"""A9T client: MCP Streamable HTTP session and room tools."""

from __future__ import annotations

import json
import re
from contextlib import AsyncExitStack

import httpx
from mcp import ClientSession, types
from mcp.client.streamable_http import streamable_http_client

from a9t_sdk.types import (
    CreateRoomParams,
    CreateRoomResult,
    GetMessagesResult,
    Message,
    PostMessageResult,
    UseRoomResult,
)

DEFAULT_BASE_URL = "https://api.a9t.io"
SDK_NAME = "a9t-sdk"
SDK_VERSION = "0.1.1"

MESSAGE_RE = re.compile(
    r"^\[(.+?)\]\s+(\S+?)(?:\s+\((.+?)\))?:\s+(.*)$",
)


def _extract_text(content: list[types.ContentBlock] | None) -> str:
    if not content:
        return ""
    for block in content:
        if isinstance(block, types.TextContent):
            return block.text
    return ""


def _parse_messages(raw: str) -> list[Message]:
    if not raw or raw == "No messages yet in this room.":
        return []
    lines: list[Message] = []
    for line in raw.split("\n"):
        match = MESSAGE_RE.match(line)
        if not match:
            lines.append(Message("", "", "", line))
            continue
        ts, sender_type, sender_id, text = match.groups()
        lines.append(
            Message(
                timestamp=ts,
                sender_type=sender_type,
                sender_id=sender_id or "",
                content=text,
            )
        )
    return lines


class A9tClient:
    """Connects to the A9T MCP server and calls room-scoped tools."""

    def __init__(self, api_key: str, *, base_url: str | None = None) -> None:
        self._api_key = api_key
        self._base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self._exit_stack: AsyncExitStack | None = None
        self._session: ClientSession | None = None

    async def __aenter__(self) -> A9tClient:
        await self.connect()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.disconnect()

    async def connect(self) -> None:
        if self._session is not None:
            return

        stack = AsyncExitStack()
        await stack.__aenter__()
        try:
            http_client = httpx.AsyncClient(
                headers={"a9t_token": self._api_key},
                timeout=httpx.Timeout(30.0, read=300.0),
            )
            await stack.enter_async_context(http_client)
            transport_cm = streamable_http_client(
                url=f"{self._base_url}/mcp",
                http_client=http_client,
            )
            read_stream, write_stream, _ = await stack.enter_async_context(
                transport_cm
            )
            session_cm = ClientSession(
                read_stream,
                write_stream,
                client_info=types.Implementation(name=SDK_NAME, version=SDK_VERSION),
            )
            session = await stack.enter_async_context(session_cm)
            await session.initialize()
            self._exit_stack = stack
            self._session = session
        except Exception:
            await stack.aclose()
            raise

    async def disconnect(self) -> None:
        if self._exit_stack is None:
            return
        try:
            await self._exit_stack.aclose()
        finally:
            self._exit_stack = None
            self._session = None

    def _ensure_session(self) -> ClientSession:
        if self._session is None:
            msg = "Client is not connected. Call connect() first."
            raise RuntimeError(msg)
        return self._session

    async def _call_tool(self, name: str, arguments: dict[str, object]) -> str:
        session = self._ensure_session()
        result = await session.call_tool(name, arguments)
        text = _extract_text(result.content)
        if result.isError:
            msg = text or f'Tool "{name}" returned an error.'
            raise RuntimeError(msg)
        return text

    async def create_room(self, params: CreateRoomParams | None = None) -> CreateRoomResult:
        p = params or CreateRoomParams()
        raw = await self._call_tool(
            "create_room",
            {
                "name": p.name,
                "mode": p.mode,
                "max_capacity": p.max_capacity,
            },
        )
        data = json.loads(raw)
        return CreateRoomResult(
            room_ref=data["room_ref"],
            name=data.get("name"),
            mode=data["mode"],
            max_capacity=data.get("max_capacity"),
            raw=raw,
        )

    async def use_room(self, room_ref: str) -> UseRoomResult:
        raw = await self._call_tool("use_room", {"room_ref": room_ref})
        return UseRoomResult(room_ref=room_ref, raw=raw)

    async def get_messages(self, limit: int = 20) -> GetMessagesResult:
        raw = await self._call_tool("get_last_messages", {"limit": limit})
        return GetMessagesResult(messages=_parse_messages(raw), raw=raw)

    async def post_message(self, content: str, *, sender_name: str) -> PostMessageResult:
        raw = await self._call_tool(
            "post_message",
            {"content": content, "sender_name": sender_name},
        )
        return PostMessageResult(raw=raw)
