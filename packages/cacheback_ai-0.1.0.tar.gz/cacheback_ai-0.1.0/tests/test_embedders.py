"""Embedder registry and base embedder tests."""

import numpy as np
import pytest
from cacheback.embedders import (
    BaseEmbedder,
    register_embedder,
    get_embedder,
    list_embedders,
    _registry,
    _clear_instances,
)


class DummyEmbedder(BaseEmbedder):
    """Minimal test embedder."""

    dim = 64
    modality = "test"

    def __init__(self, cache_dir=None):
        self.cache_dir = cache_dir

    def encode(self, input_data):
        np.random.seed(hash(str(input_data)) % (2**31))
        vec = np.random.randn(self.dim).astype(np.float32)
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        return vec


class TestBaseEmbedder:
    def test_encode_returns_normalized_vector(self):
        emb = DummyEmbedder()
        vec = emb.encode("hello world")
        assert vec.shape == (64,)
        assert vec.dtype == np.float32
        assert abs(np.linalg.norm(vec) - 1.0) < 1e-5

    def test_encode_batch_default(self):
        emb = DummyEmbedder()
        vecs = emb.encode_batch(["hello", "world"])
        assert len(vecs) == 2
        for v in vecs:
            assert v.shape == (64,)

    def test_preprocess_passthrough(self):
        emb = DummyEmbedder()
        assert emb.preprocess("raw input") == "raw input"

    def test_deterministic_encoding(self):
        emb = DummyEmbedder()
        v1 = emb.encode("hello")
        v2 = emb.encode("hello")
        np.testing.assert_array_equal(v1, v2)

    def test_different_inputs_different_vectors(self):
        emb = DummyEmbedder()
        v1 = emb.encode("hello")
        v2 = emb.encode("goodbye")
        assert not np.allclose(v1, v2)


class TestEmbedderRegistry:
    def setup_method(self):
        """Save registry state before each test."""
        self._saved = dict(_registry)

    def teardown_method(self):
        """Restore registry and clear instances after each test."""
        _registry.clear()
        _registry.update(self._saved)
        _clear_instances()

    def test_register_custom_embedder(self):
        register_embedder("test-embedder", DummyEmbedder)
        assert "test-embedder" in list_embedders()

    def test_get_custom_embedder(self):
        register_embedder("test-embedder", DummyEmbedder)
        emb = get_embedder("test-embedder")
        assert isinstance(emb, DummyEmbedder)
        assert emb.dim == 64
        assert emb.modality == "test"

    def test_get_embedder_singleton(self):
        register_embedder("test-embedder", DummyEmbedder)
        emb1 = get_embedder("test-embedder")
        emb2 = get_embedder("test-embedder")
        assert emb1 is emb2

    def test_get_unknown_embedder_raises(self):
        with pytest.raises(ValueError, match="Unknown embedder"):
            get_embedder("nonexistent-embedder-xyz")

    def test_list_embedders_includes_minilm(self):
        names = list_embedders()
        assert "minilm" in names

    def test_builtin_registration(self):
        # minilm should always be registered
        assert "minilm" in _registry
        # clip/clap/whisper may or may not be depending on imports
        # Just verify minilm exists as the base case

    def test_clear_instances(self):
        register_embedder("test-embedder", DummyEmbedder)
        emb1 = get_embedder("test-embedder")
        _clear_instances()
        emb2 = get_embedder("test-embedder")
        assert emb1 is not emb2

    def test_embedder_with_cache_dir(self):
        register_embedder("test-embedder", DummyEmbedder)
        emb1 = get_embedder("test-embedder", cache_dir="/tmp/a")
        emb2 = get_embedder("test-embedder", cache_dir="/tmp/b")
        # Different cache_dirs should create different instances
        assert emb1 is not emb2
