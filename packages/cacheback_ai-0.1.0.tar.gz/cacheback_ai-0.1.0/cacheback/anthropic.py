"""Anthropic SDK wrapper with transparent semantic caching + streaming.

Usage:
    from cacheback import CachedAnthropic

    client = CachedAnthropic()
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": "What is the capital of France?"}],
    )
    print(message._cache_hit)  # True/False

    # Streaming
    with client.messages.stream(...) as stream:
        for text in stream.text_stream:
            print(text, end="")

    # Async
    from cacheback import AsyncCachedAnthropic
    async_client = AsyncCachedAnthropic()
    message = await async_client.messages.create(...)
"""

import logging
from typing import Any, Optional

from cacheback.cache import SemanticCache, DEFAULT_CACHE_DIR
from cacheback._streaming import (
    buffer_and_cache_anthropic,
    buffer_and_cache_anthropic_async,
    replay_cached_anthropic_sync,
    replay_cached_anthropic_async,
)

logger = logging.getLogger(__name__)


# --- Response wrappers ---

class _CachedContent:
    def __init__(self, text: str):
        self.type = "text"
        self.text = text


class _CachedUsage:
    def __init__(self):
        self.input_tokens = 0
        self.output_tokens = 0


class _CachedMessage:
    """Minimal Anthropic Message response for cache hits."""

    def __init__(self, text: str, model: str = ""):
        self.id = "cache-hit"
        self.type = "message"
        self.role = "assistant"
        self.content = [_CachedContent(text)]
        self.model = model
        self.stop_reason = "end_turn"
        self.usage = _CachedUsage()
        self.cacheback_hit = True
        self._cache_hit = True  # backward compat


# --- Query extraction ---

def _extract_query(messages: list[dict]) -> str:
    """Extract last user message from Anthropic message format."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str):
                return content.strip()
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        return block.get("text", "").strip()
            break
    return ""


# --- Sync wrapper ---

class _CachedMessages:
    """Drop-in replacement for anthropic.messages with caching + streaming."""

    def __init__(self, original_messages, cache: SemanticCache):
        self._original = original_messages
        self._cache = cache

    def create(self, **kwargs) -> Any:
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "")
        stream = kwargs.get("stream", False)
        query = _extract_query(messages)

        # Skip caching for tool use or empty queries
        if kwargs.get("tools") or not query:
            return self._original.create(**kwargs)

        cached = self._cache.lookup(query)

        if stream:
            if cached is not None:
                logger.debug("[cacheback] STREAM HIT for: %s", query[:80])
                return replay_cached_anthropic_sync(cached, model=model)
            upstream = self._original.create(**kwargs)
            return buffer_and_cache_anthropic(upstream, self._cache, query, model=model)

        if cached is not None:
            logger.debug("[cacheback] HIT for: %s", query[:80])
            return _CachedMessage(text=cached, model=model)

        response = self._original.create(**kwargs)

        # Populate cache
        if response.content:
            text_parts = [b.text for b in response.content if hasattr(b, "text")]
            full_text = " ".join(text_parts)
            if full_text:
                tokens = response.usage.output_tokens if response.usage else 0
                self._cache.populate(query, full_text, model=model, tokens=tokens)

        return response


# --- Async wrapper ---

class _AsyncCachedMessages:
    """Async drop-in replacement for anthropic.messages."""

    def __init__(self, original_messages, cache: SemanticCache):
        self._original = original_messages
        self._cache = cache

    async def create(self, **kwargs) -> Any:
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "")
        stream = kwargs.get("stream", False)
        query = _extract_query(messages)

        if kwargs.get("tools") or not query:
            return await self._original.create(**kwargs)

        cached = self._cache.lookup(query)

        if stream:
            if cached is not None:
                logger.debug("[cacheback] ASYNC STREAM HIT for: %s", query[:80])
                return replay_cached_anthropic_async(cached, model=model)
            upstream = await self._original.create(**kwargs)
            return buffer_and_cache_anthropic_async(upstream, self._cache, query, model=model)

        if cached is not None:
            logger.debug("[cacheback] ASYNC HIT for: %s", query[:80])
            return _CachedMessage(text=cached, model=model)

        response = await self._original.create(**kwargs)

        if response.content:
            text_parts = [b.text for b in response.content if hasattr(b, "text")]
            full_text = " ".join(text_parts)
            if full_text:
                tokens = response.usage.output_tokens if response.usage else 0
                self._cache.populate(query, full_text, model=model, tokens=tokens)

        return response


# --- Main classes ---

class CachedAnthropic:
    """Drop-in replacement for anthropic.Anthropic with semantic caching.

    Args:
        cache_dir: Directory for cache data
        similarity_threshold: Similarity threshold for hits (default: 0.92)
        negative_threshold: Similarity threshold for negative cache (default: 0.85)
        cache_max_entries: Max entries before LRU eviction
        cache_ttl: TTL in seconds (default: 24 hours)
        cache_enabled: Enable/disable caching
        on_negative_hit: Policy for negative cache ("raise", "skip", or callable)
        **kwargs: Passed to anthropic.Anthropic()
    """

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        similarity_threshold: float = 0.92,
        negative_threshold: float = 0.85,
        cache_max_entries: int = 100_000,
        cache_ttl: int = 24 * 3600,
        cache_enabled: bool = True,
        on_negative_hit: str = "raise",
        **kwargs,
    ):
        try:
            from anthropic import Anthropic
        except ImportError:
            raise ImportError(
                "anthropic package required. Install with: pip install cacheback-ai[anthropic]"
            )

        self._client = Anthropic(**kwargs)
        self.cache = SemanticCache(
            cache_dir=cache_dir or DEFAULT_CACHE_DIR,
            similarity_threshold=similarity_threshold,
            negative_threshold=negative_threshold,
            max_entries=cache_max_entries,
            ttl_seconds=cache_ttl,
            enabled=cache_enabled,
            on_negative_hit=on_negative_hit,
        )
        self.messages = _CachedMessages(self._client.messages, self.cache)

    def __getattr__(self, name):
        return getattr(self._client, name)

    def close(self):
        self.cache.close()
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class AsyncCachedAnthropic:
    """Drop-in replacement for anthropic.AsyncAnthropic with semantic caching.

    Same args as CachedAnthropic.
    """

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        similarity_threshold: float = 0.92,
        negative_threshold: float = 0.85,
        cache_max_entries: int = 100_000,
        cache_ttl: int = 24 * 3600,
        cache_enabled: bool = True,
        on_negative_hit: str = "raise",
        **kwargs,
    ):
        try:
            from anthropic import AsyncAnthropic
        except ImportError:
            raise ImportError(
                "anthropic package required. Install with: pip install cacheback-ai[anthropic]"
            )

        self._client = AsyncAnthropic(**kwargs)
        self.cache = SemanticCache(
            cache_dir=cache_dir or DEFAULT_CACHE_DIR,
            similarity_threshold=similarity_threshold,
            negative_threshold=negative_threshold,
            max_entries=cache_max_entries,
            ttl_seconds=cache_ttl,
            enabled=cache_enabled,
            on_negative_hit=on_negative_hit,
        )
        self.messages = _AsyncCachedMessages(self._client.messages, self.cache)

    def __getattr__(self, name):
        return getattr(self._client, name)

    async def close(self):
        self.cache.close()
        await self._client.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
