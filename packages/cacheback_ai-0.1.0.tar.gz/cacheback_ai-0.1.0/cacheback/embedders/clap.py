"""CLAP audio embedder — 512-dim vectors for audio-level matching.

Compares audio similarity directly (same sound = same response).
Best for: SFX, alarms, environmental audio, audio fingerprinting.

Phase 2 — will be fully implemented when voice cache ships.
"""

import logging
import os
from typing import Any, Optional

import numpy as np

from cacheback.embedders import BaseEmbedder

logger = logging.getLogger(__name__)


class CLAPEmbedder(BaseEmbedder):
    """Audio embedder using CLAP via ONNX Runtime."""

    dim = 512
    modality = "voice"

    def __init__(self, cache_dir: Optional[str] = None):
        self._cache_dir = cache_dir or os.path.join(
            os.path.expanduser("~"), ".cacheback", "models"
        )
        self._session = None

    def _ensure_model(self):
        if self._session is not None:
            return
        raise NotImplementedError(
            "CLAP embedder is planned for cacheback v0.3.0 (Phase 2). "
            "Currently only text (MiniLM) is supported."
        )

    def encode(self, input_data: Any) -> np.ndarray:
        """Encode audio bytes into a normalized 512-dim vector."""
        self._ensure_model()
        return np.zeros(self.dim, dtype=np.float32)  # placeholder
