"""Whisper + MiniLM compound embedder — voice → text → semantic vector.

Transcribes audio via Whisper, then embeds the text with MiniLM.
Best for: voice assistants, dictation — "same meaning = same response".

Phase 2 — will be fully implemented when voice cache ships.
"""

import logging
import os
from typing import Any, Optional

import numpy as np

from cacheback.embedders import BaseEmbedder

logger = logging.getLogger(__name__)


class WhisperEmbedder(BaseEmbedder):
    """Voice-to-text-to-vector embedder using Whisper + MiniLM pipeline."""

    dim = 384  # MiniLM output dimension (text-level matching)
    modality = "voice"

    def __init__(self, cache_dir: Optional[str] = None):
        self._cache_dir = cache_dir or os.path.join(
            os.path.expanduser("~"), ".cacheback", "models"
        )
        self._whisper_session = None
        self._minilm = None

    def _ensure_model(self):
        if self._whisper_session is not None:
            return
        raise NotImplementedError(
            "Whisper embedder is planned for cacheback v0.3.0 (Phase 2). "
            "Currently only text (MiniLM) is supported."
        )

    def encode(self, input_data: Any) -> np.ndarray:
        """Encode audio bytes: transcribe → embed text → normalized vector."""
        self._ensure_model()
        return np.zeros(self.dim, dtype=np.float32)  # placeholder
