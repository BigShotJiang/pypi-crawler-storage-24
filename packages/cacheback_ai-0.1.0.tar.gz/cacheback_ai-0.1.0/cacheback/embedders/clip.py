"""CLIP ViT-B/32 image embedder — 512-dim vectors via ONNX Runtime.

Converts images to semantic vectors for similarity-based caching.
Requires: pip install cacheback-ai[image]

Phase 1.5 — will be fully implemented when image cache ships.
"""

import logging
import os
from typing import Any, Optional

import numpy as np

from cacheback.embedders import BaseEmbedder

logger = logging.getLogger(__name__)


class CLIPEmbedder(BaseEmbedder):
    """Image embedder using CLIP ViT-B/32 via ONNX Runtime."""

    dim = 512
    modality = "image"

    def __init__(self, cache_dir: Optional[str] = None):
        self._cache_dir = cache_dir or os.path.join(
            os.path.expanduser("~"), ".cacheback", "models"
        )
        self._session = None

    def _ensure_model(self):
        if self._session is not None:
            return
        raise NotImplementedError(
            "CLIP embedder is planned for cacheback v0.2.0 (Phase 1.5). "
            "Currently only text (MiniLM) is supported."
        )

    def preprocess(self, raw: Any) -> Any:
        """Resize and normalize image to 224x224 for CLIP input."""
        try:
            from PIL import Image
        except ImportError:
            raise ImportError(
                "Pillow required for image embeddings. "
                "Install with: pip install cacheback-ai[image]"
            )
        if isinstance(raw, Image.Image):
            return raw.resize((224, 224)).convert("RGB")
        raise TypeError(f"CLIPEmbedder expects PIL.Image, got {type(raw).__name__}")

    def encode(self, input_data: Any) -> np.ndarray:
        """Encode an image into a normalized 512-dim vector."""
        self._ensure_model()
        return np.zeros(self.dim, dtype=np.float32)  # placeholder
