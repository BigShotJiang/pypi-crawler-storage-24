"""
S3 Volume Mounting.

Mount S3 buckets as local filesystems using s3fs-fuse.
Great for large datasets that don't fit in instance storage.
"""

import skyward as sky


@sky.function
def list_data_files() -> list[str]:
    """List files in the mounted S3 bucket."""
    import os

    files = []
    for root, _, filenames in os.walk("/data"):
        for f in filenames:
            path = os.path.join(root, f)
            size = os.path.getsize(path)
            files.append(f"{path} ({size} bytes)")
    return files[:10]  # First 10 files


@sky.function
def process_data_file(path: str) -> dict:
    """Process a file from the mounted volume."""
    with open(path, "rb") as f:
        data = f.read()
    return {
        "path": path,
        "size": len(data),
        "checksum": hash(data) & 0xFFFFFFFF,
    }


@sky.function
def save_checkpoint(data: dict) -> str:
    """Save checkpoint to writable volume."""
    import json
    import os

    os.makedirs("/checkpoints/run1", exist_ok=True)
    path = "/checkpoints/run1/checkpoint.json"

    with open(path, "w") as f:
        json.dump(data, f)

    return f"Saved to {path}"


def main():
    # Read-only volume for input data
    data_volume = sky.Volume(
        bucket="my-ml-datasets",
        mount="/data",
        prefix="training/",
        read_only=True,
    )

    # Read-write volume for checkpoints
    checkpoint_volume = sky.Volume(
        bucket="my-ml-outputs",
        mount="/checkpoints",
        prefix="checkpoints/",
        read_only=False,
    )

    with sky.Compute(
        provider=sky.AWS(),
        accelerator=sky.accelerators.T4(),
        volumes=[data_volume, checkpoint_volume],
        image=sky.Image(pip=["numpy"]),
        allocation="spot-if-available",
    ) as compute:
        # List files in mounted volume
        files = list_data_files() >> compute
        print("Data files found:")
        for f in files:
            print(f"  {f}")

        # Process a file (if any exist)
        if files:
            # Extract path from listing
            path = files[0].split(" ")[0]
            result = process_data_file(path) >> compute
            print(f"\nProcessed: {result}")

        # Save checkpoint
        checkpoint_data = {"epoch": 10, "loss": 0.01, "accuracy": 0.99}
        save_path = save_checkpoint(checkpoint_data) >> compute
        print(f"\n{save_path}")


if __name__ == "__main__":
    main()
