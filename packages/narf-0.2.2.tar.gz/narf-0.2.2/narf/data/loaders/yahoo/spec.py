from narf.data.loaders.base_spec import NodeSpec

from .loader import YahooFundamentalsLoader, YahooKlinesLoader


# A minimal Yahoo namespace:
# - yahoo.klines.load(...) for OHLCV candles (history)
# - yahoo.fundamentals.load(...) for company/asset fundamentals

yahoo_spec = NodeSpec(
    children={
        "klines": NodeSpec(key="datatype", loader=YahooKlinesLoader),
        "fundamentals": NodeSpec(key="datatype", loader=YahooFundamentalsLoader),
    }
)
