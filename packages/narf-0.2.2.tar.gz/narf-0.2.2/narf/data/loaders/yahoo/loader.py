from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import pandas as pd

from narf.data.loaders.cache_config import get_cache_root
from narf.data.loaders.utils import DATETIME_INDEX_DTYPE_MS_UTC


# NOTE:
# - We intentionally keep Yahoo integration simple and self-contained.
# - Primary backend: yfinance
# - Caching: local files under ./cache/yahoo/


def _ensure_utc_index(idx: pd.DatetimeIndex) -> pd.DatetimeIndex:
    # yfinance sometimes returns tz-naive index; normalize to UTC.
    if getattr(idx, "tz", None) is None:
        return idx.tz_localize("UTC")
    return idx.tz_convert("UTC")


def _cache_key(*parts: str) -> str:
    raw = "|".join(parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class YahooCache:
    root: Path = field(default_factory=lambda: get_cache_root() / "yahoo")

    def path_for(self, kind: str, key: str, suffix: str) -> Path:
        return self.root / kind / f"{key}{suffix}"


class YahooKlinesLoader:
    def __init__(self, path: tuple[str, ...]):
        self._path = path
        self._cache = YahooCache()

    def load(
        self,
        symbol: str,
        start: datetime,
        end: Optional[datetime] = None,
        interval: str = "1d",
        *,
        force: bool = False,
    ) -> pd.DataFrame:
        """Load OHLCV bars from Yahoo Finance.

        Args:
            symbol: Yahoo ticker (e.g. AAPL, ^GSPC, EURUSD=X, BTC-USD)
            start/end: datetime range (end optional)
            interval: Yahoo/yfinance interval (e.g. 1d, 1h, 15m)
            force: bypass cache

        Returns:
            DataFrame indexed by UTC timestamps with columns:
              open, high, low, close, volume (+ adj_close if present)
        """
        if end is None:
            end = datetime.now()

        key = _cache_key("klines", symbol, interval, start.isoformat(), end.isoformat())
        out = self._cache.path_for("klines", key, ".parquet")
        out.parent.mkdir(parents=True, exist_ok=True)

        if out.exists() and not force:
            df = pd.read_parquet(out, engine="pyarrow")
            return df

        import yfinance as yf

        df = yf.download(
            tickers=symbol,
            start=start,
            end=end,
            interval=interval,
            auto_adjust=False,
            progress=False,
            group_by="column",
            threads=True,
        )

        if df is None or len(df) == 0:
            return pd.DataFrame()

        # For a single ticker, yfinance can still return a MultiIndex columns
        # like ("Open", "AAPL"). Flatten it.
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)

        # yfinance returns columns: Open High Low Close Adj Close Volume
        df = df.rename(
            columns={
                "Open": "open",
                "High": "high",
                "Low": "low",
                "Close": "close",
                "Adj Close": "adj_close",
                "Volume": "volume",
            }
        )

        df.columns.name = None

        # Keep only known columns (some symbols may omit Adj Close)
        cols = [c for c in ["open", "high", "low", "close", "adj_close", "volume"] if c in df.columns]
        df = df[cols].copy()

        df.index = _ensure_utc_index(pd.DatetimeIndex(df.index))
        df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)
        df.index.name = "time"
        df.sort_index(inplace=True)

        # Write cache (parquet for better compression and performance)
        df.to_parquet(out, engine="pyarrow")
        return df


class YahooFundamentalsLoader:
    def __init__(self, path: tuple[str, ...]):
        self._path = path
        self._cache = YahooCache()

    def load(
        self,
        symbol: str,
        *,
        force: bool = False,
    ) -> dict[str, Any]:
        """Load fundamentals/metadata for a Yahoo ticker.

        Uses yfinance's `.info` which aggregates many Yahoo fundamentals fields.

        Returns:
            A JSON-serializable dict of fundamentals fields.
        """
        key = _cache_key("fundamentals", symbol)
        out = self._cache.path_for("fundamentals", key, ".json")
        out.parent.mkdir(parents=True, exist_ok=True)

        if out.exists() and not force:
            return json.loads(out.read_text(encoding="utf-8"))

        import yfinance as yf

        info = yf.Ticker(symbol).info or {}

        # Ensure JSON-serializable (some values can be numpy scalars, Timestamps, etc.)
        def _to_jsonable(x: Any) -> Any:
            if isinstance(x, (str, int, float, bool)) or x is None:
                return x
            if isinstance(x, (datetime,)):
                return x.isoformat()
            # pandas Timestamp
            try:
                import pandas as _pd

                if isinstance(x, _pd.Timestamp):
                    return x.isoformat()
            except Exception:
                pass
            # numpy scalars
            try:
                import numpy as _np

                if isinstance(x, _np.generic):
                    return x.item()
            except Exception:
                pass
            # lists/tuples
            if isinstance(x, (list, tuple)):
                return [_to_jsonable(v) for v in x]
            if isinstance(x, dict):
                return {str(k): _to_jsonable(v) for k, v in x.items()}
            # fallback: string repr
            return str(x)

        info = _to_jsonable(info)
        out.write_text(json.dumps(info, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        return info
