from narf.data.loaders.base_spec import build

from .spec import yahoo_spec


yahoo = build(yahoo_spec)


__all__ = ["yahoo"]
