"""Cache backend abstraction for narf data loaders.

Supports multiple backends (filesystem and S3) with a unified interface.
"""

import asyncio
import json
import os
import pickle
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

import pandas as pd


class CacheBackend(ABC):
    """Abstract base class for cache backends."""

    @abstractmethod
    def save(self, path: str, data: Any) -> None:
        """Save data to cache at the given path.
        
        Args:
            path: Cache path (string, includes filename with extension)
            data: Data to save (DataFrame, dict, or any pickleable type)
        """
        pass

    @abstractmethod
    def load(self, path: str) -> Any:
        """Load data from cache at the given path.
        
        Args:
            path: Cache path (string, includes filename with extension)
            
        Returns:
            Cached data
            
        Raises:
            FileNotFoundError: If cache entry doesn't exist
        """
        pass

    @abstractmethod
    def try_load(self, path: str) -> Any | None:
        """Try to load data from cache, returning None if it doesn't exist.
        
        This method avoids making two separate calls (exists + load) which is
        especially important for S3 backend to reduce network calls.
        
        Args:
            path: Cache path (string, includes filename with extension)
            
        Returns:
            Cached data if exists, None otherwise
        """
        pass

    @abstractmethod
    def exists(self, path: str) -> bool:
        """Check if a cache entry exists.
        
        Args:
            path: Cache path (string, includes filename with extension)
            
        Returns:
            True if cache entry exists, False otherwise
        """
        pass

    @abstractmethod
    def delete(self, path: str) -> bool:
        """Delete a cache entry.
        
        Args:
            path: Cache path (string, includes filename with extension)

        Returns:
            True if cache entry was deleted, False otherwise
        """
        pass

    @abstractmethod
    async def asave(self, path: str, data: Any) -> None:
        """Async save data to cache at the given path.
        
        Args:
            path: Cache path (string, includes filename with extension)
            data: Data to save (DataFrame, dict, or any pickleable type)
        """
        pass

    @abstractmethod
    async def aload(self, path: str) -> Any:
        """Async load data from cache at the given path.
        
        Args:
            path: Cache path (string, includes filename with extension)
            
        Returns:
            Cached data
            
        Raises:
            FileNotFoundError: If cache entry doesn't exist
        """
        pass

    @abstractmethod
    async def atry_load(self, path: str) -> Any | None:
        """Async try to load data from cache, returning None if it doesn't exist.
        
        This method avoids making two separate calls (exists + load) which is
        especially important for S3 backend to reduce network calls.
        
        Args:
            path: Cache path (string, includes filename with extension)
            
        Returns:
            Cached data if exists, None otherwise
        """
        pass

    @abstractmethod
    async def aexists(self, path: str) -> bool:
        """Async check if a cache entry exists.
        
        Args:
            path: Cache path (string, includes filename with extension)
            
        Returns:
            True if cache entry exists, False otherwise
        """
        pass

    @abstractmethod
    async def adelete(self, path: str) -> bool:
        """Async delete a cache entry.
        
        Args:
            path: Cache path (string, includes filename with extension)

        Returns:
            True if cache entry was deleted, False otherwise
        """
        pass


class LocalFilesystemBackend(CacheBackend):
    """Local filesystem cache backend."""

    def __init__(self, cache_root: Path | None = None):
        """Initialize filesystem backend.
        
        Args:
            cache_root: Root directory for cache files. If None, uses get_cache_root()
        """
        if cache_root is None:
            # Lazy import to avoid circular dependency
            from narf.data.loaders.cache_config import get_cache_root
            cache_root = get_cache_root()
        self.cache_root = cache_root
        # Create cache root directory if it doesn't exist
        self.cache_root.mkdir(parents=True, exist_ok=True)

    def _get_full_path(self, path: str) -> Path:
        """Convert string path to full Path object."""
        return self.cache_root / path

    def save(self, path: str, data: Any) -> None:
        """Save data to cache file.
        
        Validates data format matches path extension:
        - .parquet → must be pd.DataFrame
        - .json → must be dict
        - .pkl → any pickleable type
        """
        full_path = self._get_full_path(path)
        full_path.parent.mkdir(parents=True, exist_ok=True)
        
        if path.endswith(".parquet"):
            if not isinstance(data, pd.DataFrame):
                raise TypeError(f"Expected pd.DataFrame for .parquet file, got {type(data).__name__}")
            data.to_parquet(full_path, engine="pyarrow")
        elif path.endswith(".json"):
            if not isinstance(data, dict):
                raise TypeError(f"Expected dict for .json file, got {type(data).__name__}")
            full_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8"
            )
        elif path.endswith(".pkl"):
            with full_path.open("wb") as f:
                pickle.dump(data, f)
        else:
            raise ValueError(f"Unsupported file format: {path}. Supported formats: .parquet, .json, .pkl")

    def load(self, path: str) -> Any:
        """Load data from cache file.
        
        Automatically determines the file format based on path extension.
        """
        full_path = self._get_full_path(path)
        
        if not full_path.exists():
            raise FileNotFoundError(f"Cache file not found: {path}")
        
        if path.endswith(".parquet"):
            return pd.read_parquet(full_path, engine="pyarrow")
        elif path.endswith(".json"):
            return json.loads(full_path.read_text(encoding="utf-8"))
        elif path.endswith(".pkl"):
            with full_path.open("rb") as f:
                return pickle.load(f)
        else:
            raise ValueError(f"Unsupported file format: {path}. Supported formats: .parquet, .json, .pkl")

    def try_load(self, path: str) -> Any | None:
        """Try to load data from cache, returning None if it doesn't exist."""
        full_path = self._get_full_path(path)
        
        if not full_path.exists():
            return None
        
        try:
            return self.load(path)
        except FileNotFoundError:
            return None

    def exists(self, path: str) -> bool:
        """Check if cache file exists."""
        return self._get_full_path(path).exists()

    def delete(self, path: str) -> bool:
        """Delete cache file."""
        full_path = self._get_full_path(path)
        if full_path.exists():
            full_path.unlink()
            return True
        return False

    async def asave(self, path: str, data: Any) -> None:
        """Async save data to cache file (calls sync version)."""
        self.save(path, data)

    async def aload(self, path: str) -> Any:
        """Async load data from cache file (calls sync version)."""
        return self.load(path)

    async def atry_load(self, path: str) -> Any | None:
        """Async try to load data from cache (calls sync version)."""
        return self.try_load(path)

    async def aexists(self, path: str) -> bool:
        """Async check if cache file exists (calls sync version)."""
        return self.exists(path)

    async def adelete(self, path: str) -> bool:
        """Async delete cache file (calls sync version)."""
        return self.delete(path)


def _s3_store_local_cache() -> bool:
    """Return False when NARF_CACHE_S3_NO_LOCAL_CACHE=1 (no local copy of S3 data)."""
    return os.environ.get("NARF_CACHE_S3_NO_LOCAL_CACHE") != "1"


class S3Backend(CacheBackend):
    """S3 cache backend using boto3 (sync) and aioboto3 (async).
    
    Automatically caches S3 downloads locally in cwd/cache folder, replicating the same structure.
    Set NARF_CACHE_S3_NO_LOCAL_CACHE=1 to skip storing local copies (S3 only).
    """

    def __init__(self, bucket: str, access_key_id: str, secret_access_key: str, region: str):
        """Initialize S3 backend.
        
        Args:
            bucket: S3 bucket name
            access_key_id: AWS access key ID
            secret_access_key: AWS secret access key
            region: AWS region
            
        Raises:
            ImportError: If boto3 is not installed
        """
        try:
            import boto3
        except ImportError:
            raise ImportError(
                "boto3 is required for S3 backend. Install it with: pip install narf-market-data[s3]"
            )
        
        self.bucket = bucket
        self.access_key_id = access_key_id
        self.secret_access_key = secret_access_key
        self.region = region
        self.s3_client = boto3.client(
            "s3",
            aws_access_key_id=access_key_id,
            aws_secret_access_key=secret_access_key,
            region_name=region,
        )
        self._s3_session = None
        self._async_s3_client = None
        self._async_client_context = None
        self._async_client_lock = asyncio.Lock()

        # Initialize local cache root
        from narf.data.loaders.cache_config import get_cache_root
        self.local_cache_root = get_cache_root()
        self.local_cache_root.mkdir(parents=True, exist_ok=True)
    
    def _get_local_cache_path(self, path: str) -> Path:
        """Get the local cache path for an S3 path, replicating the same structure."""
        return self.local_cache_root / path
    
    def _load_from_local_cache(self, path: str) -> Any | None:
        """Load data from local cache if it exists."""
        local_path = self._get_local_cache_path(path)
        if not local_path.exists():
            return None
        
        try:
            if path.endswith(".parquet"):
                return pd.read_parquet(local_path, engine="pyarrow")
            elif path.endswith(".json"):
                return json.loads(local_path.read_text(encoding="utf-8"))
            elif path.endswith(".pkl"):
                with local_path.open("rb") as f:
                    return pickle.load(f)
            else:
                return None
        except Exception:
            # If loading fails, return None to fall back to S3
            return None
    
    def _save_to_local_cache(self, path: str, data: Any) -> None:
        """Save data to local cache, replicating the S3 structure."""
        local_path = self._get_local_cache_path(path)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        
        if path.endswith(".parquet"):
            if isinstance(data, pd.DataFrame):
                data.to_parquet(local_path, engine="pyarrow")
            else:
                # If data is bytes (raw), save it directly
                local_path.write_bytes(data)
        elif path.endswith(".json"):
            if isinstance(data, dict):
                local_path.write_text(
                    json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True),
                    encoding="utf-8"
                )
            else:
                # If data is bytes (raw), save it directly
                local_path.write_bytes(data)
        elif path.endswith(".pkl"):
            if isinstance(data, bytes):
                local_path.write_bytes(data)
            else:
                with local_path.open("wb") as f:
                    pickle.dump(data, f)
    
    def _save_bytes_to_local_cache(self, path: str, body: bytes) -> None:
        """Save raw bytes to local cache."""
        local_path = self._get_local_cache_path(path)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        # For JSON files, save as text; for others, save as bytes
        if path.endswith(".json"):
            local_path.write_text(body.decode("utf-8"), encoding="utf-8")
        else:
            local_path.write_bytes(body)

    def save(self, path: str, data: Any) -> None:
        """Save data to S3 and local cache.
        
        Validates data format matches path extension:
        - .parquet → must be pd.DataFrame (PyArrow, saved as bytes)
        - .json → must be dict (saved as JSON string)
        - .pkl → any pickleable type (saved as bytes)
        """
        import io
        
        if path.endswith(".parquet"):
            if not isinstance(data, pd.DataFrame):
                raise TypeError(f"Expected pd.DataFrame for .parquet file, got {type(data).__name__}")
            buffer = io.BytesIO()
            data.to_parquet(buffer, engine="pyarrow")
            body = buffer.getvalue()
            self.s3_client.put_object(
                Bucket=self.bucket,
                Key=path,
                Body=body,
            )
            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        elif path.endswith(".json"):
            if not isinstance(data, dict):
                raise TypeError(f"Expected dict for .json file, got {type(data).__name__}")
            json_str = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
            body = json_str.encode("utf-8")
            self.s3_client.put_object(
                Bucket=self.bucket,
                Key=path,
                Body=body,
                ContentType="application/json",
            )
            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        elif path.endswith(".pkl"):
            buffer = io.BytesIO()
            pickle.dump(data, buffer)
            body = buffer.getvalue()
            self.s3_client.put_object(
                Bucket=self.bucket,
                Key=path,
                Body=body,
            )
            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        else:
            raise ValueError(f"Unsupported file format: {path}. Supported formats: .parquet, .json, .pkl")

    def load(self, path: str) -> Any:
        """Load data from S3, checking local cache first.
        
        Automatically determines the file format based on path extension.
        """
        import io
        
        # Check local cache first (unless NARF_CACHE_S3_NO_LOCAL_CACHE=1)
        if _s3_store_local_cache():
            cached_data = self._load_from_local_cache(path)
            if cached_data is not None:
                print(f"Loading from local cache: {self._get_local_cache_path(path)}")
                return cached_data
        
        # Download from S3 if not in local cache
        try:
            response = self.s3_client.get_object(Bucket=self.bucket, Key=path)
            body = response["Body"].read()
            print(f"Loading S3 cache file: s3://{self.bucket}/{path}")
            
            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        except Exception as e:
            # Check if it's a NoSuchKey error
            error_code = getattr(e, "response", {}).get("Error", {}).get("Code", "")
            if error_code == "NoSuchKey" or "NoSuchKey" in str(e):
                raise FileNotFoundError(f"Cache file not found in S3: {path}")
            raise
        
        if path.endswith(".parquet"):
            buffer = io.BytesIO(body)
            return pd.read_parquet(buffer, engine="pyarrow")
        elif path.endswith(".json"):
            return json.loads(body.decode("utf-8"))
        elif path.endswith(".pkl"):
            buffer = io.BytesIO(body)
            return pickle.load(buffer)
        else:
            raise ValueError(f"Unsupported file format: {path}. Supported formats: .parquet, .json, .pkl")

    def try_load(self, path: str) -> Any | None:
        """Try to load data from S3, checking local cache first, returning None if it doesn't exist.
        
        This avoids making two separate network calls (head_object + get_object).
        """
        import io
        
        # Check local cache first (unless NARF_CACHE_S3_NO_LOCAL_CACHE=1)
        if _s3_store_local_cache():
            cached_data = self._load_from_local_cache(path)
            if cached_data is not None:
                return cached_data
        
        # Download from S3 if not in local cache
        try:
            response = self.s3_client.get_object(Bucket=self.bucket, Key=path)
            body = response["Body"].read()
            print(f"Loading S3 cache file: s3://{self.bucket}/{path}")
            
            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        except Exception as e:
            # Check if it's a NoSuchKey error
            error_code = getattr(e, "response", {}).get("Error", {}).get("Code", "")
            if error_code == "NoSuchKey" or "NoSuchKey" in str(e):
                return None
            # Re-raise other errors
            raise
        
        # Parse the data based on extension
        if path.endswith(".parquet"):
            buffer = io.BytesIO(body)
            return pd.read_parquet(buffer, engine="pyarrow")
        elif path.endswith(".json"):
            return json.loads(body.decode("utf-8"))
        elif path.endswith(".pkl"):
            buffer = io.BytesIO(body)
            return pickle.load(buffer)
        else:
            raise ValueError(f"Unsupported file format: {path}. Supported formats: .parquet, .json, .pkl")

    def exists(self, path: str) -> bool:
        """Check if cache file exists in local cache or S3."""
        # Check local cache first (unless NARF_CACHE_S3_NO_LOCAL_CACHE=1)
        if _s3_store_local_cache() and self._get_local_cache_path(path).exists():
            return True
        # Check S3
        try:
            self.s3_client.head_object(Bucket=self.bucket, Key=path)
            return True
        except Exception:
            return False

    def delete(self, path: str) -> bool:
        """Delete cache file from S3 and local cache."""
        deleted = False
        # Delete from local cache (if we use local cache)
        if _s3_store_local_cache():
            local_path = self._get_local_cache_path(path)
            if local_path.exists():
                local_path.unlink()
                deleted = True
        # Delete from S3
        try:
            self.s3_client.delete_object(Bucket=self.bucket, Key=path)
            deleted = True
        except Exception:
            pass
        return deleted

    async def _get_s3_session(self):
        """Get or create aioboto3 session for async operations."""
        if self._s3_session is None:
            try:
                import aioboto3
            except ImportError:
                raise ImportError(
                    "aioboto3 is required for async S3 operations. Install it with: pip install narf-market-data[s3]"
                )
            self._s3_session = aioboto3.Session()
        return self._s3_session

    async def _get_async_s3_client(self):
        """Get or create reusable aioboto3 S3 client for async operations.

        Client is created once and reused across all async operations to avoid
        connection setup overhead when fetching many S3 objects.
        """
        async with self._async_client_lock:
            if self._async_s3_client is None:
                session = await self._get_s3_session()
                self._async_client_context = session.client(
                    "s3",
                    aws_access_key_id=self.access_key_id,
                    aws_secret_access_key=self.secret_access_key,
                    region_name=self.region,
                )
                self._async_s3_client = await self._async_client_context.__aenter__()
            return self._async_s3_client

    async def asave(self, path: str, data: Any) -> None:
        """Async save data to S3 and local cache.
        
        Validates data format matches path extension:
        - .parquet → must be pd.DataFrame (PyArrow, saved as bytes)
        - .json → must be dict (saved as JSON string)
        - .pkl → any pickleable type (saved as bytes)
        """
        import io

        s3_client = await self._get_async_s3_client()

        if path.endswith(".parquet"):
            if not isinstance(data, pd.DataFrame):
                raise TypeError(f"Expected pd.DataFrame for .parquet file, got {type(data).__name__}")
            buffer = io.BytesIO()
            data.to_parquet(buffer, engine="pyarrow")
            body = buffer.getvalue()
            await s3_client.put_object(
                Bucket=self.bucket,
                Key=path,
                Body=body,
            )
            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        elif path.endswith(".json"):
            if not isinstance(data, dict):
                raise TypeError(f"Expected dict for .json file, got {type(data).__name__}")
            json_str = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
            body = json_str.encode("utf-8")
            await s3_client.put_object(
                Bucket=self.bucket,
                Key=path,
                Body=body,
                ContentType="application/json",
            )
            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        elif path.endswith(".pkl"):
            buffer = io.BytesIO()
            pickle.dump(data, buffer)
            body = buffer.getvalue()
            await s3_client.put_object(
                Bucket=self.bucket,
                Key=path,
                Body=body,
            )
            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        else:
            raise ValueError(f"Unsupported file format: {path}. Supported formats: .parquet, .json, .pkl")

    async def aload(self, path: str) -> Any:
        """Async load data from S3, checking local cache first.
        
        Automatically determines the file format based on path extension.
        """
        import io
        from botocore.exceptions import ClientError

        # Check local cache first (unless NARF_CACHE_S3_NO_LOCAL_CACHE=1)
        if _s3_store_local_cache():
            cached_data = self._load_from_local_cache(path)
            if cached_data is not None:
                print(f"Loading from local cache: {self._get_local_cache_path(path)}")
                return cached_data

        # Download from S3 if not in local cache
        s3_client = await self._get_async_s3_client()

        try:
            response = await s3_client.get_object(Bucket=self.bucket, Key=path)
            async with response["Body"] as stream:
                body = await stream.read()
            print(f"Loading S3 cache file: s3://{self.bucket}/{path}")

            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "NoSuchKey":
                raise FileNotFoundError(f"Cache file not found in S3: {path}")
            raise
        except Exception as e:
            # Fallback check for NoSuchKey in string representation
            if "NoSuchKey" in str(e):
                raise FileNotFoundError(f"Cache file not found in S3: {path}")
            raise
        
        if path.endswith(".parquet"):
            buffer = io.BytesIO(body)
            return pd.read_parquet(buffer, engine="pyarrow")
        elif path.endswith(".json"):
            return json.loads(body.decode("utf-8"))
        elif path.endswith(".pkl"):
            buffer = io.BytesIO(body)
            return pickle.load(buffer)
        else:
            raise ValueError(f"Unsupported file format: {path}. Supported formats: .parquet, .json, .pkl")

    async def atry_load(self, path: str) -> Any | None:
        """Async try to load data from S3, checking local cache first, returning None if it doesn't exist.
        
        This avoids making two separate network calls (head_object + get_object).
        """
        import io
        from botocore.exceptions import ClientError
        
        # Check local cache first (unless NARF_CACHE_S3_NO_LOCAL_CACHE=1)
        if _s3_store_local_cache():
            cached_data = self._load_from_local_cache(path)
            if cached_data is not None:
                return cached_data
        
        # Download from S3 if not in local cache
        s3_client = await self._get_async_s3_client()

        try:
            response = await s3_client.get_object(Bucket=self.bucket, Key=path)
            async with response["Body"] as stream:
                body = await stream.read()
            print(f"Loading S3 cache file: s3://{self.bucket}/{path}")

            if _s3_store_local_cache():
                self._save_bytes_to_local_cache(path, body)
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "NoSuchKey":
                return None
            # Re-raise other errors
            raise
        except Exception as e:
            # Fallback check for NoSuchKey in string representation
            if "NoSuchKey" in str(e):
                return None
            # Re-raise other errors
            raise
        
        # Parse the data based on extension
        if path.endswith(".parquet"):
            buffer = io.BytesIO(body)
            return pd.read_parquet(buffer, engine="pyarrow")
        elif path.endswith(".json"):
            return json.loads(body.decode("utf-8"))
        elif path.endswith(".pkl"):
            buffer = io.BytesIO(body)
            return pickle.load(buffer)
        else:
            raise ValueError(f"Unsupported file format: {path}. Supported formats: .parquet, .json, .pkl")

    async def aexists(self, path: str) -> bool:
        """Async check if cache file exists in local cache or S3."""
        # Check local cache first (unless NARF_CACHE_S3_NO_LOCAL_CACHE=1)
        if _s3_store_local_cache() and self._get_local_cache_path(path).exists():
            return True
        # Check S3
        s3_client = await self._get_async_s3_client()

        try:
            await s3_client.head_object(Bucket=self.bucket, Key=path)
            return True
        except Exception:
            return False

    async def adelete(self, path: str) -> bool:
        """Async delete cache file from S3 and local cache."""
        deleted = False
        # Delete from local cache (if we use local cache)
        if _s3_store_local_cache():
            local_path = self._get_local_cache_path(path)
            if local_path.exists():
                local_path.unlink()
                deleted = True
        # Delete from S3
        s3_client = await self._get_async_s3_client()

        try:
            await s3_client.delete_object(Bucket=self.bucket, Key=path)
            deleted = True
        except Exception:
            pass
        return deleted
