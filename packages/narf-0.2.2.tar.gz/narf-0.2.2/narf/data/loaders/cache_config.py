"""Centralized cache configuration for narf data loaders.

Cache root can be configured via NARF_CACHE_ROOT environment variable.
If not set, defaults to <repo_root>/cache.

For S3 backend: set NARF_CACHE_S3_NO_LOCAL_CACHE=1 to skip storing local copies.
"""

import os
from pathlib import Path
from typing import TYPE_CHECKING
import dotenv

if TYPE_CHECKING:
    from narf.data.loaders.cache_backend import CacheBackend, LocalFilesystemBackend, S3Backend

dotenv.load_dotenv()

# Module-level singleton to cache the backend instance
_backend_instance: "CacheBackend | None" = None


def get_cache_root() -> Path:
    """Get the cache root directory.
    
    Checks NARF_CACHE_ROOT environment variable first.
    If not set, defaults to <cwd>/cache.
    
    Returns:
        Path to the cache root directory (does not create it)
    """
    env_cache_root = os.environ.get("NARF_CACHE_ROOT")
    if env_cache_root:
        cache_root = Path(env_cache_root).expanduser().resolve()
    else:
        # Default: use current working directory / cache
        cache_root = Path.cwd() / "cache"
    
    return cache_root


def get_cache_backend() -> "CacheBackend":
    """Get the cache backend instance (singleton pattern).
    
    On first call, creates and caches the backend instance based on NARF_CACHE_BACKEND env var.
    On subsequent calls, returns the cached instance.
    
    Backend selection:
    - "s3" or "S3": S3 backend (requires NARF_CACHE_S3_BUCKET, NARF_AWS_ACCESS_KEY_ID,
                     NARF_AWS_SECRET_ACCESS_KEY, NARF_AWS_REGION).
                     Set NARF_CACHE_S3_NO_LOCAL_CACHE=1 to skip storing local copies.
    - Otherwise: Filesystem backend (default)
    
    Returns:
        CacheBackend instance
        
    Raises:
        ValueError: If S3 backend is selected but required env vars are missing
        ImportError: If S3 backend is selected but boto3 is not installed
    """
    global _backend_instance
    
    if _backend_instance is not None:
        return _backend_instance
    
    # Lazy import to avoid circular dependency
    from narf.data.loaders.cache_backend import LocalFilesystemBackend, S3Backend
    
    backend_type = os.environ.get("NARF_CACHE_BACKEND", "filesystem").lower()
    
    if backend_type == "s3":
        # Validate required environment variables
        bucket = os.environ.get("NARF_CACHE_S3_BUCKET")
        access_key_id = os.environ.get("NARF_AWS_ACCESS_KEY_ID")
        secret_access_key = os.environ.get("NARF_AWS_SECRET_ACCESS_KEY")
        region = os.environ.get("NARF_AWS_REGION")
        
        missing_vars = []
        if not bucket:
            missing_vars.append("NARF_CACHE_S3_BUCKET")
        if not access_key_id:
            missing_vars.append("NARF_AWS_ACCESS_KEY_ID")
        if not secret_access_key:
            missing_vars.append("NARF_AWS_SECRET_ACCESS_KEY")
        if not region:
            missing_vars.append("NARF_AWS_REGION")
        
        if missing_vars:
            raise ValueError(
                f"S3 backend requires the following environment variables: {', '.join(missing_vars)}"
            )
        
        _backend_instance = S3Backend(bucket, access_key_id, secret_access_key, region)
    else:
        # Default to filesystem backend
        _backend_instance = LocalFilesystemBackend()
    
    return _backend_instance
