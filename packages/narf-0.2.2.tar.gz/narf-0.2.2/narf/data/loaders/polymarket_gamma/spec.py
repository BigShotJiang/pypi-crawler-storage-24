from narf.data.loaders.base_spec import NodeSpec

from .loader import PolymarketGammaCryptoUpdownLoader, PolymarketGammaGenericLoader


# Polymarket Gamma namespace:
# - polymarket_gamma.markets.load(slug) for any slug (generic, per-slug cache)
# - polymarket_gamma.markets.crypto_updown.load(slug) for crypto up/down
# - polymarket_gamma.markets.crypto_updown.load_range(asset, minutes, start, end)

polymarket_gamma_spec = NodeSpec(
    children={
        "markets": NodeSpec(
            key="datatype",
            loader=PolymarketGammaGenericLoader,
            children={
                "crypto_updown": NodeSpec(key="datatype", loader=PolymarketGammaCryptoUpdownLoader),
            },
        ),
    }
)
