from narf.data.loaders.base_spec import build

from .spec import polymarket_gamma_spec


polymarket_gamma = build(polymarket_gamma_spec)


__all__ = ["polymarket_gamma"]
