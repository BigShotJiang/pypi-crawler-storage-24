"""Polymarket Gamma API loader.

Data source: Polymarket Gamma API
  GET https://gamma-api.polymarket.com/markets/slug/{slug}

Set NARF_POLYMARKET_GAMMA_CACHE_ONLY=1 to skip API fetches (read from cache only).

Returned DataFrame:
- index: slug (string)
- columns: id, conditionId, slug, startDate, endDate, upPrice, downPrice, volume,
           createdAt, updatedAt, closedTime, questionID, umaEndDate, orderPriceMinTickSize,
           orderMinSize, clobTokenUpId, clobTokenDownId, makerBaseFee, takerBaseFee,
           acceptingOrdersTimestamp, feesEnabled, makerRebatesFeeShareBps, feeType
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import date, datetime, timedelta, timezone
from typing import Optional

import aiohttp
import pandas as pd

from narf.data.loaders.polymarket_slug import (
    generate_crypto_updown_slug,
    parse_slug_to_fetch_params,
    parse_slug_to_market_datetime,
)
from narf.data.loaders.utils import DoNotCache, cached_function

BASE_URL = "https://gamma-api.polymarket.com"
ENDPOINT = "/markets/slug/{slug}"

logger = logging.getLogger(__name__)


def _is_cache_only() -> bool:
    """Return True when NARF_POLYMARKET_GAMMA_CACHE_ONLY=1 (no API fetches)."""
    return os.environ.get("NARF_POLYMARKET_GAMMA_CACHE_ONLY") == "1"


def _generate_slugs_for_range(asset: str, minutes: int, start: datetime, end: datetime) -> list[str]:
    """Generate all slugs for time range with given interval."""
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    
    slugs = []
    current = start
    interval_delta = timedelta(minutes=minutes)
    
    while current < end:
        slugs.append(generate_crypto_updown_slug(asset, minutes, current))
        current += interval_delta
    
    return slugs


def _iter_dates(start: datetime, end: datetime):
    """Yield date objects for each day in [start, end] (UTC)."""
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    current = start.date()
    end_date = end.date()
    while current <= end_date:
        yield current
        current += timedelta(days=1)


def _get_slugs_for_day(asset: str, minutes: int, d: date) -> list[str]:
    """Get all slugs for a specific day."""
    day_start = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    day_end = day_start + timedelta(days=1) - timedelta(seconds=1)
    return _generate_slugs_for_range(asset, minutes, day_start, day_end)


async def _fetch_market_data(slug: str) -> dict | None:
    """Fetch single market from Gamma API.

    Returns None if market doesn't exist (404).
    Raises exception if retries fail for non-404 errors.
    """
    url = f"{BASE_URL}{ENDPOINT.format(slug=slug)}"
    print(url)
    max_retries = 3
    backoff = 1.0
    
    for attempt in range(max_retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    if response.status == 404:
                        return None
                    response.raise_for_status()
                    return await response.json()
        except aiohttp.ClientResponseError as e:
            # 404 is handled above, so this is a different error
            if attempt < max_retries - 1:
                print(f"Error fetching {slug} (attempt {attempt + 1}/{max_retries}): {e.status} {e.message}. Retrying in {backoff}s...")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2.0, 10.0)
            else:
                raise RuntimeError(f"Failed to fetch {slug} after {max_retries} attempts: {e.status} {e.message}") from e
        except Exception as e:
            if attempt < max_retries - 1:
                print(f"Error fetching {slug} (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {backoff}s...")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2.0, 10.0)
            else:
                raise RuntimeError(f"Failed to fetch {slug} after {max_retries} attempts") from e


def _as_list(value):
    """Convert value to list if needed."""
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        return json.loads(value)
    return []


def _process_market_response(response: dict) -> dict | None:
    """Process API response, return None if umaResolutionStatus != 'resolved'."""
    if response is None:
        return None
    
    # Only include resolved markets
    if response.get("umaResolutionStatus") != "resolved":
        return None
    
    # Extract outcomePrices: ["upPrice", "downPrice"]
    outcome_prices = _as_list(response.get("outcomePrices", []))
    if len(outcome_prices) < 2:
        return None
    
    up_price = float(outcome_prices[0])
    down_price = float(outcome_prices[1])
    
    # Extract clobTokenIds: [upTokenId, downTokenId]
    clob_token_ids = _as_list(response.get("clobTokenIds", []))
    if len(clob_token_ids) < 2:
        return None
    
    clob_token_up_id = str(clob_token_ids[0])
    clob_token_down_id = str(clob_token_ids[1])
    
    # Extract and convert dates
    start_date_str = response.get("startDate")
    end_date_str = response.get("endDate")
    created_at_str = response.get("createdAt")
    updated_at_str = response.get("updatedAt")
    closed_time_str = response.get("closedTime")
    uma_end_date_str = response.get("umaEndDate")
    accepting_orders_timestamp_str = response.get("acceptingOrdersTimestamp")
    
    start_date = pd.to_datetime(start_date_str) if start_date_str else None
    end_date = pd.to_datetime(end_date_str) if end_date_str else None
    created_at = pd.to_datetime(created_at_str) if created_at_str else None
    updated_at = pd.to_datetime(updated_at_str) if updated_at_str else None
    closed_time = pd.to_datetime(closed_time_str) if closed_time_str else None
    uma_end_date = pd.to_datetime(uma_end_date_str) if uma_end_date_str else None
    accepting_orders_timestamp = pd.to_datetime(accepting_orders_timestamp_str) if accepting_orders_timestamp_str else None
    
    # Extract numeric fields
    volume = float(response.get("volume", 0))
    order_price_min_tick_size = float(response.get("orderPriceMinTickSize", 0))
    order_min_size = float(response.get("orderMinSize", 0))
    maker_base_fee = int(response.get("makerBaseFee", 0))
    taker_base_fee = int(response.get("takerBaseFee", 0))
    fees_enabled = bool(response.get("feesEnabled", False))
    maker_rebates_fee_share_bps = int(response.get("makerRebatesFeeShareBps", 0))
    
    return {
        "id": str(response.get("id", "")),
        "conditionId": str(response.get("conditionId", "")),
        "slug": str(response.get("slug", "")),
        "startDate": start_date,
        "endDate": end_date,
        "upPrice": up_price,
        "downPrice": down_price,
        "volume": volume,
        "createdAt": created_at,
        "updatedAt": updated_at,
        "closedTime": closed_time,
        "questionID": str(response.get("questionID", "")),
        "umaEndDate": uma_end_date,
        "orderPriceMinTickSize": order_price_min_tick_size,
        "orderMinSize": order_min_size,
        "clobTokenUpId": clob_token_up_id,
        "clobTokenDownId": clob_token_down_id,
        "makerBaseFee": maker_base_fee,
        "takerBaseFee": taker_base_fee,
        "acceptingOrdersTimestamp": accepting_orders_timestamp,
        "feesEnabled": fees_enabled,
        "makerRebatesFeeShareBps": maker_rebates_fee_share_bps,
        "feeType": str(response.get("feeType", "")),
    }


def parse_market_token_info(response: dict) -> dict:
    """Parse raw gamma market response for token-to-slug resolution.

    Returns dict with keys: slug (str), clobTokenIds (list[str]),
    upPrice (float), downPrice (float).

    Raises ValueError if market is not resolved or has missing data.
    """
    slug = response.get("slug", "<unknown>")

    uma_status = response.get("umaResolutionStatus")
    has_outcome_prices = len(_as_list(response.get("outcomePrices", []))) >= 2
    if uma_status != "resolved" and not (uma_status is None and has_outcome_prices):
        raise ValueError(f"Market {slug} is not resolved (status={uma_status!r})")

    outcome_prices = _as_list(response.get("outcomePrices", []))
    if len(outcome_prices) < 2:
        raise ValueError(f"Market {slug} has fewer than 2 outcome prices: {outcome_prices}")

    clob_token_ids = [str(x) for x in _as_list(response.get("clobTokenIds", []))]
    if len(clob_token_ids) < 2:
        raise ValueError(f"Market {slug} has fewer than 2 clob token IDs: {clob_token_ids}")

    return {
        "slug": str(slug),
        "clobTokenIds": clob_token_ids,
        "upPrice": float(outcome_prices[0]),
        "downPrice": float(outcome_prices[1]),
    }


def _cache_path_crypto_updown(asset: str, minutes: int, d: date) -> str:
    """Generate cache path for a day's crypto_updown data."""
    return f"polymarket_gamma/{asset.lower()}-updown-{minutes}m/{d.year}-{d.month:02d}-{d.day:02d}.parquet"


def _should_cache_empty_result(slug: str) -> bool:
    """Return True if empty result (404/no tokens) should be cached.

    Only cache when market timestamp is > 3 days ago (market would have resolved).
    Raises for malformed slugs or when timestamp is > 10 years in the past.
    """
    market_ts = parse_slug_to_market_datetime(slug)
    if market_ts is None:
        raise ValueError(f"Malformed slug: {slug}")
    now = datetime.now(timezone.utc)
    age = now - market_ts
    if age > timedelta(days=3650):
        raise ValueError(
            f"Slug {slug} has timestamp > 10 years in the past, is the timestamp parsing correct?"
        )
    return age > timedelta(days=3)


def _ensure_exists_column(df: pd.DataFrame) -> pd.DataFrame:
    """Add exists=True for all rows if column is missing (backward compat)."""
    if df.empty:
        return df
    if "exists" not in df.columns:
        df = df.copy()
        df["exists"] = True
    return df


def _filter_existing_and_drop_exists(df: pd.DataFrame) -> pd.DataFrame:
    """Filter to exists==True and drop the exists column before returning."""
    if df.empty:
        return df
    if "exists" not in df.columns:
        return df
    out = df[df["exists"] == True].drop(columns=["exists"])
    return out


async def _fetch_day_data(asset: str, minutes: int, d: date) -> pd.DataFrame:
    """Fetch all markets for a day (cached by day).
    
    For each day:
    - Generate all slugs for that day
    - Load cached day data (if exists)
    - Check which slugs are missing from cache
    - Fetch missing slugs from API
    - Combine cached + new data (including nonexistent rows with exists=False)
    - Save updated cache
    - Return day data (only existing markets, exists column dropped)
    """
    # Generate all slugs for this day
    expected_slugs = _get_slugs_for_day(asset, minutes, d)
    
    # Try to load cached data
    from narf.data.loaders.cache_config import get_cache_backend
    backend = get_cache_backend()
    cache_path = _cache_path_crypto_updown(asset, minutes, d)
    cached_df = await backend.atry_load(cache_path)
    
    # Backward compat: add exists=True if column missing
    if cached_df is not None and not cached_df.empty:
        cached_df = _ensure_exists_column(cached_df)
    
    # Determine which slugs are missing (we don't re-fetch slugs we've already checked)
    if cached_df is not None and not cached_df.empty:
        cached_slugs = set(cached_df.index.tolist())
        missing_slugs = [slug for slug in expected_slugs if slug not in cached_slugs]
    else:
        cached_df = pd.DataFrame()
        missing_slugs = expected_slugs
    
    # Fetch missing slugs (skip when NARF_POLYMARKET_GAMMA_CACHE_ONLY=1)
    if missing_slugs and not _is_cache_only():
        print(f"Fetching {len(missing_slugs)} missing slugs for {d}")
        sem = asyncio.Semaphore(10)  # Limit concurrent requests
        
        async def fetch_one(slug: str) -> tuple[str, dict | None]:
            async with sem:
                response = await _fetch_market_data(slug)
                return slug, _process_market_response(response)
        
        results = await asyncio.gather(*[fetch_one(slug) for slug in missing_slugs])
        
        new_rows: list[dict] = []
        nonexistent_rows: list[dict] = []
        
        for slug, row in results:
            if row is not None:
                row["exists"] = True
                new_rows.append(row)
            else:
                try:
                    if _should_cache_empty_result(slug):
                        nonexistent_rows.append({"slug": slug, "exists": False})
                except ValueError:
                    pass  # malformed or stale slug, don't cache
        
        rows_to_add: list[dict] = new_rows + nonexistent_rows
        if rows_to_add:
            new_df = pd.DataFrame(rows_to_add)
            new_df = new_df.set_index("slug")
            
            # Combine with cached data
            if not cached_df.empty:
                combined = pd.concat([cached_df, new_df])
                # Remove duplicates, keep last
                combined = combined[~combined.index.duplicated(keep="last")]
            else:
                combined = new_df
            
            # Save full cache (including exists column and nonexistent rows)
            await backend.asave(cache_path, combined.sort_index())
            return _filter_existing_and_drop_exists(combined.sort_index())
    
    # Return cached data if no missing slugs
    if cached_df.empty:
        return pd.DataFrame()
    return _filter_existing_and_drop_exists(cached_df)


@cached_function(lambda slug: f"polymarket_gamma/markets/{slug}.parquet")
async def _fetch_market_single(slug: str) -> pd.DataFrame:
    """Fetch single market from Gamma API (cached). Raises DoNotCache for unresolved."""
    if _is_cache_only():
        raise DoNotCache(pd.DataFrame())
    response = await _fetch_market_data(slug)
    row = _process_market_response(response)
    if row is None:
        raise DoNotCache(pd.DataFrame())
    return pd.DataFrame([row]).set_index("slug")


class PolymarketGammaGenericLoader:
    """Loader for Polymarket Gamma API market data (generic, any slug, per-slug cache)."""

    def __init__(self, path: tuple[str, ...]):
        self._path = path

    async def load(self, slug: str) -> pd.DataFrame:
        """Load market data for any slug (per-slug cache).

        Args:
            slug: Market slug identifier

        Returns:
            DataFrame with single row (index=slug) or empty DataFrame if not found/unresolved
        """
        return await _fetch_market_single(slug)


class PolymarketGammaCryptoUpdownLoader:
    """Loader for Polymarket Gamma API crypto up/down market data (per-day cache)."""

    CONCURRENCY = 4

    def __init__(self, path: tuple[str, ...]):
        self._path = path

    async def load_range(
        self,
        asset: str,
        minutes: int,
        start: datetime,
        end: datetime | None = None,
    ) -> pd.DataFrame:
        """Load Polymarket Gamma market data for a time range.
        
        Args:
            asset: Asset symbol (e.g., "btc")
            minutes: Interval in minutes (e.g., 15)
            start: Start datetime (UTC)
            end: End datetime (UTC). If None, defaults to now
            
        Returns:
            DataFrame with index=slug, columns as specified in docstring
        """
        if end is None:
            end = datetime.now(timezone.utc)
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)

        dates = list(_iter_dates(start, end))
        if not dates:
            return pd.DataFrame()

        sem = asyncio.Semaphore(self.CONCURRENCY)

        async def fetch_one(d: date) -> pd.DataFrame:
            async with sem:
                return await _fetch_day_data(asset, minutes, d)

        results = await asyncio.gather(*[fetch_one(d) for d in dates])
        combined = pd.concat(results, axis=0) if results else pd.DataFrame()
        if combined.empty:
            return combined
        
        combined = combined[~combined.index.duplicated(keep="last")]
        
        # Filter to requested time range: include market if it overlaps [start, end]
        # (1d markets have startDate days before resolution, so startDate filter would exclude them)
        if not combined.empty and "startDate" in combined.columns and "endDate" in combined.columns:
            combined = combined[
                (combined["startDate"] <= end) & (combined["endDate"] >= start)
            ]
        
        if not combined.empty and "endDate" in combined.columns:
            combined = combined.sort_values("endDate")
        return combined

    async def load(self, slug: str) -> pd.DataFrame:
        """Load Polymarket Gamma market data for a single slug.

        Fetches the whole day for that slug and returns a single row.

        Args:
            slug: Market slug (e.g., "btc-updown-15m-1770788700" or "bitcoin-up-or-down-march-18-2026-8am-et")

        Returns:
            DataFrame with single row (index=slug) or empty DataFrame if not found
        """
        params = parse_slug_to_fetch_params(slug)
        if params is None:
            print(f"Error parsing slug {slug}")
            return pd.DataFrame()
        asset, minutes, d = params
        day_df = await _fetch_day_data(asset, minutes, d)
        if not day_df.empty and slug in day_df.index:
            return day_df.loc[[slug]]
        return pd.DataFrame()
