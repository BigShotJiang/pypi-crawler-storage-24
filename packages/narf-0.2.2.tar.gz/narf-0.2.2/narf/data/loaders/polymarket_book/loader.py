"""Polymarket CLOB order book streaming loader.

Data source: Polymarket CLOB WebSocket
  wss://ws-subscriptions-clob.polymarket.com/ws/market

Collects order book events (book snapshots, price_change) for crypto up/down markets.
Saves to cache when market resolves. load() reads from cache by slug.

Returned DataFrame (main file {slug}.parquet):
- index: timestamp (UTC datetime)
- columns: event_type, token, side, price, size (prices rounded to tick size; tick_size_change stores new tick in price)

Ticker file ({slug}-ticker.parquet): best_bid, best_ask, best_bid_size, best_ask_size; rows only when ticker changed.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import random
import time
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone

import aiohttp
import pandas as pd

from narf.data.loaders.cache_config import get_cache_backend
from narf.data.loaders.polymarket_gamma.loader import (
    _as_list,
    _fetch_market_data,
)
from narf.data.loaders.polymarket_slug import generate_crypto_updown_slug
from narf.data.loaders.utils import DATETIME_INDEX_DTYPE_MS_UTC

logger = logging.getLogger(__name__)

WS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
CACHE_PATH_TEMPLATE = "polymarket_book/crypto_updown/book/{slug}.parquet"
CACHE_PATH_TICKER_TEMPLATE = "polymarket_book/crypto_updown/ticker/{slug}.parquet"
PING_INTERVAL_S = 10
REFRESH_INTERVAL_S = 60
MAX_RECONNECT_ATTEMPTS = 10
INITIAL_BACKOFF_S = 1.0
MAX_BACKOFF_S = 60.0
DEDUPE_WINDOW_S = 2.0


def _get_active_slug(asset: str, duration: int) -> str:
    """Compute slug for the currently active market (aligned to duration boundary)."""
    now = datetime.now(timezone.utc)
    # Align to last duration-minute boundary
    total_minutes = int(now.timestamp() // 60)
    aligned_minutes = (total_minutes // duration) * duration
    market_start = datetime.fromtimestamp(aligned_minutes * 60, tz=timezone.utc)
    return generate_crypto_updown_slug(asset, duration, market_start)


def _get_slugs_to_track(
    asset: str, duration: int, now: datetime, *, skip_started: bool = True
) -> list[str]:
    """Return slugs to track: (1) active/overlapping, (2) starting in 5 min.

    Polymarket creates recurring crypto markets ~24h in advance.
    When skip_started=True (default), excludes markets that have already started.
    """
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    total_minutes = int(now.timestamp() // 60)
    aligned_minutes = (total_minutes // duration) * duration

    slugs = []
    # Current + previous (may still be resolving)
    for offset_min in [0, duration]:
        boundary_ts = (aligned_minutes - offset_min) * 60
        boundary = datetime.fromtimestamp(boundary_ts, tz=timezone.utc)
        if skip_started and boundary < now:
            continue
        slugs.append(generate_crypto_updown_slug(asset, duration, boundary))
    # Next (starts in ~5 min) - for early dispatch
    next_boundary = datetime.fromtimestamp((aligned_minutes + duration) * 60, tz=timezone.utc)
    if (next_boundary - now).total_seconds() <= 5 * 60 + 60:
        if not skip_started or next_boundary >= now:
            slugs.append(generate_crypto_updown_slug(asset, duration, next_boundary))
    return list(dict.fromkeys(slugs))


def _extract_token_ids(response: dict) -> tuple[str, str]:
    """Extract clobTokenUpId and clobTokenDownId from Gamma API response."""
    clob_token_ids = _as_list(response.get("clobTokenIds", []))
    if len(clob_token_ids) < 2:
        raise ValueError(f"Market response missing clobTokenIds: {response.get('slug', 'unknown')}")
    return str(clob_token_ids[0]), str(clob_token_ids[1])


def _extract_tick_size(response: dict) -> float:
    """Extract orderPriceMinTickSize from Gamma API. Default 0.01."""
    v = response.get("orderPriceMinTickSize")
    if v is None:
        return 0.01
    f = float(v)
    return f if f > 0 else 0.01


def _flip_price(p: float) -> float:
    """Complementary token: UP price p -> DOWN price (1-p).

    Docs: https://docs.polymarket.com/concepts/prices-orderbook
    - "Since $0.60 + $0.40 = $1.00, the orders match"
    - "Someone places a limit order to buy No at the complementary price (e.g., $0.40)"
    - "When matched, $1.00 is converted into 1 Yes token and 1 No token"

    Docs: https://docs.polymarket.com/concepts/positions-tokens
    - "Every Yes/No pair in existence is backed by exactly $1 of USDC.e collateral"
    - Split: $1 -> 1 Yes + 1 No; Merge: 1 Yes + 1 No -> $1
    """
    return 1.0 - p


def _round_to_tick(price: float, tick_size: float) -> float:
    """Round price to market tick size. Tick size changes when price > 0.96 or < 0.04."""
    if tick_size <= 0:
        return price
    return round(price / tick_size) * tick_size


def _book_to_rows(
    msg: dict,
    token_up_id: str,
    token_down_id: str,
    tick_size: float,
) -> tuple[list[dict], float, float, float, float]:
    """Convert book event to flattened rows. Stores only UP representation (DOWN is derived via flip).

    Returns (rows, best_bid, best_ask, best_bid_size, best_ask_size) for ticker tracking.
    """
    asset_id = str(msg["asset_id"])
    if asset_id == token_up_id:
        flip = False
    elif asset_id == token_down_id:
        flip = True
    else:
        return [], 0.0, 0.0, 0.0, 0.0

    bids = msg["bids"]
    asks = msg["asks"]
    ts_ms = int(msg["timestamp"])

    if flip:
        best_bid = _flip_price(min((float(a["price"]) for a in asks), default=1.0) if asks else 1.0)
        best_ask = _flip_price(max((float(b["price"]) for b in bids), default=0.0) if bids else 0.0)
        best_bid_size = float(asks[0]["size"]) if asks else 0.0
        best_ask_size = float(bids[0]["size"]) if bids else 0.0
    else:
        best_bid = max((float(b["price"]) for b in bids), default=0.0) if bids else 0.0
        best_ask = min((float(a["price"]) for a in asks), default=0.0) if asks else 0.0
        best_bid_size = float(bids[0]["size"]) if bids else 0.0
        best_ask_size = float(asks[0]["size"]) if asks else 0.0

    rows = []
    for b in bids:
        price = _flip_price(float(b["price"])) if flip else float(b["price"])
        side = "ASK" if flip else "BID"
        rows.append({
            "event_type": "book",
            "token": "UP",
            "side": side,
            "price": _round_to_tick(price, tick_size),
            "size": float(b["size"]),
            "timestamp": ts_ms,
        })
    for a in asks:
        price = _flip_price(float(a["price"])) if flip else float(a["price"])
        side = "BID" if flip else "ASK"
        rows.append({
            "event_type": "book",
            "token": "UP",
            "side": side,
            "price": _round_to_tick(price, tick_size),
            "size": float(a["size"]),
            "timestamp": ts_ms,
        })
    return rows, best_bid, best_ask, best_bid_size, best_ask_size


def _price_change_to_rows(
    msg: dict,
    token_up_id: str,
    token_down_id: str,
    tick_size: float,
) -> tuple[list[dict], float, float, float | None, float | None]:
    """Convert price_change event to flattened rows. Stores only UP representation.

    Returns (rows, best_bid, best_ask, best_bid_size, best_ask_size). Sizes from pc at best level if found.
    """
    price_changes = msg["price_changes"]
    ts_ms = int(msg["timestamp"])
    rows = []
    best_bid_up = 0.0
    best_ask_up = 0.0
    best_bid_size: float | None = None
    best_ask_size: float | None = None
    for pc in price_changes:
        asset_id = str(pc["asset_id"])
        if asset_id == token_up_id:
            flip = False
        elif asset_id == token_down_id:
            flip = True
        else:
            continue
        price = float(pc["price"])
        side = "BID" if str(pc["side"]) == "BUY" else "ASK"
        best_bid = float(pc["best_bid"])
        best_ask = float(pc["best_ask"])
        if flip:
            price = _flip_price(price)
            side = "ASK" if side == "BID" else "BID"
            best_bid, best_ask = _flip_price(best_ask), _flip_price(best_bid)
        best_bid_up = best_bid
        best_ask_up = best_ask
        if abs(price - best_bid) < 1e-9:
            best_bid_size = float(pc["size"])
        if abs(price - best_ask) < 1e-9:
            best_ask_size = float(pc["size"])
        rows.append({
            "event_type": "price_change",
            "token": "UP",
            "side": side,
            "price": _round_to_tick(price, tick_size),
            "size": float(pc["size"]),
            "timestamp": ts_ms,
        })
    return rows, best_bid_up, best_ask_up, best_bid_size, best_ask_size


def _tick_size_change_to_row(new_tick_size: float, ts_ms: int) -> dict:
    """Create a tick_size_change event row. Stores new tick size in price field."""
    return {
        "event_type": "tick_size_change",
        "token": "UP",
        "side": "",
        "price": new_tick_size,
        "size": 0.0,
        "timestamp": ts_ms,
    }


def _maybe_append_ticker(
    ticker_collected: list[dict],
    last_ticker: dict | None,
    best_bid: float,
    best_ask: float,
    best_bid_size: float | None,
    best_ask_size: float | None,
    ts_ms: int,
) -> dict:
    """Append ticker row only if best bid/ask changed. Returns new last_ticker."""
    new_state = {
        "best_bid": best_bid,
        "best_ask": best_ask,
        "best_bid_size": best_bid_size,
        "best_ask_size": best_ask_size,
    }
    if last_ticker is None or (
        last_ticker["best_bid"] != best_bid
        or last_ticker["best_ask"] != best_ask
        or last_ticker.get("best_bid_size") != best_bid_size
        or last_ticker.get("best_ask_size") != best_ask_size
    ):
        ticker_collected.append({
            "event_type": "ticker",
            "best_bid": best_bid,
            "best_ask": best_ask,
            "best_bid_size": best_bid_size if best_bid_size is not None else 0.0,
            "best_ask_size": best_ask_size if best_ask_size is not None else 0.0,
            "price": float("nan"),
            "timestamp": ts_ms,
        })
    return new_state


def _reconnect_delay_s(close_code: int | None, attempt: int) -> float:
    """Return delay in seconds before reconnect based on close code or attempt."""
    if close_code == aiohttp.WSCloseCode.SERVICE_RESTART:
        return random.uniform(5.0, 30.0)
    if close_code == aiohttp.WSCloseCode.TRY_AGAIN_LATER:
        return random.uniform(5.0, 15.0)
    backoff = min(INITIAL_BACKOFF_S * (2**attempt), MAX_BACKOFF_S)
    return backoff + random.uniform(0, backoff * 0.1)


def _msg_hash(msg: dict) -> str:
    """Canonical hash for deduplication."""
    return hashlib.sha256(json.dumps(msg, sort_keys=True).encode()).hexdigest()


async def _drain_subscribe_queue(
    ws: aiohttp.ClientWebSocketResponse,
    subscribe_queue: asyncio.Queue[list[str]],
) -> None:
    """Drain subscribe queue and send subscribe messages for each batch."""
    while not subscribe_queue.empty():
        try:
            new_asset_ids = subscribe_queue.get_nowait()
        except asyncio.QueueEmpty:
            break
        if new_asset_ids:
            await ws.send_str(json.dumps({
                "assets_ids": list(dict.fromkeys(new_asset_ids)),
                "operation": "subscribe",
                "custom_feature_enabled": True,
            }))


async def _wait_receive_or_ping(
    ws: aiohttp.ClientWebSocketResponse,
    ping_interval_s: float = PING_INTERVAL_S,
) -> tuple[str, aiohttp.WSMessage | None]:
    """Wait for receive or ping interval. Returns ('message', msg) or ('ping', None) or ('error', None)."""
    receive_task = asyncio.create_task(ws.receive())
    timer_task = asyncio.create_task(asyncio.sleep(ping_interval_s))
    done, _ = await asyncio.wait(
        [receive_task, timer_task],
        return_when=asyncio.FIRST_COMPLETED,
    )
    if receive_task in done:
        timer_task.cancel()
        try:
            await timer_task
        except asyncio.CancelledError:
            pass
        try:
            msg = receive_task.result()
            return ("message", msg)
        except (
            ConnectionResetError,
            ConnectionError,
            aiohttp.ClientError,
            aiohttp.ClientConnectorError,
        ):
            return ("error", None)
    timer_task.cancel()
    try:
        await timer_task
    except asyncio.CancelledError:
        pass
    receive_task.cancel()
    try:
        await receive_task
    except asyncio.CancelledError:
        pass
    return ("ping", None)


class PolymarketBookCryptoUpdownLoader:
    """Streaming loader for Polymarket CLOB order book (crypto up/down markets)."""

    def __init__(self, path: tuple[str, ...]):
        self._path = path

    async def listen(
        self,
        asset: str | None = None,
        duration: int | None = None,
        assets_durations: list[tuple[str, int]] | None = None,
        num_connections: int = 2,
        shutdown: asyncio.Event | None = None,
    ) -> None:
        """Listen to active crypto markets indefinitely. Collect order book events, save on market_resolved.

        Uses persistent WebSocket(s) with dynamic subscribe/unsubscribe.
        Dispatches markets 5 min before start; tracks overlapping markets (previous may still be resolving).

        Pass either (asset, duration) or assets_durations. num_connections>=2 runs parallel
        connections for redundancy (deduplication applied).
        """
        if assets_durations is not None:
            pairs = assets_durations
        elif asset is not None and duration is not None:
            pairs = [(asset, duration)]
        else:
            raise ValueError("Pass (asset, duration) or assets_durations")
        if num_connections < 2:
            raise ValueError("num_connections must be >= 2")

        backend = get_cache_backend()

        # Persistent state across reconnects
        slug_to_tokens: dict[str, tuple[str, str]] = {}
        asset_id_to_slug: dict[str, str] = {}
        tokens_to_slug: dict[frozenset[str], str] = {}
        tick_size_per_slug: dict[str, float] = {}
        collected: dict[str, list[dict]] = {}
        ticker_collected: dict[str, list[dict]] = {}
        last_ticker: dict[str, dict] = {}
        subscribed_slugs: set[str] = set()

        await self._listen_multi(
                pairs=pairs,
                backend=backend,
                num_connections=num_connections,
                slug_to_tokens=slug_to_tokens,
                asset_id_to_slug=asset_id_to_slug,
                tokens_to_slug=tokens_to_slug,
                tick_size_per_slug=tick_size_per_slug,
                collected=collected,
                ticker_collected=ticker_collected,
                last_ticker=last_ticker,
                subscribed_slugs=subscribed_slugs,
                shutdown=shutdown,
            )

    async def _refresh_slugs(
        self,
        pairs: list[tuple[str, int]],
        now: datetime,
        slug_to_tokens: dict[str, tuple[str, str]],
        asset_id_to_slug: dict[str, str],
        tokens_to_slug: dict[frozenset[str], str],
        tick_size_per_slug: dict[str, float],
        collected: dict[str, list[dict]],
        ticker_collected: dict[str, list[dict]],
        subscribed_slugs: set[str],
        shutdown: asyncio.Event | None,
    ) -> list[str]:
        """Refresh slugs to track, add new ones. Returns new asset IDs to subscribe."""
        if shutdown is not None and shutdown.is_set():
            return []
        new_asset_ids: list[str] = []
        for a, d in pairs:
            for slug in _get_slugs_to_track(a, d, now):
                if slug in subscribed_slugs:
                    continue
                response = await _fetch_market_data(slug)
                if response is None:
                    continue
                token_up_id, token_down_id = _extract_token_ids(response)
                slug_to_tokens[slug] = (token_up_id, token_down_id)
                asset_id_to_slug[token_up_id] = slug
                asset_id_to_slug[token_down_id] = slug
                tokens_to_slug[frozenset([token_up_id, token_down_id])] = slug
                tick_size_per_slug[slug] = _extract_tick_size(response)
                collected.setdefault(slug, [])
                ticker_collected.setdefault(slug, [])
                subscribed_slugs.add(slug)
                new_asset_ids.append(token_up_id)
        return new_asset_ids

    async def _process_messages(
        self,
        data: dict | list,
        slug_to_tokens: dict[str, tuple[str, str]],
        asset_id_to_slug: dict[str, str],
        tokens_to_slug: dict[frozenset[str], str],
        tick_size_per_slug: dict[str, float],
        collected: dict[str, list[dict]],
        ticker_collected: dict[str, list[dict]],
        last_ticker: dict[str, dict],
        subscribed_slugs: set[str],
        backend: object,
        on_unsubscribe: Callable[[list[str]], Awaitable[None]],
    ) -> None:
        """Process WebSocket messages and update collected state."""
        messages = data if isinstance(data, list) else [data]
        for msg_data in messages:
            event_type = msg_data["event_type"]

            if event_type == "book":
                slug = asset_id_to_slug.get(str(msg_data["asset_id"]))
                if slug is not None and slug in subscribed_slugs:
                    token_up_id, token_down_id = slug_to_tokens[slug]
                    tick_size = tick_size_per_slug.get(slug, 0.01)
                    rows, bb, ba, bbs, bas = _book_to_rows(
                        msg_data, token_up_id, token_down_id, tick_size
                    )
                    collected[slug].extend(rows)
                    last_ticker[slug] = _maybe_append_ticker(
                        ticker_collected[slug],
                        last_ticker.get(slug),
                        bb, ba, bbs, bas,
                        int(msg_data["timestamp"]),
                    )
            elif event_type == "price_change":
                for slug, (token_up_id, token_down_id) in slug_to_tokens.items():
                    if slug not in subscribed_slugs:
                        continue
                    tick_size = tick_size_per_slug.get(slug, 0.01)
                    rows, bb, ba, bbs, bas = _price_change_to_rows(
                        msg_data, token_up_id, token_down_id, tick_size
                    )
                    if rows:
                        collected[slug].extend(rows)
                        last_ticker[slug] = _maybe_append_ticker(
                            ticker_collected[slug],
                            last_ticker.get(slug),
                            bb, ba, bbs, bas,
                            int(msg_data["timestamp"]),
                        )
            elif event_type == "tick_size_change":
                asset_id = str(msg_data.get("asset_id", ""))
                slug = asset_id_to_slug.get(asset_id)
                if slug is not None and slug in subscribed_slugs:
                    new_ts = float(msg_data.get("new_tick_size", 0.01))
                    tick_size_per_slug[slug] = new_ts if new_ts > 0 else 0.01
                    ts_ms = int(msg_data.get("timestamp", 0))
                    row = _tick_size_change_to_row(new_ts, ts_ms)
                    collected[slug].append(row)
                    ticker_collected[slug].append({
                        "event_type": "tick_size_change",
                        "best_bid": float("nan"),
                        "best_ask": float("nan"),
                        "best_bid_size": 0.0,
                        "best_ask_size": 0.0,
                        "price": new_ts,
                        "timestamp": ts_ms,
                    })
            elif event_type == "best_bid_ask":
                asset_id = str(msg_data.get("asset_id", ""))
                slug = asset_id_to_slug.get(asset_id)
                if slug is not None and slug in subscribed_slugs:
                    bb = float(msg_data.get("best_bid", 0))
                    ba = float(msg_data.get("best_ask", 0))
                    ts_ms = int(msg_data.get("timestamp", 0))
                    prev = last_ticker.get(slug)
                    bbs = prev.get("best_bid_size") if prev is not None else None
                    bas = prev.get("best_ask_size") if prev is not None else None
                    last_ticker[slug] = _maybe_append_ticker(
                        ticker_collected[slug],
                        prev,
                        bb, ba, bbs, bas,
                        ts_ms,
                    )
            elif event_type == "market_resolved":
                assets_ids = msg_data["assets_ids"]
                slug = tokens_to_slug.get(frozenset(str(a) for a in assets_ids))
                if slug is not None and slug in subscribed_slugs:
                    if collected.get(slug):
                        df = pd.DataFrame(collected[slug])
                        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
                        df = df.set_index("timestamp")
                        df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)
                        cache_path = CACHE_PATH_TEMPLATE.format(slug=slug)
                        await backend.asave(cache_path, df)
                        logger.info("Saved %d order book rows for %s", len(collected[slug]), slug)
                    if ticker_collected.get(slug):
                        df_ticker = pd.DataFrame(ticker_collected[slug])
                        df_ticker["timestamp"] = pd.to_datetime(
                            df_ticker["timestamp"], unit="ms", utc=True
                        )
                        df_ticker = df_ticker.set_index("timestamp")
                        df_ticker.index = df_ticker.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)
                        ticker_path = CACHE_PATH_TICKER_TEMPLATE.format(slug=slug)
                        await backend.asave(ticker_path, df_ticker)
                        logger.info("Saved %d ticker rows for %s", len(ticker_collected[slug]), slug)
                    token_up_id, token_down_id = slug_to_tokens[slug]
                    del collected[slug]
                    del ticker_collected[slug]
                    last_ticker.pop(slug, None)
                    tick_size_per_slug.pop(slug, None)
                    subscribed_slugs.discard(slug)
                    del slug_to_tokens[slug]
                    del asset_id_to_slug[token_up_id]
                    del asset_id_to_slug[token_down_id]
                    del tokens_to_slug[frozenset([token_up_id, token_down_id])]
                    await on_unsubscribe([token_up_id])

    async def _listen_multi(
        self,
        pairs: list[tuple[str, int]],
        backend: object,
        num_connections: int,
        slug_to_tokens: dict[str, tuple[str, str]],
        asset_id_to_slug: dict[str, str],
        tokens_to_slug: dict[frozenset[str], str],
        tick_size_per_slug: dict[str, float],
        collected: dict[str, list[dict]],
        ticker_collected: dict[str, list[dict]],
        last_ticker: dict[str, dict],
        subscribed_slugs: set[str],
        shutdown: asyncio.Event | None,
    ) -> None:
        """Multi-connection listen with shared queue and deduplication."""
        message_queue: asyncio.Queue[dict | list] = asyncio.Queue()
        command_queues: list[asyncio.Queue[dict]] = []
        subscribe_queues: list[asyncio.Queue[list[str]]] = [
            asyncio.Queue() for _ in range(num_connections)
        ]
        seen_hashes: dict[str, float] = {}
        evict_before = time.monotonic()

        async def refresh_loop() -> None:
            """Run refresh once per interval and broadcast new slugs to all producers."""
            while True:
                await asyncio.sleep(REFRESH_INTERVAL_S)
                if shutdown is not None and shutdown.is_set():
                    return
                now = datetime.now(timezone.utc)
                ids = await self._refresh_slugs(
                    pairs, now, slug_to_tokens, asset_id_to_slug,
                    tokens_to_slug, tick_size_per_slug, collected,
                    ticker_collected, subscribed_slugs, shutdown,
                )
                if ids:
                    new_slugs = [
                        asset_id_to_slug[aid]
                        for aid in ids
                        if aid in asset_id_to_slug
                    ]
                    for q in subscribe_queues:
                        q.put_nowait(ids)
                    logger.info(
                        "Refreshed: subscribed to %d new slugs: %s",
                        len(new_slugs),
                        sorted(new_slugs),
                    )

        async def producer(
            conn_id: int,
            cmd_queue: asyncio.Queue[dict],
            subscribe_queue: asyncio.Queue[list[str]],
        ) -> None:
            while True:
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.ws_connect(WS_URL) as ws:
                            logger.info("WebSocket connection %d connected", conn_id)
                            if not (shutdown is not None and shutdown.is_set()):
                                now = datetime.now(timezone.utc)
                                await self._refresh_slugs(
                                    pairs, now, slug_to_tokens, asset_id_to_slug,
                                    tokens_to_slug, tick_size_per_slug, collected,
                                    ticker_collected, subscribed_slugs, shutdown,
                                )
                            if slug_to_tokens:
                                all_asset_ids = list(dict.fromkeys(t[0] for t in slug_to_tokens.values()))
                                await ws.send_str(json.dumps({
                                    "assets_ids": all_asset_ids,
                                    "type": "market",
                                    "custom_feature_enabled": True,
                                }))
                                logger.info(
                                    "Subscribed to %d slugs: %s",
                                    len(subscribed_slugs),
                                    sorted(subscribed_slugs),
                                )

                            while True:
                                try:
                                    cmd = cmd_queue.get_nowait()
                                except asyncio.QueueEmpty:
                                    cmd = None
                                if cmd is not None:
                                    await ws.send_str(json.dumps(cmd))

                                if shutdown is not None and shutdown.is_set():
                                    break

                                await _drain_subscribe_queue(ws, subscribe_queue)

                                result_type, msg = await _wait_receive_or_ping(ws)
                                if result_type == "error":
                                    logger.warning("WebSocket connection %d error", conn_id)
                                    break
                                if result_type == "ping":
                                    await ws.send_str("PING")
                                    continue

                                if msg.type == aiohttp.WSMsgType.TEXT:
                                    try:
                                        data = json.loads(msg.data)
                                    except json.JSONDecodeError:
                                        continue
                                    message_queue.put_nowait(data)
                                    continue
                                if msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.ERROR):
                                    logger.warning(
                                        "WebSocket connection %d closed: %s",
                                        conn_id,
                                        msg.data if msg.type == aiohttp.WSMsgType.CLOSE else msg.type,
                                    )
                                    break

                except (aiohttp.ClientError, asyncio.TimeoutError, ConnectionError) as e:
                    logger.warning("Connection %d failed: %s. Reconnecting...", conn_id, e)

                if shutdown is not None and shutdown.is_set():
                    return
                await asyncio.sleep(_reconnect_delay_s(None, 0))

        async def consumer() -> None:
            nonlocal evict_before
            while True:
                try:
                    data = await asyncio.wait_for(
                        message_queue.get(),
                        timeout=min(PING_INTERVAL_S, DEDUPE_WINDOW_S),
                    )
                except asyncio.TimeoutError:
                    now = time.monotonic()
                    if shutdown is not None and shutdown.is_set() and not subscribed_slugs:
                        break
                    if now - evict_before >= DEDUPE_WINDOW_S:
                        evict_before = now
                        cutoff = now - DEDUPE_WINDOW_S
                        for h, t in list(seen_hashes.items()):
                            if t < cutoff:
                                del seen_hashes[h]
                    continue

                messages = data if isinstance(data, list) else [data]
                for msg_data in messages:
                    h = _msg_hash(msg_data)
                    if h in seen_hashes:
                        continue
                    seen_hashes[h] = time.monotonic()

                    async def _on_unsub_multi(ids: list[str]) -> None:
                        cmd = {"assets_ids": ids, "operation": "unsubscribe"}
                        for q in command_queues:
                            q.put_nowait(cmd)

                    await self._process_messages(
                        msg_data, slug_to_tokens, asset_id_to_slug, tokens_to_slug,
                        tick_size_per_slug, collected, ticker_collected, last_ticker,
                        subscribed_slugs, backend, _on_unsub_multi,
                    )
                    if shutdown is not None and shutdown.is_set() and not subscribed_slugs:
                        break
                if shutdown is not None and shutdown.is_set() and not subscribed_slugs:
                    break

        asyncio.create_task(refresh_loop())
        for i in range(num_connections):
            cmd_q: asyncio.Queue[dict] = asyncio.Queue()
            command_queues.append(cmd_q)
            asyncio.create_task(producer(i, cmd_q, subscribe_queues[i]))

        await consumer()

    async def load(self, slug: str) -> pd.DataFrame | None:
        """Load cached order book data for slug. Returns None if not in cache."""
        backend = get_cache_backend()
        cache_path = CACHE_PATH_TEMPLATE.format(slug=slug)
        return await backend.atry_load(cache_path)

    async def load_ticker(self, slug: str) -> pd.DataFrame | None:
        """Load cached ticker data (best_bid, best_ask, best_bid_size, best_ask_size) for slug. Returns None if not in cache."""
        backend = get_cache_backend()
        ticker_path = CACHE_PATH_TICKER_TEMPLATE.format(slug=slug)
        return await backend.atry_load(ticker_path)
