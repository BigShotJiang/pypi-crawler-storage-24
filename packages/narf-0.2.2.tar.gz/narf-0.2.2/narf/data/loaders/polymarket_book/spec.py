from narf.data.loaders.base_spec import NodeSpec

from .loader import PolymarketBookCryptoUpdownLoader


# polymarket_book namespace:
# - polymarket_book.crypto_updown.listen(asset, duration)
# - polymarket_book.crypto_updown.load(slug)
# - polymarket_book.crypto_updown.load_ticker(slug)

polymarket_book_spec = NodeSpec(
    children={
        "crypto_updown": NodeSpec(key="datatype", loader=PolymarketBookCryptoUpdownLoader),
    },
)
