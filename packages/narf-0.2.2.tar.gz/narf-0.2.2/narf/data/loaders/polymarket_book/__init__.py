from narf.data.loaders.base_spec import build

from .spec import polymarket_book_spec


polymarket_book = build(polymarket_book_spec)


__all__ = ["polymarket_book"]
