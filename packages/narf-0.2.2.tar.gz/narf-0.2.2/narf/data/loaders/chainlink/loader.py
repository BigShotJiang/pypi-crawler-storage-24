"""Chainlink Data Streams loader.

Data source: Chainlink Data Streams REST API
  GET https://api.dataengine.chain.link/api/v1/reports/page

Returned DataFrame:
- index: observationsTimestamp (UTC datetime)
- columns: price (float), bid (float), ask (float)
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import os
import time
from datetime import date, datetime, timedelta, timezone
from enum import Enum

import aiohttp
import pandas as pd
from py_chainlink_streams import ReportResponse

from narf.data.loaders.cache_config import get_cache_backend
from narf.data.loaders.utils import cached_function, DATETIME_INDEX_DTYPE_MS_UTC


BASE_URL = "https://api.dataengine.chain.link"
LIMIT = 100
MAX_PAGES = 1_000_000


class ChainLinkAsset(Enum):
    """Chainlink asset identifiers with their feed IDs."""

    BTCUSD = "0x00039d9e45394f473ab1f050a1b963e6b05351e52d71e507509ada0c95ed75b8"
    ETHUSD = "0x000362205e10b3a147d02792eccee483dca6c7b44ecce7012cb8c6e0b68b3ae9"
    SOLUSD = "0x0003b778d3f6b2ac4991302b89cb313f99a42467d6c9c5f96f57c29c0d2bc24f"
    XRPUSD = "0x0003c16c6aed42294f5cb4741f6e59ba2d728f0eae2eb9e6d3f555808c59fc45"

    @property
    def feed_id(self) -> str:
        return self.value


def _sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def _sign_request(method: str, full_path: str, body: str, api_key: str, api_secret: str) -> tuple[int, str]:
    timestamp_ms = int(time.time() * 1000)
    body_hash = _sha256_hex(body)
    string_to_sign = f"{method} {full_path} {body_hash} {api_key} {timestamp_ms}"
    signature = hmac.new(
        api_secret.encode(),
        string_to_sign.encode(),
        hashlib.sha256,
    ).hexdigest()
    return timestamp_ms, signature


async def _fetch_page(
    session: aiohttp.ClientSession,
    feed_id: str,
    start_timestamp: int,
    api_key: str,
    api_secret: str,
) -> dict:
    full_path = f"/api/v1/reports/page?feedID={feed_id}&startTimestamp={start_timestamp}&limit={LIMIT}"
    print(f"Fetching Chainlink page from {BASE_URL}{full_path}")
    timestamp_ms, signature = _sign_request("GET", full_path, "", api_key, api_secret)
    headers = {
        "Authorization": api_key,
        "X-Authorization-Timestamp": str(timestamp_ms),
        "X-Authorization-Signature-SHA256": signature,
        "accept": "application/json",
    }
    async with session.get(f"{BASE_URL}{full_path}", headers=headers, timeout=aiohttp.ClientTimeout(total=30)) as response:
        response.raise_for_status()
        return await response.json()


def _rows_to_dataframe(rows: list[dict], feed_id: str) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame()
    out = []
    for row in rows:
        report = ReportResponse(
            feed_id=feed_id,
            full_report=row["fullReport"],
            valid_from_timestamp=row["validFromTimestamp"],
            observations_timestamp=row["observationsTimestamp"],
        )
        prices = report.get_decoded_prices()
        ts = datetime.fromtimestamp(row["observationsTimestamp"], tz=timezone.utc)
        out.append({
            "observationsTimestamp": ts,
            "price": prices["benchmarkPrice"],
            "bid": prices["bid"],
            "ask": prices["ask"],
        })
    df = pd.DataFrame(out)
    df = df.set_index("observationsTimestamp").sort_index()
    df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)
    return df[~df.index.duplicated(keep="last")]


def _day_cache_path(feed_id: str, d: date) -> str:
    return f"chainlink/{feed_id}/{d.year}-{d.month:02d}-{d.day:02d}.parquet"


async def _fetch_range(feed_id: str, start_ts: int, end_ts: int) -> pd.DataFrame:
    """Fetch reports from Chainlink API for a timestamp range (uncached)."""
    api_key = os.environ.get("CHAIN_LINK_STREAMS_API_KEY")
    if not api_key:
        raise ValueError("CHAIN_LINK_STREAMS_API_KEY environment variable is required")
    api_secret = os.environ.get("CHAIN_LINK_STREAMS_API_SECRET")
    if not api_secret:
        raise ValueError("CHAIN_LINK_STREAMS_API_SECRET environment variable is required")

    rows: list[dict] = []
    cursor = start_ts
    pages = 0

    async with aiohttp.ClientSession() as session:
        while cursor <= end_ts:
            pages += 1
            if pages > MAX_PAGES:
                raise RuntimeError("max_pages exceeded")
            resp = await _fetch_page(session, feed_id, cursor, api_key, api_secret)
            reports = resp.get("reports", [])
            if not reports:
                break
            rows.extend(reports)
            last_obs_ts = int(reports[-1]["observationsTimestamp"])
            if last_obs_ts <= cursor:
                break
            cursor = last_obs_ts

    return _rows_to_dataframe(rows, feed_id)


@cached_function(_day_cache_path)
async def _fetch_day_data(feed_id: str, d: date) -> pd.DataFrame:
    """Fetch one day of reports from Chainlink API."""
    print(f"Fetching Chainlink data for feed_id={feed_id}, date={d}")
    day_start = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    day_end = day_start + timedelta(days=1) - timedelta(seconds=1)
    day_start_ts = int(day_start.timestamp())
    day_end_ts = int(day_end.timestamp())
    return await _fetch_range(feed_id, day_start_ts, day_end_ts)


def _day_complete(df: pd.DataFrame, d: date) -> bool:
    if df.empty:
        return False
    day_start = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    day_end = day_start + timedelta(days=1) - timedelta(seconds=1)
    return df.index.min() <= day_start and df.index.max() >= day_end


def _missing_ranges(df: pd.DataFrame, d: date) -> list[tuple[int, int]]:
    """Return (start_ts, end_ts) ranges that are missing for the given day."""
    day_start = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    day_end = day_start + timedelta(days=1) - timedelta(seconds=1)
    day_start_ts = int(day_start.timestamp())
    day_end_ts = int(day_end.timestamp())

    if df.empty:
        return [(day_start_ts, day_end_ts)]

    ranges: list[tuple[int, int]] = []
    min_ts = int(df.index.min().timestamp())
    max_ts = int(df.index.max().timestamp())
    if min_ts > day_start_ts:
        ranges.append((day_start_ts, min_ts - 1))
    if max_ts < day_end_ts:
        ranges.append((max_ts + 1, day_end_ts))
    return ranges


def _iter_dates(start: datetime, end: datetime):
    """Yield date objects for each day in [start, end] (UTC)."""
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    current = start.date()
    end_date = end.date()
    while current <= end_date:
        yield current
        current += timedelta(days=1)


class ChainLinkAssetLoader:
    """Loader for Chainlink Data Streams reports."""

    CONCURRENCY = 4

    def __init__(self, path: tuple[str, ...]):
        self._path = path

    async def load(
        self,
        asset: ChainLinkAsset,
        start: datetime,
        end: datetime | None = None,
    ) -> pd.DataFrame:
        """Load Chainlink reports for an asset."""
        if end is None:
            end = datetime.now(timezone.utc)
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)

        feed_id = asset.feed_id
        dates = list(_iter_dates(start, end))
        if not dates:
            return pd.DataFrame()

        sem = asyncio.Semaphore(self.CONCURRENCY)

        async def fetch_one(d: date) -> pd.DataFrame:
            async with sem:
                df = await _fetch_day_data(feed_id, d)
            if _day_complete(df, d):
                return df
            ranges = _missing_ranges(df, d)
            for start_ts, end_ts in ranges:
                extra = await _fetch_range(feed_id, start_ts, end_ts)
                if not extra.empty:
                    df = pd.concat([df, extra], axis=0)
            df = df[~df.index.duplicated(keep="last")].sort_index()
            cache_path = _day_cache_path(feed_id, d)
            backend = get_cache_backend()
            await backend.asave(cache_path, df)
            return df

        results = await asyncio.gather(*[fetch_one(d) for d in dates])
        combined = pd.concat(results, axis=0) if results else pd.DataFrame()
        if combined.empty:
            return combined
        combined = combined[~combined.index.duplicated(keep="last")].sort_index()
        return combined.loc[(combined.index >= start) & (combined.index <= end)]
