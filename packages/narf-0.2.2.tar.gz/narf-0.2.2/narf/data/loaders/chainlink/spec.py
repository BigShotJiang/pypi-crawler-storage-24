from narf.data.loaders.base_spec import NodeSpec

from .loader import ChainLinkAssetLoader


# Chainlink namespace:
# - chainlink.asset.load(ChainLinkAsset, start, end) for price reports

chainlink_spec = NodeSpec(
    children={
        "asset": NodeSpec(key="datatype", loader=ChainLinkAssetLoader),
    }
)
