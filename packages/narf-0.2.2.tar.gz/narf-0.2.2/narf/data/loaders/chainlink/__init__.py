from narf.data.loaders.base_spec import build

from .loader import ChainLinkAsset
from .spec import chainlink_spec


chainlink = build(chainlink_spec)


__all__ = ["chainlink", "ChainLinkAsset"]
