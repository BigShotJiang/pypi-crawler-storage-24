"""Shared slug generation and parsing for Polymarket crypto up/down markets.

Duration 60 (hourly) uses human-readable format. Two variants exist:
- Old (before 2026-03-15 05:00 UTC): {asset}-up-or-down-{month}-{day}-{hour}am-et (no year)
- New (from 2026-03-15 05:00 UTC): {asset}-up-or-down-{month}-{day}-{year}-{hour}am-et
Duration 1440 (1d): two variants:
- Before 2026-03-13: {asset}-up-or-down-on-{month}-{day} (no year)
- From 2026-03-13: {asset}-up-or-down-on-{month}-{day}-{year}
Other durations use: {asset}-updown-{minutes}m-{unix_timestamp}
"""

from __future__ import annotations

import re
from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

CRYPTO_ASSET_NAME_MAP = {"btc": "bitcoin", "sol": "solana", "xrp": "xrp", "eth": "etherium"}
CRYPTO_ASSET_SYMBOL_MAP = {v: k for k, v in CRYPTO_ASSET_NAME_MAP.items()}

ET = ZoneInfo("America/New_York")
MONTH_NAMES = [
    "january", "february", "march", "april", "may", "june",
    "july", "august", "september", "october", "november", "december",
]

# Cutoff: March 15 2026 05:00 UTC (1am ET) - slugs before this use old format (no year)
_DURATION_60_FORMAT_CUTOFF = datetime(2026, 3, 15, 5, 0, 0, tzinfo=timezone.utc)

# New format: bitcoin-up-or-down-march-18-2026-8am-et
_DURATION_60_NEW_PATTERN = re.compile(
    r"^(\w+)-up-or-down-([a-z]+)-(\d{1,2})-(\d{4})-(\d{1,2})(am|pm)-et$"
)
# Old format: bitcoin-up-or-down-march-15-12am-et (no year)
_DURATION_60_OLD_PATTERN = re.compile(
    r"^(\w+)-up-or-down-([a-z]+)-(\d{1,2})-(\d{1,2})(am|pm)-et$"
)
# Duration 1440 (1d) cutoff: first date with year suffix
_DURATION_1440_FORMAT_CUTOFF = date(2026, 3, 13)
# New format: bitcoin-up-or-down-on-march-13-2026
_DURATION_1440_NEW_PATTERN = re.compile(
    r"^(\w+)-up-or-down-on-([a-z]+)-(\d{1,2})-(\d{4})$"
)
# Old format: bitcoin-up-or-down-on-january-15 (no year)
_DURATION_1440_OLD_PATTERN = re.compile(
    r"^(\w+)-up-or-down-on-([a-z]+)-(\d{1,2})$"
)


def generate_crypto_updown_slug(asset: str, minutes: int, timestamp: datetime) -> str:
    """Generate Polymarket crypto up/down market slug.

    For duration 60: human-readable format in ET. Format depends on date:
    - Before 2026-03-15 05:00 UTC: {asset}-up-or-down-{month}-{day}-{hour}am-et (no year)
    - From 2026-03-15 05:00 UTC: {asset}-up-or-down-{month}-{day}-{year}-{hour}am-et
    For duration 1440 (1d): before 2026-03-13 no year, from 2026-03-13 {month}-{day}-{year}
    For other durations: {asset}-updown-{minutes}m-{unix_timestamp}

    Raises ValueError if asset not in CRYPTO_ASSET_NAME_MAP for duration 60 or 1440.
    """
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)

    if minutes == 60:
        full_name = CRYPTO_ASSET_NAME_MAP.get(asset.lower())
        if full_name is None:
            raise ValueError(
                f"Unknown asset {asset!r} for duration 60, expected one of "
                f"{list(CRYPTO_ASSET_NAME_MAP)}"
            )
        et_dt = timestamp.astimezone(ET)
        month = MONTH_NAMES[et_dt.month - 1]
        day = et_dt.day
        year = et_dt.year
        hour_24 = et_dt.hour
        hour_12 = (hour_24 % 12) or 12
        am_pm = "am" if hour_24 < 12 else "pm"
        if timestamp < _DURATION_60_FORMAT_CUTOFF:
            return f"{full_name}-up-or-down-{month}-{day}-{hour_12}{am_pm}-et"
        return f"{full_name}-up-or-down-{month}-{day}-{year}-{hour_12}{am_pm}-et"

    if minutes == 1440:
        full_name = CRYPTO_ASSET_NAME_MAP.get(asset.lower())
        if full_name is None:
            raise ValueError(
                f"Unknown asset {asset!r} for duration 1440, expected one of "
                f"{list(CRYPTO_ASSET_NAME_MAP)}"
            )
        d = timestamp.date()
        month = MONTH_NAMES[d.month - 1]
        day = d.day
        if d >= _DURATION_1440_FORMAT_CUTOFF:
            return f"{full_name}-up-or-down-on-{month}-{day}-{d.year}"
        return f"{full_name}-up-or-down-on-{month}-{day}"

    unix_ts = int(timestamp.timestamp())
    return f"{asset.lower()}-updown-{minutes}m-{unix_ts}"


def _parse_hour_am_pm(hour_str: str, am_pm: str) -> int:
    """Convert hour_12 + am_pm to 24-hour."""
    hour_12 = int(hour_str)
    if am_pm == "am":
        return 0 if hour_12 == 12 else hour_12
    return 12 if hour_12 == 12 else hour_12 + 12


def parse_slug_to_market_datetime(slug: str) -> datetime | None:
    """Parse slug to market start datetime (UTC). Returns None for malformed slugs."""
    slug_lower = slug.lower()
    m = _DURATION_60_NEW_PATTERN.match(slug_lower)
    if m is not None:
        _asset, month_str, day_str, year_str, hour_str, am_pm = m.groups()
        try:
            month_idx = MONTH_NAMES.index(month_str) + 1
        except ValueError:
            return None
        et_dt = datetime(
            int(year_str), month_idx, int(day_str),
            _parse_hour_am_pm(hour_str, am_pm), 0, 0, tzinfo=ET
        )
        return et_dt.astimezone(timezone.utc)

    m = _DURATION_60_OLD_PATTERN.match(slug_lower)
    if m is not None:
        _asset, month_str, day_str, hour_str, am_pm = m.groups()
        try:
            month_idx = MONTH_NAMES.index(month_str) + 1
        except ValueError:
            return None
        day = int(day_str)
        hour_24 = _parse_hour_am_pm(hour_str, am_pm)
        year = _DURATION_60_FORMAT_CUTOFF.year
        et_dt = datetime(year, month_idx, day, hour_24, 0, 0, tzinfo=ET)
        return et_dt.astimezone(timezone.utc)

    m = _DURATION_1440_NEW_PATTERN.match(slug_lower)
    if m is not None:
        _asset, month_str, day_str, year_str = m.groups()
        try:
            month_idx = MONTH_NAMES.index(month_str) + 1
        except ValueError:
            return None
        et_dt = datetime(int(year_str), month_idx, int(day_str), 0, 0, 0, tzinfo=ET)
        return et_dt.astimezone(timezone.utc)

    m = _DURATION_1440_OLD_PATTERN.match(slug_lower)
    if m is not None:
        _asset, month_str, day_str = m.groups()
        try:
            month_idx = MONTH_NAMES.index(month_str) + 1
        except ValueError:
            return None
        year = _DURATION_1440_FORMAT_CUTOFF.year
        et_dt = datetime(year, month_idx, int(day_str), 0, 0, 0, tzinfo=ET)
        return et_dt.astimezone(timezone.utc)

    parts = slug.split("-")
    if len(parts) < 4:
        return None
    try:
        return datetime.fromtimestamp(int(parts[-1]), tz=timezone.utc)
    except (ValueError, OverflowError):
        return None


def parse_slug_to_fetch_params(slug: str) -> tuple[str, int, date] | None:
    """Parse slug to (asset_symbol, minutes, date) for cache/day lookup. Returns None for malformed slugs."""
    slug_lower = slug.lower()
    m = _DURATION_60_NEW_PATTERN.match(slug_lower)
    if m is not None:
        asset_name, month_str, day_str, year_str, _hour_str, _am_pm = m.groups()
        symbol = CRYPTO_ASSET_SYMBOL_MAP.get(asset_name)
        if symbol is None:
            return None
        try:
            month_idx = MONTH_NAMES.index(month_str) + 1
        except ValueError:
            return None
        d = date(int(year_str), month_idx, int(day_str))
        return (symbol, 60, d)

    m = _DURATION_60_OLD_PATTERN.match(slug_lower)
    if m is not None:
        asset_name, month_str, day_str, hour_str, am_pm = m.groups()
        symbol = CRYPTO_ASSET_SYMBOL_MAP.get(asset_name)
        if symbol is None:
            return None
        try:
            month_idx = MONTH_NAMES.index(month_str) + 1
        except ValueError:
            return None
        year = _DURATION_60_FORMAT_CUTOFF.year
        hour_24 = _parse_hour_am_pm(hour_str, am_pm)
        et_dt = datetime(year, month_idx, int(day_str), hour_24, 0, 0, tzinfo=ET)
        utc_dt = et_dt.astimezone(timezone.utc)
        return (symbol, 60, utc_dt.date())

    m = _DURATION_1440_NEW_PATTERN.match(slug_lower)
    if m is not None:
        asset_name, month_str, day_str, year_str = m.groups()
        symbol = CRYPTO_ASSET_SYMBOL_MAP.get(asset_name)
        if symbol is None:
            return None
        try:
            month_idx = MONTH_NAMES.index(month_str) + 1
        except ValueError:
            return None
        d = date(int(year_str), month_idx, int(day_str))
        return (symbol, 1440, d)

    m = _DURATION_1440_OLD_PATTERN.match(slug_lower)
    if m is not None:
        asset_name, month_str, day_str = m.groups()
        symbol = CRYPTO_ASSET_SYMBOL_MAP.get(asset_name)
        if symbol is None:
            return None
        try:
            month_idx = MONTH_NAMES.index(month_str) + 1
        except ValueError:
            return None
        year = _DURATION_1440_FORMAT_CUTOFF.year
        d = date(year, month_idx, int(day_str))
        return (symbol, 1440, d)

    parts = slug.split("-")
    if len(parts) < 4:
        return None
    try:
        unix_ts = int(parts[-1])
        d = datetime.fromtimestamp(unix_ts, tz=timezone.utc).date()
        minutes_str = parts[2].rstrip("m")
        minutes = int(minutes_str)
        asset = parts[0]
        return (asset, minutes, d)
    except (ValueError, OverflowError, IndexError):
        return None
