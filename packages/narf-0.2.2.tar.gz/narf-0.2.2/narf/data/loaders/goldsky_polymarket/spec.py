from narf.data.loaders.base_spec import NodeSpec

from .loader import GoldskyCryptoUpdownTradesLoader, GoldskyGenericTradesLoader
from .user_loader import GoldskyUserTradesLoader


# Goldsky Polymarket namespace:
# - goldsky_polymarket.trades.load(slug) for any slug (generic)
# - goldsky_polymarket.trades.crypto_updown.load(slug) for crypto up/down
# - goldsky_polymarket.trades.crypto_updown.load_range(asset, minutes, start, end) for range
# - goldsky_polymarket.user_trades.load(account, start, end) for user trades

goldsky_polymarket_spec = NodeSpec(
    children={
        "trades": NodeSpec(
            key="datatype",
            loader=GoldskyGenericTradesLoader,
            children={
                "crypto_updown": NodeSpec(key="datatype", loader=GoldskyCryptoUpdownTradesLoader),
            },
        ),
        "user_trades": NodeSpec(key="datatype", loader=GoldskyUserTradesLoader),
    }
)
