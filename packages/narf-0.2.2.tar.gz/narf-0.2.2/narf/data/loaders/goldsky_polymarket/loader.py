"""Goldsky Polymarket trades loader.

Data source: Goldsky GraphQL API + Polymarket Gamma API (via polymarket_gamma loader)
  - Goldsky: GraphQL endpoint for order filled events (from GOLDSKY_ENDPOINT env var)
  - polymarket_gamma: Market metadata and token IDs (markets.load or markets.crypto_updown.load)

Returned DataFrame:
- index: timestamp (UTC datetime)
- columns: maker, taker, makerAmountFilled, takerAmountFilled,
           fee, usdc_on_maker, usdc_on_taker, usd_amount, token_amount, price,
           taker_direction, maker_direction, outcome_label
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timezone

import aiohttp
import numpy as np
import pandas as pd

from narf.data.loaders.cache_config import get_cache_backend
from narf.data.loaders.utils import cached_function, DATETIME_INDEX_DTYPE_MS_UTC

# Constants
USDC_ASSET_ID = "0"
SCALE = 1e6  # poly_data normalizes by 1e6

# GraphQL query fields
FIELDS = """
id
transactionHash
timestamp
orderHash
maker
taker
makerAssetId
takerAssetId
makerAmountFilled
takerAmountFilled
fee
"""

Q_MAKER = f"""
query ($first: Int!, $lastId: ID!, $assetId: BigInt!) {{
  orderFilledEvents(
    first: $first
    orderBy: id
    orderDirection: asc
    where: {{ id_gt: $lastId, makerAssetId: $assetId }}
  ) {{
    {FIELDS}
  }}
}}
"""

Q_TAKER = f"""
query ($first: Int!, $lastId: ID!, $assetId: BigInt!) {{
  orderFilledEvents(
    first: $first
    orderBy: id
    orderDirection: asc
    where: {{ id_gt: $lastId, takerAssetId: $assetId }}
  ) {{
    {FIELDS}
  }}
}}
"""


def _token_ids_from_market_df(df: pd.DataFrame, slug: str) -> tuple[str, str]:
    """Extract token IDs from polymarket_gamma market DataFrame."""
    if df.empty or slug not in df.index:
        raise ValueError(f"Market not found or unresolved: {slug}")
    row = df.loc[slug]
    return str(row["clobTokenUpId"]), str(row["clobTokenDownId"])


_INTERNAL_COLUMNS = ["id", "transactionHash", "orderHash", "token_asset_id", "makerAssetId", "takerAssetId"]


def drop_internal_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Drop internal/raw columns that shouldn't be in the final output."""
    to_drop = [c for c in _INTERNAL_COLUMNS if c in df.columns]
    if to_drop:
        return df.drop(columns=to_drop)
    return df


async def gql(query: str, variables: dict, endpoint: str, session: aiohttp.ClientSession, timeout: int = 60) -> dict:
    """Execute GraphQL query against Goldsky endpoint.

    Args:
        query: GraphQL query string
        variables: Query variables dict
        endpoint: Goldsky GraphQL endpoint URL
        session: Reused aiohttp ClientSession for connection pooling
        timeout: Request timeout in seconds

    Returns:
        GraphQL response data dict

    Raises:
        RuntimeError: If GraphQL response contains errors or request fails after retries
    """
    max_retries = 3
    backoff = 1.0

    for attempt in range(max_retries):
        try:
            async with session.post(
                endpoint,
                json={"query": query, "variables": variables},
                timeout=aiohttp.ClientTimeout(total=timeout)
            ) as response:
                response.raise_for_status()
                j = await response.json()
                if "errors" in j:
                    raise RuntimeError(j["errors"])
                return j["data"]
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            if attempt < max_retries - 1:
                print(f"Goldsky request failed (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {backoff}s...")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2.0, 10.0)
            else:
                raise RuntimeError(f"Goldsky request failed after {max_retries} attempts") from e


async def fetch_all(
    query: str,
    base_vars: dict,
    endpoint: str,
    session: aiohttp.ClientSession,
    page_size: int = 1000,
    sleep_s: float = 0.1,
    label: str = "",
) -> list[dict]:
    """Fetch all order filled events with pagination.

    Args:
        query: GraphQL query string with $first, $lastId, and any custom variables
        base_vars: Query variables dict (merged with first/lastId per page)
        endpoint: Goldsky GraphQL endpoint URL
        session: Reused aiohttp ClientSession for connection pooling
        page_size: Number of records per page
        sleep_s: Sleep between requests (seconds)
        label: Log prefix for pagination progress

    Returns:
        List of order filled event dicts
    """
    out = []
    last_id = ""  # works with id_gt in graph-node
    pages = 0

    while True:
        data = await gql(query, {"first": page_size, "lastId": last_id, **base_vars}, endpoint, session)
        batch = data.get("orderFilledEvents", [])
        if not batch:
            break

        pages += 1
        out.extend(batch)
        last_id = batch[-1]["id"]

        print(f"{label} page={pages} fetched={len(batch)} total={len(out)}")

        await asyncio.sleep(sleep_s)

    print(f"{label} done pages={pages} total={len(out)}")
    return out




async def export_market_fills(
    token1: str,
    token2: str,
    endpoint: str,
    page_size: int = 1000,
    sleep_s: float = 0.0,
) -> pd.DataFrame:
    """Fetch and process all market fills for a pair of tokens.

    Args:
        token1: First token ID
        token2: Second token ID
        endpoint: Goldsky GraphQL endpoint URL
        page_size: Records per page
        sleep_s: Sleep between requests

    Returns:
        DataFrame with processed trade data
    """
    # Pull fills where either outcome token appears on maker or taker side (4 queries), then dedupe.
    # Reuse one ClientSession across all 4 concurrent fetches for connection pooling
    async with aiohttp.ClientSession() as session:
        results = await asyncio.gather(
            fetch_all(Q_MAKER, {"assetId": token1}, endpoint, session, page_size=page_size, sleep_s=sleep_s, label="maker-up"),
            fetch_all(Q_TAKER, {"assetId": token1}, endpoint, session, page_size=page_size, sleep_s=sleep_s, label="taker-up"),
            fetch_all(Q_MAKER, {"assetId": token2}, endpoint, session, page_size=page_size, sleep_s=sleep_s, label="maker-down"),
            fetch_all(Q_TAKER, {"assetId": token2}, endpoint, session, page_size=page_size, sleep_s=sleep_s, label="taker-down"),
        )
    rows = []
    for result in results:
        rows.extend(result)

    print(f"Raw rows across 4 queries: {len(rows)}")

    if not rows:
        print("No rows found, returning empty DataFrame")
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    before_dedupe = len(df)
    df = df.drop_duplicates(subset=["id"])
    print(f"After dedupe by id: {len(df)} (dropped {before_dedupe - len(df)})")

    # Keep huge ids exact
    df["makerAssetId"] = df["makerAssetId"].astype(str)
    df["takerAssetId"] = df["takerAssetId"].astype(str)

    # Convert numeric fields (fail fast if unexpected)
    for col in ["timestamp", "makerAmountFilled", "takerAmountFilled", "fee"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="raise")

    # Constrain to "this market": one side is USDC and the other side is one of the market tokens
    market_tokens = {str(token1), str(token2)}
    is_usdc_maker = df["makerAssetId"].eq(USDC_ASSET_ID)
    is_usdc_taker = df["takerAssetId"].eq(USDC_ASSET_ID)
    other_is_market_token = (
        (is_usdc_maker & df["takerAssetId"].isin(market_tokens))
        | (is_usdc_taker & df["makerAssetId"].isin(market_tokens))
    )
    before_market_filter = len(df)
    df = df[other_is_market_token].copy()
    print(
        f"After USDC<->(token1/token2) filter: {len(df)} "
        f"(dropped {before_market_filter - len(df)})"
    )

    # Derive usd_amount, token_amount, price, and directions (poly_data-style)
    df["usdc_on_maker"] = df["makerAssetId"].eq(USDC_ASSET_ID)
    df["usdc_on_taker"] = df["takerAssetId"].eq(USDC_ASSET_ID)

    # sanity: exactly one side should be USDC
    bad = df[~(df["usdc_on_maker"] ^ df["usdc_on_taker"])]
    if len(bad) > 0:
        raise ValueError(f"Unexpected fills where USDC isn't exactly one side: {len(bad)} rows")

    df["usd_amount"] = np.where(df["usdc_on_maker"], df["makerAmountFilled"], df["takerAmountFilled"]) / SCALE
    df["token_amount"] = np.where(df["usdc_on_maker"], df["takerAmountFilled"], df["makerAmountFilled"]) / SCALE
    df["token_asset_id"] = np.where(df["usdc_on_maker"], df["takerAssetId"], df["makerAssetId"])
    df["price"] = df["usd_amount"] / df["token_amount"]

    # taker BUY if taker pays USDC; else taker SELL
    df["taker_direction"] = np.where(df["takerAssetId"].eq(USDC_ASSET_ID), "BUY", "SELL")
    df["maker_direction"] = np.where(df["taker_direction"].eq("BUY"), "SELL", "BUY")

    # Map token_asset_id to labels (token1/token2)
    df["outcome_label"] = np.where(df["token_asset_id"].astype(str) == str(token1), "token1", "token2")

    # Convert timestamp to datetime and set as index
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", utc=True)
    df = df.sort_values(["timestamp", "id"], ascending=[True, True])
    df = df.set_index("timestamp")
    df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)

    df = drop_internal_columns(df)

    return df


# For trades loading, refactor to use cached_function on a helper function
# Path function returns FULL path including filename WITH extension  
# Example result: "goldsky_polymarket/trades/{slug}.parquet" (complete path with extension)
@cached_function(lambda slug, token1=None, token2=None, endpoint=None, page_size=None, sleep_s=None: f"goldsky_polymarket/trades/{slug}.parquet")
async def _fetch_trades_data(slug: str, token1: str, token2: str, endpoint: str, page_size: int = 1000, sleep_s: float = 0.1) -> pd.DataFrame:
    """Helper function to fetch trades data (cached).
    
    Path function returns FULL path including filename WITH extension.
    Example result: "goldsky_polymarket/trades/{slug}.parquet" (complete path with extension)
    """
    df = await export_market_fills(token1, token2, endpoint, page_size=page_size, sleep_s=sleep_s)
    # Cache backend saves with index=True, so no need to reset
    return df


class GoldskyGenericTradesLoader:
    """Loader for Goldsky Polymarket trades (generic, any slug)."""

    def __init__(self, path: tuple[str, ...]):
        self._path = path

    async def load(
        self,
        slug: str,
        refresh: str = "auto",  # auto|force|cache-only
        page_size: int = 1000,
        sleep_s: float = 0.1,
    ) -> pd.DataFrame:
        """Load Polymarket trades for any market slug."""
        from narf.data import polymarket_gamma

        endpoint = os.environ.get("GOLDSKY_ENDPOINT")
        if not endpoint:
            raise ValueError("GOLDSKY_ENDPOINT environment variable is required")

        cache_path = f"goldsky_polymarket/trades/{slug}.parquet"
        backend = get_cache_backend()

        if refresh == "cache-only":
            cached_result = await backend.atry_load(cache_path)
            return drop_internal_columns(cached_result) if cached_result is not None else pd.DataFrame()

        if refresh == "auto":
            cached_result = await backend.atry_load(cache_path)
            if cached_result is not None:
                return drop_internal_columns(cached_result)

        if refresh == "force":
            from narf.data.loaders.utils import invalidate_cached_function
            invalidate_cached_function(lambda s: f"goldsky_polymarket/trades/{s}.parquet", slug)

        df_market = await polymarket_gamma.markets.load(slug)
        token1, token2 = _token_ids_from_market_df(df_market, slug)
        print(f"Resolved slug={slug} -> token1:{token1}, token2:{token2}")

        return drop_internal_columns(await _fetch_trades_data(slug, token1, token2, endpoint, page_size=page_size, sleep_s=sleep_s))


class GoldskyCryptoUpdownTradesLoader:
    """Loader for Goldsky Polymarket trades (crypto up/down slugs)."""

    CONCURRENCY = 4

    def __init__(self, path: tuple[str, ...]):
        self._path = path

    async def load_range(
        self,
        asset: str,
        minutes: int,
        start: datetime,
        end: datetime | None = None,
        page_size: int = 1000,
        sleep_s: float = 0.1,
    ) -> None:
        """Fetch and cache Polymarket trades for all crypto up/down slugs in range.

        Does not return data (would not fit in memory). Use load(slug) to read cached trades.
        """
        from narf.data import polymarket_gamma

        endpoint = os.environ.get("GOLDSKY_ENDPOINT")
        if not endpoint:
            raise ValueError("GOLDSKY_ENDPOINT environment variable is required")

        if end is None:
            end = datetime.now(timezone.utc)
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)

        df_markets = await polymarket_gamma.markets.crypto_updown.load_range(asset, minutes, start, end)
        if df_markets.empty:
            return

        slugs = df_markets.index.tolist()
        sem = asyncio.Semaphore(self.CONCURRENCY)

        async def fetch_one(slug: str) -> None:
            async with sem:
                token1 = str(df_markets.loc[slug, "clobTokenUpId"])
                token2 = str(df_markets.loc[slug, "clobTokenDownId"])
                await _fetch_trades_data(slug, token1, token2, endpoint, page_size=page_size, sleep_s=sleep_s)

        await asyncio.gather(*[fetch_one(slug) for slug in slugs])

    async def load(
        self,
        slug: str,
        refresh: str = "auto",  # auto|force|cache-only
        page_size: int = 1000,
        sleep_s: float = 0.1,
    ) -> pd.DataFrame:
        """Load Polymarket trades for a crypto up/down market slug."""
        from narf.data import polymarket_gamma

        endpoint = os.environ.get("GOLDSKY_ENDPOINT")
        if not endpoint:
            raise ValueError("GOLDSKY_ENDPOINT environment variable is required")

        cache_path = f"goldsky_polymarket/trades/{slug}.parquet"
        backend = get_cache_backend()

        if refresh == "cache-only":
            cached_result = await backend.atry_load(cache_path)
            return drop_internal_columns(cached_result) if cached_result is not None else pd.DataFrame()

        if refresh == "auto":
            cached_result = await backend.atry_load(cache_path)
            if cached_result is not None:
                return drop_internal_columns(cached_result)

        if refresh == "force":
            from narf.data.loaders.utils import invalidate_cached_function
            invalidate_cached_function(lambda s: f"goldsky_polymarket/trades/{s}.parquet", slug)

        df_market = await polymarket_gamma.markets.crypto_updown.load(slug)
        token1, token2 = _token_ids_from_market_df(df_market, slug)
        print(f"Resolved slug={slug} -> token1:{token1}, token2:{token2}")

        return drop_internal_columns(await _fetch_trades_data(slug, token1, token2, endpoint, page_size=page_size, sleep_s=sleep_s))
