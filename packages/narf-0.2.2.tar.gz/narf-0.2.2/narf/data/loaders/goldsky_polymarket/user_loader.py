"""Goldsky Polymarket per-user trades loader.

Loads all trades for a single account address, one day at a time (cached).
Resolves token asset IDs to market slugs via the Polymarket Gamma API.

Data source: Goldsky GraphQL API + Polymarket Gamma API (for slug resolution)

Returned DataFrame:
- index: timestamp (UTC datetime)
- columns: slug, maker, taker, makerAmountFilled, takerAmountFilled,
           fee, usdc_on_maker, usdc_on_taker, usd_amount, token_amount, price,
           taker_direction, maker_direction, outcome_label, upPrice, downPrice
"""

from __future__ import annotations

import asyncio
import os
from datetime import date, datetime, timedelta, timezone

import aiohttp
import numpy as np
import pandas as pd

from narf.data.loaders.goldsky_polymarket.loader import (
    FIELDS,
    SCALE,
    USDC_ASSET_ID,
    drop_internal_columns,
    fetch_all,
    gql,
)
from narf.data.loaders.polymarket_gamma.loader import parse_market_token_info
from narf.data.loaders.utils import DATETIME_INDEX_DTYPE_MS_UTC, cached_function

GAMMA_BASE_URL = "https://gamma-api.polymarket.com"
BATCH_SIZE = 10

Q_USER_MAKER = f"""
query ($first: Int!, $lastId: ID!, $account: String!, $startTs: BigInt!, $endTs: BigInt!) {{
  orderFilledEvents(
    first: $first
    orderBy: id
    orderDirection: asc
    where: {{ id_gt: $lastId, maker: $account, timestamp_gte: $startTs, timestamp_lt: $endTs }}
  ) {{
    {FIELDS}
  }}
}}
"""

Q_USER_TAKER = f"""
query ($first: Int!, $lastId: ID!, $account: String!, $startTs: BigInt!, $endTs: BigInt!) {{
  orderFilledEvents(
    first: $first
    orderBy: id
    orderDirection: asc
    where: {{ id_gt: $lastId, taker: $account, timestamp_gte: $startTs, timestamp_lt: $endTs }}
  ) {{
    {FIELDS}
  }}
}}
"""

# In-memory cache: token_id -> (slug, outcome_label, upPrice, downPrice)
# Not persisted. Rebuilt on process restart.
_token_to_slug: dict[str, tuple[str, str, float, float]] = {}


async def _fetch_markets_by_token_ids(token_ids: list[str]) -> list[dict]:
    """Fetch markets from Gamma API by clob token IDs (single batch, max 10)."""
    params = "&".join(f"clob_token_ids={tid}" for tid in token_ids)
    url = f"{GAMMA_BASE_URL}/markets?{params}"
    max_retries = 3
    backoff = 1.0

    for attempt in range(max_retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    response.raise_for_status()
                    return await response.json()
        except Exception as e:
            if attempt < max_retries - 1:
                print(f"Gamma markets request failed (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {backoff}s...")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2.0, 10.0)
            else:
                raise RuntimeError(f"Gamma markets request failed after {max_retries} attempts") from e


async def _resolve_token_slugs(token_ids: set[str]) -> dict[str, tuple[str, str, float, float]]:
    """Resolve token IDs to (slug, outcome_label, upPrice, downPrice) via Gamma API.

    Uses module-level _token_to_slug as in-memory cache.
    Batches unknown IDs in groups of BATCH_SIZE.
    Returns the mapping for the requested token_ids only.
    Raises ValueError if any market is not resolved.
    """
    unknown = [tid for tid in token_ids if tid not in _token_to_slug]

    if unknown:
        total_batches = (len(unknown) + BATCH_SIZE - 1) // BATCH_SIZE
        print(f"slug-resolve: {len(unknown)} unknown token IDs, {total_batches} batches")
        for i in range(0, len(unknown), BATCH_SIZE):
            batch = unknown[i : i + BATCH_SIZE]
            batch_num = i // BATCH_SIZE + 1
            markets = await _fetch_markets_by_token_ids(batch)
            print(f"slug-resolve batch={batch_num}/{total_batches}")
            for market in markets:
                info = parse_market_token_info(market)
                clob_ids = info["clobTokenIds"]
                _token_to_slug[clob_ids[0]] = (info["slug"], "token1", info["upPrice"], info["downPrice"])
                _token_to_slug[clob_ids[1]] = (info["slug"], "token2", info["upPrice"], info["downPrice"])
        print(f"slug-resolve done, cache size={len(_token_to_slug)}")

    return {tid: _token_to_slug[tid] for tid in token_ids if tid in _token_to_slug}


@cached_function(lambda account, d: f"goldsky_polymarket/user_trades/{account}/{d}.parquet")
async def _fetch_user_day(account: str, d: date) -> pd.DataFrame:
    """Fetch and process all trades for an account on a single UTC day (cached)."""
    endpoint = os.environ.get("GOLDSKY_ENDPOINT")
    if not endpoint:
        raise ValueError("GOLDSKY_ENDPOINT environment variable is required")

    day_start = int(datetime(d.year, d.month, d.day, tzinfo=timezone.utc).timestamp())
    day_end = day_start + 86400
    base_vars = {"account": account, "startTs": str(day_start), "endTs": str(day_end)}

    max_retries = 3
    for attempt in range(max_retries):
        try:
            async with aiohttp.ClientSession() as session:
                results = await asyncio.gather(
                    fetch_all(Q_USER_MAKER, base_vars, endpoint, session, label=f"user-maker {d}"),
                    fetch_all(Q_USER_TAKER, base_vars, endpoint, session, label=f"user-taker {d}"),
                )
            break
        except RuntimeError as e:
            if attempt < max_retries - 1:
                print(f"Goldsky fetch failed for {d} (attempt {attempt + 1}/{max_retries}): {e}. Retrying in 3s...")
                await asyncio.sleep(3)
            else:
                raise

    rows: list[dict] = []
    for result in results:
        rows.extend(result)

    print(f"Raw rows across 2 queries for {account} on {d}: {len(rows)}")

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    before_dedupe = len(df)
    df = df.drop_duplicates(subset=["id"])
    print(f"After dedupe by id: {len(df)} (dropped {before_dedupe - len(df)})")

    df["makerAssetId"] = df["makerAssetId"].astype(str)
    df["takerAssetId"] = df["takerAssetId"].astype(str)

    for col in ["timestamp", "makerAmountFilled", "takerAmountFilled", "fee"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="raise")

    # Keep only rows where exactly one side is USDC
    is_usdc_maker = df["makerAssetId"].eq(USDC_ASSET_ID)
    is_usdc_taker = df["takerAssetId"].eq(USDC_ASSET_ID)
    has_usdc_side = is_usdc_maker ^ is_usdc_taker
    before_filter = len(df)
    df = df[has_usdc_side].copy()
    print(f"After USDC-one-side filter: {len(df)} (dropped {before_filter - len(df)})")

    if df.empty:
        return pd.DataFrame()

    df["usdc_on_maker"] = df["makerAssetId"].eq(USDC_ASSET_ID)
    df["usdc_on_taker"] = df["takerAssetId"].eq(USDC_ASSET_ID)

    df["usd_amount"] = np.where(df["usdc_on_maker"], df["makerAmountFilled"], df["takerAmountFilled"]) / SCALE
    df["token_amount"] = np.where(df["usdc_on_maker"], df["takerAmountFilled"], df["makerAmountFilled"]) / SCALE
    df["token_asset_id"] = np.where(df["usdc_on_maker"], df["takerAssetId"], df["makerAssetId"])
    df["price"] = df["usd_amount"] / df["token_amount"]

    df["taker_direction"] = np.where(df["takerAssetId"].eq(USDC_ASSET_ID), "BUY", "SELL")
    df["maker_direction"] = np.where(df["taker_direction"] == "BUY", "SELL", "BUY")

    # Resolve token_asset_id -> (slug, outcome_label) via Gamma API
    unique_tokens = set(df["token_asset_id"].unique())
    token_map = await _resolve_token_slugs(unique_tokens)

    df["slug"] = df["token_asset_id"].map(lambda tid: token_map[tid][0] if tid in token_map else None)
    df["outcome_label"] = df["token_asset_id"].map(lambda tid: token_map[tid][1] if tid in token_map else None)
    df["upPrice"] = df["token_asset_id"].map(lambda tid: token_map[tid][2] if tid in token_map else None)
    df["downPrice"] = df["token_asset_id"].map(lambda tid: token_map[tid][3] if tid in token_map else None)

    unresolved = df["slug"].isna().sum()
    if unresolved > 0:
        unresolved_ids = set(df.loc[df["slug"].isna(), "token_asset_id"].unique())
        raise RuntimeError(f"Failed to resolve {unresolved} rows ({len(unresolved_ids)} token IDs) to slugs: {unresolved_ids}")

    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", utc=True)
    df = df.sort_values(["timestamp", "id"], ascending=[True, True])
    df = df.set_index("timestamp")
    df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)

    df = drop_internal_columns(df)

    return df


class GoldskyUserTradesLoader:
    """Loader for Goldsky Polymarket trades for a specific user account.

    Fetches trades per-day (cached). Each completed UTC day is cached independently.
    """

    def __init__(self, path: tuple[str, ...]):
        self._path = path

    async def load(self, account: str, start: date, end: date, concurrency: int = 3) -> pd.DataFrame:
        """Load trades for [start, end) date range. Each day cached independently.

        Raises ValueError if the range includes today or future dates (UTC).
        """
        today_utc = datetime.now(timezone.utc).date()
        if end > today_utc:
            raise ValueError(f"Range includes unfinished days (end={end}, today UTC is {today_utc})")

        days: list[date] = []
        d = start
        while d < end:
            days.append(d)
            d += timedelta(days=1)
        if not days:
            return pd.DataFrame()

        sem = asyncio.Semaphore(concurrency)

        async def fetch_day(day: date) -> pd.DataFrame:
            async with sem:
                return await _fetch_user_day(account, day)

        frames = await asyncio.gather(*[fetch_day(day) for day in days])
        combined = pd.concat(frames)
        if combined.empty:
            return pd.DataFrame()
        cols = ["slug"] + [c for c in combined.columns if c != "slug"]
        return combined[cols]
