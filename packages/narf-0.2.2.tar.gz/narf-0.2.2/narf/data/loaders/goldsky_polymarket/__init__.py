from narf.data.loaders.base_spec import build

from .spec import goldsky_polymarket_spec


goldsky_polymarket = build(goldsky_polymarket_spec)


__all__ = ["goldsky_polymarket"]
