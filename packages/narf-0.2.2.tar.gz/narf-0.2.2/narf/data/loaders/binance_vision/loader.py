import asyncio
import io
import os
from typing import List, Optional, Tuple
from datetime import datetime, date, timedelta, timezone
import zipfile
import aiohttp
import pandas as pd

from narf.data.loaders.base_loader import Loader, extract_semantic_path
from narf.data.loaders.utils import cached_function, DATETIME_INDEX_DTYPE_MS_UTC


URL_PATTERNS = [
    (
        (),
        "{base}/{market}/um/daily/klines/{symbol}/{interval}/{symbol}-{interval}-{year}-{month:02d}-{day:02d}.zip",
    ),
    (
        ("futures",),
        "{base}/{market}/um/daily/klines/{symbol}/{interval}/{symbol}-{interval}-{year}-{month:02d}-{day:02d}.zip",
    ),
    (
        ("futures", "<margination>", "<datatype>"),
        "{base}/{market}/{margination}/daily/{datatype}/{symbol}/{interval}/{symbol}-{interval}-{year}-{month:02d}-{day:02d}.zip",
    ),

    (
        ("spot",),
        "{base}/{market}/daily/{datatype}/{symbol}/{interval}/{symbol}-{interval}-{year}-{month:02d}-{day:02d}.zip",
    ),
    (
        ("spot", "aggTrades"),
        "{base}/{market}/daily/{datatype}/{symbol}/{symbol}-{datatype}-{year}-{month:02d}-{day:02d}.zip",
    ),
    (
        ("spot", "<datatype>"),
        "{base}/{market}/daily/{datatype}/{symbol}/{interval}/{symbol}-{interval}-{year}-{month:02d}-{day:02d}.zip",
    ),
]


INDEX_COLUMN = {
    "klines": "open_time",
    "trades": "timestamp",
    "aggTrades": "timestamp",
}


async def load_zipped_csv(url: str, header: Optional[Tuple[str]] = None) -> pd.DataFrame:
    """Load CSV data from a zipped URL."""
    async with aiohttp.ClientSession() as session:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as response:
            response.raise_for_status()
            content = await response.read()

    zf = zipfile.ZipFile(io.BytesIO(content))
    name = zf.namelist()[0]

    with zf.open(name) as f:
        df = pd.read_csv(f, header=None if header else 0, names=list(header) if header else None, index_col=False)

    return df


def _parse_intraday_interval(interval: str) -> timedelta | None:
    """Parse Binance intraday interval into timedelta.

    Returns None for 1d+ intervals and unsupported formats.
    """
    if len(interval) < 2:
        return None

    value = interval[:-1]
    unit = interval[-1]
    if not value.isdigit():
        return None

    amount = int(value)
    if unit == "s":
        return timedelta(seconds=amount)
    if unit == "m":
        return timedelta(minutes=amount)
    if unit == "h":
        return timedelta(hours=amount)
    return None


def _day_complete(df: pd.DataFrame, d: date, interval: str) -> bool:
    """Check if the DataFrame covers the full range of the day."""
    if df.empty:
        return False
    # Ensure index is timezone-aware (UTC) - handles cached data that might be naive
    if df.index.tz is None:
        df.index = df.index.tz_localize('UTC')

    interval_td = _parse_intraday_interval(interval)
    # Ignore 1d+ and unsupported intervals for now.
    if interval_td is None:
        return True

    day_start = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    day_end = day_start + timedelta(days=1) - interval_td
    return df.index.min() <= day_start and df.index.max() >= day_end


def _iter_dates(start: datetime, end: datetime):
    """Yield date objects for each day in [start, end] (UTC)."""
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    current = start.date()
    end_date = end.date()
    while current <= end_date:
        yield current
        current += timedelta(days=1)


class BinanceVisionLoader(Loader):
    BASE_URL = "https://data.binance.vision/data"
    URL_PATTERNS = URL_PATTERNS

    def _path_func(self, symbol: str, interval: str, year: int, month: int, day: int) -> str:
        """Path function for binance_vision cache.
        """
        path_info = self.get_parsed_path()
        market = path_info['market']
        datatype = path_info['datatype']
        if 'margination' in path_info:
            margination = f"{path_info['margination']}/"
        else:
            margination = ""
        return f"binance_vision/{market}/{margination}{symbol}/{datatype}/{interval}/{year}-{month:02d}-{day:02d}.parquet"

    @cached_function(lambda self, symbol, interval, year, month, day: self._path_func(symbol, interval, year, month, day))
    async def _load_day(self, symbol: str, interval: str, year: int, month: int, day: int) -> pd.DataFrame:
        url = self._build_url(**{
            "symbol": symbol,
            "interval": interval,
            "year": year,
            "month": month,
            "day": day,
        })
        print('Loading', url)
        df = await load_zipped_csv(url)

        path = self.get_parsed_path()
        idx_col = INDEX_COLUMN[path["datatype"]]

        df[idx_col] = pd.to_datetime(df[idx_col] * 1000000)
        df.set_index(idx_col, inplace=True)
        
        # Ensure index is timezone-aware (UTC)
        if df.index.tz is None:
            df.index = df.index.tz_localize('UTC')
        df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)

        return df
    
    CONCURRENCY = 4

    async def load(self, symbol: str, start: datetime, end: Optional[datetime] = None, interval: str = "1m") -> pd.DataFrame:
        if end is None:
            end = datetime.now(timezone.utc)
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)

        dates = list(_iter_dates(start, end))
        if not dates:
            return pd.DataFrame()

        sem = asyncio.Semaphore(self.CONCURRENCY)

        async def fetch_one(d: date) -> pd.DataFrame:
            async with sem:
                df = await self._load_day(symbol, interval, d.year, d.month, d.day)
            if not _day_complete(df, d, interval):
                cache_path = self._path_func(symbol, interval, d.year, d.month, d.day)
                from narf.data.loaders.cache_config import get_cache_backend
                backend = get_cache_backend()
                await backend.adelete(cache_path)
                df = await self._load_day(symbol, interval, d.year, d.month, d.day)
            return df

        results = await asyncio.gather(*[fetch_one(d) for d in dates])
        combined = pd.concat(results, axis=0) if results else pd.DataFrame()
        if combined.empty:
            return combined
        combined = combined[~combined.index.duplicated(keep="last")].sort_index()
        return combined.loc[(combined.index >= start) & (combined.index <= end)]
    

class BinanceVisionSpotLoader(BinanceVisionLoader):
    @cached_function(lambda self, symbol, interval, year, month, day: self._path_func(symbol, interval, year, month, day))
    async def _load_day(self, symbol: str, interval: str, year: int, month: int, day: int) -> pd.DataFrame:
        url = self._build_url(**{
            "symbol": symbol,
            "interval": interval,
            "year": year,
            "month": month,
            "day": day,
        })
        print('Loading', url)
        df = await load_zipped_csv(url, header=(
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_asset_volume", "number_of_trades",
            "taker_buy_base_volume", "taker_buy_quote_volume", "ignore",
        ))

        path = self.get_parsed_path()
        idx_col = INDEX_COLUMN[path["datatype"]]

        df[idx_col] = pd.to_datetime(df[idx_col] * 1000)
        df.set_index(idx_col, inplace=True)
        
        # Ensure index is timezone-aware (UTC)
        if df.index.tz is None:
            df.index = df.index.tz_localize('UTC')
        df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)

        return df
    
    async def load(self, symbol: str, start: datetime, end: Optional[datetime] = None, interval: str = "1m") -> pd.DataFrame:
        df = await super().load(symbol, start, end, interval)
        if df.empty:
            return df
        # Deduplicate by index for spot data
        df = df[~df.index.duplicated(keep="last")].sort_index()
        return df
