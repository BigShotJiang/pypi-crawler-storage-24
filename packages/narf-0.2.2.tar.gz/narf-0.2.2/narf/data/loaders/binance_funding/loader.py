"""Binance USDT-M futures funding rate loader.

Data source: Binance Futures public REST API
  GET https://fapi.binance.com/fapi/v1/fundingRate

Design goals:
- No auth required (public endpoint)
- Pagination across long history
- Local caching in repo ./cache/ (consistent with other narf loaders)
- Incremental updates

Returned DataFrame:
- index: fundingTime (UTC datetime)
- columns:
    - fundingRate (float)
    - markPrice (float)

We intentionally omit the redundant "symbol" column.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone, date, timedelta
from typing import Optional

import aiohttp
import pandas as pd

from narf.data.loaders.utils import cached_function, DATETIME_INDEX_DTYPE_MS_UTC


BASE_URL = "https://fapi.binance.com"
ENDPOINT = "/fapi/v1/fundingRate"


def _dt_to_ms(dt: datetime) -> int:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def _ms_to_dt(ms: int) -> pd.Timestamp:
    return pd.to_datetime(ms, unit="ms", utc=True)


def _day_complete(df: pd.DataFrame, d: date) -> bool:
    """Check if the DataFrame covers the full range of the day."""
    if df.empty:
        return False
    # Ensure index is timezone-aware (UTC) - handles cached data that might be naive
    if df.index.tz is None:
        df.index = df.index.tz_localize('UTC')
    day_start = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    day_end = day_start + timedelta(days=1) - timedelta(seconds=1)
    return df.index.min() <= day_start and df.index.max() >= day_end


def _iter_dates(start: datetime, end: datetime):
    """Yield date objects for each day in [start, end] (UTC)."""
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    current = start.date()
    end_date = end.date()
    while current <= end_date:
        yield current
        current += timedelta(days=1)


def _cache_path(symbol: str, d: date) -> str:
    """Generate cache path for a day's data."""
    return f"binance_funding/futures/um/{symbol}/{d.year}-{d.month:02d}-{d.day:02d}.parquet"


def _cache_path_month(symbol: str, year: int, month: int) -> str:
    """Generate cache path for a month's data."""
    return f"binance_funding/futures/um/{symbol}/{year}-{month:02d}.parquet"


def _is_month_completed(year: int, month: int) -> bool:
    """Check if a month is completed (not the current month)."""
    now = datetime.now(timezone.utc)
    current_year = now.year
    current_month = now.month
    return year < current_year or (year == current_year and month < current_month)


def _iter_months(start: datetime, end: datetime):
    """Yield (year, month) tuples for each month in [start, end] (UTC)."""
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    
    current = datetime(start.year, start.month, 1, tzinfo=timezone.utc)
    end_month = datetime(end.year, end.month, 1, tzinfo=timezone.utc)
    
    while current <= end_month:
        yield (current.year, current.month)
        # Move to next month
        if current.month == 12:
            current = datetime(current.year + 1, 1, 1, tzinfo=timezone.utc)
        else:
            current = datetime(current.year, current.month + 1, 1, tzinfo=timezone.utc)


@cached_function(lambda symbol, year, month: _cache_path_month(symbol, year, month))
async def _fetch_month_data(symbol: str, year: int, month: int) -> pd.DataFrame:
    """Fetch one month of funding rates from Binance API.
    
    Fetches data from the first day of the month to the last day of the month.
    """
    # Calculate month boundaries
    month_start = datetime(year, month, 1, tzinfo=timezone.utc)
    if month == 12:
        month_end = datetime(year + 1, 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)
    else:
        month_end = datetime(year, month + 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)
    
    start_ms = _dt_to_ms(month_start)
    end_ms = _dt_to_ms(month_end)

    rows: list[dict] = []
    cursor = int(start_ms)
    pages = 0
    limit = 1000
    max_pages = 1_000_000
    sleep_s = 0.2

    async with aiohttp.ClientSession() as session:
        while cursor <= end_ms:
            pages += 1
            if pages > max_pages:
                raise RuntimeError("max_pages exceeded; possible pagination loop")

            params = {
                "symbol": symbol,
                "startTime": cursor,
                "endTime": end_ms,
                "limit": limit,
            }

            # basic retry/backoff
            backoff = 1.0
            while True:
                print(f"Fetching funding rates for {symbol} from {cursor} to {end_ms} (month {year}-{month:02d})")
                async with session.get(
                    f"{BASE_URL}{ENDPOINT}",
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 429:
                        await asyncio.sleep(backoff)
                        backoff = min(backoff * 2.0, 30.0)
                        continue
                    response.raise_for_status()
                    data = await response.json()
                    break

            if not data:
                break

            rows.extend(data)

            last_ms = int(data[-1]["fundingTime"])
            # ensure progress
            if last_ms < cursor:
                break
            cursor = last_ms + 1

            if sleep_s:
                await asyncio.sleep(sleep_s)

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)

    # Expected columns: symbol, fundingTime, fundingRate, markPrice
    df["fundingTime"] = df["fundingTime"].astype(int)
    df["fundingTime"] = df["fundingTime"].map(_ms_to_dt)
    df["fundingRate"] = df["fundingRate"].astype(float)
    if "markPrice" in df.columns:
        df["markPrice"] = df["markPrice"].astype(float)

    # Drop redundant column
    if "symbol" in df.columns:
        df = df.drop(columns=["symbol"])

    df = df.set_index("fundingTime").sort_index()
    df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)

    # drop duplicates if any
    df = df[~df.index.duplicated(keep="last")]
    return df


@cached_function(lambda symbol, d: _cache_path(symbol, d))
async def _fetch_day_data(symbol: str, d: date) -> pd.DataFrame:
    """Fetch one day of funding rates from Binance API.
    """
    day_start = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    day_end = day_start + timedelta(days=1) - timedelta(seconds=1)
    start_ms = _dt_to_ms(day_start)
    end_ms = _dt_to_ms(day_end)

    rows: list[dict] = []
    cursor = int(start_ms)
    pages = 0
    limit = 1000
    max_pages = 1_000_000
    sleep_s = 0.2

    async with aiohttp.ClientSession() as session:
        while cursor <= end_ms:
            pages += 1
            if pages > max_pages:
                raise RuntimeError("max_pages exceeded; possible pagination loop")

            params = {
                "symbol": symbol,
                "startTime": cursor,
                "endTime": end_ms,
                "limit": limit,
            }

            # basic retry/backoff
            backoff = 1.0
            while True:
                print(f"Fetching funding rates for {symbol} from {cursor} to {end_ms}")
                async with session.get(
                    f"{BASE_URL}{ENDPOINT}",
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 429:
                        await asyncio.sleep(backoff)
                        backoff = min(backoff * 2.0, 30.0)
                        continue
                    response.raise_for_status()
                    data = await response.json()
                    break

            if not data:
                break

            rows.extend(data)

            last_ms = int(data[-1]["fundingTime"])
            # ensure progress
            if last_ms < cursor:
                break
            cursor = last_ms + 1

            if sleep_s:
                await asyncio.sleep(sleep_s)

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)

    # Expected columns: symbol, fundingTime, fundingRate, markPrice
    df["fundingTime"] = df["fundingTime"].astype(int)
    df["fundingTime"] = df["fundingTime"].map(_ms_to_dt)
    df["fundingRate"] = df["fundingRate"].astype(float)
    if "markPrice" in df.columns:
        df["markPrice"] = df["markPrice"].astype(float)

    # Drop redundant column
    if "symbol" in df.columns:
        df = df.drop(columns=["symbol"])

    df = df.set_index("fundingTime").sort_index()
    df.index = df.index.astype(DATETIME_INDEX_DTYPE_MS_UTC)

    # drop duplicates if any
    df = df[~df.index.duplicated(keep="last")]
    return df


class BinanceFundingRateLoader:
    """Loader wired into narf.data.binance under futures.um.funding."""

    CONCURRENCY = 4

    def __init__(self, path: tuple[str, ...]):
        self._path = path

    async def load(
        self,
        symbol: str,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
    ) -> pd.DataFrame:
        """Load Binance funding rates for a symbol.
        
        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            start: Start datetime (UTC). If None, defaults to 90 days ago
            end: End datetime (UTC). If None, defaults to now
            
        Returns:
            DataFrame with index=fundingTime, columns=fundingRate, markPrice
        """
        if end is None:
            end = datetime.now(timezone.utc)
        if start is None:
            # default: last 90 days
            start = end - pd.Timedelta(days=90)
            if start.tzinfo is None:
                start = start.to_pydatetime().replace(tzinfo=timezone.utc)

        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)

        if start > end:
            return pd.DataFrame()

        # Group dates by month
        months = list(_iter_months(start, end))
        if not months:
            return pd.DataFrame()

        sem = asyncio.Semaphore(self.CONCURRENCY)
        results: list[pd.DataFrame] = []

        async def fetch_month(year: int, month: int) -> pd.DataFrame:
            """Fetch data for a completed month using monthly cache."""
            async with sem:
                # _fetch_month_data handles caching automatically via @cached_function
                return await _fetch_month_data(symbol, year, month)

        async def fetch_current_month_days(dates: list[date]) -> list[pd.DataFrame]:
            """Fetch data for current month using daily cache."""
            async def fetch_one(d: date) -> pd.DataFrame:
                async with sem:
                    return await _fetch_day_data(symbol, d)
            
            day_results = await asyncio.gather(*[fetch_one(d) for d in dates])
            return [df for df in day_results if not df.empty]

        # Process each month
        for year, month in months:
            is_completed = _is_month_completed(year, month)
            
            if is_completed:
                # Completed month: use monthly cache
                month_df = await fetch_month(year, month)
                if not month_df.empty:
                    results.append(month_df)
            else:
                # Current month: use daily cache
                # Get dates for this month within the requested range
                month_start = datetime(year, month, 1, tzinfo=timezone.utc)
                if month == 12:
                    month_end = datetime(year + 1, 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)
                else:
                    month_end = datetime(year, month + 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)
                
                # Clip to requested range
                month_start = max(month_start, start)
                month_end = min(month_end, end)
                
                month_dates = list(_iter_dates(month_start, month_end))
                if month_dates:
                    day_results = await fetch_current_month_days(month_dates)
                    results.extend(day_results)

        if not results:
            return pd.DataFrame()

        # Combine all results
        combined = pd.concat(results, axis=0) if results else pd.DataFrame()
        if combined.empty:
            return combined
        
        combined = combined[~combined.index.duplicated(keep="last")].sort_index()
        
        # Filter to requested time range
        return combined.loc[(combined.index >= start) & (combined.index <= end)]
