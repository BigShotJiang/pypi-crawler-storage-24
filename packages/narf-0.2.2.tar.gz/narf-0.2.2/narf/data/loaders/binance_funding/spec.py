from narf.data.loaders.base_spec import NodeSpec

from .loader import BinanceFundingRateLoader


# Binance funding namespace:
# - binance_funding.rate.load(symbol, start, end) for funding rates

binance_funding_spec = NodeSpec(loader=BinanceFundingRateLoader)
