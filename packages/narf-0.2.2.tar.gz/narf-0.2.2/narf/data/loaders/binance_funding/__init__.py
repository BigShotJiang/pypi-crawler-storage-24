from narf.data.loaders.base_spec import build
from .loader import BinanceFundingRateLoader
from .spec import binance_funding_spec

binance_funding = build(binance_funding_spec)

__all__ = ["BinanceFundingRateLoader"]
