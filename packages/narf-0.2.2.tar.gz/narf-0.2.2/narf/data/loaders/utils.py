"""Shared utility functions for narf data loaders."""

import inspect
from typing import Any, Callable

from narf.data.loaders.cache_config import get_cache_backend

# Parquet uses ms precision for datetime. Ensure fresh loads match cached for consistency.
DATETIME_INDEX_DTYPE_MS_UTC = "datetime64[ms, UTC]"


class DoNotCache(Exception):
    """Raise with (value) to return value without caching.

    Use in cached_function-decorated functions when the result should not be cached.
    """

    def __init__(self, value: Any):
        self.value = value


def _save_result(result: Any, cache_path: str) -> None:
    """Save a function result to cache using the cache backend.
    
    Args:
        result: The result to cache
        cache_path: Full cache path including filename with extension (string)
    """
    backend = get_cache_backend()
    backend.save(cache_path, result)


async def _asave_result(result: Any, cache_path: str) -> None:
    """Async save a function result to cache using the cache backend.
    
    Args:
        result: The result to cache
        cache_path: Full cache path including filename with extension (string)
    """
    backend = get_cache_backend()
    await backend.asave(cache_path, result)


def _load_result(cache_path: str) -> Any:
    """Load a function result from cache using the cache backend.
    
    Args:
        cache_path: Full cache path including filename with extension (string)
        
    Returns:
        The cached result
        
    Raises:
        FileNotFoundError: If cache entry doesn't exist
    """
    backend = get_cache_backend()
    return backend.load(cache_path)


def cached_function(path_func: Callable) -> Callable:
    """Decorator that caches function results using a customizable path function.
    
    The path function must accept the same parameters as the cached function (matching signature)
    and return a string path including the filename WITH extension (.parquet, .json, .pkl, etc.).
    
    For methods, path_func will receive `self` as the first argument, allowing access to
    instance attributes like `get_parsed_path()`.
    
    Supports both sync and async functions. For async functions, the wrapper is also async.
    
    Args:
        path_func: Function that generates cache path from function arguments.
                   Must accept the same parameters as the cached function and return
                   a string path with extension (e.g., "binance_vision/spot/BTCUSDT/klines/1m/2024-01.parquet")
        
    Returns:
        Decorator function that wraps the target function with caching
        
    Example:
        @cached_function(lambda feed_id, d: f"chainlink/{feed_id}/{d.year}-{d.month:02d}-{d.day:02d}.parquet")
        async def _fetch_day_data(feed_id: str, d: date) -> pd.DataFrame:
            ...
    """
    def decorator(func: Callable) -> Callable:
        if inspect.iscoroutinefunction(func):
            # Async function wrapper
            async def async_wrapper(*args, **kwargs):
                cache_path = path_func(*args, **kwargs)
                
                # Try to load from cache (single call, returns None if not found)
                backend = get_cache_backend()
                cached_result = await backend.atry_load(cache_path)
                if cached_result is not None:
                    return cached_result
                
                # Cache miss - call async function and save result
                try:
                    result = await func(*args, **kwargs)
                    await _asave_result(result, cache_path)
                    return result
                except DoNotCache as e:
                    return e.value
            
            return async_wrapper
        else:
            # Sync function wrapper
            def wrapper(*args, **kwargs):
                cache_path = path_func(*args, **kwargs)
                
                # Try to load from cache (single call, returns None if not found)
                backend = get_cache_backend()
                cached_result = backend.try_load(cache_path)
                if cached_result is not None:
                    return cached_result
                
                # Cache miss - call function and save result
                try:
                    result = func(*args, **kwargs)
                    _save_result(result, cache_path)
                    return result
                except DoNotCache as e:
                    return e.value
            
            return wrapper
    
    return decorator


# cache_to_file_by_url removed - use cached_function with a path function instead


def invalidate_cached_function(path_func: Callable, *args, **kwargs) -> None:
    """Invalidate a specific cache entry using a path function.
    
    Args:
        path_func: Path function that generates the cache path
        *args: Positional arguments passed to path_func
        **kwargs: Keyword arguments passed to path_func
    """
    cache_path = path_func(*args, **kwargs)
    backend = get_cache_backend()
    backend.delete(cache_path)
