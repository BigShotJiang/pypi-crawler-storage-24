"""
Build provenance record — auto-generated, do not edit.

This file is embedded by the CI/CD pipeline at build time.
It provides hash verification and optional cryptographic
signature verification for this package distribution.
"""

PROVENANCE = {
    'schema_version': '1.0',
    'artifact_hash': 'sha512:4ba05761fd3849ffb5b597679b1b8c542e44d570b5bfc39e16d4cf94255ab9dadabd1425e80a6517eaa7b76df5b1044c96f833be91b54a25b9341704b088a807',
    'version': '0.3.7',
    'registry': 'pypi',
    'package_name': 'kevros',
    'build_timestamp': '2026-03-08T19:21:20Z',
    'build_host_hash': 'sha256:a67e39d1e616c143fa8cde43e1a76acf3012068b1109911b3fc4aa780cb69ef4',
    'git_commit': '634ff936e884c07fc2f458ef7848decc46a72055',
    'git_branch': 'sdk-v0.3.7',
    'signer': 'github-actions-oidc',
    'signature_algorithm': '',
    'signature': '',
    'public_key': '',
    'dependencies_hash': 'sha256:acaa19fb50c1b8622a799ad37fe3638a4002f936bf018d19d03673166dbc2e8d',
}


def get_provenance() -> dict:
    """Return a copy of the build provenance record."""
    return dict(PROVENANCE)
