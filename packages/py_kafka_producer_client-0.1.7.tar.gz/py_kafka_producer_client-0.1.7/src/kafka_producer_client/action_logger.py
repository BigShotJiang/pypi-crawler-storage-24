"""
Action Logger Utility for SD Pipeline.

Provides a reusable `@action_log` decorator that automatically sends
structured action log events to Kafka via the `kafka_producer_client`
package. Works with both sync functions and async FastAPI endpoints.

Usage:
    from kafka_producer_client import action_log, ActionType, NodeType

    @action_log(action_type=ActionType.CREATE, node_type=NodeType.SCIENCES)
    async def my_endpoint(request, credentials=Depends(security)):
        ...
"""

import os
import json
import time
import logging
import functools
import asyncio
import traceback
import inspect
from typing import Any, Optional, Callable

from .producer import KafkaProducerClient
from .config import KafkaProducerConfig
from .models import (
    ActionSource,
    ActionType,
    RequesterType,
    NodeType,
    ActionLogRequestStatus,
    create_action_log_operation,
)

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Singleton Kafka Producer
# ──────────────────────────────────────────────────────────────────────────────

_producer: Optional[KafkaProducerClient] = None
_config: Optional[KafkaProducerConfig] = None


def configure_kafka_producer(config: KafkaProducerConfig) -> None:
    """Manually configure the singleton Kafka producer.
    
    If a producer is already running, it will be shut down and recreated
    with the new configuration upon the next call to ``get_kafka_producer``.
    """
    global _config, _producer
    _config = config
    if _producer is not None:
        _producer.close()
        _producer = None
    logger.info("Kafka producer configuration updated.")


def get_kafka_producer() -> KafkaProducerClient:
    """Return a module-level singleton Kafka producer.
    
    Configuration is pulled from ``configure_kafka_producer`` if called,
    otherwise from environment variables with sensible defaults.
    """
    global _producer, _config
    if _producer is None:
        # if _config is None:
        #     _config = KafkaProducerConfig(
        #         bootstrap_servers=os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"),
        #         default_topic=os.getenv("KAFKA_ACTION_LOG_TOPIC", "action-logs"),
        #         client_id=os.getenv("KAFKA_CLIENT_ID", "sd-pipeline-producer"),
        #     )
        _producer = KafkaProducerClient(_config)
        _producer.start_background_poll()
        logger.info(
            "Kafka producer initialized: servers=%s, topic=%s",
            _config.bootstrap_servers,
            _config.default_topic,
        )
    return _producer


def shutdown_kafka_producer() -> None:
    """Gracefully close the singleton producer. Call on app shutdown."""
    global _producer
    if _producer is not None:
        _producer.close()
        _producer = None
        logger.info("Kafka producer shut down.")


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _extract_token_metadata(credentials) -> dict:
    """Extract requester_id and tenant_id from JWT credentials if available.

    Tries to decode the JWT payload (Base64) without verification — we only
    need non-sensitive metadata fields.  Falls back to 'unknown' on failure.
    """
    import base64

    result = {"requester_id": "unknown", "tenant_id": "unknown"}
    try:
        if credentials is None:
            return result
        token = getattr(credentials, "credentials", None) or str(credentials)
        # JWT: header.payload.signature
        parts = token.split(".")
        if len(parts) >= 2:
            padded = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(padded))
            result["requester_id"] = payload.get("sub", payload.get("userId", "unknown"))
            result["tenant_id"] = payload.get("tenantId", payload.get("tenant_id", "unknown"))
    except Exception:
        logger.debug("Could not decode JWT for action log metadata", exc_info=True)
    return result


def _safe_serialize(obj: Any) -> Any:
    """Attempt to serialize ``obj`` to a JSON-friendly format.

    Handles Pydantic models, dicts, lists, and falls back to ``str(obj)`` 
    for anything else.
    """
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    try:
        # Pydantic v2
        if hasattr(obj, "model_dump"):
            return obj.model_dump()
        # Pydantic v1
        if hasattr(obj, "dict"):
            return obj.dict()
        if isinstance(obj, dict):
            return obj
        if isinstance(obj, (list, tuple)):
            return [_safe_serialize(item) for item in obj]
        return str(obj)
    except Exception:
        return str(obj)


def _send_action_log(
    action_type: ActionType,
    node_type: NodeType,
    node_id: str,
    message: str,
    request_object: Any,
    response_object: Any,
    status: ActionLogRequestStatus,
    requester_id: str = "unknown",
    tenant_id: str = "unknown",
    action_source: ActionSource = ActionSource.HUMAN_API,
    requester_type: RequesterType = RequesterType.TENANT,
    universe_id: Optional[str] = None,
    schema_id: Optional[str] = None,
) -> None:
    """Build and send an action log event to Kafka (fire-and-forget)."""
    try:
        producer = get_kafka_producer()

        action_log_op = create_action_log_operation(
            action_source=action_source,
            action_type=action_type,
            requester_type=requester_type,
            requester_id=requester_id,
            node_type=node_type,
            node_id=node_id,
            message=message,
            request_object=_safe_serialize(request_object),
            response_object=_safe_serialize(response_object),
            universe_id=universe_id or os.getenv("UNIVERSE_ID", "unknown"),
            status=status,
            schema_id=schema_id or os.getenv("ACTION_LOG_SCHEMA_ID", "66a38fe266fc4a159e37149d"),
            tenant_id=tenant_id,
        )

        producer.send(action_log_op.model_dump())
        logger.info(
            "Action log sent: type=%s, node=%s, status=%s, node_id=%s",
            action_type.value, node_type.value, status.value, node_id,
        )
    except Exception:
        # Never let logging failures break the actual business logic
        logger.error("Failed to send action log to Kafka", exc_info=True)


# ──────────────────────────────────────────────────────────────────────────────
# Decorator
# ──────────────────────────────────────────────────────────────────────────────

def action_log(
    action_type: ActionType,
    node_type: NodeType,
    action_source: ActionSource = ActionSource.HUMAN_API,
    requester_type: RequesterType = RequesterType.TENANT,
) -> Callable:
    """Decorator that automatically logs function calls to Kafka.

    Works with both **sync** and **async** callables.  
    It inspects the wrapped function's keyword arguments for a ``credentials``
    or ``token`` argument to extract requester/tenant metadata.

    Parameters
    ----------
    action_type : ActionType
        CREATE, READ, UPDATE, or DELETE.
    node_type : NodeType
        The domain entity type (e.g., SCIENCES, PRODUCTCREATION).
    action_source : ActionSource
        HUMAN_API or SYSTEM.
    requester_type : RequesterType
        TENANT, USER, or SYSTEM.

    Example
    -------
    ::

        @action_log(action_type=ActionType.CREATE, node_type=NodeType.SCIENCES)
        async def generate(request: PipelineRequest, credentials=Depends(security)):
            ...
    """

    def decorator(func: Callable) -> Callable:
        func_name = func.__qualname__

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            # Capture all arguments as a dictionary via inspect
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            all_args = bound_args.arguments

            # Try to extract credentials/token from the bound arguments
            credentials = all_args.get("credentials")
            token = all_args.get("token")
            token_meta = _extract_token_metadata(credentials or token)

            # Filter out 'self', 'cls', and security fields for the request log
            request_obj = {
                k: v for k, v in all_args.items()
                if k not in ("self", "cls", "token", "credentials")
            }

            node_id = func_name
            
            start = time.time()
            try:
                result = await func(*args, **kwargs)
                elapsed = round(time.time() - start, 3)

                _send_action_log(
                    action_type=action_type,
                    node_type=node_type,
                    node_id=node_id,
                    message=f"[{func_name}] completed successfully in {elapsed}s",
                    request_object=request_obj,
                    response_object={"response": result} if isinstance(result, (str, bytes)) else result,
                    status=ActionLogRequestStatus.SUCCESS,
                    requester_id=token_meta["requester_id"],
                    tenant_id=token_meta["tenant_id"],
                    action_source=action_source,
                    requester_type=requester_type,
                )
                return result

            except Exception as exc:
                elapsed = round(time.time() - start, 3)
                _send_action_log(
                    action_type=action_type,
                    node_type=node_type,
                    node_id=node_id,
                    message=f"[{func_name}] failed after {elapsed}s: {str(exc)}",
                    request_object=request_obj,
                    response_object={"error": str(exc), "traceback": traceback.format_exc()},
                    status=ActionLogRequestStatus.FAILURE,
                    requester_id=token_meta["requester_id"],
                    tenant_id=token_meta["tenant_id"],
                    action_source=action_source,
                    requester_type=requester_type,
                )
                raise

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            # Capture all arguments as a dictionary (sync version)
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            all_args = bound_args.arguments

            # Try to extract credentials/token from the bound arguments
            credentials = all_args.get("credentials")
            token = all_args.get("token")
            token_meta = _extract_token_metadata(credentials or token)

            request_obj = {
                k: v for k, v in all_args.items()
                if k not in ("self", "cls", "token", "credentials")
            }

            node_id = func_name

            start = time.time()
            try:
                result = func(*args, **kwargs)
                elapsed = round(time.time() - start, 3)

                _send_action_log(
                    action_type=action_type,
                    node_type=node_type,
                    node_id=node_id,
                    message=f"[{func_name}] completed successfully in {elapsed}s",
                    request_object=request_obj,
                    response_object={"response": result} if isinstance(result, (str, bytes)) else result,
                    status=ActionLogRequestStatus.SUCCESS,
                    requester_id=token_meta["requester_id"],
                    tenant_id=token_meta["tenant_id"],
                    action_source=action_source,
                    requester_type=requester_type,
                )
                return result

            except Exception as exc:
                elapsed = round(time.time() - start, 3)
                _send_action_log(
                    action_type=action_type,
                    node_type=node_type,
                    node_id=node_id,
                    message=f"[{func_name}] failed after {elapsed}s: {str(exc)}",
                    request_object=request_obj,
                    response_object={"error": str(exc), "traceback": traceback.format_exc()},
                    status=ActionLogRequestStatus.FAILURE,
                    requester_id=token_meta["requester_id"],
                    tenant_id=token_meta["tenant_id"],
                    action_source=action_source,
                    requester_type=requester_type,
                )
                raise

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator
