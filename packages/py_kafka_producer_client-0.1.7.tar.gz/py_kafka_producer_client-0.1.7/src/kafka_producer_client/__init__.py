"""kafka-producer-client — reusable Kafka producer for any Python project."""

from .config import KafkaProducerConfig
from .producer import KafkaProducerClient
from .models import (
    ActionSource, ActionType, RequesterType, NodeType, 
    ActionLogRequestStatus, ActionLogCreateRequest, 
    DataIngestionOperation, create_action_log_operation
)
from .action_logger import (
    action_log, 
    get_kafka_producer, 
    shutdown_kafka_producer, 
    configure_kafka_producer
)

__all__ = [
    "KafkaProducerConfig", 
    "KafkaProducerClient",
    "ActionSource", 
    "ActionType", 
    "RequesterType", 
    "NodeType", 
    "ActionLogRequestStatus", 
    "ActionLogCreateRequest", 
    "DataIngestionOperation", 
    "create_action_log_operation",
    "action_log",
    "get_kafka_producer",
    "shutdown_kafka_producer",
    "configure_kafka_producer"
]
