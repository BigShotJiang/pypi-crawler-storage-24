from IsoScore import IsoScore
import torch
import logging
from sklearn.covariance import LedoitWolf
from sklearn.neighbors import kneighbors_graph
import numpy as np
from scipy.stats import skew

logger = logging.getLogger(__name__)

def run_isoscore(embedding):
    """
    Computes the isotropy of a point cloud in embedding space using IsoScore.

    Args:
        embedding (np.ndarray): A set of points (N x D)

    Returns:
        float: The IsoScore between 0 and 1.

    References
    ----------
    [1] Rudman et al. "IsoScore: Measuring the Uniformity of Embedding Space
    Utilization." ACL, pp. 3325-3339. doi: 10.18653/v1/2022.findings-acl.262
    """
    if embedding is None or len(embedding) == 0:
        logger.warning("Empty embedding passed to IsoScore.")
        return 0.0

    score = IsoScore.IsoScore(embedding)
    score = score.detach().to("cpu").item()
    logger.debug(f"Computed IsoScore for shape {embedding.shape}: {score:.4f}")

    return score


def run_isoscore_star(embedding, dim):
    """
    Computes the isotropy of a point cloud in embedding space using IsoScore*.

    Args:
        embedding (np.ndarray): A set of points (N x D)
        dim (int): the dimensionality of the embedding space

    Returns:
        float: The IsoScore between 0 and 1.

    References:
    ----------
    [1] Rudman et al. "Stable Ansiotropic Regularization" arXiv. doi: 10.48550/arXiv.2305.19358
    """
    if embedding is None or len(embedding) == 0:
        logger.warning("Empty embedding passed to IsoScore*.")
        return 0.0

    lw = LedoitWolf().fit(embedding)
    optimal_zeta = lw.shrinkage_

    emb_tensor = torch.from_numpy(embedding).float()
    avg_var = emb_tensor.var(dim=0).mean()
    C0 = torch.eye(dim) * avg_var

    score = IsoScore.IsoScore_star(embedding, C0, optimal_zeta)

    logger.debug(f"Computed IsoScore* for shape {embedding.shape}: {score:.4f}")

    return score.item()


def run_hubness(embedding, k=10, metric='cosine', p=2, measure='robinhood', n_jobs=-1):
    """
    Computes the hubness of an embedding space.

    The hubness of a dataset is defined as the skewness of the in-degree
    distribution (k-occurrence) in a k-nearest neighbour graph.

    Args:
        embedding (np.ndarray): A set of points (N x D)
        k (int): The number of nearest neighbors to consider
        metric (str): The metric used for distance computation.
        p (int): Power parameter for the Minkowski distance: p=1 for Manhattan, p=2 for Euclidean.

    Returns:
        float: The skewness of the in-degree distribution.

    References
    ----------
    [1] Radovanović et al. (2010). "Hubs in Space: Popular Nearest Neighbors in
    High-Dimensional Data." JMLR, pp. 2487-2531. doi: 10.5555/1756006.1953015
    """
    if embedding is None or len(embedding) == 0:
        logger.warning("Empty embedding passed to Hubness.")
        return 0.0

    G_neighbors = kneighbors_graph(embedding, n_neighbors=k, metric=metric, p=p, include_self=False, n_jobs=n_jobs)
    in_degree = np.bincount(G_neighbors.indices, minlength=embedding.shape[0])

    if measure == 'skew':
        return skew(in_degree)

    elif measure == 'gini':
        sorted_indices = np.sort(in_degree)
        n = len(in_degree)
        index = np.arange(1, n + 1)
        return (np.sum((2 * index - n - 1) * sorted_indices)) / (n * np.sum(sorted_indices))

    elif measure == 'robinhood':
        mean_val = np.mean(in_degree)
        return np.sum(np.abs(in_degree - mean_val)) / (2 * np.sum(in_degree))

    else:
        raise ValueError("Unsupported measure. Choose from 'skew', 'gini', or 'robinhood'.")


def run_effective_dimensionality(embeddings, metric='pr', l2_normalize=False, mean_center=True, eps=1e-12):
    X = np.asarray(embeddings, dtype=np.float64)

    if l2_normalize:
        norms = np.linalg.norm(X, axis=1, keepdims=True)
        X = X / np.maximum(norms, eps)

    if mean_center:
        X = X - X.mean(axis=0, keepdims=True)

    # singular values (faster: compute_uv=False)
    s = np.linalg.svd(X, full_matrices=False, compute_uv=False)

    # eigenvalues of X^T X
    lambdas = s * s

    total = lambdas.sum()

    p = lambdas / total
    if metric == 'pr':
        return float(1.0 / np.sum(p * p))

    elif metric == 'er':
        p_safe = np.clip(p, eps, 1.0)
        return float(np.exp(-np.sum(p_safe * np.log(p_safe))))

    else:
        return ValueError('metric must be one of pr or er')


def _normalize_rows(X, eps=1e-12):
    norms = np.linalg.norm(X, axis=1, keepdims=True)
    return X / np.clip(norms, eps, None)


def _estimate_kappa_from_resultant(R, d, eps=1e-12):
    R = float(np.clip(R, 0.0, 1.0 - 1e-6))
    if R < 1e-8:
        return 0.0
    return float(R * (d - R**2) / (1.0 - R**2 + eps))


def _sample_cosine_null(X_unit, rng):
    # X_unit must be row-normalised already
    n, d = X_unit.shape
    m = X_unit.mean(axis=0)
    m_norm = np.linalg.norm(m)
    if m_norm < 1e-12:
        mu_dir = np.zeros(d); mu_dir[0] = 1.0
        R = 0.0
    else:
        mu_dir = m / m_norm
        R = m_norm

    kappa = _estimate_kappa_from_resultant(R, d)
    Z = rng.normal(size=(n, d))
    Y = Z + kappa * mu_dir              # projected-normal / vMF-like
    return _normalize_rows(Y)


def _sample_euclidean_null(X, rng):
    mu = X.mean(axis=0)
    cov = LedoitWolf().fit(X).covariance_ # shrinkage to for low sample sizes
    cov = (cov + cov.T) / 2.0
    cov.flat[:: cov.shape[0] + 1] += 1e-9
    return rng.multivariate_normal(mu, cov, size=X.shape[0])


def _sample_l1_null_laplace_independent(X, rng):
    # Matches per-dimension location and mean absolute deviation (L1 scale proxy)
    mu = X.mean(axis=0)
    b = np.mean(np.abs(X - mu), axis=0) + 1e-12  # Laplace scale estimate
    return rng.laplace(loc=mu, scale=b, size=X.shape)


def _sample_isotropic_null(X, metric, p, rng):
    n, d = X.shape
    Z = rng.normal(size=(n, d))
    if metric == "cosine":
        return _normalize_rows(Z)      # uniform-ish on the sphere
    if metric == "minkowski" and p in (1, 2):
        return Z                       # isotropic in R^d
    raise ValueError


def sample_null_embedding(X, metric, p, rng):
    if metric == "cosine":
        X_unit = _normalize_rows(X)
        return _sample_isotropic_null(X_unit, metric, p,rng)

    if metric == "minkowski" and p == 2:
        return _sample_isotropic_null(X, metric, p ,rng)

    if metric == "minkowski" and p == 1:
        return _sample_isotropic_null(X, metric, p ,rng)

    raise ValueError("Supported: cosine, minkowski p=1 (manhattan), minkowski p=2 (euclidean)")


def run_hubness_zscore(embedding, n_trials=30, k=10, metric="cosine", p=2,
                       measure="robinhood", n_jobs=-1, seed=None):
    X = np.asarray(embedding)
    if X.size == 0:
        return {"observed_hubness": 0.0, "null_mean": 0.0, "null_std": 0.0, "z_score": 0.0}

    # metric-consistent observed representation
    X_obs = _normalize_rows(X) if metric == "cosine" else X
    obs = run_hubness(X_obs, k=k, metric=metric, p=p, measure=measure, n_jobs=n_jobs)

    rng = np.random.default_rng(seed)
    null_scores = []
    for _ in range(int(n_trials)):
        X_null = sample_null_embedding(X, metric=metric, p=p, rng=rng)
        X_null_obs = _normalize_rows(X_null) if metric == "cosine" else X_null
        null_scores.append(run_hubness(X_null_obs, k=k, metric=metric, p=p,
                                       measure=measure, n_jobs=n_jobs))

    null_mean = float(np.mean(null_scores))
    null_std = float(np.std(null_scores, ddof=1)) if len(null_scores) > 1 else 0.0
    z = (obs - null_mean) / null_std if null_std > 0 else 0.0

    return {"observed_hubness": float(obs), "null_mean": null_mean, "null_std": null_std, "z_score": float(z)}
