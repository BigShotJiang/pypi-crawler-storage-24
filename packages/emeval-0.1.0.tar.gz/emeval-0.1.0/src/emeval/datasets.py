import numpy as np
from scipy.stats import ortho_group
from sklearn.preprocessing import normalize


def generate_synthetic_embedding(n_samples=1000, dim=128):
    """ Generates a synthetic dataset with Gaussian noise. """
    return np.random.normal(loc=0.0, scale=1.0, size=(n_samples, dim))


def generate_low_effective_dim(n_samples=1000, high_dim=128, low_dim=3):
    """
    Generates a high-dimensional dataset with a lower effective dimensionality.

    This is achieved by creating a synthetic dataset in a low(er)-dimensional
    space and projecting it into a higher-dimensional space using a random
    linear transformation.

    Args:
        n_samples: The number of data points to generate.
        high_dim: The dimension of the final ambient space (the embedding).
        low_dim: The actual number of independent variables (effective dimension).

    Returns:
        np.ndarray: A matrix of shape (n_samples, high_dim) representing the
            high-dimensional embedding.
    """
    X = generate_synthetic_embedding(n_samples, low_dim)

    # Create random high-D coordinate system
    rotation = ortho_group.rvs(high_dim)

    # Pick only low_dim directions out of high_dim space to define subspace
    embedding_map = rotation[:low_dim, :]

    return X @ embedding_map


def generate_anisotropic(n_samples=1000, dim=128, alpha=2.0):
    X = generate_synthetic_embedding(n_samples, dim)

    # Power-law spectrum (target covariance eigenvalues)
    eigenvalues = np.array([(i + 1) ** (-alpha) for i in range(dim)])

    # Re-normalise so average per-dim variance remains 1
    eigenvalues = eigenvalues / np.sum(eigenvalues) * dim

    scale_diag = np.diag(np.sqrt(eigenvalues))
    rotation = ortho_group.rvs(dim) # random orthogonal matrix so high/low variance directions are randomly orientated

    return X @ scale_diag @ rotation


def generate_noisy_low_effective_dim(n_samples, high_dim=128, low_dim=3, noise_std=0.001):
    """
    Generates points on a unit square in x-y plane with Gaussian noise in z.
    """

    X = generate_synthetic_embedding(n_samples, low_dim)
    Y = np.random.normal(0, noise_std, (n_samples, high_dim - low_dim))

    X = np.column_stack((X,Y))

    # Create random high-D coordinate system
    rotation = ortho_group.rvs(high_dim)

    # Pick only low_dim directions out of high_dim space to define subspace
    embedding_map = rotation[:, :]

    return X @ embedding_map


def generate_unit_hubs(
        n_samples=1000,
        dim=128,
        n_hubs=5,
        pull_strength=0.0,
        seed=None
):
    rng = np.random.default_rng(seed)

    X = generate_synthetic_embedding(n_samples, dim)
    X = normalize(X)

    if pull_strength <= 0:
        return X

    hub_indices = rng.choice(n_samples, size=n_hubs, replace=False)
    hubs = X[hub_indices]

    for i in range(n_samples):
        if i in hub_indices: continue
        target_hub = hubs[rng.integers(0, n_hubs)]

        # weighted average between original point and target hub
        X[i] = (1 - pull_strength) * X[i] + pull_strength * target_hub

    return normalize(X)


def generate_duplicate_samples(n_samples, dim, n_dupes=1, n_copies=10, seed=None):
    rng = np.random.default_rng(seed)

    X = generate_synthetic_embedding(n_samples, dim)

    dupe_indices = rng.choice(n_samples, size=n_dupes, replace=False)
    dupes = X[dupe_indices]

    X_dupe = np.zeros((n_dupes * n_copies, X.shape[1]))
    for i, dupe in enumerate(dupes):
        X_dupe[i*n_copies:(i+1)*n_copies, :] = dupes[i]

    return np.concat((X, X_dupe), axis=0)
