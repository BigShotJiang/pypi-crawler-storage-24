# EmEval
Quantitative evaluation metrics for embeddings and synthetic datasets.