# all-tools-on-blockchain

All-in-one toolset for blockchain smart contract analysis. Read on-chain data, query access control roles, compare contract similarity, check deploy time, and verify bytecode.

## Install

```bash
pip install all-tools-on-blockchain
```

## Tools

| Command | Description |
|---------|-------------|
| `cread` | Read on-chain contract public view data and storage slots |
| `acl` | Query OpenZeppelin AccessControl roles and members |
| `solsim` | Compare similarity of Solidity contracts in a directory |
| `deploytime` | Query contract deployment time |
| `bcverify` | Verify on-chain bytecode against a local compiled artifact |

## Usage

### cread — Read Contract Data

Read all public view functions and default proxy slots:

```bash
cread -a 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38
```

Read a specific storage slot:

```bash
cread -a 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 -s 0x0
```

Example output:

```
Contract Address: 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38
Contract Name: TimedLockBox
+--------------------------------------------+------------------+---------------------------+--------------------------------------------------------------------+
|          ABI From Which Contract           |    Data Type     |       Variable Name       |                         Value|Input Type                          |
+--------------------------------------------+------------------+---------------------------+--------------------------------------------------------------------+
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 |  no params func  |           owner           |             0x1590a7dc3485cE3D32cDAA7cB60E9F2D68116003             |
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 |  no params func  |     penaltyPercentage     |                                 5                                  |
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 |  no params func  |         totalFees         |                                 0                                  |
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 |       slot       |        _ADMIN_SLOT        | 0x0000000000000000000000000000000000000000000000000000000000000000 |
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 |       slot       |        _BEACON_SLOT       | 0x0000000000000000000000000000000000000000000000000000000000000000 |
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 |       slot       |    _IMPLEMENTATION_SLOT   | 0x0000000000000000000000000000000000000000000000000000000000000000 |
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 |       slot       |       _ROLLBACK_SLOT      | 0x0000000000000000000000000000000000000000000000000000000000000000 |
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 | with params func | getUnlockTimeAndLockedEth |                              address                               |
| 0xb916F7A2233C90f7ca7B09f4Ece6aF9feafB8E38 | with params func |           locks           |                              address                               |
+--------------------------------------------+------------------+---------------------------+--------------------------------------------------------------------+
```

### acl — Query Access Control

```bash
acl -a 0xYourContractAddress
```

Options:
- `-r / --role` — Filter by role name or hash (partial match)
- `-p / --proxy` — HTTP/SOCKS proxy (e.g. `http://127.0.0.1:7890`)
- `-o / --output` — Export results to `.json` or `.md`
- `-c / --chain` — Chain ID (default: 1 for Ethereum Mainnet)

### solsim — Contract Similarity

Compare all `.sol` files within a single directory:

```bash
solsim -d ./contracts
```

Cross-compare `.sol` files between two directories:

```bash
solsim -d ./contracts-v1 -d2 ./contracts-v2
```

Options:
- `-d2 / --dir2` — Second directory to cross-compare against the first
- `-t / --threshold` — Minimum similarity ratio (0.0–1.0, default 0.0)

### deploytime — Deploy Time

```bash
deploytime -a 0xYourContractAddress
```

Options:
- `-p / --proxy` — HTTP/SOCKS proxy
- `-c / --chain` — Chain ID (default: 1)

### bcverify — Bytecode Verify

Verify on-chain bytecode matches a local compiled artifact:

```bash
bcverify -a 0xYourContractAddress -f ./artifacts/Contract.json
```

Options:
- `-f / --file` — Local bytecode file (Hardhat/Foundry JSON artifact, or `.bin`/`.hex`)
- `-p / --proxy` — HTTP/SOCKS proxy
- `--strict` — Strict mode: do not ignore metadata differences
- `-c / --chain` — Chain ID (default: 1)

## Supported Chains

Any EVM-compatible chain supported by Etherscan V2 API. Use `-c` to specify the chain ID:

| Chain | ID |
|-------|----|
| Ethereum | 1 |
| BSC | 56 |
| Polygon | 137 |
| Arbitrum | 42161 |
| Optimism | 10 |
| ... | ... |

## License

MIT
