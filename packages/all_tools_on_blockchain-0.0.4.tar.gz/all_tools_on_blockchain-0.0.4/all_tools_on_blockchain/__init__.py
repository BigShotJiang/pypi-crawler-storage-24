# -*- coding: utf-8 -*-
from all_tools_on_blockchain.argparse import (
    read_argparse, access_control_argparse, similarity_argparse,
    deploy_time_argparse, bytecode_verify_argparse,
)
from all_tools_on_blockchain.read import read_contract_storage_data, read_contract_onchain_public_view_data
from all_tools_on_blockchain.access_control import display_access_control, export_results
from all_tools_on_blockchain.contract_similarity import compare_contracts, compare_two_directories
from all_tools_on_blockchain.deploy_time import query_deploy_time
from all_tools_on_blockchain.bytecode_verify import verify_bytecode
from all_tools_on_blockchain.common import setup_proxy, set_chain_id, create_web3


def _init_common(args):
    """统一初始化代理和链 ID"""
    if getattr(args, 'proxy', None):
        setup_proxy(args.proxy)
    if getattr(args, 'chainId', None):
        set_chain_id(args.chainId)


def read_contract():
    args = read_argparse()
    try:
        if not args.inputAddress and not args.slot:
            print('Please input address or read slot')
            return
        web3 = create_web3()
        if args.slot:
            read_contract_storage_data(args.inputAddress, args.slot)
        else:
            read_contract_onchain_public_view_data(args.inputAddress, web3)
    except Exception as e:
        print(e)


def query_access_control():
    args = access_control_argparse()
    try:
        _init_common(args)
        web3 = create_web3()
        result = display_access_control(args.inputAddress, web3, args.roleFilter)
        if result and args.output:
            export_results(*result, args.output)
    except Exception as e:
        print(e)


def query_similarity():
    args = similarity_argparse()
    try:
        if args.directory2:
            compare_two_directories(args.directory, args.directory2, args.threshold)
        else:
            compare_contracts(args.directory, args.threshold)
    except Exception as e:
        print(e)


def query_deploy():
    args = deploy_time_argparse()
    try:
        _init_common(args)
        query_deploy_time(args.inputAddress, create_web3())
    except Exception as e:
        print(e)


def query_bytecode_verify():
    args = bytecode_verify_argparse()
    try:
        _init_common(args)
        verify_bytecode(args.inputAddress, args.filepath, create_web3(),
                        ignore_metadata=not args.strict)
    except Exception as e:
        print(e)
