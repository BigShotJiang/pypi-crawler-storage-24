"""查询 OpenZeppelin AccessControl 合约的角色权限状态"""
import json
from prettytable import PrettyTable
from web3 import Web3
from all_tools_on_blockchain.common import get_session, etherscan_get, ETHERSCAN_API_KEY

# 核心事件签名
ROLE_GRANTED_SIG = Web3.keccak(text="RoleGranted(bytes32,address,address)")
ROLE_REVOKED_SIG = Web3.keccak(text="RoleRevoked(bytes32,address,address)")
ROLE_ADMIN_CHANGED_SIG = Web3.keccak(text="RoleAdminChanged(bytes32,bytes32,bytes32)")

KNOWN_ROLES = {
    "0x" + "0" * 64: "DEFAULT_ADMIN_ROLE",
}


def _get_role_name(role_hash):
    return KNOWN_ROLES.get(role_hash, role_hash)


def _fetch_logs_rpc(web3_instance, address, topic0):
    """通过 RPC eth_getLogs 获取事件"""
    try:
        return web3_instance.eth.get_logs({
            "address": web3_instance.to_checksum_address(address),
            "topics": [topic0],
            "fromBlock": 0,
            "toBlock": "latest",
        })
    except Exception as e:
        print(f"RPC eth_getLogs error: {e}")
        return None


def _fetch_logs_etherscan(address, topic0_hex):
    """通过 Etherscan 获取事件（备选）"""
    data = etherscan_get("", {
        "module": "logs", "action": "getLogs",
        "address": address, "topic0": topic0_hex,
        "fromBlock": 0, "toBlock": "latest",
    }, timeout=10)
    if data and data.get("status") == "1" and data.get("result"):
        return data["result"]
    return []


def _parse_topics(logs, is_rpc=True):
    """统一解析 topics[1] 和 topics[2]"""
    results = []
    for log in logs:
        topics = log.get("topics", [])
        if len(topics) >= 3:
            if is_rpc:
                role = "0x" + topics[1].hex()
                val = "0x" + topics[2].hex()[-40:]
            else:
                role = topics[1]
                val = "0x" + topics[2][-40:]
            results.append((role, val.lower()))
    return results


def _parse_admin_topics(logs, is_rpc=True):
    """解析 RoleAdminChanged topics"""
    results = []
    for log in logs:
        topics = log.get("topics", [])
        if len(topics) >= 3:
            if is_rpc:
                role = "0x" + topics[1].hex()
                new_admin = "0x" + topics[2].hex()
            else:
                role = topics[1]
                new_admin = topics[2]
            results.append((role, new_admin))
    return results


def _fetch_and_parse(web3_instance, address, sig, parser, admin=False):
    """优先 RPC，失败回退 Etherscan"""
    logs = _fetch_logs_rpc(web3_instance, address, sig)
    if logs is not None:
        return (_parse_admin_topics if admin else _parse_topics)(logs, is_rpc=True)
    print("RPC failed, falling back to Etherscan API...")
    logs = _fetch_logs_etherscan(address, sig.hex())
    return (_parse_admin_topics if admin else _parse_topics)(logs, is_rpc=False)


def _resolve_role_names(address, web3_instance):
    """尝试从合约 ABI 中读取 bytes32 常量映射角色名"""
    try:
        checksum = web3_instance.to_checksum_address(address)
        imp = checksum

        # 检查代理
        data = etherscan_get("", {
            "module": "contract", "action": "getsourcecode", "address": checksum
        }, timeout=10)
        if data and data.get("result") and data["result"][0].get("Implementation"):
            impl = data["result"][0]["Implementation"]
            if impl:
                imp = impl

        # 获取 ABI
        abi_data = etherscan_get("", {
            "module": "contract", "action": "getabi", "address": imp
        }, timeout=10)
        if not abi_data or abi_data.get("status") != "1":
            return
        abi = json.loads(abi_data["result"])
        contract = web3_instance.eth.contract(address=checksum, abi=abi)

        for item in abi:
            if (item.get("type") == "function"
                    and item.get("stateMutability") in ("view", "pure")
                    and not item.get("inputs")
                    and len(item.get("outputs", [])) == 1
                    and item["outputs"][0].get("type") == "bytes32"):
                try:
                    result = contract.functions[item["name"]]().call()
                    hex_val = "0x" + result.hex()
                    KNOWN_ROLES.setdefault(hex_val, item["name"])
                except Exception:
                    pass
    except Exception:
        pass


def display_access_control(address, web3_instance, role_filter=None):
    """查询并展示 AccessControl 角色信息"""
    print(f"Querying AccessControl roles for: {address}")
    print("Fetching events...")

    _resolve_role_names(address, web3_instance)

    role_members = {}
    role_admins = {}

    for role, account in _fetch_and_parse(web3_instance, address, ROLE_GRANTED_SIG, _parse_topics):
        role_members.setdefault(role, set()).add(account)

    for role, account in _fetch_and_parse(web3_instance, address, ROLE_REVOKED_SIG, _parse_topics):
        if role in role_members:
            role_members[role].discard(account)

    for role, new_admin in _fetch_and_parse(web3_instance, address, ROLE_ADMIN_CHANGED_SIG, _parse_admin_topics, admin=True):
        role_admins[role] = new_admin

    if not role_members:
        print("No AccessControl role events found for this contract.")
        return None

    table = PrettyTable(["Role Name", "Role Hash", "Member", "Admin Role"])
    table.align = "l"

    for role_hash, members in sorted(role_members.items()):
        role_name = _get_role_name(role_hash)
        admin_name = _get_role_name(role_admins.get(role_hash, "0x" + "0" * 64))

        if role_filter:
            fl = role_filter.lower()
            if fl not in role_name.lower() and fl not in role_hash.lower():
                continue

        if not members:
            table.add_row([role_name, role_hash[:18] + "...", "(no members)", admin_name])
        else:
            for i, member in enumerate(sorted(members)):
                table.add_row([role_name if i == 0 else "", role_hash[:18] + "..." if i == 0 else "", member, admin_name if i == 0 else ""])

    print(table if table.rowcount > 0 else f"No roles found matching filter: '{role_filter}'")
    print(f"\nSummary: {len(role_members)} roles, {sum(len(m) for m in role_members.values())} active members")
    return role_members, role_admins


def export_results(role_members, role_admins, output_path):
    """导出为 JSON 或 Markdown"""
    if output_path.endswith(".json"):
        data = [{
            "role_name": _get_role_name(rh),
            "role_hash": rh,
            "admin_role": _get_role_name(role_admins.get(rh, "0x" + "0" * 64)),
            "members": sorted(members) if members else [],
        } for rh, members in sorted(role_members.items())]
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    elif output_path.endswith(".md"):
        lines = ["# AccessControl Roles\n"]
        for rh, members in sorted(role_members.items()):
            name = _get_role_name(rh)
            lines.append(f"## {name}\n")
            lines.append(f"- **Role Hash**: `{rh}`")
            lines.append(f"- **Admin Role**: {_get_role_name(role_admins.get(rh, '0x' + '0' * 64))}")
            lines.append(f"- **Members** ({len(members)}):\n")
            if members:
                for m in sorted(members):
                    lines.append(f"  - `{m}`")
            else:
                lines.append("  - _(no members)_")
            lines.append("")
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    else:
        print(f"Unsupported format: {output_path} (use .json or .md)")
        return
    print(f"Exported to {output_path}")
