"""CLI 参数解析"""
import argparse


def read_argparse():
    p = argparse.ArgumentParser(description='Read on-chain contract data.')
    p.add_argument('-a', default='', dest='inputAddress', help='Contract address.')
    p.add_argument('-s', default='', dest='slot', help='Storage slot to read.')
    return p.parse_args()


def access_control_argparse():
    p = argparse.ArgumentParser(description='Query AccessControl roles for a contract.')
    p.add_argument('-a', required=True, dest='inputAddress', help='Contract address.')
    p.add_argument('-r', '--role', default=None, dest='roleFilter',
                   help='Filter by role name or hash (partial match).')
    p.add_argument('-p', '--proxy', default=None, dest='proxy',
                   help='HTTP/SOCKS proxy, e.g. http://127.0.0.1:7890')
    p.add_argument('-o', '--output', default=None, dest='output',
                   help='Export to file (.json or .md).')
    p.add_argument('-c', '--chain', default=1, type=int, dest='chainId',
                   help='Chain ID (default: 1 for Ethereum Mainnet).')
    return p.parse_args()


def similarity_argparse():
    p = argparse.ArgumentParser(description='Compare similarity of Solidity contracts.')
    p.add_argument('-d', '--dir', required=True, dest='directory',
                   help='Directory containing .sol files.')
    p.add_argument('-d2', '--dir2', default=None, dest='directory2',
                   help='Second directory to cross-compare against the first.')
    p.add_argument('-t', '--threshold', default=0.0, type=float, dest='threshold',
                   help='Minimum similarity (0.0-1.0), default 0.0')
    return p.parse_args()


def deploy_time_argparse():
    p = argparse.ArgumentParser(description='Query contract deploy time.')
    p.add_argument('-a', required=True, dest='inputAddress', help='Contract address.')
    p.add_argument('-p', '--proxy', default=None, dest='proxy', help='HTTP/SOCKS proxy.')
    p.add_argument('-c', '--chain', default=1, type=int, dest='chainId',
                   help='Chain ID (default: 1 for Ethereum Mainnet).')
    return p.parse_args()


def bytecode_verify_argparse():
    p = argparse.ArgumentParser(description='Verify on-chain bytecode against local file.')
    p.add_argument('-a', required=True, dest='inputAddress', help='Contract address.')
    p.add_argument('-f', '--file', required=True, dest='filepath',
                   help='Local bytecode file (.json artifact or .bin/.hex).')
    p.add_argument('-p', '--proxy', default=None, dest='proxy', help='HTTP/SOCKS proxy.')
    p.add_argument('--strict', action='store_true', dest='strict',
                   help='Strict mode: do not ignore metadata differences.')
    p.add_argument('-c', '--chain', default=1, type=int, dest='chainId',
                   help='Chain ID (default: 1 for Ethereum Mainnet).')
    return p.parse_args()
