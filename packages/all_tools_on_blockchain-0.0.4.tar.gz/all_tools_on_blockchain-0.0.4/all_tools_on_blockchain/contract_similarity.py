"""比较文件夹内 Solidity 合约的相似度"""
import os
import re
from difflib import SequenceMatcher
from prettytable import PrettyTable


def _read_sol_files(directory):
    """读取目录下所有 .sol 文件"""
    files = {}
    for root, _, filenames in os.walk(directory):
        for f in filenames:
            if f.endswith(".sol"):
                path = os.path.join(root, f)
                rel = os.path.relpath(path, directory)
                with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                    files[rel] = fh.read()
    return files


def _normalize(code):
    """去除注释和多余空白，便于比较"""
    # 去除多行注释
    code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
    # 去除单行注释
    code = re.sub(r'//.*', '', code)
    # 压缩空白
    code = re.sub(r'\s+', ' ', code).strip()
    return code


def compare_contracts(directory, threshold=0.0):
    """比较目录下所有 .sol 文件的两两相似度"""
    files = _read_sol_files(directory)
    if len(files) < 2:
        print(f"Found {len(files)} .sol file(s) in {directory}, need at least 2 to compare.")
        return

    names = sorted(files.keys())
    normalized = {n: _normalize(files[n]) for n in names}

    table = PrettyTable(["File A", "File B", "Similarity"])
    table.align = "l"

    pairs = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            ratio = SequenceMatcher(None, normalized[names[i]], normalized[names[j]]).ratio()
            if ratio >= threshold:
                pairs.append((names[i], names[j], ratio))

    pairs.sort(key=lambda x: x[2], reverse=True)
    for a, b, ratio in pairs:
        table.add_row([a, b, f"{ratio:.2%}"])

    if pairs:
        print(table)
    else:
        print(f"No pairs found above {threshold:.0%} threshold.")
    print(f"\nTotal: {len(names)} contracts, {len(pairs)} pairs compared")


def compare_two_directories(dir_a, dir_b, threshold=0.0):
    """比较两个目录下 .sol 文件的跨目录相似度"""
    files_a = _read_sol_files(dir_a)
    files_b = _read_sol_files(dir_b)

    if not files_a:
        print(f"No .sol files found in {dir_a}")
        return
    if not files_b:
        print(f"No .sol files found in {dir_b}")
        return

    names_a = sorted(files_a.keys())
    names_b = sorted(files_b.keys())
    norm_a = {n: _normalize(files_a[n]) for n in names_a}
    norm_b = {n: _normalize(files_b[n]) for n in names_b}

    table = PrettyTable([f"File A ({os.path.basename(dir_a)})",
                         f"File B ({os.path.basename(dir_b)})",
                         "Similarity"])
    table.align = "l"

    pairs = []
    for a in names_a:
        for b in names_b:
            ratio = SequenceMatcher(None, norm_a[a], norm_b[b]).ratio()
            if ratio >= threshold:
                pairs.append((a, b, ratio))

    pairs.sort(key=lambda x: x[2], reverse=True)
    for a, b, ratio in pairs:
        table.add_row([a, b, f"{ratio:.2%}"])

    if pairs:
        print(table)
    else:
        print(f"No pairs found above {threshold:.0%} threshold.")
    print(f"\nTotal: {len(names_a)} + {len(names_b)} contracts, {len(pairs)} cross-pairs compared")
