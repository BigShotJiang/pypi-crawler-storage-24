"""验证链上合约字节码是否与指定源码/JSON文件一致"""
import json
import os
from all_tools_on_blockchain.common import etherscan_get


def _get_onchain_bytecode(address, web3_instance):
    """获取链上 runtime bytecode，优先 RPC"""
    try:
        code = web3_instance.eth.get_code(web3_instance.to_checksum_address(address))
        return code.hex()
    except Exception as e:
        print(f"RPC error: {e}")

    data = etherscan_get("", {
        "module": "proxy", "action": "eth_getCode",
        "address": address, "tag": "latest",
    })
    if data and data.get("result"):
        return data["result"]
    return None


def _load_bytecode_from_file(filepath):
    """从文件加载字节码 (.json artifact / .bin / .hex)"""
    ext = os.path.splitext(filepath)[1].lower()
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read().strip()

    if ext != ".json":
        return content

    data = json.loads(content)
    # Hardhat / Foundry artifact
    for key in ("deployedBytecode", "bytecode"):
        if key in data:
            bc = data[key]
            return bc["object"] if isinstance(bc, dict) and "object" in bc else bc
    # Solc standard output
    if "evm" in data and "deployedBytecode" in data["evm"]:
        return data["evm"]["deployedBytecode"]["object"]

    print("Could not find bytecode in JSON. Expected 'deployedBytecode' or 'bytecode' field.")
    return None


def _normalize(bc):
    if not bc:
        return None
    bc = bc.strip()
    if bc.startswith("0x"):
        bc = bc[2:]
    return bc.lower()


def _strip_metadata(bytecode):
    """去除 Solidity 编译器末尾的 CBOR metadata"""
    if bytecode and len(bytecode) > 86:
        try:
            suffix_len = int(bytecode[-4:], 16) * 2 + 4
            if 0 < suffix_len < len(bytecode):
                return bytecode[:-suffix_len]
        except ValueError:
            pass
    return bytecode


def verify_bytecode(address, filepath, web3_instance, ignore_metadata=True):
    """验证链上字节码与本地文件是否一致"""
    print(f"Verifying bytecode for: {address}")
    print(f"Local file: {filepath}")

    onchain = _normalize(_get_onchain_bytecode(address, web3_instance))
    local = _normalize(_load_bytecode_from_file(filepath))

    if not onchain:
        print("Failed to get on-chain bytecode.")
        return False
    if not local:
        print("Failed to load local bytecode.")
        return False

    if onchain == local:
        print("MATCH: Bytecode is identical.")
        return True

    if ignore_metadata and _strip_metadata(onchain) == _strip_metadata(local):
        print("MATCH: Bytecode matches (metadata differs, which is expected).")
        return True

    print("MISMATCH: Bytecode does not match.")
    print(f"  On-chain: {len(onchain) // 2} bytes | Local: {len(local) // 2} bytes")

    for i in range(min(len(onchain), len(local))):
        if onchain[i] != local[i]:
            print(f"  First difference at byte {i // 2} (hex pos {i})")
            break
    return False
