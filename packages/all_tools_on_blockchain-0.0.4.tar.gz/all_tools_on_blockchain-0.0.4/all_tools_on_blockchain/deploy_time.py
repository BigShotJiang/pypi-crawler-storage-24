"""获取合约部署时间"""
from datetime import datetime, timezone
from all_tools_on_blockchain.common import etherscan_get


def query_deploy_time(address, web3_instance):
    """查询合约部署时间"""
    print(f"Querying deploy time for: {address}")

    # 获取创建交易
    data = etherscan_get("", {
        "module": "contract", "action": "getcontractcreation",
        "contractaddresses": address,
    })
    if not data or data.get("status") != "1" or not data.get("result"):
        print("Could not find contract creation transaction.")
        return

    tx_hash = data["result"][0]["txHash"]
    creator = data["result"][0]["contractCreator"]
    print(f"Creator: {creator}")
    print(f"Deploy TX: {tx_hash}")

    # 优先 RPC 获取区块时间
    timestamp, block_num = None, None
    try:
        receipt = web3_instance.eth.get_transaction_receipt(tx_hash)
        block = web3_instance.eth.get_block(receipt["blockNumber"])
        timestamp, block_num = block["timestamp"], receipt["blockNumber"]
    except Exception as e:
        print(f"RPC error: {e}")

    # 备选 Etherscan
    if not timestamp:
        tx_data = etherscan_get("", {
            "module": "proxy", "action": "eth_getTransactionByHash",
            "txhash": tx_hash,
        })
        if tx_data and tx_data.get("result"):
            block_hex = tx_data["result"].get("blockNumber")
            if block_hex:
                block_num = int(block_hex, 16)
                block_data = etherscan_get("", {
                    "module": "block", "action": "getblockreward",
                    "blockno": block_num,
                })
                if block_data and block_data.get("status") == "1":
                    timestamp = int(block_data["result"]["timeStamp"])

    if timestamp:
        dt = datetime.fromtimestamp(timestamp, tz=timezone.utc)
        print(f"Block: {block_num}")
        print(f"Deploy Time (UTC): {dt.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Timestamp: {timestamp}")
    else:
        print("Could not retrieve block timestamp.")
