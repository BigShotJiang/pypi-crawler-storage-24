"""公共工具模块：代理、session、Etherscan API 等"""
import os
import requests
from web3 import Web3

ETHERSCAN_API_KEY = "Q8K1J5WIXHVQWV1XHVFF1INTPHWFZP5AZV"
DEFAULT_RPC_URL = "https://mainnet.infura.io/v3/c77b93a34625489b8a04b548c96369bf"
ETHERSCAN_V2_BASE = "https://api.etherscan.io/v2/api"
DEFAULT_CHAIN_ID = 1  # Ethereum Mainnet

_session = None  # type: requests.Session | None
_chain_id = DEFAULT_CHAIN_ID


def get_session() -> requests.Session:
    global _session
    if _session is None:
        _session = requests.Session()
    return _session


def setup_proxy(proxy: str):
    """设置全局 HTTP/SOCKS 代理"""
    global _session
    _session = requests.Session()
    if proxy:
        _session.proxies = {"http": proxy, "https": proxy}
        os.environ["HTTP_PROXY"] = proxy
        os.environ["HTTPS_PROXY"] = proxy
        print(f"Using proxy: {proxy}")


def set_chain_id(chain_id: int):
    """设置目标链 ID"""
    global _chain_id
    _chain_id = chain_id


def create_web3(rpc_url: str = DEFAULT_RPC_URL) -> Web3:
    return Web3(Web3.HTTPProvider(rpc_url))


def etherscan_get(path: str, params: dict, timeout: int = 15):
    """统一的 Etherscan V2 API 请求"""
    params["apikey"] = ETHERSCAN_API_KEY
    params["chainid"] = _chain_id
    try:
        resp = get_session().get(ETHERSCAN_V2_BASE, params=params, timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"Etherscan API error: {e}")
        return None
