# -*- coding: utf-8 -*-
"""Tests for deploy_time.py"""
import pytest
from unittest.mock import patch, MagicMock
from all_tools_on_blockchain.deploy_time import query_deploy_time


class TestQueryDeployTime:
    @patch("all_tools_on_blockchain.deploy_time.etherscan_get")
    def test_success_via_rpc(self, mock_escan, capsys):
        mock_escan.return_value = {
            "status": "1",
            "result": [{"txHash": "0xabc", "contractCreator": "0xCreator"}],
        }
        mock_w3 = MagicMock()
        mock_receipt = {"blockNumber": 12345}
        mock_block = {"timestamp": 1609459200}  # 2021-01-01 00:00:00 UTC
        mock_w3.eth.get_transaction_receipt.return_value = mock_receipt
        mock_w3.eth.get_block.return_value = mock_block

        query_deploy_time("0xContract", mock_w3)
        out = capsys.readouterr().out
        assert "0xCreator" in out
        assert "0xabc" in out
        assert "2021-01-01" in out
        assert "12345" in out

    @patch("all_tools_on_blockchain.deploy_time.etherscan_get")
    def test_no_creation_tx(self, mock_escan, capsys):
        mock_escan.return_value = {"status": "0", "result": []}
        mock_w3 = MagicMock()

        query_deploy_time("0xContract", mock_w3)
        out = capsys.readouterr().out
        assert "Could not find" in out

    @patch("all_tools_on_blockchain.deploy_time.etherscan_get")
    def test_rpc_fails_fallback_etherscan(self, mock_escan, capsys):
        # First call: getcontractcreation success
        # Second call: eth_getTransactionByHash
        # Third call: getblockreward
        mock_escan.side_effect = [
            {
                "status": "1",
                "result": [{"txHash": "0xabc", "contractCreator": "0xCreator"}],
            },
            {
                "result": {"blockNumber": hex(100)},
            },
            {
                "status": "1",
                "result": {"timeStamp": "1609459200"},
            },
        ]
        mock_w3 = MagicMock()
        mock_w3.eth.get_transaction_receipt.side_effect = Exception("rpc down")

        query_deploy_time("0xContract", mock_w3)
        out = capsys.readouterr().out
        assert "0xCreator" in out
        assert "2021-01-01" in out
