# -*- coding: utf-8 -*-
"""Tests for contract_similarity.py"""
import os
import tempfile
import pytest
from all_tools_on_blockchain.contract_similarity import (
    _read_sol_files, _normalize, compare_contracts, compare_two_directories,
)


class TestNormalize:
    def test_removes_single_line_comments(self):
        code = "uint x; // this is a comment\nuint y;"
        result = _normalize(code)
        assert "//" not in result
        assert "uint x;" in result and "uint y;" in result

    def test_removes_multi_line_comments(self):
        code = "uint x; /* multi\nline\ncomment */ uint y;"
        result = _normalize(code)
        assert "/*" not in result
        assert "uint x;" in result and "uint y;" in result

    def test_compresses_whitespace(self):
        code = "uint   x;\n\n\n  uint   y;"
        result = _normalize(code)
        assert "  " not in result

    def test_empty_string(self):
        assert _normalize("") == ""


class TestReadSolFiles:
    def test_reads_sol_files(self, tmp_path):
        (tmp_path / "A.sol").write_text("contract A {}", encoding="utf-8")
        (tmp_path / "B.sol").write_text("contract B {}", encoding="utf-8")
        (tmp_path / "readme.md").write_text("not a sol file", encoding="utf-8")
        files = _read_sol_files(str(tmp_path))
        assert len(files) == 2
        assert "A.sol" in files
        assert "B.sol" in files

    def test_reads_nested(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "C.sol").write_text("contract C {}", encoding="utf-8")
        files = _read_sol_files(str(tmp_path))
        assert len(files) == 1

    def test_empty_dir(self, tmp_path):
        files = _read_sol_files(str(tmp_path))
        assert len(files) == 0


class TestCompareContracts:
    def test_identical_files(self, tmp_path, capsys):
        (tmp_path / "A.sol").write_text("contract A { uint x; }", encoding="utf-8")
        (tmp_path / "B.sol").write_text("contract A { uint x; }", encoding="utf-8")
        compare_contracts(str(tmp_path))
        out = capsys.readouterr().out
        assert "100.00%" in out

    def test_different_files(self, tmp_path, capsys):
        (tmp_path / "A.sol").write_text("contract A { uint x; }", encoding="utf-8")
        (tmp_path / "B.sol").write_text("contract B { string name; mapping(address => uint) balances; }", encoding="utf-8")
        compare_contracts(str(tmp_path))
        out = capsys.readouterr().out
        assert "100.00%" not in out

    def test_threshold_filter(self, tmp_path, capsys):
        (tmp_path / "A.sol").write_text("contract A { uint x; }", encoding="utf-8")
        (tmp_path / "B.sol").write_text("contract B { string name; mapping(address => uint) balances; }", encoding="utf-8")
        compare_contracts(str(tmp_path), threshold=0.99)
        out = capsys.readouterr().out
        assert "No pairs found" in out

    def test_single_file(self, tmp_path, capsys):
        (tmp_path / "A.sol").write_text("contract A {}", encoding="utf-8")
        compare_contracts(str(tmp_path))
        out = capsys.readouterr().out
        assert "need at least 2" in out


class TestCompareTwoDirectories:
    def test_cross_identical(self, tmp_path, capsys):
        dir_a = tmp_path / "a"
        dir_b = tmp_path / "b"
        dir_a.mkdir()
        dir_b.mkdir()
        (dir_a / "X.sol").write_text("contract X { uint x; }", encoding="utf-8")
        (dir_b / "Y.sol").write_text("contract X { uint x; }", encoding="utf-8")
        compare_two_directories(str(dir_a), str(dir_b))
        out = capsys.readouterr().out
        assert "100.00%" in out
        assert "cross-pairs" in out

    def test_cross_different(self, tmp_path, capsys):
        dir_a = tmp_path / "a"
        dir_b = tmp_path / "b"
        dir_a.mkdir()
        dir_b.mkdir()
        (dir_a / "X.sol").write_text("contract X { uint x; }", encoding="utf-8")
        (dir_b / "Y.sol").write_text("contract Y { string s; mapping(address => uint) m; }", encoding="utf-8")
        compare_two_directories(str(dir_a), str(dir_b))
        out = capsys.readouterr().out
        assert "100.00%" not in out

    def test_cross_threshold(self, tmp_path, capsys):
        dir_a = tmp_path / "a"
        dir_b = tmp_path / "b"
        dir_a.mkdir()
        dir_b.mkdir()
        (dir_a / "X.sol").write_text("contract X { uint x; }", encoding="utf-8")
        (dir_b / "Y.sol").write_text("contract Y { string s; mapping(address => uint) m; }", encoding="utf-8")
        compare_two_directories(str(dir_a), str(dir_b), threshold=0.99)
        out = capsys.readouterr().out
        assert "No pairs found" in out

    def test_empty_dir_a(self, tmp_path, capsys):
        dir_a = tmp_path / "a"
        dir_b = tmp_path / "b"
        dir_a.mkdir()
        dir_b.mkdir()
        (dir_b / "Y.sol").write_text("contract Y {}", encoding="utf-8")
        compare_two_directories(str(dir_a), str(dir_b))
        out = capsys.readouterr().out
        assert "No .sol files" in out

    def test_empty_dir_b(self, tmp_path, capsys):
        dir_a = tmp_path / "a"
        dir_b = tmp_path / "b"
        dir_a.mkdir()
        dir_b.mkdir()
        (dir_a / "X.sol").write_text("contract X {}", encoding="utf-8")
        compare_two_directories(str(dir_a), str(dir_b))
        out = capsys.readouterr().out
        assert "No .sol files" in out
