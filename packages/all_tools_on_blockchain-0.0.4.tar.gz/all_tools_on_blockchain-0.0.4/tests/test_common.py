# -*- coding: utf-8 -*-
"""Tests for common.py"""
import os
import pytest
from unittest.mock import patch, MagicMock
from all_tools_on_blockchain.common import (
    get_session, setup_proxy, set_chain_id, create_web3,
    etherscan_get, DEFAULT_RPC_URL, DEFAULT_CHAIN_ID,
    ETHERSCAN_API_KEY, ETHERSCAN_V2_BASE,
)
import all_tools_on_blockchain.common as common_mod


class TestGetSession:
    def setup_method(self):
        common_mod._session = None

    def test_returns_session(self):
        s = get_session()
        assert s is not None

    def test_returns_same_session(self):
        s1 = get_session()
        s2 = get_session()
        assert s1 is s2


class TestSetupProxy:
    def setup_method(self):
        common_mod._session = None

    def teardown_method(self):
        os.environ.pop("HTTP_PROXY", None)
        os.environ.pop("HTTPS_PROXY", None)
        common_mod._session = None

    def test_sets_proxy(self):
        setup_proxy("http://127.0.0.1:7890")
        s = get_session()
        assert s.proxies["http"] == "http://127.0.0.1:7890"
        assert os.environ["HTTP_PROXY"] == "http://127.0.0.1:7890"


class TestSetChainId:
    def setup_method(self):
        common_mod._chain_id = DEFAULT_CHAIN_ID

    def test_set_chain_id(self):
        set_chain_id(56)
        assert common_mod._chain_id == 56

    def teardown_method(self):
        common_mod._chain_id = DEFAULT_CHAIN_ID


class TestCreateWeb3:
    def test_default_rpc(self):
        w3 = create_web3()
        assert w3 is not None

    def test_custom_rpc(self):
        w3 = create_web3("https://rpc.ankr.com/eth")
        assert w3 is not None


class TestEtherscanGet:
    def setup_method(self):
        common_mod._session = None
        common_mod._chain_id = DEFAULT_CHAIN_ID

    @patch.object(common_mod, "get_session")
    def test_success(self, mock_get_session):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"status": "1", "result": "ok"}
        mock_resp.raise_for_status = MagicMock()
        mock_session = MagicMock()
        mock_session.get.return_value = mock_resp
        mock_get_session.return_value = mock_session

        result = etherscan_get("", {"module": "contract", "action": "getabi"})
        assert result == {"status": "1", "result": "ok"}
        call_args = mock_session.get.call_args
        assert call_args[1]["params"]["apikey"] == ETHERSCAN_API_KEY
        assert call_args[1]["params"]["chainid"] == DEFAULT_CHAIN_ID

    @patch.object(common_mod, "get_session")
    def test_request_error(self, mock_get_session):
        mock_session = MagicMock()
        mock_session.get.side_effect = Exception("timeout")
        mock_get_session.return_value = mock_session

        result = etherscan_get("", {"module": "test"})
        assert result is None
