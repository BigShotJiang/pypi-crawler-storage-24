# -*- coding: utf-8 -*-
"""Tests for access_control.py"""
import json
import os
import pytest
from unittest.mock import patch, MagicMock
from all_tools_on_blockchain.access_control import (
    _get_role_name, export_results, display_access_control,
    KNOWN_ROLES, ROLE_GRANTED_SIG, ROLE_REVOKED_SIG,
)


class TestGetRoleName:
    def test_known_role(self):
        assert _get_role_name("0x" + "0" * 64) == "DEFAULT_ADMIN_ROLE"

    def test_unknown_role(self):
        h = "0x" + "ab" * 32
        assert _get_role_name(h) == h


class TestExportResults:
    def _sample_data(self):
        role_hash = "0x" + "0" * 64
        role_members = {role_hash: {"0xaaa", "0xbbb"}}
        role_admins = {role_hash: "0x" + "0" * 64}
        return role_members, role_admins

    def test_export_json(self, tmp_path):
        rm, ra = self._sample_data()
        out = str(tmp_path / "out.json")
        export_results(rm, ra, out)
        with open(out, "r") as f:
            data = json.load(f)
        assert len(data) == 1
        assert data[0]["role_name"] == "DEFAULT_ADMIN_ROLE"
        assert len(data[0]["members"]) == 2

    def test_export_md(self, tmp_path):
        rm, ra = self._sample_data()
        out = str(tmp_path / "out.md")
        export_results(rm, ra, out)
        with open(out, "r") as f:
            content = f.read()
        assert "DEFAULT_ADMIN_ROLE" in content
        assert "0xaaa" in content

    def test_export_unsupported(self, tmp_path, capsys):
        rm, ra = self._sample_data()
        out = str(tmp_path / "out.txt")
        export_results(rm, ra, out)
        assert "Unsupported" in capsys.readouterr().out


class TestDisplayAccessControl:
    @patch("all_tools_on_blockchain.access_control._resolve_role_names")
    @patch("all_tools_on_blockchain.access_control._fetch_and_parse")
    def test_no_events(self, mock_fetch, mock_resolve, capsys):
        mock_fetch.return_value = []
        mock_w3 = MagicMock()
        result = display_access_control("0xAddr", mock_w3)
        assert result is None
        assert "No AccessControl" in capsys.readouterr().out

    @patch("all_tools_on_blockchain.access_control._resolve_role_names")
    @patch("all_tools_on_blockchain.access_control._fetch_and_parse")
    def test_with_grant_events(self, mock_fetch, mock_resolve, capsys):
        role_hash = "0x" + "0" * 64
        # grant calls return data, revoke and admin return empty
        mock_fetch.side_effect = [
            [(role_hash, "0xaaa")],  # granted
            [],                      # revoked
            [],                      # admin changed
        ]
        mock_w3 = MagicMock()
        result = display_access_control("0xAddr", mock_w3)
        assert result is not None
        rm, ra = result
        assert "0xaaa" in rm[role_hash]
        out = capsys.readouterr().out
        assert "1 roles" in out

    @patch("all_tools_on_blockchain.access_control._resolve_role_names")
    @patch("all_tools_on_blockchain.access_control._fetch_and_parse")
    def test_grant_then_revoke(self, mock_fetch, mock_resolve, capsys):
        role_hash = "0x" + "0" * 64
        mock_fetch.side_effect = [
            [(role_hash, "0xaaa")],   # granted
            [(role_hash, "0xaaa")],   # revoked
            [],
        ]
        mock_w3 = MagicMock()
        result = display_access_control("0xAddr", mock_w3)
        assert result is not None
        rm, _ = result
        assert len(rm[role_hash]) == 0
