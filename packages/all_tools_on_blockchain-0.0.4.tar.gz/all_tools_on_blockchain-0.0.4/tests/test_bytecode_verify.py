# -*- coding: utf-8 -*-
"""Tests for bytecode_verify.py"""
import json
import pytest
from unittest.mock import patch, MagicMock
from all_tools_on_blockchain.bytecode_verify import (
    _normalize, _strip_metadata, _load_bytecode_from_file,
    _get_onchain_bytecode, verify_bytecode,
)


class TestNormalize:
    def test_strips_0x(self):
        assert _normalize("0xabcd") == "abcd"

    def test_lowercases(self):
        assert _normalize("0xABCD") == "abcd"

    def test_strips_whitespace(self):
        assert _normalize("  0xab  ") == "ab"

    def test_none(self):
        assert _normalize(None) is None

    def test_empty(self):
        assert _normalize("") is None


class TestStripMetadata:
    def test_strips_cbor_suffix(self):
        # Simulate a bytecode with a CBOR metadata suffix
        # Last 2 bytes (4 hex chars) encode the metadata length
        core = "6080604052" * 20  # 200 hex chars
        meta = "a264" + "00" * 30  # 64 hex chars of fake metadata
        length_hex = f"{33:04x}"  # 33 bytes = 66 hex chars + 4 = 70
        bc = core + meta + length_hex
        result = _strip_metadata(bc)
        # Should have removed the suffix
        assert len(result) < len(bc)

    def test_short_bytecode_unchanged(self):
        assert _strip_metadata("abcd") == "abcd"

    def test_none(self):
        assert _strip_metadata(None) is None


class TestLoadBytecodeFromFile:
    def test_load_bin_file(self, tmp_path):
        f = tmp_path / "code.bin"
        f.write_text("0x608060405260", encoding="utf-8")
        result = _load_bytecode_from_file(str(f))
        assert result == "0x608060405260"

    def test_load_json_hardhat_artifact(self, tmp_path):
        artifact = {"deployedBytecode": "0x608060"}
        f = tmp_path / "artifact.json"
        f.write_text(json.dumps(artifact), encoding="utf-8")
        result = _load_bytecode_from_file(str(f))
        assert result == "0x608060"

    def test_load_json_foundry_artifact(self, tmp_path):
        artifact = {"bytecode": {"object": "0xaabb"}}
        f = tmp_path / "artifact.json"
        f.write_text(json.dumps(artifact), encoding="utf-8")
        result = _load_bytecode_from_file(str(f))
        assert result == "0xaabb"

    def test_load_json_solc_output(self, tmp_path):
        artifact = {"evm": {"deployedBytecode": {"object": "0xccdd"}}}
        f = tmp_path / "out.json"
        f.write_text(json.dumps(artifact), encoding="utf-8")
        result = _load_bytecode_from_file(str(f))
        assert result == "0xccdd"

    def test_load_json_no_bytecode_field(self, tmp_path, capsys):
        artifact = {"abi": []}
        f = tmp_path / "bad.json"
        f.write_text(json.dumps(artifact), encoding="utf-8")
        result = _load_bytecode_from_file(str(f))
        assert result is None


class TestGetOnchainBytecode:
    def test_rpc_success(self):
        mock_w3 = MagicMock()
        mock_w3.to_checksum_address.return_value = "0xAddr"
        mock_w3.eth.get_code.return_value = b'\x60\x80'
        result = _get_onchain_bytecode("0xAddr", mock_w3)
        assert result == "6080"

    @patch("all_tools_on_blockchain.bytecode_verify.etherscan_get")
    def test_fallback_etherscan(self, mock_escan):
        mock_w3 = MagicMock()
        mock_w3.to_checksum_address.return_value = "0xAddr"
        mock_w3.eth.get_code.side_effect = Exception("rpc down")
        mock_escan.return_value = {"result": "0x6080"}
        result = _get_onchain_bytecode("0xAddr", mock_w3)
        assert result == "0x6080"


class TestVerifyBytecode:
    def test_exact_match(self, tmp_path, capsys):
        f = tmp_path / "code.bin"
        f.write_text("0x608060", encoding="utf-8")
        mock_w3 = MagicMock()
        mock_w3.to_checksum_address.return_value = "0xAddr"
        mock_w3.eth.get_code.return_value = bytes.fromhex("608060")
        result = verify_bytecode("0xAddr", str(f), mock_w3)
        assert result is True
        assert "MATCH" in capsys.readouterr().out

    def test_mismatch(self, tmp_path, capsys):
        f = tmp_path / "code.bin"
        f.write_text("0xaabbcc", encoding="utf-8")
        mock_w3 = MagicMock()
        mock_w3.to_checksum_address.return_value = "0xAddr"
        mock_w3.eth.get_code.return_value = bytes.fromhex("112233")
        result = verify_bytecode("0xAddr", str(f), mock_w3)
        assert result is False
        assert "MISMATCH" in capsys.readouterr().out
