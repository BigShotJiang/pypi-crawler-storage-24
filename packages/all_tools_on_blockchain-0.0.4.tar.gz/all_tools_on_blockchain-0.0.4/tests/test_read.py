# -*- coding: utf-8 -*-
"""Tests for read.py"""
import pytest
from unittest.mock import patch, MagicMock, PropertyMock
from prettytable import PrettyTable
from all_tools_on_blockchain.read import (
    has_data, read_contract_storage_data, read_default_slot,
    DEFAULT_SLOTS,
)


class TestHasData:
    def test_empty_table(self):
        t = PrettyTable(["A", "B"])
        assert has_data(t) is False

    def test_table_with_row(self):
        t = PrettyTable(["A", "B"])
        t.add_row(["1", "2"])
        assert has_data(t) is True


class TestReadContractStorageData:
    def test_prints_slot_value(self, capsys):
        mock_w3 = MagicMock()
        mock_w3.eth.get_storage_at.return_value = bytes.fromhex("abcd")
        read_contract_storage_data("0xAddr", "0x0", mock_w3)
        out = capsys.readouterr().out
        assert "0xAddr" in out
        assert "0x0" in out
        assert "abcd" in out

    def test_empty_address(self, capsys):
        mock_w3 = MagicMock()
        read_contract_storage_data("", "0x0", mock_w3)
        out = capsys.readouterr().out
        assert "Please input" in out

    def test_empty_slot(self, capsys):
        mock_w3 = MagicMock()
        read_contract_storage_data("0xAddr", "", mock_w3)
        out = capsys.readouterr().out
        assert "Please input" in out

    def test_rpc_error(self, capsys):
        mock_w3 = MagicMock()
        mock_w3.eth.get_storage_at.side_effect = Exception("rpc error")
        read_contract_storage_data("0xAddr", "0x0", mock_w3)
        out = capsys.readouterr().out
        assert "Failed" in out


class TestDefaultSlots:
    def test_slot_count(self):
        assert len(DEFAULT_SLOTS) == 4

    def test_slot_structure(self):
        for slot in DEFAULT_SLOTS:
            assert "name" in slot
            assert "value" in slot
            assert slot["value"].startswith("0x")
