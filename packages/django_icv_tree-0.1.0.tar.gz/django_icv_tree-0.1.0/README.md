# django-icv-tree

Materialised path tree structures for Django.

One abstract model, one manager, one queryset. Queryset returns throughout — no
Python list coercions. Configurable path format, async-safe, no tenancy coupling.
Replaces django-mptt, django-treebeard (mp_node), and django-polymorphic-tree.

```python
from icv_tree.models import TreeNode

class Page(TreeNode):
    title = models.CharField(max_length=255)

# Every traversal method returns a lazy QuerySet
page.get_ancestors()
page.get_descendants()
page.get_children()
page.get_siblings()
page.get_root()
page.is_root()
page.is_leaf()

page.move_to(target, position='first-child')
Page.objects.rebuild()
```

For full documentation, configuration reference, and API details see the
[APP-020 spec](../../docs/specs/APP-020-tree/).
