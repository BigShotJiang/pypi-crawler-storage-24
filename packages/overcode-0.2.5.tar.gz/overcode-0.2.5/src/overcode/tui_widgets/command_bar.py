"""
Command bar widget for TUI.

Inline command bar for sending instructions to agents.
"""

from typing import Optional, Tuple

from textual.widgets import Static, Label, Input, TextArea
from textual.containers import Horizontal
from textual.reactive import reactive
from textual.app import ComposeResult
from textual.message import Message
from textual import events


def get_mode_label_and_placeholder(mode: str, target_session: Optional[str]) -> Tuple[str, str]:
    """Get the label text and placeholder for a given command bar mode.

    Pure function — no side effects, fully testable.

    Args:
        mode: The command bar mode (send, standing_orders, new_agent_dir, etc.)
        target_session: The currently targeted session name, or None

    Returns:
        Tuple of (label_text, placeholder_text)
    """
    if mode == "new_agent_dir":
        return "[New Agent: Directory] ", "Enter working directory path..."
    elif mode == "new_agent_name":
        return "[New Agent: Name] ", "Enter agent name (or Enter to accept default)..."
    elif mode == "new_agent_perms":
        return "[New Agent: Permissions] ", "Type 'bypass' for --dangerously-skip-permissions, or Enter for normal..."
    elif mode == "new_agent_teams":
        return "[New Agent: Teams] ", "Type 'yes' to enable agent teams, or Enter to skip..."
    elif mode == "new_remote_agent_sister":
        return "[Remote Agent: Sister] ", "Enter sister name..."
    elif mode == "new_remote_agent_dir":
        return "[Remote Agent: Directory] ", "Enter remote directory (or Enter for '.')..."
    elif mode == "new_remote_agent_name":
        return "[Remote Agent: Name] ", "Enter agent name..."
    elif mode == "new_remote_agent_perms":
        return "[Remote Agent: Permissions] ", "Type 'bypass' or 'skip', or Enter for normal..."
    elif mode == "standing_orders":
        prefix = f"[{target_session} Standing Orders] " if target_session else "[Standing Orders] "
        return prefix, "Enter standing orders (or empty to clear)..."
    elif mode == "value":
        prefix = f"[{target_session} Value] " if target_session else "[Value] "
        return prefix, "Enter priority value (1000 = normal, higher = more important)..."
    elif mode == "cost_budget":
        prefix = f"[{target_session} Budget] " if target_session else "[Budget] "
        return prefix, "Enter $ budget (e.g., 5.00) or 0 to clear..."
    elif mode == "annotation":
        prefix = f"[{target_session} Annotation] " if target_session else "[Annotation] "
        return prefix, "Enter human annotation (or empty to clear)..."
    elif mode == "heartbeat_freq":
        prefix = f"[{target_session} Heartbeat: Frequency] " if target_session else "[Heartbeat: Frequency] "
        return prefix, "Enter interval (e.g., 300, 5m, 1h) or empty to disable..."
    elif mode == "heartbeat_instruction":
        prefix = f"[{target_session} Heartbeat: Instruction] " if target_session else "[Heartbeat: Instruction] "
        return prefix, "Enter instruction to send at each heartbeat..."
    elif target_session:
        return f"[{target_session}] ", "Type instruction (Enter to send)..."
    else:
        return "[no session] ", "Type instruction (Enter to send)..."


class CommandBar(Static):
    """Inline command bar for sending instructions to agents.

    Supports single-line (Input) and multi-line (TextArea) modes.
    Toggle with Ctrl+E. Send with Enter (single) or Ctrl+S / Ctrl+Enter (multi).
    Use Ctrl+O to set as standing order instead of sending.

    Modes:
    - "send": Default mode for sending instructions to an agent
    - "standing_orders": Mode for editing standing orders for an agent
    - "new_agent_dir": First step of new agent creation - enter working directory
    - "new_agent_name": Second step of new agent creation - enter agent name
    - "new_agent_perms": Third step of new agent creation - choose permission mode

    Key handling is done via on_key() since Input/TextArea consume most keys.
    """

    expanded = reactive(False)  # Toggle single/multi-line mode
    target_session: Optional[str] = None
    target_session_id: Optional[str] = None
    mode: str = "send"  # "send", "standing_orders", "new_agent_*", "heartbeat_freq", "heartbeat_instruction", etc.
    new_agent_dir: Optional[str] = None  # Store directory between steps
    new_agent_name: Optional[str] = None  # Store name between steps
    new_agent_bypass: bool = False  # Store permissions between steps
    new_agent_teams: bool = False  # Store teams flag between steps (#309)
    new_agent_claude_agent: Optional[str] = None  # Store selected Claude agent between steps
    heartbeat_freq: Optional[int] = None  # Store frequency between heartbeat steps (#171)
    new_remote_sister: Optional[str] = None  # Store selected sister name for remote agent flow (#310)

    class SendRequested(Message):
        """Message sent when user wants to send text to a session."""
        def __init__(self, session_name: str, text: str, session_id: str = ""):
            super().__init__()
            self.session_name = session_name
            self.text = text
            self.session_id = session_id

    class StandingOrderRequested(Message):
        """Message sent when user wants to set a standing order."""
        def __init__(self, session_name: str, text: str, session_id: str = ""):
            super().__init__()
            self.session_name = session_name
            self.text = text
            self.session_id = session_id

    class NewAgentRequested(Message):
        """Message sent when user wants to create a new agent."""
        def __init__(self, agent_name: str, directory: Optional[str] = None, bypass_permissions: bool = False, agent_teams: bool = False, claude_agent: Optional[str] = None):
            super().__init__()
            self.agent_name = agent_name
            self.directory = directory
            self.bypass_permissions = bypass_permissions
            self.agent_teams = agent_teams
            self.claude_agent = claude_agent

    class NewRemoteAgentRequested(Message):
        """Message sent when user wants to launch a remote agent on a sister (#310)."""
        def __init__(self, sister_name: str, agent_name: str, directory: Optional[str] = None, permissions: str = "normal"):
            super().__init__()
            self.sister_name = sister_name
            self.agent_name = agent_name
            self.directory = directory
            self.permissions = permissions

    class ValueUpdated(Message):
        """Message sent when user updates agent value (#61)."""
        def __init__(self, session_name: str, value: int, session_id: str = ""):
            super().__init__()
            self.session_name = session_name
            self.value = value
            self.session_id = session_id

    class AnnotationUpdated(Message):
        """Message sent when user updates human annotation (#74)."""
        def __init__(self, session_name: str, annotation: str, session_id: str = ""):
            super().__init__()
            self.session_name = session_name
            self.annotation = annotation
            self.session_id = session_id

    class HeartbeatUpdated(Message):
        """Message sent when user configures heartbeat (#171)."""
        def __init__(self, session_name: str, enabled: bool, frequency: int, instruction: str, session_id: str = ""):
            super().__init__()
            self.session_name = session_name
            self.enabled = enabled
            self.frequency = frequency
            self.instruction = instruction
            self.session_id = session_id

    class BudgetUpdated(Message):
        """Message sent when user updates cost budget (#173)."""
        def __init__(self, session_name: str, budget_usd: float, session_id: str = ""):
            super().__init__()
            self.session_name = session_name
            self.budget_usd = budget_usd
            self.session_id = session_id

    class ClearRequested(Message):
        """Message sent when user clears the command bar."""
        pass

    def compose(self) -> ComposeResult:
        """Create command bar widgets."""
        with Horizontal(id="cmd-bar-container"):
            yield Label("", id="target-label")
            yield Input(id="cmd-input", placeholder="Type instruction (Enter to send)...", disabled=True)
            yield TextArea(id="cmd-textarea", classes="hidden", disabled=True)
            yield Label("[^E]", id="expand-hint")

    def on_mount(self) -> None:
        """Initialize command bar state."""
        self._update_target_label()
        # Ensure widgets start disabled to prevent auto-focus
        self.query_one("#cmd-input", Input).disabled = True
        self.query_one("#cmd-textarea", TextArea).disabled = True

    def _update_target_label(self) -> None:
        """Update the target session label based on mode."""
        label = self.query_one("#target-label", Label)
        input_widget = self.query_one("#cmd-input", Input)
        label_text, placeholder = get_mode_label_and_placeholder(self.mode, self.target_session)
        label.update(label_text)
        input_widget.placeholder = placeholder

    def set_target(self, session_name: Optional[str], session_id: Optional[str] = None) -> None:
        """Set the target session for commands."""
        self.target_session = session_name
        self.target_session_id = session_id
        self.mode = "send"  # Reset to send mode when target changes
        self._update_target_label()

    def set_mode(self, mode: str) -> None:
        """Set the command bar mode ('send' or 'new_agent')."""
        self.mode = mode
        self._update_target_label()

    def watch_expanded(self, expanded: bool) -> None:
        """Toggle between single-line and multi-line mode."""
        input_widget = self.query_one("#cmd-input", Input)
        textarea = self.query_one("#cmd-textarea", TextArea)

        if expanded:
            # Switch to multi-line
            input_widget.add_class("hidden")
            input_widget.disabled = True
            textarea.remove_class("hidden")
            textarea.disabled = False
            # Transfer content
            textarea.text = input_widget.value
            input_widget.value = ""
            textarea.focus()
        else:
            # Switch to single-line
            textarea.add_class("hidden")
            textarea.disabled = True
            input_widget.remove_class("hidden")
            input_widget.disabled = False
            # Transfer content (first line only for single-line)
            if textarea.text:
                first_line = textarea.text.split('\n')[0]
                input_widget.value = first_line
            textarea.text = ""
            input_widget.focus()

    def on_key(self, event: events.Key) -> None:
        """Handle key events for command bar shortcuts."""
        if event.key == "ctrl+e":
            self.action_toggle_expand()
            event.stop()
        elif event.key == "ctrl+o":
            self.action_set_standing_order()
            event.stop()
        elif event.key == "escape":
            self.action_clear_and_unfocus()
            event.stop()
        elif event.key in ("ctrl+enter", "ctrl+s") and self.expanded:
            self.action_send_multiline()
            event.stop()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle Enter in single-line mode."""
        if event.input.id == "cmd-input":
            text = event.value.strip()

            if self.mode == "new_remote_agent_sister":
                self._handle_remote_agent_sister(text)
                return
            elif self.mode == "new_remote_agent_dir":
                self._handle_remote_agent_dir(text)
                return
            elif self.mode == "new_remote_agent_name":
                self._handle_remote_agent_name(text)
                event.input.value = ""
                return
            elif self.mode == "new_remote_agent_perms":
                self._handle_remote_agent_perms(text)
                event.input.value = ""
                self.action_clear_and_unfocus()
                return
            elif self.mode == "new_agent_dir":
                # Step 1: Directory entered, validate and move to name step
                # Note: _handle_new_agent_dir sets input value to default name, don't clear it
                self._handle_new_agent_dir(text if text else None)
                return
            elif self.mode == "new_agent_name":
                # Step 2: Name entered (or default accepted), move to permissions step
                # If empty, use the pre-filled default
                name = text if text else event.input.value.strip()
                if not name:
                    # Derive from directory as fallback
                    from pathlib import Path
                    name = Path(self.new_agent_dir).name if self.new_agent_dir else "agent"
                self._handle_new_agent_name(name)
                event.input.value = ""
                return
            elif self.mode == "new_agent_perms":
                # Step 3: Permissions chosen, transition to teams step
                self.new_agent_bypass = text.lower().strip() in ("bypass", "y", "yes", "!")
                self._handle_new_agent_perms()
                event.input.value = ""
                return
            elif self.mode == "new_agent_teams":
                # Step 4: Teams chosen, create agent
                teams = text.lower().strip() in ("yes", "y", "true", "1", "teams")
                self._create_new_agent(self.new_agent_name, self.new_agent_bypass, teams)
                event.input.value = ""
                self.action_clear_and_unfocus()
                return
            elif self.mode == "standing_orders":
                # Set standing orders (empty string clears them)
                self._set_standing_order(text)
                event.input.value = ""
                self.action_clear_and_unfocus()
                return
            elif self.mode == "value":
                # Set agent value (#61)
                self._set_value(text)
                event.input.value = ""
                self.action_clear_and_unfocus()
                return
            elif self.mode == "cost_budget":
                # Set cost budget (#173)
                self._set_cost_budget(text)
                event.input.value = ""
                self.action_clear_and_unfocus()
                return
            elif self.mode == "annotation":
                # Set human annotation (empty string clears it)
                self._set_annotation(text)
                event.input.value = ""
                self.action_clear_and_unfocus()
                return
            elif self.mode == "heartbeat_freq":
                # Handle frequency input for heartbeat configuration (#171)
                self._handle_heartbeat_freq(text)
                event.input.value = ""
                return
            elif self.mode == "heartbeat_instruction":
                # Handle instruction input for heartbeat configuration (#171)
                self._handle_heartbeat_instruction(text)
                event.input.value = ""
                self.action_clear_and_unfocus()
                return

            # Default "send" mode
            if not text:
                return
            self._send_message(text)
            event.input.value = ""
            self.action_clear_and_unfocus()

    def _send_message(self, text: str) -> None:
        """Send message to target session."""
        if not self.target_session or not text.strip():
            return
        self.post_message(self.SendRequested(self.target_session, text.strip(), session_id=self.target_session_id or ""))

    def _handle_new_agent_dir(self, directory: Optional[str]) -> None:
        """Handle directory input for new agent creation.

        Validates directory and transitions to name input step.
        """
        from pathlib import Path

        # Expand ~ and resolve path
        if directory:
            dir_path = Path(directory).expanduser().resolve()
            if not dir_path.exists():
                # Create the directory
                try:
                    dir_path.mkdir(parents=True, exist_ok=True)
                    self.app.notify(f"Created directory: {dir_path}", severity="information")
                except OSError as e:
                    self.app.notify(f"Failed to create directory: {e}", severity="error")
                    return
            if not dir_path.is_dir():
                self.app.notify(f"Not a directory: {dir_path}", severity="error")
                return
            self.new_agent_dir = str(dir_path)
        else:
            # Use current working directory if none specified
            self.new_agent_dir = str(Path.cwd())

        # Check for available Claude agents
        from ..agent_scanner import scan_agents
        agents = scan_agents(self.new_agent_dir)

        if agents:
            # Show agent selection modal (TUI will handle the message and
            # transition us to name step afterwards)
            from .agent_select_modal import AgentSelectModal
            try:
                modal = self.app.query_one("#agent-select-modal", AgentSelectModal)
                modal.show(agents, self.app)
            except Exception:
                # Modal not found — fall through to name step
                self._transition_to_name_step()
        else:
            # No agents found — skip straight to name step
            self._transition_to_name_step()

    def _transition_to_name_step(self) -> None:
        """Transition to the name input step of new agent creation."""
        from pathlib import Path

        # Derive default agent name from directory basename (#131)
        # If an agent with that name exists, increment (foo -> foo2 -> foo3)
        base_name = Path(self.new_agent_dir).name
        default_name = self._get_unique_agent_name(base_name)

        # Transition to name step
        self.mode = "new_agent_name"
        self._update_target_label()

        # Pre-fill the input with the default name
        input_widget = self.query_one("#cmd-input", Input)
        input_widget.value = default_name

    def _get_unique_agent_name(self, base_name: str) -> str:
        """Get a unique agent name by incrementing suffix if needed (#131).

        Args:
            base_name: The base name to start with (e.g., directory name)

        Returns:
            A unique name: base_name if available, else base_name2, base_name3, etc.
        """
        # Check if base name is available
        if not self.app.session_manager.get_session_by_name(base_name):
            return base_name

        # Try incrementing suffix until we find an unused name
        suffix = 2
        while suffix < 100:  # Reasonable limit
            candidate = f"{base_name}{suffix}"
            if not self.app.session_manager.get_session_by_name(candidate):
                return candidate
            suffix += 1

        # Fallback (very unlikely to reach)
        return f"{base_name}_{suffix}"

    def _handle_new_agent_name(self, name: str) -> None:
        """Handle name input for new agent creation.

        Stores the name and transitions to permissions step.
        Pre-fills bypass from config defaults.
        """
        self.new_agent_name = name

        # Transition to permissions step
        self.mode = "new_agent_perms"
        self._update_target_label()

        # Pre-fill from config defaults
        from ..config import get_new_agent_defaults
        defaults = get_new_agent_defaults()
        if defaults.get("bypass_permissions", False):
            input_widget = self.query_one("#cmd-input", Input)
            input_widget.value = "bypass"

    def _handle_new_agent_perms(self) -> None:
        """Handle permissions input for new agent creation.

        Stores the bypass flag and transitions to teams step.
        Pre-fills teams from config defaults.
        """
        from ..config import get_new_agent_defaults
        defaults = get_new_agent_defaults()
        self.new_agent_teams = defaults.get("agent_teams", False)

        self.mode = "new_agent_teams"
        self._update_target_label()

        # Pre-fill with current default
        if self.new_agent_teams:
            input_widget = self.query_one("#cmd-input", Input)
            input_widget.value = "yes"

    def _create_new_agent(self, name: str, bypass_permissions: bool = False, agent_teams: bool = False) -> None:
        """Create a new agent with the given name, directory, permission mode, and teams flag."""
        self.post_message(self.NewAgentRequested(name, self.new_agent_dir, bypass_permissions, agent_teams, claude_agent=self.new_agent_claude_agent))
        # Reset state
        self.new_agent_dir = None
        self.new_agent_name = None
        self.new_agent_bypass = False
        self.new_agent_teams = False
        self.new_agent_claude_agent = None
        self.mode = "send"
        self._update_target_label()

    # --- Remote agent flow (#310) ---

    def _handle_remote_agent_sister(self, text: str) -> None:
        """Handle sister name input for remote agent creation."""
        if not text:
            self.app.notify("Sister name required", severity="error")
            return

        from overcode.config import get_sister_by_name
        sister = get_sister_by_name(text)
        if not sister:
            from overcode.config import get_sisters_config
            available = [s["name"] for s in get_sisters_config()]
            if available:
                self.app.notify(f"Sister '{text}' not found. Available: {', '.join(available)}", severity="error")
            else:
                self.app.notify("No sisters configured", severity="error")
            return

        self.new_remote_sister = text
        self.mode = "new_remote_agent_dir"
        self._update_target_label()
        input_widget = self.query_one("#cmd-input", Input)
        input_widget.value = "."

    def _handle_remote_agent_dir(self, text: str) -> None:
        """Handle directory input for remote agent creation."""
        self.new_agent_dir = text if text else "."
        self.mode = "new_remote_agent_name"
        self._update_target_label()

    def _handle_remote_agent_name(self, name: str) -> None:
        """Handle name input for remote agent creation."""
        if not name:
            self.app.notify("Agent name required", severity="error")
            return
        self.new_agent_name = name
        self.mode = "new_remote_agent_perms"
        self._update_target_label()

    def _handle_remote_agent_perms(self, text: str) -> None:
        """Handle permissions input and post remote agent message."""
        perms = text.lower().strip()
        if perms in ("bypass", "!"):
            permissions = "bypass"
        elif perms in ("skip", "deny"):
            permissions = "skip"
        else:
            permissions = "normal"

        self.post_message(self.NewRemoteAgentRequested(
            sister_name=self.new_remote_sister,
            agent_name=self.new_agent_name,
            directory=self.new_agent_dir,
            permissions=permissions,
        ))
        # Reset state
        self.new_remote_sister = None
        self.new_agent_dir = None
        self.new_agent_name = None
        self.mode = "send"
        self._update_target_label()

    def _set_standing_order(self, text: str) -> None:
        """Set text as standing order (empty string clears orders)."""
        if not self.target_session:
            return
        self.post_message(self.StandingOrderRequested(self.target_session, text.strip(), session_id=self.target_session_id or ""))

    def _set_value(self, text: str) -> None:
        """Set agent value (#61)."""
        if not self.target_session:
            return
        try:
            value = int(text.strip()) if text.strip() else 1000
            if value < 0 or value > 9999:
                self.app.notify("Value must be between 0 and 9999", severity="error")
                return
            self.post_message(self.ValueUpdated(self.target_session, value, session_id=self.target_session_id or ""))
        except ValueError:
            # Invalid input, notify user but don't crash
            self.app.notify("Invalid value - please enter a number", severity="error")

    def _set_cost_budget(self, text: str) -> None:
        """Set cost budget (#173)."""
        if not self.target_session:
            return
        try:
            cleaned = text.strip().lstrip('$')
            budget = float(cleaned) if cleaned else 0.0
            if budget < 0:
                self.app.notify("Budget cannot be negative", severity="error")
                return
            self.post_message(self.BudgetUpdated(self.target_session, budget, session_id=self.target_session_id or ""))
        except ValueError:
            self.app.notify("Invalid budget - enter a dollar amount (e.g., 5.00)", severity="error")

    def _set_annotation(self, text: str) -> None:
        """Set human annotation (empty string clears it) (#74)."""
        if not self.target_session:
            return
        self.post_message(self.AnnotationUpdated(self.target_session, text.strip(), session_id=self.target_session_id or ""))

    def action_toggle_expand(self) -> None:
        """Toggle between single and multi-line mode."""
        self.expanded = not self.expanded

    def action_send_multiline(self) -> None:
        """Send content from multi-line textarea."""
        textarea = self.query_one("#cmd-textarea", TextArea)
        self._send_message(textarea.text)
        textarea.text = ""
        self.action_clear_and_unfocus()

    def action_set_standing_order(self) -> None:
        """Set current content as standing order."""
        if self.expanded:
            textarea = self.query_one("#cmd-textarea", TextArea)
            self._set_standing_order(textarea.text)
            textarea.text = ""
        else:
            input_widget = self.query_one("#cmd-input", Input)
            self._set_standing_order(input_widget.value)
            input_widget.value = ""

    def action_clear_and_unfocus(self) -> None:
        """Clear input and unfocus command bar."""
        if self.expanded:
            textarea = self.query_one("#cmd-textarea", TextArea)
            textarea.text = ""
            self.expanded = False  # Reset to single-line mode
        else:
            input_widget = self.query_one("#cmd-input", Input)
            input_widget.value = ""
        # Reset mode and state
        self.mode = "send"
        self.new_agent_dir = None
        self.new_agent_name = None
        self.new_agent_bypass = False
        self.new_agent_teams = False
        self.new_agent_claude_agent = None
        self.new_remote_sister = None  # Reset remote agent state (#310)
        self.heartbeat_freq = None  # Reset heartbeat state (#171)
        self._update_target_label()
        # Let parent handle unfocus
        self.post_message(self.ClearRequested())

    def focus_input(self) -> None:
        """Focus the command bar input and enable it."""
        input_widget = self.query_one("#cmd-input", Input)
        input_widget.disabled = False
        input_widget.focus()

    def _find_target_session(self):
        """Find the target session by ID from the app's session list."""
        if not self.target_session_id:
            return None
        for s in self.app.sessions:
            if s.id == self.target_session_id:
                return s
        return None

    def _parse_duration(self, text: str) -> Optional[int]:
        """Parse duration string like '5m', '1h', '300' into seconds (#171)."""
        text = text.strip().lower()
        if not text:
            return None
        try:
            if text.endswith('s'):
                return int(text[:-1])
            elif text.endswith('m'):
                return int(text[:-1]) * 60
            elif text.endswith('h'):
                return int(text[:-1]) * 3600
            else:
                return int(text)
        except ValueError:
            return None

    def _handle_heartbeat_freq(self, text: str) -> None:
        """Handle frequency input for heartbeat configuration (#171)."""
        if not text.strip() or text.lower().strip() in ('off', 'disable', '0', 'no', 'false'):
            # Disable heartbeat
            if self.target_session:
                self.post_message(self.HeartbeatUpdated(
                    self.target_session, enabled=False, frequency=0, instruction="",
                    session_id=self.target_session_id or "",
                ))
            self.action_clear_and_unfocus()
            return

        freq = self._parse_duration(text)
        if freq is None:
            self.app.notify("Invalid format. Use: 300, 5m, or 1h", severity="error")
            return
        if freq < 30:
            self.app.notify("Minimum heartbeat interval is 30 seconds", severity="error")
            return

        self.heartbeat_freq = freq
        self.mode = "heartbeat_instruction"
        self._update_target_label()

        # Pre-fill with existing heartbeat instruction if available
        if self.target_session:
            session = self._find_target_session()
            if session and session.heartbeat_instruction:
                input_widget = self.query_one("#cmd-input", Input)
                input_widget.value = session.heartbeat_instruction

    def _handle_heartbeat_instruction(self, text: str) -> None:
        """Handle instruction input for heartbeat configuration (#171)."""
        if not self.target_session:
            return

        instruction = text.strip()
        # If empty, keep the existing instruction (user just hit Enter to confirm)
        if not instruction:
            session = self._find_target_session()
            if session and session.heartbeat_instruction:
                instruction = session.heartbeat_instruction
            else:
                self.app.notify("Heartbeat instruction cannot be empty", severity="error")
                return

        self.post_message(self.HeartbeatUpdated(
            self.target_session,
            enabled=True,
            frequency=self.heartbeat_freq or 300,
            instruction=instruction,
            session_id=self.target_session_id or "",
        ))
        self.heartbeat_freq = None
