.. _examples-cpymemtrace:

:py:mod:`pymemtrace.cPyMemTrace` Examples
===============================================

Introduction
--------------------------------

:py:mod:`pymemtrace.cPyMemTrace` is a Python profiler written in 'C' that records the
`Resident Set Size <https://en.wikipedia.org/wiki/Resident_set_size>`_ for every Python and C call and return.
It writes this data to a log file with a name of the form ``"20241107_195847_12_62264_P_0_PY3.13.0b3.log"``.
See :ref:`tech_notes-cpymemtrace_profile_trace_log_file_format` for the format.

Python supports several similar ways of tracking code:

- A *Profiler* that is suitable for logging Python and C code.
  This ignores Python line, opcode and exception events.
  This is supported by the :py:class:`pymemtrace.cPyMemTrace.Profile` class.
- A *Tracer* that is suitable for logging pure Python code.
  It ignores C call, and return events.
  This is supported by the :py:class:`pymemtrace.cPyMemTrace.Trace` class.
- A *Reference Tracer* tracks every Python allocation and de-allocation.
  This is supported by the :py:class:`pymemtrace.cPyMemTrace.ReferenceTracing` class.
  This is available in Python 3.13+.

The events that the :py:class:`pymemtrace.cPyMemTrace.Profile` and
:py:class:`pymemtrace.cPyMemTrace.Trace` respond to are:

.. list-table:: **Python Profile/Trace Events**
   :widths: 40 60 15 15 15
   :header-rows: 1

   * - Event
     - Description
     - Profile?
     - Trace?
     - Log
   * - `PyTrace_CALL <https://docs.python.org/3/c-api/profiling.html#c.PyTrace_CALL>`_
     - Call to a Python function.
     - Yes
     - Yes
     - ``CALL``
   * - `PyTrace_EXCEPTION <https://docs.python.org/3/c-api/profiling.html#c.PyTrace_EXCEPTION>`_
     - When raising a Python exception.
     - No
     - Yes
     - ``EXCEPT``
   * - `PyTrace_LINE <https://docs.python.org/3/c-api/profiling.html#c.PyTrace_LINE>`_
     - When processing a Python line.
     - No
     - Yes
     - ``LINE``
   * - `PyTrace_RETURN <https://docs.python.org/3/c-api/profiling.html#c.PyTrace_RETURN>`_
     - When the code is about to return from a Python function.
     - Yes
     - Yes
     - ``RETURN``
   * - `PyTrace_C_CALL <https://docs.python.org/3/c-api/profiling.html#c.PyTrace_C_CALL>`_
     - Call to a C function.
     - Yes
     - No
     - ``C_CALL``
   * - `PyTrace_C_EXCEPTION <https://docs.python.org/3/c-api/profiling.html#c.PyTrace_C_EXCEPTION>`_
     - When raising a Python exception from C code.
     - Yes
     - No
     - ``C_EXCEPT``
   * - `PyTrace_C_RETURN <https://docs.python.org/3/c-api/profiling.html#c.PyTrace_C_RETURN>`_
     - When the code is about to return from a C function.
     - Yes
     - No
     - ``C_RETURN``
   * - `PyTrace_OPCODE <https://docs.python.org/3/c-api/profiling.html#c.PyTrace_OPCODE>`_
     - When a new opcode is about to be executed.
     - No
     - Yes
     - ``OPCODE``

:py:class:`pymemtrace.cPyMemTrace.ReferenceTracing` responds to every object allocation and de-allocation events.

Logging Changes in RSS
--------------------------------

Here is a simple example using :py:class:`pymemtrace.cPyMemTrace.Profile`:

.. code-block:: python

    from pymemtrace import cPyMemTrace

    def new_str(l: int) -> str:
        return ' ' * l

    with cPyMemTrace.Profile():
        l = []
        for i in range(8):
            l.append(new_str(1024**2))
        while len(l):
            l.pop()

This produces a log file in the current working directory such as:

.. code-block:: text

          Event dEvent  Clock        What     File    #line Function     RSS         dRSS
    NEXT: 0     +0      0.066718     CALL     test.py #   9 new_str  9101312      9101312
    NEXT: 1     +1      0.067265     RETURN   test.py #  10 new_str 10153984      1052672
    PREV: 4     +3      0.067285     CALL     test.py #   9 new_str 10153984            0
    NEXT: 5     +4      0.067777     RETURN   test.py #  10 new_str 11206656      1052672
    PREV: 8     +3      0.067787     CALL     test.py #   9 new_str 11206656            0
    NEXT: 9     +4      0.068356     RETURN   test.py #  10 new_str 12259328      1052672
    PREV: 12    +3      0.068367     CALL     test.py #   9 new_str 12259328            0
    NEXT: 13    +4      0.068944     RETURN   test.py #  10 new_str 13312000      1052672
    PREV: 16    +3      0.068954     CALL     test.py #   9 new_str 13312000            0
    NEXT: 17    +4      0.069518     RETURN   test.py #  10 new_str 14364672      1052672
    PREV: 20    +3      0.069534     CALL     test.py #   9 new_str 14364672            0
    NEXT: 21    +4      0.070101     RETURN   test.py #  10 new_str 15417344      1052672
    PREV: 24    +3      0.070120     CALL     test.py #   9 new_str 15417344            0
    NEXT: 25    +4      0.070663     RETURN   test.py #  10 new_str 16470016      1052672
    PREV: 28    +3      0.070677     CALL     test.py #   9 new_str 16470016            0
    NEXT: 29    +4      0.071211     RETURN   test.py #  10 new_str 17522688      1052672

By default not all events are recorded just any that increase the RSS by one page along with the immediately preceding event.

Logging Every Event
--------------------------------

If all events are needed then change the constructor argument to 0:

.. code-block:: python

    with cPyMemTrace.Profile(0):
        # As before

And the log file looks like this:

.. code-block:: text

          Event dEvent  Clock        What     File    #line Function     RSS         dRSS
    NEXT: 0     +0      0.079408     CALL     test.py #   9 new_str  9105408      9105408
    NEXT: 1     +1      0.079987     RETURN   test.py #  10 new_str 10158080      1052672
    NEXT: 2     +1      0.079994     C_CALL   test.py #  64 append  10158080            0
    NEXT: 3     +1      0.079998     C_RETURN test.py #  64 append  10158080            0
    NEXT: 4     +1      0.080003     CALL     test.py #   9 new_str 10158080            0
    NEXT: 5     +1      0.080682     RETURN   test.py #  10 new_str 11210752      1052672
    NEXT: 6     +1      0.080693     C_CALL   test.py #  64 append  11210752            0
    NEXT: 7     +1      0.080698     C_RETURN test.py #  64 append  11210752            0
    NEXT: 8     +1      0.080704     CALL     test.py #   9 new_str 11210752            0
    NEXT: 9     +1      0.081414     RETURN   test.py #  10 new_str 12263424      1052672
    NEXT: 10    +1      0.081424     C_CALL   test.py #  64 append  12263424            0
    NEXT: 11    +1      0.081429     C_RETURN test.py #  64 append  12263424            0
    NEXT: 12    +1      0.081434     CALL     test.py #   9 new_str 12263424            0
    NEXT: 13    +1      0.081993     RETURN   test.py #  10 new_str 13316096      1052672
    NEXT: 14    +1      0.081998     C_CALL   test.py #  64 append  13316096            0
    ...
    NEXT: 59    +1      0.084531     C_RETURN test.py #  66 pop     17526784            0
    NEXT: 60    +1      0.084535     C_CALL   test.py #  65 len     17526784            0
    NEXT: 61    +1      0.084539     C_RETURN test.py #  65 len     17526784            0
    NEXT: 62    +1      0.084541     C_CALL   test.py #  66 pop     17526784            0
    NEXT: 63    +1      0.084561     C_RETURN test.py #  66 pop     17526784            0
    NEXT: 64    +1      0.084566     C_CALL   test.py #  65 len     17526784            0
    NEXT: 65    +1      0.084568     C_RETURN test.py #  65 len     17526784            0

There is some discussion about the performance of :py:mod:`pymemtrace.cPyMemTrace` here :ref:`tech_notes-cpymemtrace`

Reference Tracing
-----------------

From Python 3.13 onwards Python supports
`Reference Tracing <https://docs.python.org/3/c-api/profiling.html#reference-tracing>`_.
This enables us to track every Python allocation and de-allocation.
The class that does this is :py:class:`cPyMemTrace.ReferenceTracing`.

Here we create an example class that just allocates memory:

.. code-block:: python

    class BytesWrapper:
        def __init__(self, length: int):
            self.bytes = b' ' * length

Then we invoke this multiple times under the watchful eye of a :py:class:`pymemtrace.cPyMemTrace.ReferenceTracing`
context manger:

.. code-block:: python

    from pymemtrace import cPyMemTrace

    def make_bytes_wrappers() -> str:
        with cPyMemTrace.ReferenceTracing() as profiler:
            l = []
            for i in range(4):
                length = random.randint(512, 1024) + 1024 ** 2
                l.append(BytesWrapper(length))
                time.sleep(0.25)
            while len(l):
                p = l.pop()
                del p
                time.sleep(0.25)
            return profiler.log_file_path()

Example
^^^^^^^

The log file wil look like this (abridged).

..

    .. raw:: latex

        [Continued on the next page]

        \pagebreak

.. raw:: latex

    \begin{landscape}

.. code-block:: text

    SOF
    HDR:        Clock          Address RefCnt Type                             File                                            Line Function                                              RSS             dRSS
    DEL:     0.816121   0x60000670f980      0 builtin_function_or_method       pymemtrace/tests/test_cpymemtrace.py             292 make_bytes_wrappers                              38207488         38207488
    NEW:     0.816183   0x6000025fde70      1 list                             pymemtrace/tests/test_cpymemtrace.py             293 make_bytes_wrappers                              38207488                0
    NEW:     0.816203   0x6000025ec6a0      1 range                            pymemtrace/tests/test_cpymemtrace.py             294 make_bytes_wrappers                              38207488                0
    NEW:     0.816218   0x60000169c210      1 range_iterator                   pymemtrace/tests/test_cpymemtrace.py             294 make_bytes_wrappers                              38207488                0
    DEL:     0.816229   0x6000025ec6a0      0 range                            pymemtrace/tests/test_cpymemtrace.py             294 make_bytes_wrappers                              38207488                0
    8<---- Snip ---->8
    NEW:     0.816531   0x7fa81fbf2a00      1 BytesWrapper                     pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    NEW:     0.816590   0x7fa823903010      1 bytes                            pymemtrace/tests/test_cpymemtrace.py             288 __init__                                         38207488                0
    DEL:     0.816634   0x60000385cf90      0 frame                            pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    DEL:     0.816645   0x6000025e34a0      0 tuple                            pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    8<---- Snip ---->8
    NEW:     0.817109   0x7fa81e7aa280      1 BytesWrapper                     pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    NEW:     0.817162   0x7fa823600010      1 bytes                            pymemtrace/tests/test_cpymemtrace.py             288 __init__                                         38207488                0
    DEL:     0.817203   0x6000038593a0      0 frame                            pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    NEW:     0.817250   0x60000169c110      1 int                              Python-3.13.2/Lib/random.py                      340 randint                                          38207488                0
    8<---- Snip ---->8
    DEL:     0.817495   0x60000168b350      0 int                              pymemtrace/tests/test_cpymemtrace.py             295 make_bytes_wrappers                              38207488                0
    NEW:     0.817513   0x7fa82347c940      1 BytesWrapper                     pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    NEW:     0.817602   0x7fa823701010      1 bytes                            pymemtrace/tests/test_cpymemtrace.py             288 __init__                                         38207488                0
    DEL:     0.817675   0x600003849540      0 frame                            pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    NEW:     0.817762   0x600001694d90      1 int                              Python-3.13.2/Lib/random.py                      340 randint                                          38207488                0
    NEW:     0.817885   0x600001694c90      1 int                              Python-3.13.2/Lib/random.py                      317 randrange                                        38207488                0
    8<---- Snip ---->8
    DEL:     0.818299   0x60000169c510      0 int                              pymemtrace/tests/test_cpymemtrace.py             295 make_bytes_wrappers                              38207488                0
    NEW:     0.818333   0x7fa81fafbe60      1 BytesWrapper                     pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    NEW:     0.818525   0x7fa823802010      1 bytes                            pymemtrace/tests/test_cpymemtrace.py             288 __init__                                         38207488                0
    DEL:     0.818701   0x6000038409e0      0 frame                            pymemtrace/tests/test_cpymemtrace.py             296 make_bytes_wrappers                              38207488                0
    DEL:     0.818776   0x60000169c210      0 range_iterator                   pymemtrace/tests/test_cpymemtrace.py             294 make_bytes_wrappers                              38207488                0
    DEL:     0.818860   0x7fa81fafbe60      0 BytesWrapper                     pymemtrace/tests/test_cpymemtrace.py             300 make_bytes_wrappers                              38207488                0
    DEL:     0.818875   0x7fa823802010      0 bytes                            pymemtrace/tests/test_cpymemtrace.py             300 make_bytes_wrappers                              38207488                0
    DEL:     0.819012   0x7fa82347c940      0 BytesWrapper                     pymemtrace/tests/test_cpymemtrace.py             300 make_bytes_wrappers                              38207488                0
    DEL:     0.819128   0x7fa823701010      0 bytes                            pymemtrace/tests/test_cpymemtrace.py             300 make_bytes_wrappers                              38207488                0
    DEL:     0.819370   0x7fa81e7aa280      0 BytesWrapper                     pymemtrace/tests/test_cpymemtrace.py             300 make_bytes_wrappers                              38207488                0
    DEL:     0.819447   0x7fa823600010      0 bytes                            pymemtrace/tests/test_cpymemtrace.py             300 make_bytes_wrappers                              38207488                0
    DEL:     0.819582   0x7fa81fbf2a00      0 BytesWrapper                     pymemtrace/tests/test_cpymemtrace.py             300 make_bytes_wrappers                              38207488                0
    DEL:     0.819648   0x7fa823903010      0 bytes                            pymemtrace/tests/test_cpymemtrace.py             300 make_bytes_wrappers                              38207488                0
    NEW:     0.820073   0x600003236b30      1 str                              pymemtrace/tests/test_cpymemtrace.py             304 make_bytes_wrappers                              38211584             4096
    NEW:     0.820357   0x6000067033e0      1 tuple                            pymemtrace/tests/test_cpymemtrace.py             292 make_bytes_wrappers                              38211584                0
    EOF

.. raw:: latex

    \end{landscape}

The file format is described here :ref:`tech_notes-cpymemtrace_reference_tracing_log_file_format`.


Analysing the Log With ``ref_trace_analyse.py``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This log file can be very large so to help understand it there is a script
:py:mod:`pymemtrace.util.ref_trace_analyse` that can analyse it.

This performs the following analysis:

- If an object is deleted but hasn't been created in the log file a warning is issued.
  These are not significant as they refer to objects created before the log file was started.
- Any objects that were created within the log run but not de-allocated are listed
  along with the function, file, and line where it was created.
- Any objects that were created and deleted within the log run are listed.
- A count of objects created and deleted by object type.

For example the output will be something like:

..

    .. raw:: latex

        [Continued on the next page]

        \pagebreak

.. raw:: latex

    \begin{landscape}


.. code-block:: text

    2026-03-18 11:51:12,278 - ref_trace_analyse.py#107 - WARNING  - DEL: on untracked object of type "builtin_function_or_method" at 0x60000670f980 on line 3
    2026-03-18 11:51:12,278 - ref_trace_analyse.py#107 - WARNING  - DEL: on untracked object of type "frame" at 0x600007cc44d0 on line 13
    2026-03-18 11:51:12,278 - ref_trace_analyse.py#107 - WARNING  - DEL: on untracked object of type "frame" at 0x7fa82347c930 on line 16
    8<---- Snip ---->8
    2026-03-18 11:51:12,280 - ref_trace_analyse.py#107 - WARNING  - DEL: on untracked object of type "frame" at 0x6000038409e0 on line 78
    Live Objects [4]:
        0x600001694c90    1 int                                      make_bytes_wrappers              test_cpymemtrace.py#295
        0x6000025fde70    1 list                                     make_bytes_wrappers              test_cpymemtrace.py#293
        0x600003236b30    1 str                                      make_bytes_wrappers              test_cpymemtrace.py#304
        0x6000067033e0    1 tuple                                    make_bytes_wrappers              test_cpymemtrace.py#292
    Previous Objects [26]:
        0x60000168b0d0 int                                      NEW: random.py#340 DEL: random.py#340
        0x60000168b190 int                                      NEW: random.py#322 DEL: test_cpymemtrace.py#295
        0x60000168b2d0 int                                      NEW: random.py#250 DEL: random.py#322
    8<---- Snip ---->8
        0x6000025e34a0 tuple                                    NEW: test_cpymemtrace.py#296 DEL: test_cpymemtrace.py#296
        0x6000025ec6a0 range                                    NEW: test_cpymemtrace.py#294 DEL: test_cpymemtrace.py#294
        0x6000067035c0 builtin_function_or_method               NEW: random.py#248 DEL: random.py#322
        0x600006709760 builtin_function_or_method               NEW: random.py#248 DEL: random.py#322
        0x60000670f980 builtin_function_or_method               NEW: random.py#248 DEL: random.py#322
        0x60000670f980 builtin_function_or_method               NEW: random.py#248 DEL: random.py#322
        0x7fa81e7aa280 BytesWrapper                             NEW: test_cpymemtrace.py#296 DEL: test_cpymemtrace.py#300
        0x7fa81fafbe60 BytesWrapper                             NEW: test_cpymemtrace.py#296 DEL: test_cpymemtrace.py#300
        0x7fa81fbf2a00 BytesWrapper                             NEW: test_cpymemtrace.py#296 DEL: test_cpymemtrace.py#300
        0x7fa82347c940 BytesWrapper                             NEW: test_cpymemtrace.py#296 DEL: test_cpymemtrace.py#300
        0x7fa823600010 bytes                                    NEW: test_cpymemtrace.py#288 DEL: test_cpymemtrace.py#300
        0x7fa823701010 bytes                                    NEW: test_cpymemtrace.py#288 DEL: test_cpymemtrace.py#300
        0x7fa823802010 bytes                                    NEW: test_cpymemtrace.py#288 DEL: test_cpymemtrace.py#300
        0x7fa823903010 bytes                                    NEW: test_cpymemtrace.py#288 DEL: test_cpymemtrace.py#300
    Type count [10]:
    Type                                          New      Del  New - Del
    BytesWrapper                                    4        4          0
    builtin_function_or_method                      4        5         -1
    bytes                                           4        4          0
    frame                                           0       16        -16
    int                                            19       18          1
    list                                            1        0          1
    range                                           1        1          0
    range_iterator                                  1        1          0
    str                                             1        0          1
    tuple                                           2        1          1
    Process time: 0.004 (s)

.. raw:: latex

    \end{landscape}

Stacking Context Managers
-------------------------------

The :py:mod:`pymemtrace.cPyMemTrace` tracers :py:class:`pymemtrace.cPyMemTrace.Profile`,
:py:class:`pymemtrace.cPyMemTrace.Trace`
and :py:class:`pymemtrace.cPyMemTrace.ReferenceTracing`
context managers can be stacked.
In that case a new log file is started and the previous one is temporarily suspended.
:py:mod:`pymemtrace.cPyMemTrace` only writes to one log file at a time for each tracer.
The log file will have the stack depth in its name, starting from 0.

For example:

.. code-block:: python

    from pymemtrace import cPyMemTrace

    with cPyMemTrace.Profile():
        # Now writing to, say, "20241107_195847_11_62264_P_0_PY3.13.0b3.log"
        # Note the "_0_" in the file name.
        with cPyMemTrace.Profile():
            # Writing to "20241107_195847_12_62264_P_0_PY3.13.0b3.log" is suspended.
            # Now writing to, say, "20241107_195847_12_62264_P_1_PY3.13.0b3.log"
            # Note the "_1_" in the file name.
            pass
        # The log file "20241107_195847_12_62264_P_1_PY3.13.0b3.log" is closed.
        # Writing to "20241107_195847_11_62264_P_0_PY3.13.0b3.log" is resumed.
        pass
    # The log file "20241107_195847_11_62264_P_0_PY3.13.0b3.log" is closed.

When running all the tests example log files will be generated in the ``tests`` directory.

The module has these functions to give you the stack depth for that tracer:

- :py:meth:`pymemtrace.cPyMemTrace.profile_wrapper_depth` for the
  :py:class:`pymemtrace.cPyMemTrace.Profile` stack.
- :py:meth:`pymemtrace.cPyMemTrace.trace_wrapper_depth` for the
  :py:class:`pymemtrace.cPyMemTrace.Trace` stack.
- :py:meth:`pymemtrace.cPyMemTrace.reference_tracing_wrapper_depth` for the
  :py:class:`pymemtrace.cPyMemTrace.ReferenceTracing` stack.

For example:

.. code-block:: python

    assert cPyMemTrace.profile_wrapper_depth() == 0
    with cPyMemTrace.Profile():
        assert cPyMemTrace.profile_wrapper_depth() == 1
        with cPyMemTrace.Profile():
            assert cPyMemTrace.profile_wrapper_depth() == 2
            with cPyMemTrace.Profile():
                assert cPyMemTrace.profile_wrapper_depth() == 3
            assert cPyMemTrace.profile_wrapper_depth() == 2
        assert cPyMemTrace.profile_wrapper_depth() == 1
    assert cPyMemTrace.profile_wrapper_depth() == 0

Writing Messages to a Log File
------------------------------

To make log files more useful the user can inject messages into the log file in two ways:

- On construction of the Trace/Profile/Reference Tracing object using the ``message=<message>`` argument.
  This message will be reproduced verbatim and will be followed by a newline.
- At any time during the running of Trace/Profile/Reference Tracing object with the
  ``write_message_to_log_file()`` API.
  This message will be preceded with a ``MESG:`` or ``MSG:`` string, then the message is reproduced verbatim and
  will be followed by a newline.

.. note::

    New lines *within* messages will be respected.
    This may affect your parsing of the log file.

This example illustrates both techniques.
Firstly the code (slightly edited), here we create a profiler with a start message then allocate, then delete, a
randomly sized string of between 100 Mb and 500 Mb.
Before the allocation and after deletion we write an appropriate message to the log file.

.. code-block:: python

    with cPyMemTrace.Profile(d_rss_trigger=-1, message="Start message") as profiler:
        for i in range(8):
            str_len = random.randint(100 * 1024**2, 500 * 1024**2)
            profiler.write_message_to_log(f'Before allocation of {str_len} bytes.')
            s = ' ' * str_len
            time.sleep(0.5)
            del s
            profiler.write_message_to_log(f'After de-allocation of {str_len} bytes.')
            time.sleep(0.5)
        time.sleep(0.5)

Here is a typical log file:

.. raw:: latex

    \begin{landscape}

.. code-block:: text

    Start message
    SOF
    HEDR: Event  dEvent  Clock        What     File                           Line Function                  RSS         dRSS
    FRST: 0      +0      3.153048     LINE     test_cpymemtrace.py             201 test_messaging       41754624     41754624
    MESG: 18     +17     3.153134     Before allocation of 179379131 bytes.
    PREV: 18     +17     3.153134    
    NEXT: 19     +18     3.232753     C_CALL   test_cpymemtrace.py             206 sleep                221143040    179380224
    PREV: 19     +18     3.232753     C_CALL   test_cpymemtrace.py             206 sleep                221143040    179380224
    NEXT: 21     +2      3.249982     C_CALL   test_cpymemtrace.py             208 write_message_to_log  41762816   -179380224
    MESG: 22     +1      3.250007     After de-allocation of 179379131 bytes.
    MESG: 42     +21     3.250190     Before allocation of 198138484 bytes.
    PREV: 42     +21     3.250190    
    NEXT: 43     +22     3.344885     C_CALL   test_cpymemtrace.py             206 sleep                239902720    198139904
    PREV: 43     +22     3.344885     C_CALL   test_cpymemtrace.py             206 sleep                239902720    198139904
    NEXT: 45     +2      3.362191     C_CALL   test_cpymemtrace.py             208 write_message_to_log  41762816   -198139904
    MESG: 46     +1      3.362201     After de-allocation of 198138484 bytes.
    MESG: 66     +21     3.362277     Before allocation of 392320729 bytes.
    PREV: 66     +21     3.362277    
    NEXT: 67     +22     3.541612     C_CALL   test_cpymemtrace.py             206 sleep                434085888    392323072
    PREV: 67     +22     3.541612     C_CALL   test_cpymemtrace.py             206 sleep                434085888    392323072
    NEXT: 69     +2      3.573907     C_CALL   test_cpymemtrace.py             208 write_message_to_log  41762816   -392323072
    MESG: 70     +1      3.573918     After de-allocation of 392320729 bytes.
    MESG: 90     +21     3.574011     Before allocation of 504746338 bytes.
    PREV: 90     +21     3.574011    
    NEXT: 91     +22     3.803951     C_CALL   test_cpymemtrace.py             206 sleep                546512896    504750080
    PREV: 91     +22     3.803951     C_CALL   test_cpymemtrace.py             206 sleep                546512896    504750080
    NEXT: 93     +2      3.845491     C_CALL   test_cpymemtrace.py             208 write_message_to_log  41762816   -504750080
    MESG: 94     +1      3.845500     After de-allocation of 504746338 bytes.
    MESG: 114    +21     3.845611     Before allocation of 312965383 bytes.
    PREV: 114    +21     3.845611
    NEXT: 115    +22     3.993233     C_CALL   test_cpymemtrace.py             206 sleep                354729984    312967168
    PREV: 115    +22     3.993233     C_CALL   test_cpymemtrace.py             206 sleep                354729984    312967168
    NEXT: 117    +2      4.018102     C_CALL   test_cpymemtrace.py             208 write_message_to_log  41762816   -312967168
    MESG: 118    +1      4.018114     After de-allocation of 312965383 bytes.
    MESG: 138    +21     4.018275     Before allocation of 438944001 bytes.
    PREV: 138    +21     4.018275
    NEXT: 139    +22     4.231798     C_CALL   test_cpymemtrace.py             206 sleep                480710656    438947840
    PREV: 139    +22     4.231798     C_CALL   test_cpymemtrace.py             206 sleep                480710656    438947840
    NEXT: 141    +2      4.275196     C_CALL   test_cpymemtrace.py             208 write_message_to_log  41762816   -438947840
    MESG: 142    +1      4.275208     After de-allocation of 438944001 bytes.
    MESG: 162    +21     4.275367     Before allocation of 279020117 bytes.
    PREV: 162    +21     4.275367
    NEXT: 163    +22     4.424839     C_CALL   test_cpymemtrace.py             206 sleep                320786432    279023616
    PREV: 163    +22     4.424839     C_CALL   test_cpymemtrace.py             206 sleep                320786432    279023616
    NEXT: 165    +2      4.446285     C_CALL   test_cpymemtrace.py             208 write_message_to_log  41762816   -279023616
    MESG: 166    +1      4.446297     After de-allocation of 279020117 bytes.
    MESG: 186    +21     4.446371     Before allocation of 442963008 bytes.
    PREV: 186    +21     4.446371
    NEXT: 187    +22     4.643456     C_CALL   test_cpymemtrace.py             206 sleep                484728832    442966016
    PREV: 187    +22     4.643456     C_CALL   test_cpymemtrace.py             206 sleep                484728832    442966016
    NEXT: 189    +2      4.678978     C_CALL   test_cpymemtrace.py             208 write_message_to_log  41762816   -442966016
    MESG: 190    +1      4.678990     After de-allocation of 442963008 bytes.
    LAST: 196    +7      4.679326     LINE     test_cpymemtrace.py             201 test_messaging        41762816            0
    EOF

.. raw:: latex

    \end{landscape}

Logging to a Temporary File
------------------------------

By default the log is written to a file in the current working directory.
To write to a specific file, and then read it follow this pattern:

.. code-block:: python

    import tempfile

    with tempfile.NamedTemporaryFile() as file:
        with cPyMemTrace.Trace(0, message='# Trace level0', filepath=file.name) as trace:
            trace.trace_file_wrapper.write_message_to_log('# Level 0 __enter__')
            temp_list = []
            for i in range(16):
                temp_list.append(b' ' * (1024 ** 2))
            trace.trace_file_wrapper.write_message_to_log('# Level 0 after populating list.')
            while len(temp_list):
                temp_list.pop()
            trace.trace_file_wrapper.write_message_to_log('# Level 0 after deleting the list.')
        file.flush()
        file_data = file.read()
        print()
        print(' filedata '.center(75, '-'))
        for line in file_data.split(b'\n'):
            print(line.decode('ascii'))
        print(' file_data DONE '.center(75, '-'))

See ``tests.test_cpymemtrace.test_trace_to_specific_log_file_nested()`` for a more complicated example.
