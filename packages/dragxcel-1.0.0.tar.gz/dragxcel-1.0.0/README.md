# DragXcel Python SDK

Official Python client for the **DragXcel API Platform** — automate personalized certificate and email generation at scale.

## Installation

```bash
pip install dragxcel
```

## Quick Start (Connect your Data)

```python
from dragxcel import DragXcel

dxl = DragXcel()

# Connect your external API to DragXcel
dxl.connect(
    user_key='dxl_user_xxx',
    protection_key='dxl_prot_xxx',
    endpoint='https://your-api.com/members'
)
```

## Usage

### Automate Bulk Sending
```python
dxl = DragXcel(server_key='dxl_srv_xxx')

dxl.send(
    subject='Your Certificate',
    filter_rules=[
        {'column': 'Attendance%', 'operator': 'gte', 'value': 75}
    ],
    smtp=[
        {'email': 'sender@gmail.com', 'password': 'xxx', 'host': 'smtp.gmail.com', 'port': 465}
    ]
)
```

### Local Filtering Utility
```python
data = [
    {'name': 'Arun', 'score': 85},
    {'name': 'Sita', 'score': 60}
]

rules = [{'column': 'score', 'operator': 'gte', 'value': 75}]

filtered = DragXcel.filter_data(data, rules)
# [{'name': 'Arun', 'score': 85}]
```

## License
MIT
