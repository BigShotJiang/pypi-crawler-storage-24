from setuptools import setup, find_packages

setup(
    name="dragxcel",
    version="1.0.0",
    author="DragXcel Team",
    description="Official Python SDK for the DragXcel API Platform",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/dragxcel/dragxcel-python-sdk",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
