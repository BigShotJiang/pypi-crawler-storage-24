def test_import_smoke() -> None:
    import aitop

    assert aitop.__name__ == "aitop"
