import aitop.ui.components.cpu_panel as cpu_panel_module
from aitop.core.system.cpu import CPUStats
from aitop.ui.components.cpu_panel import CPUPanel


class _RecordingDisplay:
    def __init__(self) -> None:
        self.width = 140
        self.calls: list[tuple[int, int, str, int]] = []

    def safe_addstr(self, y: int, x: int, text: str, attr: int = 0) -> None:
        self.calls.append((y, x, text, attr))

    def create_bar(self, _value: float, width: int) -> tuple[str, int]:
        return ("#" * min(max(width, 0), 10), 0)

    def get_color(self, _value: float) -> int:
        return 0


def test_cpu_panel_renders_extended_frequency_and_temperature_sources(
    monkeypatch: object,
) -> None:
    display = _RecordingDisplay()
    panel = CPUPanel(display)
    stats = CPUStats(
        vendor="AMD",
        model="Ryzen Test",
        total_percent=33.0,
        core_percents=[10.0, 56.0],
        current_freq=3200.0,
        min_freq=400.0,
        max_freq=4600.0,
        temperature=65.5,
        load_1min=0.2,
        load_5min=0.4,
        load_15min=0.6,
        frequency_source="linux-cpufreq,driver=amd-pstate,boost=on",
        temperature_source="hwmon:k10temp/Tdie",
        policy_min_freq=400.0,
        policy_max_freq=3800.0,
        hardware_min_freq=400.0,
        hardware_max_freq=4600.0,
    )

    monkeypatch.setattr(cpu_panel_module.curses, "color_pair", lambda _index: 0)
    monkeypatch.setattr(cpu_panel_module.curses, "A_BOLD", 0)

    panel.render(stats, start_y=0)

    lines = [entry[2] for entry in display.calls]
    assert any("Policy:" in line and "HW:" in line for line in lines)
    assert any("Source: linux-cpufreq" in line for line in lines)
    assert any("Source: hwmon:k10temp/Tdie" in line for line in lines)
