"""Application layer tests for process topology facade."""

from aitop.application.process_topology import (
    annotate_job_topology,
    summarize_job_topology,
)


def test_topology_facade_annotates_and_summarizes() -> None:
    processes = [
        {
            "pid": 5001,
            "ppid": 4000,
            "name": "python",
            "cmdline": "torchrun --rdzv-id app-job --rank 0 train.py",
            "cpu_percent": 75.0,
        },
        {
            "pid": 5002,
            "ppid": 4000,
            "name": "python",
            "cmdline": "torchrun --rdzv-id app-job --rank 1 train.py",
            "cpu_percent": 2.0,
        },
    ]
    gpu_processes = [{"pid": 5001, "sm_util": 91.0}, {"pid": 5002, "sm_util": 1.0}]

    enriched = annotate_job_topology(processes, gpu_processes)
    summaries = summarize_job_topology(enriched, max_jobs=3)

    assert summaries
    assert summaries[0]["job_id"] == "run-app-job"
    assert summaries[0]["stragglers"] == 1
    assert summaries[0]["is_distributed"] is True
