"""Tests for top header rendering behavior."""

from dataclasses import dataclass
from typing import Any

import aitop.ui.components.header as header_module
from aitop.ui.components.header import HeaderComponent


@dataclass
class _Rect:
    y: int = 0
    width: int = 120
    bottom: int = 1


class _LayoutStub:
    def calculate(self) -> dict[str, Any]:
        return {"header": _Rect()}


class _DisplayStub:
    def __init__(self) -> None:
        self.layout = _LayoutStub()
        self.calls: list[tuple[int, int, str, int]] = []

    def get_theme_attr(self, _name: str) -> int:
        return 0

    def safe_addstr(self, y: int, x: int, text: str, attr: int = 0) -> None:
        self.calls.append((y, x, text, attr))


def test_header_renders_tab_chip_without_vendor_chip(monkeypatch: object) -> None:
    display = _DisplayStub()
    header = HeaderComponent(display)

    monkeypatch.setattr(header_module.curses, "A_BOLD", 0)

    header.render(gpu_vendor="nvidia", current_tab="overview")

    texts = [entry[2] for entry in display.calls]
    rendered = " ".join(texts)
    assert "AITop" in rendered
    assert "[OVERVIEW]" in rendered
    assert "[NVIDIA]" not in rendered
    assert "[CPU]" not in rendered


def test_header_renders_requested_tab_label(monkeypatch: object) -> None:
    display = _DisplayStub()
    header = HeaderComponent(display)

    monkeypatch.setattr(header_module.curses, "A_BOLD", 0)

    header.render(gpu_vendor="amd", current_tab="gpu")

    texts = [entry[2] for entry in display.calls]
    rendered = " ".join(texts)
    assert "[GPU]" in rendered
