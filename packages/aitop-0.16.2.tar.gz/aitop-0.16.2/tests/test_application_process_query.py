"""Application layer tests for process query facade."""

from aitop.application.process_query import SUPPORTED_FIELDS, filter_processes


def test_filter_processes_facade_keeps_expected_semantics() -> None:
    processes = [
        {"pid": 10, "name": "python", "username": "alice", "is_gpu_process": True},
        {"pid": 11, "name": "bash", "username": "bob", "is_gpu_process": False},
    ]

    filtered = filter_processes(processes, "name:python gpu:true")
    assert [proc["pid"] for proc in filtered] == [10]


def test_supported_fields_exposed_by_facade() -> None:
    assert {"name", "pid", "user", "gpu", "cmd", "status"} <= SUPPORTED_FIELDS


def test_filter_processes_facade_supports_status_queries() -> None:
    processes = [
        {"pid": 21, "name": "trainer", "status": "running"},
        {"pid": 22, "name": "trainer", "status": "sleeping"},
    ]

    filtered = filter_processes(processes, "status:running")
    assert [proc["pid"] for proc in filtered] == [21]
