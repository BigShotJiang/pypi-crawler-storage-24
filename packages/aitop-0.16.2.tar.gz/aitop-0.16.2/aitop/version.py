"""AITop version information."""

__version__ = "0.16.2"  # Release: active-status heuristics and header chip cleanup
__author__ = "Alexander Warth"
__copyright__ = f"Copyright (c) 2025 {__author__}"
