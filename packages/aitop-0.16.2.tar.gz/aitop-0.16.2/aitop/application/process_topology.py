#!/usr/bin/env python3
"""Application-level job-topology services."""

from typing import Any, Dict, List, Optional

from ..domain.job_topology import (
    annotate_job_topology as _annotate_job_topology,
    summarize_job_topology as _summarize_job_topology,
)


def annotate_job_topology(
    processes: List[Dict[str, Any]],
    gpu_processes: Optional[List[Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """Annotate process entries with inferred job topology."""
    return _annotate_job_topology(processes, gpu_processes)


def summarize_job_topology(
    processes: List[Dict[str, Any]],
    max_jobs: int = 5,
) -> List[Dict[str, Any]]:
    """Summarize annotated processes into top-level job rows."""
    return _summarize_job_topology(processes, max_jobs=max_jobs)


__all__ = ["annotate_job_topology", "summarize_job_topology"]
