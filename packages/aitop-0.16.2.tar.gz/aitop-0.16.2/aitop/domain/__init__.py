"""Domain layer for pure business logic and invariants."""

