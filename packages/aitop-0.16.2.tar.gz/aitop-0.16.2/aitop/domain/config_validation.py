#!/usr/bin/env python3
"""Pure validation helpers for configuration payloads."""

from typing import Any, Dict

ThemeConfig = Dict[str, Any]
ThemeMap = Dict[str, ThemeConfig]


def validate_process_patterns(payload: Any) -> list[str]:
    """Validate and return AI process pattern list payload."""
    if not isinstance(payload, list) or not all(
        isinstance(pattern, str) for pattern in payload
    ):
        raise ValueError("Process patterns file must contain a list of strings")
    return payload


def validate_themes_payload(payload: Any) -> ThemeMap:
    """Validate and return the themes mapping from a configuration payload."""
    if not isinstance(payload, dict):
        raise ValueError("Theme configuration must be a dictionary")
    if "themes" not in payload:
        raise KeyError("Missing 'themes' key in theme file")
    themes = payload["themes"]
    if not isinstance(themes, dict):
        raise ValueError("'themes' must be a dictionary")
    if "default" not in themes:
        raise KeyError("Missing required 'default' theme")
    return themes


__all__ = [
    "ThemeConfig",
    "ThemeMap",
    "validate_process_patterns",
    "validate_themes_payload",
]
