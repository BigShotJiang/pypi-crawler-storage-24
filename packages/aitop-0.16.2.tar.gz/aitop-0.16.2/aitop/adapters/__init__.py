"""Adapter layer for UI, CLI, and other IO entry points."""

