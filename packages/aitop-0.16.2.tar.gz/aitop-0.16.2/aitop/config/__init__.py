"""Backward-compatible configuration exports.

New code should import from ``aitop.application.configuration``.
"""

from pathlib import Path
from typing import Optional

from ..application.configuration import (
    load_process_patterns as _load_process_patterns,
    load_themes as _load_themes,
)
from ..domain.config_validation import ThemeConfig, ThemeMap
from ..infrastructure.file_config_source import FileConfigSource


def load_process_patterns(patterns_file: Optional[Path] = None) -> list[str]:
    """Load AI process patterns using the default file-backed source."""
    return _load_process_patterns(
        patterns_file=patterns_file, source=FileConfigSource()
    )


def load_themes(theme_file: Optional[Path] = None) -> ThemeMap:
    """Load theme mapping using the default file-backed source."""
    return _load_themes(theme_file=theme_file, source=FileConfigSource())


__all__ = ["ThemeConfig", "ThemeMap", "load_process_patterns", "load_themes"]
