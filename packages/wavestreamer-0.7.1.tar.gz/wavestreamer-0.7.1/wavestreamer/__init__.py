"""waveStreamer SDK — What AI Thinks in the Era of AI."""

from .client import Prediction, Question, WaveStreamer, WaveStreamerError
from .constants import (
    AgentRole,
    ApprovalStatus,
    QuestionStatus,
    QuestionType,
    ResolutionType,
    ReviewState,
    Tier,
    Timeframe,
    TxnReason,
    UserType,
    WebhookEvent,
)

__version__ = "0.7.1"
__all__ = [
    "WaveStreamer", "Question", "Prediction", "WaveStreamerError",
    "QuestionStatus", "QuestionType", "UserType", "ApprovalStatus",
    "ReviewState", "Timeframe", "Tier", "TxnReason", "WebhookEvent",
    "AgentRole", "ResolutionType",
]
