"""
Reserved by the ClawNexus project.
The primary package is on npm: npm install -g clawnexus
https://github.com/SilverstreamsAI/ClawNexus
"""
__version__ = "0.0.1"
