# Matter Lab Rotavaps

`matterlab_rotavaps` provides Python drivers for rotary evaporators used in Matter Lab automation workflows.

The package currently includes:

- `Rotavap`: abstract base class for rotavap interfaces
- `IKARV10`: serial driver for the IKA RV10 rotavap

## Installation

Use the `matterlab` conda environment and install the package in editable mode during development:

```bash
pip install -e .[dev]
```

The package depends on `matterlab_serial_device` for serial communication.

## Quick Start

```python
from matterlab_rotavaps import IKARV10

rotavap = IKARV10(com_port="COM4", max_rpm=200)
print(rotavap.name)
print(rotavap.rpm)
rotavap.interval = 5
rotavap.timer = 1
rotavap.rpm = 80
rotavap.standby()
```

## Testing

Simulation tests are the default and are the only tests intended for CI enforcement.

One-click local sim run:

```bash
python examples/test_sim.py
```

Direct pytest run:

```bash
pytest
```

Real hardware tests are present for manual validation but are skipped unless explicitly enabled.

Run real tests with a COM port:

```bash
pytest tests/test_ika_rotavap_real.py --run-real --com-port COM4
```

You can also provide the port through an environment variable:

```bash
set ROTAVAP_COM_PORT=COM4
pytest tests/test_ika_rotavap_real.py --run-real
```

## Examples

Additional examples live in [examples/README.md](examples/README.md):

- `examples/test_sim.py` for the sim suite
- `examples/real_devices.py` for readable hardware usage examples

## Development Notes

- Source code lives under `src/`
- Pytest uses `src` as the import root
- Hardware-backed tests are marked with `@pytest.mark.real`
- Generated coverage, build, and cache artifacts are ignored
