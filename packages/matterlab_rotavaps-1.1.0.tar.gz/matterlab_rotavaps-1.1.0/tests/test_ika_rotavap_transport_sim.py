from matterlab_rotavaps import IKARV10, create_ika_rotavap_sim_transport_factory


def test_ika_rotavap_transport_sim_uses_public_api():
    transport_factory = create_ika_rotavap_sim_transport_factory(current_rpm=0, target_rpm=120)
    rotavap = IKARV10("SIM::rv10", max_rpm=250, transport_factory=transport_factory)

    assert rotavap.name == "RV10"
    assert rotavap.software_version == "1.0.0"
    rotavap.rpm = 120
    assert rotavap.target_rpm == 120
    assert rotavap.rpm == 120
    rotavap.standby()
    assert rotavap.rpm == 0


def test_ika_rotavap_transport_sim_tracks_lift_commands():
    transport_factory = create_ika_rotavap_sim_transport_factory()
    rotavap = IKARV10("SIM::rv10", max_rpm=250, transport_factory=transport_factory)

    rotavap.move_up()
    assert transport_factory.state.lift_state == "up"
    rotavap.move_down()
    assert transport_factory.state.lift_state == "down"
    rotavap.move_stop()
    assert transport_factory.state.lift_state == "stopped"
