import pytest

from matterlab_rotavaps import IKARV10


@pytest.mark.real
def test_ika_rotavap_reports_identity(com_port: str) -> None:
    rotavap = IKARV10(com_port=com_port)

    assert isinstance(rotavap.name, str)
    assert isinstance(rotavap.software_version, str)


@pytest.mark.real
def test_ika_rotavap_roundtrip_speed(com_port: str) -> None:
    rotavap = IKARV10(com_port=com_port)
    try:
        trial_rpm = min(80, rotavap.max_rpm)
        rotavap.rpm = trial_rpm
        assert rotavap.target_rpm == trial_rpm
        rotavap.standby()
        assert rotavap.target_rpm == 0
    finally:
        rotavap.standby()
