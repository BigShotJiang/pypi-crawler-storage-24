from matterlab_rotavaps.base_rotavap import Rotavap


class DummyRotavap(Rotavap):
    def __init__(self, max_rpm: int = 250) -> None:
        super().__init__(max_rpm=max_rpm)
        self._rpm = 0
        self._target_rpm = 0
        self._stir_switch_status = False

    def _query_rotavap(self, command: str) -> str:
        return command

    def standby(self) -> None:
        self.rpm = self._switch_rpm

    @property
    def rpm(self) -> int:
        return self._rpm

    @rpm.setter
    def rpm(self, rpm: int) -> None:
        self._rpm = rpm
        self._target_rpm = rpm
        self._stir_switch = rpm != self._switch_rpm

    @property
    def target_rpm(self) -> int:
        return self._target_rpm

    @property
    def _stir_switch(self) -> bool:
        return self._stir_switch_status

    @_stir_switch.setter
    def _stir_switch(self, stir_switch_status: bool) -> None:
        self._stir_switch_status = stir_switch_status


def test_default_logger_name() -> None:
    rotavap = DummyRotavap()

    assert rotavap.logger.name.endswith("DummyRotavap")


def test_standby_sets_zero_speed_and_stops_rotation() -> None:
    rotavap = DummyRotavap()
    rotavap.rpm = 150

    rotavap.standby()

    assert rotavap.rpm == 0
    assert rotavap.target_rpm == 0
    assert rotavap._stir_switch is False
