from abc import ABC, abstractmethod
from logging import Logger, getLogger
from typing import Optional


class Rotavap(ABC):
    category = "Rotavap"
    ui_fields = "com_port"

    _rpm_query: str
    _rpm_set: str
    _stir_start: str
    _stir_stop: str

    _switch_rpm: int = 0

    def __init__(self, max_rpm: int, logger: Optional[Logger] = None):
        self._targe_rpm: int
        self._stir_switch_status: bool

        self.max_rpm = max_rpm
        self.logger = logger if logger is not None else getLogger(
            f"{self.__class__.__module__}.{self.__class__.__name__}"
        )

    @abstractmethod
    def _query_rotavap(self, command: str) ->str:
        pass

    @abstractmethod
    def standby(self)->None:
        self.rpm = self._switch_rpm

    @property
    @abstractmethod
    def rpm(self) ->int:
        pass
    
    @rpm.setter
    @abstractmethod
    def rpm(self, rpm:int) ->None:
        pass

    @property
    @abstractmethod
    def target_rpm(self) ->int:
        pass

    @property
    @abstractmethod
    def _stir_switch(self) ->bool:
        pass

    @_stir_switch.setter
    @abstractmethod
    def _stir_switch(self, stir_switch_status: bool) ->None:
        pass
    