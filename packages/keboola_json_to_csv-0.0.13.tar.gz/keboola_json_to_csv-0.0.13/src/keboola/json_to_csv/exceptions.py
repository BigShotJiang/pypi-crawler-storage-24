class JsonParserException(Exception):
    pass
