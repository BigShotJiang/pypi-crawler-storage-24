"""Utility functions."""

# Copyright (C) 2022 Atsushi Togo
# All rights reserved.
#
# This file is part of phonopy.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# * Redistributions of source code must retain the above copyright
#   notice, this list of conditions and the following disclaimer.
#
# * Redistributions in binary form must reproduce the above copyright
#   notice, this list of conditions and the following disclaimer in
#   the documentation and/or other materials provided with the
#   distribution.
#
# * Neither the name of the phonopy project nor the names of its
#   contributors may be used to endorse or promote products derived
#   from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

from __future__ import annotations

from collections.abc import Sequence
from types import SimpleNamespace

import numpy as np
import spglib
from numpy.typing import NDArray

try:
    spglib.error.OLD_ERROR_HANDLING = False
except AttributeError:
    pass


def similarity_transformation(
    rot: Sequence[Sequence[float]]
    | NDArray[np.double]
    | Sequence[Sequence[int]]
    | NDArray[np.int64],
    mat: Sequence[Sequence[float]]
    | NDArray[np.double]
    | Sequence[Sequence[int]]
    | NDArray[np.int64],
) -> NDArray[np.double]:
    """Similarity transformation by R x M x R^-1."""
    return np.dot(rot, np.dot(mat, np.linalg.inv(rot)))  # type: ignore


def get_dot_access_dataset(dataset) -> SimpleNamespace | spglib.SpglibDataset:
    """Return dataset with dot access.

    From spglib 2.5, dataset is returned as dataclass.
    To emulate it for older versions, this function is used.

    """
    import spglib

    spg_version = tuple(int(v) for v in spglib.__version__.split(".")[:3])  # type: ignore

    if spg_version < (2, 5, 0):
        return SimpleNamespace(**dataset)
    else:
        return dataset
