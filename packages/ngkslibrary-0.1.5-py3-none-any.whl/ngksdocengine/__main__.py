from __future__ import annotations

from ngkslibrary.__main__ import main


if __name__ == "__main__":
    raise SystemExit(main())
