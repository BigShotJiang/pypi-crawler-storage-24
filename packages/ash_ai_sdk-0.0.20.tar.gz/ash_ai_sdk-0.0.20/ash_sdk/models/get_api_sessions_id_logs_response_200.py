from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.get_api_sessions_id_logs_response_200_logs_item import (
        GetApiSessionsIdLogsResponse200LogsItem,
    )


T = TypeVar("T", bound="GetApiSessionsIdLogsResponse200")


@_attrs_define
class GetApiSessionsIdLogsResponse200:
    """
    Attributes:
        logs (list[GetApiSessionsIdLogsResponse200LogsItem]):
        source (str):
    """

    logs: list[GetApiSessionsIdLogsResponse200LogsItem]
    source: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        logs = []
        for logs_item_data in self.logs:
            logs_item = logs_item_data.to_dict()
            logs.append(logs_item)

        source = self.source

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "logs": logs,
                "source": source,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_sessions_id_logs_response_200_logs_item import (
            GetApiSessionsIdLogsResponse200LogsItem,
        )

        d = dict(src_dict)
        logs = []
        _logs = d.pop("logs")
        for logs_item_data in _logs:
            logs_item = GetApiSessionsIdLogsResponse200LogsItem.from_dict(logs_item_data)

            logs.append(logs_item)

        source = d.pop("source")

        get_api_sessions_id_logs_response_200 = cls(
            logs=logs,
            source=source,
        )

        get_api_sessions_id_logs_response_200.additional_properties = d
        return get_api_sessions_id_logs_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
