from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="GetApiAgentsNameFilesResponse200FilesItem")


@_attrs_define
class GetApiAgentsNameFilesResponse200FilesItem:
    """
    Attributes:
        path (str):
        size (int):
        modified_at (datetime.datetime):
    """

    path: str
    size: int
    modified_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        path = self.path

        size = self.size

        modified_at = self.modified_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "path": path,
                "size": size,
                "modifiedAt": modified_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        path = d.pop("path")

        size = d.pop("size")

        modified_at = isoparse(d.pop("modifiedAt"))

        get_api_agents_name_files_response_200_files_item = cls(
            path=path,
            size=size,
            modified_at=modified_at,
        )

        get_api_agents_name_files_response_200_files_item.additional_properties = d
        return get_api_agents_name_files_response_200_files_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
