"""
Merge and rebase — diff branches, then merge or rebase.

Usage:
    export FORGE_API_KEY="your-api-key"
    python examples/merge_and_rebase.py
"""

from py_forge import Client


def main():
    client = Client()
    repo = None

    try:
        repo = client.repositories.create(
            name="merge-rebase-example",
            repo_type_key="TST",
        )

        # Set up two branches with diverging content
        main_branch = client.branches.create(repo.id, name="main-line")
        feature = client.branches.create(
            repo.id, name="feature", source_branch_id=main_branch.id
        )

        # Add a node to the feature branch
        client.nodes.create(
            repo.id,
            feature.id,
            node_data={
                "@type": "Folder",
                "@id": "Folder_feature",
                "doc_string": "Feature work",
            },
        )

        # Diff before merging
        diff = client.branches.diff(
            repo.id, feature.id, target_branch_id=main_branch.id
        )
        print(f"Diff (feature → main): {diff}")

        # Merge feature into main
        merge_result = client.repositories.merge(
            repo.id,
            source_branch_id=feature.id,
            target_branch_id=main_branch.id,
            message="Merge feature into main",
        )
        print(f"Merge result: {merge_result}")

        # --- Rebase example ---

        rebase_branch = client.branches.create(
            repo.id, name="rebase-me", source_branch_id=main_branch.id
        )

        client.nodes.create(
            repo.id,
            rebase_branch.id,
            node_data={
                "@type": "Folder",
                "@id": "Folder_rebase",
                "doc_string": "Will be rebased",
            },
        )

        # Rebase onto main
        rebase_result = client.repositories.rebase(
            repo.id,
            source_branch=rebase_branch.id,
            onto_branch=main_branch.id,
            message="Rebase onto main",
        )
        print(f"Rebase result: {rebase_result}")

    finally:
        if repo:
            client.repositories.delete(repo.id)
            print("Cleaned up repository")


if __name__ == "__main__":
    main()
