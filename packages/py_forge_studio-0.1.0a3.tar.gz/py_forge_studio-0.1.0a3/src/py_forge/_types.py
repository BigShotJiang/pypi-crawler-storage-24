from __future__ import annotations

from io import IOBase
from typing import Any, Dict, Literal, Tuple, Union

Headers = Dict[str, str]
Query = Dict[str, Any]
Body = Dict[str, Any]
HttpMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE"]

FileContent = Union[bytes, str, IOBase]
FileTypes = Union[
    # (filename, file)
    Tuple[str, FileContent],
    # (filename, file, content_type)
    Tuple[str, FileContent, str],
]
RequestFiles = Dict[str, FileTypes]
