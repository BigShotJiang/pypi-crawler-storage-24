from __future__ import annotations

import os
import warnings
from functools import cached_property
from typing import Optional

import httpx

from ._base_client import AsyncAPIClient, SyncAPIClient
from ._constants import DEFAULT_MAX_RETRIES
from ._exceptions import ForgeError
from .resources import (
    Admin,
    AsyncAdmin,
    AsyncAttachments,
    AsyncAuth,
    AsyncBranches,
    AsyncCommits,
    AsyncNodeMedia,
    AsyncNodes,
    AsyncRepositories,
    AsyncSchemas,
    Attachments,
    Auth,
    Branches,
    Commits,
    NodeMedia,
    Nodes,
    Repositories,
    Schemas,
)


class Client(SyncAPIClient):
    """Sync client for the Forge Studio API."""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http_client: Optional[httpx.Client] = None,
        verify: bool = True,
    ) -> None:
        resolved_api_key = api_key or os.environ.get("FORGE_API_KEY")
        if not resolved_api_key:
            raise ForgeError(
                "The api_key argument must be provided or the FORGE_API_KEY environment variable must be set."
            )

        resolved_base_url = base_url or os.environ.get("FORGE_BASE_URL")
        if not resolved_base_url:
            raise ForgeError(
                "The base_url argument must be provided or the FORGE_BASE_URL environment variable must be set. "
                "Your instance URL is https://<instance>.forge-studio.tech/api"
            )

        if not resolved_base_url.rstrip("/").endswith("/api"):
            warnings.warn(
                "The base_url does not end with '/api'. Forge Studio URLs typically look like "
                "https://<instance>.forge-studio.tech/api. If requests fail, check your base_url.",
                stacklevel=2,
            )

        super().__init__(
            base_url=resolved_base_url,
            api_key=resolved_api_key,
            timeout=timeout,
            max_retries=max_retries,
            http_client=http_client,
            verify=verify,
        )

    @cached_property
    def repositories(self) -> Repositories:
        return Repositories(self)

    @cached_property
    def branches(self) -> Branches:
        return Branches(self)

    @cached_property
    def nodes(self) -> Nodes:
        return Nodes(self)

    @cached_property
    def commits(self) -> Commits:
        return Commits(self)

    @cached_property
    def schemas(self) -> Schemas:
        return Schemas(self)

    @cached_property
    def auth(self) -> Auth:
        return Auth(self)

    @cached_property
    def attachments(self) -> Attachments:
        return Attachments(self)

    @cached_property
    def node_media(self) -> NodeMedia:
        return NodeMedia(self)

    @cached_property
    def admin(self) -> Admin:
        return Admin(self)

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncClient(AsyncAPIClient):
    """Async client for the Forge Studio API."""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[httpx.Timeout] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http_client: Optional[httpx.AsyncClient] = None,
        verify: bool = True,
    ) -> None:
        resolved_api_key = api_key or os.environ.get("FORGE_API_KEY")
        if not resolved_api_key:
            raise ForgeError(
                "The api_key argument must be provided or the FORGE_API_KEY environment variable must be set."
            )

        resolved_base_url = base_url or os.environ.get("FORGE_BASE_URL")
        if not resolved_base_url:
            raise ForgeError(
                "The base_url argument must be provided or the FORGE_BASE_URL environment variable must be set. "
                "Your instance URL is https://<instance>.forge-studio.tech/api"
            )

        if not resolved_base_url.rstrip("/").endswith("/api"):
            warnings.warn(
                "The base_url does not end with '/api'. Forge Studio URLs typically look like "
                "https://<instance>.forge-studio.tech/api. If requests fail, check your base_url.",
                stacklevel=2,
            )

        super().__init__(
            base_url=resolved_base_url,
            api_key=resolved_api_key,
            timeout=timeout,
            max_retries=max_retries,
            http_client=http_client,
            verify=verify,
        )

    @cached_property
    def repositories(self) -> AsyncRepositories:
        return AsyncRepositories(self)

    @cached_property
    def branches(self) -> AsyncBranches:
        return AsyncBranches(self)

    @cached_property
    def nodes(self) -> AsyncNodes:
        return AsyncNodes(self)

    @cached_property
    def commits(self) -> AsyncCommits:
        return AsyncCommits(self)

    @cached_property
    def schemas(self) -> AsyncSchemas:
        return AsyncSchemas(self)

    @cached_property
    def auth(self) -> AsyncAuth:
        return AsyncAuth(self)

    @cached_property
    def attachments(self) -> AsyncAttachments:
        return AsyncAttachments(self)

    @cached_property
    def node_media(self) -> AsyncNodeMedia:
        return AsyncNodeMedia(self)

    @cached_property
    def admin(self) -> AsyncAdmin:
        return AsyncAdmin(self)

    async def __aenter__(self) -> AsyncClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
