from __future__ import annotations

from collections.abc import Iterator

import httpx
import pytest
import respx

from py_forge import Client
from py_forge._exceptions import (
    APIConnectionError,
    APIError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    ForgeError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)
from py_forge.types import User

BASE_URL = "http://test-host"


@pytest.fixture()
def client() -> Iterator[Client]:
    c = Client(api_key="test-key", base_url=BASE_URL, max_retries=0)
    yield c
    c.close()


class TestEnvelopeSuccess:
    @respx.mock
    def test_unwrap_success_envelope(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "id": "user-1", "email": "test@example.com", "name": "Test",
                        "is_superuser": False, "email_verified": True,
                    },
                    "error": None,
                },
            )
        )
        user = client.auth.me()
        assert isinstance(user, User)
        assert user.id == "user-1"
        assert user.email == "test@example.com"


class TestEnvelopeError:
    @respx.mock
    def test_unwrap_failure_envelope(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/graph/repository/bad-id").mock(
            return_value=httpx.Response(
                400,
                json={"success": False, "data": None, "error": "Something failed", "message": "Bad request"},
            )
        )
        with pytest.raises(BadRequestError) as exc_info:
            client.repositories.get("bad-id")
        assert "Something failed" in exc_info.value.message


class TestDetailError:
    @respx.mock
    def test_detail_error_401(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(
            return_value=httpx.Response(
                401,
                json={"detail": "Invalid authentication token"},
            )
        )
        with pytest.raises(AuthenticationError) as exc_info:
            client.auth.me()
        assert "Invalid authentication token" in exc_info.value.message

    @respx.mock
    def test_detail_error_404(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/graph/repository/nonexistent").mock(
            return_value=httpx.Response(
                404,
                json={"detail": "Unknown database error"},
            )
        )
        with pytest.raises(NotFoundError) as exc_info:
            client.repositories.get("nonexistent")
        assert "Unknown database error" in exc_info.value.message

    @respx.mock
    def test_detail_error_422(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/graph/repository").mock(
            return_value=httpx.Response(
                422,
                json={"detail": [{"loc": ["body", "name"], "msg": "field required", "type": "value_error.missing"}]},
            )
        )
        with pytest.raises(UnprocessableEntityError) as exc_info:
            client.repositories.create(name="test", repo_type_key="TST")
        assert exc_info.value.status_code == 422


class TestStatusCodeMapping:
    @respx.mock
    def test_status_code_mapping_400(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(return_value=httpx.Response(400, json={"error": "bad"}))
        with pytest.raises(BadRequestError):
            client.auth.me()

    @respx.mock
    def test_status_code_mapping_401(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(return_value=httpx.Response(401, json={"detail": "unauth"}))
        with pytest.raises(AuthenticationError):
            client.auth.me()

    @respx.mock
    def test_status_code_mapping_403(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(return_value=httpx.Response(403, json={"detail": "forbidden"}))
        with pytest.raises(PermissionDeniedError):
            client.auth.me()

    @respx.mock
    def test_status_code_mapping_404(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/graph/repository/x").mock(return_value=httpx.Response(404, json={"detail": "not found"}))
        with pytest.raises(NotFoundError):
            client.repositories.get("x")

    @respx.mock
    def test_status_code_mapping_409(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/graph/repository/x").mock(return_value=httpx.Response(409, json={"error": "conflict"}))
        with pytest.raises(ConflictError):
            client.repositories.get("x")

    @respx.mock
    def test_status_code_mapping_422(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(return_value=httpx.Response(422, json={"detail": "unprocessable"}))
        with pytest.raises(UnprocessableEntityError):
            client.auth.me()

    @respx.mock
    def test_status_code_mapping_429(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(return_value=httpx.Response(429, json={"error": "rate limited"}))
        with pytest.raises(RateLimitError):
            client.auth.me()

    @respx.mock
    def test_status_code_mapping_500(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(return_value=httpx.Response(500, json={"error": "internal"}))
        with pytest.raises(InternalServerError):
            client.auth.me()

    @respx.mock
    def test_status_code_mapping_503(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(return_value=httpx.Response(503, json={"error": "unavailable"}))
        with pytest.raises(InternalServerError):
            client.auth.me()


class TestConnectionErrors:
    @respx.mock
    def test_connection_error(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(side_effect=httpx.ConnectError("connection refused"))
        with pytest.raises(APIConnectionError):
            client.auth.me()

    @respx.mock
    def test_timeout_error(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(side_effect=httpx.ReadTimeout("timed out"))
        with pytest.raises(APITimeoutError):
            client.auth.me()


class TestExceptionAttributes:
    @respx.mock
    def test_status_error_has_attributes(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(
            return_value=httpx.Response(404, json={"detail": "not found"})
        )
        with pytest.raises(APIStatusError) as exc_info:
            client.auth.me()
        err = exc_info.value
        assert err.status_code == 404
        assert err.response is not None
        assert isinstance(err.response, httpx.Response)
        assert err.body == {"detail": "not found"}
        assert err.message == "not found"

    @respx.mock
    def test_connection_error_wraps_original(self, client: Client) -> None:
        original = httpx.ConnectError("connection refused")
        respx.get(f"{BASE_URL}/auth/me").mock(side_effect=original)
        with pytest.raises(APIConnectionError) as exc_info:
            client.auth.me()
        assert exc_info.value.__cause__ is original


class TestExceptionHierarchy:
    @respx.mock
    def test_catch_api_error_catches_status_error(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(return_value=httpx.Response(404, json={"detail": "nope"}))
        with pytest.raises(APIError):
            client.auth.me()

    @respx.mock
    def test_catch_forge_error_catches_all(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/auth/me").mock(side_effect=httpx.ConnectError("fail"))
        with pytest.raises(ForgeError):
            client.auth.me()
