from __future__ import annotations

import io
from collections.abc import Iterator

import httpx
import pytest
import respx

from py_forge import Client

BASE_URL = "http://test-host"


@pytest.fixture()
def client() -> Iterator[Client]:
    c = Client(api_key="test-key", base_url=BASE_URL, max_retries=0)
    yield c
    c.close()


def _success_envelope(data: dict | list) -> dict:
    return {"success": True, "data": data, "error": None, "message": "OK"}


class TestRepositories:
    @respx.mock
    def test_create_sends_post_with_body(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/graph/repository").mock(
            return_value=httpx.Response(
                201,
                json=_success_envelope(
                    {
                        "id": "r1", "name": "test", "description": "",
                        "default_branch": "main", "repo_type_key": "TST",
                        "created_at": "2024-01-01", "branches": [],
                    }
                ),
            )
        )
        result = client.repositories.create(name="test", repo_type_key="TST")
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "POST"
        import json
        body = json.loads(req.content)
        assert body["name"] == "test"
        assert body["repo_type_key"] == "TST"
        assert result.name == "test"

    @respx.mock
    def test_list_sends_get_with_query_params(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/graph/repository").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {"repositories": [], "total_count": 0, "page": 1, "page_size": 50}
                ),
            )
        )
        client.repositories.list(page=1, page_size=50)
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "GET"
        assert "page=1" in str(req.url)
        assert "page_size=50" in str(req.url)

    @respx.mock
    def test_get_sends_get_with_path(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/graph/repository/repo-123").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "id": "repo-123", "name": "test", "description": "",
                        "default_branch": "main", "repo_type_key": "TST",
                        "created_at": "2024-01-01", "branches": [],
                    }
                ),
            )
        )
        result = client.repositories.get("repo-123")
        assert route.call_count == 1
        assert route.calls[0].request.method == "GET"
        assert result.id == "repo-123"

    @respx.mock
    def test_delete_sends_delete(self, client: Client) -> None:
        route = respx.delete(f"{BASE_URL}/graph/repository/repo-123").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope({"deleted": True}),
            )
        )
        result = client.repositories.delete("repo-123")
        assert route.call_count == 1
        assert route.calls[0].request.method == "DELETE"
        assert result.deleted is True

    @respx.mock
    def test_merge_sends_post(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/graph/repository/repo-123/merge").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {"success": True, "merge_commit_id": "mc1", "message": "merged", "merged_at": "2024-01-01"}
                ),
            )
        )
        client.repositories.merge(
            "repo-123",
            source_branch_id="br-1",
            target_branch_id="br-2",
            message="merge it",
        )
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "POST"
        import json
        body = json.loads(req.content)
        assert body["source_branch_id"] == "br-1"
        assert body["target_branch_id"] == "br-2"
        assert body["message"] == "merge it"


class TestBranches:
    @respx.mock
    def test_create_branch_sends_post(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/graph/repository/repo-1/branch").mock(
            return_value=httpx.Response(
                201,
                json=_success_envelope(
                    {
                        "id": "br-1", "name": "feature", "description": "",
                        "repository_id": "repo-1", "created_at": "2024-01-01",
                        "is_default": False,
                    }
                ),
            )
        )
        result = client.branches.create("repo-1", name="feature")
        assert route.call_count == 1
        assert route.calls[0].request.method == "POST"
        import json
        body = json.loads(route.calls[0].request.content)
        assert body["name"] == "feature"
        assert result.name == "feature"

    @respx.mock
    def test_get_head_sends_get(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/graph/repository/repo-1/branch/br-1/head").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope({"head": "commit-abc"}),
            )
        )
        result = client.branches.get_head("repo-1", "br-1")
        assert route.call_count == 1
        assert route.calls[0].request.method == "GET"
        assert result.head == "commit-abc"

    @respx.mock
    def test_diff_sends_get_with_query(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/graph/repository/repo-1/branch/br-1/diff").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "diverged": False,
                        "common_ancestor": "c0",
                        "source_ahead": 0,
                        "target_ahead": 0,
                        "source_commits": [],
                        "target_commits": [],
                        "requires_rebase": False,
                        "can_fast_forward": False,
                    }
                ),
            )
        )
        result = client.branches.diff("repo-1", "br-1", target_branch_id="br-2")
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "GET"
        assert "target=br-2" in str(req.url)
        assert result.diverged is False


class TestNodes:
    @respx.mock
    def test_create_node_sends_post(self, client: Client) -> None:
        node_data = {"@type": "TST_Test", "@id": "TST_1", "doc_string": "test"}
        route = respx.post(f"{BASE_URL}/graph/repository/repo-1/branch/br-1/node").mock(
            return_value=httpx.Response(
                201,
                json=_success_envelope(
                    {"id": "TST_1", "repository_id": "repo-1", "branch_id": "br-1", "node": node_data}
                ),
            )
        )
        result = client.nodes.create("repo-1", "br-1", node_data=node_data)
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "POST"
        import json
        body = json.loads(req.content)
        assert body["node_data"] == node_data
        assert result.id == "TST_1"

    @respx.mock
    def test_get_history_sends_get(self, client: Client) -> None:
        route = respx.get(
            f"{BASE_URL}/graph/repository/repo-1/branch/br-1/node/node-1/history"
        ).mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {"commits": [], "total_count": 0, "start_offset": 0}
                ),
            )
        )
        result = client.nodes.get_history("repo-1", "br-1", "node-1")
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "GET"
        assert result.total_count == 0


class TestAuth:
    @respx.mock
    def test_login_sends_post_without_auth_header(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/auth/login").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "id_token": "tok",
                        "refresh_token": "ref",
                        "expires_in": 3600,
                        "user_id": "u1",
                        "email": "a@b.com",
                    }
                ),
            )
        )
        result = client.auth.login(email="a@b.com", password="pass")
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "POST"
        auth_header = req.headers.get("authorization", "")
        assert "Bearer" not in auth_header
        assert result.id_token == "tok"

    @respx.mock
    def test_me_sends_get_with_auth_header(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/auth/me").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "id": "u1",
                        "email": "a@b.com",
                        "name": "Test",
                        "is_superuser": False,
                        "email_verified": True,
                    }
                ),
            )
        )
        result = client.auth.me()
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "GET"
        assert req.headers["authorization"] == "Bearer test-key"
        assert result.email == "a@b.com"


class TestAttachments:
    @respx.mock
    def test_upload_sends_multipart(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/graph/attachment/upload").mock(
            return_value=httpx.Response(
                201,
                json=_success_envelope(
                    {
                        "filename": "test.txt",
                        "mime_type": "text/plain",
                        "size_bytes": 12,
                        "storage_path": "attachments/test.txt",
                    }
                ),
            )
        )
        file_obj = ("test.txt", io.BytesIO(b"test content"), "text/plain")
        result = client.attachments.upload(file=file_obj, repo_id="repo-1")
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "POST"
        content_type = req.headers.get("content-type", "")
        assert "multipart/form-data" in content_type
        assert result.filename == "test.txt"

    @respx.mock
    def test_exists_sends_get_with_query(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/graph/attachment/exists").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope({"exists": True, "id": "att-1"}),
            )
        )
        result = client.attachments.exists(attachment_id="att-1")
        assert route.call_count == 1
        req = route.calls[0].request
        assert req.method == "GET"
        assert "id=att-1" in str(req.url)
        assert result.exists is True


class TestAuthHeaderOnAllResources:
    @respx.mock
    def test_repositories_include_auth(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/graph/repository/r1").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "id": "r1", "name": "t", "description": "",
                        "default_branch": "main", "repo_type_key": "T",
                        "created_at": "2024-01-01", "branches": [],
                    }
                ),
            )
        )
        client.repositories.get("r1")
        assert route.calls[0].request.headers["authorization"] == "Bearer test-key"

    @respx.mock
    def test_branches_include_auth(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/graph/repository/r1/branch/b1").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "id": "b1", "name": "main", "description": "",
                        "repository_id": "r1", "created_at": "2024-01-01",
                        "is_default": True,
                    }
                ),
            )
        )
        client.branches.get("r1", "b1")
        assert route.calls[0].request.headers["authorization"] == "Bearer test-key"

    @respx.mock
    def test_nodes_include_auth(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/graph/repository/r1/branch/b1/node/n1").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {"id": "n1", "repository_id": "r1", "branch_id": "b1", "node": {}}
                ),
            )
        )
        client.nodes.get("r1", "b1", "n1")
        assert route.calls[0].request.headers["authorization"] == "Bearer test-key"

    @respx.mock
    def test_login_excludes_auth(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/auth/login").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {"id_token": "t", "refresh_token": "r", "expires_in": 3600, "user_id": "u", "email": "e"}
                ),
            )
        )
        client.auth.login(email="e", password="p")
        auth_header = route.calls[0].request.headers.get("authorization", "")
        assert "Bearer" not in auth_header

    @respx.mock
    def test_refresh_excludes_auth(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/auth/refresh").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {"id_token": "t", "refresh_token": "r", "expires_in": 3600, "user_id": "u", "email": "e"}
                ),
            )
        )
        client.auth.refresh(refresh_token="old-token")
        auth_header = route.calls[0].request.headers.get("authorization", "")
        assert "Bearer" not in auth_header
