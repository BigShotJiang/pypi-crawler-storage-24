from __future__ import annotations

from collections.abc import Iterator

import httpx
import pytest

from py_forge import Client
from py_forge._constants import DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT
from py_forge._exceptions import ForgeError
from py_forge.resources import (
    Admin,
    Attachments,
    Auth,
    Branches,
    Commits,
    NodeMedia,
    Nodes,
    Repositories,
    Schemas,
)


class TestClientConstruction:
    def test_client_default_construction(self) -> None:
        client = Client(api_key="test", base_url="http://localhost")
        try:
            assert client._base_url == "http://localhost"
            assert client._api_key == "test"
            assert client._timeout == DEFAULT_TIMEOUT
            assert client._max_retries == DEFAULT_MAX_RETRIES
        finally:
            client.close()

    def test_client_env_var_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("FORGE_API_KEY", "env-key-123")
        monkeypatch.delenv("FORGE_BASE_URL", raising=False)
        client = Client(base_url="http://localhost")
        try:
            assert client._api_key == "env-key-123"
        finally:
            client.close()

    def test_client_env_var_base_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("FORGE_BASE_URL", "http://env-host:8080")
        monkeypatch.delenv("FORGE_API_KEY", raising=False)
        client = Client(api_key="test")
        try:
            assert client._base_url == "http://env-host:8080"
        finally:
            client.close()

    def test_client_explicit_overrides_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("FORGE_API_KEY", "env-key")
        monkeypatch.setenv("FORGE_BASE_URL", "http://env-host")
        client = Client(api_key="explicit-key", base_url="http://explicit-host")
        try:
            assert client._api_key == "explicit-key"
            assert client._base_url == "http://explicit-host"
        finally:
            client.close()

    def test_client_no_api_key_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("FORGE_API_KEY", raising=False)
        with pytest.raises(ForgeError, match="api_key"):
            Client(base_url="http://localhost")

    def test_client_no_base_url_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("FORGE_BASE_URL", raising=False)
        with pytest.raises(ForgeError, match="base_url"):
            Client(api_key="test")

    def test_client_verify_false_propagates(self) -> None:
        client = Client(api_key="test", base_url="http://localhost", verify=False)
        try:
            assert client._verify is False
        finally:
            client.close()

    def test_client_custom_timeout(self) -> None:
        custom_timeout = httpx.Timeout(30.0)
        client = Client(api_key="test", base_url="http://localhost", timeout=custom_timeout)
        try:
            assert client._timeout == custom_timeout
        finally:
            client.close()

    def test_client_custom_max_retries(self) -> None:
        client = Client(api_key="test", base_url="http://localhost", max_retries=5)
        try:
            assert client._max_retries == 5
        finally:
            client.close()


class TestClientResources:
    @pytest.fixture()
    def client(self) -> Iterator[Client]:
        c = Client(api_key="test", base_url="http://localhost")
        yield c
        c.close()

    def test_client_resource_access(self, client: Client) -> None:
        assert isinstance(client.repositories, Repositories)
        assert isinstance(client.branches, Branches)
        assert isinstance(client.nodes, Nodes)
        assert isinstance(client.commits, Commits)
        assert isinstance(client.schemas, Schemas)
        assert isinstance(client.auth, Auth)
        assert isinstance(client.attachments, Attachments)
        assert isinstance(client.node_media, NodeMedia)
        assert isinstance(client.admin, Admin)

    def test_client_cached_property(self, client: Client) -> None:
        repos1 = client.repositories
        repos2 = client.repositories
        assert repos1 is repos2

    def test_client_context_manager(self) -> None:
        with Client(api_key="test", base_url="http://localhost") as client:
            assert isinstance(client, Client)
            assert isinstance(client.repositories, Repositories)
        # After exiting, the underlying httpx client should be closed
        assert client._client.is_closed
