from __future__ import annotations

from collections.abc import Iterator

import httpx
import pytest
import respx

from py_forge import Client
from py_forge._exceptions import AuthenticationError, BadRequestError
from py_forge.types.auth import LoginResponse, PasswordChangeResponse

BASE_URL = "http://test-host"


@pytest.fixture()
def client() -> Iterator[Client]:
    c = Client(api_key="test-key", base_url=BASE_URL, max_retries=0)
    yield c
    c.close()


def _success_envelope(data: dict | list) -> dict:
    return {"success": True, "data": data, "error": None, "message": "OK"}


class TestLoginHappyPath:
    @respx.mock
    def test_login_happy_path(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/auth/login").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "id_token": "tok123",
                        "refresh_token": "ref456",
                        "expires_in": 3600,
                        "user_id": "uid-001",
                        "email": "user@example.com",
                    }
                ),
            )
        )
        result = client.auth.login(email="user@example.com", password="secret")
        assert route.call_count == 1
        assert isinstance(result, LoginResponse)
        assert result.id_token == "tok123"
        assert result.refresh_token == "ref456"
        assert result.expires_in == 3600
        assert result.user_id == "uid-001"

    @respx.mock
    def test_login_wrong_credentials(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/auth/login").mock(
            return_value=httpx.Response(
                401,
                json={"detail": "Invalid email or password"},
            )
        )
        with pytest.raises(AuthenticationError) as exc_info:
            client.auth.login(email="bad@example.com", password="wrong")
        assert exc_info.value.status_code == 401


class TestRefresh:
    @respx.mock
    def test_refresh_happy_path(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/auth/refresh").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "id_token": "newtok",
                        "refresh_token": "newref",
                        "expires_in": 3600,
                        "user_id": "uid-001",
                    }
                ),
            )
        )
        result = client.auth.refresh(refresh_token="oldref")
        assert route.call_count == 1
        assert isinstance(result, LoginResponse)
        assert result.id_token == "newtok"
        assert result.refresh_token == "newref"

    @respx.mock
    def test_refresh_expired_token(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/auth/refresh").mock(
            return_value=httpx.Response(
                401,
                json={"detail": "Token has expired"},
            )
        )
        with pytest.raises(AuthenticationError) as exc_info:
            client.auth.refresh(refresh_token="expired")
        assert exc_info.value.status_code == 401


class TestChangePassword:
    @respx.mock
    def test_change_password_happy_path(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/auth/me/password").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope(
                    {
                        "id_token": "newtok",
                        "refresh_token": "newref",
                        "message": "Password changed successfully",
                    }
                ),
            )
        )
        result = client.auth.change_password(current_password="old", new_password="new")
        assert route.call_count == 1
        assert isinstance(result, PasswordChangeResponse)
        assert result.message == "Password changed successfully"
        assert result.id_token == "newtok"

    @respx.mock
    def test_change_password_wrong_current(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/auth/me/password").mock(
            return_value=httpx.Response(
                400,
                json={
                    "success": False, "data": None,
                    "error": "Current password is incorrect", "message": "Bad request",
                },
            )
        )
        with pytest.raises(BadRequestError) as exc_info:
            client.auth.change_password(current_password="wrong", new_password="new")
        assert exc_info.value.status_code == 400


class TestCreateDocsSession:
    @respx.mock
    def test_create_docs_session(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/auth/docs-session").mock(
            return_value=httpx.Response(
                200,
                json=_success_envelope({"message": "Docs session created"}),
            )
        )
        result = client.auth.create_docs_session()
        assert route.call_count == 1
        assert result.message == "Docs session created"
