"""
Comprehensive integration tests for the Forge Studio API.

Run with:
    python -m pytest tests/integration/test_api.py -v --timeout=120
"""

from __future__ import annotations

import io
import os
import time
import uuid

import pytest

from py_forge import Client
from py_forge._exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    UnprocessableEntityError,
)
from py_forge.types.attachment import (
    AttachmentExists,
    AttachmentMetadata,
    AttachmentUrl,
    NodeMediaUpload,
)
from py_forge.types.auth import ApiKeyCreated, User
from py_forge.types.branch import Branch, BranchDiff, BranchHead
from py_forge.types.commit import CommitHistory, CommitResponse
from py_forge.types.merge import MergeResponse, RebaseResponse
from py_forge.types.node import Node, NodeHistory
from py_forge.types.repository import Repository
from py_forge.types.schema import SchemaResponse
from py_forge.types.shared import DeleteResponse, MessageResponse

pytestmark = pytest.mark.integration

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

API_KEY = os.environ.get("FORGE_API_KEY", "")
if not API_KEY:
    pytest.skip("FORGE_API_KEY not set", allow_module_level=True)
BASE_URL = os.environ.get("FORGE_BASE_URL", "")
if not BASE_URL:
    pytest.skip("FORGE_BASE_URL not set", allow_module_level=True)

FOLDER_SCHEMA = {
    "classes": [
        {
            "@type": "Class",
            "@id": "Folder",
            "@inherits": "Node",
            "@metadata": {
                "node_type_key": "FLD",
                "displayname": {"singular": "Folder", "plural": "Folders"},
                "NodeOptions": {"type": "structure"},
                "ui": {"icon": {"name": "mdi:folder", "color": "#FFB300"}},
            },
        }
    ]
}

_SKIP_SSL = "localhost" in BASE_URL


def _unique(prefix: str = "sdk-test") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def _make_node_data(suffix: str | None = None) -> dict:
    tag = suffix or uuid.uuid4().hex[:8]
    return {
        "@type": "Folder",
        "doc_string": f"test node {tag}",
        "@id": f"Folder/test_{tag}",
    }


@pytest.fixture(scope="session")
def client():
    c = Client(
        api_key=API_KEY,
        base_url=BASE_URL,
        verify=not _SKIP_SSL,
    )
    yield c
    c.close()


@pytest.fixture()
def temp_repo(client: Client):
    """Create a temporary repo with schema, yield (repo, default_branch_id), then clean up."""
    repo = client.repositories.create(
        name=_unique(),
        repo_type_key="TST",
        description="SDK integration test repo",
    )
    # Find default branch
    page = client.branches.list(repo.id)
    default_branch_id = page.data[0].id
    for b in page.data:
        if b.is_default:
            default_branch_id = b.id
            break

    # Apply schema so we can create nodes
    client.schemas.update(
        repo.id,
        default_branch_id,
        schema_data=FOLDER_SCHEMA,
        commit_msg="init schema",
    )

    yield repo, default_branch_id

    try:
        client.repositories.delete(repo.id)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 1. Auth
# ---------------------------------------------------------------------------


class TestAuth:
    def test_get_current_user(self, client: Client):
        user = client.auth.me()
        assert isinstance(user, User)
        assert user.id
        assert isinstance(user.is_superuser, bool)


# ---------------------------------------------------------------------------
# 2. Repository CRUD
# ---------------------------------------------------------------------------


class TestRepositoryCRUD:
    def test_full_lifecycle(self, client: Client):
        name = _unique()
        repo = None
        try:
            # Create
            repo = client.repositories.create(
                name=name,
                repo_type_key="TST",
                description="lifecycle test",
            )
            assert isinstance(repo, Repository)
            assert repo.name == name
            assert repo.repo_type_key == "TST"

            # Get
            fetched = client.repositories.get(repo.id)
            assert fetched.id == repo.id
            assert fetched.name == name

            # Update
            new_name = _unique("renamed")
            updated = client.repositories.update(
                repo.id, name=new_name, description="updated desc"
            )
            assert updated.name == new_name
            assert updated.description == "updated desc"

            # List
            page = client.repositories.list()
            assert page.total_count >= 1
            assert page.page == 1

            # List with pagination
            page_small = client.repositories.list(page_size=1)
            assert page_small.page_size == 1
            if page_small.total_count > 1:
                assert page_small.has_next_page

            # Delete
            deleted = client.repositories.delete(repo.id)
            assert isinstance(deleted, DeleteResponse)
            assert deleted.deleted is True
            repo = None  # mark cleaned up
        finally:
            if repo is not None:
                try:
                    client.repositories.delete(repo.id)
                except Exception:
                    pass

    def test_get_nonexistent_repo(self, client: Client):
        with pytest.raises(NotFoundError):
            client.repositories.get("nonexistent-repo-id-00000000")


# ---------------------------------------------------------------------------
# 3. Branch operations
# ---------------------------------------------------------------------------


class TestBranchOperations:
    def test_full_lifecycle(self, client: Client):
        repo = client.repositories.create(
            name=_unique(), repo_type_key="TST"
        )
        try:
            # List — expect default branch
            page = client.branches.list(repo.id)
            assert len(page.data) >= 1
            default_branch = page.data[0]
            assert default_branch.is_default

            # Create
            new_branch = client.branches.create(
                repo.id,
                name="feature-test",
                description="test branch",
                source_branch_id=default_branch.id,
            )
            assert isinstance(new_branch, Branch)
            assert new_branch.name == "feature-test"

            # Get
            fetched = client.branches.get(repo.id, new_branch.id)
            assert fetched.id == new_branch.id

            # Update
            updated = client.branches.update(
                repo.id, new_branch.id, name="feature-renamed"
            )
            assert updated.name == "feature-renamed"

            # Get head commit
            head = client.branches.get_head(repo.id, new_branch.id)
            assert isinstance(head, BranchHead)

            # Delete
            deleted = client.branches.delete(repo.id, new_branch.id)
            assert isinstance(deleted, DeleteResponse)
            assert deleted.deleted is True
        finally:
            try:
                client.repositories.delete(repo.id)
            except Exception:
                pass

    def test_get_nonexistent_branch(self, client: Client):
        repo = client.repositories.create(
            name=_unique(), repo_type_key="TST"
        )
        try:
            with pytest.raises(NotFoundError):
                client.branches.get(repo.id, "nonexistent-branch-id-00000000")
        finally:
            try:
                client.repositories.delete(repo.id)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# 4. Schema operations
# ---------------------------------------------------------------------------


class TestSchemaOperations:
    def test_update_get_delete(self, client: Client):
        repo = client.repositories.create(
            name=_unique(), repo_type_key="TST"
        )
        try:
            page = client.branches.list(repo.id)
            branch_id = page.data[0].id

            # Update schema
            schema_resp = client.schemas.update(
                repo.id,
                branch_id,
                schema_data=FOLDER_SCHEMA,
                commit_msg="add Folder class",
            )
            assert isinstance(schema_resp, SchemaResponse)
            assert schema_resp.repository_id == repo.id

            # Get schema
            fetched = client.schemas.get(repo.id, branch_id)
            assert isinstance(fetched, SchemaResponse)
            assert fetched.schema_data  # non-empty

            # Delete schema
            deleted = client.schemas.delete(
                repo.id, branch_id, force=True, commit_msg="remove schema"
            )
            assert isinstance(deleted, SchemaResponse)
        finally:
            try:
                client.repositories.delete(repo.id)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# 5. Node CRUD
# ---------------------------------------------------------------------------


class TestNodeCRUD:
    def test_full_lifecycle(self, client: Client, temp_repo):
        repo, branch_id = temp_repo

        tag = uuid.uuid4().hex[:8]
        node_data = _make_node_data(tag)

        # Create
        node = client.nodes.create(repo.id, branch_id, node_data=node_data)
        assert isinstance(node, Node)
        assert node.repository_id == repo.id
        node_id = node.id

        # Get
        fetched = client.nodes.get(repo.id, branch_id, node_id)
        assert fetched.id == node_id

        # Update — must use server-assigned @id, not the one from test data
        updated_data = {
            "@type": "Folder",
            "doc_string": f"updated node {tag}",
            "@id": node_id,
        }
        updated = client.nodes.update(
            repo.id, branch_id, node_id, node_data=updated_data
        )
        assert isinstance(updated, Node)

        # List
        page = client.nodes.list(repo.id, branch_id)
        assert page.total_count >= 1
        ids = [n.id for n in page.data]
        assert node_id in ids

        # History
        history = client.nodes.get_history(repo.id, branch_id, node_id)
        assert isinstance(history, NodeHistory)
        assert history.total_count >= 1

        # Delete
        deleted = client.nodes.delete(repo.id, branch_id, node_id)
        assert isinstance(deleted, DeleteResponse)
        assert deleted.deleted is True

    def test_get_nonexistent_node(self, client: Client, temp_repo):
        repo, branch_id = temp_repo
        with pytest.raises(NotFoundError):
            client.nodes.get(repo.id, branch_id, "nonexistent-node-id-00000000")


# ---------------------------------------------------------------------------
# 6. Commit operations
# ---------------------------------------------------------------------------


class TestCommitOperations:
    def test_create_and_list(self, client: Client, temp_repo):
        repo, branch_id = temp_repo

        # Create a commit with a node_create operation
        commit_resp = client.commits.create(
            repo.id,
            branch_id,
            message="test commit from integration test",
            operations=[
                {
                    "type": "node_create",
                    "data": {"node_data": _make_node_data()},
                }
            ],
        )
        assert isinstance(commit_resp, CommitResponse)
        assert commit_resp.repository_id == repo.id
        assert commit_resp.branch_id == branch_id

        # List history
        history = client.commits.list_history(repo.id, branch_id)
        assert isinstance(history, CommitHistory)
        assert history.total_count >= 1
        assert len(history.commits) >= 1


# ---------------------------------------------------------------------------
# 7. Merge & Rebase
# ---------------------------------------------------------------------------


class TestMergeAndRebase:
    def _setup_two_branches(self, client: Client, suffix: str):
        """Create a repo with schema, a feature branch, and a node on the feature branch."""
        repo = client.repositories.create(
            name=_unique(f"merge-{suffix}"),
            repo_type_key="TST",
        )
        page = client.branches.list(repo.id)
        main_branch_id = page.data[0].id

        # Schema on main
        client.schemas.update(
            repo.id,
            main_branch_id,
            schema_data=FOLDER_SCHEMA,
            commit_msg="init schema",
        )

        # Create feature branch
        feature = client.branches.create(
            repo.id,
            name=f"feature-{suffix}",
            source_branch_id=main_branch_id,
        )

        # Create a node on the feature branch
        node_data = _make_node_data(suffix)
        client.nodes.create(repo.id, feature.id, node_data=node_data)

        return repo, main_branch_id, feature

    def test_merge(self, client: Client):
        repo = None
        try:
            repo, main_id, feature = self._setup_two_branches(client, "mrg")
            result = client.repositories.merge(
                repo.id,
                source_branch_id=feature.id,
                target_branch_id=main_id,
                message="merge feature into main",
            )
            assert isinstance(result, MergeResponse)
            assert result.success is True
        finally:
            if repo:
                try:
                    client.repositories.delete(repo.id)
                except Exception:
                    pass

    def test_rebase(self, client: Client):
        repo = None
        try:
            repo, main_id, feature = self._setup_two_branches(client, "rbs")

            # Create a node on main so the branches diverge
            main_node = _make_node_data("main-rbs")
            client.nodes.create(repo.id, main_id, node_data=main_node)

            result = client.repositories.rebase(
                repo.id,
                source_branch=feature.id,
                onto_branch=main_id,
                message="rebase feature onto main",
            )
            assert isinstance(result, RebaseResponse)
            assert result.success is True
        finally:
            if repo:
                try:
                    client.repositories.delete(repo.id)
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# 8. Rate limiting
# ---------------------------------------------------------------------------


class TestRateLimiting:
    def test_rapid_requests(self, client: Client):
        """Fire 50+ rapid requests to detect rate limiting behavior."""
        num_requests = 60
        results = {"success": 0, "rate_limited": 0, "errors": 0}
        first_429_at: int | None = None

        for i in range(num_requests):
            try:
                client.repositories.list(page_size=1)
                results["success"] += 1
            except RateLimitError:
                results["rate_limited"] += 1
                if first_429_at is None:
                    first_429_at = i
            except Exception:
                results["errors"] += 1

        # Report findings
        total = results["success"] + results["rate_limited"] + results["errors"]
        assert total == num_requests

        if results["rate_limited"] > 0:
            print(
                f"\n[Rate Limit] Hit 429 after {first_429_at} requests. "
                f"Total: {results['success']} ok, {results['rate_limited']} limited, "
                f"{results['errors']} errors out of {num_requests}."
            )
            # Verify retry logic eventually succeeds after rate limiting
            time.sleep(2)
            page = client.repositories.list(page_size=1)
            assert page.page == 1, "Request should succeed after rate limit cooldown"
        else:
            print(
                f"\n[Rate Limit] No 429s observed in {num_requests} rapid requests. "
                f"{results['success']} ok, {results['errors']} errors."
            )

        # The test passes either way — it's observational
        assert results["errors"] == 0, f"Unexpected errors: {results['errors']}"


# ---------------------------------------------------------------------------
# 9. Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_invalid_api_key(self):
        bad_client = Client(
            api_key="forge_INVALID_KEY_000000000000000000000",
            base_url=BASE_URL,
            verify=not _SKIP_SSL,
        )
        try:
            with pytest.raises(AuthenticationError):
                bad_client.auth.me()
        finally:
            bad_client.close()

    def test_bad_request_empty_name(self, client: Client):
        with pytest.raises(UnprocessableEntityError):
            client.repositories.create(name="", repo_type_key="TST")

    def test_not_found(self, client: Client):
        with pytest.raises(NotFoundError):
            client.repositories.get("00000000-0000-0000-0000-000000000000")


# ---------------------------------------------------------------------------
# 10. Auth — API Key Management
# ---------------------------------------------------------------------------


class TestApiKeyManagement:
    def test_api_key_lifecycle(self, client: Client):
        key_name = _unique("test-key")
        created = None
        try:
            # List existing keys
            keys_before = client.auth.list_api_keys()
            assert isinstance(keys_before, list)

            # Create
            created = client.auth.create_api_key(name=key_name)
            assert isinstance(created, ApiKeyCreated)
            assert created.name == key_name
            assert created.api_key  # the full key is returned only on creation

            # List again — new key should appear
            keys_after = client.auth.list_api_keys()
            ids_after = [k.id for k in keys_after]
            assert created.id in ids_after

            # Revoke
            revoked = client.auth.revoke_api_key(created.id)
            assert isinstance(revoked, MessageResponse)
            created = None  # mark cleaned up

            # Verify revoked key no longer active
            keys_final = client.auth.list_api_keys()
            active_ids = [k.id for k in keys_final if k.is_active]
            assert created is None or created.id not in active_ids
        finally:
            if created is not None:
                try:
                    client.auth.revoke_api_key(created.id)
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# 11. Auth — Profile Operations
# ---------------------------------------------------------------------------


class TestProfileOperations:
    def test_update_profile(self, client: Client):
        original = client.auth.me()
        original_name = original.name
        try:
            updated = client.auth.update_profile(display_name="SDK Test Name")
            assert isinstance(updated, User)
            assert updated.name == "SDK Test Name"

            # Verify via me()
            me = client.auth.me()
            assert me.name == "SDK Test Name"
        finally:
            # Restore original display name
            if original_name is not None:
                client.auth.update_profile(display_name=original_name)

    def test_get_public_user(self, client: Client):
        me = client.auth.me()
        public = client.auth.get_public_user(me.id)
        assert isinstance(public, User)
        assert public.id == me.id


# ---------------------------------------------------------------------------
# 12. Auth — Docs Session
# ---------------------------------------------------------------------------


class TestDocsSession:
    def test_create_docs_session(self, client: Client):
        # The endpoint returns 204 No Content. The SDK currently can't parse
        # empty responses, so we expect APIStatusError with status 204.
        # This still validates the endpoint is reachable and authenticates.
        from py_forge._exceptions import APIStatusError

        try:
            client.auth.create_docs_session()
        except APIStatusError as e:
            # 204 is success — the SDK just can't deserialize it
            assert "204" in str(e)


# ---------------------------------------------------------------------------
# 13. Branch Diff
# ---------------------------------------------------------------------------


class TestBranchDiff:
    def test_diff_between_branches(self, client: Client):
        repo = None
        try:
            repo = client.repositories.create(
                name=_unique("diff"), repo_type_key="TST"
            )
            page = client.branches.list(repo.id)
            main_id = page.data[0].id

            # Schema on main
            client.schemas.update(
                repo.id, main_id,
                schema_data=FOLDER_SCHEMA,
                commit_msg="init schema",
            )

            # Create feature branch and add a node
            feature = client.branches.create(
                repo.id, name="feature-diff", source_branch_id=main_id
            )
            client.nodes.create(
                repo.id, feature.id, node_data=_make_node_data("diff")
            )

            # Diff
            diff = client.branches.diff(
                repo.id, feature.id, target_branch_id=main_id
            )
            assert isinstance(diff, BranchDiff)
            assert diff.source_ahead >= 1
        finally:
            if repo:
                try:
                    client.repositories.delete(repo.id)
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# 14. Attachments
# ---------------------------------------------------------------------------


class TestAttachments:
    def test_attachment_lifecycle(self, client: Client, temp_repo):
        repo, _branch_id = temp_repo

        # Upload a small text file
        content = b"hello from SDK integration test"
        file = ("test-upload.txt", io.BytesIO(content), "text/plain")

        metadata = client.attachments.upload(file=file, repo_id=repo.id)
        assert isinstance(metadata, AttachmentMetadata)
        assert metadata.storage_path
        assert metadata.size_bytes == len(content)

        # Check exists
        exists_resp = client.attachments.exists(
            attachment_id=metadata.storage_path, repo_id=repo.id
        )
        assert isinstance(exists_resp, AttachmentExists)
        assert exists_resp.exists is True

        # Get download URL
        url_resp = client.attachments.get_url(
            attachment_id=metadata.storage_path, repo_id=repo.id
        )
        assert isinstance(url_resp, AttachmentUrl)
        assert url_resp.download_url

    def test_nonexistent_attachment(self, client: Client, temp_repo):
        repo, _branch_id = temp_repo
        exists_resp = client.attachments.exists(
            attachment_id="nonexistent-file-00000000", repo_id=repo.id
        )
        assert isinstance(exists_resp, AttachmentExists)
        assert exists_resp.exists is False


# ---------------------------------------------------------------------------
# 15. Node Media
# ---------------------------------------------------------------------------


class TestNodeMedia:
    def test_upload(self, client: Client, temp_repo):
        repo, _branch_id = temp_repo

        # Create a minimal 1x1 PNG
        png_bytes = (
            b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
            b"\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00"
            b"\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00"
            b"\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82"
        )
        file = ("test-media.png", io.BytesIO(png_bytes), "image/png")

        result = client.node_media.upload(file=file, repo_id=repo.id)
        assert isinstance(result, NodeMediaUpload)
        assert result.storage_path
        assert result.filename


# ---------------------------------------------------------------------------
# 16. Admin Operations
# ---------------------------------------------------------------------------


class TestAdminOperations:
    def test_list_users(self, client: Client):
        me = client.auth.me()
        if not me.is_superuser:
            pytest.skip("Current user is not a superuser")

        users = client.admin.list_users()
        assert isinstance(users, list)
        assert len(users) >= 1

    def test_set_superuser_noop(self, client: Client):
        """Toggle superuser status on self (set to current value) to verify endpoint works."""
        me = client.auth.me()
        if not me.is_superuser:
            pytest.skip("Current user is not a superuser")

        # Set to current value — no-op but validates the endpoint
        result = client.admin.set_superuser(me.id, is_superuser=me.is_superuser)
        assert isinstance(result, MessageResponse)
