from __future__ import annotations

import uuid

import pytest

from py_forge import (
    BadRequestError,
    Client,
    DeleteResponse,
    Node,
    NodeHistory,
    NotFoundError,
    Repository,
    SyncPage,
)

pytestmark = pytest.mark.integration


FOLDER_SCHEMA = {
    "classes": [
        {
            "@type": "Class",
            "@id": "Folder",
            "@inherits": "Node",
            "@metadata": {
                "node_type_key": "FLD",
                "displayname": {"singular": "Folder", "plural": "Folders"},
                "NodeOptions": {"type": "structure"},
                "ui": {"icon": {"name": "mdi:folder", "color": "#FFB300"}},
            },
        }
    ]
}


@pytest.fixture
def temp_repo(client: Client):
    """Create a temporary repository for testing and delete it on teardown."""
    unique_name = f"sdk-test-node-{uuid.uuid4()}"
    repo = client.repositories.create(
        name=unique_name,
        repo_type_key="EVC",
        description="SDK node integration test repo",
    )
    # Add concrete Folder class so we can create nodes
    page = client.branches.list(repo.id)
    default_bid = page.data[0].id
    client.schemas.update(repo.id, default_bid, schema_data=FOLDER_SCHEMA, commit_msg="Add Folder class")
    yield repo
    try:
        client.repositories.delete(repo.id)
    except Exception:
        pass


@pytest.fixture
def default_branch_id(client: Client, temp_repo: Repository) -> str:
    """Resolve the default (main) branch ID from the temp repo."""
    page = client.branches.list(temp_repo.id)
    for branch in page.data:
        if branch.is_default:
            return branch.id
    assert page.data, "Repository should have at least one branch"
    return page.data[0].id


def _make_node_data(suffix: str | None = None) -> dict:
    """Helper to create valid node data with unique @id."""
    tag = suffix or uuid.uuid4().hex[:8]
    return {
        "@type": "Folder",
        "doc_string": f"test node {tag}",
        "@id": f"Folder_test_{tag}",
    }


class TestNodeHappyPath:
    def test_create_node(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        node_data = _make_node_data()
        node = client.nodes.create(
            temp_repo.id, default_branch_id, node_data=node_data
        )
        assert isinstance(node, Node)
        assert node.id
        assert node.repository_id == temp_repo.id
        assert node.branch_id == default_branch_id
        assert isinstance(node.node, dict)

    def test_get_node(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        node_data = _make_node_data()
        created = client.nodes.create(
            temp_repo.id, default_branch_id, node_data=node_data
        )
        fetched = client.nodes.get(temp_repo.id, default_branch_id, created.id)
        assert isinstance(fetched, Node)
        assert fetched.id == created.id
        assert fetched.node.get("@type") == "Folder"

    def test_update_node(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        node_data = _make_node_data()
        created = client.nodes.create(
            temp_repo.id, default_branch_id, node_data=node_data
        )
        updated_data = {
            "@type": "Folder",
            "@id": created.id,
            "doc_string": "updated description",
        }
        updated = client.nodes.update(
            temp_repo.id, default_branch_id, created.id, node_data=updated_data
        )
        assert isinstance(updated, Node)
        # Verify the update persists
        fetched = client.nodes.get(temp_repo.id, default_branch_id, created.id)
        assert fetched.node.get("doc_string") == "updated description"

    def test_list_nodes(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        # Create 2 nodes
        for _ in range(2):
            client.nodes.create(
                temp_repo.id, default_branch_id, node_data=_make_node_data()
            )
        page = client.nodes.list(temp_repo.id, default_branch_id)
        assert isinstance(page, SyncPage)
        assert page.total_count >= 2
        assert len(page.data) >= 2
        for node in page.data:
            assert isinstance(node, Node)
            assert node.repository_id == temp_repo.id
            assert node.branch_id == default_branch_id

    def test_delete_node(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        node_data = _make_node_data()
        created = client.nodes.create(
            temp_repo.id, default_branch_id, node_data=node_data
        )
        result = client.nodes.delete(temp_repo.id, default_branch_id, created.id)
        assert isinstance(result, DeleteResponse)
        assert result.deleted is True
        # Subsequent get should fail
        with pytest.raises(NotFoundError) as exc_info:
            client.nodes.get(temp_repo.id, default_branch_id, created.id)
        assert exc_info.value.status_code == 404
        assert exc_info.value.message


class TestNodeErrors:
    def test_get_nonexistent_node(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.nodes.get(
                temp_repo.id, default_branch_id, "Folder_nonexistent_node_id"
            )
        assert exc_info.value.status_code == 404
        assert exc_info.value.message

    def test_create_node_on_nonexistent_branch(
        self, client: Client, temp_repo: Repository
    ) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            client.nodes.create(
                temp_repo.id,
                "00000000-0000-0000-0000-000000000000",
                node_data=_make_node_data(),
            )
        assert exc_info.value.status_code == 404
        assert exc_info.value.message

    def test_update_node_missing_required_fields(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        created = client.nodes.create(
            temp_repo.id, default_branch_id, node_data=_make_node_data()
        )
        # Update with incomplete data (missing @type and doc_string)
        with pytest.raises(BadRequestError) as exc_info:
            client.nodes.update(
                temp_repo.id,
                default_branch_id,
                created.id,
                node_data={"@id": created.id},
            )
        assert exc_info.value.status_code == 400
        assert exc_info.value.message


class TestNodeEdgeCases:
    def test_node_history_after_updates(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        node_data = _make_node_data()
        created = client.nodes.create(
            temp_repo.id, default_branch_id, node_data=node_data
        )
        # Update twice
        for i in range(2):
            client.nodes.update(
                temp_repo.id,
                default_branch_id,
                created.id,
                node_data={
                    "@type": "Folder",
                    "@id": created.id,
                    "doc_string": f"update {i}",
                },
            )
        history = client.nodes.get_history(
            temp_repo.id, default_branch_id, created.id
        )
        assert isinstance(history, NodeHistory)
        assert history.total_count >= 2
        assert len(history.commits) >= 2

    def test_node_history_empty_for_new_repo(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        node_data = _make_node_data()
        created = client.nodes.create(
            temp_repo.id, default_branch_id, node_data=node_data
        )
        history = client.nodes.get_history(
            temp_repo.id, default_branch_id, created.id
        )
        assert isinstance(history, NodeHistory)
        assert history.total_count == 1
        assert len(history.commits) == 1

    def test_list_nodes_empty_branch(
        self, client: Client, temp_repo: Repository
    ) -> None:
        # Create a fresh branch with no nodes
        branch = client.branches.create(temp_repo.id, name="empty-branch")
        try:
            page = client.nodes.list(temp_repo.id, branch.id)
            assert isinstance(page, SyncPage)
            assert page.total_count == 0
            assert len(page.data) == 0
        finally:
            try:
                client.branches.delete(temp_repo.id, branch.id)
            except Exception:
                pass

    def test_list_nodes_pagination(
        self, client: Client, temp_repo: Repository, default_branch_id: str
    ) -> None:
        # Create 3 nodes
        for _ in range(3):
            client.nodes.create(
                temp_repo.id, default_branch_id, node_data=_make_node_data()
            )
        page = client.nodes.list(temp_repo.id, default_branch_id, page_size=1)
        assert page.page == 1
        assert page.page_size == 1
        assert page.total_count >= 3
        assert page.has_next_page
