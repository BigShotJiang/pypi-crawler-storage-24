from napari.utils.notifications import show_info

__version__ = "1.0.0"

def show_hello_message():
    show_info(f'napari-stereoTis v{__version__}')