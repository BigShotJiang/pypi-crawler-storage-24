"""
MuBit Learn Anthropic Wrapper.

Extends the existing auto-capture Anthropic wrapper with pre-call lesson
retrieval and injection into the Anthropic `system` parameter.
"""

import inspect
import logging
from typing import Any, Optional

from mubit.auto._anthropic import wrap_anthropic
from mubit.learn._client import LearnClient
from mubit.learn._config import LearnConfig
from mubit.learn._injection import extract_query, inject_context_anthropic
from mubit.learn._lesson_cache import LessonCache
from mubit.learn._run_manager import RunManager

logger = logging.getLogger("mubit.learn")


def wrap_anthropic_learn(
    client: Any,
    *,
    learn_config: LearnConfig,
    lesson_cache: LessonCache,
    learn_client: LearnClient,
    run_manager: RunManager,
    session_id: str = "",
    agent_id: str = "auto",
    user_id: str = "",
    capture: str = "all",
    min_length: int = 0,
    mubit_api_key: Optional[str] = None,
    mubit_endpoint: Optional[str] = None,
) -> Any:
    """Wrap an Anthropic client with learn (inject + ingest) capabilities."""
    if not hasattr(client, "messages") or not hasattr(client.messages, "create"):
        return client

    if getattr(client, "_mubit_learn_wrapped", None) is True:
        return client

    # Apply auto-capture wrapping first
    wrap_anthropic(
        client,
        session_id=session_id,
        agent_id=agent_id,
        user_id=user_id,
        capture=capture,
        min_length=min_length,
        mubit_api_key=mubit_api_key,
        mubit_endpoint=mubit_endpoint,
    )

    auto_create = client.messages.create
    is_async = inspect.iscoroutinefunction(auto_create)
    val = getattr(auto_create, "_is_coroutine", None)
    if not is_async and val is True:
        is_async = True

    def _enrich_kwargs(kwargs):
        """Inject context into the Anthropic system parameter."""
        if not learn_config.inject_lessons:
            return kwargs

        messages = kwargs.get("messages", [])
        query = extract_query(messages)
        if not query:
            return kwargs

        context_block = lesson_cache.get(run_manager.session_id, query)
        if context_block is None:
            try:
                context_block = learn_client.get_context(
                    session_id=run_manager.session_id,
                    query=query,
                    max_token_budget=learn_config.max_token_budget,
                    entry_types=learn_config.entry_types,
                    sections=learn_config.context_sections,
                )
                lesson_cache.set(run_manager.session_id, query, context_block)
            except Exception as e:
                if learn_config.fail_open:
                    logger.debug("mubit.learn context fetch failed: %s", e)
                    context_block = ""
                else:
                    raise

        if context_block:
            kwargs = dict(kwargs)
            kwargs["system"] = inject_context_anthropic(
                kwargs.get("system"), context_block
            )

        return kwargs

    if is_async:
        async def learn_create(*args, **kwargs):
            kwargs = _enrich_kwargs(kwargs)
            result = await auto_create(*args, **kwargs)
            run_manager.increment()
            return result

        client.messages.create = learn_create
    else:
        def learn_create(*args, **kwargs):
            kwargs = _enrich_kwargs(kwargs)
            result = auto_create(*args, **kwargs)
            run_manager.increment()
            return result

        client.messages.create = learn_create

    client._mubit_learn_wrapped = True
    return client
