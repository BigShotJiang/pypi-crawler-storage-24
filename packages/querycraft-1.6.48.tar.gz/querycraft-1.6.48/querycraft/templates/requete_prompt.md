# Instructions

L'élève propose *la requête SQL* suivante :
```sql
{{sec_start}}
{{requete}}
{{sec_end}}
```

Indique de manière synthétique l'objectif fonctionnel de cette requête. 
