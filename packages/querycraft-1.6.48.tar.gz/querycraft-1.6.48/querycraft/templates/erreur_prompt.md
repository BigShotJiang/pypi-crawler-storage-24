# Instructions

L'élève propose *une erreur sur une requête SQL*. Tu es chargé de l'aider à comprendre son erreur. S'il y a des erreurs, elles viennent *nécessairement* de la requête.

L'erreur est la suivante :
```sql
{{sec_start_err}}
{{erreur}}
{{sec_end_err}}
```

Voici la requête SQL qui a généré cette erreur : 
```sql
-- Requête qui a généré l'erreur
{{sec_start_req_err}}
{{requete_err}}
{{sec_end_req_err}}
```

{‰ if requete_err is defined  ‰}
La requête attendue était :
```sql
-- Requête que l'élève aurait dû proposer
{{sec_start_req}}
{{requete}}
{{sec_end_req}}
```
{‰ endif ‰}

Explique l'erreur et propose une correction.
