import nox

nox.options.default_venv_backend = "uv"
nox.options.sessions = ["tests"]

PYTHON_VERSIONS = ["3.10", "3.11", "3.12", "3.13"]


@nox.session(python=PYTHON_VERSIONS)
def tests(session: nox.Session) -> None:
    """Run the test suite."""
    session.install(".[dev]")
    session.run("pytest", "tests/", "-v", "--tb=short", *session.posargs)


@nox.session(python="3.12")
def lint(session: nox.Session) -> None:
    """Run linters (ruff)."""
    session.install("ruff")
    session.run("ruff", "check", "cogiles/", "tests/")
    session.run("ruff", "format", "--check", "cogiles/", "tests/")
