# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2026-03-13

### Added

- SMARTS-like subgraph pattern matching via `cogiles.find_pattern()` with support for wildcards (`*`), color sets (`[RBG]`), and negated sets (`[!RBG]`)
- `cogiles.parse_pattern()` for parsing pattern strings into pattern graphs
- `Match` dataclass with `mapping` and `nodes` properties for inspecting match results
- `cogiles.draw_matches()` for visualizing pattern matches with colored node halos and edge highlights
- Multi-color highlight support by chaining `draw_matches()` calls on the same axes
- Example notebook `examples/01_pattern_matching.ipynb` showcasing pattern matching and visualization

## [0.2.0] - 2026-03-13

### Added

- ECFP-style circular fingerprints for colored graphs via `cogiles.fingerprint()`
- `FingerprintGenerator` class for reusable, configurable fingerprint generation (custom `radius` and `nbits`)
- Jaccard (Tanimoto) similarity via `cogiles.jaccard_similarity()` — accepts COGILES strings, NetworkX graphs, or pre-computed fingerprints
- Fingerprint and similarity sections in the quickstart notebook

## [0.1.0] - 2026-03-09

Initial version.

### Added

- COGILES parser: convert COGILES strings to NetworkX graphs via `cogiles.parse()`
- COGILES encoder: convert NetworkX graphs to COGILES strings via `cogiles.encode()`
- Graph visualization with `cogiles.draw()`
- Color definitions for node/edge coloring
- Custom error types: `CogilesParseError`, `CogilesEncodeError`
- Version management via `VERSION` file and `cogiles.get_version()`
