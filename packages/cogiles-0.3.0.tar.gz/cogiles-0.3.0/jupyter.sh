#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

uv run jupyter lab --port 8888 --IdentityProvider.token cogiles-token --ip 0.0.0.0
