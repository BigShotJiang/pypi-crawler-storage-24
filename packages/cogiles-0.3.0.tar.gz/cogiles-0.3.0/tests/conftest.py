import pytest
import networkx as nx


@pytest.fixture
def simple_chain():
    """A chain of 3 red nodes: RRR"""
    G = nx.Graph()
    for i in range(3):
        G.add_node(i, color=(1.0, 0.0, 0.0), symbol="R", color_name="red")
    G.add_edge(0, 1)
    G.add_edge(1, 2)
    return G


@pytest.fixture
def simple_cycle():
    """A cycle of 6 red nodes: R-1RRRRR-1"""
    G = nx.Graph()
    for i in range(6):
        G.add_node(i, color=(1.0, 0.0, 0.0), symbol="R", color_name="red")
    for i in range(5):
        G.add_edge(i, i + 1)
    G.add_edge(5, 0)
    return G


@pytest.fixture
def disconnected_graph():
    """Two disconnected components: RR.BB"""
    G = nx.Graph()
    G.add_node(0, color=(1.0, 0.0, 0.0), symbol="R", color_name="red")
    G.add_node(1, color=(1.0, 0.0, 0.0), symbol="R", color_name="red")
    G.add_node(2, color=(0.0, 0.0, 1.0), symbol="B", color_name="blue")
    G.add_node(3, color=(0.0, 0.0, 1.0), symbol="B", color_name="blue")
    G.add_edge(0, 1)
    G.add_edge(2, 3)
    return G
