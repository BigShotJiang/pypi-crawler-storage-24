"""Custom exception types for the cogiles library."""

from __future__ import annotations


class CogilesParseError(Exception):
    """Raised when a COGILES string cannot be parsed.

    Attributes:
        text: The original COGILES string that failed to parse.
        position: 0-based character offset where the error was detected, or None.
    """

    def __init__(
        self,
        message: str,
        text: str = "",
        position: int | None = None,
    ):
        self.text = text
        self.position = position
        if position is not None and text:
            pointer = " " * position + "^"
            full = f"{message}\n  {text}\n  {pointer}"
        else:
            full = message
        super().__init__(full)


class CogilesEncodeError(Exception):
    """Raised when encoding a graph fails.

    Attributes:
        node: The node index that caused the error, or None.
        color: The RGB tuple that could not be matched, or None.
    """

    def __init__(
        self,
        message: str,
        node: int | None = None,
        color: tuple[float, float, float] | None = None,
    ):
        self.node = node
        self.color = color
        super().__init__(message)
