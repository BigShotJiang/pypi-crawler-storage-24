from pathlib import Path


def get_version() -> str:
    """Return the version string from the VERSION file."""
    version_file = Path(__file__).resolve().parent.parent / "VERSION"
    try:
        return version_file.read_text().strip()
    except FileNotFoundError:
        from importlib.metadata import version

        return version("cogiles")
