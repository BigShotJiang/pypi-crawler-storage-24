"""
COGILES - Colored Graph Input Line Entry System

A SMILES-inspired string notation for colored graphs.

Usage::

    import cogiles

    G = cogiles.parse("R-1RRRRR-1")      # COGILES string -> nx.Graph
    s = cogiles.encode(G)                 # nx.Graph -> COGILES string
    s = cogiles.encode(G, strict=True)    # raises on unknown colors

"""

from cogiles.parser import parse
from cogiles.encoder import encode
from cogiles.fingerprint import fingerprint, FingerprintGenerator, jaccard_similarity
from cogiles.visualization import draw, draw_matches
from cogiles.pattern import find_pattern, parse_pattern, Match
from cogiles.errors import CogilesParseError, CogilesEncodeError
from cogiles.colors import COLORS
from cogiles.utils import get_version

__all__ = [
    "parse",
    "encode",
    "fingerprint",
    "FingerprintGenerator",
    "jaccard_similarity",
    "draw",
    "draw_matches",
    "find_pattern",
    "parse_pattern",
    "Match",
    "CogilesParseError",
    "CogilesEncodeError",
    "COLORS",
    "get_version",
]

__version__ = get_version()
