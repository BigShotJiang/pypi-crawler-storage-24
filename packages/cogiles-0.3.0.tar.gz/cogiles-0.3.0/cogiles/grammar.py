"""PEG grammar definition for the COGILES string format."""

import parsimonious

cogiles_grammar = parsimonious.Grammar(
    r"""
    graph           = (branch / node / anchor / break)*

    branch_node     = (break_node / node) branch+
    anchor_node     = (branch_node / break_node / node) anchor+
    break_node      = break node

    branch          = lpar graph rpar
    lpar            = "("
    rpar            = ")"

    break           = "."
    anchor          = ~r"-[\d]+"
    node            = ~r"(Bl|Br|Gr|Pi|Ol|[RGBYKCMWOPTLI])"
    """
)
