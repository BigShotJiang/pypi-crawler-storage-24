"""Temporary script to generate the README example image."""

import matplotlib.pyplot as plt
import cogiles

examples = [
    "R(G)(B)(Y)",
    "R-1GBY-1",
    "R(GB(C))(Y(OM))",
    "RG.BY.CM",
]

fig, axes = plt.subplots(1, 4, figsize=(16, 4))

for ax, s in zip(axes, examples):
    cogiles.draw(s, ax=ax, labels="symbol", node_size=500)
    ax.set_title(s, fontsize=14, fontfamily="monospace", pad=10)

fig.tight_layout()
fig.savefig("docs/examples.png", dpi=150, bbox_inches="tight", facecolor="white")
print("Saved docs/examples.png")
