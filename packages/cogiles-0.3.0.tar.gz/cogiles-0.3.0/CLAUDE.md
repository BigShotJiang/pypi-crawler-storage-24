# Claude Code Instructions

## Package Management

- Use `uv pip install` for all package installations (not plain `pip install`).

## Python Environment

- Always use the `.venv` virtual environment (run commands via `.venv/bin/python` or activate it first).
- Use `uv pip install` for installing packages into the venv.
