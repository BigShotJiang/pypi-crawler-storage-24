"""
CLI entrypoint for Prajnyavan.

Goals:
- `prajnyavan dev` starts the bundled service as a background daemon (no Docker).
- `status`, `stop`, `reset` manage the local daemon and cache.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional
import threading

import requests

from .client import (
    BASE_DIR,
    DEV_CONFIG,
    MODEL_CACHE_DIR,
    PID_FILE,
    DEFAULT_BIND_ADDR,
    DEFAULT_START_PORT,
    MAX_PORT_RETRIES,
    _load_dev_config,
    _save_dev_config,
    get_token,
    _ensure_local_model,
)


def _platform_dir() -> str:
    system = platform.system().lower()
    if system.startswith("linux"):
        return "linux"
    if system.startswith("darwin"):
        return "macos"
    if system.startswith("windows"):
        return "windows"
    return system


def _binary_path() -> Path:
    name = "prajnyavan_service.exe" if platform.system().lower().startswith("windows") else "prajnyavan_service"
    path = Path(__file__).resolve().parent / "bin" / _platform_dir() / name
    return path


def _pid_is_alive(pid: int) -> bool:
    try:
        if platform.system().lower().startswith("windows"):
            # On Windows, os.kill with 0 is supported from Python 3.2+
            os.kill(pid, 0)
        else:
            os.kill(pid, 0)
        return True
    except OSError:
        return False


def _find_free_port(start: int = DEFAULT_START_PORT) -> int:
    for i in range(MAX_PORT_RETRIES):
        port = start + i
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind((DEFAULT_BIND_ADDR, port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"Could not find a free port after {MAX_PORT_RETRIES} attempts starting at {start}")


def _wait_for_health(url: str, timeout: float = 30.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = requests.get(url, timeout=2)
            if r.ok:
                return True
        except Exception:
            pass
        time.sleep(0.5)
    return False


def cmd_dev(args: argparse.Namespace) -> int:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    binary = _binary_path()
    if not binary.exists():
        print(
            f"[prajnyavan] Bundled service binary not found at {binary}.\n"
            "Reinstall the wheel or build the service binary.",
            file=sys.stderr,
        )
        return 1

    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            if _pid_is_alive(pid):
                cfg = _load_dev_config() or {}
                print(f"[prajnyavan] Already running (pid={pid}, url={cfg.get('base_url', 'unknown')}).")
                return 0
        except Exception:
            PID_FILE.unlink(missing_ok=True)

    secret = os.environ.get("BRAIN_SECRET_KEY")
    if not secret:
        import secrets

        secret = secrets.token_urlsafe(32)

    port = _find_free_port()
    env = os.environ.copy()
    env["BRAIN_SECRET_KEY"] = secret
    env.setdefault("BIND_ADDR", DEFAULT_BIND_ADDR)
    env["PORT"] = str(port)

    # Store data under ~/.prajnyavan
    workdir = str(BASE_DIR)

    creationflags = 0
    if platform.system().lower().startswith("windows"):
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]

    proc = subprocess.Popen(
        [str(binary)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        cwd=workdir,
        env=env,
        creationflags=creationflags,
    )
    PID_FILE.write_text(str(proc.pid))

    base_url = f"http://{DEFAULT_BIND_ADDR}:{port}"
    if not _wait_for_health(f"{base_url}/health", timeout=30):
        print("[prajnyavan] Service failed to become healthy within 30s.", file=sys.stderr)
        return 1

    token = get_token(base_url)
    cfg = {
        "base_url": base_url,
        "port": port,
        "pid": proc.pid,
        "token": token,
        "started_at": int(time.time()),
    }
    _save_dev_config(cfg)

    # Warm the default local model in the background so first request is fast.
    if not os.environ.get("OPENAI_API_KEY") and not os.environ.get("COHERE_API_KEY"):
        threading.Thread(target=_ensure_local_model, kwargs={"model_name": "all-MiniLM-L6-v2"}, daemon=True).start()

    snippet = (
        "from prajnyavan import auto_client\n"
        "mem = auto_client(user_id=\"user_123\")\n"
        "@mem.wrap_llm(user_id=\"user_123\")\n"
        "def chat(prompt):\n"
        "    return \"Your LLM call here\"\n"
    )

    print(f"[prajnyavan] running at {base_url} (pid={proc.pid})")
    print("[prajnyavan] paste this snippet into your app:\n")
    print(snippet)
    return 0


def cmd_status(_: argparse.Namespace) -> int:
    cfg = _load_dev_config()
    if not cfg:
        print("[prajnyavan] No dev config found. Run `prajnyavan dev` first.", file=sys.stderr)
        return 1
    pid = cfg.get("pid")
    alive = _pid_is_alive(pid) if pid else False
    health = False
    if alive:
        try:
            r = requests.get(f"{cfg['base_url']}/health", timeout=2)
            health = r.ok
        except Exception:
            health = False

    print(f"base_url: {cfg.get('base_url')}")
    print(f"pid: {pid} (alive={alive})")
    print(f"health: {'ok' if health else 'unreachable'}")
    model_cache = MODEL_CACHE_DIR.exists()
    cache_size = sum(p.stat().st_size for p in MODEL_CACHE_DIR.rglob("*")) if model_cache else 0
    print(f"model cache: {'present' if model_cache else 'missing'} ({cache_size/1_048_576:.1f} MB)")
    return 0 if alive and health else 1


def _kill_pid(pid: int) -> None:
    if platform.system().lower().startswith("windows"):
        subprocess.run(["taskkill", "/PID", str(pid), "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        os.kill(pid, signal.SIGTERM)


def cmd_stop(_: argparse.Namespace) -> int:
    if not PID_FILE.exists():
        print("[prajnyavan] No running daemon found.")
        return 0
    try:
        pid = int(PID_FILE.read_text().strip())
    except Exception:
        PID_FILE.unlink(missing_ok=True)
        return 0

    if _pid_is_alive(pid):
        _kill_pid(pid)
        time.sleep(0.5)
    PID_FILE.unlink(missing_ok=True)
    print("[prajnyavan] stopped.")
    return 0


def cmd_reset(_: argparse.Namespace) -> int:
    cmd_stop(_)
    if BASE_DIR.exists():
        shutil.rmtree(BASE_DIR, ignore_errors=True)
    print("[prajnyavan] reset: cleared data and model cache.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="prajnyavan", description="Prajnyavan CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("dev", help="Start local daemon")
    sub.add_parser("status", help="Show daemon status")
    sub.add_parser("stop", help="Stop daemon")
    sub.add_parser("reset", help="Stop and clear local data/cache")

    args = parser.parse_args()

    if args.cmd == "dev":
        return cmd_dev(args)
    if args.cmd == "status":
        return cmd_status(args)
    if args.cmd == "stop":
        return cmd_stop(args)
    if args.cmd == "reset":
        return cmd_reset(args)

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
