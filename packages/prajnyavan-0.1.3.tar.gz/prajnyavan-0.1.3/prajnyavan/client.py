"""
Prajnyavan SDK — Phase 1
------------------------
Persistent, emotionally-weighted memory for any LLM.

Quick start:
    from prajnyavan import MemoryClient
    import openai

    mem = MemoryClient(
        base_url="http://localhost:9999",
        token="Bearer <your-token>",
        openai_api_key="sk-..."   # for embeddings
    )

    @mem.wrap_llm(user_id="user_123")
    def chat(prompt):
        return openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}]
        ).choices[0].message.content

    chat("My dog Bruno loves long walks")
    chat("What should I get Bruno?")  # AI already knows Bruno is a dog
"""

from __future__ import annotations

import functools
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
import inspect

import requests

# ── Paths & defaults ────────────────────────────────────────────────────────────
BASE_DIR = Path.home() / ".prajnyavan"
DEV_CONFIG = BASE_DIR / "dev.json"
MODEL_CACHE_DIR = BASE_DIR / "models"
PID_FILE = BASE_DIR / "prajnyavan.pid"
DEFAULT_BIND_ADDR = "127.0.0.1"
DEFAULT_START_PORT = 9999
MAX_PORT_RETRIES = 10

# Keep a cached local model per model_name to avoid repeated loads.
_LOCAL_MODELS: Dict[str, Any] = {}
EMBED_DIM = 768


def _load_dev_config() -> Optional[Dict[str, Any]]:
    if not DEV_CONFIG.exists():
        return None
    try:
        return json.loads(DEV_CONFIG.read_text())
    except Exception:
        return None


def _save_dev_config(data: Dict[str, Any]) -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    DEV_CONFIG.write_text(json.dumps(data, indent=2))


# ── Embedding providers ────────────────────────────────────────────────────

def _fit_embedding(vec: List[float]) -> List[float]:
    """Resize any embedding to EMBED_DIM by sampling."""
    if len(vec) == EMBED_DIM:
        return vec
    out = [0.0] * EMBED_DIM
    n = len(vec)
    for i in range(EMBED_DIM):
        src = int(i * n / EMBED_DIM)
        out[i] = float(vec[src])
    return out


def _embed_openai(text: str, api_key: str, model: str = "text-embedding-3-small") -> List[float]:
    """Real semantic embedding via OpenAI. ~50ms, costs ~$0.00002/1K tokens."""
    import openai
    client = openai.OpenAI(api_key=api_key)
    response = client.embeddings.create(model=model, input=text)
    return _fit_embedding(response.data[0].embedding)


def _embed_cohere(text: str, api_key: str, model: str = "embed-english-v3.0") -> List[float]:
    """Real semantic embedding via Cohere."""
    import cohere
    co = cohere.Client(api_key)
    response = co.embed(texts=[text], model=model, input_type="search_document")
    return _fit_embedding(response.embeddings[0])


def _ensure_local_model(model_name: str) -> Any:
    """Load/cached local model, downloading once into ~/.prajnyavan/models."""
    if model_name in _LOCAL_MODELS:
        return _LOCAL_MODELS[model_name]

    MODEL_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer(model_name, cache_folder=str(MODEL_CACHE_DIR))
        _LOCAL_MODELS[model_name] = model
        return model
    except Exception:
        # Fallback to None; caller will use hash embedding to stay zero-dependency.
        _LOCAL_MODELS[model_name] = None
        return None


def _hash_embed(text: str) -> List[float]:
    """Deterministic hash-based embedding (fallback when transformers/torch unavailable)."""
    out = [0.0] * EMBED_DIM
    h = 14695981039346656037  # FNV-1a offset
    for b in text.encode("utf-8"):
        h ^= b
        h = (h * 1099511628211) & 0xFFFFFFFFFFFFFFFF
        idx = h % EMBED_DIM
        out[idx] = min(1.0, out[idx] + b / 255.0)
    return out


def _embed_local(text: str, model_name: str = "all-mpnet-base-v2") -> List[float]:
    """Free local embedding using sentence-transformers. No API key needed."""
    model = _ensure_local_model(model_name)
    if model is None:
        return _hash_embed(text)
    return _fit_embedding(model.encode(text).tolist())


# ── Main client ────────────────────────────────────────────────────────────

class MemoryClient:
    """
    Prajnyavan memory client.

    Parameters
    ----------
    base_url : str, optional
        URL of the running prajnyavan_service. Optional if `prajnyavan dev` has been started.
    token : str, optional
        Bearer token from /auth/token. Optional if `prajnyavan dev` has been started (auto-discovered).
    openai_api_key : str, optional
        OpenAI API key for embedding generation (used when embedding_provider="openai").
    embedding_provider : str
        "local" (default) | "openai" | "cohere"
    embedding_model : str, optional
        Override the default model for your chosen provider.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        embedding_provider: str = "local",
        embedding_model: Optional[str] = None,
    ):
        if base_url is None or token is None:
            cfg = _load_dev_config()
            if not cfg:
                raise ValueError(
                    "base_url and token are required unless prajnyavan dev has been started. "
                    "Run `prajnyavan dev` or pass base_url/token explicitly."
                )
            base_url = base_url or cfg["base_url"]
            token = token or cfg["token"]

        self.base_url = base_url.rstrip("/")
        self.token = token
        self.embedding_provider = embedding_provider
        self.embedding_model = embedding_model

        # Resolve API key from parameter or environment
        self._openai_key = openai_api_key or os.environ.get("OPENAI_API_KEY")

        self.session = requests.Session()
        self.session.headers.update({
            "authorization": token,
            "content-type": "application/json",
        })

    def embed(self, text: str) -> List[float]:
        """
        Convert text to a vector embedding.
        This is the ONLY place embeddings are generated — keeps it swappable.
        """
        if self.embedding_provider == "openai":
            if not self._openai_key:
                raise ValueError(
                    "OpenAI API key required. Pass openai_api_key=... or set OPENAI_API_KEY env var."
                )
            model = self.embedding_model or "text-embedding-3-small"
            return _embed_openai(text, self._openai_key, model)

        elif self.embedding_provider == "cohere":
            cohere_key = os.environ.get("COHERE_API_KEY", "")
            model = self.embedding_model or "embed-english-v3.0"
            return _embed_cohere(text, cohere_key, model)

        elif self.embedding_provider == "local":
            model = self.embedding_model or "all-MiniLM-L6-v2"
            return _embed_local(text, model)

        else:
            raise ValueError(f"Unknown embedding provider: {self.embedding_provider}")

    # ── Core memory API ───────────────────────────────────────────────────

    def store(
        self,
        user_id: str,
        content: str,
        *,
        importance: Optional[float] = None,
        category: Optional[str] = None,
        ttl_days: Optional[int] = None,
        tags: Optional[List[str]] = None,
    ) -> str:
        """
        Store a memory for a user.

        The content is embedded here in Python (real semantic embedding),
        then sent to the Rust service with the vector attached.
        This means the Rust service never needs to call an external API.

        Returns the memory ID (UUID string).
        """
        # Generate real embedding
        embedding = self.embed(content)

        payload: Dict[str, Any] = {
            "content": content,
            "modality": "text",
            "user_id": user_id,
            "embedding": embedding,   # <-- real vector, not a hash
            "tags": tags or [],
        }
        if importance is not None:
            payload["importance"] = float(importance)
        if category:
            payload["category"] = category
        if ttl_days:
            payload["ttl_days"] = ttl_days

        resp = self.session.post(
            f"{self.base_url}/memory",
            data=json.dumps(payload),
            timeout=10
        )
        resp.raise_for_status()
        return resp.json()["id"]

    def search(
        self,
        user_id: str,
        query: str,
        *,
        k: int = 5,
        valence_bias: Optional[str] = None,  # "positive" | "negative"
        min_importance: Optional[float] = None,
        category: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Search for relevant memories for a user.

        The query is embedded here in Python, then sent to the Rust service.
        Returns top-k memories ranked by: vector_similarity × (1 + importance) × recency_decay
        """
        # Generate real embedding for the query
        embedding = self.embed(query)

        payload: Dict[str, Any] = {
            "query": query,
            "embedding": embedding,   # <-- real vector for semantic search
            "k": k,
            "filters": {"person": user_id},
        }
        if valence_bias:
            payload["filters"]["valence_bias"] = valence_bias
        if min_importance is not None:
            payload["filters"]["min_importance"] = min_importance
        if category:
            payload["filters"]["category"] = category

        resp = self.session.post(
            f"{self.base_url}/memory/search",
            data=json.dumps(payload),
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("results", [])

    def delete_user(self, user_id: str) -> int:
        """Delete ALL memories for a user. GDPR Article 17 compliance."""
        resp = self.session.delete(
            f"{self.base_url}/memory/user/{user_id}",
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("deleted", 0)

    def export_user(self, user_id: str) -> List[Dict[str, Any]]:
        """Export all memories for a user as JSON. GDPR Article 20 compliance."""
        resp = self.session.get(
            f"{self.base_url}/memory/export/{user_id}",
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("memories", [])

    def highlights(self, user_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Return the top-N most emotionally important memories for a user."""
        resp = self.session.get(
            f"{self.base_url}/memory/highlights/{user_id}",
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("highlights", [])[:limit]

    def summary(self, user_id: str, days: int = 7) -> str:
        """Return a natural language summary of a user's recent memories."""
        resp = self.session.get(
            f"{self.base_url}/memory/summary/{user_id}",
            params={"days": days},
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("summary", "")

    def explain(self, query: str) -> List[Dict[str, Any]]:
        """
        Debug tool: shows which memories would be retrieved for a query
        and why each one scored the way it did.
        """
        embedding = self.embed(query)
        payload = {"query": query, "embedding": embedding, "k": 5}
        resp = self.session.post(
            f"{self.base_url}/memory/explain",
            data=json.dumps(payload),
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("results", [])

    # ── Decorator ─────────────────────────────────────────────────────────

    def wrap_llm(
        self,
        user_id: str,
        *,
        k: int = 5,
        valence_bias: Optional[str] = None,
        debug: bool = False,
    ):
        """
        Decorator that gives any LLM function persistent memory.

        Works with OpenAI, Claude, Gemini, Perplexity — any LLM.
        The same user_id works across all of them.

        What happens automatically:
          1. Before LLM call: retrieves top-k relevant memories, injects into prompt
          2. After LLM call: stores the interaction as a new memory (async)

        Example:
            @mem.wrap_llm(user_id="user_123")
            def chat(prompt):
                return openai_client.chat(prompt)

        debug=True returns {"result": ..., "memories_used": [...]} instead of just the string.
        """
        def decorator(fn: Callable[..., str]):
            @functools.wraps(fn)
            def wrapper(prompt: str, *args, **kwargs):
                # Step 1: retrieve relevant memories
                memories = self.search(user_id, prompt, k=k, valence_bias=valence_bias)

                # Step 2: build enriched prompt
                if memories:
                    ctx_lines = [
                        f"- ({m.get('importance', 0):.2f} importance) {m.get('content_text') or m.get('content', '')}"
                        for m in memories
                    ]
                    enriched = (
                        "Relevant memories about this user:\n"
                        + "\n".join(ctx_lines)
                        + "\n\nUser message: "
                        + prompt
                    )
                else:
                    enriched = prompt

                # Step 3: call the LLM with memory context without mutating the
                # original prompt. If the wrapped function declares a
                # `memory_context` or `enriched_prompt` parameter (or accepts
                # **kwargs), pass those along so callers can opt‑in to richer
                # context. Otherwise, keep the call signature unchanged to avoid
                # surprising prompt mutations.
                sig = inspect.signature(fn)
                accepts_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
                call_kwargs = dict(kwargs)

                if accepts_kwargs or "memory_context" in sig.parameters:
                    call_kwargs.setdefault("memory_context", memories)
                if accepts_kwargs or "enriched_prompt" in sig.parameters:
                    call_kwargs.setdefault("enriched_prompt", enriched)

                result = fn(prompt, *args, **call_kwargs)

                # Step 4: store this interaction as a new memory
                # (fire and forget — doesn't block the response)
                try:
                    interaction = f"User said: {prompt}"
                    self.store(user_id, interaction)
                except Exception:
                    pass  # never crash the LLM call because of memory storage

                if debug:
                    return {"result": result, "memories_used": memories}
                return result

            return wrapper
        return decorator


# ── Helper: get a token from the service ──────────────────────────────────

def get_token(base_url: str, user_id: str = "developer") -> str:
    """
    Get a bearer token from the service.
    Use this once at startup and pass the token to MemoryClient.

    Example:
        token = get_token("http://localhost:9999")
        mem = MemoryClient(base_url="http://localhost:9999", token=token)
    """
    resp = requests.post(
        f"{base_url.rstrip('/')}/auth/token",
        json={"user_id": user_id, "capabilities": ["read", "write"]},
        timeout=8
    )
    resp.raise_for_status()
    return f"Bearer {resp.json()['token']}"


def auto_client(user_id: str = "developer", **kwargs: Any) -> MemoryClient:
    """
    Construct a MemoryClient using the local daemon started by `prajnyavan dev`.

    Reads ~/.prajnyavan/dev.json for base_url and fetches a fresh token.
    """
    cfg = _load_dev_config()
    if not cfg:
        raise RuntimeError(
            "No local Prajnyavan daemon found. Run `prajnyavan dev` first, or pass base_url/token explicitly."
        )
    base_url = cfg.get("base_url")
    token = get_token(base_url, user_id=user_id)
    return MemoryClient(base_url=base_url, token=token, **kwargs)


__all__ = ["MemoryClient", "get_token", "auto_client"]
