from __future__ import annotations

import os


class LicenseError(RuntimeError):
    pass


try:
    if os.getenv("QUANTUMDRIVE_ENFORCE_LICENSE", "1") != "0":
        from core.license.license import enforce_license as _qd_enforce_license

        _qd_enforce_license()
except Exception as _lic_err:
    raise LicenseError(f"{_lic_err}") from _lic_err


from core.license.key_manager import get_license_key
from core.license.license import enforce_license, verify_license

__all__ = [
    "LicenseError",
    "enforce_license",
    "get_license_key",
    "verify_license",
]
