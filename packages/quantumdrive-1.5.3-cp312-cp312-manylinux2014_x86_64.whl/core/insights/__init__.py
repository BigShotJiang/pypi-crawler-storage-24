from core.insights.q_cross_project_insight_service import (
    CrossProjectInsightConfig,
    CrossProjectInsightMatch,
    CrossProjectReferenceRecord,
    QCrossProjectInsightService,
    get_q_cross_project_insight_service,
)
from core.insights.q_memory_router import PromotionDecision, QMemoryRouter, WavePromotionInput

__all__ = [
    "CrossProjectInsightConfig",
    "CrossProjectInsightMatch",
    "CrossProjectReferenceRecord",
    "PromotionDecision",
    "QCrossProjectInsightService",
    "QMemoryRouter",
    "QReuseValidationService",
    "ReuseValidationCheck",
    "ReuseValidationResult",
    "WavePromotionInput",
    "get_q_cross_project_insight_service",
    "get_q_reuse_validation_service",
]


def __getattr__(name: str):
    if name in {
        "QReuseValidationService",
        "ReuseValidationCheck",
        "ReuseValidationResult",
        "get_q_reuse_validation_service",
    }:
        from core.insights.q_reuse_validation_service import (
            QReuseValidationService,
            ReuseValidationCheck,
            ReuseValidationResult,
            get_q_reuse_validation_service,
        )

        exports = {
            "QReuseValidationService": QReuseValidationService,
            "ReuseValidationCheck": ReuseValidationCheck,
            "ReuseValidationResult": ReuseValidationResult,
            "get_q_reuse_validation_service": get_q_reuse_validation_service,
        }
        return exports[name]
    raise AttributeError(name)
