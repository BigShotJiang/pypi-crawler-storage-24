"""QuantumDrive Threat Mitigation subsystem.

Provides the TMAPI — a service-to-service REST API that Qato (the AlphaSix
Cyber Analysis product) calls to trigger real-time security mitigations once
threats have been identified.

Phased roll-out:
  Phase 1 — Job lifecycle: models, job store, audit service, Flask Blueprint.
  Phase 2 — Tool execution: port lockdown, IP blacklist, patching, quarantine, etc.
  Phase 3 — Approval workflow integration via the existing KGraph approval system.
  Phase 4 — AI strategy: QAssistant reasoning for let_agent_decide=True requests.
  Phase 5 — Lab environment branches and webhook delivery.
"""
