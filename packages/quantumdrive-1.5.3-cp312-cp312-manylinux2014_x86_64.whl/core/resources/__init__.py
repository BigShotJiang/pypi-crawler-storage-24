"""Packaged QuantumDrive resources."""
