# ACEMD

ACEMD is the next generation molecular dynamics (MD) simulation software designed for high performance and ease of use.

## Features

- **High Performance**: Optimized for NVIDIA GPUs with CUDA support
- **Multiple Force Fields**: Support for AMBER, CHARMM, and OpenMM XML force fields
- **Small Molecule Support**: Automated parameterization using GAFF, OpenFF, and Espaloma force fields
- **Neural Network Potentials**: Integration with TorchMD-NET, ANI, and other ML potentials
- **Flexible I/O**: Multiple trajectory formats
- **Python API**: Full control through Python scripting
- **Advanced Sampling**: Support for metadynamics, steered MD, and custom forces

## Installation

### Prerequisites

- Python 3.10 or higher
- NVIDIA GPU with CUDA support

### Install with pip (recommended)

The simplest way to install ACEMD is using pip:

```bash
# GPU version with CUDA 12
pip install "acemd[cu12]"

# With neural network potential support (CUDA 12)
pip install "acemd[nnp-cu12]"

# With OpenFF support
pip install "acemd[nnp-cu12,openff]"
```

### Install with conda/mamba

For conda users, ACEMD is available from the acellera channel:

```bash
conda install -c acellera -c conda-forge acemd
```


## Quick Start

### Command Line Usage

Create an input configuration file `input.yaml`:

```yaml
# Example with AMBER files
structure: system.prmtop
coordinates: system.pdb
temperature: 300
timestep: 4
run: "4ns"

# Example with OpenMM XML force fields
# structure: system.pdb
# parameters: [amber14-all.xml, amber14/tip3pfb.xml]
```

Run the simulation:

```bash
acemd --input input.yaml

# Or if input.yaml file is in current directory
acemd
```

### Python API

```python
from acemd.acemd import acemd

# Run simulation from a directory containing input file
acemd('/path/to/simulation/directory')

# Or run with specific input file
acemd('/path/to/directory', inputfile='input.yaml')

# Example of creating input file programmatically
import yaml

input_dict = {
    'structure': 'system.prmtop',
    'coordinates': 'system.pdb',
    'temperature': 300,
    'timestep': 4,
    'run': "4ns"
}

with open('input.yaml', 'w') as f:
    yaml.dump(input_dict, f)

acemd('.')
```

### Small Molecule Simulations

ACEMD can also automatically parameterize small molecules:

```yaml
structure: protein_ligand.pdb
parameters: [amber14-all.xml, amber14/tip3pfb.xml]
molecules:
  smiles:
    LIG: "CC(=O)Nc1ccc(O)cc1"  # acetaminophen
  forcefield: gaff-2.2.20
  charge_model: am1bcc
temperature: 300
timestep: 4
run: 1000000 # Equivalent to 4ns
```

## Documentation

Full documentation is available at [https://docs.acellera.com/acemd/](https://docs.acellera.com/acemd/)

### Key Topics

- [Installation Guide](https://docs.acellera.com/acemd/install)
- [Input Parameters](https://docs.acellera.com/acemd/parameters)
- [Force Fields](https://docs.acellera.com/acemd/forcefields)
- [Tutorials](https://docs.acellera.com/acemd/tutorials)
- [Python API Reference](https://docs.acellera.com/acemd/api)

## License

ACEMD is commercial software. For licensing information, please contact sales@acellera.com.

Academic licenses are available for qualifying institutions.

## Citation

If you use ACEMD in your research, please cite:

```bibtex
@article{acemd2024,
  title={ACEMD: High-Performance Molecular Dynamics Software},
  author={Acellera},
  journal={Journal of Chemical Theory and Computation},
  year={2024}
}
```

## Support

- **Documentation**: https://docs.acellera.com/acemd/
- **Support**: support@acellera.com
- **Sales**: sales@acellera.com