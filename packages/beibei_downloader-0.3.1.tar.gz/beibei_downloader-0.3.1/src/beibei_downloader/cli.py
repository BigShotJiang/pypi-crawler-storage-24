#!/usr/bin/env python3
"""命令行入口：启动 Web UI。"""
from __future__ import annotations

import os


def main() -> None:
    port = int(os.environ.get("DOWNLOADER_PORT", "8080"))
    from beibei_downloader.app import main as run_app

    run_app(port=port)


if __name__ == "__main__":
    main()
