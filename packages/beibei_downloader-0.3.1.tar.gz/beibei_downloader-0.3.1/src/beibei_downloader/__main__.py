from beibei_downloader.cli import main

main()
