"""蓓蓓无水印下载 — 可通过 `beibei-download` 或 `python -m beibei_downloader` 启动。"""

__version__ = "0.3.1"
