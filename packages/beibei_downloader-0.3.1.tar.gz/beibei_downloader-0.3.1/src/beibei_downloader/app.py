"""
蓓蓓无水印下载 — 基于 yt-dlp 的批量下载 Web UI（NiceGUI）。
"""
from __future__ import annotations

import os
import platform
import queue
import shutil
import subprocess
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import yt_dlp
from nicegui import run, ui

def _default_save_dir() -> Path:
    """pip 安装后默认保存到用户下载目录下的 beibei-downloads。"""
    for d in (
        Path.home() / "Downloads" / "beibei-downloads",
        Path.home() / "下载" / "beibei-downloads",
        Path.home() / "beibei-downloads",
    ):
        try:
            d.mkdir(parents=True, exist_ok=True)
            return d
        except OSError:
            continue
    return Path.home()


DEFAULT_OUT = _default_save_dir()


def _pick_folder_tk(initial_dir: str) -> str:
    """Tk 选目录（Windows 上在子线程通常可用；macOS 上不可靠）。"""
    init = initial_dir if initial_dir and Path(initial_dir).is_dir() else None
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        try:
            root.attributes("-topmost", True)
        except tk.TclError:
            pass
        root.update_idletasks()
        d = filedialog.askdirectory(
            initialdir=init,
            title="选择视频保存目录",
        )
        root.destroy()
        return (d or "").strip()
    except Exception:
        return ""


def _pick_folder_linux(initial_dir: str) -> str:
    """Linux：依次尝试 zenity（GNOME/XFCE 等）、kdialog（KDE）、yad。"""
    home = str(Path.home())
    start = (
        str(Path(initial_dir).expanduser().resolve())
        if initial_dir and Path(initial_dir).expanduser().is_dir()
        else home
    )

    zen = shutil.which("zenity")
    if zen:
        try:
            cmd = [
                zen,
                "--file-selection",
                "--directory",
                "--title=选择视频保存目录",
                f"--filename={start}/",
            ]
            r = subprocess.run(
                cmd, capture_output=True, text=True, timeout=300
            )
            out = (r.stdout or "").strip()
            if r.returncode == 0 and out and Path(out).is_dir():
                return out
        except (OSError, subprocess.TimeoutExpired):
            pass

    kd = shutil.which("kdialog")
    if kd:
        try:
            r = subprocess.run(
                [
                    kd,
                    "--title",
                    "选择视频保存目录",
                    "--getexistingdirectory",
                    start,
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
            out = (r.stdout or "").strip()
            if r.returncode == 0 and out and Path(out).is_dir():
                return out
        except (OSError, subprocess.TimeoutExpired):
            pass

    yad = shutil.which("yad")
    if yad:
        try:
            r = subprocess.run(
                [
                    yad,
                    "--file-selection",
                    "--directory",
                    "--title=选择视频保存目录",
                    f"--filename={start}/",
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
            out = (r.stdout or "").strip()
            if r.returncode == 0 and out and Path(out).is_dir():
                return out
        except (OSError, subprocess.TimeoutExpired):
            pass

    return ""


def _pick_folder_windows(initial_dir: str) -> str:
    """Windows：PowerShell 弹系统文件夹对话框（路径经环境变量传入，避免引号转义问题）。"""
    sel = (
        str(Path(initial_dir).expanduser().resolve())
        if initial_dir and Path(initial_dir).expanduser().is_dir()
        else str(Path.home())
    )
    ps = r"""
Add-Type -AssemblyName System.Windows.Forms
$b = New-Object System.Windows.Forms.FolderBrowserDialog
$b.Description = '选择视频保存目录'
$b.SelectedPath = $env:BB_PICK_INIT
if (-not (Test-Path -LiteralPath $b.SelectedPath)) {
  $b.SelectedPath = [Environment]::GetFolderPath('UserProfile')
}
if ($b.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
  Write-Output $b.SelectedPath
}
"""
    env = {**os.environ, "BB_PICK_INIT": sel}
    win_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    sys_root = os.environ.get("SystemRoot", r"C:\Windows")
    pw_candidates = [
        Path(sys_root) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe",
        Path(sys_root) / "SysWOW64" / "WindowsPowerShell" / "v1.0" / "powershell.exe",
    ]
    pw_list: list[str] = []
    for p in pw_candidates:
        if p.is_file():
            pw_list.append(str(p))
            break
    pw_sh = shutil.which("powershell") or shutil.which("pwsh")
    if pw_sh and pw_sh not in pw_list:
        pw_list.append(pw_sh)

    for pw_exe in pw_list:
        for sta in ("-STA", None):
            cmd = [pw_exe, "-NoProfile", "-ExecutionPolicy", "Bypass"]
            if sta:
                cmd.append(sta)
            cmd.extend(["-Command", ps])
            try:
                r = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                    env=env,
                    creationflags=win_flags,
                )
                out = (r.stdout or "").strip()
                if out.startswith("\ufeff"):
                    out = out[1:].strip()
                first = out.replace("\r\n", "\n").split("\n", 1)[0].strip()
                if first and Path(first).is_dir():
                    return first
            except (OSError, subprocess.TimeoutExpired):
                continue

    return _pick_folder_tk(sel)


def pick_save_directory_native(initial_dir: str) -> str:
    """
    本机选文件夹。返回路径或 ''（取消 / 失败）。
    - macOS: osascript
    - Linux: zenity → kdialog → yad → Tk
    - Windows: PowerShell FolderBrowserDialog → Tk
    """
    init = ""
    p0 = Path(initial_dir).expanduser()
    if p0.is_dir():
        try:
            init = str(p0.resolve())
        except OSError:
            init = str(p0)

    system = platform.system()

    if system == "Darwin":
        try:
            if init:
                esc = init.replace("\\", "\\\\").replace('"', '\\"')
                script = (
                    "try\n"
                    f'  set def to POSIX file "{esc}"\n'
                    "  set f to choose folder with prompt \"选择视频保存目录\" "
                    "default location def\n"
                    "on error\n"
                    '  set f to choose folder with prompt "选择视频保存目录"\n'
                    "end try\n"
                    "return POSIX path of f\n"
                )
            else:
                script = (
                    'set f to choose folder with prompt "选择视频保存目录"\n'
                    "return POSIX path of f\n"
                )
            r = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                text=True,
                timeout=300,
            )
            out = (r.stdout or "").strip().rstrip("/")
            if r.returncode == 0 and out and Path(out).is_dir():
                return out
        except (OSError, subprocess.TimeoutExpired):
            pass
        return ""

    if system == "Linux":
        out = _pick_folder_linux(init)
        if out:
            return out
        return _pick_folder_tk(init or str(Path.home()))

    if system == "Windows":
        return _pick_folder_windows(init)

    return _pick_folder_tk(init or str(Path.home()))
# 多链接时并行下载的最大线程数（过大易被站点限流）
MAX_PARALLEL_DOWNLOADS = 8

# 本软件仅支持以下四个平台（链接校验 + Cookies 固定四行）
PLATFORM_LABELS: dict[str, str] = {
    "youtube": "YouTube",
    "bilibili": "Bilibili",
    "douyin": "抖音",
    "xiaohongshu": "小红书",
}
# Cookies 区块从上到下固定顺序
COOKIE_UI_ORDER: tuple[tuple[str, str], ...] = (
    ("youtube", "YouTube"),
    ("bilibili", "Bilibili"),
    ("douyin", "抖音"),
    ("xiaohongshu", "小红书"),
)
PLATFORM_URL_KEYWORDS: dict[str, tuple[str, ...]] = {
    "youtube": ("youtube.com", "youtu.be", "youtube"),
    "bilibili": ("bilibili.com", "b23.tv", "bilibili", "bilivideo"),
    "douyin": ("douyin.com", "iesdouyin", "douyin", "amemv.com"),
    "xiaohongshu": ("xiaohongshu.com", "xhslink.com", "xhscdn", "xiaohongshu"),
}


def url_is_supported_platform(url: str) -> bool:
    """仅允许 YouTube / Bilibili / 抖音 / 小红书 相关域名（含短链）。"""
    try:
        p = urlparse(url.strip())
        host = p.netloc.lower()
    except Exception:
        return False
    if not host:
        return False
    if "youtube.com" in host or host == "youtu.be" or host.endswith(".youtu.be"):
        return True
    if "bilibili.com" in host or host == "b23.tv" or host.endswith(".b23.tv"):
        return True
    if (
        "douyin.com" in host
        or "iesdouyin.com" in host
        or "amemv.com" in host
        or host.endswith(".douyin.com")
    ):
        return True
    if "xiaohongshu.com" in host or "xhslink.com" in host:
        return True
    return False


def validate_video_urls(urls: list[str]) -> list[str]:
    """合法 http(s) 链接，且仅限四个支持平台。"""
    errs: list[str] = []
    for i, u in enumerate(urls, 1):
        if not u:
            continue
        if any(c in u for c in " \t"):
            errs.append(f"第 {i} 行：链接中不能含空格，请一行只放一个完整链接")
            continue
        parsed = urlparse(u)
        if parsed.scheme not in ("http", "https"):
            errs.append(
                f"第 {i} 行：必须以 http:// 或 https:// 开头（当前：{u[:48]}{'…' if len(u) > 48 else ''}）"
            )
            continue
        if not parsed.netloc:
            errs.append(f"第 {i} 行：链接缺少域名，请检查是否完整")
            continue
        if not url_is_supported_platform(u):
            errs.append(
                f"第 {i} 行：仅支持 YouTube、Bilibili、抖音、小红书 的链接，其它站点请勿提交"
            )
    return errs


def validate_platform_cookie_paste(rows: list[tuple[str, str]]) -> list[str]:
    """rows: (平台 key, 粘贴的 Cookies 全文)。空则跳过；非空须像 Netscape（含 Tab）。"""
    errs: list[str] = []
    for plat, raw in rows:
        s = raw.strip()
        if not s:
            continue
        label = PLATFORM_LABELS.get(plat, plat)
        if len(s) < 24:
            errs.append(f"[{label}] Cookies 内容过短，请完整粘贴（建议从扩展导出 Netscape 后整段复制）")
            continue
        if s.lstrip().startswith("{"):
            errs.append(
                f"[{label}] 检测到 JSON，yt-dlp 需要 Netscape 文本格式，请用扩展导出 cookies.txt 后粘贴全文"
            )
            continue
        if "\t" not in s:
            errs.append(
                f"[{label}] 未检测到 Tab 分隔（Netscape 格式每行含 Tab），请确认粘贴的是 cookies.txt 全文"
            )
    return errs


def write_platform_cookies_to_tempfiles(
    platform_text: dict[str, str],
) -> tuple[list[str], dict[str, str]]:
    """将各平台粘贴的文本写入临时文件，返回 (待删除路径列表, 平台->路径)。"""
    to_cleanup: list[str] = []
    paths: dict[str, str] = {}
    try:
        for plat, text in platform_text.items():
            t = text.strip()
            if not t:
                continue
            fd, path = tempfile.mkstemp(
                suffix=".txt", prefix=f"bbck_{plat}_", text=False
            )
            to_cleanup.append(path)
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as wf:
                wf.write(t)
                if not t.endswith("\n"):
                    wf.write("\n")
            paths[plat] = path
        return to_cleanup, paths
    except OSError:
        for p in to_cleanup:
            try:
                Path(p).unlink(missing_ok=True)
            except OSError:
                pass
        raise


def platform_paths_to_rules(platform_paths: dict[str, str]) -> list[tuple[str, str]]:
    """平台 → 多组 URL 子串规则，供 cookie_path_for_url 使用。"""
    rules: list[tuple[str, str]] = []
    for plat, path in platform_paths.items():
        resolved = str(Path(path).expanduser().resolve())
        for kw in PLATFORM_URL_KEYWORDS.get(plat, ()):
            rules.append((kw, resolved))
    return rules


def cookie_path_for_url(url: str, rules: list[tuple[str, str]]) -> str | None:
    """按链接为本次下载选择 cookies 文件路径；无匹配且无 default 则 None。"""
    host = urlparse(url).netloc.lower()
    full = url.lower()
    defaults: list[str] = []
    for kw, path in rules:
        path_exp = str(Path(path).expanduser())
        if not Path(path_exp).is_file():
            continue
        resolved = str(Path(path_exp).resolve())
        k = kw.strip().lower()
        if k == "default":
            defaults.append(resolved)
            continue
        if k and (k in host or k in full):
            return resolved
    for p in defaults:
        if Path(p).is_file():
            return p
    return None


class _YtdlpUiLogger:
    """
    yt-dlp 会以 logger.xxx(msg)、logger.xxx(msg, *args) 或带 keyword 等形式调用，
    不能只实现单参数 lambda，否则会报 takes 1 positional argument but 2 were given。
    """

    __slots__ = ("_log",)

    def __init__(self, log_fn) -> None:
        self._log = log_fn

    @staticmethod
    def _format(msg: Any, args: tuple[Any, ...]) -> str:
        if not args:
            return str(msg)
        try:
            if isinstance(msg, str) and "%" in msg:
                return msg % args
        except Exception:
            pass
        return f"{msg} " + " ".join(str(x) for x in args)

    def debug(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        pass

    def trace(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        pass

    def info(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._log("[信息] " + self._format(msg, args))

    def warning(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._log("[警告] " + self._format(msg, args))

    def error(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._log("[错误] " + self._format(msg, args))

    def stdout(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        self._log(self._format(msg, args))


def build_ydl_opts(
    out_dir: Path,
    quality: str,
    cookies_file: str | None,
    log_fn,
    progress_hook,
) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    outtmpl = str(out_dir / "%(title).200s [%(id)s].%(ext)s")

    opts: dict[str, Any] = {
        "outtmpl": outtmpl,
        "merge_output_format": "mp4",
        "ignoreerrors": False,
        "no_warnings": False,
        "quiet": True,
        "no_progress": True,
        "progress_hooks": [progress_hook],
        "logger": _YtdlpUiLogger(log_fn),
    }

    if cookies_file and Path(cookies_file).is_file():
        opts["cookiefile"] = cookies_file

    if quality == "best":
        opts["format"] = "bv*+ba/best/bestvideo+bestaudio"
    elif quality == "1080":
        opts["format"] = (
            "bestvideo[height<=1080]+bestaudio/best[height<=1080]/bv*+ba/best"
        )
    elif quality == "720":
        opts["format"] = (
            "bestvideo[height<=720]+bestaudio/best[height<=720]/bv*+ba/best"
        )
    elif quality == "480":
        opts["format"] = (
            "bestvideo[height<=480]+bestaudio/best[height<=480]/bv*+ba/best"
        )
    elif quality == "audio":
        opts["format"] = "bestaudio/best"
        opts["postprocessors"] = [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "m4a",
                "preferredquality": "192",
            }
        ]
        opts["merge_output_format"] = None

    return opts


def _inject_styles() -> None:
    ui.add_head_html(
        """
<style>
  body.body--dark { background: transparent !important; }
  .bb-page {
    min-height: 100vh;
    color: #e2e8f0;
    background:
      radial-gradient(ellipse 85% 50% at 50% -12%, rgba(139, 92, 246, 0.28), transparent 50%),
      radial-gradient(ellipse 45% 35% at 95% 25%, rgba(6, 182, 212, 0.1), transparent),
      radial-gradient(ellipse 40% 30% at 5% 75%, rgba(244, 114, 182, 0.08), transparent),
      linear-gradient(168deg, #030712 0%, #0f0a1a 38%, #0a1628 72%, #030712 100%);
  }
  .bb-app-title {
    font-size: clamp(1.35rem, 4vw, 1.75rem);
    font-weight: 800;
    letter-spacing: 0.02em;
    background: linear-gradient(100deg, #f9a8d4, #c4b5fd, #67e8f9, #fde68a);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    filter: drop-shadow(0 0 20px rgba(167, 139, 250, 0.25));
  }
  .bb-yt-badge {
    font-family: ui-monospace, monospace;
    font-size: 0.7rem;
    padding: 4px 10px;
    border-radius: 999px;
    border: 1px solid rgba(148, 163, 184, 0.35);
    background: rgba(15, 23, 42, 0.6);
    color: #94a3b8;
  }
  .bb-divider-glow {
    height: 2px;
    border-radius: 2px;
    background: linear-gradient(90deg, transparent, rgba(167, 139, 250, 0.5), rgba(34, 211, 238, 0.45), transparent);
    opacity: 0.75;
    max-width: 28rem;
  }
  .bb-card {
    background: linear-gradient(155deg, rgba(30, 27, 75, 0.35) 0%, rgba(15, 23, 42, 0.88) 45%, rgba(8, 15, 30, 0.92) 100%);
    border: 1px solid rgba(139, 92, 246, 0.22);
    border-radius: 20px;
    box-shadow:
      0 0 0 1px rgba(255,255,255,0.04) inset,
      0 24px 64px -24px rgba(0, 0, 0, 0.55),
      0 0 80px -40px rgba(124, 58, 237, 0.2);
    backdrop-filter: blur(16px);
  }
  .bb-field-glow .q-field__control {
    border-radius: 12px !important;
  }
  .bb-btn-start.q-btn {
    background: linear-gradient(92deg, #db2777, #7c3aed, #0891b2) !important;
    color: #fff !important;
    font-weight: 600 !important;
    border-radius: 12px !important;
    padding: 10px 22px !important;
    box-shadow: 0 4px 24px rgba(124, 58, 237, 0.35), 0 0 32px rgba(236, 72, 153, 0.15) !important;
  }
  .bb-btn-start.q-btn:hover { filter: brightness(1.06); }
  .bb-btn-stop.q-btn {
    border: 1px solid rgba(248, 113, 113, 0.45) !important;
    color: #fecaca !important;
    border-radius: 12px !important;
    background: rgba(127, 29, 29, 0.2) !important;
  }
  .bb-select-menu {
    background: #1e293b !important;
    color: #f8fafc !important;
    border: 1px solid #475569 !important;
  }
  .bb-select-menu .q-item {
    color: #f8fafc !important;
    min-height: 44px;
  }
  .bb-select-menu .q-item:hover,
  .bb-select-menu .q-manual-focusable--focused {
    background: #334155 !important;
  }
  .bb-select-menu .q-item--active {
    background: #475569 !important;
    font-weight: 600;
  }
  body.body--dark .q-menu {
    background: #1e293b !important;
    color: #f8fafc !important;
    border: 1px solid #475569;
  }
  body.body--dark .q-menu .q-item {
    color: #f8fafc !important;
  }
  body.body--dark .q-menu .q-item:hover,
  body.body--dark .q-menu .q-manual-focusable--focused {
    background: #334155 !important;
  }
  .bb-log {
    background: rgba(2, 6, 23, 0.65);
    border: 1px solid rgba(34, 211, 238, 0.15);
    border-radius: 14px;
    box-shadow: 0 0 40px rgba(6, 182, 212, 0.04) inset;
    font-family: ui-monospace, monospace;
    font-size: 0.8125rem;
    color: #7dd3fc !important;
  }
  .bb-sep {
    background: linear-gradient(90deg, transparent, rgba(139, 92, 246, 0.25), transparent) !important;
    height: 1px !important;
    opacity: 1 !important;
  }
</style>
        """,
        shared=True,
    )


def main(port: int = 8080) -> None:
    _inject_styles()

    log_queue: queue.Queue[str] = queue.Queue()
    status_queue: queue.Queue[str] = queue.Queue()
    ui_queue: queue.Queue[str] = queue.Queue()
    stop_event = threading.Event()

    def enqueue_log(msg: str) -> None:
        log_queue.put(msg.rstrip() + "\n")

    def enqueue_status(msg: str) -> None:
        status_queue.put(msg)

    @ui.page("/")
    def _page_root() -> None:
        with ui.column().classes("bb-page w-full p-0"):
            with ui.column().classes("w-full max-w-4xl mx-auto px-4 py-7 gap-5"):
                with ui.row().classes(
                    "w-full items-center justify-between flex-wrap gap-3"
                ):
                    ui.html('<div class="bb-app-title">蓓蓓无水印下载</div>')
                    ui.html('<span class="bb-yt-badge">yt-dlp</span>')
    
                ui.label(
                    "仅支持 YouTube、Bilibili、抖音、小红书 四个站点的视频链接（每行一条，可混填）。"
                    " 会员或高清可在下方按站粘贴 Cookies（Netscape 全文，可选）。"
                ).classes("text-body2 text-slate-400 leading-normal max-w-3xl")
    
                ui.element("div").classes("bb-divider-glow w-full")
    
                with ui.column().classes("bb-card w-full p-6 sm:p-7 gap-5 bb-field-glow"):
                    ui.label("视频链接（每行一个）").classes(
                        "text-subtitle2 text-slate-200"
                    )
                    url_input = (
                        ui.textarea(
                            placeholder="https://www.youtube.com/watch?v=...\n"
                            "https://www.bilibili.com/video/BV...\n"
                            "https://v.douyin.com/...\n"
                            "http://xhslink.com/...",
                        )
                        .classes("w-full")
                        .props(
                            "rows=8 dark outlined standout dense "
                            "input-class=text-slate-100"
                        )
                    )
    
                    async def pick_output_dir() -> None:
                        cur = (out_input.value or "").strip() or str(DEFAULT_OUT)
                        p = Path(cur).expanduser()
                        init = (
                            str(p.resolve())
                            if p.is_dir()
                            else str(DEFAULT_OUT.resolve())
                        )
                        # 必须在子线程跑，避免阻塞事件循环；macOS 上 Tk 在子线程会失败，已改用 osascript 等
                        chosen = await run.io_bound(pick_save_directory_native, init)
                        if chosen:
                            out_input.value = chosen
                            ui.notify("已设置保存目录", type="positive")
                        else:
                            ui.notify(
                                "未选择目录（若点了取消会如此）；"
                                "无图形界面时请手动输入路径",
                                type="warning",
                            )
    
                    with ui.row().classes("w-full gap-3 flex-wrap items-end"):
                        out_input = (
                            ui.input(label="保存目录", value=str(DEFAULT_OUT))
                            .classes("flex-grow min-w-52")
                            .props("dark outlined standout dense")
                        )
                        ui.button("选择文件夹", icon="folder_open").classes(
                            "bb-btn-stop"
                        ).props("outline no-caps dense").on_click(pick_output_dir)
                        quality_select = (
                            ui.select(
                                {
                                    "best": "最佳画质",
                                    "1080": "最高 1080p",
                                    "720": "最高 720p",
                                    "480": "最高 480p",
                                    "audio": "仅音频 (m4a)",
                                },
                                value="best",
                                label="画质",
                            )
                            .classes("min-w-44")
                            .props(
                                "dark outlined standout dense "
                                "popup-content-class=bb-select-menu"
                            )
                        )
    
                    ui.label("Cookies 配置（可选）").classes(
                        "text-subtitle2 text-slate-200"
                    )
                    ui.label(
                        "在对应站点登录后，用扩展导出 Netscape 格式的 cookies.txt，"
                        "打开后全选复制，粘贴到该行文本框；不填表示该站不用 Cookies。"
                    ).classes("text-caption text-slate-500 leading-normal")
                    cookie_plat_inputs: list[tuple[str, Any]] = []
                    for plat_key, plat_name in COOKIE_UI_ORDER:
                        with ui.row().classes(
                            "w-full gap-4 flex-wrap items-start"
                        ):
                            ui.label(plat_name).classes(
                                "min-w-[5.5rem] sm:min-w-28 text-slate-200 "
                                "font-semibold text-sm pt-3 shrink-0"
                            )
                            cookie_ta = (
                                ui.textarea(
                                    label=f"{plat_name} · 粘贴 Cookies（可选）",
                                    placeholder="# Netscape HTTP Cookie File\n"
                                    ".example.com\tTRUE\t/\tFALSE\t0\tname\tvalue",
                                )
                                .classes("flex-grow min-w-0")
                                .props(
                                    "rows=3 dark outlined standout dense "
                                    "input-class=text-slate-200 text-xs"
                                )
                            )
                            cookie_plat_inputs.append((plat_key, cookie_ta))
    
                    with ui.row().classes("w-full items-center gap-3 flex-wrap"):
                        status_label = ui.label("就绪").classes(
                            "text-body2 text-cyan-200/80 flex-grow"
                        )
                        start_btn = ui.button("开始下载", icon="download").classes(
                            "bb-btn-start"
                        ).props("unelevated no-caps")
                        stop_btn = ui.button("停止", icon="stop").classes(
                            "bb-btn-stop"
                        ).props("unelevated no-caps outline disable")
    
                    ui.separator().classes("bb-sep")
                    ui.label("运行日志").classes("text-subtitle2 text-slate-200")
                    log_box = (
                        ui.log(max_lines=500)
                        .classes("w-full h-72 bb-log")
                        .props("dark")
                    )
    
            def pump_log() -> None:
                try:
                    while True:
                        log_box.push(log_queue.get_nowait().rstrip("\n"))
                except queue.Empty:
                    pass
                last_status = None
                try:
                    while True:
                        last_status = status_queue.get_nowait()
                except queue.Empty:
                    pass
                if last_status is not None:
                    status_label.set_text(last_status)
                try:
                    while True:
                        cmd = ui_queue.get_nowait()
                        if cmd == "end_worker":
                            start_btn.props(remove="disable")
                            stop_btn.props("disable")
                except queue.Empty:
                    pass
    
            ui.timer(0.25, pump_log)
    
            def run_downloads() -> None:
                log_box.clear()
                status_label.set_text("就绪")
                raw = (url_input.value or "").strip()
                urls = [u.strip() for u in raw.splitlines() if u.strip()]
                if not urls:
                    enqueue_log("请至少输入一个有效链接。")
                    return
    
                url_errs = validate_video_urls(urls)
                if url_errs:
                    enqueue_log("【视频链接校验未通过】")
                    for msg in url_errs:
                        enqueue_log(f"  · {msg}")
                    enqueue_log("请修正后重试。")
                    return
    
                cookie_rows_data = [
                    (pk, (ta.value or "").strip()) for pk, ta in cookie_plat_inputs
                ]
                cookie_errs = validate_platform_cookie_paste(cookie_rows_data)
                if cookie_errs:
                    enqueue_log("【Cookies 配置校验未通过】")
                    for msg in cookie_errs:
                        enqueue_log(f"  · {msg}")
                    enqueue_log("请粘贴 Netscape 格式全文，或清空对应文本框。")
                    return
    
                out_path = Path((out_input.value or "").strip() or str(DEFAULT_OUT))
                try:
                    out_path = out_path.expanduser().resolve()
                except OSError as e:
                    enqueue_log(f"保存目录无效: {e}")
                    return
    
                platform_cookie_text: dict[str, str] = {}
                for plat, txt in cookie_rows_data:
                    if txt.strip():
                        platform_cookie_text[plat] = txt.strip()
    
                temp_cookie_paths: list[str] = []
                if platform_cookie_text:
                    try:
                        temp_cookie_paths, platform_paths = (
                            write_platform_cookies_to_tempfiles(platform_cookie_text)
                        )
                    except OSError as e:
                        enqueue_log(f"写入临时 Cookies 失败: {e}")
                        return
                else:
                    platform_paths = {}
                cookie_rules = platform_paths_to_rules(platform_paths)
                quality = quality_select.value or "best"
                stop_event.clear()
    
                def worker() -> None:
                    n = len(urls)
                    workers = min(MAX_PARALLEL_DOWNLOADS, n)
    
                    def run_one(i: int, url: str) -> str:
                        """返回 ok / fail / cancel / skip"""
                        if stop_event.is_set():
                            enqueue_log(f"[{i}/{n}] 已跳过（已停止） {url}")
                            return "skip"
    
                        ck = cookie_path_for_url(url, cookie_rules)
                        enqueue_log(f"[{i}/{n}] 开始 {url}")
                        if ck:
                            enqueue_log(f"[{i}/{n}]   已使用该站 Cookies")
                        elif cookie_rules:
                            enqueue_log(
                                f"[{i}/{n}]   未匹配到已填 Cookies 的站点，本链不使用 Cookies"
                            )
    
                        def progress_hook(d: dict) -> None:
                            if stop_event.is_set():
                                raise yt_dlp.utils.DownloadCancelled()
                            st = d.get("status")
                            if st == "downloading":
                                p = d.get("_percent_str") or ""
                                spd = d.get("_speed_str") or ""
                                eta = d.get("_eta_str") or ""
                                fn = d.get("filename", "")
                                base = Path(fn).name if fn else ""
                                enqueue_status(
                                    f"[{i}/{n}] {p} {spd} ETA {eta} {base[:36]}"
                                )
                            elif st == "finished":
                                enqueue_status(f"[{i}/{n}] 合并/后处理…")
    
                        try:
                            opts = build_ydl_opts(
                                out_path,
                                quality,
                                ck,
                                enqueue_log,
                                progress_hook,
                            )
                            with yt_dlp.YoutubeDL({**opts}) as ydl:
                                ydl.download([url])
                            enqueue_log(f"[{i}/{n}] 完成")
                            return "ok"
                        except yt_dlp.utils.DownloadCancelled:
                            enqueue_log(f"[{i}/{n}] 已取消")
                            return "cancel"
                        except Exception as e:
                            enqueue_log(f"[{i}/{n}] 失败: {e}")
                            return "fail"
    
                    try:
                        enqueue_log(
                            f"共 {n} 个链接 → {out_path}"
                            + (
                                f" | 已配置 {len(platform_paths)} 个来源的 Cookies"
                                if platform_paths
                                else " | 未填写 Cookies（选填）"
                            )
                        )
                        enqueue_log(
                            f"并行下载：最多同时 {workers} 路（可在代码里改 MAX_PARALLEL_DOWNLOADS）"
                        )
                        outcomes: list[str] = []
                        with ThreadPoolExecutor(
                            max_workers=workers, thread_name_prefix="ytdlp"
                        ) as pool:
                            futures = [
                                pool.submit(run_one, i, url)
                                for i, url in enumerate(urls, 1)
                            ]
                            for fut in as_completed(futures):
                                try:
                                    outcomes.append(fut.result())
                                except Exception as e:
                                    enqueue_log(f"任务异常: {e}")
                                    outcomes.append("fail")
                        ok = sum(1 for x in outcomes if x == "ok")
                        bad = sum(1 for x in outcomes if x in ("fail", "cancel"))
                        skipped = sum(1 for x in outcomes if x == "skip")
                        enqueue_status(
                            f"结束：成功 {ok}，失败/取消 {bad}"
                            + (f"，跳过 {skipped}" if skipped else "")
                        )
                    finally:
                        for p in temp_cookie_paths:
                            try:
                                Path(p).unlink(missing_ok=True)
                            except OSError:
                                pass
                        ui_queue.put("end_worker")
    
                start_btn.props("disable")
                stop_btn.props(remove="disable")
                threading.Thread(target=worker, daemon=True).start()
    
            def request_stop() -> None:
                stop_event.set()
                enqueue_log("正在请求停止…")
                enqueue_status("停止中…")
    
            start_btn.on_click(run_downloads)
            stop_btn.on_click(request_stop)

    ui.run(
        title="蓓蓓无水印下载",
        port=port,
        host="127.0.0.1",
        reload=False,
        show=True,
        favicon="🎬",
        dark=True,
    )


if __name__ == "__main__":
    main()
