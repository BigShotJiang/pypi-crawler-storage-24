# 蓓蓓无水印下载

基于 [yt-dlp](https://github.com/yt-dlp/yt-dlp) 的本地工具，**仅支持** **YouTube、Bilibili、抖音、小红书** 四个站点的视频批量下载（链接与 Cookies 均按此四站设计；单条能否下成功仍取决于 yt-dlp 与站点）。

PyPI 包名：**`beibei-downloader`**，安装后命令：**`beibei-download`**。

## 环境要求

- Python **3.10+**
- **ffmpeg**（合并音视频等）  
  - macOS: `brew install ffmpeg`  
  - Windows / Linux: 见 [ffmpeg 官网](https://ffmpeg.org/download.html)

---

## 方式一：`pip install`（推荐）

### 从本仓库目录安装（未发 PyPI 时）

```bash
cd /path/to/dsyy   # 含 pyproject.toml 的目录
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -U pip
pip install .
```

### 开发可编辑安装（改代码立即生效）

```bash
pip install -e .
```

### 启动

```bash
beibei-download
# 或
python -m beibei_downloader
```

浏览器打开 **http://127.0.0.1:8080**。端口：`export DOWNLOADER_PORT=9090`（Windows 用 `set DOWNLOADER_PORT=9090`）。

**默认保存目录**（可再在界面里改）：优先 `~/Downloads/beibei-downloads`，其次 `~/下载/beibei-downloads`，再否则 `~/beibei-downloads`。

---

## 方式二：发到 PyPI 后别人一键安装

1. 注册 [PyPI](https://pypi.org/account/register/)，配置 `~/.pypirc` 或 API token。  
2. 安装构建工具：`pip install build twine`  
3. 在项目根目录：

```bash
python -m build
twine upload dist/*
```

4. 别人执行：

```bash
pip install beibei-downloader
beibei-download
```

发布前请在 `pyproject.toml` 里改 `version`、补全 `[project.urls]` 等元数据。

---

## 方式三：仅克隆仓库、不安装包

```bash
pip install -r requirements.txt
python run.py
```

---

## 使用说明

1. **视频链接**：每行一个，**仅限四站**（youtube / bilibili / douyin / 小红书相关域名）；其它域名会被拒绝。
2. **保存目录**：可 **选择文件夹**（本机对话框）或手输路径。
3. **画质**：下拉选择。
4. **并行下载**：默认最多同时 8 路，可在源码 `src/beibei_downloader/app.py` 中修改 `MAX_PARALLEL_DOWNLOADS`。

### Cookies

界面固定四行：**YouTube → Bilibili → 抖音 → 小红书**。各站登录后用扩展导出 **Netscape** 的 `cookies.txt`，全选复制粘贴到对应行；不填则该站不用 Cookies。格式示例见 **`cookies.sample.txt`**。

### 关于「无水印」与合规

取决于平台提供的流；请仅下载有权使用的内容，使用者自负责任。

## 常见问题

- **某站报错**：`pip install -U yt-dlp`。
- **抖音/小红书**：可关注 [yt-dlp issues](https://github.com/yt-dlp/yt-dlp/issues)。
