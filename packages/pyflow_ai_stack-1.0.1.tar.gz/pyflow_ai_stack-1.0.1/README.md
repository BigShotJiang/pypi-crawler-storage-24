# PyFlow AI Stack

**PyFlow AI Stack** is a high-performance Python library and boilerplate designed for building robust **Node APIs** and **AI Workers** within workflow automation systems (like Dify, LangChain, or custom microservices).

It provides a unified, production-ready interface for interacting with essential services: **Google Gemini AI**, **Redis Caching**, and **S3-compatible Object Storage** (AWS S3, MinIO, etc.).

## ✨ Key Features

- **Google Gemini AI**: Seamless integration with Gemini models for content generation and file processing with managed concurrency.
- **Redis Caching**: Efficient asynchronous caching with automatic connection management and expiration support.
- **S3 Storage**: Asynchronous access to S3-compatible storage providers, optimized for high-performance file operations.
- **Health Checks**: Built-in monitoring for service health and connectivity status across all integrated components.
- **Lifecycle Hooks**: Flexible hook system to intercept execution at `before`, `after`, and `error` stages.
- **Pydantic Validation**: Strong typing and data validation for all service requests and responses.

## 🛠️ Installation

Install the stable version from [PyPI](https://pypi.org/project/pyflow-ai-stack/):

```bash
pip install pyflow-ai-stack
```

Or install from source for development:

```bash
git clone https://github.com/tranthethang/pyflow-ai-stack.git
cd pyflow-ai-stack
pip install -e .[dev]
```

## 📚 Documentation

For detailed guides on configuration and usage, please refer to the following resources:

- [**Quick Start Guide**](./docs/index.md): Library overview and basic examples.
- [**Configuration**](./docs/configuration.md): Environment variables and system settings.
- [**Services Reference**](./docs/services/index.md): Detailed documentation for Gemini, Redis, S3, and Health services.
- [**Data Schemas**](./docs/schemas.md): Input/output models and validation rules.
- [**Lifecycle Hooks**](./docs/hooks.md): How to extend service functionality using hooks.
- [**How-to Guides**](./docs/how-to-use.md): Practical usage scenarios and best practices.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](./LICENSE) file for details.
