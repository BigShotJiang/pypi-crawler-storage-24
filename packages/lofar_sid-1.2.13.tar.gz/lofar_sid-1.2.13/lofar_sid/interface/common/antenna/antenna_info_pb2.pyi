from lofar_sid.interface.common.antenna import antenna_id_pb2 as _antenna_id_pb2
from lofar_sid.interface.common.antenna import antenna_status_pb2 as _antenna_status_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AntennaInfo(_message.Message):
    __slots__ = ("antenna", "antenna_status")
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_STATUS_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    antenna_status: _antenna_status_pb2.Antenna_Status
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., antenna_status: _Optional[_Union[_antenna_status_pb2.Antenna_Status, str]] = ...) -> None: ...
