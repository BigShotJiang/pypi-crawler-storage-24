from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class Antenna_Status(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ANTENNA_STATUS_UNSPECIFIED: _ClassVar[Antenna_Status]
    ANTENNA_STATUS_OK: _ClassVar[Antenna_Status]
    ANTENNA_STATUS_SUSPICIOUS: _ClassVar[Antenna_Status]
    ANTENNA_STATUS_BROKEN: _ClassVar[Antenna_Status]
    ANTENNA_STATUS_BEYOND_REPAIR: _ClassVar[Antenna_Status]
    ANTENNA_STATUS_NOT_AVAILABLE: _ClassVar[Antenna_Status]
ANTENNA_STATUS_UNSPECIFIED: Antenna_Status
ANTENNA_STATUS_OK: Antenna_Status
ANTENNA_STATUS_SUSPICIOUS: Antenna_Status
ANTENNA_STATUS_BROKEN: Antenna_Status
ANTENNA_STATUS_BEYOND_REPAIR: Antenna_Status
ANTENNA_STATUS_NOT_AVAILABLE: Antenna_Status
