from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class Antenna_Usage(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ANTENNA_USAGE_UNSPECIFIED: _ClassVar[Antenna_Usage]
    ANTENNA_USAGE_AUTO: _ClassVar[Antenna_Usage]
    ANTENNA_USAGE_ON: _ClassVar[Antenna_Usage]
    ANTENNA_USAGE_OFF: _ClassVar[Antenna_Usage]
ANTENNA_USAGE_UNSPECIFIED: Antenna_Usage
ANTENNA_USAGE_AUTO: Antenna_Usage
ANTENNA_USAGE_ON: Antenna_Usage
ANTENNA_USAGE_OFF: Antenna_Usage
