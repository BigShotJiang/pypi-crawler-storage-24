from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class Antenna_Power_Status(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ANTENNA_POWER_STATUS_UNSPECIFIED: _ClassVar[Antenna_Power_Status]
    ANTENNA_POWER_STATUS_OFF: _ClassVar[Antenna_Power_Status]
    ANTENNA_POWER_STATUS_ON: _ClassVar[Antenna_Power_Status]
ANTENNA_POWER_STATUS_UNSPECIFIED: Antenna_Power_Status
ANTENNA_POWER_STATUS_OFF: Antenna_Power_Status
ANTENNA_POWER_STATUS_ON: Antenna_Power_Status
