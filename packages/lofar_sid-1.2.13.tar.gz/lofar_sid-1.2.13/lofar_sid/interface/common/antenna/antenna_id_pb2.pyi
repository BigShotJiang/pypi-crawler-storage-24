from lofar_sid.interface.common.antennafield import antennafield_id_pb2 as _antennafield_id_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AntennaId(_message.Message):
    __slots__ = ("antennafield", "antenna_id")
    ANTENNAFIELD_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_ID_FIELD_NUMBER: _ClassVar[int]
    antennafield: _antennafield_id_pb2.AntennafieldId
    antenna_id: int
    def __init__(self, antennafield: _Optional[_Union[_antennafield_id_pb2.AntennafieldId, _Mapping]] = ..., antenna_id: _Optional[int] = ...) -> None: ...
