from lofar_sid.interface.common.station import station_id_pb2 as _station_id_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AntennafieldId(_message.Message):
    __slots__ = ("station", "antennafield_name")
    STATION_FIELD_NUMBER: _ClassVar[int]
    ANTENNAFIELD_NAME_FIELD_NUMBER: _ClassVar[int]
    station: _station_id_pb2.StationId
    antennafield_name: str
    def __init__(self, station: _Optional[_Union[_station_id_pb2.StationId, _Mapping]] = ..., antennafield_name: _Optional[str] = ...) -> None: ...
