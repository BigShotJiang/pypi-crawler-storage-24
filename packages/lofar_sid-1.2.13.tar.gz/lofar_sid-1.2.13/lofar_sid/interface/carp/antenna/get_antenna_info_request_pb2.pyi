import datetime

from lofar_sid.interface.common.antenna import antenna_id_pb2 as _antenna_id_pb2
from lofar_sid.interface.common.antenna import antenna_status_pb2 as _antenna_status_pb2
from lofar_sid.interface.common.antennafield import antennafield_id_pb2 as _antennafield_id_pb2
from lofar_sid.interface.common.station import station_id_pb2 as _station_id_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetAntennaInfoRequest(_message.Message):
    __slots__ = ("station", "antennafield", "antenna", "timestamp", "antenna_status")
    STATION_FIELD_NUMBER: _ClassVar[int]
    ANTENNAFIELD_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_STATUS_FIELD_NUMBER: _ClassVar[int]
    station: _station_id_pb2.StationId
    antennafield: _antennafield_id_pb2.AntennafieldId
    antenna: _antenna_id_pb2.AntennaId
    timestamp: _timestamp_pb2.Timestamp
    antenna_status: _containers.RepeatedScalarFieldContainer[_antenna_status_pb2.Antenna_Status]
    def __init__(self, station: _Optional[_Union[_station_id_pb2.StationId, _Mapping]] = ..., antennafield: _Optional[_Union[_antennafield_id_pb2.AntennafieldId, _Mapping]] = ..., antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., antenna_status: _Optional[_Iterable[_Union[_antenna_status_pb2.Antenna_Status, str]]] = ...) -> None: ...
