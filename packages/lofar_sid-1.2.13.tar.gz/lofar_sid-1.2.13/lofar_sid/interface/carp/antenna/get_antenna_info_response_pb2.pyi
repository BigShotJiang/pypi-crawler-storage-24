import datetime

from lofar_sid.interface.common.antenna import antenna_info_pb2 as _antenna_info_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetAntennaInfoResponse(_message.Message):
    __slots__ = ("timestamp", "antenna_info")
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_INFO_FIELD_NUMBER: _ClassVar[int]
    timestamp: _timestamp_pb2.Timestamp
    antenna_info: _antenna_info_pb2.AntennaInfo
    def __init__(self, timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., antenna_info: _Optional[_Union[_antenna_info_pb2.AntennaInfo, _Mapping]] = ...) -> None: ...
