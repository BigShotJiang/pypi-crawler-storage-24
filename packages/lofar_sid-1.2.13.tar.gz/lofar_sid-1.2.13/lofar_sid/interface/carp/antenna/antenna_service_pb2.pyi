from lofar_sid.interface.carp.antenna import get_antenna_info_request_pb2 as _get_antenna_info_request_pb2
from lofar_sid.interface.carp.antenna import get_antenna_info_response_pb2 as _get_antenna_info_response_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
