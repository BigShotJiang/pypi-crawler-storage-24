"""vssh — Distributed command & file transport daemon"""
