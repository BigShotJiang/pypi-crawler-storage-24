# vssh

Distributed command & file transport daemon.

> This package is a placeholder. Full release coming soon.

See [github.com/meshpop/vssh](https://github.com/meshpop/vssh) for source.
