#!/bin/bash

# =============================================================================
# AILOOS Coordinator Deployment Script for Arsys Server
# =============================================================================
# Server: Arsys
# IP: 212.227.95.247
# Specs: 4 vCPU, 8 GB RAM, 240 GB SSD
# OS: Ubuntu 24.04
# =============================================================================

# Cambiamos a no fallar por variables no definidas para este script
set -eo pipefail

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
SERVER_IP="212.227.95.247"
SERVER_NAME="ailoos-coordinator"
COORDINATOR_PORT="8000"
POSTGRES_PORT="5432"
REDIS_PORT="6379"

# Directories
APP_DIR="/opt/ailoos"
DATA_DIR="/opt/ailoos/data"
CONFIG_DIR="/opt/ailoos/config"
LOG_DIR="/var/log/ailoos"

# Docker images
POSTGRES_IMAGE="postgres:16-alpine"
REDIS_IMAGE="redis:7-alpine"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# -----------------------------------------------------------------------------
# Functions
# -----------------------------------------------------------------------------

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${CYAN}[STEP]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

# Detect OS
detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$ID
        VERSION=$VERSION_ID
    else
        log_error "Cannot detect OS"
        exit 1
    fi
    
    if [[ "$OS" != "ubuntu" ]]; then
        log_warning "This script is designed for Ubuntu. Detected: $OS $VERSION"
    fi
}

# Update system packages
update_system() {
    log_step "Updating system packages..."
    apt-get update -qq
    apt-get upgrade -y -qq
    log_success "System updated"
}

# Install dependencies
install_dependencies() {
    log_step "Installing dependencies..."
    
    # Install required packages
    apt-get install -y -qq \
        curl \
        wget \
        git \
        gnupg \
        lsb-release \
        ca-certificates \
        unzip \
        libpq-dev \
        python3 \
        python3-pip \
        python3-venv \
        ufw \
        fail2ban \
        htop \
        net-tools \
        certbot \
        python3-certbot-nginx \
        > /dev/null 2>&1
    
    log_success "Dependencies installed"
}

# Install Docker
install_docker() {
    log_step "Installing Docker..."
    
    # Check if Docker is already installed
    if command -v docker &> /dev/null; then
        log_warning "Docker is already installed: $(docker --version)"
        
        # Check if Docker service is running
        if ! systemctl is-active --quiet docker; then
            log_info "Starting Docker service..."
            systemctl start docker
            systemctl enable docker
        fi
        log_success "Docker is ready"
        return 0
    fi
    
    # Remove old Docker versions if they exist
    apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true
    
    # Add Docker GPG key
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    
    # Add Docker repository
    echo \
        "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
        $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Install Docker
    apt-get update -qq
    apt-get install -y -qq \
        docker-ce \
        docker-ce-cli \
        containerd.io \
        docker-buildx-plugin \
        docker-compose-plugin \
        > /dev/null 2>&1
    
    # Add current user to docker group
    if [[ -n "${SUDO_USER:-}" ]]; then
        usermod -aG docker "$SUDO_USER"
    fi
    
    # Start and enable Docker
    systemctl start docker
    systemctl enable docker
    
    log_success "Docker installed successfully"
}

# Install Docker Compose (standalone)
install_docker_compose() {
    log_step "Installing Docker Compose..."
    
    # Check if Docker Compose is already installed
    if command -v docker-compose &> /dev/null; then
        log_warning "Docker Compose is already installed: $(docker-compose --version)"
        return 0
    fi
    
    # Install Docker Compose
    curl -fsSL "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    
    log_success "Docker Compose installed"
}

# Configure firewall
configure_firewall() {
    log_step "Configuring firewall..."
    
    # Check if ufw is installed
    if ! command -v ufw &> /dev/null; then
        log_warning "UFW not installed, skipping firewall configuration"
        return 0
    fi
    
    # Reset ufw to default
    ufw --force reset
    
    # Set default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH
    ufw allow 22/tcp comment 'SSH'
    
    # Allow HTTP/HTTPS
    ufw allow 80/tcp comment 'HTTP'
    ufw allow 443/tcp comment 'HTTPS'
    
    # Allow application ports
    ufw allow ${COORDINATOR_PORT}/tcp comment 'Ailoos Coordinator API'
    ufw allow ${POSTGRES_PORT}/tcp comment 'PostgreSQL'
    ufw allow ${REDIS_PORT}/tcp comment 'Redis'
    
    # Enable ufw
    echo "y" | ufw enable
    
    log_success "Firewall configured"
}

# Create application directories
create_directories() {
    log_step "Creating application directories..."
    
    mkdir -p "${APP_DIR}"
    mkdir -p "${DATA_DIR}"/{postgres,redis,uploads,logs}
    mkdir -p "${CONFIG_DIR}"
    mkdir -p "${LOG_DIR}"
    
    # Set permissions
    chmod -R 755 "${APP_DIR}"
    chmod -R 700 "${DATA_DIR}/postgres"  # PostgreSQL data
    
    log_success "Directories created"
}

# Generate secrets
generate_secrets() {
    log_step "Generating secrets..."
    
    # Check if openssl is available
    if ! command -v openssl &> /dev/null; then
        log_error "openssl not found"
        exit 1
    fi
    
    SECRETS_FILE="${CONFIG_DIR}/secrets.env"
    
    # Function to add secret if not exists
    add_secret() {
        local key="$1"
        local value="$2"
        if ! grep -q "^${key}=" "${SECRETS_FILE}" 2>/dev/null; then
            echo "${key}=${value}" >> "${SECRETS_FILE}"
        fi
    }
    
    # Create secrets file
    touch "${SECRETS_FILE}"
    chmod 600 "${SECRETS_FILE}"
    
    # Generate secrets
    add_secret "POSTGRES_PASSWORD" "$(openssl rand -base64 32)"
    add_secret "REDIS_PASSWORD" "$(openssl rand -base64 32)"
    add_secret "JWT_SECRET_KEY" "$(openssl rand -base64 48)"
    add_secret "ENCRYPTION_KEY" "$(openssl rand -base64 32)"
    add_secret "SECRET_KEY" "$(openssl rand -base64 32)"
    
    log_success "Secrets generated"
}

# Create environment file
create_env_file() {
    log_step "Creating environment configuration..."
    
    ENV_FILE="${CONFIG_DIR}/.env"
    
    # Load secrets if they exist
    source "${CONFIG_DIR}/secrets.env" 2>/dev/null || true
    
    # Default values if secrets not loaded
    POSTGRES_PASSWORD="${POSTGRES_PASSWORD:-$(openssl rand -base64 32)}"
    REDIS_PASSWORD="${REDIS_PASSWORD:-$(openssl rand -base64 32)}"
    JWT_SECRET_KEY="${JWT_SECRET_KEY:-$(openssl rand -base64 48)}"
    
    cat > "${ENV_FILE}" << EOF
# =============================================================================
# AILOOS Coordinator Environment Configuration
# =============================================================================
# Server: Arsys - ${SERVER_IP}
# Generated: $(date -u +"%Y-%m-%d %H:%M:%S UTC")
# =============================================================================

# -----------------------------------------------------------------------------
# Server Configuration
# -----------------------------------------------------------------------------
SERVER_IP=${SERVER_IP}
SERVER_NAME=${SERVER_NAME}
COORDINATOR_PORT=${COORDINATOR_PORT}

# -----------------------------------------------------------------------------
# Application Settings
# -----------------------------------------------------------------------------
ENVIRONMENT=production
DEBUG=false
LOG_LEVEL=INFO

# -----------------------------------------------------------------------------
# Database Configuration (PostgreSQL)
# -----------------------------------------------------------------------------
DB_HOST=postgres
DB_PORT=5432
DB_NAME=ailoos
DB_USER=ailoos
DB_PASSWORD=${POSTGRES_PASSWORD}
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=10

# Connection string (used by application)
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@postgres:5432/${DB_NAME}

# -----------------------------------------------------------------------------
# Redis Configuration
# -----------------------------------------------------------------------------
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=${REDIS_PASSWORD}
REDIS_DB=0
REDIS_MAX_CONNECTIONS=50

# -----------------------------------------------------------------------------
# Security
# -----------------------------------------------------------------------------
JWT_SECRET_KEY=${JWT_SECRET_KEY}
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24
ENCRYPTION_KEY=${ENCRYPTION_KEY:-$(openssl rand -base64 32)}

# -----------------------------------------------------------------------------
# API Configuration
# -----------------------------------------------------------------------------
API_HOST=0.0.0.0
API_PORT=${COORDINATOR_PORT}
API_WORKERS=4
API_TIMEOUT=60

# -----------------------------------------------------------------------------
# CORS Configuration
# -----------------------------------------------------------------------------
CORS_ORIGINS=http://${SERVER_IP},https://${SERVER_IP},http://localhost,https://localhost
CORS_ALLOW_CREDENTIALS=true
CORS_ALLOW_METHODS=GET,POST,PUT,DELETE,PATCH,OPTIONS
CORS_ALLOW_HEADERS=*

# -----------------------------------------------------------------------------
# Rate Limiting
# -----------------------------------------------------------------------------
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60

# -----------------------------------------------------------------------------
# Monitoring
# -----------------------------------------------------------------------------
METRICS_ENABLED=true
METRICS_PORT=9090
HEALTH_CHECK_ENDPOINT=/health
HEALTH_CHECK_TIMEOUT=5

# -----------------------------------------------------------------------------
# File Storage
# -----------------------------------------------------------------------------
UPLOAD_DIR=/app/uploads
MAX_UPLOAD_SIZE=104857600  # 100MB

# -----------------------------------------------------------------------------
# Optional Services
# -----------------------------------------------------------------------------
SMTP_ENABLED=false
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_FROM=noreply@ailoos.com

EOF
    
    chmod 600 "${ENV_FILE}"
    log_success "Environment configuration created"
}

# Create Docker Compose file
create_docker_compose() {
    log_step "Creating Docker Compose configuration..."
    
    COMPOSE_FILE="${APP_DIR}/docker-compose.yml"
    
    # Load secrets
    source "${CONFIG_DIR}/secrets.env" 2>/dev/null || true
    
    # Default values
    POSTGRES_PASSWORD="${POSTGRES_PASSWORD:-$(openssl rand -base64 32)}"
    REDIS_PASSWORD="${REDIS_PASSWORD:-$(openssl rand -base64 32)}"
    
    cat > "${COMPOSE_FILE}" << 'EOF'
version: '3.8'

# =============================================================================
# AILOOS Coordinator Docker Compose
# =============================================================================
# Server: Arsys - 212.227.95.247
# Services: PostgreSQL + Redis + Coordinator
# =============================================================================

services:
  # ----------------------------------------------------------------------------
  # PostgreSQL Database
  # ----------------------------------------------------------------------------
  postgres:
    image: postgres:16-alpine
    container_name: ailoos-postgres
    restart: unless-stopped
    environment:
      POSTGRES_DB: ailoos
      POSTGRES_USER: ailoos
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      PGDATA: /var/lib/postgresql/data/pgdata
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ailoos -d ailoos"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - ailoos-network
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # ----------------------------------------------------------------------------
  # Redis Cache
  # ----------------------------------------------------------------------------
  redis:
    image: redis:7-alpine
    container_name: ailoos-redis
    restart: unless-stopped
    command: redis-server --requirepass ${REDIS_PASSWORD} --maxmemory 512mb --maxmemory-policy allkeys-lru
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "--raw", "incr", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - ailoos-network
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # ----------------------------------------------------------------------------
  # Ailoos Coordinator API (from source)
  # ----------------------------------------------------------------------------
  coordinator:
    image: python:3.9-slim
    container_name: ailoos-coordinator
    restart: unless-stopped
    working_dir: /app
    command: >
      bash -c "pip install -q fastapi uvicorn aiohttp sqlalchemy asyncpg redis pydantic pydantic-settings python-jose passlib &&
      python -m uvicorn src.ailoos.coordinator.main:app --host 0.0.0.0 --port 8000"
    env_file:
      - ./config/.env
    environment:
      - SERVER_IP=212.227.95.247
      - PYTHONUNBUFFERED=1
      - PYTHONPATH=/app/src
    volumes:
      - ../../../src:/app/src
    ports:
      - "8000:8000"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    networks:
      - ailoos-network
    logging:
      driver: "json-file"
      options:
        max-size: "50m"
        max-file: "5"

  # ----------------------------------------------------------------------------
  # Nginx Reverse Proxy (optional)
  # ----------------------------------------------------------------------------
  nginx:
    image: nginx:alpine
    container_name: ailoos-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./config/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./config/ssl:/etc/nginx/ssl:ro
    depends_on:
      - coordinator
    networks:
      - ailoos-network
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

# ----------------------------------------------------------------------------
# Networks
# ----------------------------------------------------------------------------
networks:
  ailoos-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.28.0.0/16

# ----------------------------------------------------------------------------
# Volumes
# ----------------------------------------------------------------------------
volumes:
  postgres_data:
    driver: local
  redis_data:
    driver: local
EOF
    
    chmod 644 "${COMPOSE_FILE}"
    log_success "Docker Compose configuration created"
}

# Create Nginx configuration
create_nginx_config() {
    log_step "Creating Nginx configuration..."
    
    NGINX_CONF="${CONFIG_DIR}/nginx.conf"
    
    mkdir -p "${CONFIG_DIR}/ssl"
    
    cat > "${NGINX_CONF}" << 'EOF'
events {
    worker_connections 1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    # Logging format
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;
    error_log /var/log/nginx/error.log warn;

    # Performance
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml+rss application/rss+xml font/truetype font/opentype application/vnd.ms-fontobject image/svg+xml;

    # Upstream for coordinator
    upstream coordinator {
        server coordinator:8000;
    }

    server {
        listen 80;
        server_name 212.227.95.247;

        # Redirect to HTTPS (uncomment after SSL setup)
        # return 301 https://$server_name$request_uri;

        location / {
            proxy_pass http://coordinator;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
            
            # Timeouts
            proxy_connect_timeout 60s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        # Health check endpoint
        location /health {
            proxy_pass http://coordinator/health;
            access_log off;
        }

        # WebSocket support
        location /ws {
            proxy_pass http://coordinator;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
            proxy_set_header Host $host;
            proxy_read_timeout 86400;
        }

        # Static files
        location /static {
            proxy_pass http://coordinator;
            proxy_set_header Host $host;
        }
    }
}
EOF
    
    # Create self-signed SSL certificates for development
    if [[ ! -f "${CONFIG_DIR}/ssl/cert.pem" ]]; then
        log_info "Generating self-signed SSL certificate..."
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout "${CONFIG_DIR}/ssl/key.pem" \
            -out "${CONFIG_DIR}/ssl/cert.pem" \
            -subj "/C=ES/ST=Madrid/L=Madrid/O=Ailoos/OU=Dev/CN=${SERVER_IP}" \
            2>/dev/null || true
    fi
    
    chmod 644 "${NGINX_CONF}"
    log_success "Nginx configuration created"
}

# Create systemd service for auto-start
create_systemd_service() {
    log_step "Creating systemd service..."
    
    SERVICE_FILE="/etc/systemd/system/ailoos-coordinator.service"
    
    cat > "${SERVICE_FILE}" << EOF
[Unit]
Description=Ailoos Coordinator Service
Requires=docker.service
After=docker.service network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=${APP_DIR}
ExecStart=/usr/bin/docker-compose -f ${APP_DIR}/docker-compose.yml up -d
ExecStop=/usr/bin/docker-compose -f ${APP_DIR}/docker-compose.yml down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable ailoos-coordinator.service
    
    log_success "Systemd service created"
}

# Pull Docker images
pull_images() {
    log_step "Pulling Docker images..."
    
    cd "${APP_DIR}"
    
    docker-compose pull postgres redis
    
    log_success "Docker images pulled"
}

# Start services
start_services() {
    log_step "Starting services..."
    
    cd "${APP_DIR}"
    
    # Start PostgreSQL and Redis first
    docker-compose up -d postgres redis
    
    # Wait for PostgreSQL to be healthy
    log_info "Waiting for PostgreSQL to be ready..."
    for i in {1..30}; do
        if docker-compose exec -T postgres pg_isready -U ailoos -d ailoos &>/dev/null; then
            log_success "PostgreSQL is ready"
            break
        fi
        sleep 2
    done
    
    # Wait for Redis to be healthy
    log_info "Waiting for Redis to be ready..."
    for i in {1..15}; do
        if docker-compose exec -T redis redis-cli -a "${REDIS_PASSWORD}" ping &>/dev/null; then
            log_success "Redis is ready"
            break
        fi
        sleep 2
    done
    
    # Start coordinator
    docker-compose up -d coordinator
    
    # Start nginx (optional)
    # docker-compose up -d nginx
    
    log_success "Services started"
}

# Verify deployment
verify_deployment() {
    log_step "Verifying deployment..."
    
    # Check containers
    log_info "Checking containers..."
    docker ps --filter "name=ailoos" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
    
    # Check PostgreSQL
    log_info "Checking PostgreSQL..."
    if docker-compose exec -T postgres pg_isready -U ailoos -d ailoos &>/dev/null; then
        log_success "PostgreSQL is healthy"
    else
        log_warning "PostgreSQL check failed"
    fi
    
    # Check Redis
    log_info "Checking Redis..."
    source "${CONFIG_DIR}/secrets.env"
    if docker-compose exec -T redis redis-cli -a "${REDIS_PASSWORD}" ping &>/dev/null; then
        log_success "Redis is healthy"
    else
        log_warning "Redis check failed"
    fi
    
    # Check Coordinator API
    log_info "Checking Coordinator API..."
    for i in {1..10}; do
        if curl -sf http://localhost:8000/health &>/dev/null; then
            log_success "Coordinator API is healthy"
            break
        fi
        sleep 2
    done
    
    # Show endpoints
    echo ""
    echo "=============================================="
    echo "  AILOOS Coordinator Deployment Complete!"
    echo "=============================================="
    echo ""
    echo "  Server IP: ${SERVER_IP}"
    echo "  Coordinator API: http://${SERVER_IP}:${COORDINATOR_PORT}"
    echo "  Health Check: http://${SERVER_IP}:${COORDINATOR_PORT}/health"
    echo "  API Docs: http://${SERVER_IP}:${COORDINATOR_PORT}/docs"
    echo ""
    echo "  PostgreSQL: ${SERVER_IP}:${POSTGRES_PORT}"
    echo "  Redis: ${SERVER_IP}:${REDIS_PORT}"
    echo ""
    echo "  Configuration: ${CONFIG_DIR}/.env"
    echo "  Logs: ${LOG_DIR}"
    echo ""
    echo "=============================================="
    echo ""
    echo "Useful commands:"
    echo "  View logs:     cd ${APP_DIR} && docker-compose logs -f"
    echo "  Stop services: cd ${APP_DIR} && docker-compose down"
    echo "  Restart:       cd ${APP_DIR} && docker-compose restart"
    echo "  Status:        docker ps"
    echo ""
}

# Show help
show_help() {
    cat << EOF
AILOOS Coordinator Deployment Script
======================================

Usage: $0 [COMMAND]

Commands:
    install       Install all dependencies (Docker, Docker Compose)
    configure     Create configuration files
    start         Start all services
    stop          Stop all services
    restart       Restart all services
    status        Show service status
    logs          Show logs (use -f to follow)
    update        Update and restart services
    full          Run full deployment (install + configure + start)
    help          Show this help message

Examples:
    $0 full           # Full deployment
    $0 install        # Install dependencies only
    $0 configure      # Create configuration only
    $0 start          # Start services
    $0 logs -f        # Follow logs

EOF
}

# Main function
main() {
    COMMAND="${1:-help}"
    
    echo ""
    echo "=============================================="
    echo "  AILOOS Coordinator Deployment Script"
    echo "  Server: Arsys (${SERVER_IP})"
    echo "=============================================="
    echo ""
    
    case "$COMMAND" in
        install)
            check_root
            detect_os
            update_system
            install_dependencies
            install_docker
            install_docker_compose
            configure_firewall
            log_success "Installation complete!"
            ;;
        
        configure)
            check_root
            create_directories
            generate_secrets
            create_env_file
            create_docker_compose
            create_nginx_config
            create_systemd_service
            log_success "Configuration complete!"
            ;;
        
        start)
            check_root
            start_services
            ;;
        
        stop)
            check_root
            cd "${APP_DIR}"
            docker-compose down
            log_success "Services stopped"
            ;;
        
        restart)
            check_root
            cd "${APP_DIR}"
            docker-compose restart
            log_success "Services restarted"
            ;;
        
        status)
            docker ps --filter "name=ailoos" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
            ;;
        
        logs)
            cd "${APP_DIR}"
            if [[ "${2:-}" == "-f" ]]; then
                docker-compose logs -f
            else
                docker-compose logs --tail=100
            fi
            ;;
        
        update)
            check_root
            cd "${APP_DIR}"
            docker-compose pull
            docker-compose up -d
            log_success "Services updated"
            ;;
        
        pull)
            check_root
            pull_images
            ;;
        
        full)
            check_root
            detect_os
            update_system
            install_dependencies
            install_docker
            install_docker_compose
            configure_firewall
            create_directories
            generate_secrets
            create_env_file
            create_docker_compose
            create_nginx_config
            create_systemd_service
            pull_images
            start_services
            verify_deployment
            ;;
        
        help|--help|-h)
            show_help
            ;;
        
        *)
            log_error "Unknown command: $COMMAND"
            show_help
            exit 1
            ;;
    esac
}

# Run main function
main "$@"
