#!/usr/bin/env python3
"""
Prepare calibration/performance data for quantization.
Outputs a .pt file with input_ids (+ attention_mask if available).
"""

import argparse
import json
from pathlib import Path
from typing import List

import torch
from transformers import AutoTokenizer


def _load_texts(path: Path, field: str) -> List[str]:
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")

    texts: List[str] = []
    suffix = path.suffix.lower()

    if suffix in (".txt", ".text"):
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line:
                    texts.append(line)
        return texts

    if suffix == ".jsonl":
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                payload = json.loads(line)
                value = payload.get(field)
                if value:
                    texts.append(str(value))
        return texts

    if suffix == ".json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, list):
            for item in payload:
                if isinstance(item, dict):
                    value = item.get(field)
                    if value:
                        texts.append(str(value))
                else:
                    texts.append(str(item))
        elif isinstance(payload, dict):
            value = payload.get(field)
            if isinstance(value, list):
                texts.extend([str(v) for v in value])
            elif value:
                texts.append(str(value))
        return texts

    raise ValueError("Unsupported input format. Use .txt, .jsonl, or .json")


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare quantization data.")
    parser.add_argument("--input", required=True, help="Path to .txt/.jsonl/.json with samples.")
    parser.add_argument("--output", required=True, help="Path to output .pt file.")
    parser.add_argument("--tokenizer", required=True, help="Tokenizer name or model path.")
    parser.add_argument("--field", default="text", help="JSON/JSONL field to read.")
    parser.add_argument("--max-samples", type=int, default=1024, help="Max samples to include.")
    parser.add_argument("--max-length", type=int, default=512, help="Max token length.")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    texts = _load_texts(input_path, args.field)
    if not texts:
        raise ValueError("No texts found in input file.")

    if args.max_samples and len(texts) > args.max_samples:
        texts = texts[:args.max_samples]

    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer, trust_remote_code=True)
    tokenized = tokenizer(
        texts,
        padding="max_length",
        truncation=True,
        max_length=args.max_length,
        return_tensors="pt"
    )

    payload = {
        "input_ids": tokenized["input_ids"],
        "attention_mask": tokenized.get("attention_mask"),
    }
    torch.save(payload, output_path)

    print(f"Saved {len(texts)} samples to {output_path}")


if __name__ == "__main__":
    main()
