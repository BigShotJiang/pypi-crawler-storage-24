#!/usr/bin/env bash
set -euo pipefail

# Certify one external node against real testnet bridge path.
# Output: artifacts/e2e_nodes/<node_id>_<timestamp>.json

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/artifacts/e2e_nodes"
mkdir -p "$OUT_DIR"

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  cat <<'USAGE'
Usage:
  scripts/certify_external_node.sh --node-id <NODE_ID> --dataset-id <DATASET_ID> --units <N> [--claim]

Required env:
  DRACMA_BRIDGE_URL
  DRACMA_BRIDGE_BASIC_AUTH_USER
  DRACMA_BRIDGE_BASIC_AUTH_PASS
  AILOOS_BRIDGE_PRIVATE_KEY
  AILOOS_REWARDS_BRIDGE_ONLY=1
  AILOOS_USE_LOCAL_STATE_CHANNEL=0

Tip:
  cp scripts/external_node.env.example .env.external-node
  set -a; source .env.external-node; set +a
USAGE
  exit 0
fi

NODE_ID=""
DATASET_ID=""
UNITS=""
DO_CLAIM=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --node-id) NODE_ID="${2:-}"; shift 2 ;;
    --dataset-id) DATASET_ID="${2:-}"; shift 2 ;;
    --units) UNITS="${2:-}"; shift 2 ;;
    --claim) DO_CLAIM=1; shift ;;
    *) echo "Unknown arg: $1"; exit 2 ;;
  esac
done

[[ -n "$NODE_ID" ]] || { echo "ERROR: --node-id required"; exit 2; }
[[ -n "$DATASET_ID" ]] || { echo "ERROR: --dataset-id required"; exit 2; }
[[ -n "$UNITS" ]] || { echo "ERROR: --units required"; exit 2; }

for v in DRACMA_BRIDGE_URL DRACMA_BRIDGE_BASIC_AUTH_USER DRACMA_BRIDGE_BASIC_AUTH_PASS AILOOS_BRIDGE_PRIVATE_KEY AILOOS_REWARDS_BRIDGE_ONLY AILOOS_USE_LOCAL_STATE_CHANNEL; do
  [[ -n "${!v:-}" ]] || { echo "ERROR: missing env $v"; exit 2; }
done

[[ "${AILOOS_REWARDS_BRIDGE_ONLY}" == "1" ]] || { echo "ERROR: AILOOS_REWARDS_BRIDGE_ONLY must be 1"; exit 2; }
[[ "${AILOOS_USE_LOCAL_STATE_CHANNEL}" == "0" ]] || { echo "ERROR: AILOOS_USE_LOCAL_STATE_CHANNEL must be 0"; exit 2; }

export PYTHONPATH="$ROOT_DIR/src"

STAMP="$(date -u +%Y%m%d_%H%M%S)"
OUT_JSON="$OUT_DIR/${NODE_ID}_${STAMP}.json"

CMD=(python3 "$ROOT_DIR/scripts/e2e_rewards_real.py" --node-id "$NODE_ID" --dataset-id "$DATASET_ID" --units "$UNITS")
if [[ "$DO_CLAIM" -eq 1 ]]; then
  CMD+=(--claim)
fi

"${CMD[@]}" | tee "$OUT_JSON"

python3 - "$OUT_JSON" <<'PY'
import json, sys
p=sys.argv[1]
with open(p, "r", encoding="utf-8") as f:
    data=json.load(f)
steps=data.get("steps", {})
ok=True
if not steps.get("report_work", {}).get("success"):
    ok=False
if "pending_after" not in steps:
    ok=False
if "claim" in steps and not steps["claim"].get("skipped", False):
    if not steps["claim"].get("success"):
        ok=False
print("CERT_PASS" if ok else "CERT_FAIL")
sys.exit(0 if ok else 1)
PY

echo "Evidence: $OUT_JSON"

