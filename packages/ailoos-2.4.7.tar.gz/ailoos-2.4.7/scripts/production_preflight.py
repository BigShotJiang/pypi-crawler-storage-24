import sys
import os
import shutil
import platform
import logging
from pathlib import Path
import psutil

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger("Preflight")

def check_python_version():
    req_version = (3, 9)
    current = sys.version_info
    if current < req_version:
        logger.error(f"❌ Python version {current.major}.{current.minor} is too old. Required: {req_version[0]}.{req_version[1]}+")
        return False
    logger.info(f"✅ Python Version: {platform.python_version()}")
    return True

def check_resources():
    # Memory > 8GB for Production
    mem = psutil.virtual_memory()
    total_gb = mem.total / (1024**3)
    if total_gb < 7.5:
        logger.warning(f"⚠️ Low Memory: {total_gb:.1f}GB. Recommended: 8GB+")
    else:
        logger.info(f"✅ Memory: {total_gb:.1f}GB")

    # Disk Space > 20GB free
    disk = shutil.disk_usage("/")
    free_gb = disk.free / (1024**3)
    if free_gb < 20:
        logger.error(f"❌ Low Disk Space: {free_gb:.1f}GB free. Required: 20GB+")
        return False
    logger.info(f"✅ Disk Space: {free_gb:.1f}GB free")
    return True

def check_cuda():
    try:
        import torch
        if torch.cuda.is_available():
            logger.info(f"✅ CUDA Available: {torch.cuda.get_device_name(0)}")
            return True
        else:
            logger.warning("⚠️ CUDA not available. Running in CPU mode (slower).")
            return True # Not strictly fatal
    except ImportError:
        logger.warning("⚠️ PyTorch not installed/found. Skipping CUDA check.")
        return True

def check_ulimit():
    # Check open file limits
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        if soft < 1024:
            logger.warning(f"⚠️ Soft file limit too low: {soft}. Recommended: 4096+")
        else:
            logger.info(f"✅ File descriptors limit: {soft}")
    except ImportError:
        pass # Windows?

def main():
    logger.info("🚀 Starting Ailoos Production Pre-flight Checks...")
    
    checks = [
        check_python_version(),
        check_resources(),
        check_cuda()
    ]
    
    check_ulimit()

    if all(checks):
        logger.info("✅ SYSTEM READY FOR TAKEOFF")
        sys.exit(0)
    else:
        logger.error("❌ CRTICAL CHECKS FAILED")
        sys.exit(1)

if __name__ == "__main__":
    main()
