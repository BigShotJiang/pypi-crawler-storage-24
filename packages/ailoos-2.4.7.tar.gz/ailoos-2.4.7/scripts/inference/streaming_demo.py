#!/usr/bin/env python3
"""
Run a local streaming inference demo and print tokens as they arrive.
"""

import argparse
import asyncio

from src.ailoos.inference.engine import InferenceEngine


async def run_demo(args: argparse.Namespace) -> None:
    engine = InferenceEngine(model_path=args.model_path, load_in_8bit=args.load_in_8bit)
    async for token in engine.generate(
        prompt=args.prompt,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
    ):
        print(token, end="", flush=True)
    print()


def main() -> None:
    parser = argparse.ArgumentParser(description="Streaming inference demo.")
    parser.add_argument("--model-path", default="Empoorio/EmpoorioLM-7B", help="Model path or name.")
    parser.add_argument("--prompt", required=True, help="Prompt text.")
    parser.add_argument("--max-new-tokens", type=int, default=200)
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--load-in-8bit", action="store_true", default=False)
    args = parser.parse_args()

    asyncio.run(run_demo(args))


if __name__ == "__main__":
    main()
