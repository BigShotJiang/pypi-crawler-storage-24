#!/usr/bin/env bash
# Ailoos PostgreSQL backup script (Docker Compose)
# Creates compressed backups with retention and optional S3 upload.

set -euo pipefail
IFS=$'\n\t'

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
PROJECT_DIR=${PROJECT_DIR:-$(cd "$SCRIPT_DIR/.." && pwd)}
ENV_FILE=${ENV_FILE:-.env.production}

cd "$PROJECT_DIR"

if [[ -f "$ENV_FILE" ]]; then
    set -a
    # shellcheck disable=SC1090
    . "$ENV_FILE"
    set +a
fi

BACKUP_DIR="${BACKUP_DIR:-/opt/ailoos/backups/postgres}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
POSTGRES_SERVICE="${POSTGRES_SERVICE:-postgres}"
DB_NAME="${DB_NAME:-${POSTGRES_DB:-ailoos_coordinator}}"
DB_USER="${DB_USER:-${POSTGRES_USER:-ailoos_coordinator}}"
DB_PASSWORD="${DB_PASSWORD:-${POSTGRES_PASSWORD:-}}"
S3_BUCKET="${S3_BUCKET:-}"  # Optional: s3://ailoos-backups/postgres
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="backup_${DB_NAME}_${DATE}.sql.gz"

COMPOSE_FILE_INPUT="${COMPOSE_FILE:-}"
if [[ -z "$COMPOSE_FILE_INPUT" ]]; then
    if [[ -f "docker-compose.production.yml" ]]; then
        COMPOSE_FILE_INPUT="docker-compose.production.yml"
    elif [[ -f "docker-compose.yml" ]]; then
        COMPOSE_FILE_INPUT="docker-compose.yml"
    else
        echo "No compose file found." >&2
        exit 1
    fi
fi

COMPOSE_FILE_PATH="$COMPOSE_FILE_INPUT"
if [[ ! -f "$COMPOSE_FILE_PATH" && -f "$PROJECT_DIR/$COMPOSE_FILE_PATH" ]]; then
    COMPOSE_FILE_PATH="$PROJECT_DIR/$COMPOSE_FILE_PATH"
fi

if [[ ! -f "$COMPOSE_FILE_PATH" ]]; then
    echo "Compose file not found: $COMPOSE_FILE_INPUT" >&2
    exit 1
fi

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    log_error "Docker is not running"
    exit 1
fi

if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    DC=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
    DC=(docker-compose)
else
    log_error "docker compose not found"
    exit 1
fi

SERVICE_ID=$("${DC[@]}" -f "$COMPOSE_FILE_PATH" ps -q "$POSTGRES_SERVICE" 2>/dev/null || true)
if [[ -z "$SERVICE_ID" ]]; then
    log_error "Postgres service not running: ${POSTGRES_SERVICE}"
    exit 1
fi

log_info "Using compose file: ${COMPOSE_FILE_PATH}"
log_info "Starting backup of ${DB_NAME} from service ${POSTGRES_SERVICE}"

# Perform backup
EXEC_ENV=()
if [[ -n "$DB_PASSWORD" ]]; then
    EXEC_ENV=(-e "PGPASSWORD=$DB_PASSWORD")
fi

if "${DC[@]}" -f "$COMPOSE_FILE_PATH" exec -T "${EXEC_ENV[@]}" "$POSTGRES_SERVICE" \
    pg_dump -U "$DB_USER" "$DB_NAME" | gzip > "${BACKUP_DIR}/${BACKUP_FILE}"; then
    BACKUP_SIZE=$(du -h "${BACKUP_DIR}/${BACKUP_FILE}" | cut -f1)
    log_info "Backup completed successfully: ${BACKUP_FILE} (${BACKUP_SIZE})"
else
    log_error "Backup failed"
    rm -f "${BACKUP_DIR}/${BACKUP_FILE}"
    exit 1
fi

# Verify backup integrity
if gzip -t "${BACKUP_DIR}/${BACKUP_FILE}" > /dev/null 2>&1; then
    log_info "Backup integrity verified"
else
    log_error "Backup file is corrupted"
    exit 1
fi

# Apply retention policy
log_info "Applying retention policy (${RETENTION_DAYS} days)"
DELETED_COUNT=$(find "$BACKUP_DIR" -name "backup_${DB_NAME}_*.sql.gz" -mtime +${RETENTION_DAYS} -delete -print | wc -l)
if [ "$DELETED_COUNT" -gt 0 ]; then
    log_info "Deleted ${DELETED_COUNT} old backup(s)"
fi

# Optional: Upload to S3
if [ -n "$S3_BUCKET" ]; then
    DEST="${S3_BUCKET%/}/${BACKUP_FILE}"
    log_info "Uploading backup to S3: ${DEST}"
    if command -v aws > /dev/null 2>&1; then
        if aws s3 cp "${BACKUP_DIR}/${BACKUP_FILE}" "${DEST}"; then
            log_info "S3 upload completed successfully"
        else
            log_warn "S3 upload failed (backup still available locally)"
        fi
    else
        log_warn "AWS CLI not installed, skipping S3 upload"
    fi
fi

# Summary
TOTAL_BACKUPS=$(find "$BACKUP_DIR" -name "backup_*.sql.gz" | wc -l)
TOTAL_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
log_info "Backup summary:"
log_info "  - Total backups: ${TOTAL_BACKUPS}"
log_info "  - Total size: ${TOTAL_SIZE}"
log_info "  - Latest: ${BACKUP_FILE}"

exit 0
