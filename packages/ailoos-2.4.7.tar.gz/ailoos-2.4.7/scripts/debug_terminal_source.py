
import sys
import os
from pathlib import Path

# Add src to sys.path
sys.path.insert(0, str(Path.cwd() / "src"))

from ailoos.cli.terminal import AILOOSTerminal
import inspect

def main():
    terminal = AILOOSTerminal()
    source = inspect.getsource(terminal.run)
    print("--- START OF RUN SOURCE ---")
    print(source)
    print("--- END OF RUN SOURCE ---")

if __name__ == "__main__":
    main()
