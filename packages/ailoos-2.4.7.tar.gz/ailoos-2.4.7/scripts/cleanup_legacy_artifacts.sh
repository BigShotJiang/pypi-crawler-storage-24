#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

STAMP="$(date +%Y%m%d_%H%M%S)"
ARCHIVE_DIR="artifacts/legacy_archive/${STAMP}"

FILES=(
  "grep_findings.txt"
  "placeholders_report.json"
  "placeholders_report.txt"
  "src/placeholders_report.json"
  "src/placeholders_report.txt"
)

mkdir -p "$ARCHIVE_DIR"
MOVED=0

for f in "${FILES[@]}"; do
  if [[ -f "$f" ]]; then
    mkdir -p "$ARCHIVE_DIR/$(dirname "$f")"
    mv "$f" "$ARCHIVE_DIR/$f"
    echo "moved: $f -> $ARCHIVE_DIR/$f"
    MOVED=$((MOVED+1))
  fi
done

echo "done. moved_files=$MOVED archive=$ARCHIVE_DIR"
