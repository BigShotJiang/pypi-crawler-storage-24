#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

ENV_FILE=${ENV_FILE:-.env.production}

required_files=(
  "docker-compose.production.yml"
  "infra/nginx/ailoos_ssl_hardened.conf"
  "infra/nginx/nginx.conf"
  "infra/prometheus/prometheus.yml"
  "infra/grafana/provisioning/datasources/prometheus.yml"
)

required_env=(
  "DB_PASSWORD"
  "REDIS_PASSWORD"
  "JWT_SECRET_KEY"
  "GRAFANA_PASSWORD"
)

missing_files=()
for f in "${required_files[@]}"; do
  if [[ ! -f "$f" ]]; then
    missing_files+=("$f")
  fi
done

missing_env=()
if [[ -f "$ENV_FILE" ]]; then
  for key in "${required_env[@]}"; do
    if ! grep -q "^${key}=" "$ENV_FILE"; then
      missing_env+=("$key")
      continue
    fi
    value=$(grep "^${key}=" "$ENV_FILE" | head -1 | cut -d= -f2-)
    if [[ -z "$value" ]]; then
      missing_env+=("$key")
    fi
  done
else
  missing_env=("ALL")
fi

echo "Preflight: production readiness"

echo "- Files:"
if [[ ${#missing_files[@]} -eq 0 ]]; then
  echo "  OK"
else
  printf "  Missing: %s\n" "${missing_files[*]}"
fi

echo "- Env:"
if [[ ${#missing_env[@]} -eq 0 ]]; then
  echo "  OK"
else
  if [[ ${missing_env[0]} == "ALL" ]]; then
    echo "  Missing $ENV_FILE (create from .env.production.example)"
  else
    printf "  Missing values: %s\n" "${missing_env[*]}"
  fi
fi

if command -v docker >/dev/null 2>&1; then
  if docker compose version >/dev/null 2>&1; then
    echo "- docker compose: OK"
    docker compose -f docker-compose.production.yml config >/dev/null 2>&1 || \
      echo "  WARNING: docker compose config failed"
  else
    echo "- docker compose: not available"
  fi
else
  echo "- docker: not available"
fi

if command -v nginx >/dev/null 2>&1; then
  echo "- nginx: installed"
else
  echo "- nginx: not installed"
fi

if command -v openssl >/dev/null 2>&1; then
  echo "- openssl: OK"
else
  echo "- openssl: not installed"
fi

if [[ ${#missing_files[@]} -eq 0 && ${#missing_env[@]} -eq 0 ]]; then
  echo "Preflight OK"
else
  echo "Preflight incomplete"
  exit 1
fi
