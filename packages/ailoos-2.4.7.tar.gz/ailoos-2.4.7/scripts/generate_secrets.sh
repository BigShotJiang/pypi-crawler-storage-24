#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="${1:-.env.production}"

if ! command -v openssl >/dev/null 2>&1; then
  echo "openssl not found; install it before running this script." >&2
  exit 1
fi

touch "${ENV_FILE}"
chmod 600 "${ENV_FILE}"

append_if_missing() {
  local key="$1"
  local value="$2"
  if ! grep -q "^${key}=" "${ENV_FILE}"; then
    echo "${key}=${value}" >> "${ENV_FILE}"
  fi
}

append_if_missing "DB_PASSWORD" "$(openssl rand -base64 32)"
append_if_missing "REDIS_PASSWORD" "$(openssl rand -base64 32)"
append_if_missing "JWT_SECRET_KEY" "$(openssl rand -base64 48)"
append_if_missing "GRAFANA_PASSWORD" "$(openssl rand -base64 24)"

echo "Secrets written to ${ENV_FILE}"
