try:
    import psycopg2
except ImportError:
    print("❌ Missing dependency: psycopg2-binary. Install with: pip install psycopg2-binary")
    raise SystemExit(1)
import sys
import os

# URL from .env (root)
DB_URL = os.getenv("DATABASE_URL") or os.getenv("DB_URL")
if not DB_URL:
    print("❌ Missing DATABASE_URL/DB_URL environment variable")
    sys.exit(1)

SQL_CREATE_SECURITY = """
CREATE TABLE IF NOT EXISTS "security_settings" (
	"user_id" text PRIMARY KEY NOT NULL REFERENCES "user"("id") ON DELETE CASCADE,
	"two_factor_enabled" boolean DEFAULT false NOT NULL,
	"session_timeout_minutes" integer DEFAULT 60 NOT NULL,
	"login_alerts_enabled" boolean DEFAULT false NOT NULL,
	"password_last_changed" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
"""

def create_security_table():
    print(f"Connecting to {DB_URL}...")
    try:
        conn = psycopg2.connect(DB_URL)
        conn.autocommit = True
        cur = conn.cursor()
        
        print("Creating security_settings table...")
        cur.execute(SQL_CREATE_SECURITY)
        print("✅ security_settings table created.")
        
        conn.close()
    except Exception as e:
        print(f"❌ Creation failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    create_security_table()
