#!/usr/bin/env bash
set -euo pipefail

# Daily real E2E rewards check (bridge/on-chain), writes JSON artifacts.
# Required env vars:
# - AILOOS_BRIDGE_PRIVATE_KEY
# - E2E_NODE_ID
# - E2E_DATASET_ID
# Optional:
# - E2E_UNITS (default 25)
# - E2E_WALLET
# - AILOOS_ENV (default production)

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${ROOT_DIR}/artifacts/e2e_rewards"
mkdir -p "${OUT_DIR}"

export PYTHONPATH="${ROOT_DIR}/src"
export AILOOS_ENV="${AILOOS_ENV:-production}"
export AILOOS_REWARDS_BRIDGE_ONLY=1
export AILOOS_USE_LOCAL_STATE_CHANNEL=0

: "${AILOOS_BRIDGE_PRIVATE_KEY:?Missing AILOOS_BRIDGE_PRIVATE_KEY}"
: "${E2E_NODE_ID:?Missing E2E_NODE_ID}"
: "${E2E_DATASET_ID:?Missing E2E_DATASET_ID}"

E2E_UNITS="${E2E_UNITS:-25}"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
REPORT_FILE="${OUT_DIR}/e2e_rewards_${STAMP}.json"

CMD=(
  python3 "${ROOT_DIR}/scripts/e2e_rewards_real.py"
  --node-id "${E2E_NODE_ID}"
  --dataset-id "${E2E_DATASET_ID}"
  --units "${E2E_UNITS}"
  --claim
)

if [[ -n "${E2E_WALLET:-}" ]]; then
  CMD+=(--wallet "${E2E_WALLET}")
fi

"${CMD[@]}" > "${REPORT_FILE}"
echo "E2E rewards report: ${REPORT_FILE}"
