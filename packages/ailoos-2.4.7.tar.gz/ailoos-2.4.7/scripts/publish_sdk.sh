#!/bin/bash
# AILOOS SDK Publication Script

set -e

SDK_VERSION="$(python3 - <<'PY'
from pathlib import Path
try:
    import tomllib
except Exception:
    tomllib = None
txt = Path("pyproject.toml").read_text(encoding="utf-8")
if tomllib is not None:
    data = tomllib.loads(txt)
    print(data.get("project", {}).get("version", "unknown"))
else:
    import re
    m = re.search(r'^version\s*=\s*"([^"]+)"', txt, re.M)
    print(m.group(1) if m else "unknown")
PY
)"

echo "🚀 Preparando lanzamiento de AILOOS SDK v${SDK_VERSION}..."

# 1. Limpieza
echo "🧹 Limpiando builds anteriores..."
rm -rf dist/ build/ *.egg-info

# 2. Construcción
echo "📦 Construyendo sdist y wheel..."
if ! python3 -m build; then
    echo "⚠️ Build aislado falló; reintentando sin aislamiento (entorno local)..."
    if ! python3 -m build --no-isolation; then
        if ! python3 -c "import wheel" >/dev/null 2>&1; then
            echo "⚠️ 'wheel' no está disponible; generando solo sdist con setuptools..."
            python3 setup.py sdist
        else
            echo "❌ Falló build sin aislamiento."
            exit 1
        fi
    fi
fi

# 3. Verificación
echo "🔍 Verificando integridad del paquete..."
SDIST="dist/ailoos-${SDK_VERSION}.tar.gz"
if [ -f "$SDIST" ]; then
    echo "✅ Archivo fuente generado: $SDIST"
    # Verificar si incluye el directorio security
    tar -tzf "$SDIST" | grep "ailoos/security/" > /dev/null && echo "✅ Directorio 'security' incluido." || echo "❌ ERROR: 'security' no se incluyó."
else
    echo "❌ ERROR: No se generó el archivo $SDIST"
    exit 1
fi

echo ""
echo "🎉 ¡Todo listo! Para subir a PyPI ejecuta:"
echo "   twine upload dist/*"
echo ""
echo "Nota: Necesitarás tener instalado 'twine' y 'wheel'."
