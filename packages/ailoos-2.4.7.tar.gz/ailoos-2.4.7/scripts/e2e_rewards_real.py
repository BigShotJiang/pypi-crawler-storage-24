#!/usr/bin/env python3
"""
Real E2E rewards check against bridge/on-chain path.

Flow:
1) Read pending rewards for node_id.
2) Report work units through bridge.
3) Read pending rewards again.
4) Optionally claim rewards.
"""

import argparse
import asyncio
import json
import os
import sys
from datetime import datetime, timezone

from ailoos.blockchain.rewards_manager import RewardsManager
from ailoos.blockchain.work_reporting import WorkReportingManager
from ailoos.blockchain.bridge_client import get_bridge_client


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


async def run(args: argparse.Namespace) -> int:
    if os.getenv("AILOOS_USE_LOCAL_STATE_CHANNEL", "0").lower() in {"1", "true", "yes"}:
        print("ERROR: AILOOS_USE_LOCAL_STATE_CHANNEL must be 0 for real on-chain E2E.")
        return 2

    if not os.getenv("AILOOS_BRIDGE_PRIVATE_KEY"):
        print("ERROR: AILOOS_BRIDGE_PRIVATE_KEY is required for signed bridge requests.")
        return 2

    rewards = RewardsManager()
    work = WorkReportingManager()
    bridge = get_bridge_client()

    report = {
        "timestamp": _utc_now(),
        "node_id": args.node_id,
        "dataset_id": args.dataset_id,
        "units_reported": args.units,
        "steps": {},
    }

    before = await rewards.get_pending_rewards(args.node_id)
    report["steps"]["pending_before"] = {
        "amount": before.amount,
        "last_updated": before.last_updated,
    }

    work_result = await work.report_training_work(
        node_id=args.node_id,
        units=args.units,
        dataset_id=args.dataset_id,
        proof_hash=args.proof_hash,
    )
    report["steps"]["report_work"] = {
        "success": work_result.get("success", False),
        "transaction_hash": work_result.get("transaction_hash"),
        "message": work_result.get("message"),
    }

    after = await rewards.get_pending_rewards(args.node_id)
    report["steps"]["pending_after"] = {
        "amount": after.amount,
        "last_updated": after.last_updated,
    }

    if args.claim:
        claim_result = await rewards.claim_node_rewards(args.node_id)
        claim = claim_result.get("claim")
        report["steps"]["claim"] = {
            "success": claim_result.get("success", False),
            "amount": getattr(claim, "amount", 0),
            "tx_hash": getattr(claim, "transaction_hash", ""),
            "status": getattr(claim, "status", ""),
        }
    else:
        report["steps"]["claim"] = {"skipped": True}

    if args.wallet:
        wallet_result = await bridge.get_wallet_balance(args.wallet)
        report["steps"]["wallet_balance"] = wallet_result

    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Run real bridge rewards E2E check.")
    parser.add_argument("--node-id", required=True, help="Empoorio node id.")
    parser.add_argument("--dataset-id", required=True, help="Dataset id for work report.")
    parser.add_argument("--units", required=True, type=int, help="Work units to report.")
    parser.add_argument("--proof-hash", default=None, help="Optional proof hash.")
    parser.add_argument("--wallet", default=None, help="Optional wallet address for balance check.")
    parser.add_argument("--claim", action="store_true", help="Claim rewards after reporting.")
    args = parser.parse_args()

    if args.units <= 0:
        print("ERROR: --units must be > 0")
        return 2

    try:
        return asyncio.run(run(args))
    except Exception as exc:
        print(f"ERROR: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
