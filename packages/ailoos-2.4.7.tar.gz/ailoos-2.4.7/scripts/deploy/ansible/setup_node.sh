#!/bin/bash
# AILOOS Node Setup Script
# Runs on GCP Confidential VM (Ubuntu 22.04)

set -e

echo "🚀 Starting AILOOS Node Setup..."

# 1. Update & Base Dependencies
apt-get update
apt-get install -y python3-pip python3-venv git docker.io docker-compose

# 2. Verify TEE / SEV Support
echo "🛡️ Verifying AMD SEV support..."
if dmesg | grep -i sev; then
    echo "✅ AMD SEV detected and active."
else
    echo "⚠️ AMD SEV NOT detected! Check VM configuration."
fi

# 3. Install AILOOS SDK
echo "📦 Installing AILOOS SDK..."
mkdir -p /opt/ailoos
cd /opt/ailoos
# In a real scenario, we would clone the private repo or pip install from index
# git clone https://github.com/empoorio/ailoos.git .
# pip3 install .

# 4. Setup Local Datasets directory
mkdir -p /var/lib/ailoos/data
mkdir -p /var/lib/ailoos/models

# 5. Start Monitoring Stack (Optional - if handled by separate compose)
# docker-compose -f /opt/ailoos/scripts/deploy/monitoring/docker-compose.yml up -d

echo "✅ AILOOS Node setup complete."
