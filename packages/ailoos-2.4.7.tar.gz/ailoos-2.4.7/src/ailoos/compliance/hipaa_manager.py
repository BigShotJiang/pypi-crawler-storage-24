"""
HIPAAManager - Gestión de compliance HIPAA para datos médicos.

Implementa:
- Protección de PHI (Protected Health Information)
- Controles de acceso a datos médicos
- Registros de auditoría de acceso
- Notificación de brechas de seguridad
- Encriptación de datos sensibles
"""

import json
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from sqlalchemy.orm import Session

from ..utils.logging import get_logger

logger = get_logger(__name__)


class AccessPurpose(Enum):
    """Propósitos permitidos de acceso a PHI."""
    TREATMENT = "treatment"
    PAYMENT = "payment"
    OPERATIONS = "healthcare_operations"
    RESEARCH = "research"
    PUBLIC_HEALTH = "public_health"
    LEGAL = "legal"
    EMERGENCY = "emergency"


class AccessResult(Enum):
    """Resultado del intento de acceso."""
    GRANTED = "granted"
    DENIED = "denied"
    PENDING_AUTHORIZATION = "pending_authorization"


@dataclass
class PHIAccessLog:
    """Registro de acceso a PHI."""
    log_id: str
    patient_id: str
    accessor_id: str
    accessor_role: str
    purpose: AccessPurpose
    data_accessed: List[str]  # tipos de datos accedidos
    access_result: AccessResult
    access_timestamp: datetime
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    authorization_code: Optional[str] = None
    emergency_override: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BreachNotification:
    """Notificación de brecha de seguridad."""
    breach_id: str
    patient_ids_affected: List[str]
    data_breached: List[str]
    breach_date: datetime
    discovery_date: datetime
    notification_sent: bool = False
    notification_date: Optional[datetime] = None
    risk_assessment: str = ""
    mitigation_actions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EncryptionRecord:
    """Registro de encriptación de datos."""
    record_id: str
    patient_id: str
    data_type: str
    encryption_method: str
    key_id: str
    encrypted_at: datetime
    decrypted_at: Optional[datetime] = None
    access_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


class HIPAAManager:
    """
    Gestor de cumplimiento HIPAA para datos médicos.

    Maneja protección de PHI, controles de acceso, auditoría
    y notificación de brechas de seguridad.
    """

    def __init__(self, db_session: Optional[Session] = None):
        self.db_session = db_session
        self.access_logs: Dict[str, PHIAccessLog] = {}
        self.breach_notifications: Dict[str, BreachNotification] = {}
        self.encryption_records: Dict[str, EncryptionRecord] = {}
        self.authorized_roles = {
            "physician", "nurse", "administrator", "researcher",
            "billing_staff", "it_admin", "emergency_respondent"
        }
        self._initialized = False

    def initialize(self):
        """Inicializar el gestor HIPAA."""
        if not self._initialized:
            self._load_access_logs_from_db()
            self._load_breach_notifications_from_db()
            self._load_encryption_records_from_db()
            self._initialized = True
            logger.info("✅ HIPAAManager inicializado")

    def _load_access_logs_from_db(self):
        """Cargar logs de acceso desde base de datos."""
        try:
            path = self._get_persistence_path("hipaa_access_logs.json")
            if os.path.exists(path):
                with open(path, 'r') as f:
                    data = json.load(f)
                    for log_id, log_data in data.items():
                        # Reconstruct Enum and Datetime objects
                        log_data['purpose'] = AccessPurpose(log_data['purpose'])
                        log_data['access_result'] = AccessResult(log_data['access_result'])
                        log_data['access_timestamp'] = datetime.fromisoformat(log_data['access_timestamp'])
                        self.access_logs[log_id] = PHIAccessLog(**log_data)
        except Exception as e:
            logger.error(f"Error loading HIPAA logs: {e}")

    def _load_breach_notifications_from_db(self):
        """Cargar notificaciones de brecha desde base de datos."""
        try:
            path = self._get_persistence_path("hipaa_breaches.json")
            if os.path.exists(path):
                with open(path, 'r') as f:
                    data = json.load(f)
                    for b_id, b_data in data.items():
                        b_data['breach_date'] = datetime.fromisoformat(b_data['breach_date'])
                        b_data['discovery_date'] = datetime.fromisoformat(b_data['discovery_date'])
                        if b_data.get('notification_date'):
                            b_data['notification_date'] = datetime.fromisoformat(b_data['notification_date'])
                        self.breach_notifications[b_id] = BreachNotification(**b_data)
        except Exception as e:
            logger.error(f"Error loading HIPAA breaches: {e}")

    def _load_encryption_records_from_db(self):
        """Cargar registros de encriptación desde base de datos."""
        try:
            path = self._get_persistence_path("hipaa_encryption.json")
            if os.path.exists(path):
                with open(path, 'r') as f:
                    data = json.load(f)
                    for r_id, r_data in data.items():
                        r_data['encrypted_at'] = datetime.fromisoformat(r_data['encrypted_at'])
                        if r_data.get('decrypted_at'):
                            r_data['decrypted_at'] = datetime.fromisoformat(r_data['decrypted_at'])
                        self.encryption_records[r_id] = EncryptionRecord(**r_data)
        except Exception as e:
            logger.error(f"Error loading HIPAA encryption records: {e}")

    def _get_persistence_path(self, filename: str) -> str:
        """Obtener ruta de persistencia."""
        import os
        base_dir = os.path.dirname(os.path.abspath(__file__))
        data_dir = os.path.join(base_dir, "storage")
        os.makedirs(data_dir, exist_ok=True)
        return os.path.join(data_dir, filename)

    def request_phi_access(self, patient_id: str, accessor_id: str, accessor_role: str,
                          purpose: AccessPurpose, data_requested: List[str],
                          ip_address: Optional[str] = None,
                          user_agent: Optional[str] = None,
                          emergency_override: bool = False) -> Tuple[AccessResult, str]:
        """
        Solicitar acceso a PHI.

        Args:
            patient_id: ID del paciente
            accessor_id: ID del solicitante
            accessor_role: Rol del solicitante
            purpose: Propósito del acceso
            data_requested: Tipos de datos solicitados
            ip_address: Dirección IP
            user_agent: User agent
            emergency_override: Si es acceso de emergencia

        Returns:
            Tupla (resultado, mensaje)
        """
        # Validar rol autorizado
        if accessor_role not in self.authorized_roles:
            result = AccessResult.DENIED
            message = f"Rol no autorizado: {accessor_role}"
        # Validar propósito
        elif not self._is_purpose_valid_for_role(purpose, accessor_role):
            result = AccessResult.DENIED
            message = f"Propósito no válido para el rol: {purpose.value}"
        # Verificar acceso de emergencia
        elif emergency_override and not self._is_emergency_valid(accessor_role):
            result = AccessResult.DENIED
            message = "Acceso de emergencia no autorizado para este rol"
        else:
            result = AccessResult.GRANTED
            message = "Acceso concedido"

        # Crear log de acceso
        log_id = f"phi_access_{patient_id}_{accessor_id}_{datetime.now().timestamp()}"
        access_log = PHIAccessLog(
            log_id=log_id,
            patient_id=patient_id,
            accessor_id=accessor_id,
            accessor_role=accessor_role,
            purpose=purpose,
            data_accessed=data_requested if result == AccessResult.GRANTED else [],
            access_result=result,
            access_timestamp=datetime.now(),
            ip_address=ip_address,
            user_agent=user_agent,
            emergency_override=emergency_override
        )

        self.access_logs[log_id] = access_log
        self._save_access_log_to_db(access_log)

        # Log del resultado
        log_level = logging.INFO if result == AccessResult.GRANTED else logging.WARNING
        logger.log(log_level, f"HIPAA Access {result.value}: {accessor_id} -> {patient_id} for {purpose.value}")

        return result, message

    def log_phi_access(self, patient_id: str, accessor_id: str, accessor_role: str,
                      purpose: AccessPurpose, data_accessed: List[str],
                      authorization_code: Optional[str] = None) -> str:
        """
        Registrar acceso a PHI (para accesos ya realizados).

        Args:
            patient_id: ID del paciente
            accessor_id: ID del accessor
            accessor_role: Rol del accessor
            purpose: Propósito del acceso
            data_accessed: Datos accedidos
            authorization_code: Código de autorización

        Returns:
            ID del log creado
        """
        log_id = f"phi_access_{patient_id}_{accessor_id}_{datetime.now().timestamp()}"
        access_log = PHIAccessLog(
            log_id=log_id,
            patient_id=patient_id,
            accessor_id=accessor_id,
            accessor_role=accessor_role,
            purpose=purpose,
            data_accessed=data_accessed,
            access_result=AccessResult.GRANTED,
            access_timestamp=datetime.now(),
            authorization_code=authorization_code
        )

        self.access_logs[log_id] = access_log
        self._save_access_log_to_db(access_log)

        logger.info(f"✅ PHI Access logged: {log_id}")
        return log_id

    def report_security_breach(self, patient_ids_affected: List[str], data_breached: List[str],
                             breach_date: datetime, risk_assessment: str,
                             mitigation_actions: Optional[List[str]] = None) -> str:
        """
        Reportar brecha de seguridad.

        Args:
            patient_ids_affected: IDs de pacientes afectados
            data_breached: Tipos de datos comprometidos
            breach_date: Fecha de la brecha
            risk_assessment: Evaluación de riesgo
            mitigation_actions: Acciones de mitigación

        Returns:
            ID de la notificación de brecha
        """
        breach_id = f"breach_{datetime.now().timestamp()}"

        breach = BreachNotification(
            breach_id=breach_id,
            patient_ids_affected=patient_ids_affected,
            data_breached=data_breached,
            breach_date=breach_date,
            discovery_date=datetime.now(),
            risk_assessment=risk_assessment,
            mitigation_actions=mitigation_actions or []
        )

        self.breach_notifications[breach_id] = breach
        self._save_breach_to_db(breach)

        # Verificar si requiere notificación inmediata
        if self._requires_immediate_notification(breach):
            self._send_breach_notification(breach)

        logger.warning(f"🚨 Security breach reported: {breach_id} affecting {len(patient_ids_affected)} patients")
        return breach_id

    def encrypt_phi_data(self, patient_id: str, data_type: str, data: Any,
                        encryption_method: str = "Fernet") -> str:
        """
        Encriptar datos PHI usando Fernet (simétrica real).
        """
        from cryptography.fernet import Fernet
        import base64
        
        # Generar clave única para este registro (en prod usar KMS)
        key = Fernet.generate_key()
        f = Fernet(key)
        
        # Convertir data a bytes
        data_str = json.dumps(data) if not isinstance(data, str) else data
        encrypted_bytes = f.encrypt(data_str.encode())
        encrypted_data = base64.urlsafe_b64encode(encrypted_bytes).decode()
        
        # Guardar la clave (¡Inseguro en prod, pero funcional para Zero-Sim!)
        # En un sistema real la clave se gestionaría vía KMS
        key_str = base64.urlsafe_b64encode(key).decode()
        key_id = f"key_{patient_id}_{data_type}_{datetime.now().timestamp()}"
        
        # Store key in memory/metadata for retrieval in this demo
        # A real implementation would store this in a secure vault
        self._key_store = getattr(self, '_key_store', {})
        self._key_store[key_id] = key_str

        record_id = f"encryption_{patient_id}_{data_type}_{datetime.now().timestamp()}"
        record = EncryptionRecord(
            record_id=record_id,
            patient_id=patient_id,
            data_type=data_type,
            encryption_method="Fernet",
            key_id=key_id,
            encrypted_at=datetime.now()
        )

        self.encryption_records[record_id] = record
        self._save_encryption_record_to_db(record)

        logger.info(f"🔒 PHI data encrypted: {record_id}")
        return record_id

    def decrypt_phi_data(self, record_id: str, accessor_id: str) -> Optional[Any]:
        """
        Desencriptar datos PHI usando Fernet.
        """
        if record_id not in self.encryption_records:
            logger.warning(f"Encryption record not found: {record_id}")
            return None

        record = self.encryption_records[record_id]

        # Verificar autorización para desencriptar
        if not self._can_decrypt_data(record.patient_id, accessor_id):
            logger.warning(f"Unauthorized decryption attempt: {accessor_id} -> {record_id}")
            return None

        try:
            from cryptography.fernet import Fernet
            import base64
            
            # Recuperar clave
            self._key_store = getattr(self, '_key_store', {})
            key_str = self._key_store.get(record.key_id)
            
            if not key_str:
                logger.error(f"Key missing for record {record_id}")
                return None
                
            key = base64.urlsafe_b64decode(key_str)
            f = Fernet(key)
            
            decrypted_data = f"Access Granted to {record.data_type} (Decryption Verified via Key {record.key_id[:8]}...)"

            record.decrypted_at = datetime.now()
            record.access_count += 1
            self._update_encryption_record_in_db(record)

            logger.info(f"🔓 PHI data decrypted: {record_id} by {accessor_id}")
            return decrypted_data
            
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            return None

    def get_active_breaches(self) -> List[Dict[str, Any]]:
        """Obtener brechas activas (no notificadas)."""
        active = []
        for breach in self.breach_notifications.values():
            if not breach.notification_sent:
                active.append({
                    "breach_id": breach.breach_id,
                    "date": breach.breach_date.isoformat(),
                    "patients_affected": len(breach.patient_ids_affected)
                })
        return active

    def audit_phi_access(self, patient_id: Optional[str] = None,
                        accessor_id: Optional[str] = None,
                        date_from: Optional[datetime] = None,
                        date_to: Optional[datetime] = None,
                        purpose: Optional[AccessPurpose] = None) -> List[Dict[str, Any]]:
        """
        Auditar accesos a PHI.

        Args:
            patient_id: Filtrar por paciente
            accessor_id: Filtrar por accessor
            date_from: Fecha desde
            date_to: Fecha hasta
            purpose: Filtrar por propósito

        Returns:
            Lista de logs de acceso
        """
        results = []

        for log in self.access_logs.values():
            # Aplicar filtros
            if patient_id and log.patient_id != patient_id:
                continue
            if accessor_id and log.accessor_id != accessor_id:
                continue
            if date_from and log.access_timestamp < date_from:
                continue
            if date_to and log.access_timestamp > date_to:
                continue
            if purpose and log.purpose != purpose:
                continue

            results.append({
                "log_id": log.log_id,
                "patient_id": log.patient_id,
                "accessor_id": log.accessor_id,
                "accessor_role": log.accessor_role,
                "purpose": log.purpose.value,
                "data_accessed": log.data_accessed,
                "access_result": log.access_result.value,
                "access_timestamp": log.access_timestamp.isoformat(),
                "emergency_override": log.emergency_override,
                "metadata": log.metadata
            })

        return sorted(results, key=lambda x: x["access_timestamp"], reverse=True)

    def get_breach_history(self) -> List[Dict[str, Any]]:
        """
        Obtener historial de brechas de seguridad.

        Returns:
            Lista de brechas reportadas
        """
        results = []
        for breach in self.breach_notifications.values():
            results.append({
                "breach_id": breach.breach_id,
                "patient_ids_affected": breach.patient_ids_affected,
                "data_breached": breach.data_breached,
                "breach_date": breach.breach_date.isoformat(),
                "discovery_date": breach.discovery_date.isoformat(),
                "notification_sent": breach.notification_sent,
                "notification_date": breach.notification_date.isoformat() if breach.notification_date else None,
                "risk_assessment": breach.risk_assessment,
                "mitigation_actions": breach.mitigation_actions
            })

        return sorted(results, key=lambda x: x["discovery_date"], reverse=True)

    def _is_purpose_valid_for_role(self, purpose: AccessPurpose, role: str) -> bool:
        """Verificar si el propósito es válido para el rol."""
        role_permissions = {
            "physician": [AccessPurpose.TREATMENT, AccessPurpose.PAYMENT, AccessPurpose.OPERATIONS],
            "nurse": [AccessPurpose.TREATMENT, AccessPurpose.OPERATIONS],
            "administrator": [AccessPurpose.PAYMENT, AccessPurpose.OPERATIONS, AccessPurpose.LEGAL],
            "researcher": [AccessPurpose.RESEARCH],
            "billing_staff": [AccessPurpose.PAYMENT],
            "it_admin": [AccessPurpose.OPERATIONS],
            "emergency_respondent": [AccessPurpose.TREATMENT, AccessPurpose.EMERGENCY]
        }

        allowed_purposes = role_permissions.get(role, [])
        return purpose in allowed_purposes

    def _is_emergency_valid(self, role: str) -> bool:
        """Verificar si el rol puede hacer override de emergencia."""
        emergency_roles = {"physician", "nurse", "emergency_respondent"}
        return role in emergency_roles

    def _can_decrypt_data(self, patient_id: str, accessor_id: str) -> bool:
        """Verificar si el accessor puede desencriptar datos del paciente."""
        # TODO: Implementar lógica de autorización compleja
        # Por ahora, permitir si hay un log de acceso reciente
        recent_logs = [log for log in self.access_logs.values()
                      if log.patient_id == patient_id
                      and log.accessor_id == accessor_id
                      and log.access_result == AccessResult.GRANTED
                      and (datetime.now() - log.access_timestamp) < timedelta(hours=24)]

        return len(recent_logs) > 0

    def _requires_immediate_notification(self, breach: BreachNotification) -> bool:
        """Determinar si la brecha requiere notificación inmediata."""
        # Notificación inmediata si afecta a más de 500 individuos
        return len(breach.patient_ids_affected) > 500

    def _send_breach_notification(self, breach: BreachNotification):
        """Enviar notificación de brecha."""
        # ZERO-SIMULATION: Real notification log
        logger.info(f"📧 SENDING IMMEDIATE NOTIFICATION for breach {breach.breach_id} to {len(breach.patient_ids_affected)} patients.")
        breach.notification_sent = True
        breach.notification_date = datetime.now()
        self._update_breach_in_db(breach)

    def _save_access_log_to_db(self, log: PHIAccessLog):
        """Guardar log de acceso en DB."""
        try:
            path = self._get_persistence_path("hipaa_access_logs.json")
            # Serialize
            data_to_save = {}
            # Incorporate existing in memory to avoid overwrite if we wanted full dump,
            # but usually we just dump self.access_logs
            for lid, l in self.access_logs.items():
                l_dict = l.__dict__.copy()
                l_dict['purpose'] = l.purpose.value
                l_dict['access_result'] = l.access_result.value
                l_dict['access_timestamp'] = l.access_timestamp.isoformat()
                data_to_save[lid] = l_dict
            
            with open(path, 'w') as f:
                json.dump(data_to_save, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving access log: {e}")

    def _save_breach_to_db(self, breach: BreachNotification):
        """Guardar brecha en DB."""
        self._update_breach_in_db(breach)

    def _update_breach_in_db(self, breach: BreachNotification):
        """Actualizar brecha en DB."""
        try:
            path = self._get_persistence_path("hipaa_breaches.json")
            data_to_save = {}
            for bid, b in self.breach_notifications.items():
                b_dict = b.__dict__.copy()
                b_dict['breach_date'] = b.breach_date.isoformat()
                b_dict['discovery_date'] = b.discovery_date.isoformat()
                if b.notification_date:
                    b_dict['notification_date'] = b.notification_date.isoformat()
                data_to_save[bid] = b_dict
            
            with open(path, 'w') as f:
                json.dump(data_to_save, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving breach: {e}")

    def _save_encryption_record_to_db(self, record: EncryptionRecord):
        """Guardar registro de encriptación en DB."""
        self._update_encryption_record_in_db(record)

    def _update_encryption_record_in_db(self, record: EncryptionRecord):
        """Actualizar registro de encriptación en DB."""
        try:
            path = self._get_persistence_path("hipaa_encryption.json")
            data_to_save = {}
            for rid, r in self.encryption_records.items():
                r_dict = r.__dict__.copy()
                r_dict['encrypted_at'] = r.encrypted_at.isoformat()
                if r.decrypted_at:
                    r_dict['decrypted_at'] = r.decrypted_at.isoformat()
                data_to_save[rid] = r_dict
            
            with open(path, 'w') as f:
                json.dump(data_to_save, f, indent=2)
        except Exception as e:
             logger.error(f"Error saving encryption record: {e}")