"""
ComplianceAuditor - Auditor automático de compliance.

Implementa:
- Auditorías automáticas de cumplimiento
- Evaluación de riesgos de compliance
- Generación de reportes de auditoría
- Monitoreo continuo de compliance
- Alertas de no cumplimiento
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum
import os
from sqlalchemy.orm import Session
from pathlib import Path

from ..utils.logging import get_logger

logger = get_logger(__name__)


class AuditType(Enum):
    """Tipos de auditoría."""
    SCHEDULED = "scheduled"
    ON_DEMAND = "on_demand"
    INCIDENT_RESPONSE = "incident_response"
    REGULATORY = "regulatory"


class ComplianceRisk(Enum):
    """Niveles de riesgo de compliance."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AuditStatus(Enum):
    """Estados de auditoría."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class AuditFinding:
    """Hallazgo de auditoría."""
    finding_id: str
    regulation: str
    category: str
    severity: ComplianceRisk
    description: str
    evidence: List[str] = field(default_factory=list)
    recommendation: str = ""
    status: str = "open"  # "open", "in_progress", "resolved", "accepted"
    assigned_to: Optional[str] = None
    due_date: Optional[datetime] = None
    resolved_date: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ComplianceAudit:
    """Auditoría de compliance."""
    audit_id: str
    audit_type: AuditType
    regulations: List[str]  # ["GDPR", "HIPAA", "SOX"]
    scope: str
    start_date: datetime
    end_date: Optional[datetime] = None
    status: AuditStatus = AuditStatus.PENDING
    findings: List[AuditFinding] = field(default_factory=list)
    overall_risk: ComplianceRisk = ComplianceRisk.LOW
    summary: str = ""
    recommendations: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ComplianceMetric:
    """Métrica de compliance."""
    metric_id: str
    name: str
    regulation: str
    value: float
    target: float
    status: str  # "compliant", "warning", "breach"
    last_updated: datetime
    trend: str = "stable"  # "improving", "stable", "declining"
    metadata: Dict[str, Any] = field(default_factory=dict)


class ComplianceAuditor:
    """
    Auditor automático de compliance.

    Realiza auditorías programadas y bajo demanda,
    evalúa riesgos y genera reportes de cumplimiento.
    """

    def __init__(self, db_session: Optional[Session] = None):
        self.db_session = db_session
        self.audits: Dict[str, ComplianceAudit] = {}
        self.findings: Dict[str, AuditFinding] = {}
        self.metrics: Dict[str, ComplianceMetric] = {}
        self._initialized = False
        
        # File-based persistence configuration
        self.data_dir = Path("data/compliance")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.audits_file = self.data_dir / "audits.json"
        self.findings_file = self.data_dir / "findings.json"
        self.metrics_file = self.data_dir / "metrics.json"

    def _serialize_datetime(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        raise TypeError(f"Type {type(obj)} not serializable")

    def _deserialize_datetime(self, date_str):
        if date_str:
            return datetime.fromisoformat(date_str)
        return None

    def initialize(self):
        """Inicializar el auditor."""
        if not self._initialized:
            self._load_audits_from_db()
            self._load_findings_from_db()
            self._load_metrics_from_db()
            self._initialize_default_metrics()
            self._initialized = True
            logger.info("✅ ComplianceAuditor inicializado")

    def _initialize_default_metrics(self):
        """Inicializar métricas por defecto."""
        default_metrics = [
            {
                "metric_id": "gdpr_consent_rate",
                "name": "GDPR Consent Rate",
                "regulation": "GDPR",
                "value": 0.95,
                "target": 0.90,
                "status": "compliant"
            },
            {
                "metric_id": "hipaa_breach_reporting",
                "name": "HIPAA Breach Reporting Time",
                "regulation": "HIPAA",
                "value": 48.0,  # horas
                "target": 60.0,
                "status": "compliant"
            },
            {
                "metric_id": "sox_control_effectiveness",
                "name": "SOX Control Effectiveness",
                "regulation": "SOX",
                "value": 0.92,
                "target": 0.85,
                "status": "compliant"
            }
        ]

        for metric_data in default_metrics:
            metric_data["last_updated"] = datetime.now()
            if metric_data["metric_id"] not in self.metrics:
                metric = ComplianceMetric(**metric_data)
                self.metrics[metric.metric_id] = metric
                self._save_metric_to_db(metric)

    def _load_audit_data_from_file(self, file_path: Path) -> Dict:
        if not file_path.exists():
            return {}
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load data from {file_path}: {e}")
            return {}

    def _save_data_to_file(self, file_path: Path, data: Dict):
        try:
            with open(file_path, 'w') as f:
                json.dump(data, f, default=self._serialize_datetime, indent=2)
        except Exception as e:
            logger.error(f"Failed to save data to {file_path}: {e}")

    def _load_audits_from_db(self):
        """Cargar auditorías desde DB o archivo."""
        if self.db_session:
             # TODO: SQLAlchemy logic would go here
             pass
        else:
            data = self._load_audit_data_from_file(self.audits_file)
            for audit_id, audit_data in data.items():
                audit_data['start_date'] = self._deserialize_datetime(audit_data['start_date'])
                audit_data['end_date'] = self._deserialize_datetime(audit_data.get('end_date'))
                audit_data['audit_type'] = AuditType(audit_data['audit_type'])
                audit_data['status'] = AuditStatus(audit_data['status'])
                audit_data['overall_risk'] = ComplianceRisk(audit_data['overall_risk'])
                # Findings are re-linked separately
                audit_data['findings'] = [] 
                self.audits[audit_id] = ComplianceAudit(**audit_data)

    def _load_findings_from_db(self):
        """Cargar hallazgos desde DB o archivo."""
        if self.db_session:
             pass
        else:
            data = self._load_audit_data_from_file(self.findings_file)
            for finding_id, f_data in data.items():
                f_data['severity'] = ComplianceRisk(f_data['severity'])
                f_data['due_date'] = self._deserialize_datetime(f_data.get('due_date'))
                f_data['resolved_date'] = self._deserialize_datetime(f_data.get('resolved_date'))
                self.findings[finding_id] = AuditFinding(**f_data)

    def _load_metrics_from_db(self):
        """Cargar métricas desde DB o archivo."""
        if self.db_session:
             pass
        else:
            data = self._load_audit_data_from_file(self.metrics_file)
            for metric_id, m_data in data.items():
                m_data['last_updated'] = self._deserialize_datetime(m_data['last_updated'])
                self.metrics[metric_id] = ComplianceMetric(**m_data)

    def start_audit(self, audit_type: AuditType, regulations: List[str],
                   scope: str, scheduled_by: str) -> str:
        """
        Iniciar una auditoría de compliance.

        Args:
            audit_type: Tipo de auditoría
            regulations: Regulaciones a auditar
            scope: Alcance de la auditoría
            scheduled_by: Usuario que programa

        Returns:
            ID de la auditoría
        """
        audit_id = f"audit_{audit_type.value}_{datetime.now().timestamp()}"

        audit = ComplianceAudit(
            audit_id=audit_id,
            audit_type=audit_type,
            regulations=regulations,
            scope=scope,
            start_date=datetime.now(),
            status=AuditStatus.IN_PROGRESS
        )

        self.audits[audit_id] = audit
        self._save_audit_to_db(audit)

        # Ejecutar auditoría en background
        self._execute_audit(audit)

        logger.info(f"🔍 Audit started: {audit_id} ({audit_type.value})")
        return audit_id

    def _execute_audit(self, audit: ComplianceAudit):
        """Ejecutar la auditoría."""
        try:
            findings = []

            # Auditar cada regulación
            for regulation in audit.regulations:
                if regulation == "GDPR":
                    findings.extend(self._audit_gdpr())
                elif regulation == "HIPAA":
                    findings.extend(self._audit_hipaa())
                elif regulation == "SOX":
                    findings.extend(self._audit_sox())

            audit.findings = findings
            audit.overall_risk = self._calculate_overall_risk(findings)
            audit.summary = self._generate_audit_summary(findings)
            audit.recommendations = self._generate_recommendations(findings)
            audit.end_date = datetime.now()
            audit.status = AuditStatus.COMPLETED

            # Guardar hallazgos
            for finding in findings:
                self.findings[finding.finding_id] = finding
                self._save_finding_to_db(finding)

            self._update_audit_in_db(audit)

            # Generar alertas si hay hallazgos críticos
            self._generate_audit_alerts(audit)

            logger.info(f"✅ Audit completed: {audit.audit_id}")

        except Exception as e:
            logger.error(f"Error executing audit {audit.audit_id}: {e}")
            audit.status = AuditStatus.FAILED
            audit.summary = f"Audit failed: {str(e)}"
            self._update_audit_in_db(audit)

    def _audit_gdpr(self) -> List[AuditFinding]:
        """Auditar cumplimiento GDPR."""
        findings = []
        
        # Check consensus rate metric
        consent_metric = self.metrics.get("gdpr_consent_rate")
        if consent_metric and consent_metric.value < consent_metric.target:
             findings.append(AuditFinding(
                finding_id=f"gdpr_consent_{datetime.now().timestamp()}",
                regulation="GDPR",
                category="consent",
                severity=ComplianceRisk.MEDIUM,
                description=f"Consent rate {consent_metric.value:.2f} is below target {consent_metric.target:.2f}",
                evidence=[f"Metric ID: {consent_metric.metric_id}"],
                recommendation="Launch re-consent campaign"
            ))

        return findings

    def _audit_hipaa(self) -> List[AuditFinding]:
        """Auditar cumplimiento HIPAA."""
        findings = []
        
        # Check breach reporting metric
        breach_metric = self.metrics.get("hipaa_breach_reporting")
        if breach_metric and breach_metric.value > breach_metric.target:
             findings.append(AuditFinding(
                finding_id=f"hipaa_breach_{datetime.now().timestamp()}",
                regulation="HIPAA",
                category="reporting",
                severity=ComplianceRisk.HIGH,
                description=f"Breach reporting time {breach_metric.value}h exceeds limit {breach_metric.target}h",
                evidence=[f"Metric ID: {breach_metric.metric_id}"],
                recommendation="Improve incident response process"
            ))

        return findings

    def _audit_sox(self) -> List[AuditFinding]:
        """Auditar cumplimiento SOX."""
        findings = []
        
        # Check control effectiveness
        sox_metric = self.metrics.get("sox_control_effectiveness")
        if sox_metric and sox_metric.value < sox_metric.target:
             findings.append(AuditFinding(
                finding_id=f"sox_control_{datetime.now().timestamp()}",
                regulation="SOX",
                category="internal_controls",
                severity=ComplianceRisk.LOW,
                description=f"Control effectiveness {sox_metric.value:.2f} below target {sox_metric.target:.2f}",
                evidence=[f"Metric ID: {sox_metric.metric_id}"],
                recommendation="Review internal control procedures"
            ))

        return findings

    def update_finding_status(self, finding_id: str, status: str,
                            assigned_to: Optional[str] = None,
                            due_date: Optional[datetime] = None) -> bool:
        """
        Actualizar estado de un hallazgo.

        Args:
            finding_id: ID del hallazgo
            status: Nuevo estado
            assigned_to: Usuario asignado
            due_date: Fecha límite

        Returns:
            True si actualizado exitosamente
        """
        if finding_id not in self.findings:
            logger.error(f"Finding not found: {finding_id}")
            return False

        finding = self.findings[finding_id]
        finding.status = status
        finding.assigned_to = assigned_to
        finding.due_date = due_date

        if status in ["resolved", "accepted"]:
            finding.resolved_date = datetime.now()

        self._update_finding_in_db(finding)

        logger.info(f"📝 Finding updated: {finding_id} -> {status}")
        return True

    def update_metric(self, metric_id: str, value: float,
                     trend: Optional[str] = None) -> bool:
        """
        Actualizar valor de métrica.

        Args:
            metric_id: ID de la métrica
            value: Nuevo valor
            trend: Tendencia

        Returns:
            True si actualizado exitosamente
        """
        if metric_id not in self.metrics:
            logger.error(f"Metric not found: {metric_id}")
            return False

        metric = self.metrics[metric_id]
        old_value = metric.value
        metric.value = value
        metric.last_updated = datetime.now()

        if trend:
            metric.trend = trend
        else:
            # Calcular tendencia automáticamente
            if value > old_value:
                metric.trend = "improving" if metric.metric_id.endswith("_rate") else "declining"
            elif value < old_value:
                metric.trend = "declining" if metric.metric_id.endswith("_rate") else "improving"
            else:
                metric.trend = "stable"

        # Actualizar estado
        if value >= metric.target:
            metric.status = "compliant"
        elif value >= metric.target * 0.8:
            metric.status = "warning"
        else:
            metric.status = "breach"

        self._update_metric_in_db(metric)

        logger.info(f"📊 Metric updated: {metric_id} = {value}")
        return True

    def get_audit_report(self, audit_id: str) -> Optional[Dict[str, Any]]:
        """
        Obtener reporte de auditoría.

        Args:
            audit_id: ID de la auditoría

        Returns:
            Reporte de auditoría o None
        """
        if audit_id not in self.audits:
            return None

        audit = self.audits[audit_id]

        return {
            "audit_id": audit.audit_id,
            "audit_type": audit.audit_type.value,
            "regulations": audit.regulations,
            "scope": audit.scope,
            "start_date": audit.start_date.isoformat(),
            "end_date": audit.end_date.isoformat() if audit.end_date else None,
            "status": audit.status.value,
            "overall_risk": audit.overall_risk.value,
            "summary": audit.summary,
            "findings_count": len(audit.findings),
            "findings": [
                {
                    "finding_id": f.finding_id,
                    "regulation": f.regulation,
                    "category": f.category,
                    "severity": f.severity.value,
                    "description": f.description,
                    "status": f.status,
                    "recommendation": f.recommendation
                }
                for f in audit.findings
            ],
            "recommendations": audit.recommendations
        }

    def get_compliance_dashboard(self) -> Dict[str, Any]:
        """
        Obtener dashboard de compliance.

        Returns:
            Datos del dashboard
        """
        # Métricas por regulación
        metrics_by_regulation = {}
        for metric in self.metrics.values():
            reg = metric.regulation
            if reg not in metrics_by_regulation:
                metrics_by_regulation[reg] = []
            metrics_by_regulation[reg].append({
                "metric_id": metric.metric_id,
                "name": metric.name,
                "value": metric.value,
                "target": metric.target,
                "status": metric.status,
                "trend": metric.trend
            })

        # Hallazgos abiertos por severidad
        open_findings = [f for f in self.findings.values() if f.status == "open"]
        findings_by_severity = {}
        for finding in open_findings:
            sev = finding.severity.value
            findings_by_severity[sev] = findings_by_severity.get(sev, 0) + 1

        # Auditorías recientes
        recent_audits = []
        for audit in sorted(self.audits.values(),
                          key=lambda x: x.start_date, reverse=True)[:5]:
            recent_audits.append({
                "audit_id": audit.audit_id,
                "type": audit.audit_type.value,
                "status": audit.status.value,
                "risk": audit.overall_risk.value,
                "start_date": audit.start_date.isoformat()
            })

        return {
            "metrics_by_regulation": metrics_by_regulation,
            "open_findings_by_severity": findings_by_severity,
            "recent_audits": recent_audits,
            "overall_compliance_score": self._calculate_overall_compliance_score(),
            "generated_at": datetime.now().isoformat()
        }

    def schedule_audit(self, audit_type: AuditType, regulations: List[str],
                      scope: str, scheduled_date: datetime, scheduled_by: str) -> str:
        """
        Programar auditoría futura.

        Args:
            audit_type: Tipo de auditoría
            regulations: Regulaciones
            scope: Alcance
            scheduled_date: Fecha programada
            scheduled_by: Usuario que programa

        Returns:
            ID de la auditoría programada
        """
        audit_id = f"scheduled_audit_{datetime.now().timestamp()}"

        audit = ComplianceAudit(
            audit_id=audit_id,
            audit_type=audit_type,
            regulations=regulations,
            scope=scope,
            start_date=scheduled_date,
            status=AuditStatus.PENDING
        )

        self.audits[audit_id] = audit
        self._save_audit_to_db(audit)

        logger.info(f"📅 Audit scheduled: {audit_id} for {scheduled_date.isoformat()}")
        return audit_id

    def _calculate_overall_risk(self, findings: List[AuditFinding]) -> ComplianceRisk:
        """Calcular riesgo general de la auditoría."""
        if not findings:
            return ComplianceRisk.LOW

        severity_counts = {
            ComplianceRisk.CRITICAL: 0,
            ComplianceRisk.HIGH: 0,
            ComplianceRisk.MEDIUM: 0,
            ComplianceRisk.LOW: 0
        }

        for finding in findings:
            severity_counts[finding.severity] += 1

        if severity_counts[ComplianceRisk.CRITICAL] > 0:
            return ComplianceRisk.CRITICAL
        elif severity_counts[ComplianceRisk.HIGH] > 2:
            return ComplianceRisk.HIGH
        elif severity_counts[ComplianceRisk.HIGH] > 0 or severity_counts[ComplianceRisk.MEDIUM] > 3:
            return ComplianceRisk.MEDIUM
        else:
            return ComplianceRisk.LOW

    def _generate_audit_summary(self, findings: List[AuditFinding]) -> str:
        """Generar resumen de auditoría."""
        total_findings = len(findings)
        critical = sum(1 for f in findings if f.severity == ComplianceRisk.CRITICAL)
        high = sum(1 for f in findings if f.severity == ComplianceRisk.HIGH)

        return f"Audit completed with {total_findings} findings ({critical} critical, {high} high severity)"

    def _generate_recommendations(self, findings: List[AuditFinding]) -> List[str]:
        """Generar recomendaciones basadas en hallazgos."""
        recommendations = []

        # Agrupar por categoría
        categories = {}
        for finding in findings:
            cat = finding.category
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(finding)

        for category, cat_findings in categories.items():
            high_severity = [f for f in cat_findings if f.severity in [ComplianceRisk.HIGH, ComplianceRisk.CRITICAL]]
            if high_severity:
                recommendations.append(f"Address {len(high_severity)} high-priority {category} issues immediately")

        if not recommendations:
            recommendations.append("No critical issues found. Continue monitoring compliance metrics.")

        return recommendations

    def _calculate_overall_compliance_score(self) -> float:
        """Calcular puntuación general de compliance."""
        if not self.metrics:
            return 0.0

        scores = []
        for metric in self.metrics.values():
            if metric.status == "compliant":
                scores.append(1.0)
            elif metric.status == "warning":
                scores.append(0.7)
            else:  # breach
                scores.append(0.3)

        return sum(scores) / len(scores) if scores else 0.0

    def _generate_audit_alerts(self, audit: ComplianceAudit):
        """Generar alertas basadas en resultados de auditoría."""
        critical_findings = [f for f in audit.findings if f.severity == ComplianceRisk.CRITICAL]

        if critical_findings:
            logger.warning(f"🚨 CRITICAL AUDIT FINDINGS: {len(critical_findings)} in audit {audit.audit_id}")
            # TODO: Enviar alertas a equipo de compliance

    def _save_audit_to_db(self, audit: ComplianceAudit):
        """Guardar auditoría en DB o archivo."""
        if self.db_session:
            pass
        else:
            # Prepare dict for serialization
            audit_dict = asdict(audit)
            audit_dict['audit_type'] = audit.audit_type.value
            audit_dict['status'] = audit.status.value
            audit_dict['overall_risk'] = audit.overall_risk.value
            # Don't save full finding objects inside audit dict to avoid duplication/cycles, just IDs if needed
            # But for simple JSON file, embedding them or just saving flat list in audits is fine for now
            # Here we follow the structure: audits in one file, findings in another
            audit_dict['findings'] = [f.finding_id for f in audit.findings]
            
            # Update cache
            self.audits[audit.audit_id] = audit
            
            # Save all audits to file
            all_audits_dict = {
                aid: {
                    **asdict(a), 
                    'audit_type': a.audit_type.value,
                    'status': a.status.value,
                    'overall_risk': a.overall_risk.value,
                    'findings': [f.finding_id for f in a.findings]
                } 
                for aid, a in self.audits.items()
            }
            self._save_data_to_file(self.audits_file, all_audits_dict)

    def _update_audit_in_db(self, audit: ComplianceAudit):
        """Actualizar auditoría en DB."""
        self._save_audit_to_db(audit)

    def _save_finding_to_db(self, finding: AuditFinding):
        """Guardar hallazgo en DB o archivo."""
        if self.db_session:
            pass
        else:
            self.findings[finding.finding_id] = finding
            
            all_findings_dict = {
                fid: {
                   **asdict(f),
                   'severity': f.severity.value
                }
                for fid, f in self.findings.items()
            }
            self._save_data_to_file(self.findings_file, all_findings_dict)

    def _update_finding_in_db(self, finding: AuditFinding):
        """Actualizar hallazgo en DB."""
        self._save_finding_to_db(finding)

    def _save_metric_to_db(self, metric: ComplianceMetric):
        """Guardar métrica en DB o archivo."""
        if self.db_session:
            pass
        else:
            self.metrics[metric.metric_id] = metric
            all_metrics_dict = {
                mid: asdict(m) for mid, m in self.metrics.items()
            }
            self._save_data_to_file(self.metrics_file, all_metrics_dict)

    def _update_metric_in_db(self, metric: ComplianceMetric):
        """Actualizar métrica en DB."""
        self._save_metric_to_db(metric)