import asyncio
import aiohttp
import time
import json
import logging
import random
import statistics
import uuid
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
import psutil
import os
from pathlib import Path

try:
    import torch
except ImportError:
    torch = None

from .async_aggregator import AsyncAggregator, WeightUpdate
from ..sdk.node_sdk import NodeSDK, NodeConfig
from ..core.config import get_config

logger = logging.getLogger(__name__)


@dataclass
class LoadTestConfig:
    """Configuración sofisticada del sistema de load testing federado real."""

    # Configuración de usuarios concurrentes (Inferencia)
    num_concurrent_users: int = 50
    user_ramp_up_time: float = 10.0
    test_duration_seconds: int = 60

    # Configuración de consultas de inferencia (RAG API)
    rag_api_url: Optional[str] = None  # Si es None, se toma de config global
    rag_types: List[str] = field(default_factory=lambda: ["naive", "hyde", "modular", "fusion"])
    queries_per_second_per_user: float = 0.5
    query_templates: List[str] = field(default_factory=lambda: [
        "¿Cuál es la capital de {país}?",
        "Explica el concepto de {concepto} en machine learning",
        "Escribe un resumen sobre {tema}",
        "¿Cómo funciona {tecnología}?",
        "Traduce '{frase}' al inglés"
    ])

    # Configuración de federated learning real (Usa NodeSDK)
    num_federated_nodes: int = 5
    coordinator_url: Optional[str] = None  # Si es None, se toma de config global
    model_name: str = "empoorio_lm_prod"
    training_interval_range: Tuple[float, float] = (5.0, 15.0)

    # Configuración de métricas
    metrics_collection_interval: float = 1.0


@dataclass
class LoadTestMetrics:
    """Métricas avanzadas recopiladas durante las pruebas de carga."""
    total_inference_requests: int = 0
    successful_inference_requests: int = 0
    failed_inference_requests: int = 0
    inference_latencies: List[float] = field(default_factory=list)
    
    total_p2p_updates_sent: int = 0
    successful_p2p_updates: int = 0
    
    memory_usage_mb: List[float] = field(default_factory=list)
    cpu_usage_percent: List[float] = field(default_factory=list)
    
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None

    def _calculate_percentile(self, data: List[float], percentile: float) -> float:
        if not data:
            return 0.0
        sorted_data = sorted(data)
        index = (percentile / 100) * (len(sorted_data) - 1)
        lower = sorted_data[int(index)]
        upper = sorted_data[min(int(index) + 1, len(sorted_data) - 1)]
        return lower + (upper - lower) * (index % 1)

    def get_summary(self) -> Dict[str, Any]:
        duration = (self.end_time or time.time()) - self.start_time
        latencies_ms = [l * 1000 for l in self.inference_latencies]
        
        return {
            'duration_s': duration,
            'inference': {
                'total': self.total_inference_requests,
                'success_rate': self.successful_inference_requests / max(self.total_inference_requests, 1),
                'avg_latency_ms': statistics.mean(latencies_ms) if latencies_ms else 0,
                'p50_latency_ms': self._calculate_percentile(latencies_ms, 50),
                'p95_latency_ms': self._calculate_percentile(latencies_ms, 95),
                'p99_latency_ms': self._calculate_percentile(latencies_ms, 99),
                'p999_latency_ms': self._calculate_percentile(latencies_ms, 99.9),
                'rps': self.successful_inference_requests / max(duration, 1)
            },
            'federated': {
                'updates_sent': self.total_p2p_updates_sent,
                'success_rate': self.successful_p2p_updates / max(self.total_p2p_updates_sent, 1)
            },
            'resources': {
                'avg_memory_mb': statistics.mean(self.memory_usage_mb) if self.memory_usage_mb else 0,
                'max_memory_mb': max(self.memory_usage_mb) if self.memory_usage_mb else 0,
                'avg_cpu_percent': statistics.mean(self.cpu_usage_percent) if self.cpu_usage_percent else 0,
                'max_cpu_percent': max(self.cpu_usage_percent) if self.cpu_usage_percent else 0
            }
        }


class InferenceLoadSimulator:
    """Simulador de carga real para la RAG API con soporte multitécnica."""

    def __init__(self, config: LoadTestConfig, metrics: LoadTestMetrics):
        self.config = config
        self.metrics = metrics
        self.session: Optional[aiohttp.ClientSession] = None
        self.is_running = False
        self._config_global = get_config()
        self.api_url = config.rag_api_url or self._config_global.get("rag_api_url", "http://localhost:8000")
        
        self.query_data = {
            'país': ['Francia', 'España', 'México', 'Argentina', 'Japón', 'Brasil'],
            'concepto': ['RAG', 'LLM', 'Embeddings', 'Vector DB', 'Prompt Engineering'],
            'tema': ['Ailoos', 'Deepmind', 'Inteligencia Artificial', 'Web3', 'Blockchain'],
            'tecnología': ['Python', 'FastAPI', 'PyTorch', 'Rust', 'Substrate'],
            'frase': ['Hola mundo', 'IA es el futuro', 'Code is law']
        }

    async def start(self):
        self.is_running = True
        self.session = aiohttp.ClientSession()
        logger.info(f"🚀 Starting Multi-Technique RAG Load Test on {self.api_url}")

        tasks = [asyncio.create_task(self._simulate_user(i)) for i in range(self.config.num_concurrent_users)]
        await asyncio.gather(*tasks)

    async def stop(self):
        self.is_running = False
        if self.session:
            await self.session.close()

    async def _simulate_user(self, user_id: int):
        await asyncio.sleep(random.uniform(0, self.config.user_ramp_up_time))
        
        start_time = time.time()
        while self.is_running and (time.time() - start_time) < self.config.test_duration_seconds:
            query = self._generate_query()
            rag_type = random.choice(self.config.rag_types)
            await self._send_request(query, rag_type)
            await asyncio.sleep(1.0 / self.config.queries_per_second_per_user)

    def _generate_query(self) -> str:
        template = random.choice(self.config.query_templates)
        query = template
        for k, v in self.query_data.items():
            if f"{{{k}}}" in query:
                query = query.replace(f"{{{k}}}", random.choice(v))
        return query

    async def _send_request(self, query: str, rag_type: str):
        self.metrics.total_inference_requests += 1
        payload = {
            "query": query,
            "rag_type": rag_type,
            "user_context": {"user_id": f"test_user_{random.randint(1,1000)}", "roles": ["tester"]}
        }
        
        try:
            start = time.time()
            async with self.session.post(f"{self.api_url}/query", json=payload, timeout=15) as resp:
                latency = time.time() - start
                if resp.status == 200:
                    self.metrics.successful_inference_requests += 1
                    self.metrics.inference_latencies.append(latency)
                else:
                    logger.debug(f"Request failed ({rag_type}): {resp.status}")
                    self.metrics.failed_inference_requests += 1
        except Exception as e:
            logger.debug(f"Request exception ({rag_type}): {e}")
            self.metrics.failed_inference_requests += 1


class FederatedTrainingSimulator:
    """Simulador real de nodos usando el NodeSDK de Ailoos."""

    def __init__(self, config: LoadTestConfig, metrics: LoadTestMetrics):
        self.config = config
        self.metrics = metrics
        self.nodes: List[NodeSDK] = []
        self.is_running = False
        self._config_global = get_config()
        self.coordinator_url = config.coordinator_url or self._config_global.get("coordinator_url", "http://localhost:5001")

    async def start(self):
        self.is_running = True
        logger.info(f"🚀 Initializing {self.config.num_federated_nodes} NodeSDK nodes for stress testing")
        
        for i in range(self.config.num_federated_nodes):
            node_id = f"stress_test_node_{uuid.uuid4().hex[:8]}"
            sdk = NodeSDK(node_id=node_id, coordinator_url=self.coordinator_url)
            # No necesitamos todos los componentes para un test de carga federado
            sdk.config.enable_marketplace = False
            sdk.config.enable_monitoring = True
            
            # Inicialización parcial para mayor velocidad en test
            await sdk.initialize()
            await sdk.start()
            self.nodes.append(sdk)

        tasks = [asyncio.create_task(self._node_lifecycle(node)) for node in self.nodes]
        await asyncio.gather(*tasks)

    async def stop(self):
        self.is_running = False
        for node in self.nodes:
            await node.shutdown()
        self.nodes.clear()

    async def _node_lifecycle(self, node: NodeSDK):
        # Unirse a una sesión de prueba si existe
        session_id = f"stress_session_{self.config.model_name}"
        await node.join_federated_session(session_id)
        
        while self.is_running:
            await asyncio.sleep(random.uniform(*self.config.training_interval_range))
            
            weights = self._generate_weights()
            self.metrics.total_p2p_updates_sent += 1
            
            try:
                success = await node.participate_in_round(
                    session_id=session_id,
                    model_weights=weights,
                    metadata={"samples": random.randint(10, 100), "loss": random.random()}
                )
                if success:
                    self.metrics.successful_p2p_updates += 1
                else:
                    logger.debug(f"Node {node.config.node_id} update rejected")
            except Exception as e:
                logger.error(f"Node {node.config.node_id} participation error: {e}")

    def _generate_weights(self) -> Dict[str, Any]:
        if torch:
            return {f"layer_{i}": torch.randn(20, 20).tolist() for i in range(5)}
        return {f"layer_{i}": [[random.random() for _ in range(10)] for _ in range(10)] for i in range(5)}


class FederatedLoadTester:
    """Orquestador profesional de pruebas de carga reales e integradas."""

    def __init__(self, config: LoadTestConfig):
        self.config = config
        self.metrics = LoadTestMetrics()
        self.inference_sim = InferenceLoadSimulator(config, self.metrics)
        self.fed_sim = FederatedTrainingSimulator(config, self.metrics)
        self.process = psutil.Process()

    async def run(self):
        logger.info("🏁 Starting Integrated Federated Load Test (SDK & Pro Metrics)")
        self.metrics.start_time = time.time()
        
        monitor_task = asyncio.create_task(self._monitor_resources())
        
        try:
            # Ejecutar ambos simuladores concurrentemente
            await asyncio.gather(
                self.inference_sim.start(),
                self.fed_sim.start()
            )
        except Exception as e:
            logger.error(f"Load Test interrupted: {e}")
        finally:
            self.metrics.end_time = time.time()
            monitor_task.cancel()
            await self.inference_sim.stop()
            await self.fed_sim.stop()
            
        self.print_summary()

    async def _monitor_resources(self):
        while True:
            self.metrics.memory_usage_mb.append(self.process.memory_info().rss / 1e6)
            self.metrics.cpu_usage_percent.append(self.process.cpu_percent())
            await asyncio.sleep(self.config.metrics_collection_interval)

    def print_summary(self):
        summary = self.metrics.get_summary()
        inf = summary['inference']
        fed = summary['federated']
        res = summary['resources']
        
        print("\n" + "╔" + "═"*60 + "╗")
        print("║" + " 📊 LOAD TEST SUMMARY (SDK INTEGRATED) ".center(60) + "║")
        print("╠" + "═"*60 + "╣")
        print(f"║ Duration: {summary['duration_s']:.2f}s".ljust(61) + "║")
        print(f"║ Nodes: {self.config.num_federated_nodes} | Users: {self.config.num_concurrent_users}".ljust(61) + "║")
        print("╠" + "═"*30 + "╦" + "═"*29 + "╣")
        print(f"║ INFERENCE (RAG API)".ljust(31) + "║" + " FEDERATED (SDK)".ljust(30) + "║")
        print(f"║ Total: {inf['total']}".ljust(31) + "║" + f" Updates Sent: {fed['updates_sent']}".ljust(30) + "║")
        print(f"║ Success: {inf['success_rate']:.1%}".ljust(31) + "║" + f" Success: {fed['success_rate']:.1%}".ljust(30) + "║")
        print(f"║ RPS: {inf['rps']:.2f}".ljust(31) + "║" + " ".ljust(30) + "║")
        print("╠" + "═"*30 + "╩" + "═"*29 + "╣")
        print("║ LATENCY PERCENTILES (Inference)".center(60) + "║")
        print(f"║ p50: {inf['p50_latency_ms']:.2f}ms | p95: {inf['p95_latency_ms']:.2f}ms".center(60) + "║")
        print(f"║ p99: {inf['p99_latency_ms']:.2f}ms | p99.9: {inf['p999_latency_ms']:.2f}ms".center(60) + "║")
        print("╠" + "═"*60 + "╣")
        print("║ RESOURCE USAGE".center(60) + "║")
        print(f"║ CPU: Avg {res['avg_cpu_percent']:.1f}% / Max {res['max_cpu_percent']:.1f}%".center(60) + "║")
        print(f"║ RAM: Avg {res['avg_memory_mb']:.1f}MB / Max {res['max_memory_mb']:.1f}MB".center(60) + "║")
        print("╚" + "═"*60 + "╝\n")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # Prueba rápida
    config = LoadTestConfig(num_concurrent_users=5, num_federated_nodes=2, test_duration_seconds=20)
    tester = FederatedLoadTester(config)
    asyncio.run(tester.run())