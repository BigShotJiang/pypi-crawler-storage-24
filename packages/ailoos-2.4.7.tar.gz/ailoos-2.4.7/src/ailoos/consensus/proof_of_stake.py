"""
Proof of Stake (PoS) Protocol.
Weighted Sortition for Validator Selection and Slashing Logic.
"""

import random
import logging
import time
from typing import List, Dict, Optional, Any

logger = logging.getLogger(__name__)

class ProofOfStake:
    """
    Real Proof of Stake validator selection logic.
    Uses 'Skin in the Game' probability.
    """
    
    MIN_STAKE_REQUIRED = 100.0
    
    @staticmethod
    def select_validator(seed: int, 
                         validators: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        Select a validator deterministically based on stake weight.
        
        Args:
            seed: Random seed (e.g., BlockHash).
            validators: List of dicts with 'id' and 'stake'.
            
        Returns:
            The selected validator dict.
        """
        if not validators:
            return None
            
        # 1. Filter eligible validators
        eligible = [v for v in validators if v.get('stake', 0) >= ProofOfStake.MIN_STAKE_REQUIRED]
        
        if not eligible:
            logger.warning(f"⚠️ No validators met minimum stake of {ProofOfStake.MIN_STAKE_REQUIRED}")
            return None
            
        # 2. Extract weights
        stakes = [v.get('stake', 0) for v in eligible]
        
        # 3. Deterministic Selection
        # Use python's random with seed for "Weighted Sortition"
        rng = random.Random(seed)
        
        # random.choices is weighted selection with replacement (k=1)
        selected = rng.choices(eligible, weights=stakes, k=1)[0]
        
        logger.info(f"⚖️ PoS Lottery [Seed {seed}]: Selected {selected['id']} (Stake: {selected['stake']})")
        return selected

    @staticmethod
    def slash_validator(validator_id: str, 
                        infraction_level: int, 
                        current_stake: float) -> float:
        """
        Calculate new stake after slashing penalty.
        
        Args:
            infraction_level: 1 (Minor) to 10 (Major Fraud).
        Returns:
            New stake amount.
        """
        penalty_ratio = 0.0
        
        if infraction_level <= 3:
            penalty_ratio = 0.01  # 1% warning
        elif infraction_level <= 7:
            penalty_ratio = 0.10  # 10% negligence
        else:
            penalty_ratio = 0.50  # 50% fraud (PoC failure)
            
        penalty = current_stake * penalty_ratio
        new_stake = max(0, current_stake - penalty)
        
        logger.warning(f"🔪 SLASHING: {validator_id} penalized {penalty} (Level {infraction_level}). New Stake: {new_stake}")
        return new_stake
