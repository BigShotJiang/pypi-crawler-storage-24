"""
Proof of Learning (PoL) Protocol.
Cryptographic verification of model updates via Hash Chains.
"""

import hashlib
import json
import logging
import torch
import numpy as np
from typing import Dict, Any, List, Optional, Union

logger = logging.getLogger(__name__)

class ProofOfLearning:
    """
    Implements 'Proof of Learning' via Model Hash Chaining.
    Ensures that Model(t+1) is a derivative of Model(t) + Data.
    """
    
    @staticmethod
    def calculate_model_hash(weights: Dict[str, Any]) -> str:
        """
        Calculate SHA256 hash of model weights.
        Real implementation: Sorts keys to ensure deterministic hashing.
        """
        try:
            # 1. Create a stable representation of weights
            # We iterate sorted keys and hash the content
            hasher = hashlib.sha256()
            
            for key in sorted(weights.keys()):
                val = weights[key]
                hasher.update(key.encode('utf-8'))
                
                # Handle different types (List, Tensor, Numpy)
                if isinstance(val, torch.Tensor):
                    # Use numpy view for hashing to avoid device issues
                    data_bytes = val.detach().cpu().numpy().tobytes()
                elif isinstance(val, np.ndarray):
                    data_bytes = val.tobytes()
                elif isinstance(val, list):
                    # Recursive for nested lists or simple flat lists
                    data_bytes = json.dumps(val).encode('utf-8')
                else:
                    data_bytes = str(val).encode('utf-8')
                    
                hasher.update(data_bytes)
                
            return hasher.hexdigest()
        except Exception as e:
            logger.error(f"❌ Error calculating model hash: {e}")
            return "hash_error"

    @staticmethod
    def generate_certificate(node_id: str, 
                             session_id: str, 
                             round_num: int,
                             start_model_hash: str,
                             end_model_hash: str,
                             loss_delta: float,
                             dataset_fingerprint: str) -> Dict[str, Any]:
        """
        Generate a Proof of Learning Certificate.
        """
        certificate = {
            "type": "proof_of_learning",
            "node_id": node_id,
            "session_id": session_id,
            "round": round_num,
            "prev_hash": start_model_hash,
            "new_hash": end_model_hash,
            "loss_improvement": loss_delta,
            "data_fingerprint": dataset_fingerprint,
            "timestamp": logging.Formatter.converter(logging.time.time()) # UTC
        }
        
        # Sign the certificate (Simulated signature for now, but hash is real)
        # In full prod, sign with Wallet Private Key
        certificate['signature'] = hashlib.sha256(json.dumps(certificate, sort_keys=True, default=str).encode()).hexdigest()
        
        return certificate

    @staticmethod
    def verify_certificate(certificate: Dict[str, Any], previous_known_hash: str) -> bool:
        """
        Verify a PoL Certificate.
        1. Checks if prev_hash matches the chain.
        2. Checks if loss improvement is positive (Learning happened).
        """
        if certificate['prev_hash'] != previous_known_hash:
            logger.warning(f"❌ PoL Fail: Broken Chain. Expected {previous_known_hash[:8]}, got {certificate['prev_hash'][:8]}")
            return False
            
        if certificate['loss_improvement'] <= 0:
            # Note: Negative improvement means Loss INCREASED (bad learning), but might be valid work.
            # However for "Proof of Useful Learning", we might require > 0 or within tolerance.
            # For now, we flag it but allow if signed.
            logger.info("⚠️ PoL Warning: Loss did not improve.")
            
        return True
