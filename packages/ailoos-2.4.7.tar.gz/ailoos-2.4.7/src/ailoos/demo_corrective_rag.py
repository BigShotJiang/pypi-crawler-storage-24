#!/usr/bin/env python3
"""
Demo script for Corrective RAG

This script demonstrates the Corrective RAG technique, which implements
iterative self-correction loops with confidence-based adjustments to improve
retrieval and generation quality.

Usage:
    python demo_corrective_rag.py

Features demonstrated:
- Iterative correction loops
- Confidence-based retrieval adjustments
- Self-evaluation and refinement
- Comprehensive correction metrics
- Error handling and fallback mechanisms
"""

import sys
import time
from typing import Dict, Any

# Add the src directory to the path
sys.path.insert(0, 'src')

# Import modules (assuming these exist and work)
from ailoos.rag.techniques.corrective_rag import CorrectiveRAG
from ailoos.rag.demo_utils import load_documents_from_env, require_env
from ailoos.utils.logging import get_logger

logger = get_logger(__name__)


def setup_corrective_rag():
    """Set up CorrectiveRAG with sample configuration."""
    model_path = require_env("AILOOS_RAG_MODEL_PATH")
    config = {
        'retriever_config': {
            'chunk_size': 500,
            'chunk_overlap': 50
        },
        'generator_config': {
            'empoorio_api_config': {
                'model_path': model_path
            },
            'generation_config': {
                'max_new_tokens': 512,
                'temperature': 0.7,
                'top_p': 0.9
            }
        },
        'evaluator_config': {},
        'correction_config': {
            'max_iterations': 3,
            'confidence_threshold': 0.7,
            'relevance_threshold': 0.5,
            'factuality_threshold': 0.6,
            'adaptive_retrieval': True,
            'correction_enabled': True
        }
    }

    # Create RAG instance
    rag = CorrectiveRAG(config)

    documents = load_documents_from_env()
    rag.retriever.add_documents(documents)

    logger.info(f"✅ CorrectiveRAG initialized with {len(documents)} documents")
    return rag


def demonstrate_basic_query(rag: CorrectiveRAG):
    """Demonstrate a basic query that may need correction."""
    print("\n" + "="*60)
    print("🔍 DEMO 1: Basic Query with Potential Corrections")
    print("="*60)

    query = "What are the main branches of artificial intelligence?"

    print(f"Query: {query}")
    print("\nProcessing with Corrective RAG...")

    start_time = time.time()
    result = rag.run(query)
    processing_time = time.time() - start_time

    print("\n📄 Response:")
    print(result['response'])

    print("\n📊 Metrics:")
    for key, value in result['metrics'].items():
        print(f"  - {key}: {value:.3f}")

    print("\n🔧 Correction Metadata:")
    metadata = result['metadata']
    print(f"  - Total Iterations: {metadata['total_iterations']}")
    print(f"  - Final Confidence: {metadata['final_confidence']:.3f}")
    print(f"  - Processing Time: {processing_time:.2f}s")

    correction_metrics = metadata['correction_metrics']
    print(f"  - Corrections Applied: {correction_metrics['corrections_applied']}")
    print(f"  - Retrieval Adjustments: {correction_metrics['retrieval_adjustments']}")

    if metadata['correction_history']:
        print(f"  - Correction Iterations: {len(metadata['correction_history'])}")
        for i, correction in enumerate(metadata['correction_history']):
            print(f"    Iteration {correction['iteration']}: {correction['corrections_applied']}")


def demonstrate_complex_query(rag: CorrectiveRAG):
    """Demonstrate a complex query requiring multiple corrections."""
    print("\n" + "="*60)
    print("🔍 DEMO 2: Complex Query with Multiple Corrections")
    print("="*60)

    query = "Explain how machine learning and computer vision work together in autonomous vehicles, including specific techniques and challenges."

    print(f"Query: {query}")
    print("\nProcessing with Corrective RAG (this may take longer due to corrections)...")

    start_time = time.time()
    result = rag.run(query)
    processing_time = time.time() - start_time

    print("\n📄 Response:")
    print(result['response'][:500] + "..." if len(result['response']) > 500 else result['response'])

    print("\n📊 Metrics:")
    for key, value in result['metrics'].items():
        print(f"  - {key}: {value:.3f}")

    print("\n🔧 Correction Details:")
    metadata = result['metadata']
    print(f"  - Iterations Performed: {metadata['total_iterations']}")
    print(f"  - Final Confidence: {metadata['final_confidence']:.3f}")
    print(f"  - Total Processing Time: {processing_time:.2f}s")

    if metadata['correction_history']:
        print("  - Correction History:")
        for correction in metadata['correction_history']:
            print(f"    • Iteration {correction['iteration']}: "
                  f"Confidence {correction['old_confidence']:.2f} → {correction['new_confidence']:.2f}, "
                  f"Changes: {correction['corrections_applied']}")


def demonstrate_correction_metrics(rag: CorrectiveRAG):
    """Demonstrate comprehensive correction metrics."""
    print("\n" + "="*60)
    print("📈 DEMO 3: Correction Metrics Overview")
    print("="*60)

    # Run multiple queries to build metrics
    queries = [
        "What is AI?",
        "Explain machine learning algorithms.",
        "How does computer vision work?",
        "What are NLP applications?"
    ]

    print("Running multiple queries to demonstrate metrics accumulation...")

    for i, query in enumerate(queries, 1):
        print(f"  {i}. Processing: {query[:50]}...")
        result = rag.run(query)
        print(f"     → {result['metadata']['total_iterations']} iterations, "
              f"confidence: {result['metadata']['final_confidence']:.2f}")

    # Display accumulated metrics
    print("\n📊 Accumulated Correction Metrics:")
    metrics = rag.get_correction_metrics()
    for key, value in metrics.items():
        if isinstance(value, float):
            print(f"  - {key}: {value:.3f}")
        else:
            print(f"  - {key}: {value}")


def demonstrate_error_handling(rag: CorrectiveRAG):
    """Demonstrate error handling and fallback mechanisms."""
    print("\n" + "="*60)
    print("🛡️ DEMO 4: Error Handling and Fallback")
    print("="*60)

    # Configure retriever with INVALID connection details to trigger a REAL error
    print("Configuring retriever to us non-existent vector DB host...")
    
    # Save original retriever to restore later
    original_retriever = rag.retriever
    
    try:
        # Create a bad configuration
        bad_config = {
            'vector_store_config': {
                'store_type': 'remote_service', 
                'host': 'http://non-existent-host.local:12345',
                'timeout': 1.0
            },
            'embedding_config': {} 
        }
        
        # Inject broken retriever
        # We instantiate a fresh one with bad config to force connection errors
        from ailoos.rag.core.retrievers import VectorRetriever
        rag.retriever = VectorRetriever(bad_config)
        
    except Exception as e:
        logger.info(f"(Setup) Failed to init bad retriever: {e}")
        # If init failed, we can't test runtime fallback. 
        pass

    query = "What is artificial intelligence?"

    print(f"Query: {query}")
    print("Attempting retrieval from invalid source...")

    try:
        result = rag.run(query)
        print("✅ System handled error gracefully")
        
        # Check if fallback logic was actually triggered
        fallback_count = result.get('metadata', {}).get('correction_metrics', {}).get('fallback_activations', 0)
        if fallback_count > 0:
             print(f"Fallback activated: {fallback_count} times")
        else:
             print("⚠️ Fallback did not trigger (retrieval might have returned empty instead of raising)")
             
        print(f"Response received: {len(result.get('response', ''))} characters")
        
    except Exception as e:
        print(f"❌ Unexpected error (System crashed instead of handling?): {e}")

    # Restore original retriever
    rag.retriever = original_retriever


def main():
    """Main demonstration function."""
    print("🤖 Corrective RAG Demonstration")
    print("="*60)
    print("This demo showcases the Corrective RAG technique with:")
    print("• Iterative self-correction loops")
    print("• Confidence-based retrieval adjustments")
    print("• Comprehensive correction metrics")
    print("• Error handling and fallback mechanisms")
    print()

    try:
        # Set up the system
        rag = setup_corrective_rag()

        # Run demonstrations
        demonstrate_basic_query(rag)
        demonstrate_complex_query(rag)
        demonstrate_correction_metrics(rag)
        demonstrate_error_handling(rag)

        print("\n" + "="*60)
        print("✅ Corrective RAG demonstration completed successfully!")
        print("="*60)

        # Display final pipeline info
        print("\n🔧 Final Pipeline Information:")
        info = rag.get_pipeline_info()
        print(f"  - Technique: {info['technique']}")
        print(f"  - Description: {info['description']}")
        print(f"  - Max Iterations: {info['correction_config']['max_iterations']}")
        print(f"  - Confidence Threshold: {info['correction_config']['confidence_threshold']}")

    except Exception as e:
        logger.error(f"❌ Demo failed: {e}")
        print(f"\n❌ Demonstration failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
