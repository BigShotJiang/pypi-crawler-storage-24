"""
dracma Compliance - Travel Rule & VASP Integration

Implementa compliance para criptomonedas según FATF guidelines:
- Travel Rule para transacciones P2P
- Registro y verificación de VASPs
- Reportes regulatorios de transacciones
"""

import asyncio
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
import json
import uuid
import aiohttp

logger = logging.getLogger(__name__)


class VASPStatus(Enum):
    """Estados de registro VASP."""
    PENDING = "pending"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    SUSPENDED = "suspended"
    REVOKED = "revoked"


class VASPType(Enum):
    """Tipos de VASP."""
    EXCHANGE = "exchange"
    WALLET_PROVIDER = "wallet_provider"
    OTC_DESK = "otc_desk"
    P2P_PLATFORM = "p2p_platform"
    ATM_OPERATOR = "atm_operator"
    CUSTODY_SERVICE = "custody_service"


class TravelRuleStatus(Enum):
    """Estados del Travel Rule."""
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    PENDING_VERIFICATION = "pending_verification"
    VERIFICATION_FAILED = "verification_failed"
    EXEMPTED = "exempted"


@dataclass
class VASPRegistration:
    """Registro de VASP (Virtual Asset Service Provider)."""
    vasp_id: str
    name: str
    legal_name: str
    registration_number: str
    jurisdiction: str
    vasp_type: VASPType

    # Información de contacto
    email: str
    phone: str
    website: str

    # Información regulatoria
    regulatory_approvals: List[str] = field(default_factory=list)
    compliance_officer: Dict[str, str] = field(default_factory=dict)

    # Estado y metadata
    status: VASPStatus = VASPStatus.PENDING
    registered_at: datetime = field(default_factory=datetime.now)
    approved_at: Optional[datetime] = None
    last_updated: datetime = field(default_factory=datetime.now)

    # Información técnica para Travel Rule
    travel_rule_endpoints: Dict[str, str] = field(default_factory=dict)  # API endpoints
    public_keys: Dict[str, str] = field(default_factory=dict)  # Para verificación

    # Estadísticas
    monthly_volume: float = 0.0
    risk_score: float = 0.0

    @property
    def is_active(self) -> bool:
        """Verificar si el VASP está activo."""
        return self.status == VASPStatus.APPROVED

    @property
    def travel_rule_compliant(self) -> bool:
        """Verificar si soporta Travel Rule."""
        return bool(self.travel_rule_endpoints)


@dataclass
class TravelRuleTransaction:
    """Transacción sujeta a Travel Rule."""
    transaction_id: str
    originator_vasp: str
    beneficiary_vasp: str
    originator_user: Dict[str, Any]  # Información del originador
    beneficiary_user: Dict[str, Any]  # Información del beneficiario

    # Detalles de la transacción
    amount: float
    currency: str = "DRACMA"
    transaction_hash: str = ""  # Ahora tiene valor por defecto
    timestamp: datetime = field(default_factory=datetime.now)

    # Estado del Travel Rule
    status: TravelRuleStatus = TravelRuleStatus.PENDING_VERIFICATION
    verification_attempts: int = 0
    last_verification_attempt: Optional[datetime] = None

    # Información de cumplimiento
    compliance_check_passed: bool = False
    risk_assessment: Dict[str, Any] = field(default_factory=dict)
    regulatory_reports: List[Dict[str, Any]] = field(default_factory=list)

    # Metadata
    exemption_reason: Optional[str] = None
    notes: List[str] = field(default_factory=list)


@dataclass
class RegulatoryReport:
    """Reporte regulatorio de transacciones."""
    report_id: str
    report_type: str  # "monthly", "suspicious_activity", "travel_rule"
    jurisdiction: str
    reporting_period_start: datetime
    reporting_period_end: datetime

    # Contenido del reporte
    transactions: List[Dict[str, Any]] = field(default_factory=list)
    total_volume: float = 0.0
    high_value_transactions: List[Dict[str, Any]] = field(default_factory=list)
    suspicious_activities: List[Dict[str, Any]] = field(default_factory=list)

    # Estado
    status: str = "draft"  # draft, submitted, accepted, rejected
    submitted_at: Optional[datetime] = None
    regulator_response: Optional[str] = None

    # Metadata
    generated_at: datetime = field(default_factory=datetime.now)
    generated_by: str = "ailoos_compliance_system"


class TravelRuleEngine:
    """
    Motor de Travel Rule para transacciones DRACMA.

    Implementa FATF Travel Rule requirements:
    - Recopilación de información del originador y beneficiario
    - Verificación de VASPs
    - Transmisión segura de información
    - Manejo de exenciones
    """

    def __init__(self):
        self.vasps: Dict[str, VASPRegistration] = {}
        self.transactions: List[TravelRuleTransaction] = []
        self.thresholds = {
            'travel_rule_threshold': 1000,  # Dracma - umbral para Travel Rule
            'high_value_threshold': 10000,  # Dracma - transacción de alto valor
            'verification_timeout': 24,  # horas para timeout de verificación
        }
        self.vasp_verify_url = os.getenv("AILOOS_VASP_VERIFY_URL")
        self.vasp_verify_token = os.getenv("AILOOS_VASP_VERIFY_TOKEN")
        self.travel_rule_timeout = float(os.getenv("AILOOS_TRAVEL_RULE_TIMEOUT", "10.0"))

        # Estadísticas
        self.stats = {
            'total_transactions': 0,
            'compliant_transactions': 0,
            'non_compliant_transactions': 0,
            'exempted_transactions': 0,
            'verification_failures': 0
        }

        logger.info("TravelRuleEngine initialized")

    def register_vasp(self, registration: VASPRegistration) -> str:
        """Registrar un nuevo VASP."""
        if registration.vasp_id in self.vasps:
            raise ValueError(f"VASP {registration.vasp_id} already registered")

        self.vasps[registration.vasp_id] = registration

        # Iniciar proceso de verificación
        asyncio.create_task(self._verify_vasp_registration(registration))

        logger.info(f"VASP registered: {registration.vasp_id} - {registration.name}")
        return registration.vasp_id

    async def _verify_vasp_registration(self, vasp: VASPRegistration):
        """Verificar registro de VASP usando un proveedor externo."""
        if not self.vasp_verify_url:
            vasp.status = VASPStatus.UNDER_REVIEW
            vasp.last_updated = datetime.now()
            logger.warning("No VASP verification endpoint configured")
            return

        payload = {
            "vasp_id": vasp.vasp_id,
            "name": vasp.name,
            "legal_name": vasp.legal_name,
            "registration_number": vasp.registration_number,
            "jurisdiction": vasp.jurisdiction,
            "vasp_type": vasp.vasp_type.value,
            "email": vasp.email,
            "phone": vasp.phone,
            "website": vasp.website,
            "travel_rule_endpoints": vasp.travel_rule_endpoints,
            "public_keys": vasp.public_keys
        }

        headers = {"Content-Type": "application/json"}
        if self.vasp_verify_token:
            headers["Authorization"] = f"Bearer {self.vasp_verify_token}"

        timeout = aiohttp.ClientTimeout(total=self.travel_rule_timeout)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(self.vasp_verify_url, json=payload, headers=headers) as response:
                    body = await response.text()
                    if response.status >= 300:
                        logger.error(f"VASP verification failed: HTTP {response.status} - {body}")
                        vasp.status = VASPStatus.UNDER_REVIEW
                    else:
                        data = json.loads(body) if body else {}
                        status = data.get("status", "under_review").lower()
                        if status in {"approved", "active"}:
                            vasp.status = VASPStatus.APPROVED
                            vasp.approved_at = datetime.now()
                        elif status in {"suspended"}:
                            vasp.status = VASPStatus.SUSPENDED
                        elif status in {"revoked"}:
                            vasp.status = VASPStatus.REVOKED
                        else:
                            vasp.status = VASPStatus.UNDER_REVIEW
        except Exception as e:
            logger.error(f"VASP verification error: {e}")
            vasp.status = VASPStatus.UNDER_REVIEW

        vasp.last_updated = datetime.now()
        logger.info(f"VASP verification completed: {vasp.vasp_id} - {vasp.status.value}")

    def check_travel_rule_required(self, amount: float, originator_vasp: str, beneficiary_vasp: str) -> bool:
        """Verificar si una transacción requiere Travel Rule."""
        # Travel Rule aplica si:
        # 1. Monto supera el umbral
        # 2. Involucra diferentes VASPs
        # 3. No está exenta

        if amount < self.thresholds['travel_rule_threshold']:
            return False

        if originator_vasp == beneficiary_vasp:
            return False  # Misma VASP, no requiere Travel Rule

        return True

    async def process_travel_rule_transaction(self,
                                            transaction_id: str,
                                            originator_vasp: str,
                                            beneficiary_vasp: str,
                                            amount: float,
                                            originator_info: Dict[str, Any],
                                            transaction_hash: str) -> TravelRuleTransaction:
        """Procesar transacción sujeta a Travel Rule."""

        # Verificar si Travel Rule aplica
        if not self.check_travel_rule_required(amount, originator_vasp, beneficiary_vasp):
            # Crear transacción exenta
            transaction = TravelRuleTransaction(
                transaction_id=transaction_id,
                originator_vasp=originator_vasp,
                beneficiary_vasp=beneficiary_vasp,
                originator_user=originator_info,
                beneficiary_user={},  # No requerida para exenciones
                amount=amount,
                transaction_hash=transaction_hash,
                status=TravelRuleStatus.EXEMPTED,
                exemption_reason="Below threshold or same VASP"
            )
            self.transactions.append(transaction)
            self.stats['exempted_transactions'] += 1
            return transaction

        # Verificar VASPs
        originator = self.vasps.get(originator_vasp)
        beneficiary = self.vasps.get(beneficiary_vasp)

        if not originator or not originator.is_active:
            raise ValueError(f"Originator VASP {originator_vasp} not found or inactive")

        if not beneficiary or not beneficiary.is_active:
            raise ValueError(f"Beneficiary VASP {beneficiary_vasp} not found or inactive")

        # Crear transacción Travel Rule
        transaction = TravelRuleTransaction(
            transaction_id=transaction_id,
            originator_vasp=originator_vasp,
            beneficiary_vasp=beneficiary_vasp,
            originator_user=originator_info,
            beneficiary_user={},  # Se obtendrá del beneficiario
            amount=amount,
            transaction_hash=transaction_hash
        )

        self.transactions.append(transaction)
        self.stats['total_transactions'] += 1

        # Iniciar proceso de verificación
        asyncio.create_task(self._verify_travel_rule_compliance(transaction))

        logger.info(f"Travel Rule transaction initiated: {transaction_id}")
        return transaction

    async def _verify_travel_rule_compliance(self, transaction: TravelRuleTransaction):
        """Verificar cumplimiento de Travel Rule."""
        try:
            transaction.verification_attempts += 1
            transaction.last_verification_attempt = datetime.now()

            # Paso 1: Obtener información del beneficiario del VASP destino
            beneficiary_info = await self._request_beneficiary_info(transaction)

            if beneficiary_info:
                transaction.beneficiary_user = beneficiary_info

                # Paso 2: Verificar información requerida
                if self._validate_travel_rule_data(transaction):
                    transaction.status = TravelRuleStatus.COMPLIANT
                    transaction.compliance_check_passed = True
                    self.stats['compliant_transactions'] += 1

                    # Paso 3: Transmitir información al VASP destino
                    await self._transmit_travel_rule_data(transaction)

                else:
                    transaction.status = TravelRuleStatus.NON_COMPLIANT
                    self.stats['non_compliant_transactions'] += 1
            else:
                transaction.status = TravelRuleStatus.VERIFICATION_FAILED
                self.stats['verification_failures'] += 1

        except Exception as e:
            logger.error(f"Travel Rule verification failed for {transaction.transaction_id}: {e}")
            transaction.status = TravelRuleStatus.VERIFICATION_FAILED
            self.stats['verification_failures'] += 1

    async def _request_beneficiary_info(self, transaction: TravelRuleTransaction) -> Optional[Dict[str, Any]]:
        """Solicitar información del beneficiario al VASP destino."""
        beneficiary_vasp = self.vasps.get(transaction.beneficiary_vasp)

        if not beneficiary_vasp or not beneficiary_vasp.travel_rule_compliant:
            return None
        endpoint = beneficiary_vasp.travel_rule_endpoints.get("beneficiary_info") or \
            beneficiary_vasp.travel_rule_endpoints.get("beneficiary_info_url")
        if not endpoint:
            logger.warning(f"No beneficiary info endpoint configured for {beneficiary_vasp.vasp_id}")
            return None

        payload = {
            "transaction_id": transaction.transaction_id,
            "originator_user": transaction.originator_user,
            "amount": transaction.amount,
            "currency": transaction.currency,
            "transaction_hash": transaction.transaction_hash
        }

        headers = {"Content-Type": "application/json"}
        token = beneficiary_vasp.public_keys.get("auth_token") if beneficiary_vasp.public_keys else None
        if token:
            headers["Authorization"] = f"Bearer {token}"

        timeout = aiohttp.ClientTimeout(total=self.travel_rule_timeout)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(endpoint, json=payload, headers=headers) as response:
                    if response.status >= 300:
                        logger.error(f"Beneficiary info request failed: HTTP {response.status}")
                        return None
                    return await response.json()
        except Exception as e:
            logger.error(f"Beneficiary info request error: {e}")
            return None

    def _validate_travel_rule_data(self, transaction: TravelRuleTransaction) -> bool:
        """Validar que la transacción tiene toda la información requerida."""
        required_fields = ['name', 'account_id', 'verification_status']

        originator_valid = all(
            field in transaction.originator_user and transaction.originator_user[field]
            for field in required_fields
        )

        beneficiary_valid = all(
            field in transaction.beneficiary_user and transaction.beneficiary_user[field]
            for field in required_fields
        )

        return originator_valid and beneficiary_valid

    async def _transmit_travel_rule_data(self, transaction: TravelRuleTransaction):
        """Transmitir datos de Travel Rule al VASP destino."""
        beneficiary_vasp = self.vasps.get(transaction.beneficiary_vasp)

        if not beneficiary_vasp:
            return
        endpoint = beneficiary_vasp.travel_rule_endpoints.get("travel_rule_data") or \
            beneficiary_vasp.travel_rule_endpoints.get("transmit")
        if not endpoint:
            logger.warning(f"No travel rule transmit endpoint configured for {beneficiary_vasp.vasp_id}")
            return

        payload = {
            "transaction_id": transaction.transaction_id,
            "originator_user": transaction.originator_user,
            "beneficiary_user": transaction.beneficiary_user,
            "amount": transaction.amount,
            "currency": transaction.currency,
            "transaction_hash": transaction.transaction_hash,
            "timestamp": transaction.timestamp.isoformat()
        }

        headers = {"Content-Type": "application/json"}
        token = beneficiary_vasp.public_keys.get("auth_token") if beneficiary_vasp.public_keys else None
        if token:
            headers["Authorization"] = f"Bearer {token}"

        timeout = aiohttp.ClientTimeout(total=self.travel_rule_timeout)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(endpoint, json=payload, headers=headers) as response:
                    if response.status >= 300:
                        body = await response.text()
                        logger.error(
                            f"Travel Rule transmission failed: HTTP {response.status} - {body}"
                        )
                        return
            logger.info(
                f"Travel Rule data transmitted to {transaction.beneficiary_vasp} for transaction {transaction.transaction_id}"
            )
        except Exception as e:
            logger.error(f"Travel Rule transmission error: {e}")

    def get_travel_rule_status(self, transaction_id: str) -> Optional[Dict[str, Any]]:
        """Obtener estado de Travel Rule para una transacción."""
        transaction = next((t for t in self.transactions if t.transaction_id == transaction_id), None)

        if not transaction:
            return None

        return {
            'transaction_id': transaction.transaction_id,
            'status': transaction.status.value,
            'verification_attempts': transaction.verification_attempts,
            'compliance_check_passed': transaction.compliance_check_passed,
            'last_verification_attempt': transaction.last_verification_attempt.isoformat() if transaction.last_verification_attempt else None,
            'exemption_reason': transaction.exemption_reason
        }

    def get_travel_rule_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas de Travel Rule."""
        return {
            **self.stats,
            'compliance_rate': (self.stats['compliant_transactions'] / self.stats['total_transactions'] * 100) if self.stats['total_transactions'] > 0 else 0,
            'generated_at': datetime.now().isoformat()
        }


class TransactionReportingEngine:
    """
    Motor de reportes regulatorios para transacciones DRACMA.

    Genera reportes requeridos por reguladores según jurisdicción.
    """

    def __init__(self):
        self.reports: List[RegulatoryReport] = []
        self.reporting_jurisdictions = {
            'US': {'threshold': 3000, 'frequency': 'monthly'},
            'EU': {'threshold': 1000, 'frequency': 'quarterly'},
            'UK': {'threshold': 1000, 'frequency': 'monthly'}
        }
        self.reporting_endpoint = os.getenv("AILOOS_DRACMA_REPORTING_ENDPOINT")
        self.sar_endpoint = os.getenv("AILOOS_DRACMA_SAR_ENDPOINT")
        self.reporting_token = os.getenv("AILOOS_DRACMA_REPORTING_TOKEN")
        self.reporting_timeout = float(os.getenv("AILOOS_DRACMA_REPORTING_TIMEOUT", "10.0"))
        self.regulator_submit_url = os.getenv("AILOOS_REGULATOR_SUBMIT_URL")

        logger.info("TransactionReportingEngine initialized")

    def generate_monthly_report(self, jurisdiction: str, year: int, month: int) -> RegulatoryReport:
        """Generar reporte mensual para una jurisdicción."""
        start_date = datetime(year, month, 1)
        end_date = datetime(year, month + 1, 1) - timedelta(days=1)

        report = RegulatoryReport(
            report_id=f"monthly_{jurisdiction}_{year}_{month:02d}",
            report_type="monthly",
            jurisdiction=jurisdiction,
            reporting_period_start=start_date,
            reporting_period_end=end_date
        )

        report.transactions = self._fetch_transactions(start_date, end_date, jurisdiction)
        report.total_volume = sum(t['amount'] for t in report.transactions)
        report.high_value_transactions = [
            t for t in report.transactions
            if t['amount'] >= self.reporting_jurisdictions[jurisdiction]['threshold']
        ]

        self.reports.append(report)
        logger.info(f"Monthly report generated: {report.report_id}")

        return report

    def generate_suspicious_activity_report(self, jurisdiction: str, start_date: datetime, end_date: datetime) -> RegulatoryReport:
        """Generar reporte de actividades sospechosas."""
        report = RegulatoryReport(
            report_id=f"sar_{jurisdiction}_{int(start_date.timestamp())}",
            report_type="suspicious_activity",
            jurisdiction=jurisdiction,
            reporting_period_start=start_date,
            reporting_period_end=end_date
        )

        report.suspicious_activities = self._fetch_suspicious_activities(start_date, end_date, jurisdiction)

        self.reports.append(report)
        logger.info(f"Suspicious activity report generated: {report.report_id}")

        return report

    def _fetch_transactions(self, start_date: datetime, end_date: datetime,
                            jurisdiction: str) -> List[Dict[str, Any]]:
        if not self.reporting_endpoint:
            logger.error("No reporting endpoint configured for transactions")
            return []

        payload = {
            "jurisdiction": jurisdiction,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        }
        headers = {"Content-Type": "application/json"}
        if self.reporting_token:
            headers["Authorization"] = f"Bearer {self.reporting_token}"

        try:
            import requests
            response = requests.post(
                self.reporting_endpoint,
                json=payload,
                headers=headers,
                timeout=self.reporting_timeout
            )
            response.raise_for_status()
            data = response.json()
            return data.get("transactions", [])
        except Exception as e:
            logger.error(f"Failed to fetch transactions: {e}")
            return []

    def _fetch_suspicious_activities(self, start_date: datetime, end_date: datetime,
                                     jurisdiction: str) -> List[Dict[str, Any]]:
        if not self.sar_endpoint:
            logger.error("No suspicious activity endpoint configured")
            return []

        payload = {
            "jurisdiction": jurisdiction,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        }
        headers = {"Content-Type": "application/json"}
        if self.reporting_token:
            headers["Authorization"] = f"Bearer {self.reporting_token}"

        try:
            import requests
            response = requests.post(
                self.sar_endpoint,
                json=payload,
                headers=headers,
                timeout=self.reporting_timeout
            )
            response.raise_for_status()
            data = response.json()
            return data.get("suspicious_activities", [])
        except Exception as e:
            logger.error(f"Failed to fetch suspicious activities: {e}")
            return []

    def submit_report(self, report_id: str) -> bool:
        """Enviar reporte a regulador."""
        report = next((r for r in self.reports if r.report_id == report_id), None)

        if not report:
            return False

        if not self.regulator_submit_url:
            logger.error("No regulator submit URL configured")
            return False

        payload = {
            "report_id": report.report_id,
            "report_type": report.report_type,
            "jurisdiction": report.jurisdiction,
            "reporting_period_start": report.reporting_period_start.isoformat(),
            "reporting_period_end": report.reporting_period_end.isoformat(),
            "transactions": report.transactions,
            "total_volume": report.total_volume,
            "high_value_transactions": report.high_value_transactions,
            "suspicious_activities": report.suspicious_activities
        }
        headers = {"Content-Type": "application/json"}
        if self.reporting_token:
            headers["Authorization"] = f"Bearer {self.reporting_token}"

        try:
            import requests
            response = requests.post(
                self.regulator_submit_url,
                json=payload,
                headers=headers,
                timeout=self.reporting_timeout
            )
            response.raise_for_status()
            report.status = "submitted"
            report.submitted_at = datetime.now()
        except Exception as e:
            logger.error(f"Report submission failed: {e}")
            return False

        logger.info(f"Report submitted: {report_id}")
        return True

    def get_report_status(self, report_id: str) -> Optional[Dict[str, Any]]:
        """Obtener estado de un reporte."""
        report = next((r for r in self.reports if r.report_id == report_id), None)

        if not report:
            return None

        return {
            'report_id': report.report_id,
            'type': report.report_type,
            'jurisdiction': report.jurisdiction,
            'status': report.status,
            'submitted_at': report.submitted_at.isoformat() if report.submitted_at else None,
            'total_transactions': len(report.transactions),
            'total_volume': report.total_volume
        }

    def get_reporting_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas de reportes."""
        submitted = len([r for r in self.reports if r.status == "submitted"])
        pending = len([r for r in self.reports if r.status == "draft"])

        return {
            'total_reports': len(self.reports),
            'submitted_reports': submitted,
            'pending_reports': pending,
            'submission_rate': (submitted / len(self.reports) * 100) if self.reports else 0,
            'generated_at': datetime.now().isoformat()
        }


# Instancias globales
_travel_rule_engine = TravelRuleEngine()
_transaction_reporting = TransactionReportingEngine()


def get_travel_rule_engine() -> TravelRuleEngine:
    """Obtener instancia global del Travel Rule engine."""
    return _travel_rule_engine


def get_transaction_reporting_engine() -> TransactionReportingEngine:
    """Obtener instancia global del transaction reporting engine."""
    return _transaction_reporting


# Funciones de conveniencia

def register_vasp(name: str, jurisdiction: str, vasp_type: VASPType, **kwargs) -> str:
    """Registrar un VASP."""
    vasp_id = f"vasp_{uuid.uuid4().hex[:8]}"

    registration = VASPRegistration(
        vasp_id=vasp_id,
        name=name,
        legal_name=kwargs.get('legal_name', name),
        registration_number=kwargs.get('registration_number', f"REG_{jurisdiction}_{uuid.uuid4().hex[:6]}"),
        jurisdiction=jurisdiction,
        vasp_type=vasp_type,
        email=kwargs.get('email', f'compliance@{name.lower().replace(" ", "")}.com'),
        phone=kwargs.get('phone', '+1-555-0123'),
        website=kwargs.get('website', f'https://{name.lower().replace(" ", "")}.com')
    )

    return _travel_rule_engine.register_vasp(registration)


async def process_dracma_transaction(originator_vasp: str,
                                   beneficiary_vasp: str,
                                   amount: float,
                                   originator_info: Dict[str, Any],
                                   transaction_hash: str) -> TravelRuleTransaction:
    """Procesar transacción Dracma con Travel Rule."""
    transaction_id = f"dracma_tx_{uuid.uuid4().hex}"

    return await _travel_rule_engine.process_travel_rule_transaction(
        transaction_id=transaction_id,
        originator_vasp=originator_vasp,
        beneficiary_vasp=beneficiary_vasp,
        amount=amount,
        originator_info=originator_info,
        transaction_hash=transaction_hash
    )


def generate_monthly_report(jurisdiction: str, year: int, month: int) -> RegulatoryReport:
    """Generar reporte mensual."""
    return _transaction_reporting.generate_monthly_report(jurisdiction, year, month)
