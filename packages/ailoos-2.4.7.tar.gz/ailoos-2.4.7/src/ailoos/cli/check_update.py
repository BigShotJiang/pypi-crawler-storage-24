#!/usr/bin/env python3
"""
Ailoos SDK Update Checker CLI
Check for available updates and optionally auto-update.
"""

import asyncio
import sys
from ailoos.sdk import __version__
from ailoos.sdk.auto_update import AutoUpdateChecker


async def main():
    print(f"""
 ███         █████████ 
░░░███      ███░░░░░███
  ░░░███   ███     ░░░ 
    ░░░███░███         
     ███░ ░███    █████
   ███░   ░░███  ░░███ 
 ███░      ░░█████████ 
░░░         ░░░░░░░░░  
""")
    print(f"Ailoos SDK v{__version__}")
    print("-" * 40)
    
    # Check for updates
    checker = AutoUpdateChecker(__version__, auto_update=False, check_on_init=False)
    update_available, latest = await checker.check_for_updates(force=True)
    
    if update_available:
        print(f"\n✅ Update available: {__version__} → {latest}")
        print("\nTo update, run:")
        print("  pip install --upgrade ailoos")
        print("  # or")
        print("  ailoos-terminal --update")
        return 1
    else:
        print(f"\n✅ You're running the latest version ({__version__})")
        return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
