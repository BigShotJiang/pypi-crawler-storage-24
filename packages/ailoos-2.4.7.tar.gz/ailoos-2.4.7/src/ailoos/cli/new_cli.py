#!/usr/bin/env python3
"""
AILOOS New CLI - Terminal nativo en Python
Interfaz real que lee hardware, wallet y estado del sistema
"""

import asyncio
import os
import click
from typing import Optional

from ..blockchain.dracma_token import get_token_manager

from ..blockchain.dracma_token import get_token_manager
from ..sdk.node_sdk import NodeSDK, NodeRole
from ..core.deployment_archetypes import DeploymentArchetype

from .main import AILOOSCLI


@click.group()
@click.option('--user-id', default='default_user', help='User ID for the session')
@click.pass_context
def cli(ctx, user_id):
    """AILOOS Neural Link Terminal - Decentralized AI Command Center"""
    ctx.ensure_object(dict)
    ctx.obj['user_id'] = user_id
    ctx.obj['cli_instance'] = AILOOSCLI(user_id)


@cli.command()
@click.pass_context
def terminal(ctx):
    """Launch the interactive neural link terminal"""
    cli_instance = ctx.obj['cli_instance']
    asyncio.run(cli_instance.run())


@cli.command()
@click.pass_context
def status(ctx):
    """Show current system and wallet status"""
    cli_instance = ctx.obj['cli_instance']

    async def show_status():
        await cli_instance.initialize()
        cli_instance.show_main_screen()

    asyncio.run(show_status())


@cli.command()
@click.option('--role', default='scout', help='Node Role (scout, forge, etc.)')
@click.option('--archetype', default='sovereign', help='Deployment Archetype (sovereign, phalanx, foundry, nexus)')
@click.option('--node-id', default='my_node', help='Unique Node ID')
@click.pass_context
def start(ctx, role, archetype, node_id):
    """Start a headless node instance with specific configuration."""
    
    async def run_node():
        click.echo(f"🚀 Starting Node: {node_id}")
        click.echo(f"   Role: {role.upper()}")
        click.echo(f"   Archetype: {archetype.upper()}")
        
        try:
            # Map strings to Enums
            role_enum = NodeRole(role.lower())
            archetype_enum = DeploymentArchetype(archetype.lower())
            
            node = NodeSDK(
                node_id=node_id, 
                role=role_enum, 
                archetype=archetype_enum
            )
            
            click.echo("   Initializing SDK...")
            if await node.initialize():
                click.echo("   ✅ SDK Initialized")
                if await node.start():
                    click.echo("   ✅ Node Started successfully. Press Ctrl+C to stop.")
                    # Keep running
                    while True:
                        await asyncio.sleep(1)
            else:
                click.echo("   ❌ Failed to initialize node.", err=True)
                
        except ValueError as e:
            click.echo(f"   ❌ Invalid configuration: {e}", err=True)
        except Exception as e:
            click.echo(f"   ❌ Critical error: {e}", err=True)

    try:
        asyncio.run(run_node())
    except KeyboardInterrupt:
        click.echo("\n🛑 Node stopped by user.")


@cli.command()
@click.option('--json', is_flag=True, help='Output in JSON format')
@click.pass_context
def wallet_balance(ctx, json):
    """Show wallet balance"""
    cli_instance = ctx.obj['cli_instance']

    async def show_balance():
        wallet_info = await cli_instance.wallet.get_wallet_balance()
        if json:
            import json as json_lib
            click.echo(json_lib.dumps(wallet_info, indent=2))
        else:
            click.echo(f"💰 Balance: {wallet_info.get('balance', 0):.2f} DRACMA")
            click.echo(f"🔒 Staked: {wallet_info.get('staked', 0):.2f} DRACMA")
            click.echo(f"🎁 Rewards: {wallet_info.get('rewards', 0):.2f} DRACMA")
            click.echo(f"📧 Address: {wallet_info.get('address', 'Not set')}")

    asyncio.run(show_balance())


@cli.command()
@click.option('--limit', default=10, help='Number of transactions to show')
@click.pass_context
def wallet_history(ctx, limit):
    """Show wallet transaction history"""
    cli_instance = ctx.obj['cli_instance']

    async def show_history():
        transactions = await cli_instance.wallet.get_transaction_history(limit)
        if transactions:
            click.echo("📊 Recent Transactions:")
            for tx in transactions:
                click.echo(f"  {tx.get('date', '')[:10]} | {tx.get('type', '')} | {tx.get('amount', 0):.2f} Dracma | {tx.get('description', '')}")
        else:
            click.echo("No transactions found")

    asyncio.run(show_history())


@cli.command()
@click.argument('amount', type=float)
@click.option('--to', required=True, help='Recipient address')
@click.pass_context
def wallet_transfer(ctx, amount, to):
    """Transfer dracma"""
    cli_instance = ctx.obj['cli_instance']

    async def transfer():
        try:
            # Verificar balance
            balance_info = await cli_instance.wallet.get_wallet_balance()
            if balance_info.get('balance', 0) < amount:
                click.echo("❌ Insufficient balance", err=True)
                return

            sender_address = balance_info.get('address') or os.getenv("WALLET_ADDRESS", "")
            private_key = os.getenv("WALLET_PRIVATE_KEY") or os.getenv("AILOOS_BRIDGE_PRIVATE_KEY")
            if not sender_address:
                click.echo("❌ WALLET_ADDRESS not configured", err=True)
                return

            click.echo(f"💸 Transferring {amount} Dracma to {to}...")

            token_manager = get_token_manager()
            result = await token_manager.transfer_tokens(sender_address, to, amount, private_key=private_key)
            if not result.success:
                click.echo(f"❌ Transfer failed: {result.error_message or 'Unknown error'}", err=True)
                return

            cli_instance.state.add_transaction({
                'type': 'transfer',
                'amount': -amount,
                'description': f'Transfer to {to}',
                'tx_hash': result.tx_hash
            })

            click.echo("✅ Transfer completed successfully!")

        except Exception as e:
            click.echo(f"❌ Transfer failed: {e}", err=True)

    asyncio.run(transfer())


@cli.command()
@click.argument('amount', type=float)
@click.pass_context
def stake(ctx, amount):
    """Stake dracma"""
    cli_instance = ctx.obj['cli_instance']

    async def stake_tokens():
        try:
            # Verificar balance
            balance_info = await cli_instance.wallet.get_wallet_balance()
            if balance_info.get('balance', 0) < amount:
                click.echo("❌ Insufficient balance", err=True)
                return

            click.echo(f"🔒 Staking {amount} DRACMA...")

            sender_address = balance_info.get('address') or os.getenv("WALLET_ADDRESS", "")
            private_key = os.getenv("WALLET_PRIVATE_KEY") or os.getenv("AILOOS_BRIDGE_PRIVATE_KEY")
            if not sender_address:
                click.echo("❌ WALLET_ADDRESS not configured", err=True)
                return

            token_manager = get_token_manager()
            result = await token_manager.stake_tokens(sender_address, amount, private_key=private_key)
            if not result.success:
                click.echo(f"❌ Staking failed: {result.error_message or 'Unknown error'}", err=True)
                return

            cli_instance.state.add_transaction({
                'type': 'stake',
                'amount': amount,
                'description': 'Token staking',
                'tx_hash': result.tx_hash
            })

            staking_info = await cli_instance.wallet.get_staking_info()
            click.echo(f"✅ Staking completed! APY: {staking_info.get('apy', 15.5)}%")

        except Exception as e:
            click.echo(f"❌ Staking failed: {e}", err=True)

    asyncio.run(stake_tokens())


@cli.command()
@click.pass_context
def hardware(ctx):
    """Show hardware information"""
    cli_instance = ctx.obj['cli_instance']

    hardware_info = cli_instance.hardware.get_all_hardware_info()

    click.echo("🔧 HARDWARE INFORMATION")
    click.echo("=" * 40)

    cpu = hardware_info.get('cpu', {})
    click.echo(f"CPU: {cpu.get('cores', 0)} cores, {cpu.get('usage_percent', 0):.1f}% usage")

    mem = hardware_info.get('memory', {})
    click.echo(f"RAM: {mem.get('used_gb', 0):.1f}/{mem.get('total_gb', 0):.1f} GB ({mem.get('usage_percent', 0):.1f}%)")

    disk = hardware_info.get('disk', {})
    click.echo(f"Disk: {disk.get('used_gb', 0):.1f}/{disk.get('total_gb', 0):.1f} GB ({disk.get('usage_percent', 0):.1f}%)")

    gpu = hardware_info.get('gpu', {})
    click.echo(f"GPU: {gpu.get('name', 'None detected')}")

    system = hardware_info.get('system', {})
    click.echo(f"OS: {system.get('os', 'Unknown')}")


@cli.command()
@click.pass_context
def system(ctx):
    """Show system status"""
    cli_instance = ctx.obj['cli_instance']

    system_info = cli_instance.system.get_all_system_status()

    click.echo("🌐 SYSTEM STATUS")
    click.echo("=" * 40)

    click.echo(f"Uptime: {system_info.get('uptime', 'Unknown')}")
    click.echo(f"Peers: {system_info.get('peers', 0)}")
    click.echo(f"Network: {system_info.get('network', {}).get('status', 'Unknown')}")

    load = system_info.get('load', {})
    click.echo(f"Load Average: {load.get('1min', 0):.2f}, {load.get('5min', 0):.2f}, {load.get('15min', 0):.2f}")


@cli.command()
@click.pass_context
def node_info(ctx):
    """Show node information"""
    cli_instance = ctx.obj['cli_instance']

    node_info = cli_instance.state.get_node_info()
    stats = cli_instance.state.get_stats()

    click.echo("🤖 NODE INFORMATION")
    click.echo("=" * 40)

    click.echo(f"Node ID: {node_info.get('id', 'Unknown')}")
    click.echo(f"Role: {node_info.get('role', 'Unknown')}")
    click.echo(f"Level: {node_info.get('level', 1)}")
    click.echo(f"Reputation: {node_info.get('reputation', 0)}/1000")
    click.echo(f"Peers: {node_info.get('peers', 0)}")
    click.echo(f"Status: {node_info.get('status', 'Unknown')}")

    click.echo(f"\n📊 STATISTICS")
    click.echo(f"Total Earned: {stats.get('total_earned', 0):.2f} DRACMA")
    click.echo(f"Datasets Processed: {stats.get('datasets_processed', 0)}")
    click.echo(f"Training Sessions: {stats.get('training_sessions', 0)}")
    click.echo(f"Validation Tasks: {stats.get('validation_tasks', 0)}")


@cli.command()
@click.argument('user_id', required=False)
@click.pass_context
def create_wallet(ctx, user_id):
    """Create a new Dracma wallet"""
    if not user_id:
        user_id = ctx.obj['user_id']

    cli_instance = ctx.obj['cli_instance']

    async def create():
        try:
            click.echo(f"💰 Creating wallet for user: {user_id}...")

            # Intentar crear wallet real
            wallet_info = await cli_instance.wallet.get_wallet_balance()

            if wallet_info.get('address'):
                click.echo(f"✅ Wallet already exists: {wallet_info.get('address')}")
                return

            token_manager = get_token_manager()
            address = await token_manager.initialize_user_wallet(user_id)
            click.echo("✅ Wallet created successfully!")
            click.echo(f"📧 Address: {address}")

        except Exception as e:
            click.echo(f"❌ Failed to create wallet: {e}", err=True)

    asyncio.run(create())


if __name__ == '__main__':
    cli()
