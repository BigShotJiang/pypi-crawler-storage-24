"""
Database Models
===============

SQLAlchemy models for database tables.
"""

from sqlalchemy import Column, Integer, String, DateTime, JSON, Text, Float
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class SystemMetric(Base):
    """Model for storing system metrics."""
    __tablename__ = "system_metrics"

    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, nullable=False, default=datetime.utcnow)
    metric_type = Column(String(50), nullable=False)  # e.g., 'resource', 'performance', 'application'
    data = Column(JSON, nullable=False)  # JSON data containing the metrics
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return f"<SystemMetric(id={self.id}, type={self.metric_type}, timestamp={self.timestamp})>"


class LogEntry(Base):
    """Model for storing log entries."""
    __tablename__ = "log_entries"

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(100), nullable=False)
    event_type = Column(String(50), nullable=False)
    timestamp = Column(DateTime, nullable=False)
    user_id = Column(String(100), nullable=True)
    action = Column(String(100), nullable=False)
    data = Column(JSON, nullable=True)
    signature = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return f"<LogEntry(id={self.id}, event_id={self.event_id}, event_type={self.event_type})>"