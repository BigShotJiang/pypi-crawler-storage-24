"""
Privacy Models - SQLAlchemy definitions for Privacy Persistence
==============================================================

Defines database models for:
- User Consents (GDPR)
- Do Not Sell Preferences (CCPA)
- Data Deletion Requests (Right to Erasure)
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, JSON, ForeignKey, Text, Enum as SQLEnum
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

from ailoos.coordinator.database.connection import Base

class ConsentCategory(str, enum.Enum):
    ESSENTIAL = "essential"
    FUNCTIONAL = "functional"
    ANALYTICS = "analytics"
    MARKETING = "marketing"
    PERSONALIZATION = "personalization"

class ConsentPurpose(str, enum.Enum):
    ACCOUNT_CREATION = "account_creation"
    SERVICE_DELIVERY = "service_delivery"
    ANALYTICS_TRACKING = "analytics_tracking"
    MARKETING_COMMUNICATION = "marketing_communication"
    FEDERATED_TRAINING = "federated_training"

class UserConsent(Base):
    """Model for storing user consent history."""
    __tablename__ = "privacy_user_consents"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, index=True, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    category = Column(String, nullable=False) # Stored as string to allow flexibility, validated against enum in manager
    purpose = Column(String, nullable=False)
    granted = Column(Boolean, default=True, nullable=False)
    ip_address = Column(String, nullable=True)
    user_agent = Column(String, nullable=True)
    valid_until = Column(DateTime, nullable=True)
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "timestamp": self.timestamp.isoformat(),
            "category": self.category,
            "purpose": self.purpose,
            "granted": self.granted,
            "valid_until": self.valid_until.isoformat() if self.valid_until else None
        }

class DoNotSellPreference(Base):
    """Model for storing CCPA Do Not Sell preferences."""
    __tablename__ = "privacy_do_not_sell"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, unique=True, index=True, nullable=False)
    global_opt_out = Column(Boolean, default=False, nullable=False)
    categories = Column(JSON, default=list) # List of blocked categories
    third_parties = Column(JSON, default=list) # List of blocked third parties
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    ip_address = Column(String, nullable=True)
    user_agent = Column(String, nullable=True)

    def to_dict(self):
        return {
            "user_id": self.user_id,
            "global_opt_out": self.global_opt_out,
            "categories": self.categories,
            "third_parties": self.third_parties,
            "updated_at": self.updated_at.isoformat()
        }

class DeletionRequest(Base):
    """Model for tracking Data Deletion Workflows."""
    __tablename__ = "privacy_deletion_requests"

    id = Column(Integer, primary_key=True, index=True)
    request_id = Column(String, unique=True, index=True, nullable=False)
    user_id = Column(String, index=True, nullable=False)
    status = Column(String, default="pending", nullable=False) # pending, in_progress, completed, failed, partial
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    data_locations = Column(JSON, default=list) # List of locations to delete from
    verification_report = Column(JSON, default=dict) # Verification hashes and status
    metadata_info = Column(JSON, default=dict) # Renamed from metadata to avoid conflict with SQLAlchemy metadata

    def to_dict(self):
        return {
            "request_id": self.request_id,
            "user_id": self.user_id,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "verification_report": self.verification_report
        }
