"""
Batch Operations Utility
========================

Provides buffering and batch writing capabilities for database operations.
Significantly improves throughput for high-volume logs and metrics.
"""

import asyncio
import logging
from typing import List, Any, Callable, Optional, TypeVar, Generic
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from .async_connection import get_async_db
from .models import SystemMetric, LogEntry

logger = logging.getLogger(__name__)

T = TypeVar("T")

class BatchWriter(Generic[T]):
    """
    Async Batch Writer.
    Buffers items and writes them to DB when buffer is full or flushing interval is reached.
    """
    
    def __init__(self, 
                 write_callback: Callable[[AsyncSession, List[T]], Any],
                 batch_size: int = 1000,
                 flush_interval_seconds: float = 1.0):
        """
        Args:
            write_callback: Async function (session, items) -> None to persist batch.
            batch_size: Max items before forced flush.
            flush_interval_seconds: Max time before forced flush.
        """
        self.write_callback = write_callback
        self.batch_size = batch_size
        self.flush_interval = flush_interval_seconds
        
        self.buffer: List[T] = []
        self._lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None
        self._running = False
        
    async def start(self):
        """Start the auto-flush loop."""
        if self._running:
            return
            
        self._running = True
        self._flush_task = asyncio.create_task(self._flush_loop())
        logger.info(f"🚀 BatchWriter started (Size: {self.batch_size}, Interval: {self.flush_interval}s)")
        
    async def stop(self):
        """Stop the writer and flush remaining items."""
        self._running = False
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        
        # Final flush
        await self.flush()
        logger.info("🛑 BatchWriter stopped")
        
    async def add(self, item: T):
        """Add an item to the buffer."""
        async with self._lock:
            self.buffer.append(item)
            should_flush = len(self.buffer) >= self.batch_size
            
        if should_flush:
            await self.flush()
            
    async def flush(self):
        """Flush buffer to database."""
        async with self._lock:
            if not self.buffer:
                return
            
            items_to_process = self.buffer[:]
            self.buffer.clear()
            
        if not items_to_process:
            return

        try:
            async with get_async_db() as session:
                await self.write_callback(session, items_to_process)
            logger.debug(f"✅ Flushed {len(items_to_process)} items")
            
        except Exception as e:
            logger.error(f"❌ Error flushing batch: {e}")
            # Optional: Re-queue items or dump to fallback log
            
    async def _flush_loop(self):
        """Background loop to flush periodically."""
        while self._running:
            try:
                await asyncio.sleep(self.flush_interval)
                await self.flush()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in flush loop: {e}")

# Global batch writer instance
_batch_writer: Optional[BatchWriter[dict]] = None

async def get_batch_writer() -> BatchWriter[dict]:
    """Get or create global batch writer instance."""
    global _batch_writer
    if _batch_writer is None:
        async def generic_writer(session: AsyncSession, items: List[dict]):
            # Handle different types of items
            for item in items:
                item_type = item.get('type')
                data = item.get('data', {})

                if item_type == 'audit_log':
                    # Use immutable log storage
                    from ..auditing.immutable_log_storage import LogEntry, get_immutable_log_storage
                    log_entry = LogEntry(
                        log_id=data.get('event_id'),
                        log_type=data.get('event_type', 'unknown'),
                        timestamp=data.get('timestamp'),
                        user_id=data.get('user_id'),
                        operation_type=data.get('action'),
                        data=data,
                        signature=None
                    )
                    storage = get_immutable_log_storage()
                    storage.store_log(log_entry)

                elif item_type == 'system_metric':
                    # For now, just log metrics (could be stored in a metrics table)
                    # Metrics Storage Implementation
                    # We store metrics via standard logging or specialized time-series DB ingestion hooks.
                    # For now, we utilize the structured logger which can be routed to Prometheus/Grafana.
                    logger.info(f"METRIC: {item_type} | {data.get('name')}: {data.get('value')} | {data.get('labels')}")

                else:
                    # Unknown type, skip or log warning
                    pass

        _batch_writer = BatchWriter(generic_writer, batch_size=100, flush_interval_seconds=1.0)
        await _batch_writer.start()

    return _batch_writer

# Example Usage Helper / Factory
def create_log_batch_writer() -> BatchWriter[dict]:
    async def log_writer(session: AsyncSession, logs: List[dict]):
        # Implementation depends on Log model
        # from .models import LogEntry
        # session.add_all([LogEntry(**log) for log in logs])
        pass

    return BatchWriter(log_writer)
