"""
Async Database Connection
=========================

Provides asynchronous SQLAlchemy engine and session management.
Required for high-throughput non-blocking DB operations.
"""

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from contextlib import asynccontextmanager
from typing import AsyncGenerator
import asyncio

from ..core.config import get_config
from .models import Base

config = get_config()

# Convert standard postgresql:// URL to postgresql+asyncpg://
db_url = config.database.connection_string.replace("postgresql://", "postgresql+asyncpg://")

# Async Engine
async_engine = create_async_engine(
    db_url,
    echo=config.debug_mode,
    pool_size=config.database.connection_pool_size,
    max_overflow=10,
    pool_pre_ping=True
)

# Async Session Factory
AsyncSessionLocal = sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False
)

@asynccontextmanager
async def get_async_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency for getting async DB session.
    Usage:
        async with get_async_db() as db:
            result = await db.execute(...)
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        # Session closes automatically due to context manager
