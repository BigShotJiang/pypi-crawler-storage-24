#!/usr/bin/env python3
"""
Demo script for Self RAG

This script demonstrates the Self-RAG technique, which dynamically decides
whether retrieval is needed based on internal confidence assessment.
"""

import sys
import time

sys.path.insert(0, 'src')

from ailoos.rag.techniques.self_rag import SelfRAG
from ailoos.rag.demo_utils import load_documents_from_env, require_env
from ailoos.utils.logging import get_logger

logger = get_logger(__name__)


def setup_self_rag():
    """Set up SelfRAG with sample configuration."""
    model_path = require_env("AILOOS_RAG_MODEL_PATH")
    config = {
        'retriever_config': {'chunk_size': 500, 'chunk_overlap': 50},
        'generator_config': {
            'empoorio_api_config': {
                'model_path': model_path
            },
            'generation_config': {
                'max_new_tokens': 512,
                'temperature': 0.7,
                'top_p': 0.9
            }
        },
        'evaluator_config': {},
        'reflection_config': {
            'enable_self_assessment': True,
            'confidence_threshold': 0.6,
            'force_retrieval_for_complex_queries': True
        }
    }

    rag = SelfRAG(config)
    documents = load_documents_from_env()
    rag.retriever.add_documents(documents)

    logger.info(f"SelfRAG initialized with {len(documents)} documents")
    return rag


def demonstrate_self_rag(rag: SelfRAG):
    """Demonstrate self-reflective RAG functionality."""
    print("="*60)
    print("SELF RAG DEMONSTRATION")
    print("="*60)

    # Test queries with different confidence levels
    queries = [
        "What is AI?",  # Should have high confidence, avoid retrieval
        "Explain the relationship between machine learning and deep learning in detail.",  # Complex, should retrieve
    ]

    for i, query in enumerate(queries, 1):
        print(f"\nQuery {i}: {query}")

        start_time = time.time()
        result = rag.run(query)
        processing_time = time.time() - start_time

        meta = result['metadata']
        retrieval_performed = meta['retrieval_performed']
        confidence = meta['confidence_assessment']['confidence']

        print(f"Retrieval performed: {retrieval_performed}")
        print(f"Confidence level: {meta['confidence_assessment']['confidence_level']} ({confidence:.3f})")
        print(f"Processing time: {processing_time:.2f}s")

        if meta.get('reflection_metadata'):
            reflection = meta['reflection_metadata']
            if reflection.get('issues_identified'):
                print(f"Issues identified: {reflection['issues_identified']}")
            if reflection.get('refinements_applied'):
                print(f"Refinements applied: {len(reflection['refinements_applied'])}")

        print(f"Response: {result['response'][:100]}...")

    # Show efficiency metrics
    print("\nEfficiency Metrics:")
    efficiency = rag._calculate_efficiency_info()
    print(f"  - Efficiency ratio: {efficiency['efficiency_ratio']:.2f}")
    print(f"  - Retrievals avoided: {efficiency['retrieval_avoided']}")
    print(f"  - Retrievals performed: {efficiency['retrieval_performed']}")
    print(f"  - Average confidence: {efficiency['average_confidence']:.3f}")


def main():
    """Main demonstration function."""
    print("Self RAG Demo")
    print("Features: Dynamic retrieval decision-making, confidence assessment, efficiency optimization")

    try:
        rag = setup_self_rag()
        demonstrate_self_rag(rag)
        print("\nDemo completed successfully!")

    except Exception as e:
        logger.error(f"Demo failed: {e}")
        print(f"Demo failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
