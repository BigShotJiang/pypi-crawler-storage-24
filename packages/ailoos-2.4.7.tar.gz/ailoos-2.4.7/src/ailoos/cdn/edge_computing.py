import asyncio
import logging
import json
import time
from typing import Dict, List, Optional, Any, Callable, Union
from dataclasses import dataclass
from enum import Enum
import numpy as np
import aiohttp

logger = logging.getLogger(__name__)

class ModelType(Enum):
    CLASSIFICATION = "classification"
    REGRESSION = "regression"
    NLP = "nlp"
    COMPUTER_VISION = "computer_vision"
    RECOMMENDATION = "recommendation"

@dataclass
class EdgeLocation:
    id: str
    region: str
    latitude: float
    longitude: float
    capacity: int  # Max concurrent inferences
    current_load: int = 0

@dataclass
class ModelConfig:
    model_id: str
    model_type: ModelType
    version: str
    input_shape: List[int]
    output_shape: List[int]
    framework: str  # tensorflow, pytorch, onnx, etc.
    memory_mb: int
    latency_ms_target: int
    endpoint: Optional[str] = None

@dataclass
class InferenceRequest:
    request_id: str
    model_id: str
    input_data: Union[List[float], Dict[str, Any]]
    priority: int = 1
    timeout_ms: int = 5000

@dataclass
class InferenceResult:
    request_id: str
    output_data: Any
    latency_ms: float
    edge_location: str
    confidence: Optional[float] = None
    error: Optional[str] = None

class EdgeComputing:
    """Edge computing system for model inference at CDN edge locations"""

    def __init__(self):
        self.edge_locations: Dict[str, EdgeLocation] = {}
        self.deployed_models: Dict[str, Dict[str, ModelConfig]] = {}  # location -> model_id -> config
        self.model_registry: Dict[str, ModelConfig] = {}
        self.model_handlers: Dict[str, Callable[[Any], Any]] = {}
        self._engines: Dict[str, Any] = {}
        self._onnx_sessions: Dict[str, Any] = {}
        self._torch_models: Dict[str, Any] = {}
        self.inference_queue: asyncio.Queue = asyncio.Queue()
        self.results_cache: Dict[str, InferenceResult] = {}
        self._running = False
        self._workers: List[asyncio.Task] = []

    async def start(self) -> None:
        """Start the edge computing system"""
        self._running = True

        # Start inference workers
        for i in range(10):  # 10 concurrent workers
            worker = asyncio.create_task(self._inference_worker())
            self._workers.append(worker)

        logger.info("Edge computing system started")

    async def stop(self) -> None:
        """Stop the edge computing system"""
        self._running = False

        # Cancel workers
        for worker in self._workers:
            worker.cancel()

        await asyncio.gather(*self._workers, return_exceptions=True)
        logger.info("Edge computing system stopped")

    async def add_edge_location(self, location: EdgeLocation) -> bool:
        """Add an edge location"""
        if location.id in self.edge_locations:
            return False

        self.edge_locations[location.id] = location
        self.deployed_models[location.id] = {}
        logger.info(f"Added edge location: {location.id} in {location.region}")
        return True

    async def deploy_model(self, model_config: ModelConfig, locations: List[str]) -> bool:
        """Deploy model to specified edge locations"""
        if model_config.model_id in self.model_registry:
            logger.warning(f"Model {model_config.model_id} already registered")
            return False

        self.model_registry[model_config.model_id] = model_config

        success_count = 0
        for location_id in locations:
            if location_id in self.edge_locations:
                self.deployed_models[location_id][model_config.model_id] = model_config
                success_count += 1
                logger.info(f"Deployed model {model_config.model_id} to {location_id}")

        return success_count > 0

    def register_model_handler(self, model_id: str, handler: Callable[[Any], Any]) -> None:
        """Register a custom inference handler for a model."""
        self.model_handlers[model_id] = handler

    async def register_models_from_catalog(self, catalog: List[Dict[str, Any]],
                                           locations: Optional[List[str]] = None) -> int:
        """Register models from a catalog payload."""
        registered = 0
        for entry in catalog:
            model_id = entry.get("model_id") or entry.get("id") or entry.get("name")
            if not model_id:
                continue

            model_type_raw = entry.get("model_type") or entry.get("task") or "nlp"
            try:
                model_type = ModelType(model_type_raw)
            except Exception:
                model_type = ModelType.NLP

            endpoint = entry.get("endpoint") or entry.get("inference_endpoint")
            framework = entry.get("framework") or ("http" if endpoint else "pytorch")

            config = ModelConfig(
                model_id=model_id,
                model_type=model_type,
                version=str(entry.get("version") or "latest"),
                input_shape=entry.get("input_shape") or [],
                output_shape=entry.get("output_shape") or [],
                framework=framework,
                memory_mb=int(entry.get("memory_mb") or 0),
                latency_ms_target=int(entry.get("latency_ms_target") or 0),
                endpoint=endpoint
            )

            if model_id not in self.model_registry:
                self.model_registry[model_id] = config
                registered += 1
            else:
                self.model_registry[model_id] = config

            target_locations = locations or list(self.edge_locations.keys())
            for location_id in target_locations:
                if location_id in self.edge_locations:
                    self.deployed_models.setdefault(location_id, {})[model_id] = config

        return registered

    async def sync_model_catalog_from_url(self, url: str, auth_token: Optional[str] = None,
                                          locations: Optional[List[str]] = None) -> int:
        """Fetch a model catalog from URL and register models."""
        headers = {}
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"

        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, timeout=15) as response:
                if response.status != 200:
                    raise RuntimeError(f"Catalog fetch failed: {response.status}")
                payload = await response.json()

        catalog = payload.get("data") if isinstance(payload, dict) else None
        if catalog is None and isinstance(payload, list):
            catalog = payload
        if catalog is None:
            catalog = []

        return await self.register_models_from_catalog(catalog, locations)

    async def run_inference(self, request: InferenceRequest,
                          preferred_location: Optional[str] = None) -> Optional[InferenceResult]:
        """Run inference on the edge"""
        if not self._running:
            return None

        # Find optimal edge location
        location_id = self._select_edge_location(request.model_id, preferred_location)

        if not location_id:
            result = InferenceResult(
                request_id=request.request_id,
                output_data=None,
                latency_ms=0,
                edge_location="",
                error="No suitable edge location found"
            )
            return result

        # Check if location has capacity
        location = self.edge_locations[location_id]
        if location.current_load >= location.capacity:
            result = InferenceResult(
                request_id=request.request_id,
                output_data=None,
                latency_ms=0,
                edge_location=location_id,
                error="Edge location at capacity"
            )
            return result

        # Increment load
        location.current_load += 1

        try:
            # Queue the inference
            future = asyncio.Future()
            await self.inference_queue.put((request, location_id, future))

            # Wait for result with timeout
            try:
                result = await asyncio.wait_for(future, timeout=request.timeout_ms / 1000)
                return result
            except asyncio.TimeoutError:
                return InferenceResult(
                    request_id=request.request_id,
                    output_data=None,
                    latency_ms=request.timeout_ms,
                    edge_location=location_id,
                    error="Inference timeout"
                )

        finally:
            # Decrement load
            location.current_load -= 1

    async def get_inference_result(self, request_id: str) -> Optional[InferenceResult]:
        """Get cached inference result"""
        return self.results_cache.get(request_id)

    async def get_edge_metrics(self) -> Dict[str, Any]:
        """Get edge computing metrics"""
        total_locations = len(self.edge_locations)
        total_deployed_models = sum(len(models) for models in self.deployed_models.values())
        total_load = sum(loc.current_load for loc in self.edge_locations.values())
        total_capacity = sum(loc.capacity for loc in self.edge_locations.values())

        location_metrics = {}
        for loc_id, location in self.edge_locations.items():
            location_metrics[loc_id] = {
                'region': location.region,
                'current_load': location.current_load,
                'capacity': location.capacity,
                'utilization': location.current_load / location.capacity if location.capacity > 0 else 0,
                'deployed_models': list(self.deployed_models[loc_id].keys())
            }

        return {
            'total_edge_locations': total_locations,
            'total_deployed_models': total_deployed_models,
            'total_load': total_load,
            'total_capacity': total_capacity,
            'overall_utilization': total_load / total_capacity if total_capacity > 0 else 0,
            'location_metrics': location_metrics
        }

    def _select_edge_location(self, model_id: str, preferred_location: Optional[str] = None) -> Optional[str]:
        """Select optimal edge location for inference"""
        if preferred_location and preferred_location in self.edge_locations:
            if model_id in self.deployed_models.get(preferred_location, {}):
                return preferred_location

        # Find locations with the model deployed and available capacity
        available_locations = []
        for loc_id, models in self.deployed_models.items():
            if model_id in models:
                location = self.edge_locations[loc_id]
                if location.current_load < location.capacity:
                    available_locations.append((loc_id, location.current_load))

        if not available_locations:
            return None

        # Select location with lowest load
        available_locations.sort(key=lambda x: x[1])
        return available_locations[0][0]

    async def _inference_worker(self) -> None:
        """Background worker for processing inference requests"""
        while self._running:
            try:
                request, location_id, future = await self.inference_queue.get()

                start_time = time.time()
                result = await self._execute_inference(request, location_id)
                latency_ms = (time.time() - start_time) * 1000

                result.latency_ms = latency_ms
                result.edge_location = location_id

                # Cache result
                self.results_cache[request.request_id] = result

                # Set future result
                if not future.done():
                    future.set_result(result)

                self.inference_queue.task_done()

            except Exception as e:
                logger.error(f"Inference worker error: {e}")
                await asyncio.sleep(0.1)

    async def _execute_inference(self, request: InferenceRequest, location_id: str) -> InferenceResult:
        """Execute the actual inference."""
        model_config = self.model_registry.get(request.model_id)

        if not model_config:
            return InferenceResult(
                request_id=request.request_id,
                output_data=None,
                latency_ms=0,
                edge_location=location_id,
                error=f"Model {request.model_id} not found"
            )

        try:
            output = await self._run_model_inference(model_config, request.input_data)
            return InferenceResult(
                request_id=request.request_id,
                output_data=output,
                latency_ms=0,  # Will be set by worker
                edge_location=location_id,
                confidence=None
            )

        except Exception as e:
            return InferenceResult(
                request_id=request.request_id,
                output_data=None,
                latency_ms=0,
                edge_location=location_id,
                error=str(e)
            )

    async def _run_model_inference(self, model_config: ModelConfig, input_data: Any) -> Any:
        """Run model inference using registered handlers or supported runtimes."""
        handler = self.model_handlers.get(model_config.model_id)
        if handler:
            if asyncio.iscoroutinefunction(handler):
                return await handler(input_data)
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, handler, input_data)

        if model_config.model_type == ModelType.NLP:
            try:
                from ailoos.inference.engine import InferenceEngine
            except Exception as e:
                raise RuntimeError(f"InferenceEngine unavailable: {e}") from e

            engine = self._engines.get(model_config.model_id)
            if not engine:
                engine = InferenceEngine(model_path=model_config.model_id)
                engine.load_model()
                self._engines[model_config.model_id] = engine

            prompt = input_data
            if isinstance(input_data, dict):
                prompt = input_data.get("prompt") or input_data.get("text") or ""
            if not isinstance(prompt, str):
                prompt = json.dumps(prompt)

            output_text = ""
            async for token in engine.generate(prompt, max_new_tokens=64):
                output_text += token
            return {"text": output_text}

        if model_config.framework.lower() == "onnx":
            try:
                import onnxruntime as ort
            except Exception as e:
                raise RuntimeError(f"onnxruntime unavailable: {e}") from e

            session = self._onnx_sessions.get(model_config.model_id)
            if not session:
                session = ort.InferenceSession(model_config.model_id)
                self._onnx_sessions[model_config.model_id] = session

            if isinstance(input_data, dict):
                input_feed = {k: np.asarray(v) for k, v in input_data.items()}
            else:
                input_name = session.get_inputs()[0].name
                input_feed = {input_name: np.asarray(input_data)}

            outputs = session.run(None, input_feed)
            return outputs

        if model_config.framework.lower() == "pytorch":
            try:
                import torch
            except Exception as e:
                raise RuntimeError(f"torch unavailable: {e}") from e

            model = self._torch_models.get(model_config.model_id)
            if not model:
                model = torch.jit.load(model_config.model_id)
                model.eval()
                self._torch_models[model_config.model_id] = model

            with torch.no_grad():
                if isinstance(input_data, dict):
                    tensor_inputs = {k: torch.tensor(v) for k, v in input_data.items()}
                    output = model(**tensor_inputs)
                else:
                    tensor = torch.tensor(input_data)
                    output = model(tensor)
            return output

        if model_config.framework.lower() in ("http", "remote") and model_config.endpoint:
            async with aiohttp.ClientSession() as session:
                async with session.post(model_config.endpoint, json={"input": input_data}) as response:
                    if response.status != 200:
                        raise RuntimeError(f"Remote inference failed: {response.status}")
                    return await response.json()

        raise RuntimeError(f"No inference handler registered for model {model_config.model_id}")
