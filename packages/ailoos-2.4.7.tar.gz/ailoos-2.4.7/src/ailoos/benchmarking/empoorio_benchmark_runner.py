"""
EmpoorioLM Unified Benchmark Runner
===================================
Orquestador principal de benchmarks para EmpoorioLM.
Unifica métricas de latencia, calidad (vs Gigantes) y rendimiento de red.
"""

import asyncio
import os
import sys
import json
import logging
import time
from datetime import datetime
from typing import Dict, List, Any, Optional

# Añadir src al path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))

from ailoos.coordinator.empoorio_lm.service import EmpoorioLMService, EmpoorioLMServiceConfig
from ailoos.benchmarking.latency_tester import LatencyTester, LatencyTestConfig
from ailoos.benchmarking.real_vs_giants import GiantsBenchmarkRunner
from ailoos.inference.api import EmpoorioLMInferenceAPI, InferenceConfig

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("EmpoorioBenchmark")

class EmpoorioServiceWrapper:
    """Wrapper para adaptar EmpoorioLMService a la interfaz de LatencyTester."""
    def __init__(self, service: EmpoorioLMService):
        self.service = service

    def generate(self, prompt, max_tokens=256, temperature=0.7):
        # EmpoorioLMService.generate_text es async, pero LatencyTester usa ThreadPoolExecutor
        # Necesitamos un bridge síncrono o adaptar LatencyTester (que es síncrono por diseño de threads)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(self.service.generate_text(
                prompt, 
                max_tokens=max_tokens, 
                temperature=temperature
            ))
            if result:
                return result["generated_text"], {"tokens_generated": result["tokens_generated"]}
            return "", {"tokens_generated": 0}
        finally:
            loop.close()

    def generate_stream(self, prompt, max_tokens=256, temperature=0.7):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            stream_gen = loop.run_until_complete(self.service.stream_generate_text(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature
            ))
            # Convertir async generator a sync generator para LatencyTester
            for chunk in self._sync_generator(stream_gen):
                yield chunk
        finally:
            loop.close()

    def _sync_generator(self, async_gen):
        loop = asyncio.get_event_loop()
        try:
            while True:
                try:
                    yield loop.run_until_complete(async_gen.__anext__())
                except StopAsyncIteration:
                    break
        except Exception as e:
            logger.error(f"Error en stream sync wrapper: {e}")

class EmpoorioBenchmarkRunner:
    def __init__(self, output_dir: str = "./benchmarks/results"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        self.service = None
        self.giants_runner = GiantsBenchmarkRunner()

    async def initialize(self):
        logger.info("Initializing EmpoorioLM Service for benchmarks...")
        config = EmpoorioLMServiceConfig(
            service_name="benchmark_service",
            auto_initialize_base_model=True,
            default_model_version="v1.0.0-trained"
        )
        self.service = EmpoorioLMService(config)
        await self.service.initialize()
        await self.service.start()
        
        # Inicializar runners externos
        await self.giants_runner.initialize()
        logger.info("Benchmarks initialized.")

    async def run_full_baseline(self):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report = {
            "timestamp": timestamp,
            "version": "1.0.0",
            "categories": {}
        }

        # 1. Latency & Throughput Baseline
        logger.info("Running Latency & Throughput baseline...")
        latency_config = LatencyTestConfig(
            num_requests=20,
            context_sizes=[512, 1024, 2048],
            batch_sizes=[1],
            output_dir=os.path.join(self.output_dir, f"latency_{timestamp}")
        )
        tester = LatencyTester(latency_config)
        wrapper = EmpoorioServiceWrapper(self.service)
        
        latency_results = tester.run_latency_tests(wrapper, "empoorio_lm_baseline")
        report["categories"]["performance"] = self._format_latency_results(latency_results)

        # 2. Quality vs Giants (Reasoning, Coding)
        logger.info("Running Quality vs Giants baseline...")
        reasoning_summary = await self.giants_runner.run_benchmark_suite("reasoning")
        coding_summary = await self.giants_runner.run_benchmark_suite("coding")
        
        report["categories"]["quality"] = {
            "reasoning": reasoning_summary["model_summaries"].get("empoorio_lm", {}),
            "coding": coding_summary["model_summaries"].get("empoorio_lm", {})
        }

        # 3. Export Report
        report_path = os.path.join(self.output_dir, f"baseline_report_{timestamp}.json")
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        self.generate_markdown_report(report, timestamp)
        logger.info(f"Baseline report generated: {report_path}")

    def _format_latency_results(self, results):
        formatted = {}
        for key, metrics in results.items():
            formatted[key] = {
                "avg_latency": metrics.avg_latency,
                "p95_latency": metrics.p95_latency,
                "avg_ttft": metrics.avg_time_to_first_token,
                "avg_throughput": metrics.avg_throughput
            }
        return formatted

    def generate_markdown_report(self, report, timestamp):
        md_path = os.path.join(self.output_dir, f"baseline_report_{timestamp}.md")
        perf = report["categories"]["performance"]
        quality = report["categories"]["quality"]
        
        with open(md_path, 'w') as f:
            f.write(f"# 🚀 EmpoorioLM Baseline Performance Report ({timestamp})\n\n")
            
            f.write("## ⚡ Latency & Throughput\n\n")
            f.write("| Config | Avg Latency (s) | P95 Latency (s) | TTFT (s) | Throughput (tok/s) |\n")
            f.write("|---|---|---|---|---|\n")
            for cfg, m in perf.items():
                f.write(f"| {cfg} | {m['avg_latency']:.3f} | {m['p95_latency']:.3f} | {m['avg_ttft']:.3f} | {m['avg_throughput']:.1f} |\n")
            
            f.write("\n## 🧠 Quality vs Giants (Scores 0-1)\n\n")
            f.write("| Category | Score | Avg Response Time |\n")
            f.write("|---|---|---|\n")
            f.write(f"| Reasoning | {quality['reasoning'].get('average_score', 0):.2f} | {quality['reasoning'].get('average_response_time', 0):.2f}s |\n")
            f.write(f"| Coding | {quality['coding'].get('average_score', 0):.2f} | {quality['coding'].get('average_response_time', 0):.2f}s |\n")
            
        logger.info(f"Markdown report generated: {md_path}")

async def main():
    runner = EmpoorioBenchmarkRunner()
    await runner.initialize()
    await runner.run_full_baseline()

if __name__ == "__main__":
    asyncio.run(main())
