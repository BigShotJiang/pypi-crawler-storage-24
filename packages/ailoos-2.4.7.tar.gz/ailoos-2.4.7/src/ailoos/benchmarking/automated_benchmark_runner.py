import json
import logging
import os
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import psutil

    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    import numpy as np
except ImportError:
    np = None

# Transformers / Torch / Evaluate are required for production benchmarking.
try:
    import torch
    from transformers import (
        AutoModelForCausalLM,
        AutoTokenizer,
        PreTrainedModel,
        PreTrainedTokenizerBase,
    )
except ImportError as e:
    raise ImportError(
        "Missing required dependencies. Install with: pip install torch transformers"
    ) from e

try:
    import evaluate
except ImportError as e:
    raise ImportError(
        "Missing required dependency 'evaluate'. Install with: pip install evaluate"
    ) from e

try:
    from datasets import load_dataset

    DATASETS_AVAILABLE = True
except ImportError:
    DATASETS_AVAILABLE = False


@dataclass
class BenchmarkConfig:
    model_name: str
    datasets: List[str]
    metrics: List[str]
    batch_size: int = 8
    max_length: int = 512
    num_samples: Optional[int] = None
    seed: int = 42
    device: str = "auto"  # auto | cpu | cuda


@dataclass
class BenchmarkResult:
    dataset: str
    metric: str
    score: float
    execution_time: float
    metadata: Dict[str, Any]


class AutomatedBenchmarkRunner:
    """
    Ejecutor automático de benchmarks estandarizados para modelos de lenguaje.

    - Carga datasets reales vía `datasets` (HuggingFace Datasets) si está disponible.
    - Calcula métricas reales (perplexity, rouge*, accuracy exact-match) y métricas de `evaluate`.
    - Incluye medición básica de latencia y delta de recursos (CPU / RAM) cuando psutil está disponible.

    Requisitos:
    - torch
    - transformers
    - evaluate
    - (opcional) datasets
    - (opcional) psutil
    """

    def __init__(self, config: BenchmarkConfig, log_level: str = "INFO"):
        self.config = config

        # Create results dir BEFORE logger setup (logger writes to it).
        self.results_dir = Path("benchmark_results")
        self.results_dir.mkdir(exist_ok=True)

        self.logger = self._setup_logger(log_level)

        # Reproducibility
        self._set_seed(config.seed)

        self.model: Optional[PreTrainedModel] = None
        self.tokenizer: Optional[PreTrainedTokenizerBase] = None
        self._device = self._resolve_device(config.device)

    def _setup_logger(self, log_level: str) -> logging.Logger:
        logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

        # Avoid duplicate handlers when re-instantiating in notebooks/tests.
        if logger.handlers:
            return logger

        file_handler = logging.FileHandler(self.results_dir / "benchmark_runner.log")
        console_handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        return logger

    def _set_seed(self, seed: int) -> None:
        random.seed(seed)
        if np is not None:
            np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    def _resolve_device(self, device: str) -> torch.device:
        device = (device or "auto").lower().strip()
        if device == "cpu":
            return torch.device("cpu")
        if device == "cuda":
            if not torch.cuda.is_available():
                raise RuntimeError("device='cuda' requested but CUDA is not available")
            return torch.device("cuda")
        # auto
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def load_model(self) -> None:
        """Carga el modelo y tokenizer especificados en la configuración."""
        try:
            self.logger.info("Loading model: %s", self.config.model_name)

            self.tokenizer = AutoTokenizer.from_pretrained(
                self.config.model_name, use_fast=True
            )
            self.model = AutoModelForCausalLM.from_pretrained(
                self.config.model_name,
                torch_dtype=(torch.float16 if self._device.type == "cuda" else None),
            )
            self.model.to(self._device)
            self.model.eval()

            # Ensure pad token exists
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token

            # Make generation deterministic-ish (benchmark consistency)
            # NOTE: Users can override via env vars if desired.
            if os.getenv("AILOOS_DETERMINISTIC", "1") == "1":
                torch.use_deterministic_algorithms(False)  # safer default for HF

            self.logger.info("Model loaded successfully on %s", self._device)
        except Exception as e:
            self.logger.exception("Failed to load model")
            raise

    def run_benchmarks(self) -> List[BenchmarkResult]:
        """Ejecuta todos los benchmarks configurados y devuelve los resultados."""
        if self.model is None or self.tokenizer is None:
            self.load_model()

        results: List[BenchmarkResult] = []
        self.logger.info("Starting benchmark execution")

        for dataset_name in self.config.datasets:
            self.logger.info("Running benchmarks for dataset: %s", dataset_name)
            dataset_results = self._run_dataset_benchmarks(dataset_name)
            results.extend(dataset_results)

        self._save_results(results)
        self.logger.info("Benchmark execution completed")
        return results

    # -------------------------
    # Dataset loading
    # -------------------------

    def _load_dataset_records(self, dataset_name: str) -> List[Dict[str, Any]]:
        """Loads a dataset into a list of dict records.

        Supported dataset_name formats:
        - "repo" (e.g., "wikitext") -> tries split="test" then "validation" then "train"
        - "repo:config" (e.g., "wikitext:wikitext-2-raw-v1")
        - "repo:config:split" (e.g., "wikitext:wikitext-2-raw-v1:test")

        Requires `datasets`. If unavailable, strict production mode will raise.
        """
        strict = os.getenv("AILOOS_PRODUCTION_STRICT", "0") == "1"
        if not DATASETS_AVAILABLE:
            if strict:
                raise RuntimeError(
                    "Strict production: 'datasets' not installed. Install with: pip install datasets"
                )
            self.logger.warning(
                "datasets not installed; cannot load real datasets. Returning empty dataset for %s",
                dataset_name,
            )
            return []

        parts = dataset_name.split(":")
        repo = parts[0]
        config = parts[1] if len(parts) >= 2 and parts[1] else None
        split = parts[2] if len(parts) >= 3 and parts[2] else None

        split_candidates = [split] if split else ["test", "validation", "train"]

        last_err: Optional[Exception] = None
        for sp in split_candidates:
            try:
                ds = load_dataset(repo, config, split=sp) if config else load_dataset(repo, split=sp)
                if self.config.num_samples is not None:
                    n = min(int(self.config.num_samples), len(ds))
                    ds = ds.select(range(n))
                # Convert to plain python dicts
                return [dict(r) for r in ds]
            except Exception as e:
                last_err = e
                continue

        if strict:
            raise RuntimeError(
                f"Strict production: failed to load dataset '{dataset_name}'. Last error: {last_err}"
            )
        self.logger.error(
            "Failed to load dataset %s (last error: %s)", dataset_name, last_err
        )
        return []

    def _extract_text_and_reference(self, record: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
        """Best-effort extraction of input text and reference/label.

        Input text candidate keys: text, prompt, input, question, content.
        Reference candidate keys: reference, summary, answer, label, target.

        Returns (text, reference). Either may be None.
        """
        text_keys = ["text", "prompt", "input", "question", "content"]
        ref_keys = ["reference", "summary", "answer", "label", "target"]

        text = None
        for k in text_keys:
            v = record.get(k)
            if isinstance(v, str) and v.strip():
                text = v
                break

        reference = None
        for k in ref_keys:
            v = record.get(k)
            if isinstance(v, str) and v.strip():
                reference = v
                break

        return text, reference

    # -------------------------
    # Benchmark execution
    # -------------------------

    def _run_dataset_benchmarks(self, dataset_name: str) -> List[BenchmarkResult]:
        results: List[BenchmarkResult] = []

        dataset_records = self._load_dataset_records(dataset_name)
        if not dataset_records:
            self.logger.warning("Dataset %s is empty; skipping.", dataset_name)
            return results

        # Build normalized samples with required fields
        samples: List[Dict[str, Any]] = []
        for r in dataset_records:
            text, reference = self._extract_text_and_reference(r)
            if text is None:
                continue
            samples.append({"text": text, "reference": reference})

        if not samples:
            self.logger.warning(
                "Dataset %s has no usable 'text/prompt/input' fields; skipping.",
                dataset_name,
            )
            return results

        for metric_name in self.config.metrics:
            self.logger.info("Computing metric: %s on %s", metric_name, dataset_name)

            memory_usage: List[float] = []
            cpu_usage: List[float] = []
            latencies: List[float] = []

            try:
                start_time = time.perf_counter()

                if metric_name == "latency":
                    for s in samples:
                        t0 = time.perf_counter()
                        _ = self._generate([s["text"]], max_new_tokens=32)
                        latencies.append(time.perf_counter() - t0)
                    score = float(sum(latencies) / max(1, len(latencies)))
                else:
                    process = psutil.Process() if PSUTIL_AVAILABLE else None

                    cpu_start = 0.0
                    mem_start_mb = 0.0
                    if process is not None:
                        # cpu_percent needs an initial call to establish baseline
                        process.cpu_percent(interval=None)
                        cpu_start = process.cpu_percent(interval=0.1)
                        mem_start_mb = process.memory_info().rss / 1024 / 1024

                    score = self._compute_metric(samples, metric_name)

                    if process is not None:
                        cpu_end = process.cpu_percent(interval=0.1)
                        mem_end_mb = process.memory_info().rss / 1024 / 1024
                        cpu_usage.append(max(0.0, cpu_end - cpu_start))
                        memory_usage.append(max(0.0, mem_end_mb - mem_start_mb))

                total_time = time.perf_counter() - start_time

                stats: Dict[str, Any] = {"mean": float(score), "total_time": float(total_time)}

                if latencies and np is not None:
                    stats.update(
                        {
                            "p50": float(np.percentile(latencies, 50)),
                            "p95": float(np.percentile(latencies, 95)),
                            "p99": float(np.percentile(latencies, 99)),
                            "std_dev": float(np.std(latencies)),
                        }
                    )

                if PSUTIL_AVAILABLE:
                    stats["avg_cpu_delta"] = float(sum(cpu_usage) / len(cpu_usage)) if cpu_usage else 0.0
                    stats["avg_mem_delta_mb"] = float(sum(memory_usage) / len(memory_usage)) if memory_usage else 0.0

                result = BenchmarkResult(
                    dataset=dataset_name,
                    metric=metric_name,
                    score=float(score),
                    execution_time=float(total_time),
                    metadata={
                        "model": self.config.model_name,
                        "num_samples": len(samples),
                        "stats": stats,
                        "config": self.config.__dict__,
                        "device": str(self._device),
                    },
                )
                results.append(result)
                self.logger.info(
                    "Metric %s: %.6f (time: %.2fs)", metric_name, float(score), float(total_time)
                )

            except Exception as e:
                strict = os.getenv("AILOOS_PRODUCTION_STRICT", "0") == "1"
                if strict:
                    raise
                self.logger.error("Failed to compute metric %s: %s", metric_name, e)
                continue

        return results

    # -------------------------
    # Generation helpers
    # -------------------------

    def _generate(self, prompts: List[str], max_new_tokens: int = 64) -> List[str]:
        """Batch text generation using the loaded model (no pipeline).

        Returns generated continuations INCLUDING the prompt text.
        """
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("Model/tokenizer not loaded")

        tok = self.tokenizer(
            prompts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=self.config.max_length,
        )
        tok = {k: v.to(self._device) for k, v in tok.items()}

        with torch.no_grad():
            out = self.model.generate(
                **tok,
                max_new_tokens=int(max_new_tokens),
                do_sample=False,
                num_beams=1,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )

        texts = self.tokenizer.batch_decode(out, skip_special_tokens=True)
        return texts

    def _batched(self, items: List[Dict[str, Any]], batch_size: int) -> Iterable[List[Dict[str, Any]]]:
        for i in range(0, len(items), batch_size):
            yield items[i : i + batch_size]

    # -------------------------
    # Metric computations
    # -------------------------

    def _compute_metric(self, dataset: List[Dict[str, Any]], metric_name: str) -> float:
        """Computa una métrica específica en el dataset."""
        metric_name = (metric_name or "").strip().lower()

        if metric_name == "perplexity":
            return self._compute_perplexity(dataset)
        if metric_name == "accuracy":
            return self._compute_accuracy(dataset)
        if metric_name.startswith("rouge"):
            return self._compute_rouge(dataset, metric_name)

        # Evaluate library for other metrics
        metric = evaluate.load(metric_name)
        predictions: List[str] = []
        references: List[str] = []

        for batch in self._batched(dataset, self.config.batch_size):
            prompts = [b["text"] for b in batch]
            gens = self._generate(prompts, max_new_tokens=64)
            predictions.extend(gens)
            for b, g in zip(batch, gens):
                ref = b.get("reference")
                if isinstance(ref, str) and ref.strip():
                    references.append(ref)
                else:
                    # If no reference, fall back to prompt (metric might still run for some tasks)
                    references.append(b["text"])

        computed = metric.compute(predictions=predictions, references=references)
        # Some metrics return dicts with different keys; best effort.
        if metric_name in computed and isinstance(computed[metric_name], (int, float)):
            return float(computed[metric_name])
        # Common alternative: single key in dict
        for v in computed.values():
            if isinstance(v, (int, float)):
                return float(v)
        raise RuntimeError(f"Metric '{metric_name}' returned no numeric result: {computed}")

    def _compute_perplexity(self, dataset: List[Dict[str, Any]]) -> float:
        """Computa perplexity usando cross-entropy sobre el texto de entrada."""
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("Model/tokenizer not loaded")

        losses: List[float] = []
        for batch in self._batched(dataset, self.config.batch_size):
            texts = [b["text"] for b in batch]
            inputs = self.tokenizer(
                texts,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=self.config.max_length,
            )
            inputs = {k: v.to(self._device) for k, v in inputs.items()}

            # labels = input_ids; ignore padding tokens
            labels = inputs["input_ids"].clone()
            labels[labels == self.tokenizer.pad_token_id] = -100

            with torch.no_grad():
                outputs = self.model(**inputs, labels=labels)
                loss = outputs.loss
                losses.append(float(loss.item()))

        if not losses:
            return float("inf")
        mean_loss = sum(losses) / len(losses)
        return float(torch.exp(torch.tensor(mean_loss)).item())

    def _normalize_text(self, s: str) -> str:
        return " ".join(s.strip().split()).lower()

    def _compute_accuracy(self, dataset: List[Dict[str, Any]]) -> float:
        """Exact-match accuracy.

        Requires that at least some samples have a non-empty `reference`.
        We generate continuations and compare normalized generated text against normalized reference.

        Note: This is a generic LLM accuracy proxy for instruction/QA-style datasets.
        For classification-style accuracy, provide a dataset where the reference is the expected label text.
        """
        strict = os.getenv("AILOOS_PRODUCTION_STRICT", "0") == "1"

        labeled = [d for d in dataset if isinstance(d.get("reference"), str) and d["reference"].strip()]
        if not labeled:
            if strict:
                raise ValueError("Strict production: Accuracy requires labeled data with 'reference' field")
            self.logger.warning("Accuracy requested but dataset has no references; returning 0.0")
            return 0.0

        correct = 0
        total = 0

        for batch in self._batched(labeled, self.config.batch_size):
            prompts = [b["text"] for b in batch]
            gens = self._generate(prompts, max_new_tokens=64)

            for b, g in zip(batch, gens):
                ref = str(b.get("reference", ""))
                if not ref.strip():
                    continue
                total += 1
                if self._normalize_text(g).endswith(self._normalize_text(ref)) or self._normalize_text(g) == self._normalize_text(ref):
                    correct += 1

        return float(correct / total) if total else 0.0

    def _compute_rouge(self, dataset: List[Dict[str, Any]], metric_name: str) -> float:
        """Computa ROUGE scores via `evaluate`.

        Supported metric_name values:
        - rouge1, rouge2, rougel, rougelsum
        - rouge-1, rouge-2, rouge-l, rouge-lsum
        """
        strict = os.getenv("AILOOS_PRODUCTION_STRICT", "0") == "1"

        labeled = [d for d in dataset if isinstance(d.get("reference"), str) and d["reference"].strip()]
        if not labeled:
            if strict:
                raise ValueError("Strict production: ROUGE requires labeled data with 'reference' field")
            self.logger.warning("ROUGE requested but dataset has no references; returning 0.0")
            return 0.0

        rouge = evaluate.load("rouge")
        predictions: List[str] = []
        references: List[str] = []

        for batch in self._batched(labeled, self.config.batch_size):
            prompts = [b["text"] for b in batch]
            gens = self._generate(prompts, max_new_tokens=128)
            predictions.extend(gens)
            references.extend([b["reference"] for b in batch])

        results = rouge.compute(predictions=predictions, references=references)

        key = metric_name.replace("-", "")  # rouge-1 -> rouge1
        if key == "rouge":
            # Default to rougeL if ambiguous
            key = "rougeL"

        # Normalize to actual keys returned by evaluate (rouge1, rouge2, rougeL, rougeLsum)
        key_map = {
            "rouge1": "rouge1",
            "rouge2": "rouge2",
            "rougel": "rougeL",
            "rougelsum": "rougeLsum",
            "rougel": "rougeL",
            "rougelsum": "rougeLsum",
        }
        resolved = key_map.get(key, None)
        if resolved is None:
            # try direct
            resolved = key if key in results else None

        if resolved is None or resolved not in results:
            if strict:
                raise RuntimeError(f"ROUGE key '{metric_name}' not found in results: {results.keys()}")
            # fallback: return first numeric
            for v in results.values():
                if isinstance(v, (int, float)):
                    return float(v)
            return 0.0

        return float(results[resolved])

    # -------------------------
    # Persistence
    # -------------------------

    def _save_results(self, results: List[BenchmarkResult]) -> None:
        """Guarda los resultados en archivos JSON."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"benchmark_results_{timestamp}.json"
        filepath = self.results_dir / filename

        results_dict = {
            "config": self.config.__dict__,
            "timestamp": timestamp,
            "results": [result.__dict__ for result in results],
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(results_dict, f, indent=2, ensure_ascii=False, default=str)

        self.logger.info("Results saved to %s", filepath)