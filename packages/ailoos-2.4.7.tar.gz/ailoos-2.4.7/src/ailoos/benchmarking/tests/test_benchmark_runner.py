"""
Tests for EmpoorioLM Benchmark Runner
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, MagicMock
from ailoos.benchmarking.empoorio_benchmark_runner import EmpoorioBenchmarkRunner, EmpoorioServiceWrapper

class TestBenchmarkRunner:
    @pytest.fixture
    def mock_service(self):
        service = Mock()
        service.generate_text = asyncio.coroutine(lambda *args, **kwargs: {
            "generated_text": "Test response",
            "tokens_generated": 10
        })
        service.stream_generate_text = asyncio.coroutine(lambda *args, **kwargs: self.async_gen(["word1", "word2"]))
        return service

    async def async_gen(self, items):
        for item in items:
            yield item

    def test_service_wrapper_generate(self, mock_service):
        wrapper = EmpoorioServiceWrapper(mock_service)
        text, metrics = wrapper.generate("Hello")
        assert text == "Test response"
        assert metrics["tokens_generated"] == 10

    def test_service_wrapper_stream(self, mock_service):
        wrapper = EmpoorioServiceWrapper(mock_service)
        chunks = list(wrapper.generate_stream("Hello"))
        assert chunks == ["word1", "word2"]

    @pytest.mark.asyncio
    async def test_runner_initialization(self):
        with patch('src.ailoos.coordinator.empoorio_lm.service.EmpoorioLMService') as mock_service_class:
            mock_service_instance = mock_service_class.return_value
            mock_service_instance.initialize = asyncio.coroutine(lambda: True)
            mock_service_instance.start = asyncio.coroutine(lambda: True)
            
            runner = EmpoorioBenchmarkRunner(output_dir="/tmp/benchmark_test")
            await runner.initialize()
            
            assert runner.service is not None
            mock_service_instance.initialize.assert_called_once()
