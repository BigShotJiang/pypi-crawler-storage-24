"""
Nutrition Engine (PoN Core).
Analyzes data quality using Information Theory metrics.
"""

import math
import logging
import re
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class NutritionEngine:
    """
    Evaluates the 'Nutritional Value' of a dataset for AI training.
    Higher Score = Better Training Data = Higher Reward.
    """
    
    @staticmethod
    def calculate_nutrition_score(text: str) -> Dict[str, Any]:
        """
        Calculate a composite score for text data quality.
        """
        if not text or len(text.strip()) == 0:
            return {"score": 0.0, "reason": "Empty content"}
            
        # 1. Entropy (Information Density)
        entropy = NutritionEngine._calculate_entropy(text)
        
        # 2. Vocabulary Richness (Diversity)
        diversity = NutritionEngine._calculate_diversity(text)
        
        # 3. Junk Filters
        is_junk, junk_reason = NutritionEngine._is_junk(text)
        
        # Composite Score Formula
        # Entropy target: ~4.5 bits/char is standard English. 
        # Too low = simple repetition. Too high = random noise.
        entropy_score = 1.0 - abs(4.5 - entropy) / 4.5
        entropy_score = max(0.0, entropy_score)
        
        # Diversity target: > 0.1 ratio
        diversity_score = min(1.0, diversity * 5) # Scale up
        
        final_score = (entropy_score * 0.6) + (diversity_score * 0.4)
        
        if is_junk:
            final_score *= 0.1 # Heavily penalize junk
        
        classification = "Junk"
        if final_score > 0.8: classification = "Superfood (High Quality)"
        elif final_score > 0.5: classification = "Standard"
        elif final_score > 0.2: classification = "Low Quality"
            
        return {
            "score": round(final_score, 4),
            "entropy": round(entropy, 4),
            "diversity": round(diversity, 4),
            "is_junk": is_junk,
            "classification": classification,
            "reason": junk_reason if is_junk else "Valid Data"
        }

    @staticmethod
    def _calculate_entropy(text: str) -> float:
        """Shannon Entropy in bits."""
        prob = [float(text.count(c)) / len(text) for c in dict.fromkeys(list(text))]
        entropy = -sum([p * math.log(p) / math.log(2.0) for p in prob])
        return entropy

    @staticmethod
    def _calculate_diversity(text: str) -> float:
        """Ratio of unique words to total words."""
        words = re.findall(r'\w+', text.lower())
        if not words: return 0.0
        unique_words = set(words)
        return len(unique_words) / len(words)

    @staticmethod
    def _is_junk(text: str) -> (bool, str):
        """Detect repetitive spam patterns."""
        # Check for single char repetition "aaaaa"
        if len(text) > 50 and len(set(text)) < 5:
            return True, "Low Character Variety"
            
        # Check for word repetition "buy crypto buy crypto"
        words = re.findall(r'\w+', text.lower())
        if len(words) > 20:
            unique_ratio = len(set(words)) / len(words)
            if unique_ratio < 0.05:
                return True, "Massive Word Repetition"
                
        return False, None
