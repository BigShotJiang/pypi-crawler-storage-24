import logging
import os
import asyncio
import json
import hashlib
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
from datetime import datetime

# AILOOS SDK Imports
from ..p2p.dht.node import DHTNode
from ..data.dataset_manager import get_dataset_manager
from ..federated.trainer import FederatedTrainer
from ..core.config import get_config
from .storage import DataHubStorage
from ..data.registry import data_registry # Import Registry

logger = logging.getLogger(__name__)

@dataclass
class FederatedDiet:
    """Una 'dieta' (misión de entrenamiento) disponible en la red."""
    mission_id: str
    name: str
    description: str
    data_type: str  # 'text', 'code', 'science'
    reward_per_shard: float
    total_shards: int
    available_shards: List[str]  # Lista de CIDs
    source: str = "Network" # 'Network' or 'Local Refinery'
    coordinator_url: Optional[str] = None
    model_name: Optional[str] = None
    session_id: Optional[str] = None

class NutritionClient:
    """
    Cliente de Nutrición Federada.
    Se encarga de 'alimentar' al nodo descargando datos, entrenando y subiendo conocimientos.
    """

    def __init__(self, dht_node: Optional[DHTNode] = None):
        self.dht_node = dht_node
        self.dataset_manager = get_dataset_manager()
        self.config = get_config()
        self.active_training = False
        
        # Initialize Storage
        from pathlib import Path
        data_path = Path(os.getcwd()) / "data" / "datahub"
        self.storage = DataHubStorage(data_path)
        self._missions_key = os.getenv("AILOOS_DHT_MISSIONS_KEY", "active_missions")

    async def list_available_diets(self) -> List[FederatedDiet]:
        """
        Consulta la DHT (o caché local) para ver qué misiones de entrenamiento están activas.
        En producción real: await self.dht_node.get("active_missions")
        """
        diets = []
        # 1. Missions from DHT (real network)
        if self.dht_node:
            raw_missions = await self.dht_node.get(self._missions_key)
            if raw_missions:
                try:
                    missions_data = json.loads(raw_missions)
                except Exception as e:
                    logger.warning(f"Invalid DHT missions payload: {e}")
                    missions_data = []

                if isinstance(missions_data, dict):
                    missions_data = missions_data.get("missions", [])

                for data in missions_data or []:
                    shard_cids = data.get("shard_cids") or data.get("shards") or []
                    if not shard_cids:
                        continue
                    mission_id = data.get("mission_id") or data.get("id")
                    if not mission_id:
                        continue
                    diets.append(FederatedDiet(
                        mission_id=mission_id,
                        name=data.get("name", mission_id),
                        description=data.get("description", ""),
                        data_type=data.get("data_type", "text"),
                        reward_per_shard=float(data.get("reward_per_shard", data.get("reward", 0.0))),
                        total_shards=len(shard_cids),
                        available_shards=shard_cids,
                        source="Network",
                        coordinator_url=data.get("coordinator_url"),
                        model_name=data.get("model_name"),
                        session_id=data.get("session_id")
                    ))

        # 2. Missions from Local Registry (Refined Data)
        registered_datasets = data_registry.list_datasets(type_filter=None) # Get all
        for ds in registered_datasets:
            # Adapt Registry format to FederatedDiet
            diets.append(FederatedDiet(
                mission_id=ds['id'],
                name=f"🏭 {ds.get('name', 'Unnamed')}", # Add icon to distinguish
                description=f"Refined dataset ({ds.get('total_size_mb', 0):.1f}MB)",
                data_type=ds.get('original_type', 'text'),
                reward_per_shard=10.0, # Default local reward
                total_shards=ds.get('num_shards', 0),
                available_shards=ds.get('shard_cids', []),
                source="Local Factory" # Explicitly mark as local
            ))

        return diets

    def _select_shard(self, diet: FederatedDiet) -> str:
        """Selecciona un shard no consumido de forma determinista."""
        consumed = self.storage.metadata.get("consumed_shards", {})
        consumed_set = set(consumed.get(diet.mission_id, []))
        for cid in diet.available_shards:
            if cid not in consumed_set:
                return cid
        raise RuntimeError(f"No available shards left for mission {diet.mission_id}")

    def _mark_shard_consumed(self, diet: FederatedDiet, cid: str) -> None:
        consumed = self.storage.metadata.setdefault("consumed_shards", {})
        consumed.setdefault(diet.mission_id, [])
        if cid not in consumed[diet.mission_id]:
            consumed[diet.mission_id].append(cid)
        self.storage._save_metadata()

    async def consume_shard(self, diet: FederatedDiet) -> Dict[str, Any]:
        """
        Ejecuta el ciclo completo de nutrición:
        1. Selecciona un shard
        2. Descarga (Ingesta)
        3. Entrena (Digestión)
        4. Sube pesos (Sinapsis)
        5. Limpia (Digestión completa)
        """
        if self.active_training:
            raise RuntimeError("El nodo ya está 'digiriendo' un shard.")
        
        self.active_training = True
        try:
            # 1. Selección de Shard determinista (no aleatoria)
            target_cid = self._select_shard(diet)
            local_filename = f"shard_{target_cid[:8]}.json"
            
            # Use Inbox for temporary downloads
            local_path = self.storage.inbox_path / local_filename

            logger.info(f"🍽️ Iniciando banquete: {diet.name} -> {target_cid}")

            # 2. Ingesta (Descarga IPFS)
            logger.info("⬇️ Descargando ingredientes (Shard) de IPFS...")
            if not self.dataset_manager.download_shard(target_cid, local_path):
                raise RuntimeError(f"Failed to download shard from IPFS: {target_cid}")
            
            # 3. Digestión (Entrenamiento Local)
            logger.info(f"🧠 Digiriendo conocimiento (Entrenando {diet.data_type} en {target_cid})...")
            
            # PoN: ANALYZE DATA NUTRITION
            from .nutrition_engine import NutritionEngine
            nutrition_report = {"score": 0.5, "classification": "Unknown"}
            
            try:
                # Read sample content for analysis
                with open(local_path, 'r', errors='ignore') as f:
                    content_limit = f.read(5000) # Analyze first 5KB
                    if diet.data_type == 'text':
                         nutrition_report = NutritionEngine.calculate_nutrition_score(content_limit)
                    elif diet.data_type == 'code':
                         # Simple adapter for code (treat as text for now, but assume higher entropy density)
                         nutrition_report = NutritionEngine.calculate_nutrition_score(content_limit)
                
                logger.info(f"🍎 Nutrition Score: {nutrition_report['score']} ({nutrition_report['classification']})")
                
            except Exception as e:
                logger.error(f"⚠️ Failed to analyze nutrition: {e}")

            session_id = diet.session_id or diet.mission_id
            coordinator_url = diet.coordinator_url or os.getenv("AILOOS_COORDINATOR_URL")
            node_id = os.getenv("AILOOS_NODE_ID")
            model_name = diet.model_name or os.getenv("AILOOS_FEDERATED_MODEL_NAME", "Empoorio/EmpoorioLM-7B")

            if not coordinator_url:
                raise RuntimeError("AILOOS_COORDINATOR_URL is required for real nutrition flow")
            if not node_id:
                raise RuntimeError("AILOOS_NODE_ID is required for real nutrition flow")

            trainer = FederatedTrainer(
                session_id=session_id,
                model_name=model_name,
                dataset_name=diet.name,
                coordinator_url=coordinator_url,
                node_id=node_id,
                algorithm="fedavg"
            )
            
            if not await trainer.connect_to_coordinator_session():
                raise RuntimeError(f"Failed to connect to coordinator session {session_id}")

            # Entrenamiento REAL
            metrics = await trainer.train_on_local_data(str(local_path))
            loss_end = float(metrics.get("loss", 0.0))
            num_samples = int(metrics.get("samples", 0))
            weights = metrics.get("weights")
            if not weights:
                raise RuntimeError("Training produced no weights")

            # 4. Sinapsis (Envío real al coordinador)
            logger.info("📤 Enviando actualización real al coordinador...")
            submit_ok = await trainer.submit_training_update(
                model_weights=weights,
                num_samples=num_samples,
                accuracy=float(metrics.get("accuracy", 0.0)),
                loss=loss_end,
                metadata={
                    "nutrition_score": nutrition_report,
                    "shard_cid": target_cid,
                    "data_type": diet.data_type
                }
            )
            if not submit_ok:
                raise RuntimeError("Failed to submit training update to coordinator")
            
            # 5. Limpieza
            if os.path.exists(local_path):
                os.remove(local_path)
                logger.info("🧹 Limpiando plato (Shard borrado del disco)")

            self.active_training = False
            
            # Registrar shard consumido
            self._mark_shard_consumed(diet, target_cid)

            # Generar hash de operación (Proof of Nutrition)
            digest_source = f"{node_id}:{session_id}:{target_cid}:{loss_end}:{datetime.now().isoformat()}"
            tx_hash = hashlib.sha256(digest_source.encode("utf-8")).hexdigest()
            
            # Calculate Quality-Adjusted Reward
            base_reward = diet.reward_per_shard
            quality_multiplier = nutrition_report['score']
            final_reward = base_reward * quality_multiplier
            
            return {
                "status": "success",
                "diet_name": diet.name,
                "shard_cid": target_cid,
                "loss": loss_end,
                "reward_earned": round(final_reward, 2),
                "nutrition_score": nutrition_report,
                "tx_hash": tx_hash,
                "training_session": session_id
            }

        except Exception as e:
            self.active_training = False
            logger.error(f"🤮 Indigestión (Error en entrenamiento): {e}")
            raise e
