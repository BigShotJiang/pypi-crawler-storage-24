"""
Resilience & Fault Tolerance
============================

Implements stability patterns like Circuit Breaker and Retry logic.
Prevents cascading failures in distributed components.
"""

import asyncio
import logging
import random
import time
from enum import Enum
from typing import Callable, Any, Optional, TypeVar
from functools import wraps

logger = logging.getLogger(__name__)

class CircuitState(Enum):
    CLOSED = "CLOSED"     # Normal operation
    OPEN = "OPEN"         # Failing, rejecting requests
    HALF_OPEN = "HALF_OPEN" # Testing recovery

class CircuitBreakerOpenException(Exception):
    pass

class CircuitBreaker:
    """
    Circuit Breaker pattern implementation.
    """
    def __init__(self, 
                 name: str, 
                 failure_threshold: int = 5, 
                 recovery_timeout: float = 30.0,
                 reset_timeout: float = 60.0):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.reset_timeout = reset_timeout
        
        self._failures = 0
        self._state = CircuitState.CLOSED
        self._last_failure_time = 0.0
        self._lock = asyncio.Lock()
        
    async def call(self, func: Callable[..., Any], *args, **kwargs) -> Any:
        """Execute a function protected by the circuit breaker."""
        async with self._lock:
            if self._state == CircuitState.OPEN:
                if time.time() - self._last_failure_time > self.recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    logger.info(f"⚡ Circuit {self.name} entering HALF_OPEN state (probing)")
                else:
                    raise CircuitBreakerOpenException(f"Circuit {self.name} is OPEN")
                    
        try:
            result = await func(*args, **kwargs)

            # Success logic
            async with self._lock:
                if self._state == CircuitState.HALF_OPEN:
                    self._state = CircuitState.CLOSED
                    self._failures = 0
                    logger.info(f"✅ Circuit {self.name} closed again (recovered)")
                elif self._state == CircuitState.CLOSED:
                    self._failures = 0 # Reset consecutive failures on success

            return result

        except Exception as e:
            # Failure logic
            async with self._lock:
                self._failures += 1
                self._last_failure_time = time.time()

                if self._state == CircuitState.HALF_OPEN:
                    self._state = CircuitState.OPEN
                    logger.warning(f"❌ Circuit {self.name} probe failed. Re-opening.")

                elif self._failures >= self.failure_threshold:
                    if self._state == CircuitState.CLOSED:
                        self._state = CircuitState.OPEN
                        logger.critical(f"🔥 Circuit {self.name} OPENED after {self._failures} failures")

            raise e

class Retry:
    """
    Retry pattern implementation with exponential backoff and jitter.
    """
    def __init__(self,
                 max_retries: int = 3,
                 backoff_factor: float = 1.0,
                 jitter: bool = True,
                 max_backoff: float = 60.0):
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.jitter = jitter
        self.max_backoff = max_backoff

    async def call(self, func: Callable[..., Any], *args, **kwargs) -> Any:
        """Execute a function with retry logic."""
        last_exception = None
        for attempt in range(self.max_retries + 1):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                if attempt < self.max_retries:
                    delay = min(self.backoff_factor * (2 ** attempt), self.max_backoff)
                    if self.jitter:
                        delay += random.uniform(0, delay * 0.1)
                    logger.warning(f"Retry attempt {attempt + 1} failed, retrying in {delay:.2f}s: {e}")
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"All {self.max_retries + 1} attempts failed: {e}")
        raise last_exception

def retry(max_retries: int = 3, backoff_factor: float = 1.0, jitter: bool = True):
    """Decorator for async functions with retry logic."""
    retry_instance = Retry(max_retries, backoff_factor, jitter)
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            return await retry_instance.call(func, *args, **kwargs)
        return wrapper
    return decorator

def circuit_breaker(name: str, threshold: int = 5, recovery: float = 30.0):
    """Decorator for async functions."""
    breaker = CircuitBreaker(name, threshold, recovery)
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            return await breaker.call(func, *args, **kwargs)
        return wrapper
    return decorator
