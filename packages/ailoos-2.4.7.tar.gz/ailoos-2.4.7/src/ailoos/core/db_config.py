"""
Database Configuration Utility for AILOOS
Handles dynamic switching between local SQLite (Dev) and remote PostgreSQL (Prod).
"""

import os
from typing import Optional
import logging

logger = logging.getLogger(__name__)

def get_database_url(component_name: str = "general") -> str:
    """
    Returns the database URL for a given component.
    Priority:
    1. Environment Variable: AILOOS_{COMPONENT}_DATABASE_URL
    2. Environment Variable: AILOOS_DATABASE_URL
    3. Default: local SQLite in data/{component}.db
    """
    
    # Check for component-specific override
    env_component = f"AILOOS_{component_name.upper()}_DATABASE_URL"
    if os.getenv(env_component):
        logger.info(f"💾 Using component-specific database for {component_name}")
        return os.getenv(env_component)
        
    # Check for global production database (e.g. Postgres)
    if os.getenv("AILOOS_DATABASE_URL"):
        logger.info(f"🌐 Using global production database for {component_name}")
        return os.getenv("AILOOS_DATABASE_URL")
        
    # Default to SQLite
    data_dir = os.path.abspath(os.path.join(os.getcwd(), "data"))
    os.makedirs(data_dir, exist_ok=True)
    db_path = os.path.join(data_dir, f"{component_name}.db")
    
    # In strict production mode, detect missing DB as a failure
    if os.getenv("AILOOS_FORCE_PRODUCTION"):
         logger.warning(f"⚠️ Production Mode active but no remote DB URL found. Falling back to local: {db_path}")

    return f"sqlite:///{db_path}"

def is_production_db(url: str) -> bool:
    """Helper to check if the URL points to a production-grade DB."""
    return url.startswith("postgresql") or url.startswith("mysql")
