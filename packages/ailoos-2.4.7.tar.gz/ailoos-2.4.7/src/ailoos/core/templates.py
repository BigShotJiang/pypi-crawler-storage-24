"""
Data augmentation templates for Ailoos platform.
"""

from typing import List

def get_augmentation_templates(user_id: int) -> List[str]:
    """Get real data augmentation templates for a user."""
    # In a full implementation, these would be fetched from a database or template registry
    return [
        "Cuéntame más sobre tus proyectos actuales",
        "¿Cómo puedo optimizar mi flujo de trabajo hoy?",
        "Análisis de rendimiento para la sesión actual",
        "Resumen de mis preferencias de comunicación",
        "Generación de insights estratégicos basados en mi perfil"
    ]
