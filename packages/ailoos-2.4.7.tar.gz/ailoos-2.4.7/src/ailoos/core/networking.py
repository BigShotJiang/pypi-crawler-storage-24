"""
Networking Core - Global Connection Pooling
===========================================

Centralized HTTP session management to improve throughput and reduce handshake overhead.
"""

import aiohttp
import asyncio
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class SharedSessionManager:
    """
    Singleton connection pool for the entire application.
    Reuses TCP connections across different clients (Federated, P2P, DataHub).
    """
    _instance: Optional['SharedSessionManager'] = None
    _session: Optional[aiohttp.ClientSession] = None
    _lock = asyncio.Lock()

    @classmethod
    async def get_instance(cls):
        if not cls._instance:
            async with cls._lock:
                if not cls._instance:
                    cls._instance = SharedSessionManager()
        return cls._instance

    @classmethod
    async def get_session(cls) -> aiohttp.ClientSession:
        """
        Get the shared aiohttp ClientSession.
        If it doesn't exist or is closed, create a new one.
        """
        if cls._session is None or cls._session.closed:
            async with cls._lock:
                if cls._session is None or cls._session.closed:
                    logger.info("🔌 Initializing Global HTTP Connection Pool")
                    # High performance configuration
                    connector = aiohttp.TCPConnector(
                        limit=100,              # Total max connections
                        limit_per_host=20,      # Max connections per host
                        ttl_dns_cache=300,      # DNS caching
                        use_dns_cache=True,
                        enable_cleanup_closed=True
                    )
                    timeout = aiohttp.ClientTimeout(
                        total=60,               # Total request timeout
                        connect=10,             # Connection timeout
                        sock_read=60,
                        sock_connect=10
                    )
                    cls._session = aiohttp.ClientSession(
                        connector=connector,
                        timeout=timeout,
                        headers={"User-Agent": "Ailoos-Node/1.0"}
                    )
        return cls._session

    @classmethod
    async def close(cls):
        """Close the shared session and cleanup resources."""
        if cls._session and not cls._session.closed:
            logger.info("🔌 Closing Global HTTP Connection Pool")
            await cls._session.close()
            cls._session = None

    @classmethod
    async def get_stats(cls) -> dict:
        """Get stats about current connection pool usage."""
        # Note: aiohttp doesn't expose detailed stats publicly easily without private access
        # This is a placeholder for future implementation using a custom connector wrapper if needed
        return {
            "status": "active" if cls._session and not cls._session.closed else "closed"
        }
