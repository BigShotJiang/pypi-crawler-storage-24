#!/usr/bin/env python3
"""
AILOOS IPFS Connector - Conector Híbrido Inteligente
====================================================

Este módulo gestiona la conexión física con IPFS. Es "Híbrido" porque:
- Intenta usar un nodo local para máxima soberanía de datos
- Hace fallback automático a gateways públicos para operaciones de lectura
- Gestiona errores y reconexiones automáticamente
- Proporciona estadísticas detalladas de uso

Arquitectura:
- Nodo Local (lectura/escritura) → Máxima privacidad
- Gateway Público (solo lectura) → Fallback cuando no hay nodo local
"""

import os
import json
import time
import logging
import asyncio
import aiohttp
from aiohttp import FormData
from typing import Dict, List, Optional, Any, Union, Tuple
from pathlib import Path
from urllib.parse import urljoin
import base58
import hashlib
import base64

logger = logging.getLogger(__name__)

class IPFSConnector:
    """
    Conector híbrido inteligente para IPFS.
    Gestiona conexiones locales y gateways públicos.
    """

    def __init__(self,
                 local_api_url: str = "http://127.0.0.1:5001/api/v0",
                 public_gateways: List[str] = None,
                 enforce_tls: bool = True):
        """
        Inicializa el conector IPFS.
        """
        self.local_api_url = local_api_url
        self.public_gateways = public_gateways or [
            "https://ipfs.io/ipfs/",
            "https://gateway.pinata.cloud/ipfs/",
            "https://cloudflare-ipfs.com/ipfs/"
        ]
        self.enforce_tls = enforce_tls

        # Estado de conexión
        self.connected = False
        self.mode = "gateway_only"

        # Estadísticas
        self.stats = {
            "uploads": 0,
            "downloads": 0,
            "errors": 0,
            "last_check": 0,
            "connected_peers": 0,
            "repo_size": 0
        }

        if self.enforce_tls:
            self._validate_https_gateways()

        # NOTE: Initial connection check moved to explicit connect() method 
        # to support async execution without blocking __init__

    async def connect(self) -> bool:
        """Coroutine to establish connection and check status."""
        return await self._check_connection_async()

    def _validate_https_gateways(self):
        """Valida que todos los gateways públicos usen HTTPS."""
        from urllib.parse import urlparse

        invalid_gateways = []
        for gateway in self.public_gateways:
            parsed = urlparse(gateway)
            if parsed.scheme != "https":
                invalid_gateways.append(gateway)

        if invalid_gateways:
            logger.warning(f"⚠️ Gateways no-HTTPS encontrados (serán forzados a HTTPS): {invalid_gateways}")
            self.public_gateways = [gw.replace("http://", "https://") for gw in self.public_gateways]

    async def _check_connection_async(self) -> bool:
        """Verifica el estado de conexión con IPFS de manera asíncrona."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(f"{self.local_api_url}/id", timeout=5) as response:
                    if response.status == 200:
                        self.connected = True
                        self.mode = "full_node"
                        logger.info("✅ Conectado a nodo IPFS local (Async)")
                        await self._update_node_stats_async(session)
                        return True
        except Exception as e:
            # Fallback a modo gateway
            pass
            
        # Si falla local, asumimos gateway mode
        self.connected = True
        self.mode = "gateway_only"
        return True

    async def _update_node_stats_async(self, session: aiohttp.ClientSession):
        """Actualiza estadísticas del nodo local asíncronamente."""
        try:
            # Peers
            async with session.post(f"{self.local_api_url}/swarm/peers", timeout=5) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    self.stats["connected_peers"] = len(data.get("Peers", []))

            # Repo Stat
            async with session.post(f"{self.local_api_url}/repo/stat", timeout=5) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    self.stats["repo_size"] = data.get("RepoSize", 0)
        except Exception as e:
            logger.debug(f"Error updating stats: {e}")

    async def add_json(self, data: Dict) -> Optional[str]:
        """
        Sube datos JSON a IPFS de manera asíncrona.

        Args:
            data: Datos a subir

        Returns:
            CID del contenido subido, o None si falla
        """
        if not self.connected:
            logger.error("❌ No hay conexión IPFS disponible")
            return None

        # Convertir a JSON string
        json_str = json.dumps(data, ensure_ascii=False, separators=(',', ':'))

        try:
            if self.mode == "full_node":
                # Usar nodo local para subida
                form = FormData()
                form.add_field('file', json_str, filename='data.json', content_type='application/json')

                async with aiohttp.ClientSession() as session:
                    async with session.post(f"{self.local_api_url}/add", data=form, timeout=30) as response:
                        if response.status == 200:
                            result = await response.json()
                            cid = result.get("Hash")
                            self.stats["uploads"] += 1
                            logger.info(f"✅ Datos subidos a IPFS local: {cid}")
                            return cid

            # Si no hay nodo local o falló, no podemos subir
            logger.error("❌ No se puede subir datos sin nodo IPFS local")
            return None

        except Exception as e:
            self.stats["errors"] += 1
            logger.error(f"❌ Error subiendo datos a IPFS: {e}")
            return None

    async def get_json(self, cid: str) -> Optional[Dict]:
        """
        Descarga datos JSON desde IPFS de manera asíncrona.

        Args:
            cid: CID del contenido a descargar

        Returns:
            Datos descargados como dict, o None si falla
        """
        if not self.connected:
            logger.error("❌ No hay conexión IPFS disponible")
            return None

        # Intentar descarga desde diferentes fuentes
        sources = []

        if self.mode == "full_node":
            sources.append(("local", f"{self.local_api_url}/cat/{cid}"))

        # Añadir gateways públicos
        for gateway in self.public_gateways:
            sources.append(("gateway", urljoin(gateway, cid)))

        async with aiohttp.ClientSession() as session:
            for source_name, url in sources:
                try:
                    logger.debug(f"Intentando descarga desde {source_name}: {url}")

                    async with session.get(url, timeout=30) as response:
                        if response.status == 200:
                            content = await response.read()
                            data = json.loads(content.decode('utf-8'))

                            # [Security Hardening] Integrity Verification
                            try:
                                if not self.verify_cid_integrity(content, cid):
                                     logger.error(f"🚨 SECURITY ALERT: Integrity verification failed for {cid}")
                                     continue # Try next source

                            except Exception as e:
                                logger.warning(f"Integrity check skipped for JSON: {e}")

                            self.stats["downloads"] += 1
                            logger.info(f"✅ Datos descargados desde {source_name}: {cid}")
                            return data

                except json.JSONDecodeError:
                    logger.warning(f"Contenido de {source_name} no es JSON válido")
                except Exception as e:
                    logger.debug(f"Error descargando desde {source_name}: {e}")
                    continue

        self.stats["errors"] += 1
        logger.error(f"❌ No se pudo descargar {cid} desde ninguna fuente")
        return None

    async def get_bytes(self, cid: str) -> Optional[bytes]:
        """
        Descarga datos binarios desde IPFS de manera asíncrona.

        Args:
            cid: CID del contenido a descargar

        Returns:
            Datos como bytes, o None si falla
        """
        if not self.connected:
            logger.error("❌ No hay conexión IPFS disponible")
            return None

        # Intentar descarga desde diferentes fuentes
        sources = []

        if self.mode == "full_node":
            sources.append(("local", f"{self.local_api_url}/cat/{cid}"))

        # Añadir gateways públicos
        for gateway in self.public_gateways:
            sources.append(("gateway", urljoin(gateway, cid)))

        async with aiohttp.ClientSession() as session:
            for source_name, url in sources:
                try:
                    logger.debug(f"Intentando descarga desde {source_name}: {url}")

                    async with session.get(url, timeout=30) as response:
                        if response.status == 200:
                            content = await response.read()

                            # [Security Hardening] Integrity Verification
                            if not self.verify_cid_integrity(content, cid):
                                logger.error(f"🚨 SECURITY ALERT: Integrity verification failed for {cid} (Bytes)")
                                continue

                            self.stats["downloads"] += 1
                            logger.info(f"✅ Datos binarios descargados desde {source_name}: {cid}")
                            return content

                except Exception as e:
                    logger.debug(f"Error descargando desde {source_name}: {e}")
                    continue

        self.stats["errors"] += 1
        logger.error(f"❌ No se pudo descargar {cid} desde ninguna fuente")
        return None

    async def download_parallel_async(self, cids: List[str], max_concurrent: int = 5) -> Dict[str, bytes]:
        """
        Descarga múltiples CIDs en paralelo usando aiohttp.
        """
        results = {}
        semaphore = asyncio.Semaphore(max_concurrent)

        async with aiohttp.ClientSession() as session:
            tasks = []
            for cid in cids:
                tasks.append(self._download_single_async(session, cid, semaphore))
            
            downloaded = await asyncio.gather(*tasks)
            for cid, content in downloaded:
                if content:
                    results[cid] = content
        
        return results

    async def _download_single_async(self, session: aiohttp.ClientSession, cid: str, semaphore: asyncio.Semaphore) -> Tuple[str, Optional[bytes]]:
        """Descarga un solo CID asíncronamente con semáforo para balanceo de carga."""
        async with semaphore:
            # Fuentes
            urls = []
            if self.mode == "full_node":
                urls.append(f"{self.local_api_url}/cat/{cid}")
            for gateway in self.public_gateways:
                urls.append(urljoin(gateway, cid))

            for url in urls:
                try:
                    async with session.get(url, timeout=30) as response:
                        if response.status == 200:
                            content = await response.read()
                            logger.info(f"✅ Async download success: {cid}")
                            return cid, content
                except Exception as e:
                    logger.debug(f"Async download failed for {url}: {e}")
                    continue
            
            return cid, None

    async def get_stats(self) -> Dict:
        """
        Obtiene estadísticas del conector de manera asíncrona.

        Returns:
            Dict con estadísticas de uso
        """
        # Actualizar timestamp
        self.stats["last_check"] = time.time()

        # Verificar conexión actual
        await self._check_connection_async()

        return {
            "connected": self.connected,
            "mode": self.mode,
            "uploads": self.stats["uploads"],
            "downloads": self.stats["downloads"],
            "errors": self.stats["errors"],
            "connected_peers": self.stats.get("connected_peers", 0),
            "repo_size": self.stats.get("repo_size", 0),
            "last_check": self.stats["last_check"]
        }

    async def pin_cid(self, cid: str) -> bool:
        """
        Pin un CID para mantenerlo disponible localmente de manera asíncrona.

        Args:
            cid: CID a pinear

        Returns:
            True si se pudo pinear, False en caso contrario
        """
        if self.mode != "full_node":
            logger.warning("⚠️ Pinning solo disponible en modo nodo local")
            return False

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(f"{self.local_api_url}/pin/add/{cid}", timeout=30) as response:
                    if response.status == 200:
                        logger.info(f"✅ CID pineado: {cid}")
                        return True
                    else:
                        text = await response.text()
                        logger.error(f"❌ Error pineando CID: {text}")
                        return False

        except Exception as e:
            logger.error(f"❌ Error en pinning: {e}")
            return False

    def verify_cid_integrity(self, content: Union[bytes, str], cid: str) -> bool:
        """
        Verifica criptográficamente que el contenido coincida con el CID.
        Soporta CIDv0 (Qm...) y CIDv1 (b.../z...).
        """
        try:
            # Normalizar contenido a bytes
            if isinstance(content, str):
                content_bytes = content.encode('utf-8')
            else:
                content_bytes = content
                
            # Calcular SHA-256 del contenido
            actual_hash = hashlib.sha256(content_bytes).digest()
            
            # --- CIDv0 (Legacy) ---
            if cid.startswith("Qm"):
                decoded = base58.b58decode(cid)
                if len(decoded) < 34: # min length check
                    return False
                # Verify Multihash prefix for SHA2-256 (0x12 0x20)
                if decoded[0] != 0x12 or decoded[1] != 0x20:
                    logger.warning(f"⚠️ CIDv0 non-standard hash: {decoded[0:2].hex()}")
                    return False
                expected_digest = decoded[2:]
                
                if actual_hash == expected_digest:
                    return True
                else:
                     logger.error(f"❌ Hash Mismatch (CIDv0)! Exp: {expected_digest.hex()[:8]}... Got: {actual_hash.hex()[:8]}...")
                     return False

            # --- CIDv1 ---
            # 1. Multibase Decoding
            decoded_bytes = None
            if cid.startswith("b"): # base32 (rfc4648 no pad lowercase)
                # Padding might be needed for python's decoder
                b32_str = cid[1:].upper()
                pad = len(b32_str) % 8
                if pad > 0:
                    b32_str += "=" * (8 - pad)
                decoded_bytes = base64.b32decode(b32_str)
            elif cid.startswith("z"): # base58btc
                decoded_bytes = base58.b58decode(cid[1:])
            else:
                logger.warning(f"⚠️ Unsupported Multibase: {cid[0]}")
                return False

            # 2. Parse CID Structure: <version><multicodec><multihash>
            # Use simple pointer to consume varints
            idx = 0
            
            # Helper to read varint
            def read_varint(data, ptr):
                val = 0
                shift = 0
                while True:
                    if ptr >= len(data): raise ValueError("Varint out of bounds")
                    b = data[ptr]
                    ptr += 1
                    val |= (b & 0x7f) << shift
                    if not (b & 0x80):
                        break
                    shift += 7
                return val, ptr

            # Verify Version
            version, idx = read_varint(decoded_bytes, idx)
            if version != 1:
                logger.warning(f"⚠️ Unsupported CID Version: {version}")
                return False
                
            # Skip Multicodec (dag-pb, raw, etc.) - we authenticate the hash regardless of codec
            _, idx = read_varint(decoded_bytes, idx)
            
            # 3. Parse Multihash: <fn code><size><digest>
            fn_code, idx = read_varint(decoded_bytes, idx)
            digest_size, idx = read_varint(decoded_bytes, idx)
            
            if fn_code != 0x12: # SHA2-256
                 # We fail-close on unknown hashes for strictness now
                 logger.error(f"❌ Unsupported Hash Function: 0x{fn_code:x} (Only SHA2-256 supported)")
                 return False

            if digest_size != 32:
                 logger.error(f"❌ Unexpected Digest Size: {digest_size} (Expected 32)")
                 return False

            expected_digest = decoded_bytes[idx : idx + digest_size]
            
            if len(expected_digest) != 32:
                 logger.error("❌ Malformed CID: Digest truncated")
                 return False

            if actual_hash == expected_digest:
                return True
            else:
                logger.error(f"❌ Hash Mismatch (CIDv1)! Exp: {expected_digest.hex()[:8]}... Got: {actual_hash.hex()[:8]}...")
                return False
                
        except Exception as e:
            logger.error(f"❌ Error verificando integridad CIDv1: {e}")
            return False

# Instancia global del conector
ipfs_connector = IPFSConnector()