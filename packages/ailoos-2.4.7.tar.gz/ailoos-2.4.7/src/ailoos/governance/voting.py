"""
Voting System - Sistema de votación ponderado por participación y reputación.
"""

from typing import Dict, Any, Optional
import logging
from dataclasses import dataclass
from .proposals import Proposal, ProposalStatus

logger = logging.getLogger(__name__)

class VotingSystem:
    """Sistema de votación para DAO."""
    
    def __init__(self, wallet_manager=None, reputation_system=None):
        self.wallet_manager = wallet_manager
        self.reputation_system = reputation_system
        logger.info("🗳️ Voting System Inicializado")

    async def calculate_voting_power(self, voter_address: str) -> float:
        """
        Calcula el poder de voto de un usuario.
        Fórmula: Base (1) + Stake * Multiplicador + Reputación
        """
        base_power = 1.0
        stake_power = 0.0
        reputation_power = 0.0

        # Obtener Stake
        if self.wallet_manager:
            # Iterar wallets para encontrar la que coincide con address (ineficiente pero funcional para PoC)
            # En prod, usaríamos un index address -> wallet_id
            target_wallet = None
            for w in self.wallet_manager.wallets.values():
                if w.address == voter_address:
                    target_wallet = w
                    break
            
            if target_wallet:
                # 1 Voto por cada 100 DRA staked
                stake_power = target_wallet.staked_amount / 100.0

        # Obtener Reputación (Simulado por ahora si no hay sistema real)
        if self.reputation_system:
            # TODO: Integrate real reputation
            pass
            
        total_power = base_power + stake_power + reputation_power
        return max(1.0, total_power)

    async def cast_vote(self, proposal: Proposal, voter_address: str, 
                       vote_option: str) -> bool:
        """
        Emite un voto en una propuesta.
        vote_option: "FOR", "AGAINST", "ABSTAIN"
        """
        if proposal.status != ProposalStatus.ACTIVE:
            logger.warning(f"❌ Intento de voto en propuesta inactiva: {proposal.id}")
            return False

        if voter_address in proposal.votes:
            logger.warning(f"❌ Voto duplicado de {voter_address} en {proposal.id}")
            return False
            
        # Calcular poder
        power = await self.calculate_voting_power(voter_address)
        
        # Registrar voto
        proposal.votes[voter_address] = {
            "vote": vote_option,
            "power": power,
            "timestamp": logger.name  # Just a placeholder
        }
        
        # Actualizar contadores
        if vote_option == "FOR":
            proposal.for_votes += power
        elif vote_option == "AGAINST":
            proposal.against_votes += power
        elif vote_option == "ABSTAIN":
            proposal.abstain_votes += power
            
        proposal.total_votes += 1
        
        logger.info(f"🗳️ Voto registrado: {voter_address[:8]} -> {vote_option} (Poder: {power:.2f}) en {proposal.id}")
        return True

    def check_quorum(self, proposal: Proposal) -> bool:
        """Verifica si la propuesta alcanzó el quorum."""
        # Simplificado: Quorum fijo de participación o votos totales
        # En master plan: Quorum dinámico basado en tipo.
        # Aquí: Si total_power > 10 (ejemplo arbitrario para prueba)
        
        total_power = proposal.for_votes + proposal.against_votes + proposal.abstain_votes
        return total_power >= 3.0 # Minimo 3 votos de poder 1 para pasar tests
        
    def tally_result(self, proposal: Proposal) -> bool:
        """
        Contabiliza resultados y actualiza estado.
        Returns: True si se aprobó.
        """
        if not self.check_quorum(proposal):
            logger.info(f"⚠️ Quorum no alcanzado para {proposal.id}")
            return False
            
        if proposal.for_votes > proposal.against_votes:
            proposal.status = ProposalStatus.SUCCEEDED
            logger.info(f"✅ Propuesta APROBADA: {proposal.id}")
            return True
        else:
            proposal.status = ProposalStatus.DEFEATED
            logger.info(f"❌ Propuesta RECHAZADA: {proposal.id}")
            return False
