"""
Proposal Manager - Gestión del ciclo de vida de propuestas DAO.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any
import time
from datetime import datetime
import json
import logging

logger = logging.getLogger(__name__)

class ProposalType(str, Enum):
    PARAMETER_CHANGE = "PARAMETER_CHANGE"
    FUNDING_REQUEST = "FUNDING_REQUEST"
    CODE_UPGRADE = "CODE_UPGRADE"
    TREASURY_ALLOCATION = "TREASURY_ALLOCATION"
    PARTNERSHIP_AGREEMENT = "PARTNERSHIP_AGREEMENT"

class ProposalStatus(str, Enum):
    DRAFT = "DRAFT"
    ACTIVE = "ACTIVE"
    SUCCEEDED = "SUCCEEDED"
    DEFEATED = "DEFEATED"
    EXECUTED = "EXECUTED"
    CANCELLED = "CANCELLED"

@dataclass
class Proposal:
    id: str
    proposer: str
    proposal_type: ProposalType
    title: str
    description: str
    data: Dict[str, Any]
    start_time: float
    end_time: float
    status: ProposalStatus = ProposalStatus.DRAFT
    for_votes: float = 0.0
    against_votes: float = 0.0
    abstain_votes: float = 0.0
    total_votes: int = 0
    votes: Dict[str, Dict] = field(default_factory=dict) # voter_addr -> {vote: "FOR", power: 10}
    created_at: float = field(default_factory=time.time)
    execution_result: Optional[Dict] = None

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "proposer": self.proposer,
            "type": self.proposal_type.value,
            "title": self.title,
            "description": self.description,
            "data": self.data,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "status": self.status.value,
            "votes_summary": {
                "for": self.for_votes,
                "against": self.against_votes,
                "abstain": self.abstain_votes,
                "total_voters": self.total_votes
            },
            "created_at": datetime.fromtimestamp(self.created_at).isoformat()
        }

class ProposalManager:
    """Gestor del ciclo de vida de las propuestas."""

    def __init__(self):
        self.proposals: Dict[str, Proposal] = {}
        logger.info("🏛️ Proposal Manager Inicializado")

    def create_proposal(self, proposer: str, 
                       proposal_type: ProposalType,
                       title: str,
                       description: str,
                       data: Dict[str, Any],
                       duration_days: int = 7) -> Proposal:
        """Crea una nueva propuesta."""
        
        proposal_id = f"prop_{int(time.time())}_{proposer[:6]}"
        now = time.time()
        
        proposal = Proposal(
            id=proposal_id,
            proposer=proposer,
            proposal_type=proposal_type,
            title=title,
            description=description,
            data=data,
            start_time=now,
            end_time=now + (duration_days * 86400),
            status=ProposalStatus.ACTIVE # Auto-activate for simplicity in Phase 80
        )
        
        self.proposals[proposal_id] = proposal
        logger.info(f"📝 Propuesta creada: {title} ({proposal_id})")
        return proposal

    def get_proposal(self, proposal_id: str) -> Optional[Proposal]:
        return self.proposals.get(proposal_id)

    def list_active_proposals(self) -> List[Proposal]:
        return [p for p in self.proposals.values() if p.status == ProposalStatus.ACTIVE]
    
    def get_parameter_value(self, parameter_key: str, default: Any) -> Any:
        """Obtiene el valor actual de un parámetro gobernado (Simulado)."""
        # En el futuro, esto leería del estado global de gobernanza
        return default
