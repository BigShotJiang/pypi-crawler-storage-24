"""
Governance Engine - Motor principal de la DAO Ailoos.
Coordina gestión de propuestas, votación y ejecución.
"""

from typing import Dict, Any, Optional
import logging
from .proposals import ProposalManager, Proposal, ProposalStatus, ProposalType
from .voting import VotingSystem

logger = logging.getLogger(__name__)

class GovernanceEngine:
    """Motor de orquestación de gobernanza."""

    def __init__(self, wallet_manager=None, blockchain=None):
        self.wallet_manager = wallet_manager
        self.blockchain = blockchain
        
        self.proposals = ProposalManager()
        self.voting = VotingSystem(wallet_manager=wallet_manager)
        
        logger.info("🏛️ Governance Engine Inicializado")

    def submit_proposal(self, proposer_addr: str, 
                        type_str: str,
                        title: str, 
                        description: str,
                        data: Dict[str, Any]) -> str:
        """
        Envía una nueva propuesta a la DAO.
        """
        # Validar tipo
        try:
            p_type = ProposalType(type_str)
        except ValueError:
            raise ValueError(f"Tipo de propuesta inválido: {type_str}")

        # Validar permisos (Ej: Stake mínimo 100 DRA para proponer)
        # Por ahora asumimos check externo o permitido.
        
        proposal = self.proposals.create_proposal(
            proposer=proposer_addr,
            proposal_type=p_type,
            title=title,
            description=description,
            data=data
        )
        
        return proposal.id

    async def cast_vote(self, proposal_id: str, voter_addr: str, vote_option: str) -> bool:
        """Emite voto a través del sistema de votación."""
        proposal = self.proposals.get_proposal(proposal_id)
        if not proposal:
            logger.error(f"Propuesta no encontrada: {proposal_id}")
            return False
            
        return await self.voting.cast_vote(proposal, voter_addr, vote_option)

    def process_results(self, proposal_id: str) -> bool:
        """
        Cierra votación y ejecuta si es aprobada.
        """
        proposal = self.proposals.get_proposal(proposal_id)
        if not proposal:
            return False
            
        if proposal.status != ProposalStatus.ACTIVE:
            return False
            
        # Contabilizar
        passed = self.voting.tally_result(proposal)
        
        if passed:
            self._execute_proposal(proposal)
            
        return passed

    def _execute_proposal(self, proposal: Proposal):
        """Ejecuta la lógica de una propuesta aprobada."""
        logger.info(f"⚙️ Ejecutando propuesta {proposal.id} ({proposal.proposal_type})")
        
        try:
            if proposal.proposal_type == ProposalType.PARAMETER_CHANGE:
                # Simular cambio de parámetro
                param = proposal.data.get("parameter")
                value = proposal.data.get("value")
                logger.info(f"🛠️ Parámetro actualizado: {param} -> {value}")
                
            elif proposal.proposal_type == ProposalType.FUNDING_REQUEST:
                # Simular envío de fondos
                recipient = proposal.data.get("recipient")
                amount = proposal.data.get("amount")
                logger.info(f"💸 Fondos liberados: {amount} DRA -> {recipient}")
                
            proposal.status = ProposalStatus.EXECUTED
            logger.info(f"✅ Ejecución completada para {proposal.id}")
            
        except Exception as e:
            logger.error(f"❌ Fallo en ejecución de propuesta {proposal.id}: {e}")
            # No cambiamos estado a FAILED aquí para simplificar, pero en prod sí deberíamos.

# Global Instance
governance_engine = GovernanceEngine()
