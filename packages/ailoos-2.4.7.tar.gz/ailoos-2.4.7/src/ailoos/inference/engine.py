"""
AILOOS Inference Engine v1.0
Runs EmpoorioLM models directly on the node using PyTorch/Transformers.
"""

import os
import torch
import logging
import asyncio
import threading
from typing import Optional, Dict, Any, Generator
from dataclasses import dataclass


try:
    from vllm import LLM, SamplingParams
    VLLM_AVAILABLE = True
except ImportError:
    VLLM_AVAILABLE = False
    
logger = logging.getLogger(__name__)

class InferenceEngine:
    """
    Engine principal para ejecutar modelos LLM locales.
    Soporta:
    - Carga de modelos via Transformers (AutoModelForCausalLM)
    - Generación de texto en streaming
    - fallback automático a "Modo Simulación" si no hay GPU/RAM
    """
    
    def __init__(self, model_path: str = "Empoorio/EmpoorioLM-7B", load_in_8bit: bool = True, draft_model_path: Optional[str] = None):
        self.model_path = model_path
        self.load_in_8bit = load_in_8bit
        self.draft_model_path = draft_model_path

        # Critical Performance Optimization: GPU Enforcement
        if torch.cuda.is_available():
            self.device = "cuda"
        elif torch.backends.mps.is_available():
            self.device = "mps"
        else:
            # STRICT ENFORCEMENT: No CPU allowed for inference
            error_msg = "CRITICAL: No GPU detected (CUDA/MPS). CPU inference is disabled for performance reasons."
            logger.critical(f"❌ {error_msg}")
            raise SystemError(error_msg)

        self.model = None
        self.draft_model = None
        self.tokenizer = None
        self.vllm_engine = None # 🚀 Motor vLLM (High Throughput)
        self.is_loaded = False

        # Detectar recursos
        self._check_resources()

    def _check_resources(self):
        """Verifica si el nodo tiene capacidad para correr el modelo real."""
        import psutil
        mem = psutil.virtual_memory()
        total_gb = mem.total / (1024**3)
        
        logger.info(f"✅ Resources OK: {self.device.upper()} detected, {total_gb:.1f}GB RAM.")

    def load_model(self):
        """Carga el modelo en memoria con optimización (4-bit/8-bit)."""

        # 1. Intentar Cargar vLLM (Solo CUDA/Linux usualmente, pero prioritario)
        if VLLM_AVAILABLE and self.device == "cuda":
            try:
                logger.info(f"🚀 Initializing vLLM Engine for {self.model_path}...")
                # Configuración de 4-bit para vLLM si se solicita
                quantization = "bitsandbytes" if self.load_in_8bit else None # vllm soporta awq/gptq mejor, pero bnb experimental

                # Nota: vLLM requiere GPU dedicada.
                # Configuration for PagedAttention (Phase 30 Optimization)
                # gpu_memory_utilization=0.9 ensures maximum VRAM for KV cache blocks
                # swap_space=4 creates 4GB CPU swap for overflow
                self.vllm_engine = LLM(
                    model=self.model_path,
                    quantization="load_only_4bit" if self.load_in_8bit else None,
                    trust_remote_code=True,
                    dtype="float16",
                    gpu_memory_utilization=0.9, 
                    swap_space=4,
                    enforce_eager=False # Allow CUDA graph capture for speed
                )
                self.is_loaded = True
                logger.info("✅ vLLM Engine loaded successfully! (High Throughput Mode)")
                return
            except Exception as e:
                logger.warning(f"⚠️ vLLM init failed: {e}. Falling back to Transformers.")
                self.vllm_engine = None

        # 2. Fallback a Transformers (Standard)
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
            
            logger.info(f"⏳ Loading model {self.model_path} on {self.device}...")
            
            # Autotokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, trust_remote_code=True)
            
            # Quantization Configuration (Hyper-Optimization)
            quantization_config = None
            if self.device == "cuda":
                logger.info("🚀 Enabling 4-bit Quantization (BitsAndBytes) for efficiency")
                quantization_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.float16,
                    bnb_4bit_quant_type="nf4",
                    bnb_4bit_use_double_quant=True,
                )
            
            # Load Model with Quantization
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_path,
                quantization_config=quantization_config,
                device_map="auto" if self.device == "cuda" else None,
                torch_dtype=torch.float16 if self.device != "cpu" else torch.float32,
                low_cpu_mem_usage=True,
                trust_remote_code=True
            )
            
            if self.device != "cuda":
                 self.model.to(self.device)

            self.is_loaded = True
            logger.info(f"✅ Model loaded successfully! (Quantized: {quantization_config is not None})")

            # Load draft model if provided
            if self.draft_model_path:
                try:
                    logger.info(f"⏳ Loading draft model {self.draft_model_path} on {self.device}...")
                    self.draft_model = AutoModelForCausalLM.from_pretrained(
                        self.draft_model_path,
                        quantization_config=quantization_config,
                        device_map="auto" if self.device == "cuda" else None,
                        torch_dtype=torch.float16 if self.device != "cpu" else torch.float32,
                        low_cpu_mem_usage=True,
                        trust_remote_code=True
                    )
                    if self.device != "cuda":
                        self.draft_model.to(self.device)
                    logger.info("✅ Draft model loaded successfully!")
                except Exception as e:
                    logger.warning(f"⚠️ Failed to load draft model: {e}. Speculative decoding will not be available.")

        except ImportError as e:
            logger.error(f"❌ Required libraries missing: {e}")
            raise RuntimeError("Inference dependencies missing") from e

        except Exception as e:
            logger.error(f"❌ Failed to load real model: {e}")
            raise

    async def generate(self, prompt: str, max_new_tokens: int = 200, temperature: float = 0.7, use_speculative: bool = False) -> Generator[str, None, None]:
        """
        Genera respuesta (streaming).
        Support for Speculative Decoding (Experimental).
        """
        if not self.is_loaded:
            self.load_model()

        # 1. vLLM Generation (High Performance)
        if self.vllm_engine:
            # vLLM speculative decoding is configured at engine level, 
            # we can pass params if supported by installed version.
            sampling_params = SamplingParams(
                temperature=temperature,
                max_tokens=max_new_tokens,
                top_p=0.95
            )
            
            outputs = self.vllm_engine.generate([prompt], sampling_params)
            generated_text = outputs[0].outputs[0].text
            yield generated_text
            return

        # 2. Speculative Decoding (Transformers) -> Requires Draft Model
        # Simplified implementation: We check if experimental flag is on.
        # Real implementation would require loading a second smaller model.
        if use_speculative and self.device == "cuda":
            if hasattr(self, 'draft_model') and self.draft_model:
                logger.info("🚀 Speculative Decoding ENABLED (Draft model ready)")
                
                # Speculative parameters
                gamma = 4 # Number of draft tokens to generate
                
                # Minimal loop for demonstration/impl (requires synchronized tokenizers)
                # Note: This is a complex logic simplified for the codebase
                prefix_tokens = self.tokenizer(prompt, return_tensors="pt").input_ids.to(self.device)
                
                while True: # Outer generation loop
                    # 1. Generate gamma draft tokens
                    draft_outputs = self.draft_model.generate(
                        input_ids=prefix_tokens,
                        max_new_tokens=gamma,
                        do_sample=False, # Draft is greedy for speed usually
                    )
                    draft_tokens = draft_outputs[0][prefix_tokens.shape[1]:]  # New tokens only
                    
                    # 2. Verify with Main Model
                    # We run forward pass on [prefix + draft]
                    candidate_input = torch.cat([prefix_tokens, draft_tokens.unsqueeze(0)], dim=1)
                    
                    with torch.no_grad():
                        main_outputs = self.model(candidate_input)
                        logits = main_outputs.logits
                    
                    # 3. Acceptance Logic
                    # Check if draft tokens match greedy prediction of main model (simplified verification)
                    # Real speculative sampling uses probabilistic rejection sampling.
                    # Here we implement "Blockwise Parallel Decoding" style strict matching for simplicity.
                    
                    accepted_count = 0
                    for i in range(len(draft_tokens)):
                        # Logits at pos [prefix_len + i - 1] predict pos [prefix_len + i]
                        # We need the logits corresponding to the input position just before the draft token
                        pos = prefix_tokens.shape[1] + i - 1
                        
                        # Greedy token from main model
                        target_token_id = torch.argmax(logits[0, pos]).item()
                        draft_token_id = draft_tokens[i].item()
                        
                        if target_token_id == draft_token_id:
                            accepted_count += 1
                        else:
                            # Rejection found, stop accepting
                            break
                            
                    # 4. Yield accepted tokens
                    for i in range(accepted_count):
                         token_text = self.tokenizer.decode(draft_tokens[i])
                         yield token_text
                    
                    # 5. Update prefix
                    # Append accepted tokens
                    prefix_tokens = torch.cat([prefix_tokens, draft_tokens[:accepted_count].unsqueeze(0)], dim=1)
                    
                    # 6. Corrective Step (if we rejected something, or just generate one more from main model)
                    # Main model has computed logits for the rejected position anyway.
                    # We accept one token from main model to ensure progress even if draft is wrong.
                    if accepted_count < len(draft_tokens):
                        # The first rejected token position
                        pos = prefix_tokens.shape[1] - 1 # Last valid token index
                        next_token_id = torch.argmax(logits[0, pos]).unsqueeze(0).unsqueeze(0)
                        
                        prefix_tokens = torch.cat([prefix_tokens, next_token_id], dim=1)
                        yield self.tokenizer.decode(next_token_id[0][0])
                    
                    # Stop condition
                    if prefix_tokens.shape[1] >= max_new_tokens + len(self.tokenizer(prompt)['input_ids']):
                         break
                         
                return
            else:
                logger.warning("⚠️ Speculative Decoding requested but no draft model loaded. Falling back to standard generation.")
            
        # 3. Standard Transformers Generation (streaming real)
        from transformers import TextIteratorStreamer

        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        streamer = TextIteratorStreamer(
            self.tokenizer,
            skip_prompt=True,
            skip_special_tokens=True
        )

        gen_kwargs = {
            **inputs,
            "max_new_tokens": max_new_tokens,
            "temperature": temperature,
            "do_sample": True,
            "streamer": streamer
        }

        loop = asyncio.get_running_loop()
        queue: asyncio.Queue = asyncio.Queue()

        def _run_generation():
            try:
                with torch.no_grad():
                    self.model.generate(**gen_kwargs)
            except Exception as exc:
                loop.call_soon_threadsafe(queue.put_nowait, exc)
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        def _forward_stream():
            try:
                for text in streamer:
                    loop.call_soon_threadsafe(queue.put_nowait, text)
            except Exception as exc:
                loop.call_soon_threadsafe(queue.put_nowait, exc)

        threading.Thread(target=_run_generation, daemon=True).start()
        threading.Thread(target=_forward_stream, daemon=True).start()

        while True:
            item = await queue.get()
            if item is None:
                break
            if isinstance(item, Exception):
                raise item
            yield item
