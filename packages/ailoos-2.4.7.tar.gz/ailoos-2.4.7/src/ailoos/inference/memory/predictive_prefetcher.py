"""
Predictive Prefetcher - Sistema de prefetching predictivo para memoria IPFS
==========================================================================

Sistema de prefetching predictivo que usa un modelo MLP para predecir y cargar
chunks de memoria necesarios desde IPFS, reduciendo significativamente la latencia
de recuperación de memoria distribuida.

Características principales:
- Modelo MLP para predicción de patrones de acceso
- Prefetching asíncrono con prioridad
- Cache inteligente de chunks
- Integración completa con IPFS
- Métricas de rendimiento y optimización automática
"""

import asyncio
import inspect
import json
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Optional, Tuple, Any, Set, Union, Callable
import threading
import time
import logging
from dataclasses import dataclass, field
from collections import defaultdict, deque
import math
from concurrent.futures import ThreadPoolExecutor

from ...infrastructure.ipfs_embedded import IPFSManager
from ...utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ChunkAccessPattern:
    """Patrón de acceso a un chunk de memoria."""
    chunk_id: str
    access_count: int = 0
    last_access: float = 0.0
    access_times: List[float] = field(default_factory=list)
    context_embeddings: List[torch.Tensor] = field(default_factory=list)
    prediction_score: float = 0.0
    prefetch_priority: float = 0.0


@dataclass
class PrefetchMetrics:
    """Métricas del sistema de prefetching."""
    total_predictions: int = 0
    correct_predictions: int = 0
    false_positives: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    average_prefetch_time: float = 0.0
    total_prefetched_chunks: int = 0
    memory_saved_mb: float = 0.0


class PredictiveMLP(nn.Module):
    """
    Modelo MLP para predicción de chunks necesarios.
    Usa embeddings de contexto y patrones históricos para predecir accesos futuros.
    """

    def __init__(
        self,
        input_size: int = 512,
        hidden_sizes: List[int] = [256, 128, 64],
        num_chunks: int = 1000,
        dropout: float = 0.1
    ):
        super().__init__()
        self.input_size = input_size
        self.num_chunks = num_chunks

        # Encoder para contexto
        layers = []
        prev_size = input_size
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout)
            ])
            prev_size = hidden_size

        self.encoder = nn.Sequential(*layers)

        # Cabeza de predicción
        self.predictor = nn.Sequential(
            nn.Linear(prev_size, prev_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(prev_size // 2, num_chunks),
            nn.Sigmoid()  # Probabilidades de acceso
        )

        # Optimizador y pérdida
        self.optimizer = torch.optim.Adam(self.parameters(), lr=1e-3)
        self.criterion = nn.BCELoss()

    def forward(self, context_embedding: torch.Tensor) -> torch.Tensor:
        """
        Predice probabilidades de acceso a chunks basado en el contexto.

        Args:
            context_embedding: Embedding del contexto actual [batch_size, input_size]

        Returns:
            Probabilidades de acceso [batch_size, num_chunks]
        """
        encoded = self.encoder(context_embedding)
        predictions = self.predictor(encoded)
        return predictions

    def train_step(self, context_embeddings: torch.Tensor, target_chunks: torch.Tensor):
        """
        Entrena el modelo con un batch de datos.

        Args:
            context_embeddings: Embeddings de contexto [batch_size, input_size]
            target_chunks: Chunks objetivo (one-hot) [batch_size, num_chunks]
        """
        self.optimizer.zero_grad()
        predictions = self.forward(context_embeddings)
        loss = self.criterion(predictions, target_chunks)
        loss.backward()
        self.optimizer.step()
        return loss.item()


class ChunkCache:
    """
    Cache inteligente para chunks prefetched.
    Gestiona memoria y prioridad de chunks.
    """

    def __init__(self, max_memory_mb: int = 512, chunk_size_mb: float = 1.0):
        self.max_memory_mb = max_memory_mb
        self.chunk_size_mb = chunk_size_mb
        self.max_chunks = int(max_memory_mb / chunk_size_mb)

        # Cache: chunk_id -> (data, timestamp, access_count, priority)
        self.cache: Dict[str, Tuple[bytes, float, int, float]] = {}
        self.access_order = deque()  # Para LRU eviction

        self.lock = threading.RLock()

    def get(self, chunk_id: str) -> Optional[bytes]:
        """Obtiene un chunk del cache."""
        with self.lock:
            if chunk_id in self.cache:
                data, timestamp, access_count, priority = self.cache[chunk_id]
                # Actualizar estadísticas de acceso
                self.cache[chunk_id] = (data, time.time(), access_count + 1, priority)
                # Mover al final (más recientemente usado)
                self.access_order.remove(chunk_id)
                self.access_order.append(chunk_id)
                return data
        return None

    def put(self, chunk_id: str, data: bytes, priority: float = 1.0):
        """Almacena un chunk en el cache."""
        with self.lock:
            # Evict si es necesario
            while len(self.cache) >= self.max_chunks:
                self._evict_lru()

            # Almacenar
            self.cache[chunk_id] = (data, time.time(), 0, priority)
            self.access_order.append(chunk_id)

    def _evict_lru(self):
        """Evita el chunk menos recientemente usado."""
        if self.access_order:
            lru_chunk = self.access_order.popleft()
            if lru_chunk in self.cache:
                del self.cache[lru_chunk]

    def get_stats(self) -> Dict[str, Any]:
        """Retorna estadísticas del cache."""
        with self.lock:
            total_size = len(self.cache) * self.chunk_size_mb
            return {
                "cached_chunks": len(self.cache),
                "max_chunks": self.max_chunks,
                "memory_usage_mb": total_size,
                "max_memory_mb": self.max_memory_mb,
                "hit_rate": 0.0  # Calcular basado en accesos
            }


class PredictivePrefetcher:
    """
    Sistema de prefetching predictivo que usa MLP para predecir y cargar chunks desde IPFS.
    """

    def __init__(
        self,
        ipfs_manager: IPFSManager,
        num_chunks: int = 1000,
        prefetch_batch_size: int = 10,
        max_concurrent_prefetches: int = 5,
        cache_memory_mb: int = 512,
        device: str = "cuda" if torch.cuda.is_available() else "cpu",
        chunk_manifest_cid: Optional[str] = None,
        chunk_id_resolver: Optional[Callable[[str], Optional[str]]] = None,
        chunk_id_map: Optional[Dict[str, str]] = None
    ):
        self.ipfs_manager = ipfs_manager
        self.num_chunks = num_chunks
        self.prefetch_batch_size = prefetch_batch_size
        self.max_concurrent = max_concurrent_prefetches
        self.device = device
        self.chunk_manifest_cid = chunk_manifest_cid or os.getenv("AILOOS_IPFS_CHUNK_MANIFEST_CID")
        self.chunk_id_resolver = chunk_id_resolver
        self.strict_chunk_ids = os.getenv("AILOOS_PREFETCH_STRICT_CHUNK_IDS", "0") == "1"

        # Modelo predictivo
        self.predictive_model = PredictiveMLP(num_chunks=num_chunks)
        self.predictive_model.to(device)

        # Cache de chunks
        self.chunk_cache = ChunkCache(max_memory_mb=cache_memory_mb)

        # Estado de chunks y patrones de acceso
        self.chunk_patterns: Dict[str, ChunkAccessPattern] = {}
        self.active_prefetches: Set[str] = set()
        self.prefetch_queue: asyncio.Queue = asyncio.Queue()

        # Ejecutor para operaciones IO
        self.executor = ThreadPoolExecutor(max_workers=max_concurrent_prefetches)

        # Métricas
        self.metrics = PrefetchMetrics()

        self._chunk_manifest: Optional[Dict[str, Any]] = None
        self._chunk_cids: Optional[List[str]] = None
        self._chunk_cid_map: Dict[str, str] = dict(chunk_id_map or {})
        self._manifest_lock = asyncio.Lock()

        # Locks
        self.patterns_lock = threading.RLock()
        self.prefetch_lock = threading.RLock()

        # Tarea de prefetching
        self.prefetch_task: Optional[asyncio.Task] = None
        self.running = False

        logger.info(f"🧠 PredictivePrefetcher inicializado: {num_chunks} chunks, {max_concurrent_prefetches} workers")

    async def start(self):
        """Inicia el sistema de prefetching."""
        if self.running:
            return

        self.running = True
        self.prefetch_task = asyncio.create_task(self._prefetch_worker())
        logger.info("✅ PredictivePrefetcher iniciado")

    async def stop(self):
        """Detiene el sistema de prefetching."""
        self.running = False
        if self.prefetch_task:
            self.prefetch_task.cancel()
            try:
                await self.prefetch_task
            except asyncio.CancelledError:
                pass
        self.executor.shutdown(wait=True)
        logger.info("🛑 PredictivePrefetcher detenido")

    def record_access(self, chunk_id: str, context_embedding: Optional[torch.Tensor] = None):
        """
        Registra un acceso a un chunk para aprendizaje del modelo.

        Args:
            chunk_id: ID del chunk accedido
            context_embedding: Embedding del contexto de acceso
        """
        with self.patterns_lock:
            if chunk_id not in self.chunk_patterns:
                self.chunk_patterns[chunk_id] = ChunkAccessPattern(chunk_id=chunk_id)

            pattern = self.chunk_patterns[chunk_id]
            pattern.access_count += 1
            pattern.last_access = time.time()
            pattern.access_times.append(time.time())

            if context_embedding is not None:
                pattern.context_embeddings.append(context_embedding.detach().cpu())

            # Limitar historial
            if len(pattern.access_times) > 100:
                pattern.access_times = pattern.access_times[-100:]
            if len(pattern.context_embeddings) > 50:
                pattern.context_embeddings = pattern.context_embeddings[-50:]

    async def prefetch_for_context(self, context_embedding: torch.Tensor) -> List[str]:
        """
        Predice y prefetch chunks basados en el contexto actual.

        Args:
            context_embedding: Embedding del contexto actual

        Returns:
            Lista de chunk_ids que se están prefetching
        """
        # Obtener predicciones del modelo
        with torch.no_grad():
            predictions = self.predictive_model(context_embedding.unsqueeze(0).to(self.device))
            probabilities = predictions.squeeze(0).cpu()

        # Seleccionar chunks para prefetch con mayor probabilidad
        top_k = min(self.prefetch_batch_size, len(probabilities))
        top_probabilities, top_indices = torch.topk(probabilities, top_k)

        prefetched_chunks = []
        for idx, prob in zip(top_indices.tolist(), top_probabilities.tolist()):
            chunk_id = f"chunk_{idx}"
            if prob > 0.5 and chunk_id not in self.active_prefetches:  # Threshold
                await self._queue_prefetch(chunk_id, prob)
                prefetched_chunks.append(chunk_id)

        self.metrics.total_predictions += len(prefetched_chunks)
        return prefetched_chunks

    async def get_chunk(self, chunk_id: str, ipfs_cid: Optional[str] = None) -> Optional[bytes]:
        """
        Obtiene un chunk, usando cache o cargando desde IPFS.

        Args:
            chunk_id: ID del chunk
            ipfs_cid: CID de IPFS (opcional, para carga directa)

        Returns:
            Datos del chunk o None si no encontrado
        """
        # Verificar cache primero
        cached_data = self.chunk_cache.get(chunk_id)
        if cached_data is not None:
            self.metrics.cache_hits += 1
            return cached_data

        self.metrics.cache_misses += 1

        # Cargar desde IPFS
        try:
            if ipfs_cid:
                self._chunk_cid_map[chunk_id] = ipfs_cid
                data = await self.ipfs_manager.get_data(ipfs_cid)
            else:
                data = await self._load_chunk_from_ipfs(chunk_id)

            if data:
                # Almacenar en cache
                self.chunk_cache.put(chunk_id, data)
                return data

        except Exception as e:
            logger.warning(f"Error cargando chunk {chunk_id}: {e}")

        return None

    async def _queue_prefetch(self, chunk_id: str, priority: float):
        """Cola un chunk para prefetching."""
        with self.prefetch_lock:
            if chunk_id not in self.active_prefetches:
                self.active_prefetches.add(chunk_id)
                await self.prefetch_queue.put((chunk_id, priority))

    async def _prefetch_worker(self):
        """Worker que maneja el prefetching asíncrono."""
        semaphore = asyncio.Semaphore(self.max_concurrent)

        while self.running:
            try:
                # Obtener siguiente chunk para prefetch
                chunk_id, priority = await self.prefetch_queue.get()

                # Ejecutar prefetch con semáforo
                asyncio.create_task(self._execute_prefetch(chunk_id, priority, semaphore))

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error en prefetch worker: {e}")
                await asyncio.sleep(1)

    async def _execute_prefetch(self, chunk_id: str, priority: float, semaphore: asyncio.Semaphore):
        """Ejecuta el prefetching de un chunk."""
        async with semaphore:
            start_time = time.time()

            try:
                # Cargar chunk desde IPFS
                data = await self._load_chunk_from_ipfs(chunk_id)

                if data:
                    # Almacenar en cache con prioridad
                    self.chunk_cache.put(chunk_id, data, priority)

                    # Actualizar métricas
                    prefetch_time = time.time() - start_time
                    self.metrics.average_prefetch_time = (
                        (self.metrics.average_prefetch_time * self.metrics.total_prefetched_chunks + prefetch_time) /
                        (self.metrics.total_prefetched_chunks + 1)
                    )
                    self.metrics.total_prefetched_chunks += 1

                    logger.debug(f"✅ Prefetched chunk {chunk_id} en {prefetch_time:.3f}s")

            except Exception as e:
                logger.warning(f"Error prefetching chunk {chunk_id}: {e}")

            finally:
                with self.prefetch_lock:
                    self.active_prefetches.discard(chunk_id)

    async def _load_chunk_from_ipfs(self, chunk_id: str) -> Optional[bytes]:
        """Carga un chunk desde IPFS usando mapping real de chunk_id -> CID."""
        try:
            cid = await self._resolve_chunk_id_to_cid(chunk_id)
            if not cid:
                message = f"No se pudo resolver CID para chunk_id={chunk_id}"
                if self.strict_chunk_ids:
                    raise ValueError(message)
                logger.warning(message)
                return None

            return await self.ipfs_manager.get_data(cid)
        except Exception as e:
            logger.error(f"Error cargando IPFS para {chunk_id}: {e}")
            return None

    async def _resolve_chunk_id_to_cid(self, chunk_id: str) -> Optional[str]:
        if self._looks_like_cid(chunk_id):
            return chunk_id

        if self.chunk_id_resolver is not None:
            resolved = self.chunk_id_resolver(chunk_id)
            if inspect.isawaitable(resolved):
                resolved = await resolved
            if resolved:
                return resolved

        await self._load_chunk_manifest()

        mapped = self._chunk_cid_map.get(chunk_id)
        if mapped:
            return mapped

        index = self._extract_chunk_index(chunk_id)
        if index is not None and self._chunk_cids and 0 <= index < len(self._chunk_cids):
            cid = self._chunk_cids[index]
            self._chunk_cid_map[chunk_id] = cid
            return cid

        return None

    async def _load_chunk_manifest(self):
        if self._chunk_manifest is not None or not self.chunk_manifest_cid:
            return

        async with self._manifest_lock:
            if self._chunk_manifest is not None or not self.chunk_manifest_cid:
                return
            raw = await self.ipfs_manager.get_data(self.chunk_manifest_cid)
            manifest = json.loads(raw.decode("utf-8"))

            chunk_cids = manifest.get("chunk_cids")
            if not isinstance(chunk_cids, list) or not chunk_cids:
                raise ValueError("El manifiesto de chunks no contiene chunk_cids validos.")

            self._chunk_manifest = manifest
            self._chunk_cids = [str(cid) for cid in chunk_cids]
            for idx, cid in enumerate(self._chunk_cids):
                self._chunk_cid_map.setdefault(f"chunk_{idx}", cid)
                self._chunk_cid_map.setdefault(f"chunk_{idx:06d}", cid)
                self._chunk_cid_map.setdefault(str(idx), cid)

    @staticmethod
    def _looks_like_cid(chunk_id: str) -> bool:
        if chunk_id.startswith("Qm") and len(chunk_id) > 20:
            return True
        if chunk_id.startswith("baf") and len(chunk_id) > 20:
            return True
        if chunk_id.startswith("k51") and len(chunk_id) > 20:
            return True
        return False

    @staticmethod
    def _extract_chunk_index(chunk_id: str) -> Optional[int]:
        if chunk_id.isdigit():
            return int(chunk_id)
        if chunk_id.startswith("chunk_"):
            suffix = chunk_id.split("_", 1)[1]
            if suffix.isdigit():
                return int(suffix)
        return None

    def train_predictive_model(self, epochs: int = 10, batch_size: int = 32):
        """
        Entrena el modelo predictivo con datos históricos de acceso.

        Args:
            epochs: Número de epochs de entrenamiento
            batch_size: Tamaño del batch
        """
        # Preparar datos de entrenamiento
        training_data = []

        with self.patterns_lock:
            for pattern in self.chunk_patterns.values():
                if len(pattern.context_embeddings) > 0:
                    # Crear targets one-hot
                    target = torch.zeros(self.num_chunks)
                    chunk_idx = int(pattern.chunk_id.split('_')[1]) if '_' in pattern.chunk_id else 0
                    target[chunk_idx] = 1.0

                    for context_emb in pattern.context_embeddings:
                        training_data.append((context_emb, target))

        if not training_data:
            logger.warning("No hay suficientes datos para entrenar el modelo predictivo")
            return

        # Entrenar
        self.predictive_model.train()
        for epoch in range(epochs):
            total_loss = 0.0
            batches = 0

            # Shuffle data
            import random
            random.shuffle(training_data)

            for i in range(0, len(training_data), batch_size):
                batch = training_data[i:i+batch_size]
                contexts = torch.stack([item[0] for item in batch])
                targets = torch.stack([item[1] for item in batch])

                loss = self.predictive_model.train_step(contexts, targets)
                total_loss += loss
                batches += 1

            avg_loss = total_loss / batches if batches > 0 else 0
            logger.info(f"Epoch {epoch+1}/{epochs}, Loss: {avg_loss:.4f}")

    def get_metrics(self) -> Dict[str, Any]:
        """Retorna métricas completas del sistema."""
        cache_stats = self.chunk_cache.get_stats()

        return {
            "predictive_metrics": {
                "total_predictions": self.metrics.total_predictions,
                "correct_predictions": self.metrics.correct_predictions,
                "false_positives": self.metrics.false_positives,
                "prediction_accuracy": (
                    self.metrics.correct_predictions / self.metrics.total_predictions
                    if self.metrics.total_predictions > 0 else 0
                ),
                "average_prefetch_time": self.metrics.average_prefetch_time,
                "total_prefetched_chunks": self.metrics.total_prefetched_chunks,
            },
            "cache_metrics": cache_stats,
            "system_metrics": {
                "active_prefetches": len(self.active_prefetches),
                "tracked_patterns": len(self.chunk_patterns),
                "prefetch_queue_size": self.prefetch_queue.qsize(),
            }
        }


# Función factory
def create_predictive_prefetcher(
    ipfs_manager: IPFSManager,
    num_chunks: int = 1000,
    prefetch_batch_size: int = 10,
    max_concurrent_prefetches: int = 5,
    cache_memory_mb: int = 512,
    device: str = "cuda" if torch.cuda.is_available() else "cpu",
    chunk_manifest_cid: Optional[str] = None,
    chunk_id_resolver: Optional[Callable[[str], Optional[str]]] = None,
    chunk_id_map: Optional[Dict[str, str]] = None
) -> PredictivePrefetcher:
    """
    Factory function para crear un prefetcher predictivo.

    Args:
        ipfs_manager: Gestor de IPFS
        num_chunks: Número total de chunks
        prefetch_batch_size: Tamaño del batch de prefetch
        max_concurrent_prefetches: Máximo de prefetches concurrentes
        cache_memory_mb: Memoria máxima del cache en MB
        device: Dispositivo para el modelo
        chunk_manifest_cid: CID del manifiesto de chunks
        chunk_id_resolver: Resolver externo de chunk_id a CID
        chunk_id_map: Mapping inicial chunk_id -> CID

    Returns:
        PredictivePrefetcher instance
    """
    return PredictivePrefetcher(
        ipfs_manager=ipfs_manager,
        num_chunks=num_chunks,
        prefetch_batch_size=prefetch_batch_size,
        max_concurrent_prefetches=max_concurrent_prefetches,
        cache_memory_mb=cache_memory_mb,
        device=device,
        chunk_manifest_cid=chunk_manifest_cid,
        chunk_id_resolver=chunk_id_resolver,
        chunk_id_map=chunk_id_map
    )
