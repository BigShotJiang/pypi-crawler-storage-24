import pytest

from .rewards_manager import RewardsManager


class _BridgeStub:
    def __init__(self):
        self.report_calls = []
        self.claim_calls = []

    async def report_work(self, node_id, units, operation_id=None):
        self.report_calls.append((node_id, units, operation_id))
        return {"success": True, "tx_hash": "0xabc"}

    async def get_pending_rewards(self, node_id):
        return {"success": True, "pending_amount": "10"}

    async def claim_rewards(self, node_id, operation_id=None):
        self.claim_calls.append((node_id, operation_id))
        return {"success": True, "tx_hash": "0xclaim", "amount": "10"}


@pytest.mark.asyncio
async def test_process_proof_deduplicates_operation_id(monkeypatch):
    monkeypatch.setenv("AILOOS_REWARDS_BRIDGE_ONLY", "1")
    bridge = _BridgeStub()
    manager = RewardsManager(bridge_client=bridge)

    payload = {"valid": True, "proof_id": "proof-1"}
    r1 = await manager.process_proof("proof_of_compute", payload, "node_a")
    r2 = await manager.process_proof("proof_of_compute", payload, "node_a")

    assert r1["success"] is True
    assert r2["success"] is True
    assert "Duplicate" in r2["reason"]
    assert len(bridge.report_calls) == 1


@pytest.mark.asyncio
async def test_claim_node_rewards_deduplicates_operation_id(monkeypatch):
    monkeypatch.setenv("AILOOS_REWARDS_BRIDGE_ONLY", "1")
    bridge = _BridgeStub()
    manager = RewardsManager(bridge_client=bridge)

    r1 = await manager.claim_node_rewards("node_a", operation_id="claim-op-1")
    r2 = await manager.claim_node_rewards("node_a", operation_id="claim-op-1")

    assert r1["success"] is True
    assert r2["success"] is True
    assert r2["claim"].status == "duplicate_ignored"
    assert len(bridge.claim_calls) == 1
