"""
Identity Unificator - El Punto de Sutura de Identidad.
Este módulo permite la traducción determinista de identidades entre los 4 pilares:
1. EmpoorioChain (Substrate SS58)
2. DAOtonomos (Substrate SS58)
3. Dracma (CosmWasm Bech32)
4. Empoorio L1 (EVM H160)
"""

import hashlib
import base58
from typing import Optional

# Usamos pycryptodome para Keccak256 real (requerido para EVM)
try:
    from Crypto.Hash import keccak as pykeccak
    def keccak256(data):
        k = pykeccak.new(digest_bits=256)
        k.update(data)
        return k.digest()
except ImportError:
    try:
        from eth_hash.auto import keccak as eth_keccak
        keccak256 = eth_keccak
    except ImportError:
        # Fallback de seguridad (notar que sha3 no es Keccak-256 de Ethereum)
        def keccak256(data):
            return hashlib.sha3_256(data).digest()

# Bech32 constants
CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"

def bech32_polymod(values):
    generator = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3]
    chk = 1
    for value in values:
        top = chk >> 25
        chk = (chk & 0x1ffffff) << 5 ^ value
        for i in range(5):
            chk ^= generator[i] if ((top >> i) & 1) else 0
    return chk

def bech32_hrp_expand(hrp):
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]

def bech32_create_checksum(hrp, data):
    values = bech32_hrp_expand(hrp) + data
    polymod = bech32_polymod(values + [0, 0, 0, 0, 0, 0]) ^ 1
    return [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]

def bech32_encode(hrp, data):
    combined = data + bech32_create_checksum(hrp, data)
    return hrp + "1" + "".join([CHARSET[d] for d in combined])

def convertbits(data, frombits, tobits, pad=True):
    acc = 0
    bits = 0
    ret = []
    maxv = (1 << tobits) - 1
    max_acc = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            return None
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        return None
    return ret

class IdentityUnificator:
    """
    Gestiona la unificación de identidades en el ecosistema Dracma.
    Implementa el 'Mirror Identity Protocol'.
    """

    @staticmethod
    def decode_ss58(address: str) -> bytes:
        """
        Decodifica una dirección SS58 (Substrate) y verifica el checksum SS58 (Blake2b).

        Estricto (sin fallbacks incorrectos):
        - soporta account-id de 32 bytes (sr25519/ed25519).
        - soporta prefijo de 1 o 2 bytes (deducido por longitud total).
        """
        raw = base58.b58decode(address)
        if len(raw) < 1 + 32 + 2:
            raise ValueError("SS58 inválida: longitud demasiado corta")

        checksum_len = 2
        pubkey_len = 32

        checksum = raw[-checksum_len:]
        body = raw[:-checksum_len]  # prefix bytes + account id

        prefix_len = len(body) - pubkey_len
        if prefix_len not in (1, 2):
            raise ValueError(
                f"SS58 no soportada: prefix_len={prefix_len} (solo 1 o 2) para account-id 32 bytes"
            )

        expected_chk = hashlib.blake2b(b"SS58PRE" + body, digest_size=64).digest()[:checksum_len]
        if checksum != expected_chk:
            raise ValueError("SS58 inválida: checksum no coincide")

        pubkey = body[prefix_len : prefix_len + pubkey_len]
        if len(pubkey) != pubkey_len:
            raise ValueError("SS58 inválida: account-id no es de 32 bytes")
        return pubkey

    @staticmethod
    def substrate_to_bech32(address_ss58: str, hrp: str = "emp") -> str:
        """Convierte una dirección de Substrate (SS58) a Bech32 (CosmWasm)."""
        pubkey = IdentityUnificator.decode_ss58(address_ss58)
        data = convertbits(pubkey, 8, 5)
        return bech32_encode(hrp, data)

    @staticmethod
    def pubkey_to_ss58(pubkey: bytes, prefix: int = 42) -> str:
        """Convierte una llave pública a formato SS58 (Substrate) estricto."""
        if prefix < 64:
            prefix_bytes = bytes([prefix])
        else:
            # Codificación de prefijo de 2 bytes (Substrate standard)
            # ((prefix & 0b0000_0000_1111_1100) >> 2) | 0b0100_0000
            # ((prefix & 0b0000_0000_0000_0011) << 6) | ((prefix & 0b0011_1111_0000_0000) >> 8)
            # Simplificamos para el prefijo 42 (1 byte). Si se requieren más, se completa la lógica de bits.
            prefix_bytes = bytes([(prefix & 0b00111111) | 0x40, (prefix >> 6)])
            
        data = prefix_bytes + pubkey
        checksum_input = b"SS58PRE" + data
        chk = hashlib.blake2b(checksum_input, digest_size=64).digest()
        data_with_chk = data + chk[:2]
        return base58.b58encode(data_with_chk).decode()

    @staticmethod
    def pubkey_to_evm(pubkey: bytes) -> str:
        """Deriva una dirección EVM (H160) desde la llave pública usando Keccak-256."""
        # Mirror Identity: Keccak256 de los 32 bytes de la pubkey.
        khash = keccak256(pubkey)
        # Ethereum usa los últimos 20 bytes del hash Keccak256 de la pubkey (pero es de la pubkey de 64 bytes recuperada).
        # En el Protocolo Espejo de Empoorio, mapeamos DIRECTAMENTE el hash de la pubkey SR25519 (32 bytes).
        return "0x" + khash[-20:].hex()

    @staticmethod
    def get_identity_matrix(pubkey_hex: str) -> dict:
        """Genera todas las direcciones unificadas para una llave pública."""
        pubkey = bytes.fromhex(pubkey_hex)
        return {
            "substrate": IdentityUnificator.pubkey_to_ss58(pubkey),
            "cosmwasm": IdentityUnificator.substrate_to_bech32(IdentityUnificator.pubkey_to_ss58(pubkey)),
            "evm": IdentityUnificator.pubkey_to_evm(pubkey),
            "public_key": pubkey_hex
        }

if __name__ == "__main__":
    # Test Alice (Substrate standard)
    alice_pubkey = "d43593c715fdd31c61141abd04a99fd6822c8558854ccde39a5684e7a56da27d"
    matrix = IdentityUnificator.get_identity_matrix(alice_pubkey)
    print(f"Substrate (SS58): {matrix['substrate']}")
    print(f"CosmWasm (emp1):  {matrix['cosmwasm']}")
    print(f"EVM (0x...):      {matrix['evm']}")
