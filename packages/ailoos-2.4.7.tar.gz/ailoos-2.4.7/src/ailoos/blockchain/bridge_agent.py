"""
Bridge Agent (testnet pública)

Runner mínimo para wiring E2E en producción/testnet:
- report_work
- node staking
- claim_rewards

NO es el “runtime completo” de Ailoos; es un agente operacional para mantener
el flujo Ailoos↔Bridge real mientras evolucionas el runtime principal.

Ejecución:
  PYTHONPATH=Ailoos/src \
  AILOOS_BRIDGE_CLIENT_MODE=rust \
  DRACMA_BRIDGE_URL=https://bridge.testnet... \
  AILOOS_BRIDGE_PRIVATE_KEY=0x... \
  AILOOS_NODE_ID=12D3KooW... \
  python3 -m ailoos.blockchain.bridge_agent
"""

from __future__ import annotations

import asyncio
import os
import time

from .bridge_client import get_bridge_client


def _env(name: str, default: str = "") -> str:
    v = os.getenv(name, default).strip()
    if not v:
        raise SystemExit(f"Falta variable: {name}")
    return v


async def run_once() -> None:
    client = get_bridge_client()
    node_id = _env("AILOOS_NODE_ID")

    do_report = os.getenv("AILOOS_DO_REPORT_WORK", "1") == "1"
    do_claim = os.getenv("AILOOS_DO_CLAIM", "0") == "1"
    do_stake = os.getenv("AILOOS_DO_NODE_STAKE", "0") == "1"

    units = int(os.getenv("AILOOS_WORK_UNITS", "1"))
    stake_amt = os.getenv("AILOOS_NODE_STAKE_AMOUNT_BASE", "0").strip()

    pending_before = await client.get_pending_rewards(node_id)
    print("pending_before:", pending_before, flush=True)

    if do_report:
        res = await client.report_work(node_id, units)
        print("report_work:", res, flush=True)

    if do_stake:
        if stake_amt in ("", "0"):
            raise SystemExit("AILOOS_NODE_STAKE_AMOUNT_BASE debe ser > 0 (base units)")
        res = await client.stake_node_tokens(node_id, stake_amt)
        print("stake_node_tokens:", res, flush=True)

    pending_after = await client.get_pending_rewards(node_id)
    print("pending_after:", pending_after, flush=True)

    if do_claim:
        res = await client.claim_rewards(node_id)
        print("claim_rewards:", res, flush=True)

    pending_final = await client.get_pending_rewards(node_id)
    print("pending_final:", pending_final, flush=True)


async def main() -> None:
    interval = int(os.getenv("AILOOS_AGENT_INTERVAL_S", "30"))
    while True:
        await run_once()
        time.sleep(interval)


if __name__ == "__main__":
    asyncio.run(main())

