"""
Blockchain infrastructure para AILOOS.
Incluye blockchain completa con proof-of-work real, criptografía asimétrica y gestión de tokens DRACMA.
"""

# Importes "best-effort": algunos submódulos (p.ej. `core`) dependen de
# dependencias opcionales como `cryptography`. Para permitir que el ecosistema
# ejecute smoke tests (bridge_client, rewards_manager, etc.) sin instalar todo
# el stack, no fallamos en import-time.

try:
    from .core import (
        Blockchain,
        Block,
        Transaction,
        Wallet,
        get_blockchain,
        create_transaction,
        send_transaction,
        generate_keypair,
        address_from_public_key,
    )
except Exception:  # pragma: no cover
    Blockchain = Block = Transaction = Wallet = None  # type: ignore
    get_blockchain = create_transaction = send_transaction = None  # type: ignore
    generate_keypair = address_from_public_key = None  # type: ignore

try:
    from .dracma_token import (
        dracmaManager,
        get_token_manager,
        initialize_dracma_infrastructure,
        TokenConfig,
        TokenStandard,
        NetworkType,
        TransactionResult,
    )
except Exception:  # pragma: no cover
    dracmaManager = get_token_manager = initialize_dracma_infrastructure = None  # type: ignore
    TokenConfig = TokenStandard = NetworkType = TransactionResult = None  # type: ignore

__all__ = [name for name in list(globals().keys()) if not name.startswith("_")]
