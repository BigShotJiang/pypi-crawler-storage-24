"""
Bridge Client - Cliente HTTP para comunicarse con el puente Rust Dracma
"""

import asyncio
import json
import os
import time
import uuid
from typing import Dict, Any, Optional, Union

# Dependencias opcionales. Si no están instaladas, este cliente no podrá usarse,
# pero el ecosistema sigue funcionando con `bridge_client_rust.py`.
_HAS_PY_BRIDGE_DEPS = True
try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    from eth_account import Account
    from eth_account.signers.local import LocalAccount
    from eth_account.messages import encode_defunct
except Exception:  # pragma: no cover
    _HAS_PY_BRIDGE_DEPS = False
    requests = None  # type: ignore
    HTTPAdapter = None  # type: ignore
    Retry = None  # type: ignore
    Account = None  # type: ignore
    LocalAccount = None  # type: ignore
    encode_defunct = None  # type: ignore
from decimal import Decimal, InvalidOperation

# Logging: fallback to stdlib if Ailoos core deps (pyyaml, etc.) are not installed.
try:
    from ..core.logging import get_logger  # type: ignore
    logger = get_logger(__name__)
except Exception:  # pragma: no cover
    import logging
    logger = logging.getLogger(__name__)


class BridgeClientError(Exception):
    """Error del cliente del puente."""
    pass


class BridgeClient:
    """
    Cliente HTTP para el puente cross-chain Dracma.

    Maneja autenticación, firmas, retry logic y comunicación con el puente Rust.
    """

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        timeout: int = 30,
        fallback_urls: Optional[list[str]] = None,
    ):
        """
        Inicializar cliente del puente.

        Args:
            base_url: URL base del puente (ej: http://localhost:3000)
            api_key: Clave API opcional para autenticación
            timeout: Timeout en segundos para requests
        """
        if not _HAS_PY_BRIDGE_DEPS:
            raise BridgeClientError(
                "Dependencias Python del bridge no disponibles (requests/eth_account). "
                "Usa BridgeClientRust (AILOOS_BRIDGE_CLIENT_MODE=rust) o instala Ailoos/requirements.txt."
            )

        self.base_url = base_url.rstrip('/')
        self.fallback_urls = [u.rstrip("/") for u in (fallback_urls or []) if u]
        self.api_key = api_key
        self.timeout = timeout

        # Configurar sesión con retry
        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,
            status_forcelist=[429, 500, 502, 503, 504],
            backoff_factor=1
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

        # Headers comunes
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': 'Ailoos-Bridge-Client/1.0'
        })

        if self.api_key:
            self.session.headers.update({'X-API-Key': self.api_key})

        # Optional HTTP Basic Auth for bridge deployments protected at proxy level.
        basic_user = (
            os.getenv("DRACMA_BRIDGE_BASIC_AUTH_USER")
            or os.getenv("BRIDGE_BASIC_AUTH_USER")
        )
        basic_pass = (
            os.getenv("DRACMA_BRIDGE_BASIC_AUTH_PASS")
            or os.getenv("BRIDGE_BASIC_AUTH_PASS")
        )
        if basic_user and basic_pass:
            self.session.auth = (basic_user, basic_pass)

        # Cargar signer si hay private key
        self.signer: Optional[LocalAccount] = None
        private_key = self._get_private_key()
        if private_key:
            self.signer = Account.from_key(private_key)

        logger.info(
            f"🔗 Bridge client initialized for {base_url}"
            f" (fallbacks={len(self.fallback_urls)})"
            f" (basic_auth={'on' if basic_user and basic_pass else 'off'})"
        )

    def _get_private_key(self) -> Optional[str]:
        """Obtener private key de entorno."""
        return os.getenv('AILOOS_BRIDGE_PRIVATE_KEY')

    def _sign_message(self, message: str) -> str:
        """Firmar mensaje con EIP-191 (Ethereum Signed Message)."""
        if not self.signer:
            raise BridgeClientError("No private key available for signing")

        signable = encode_defunct(text=message)
        signed = self.signer.sign_message(signable)
        signature = signed.signature.hex()
        if os.getenv("AILOOS_BRIDGE_SIG_HEX_PREFIX", "").lower() in ("1", "true", "yes"):
            return signature
        return signature[2:] if signature.startswith("0x") else signature

    def _to_base_units(self, amount: Union[str, int, float], decimals: int = 18) -> str:
        """
        Convert an amount (human or base) into base units string.

        If `amount` looks like an integer string/int, it is treated as already-base-units.
        If it contains a decimal point, we convert using Decimal with the provided `decimals`.
        """
        if isinstance(amount, int):
            return str(amount)
        if isinstance(amount, float):
            # Convert via string to reduce binary float surprises.
            amount = str(amount)
        if not isinstance(amount, str):
            raise BridgeClientError("Invalid amount type")

        s = amount.strip()
        if not s:
            raise BridgeClientError("Amount is required")

        # Already base units if it's a pure integer.
        if s.isdigit():
            return s

        try:
            d = Decimal(s)
        except InvalidOperation as e:
            raise BridgeClientError(f"Invalid amount: {amount}") from e

        scale = Decimal(10) ** decimals
        base = int((d * scale).to_integral_value(rounding="ROUND_DOWN"))
        if base < 0:
            raise BridgeClientError("Amount must be non-negative")
        return str(base)

    @staticmethod
    def _new_operation_id(prefix: str) -> str:
        return f"{prefix}-{int(time.time())}-{uuid.uuid4().hex[:12]}"

    def _make_request(self, method: str, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Hacer request HTTP con manejo de errores.

        Args:
            method: Método HTTP
            endpoint: Endpoint relativo
            data: Datos JSON a enviar

        Returns:
            Respuesta JSON

        Raises:
            BridgeClientError: En caso de error
        """
        base_candidates = [self.base_url] + self.fallback_urls
        last_error = "unknown error"

        for idx, base in enumerate(base_candidates):
            url = f"{base}{endpoint}"
            try:
                if data:
                    response = self.session.request(method, url, json=data, timeout=self.timeout)
                else:
                    response = self.session.request(method, url, timeout=self.timeout)

                if response.status_code >= 500 and idx < len(base_candidates) - 1:
                    logger.warning(
                        "Bridge endpoint %s returned %s; trying fallback #%d",
                        url,
                        response.status_code,
                        idx + 1,
                    )
                    continue

                response.raise_for_status()

                if response.content:
                    result = response.json()
                else:
                    result = {}

                if not result.get('success', False):
                    error_msg = result.get('error', 'Unknown bridge error')
                    raise BridgeClientError(f"Bridge error: {error_msg}")

                if base != self.base_url:
                    logger.warning("Bridge primary switched to fallback: %s", base)
                    self.base_url = base
                return result

            except json.JSONDecodeError as e:
                last_error = f"Invalid JSON response from {url}: {e}"
                logger.error(last_error)
            except requests.exceptions.RequestException as e:
                last_error = f"HTTP error calling {url}: {e}"
                logger.error(last_error)
            except Exception as e:
                last_error = f"Unexpected error calling {url}: {e}"
                logger.error(last_error)

        raise BridgeClientError(last_error)

    async def register_node(
        self,
        node_id: str,
        cpu_score: int,
        gpu_score: int,
        ram_gb: int,
        location: str,
        owner: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Registrar un nuevo nodo en Dracma.

        Args:
            node_id: ID único del nodo
            cpu_score: Puntaje CPU
            gpu_score: Puntaje GPU
            ram_gb: RAM en GB
            location: Ubicación del nodo

        Returns:
            Resultado del registro
        """
        # Crear mensaje para firma
        owner_value = owner or ""
        message = f"register_node:{node_id}{cpu_score}{gpu_score}{ram_gb}{location}{owner_value}"

        # Firmar
        signature = self._sign_message(message)

        # Preparar payload
        payload = {
            "node_id": node_id,
            "cpu_score": cpu_score,
            "gpu_score": gpu_score,
            "ram_gb": ram_gb,
            "location": location,
            "owner": owner,
            "signature": signature
        }

        # Hacer request
        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/register_node_from_ailoos', payload
        )

        logger.info(f"✅ Node {node_id} registered via bridge")
        return result

    async def report_work(self, node_id: str, units: int, operation_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Reportar trabajo realizado por un nodo.

        Args:
            node_id: ID del nodo
            units: Unidades de trabajo realizadas

        Returns:
            Resultado del reporte
        """
        # Crear mensaje para firma
        message = f"report_work:{node_id}{units}"

        # Firmar
        signature = self._sign_message(message)

        # Preparar payload
        payload = {
            "node_id": node_id,
            "units": units,
            "signature": signature
        }
        payload["operation_id"] = operation_id or self._new_operation_id("report")

        # Hacer request
        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/report_work_from_ailoos', payload
        )

        logger.info(f"✅ Work reported for node {node_id}: {units} units")
        return result

    async def validate_proof(self, node_id: str, dataset_id: str, compute_power: int,
                           proof: bytes, model_hash: str, expected_accuracy: str) -> Dict[str, Any]:
        """
        Validar proof de entrenamiento.

        Args:
            node_id: ID del nodo
            dataset_id: ID del dataset
            compute_power: Poder computacional usado
            proof: Proof de entrenamiento (bytes)
            model_hash: Hash del modelo resultante
            expected_accuracy: Precisión esperada

        Returns:
            Resultado de la validación
        """
        # Crear mensaje para firma
        message = f"validate_proof:{node_id}{dataset_id}{compute_power}{model_hash}{expected_accuracy}"

        # Firmar
        signature = self._sign_message(message)

        # Preparar payload
        payload = {
            "node_id": node_id,
            "dataset_id": dataset_id,
            "compute_power": str(compute_power),  # Como string para compatibilidad
            "proof": list(proof),  # Convertir bytes a lista
            "model_hash": model_hash,
            "expected_accuracy": expected_accuracy,
            "signature": signature
        }

        # Hacer request
        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/validate_proof_from_ailoos', payload
        )

        logger.info(f"✅ Proof validated for node {node_id} on dataset {dataset_id}")
        return result

    async def claim_rewards(self, node_id: str, operation_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Reclamar recompensas para un nodo.

        Args:
            node_id: ID del nodo

        Returns:
            Resultado del claim
        """
        # Crear mensaje para firma
        message = f"claim_rewards:{node_id}"

        # Firmar
        signature = self._sign_message(message)

        # Preparar payload
        payload = {
            "node_id": node_id,
            "signature": signature
        }
        payload["operation_id"] = operation_id or self._new_operation_id("claim")

        # Hacer request
        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/claim_rewards_from_ailoos', payload
        )

        logger.info(f"✅ Rewards claimed for node {node_id}")
        return result

    async def get_pending_rewards(self, node_id: str) -> Dict[str, Any]:
        """
        Consultar recompensas pendientes para un nodo.

        Args:
            node_id: ID del nodo

        Returns:
            Resultado con recompensas pendientes
        """
        message = f"pending_rewards:{node_id}"
        signature = self._sign_message(message)

        payload = {
            "node_id": node_id,
            "signature": signature
        }

        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/pending_rewards_from_ailoos', payload
        )

        logger.info(f"✅ Pending rewards requested for node {node_id}")
        return result

    async def get_wallet_balance(self, address: str) -> Dict[str, Any]:
        """
        Consultar balance de una wallet via bridge.

        Args:
            address: Direccion de la wallet

        Returns:
            Resultado con balance
        """
        message = f"wallet_balance:{address}"
        signature = self._sign_message(message)

        payload = {
            "address": address,
            "signature": signature
        }

        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/wallet_balance_from_ailoos', payload
        )

        logger.info(f"✅ Wallet balance requested for {address}")
        return result

    async def get_staking_info(self, address: str) -> Dict[str, Any]:
        """
        Consultar informacion de staking via bridge.

        Args:
            address: Direccion de la wallet

        Returns:
            Resultado con staking info
        """
        message = f"staking_info:{address}"
        signature = self._sign_message(message)

        payload = {
            "address": address,
            "signature": signature
        }

        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/staking_info_from_ailoos', payload
        )

        logger.info(f"✅ Staking info requested for {address}")
        return result

    async def get_transaction_history(self, address: str, limit: int = 50) -> Dict[str, Any]:
        """
        Consultar historial de transacciones via bridge.

        Args:
            address: Direccion de la wallet
            limit: Numero maximo de transacciones

        Returns:
            Resultado con historial
        """
        message = f"wallet_history:{address}:{limit}"
        signature = self._sign_message(message)

        payload = {
            "address": address,
            "limit": limit,
            "signature": signature
        }

        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/wallet_history_from_ailoos', payload
        )

        logger.info(f"✅ Wallet history requested for {address}")
        return result

    async def get_rewards_totals(self) -> Dict[str, Any]:
        """
        Consultar totales globales de rewards via bridge.

        Returns:
            Resultado con totales
        """
        message = "rewards_totals"
        signature = self._sign_message(message)

        payload = {
            "signature": signature
        }

        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/rewards_totals_from_ailoos', payload
        )

        logger.info("✅ Rewards totals requested")
        return result

    async def get_bridge_signer_address(self) -> Dict[str, Any]:
        """
        Obtener la direccion cosmos del signer del bridge.
        """
        message = "bridge_signer_address"
        signature = self._sign_message(message)
        payload = {"signature": signature}

        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/bridge_signer_address_from_ailoos', payload
        )
        logger.info("✅ Bridge signer address requested")
        return result

    async def register_bridge_signer_system_account(self) -> Dict[str, Any]:
        """
        Registrar el signer del bridge como system account en la chain.
        """
        message = "register_bridge_signer"
        signature = self._sign_message(message)
        payload = {"signature": signature}

        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/register_bridge_signer_from_ailoos', payload
        )
        logger.info("✅ Bridge signer registered as system account")
        return result

    async def stake_tokens(self, amount: Union[str, int, float], address: str) -> Dict[str, Any]:
        """
        Stakear tokens en Dracma a través del puente.

        Args:
            amount: Cantidad a stakear
            address: Dirección del usuario

        Returns:
            Resultado del staking
        """
        amount_base = self._to_base_units(amount)
        # Crear mensaje para firma (base units)
        message = f"stake:{amount_base}:{address}"

        # Firmar
        signature = self._sign_message(message)

        # Preparar payload
        payload = {
            "amount": amount_base,
            "address": address,
            "signature": signature
        }

        # Hacer request (asumiendo endpoint /stake_from_ailoos)
        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/stake_from_ailoos', payload
        )

        logger.info(f"✅ Tokens staked via bridge: {amount_base} (base) for {address}")
        return result

    async def unstake_tokens(self, amount: Union[str, int, float], address: str) -> Dict[str, Any]:
        """
        Unstakear tokens de Dracma a través del puente.

        Args:
            amount: Cantidad a unstakear
            address: Dirección del usuario

        Returns:
            Resultado del unstaking
        """
        amount_base = self._to_base_units(amount)
        # Crear mensaje para firma (base units)
        message = f"unstake:{amount_base}:{address}"

        # Firmar
        signature = self._sign_message(message)

        # Preparar payload
        payload = {
            "amount": amount_base,
            "address": address,
            "signature": signature
        }

        # Hacer request (asumiendo endpoint /unstake_from_ailoos)
        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, 'POST', '/unstake_from_ailoos', payload
        )

        logger.info(f"✅ Tokens unstaked via bridge: {amount_base} (base) for {address}")
        return result

    async def stake_node_tokens(self, node_id: str, amount: Union[str, int, float]) -> Dict[str, Any]:
        """
        Stake tokens for an Ailoos node via the bridge (node staking).

        IMPORTANT: `amount` should be an integer string in base units (18 decimals),
        matching the Dracma contract JSON format for Uint128.
        """
        if not node_id:
            raise BridgeClientError("node_id is required")
        amount_base = self._to_base_units(amount)
        message = f"stake_node:{node_id}:{amount_base}"
        signature = self._sign_message(message)
        payload = {"node_id": node_id, "amount": amount_base, "signature": signature}
        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, "POST", "/stake_node_from_ailoos", payload
        )
        logger.info(f"✅ Node staked via bridge: {node_id} amount_base={amount_base}")
        return result

    async def unstake_node_tokens(self, node_id: str, amount: Union[str, int, float]) -> Dict[str, Any]:
        """
        Unstake tokens from an Ailoos node via the bridge (node staking).

        `amount` should be base units (Uint128 string/int).
        """
        if not node_id:
            raise BridgeClientError("node_id is required")
        amount_base = self._to_base_units(amount)
        message = f"unstake_node:{node_id}:{amount_base}"
        signature = self._sign_message(message)
        payload = {"node_id": node_id, "amount": amount_base, "signature": signature}
        result = await asyncio.get_event_loop().run_in_executor(
            None, self._make_request, "POST", "/unstake_node_from_ailoos", payload
        )
        logger.info(f"✅ Node unstaked via bridge: {node_id} amount_base={amount_base}")
        return result

    async def get_bridge_status(self) -> Dict[str, Any]:
        """
        Obtener estado del puente.

        Returns:
            Información del estado
        """
        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None, self._make_request, 'GET', '/status'
            )
            return result
        except BridgeClientError:
            # Si no hay endpoint de status, devolver info básica
            return {
                "status": "unknown",
                "bridge_url": self.base_url,
                "has_signer": self.signer is not None
            }

    def close(self):
        """Cerrar sesión HTTP."""
        self.session.close()
        logger.info("🔌 Bridge client connection closed")


# Instancia global del cliente
_bridge_client: Optional[BridgeClient] = None


def get_bridge_client() -> BridgeClient:
    """Obtener instancia global del cliente del puente."""
    global _bridge_client
    if _bridge_client is None:
        mode = (os.getenv("AILOOS_BRIDGE_CLIENT_MODE") or "auto").lower()  # auto|python|rust
        env = (os.getenv("AILOOS_ENV") or "").lower()
        is_strict = env in {"prod", "production", "staging", "testnet"}

        base_url = (
            os.getenv("DRACMA_BRIDGE_URL")
            or os.getenv("dracma_BRIDGE_URL")
            or os.getenv("BRIDGE_URL")
            or ("http://127.0.0.1:8080" if not is_strict else "")
        )
        api_key = os.getenv("DRACMA_BRIDGE_API_KEY") or os.getenv("dracma_BRIDGE_API_KEY")
        fallback_urls: list[str] = []
        for key in ("DRACMA_BRIDGE_URL_FALLBACK", "DRACMA_BRIDGE_URL_SECONDARY", "BRIDGE_URL_FALLBACK"):
            v = os.getenv(key)
            if v:
                fallback_urls.append(v)

        if is_strict:
            if not base_url:
                raise BridgeClientError(
                    "DRACMA_BRIDGE_URL is required in strict environments (prod/staging/testnet)."
                )
            if "localhost" in base_url or "127.0.0.1" in base_url:
                if os.getenv("DRACMA_ALLOW_LOCAL_BRIDGE", "0") not in {"1", "true", "yes"}:
                    raise BridgeClientError(
                        "DRACMA_BRIDGE_URL points to localhost, which is not allowed in strict mode. "
                        "Set DRACMA_ALLOW_LOCAL_BRIDGE=1 to override."
                    )
            if not os.getenv("AILOOS_BRIDGE_PRIVATE_KEY"):
                raise BridgeClientError(
                    "AILOOS_BRIDGE_PRIVATE_KEY is required in strict environments to sign bridge requests."
                )

        # Decide cliente según dependencias / modo.
        if mode == "rust" or (mode == "auto" and not _HAS_PY_BRIDGE_DEPS):
            from .bridge_client_rust import BridgeClientRust  # local import, sin deps
            _bridge_client = BridgeClientRust(base_url)  # type: ignore
        else:
            _bridge_client = BridgeClient(base_url, api_key, fallback_urls=fallback_urls)
    return _bridge_client


def create_bridge_client(base_url: str, api_key: Optional[str] = None) -> BridgeClient:
    """Crear nueva instancia del cliente del puente."""
    return BridgeClient(base_url, api_key)
