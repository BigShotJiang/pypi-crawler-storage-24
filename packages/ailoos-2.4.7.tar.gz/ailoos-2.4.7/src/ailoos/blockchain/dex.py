"""
DEX (Decentralized Exchange) - Automated Market Maker (AMM)
Implementación local de pools de liquidez usando x * y = k.
Permite el intercambio de activos de manera descentralizada.
"""

import json
import time
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
from dataclasses import dataclass, asdict

from ..core.logging import get_logger

logger = get_logger(__name__)

@dataclass
class LiquidityPool:
    """Pool de liquidez AMM (Constant Product Rule)."""
    token_a: str
    token_b: str
    reserve_a: float
    reserve_b: float
    fee_percent: float = 0.3
    
    @property
    def k(self) -> float:
        """Constante k = x * y"""
        return self.reserve_a * self.reserve_b
        
    def get_price(self, token_in: str) -> float:
        """Obtener precio spot del token de entrada en términos del otro."""
        if token_in == self.token_a:
            return self.reserve_b / self.reserve_a
        elif token_in == self.token_b:
            return self.reserve_a / self.reserve_b
        else:
            raise ValueError("Token not in pool")

    def get_amount_out(self, amount_in: float, reserve_in: float, reserve_out: float) -> float:
        """
        Calcula la cantidad de salida dada una entrada (con fees).
        x * y = k
        (x + dx) * (y - dy) = k
        dy = y - (k / (x + dx))
        """
        if amount_in <= 0: return 0.0
        if reserve_in <= 0 or reserve_out <= 0: return 0.0
        
        amount_in_with_fee = amount_in * (1 - self.fee_percent / 100)
        numerator = amount_in_with_fee * reserve_out
        denominator = reserve_in + amount_in_with_fee
        
        return numerator / denominator
        
    def swap(self, token_in: str, amount_in: float) -> Tuple[float, float]:
        """
        Ejecuta un swap.
        
        Returns:
            Tuple(amount_out, price_impact_percent)
        """
        if token_in == self.token_a:
            amount_out = self.get_amount_out(amount_in, self.reserve_a, self.reserve_b)
            # Update reserves
            self.reserve_a += amount_in
            self.reserve_b -= amount_out
            return amount_out
            
        elif token_in == self.token_b:
            amount_out = self.get_amount_out(amount_in, self.reserve_b, self.reserve_a)
            # Update reserves
            self.reserve_b += amount_in
            self.reserve_a -= amount_out
            return amount_out
        else:
            raise ValueError(f"Token {token_in} not in pool {self.token_a}/{self.token_b}")

class DEXManager:
    """Gestor de Pools de DEX."""
    
    def __init__(self):
        self.pools: Dict[str, LiquidityPool] = {}
        self.storage_path = Path.home() / ".ailoos" / "data" / "dex_storage.json"
        
        # Cargar estado o inicializar defaults
        if not self.load_state():
            self._init_default_pools()
            
    def _init_default_pools(self):
        """Crear pools iniciales para demostración."""
        # Pool DRACMA / CREDITS
        # Precio inicial: 1 DRA = 10 CREDITS
        self.pools["DRA/CREDIT"] = LiquidityPool(
            token_a="DRACMA",
            token_b="CREDIT",
            reserve_a=100000.0, # 100k DRA
            reserve_b=1000000.0, # 1M CREDITS
            fee_percent=0.3
        )
        self.save_state()
        logger.info("💧 Initialized DEX Liquidity Pools")

    def get_pool(self, pair_name: str) -> Optional[LiquidityPool]:
        return self.pools.get(pair_name)

    def execute_swap(self, pair_name: str, token_in: str, amount_in: float) -> Tuple[float, str]:
        """
        Ejecuta el swap y persiste el estado.
        Returns: (amount_out, token_out_name)
        """
        pool = self.pools.get(pair_name)
        if not pool:
            raise ValueError("Pool not found")
            
        token_out_name = pool.token_b if token_in == pool.token_a else pool.token_a
        amount_out = pool.swap(token_in, amount_in)
        
        self.save_state()
        logger.info(f"💱 Swapped {amount_in} {token_in} -> {amount_out:.4f} {token_out_name} (Pool: {pair_name})")
        
        return amount_out, token_out_name

    def save_state(self):
        try:
            self.storage_path.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "pools": {
                    name: asdict(pool) for name, pool in self.pools.items()
                }
            }
            with open(self.storage_path, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"❌ Failed to save DEX state: {e}")

    def load_state(self) -> bool:
        try:
            if not self.storage_path.exists(): return False
            
            with open(self.storage_path, 'r') as f:
                data = json.load(f)
                
            for name, pool_data in data["pools"].items():
                self.pools[name] = LiquidityPool(**pool_data)
            return True
        except Exception as e:
            logger.error(f"❌ Failed to load DEX state: {e}")
            return False
