"""
Bridge client ligero (sin deps Python) usando el binario Rust `bridge_tool`.

Objetivo:
- Permitir que Ailoos ejecute `report_work`, `pending_rewards`, `claim_rewards`
  y `register_bridge_signer_system_account` sin depender de `requests`,
  `eth_account` o `cryptography`.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
from dataclasses import dataclass
from typing import Any, Dict, Optional

# Logging: fallback to stdlib if Ailoos core deps (pyyaml, etc.) are not installed.
try:
    from ..core.logging import get_logger  # type: ignore
    logger = get_logger(__name__)
except Exception:  # pragma: no cover
    import logging
    logger = logging.getLogger(__name__)


class BridgeClientRustError(Exception):
    pass


def _bridge_tool_path() -> str:
    # Busca el repo root subiendo directorios hasta encontrar `Dracma/`.
    here = os.path.abspath(os.path.dirname(__file__))
    cur = here
    for _ in range(12):
        candidate = os.path.join(cur, "Dracma", "target", "release", "bridge_tool")
        if os.path.exists(candidate):
            return candidate
        if os.path.isdir(os.path.join(cur, "Dracma")):
            return os.path.join(cur, "Dracma", "target", "release", "bridge_tool")
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    # Fallback: relative guess from Desktop layout.
    return os.path.join("/Users", os.getenv("USER", "juliojavier"), "Desktop", "Empoorio_Ecosystem", "Dracma", "target", "release", "bridge_tool")


@dataclass
class BridgeClientRust:
    base_url: str
    timeout_s: int = 30
    tool_path: Optional[str] = None

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")
        if not self.tool_path:
            self.tool_path = _bridge_tool_path()

        if not os.path.exists(self.tool_path):
            raise BridgeClientRustError(
                f"bridge_tool no encontrado en {self.tool_path}. "
                "Compílalo con: (cd Dracma && cargo build --release --features bridge_server --bin bridge_tool)"
            )

        if not os.getenv("AILOOS_BRIDGE_PRIVATE_KEY"):
            raise BridgeClientRustError("AILOOS_BRIDGE_PRIVATE_KEY requerido para firmar.")

        logger.info(f"🦀 BridgeClientRust activo (tool={self.tool_path}, base_url={self.base_url})")

    def _run(self, args: list[str]) -> Dict[str, Any]:
        env = os.environ.copy()
        env["BRIDGE_URL"] = self.base_url
        # AILOOS_BRIDGE_PRIVATE_KEY ya viene del entorno.

        max_retries = int(os.getenv("AILOOS_BRIDGE_RETRY", "5"))
        retry_sleep_s = float(os.getenv("AILOOS_BRIDGE_RETRY_SLEEP_S", "1"))

        last_stderr = ""
        for attempt in range(1, max_retries + 1):
            try:
                proc = subprocess.run(
                    [self.tool_path, *args],
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=self.timeout_s,
                    check=False,
                    text=True,
                )
            except subprocess.TimeoutExpired as e:
                raise BridgeClientRustError(f"Timeout ejecutando bridge_tool: {e}") from e

            if proc.returncode == 0:
                last_stderr = proc.stderr or ""
                break

            last_stderr = (proc.stderr or "").strip()
            # Retry only on transient connectivity errors.
            transient = any(
                s in last_stderr.lower()
                for s in (
                    "connection refused",
                    "tcp connect error",
                    "error sending request",
                    "client error (connect)",
                )
            )
            if transient and attempt < max_retries:
                logger.warning(
                    f"BridgeClientRust: bridge_tool fallo por conectividad (attempt {attempt}/{max_retries}), reintentando..."
                )
                try:
                    import time
                    time.sleep(retry_sleep_s)
                except Exception:
                    pass
                continue

            raise BridgeClientRustError(
                f"bridge_tool falló (code={proc.returncode}). stderr={last_stderr}"
            )

        try:
            return json.loads(proc.stdout)
        except Exception as e:
            raise BridgeClientRustError(
                f"Salida no-JSON de bridge_tool. stdout={proc.stdout.strip()} stderr={last_stderr}"
            ) from e

    async def register_bridge_signer_system_account(self) -> Dict[str, Any]:
        return await asyncio.to_thread(self._run, ["register_bridge_signer"])

    async def get_pending_rewards(self, node_id: str) -> Dict[str, Any]:
        return await asyncio.to_thread(self._run, ["pending_rewards", node_id])

    async def report_work(self, node_id: str, units: int) -> Dict[str, Any]:
        if units <= 0:
            raise BridgeClientRustError("units debe ser > 0")
        return await asyncio.to_thread(self._run, ["report_work", node_id, str(units)])

    async def claim_rewards(self, node_id: str) -> Dict[str, Any]:
        return await asyncio.to_thread(self._run, ["claim_rewards", node_id])

    async def stake_node_tokens(self, node_id: str, amount: Any) -> Dict[str, Any]:
        """
        Stake tokens for a node via bridge_tool (sin deps Python).

        IMPORTANT: `amount` debe venir ya en base units (Uint128 string/int).
        """
        if not node_id:
            raise BridgeClientRustError("node_id es requerido")
        amount_s = str(amount).strip()
        if not amount_s or amount_s == "0":
            raise BridgeClientRustError("amount debe ser > 0 (base units)")
        # Si trae decimales, forzamos a que el caller pase base units (evitamos Decimal deps).
        if "." in amount_s:
            raise BridgeClientRustError("amount con decimales no soportado en modo rust; pasa base units (Uint128)")
        return await asyncio.to_thread(self._run, ["stake_node", node_id, amount_s])

    async def unstake_node_tokens(self, node_id: str, amount: Any) -> Dict[str, Any]:
        if not node_id:
            raise BridgeClientRustError("node_id es requerido")
        amount_s = str(amount).strip()
        if not amount_s or amount_s == "0":
            raise BridgeClientRustError("amount debe ser > 0 (base units)")
        if "." in amount_s:
            raise BridgeClientRustError("amount con decimales no soportado en modo rust; pasa base units (Uint128)")
        return await asyncio.to_thread(self._run, ["unstake_node", node_id, amount_s])
