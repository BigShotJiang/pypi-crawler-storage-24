def dijkstra(graph, start):
    """
    Version simple de Dijkstra.
    Complexité : O(n^2)
    """

    # Initialisation des distances
    distances = {node: float("inf") for node in graph}
    distances[start] = 0

    visited = set()

    while len(visited) < len(graph):

        # Trouver le noeud non visité avec la plus petite distance
        current = None
        current_dist = float("inf")

        for node in graph:
            if node not in visited and distances[node] < current_dist:
                current = node
                current_dist = distances[node]

        if current is None:
            break  # plus rien à explorer

        visited.add(current)

        # Mise à jour des distances des voisins
        for neighbor, weight in graph[current]:
            new_dist = distances[current] + weight
            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist

    return distances
