def quick_sort(arr):
    """
    Version simple du tri rapide (Quick Sort).
    Complexité moyenne : O(n log n)
    Pire cas : O(n^2)
    """

    # cas de base
    if len(arr) <= 1:
        return arr

    pivot = arr[0]

    left = []
    right = []

    # séparation des éléments
    for x in arr[1:]:
        if x <= pivot:
            left.append(x)
        else:
            right.append(x)

    # appel récursif
    return quick_sort(left) + [pivot] + quick_sort(right)