# Utiliser la library
```Bash
pip install --upgrade algosjohn
```

# Liste des algos :
- Dijkstra
- Tri Rapide (quick_sort)
- Tri Fusion (mergee_sort)


## Commande développeur :
```Bash
python -m build
```
```Bash
python -m twine upload dist/*
```
