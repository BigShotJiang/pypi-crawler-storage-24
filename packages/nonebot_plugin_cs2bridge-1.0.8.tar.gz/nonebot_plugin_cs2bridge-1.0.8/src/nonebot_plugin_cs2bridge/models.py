from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError, field_validator


class CS2EventBase(BaseModel):
    event: str = Field(..., description="事件类型，如 player_connect, player_disconnect 等")
    data: dict[str, Any] = Field(default_factory=dict, description="事件具体数据")


class PlayerConnectData(BaseModel):
    player_name: str = Field(default="未知玩家", description="玩家名称")
    steamid: str | None = Field(default=None, description="SteamID64")
    player_count: int = Field(default=0, ge=0, description="当前在线人数")
    max_players: int = Field(default=0, ge=0, description="服务器最大人数")

    @field_validator("steamid", mode="before")
    @classmethod
    def validate_steamid(cls, value: Any) -> str | None:
        if value is None or value == "":
            return None
        if not isinstance(value, str):
            value = str(value)
        if not value.isdigit() or len(value) != 17:
            raise ValueError("SteamID 必须是17位数字字符串")
        return value


class PlayerConnectEvent(CS2EventBase):
    event: Literal["player_connect"] = "player_connect"
    data: PlayerConnectData


class PlayerDisconnectData(BaseModel):
    player_name: str = Field(default="未知玩家")
    steamid: str | None = Field(default=None)
    reason: str = Field(default="正常断开", description="离开原因")
    player_count: int = Field(default=0, ge=0)
    max_players: int = Field(default=0, ge=0)


class PlayerDisconnectEvent(CS2EventBase):
    event: Literal["player_disconnect"] = "player_disconnect"
    data: PlayerDisconnectData


class MapChangedData(BaseModel):
    new_map: str = Field(default="未知地图")
    old_map: str = Field(default="未知")
    time: str = Field(default="未知时间")


class MapChangedEvent(CS2EventBase):
    event: Literal["map_changed"] = "map_changed"
    data: MapChangedData


# 示例：在 webhook 中按事件类型进行结构化校验
# from .models import MapChangedEvent, PlayerConnectEvent, PlayerDisconnectEvent
#
# try:
#     if payload["event"] == "player_connect":
#         event_obj = PlayerConnectEvent.model_validate(payload)
#         player_name = event_obj.data.player_name
#         steamid = event_obj.data.steamid or "未知"
#     elif payload["event"] == "player_disconnect":
#         event_obj = PlayerDisconnectEvent.model_validate(payload)
#     elif payload["event"] == "map_changed":
#         event_obj = MapChangedEvent.model_validate(payload)
#     else:
#         logger.info("未知事件类型: {}", payload["event"])
# except ValidationError as exception:
#     logger.error("Payload 验证失败: {}", exception)
