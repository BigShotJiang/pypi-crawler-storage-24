from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from nonebot import get_driver, get_plugin_config


class Config(BaseSettings):
    qq_group_ids: list[int] = Field(
        default_factory=list,
        validation_alias=AliasChoices("qq_group_ids", "cs2_qq_group_ids", "QQ_GROUP_IDS"),
    )
    webhook_secret: str = Field(
        default="",
        validation_alias=AliasChoices("webhook_secret", "cs2bridge_secret", "WEBHOOK_SECRET"),
    )
    webhook_path: str = Field(
        default="/cs2/event",
        validation_alias=AliasChoices("webhook_path", "cs2bridge_path", "WEBHOOK_PATH"),
    )

    server_host: str = Field(
        default="",
        validation_alias=AliasChoices("server_host", "cs2_server_host", "SERVER_HOST"),
    )
    query_port: int = Field(
        default=27015,
        validation_alias=AliasChoices("query_port", "cs2_query_port", "QUERY_PORT"),
    )
    status_interval: int = Field(
        default=45,
        ge=30,
        le=60,
        validation_alias=AliasChoices(
            "status_interval", "cs2_status_interval", "STATUS_INTERVAL"
        ),
    )

    rcon_host: str = Field(
        default="",
        validation_alias=AliasChoices("rcon_host", "cs2_rcon_host", "CS2_RCON_HOST"),
    )
    rcon_port: int = Field(
        default=27015,
        validation_alias=AliasChoices("rcon_port", "cs2_rcon_port", "CS2_RCON_PORT"),
    )
    rcon_password: str = Field(
        default="",
        validation_alias=AliasChoices(
            "rcon_password", "cs2_rcon_password", "CS2_RCON_PASSWORD"
        ),
    )

    model_config = SettingsConfigDict(
        env_prefix="CS2_",
        env_file=".env",
        extra="ignore",
        case_sensitive=False,
    )


try:
    config = get_plugin_config(Config)
except Exception:
    driver_config = get_driver().config
    if hasattr(driver_config, "dict"):
        config = Config.parse_obj(driver_config.dict())
    else:
        config = Config.parse_obj(driver_config)
