from typing import Any, Optional

from vicentin.kernels import Kernel, LinearKernel
from vicentin.utils import Dispatcher
from vicentin.utils.logging import info, debug, error, warn

disp_logistic = Dispatcher()

try:
    from .logistic_regression_np import logistic_regression as lr_np

    disp_logistic.register("numpy", lr_np)
except ModuleNotFoundError:
    warn("NumPy backend not found.")
except Exception:
    error("NumPy backend failed to load.")

try:
    from .logistic_regression_torch import logistic_regression as lr_torch

    disp_logistic.register("torch", lr_torch)
except ModuleNotFoundError:
    warn("Torch backend not found.")
except Exception:
    error("Torch backend failed to load.")


class LogisticRegression:
    def __init__(
        self,
        lambda_: float = 0,
        max_iter: int = 20,
        tol: float = 1e-5,
        backend: Optional[str] = None,
    ):
        self.lambda_ = lambda_
        self.max_iter = max_iter
        self.tol = tol
        self.backend = backend

        self.weights = None
        self.kernel = None
        self.is_primal = False

    def fit(self, X: Any, y: Any) -> "LogisticRegression":
        ctx = disp_logistic.detect_backend(X, self.backend)
        info(f"Fitting Logistic Regression model using backend: {ctx.backend}")

        if isinstance(X, Kernel):
            self.kernel = X
            X_data = self.kernel.X
        else:
            self.kernel = LinearKernel(X)
            X_data = X

        n, d = X_data.shape

        self.is_primal = (d < n) and not isinstance(X, Kernel)

        if self.is_primal:
            debug(f"Using Primal space optimization (n={n}, d={d})")
            X_input = X_data
        else:
            debug(f"Using Dual space (Kernel) optimization (n={n}, d={d})")
            X_input = self.kernel

        self.weights = disp_logistic(
            ctx,
            X_input,
            y,
            self.lambda_,
            self.max_iter,
            self.tol,
            self.is_primal,
        )
        info("Logistic Regression fit complete.")

        return self

    def predict(self, X: Any) -> Any:
        """Returns the raw logit decision scores (inner product)"""
        if self.weights is None:
            raise RuntimeError("Model must be fit before calling predict.")

        debug(f"Predicting data of shape {X.shape}")
        if self.is_primal:
            return X @ self.weights

        return self.kernel.apply(X, self.weights)

    def __repr__(self):
        return f"LogisticRegression(lambda_={self.lambda_:.2e}, max_iter={self.max_iter}, tol={self.tol:.2e}, backend={self.backend!r})"
