import numpy as np

from vicentin.machine_learning.regression import RidgeRegression
from vicentin.utils.logging import debug, info


def _sigmoid(u):
    return 1 / (1 + np.exp(-u))


def logistic_regression(X_or_kernel, y, lambda_orig, max_iter, tol, is_primal):
    if is_primal:
        N = X_or_kernel.shape[0]
        dtype = X_or_kernel.dtype
    else:
        N = X_or_kernel.N
        dtype = X_or_kernel.X.dtype

    m = np.zeros((N, 1), dtype=dtype)
    y = y.reshape(-1, 1) if y.ndim == 1 else y

    weights = None
    ridge_model = RidgeRegression(lambda_=lambda_orig, backend="numpy")

    for i in range(max_iter):
        m_prev = m.copy()

        W = _sigmoid(m) * _sigmoid(-m)
        z = m + y / _sigmoid(y * m)

        ridge_model.fit(X_or_kernel, z, W=W)
        weights = ridge_model.weights

        m = (X_or_kernel @ weights).reshape(-1, 1)

        diff = float(np.max(np.abs(m - m_prev)))
        debug(f"Logistic Iteration {i+1}/{max_iter}, Diff: {diff:.6f}")

        if diff < tol:
            info(f"Logistic Regression converged in {i+1} iterations.")
            break

    return weights
