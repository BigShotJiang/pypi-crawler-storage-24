from typing import Callable, Any

import torch
from torch.func import jacrev

from vicentin.utils.logging import info, debug, warn


def newton_raphson(
    f: Callable[[torch.Tensor], torch.Tensor],
    x0: Any,
    max_iter: int = 100,
    tol: float = 1e-6,
    return_loss: bool = False,
):
    x = x0.clone().detach()

    info(f"Starting Newton-Raphson [Torch] on {x.device}")

    grad_f = jacrev(f)
    loss = []

    for i in range(max_iter):
        f_val = torch.atleast_1d(f(x))

        if torch.isinf(f_val).any():
            error_msg = f"Function diverged at iteration {i}."
            warn(error_msg)
            raise RuntimeError(error_msg)

        f_norm = torch.linalg.norm(f_val).item()
        loss.append(f_norm)

        debug(f"Iter {i}: ||f(x)|| = {f_norm:.4e}")

        if f_norm < tol:
            info(f"Newton-Raphson converged at iteration {i}.")
            break

        grad = grad_f(x)
        if isinstance(grad, tuple):
            grad = grad[0]

        if torch.any(grad == 0):
            error_msg = f"Gradient is zero at iteration {i}."
            warn(error_msg)
            raise RuntimeError(error_msg)

        if grad.ndim > 1:
            delta_x = torch.linalg.solve(grad, f_val)
        else:
            delta_x = f_val / grad

        x = x - delta_x
    else:
        warn(
            f"Newton-Raphson reached max_iter ({max_iter}) without full convergence."
        )

    return (x, loss) if return_loss else x
