"""LeanProgress integration examples."""
