# Verilock Python SDK

Official Python SDK for the Verilock Identity Verification API.

## Installation

```bash
pip install verilock
```

## Quick Start

```python
from verilock import VerilockClient

client = VerilockClient(api_key="your_api_key")

session = client.sessions.create(
    type="identity",
    redirect_url="https://yourapp.com/callback"
)

print(session.url)
```

## Documentation

Full documentation is available at [developer.verilock.io](https://developer.verilock.io/sdks/python).
