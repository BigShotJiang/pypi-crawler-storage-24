"""Verilock — Official Python SDK for the Verilock Identity Verification API.

Usage::

    from verilock import Verilock

    client = Verilock(api_key="qi_live_...")
    session = client.sessions.create({"applicant_email": "john@example.com"})

Async usage::

    from verilock import AsyncVerilock

    async with AsyncVerilock(api_key="qi_live_...") as client:
        session = await client.sessions.create({"applicant_email": "john@example.com"})
"""

from .client import AsyncVerilock, Verilock
from .exceptions import (
    AuthenticationError,
    InsufficientBalanceError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    VerilockError,
)

# Re-export all types for convenience
from .types.common import (
    ApiErrorBody,
    ListParams,
    PaginatedResponse,
    PaginationMeta,
)
from .types.sessions import (
    CreateSessionParams,
    CreateSessionResponse,
    ListSessionsParams,
    Session,
    SessionAmlMatch,
    SessionAmlScreening,
    SessionDocument,
    SessionListItem,
    SessionSelfie,
    SubmitSessionResponse,
    UploadAddressProofParams,
    UploadAddressProofResponse,
    UploadDocumentParams,
    UploadDocumentResponse,
    UploadSelfieParams,
    UploadSelfieResponse,
)
from .types.aml import (
    AmlDecisionParams,
    AmlDecisionResponse,
    AmlMatch,
    AmlScreeningResult,
    ScreenPersonParams,
)
from .types.transactions import (
    BatchScreenParams,
    BatchScreenResponse,
    BatchScreenResultItem,
    ListTransactionsParams,
    ScreenTransactionParams,
    TransactionAlert,
    TransactionDecisionParams,
    TransactionDecisionResponse,
    TransactionDetail,
    TransactionListItem,
    TransactionScreeningResult,
    TransactionType,
)
from .types.biometric import (
    BiometricAuthParams,
    BiometricAuthResponse,
    BiometricAuthResult,
)
from .types.database import (
    DatabaseProvider,
    DatabaseValidateParams,
    DatabaseValidationResult,
)
from .types.face_search import (
    FaceSearchMatch,
    FaceSearchParams,
    FaceSearchResult,
)
from .types.wallet import (
    WalletScreenParams,
    WalletScreeningResult,
)
from .types.credentials import (
    CreateCredentialParams,
    Credential,
    VerificationResult,
    VerifyCredentialParams,
    VerifyCredentialResponse,
)
from .types.age_verify import (
    AgeVerifyParams,
    AgeVerifyResult,
)

__all__ = [
    # Clients
    "Verilock",
    "AsyncVerilock",
    # Exceptions
    "VerilockError",
    "AuthenticationError",
    "InsufficientBalanceError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    # Common types
    "PaginationMeta",
    "PaginatedResponse",
    "ApiErrorBody",
    "ListParams",
    # Sessions
    "CreateSessionParams",
    "CreateSessionResponse",
    "SessionDocument",
    "SessionSelfie",
    "SessionAmlMatch",
    "SessionAmlScreening",
    "Session",
    "SessionListItem",
    "ListSessionsParams",
    "SubmitSessionResponse",
    "UploadDocumentParams",
    "UploadDocumentResponse",
    "UploadSelfieParams",
    "UploadSelfieResponse",
    "UploadAddressProofParams",
    "UploadAddressProofResponse",
    # AML
    "ScreenPersonParams",
    "AmlMatch",
    "AmlScreeningResult",
    "AmlDecisionParams",
    "AmlDecisionResponse",
    # Transactions
    "ScreenTransactionParams",
    "TransactionAlert",
    "TransactionScreeningResult",
    "BatchScreenParams",
    "BatchScreenResultItem",
    "BatchScreenResponse",
    "TransactionDetail",
    "ListTransactionsParams",
    "TransactionListItem",
    "TransactionDecisionParams",
    "TransactionDecisionResponse",
    "TransactionType",
    # Biometric
    "BiometricAuthParams",
    "BiometricAuthResponse",
    "BiometricAuthResult",
    # Database
    "DatabaseProvider",
    "DatabaseValidateParams",
    "DatabaseValidationResult",
    # Face Search
    "FaceSearchParams",
    "FaceSearchMatch",
    "FaceSearchResult",
    # Wallet
    "WalletScreenParams",
    "WalletScreeningResult",
    # Credentials
    "CreateCredentialParams",
    "Credential",
    "VerifyCredentialParams",
    "VerifyCredentialResponse",
    "VerificationResult",
    # Age Verify
    "AgeVerifyParams",
    "AgeVerifyResult",
]

__version__ = "1.0.0"
