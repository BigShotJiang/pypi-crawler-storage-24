"""Database resource — government database identity validation."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..http_client import AsyncHttpClient, HttpClient

__all__ = ["Database", "AsyncDatabase"]


class Database:
    """Government database validation (synchronous).

    Example::

        result = verilock.database.validate(
            DatabaseValidateParams(
                provider="ng_nin",
                first_name="John",
                last_name="Doe",
                date_of_birth="1990-01-15",
                document_number="12345678901",
                country="NG",
            )
        )
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list_providers(
        self,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List available government database providers.

        Returns:
            Response with a ``providers`` list.
        """
        return self._http.get("/v1/database/providers", idempotency_key=idempotency_key)

    def validate(
        self,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Validate identity data against a government database.

        Args:
            params: A :class:`~verilock.types.database.DatabaseValidateParams` or dict.

        Returns:
            Validation result with match score and field matches.
        """
        body = asdict(params) if hasattr(params, "__dataclass_fields__") else params
        body = {k: v for k, v in body.items() if v is not None}
        return self._http.post(
            "/v1/database/validate", body, idempotency_key=idempotency_key
        )

    def retrieve(
        self,
        validation_id: str,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Retrieve a previous database validation result.

        Args:
            validation_id: The validation ID.

        Returns:
            Full validation result.
        """
        return self._http.get(
            f"/v1/database/validate/{validation_id}",
            idempotency_key=idempotency_key,
        )


class AsyncDatabase:
    """Government database validation (asynchronous)."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list_providers(
        self,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List available government database providers."""
        return await self._http.get(
            "/v1/database/providers", idempotency_key=idempotency_key
        )

    async def validate(
        self,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Validate identity data against a government database."""
        body = asdict(params) if hasattr(params, "__dataclass_fields__") else params
        body = {k: v for k, v in body.items() if v is not None}
        return await self._http.post(
            "/v1/database/validate", body, idempotency_key=idempotency_key
        )

    async def retrieve(
        self,
        validation_id: str,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Retrieve a previous database validation result."""
        return await self._http.get(
            f"/v1/database/validate/{validation_id}",
            idempotency_key=idempotency_key,
        )
