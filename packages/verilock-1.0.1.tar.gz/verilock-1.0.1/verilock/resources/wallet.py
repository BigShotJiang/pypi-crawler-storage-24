"""Wallet resource — crypto wallet compliance screening."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..http_client import AsyncHttpClient, HttpClient

__all__ = ["Wallet", "AsyncWallet"]


class Wallet:
    """Crypto wallet compliance screening (synchronous).

    Example::

        result = verilock.wallet.screen(
            WalletScreenParams(
                address="0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18",
                network="ethereum",
            )
        )
        print(f"Risk: {result['risk_level']} ({result['risk_score']})")
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def screen(
        self,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Screen a crypto wallet address for compliance risk.

        Requires the ``wallet_screening`` license feature.

        Args:
            params: A :class:`~verilock.types.wallet.WalletScreenParams` or dict.

        Returns:
            Wallet screening result with risk score, level, and categories.
        """
        body = asdict(params) if hasattr(params, "__dataclass_fields__") else params
        body = {k: v for k, v in body.items() if v is not None}
        return self._http.post(
            "/v1/wallet/screen", body, idempotency_key=idempotency_key
        )

    def retrieve(
        self,
        screening_id: str,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Retrieve a previous wallet screening result.

        Args:
            screening_id: The wallet screening ID.

        Returns:
            Full wallet screening result.
        """
        return self._http.get(
            f"/v1/wallet/screen/{screening_id}", idempotency_key=idempotency_key
        )


class AsyncWallet:
    """Crypto wallet compliance screening (asynchronous)."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def screen(
        self,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Screen a crypto wallet address for compliance risk."""
        body = asdict(params) if hasattr(params, "__dataclass_fields__") else params
        body = {k: v for k, v in body.items() if v is not None}
        return await self._http.post(
            "/v1/wallet/screen", body, idempotency_key=idempotency_key
        )

    async def retrieve(
        self,
        screening_id: str,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Retrieve a previous wallet screening result."""
        return await self._http.get(
            f"/v1/wallet/screen/{screening_id}", idempotency_key=idempotency_key
        )
