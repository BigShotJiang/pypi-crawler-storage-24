"""AML resource — sanctions, PEP, and watchlist screening."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..http_client import AsyncHttpClient, HttpClient

__all__ = ["Aml", "AsyncAml"]


class Aml:
    """AML/PEP/sanctions screening (synchronous).

    Example::

        result = verilock.aml.screen(
            ScreenPersonParams(name="John Doe", nationality="US")
        )
        if result["status"] == "match":
            print(f"Found {result['matches_found']} matches")
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def screen(
        self,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Screen a person against global sanctions, PEP, and watchlists.

        Args:
            params: A :class:`~verilock.types.aml.ScreenPersonParams` instance or dict.

        Returns:
            AML screening result with matches.
        """
        body = asdict(params) if hasattr(params, "__dataclass_fields__") else params
        body = {k: v for k, v in body.items() if v is not None}
        return self._http.post("/v1/aml/screen", body, idempotency_key=idempotency_key)

    def retrieve(
        self,
        screening_id: str,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Retrieve a previous AML screening result.

        Args:
            screening_id: The screening ID to retrieve.

        Returns:
            Full AML screening result with matches.
        """
        return self._http.get(
            f"/v1/aml/screen/{screening_id}", idempotency_key=idempotency_key
        )

    def decide(
        self,
        screening_id: str,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Submit a decision for an AML screening.

        Args:
            screening_id: The screening ID to decide on.
            params: A :class:`~verilock.types.aml.AmlDecisionParams` instance or dict
                with ``decision`` (``"true_positive"``, ``"false_positive"``, or ``"clear"``)
                and optional ``notes``.

        Returns:
            Decision confirmation with ``id``, ``status``, and ``decision``.
        """
        body = asdict(params) if hasattr(params, "__dataclass_fields__") else params
        body = {k: v for k, v in body.items() if v is not None}
        return self._http.post(
            f"/v1/aml/screen/{screening_id}/decision",
            body,
            idempotency_key=idempotency_key,
        )


class AsyncAml:
    """AML/PEP/sanctions screening (asynchronous)."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def screen(
        self,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Screen a person against global sanctions, PEP, and watchlists."""
        body = asdict(params) if hasattr(params, "__dataclass_fields__") else params
        body = {k: v for k, v in body.items() if v is not None}
        return await self._http.post("/v1/aml/screen", body, idempotency_key=idempotency_key)

    async def retrieve(
        self,
        screening_id: str,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Retrieve a previous AML screening result."""
        return await self._http.get(
            f"/v1/aml/screen/{screening_id}", idempotency_key=idempotency_key
        )

    async def decide(
        self,
        screening_id: str,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Submit a decision for an AML screening."""
        body = asdict(params) if hasattr(params, "__dataclass_fields__") else params
        body = {k: v for k, v in body.items() if v is not None}
        return await self._http.post(
            f"/v1/aml/screen/{screening_id}/decision",
            body,
            idempotency_key=idempotency_key,
        )
