"""Age Verify resource — age verification from selfie."""

from __future__ import annotations

from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..http_client import AsyncHttpClient, HttpClient

__all__ = ["AgeVerify", "AsyncAgeVerify"]


class AgeVerify:
    """Age verification from selfie (synchronous).

    Example::

        result = verilock.age_verify.verify(
            AgeVerifyParams(
                file=open("selfie.jpg", "rb").read(),
                min_age=18,
            )
        )
        if result["verified"]:
            print(f"Age: {result['estimated_age_low']}-{result['estimated_age_high']}")
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def verify(
        self,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Verify a person's age from a selfie image.

        Args:
            params: An :class:`~verilock.types.age_verify.AgeVerifyParams` instance
                with ``file``, ``min_age``, and optionally ``filename``.

        Returns:
            Age verification result with ``verified``, ``estimated_age_low``,
            ``estimated_age_high``, and ``confidence``.
        """
        return self._http.upload(
            "/v1/age-verify",
            params.file,
            params.filename or "photo.jpg",
            {"min_age": str(params.min_age)},
            idempotency_key=idempotency_key,
        )


class AsyncAgeVerify:
    """Age verification from selfie (asynchronous)."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def verify(
        self,
        params: Any,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Verify a person's age from a selfie image."""
        return await self._http.upload(
            "/v1/age-verify",
            params.file,
            params.filename or "photo.jpg",
            {"min_age": str(params.min_age)},
            idempotency_key=idempotency_key,
        )
