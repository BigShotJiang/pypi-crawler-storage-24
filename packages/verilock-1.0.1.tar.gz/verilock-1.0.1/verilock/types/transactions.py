"""Types for the Transactions resource."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

__all__ = [
    "TransactionStatus",
    "TransactionRiskLevel",
    "TransactionDecisionType",
    "AlertType",
    "AlertSeverity",
    "ScreenTransactionParams",
    "TransactionAlert",
    "TransactionScreeningResult",
    "BatchScreenParams",
    "BatchScreenResultItem",
    "BatchScreenResponse",
    "TransactionDetail",
    "ListTransactionsParams",
    "TransactionListItem",
    "TransactionDecisionParams",
    "TransactionDecisionResponse",
    "TransactionType",
]

TransactionStatus = Literal["pending", "screening", "cleared", "flagged", "blocked"]
TransactionRiskLevel = Literal["low", "medium", "high", "critical"]
TransactionDecisionType = Literal["approved", "rejected", "escalated"]
AlertType = Literal[
    "sanctions_match", "pep_match", "high_risk_country",
    "unusual_amount", "velocity", "pattern",
    "round_amounts", "rapid_movement", "pass_through_account",
    "circular_flow", "activity_spike", "dormant_account",
    "micro_transactions", "new_account_volume", "peer_concentration",
    "funnel_account", "behavioral_deviation", "multi_account_device",
    "suspicious_merchant",
]
AlertSeverity = Literal["low", "medium", "high", "critical"]


@dataclass
class ScreenTransactionParams:
    """Parameters for screening a single transaction.

    Example::

        params = ScreenTransactionParams(
            transaction_ref="TX-001",
            sender_name="Alice Corp",
            receiver_name="Bob Ltd",
            amount=15000,
            currency="USD",
        )
    """

    transaction_ref: str
    sender_name: str
    receiver_name: str
    amount: float
    currency: str
    transaction_type: Optional[str] = None
    sender_account: Optional[str] = None
    sender_country: Optional[str] = None
    receiver_account: Optional[str] = None
    receiver_country: Optional[str] = None
    transaction_date: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class TransactionAlert:
    """An alert triggered by transaction screening."""

    id: str
    type: AlertType
    severity: AlertSeverity
    title: str
    description: str
    matched_entity: Optional[str] = None
    match_score: Optional[float] = None


@dataclass
class TransactionScreeningResult:
    """Result from screening a single transaction."""

    id: str
    transaction_ref: str
    risk_level: TransactionRiskLevel
    risk_score: float
    status: TransactionStatus
    alerts_count: int = 0
    transaction_type: Optional[str] = None
    alerts: List[TransactionAlert] = field(default_factory=list)


@dataclass
class BatchScreenParams:
    """Parameters for batch transaction screening."""

    transactions: List[ScreenTransactionParams]


@dataclass
class BatchScreenResultItem:
    """Summary result for a single transaction in a batch."""

    id: str
    transaction_ref: str
    risk_level: TransactionRiskLevel
    risk_score: float
    status: TransactionStatus
    alerts_count: int = 0


@dataclass
class BatchScreenResponse:
    """Response from batch transaction screening."""

    total: int
    results: List[BatchScreenResultItem] = field(default_factory=list)


@dataclass
class TransactionDetail:
    """Full transaction detail including screening results and party info."""

    id: str
    transaction_ref: str
    risk_level: TransactionRiskLevel
    risk_score: float
    status: TransactionStatus
    sender_name: str
    receiver_name: str
    amount: float
    currency: str
    alerts_count: int = 0
    transaction_type: Optional[str] = None
    alerts: List[TransactionAlert] = field(default_factory=list)
    sender_account: Optional[str] = None
    sender_country: Optional[str] = None
    receiver_account: Optional[str] = None
    receiver_country: Optional[str] = None
    transaction_date: Optional[str] = None
    description: Optional[str] = None
    decision: Optional[TransactionDecisionType] = None
    decided_at: Optional[str] = None


@dataclass
class ListTransactionsParams:
    """Parameters for listing transaction screenings."""

    per_page: Optional[int] = None
    page: Optional[int] = None
    from_date: Optional[str] = None
    to_date: Optional[str] = None
    status: Optional[TransactionStatus] = None
    risk_level: Optional[TransactionRiskLevel] = None
    transaction_type: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {}
        if self.per_page is not None:
            d["per_page"] = self.per_page
        if self.page is not None:
            d["page"] = self.page
        if self.from_date is not None:
            d["from"] = self.from_date
        if self.to_date is not None:
            d["to"] = self.to_date
        if self.status is not None:
            d["status"] = self.status
        if self.risk_level is not None:
            d["risk_level"] = self.risk_level
        if self.transaction_type is not None:
            d["transaction_type"] = self.transaction_type
        return d


@dataclass
class TransactionListItem:
    """Summary transaction item returned by the list endpoint."""

    id: str
    transaction_ref: str
    risk_level: TransactionRiskLevel
    risk_score: float
    status: TransactionStatus
    alerts_count: int = 0
    transaction_type: Optional[str] = None
    created_at: str = ""


@dataclass
class TransactionDecisionParams:
    """Parameters for submitting a transaction decision."""

    decision: TransactionDecisionType
    notes: Optional[str] = None


@dataclass
class TransactionDecisionResponse:
    """Response from submitting a transaction decision."""

    id: str
    status: str
    decision: str


@dataclass
class TransactionType:
    """A transaction type classification."""

    slug: str
    label: str
    description: str
