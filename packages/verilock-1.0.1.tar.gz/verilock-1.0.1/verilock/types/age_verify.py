"""Types for the Age Verify resource."""

from __future__ import annotations

from dataclasses import dataclass
from typing import BinaryIO, Optional, Union

__all__ = [
    "AgeVerifyParams",
    "AgeVerifyResult",
]


@dataclass
class AgeVerifyParams:
    """Parameters for age verification from a selfie.

    Example::

        params = AgeVerifyParams(
            file=open("selfie.jpg", "rb").read(),
            min_age=18,
        )
    """

    file: Union[bytes, BinaryIO]
    min_age: int
    filename: Optional[str] = None


@dataclass
class AgeVerifyResult:
    """Result of an age verification check."""

    verified: bool
    min_age_required: int
    reason: Optional[str] = None
    estimated_age_low: Optional[int] = None
    estimated_age_high: Optional[int] = None
    confidence: Optional[float] = None
