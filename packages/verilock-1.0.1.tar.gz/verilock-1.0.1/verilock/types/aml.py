"""Types for the AML screening resource."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

__all__ = [
    "AmlStatus",
    "AmlDecisionType",
    "ScreenPersonParams",
    "AmlMatch",
    "AmlScreeningResult",
    "AmlDecisionParams",
    "AmlDecisionResponse",
]

AmlStatus = Literal["pending", "clear", "match", "false_positive", "confirmed", "error"]
AmlDecisionType = Literal["true_positive", "false_positive", "clear"]


@dataclass
class ScreenPersonParams:
    """Parameters for screening a person against AML databases.

    Example::

        params = ScreenPersonParams(
            name="John Doe",
            date_of_birth="1990-01-15",
            nationality="US",
        )
    """

    name: str
    date_of_birth: Optional[str] = None
    nationality: Optional[str] = None


@dataclass
class AmlMatch:
    """A single match found in AML/PEP/sanctions databases."""

    entity_id: str
    matched_name: str
    match_score: float
    schema: Optional[str] = None
    datasets: List[str] = field(default_factory=list)
    topics: List[str] = field(default_factory=list)
    birth_date: Optional[str] = None
    nationality: Optional[str] = None
    caption: Optional[str] = None


@dataclass
class AmlScreeningResult:
    """Result of an AML screening operation."""

    id: str
    status: AmlStatus
    screened_name: str
    matches_found: int = 0
    highest_score: Optional[float] = None
    decision: Optional[AmlDecisionType] = None
    decided_at: Optional[str] = None
    decision_notes: Optional[str] = None
    matches: List[AmlMatch] = field(default_factory=list)


@dataclass
class AmlDecisionParams:
    """Parameters for submitting a decision on an AML screening."""

    decision: AmlDecisionType
    notes: Optional[str] = None


@dataclass
class AmlDecisionResponse:
    """Response from submitting an AML decision."""

    id: str
    status: str
    decision: str
