"""Types for the Credentials resource."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

__all__ = [
    "CredentialStatus",
    "CreateCredentialParams",
    "Credential",
    "VerifyCredentialParams",
    "VerifyCredentialResponse",
    "VerificationResult",
]

CredentialStatus = Literal["active", "expired", "revoked"]


@dataclass
class CreateCredentialParams:
    """Parameters for creating a reusable KYC credential.

    Example::

        params = CreateCredentialParams(
            session_id="sess_123",
            shared_fields=["full_name", "date_of_birth", "nationality"],
            expires_in_days=90,
        )
    """

    session_id: str
    shared_fields: Optional[List[str]] = None
    expires_in_days: Optional[int] = None


@dataclass
class Credential:
    """A reusable KYC credential."""

    id: str
    status: CredentialStatus
    shared_fields: List[str] = field(default_factory=list)
    verification_level: str = ""
    expires_at: str = ""
    session_id: Optional[str] = None
    token: Optional[str] = None
    created_at: Optional[str] = None


@dataclass
class VerifyCredentialParams:
    """Parameters for verifying a credential token."""

    token: str


@dataclass
class VerificationResult:
    """Nested verification result within a credential verification."""

    decision: str
    risk_score: Optional[float] = None
    completed_at: str = ""


@dataclass
class VerifyCredentialResponse:
    """Response from verifying a credential token."""

    valid: bool
    credential_id: str
    verification_level: str
    shared_data: Dict[str, Any] = field(default_factory=dict)
    verification_result: Optional[VerificationResult] = None
    issued_at: str = ""
    expires_at: str = ""
