"""Types for the Biometric resource."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, BinaryIO, Dict, Literal, Optional, Union

__all__ = [
    "BiometricResult",
    "BiometricAuthParams",
    "BiometricAuthResponse",
    "BiometricAuthResult",
]

BiometricResult = Literal["match", "no_match", "error", "pending"]


@dataclass
class BiometricAuthParams:
    """Parameters for biometric face authentication.

    Example::

        params = BiometricAuthParams(
            session_id="sess_123",
            file=open("selfie.jpg", "rb").read(),
            threshold=85,
        )
    """

    session_id: str
    file: Union[bytes, BinaryIO]
    filename: Optional[str] = None
    threshold: Optional[int] = None
    device_info: Optional[Dict[str, Any]] = None


@dataclass
class BiometricAuthResponse:
    """Response from initiating a biometric authentication."""

    id: str
    status: Literal["processing"]
    message: str


@dataclass
class BiometricAuthResult:
    """Result of a biometric authentication attempt."""

    id: str
    session_id: str
    result: BiometricResult
    threshold_used: float
    created_at: str
    similarity: Optional[float] = None
    liveness_score: Optional[float] = None
    liveness_passed: Optional[bool] = None
