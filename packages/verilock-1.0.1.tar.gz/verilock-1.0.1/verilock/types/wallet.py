"""Types for the Wallet resource."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Literal, Optional

__all__ = [
    "WalletRiskLevel",
    "WalletScreenParams",
    "WalletScreeningResult",
]

WalletRiskLevel = Literal["low", "medium", "high", "severe"]


@dataclass
class WalletScreenParams:
    """Parameters for screening a crypto wallet address.

    Example::

        params = WalletScreenParams(
            address="0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18",
            network="ethereum",
        )
    """

    address: str
    network: Optional[str] = None


@dataclass
class WalletScreeningResult:
    """Result of a wallet compliance screening."""

    id: str
    address: str
    network: str
    risk_score: float
    risk_level: WalletRiskLevel
    created_at: str
    categories: List[str] = field(default_factory=list)
    exposures: Optional[List[Any]] = None
    is_free: Optional[bool] = None
    charged: Optional[float] = None
