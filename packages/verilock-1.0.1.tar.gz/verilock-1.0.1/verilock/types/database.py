"""Types for the Database resource."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

__all__ = [
    "DatabaseValidationStatus",
    "DatabaseProvider",
    "DatabaseValidateParams",
    "DatabaseValidationResult",
]

DatabaseValidationStatus = Literal["pending", "completed", "error", "not_found"]


@dataclass
class DatabaseProvider:
    """A government database provider."""

    id: str
    name: str
    countries: List[str] = field(default_factory=list)
    fields: List[str] = field(default_factory=list)


@dataclass
class DatabaseValidateParams:
    """Parameters for validating identity against a government database.

    Example::

        params = DatabaseValidateParams(
            provider="ng_nin",
            first_name="John",
            last_name="Doe",
            date_of_birth="1990-01-15",
            document_number="12345678901",
            country="NG",
        )
    """

    provider: str
    first_name: str
    last_name: str
    session_id: Optional[str] = None
    date_of_birth: Optional[str] = None
    document_number: Optional[str] = None
    country: Optional[str] = None


@dataclass
class DatabaseValidationResult:
    """Result of a database validation check."""

    id: str
    status: DatabaseValidationStatus
    provider: Optional[str] = None
    match_score: Optional[float] = None
    field_matches: Optional[Dict[str, bool]] = None
    result_data: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None
