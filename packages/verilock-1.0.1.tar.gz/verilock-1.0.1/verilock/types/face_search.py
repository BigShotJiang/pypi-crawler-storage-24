"""Types for the Face Search resource."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

__all__ = [
    "FaceSearchParams",
    "FaceSearchMatch",
    "FaceSearchResult",
]


@dataclass
class FaceSearchParams:
    """Parameters for 1:N face duplicate search.

    Example::

        params = FaceSearchParams(session_id="sess_123", threshold=90)
    """

    session_id: str
    threshold: Optional[int] = None


@dataclass
class FaceSearchMatch:
    """A duplicate face match found in the search."""

    session_id: str
    similarity: float
    matched_at: str


@dataclass
class FaceSearchResult:
    """Result of a face search operation."""

    id: str
    duplicate_found: bool
    threshold_used: float
    session_id: Optional[str] = None
    highest_similarity: Optional[float] = None
    matches: List[FaceSearchMatch] = field(default_factory=list)
    created_at: Optional[str] = None
