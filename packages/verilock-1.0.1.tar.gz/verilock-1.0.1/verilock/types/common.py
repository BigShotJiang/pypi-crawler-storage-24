"""Common types shared across all Verilock API resources."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Generic, List, Optional, TypeVar

__all__ = [
    "PaginationMeta",
    "PaginatedResponse",
    "ApiErrorBody",
    "ListParams",
]

T = TypeVar("T")


@dataclass
class PaginationMeta:
    """Pagination metadata returned by list endpoints."""

    current_page: int
    last_page: int
    per_page: int
    total: int


@dataclass
class PaginatedResponse(Generic[T]):
    """Paginated list response wrapping data and metadata."""

    data: List[T]
    meta: PaginationMeta


@dataclass
class ApiErrorBody:
    """Structure of an API error response body."""

    error: str = ""
    message: str = ""
    required: Optional[float] = None
    balance: Optional[float] = None
    count: Optional[int] = None
    price_per_screening: Optional[float] = None


@dataclass
class ListParams:
    """Base parameters for paginated list endpoints."""

    per_page: Optional[int] = None
    page: Optional[int] = None
    from_date: Optional[str] = None
    to_date: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {}
        if self.per_page is not None:
            d["per_page"] = self.per_page
        if self.page is not None:
            d["page"] = self.page
        if self.from_date is not None:
            d["from"] = self.from_date
        if self.to_date is not None:
            d["to"] = self.to_date
        return d
