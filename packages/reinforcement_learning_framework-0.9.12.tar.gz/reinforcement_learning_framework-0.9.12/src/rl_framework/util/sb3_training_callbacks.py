from collections import Counter, deque
from typing import Any, Deque, List, Union

import numpy as np
from stable_baselines3.common.callbacks import BaseCallback, CallbackList


def add_callbacks_to_callback(callbacks_to_add: CallbackList, callback_to_be_added_to: BaseCallback):
    if callback_to_be_added_to is None:
        callback_to_be_added_to = CallbackList([])
    elif not isinstance(callback_to_be_added_to, CallbackList):
        callback_to_be_added_to = CallbackList([callback_to_be_added_to])

    for callback in callbacks_to_add.callbacks:
        if callback not in callback_to_be_added_to.callbacks:
            callback_to_be_added_to.callbacks.append(callback)


class LoggingCallback(BaseCallback):
    """
    A custom callback that logs after every done episode:
        - histogram of performed actions per episode
        - episode rewards
        - mean of any tracked metric (provided as "step_metric_<name>" in the info dict at each step)
        - reason of episode end (provided as "episode_end_reason" in the info dict on terminated step)
    """

    def __init__(self, connector, log_distributions=False, verbose=0):
        """
        Args:
            verbose: Verbosity level: 0 for no output, 1 for info messages, 2 for debug messages
        """
        super().__init__(verbose)
        self.connector = connector
        self.log_distributions = log_distributions

        # Tracking episode reward per episode
        #   (np.array, one index per agent, continuously updated by adding rewards at each step)
        self.episode_reward: Union[np.ndarray | None] = None
        # Tracking actions per episode (one list per agent, updated by appending action at each step)
        # NOTE: Even though officially actions can be Any, for logging we assume they are int or float
        self.episode_actions: Union[List[List[Any]] | None] = None
        # Tracking other numeric metrics for each step episode (name -> value)
        self.episode_step_metrics: dict[str, List[List[float]]] = {}

        # Tracking stats across multiple episodes
        self.episode_end_reasons = deque(maxlen=500)

    def _on_step(self) -> bool:
        """
        This method will be called by the model after each call to `env.step()`.
        If the callback returns False, training is aborted early.
        """
        if self.episode_reward is None:
            self.episode_reward = self.locals["rewards"]
        else:
            self.episode_reward += self.locals["rewards"]

        if self.log_distributions:
            if not self.episode_actions:
                self.episode_actions = [[action] for action in self.locals["actions"]]
            else:
                for agent_index, action in enumerate(self.locals["actions"]):
                    self.episode_actions[agent_index].append(action)

        for agent_index, info in enumerate(self.locals["infos"]):
            for key, value in info.items():
                if key.startswith("step_metric_"):
                    metric_name = key[len("step_metric_") :]
                    if metric_name not in self.episode_step_metrics:
                        self.episode_step_metrics[metric_name] = [[] for _ in range(len(self.locals["infos"]))]
                    self.episode_step_metrics[metric_name][agent_index].append(float(value))
                if key.startswith("meta_"):
                    if isinstance(value, dict):
                        self.connector.log_dict(value, key)
                    else:
                        self.connector.log_dict({key: value}, key)

        done_indices = np.where(self.locals["dones"] == True)[0]
        if done_indices.size != 0:
            for done_index in done_indices:
                if not self.locals["infos"][done_index].get("discard", False):
                    self.connector.log_value_with_timestep(
                        self.num_timesteps, self.episode_reward[done_index], "Episode reward"
                    )
                    # Log other tracked step metrics
                    for metric_name, per_agent_values in self.episode_step_metrics.items():
                        if per_agent_values[done_index]:
                            self.connector.log_value_with_timestep(
                                self.num_timesteps,
                                np.mean(per_agent_values[done_index]),
                                value_name=f"Mean - {metric_name}",
                                title_name=metric_name,
                            )
                            self.connector.log_value_with_timestep(
                                self.num_timesteps,
                                np.std(per_agent_values[done_index]),
                                value_name=f"Std - {metric_name}",
                                title_name=metric_name,
                            )
                            self.connector.log_value_with_timestep(
                                self.num_timesteps,
                                np.max(per_agent_values[done_index]),
                                value_name=f"Max - {metric_name}",
                                title_name=metric_name,
                            )
                            self.connector.log_value_with_timestep(
                                self.num_timesteps,
                                np.min(per_agent_values[done_index]),
                                value_name=f"Min - {metric_name}",
                                title_name=metric_name,
                            )

                if self.locals["infos"][done_index].get("episode_end_reason", None) is not None:
                    self.episode_end_reasons.append(self.locals["infos"][done_index]["episode_end_reason"])
                    counter = Counter(self.episode_end_reasons)
                    for reason, count in counter.items():
                        self.connector.log_value_with_timestep(
                            self.num_timesteps,
                            count / len(self.episode_end_reasons),
                            value_name=f"Episode end reason - {reason}",
                            title_name="Episode end reasons",
                        )

                if self.log_distributions:
                    # Log action distribution
                    if self.episode_actions[done_index]:
                        if isinstance(self.episode_actions[done_index][0], np.ndarray):
                            for action_index, action_sequence in enumerate(zip(*self.episode_actions[done_index])):
                                self.connector.log_histogram_with_timestep(
                                    self.num_timesteps,
                                    np.array(action_sequence),
                                    f"Action distribution - action dim {action_index}",
                                )
                        else:
                            self.connector.log_histogram_with_timestep(
                                self.num_timesteps, np.array(self.episode_actions[done_index]), "Action distribution"
                            )

                    # Log other tracked step metric distributions
                    for metric_name, per_agent_values in self.episode_step_metrics.items():
                        if per_agent_values[done_index]:
                            self.connector.log_histogram_with_timestep(
                                self.num_timesteps,
                                np.array(per_agent_values[done_index]),
                                f"Distribution - {metric_name}",
                            )

                # Reset trackers for done agent
                self.episode_reward[done_index] = 0
                for metric_name in self.episode_step_metrics.keys():
                    self.episode_step_metrics[metric_name][done_index] = []
                if self.episode_actions:
                    self.episode_actions[done_index] = []

        return True


class SavingCallback(BaseCallback):
    """
    A custom callback which uploads the agent to the connector after every `checkpoint_frequency` steps.
    """

    def __init__(self, agent, connector, checkpoint_frequency=50000, verbose=0):
        """
        Args:
            checkpoint_frequency: After how many steps a checkpoint should be saved to the connector.
            verbose: Verbosity level: 0 for no output, 1 for info messages, 2 for debug messages
        """
        super().__init__(verbose)
        self.agent = agent
        self.connector = connector
        self.checkpoint_frequency = checkpoint_frequency
        self.next_upload = checkpoint_frequency

    def _on_step(self) -> bool:
        """
        This method will be called by the model after each call to `env.step()`.
        If the callback returns False, training is aborted early.
        """
        if self.num_timesteps > self.next_upload:
            self.connector.upload(
                agent=self.agent,
                checkpoint_id=self.num_timesteps,
            )
            self.next_upload = self.num_timesteps + self.checkpoint_frequency

        return True


class ExperimentPruningCallback(BaseCallback):
    """
    A custom callback which stop the training the experiment does not reach performance threshold at given step amount.
    """

    def __init__(self, episode_reward_threshold: float = 0.0, pruning_start_at: int = 1000000, verbose=0):
        """
        Args:
            episode_reward_threshold: If the mean episode reward of the last 1000 episodes is below this threshold
                (after `pruning_start_at` steps), the experiment will be pruned.
            pruning_start_at: After how many steps the potential pruning should start.
            verbose: Verbosity level: 0 for no output, 1 for info messages, 2 for debug messages
        """
        super().__init__(verbose)

        self.episode_reward_threshold = episode_reward_threshold
        self.pruning_start_at = pruning_start_at

        # Continuously tracking episode reward for all agents
        #   (np.array, one index per agent, continuously updated by adding rewards at each step)
        self.accumulation_of_episode_reward: Union[np.ndarray | None] = None
        # Saving episode rewards of last 1000 episodes (for all agents)
        self.episode_rewards: Deque[float] = deque(maxlen=1000)

    def _on_step(self) -> bool:
        """
        This method will be called by the model after each call to `env.step()`.
        If the callback returns False, training is aborted early.
        """
        if self.episode_reward is None:
            self.episode_reward = self.locals["rewards"]
        else:
            self.episode_reward += self.locals["rewards"]

        done_indices = np.where(self.locals["dones"] == True)[0]
        if done_indices.size != 0:
            for done_index in done_indices:
                if not self.locals["infos"][done_index].get("discard", False):
                    self.episode_rewards.append(self.episode_reward[done_index])
                # Reset trackers for done agent
                self.episode_reward[done_index] = 0

        if self.num_timesteps > self.pruning_start_at and len(self.episode_rewards) == self.episode_rewards.maxlen:
            mean_episode_reward = np.mean(self.episode_rewards)
            if mean_episode_reward < self.episode_reward_threshold:
                return False

        return True


class ResetInfoCallback(BaseCallback):
    """
    A custom callback that logs after every reset the reset_infos dict..
    """

    def __init__(self, connector, verbose=0):
        """
        Args:
            verbose: Verbosity level: 0 for no output, 1 for info messages, 2 for debug messages
        """
        super().__init__(verbose)
        self.connector = connector
        # Tracking episode number for each agent (agent index -> episode count)
        self.episode_counter: dict[str, int] = {}
        # Tracking agents which have done a first step (list of agent indices)
        self.first_step_tracker: list[str] = []

    def _on_step(self) -> bool:
        """
        This method will be called by the model after each call to `env.step()`.
        If the callback returns False, training is aborted early.
        """

        # Write reset info at first step of first episode
        for agent_index, reset_info in enumerate(self.locals["reset_infos"]):
            if agent_index not in self.first_step_tracker:
                self.episode_counter[agent_index] = 0
                self.first_step_tracker.append(agent_index)
                if reset_info:
                    self.connector.log_dict(
                        reset_info,
                        f"Reset Info - Agent {agent_index} - Episode {self.episode_counter.get(agent_index, 0)}",
                    )

        # Write reset info at each reset (when done=True, reset has already happened and reset_info is available)
        done_indices = np.where(self.locals["dones"] == True)[0]
        if done_indices.size != 0:
            for done_index in done_indices:
                self.episode_counter[done_index] = self.episode_counter.get(done_index, 0) + 1
                reset_info = self.locals["reset_infos"][done_index]
                if reset_info:
                    self.connector.log_dict(
                        reset_info,
                        f"Reset Info - Agent {done_index} - Episode {self.episode_counter.get(done_index, 0)}",
                    )

        return True
