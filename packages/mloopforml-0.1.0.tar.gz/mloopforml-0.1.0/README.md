# mloopforml

Neural network surrogate hyperparameter optimization via a simple decorator.

```python
import mloopforml as mloop

@mloop.optimize(params={"lr": (0.001, 0.1)}, max_iterations=30, direction="maximize")
def train(lr):
    # your model training here
    return accuracy

result = train()
print(result.best_params, result.best_score)
```

## Install

```bash
pip install mloopforml
```

## Requirements

- Python >=3.11
- numpy >=2.0
- scipy >=1.15
