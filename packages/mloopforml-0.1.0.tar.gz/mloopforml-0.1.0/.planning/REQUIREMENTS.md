# Requirements: mloopforml

**Defined:** 2026-03-06
**Core Value:** A researcher can `pip install mloopforml`, write a decorator with parameter ranges, and have a working hyperparameter optimization loop running in under 5 minutes — without learning a framework.

## v1 Requirements

### Packaging

- [x] **PKG-01**: Package is installable via `pip install mloopforml` from PyPI
- [x] **PKG-02**: Package publishes to PyPI automatically on version tag via GitHub Actions (Trusted Publishing / OIDC — no long-lived API tokens)
- [x] **PKG-03**: Package ships both sdist and wheel so users on restricted systems don't need a compiler
- [x] **PKG-04**: Runtime dependencies are numpy>=2.0 and scipy>=1.15 only — no ML framework (PyTorch, TensorFlow, scikit-learn) required at runtime
- [x] **PKG-05**: Package requires Python >=3.11 and declares this in pyproject.toml
- [x] **PKG-06**: Version is single-sourced in pyproject.toml and accessible at runtime via `mloopforml.__version__`

### API

- [ ] **API-01**: User can decorate a wrapper function with `@mloop.optimize(params={"lr": (0.001, 0.1)})` to define an optimization target
- [ ] **API-02**: User can specify continuous hyperparameter ranges as `(min, max)` float tuples
- [ ] **API-03**: User can set `max_iterations` on the decorator to control total trial count
- [ ] **API-04**: User can set `direction="minimize"` or `direction="maximize"` to control optimization direction
- [ ] **API-05**: User can set `seed` for reproducible runs
- [ ] **API-06**: Calling the decorated function triggers the optimization loop and blocks until complete
- [ ] **API-07**: Importing the module does not trigger any optimization logic
- [ ] **API-08**: Invalid parameter bounds (min >= max, non-numeric) raise a clear `ValueError` at decoration time, not at iteration time

### Optimizer

- [ ] **OPT-01**: Optimizer runs a bootstrap phase of `max(10, 2 * n_params)` random trials before the neural net surrogate activates
- [ ] **OPT-02**: After bootstrap, optimizer uses a numpy-only neural net surrogate (MLP) to propose the next candidate via scipy.optimize.minimize
- [ ] **OPT-03**: All proposed parameter values are clipped to declared bounds (guard against floating-point boundary violations from scipy)
- [ ] **OPT-04**: Surrogate uses multiple random restarts (>=5) in scipy minimize to avoid local minima traps
- [ ] **OPT-05**: Surrogate input and output values are normalized internally (StandardScaler equivalent) — normalized values are never exposed externally
- [ ] **OPT-06**: If the objective function raises an exception, the error is logged at WARNING with full traceback and the trial is skipped (optimizer continues)

### Results

- [ ] **RES-01**: Decorated function returns an `OptimizeResult` object with `best_params` (dict) and `best_score` (float)
- [ ] **RES-02**: `OptimizeResult` also exposes `all_params` (list of dicts) and `all_costs` (list of floats) for full history access

### Observability

- [ ] **OBS-01**: Each completed trial is logged to stdout in format: `[Trial N/M] params={...} score=X.XXX (best: X.XXX)`
- [ ] **OBS-02**: Bootstrap phase is clearly identified in logs so users understand why early trials appear random

### Example

- [ ] **EX-01**: Repository includes a working example (`examples/sklearn_iris.py` or similar) demonstrating the decorator pattern on a real ML use case
- [ ] **EX-02**: README includes a minimal install-and-run example a user can copy-paste and execute in under 5 minutes

## v2 Requirements

### Parameter Types

- **PARAM-01**: User can specify integer (discrete) parameter ranges
- **PARAM-02**: User can specify categorical parameters (string choices)
- **PARAM-03**: User can specify log-scale continuous ranges for parameters spanning orders of magnitude (e.g., learning rate)

### Execution

- **EXEC-01**: User can run multiple trials in parallel (parallel objective evaluation)
- **EXEC-02**: User can supply a per-trial callback function invoked after each trial completes

### Observability

- **OBS-03**: User can access convergence plot showing score vs. trial number
- **OBS-04**: User can export full run history to CSV

### Integrations

- **INT-01**: User can log trials to Weights & Biases via callback
- **INT-02**: User can log trials to MLflow via callback

## Out of Scope

| Feature | Reason |
|---------|--------|
| Pruning / early stopping | Requires objective to report intermediate values — breaks the "return a float" API contract |
| Dashboard or web UI | Separate product; stdout logging is sufficient for v1 |
| CLI interface | Not core to decorator-based API; users run Python scripts |
| Distributed execution | Ray Tune exists for this; out of mloopforml's scope |
| Categorical / integer params | Requires surrogate architecture changes; defer to v2 |
| PyTorch / TensorFlow as runtime dep | Would collapse adoption on ML clusters; numpy-only is non-negotiable |
| Auto-convergence / early stop | User controls iteration count; predictable runtime is more valuable for v1 |

## Traceability

Which phases cover which requirements. Updated during roadmap creation.

| Requirement | Phase | Status |
|-------------|-------|--------|
| PKG-01 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-02 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-03 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-04 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-05 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| PKG-06 | Phase 1: Scaffold & Packaging Pipeline | Complete |
| API-01 | Phase 2: Parameter Space & Results Layer | Pending |
| API-02 | Phase 2: Parameter Space & Results Layer | Pending |
| API-03 | Phase 2: Parameter Space & Results Layer | Pending |
| API-04 | Phase 2: Parameter Space & Results Layer | Pending |
| API-05 | Phase 2: Parameter Space & Results Layer | Pending |
| API-07 | Phase 2: Parameter Space & Results Layer | Pending |
| API-08 | Phase 2: Parameter Space & Results Layer | Pending |
| RES-01 | Phase 2: Parameter Space & Results Layer | Pending |
| RES-02 | Phase 2: Parameter Space & Results Layer | Pending |
| OPT-01 | Phase 3: Neural Net Surrogate | Pending |
| OPT-02 | Phase 3: Neural Net Surrogate | Pending |
| OPT-03 | Phase 3: Neural Net Surrogate | Pending |
| OPT-04 | Phase 3: Neural Net Surrogate | Pending |
| OPT-05 | Phase 3: Neural Net Surrogate | Pending |
| OPT-06 | Phase 3: Neural Net Surrogate | Pending |
| API-06 | Phase 4: Optimizer Loop, Public API & Example | Pending |
| OBS-01 | Phase 4: Optimizer Loop, Public API & Example | Pending |
| OBS-02 | Phase 4: Optimizer Loop, Public API & Example | Pending |
| EX-01 | Phase 4: Optimizer Loop, Public API & Example | Pending |
| EX-02 | Phase 4: Optimizer Loop, Public API & Example | Pending |

**Coverage:**
- v1 requirements: 26 total
- Mapped to phases: 26
- Unmapped: 0 ✓

---
*Requirements defined: 2026-03-06*
*Last updated: 2026-03-06 after initial definition*
