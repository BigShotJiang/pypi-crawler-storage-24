# Roadmap: mloopforml

**Created:** 2026-03-06
**Granularity:** Coarse
**Coverage:** 26/26 v1 requirements mapped ✓

---

## Phases

- [x] **Phase 1: Scaffold & Packaging Pipeline** - Repo structure, pyproject.toml, CI/CD publish to PyPI
- [ ] **Phase 2: Parameter Space & Results Layer** - Validated param bounds, `OptimizeResult` dataclass
- [ ] **Phase 3: Neural Net Surrogate** - numpy-only MLP with normalization, bootstrap threshold, scipy restarts
- [ ] **Phase 4: Optimizer Loop, Public API & Example** - Full optimization loop, `@optimize` decorator, end-to-end example

---

## Phase Details

### Phase 1: Scaffold & Packaging Pipeline

**Goal:** A properly structured, publishable Python package exists on PyPI before any library code is written.

**Depends on:** Nothing (first phase)

**Requirements:** PKG-01, PKG-02, PKG-03, PKG-04, PKG-05, PKG-06

**Success Criteria** (what must be TRUE):
  1. Running `pip install mloopforml` on a clean environment installs the package without errors
  2. A `v*` git tag triggers GitHub Actions to build and publish sdist + wheel to PyPI automatically (no manual upload, no long-lived API tokens)
  3. `import mloopforml; mloopforml.__version__` returns a version string matching the tag
  4. The installed package pulls in only `numpy` and `scipy` as runtime dependencies — no PyTorch, TensorFlow, or scikit-learn

**Plans:** 2 plans

Plans:
- [x] 01-01-PLAN.md — Repo scaffold: pyproject.toml, src layout, version tests, build artifacts (PKG-01, PKG-03, PKG-04, PKG-05, PKG-06)
- [x] 01-02-PLAN.md — GitHub Actions CI/CD: test matrix + OIDC Trusted Publishing to TestPyPI and PyPI (PKG-02, PKG-03)

---

### Phase 2: Parameter Space & Results Layer

**Goal:** Users can declare hyperparameter ranges that are validated at decoration time, and the result contract is fully defined and tested.

**Depends on:** Phase 1

**Requirements:** API-01, API-02, API-03, API-04, API-05, API-07, API-08, RES-01, RES-02

**Success Criteria** (what must be TRUE):
  1. A user decorating a function with `@mloop.optimize(params={"lr": (0.001, 0.1)}, max_iterations=20, direction="maximize", seed=42)` receives no errors at decoration time
  2. Invalid parameter bounds (e.g., `min >= max`, non-numeric values) raise a `ValueError` immediately when the decorator is applied — not during trial execution
  3. Importing `mloopforml` does not trigger any optimization logic
  4. `OptimizeResult` exposes `best_params`, `best_score`, `all_params`, and `all_costs` with the correct types

**Plans:** TBD

---

### Phase 3: Neural Net Surrogate

**Goal:** The numpy MLP surrogate correctly models a cost landscape, normalizes inputs internally, and proposes useful candidates via scipy — validated in isolation against synthetic objectives before any optimizer integration.

**Depends on:** Phase 2

**Requirements:** OPT-01, OPT-02, OPT-03, OPT-04, OPT-05, OPT-06

**Success Criteria** (what must be TRUE):
  1. The surrogate, given 15+ observations of a sphere function, proposes a next candidate closer to the optimum than random search would on average
  2. All proposed parameter values are always within declared bounds (even when scipy minimization overshoots)
  3. Internally normalized values are never observable in any public output — `best_params`, `all_params`, and log output always show original-scale values
  4. If the bootstrap threshold (`max(10, 2 * n_params)`) has not been reached, only random proposals are issued — no surrogate is used
  5. When the objective function raises an exception during a trial, the error is logged with full traceback at WARNING level and the run continues to the next trial

**Plans:** TBD

---

### Phase 4: Optimizer Loop, Public API & Example

**Goal:** A researcher can `pip install mloopforml`, copy-paste the README example, run it in under 5 minutes, and get a meaningful result — with live trial logs and a final `OptimizeResult`.

**Depends on:** Phase 3

**Requirements:** API-06, OBS-01, OBS-02, EX-01, EX-02

**Success Criteria** (what must be TRUE):
  1. Calling a decorated function blocks until `max_iterations` trials complete, then returns an `OptimizeResult`
  2. Each completed trial prints to stdout in the format `[Trial N/M] params={...} score=X.XXX (best: X.XXX)`, and bootstrap trials are labeled so users understand early randomness
  3. Running `examples/sklearn_iris.py` (or equivalent) produces a visible best score and best params after the run completes
  4. A user following only the README install-and-run example reaches a working optimization loop in under 5 minutes

**Plans:** TBD

---

## Progress

| Phase | Plans Complete | Status | Completed |
|-------|----------------|--------|-----------|
| 1. Scaffold & Packaging Pipeline | 2/2 | Complete | 2026-03-07 |
| 2. Parameter Space & Results Layer | 0/? | Not started | — |
| 3. Neural Net Surrogate | 0/? | Not started | — |
| 4. Optimizer Loop, Public API & Example | 0/? | Not started | — |

---

## Coverage

| Requirement | Phase |
|-------------|-------|
| PKG-01 | Phase 1 |
| PKG-02 | Phase 1 |
| PKG-03 | Phase 1 |
| PKG-04 | Phase 1 |
| PKG-05 | Phase 1 |
| PKG-06 | Phase 1 |
| API-01 | Phase 2 |
| API-02 | Phase 2 |
| API-03 | Phase 2 |
| API-04 | Phase 2 |
| API-05 | Phase 2 |
| API-07 | Phase 2 |
| API-08 | Phase 2 |
| RES-01 | Phase 2 |
| RES-02 | Phase 2 |
| OPT-01 | Phase 3 |
| OPT-02 | Phase 3 |
| OPT-03 | Phase 3 |
| OPT-04 | Phase 3 |
| OPT-05 | Phase 3 |
| OPT-06 | Phase 3 |
| API-06 | Phase 4 |
| OBS-01 | Phase 4 |
| OBS-02 | Phase 4 |
| EX-01 | Phase 4 |
| EX-02 | Phase 4 |

**Total mapped:** 26/26 ✓

---

*Roadmap created: 2026-03-06*
