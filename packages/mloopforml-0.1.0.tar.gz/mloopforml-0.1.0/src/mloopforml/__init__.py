"""mloopforml — neural network surrogate hyperparameter optimization."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("mloopforml")
except PackageNotFoundError:
    # Package not installed (running from source without pip install -e .)
    __version__ = "unknown"

__all__ = ["__version__"]
