"""Smoke tests for package metadata (PKG-04, PKG-06)."""

import importlib.metadata
import sys

import mloopforml


def test_version_is_string():
    """__version__ must be a non-empty string — not 'unknown'."""
    assert isinstance(mloopforml.__version__, str)
    assert mloopforml.__version__ != ""
    assert mloopforml.__version__ != "unknown"


def test_version_matches_metadata():
    """__version__ must match importlib.metadata — no skew allowed (PKG-06)."""
    assert mloopforml.__version__ == importlib.metadata.version("mloopforml")


def test_no_runtime_deps_beyond_numpy_scipy():
    """Importing mloopforml must not pull in ML frameworks (PKG-04)."""
    # mloopforml was already imported above; check sys.modules for unwanted deps
    assert "torch" not in sys.modules
    assert "tensorflow" not in sys.modules
    assert "sklearn" not in sys.modules
