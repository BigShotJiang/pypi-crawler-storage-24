"""Amazon Q installer."""

from pathlib import Path
from src.installer.base import install


def get_config_path():
    return Path.home() / ".aws/amazonq/mcp.json"


def install_amazonq():
    print("🚀 Pier Cloud MCP - Amazon Q Setup\n")
    install(get_config_path(), "Please restart Amazon Q to apply changes.")
