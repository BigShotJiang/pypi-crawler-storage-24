"""AWS Kiro installer."""

from pathlib import Path
from src.installer.base import install


def get_config_path():
    return Path.home() / ".kiro/settings/mcp.json"


def install_kiro():
    print("🚀 Pier Cloud MCP - AWS Kiro Setup\n")
    install(get_config_path(), "Please restart AWS Kiro to apply changes.")
