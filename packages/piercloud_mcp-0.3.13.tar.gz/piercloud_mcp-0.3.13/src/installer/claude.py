"""Claude Desktop installer."""

import sys
import os
from pathlib import Path
from src.installer.base import install


def get_config_path():
    if sys.platform == "darwin":
        return (
            Path.home()
            / "Library/Application Support/Claude/claude_desktop_config.json"
        )
    elif sys.platform == "win32":
        return Path(os.getenv("APPDATA")) / "Claude/claude_desktop_config.json"
    else:
        return Path.home() / ".config/Claude/claude_desktop_config.json"


def install_claude():
    print("🚀 Pier Cloud MCP - Claude Desktop Setup\n")
    install(get_config_path(), "Please restart Claude Desktop to apply changes.")
