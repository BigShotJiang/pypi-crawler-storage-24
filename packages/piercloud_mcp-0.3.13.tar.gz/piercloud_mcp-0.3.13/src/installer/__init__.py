from src.installer.claude import install_claude
from src.installer.amazonq import install_amazonq
from src.installer.kiro import install_kiro
