🛠 Pypower Full Documentation

🕒 Time: For managing clock operations and time conversions.
    how_many_hms_in_s: Calculates how many hours, minutes, and seconds are in total seconds.

    reverse_many_hms: Converts 'HH:MM:SS' string back into total seconds.

    convert_to_iterable_and_int: Converts 'HH:MM:SS' string to a tuple of integers.

    random_time: Generates a random time string in 12 or 24-hour format.

    minus_clock: Calculates the time difference between two 'HH:MM:SS' strings.


🔍 Other: General utilities for system and browser automation.
    copy_pypower: Copies the entire library code to your clipboard.

    search_google: Opens a browser tab to search Google for any text.

    in_bg: Runs any action in a background thread after a specific duration.


🚀 Apps: Tools for application lifecycle and distribution.
    create_app: Automatically builds a standalone .exe from your .py file (handles cleanup and hidden imports).


📂 Files: Simple file system and directory management.
    make_if_not_exists: Creates a folder or an empty file if it's missing.

    append_to_pypower: Appends a labeled code block to the library file.

    append_to_file: Adds text to any file while cleaning up double blank lines.


🎨 GUI: Modern wrappers for CustomTkinter and Turtle graphics.
    CustomTk (Sub Class): For automating modern UI components.
        sync_entry_with_label: Links a CTkEntry's text with a CTkLabel in real-time.

        console: Generates a button grid with optional dictionary return.

        console_num: Creates a 0-9 numeric keypad linked to an entry.

        show_hide_entry_btn: Adds a toggle button to show/hide text in password entries.

        move: Makes any widget draggable across the master window.

        good_size: Resizes a list of widgets to match the largest one.

        tidy_up: Arranges widgets in a perfect grid based on a fixed number per row.

        all_objects: Returns a flat list of all child widgets inside a master.

        edit_all_widgets_texts: Batch edits font and color for all widgets.

        info: Creates a tooltip that appears on hover.

        mouse_wheel_num: Enables number scrolling inside an Entry using the mouse wheel.

        double_clk_copy_label: Copies label text to clipboard on double-click.

        Timer (Inner Class): For creating functional countdown timers.
            start: Begins the countdown and updates the target object.

            stop: Pauses the timer and changes the button icon.

            resume_timer: Resumes a paused timer from its current duration.

    Turtle (Sub Class): For advanced turtle graphics and window boundaries.
        in_circle: Draws a repeated shape in a circular pattern.

        rock_bottom: Checks if the turtle object has hit the window boundaries.

        move: Moves the turtle to a distance without drawing.


📝 String: Advanced methods for text analysis and manipulation.
    between: Extracts the text located between two specific characters.

    there_is_a_number: Checks if a string contains any digits within a range.

    super_join: Inserts a separator every few characters in a string.

    reverse: Reverses the order of words or parts split by a separator.

    replace_objects_with_one: Replaces multiple characters with a single new one.

    replace_many: Maps and replaces a set of characters with another set.


📊 Iterable: Management for Lists, Tuples, and Dictionaries.
    search_iterable: Filters an iterable for items containing a keyword.

    get_circular_index: Safely gets an item by index using modulo.

    any_is_class: Filters objects of a specific class within an iterable.

    numred: Formats a list into a numbered string (e.g., 1. Item).

    replace_iterable: Replaces or removes an object in a list by index.

    all_in: Checks if all elements of one list exist in another.

    return_dict_in_lines: Returns a dictionary formatted as "key: value" lines.

    Dict (Sub Class): For specialized dictionary operations.
        swap_dict: Swaps keys and values in a dictionary (handles list/dict values as strings).


🔢 Math: Fast mathematical shortcuts and sequence generators.
    int_or_float: Validates if a number is a valid integer or float.

    iter_num: Return sum, average, max, and min of an iterable as a dict.

    number_multiplies: Return all multiples of num up to end.

    arrays: Split a range into consecutive [start, end] pairs by step.