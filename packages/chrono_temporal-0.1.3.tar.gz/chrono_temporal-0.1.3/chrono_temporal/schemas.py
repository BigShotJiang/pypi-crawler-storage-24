from pydantic import BaseModel
from datetime import datetime
from typing import Optional, Any


class TemporalRecordCreate(BaseModel):
    """Schema for creating a new temporal record."""
    entity_type: str
    entity_id: str
    valid_from: datetime
    valid_to: Optional[datetime] = None
    data: dict[str, Any]
    notes: Optional[str] = None


class TemporalRecordRead(BaseModel):
    """Schema for reading a temporal record."""
    id: int
    entity_type: str
    entity_id: str
    valid_from: datetime
    valid_to: Optional[datetime] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    data: dict[str, Any]
    notes: Optional[str] = None

    class Config:
        from_attributes = True


class TemporalDiff(BaseModel):
    """Result of a diff between two points in time."""
    entity_type: str
    entity_id: str
    from_dt: str
    to_dt: str
    changed: dict[str, Any]
    added: dict[str, Any]
    removed: dict[str, Any]
    unchanged: list[str]
    has_changes: bool
