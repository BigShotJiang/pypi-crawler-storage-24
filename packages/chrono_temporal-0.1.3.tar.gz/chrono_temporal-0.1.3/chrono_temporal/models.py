from sqlalchemy import Column, Integer, String, DateTime, JSON, Text, func
from chrono_temporal.base import ChronoBase


class TemporalRecord(ChronoBase):
    """
    Core temporal record model.

    Stores any entity with valid_from/valid_to time bounds,
    enabling time-travel queries across the full history of any entity.

    Columns:
        entity_type: Category of entity e.g. "user", "order", "product"
        entity_id:   Unique identifier within the entity type
        valid_from:  When this version of the entity became true
        valid_to:    When this version expired (NULL = still valid)
        created_at:  When this record was inserted (transaction time)
        data:        JSON payload — any fields you want to track
        notes:       Optional human-readable description of the change
    """
    __tablename__ = "temporal_records"

    id = Column(Integer, primary_key=True, index=True)
    entity_type = Column(String(100), nullable=False, index=True)
    entity_id = Column(String(255), nullable=False, index=True)

    valid_from = Column(DateTime(timezone=True), nullable=False)
    valid_to = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    data = Column(JSON, nullable=False)
    notes = Column(Text, nullable=True)
