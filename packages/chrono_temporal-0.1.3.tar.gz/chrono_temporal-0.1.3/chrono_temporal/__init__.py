"""
Chrono Temporal — Time-travel queries for any data entity.

Usage:
    from chrono_temporal import TemporalService, TemporalRecord, TemporalRecordCreate
"""

from chrono_temporal.service import TemporalService
from chrono_temporal.models import TemporalRecord
from chrono_temporal.schemas import TemporalRecordCreate, TemporalRecordRead
from chrono_temporal.base import ChronoBase, get_engine, get_session

__version__ = "0.1.0"
__all__ = [
    "TemporalService",
    "TemporalRecord",
    "TemporalRecordCreate",
    "TemporalRecordRead",
    "ChronoBase",
    "get_engine",
    "get_session",
]
