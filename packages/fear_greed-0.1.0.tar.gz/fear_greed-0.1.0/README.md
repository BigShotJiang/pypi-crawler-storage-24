<div align="center">

<img src="https://upload.wikimedia.org/wikipedia/commons/f/fb/Cnn_logo_red_background.png" width="120" alt="CNN">

# CNN Fear & Greed Index

**The only Python library that actually works.**

Fetch real-time CNN Fear & Greed Index data with full historical data and all 7 indicators — powered by CNN's internal API, not fragile web scraping.

[![PyPI](https://img.shields.io/pypi/v/fear-greed)](https://pypi.org/project/fear-greed/)
[![Python](https://img.shields.io/badge/python-3.9%2B-yellow)](#)
[![License: MIT](https://img.shields.io/badge/license-MIT-lightgrey)](#)

[Installation](#installation) · [Quick Start](#quick-start) · [CLI](#cli) · [API Reference](#api-reference) · [Indicators](#indicators)

</div>

![](https://github.com/tjdwls101010/DUMOK/blob/main/Images/gemini-3-pro-1774099290015fa3l6cyi6.png?raw=true)

---

## Why This Library?

Every other CNN Fear & Greed library on PyPI is **broken**. They rely on HTML scraping that breaks whenever CNN updates their website — and CNN has redesigned it multiple times since 2022.

This library uses **CNN's internal data API directly** — the same one that powers their official page. That means:

- **It actually works** (no scraping, no Selenium, no browser automation)
- **All 7 indicators** with individual scores, not just the overall index
- **1 year of daily history** (~251 trading days) in a single API call
- **Fast** — one lightweight JSON request, no HTML parsing
- **No API key** needed

```python
import fear_greed

fear_greed.get()
# {'score': 14.59, 'rating': 'extreme fear', 'history': {'1w': 22.63, ...}, 'indicators': {...}}
```

### Comparison

| Feature | **fear-greed** | fear-and-greed | fear-greed-index |
|---------|:---------:|:-----------:|:------------:|
| Works in 2025+ | **Yes** | No | No |
| Method | Internal API | Scraping | Scraping |
| Current score | **Yes** | Yes | Yes |
| All 7 indicators | **Yes** | No | Partial |
| Historical data | **1 year** | No | No |
| CLI tool | **Yes** | No | No |
| Last updated | **2026** | 2022 | 2022 |

---

## Installation

```bash
pip install fear-greed
```

Requires Python 3.9+ and `requests`.

---

## Quick Start

```python
import fear_greed

# Get everything in one call
data = fear_greed.get()
print(data['score'])      # 14.59
print(data['rating'])     # 'extreme fear'
print(data['history'])    # {'1w': 22.63, '1m': 44.41, '3m': 54.89, '6m': 56.77, '1y': 21.69}
print(data['indicators']) # All 7 indicators with scores and ratings

# Just the score
fear_greed.get_score()    # 14.59

# Just the rating
fear_greed.get_rating()   # 'extreme fear'

# Historical data (last 3 months)
fear_greed.get_history(last="3m")
# [{'date': '2026-03-20', 'score': 14.59, 'rating': 'extreme fear'}, ...]

# Date range
fear_greed.get_history(start="2025-06-01", end="2025-12-31")
```

---

## CLI

```bash
# Current score + all indicators + history snapshots
fear-greed

# Historical data
fear-greed history                             # Full year (~251 days)
fear-greed history --last 30                   # Last 30 days
fear-greed history --last 3m                   # Last 3 months
fear-greed history --start 2025-06-01          # From a date
fear-greed history --start 2025-06 --end 2025-12  # Date range

# What each indicator means
fear-greed info

# Compact output (single line JSON)
fear-greed --compact
```

### Example Output

```bash
$ fear-greed
```

```json
{
  "score": 14.59,
  "rating": "extreme fear",
  "timestamp": "2026-03-20T23:59:51+00:00",
  "history": {
    "1w": 22.63,
    "1m": 44.41,
    "3m": 54.89,
    "6m": 56.77,
    "1y": 21.69
  },
  "indicators": {
    "market_momentum_sp500": { "score": 1.2, "rating": "extreme fear" },
    "stock_price_strength":  { "score": 18.0, "rating": "extreme fear" },
    "stock_price_breadth":   { "score": 5.2, "rating": "extreme fear" },
    "put_call_options":      { "score": 3.6, "rating": "extreme fear" },
    "market_volatility_vix": { "score": 40.74, "rating": "fear" },
    "junk_bond_demand":      { "score": 19.4, "rating": "extreme fear" },
    "safe_haven_demand":     { "score": 13.8, "rating": "extreme fear" }
  }
}
```

---

## API Reference

### `fear_greed.get() -> dict`

Returns the full Fear & Greed snapshot: current score, history comparisons (1w/1m/3m/6m/1y), and all 7 indicator scores.

### `fear_greed.get_history(last=None, start=None, end=None) -> list`

Returns daily historical data as a list of `{date, score, rating}` dicts, sorted newest-first.

| Parameter | Type | Example | Description |
|-----------|------|---------|-------------|
| `last` | str | `"30"`, `"7d"`, `"2w"`, `"3m"` | Recent period |
| `start` | str | `"2025-06-01"` | Start date |
| `end` | str | `"2025-12-31"` | End date |

### `fear_greed.get_score() -> float`

Returns the current index score (0–100).

### `fear_greed.get_rating() -> str`

Returns the current rating: `"extreme fear"`, `"fear"`, `"neutral"`, `"greed"`, or `"extreme greed"`.

### `fear_greed.fetch() -> dict`

Returns the raw API response for advanced use.

---

## Indicators

The Fear & Greed Index is calculated from 7 market indicators. Each is scored 0–100.

| Indicator | Measures | Fear Signal | Greed Signal |
|-----------|----------|-------------|--------------|
| **Market Momentum** | S&P 500 vs 125-day moving average | Below average | Above average |
| **Stock Price Strength** | NYSE 52-week highs vs lows | More lows | More highs |
| **Stock Price Breadth** | McClellan Volume Summation Index | Low/negative volume | High rising volume |
| **Put/Call Options** | 5-day average put/call ratio | Ratio > 1 (bearish) | Ratio < 1 (bullish) |
| **Market Volatility** | VIX vs 50-day moving average | Rising VIX | Falling VIX |
| **Safe Haven Demand** | 20-day stock vs bond returns | Bonds outperform | Stocks outperform |
| **Junk Bond Demand** | Junk vs investment grade yield spread | Wider spread | Narrower spread |

Run `fear-greed info` for detailed descriptions.

---

## Disclaimer

This project is **not affiliated with CNN or Warner Bros. Discovery**. Data is fetched from CNN's publicly accessible API. For the official index, visit [CNN Fear & Greed Index](https://edition.cnn.com/markets/fear-and-greed).

This tool is for **educational and research purposes**. It is not financial advice.

---

## License

MIT
