from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone


def _parse_timestamp(value) -> datetime:
    if isinstance(value, str):
        return datetime.fromisoformat(value)
    return datetime.fromtimestamp(value / 1000, tz=timezone.utc)


@dataclass
class HistoricalPoint:
    date: datetime
    score: float
    rating: str

    @classmethod
    def from_api(cls, item: dict) -> HistoricalPoint:
        return cls(
            date=datetime.fromtimestamp(item["x"] / 1000, tz=timezone.utc),
            score=item["y"],
            rating=item["rating"],
        )

    def to_dict(self) -> dict:
        return {
            "date": self.date.strftime("%Y-%m-%d"),
            "score": round(self.score, 2),
            "rating": self.rating,
        }
