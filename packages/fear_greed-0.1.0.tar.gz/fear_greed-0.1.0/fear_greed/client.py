from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone

import requests

from .models import HistoricalPoint

API_URL = "https://production.dataviz.cnn.io/index/fearandgreed/graphdata"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
    "Referer": "https://edition.cnn.com/",
    "Accept": "application/json",
}

INDICATOR_KEYS = [
    "market_momentum_sp500",
    "stock_price_strength",
    "stock_price_breadth",
    "put_call_options",
    "market_volatility_vix",
    "junk_bond_demand",
    "safe_haven_demand",
]

INDICATOR_INFO = {
    "market_momentum_sp500": {
        "name": "Market Momentum",
        "measure": "S&P 500 vs its 125-day moving average",
        "description": (
            "When the S&P 500 is above its 125-day moving average, "
            "that signals positive momentum (Greed). Below it signals Fear."
        ),
    },
    "stock_price_strength": {
        "name": "Stock Price Strength",
        "measure": "Net new 52-week highs and lows on the NYSE",
        "description": (
            "Compares NYSE stocks hitting 52-week highs vs lows. "
            "Many more highs than lows is bullish and signals Greed."
        ),
    },
    "stock_price_breadth": {
        "name": "Stock Price Breadth",
        "measure": "McClellan Volume Summation Index",
        "description": (
            "Measures the volume of rising shares vs falling shares on the NYSE. "
            "Decreasing breadth signals Fear."
        ),
    },
    "put_call_options": {
        "name": "Put and Call Options",
        "measure": "5-day average put/call ratio",
        "description": (
            "A rising put/call ratio means investors are buying more puts (bearish bets). "
            "A ratio above 1 is bearish and signals Fear."
        ),
    },
    "market_volatility_vix": {
        "name": "Market Volatility",
        "measure": "VIX and its 50-day moving average",
        "description": (
            "The CBOE Volatility Index (VIX) measures expected S&P 500 volatility. "
            "Higher VIX means more fear. It tends to be lower in bull markets."
        ),
    },
    "safe_haven_demand": {
        "name": "Safe Haven Demand",
        "measure": "Difference in 20-day stock and bond returns",
        "description": (
            "When bonds outperform stocks, investors are seeking safety. "
            "Increasing safe haven demand signals Fear."
        ),
    },
    "junk_bond_demand": {
        "name": "Junk Bond Demand",
        "measure": "Yield spread: junk bonds vs investment grade",
        "description": (
            "A smaller spread between junk bond and investment grade yields means "
            "investors are taking on more risk (Greed). A wider spread signals Fear."
        ),
    },
}


def _parse_duration(s: str) -> timedelta:
    s = s.strip().lower()
    m = re.fullmatch(r"(\d+)\s*([dwm])?", s)
    if not m:
        raise ValueError(f"Invalid duration: {s!r}. Examples: 30, 7d, 2w, 3m")
    n = int(m.group(1))
    unit = m.group(2) or "d"
    if unit == "d":
        return timedelta(days=n)
    if unit == "w":
        return timedelta(weeks=n)
    if unit == "m":
        return timedelta(days=n * 30)
    raise ValueError(f"Unknown unit: {unit}")


def _find_closest_point(
    points: list[HistoricalPoint], target: datetime,
) -> HistoricalPoint | None:
    if not points:
        return None
    return min(points, key=lambda p: abs((p.date - target).total_seconds()))


class FearGreedClient:
    def __init__(self, timeout: int = 10):
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(HEADERS)

    def fetch(self) -> dict:
        resp = self._session.get(API_URL, timeout=self._timeout)
        resp.raise_for_status()
        return resp.json()

    def get(self) -> dict:
        data = self.fetch()
        fg = data["fear_and_greed"]
        historical = [
            HistoricalPoint.from_api(p)
            for p in data["fear_and_greed_historical"]["data"]
        ]

        now = datetime.now(timezone.utc)
        history = {
            "1w": round(fg["previous_1_week"], 2),
            "1m": round(fg["previous_1_month"], 2),
        }
        for label, delta in [("3m", timedelta(days=90)), ("6m", timedelta(days=180))]:
            pt = _find_closest_point(historical, now - delta)
            history[label] = round(pt.score, 2) if pt else None
        history["1y"] = round(fg["previous_1_year"], 2)

        indicators = {}
        for key in INDICATOR_KEYS:
            if key in data:
                indicators[key] = {
                    "score": round(data[key]["score"], 2),
                    "rating": data[key]["rating"],
                }

        return {
            "score": round(fg["score"], 2),
            "rating": fg["rating"],
            "timestamp": datetime.fromisoformat(fg["timestamp"]).isoformat(),
            "history": history,
            "indicators": indicators,
        }

    def get_history(
        self,
        last: str | None = None,
        start: str | None = None,
        end: str | None = None,
    ) -> list[HistoricalPoint]:
        data = self.fetch()
        points = [
            HistoricalPoint.from_api(p)
            for p in data["fear_and_greed_historical"]["data"]
        ]

        if last:
            delta = _parse_duration(last)
            cutoff = datetime.now(timezone.utc) - delta
            points = [p for p in points if p.date >= cutoff]
        else:
            if start:
                start_dt = datetime.fromisoformat(start).replace(tzinfo=timezone.utc)
                points = [p for p in points if p.date >= start_dt]
            if end:
                end_dt = datetime.fromisoformat(end).replace(tzinfo=timezone.utc)
                # Include the full end day
                end_dt = end_dt.replace(hour=23, minute=59, second=59)
                points = [p for p in points if p.date <= end_dt]

        points.sort(key=lambda p: p.date, reverse=True)
        return points

    def get_score(self) -> float:
        data = self.fetch()
        return data["fear_and_greed"]["score"]

    def get_rating(self) -> str:
        data = self.fetch()
        return data["fear_and_greed"]["rating"]
