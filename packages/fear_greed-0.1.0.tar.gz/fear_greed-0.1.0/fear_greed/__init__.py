"""CNN Fear & Greed Index API client."""

from .client import FearGreedClient, INDICATOR_INFO
from .models import HistoricalPoint

_default_client = FearGreedClient()


def fetch() -> dict:
    """Return raw API response as dict."""
    return _default_client.fetch()


def get() -> dict:
    """Get current score, history snapshots, and all indicators."""
    return _default_client.get()


def get_history(
    last: str | None = None,
    start: str | None = None,
    end: str | None = None,
) -> list[HistoricalPoint]:
    """Get historical data with optional filtering.

    Args:
        last: Duration like "30", "7d", "2w", "3m"
        start: Start date "YYYY-MM-DD"
        end: End date "YYYY-MM-DD"
    """
    return _default_client.get_history(last=last, start=start, end=end)


def get_score() -> float:
    """Get current score (0-100)."""
    return _default_client.get_score()


def get_rating() -> str:
    """Get current rating string."""
    return _default_client.get_rating()
