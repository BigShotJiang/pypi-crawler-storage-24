from __future__ import annotations

import argparse
import json
import sys

from .client import FearGreedClient, INDICATOR_INFO


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="fear-greed",
        description="CNN Fear & Greed Index CLI",
    )
    p.add_argument("--compact", action="store_true", help="Compact JSON output")
    p.add_argument("--raw", action="store_true", help="Output raw API response")

    sub = p.add_subparsers(dest="command")

    hist = sub.add_parser("history", help="Show historical data")
    hist.add_argument("--last", metavar="PERIOD", help="e.g. 30, 7d, 2w, 3m")
    hist.add_argument("--start", metavar="DATE", help="Start date (YYYY-MM-DD)")
    hist.add_argument("--end", metavar="DATE", help="End date (YYYY-MM-DD)")

    sub.add_parser("info", help="Show indicator descriptions")

    return p


def _cmd_info() -> None:
    for key, info in INDICATOR_INFO.items():
        print(f"\033[1m{info['name']}\033[0m  ({key})")
        print(f"  Measures: {info['measure']}")
        print(f"  {info['description']}")
        print()


def main(argv: list[str] | None = None) -> None:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "info":
        _cmd_info()
        return

    indent = None if args.compact else 2
    client = FearGreedClient()

    try:
        if args.raw:
            result = client.fetch()
        elif args.command == "history":
            points = client.get_history(
                last=args.last, start=args.start, end=args.end,
            )
            result = [p.to_dict() for p in points]
        else:
            result = client.get()

        json.dump(result, sys.stdout, indent=indent, ensure_ascii=False)
        sys.stdout.write("\n")
    except Exception as e:
        json.dump({"error": str(e)}, sys.stderr, ensure_ascii=False)
        sys.stderr.write("\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
