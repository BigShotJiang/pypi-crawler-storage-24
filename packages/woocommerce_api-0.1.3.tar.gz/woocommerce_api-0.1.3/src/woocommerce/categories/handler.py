from typing import Optional
import requests
from woocommerce.categories.models import CreateCategory

class CategoryHandler:

    def __init__(self, woocommerce_base_url: str, woocommerce_auth: tuple[str]):
        """Class to handle category's operations

        Args:
            woocommerce_base_url (str): The base URL of your woocommerce instance www.<...>.com. Do not add the /wp-json/...
            woocommerce_auth (tuple[str]): A tuple with auth key from woocommerce in the type (ck_...,cs_...)
        """
        self.woocommerce_url = woocommerce_base_url
        self.formatted_url = f'{self.woocommerce_url}/wp-json/wc/v3/products/categories'
        self.auth = woocommerce_auth

    def retrieve_categories(self, extra_data: bool = False) -> list[dict]:
        """Retrieves categories data from the API

        Args:
            extra_data (bool, optional): If False, it will return only name and ID, if set to true it will retrieve all the category properties. Defaults to False.

        Returns:
            list[dict]: Output from the API
        """
        res = requests.get(
            url=self.formatted_url,
            auth=self.auth
        )

        data = res.json()

        if not extra_data:
            data = [{"ID":d['id'], "Name": d['name'], "Slug":d["slug"]} for d in data]

        return data
    
    def create_category(self, category: CreateCategory) -> dict:
        res = requests.post(
            url= self.formatted_url,
            auth=self.auth,
            data=category
        )

        return res.json()
    
    def retrive_category_by_id(self, id: int) -> dict:
        res = requests.get(
            url=f'{self.formatted_url}/{id}'
        )
        return res.json()
    
    def update_category(self, id: int, **kwargs) -> dict:
        res = requests.put(
            url=f'{self.formatted_url}/{id}',
            json=kwargs
        )

        return res.json()
    
    def delete_category(self, id: int, force: bool) -> dict:
        res = requests.delete(
            url=f'{self.formatted_url}/{id}',
            params={'force':force}
        )
        return res.json()
    
    def batch_update(self, create: Optional[list[dict]] = None, update: Optional[list[dict]] = None, delete: Optional[list[int]] = None):
        d = {}
        if create:
            d["create"] = create
        if update:
            d["update"] = update
        if delete:
            d["delete"] = delete
        res = requests.post(
            url=f'{self.formatted_url}/batch',
            data=d
        )
        return res.json()
        
