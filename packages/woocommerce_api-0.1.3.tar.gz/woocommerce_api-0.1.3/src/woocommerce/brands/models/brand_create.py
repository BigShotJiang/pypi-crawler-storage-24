from dataclasses import dataclass, field
from woocommerce.images import ImageProperties

@dataclass
class BrandCreate:
    name: str = field(metadata={"doc": "Category name.mandatory"})
    slug: str = field(metadata={"doc": "An alphanumeric identifier for the resource unique to its type."})
    parent: int = field(metadata={"doc": "The ID for the parent of the resource."})
    description: str = field(metadata={"doc": "HTML description of the resource."})
    display: str = field(metadata={"doc": "Category archive display type. Options: default, products, subcategories and both. Default is default."})
    image: ImageProperties = field(metadata={"doc": "See ImageProperties doc."})
    menu_order: int = field(metadata={"doc": "Menu order, used to custom sort the resource."})