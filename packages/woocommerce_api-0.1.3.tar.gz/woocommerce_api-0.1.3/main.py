from fastapi import FastAPI

app = FastAPI(
    title="woocommerce-api"
)

