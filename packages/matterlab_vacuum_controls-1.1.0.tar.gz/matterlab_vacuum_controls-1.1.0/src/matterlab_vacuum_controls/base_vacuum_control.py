from abc import ABC, abstractmethod
from logging import Logger, getLogger
from typing import Optional


class VacuumControl(ABC):
    category = "Vacuum"
    ui_fields = "com_port"
    min_pressure: float

    _pressure_query: str
    _pressure_set: str
    _vacuo_start: str
    _vacuo_stop: str

    _switch_pressure: int = 1000

    def __init__(self, min_pressure: float, logger: Optional[Logger] = None):
        self._target_pressure: float
        self._vacuum_switch_status: bool
        self._min_pressure = min_pressure
        self.logger = logger if logger is not None else getLogger(
            f"{self.__class__.__module__}.{self.__class__.__name__}"
        )

    @abstractmethod
    def _query_vacuum(self, command: str) ->str:
        pass

    def standby(self) ->None:
        self.logger.info("Setting vacuum controller to standby pressure %s", self._switch_pressure)
        self.pressure = self._switch_pressure

    @property
    @abstractmethod
    def pressure(self) -> float:
        pass

    @pressure.setter
    @abstractmethod
    def pressure(self, pressure: float) -> None:
        pass

    @property
    @abstractmethod
    def target_pressure(self) -> float:
        pass
    
    @property
    @abstractmethod
    def _vacuum_switch(self) ->bool:
        pass

    @_vacuum_switch.setter
    @abstractmethod
    def _vacuum_switch(self, vacuum_switch_status: bool) ->None:
        pass