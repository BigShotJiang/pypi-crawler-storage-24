from __future__ import annotations

from dataclasses import dataclass

from matterlab_serial_device import ScriptedSerialTransport
from matterlab_serial_device.transport import SerialTransportConfig


@dataclass
class IKAVC10SimState:
    name: str = "VC10"
    temp: float = 25.0
    pressure: int = 1000
    target_pressure: int = 1000
    hysteresis: int = 10
    mode: int = 1
    error: str = "0"
    vacuum_on: bool = False


class IKAVC10SimProtocol:
    def __init__(self, state: IKAVC10SimState) -> None:
        self.state = state

    def __call__(self, write_data: bytes, expected: bytes, size: int | None) -> bytes:
        del expected, size
        command = write_data.decode("utf-8").strip()

        if command == "IN_NAME":
            return f"IN_NAME {self.state.name}\r\n".encode("utf-8")
        if command == "IN_PV_3":
            return f"IN_PV_3 {self.state.temp}\r\n".encode("utf-8")
        if command == "IN_PV_66":
            return f"IN_PV_66 {self.state.pressure}\r\n".encode("utf-8")
        if command == "IN_SP_66":
            return f"IN_SP_66 {self.state.target_pressure}\r\n".encode("utf-8")
        if command == "IN_SP_70":
            return f"IN_SP_70 {self.state.hysteresis}\r\n".encode("utf-8")
        if command == "IN_MODE_66":
            return f"IN_MODE_66 {self.state.mode}\r\n".encode("utf-8")
        if command == "IN_ERROR":
            return f"IN_ERROR {self.state.error}\r\n".encode("utf-8")
        if command.startswith("OUT_SP_66 "):
            self.state.target_pressure = int(command.split()[1])
            self.state.pressure = self.state.target_pressure
            return f"{command}\r\n".encode("utf-8")
        if command.startswith("OUT_SP_70 "):
            self.state.hysteresis = int(command.split()[1])
            return f"{command}\r\n".encode("utf-8")
        if command.startswith("OUT_MODE_66 "):
            self.state.mode = int(command.split()[1])
            return f"{command}\r\n".encode("utf-8")
        if command == "START_66":
            self.state.vacuum_on = True
            self.state.pressure = self.state.target_pressure
            return b"START_66 OK\r\n"
        if command == "STOP_66":
            self.state.vacuum_on = False
            self.state.pressure = 1000
            return b"STOP_66 OK\r\n"
        if command == "RESET":
            self.state.vacuum_on = False
            self.state.pressure = 1000
            self.state.target_pressure = 1000
            self.state.error = "0"
            return b"RESET OK\r\n"
        return b"OK 1\r\n"


def create_ika_vc10_sim_transport_factory(
    *,
    name: str = "VC10",
    temp: float = 25.0,
    pressure: int = 1000,
    target_pressure: int = 1000,
    hysteresis: int = 10,
    mode: int = 1,
    error: str = "0",
):
    state = IKAVC10SimState(
        name=name,
        temp=temp,
        pressure=pressure,
        target_pressure=target_pressure,
        hysteresis=hysteresis,
        mode=mode,
        error=error,
    )
    protocol = IKAVC10SimProtocol(state)

    def _factory(config: SerialTransportConfig):
        return ScriptedSerialTransport(config, default_response=protocol)

    _factory.state = state
    return _factory
