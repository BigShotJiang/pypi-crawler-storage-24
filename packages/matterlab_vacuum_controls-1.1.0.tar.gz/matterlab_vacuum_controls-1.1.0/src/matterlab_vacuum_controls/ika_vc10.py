import time
from logging import Logger
from typing import Optional, Union
from enum import IntEnum

from matterlab_serial_device import SerialDevice, open_close
from matterlab_vacuum_controls.base_vacuum_control import VacuumControl

# from src.matterlab_vacuum_control.base_vacuum_control import VacuumControl

class Modes(IntEnum):
    MANUAL = 1
    PERCENT = 2

    @classmethod
    def from_any(cls, v):
        if isinstance(v, cls):
            return v
        if isinstance(v, int):
            return cls(v)
        if isinstance(v, str):
            key = v.strip().upper()
            key = key.replace(" ", "")
            return cls[key]
        raise TypeError(f"Unsupported mode: {type(v)}")
    
    def to_str(self) -> str:
        return self.name.lower()
    
class IKAVC10(VacuumControl, SerialDevice):
    """
    Controller for IKA VC10 vacuum controller (NAMUR command set).
    """
    category = "Vacuum"
    ui_fields = "com_port"

    _name_query: str = "IN_NAME"
    _pt1000_query: str = "IN_PV_3"

    _pressure_query: str = "IN_PV_66"
    _pressure_target_query: str = "IN_SP_66"
    _hysteresis_query: str = "IN_SP_70"
    _mode_query: str = "IN_MODE_66"
    _error_query: str = "IN_ERROR"

    _pressure_set: str = "OUT_SP_66"
    _hysteresis_set: str = "OUT_SP_70"
    _mode_set: str = "OUT_MODE_66"

    _vacuo_start: str = "START_66"
    _vacuo_stop: str = "STOP_66"
    _reset: str = "RESET"
    

    def __init__(
        self,
        com_port: str,
        min_pressure: int = 1,
        connect_hardware: bool = True,
        encoding: str = "utf-8",
        baudrate: int = 9600,
        timeout: float = 1.0,
        parity: str = "even",
        bytesize: int = 7,
        stopbits: int = 1,
        read_delay: float = 0.5,
        write_delay: float = 0.5,
        logger: Optional[Logger] = None,
        **kwargs,
    ) -> None:
        SerialDevice.__init__(
            self,
            com_port=com_port,
            encoding=encoding,
            baudrate=baudrate,
            timeout=timeout,
            parity=parity,
            bytesize=bytesize,
            stopbits=stopbits,
            connect_hardware=connect_hardware,
            **kwargs,
        )
        VacuumControl.__init__(self, min_pressure=float(min_pressure), logger=logger)
        self._read_delay = read_delay
        self._write_delay = write_delay
        self._target_pressure = 1000

        if connect_hardware:
            self.logger.info("Initializing IKA VC10 vacuum controller on %s", self.com_port)
            self.reset()
            self.stop()

    @open_close
    def _query_vacuum(self, command: str) -> str:
        response = self.query(write_command=f"{command}\r\n", read_delay=self._read_delay).split()[-1]
        self.logger.debug("Query to IKA VC10 on %s: %s -> %s", self.com_port, command, response)
        return response
    
    @property
    def name(self) -> str:
        name = self._query_vacuum(self._name_query)
        self.logger.info("IKA VC10 on %s reports name %s", self.com_port, name)
        return name
    
    @property
    def temp(self) -> float:
        if self.name == "VC10 lite":
            self.logger.warning("PT1000 external temperature is not available for VC10 Lite")
            return None
        temp = float(self._query_vacuum(self._pt1000_query))
        self.logger.info("External PT1000 temperature on %s is %s", self.com_port, temp)
        return temp     
        
    @property
    def pressure(self) -> int:
        pressure = int(self._query_vacuum(self._pressure_query))
        self.logger.info("Current pressure on %s is %s mbar", self.com_port, pressure)
        return pressure

    @pressure.setter
    def pressure(self, pressure: Union[float, int]) -> None:
        if not isinstance(pressure, (float, int)):
            raise TypeError("target_pressure must be float or int")
        if pressure < self._min_pressure:
            pressure = self._min_pressure
            
        self.logger.info("Setting target pressure on %s to %s mbar", self.com_port, int(pressure))
        self._query_vacuum(f"{self._pressure_set} {int(pressure)}")
        if self.target_pressure != pressure:
            self.logger.error("Set pressure failed on %s: expected %s, read back %s", self.com_port, pressure, self.target_pressure)
        
        if pressure == self._switch_pressure:
            self._vacuum_switch = False
        else:
            self._vacuum_switch = True

    @property
    def target_pressure(self) -> int:
        self._target_pressure = int(self._query_vacuum(self._pressure_target_query))
        self.logger.info("Target pressure on %s is %s mbar", self.com_port, self._target_pressure)
        return self._target_pressure

    @property
    def hysteresis(self) -> int:
        hysteresis = int(self._query_vacuum(self._hysteresis_query))
        self.logger.info("Pressure hysteresis on %s is %s mbar", self.com_port, hysteresis)
        return hysteresis

    @property
    def mode(self) -> str:
        raw = int(self._query_vacuum(self._mode_query))
        try:
            mode = Modes(raw).to_str()
        except ValueError:
            mode = f"Unknown ({raw})"
        self.logger.info("IKA VC10 on %s mode is %s", self.com_port, mode)
        return mode

    @property
    def error(self) -> str:
        error = str(self._query_vacuum(self._error_query))
        self.logger.info("IKA VC10 on %s error status is %s", self.com_port, error)
        return error

    @property
    def _vacuum_switch(self) -> bool:
        return self._vacuum_switch_status
    
    @_vacuum_switch.setter
    def _vacuum_switch(self, vacuum_switch_status: bool) ->None:
        self._vacuum_switch_status = vacuum_switch_status
        if self._vacuum_switch_status:
            self._query_vacuum(self._vacuo_start)
            self.logger.info("Started vacuum control on %s", self.com_port)
        else:
            self._query_vacuum(self._vacuo_stop)
            self.logger.info("Stopped vacuum control on %s", self.com_port)

    @hysteresis.setter
    def hysteresis(self, value: Union[float, int]) -> None:
        if not isinstance(value, (float, int)):
            raise TypeError("hysteresis must be float or int")
        if float(value) < 0:
            raise ValueError("hysteresis must be >= 0")
        self._query_vacuum(f"{self._hysteresis_set} {int(value)}")
        self.logger.info("Set pressure hysteresis on %s to %s mbar", self.com_port, int(value))

    @mode.setter
    def mode(self, mode: str) -> None:
        m = Modes.from_any(mode)
        self._query_vacuum(f"{self._mode_set} {m.value}")
        self.logger.info("Set IKA VC10 on %s mode to %s", self.com_port, m.to_str())
    

    def reset(self) -> None:
        """Switch to normal operating mode (RESET)."""
        self.logger.warning("Resetting IKA VC10 on %s", self.com_port)
        self._query_vacuum(self._reset)
       
    def start(self) -> None:
        self._vacuum_switch = True

    def stop(self) -> None:
        self._vacuum_switch = False

# v = IKAVC10("COM4")
# print(v.mode)
# print(v.pressure)
# v.pressure=900
# v.start()
# time.sleep(1)
# v.stop()
# print(v.pressure)
# print(v.target_pressure)
