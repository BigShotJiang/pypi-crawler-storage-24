# Matter Lab Vacuum Controls

`matterlab_vacuum_controls` provides Python drivers for vacuum controllers used in Matter Lab automation workflows.

The package currently includes:

- `VacuumControl`: abstract base class for vacuum controller interfaces
- `IKAVC10`: serial driver for the IKA VC10 vacuum controller

## Installation

Use the `matterlab` conda environment and install the package in editable mode during development:

```bash
pip install -e .[dev]
```

The package depends on `matterlab_serial_device` for serial communication.

## Quick Start

```python
from matterlab_vacuum_controls import IKAVC10

vacuum = IKAVC10(com_port="COM4", min_pressure=50)
print(vacuum.name)
print(vacuum.pressure)
vacuum.hysteresis = 25
vacuum.mode = "manual"
vacuum.pressure = 250
vacuum.standby()
vacuum.stop()
```

## Testing

Simulation tests are the default and are the only tests intended for CI enforcement.

One-click local sim run:

```bash
python examples/test_sim.py
```

Direct pytest run:

```bash
pytest
```

Real hardware tests are present for manual validation but are skipped unless explicitly enabled.

Run real tests with a COM port:

```bash
pytest tests/test_ika_vc10_real.py --run-real --com-port COM4
```

You can also provide the port through an environment variable:

```bash
set VACUUM_COM_PORT=COM4
pytest tests/test_ika_vc10_real.py --run-real
```

## Examples

Additional examples live in [examples/README.md](examples/README.md):

- `examples/test_sim.py` for the sim suite
- `examples/real_devices.py` for readable hardware usage examples

## Development Notes

- Source code lives under `src/`
- Pytest uses `src` as the import root
- Hardware-backed tests are marked with `@pytest.mark.real`
- The repository keeps generated coverage and build artifacts out of version control
