from matterlab_vacuum_controls import IKAVC10, create_ika_vc10_sim_transport_factory


def test_ika_vc10_transport_sim_uses_public_api():
    transport_factory = create_ika_vc10_sim_transport_factory(temp=28.0, pressure=950, target_pressure=900)
    vacuum = IKAVC10("SIM::vc10", min_pressure=25, transport_factory=transport_factory)

    assert vacuum.name == "VC10"
    assert vacuum.temp == 28.0
    assert vacuum.pressure == 1000
    vacuum.pressure = 850
    assert vacuum.target_pressure == 850
    assert vacuum.mode == "manual"
    vacuum.hysteresis = 15
    assert vacuum.hysteresis == 15


def test_ika_vc10_transport_sim_tracks_mode_changes():
    transport_factory = create_ika_vc10_sim_transport_factory(mode=2)
    vacuum = IKAVC10("SIM::vc10", min_pressure=25, transport_factory=transport_factory)

    assert vacuum.mode == "percent"
    vacuum.mode = "manual"
    assert vacuum.mode == "manual"
