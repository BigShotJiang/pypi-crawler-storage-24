from matterlab_vacuum_controls.base_vacuum_control import VacuumControl


class DummyVacuumControl(VacuumControl):
    def __init__(self, min_pressure: float = 25) -> None:
        super().__init__(min_pressure=min_pressure)
        self._pressure = 500
        self._target_pressure = 500
        self._vacuum_switch_status = False
        self.commands: list[str] = []

    def _query_vacuum(self, command: str) -> str:
        self.commands.append(command)
        return command

    @property
    def pressure(self) -> float:
        return self._pressure

    @pressure.setter
    def pressure(self, pressure: float) -> None:
        self._target_pressure = pressure
        self._pressure = pressure
        self._vacuum_switch = pressure != self._switch_pressure

    @property
    def target_pressure(self) -> float:
        return self._target_pressure

    @property
    def _vacuum_switch(self) -> bool:
        return self._vacuum_switch_status

    @_vacuum_switch.setter
    def _vacuum_switch(self, vacuum_switch_status: bool) -> None:
        self._vacuum_switch_status = vacuum_switch_status


def test_default_logger_name() -> None:
    vacuum = DummyVacuumControl()

    assert vacuum.logger.name.endswith("DummyVacuumControl")


def test_standby_sets_switch_pressure_and_turns_control_off() -> None:
    vacuum = DummyVacuumControl()

    vacuum.standby()

    assert vacuum.pressure == vacuum._switch_pressure
    assert vacuum.target_pressure == vacuum._switch_pressure
    assert vacuum._vacuum_switch is False
