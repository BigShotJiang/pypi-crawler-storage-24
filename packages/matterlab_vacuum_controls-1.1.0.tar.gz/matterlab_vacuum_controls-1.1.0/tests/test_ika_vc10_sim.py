from contextlib import nullcontext
from logging import getLogger
from types import SimpleNamespace

import pytest

from matterlab_serial_device import SerialDevice
from matterlab_vacuum_controls.ika_vc10 import IKAVC10, Modes


@pytest.fixture
def serial_device_mocks(mocker):
    def fake_serial_init(
        self,
        com_port,
        baudrate=9600,
        bytesize=8,
        parity="none",
        stopbits=1,
        timeout=None,
        encoding="utf-8",
        connect_hardware=True,
        share_port=False,
        logger=None,
        **kwargs,
    ):
        self.com_port = com_port
        self.baudrate = baudrate
        self.bytesize = bytesize
        self.parity = parity
        self.stopbits = stopbits
        self.timeout = timeout
        self.encoding = encoding
        self.connect_hardware = connect_hardware
        self.share_port = share_port
        self.logger = logger if logger is not None else getLogger("test.serial")
        self.device = SimpleNamespace(is_open=False)

    serial_init = mocker.patch.object(SerialDevice, "__init__", autospec=True, side_effect=fake_serial_init)
    ensure_device = mocker.patch.object(SerialDevice, "_ensure_device", autospec=True)
    lock = mocker.patch.object(SerialDevice, "_transport_lock", autospec=True, side_effect=lambda self: nullcontext())
    open_comm = mocker.patch.object(SerialDevice, "open_device_comm", autospec=True)
    close_comm = mocker.patch.object(SerialDevice, "close_device_comm", autospec=True)
    query = mocker.patch.object(SerialDevice, "query", autospec=True, return_value="VALUE 321")

    return {
        "serial_init": serial_init,
        "ensure_device": ensure_device,
        "lock": lock,
        "open_comm": open_comm,
        "close_comm": close_comm,
        "query": query,
    }


@pytest.fixture
def valve(serial_device_mocks):
    return IKAVC10("COM9", min_pressure=25, connect_hardware=False)


def test_modes_from_any_supports_enum_int_and_string() -> None:
    assert Modes.from_any(Modes.MANUAL) is Modes.MANUAL
    assert Modes.from_any(2) is Modes.PERCENT
    assert Modes.from_any("manual") is Modes.MANUAL
    assert Modes.from_any("percent") is Modes.PERCENT


def test_modes_from_any_rejects_unsupported_type() -> None:
    with pytest.raises(TypeError):
        Modes.from_any(1.5)


def test_init_resets_and_stops_when_connecting_hardware(serial_device_mocks, mocker) -> None:
    reset = mocker.patch.object(IKAVC10, "reset", autospec=True)
    stop = mocker.patch.object(IKAVC10, "stop", autospec=True)

    vacuum = IKAVC10("COM4", connect_hardware=True)

    assert vacuum.com_port == "COM4"
    reset.assert_called_once_with(vacuum)
    stop.assert_called_once_with(vacuum)
    assert vacuum.connect_hardware is True


def test_init_passes_connect_hardware_to_serial_base(serial_device_mocks) -> None:
    vacuum = IKAVC10("COM7", connect_hardware=False)

    assert vacuum.connect_hardware is False


def test_query_vacuum_writes_expected_command_and_reads_last_token(valve, serial_device_mocks) -> None:
    response = valve._query_vacuum("IN_PV_66")

    assert response == "321"
    serial_device_mocks["query"].assert_called_once_with(
        valve,
        write_command="IN_PV_66\r\n",
        read_delay=0.5,
    )
    serial_device_mocks["open_comm"].assert_called_once_with(valve)
    serial_device_mocks["close_comm"].assert_called_once_with(valve)


def test_name_property_queries_name(valve, mocker) -> None:
    query = mocker.patch.object(valve, "_query_vacuum", return_value="VC10")

    assert valve.name == "VC10"
    query.assert_called_once_with("IN_NAME")


def test_temp_returns_none_for_lite_model(valve, mocker) -> None:
    mocker.patch.object(type(valve), "name", new_callable=mocker.PropertyMock, return_value="VC10 lite")
    query = mocker.patch.object(valve, "_query_vacuum")

    assert valve.temp is None
    query.assert_not_called()


def test_temp_queries_pt1000_for_full_model(valve, mocker) -> None:
    mocker.patch.object(type(valve), "name", new_callable=mocker.PropertyMock, return_value="VC10")
    query = mocker.patch.object(valve, "_query_vacuum", return_value="42.5")

    assert valve.temp == 42.5
    query.assert_called_once_with("IN_PV_3")


def test_pressure_target_hysteresis_mode_and_error_queries(valve, mocker) -> None:
    responses = {
        "IN_PV_66": "850",
        "IN_SP_66": "700",
        "IN_SP_70": "25",
        "IN_MODE_66": "2",
        "IN_ERROR": "0",
    }
    query = mocker.patch.object(valve, "_query_vacuum", side_effect=lambda command: responses[command])

    assert valve.pressure == 850
    assert valve.target_pressure == 700
    assert valve.hysteresis == 25
    assert valve.mode == "percent"
    assert valve.error == "0"
    assert query.call_count == 5


def test_mode_property_handles_unknown_numeric_value(valve, mocker) -> None:
    mocker.patch.object(valve, "_query_vacuum", return_value="99")

    assert valve.mode == "Unknown (99)"


def test_pressure_setter_clamps_to_minimum_and_starts_vacuum(valve, mocker) -> None:
    query = mocker.patch.object(valve, "_query_vacuum", return_value="1")
    mocker.patch.object(type(valve), "target_pressure", new_callable=mocker.PropertyMock, return_value=25)

    valve.pressure = 5

    assert valve._vacuum_switch is True
    assert query.call_args_list == [
        mocker.call("OUT_SP_66 25"),
        mocker.call("START_66"),
    ]


def test_pressure_setter_stops_vacuum_at_switch_pressure(valve, mocker) -> None:
    query = mocker.patch.object(valve, "_query_vacuum", return_value="1")
    mocker.patch.object(type(valve), "target_pressure", new_callable=mocker.PropertyMock, return_value=1000)

    valve.pressure = 1000

    assert valve._vacuum_switch is False
    assert query.call_args_list == [
        mocker.call("OUT_SP_66 1000"),
        mocker.call("STOP_66"),
    ]


def test_pressure_setter_requires_numeric_value(valve) -> None:
    with pytest.raises(TypeError):
        valve.pressure = "100"


def test_hysteresis_setter_validates_value_and_sends_command(valve, mocker) -> None:
    query = mocker.patch.object(valve, "_query_vacuum", return_value="OK")

    valve.hysteresis = 15

    query.assert_called_once_with("OUT_SP_70 15")


def test_hysteresis_setter_rejects_invalid_values(valve) -> None:
    with pytest.raises(TypeError):
        valve.hysteresis = "15"
    with pytest.raises(ValueError):
        valve.hysteresis = -1


def test_mode_setter_accepts_multiple_inputs(valve, mocker) -> None:
    query = mocker.patch.object(valve, "_query_vacuum", return_value="OK")

    valve.mode = "manual"
    valve.mode = 2

    assert query.call_args_list == [
        mocker.call("OUT_MODE_66 1"),
        mocker.call("OUT_MODE_66 2"),
    ]


def test_reset_start_and_stop_delegate_to_switch_commands(valve, mocker) -> None:
    query = mocker.patch.object(valve, "_query_vacuum", return_value="OK")

    valve.reset()
    valve.start()
    valve.stop()

    assert query.call_args_list == [
        mocker.call("RESET"),
        mocker.call("START_66"),
        mocker.call("STOP_66"),
    ]
