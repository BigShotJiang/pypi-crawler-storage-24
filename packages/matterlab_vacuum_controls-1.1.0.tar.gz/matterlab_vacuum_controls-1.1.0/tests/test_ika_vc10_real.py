import pytest

from matterlab_vacuum_controls import IKAVC10


@pytest.mark.real
def test_ika_vc10_reports_name(com_port: str) -> None:
    vacuum = IKAVC10(com_port=com_port)
    try:
        assert isinstance(vacuum.name, str)
        assert vacuum.name
    finally:
        vacuum.stop()


@pytest.mark.real
def test_ika_vc10_pressure_roundtrip(com_port: str) -> None:
    vacuum = IKAVC10(com_port=com_port)
    try:
        original = vacuum.target_pressure
        trial = max(vacuum._min_pressure, min(original, vacuum._switch_pressure - 50))
        vacuum.pressure = trial
        assert vacuum.target_pressure == int(trial)
        vacuum.standby()
        assert vacuum.target_pressure == vacuum._switch_pressure
    finally:
        vacuum.stop()
