---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: feature request
assignees: discogestalt

---

**Is your feature request related to a problem? Please describe.**

A clear and concise description of what the problem is.
Ex. I'm always frustrated when [...]

**Describe the solution you'd like**

A clear and concise description of what you want to happen.
Provide a code snippet on how new APIs/changes would be used by others.

**Describe alternatives you've considered**

A clear and concise description of any alternative solutions or features you've considered.

**Environment**

 - Nautobot version: <!-- Example: 1.6.25 -->
 - Nautobot NV Data Models version: <!-- Example: 1.0.0 -->

**Additional context**

Add any other context or screenshots about the feature request here.
