# emit module

::: hypercoast.emit
