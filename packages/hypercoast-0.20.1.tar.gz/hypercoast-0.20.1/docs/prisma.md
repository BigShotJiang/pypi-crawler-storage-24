# prisma module

::: hypercoast.prisma
