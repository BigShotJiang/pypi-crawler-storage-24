"""
cache/
──────
Performance layer — speeds up repeated queries by remembering past results.

Language Server calls can be slow on large projects. This cache
saves the results of common lookups (definitions, references) so
the same question doesn't need to be asked twice.

Results are stored on disk (in ~/.cache/mcp-semantic/) so they survive
IDE restarts — this is the "Project Memory" feature.

- store.py : get_cached, set_cached, invalidate, clear_all
"""

from mcp_semantic.cache.store import get_cached, set_cached, invalidate, clear_all

__all__ = ["get_cached", "set_cached", "invalidate", "clear_all"]
