"""
Symbol and Reference Cache.

Language Server calls can be slow, especially on large projects.
This module caches the results of common queries (like "where is X defined?")
so we don't have to ask the Language Server the same question twice.

Think of it like a short-term memory for the server — fast lookups
for things we've already looked up before.
"""

import diskcache
from pathlib import Path

from mcp_semantic.utils.logger import log

# Store the cache on disk so it survives between sessions (our "Project Memory")
_CACHE_DIR = Path.home() / ".cache" / "mcp-semantic"
_cache = diskcache.Cache(str(_CACHE_DIR))


def get_cached(key: str):
    """
    Retrieve a previously saved result from the cache.
    Returns None if we haven't seen this query before.
    """
    value = _cache.get(key)
    if value is not None:
        log.debug("cache_hit", key=key)
    return value


def set_cached(key: str, value, expire_seconds: int = 300):
    """
    Save a result to the cache so we can reuse it later.
    By default, entries expire after 5 minutes to stay fresh.
    """
    log.debug("cache_set", key=key, ttl=expire_seconds)
    _cache.set(key, value, expire=expire_seconds)


def invalidate(key: str):
    """
    Remove a specific entry from the cache.
    We call this when a file has been edited, so we don't serve stale data.
    """
    log.debug("cache_invalidate", key=key)
    _cache.delete(key)


def clear_all():
    """Wipe the entire cache — useful for a fresh start."""
    log.info("cache_cleared")
    _cache.clear()
