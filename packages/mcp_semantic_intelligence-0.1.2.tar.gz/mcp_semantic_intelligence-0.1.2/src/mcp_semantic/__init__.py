"""
mcp_semantic/
─────────────
The root package for the MCP Semantic Intelligence Server.

This tool gives AI assistants (Antigravity, Cursor, Augment) deep,
compiler-level understanding of any codebase — and the ability to
safely apply large-scale changes.

Sub-packages:
  server/    — MCP protocol & tool registration (the front door)
  lsp/       — Language Server communication (the expert translator)
  discovery/ — Project root & language detection (the navigator)
  tools/     — Read-only AI tools (definition, references, symbols, hover)
  actions/   — Write operations (rename, edit, format)
  analysis/  — Deep reasoning (impact, flow, call hierarchy)
  graph/     — Architecture visualization (dependency maps)
  cache/     — Performance layer (symbol & definition caching)
  safety/    — Trust layer (dry-run, lint/compile validation)
  utils/     — Shared helpers (URIs, logging)
"""
