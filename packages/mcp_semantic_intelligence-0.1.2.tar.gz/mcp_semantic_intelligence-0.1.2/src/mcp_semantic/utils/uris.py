"""
Shared URI utilities.
Converts between local file paths (e.g. /home/user/project/Main.java)
and the URI format that Language Servers understand (file:///home/user/project/Main.java).
"""

from pathlib import Path


def path_to_uri(path: str | Path) -> str:
    """Turn a local file path into a URI the Language Server can use."""
    return Path(path).resolve().as_uri()


def uri_to_path(uri: str) -> Path:
    """Turn a Language Server URI back into a readable local file path."""
    # Strip the 'file://' prefix so we get a normal path string
    if uri.startswith("file://"):
        return Path(uri[7:])
    return Path(uri)
