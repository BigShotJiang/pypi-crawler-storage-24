"""
Structured logging for the entire server.

Uses structlog to produce clean, machine-readable log entries that are
easy to read in the terminal AND easy to parse in monitoring tools.
"""

import sys
import structlog

# MCP servers communicate over stdout, so ALL logs must go to stderr
# to avoid corrupting the JSON-RPC stream.
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer() if not sys.stderr.isatty() else structlog.dev.ConsoleRenderer()
    ],
    logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
)

log = structlog.get_logger()
