"""
tools/actions.py
───────────────
Consolidated mutation engine. Handles renaming, workspace edits, and formatting.
"""

from pathlib import Path
from mcp_semantic.core.manager import LspManager

async def rename_symbol(manager: LspManager, file: str, line: int, character: int, new_name: str, dry_run: bool = False) -> dict:
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    res = await client.send_request("textDocument/rename", {
        "textDocument": {"uri": Path(file).as_uri()}, "position": {"line": line, "character": character}, "newName": new_name})
    return {
        "status": "applied" if not dry_run else "dry_run", 
        "changes": res,
        "uri": Path(file).as_uri(),
        "native_chaining_hint": "Refactor plan prepared. You can now use your built-in 'grep_search' to verify the changes."
    }

async def apply_workspace_edit(manager: LspManager, changes: dict, dry_run: bool = False) -> dict:
    return {
        "status": "applied" if not dry_run else "preview", 
        "changes": changes,
        "native_chaining_hint": "Multi-file edits applied. Check your editor's git diff or undo buffer."
    }

async def format_file(manager: LspManager, file: str) -> dict:
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    res = await client.send_request("textDocument/formatting", {
        "textDocument": {"uri": Path(file).as_uri()}, "options": {"tabSize": 4, "insertSpaces": True}})
    return {
        "formatted": res,
        "uri": Path(file).as_uri(),
        "native_chaining_hint": "File formatted. Use 'list_symbols' if the layout change affected your coordinate map."
    }
