"""
tools/navigation.py
──────────────────
Consolidated navigation engine. Handles symbol lookup, reference finding,
symbol listing, and hover information.
"""

from typing import Any
from pathlib import Path
from mcp_semantic.core.manager import LspManager

async def get_definition(manager: LspManager, file: str, line: int, character: int) -> dict:
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    
    response = await client.send_request("textDocument/definition", {
        "textDocument": {"uri": Path(file).as_uri()}, "position": {"line": line, "character": character}})
    
    # --- AI Context Booster: Extract Snippet ---
    snippet = ""
    try:
        # If the LSP returned a list or single location
        loc = response[0] if isinstance(response, list) and response else response
        if loc and "range" in loc:
            start_line = loc["range"]["start"]["line"]
            path = Path(file)
            if path.exists():
                lines = path.read_text().splitlines()
                # Grab 10 lines from the definition point
                snippet = "\n".join(lines[start_line:start_line + 10])
    except Exception:
        pass

    return {
        "definition": response,
        "context_snippet": snippet,
        "advice": "Use the context_snippet to understand the parameters/docstring without opening the file."
    }

async def find_references(manager: LspManager, file: str, line: int, character: int) -> dict:
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    
    res = await client.send_request("textDocument/references", {
        "textDocument": {"uri": Path(file).as_uri()}, "position": {"line": line, "character": character},
        "context": {"includeDeclaration": True}})
    
    return {
        "references": res,
        "uri": Path(file).as_uri(),
        "native_chaining_hint": "Use your built-in search or view_file to explore these reference locations."
    }

async def list_symbols(manager: LspManager, file: str) -> dict:
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    res = await client.send_request("textDocument/documentSymbol", {
        "textDocument": {"uri": Path(file).as_uri()}})
    return {
        "symbols": res,
        "uri": Path(file).as_uri(),
        "native_chaining_hint": "Each symbol has a range. You can use 'get_definition' on any symbol to see its implementation."
    }

async def get_hover(manager: LspManager, file: str, line: int, character: int) -> dict:
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    res = await client.send_request("textDocument/hover", {
        "textDocument": {"uri": Path(file).as_uri()}, "position": {"line": line, "character": character}})
    return {
        "hover": res,
        "uri": Path(file).as_uri(),
        "native_chaining_hint": "The type info helps you understand the interface. If you need the logic, use 'get_definition'."
    }

async def bring_back_to_reality(manager: LspManager, file: str) -> dict:
    """
    The "Reality Anchor" - Resets the AI's internal model with fresh,
    high-fidelity data from the current file.
    """
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    
    symbols = await client.send_request("textDocument/documentSymbol", {
        "textDocument": {"uri": Path(file).as_uri()}})
    
    return {
        "reality_anchor": {
            "file": file,
            "uri": Path(file).as_uri(),
            "symbols": symbols,
        },
        "native_chaining_hint": "You have been brought back to reality. Your internal map is now synced with the LSP. Rethink your next step based on this fresh state."
    }
