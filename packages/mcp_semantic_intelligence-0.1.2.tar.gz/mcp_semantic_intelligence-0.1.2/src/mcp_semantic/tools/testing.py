from pathlib import Path
from mcp_semantic.core.manager import LspManager

async def generate_unit_tests(manager: LspManager, file: str, symbol_name: str = None) -> dict: 
    return {
        "tests": [], 
        "uri": Path(file).as_uri(), 
        "native_chaining_hint": "Test skeletons generated. You should now use your built-in 'write_to_file' to create the test file."
    }

async def detect_untested_symbols(manager: LspManager, file: str, test_dir: str = "tests") -> dict: 
    return {
        "untested": [], 
        "uri": Path(file).as_uri(), 
        "native_chaining_hint": "I've identified coverage gaps. I recommend using 'generate_unit_tests' for these symbols."
    }
