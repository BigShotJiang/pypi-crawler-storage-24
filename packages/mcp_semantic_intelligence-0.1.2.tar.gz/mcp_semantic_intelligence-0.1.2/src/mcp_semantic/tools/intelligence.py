from pathlib import Path
from mcp_semantic.core.manager import LspManager
from mcp_semantic.tools import navigation as nav

async def sequential_think(thought: str, hypothesis: str = None, next_thought_needed: bool = True) -> dict:
    """
    Native Reasoning Tool. 
    Allows an AI to persist and refine its multi-step logic.
    """
    return {
        "thought": thought,
        "hypothesis": hypothesis,
        "next_thought_needed": next_thought_needed,
        "native_chaining_hint": "Thought recorded. Proceed to 'verify_reality' or use a semantic tool to test your hypothesis."
    }

async def verify_reality(manager: LspManager, file: str, assumptions: list[str]) -> dict:
    """
    The Ultimate Anti-Hallucination Tool.
    Checks if symbols the AI thinks exist actually do exist in the current LSP state.
    """
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    
    # 1. Get all symbols in the file for reality check
    symbols_res = await client.send_request("textDocument/documentSymbol", {
        "textDocument": {"uri": Path(file).as_uri()}})
    
    # Simple check: extract names from symbols_res (assuming a flat or nested list)
    def extract_names(items):
        names = []
        for it in items:
            names.append(it.get("name"))
            if "children" in it: names.extend(extract_names(it["children"]))
        return names
    
    existing_symbols = extract_names(symbols_res) if isinstance(symbols_res, list) else []
    
    results = []
    for ass in assumptions:
        valid = ass in existing_symbols
        results.append({
            "assumption": ass,
            "is_valid": valid,
            "correction": None if valid else f"Symbol '{ass}' not found. Try 'list_symbols' to see the actual names."
        })

    return {
        "verification": results,
        "uri": Path(file).as_uri(),
        "doubt_flag": any(not r["is_valid"] for r in results),
        "native_chaining_hint": "If any assumptions were invalid, use 'refresh_context' to resync your internal model."
    }

async def get_semantic_context(manager: LspManager, file: str, line: int, character: int) -> dict:
    """
    High-Density Semantic Map.
    Chains Definition, References, and Impact into a single IDE-ready response.
    """
    # 1. Get Definition (with snippet)
    defn_res = await nav.get_definition(manager, file, line, character)
    
    # 2. Get References
    refs_res = await nav.find_references(manager, file, line, character)
    refs = refs_res.get("references", [])
    
    # 3. Analyze Impact (Real-World Depth)
    ref_count = len(refs)
    if ref_count > 10:
        impact = "high"
        reason = f"Symbol is a major public API with {ref_count} cross-file consumers."
        doubt = True
    elif ref_count > 2:
        impact = "medium"
        reason = f"Symbol has {ref_count} references. Multiple modules may be affected."
        doubt = False
    else:
        impact = "low"
        reason = "Symbol is likely private or has very few consumers."
        doubt = False
    
    # 4. Construct Clickable Map
    uris = [file]
    for ref in refs:
        uris.append(ref.get("uri", ""))

    return {
        "symbol_dna": defn_res.get("context_snippet", ""),
        "blast_radius": {
            "impact_level": impact,
            "affected_uris": list(set(filter(None, uris))),
            "reason": reason
        },
        "doubt_flag": doubt,
        "native_chaining_hint": (
            "I've mapped the symbol's DNA and its blast radius. "
            f"Impact is {impact.upper()}. "
            "You should now use your built-in 'view_file' on the 'affected_uris' to verify the logic."
        )
    }

async def get_call_hierarchy(manager: LspManager, file: str, line: int, character: int) -> dict:
    """
    Structural Call Graph.
    Traces function dependencies (incoming/outgoing) across the project.
    """
    client = await manager.get_client(file)
    if not client: return {"error": "LSP not available."}
    
    # 1. Prepare hierarchy (identify the node)
    prepare = await client.send_request("textDocument/prepareCallHierarchy", {
        "textDocument": {"uri": Path(file).as_uri()}, "position": {"line": line, "character": character}})
    
    if not prepare: return {"details": "No call hierarchy available for this symbol."}
    item = prepare[0]
    
    # 2. Get incoming calls (who calls this?)
    incoming = await client.send_request("callHierarchy/incomingCalls", {"item": item})
    
    # 3. Get outgoing calls (who does this call?)
    outgoing = await client.send_request("callHierarchy/outgoingCalls", {"item": item})
    
    return {
        "symbol": item.get("name"),
        "incoming": [call.get("from", {}).get("name") for call in incoming],
        "outgoing": [call.get("to", {}).get("name") for call in outgoing],
        "uri": Path(file).as_uri(),
        "native_chaining_hint": (
            "I've mapped the call-hierarchy graph. "
            "You can now see the 'incoming' consumers and 'outgoing' dependencies. "
            "Use 'get_definition' on any consumer to check the integration logic."
        )
    }

async def analyze_impact(manager: LspManager, file: str, line: int, character: int) -> dict: 
    res = await nav.find_references(manager, file, line, character)
    count = len(res.get("references", []))
    return {
        "impact": "high" if count > 5 else "low", 
        "reference_count": count,
        "uri": Path(file).as_uri()
    }

async def evaluate_change_risk(manager: LspManager, file: str, line: int, character: int) -> dict:
    """
    Semantic Risk Engine.
    Calculates a "Danger Score" for a proposed refactor.
    """
    # 1. Architectural Impact (References)
    refs = await nav.find_references(manager, file, line, character)
    ref_count = len(refs.get("references", []))
    
    # 2. Structural Complexity
    content = Path(file).read_text().splitlines()
    line_count = len(content)
    # Simple nesting heuristic
    target_line = content[line] if line < len(content) else ""
    nesting = (len(target_line) - len(target_line.lstrip())) // 4

    # 3. Calculate Score
    score = (ref_count * 10) + (nesting * 20) + (10 if line_count > 500 else 0)
    
    level = "LOW"
    if score > 100: level = "CRITICAL"
    elif score > 50: level = "HIGH"
    elif score > 20: level = "MEDIUM"
    
    return {
        "risk_score": score,
        "risk_level": level,
        "metrics": {
            "reference_density": ref_count,
            "nesting_depth": nesting,
            "file_size_warning": line_count > 500
        },
        "uri": Path(file).as_uri(),
        "native_chaining_hint": (
            f"Risk Level is {level}. "
            + ("STOP: This is a critical component. Run 'get_call_hierarchy' before making any changes." if level in ["HIGH", "CRITICAL"] else "Proceed with standard verification.")
        )
    }

async def explain_flow(manager: LspManager, file: str, line: int, character: int) -> dict: 
    return {"flow": [], "uri": Path(file).as_uri(), "note": "Flow analysis requires deep LSP call-hierarchy support (Planned for Pro)."}

async def get_dependency_graph(manager: LspManager, file: str) -> dict: 
    return {"mermaid": "graph LR\n  A --> B", "uri": Path(file).as_uri()}
