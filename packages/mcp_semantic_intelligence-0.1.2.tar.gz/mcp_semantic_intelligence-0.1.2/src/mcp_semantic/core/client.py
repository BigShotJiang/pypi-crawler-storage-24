"""
core/client.py
──────────────────
LSP Client — The Low-Level Messenger.
"""

import asyncio
import json
from typing import Any
from mcp_semantic.utils.logger import log

class LspClient:
    def __init__(self, process: asyncio.subprocess.Process):
        self._process = process
        self._request_id = 0
        self._pending: dict[int, asyncio.Future] = {}
        self._reader_task: asyncio.Task | None = None

    async def start(self):
        self._reader_task = asyncio.create_task(self._read_responses())

    async def stop(self):
        if self._reader_task:
            self._reader_task.cancel()
        if self._process.returncode is None:
            self._process.terminate()

    async def send_notification(self, method: str, params: dict):
        message = {"jsonrpc": "2.0", "method": method, "params": params}
        raw = json.dumps(message)
        header = f"Content-Length: {len(raw)}\r\n\r\n"
        self._process.stdin.write((header + raw).encode())
        await self._process.stdin.drain()
        log.debug("lsp_notification_sent", method=method)

    async def send_request(self, method: str, params: dict) -> Any:
        self._request_id += 1
        request_id = self._request_id
        message = {"jsonrpc": "2.0", "id": request_id, "method": method, "params": params}
        raw = json.dumps(message)
        header = f"Content-Length: {len(raw)}\r\n\r\n"
        self._process.stdin.write((header + raw).encode())
        await self._process.stdin.drain()
        
        self._pending[request_id] = asyncio.get_event_loop().create_future()
        log.debug("lsp_request_sent", method=method, id=request_id)
        return await asyncio.wait_for(self._pending[request_id], timeout=30)

    async def _read_responses(self):
        while True:
            try:
                line = await self._process.stdout.readline()
                if not line: break
                if not line.startswith(b"Content-Length:"): continue
                
                length = int(line.strip().split(b":")[1])
                # Skip any other headers until the blank line
                while True:
                    line = await self._process.stdout.readline()
                    if line in (b"\r\n", b"\n"): break
                
                body = await self._process.stdout.readexactly(length)
                
                resp = json.loads(body)
                rid = resp.get("id")
                if rid is not None and rid in self._pending:
                    fut = self._pending.pop(rid)
                    if "error" in resp: fut.set_exception(RuntimeError(str(resp["error"])))
                    else: fut.set_result(resp.get("result"))
                elif rid is None:
                    log.info("lsp_notification_received", method=resp.get("method"), params=resp.get("params"))
                else:
                    log.info("lsp_response_received", id=rid, result=resp.get("result"), error=resp.get("error"))
            except Exception as e:
                log.error("lsp_read_error", error=str(e))
                # Don't break, try to recover
                continue
