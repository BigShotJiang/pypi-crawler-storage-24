"""
core/manager.py
──────────────────
LSP Manager — Lifecycle Overseer.
"""

import asyncio
import shutil
from pathlib import Path
from mcp_semantic.core.client import LspClient
from mcp_semantic.core.downloader import ensure_server
from mcp_semantic.utils.logger import log
from mcp_semantic.utils.uris import path_to_uri

LANGUAGE_SERVERS = {
    ".py": {"name": "Python", "cmd": "pyright-langserver", "args": ["--stdio"]},
    ".java": {"name": "Java", "cmd": "jdtls", "args": []},
    ".ts": {"name": "TypeScript", "cmd": "typescript-language-server", "args": ["--stdio"]},
    ".js": {"name": "JavaScript", "cmd": "typescript-language-server", "args": ["--stdio"]},
    ".go": {"name": "Go", "cmd": "gopls", "args": []},
    ".rs": {"name": "Rust", "cmd": "rust-analyzer", "args": []},
}

class LspManager:
    def __init__(self):
        self._clients = {}
        self._workspace_root = None

    async def initialize(self, path=None):
        self._workspace_root = Path(path).resolve() if path else Path.cwd()

    async def get_client(self, file_path):
        ext = Path(file_path).suffix.lower()
        if ext in self._clients: return self._clients[ext]
        
        info = LANGUAGE_SERVERS.get(ext)
        if not info: return None
        
        path = await ensure_server(info["name"].lower())
        if not path: return None
        
        proc = await asyncio.create_subprocess_exec(path, *info["args"], 
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
        client = LspClient(proc)
        await client.start()
        
        await client.send_request("initialize", {
            "rootUri": path_to_uri(self._workspace_root),
            "capabilities": {"textDocument": {"definition": {}, "references": {}, "documentSymbol": {}, "hover": {}}}
        })
        await client.send_notification("initialized", {})
        self._clients[ext] = client
        return client

    async def shutdown(self):
        for c in self._clients.values(): await c.stop()
