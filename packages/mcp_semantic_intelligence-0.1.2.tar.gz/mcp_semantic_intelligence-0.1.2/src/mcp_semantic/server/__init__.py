"""
server/
───────
The MCP Protocol layer — the "front door" of the application.

This is where AI assistants connect to the server. It registers every
available tool with the MCP protocol and routes incoming requests to
the correct handler.

- main.py : Entry point. Registers all tools and starts the MCP server.
            Also handles `mcp-semantic --check` for health diagnostics.
"""

from mcp_semantic.server.main import run

__all__ = ["run"]
