"""
server/schema.py
────────────────
Consolidated JSON-RPC Schemas for all 26 MCP Semantic Intelligence tools.
"""

from mcp.types import Tool

TOOL_SCHEMAS = [
    # --- NAVIGATION (core/navigation.py) ---
    Tool(name="get_definition",
         description="[PRIORITY: HIGH] Find where a symbol is defined. Returns a 'context_snippet' so you can see the signature immediately. USE THIS BEFORE READING FILES.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string", "description": "Absolute path to the file."},
             "line": {"type": "integer", "description": "Line number (0-indexed)."},
             "character": {"type": "integer", "description": "Column number (0-indexed)."},
         }, "required": ["file", "line", "character"]}),

    Tool(name="find_references",
         description="Find every usage of a symbol. Essential for calculating the impact of a refactor.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
             "line": {"type": "integer"},
             "character": {"type": "integer"},
         }, "required": ["file", "line", "character"]}),

    Tool(name="list_symbols",
         description="List all classes, methods, and variables declared in a file.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
         }, "required": ["file"]}),

    Tool(name="get_hover",
         description="Get the type information and documentation for a symbol at a given position.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
             "line": {"type": "integer"},
             "character": {"type": "integer"},
         }, "required": ["file", "line", "character"]}),

    Tool(name="bring_back_to_reality",
         description="REALITY ANCHOR. Resync your internal model with a high-fidelity map of the current file's symbols and types. Use this whenever you feel lost or likely hallucinating.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
         }, "required": ["file"]}),

    # --- ACTIONS (core/actions.py) ---
    Tool(name="rename_symbol",
         description="Safely rename a symbol everywhere it is used in the project. Supports dry_run mode.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
             "line": {"type": "integer"},
             "character": {"type": "integer"},
             "new_name": {"type": "string", "description": "The new name for the symbol."},
             "dry_run": {"type": "boolean"},
         }, "required": ["file", "line", "character", "new_name"]}),

    Tool(name="apply_workspace_edit",
         description="Apply structured edits across multiple files atomically. Supports dry_run mode.",
         inputSchema={"type": "object", "properties": {
             "changes": {"type": "object", "description": "Map of {file_path: [{line, new_text}]} edits."},
             "dry_run": {"type": "boolean"},
         }, "required": ["changes"]}),

    Tool(name="format_file",
         description="Auto-format a file to match the project's coding style.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
         }, "required": ["file"]}),

    # --- INTELLIGENCE (tools/intelligence.py) ---
    Tool(name="get_semantic_context",
         description="[MANDATORY START] The absolute best starting point for every task. Returns DNA (snippet), all references, and blast radius. FASTER THAN VIEW_FILE.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string", "description": "Absolute path to the file."},
             "line": {"type": "integer"},
             "character": {"type": "integer"},
         }, "required": ["file", "line", "character"]}),

    Tool(name="sequential_think",
         description="Structure your reasoning. Record your thoughts, hypotheses, and verification steps. Essential for complex multi-file refactors.",
         inputSchema={"type": "object", "properties": {
             "thought": {"type": "string", "description": "Your current analytical step."},
             "hypothesis": {"type": "string", "description": "A theory to be tested."},
             "next_thought_needed": {"type": "boolean"},
         }, "required": ["thought"]}),

    Tool(name="verify_reality",
         description="ANTI-HALLUCINATION GUARD. Cross-reference your assumptions (symbols, classes) against the actual codebase state.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string", "description": "The file to check against."},
             "assumptions": {"type": "array", "items": {"type": "string"}, "description": "List of symbols you think exist."},
         }, "required": ["file", "assumptions"]}),

    Tool(name="analyze_impact",
         description="Calculate the Blast Radius of changing a symbol — how many files and references will be affected.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
             "line": {"type": "integer"},
             "character": {"type": "integer"},
         }, "required": ["file", "line", "character"]}),

    Tool(name="get_dependency_graph",
         description="Build a visual dependency graph for a file, showing which other modules depend on it. Returns a Mermaid diagram.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
         }, "required": ["file"]}),

    # --- QUALITY & SECURITY (features/security.py) ---
    Tool(name="scan_for_vulnerabilities",
         description="Scan a source file for common security issues: hardcoded secrets, SQL injection, unsafe eval, etc.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
         }, "required": ["file"]}),

    Tool(name="audit_dependencies",
         description="Check the project's dependency file for packages with known historical vulnerabilities.",
         inputSchema={"type": "object", "properties": {
             "project_root": {"type": "string"},
         }, "required": ["project_root"]}),

    Tool(name="review_diff",
         description="Semantically compare two versions of a file — detects public API changes and assigns a risk level.",
         inputSchema={"type": "object", "properties": {
             "original_file": {"type": "string"},
             "modified_file": {"type": "string"},
         }, "required": ["original_file", "modified_file"]}),

    # --- AUTOMATION (features/testing.py) ---
    Tool(name="generate_unit_tests",
         description="Generate type-accurate unit test skeletons for functions in a file using LSP type info.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
             "symbol_name": {"type": "string", "description": "Optional: generate tests for only this function."},
         }, "required": ["file"]}),

    Tool(name="detect_untested_symbols",
         description="Find functions in a file that have no corresponding unit tests.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
             "test_dir": {"type": "string"},
         }, "required": ["file"]}),

    # --- HISTORY (features/history.py) ---
    Tool(name="backup_before_edit",
         description="Take a snapshot of a file before modifying it, so it can be restored later.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
         }, "required": ["file"]}),

    Tool(name="revert_last_edit",
         description="Restore a file to its state before the last AI edit.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
         }, "required": ["file"]}),

    Tool(name="log_change",
         description="Record an AI action in the session audit log with a human-readable description.",
         inputSchema={"type": "object", "properties": {
             "file": {"type": "string"},
             "action": {"type": "string"},
             "description": {"type": "string"},
         }, "required": ["file", "action", "description"]}),

    Tool(name="get_session_report",
         description="Get a full audit trail of all AI changes this session, formatted as a PR description.",
         inputSchema={"type": "object", "properties": {}}),
    Tool(
        name="get_call_hierarchy",
        description="[ARCHITECTURAL AUDIT] Structural Call Graph. Trace dependencies (incoming/outgoing) across the project. Essential for understanding logic flow.",
        inputSchema={
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "Absolute path to code file"},
                "line": {"type": "integer", "description": "Line number (0-indexed)"},
                "character": {"type": "integer", "description": "Column number (0-indexed)"}
            },
            "required": ["file", "line", "character"]
        }
    ),
    Tool(
        name="get_ownership_context",
        description="Human-Context Awareness. Identifies primary authors and recent editors using git-blame and CODEOWNERS. Helps AI decide 'who to ask' for context.",
        inputSchema={
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "Absolute path to code file"}
            },
            "required": ["file"]
        }
    ),
    Tool(
        name="evaluate_change_risk",
        description="Semantic Risk Engine. Calculates a 'Danger Score' for a proposed refactor based on architectural impact and structural complexity.",
        inputSchema={
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "Absolute path to code file"},
                "line": {"type": "integer", "description": "Line number (0-indexed)"},
                "character": {"type": "integer", "description": "Column number (0-indexed)"}
            },
            "required": ["file", "line", "character"]
        }
    ),
]
