"""
server/main.py
──────────────
Stable MCP Semantic Intelligence Server.
Uses the base Server class for robust JSON-RPC dispatching.
"""

import json
import asyncio
import argparse
from pathlib import Path

from mcp.server import Server, NotificationOptions
from mcp.types import Tool, TextContent, EmptyResult, Prompt, PromptMessage, Resource, ResourceContents, ImageContent
from mcp.server.models import InitializationOptions
import mcp.server.stdio

from mcp_semantic.core.manager import LspManager
from mcp_semantic.core.downloader import install_all_servers
from mcp_semantic.utils.logger import log

from mcp_semantic.tools import navigation as nav, actions, intelligence as intel, testing, history
from mcp_semantic.security import scanner, audit
from mcp_semantic.server.schema import TOOL_SCHEMAS

# The heart of the server
_manager = LspManager()
server = Server("semantic-intel")

@server.list_tools()
async def list_tools() -> list[Tool]:
    """Return the full list of 29 semantic tools."""
    return TOOL_SCHEMAS

@server.list_resources()
async def list_resources() -> list[Resource]:
    """Expose the Senior Engineer Protocol (AGENTS.md) as a discoverable resource."""
    return [
        Resource(
            uri="mcp://semantic-intel/protocol/agents.md",
            name="Senior Engineer Manual",
            description="The definitive guide for AI agents on how to use this semantic intelligence suite.",
            mimeType="text/markdown"
        )
    ]

@server.read_resource()
async def read_resource(uri: str) -> list[ResourceContents]:
    """Read the content of the manual."""
    if uri == "mcp://semantic-intel/protocol/agents.md":
        path = Path(__file__).parent.parent.parent.parent / "AGENTS.md"
        if path.exists():
            return [ResourceContents(uri=uri, mimeType="text/markdown", text=path.read_text())]
    raise ValueError(f"Resource not found: {uri}")

@server.list_prompts()
async def list_prompts() -> list[Prompt]:
    """List instruction templates to 'Awaken' the AI agent."""
    return [
        Prompt(
            name="senior-engineer-init",
            description="Initializes the AI agent with the Senior Engineer semantic protocol.",
            arguments=[]
        )
    ]

@server.get_prompt()
async def get_prompt(name: str, arguments: dict | None) -> dict:
    """Get the 'The Awakening' instruction set."""
    if name == "senior-engineer-init":
        path = Path(__file__).parent.parent.parent.parent / "AGENTS.md"
        content = path.read_text() if path.exists() else "Use get_semantic_context for every task."
        return {
            "messages": [
                PromptMessage(
                    role="user",
                    content=TextContent(
                        type="text",
                        text=f"You are a Senior Software Architect. Follow this protocol for all tasks:\n\n{content}"
                    )
                )
            ]
        }
    raise ValueError(f"Prompt not found: {name}")

@server.call_tool()
async def call_tool(name: str, arguments: dict):
    """The central dispatcher — routes each AI request to the correct module."""
    log.info("tool_called", name=name)
    try:
        # Route based on tool name
        if name == "get_semantic_context":
            res = await intel.get_semantic_context(_manager, **arguments)
        elif name == "sequential_think":
            res = await intel.sequential_think(**arguments)
        elif name == "verify_reality":
            res = await intel.verify_reality(_manager, **arguments)
        elif name == "bring_back_to_reality":
            res = await nav.bring_back_to_reality(_manager, **arguments)
        elif name == "get_definition":
            res = await nav.get_definition(_manager, **arguments)
        elif name == "find_references":
            res = await nav.find_references(_manager, **arguments)
        elif name == "list_symbols":
            res = await nav.list_symbols(_manager, **arguments)
        elif name == "get_hover":
            res = await nav.get_hover(_manager, **arguments)
        elif name == "rename_symbol":
            res = await actions.rename_symbol(_manager, **arguments)
        elif name == "apply_workspace_edit":
            res = await actions.apply_workspace_edit(_manager, **arguments)
        elif name == "format_file":
            res = await actions.format_file(_manager, **arguments)
        elif name == "get_call_hierarchy":
            res = await intel.get_call_hierarchy(_manager, **arguments)
        elif name == "get_ownership_context":
            res = await audit.get_ownership_context(**arguments)
        elif name == "evaluate_change_risk":
            res = await intel.evaluate_change_risk(_manager, **arguments)
        elif name == "analyze_impact":
            res = await intel.analyze_impact(_manager, **arguments)
        elif name == "get_dependency_graph":
            res = await intel.get_dependency_graph(_manager, **arguments)
        elif name == "explain_flow":
            res = await intel.explain_flow(_manager, **arguments)
        elif name == "scan_for_vulnerabilities":
            res = await scanner.scan_for_vulnerabilities(_manager, **arguments)
        elif name == "audit_dependencies":
            res = await audit.audit_dependencies(**arguments)
        elif name == "review_diff":
            res = await audit.review_diff(**arguments)
        elif name == "generate_unit_tests":
            res = await testing.generate_unit_tests(_manager, **arguments)
        elif name == "detect_untested_symbols":
            res = await testing.detect_untested_symbols(_manager, **arguments)
        elif name == "backup_before_edit":
            res = history.backup_before_edit(**arguments)
        elif name == "revert_last_edit":
            res = history.revert_last_edit(**arguments)
        elif name == "log_change":
            res = history.log_change(**arguments)
        elif name == "get_session_report":
            res = history.get_session_report()
        else:
            return [TextContent(type="text", text=json.dumps({"error": f"Tool not found: {name}"}))]

        return [TextContent(type="text", text=json.dumps(res, indent=2))]
    except Exception as e:
        log.error("execution_failed", name=name, error=str(e))
        return [TextContent(type="text", text=json.dumps({"error": f"{type(e).__name__}: {str(e)}"}))]


async def _serve():
    """Boot up the server over stdio."""
    await _manager.initialize()
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(
                notification_options=NotificationOptions(resources_changed=True)
            )
        )
    await _manager.shutdown()


def run():
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="MCP Semantic Intelligence Server")
    parser.add_argument("--check", action="store_true", help="Run health check")
    parser.add_argument("install", nargs="?", help="Auto-install LSPs")
    args = parser.parse_args()

    if args.check:
        from mcp_semantic.core.downloader import LSP_CONFIGS
        print(f"\n🔍 MCP Semantic Intelligence — Health Check: OK ✅")
        print(f"🌍 Languages Supported: {len(LSP_CONFIGS)}")
        print(f"🛡️ Security Engine: Real-World (Async)\n")
    elif args.install == "install":
        print("🚀 Installing all 6 Language Servers...")
        asyncio.run(install_all_servers())
    else:
        asyncio.run(_serve())
