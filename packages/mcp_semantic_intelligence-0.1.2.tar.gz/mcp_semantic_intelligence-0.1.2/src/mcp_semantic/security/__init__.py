# security/__init__.py
from .scanner import scan_for_vulnerabilities
from .audit import audit_dependencies
