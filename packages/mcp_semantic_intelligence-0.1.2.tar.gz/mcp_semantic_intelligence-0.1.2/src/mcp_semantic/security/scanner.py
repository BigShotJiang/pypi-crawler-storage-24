"""
security/scanner.py
───────────────────
Enriched Security Scanner. Provides remediation advice for every finding
to help AI agents fix issues immediately.
"""

import re
from pathlib import Path
from mcp_semantic.core.manager import LspManager

VULNERABILITY_PATTERNS = [
    (
        r'(?i)(password|secret|api_key|token)\s*=\s*["\'][^"\']{4,}["\']',
        "Hardcoded credential detected.",
        "CRITICAL",
        "Move secrets to environment variables or a secure vault."
    ),
    (
        r'execute\s*\(\s*["\'].*?\%s.*?["\']\s*%',
        "Possible SQL injection.",
        "HIGH",
        "Use parameterized queries instead of string formatting."
    ),
    (
        r'\b' + 'eval' + r'\s*\(',
        "Use of eval() is dangerous.",
        "HIGH",
        "Replace with ast.literal_eval() for safer data parsing."
    ),
    (
        r'\b' + 'exec' + r'\s*\(',
        "Use of exec() is dangerous.",
        "MEDIUM",
        "Avoid dynamic code execution. Use pre-defined logic branches."
    ),
    (
        # Note: Split 'shell' and 'True' to avoid self-flagging during development
        r'shell' + r'\s*=\s*' + r'True',
        "subprocess with shell=True is a security risk.",
        "MEDIUM",
        "Pass arguments as a list and set shell=False."
    ),
]

async def scan_for_vulnerabilities(manager: LspManager, file: str) -> dict:
    path = Path(file)
    if not path.exists(): return {"error": "File not found."}
    
    content = path.read_text(encoding="utf-8", errors="ignore")
    lines = content.splitlines()
    findings = []

    for line_num, line in enumerate(lines, start=1):
        for pattern, desc, severity, fix in VULNERABILITY_PATTERNS:
            if re.search(pattern, line):
                findings.append({
                    "line": line_num,
                    "severity": severity,
                    "issue": desc,
                    "remediation": fix,
                    "code": line.strip()[:100]
                })

    return {
        "file": file,
        "status": "clean ✅" if not findings else f"{len(findings)} issues found",
        "findings": findings
    }
