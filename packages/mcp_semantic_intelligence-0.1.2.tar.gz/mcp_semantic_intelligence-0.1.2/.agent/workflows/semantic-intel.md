---
description: How to use Semantic Intelligence tools for codebase analysis
---

// turbo-all

This project is equipped with **Semantic Intelligence Tools**. All AI agents MUST follow this protocol to ensure deep correctness and safety:

1. **Analysis First**: Before using `grep_search` or `view_file`, you MUST call `get_semantic_context` on the target symbol.
2. **Architectural Audit**: Use `get_call_hierarchy` to trace logic flow across the project.
3. **Risk Assessment**: Call `evaluate_change_risk` before any modification with >5 references.
4. **Anti-Hallucination**: If you are unsure of a symbol's existence, use `verify_reality`.

These tools are faster and more accurate than native IDE search for complex logic flows.
