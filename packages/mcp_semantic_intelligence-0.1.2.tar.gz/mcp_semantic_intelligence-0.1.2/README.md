# 🧠 MCP Semantic Intelligence Server

> **AI agents typically guess. We verify.**

An AI-Native MCP server that gives AI assistants (Antigravity, Cursor, Augment Code) **deep, compiler-level understanding** of your codebase — plus the ability to safely apply large-scale changes.

## Why This Exists

Autocomplete tools are great for the next line. This tool is for the **next feature, refactor, or debugging session** in a 100k-line production codebase.

| Problem | Typical AI | With This Tool |
|---|---|---|
| Rename a core method | Misses some usages | Atomic, LSP-verified rename |
| Debug a cryptic error | Reads random files | Traces the exact call chain |
| "What will break?" | Guesses | Calculates the Blast Radius |

## Installation

### Option A: `uv` (Recommended — no virtualenv needed)
```bash
# Install uv if you don't have it
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install the tool globally
uv tool install /home/sayone-184/Documents/ai-intelligence/mcp-semantic-intelligence
```

### Option B: `pipx` (Alternative global install)
```bash
sudo apt install pipx
pipx install /home/sayone-184/Documents/ai-intelligence/mcp-semantic-intelligence
```

### Option C: Dev mode (local, no install needed)
```bash
uv run --project /path/to/mcp-semantic-intelligence mcp-semantic
```

## Setup (works globally — no project path needed)

Add to your AI tool's MCP config. **Pick one option:**

#### If installed via `uv tool` or `pipx`:
```json
{
  "mcpServers": {
    "semantic-intel": {
      "command": "mcp-semantic"
    }
  }
}
```

#### If running from source with `uv run` (zero install):
```json
{
  "mcpServers": {
    "semantic-intel": {
      "command": "uv",
      "args": [
        "--directory",
        "/home/sayone-184/Documents/ai-intelligence/mcp-semantic-intelligence",
        "run",
        "mcp-semantic"
      ]
    }
  }
}
```
> This second option works like `npx` for Node — uv handles the virtualenv automatically every time.

The server auto-discovers your project root from `.git`, `pom.xml`, `package.json`, `pyproject.toml` etc.

## Health Check

```bash
mcp-semantic --check
```

Reports which languages are AI-Ready on your system.

## Language Support

| Language | LSP Backend |
|---|---|
| Java | Eclipse JDT.LS |
| Python | pyright |
| TypeScript/JS | typescript-language-server |
| Go | gopls |
| Rust | rust-analyzer |

## Available Tools

### Read
- `get_definition` — Jump to where a symbol is defined
- `find_references` — Find all usages across the workspace
- `list_symbols` — List all symbols in a file
- `search_symbols` — Search for a symbol by name
- `get_hover` — Get type info & docs for a symbol
- `build_semantic_context` — Get definition + references + docs in one call

### Action (Write)
- `rename_symbol` — Safely rename across the entire workspace
- `apply_workspace_edit` — Apply multi-file changes atomically
- `format_file` — Auto-format a file after edits

### Analysis
- `get_call_hierarchy` — Who calls this? What does it call?
- `analyze_impact` — Calculate the Blast Radius of a change
- `explain_flow` — Trace a path (API → Service → Repo → DB)
- `get_dependency_graph` — Visualize module dependencies

## Coding Standards

- Narrative inline comments (readable by non-technical people)
- Python PEP 8 + type hints throughout
- Each module has one clear responsibility
