"""
Tests for the ImpactCalculator engine.

Covers:
  - CardinalityArchetype.classify() for each tier
  - Platform cost detection from rule_id prefix
  - Severity multiplier effect on estimated series
  - Full enrich() pipeline with EconomicImpact fields
  - Existing scanner estimate respected (max logic)
"""
from __future__ import annotations

import pytest

from metricguard.engines.impact_calculator import (
    CardinalityArchetype,
    ImpactCalculator,
)
from metricguard.models.finding import (
    EconomicImpact,
    FindingCategory,
    Finding,
    Severity,
)


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def _make_finding(
    rule_id: str = "MG-PY-001",
    label: str | None = None,
    snippet: str | None = None,
    severity: Severity = Severity.HIGH,
    existing_impact: EconomicImpact | None = None,
    taint_source: str | None = None,
) -> Finding:
    return Finding(
        file_path="/repo/app.py",
        line_number=10,
        severity=severity,
        category=FindingCategory.DYNAMIC_LABEL_VALUE,
        rule_id=rule_id,
        message="Test finding",
        label_or_tag_name=label,
        offending_code_snippet=snippet,
        taint_source=taint_source,
        economic_impact=existing_impact,
    )


# ─────────────────────────────────────────────────────────────────────
# CardinalityArchetype.classify()
# ─────────────────────────────────────────────────────────────────────

class TestCardinalityArchetypeClassify:
    def test_uuid_label_key(self) -> None:
        series, name = CardinalityArchetype.classify("request_id", None)
        assert name == "uuid_request_id"
        assert series == 10_000_000

    def test_user_id_label_key(self) -> None:
        series, name = CardinalityArchetype.classify("user_id", None)
        assert name == "user_id"
        assert series == 1_000_000

    def test_email_label_key(self) -> None:
        series, name = CardinalityArchetype.classify("email", None)
        assert name == "email"
        assert series == 5_000_000

    def test_url_path_label_key(self) -> None:
        series, name = CardinalityArchetype.classify("url_path", None)
        assert name == "url_path"
        assert series == 100_000

    def test_hostname_label_key(self) -> None:
        series, name = CardinalityArchetype.classify("hostname", None)
        assert name == "hostname"
        assert series == 50_000

    def test_http_status_key(self) -> None:
        series, name = CardinalityArchetype.classify("http_status", None)
        assert name == "http_status"
        assert series == 50

    def test_http_method_key(self) -> None:
        series, name = CardinalityArchetype.classify("method", None)
        assert name == "http_method"
        assert series == 10

    def test_environment_key(self) -> None:
        series, name = CardinalityArchetype.classify("environment", None)
        assert name == "environment"
        assert series == 20

    def test_unknown_returns_default(self) -> None:
        series, name = CardinalityArchetype.classify("completely_unknown_key", None)
        assert name == "unknown_dynamic"
        assert series == 10_000

    def test_fstring_in_value_expr_detected(self) -> None:
        """F-string pattern in value expression is classified as dynamic_template."""
        series, name = CardinalityArchetype.classify(None, "f'tag:{value}'")
        assert name == "dynamic_template"

    def test_label_key_takes_precedence_over_value_expr(self) -> None:
        """Label key classification wins over value expression."""
        series, name = CardinalityArchetype.classify("user_id", "f'some_template'")
        # user_id wins over dynamic_template because label_key is searched first
        assert name == "user_id"

    def test_none_inputs_return_default(self) -> None:
        series, name = CardinalityArchetype.classify(None, None)
        assert name == "unknown_dynamic"

    def test_case_insensitive(self) -> None:
        series, name = CardinalityArchetype.classify("USER_ID", None)
        assert name == "user_id"

    def test_session_id_variant(self) -> None:
        series, name = CardinalityArchetype.classify("session_id", None)
        assert name == "session_id"
        assert series == 500_000


# ─────────────────────────────────────────────────────────────────────
# Platform pricing detection
# ─────────────────────────────────────────────────────────────────────

class TestPlatformPricing:
    @pytest.mark.parametrize("rule_id, expected_platform, max_cost_factor", [
        ("MG-AWS-INF-001", "aws_cloudwatch", 0.50),    # $0.30/series — very expensive
        ("MG-STAT-PY-001", "datadog_statsd", 0.10),   # $0.05/series
        ("MG-GCP-PY-001",  "gcp_monitoring", 0.02),   # $0.01/series
        ("MG-AZR-PY-001",  "azure_monitor",  0.15),   # $0.10/series (GA, 2025)
        ("MG-YAML-001",    "prometheus",     0.02),   # $0.0065/series
        ("MG-PY-001",      "prometheus",     0.02),   # $0.0065/series
        ("MG-TEL-INF-001", "telegraf_influx", 0.01),  # $0.005/series
    ])
    def test_platform_detected_from_rule_id(
        self, rule_id: str, expected_platform: str, max_cost_factor: float
    ) -> None:
        calc = ImpactCalculator()
        finding = _make_finding(rule_id=rule_id, label="user_id", severity=Severity.CRITICAL)
        enriched = calc.enrich(finding)
        assert enriched.economic_impact is not None
        assert enriched.economic_impact.platform == expected_platform

    def test_aws_has_highest_cost_per_series(self) -> None:
        """AWS CloudWatch should produce the highest dollar estimate for same label."""
        calc = ImpactCalculator()
        aws_finding = _make_finding("MG-AWS-PY-001", label="user_id", severity=Severity.CRITICAL)
        prom_finding = _make_finding("MG-PY-001", label="user_id", severity=Severity.CRITICAL)
        aws_enriched = calc.enrich(aws_finding)
        prom_enriched = calc.enrich(prom_finding)
        assert (
            aws_enriched.economic_impact.estimated_monthly_cost_usd
            > prom_enriched.economic_impact.estimated_monthly_cost_usd
        )


# ─────────────────────────────────────────────────────────────────────
# Severity multiplier
# ─────────────────────────────────────────────────────────────────────

class TestSeverityMultiplier:
    def test_critical_higher_than_medium(self) -> None:
        calc = ImpactCalculator()
        critical = calc.enrich(_make_finding(label="user_id", severity=Severity.CRITICAL))
        medium = calc.enrich(_make_finding(label="user_id", severity=Severity.MEDIUM))
        assert (
            critical.economic_impact.estimated_series_increase
            > medium.economic_impact.estimated_series_increase
        )

    def test_info_produces_minimal_estimate(self) -> None:
        calc = ImpactCalculator()
        info_finding = calc.enrich(_make_finding(label="user_id", severity=Severity.INFO))
        # INFO * 0.01 * 1,000,000 = 10,000 series
        assert info_finding.economic_impact.estimated_series_increase == 10_000

    def test_critical_produces_full_estimate(self) -> None:
        calc = ImpactCalculator()
        critical_finding = calc.enrich(_make_finding(label="user_id", severity=Severity.CRITICAL))
        # CRITICAL * 1.0 * 1,000,000 = 1,000,000 series
        assert critical_finding.economic_impact.estimated_series_increase == 1_000_000


# ─────────────────────────────────────────────────────────────────────
# Full enrich() pipeline
# ─────────────────────────────────────────────────────────────────────

class TestEnrichPipeline:
    def test_enrich_populates_all_fields(self) -> None:
        calc = ImpactCalculator()
        enriched = calc.enrich(_make_finding(label="user_id"))
        ei = enriched.economic_impact
        assert ei is not None
        assert ei.estimated_series_increase > 0
        assert ei.estimated_monthly_cost_usd is not None
        assert ei.estimated_monthly_cost_usd > 0
        assert ei.cardinality_archetype is not None
        assert ei.platform is not None
        assert ei.risk_description

    def test_finding_is_not_mutated(self) -> None:
        calc = ImpactCalculator()
        original = _make_finding(label="user_id")
        enriched = calc.enrich(original)
        # Original is unchanged
        assert original.economic_impact is None
        # Enriched is a new object
        assert enriched is not original
        assert enriched.economic_impact is not None

    def test_existing_larger_series_estimate_preserved(self) -> None:
        """Scanner-provided estimate is respected when larger than our heuristic."""
        # Scanner says 5,000,000 series — more than our HIGH * user_id estimate
        big_impact = EconomicImpact(
            estimated_series_increase=5_000_000,
            risk_description="Scanner found big issue",
        )
        calc = ImpactCalculator()
        enriched = calc.enrich(_make_finding(label="user_id", severity=Severity.HIGH, existing_impact=big_impact))
        # max(500_000, 5_000_000) = 5_000_000
        assert enriched.economic_impact.estimated_series_increase == 5_000_000

    def test_existing_smaller_series_estimate_replaced(self) -> None:
        """Our heuristic takes over when scanner's estimate is lower."""
        tiny_impact = EconomicImpact(
            estimated_series_increase=1,
            risk_description="Scanner gave minimal estimate",
        )
        calc = ImpactCalculator()
        enriched = calc.enrich(_make_finding(label="user_id", severity=Severity.CRITICAL, existing_impact=tiny_impact))
        # max(1, 1_000_000) = 1_000_000
        assert enriched.economic_impact.estimated_series_increase == 1_000_000

    def test_cost_is_series_times_platform_rate(self) -> None:
        """Monthly cost = estimated_series * $0.0065 for Prometheus rules (Grafana Cloud Pro, 2026)."""
        calc = ImpactCalculator()
        enriched = calc.enrich(_make_finding(rule_id="MG-PY-001", label="user_id", severity=Severity.CRITICAL))
        ei = enriched.economic_impact
        expected_cost = round(ei.estimated_series_increase * 0.0065, 2)
        assert ei.estimated_monthly_cost_usd == expected_cost

    def test_risk_description_includes_label_and_cost(self) -> None:
        calc = ImpactCalculator()
        enriched = calc.enrich(_make_finding(label="user_id"))
        desc = enriched.economic_impact.risk_description
        assert "user_id" in desc
        assert "$" in desc
