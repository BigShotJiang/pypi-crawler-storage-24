"""
MetricGuard v1.0.0 — SemgrepScanner Test Suite.

Tests the multi-language Semgrep engine using mocked subprocess invocations,
so no real semgrep binary is required in CI.

Coverage:
  - JSON output parsing: Go, TypeScript, Java findings
  - Graceful handling when semgrep is not installed
  - Severity mapping (ERROR → CRITICAL, WARNING → HIGH, INFO → MEDIUM)
  - Label/tag name extraction from metavariable bindings
  - Code snippet population from Semgrep 'lines' field
  - Inline suppression passthrough (via BaseScanner)
  - Empty/error results
  - Fingerprint stability
"""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from metricguard.core.config import MetricGuardConfig
from metricguard.models.finding import Finding, FindingCategory, Severity
from metricguard.scanners.semgrep_scanner import SemgrepScanner, _parse_semgrep_output


# ─────────────────────────────────────────────────────────────────────
# Fixtures & helpers
# ─────────────────────────────────────────────────────────────────────


@pytest.fixture()
def config() -> MetricGuardConfig:
    return MetricGuardConfig.default()


@pytest.fixture()
def scanner(config: MetricGuardConfig) -> SemgrepScanner:
    return SemgrepScanner(config)


def _make_semgrep_result(
    check_id: str = "MG-GO-001",
    path: str = "/tmp/test.go",
    line: int = 10,
    col: int = 5,
    severity: str = "WARNING",
    message: str = "High-cardinality label",
    lines: str = 'counter.With(prometheus.Labels{"user_id": userId}).Inc()',
    metavars: dict | None = None,
) -> dict:
    """Build a single Semgrep JSON result dict."""
    return {
        "check_id": check_id,
        "path": path,
        "start": {"line": line, "col": col},
        "end": {"line": line, "col": col + 20},
        "extra": {
            "message": message,
            "severity": severity,
            "lines": lines,
            "metavars": metavars or {},
        },
    }


def _semgrep_json(results: list[dict], errors: list | None = None) -> str:
    """Wrap results in the top-level Semgrep JSON envelope."""
    return json.dumps({"results": results, "errors": errors or []})


# ─────────────────────────────────────────────────────────────────────
# Supported extensions
# ─────────────────────────────────────────────────────────────────────


class TestSupportedExtensions:
    def test_includes_go(self, scanner: SemgrepScanner) -> None:
        assert ".go" in scanner.supported_extensions

    def test_includes_typescript(self, scanner: SemgrepScanner) -> None:
        assert ".ts" in scanner.supported_extensions
        assert ".tsx" in scanner.supported_extensions

    def test_includes_javascript(self, scanner: SemgrepScanner) -> None:
        assert ".js" in scanner.supported_extensions
        assert ".jsx" in scanner.supported_extensions

    def test_includes_java(self, scanner: SemgrepScanner) -> None:
        assert ".java" in scanner.supported_extensions

    def test_does_not_include_python(self, scanner: SemgrepScanner) -> None:
        assert ".py" not in scanner.supported_extensions

    def test_scanner_name(self, scanner: SemgrepScanner) -> None:
        assert scanner.scanner_name == "Semgrep"


# ─────────────────────────────────────────────────────────────────────
# Graceful degradation when semgrep is not installed
# ─────────────────────────────────────────────────────────────────────


class TestGracefulDegradation:
    def test_returns_empty_when_semgrep_missing(
        self, scanner: SemgrepScanner, tmp_path: Path
    ) -> None:
        """If semgrep binary is absent, scan_file() returns [] without raising."""
        go_file = tmp_path / "main.go"
        go_file.write_text('counter.With(prometheus.Labels{"user_id": userId}).Inc()')

        with patch("metricguard.scanners.semgrep_scanner._semgrep_available", return_value=False):
            findings = scanner.scan_file(go_file, go_file.read_text())

        assert findings == []

    def test_logs_warning_when_semgrep_missing(
        self, scanner: SemgrepScanner, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        go_file = tmp_path / "app.go"
        go_file.write_text("package main")

        import logging
        with caplog.at_level(logging.WARNING, logger="metricguard.scanners.semgrep_scanner"):
            with patch(
                "metricguard.scanners.semgrep_scanner._semgrep_available", return_value=False
            ):
                scanner.scan_file(go_file, go_file.read_text())

        assert any("semgrep" in msg.lower() for msg in caplog.messages)

    def test_returns_empty_for_unknown_extension(
        self, scanner: SemgrepScanner, tmp_path: Path
    ) -> None:
        """Files with no matching rule file return [] cleanly."""
        unknown = tmp_path / "data.csv"
        unknown.write_text("a,b,c")

        with patch("metricguard.scanners.semgrep_scanner._semgrep_available", return_value=True):
            findings = scanner.scan_file(unknown, unknown.read_text())

        assert findings == []


# ─────────────────────────────────────────────────────────────────────
# Output parsing: severity mapping
# ─────────────────────────────────────────────────────────────────────


class TestSeverityMapping:
    def _parse(
        self,
        config: MetricGuardConfig,
        severity_str: str,
        file_path: Path,
    ) -> list[Finding]:
        raw = {"results": [_make_semgrep_result(severity=severity_str, path=str(file_path))], "errors": []}
        return _parse_semgrep_output(raw, file_path, config)

    def test_error_maps_to_critical(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "f.go"
        findings = self._parse(config, "ERROR", fp)
        assert len(findings) == 1
        assert findings[0].severity == Severity.CRITICAL

    def test_warning_maps_to_high(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "f.go"
        findings = self._parse(config, "WARNING", fp)
        assert findings[0].severity == Severity.HIGH

    def test_info_maps_to_medium(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "f.go"
        findings = self._parse(config, "INFO", fp)
        assert findings[0].severity == Severity.MEDIUM


# ─────────────────────────────────────────────────────────────────────
# Output parsing: Go findings
# ─────────────────────────────────────────────────────────────────────


class TestGoFindingParsing:
    def test_go_finding_parsed_correctly(
        self, config: MetricGuardConfig, tmp_path: Path
    ) -> None:
        fp = tmp_path / "handler.go"
        fp.write_text("package main")

        raw = {
            "results": [
                _make_semgrep_result(
                    check_id="MG-GO-001",
                    path=str(fp),
                    line=12,
                    col=3,
                    severity="WARNING",
                    message='[MetricGuard MG-GO-001] High-cardinality label value detected.',
                    lines='counter.With(prometheus.Labels{"user_id": userId}).Inc()',
                    metavars={"$KEY": {"abstract_content": '"user_id"'}},
                )
            ],
            "errors": [],
        }

        findings = _parse_semgrep_output(raw, fp, config)

        assert len(findings) == 1
        f = findings[0]
        assert f.rule_id == "MG-GO-001"
        assert f.severity == Severity.HIGH
        assert f.line_number == 12
        assert f.column_number == 3
        assert f.language == "go"
        assert "user_id" in (f.label_or_tag_name or "")
        assert "user_id" in (f.offending_code_snippet or "")

    def test_semgrep_prefixed_rule_id_stripped(
        self, config: MetricGuardConfig, tmp_path: Path
    ) -> None:
        """go_metrics.MG-GO-001 → rule_id == MG-GO-001."""
        fp = tmp_path / "main.go"
        raw = {
            "results": [
                _make_semgrep_result(
                    check_id="go_metrics.MG-GO-001",
                    path=str(fp),
                )
            ],
            "errors": [],
        }
        findings = _parse_semgrep_output(raw, fp, config)
        assert findings[0].rule_id == "MG-GO-001"

    def test_go_critical_rule(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "service.go"
        raw = {
            "results": [
                _make_semgrep_result(
                    check_id="MG-GO-002",
                    path=str(fp),
                    severity="ERROR",
                )
            ],
            "errors": [],
        }
        findings = _parse_semgrep_output(raw, fp, config)
        assert findings[0].severity == Severity.CRITICAL
        assert findings[0].rule_id == "MG-GO-002"


# ─────────────────────────────────────────────────────────────────────
# Output parsing: TypeScript findings
# ─────────────────────────────────────────────────────────────────────


class TestTypeScriptFindingParsing:
    def test_ts_finding_language_set(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "metrics.ts"
        raw = {
            "results": [
                _make_semgrep_result(
                    check_id="MG-TS-001",
                    path=str(fp),
                    lines="counter.labels({ userId: req.userId }).inc();",
                )
            ],
            "errors": [],
        }
        findings = _parse_semgrep_output(raw, fp, config)
        assert len(findings) == 1
        assert findings[0].language == "typescript"
        assert findings[0].rule_id == "MG-TS-001"

    def test_js_finding_language_set(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "tracker.js"
        raw = {
            "results": [_make_semgrep_result(check_id="MG-TS-002", path=str(fp))],
            "errors": [],
        }
        findings = _parse_semgrep_output(raw, fp, config)
        assert findings[0].language == "javascript"


# ─────────────────────────────────────────────────────────────────────
# Output parsing: Java findings
# ─────────────────────────────────────────────────────────────────────


class TestJavaFindingParsing:
    def test_java_finding_parsed(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "MetricsService.java"
        raw = {
            "results": [
                _make_semgrep_result(
                    check_id="MG-JAVA-001",
                    path=str(fp),
                    lines='Counter.builder("http.requests").tag("userId", userId).register(reg).increment();',
                    metavars={"$KEY": {"abstract_content": '"userId"'}},
                )
            ],
            "errors": [],
        }
        findings = _parse_semgrep_output(raw, fp, config)
        assert len(findings) == 1
        assert findings[0].rule_id == "MG-JAVA-001"
        assert findings[0].language == "java"

    def test_java_critical_rule(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "Main.java"
        raw = {
            "results": [
                _make_semgrep_result(
                    check_id="MG-JAVA-002",
                    path=str(fp),
                    severity="ERROR",
                )
            ],
            "errors": [],
        }
        findings = _parse_semgrep_output(raw, fp, config)
        assert findings[0].severity == Severity.CRITICAL


# ─────────────────────────────────────────────────────────────────────
# Fingerprint stability
# ─────────────────────────────────────────────────────────────────────


class TestFingerprintStability:
    def test_fingerprint_populated(self, config: MetricGuardConfig, tmp_path: Path) -> None:
        fp = tmp_path / "app.go"
        raw = {
            "results": [_make_semgrep_result(path=str(fp), line=5)],
            "errors": [],
        }
        findings = _parse_semgrep_output(raw, fp, config)
        assert len(findings[0].fingerprint) == 16
        assert findings[0].fingerprint.isalnum()

    def test_same_location_same_fingerprint(
        self, config: MetricGuardConfig, tmp_path: Path
    ) -> None:
        fp = tmp_path / "app.go"
        result = _make_semgrep_result(path=str(fp), line=5)
        raw = {"results": [result], "errors": []}
        f1 = _parse_semgrep_output(raw, fp, config)[0]
        f2 = _parse_semgrep_output(raw, fp, config)[0]
        assert f1.fingerprint == f2.fingerprint

    def test_different_location_different_fingerprint(
        self, config: MetricGuardConfig, tmp_path: Path
    ) -> None:
        fp = tmp_path / "app.go"
        r1 = _make_semgrep_result(path=str(fp), line=5)
        r2 = _make_semgrep_result(path=str(fp), line=99)
        raw1 = {"results": [r1], "errors": []}
        raw2 = {"results": [r2], "errors": []}
        f1 = _parse_semgrep_output(raw1, fp, config)[0]
        f2 = _parse_semgrep_output(raw2, fp, config)[0]
        assert f1.fingerprint != f2.fingerprint


# ─────────────────────────────────────────────────────────────────────
# Edge cases
# ─────────────────────────────────────────────────────────────────────


class TestEdgeCases:
    def test_empty_results_returns_empty(
        self, config: MetricGuardConfig, tmp_path: Path
    ) -> None:
        fp = tmp_path / "clean.go"
        raw = {"results": [], "errors": []}
        findings = _parse_semgrep_output(raw, fp, config)
        assert findings == []

    def test_multiple_findings_returned(
        self, config: MetricGuardConfig, tmp_path: Path
    ) -> None:
        fp = tmp_path / "multi.go"
        raw = {
            "results": [
                _make_semgrep_result(check_id="MG-GO-001", path=str(fp), line=10),
                _make_semgrep_result(check_id="MG-GO-002", path=str(fp), line=20),
            ],
            "errors": [],
        }
        findings = _parse_semgrep_output(raw, fp, config)
        assert len(findings) == 2
        rule_ids = {f.rule_id for f in findings}
        assert rule_ids == {"MG-GO-001", "MG-GO-002"}

    def test_finding_category_is_dynamic_label_value(
        self, config: MetricGuardConfig, tmp_path: Path
    ) -> None:
        fp = tmp_path / "app.go"
        raw = {"results": [_make_semgrep_result(path=str(fp))], "errors": []}
        findings = _parse_semgrep_output(raw, fp, config)
        assert findings[0].category == FindingCategory.DYNAMIC_LABEL_VALUE

    def test_malformed_result_item_skipped(
        self, config: MetricGuardConfig, tmp_path: Path
    ) -> None:
        """A result with missing required fields shouldn't crash the parser."""
        fp = tmp_path / "app.go"
        raw = {
            "results": [
                {"check_id": "MG-GO-001"},  # missing start, path, extra
                _make_semgrep_result(path=str(fp), line=5),  # valid entry
            ],
            "errors": [],
        }
        # Should not raise — may return 1 or 2 results depending on defaults
        findings = _parse_semgrep_output(raw, fp, config)
        # At least the valid one should be present
        rule_ids = [f.rule_id for f in findings]
        assert "MG-GO-001" in rule_ids


# ─────────────────────────────────────────────────────────────────────
# Integration: scan_file via mocked subprocess
# ─────────────────────────────────────────────────────────────────────


class TestScanFileIntegration:
    def _mock_subprocess(self, stdout_json: str) -> MagicMock:
        mock = MagicMock()
        mock.stdout = stdout_json
        mock.returncode = 1  # semgrep exits 1 when findings exist
        return mock

    def test_scan_file_returns_findings_via_subprocess(
        self, scanner: SemgrepScanner, tmp_path: Path
    ) -> None:
        go_file = tmp_path / "main.go"
        go_file.write_text('counter.With(prometheus.Labels{"user_id": userId}).Inc()')

        stdout = _semgrep_json(
            [_make_semgrep_result(check_id="MG-GO-001", path=str(go_file), line=1)]
        )

        with patch("metricguard.scanners.semgrep_scanner._semgrep_available", return_value=True):
            with patch("subprocess.run", return_value=self._mock_subprocess(stdout)):
                findings = scanner.scan_file(go_file, go_file.read_text())

        assert len(findings) == 1
        assert findings[0].rule_id == "MG-GO-001"
        assert findings[0].language == "go"

    def test_scan_ts_file_dispatches_ts_rules(
        self, scanner: SemgrepScanner, tmp_path: Path
    ) -> None:
        ts_file = tmp_path / "metrics.ts"
        ts_file.write_text("counter.labels({ userId: req.userId }).inc();")

        stdout = _semgrep_json(
            [_make_semgrep_result(check_id="MG-TS-001", path=str(ts_file), line=1)]
        )

        with patch("metricguard.scanners.semgrep_scanner._semgrep_available", return_value=True):
            with patch("subprocess.run", return_value=self._mock_subprocess(stdout)):
                findings = scanner.scan_file(ts_file, ts_file.read_text())

        assert findings[0].rule_id == "MG-TS-001"
        assert findings[0].language == "typescript"

    def test_scan_java_file_dispatches_java_rules(
        self, scanner: SemgrepScanner, tmp_path: Path
    ) -> None:
        java_file = tmp_path / "Service.java"
        java_file.write_text(
            'Counter.builder("requests").tag("userId", userId).register(reg).increment();'
        )

        stdout = _semgrep_json(
            [_make_semgrep_result(check_id="MG-JAVA-001", path=str(java_file), line=1)]
        )

        with patch("metricguard.scanners.semgrep_scanner._semgrep_available", return_value=True):
            with patch("subprocess.run", return_value=self._mock_subprocess(stdout)):
                findings = scanner.scan_file(java_file, java_file.read_text())

        assert findings[0].rule_id == "MG-JAVA-001"
        assert findings[0].language == "java"

    def test_subprocess_timeout_returns_empty(
        self, scanner: SemgrepScanner, tmp_path: Path
    ) -> None:
        go_file = tmp_path / "slow.go"
        go_file.write_text("package main")

        import subprocess as sp
        with patch("metricguard.scanners.semgrep_scanner._semgrep_available", return_value=True):
            with patch("subprocess.run", side_effect=sp.TimeoutExpired("semgrep", 60)):
                findings = scanner.scan_file(go_file, go_file.read_text())

        assert findings == []

    def test_json_parse_error_returns_empty(
        self, scanner: SemgrepScanner, tmp_path: Path
    ) -> None:
        go_file = tmp_path / "bad.go"
        go_file.write_text("package main")

        bad_output = MagicMock()
        bad_output.stdout = "not valid json <<"
        bad_output.returncode = 1

        with patch("metricguard.scanners.semgrep_scanner._semgrep_available", return_value=True):
            with patch("subprocess.run", return_value=bad_output):
                findings = scanner.scan_file(go_file, go_file.read_text())

        assert findings == []
