"""
MetricGuard Test Suite — SARIF Exporter Tests.

Tests for the SARIF 2.1.0 exporter:
  - Valid SARIF structure (schema, version, runs).
  - Rule generation from findings.
  - Location and region mapping.
  - Fingerprint stability.
  - False positive candidate suppression markers.
  - JSON serialization validity.
"""
from __future__ import annotations

import json

import pytest

from metricguard.models.finding import (
    EconomicImpact,
    Finding,
    FindingCategory,
    RemediationSuggestion,
    Severity,
)
from metricguard.reporters.sarif_exporter import SarifExporter


def _make_finding(**kwargs) -> Finding:
    """Create a minimal test Finding with sensible defaults."""
    defaults = dict(
        file_path="/repo/src/metrics.py",
        line_number=42,
        severity=Severity.HIGH,
        category=FindingCategory.DYNAMIC_LABEL_VALUE,
        rule_id="MG-PY-001",
        message="Test finding: dynamic label value detected.",
        metric_name="request_counter",
        label_or_tag_name="user_id",
        offending_code_snippet="counter.labels(user_id=uid).inc()",
        language="python",
        economic_impact=EconomicImpact(
            estimated_series_increase=100_000,
            risk_description="High impact.",
            estimated_monthly_cost_usd=50.0,
        ),
        remediation=RemediationSuggestion(
            description="Remove user_id from labels.",
            code_before="counter.labels(user_id=uid).inc()",
            code_after="counter.inc()  # remove user_id",
            docs_url="https://prometheus.io/docs/practices/naming/",
        ),
    )
    defaults.update(kwargs)
    return Finding(**defaults)


class TestSarifStructure:
    """Verify the top-level SARIF structure."""

    def test_sarif_version(self) -> None:
        exporter = SarifExporter([])
        sarif = json.loads(exporter.export())
        assert sarif["version"] == "2.1.0"

    def test_sarif_has_schema(self) -> None:
        exporter = SarifExporter([])
        sarif = json.loads(exporter.export())
        assert "$schema" in sarif
        assert "sarif" in sarif["$schema"]

    def test_sarif_has_one_run(self) -> None:
        exporter = SarifExporter([_make_finding()])
        sarif = json.loads(exporter.export())
        assert len(sarif["runs"]) == 1

    def test_tool_driver_name(self) -> None:
        exporter = SarifExporter([])
        sarif = json.loads(exporter.export())
        assert sarif["runs"][0]["tool"]["driver"]["name"] == "MetricGuard"

    def test_empty_findings_produces_valid_sarif(self) -> None:
        exporter = SarifExporter([])
        sarif_str = exporter.export()
        sarif = json.loads(sarif_str)
        assert sarif["runs"][0]["results"] == []
        assert sarif["runs"][0]["tool"]["driver"]["rules"] == []


class TestRuleGeneration:
    """Verify SARIF rule descriptors."""

    def test_one_rule_per_unique_rule_id(self) -> None:
        findings = [
            _make_finding(rule_id="MG-PY-001", line_number=10),
            _make_finding(rule_id="MG-PY-001", line_number=20),
            _make_finding(rule_id="MG-PY-002", line_number=30),
        ]
        exporter = SarifExporter(findings)
        sarif = json.loads(exporter.export())
        rules = sarif["runs"][0]["tool"]["driver"]["rules"]
        rule_ids = [r["id"] for r in rules]
        assert "MG-PY-001" in rule_ids
        assert "MG-PY-002" in rule_ids
        assert rule_ids.count("MG-PY-001") == 1

    def test_rule_has_security_severity(self) -> None:
        exporter = SarifExporter([_make_finding(severity=Severity.CRITICAL)])
        sarif = json.loads(exporter.export())
        rules = sarif["runs"][0]["tool"]["driver"]["rules"]
        assert "security-severity" in rules[0]["properties"]
        score = float(rules[0]["properties"]["security-severity"])
        assert score >= 9.0  # CRITICAL should be 9.5


class TestResultMapping:
    """Verify each Finding is correctly mapped to a SARIF result."""

    def test_result_has_correct_rule_id(self) -> None:
        finding = _make_finding(rule_id="MG-PY-004")
        sarif = json.loads(SarifExporter([finding]).export())
        results = sarif["runs"][0]["results"]
        assert results[0]["ruleId"] == "MG-PY-004"

    def test_result_location_maps_correctly(self) -> None:
        finding = _make_finding(line_number=99, column_number=5)
        sarif = json.loads(SarifExporter([finding]).export())
        region = sarif["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["region"]
        assert region["startLine"] == 99
        assert region["startColumn"] == 5

    def test_result_has_fingerprint(self) -> None:
        finding = _make_finding()
        sarif = json.loads(SarifExporter([finding]).export())
        result = sarif["runs"][0]["results"][0]
        assert "fingerprints" in result
        assert "metricguardFingerprint/v1" in result["fingerprints"]

    def test_fp_candidate_has_suppression(self) -> None:
        finding = _make_finding(
            is_false_positive_candidate=True,
            false_positive_reason="Taint analysis heuristic.",
        )
        sarif = json.loads(SarifExporter([finding]).export())
        result = sarif["runs"][0]["results"][0]
        assert "suppressions" in result
        assert result["suppressions"][0]["status"] == "underReview"

    def test_result_level_matches_severity(self) -> None:
        tests = [
            (Severity.CRITICAL, "error"),
            (Severity.HIGH, "error"),
            (Severity.MEDIUM, "warning"),
            (Severity.LOW, "note"),
            (Severity.INFO, "none"),
        ]
        for severity, expected_level in tests:
            finding = _make_finding(severity=severity)
            sarif = json.loads(SarifExporter([finding]).export())
            actual_level = sarif["runs"][0]["results"][0]["level"]
            assert actual_level == expected_level, f"For {severity}, expected {expected_level}, got {actual_level}"


class TestRelativePaths:
    """Verify relative path generation from base_path."""

    def test_relative_path_generated(self, tmp_path) -> None:
        finding = _make_finding(file_path=str(tmp_path / "src" / "metrics.py"))
        exporter = SarifExporter([finding], base_path=tmp_path)
        sarif = json.loads(exporter.export())
        uri = sarif["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["artifactLocation"]["uri"]
        assert uri == "src/metrics.py"

    def test_absolute_path_when_no_base(self) -> None:
        finding = _make_finding(file_path="/absolute/path/to/metrics.py")
        exporter = SarifExporter([finding], base_path=None)
        sarif = json.loads(exporter.export())
        uri = sarif["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["artifactLocation"]["uri"]
        assert "metrics.py" in uri
