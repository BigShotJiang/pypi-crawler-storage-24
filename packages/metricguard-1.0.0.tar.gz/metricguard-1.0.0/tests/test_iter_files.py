"""
Regression tests for the _iter_files 3-layer test-file filter.

Tests cover:
  Layer 1 — Directory-name pruning
  Layer 2 — Filename pattern (fnmatch) filtering
  Layer 3 — Legacy ignored_patterns path-glob filtering

All three layers must operate correctly when used together.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from metricguard.cli import _iter_files


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

PY = frozenset({".py"})
GO = frozenset({".go"})
ALL = frozenset({".py", ".go", ".ts", ".js"})

NO_PATTERNS: list[str] = []


def _make_files(root: Path, *relative_paths: str) -> list[Path]:
    """Create empty files at the given relative paths inside *root*."""
    created = []
    for rel in relative_paths:
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.touch()
        created.append(p.resolve())
    return created


def _collect(root: Path, extensions: frozenset[str] = ALL, **kwargs) -> set[str]:
    """Run _iter_files and return a set of relative path strings for easy assertion."""
    return {
        str(p.relative_to(root.resolve()))
        for p in _iter_files([root], extensions, NO_PATTERNS, **kwargs)
    }


# ──────────────────────────────────────────────────────────────────────────────
# Layer 1: Directory pruning
# ──────────────────────────────────────────────────────────────────────────────


class TestDirectoryPruning:
    """Layer 1: directories in ignored_dirs are never entered."""

    @pytest.mark.parametrize("dirname", [
        "tests", "test", "testdata", "testing",
        "spec", "specs", "__tests__", "__mocks__",
        "fixtures", "mock", "mocks", "e2e", "integration",
    ])
    def test_default_test_dirs_are_skipped(self, tmp_path: Path, dirname: str) -> None:
        _make_files(tmp_path,
                    "src/app.py",
                    f"{dirname}/test_something.py",
                    f"pkg/{dirname}/helper.py")
        result = _collect(tmp_path, PY)
        assert "src/app.py" in result
        # Nothing from the test directory should appear
        assert not any(dirname in p for p in result), (
            f"Directory '{dirname}' was not pruned: {result}"
        )

    def test_case_insensitive_dir_pruning(self, tmp_path: Path) -> None:
        """Directory names should be matched case-insensitively."""
        _make_files(tmp_path, "Tests/test_foo.py", "src/app.py")
        result = _collect(tmp_path, PY)
        assert "src/app.py" in result
        assert not any("Tests" in p for p in result)

    def test_non_test_dir_is_scanned(self, tmp_path: Path) -> None:
        """Directories not in the ignore list should be traversed normally."""
        _make_files(tmp_path, "services/auth/app.py", "utils/helpers.go")
        result = _collect(tmp_path)
        assert "services/auth/app.py" in result
        assert "utils/helpers.go" in result

    def test_custom_ignored_dirs_override(self, tmp_path: Path) -> None:
        """Passing ignored_dirs replaces the defaults; only the custom list applies."""
        _make_files(tmp_path,
                    "benchmarks/bench.py",   # custom dir to ignore
                    "tests/test_foo.py")     # normally ignored, but not in custom list
        result = _collect(
            tmp_path, PY,
            ignored_dirs=["benchmarks"],    # custom — no 'tests' here
            ignored_file_patterns=[],
        )
        # 'tests/test_foo.py' is NOT in custom ignored_dirs, so it IS discovered
        assert "tests/test_foo.py" in result
        # 'benchmarks/bench.py' IS in custom ignored_dirs, so it is pruned
        assert not any("benchmarks" in p for p in result)


# ──────────────────────────────────────────────────────────────────────────────
# Layer 2: Filename pattern filtering
# ──────────────────────────────────────────────────────────────────────────────


class TestFilePatternFiltering:
    """Layer 2: co-located test files are excluded by filename fnmatch."""

    @pytest.mark.parametrize("filename", [
        "test_metrics.py",    # Python pytest
        "metrics_test.py",    # Python unittest
        "metrics_test.go",    # Go standard
        "metrics.spec.ts",    # TypeScript Jest
        "metrics.test.ts",    # TypeScript Jest
        "metrics.spec.js",    # JavaScript
        "metrics.test.js",    # JavaScript
        "component.spec.jsx", # React
        "component.test.jsx", # React
        "component.spec.tsx", # React+TS
        "component.test.tsx", # React+TS
    ])
    def test_test_filenames_excluded(self, tmp_path: Path, filename: str) -> None:
        """Test files co-located with production code must be filtered out."""
        ext = Path(filename).suffix
        _make_files(tmp_path, f"src/{filename}", "src/app.py")
        result = _collect(tmp_path, frozenset({ext, ".py"}))
        assert "src/app.py" in result
        assert f"src/{filename}" not in result, (
            f"Test file '{filename}' was not filtered by filename pattern"
        )

    def test_production_py_file_not_excluded(self, tmp_path: Path) -> None:
        """A normal 'app.py' has no test-file pattern, must not be filtered."""
        _make_files(tmp_path, "src/app.py", "src/utils.py")
        result = _collect(tmp_path, PY)
        assert "src/app.py" in result
        assert "src/utils.py" in result

    def test_go_test_file_outside_testdir(self, tmp_path: Path) -> None:
        """Go _test.go files that live next to production code should be pruned."""
        _make_files(tmp_path, "pkg/handler.go", "pkg/handler_test.go")
        result = _collect(tmp_path, GO)
        assert "pkg/handler.go" in result
        assert "pkg/handler_test.go" not in result


# ──────────────────────────────────────────────────────────────────────────────
# Layer 3: Legacy path-glob filtering
# ──────────────────────────────────────────────────────────────────────────────


class TestLegacyPathGlobs:
    """Layer 3: ignored_patterns (full path globs) still work normally."""

    def test_glob_excludes_vendor(self, tmp_path: Path) -> None:
        _make_files(tmp_path, "vendor/dep/metrics.py", "src/app.py")
        result = set(_iter_files(
            [tmp_path], PY, ["**/vendor/**"],
        ))
        names = {str(p.relative_to(tmp_path.resolve())) for p in result}
        assert "src/app.py" in names
        assert not any("vendor" in p for p in names)


# ──────────────────────────────────────────────────────────────────────────────
# Integration: All 3 layers together
# ──────────────────────────────────────────────────────────────────────────────


class TestAllLayersTogether:
    """Combined tree with test dirs, co-located test files, and production code."""

    def test_only_production_files_yielded(self, tmp_path: Path) -> None:
        _make_files(tmp_path,
                    # Production
                    "src/metrics.py",
                    "pkg/handler.go",
                    # Layer 1: pruned via directory name
                    "tests/test_metrics.py",
                    "spec/metrics.spec.ts",
                    "testdata/fixtures.py",
                    "__mocks__/mock_client.py",
                    # Layer 2: pruned via filename pattern
                    "src/metrics_test.go",
                    "src/metrics.test.ts",
                    # Layer 3: pruned via path glob
                    "vendor/lib/helper.py",
                    )
        result = set(_iter_files(
            [tmp_path],
            frozenset({".py", ".go", ".ts"}),
            ["**/vendor/**"],
        ))
        names = {str(p.relative_to(tmp_path.resolve())) for p in result}
        assert names == {"src/metrics.py", "pkg/handler.go"}, (
            f"Expected only production files, got: {names}"
        )

    def test_extend_ignored_dirs_additive(self, tmp_path: Path) -> None:
        """Extra ignored dirs from metricguard.yml are respected on top of defaults."""
        _make_files(tmp_path,
                    "src/app.py",
                    "bench/perf.py",    # custom extra dir
                    "tests/test_foo.py",  # default dir, still pruned
                    )
        from metricguard.core.config import _DEFAULT_IGNORED_DIRS
        combined = list(_DEFAULT_IGNORED_DIRS) + ["bench"]
        result = _collect(tmp_path, PY, ignored_dirs=combined, ignored_file_patterns=[])
        assert "src/app.py" in result
        assert not any("bench" in p for p in result)
        assert not any("tests" in p for p in result)
