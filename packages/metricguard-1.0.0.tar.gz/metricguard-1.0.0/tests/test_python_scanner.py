"""
MetricGuard Test Suite — Python Scanner Tests.

Tests for the Python AST scanner covering:
  - Detection of dangerous keywords in label arguments.
  - F-string label value detection.
  - Taint analysis: tracking variables to their sources.
  - Bounded value heuristics: Enum members, booleans, constants.
  - Edge cases: syntax errors, empty files, chained method calls.
"""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from metricguard.core.config import MetricGuardConfig
from metricguard.models.finding import Finding, Severity
from metricguard.scanners.python_scanner import PythonScanner


def _scanner() -> PythonScanner:
    """Return a PythonScanner with default config."""
    return PythonScanner(MetricGuardConfig.default())


def _scan_source(source: str, tmp_path: Path) -> list[Finding]:
    """Write source to a temp .py file and scan it."""
    f = tmp_path / "test_code.py"
    f.write_text(textwrap.dedent(source))
    return _scanner().scan_file(f, f.read_text())


class TestDangerousKeyword:
    """MG-PY-004: Variable name matches dangerous keyword."""

    def test_detects_user_id_label(self, tmp_path: Path) -> None:
        source = """
        from prometheus_client import Counter
        c = Counter('requests', 'Reqs', ['user_id'])
        user_id = "abc-123"
        c.labels(user_id=user_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        rule_ids = [f.rule_id for f in findings]
        assert any("MG-PY-004" in r or "MG-PY-003" in r for r in rule_ids), \
            f"Expected dangerous keyword finding, got: {rule_ids}"

    def test_detects_request_id_label(self, tmp_path: Path) -> None:
        source = """
        request_id = "req-xyz"
        COUNTER.labels(request_id=request_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0

    def test_no_finding_for_status_label(self, tmp_path: Path) -> None:
        source = """
        status = "ok"
        COUNTER.labels(status=status).inc()
        """
        findings = _scan_source(source, tmp_path)
        # 'status' is not in dangerous keywords — taint analysis may still flag
        # the unknown origin, but we just verify no CRITICAL keyword finding
        critical_findings = [f for f in findings if f.severity == Severity.CRITICAL]
        assert len(critical_findings) == 0


class TestFStringDetection:
    """MG-PY-002: F-string label values."""

    def test_detects_fstring_label(self, tmp_path: Path) -> None:
        source = """
        method = "GET"
        endpoint = "/api/v1/users/{user_id}"
        HISTOGRAM.labels(route=f"{method}:{endpoint}").observe(0.1)
        """
        findings = _scan_source(source, tmp_path)
        rule_ids = [f.rule_id for f in findings]
        assert "MG-PY-002" in rule_ids, f"Expected MG-PY-002, got: {rule_ids}"

    def test_fstring_finding_is_not_fp_candidate(self, tmp_path: Path) -> None:
        source = """
        COUNTER.labels(env=f"env-{some_var}").inc()
        """
        findings = _scan_source(source, tmp_path)
        fstring_findings = [f for f in findings if f.rule_id == "MG-PY-002"]
        if fstring_findings:
            assert not fstring_findings[0].is_false_positive_candidate


class TestBoundednessHeuristics:
    """Context-aware heuristics: Enum members should not trigger findings."""

    def test_enum_member_is_safe(self, tmp_path: Path) -> None:
        source = """
        from enum import Enum

        class Environment(Enum):
            PROD = "prod"
            STAGING = "staging"
            DEV = "dev"

        COUNTER.labels(env=Environment.PROD).inc()
        """
        findings = _scan_source(source, tmp_path)
        # Enum member access should be recognized as bounded — no findings
        assert len(findings) == 0, f"Expected no findings for Enum label, got: {findings}"

    def test_constant_string_is_safe(self, tmp_path: Path) -> None:
        source = """
        COUNTER.labels(status="success").inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0

    def test_boolean_is_safe(self, tmp_path: Path) -> None:
        source = """
        COUNTER.labels(cached=True).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0


class TestTaintAnalysis:
    """MG-PY-003: Taint analysis for variable origins."""

    def test_variable_from_request_is_tainted(self, tmp_path: Path) -> None:
        source = """
        label_val = request.user_id
        COUNTER.labels(val=label_val).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "Expected taint finding for request.user_id assignment"

    def test_variable_from_constant_is_safe(self, tmp_path: Path) -> None:
        source = """
        region = "us-east-1"
        COUNTER.labels(region=region).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0, f"Expected no findings for constant assignment, got: {findings}"

    def test_function_with_unknown_return_triggers_taint(self, tmp_path: Path) -> None:
        source = """
        def get_label():
            return some_dynamic_source()

        val = get_label()
        GAUGE.labels(label=val).set(1)
        """
        findings = _scan_source(source, tmp_path)
        # Unknown return → should be flagged as tainted
        assert len(findings) > 0


class TestEdgeCases:
    """Edge cases: syntax errors, empty files, large files."""

    def test_syntax_error_returns_empty(self, tmp_path: Path) -> None:
        f = tmp_path / "broken.py"
        f.write_text("def unclosed(")
        findings = _scanner().scan_file(f, f.read_text())
        assert findings == []

    def test_empty_file_returns_empty(self, tmp_path: Path) -> None:
        f = tmp_path / "empty.py"
        f.write_text("")
        findings = _scanner().scan_file(f, f.read_text())
        assert findings == []

    def test_file_with_no_monitoring_calls(self, tmp_path: Path) -> None:
        source = """
        import os

        def process(user_id: str) -> None:
            print(f"Processing {user_id}")
        """
        findings = _scan_source(source, tmp_path)
        assert findings == []

    def test_chained_method_call(self, tmp_path: Path) -> None:
        """labels() chained on a Counter object should be detected when a dangerous keyword variable is used."""
        source = """
        from prometheus_client import Counter
        REQUEST_COUNT = Counter('req', 'Requests', ['user_id'])
        user_id = get_current_user_id()   # unknown origin: return value flagged as tainted
        REQUEST_COUNT.labels(user_id=user_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0


class TestFindingModel:
    """Verify Finding objects are correctly populated."""

    def test_finding_has_fingerprint(self, tmp_path: Path) -> None:
        source = """
        user_id = request.user_id
        COUNTER.labels(user_id=user_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        if findings:
            f = findings[0]
            assert len(f.fingerprint) == 16  # SHA256[:16]
            assert f.fingerprint.isalnum()

    def test_finding_has_economic_impact(self, tmp_path: Path) -> None:
        source = """
        user_id = "some-user"
        COUNTER.labels(user_id=user_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        if findings:
            assert findings[0].economic_impact is not None
            assert findings[0].economic_impact.estimated_series_increase > 0

    def test_finding_has_remediation(self, tmp_path: Path) -> None:
        source = """
        uid = "abc"
        COUNTER.labels(user_id=uid).inc()
        """
        findings = _scan_source(source, tmp_path)
        if findings:
            assert findings[0].remediation is not None
            assert len(findings[0].remediation.description) > 0


# ─────────────────────────────────────────────────────────────────────────────
# Regression tests for the 4 false-positive / unnecessary-scan fixes
# ─────────────────────────────────────────────────────────────────────────────


class TestWordBoundaryKeywordMatching:
    """Fix 2: dangerous keywords use word-boundary regex, not bare substring."""

    def test_no_fp_on_identifier_contains_id(self, tmp_path: Path) -> None:
        """'identifier' contains 'id' as substring but should NOT match."""
        source = """
        identifier = "some_bounded_value"
        COUNTER.labels(key=identifier).inc()
        """
        findings = _scan_source(source, tmp_path)
        kw_findings = [f for f in findings if f.rule_id == "MG-PY-004"]
        assert len(kw_findings) == 0, (
            f"False positive: 'identifier' should not match keyword 'id'. Got: {kw_findings}"
        )

    def test_no_fp_on_middle_contains_id(self, tmp_path: Path) -> None:
        """'middle' contains 'id' as substring but should NOT match."""
        source = """
        middle = "center"
        COUNTER.labels(pos=middle).inc()
        """
        findings = _scan_source(source, tmp_path)
        kw_findings = [f for f in findings if f.rule_id == "MG-PY-004"]
        assert len(kw_findings) == 0, (
            f"False positive: 'middle' should not match keyword 'id'. Got: {kw_findings}"
        )

    def test_bare_id_still_flagged(self, tmp_path: Path) -> None:
        """A variable literally named 'id' should still trigger a finding."""
        source = """
        id = "user-123"
        COUNTER.labels(label=id).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "Variable literally named 'id' should still be flagged"

    def test_provider_id_still_flagged(self, tmp_path: Path) -> None:
        """'provider_id' ends with '_id' and should still match keyword 'id'."""
        source = """
        provider_id = get_provider_id()
        COUNTER.labels(label=provider_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "'provider_id' should be flagged (ends with _id)"

    def test_user_id_still_flagged(self, tmp_path: Path) -> None:
        """Canonical 'user_id' must still trigger CRITICAL keyword finding."""
        source = """
        user_id = "abc-123"
        COUNTER.labels(u=user_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        kw_findings = [f for f in findings if f.rule_id == "MG-PY-004"]
        assert len(kw_findings) > 0, "user_id should still be flagged"


class TestUppercaseAttributeSafe:
    """Fix 4: UPPERCASE attribute access treated as bounded Enum constant."""

    def test_uppercase_attr_on_unknown_class_is_safe(self, tmp_path: Path) -> None:
        """OnboardingTaskStatus.COMPLETE — Enum from external module, UPPERCASE attr."""
        source = """
        COUNTER.labels(status=OnboardingTaskStatus.COMPLETE).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0, (
            f"UPPERCASE Enum constant should not be flagged. Got: {findings}"
        )

    def test_uppercase_attr_multi_word_is_safe(self, tmp_path: Path) -> None:
        """MyStatus.IN_PROGRESS — multi-word ALL_CAPS Enum constant."""
        source = """
        GAUGE.labels(phase=JobStatus.IN_PROGRESS).set(1)
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0, (
            f"Multi-word UPPERCASE Enum constant should not be flagged. Got: {findings}"
        )

    def test_lowercase_attr_still_flagged(self, tmp_path: Path) -> None:
        """obj.some_method — mixed-case attr is not an Enum constant, still flagged."""
        source = """
        COUNTER.labels(val=obj.get_value()).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "Dynamic method call result should still be flagged"


class TestRecordFunctionRemoved:
    """Fix 3: 'record' removed from monitored functions — no false positives on ORM calls."""

    def test_orm_record_call_not_flagged(self, tmp_path: Path) -> None:
        """Django-style objects.record() should not trigger any finding."""
        source = """
        def save_metric(user_id: str) -> None:
            objects.record(value=user_id, timestamp=now())
        """
        findings = _scan_source(source, tmp_path)
        # If 'record' was still monitored it would generate a finding;
        # after Fix 3 the call is no longer intercepted.
        monitored_findings = [
            f for f in findings
            if "record" in (f.metric_name or "").lower()
        ]
        assert len(monitored_findings) == 0, (
            f"'record()' should not be treated as a monitored metric function. Got: {monitored_findings}"
        )


class TestShortKeywordCamelCase:
    """Smart 3-arm regex for short keywords (id, ip, port, etc.)."""

    def test_bare_ip_is_flagged(self, tmp_path: Path) -> None:
        """Exact short keyword 'ip' at label argument must be flagged."""
        source = """
        from prometheus_client import Counter
        c = Counter('reqs', 'Reqs', ['ip'])
        c.labels(ip=request.remote_addr).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "Bare 'ip' label should be flagged"

    def test_snake_client_ip_is_flagged(self, tmp_path: Path) -> None:
        """'client_ip' (snake_case suffix) must still be flagged."""
        source = """
        from prometheus_client import Counter
        c = Counter('reqs', 'Reqs', ['client_ip'])
        c.labels(client_ip=request.remote_addr).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "'client_ip' (snake suffix) should be flagged"

    def test_camel_client_ip_is_flagged(self, tmp_path: Path) -> None:
        """'clientIp' (CamelCase suffix) must be flagged."""
        source = """
        from prometheus_client import Counter
        c = Counter('reqs', 'Reqs', ['clientIp'])
        c.labels(clientIp=request.remote_addr).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "'clientIp' (CamelCase suffix) should be flagged"

    def test_camel_prefix_not_flagged(self, tmp_path: Path) -> None:
        """'ipAddress' has 'ip' as a PREFIX, not suffix — must NOT be flagged as bare 'ip'."""
        source = """
        from prometheus_client import Gauge
        g = Gauge('connections', 'Conns', ['zone'])
        g.labels(zone="us-east-1").set(1)
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0, "Unrelated label should not be flagged"

    def test_scripted_does_not_match_id(self, tmp_path: Path) -> None:
        """'scripted' contains 'id' but is NOT an id suffix — must not be flagged."""
        source = """
        from prometheus_client import Counter
        c = Counter('tasks', 'Tasks', ['status'])
        c.labels(status="scripted").inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0, "'scripted' should not match keyword 'id'"

    def test_bare_id_is_flagged(self, tmp_path: Path) -> None:
        """Exact short keyword 'id' at label argument must be flagged."""
        source = """
        from prometheus_client import Counter
        c = Counter('items', 'Items', ['id'])
        c.labels(id=item_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "Bare 'id' label should be flagged"

    def test_snake_order_id_is_flagged(self, tmp_path: Path) -> None:
        """'order_id' (snake_case suffix of 'id') must be flagged."""
        source = """
        from prometheus_client import Counter
        c = Counter('orders', 'Orders', ['order_id'])
        c.labels(order_id=order_id).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, "'order_id' should be flagged"


class TestInlineEscapeHatch:
    """metricguard:ignore / metricguard:disable-line suppresses findings."""

    def test_ignore_comment_on_same_line(self, tmp_path: Path) -> None:
        """Finding is suppressed when metricguard:ignore is on the flagged line."""
        source = """
        from prometheus_client import Counter
        c = Counter('reqs', 'R', ['user_id'])
        c.labels(user_id=uid).inc()  # metricguard:ignore
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0, (
            "Finding should be suppressed by inline 'metricguard:ignore'"
        )

    def test_disable_line_comment_on_preceding_line(self, tmp_path: Path) -> None:
        """Finding is suppressed when metricguard:disable-line is on the preceding line."""
        source = """
        from prometheus_client import Counter
        c = Counter('reqs', 'R', ['user_id'])
        # metricguard:disable-line
        c.labels(user_id=uid).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) == 0, (
            "Finding should be suppressed by 'metricguard:disable-line' on preceding line"
        )

    def test_no_comment_still_flagged(self, tmp_path: Path) -> None:
        """Without any suppression comment the finding must still be reported."""
        source = """
        from prometheus_client import Counter
        c = Counter('reqs', 'R', ['user_id'])
        c.labels(user_id=uid).inc()
        """
        findings = _scan_source(source, tmp_path)
        assert len(findings) > 0, (
            "Finding should be reported when no suppression comment is present"
        )
