"""
Regression tests for the 7 enterprise hardening mechanisms.

  H1 — OOM size gate: files > 1 MiB are skipped
  H2 — Dot-dir pruning: hidden directories are never entered
  H3 — Dependency/build dir pruning: node_modules, vendor, target, …
  H4 — Symlink safety: followlinks=False
  H5 — YAML Prometheus heuristic: non-monitoring YAML returns []
  H6 — Smart short-keyword regex: CamelCase + snake_case detection
  H7 — Inline escape hatch: metricguard:ignore / disable-line
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from metricguard.cli import _iter_files
from metricguard.core.config import MetricGuardConfig, _build_short_keyword_pattern, _SHORT_KEYWORDS
from metricguard.scanners.yaml_scanner import YamlScanner

ALL_EXT = frozenset({".py", ".go", ".ts", ".js", ".yml", ".yaml"})
NO_PATTERNS: list[str] = []


def _collect(root: Path, ext: frozenset[str] = ALL_EXT) -> set[str]:
    """Run _iter_files and return relative path strings."""
    return {
        str(p.relative_to(root.resolve()))
        for p in _iter_files([root], ext, NO_PATTERNS)
    }


# ══════════════════════════════════════════════════════════════════════════════
# H1 — OOM / file size gate
# ══════════════════════════════════════════════════════════════════════════════

class TestOomSizeGate:
    """Files strictly larger than 1 MiB must be silently skipped."""

    def test_large_file_is_skipped(self, tmp_path: Path) -> None:
        small = tmp_path / "small.py"
        small.write_bytes(b"x" * 100)

        large = tmp_path / "large.py"
        large.write_bytes(b"x" * (1_048_576 + 1))   # 1 MiB + 1 byte

        result = _collect(tmp_path, frozenset({".py"}))
        assert "small.py" in result, "Small file should be discovered"
        assert "large.py" not in result, "Oversized file must be skipped"

    def test_exactly_1_mib_is_allowed(self, tmp_path: Path) -> None:
        exact = tmp_path / "exact.py"
        exact.write_bytes(b"x" * 1_048_576)  # exactly 1 MiB (not strictly greater)

        result = _collect(tmp_path, frozenset({".py"}))
        assert "exact.py" in result, "File of exactly 1 MiB should be allowed"


# ══════════════════════════════════════════════════════════════════════════════
# H2 — Dot-dir pruning
# ══════════════════════════════════════════════════════════════════════════════

class TestDotDirPruning:
    """Hidden directories (dot-prefix) must never be entered."""

    @pytest.mark.parametrize("hidden_dir", [
        ".git", ".github", ".vscode", ".idea", ".mypy_cache",
    ])
    def test_hidden_dir_is_pruned(self, tmp_path: Path, hidden_dir: str) -> None:
        src = tmp_path / "src" / "app.py"
        src.parent.mkdir(parents=True)
        src.touch()

        hidden_file = tmp_path / hidden_dir / "secret.py"
        hidden_file.parent.mkdir(parents=True)
        hidden_file.touch()

        result = _collect(tmp_path, frozenset({".py"}))
        assert "src/app.py" in result
        assert not any(hidden_dir in p for p in result), (
            f"Hidden dir '{hidden_dir}' should be pruned: {result}"
        )


# ══════════════════════════════════════════════════════════════════════════════
# H3 — Dependency / build dir pruning
# ══════════════════════════════════════════════════════════════════════════════

class TestDepAndBuildDirPruning:
    """Dependency trees and build artifact directories must be pruned."""

    @pytest.mark.parametrize("dirname", [
        "node_modules", "vendor", "venv", "env",
        "build", "dist", "out", "target", "bin", "obj", "__pycache__",
    ])
    def test_dep_or_build_dir_is_pruned(self, tmp_path: Path, dirname: str) -> None:
        prod = tmp_path / "src" / "main.py"
        prod.parent.mkdir(parents=True)
        prod.touch()

        dep_file = tmp_path / dirname / "dep.py"
        dep_file.parent.mkdir(parents=True)
        dep_file.touch()

        result = _collect(tmp_path, frozenset({".py"}))
        assert "src/main.py" in result
        assert not any(dirname in p for p in result), (
            f"Dir '{dirname}' should be pruned: {result}"
        )


# ══════════════════════════════════════════════════════════════════════════════
# H4 — Symlink safety
# ══════════════════════════════════════════════════════════════════════════════

class TestSymlinkSafety:
    """Symlinks to directories outside the scan root must not be followed."""

    def test_symlink_dir_is_not_followed(self, tmp_path: Path) -> None:
        external = tmp_path / "external"
        external.mkdir()
        (external / "secret.py").touch()

        project = tmp_path / "project"
        project.mkdir()
        (project / "app.py").touch()

        link = project / "linked"
        link.symlink_to(external, target_is_directory=True)

        result = _collect(project, frozenset({".py"}))
        assert "app.py" in result
        assert not any("secret" in p for p in result), (
            f"Symlink directory should NOT be followed: {result}"
        )


# ══════════════════════════════════════════════════════════════════════════════
# H5 — YAML Prometheus/OTel heuristic
# ══════════════════════════════════════════════════════════════════════════════

class TestYamlMonitoringHeuristic:
    """Non-monitoring YAML files must be skipped by the fast-path heuristic."""

    def _scan(self, source: str, tmp_path: Path):
        f = tmp_path / "config.yml"
        f.write_text(source)
        return YamlScanner(MetricGuardConfig.default()).scan_file(f, f.read_text())

    def test_docker_compose_returns_empty(self, tmp_path: Path) -> None:
        source = """\
        version: "3.9"
        services:
          app:
            image: myapp:latest
            environment:
              - USER_ID=admin
        """
        assert self._scan(source, tmp_path) == [], (
            "Docker Compose YAML should be skipped (no monitoring indicators)"
        )

    def test_github_actions_returns_empty(self, tmp_path: Path) -> None:
        source = """\
        name: CI
        on: [push]
        jobs:
          build:
            runs-on: ubuntu-latest
            steps:
              - uses: actions/checkout@v3
        """
        assert self._scan(source, tmp_path) == [], (
            "GitHub Actions YAML should be skipped (no monitoring indicators)"
        )

    def test_prometheus_config_is_scanned(self, tmp_path: Path) -> None:
        """A file with a Prometheus indicator must NOT be fast-pathed out."""
        source = """\
        scrape_configs:
          - job_name: myapp
            relabel_configs:
              - source_labels: [http_url]
                target_label: path
                action: replace
        """
        # Should not raise; may or may not find issues, but must not skip entirely.
        # We just confirm scan_file does not short-circuit.
        findings = self._scan(source, tmp_path)
        # The test is about the *heuristic*, not the finding count.
        # A real Prometheus config with a dangerous `target_label: path` is fine;
        # we only care that the scanner ran (indicator present → no early return).
        assert isinstance(findings, list)


# ══════════════════════════════════════════════════════════════════════════════
# H6 — Smart short-keyword regex (unit tests for the pattern builder)
# ══════════════════════════════════════════════════════════════════════════════

class TestShortKeywordPatternBuilder:
    """_build_short_keyword_pattern generates correct 3-arm patterns."""

    @pytest.mark.parametrize("kw", _SHORT_KEYWORDS)
    def test_exact_match(self, kw: str) -> None:
        pat = _build_short_keyword_pattern(kw)
        assert pat.search(kw), f"Should match exact '{kw}'"

    @pytest.mark.parametrize("kw", _SHORT_KEYWORDS)
    def test_snake_suffix(self, kw: str) -> None:
        pat = _build_short_keyword_pattern(kw)
        assert pat.search(f"client_{kw}"), f"Should match 'client_{kw}' (snake suffix)"

    @pytest.mark.parametrize("kw", _SHORT_KEYWORDS)
    def test_camel_suffix(self, kw: str) -> None:
        cap = kw[0].upper() + kw[1:]
        pat = _build_short_keyword_pattern(kw)
        assert pat.search(f"client{cap}"), f"Should match 'client{cap}' (CamelCase suffix)"

    def test_prefix_position_not_matched_for_ip(self) -> None:
        """'ipAddress' should NOT match the 'ip' keyword."""
        pat = _build_short_keyword_pattern("ip")
        # Exact arm: 'ipAddress' != 'ip'
        # Snake arm: no leading '_'
        # Camel arm: ends with 'ress', not 'Ip'
        assert not pat.search("ipAddress"), "'ipAddress' has 'ip' as a prefix, not a suffix"

    def test_embedded_substring_not_matched_for_id(self) -> None:
        """'scripted' must not match 'id' keyword (embedded, not suffix)."""
        pat = _build_short_keyword_pattern("id")
        assert not pat.search("scripted"), "'scripted' should not match keyword 'id'"
