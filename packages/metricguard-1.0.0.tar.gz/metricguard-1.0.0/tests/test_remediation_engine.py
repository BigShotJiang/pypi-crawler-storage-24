"""
Tests for the RemediationEngine.

Covers:
  - Rule-specific fix generators for Python, YAML, AWS, GCP, Azure, StatsD, Telegraf
  - Existing scanner-provided fixes are never overwritten
  - Unknown rule IDs return a generic fix without crashing
  - Default description generation when none exists
  - Immutability: original Finding is not mutated
"""
from __future__ import annotations

import pytest

from metricguard.engines.remediation_engine import RemediationEngine
from metricguard.models.finding import (
    FindingCategory,
    Finding,
    RemediationSuggestion,
    Severity,
)


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def _make_finding(
    rule_id: str = "MG-PY-001",
    label: str | None = "user_id",
    snippet: str | None = None,
    taint_source: str | None = None,
    metric: str | None = "request_count",
    existing_remediation: RemediationSuggestion | None = None,
    severity: Severity = Severity.HIGH,
) -> Finding:
    return Finding(
        file_path="/repo/app.py",
        line_number=42,
        severity=severity,
        category=FindingCategory.DYNAMIC_LABEL_VALUE,
        rule_id=rule_id,
        message="Test finding",
        label_or_tag_name=label,
        offending_code_snippet=snippet,
        taint_source=taint_source,
        metric_name=metric,
        remediation=existing_remediation,
    )


# ─────────────────────────────────────────────────────────────────────
# MG-PY-001: Dynamic label value
# ─────────────────────────────────────────────────────────────────────

class TestPyDynamicLabel:
    def test_generates_code_before_and_after(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-001", label="user_id"))
        rem = enriched.remediation
        assert rem is not None
        assert rem.code_before is not None
        assert rem.code_after is not None

    def test_code_after_contains_logger_info(self) -> None:
        """Fix should suggest structured logging."""
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-001", label="user_id"))
        assert "logger.info" in enriched.remediation.code_after

    def test_code_after_contains_label_name(self) -> None:
        """Label name appears in the structured log extra dict."""
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-001", label="request_id"))
        assert "request_id" in enriched.remediation.code_after

    def test_code_before_contains_warning_comment(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-001", label="user_id"))
        assert "⚠️" in enriched.remediation.code_before


# ─────────────────────────────────────────────────────────────────────
# MG-PY-002: F-string label value
# ─────────────────────────────────────────────────────────────────────

class TestPyFStringLabel:
    def test_generates_static_label_fix(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-002", label="user_id", snippet="f'{user_id}'"))
        assert "static_value" in enriched.remediation.code_after

    def test_snippet_appears_in_fix(self) -> None:
        """The f-string snippet should appear in the before/after for context."""
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-002", snippet="f'id:{req_id}'"))
        # The snippet should appear in code_before context
        assert "f'id:{req_id}'" in enriched.remediation.code_before or \
               "f'id:{req_id}'" in enriched.remediation.code_after


# ─────────────────────────────────────────────────────────────────────
# MG-PY-003: Tainted variable
# ─────────────────────────────────────────────────────────────────────

class TestTaintedVariable:
    def test_generates_allowlist_fix(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-003", label="status", taint_source="request.status"))
        assert "ALLOWED_" in enriched.remediation.code_after
        assert "frozenset" in enriched.remediation.code_after

    def test_taint_source_in_fix(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-003", label="env", taint_source="os.environ.get('ENV')"))
        assert "os.environ.get('ENV')" in enriched.remediation.code_after


# ─────────────────────────────────────────────────────────────────────
# MG-PY-004: Dangerous keyword
# ─────────────────────────────────────────────────────────────────────

class TestDangerousKeyword:
    def test_generates_rename_or_drop_suggestion(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-004", label="user_id"))
        # Suggests either a category alternative or dropping the label
        assert "segment" in enriched.remediation.code_after or "removed" in enriched.remediation.code_after

    def test_fix_references_original_label(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-004", label="account_id"))
        assert "account_id" in enriched.remediation.code_before


# ─────────────────────────────────────────────────────────────────────
# MG-YAML-001 through MG-YAML-006: YAML relabel
# ─────────────────────────────────────────────────────────────────────

class TestYamlRelabel:
    @pytest.mark.parametrize("rule_id", [
        "MG-YAML-001", "MG-YAML-002", "MG-YAML-003",
        "MG-YAML-004", "MG-YAML-005", "MG-YAML-006",
    ])
    def test_all_yaml_rules_get_fix(self, rule_id: str) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding(rule_id=rule_id, label="pod_id"))
        assert enriched.remediation.code_before is not None
        assert enriched.remediation.code_after is not None

    def test_yaml_fix_suggests_drop_action(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-YAML-001", label="pod_id"))
        assert "drop" in enriched.remediation.code_after

    def test_yaml_labelmap_suggests_removal(self) -> None:
        """Labelmap wildcard rule suggests removing the rule entirely."""
        engine = RemediationEngine()
        enriched = engine.enrich(
            _make_finding("MG-YAML-003", label=None, snippet="action: labelmap")
        )
        assert "Remove" in enriched.remediation.code_after or "explicit" in enriched.remediation.code_after


# ─────────────────────────────────────────────────────────────────────
# MG-AWS-PY-001: CloudWatch dynamic dimension
# ─────────────────────────────────────────────────────────────────────

class TestAwsPythonFix:
    def test_suggests_constant_dimension(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-AWS-PY-001", label="UserId"))
        assert "bounded_constant" in enriched.remediation.code_after

    def test_suggests_cloudwatch_logs_fallback(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-AWS-PY-001", label="UserId"))
        assert "logger.info" in enriched.remediation.code_after


# ─────────────────────────────────────────────────────────────────────
# MG-GCP-PY-001, MG-AZR-PY-001, MG-STAT-PY-001
# ─────────────────────────────────────────────────────────────────────

class TestCloudSDKFixes:
    def test_gcp_fix_suggests_cloud_logging(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-GCP-PY-001", label="user_id"))
        assert "Cloud Logging" in enriched.remediation.code_after or "logging.info" in enriched.remediation.code_after

    def test_azure_fix_suggests_log_analytics(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-AZR-PY-001", label="customer_id"))
        assert "track_event" in enriched.remediation.code_after or "Log Analytics" in enriched.remediation.code_after

    def test_statsd_fix_suggests_bounded_tags(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-STAT-PY-001", label="user_tag", snippet="f'user:{user_id}'"))
        assert "env:prod" in enriched.remediation.code_after or "bounded" in enriched.remediation.code_after


# ─────────────────────────────────────────────────────────────────────
# MG-TEL-INF-001, MG-TEL-INF-002
# ─────────────────────────────────────────────────────────────────────

class TestTelegrafFixes:
    def test_global_tag_fix_suggests_removal(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-TEL-INF-001", label="pod_id"))
        assert "[global_tags]" in enriched.remediation.code_after
        assert "pod_id" in enriched.remediation.code_after or "Removed" in enriched.remediation.code_after

    def test_regex_processor_fix_suggests_bounded_result_key(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-TEL-INF-002", label="user_id"))
        assert "api_version" in enriched.remediation.code_after or "bounded" in enriched.remediation.code_after


# ─────────────────────────────────────────────────────────────────────
# MG-AWS-INF-001, MG-AWS-INF-002
# ─────────────────────────────────────────────────────────────────────

class TestAwsInfraFixes:
    def test_append_dimensions_fix_removes_key(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-AWS-INF-001", label="InstanceId"))
        assert "append_dimensions" in enriched.remediation.code_after

    def test_namespace_fix_suggests_static(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-AWS-INF-002", label=None, snippet="MyApp/${ENV_NAME}"))
        assert "static" in enriched.remediation.code_after or "Production" in enriched.remediation.code_after


# ─────────────────────────────────────────────────────────────────────
# Edge cases and immutability
# ─────────────────────────────────────────────────────────────────────

class TestEdgeCases:
    def test_unknown_rule_id_does_not_crash(self) -> None:
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding(rule_id="MG-UNKNOWN-999"))
        assert enriched.remediation is not None
        assert enriched.remediation.code_after is not None

    def test_existing_complete_fix_is_not_overwritten(self) -> None:
        """If scanner already provided both code_before and code_after, engine respects them."""
        existing_fix = RemediationSuggestion(
            description="Scanner-provided fix",
            code_before="# scanner before",
            code_after="# scanner after",
        )
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-001", existing_remediation=existing_fix))
        assert enriched.remediation.code_before == "# scanner before"
        assert enriched.remediation.code_after == "# scanner after"

    def test_existing_partial_fix_is_enriched(self) -> None:
        """If scanner provided only description (no code), engine fills in the code."""
        partial_fix = RemediationSuggestion(
            description="Scanner description only",
            # code_before / code_after are None
        )
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-001", existing_remediation=partial_fix))
        # Engine should fill in the code
        assert enriched.remediation.code_after is not None
        # But should preserve scanner's description
        assert enriched.remediation.description == "Scanner description only"

    def test_original_finding_not_mutated(self) -> None:
        engine = RemediationEngine()
        original = _make_finding("MG-PY-001", label="user_id")
        enriched = engine.enrich(original)
        assert original.remediation is None
        assert enriched is not original
        assert enriched.remediation is not None

    def test_description_generated_when_none(self) -> None:
        """Default description is generated when finding has no remediation at all."""
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-001", label="session_id"))
        assert enriched.remediation.description
        assert "session_id" in enriched.remediation.description

    def test_none_label_does_not_crash(self) -> None:
        """Finding with no label_or_tag_name is handled gracefully."""
        engine = RemediationEngine()
        enriched = engine.enrich(_make_finding("MG-PY-001", label=None))
        assert enriched.remediation is not None
