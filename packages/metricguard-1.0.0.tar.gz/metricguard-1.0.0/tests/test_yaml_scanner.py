"""
MetricGuard Test Suite — YAML Scanner Tests.

Tests for the YAML infrastructure scanner covering:
  - Prometheus relabel_config dangerous source_labels.
  - Prometheus dangerous target_label names.
  - labelmap action with wildcard regexes.
  - OpenTelemetry unsafe attribute processor actions.
  - OpenTelemetry spanmetrics unbounded dimensions.
  - Generic dangerous label key detection.
  - Safe YAML configurations that should produce no findings.
"""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from metricguard.core.config import MetricGuardConfig
from metricguard.models.finding import Finding, Severity
from metricguard.scanners.yaml_scanner import YamlScanner


def _scanner() -> YamlScanner:
    return YamlScanner(MetricGuardConfig.default())


def _scan_yaml(source: str, tmp_path: Path) -> list[Finding]:
    f = tmp_path / "config.yml"
    f.write_text(textwrap.dedent(source))
    return _scanner().scan_file(f, f.read_text())


class TestPrometheusRelabel:
    """Prometheus relabel_config dangerous patterns."""

    def test_detects_dangerous_source_label(self, tmp_path: Path) -> None:
        source = """
        scrape_configs:
          - job_name: myapp
            relabel_configs:
              - source_labels: [http_url]
                target_label: path
                action: replace
        """
        findings = _scan_yaml(source, tmp_path)
        rule_ids = [f.rule_id for f in findings]
        assert "MG-YAML-002" in rule_ids

    def test_detects_dangerous_target_label(self, tmp_path: Path) -> None:
        source = """
        scrape_configs:
          - job_name: app
            relabel_configs:
              - source_labels: [__meta_kubernetes_pod_name]
                target_label: user_id
        """
        findings = _scan_yaml(source, tmp_path)
        critical = [f for f in findings if f.severity == Severity.CRITICAL]
        assert len(critical) > 0

    def test_detects_labelmap_wildcard(self, tmp_path: Path) -> None:
        source = """
        scrape_configs:
          - job_name: k8s
            relabel_configs:
              - action: labelmap
                regex: __meta_kubernetes_pod_label_(.*)
        """
        findings = _scan_yaml(source, tmp_path)
        rule_ids = [f.rule_id for f in findings]
        assert "MG-YAML-003" in rule_ids

    def test_safe_relabel_no_finding(self, tmp_path: Path) -> None:
        source = """
        scrape_configs:
          - job_name: safe_app
            relabel_configs:
              - source_labels: [__meta_kubernetes_namespace]
                target_label: namespace
                action: replace
        """
        findings = _scan_yaml(source, tmp_path)
        assert len(findings) == 0, f"Expected no findings for safe relabel, got {findings}"

    def test_metric_relabel_configs_also_scanned(self, tmp_path: Path) -> None:
        source = """
        scrape_configs:
          - job_name: metrics_job
            metric_relabel_configs:
              - source_labels: [http_url]
                target_label: url
        """
        findings = _scan_yaml(source, tmp_path)
        assert len(findings) > 0


class TestOtelProcessors:
    """OpenTelemetry collector processor analysis."""

    def test_detects_unsafe_attributes_insert(self, tmp_path: Path) -> None:
        source = """
        processors:
          attributes/add_user:
            actions:
              - key: user_id
                action: insert
                value: "from-context"
        """
        findings = _scan_yaml(source, tmp_path)
        rule_ids = [f.rule_id for f in findings]
        assert "MG-YAML-004" in rule_ids

    def test_detects_spanmetrics_unbounded_dimension(self, tmp_path: Path) -> None:
        source = """
        processors:
          spanmetrics:
            dimensions:
              - name: http.method
              - name: user_id
              - name: http.status_code
        """
        findings = _scan_yaml(source, tmp_path)
        rule_ids = [f.rule_id for f in findings]
        assert "MG-YAML-005" in rule_ids

    def test_safe_spanmetrics_no_finding(self, tmp_path: Path) -> None:
        source = """
        processors:
          spanmetrics:
            dimensions:
              - name: http.method
              - name: http.status_code
              - name: service.name
        """
        findings = _scan_yaml(source, tmp_path)
        assert len(findings) == 0, f"Expected no findings for safe dimensions, got {findings}"


class TestGenericLabelKeys:
    """Generic dangerous label key detection."""

    def test_detects_dangerous_key_in_labels_block(self, tmp_path: Path) -> None:
        # Include an OTel indicator so the Prometheus/OTel heuristic passes.
        # Generic label scanning requires the file to look like a monitoring config.
        source = """
        processors:
          noop: {}
        service:
          labels:
            user_id: some_value
            environment: production
        """
        findings = _scan_yaml(source, tmp_path)
        assert len(findings) > 0

    def test_safe_labels_no_finding(self, tmp_path: Path) -> None:
        # Include an OTel indicator so the Prometheus/OTel heuristic passes.
        source = """
        processors:
          noop: {}
        service:
          labels:
            app: myapp
            version: "1.2.3"
            environment: prod
        """
        findings = _scan_yaml(source, tmp_path)
        assert len(findings) == 0



class TestEdgeCases:
    """Edge cases for YAML scanner."""

    def test_empty_file_returns_empty(self, tmp_path: Path) -> None:
        f = tmp_path / "empty.yml"
        f.write_text("")
        findings = _scanner().scan_file(f, f.read_text())
        assert findings == []

    def test_non_dict_yaml_returns_empty(self, tmp_path: Path) -> None:
        f = tmp_path / "list.yml"
        f.write_text("- item1\n- item2\n")
        findings = _scanner().scan_file(f, f.read_text())
        assert findings == []

    def test_broken_yaml_returns_empty(self, tmp_path: Path) -> None:
        f = tmp_path / "broken.yml"
        f.write_text("key: {unclosed")
        findings = _scanner().scan_file(f, f.read_text())
        assert findings == []

    def test_deduplication(self, tmp_path: Path) -> None:
        """Same finding should not appear twice even if multiple rules match."""
        source = """
        scrape_configs:
          - job_name: app
            relabel_configs:
              - source_labels: [http_url]
                target_label: user_id
        """
        findings = _scan_yaml(source, tmp_path)
        fingerprints = [f.fingerprint for f in findings]
        assert len(fingerprints) == len(set(fingerprints)), "Duplicate findings detected"
