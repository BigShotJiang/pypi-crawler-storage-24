"""
Tests for the Telegraf/StatsD scanner.

Covers:
  - Telegraf TOML: [global_tags] dangerous keys / env-var interpolation (MG-TEL-INF-001)
  - Telegraf TOML: [[processors.regex]] dangerous result_key (MG-TEL-INF-002)
  - Python StatsD: dynamic tags list in statsd.increment() etc. (MG-STAT-PY-001)
"""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from metricguard.core.config import MetricGuardConfig
from metricguard.scanners.python_scanner import PythonScanner
from metricguard.scanners.telegraf_scanner import (
    RULE_STAT_PY_DYNAMIC_TAGS,
    RULE_TEL_INF_GLOBAL_TAGS,
    RULE_TEL_INF_REGEX_PROC,
    TelegrafScanner,
)


@pytest.fixture()
def config() -> MetricGuardConfig:
    return MetricGuardConfig.default()


@pytest.fixture()
def scanner(config: MetricGuardConfig) -> TelegrafScanner:
    return TelegrafScanner(config)


@pytest.fixture()
def py_scanner(config: MetricGuardConfig) -> PythonScanner:
    return PythonScanner(config)


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────


def _write_conf(tmp_path: Path, content: str) -> Path:
    p = tmp_path / "telegraf.conf"
    p.write_text(textwrap.dedent(content))
    return p


def _write_py(tmp_path: Path, code: str) -> Path:
    p = tmp_path / "test_statsd.py"
    p.write_text(textwrap.dedent(code))
    return p


# ─────────────────────────────────────────────────────────────────────
# MG-TEL-INF-001: [global_tags] dangerous keys
# ─────────────────────────────────────────────────────────────────────


class TestGlobalTags:
    def test_env_var_interpolation_flagged(
        self, scanner: TelegrafScanner, tmp_path: Path
    ) -> None:
        """Shell variable interpolation in global_tags → MG-TEL-INF-001."""
        conf = """
            [global_tags]
              region = "us-east-1"
              pod_id = "${POD_UID}"
        """
        fp = _write_conf(tmp_path, conf)
        findings = scanner.scan_file(fp, fp.read_text())
        flagged = [f for f in findings if f.rule_id == RULE_TEL_INF_GLOBAL_TAGS]
        assert len(flagged) == 1
        assert flagged[0].label_or_tag_name == "pod_id"

    def test_dangerous_keyword_key_flagged(
        self, scanner: TelegrafScanner, tmp_path: Path
    ) -> None:
        """Tag key matching 'user_id' → MG-TEL-INF-001 CRITICAL."""
        conf = """
            [global_tags]
              user_id = "some_static_value"
        """
        fp = _write_conf(tmp_path, conf)
        findings = scanner.scan_file(fp, fp.read_text())
        flagged = [f for f in findings if f.rule_id == RULE_TEL_INF_GLOBAL_TAGS]
        assert len(flagged) == 1
        from metricguard.models.finding import Severity
        assert flagged[0].severity == Severity.CRITICAL

    def test_static_bounded_tags_no_finding(
        self, scanner: TelegrafScanner, tmp_path: Path
    ) -> None:
        """Static, bounded global tags → no findings."""
        conf = """
            [global_tags]
              environment = "production"
              region = "us-east-1"
              team = "platform"
        """
        fp = _write_conf(tmp_path, conf)
        findings = scanner.scan_file(fp, fp.read_text())
        flagged = [f for f in findings if f.rule_id == RULE_TEL_INF_GLOBAL_TAGS]
        assert flagged == []

    def test_empty_global_tags_no_finding(
        self, scanner: TelegrafScanner, tmp_path: Path
    ) -> None:
        """Empty [global_tags] block → no findings."""
        conf = """
            [global_tags]

            [[inputs.cpu]]
              percpu = true
        """
        fp = _write_conf(tmp_path, conf)
        findings = scanner.scan_file(fp, fp.read_text())
        assert findings == []

    def test_dollar_without_braces_flagged(
        self, scanner: TelegrafScanner, tmp_path: Path
    ) -> None:
        """$VAR (without braces) is also flagged as dynamic interpolation."""
        conf = """
            [global_tags]
              deployment_id = "$DEPLOYMENT_ID"
        """
        fp = _write_conf(tmp_path, conf)
        findings = scanner.scan_file(fp, fp.read_text())
        flagged = [f for f in findings if f.rule_id == RULE_TEL_INF_GLOBAL_TAGS]
        assert len(flagged) == 1


# ─────────────────────────────────────────────────────────────────────
# MG-TEL-INF-002: [[processors.regex]] dangerous result_key
# ─────────────────────────────────────────────────────────────────────


class TestRegexProcessors:
    def test_regex_processor_dangerous_result_key(
        self, scanner: TelegrafScanner, tmp_path: Path
    ) -> None:
        """Regex processor result_key 'user_id' → MG-TEL-INF-002."""
        conf = """
            [[processors.regex]]
              [[processors.regex.fields]]
                key = "url"
                pattern = "/users/(?P<user_id>[^/]+)"
                result_key = "user_id"
        """
        fp = _write_conf(tmp_path, conf)
        findings = scanner.scan_file(fp, fp.read_text())
        flagged = [f for f in findings if f.rule_id == RULE_TEL_INF_REGEX_PROC]
        assert len(flagged) == 1
        assert "user_id" in flagged[0].label_or_tag_name

    def test_regex_processor_safe_result_key(
        self, scanner: TelegrafScanner, tmp_path: Path
    ) -> None:
        """Regex processor result_key 'http_method' (bounded) → no finding."""
        conf = """
            [[processors.regex]]
              [[processors.regex.fields]]
                key = "url"
                pattern = "^(?P<http_method>GET|POST|PUT|DELETE)"
                result_key = "http_method"
        """
        fp = _write_conf(tmp_path, conf)
        findings = scanner.scan_file(fp, fp.read_text())
        flagged = [f for f in findings if f.rule_id == RULE_TEL_INF_REGEX_PROC]
        assert flagged == []

    def test_broken_toml_returns_empty(
        self, scanner: TelegrafScanner, tmp_path: Path
    ) -> None:
        """Malformed TOML → empty findings, no exception."""
        fp = tmp_path / "telegraf.conf"
        fp.write_text("[broken toml !! = not valid")
        findings = scanner.scan_file(fp, fp.read_text())
        assert findings == []


# ─────────────────────────────────────────────────────────────────────
# MG-STAT-PY-001: StatsD/DogStatsD tags list (via PythonScanner)
# ─────────────────────────────────────────────────────────────────────


class TestStatsdTagsRule:
    def test_dynamic_fstring_tag_flagged(
        self, py_scanner: PythonScanner, tmp_path: Path
    ) -> None:
        """F-string tag element → MG-STAT-PY-001."""
        code = """
            user_id = get_current_user()
            statsd.increment('api.requests', tags=[f'user:{user_id}', 'env:prod'])
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        stat_findings = [f for f in findings if f.rule_id == RULE_STAT_PY_DYNAMIC_TAGS]
        assert len(stat_findings) >= 1

    def test_variable_tag_element_flagged(
        self, py_scanner: PythonScanner, tmp_path: Path
    ) -> None:
        """Variable name as tag element → MG-STAT-PY-001."""
        code = """
            user_tag = build_user_tag(request)
            statsd.gauge('queue.depth', 42, tags=[user_tag, 'region:us-east-1'])
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        stat_findings = [f for f in findings if f.rule_id == RULE_STAT_PY_DYNAMIC_TAGS]
        assert len(stat_findings) >= 1

    def test_all_constant_tags_safe(
        self, py_scanner: PythonScanner, tmp_path: Path
    ) -> None:
        """All-constant tags list → no MG-STAT-PY-001 finding."""
        code = """
            statsd.increment('api.requests', tags=['env:prod', 'region:us-east-1', 'service:api'])
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        stat_findings = [f for f in findings if f.rule_id == RULE_STAT_PY_DYNAMIC_TAGS]
        assert stat_findings == []

    def test_dogstatsd_also_detected(
        self, py_scanner: PythonScanner, tmp_path: Path
    ) -> None:
        """DogStatsd client name variant is detected."""
        code = """
            request_id = request.headers.get('X-Request-ID')
            dogstatsd.histogram('response.time', duration, tags=[f'request:{request_id}'])
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        stat_findings = [f for f in findings if f.rule_id == RULE_STAT_PY_DYNAMIC_TAGS]
        assert len(stat_findings) >= 1

    def test_variable_tags_list_flagged(
        self, py_scanner: PythonScanner, tmp_path: Path
    ) -> None:
        """Variable passed as entire tags arg (not a list literal) → flagged."""
        code = """
            def track_request(method, tags):
                statsd.increment('requests', tags=tags)
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        stat_findings = [f for f in findings if f.rule_id == RULE_STAT_PY_DYNAMIC_TAGS]
        assert len(stat_findings) >= 1

    def test_non_statsd_client_not_flagged(
        self, py_scanner: PythonScanner, tmp_path: Path
    ) -> None:
        """Non-statsd object method call is not flagged (avoids false positives)."""
        code = """
            # 'database' is not a statsd client name
            database.increment('counter', tags=['env:prod'])
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        stat_findings = [f for f in findings if f.rule_id == RULE_STAT_PY_DYNAMIC_TAGS]
        # The object name "database" doesn't match any statsd client pattern
        assert stat_findings == []
