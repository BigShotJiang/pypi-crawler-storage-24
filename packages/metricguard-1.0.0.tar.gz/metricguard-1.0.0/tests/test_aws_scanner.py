"""
Tests for the AWS CloudWatch scanner.

Covers:
  - Python SDK: boto3 put_metric_data() Dimensions (MG-AWS-PY-001)
  - Infrastructure JSON: append_dimensions dangerous keys (MG-AWS-INF-001)
  - Infrastructure JSON: dynamic namespace interpolation (MG-AWS-INF-002)
"""
from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from metricguard.core.config import MetricGuardConfig
from metricguard.scanners.aws_scanner import (
    RULE_AWS_INF_APPEND_DIM,
    RULE_AWS_INF_NAMESPACE,
    RULE_AWS_PY_DYNAMIC_DIM,
    AwsScanner,
)
from metricguard.scanners.python_scanner import PythonScanner


@pytest.fixture()
def config() -> MetricGuardConfig:
    return MetricGuardConfig.default()


@pytest.fixture()
def scanner(config: MetricGuardConfig) -> AwsScanner:
    return AwsScanner(config)


@pytest.fixture()
def py_scanner(config: MetricGuardConfig) -> PythonScanner:
    return PythonScanner(config)


# ─────────────────────────────────────────────────────────────────────
# Fixtures: temporary file helpers
# ─────────────────────────────────────────────────────────────────────


def _write_py(tmp_path: Path, code: str) -> Path:
    p = tmp_path / "test_aws.py"
    p.write_text(textwrap.dedent(code))
    return p


def _write_json(tmp_path: Path, data: dict, name: str = "amazon-cloudwatch-agent.json") -> Path:
    p = tmp_path / name
    p.write_text(json.dumps(data, indent=2))
    return p


# ─────────────────────────────────────────────────────────────────────
# MG-AWS-PY-001: boto3 Python SDK rule (via PythonScanner second pass)
# ─────────────────────────────────────────────────────────────────────


class TestAwsPythonRule:
    def test_dynamic_dimension_value_flagged(self, py_scanner: PythonScanner, tmp_path: Path) -> None:
        """Dynamic variable as Dimension.Value → MG-AWS-PY-001."""
        code = """
            user_id = get_user_from_request()
            cloudwatch.put_metric_data(
                Namespace='MyApp',
                MetricData=[{
                    'MetricName': 'PageViews',
                    'Dimensions': [{'Name': 'UserId', 'Value': user_id}],
                    'Value': 1.0,
                }]
            )
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        aws_findings = [f for f in findings if f.rule_id == RULE_AWS_PY_DYNAMIC_DIM]
        assert len(aws_findings) >= 1
        assert aws_findings[0].label_or_tag_name == "UserId"

    def test_constant_dimension_value_safe(self, py_scanner: PythonScanner, tmp_path: Path) -> None:
        """Constant string as Dimension.Value → no MG-AWS-PY-001 finding."""
        code = """
            cloudwatch.put_metric_data(
                Namespace='MyApp',
                MetricData=[{
                    'MetricName': 'PageViews',
                    'Dimensions': [{'Name': 'Environment', 'Value': 'production'}],
                    'Value': 1.0,
                }]
            )
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        aws_findings = [f for f in findings if f.rule_id == RULE_AWS_PY_DYNAMIC_DIM]
        assert aws_findings == []

    def test_fstring_dimension_value_flagged(self, py_scanner: PythonScanner, tmp_path: Path) -> None:
        """F-string as Dimension.Value → MG-AWS-PY-001."""
        code = """
            env = 'prod'
            cloudwatch.put_metric_data(
                Namespace='MyApp',
                MetricData=[{
                    'Dimensions': [{'Name': 'RequestId', 'Value': f'req-{request_id}'}],
                    'Value': 1.0,
                }]
            )
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        aws_findings = [f for f in findings if f.rule_id == RULE_AWS_PY_DYNAMIC_DIM]
        assert len(aws_findings) >= 1

    def test_multiple_dimensions_detects_all_dynamic(
        self, py_scanner: PythonScanner, tmp_path: Path
    ) -> None:
        """Multiple Dimensions — only dynamic Values are flagged."""
        code = """
            cloudwatch.put_metric_data(
                Namespace='MyApp',
                MetricData=[{
                    'Dimensions': [
                        {'Name': 'Env', 'Value': 'production'},   # constant — safe
                        {'Name': 'UserId', 'Value': get_user()},  # dynamic — flagged
                    ],
                    'Value': 1.0,
                }]
            )
        """
        fp = _write_py(tmp_path, code)
        findings = py_scanner.scan_file(fp, fp.read_text())
        aws_findings = [f for f in findings if f.rule_id == RULE_AWS_PY_DYNAMIC_DIM]
        assert len(aws_findings) == 1
        assert aws_findings[0].label_or_tag_name == "UserId"


# ─────────────────────────────────────────────────────────────────────
# MG-AWS-INF-001: CloudWatch Agent JSON — append_dimensions
# ─────────────────────────────────────────────────────────────────────


class TestAwsInfraAppendDimensions:
    def test_instance_id_in_append_dimensions_flagged(
        self, scanner: AwsScanner, tmp_path: Path
    ) -> None:
        """InstanceId in append_dimensions → MG-AWS-INF-001."""
        data = {
            "metrics": {
                "append_dimensions": {
                    "InstanceId": "${aws:InstanceId}",
                    "Region": "us-east-1",
                }
            }
        }
        fp = _write_json(tmp_path, data)
        findings = scanner.scan_file(fp, fp.read_text())
        inf_findings = [f for f in findings if f.rule_id == RULE_AWS_INF_APPEND_DIM]
        assert len(inf_findings) >= 1
        assert any(f.label_or_tag_name == "InstanceId" for f in inf_findings)

    def test_dangerous_keyword_dimension_flagged(
        self, scanner: AwsScanner, tmp_path: Path
    ) -> None:
        """user_id in append_dimensions → MG-AWS-INF-001 CRITICAL."""
        data = {
            "metrics": {
                "append_dimensions": {
                    "user_id": "${USER_ID}",
                }
            }
        }
        fp = _write_json(tmp_path, data)
        findings = scanner.scan_file(fp, fp.read_text())
        inf_findings = [f for f in findings if f.rule_id == RULE_AWS_INF_APPEND_DIM]
        assert len(inf_findings) == 1
        from metricguard.models.finding import Severity
        assert inf_findings[0].severity == Severity.CRITICAL

    def test_safe_static_dimensions_no_finding(
        self, scanner: AwsScanner, tmp_path: Path
    ) -> None:
        """Static dimension keys with bounded values → no finding."""
        data = {
            "metrics": {
                "append_dimensions": {
                    "Environment": "production",
                    "Region": "us-east-1",
                }
            }
        }
        fp = _write_json(tmp_path, data)
        findings = scanner.scan_file(fp, fp.read_text())
        inf_findings = [f for f in findings if f.rule_id == RULE_AWS_INF_APPEND_DIM]
        assert inf_findings == []

    def test_non_cloudwatch_json_ignored(
        self, scanner: AwsScanner, tmp_path: Path
    ) -> None:
        """Generic JSON file (not matching filename pattern) is not scanned."""
        data = {"append_dimensions": {"user_id": "dynamic"}}
        fp = _write_json(tmp_path, data, name="package.json")
        findings = scanner.scan_file(fp, fp.read_text())
        assert findings == []


# ─────────────────────────────────────────────────────────────────────
# MG-AWS-INF-002: Dynamic namespace interpolation
# ─────────────────────────────────────────────────────────────────────


class TestAwsInfraNamespace:
    def test_dynamic_namespace_interpolation_flagged(
        self, scanner: AwsScanner, tmp_path: Path
    ) -> None:
        """Namespace with ${VAR} → MG-AWS-INF-002."""
        data = {
            "metrics": {
                "Namespace": "MyApp/${ENV_NAME}",
                "metrics_collected": {}
            }
        }
        fp = _write_json(tmp_path, data)
        findings = scanner.scan_file(fp, fp.read_text())
        ns_findings = [f for f in findings if f.rule_id == RULE_AWS_INF_NAMESPACE]
        assert len(ns_findings) == 1
        assert "MyApp/${ENV_NAME}" in ns_findings[0].message

    def test_static_namespace_safe(
        self, scanner: AwsScanner, tmp_path: Path
    ) -> None:
        """Static namespace string → no MG-AWS-INF-002 finding."""
        data = {
            "metrics": {
                "Namespace": "MyApp/Production",
                "metrics_collected": {}
            }
        }
        fp = _write_json(tmp_path, data)
        findings = scanner.scan_file(fp, fp.read_text())
        ns_findings = [f for f in findings if f.rule_id == RULE_AWS_INF_NAMESPACE]
        assert ns_findings == []

    def test_broken_json_returns_empty(
        self, scanner: AwsScanner, tmp_path: Path
    ) -> None:
        """Malformed JSON → empty findings, no exception."""
        fp = tmp_path / "amazon-cloudwatch-agent.json"
        fp.write_text("{ broken json: !!! }")
        findings = scanner.scan_file(fp, fp.read_text())
        assert findings == []
