"""
MetricGuard v1.0.0 — Enterprise-grade, multi-language Shift-Left FinOps engine.

Prevents metric cardinality explosion in Prometheus, Datadog, and OpenTelemetry
by analysing Python (AST + taint), Go, TypeScript, and Java (Semgrep) source
code and infrastructure configs before they reach production.
"""

__version__ = "1.0.0"
__author__ = "Yossi Cohen"
__email__ = "Yossi85291@gmail.com"
__github__ = "https://github.com/Yossi-Cohen19/"
__linkedin__ = "https://www.linkedin.com/in/yossi-cohen-b302b0372"
__license__ = "MIT"
