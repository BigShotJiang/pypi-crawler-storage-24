"""
MetricGuard Configuration Management.

Handles loading, validation, and defaulting of the `metricguard.yml`
configuration file. Organizations use this file to customize scanner
behavior, suppress false positives, and define their own high-risk
monitoring wrapper functions.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, model_validator

logger = logging.getLogger(__name__)

# ────────────────────────────────────────────────────────────────
# Short / ambiguous keywords that need CamelCase-aware regex.
# A simple word-boundary regex fails for camelCase identifiers:
#   e.g. \bip\b would NOT match 'clientIp' (capital 'I' precedes
#   'p'), so we use a 3-arm pattern instead:
#     ^kw$        — exact match ('ip')
#     _kw$        — snake_case suffix ('client_ip')
#     Kw$         — CamelCase suffix ('clientIp')
# ────────────────────────────────────────────────────────────────
_SHORT_KEYWORDS: frozenset[str] = frozenset(
    {
        "id",
        "ip",
        "mac",
        "url",
        "uri",
        "port",
        "host",
        "hash",
        "sku",
    }
)


def _build_short_keyword_pattern(kw: str) -> re.Pattern[str]:
    """
    Build a regex pattern for a short / ambiguous keyword that
    correctly handles both snake_case and camelCase contexts.

    The three arms (case-insensitive on exact and snake forms;
    capitalized on the CamelCase arm):

    Example for ``kw='ip'``:

    .. code-block:: text

        (?:^ip$|_ip$|Ip$)

    Matches: ``ip``, ``client_ip``, ``clientIp``.
    Does NOT match: ``clientip``, ``scripted``, ``strip``.

    Args:
        kw: Lowercase short keyword string.

    Returns:
        Compiled regex pattern.
    """
    cap = kw[0].upper() + kw[1:]  # e.g. 'ip' → 'Ip'
    # Pattern reads: exact-whole OR snake-suffix OR CamelCase-suffix
    return re.compile(
        rf"(?:^{re.escape(kw)}$|_{re.escape(kw)}$|{re.escape(cap)}$)", re.IGNORECASE
    )


# ────────────────────────────────────────────────────────────────
# Default dangerous keywords for label/tag/attribute values.
# Rule: any variable/key whose name matches one of these is
# flagged because its VALUE is almost always unbounded at scale.
# Teams may EXTEND (not replace) this list via metricguard.yml.
# ────────────────────────────────────────────────────────────────
_DEFAULT_DANGEROUS_KEYWORDS: list[str] = [
    # ── Identity / auth ─────────────────────────────────────────
    "user_id",  # 1 series per registered user
    "userid",
    "user_name",  # unbounded usernames
    "username",
    "email",  # PII + O(users) cardinality
    "phone",  # PII + O(users)
    "token",  # short-lived auth tokens change per request
    "api_key",  # unique per integration
    "password",  # should never appear, but flag if it does
    # ── Request / tracing ────────────────────────────────────────
    "request_id",  # 1 series per HTTP request worldwide
    "requestid",
    "req_id",
    "trace_id",  # 1 series per distributed trace
    "traceid",
    "span_id",  # 1 series per span — even worse than trace_id
    "spanid",
    "correlation_id",  # cross-service request correlation
    "idempotency_key",  # client-generated unique key per retry
    # ── Session ──────────────────────────────────────────────────
    "session_id",  # 1 series per browser/mobile session
    "sessionid",
    # ── Generic identifiers ──────────────────────────────────────
    "uuid",  # by definition unbounded
    "guid",
    "id",  # bare 'id' is almost always a row key
    "hash",  # commit hashes, content hashes — unbounded
    # ── Network ──────────────────────────────────────────────────
    "ip_address",  # O(Internet) cardinality
    "ip",
    "src_ip",
    "dst_ip",
    "source_ip",
    "client_ip",
    "remote_addr",
    "port",  # ephemeral client ports are unbounded (0-65535)
    "src_port",
    "dst_port",
    "user_agent",  # every browser version is a new series
    # ── B2B SaaS / multi-tenancy ─────────────────────────────────
    "tenant_id",  # O(customers) — death in SaaS
    "tenantid",
    "account_id",  # billing account — same risk as tenant_id
    "accountid",
    "client_id",  # OAuth client or B2B customer
    "clientid",
    "organization_id",  # org-level partitioning
    "org_id",
    "workspace_id",  # Slack/Notion/Jira style multi-tenancy
    "company_id",
    # ── E-commerce / billing ─────────────────────────────────────
    "customer_id",  # 1 series per paying customer
    "order_id",  # 1 series per order worldwide
    "transaction_id",  # 1 series per payment attempt
    "payment_id",  # downstream payment processor ID
    "invoice_id",  # billing cycles × customers
    "subscription_id",  # SaaS subscription handle
    "cart_id",  # abandoned cart tracking
    "product_id",  # may be large catalog
    "sku",  # stock-keeping units — unbounded in retail
    "coupon_code",  # campaign codes multiply quickly
    # ── Cloud / infrastructure ───────────────────────────────────
    "device_id",  # IoT: potentially millions of devices
    "deviceid",
    "instance_id",  # EC2/GCE/Azure VM — changes on every restart
    "pod_name",  # K8s pods are ephemeral; names encode random suffix
    "pod_id",
    "container_id",  # Docker container ID is a 64-char hash
    "node_name",  # cluster nodes change during scaling events
    "host",  # hostname — changes per pod restart
    "hostname",
    # ── Messaging / queues ───────────────────────────────────────
    "message_id",  # 1 series per message published
    "event_id",  # event-sourcing events — high-frequency unique IDs
    "job_id",  # background job handle
    "task_id",  # async task handle
    "queue_name",  # may be dynamically generated per-consumer
    "consumer_group",  # Kafka consumer groups can proliferate
    # ── CI/CD & Git ──────────────────────────────────────────────
    "commit_hash",  # O(commits-per-day) — very fast accumulation
    "commit_sha",
    "build_id",  # 1 series per CI build run
    "run_id",  # GitHub Actions run ID is a 10-digit integer
    "pipeline_id",  # GitLab/Buildkite pipeline
    "deployment_id",  # ArgoCD/Flux deployment revision
    "release_id",  # rolling release identifiers
    "version",  # SemVer is bounded, but raw git tags/hashes aren't
    # ── URLs / paths (common mistake) ───────────────────────────
    "url",  # full URL — query string makes it unbounded
    "path",  # raw URL path without route normalization
    "endpoint",  # sometimes used for raw paths, not route templates
    "uri",
    "route",  # raw router match — may include param values
]

# ──────────────────────────────────────────────
# Default high-cardinality monitoring functions
# ──────────────────────────────────────────────
_DEFAULT_MONITORED_FUNCTIONS: list[str] = [
    # Prometheus client_python
    "Counter",
    "Gauge",
    "Histogram",
    "Summary",
    "labels",
    "inc",
    "observe",
    # Datadog
    "statsd.increment",
    "statsd.gauge",
    "statsd.histogram",
    "statsd.distribution",
    "DogStatsd.increment",
    "DogStatsd.gauge",
    # OpenTelemetry
    "set_attribute",
    "set_attributes",
    # Generic wrappers
    "track_event",
    "emit_metric",
    "report_metric",
    # ── Cloud SDK additions ───────────────────────────────────
    # AWS boto3 CloudWatch
    "put_metric_data",
    # Google Cloud Monitoring
    "create_time_series",
    # Azure Monitor / Application Insights
    "track_metric",
    "track_event",
]

# ────────────────────────────────────────────────────────────────
# Default dangerous YAML label keys.
# Used by YamlScanner and OTel processor checks.
# ────────────────────────────────────────────────────────────────
_DEFAULT_DANGEROUS_YAML_KEYS: list[str] = [
    # Identity
    "user_id",
    "userid",
    "user_name",
    "username",
    "email",
    "phone",
    # Request / tracing
    "request_id",
    "requestid",
    "req_id",
    "trace_id",
    "traceid",
    "span_id",
    "spanid",
    "correlation_id",
    "idempotency_key",
    # Session
    "session_id",
    "sessionid",
    # Generic identifiers
    "uuid",
    "guid",
    "id",
    "hash",
    # Network
    "ip_address",
    "ip",
    "src_ip",
    "dst_ip",
    "client_ip",
    "remote_addr",
    "port",
    "src_port",
    "dst_port",
    "user_agent",
    # B2B SaaS
    "tenant_id",
    "tenantid",
    "account_id",
    "accountid",
    "client_id",
    "clientid",
    "organization_id",
    "org_id",
    "workspace_id",
    # E-commerce
    "customer_id",
    "order_id",
    "transaction_id",
    "payment_id",
    "invoice_id",
    "subscription_id",
    "product_id",
    "sku",
    # Cloud / infra
    "device_id",
    "deviceid",
    "instance_id",
    "pod_name",
    "pod_id",
    "container_id",
    "node_name",
    "host",
    "hostname",
    # Messaging
    "message_id",
    "event_id",
    "job_id",
    "task_id",
    "queue_name",
    # CI/CD
    "commit_hash",
    "commit_sha",
    "build_id",
    "run_id",
    "pipeline_id",
    "deployment_id",
    "release_id",
    # URLs
    "url",
    "path",
    "endpoint",
    "uri",
    "route",
]

_DEFAULT_DANGEROUS_RELABEL_ACTIONS: list[str] = [
    "replace",
    "labelmap",
]

_DEFAULT_DANGEROUS_SOURCE_LABELS: list[str] = [
    # ── Kubernetes pod metadata ──────────────────────────────────
    # Pod UIDs and IPs change on every restart — never use as metric labels
    "__meta_kubernetes_pod_uid",
    "__meta_kubernetes_pod_ip",
    "__meta_kubernetes_pod_name",
    "__meta_kubernetes_pod_label_user_id",
    "__meta_kubernetes_pod_label_request_id",
    "__meta_kubernetes_pod_label_session_id",
    "__meta_kubernetes_pod_annotation_trace",
    # Container IDs are 64-char hashes — instant cardinality bomb
    "__meta_kubernetes_container_id",
    # Per-node labels that change during cluster scaling
    "__meta_kubernetes_node_name",
    # ── AWS EC2 / ECS metadata ───────────────────────────────────
    "__meta_ec2_instance_id",  # EC2 instance ID — changes on every launch
    "__meta_ec2_private_ip",  # internal IP — changes with instance
    "__meta_ecs_task_arn",  # ECS task ARN encodes a random UUID segment
    "__meta_ec2_tag_Name",  # EC2 Name tag can be user-supplied string
    # ── GCP / GKE metadata ──────────────────────────────────────
    "__meta_gce_instance_id",  # GCP compute instance numeric ID
    "__meta_gce_private_ip",
    # ── HTTP / application metadata ─────────────────────────────
    "http_url",  # full URL including query string
    "http_target",  # raw path — needs route normalization
    "http_route",  # sometimes carries path params verbatim
    "url",
    "path",
    "endpoint",
    # ── Request / tracing ────────────────────────────────────────
    "request_id",
    "trace_id",
    "span_id",
    "correlation_id",
    # ── Identity ─────────────────────────────────────────────────
    "user_id",
    "user_agent",  # every browser/version/OS combination is a new series
    "client_ip",
    "remote_addr",
]


# ────────────────────────────────────────────────────────────────
# Default dangerous AWS CloudWatch dimension keys.
# Flagged in boto3.put_metric_data() and CloudWatch agent configs.
# ────────────────────────────────────────────────────────────────
_DEFAULT_DANGEROUS_DIMENSION_KEYS: list[str] = [
    # Identity / auth
    "user_id",
    "userid",
    "user_name",
    "email",
    # Request / tracing
    "request_id",
    "trace_id",
    "span_id",
    "correlation_id",
    # Session
    "session_id",
    "sessionid",
    # Generic
    "uuid",
    "guid",
    # Network
    "ip_address",
    "ip",
    "client_ip",
    "port",
    "user_agent",
    # B2B SaaS
    "tenant_id",
    "account_id",
    "client_id",
    "org_id",
    "workspace_id",
    # E-commerce
    "customer_id",
    "order_id",
    "transaction_id",
    "payment_id",
    "invoice_id",
    "subscription_id",
    # Cloud / infra — AWS-specific
    "InstanceId",  # EC2 instance — the most common CloudWatch explosion
    "TaskId",  # ECS task ID
    "ContainerId",  # ECS container ID
    "instance_id",
    "device_id",
    "pod_name",
    "container_id",
    # URLs
    "url",
    "path",
    "endpoint",
    # Messaging
    "message_id",
    "event_id",
    "job_id",
    "task_id",
    # CI/CD
    "build_id",
    "run_id",
    "commit_hash",
    "commit_sha",
    "deployment_id",
]

# ────────────────────────────────────────────────────────────────
# Default dangerous Telegraf global_tag keys and StatsD tag names.
# Dynamic values in [global_tags] are injected into EVERY metric
# emitted by that agent — one bad tag multiplies all series by N.
# ────────────────────────────────────────────────────────────────
_DEFAULT_DANGEROUS_TELEGRAF_KEYS: list[str] = [
    # Identity
    "user_id",
    "userid",
    "email",
    "user_name",
    # Request / tracing
    "request_id",
    "trace_id",
    "span_id",
    "correlation_id",
    # Session
    "session_id",
    # Network — per-connection values
    "ip",
    "ip_address",
    "client_ip",
    "remote_addr",
    "port",
    "user_agent",
    # B2B SaaS
    "tenant_id",
    "account_id",
    "client_id",
    "org_id",
    # Cloud / infra
    "instance_id",  # EC2/GCE instance ID changes per restart
    "pod_name",  # K8s pod name carries random suffix
    "container_id",  # 64-char Docker hash
    "device_id",  # IoT device identifiers
    "host",  # dynamic hostname per pod restart
    "hostname",
    "node_name",  # K8s node name — changes during cluster scaling
    # Messaging
    "message_id",
    "event_id",
    "job_id",
    "task_id",
    # CI/CD
    "build_id",
    "run_id",
    "commit_hash",
    "commit_sha",
    "deployment_id",
    # URLs
    "url",
    "path",
    "endpoint",
]


# ────────────────────────────────────────────────────────────────
# "Black hole" directory names pruned unconditionally during
# os.walk traversal.  MetricGuard never stats files inside these
# trees.  Hidden dirs (names starting with ".") are handled by a
# separate dot-prefix rule in cli.py.
#
# Categories:
#   Test/mock  – tests, test, testdata, testing, spec, specs,
#                __tests__, __mocks__, fixtures, mock, mocks,
#                e2e, integration
#   Dependency – node_modules, vendor, venv, env, .venv
#   Build/dist – build, dist, out, target, bin, obj, __pycache__
# ────────────────────────────────────────────────────────────────
_DEFAULT_IGNORED_DIRS: list[str] = [
    # ── Test / mock / fixture ────────────────────────────────────
    "test",
    "tests",
    "testdata",
    "testing",
    "spec",
    "specs",
    "__tests__",
    "__mocks__",
    "fixtures",
    "mock",
    "mocks",
    "e2e",
    "integration",
    # ── Dependency trees ─────────────────────────────────────────
    "node_modules",  # npm / yarn / pnpm
    "vendor",  # Go modules, PHP Composer, Ruby Bundler
    "venv",  # Python virtualenv (non-hidden)
    "env",  # Python virtualenv (non-hidden)
    # ── Build / distribution artifacts ───────────────────────────
    "build",
    "dist",
    "out",
    "target",  # Rust / Maven / Gradle output
    "bin",
    "obj",  # .NET build objects
    "__pycache__",  # Python bytecode
]

# ────────────────────────────────────────────────────────────────
# File-name glob patterns evaluated with fnmatch against the
# filename only (not the full path).  Covers two categories:
#
#   Test files – co-located test files outside test directories
#                (e.g. Go *_test.go next to production code).
#   Non-code   – lock files, auto-generated assets, docs.
#                These add I/O overhead with zero analysis value.
# ────────────────────────────────────────────────────────────────
_DEFAULT_IGNORED_FILE_PATTERNS: list[str] = [
    # ── Co-located test files ────────────────────────────────────
    "test_*.py",  # Python: pytest-style
    "*_test.py",  # Python: unittest-style
    "*_test.go",  # Go: standard _test.go convention
    "*.spec.ts",  # TypeScript: Jest / Vitest
    "*.test.ts",  # TypeScript: Jest
    "*.spec.js",  # JavaScript: Jest / Mocha
    "*.test.js",  # JavaScript: Jest
    "*.spec.jsx",  # React: component spec files
    "*.test.jsx",  # React: component test files
    "*.spec.tsx",  # React+TS: component spec files
    "*.test.tsx",  # React+TS: component test files
    # ── Lock files (auto-generated, not source code) ─────────────
    "*lock.json",  # package-lock.json, yarn.lock.json
    "*.lock",  # Pipfile.lock, Cargo.lock, poetry.lock
    "go.sum",  # Go module checksums
    # ── Non-code assets ──────────────────────────────────────────
    "*.md",  # Markdown documentation
    "*.csv",  # Data files
    "*.txt",  # Plain text
    "*.png",  # Images
    "*.jpg",  # Images
    "LICENSE",  # License file (exact name)
    "LICENSE.*",  # LICENSE.txt, LICENSE.md, etc.
]


class PythonScannerConfig(BaseModel):
    """Configuration specific to the Python AST scanner."""

    monitored_functions: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_MONITORED_FUNCTIONS),
        description="List of function/method names to treat as monitoring API calls.",
    )
    dangerous_keywords: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_DANGEROUS_KEYWORDS),
        description="Variable name substrings that indicate high cardinality.",
    )
    enable_taint_analysis: bool = Field(
        default=True,
        description="Whether to perform inter-statement taint tracking.",
    )


class AwsScannerConfig(BaseModel):
    """Configuration for the AWS CloudWatch infrastructure scanner."""

    dangerous_dimension_keys: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_DANGEROUS_DIMENSION_KEYS),
        description="Dimension key names in CloudWatch configs that indicate high cardinality.",
    )
    cloudwatch_agent_filename_patterns: list[str] = Field(
        default=[
            "amazon-cloudwatch-agent.json",
            "cloudwatch-agent*.json",
            "cwa-config*.json",
        ],
        description="Glob patterns matching CloudWatch Agent JSON config files.",
    )
    flag_instance_id: bool = Field(
        default=True,
        description="Flag InstanceId in append_dimensions (creates per-instance series at scale).",
    )


class TelegrafScannerConfig(BaseModel):
    """Configuration for the Telegraf TOML infrastructure scanner."""

    dangerous_global_tag_keys: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_DANGEROUS_TELEGRAF_KEYS),
        description="Keys in [global_tags] that carry high-cardinality data.",
    )
    flag_env_var_interpolation: bool = Field(
        default=True,
        description="Flag global tags whose values are shell variable interpolations (${...}).",
    )
    dangerous_regex_result_keys: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_DANGEROUS_TELEGRAF_KEYS),
        description="If a regex processor writes to one of these keys, flag it as dangerous.",
    )


class YamlScannerConfig(BaseModel):
    """Configuration specific to the YAML infrastructure scanner."""

    dangerous_label_keys: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_DANGEROUS_YAML_KEYS),
        description="Label/tag keys known to carry high-cardinality data.",
    )
    dangerous_relabel_actions: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_DANGEROUS_RELABEL_ACTIONS),
        description="relabel_config actions that can introduce cardinality.",
    )
    dangerous_source_labels: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_DANGEROUS_SOURCE_LABELS),
        description="Prometheus source_labels values considered high-cardinality.",
    )


class MetricGuardConfig(BaseModel):
    """
    Top-level MetricGuard configuration model.

    Loaded from `metricguard.yml` at the repository root (or a custom path).
    Unknown keys in the YAML file are silently ignored to maintain forward
    compatibility as new options are added.

    Attributes:
        version: Config schema version for future migration support.
        ignored_paths: Glob patterns for paths to skip during scanning.
        python: Python-specific scanner configuration.
        yaml: YAML-specific scanner configuration.
        fail_on_severity: Minimum severity that causes a non-zero CLI exit.
        max_findings: Abort after this many total findings (0 = unlimited).
    """

    version: str = Field(default="1", description="Config schema version.")
    ignored_paths: list[str] = Field(
        default_factory=lambda: [
            "**/.git/**",
            "**/node_modules/**",
            "**/vendor/**",
            "**/__pycache__/**",
            "**/.venv/**",
            "**/venv/**",
            "**/dist/**",
            "**/build/**",
        ],
        description="Glob patterns for paths/directories to skip.",
    )
    ignored_dirs: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_IGNORED_DIRS),
        description=(
            "Directory names (case-insensitive) to skip entirely during traversal. "
            "Applied via in-place os.walk pruning so their contents are never read. "
            "Extend via 'extend_ignored_dirs' in metricguard.yml."
        ),
    )
    ignored_file_patterns: list[str] = Field(
        default_factory=lambda: list(_DEFAULT_IGNORED_FILE_PATTERNS),
        description=(
            "fnmatch glob patterns matched against filenames (not full paths). "
            "Files whose names match are skipped even outside test directories. "
            "Extend via 'extend_ignored_file_patterns' in metricguard.yml."
        ),
    )
    python: PythonScannerConfig = Field(
        default_factory=PythonScannerConfig,
        description="Python scanner settings.",
    )
    yaml: YamlScannerConfig = Field(
        default_factory=YamlScannerConfig,
        description="YAML scanner settings.",
    )
    aws: AwsScannerConfig = Field(
        default_factory=AwsScannerConfig,
        description="AWS CloudWatch scanner settings.",
    )
    telegraf: TelegrafScannerConfig = Field(
        default_factory=TelegrafScannerConfig,
        description="Telegraf TOML scanner settings.",
    )
    fail_on_severity: str = Field(
        default="high",
        description="Minimum severity level that triggers a non-zero exit code.",
    )
    max_findings: int = Field(
        default=0,
        ge=0,
        description="Maximum findings before aborting (0 = unlimited).",
    )

    @model_validator(mode="before")
    @classmethod
    def _merge_defaults(cls, values: Any) -> Any:
        """
        Allow extending the default lists via ``extend_`` prefixed keys.

        This lets organizations add entries to built-in lists WITHOUT
        replacing the defaults:

        .. code-block:: yaml

            # metricguard.yml
            extend_ignored_dirs:
              - "vendor_tests"
              - "bench"
            extend_ignored_file_patterns:
              - "*_bench_test.go"

            python:
              extend_dangerous_keywords:
                - "tenant_slug"
        """
        if not isinstance(values, dict):
            return values

        # Support extend_ pattern for top-level ignored_dirs and ignored_file_patterns
        for field_name in ["ignored_dirs", "ignored_file_patterns"]:
            extend_key = f"extend_{field_name}"
            if extend_key in values:
                existing = values.get(field_name, [])
                values[field_name] = existing + values.pop(extend_key)

        # Support extend_ pattern for python section
        py = values.get("python", {})
        if isinstance(py, dict):
            for field_name in ["monitored_functions", "dangerous_keywords"]:
                extend_key = f"extend_{field_name}"
                if extend_key in py:
                    existing = py.get(field_name, [])
                    py[field_name] = existing + py.pop(extend_key)

        return values

    @classmethod
    def from_file(cls, config_path: Path) -> MetricGuardConfig:
        """
        Load and validate a MetricGuard config from a YAML file.

        Falls back gracefully to all defaults if the file is missing or
        malformed, logging a warning instead of raising an exception.
        This ensures MetricGuard never blocks CI due to a config error.

        Args:
            config_path: Path to the `metricguard.yml` file.

        Returns:
            A fully validated MetricGuardConfig instance.
        """
        if not config_path.exists():
            logger.debug(
                "No metricguard.yml found at %s — using default configuration.",
                config_path,
            )
            return cls()

        try:
            with config_path.open("r", encoding="utf-8") as fh:
                raw: dict[str, Any] = yaml.safe_load(fh) or {}
            config = cls.model_validate(raw)
            logger.info("Loaded MetricGuard config from %s", config_path)
            return config
        except (yaml.YAMLError, ValueError) as exc:
            logger.warning(
                "Failed to parse metricguard.yml (%s) — falling back to defaults.",
                exc,
            )
            return cls()

    @classmethod
    def default(cls) -> MetricGuardConfig:
        """Return a default configuration with all built-in settings."""
        return cls()
