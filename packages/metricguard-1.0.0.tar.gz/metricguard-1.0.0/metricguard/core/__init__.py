"""Core abstractions and base classes for MetricGuard."""

from metricguard.core.config import MetricGuardConfig
from metricguard.core.scanner import BaseScanner, ScanResult

__all__ = ["BaseScanner", "ScanResult", "MetricGuardConfig"]
