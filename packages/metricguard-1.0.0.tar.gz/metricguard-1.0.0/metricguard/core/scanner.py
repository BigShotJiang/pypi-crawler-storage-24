"""
MetricGuard Abstract Base Scanner.

Defines the Strategy Pattern interface that all concrete language scanners
must implement. This abstraction enables the CLI to orchestrate heterogeneous
scanners (Python AST, YAML, future Go/Java) through a single unified API,
while each scanner encapsulates language-specific parsing and analysis logic.

Design Principles:
    - Open/Closed: New scanner languages can be added without modifying the CLI.
    - Single Responsibility: Each scanner owns only parsing + analysis for its
      target language/format; reporting is handled by dedicated reporter classes.
    - Liskov Substitution: Any BaseScanner subclass is fully interchangeable
      in the scanning pipeline.
"""

from __future__ import annotations

import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

from metricguard.core.config import MetricGuardConfig
from metricguard.models.finding import Finding

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────
# Inline suppression patterns (M1)
# ─────────────────────────────────────────────────────────────────────
# Matches:
#   # metricguard:ignore
#   # metricguard:ignore-cardinality
#   # noqa                       ← bare noqa silences everything
#   # noqa: MG-PY-001            ← rule-specific noqa
#   # noqa: MG-PY-001, MG-PY-002 ← multi-rule noqa

_MG_IGNORE_RE = re.compile(r"#\s*metricguard\s*:\s*ignore", re.IGNORECASE)
_NOQA_RE = re.compile(r"#\s*noqa(?:\s*:\s*([A-Z0-9\-,\s]+))?", re.IGNORECASE)


def _line_suppresses(line: str, rule_id: str) -> bool:
    """Return True if *line* contains a suppression comment for *rule_id*."""
    # metricguard:ignore (any variant) always suppresses
    if _MG_IGNORE_RE.search(line):
        return True

    m = _NOQA_RE.search(line)
    if m:
        codes_str = m.group(1)
        if codes_str is None:
            # bare `# noqa` — silences all rules
            return True
        # rule-specific: `# noqa: MG-PY-001, MG-PY-002`
        codes = [c.strip() for c in codes_str.split(",")]
        if rule_id in codes:
            return True

    return False


def _is_suppressed(source_lines: list[str], line_no: int, rule_id: str) -> bool:
    """
    Return True if a finding at *line_no* (1-indexed) is suppressed.

    Checks the flagged line itself **and** the line directly above it so
    that engineers can place suppression comments on a preceding line when
    the method chaining prevents inline placement:

        # metricguard:ignore
        counter.labels(user_id=user_id).inc()

    Args:
        source_lines: Full list of source lines (0-indexed).
        line_no:      1-indexed line number of the finding.
        rule_id:      Rule ID of the finding (e.g., "MG-PY-001").

    Returns:
        True if the finding should be dropped from the output.
    """
    # Check the flagged line
    if 0 < line_no <= len(source_lines):
        if _line_suppresses(source_lines[line_no - 1], rule_id):
            return True

    # Check the line directly above
    if line_no > 1 and (line_no - 1) <= len(source_lines):
        if _line_suppresses(source_lines[line_no - 2], rule_id):
            return True

    return False


@dataclass
class ScanResult:
    """
    The result of scanning a single file.

    Wraps the list of findings with metadata about the scan itself.
    A scan can succeed with zero findings, succeed with findings, or
    fail with an error (e.g., the file was unparseable). Separating
    the error state from findings allows the pipeline to continue
    scanning other files even if one file fails.

    Attributes:
        file_path: Path to the scanned file.
        findings: All cardinality issues discovered in this file.
        scan_error: Description of any fatal error during scanning (or None).
        lines_analyzed: Total lines of source code analyzed.
        scan_duration_ms: Time taken to scan this file in milliseconds.
    """

    file_path: Path
    findings: list[Finding] = field(default_factory=list)
    scan_error: str | None = None
    lines_analyzed: int = 0
    scan_duration_ms: float = 0.0

    @property
    def succeeded(self) -> bool:
        """True if the scan completed without a fatal error."""
        return self.scan_error is None

    @property
    def finding_count(self) -> int:
        """Total number of findings in this scan result."""
        return len(self.findings)

    @property
    def critical_count(self) -> int:
        """Number of CRITICAL-severity findings."""
        from metricguard.models.finding import Severity

        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)


class BaseScanner(ABC):
    """
    Abstract base class for all MetricGuard file scanners.

    Concrete implementations must override `supported_extensions` to declare
    which file types they handle, and `scan_file` to perform the actual
    language-specific analysis.

    The `can_scan` method uses `supported_extensions` to allow the CLI to
    dispatch files to the correct scanner without any explicit mapping.

    Usage:
        scanner = PythonScanner(config)
        result = scanner.scan(Path("myapp/metrics.py"))
    """

    def __init__(self, config: MetricGuardConfig) -> None:
        """
        Initialize the scanner with the active MetricGuard configuration.

        Args:
            config: Validated MetricGuardConfig with organization-specific
                    settings for dangerous keywords, ignored paths, etc.
        """
        self.config = config
        self._logger = logging.getLogger(self.__class__.__name__)

    @property
    @abstractmethod
    def supported_extensions(self) -> frozenset[str]:
        """
        Return the set of file extensions this scanner handles.

        Extensions should be lowercase and include the leading dot
        (e.g., {'.py', '.pyw'}).

        Returns:
            A frozenset of lowercase extension strings.
        """
        ...

    @property
    @abstractmethod
    def scanner_name(self) -> str:
        """
        A short, human-readable name for this scanner (e.g., 'PythonAST').

        Used in log messages and scan result metadata.
        """
        ...

    @abstractmethod
    def scan_file(self, file_path: Path, source: str) -> list[Finding]:
        """
        Perform static analysis on a single file and return all findings.

        The ``source`` argument is the **pre-read file content** — the
        caller (``scan()``) reads the file exactly once and passes it here
        so that each concrete scanner does not need to open the file again.
        This eliminates the double-read that previously occurred between
        ``scan()`` and every ``scan_file()`` implementation.

        Implementations must:
          - Return an empty list (not raise) if no issues are found.
          - Raise exceptions only for truly unexpected errors; expected
            parse errors should be caught and logged internally.
          - Never modify the file; this is strictly read-only analysis.

        Args:
            file_path: Absolute path to the file (keep for Finding metadata).
            source:    Full UTF-8 text content of the file (already read).

        Returns:
            A list of Finding objects representing cardinality vulnerabilities.

        Raises:
            Any unexpected exception can bubble up; the public ``scan`` method
            wraps this in a fault-tolerant try/except.
        """
        ...

    def can_scan(self, file_path: Path) -> bool:
        """
        Determine if this scanner is capable of analyzing the given file.

        Checks the file extension against `supported_extensions`. Does NOT
        check if the file exists; callers are responsible for file existence.

        Args:
            file_path: Path to the candidate file.

        Returns:
            True if the file extension matches this scanner's supported types.
        """
        return file_path.suffix.lower() in self.supported_extensions

    def scan(self, file_path: Path) -> ScanResult:
        """
        Fault-tolerant entry point for scanning a single file.

        Reads the file **once**, passes the source text to ``scan_file``, then
        filters out any findings suppressed via inline comments (``# noqa`` or
        ``# metricguard:ignore``).  Timing, logging, and error handling wrap
        the whole operation so that one malformed file cannot abort a
        50k-file monorepo scan.

        Args:
            file_path: Absolute path to the file to scan.

        Returns:
            A ScanResult containing all findings and metadata about the scan.
        """
        import time

        start = time.monotonic()
        result = ScanResult(file_path=file_path)

        if not file_path.exists():
            result.scan_error = f"File not found: {file_path}"
            self._logger.warning("Skipping missing file: %s", file_path)
            return result

        if not file_path.is_file():
            result.scan_error = f"Path is not a regular file: {file_path}"
            return result

        try:
            # ── B5: Read exactly once ──────────────────────────────
            source = file_path.read_text(encoding="utf-8", errors="replace")
            source_lines = source.splitlines()
            result.lines_analyzed = len(source_lines) or 1

            # Pass pre-read source to scanner implementation
            raw_findings = self.scan_file(file_path, source)

            # ── M1: Filter inline-suppressed findings ──────────────
            result.findings = [
                f
                for f in raw_findings
                if not _is_suppressed(source_lines, f.line_number, f.rule_id)
            ]

            suppressed_count = len(raw_findings) - len(result.findings)
            if suppressed_count:
                self._logger.debug(
                    "[%s] %s → %d suppressed by inline comment(s)",
                    self.scanner_name,
                    file_path,
                    suppressed_count,
                )

            self._logger.debug(
                "[%s] %s → %d finding(s) (%d suppressed)",
                self.scanner_name,
                file_path,
                result.finding_count,
                suppressed_count,
            )
        except MemoryError:
            result.scan_error = f"File too large to analyze: {file_path}"
            self._logger.error("MemoryError scanning %s — skipping.", file_path)
        except Exception as exc:  # noqa: BLE001
            result.scan_error = f"{type(exc).__name__}: {exc}"
            self._logger.warning(
                "Unexpected error scanning %s: %s",
                file_path,
                exc,
                exc_info=True,
            )
        finally:
            elapsed_ms = (time.monotonic() - start) * 1000
            result.scan_duration_ms = elapsed_ms

        return result
