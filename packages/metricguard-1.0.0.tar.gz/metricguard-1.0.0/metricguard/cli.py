"""
MetricGuard CLI — Main Entry Point.

The command-line interface for MetricGuard, designed to run as a high-performance
standalone tool and as a GitHub Action. Provides:

  - Parallel file scanning using `concurrent.futures.ProcessPoolExecutor` for
    true CPU-level parallelism (critical for large monorepos).
  - Multiple output formats: human-readable table, JSON, SARIF.
  - Differential scanning via `--diff` flag (only scan Git-changed files).
  - Configurable severity thresholds for CI pass/fail gates.
  - Rich colored terminal output with finding summaries.

Exit Codes:
    0 — No findings at or above fail_on_severity.
    1 — One or more findings at or above fail_on_severity.
    2 — CLI usage error (invalid arguments).
    3 — Internal error (unexpected exception during scan).

Usage:
    # Scan an entire directory
    metricguard scan ./src

    # Scan only files changed vs. main (PR mode)
    metricguard scan ./src --diff origin/main

    # Export SARIF for GitHub Code Scanning
    metricguard scan ./src --format sarif --output results.sarif

    # Use custom config, fail only on CRITICAL
    metricguard scan ./src --config ./metricguard.yml --fail-on critical
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from collections.abc import Iterator
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

# ─────────────────────────────────────────────────────────────────────
# Lazy imports: keep startup fast; only import heavy deps when needed.
# ─────────────────────────────────────────────────────────────────────

# Enable color output on Windows + detect no-color environments
_USE_COLOR = (
    sys.stdout.isatty()
    and os.environ.get("NO_COLOR") is None
    and os.environ.get("TERM") != "dumb"
)

# ANSI color codes — only applied when _USE_COLOR is True
_C = {
    "reset": "\033[0m" if _USE_COLOR else "",
    "bold": "\033[1m" if _USE_COLOR else "",
    "red": "\033[91m" if _USE_COLOR else "",
    "yellow": "\033[93m" if _USE_COLOR else "",
    "green": "\033[92m" if _USE_COLOR else "",
    "cyan": "\033[96m" if _USE_COLOR else "",
    "dim": "\033[2m" if _USE_COLOR else "",
    "magenta": "\033[95m" if _USE_COLOR else "",
}

_SEVERITY_COLORS = {
    "critical": _C["red"] + _C["bold"],
    "high": _C["red"],
    "medium": _C["yellow"],
    "low": _C["cyan"],
    "info": _C["dim"],
}

_SEVERITY_ORDER = ["critical", "high", "medium", "low", "info"]

logger = logging.getLogger("metricguard")


# ─────────────────────────────────────────────────────────────────────
# File discovery helpers
# ─────────────────────────────────────────────────────────────────────


def _iter_files(
    paths: list[Path],
    extensions: frozenset[str],
    ignored_patterns: list[str],
    *,
    ignored_dirs: list[str] | None = None,
    ignored_file_patterns: list[str] | None = None,
) -> Iterator[Path]:
    """
    Lazily yield all files matching *extensions* from *paths*, applying a
    three-layer filter to eliminate test noise at minimal I/O cost.

    **Layer 1 — Directory pruning (fastest)**
        ``dirnames`` is modified in-place inside ``os.walk`` so the scanner
        never descends into directories whose *name* (case-insensitive) is in
        ``ignored_dirs``.  An entire ``tests/`` sub-tree with 5 000 files is
        skipped with a single string comparison.

    **Layer 2 — Filename pattern filtering**
        Each candidate filename is matched against ``ignored_file_patterns``
        via ``fnmatch``.  This catches co-located test files outside a test
        directory (Go ``*_test.go``, Jest ``*.test.ts``, etc.).

    **Layer 3 — Path glob filtering (legacy, backward-compat)**
        The existing ``ignored_patterns`` list is applied to the full path
        string and filename for any custom rules set via ``metricguard.yml``.

    Args:
        paths:                  File or directory paths to scan.
        extensions:             Lowercase file extensions to include.
        ignored_patterns:       Full-path glob patterns (legacy).
        ignored_dirs:           Directory names to prune (case-insensitive).
                                Defaults to config._DEFAULT_IGNORED_DIRS.
        ignored_file_patterns:  fnmatch patterns matched against filename only.
                                Defaults to config._DEFAULT_IGNORED_FILE_PATTERNS.

    Yields:
        Unique absolute file paths matching the criteria, in discovery order.
    """
    import fnmatch

    from metricguard.core.config import (
        _DEFAULT_IGNORED_DIRS,
        _DEFAULT_IGNORED_FILE_PATTERNS,
    )

    # Build lookup structures once — used in the hot path.
    _ign_dirs: frozenset[str] = frozenset(
        d.lower()
        for d in (ignored_dirs if ignored_dirs is not None else _DEFAULT_IGNORED_DIRS)
    )
    _ign_file_pats: list[str] = (
        ignored_file_patterns
        if ignored_file_patterns is not None
        else _DEFAULT_IGNORED_FILE_PATTERNS
    )

    # 1 MiB guard: files larger than this are almost certainly
    # auto-generated (proto bundles, compiled assets, data dumps)
    # and will cause AST/regex memory spikes with zero true-positive value.
    MAX_FILE_BYTES: int = 1_048_576

    seen: set[Path] = set()

    def is_path_ignored(p: Path) -> bool:
        """Layer 3: full-path glob matching (legacy ignored_patterns)."""
        rel = str(p)
        for pattern in ignored_patterns:
            if fnmatch.fnmatch(rel, pattern):
                return True
            if fnmatch.fnmatch(p.name, pattern):
                return True
        return False

    def is_filename_ignored(fname: str) -> bool:
        """Layer 2: filename-only fnmatch against test-file patterns."""
        for pattern in _ign_file_pats:
            if fnmatch.fnmatch(fname, pattern):
                return True
        return False

    for base_path in paths:
        base_path = base_path.resolve()

        if base_path.is_file():
            if (
                base_path.suffix.lower() in extensions
                and not is_filename_ignored(base_path.name)
                and not is_path_ignored(base_path)
            ):
                if base_path not in seen:
                    seen.add(base_path)
                    yield base_path
        elif base_path.is_dir():
            # followlinks=False (default, made explicit) prevents the traversal
            # from following symlinks into circular directory structures that exist
            # in some monorepos and container overlay filesystems.
            for dirpath_str, dirnames, filenames in os.walk(
                base_path, followlinks=False
            ):
                dirpath = Path(dirpath_str)

                # Layer 1: in-place pruning — os.walk skips these sub-trees entirely.
                #   • dot-prefix rule: prune ALL hidden directories (.git, .github,
                #     .vscode, .idea, .mypy_cache, etc.) without maintaining an
                #     explicit list.
                #   • _ign_dirs: test dirs + dependency dirs + build artifact dirs.
                #   • is_path_ignored: legacy full-path glob patterns.
                dirnames[:] = [
                    d
                    for d in dirnames
                    if not d.startswith(".")  # hidden dirs (dot-prefix)
                    and d.lower() not in _ign_dirs  # test / dep / build dirs
                    and not is_path_ignored(dirpath / d)
                ]

                for fname in filenames:
                    # Layer 2: filename pattern check (catches co-located tests)
                    if is_filename_ignored(fname):
                        continue
                    file_path = dirpath / fname
                    # Layer 3: full-path glob check
                    if file_path.suffix.lower() in extensions and not is_path_ignored(
                        file_path
                    ):
                        resolved = file_path.resolve()
                        if resolved not in seen:
                            # OOM guard: skip files larger than 1 MiB.
                            # Auto-generated files (proto bundles, minified JS,
                            # compiled assets) can exhaust the AST parser's memory.
                            try:
                                if os.path.getsize(resolved) > MAX_FILE_BYTES:
                                    logger.debug(
                                        "Skipping oversized file (%d bytes): %s",
                                        os.path.getsize(resolved),
                                        resolved,
                                    )
                                    continue
                            except OSError:
                                continue
                            seen.add(resolved)
                            yield resolved
        else:
            logger.warning("Path does not exist: %s", base_path)


# ─────────────────────────────────────────────────────────────────────
# Worker function for parallel scanning (must be module-level for pickle)
# ─────────────────────────────────────────────────────────────────────


def _scan_file_worker(args: tuple[Any, ...]) -> dict[str, Any]:
    """
    Top-level worker function for ProcessPoolExecutor.

    Must be a module-level function (not a closure or lambda) so it can
    be pickled for multiprocessing. Accepts and returns JSON-serializable
    types to avoid cross-process serialization issues with Pydantic models.

    Args:
        args: Tuple of (file_path_str, scanner_type, config_dict).

    Returns:
        A dict with keys: 'file_path', 'findings', 'error', 'lines', 'duration_ms'.
    """
    file_path_str, scanner_type, config_dict = args

    try:
        from metricguard.core.config import MetricGuardConfig
        from metricguard.scanners.aws_scanner import AwsScanner
        from metricguard.scanners.python_scanner import PythonScanner
        from metricguard.scanners.semgrep_scanner import SemgrepScanner
        from metricguard.scanners.telegraf_scanner import TelegrafScanner
        from metricguard.scanners.yaml_scanner import YamlScanner

        config = MetricGuardConfig.model_validate(config_dict)
        file_path = Path(file_path_str)

        # Registry: scanner_type (str key) → scanner class
        # New scanners are added here only — no other CLI code changes needed.
        scanner_map = {
            "python": PythonScanner,
            "yaml": YamlScanner,
            "aws": AwsScanner,
            "telegraf": TelegrafScanner,
            "semgrep": SemgrepScanner,
        }
        scanner_cls = scanner_map.get(scanner_type)
        if not scanner_cls:
            return {
                "file_path": file_path_str,
                "findings": [],
                "error": f"Unknown scanner: {scanner_type}",
                "lines": 0,
                "duration_ms": 0.0,
            }

        scanner = scanner_cls(config)  # type: ignore[abstract]
        result = scanner.scan(file_path)

        return {
            "file_path": file_path_str,
            "findings": [f.model_dump(mode="json") for f in result.findings],
            "error": result.scan_error,
            "lines": result.lines_analyzed,
            "duration_ms": result.scan_duration_ms,
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "file_path": file_path_str,
            "findings": [],
            "error": f"Worker exception: {exc}",
            "lines": 0,
            "duration_ms": 0.0,
        }


# ─────────────────────────────────────────────────────────────────────
# Output formatters
# ─────────────────────────────────────────────────────────────────────


def _print_finding_table(findings: list[Any], base_path: Path | None = None) -> None:
    """Print findings as a formatted, colored table to stdout."""
    from metricguard.models.finding import Finding

    if not findings:
        _print_success("✅ No cardinality violations detected.")
        return

    # Group by file
    by_file: dict[str, list[Finding]] = {}
    for f in findings:
        by_file.setdefault(f.file_path, []).append(f)

    for file_path, file_findings in sorted(by_file.items()):
        # Display relative path if possible
        display_path = file_path
        if base_path:
            try:
                display_path = str(Path(file_path).relative_to(base_path))
            except ValueError:
                pass

        print(f"\n{_C['bold']}{_C['cyan']}📄 {display_path}{_C['reset']}")
        print("─" * 80)

        for finding in sorted(file_findings, key=lambda f: f.line_number):
            sev_color = _SEVERITY_COLORS.get(finding.severity.value, "")
            sev_badge = f"{sev_color}[{finding.severity.value.upper():8}]{_C['reset']}"
            loc = f"{_C['dim']}line {finding.line_number:4d}{_C['reset']}"
            rule = f"{_C['magenta']}{finding.rule_id}{_C['reset']}"
            msg = finding.message

            print(f"  {sev_badge} {loc}  {rule}")
            print(f"    {msg}")

            if finding.offending_code_snippet:
                print(
                    f"    {_C['dim']}  ▸ {finding.offending_code_snippet}{_C['reset']}"
                )

            if finding.remediation and finding.remediation.description:
                print(
                    f"    {_C['green']}  💡 {finding.remediation.description}{_C['reset']}"
                )

            if finding.economic_impact:
                cost_str = ""
                if finding.economic_impact.estimated_monthly_cost_usd:
                    cost_str = f" (~${finding.economic_impact.estimated_monthly_cost_usd:.0f}/mo)"
                print(
                    f"    {_C['yellow']}  📈 ~{finding.economic_impact.estimated_series_increase:,} series increase{cost_str}{_C['reset']}"
                )

            if finding.is_false_positive_candidate:
                print(
                    f"    {_C['dim']}  ⚠️  Possible false positive — review recommended{_C['reset']}"
                )

            print()


def _print_summary(
    findings: list[Any], errors: list[str], total_files: int, duration_s: float
) -> None:
    """Print a scan summary table."""

    counts: dict[str, int] = {s: 0 for s in _SEVERITY_ORDER}
    for f in findings:
        counts[f.severity.value] += 1

    print("\n" + "═" * 80)
    print(f"{_C['bold']}  📊 MetricGuard Scan Summary{_C['reset']}")
    print("═" * 80)
    print(f"  Files scanned  : {_C['bold']}{total_files:,}{_C['reset']}")
    print(f"  Scan duration  : {_C['bold']}{duration_s:.2f}s{_C['reset']}")
    print(f"  Total findings : {_C['bold']}{len(findings):,}{_C['reset']}")
    print(f"  Scan errors    : {_C['yellow']}{len(errors):,}{_C['reset']}")
    print()

    for sev in _SEVERITY_ORDER:
        cnt = counts[sev]
        color = _SEVERITY_COLORS.get(sev, "")
        print(f"    {color}{sev.upper():8}{_C['reset']} : {cnt}")

    if errors:
        print(
            f"\n{_C['yellow']}  Scan errors (files that could not be analyzed):{_C['reset']}"
        )
        for err in errors[:5]:
            print(f"    • {err}")
        if len(errors) > 5:
            print(f"    ... and {len(errors)-5} more")

    print("═" * 80)


def _print_success(msg: str) -> None:
    print(f"{_C['green']}{msg}{_C['reset']}")


def _print_error(msg: str) -> None:
    print(f"{_C['red']}❌ {msg}{_C['reset']}", file=sys.stderr)


# ─────────────────────────────────────────────────────────────────────
# Baseline helpers (M2)
# ─────────────────────────────────────────────────────────────────────


def _load_baseline(path: Path) -> set[str]:
    """
    Load a MetricGuard baseline file and return a set of fingerprints.

    Returns an empty set on any parse/IO failure so that a corrupt
    baseline never blocks the scanner entirely.
    """
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or "fingerprints" not in data:
            logger.warning("Baseline file %s has unexpected format — ignoring.", path)
            return set()
        return set(data["fingerprints"])
    except FileNotFoundError:
        logger.warning("Baseline file not found: %s", path)
        return set()
    except Exception as exc:
        logger.warning("Failed to load baseline %s: %s", path, exc)
        return set()


def _save_baseline(path: Path, findings: list[Any]) -> None:
    """
    Persist current findings as a baseline file.

    The file stores a list of finding fingerprints so that subsequent
    scans can identify which findings are *new* vs. existing debt.
    """
    fingerprints = sorted({f.fingerprint for f in findings if f.fingerprint})
    data = {
        "metricguard_baseline": True,
        "fingerprint_count": len(fingerprints),
        "fingerprints": fingerprints,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ─────────────────────────────────────────────────────────────────────
# Core scan orchestration
# ─────────────────────────────────────────────────────────────────────


def run_scan(
    scan_paths: list[Path],
    config_path: Path | None,
    diff_base: str | None,
    output_format: str,
    output_file: Path | None,
    fail_on: str | None,
    workers: int,
    verbose: bool,
    baseline_path: Path | None = None,
    create_baseline: bool = False,
) -> int:
    """
    Orchestrate a full MetricGuard scan.

    This is the core scan pipeline:
      1. Load configuration.
      2. Collect files (full dir scan or diff-filtered).
      3. Dispatch to parallel workers.
      4. Aggregate results.
      5. Output in requested format.
      6. Return exit code based on severity threshold.

    Args:
        scan_paths: List of paths (files or directories) to scan.
        config_path: Optional path to metricguard.yml.
        diff_base: If set, only scan files changed vs. this Git ref.
        output_format: 'table', 'json', or 'sarif'.
        output_file: Optional file path to write output to.
        fail_on: Minimum severity for non-zero exit ('critical', 'high', etc.).
        workers: Number of parallel worker processes.
        verbose: Enable debug logging.

    Returns:
        Exit code (0 = clean, 1 = findings above threshold, 3 = error).
    """
    import time

    from metricguard.core.config import MetricGuardConfig
    from metricguard.engines.impact_calculator import ImpactCalculator
    from metricguard.engines.remediation_engine import RemediationEngine
    from metricguard.models.finding import Finding, Severity
    from metricguard.reporters.sarif_exporter import SarifExporter
    from metricguard.scanners.aws_scanner import AwsScanner
    from metricguard.scanners.python_scanner import PythonScanner
    from metricguard.scanners.semgrep_scanner import SemgrepScanner
    from metricguard.scanners.telegraf_scanner import TelegrafScanner
    from metricguard.scanners.yaml_scanner import YamlScanner

    start_time = time.monotonic()

    # ── Step 1: Load configuration ──────────────────────────────────
    resolved_config_path = config_path or (
        scan_paths[0] / "metricguard.yml" if scan_paths else Path("metricguard.yml")
    )
    config = MetricGuardConfig.from_file(resolved_config_path)

    # Effective fail_on severity
    effective_fail_on = fail_on or config.fail_on_severity
    try:
        fail_severity = Severity(effective_fail_on.lower())
    except ValueError:
        _print_error(
            f"Invalid --fail-on severity: '{effective_fail_on}'. Valid: {[s.value for s in Severity]}"
        )
        return 2

    # ── Step 2: Determine which files to scan ───────────────────────
    # Registered scanner instances — add new scanners here ONLY
    all_scanners = [
        PythonScanner(config),
        YamlScanner(config),
        AwsScanner(config),
        TelegrafScanner(config),
        SemgrepScanner(config),
    ]

    # Build a deduplicated union of all handled extensions
    all_extensions: frozenset[str] = frozenset(
        ext for scanner in all_scanners for ext in scanner.supported_extensions
    )

    # Build extension → scanner type key for worker dispatch
    # When multiple scanners handle the same extension (e.g., .py for both
    # PythonScanner and TelegrafScanner), we store all type keys so the
    # work_items list below can dispatch to each scanner independently.
    ext_to_scanner_types: dict[str, list[str]] = {}
    scanner_type_map = {
        PythonScanner: "python",
        YamlScanner: "yaml",
        AwsScanner: "aws",
        TelegrafScanner: "telegraf",
        SemgrepScanner: "semgrep",
    }
    for scanner in all_scanners:
        stype = scanner_type_map[type(scanner)]
        for ext in scanner.supported_extensions:
            ext_to_scanner_types.setdefault(ext, []).append(stype)

    if diff_base:
        from metricguard.utils.git_diff import GitDiffUtil

        repo_root = scan_paths[0] if scan_paths else Path(".")
        diff_util = GitDiffUtil(repo_root.resolve())
        if not diff_util.is_git_repo():
            logger.warning(
                "--diff specified but '%s' is not a Git repo. Falling back to full scan.",
                repo_root,
            )
            files_iter = _iter_files(
                scan_paths,
                all_extensions,
                config.ignored_paths,
                ignored_dirs=config.ignored_dirs,
                ignored_file_patterns=config.ignored_file_patterns,
            )
        else:
            diff_files = diff_util.get_changed_files(
                base_ref=diff_base, extensions=set(all_extensions)
            )
            logger.info(
                "Differential scan: %d changed files vs. '%s'",
                len(diff_files),
                diff_base,
            )
            files_iter = (
                f for f in sorted(diff_files) if f.suffix.lower() in all_extensions
            )
    else:
        files_iter = _iter_files(
            scan_paths,
            all_extensions,
            config.ignored_paths,
            ignored_dirs=config.ignored_dirs,
            ignored_file_patterns=config.ignored_file_patterns,
        )

    # Materialise the iterator once — required to know count for progress output
    # and to feed into the parallel executor below. For most repos this is fine;
    # for very large monorepos consider streaming directly into the executor.
    files_to_scan = list(files_iter)

    if not files_to_scan:
        _print_success("✅ No files to scan.")
        return 0

    logger.info("Scanning %d files with %d worker(s)...", len(files_to_scan), workers)
    print(
        f"\n{_C['bold']}🔍 MetricGuard — Scanning {len(files_to_scan):,} files...{_C['reset']}\n"
    )

    # ── Step 3: Build work items — one item per (file, scanner) pair ─
    # A single .py file dispatches to both 'python' and 'telegraf' scanners;
    # a .json file dispatches to 'aws'; a .conf file dispatches to 'telegraf'.
    config_dict = config.model_dump(mode="json")
    work_items = []
    for fp in files_to_scan:
        ext = fp.suffix.lower()
        for stype in ext_to_scanner_types.get(ext, []):
            work_items.append((str(fp), stype, config_dict))

    # ── Step 4: Parallel scanning ────────────────────────────────────
    all_findings: list[Finding] = []
    scan_errors: list[str] = []

    effective_workers = min(workers, len(work_items))

    if effective_workers <= 1:
        # Single-threaded path (avoids ProcessPoolExecutor overhead for small scans)
        for item in work_items:
            raw_result = _scan_file_worker(item)
            _process_worker_result(
                raw_result, all_findings, scan_errors, config.max_findings
            )
    else:
        with ProcessPoolExecutor(max_workers=effective_workers) as pool:
            futures = {
                pool.submit(_scan_file_worker, item): item[0] for item in work_items
            }
            for future in as_completed(futures):
                raw_result = future.result()
                _process_worker_result(
                    raw_result, all_findings, scan_errors, config.max_findings
                )
                if config.max_findings > 0 and len(all_findings) >= config.max_findings:
                    logger.warning(
                        "max_findings limit (%d) reached — aborting additional files.",
                        config.max_findings,
                    )
                    pool.shutdown(wait=False, cancel_futures=True)
                    break

    duration_s = time.monotonic() - start_time

    # ── Step 5: Enrich all findings (B7: format-agnostic) ───────────
    # ImpactCalculator + RemediationEngine run for ALL output formats,
    # not just SARIF. Table and JSON output now show costs and fixes too.
    impact_calc = ImpactCalculator()
    remediation_eng = RemediationEngine()
    all_findings = [remediation_eng.enrich(impact_calc.enrich(f)) for f in all_findings]

    # ── Step 5a: Baseline filtering (M2) ────────────────────────────
    if create_baseline:
        target = baseline_path or Path("metricguard-baseline.json")
        _save_baseline(target, all_findings)
        print(
            f"{_C['green']}✅ Baseline saved to {target} ({len(all_findings)} findings).{_C['reset']}"
        )
        return 0

    if baseline_path:
        known_fingerprints = _load_baseline(baseline_path)
        before = len(all_findings)
        all_findings = [
            f
            for f in all_findings
            if not f.fingerprint or f.fingerprint not in known_fingerprints
        ]
        suppressed = before - len(all_findings)
        if suppressed:
            print(
                f"{_C['dim']}  ℹ︎  {suppressed} finding(s) suppressed by baseline "
                f"({baseline_path.name}).{_C['reset']}"
            )

    # ── Step 6: Output ───────────────────────────────────────────────
    repo_root = scan_paths[0].resolve() if scan_paths else Path(".").resolve()

    if output_format == "table":
        _print_finding_table(all_findings, base_path=repo_root)
        _print_summary(all_findings, scan_errors, len(files_to_scan), duration_s)

    elif output_format == "json":
        try:
            from importlib.metadata import version as _pkg_version

            _mg_version = _pkg_version("metricguard")
        except Exception:
            _mg_version = "1.0.0"
        output_data = {
            "metricguard_version": _mg_version,
            "summary": {
                "total_findings": len(all_findings),
                "files_scanned": len(files_to_scan),
                "duration_seconds": round(duration_s, 3),
            },
            "findings": [f.model_dump(mode="json") for f in all_findings],
            "errors": scan_errors,
        }
        json_output = json.dumps(output_data, indent=2)
        if output_file:
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_text(json_output, encoding="utf-8")
            print(f"JSON report written to: {output_file}")
        else:
            print(json_output)

    elif output_format == "sarif":
        exporter = SarifExporter(all_findings, base_path=repo_root)
        if output_file:
            exporter.export_to_file(output_file)
            print(f"SARIF report written to: {output_file}")
        else:
            print(exporter.export())

    # ── Step 7: Exit code determination ─────────────────────────────
    fail_sev_index = _SEVERITY_ORDER.index(fail_severity.value)
    for finding in all_findings:
        finding_sev_index = _SEVERITY_ORDER.index(finding.severity.value)
        if finding_sev_index <= fail_sev_index:
            if output_format == "table":
                print(
                    f"\n{_C['red']}{_C['bold']}❌ Build failed: findings at or above "
                    f"'{fail_severity.value}' severity detected.{_C['reset']}"
                )
            return 1

    if output_format == "table":
        _print_success(
            f"\n✅ No findings at or above '{fail_severity.value}' severity."
        )
    return 0


def _process_worker_result(
    raw_result: dict[str, Any],
    all_findings: list[Any],
    scan_errors: list[str],
    max_findings: int,
) -> None:
    """
    Process a raw worker result dict, deserializing findings and collecting errors.
    Modifies all_findings and scan_errors in place.
    """
    from metricguard.models.finding import Finding

    if raw_result.get("error"):
        scan_errors.append(f"{raw_result['file_path']}: {raw_result['error']}")
        logger.debug(
            "Scan error in %s: %s", raw_result["file_path"], raw_result["error"]
        )

    for raw_finding in raw_result.get("findings", []):
        try:
            all_findings.append(Finding.model_validate(raw_finding))
        except Exception as exc:
            logger.debug("Failed to deserialize finding: %s", exc)


# ─────────────────────────────────────────────────────────────────────
# CLI argument parsing
# ─────────────────────────────────────────────────────────────────────


def build_parser() -> argparse.ArgumentParser:
    """Build and return the MetricGuard CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="metricguard",
        description=(
            "MetricGuard — Shift-Left FinOps static analysis for cardinality explosion prevention.\n"
            "Analyzes Python code and infrastructure YAML configs for metrics that will explode\n"
            "cardinality in Prometheus, Datadog, or OpenTelemetry at scale."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  metricguard scan ./src\n"
            "  metricguard scan ./src --diff origin/main --format sarif --output results.sarif\n"
            "  metricguard scan ./src --fail-on critical --workers 8\n"
            "  metricguard scan ./infra --config ./metricguard.yml\n"
        ),
    )
    try:
        from importlib.metadata import version as _pkg_version

        _mg_ver = _pkg_version("metricguard")
    except Exception:
        _mg_ver = "1.0.0"
    parser.add_argument("--version", action="version", version=f"MetricGuard {_mg_ver}")

    subparsers = parser.add_subparsers(dest="command")

    # ── `scan` subcommand ────────────────────────────────────────────
    scan_parser = subparsers.add_parser(
        "scan", help="Scan files or directories for cardinality risks."
    )
    scan_parser.add_argument(
        "paths",
        nargs="+",
        type=Path,
        metavar="PATH",
        help="One or more files or directories to scan.",
    )
    scan_parser.add_argument(
        "--config",
        type=Path,
        default=None,
        metavar="PATH",
        help="Path to metricguard.yml config file (default: <first_scan_path>/metricguard.yml).",
    )
    scan_parser.add_argument(
        "--diff",
        type=str,
        default=None,
        metavar="BASE_REF",
        help=(
            "Only scan files changed vs. BASE_REF (e.g., 'origin/main', 'HEAD~1'). "
            "Requires the scan path to be a Git repository."
        ),
    )
    scan_parser.add_argument(
        "--format",
        choices=["table", "json", "sarif"],
        default="table",
        metavar="FORMAT",
        help="Output format: table (default), json, or sarif.",
    )
    scan_parser.add_argument(
        "--output",
        type=Path,
        default=None,
        metavar="FILE",
        help="Write output to FILE instead of stdout (required for --format sarif in CI).",
    )
    scan_parser.add_argument(
        "--fail-on",
        type=str,
        default=None,
        metavar="SEVERITY",
        help=(
            "Minimum severity that causes a non-zero exit code "
            "(critical, high, medium, low, info). Overrides config file."
        ),
    )
    scan_parser.add_argument(
        "--workers",
        type=int,
        default=os.cpu_count() or 4,
        metavar="N",
        help=f"Number of parallel worker processes (default: {os.cpu_count() or 4}).",
    )
    scan_parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose/debug logging.",
    )
    scan_parser.add_argument(
        "--baseline",
        type=Path,
        default=None,
        metavar="FILE",
        help=(
            "Path to a baseline JSON file created with --create-baseline. "
            "Only findings NOT present in the baseline will be reported. "
            "Allows teams to suppress pre-existing debt and fail only on new issues."
        ),
    )
    scan_parser.add_argument(
        "--create-baseline",
        action="store_true",
        default=False,
        help=(
            "Save current findings to the file specified by --baseline "
            "(or 'metricguard-baseline.json') and exit with code 0. "
            "Use this on the first run against a legacy codebase."
        ),
    )

    return parser


def main(argv: list[str] | None = None) -> int:
    """
    MetricGuard CLI entry point.

    Parses command-line arguments, configures logging, and dispatches
    to the appropriate subcommand handler.

    Args:
        argv: Optional argument list (defaults to sys.argv[1:]).

    Returns:
        Exit code suitable for sys.exit().
    """
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 2

    # Configure logging based on verbosity
    log_level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    if args.command == "scan":
        try:
            return run_scan(
                scan_paths=[p.resolve() for p in args.paths],
                config_path=args.config,
                diff_base=args.diff,
                output_format=args.format,
                output_file=args.output,
                fail_on=args.fail_on,
                workers=args.workers,
                verbose=args.verbose,
                baseline_path=args.baseline,
                create_baseline=args.create_baseline,
            )
        except KeyboardInterrupt:
            print("\n⚠️  Scan interrupted by user.", file=sys.stderr)
            return 3
        except Exception as exc:  # noqa: BLE001
            _print_error(f"Unexpected error: {exc}")
            if args.verbose:
                import traceback

                traceback.print_exc()
            return 3

    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
