"""
MetricGuard Finding Model.

Defines the core data structure for representing a cardinality vulnerability
found during static analysis. Uses Pydantic for robust validation and
serialization, ensuring a consistent interface between all scanning layers
and reporting outputs.
"""

from __future__ import annotations

import hashlib
from enum import StrEnum

from pydantic import BaseModel, Field, computed_field


class Severity(StrEnum):
    """
    CVSS-inspired severity levels adapted for FinOps cardinality risk.

    Severity is determined by the combination of the variable's boundedness
    and the potential economic impact on the monitoring infrastructure.
    """

    CRITICAL = "critical"  # e.g., user_id, UUID directly in a high-frequency label
    HIGH = "high"  # e.g., dynamic string with broad cardinality potential
    MEDIUM = "medium"  # e.g., f-string that may be bounded in some paths
    LOW = "low"  # e.g., environment variable — may or may not be dynamic
    INFO = "info"  # Informational, e.g., potential false positive flagged for review


class FindingCategory(StrEnum):
    """
    Categorizes the source and nature of each finding.

    Enables downstream filtering (e.g., show only YAML findings) and
    is embedded in the SARIF rule metadata for GitHub Code Scanning.
    """

    DYNAMIC_LABEL_VALUE = "dynamic_label_value"
    UNBOUNDED_TAG = "unbounded_tag"
    DANGEROUS_RELABEL = "dangerous_relabel"
    HIGH_CARDINALITY_ATTRIBUTE = "high_cardinality_attribute"
    HIGH_CARDINALITY_LABEL_KEY = "high_cardinality_label_key"
    TAINTED_VARIABLE = "tainted_variable"
    UNSAFE_PROCESSOR = "unsafe_processor"


class EconomicImpact(BaseModel):
    """
    Estimated economic and operational impact of a cardinality explosion.

    These estimates are heuristic and based on industry-observed patterns from
    Prometheus, Datadog, and Grafana Cloud pricing models. They are intended
    to help teams prioritize remediation, not to replace actual cost analysis.
    """

    estimated_series_increase: int = Field(
        ...,
        description="Estimated increase in unique time-series if the issue is triggered at scale.",
        ge=0,
    )
    risk_description: str = Field(
        ...,
        description="Human-readable description of the potential financial and operational impact.",
    )
    estimated_monthly_cost_usd: float | None = Field(
        default=None,
        description="Rough monthly cost increase in USD based on typical cloud monitoring pricing.",
    )
    cardinality_archetype: str | None = Field(
        default=None,
        description=(
            "Detected cardinality archetype "
            "(e.g., 'uuid_request_id', 'user_id', 'http_status')."
        ),
    )
    platform: str | None = Field(
        default=None,
        description=(
            "Monitoring platform driving the cost estimate "
            "(e.g., 'aws_cloudwatch', 'prometheus')."
        ),
    )


class RemediationSuggestion(BaseModel):
    """
    Actionable remediation advice for an identified finding.

    Provides both a human-readable description and optional code snippets
    to help developers immediately fix the issue without deep FinOps expertise.
    """

    description: str = Field(
        ...,
        description="Plain-English description of the recommended fix.",
    )
    code_before: str | None = Field(
        default=None,
        description="The existing problematic code pattern (for diff display).",
    )
    code_after: str | None = Field(
        default=None,
        description="The suggested replacement code pattern.",
    )
    docs_url: str | None = Field(
        default=None,
        description="Link to relevant MetricGuard or vendor documentation.",
    )


class Finding(BaseModel):
    """
    The canonical representation of a single cardinality vulnerability.

    A Finding is the primitive output unit of all MetricGuard scanners.
    It is designed to be serializable to SARIF, JSON, and human-readable
    text formats. Each finding contains full context for triage, economic
    justification, and concrete remediation steps.

    Attributes:
        file_path: Absolute or repo-relative path to the affected file.
        line_number: 1-indexed line number where the issue was detected.
        column_number: 1-indexed column number for precise editor positioning.
        severity: Impact level of the finding.
        category: The type of cardinality problem detected.
        rule_id: Machine-readable rule identifier (e.g., MG001).
        message: Human-readable summary of the specific finding.
        metric_name: The monitoring metric or signal affected (if detectable).
        label_or_tag_name: The specific label/tag key that is high-cardinality.
        offending_code_snippet: The raw code line(s) containing the issue.
        language: Source language of the scanned file.
        economic_impact: Estimated cost and risk if the issue is not fixed.
        remediation: Suggested fix with code examples.
        taint_source: If taint analysis was used, the origin variable/expression.
        is_false_positive_candidate: Whether heuristics suggest this may be safe.
        false_positive_reason: Explanation if is_false_positive_candidate is True.
    """

    file_path: str = Field(..., description="Path to the file containing the finding.")
    line_number: int = Field(..., ge=1, description="1-indexed line number.")
    column_number: int = Field(default=1, ge=1, description="1-indexed column number.")
    severity: Severity = Field(..., description="Risk severity level.")
    category: FindingCategory = Field(..., description="Type of cardinality problem.")
    rule_id: str = Field(..., description="Unique rule identifier (e.g., 'MG-PY-001').")
    message: str = Field(..., description="Human-readable description of the finding.")
    metric_name: str | None = Field(
        default=None, description="The monitoring metric name affected."
    )
    label_or_tag_name: str | None = Field(
        default=None, description="The specific label or tag key implicated."
    )
    offending_code_snippet: str | None = Field(
        default=None, description="The raw source code snippet containing the issue."
    )
    language: str = Field(
        default="unknown", description="Source language (e.g., 'python', 'yaml')."
    )
    economic_impact: EconomicImpact | None = Field(
        default=None, description="Estimated economic and operational impact."
    )
    remediation: RemediationSuggestion | None = Field(
        default=None, description="Actionable remediation advice."
    )
    taint_source: str | None = Field(
        default=None,
        description="The origin variable/expression that taints this label value.",
    )
    is_false_positive_candidate: bool = Field(
        default=False,
        description="True if heuristics indicate this finding may be a false positive.",
    )
    false_positive_reason: str | None = Field(
        default=None,
        description="Explanation of why this might be a false positive.",
    )

    @computed_field  # type: ignore[prop-decorator]
    @property
    def fingerprint(self) -> str:
        """
        Generate a stable, deterministic fingerprint for deduplication.

        The fingerprint is computed from the key identifying attributes so that
        the same logical issue in the same location always produces the same
        hash, even across different scan runs. This is critical for SARIF
        suppression tracking and CI status stability.
        """
        raw = f"{self.file_path}:{self.line_number}:{self.rule_id}:{self.label_or_tag_name}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    def to_console_str(self) -> str:
        """
        Render a human-readable, colorable console representation.

        Returns a compact summary string suitable for terminal output,
        including severity, location, and the core message.
        """
        fp_marker = " [FP?]" if self.is_false_positive_candidate else ""
        return (
            f"[{self.severity.value.upper()}]{fp_marker} "
            f"{self.file_path}:{self.line_number} "
            f"({self.rule_id}) — {self.message}"
        )
