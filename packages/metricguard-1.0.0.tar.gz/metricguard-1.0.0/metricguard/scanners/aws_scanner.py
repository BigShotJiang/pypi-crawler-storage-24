"""
MetricGuard AWS CloudWatch Scanner.

Detects cardinality explosion risks in two contexts:

1. **Python Application Code** (MG-AWS-PY-001):
   Analyzes Python files using the `boto3` CloudWatch SDK pattern
   `cloudwatch.put_metric_data(MetricData=[{'Dimensions': [...]}])`.
   Flags any `Value` inside a Dimensions list that is dynamically
   generated (variable, f-string, attribute access, etc.) rather
   than a bounded constant.

2. **CloudWatch Agent Infrastructure Config** (MG-AWS-INF-001/002):
   Parses `amazon-cloudwatch-agent.json` files (stdlib `json` module —
   no extra dependencies). Detects:
     - `append_dimensions` blocks containing per-instance or
       per-request dimension keys (e.g., `InstanceId`, `user_id`).
     - Namespace strings with dynamic interpolation patterns (`${...}`).

Rule IDs:
    MG-AWS-PY-001:  Dynamic Dimension Value in boto3 put_metric_data()
    MG-AWS-INF-001: Dangerous dimension key in append_dimensions (JSON)
    MG-AWS-INF-002: Dynamic namespace interpolation in CloudWatch config
"""

from __future__ import annotations

import ast
import fnmatch
import json
import logging
import re
from pathlib import Path
from typing import Any

from metricguard.core.scanner import BaseScanner
from metricguard.models.finding import (
    EconomicImpact,
    Finding,
    FindingCategory,
    RemediationSuggestion,
    Severity,
)

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────
# Rule IDs
# ─────────────────────────────────────────────────────
RULE_AWS_PY_DYNAMIC_DIM = "MG-AWS-PY-001"
RULE_AWS_INF_APPEND_DIM = "MG-AWS-INF-001"
RULE_AWS_INF_NAMESPACE = "MG-AWS-INF-002"

# Matches ${VAR_NAME} or {var_name} shell/template interpolations
_INTERPOLATION_RE = re.compile(r"\$\{[^}]+\}|\{[^}]+\}")

# Per-instance CloudWatch dimension keys that are always high-cardinality
# at large fleet scale (each EC2 instance = separate time series)
_ALWAYS_FLAG_DIMENSIONS = frozenset(
    {
        "InstanceId",
        "InstanceType",
        "host",
        "hostname",
        "pod_name",
        "container_id",
    }
)


def _node_to_str(node: ast.AST) -> str:
    """Best-effort AST node → source string for snippets."""
    try:
        return ast.unparse(node)
    except Exception:
        return "<unparseable>"


class AwsScanner(BaseScanner):
    """
    AWS CloudWatch cardinality scanner.

    Handles two file types:
      - Python files (.py): AST analysis for boto3 `put_metric_data` calls.
      - JSON files (.json): CloudWatch Agent config structural analysis.

    The JSON scanner only activates on files that match the configured
    `cloudwatch_agent_filename_patterns` to avoid flagging unrelated JSON.
    This prevents thousands of false positives in repos with generic JSON.

    Architecture Note:
        The Python rule (MG-AWS-PY-001) is implemented as a *second* AST walk
        inside scan_file(), separate from the generic monitored-functions walk
        in PythonScanner. This keeps concerns separated and allows independent
        tuning of cloud-specific rules without touching the core scanner.
    """

    @property
    def supported_extensions(self) -> frozenset[str]:
        """Python and JSON files."""
        return frozenset({".py", ".json"})

    @property
    def scanner_name(self) -> str:
        return "AWSCloudWatch"

    def scan_file(self, file_path: Path, source: str) -> list[Finding]:
        """
        Route to the appropriate sub-scanner based on file extension.

        Args:
            file_path: Path to the file to analyze.
            source:    Pre-read file content (passed from BaseScanner.scan()).

        Returns:
            List of Finding objects.
        """
        ext = file_path.suffix.lower()

        if ext == ".py":
            return self._scan_python(file_path, source)
        elif ext == ".json":
            return self._scan_json(file_path, source)
        return []

    # ────────────────────────────────────────────────────────────────
    # Python (boto3) analysis — MG-AWS-PY-001
    # ────────────────────────────────────────────────────────────────

    def _scan_python(self, file_path: Path, source: str) -> list[Finding]:
        """
        Scan a Python file for boto3 put_metric_data() cardinality risks.

        Looks for the pattern:
            cloudwatch.put_metric_data(
                Namespace='...',
                MetricData=[{
                    'Dimensions': [{'Name': '...',  'Value': <DANGEROUS>}]
                }]
            )
        """
        try:
            tree = ast.parse(source, filename=str(file_path))
        except SyntaxError:
            return []

        source_lines = source.splitlines()
        findings: list[Finding] = []

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            # Match: anything.put_metric_data(...)
            func_str = _node_to_str(node.func)
            if "put_metric_data" not in func_str:
                continue

            line_no = getattr(node, "lineno", 1)
            snippet = (
                source_lines[line_no - 1].strip()
                if line_no <= len(source_lines)
                else ""
            )

            # Extract MetricData keyword argument
            for kw in node.keywords:
                if kw.arg != "MetricData":
                    continue
                findings.extend(
                    self._inspect_metric_data_arg(
                        kw.value, file_path, line_no, snippet, func_str
                    )
                )

        return findings

    def _inspect_metric_data_arg(
        self,
        node: ast.AST,
        file_path: Path,
        line_no: int,
        snippet: str,
        call_name: str,
    ) -> list[Finding]:
        """
        Recursively inspect MetricData=[...] for dangerous Dimension Values.

        MetricData is a list of metric definition dicts. Each dict may contain
        a 'Dimensions' list of {'Name': ..., 'Value': ...} dicts. We flag any
        Value that is not a constant string literal.
        """
        findings: list[Finding] = []

        # MetricData=[{...}, {...}]  — a list literal
        if isinstance(node, ast.List):
            for elt in node.elts:
                findings.extend(
                    self._inspect_metric_data_arg(
                        elt, file_path, line_no, snippet, call_name
                    )
                )

        # Individual metric dict: {'MetricName': '...', 'Dimensions': [...]}
        elif isinstance(node, ast.Dict):
            for key_node, val_node in zip(node.keys, node.values):
                if not isinstance(key_node, ast.Constant):
                    continue
                if str(key_node.value) == "Dimensions":
                    findings.extend(
                        self._inspect_dimensions_list(
                            val_node, file_path, line_no, snippet, call_name
                        )
                    )

        return findings

    def _inspect_dimensions_list(
        self,
        node: ast.AST,
        file_path: Path,
        line_no: int,
        snippet: str,
        call_name: str,
    ) -> list[Finding]:
        """
        Inspect Dimensions=[{'Name': ..., 'Value': <EXPR>}] list.

        A Dimension Value that is not a Constant is flagged as MG-AWS-PY-001.
        """
        findings: list[Finding] = []

        if not isinstance(node, ast.List):
            return findings

        for dim_dict in node.elts:
            if not isinstance(dim_dict, ast.Dict):
                continue

            dim_name = "<unknown>"
            dim_value_node: ast.AST | None = None

            for key_node, val_node in zip(dim_dict.keys, dim_dict.values):
                if not isinstance(key_node, ast.Constant):
                    continue
                if str(key_node.value) == "Name" and isinstance(val_node, ast.Constant):
                    dim_name = str(val_node.value)
                elif str(key_node.value) == "Value":
                    dim_value_node = val_node

            if dim_value_node is None:
                continue

            # Safe: constant string literal
            if isinstance(dim_value_node, ast.Constant):
                continue

            # Everything else: dynamic → flag it
            value_str = _node_to_str(dim_value_node)
            severity = (
                Severity.CRITICAL
                if any(
                    kw in dim_name.lower()
                    for kw in self.config.aws.dangerous_dimension_keys
                )
                else Severity.HIGH
            )

            findings.append(
                self._build_finding(
                    rule_id=RULE_AWS_PY_DYNAMIC_DIM,
                    file_path=file_path,
                    line_no=line_no,
                    severity=severity,
                    category=FindingCategory.DYNAMIC_LABEL_VALUE,
                    metric_name=call_name,
                    label_key=dim_name,
                    value_str=value_str,
                    snippet=snippet,
                    message=(
                        f"Dynamic expression '{value_str}' used as CloudWatch Dimension Value "
                        f"for '{dim_name}' in {call_name}(). Each unique dimension value creates "
                        "a separate CloudWatch metric stream, incurring per-metric costs at scale."
                    ),
                    remediation=RemediationSuggestion(
                        description=(
                            f"Replace the dynamic Dimension Value for '{dim_name}' with a bounded "
                            "constant from a finite set (e.g., environment name, service name, region). "
                            "Use CloudWatch Logs Insights or AWS X-Ray for high-cardinality correlation."
                        ),
                        code_before=f"{{'Name': '{dim_name}', 'Value': {value_str}}}",
                        code_after=f"{{'Name': '{dim_name}', 'Value': 'prod'}}  # bounded constant",
                        docs_url="https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/cloudwatch_concepts.html#Dimension",
                    ),
                )
            )

        return findings

    # ────────────────────────────────────────────────────────────────
    # JSON CloudWatch Agent config analysis — MG-AWS-INF-001/002
    # ────────────────────────────────────────────────────────────────

    def _scan_json(self, file_path: Path, source: str) -> list[Finding]:
        """
        Scan a CloudWatch Agent JSON config for cardinality risks.

        Only activates on files matching the configured agent filename patterns
        to avoid false positives on unrelated JSON files in the repository.
        """
        if not self._is_cloudwatch_config(file_path):
            return []

        try:
            config_data: Any = json.loads(source)
        except json.JSONDecodeError as exc:
            logger.debug("JSON parse error in %s: %s", file_path, exc)
            return []

        if not isinstance(config_data, dict):
            return []

        findings: list[Finding] = []
        findings.extend(self._check_append_dimensions(config_data, file_path))
        findings.extend(self._check_namespace_interpolation(config_data, file_path))
        return findings

    def _is_cloudwatch_config(self, file_path: Path) -> bool:
        """Return True if the file matches any configured CloudWatch agent filename pattern."""
        for pattern in self.config.aws.cloudwatch_agent_filename_patterns:
            if fnmatch.fnmatch(file_path.name, pattern):
                return True
        return False

    def _check_append_dimensions(
        self, config_data: dict[str, Any], file_path: Path
    ) -> list[Finding]:
        """
        Detect dangerous dimension keys in append_dimensions blocks.

        The CloudWatch Agent config uses append_dimensions to inject additional
        labels into all metrics. High-cardinality keys here affect EVERY metric.

        Dangerous patterns:
          - Keys matching any `dangerous_dimension_keys` config list.
          - Keys from `_ALWAYS_FLAG_DIMENSIONS` (InstanceId etc.) when
            `flag_instance_id` is enabled — these create per-host time series.
        """
        findings: list[Finding] = []

        # Navigate: metrics → metrics_collected → <plugin> → append_dimensions
        # Also check top-level append_dimensions (global config)
        def _walk_append_dimensions(obj: Any, path: str, line_hint: int = 1) -> None:
            if isinstance(obj, dict):
                if "append_dimensions" in obj:
                    dims = obj["append_dimensions"]
                    if isinstance(dims, dict):
                        for key, val in dims.items():
                            _check_dim_key(key, str(val), path, line_hint)

                for subkey, subval in obj.items():
                    _walk_append_dimensions(subval, f"{path}.{subkey}", line_hint)

            elif isinstance(obj, list):
                for item in obj:
                    _walk_append_dimensions(item, path, line_hint)

        dangerous_kw = set(self.config.aws.dangerous_dimension_keys)
        always_flag = (
            _ALWAYS_FLAG_DIMENSIONS if self.config.aws.flag_instance_id else set()
        )

        def _check_dim_key(key: str, value: str, path: str, line_hint: int) -> None:
            lower_key = key.lower()

            is_keyword_match = any(kw.lower() in lower_key for kw in dangerous_kw)
            is_always_flag = key in always_flag

            if is_keyword_match or is_always_flag:
                reason = (
                    "matches dangerous keyword pattern"
                    if is_keyword_match
                    else f"'{key}' creates a separate time series per EC2 instance/container"
                )
                severity = Severity.CRITICAL if is_keyword_match else Severity.HIGH

                findings.append(
                    self._build_finding(
                        rule_id=RULE_AWS_INF_APPEND_DIM,
                        file_path=file_path,
                        line_no=1,  # JSON doesn't give us line numbers easily
                        severity=severity,
                        category=FindingCategory.HIGH_CARDINALITY_ATTRIBUTE,
                        metric_name="CloudWatch Agent append_dimensions",
                        label_key=key,
                        value_str=value,
                        snippet=f'"{key}": "{value}"  (in {path})',
                        message=(
                            f"Dimension key '{key}' in append_dimensions ({reason}). "
                            "This dimension will be applied to ALL metrics collected by this agent, "
                            "multiplying cardinality across your entire CloudWatch namespace."
                        ),
                        remediation=RemediationSuggestion(
                            description=(
                                f"Remove '{key}' from append_dimensions. Use CloudWatch resource tags "
                                "and tag-based filtering for instance-level correlation. Alternatively, "
                                "push high-cardinality data to CloudWatch Logs for ad-hoc analysis."
                            ),
                            docs_url="https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch-Agent-Configuration-File-Details.html",
                        ),
                    )
                )

        _walk_append_dimensions(config_data, "root")
        return findings

    def _check_namespace_interpolation(
        self, config_data: dict[str, Any], file_path: Path
    ) -> list[Finding]:
        """
        Detect dynamic namespace strings containing shell/template variable interpolations.

        A namespace like `"MyApp/${ENV_NAME}"` is dangerous because each unique
        ENV_NAME value creates a completely separate CloudWatch namespace with its
        own metric registry, making cross-namespace queries impossible.
        """
        findings: list[Finding] = []

        def _walk_namespaces(obj: Any, path: str) -> None:
            if isinstance(obj, dict):
                if "Namespace" in obj or "namespace" in obj:
                    ns_val = obj.get("Namespace") or obj.get("namespace", "")
                    if isinstance(ns_val, str) and _INTERPOLATION_RE.search(ns_val):
                        findings.append(
                            self._build_finding(
                                rule_id=RULE_AWS_INF_NAMESPACE,
                                file_path=file_path,
                                line_no=1,
                                severity=Severity.HIGH,
                                category=FindingCategory.DYNAMIC_LABEL_VALUE,
                                metric_name="CloudWatch Agent namespace",
                                label_key="namespace",
                                value_str=ns_val,
                                snippet=f'"namespace": "{ns_val}"  (in {path})',
                                message=(
                                    f"CloudWatch namespace '{ns_val}' contains a dynamic interpolation. "
                                    "Each unique interpolated value creates a separate namespace, "
                                    "making cross-namespace queries impossible and cost unpredictable."
                                ),
                                remediation=RemediationSuggestion(
                                    description=(
                                        "Use a static namespace string. Encode environment/region "
                                        "information as dimensions or metric name prefixes instead."
                                    ),
                                    code_before=f'"namespace": "{ns_val}"',
                                    code_after='"namespace": "MyApp/Production"  # static namespace',
                                    docs_url="https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/cloudwatch_concepts.html#Namespace",
                                ),
                            )
                        )
                for subkey, subval in obj.items():
                    _walk_namespaces(subval, f"{path}.{subkey}")

            elif isinstance(obj, list):
                for item in obj:
                    _walk_namespaces(item, path)

        _walk_namespaces(config_data, "root")
        return findings

    # ────────────────────────────────────────────────────────────────
    # Shared Finding builder
    # ────────────────────────────────────────────────────────────────

    def _build_finding(
        self,
        rule_id: str,
        file_path: Path,
        line_no: int,
        severity: Severity,
        category: FindingCategory,
        metric_name: str,
        label_key: str,
        value_str: str,
        snippet: str,
        message: str,
        remediation: RemediationSuggestion | None = None,
    ) -> Finding:
        """Construct a Finding with AWS-specific economic impact estimates."""
        series_map = {
            Severity.CRITICAL: (1_000_000, 800.0),
            Severity.HIGH: (100_000, 80.0),
            Severity.MEDIUM: (10_000, 8.0),
            Severity.LOW: (1_000, 0.8),
            Severity.INFO: (0, 0.0),
        }
        est_series, est_cost = series_map.get(severity, (0, 0.0))

        return Finding(
            file_path=str(file_path),
            line_number=line_no,
            severity=severity,
            category=category,
            rule_id=rule_id,
            message=message,
            metric_name=metric_name,
            label_or_tag_name=label_key,
            offending_code_snippet=snippet,
            language="python" if file_path.suffix.lower() == ".py" else "json",
            is_false_positive_candidate=False,
            economic_impact=EconomicImpact(
                estimated_series_increase=est_series,
                risk_description=(
                    f"In AWS CloudWatch, each unique Dimension combination creates a separate "
                    f"metric stream billed at $0.30/metric/month. At '{label_key}' cardinality "
                    f"of 10K+, this can cost ${est_cost * 100:.0f}+/month unexpectedly."
                ),
                estimated_monthly_cost_usd=est_cost,
            ),
            remediation=remediation,
        )
