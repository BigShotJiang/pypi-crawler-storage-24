"""
MetricGuard Python Scanner.

Performs static analysis on Python source files to detect cardinality
explosion risks in monitoring/observability API calls. This scanner uses
Python's built-in `ast` module (wrapped behind the BaseScanner strategy
interface) to enable robust, production-safe analysis of large codebases.

Analysis Capabilities:
    1. **API Call Detection**: Identifies calls to known monitoring functions
       (Prometheus, Datadog, OTel) by traversing the AST for `Call` nodes
       whose function name matches the configured `monitored_functions` list.

    2. **Label Value Inspection**: For each detected monitoring call, inspects
       all arguments and keyword arguments to identify label values.

    3. **Taint Analysis (Inter-Statement)**: Tracks variable assignments in the
       function scope. If a label value is a variable name, the scanner looks
       back through the scope's assignment map to find its last assigned value
       and determines if that value came from a dangerous source (e.g., a
       function parameter, an f-string with dynamic parts, or a method call
       whose name suggests high cardinality).

    4. **Context-Aware Heuristics (False Positive Reduction)**:
       - Enum members are considered BOUNDED and safe.
       - Boolean literals are always safe.
       - Variables compared against a hardcoded set in an enclosing `if`
         statement are flagged as likely bounded.
       - Constant string literals are always safe.
"""

from __future__ import annotations

import ast
import logging
import re
from pathlib import Path

from metricguard.core.scanner import BaseScanner
from metricguard.models.finding import (
    EconomicImpact,
    Finding,
    FindingCategory,
    RemediationSuggestion,
    Severity,
)

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────
# Rule IDs for Python scanner findings
# ─────────────────────────────────────────────────────
# Core rules (Prometheus/OTel/Datadog)
RULE_DYNAMIC_LABEL = "MG-PY-001"
RULE_FSTRING_LABEL = "MG-PY-002"
RULE_TAINTED_VAR = "MG-PY-003"
RULE_DANGEROUS_KEYWORD = "MG-PY-004"

# Cloud SDK rules
RULE_AWS_PY_DYNAMIC_DIM = "MG-AWS-PY-001"  # boto3 CloudWatch put_metric_data Dimensions
RULE_GCP_PY_DYNAMIC_LABEL = "MG-GCP-PY-001"  # google-cloud-monitoring labels dict
RULE_AZR_PY_DYNAMIC_PROP = (
    "MG-AZR-PY-001"  # Azure Monitor custom_dimensions / properties
)
RULE_STAT_PY_DYNAMIC_TAGS = "MG-STAT-PY-001"  # StatsD/DogStatsD tags list

# ─────────────────────────────────────────────────────
# Patterns that indicate unbounded variable origins
# ─────────────────────────────────────────────────────
_UNBOUNDED_CALL_PATTERNS: list[str] = [
    "str(",
    "uuid",
    "format(",
    "request.",
    "flask.request",
    "django.request",
    "os.environ",
    "environ.get",
    "getenv",
]

_SAFE_TYPES = (ast.Constant,)
_SAFE_CALL_NAMES: frozenset[str] = frozenset(
    ["bool", "int", "float", "len", "isinstance", "type"]
)
_ENUM_BASE_NAMES: frozenset[str] = frozenset(["Enum", "IntEnum", "StrEnum", "Flag"])


# ─────────────────────────────────────────────────────
# Keyword matching helpers (Fix: word-boundary matching)
# ─────────────────────────────────────────────────────


def _build_keyword_patterns(keywords: list[str]) -> list[re.Pattern[str]]:
    """
    Compile dangerous keyword strings into name-matching regex patterns.

    Two strategies are applied depending on keyword length/ambiguity:

    **Long keywords** (e.g. ``user_id``, ``tenant_id``) use a
    negated-lookaround word-boundary pattern that rejects matches where
    a lowercase letter or underscore immediately precedes or follows the
    keyword.  This prevents ``'id'`` from matching inside ``'identifier'``.

        pattern: ``(?<![a-z_])keyword(?![a-z_])``

    **Short / ambiguous keywords** (``id``, ``ip``, ``port``, ``mac``,
    ``url``, ``uri``, ``host``, ``hash``, ``sku``) require a stricter,
    three-arm pattern because the lookaround strategy still produces false
    positives in camelCase names (e.g. the original regex would match
    ``'Ip'`` inside ``'clientIp'`` because neither ``'t'`` nor the end
    of string satisfies ``[a-z_]``).

        pattern: ``(?:^kw$|_kw$|Kw$)``  — exact, snake-suffix, CamelCase-suffix

    See ``metricguard.core.config._build_short_keyword_pattern`` for details.
    """
    from metricguard.core.config import _SHORT_KEYWORDS, _build_short_keyword_pattern

    patterns: list[re.Pattern[str]] = []
    for kw in keywords:
        kl = kw.lower()
        if kl in _SHORT_KEYWORDS:
            # CamelCase + snake_case aware 3-arm pattern
            patterns.append(_build_short_keyword_pattern(kl))
        else:
            # Standard word-boundary-style pattern for longer keywords
            escaped = re.escape(kl)
            patterns.append(re.compile(r"(?<![a-z_])" + escaped + r"(?![a-z_])"))
    return patterns


def _matches_keyword(
    name_lower: str,
    patterns: list[re.Pattern[str]],
    keywords: list[str],
) -> tuple[bool, str]:
    """
    Return ``(True, matched_keyword)`` if *name_lower* matches any compiled
    keyword pattern, or ``(False, '')`` otherwise.

    Args:
        name_lower: The lowercased identifier/attribute name to test.
        patterns:   Pre-compiled patterns from ``_build_keyword_patterns``.
        keywords:   Original keyword strings (parallel list to *patterns*),
                    used to return a human-readable match in the reason string.
    """
    for pat, kw in zip(patterns, keywords):
        if pat.search(name_lower):
            return True, kw
    return False, ""


# ────────────────────────────────────────────────────────────────
# Inline escape hatch:  metricguard:ignore / metricguard:disable-line
#
# Developers may suppress a specific finding by adding a comment
# on the flagged line or on the immediately preceding line:
#
#     some_metric.labels(user_id=uid)   # metricguard:ignore
#     # metricguard:disable-line
#     some_metric.labels(user_id=uid)
# ────────────────────────────────────────────────────────────────
_SUPPRESS_COMMENTS: tuple[str, ...] = (
    "metricguard:ignore",
    "metricguard:disable-line",
    "metricguard:disable",
)


def _is_suppressed(source_lines: list[str], line_no: int) -> bool:
    """
    Return ``True`` if the finding at *line_no* should be suppressed because
    either the flagged line itself or the immediately preceding line contains
    a MetricGuard inline suppression comment.

    Args:
        source_lines: All source lines of the file (1-indexed via ``line_no``).
        line_no:      1-indexed line number of the finding.

    Returns:
        ``True`` if the finding should be discarded.
    """
    # Check the flagged line and the line immediately above it.
    for check_ln in range(max(1, line_no - 1), line_no + 1):
        if check_ln <= len(source_lines):
            if any(tag in source_lines[check_ln - 1] for tag in _SUPPRESS_COMMENTS):
                return True
    return False


def _node_to_str(node: ast.AST) -> str:
    """
    Best-effort conversion of an AST node to a human-readable string.

    Used for generating code snippets in finding messages.
    """
    try:
        return ast.unparse(node)
    except Exception:
        return "<unparseable>"


# ─────────────────────────────────────────────────────
# Scope-aware helpers (B2/B3/M4)
# ─────────────────────────────────────────────────────


def _build_parent_map(tree: ast.AST) -> dict[int, ast.AST]:
    """
    Build a mapping of ``id(child) → parent`` for the entire AST.

    Used by the taint tracker to walk upward from a call site and locate
    the enclosing function scope without re-walking the tree on every lookup.
    """
    parent_map: dict[int, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parent_map[id(child)] = parent
    return parent_map


def _collect_scope_assignments(
    stmts: list[ast.stmt],
) -> dict[str, ast.AST | None]:
    """
    Collect ``name → value_node`` assignments from a list of statements,
    stopping at nested ``FunctionDef`` / ``AsyncFunctionDef`` boundaries.

    ``None`` is used as a sentinel meaning "function parameter" — the caller
    determines the actual value at runtime, which we cannot inspect.

    Processes control-flow blocks (``if``, ``for``, ``with``, ``try``) by
    recursively visiting their sub-statement lists so that assignments inside
    conditionals are visible to the outer scope (flow-insensitive by design;
    the important correctness property is *scope isolation*, not full SSA).
    """
    assignments: dict[str, ast.AST | None] = {}

    def _walk(stmt_list: list[ast.stmt]) -> None:
        for stmt in stmt_list:
            # Stop at nested function / class definition boundaries
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue

            if isinstance(stmt, ast.Assign):
                for target in stmt.targets:
                    if isinstance(target, ast.Name):
                        assignments[target.id] = stmt.value

            elif isinstance(stmt, ast.AnnAssign):
                if isinstance(stmt.target, ast.Name) and stmt.value is not None:
                    assignments[stmt.target.id] = stmt.value

            # Descend into control flow bodies
            for child_field, child_value in ast.iter_fields(stmt):
                if isinstance(child_value, list):
                    sub = [n for n in child_value if isinstance(n, ast.stmt)]
                    if sub:
                        _walk(sub)

    _walk(stmts)
    return assignments


class _TaintTracker:
    """
    Scope-aware intra-function taint tracker.

    Improvements over the previous global ``ast.walk()`` approach:

    * **Scope isolation** — assignments in ``func_a`` do not bleed into
      ``func_b``.  Each ``FunctionDef`` gets its own assignment map.
    * **Parameter tracking** — function parameters are explicitly recorded
      as ``None`` (caller-controlled), making them tainted by default.
    * **Module-level scope** — top-level assignments are tracked separately
      and only used when the call site is not inside any function.
    * **Circular-reference guard** — ``visited`` set prevents infinite
      recursion when a variable is reassigned to itself.

    Limitations (by design):
        - Flow-insensitive: the last assignment to a name wins.
        - No inter-procedural analysis: calls into other functions opaque.
    """

    def __init__(self, tree: ast.AST, dangerous_keywords: list[str]) -> None:
        self._dangerous_keywords = [k.lower() for k in dangerous_keywords]
        # Pre-compile word-boundary-aware regex patterns once at construction
        # time so all per-node checks are O(n_keywords) regex searches, not
        # repeated string builds.
        self._keyword_patterns = _build_keyword_patterns(dangerous_keywords)
        self._parent_map = _build_parent_map(tree)
        # Module-level scope (statements directly in the module body)
        module_stmts = getattr(tree, "body", [])
        self._module_scope: dict[str, ast.AST | None] = _collect_scope_assignments(
            module_stmts
        )
        # Per-function scope: id(FunctionDef) → {name: node | None}
        self._func_scopes: dict[int, dict[str, ast.AST | None]] = {}
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                scope: dict[str, ast.AST | None] = {}
                # Record all parameters as None (caller-controlled)
                all_args = node.args.posonlyargs + node.args.args + node.args.kwonlyargs
                for arg in all_args:
                    scope[arg.arg] = None
                if node.args.vararg:
                    scope[node.args.vararg.arg] = None
                if node.args.kwarg:
                    scope[node.args.kwarg.arg] = None
                # Body assignments (not crossing into nested functions)
                scope.update(_collect_scope_assignments(node.body))
                self._func_scopes[id(node)] = scope

    def _scope_for_node(self, context_node: ast.AST) -> dict[str, ast.AST | None]:
        """
        Walk the parent chain from *context_node* upward and return the
        assignment map for the immediately enclosing function scope.  If no
        enclosing function exists (module-level code), return the module scope.
        """
        current = id(context_node)
        while current in self._parent_map:
            parent = self._parent_map[current]
            if isinstance(parent, (ast.FunctionDef, ast.AsyncFunctionDef)):
                return self._func_scopes.get(id(parent), self._module_scope)
            current = id(parent)
        return self._module_scope

    def is_tainted(
        self,
        name: str,
        context_node: ast.AST,
    ) -> tuple[bool, str]:
        """
        Determine whether *name* carries a tainted (high-cardinality) value
        **within the scope that contains** *context_node*.

        Args:
            name:         Variable name used as a label value.
            context_node: The AST ``Call`` node where the name appears
                          (used to identify the enclosing scope).

        Returns:
            ``(is_tainted, reason_string)``.
        """
        scope = self._scope_for_node(context_node)
        return self._is_tainted_in(name, scope, frozenset())

    def _is_tainted_in(
        self,
        name: str,
        scope: dict[str, ast.AST | None],
        visited: frozenset[str],
    ) -> tuple[bool, str]:
        """Recursive taint resolution within a given scope dict."""
        if name in visited:
            return True, f"Variable '{name}' circular reference — flagging as tainted"

        # Variable name heuristic (always applies regardless of assignment).
        # Use word-boundary-aware regex so 'id' does not match 'identifier'.
        lower_name = name.lower()
        matched, kw = _matches_keyword(
            lower_name, self._keyword_patterns, self._dangerous_keywords
        )
        if matched:
            return True, f"Variable name '{name}' matches dangerous keyword '{kw}'"

        if name not in scope:
            # Unknown in this scope — could be an import or outer closure
            return (
                True,
                f"Variable '{name}' has unknown origin (possibly a parameter or import)",
            )

        assigned_node = scope[name]
        if assigned_node is None:
            # Explicitly a function parameter: caller controls the value
            return (
                True,
                f"Variable '{name}' is a function parameter — value is caller-controlled",
            )

        return self._inspect_node(assigned_node, scope, visited | {name})

    def _inspect_node(
        self,
        node: ast.AST,
        scope: dict[str, ast.AST | None],
        visited: frozenset[str],
    ) -> tuple[bool, str]:
        """
        Recursively inspect an AST node to determine if it is tainted.

        Safe nodes: Constant, BoolOp, Compare, bounded function calls.
        Tainted nodes: JoinedStr (f-string), most Calls, Attribute access,
                       Subscript, unresolvable Name references.
        """
        # Safe: literal constants (strings, numbers, None, booleans)
        if isinstance(node, ast.Constant):
            return False, "Constant literal — bounded by definition"

        # Safe: boolean operations / comparisons always produce bounded values
        if isinstance(node, (ast.BoolOp, ast.Compare)):
            return False, "Boolean/comparison expression — bounded"

        # Dangerous: f-string — almost always dynamic
        if isinstance(node, ast.JoinedStr):
            snippet = _node_to_str(node)
            return True, f"F-string expression '{snippet}' introduces dynamic content"

        # Function calls
        if isinstance(node, ast.Call):
            func_name = _node_to_str(node.func).lower()
            if any(p in func_name for p in _UNBOUNDED_CALL_PATTERNS):
                return (
                    True,
                    f"Call to potentially unbounded source: '{_node_to_str(node.func)}'",
                )
            if _node_to_str(node.func) in _SAFE_CALL_NAMES:
                return False, "Call to safe bounded function"
            return True, f"Return value of '{_node_to_str(node.func)}' may be unbounded"

        # Attribute access — conservative; real Enum checks happen before taint.
        if isinstance(node, ast.Attribute):
            source_str = _node_to_str(node)
            # UPPERCASE attribute name → Enum constant from an external module.
            # Enum members are bounded by definition; skip taint analysis.
            if (
                node.attr
                and node.attr == node.attr.upper()
                and node.attr.replace("_", "").isalpha()
            ):
                return (
                    False,
                    f"Attribute '{source_str}' is UPPERCASE — treated as a bounded Enum constant",
                )
            lower_attr = node.attr.lower()
            attr_matched, kw = _matches_keyword(
                lower_attr, self._keyword_patterns, self._dangerous_keywords
            )
            if attr_matched:
                return (
                    True,
                    f"Attribute '{source_str}' matches dangerous keyword '{kw}'",
                )
            return (
                True,
                f"Attribute access '{source_str}' may yield high-cardinality data",
            )

        # Name reference → recurse within the SAME scope
        if isinstance(node, ast.Name):
            return self._is_tainted_in(node.id, scope, visited)

        # Subscript (e.g., data['user_id']) — assume tainted
        if isinstance(node, ast.Subscript):
            return (
                True,
                f"Subscript expression '{_node_to_str(node)}' may be high-cardinality",
            )

        # Default: conservative
        return (
            True,
            f"Cannot statically determine boundedness of '{_node_to_str(node)}'",
        )


class _BoundednessChecker:
    """
    Heuristic-based checker to identify whether a label value is BOUNDED.

    A value is considered bounded when it is drawn from a known finite set,
    such as an Enum, a boolean, or a variable explicitly compared/checked
    against a hardcoded set of string literals.

    This is MetricGuard's primary false-positive-reduction mechanism.
    """

    def __init__(self, tree: ast.AST, enum_class_names: set[str]) -> None:
        self._enum_names = enum_class_names
        self._tree = tree

    def is_bounded(self, node: ast.AST) -> tuple[bool, str]:
        """
        Determine if `node` represents a bounded (safe) cardinality value.

        Args:
            node: An AST node representing a label value expression.

        Returns:
            Tuple of (is_bounded: bool, reason: str).
        """
        # Literal constants are always bounded
        if isinstance(node, ast.Constant):
            return True, "Constant literal"

        # Boolean literals / operations
        if isinstance(node, (ast.BoolOp, ast.Constant)):
            return True, "Boolean expression"

        # Enum member access: SomeEnum.VALUE (locally defined enum)
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
            if node.value.id in self._enum_names:
                return (
                    True,
                    f"Enum member of '{node.value.id}' — cardinality bounded by enum definition",
                )

        # UPPERCASE attribute → treat as Enum constant even for *imported* enums
        # that are not visible to _collect_enum_class_names (e.g., from other
        # packages).  Enum members are always ALL_CAPS by convention.
        # Requirement: the attr is at least one character and is composed of
        # uppercase letters/underscores only (ruling out mixed-case attributes).
        if (
            isinstance(node, ast.Attribute)
            and node.attr
            and node.attr == node.attr.upper()
            and node.attr.replace("_", "").isalpha()
        ):
            return True, (
                f"Attribute '{node.attr}' is UPPERCASE — treated as a bounded "
                "Enum constant (e.g., Status.COMPLETE, MyEnum.PENDING)"
            )

        # Name that IS an enum class itself (e.g., passing the enum value directly)
        if isinstance(node, ast.Name) and node.id in self._enum_names:
            return True, f"Reference to Enum class '{node.id}'"

        # Call to bool(), int(), len() — always produces a bounded type
        if isinstance(node, ast.Call):
            func_name = _node_to_str(node.func)
            if func_name in _SAFE_CALL_NAMES:
                return True, f"Call to bounded function '{func_name}'"

        return False, "Could not confirm bounded cardinality"


def _collect_enum_class_names(tree: ast.AST) -> set[str]:
    """
    Scan the module AST for class definitions that inherit from Enum variants.

    Returns a set of class names that are confirmed Enum subclasses, used by
    the BoundednessChecker to recognize safe label values.
    """
    enum_names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            for base in node.bases:
                base_name = _node_to_str(base)
                if base_name in _ENUM_BASE_NAMES or "Enum" in base_name:
                    enum_names.add(node.name)
    return enum_names


def _extract_label_values(call_node: ast.Call) -> list[tuple[str, ast.AST]]:
    """
    Extract (label_key, value_node) pairs from a monitoring function call.

    Handles multiple call conventions:
      - Positional dict: counter.labels({"user": user_id})
      - Keyword args:    counter.labels(user=user_id)
      - Direct positional args: counter.inc(user_id)  ← less common but real

    Args:
        call_node: An AST Call node for a monitoring function call.

    Returns:
        List of (label_key_str, value_ast_node) tuples.
    """
    pairs: list[tuple[str, ast.AST]] = []

    # Keyword arguments: counter.labels(env=env, user_id=user_id)
    for kw in call_node.keywords:
        if kw.arg:  # kw.arg is None for **kwargs
            pairs.append((kw.arg, kw.value))

    # Positional dict literal argument: counter.labels({"user_id": uid})
    for arg in call_node.args:
        if isinstance(arg, ast.Dict):
            for key_node, val_node in zip(arg.keys, arg.values):
                if key_node is not None and isinstance(key_node, ast.Constant):
                    pairs.append((str(key_node.value), val_node))
        else:
            # Bare positional (e.g., hist.observe(amount, label_val))
            pairs.append(("_positional_", arg))

    return pairs


class PythonScanner(BaseScanner):
    """
    Concrete Python AST-based cardinality scanner.

    Analyzes Python source files using the built-in `ast` module to detect
    monitoring API calls where label or tag values are dynamically generated.
    Includes inter-statement taint analysis and context-aware heuristics to
    reduce false positives from Enum/bounded-value usages.

    Supported monitoring libraries (configurable):
        - prometheus_client (Counter, Gauge, Histogram, Summary, labels)
        - datadog / dogstatsd (DogStatsd, statsd.increment, etc.)
        - opentelemetry-api (add, record, set_attribute)
        - Custom wrappers (via metricguard.yml)

    Example of a HIGH-severity finding:
        ```python
        REQUEST_COUNTER = Counter("requests_total", "Requests", ["user_id"])
        REQUEST_COUNTER.labels(user_id=request.user_id).inc()
        #                       ^^^^^^^ CRITICAL: unbounded cardinality
        ```

    Example of a safe (bounded) usage that will NOT be flagged:
        ```python
        class Status(Enum):
            OK = "ok"
            ERROR = "error"

        REQUEST_COUNTER.labels(status=Status.OK).inc()  # ✓ Bounded
        ```
    """

    @property
    def supported_extensions(self) -> frozenset[str]:
        """Python source file extensions."""
        return frozenset({".py", ".pyw"})

    @property
    def scanner_name(self) -> str:
        return "PythonAST"

    def scan_file(self, file_path: Path, source: str) -> list[Finding]:
        """
        Parse the Python file and detect cardinality issues.

        ``source`` is the pre-read file content provided by ``BaseScanner.scan()``
        — no additional file I/O is performed here (fixes audit finding B5).

        Pipeline:
          1. Parse source into AST (or propagate SyntaxError → empty list).
          2. Collect Enum class names for boundedness checks.
          3. Build scope-aware taint maps (per-function + module-level).
          4. Build parent map for scope lookup at each call site.
          5. Walk all AST nodes looking for monitoring API calls.
          6. For each call, extract label values and inspect each one.

        Args:
            file_path: Path to the `.py` file to analyze.
            source:    Pre-read UTF-8 source text.

        Returns:
            List of Finding objects, empty if no issues found.
        """
        try:
            tree = ast.parse(source, filename=str(file_path))
        except SyntaxError as exc:
            logger.warning(
                "SyntaxError in %s at line %d: %s", file_path, exc.lineno or 0, exc.msg
            )
            return []  # Unparseable files produce no findings

        source_lines = source.splitlines()
        findings: list[Finding] = []

        enum_names = _collect_enum_class_names(tree)
        taint_tracker = _TaintTracker(tree, self.config.python.dangerous_keywords)
        boundedness_checker = _BoundednessChecker(tree, enum_names)

        monitored_set = set(self.config.python.monitored_functions)

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            func_name = self._extract_func_name(node)
            if not self._is_monitored_call(func_name, monitored_set):
                continue

            label_pairs = _extract_label_values(node)
            line_no = getattr(node, "lineno", 1)
            snippet = (
                source_lines[line_no - 1].strip()
                if line_no <= len(source_lines)
                else ""
            )

            for label_key, value_node in label_pairs:
                finding = self._analyze_label_value(
                    file_path=file_path,
                    metric_call_name=func_name,
                    label_key=label_key,
                    value_node=value_node,
                    line_no=line_no,
                    snippet=snippet,
                    call_node=node,  # ← scope context for taint tracker
                    taint_tracker=taint_tracker,
                    boundedness_checker=boundedness_checker,
                )
                # Respect inline suppression comments:
                #   some_metric.labels(user_id=uid)  # metricguard:ignore
                if finding and not _is_suppressed(source_lines, finding.line_number):
                    findings.append(finding)

        # ── Second pass: Cloud SDK specific detection ────────────────
        # Apply the escape hatch to cloud SDK findings too so developers
        # can silence them with the same inline comment mechanism.
        findings.extend(
            f
            for f in self._scan_cloud_sdks(tree, file_path, source_lines)
            if not _is_suppressed(source_lines, f.line_number)
        )

        return findings

    def _scan_cloud_sdks(
        self,
        tree: ast.AST,
        file_path: Path,
        source_lines: list[str],
    ) -> list[Finding]:
        """
        Dedicated AST walk for cloud-provider SDK cardinality patterns.

        Detects four new rule categories without touching the existing
        Prometheus/OTel scanning logic:

        MG-AWS-PY-001: boto3 put_metric_data() — dynamic Dimensions Value
        MG-GCP-PY-001: google-cloud-monitoring create_time_series() — dynamic labels
        MG-AZR-PY-001: Azure track_metric() / OTel — dynamic custom_dimensions/properties
        MG-STAT-PY-001: StatsD/DogStatsD — dynamic tags list elements

        Note: MG-AWS-PY-001 and MG-STAT-PY-001 are also implemented in their
        respective infrastructure scanners (aws_scanner.py, telegraf_scanner.py)
        for users who run those scanners directly. The rules here detect the
        same patterns from the PythonScanner entrypoint.
        """
        findings: list[Finding] = []

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            func_str = _node_to_str(node.func)
            func_lower = func_str.lower()
            line_no = getattr(node, "lineno", 1)
            snippet = (
                source_lines[line_no - 1].strip()
                if line_no <= len(source_lines)
                else ""
            )

            # ── MG-AWS-PY-001: boto3 put_metric_data ────────────────
            if "put_metric_data" in func_lower:
                findings.extend(
                    self._detect_aws_dimensions(
                        node, file_path, line_no, snippet, func_str
                    )
                )

            # ── MG-GCP-PY-001: google-cloud-monitoring labels ────────
            elif "create_time_series" in func_lower or "time_series" in func_lower:
                findings.extend(
                    self._detect_gcp_labels(node, file_path, line_no, snippet, func_str)
                )

            # ── MG-AZR-PY-001: Azure Monitor custom_dimensions ───────
            elif any(
                az in func_lower
                for az in ("track_metric", "track_event", "track_exception")
            ):
                findings.extend(
                    self._detect_azure_properties(
                        node, file_path, line_no, snippet, func_str
                    )
                )

            # ── MG-STAT-PY-001: StatsD/DogStatsD tags list ──────────
            elif self._is_statsd_call(node):
                findings.extend(
                    self._detect_statsd_tags(
                        node, file_path, line_no, snippet, func_str
                    )
                )

        return findings

    # ── Cloud rule helpers ───────────────────────────────────────────────────

    def _is_statsd_call(self, node: ast.Call) -> bool:
        """Heuristic: is this a statsd/dogstatsd method call?"""
        if not isinstance(node.func, ast.Attribute):
            return False
        method = node.func.attr
        if method not in {
            "increment",
            "decrement",
            "gauge",
            "histogram",
            "distribution",
            "timing",
            "set",
        }:
            return False
        obj_str = _node_to_str(node.func.value).lower()
        return any(
            name in obj_str for name in ("statsd", "dogstatsd", "ddstatsd", "stats")
        )

    def _detect_aws_dimensions(
        self,
        node: ast.Call,
        file_path: Path,
        line_no: int,
        snippet: str,
        func_name: str,
    ) -> list[Finding]:
        """
        MG-AWS-PY-001: Detect dynamic Values in put_metric_data() Dimensions.

        Walks MetricData=[{'Dimensions': [{'Name': '...', 'Value': <EXPR>}]}]
        and flags any Value that is not a bounded constant.
        """
        findings: list[Finding] = []

        def _inspect_list(lst_node: ast.AST) -> None:
            if not isinstance(lst_node, ast.List):
                return
            for elt in lst_node.elts:
                _inspect_metric_dict(elt)

        def _inspect_metric_dict(d: ast.AST) -> None:
            if not isinstance(d, ast.Dict):
                return
            for key_n, val_n in zip(d.keys, d.values):
                if isinstance(key_n, ast.Constant) and str(key_n.value) == "Dimensions":
                    _inspect_dims_list(val_n)

        def _inspect_dims_list(dims: ast.AST) -> None:
            if not isinstance(dims, ast.List):
                return
            for dim in dims.elts:
                if not isinstance(dim, ast.Dict):
                    continue
                dim_name = "<unknown>"
                dim_val_node: ast.AST | None = None
                for k, v in zip(dim.keys, dim.values):
                    if not isinstance(k, ast.Constant):
                        continue
                    if str(k.value) == "Name" and isinstance(v, ast.Constant):
                        dim_name = str(v.value)
                    elif str(k.value) == "Value":
                        dim_val_node = v
                if dim_val_node is None or isinstance(dim_val_node, ast.Constant):
                    continue
                val_str = _node_to_str(dim_val_node)
                findings.append(
                    self._build_finding(
                        rule_id=RULE_AWS_PY_DYNAMIC_DIM,
                        file_path=file_path,
                        line_no=line_no,
                        severity=Severity.HIGH,
                        category=FindingCategory.DYNAMIC_LABEL_VALUE,
                        metric_name=func_name,
                        label_key=dim_name,
                        value_str=val_str,
                        snippet=snippet,
                        message=(
                            f"Dynamic expression '{val_str}' used as CloudWatch Dimension Value "
                            f"for '{dim_name}' in {func_name}(). Each unique Dimension value "
                            "is billed as a separate CloudWatch metric stream at $0.30/month."
                        ),
                        taint_source=val_str,
                        is_fp_candidate=False,
                        remediation=RemediationSuggestion(
                            description=(
                                f"Replace '{val_str}' with a bounded constant (environment name, "
                                "service name, region). Use CloudWatch Logs Insights or X-Ray "
                                "for high-cardinality correlation."
                            ),
                            docs_url="https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/cloudwatch_concepts.html#Dimension",
                        ),
                    )
                )

        for kw in node.keywords:
            if kw.arg == "MetricData":
                _inspect_list(kw.value)

        return findings

    def _detect_gcp_labels(
        self,
        node: ast.Call,
        file_path: Path,
        line_no: int,
        snippet: str,
        func_name: str,
    ) -> list[Finding]:
        """
        MG-GCP-PY-001: Detect dynamic values in google-cloud-monitoring labels dict.

        Targets the pattern:
            client.create_time_series(name, time_series=[...])
        and labels={...} keyword arguments where values are non-constants.
        """
        findings: list[Finding] = []

        for kw in node.keywords:
            if kw.arg != "labels":
                continue
            if not isinstance(kw.value, ast.Dict):
                # Variable reference: labels=some_dict — flag as uncertain
                val_str = _node_to_str(kw.value)
                if not isinstance(kw.value, ast.Constant):
                    findings.append(
                        self._build_finding(
                            rule_id=RULE_GCP_PY_DYNAMIC_LABEL,
                            file_path=file_path,
                            line_no=line_no,
                            severity=Severity.HIGH,
                            category=FindingCategory.TAINTED_VARIABLE,
                            metric_name=func_name,
                            label_key="labels",
                            value_str=val_str,
                            snippet=snippet,
                            message=(
                                f"Variable '{val_str}' passed as labels dict to {func_name}(). "
                                "Cannot statically verify label values are bounded. "
                                "GCP Monitoring charges per unique label-value combination."
                            ),
                            taint_source=val_str,
                            is_fp_candidate=True,
                            remediation=RemediationSuggestion(
                                description=(
                                    "Ensure all label values are drawn from a bounded set. "
                                    "Use a literal dict with constant values where possible."
                                ),
                                docs_url="https://cloud.google.com/monitoring/docs/apis/v3/metrics#labels",
                            ),
                        )
                    )
                continue

            # Dict literal: inspect each value
            for key_node, val_node in zip(kw.value.keys, kw.value.values):
                if isinstance(val_node, ast.Constant):
                    continue
                key_str = (
                    str(key_node.value)
                    if isinstance(key_node, ast.Constant)
                    else _node_to_str(key_node) if key_node else "<unknown>"
                )
                val_str = _node_to_str(val_node)
                findings.append(
                    self._build_finding(
                        rule_id=RULE_GCP_PY_DYNAMIC_LABEL,
                        file_path=file_path,
                        line_no=line_no,
                        severity=Severity.HIGH,
                        category=FindingCategory.DYNAMIC_LABEL_VALUE,
                        metric_name=func_name,
                        label_key=key_str,
                        value_str=val_str,
                        snippet=snippet,
                        message=(
                            f"Dynamic expression '{val_str}' used as GCP Monitoring label value "
                            f"for '{key_str}' in {func_name}(). GCP Monitoring has a hard limit "
                            "of 100,000 unique label-value combinations per metric descriptor."
                        ),
                        taint_source=val_str,
                        is_fp_candidate=False,
                        remediation=RemediationSuggestion(
                            description=(
                                f"Replace dynamic label value for '{key_str}' with a bounded constant. "
                                "Use Cloud Logging or Cloud Trace for high-cardinality correlation."
                            ),
                            docs_url="https://cloud.google.com/monitoring/docs/apis/v3/metrics#labels",
                        ),
                    )
                )

        return findings

    def _detect_azure_properties(
        self,
        node: ast.Call,
        file_path: Path,
        line_no: int,
        snippet: str,
        func_name: str,
    ) -> list[Finding]:
        """
        MG-AZR-PY-001: Detect dynamic values in Azure Monitor custom_dimensions/properties.

        Targets `track_metric()` and `track_event()` calls from:
          - applicationinsights SDK: tc.track_metric(name, value, properties={...})
          - azure-monitor-opentelemetry: track_metric(custom_dimensions={...})
        """
        findings: list[Finding] = []
        target_kwargs = {"custom_dimensions", "properties", "measurements"}

        for kw in node.keywords:
            if kw.arg not in target_kwargs:
                continue

            if not isinstance(kw.value, ast.Dict):
                val_str = _node_to_str(kw.value)
                if not isinstance(kw.value, ast.Constant):
                    findings.append(
                        self._build_finding(
                            rule_id=RULE_AZR_PY_DYNAMIC_PROP,
                            file_path=file_path,
                            line_no=line_no,
                            severity=Severity.HIGH,
                            category=FindingCategory.TAINTED_VARIABLE,
                            metric_name=func_name,
                            label_key=kw.arg,
                            value_str=val_str,
                            snippet=snippet,
                            message=(
                                f"Variable '{val_str}' passed as '{kw.arg}' to {func_name}(). "
                                "Azure Monitor Application Insights indexes custom dimensions — "
                                "unbounded cardinality increases storage costs and query latency."
                            ),
                            taint_source=val_str,
                            is_fp_candidate=True,
                            remediation=RemediationSuggestion(
                                description=(
                                    "Pass a literal dict with bounded constant values. "
                                    "Keep high-cardinality data in Log Analytics custom logs instead."
                                ),
                                docs_url="https://learn.microsoft.com/en-us/azure/azure-monitor/app/api-custom-events-metrics#properties",
                            ),
                        )
                    )
                continue

            for key_node, val_node in zip(kw.value.keys, kw.value.values):
                if isinstance(val_node, ast.Constant):
                    continue
                key_str = (
                    str(key_node.value)
                    if isinstance(key_node, ast.Constant)
                    else _node_to_str(key_node) if key_node else "<unknown>"
                )
                val_str = _node_to_str(val_node)
                # Check for dangerous keyword in the dimension key name
                is_critical = any(
                    kw_p in key_str.lower()
                    for kw_p in self.config.python.dangerous_keywords
                )
                findings.append(
                    self._build_finding(
                        rule_id=RULE_AZR_PY_DYNAMIC_PROP,
                        file_path=file_path,
                        line_no=line_no,
                        severity=Severity.CRITICAL if is_critical else Severity.HIGH,
                        category=FindingCategory.DYNAMIC_LABEL_VALUE,
                        metric_name=func_name,
                        label_key=key_str,
                        value_str=val_str,
                        snippet=snippet,
                        message=(
                            f"Dynamic expression '{val_str}' in '{kw.arg}' dict key '{key_str}' "
                            f"passed to {func_name}(). Azure Application Insights stores custom "
                            "dimensions as indexed properties — unbounded values cause data "
                            "storage explosion and degrade query performance."
                        ),
                        taint_source=val_str,
                        is_fp_candidate=False,
                        remediation=RemediationSuggestion(
                            description=(
                                f"Replace the dynamic value for '{key_str}' with a bounded constant. "
                                "Store high-cardinality identifiers in Log Analytics custom tables "
                                "rather than Application Insights custom dimensions."
                            ),
                            docs_url="https://learn.microsoft.com/en-us/azure/azure-monitor/app/api-custom-events-metrics#properties",
                        ),
                    )
                )

        return findings

    def _detect_statsd_tags(
        self,
        node: ast.Call,
        file_path: Path,
        line_no: int,
        snippet: str,
        func_name: str,
    ) -> list[Finding]:
        """
        MG-STAT-PY-001: Detect dynamic tag list elements in StatsD/DogStatsD calls.

        Flags non-constant entries in `tags=[...]` keyword argument.
        In Datadog, each unique tag-value combination = 1 custom metric at $0.05+/month.
        """
        findings: list[Finding] = []

        for kw in node.keywords:
            if kw.arg != "tags":
                continue
            if not isinstance(kw.value, ast.List):
                # Variable reference: tags=some_list — flag as uncertain
                val_str = _node_to_str(kw.value)
                if not isinstance(kw.value, ast.Constant):
                    findings.append(
                        self._build_finding(
                            rule_id=RULE_STAT_PY_DYNAMIC_TAGS,
                            file_path=file_path,
                            line_no=line_no,
                            severity=Severity.HIGH,
                            category=FindingCategory.TAINTED_VARIABLE,
                            metric_name=func_name,
                            label_key="tags",
                            value_str=val_str,
                            snippet=snippet,
                            message=(
                                f"Variable '{val_str}' passed as tags list to {func_name}(). "
                                "Cannot statically verify tag values. If any tag is dynamic, "
                                "this causes Datadog custom metric cardinality explosion."
                            ),
                            taint_source=val_str,
                            is_fp_candidate=True,
                            remediation=RemediationSuggestion(
                                description="Pass a literal list of constant tags instead of a variable.",
                                docs_url="https://docs.datadoghq.com/metrics/custom_metrics/",
                            ),
                        )
                    )
                continue

            for i, elt in enumerate(kw.value.elts):
                if isinstance(elt, ast.Constant):
                    continue  # Constant string tag — safe
                elt_str = _node_to_str(elt)
                findings.append(
                    self._build_finding(
                        rule_id=RULE_STAT_PY_DYNAMIC_TAGS,
                        file_path=file_path,
                        line_no=line_no,
                        severity=Severity.HIGH,
                        category=FindingCategory.DYNAMIC_LABEL_VALUE,
                        metric_name=func_name,
                        label_key=f"tags[{i}]",
                        value_str=elt_str,
                        snippet=snippet,
                        message=(
                            f"Dynamic tag '{elt_str}' at index {i} in {func_name}() tags list. "
                            "Datadog bills per unique tag-value combination as a custom metric."
                        ),
                        taint_source=elt_str,
                        is_fp_candidate=False,
                        remediation=RemediationSuggestion(
                            description=(
                                "Replace dynamic tag values with bounded constants. "
                                "Move high-cardinality data to APM Trace tags or log attributes."
                            ),
                            code_after=f"{func_name}('metric', tags=['env:prod', 'service:api'])",
                            docs_url="https://docs.datadoghq.com/metrics/custom_metrics/",
                        ),
                    )
                )

        return findings

    def _is_monitored_call(self, func_name: str, monitored_set: set[str]) -> bool:
        """
        Check if a function call target is a monitored metric API.

        Performs both exact and partial matching:
          - Exact match: "Counter" → matches Counter()
          - Suffix match: "labels" → matches counter.labels(), obj.labels()

        Args:
            func_name: Extracted function/method name string.
            monitored_set: Set of configured monitored function names.

        Returns:
            True if the call should be analyzed for cardinality issues.
        """
        if func_name in monitored_set:
            return True
        # Match method calls: "obj.labels" → check "labels"
        if "." in func_name:
            _, method = func_name.rsplit(".", 1)
            if method in monitored_set:
                return True
        return False

    @staticmethod
    def _extract_func_name(call_node: ast.Call) -> str:
        """
        Extract the function name string from a Call node.

        Handles:
          - Simple names: `Counter(...)` → "Counter"
          - Attribute access: `counter.labels(...)` → "counter.labels"
          - Chained: `obj.method.sub(...)` → "obj.method.sub"
        """
        return _node_to_str(call_node.func)

    def _analyze_label_value(
        self,
        file_path: Path,
        metric_call_name: str,
        label_key: str,
        value_node: ast.AST,
        line_no: int,
        snippet: str,
        call_node: ast.Call,
        taint_tracker: _TaintTracker,
        boundedness_checker: _BoundednessChecker,
    ) -> Finding | None:
        """
        Determine if a single label value is safe or high-cardinality.

        Decision tree:
          1. Is the value node itself bounded? → No finding.
          2. Is it an f-string? → MG-PY-002 (HIGH).
          3. Is it a Name node? → Run taint analysis:
               a. Is the var name a dangerous keyword? → MG-PY-004 (CRITICAL).
               b. Does taint analysis say it's tainted? → MG-PY-003 (HIGH).
          4. Is it an attribute/call/subscript? → MG-PY-001 (HIGH).
          5. Otherwise: skip (conservative safe default for unknown patterns).

        Args:
            file_path:         Source file path for the Finding.
            metric_call_name:  Name of the monitoring function being called.
            label_key:         The label/tag key name.
            value_node:        AST node of the label value expression.
            line_no:           Line number of the monitoring call.
            snippet:           Raw source line for context.
            call_node:         The AST Call node (provides scope context for taint tracker).
            taint_tracker:     Scope-aware taint tracker.
            boundedness_checker: Boundedness heuristic checker.

        Returns:
            A Finding object if a vulnerability is detected, else None.
        """
        value_str = _node_to_str(value_node)

        # Step 1: Boundedness fast-exit
        is_bounded, bound_reason = boundedness_checker.is_bounded(value_node)
        if is_bounded:
            logger.debug(
                "Skipping bounded value '%s' for label '%s': %s",
                value_str,
                label_key,
                bound_reason,
            )
            return None

        # Step 2: F-string → always dangerous
        if isinstance(value_node, ast.JoinedStr):
            return self._build_finding(
                rule_id=RULE_FSTRING_LABEL,
                file_path=file_path,
                line_no=line_no,
                severity=Severity.HIGH,
                category=FindingCategory.DYNAMIC_LABEL_VALUE,
                metric_name=metric_call_name,
                label_key=label_key,
                value_str=value_str,
                snippet=snippet,
                message=(
                    f"F-string used as label value for '{label_key}' in {metric_call_name}(). "
                    "F-strings produce unbounded cardinality at runtime."
                ),
                taint_source=None,
                is_fp_candidate=False,
                remediation=RemediationSuggestion(
                    description=(
                        "Replace the f-string with a bounded Enum value or a pre-computed "
                        "constant. If dynamic context is needed for debugging, use a Prometheus "
                        "Exemplar or a structured log instead."
                    ),
                    code_before=f"{metric_call_name}(... {label_key}={value_str} ...)",
                    code_after=(
                        f"# Option 1: Use an Enum\n"
                        f"class {label_key.title()}(Enum):\n"
                        f"    EXPECTED_VALUE_A = 'value_a'\n\n"
                        f"{metric_call_name}(... {label_key}={label_key.title()}.EXPECTED_VALUE_A ...)\n\n"
                        f"# Option 2: Move to a structured log\n"
                        f"logger.info('event', extra={{'{label_key}': {value_str}}})\n"
                        f"{metric_call_name}(... )  # remove dynamic label"
                    ),
                    docs_url="https://prometheus.io/docs/practices/exemplars/",
                ),
            )

        # Step 3: Variable name → dangerous keyword check + taint analysis
        if isinstance(value_node, ast.Name):
            var_name = value_node.id

            # Direct dangerous keyword match — use word-boundary-aware regex
            # so short keywords like 'id' don't fire on 'identifier' or 'grid'.
            lower_var = var_name.lower()
            kw_patterns = _build_keyword_patterns(self.config.python.dangerous_keywords)
            kw_matched, matched_kw = _matches_keyword(
                lower_var,
                kw_patterns,
                [k.lower() for k in self.config.python.dangerous_keywords],
            )
            if kw_matched:
                return self._build_finding(
                    rule_id=RULE_DANGEROUS_KEYWORD,
                    file_path=file_path,
                    line_no=line_no,
                    severity=Severity.CRITICAL,
                    category=FindingCategory.DYNAMIC_LABEL_VALUE,
                    metric_name=metric_call_name,
                    label_key=label_key,
                    value_str=var_name,
                    snippet=snippet,
                    message=(
                        f"Variable '{var_name}' matches high-cardinality keyword '{matched_kw}' "
                        f"and is used as label value for '{label_key}' in {metric_call_name}(). "
                        "This will cause cardinality explosion at scale."
                    ),
                    taint_source=var_name,
                    is_fp_candidate=False,
                    remediation=RemediationSuggestion(
                        description=(
                            f"Remove '{label_key}' from the metric labels. "
                            "High-cardinality identifiers like user IDs and request IDs "
                            "belong in Prometheus Exemplars or structured logs."
                        ),
                        code_before=f"{metric_call_name}(... {label_key}={var_name} ...)",
                        code_after=(
                            f"# Remove the high-cardinality label:\n"
                            f"{metric_call_name}(... )  # remove {label_key}\n\n"
                            f"# Use an Exemplar for correlation:\n"
                            f"histogram.observe(value, exemplar={{'{label_key}': {var_name}}})"
                        ),
                        docs_url="https://prometheus.io/docs/practices/naming/",
                    ),
                )

            # Taint analysis — now scope-aware via call_node context
            if self.config.python.enable_taint_analysis:
                is_tainted, taint_reason = taint_tracker.is_tainted(var_name, call_node)
                if is_tainted:
                    return self._build_finding(
                        rule_id=RULE_TAINTED_VAR,
                        file_path=file_path,
                        line_no=line_no,
                        severity=Severity.HIGH,
                        category=FindingCategory.TAINTED_VARIABLE,
                        metric_name=metric_call_name,
                        label_key=label_key,
                        value_str=var_name,
                        snippet=snippet,
                        message=(
                            f"Taint analysis: variable '{var_name}' used as label '{label_key}' "
                            f"in {metric_call_name}() traces to a potentially unbounded source. "
                            f"Reason: {taint_reason}"
                        ),
                        taint_source=taint_reason,
                        is_fp_candidate=True,  # Taint analysis has more FP potential
                        remediation=RemediationSuggestion(
                            description=(
                                f"Verify that '{var_name}' is drawn from a finite, known set "
                                "of values. If it is an Enum or boolean, annotate it with the "
                                "Enum type to silence this warning. If it is truly unbounded, "
                                "remove it from metric labels."
                            ),
                            docs_url="https://opentelemetry.io/docs/specs/semconv/",
                        ),
                    )
            return None  # Safe variable, no finding

        # Step 4: Attribute access, method call, or subscript
        if isinstance(value_node, (ast.Attribute, ast.Call, ast.Subscript)):
            return self._build_finding(
                rule_id=RULE_DYNAMIC_LABEL,
                file_path=file_path,
                line_no=line_no,
                severity=Severity.HIGH,
                category=FindingCategory.DYNAMIC_LABEL_VALUE,
                metric_name=metric_call_name,
                label_key=label_key,
                value_str=value_str,
                snippet=snippet,
                message=(
                    f"Dynamic expression '{value_str}' used as label value for '{label_key}' "
                    f"in {metric_call_name}(). Runtime expressions may produce unbounded cardinality."
                ),
                taint_source=value_str,
                is_fp_candidate=False,
                remediation=RemediationSuggestion(
                    description=(
                        "Replace with a bounded value. If the expression evaluates to one of "
                        "a small set of known values, extract those into an Enum."
                    ),
                ),
            )

        return None

    def _build_finding(
        self,
        rule_id: str,
        file_path: Path,
        line_no: int,
        severity: Severity,
        category: FindingCategory,
        metric_name: str,
        label_key: str,
        value_str: str,
        snippet: str,
        message: str,
        taint_source: str | None,
        is_fp_candidate: bool,
        remediation: RemediationSuggestion | None = None,
    ) -> Finding:
        """
        Construct a fully populated Finding with economic impact data.

        Economic impact estimates are heuristic and scale with severity:
          - CRITICAL: ~1M+ series increase (unbounded per-user labels).
          - HIGH: ~100K series increase.
          - MEDIUM: ~10K series increase.
        """
        series_map = {
            Severity.CRITICAL: (1_000_000, 500.0),
            Severity.HIGH: (100_000, 50.0),
            Severity.MEDIUM: (10_000, 5.0),
            Severity.LOW: (1_000, 0.5),
            Severity.INFO: (0, 0.0),
        }
        est_series, est_cost = series_map.get(severity, (0, 0.0))

        return Finding(
            file_path=str(file_path),
            line_number=line_no,
            severity=severity,
            category=category,
            rule_id=rule_id,
            message=message,
            metric_name=metric_name,
            label_or_tag_name=label_key,
            offending_code_snippet=snippet,
            language="python",
            taint_source=taint_source,
            is_false_positive_candidate=is_fp_candidate,
            false_positive_reason=(
                "Taint analysis has inherent false positive risk. Verify the variable's origin."
                if is_fp_candidate
                else None
            ),
            economic_impact=EconomicImpact(
                estimated_series_increase=est_series,
                risk_description=(
                    f"If '{label_key}' holds unbounded values, each unique value creates a new "
                    "time series. At 10K requests/min per instance, this could increase your "
                    "Prometheus TSDB size by orders of magnitude and spike scrape latency."
                ),
                estimated_monthly_cost_usd=est_cost,
            ),
            remediation=remediation,
        )
