"""
MetricGuard Telegraf/StatsD Scanner.

Detects cardinality explosion risks in two contexts:

1. **Telegraf Infrastructure Config** (.conf / TOML):
   Uses Python 3.11+ stdlib `tomllib` (zero new dependencies) to parse
   Telegraf configuration files. Detects:
   - MG-TEL-INF-001: `[global_tags]` entries that carry dynamic, high-
     cardinality values (e.g., shell variable interpolations like `${USER_ID}`
     or keys matching dangerous keyword patterns).
   - MG-TEL-INF-002: `[[processors.regex]]` blocks whose `result_key` writes
     into a high-cardinality dimension name.

2. **Python StatsD / DogStatsD Application Code** (MG-STAT-PY-001):
   AST analysis of Python source files for `statsd.increment()`,
   `statsd.gauge()`, `dogstatsd.increment()`, etc. Flags any element in the
   `tags=[...]` list argument that is not a constant string literal, because
   dynamic tag values in StatsD/DogStatsD result in unbounded Datadog custom
   metric cardinality.

Rule IDs:
    MG-TEL-INF-001:  High-cardinality / dynamic key in [global_tags]
    MG-TEL-INF-002:  Regex processor writes to dangerous result_key
    MG-STAT-PY-001:  Dynamic tag value in StatsD/DogStatsD tags list
"""

from __future__ import annotations

import ast
import logging
import re
from pathlib import Path
from typing import Any

from metricguard.core.scanner import BaseScanner
from metricguard.models.finding import (
    EconomicImpact,
    Finding,
    FindingCategory,
    RemediationSuggestion,
    Severity,
)

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────
# Rule IDs
# ─────────────────────────────────────────────────────
RULE_TEL_INF_GLOBAL_TAGS = "MG-TEL-INF-001"
RULE_TEL_INF_REGEX_PROC = "MG-TEL-INF-002"
RULE_STAT_PY_DYNAMIC_TAGS = "MG-STAT-PY-001"

# Shell variable interpolation patterns: ${VAR} or $VAR
_ENV_VAR_RE = re.compile(r"\$\{[^}]+\}|\$[A-Za-z_][A-Za-z0-9_]*")

# StatsD / DogStatsD function names that accept a `tags` argument
_STATSD_FUNC_NAMES: frozenset[str] = frozenset(
    {
        "increment",
        "decrement",
        "gauge",
        "histogram",
        "distribution",
        "timing",
        "set",
        "event",
        "service_check",
    }
)

# Known StatsD client variable names (heuristic — extend via config)
_STATSD_CLIENT_NAMES: frozenset[str] = frozenset(
    {
        "statsd",
        "dogstatsd",
        "ddstatsd",
        "dd",
        "stats",
        "client",
        "metrics",
    }
)


def _node_to_str(node: ast.AST) -> str:
    """Best-effort AST node → source string."""
    try:
        return ast.unparse(node)
    except Exception:
        return "<unparseable>"


class TelegrafScanner(BaseScanner):
    """
    Telegraf/StatsD cardinality scanner.

    Handles two file types:
      - TOML files (.conf): Telegraf config structural analysis.
      - Python files (.py): AST analysis for StatsD/DogStatsD API calls.

    Architecture Note:
        This scanner deliberately does NOT scan .py files for Prometheus/OTel
        patterns — that is `PythonScanner`'s responsibility. The `.py`
        extension here is scoped exclusively to StatsD tag detection.
        The CLI scanner-dispatch logic assigns files to ALL matching scanners,
        so a `.py` file will run through both `PythonScanner` and
        `TelegrafScanner`, each detecting its own rules independently.
    """

    @property
    def supported_extensions(self) -> frozenset[str]:
        """Telegraf config files and Python source files."""
        return frozenset({".conf", ".py"})

    @property
    def scanner_name(self) -> str:
        return "TelegrafStatsD"

    def scan_file(self, file_path: Path, source: str) -> list[Finding]:
        """
        Route to the appropriate sub-scanner based on file extension.

        Args:
            file_path: Path to the file to analyze.
            source:    Pre-read file content (passed from BaseScanner.scan()).

        Returns:
            List of Finding objects.
        """
        ext = file_path.suffix.lower()

        if ext == ".conf":
            return self._scan_toml(file_path, source)
        elif ext == ".py":
            return self._scan_python_statsd(file_path, source)
        return []

    # ────────────────────────────────────────────────────────────────
    # Telegraf TOML config analysis
    # ────────────────────────────────────────────────────────────────

    def _scan_toml(self, file_path: Path, source: str) -> list[Finding]:
        """
        Parse a Telegraf .conf file (TOML) and detect cardinality risks.

        Uses `tomllib` from the Python 3.11 standard library. Falls back
        gracefully on parse errors (returns empty findings).
        """
        try:
            import tomllib
        except ImportError:
            # Python < 3.11 fallback — try tomli (optional third-party)
            try:
                import tomli as tomllib  # type: ignore[no-redef]
            except ImportError:
                logger.warning(
                    "tomllib/tomli not available — skipping Telegraf scan of %s. "
                    "Python 3.11+ is required for .conf file analysis.",
                    file_path,
                )
                return []

        try:
            config_data: dict[str, Any] = tomllib.loads(source)
        except Exception as exc:
            logger.debug("TOML parse error in %s: %s", file_path, exc)
            return []

        findings: list[Finding] = []
        findings.extend(self._check_global_tags(config_data, file_path))
        findings.extend(self._check_regex_processors(config_data, file_path))
        return findings

    def _check_global_tags(self, config_data: dict[str, Any], file_path: Path) -> list[Finding]:
        """
        Inspect [global_tags] for high-cardinality or dynamic tag values.

        Flags two categories:
          1. Keys matching `dangerous_global_tag_keys` config list.
          2. Values containing shell variable interpolations (${VAR} or $VAR)
             when `flag_env_var_interpolation` is True — these inject runtime
             environment values into every single metric produced by this agent.

        Design rationale: `global_tags` apply to ALL metrics emitted by the
        agent (potentially thousands). A single high-cardinality tag here is
        a force multiplier — far more dangerous than a per-metric label.
        """
        findings: list[Finding] = []
        global_tags: Any = config_data.get("global_tags", {})

        if not isinstance(global_tags, dict):
            return findings

        dangerous_keys = set(self.config.telegraf.dangerous_global_tag_keys)

        for tag_key, tag_val in global_tags.items():
            tag_val_str = str(tag_val)
            lower_key = tag_key.lower()

            # Check 1: Key name matches dangerous keyword
            matched_kw = next(
                (kw for kw in dangerous_keys if kw.lower() in lower_key), None
            )
            if matched_kw:
                findings.append(
                    self._build_finding(
                        rule_id=RULE_TEL_INF_GLOBAL_TAGS,
                        file_path=file_path,
                        line_no=1,
                        severity=Severity.CRITICAL,
                        category=FindingCategory.HIGH_CARDINALITY_ATTRIBUTE,
                        metric_name="[global_tags]",
                        label_key=tag_key,
                        value_str=tag_val_str,
                        message=(
                            f"Global tag key '{tag_key}' in [global_tags] matches the dangerous "
                            f"keyword '{matched_kw}'. This tag is applied to ALL metrics emitted "
                            "by this Telegraf agent, creating unbounded cardinality at scale."
                        ),
                        remediation=RemediationSuggestion(
                            description=(
                                f"Remove '{tag_key}' from [global_tags]. Use a bounded, static value "
                                "like a region name or environment. High-cardinality identifiers "
                                "belong in Telegraf's structured logs, not in metrics tags."
                            ),
                            docs_url="https://docs.influxdata.com/telegraf/v1/configuration/#global-tags",
                        ),
                    )
                )
                continue  # Skip env-var check if keyword match already flagged

            # Check 2: Value is a shell variable interpolation
            if self.config.telegraf.flag_env_var_interpolation and _ENV_VAR_RE.search(
                tag_val_str
            ):
                findings.append(
                    self._build_finding(
                        rule_id=RULE_TEL_INF_GLOBAL_TAGS,
                        file_path=file_path,
                        line_no=1,
                        severity=Severity.HIGH,
                        category=FindingCategory.DYNAMIC_LABEL_VALUE,
                        metric_name="[global_tags]",
                        label_key=tag_key,
                        value_str=tag_val_str,
                        message=(
                            f"Global tag '{tag_key} = \"{tag_val_str}\"' in [global_tags] contains "
                            "a shell variable interpolation. If the environment variable holds "
                            "high-cardinality data (e.g., request ID, pod UID), this will create "
                            "unbounded cardinality across all metrics."
                        ),
                        remediation=RemediationSuggestion(
                            description=(
                                "Replace the dynamic value with a static bounded string. "
                                "If you need host-level grouping, use bounded values like "
                                "region, availability zone, or environment name."
                            ),
                            code_before=f'[global_tags]\n  {tag_key} = "{tag_val_str}"',
                            code_after=f'[global_tags]\n  {tag_key} = "us-east-1"  # static bounded value',
                            docs_url="https://docs.influxdata.com/telegraf/v1/configuration/#global-tags",
                        ),
                    )
                )

        return findings

    def _check_regex_processors(
        self, config_data: dict[str, Any], file_path: Path
    ) -> list[Finding]:
        """
        Detect [[processors.regex]] blocks that write to dangerous result_keys.

        A regex processor that extracts a substring of a URL or request path
        and stores it under a `result_key` like `user_id` will inject that
        dynamic value into every metric flowing through the pipeline.
        """
        findings: list[Finding] = []

        # TOML array-of-tables: [[processors.regex]] → parsed as a list per key
        processors = config_data.get("processors", {})
        regex_processors = processors.get("regex", [])

        # Handle both list-of-dicts and single dict
        if isinstance(regex_processors, dict):
            regex_processors = [regex_processors]

        dangerous_keys = set(self.config.telegraf.dangerous_regex_result_keys)

        for proc in regex_processors:
            if not isinstance(proc, dict):
                continue

            # Check each field-level regex rule: fields, tags, metrics
            for field_type in ("fields", "tags", "metrics"):
                field_rules = proc.get(field_type, [])
                if isinstance(field_rules, dict):
                    field_rules = [field_rules]

                for rule in field_rules:
                    if not isinstance(rule, dict):
                        continue
                    result_key = rule.get("result_key", "")
                    if not result_key:
                        continue

                    lower_result = result_key.lower()
                    matched = next(
                        (kw for kw in dangerous_keys if kw.lower() in lower_result),
                        None,
                    )
                    if matched:
                        pattern = rule.get("pattern", "<regex>")
                        findings.append(
                            self._build_finding(
                                rule_id=RULE_TEL_INF_REGEX_PROC,
                                file_path=file_path,
                                line_no=1,
                                severity=Severity.HIGH,
                                category=FindingCategory.DYNAMIC_LABEL_VALUE,
                                metric_name="[[processors.regex]]",
                                label_key=result_key,
                                value_str=pattern,
                                message=(
                                    f"Regex processor writes extracted value to result_key '{result_key}' "
                                    f"(matched dangerous keyword '{matched}'). "
                                    f"Regex pattern '{pattern}' may extract unbounded substrings "
                                    "(e.g., from URLs or request paths) into metric tags."
                                ),
                                remediation=RemediationSuggestion(
                                    description=(
                                        f"Rename result_key '{result_key}' to a bounded tag, or "
                                        "redesign the regex to extract only a finite set of categories "
                                        "(e.g., HTTP method, status code class) rather than raw identifiers."
                                    ),
                                    docs_url="https://docs.influxdata.com/telegraf/v1/plugins/processors/regex/",
                                ),
                            )
                        )

        return findings

    # ────────────────────────────────────────────────────────────────
    # Python StatsD analysis — MG-STAT-PY-001
    # ────────────────────────────────────────────────────────────────

    def _scan_python_statsd(self, file_path: Path, source: str) -> list[Finding]:
        """
        Scan a Python file for DogStatsD/StatsD dynamic tag values.

        Targets calls like:
            statsd.increment('my.metric', tags=['env:prod', f'user:{user_id}'])
            dogstatsd.gauge('my.metric', 42, tags=[tag_var, 'region:us-east'])

        A tag list element that is not a constant string literal is flagged
        as MG-STAT-PY-001 because Datadog charges per unique tag value combination.

        Note: We check the calling object's variable name against known StatsD
        client names AND check if the method name is in `_STATSD_FUNC_NAMES`.
        This is intentionally permissive to catch custom wrappers.
        """
        try:
            tree = ast.parse(source, filename=str(file_path))
        except SyntaxError:
            return []

        source_lines = source.splitlines()
        findings: list[Finding] = []

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            # Must be a method call: obj.method(...)
            if not isinstance(node.func, ast.Attribute):
                continue

            method_name = node.func.attr
            if method_name not in _STATSD_FUNC_NAMES:
                continue

            # Heuristic: check if the callee looks like a StatsD client
            obj_str = _node_to_str(node.func.value).lower()
            if not any(name in obj_str for name in _STATSD_CLIENT_NAMES):
                continue

            line_no = getattr(node, "lineno", 1)
            snippet = (
                source_lines[line_no - 1].strip()
                if line_no <= len(source_lines)
                else ""
            )

            # Find the `tags` keyword argument
            for kw in node.keywords:
                if kw.arg != "tags":
                    continue
                findings.extend(
                    self._inspect_tags_arg(
                        kw.value, file_path, line_no, snippet, method_name
                    )
                )

            # Also check positional `tags` argument (3rd+ positional in DogStatsD)
            # DogStatsd.increment(metric, value, tags) — tags is 3rd positional
            if len(node.args) >= 3:
                potential_tags = node.args[2]
                findings.extend(
                    self._inspect_tags_arg(
                        potential_tags, file_path, line_no, snippet, method_name
                    )
                )

        return findings

    def _inspect_tags_arg(
        self,
        tags_node: ast.AST,
        file_path: Path,
        line_no: int,
        snippet: str,
        call_name: str,
    ) -> list[Finding]:
        """
        Inspect the tags=[...] argument for non-constant elements.

        Each element in the tags list that is NOT a constant string literal
        is flagged. This catches:
          - Variable references: `tags=[user_tag]`
          - F-strings: `tags=[f'user:{user_id}']`
          - Method calls: `tags=[get_user_tag()]`
          - Attribute access: `tags=[obj.tag]`
        """
        findings: list[Finding] = []

        if isinstance(tags_node, ast.List):
            for i, elt in enumerate(tags_node.elts):
                if isinstance(elt, ast.Constant):
                    # Validate the constant tag format: "key:value"
                    # Even constant tags should use bounded key:VALUE format
                    tag_str = str(elt.value)
                    # Check if the tag key itself is a dangerous keyword
                    if ":" in tag_str:
                        tag_key = tag_str.split(":", 1)[0]
                        lower_key = tag_key.lower()
                        if any(
                            kw in lower_key
                            for kw in self.config.telegraf.dangerous_global_tag_keys
                        ):
                            findings.append(
                                self._build_finding(
                                    rule_id=RULE_STAT_PY_DYNAMIC_TAGS,
                                    file_path=file_path,
                                    line_no=line_no,
                                    severity=Severity.HIGH,
                                    category=FindingCategory.HIGH_CARDINALITY_LABEL_KEY,
                                    metric_name=call_name,
                                    label_key=tag_key,
                                    value_str=tag_str,
                                    message=(
                                        f"StatsD tag '{tag_str}' uses key '{tag_key}' which matches "
                                        "a dangerous cardinality keyword. Ensure the value for this "
                                        "tag is bounded — each unique value creates a new Datadog metric."
                                    ),
                                    remediation=RemediationSuggestion(
                                        description=f"Remove '{tag_key}' tag or ensure its value is from a bounded set.",
                                        docs_url="https://docs.datadoghq.com/metrics/custom_metrics/",
                                    ),
                                )
                            )
                    continue  # Safe constant (no dynamic interpolation)

                # Non-constant element → flag it
                elt_str = _node_to_str(elt)
                is_fstring = isinstance(elt, ast.JoinedStr)

                severity = Severity.HIGH
                category = (
                    FindingCategory.DYNAMIC_LABEL_VALUE
                    if is_fstring
                    else FindingCategory.DYNAMIC_LABEL_VALUE
                )

                findings.append(
                    self._build_finding(
                        rule_id=RULE_STAT_PY_DYNAMIC_TAGS,
                        file_path=file_path,
                        line_no=line_no,
                        severity=severity,
                        category=category,
                        metric_name=call_name,
                        label_key=f"tags[{i}]",
                        value_str=elt_str,
                        message=(
                            f"Dynamic tag value '{elt_str}' in {call_name}() tags list (index {i}). "
                            "In Datadog, each unique tag value combination creates a separate custom "
                            "metric — dynamic tags cause unbounded custom metric growth."
                        ),
                        remediation=RemediationSuggestion(
                            description=(
                                "Use only bounded tag values from a finite set. "
                                "Replace dynamic values with constants or Enum members. "
                                "Move high-cardinality data to APM Trace tags or log attributes."
                            ),
                            code_before=f"{call_name}('metric', tags=[{elt_str}])",
                            code_after=f"{call_name}('metric', tags=['env:prod', 'region:us-east-1'])",
                            docs_url="https://docs.datadoghq.com/metrics/custom_metrics/",
                        ),
                    )
                )

        elif not isinstance(tags_node, ast.Constant):
            # tags= is a variable reference or other expression, not a list literal
            tags_str = _node_to_str(tags_node)
            findings.append(
                self._build_finding(
                    rule_id=RULE_STAT_PY_DYNAMIC_TAGS,
                    file_path=file_path,
                    line_no=line_no,
                    severity=Severity.HIGH,
                    category=FindingCategory.TAINTED_VARIABLE,
                    metric_name=call_name,
                    label_key="tags",
                    value_str=tags_str,
                    message=(
                        f"Variable '{tags_str}' passed as tags list to {call_name}(). "
                        "Cannot statically verify that all tag values are bounded. "
                        "If any tag value is dynamic, this will cause cardinality explosion."
                    ),
                    remediation=RemediationSuggestion(
                        description=(
                            "Pass a literal list of constant tags instead of a variable. "
                            "If the tags must be dynamic, audit every element for boundedness."
                        ),
                        docs_url="https://docs.datadoghq.com/metrics/custom_metrics/",
                    ),
                )
            )

        return findings

    # ────────────────────────────────────────────────────────────────
    # Shared Finding builder
    # ────────────────────────────────────────────────────────────────

    def _build_finding(
        self,
        rule_id: str,
        file_path: Path,
        line_no: int,
        severity: Severity,
        category: FindingCategory,
        metric_name: str,
        label_key: str,
        value_str: str,
        message: str,
        remediation: RemediationSuggestion | None = None,
    ) -> Finding:
        """Construct a Finding with Telegraf/StatsD-specific economic impact."""
        series_map = {
            Severity.CRITICAL: (
                5_000_000,
                1500.0,
            ),  # Global tags → all metrics affected
            Severity.HIGH: (100_000, 100.0),
            Severity.MEDIUM: (10_000, 10.0),
            Severity.LOW: (1_000, 1.0),
            Severity.INFO: (0, 0.0),
        }
        est_series, est_cost = series_map.get(severity, (0, 0.0))

        return Finding(
            file_path=str(file_path),
            line_number=line_no,
            severity=severity,
            category=category,
            rule_id=rule_id,
            message=message,
            metric_name=metric_name,
            label_or_tag_name=label_key,
            offending_code_snippet=value_str,
            language="toml" if file_path.suffix.lower() == ".conf" else "python",
            is_false_positive_candidate=False,
            economic_impact=EconomicImpact(
                estimated_series_increase=est_series,
                risk_description=(
                    f"High-cardinality tag in {rule_id}: '{label_key}' could create "
                    f"~{est_series:,} additional metric combinations. In Datadog, each "
                    f"unique tag-value combination = 1 custom metric at $0.05+/metric/month."
                ),
                estimated_monthly_cost_usd=est_cost,
            ),
            remediation=remediation,
        )
