"""
MetricGuard YAML Infrastructure Scanner.

Analyzes Prometheus and OpenTelemetry YAML configuration files to identify
cardinality explosion risks at the infrastructure level. While the Python
scanner catches issues introduced by application developers, this scanner
catches issues introduced by platform/SRE engineers in their observability
configs — a critical but often overlooked attack vector.

What This Scanner Detects:

1. **Dangerous Prometheus relabel_configs**:
   Prometheus scrape configs can use `relabel_configs` to attach labels
   derived from pod/node metadata. When these source labels contain
   per-request or per-user data (e.g., `__meta_kubernetes_pod_label_user_id`),
   each unique combination creates a new time series.

   Dangerous patterns:
   - `source_labels` containing high-cardinality metadata fields.
   - `target_label` names that match dangerous keyword patterns.
   - `action: labelmap` with regex that captures unbounded data.

2. **Dangerous OpenTelemetry Processors**:
   OTel Collector pipelines can use attributes processors to enrich spans
   with runtime data. When those attributes map to high-cardinality values,
   they cascade into all downstream metric aggregations.

   Dangerous patterns:
   - `attributes/insert` or `attributes/upsert` with dynamic keys.
   - Span-to-metric processors that use unbounded span attributes as dimensions.
   - Resource detection processors that inject per-pod or per-request labels.

3. **General High-Cardinality Label Configuration**:
   Any YAML key-value pair where the key matches a known dangerous label
   name and it appears in a monitoring context (Prometheus, OTel, Datadog).
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from pathlib import Path
from typing import Any

import yaml

from metricguard.core.scanner import BaseScanner
from metricguard.models.finding import (
    EconomicImpact,
    Finding,
    FindingCategory,
    RemediationSuggestion,
    Severity,
)

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────
# Rule IDs for YAML scanner findings
# ─────────────────────────────────────────────────────
RULE_DANGEROUS_RELABEL = "MG-YAML-001"
RULE_HIGH_CARD_SOURCE_LABEL = "MG-YAML-002"
RULE_LABELMAP_WILDCARD = "MG-YAML-003"
RULE_OTEL_UNSAFE_ATTRIBUTE = "MG-YAML-004"
RULE_OTEL_SPAN_METRIC_DIMENSION = "MG-YAML-005"
RULE_DANGEROUS_LABEL_KEY = "MG-YAML-006"

# ─────────────────────────────────────────────────────
# Prometheus-specific detection patterns
# ─────────────────────────────────────────────────────
_PROMETHEUS_TOP_LEVEL_KEYS: frozenset[str] = frozenset(
    [
        "scrape_configs",
        "remote_write",
        "remote_read",
        "global",
        "rule_files",
        "alerting",
    ]
)

_OTEL_TOP_LEVEL_KEYS: frozenset[str] = frozenset(
    ["receivers", "processors", "exporters", "extensions", "service", "pipelines"]
)

# OTel processors that can introduce high-cardinality
_OTEL_RISKY_PROCESSOR_PREFIXES: tuple[str, ...] = (
    "attributes",
    "span",
    "transform",
    "metricstransform",
    "spanmetrics",
    "servicegraph",
)

# Regex patterns that wildcard-capture unbounded metadata
_DANGEROUS_LABELMAP_REGEXES: list[str] = [
    "(.*)",
    "(.+)",
    "__meta_kubernetes_pod_label_(.*)",
    "__meta_kubernetes_pod_annotation_(.*)",
    "__meta_ec2_tag_(.*)",
]

# ─────────────────────────────────────────────────────
# Monitoring-config indicator strings
#
# Before parsing YAML, a fast raw-string scan is run.
# Any YAML file that contains NONE of these strings is
# almost certainly not a Prometheus / OTel config and is
# skipped entirely to avoid false positives in Docker
# Compose files, Helm values files, GitHub Actions YAMLs,
# etc.
# ─────────────────────────────────────────────────────
_PROMETHEUS_INDICATORS: frozenset[str] = frozenset(
    {
        "relabel_configs",
        "metric_relabel_configs",
        "scrape_configs",
        "target_label",
        "action: replace",
        "action: labelmap",
        "action: keep",
        "action: drop",
        "remote_write",
        "alerting:",
        "rule_files:",
    }
)

_OTEL_INDICATORS: frozenset[str] = frozenset(
    {
        "receivers:",
        "processors:",
        "exporters:",
        "pipelines:",
        "spanmetrics",
        "attributes/",
        "otelcol",
        "otlp:",
    }
)


def _yaml_load_safe(source: str) -> Any:
    """
    Load YAML content safely, returning None on parse failure.

    Uses yaml.safe_load to prevent arbitrary Python object instantiation.
    """
    try:
        return yaml.safe_load(source)
    except yaml.YAMLError as exc:
        logger.debug("YAML parse error: %s", exc)
        return None


def _find_line_number(source_lines: list[str], search_value: str) -> int:
    """
    Best-effort search for a string value within source lines.

    Returns the 1-indexed line number of the first occurrence, or 1 as fallback.
    This is a heuristic approach since PyYAML's safe_load discards line numbers.
    """
    search_lower = search_value.lower().strip()
    for i, line in enumerate(source_lines, start=1):
        if search_lower in line.lower():
            return i
    return 1


def _walk_yaml(
    data: Any,
    path: list[str] | None = None,
) -> Iterator[tuple[list[str], Any]]:
    """
    Recursively walk a parsed YAML structure yielding (path, value) pairs.

    Yields every node (dict, list element, scalar) with its key path for
    context-aware analysis. Used to find dangerous patterns regardless of
    nesting depth.

    Args:
        data: The parsed YAML object (any Python type).
        path: Current nesting path (accumulated key names).

    Yields:
        Tuples of (path_list, value) for every node.
    """
    if path is None:
        path = []

    yield path, data

    if isinstance(data, dict):
        for key, value in data.items():
            yield from _walk_yaml(value, path + [str(key)])
    elif isinstance(data, list):
        for i, item in enumerate(data):
            yield from _walk_yaml(item, path + [f"[{i}]"])


class YamlScanner(BaseScanner):
    """
    YAML infrastructure configuration cardinality scanner.

    Parses Prometheus scrape configs, OTel Collector configurations, and
    general YAML monitoring configs to detect patterns that will cause
    cardinality explosion in downstream monitoring systems.

    The scanner auto-detects the config format based on top-level keys
    and applies format-specific detection rules. Files that cannot be
    detected as monitoring configs are scanned for dangerous label key
    patterns as a general catch-all.
    """

    @property
    def supported_extensions(self) -> frozenset[str]:
        """YAML config file extensions."""
        return frozenset({".yml", ".yaml"})

    @property
    def scanner_name(self) -> str:
        return "YamlInfra"

    def scan_file(self, file_path: Path, source: str) -> list[Finding]:
        """
        Parse and analyze a YAML infrastructure configuration file.

        Detection pipeline:
          0. Fast-path indicator check — skip immediately if the raw source
             contains no Prometheus or OTel indicator strings.  This prevents
             MetricGuard from parsing CI/CD YAMLs, Docker Compose files, Helm
             values files, etc. that happen to share a ``.yml`` extension with
             monitoring configs.  The cost is a single ``in`` scan of the raw
             string, which is orders of magnitude cheaper than YAML parsing.
          1. Parse YAML safely into a Python object.
          2. Detect config format (Prometheus, OTel, Generic).
          3. Apply format-specific analysis rules.
          4. Apply generic dangerous-key scan as catch-all.

        Args:
            file_path: Path to the .yml/.yaml file to analyze.
            source:    Pre-read file content (passed from BaseScanner.scan()).

        Returns:
            List of Finding objects, empty if no issues were detected.
        """
        # ── Step 0: fast-path monitoring-config heuristic ──────────────
        # Combine both indicator sets for a single O(n) scan of the source.
        all_indicators = _PROMETHEUS_INDICATORS | _OTEL_INDICATORS
        if not any(ind in source for ind in all_indicators):
            logger.debug(
                "Skipping non-monitoring YAML (no Prometheus/OTel indicators): %s",
                file_path,
            )
            return []
        source_lines = source.splitlines()

        data = _yaml_load_safe(source)
        if data is None or not isinstance(data, dict):
            logger.debug("Skipping non-dict or unparseable YAML: %s", file_path)
            return []

        findings: list[Finding] = []

        # Detect config type and run targeted analysis
        top_keys = set(data.keys())
        is_prometheus = bool(top_keys & _PROMETHEUS_TOP_LEVEL_KEYS)
        is_otel = bool(top_keys & _OTEL_TOP_LEVEL_KEYS)

        if is_prometheus:
            logger.debug("Detected Prometheus config: %s", file_path)
            findings.extend(self._scan_prometheus(data, file_path, source_lines))

        if is_otel:
            logger.debug("Detected OTel Collector config: %s", file_path)
            findings.extend(self._scan_otel(data, file_path, source_lines))

        # Generic: catch dangerous label keys in any YAML monitoring config
        findings.extend(self._scan_dangerous_label_keys(data, file_path, source_lines))

        # Deduplicate by fingerprint (same line+rule may trigger multiple passes)
        seen: set[str] = set()
        unique_findings: list[Finding] = []
        for finding in findings:
            if finding.fingerprint not in seen:
                seen.add(finding.fingerprint)
                unique_findings.append(finding)

        return unique_findings

    # ─────────────────────────────────────────────────────────
    # Prometheus-specific analysis
    # ─────────────────────────────────────────────────────────

    def _scan_prometheus(
        self,
        data: dict[str, Any],
        file_path: Path,
        source_lines: list[str],
    ) -> list[Finding]:
        """
        Scan a Prometheus configuration for dangerous relabeling.

        Traverses all `scrape_configs` to find `relabel_configs` and
        `metric_relabel_configs` entries that map high-cardinality metadata
        into target labels. Also checks for dangerous `labelmap` regexes.

        Args:
            data: Parsed Prometheus config as a Python dict.
            file_path: Path to the config file (for Finding metadata).
            source_lines: Raw source lines for line number lookup.

        Returns:
            List of findings from Prometheus-specific rule analysis.
        """
        findings: list[Finding] = []
        scrape_configs = data.get("scrape_configs", [])
        if not isinstance(scrape_configs, list):
            return findings

        for scrape_config in scrape_configs:
            if not isinstance(scrape_config, dict):
                continue

            job_name = scrape_config.get("job_name", "<unnamed_job>")

            # Check both relabel_configs and metric_relabel_configs
            for relabel_section in ["relabel_configs", "metric_relabel_configs"]:
                relabel_configs = scrape_config.get(relabel_section, [])
                if not isinstance(relabel_configs, list):
                    continue

                for relabel in relabel_configs:
                    if not isinstance(relabel, dict):
                        continue
                    findings.extend(
                        self._analyze_relabel_config(
                            relabel=relabel,
                            job_name=job_name,
                            file_path=file_path,
                            source_lines=source_lines,
                        )
                    )

        return findings

    def _analyze_relabel_config(
        self,
        relabel: dict[str, Any],
        job_name: str,
        file_path: Path,
        source_lines: list[str],
    ) -> list[Finding]:
        """
        Analyze a single relabel_config block for cardinality risks.

        Checks:
          1. source_labels containing known high-cardinality fields.
          2. target_label matching dangerous keyword patterns.
          3. action=labelmap with wildcard regexes.

        Args:
            relabel: A single parsed relabel_config dict.
            job_name: The parent scrape job name for context.
            file_path: Source file path.
            source_lines: Raw source lines for line number lookup.

        Returns:
            List of findings from this relabel block.
        """
        findings: list[Finding] = []
        action = relabel.get("action", "replace")
        target_label = relabel.get("target_label", "")
        source_labels = relabel.get("source_labels", [])
        regex = relabel.get("regex", "")

        # Rule 1: High-cardinality source_labels
        if isinstance(source_labels, list):
            for src_label in source_labels:
                src_str = str(src_label)
                for dangerous in self.config.yaml.dangerous_source_labels:
                    if dangerous.lower() in src_str.lower():
                        line_no = _find_line_number(source_lines, src_str)
                        findings.append(
                            Finding(
                                file_path=str(file_path),
                                line_number=line_no,
                                severity=Severity.HIGH,
                                category=FindingCategory.DANGEROUS_RELABEL,
                                rule_id=RULE_HIGH_CARD_SOURCE_LABEL,
                                language="yaml",
                                message=(
                                    f"Prometheus job '{job_name}': source_label '{src_str}' "
                                    "maps high-cardinality metadata to a metric label. "
                                    "This will cause cardinality explosion proportional to "
                                    "the number of unique pods/requests."
                                ),
                                metric_name=job_name,
                                label_or_tag_name=target_label or src_str,
                                offending_code_snippet=(
                                    f"source_labels: [{src_str}]  → target_label: {target_label or '(implicit)'}"
                                ),
                                economic_impact=EconomicImpact(
                                    estimated_series_increase=50_000,
                                    risk_description=(
                                        "In Kubernetes environments, pod-level labels can generate "
                                        "1 series per pod per metric. At 1000 pods, this is 1000x "
                                        "your baseline series count."
                                    ),
                                    estimated_monthly_cost_usd=25.0,
                                ),
                                remediation=RemediationSuggestion(
                                    description=(
                                        f"Remove '{src_str}' from source_labels. If this metadata "
                                        "is required for correlation, attach it to Prometheus Exemplars "
                                        "or route it to a log aggregation pipeline instead."
                                    ),
                                    code_before=f"source_labels: [{src_str}]\ntarget_label: {target_label}",
                                    code_after=(
                                        "# Remove the high-cardinality relabel entirely.\n"
                                        "# If correlation is needed, use Exemplars:\n"
                                        "# exemplar_relabeling:\n"
                                        f"#   - source_labels: [{src_str}]\n"
                                        f"#     target_label: {target_label}"
                                    ),
                                    docs_url="https://prometheus.io/docs/practices/exemplars/",
                                ),
                            )
                        )
                        break  # One finding per source_label

        # Rule 2: Dangerous target_label names
        if target_label:
            lower_target = str(target_label).lower()
            for kw in self.config.yaml.dangerous_label_keys:
                if kw in lower_target:
                    line_no = _find_line_number(source_lines, target_label)
                    findings.append(
                        Finding(
                            file_path=str(file_path),
                            line_number=line_no,
                            severity=Severity.CRITICAL,
                            category=FindingCategory.DANGEROUS_RELABEL,
                            rule_id=RULE_DANGEROUS_RELABEL,
                            language="yaml",
                            message=(
                                f"Prometheus job '{job_name}': target_label '{target_label}' "
                                f"matches dangerous keyword '{kw}'. Labeling metrics with "
                                "user/request identifiers causes catastrophic cardinality explosion."
                            ),
                            metric_name=job_name,
                            label_or_tag_name=str(target_label),
                            offending_code_snippet=f"target_label: {target_label}",
                            economic_impact=EconomicImpact(
                                estimated_series_increase=1_000_000,
                                risk_description=(
                                    "A label with unbounded unique values (e.g., one per user) "
                                    "linearly scales your time-series count. At 100K users, "
                                    "a single metric can generate 100K+ series."
                                ),
                                estimated_monthly_cost_usd=500.0,
                            ),
                            remediation=RemediationSuggestion(
                                description=(
                                    f"Replace target_label '{target_label}' with a bounded "
                                    "label. Consider using Alertmanager's `group_by` for "
                                    "aggregation or Prometheus Exemplars for trace correlation."
                                ),
                                docs_url="https://prometheus.io/docs/alerting/latest/configuration/#group-by",
                            ),
                        )
                    )
                    break

        # Rule 3: labelmap with dangerous wildcard regex
        if action == "labelmap" and regex:
            regex_str = str(regex)
            for dangerous_re in _DANGEROUS_LABELMAP_REGEXES:
                if dangerous_re in regex_str:
                    line_no = _find_line_number(source_lines, regex_str)
                    findings.append(
                        Finding(
                            file_path=str(file_path),
                            line_number=line_no,
                            severity=Severity.HIGH,
                            category=FindingCategory.DANGEROUS_RELABEL,
                            rule_id=RULE_LABELMAP_WILDCARD,
                            language="yaml",
                            message=(
                                f"Prometheus job '{job_name}': action=labelmap with regex "
                                f"'{regex_str}' may capture an unbounded set of Kubernetes "
                                "metadata labels into metric labels."
                            ),
                            metric_name=job_name,
                            label_or_tag_name="<labelmap_wildcard>",
                            offending_code_snippet=f"action: labelmap\nregex: {regex_str}",
                            economic_impact=EconomicImpact(
                                estimated_series_increase=200_000,
                                risk_description=(
                                    "labelmap with (.*) captures ALL matched pod annotation/label "
                                    "keys into Prometheus labels. In dynamic Kubernetes clusters "
                                    "with rolling deploments, this creates a continuous stream "
                                    "of new label combinations."
                                ),
                                estimated_monthly_cost_usd=100.0,
                            ),
                            remediation=RemediationSuggestion(
                                description=(
                                    "Replace the wildcard regex with an explicit allowlist of "
                                    "safe, bounded label names. Only promote metadata labels "
                                    "that have a known finite set of values."
                                ),
                                code_before=f"action: labelmap\nregex: {regex_str}",
                                code_after=(
                                    "# Explicitly allowlist only safe, bounded labels:\n"
                                    "action: labelmap\n"
                                    "regex: __meta_kubernetes_pod_label_(app|environment|version)"
                                ),
                                docs_url="https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config",
                            ),
                        )
                    )
                    break

        return findings

    # ─────────────────────────────────────────────────────────
    # OpenTelemetry-specific analysis
    # ─────────────────────────────────────────────────────────

    def _scan_otel(
        self,
        data: dict[str, Any],
        file_path: Path,
        source_lines: list[str],
    ) -> list[Finding]:
        """
        Scan an OpenTelemetry Collector config for unsafe attribute processors.

        Focuses on processors that can inject high-cardinality span attributes
        into metrics, particularly:
          - attributes/* processors with dynamic value insertions.
          - spanmetrics/* processors that use unbounded span attributes as metric dimensions.
          - transform/* processors that compute labels from request data.

        Args:
            data: Parsed OTel config as a Python dict.
            file_path: Path to the config file.
            source_lines: Raw source lines for line number lookup.

        Returns:
            List of OTel-specific cardinality findings.
        """
        findings: list[Finding] = []
        processors = data.get("processors", {})
        if not isinstance(processors, dict):
            return findings

        for processor_name, processor_config in processors.items():
            if not isinstance(processor_config, dict):
                continue

            processor_prefix = str(processor_name).split("/")[0]

            if not processor_prefix.startswith(_OTEL_RISKY_PROCESSOR_PREFIXES):
                continue

            # Analyze attributes processor actions
            if processor_prefix == "attributes":
                actions = processor_config.get("actions", [])
                if isinstance(actions, list):
                    for action in actions:
                        if not isinstance(action, dict):
                            continue
                        findings.extend(
                            self._analyze_otel_attribute_action(
                                action=action,
                                processor_name=str(processor_name),
                                file_path=file_path,
                                source_lines=source_lines,
                            )
                        )

            # Analyze spanmetrics processor dimensions
            elif processor_prefix in ("spanmetrics", "servicegraph"):
                dimensions = processor_config.get("dimensions", [])
                if isinstance(dimensions, list):
                    for dim in dimensions:
                        if not isinstance(dim, dict):
                            continue
                        dim_name = dim.get("name", "")
                        findings.extend(
                            self._analyze_otel_span_metric_dimension(
                                dim_name=str(dim_name),
                                processor_name=str(processor_name),
                                file_path=file_path,
                                source_lines=source_lines,
                            )
                        )

        return findings

    def _analyze_otel_attribute_action(
        self,
        action: dict[str, Any],
        processor_name: str,
        file_path: Path,
        source_lines: list[str],
    ) -> list[Finding]:
        """
        Analyze an OTel attributes processor action for cardinality risks.

        Dangerous patterns:
          - action: insert/upsert with a key matching dangerous keyword patterns.
          - action: extract with a regex pattern on high-cardinality attributes.
        """
        findings: list[Finding] = []
        key = str(action.get("key", ""))
        action_type = str(action.get("action", ""))

        if action_type not in ("insert", "upsert", "update", "extract"):
            return findings

        for kw in self.config.yaml.dangerous_label_keys:
            if kw in key.lower():
                line_no = _find_line_number(source_lines, key)
                findings.append(
                    Finding(
                        file_path=str(file_path),
                        line_number=line_no,
                        severity=Severity.HIGH,
                        category=FindingCategory.HIGH_CARDINALITY_ATTRIBUTE,
                        rule_id=RULE_OTEL_UNSAFE_ATTRIBUTE,
                        language="yaml",
                        message=(
                            f"OTel processor '{processor_name}': action='{action_type}' inserts "
                            f"attribute key '{key}' which matches dangerous keyword '{kw}'. "
                            "If this attribute propagates to metrics, it will cause cardinality explosion."
                        ),
                        metric_name=processor_name,
                        label_or_tag_name=key,
                        offending_code_snippet=f"action: {action_type}\nkey: {key}",
                        economic_impact=EconomicImpact(
                            estimated_series_increase=100_000,
                            risk_description=(
                                "OTel span attributes that are promoted to metric dimensions "
                                "can turn a single counter into thousands of distinct series."
                            ),
                            estimated_monthly_cost_usd=50.0,
                        ),
                        remediation=RemediationSuggestion(
                            description=(
                                f"Remove the '{key}' attribute insertion from the '{processor_name}' processor. "
                                "If correlation is needed, keep it as a span attribute only (not a metric dimension) "
                                "and use Exemplars or trace-log correlation instead."
                            ),
                            docs_url="https://opentelemetry.io/docs/specs/semconv/general/metrics/",
                        ),
                    )
                )
                break

        return findings

    def _analyze_otel_span_metric_dimension(
        self,
        dim_name: str,
        processor_name: str,
        file_path: Path,
        source_lines: list[str],
    ) -> list[Finding]:
        """Analyze a spanmetrics dimension for cardinality risks."""
        findings: list[Finding] = []
        for kw in self.config.yaml.dangerous_label_keys:
            if kw in dim_name.lower():
                line_no = _find_line_number(source_lines, dim_name)
                findings.append(
                    Finding(
                        file_path=str(file_path),
                        line_number=line_no,
                        severity=Severity.CRITICAL,
                        category=FindingCategory.UNSAFE_PROCESSOR,
                        rule_id=RULE_OTEL_SPAN_METRIC_DIMENSION,
                        language="yaml",
                        message=(
                            f"OTel spanmetrics processor '{processor_name}': dimension '{dim_name}' "
                            f"matches dangerous keyword '{kw}'. Span-to-metric dimensions must be "
                            "bounded — each unique value produces a new metric series."
                        ),
                        metric_name=processor_name,
                        label_or_tag_name=dim_name,
                        offending_code_snippet=f"dimensions:\n  - name: {dim_name}",
                        economic_impact=EconomicImpact(
                            estimated_series_increase=1_000_000,
                            risk_description=(
                                "SpanMetrics converts traces to RED metrics. An unbounded "
                                "dimension like user_id creates 1 metric series per user_id "
                                "per service — this can exhaust Prometheus storage within hours."
                            ),
                            estimated_monthly_cost_usd=500.0,
                        ),
                        remediation=RemediationSuggestion(
                            description=(
                                f"Remove '{dim_name}' from spanmetrics dimensions. "
                                "Only include dimensions with a known, small, bounded cardinality "
                                "(e.g., http.method, http.status_code, service.name)."
                            ),
                            code_before=f"dimensions:\n  - name: {dim_name}",
                            code_after=(
                                "dimensions:\n"
                                "  - name: http.method       # ✓ Bounded: GET/POST/...\n"
                                "  - name: http.status_code  # ✓ Bounded: 200/400/500/...\n"
                                f"  # Removed: {dim_name}    # ✗ Unbounded"
                            ),
                            docs_url="https://opentelemetry.io/docs/collector/transforming-telemetry/",
                        ),
                    )
                )
                break
        return findings

    # ─────────────────────────────────────────────────────────
    # Generic dangerous label key scanner
    # ─────────────────────────────────────────────────────────

    def _scan_dangerous_label_keys(
        self,
        data: dict[str, Any],
        file_path: Path,
        source_lines: list[str],
    ) -> list[Finding]:
        """
        Generic scan for dangerous label key names in any monitoring YAML.

        Walks the entire YAML structure looking for dictionary keys that
        match the configured dangerous label keywords. This catches issues
        in Datadog agent configs, Grafana Alloy, Vector, and other tools
        not otherwise covered by format-specific rules.

        Args:
            data: Parsed YAML object.
            file_path: Source file path.
            source_lines: Raw source lines for line number lookup.

        Returns:
            List of generic dangerous-key findings.
        """
        findings: list[Finding] = []
        dangerous_keys = self.config.yaml.dangerous_label_keys

        for path, value in _walk_yaml(data):
            if not path:
                continue

            last_key = path[-1].lower()
            # Only inspect values that look like label configurations (dict with label keys)
            # and skip deeply nested structures that are obviously not label configs
            if last_key in (
                "labels",
                "tags",
                "attributes",
                "dimensions",
                "extra_labels",
            ):
                if isinstance(value, dict):
                    for label_key, label_value in value.items():
                        for kw in dangerous_keys:
                            if kw in str(label_key).lower():
                                line_no = _find_line_number(
                                    source_lines, str(label_key)
                                )
                                findings.append(
                                    Finding(
                                        file_path=str(file_path),
                                        line_number=line_no,
                                        severity=Severity.MEDIUM,
                                        category=FindingCategory.UNBOUNDED_TAG,
                                        rule_id=RULE_DANGEROUS_LABEL_KEY,
                                        language="yaml",
                                        message=(
                                            f"Label key '{label_key}' at path "
                                            f"'{'.'.join(str(p) for p in path)}' "
                                            f"matches dangerous keyword '{kw}'. "
                                            "Verify this label's cardinality before deployment."
                                        ),
                                        label_or_tag_name=str(label_key),
                                        offending_code_snippet=f"{label_key}: {label_value}",
                                        economic_impact=EconomicImpact(
                                            estimated_series_increase=10_000,
                                            risk_description="Generic label cardinality risk.",
                                        ),
                                        remediation=RemediationSuggestion(
                                            description=(
                                                f"Remove or replace label '{label_key}' with a bounded "
                                                "alternative. If needed for log correlation, use "
                                                "structured logging instead."
                                            ),
                                        ),
                                    )
                                )
                                break  # One finding per label key

        return findings
