"""
MetricGuard Git Diff Utility.

Provides differential scanning capability — instead of scanning an entire
repository on every commit, this utility extracts the set of files changed
in a Git diff and returns only paths matching the supported scanner extensions.

This is the mechanism behind the `--diff` CLI flag, which dramatically reduces
CI scan time in large monorepos by focusing analysis on code that actually changed
in the current PR. This is especially important for compliance gates: only new or
modified code needs to conform to cardinality standards; existing code can be
addressed via a separate remediation backlog.

Design Decisions:
    - Uses subprocess to call the system `git` binary rather than importing
      a Python Git library. This avoids adding heavy dependencies (GitPython,
      pygit2) and ensures compatibility with all Git versions in CI environments.
    - Falls back gracefully if Git is not installed or the directory is not
      a Git repository, returning an empty set (which causes the CLI to fall
      back to full directory scanning).
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

# File status codes from `git diff --name-status` that indicate the file has changed code
_CHANGED_STATUSES: frozenset[str] = frozenset(
    [
        "A",  # Added
        "M",  # Modified
        "R",  # Renamed (file was moved, but content may have changed)
        "C",  # Copied
    ]
)


class GitDiffUtil:
    """
    Utility for extracting changed file paths from a Git repository.

    Wraps Git CLI commands to provide a clean Python interface for differential
    file discovery. Designed to be fault-tolerant: any Git error results in an
    empty set, not an exception, so the CLI can always fall back to full scanning.

    Usage:
        util = GitDiffUtil(repo_root=Path("."))

        # Get files changed vs. main branch (typical PR usage)
        changed = util.get_changed_files(base_ref="origin/main")

        # Get files changed in the last commit (post-merge usage)
        changed = util.get_changed_files(base_ref="HEAD~1")

        # Get currently staged files only
        changed = util.get_staged_files()
    """

    def __init__(self, repo_root: Path) -> None:
        """
        Initialize the Git diff utility for a repository.

        Args:
            repo_root: The root directory of the Git repository. This directory
                       must contain a `.git` folder (or be within one).
        """
        self._repo_root = repo_root

    def get_changed_files(
        self,
        base_ref: str = "HEAD",
        head_ref: str = "HEAD",
        extensions: set[str] | None = None,
    ) -> set[Path]:
        """
        Get the set of files changed between two Git refs.

        Uses `git diff --name-status` which provides both the change type
        and the file path in a machine-parseable format. Handles renamed
        files correctly by extracting the destination path.

        Args:
            base_ref: The base Git reference (e.g., 'origin/main', 'HEAD~1').
                      Defaults to 'HEAD', which compares staged vs working tree.
            head_ref: The head Git reference. Set to 'HEAD' for committed changes,
                      or omit for staged changes vs. base_ref.
            extensions: If provided, only return files with these extensions
                        (e.g., {'.py', '.yml'}). Returns all changed files if None.

        Returns:
            Set of absolute Path objects for changed files that exist on disk.
        """
        try:
            # `git diff --name-status BASE HEAD` lists changed files between refs
            cmd = [
                "git",
                "-C",
                str(self._repo_root),
                "diff",
                "--name-status",
                base_ref,
                head_ref,
            ]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                logger.warning(
                    "git diff failed (exit %d): %s",
                    result.returncode,
                    result.stderr.strip(),
                )
                return set()

            return self._parse_name_status_output(result.stdout, extensions)

        except FileNotFoundError:
            logger.warning(
                "Git is not installed or not on PATH. Differential scanning is unavailable."
            )
            return set()
        except subprocess.TimeoutExpired:
            logger.warning("git diff timed out. Falling back to full scan.")
            return set()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Unexpected error running git diff: %s", exc)
            return set()

    def get_staged_files(self, extensions: set[str] | None = None) -> set[Path]:
        """
        Get files currently staged in the Git index (git add).

        Useful for pre-commit hook integrations where you want to scan
        only the files in the current commit.

        Args:
            extensions: Optional filter by file extension.

        Returns:
            Set of absolute Path objects for staged files.
        """
        try:
            result = subprocess.run(
                [
                    "git",
                    "-C",
                    str(self._repo_root),
                    "diff",
                    "--cached",
                    "--name-status",
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                logger.warning("git diff --cached failed: %s", result.stderr.strip())
                return set()
            return self._parse_name_status_output(result.stdout, extensions)
        except (FileNotFoundError, subprocess.TimeoutExpired, Exception) as exc:
            logger.warning("Failed to get staged files: %s", exc)
            return set()

    def get_files_in_commit_range(
        self,
        base_sha: str,
        head_sha: str = "HEAD",
        extensions: set[str] | None = None,
    ) -> set[Path]:
        """
        Get all files changed across a range of commits.

        Used in GitHub Actions context where the event provides a
        `base_sha` and `head_sha` for the push or pull request event.

        Args:
            base_sha: The start of the commit range (e.g., ${{ github.event.before }}).
            head_sha: The end of the commit range (defaults to HEAD).
            extensions: Optional file extension filter.

        Returns:
            Set of absolute Path objects for changed files.
        """
        return self.get_changed_files(
            base_ref=base_sha,
            head_ref=head_sha,
            extensions=extensions,
        )

    def is_git_repo(self) -> bool:
        """
        Check if the configured repo_root is inside a Git repository.

        Returns:
            True if `git rev-parse --git-dir` succeeds.
        """
        try:
            result = subprocess.run(
                ["git", "-C", str(self._repo_root), "rev-parse", "--git-dir"],
                capture_output=True,
                timeout=5,
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def _parse_name_status_output(
        self,
        output: str,
        extensions: set[str] | None = None,
    ) -> set[Path]:
        """
        Parse the output of `git diff --name-status` into absolute paths.

        The format is:
          M    path/to/modified_file.py
          A    path/to/added_file.py
          D    path/to/deleted_file.py
          R100 old/path.py    new/path.py   (renamed, 100% similarity)

        We ignore Deleted files (D) since they don't exist on disk anymore.
        For Renamed files, we keep the destination path (new location).

        Args:
            output: Raw stdout from `git diff --name-status`.
            extensions: Optional file extension allowlist.

        Returns:
            Set of absolute Paths for existing, changed files.
        """
        changed_files: set[Path] = set()

        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue

            parts = line.split("\t")
            if len(parts) < 2:
                continue

            status_code = parts[0].upper()

            # Extract the relevant file path
            if status_code.startswith("R") or status_code.startswith("C"):
                # Renamed/copied: parts[1] = old path, parts[2] = new path
                filepath_str = parts[2] if len(parts) > 2 else parts[1]
            elif status_code.startswith("D"):
                # Deleted files don't exist anymore — skip
                continue
            else:
                # Added, Modified, or other
                filepath_str = parts[1]

            # Only include known changed statuses (skip Deleted, Unmerged, etc.)
            status_letter = status_code[0]
            if status_letter not in _CHANGED_STATUSES:
                continue

            file_path = (self._repo_root / filepath_str).resolve()

            # Extension filter
            if extensions and file_path.suffix.lower() not in extensions:
                continue

            # Only include files that actually exist (ignore false pathnames)
            if file_path.exists() and file_path.is_file():
                changed_files.add(file_path)

        return changed_files
