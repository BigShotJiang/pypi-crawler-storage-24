"""
MetricGuard SARIF Exporter.

Converts MetricGuard Finding objects into valid SARIF (Static Analysis
Results Interchange Format) JSON, enabling seamless integration with
GitHub Advanced Security (Code Scanning), Azure DevOps, and any other
SARIF-compatible security tooling.

SARIF 2.1.0 Specification:
    https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html

GitHub Code Scanning Integration:
    When the SARIF output is uploaded via `github/codeql-action/upload-sarif`,
    findings appear as GitHub Code Scanning alerts directly in pull requests,
    with inline annotations on the offending lines.

Key SARIF Concepts Used:
    - `tool.driver`: Describes MetricGuard itself (rules, version, URI).
    - `run.results`: One result object per Finding.
    - `result.locations`: File + line + column for editor integration.
    - `result.fixes`: Machine-readable suggested code fixes.
    - `result.suppressions`: For false_positive_candidate findings.
    - `result.fingerprints`: Deterministic hash for suppression persistence.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from metricguard.models.finding import Finding, Severity

__all__ = ["SarifExporter"]

# SARIF 2.1.0 schema URL — required by the spec for validation
_SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json"
_SARIF_VERSION = "2.1.0"

# MetricGuard tool metadata for SARIF `tool.driver`
_TOOL_NAME = "MetricGuard"
_TOOL_VERSION = "1.0.0"
_TOOL_INFORMATION_URI = "https://github.com/Yossi-Cohen19/MetricGuard"

# Severity level → SARIF `level` mapping
_SEVERITY_TO_SARIF_LEVEL: dict[Severity, str] = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "none",
}

# SARIF security severity scores (0.0–10.0), for GitHub security dashboard
_SEVERITY_TO_SECURITY_SCORE: dict[Severity, float] = {
    Severity.CRITICAL: 9.5,
    Severity.HIGH: 7.5,
    Severity.MEDIUM: 5.0,
    Severity.LOW: 2.5,
    Severity.INFO: 0.0,
}


class SarifExporter:
    """
    Converts a list of MetricGuard Finding objects into a SARIF 2.1.0 document.

    The exporter builds a complete, spec-compliant SARIF log including:
      - Full rule definitions (one per unique rule_id) with help text.
      - Result objects with precise physical locations.
      - Code flow / fix suggestions where available.
      - Suppression markers for false-positive candidates.
      - Fingerprints for stable alert identity across CI runs.

    Usage:
        exporter = SarifExporter(findings, base_path=repo_root)
        sarif_json = exporter.export()
        Path("results.sarif").write_text(sarif_json)
    """

    def __init__(
        self,
        findings: list[Finding],
        base_path: Path | None = None,
        tool_version: str = _TOOL_VERSION,
    ) -> None:
        """
        Initialize the exporter with findings and repository context.

        Args:
            findings: All Finding objects from a scan run.
            base_path: Repository root path. If provided, file paths in the
                       SARIF output will be relativized to this path, making
                       the SARIF portable across machines.
            tool_version: MetricGuard version string embedded in the SARIF.
        """
        self._findings = findings
        self._base_path = base_path
        self._tool_version = tool_version

    def export(self, indent: int = 2) -> str:
        """
        Generate a SARIF 2.1.0 JSON string from the stored findings.

        Args:
            indent: JSON indentation level (default 2 for readability).

        Returns:
            A formatted JSON string that is valid SARIF 2.1.0.
        """
        sarif_log = self._build_sarif_log()
        return json.dumps(sarif_log, indent=indent, ensure_ascii=False)

    def export_to_file(self, output_path: Path, indent: int = 2) -> None:
        """
        Write the SARIF output directly to a file.

        Args:
            output_path: Destination path for the .sarif/.json file.
            indent: JSON indentation level.
        """
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(self.export(indent=indent), encoding="utf-8")

    def _build_sarif_log(self) -> dict[str, Any]:
        """Build the top-level SARIF log object."""
        rules = self._build_rules()
        results = [self._finding_to_result(f) for f in self._findings]

        return {
            "$schema": _SARIF_SCHEMA,
            "version": _SARIF_VERSION,
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": _TOOL_NAME,
                            "version": self._tool_version,
                            "informationUri": _TOOL_INFORMATION_URI,
                            "organization": "MetricGuard",
                            "shortDescription": {
                                "text": "Shift-Left FinOps static analysis tool for cardinality explosion prevention."
                            },
                            "fullDescription": {
                                "text": (
                                    "MetricGuard analyzes application code and infrastructure "
                                    "configurations to detect cardinality explosion risks in "
                                    "monitoring systems (Prometheus, Datadog, OpenTelemetry) "
                                    "before they reach production."
                                )
                            },
                            "rules": rules,
                            "properties": {
                                "tags": [
                                    "finops",
                                    "observability",
                                    "cardinality",
                                    "security",
                                ],
                            },
                        }
                    },
                    "invocations": [
                        {
                            "executionSuccessful": True,
                            "endTimeUtc": datetime.now(UTC).isoformat(),
                        }
                    ],
                    "results": results,
                    "columnKind": "unicodeCodePoints",
                }
            ],
        }

    def _build_rules(self) -> list[dict[str, Any]]:
        """
        Build the SARIF `rules` array from unique rule IDs in findings.

        Each unique rule_id becomes one `reportingDescriptor` entry, with
        full help text and security severity scores for GitHub integration.

        Returns:
            List of SARIF reportingDescriptor dicts.
        """
        seen_rules: dict[str, Finding] = {}
        # Keep one representative finding per rule for metadata
        for finding in self._findings:
            if finding.rule_id not in seen_rules:
                seen_rules[finding.rule_id] = finding

        rules: list[dict[str, Any]] = []
        for rule_id, representative in seen_rules.items():
            rules.append(self._build_rule(rule_id, representative))

        return rules

    def _build_rule(self, rule_id: str, finding: Finding) -> dict[str, Any]:
        """
        Build a SARIF `reportingDescriptor` for a single rule.

        Args:
            rule_id: The unique rule identifier (e.g., 'MG-PY-001').
            finding: A representative finding to extract metadata from.

        Returns:
            A SARIF reportingDescriptor dict.
        """
        security_score = _SEVERITY_TO_SECURITY_SCORE.get(finding.severity, 0.0)
        sarif_level = _SEVERITY_TO_SARIF_LEVEL.get(finding.severity, "note")

        help_text = self._build_rule_help_text(rule_id, finding)
        rule_name = self._rule_id_to_name(rule_id)

        return {
            "id": rule_id,
            "name": rule_name,
            "shortDescription": {
                "text": f"[{finding.severity.value.upper()}] {finding.category.value.replace('_', ' ').title()}"
            },
            "fullDescription": {
                "text": (
                    f"MetricGuard rule {rule_id}: Detects {finding.category.value.replace('_', ' ')} "
                    f"that can cause cardinality explosion in monitoring systems."
                )
            },
            "helpUri": (
                finding.remediation.docs_url
                if finding.remediation and finding.remediation.docs_url
                else _TOOL_INFORMATION_URI
            ),
            "help": {
                "text": help_text,
                "markdown": self._build_rule_help_markdown(rule_id, finding),
            },
            "defaultConfiguration": {
                "level": sarif_level,
                "enabled": True,
            },
            "properties": {
                "tags": [
                    "finops",
                    "cardinality",
                    finding.language,
                    finding.category.value,
                ],
                "security-severity": str(security_score),
                "precision": (
                    "medium" if finding.is_false_positive_candidate else "high"
                ),
                "problem.severity": finding.severity.value,
            },
        }

    @staticmethod
    def _rule_id_to_name(rule_id: str) -> str:
        """Convert a rule ID like 'MG-PY-001' to a CamelCase name."""
        names = {
            "MG-PY-001": "DynamicLabelValue",
            "MG-PY-002": "FStringLabelValue",
            "MG-PY-003": "TaintedVariableLabel",
            "MG-PY-004": "DangerousKeywordLabel",
            "MG-YAML-001": "DangerousRelabelConfig",
            "MG-YAML-002": "HighCardinalitySourceLabel",
            "MG-YAML-003": "LabelMapWildcard",
            "MG-YAML-004": "OtelUnsafeAttributeProcessor",
            "MG-YAML-005": "OtelSpanMetricUnboundedDimension",
            "MG-YAML-006": "DangerousLabelKeyInConfig",
            "MG-AWS-PY-001": "AwsDynamicDimensionValue",
            "MG-AWS-INF-001": "AwsAppendDimensionsDangerous",
            "MG-AWS-INF-002": "AwsDynamicNamespace",
            "MG-GCP-PY-001": "GcpDynamicLabelValue",
            "MG-AZR-PY-001": "AzureDynamicCustomDimension",
            "MG-STAT-PY-001": "StatsDDynamicTagElement",
            "MG-TEL-INF-001": "TelegrafGlobalTagHighCardinality",
            "MG-TEL-INF-002": "TelegrafRegexProcessorDangerousKey",
        }
        return names.get(rule_id, rule_id.replace("-", ""))

    @staticmethod
    def _build_rule_help_text(rule_id: str, finding: Finding) -> str:
        """Build plain-text help for a rule."""
        lines = [
            f"Rule: {rule_id}",
            f"Category: {finding.category.value}",
            f"Severity: {finding.severity.value.upper()}",
            "",
            "This MetricGuard rule detects potential cardinality explosion risks in your "
            "monitoring configuration. Cardinality explosion occurs when metric labels or tags "
            "contain unbounded values (e.g., user IDs, request IDs, UUIDs), causing monitoring "
            "systems to create an exponentially growing number of time series.",
            "",
            "Impact: Excessive cardinality leads to increased storage costs, degraded query "
            "performance, and in severe cases, OOM crashes of Prometheus or other TSDB systems.",
        ]
        if finding.remediation and finding.remediation.description:
            lines.append("")
            lines.append(f"Suggested Fix: {finding.remediation.description}")
        return "\n".join(lines)

    @staticmethod
    def _build_rule_help_markdown(rule_id: str, finding: Finding) -> str:
        """Build GitHub-flavored Markdown help for a rule."""
        lines = [
            f"## 🔴 MetricGuard: `{rule_id}`",
            "",
            f"**Severity:** `{finding.severity.value.upper()}`  ",
            f"**Category:** `{finding.category.value}`  ",
            f"**Language:** `{finding.language}`",
            "",
            "### What is Cardinality Explosion?",
            "",
            "Cardinality explosion occurs when metric labels or tags contain **unbounded values** "
            "(e.g., `user_id`, `request_id`, `uuid`). Each unique label value combination creates "
            "a new **time series** in Prometheus or a new **custom metric** in Datadog/OTel.",
            "",
            "### Impact",
            "",
            "| Risk | Description |",
            "|------|-------------|",
            "| 💰 Cost | Dramatically increased monitoring storage & ingestion costs |",
            "| 🐌 Performance | Slow queries, high scrape latency, OOM errors |",
            "| 🔴 Reliability | TSDB thrashing, Prometheus crashes, missed alerts |",
            "",
        ]
        if finding.remediation:
            lines += [
                "### Suggested Fix",
                "",
                finding.remediation.description,
                "",
            ]
            if finding.remediation.code_before and finding.remediation.code_after:
                lines += [
                    "**Before:**",
                    f"```\n{finding.remediation.code_before}\n```",
                    "",
                    "**After:**",
                    f"```\n{finding.remediation.code_after}\n```",
                    "",
                ]
            if finding.remediation.docs_url:
                lines.append(f"📚 [Learn more]({finding.remediation.docs_url})")

        if finding.economic_impact:
            ei = finding.economic_impact
            cost_str = (
                f"${ei.estimated_monthly_cost_usd:,.2f}"
                if ei.estimated_monthly_cost_usd is not None
                else "N/A"
            )
            series_str = f"{ei.estimated_series_increase:,}"
            archetype = ei.cardinality_archetype or "unknown"
            platform = (ei.platform or "prometheus").replace("_", " ").title()
            lines += [
                "",
                "### 💰 Financial Impact Estimate",
                "",
                "| Attribute | Value |",
                "|---|---|",
                f"| Estimated Additional Series | `{series_str}` |",
                f"| Estimated Monthly Cost | `{cost_str}` |",
                f"| Cardinality Archetype | `{archetype}` |",
                f"| Platform | `{platform}` |",
                "",
                "> ⚠️ Estimates are heuristic. Actual costs depend on query patterns and data retention.",
            ]

        return "\n".join(lines)

    def _finding_to_result(self, finding: Finding) -> dict[str, Any]:
        """
        Convert a single Finding to a SARIF `result` object.

        Args:
            finding: The Finding to convert.

        Returns:
            A SARIF result dict with location, message, fixes, and fingerprints.
        """
        sarif_level = _SEVERITY_TO_SARIF_LEVEL.get(finding.severity, "note")
        artifact_uri = self._make_artifact_uri(finding.file_path)

        # Build enriched message text — embed dollar cost if available
        message_text = finding.message
        if (
            finding.economic_impact
            and finding.economic_impact.estimated_monthly_cost_usd is not None
        ):
            ei = finding.economic_impact
            cost_str = f"${ei.estimated_monthly_cost_usd:,.2f}/month"
            series_str = f"{ei.estimated_series_increase:,}"
            message_text = (
                f"{finding.message} "
                f"[Estimated cost: {cost_str} · {series_str} extra series · "
                f"archetype: {ei.cardinality_archetype or 'unknown'}]"
            )

        result: dict[str, Any] = {
            "ruleId": finding.rule_id,
            "level": sarif_level,
            "message": {
                "text": message_text,
            },
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": artifact_uri,
                            "uriBaseId": "%SRCROOT%",
                        },
                        "region": {
                            "startLine": finding.line_number,
                            "startColumn": finding.column_number,
                        },
                    }
                }
            ],
            "fingerprints": {
                "metricguardFingerprint/v1": finding.fingerprint,
            },
            "properties": {
                "metricName": finding.metric_name,
                "labelOrTagName": finding.label_or_tag_name,
                "taintSource": finding.taint_source,
                "isFalsePositiveCandidate": finding.is_false_positive_candidate,
            },
        }

        # Add code snippet context if available
        if finding.offending_code_snippet:
            result["locations"][0]["physicalLocation"]["region"]["snippet"] = {
                "text": finding.offending_code_snippet,
            }

        # Add economic impact as a related location (informational)
        if finding.economic_impact:
            result["properties"][
                "estimatedSeriesIncrease"
            ] = finding.economic_impact.estimated_series_increase
            result["properties"][
                "estimatedMonthlyCostUsd"
            ] = finding.economic_impact.estimated_monthly_cost_usd

        # Mark false positive candidates as suppressed (GitHub can auto-dismiss)
        if finding.is_false_positive_candidate:
            result["suppressions"] = [
                {
                    "kind": "inSource",
                    "status": "underReview",
                    "justification": finding.false_positive_reason
                    or "Flagged by taint analysis heuristic, manual review recommended.",
                }
            ]

        # Add machine-readable fix if remediation code is available
        if finding.remediation and finding.remediation.code_after:
            artifact_changes: list[dict[str, Any]] = []
            if finding.remediation.code_before and finding.remediation.code_after:
                # Provide before/after as descriptive text replacement
                artifact_changes = [
                    {
                        "artifactLocation": {
                            "uri": artifact_uri,
                            "uriBaseId": "%SRCROOT%",
                        },
                        "replacements": [
                            {
                                "deletedRegion": {
                                    "startLine": finding.line_number,
                                    "startColumn": finding.column_number,
                                },
                                "insertedContent": {
                                    "text": finding.remediation.code_after,
                                },
                            }
                        ],
                    }
                ]
            result["fixes"] = [
                {
                    "description": {
                        "text": finding.remediation.description,
                        "markdown": (
                            f"**Fix for {finding.rule_id}:**\n\n"
                            + (
                                f"**Before:**\n```\n{finding.remediation.code_before}\n```\n\n"
                                if finding.remediation.code_before
                                else ""
                            )
                            + f"**After:**\n```\n{finding.remediation.code_after}\n```"
                        ),
                    },
                    "artifactChanges": artifact_changes,
                }
            ]

        return result

    def _make_artifact_uri(self, file_path: str) -> str:
        """
        Convert an absolute file path to a SARIF-compatible artifact URI.

        If a base_path was provided, returns a relative path (POSIX format).
        Otherwise returns the absolute path as-is. GitHub Code Scanning
        requires relative paths from the repository root to correctly link
        findings to the source file.

        Args:
            file_path: The absolute or relative file path string.

        Returns:
            A POSIX-formatted path string for the SARIF artifact URI.
        """
        path = Path(file_path)
        if self._base_path:
            try:
                return path.relative_to(self._base_path).as_posix()
            except ValueError:
                pass  # File is outside base_path, use absolute
        return path.as_posix()
