"""
MetricGuard Financial Impact Calculator.

Enriches a raw ``Finding`` from any scanner with precise economic impact
estimates — answering the CFO question: *"How much is this costing us?"*

Architecture
────────────
The calculator is a pure post-processor. It:
  1. Classifies the finding by **cardinality archetype**, inferred from the
     label/tag name and the offending expression.
  2. Maps the archetype to an **estimated series count** (heuristic).
  3. Selects the correct **cost-per-series** based on the monitoring platform
     (inferred from the rule ID prefix).
  4. Returns a new ``Finding`` with ``economic_impact`` fully populated.

No scanners are modified; the entire enrichment pipeline is additive.

Archetype Tiers
───────────────
  UUID / request_id / trace_id / email: ~10,000,000 series
      Each event or user creates a unique series. At production scale this
      converts every metric into a write-once cardinality bomb.

  user_id / session_id / account_id: ~1,000,000 series
      Bounded by user base, but user bases scale to millions.

  URL path / hostname / endpoint / IP: ~100,000 series
      Bounded by the application's route surface, but still very large.

  HTTP status / region / environment: ~50 series
      Genuinely finite, well-known enumeration.

  Unknown dynamic (default): ~10,000 series
      Conservative estimate for any dynamic expression not matching above.

Platform Pricing (published rates, 2026)
─────────────────────────────────────────
  Prometheus / Grafana Cloud: $0.0065 / active series / month
      (Grafana Cloud Pro: $6.50 per 1,000 series beyond free tier)
  Datadog custom metrics:     $0.05   / unique metric+tag-set / month
      ($5.00 per 100 custom metrics overage — unchanged since 2024)
  AWS CloudWatch:             $0.30   / metric / month (first 10k)
      Tiered: $0.10 next 240k · $0.05 next 750k · $0.02 over 1M
  GCP Cloud Monitoring:       $0.258  / MiB ingested (≈ $0.01/series proxy)
      150 MiB/month free; billing model is ingestion-based, not per-series
  Azure Monitor custom:       $0.10   / active time series / month
      (upgraded from preview to GA pricing in 2025)
  InfluxDB Cloud / Telegraf:  $0.005  / series / month
      (InfluxDB Cloud Serverless, usage-based tier)
"""

from __future__ import annotations

import re

from metricguard.models.finding import EconomicImpact, Finding, Severity

__all__ = ["ImpactCalculator", "CardinalityArchetype"]

# ─────────────────────────────────────────────────────────────────────
# Cardinality Archetype classification
# ─────────────────────────────────────────────────────────────────────

# Ordered from highest → lowest cardinality so first match wins
_ARCHETYPE_PATTERNS: list[tuple[str, int, str]] = [
    # (regex for label key OR value str, estimated_series, archetype_name)
    (
        r"uuid|request.?id|req.?id|transaction.?id|correlation.?id|trace.?id|span.?id",
        10_000_000,
        "uuid_request_id",
    ),
    (r"email|e.?mail", 5_000_000, "email"),
    (
        r"user.?id|account.?id|customer.?id|member.?id|owner.?id|actor.?id",
        1_000_000,
        "user_id",
    ),
    (r"session.?id|device.?id|client.?id|ip.?addr|ip$|\bip\b", 500_000, "session_id"),
    (r"url|path|endpoint|route|uri|href|filename|file.?name", 100_000, "url_path"),
    (
        r"host(name)?|pod.?name|container.?id|node.?name|instance.?id",
        50_000,
        "hostname",
    ),
    (r"f[\'\"]|jinja|template|\$\{|format\(", 10_000, "dynamic_template"),
    (
        r"env(ironment)?|region|az|availability.?zone|datacenter|cluster",
        20,
        "environment",
    ),
    (r"http.?status|status.?code|response.?code|grpc.?code", 50, "http_status"),
    (r"method|verb|http.?method", 10, "http_method"),
]

_ARCHETYPE_RE = [
    (re.compile(pat, re.IGNORECASE), count, name)
    for pat, count, name in _ARCHETYPE_PATTERNS
]

# Default: unknown dynamic value, conservative estimate
_DEFAULT_ARCHETYPE_NAME = "unknown_dynamic"
_DEFAULT_SERIES = 10_000

# ─────────────────────────────────────────────────────────────────────
# Platform pricing (USD per active series per month)
# ─────────────────────────────────────────────────────────────────────

# Map rule_id prefix → (platform_name, cost_per_series_usd)
# Rates sourced from published 2026 pricing pages.
_PLATFORM_PRICING: list[tuple[str, str, float]] = [
    # Most specific prefixes first
    # AWS CloudWatch: $0.30/metric/month for first 10,000 custom metrics.
    # Tiered beyond that: $0.10 (next 240k) → $0.05 (next 750k) → $0.02 (>1M).
    # We use first-tier price as the conservative worst-case for small accounts.
    ("MG-AWS", "aws_cloudwatch", 0.30),
    # GCP Cloud Monitoring: ingestion-based ($0.258/MiB); $0.01 is a
    # per-series proxy assuming ~40 bytes/sample × 4 samples/min.
    ("MG-GCP", "gcp_monitoring", 0.01),
    # Azure Monitor: $0.10/active time series/month (GA pricing, 2025).
    # Previously $0.013 during public preview — now 7.7× higher at GA.
    ("MG-AZR", "azure_monitor", 0.10),
    # Datadog: $5.00/100 custom metrics/month overage = $0.05/metric.
    # A custom metric = unique (metric_name, tag_set) combination.
    ("MG-STAT", "datadog_statsd", 0.05),
    # Telegraf → InfluxDB Cloud Serverless: $0.005/series/month (2026 rate).
    ("MG-TEL", "telegraf_influx", 0.005),
    # Prometheus / Grafana Cloud Pro: $6.50/1,000 active series = $0.0065/series.
    # Applies to YAML infra rules and Python app code targeting Prometheus.
    ("MG-YAML", "prometheus", 0.0065),
    ("MG-PY", "prometheus", 0.0065),
    # Semgrep multi-language rules: Go/TS/Java typically emit to Prometheus
    # or Datadog. Use the Prometheus rate as the conservative base.
    ("MG-GO", "prometheus", 0.0065),
    ("MG-TS", "prometheus", 0.0065),
    ("MG-JAVA", "prometheus", 0.0065),
]


def _detect_platform(rule_id: str) -> tuple[str, float]:
    """Return (platform_name, cost_per_series_usd) for a rule ID."""
    for prefix, platform, cost in _PLATFORM_PRICING:
        if rule_id.startswith(prefix):
            return platform, cost
    return "prometheus", 0.0065  # safe default — Grafana Cloud Pro 2026 rate


# ─────────────────────────────────────────────────────────────────────
# Severity multiplier — higher severity → assume higher real-world hit rate
# ─────────────────────────────────────────────────────────────────────

_SEVERITY_MULTIPLIER: dict[Severity, float] = {
    Severity.CRITICAL: 1.0,  # Full estimate — worst-case confirmed
    Severity.HIGH: 0.5,  # 50% of worst-case (high confidence)
    Severity.MEDIUM: 0.2,  # 20% — moderate confidence
    Severity.LOW: 0.05,  # 5%  — speculative
    Severity.INFO: 0.01,  # 1%  — informational only
}


# ─────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────


class CardinalityArchetype:
    """
    Classifies a label/tag name + value expression into a cardinality tier.

    This is the public classification interface, usable independently of the
    full ImpactCalculator for testing or custom integrations.
    """

    @staticmethod
    def classify(
        label_key: str | None,
        value_expr: str | None,
    ) -> tuple[int, str]:
        """
        Determine estimated series count and archetype name.

        Searches the label key first (most reliable signal), then falls back
        to the value expression (catches f-string patterns, interpolations).

        Args:
            label_key: The metric label/tag key name (e.g., "user_id").
            value_expr: The offending expression string (e.g., "f'{user.id}'").

        Returns:
            Tuple of (estimated_series_count, archetype_name).
        """
        for regex, count, name in _ARCHETYPE_RE:
            if label_key and regex.search(label_key):
                return count, name
            if value_expr and regex.search(value_expr):
                return count, name

        return _DEFAULT_SERIES, _DEFAULT_ARCHETYPE_NAME


class ImpactCalculator:
    """
    Enriches ``Finding`` objects with precise financial impact estimates.

    The calculator is stateless and thread-safe — a single instance can be
    shared across the entire CLI pipeline without locking.

    Design:
        ``enrich()`` returns a new ``Finding`` via ``model_copy(update={...})``.
        Original findings are never mutated, preserving scanner output purity.

    Usage::

        calc = ImpactCalculator()
        enriched_findings = [calc.enrich(f) for f in raw_findings]
    """

    def enrich(self, finding: Finding) -> Finding:
        """
        Compute and attach financial impact to a finding.

        Overwrites ``finding.economic_impact`` with a fully-populated
        ``EconomicImpact`` instance. If the finding already has a non-None
        ``economic_impact``, the existing ``estimated_series_increase`` is
        used as a cap (we take the max of our estimate and the scanner's).

        Args:
            finding: Raw finding from any scanner.

        Returns:
            New Finding with economic_impact fully populated.
        """
        archetype_series, archetype_name = CardinalityArchetype.classify(
            finding.label_or_tag_name,
            finding.offending_code_snippet or finding.taint_source,
        )

        severity_mult = _SEVERITY_MULTIPLIER.get(finding.severity, 0.5)
        estimated_series = max(1, int(archetype_series * severity_mult))

        # If the scanner already provided a series estimate, take the max
        # (scanner knows the local context better; we know the global blast radius)
        if (
            finding.economic_impact
            and finding.economic_impact.estimated_series_increase > 0
        ):
            estimated_series = max(
                estimated_series,
                finding.economic_impact.estimated_series_increase,
            )

        platform_name, cost_per_series = _detect_platform(finding.rule_id)
        monthly_cost = round(estimated_series * cost_per_series, 2)

        impact = EconomicImpact(
            estimated_series_increase=estimated_series,
            estimated_monthly_cost_usd=monthly_cost,
            cardinality_archetype=archetype_name,
            platform=platform_name,
            risk_description=self._build_risk_description(
                finding=finding,
                archetype_name=archetype_name,
                estimated_series=estimated_series,
                monthly_cost=monthly_cost,
                platform_name=platform_name,
                cost_per_series=cost_per_series,
            ),
        )

        return finding.model_copy(update={"economic_impact": impact})

    @staticmethod
    def _build_risk_description(
        finding: Finding,
        archetype_name: str,
        estimated_series: int,
        monthly_cost: float,
        platform_name: str,
        cost_per_series: float,
    ) -> str:
        """
        Build a rich, human-readable risk narrative for the finding.

        This text appears in SARIF rule help cards, CLI output, and
        the financial impact section of pull request annotations.
        """
        label = finding.label_or_tag_name or "unknown label"
        rule_id = finding.rule_id
        platform_display = platform_name.replace("_", " ").title()
        series_str = f"{estimated_series:,}"
        cost_str = f"${monthly_cost:,.2f}"

        archetype_descriptions = {
            "uuid_request_id": "Each request/event uniquely identifies itself, creating one series per event",
            "email": "Email addresses span the entire user population size",
            "user_id": "User IDs scale to the full user base size",
            "session_id": "Session/device IDs accumulate across reconnections",
            "url_path": "URL paths grow with application feature surface area",
            "hostname": "Per-instance hostnames multiply with fleet size",
            "dynamic_template": "Dynamic string templates produce unpredictable value spaces",
            "environment": "Environment names are bounded but confirm dynamic origin",
            "http_status": "HTTP status codes form a finite set (~80 values)",
            "http_method": "HTTP methods form a tiny finite set (~9 values)",
            "unknown_dynamic": "Dynamic expression cardinality is unknown at static-analysis time",
        }
        archetype_desc = archetype_descriptions.get(
            archetype_name, "dynamic value cardinality is unbounded"
        )

        return (
            f"Rule {rule_id} detected high-cardinality label '{label}' (archetype: {archetype_name}). "
            f"{archetype_desc}. "
            f"On {platform_display}, each unique label value combination creates a separate time series "
            f"billed at ${cost_per_series}/series/month. "
            f"Estimated blast radius: ~{series_str} additional series → {cost_str}/month."
        )
