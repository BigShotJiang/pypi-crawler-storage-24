"""
MetricGuard Auto-Remediation Engine.

Generates concrete, actionable code fixes for each cardinality finding.
The engine enriches ``RemediationSuggestion`` with ``code_before`` and
``code_after`` fields, which are surfaced in:

  - SARIF ``fixes`` objects (GitHub Code Scanning "Fix" button)
  - CLI console output (``--verbose`` mode)
  - Rule help markdown embedded in GitHub PR annotations

Design
──────
Each rule maps to a **fix generator** function. Fix generators receive the
full ``Finding`` context and return a ``(code_before, code_after)`` tuple.
This is deliberately template-based (no LLM, no network) to guarantee:

  - Deterministic output across scan runs
  - Zero latency / zero external dependencies
  - Correctness for the specific cardinality anti-pattern

Fix Strategy by Rule Category
──────────────────────────────
Python label rules (MG-PY-001, MG-PY-002, MG-GCP-PY-001, MG-AZR-PY-001,
MG-AWS-PY-001, MG-STAT-PY-001):
    Remove the dynamic label from the metric call entirely and add a
    structured log statement that preserves the data for ad-hoc queries.
    This is the canonical industry fix: metrics for aggregation, logs for
    filtering.

YAML relabeling rules (MG-YAML-001 through MG-YAML-006):
    Replace ``action: replace`` with ``action: drop`` OR remove the
    ``target_label`` entry. The YAML fix preserves all other rule fields.

Telegraf TOML rules (MG-TEL-INF-001, MG-TEL-INF-002):
    Remove the dangerous key from ``[global_tags]`` or rename the
    ``result_key`` to a bounded category name.

CloudWatch JSON rules (MG-AWS-INF-001, MG-AWS-INF-002):
    Remove the dimension key from ``append_dimensions`` or replace the
    interpolated namespace with a static string.
"""

from __future__ import annotations

import re
from collections.abc import Callable

from metricguard.models.finding import Finding, RemediationSuggestion

__all__ = ["RemediationEngine"]

# ─────────────────────────────────────────────────────────────────────
# Type alias for fix generators
# ─────────────────────────────────────────────────────────────────────

FixGenerator = Callable[[Finding], tuple[str | None, str | None]]

# ─────────────────────────────────────────────────────────────────────
# Interpolation patterns in expressions
# ─────────────────────────────────────────────────────────────────────

_FSTRING_RE = re.compile(r"f['\"].*?['\"]", re.DOTALL)
_VAR_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_.]*$")


# ─────────────────────────────────────────────────────────────────────
# Fix generators — one per rule family
# ─────────────────────────────────────────────────────────────────────


def _fix_python_dynamic_label(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-PY-001/002/003/004, MG-GCP-PY-001, MG-AZR-PY-001, MG-AWS-PY-001, MG-STAT-PY-001.

    Strategy: strip the dynamic label from the metric call and emit a
    structured log statement instead. Metrics aggregate; logs filter.
    """
    label = finding.label_or_tag_name or "dynamic_label"
    value = finding.taint_source or finding.offending_code_snippet or "dynamic_value"
    metric = finding.metric_name or "your_metric"

    # Detect a clean variable name vs complex expression for the log extra key
    var_name = label.replace("-", "_").replace(".", "_")

    before = "# ⚠️  Dynamic label creates unbounded cardinality\n"
    before += f"metric_obj.labels({label}={value}).inc()"

    after = (
        f"# ✅ Move high-cardinality data to structured logs\n"
        f"import logging\n"
        f"logger = logging.getLogger(__name__)\n\n"
        f"metric_obj.labels({label}='bounded_constant').inc()\n"
        f"logger.info(\n"
        f"    'Metric event recorded',\n"
        f"    extra={{\n"
        f"        'metric': '{metric}',\n"
        f"        '{var_name}': {value},  # ← high-cardinality data lives here\n"
        f"    }},\n"
        f")"
    )
    return before, after


def _fix_python_fstring_label(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-PY-002: f-string used as label value.

    Strategy: extract the f-string expression into a logger call and use
    a static label value in the metric.
    """
    label = finding.label_or_tag_name or "label"
    value = finding.offending_code_snippet or f"f'{{{label}}}'"

    before = "# ⚠️  F-string label causes cardinality explosion\n"
    before += f"metric_obj.labels({label}={value}).observe(duration)"

    after = (
        f"# ✅  Use a constant label; log the dynamic part\n"
        f"metric_obj.labels({label}='static_value').observe(duration)\n"
        f"logger.debug('Metric observed', extra={{'{label}': {value}}})"
    )
    return before, after


def _fix_tainted_variable(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-PY-003: Variable tainted from unbounded source.

    Strategy: add a type guard / allowlist check before the metric call.
    """
    label = finding.label_or_tag_name or "label"
    taint = finding.taint_source or "tainted_var"

    before = (
        f"# ⚠️  Variable '{taint}' originates from user/request input\n"
        f"metric_obj.labels({label}={taint}).inc()"
    )
    after = (
        f"# ✅  Validate against an allowlist before using as label\n"
        f"ALLOWED_{label.upper()}S = frozenset({{'value_a', 'value_b', 'value_c'}})\n"
        f"safe_value = {taint} if {taint} in ALLOWED_{label.upper()}S else 'other'\n"
        f"metric_obj.labels({label}=safe_value).inc()"
    )
    return before, after


def _fix_dangerous_keyword(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-PY-004: Label key itself matches a dangerous high-cardinality keyword.

    Strategy: rename the label to a bounded alternative or drop it.
    """
    label = finding.label_or_tag_name or "dangerous_label"
    value = finding.offending_code_snippet or "value"

    before = (
        f"# ⚠️  Label key '{label}' carries inherently high cardinality data\n"
        f"metric_obj.labels({label}={value}).inc()"
    )
    after = (
        f"# ✅  Replace with a bounded categorical label\n"
        f"# Option 1: Use a category instead of the raw identifier\n"
        f"metric_obj.labels(user_segment='premium').inc()  # or 'free', 'enterprise'\n\n"
        f"# Option 2: Drop the label entirely and correlate via logs\n"
        f"metric_obj.inc()  # label removed\n"
        f"logger.info('Event', extra={{'{label}': {value}}})"
    )
    return before, after


def _fix_yaml_relabel(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-YAML-001 through MG-YAML-006: Dangerous relabel/processor config.

    Strategy: replace `action: replace` with `action: drop` to discard
    the high-cardinality label from the time series entirely.
    """
    label = finding.label_or_tag_name or "high_cardinality_label"
    snippet = finding.offending_code_snippet or ""

    before = (
        f"# ⚠️  Relabeling preserves high-cardinality label '{label}'\n"
        f"- source_labels: [{label}]\n"
        f"  action: replace\n"
        f"  target_label: {label}"
    )

    # If snippet contains 'labelmap', suggest removing the rule entirely
    if "labelmap" in snippet.lower():
        after = (
            "# ✅  Remove labelmap rule or replace with explicit label allowlist\n"
            "# Remove or replace this rule entirely.\n"
            "# If you need some labels, enumerate them explicitly:\n"
            "- source_labels: [__meta_kubernetes_pod_label_app]\n"
            "  action: replace\n"
            "  target_label: app"
        )
    else:
        after = (
            f"# ✅  Drop the high-cardinality label instead of copying it\n"
            f"- source_labels: [{label}]\n"
            f"  action: drop\n"
            f"  # Removed target_label — label is discarded from time series\n\n"
            f"# ✅  Alternative: filter to only known-safe values\n"
            f"- source_labels: [{label}]\n"
            f"  regex: (prod|staging|dev)\n"
            f"  action: keep"
        )
    return before, after


def _fix_aws_cloudwatch_dimension(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-AWS-PY-001: Dynamic CloudWatch Dimension.Value.

    Strategy: use a bounded constant; move dynamic data to CloudWatch Logs.
    """
    label = finding.label_or_tag_name or "DimensionKey"
    value = finding.taint_source or finding.offending_code_snippet or "dynamic_value"

    before = (
        f"# ⚠️  Dynamic Dimension.Value creates one CloudWatch metric stream per unique value\n"
        f"cloudwatch.put_metric_data(\n"
        f"    Namespace='MyApp',\n"
        f"    MetricData=[{{\n"
        f"        'Dimensions': [{{'Name': '{label}', 'Value': {value}}}],\n"
        f"        'Value': 1.0,\n"
        f"    }}]\n"
        f")"
    )
    after = (
        f"# ✅  Use a bounded constant; log the dynamic value via CloudWatch Logs\n"
        f"import logging\n"
        f"logger = logging.getLogger(__name__)\n\n"
        f"cloudwatch.put_metric_data(\n"
        f"    Namespace='MyApp',\n"
        f"    MetricData=[{{\n"
        f"        'Dimensions': [{{'Name': '{label}', 'Value': 'bounded_constant'}}],\n"
        f"        'Value': 1.0,\n"
        f"    }}]\n"
        f")\n"
        f"# Log the high-cardinality identifier for CloudWatch Logs Insights queries\n"
        f"logger.info('Metric recorded', extra={{'{label.lower()}': {value}}})"
    )
    return before, after


def _fix_gcp_label(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-GCP-PY-001: Dynamic labels dict in create_time_series().
    """
    label = finding.label_or_tag_name or "label_key"
    value = finding.taint_source or finding.offending_code_snippet or "dynamic_value"

    before = (
        f"# ⚠️  Dynamic GCP Monitoring label: each unique value = separate time series\n"
        f"series.resource.labels = {{'{label}': {value}}}"
    )
    after = (
        f"# ✅  Use a bounded constant; use Cloud Logging for high-cardinality data\n"
        f"series.resource.labels = {{'{label}': 'bounded_constant'}}\n"
        f"# Log via Cloud Logging for high-cardinality correlation:\n"
        f"logging.info({{'message': 'Metric recorded', '{label}': {value}}})"
    )
    return before, after


def _fix_azure_property(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-AZR-PY-001: Dynamic custom_dimensions in track_metric().
    """
    label = finding.label_or_tag_name or "property_key"
    value = finding.taint_source or finding.offending_code_snippet or "dynamic_value"

    before = (
        f"# ⚠️  Dynamic custom_dimension causes Azure Monitor storage explosion\n"
        f"tc.track_metric('my_metric', 1, properties={{'{label}': {value}}})"
    )
    after = (
        f"# ✅  Use bounded constant; store dynamic data in Log Analytics\n"
        f"tc.track_metric('my_metric', 1, properties={{'{label}': 'bounded_value'}})\n"
        f"# Use Azure Log Analytics for high-cardinality event data:\n"
        f"tc.track_event('MetricEvent', properties={{'{label}': {value}}})"
    )
    return before, after


def _fix_statsd_tag(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-STAT-PY-001: Dynamic tag element in StatsD/DogStatsD tags list.
    """
    label = finding.label_or_tag_name or "tags[0]"
    value = finding.taint_source or finding.offending_code_snippet or "dynamic_value"
    metric = finding.metric_name or "my.metric"

    before = (
        f"# ⚠️  Dynamic tag value in Datadog custom metric\n"
        f"statsd.increment('{metric}', tags=[{value}])"
    )
    after = (
        f"# ✅  Use bounded tag value; log dynamic data to APM traces\n"
        f"statsd.increment('{metric}', tags=['env:prod', 'service:api'])\n"
        f"# Correlate high-cardinality data via APM trace tags:\n"
        f"# span.set_tag('{label.replace('tags[0]', 'dynamic_key')}', {value})"
    )
    return before, after


def _fix_telegraf_global_tag(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-TEL-INF-001: High-cardinality key in [global_tags].
    """
    label = finding.label_or_tag_name or "dangerous_key"
    value = finding.offending_code_snippet or "${DYNAMIC_VALUE}"

    before = (
        f"# ⚠️  [global_tags] applies this tag to ALL metrics from this agent\n"
        f"[global_tags]\n"
        f'  {label} = "{value}"'
    )
    after = (
        f"# ✅  Remove or replace with a static bounded value\n"
        f"[global_tags]\n"
        f'  environment = "production"  # ← static, bounded\n'
        f'  region = "us-east-1"        # ← static, bounded\n'
        f"  # Removed '{label}' — use structured logs for dynamic identifiers"
    )
    return before, after


def _fix_telegraf_regex_processor(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-TEL-INF-002: Regex processor writing to a dangerous result_key.
    """
    label = finding.label_or_tag_name or "result_key"
    pattern = finding.offending_code_snippet or "(?P<extract>[^/]+)"

    before = (
        f"# ⚠️  Regex processor extracts unbounded substring into metric tag\n"
        f"[[processors.regex]]\n"
        f"  [[processors.regex.fields]]\n"
        f'    key = "url"\n'
        f'    pattern = "{pattern}"\n'
        f'    result_key = "{label}"'
    )
    after = (
        "# ✅  Extract a bounded category, not raw identifier\n"
        "[[processors.regex]]\n"
        "  [[processors.regex.fields]]\n"
        '    key = "url"\n'
        '    pattern = "^/api/(?P<api_version>v[0-9]+)/"\n'
        '    result_key = "api_version"  # bounded: v1, v2, v3 only'
    )
    return before, after


def _fix_cloudwatch_append_dimensions(
    finding: Finding,
) -> tuple[str | None, str | None]:
    """
    MG-AWS-INF-001: Dangerous dimension key in append_dimensions.
    """
    label = finding.label_or_tag_name or "DangerousDimension"

    before = (
        f"# ⚠️  append_dimensions applies this to ALL CloudWatch metrics\n"
        f"{{\n"
        f'  "metrics": {{\n'
        f'    "append_dimensions": {{\n'
        f'      "{label}": "${{aws:{label}}}"\n'
        f"    }}\n"
        f"  }}\n"
        f"}}"
    )
    after = (
        f"# ✅  Remove high-cardinality dimension from append_dimensions\n"
        f"{{\n"
        f'  "metrics": {{\n'
        f'    "append_dimensions": {{\n'
        f'      "Environment": "Production",\n'
        f'      "Region": "${{aws:Region}}"  // bounded: ~30 values\n'
        f'      // Removed "{label}" — use CloudWatch resource tags instead\n'
        f"    }}\n"
        f"  }}\n"
        f"}}"
    )
    return before, after


def _fix_cloudwatch_namespace(finding: Finding) -> tuple[str | None, str | None]:
    """
    MG-AWS-INF-002: Dynamic namespace interpolation.
    """
    value = finding.offending_code_snippet or "MyApp/${ENV_NAME}"

    before = (
        f"# ⚠️  Dynamic namespace creates a separate CloudWatch namespace per value\n"
        f'"namespace": "{value}"'
    )
    after = (
        "# ✅  Use a static namespace; encode environment as a Dimension\n"
        '"namespace": "MyApp/Production"  // static — always the same namespace'
    )
    return before, after


def _fix_generic(finding: Finding) -> tuple[str | None, str | None]:
    """
    Fallback fix generator for unknown rule IDs.

    Provides a generic description without code snippets.
    """
    label = finding.label_or_tag_name or "label"
    return (
        f"# ⚠️  High-cardinality label '{label}' detected by {finding.rule_id}\n"
        f"# See finding message for details.",
        (
            "# ✅  Replace dynamic label value with a bounded constant.\n"
            "# For high-cardinality data, use structured logging or APM traces."
        ),
    )


# ─────────────────────────────────────────────────────────────────────
# Rule → fix generator dispatch table
# ─────────────────────────────────────────────────────────────────────

_RULE_FIX_GENERATORS: dict[str, FixGenerator] = {
    "MG-PY-001": _fix_python_dynamic_label,
    "MG-PY-002": _fix_python_fstring_label,
    "MG-PY-003": _fix_tainted_variable,
    "MG-PY-004": _fix_dangerous_keyword,
    "MG-YAML-001": _fix_yaml_relabel,
    "MG-YAML-002": _fix_yaml_relabel,
    "MG-YAML-003": _fix_yaml_relabel,
    "MG-YAML-004": _fix_yaml_relabel,
    "MG-YAML-005": _fix_yaml_relabel,
    "MG-YAML-006": _fix_yaml_relabel,
    "MG-AWS-PY-001": _fix_aws_cloudwatch_dimension,
    "MG-GCP-PY-001": _fix_gcp_label,
    "MG-AZR-PY-001": _fix_azure_property,
    "MG-STAT-PY-001": _fix_statsd_tag,
    "MG-TEL-INF-001": _fix_telegraf_global_tag,
    "MG-TEL-INF-002": _fix_telegraf_regex_processor,
    "MG-AWS-INF-001": _fix_cloudwatch_append_dimensions,
    "MG-AWS-INF-002": _fix_cloudwatch_namespace,
}


# ─────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────


class RemediationEngine:
    """
    Generates concrete code fixes for MetricGuard findings.

    The engine enriches ``finding.remediation`` with ``code_before`` and
    ``code_after`` fields. If the finding already has both fields populated
    (e.g., set by a scanner with precise local context), the engine does
    NOT overwrite them — scanner-provided fixes are always more accurate.

    The engine is stateless and thread-safe.

    Usage::

        engine = RemediationEngine()
        enriched = [engine.enrich(f) for f in findings]
    """

    def enrich(self, finding: Finding) -> Finding:
        """
        Attach a concrete code fix to a finding.

        Args:
            finding: Raw or impact-enriched Finding.

        Returns:
            New Finding with remediation.code_before / code_after populated.
        """
        existing = finding.remediation

        # If scanner already provided a complete fix, respect it
        if existing and existing.code_before and existing.code_after:
            return finding

        # Get the appropriate fix generator
        generator = _RULE_FIX_GENERATORS.get(finding.rule_id, _fix_generic)
        code_before, code_after = generator(finding)

        # Build updated remediation (preserve existing description and docs_url)
        description = (
            existing.description if existing else None
        ) or self._default_description(finding)
        docs_url = existing.docs_url if existing else None

        new_remediation = RemediationSuggestion(
            description=description,
            code_before=code_before,
            code_after=code_after,
            docs_url=docs_url,
        )

        return finding.model_copy(update={"remediation": new_remediation})

    @staticmethod
    def _default_description(finding: Finding) -> str:
        """Generate a default remediation description if none exists."""
        label = finding.label_or_tag_name or "this label"
        return (
            f"Remove or bound the dynamic value for '{label}'. "
            f"Use constants from a finite enum or move high-cardinality "
            f"identifiers to structured logs or APM traces."
        )
