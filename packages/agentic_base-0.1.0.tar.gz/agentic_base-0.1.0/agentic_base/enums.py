from polars import Enum


class EmbeddingPurposeEnum(Enum):
    DOCUMENT = "document"
    QUERY = "query"


class FAISSIndexType(Enum):
    FLAT_IP = "flat_ip"
    FLAT_L2 = "flat_l2"
