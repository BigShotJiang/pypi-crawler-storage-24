from typing import Generic

from agentic_base.settings import FromConfigMixinSettings
from agentic_base.types import TCDatasetConnector, TCTextPreprocessor


class TextIngestionPipelineSettings(FromConfigMixinSettings, Generic[TCDatasetConnector, TCTextPreprocessor]):
    connector: TCDatasetConnector
    preprocessor: TCTextPreprocessor
