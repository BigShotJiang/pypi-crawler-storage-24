import importlib
from typing import TYPE_CHECKING, Any

from pydantic import SecretStr

if TYPE_CHECKING:
    from agentic_base.connector.minio import MinioDatasetConnector
    from agentic_base.connector.parquet import ParquetDatasetConnector


def load_class(path: str) -> Any:
    module_path, class_name = path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def _get_minio_connector(
    bucket: str, key: str, endpoint: str, access_key: str, secret_key: str
) -> "MinioDatasetConnector":
    from agentic_base.connector.minio import MinioDatasetConnector
    from agentic_base.connector.settings import MinioDatasetConnectorSettings

    config = MinioDatasetConnectorSettings(
        module_path="",
        endpoint=endpoint,
        bucket=bucket,
        key=key,
        access_key=SecretStr(access_key),
        secret_key=SecretStr(secret_key),
    )
    return MinioDatasetConnector(config)


def _get_parquet_connector(path: str, *, lazy: bool) -> "ParquetDatasetConnector":
    from agentic_base.connector.parquet import ParquetDatasetConnector
    from agentic_base.connector.settings import ParquetDatasetConnectorSettings

    config = ParquetDatasetConnectorSettings(module_path='', path=path, lazy=lazy)
    return ParquetDatasetConnector(config)
