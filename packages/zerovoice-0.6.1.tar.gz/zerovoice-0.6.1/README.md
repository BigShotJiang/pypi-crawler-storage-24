# ZeroVoice Python 🐍

**AI-powered call center in a pip package** - Natural conversations, concurrent calling, and real-time monitoring.

## 🚀 Quick Start

```bash
# Install from PyPI
pip install zerovoice

# Or install from source
git clone https://github.com/collinparan/zero-voice.git
cd zero-voice/python
pip install .
```

## ⚡ Features

- **🦀 Rust Performance**: Core written in Rust, 10x faster than pure Python
- **🎭 Natural Conversations**: ElevenLabs-style back-and-forth dialogue
- **📞 Concurrent Calls**: Handle 100+ simultaneous calls
- **📊 Web Dashboard**: Beautiful monitoring interface
- **🎯 Simple API**: Pythonic interface for non-Rust developers

## 📖 Basic Usage

### Configure
```python
from zerovoice import configure

configure(
    twilio_sid="your_account_sid",
    twilio_token="your_auth_token",
    twilio_phone="+1234567890",
    webhook_url="https://your-domain.ngrok.io"
)
```

### Make Calls
```python
from zerovoice import CallCenter

# Initialize
center = CallCenter(max_concurrent=10)

# Single call
call_id = center.make_call(
    to_number="+0987654321",
    message="Hello, this is an automated call",
    personality="Alex"  # or "Jamie", "Sam"
)

# Campaign
campaign_id = center.start_campaign(
    phone_numbers=["+111", "+222", "+333"],
    script="Hi {name}, calling about {topic}...",
    personality="Jamie"
)

# Get stats
stats = center.get_stats()
print(f"Success rate: {stats['success_rate']:.1%}")
```

### Natural Conversations
```python
from zerovoice import ConversationManager

# Start conversation
manager = ConversationManager(personality="Alex")
session_id = manager.start_session(
    objectives=["Get feedback", "Schedule follow-up"]
)

# Process dialogue
response = manager.process_turn(
    session_id,
    "Hi, I received your call about my order"
)
print(response['text'])
# "Hello! Yes, I'm calling about your recent order. How was your experience?"
```

### Web Dashboard
```python
from zerovoice.dashboard import run_dashboard

# Launch dashboard
run_dashboard(port=8080)
# Visit http://localhost:8080
```

## 🖥️ Command Line Interface

```bash
# Configure
zerovoice setup --sid YOUR_SID --token YOUR_TOKEN --phone +1234567890

# Make a call
zerovoice call +0987654321 -m "Hello from ZeroVoice" -p Alex

# Launch campaign
zerovoice campaign -f contacts.csv -s "Survey about {product}" -c 20

# View statistics
zerovoice stats

# Call history
zerovoice history --limit 10

# View transcript
zerovoice transcript CALL_ID

# Search calls
zerovoice search +1234567890

# Launch dashboard
zerovoice dashboard --port 8080
```

## 📊 Dashboard Features

The dashboard provides:
- **Real-time Statistics**: Live metrics updated every 5 seconds
- **Call History**: Searchable log of all calls
- **Transcript Viewer**: Read full conversations
- **Quick Dial**: Make calls from the browser
- **Campaign Launcher**: Start bulk calling campaigns
- **Audio Playback**: Listen to call recordings

## 🛠️ Advanced Usage

### Custom Configuration
```python
# Use SQLite database
center = CallCenter(
    max_concurrent=50,
    database_url="sqlite:///path/to/calls.db"
)

# Custom personalities
manager = ConversationManager(personality="Sam")
```

### Webhook Integration
```python
# Process Twilio webhooks
from flask import Flask, request
from zerovoice import CallCenter

app = Flask(__name__)
center = CallCenter()

@app.route('/webhook', methods=['POST'])
def handle_webhook():
    call_data = request.form
    # Process call data
    return "OK"
```

### Batch Operations
```python
# Process CSV file
import csv

with open('contacts.csv') as f:
    reader = csv.DictReader(f)
    numbers = [row['phone'] for row in reader]

campaign_id = center.start_campaign(
    phone_numbers=numbers,
    script="Personalized message...",
    personality="Jamie"
)
```

## 🏗️ Architecture

```
zerovoice/
├── Core (Rust)          # High-performance engine
│   ├── Call management
│   ├── Conversation AI
│   └── Database layer
├── Python Bindings      # PyO3 interface
└── Python Package       # User-friendly API
    ├── CLI
    ├── Dashboard
    └── Utilities
```

## 🔧 Development

### Install for Development
```bash
# Clone repository
git clone https://github.com/collinparan/zero-voice.git
cd zero-voice/python

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Format code
black zerovoice
```

### Building from Source
```bash
# Install maturin
pip install maturin

# Build Rust extension
maturin develop

# Build wheel
maturin build --release
```

## 📋 Requirements

- Python 3.8+
- Twilio Account
- ngrok (for local development)

## 🐳 Docker Support

```bash
# Using pre-built image
docker run -p 8080:8080 zerovoice/dashboard

# Build your own
docker build -t my-zerovoice .
docker run -p 8080:8080 my-zerovoice
```

## 📈 Performance

- **Concurrent Calls**: 100+ simultaneous
- **Response Time**: <100ms per turn
- **Memory Usage**: <50MB for 1000 active calls
- **Database**: SQLite for simplicity, PostgreSQL for scale

## 🤝 Contributing

Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md)

## 📄 License

MIT License - see [LICENSE](LICENSE)

## 🔗 Links

- [GitHub Repository](https://github.com/collinparan/zero-voice)
- [PyPI Package](https://pypi.org/project/zerovoice)
- [Documentation](https://zerovoice.readthedocs.io)
- [Examples](https://github.com/collinparan/zero-voice/tree/main/examples)

## 🆘 Support

- **Issues**: [GitHub Issues](https://github.com/collinparan/zero-voice/issues)
- **Discord**: [Join our server](https://discord.gg/zerovoice)
- **Email**: support@zerovoice.ai

---

Built with ❤️ using Rust 🦀 and Python 🐍