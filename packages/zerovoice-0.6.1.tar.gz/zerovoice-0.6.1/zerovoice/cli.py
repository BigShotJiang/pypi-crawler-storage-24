#!/usr/bin/env python3
"""
ZeroVoice CLI - Command-line interface for the AI-powered call center
"""

import click
import os
from .dashboard import make_twilio_call

@click.group()
def cli():
    """ZeroVoice - AI-powered call center CLI"""
    pass

@cli.command()
@click.option('--port', default=8080, help='Port to run dashboard on')
def dashboard(port):
    """Launch the web dashboard"""
    from .dashboard import app
    click.echo(f"🚀 Starting ZeroVoice Dashboard on http://localhost:{port}")
    app.run(host='0.0.0.0', port=port)

@cli.command()
@click.option('--port', default=3001, help='Port to run webhook server on')
def webhook(port):
    """Launch the webhook server"""
    from .webhook import app
    click.echo(f"🔗 Starting Webhook Server on http://localhost:{port}")
    app.run(host='0.0.0.0', port=port)

@cli.command()
@click.argument('to_number')
@click.option('--message', '-m', default='Hello from ZeroVoice!', help='Initial message')
@click.option('--personality', '-p', default='Alex', type=click.Choice(['Alex', 'Jamie', 'Sam']))
def call(to_number, message, personality):
    """Make a phone call"""
    click.echo(f"📞 Calling {to_number}...")
    result = make_twilio_call(to_number, message, personality)

    if result.get('success'):
        click.echo(f"✅ Call initiated! ID: {result['call_sid']}")
    else:
        click.echo(f"❌ Error: {result.get('error', 'Unknown error')}")

@cli.command()
def setup():
    """Configure Twilio credentials"""
    click.echo("🛠️  ZeroVoice Setup")

    account_sid = click.prompt("Twilio Account SID")
    auth_token = click.prompt("Twilio Auth Token", hide_input=True)
    phone_number = click.prompt("Twilio Phone Number")
    webhook_url = click.prompt("Webhook Base URL", default="http://localhost:3001")

    env_content = f"""# ZeroVoice Configuration
TWILIO_ACCOUNT_SID={account_sid}
TWILIO_AUTH_TOKEN={auth_token}
TWILIO_PHONE_NUMBER={phone_number}
WEBHOOK_BASE_URL={webhook_url}
DATABASE_URL=sqlite:///data/zero_voice.db
"""

    with open('.env', 'w') as f:
        f.write(env_content)

    click.echo("✅ Configuration saved to .env file")

@cli.command()
def version():
    """Show version information"""
    from . import __version__
    click.echo(f"ZeroVoice v{__version__}")

def main():
    """Main entry point for the dashboard"""
    from .dashboard import app
    port = int(os.getenv('DASHBOARD_PORT', 8080))
    print(f"🚀 Starting ZeroVoice Dashboard on http://localhost:{port}")
    app.run(host='0.0.0.0', port=port, debug=False)

if __name__ == '__main__':
    cli()