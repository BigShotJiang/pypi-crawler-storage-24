"""
ZeroVoice - AI-powered call center with natural conversation capabilities
"""

__version__ = "0.6.1"
__author__ = "Collin Paran"
__email__ = "collin@collinparan.com"

from .dashboard import app as dashboard_app, make_twilio_call
from .webhook import app as webhook_app

__all__ = [
    "dashboard_app",
    "webhook_app",
    "make_twilio_call",
]