#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include <vector>

#include "../lib/treeshap_xgb.hpp"

using namespace grouptreeshap;

PYBIND11_MODULE(treeshap, m) {

    m.attr("__name__") = "grouptreeshap.treeshap";

    m.def("treeshap_xgb", &treeshap_xgb,
          "XGBoost-like float32 implementation of the TreeSHAP algorithm.",
          py::arg("tree"), py::arg("x"), py::arg("phi"),
          py::arg("condition"), py::arg("condition_feature"),
          py::arg("feature_reprs"));
}