# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["DocumentCreateParams"]


class DocumentCreateParams(TypedDict, total=False):
    content: Required[str]
    """Content of the initial document version"""

    title: Required[str]
    """Title of the initial document version"""

    assignee: str
    """User ID of the person assigned to this document.

    Defaults to the authenticated user if not provided.
    """

    language: str
    """Language of the initial document version"""

    metadata: Dict[str, object]
    """Optional metadata for the initial document version"""

    original_sentences: Annotated[SequenceNotStr[str], PropertyInfo(alias="originalSentences")]
    """Array of original sentences from the source"""

    scrape_job_id: Annotated[str, PropertyInfo(alias="scrapeJobId")]
    """Optional ID of the scrape job that generated this document"""

    status: Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]
    """Status of the initial document version"""
