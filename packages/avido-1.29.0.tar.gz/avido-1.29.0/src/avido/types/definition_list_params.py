# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["DefinitionListParams"]


class DefinitionListParams(TypedDict, total=False):
    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]
    """Field to order by in the result set."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    status: Literal["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED"]
    """Filter by evaluation status (e.g. COMPLETED)"""

    task_id: Annotated[str, PropertyInfo(alias="taskId")]
    """Filter by task ID"""

    trace_id: Annotated[str, PropertyInfo(alias="traceId")]
    """Filter by trace ID"""

    type: str
    """Filter by evaluation type (e.g. NATURALNESS)"""
