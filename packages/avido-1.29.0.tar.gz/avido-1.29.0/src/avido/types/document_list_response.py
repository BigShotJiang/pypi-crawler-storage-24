# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .core_tag import CoreTag
from .documents.document_version import DocumentVersion

__all__ = ["DocumentListResponse", "ScrapeJob", "ScrapeJobPage"]


class ScrapeJobPage(BaseModel):
    url: str
    """The URL of the page"""

    category: Optional[str] = None
    """The category of the page"""

    description: Optional[str] = None
    """The description of the page"""

    title: Optional[str] = None
    """The title of the page"""


class ScrapeJob(BaseModel):
    """Optional scrape job that generated this document"""

    id: str
    """The unique identifier of the scrape job"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the scrape job was created"""

    initiated_by: str = FieldInfo(alias="initiatedBy")
    """User ID who initiated the scrape job"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the scrape job was last modified"""

    name: str
    """The name/title of the scrape job"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns the scrape job"""

    status: Literal["MAPPING", "PENDING", "IN_PROGRESS", "COMPLETED", "FAILED"]
    """Current status of the scrape job"""

    url: str
    """The URL that was scraped"""

    pages: Optional[List[ScrapeJobPage]] = None
    """The pages scraped from the URL"""


class DocumentListResponse(BaseModel):
    id: str
    """Unique identifier of the document"""

    assignee: str
    """User ID of the person assigned to this document"""

    content: str
    """use versions.content"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the document was created"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the document was last modified"""

    optimized: bool
    """Whether the document has been optimized"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this document"""

    tags: List[CoreTag]

    title: str
    """use versions.title instead"""

    versions: List[DocumentVersion]
    """Array of document versions"""

    scrape_job: Optional[ScrapeJob] = FieldInfo(alias="scrapeJob", default=None)
    """Optional scrape job that generated this document"""

    scrape_job_id: Optional[str] = FieldInfo(alias="scrapeJobId", default=None)
    """Optional ID of the scrape job that generated this document"""
