# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from ..._types import SequenceNotStr
from ..._utils import PropertyInfo

__all__ = ["TagUpdateParams"]


class TagUpdateParams(TypedDict, total=False):
    tag_ids: Required[Annotated[SequenceNotStr[str], PropertyInfo(alias="tagIds")]]
    """Array of tag IDs to assign to the resource"""
