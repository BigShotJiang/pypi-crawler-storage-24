# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ..tag import Tag
from ..._models import BaseModel

__all__ = ["TagUpdateResponse"]


class TagUpdateResponse(BaseModel):
    """Successful response containing tags"""

    data: List[Tag]
