"""Interactive streaming example -- return workflow with live UI updates.

Shows how mid-node events from ``emit()`` can drive a real-time user
interface.  Each processing step appears on screen the moment it happens,
giving the user immediate feedback while the workflow runs.

Requires:
    OPENAI_API_KEY environment variable to be set.

Run with:
    uv run python examples/streaming/streaming_main.py
"""

import sys
import time
from pathlib import Path

from soprano_sdk.streaming import (
    WorkflowStreamer,
    AsyncInterruptEvent,
    CompleteEvent,
    CustomEvent,
    ErrorEvent,
    InterruptEvent,
    NodeCompleteEvent,
    OutOfScopeEvent,
)

HERE = Path(__file__).resolve().parent

# Add examples/streaming to sys.path so the YAML can resolve
# function references like "return_functions_streaming.check_eligibility"
sys.path.insert(0, str(HERE))

streamer = WorkflowStreamer.from_env(
    yaml_path=str(HERE / "return_workflow_streaming.yaml"),
    name="returns",
)

THREAD_ID = "test_thread_1"

# ── Terminal helpers ─────────────────────────────────────────────

SPINNER = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
GRAY = "\033[90m"
GREEN = "\033[92m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"


def _clear_line():
    sys.stdout.write("\r\033[K")


def _print_step(label, done=False):
    """Print a processing step with a spinner or checkmark."""
    _clear_line()
    if done:
        sys.stdout.write(f"  {GREEN}✓{RESET} {label}\n")
    else:
        # Animate spinner briefly
        for i in range(6):
            _clear_line()
            frame = SPINNER[i % len(SPINNER)]
            sys.stdout.write(f"  {CYAN}{frame}{RESET} {GRAY}{label}{RESET}")
            sys.stdout.flush()
            time.sleep(0.08)


def _print_result(label):
    """Print a result line with emphasis."""
    _clear_line()
    sys.stdout.write(f"  {GREEN}✓ {BOLD}{label}{RESET}\n")
    sys.stdout.flush()


def _print_bot(text):
    print(f"\n{BOLD}Bot:{RESET} {text}")


def _print_options(options):
    for i, opt in enumerate(options, 1):
        text = opt.get("text", opt) if isinstance(opt, dict) else opt
        subtext = opt.get("subtext", "") if isinstance(opt, dict) else ""
        if subtext:
            print(f"  {i}. {text} {GRAY}({subtext}){RESET}")
        else:
            print(f"  {i}. {text}")


# ── Event processing ─────────────────────────────────────────────

def process_events(workflow_streamer, thread_id, message, initial_context=None):
    """Run one turn and render events live.

    Returns True if the workflow needs more input, False if done.
    """
    for event in workflow_streamer.stream(
        thread_id=thread_id,
        user_message=message,
        initial_context=initial_context or {},
    ):
        match event:
            case NodeCompleteEvent():
                pass  # Silenced -- step/result events provide better detail

            case CustomEvent():
                payload = event.payload
                event_type = payload.get("type", "")

                if event_type == "step":
                    _print_step(payload.get("label", "Processing..."))
                elif event_type == "result":
                    _print_result(payload.get("label", "Done"))
                else:
                    print(f"  {GRAY}[{event_type}] {payload}{RESET}")

            case InterruptEvent():
                _print_bot(event.prompt)
                if event.options:
                    _print_options(event.options)
                return True

            case AsyncInterruptEvent():
                _print_bot(f"Waiting for external verification ({event.step_id})...")
                return True

            case OutOfScopeEvent():
                _print_bot(f"That seems unrelated to your return. ({event.reason})")
                return True

            case CompleteEvent():
                _print_bot(event.message)
                if event.options:
                    _print_options(event.options)
                return False

            case ErrorEvent():
                print(f"\n{BOLD}[error]{RESET} {event.error}")
                return False

    return False


# ── Main loop ────────────────────────────────────────────────────

def main():
    print()
    print(f"  {BOLD}Return Processing Bot{RESET}")
    print(f"  {GRAY}Streaming events are shown in real time.{RESET}")
    print(f"  {GRAY}Type 'quit' to exit.{RESET}")
    print()

    # First turn: kick off the workflow
    in_progress = process_events(streamer, THREAD_ID, "")

    while in_progress:
        try:
            query = input(f"\n{BOLD}You:{RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if query.lower() in ("quit", "exit"):
            print("Goodbye!")
            break

        print()  # Spacing before streamed events
        in_progress = process_events(streamer, THREAD_ID, query)

    print(f"\n  {GRAY}[session complete]{RESET}\n")


if __name__ == "__main__":
    main()
