"""Tests for soprano_sdk._context.emit() -- standalone stream writer emit."""

from unittest.mock import MagicMock, patch

from soprano_sdk.streaming import emit


class TestEmitNoOp:
    """emit() is a silent no-op outside a LangGraph runnable context."""

    def test_emit_does_nothing_outside_graph(self):
        # get_stream_writer() raises RuntimeError outside graph execution
        emit("some_event", {"key": "value"})  # Should not raise


class TestEmitWithStreamWriter:
    """emit() writes to the stream writer when inside a graph node."""

    def test_emit_writes_event_with_type_and_data(self):
        writer = MagicMock()
        with patch("soprano_sdk.streaming.get_stream_writer", return_value=writer):
            emit("tool_result", {"tool": "crm.lookup", "found": True})

        writer.assert_called_once_with({
            "type": "tool_result",
            "tool": "crm.lookup",
            "found": True,
        })

    def test_emit_without_data(self):
        writer = MagicMock()
        with patch("soprano_sdk.streaming.get_stream_writer", return_value=writer):
            emit("heartbeat")

        writer.assert_called_once_with({"type": "heartbeat"})

    def test_emit_noop_when_writer_raises(self):
        with patch("soprano_sdk.streaming.get_stream_writer", side_effect=RuntimeError("not in graph")):
            emit("should_not_crash", {"x": 1})  # Should not raise
