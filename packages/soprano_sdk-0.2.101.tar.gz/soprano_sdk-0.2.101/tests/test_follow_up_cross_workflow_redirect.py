"""Cross-workflow redirect test.

Scenario:
  1. Workflow 1 completes with a redirect outcome (type: redirect).
     Because follow_up is enabled the follow-up node delivers the redirect
     message to the client via a FOLLOW_UP interrupt containing __REDIRECT__.
  2. The client starts Workflow 2 in a fresh thread (simulating the redirect).
  3. Workflow 2 completes normally and enters its own follow-up session.
  4. In Workflow 2's follow-up the user asks an out-of-scope question →
     FOLLOW_UP_OUT_OF_SCOPE interrupt.
  5. The client "comes back" to Workflow 1 (still paused in follow-up) and
     asks a normal question → the follow-up LLM answers, confirming that
     Workflow 1's follow-up session is intact after the round-trip.

LLM call order (single respx mock, shared across both tools):
  LLM#1  wf1: collect_a prompt
  LLM#2  wf1: collect_a capture → redirect outcome → FOLLOW_UP (no LLM)
  LLM#3  wf2: collect_b prompt
  LLM#4  wf2: collect_b capture → success outcome → FOLLOW_UP (no LLM)
  LLM#5  wf2: follow-up LLM → out_of_scope
  LLM#6  wf1: follow-up LLM → normal answer (resumed after wf2 OOS)
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType, OutcomePrefix

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    fu_out_of_scope,
    llm_structured_response,
    make_tool,
    snap,
)


def _prompt_b(text="Please tell me field B.") -> object:
    return llm_structured_response({"bot_response": text, "field_b": None})


def _capture_b(val) -> object:
    return llm_structured_response({"bot_response": None, "field_b": val})


@respx.mock
def test_redirect_via_follow_up_then_wf2_oos_returns_to_wf1():
    """Full cross-workflow redirect + OOS round-trip using respx.

    Verifies:
    - Workflow 1's redirect outcome is delivered as a FOLLOW_UP interrupt
      whose text contains the __REDIRECT__ prefix.
    - Workflow 2 is independent (separate tool + thread); it runs to completion
      and enters its own follow-up.
    - An out-of-scope question in Workflow 2 produces FOLLOW_UP_OUT_OF_SCOPE.
    - After the OOS, Workflow 1's follow-up is still alive; resuming it yields
      a normal FOLLOW_UP answer, confirming the session was not corrupted.
    """
    responses = iter([
        collector_prompt("What is field A?"),                        # LLM#1 wf1 collect_a prompt
        collector_capture("val_a"),                                  # LLM#2 wf1 collect_a capture
        # wf1 follow-up first entry: fires interrupt — no LLM call here
        _prompt_b("What is field B?"),                               # LLM#3 wf2 collect_b prompt
        _capture_b("val_b"),                                         # LLM#4 wf2 collect_b capture
        # wf2 follow-up first entry: fires interrupt — no LLM call here
        fu_out_of_scope("unrelated_topic", "I can't help with that in this workflow."),  # LLM#5 wf2 OOS
        fu_answer("Here is the answer to your wf1 question."),       # LLM#6 wf1 follow-up answer
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    wf1 = make_tool("follow_up_redirect_source.yaml")
    wf2 = make_tool("follow_up_redirect_target.yaml")
    tid1 = str(uuid.uuid4())
    tid2 = str(uuid.uuid4())

    # ── Workflow 1 ────────────────────────────────────────────────────────────

    # T1: wf1 collect_a prompts
    wf1.execute(thread_id=tid1, initial_context={})

    # T2: wf1 collects val_a → redirect outcome → follow-up first entry
    result_wf1_redirect = wf1.execute(thread_id=tid1, user_message="val_a", initial_context={})

    # The follow-up node delivers the redirect outcome message via FOLLOW_UP interrupt.
    assert InterruptType.FOLLOW_UP in str(result_wf1_redirect), (
        f"Expected FOLLOW_UP interrupt carrying the redirect message, "
        f"got: '{str(result_wf1_redirect)[:300]}'"
    )
    assert OutcomePrefix.REDIRECT in str(result_wf1_redirect), (
        f"Expected __REDIRECT__ prefix in FOLLOW_UP message (redirect outcome), "
        f"got: '{str(result_wf1_redirect)[:300]}'"
    )
    # Workflow 1 state: redirect outcome recorded, follow-up active
    s1 = snap(wf1, tid1)
    assert s1.get("_outcome_id") == "outcome_redirect"
    assert s1.get("_follow_up_active") is True

    # ── Workflow 2 (client starts fresh after seeing redirect) ────────────────

    # T3: wf2 collect_b prompts
    wf2.execute(thread_id=tid2, initial_context={})

    # T4: wf2 collects val_b → success outcome → follow-up first entry
    result_wf2_entry = wf2.execute(thread_id=tid2, user_message="val_b", initial_context={})
    assert InterruptType.FOLLOW_UP in str(result_wf2_entry), (
        f"Expected FOLLOW_UP at wf2 entry, got: '{str(result_wf2_entry)[:300]}'"
    )
    assert OutcomePrefix.REDIRECT not in str(result_wf2_entry), (
        "wf2 outcome is success, should not contain __REDIRECT__"
    )

    # T5: user asks OOS question in wf2 follow-up
    result_wf2_oos = wf2.execute(thread_id=tid2, user_message="tell me about crypto", initial_context={})
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result_wf2_oos), (
        f"Expected FOLLOW_UP_OUT_OF_SCOPE from wf2 follow-up, "
        f"got: '{str(result_wf2_oos)[:300]}'"
    )
    # wf2 is paused — not ended; state still checkpointed
    s2 = snap(wf2, tid2)
    assert s2.get("field_b") is not None, "wf2 field_b should still be set (no restart)"

    # ── Workflow 1 resumed (client comes back after wf2 OOS) ─────────────────

    # T6: client returns to wf1 follow-up with a normal question
    result_wf1_resumed = wf1.execute(thread_id=tid1, user_message="what happened to my request?", initial_context={})
    assert InterruptType.FOLLOW_UP in str(result_wf1_resumed), (
        f"Expected wf1 follow-up to still be alive after wf2 round-trip, "
        f"got: '{str(result_wf1_resumed)[:300]}'"
    )
    assert "wf1 question" in str(result_wf1_resumed), (
        f"Expected wf1 follow-up answer text in result, "
        f"got: '{str(result_wf1_resumed)[:300]}'"
    )

    # wf1 state: follow-up active, attempt counter incremented by the T6 turn
    s1_final = snap(wf1, tid1)
    assert s1_final.get("_follow_up_active") is True
    assert s1_final.get("_follow_up_attempts") == 1

    assert respx.calls.call_count == 6
