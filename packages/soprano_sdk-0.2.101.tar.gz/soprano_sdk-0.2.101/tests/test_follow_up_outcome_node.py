"""Tests for OutcomeNode ↔ FollowUpNode interaction.

Targets six potential issues introduced by the current design where OutcomeNode
completes normally (sets FOLLOW_UP_PENDING_PROMPT in checkpoint) and FollowUpNode
delivers the outcome message via interrupt(pending_prompt):

  1. FOLLOW_UP_PENDING_PROMPT must be None in the checkpoint after the first Q&A
     completes — otherwise follow_up would re-deliver the outcome message on every
     subsequent turn (infinite re-delivery loop).

  2. FOLLOW_UP_ACTIVE must be True in the checkpoint at the first FOLLOW_UP interrupt
     — this flag is set by OutcomeNode (which returns normally), so its mutation IS
     saved; regression guard for the old interrupt()-in-OutcomeNode design where the
     mutation was discarded.

  3. Outcome message must be the first assistant entry in the follow-up LLM
     conversation, appearing before the user's first Q&A question. The entry is added
     after interrupt() returns on resumption, so ordering depends on the correct code
     path.

  4. Outcome message must be re-rendered with new field values after intent_change
     rollback + re-collection — OutcomeNode must call get_outcome_message() fresh on
     every visit, not serve cached data from the previous collection.

  5. Humanizer must be re-invoked with fresh collector context after intent_change
     rollback + re-collection — OutcomeNode re-runs get_outcome_message() which
     triggers humanization again with the new conversation.

  6. When OOS fires on the first Q&A turn (through the pending_prompt path), the
     follow-up conversation must have the correct ordering: outcome message (assistant)
     → OOS question (user) → OOS bot_response (assistant) → next user message (user).
     No consecutive user messages should appear.
"""
import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    follow_up_conv_key,
    fu_answer,
    fu_intent_change,
    fu_out_of_scope,
    llm_structured_response,
    make_tool,
    snap,
)


def _humanizer(text: str):
    """LLM response: outcome humanizer returns a structured humanized message."""
    return llm_structured_response({"message": text, "options": None, "is_selectable": None})


# ──────────────────────────────────────────────────────────────────────────────
# Issue 1 — FOLLOW_UP_PENDING_PROMPT cleared from checkpoint after first Q&A
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_follow_up_pending_prompt_cleared_in_checkpoint_after_first_qa():
    """After the first Q&A turn completes (T3), FOLLOW_UP_PENDING_PROMPT must be None
    in the LangGraph checkpoint. If still set, every subsequent follow_up run would
    enter the pending_prompt branch and re-deliver the outcome message to the user
    instead of processing the Q&A — an infinite outcome-message loop.

    The correct design: OutcomeNode sets FOLLOW_UP_PENDING_PROMPT and returns normally
    (mutation saved). follow_up receives it, fires interrupt(), and on T3 resumption
    clears it and returns normally (clearing saved). The checkpoint after T3 must show None.
    """
    responses = iter([
        collector_prompt(),                 # LLM#1: collector prompt
        collector_capture("valid_val"),     # LLM#2: collector captures
        fu_answer("Here is your answer."),  # LLM#3: follow-up Q&A
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})   # T2 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="q1", initial_context={})          # T3 → FOLLOW_UP (answer)
    s = snap(tool, tid)

    assert s.get("_follow_up_pending_prompt") is None, (
        "_follow_up_pending_prompt must be cleared from the checkpoint after the first "
        "Q&A turn. If still set, the follow-up node would re-deliver the outcome message "
        f"on every subsequent turn instead of processing Q&A. Found: {s.get('_follow_up_pending_prompt')}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Issue 2 — FOLLOW_UP_ACTIVE preserved in checkpoint at first FOLLOW_UP interrupt
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_follow_up_active_flag_preserved_in_checkpoint_at_first_follow_up_entry():
    """After T2 delivers the first FOLLOW_UP interrupt, the checkpoint must have
    FOLLOW_UP_ACTIVE = True. This flag is set by OutcomeNode before it returns normally,
    so its mutation IS persisted in the LangGraph checkpoint.

    In the old broken design where OutcomeNode called interrupt() itself, the mutation
    was discarded (LangGraph checkpoints state from before the interrupted node). This
    test guards against regressions to that pattern.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})   # T2 → FOLLOW_UP
    s = snap(tool, tid)

    assert s.get("_follow_up_active") is True, (
        "_follow_up_active must be True in the checkpoint after the first FOLLOW_UP "
        "interrupt. OutcomeNode sets it and returns normally so LangGraph persists the "
        "mutation. If OutcomeNode fired interrupt() instead, this mutation would be "
        f"discarded and _follow_up_active would be None. Found: {s.get('_follow_up_active')}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Issue 3 — Outcome message is first assistant entry in follow-up LLM conversation
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_outcome_message_is_first_assistant_entry_before_user_qa_in_llm_conversation():
    """On T3, the follow-up LLM receives the conversation history built during that
    resumption turn. The outcome message must appear as the FIRST assistant entry
    immediately before the user's first Q&A question. If the ordering is wrong (e.g.
    user message before outcome, or outcome missing), the follow-up LLM has no context
    of what the workflow concluded and cannot answer accurately.

    The conversation entry is added AFTER interrupt() returns on T3 resumption (new
    code path), so it is always saved in the same node execution that calls the LLM.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("abc_value"),
        fu_answer("The answer."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="abc_value", initial_context={})   # T2 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="first question", initial_context={})  # T3 → LLM#3

    assert len(captured_requests) >= 3
    fu_req_body = json.loads(captured_requests[2].content)
    non_system = [m for m in fu_req_body["messages"] if m["role"] != "system"]

    assert len(non_system) >= 2, (
        f"Follow-up LLM should receive at least 2 non-system messages "
        f"(outcome + user Q&A), got {len(non_system)}: {non_system}"
    )
    assert non_system[0]["role"] == "assistant", (
        f"First non-system message must be the outcome message (assistant role). "
        f"Got role='{non_system[0]['role']}': {non_system}"
    )
    assert "abc_value" in non_system[0]["content"], (
        f"First assistant entry must contain the outcome text ('abc_value'). "
        f"Got content: {non_system[0]['content']!r}"
    )
    assert non_system[1]["role"] == "user", (
        f"Second non-system message must be the user's Q&A question (user role). "
        f"Got role='{non_system[1]['role']}': {non_system}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Issue 4 — Outcome message re-rendered with new field values after re-collection
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_outcome_re_rendered_with_new_field_after_intent_change_re_collection():
    """After an intent_change rollback and re-collection with a different value, the
    FOLLOW_UP interrupt must contain the outcome message rendered with the NEW field
    value, not the stale value from the first collection. OutcomeNode calls
    get_outcome_message() on every visit so the template is always re-evaluated.

    If OutcomeNode cached the outcome payload (or the state was not refreshed), the
    second FOLLOW_UP would still show 'old_val' regardless of what the user entered.
    """
    responses = iter([
        collector_prompt(),                               # LLM#1
        collector_capture("old_val"),                     # LLM#2
        fu_intent_change("collect_a", "Let me redo."),   # LLM#3: intent_change signal
        collector_prompt("Re-enter field A."),            # LLM#4: re-prompt after rollback
        collector_capture("new_val"),                     # LLM#5: fresh capture
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="old_val", initial_context={})   # T2
    tool.execute(thread_id=tid, user_message="change it", initial_context={})           # T3 → USER_INPUT
    result4 = tool.execute(thread_id=tid, user_message="new_val", initial_context={})   # T4 → FOLLOW_UP

    assert InterruptType.FOLLOW_UP in str(result2)
    assert "old_val" in str(result2), (
        f"First FOLLOW_UP should contain the first collected value. Got: {result2}"
    )

    assert InterruptType.FOLLOW_UP in str(result4)
    assert "new_val" in str(result4), (
        f"Second FOLLOW_UP after re-collection must contain the new field value. "
        f"Got: {result4}"
    )
    assert "old_val" not in str(result4), (
        f"Re-rendered outcome must NOT contain the old value 'old_val'. "
        f"Got: {result4}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Issue 5 — Humanizer re-invoked with fresh collector context after re-collection
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_humanizer_re_invoked_with_fresh_context_after_intent_change_re_collection():
    """When humanization is enabled, OutcomeNode calls get_outcome_message() on every
    visit, which triggers the humanizer LLM with the current collector conversation.
    After an intent_change rollback + re-collection, the humanizer must be called a
    second time with the NEW collector conversation reflecting the new field value.

    LLM call sequence:
      #1  collector prompt                (T1)
      #2  collector captures 'first_val' (T2, first half)
      #3  humanizer for 'first_val'       (T2, second half — OutcomeNode visit 1)
      #4  follow-up: intent_change signal (T3, first half)
      #5  collector re-prompt             (T3, second half — after rollback)
      #6  collector captures 'second_val' (T4, first half)
      #7  humanizer for 'second_val'      (T4, second half — OutcomeNode visit 2)

    If OutcomeNode cached the previous get_outcome_message() result, LLM#7 would never
    fire and the second FOLLOW_UP would show the stale humanized text from LLM#3.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Please enter field A."),            # LLM#1
        collector_capture("first_val"),                       # LLM#2
        _humanizer("Humanized first: first_val outcome."),    # LLM#3
        fu_intent_change("collect_a", "Let me redo."),        # LLM#4
        collector_prompt("Re-enter field A."),                # LLM#5
        collector_capture("second_val"),                      # LLM#6
        _humanizer("Humanized second: second_val outcome."),  # LLM#7
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_humanized.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                                     # T1 → LLM#1
    result2 = tool.execute(thread_id=tid, user_message="first_val", initial_context={}) # T2 → LLM#2,#3
    tool.execute(thread_id=tid, user_message="change it", initial_context={})           # T3 → LLM#4,#5
    result4 = tool.execute(thread_id=tid, user_message="second_val", initial_context={}) # T4 → LLM#6,#7

    assert InterruptType.FOLLOW_UP in str(result2)
    assert "Humanized first:" in str(result2), (
        f"First FOLLOW_UP should contain first humanized text. Got: {result2}"
    )

    assert InterruptType.FOLLOW_UP in str(result4)
    assert "Humanized second:" in str(result4), (
        f"Second FOLLOW_UP after re-collection must contain the re-humanized text. "
        f"OutcomeNode must call get_outcome_message() again on its second visit. "
        f"Got: {result4}"
    )
    assert len(captured_requests) == 7, (
        f"Expected 7 LLM calls (prompt, capture, humanize, intent_change, re-prompt, "
        f"re-capture, re-humanize). Got {len(captured_requests)}. "
        f"If humanizer was skipped on second visit, count would be 6."
    )

    # LLM#7 (index 6) is the second humanizer call — it must contain the new value
    humanizer2_body = json.loads(captured_requests[6].content)
    humanizer2_content = " ".join(
        str(m.get("content", "")) for m in humanizer2_body.get("messages", [])
    )
    assert "second_val" in humanizer2_content, (
        f"The second humanizer call (LLM#7) must receive the new collector conversation "
        f"containing 'second_val', but it was not found in: {humanizer2_content!r}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Issue 6 — OOS on first Q&A turn: conversation ordering integrity
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_oos_on_first_qa_produces_correct_conversation_ordering():
    """When the user's very first post-outcome message triggers OOS (going through the
    pending_prompt branch), the follow-up conversation must be built in the correct order:

      1. assistant: outcome message          (added after interrupt returns, T3)
      2. user:      OOS question             (appended before LLM call)
      3. assistant: OOS bot_response         (appended by _handle_out_of_scope)
      4. user:      next normal question     (appended on T4 resumption)

    No consecutive user messages should appear. If the conversation entry is added in
    the wrong place (or skipped), the LLM on T4 would lack the outcome and OOS context,
    answering as if the conversation had just started.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),                                            # LLM#1
        collector_capture("valid_val"),                               # LLM#2
        fu_out_of_scope("unrelated_topic", "I can't help with that."), # LLM#3: OOS on first turn
        fu_answer("Here is the answer to your real question."),        # LLM#4: normal Q&A
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})        # T2 → FOLLOW_UP
    result3 = tool.execute(thread_id=tid, user_message="buy crypto", initial_context={})  # T3 → OOS
    result4 = tool.execute(thread_id=tid, user_message="real question", initial_context={}) # T4 → FOLLOW_UP

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"T3 should return FOLLOW_UP_OUT_OF_SCOPE interrupt. Got: {result3}"
    )
    assert InterruptType.FOLLOW_UP in str(result4), (
        f"T4 should return FOLLOW_UP with normal answer. Got: {result4}"
    )
    assert "Here is the answer to your real question." in str(result4)

    # Inspect the conversation stored in state to verify ordering
    s = snap(tool, tid)
    fu_key = follow_up_conv_key(tool)
    conversation = s.get("_conversations", {}).get(fu_key, [])

    assert len(conversation) >= 4, (
        f"Expected at least 4 conversation entries "
        f"(outcome, oos_q, oos_response, normal_q). Got {len(conversation)}: {conversation}"
    )

    # No two consecutive user messages — would indicate outcome message was skipped
    roles = [entry["role"] for entry in conversation]
    for i in range(len(roles) - 1):
        assert not (roles[i] == "user" and roles[i + 1] == "user"), (
            f"Found consecutive user messages at positions {i} and {i+1}. "
            f"This means the outcome message was not added to the conversation before "
            f"the first user OOS question. Full role sequence: {roles}"
        )

    # First entry must be the outcome message (assistant)
    assert roles[0] == "assistant", (
        f"First conversation entry must be the outcome message (assistant role). "
        f"Got roles: {roles}"
    )
    assert "valid_val" in str(conversation[0].get("content", "")), (
        f"First assistant entry must contain the outcome text ('valid_val'). "
        f"Got: {conversation[0]}"
    )

    # Verify LLM#4 also received the full ordered conversation
    assert len(captured_requests) == 4
    fu_qa_body = json.loads(captured_requests[3].content)
    non_system = [m for m in fu_qa_body["messages"] if m["role"] != "system"]

    fu_roles = [m["role"] for m in non_system]
    for i in range(len(fu_roles) - 1):
        assert not (fu_roles[i] == "user" and fu_roles[i + 1] == "user"), (
            f"LLM#4 received consecutive user messages — conversation ordering is broken. "
            f"LLM message roles: {fu_roles}"
        )
