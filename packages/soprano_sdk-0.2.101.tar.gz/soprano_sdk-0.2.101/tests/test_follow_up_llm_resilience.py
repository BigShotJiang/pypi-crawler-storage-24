"""Tests for LLM error resilience in the follow-up node. Covers agent invocation
failures, the empty bot_response fallback guard, and that the guard does not interfere
with out-of-scope dispatch signals.
"""

import uuid

import httpx
import pytest
import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    follow_up_conv_key,
    llm_structured_response,
    make_tool,
    snap,
)


def fu_empty_bot_response():
    """LLM returns a structurally valid FollowUpOutput with bot_response=''.
    This is NOT a crash — the raw_response is None fallback does NOT trigger.
    """
    return llm_structured_response({
        "bot_response": "",
        "options": None,
        "is_selectable": None,
        "intent_change": None,
        "out_of_scope": None,
        "restart": False,
    })


def fu_empty_oos(reason: str):
    """Follow-up LLM returns bot_response='' AND out_of_scope set.

    This is a structurally valid response — the LLM correctly identifies an
    out-of-scope query but produces an empty explanatory message.  The empty
    bot_response guard should NOT substitute the LLM_INVOCATION_ERROR_FALLBACK
    in this case because a dispatch signal is present.
    """
    return llm_structured_response({
        "bot_response": "",
        "options": None,
        "is_selectable": None,
        "intent_change": None,
        "out_of_scope": reason,
        "restart": False,
    })


@respx.mock
def test_llm_invocation_error_returns_fallback_response():
    """When the follow-up agent.invoke() raises a network or connection error, the node
    should catch the failure gracefully and return a FOLLOW_UP interrupt with a safe
    fallback message rather than propagating the exception to the caller.
    """
    call_count = 0

    def side_effect(req):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return collector_prompt()
        if call_count == 2:
            return collector_capture("valid_val")
        # 3rd call is the follow-up LLM — simulate a hard network failure
        raise httpx.ConnectError("Connection refused")

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})

    try:
        result3 = tool.execute(thread_id=tid, user_message="any question", initial_context={})
        assert InterruptType.FOLLOW_UP in str(result3), (
            "Expected a FOLLOW_UP interrupt with a fallback message, got: " + str(result3)
        )
    except Exception as exc:
        pytest.fail(
            f"Follow-up node should catch LLM failures gracefully "
            f"but raised: {type(exc).__name__}: {exc}"
        )


@respx.mock
def test_llm_crash_fallback_message_is_non_empty_and_delivered_to_user():
    """When the follow-up agent crashes, the fallback FOLLOW_UP interrupt should deliver
    a non-empty message to the user rather than an empty string. An empty fallback message
    gives the user no indication that something went wrong, and if stored in the conversation
    it pollutes subsequent LLM calls with a blank assistant turn.
    """
    call_count = 0

    def side_effect(req):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return collector_prompt()
        if call_count == 2:
            return collector_capture("valid_val")
        # LLM#3: follow-up agent crashes — simulates network/API failure
        raise httpx.ConnectError("Connection refused")

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})

    # T3: follow-up LLM crashes.  Expected: FOLLOW_UP with a non-empty fallback.
    result3 = tool.execute(thread_id=tid, user_message="any question", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result3), (
        f"Expected FOLLOW_UP interrupt after crash, got: '{str(result3)}'"
    )

    # The FOLLOW_UP result format is:
    #   "__FOLLOW_UP_INTERRUPT__|<thread_id>|<name>|<text>"
    # Extract the text after the third pipe.
    parts = str(result3).split("|")
    follow_up_text = parts[3] if len(parts) > 3 else ""

    assert follow_up_text.strip() != "", (
        f"FOLLOW_UP text is empty after LLM crash — user sees a blank "
        f"message.  Fallback bot_response should be a non-empty string. "
        f"Full result: '{str(result3)}'"
    )

    # Also verify the empty assistant entry is NOT permanently stored
    s = snap(tool, tid)
    follow_up_conv = s.get("_conversations", {}).get(follow_up_conv_key(tool), [])
    assistant_messages = [m for m in follow_up_conv if m["role"] == "assistant"]
    empty_msgs = [m for m in assistant_messages if m.get("content", "SENTINEL") == ""]
    assert not empty_msgs, (
        f"Empty assistant message stored in follow-up conversation: "
        f"{empty_msgs} — this pollutes future LLM context"
    )


@respx.mock
def test_empty_bot_response_in_valid_structured_output_triggers_error_fallback():
    """When the follow-up LLM returns a structurally valid response but with an empty
    bot_response string (not a crash), the node should treat this as equivalent to a
    crash and substitute the configured error fallback message. An empty bot_response
    delivered via a FOLLOW_UP interrupt gives the user no useful information.
    """
    responses = iter([
        llm_structured_response({"bot_response": "Please tell me field A.", "field_a": None}),  # LLM#1
        llm_structured_response({"bot_response": None, "field_a": "valid_val"}),                # LLM#2
        fu_empty_bot_response(),   # LLM#3: valid struct, bot_response=""
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})

    # T3: follow-up LLM returns bot_response=""
    result3 = tool.execute(thread_id=tid, user_message="q1", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result3), (
        f"Expected FOLLOW_UP interrupt after empty bot_response, got: '{str(result3)}'"
    )

    # The FOLLOW_UP result format: "__FOLLOW_UP_INTERRUPT__|<tid>|<name>|<text>"
    # text after the 3rd pipe should be non-empty.
    parts = str(result3).split("|")
    follow_up_text = parts[3] if len(parts) > 3 else ""

    assert follow_up_text.strip() != "", (
        f"FOLLOW_UP text is empty after LLM returned bot_response=''. "
        f"The guard checking for None does NOT cover structurally valid empty "
        f"responses. The node should treat bot_response='' as equivalent to a crash "
        f"and substitute the configured error fallback. "
        f"Full result: '{str(result3)}'"
    )

    # Also verify the empty assistant entry is NOT persisted in the follow-up conversation
    s = snap(tool, tid)
    follow_up_conv = s.get("_conversations", {}).get(follow_up_conv_key(tool), [])
    assistant_messages = [m for m in follow_up_conv if m.get("role") == "assistant"]
    empty_msgs = [m for m in assistant_messages if m.get("content", "SENTINEL") == ""]
    assert not empty_msgs, (
        f"Empty assistant message persisted in follow-up conversation: "
        f"{empty_msgs} — this pollutes future LLM context with a blank assistant turn."
    )


@respx.mock
def test_error_fallback_guard_does_not_fire_when_out_of_scope_signal_is_set():
    """When the follow-up LLM returns bot_response='' alongside an out_of_scope signal,
    the empty bot_response guard should NOT substitute the error fallback message. The
    OOS dispatch signal takes priority and the empty string is intentional, not an error.
    Replacing it with the error fallback message would give the user a confusing network
    error message for a legitimate OOS query.
    """
    # Default fallback text (matches FollowUpStrategy._DEFAULT_LLM_INVOCATION_ERROR_FALLBACK)
    ERROR_FALLBACK = "I'm sorry, I'm having trouble right now. Please try again."

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_empty_oos("unrelated_topic"),  # LLM#3 — follow-up: bot_response="" + out_of_scope set
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    # T3 must produce a FOLLOW_UP_OUT_OF_SCOPE interrupt (OOS path was triggered)
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"Expected FOLLOW_UP_OUT_OF_SCOPE interrupt, got: '{str(result3)}'"
    )

    # Parse the JSON payload embedded in the result string:
    # format: __FOLLOW_UP_OUT_OF_SCOPE__|tid|name|<json>
    parts = str(result3).split("|", 3)
    assert len(parts) >= 4, f"Result does not contain expected '|' separators: '{str(result3)}'"
    import json
    oos_payload = json.loads(parts[3])

    # The bot_response in the OOS payload must NOT be the network-error fallback.
    assert oos_payload.get("bot_response") != ERROR_FALLBACK, (
        f"OOS interrupt carries the LLM invocation error fallback "
        f"as bot_response: '{oos_payload.get('bot_response')}'. "
        f"The empty bot_response guard fires BEFORE the OOS dispatch, "
        f"replacing the LLM's intentional empty string with the network-error message. "
        f"Expected bot_response to be '' (the LLM's original value), not the error fallback."
    )
