"""Tests for runtime configuration integration and interaction effects.

Addresses advanced scenarios for runtime configurations:
1. integration agent model and base_url overrides (collector)
2. integration outcomes[].humanize suppression of humanizer calls
3. integration localization.instructions injection
4. integration steps[].field redirection of captured data
5. Config: data[].default state population
6. Config: follow_up.additionalProperties enforcement
7. Config: agent.humanize vs outcomes.humanize interaction
"""
import json
import uuid
import pytest
import respx

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    MODEL_CONFIG,
    CapturingCheckpointer,
    FIXTURES,
    collector_capture,
    collector_prompt,
    llm_structured_response,
    snap,
)
from soprano_sdk.tools import WorkflowTool


def _make(yaml_name: str, extra: dict = None) -> WorkflowTool:
    config = {"model_config": MODEL_CONFIG, **(extra or {})}
    return WorkflowTool(
        yaml_path=str(FIXTURES / yaml_name),
        name="test",
        description="test",
        checkpointer=CapturingCheckpointer(),
        config=config,
    )


def _humanizer(text: str):
    return llm_structured_response({"message": text, "options": None, "is_selectable": None})


# ===========================================================================
# 1. integration Model & Base URL Overrides
# ===========================================================================

@respx.mock
def test_steps_agent_model_override_in_llm_request():
    """steps[].agent.model override appears in collector LLM request body."""
    captured = []
    
    def _side_effect(request):
        captured.append(request)
        return next(responses)

    responses = iter([collector_prompt()])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"model": "runtime-collector-model"}}]
    })
    tid = str(uuid.uuid4())
    tool.execute(thread_id=tid, initial_context={})

    assert len(captured) >= 1
    req_body = json.loads(captured[0].content)
    assert req_body.get("model") == "runtime-collector-model", (
        "Runtime agent model must be used in collector LLM request"
    )


@respx.mock
def test_steps_agent_base_url_routes_correctly():
    """steps[].agent.base_url override targets the new URL."""
    # Mock the default so it fails if called
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=respx.MockResponse(500))
    
    # Mock the new runtime URL
    custom_url = "https://custom-collector-api.ai/v1/chat/completions"
    responses = iter([collector_prompt()])
    route = respx.post(custom_url).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"base_url": "https://custom-collector-api.ai/v1"}}]
    })
    tid = str(uuid.uuid4())
    tool.execute(thread_id=tid, initial_context={})

    assert route.called, "Collector LLM request must hit the runtime-overridden base_url"


# ===========================================================================
# 2. Humanizer Suppression Interation
# ===========================================================================

@respx.mock
def test_outcome_humanize_false_suppresses_humanizer():
    """outcomes[].humanize=False prevents humanization even if globally enabled.
    
    follow_up_humanized.yaml enables humanization globally, but we override
    'outcome_success' to humanize: False.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        # We do NOT include a humanizer response because it shouldn't be called!
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_humanized.yaml", {
        "outcomes": [{"id": "outcome_success", "humanize": False}]
    })
    tid = str(uuid.uuid4())
    
    print("Merged Outcomes:", tool.engine.outcomes)
    tool.execute(thread_id=tid, initial_context={})
    # 'val' is returned, triggering outcome_success which skips humanizer
    try:
        result = tool.execute(thread_id=tid, user_message="val", initial_context={})
    except Exception:
        raise
    
    # 3rd mock wasn't hit, and the raw outcome template is returned in the interrupt
    assert "Raw success message" in str(result)
    assert "field_a=" in str(result)


# ===========================================================================
# 3. Localization Instructions
# ===========================================================================

@respx.mock
def test_localization_instructions_in_collector_prompt():
    """localization.instructions override appears in system prompt (without language)."""
    captured = []
    
    def _side_effect(request):
        captured.append(request)
        return next(responses)

    responses = iter([collector_prompt()])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_single_step.yaml", {
        "localization": {"instructions": "RUNTIME_LOCAL_INSTR: Speak plainly"}
    })
    tid = str(uuid.uuid4())
    tool.execute(thread_id=tid, initial_context={})

    assert len(captured) >= 1
    req_body = json.loads(captured[0].content)
    system_prompt = " ".join(m["content"] for m in req_body.get("messages", []) if m["role"] == "system")
    assert "RUNTIME_LOCAL_INSTR: Speak plainly" in system_prompt, (
        "Localization instructions must appear in system prompt even if language is empty"
    )


# ===========================================================================
# 4. Field Redirection Interaction
# ===========================================================================

@respx.mock
def test_steps_field_override_changes_storage_slot():
    """steps[].field override changes where the LLM's captured value is stored.
    
    The step normally collects into 'field_a'. We override the step to collect
    into 'field_b' instead. The structured output model still produces 'field_a'
    because it's tied to the field's schema name, but the collector engine maps
    it to 'field_b' based on step['field'].
    """
    responses = iter([
        collector_prompt(),
        # The LLM still returns the key 'field_b' because the SO schema was rebuilt
        llm_structured_response({"bot_response": None, "field_b": "redirected_val"}), 
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        # 'field_b' is NOT in data[], so we must add it to pass schema validation
        "data": [{"name": "field_b", "type": "text", "description": "New target"}],
        "steps": [{"id": "collect_a", "field": "field_b", "agent": {
            # Must also update agent structured output fields to tell LLM to produce field_b
            "structured_output": {"fields": [{"name": "field_b", "type": "text", "description": "b"}]}
        }}]
    })
    print("Merged Steps:", tool.engine.steps)
    tid = str(uuid.uuid4())
    
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="here is val", initial_context={})
    
    state = snap(tool, tid)
    # The output is stored inside the targeted field key, as a dict generated by the LLM 
    assert state.get("field_b", {}).get("field_b") == "redirected_val", "Data must be stored in the new field slot"
    assert state.get("field_a") is None, "Old field slot must remain empty"


# ===========================================================================
# 6. Schema Constraint Enforcement (Validation follow_up)
# ===========================================================================

def test_config_follow_up_additional_properties_rejected():
    """follow_up schema has additionalProperties: False.
    
    Now that engine.py validates merged configs, adding an unknown property
    at runtime should raise a validation error.
    """
    with pytest.raises(RuntimeError, match="Validation failed|additional properties"):
        _make("follow_up_single_step.yaml", {
            "follow_up": {"unknown_property_123": True}
        })


# ===========================================================================
# 7. Agent Humanize Interaction
# ===========================================================================

def test_config_agent_humanize_vs_outcome_humanize():
    """Conflicting humanize flags: 
    agent.humanize controls the COLLECTOR agent's use of humanized prompts.
    outcomes.humanize controls the engine passing outcome messages to the humanizer LLM.
    These are independent.
    """
    tool = _make("follow_up_humanized.yaml", {
        "steps": [{"id": "collect_a", "agent": {"humanize": False}}],
        "outcomes": [{"id": "outcome_success", "humanize": True}]
    })
    # The config merge preserves both flags distinctly
    step = next(s for s in tool.engine.steps if s["id"] == "collect_a")
    outcome = next(o for o in tool.engine.outcomes if o["id"] == "outcome_success")
    
    assert step["agent"]["humanize"] is False
    assert outcome["humanize"] is True
