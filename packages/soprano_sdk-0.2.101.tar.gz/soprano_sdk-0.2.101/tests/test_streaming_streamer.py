"""Tests for soprano_sdk.streaming.streamer -- WorkflowStreamer with mocked SDK."""

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from soprano_sdk.streaming.events import (
    AsyncInterruptEvent,
    CompleteEvent,
    CustomEvent,
    ErrorEvent,
    InterruptEvent,
    NodeCompleteEvent,
    OutOfScopeEvent,
    RedirectEvent,
)
from soprano_sdk.streaming.streamer import WorkflowStreamer, _serialize


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _make_state_snapshot(*, next_nodes=None, values=None, tasks=None):
    snap = SimpleNamespace()
    snap.next = tuple(next_nodes) if next_nodes else ()
    snap.values = values or {}
    snap.tasks = tasks or []
    return snap


def _make_interrupt_task(value):
    interrupt = SimpleNamespace(value=value)
    task = SimpleNamespace(interrupts=[interrupt])
    return task


def _make_streamer(graph=None, engine=None, name="test_workflow"):
    if graph is None:
        graph = MagicMock()
    if engine is None:
        engine = MagicMock()
        engine.workflow_name = "test_workflow"
        engine.collector_node_field_map = {}
    streamer = object.__new__(WorkflowStreamer)
    streamer._graph = graph
    streamer._engine = engine
    streamer._name = name
    streamer._checkpointer = None
    return streamer


# ------------------------------------------------------------------
# _serialize
# ------------------------------------------------------------------


class TestSerialize:
    def test_primitives(self):
        assert _serialize("hello") == "hello"
        assert _serialize(42) == 42
        assert _serialize(3.14) == 3.14
        assert _serialize(True) is True
        assert _serialize(None) is None

    def test_dict(self):
        assert _serialize({"a": 1, "b": "x"}) == {"a": 1, "b": "x"}

    def test_list(self):
        assert _serialize([1, "two", None]) == [1, "two", None]

    def test_nested(self):
        assert _serialize({"a": [1, {"b": 2}]}) == {"a": [1, {"b": 2}]}

    def test_non_serializable_becomes_str(self):
        class Custom:
            def __str__(self):
                return "custom-obj"

        assert _serialize(Custom()) == "custom-obj"


# ------------------------------------------------------------------
# stream() — fresh start, workflow completes
# ------------------------------------------------------------------


class TestStreamFreshComplete:
    def test_yields_node_complete_then_complete(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={"greeting": "Hello!"}),
        ]
        graph.stream.return_value = iter([
            ("updates", {"build_greeting": {"greeting": "Hello!"}}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Hello!"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", "hi"))

        assert len(events) == 2
        assert isinstance(events[0], NodeCompleteEvent)
        assert events[0].node == "build_greeting"
        assert isinstance(events[1], CompleteEvent)
        assert events[1].message == "Hello!"


# ------------------------------------------------------------------
# stream() — fresh start, workflow interrupts for user input
# ------------------------------------------------------------------


class TestStreamFreshInterrupt:
    def test_yields_node_complete_then_interrupt(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(
                next_nodes=["collect_name"],
                values={},
                tasks=[_make_interrupt_task("What is your name?")],
            ),
        ]
        graph.stream.return_value = iter([
            ("updates", {"collect_name": {"_status": "collect_name_collecting"}}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        engine.build_field_details.return_value = [{"name": "user_name", "value": None}]

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        assert len(events) == 2
        assert isinstance(events[0], NodeCompleteEvent)
        assert isinstance(events[1], InterruptEvent)
        assert events[1].prompt == "What is your name?"
        assert events[1].field_details == [{"name": "user_name", "value": None}]

    def test_structured_interrupt_with_options(self):
        graph = MagicMock()
        interrupt_val = {
            "text": "Pick a color",
            "options": [{"text": "Red"}, {"text": "Blue"}],
            "is_selectable": True,
        }
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(
                next_nodes=["collect_color"],
                values={},
                tasks=[_make_interrupt_task(interrupt_val)],
            ),
        ]
        graph.stream.return_value = iter([])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        engine.build_field_details.return_value = []

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        interrupt = events[-1]
        assert isinstance(interrupt, InterruptEvent)
        assert interrupt.prompt == "Pick a color"
        assert len(interrupt.options) == 2
        assert interrupt.is_selectable is True


# ------------------------------------------------------------------
# stream() — async interrupt
# ------------------------------------------------------------------


class TestStreamAsyncInterrupt:
    def test_async_interrupt_yields_event(self):
        graph = MagicMock()
        interrupt_val = {
            "type": "async",
            "step_id": "verify_payment",
            "pending": {"callback_url": "https://example.com"},
        }
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(
                next_nodes=["verify_payment"],
                values={},
                tasks=[_make_interrupt_task(interrupt_val)],
            ),
        ]
        graph.stream.return_value = iter([])

        streamer = _make_streamer(graph)
        events = list(streamer.stream("t1", ""))

        assert isinstance(events[-1], AsyncInterruptEvent)
        assert events[-1].thread_id == "t1"
        assert events[-1].step_id == "verify_payment"
        assert events[-1].pending == {"callback_url": "https://example.com"}


# ------------------------------------------------------------------
# stream() — out-of-scope interrupt
# ------------------------------------------------------------------


class TestStreamOutOfScopeInterrupt:
    def test_out_of_scope_yields_event(self):
        graph = MagicMock()
        interrupt_val = {
            "type": "out_of_scope",
            "reason": "Not about returns",
            "user_message": "What's the weather?",
        }
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(
                next_nodes=["collect_reason"],
                values={},
                tasks=[_make_interrupt_task(interrupt_val)],
            ),
        ]
        graph.stream.return_value = iter([])

        streamer = _make_streamer(graph)
        events = list(streamer.stream("t1", "What's the weather?"))

        assert isinstance(events[-1], OutOfScopeEvent)
        assert events[-1].reason == "Not about returns"
        assert events[-1].user_message == "What's the weather?"


# ------------------------------------------------------------------
# stream() — resume after interrupt
# ------------------------------------------------------------------


class TestStreamResume:
    def test_resume_sends_command(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=["collect_name"]),
            _make_state_snapshot(next_nodes=[], values={"user_name": "Alice"}),
        ]
        graph.stream.return_value = iter([
            ("updates", {"collect_name": {"user_name": "Alice"}}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        engine.update_context = MagicMock()
        outcome = MagicMock()
        outcome.message = "Hello Alice!"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        list(streamer.stream("t1", "Alice"))

        call_args = graph.stream.call_args
        input_val = call_args[0][0]
        assert hasattr(input_val, "resume")
        assert input_val.resume == "Alice"

    def test_resume_calls_update_state_before_command(self):
        """Per LangGraph docs, state updates go through update_state(),
        not Command(update=...). Verify update_state is called before stream."""
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=["collect_name"], values={"existing": "val"}),
            _make_state_snapshot(next_nodes=[], values={"user_name": "Alice"}),
        ]
        graph.stream.return_value = iter([
            ("updates", {"collect_name": {"user_name": "Alice"}}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Hello Alice!"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        list(streamer.stream("t1", "Alice"))

        # update_state must be called before stream
        graph.update_state.assert_called_once()

        # Command should only have resume, not update
        input_val = graph.stream.call_args[0][0]
        assert hasattr(input_val, "resume")
        assert not hasattr(input_val, "update") or input_val.update is None


# ------------------------------------------------------------------
# stream() — interrupt detection via tasks[].interrupts
# ------------------------------------------------------------------


class TestInterruptDetectionViaTasks:
    """Per LangGraph docs, state.tasks[].interrupts is the authoritative
    source for interrupt data. state.next may or may not be populated."""

    def test_interrupt_detected_when_next_is_empty(self):
        """Interrupt should be detected even if state.next is empty,
        as long as tasks[].interrupts has data."""
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(
                next_nodes=[],  # empty — but tasks has interrupt
                values={},
                tasks=[_make_interrupt_task("What is your name?")],
            ),
        ]
        graph.stream.return_value = iter([
            ("updates", {"collect_name": {"_status": "collecting"}}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        engine.build_field_details.return_value = []

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        assert isinstance(events[-1], InterruptEvent)
        assert events[-1].prompt == "What is your name?"

    def test_out_of_scope_detected_when_next_is_empty(self):
        """OutOfScopeEvent should be detected even if state.next is empty."""
        graph = MagicMock()
        interrupt_val = {
            "type": "out_of_scope",
            "reason": "Not about returns",
            "user_message": "What's the weather?",
        }
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(
                next_nodes=[],
                values={},
                tasks=[_make_interrupt_task(interrupt_val)],
            ),
        ]
        graph.stream.return_value = iter([])

        streamer = _make_streamer(graph)
        events = list(streamer.stream("t1", "What's the weather?"))

        assert isinstance(events[-1], OutOfScopeEvent)
        assert events[-1].reason == "Not about returns"

    def test_async_interrupt_detected_when_next_is_empty(self):
        """AsyncInterruptEvent should be detected even if state.next is empty."""
        graph = MagicMock()
        interrupt_val = {
            "type": "async",
            "step_id": "verify_kyc",
            "pending": {"callback_url": "https://example.com/kyc"},
        }
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(
                next_nodes=[],
                values={},
                tasks=[_make_interrupt_task(interrupt_val)],
            ),
        ]
        graph.stream.return_value = iter([])

        streamer = _make_streamer(graph)
        events = list(streamer.stream("t1", ""))

        assert isinstance(events[-1], AsyncInterruptEvent)
        assert events[-1].step_id == "verify_kyc"

    def test_no_interrupt_when_tasks_empty(self):
        """When tasks is empty and next is empty, yield CompleteEvent."""
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}, tasks=[]),
        ]
        graph.stream.return_value = iter([])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Done"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        assert isinstance(events[-1], CompleteEvent)

    def test_no_interrupt_when_task_has_no_interrupts(self):
        """When task exists but has no interrupts, yield CompleteEvent."""
        graph = MagicMock()
        task_without_interrupt = SimpleNamespace(interrupts=[])
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}, tasks=[task_without_interrupt]),
        ]
        graph.stream.return_value = iter([])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Done"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        assert isinstance(events[-1], CompleteEvent)


# ------------------------------------------------------------------
# stream() — internal LangGraph nodes filtered
# ------------------------------------------------------------------


class TestInternalNodeFiltering:
    """LangGraph internal nodes (__interrupt__, __start__, __end__)
    should not surface as NodeCompleteEvent."""

    def test_interrupt_node_filtered(self):
        graph = MagicMock()
        interrupt_obj = SimpleNamespace(value="What is your name?")
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(
                next_nodes=["collect_name"],
                values={},
                tasks=[_make_interrupt_task("What is your name?")],
            ),
        ]
        graph.stream.return_value = iter([
            ("updates", {"collect_name": {"_status": "collecting"}}),
            ("updates", {"__interrupt__": [interrupt_obj]}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        engine.build_field_details.return_value = []

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        node_events = [e for e in events if isinstance(e, NodeCompleteEvent)]
        assert len(node_events) == 1
        assert node_events[0].node == "collect_name"

    def test_start_and_end_nodes_filtered(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}),
        ]
        graph.stream.return_value = iter([
            ("updates", {"__start__": {}}),
            ("updates", {"my_node": {"result": "ok"}}),
            ("updates", {"__end__": {}}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Done"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        node_events = [e for e in events if isinstance(e, NodeCompleteEvent)]
        assert len(node_events) == 1
        assert node_events[0].node == "my_node"


# ------------------------------------------------------------------
# stream() — custom events
# ------------------------------------------------------------------


class TestStreamCustomEvents:
    def test_custom_events_yielded(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}),
        ]
        graph.stream.return_value = iter([
            ("custom", {"type": "color_list", "colors": ["red", "blue"]}),
            ("updates", {"suggest_colors": {"available_colors": ["red", "blue"]}}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Done"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        assert len(events) == 3
        assert isinstance(events[0], CustomEvent)
        assert events[0].payload["type"] == "color_list"
        assert isinstance(events[1], NodeCompleteEvent)
        assert isinstance(events[2], CompleteEvent)

    def test_multiple_custom_events_interleaved(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}),
        ]
        graph.stream.return_value = iter([
            ("custom", {"type": "token", "chunk": "a"}),
            ("custom", {"type": "token", "chunk": "b"}),
            ("updates", {"gen_node": {"result": "ab"}}),
        ])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "ab"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        custom_events = [e for e in events if isinstance(e, CustomEvent)]
        assert len(custom_events) == 2
        assert custom_events[0].payload["chunk"] == "a"
        assert custom_events[1].payload["chunk"] == "b"


# ------------------------------------------------------------------
# stream() — error handling
# ------------------------------------------------------------------


class TestStreamErrors:
    def test_exception_yields_error_event(self):
        graph = MagicMock()
        graph.get_state.side_effect = RuntimeError("connection lost")

        streamer = _make_streamer(graph)
        events = list(streamer.stream("t1", ""))

        assert len(events) == 1
        assert isinstance(events[0], ErrorEvent)
        assert "connection lost" in events[0].error

    def test_stream_exception_yields_error_event(self):
        graph = MagicMock()
        graph.get_state.return_value = _make_state_snapshot(next_nodes=[])

        def exploding_stream(*args, **kwargs):
            yield ("updates", {"node1": {"x": 1}})
            raise ValueError("mid-stream failure")

        graph.stream.return_value = exploding_stream()

        streamer = _make_streamer(graph)
        events = list(streamer.stream("t1", ""))

        assert isinstance(events[0], NodeCompleteEvent)
        assert isinstance(events[1], ErrorEvent)
        assert "mid-stream failure" in events[1].error


# ------------------------------------------------------------------
# from_env()
# ------------------------------------------------------------------


class TestFromEnv:
    def test_raises_without_api_key(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        with pytest.raises(RuntimeError, match="OPENAI_API_KEY"):
            WorkflowStreamer.from_env("workflow.yaml")

    @patch("soprano_sdk.streaming.streamer.load_workflow")
    def test_passes_model_config(self, mock_load, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key")
        monkeypatch.setenv("MODEL_NAME", "gpt-4o")

        mock_load.return_value = (MagicMock(), MagicMock())

        WorkflowStreamer.from_env("test.yaml")

        mock_load.assert_called_once()
        call_kwargs = mock_load.call_args
        config = call_kwargs.kwargs.get("config") or call_kwargs[1].get("config")
        assert config["model_config"]["model_name"] == "gpt-4o"
        assert config["model_config"]["api_key"] == "sk-test-key"

    @patch("soprano_sdk.streaming.streamer.load_workflow")
    def test_default_model_name(self, mock_load, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        monkeypatch.delenv("MODEL_NAME", raising=False)

        mock_load.return_value = (MagicMock(), MagicMock())

        WorkflowStreamer.from_env("test.yaml")

        config = mock_load.call_args.kwargs.get("config") or mock_load.call_args[1].get("config")
        assert config["model_config"]["model_name"] == "gpt-4o-mini"


# ------------------------------------------------------------------
# Complete event with options
# ------------------------------------------------------------------


class TestCompleteWithOptions:
    def test_outcome_options_forwarded(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}),
        ]
        graph.stream.return_value = iter([])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Choose next"
        outcome.options = [{"text": "A"}, {"text": "B"}]
        outcome.is_selectable = True
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        complete = events[-1]
        assert isinstance(complete, CompleteEvent)
        assert complete.options == [{"text": "A"}, {"text": "B"}]
        assert complete.is_selectable is True

    def test_none_options_become_empty_list(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}),
        ]
        graph.stream.return_value = iter([])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Done"
        outcome.options = None
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", ""))

        assert events[-1].options == []


# ------------------------------------------------------------------
# stream() — redirect outcome
# ------------------------------------------------------------------


class TestRedirectOutcome:
    def test_redirect_yields_redirect_event(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}),
        ]
        graph.stream.return_value = iter([])

        engine = MagicMock()
        engine.workflow_name = "returns"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "__REDIRECT__|t1|returns|exchanges|We can exchange that for you."
        outcome.options = [{"text": "OK"}]
        outcome.is_selectable = True
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine, name="returns")
        events = list(streamer.stream("t1", "exchange"))

        assert len(events) == 1
        evt = events[0]
        assert isinstance(evt, RedirectEvent)
        assert evt.redirect_to == "exchanges"
        assert evt.message == "We can exchange that for you."
        assert evt.thread_id == "t1"
        assert evt.workflow_name == "returns"
        assert evt.options == [{"text": "OK"}]
        assert evt.is_selectable is True

    def test_non_redirect_still_yields_complete(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}),
        ]
        graph.stream.return_value = iter([])

        engine = MagicMock()
        engine.workflow_name = "returns"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Your return has been processed."
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        events = list(streamer.stream("t1", "done"))

        assert isinstance(events[-1], CompleteEvent)
        assert events[-1].message == "Your return has been processed."


# ------------------------------------------------------------------
# Localization support
# ------------------------------------------------------------------


class TestLocalization:
    def test_language_and_script_passed_on_fresh_start(self):
        graph = MagicMock()
        graph.get_state.side_effect = [
            _make_state_snapshot(next_nodes=[]),
            _make_state_snapshot(next_nodes=[], values={}),
        ]
        graph.stream.return_value = iter([])

        engine = MagicMock()
        engine.workflow_name = "test"
        engine.collector_node_field_map = {}
        outcome = MagicMock()
        outcome.message = "Done"
        outcome.options = []
        outcome.is_selectable = False
        engine.get_outcome_message.return_value = outcome

        streamer = _make_streamer(graph, engine)
        list(streamer.stream("t1", "hi", target_language="Tamil", target_script="Tamil"))

        call_args = graph.stream.call_args[0][0]
        assert call_args["_target_language"] == "Tamil"
        assert call_args["_target_script"] == "Tamil"
