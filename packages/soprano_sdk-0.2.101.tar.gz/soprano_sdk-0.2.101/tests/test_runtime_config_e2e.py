"""End-to-end runtime config override tests with LLM mocked via respx.

Each test proves that runtime config takes precedence over the YAML config
through **observable graph behaviour** — not just config inspection.

The YAML base for most tests is ``follow_up_single_step.yaml``, which defines:
  - follow_up.enabled          = true
  - follow_up.max_attempts     = 3
  - follow_up.on_max_attempts_reached = "Max attempts reached. Goodbye."
  - follow_up.instructions     = "You are a helpful follow-up assistant."
  - outcome_success.message    = "Success! field_a={{ field_a }}"
  - outcome_success.follow_up  = true  (all outcomes)
  - humanization_agent.enabled = false

All tests override some of these values at runtime and assert the graph
behaves according to the **runtime** value, not the YAML value.
"""

import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    CapturingCheckpointer,
    MODEL_CONFIG,
    FIXTURES,
    collector_capture,
    collector_prompt,
    fu_answer,
    llm_structured_response,
    snap,
)
from soprano_sdk.tools import WorkflowTool


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _make(yaml_name: str, extra: dict = None) -> WorkflowTool:
    config = {"model_config": MODEL_CONFIG, **(extra or {})}
    return WorkflowTool(
        yaml_path=str(FIXTURES / yaml_name),
        name="test",
        description="test",
        checkpointer=CapturingCheckpointer(),
        config=config,
    )


def _humanizer(text: str):
    return llm_structured_response({"message": text, "options": None, "is_selectable": None})


# ===========================================================================
# 1. follow_up.enabled — YAML: true, runtime: false → no FOLLOW_UP interrupt
# ===========================================================================

@respx.mock
def test_follow_up_enabled_yaml_true_overridden_false():
    """YAML enables follow-up; runtime disables it.

    Observable: graph ends cleanly after the outcome (no FOLLOW_UP interrupt).
    Only 2 LLM calls (prompt + capture); no follow-up node runs.
    """
    responses = iter([collector_prompt(), collector_capture("myval")])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {"follow_up": {"enabled": False}})
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result = tool.execute(thread_id=tid, user_message="myval", initial_context={})

    assert InterruptType.FOLLOW_UP not in str(result), (
        "YAML: follow_up.enabled=true, runtime: false → no FOLLOW_UP expected"
    )
    assert snap(tool, tid)["_outcome_id"] == "outcome_success"
    assert respx.calls.call_count == 2  # no extra LLM call for follow-up


# ===========================================================================
# 2. follow_up.max_attempts — YAML: 3, runtime: 1 → exhausted after 1 turn
# ===========================================================================

@respx.mock
def test_follow_up_max_attempts_yaml_3_overridden_1():
    """YAML sets max_attempts=3; runtime reduces it to 1.

    Observable: 2nd follow-up question exhausts the runtime limit (max=1),
    returning the on_max_attempts_reached message instead of calling the LLM again.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("myval"),
        fu_answer("Answer to Q1."),      # turn 1 — within limit
        # turn 2 is over the runtime limit (max=1); no LLM call expected
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {"follow_up": {"max_attempts": 1}})
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="myval", initial_context={})     # outcome → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="question 1", initial_context={})  # attempt 1 (allowed)
    result_exhaust = tool.execute(thread_id=tid, user_message="question 2", initial_context={})

    assert InterruptType.FOLLOW_UP not in str(result_exhaust), (
        "runtime max_attempts=1 — 2nd turn should exhaust and terminate"
    )
    # YAML farewell is still used (only max_attempts was overridden)
    assert "Max attempts reached. Goodbye." in str(result_exhaust)
    assert respx.calls.call_count == 3  # no LLM on exhaustion turn


# ===========================================================================
# 3. follow_up.on_max_attempts_reached — YAML: "Max attempts reached. Goodbye.",
#    runtime: custom message → farewell is the runtime value
# ===========================================================================

@respx.mock
def test_follow_up_farewell_message_overridden_at_runtime():
    """YAML on_max_attempts_reached = "Max attempts reached. Goodbye."
    Runtime overrides it to "Runtime farewell." — exhaustion should return
    the runtime farewell, not the YAML one.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("anyval"),
        fu_answer("Answer 1."),
        fu_answer("Answer 2."),
        fu_answer("Answer 3."),
        # turn 4 → exhaustion; no LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"on_max_attempts_reached": "Runtime farewell."}
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="anyval", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})
    tool.execute(thread_id=tid, user_message="q2", initial_context={})
    tool.execute(thread_id=tid, user_message="q3", initial_context={})
    result = tool.execute(thread_id=tid, user_message="q4", initial_context={})

    assert "Runtime farewell." in str(result), (
        "runtime on_max_attempts_reached should appear, not YAML value"
    )
    assert "Max attempts reached. Goodbye." not in str(result), (
        "YAML farewell must NOT appear — runtime value takes precedence"
    )


# ===========================================================================
# 4. outcome.message — YAML: "Success! field_a={{ field_a }}"
#    runtime: "Runtime success: {{ field_a }}" → delivered message is runtime value
# ===========================================================================

@respx.mock
def test_outcome_message_overridden_at_runtime():
    """YAML outcome_success.message = "Success! field_a={{ field_a }}"
    Runtime overrides to "Runtime success: {{ field_a }}" — the interrupt payload
    must contain the runtime-rendered message, not the YAML one.
    """
    responses = iter([collector_prompt(), collector_capture("hello")])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "message": "Runtime success: {{ field_a }}"}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result = tool.execute(thread_id=tid, user_message="hello", initial_context={})

    # The template renders "Runtime success: <state_value_of_field_a>"
    # (the exact state representation may include structured-output context,
    # so assert on the distinguishing runtime prefix rather than exact field value)
    assert "Runtime success:" in str(result), (
        "runtime outcome message must appear in FOLLOW_UP interrupt"
    )
    assert "Success! field_a=" not in str(result), (
        "YAML outcome message must NOT appear — runtime takes precedence"
    )


# ===========================================================================
# 5. outcome.follow_up (per-outcome flag) — YAML: true, runtime: false
#    → no FOLLOW_UP interrupt for that specific outcome
# ===========================================================================

@respx.mock
def test_per_outcome_follow_up_flag_overridden_false():
    """YAML outcome_success.follow_up = true; runtime overrides to false.
    The graph should end after the outcome (no FOLLOW_UP interrupt), while
    other outcomes (outcome_failure) still honour their YAML follow_up=true.
    """
    responses = iter([collector_prompt(), collector_capture("myval")])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "follow_up": False}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result = tool.execute(thread_id=tid, user_message="myval", initial_context={})

    assert InterruptType.FOLLOW_UP not in str(result), (
        "outcome_success.follow_up=false (runtime) → no FOLLOW_UP"
    )
    assert snap(tool, tid)["_outcome_id"] == "outcome_success"
    assert respx.calls.call_count == 2


# ===========================================================================
# 6. humanization_agent.enabled — YAML: false, runtime: true
#    → humanizer LLM is called before the follow-up interrupt
# ===========================================================================

@respx.mock
def test_humanization_enabled_at_runtime():
    """YAML humanization_agent.enabled=false; runtime enables it.

    Observable: a 3rd LLM call (humanizer) is made before the FOLLOW_UP
    interrupt, and the result contains the humanized text.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("hello"),
        _humanizer("Humanised at runtime: hello."),  # 3rd call — humanizer
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "humanization_agent": {"enabled": True},
        # Per-outcome humanize=false in the YAML takes precedence over the global agent;
        # override it to true so humanization actually runs for this outcome.
        "outcomes": [
            {"id": "outcome_success", "humanize": True},
            {"id": "outcome_failure", "humanize": True},
            {"id": "outcome_redirect", "humanize": True},
            {"id": "outcome_no_followup", "humanize": True},
        ],
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result = tool.execute(thread_id=tid, user_message="hello", initial_context={})

    assert "Humanised at runtime:" in str(result), (
        "humanization_agent.enabled=true (runtime) → humanized message expected"
    )
    assert respx.calls.call_count == 3  # collector prompt, capture, + humanizer


# ===========================================================================
# 7. humanization_agent.enabled — YAML(follow_up_humanized.yaml): true,
#    runtime: false → humanizer NOT called; raw message delivered
# ===========================================================================

@respx.mock
def test_humanization_disabled_at_runtime():
    """YAML (follow_up_humanized.yaml) enables humanization; runtime disables.

    Observable: only 2 LLM calls (no humanizer call), raw outcome message
    is returned directly without "Humanized:" prefix.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("hello"),
        # no humanizer call expected
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_humanized.yaml", {
        "humanization_agent": {"enabled": False}
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result = tool.execute(thread_id=tid, user_message="hello", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result)
    assert "Humanized:" not in str(result), (
        "humanization disabled at runtime → no humanizer prefix"
    )
    assert respx.calls.call_count == 2  # no 3rd humanizer call


# ===========================================================================
# 8. steps[].agent.instructions — YAML: "Collect field A from the user."
#    runtime: "RUNTIME: ask the user for alpha." → LLM system prompt uses runtime value
# ===========================================================================

@respx.mock
def test_step_agent_instructions_overridden_at_runtime():
    """YAML agent.instructions; runtime overrides.

    Observable: the LLM request for the first turn contains the runtime
    instructions in its system message, not the YAML instructions.
    """
    captured = []

    def _side_effect(req):
        captured.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Please provide alpha."),
        collector_capture("alpha"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"enabled": False},  # keep test focused on step only
        "steps": [
            {"id": "collect_a", "agent": {"instructions": "RUNTIME: ask the user for alpha."}}
        ],
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})  # LLM#1: collector prompt

    # Inspect the first LLM request — system prompt must contain runtime instructions
    req_body = json.loads(captured[0].content)
    messages = req_body.get("messages", [])
    system_messages = [m for m in messages if m.get("role") == "system"]

    assert system_messages, "No system message found in LLM request"
    system_content = " ".join(m.get("content", "") for m in system_messages)

    assert "RUNTIME: ask the user for alpha." in system_content, (
        f"Runtime instructions must appear in system prompt. Got: {system_content[:300]}"
    )
    assert "Collect field A from the user." not in system_content, (
        "YAML instructions must NOT appear — runtime takes precedence"
    )


# ===========================================================================
# 9. follow_up.instructions — runtime overrides YAML instructions
#    → follow-up LLM request system prompt uses the runtime value
# ===========================================================================

@respx.mock
def test_follow_up_instructions_overridden_at_runtime():
    """YAML follow_up.instructions = "You are a helpful follow-up assistant."
    Runtime overrides to "RUNTIME follow-up agent." — the LLM call for the
    first follow-up turn must use the runtime system prompt.
    """
    captured = []

    def _side_effect(req):
        captured.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        fu_answer("Follow-up answer."),   # LLM#3: first follow-up turn
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"instructions": "RUNTIME follow-up agent."}
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val", initial_context={})   # → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="q1", initial_context={})    # LLM#3

    assert len(captured) >= 3
    fu_req_body = json.loads(captured[2].content)
    system_msgs = [m for m in fu_req_body.get("messages", []) if m.get("role") == "system"]
    system_text = " ".join(m.get("content", "") for m in system_msgs)

    assert "RUNTIME follow-up agent." in system_text, (
        f"Runtime follow_up.instructions must be in LLM system prompt. Got: {system_text[:300]}"
    )
    assert "You are a helpful follow-up assistant." not in system_text, (
        "YAML follow_up.instructions must NOT appear — runtime takes precedence"
    )


# ===========================================================================
# 10. Mixed: YAML base + multiple runtime overrides simultaneously
#     follow_up.max_attempts, outcome.message, and agent.instructions
#     all overridden — each observable independently
# ===========================================================================

@respx.mock
def test_mixed_multiple_runtime_overrides():
    """YAML base + 3 simultaneous runtime overrides.

    YAML  : follow_up.max_attempts=3, outcome.message="Success! field_a=…",
            agent.instructions="Collect field A…"
    Runtime: max_attempts=1, message="Done: {{ field_a }}", instructions="RUNTIME."

    Assertions (in one test to reduce fixture overhead):
    - Outcome message = runtime version
    - FOLLOW_UP is active after outcome (enabled=true from YAML, not overridden)
    - After 2nd follow-up question → exhausted (runtime max=1), farewell shown
    """
    captured = []

    def _side_effect(req):
        captured.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),                  # LLM#1: collector
        collector_capture("alpha"),          # LLM#2: capture
        fu_answer("Got it."),               # LLM#3: follow-up turn 1 (allowed; max=1)
        # LLM#4: NOT called — turn 2 exceeds runtime max_attempts=1
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"max_attempts": 1},
        "outcomes": [{"id": "outcome_success", "message": "Done: {{ field_a }}"}],
        "steps": [{"id": "collect_a", "agent": {"instructions": "RUNTIME."}}],
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    # Check runtime step instructions in LLM#1
    req_body = json.loads(captured[0].content)
    system_text = " ".join(
        m.get("content", "") for m in req_body.get("messages", [])
        if m.get("role") == "system"
    )
    assert "RUNTIME." in system_text, "Runtime step instructions must be in LLM#1 system prompt"

    # Complete the workflow → FOLLOW_UP
    result_outcome = tool.execute(thread_id=tid, user_message="alpha", initial_context={})
    # Template renders "Done: <state_value>"; assert on the prefix
    assert "Done:" in str(result_outcome), "Runtime outcome message prefix must appear"
    assert "Success! field_a=" not in str(result_outcome), "YAML outcome must NOT appear"
    assert InterruptType.FOLLOW_UP in str(result_outcome)

    # Follow-up turn 1 (within runtime max=1)
    tool.execute(thread_id=tid, user_message="question 1", initial_context={})

    # Follow-up turn 2 → exhausts runtime max=1
    result_exhaust = tool.execute(thread_id=tid, user_message="question 2", initial_context={})
    assert InterruptType.FOLLOW_UP not in str(result_exhaust), (
        "runtime max_attempts=1 should exhaust after 1 turn"
    )
    assert "Max attempts reached. Goodbye." in str(result_exhaust)  # YAML farewell (not overridden)
    assert respx.calls.call_count == 3  # no LLM on exhaustion turn
