"""Complex end-to-end tests for follow-up restart and intent_change (rollback) combinations.
Verifies multi-restart stability, context persistence, and nested rollback scenarios.
"""

import uuid
import respx
from langgraph.checkpoint.memory import InMemorySaver
from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_restart,
    fu_intent_change,
    llm_structured_response,
    make_tool,
    snap,
)


def _prompt_b(text="Please tell me field B."):
    return llm_structured_response({"bot_response": text, "field_b": None})


def _capture_b(val):
    return llm_structured_response({"bot_response": None, "field_b": val})


def _get_val(state, key):
    """Helper to extract value from potentially nested structured output dict."""
    val = state.get(key)
    if isinstance(val, dict) and key in val:
        return val[key]
    return val


@respx.mock
def test_multi_restart_stability():
    """Verify that multiple consecutive restarts work without state leakage."""
    responses = iter([
        # Round 1
        collector_prompt("Round 1 A?"),
        collector_capture("r1_a"),
        fu_restart("Restarting round 1."),
        # Round 2
        collector_prompt("Round 2 A?"),
        collector_capture("r2_a"),
        fu_restart("Restarting round 2."),
        # Round 3
        collector_prompt("Round 3 A?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    # Round 1
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="r1_a", initial_context={})
    tool.execute(thread_id=tid, user_message="restart", initial_context={})
    
    # Round 2
    tool.execute(thread_id=tid, user_message="r2_a", initial_context={})
    result_restart_2 = tool.execute(thread_id=tid, user_message="restart again", initial_context={})
    
    assert InterruptType.USER_INPUT in str(result_restart_2)
    s = snap(tool, tid)
    assert _get_val(s, "field_a") is None
    
    # Round 3
    # Just verify it still prompts correctly
    assert "Round 3 A?" in str(result_restart_2)


@respx.mock
def test_restart_with_initial_context_persistence():
    """Verify initial_context is re-applied correctly after restart."""
    responses = iter([
        collector_prompt("Give me A."),
        collector_capture("val_a"),
        fu_restart("Restarting to re-apply."),
        collector_prompt("Give me A again."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    # Using fixture that defines customer_id
    tool = make_tool("follow_up_restart_initial_context.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())
    initial_context = {"customer_id": "cust_999"}

    tool.execute(thread_id=tid, initial_context=initial_context)
    tool.execute(thread_id=tid, user_message="val_a", initial_context=initial_context)
    
    result_restart = tool.execute(thread_id=tid, user_message="restart", initial_context=initial_context)
    
    s = snap(tool, tid)
    assert _get_val(s, "customer_id") == "cust_999"
    assert _get_val(s, "field_a") is None
    assert InterruptType.USER_INPUT in str(result_restart)


@respx.mock
def test_intent_change_rollback_after_restart():
    """Verify that rollback after partial run-2 doesn't pull run-1 data."""
    responses = iter([
        # ── Run 1 ──
        collector_prompt("R1 A?"),                   # LLM#1 A prompt
        collector_capture("r1_a"),                  # LLM#2 A capture
        _prompt_b("R1 B?"),                          # LLM#3 B prompt
        _capture_b("r1_b"),                         # LLM#4 B capture
        fu_restart("Reset Run 1."),                  # LLM#5 restart
        # ── Run 2 ──
        collector_prompt("R2 A?"),                   # LLM#6 A prompt
        collector_capture("r2_a"),                  # LLM#7 A capture
        _prompt_b("R2 B?"),                          # LLM#8 B prompt
        _capture_b("r2_b"),                         # LLM#9 B capture
        fu_intent_change("collect_b", "Redo B."),    # LLM#10 intent_change
        _prompt_b("Re-enter B."),                    # LLM#11 B re-prompt
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_two_step.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    # Run 1 complete + restart
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="r1_a", initial_context={})
    tool.execute(thread_id=tid, user_message="r1_b", initial_context={})
    tool.execute(thread_id=tid, user_message="restart", initial_context={})
    
    # Run 2
    tool.execute(thread_id=tid, user_message="r2_a", initial_context={})
    tool.execute(thread_id=tid, user_message="r2_b", initial_context={})
    result_ic = tool.execute(thread_id=tid, user_message="change B", initial_context={})
    
    assert InterruptType.USER_INPUT in str(result_ic)
    s = snap(tool, tid)
    assert _get_val(s, "field_a") == "r2_a" # Should be run 2's value
    assert _get_val(s, "field_b") is None # b was rolled back


@respx.mock
def test_nested_rollbacks():
    """Verify multiple intent_changes correctly truncate history."""
    responses = iter([
        collector_prompt("A?"),
        collector_capture("val_a"),
        _prompt_b("B?"),
        _capture_b("val_b"),
        fu_intent_change("collect_b", "Rollback B once."),
        _prompt_b("B again?"),
        _capture_b("new_b"),
        fu_intent_change("collect_a", "Rollback to A now."),
        collector_prompt("A again?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_two_step.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})
    
    # First rollback to B
    tool.execute(thread_id=tid, user_message="redo b", initial_context={})
    tool.execute(thread_id=tid, user_message="new_b", initial_context={})
    
    # Second rollback all the way to A
    result_rollback_a = tool.execute(thread_id=tid, user_message="redo a", initial_context={})
    
    assert InterruptType.USER_INPUT in str(result_rollback_a)
    s = snap(tool, tid)
    assert _get_val(s, "field_a") is None
    assert _get_val(s, "field_b") is None


@respx.mock
def test_restart_clears_partial_data():
    """Verify that _partial_data is cleared upon restart."""
    responses = iter([
        collector_prompt("Need A."),
        collector_capture("partial_a"), 
        fu_restart("Full reset."),
        collector_prompt("Need A again."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    
    # Manually inject partial data
    config = {"configurable": {"thread_id": tid}}
    tool.graph.update_state(config, {"_partial_data": {"extra": "data"}})
    
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    tool.execute(thread_id=tid, user_message="restart", initial_context={})
    
    s = snap(tool, tid)
    partial = s.get("_partial_data")
    assert not partial or partial == {}
