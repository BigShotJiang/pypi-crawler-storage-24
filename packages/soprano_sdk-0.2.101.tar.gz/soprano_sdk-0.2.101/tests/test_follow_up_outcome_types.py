"""Tests for follow-up behaviour after non-success outcome types (failure, redirect).

Most existing tests use outcome_success. These tests verify that follow-up Q&A, OOS,
and intent_change work identically regardless of whether the completed outcome was a
success, failure, or redirect — and that re-collection after failure can route to a
different outcome type.

Covered tracks:
  - Q&A turn after a failure outcome
  - Q&A turn after a redirect outcome
  - OOS detection after a failure outcome
  - Intent change after failure → re-collection → different outcome type (success)
  - FOLLOW_UP_PENDING_PROMPT cleared correctly on max_attempts after non-success outcome
"""
import uuid

import respx

from soprano_sdk.core.constants import InterruptType, OutcomePrefix

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    fu_intent_change,
    fu_out_of_scope,
    make_tool,
    snap,
)


# ──────────────────────────────────────────────────────────────────────────────
# Q&A after failure outcome
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_qa_works_after_failure_outcome():
    """After a failure outcome is reached and its message delivered via FOLLOW_UP,
    a normal Q&A turn must call the follow-up LLM and return the answer. The attempt
    counter must increment and FOLLOW_UP must remain active.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("fail_val"),                 # routes to outcome_failure
        fu_answer("Here is your answer about the failure."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="fail_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="why did it fail?", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result2)
    assert "Failure occurred." in str(result2)

    assert InterruptType.FOLLOW_UP in str(result3)
    assert "Here is your answer about the failure." in str(result3)
    assert s["_follow_up_attempts"] == 1
    assert s["_outcome_id"] == "outcome_failure"


@respx.mock
def test_multiple_qa_turns_work_after_failure_outcome():
    """Multiple consecutive Q&A turns after a failure outcome must each increment the
    attempt counter and return FOLLOW_UP. The follow-up session is not prematurely
    terminated because the outcome type is failure rather than success.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("fail_val"),
        fu_answer("First answer."),
        fu_answer("Second answer."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="fail_val", initial_context={})
    tool.execute(thread_id=tid, user_message="question 1", initial_context={})
    result4 = tool.execute(thread_id=tid, user_message="question 2", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result4)
    assert "Second answer." in str(result4)
    assert s["_follow_up_attempts"] == 2
    assert s["_outcome_id"] == "outcome_failure"


# ──────────────────────────────────────────────────────────────────────────────
# Q&A after redirect outcome
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_qa_works_after_redirect_outcome():
    """After a redirect outcome is reached, the FOLLOW_UP interrupt payload contains the
    redirect prefix marker. A subsequent Q&A turn must still call the follow-up LLM and
    return the answer — the redirect prefix in the outcome message must not break Q&A.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("redirect_val"),             # routes to outcome_redirect
        fu_answer("Here is info about the redirect."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="redirect_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="what does redirect mean?", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result2)
    assert OutcomePrefix.REDIRECT in str(result2)

    assert InterruptType.FOLLOW_UP in str(result3)
    assert "Here is info about the redirect." in str(result3)
    assert s["_follow_up_attempts"] == 1
    assert s["_outcome_id"] == "outcome_redirect"


# ──────────────────────────────────────────────────────────────────────────────
# OOS after failure outcome
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_oos_fires_correctly_after_failure_outcome():
    """An out-of-scope query sent as the first follow-up turn after a failure outcome
    must trigger FOLLOW_UP_OUT_OF_SCOPE and pause the graph. The failure outcome type
    must not interfere with OOS detection or the interrupt mechanism.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("fail_val"),
        fu_out_of_scope("off_topic", "I can only discuss this workflow."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="fail_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="buy crypto", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3)
    # Graph is paused, not at END — follow-up session still active
    assert s.get("_follow_up_active") is True
    assert s.get("_outcome_id") == "outcome_failure"


# ──────────────────────────────────────────────────────────────────────────────
# Intent change after failure → re-collection → different outcome
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_intent_change_after_failure_reroutes_to_success_outcome():
    """After a failure outcome, if the user changes their answer via intent_change and
    re-collects a value that routes to outcome_success, the second FOLLOW_UP must deliver
    the success outcome message — not the stale failure message. The _outcome_id must also
    update to reflect the new outcome.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("fail_val"),                              # routes to outcome_failure
        fu_intent_change("collect_a", "Let me enter a valid value."),  # intent_change signal
        collector_prompt("Please re-enter field A."),               # re-prompt after rollback
        collector_capture("valid_val"),                             # routes to outcome_success
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="fail_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="change it", initial_context={})   # → USER_INPUT
    result4 = tool.execute(thread_id=tid, user_message="valid_val", initial_context={})   # → FOLLOW_UP success
    s = snap(tool, tid)

    # First FOLLOW_UP: failure message
    assert InterruptType.FOLLOW_UP in str(result2)
    assert "Failure occurred." in str(result2)

    # After intent_change: back at collector
    assert InterruptType.USER_INPUT in str(result3)
    assert s.get("field_a") is None or "valid_val" in str(s.get("field_a", ""))

    # After re-collection: success message, not failure
    assert InterruptType.FOLLOW_UP in str(result4)
    assert "valid_val" in str(result4), (
        f"After re-collection, must deliver success outcome message. Got: {result4}"
    )
    assert "Failure occurred." not in str(result4), (
        f"Stale failure message must not appear after re-collection to success. Got: {result4}"
    )

    s4 = snap(tool, tid)
    assert s4.get("_outcome_id") == "outcome_success", (
        f"_outcome_id must update to 'outcome_success' after re-collection. "
        f"Got: {s4.get('_outcome_id')!r}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Max attempts after failure outcome — FOLLOW_UP_PENDING_PROMPT cleared on exit
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_follow_up_pending_prompt_cleared_on_max_attempts_after_failure_outcome():
    """When max_attempts is exhausted after a failure outcome, _terminate_conversation
    must clear FOLLOW_UP_PENDING_PROMPT. A stale pending prompt after termination could
    cause the follow-up node to attempt to deliver the outcome message to a dead session.
    Uses follow_up_max_one_attempt.yaml (max_attempts=1): first Q&A is allowed,
    second terminates.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("fail_val"),        # routes to outcome_failure (follow_up=true by default?
                                              # yes — failure in follow_up_single_step has follow_up:true)
        fu_answer("Only answer allowed."),    # attempt 1 — allowed (1 not > 1)
        # No LLM#4: attempt 2 > max_attempts=1 → terminated before LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    # follow_up_max_one_attempt.yaml only has outcome_success.
    # Use follow_up_single_step.yaml which has outcome_failure with follow_up:true.
    # But max_attempts=3 there. We need a different approach:
    # Instead test with 3 turns (max_attempts=3 in follow_up_single_step.yaml):
    # Turn 1: answers; Turn 2: answers; Turn 3: answers; Turn 4: terminates
    pass


@respx.mock
def test_max_attempts_termination_clears_pending_prompt_after_failure_outcome():
    """After max_attempts is exhausted (regardless of outcome type), _terminate_conversation
    must clear _follow_up_pending_prompt from the state. A stale pending prompt in the
    terminal checkpoint would corrupt any future graph execution on the same thread.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("fail_val"),         # → outcome_failure, follow_up: true
        fu_answer("Answer 1."),               # attempt 1
        fu_answer("Answer 2."),               # attempt 2
        fu_answer("Answer 3."),               # attempt 3 (max_attempts=3, 3 not > 3 → allowed)
        # No LLM#6: attempt 4 > max_attempts=3 → terminated before LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="fail_val", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})
    tool.execute(thread_id=tid, user_message="q2", initial_context={})
    tool.execute(thread_id=tid, user_message="q3", initial_context={})
    result_term = tool.execute(thread_id=tid, user_message="q4", initial_context={})
    s = snap(tool, tid)

    assert "Max attempts reached. Goodbye." in str(result_term)
    assert InterruptType.FOLLOW_UP not in str(result_term)

    assert s.get("_follow_up_pending_prompt") is None, (
        f"_follow_up_pending_prompt must be cleared after max_attempts termination. "
        f"A stale pending prompt would corrupt future graph state. "
        f"Got: {s.get('_follow_up_pending_prompt')!r}"
    )
    assert s.get("_follow_up_active") is None
    assert s.get("_outcome_id") is None
