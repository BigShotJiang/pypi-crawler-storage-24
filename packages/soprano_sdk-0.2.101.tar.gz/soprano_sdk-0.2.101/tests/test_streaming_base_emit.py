"""Tests for emit() working inside node execution via get_stream_writer()."""

from unittest.mock import MagicMock, patch

from soprano_sdk.streaming import emit


class _ConcreteStrategy:
    """Minimal concrete strategy for testing."""

    @staticmethod
    def make(step_id="test_node", execute_fn=None):
        from soprano_sdk.nodes.base import ActionStrategy

        class _Impl(ActionStrategy):
            def pre_execute(self, state):
                pass

            def execute(self, state):
                if execute_fn:
                    return execute_fn(self, state)
                return state

        engine = MagicMock()
        engine.failure_message = None
        return _Impl({"id": step_id, "action": "test"}, engine)


class TestEmitInsideNodeExecution:
    """Module-level emit() works inside node execution via get_stream_writer()."""

    def test_emit_writes_to_stream_writer_during_execute(self):
        writer = MagicMock()

        def execute_with_emit(self, state):
            emit("my_event", {"key": "val"})
            return state

        strategy = _ConcreteStrategy.make(execute_fn=execute_with_emit)

        with patch("soprano_sdk.streaming.get_stream_writer", return_value=writer):
            with patch("soprano_sdk.nodes.base.logger"):
                node_fn = strategy.get_node_function()
                node_fn({})

        writer.assert_called()
        call_args = writer.call_args[0][0]
        assert call_args["type"] == "my_event"
        assert call_args["key"] == "val"

    def test_emit_noop_when_not_streaming(self):
        """emit() is a no-op when get_stream_writer() raises (non-streaming mode)."""
        def execute_with_emit(self, state):
            emit("should_not_crash")
            return state

        strategy = _ConcreteStrategy.make(execute_fn=execute_with_emit)

        with patch("soprano_sdk.streaming.get_stream_writer", side_effect=RuntimeError):
            with patch("soprano_sdk.nodes.base.logger"):
                node_fn = strategy.get_node_function()
                node_fn({})  # Should not raise
