"""Runtime configuration override tests — exhaustive schema.py coverage.

Every parameter defined in ``soprano_sdk/validation/schema.py`` is tested here
to verify it can be set or overridden at runtime via ``WorkflowTool(config=...)``.

Test naming convention:
  ``test_<schema_path>_runtime_override``
  e.g. ``test_steps_agent_model_runtime_override``

Test strategy:
  - Config-level tests: verify the merged config (engine.steps, engine.outcomes,
    engine.follow_up_config, engine._get_humanization_config(), …) holds the
    expected value. No LLM calls needed for pure config assertions.
  - End-to-end tests (decorated with @respx.mock): only where the schema property
    actually affects graph behaviour (follow_up.enabled, outcome.follow_up flag).

Fixtures used:
  - follow_up_single_step.yaml  — rich step/outcome/follow_up base
  - follow_up_two_step.yaml    — two collector steps (collect_a, collect_b)
  - so_bool_transition.yaml    — multi-field step; no follow_up block in YAML
"""

import uuid
import respx

from soprano_sdk.core.constants import InterruptType
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    CapturingCheckpointer,
    MODEL_CONFIG,
    FIXTURES,
    collector_capture,
    collector_prompt,
    llm_structured_response,
    snap,
)
from soprano_sdk.tools import WorkflowTool


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _make(yaml_name: str, extra: dict = None) -> WorkflowTool:
    """Build a WorkflowTool from a fixture with optional runtime config overrides."""
    config = {"model_config": MODEL_CONFIG, **(extra or {})}
    return WorkflowTool(
        yaml_path=str(FIXTURES / yaml_name),
        name="test",
        description="test",
        checkpointer=CapturingCheckpointer(),
        config=config,
    )


def _steps(tool: WorkflowTool) -> dict:
    """Return a step-id→step-dict map from the merged engine config."""
    return {s["id"]: s for s in tool.engine.steps}


def _outcomes(tool: WorkflowTool) -> dict:
    """Return an outcome-id→outcome-dict map from the merged engine config."""
    return {o["id"]: o for o in tool.engine.outcomes}


# ===========================================================================
# TOP-LEVEL SCALAR PROPERTIES
# required by schema: name, description, version
# optional: agent_framework, failure_message, rollback_strategy, inputs
# ===========================================================================

def test_name_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"name": "Runtime Name"})
    assert tool.engine.workflow_name == "Runtime Name"


def test_description_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"description": "Runtime description."})
    assert tool.engine.workflow_description == "Runtime description."


def test_version_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"version": "9.9.9"})
    assert tool.engine.workflow_version == "9.9.9"


def test_agent_framework_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"agent_framework": "crewai"})
    # agent_framework is merged into self.config (YAML-schema key)
    assert tool.engine.config["agent_framework"] == "crewai"


def test_failure_message_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"failure_message": "Runtime failure."})
    assert tool.engine.failure_message == "Runtime failure."


def test_rollback_strategy_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"rollback_strategy": "field_based"})
    assert tool.engine.config.get("rollback_strategy") == "field_based"


# ===========================================================================
# HUMANIZATION_AGENT block (schema: humanization_agent.*)
# ===========================================================================

def test_humanization_agent_enabled_runtime_override():
    # follow_up_single_step.yaml has humanization_agent.enabled=false
    tool = _make("follow_up_single_step.yaml", {"humanization_agent": {"enabled": True}})
    assert tool.engine._get_humanization_config()["enabled"] is True


def test_humanization_agent_model_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"humanization_agent": {"model": "gpt-4o"}})
    assert tool.engine._get_humanization_config()["model"] == "gpt-4o"


def test_humanization_agent_base_url_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "humanization_agent": {"base_url": "http://custom-llm/v1"}
    })
    assert tool.engine._get_humanization_config()["base_url"] == "http://custom-llm/v1"


def test_humanization_agent_instructions_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "humanization_agent": {"instructions": "Custom humanizer prompt."}
    })
    assert tool.engine._get_humanization_config()["instructions"] == "Custom humanizer prompt."


def test_humanization_agent_option_char_limit_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "humanization_agent": {"option_char_limit": True}
    })
    assert tool.engine._get_humanization_config()["option_char_limit"] is True


def test_humanization_agent_deep_merge_preserves_yaml_keys():
    """Overriding one humanization_agent key leaves the rest from YAML intact."""
    # YAML: enabled=false
    tool = _make("follow_up_single_step.yaml", {
        "humanization_agent": {"model": "gpt-4o"}  # only add model
    })
    cfg = tool.engine._get_humanization_config()
    assert cfg["enabled"] is False          # preserved from YAML
    assert cfg["model"] == "gpt-4o"        # added at runtime


# ===========================================================================
# LOCALIZATION block (schema: localization.*)
# ===========================================================================

def test_localization_language_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"localization": {"language": "Hindi"}})
    assert tool.engine._get_localization_config()["language"] == "Hindi"


def test_localization_script_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"localization": {"script": "Devanagari"}})
    assert tool.engine._get_localization_config()["script"] == "Devanagari"


def test_localization_instructions_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "localization": {"instructions": "Always respond in Tamil."}
    })
    assert tool.engine._get_localization_config()["instructions"] == "Always respond in Tamil."


def test_localization_full_block_added_where_yaml_has_none():
    """localization block can be added at runtime even if YAML has no localization key."""
    # so_bool_transition.yaml has no localization block
    tool = _make("so_bool_transition.yaml", {
        "localization": {"language": "Tamil", "script": "Tamil"}
    })
    cfg = tool.engine._get_localization_config()
    assert cfg["language"] == "Tamil"
    assert cfg["script"] == "Tamil"


# ===========================================================================
# STEPS — top-level step properties
# ===========================================================================

def test_steps_max_attempts_runtime_override():
    # so_bool_transition.yaml: collect_form has max_attempts=2
    tool = _make("so_bool_transition.yaml", {
        "steps": [{"id": "collect_form", "max_attempts": 7}]
    })
    assert _steps(tool)["collect_form"]["max_attempts"] == 7


def test_steps_on_max_attempts_reached_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "on_max_attempts_reached": "Runtime max msg."}]
    })
    assert _steps(tool)["collect_a"]["on_max_attempts_reached"] == "Runtime max msg."


def test_steps_options_added_runtime():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "options": ["Yes", "No"]}]
    })
    assert _steps(tool)["collect_a"]["options"] == ["Yes", "No"]


def test_steps_is_selectable_added_runtime():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "is_selectable": True}]
    })
    assert _steps(tool)["collect_a"]["is_selectable"] is True


def test_steps_option_char_limit_added_runtime():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "option_char_limit": True}]
    })
    assert _steps(tool)["collect_a"]["option_char_limit"] is True


def test_steps_next_overridden_runtime():
    # follow_up_two_step: collect_a.next = collect_b; override to outcome_success
    tool = _make("follow_up_two_step.yaml", {
        "steps": [{"id": "collect_a", "next": "outcome_success"}]
    })
    assert _steps(tool)["collect_a"]["next"] == "outcome_success"


def test_steps_validator_added_runtime():
    """validator key is merged into the step config at runtime.

    The engine eagerly loads validator functions at graph-build time, so we
    verify the merge result via the ``_deep_merge_config`` helper directly
    rather than instantiating a full WorkflowTool with a non-existent module.
    """
    from soprano_sdk.core.engine import _deep_merge_config

    yaml_steps = [
        {
            "id": "collect_a",
            "action": "collect_input_with_agent",
            "field": "field_a",
            "agent": {"name": "A", "instructions": "Collect."},
        }
    ]
    override_steps = [{"id": "collect_a", "validator": "mymodule.validate_a"}]

    merged = _deep_merge_config({"steps": yaml_steps}, {"steps": override_steps})
    step_map = {s["id"]: s for s in merged["steps"]}

    assert step_map["collect_a"]["validator"] == "mymodule.validate_a"
    assert step_map["collect_a"]["field"] == "field_a"  # YAML key preserved


def test_steps_timeout_added_runtime():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "timeout": 120}]
    })
    assert _steps(tool)["collect_a"]["timeout"] == 120


def test_steps_only_specified_steps_touched():
    """Steps not mentioned in the runtime override are completely preserved from YAML."""
    tool = _make("follow_up_two_step.yaml", {
        "steps": [{"id": "collect_a", "max_attempts": 1}]
    })
    assert _steps(tool)["collect_a"]["max_attempts"] == 1
    assert _steps(tool)["collect_b"]["agent"]["name"] == "CollectorB"  # untouched


# ===========================================================================
# STEPS — agent sub-properties (schema: steps[].agent.*)
# ===========================================================================

def test_steps_agent_name_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"name": "RuntimeAgent"}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["name"] == "RuntimeAgent"


def test_steps_agent_model_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"model": "gpt-4o"}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["model"] == "gpt-4o"


def test_steps_agent_instructions_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"instructions": "Runtime instructions."}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["instructions"] == "Runtime instructions."


def test_steps_agent_description_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"description": "Runtime description."}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["description"] == "Runtime description."


def test_steps_agent_base_url_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"base_url": "http://custom/v1"}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["base_url"] == "http://custom/v1"


def test_steps_agent_api_key_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"api_key": "sk-runtime-key"}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["api_key"] == "sk-runtime-key"


def test_steps_agent_humanize_runtime_override():
    # YAML: humanize=false; override to true
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"humanize": True}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["humanize"] is True


def test_steps_agent_grounding_check_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"grounding_check": True}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["grounding_check"] is True


def test_steps_agent_default_tools_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"default_tools": False}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["default_tools"] is False


def test_steps_agent_bot_response_rules_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"bot_response_rules": "Custom rules."}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["bot_response_rules"] == "Custom rules."


def test_steps_agent_tools_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"tools": ["search_tool"]}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["tools"] == ["search_tool"]


def test_steps_agent_guardrails_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"guardrails": ["thought_action_check"]}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["guardrails"] == ["thought_action_check"]


def test_steps_agent_nested_preserves_sibling_keys():
    """Overriding one agent sub-key leaves all other agent sub-keys from YAML intact."""
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"model": "gpt-4o"}}]
    })
    agent = _steps(tool)["collect_a"]["agent"]
    assert agent["model"] == "gpt-4o"            # overridden
    assert agent["name"] == "CollectorA"          # preserved
    assert "instructions" in agent                # preserved
    assert agent["structured_output"]["enabled"]  # preserved


def test_steps_agent_structured_output_enabled_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"structured_output": {"enabled": False}}}]
    })
    assert _steps(tool)["collect_a"]["agent"]["structured_output"]["enabled"] is False


# ===========================================================================
# OUTCOMES block (schema: outcomes[].*)
# ===========================================================================

def test_outcomes_message_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "message": "Runtime: done."}]
    })
    assert _outcomes(tool)["outcome_success"]["message"] == "Runtime: done."


def test_outcomes_humanize_runtime_override():
    # YAML: humanize=false; add humanize=true at runtime
    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "humanize": True}]
    })
    assert _outcomes(tool)["outcome_success"]["humanize"] is True


def test_outcomes_follow_up_flag_runtime_override():
    # YAML: outcome_success has follow_up=true; disable at runtime
    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "follow_up": False}]
    })
    assert _outcomes(tool)["outcome_success"]["follow_up"] is False
    assert _outcomes(tool)["outcome_failure"]["follow_up"] is True  # untouched


def test_outcomes_type_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "type": "failure"}]
    })
    assert _outcomes(tool)["outcome_success"]["type"] == "failure"


def test_outcomes_redirect_to_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "type": "redirect", "redirect_to": "other_workflow"}]
    })
    o = _outcomes(tool)["outcome_success"]
    assert o["type"] == "redirect"
    assert o["redirect_to"] == "other_workflow"


def test_outcomes_partial_override_leaves_other_outcomes_intact():
    """Overriding one outcome leaves all other outcomes exactly as in YAML."""
    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "message": "Changed."}]
    })
    assert _outcomes(tool)["outcome_success"]["message"] == "Changed."
    assert "Failure" in _outcomes(tool)["outcome_failure"]["message"]
    assert "Done" in _outcomes(tool)["outcome_no_followup"]["message"]


# ===========================================================================
# FOLLOW_UP block (schema: follow_up.*)
# ===========================================================================

def test_follow_up_enabled_runtime_override():
    # YAML: enabled=true; disable at runtime
    tool = _make("follow_up_single_step.yaml", {"follow_up": {"enabled": False}})
    assert tool.engine.follow_up_enabled is False


def test_follow_up_instructions_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"instructions": "Runtime follow-up prompt."}
    })
    assert tool.engine.follow_up_config["instructions"] == "Runtime follow-up prompt."


def test_follow_up_max_attempts_runtime_override():
    tool = _make("follow_up_single_step.yaml", {"follow_up": {"max_attempts": 10}})
    assert tool.engine.follow_up_config["max_attempts"] == 10


def test_follow_up_on_max_attempts_reached_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"on_max_attempts_reached": "Runtime goodbye."}
    })
    assert tool.engine.follow_up_config["on_max_attempts_reached"] == "Runtime goodbye."


def test_follow_up_on_unknown_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"on_unknown": "I don't know that — runtime."}
    })
    assert tool.engine.follow_up_config["on_unknown"] == "I don't know that — runtime."


def test_follow_up_max_history_turns_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"max_history_turns": 5}
    })
    assert tool.engine.follow_up_config["max_history_turns"] == 5


def test_follow_up_model_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"model": "gpt-4o"}
    })
    assert tool.engine.follow_up_config["model"] == "gpt-4o"


def test_follow_up_base_url_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"base_url": "http://follow-up-llm/v1"}
    })
    assert tool.engine.follow_up_config["base_url"] == "http://follow-up-llm/v1"


def test_follow_up_api_key_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"api_key": "sk-fu-runtime"}
    })
    assert tool.engine.follow_up_config["api_key"] == "sk-fu-runtime"


def test_follow_up_tools_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"tools": ["search_tool", "calc_tool"]}
    })
    assert tool.engine.follow_up_config["tools"] == ["search_tool", "calc_tool"]


def test_follow_up_name_runtime_override():
    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"name": "custom_follow_up_name"}
    })
    assert tool.engine.follow_up_config["name"] == "custom_follow_up_name"


def test_follow_up_deep_merge_preserves_yaml_keys():
    """Overriding one follow_up key leaves all YAML follow_up keys intact."""
    # YAML: enabled=true, max_attempts=3, instructions=...
    tool = _make("follow_up_single_step.yaml", {"follow_up": {"max_attempts": 99}})
    assert tool.engine.follow_up_enabled is True            # preserved
    assert tool.engine.follow_up_config["max_attempts"] == 99  # overridden
    assert "helpful" in tool.engine.follow_up_config.get("instructions", "")  # preserved


def test_follow_up_added_where_yaml_has_none():
    """follow_up block can be added entirely at runtime (so_bool_transition has enabled=false)."""
    tool = _make("so_bool_transition.yaml", {
        "follow_up": {"enabled": True, "max_attempts": 2, "instructions": "Help the user."}
    })
    assert tool.engine.follow_up_enabled is True
    assert tool.engine.follow_up_config["max_attempts"] == 2


# ===========================================================================
# GUARDRAILS block (global registry, schema: guardrails[].*)
# ===========================================================================

def test_guardrails_global_registry_added_at_runtime():
    """A guardrail entry can be added to the global registry via runtime config."""
    tool = _make("follow_up_single_step.yaml", {
        "guardrails": [
            {"action": "thought_action_check", "error_message": "Runtime guardrail error."}
        ]
    })
    # The merged config should have the guardrail entry
    guardrails = tool.engine.config.get("guardrails", [])
    assert any(g["action"] == "thought_action_check" for g in guardrails)


# ===========================================================================
# DATA block (schema: data[].*)
# ===========================================================================

def test_data_field_description_runtime_override():
    """A data field's description can be overridden at runtime (by name key)."""
    tool = _make("follow_up_single_step.yaml", {
        "data": [{"name": "field_a", "description": "Runtime field description.", "type": "text"}]
    })
    data_map = {f["name"]: f for f in tool.engine.data_fields}
    assert data_map["field_a"]["description"] == "Runtime field description."


def test_data_field_type_runtime_override():
    """A data field's type can be overridden at runtime."""
    tool = _make("follow_up_single_step.yaml", {
        "data": [{"name": "field_a", "type": "any", "description": "Primary field."}]
    })
    data_map = {f["name"]: f for f in tool.engine.data_fields}
    assert data_map["field_a"]["type"] == "any"


def test_data_field_default_added_at_runtime():
    """A default value can be added to a data field at runtime."""
    tool = _make("follow_up_single_step.yaml", {
        "data": [{"name": "field_a", "type": "text", "description": "Primary field.", "default": "n/a"}]
    })
    data_map = {f["name"]: f for f in tool.engine.data_fields}
    assert data_map["field_a"]["default"] == "n/a"


# ===========================================================================
# MIXED SCENARIOS
# ===========================================================================

def test_mixed_yaml_and_runtime_multiple_sections():
    """Runtime config can simultaneously override multiple distinct schema sections."""
    tool = _make("follow_up_single_step.yaml", {
        "name": "Mixed Runtime Workflow",
        "failure_message": "Mixed failure.",
        "follow_up": {"max_attempts": 7},
        "humanization_agent": {"enabled": True, "model": "gpt-4o"},
        "localization": {"language": "Tamil"},
        "steps": [{"id": "collect_a", "max_attempts": 2, "options": ["A", "B"]}],
        "outcomes": [{"id": "outcome_success", "message": "Mixed outcome."}],
    })

    assert tool.engine.workflow_name == "Mixed Runtime Workflow"
    assert tool.engine.failure_message == "Mixed failure."
    assert tool.engine.follow_up_config["max_attempts"] == 7
    assert tool.engine.follow_up_enabled is True          # YAML default preserved
    assert tool.engine._get_humanization_config()["model"] == "gpt-4o"
    assert tool.engine._get_localization_config()["language"] == "Tamil"
    assert _steps(tool)["collect_a"]["max_attempts"] == 2
    assert _steps(tool)["collect_a"]["options"] == ["A", "B"]
    assert _outcomes(tool)["outcome_success"]["message"] == "Mixed outcome."
    # Sibling outcomes/steps untouched
    assert "Failure" in _outcomes(tool)["outcome_failure"]["message"]
    assert _steps(tool)["collect_a"]["agent"]["name"] == "CollectorA"


# ===========================================================================
# END-TO-END: follow_up enabled/disabled (graph behaviour verification)
# ===========================================================================

@respx.mock
def test_follow_up_disabled_at_runtime_ends_graph():
    """follow_up.enabled=True in YAML, overridden to False: graph ends at outcome."""
    responses = iter([collector_prompt(), collector_capture("val")])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = _make("follow_up_single_step.yaml", {"follow_up": {"enabled": False}})
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result = tool.execute(thread_id=tid, user_message="val", initial_context={})

    assert InterruptType.FOLLOW_UP not in str(result)
    assert snap(tool, tid)["_outcome_id"] == "outcome_success"


@respx.mock
def test_follow_up_enabled_at_runtime_activates_node():
    """follow_up.enabled=False in YAML, overridden to True: graph raises FOLLOW_UP interrupt."""
    responses = iter([
        llm_structured_response({"bot_response": "Submit?", "captured": None, "extra": None}),
        llm_structured_response({"bot_response": None, "captured": True, "extra": ""}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = _make("so_bool_transition.yaml", {
        "follow_up": {"enabled": True, "instructions": "Help the user.", "max_attempts": 1}
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result = tool.execute(thread_id=tid, user_message="yes", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result)


@respx.mock
def test_outcome_follow_up_flag_disabled_at_runtime():
    """outcome.follow_up=True in YAML, specific outcome disabled at runtime."""
    responses = iter([collector_prompt(), collector_capture("val")])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "outcomes": [{"id": "outcome_success", "follow_up": False}]
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result = tool.execute(thread_id=tid, user_message="val", initial_context={})

    # outcome_success follow_up=False → no FOLLOW_UP interrupt
    assert InterruptType.FOLLOW_UP not in str(result)
    assert snap(tool, tid)["_outcome_id"] == "outcome_success"
