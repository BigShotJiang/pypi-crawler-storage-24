"""Tests for structured output correctness in the follow-up node. Covers Pydantic
model field types (nullable options subtext, optional restart), RESPONSE FORMAT instruction
accuracy, and that raw JSON from collector nodes is not leaked into the follow-up LLM's context.
"""

import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    llm_structured_response,
    make_tool,
)


def fu_answer_with_null_subtext(text: str, option_texts: list):
    """Follow-up LLM returns a normal Q&A answer WITH options that have null subtext values.

    This tests that Dict[str, str] in the options type does not reject subtext=None.
    """
    return llm_structured_response({
        "bot_response": text,
        "options": [{"text": t, "subtext": None} for t in option_texts],
        "is_selectable": True,
        "intent_change": None,
        "out_of_scope": None,
        "restart": False,
    })


def fu_null_restart(text: str):
    """Follow-up LLM returns a normal Q&A answer where restart is null rather than false.

    This tests that Optional[bool] is used for restart so that null is accepted by Pydantic.
    """
    return llm_structured_response({
        "bot_response": text,
        "options": None,
        "is_selectable": None,
        "intent_change": None,
        "out_of_scope": None,
        "restart": None,   # null — should be accepted as Optional[bool]
    })


@respx.mock
def test_options_with_null_subtext_parsed_without_validation_error():
    """When the follow-up LLM returns options with null subtext values, the response should
    be parsed successfully without a ValidationError. The clean bot_response text should
    appear in the FOLLOW_UP interrupt rather than a Python repr of the full response dict.
    The options with null subtext should be present in the result payload.
    """
    BOT_TEXT = "Would you prefer A or B?"
    OPTION_TEXTS = ["Option A", "Option B"]

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer_with_null_subtext(BOT_TEXT, OPTION_TEXTS),  # LLM#3 — options with null subtext
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="choose one", initial_context={})

    # Must be a FOLLOW_UP interrupt (node self-looped)
    assert InterruptType.FOLLOW_UP in str(result3), (
        f"Expected FOLLOW_UP interrupt, got: '{str(result3)[:200]}'"
    )

    # Extract the prompt text embedded in the result string.
    # Format: __FOLLOW_UP__|tid|name|<prompt_text>
    parts = str(result3).split("|", 3)
    assert len(parts) >= 4, f"Result missing '|' separators: '{str(result3)}'"
    prompt_text = parts[3]

    # The clean bot_response text must appear in the prompt — NOT the Python repr.
    assert BOT_TEXT in prompt_text, (
        f"The clean bot_response '{BOT_TEXT}' is absent from "
        f"the FOLLOW_UP interrupt text. "
        f"FollowUpOutput.options was typed as List[Dict[str, str]]; "
        f"when subtext=null Pydantic V2 raises ValidationError. "
        f"The except block then creates "
        f"FollowUpOutput(bot_response=str(raw_response)), replacing the "
        f"clean text with the Python repr of the full response dict. "
        f"Actual prompt text (first 300 chars): '{prompt_text[:300]}'. "
        f"Fix: change Dict[str, str] to Dict[str, Optional[str]] in the "
        f"options type annotation."
    )

    # The Python repr artifact must NOT pollute the prompt text.
    assert "{'bot_response'" not in prompt_text and '{"bot_response"' not in prompt_text, (
        f"Python repr artifact detected in FOLLOW_UP interrupt text. "
        f"The prompt contains raw dict repr instead of the LLM's intended message. "
        f"Prompt text (first 300 chars): '{prompt_text[:300]}'"
    )


@respx.mock
def test_null_restart_field_parsed_without_validation_error():
    """When the follow-up LLM returns restart=null (null instead of false), the response
    should be parsed successfully without a ValidationError. The clean bot_response text
    should appear in the FOLLOW_UP interrupt rather than a Python repr of the full dict.
    This requires restart to be typed as Optional[bool] rather than a strict bool.
    """
    BOT_TEXT = "Here is your answer."

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_null_restart(BOT_TEXT),  # LLM#3 — restart=null triggers ValidationError if bool
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="q1", initial_context={})

    # Must be a FOLLOW_UP interrupt (normal self-loop path)
    assert InterruptType.FOLLOW_UP in str(result3), (
        f"Expected FOLLOW_UP interrupt, got: '{str(result3)[:200]}'"
    )

    # Extract the prompt text embedded in the result string.
    # Format: __FOLLOW_UP__|tid|name|<prompt_text>
    parts = str(result3).split("|", 3)
    assert len(parts) >= 4, f"Result missing '|' separators: '{str(result3)}'"
    prompt_text = parts[3]

    # The clean bot_response text must appear as the prompt.
    assert BOT_TEXT in prompt_text, (
        f"The clean bot_response '{BOT_TEXT}' is absent from "
        f"the FOLLOW_UP interrupt text. "
        f"FollowUpOutput.restart was typed as `bool = False`; Pydantic V2 "
        f"raises ValidationError when the LLM returns restart=null. "
        f"The except block creates FollowUpOutput(bot_response=str(raw_response)), "
        f"replacing the clean text with the Python repr of the raw response dict. "
        f"Actual prompt text (first 300 chars): '{prompt_text[:300]}'. "
        f"Fix: change `restart: bool = False` to `restart: Optional[bool] = False` "
        f"and coerce None → False when processing."
    )

    # The Python repr must not pollute the prompt text.
    assert "{'bot_response'" not in prompt_text and '{"bot_response"' not in prompt_text, (
        f"Python repr artifact detected in FOLLOW_UP interrupt text. "
        f"Prompt text (first 300 chars): '{prompt_text[:300]}'"
    )


@respx.mock
def test_response_format_instruction_describes_bot_response_as_optional():
    """The RESPONSE FORMAT section of the follow-up LLM system prompt should not describe
    bot_response as '(str, required)' since the field is Optional. Telling the LLM that
    bot_response is required causes it to always include a conversational message even
    alongside dispatch signals where an absent bot_response would be more appropriate.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Please tell me field A."),  # LLM#1 — collector prompt
        collector_capture("valid_val"),               # LLM#2 — collector captures → FOLLOW_UP
        fu_answer("Here is your answer."),            # LLM#3 — first follow-up Q&A
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})

    # Verify LLM#3 was called
    assert len(captured_requests) >= 3, (
        f"Expected at least 3 LLM requests but captured {len(captured_requests)}"
    )

    # Parse the follow-up LLM request (LLM#3, index 2)
    follow_up_req_body = json.loads(captured_requests[2].content)
    messages = follow_up_req_body.get("messages", [])

    # Find the system message
    system_messages = [m for m in messages if m.get("role") == "system"]
    assert system_messages, "No system message found in follow-up LLM#3 request"
    system_content = system_messages[0].get("content", "")

    # Isolate the RESPONSE FORMAT section (support both header variants)
    response_format_start = next(
        (system_content.find(h) for h in ("RESPONSE FORMAT", "Final Answer format") if h in system_content),
        -1,
    )
    if response_format_start == -1:
        response_format_section = system_content
    else:
        response_format_section = system_content[response_format_start:]

    # The RESPONSE FORMAT must NOT declare bot_response as "(str, required)".
    # After the Q1 fix, bot_response is Optional[str] = None — the LLM should
    # know it can omit the field when a dispatch signal is present.
    assert "(str, required)" not in response_format_section, (
        f"RESPONSE FORMAT section in the follow-up LLM system "
        f"prompt declares bot_response as '(str, required)'. "
        f"After the Q1 fix, FollowUpOutput.bot_response is "
        f"Optional[str] = None — the field is nullable and optional alongside "
        f"dispatch signals. "
        f"_build_instructions still says '(str, required)' which "
        f"contradicts the actual Pydantic schema and misleads the LLM into "
        f"always providing a conversational message even when a dispatch signal "
        f"(intent_change, out_of_scope, restart) is the intended response. "
        f"Fix: update to say '(str or null, optional)' or similar. "
        f"RESPONSE FORMAT section (first 400 chars): "
        f"'{response_format_section[:400]}'"
    )


@respx.mock
def test_response_format_instruction_describes_restart_as_optional_bool():
    """The RESPONSE FORMAT section should describe the restart field as optional or
    nullable, not as a strict required bool. After making restart Optional[bool], the
    LLM should be informed that null is a valid value so it does not always return
    a strict true/false.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Please tell me field A."),  # LLM#1 — collector
        collector_capture("valid_val"),               # LLM#2 — capture → FOLLOW_UP
        fu_answer("Here is your answer."),            # LLM#3 — first follow-up Q&A
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})

    assert len(captured_requests) >= 3, (
        f"Expected at least 3 LLM requests, got {len(captured_requests)}"
    )

    # LLM#3 system prompt (index 2)
    follow_up_req_body = json.loads(captured_requests[2].content)
    messages = follow_up_req_body.get("messages", [])
    system_messages = [m for m in messages if m.get("role") == "system"]
    assert system_messages, "No system message in LLM#3 request"
    system_content = system_messages[0].get("content", "")

    # Isolate the RESPONSE FORMAT section
    response_format_start = system_content.find("RESPONSE FORMAT")
    response_format_section = (
        system_content[response_format_start:]
        if response_format_start != -1
        else system_content
    )

    # After the S2 fix, restart is Optional[bool] = False.
    # The RESPONSE FORMAT must NOT describe restart as a strict required "(bool)".
    import re
    restart_line_match = re.search(r'restart\s*\(([^)]*)\)', response_format_section)
    assert restart_line_match, (
        f"Could not find 'restart (...)' in RESPONSE FORMAT section: "
        f"{response_format_section[:400]!r}"
    )
    restart_type_desc = restart_line_match.group(1).lower()

    # The type description must indicate optionality (null / optional / or null)
    is_optional = any(
        kw in restart_type_desc
        for kw in ("null", "optional", "or null", "optional[bool]")
    )
    assert is_optional, (
        f"RESPONSE FORMAT restart field is described as "
        f"'({restart_line_match.group(1)})' which does not indicate it is "
        f"nullable/optional. "
        f"After the S2 fix, FollowUpOutput.restart is Optional[bool] = False. "
        f"_build_instructions still says '(bool)' — the LLM is misled "
        f"into always providing a strict boolean (true/false), when null is now "
        f"an accepted value. "
        f"Fix: update to '(bool or null, optional)' or similar. "
        f"Full RESPONSE FORMAT section (first 500 chars): "
        f"{response_format_section[:500]!r}"
    )


@respx.mock
def test_response_format_instruction_marks_options_subtext_as_nullable():
    """The RESPONSE FORMAT section should not describe the options field as
    'list[{text, subtext}]' without indicating that subtext can be null. After making
    options subtext Optional[str], the LLM must be informed that null is valid, otherwise
    it will never produce null subtext even though the runtime now accepts it.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Please tell me field A."),  # LLM#1 — collector prompt
        collector_capture("valid_val"),               # LLM#2 — collector captures → FOLLOW_UP
        fu_answer("Here is your answer."),            # LLM#3 — first follow-up Q&A
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})

    # Verify LLM#3 (the follow-up agent) was called
    assert len(captured_requests) >= 3, (
        f"Expected at least 3 LLM requests but captured {len(captured_requests)}"
    )

    # Parse the follow-up LLM request (LLM#3, index 2)
    follow_up_req_body = json.loads(captured_requests[2].content)
    messages = follow_up_req_body.get("messages", [])

    # Find the system message
    system_messages = [m for m in messages if m.get("role") == "system"]
    assert system_messages, "No system message found in follow-up LLM#3 request"
    system_content = system_messages[0].get("content", "")

    # Isolate the RESPONSE FORMAT section (support both header variants)
    response_format_start = next(
        (system_content.find(h) for h in ("RESPONSE FORMAT", "Final Answer format") if h in system_content),
        -1,
    )
    if response_format_start == -1:
        response_format_section = system_content
    else:
        response_format_section = system_content[response_format_start:]

    # The RESPONSE FORMAT must NOT describe options as `list[{text, subtext}]`
    # without a null annotation for subtext.
    assert "list[{text, subtext}]" not in response_format_section, (
        f"RESPONSE FORMAT section in the follow-up LLM system "
        f"prompt describes options as 'list[{{text, subtext}}]' without indicating "
        f"that subtext can be null. "
        f"The S1 fix changed FollowUpOutput.options to "
        f"Optional[List[Dict[str, Optional[str]]]], accepting subtext=None from "
        f"the LLM. However, _build_instructions still says "
        f"'list[{{text, subtext}}]', implying both fields are required non-null "
        f"strings. This contradicts the actual Pydantic schema and defeats the S1 "
        f"fix: the LLM will never produce subtext=null even though the runtime now "
        f"accepts it, because the prompt tells it not to. "
        f"Same class of prompt-schema mismatch as S3 (bot_response) and U2 (restart). "
        f"Fix: update the options line to indicate subtext is nullable, e.g.: "
        f"'list[{{text: str, subtext: str | null}}] or null'. "
        f"RESPONSE FORMAT section (first 400 chars): "
        f"'{response_format_section[:400]}'"
    )


@respx.mock
def test_build_instructions_strips_raw_json_from_collector_conversation_history():
    """The follow-up LLM system prompt WORKFLOW CONTEXT and CONVERSATION HISTORY sections
    should not contain raw JSON from the collector's structured output. When the collector
    stores its LLM responses as raw JSON strings in the conversation, those strings should
    be cleaned up before being passed to the follow-up LLM's context.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Please tell me field A."), # LLM#1 — collector prompt
        collector_capture("valid_val"),              # LLM#2 — collector captures → FOLLOW_UP
        fu_answer("Here is your answer."),           # LLM#3 — follow-up self-loop
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                                 # T1 → LLM#1
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})       # T2 → LLM#2
    tool.execute(thread_id=tid, user_message="q1", initial_context={})              # T3 → LLM#3

    # Verify we captured the 3rd HTTP request (the follow-up LLM call)
    assert len(captured_requests) >= 3, (
        f"Expected at least 3 LLM requests but captured {len(captured_requests)}"
    )

    # Parse the request body for LLM#3 (index 2) — the follow-up agent call
    follow_up_req_body = json.loads(captured_requests[2].content)
    messages = follow_up_req_body.get("messages", [])

    # Find the system message
    system_messages = [m for m in messages if m.get("role") == "system"]
    assert system_messages, "No system message found in follow-up LLM request"
    system_content = system_messages[0].get("content", "")

    # Extract only the WORKFLOW CONTEXT and CONVERSATION HISTORY sections.
    # The RESPONSE FORMAT section legitimately contains 'bot_response' (it describes
    # the follow-up LLM's own output schema) — we must not flag those occurrences.
    # Also exclude the CONSTRAINTS section which references 'bot_response' in grounding rules.
    context_start = system_content.find("WORKFLOW CONTEXT:")
    # Support both "RESPONSE FORMAT" and "Final Answer format" headers.
    response_format_start = next(
        (system_content.find(h) for h in ("RESPONSE FORMAT", "Final Answer format") if h in system_content),
        -1,
    )
    if context_start == -1 or response_format_start == -1:
        # Fall back to checking everything if headers aren't found
        data_sections = system_content
    else:
        data_sections = system_content[context_start:response_format_start]

    assert 'bot_response' not in data_sections, (
        f"Follow-up LLM system prompt WORKFLOW CONTEXT or "
        f"CONVERSATION HISTORY contains the raw 'bot_response' field name from "
        f"the structured-output collector schema. "
        f"_build_instructions renders msg['content'] verbatim, and "
        f"collect_input.py stores str(agent_response) as message content "
        f"in structured output mode. "
        f"The CONVERSATION HISTORY should contain clean natural-language text like "
        f"'Please tell me field A.' not raw structured-output repr/JSON. "
        f"Affected sections (first 500 chars): {data_sections[:500]!r}"
    )
