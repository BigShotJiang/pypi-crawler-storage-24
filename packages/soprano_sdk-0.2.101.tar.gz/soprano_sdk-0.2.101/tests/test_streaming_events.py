"""Tests for soprano_sdk.streaming.events -- the public contract."""

from soprano_sdk.streaming.events import (
    AsyncInterruptEvent,
    CompleteEvent,
    CustomEvent,
    ErrorEvent,
    InterruptEvent,
    NodeCompleteEvent,
    OutOfScopeEvent,
    RedirectEvent,
)


class TestNodeCompleteEvent:
    def test_construction(self):
        event = NodeCompleteEvent(node="collect_name", state_update={"user_name": "Alice"})
        assert event.node == "collect_name"
        assert event.state_update == {"user_name": "Alice"}

    def test_state_update_can_be_empty(self):
        event = NodeCompleteEvent(node="noop", state_update={})
        assert event.state_update == {}


class TestCustomEvent:
    def test_construction(self):
        payload = {"type": "llm_token", "chunk": "Hello"}
        event = CustomEvent(payload=payload)
        assert event.payload == payload

    def test_payload_is_arbitrary_dict(self):
        event = CustomEvent(payload={"any": "thing", "nested": {"ok": True}})
        assert event.payload["nested"]["ok"] is True


class TestInterruptEvent:
    def test_construction_minimal(self):
        event = InterruptEvent(prompt="What is your name?")
        assert event.prompt == "What is your name?"
        assert event.options == []
        assert event.is_selectable is False
        assert event.field_details == []

    def test_construction_full(self):
        event = InterruptEvent(
            prompt="Pick a color",
            options=[{"text": "Red", "subtext": ""}],
            is_selectable=True,
            field_details=[{"name": "color", "value": None}],
        )
        assert event.prompt == "Pick a color"
        assert len(event.options) == 1
        assert event.is_selectable is True
        assert event.field_details[0]["name"] == "color"

    def test_defaults_are_independent_instances(self):
        a = InterruptEvent(prompt="a")
        b = InterruptEvent(prompt="b")
        a.options.append({"text": "X"})
        assert b.options == []


class TestAsyncInterruptEvent:
    def test_construction(self):
        event = AsyncInterruptEvent(
            thread_id="t1",
            workflow_name="returns",
            pending={"callback_url": "https://example.com"},
            step_id="verify_payment",
        )
        assert event.thread_id == "t1"
        assert event.workflow_name == "returns"
        assert event.pending == {"callback_url": "https://example.com"}
        assert event.step_id == "verify_payment"

    def test_defaults(self):
        event = AsyncInterruptEvent(thread_id="t1", workflow_name="w")
        assert event.pending == {}
        assert event.step_id == ""


class TestOutOfScopeEvent:
    def test_construction(self):
        event = OutOfScopeEvent(
            thread_id="t1",
            workflow_name="returns",
            reason="Not about returns",
            user_message="What's the weather?",
        )
        assert event.thread_id == "t1"
        assert event.reason == "Not about returns"
        assert event.user_message == "What's the weather?"

    def test_defaults(self):
        event = OutOfScopeEvent(thread_id="t1", workflow_name="w")
        assert event.reason == "User query is out of scope"
        assert event.user_message == ""


class TestCompleteEvent:
    def test_construction_minimal(self):
        event = CompleteEvent(message="Done!")
        assert event.message == "Done!"
        assert event.options == []
        assert event.is_selectable is False

    def test_construction_with_options(self):
        event = CompleteEvent(
            message="Choose next",
            options=[{"text": "A"}],
            is_selectable=True,
        )
        assert event.is_selectable is True
        assert len(event.options) == 1

    def test_defaults_are_independent_instances(self):
        a = CompleteEvent(message="a")
        b = CompleteEvent(message="b")
        a.options.append({"text": "X"})
        assert b.options == []


class TestRedirectEvent:
    def test_construction(self):
        event = RedirectEvent(
            message="Redirecting you",
            redirect_to="other_workflow",
            thread_id="t1",
            workflow_name="returns",
        )
        assert event.message == "Redirecting you"
        assert event.redirect_to == "other_workflow"
        assert event.thread_id == "t1"
        assert event.workflow_name == "returns"
        assert event.options == []
        assert event.is_selectable is False

    def test_construction_with_options(self):
        event = RedirectEvent(
            message="Choose",
            redirect_to="other",
            thread_id="t1",
            workflow_name="w",
            options=[{"text": "A"}],
            is_selectable=True,
        )
        assert event.options == [{"text": "A"}]
        assert event.is_selectable is True


class TestErrorEvent:
    def test_construction(self):
        event = ErrorEvent(error="something broke")
        assert event.error == "something broke"


class TestWorkflowEventUnion:
    def test_all_types_match_in_structural_pattern(self):
        events = [
            NodeCompleteEvent(node="n", state_update={}),
            CustomEvent(payload={}),
            InterruptEvent(prompt="q"),
            AsyncInterruptEvent(thread_id="t", workflow_name="w"),
            OutOfScopeEvent(thread_id="t", workflow_name="w"),
            CompleteEvent(message="done"),
            RedirectEvent(message="hi", redirect_to="other", thread_id="t", workflow_name="w"),
            ErrorEvent(error="err"),
        ]
        labels = []
        for event in events:
            match event:
                case NodeCompleteEvent():
                    labels.append("node")
                case CustomEvent():
                    labels.append("custom")
                case InterruptEvent():
                    labels.append("interrupt")
                case AsyncInterruptEvent():
                    labels.append("async")
                case OutOfScopeEvent():
                    labels.append("oos")
                case CompleteEvent():
                    labels.append("complete")
                case RedirectEvent():
                    labels.append("redirect")
                case ErrorEvent():
                    labels.append("error")
        assert labels == ["node", "custom", "interrupt", "async", "oos", "complete", "redirect", "error"]
