"""Tests for follow-up humanization: outcome message humanization and model config overrides.

Covers:
- Outcome message is humanized when humanize: true; Q&A answers are never re-humanized
- follow_up.base_url / api_key route agent calls to the custom endpoint
"""

import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    llm_structured_response,
    make_tool,
)

FAKE_LLM_2_URL = "http://fake-llm-2/v1"
FAKE_LLM_2_COMPLETIONS = f"{FAKE_LLM_2_URL}/chat/completions"


def _humanizer(text: str):
    """LLM response: humanizer returns a structured humanized message."""
    return llm_structured_response({"message": text, "options": None, "is_selectable": None})


@respx.mock
def test_qa_answer_not_humanized_even_when_outcome_humanize_true():
    """Q&A answers from the follow-up LLM are never humanized, regardless of the outcome's
    humanize setting. The outcome message itself is humanized (LLM#3), but subsequent Q&A
    turns return the raw follow-up LLM response directly (no extra humanizer call).
    """
    responses = iter([
        collector_prompt(),                           # LLM#1: collector prompts user
        collector_capture("hello"),                   # LLM#2: collector captures value
        _humanizer("Humanized outcome message."),     # LLM#3: humanizer for outcome message
        fu_answer("Raw Q&A answer."),                 # LLM#4: follow-up Q&A agent (no humanizer follows)
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_humanized.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="hello", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="q1", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result3)
    assert "Raw Q&A answer." in str(result3)
    assert respx.calls.call_count == 4  # no humanizer call for Q&A


@respx.mock
def test_qa_answer_not_humanized_when_outcome_humanize_false():
    """When humanization_agent.enabled is false (or the outcome has humanize: false), the
    Q&A answer should be returned as-is with no additional humanizer LLM call. Call count
    must remain at 3: collector prompt + capture + follow-up Q&A only.
    """
    responses = iter([
        collector_prompt(),                # LLM#1: collector prompts user
        collector_capture("valid_val"),    # LLM#2: collector captures
        fu_answer("Here is your answer."), # LLM#3: follow-up Q&A — no humanizer follows
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="what is this?", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result3)
    assert "Here is your answer." in str(result3)
    assert respx.calls.call_count == 3  # no humanizer call


@respx.mock
def test_outcome_humanizer_receives_collector_conversation_context():
    """The humanizer for the outcome message receives collector conversation history so
    it can personalise the humanized text. The user's collected value ('hello') should
    appear in the humanizer's messages. Only 3 LLM calls occur: collector prompt,
    collector capture, and outcome humanizer — no Q&A humanizer call.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),                        # LLM#1: collector prompt
        collector_capture("hello"),                # LLM#2: capture
        _humanizer("Humanized outcome message."),  # LLM#3: humanize outcome message
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_humanized.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="hello", initial_context={})

    assert len(captured_requests) == 3

    # LLM#3 is the outcome humanizer (index 2)
    humanizer_body = json.loads(captured_requests[2].content)
    messages = humanizer_body.get("messages", [])
    all_content = " ".join(str(m.get("content", "")) for m in messages)

    assert "hello" in all_content, (
        f"Outcome humanizer should receive collector conversation context, "
        f"but 'hello' was not found in humanizer messages: {messages}"
    )


@respx.mock
def test_follow_up_base_url_routes_agent_to_custom_endpoint():
    """When follow_up.base_url is configured, the follow-up agent's LLM calls must be
    sent to the custom URL. Collector agent calls must still use the default model_config
    base URL. The two endpoints are verified by inspecting which route handled each call.
    """
    collector_responses = iter([
        collector_prompt(),         # collector: prompt user
        collector_capture("hello"), # collector: capture value
    ])
    follow_up_responses = iter([
        fu_answer("Answer from custom endpoint."),
    ])

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(collector_responses))
    respx.post(FAKE_LLM_2_COMPLETIONS).mock(side_effect=lambda req: next(follow_up_responses))

    tool = make_tool("follow_up_model_override.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="hello", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="question", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result3)
    assert "Answer from custom endpoint." in str(result3)

    default_calls = [c for c in respx.calls if FAKE_LLM_2_URL not in str(c.request.url)]
    custom_calls = [c for c in respx.calls if FAKE_LLM_2_URL in str(c.request.url)]

    assert len(default_calls) == 2, (
        f"Expected 2 collector calls on the default URL, got {len(default_calls)}"
    )
    assert len(custom_calls) == 1, (
        f"Expected 1 follow-up call on the custom URL ({FAKE_LLM_2_URL}), got {len(custom_calls)}"
    )
