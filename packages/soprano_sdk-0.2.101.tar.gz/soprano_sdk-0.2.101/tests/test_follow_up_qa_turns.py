"""Tests for the follow-up Q&A self-loop — normal question-and-answer turns where the LLM
answers and the graph loops back to wait for the next user message. Covers single and multiple
turns, options in answers, and that options in conversation entries do not break subsequent turns.
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    llm_structured_response,
    make_tool,
    snap,
)


def fu_answer_with_options(text: str, options: list, is_selectable: bool):
    """Follow-up LLM returns a normal answer that includes selectable options."""
    return llm_structured_response({
        "bot_response": text,
        "options": options,
        "is_selectable": is_selectable,
        "intent_change": None,
        "out_of_scope": None,
        "restart": False,
    })


@respx.mock
def test_single_qa_turn_returns_answer_via_follow_up_interrupt():
    """A single follow-up Q&A turn should call the follow-up LLM and return the answer
    in a FOLLOW_UP interrupt. The attempt counter should be incremented to 1 after the
    first successful Q&A exchange.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("Here is your answer."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="what is this?", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result3)
    assert "Here is your answer." in str(result3)
    assert s["_follow_up_attempts"] == 1


@respx.mock
def test_multiple_qa_turns_increment_attempt_counter():
    """Multiple consecutive Q&A turns should each increment the attempt counter and
    return a FOLLOW_UP interrupt with the LLM's answer. After three turns the attempt
    counter should be 3, reflecting the number of completed Q&A exchanges.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("Answer 1."),
        fu_answer("Answer 2."),
        fu_answer("Answer 3."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="question 1", initial_context={})
    tool.execute(thread_id=tid, user_message="question 2", initial_context={})
    result5 = tool.execute(thread_id=tid, user_message="question 3", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result5)
    assert s["_follow_up_attempts"] == 3


@respx.mock
def test_qa_answer_with_options_forwarded_to_follow_up_interrupt():
    """When the follow-up LLM returns an answer with selectable options, the options
    and is_selectable flag should be propagated to the FOLLOW_UP interrupt result.
    The attempt counter should still increment normally for option-bearing answers.
    """
    options = [{"text": "Option A", "subtext": ""}, {"text": "Option B", "subtext": ""}]
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("Would you like A or B?", options=options, is_selectable=True),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="what are my choices?", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result3)
    assert "Would you like A or B?" in str(result3)
    assert result3.options == options
    assert result3.is_selectable is True
    assert s["_follow_up_attempts"] == 1
    assert respx.calls.call_count == 3


@respx.mock
def test_subsequent_qa_turn_succeeds_when_prior_answer_had_options():
    """When a prior follow-up answer included options and is_selectable, those extra keys
    may be stored in the conversation history. The next Q&A turn should still succeed even
    if the conversation entry contains non-standard keys, ensuring the follow-up loop is
    not broken by options metadata in previous turns.
    """
    OPTIONS = [{"text": "Option A", "subtext": ""}, {"text": "Option B", "subtext": ""}]

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer_with_options("Choose A or B?", OPTIONS, is_selectable=True),  # LLM#3: has options
        fu_answer("Here is the full answer for your second question."),           # LLM#4: after options message
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})

    # T3: first follow-up Q&A — LLM returns options
    result3 = tool.execute(thread_id=tid, user_message="what are my options?", initial_context={})
    assert InterruptType.FOLLOW_UP in str(result3), "T3 should deliver FOLLOW_UP with options"

    # T4: second follow-up Q&A — conversation now contains the options-carrying entry
    result4 = tool.execute(thread_id=tid, user_message="tell me more", initial_context={})

    # Guard: second turn should succeed cleanly
    assert InterruptType.FOLLOW_UP in str(result4), (
        f"Second Q&A turn failed after first turn had options in conversation. "
        f"The extra 'options'/'is_selectable' keys in the assistant message dict may have caused "
        f"an LLM client error. Result: '{str(result4)}'"
    )
    assert "Here is the full answer for your second question." in str(result4), (
        f"Expected second LLM answer in result4, got: '{str(result4)}'"
    )
    assert respx.calls.call_count == 4  # all 4 LLM calls consumed
