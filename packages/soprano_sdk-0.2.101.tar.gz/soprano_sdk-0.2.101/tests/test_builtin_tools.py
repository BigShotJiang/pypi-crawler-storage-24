"""Tests for built-in tools (Pydantic Monty compute tool)."""
from datetime import date, timedelta
from unittest.mock import patch

from dateutil.relativedelta import relativedelta

from soprano_sdk.utils.builtin_tools import (
    _compute,
    _filter_state_for_monty,
    _build_type_stubs,
    get_default_tools,
    make_compute_tool,
    MONTY_TOOL_NAME,
    _today,
    _days_between,
    _add_days,
    _months_ago,
    _add_months,
    _quarter_start,
    _quarter_end,
    _date_parts,
)


# --- _filter_state_for_monty ---

class TestFilterStateForMonty:
    def test_excludes_internal_keys(self):
        state = {
            "_status": "collecting",
            "_conversations": {},
            "_attempt_counts": {"step1": 2},
            "order_id": "12345",
            "amount": 99.50,
        }
        result = _filter_state_for_monty(state)
        assert "_status" not in result
        assert "_conversations" not in result
        assert "_attempt_counts" not in result
        assert result == {"order_id": "12345", "amount": 99.50}

    def test_excludes_non_serializable_values(self):
        state = {
            "name": "Alice",
            "callback": lambda: None,
            "count": 5,
        }
        result = _filter_state_for_monty(state)
        assert "callback" not in result
        assert result == {"name": "Alice", "count": 5}

    def test_empty_state(self):
        assert _filter_state_for_monty({}) == {}

    def test_all_internal_keys(self):
        state = {"_a": 1, "_b": 2}
        assert _filter_state_for_monty(state) == {}

    def test_preserves_nested_serializable_data(self):
        state = {
            "loans": [
                {"name": "A", "rate": 5.5},
                {"name": "B", "rate": 3.2},
            ]
        }
        result = _filter_state_for_monty(state)
        assert result == state

    def test_preserves_none_values(self):
        state = {"field": None, "other": "value"}
        result = _filter_state_for_monty(state)
        assert result == {"field": None, "other": "value"}


# --- _build_type_stubs ---

class TestBuildTypeStubs:
    def test_basic_types(self):
        inputs = {"name": "Alice", "age": 30, "score": 9.5, "active": True}
        stubs = _build_type_stubs(inputs)
        assert "name: str" in stubs
        assert "age: int" in stubs
        assert "score: float" in stubs
        assert "active: bool" in stubs

    def test_collection_types(self):
        inputs = {"items": [1, 2, 3], "data": {"key": "val"}}
        stubs = _build_type_stubs(inputs)
        assert "items: list" in stubs
        assert "data: dict" in stubs

    def test_empty_inputs(self):
        assert _build_type_stubs({}) == ""


# --- _compute ---

class TestCompute:
    def test_basic_arithmetic(self):
        assert _compute("2 + 3") == "5"

    def test_multiplication(self):
        assert _compute("7 * 8") == "56"

    def test_with_state_inputs(self):
        result = _compute("price * quantity", price=10, quantity=3)
        assert result == "30"

    def test_ignores_internal_state_keys(self):
        result = _compute(
            "amount * 2",
            amount=50,
            _status="collecting",
            _conversations={},
        )
        assert result == "100"

    def test_min_max(self):
        assert _compute("min([5, 3, 8, 1])") == "1"
        assert _compute("max([5, 3, 8, 1])") == "8"

    def test_list_comprehension(self):
        result = _compute(
            "[x for x in items if x > 5]",
            items=[1, 8, 3, 10, 2, 7],
        )
        assert result == "[8, 10, 7]"

    def test_sorted(self):
        result = _compute("sorted([3, 1, 2])")
        assert result == "[1, 2, 3]"

    def test_sum(self):
        result = _compute("sum(values)", values=[10, 20, 30])
        assert result == "60"

    def test_f_string(self):
        result = _compute('f"Total: {price * qty}"', price=25, qty=4)
        assert result == "Total: 100"

    def test_string_operations(self):
        result = _compute('"hello world".upper()')
        assert result == "HELLO WORLD"

    def test_dict_access(self):
        result = _compute(
            'data["name"]',
            data={"name": "Alice", "age": 30},
        )
        assert result == "Alice"

    def test_nested_data_max(self):
        code = """
records = [{'name': 'A', 'val': 10}, {'name': 'B', 'val': 5}, {'name': 'C', 'val': 20}]
vals = [r['val'] for r in records]
max_val = max(vals)
[r for r in records if r['val'] == max_val][0]
"""
        result = _compute(code)
        assert "'name': 'C'" in result
        assert "'val': 20" in result

    def test_boolean_logic(self):
        result = _compute(
            'amount > 100 and status == "active"',
            amount=150,
            status="active",
        )
        assert result == "True"

    def test_error_returns_message(self):
        result = _compute("undefined_variable + 1")
        assert result.startswith("Computation error:")

    def test_syntax_error_returns_message(self):
        result = _compute("def :")
        assert "error" in result.lower() or "Error" in result

    @patch.dict("sys.modules", {"pydantic_monty": None})
    def test_import_error_returns_message(self):
        # Simulate pydantic_monty not being installed
        with patch("builtins.__import__", side_effect=ImportError("no module")):
            result = _compute("2 + 2")
        assert "not installed" in result or "Error" in result

    def test_multiline_code(self):
        code = """
x = 10
y = 20
x + y
"""
        assert _compute(code) == "30"

    def test_conditional_expression(self):
        result = _compute(
            '"eligible" if score >= 80 else "not eligible"',
            score=85,
        )
        assert result == "eligible"


# --- get_default_tools ---

class TestGetDefaultTools:
    def test_returns_list_of_tuples(self):
        tools = get_default_tools()
        assert isinstance(tools, list)
        assert len(tools) >= 1

    def test_tuple_format(self):
        tools = get_default_tools()
        name, desc, func = tools[0]
        assert name == MONTY_TOOL_NAME
        assert isinstance(desc, str)
        assert callable(func)

    def test_compute_tool_is_included(self):
        tool_names = [t[0] for t in get_default_tools()]
        assert "compute" in tool_names


# --- Integration: make_compute_tool (clean signature) ---

class TestMakeComputeTool:
    def test_compute_with_state(self):
        state = {"order_id": "ORD-123", "amount": 50.0, "_status": "active"}
        compute = make_compute_tool(state)
        result = compute(code="amount * 2")
        assert result == "100.0"

    def test_compute_with_empty_state(self):
        compute = make_compute_tool({})
        result = compute(code="2 + 2")
        assert result == "4"

    def test_signature_has_only_code_param(self):
        """Ensure the tool signature exposes only 'code' — no **kwargs."""
        import inspect
        compute = make_compute_tool({"x": 1})
        sig = inspect.signature(compute)
        param_names = list(sig.parameters.keys())
        assert param_names == ["code"]
        assert sig.parameters["code"].annotation is str

    def test_filters_internal_state_keys(self):
        state = {"price": 10, "_status": "active", "_conversations": {}}
        compute = make_compute_tool(state)
        result = compute(code="price * 5")
        assert result == "50"

    def test_current_date_injected(self):
        compute = make_compute_tool({})
        result = compute(code="current_date")
        assert result == date.today().isoformat()


# --- Date helper unit tests ---

class TestDateHelpers:
    def test_today(self):
        result = _today()
        assert result == date.today().isoformat()

    def test_days_between_positive(self):
        assert _days_between("2026-01-01", "2026-01-31") == 30

    def test_days_between_reversed(self):
        """Order of arguments shouldn't matter — always returns absolute value."""
        assert _days_between("2026-01-31", "2026-01-01") == 30

    def test_days_between_same_day(self):
        assert _days_between("2026-03-10", "2026-03-10") == 0

    def test_add_days_positive(self):
        assert _add_days("2026-03-01", 10) == "2026-03-11"

    def test_add_days_negative(self):
        assert _add_days("2026-03-10", -5) == "2026-03-05"

    def test_add_days_cross_month(self):
        assert _add_days("2026-01-30", 5) == "2026-02-04"

    def test_months_ago(self):
        expected = (date.today() - relativedelta(months=3)).isoformat()
        assert _months_ago(3) == expected

    def test_months_ago_zero(self):
        assert _months_ago(0) == date.today().isoformat()

    def test_add_months_basic(self):
        assert _add_months("2026-01-15", 2) == "2026-03-15"

    def test_add_months_end_of_month(self):
        """Jan 31 + 1 month = Feb 28 (handles month-end)."""
        assert _add_months("2026-01-31", 1) == "2026-02-28"

    def test_add_months_negative(self):
        assert _add_months("2026-03-15", -1) == "2026-02-15"

    def test_quarter_start_current(self):
        today = date.today()
        q = (today.month - 1) // 3
        expected = date(today.year, q * 3 + 1, 1).isoformat()
        assert _quarter_start(0) == expected

    def test_quarter_start_last(self):
        d = date.today() - relativedelta(months=3)
        q = (d.month - 1) // 3
        expected = date(d.year, q * 3 + 1, 1).isoformat()
        assert _quarter_start(-1) == expected

    def test_quarter_end_current(self):
        today = date.today()
        q = (today.month - 1) // 3
        first_of_next_q = q * 3 + 4
        if first_of_next_q > 12:
            next_q_start = date(today.year + 1, first_of_next_q - 12, 1)
        else:
            next_q_start = date(today.year, first_of_next_q, 1)
        expected = (next_q_start - timedelta(days=1)).isoformat()
        assert _quarter_end(0) == expected

    def test_quarter_end_last(self):
        """Last quarter's end should be the day before current quarter's start."""
        current_q_start = _quarter_start(0)
        last_q_end = _quarter_end(-1)
        assert _add_days(last_q_end, 1) == current_q_start

    def test_date_parts(self):
        result = _date_parts("2026-07-15")
        assert result == {"year": 2026, "month": 7, "day": 15}

    def test_date_parts_january(self):
        result = _date_parts("2026-01-01")
        assert result == {"year": 2026, "month": 1, "day": 1}


# --- Date functions via _compute (integration) ---

class TestComputeDateIntegration:
    def test_current_date_auto_injected(self):
        """current_date should always be available without passing it."""
        result = _compute("current_date")
        assert result == date.today().isoformat()

    def test_days_between_via_compute(self):
        result = _compute(
            "days_between(order_date, current_date)",
            order_date="2026-02-20",
        )
        expected = abs((date.today() - date(2026, 2, 20)).days)
        assert result == str(expected)

    def test_within_30_day_window(self):
        recent_date = (date.today() - timedelta(days=10)).isoformat()
        result = _compute(
            "days_between(order_date, current_date) <= 30",
            order_date=recent_date,
        )
        assert result == "True"

    def test_outside_30_day_window(self):
        old_date = (date.today() - timedelta(days=60)).isoformat()
        result = _compute(
            "days_between(order_date, current_date) <= 30",
            order_date=old_date,
        )
        assert result == "False"

    def test_add_days_via_compute(self):
        result = _compute("add_days(current_date, 90)")
        expected = (date.today() + timedelta(days=90)).isoformat()
        assert result == expected

    def test_months_ago_via_compute(self):
        result = _compute("months_ago(3)")
        expected = (date.today() - relativedelta(months=3)).isoformat()
        assert result == expected

    def test_add_months_via_compute(self):
        result = _compute("add_months('2026-01-31', 1)")
        assert result == "2026-02-28"

    def test_quarter_filtering(self):
        """Filter orders from last quarter using quarter_start/quarter_end."""
        last_q_start = _quarter_start(-1)
        last_q_end = _quarter_end(-1)
        # Create orders spanning multiple quarters
        orders = [
            {"id": 1, "date": last_q_start},           # in last quarter
            {"id": 2, "date": last_q_end},              # in last quarter
            {"id": 3, "date": _add_days(last_q_end, 5)},  # after last quarter
        ]
        code = (
            "q_s = quarter_start(-1)\n"
            "q_e = quarter_end(-1)\n"
            "[o for o in orders if o['date'] >= q_s and o['date'] <= q_e]"
        )
        result = _compute(code, orders=orders)
        assert "'id': 1" in result
        assert "'id': 2" in result
        assert "'id': 3" not in result

    def test_date_parts_via_compute(self):
        result = _compute("date_parts(current_date)['month']")
        assert result == str(date.today().month)

    def test_today_via_compute(self):
        result = _compute("today()")
        assert result == date.today().isoformat()

    def test_date_functions_with_state_data(self):
        """Combine date functions with state inputs for business logic."""
        result = _compute(
            'add_months(start_date, tenure_months)',
            start_date="2026-01-15",
            tenure_months=12,
        )
        assert result == "2027-01-15"
