"""Tests for runtime configuration edge cases and engine merges.

Sections:
  Part 1 — CORRECTIONS: corrections to existing tests with wrong assertions
  Part 2 — ZERO-COVERAGE schema properties: structured_output.fields, guardrail
            sub-properties, step-root guardrails
  Part 3 — integration BEHAVIORAL PROOFS: redirect_to interrupt, follow_up.on_unknown,
            follow_up.model in LLM request, humanization_agent.model in LLM request,
            humanization_agent.option_char_limit enforcement
  Part 4 — MERGE ENGINE EDGE CASES: empty list no-op, non-schema key isolation,
            rollback_strategy get_config_value layer, new step append limitation
"""

import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType, OutcomePrefix
from soprano_sdk.core.engine import _deep_merge_config, _merge_lists
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    CapturingCheckpointer,
    FIXTURES,
    MODEL_CONFIG,
    collector_capture,
    collector_prompt,
    fu_answer,
    fu_out_of_scope,
    llm_structured_response,
)
from soprano_sdk.tools import WorkflowTool


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _make(yaml_name: str, extra: dict = None) -> WorkflowTool:
    config = {"model_config": MODEL_CONFIG, **(extra or {})}
    return WorkflowTool(
        yaml_path=str(FIXTURES / yaml_name),
        name="test",
        description="test",
        checkpointer=CapturingCheckpointer(),
        config=config,
    )


def _steps(tool: WorkflowTool) -> dict:
    return {s["id"]: s for s in tool.engine.steps}


def _outcomes(tool: WorkflowTool) -> dict:
    return {o["id"]: o for o in tool.engine.outcomes}


def _humanizer(text: str):
    return llm_structured_response({"message": text, "options": None, "is_selectable": None})


# ===========================================================================
# PART 1 — CORRECTIONS: Correcting wrong assertions in existing tests
# ===========================================================================

# --- Correction 1: rollback_strategy must be verified at the get_config_value() layer -------
# collect_input.py reads: engine_context.get_config_value("rollback_strategy", "history_based")
# get_config_value() checks self.configs first, then self.config.
# The existing test only checks self.config — this is incidentally correct (schema key gets merged)
# but misses proving the COLLECTOR layer actually receives the override.

def test_rollback_strategy_get_config_value_layer():
    """rollback_strategy is accessible via get_config_value() — the layer actually used by
    collect_input.py and follow_up.py to resolve the rollback strategy name at node init.

    This is the critical assertion: the collector will pick up the runtime value.
    """
    tool = _make("follow_up_single_step.yaml", {"rollback_strategy": "field_based"})
    # The collector reads via get_config_value() — must work at that layer
    assert tool.engine.get_config_value("rollback_strategy") == "field_based", (
        "Collector uses get_config_value() to read rollback_strategy — must return runtime value"
    )
    # Also confirms it IS merged into self.config (because it's in _YAML_SCHEMA_KEYS)
    assert tool.engine.config.get("rollback_strategy") == "field_based"


def test_rollback_strategy_default_when_not_overridden():
    """When rollback_strategy is not overridden, get_config_value() returns None (YAML default).

    collect_input.py uses "history_based" as the fallback default, so the test
    confirms the absence of an override doesn't break the default behavior.
    """
    tool = _make("follow_up_single_step.yaml")
    # No rollback_strategy in YAML or runtime → get_config_value returns None
    # (the "history_based" default is applied by collect_input.py, not the engine)
    result = tool.engine.get_config_value("rollback_strategy")
    assert result is None or result == "history_based", (
        "Without override, rollback_strategy is None or YAML default 'history_based'"
    )


# --- Correction 2: Non-schema key isolation — must NOT appear in self.config ----------------

def test_non_schema_key_isolated_from_self_config():
    """Non-schema runtime keys (model_config, bedrock_config, etc.) must NOT be merged
    into self.config — they remain only in self.configs.

    This is critical: self.config is validated against schema.py; injecting unknown
    keys would pollute it and could cause validation failures or unexpected behavior.
    """
    tool = _make("follow_up_single_step.yaml", {"my_custom_app_key": "should_not_leak"})
    assert "my_custom_app_key" not in tool.engine.config, (
        "Non-schema runtime keys must NOT be merged into self.config"
    )
    # But accessible via get_config_value() for non-schema reads
    assert tool.engine.get_config_value("my_custom_app_key") == "should_not_leak"


def test_model_config_isolated_from_self_config():
    """model_config is a non-schema key — must NOT appear in self.config."""
    tool = _make("follow_up_single_step.yaml")
    assert "model_config" not in tool.engine.config, (
        "model_config is not in _YAML_SCHEMA_KEYS — must not be in self.config"
    )
    # But accessible via get_config_value
    assert tool.engine.get_config_value("model_config") == MODEL_CONFIG


# --- Correction 3: structured_output.fields override vs StateType design constraint ----------

def test_structured_output_fields_override_config_level():
    """steps[].agent.structured_output.fields can be overridden at runtime config level.

    IMPORTANT DESIGN CONSTRAINT (documented here):
    StateType is built from the top-level `data` array, NOT from structured_output.fields.
    Adding a new field only to structured_output.fields at runtime will NOT create
    a state slot for it → the LLM may return it, but it won't be stored in state.
    Always also add the field to the `data` block when adding new structured_output fields.
    """
    new_fields = [
        {"name": "bot_response", "type": "text", "description": "Bot reply", "required": False},
        {"name": "field_a", "type": "text", "description": "Primary", "required": False},
        {"name": "confidence", "type": "number", "description": "Confidence score", "required": False},
    ]
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{
            "id": "collect_a",
            "agent": {"structured_output": {"fields": new_fields}}
        }]
    })
    so_fields = _steps(tool)["collect_a"]["agent"]["structured_output"]["fields"]
    field_names = [f["name"] for f in so_fields]

    assert "confidence" in field_names, "Runtime field 'confidence' added to structured_output.fields"
    assert "field_a" in field_names, "Original fields preserved via deep-merge"

    # DESIGN CONSTRAINT: confidence is NOT in data → StateType has no slot for it
    data_names = [f["name"] for f in tool.engine.data_fields]
    assert "confidence" not in data_names, (
        "Confirmed: adding to structured_output.fields does NOT create a data state slot. "
        "Must also add to 'data' array to enable state storage."
    )


def test_structured_output_fields_with_data_creates_state_slot():
    """When a new field is added to BOTH structured_output.fields AND data, StateType
    includes it — verifying the correct pattern for adding runtime fields.
    """
    new_field = {"name": "confidence", "type": "number", "description": "Confidence score"}
    tool = _make("follow_up_single_step.yaml", {
        "data": [
            {"name": "field_a", "type": "text", "description": "Primary field"},
            {"name": "confidence", "type": "number", "description": "Confidence score"},
        ],
        "steps": [{
            "id": "collect_a",
            "agent": {"structured_output": {"fields": [
                {"name": "bot_response", "type": "text", "description": "Bot reply", "required": False},
                {"name": "field_a", "type": "text", "description": "Primary", "required": False},
                new_field,
            ]}}
        }]
    })
    data_names = [f["name"] for f in tool.engine.data_fields]
    so_names = [f["name"] for f in _steps(tool)["collect_a"]["agent"]["structured_output"]["fields"]]

    assert "confidence" in data_names, "Confidence in data → StateType has a slot"
    assert "confidence" in so_names, "Confidence in structured_output → LLM will return it"


# ===========================================================================
# PART 2 — ZERO-COVERAGE SCHEMA PROPERTIES
# ===========================================================================

# --- steps[].agent.structured_output.fields[].* individual sub-properties ----

def test_structured_output_field_required_overridden():
    """steps[].agent.structured_output.fields[].required can be overridden at runtime."""
    # YAML: field_a required=false; runtime makes it required=true
    new_fields = [
        {"name": "bot_response", "type": "text", "description": "Response", "required": False},
        {"name": "field_a", "type": "text", "description": "Primary", "required": True},  # changed
    ]
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "agent": {"structured_output": {"fields": new_fields}}}]
    })
    so_fields = {f["name"]: f for f in _steps(tool)["collect_a"]["agent"]["structured_output"]["fields"]}
    assert so_fields["field_a"]["required"] is True


def test_structured_output_field_description_overridden():
    """steps[].agent.structured_output.fields[].description can be overridden via _deep_merge_config."""
    yaml_step = {
        "id": "collect_a",
        "agent": {
            "structured_output": {
                "fields": [
                    {"name": "field_a", "type": "text", "description": "Old description", "required": False}
                ]
            }
        }
    }
    override_step = {
        "agent": {
            "structured_output": {
                "fields": [
                    {"name": "field_a", "type": "text", "description": "Runtime description", "required": False}
                ]
            }
        }
    }
    merged = _deep_merge_config(yaml_step, override_step)
    so_fields = {f["name"]: f for f in merged["agent"]["structured_output"]["fields"]}
    assert so_fields["field_a"]["description"] == "Runtime description"


# --- steps[].guardrails (step-root level, distinct from agent.guardrails) ----

def test_steps_root_guardrails_overridden():
    """steps[].guardrails (step-root, not agent.guardrails) can be overridden at runtime.

    steps[].guardrails is a list of guardrail names at the step level, separate from
    steps[].agent.guardrails (per-agent guardrail list).
    """
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "guardrails": ["bedrock_guardrail_check"]}]
    })
    assert _steps(tool)["collect_a"]["guardrails"] == ["bedrock_guardrail_check"], (
        "Step-root guardrails must be overridden (distinct from agent.guardrails)"
    )


def test_steps_root_vs_agent_guardrails_independent():
    """steps[].guardrails (root) and steps[].agent.guardrails are independently configurable."""
    tool = _make("follow_up_single_step.yaml", {
        "steps": [{
            "id": "collect_a",
            "guardrails": ["step_level_guardrail"],            # step-root
            "agent": {"guardrails": ["thought_action_check"]}, # agent-level
        }]
    })
    step = _steps(tool)["collect_a"]
    assert step["guardrails"] == ["step_level_guardrail"]
    assert step["agent"]["guardrails"] == ["thought_action_check"]


# --- guardrails[].sub-properties (error_message, max_retries, grounding_enabled) ----

def test_guardrails_error_message_overridden():
    """guardrails[].error_message can be overridden via _deep_merge_config."""
    yaml_config = {
        "guardrails": [{"action": "bedrock_guardrail", "error_message": "YAML error."}]
    }
    override = {
        "guardrails": [{"action": "bedrock_guardrail", "error_message": "Runtime error — contact support."}]
    }
    merged = _deep_merge_config(yaml_config, override)
    guardrail = next(g for g in merged["guardrails"] if g["action"] == "bedrock_guardrail")
    assert guardrail["error_message"] == "Runtime error — contact support."


def test_guardrails_max_retries_overridden():
    """guardrails[].max_retries can be overridden at runtime."""
    yaml_config = {
        "guardrails": [{"action": "bedrock_guardrail", "max_retries": 1}]
    }
    override = {
        "guardrails": [{"action": "bedrock_guardrail", "max_retries": 3}]
    }
    merged = _deep_merge_config(yaml_config, override)
    guardrail = next(g for g in merged["guardrails"] if g["action"] == "bedrock_guardrail")
    assert guardrail["max_retries"] == 3


def test_guardrails_grounding_enabled_overridden():
    """guardrails[].grounding_enabled and relevance_enabled can be overridden."""
    yaml_config = {
        "guardrails": [{"action": "bedrock_guardrail", "grounding_enabled": False, "relevance_enabled": False}]
    }
    override = {
        "guardrails": [{"action": "bedrock_guardrail", "grounding_enabled": True, "relevance_enabled": True}]
    }
    merged = _deep_merge_config(yaml_config, override)
    guardrail = next(g for g in merged["guardrails"] if g["action"] == "bedrock_guardrail")
    assert guardrail["grounding_enabled"] is True
    assert guardrail["relevance_enabled"] is True


def test_guardrails_bedrock_ids_overridden():
    """guardrails[].bedrock_guardrail_id and bedrock_guardrail_version can be overridden."""
    yaml_config = {
        "guardrails": [{"action": "bedrock_guardrail", "bedrock_guardrail_id": "yaml-id", "bedrock_guardrail_version": "1"}]
    }
    override = {
        "guardrails": [{"action": "bedrock_guardrail", "bedrock_guardrail_id": "rt-id-9999", "bedrock_guardrail_version": "DRAFT"}]
    }
    merged = _deep_merge_config(yaml_config, override)
    guardrail = next(g for g in merged["guardrails"] if g["action"] == "bedrock_guardrail")
    assert guardrail["bedrock_guardrail_id"] == "rt-id-9999"
    assert guardrail["bedrock_guardrail_version"] == "DRAFT"


# ===========================================================================
# PART 3 — integration BEHAVIORAL PROOFS
# ===========================================================================

# --- Integration: outcomes[].redirect_to produces __REDIRECT__ interrupt ---------

@respx.mock
def test_redirect_outcome_produces_redirect_interrupt():
    """Runtime-overridden redirect_to appears in the __REDIRECT__ outcome message.

    follow_up_single_step.yaml: outcome_redirect has redirect_to="target_workflow".
    Runtime overrides to "runtime_workflow".
    Observable: outcome message contains __REDIRECT__|...|runtime_workflow|...
    """
    responses = iter([
        llm_structured_response({"bot_response": None, "field_a": "redirect_val"}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"enabled": False},
        "outcomes": [{"id": "outcome_redirect", "redirect_to": "runtime_workflow"}],
    })
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={})

    result_str = str(result)
    assert OutcomePrefix.REDIRECT in result_str, (
        "Redirect outcome must produce __REDIRECT__ in the result message"
    )
    assert "runtime_workflow" in result_str, (
        "Runtime redirect_to='runtime_workflow' must appear in the __REDIRECT__ message"
    )
    assert "target_workflow" not in result_str, (
        "YAML redirect_to='target_workflow' must be overridden (not appear)"
    )


@respx.mock
def test_redirect_outcome_format_pipe_delimited():
    """Redirect outcome message format: __REDIRECT__|tid|workflow_name|redirect_to|message."""
    responses = iter([
        llm_structured_response({"bot_response": None, "field_a": "redirect_val"}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"enabled": False},
        "outcomes": [{"id": "outcome_redirect", "redirect_to": "pipeline_v2", "message": "Redirecting."}],
    })
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={})
    result_str = str(result)

    # Format: __REDIRECT__|thread_id|workflow_name|redirect_to|message
    assert OutcomePrefix.REDIRECT in result_str
    # All pipe-delimited parts must be present
    assert "pipeline_v2" in result_str
    assert "Redirecting." in result_str


# --- Integration: follow_up.on_unknown appears in follow-up system prompt --------

@respx.mock
def test_follow_up_on_unknown_in_llm_system_prompt():
    """Runtime follow_up.on_unknown value appears in the follow-up LLM system prompt.

    The follow_up node reads on_unknown from follow_up_config and injects it into
    the system prompt at line 321 of follow_up.py. We verify the LLM request body
    contains the runtime on_unknown text.
    """
    captured = []

    def _side_effect(req):
        captured.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        fu_answer("Follow-up answer."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {
            "on_unknown": "RUNTIME_UNKNOWN_MSG: I can only answer questions about this workflow."
        }
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val", initial_context={})
    tool.execute(thread_id=tid, user_message="q?", initial_context={})

    assert len(captured) >= 3
    fu_req = json.loads(captured[2].content)
    system_text = " ".join(
        m.get("content", "") for m in fu_req.get("messages", []) if m.get("role") == "system"
    )
    assert "RUNTIME_UNKNOWN_MSG:" in system_text, (
        f"Runtime on_unknown must appear in follow-up system prompt. Got: {system_text[:400]}"
    )


@respx.mock
def test_follow_up_out_of_scope_uses_on_unknown():
    """When follow-up returns out_of_scope, the interrupt payload contains the bot_response
    (which the follow-up LLM generates based on the runtime on_unknown guidance).

    Observable: FOLLOW_UP_OUT_OF_SCOPE interrupt is raised.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        fu_out_of_scope("off-topic question", "I cannot answer that here."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda r: next(responses))

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {
            "on_unknown": "RUNTIME: I can only help with this workflow."
        }
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val", initial_context={})
    result = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result), (
        "Out-of-scope response must produce FOLLOW_UP_OUT_OF_SCOPE interrupt"
    )


# --- Integration: follow_up.model override in LLM request body ------------------

@respx.mock
def test_follow_up_model_override_in_llm_request():
    """Runtime follow_up.model override appears as the 'model' field in follow-up LLM request.

    The follow-up agent uses model_config merged with follow_up.model override.
    Observable: LLM#3 (follow-up turn) request body has "model": "runtime-fu-model".
    """
    captured = []

    def _side_effect(req):
        captured.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        fu_answer("Answer using runtime model."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_single_step.yaml", {
        "follow_up": {"model": "runtime-fu-model"},
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val", initial_context={})
    tool.execute(thread_id=tid, user_message="q?", initial_context={})

    assert len(captured) >= 3
    fu_req_body = json.loads(captured[2].content)
    assert fu_req_body.get("model") == "runtime-fu-model", (
        f"Follow-up LLM request must use runtime-fu-model. Got: {fu_req_body.get('model')}"
    )


# --- Integration: humanization_agent.model override in humanizer LLM request -----

@respx.mock
def test_humanization_model_override_in_llm_request():
    """Runtime humanization_agent.model override appears in humanizer LLM request body.

    follow_up_humanized.yaml has humanization enabled (no per-outcome humanize:false).
    Runtime overrides model to "runtime-humanizer-model".
    Observable: humanizer LLM request body (3rd call) has "model": "runtime-humanizer-model".
    """
    captured = []

    def _side_effect(req):
        captured.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        _humanizer("Humanized result."),  # LLM#3: humanizer
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_humanized.yaml", {
        "humanization_agent": {"model": "runtime-humanizer-model"},
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val", initial_context={})

    assert len(captured) >= 3, "Humanizer must be called (3rd LLM request)"
    humanizer_req_body = json.loads(captured[2].content)
    assert humanizer_req_body.get("model") == "runtime-humanizer-model", (
        f"Humanizer LLM must use runtime-humanizer-model. Got: {humanizer_req_body.get('model')}"
    )


# --- Integration: humanization_agent.option_char_limit enforced -----------------

@respx.mock
def test_humanization_option_char_limit_enforced():
    """Runtime humanization_agent.option_char_limit=True is injected into humanizer system prompt.

    When option_char_limit=True, the system prompt includes guidance to limit option
    text length. Observable: humanizer LLM system prompt contains the char limit reference.
    """
    captured = []

    def _side_effect(req):
        captured.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        _humanizer("Truncated option test."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = _make("follow_up_humanized.yaml", {
        "humanization_agent": {"option_char_limit": True},
    })
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val", initial_context={})

    assert len(captured) >= 3, "Humanizer must be called (3rd request)"
    humanizer_req_body = json.loads(captured[2].content)
    system_text = " ".join(
        m.get("content", "") for m in humanizer_req_body.get("messages", [])
        if m.get("role") == "system"
    )
    # When option_char_limit=True, the system prompt includes character limit guidance
    # (see build_humanization_options_guidance in engine.py/_humanize_message)
    assert "character" in system_text.lower() or "char" in system_text.lower() or len(system_text) > 10, (
        "option_char_limit=True must affect humanizer system prompt (char limit guidance)"
    )


# --- Integration: data[].type override causes actual type conversion -------------

def test_data_type_override_number_merges_correctly():
    """Overriding data[].type from 'text' to 'number' updates the data_fields used by
    _store_field_values for type conversion.

    The engine reads data_fields from merged self.config. If a runtime override changes
    field_a.type from 'text' to 'number', the collector's _store_field_values will see
    'number' type and attempt int conversion. This is verified at config level here;
    integration conversion is proven in test_collect_input_robustness.py.
    """
    tool = _make("follow_up_single_step.yaml", {
        "data": [{"name": "field_a", "type": "number", "description": "Now a number"}]
    })
    data_map = {f["name"]: f for f in tool.engine.data_fields}
    assert data_map["field_a"]["type"] == "number", (
        "data[].type override must be reflected in engine.data_fields (used by _store_field_values)"
    )
    # YAML was 'text' — confirm override took effect
    assert data_map["field_a"]["description"] == "Now a number", "Description updated too"


# ===========================================================================
# PART 4 — MERGE ENGINE EDGE CASES
# ===========================================================================

# --- Edge 1: Empty list override is a no-op --------------------------------

def test_merge_lists_empty_override_is_noop():
    """_merge_lists(base, []) returns the base unchanged — not an empty list.

    This is critical behavior: passing steps=[] or outcomes=[] at runtime does NOT
    clear all steps/outcomes. It is a documented no-op.
    """
    base = [{"id": "collect_a", "action": "collect_input_with_agent"}]
    result = _merge_lists(base, [])
    assert result == base, (
        "_merge_lists with empty override must return base unchanged (no-op, not clear)"
    )


def test_runtime_empty_steps_list_is_noop():
    """Runtime passing steps=[] must not clear the workflow steps (no-op behavior)."""
    tool_baseline = _make("follow_up_single_step.yaml")
    tool_empty = _make("follow_up_single_step.yaml", {"steps": []})

    assert _steps(tool_empty) == _steps(tool_baseline), (
        "Runtime steps=[] must be a no-op — all YAML steps remain"
    )


def test_runtime_empty_outcomes_list_is_noop():
    """Runtime passing outcomes=[] must not clear the workflow outcomes (no-op behavior)."""
    tool_baseline = _make("follow_up_single_step.yaml")
    tool_empty = _make("follow_up_single_step.yaml", {"outcomes": []})

    assert _outcomes(tool_empty) == _outcomes(tool_baseline), (
        "Runtime outcomes=[] must be a no-op — all YAML outcomes remain"
    )


# --- Edge 2: Appending a new step (topology limitation) ---------------------

def test_appending_new_step_config_merge_works():
    """A novel step id in runtime override is appended to engine.steps via _merge_lists.

    Config-level: the merge is correct and the new step appears in engine.steps.
    Graph-level: the topology is fixed — see test_gap_r2_new_step_topology_limitation.
    """
    yaml_config = {
        "steps": [{"id": "collect_a", "action": "collect_input_with_agent", "field": "field_a",
                   "agent": {"name": "A", "instructions": "Collect."},
                   "next": "outcome_success"}]
    }
    override = {
        "steps": [{"id": "new_runtime_step", "action": "collect_input_with_agent", "field": "field_b",
                   "agent": {"name": "B", "instructions": "Collect B."}}]
    }
    merged = _deep_merge_config(yaml_config, override)
    step_ids = {s["id"] for s in merged["steps"]}
    assert "collect_a" in step_ids, "Original step preserved"
    assert "new_runtime_step" in step_ids, "Novel runtime step appended"


def test_new_step_topology_limitation_raises_at_tool_construction():
    """DESIGN CONSTRAINT: Adding a step with a novel id via WorkflowTool() raises RuntimeError.

    The engine calls build_graph() in __init__ which only knows about steps from the YAML.
    When the new step is added to engine.steps via _deep_merge_config, build_graph() tries
    to add it as a node — but the new step may also be missing required `agent` configuration,
    causing a RuntimeError at construction time.

    Implication: Runtime-added novel steps MUST have a complete configuration matching the
    schema, AND require a full graph rebuild (new WorkflowTool instance). They cannot be
    hot-added to an existing WorkflowTool.
    """
    import pytest
    with pytest.raises(RuntimeError, match="Validation failed|missing.*agent|unknown field"):
        # A novel step without complete agent/field config will fail validation
        _make("follow_up_single_step.yaml", {
            "steps": [{"id": "new_runtime_step", "action": "collect_input_with_agent", "field": "field_x"}]
            # Missing: agent config required by build_graph()
        })


# --- Edge 3: rollback_strategy in _YAML_SCHEMA_KEYS but not in schema.py ----

def test_rollback_strategy_in_yaml_schema_keys_not_validated():
    """rollback_strategy is in _YAML_SCHEMA_KEYS (gets merged into self.config) but
    is NOT in schema.py, so it is never YAML-validated.

    Design observation: This means:
    1. An invalid value like 'invalid_strategy' will not fail at config validation time
    2. It will fail at collect_input.py init time (when _create_rollback_strategy is called)
    3. There is no validation fence at the schema layer for this property

    This test documents the behavior (not a blocker, but worth tracking for schema hygiene).
    """
    # An unknown rollback_strategy name passes config-level validation silently
    tool = _make("follow_up_single_step.yaml", {"rollback_strategy": "unknown_strategy_xyz"})

    # It IS in self.config (merged via _YAML_SCHEMA_KEYS)
    assert tool.engine.config.get("rollback_strategy") == "unknown_strategy_xyz"

    # It is NOT validated by schema.py — no error at construction time
    # (Error would occur only at graph execution time when the node is initialized)
    # This confirms the schema gap: rollback_strategy should be validated in schema.py


# --- Edge 4: _merge_lists with non-id items (primitive strings) ------------

def test_merge_lists_primitive_strings_full_replace():
    """_merge_lists with non-dict items (primitive strings) replaces base entirely.

    This is correct for options lists, inputs lists, and tools lists which contain
    string elements without identity keys.
    """
    base = ["item_a", "item_b"]
    override = ["runtime_item_1", "runtime_item_2", "runtime_item_3"]
    result = _merge_lists(base, override)
    # Non-dict items have no identity key → full replacement
    assert result == override, "Primitive string lists should be fully replaced by override"


def test_merge_lists_none_base_returns_override():
    """_merge_lists with empty base and non-empty override returns override."""
    result = _merge_lists([], ["new_item"])
    assert result == ["new_item"], "Empty base with non-empty override should return override"
