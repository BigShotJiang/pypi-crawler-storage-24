"""Tests for the follow-up feature flags — enabling/disabling follow-up globally and per-outcome.
Verifies that the graph terminates correctly when follow-up is disabled, and activates the follow-up
node when enabled.
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    llm_structured_response,
    make_tool,
    snap,
)


@respx.mock
def test_follow_up_disabled_ends_graph_at_outcome():
    """When follow-up is disabled globally in the workflow YAML, the graph should
    end at the outcome without raising a FOLLOW_UP interrupt. This ensures that
    workflows that do not need follow-up do not enter the follow-up node at all.
    """
    responses = iter([
        llm_structured_response({"bot_response": "Do you want to submit?", "captured": None, "extra": None}),
        llm_structured_response({"bot_response": None, "captured": True, "extra": ""}),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="yes", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP not in str(result2)
    assert s.get("_outcome_id") is not None
    assert respx.calls.call_count == 2


@respx.mock
def test_per_outcome_follow_up_disabled_ends_graph_after_outcome():
    """When a specific outcome has follow_up disabled, the graph should end after
    reaching that outcome without entering the follow-up node. Other outcomes with
    follow_up enabled should still activate the follow-up node.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("no_fu_val"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="no_fu_val", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP not in str(result2)
    assert s["_outcome_id"] == "outcome_no_followup"
    assert respx.calls.call_count == 2


@respx.mock
def test_per_outcome_follow_up_enabled_activates_follow_up_node():
    """When a specific outcome has follow_up enabled, the graph should activate the
    follow-up node after reaching that outcome and raise a FOLLOW_UP interrupt.
    The outcome_id should be stored in the checkpoint to track which outcome triggered
    the follow-up session.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result2)
    # _follow_up_active is set inside the node before interrupt() but not checkpointed
    # until the node returns — check via outcome_id instead
    assert s["_outcome_id"] == "outcome_success"
    assert respx.calls.call_count == 2
