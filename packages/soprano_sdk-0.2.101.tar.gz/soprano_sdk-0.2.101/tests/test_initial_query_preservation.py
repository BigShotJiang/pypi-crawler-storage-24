import uuid
import respx
import json
from langgraph.checkpoint.memory import InMemorySaver
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    make_tool,
    llm_structured_response
)

@respx.mock
def test_initial_query_preservation_across_nodes():
    """
    Scenario:
    1. User provides initial query Q1.
    2. Node 1 (CollectorA) asks for clarification.
    3. User replies to clarification.
    4. Workflow passes through two functional nodes.
    5. Node 4 (CollectorB) is reached.
    6. Verify that CollectorB's LLM prompt contains Q1.
    """
    captured_requests = []
    
    # Track turns for CollectorA
    state = {"collector_a_turns": 0}
    
    Q1 = "I want to apply for a loan"
    CLARIFICATION_RESPONSE = "Personal loan"

    def mock_llm(request):
        body = json.loads(request.content)
        captured_requests.append(body)
        prompt = str(body["messages"])

        if "Collect field A" in prompt:
            if state["collector_a_turns"] == 0:
                state["collector_a_turns"] += 1
                return llm_structured_response({"bot_response": "What kind of loan?"})
            else:
                return llm_structured_response({"field_a": "Loan Type Collected"})
        
        if "Collect field B" in prompt:
            return llm_structured_response({"bot_response": "What is field B?"})

        return llm_structured_response({"bot_response": "Default response"})

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)

    tool = make_tool("initial_query_preservation.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    # 1. Start workflow with initial query Q1
    resp1 = tool.execute(thread_id=tid, user_message=Q1, initial_context={})
    assert "What kind of loan?" in resp1.text
    
    # 2. User replies to clarification
    tool.execute(thread_id=tid, user_message=CLARIFICATION_RESPONSE, initial_context={})
    
    # Now verify CollectorB's history contains Q1
    b_requests = [r for r in captured_requests if "Collect field B" in str(r["messages"])]
    assert len(b_requests) > 0
    
    last_history = str(b_requests[-1]["messages"])
    assert Q1 in last_history

@respx.mock
def test_restart_updates_initial_query():
    """Verify that restart clears history but preserves the new initial query if provided."""
    captured_requests = []
    
    def mock_llm(request):
        body = json.loads(request.content)
        captured_requests.append(body)
        prompt = str(body["messages"])

        if "FollowUp" in prompt or "follow_up" in prompt.lower():
            # If we see Q2 here, it means FollowUp was reached with the new message
            return llm_structured_response({"restart": True, "bot_response": "Starting over."})
        
        if "Collect field A" in prompt:
            return llm_structured_response({"bot_response": "What is field A?"})
            
        return llm_structured_response({"bot_response": "Default."})

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)
    
    tool = make_tool("follow_up_single_step.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())
    
    Q1 = "Initial message Q1"
    Q2 = "New message Q2"
    
    tool.execute(thread_id=tid, user_message=Q1, initial_context={})
    
    # After first execute, Q1 should be in the history of CollectorA
    assert Q1 in str(captured_requests[0]["messages"])
    
    # Trigger restart with Q2. 
    tool.execute(thread_id=tid, user_message=Q2, initial_context={}) 
    
    # After restart, there should be a new call to CollectorA
    a_requests = [r for r in captured_requests if "Collect field A" in str(r["messages"])]
    assert len(a_requests) >= 2
    
    last_a_req = a_requests[-1]
    # In the last request to CollectorA, Q2 should be the new user message
    # and Q1 should no longer be present in the history (cleared by restart)
    assert Q2 in str(last_a_req["messages"])
    assert Q1 in str(last_a_req["messages"])

@respx.mock
def test_empty_initial_query_leaves_history_empty():
    captured_requests = []
    def mock_llm(request):
        body = json.loads(request.content)
        captured_requests.append(body)
        return llm_structured_response({"bot_response": "A?"})

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)
    
    tool = make_tool("follow_up_single_step.yaml")
    # Empty string user message
    tool.execute(thread_id=str(uuid.uuid4()), user_message="", initial_context={}) 
    
    # With updated logic, an empty/whitespace user message should not be added to history
    user_msgs = [m for m in captured_requests[0]["messages"] if m.get("role") == "user" and m.get("content")]
    assert len(user_msgs) == 0

@respx.mock
def test_intent_change_preserves_initial_query():
    captured_requests = []
    def mock_llm(request):
        body = json.loads(request.content)
        captured_requests.append(body)
        prompt = str(body["messages"])

        if "Collect field A" in prompt:
            return llm_structured_response({"field_a": "val_a"})
        if "Collect field B" in prompt:

            return llm_structured_response({"bot_response": "B?"})
        if "FollowUp" in prompt or "follow_up" in prompt.lower():
            return llm_structured_response({"intent_change": "collect_a"})
        return llm_structured_response({"bot_response": "..."})

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)
    
    tool = make_tool("initial_query_preservation.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())
    Q1 = "Original query for A"
    
    # 1. Start: Q1 -> CollectorA (returns field_a) -> func_1 -> func_2 -> CollectorB (interrupts with "B?")
    tool.execute(thread_id=tid, user_message=Q1, initial_context={})
    
    # 2. User says "Change A" -> Resumes CollectorB -> Default response -> FollowUp -> intent_change -> CollectorA
    tool.execute(thread_id=tid, user_message="Change A", initial_context={})
    
    a_requests = [r for r in captured_requests if "Collect field A" in str(r["messages"])]
    # At least two calls to CollectorA: one at start, one after intent change
    assert len(a_requests[0]['messages']) >= 2
    assert Q1 in str(a_requests[-1]["messages"])

@respx.mock
def test_functional_start_to_followup_preserves_query():
    """
    Scenario:
    1. Workflow starts with call_function node (non-agentic).
    2. Workflow reaches outcome and interrupts for follow-up.
    3. Verify that Follow-up's system prompt contains the initial user query.
    """
    captured_requests = []
    
    def mock_llm(request):
        body = json.loads(request.content)
        captured_requests.append(body)
        return llm_structured_response({"bot_response": "Follow-up response"})

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)

    tool = make_tool("function_only_to_followup.yaml")
    tid = str(uuid.uuid4())
    Q1 = "Initial query for functional start"
    
    # 1. Start workflow. It will run 'start_node' (function) and hit outcome_success (interrupt)
    resp = tool.execute(thread_id=tid, user_message=Q1, initial_context={})
    assert "Function executed successfully" in resp.text
    
    # 2. Responding to follow-up
    tool.execute(thread_id=tid, user_message="Still here?", initial_context={})
    
    assert len(captured_requests) > 0
    system_prompt = str(captured_requests[0]["messages"])
    
    # Verify WORKFLOW CONTEXT contains Q1
    assert "WORKFLOW CONTEXT:" in system_prompt
    assert Q1 in system_prompt
