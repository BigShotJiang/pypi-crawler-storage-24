"""Simple processing functions for test fixtures."""


def set_computed_value(state: dict) -> str:
    """Set side_effect_value directly on state; return value goes to computed_value via output."""
    state["side_effect_value"] = "side_effect_set"
    return "computed_set"


def validate_age(state: dict) -> bool:
    """Validate that the collected age is a valid number.

    In SO mode, the field stores a dict like {"age": "25", "captured": True}.
    """
    age_field = state.get('age', '')
    # Handle SO mode dict format
    if isinstance(age_field, dict):
        age = age_field.get('age', '')
    else:
        age = age_field
    try:
        age_int = int(age)
        return 0 < age_int < 150
    except (ValueError, TypeError):
        return False


def raise_exception(state: dict) -> None:
    """Raise a hard exception."""
    raise ValueError("A hard error occurred")


def dummy_func(state: dict):
    return "Success"