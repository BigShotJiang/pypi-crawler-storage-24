import re

def normalize_text(text: str) -> str:
    """Normalize user message for comparison with previous messages.
    """
    if not text:
        return ""
    text = text.lower().strip()
    # Remove common punctuation
    text = re.sub(r"[^\w\s]", "", text)
    # Collapse multiple spaces
    text = re.sub(r"\s+", " ", text)
    return text
