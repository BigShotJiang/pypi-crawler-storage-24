"""Built-in tools automatically available to all data collector agents."""
import json
from datetime import date, timedelta
from typing import Any, Callable, Dict, List, Tuple

from dateutil.relativedelta import relativedelta

from .logger import logger

# ---------------------------------------------------------------------------
# Date helper functions (executed on host, registered as Monty external fns)
# ---------------------------------------------------------------------------


def _today() -> str:
    """Return current date as ISO string."""
    return date.today().isoformat()


def _days_between(date1: str, date2: str) -> int:
    """Return absolute number of days between two ISO date strings."""
    return abs((date.fromisoformat(date2) - date.fromisoformat(date1)).days)


def _add_days(d: str, n: int) -> str:
    """Add n days to an ISO date string. Use negative n to subtract."""
    return (date.fromisoformat(d) + timedelta(days=n)).isoformat()


def _months_ago(n: int) -> str:
    """Return the date n months before today as ISO string."""
    return (date.today() - relativedelta(months=n)).isoformat()


def _add_months(d: str, n: int) -> str:
    """Add n months to an ISO date string. Handles month-end (Jan 31 + 1mo = Feb 28)."""
    return (date.fromisoformat(d) + relativedelta(months=n)).isoformat()


def _quarter_start(offset: int = 0) -> str:
    """First day of the quarter. offset=0 is current, -1 is last quarter, etc."""
    d = date.today() + relativedelta(months=3 * offset)
    q = (d.month - 1) // 3
    return date(d.year, q * 3 + 1, 1).isoformat()


def _quarter_end(offset: int = 0) -> str:
    """Last day of the quarter. offset=0 is current, -1 is last quarter, etc."""
    d = date.today() + relativedelta(months=3 * offset)
    q = (d.month - 1) // 3
    first_of_next_q_month = q * 3 + 4  # month number (1-indexed, may exceed 12)
    if first_of_next_q_month > 12:
        next_q_start = date(d.year + 1, first_of_next_q_month - 12, 1)
    else:
        next_q_start = date(d.year, first_of_next_q_month, 1)
    return (next_q_start - timedelta(days=1)).isoformat()


def _date_parts(d: str) -> dict:
    """Return {"year": int, "month": int, "day": int} from an ISO date string."""
    parsed = date.fromisoformat(d)
    return {"year": parsed.year, "month": parsed.month, "day": parsed.day}


# Registry of date external functions for Monty
DATE_EXTERNAL_FUNCTIONS: Dict[str, Callable] = {
    "today": _today,
    "days_between": _days_between,
    "add_days": _add_days,
    "months_ago": _months_ago,
    "add_months": _add_months,
    "quarter_start": _quarter_start,
    "quarter_end": _quarter_end,
    "date_parts": _date_parts,
}

DATE_TYPE_STUBS = """\
def today() -> str: ...
def days_between(date1: str, date2: str) -> int: ...
def add_days(d: str, n: int) -> str: ...
def months_ago(n: int) -> str: ...
def add_months(d: str, n: int) -> str: ...
def quarter_start(offset: int = 0) -> str: ...
def quarter_end(offset: int = 0) -> str: ...
def date_parts(d: str) -> dict: ...
"""

# ---------------------------------------------------------------------------
# Compute tool
# ---------------------------------------------------------------------------

MONTY_TOOL_NAME = "compute"
MONTY_TOOL_DESCRIPTION = (
    "Execute Python code for calculations and data processing. "
    "Use for arithmetic, min/max, filtering, sorting, string manipulation, "
    "comparisons, and conditional logic. "
    "Available builtins: min, max, sum, sorted, abs, round, len, range, enumerate, zip, map, filter, any, all, isinstance, str, int, float, bool, list, dict, set, tuple. "
    "Supports: list/dict comprehensions, f-strings, slicing, nested data access. "
    "Does NOT support: import statements or class definitions. "
    "Date functions available: "
    "today() returns current date, "
    "days_between(date1, date2) returns number of days, "
    "add_days(date, n) adds n days, "
    "months_ago(n) returns date n months ago, "
    "add_months(date, n) adds n months, "
    "quarter_start(offset) and quarter_end(offset) return quarter boundaries (0=current, -1=last), "
    "date_parts(date) returns {year, month, day}. "
    "All dates use ISO format YYYY-MM-DD. "
    "current_date is always available as a pre-defined variable. "
    "Workflow state variables are also available as pre-defined inputs. "
    "The last expression in your code is the return value. "
    "Example: compute(code='days_between(order_date, current_date) <= 30') "
    "Example: compute(code='max([r[\"score\"] for r in records])') "
    "Example: compute(code='price * quantity * (1 - discount / 100)')"
)


def _filter_state_for_monty(state: Dict[str, Any]) -> Dict[str, Any]:
    """Filter workflow state to only include user-facing, serializable data as Monty inputs."""
    inputs = {}
    for key, value in state.items():
        if key.startswith('_'):
            continue
        try:
            json.dumps(value)
            inputs[key] = value
        except (TypeError, ValueError):
            continue
    return inputs


def _build_type_stubs(inputs: Dict[str, Any]) -> str:
    """Generate type stub strings from input dict for Monty type checking."""
    type_map = {
        str: "str",
        int: "int",
        float: "float",
        bool: "bool",
        list: "list",
        dict: "dict",
    }
    lines = []
    for key, value in inputs.items():
        py_type = type_map.get(type(value), "Any")
        lines.append(f"{key}: {py_type} = {repr(value)}")
    if not lines:
        return ""
    return "\n".join(lines)


def _compute(code: str, **kwargs) -> str:
    """Execute Python code in a sandboxed Monty interpreter.

    Args:
        code: Python code to execute. The last expression is the return value.

    Returns:
        String representation of the computation result.
    """
    try:
        import pydantic_monty
    except ImportError:
        return "Error: pydantic-monty is not installed. Install with: pip install pydantic-monty"

    # Filter state and auto-inject current_date
    inputs = _filter_state_for_monty(kwargs)
    inputs["current_date"] = date.today().isoformat()

    # Build type stubs (state stubs + date function stubs)
    state_stubs = _build_type_stubs(inputs)
    all_stubs = f"{state_stubs}\n{DATE_TYPE_STUBS}"

    try:
        monty = pydantic_monty.Monty(
            code,
            inputs=list(inputs.keys()),
            type_check=True,
            type_check_stubs=all_stubs,
        )
        result = monty.run(
            inputs=inputs,
            external_functions=DATE_EXTERNAL_FUNCTIONS,
        )
        logger.info("Monty computation completed successfully")
        return str(result)
    except Exception as e:
        error_msg = f"Computation error: {e}"
        logger.warning(f"Monty execution failed: {e}")
        return error_msg


def make_compute_tool(state: Dict[str, Any]) -> Callable:
    """Create a compute tool closure that captures workflow state.

    Returns a function with a clean ``(code: str) -> str`` signature so
    that framework tool-schema generators (LangGraph, OpenAI, etc.) only
    expose the ``code`` parameter to the LLM — not ``**kwargs``.
    """
    filtered = _filter_state_for_monty(state)

    def compute(code: str) -> str:
        """Execute Python code for calculations and data processing."""
        return _compute(code, **filtered)

    return compute


def get_default_tools() -> List[Tuple[str, str, Callable]]:
    """Return list of built-in tool tuples to inject into agents by default."""
    return [
        (MONTY_TOOL_NAME, MONTY_TOOL_DESCRIPTION, _compute),
    ]
