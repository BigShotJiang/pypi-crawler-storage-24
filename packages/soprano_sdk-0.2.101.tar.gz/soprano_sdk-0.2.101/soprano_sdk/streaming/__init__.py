"""soprano_sdk.streaming -- Real-time streaming for soprano-sdk workflows.

This module wraps soprano-sdk's LangGraph-based workflow engine and
exposes a generator-based streaming API.  Instead of the synchronous
``WorkflowTool.execute()`` that returns a single ``WorkflowResult``,
you get a stream of typed events as each graph node executes -- enabling
Server-Sent Events, WebSocket pushes, or any incremental transport.

Quick start
-----------
::

    from soprano_sdk.streaming import WorkflowStreamer, InterruptEvent, CompleteEvent

    streamer = WorkflowStreamer.from_env("workflow.yaml")

    for event in streamer.stream(thread_id="t1", user_message="hello"):
        match event:
            case InterruptEvent():
                print(f"Bot asks: {event.prompt}")
            case CompleteEvent():
                print(f"Done: {event.message}")

Emitting events from user-defined functions
--------------------------------------------
::

    from soprano_sdk.streaming import emit

    def check_eligibility(state):
        result = crm.lookup(state["order_id"])
        emit("tool_result", {"tool": "crm.lookup", "result": result})
        return {"eligible": True}
"""

from typing import Any, Dict, Optional

from langgraph.config import get_stream_writer

from .events import (
    AsyncInterruptEvent,
    CompleteEvent,
    CustomEvent,
    ErrorEvent,
    FollowUpEvent,
    FollowUpOutOfScopeEvent,
    InterruptEvent,
    NodeCompleteEvent,
    OutOfScopeEvent,
    RedirectEvent,
    WorkflowEvent,
)
from .streamer import WorkflowStreamer


def emit(event_type: str, data: Optional[Dict[str, Any]] = None) -> None:
    """Emit a mid-node event to streaming consumers.

    When the workflow is running in streaming mode
    (via ``WorkflowStreamer.stream()``), the event is written to
    LangGraph's custom-event channel and surfaces as a
    ``CustomEvent``.  Outside streaming mode, this is a no-op.

    Parameters
    ----------
    event_type:
        A short label describing the event (e.g. ``"tool_result"``,
        ``"llm_response"``, ``"validation_check"``).
    data:
        Arbitrary JSON-serializable payload.  Merged into the event
        dict alongside ``type``.
    """
    try:
        writer = get_stream_writer()
    except RuntimeError:
        return
    writer({"type": event_type, **(data or {})})


__all__ = [
    "emit",
    "WorkflowStreamer",
    "NodeCompleteEvent",
    "CustomEvent",
    "InterruptEvent",
    "AsyncInterruptEvent",
    "OutOfScopeEvent",
    "FollowUpEvent",
    "FollowUpOutOfScopeEvent",
    "CompleteEvent",
    "RedirectEvent",
    "ErrorEvent",
    "WorkflowEvent",
]
