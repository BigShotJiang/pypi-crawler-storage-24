"""Domain events emitted by WorkflowStreamer.

These dataclasses are the public contract between the streaming layer
and consumer code.  They carry no soprano-sdk or LangGraph types --
consumers never need to import from those packages.

Event types
-----------
``NodeCompleteEvent``
    Emitted once per graph node after it finishes execution.

``CustomEvent``
    Emitted mid-node when a workflow function calls ``emit()``.

``InterruptEvent``
    The workflow paused and is waiting for user input.

``AsyncInterruptEvent``
    The workflow paused for an external async operation.

``OutOfScopeEvent``
    The user's query was detected as out of scope.

``FollowUpEvent``
    The workflow completed and is in follow-up mode, waiting for Q&A.

``FollowUpOutOfScopeEvent``
    The follow-up agent detected the user's query as out of scope.

``CompleteEvent``
    The workflow reached a terminal outcome.

``RedirectEvent``
    The workflow completed with a redirect to another workflow.

``ErrorEvent``
    An unrecoverable error occurred during streaming.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Union


@dataclass
class NodeCompleteEvent:
    """A graph node finished execution."""

    node: str
    """Name of the node that completed."""

    state_update: Dict[str, Any]
    """State fields written or changed by this node."""


@dataclass
class CustomEvent:
    """A mid-node event emitted via ``emit()``."""

    payload: Dict[str, Any]
    """Arbitrary dict written by the workflow function."""


@dataclass
class InterruptEvent:
    """The workflow paused and needs user input to continue."""

    prompt: str
    """The agent's message / question for the user."""

    options: List[Dict[str, Any]] = field(default_factory=list)
    """Selectable options (each has ``text`` and optional ``subtext``)."""

    is_selectable: bool = False
    """True if the user must pick from options."""

    field_details: List[Dict[str, Any]] = field(default_factory=list)
    """Metadata for the active collector node's fields."""


@dataclass
class AsyncInterruptEvent:
    """The workflow paused for an external async operation."""

    thread_id: str
    """Thread identifier for resuming."""

    workflow_name: str
    """Name of the interrupted workflow."""

    pending: Dict[str, Any] = field(default_factory=dict)
    """Metadata about the pending async operation."""

    step_id: str = ""
    """The step that triggered the async interrupt."""


@dataclass
class OutOfScopeEvent:
    """The user's query was detected as out of scope."""

    thread_id: str
    """Thread identifier for resuming."""

    workflow_name: str
    """Name of the interrupted workflow."""

    reason: str = "User query is out of scope"
    """Reason the query was classified as out of scope."""

    user_message: str = ""
    """The user message that was out of scope."""


@dataclass
class FollowUpEvent:
    """The workflow completed and is in follow-up mode, waiting for user Q&A."""

    prompt: str
    """The outcome message or follow-up Q&A answer."""

    options: List[Dict[str, Any]] = field(default_factory=list)
    """Selectable options (each has ``text`` and optional ``subtext``)."""

    is_selectable: bool = False
    """True if the user must pick from options."""


@dataclass
class FollowUpOutOfScopeEvent:
    """The follow-up agent detected the user's query as out of scope."""

    thread_id: str
    """Thread identifier for resuming."""

    workflow_name: str
    """Name of the interrupted workflow."""

    reason: str = ""
    """Reason the follow-up query was classified as out of scope."""

    user_message: str = ""
    """The user message that was out of scope."""


@dataclass
class CompleteEvent:
    """The workflow reached a terminal outcome."""

    message: str
    """Final outcome message."""

    options: List[Dict[str, Any]] = field(default_factory=list)
    """Optional outcome options."""

    is_selectable: bool = False
    """Whether the user must select from options."""


@dataclass
class RedirectEvent:
    """The workflow completed with a redirect to another workflow."""

    message: str
    """Outcome message for the user."""

    redirect_to: str
    """Name of the workflow to redirect to."""

    thread_id: str
    """Thread identifier to carry over."""

    workflow_name: str
    """Name of the workflow that issued the redirect."""

    options: List[Dict[str, Any]] = field(default_factory=list)
    """Optional outcome options."""

    is_selectable: bool = False
    """Whether the user must select from options."""


@dataclass
class ErrorEvent:
    """An error occurred during streaming."""

    error: str
    """Human-readable error description."""


WorkflowEvent = Union[
    NodeCompleteEvent,
    CustomEvent,
    InterruptEvent,
    AsyncInterruptEvent,
    OutOfScopeEvent,
    FollowUpEvent,
    FollowUpOutOfScopeEvent,
    CompleteEvent,
    RedirectEvent,
    ErrorEvent,
]
"""Union of all event types yielded by ``WorkflowStreamer.stream()``."""
