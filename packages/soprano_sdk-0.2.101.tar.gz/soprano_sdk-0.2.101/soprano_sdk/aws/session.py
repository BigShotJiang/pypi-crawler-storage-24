import boto3
from typing import Dict, Optional


class SessionRegistry:
    """Registry of named boto3 Sessions, keyed by AWS access key ID.

    Sessions are created once and reused. When no explicit credentials are
    provided, the session falls back to the default boto3 credential chain
    (environment variables, instance profile, etc.) and is stored under the
    ``"default"`` key.
    """

    _sessions: Dict[str, boto3.Session] = {}

    @classmethod
    def get_or_create(
        cls,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        region_name: Optional[str] = None,
        aws_session_token: Optional[str] = None,
    ) -> boto3.Session:
        session_kwargs: Dict[str, str] = {}
        if aws_access_key_id:
            session_kwargs["aws_access_key_id"] = aws_access_key_id
        if aws_secret_access_key:
            session_kwargs["aws_secret_access_key"] = aws_secret_access_key
        if region_name:
            session_kwargs["region_name"] = region_name
        if aws_session_token:
            session_kwargs["aws_session_token"] = aws_session_token

        # Temporary credentials (STS token) expire — never cache them
        if aws_session_token:
            return boto3.Session(**session_kwargs)

        session_key = aws_access_key_id or "default"
        if session_key not in cls._sessions:
            cls._sessions[session_key] = boto3.Session(**session_kwargs)

        elif aws_session_token:
            session = cls._sessions[session_key]
            session_credentials = session.get_credentials()
            if aws_session_token and session_credentials.token != aws_session_token:
                cls._sessions[session_key] = boto3.Session(**session_kwargs)
            elif region_name and session.region_name != region_name:
                cls._sessions[session_key] = boto3.Session(**session_kwargs)

        return cls._sessions[session_key]

    @classmethod
    def get(cls, aws_access_key_id: Optional[str] = None) -> Optional[boto3.Session]:
        """Return an existing session by key, or None if not found."""
        return cls._sessions.get(aws_access_key_id or "default")

    @classmethod
    def clear(cls) -> None:
        """Remove all cached sessions (useful for testing)."""
        cls._sessions.clear()
