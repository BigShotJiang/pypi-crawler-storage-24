from typing import Any, Dict, List, Optional, Type, Literal
from pydantic import BaseModel, Field, create_model
from ..core.constants import build_option_guidelines


class FollowUpOutput(BaseModel):
    """Structured output model for the follow-up agent."""

    bot_response: Optional[str] = Field(
        default=None,
        description=(
            "Your conversational reply to the user. "
            "May be null or omitted when a dispatch signal (intent_change, out_of_scope, restart) "
            "carries the intent and no additional user-facing text is needed."
        ),
    )
    options: Optional[List[Dict[str, Optional[str]]]] = Field(
        default=None,
        description=(
            "Selectable choices to present alongside bot_response. "
            "Each item must have 'text' (str) and 'subtext' (str or null). "
            "Null when no options are applicable."
        ),
    )
    is_selectable: Optional[bool] = Field(
        default=None,
        description=(
            "True if the user must pick from the provided options rather than type freely. "
            "Null when options is null."
        ),
    )
    intent_change: Optional[str] = Field(
        default=None,
        description=(
            "Node ID of the collector the user wants to revisit to update previously entered data. "
            "Set this when the user wants to change an earlier answer; null otherwise."
        ),
    )
    out_of_scope: Optional[str] = Field(
        default=None,
        description=(
            "Brief reason string when the user's request falls outside the scope of this workflow. "
            "Non-empty string triggers a FOLLOW_UP_OUT_OF_SCOPE interrupt; null otherwise."
        ),
    )
    restart: Optional[bool] = Field(
        default=False,
        description=(
            "True if the user wants to restart the entire workflow from the beginning, "
            "clearing all collected data. Null or false means no restart."
        ),
    )


TYPE_MAP = {
    "text": str,
    "number": int,
    "double": float,
    "boolean": bool,
    "list": list,
    "dict": dict,
    "literal": Literal,
}


def create_structured_output_model(
    fields: List[Dict[str, Any]],
    model_name: str = "StructuredOutput",
    needs_intent_change: bool = False,
    enable_out_of_scope: bool = False,
    bot_response_rules: Optional[str] = None,
) -> Type[BaseModel]:
    if not fields:
        raise ValueError("At least one field definition is required")

    required_fields = {field_def.get("name") for field_def in fields if field_def.get("required", True)}
    bot_response_description_suffix = ""
    if required_fields:
        bot_response_description_suffix = f"IMPORTANT: This value Must always be set as null if {required_fields} {'is' if len(required_fields) == 1 else 'are'} populated."

    if bot_response_rules:
        bot_response_description = f"Rules: {bot_response_rules} {bot_response_description_suffix}"
    else:
        bot_response_description = f"This value set only when the conditions given under BOT_RESPONSE_RULES section are met. {bot_response_description_suffix}"

    field_definitions = {
        "bot_response": (Optional[str], Field(None, description=bot_response_description))}

    if needs_intent_change:
        field_definitions["intent_change"] = (Optional[str], Field(None, description="node name for handling new intent"))

    if enable_out_of_scope:
        field_definitions["out_of_scope"] = (Optional[str], Field(None, description="Brief description of what the user is trying to do if their query is completely outside the scope of this workflow"))

    field_definitions["options"] = (Optional[List[Dict[str, Any]]], Field(None, description=build_option_guidelines()))
    field_definitions["is_selectable"] = (Optional[bool], Field(None, description="Set to true if user must select from the provided options, false if user can also type freely."))
    
    for field_def in fields:
        field_name = field_def.get("name")
        field_type = field_def.get("type")
        field_description = field_def.get("description", "")
        
        if not field_name:
            raise ValueError("Field definition missing 'name'")
        
        if not field_type:
            raise ValueError(f"Field '{field_name}' missing 'type'")
        
        python_type = TYPE_MAP.get(field_type)
        if python_type is None:
            raise ValueError(
                f"Unknown type '{field_type}' for field '{field_name}'. "
                f"Supported types: {list(TYPE_MAP.keys())}"
            )

        args = field_def.get("args")
        if args is not None:
            python_type = python_type[tuple(args)]

        # Make ALL fields optional to allow partial LLM outputs (e.g., clarifying questions)
        # We enforce "required" fields in collect_input.py
        python_type = Optional[python_type]
        field_definitions[field_name] = (
            python_type,
            Field(default=None, description=field_description)
        )
    
    try:
        model = create_model(model_name, **field_definitions)
        return model
    except Exception as e:
        raise ValueError(f"Failed to create model '{model_name}': {e}")


def validate_field_definitions(fields: List[Dict[str, Any]]) -> bool:
    if not isinstance(fields, list):
        raise ValueError("Field definitions must be a list")
    
    if not fields:
        raise ValueError("At least one field definition is required")
    
    field_names = set()
    
    for i, field_def in enumerate(fields):
        if not isinstance(field_def, dict):
            raise ValueError(f"Field definition at index {i} must be a dictionary")
        
        required_keys = ["name", "type", "description"]
        for key in required_keys:
            if key not in field_def:
                raise ValueError(f"Field definition at index {i} missing required key '{key}'")
        
        field_name = field_def["name"]
        
        if field_name in field_names:
            raise ValueError(f"Duplicate field name '{field_name}' found")
        field_names.add(field_name)
        
        field_type = field_def["type"]
        if field_type not in TYPE_MAP:
            raise ValueError(
                f"Invalid type '{field_type}' for field '{field_name}'. "
                f"Supported types: {list(TYPE_MAP.keys())}"
            )

        if field_type == "literal":
            args = field_def.get("args")
            if not args or not isinstance(args, list):
                raise ValueError(f"Field '{field_name}' of type 'literal' requires a non-empty 'args' list")
    
    return True
