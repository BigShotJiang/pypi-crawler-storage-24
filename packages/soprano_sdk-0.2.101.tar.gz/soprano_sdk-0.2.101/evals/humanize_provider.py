"""Promptfoo Python provider that mirrors _humanize_message LLM call logic.

Reconstructs the same system prompt, user query, and structured output call
that soprano_sdk.core.engine.WorkflowEngine._humanize_message builds,
without needing to instantiate a full WorkflowEngine.

Constants are loaded directly from soprano_sdk/core/constants.py via importlib
(bypassing soprano_sdk/__init__.py) to avoid pulling in heavy dependencies
like litellm that are not installed in the promptfoo Python environment.
"""

import importlib.util as _ilu
import json
import os
from pathlib import Path
from typing import List, Optional

from langchain_openai import ChatOpenAI
from pydantic import BaseModel, SecretStr

# ---------------------------------------------------------------------------
# Load soprano_sdk/core/constants.py directly, bypassing __init__.py so that
# heavy transitive dependencies (litellm, crewai, …) are never imported.
# ---------------------------------------------------------------------------
_constants_path = Path(__file__).resolve().parent.parent / "soprano_sdk" / "core" / "constants.py"
_spec = _ilu.spec_from_file_location("_soprano_constants", _constants_path)
_constants = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(_constants)

DEFAULT_HUMANIZATION_SYSTEM_PROMPT = _constants.DEFAULT_HUMANIZATION_SYSTEM_PROMPT
HUMANIZATION_URL_PRESERVATION_EXAMPLES = _constants.HUMANIZATION_URL_PRESERVATION_EXAMPLES
DEFAULT_LOCALIZATION_INSTRUCTIONS = _constants.DEFAULT_LOCALIZATION_INSTRUCTIONS
build_humanization_options_guidance = _constants.build_humanization_options_guidance
MAX_OPTION_TEXT_LENGTH = _constants.MAX_OPTION_TEXT_LENGTH
DEFAULT_OPTION_CHAR_LIMIT_ENABLED = _constants.DEFAULT_OPTION_CHAR_LIMIT_ENABLED


# OpenAI strict structured output rejects Dict[str, Any] (needs additionalProperties: false).
# Define a concrete model matching the option shape used by the SDK.
class OptionItem(BaseModel):
    text: str
    subtext: str


class EvalHumanizedResponse(BaseModel):
    message: str
    options: Optional[List[OptionItem]] = None
    is_selectable: Optional[bool] = None


def call_api(prompt: str, options: dict, context: dict) -> dict:
    config = options.get("config", {})
    vars_ = context.get("vars", {})

    model_name = config.get("model_name", "gpt-4o-mini")
    api_key = config.get("api_key") or os.environ.get("OPENROUTER_API_KEY", "") or os.environ.get("OPENAI_API_KEY", "")
    base_url = config.get("base_url")

    reference_message = vars_["reference_message"]
    opt = vars_.get("options")
    is_selectable = vars_.get("is_selectable")
    conversation_history = vars_.get("conversation_history")
    language = vars_.get("language")
    script = vars_.get("script")
    custom_instructions = vars_.get("custom_instructions")
    option_char_limit = vars_.get("option_char_limit")

    # Parse JSON strings (promptfoo passes vars as strings)
    if isinstance(opt, str):
        opt = json.loads(opt) if opt else None
    if isinstance(conversation_history, str):
        conversation_history = json.loads(conversation_history) if conversation_history else None
    if isinstance(is_selectable, str):
        is_selectable = is_selectable.lower() == "true"
    if isinstance(option_char_limit, str):
        option_char_limit = option_char_limit.lower() != "false"
    if option_char_limit is None:
        option_char_limit = DEFAULT_OPTION_CHAR_LIMIT_ENABLED

    # --- Build system prompt (mirrors engine.py) ---
    system_prompt = custom_instructions if custom_instructions else DEFAULT_HUMANIZATION_SYSTEM_PROMPT
    max_chars = MAX_OPTION_TEXT_LENGTH if option_char_limit else None
    system_prompt += build_humanization_options_guidance(max_chars=max_chars)
    system_prompt += HUMANIZATION_URL_PRESERVATION_EXAMPLES

    if language:
        localization_prompt = DEFAULT_LOCALIZATION_INSTRUCTIONS.format(
            language=language,
            script=script or "the appropriate script",
        )
        system_prompt = f"{localization_prompt}\n\n{system_prompt}"

    # --- Build user query (mirrors engine.py) ---
    user_query = (
        f"Humanize this message based on the prior context:\n\n"
        f"```\n{reference_message}\n```"
    )
    if opt:
        user_query += f"\n\nSelectable options: {opt}"
        user_query += f"\nMust select from options: {is_selectable}"
        char_limit_clause = (
            f" If any option text exceeds {max_chars} characters, shorten it to fit while keeping the meaning clear."
            if max_chars else ""
        )
        user_query += (
            f"\n\nReturn these options in your structured response with the same is_selectable value. "
            f"Do NOT add or remove options.{char_limit_clause}"
        )
    else:
        user_query += (
            "\n\nOnly include options if they are explicitly present "
            "in the reference message above."
        )

    # --- Assemble messages (mirrors engine.py) ---
    messages = [{"role": "system", "content": system_prompt}]
    if conversation_history:
        messages.extend(conversation_history)
    messages.append({"role": "user", "content": user_query})

    # --- Call LLM with structured output (mirrors get_model + invoke) ---
    llm_kwargs = {"model": model_name, "api_key": SecretStr(api_key)}
    if base_url:
        llm_kwargs["base_url"] = base_url

    llm = ChatOpenAI(**llm_kwargs)
    try:
        structured_llm = llm.with_structured_output(EvalHumanizedResponse)
        humanized: EvalHumanizedResponse = structured_llm.invoke(messages)
    except Exception:
        # Fallback: JSON mode for models that don't support function-calling structured output
        structured_llm = llm.with_structured_output(EvalHumanizedResponse, method="json_mode")
        humanized: EvalHumanizedResponse = structured_llm.invoke(messages)

    # Convert OptionItem models back to dicts for JSON output
    options_out = None
    if humanized.options is not None:
        options_out = [{"text": o.text, "subtext": o.subtext} for o in humanized.options]

    return {
        "output": json.dumps({
            "message": humanized.message,
            "options": options_out,
            "is_selectable": humanized.is_selectable,
        }, ensure_ascii=False),
    }
