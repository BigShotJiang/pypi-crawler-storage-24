from setuptools import setup, find_packages

setup(
    name='islamlib',
    version='0.0.06',
    packages=find_packages(),
    package_data={
        "islamlib": ["data/**/*.json", "data/*.json"],
    },
    include_package_data=True
)