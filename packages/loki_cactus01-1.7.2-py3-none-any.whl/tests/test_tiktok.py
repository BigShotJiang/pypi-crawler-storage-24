import asyncio
async def async_func():
    from loki.scrapers.tiktok import TikTok
    scraper = await TikTok.create()
    res = await scraper.get_profile_data("jakesing_")
    await scraper.close()
    return res

def test_get_profile():
    result = asyncio.run(async_func())
    print(result)