from __future__ import annotations

import re
from typing import Dict, Optional, Tuple
import logging
from bs4 import BeautifulSoup, Tag
from playwright.async_api import (
    async_playwright,
    Page,
    Browser,
    BrowserContext,
    Playwright,
)
from urllib.parse import urlencode

# 新增导入 stealth
from playwright_stealth import Stealth

from loki.common.profile import Profile, ProfileManager
from loki.scrapers.base import RequestMixin

logger = logging.getLogger('loki')

_CODE_CMP_RE = re.compile(r"([A-Z]{2,10})[-_ ]*(\d{2,6})", re.I)


class JavDB(RequestMixin):
    PLATFORM = "JavDB"

    def __init__(
            self,
            *,
            profile: Profile,
            auto_load_cookies: bool = True,
    ) -> None:
        super().__init__(profile=profile, auto_load_cookies=auto_load_cookies)
        self._base = 'https://javdb.com'
        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None

    @classmethod
    async def create(
            cls,
            *,
            profile: Profile | None = None,
            profile_name: str = "default",
            profile_manager: ProfileManager | None = None,
            auto_load_cookies: bool = True,
            headless: bool = True,
    ) -> "JavDB":
        if profile is None:
            manager = profile_manager or ProfileManager()
            profile = manager.get(cls.PLATFORM, profile_name)

        self = cls(profile=profile, auto_load_cookies=auto_load_cookies)
        self._playwright = await async_playwright().start()

        # 加强 launch 参数，减少被检测概率
        self._browser = await self._playwright.chromium.launch(
            headless=headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-infobars",
                "--window-size=1280,800",
                "--start-maximized",
                "--disable-background-timer-throttling",
                "--disable-renderer-backgrounding",
            ],
        )
        return self

    async def _new_page(self) -> Tuple[Optional[BrowserContext], Optional[Page]]:
        if self._browser is None:
            logger.error("Browser 未初始化：请先使用 await JavDB.create()")
            return None, None

        context: Optional[BrowserContext] = None
        try:
            context = await self._browser.new_context(
                viewport={"width": 1280, "height": 800},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
                locale="zh-CN",
                timezone_id="Asia/Shanghai",
                # 额外 headers，模拟真实浏览器
                extra_http_headers={
                    "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="99", "Google Chrome";v="128"',
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": '"Windows"',
                },
            )

            # 关键：应用 stealth 到 context（所有 page 自动生效）
            stealth = Stealth()  # 可传入 StealthConfig 自定义，但默认已很强
            await stealth.apply_stealth_async(context)
            logger.debug("已应用 playwright-stealth 到 context")

            if self.profile:
                cookies = self.profile.build_playwright_cookies(base_url=self._base)
                if cookies:
                    await context.add_cookies(cookies)

            page = await context.new_page()
            return context, page
        except Exception:
            logger.exception("创建页面失败")
            if context is not None:
                await context.close()
            return None, None

    async def _get_soup(self, url: str, params: Dict | None = None) -> BeautifulSoup | None:
        context, page = await self._new_page()
        if context is None or page is None:
            return None

        query = urlencode(params or {})
        target_url = f"{url}?{query}" if query else url
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            # 等待网络空闲或特定元素（视 javdb 页面结构）
            await page.wait_for_load_state("networkidle", timeout=15000)
            html = await page.content()
            return BeautifulSoup(html, 'html.parser')
        except Exception:
            logger.exception("请求异常 %s", url)
            return None
        finally:
            await context.close()  # 保持原逻辑：用完即关

    async def close(self):
        try:
            if self._browser is not None:
                await self._browser.close()
        finally:
            if self._playwright is not None:
                await self._playwright.stop()

        self._browser = None
        self._playwright = None

    def _norm_code(self, s: str | None) -> str | None:
        if not s:
            return None
        s = str(s).upper().replace('.', '-').replace('_', '-').replace(' ', '-')
        m = _CODE_CMP_RE.search(s)
        if not m:
            return None
        prefix = m.group(1).upper()
        digits = (m.group(2) or '').lstrip('0') or '0'
        return f"{prefix}-{digits}"

    def _abs_url(self, href: str | None) -> str:
        h = (href or "").strip()
        if not h:
            return ""
        if h.startswith("http://") or h.startswith("https://"):
            return h
        if not h.startswith("/"):
            h = "/" + h
        return self._base + h

    async def search(self, code: str, has_magnet: bool = True, no_subtitle: bool=True, no_uncensored: bool=True) -> Dict:
        search_code = self._norm_code(code) or code
        result = {
            'code': search_code
        }

        url = f'https://javdb.com/search'
        params = {
            'q': search_code,
            'f': 'all'
        }
        if has_magnet:
            params['f'] = 'download'

        soup = await self._get_soup(url, params=params)
        if not soup:
            return result

        target_url = ''
        items = soup.select(".movie-list .item")
        for it in items:
            title_el = it.select_one("a .video-title strong")
            link_el = it.select_one("a[href]")
            if not title_el or not link_el:
                continue
            found_text = title_el.get_text(strip=True)
            found_norm = self._norm_code(found_text)
            if found_norm and found_norm == search_code:
                href = link_el.get("href", "")
                if isinstance(href, str):
                    target_url = self._abs_url(href.strip())
                    break

        if target_url:
            soup = await self._get_soup(target_url)
            if not soup:
                return result

            actress_a = soup.select_one('.movie-panel-info a:has(+ .female)')
            if isinstance(actress_a, Tag):
                result['actress_name'] = actress_a.text

            items = soup.select("#magnets-content .item")
            best_magnet = ''
            best_size_gib = -1.0

            def size_from_meta(txt: str) -> float:
                s = txt.upper()
                m = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*(GB|G|MB|M)", s)
                if not m:
                    return 0.0
                val = float(m.group(1))
                unit = m.group(2)
                if unit.startswith("G"):
                    return val
                return val / 1024.0

            for it in items:
                a = it.select_one("a[href^='magnet:']")
                name_el = it.select_one('span.name')
                if isinstance(name_el, Tag):
                    if no_uncensored and ('-uc' in name_el.text.lower() or '无码' in name_el.text.lower() or '-u.' in name_el.text.lower()):
                        continue
                    if no_subtitle and '字幕' in name_el.text.lower():
                        continue

                has_subtitle = False
                tags_el = it.select('.tags span')
                for tag_el in tags_el:
                    if isinstance(tag_el, Tag):
                        if '字幕' in tag_el.text.strip():
                            has_subtitle = True
                            break
                if no_subtitle and has_subtitle:
                    continue

                meta_el = it.select_one(".meta")
                if not a or not meta_el:
                    continue
                href_str = a.get("href", "")
                if not isinstance(href_str, str):
                    continue
                magnet = href_str.strip()
                meta = meta_el.get_text(strip=True)
                sz = size_from_meta(meta)
                if sz > best_size_gib:
                    best_size_gib = sz
                    best_magnet = str(magnet)

            # 尝试在评论区找
            if not best_magnet:
                review_html = await self._get_soup(f"{target_url}/reviews/lastest")
                if review_html:
                    for content in review_html.select(".review-items .review-item .content"):
                        if content:
                            text = content.get_text()
                            if 'magnet:' in text:
                                match = re.search(r"(magnet:\?xt=urn:[a-z0-9]+:[a-zA-Z0-9]{32,})", text)
                                if match:
                                    best_magnet = str(match.group(1))
                                    break
                            elif 'ed2k:' in text:
                                match = re.search(r"(ed2k://\|file\|[^ ]+)", text)
                                if match:
                                    best_magnet = str(match.group(1))
                                    break

            result['magnet'] = best_magnet

        return result

    async def get_profile_soup(self, actor_id: str) -> BeautifulSoup | None:
        url = f"{self._base}/actors/{actor_id}"
        soup = await self._get_soup(url)
        if not soup:
            return None
        return soup