"""Leaky Bucket rate limiter.

Processes requests at a constant rate. Incoming requests queue up;
if the queue is full, the request is rejected.

Unlike token bucket, leaky bucket smooths output rate — good for
preventing bursts rather than allowing them.

Uses a counter + last-drain-time model to avoid float precision issues
between rapid calls.
"""

import threading
import time


class LeakyBucket:
    """Leaky bucket rate limiter.

    Args:
        rate: Requests processed per second (leak rate).
        capacity: Maximum queue size (burst capacity).
    """

    def __init__(self, rate: float, capacity: int):
        if rate <= 0:
            raise ValueError("rate must be > 0")
        if capacity < 1:
            raise ValueError("capacity must be >= 1")
        self.rate = rate
        self.capacity = capacity
        self._state: dict[str, tuple[float, float]] = {}  # key -> (level, last_leak_time)
        self._total_allowed = 0
        self._total_rejected = 0
        self._lock = threading.Lock()

    def _default_key(self) -> str:
        return "__default__"

    def _leak(self, key: str) -> float:
        """Leak out requests based on elapsed time. Returns current level."""
        now = time.monotonic()
        if key not in self._state:
            self._state[key] = (0.0, now)
            return 0.0
        level, last_time = self._state[key]
        elapsed = now - last_time
        # Only leak if enough time has passed for at least 1 unit
        if elapsed * self.rate >= 1.0:
            leaked = elapsed * self.rate
            new_level = max(0.0, level - leaked)
            self._state[key] = (new_level, now)
        return self._state[key][0]

    def allow(self, key: str = "") -> bool:
        """Try to add a request to the bucket."""
        key = key or self._default_key()
        with self._lock:
            level = self._leak(key)
            if level < self.capacity:
                self._state[key] = (level + 1.0, self._state[key][1])
                self._total_allowed += 1
                return True
            self._total_rejected += 1
            return False

    def consume(self, key: str = "") -> bool:
        """Alias for allow()."""
        return self.allow(key)

    def retry_after(self, key: str = "") -> float:
        """Seconds until one slot is available."""
        key = key or self._default_key()
        with self._lock:
            level = self._leak(key)
            if level < self.capacity:
                return 0.0
            return 1.0 / self.rate

    @property
    def level(self, key: str = "") -> float:
        """Current queue level for the given key."""
        key = key or self._default_key()
        with self._lock:
            return self._leak(key)

    def stats(self, key: str = "") -> dict:
        key = key or self._default_key()
        with self._lock:
            level = self._leak(key)
            return {
                "current_level": round(level, 2),
                "capacity": self.capacity,
                "rate": self.rate,
                "calls_allowed": self._total_allowed,
                "calls_rejected": self._total_rejected,
            }
