"""Token Bucket rate limiter.

Tokens are added at a constant rate. Each consume removes one token.
Bursts up to capacity are allowed if tokens are available.

Mathematical model:
    refill(t) = rate * elapsed_since_last_refill
    tokens = min(capacity, current_tokens + refill)
"""

import threading
import time


class TokenBucket:
    """Token bucket rate limiter.

    Args:
        rate: Tokens added per second.
        capacity: Maximum tokens (burst size).
    """

    def __init__(self, rate: float, capacity: int):
        if rate <= 0:
            raise ValueError("rate must be > 0")
        if capacity < 1:
            raise ValueError("capacity must be >= 1")
        self.rate = rate
        self.capacity = capacity
        self._tokens = float(capacity)
        self._last_refill = time.monotonic()
        self._total_allowed = 0
        self._total_rejected = 0
        self._lock = threading.Lock()

    def _refill(self):
        now = time.monotonic()
        elapsed = now - self._last_refill
        if elapsed > 0:
            self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)
            self._last_refill = now

    def allow(self) -> bool:
        """Try to consume one token. Returns True if allowed."""
        with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                self._total_allowed += 1
                return True
            self._total_rejected += 1
            return False

    def consume(self, tokens: int = 1) -> bool:
        """Try to consume multiple tokens at once."""
        if tokens < 1:
            raise ValueError("tokens must be >= 1")
        with self._lock:
            self._refill()
            if self._tokens >= tokens:
                self._tokens -= tokens
                self._total_allowed += tokens
                return True
            self._total_rejected += 1
            return False

    def retry_after(self) -> float:
        """Seconds until one token is available. Returns 0 if available now."""
        with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                return 0.0
            return (1.0 - self._tokens) / self.rate

    @property
    def available(self) -> float:
        """Current number of available tokens."""
        with self._lock:
            self._refill()
            return self._tokens

    def stats(self) -> dict:
        with self._lock:
            self._refill()
            return {
                "available_tokens": round(self._tokens, 2),
                "capacity": self.capacity,
                "rate": self.rate,
                "calls_allowed": self._total_allowed,
                "calls_rejected": self._total_rejected,
            }
