"""Fixed Window rate limiter.

Divides time into fixed-width windows. Counter resets at each window boundary.
Simple and memory-efficient, but allows burst at window boundaries
(up to 2x the limit in the worst case).

Time complexity: O(1)
Space complexity: O(k) where k = number of unique keys
"""

import threading
import time
import math


class FixedWindow:
    """Fixed window rate limiter.

    Args:
        max_calls: Maximum calls allowed per window.
        window_seconds: Length of each window in seconds.
    """

    def __init__(self, max_calls: int, window_seconds: float):
        if max_calls < 1:
            raise ValueError("max_calls must be >= 1")
        if window_seconds <= 0:
            raise ValueError("window_seconds must be > 0")
        self.max_calls = max_calls
        self.window_seconds = window_seconds
        self._windows: dict[str, tuple[int, float]] = {}  # key -> (count, window_start)
        self._total_allowed = 0
        self._total_rejected = 0
        self._lock = threading.Lock()

    def _window_start(self) -> float:
        return math.floor(time.monotonic() / self.window_seconds) * self.window_seconds

    def _default_key(self) -> str:
        return "__default__"

    def allow(self, key: str = "") -> bool:
        """Check if a call is allowed for the given key."""
        key = key or self._default_key()
        now_window = self._window_start()
        with self._lock:
            if key not in self._windows or self._windows[key][1] != now_window:
                self._windows[key] = (0, now_window)
            count, _ = self._windows[key]
            if count < self.max_calls:
                self._windows[key] = (count + 1, now_window)
                self._total_allowed += 1
                return True
            self._total_rejected += 1
            return False

    def consume(self, key: str = "") -> bool:
        """Alias for allow()."""
        return self.allow(key)

    def retry_after(self, key: str = "") -> float:
        """Seconds until the next window starts."""
        key = key or self._default_key()
        with self._lock:
            if key not in self._windows:
                return 0.0
            _, window_start = self._windows[key]
            now_window = self._window_start()
            if window_start != now_window:
                return 0.0
            elapsed = time.monotonic() - window_start
            return max(0.0, self.window_seconds - elapsed)

    @property
    def count(self, key: str = "") -> int:
        """Current count in the active window."""
        key = key or self._default_key()
        with self._lock:
            now_window = self._window_start()
            if key not in self._windows or self._windows[key][1] != now_window:
                return 0
            return self._windows[key][0]

    def stats(self, key: str = "") -> dict:
        key = key or self._default_key()
        with self._lock:
            now_window = self._window_start()
            if key not in self._windows or self._windows[key][1] != now_window:
                return {
                    "current_calls": 0,
                    "max_calls": self.max_calls,
                    "window_seconds": self.window_seconds,
                    "calls_allowed": self._total_allowed,
                    "calls_rejected": self._total_rejected,
                }
            count, _ = self._windows[key]
            return {
                "current_calls": count,
                "max_calls": self.max_calls,
                "window_seconds": self.window_seconds,
                "calls_allowed": self._total_allowed,
                "calls_rejected": self._total_rejected,
            }
