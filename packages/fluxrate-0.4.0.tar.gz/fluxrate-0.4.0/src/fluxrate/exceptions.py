"""Custom exceptions."""


class RateLimitExceeded(Exception):
    """Raised when a rate limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: float | None = None):
        super().__init__(message)
        self.retry_after = retry_after


class TimeoutExceeded(Exception):
    """Raised when waiting for a rate limit slot times out."""

    def __init__(self, message: str = "Timeout waiting for rate limit"):
        super().__init__(message)
