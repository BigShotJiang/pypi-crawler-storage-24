"""Sliding Window rate limiter.

Uses a log of timestamps with cleanup to implement true sliding window.
Each call records a timestamp; calls older than the window are pruned.

Time complexity: O(n) for allow() with periodic cleanup to O(1) amortized.
Space complexity: O(k) where k = number of calls in the window.
"""

import bisect
import threading
import time


class SlidingWindow:
    """Sliding window rate limiter using timestamp log.

    Args:
        max_calls: Maximum calls allowed in the window.
        window_seconds: Length of the sliding window in seconds.
    """

    def __init__(self, max_calls: int, window_seconds: float):
        if max_calls < 1:
            raise ValueError("max_calls must be >= 1")
        if window_seconds <= 0:
            raise ValueError("window_seconds must be > 0")
        self.max_calls = max_calls
        self.window_seconds = window_seconds
        self._calls: dict[str, list[float]] = {}
        self._total_allowed = 0
        self._total_rejected = 0
        self._lock = threading.Lock()

    def _prune(self, timestamps: list[float]) -> list[float]:
        cutoff = time.monotonic() - self.window_seconds
        # bisect_right finds first index > cutoff; everything before is expired
        idx = bisect.bisect_right(timestamps, cutoff)
        return timestamps[idx:]

    def _default_key(self) -> str:
        return "__default__"

    def allow(self, key: str = "") -> bool:
        """Check if a call is allowed for the given key."""
        key = key or self._default_key()
        now = time.monotonic()
        with self._lock:
            if key not in self._calls:
                self._calls[key] = []
            timestamps = self._prune(self._calls[key])
            if len(timestamps) < self.max_calls:
                bisect.insort(timestamps, now)
                self._calls[key] = timestamps
                self._total_allowed += 1
                return True
            self._calls[key] = timestamps
            self._total_rejected += 1
            return False

    def consume(self, key: str = "") -> bool:
        """Alias for allow()."""
        return self.allow(key)

    def retry_after(self, key: str = "") -> float:
        """Seconds until next call is allowed for the given key."""
        key = key or self._default_key()
        with self._lock:
            timestamps = self._calls.get(key, [])
            timestamps = self._prune(timestamps)
            if len(timestamps) < self.max_calls:
                return 0.0
            # Oldest timestamp determines when the window slides
            oldest = timestamps[0]
            wait = (oldest + self.window_seconds) - time.monotonic()
            return max(0.0, wait)

    @property
    def count(self, key: str = "") -> int:
        """Current call count in the window for the given key."""
        key = key or self._default_key()
        with self._lock:
            timestamps = self._prune(self._calls.get(key, []))
            return len(timestamps)

    def stats(self, key: str = "") -> dict:
        key = key or self._default_key()
        with self._lock:
            timestamps = self._prune(self._calls.get(key, []))
            return {
                "current_calls": len(timestamps),
                "max_calls": self.max_calls,
                "window_seconds": self.window_seconds,
                "calls_allowed": self._total_allowed,
                "calls_rejected": self._total_rejected,
            }
