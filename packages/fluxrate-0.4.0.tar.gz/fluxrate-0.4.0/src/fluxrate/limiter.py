"""High-level RateLimiter — decorator, context manager, and manual check API."""

import functools
import threading
import time
from typing import Any, Callable, Optional

from fluxrate.token_bucket import TokenBucket
from fluxrate.sliding_window import SlidingWindow
from fluxrate.fixed_window import FixedWindow
from fluxrate.leaky_bucket import LeakyBucket
from fluxrate.exceptions import RateLimitExceeded, TimeoutExceeded


_ALGORITHM_MAP = {
    "token_bucket": TokenBucket,
    "sliding_window": SlidingWindow,
    "fixed_window": FixedWindow,
    "leaky_bucket": LeakyBucket,
}


class RateLimiter:
    """High-level rate limiter supporting multiple algorithms.

    Can be used as a decorator, context manager, or for manual checks.

    Args:
        calls: Maximum number of calls allowed in the period.
        period: Time window in seconds.
        algorithm: One of "token_bucket", "sliding_window", "fixed_window", "leaky_bucket".
            Default: "token_bucket".
        key_func: Optional callable to extract a key from function arguments.
            Useful for per-user/IP rate limiting. Receives (*args, **kwargs).
        burst: Burst capacity (token bucket / leaky bucket). Defaults to calls.
        raise_on_limit: If True, raise RateLimitExceeded. If False, return None
            from decorated functions.
        retry_after_header: If True, include Retry-After info in exceptions.

    Examples:
        >>> @RateLimiter(calls=10, period=60)
        ... def my_func(): return "ok"
        >>> my_func()  # works up to 10 times per 60 seconds

        >>> limiter = RateLimiter(calls=5, period=10)
        >>> if limiter.allow(): do_something()
    """

    def __init__(
        self,
        calls: int,
        period: float,
        algorithm: str = "token_bucket",
        key_func: Optional[Callable] = None,
        burst: Optional[int] = None,
        raise_on_limit: bool = True,
        retry_after_header: bool = True,
    ):
        if calls < 1:
            raise ValueError("calls must be >= 1")
        if period <= 0:
            raise ValueError("period must be > 0")
        if algorithm not in _ALGORITHM_MAP:
            raise ValueError(f"algorithm must be one of {list(_ALGORITHM_MAP.keys())}")

        self.calls = calls
        self.period = period
        self.algorithm_name = algorithm
        self.key_func = key_func
        self.raise_on_limit = raise_on_limit
        self.retry_after_header = retry_after_header
        self._default_key = "__global__"
        self._buckets: dict[str, Any] = {}
        self._lock = threading.Lock()

        # Pre-build the args for algorithm construction
        rate = calls / period
        capacity = burst if burst is not None else calls

        self._init_args = {
            "token_bucket": {"rate": rate, "capacity": capacity},
            "sliding_window": {"max_calls": calls, "window_seconds": period},
            "fixed_window": {"max_calls": calls, "window_seconds": period},
            "leaky_bucket": {"rate": rate, "capacity": capacity},
        }

    def _get_bucket(self, key: str):
        if key not in self._buckets:
            cls = _ALGORITHM_MAP[self.algorithm_name]
            self._buckets[key] = cls(**self._init_args[self.algorithm_name])
        return self._buckets[key]

    def _resolve_key(self, args: tuple = (), kwargs: dict = None) -> str:
        if self.key_func and (args or kwargs):
            return str(self.key_func(*args, **(kwargs or {})))
        return self._default_key

    def allow(self, *args, **kwargs) -> bool:
        """Check if a call is allowed. Does not block."""
        key = self._resolve_key(args, kwargs)
        with self._lock:
            bucket = self._get_bucket(key)
            return bucket.allow()

    def consume(self, *args, **kwargs) -> bool:
        """Alias for allow()."""
        return self.allow(*args, **kwargs)

    def wait(self, *args, **kwargs) -> None:
        """Block until a call is allowed."""
        key = self._resolve_key(args, kwargs)
        while True:
            with self._lock:
                bucket = self._get_bucket(key)
                if bucket.allow():
                    return
            time.sleep(0.05)

    def acquire(self, *args, timeout: float = 30.0, **kwargs):
        """Context manager to acquire a rate limit slot.

        Args:
            timeout: Max seconds to wait. Raises TimeoutExceeded if exceeded.
        """
        return _RateLimitContext(self, args, kwargs, timeout)

    def retry_after(self, *args, **kwargs) -> float:
        """Seconds until next call is allowed. Returns 0 if allowed now."""
        key = self._resolve_key(args, kwargs)
        with self._lock:
            bucket = self._get_bucket(key)
            remaining = getattr(bucket, "retry_after", None)
            if remaining is not None:
                return remaining()
            # Fallback: try allow and report period if blocked
            if bucket.allow():
                return 0.0
            return self.period

    def reset(self, key: Optional[str] = None) -> None:
        """Reset rate limit state for a key or all keys."""
        with self._lock:
            if key:
                self._buckets.pop(key, None)
            else:
                self._buckets.clear()

    def stats(self, key: Optional[str] = None) -> dict:
        """Get stats for a key or all keys."""
        with self._lock:
            if key:
                bucket = self._buckets.get(key)
                return bucket.stats() if bucket else {"calls_allowed": 0, "calls_total": 0}
            return {k: b.stats() for k, b in self._buckets.items()}

    # --- Decorator usage ---
    def __call__(self, func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            key = self._resolve_key(args, kwargs)
            if not self.allow(*args, **kwargs):
                if self.raise_on_limit:
                    retry = self.retry_after(*args, **kwargs)
                    raise RateLimitExceeded(
                        f"Rate limit exceeded for {func.__name__}",
                        retry_after=retry if self.retry_after_header else None,
                    )
                return None
            return func(*args, **kwargs)

        wrapper._rate_limiter = self
        return wrapper

    async def __acall__(self, func):
        """Async decorator support."""
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            key = self._resolve_key(args, kwargs)
            if not self.allow(*args, **kwargs):
                if self.raise_on_limit:
                    retry = self.retry_after(*args, **kwargs)
                    raise RateLimitExceeded(
                        f"Rate limit exceeded for {func.__name__}",
                        retry_after=retry if self.retry_after_header else None,
                    )
                return None
            return await func(*args, **kwargs)
        return wrapper


class _RateLimitContext:
    """Context manager for rate-limited code blocks."""

    def __init__(self, limiter: RateLimiter, args: tuple, kwargs: dict, timeout: float):
        self.limiter = limiter
        self.args = args
        self.kwargs = kwargs
        self.timeout = timeout
        self._start = None

    def __enter__(self):
        self._start = time.monotonic()
        key = self.limiter._resolve_key(self.args, self.kwargs)
        while True:
            elapsed = time.monotonic() - self._start
            if elapsed >= self.timeout:
                raise TimeoutExceeded(
                    f"Timed out waiting for rate limit slot after {self.timeout}s"
                )
            with self.limiter._lock:
                bucket = self.limiter._get_bucket(key)
                if bucket.allow():
                    return self
            remaining = self.timeout - (time.monotonic() - self._start)
            time.sleep(min(0.05, remaining / 2))

    def __exit__(self, *exc):
        return False
