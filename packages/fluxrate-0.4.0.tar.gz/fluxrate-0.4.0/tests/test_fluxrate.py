"""Comprehensive tests for fluxrate."""

import threading
import time
import pytest

from fluxrate import RateLimiter, TokenBucket, SlidingWindow, FixedWindow, LeakyBucket
from fluxrate.exceptions import RateLimitExceeded, TimeoutExceeded


# ─── Token Bucket ─────────────────────────────────────────────────

class TestTokenBucket:
    def test_basic_allow(self):
        b = TokenBucket(rate=10, capacity=5)
        for _ in range(5):
            assert b.allow() is True
        assert b.allow() is False

    def test_refill(self):
        b = TokenBucket(rate=100, capacity=3)
        assert b.allow() is True
        assert b.allow() is True
        assert b.allow() is True
        assert b.allow() is False
        time.sleep(0.05)
        # Should have refilled ~5 tokens, but capped at 3
        assert b.allow() is True

    def test_consume_multiple(self):
        b = TokenBucket(rate=10, capacity=10)
        assert b.consume(5) is True
        assert b.consume(5) is True
        assert b.consume(1) is False

    def test_retry_after(self):
        b = TokenBucket(rate=10, capacity=2)
        b.allow()
        b.allow()
        ra = b.retry_after()
        assert ra > 0
        assert ra <= 0.2

    def test_available(self):
        b = TokenBucket(rate=10, capacity=5)
        assert b.available == 5.0
        b.allow()
        assert b.available < 5.0

    def test_stats(self):
        b = TokenBucket(rate=10, capacity=5)
        b.allow()
        b.allow()
        b.allow()  # 3rd one fails after exhausting
        s = b.stats()
        assert s["capacity"] == 5
        assert s["calls_allowed"] >= 2

    def test_invalid_params(self):
        with pytest.raises(ValueError):
            TokenBucket(rate=0, capacity=5)
        with pytest.raises(ValueError):
            TokenBucket(rate=10, capacity=0)

    def test_consume_invalid_tokens(self):
        b = TokenBucket(rate=10, capacity=5)
        with pytest.raises(ValueError):
            b.consume(0)

    def test_thread_safety(self):
        b = TokenBucket(rate=1000, capacity=100)
        results = []
        def worker():
            for _ in range(50):
                results.append(b.allow())
        threads = [threading.Thread(target=worker) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        allowed = sum(results)
        assert allowed <= 100 + 10  # some refill during test


# ─── Sliding Window ───────────────────────────────────────────────

class TestSlidingWindow:
    def test_basic_allow(self):
        sw = SlidingWindow(max_calls=3, window_seconds=1.0)
        assert sw.allow() is True
        assert sw.allow() is True
        assert sw.allow() is True
        assert sw.allow() is False

    def test_window_expiry(self):
        sw = SlidingWindow(max_calls=2, window_seconds=0.1)
        assert sw.allow() is True
        assert sw.allow() is True
        assert sw.allow() is False
        time.sleep(0.15)
        assert sw.allow() is True

    def test_per_key(self):
        sw = SlidingWindow(max_calls=2, window_seconds=1.0)
        assert sw.allow("a") is True
        assert sw.allow("a") is True
        assert sw.allow("a") is False
        assert sw.allow("b") is True  # different key

    def test_retry_after(self):
        sw = SlidingWindow(max_calls=2, window_seconds=1.0)
        sw.allow()
        sw.allow()
        ra = sw.retry_after()
        assert ra > 0
        assert ra <= 1.0

    def test_count(self):
        sw = SlidingWindow(max_calls=5, window_seconds=1.0)
        assert sw.count == 0
        sw.allow()
        assert sw.count == 1

    def test_stats(self):
        sw = SlidingWindow(max_calls=3, window_seconds=1.0)
        sw.allow()
        s = sw.stats()
        assert s["max_calls"] == 3
        assert s["current_calls"] >= 1

    def test_invalid_params(self):
        with pytest.raises(ValueError):
            SlidingWindow(max_calls=0, window_seconds=1.0)
        with pytest.raises(ValueError):
            SlidingWindow(max_calls=5, window_seconds=0)

    def test_thread_safety(self):
        sw = SlidingWindow(max_calls=50, window_seconds=1.0)
        results = []
        def worker():
            for _ in range(20):
                results.append(sw.allow("shared"))
        threads = [threading.Thread(target=worker) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        allowed = sum(results)
        assert allowed <= 50


# ─── Fixed Window ────────────────────────────────────────────────

class TestFixedWindow:
    def test_basic_allow(self):
        fw = FixedWindow(max_calls=3, window_seconds=1.0)
        assert fw.allow() is True
        assert fw.allow() is True
        assert fw.allow() is True
        assert fw.allow() is False

    def test_window_reset(self):
        fw = FixedWindow(max_calls=2, window_seconds=0.1)
        assert fw.allow() is True
        assert fw.allow() is True
        assert fw.allow() is False
        time.sleep(0.15)
        assert fw.allow() is True

    def test_per_key(self):
        fw = FixedWindow(max_calls=2, window_seconds=1.0)
        assert fw.allow("x") is True
        assert fw.allow("x") is True
        assert fw.allow("x") is False
        assert fw.allow("y") is True

    def test_retry_after(self):
        fw = FixedWindow(max_calls=2, window_seconds=1.0)
        fw.allow()
        fw.allow()
        ra = fw.retry_after()
        assert ra >= 0
        assert ra <= 1.0

    def test_count(self):
        fw = FixedWindow(max_calls=5, window_seconds=1.0)
        assert fw.count == 0
        fw.allow()
        assert fw.count == 1

    def test_stats(self):
        fw = FixedWindow(max_calls=3, window_seconds=1.0)
        fw.allow()
        s = fw.stats()
        assert s["max_calls"] == 3
        assert s["current_calls"] >= 1

    def test_invalid_params(self):
        with pytest.raises(ValueError):
            FixedWindow(max_calls=0, window_seconds=1.0)
        with pytest.raises(ValueError):
            FixedWindow(max_calls=5, window_seconds=0)

    def test_thread_safety(self):
        fw = FixedWindow(max_calls=50, window_seconds=1.0)
        results = []
        def worker():
            for _ in range(20):
                results.append(fw.allow("shared"))
        threads = [threading.Thread(target=worker) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        allowed = sum(results)
        assert allowed <= 50


# ─── Leaky Bucket ────────────────────────────────────────────────

class TestLeakyBucket:
    def test_basic_allow(self):
        lb = LeakyBucket(rate=0.5, capacity=3)  # very slow leak
        assert lb.allow() is True
        assert lb.allow() is True
        assert lb.allow() is True
        assert lb.allow() is False

    def test_leak(self):
        lb = LeakyBucket(rate=100, capacity=3)
        lb.allow()
        lb.allow()
        lb.allow()
        assert lb.allow() is False
        time.sleep(0.05)  # ~5 should leak out
        assert lb.allow() is True

    def test_per_key(self):
        lb = LeakyBucket(rate=0.5, capacity=2)  # very slow leak
        assert lb.allow("a") is True
        assert lb.allow("a") is True
        assert lb.allow("a") is False
        assert lb.allow("b") is True

    def test_retry_after(self):
        lb = LeakyBucket(rate=0.5, capacity=2)  # very slow leak
        lb.allow()
        lb.allow()
        ra = lb.retry_after()
        assert ra > 0
        assert ra <= 2.0

    def test_level(self):
        lb = LeakyBucket(rate=0.5, capacity=5)  # very slow leak
        assert lb.level == 0
        lb.allow()
        assert lb.level >= 0.9  # slightly less due to tiny leak

    def test_stats(self):
        lb = LeakyBucket(rate=100, capacity=5)
        lb.allow()
        s = lb.stats()
        assert s["capacity"] == 5
        assert s["rate"] == 100

    def test_invalid_params(self):
        with pytest.raises(ValueError):
            LeakyBucket(rate=0, capacity=5)
        with pytest.raises(ValueError):
            LeakyBucket(rate=10, capacity=0)

    def test_thread_safety(self):
        lb = LeakyBucket(rate=1000, capacity=100)
        results = []
        def worker():
            for _ in range(50):
                results.append(lb.allow("shared"))
        threads = [threading.Thread(target=worker) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        allowed = sum(results)
        assert allowed <= 100 + 20  # some leak during test


# ─── RateLimiter (high-level) ────────────────────────────────────

class TestRateLimiter:
    def test_decorator_basic(self):
        call_count = 0
        @RateLimiter(calls=3, period=1.0)
        def func():
            nonlocal call_count
            call_count += 1
            return "ok"
        assert func() == "ok"
        assert func() == "ok"
        assert func() == "ok"
        with pytest.raises(RateLimitExceeded):
            func()
        assert call_count == 3

    def test_decorator_no_raise(self):
        @RateLimiter(calls=1, period=1.0, raise_on_limit=False)
        def func():
            return "ok"
        assert func() == "ok"
        assert func() is None  # rate limited, returns None

    def test_decorator_with_key_func(self):
        calls = {}
        @RateLimiter(calls=2, period=1.0, key_func=lambda user: user)
        def greet(user):
            calls[user] = calls.get(user, 0) + 1
            return f"hi {user}"
        assert greet("alice") == "hi alice"
        assert greet("alice") == "hi alice"
        with pytest.raises(RateLimitExceeded):
            greet("alice")
        assert greet("bob") == "hi bob"  # different user

    def test_manual_allow(self):
        rl = RateLimiter(calls=2, period=1.0)
        assert rl.allow() is True
        assert rl.allow() is True
        assert rl.allow() is False

    def test_wait(self):
        rl = RateLimiter(calls=2, period=0.1)
        rl.allow()
        rl.allow()
        start = time.monotonic()
        rl.wait()
        elapsed = time.monotonic() - start
        assert elapsed < 0.3  # should wait ~0.1s

    def test_acquire_context_manager(self):
        rl = RateLimiter(calls=3, period=1.0)
        with rl.acquire():
            pass
        with rl.acquire():
            pass
        with rl.acquire():
            pass
        with pytest.raises(TimeoutExceeded):
            with rl.acquire(timeout=0.05):
                pass

    def test_acquire_with_timeout(self):
        rl = RateLimiter(calls=1, period=1.0)
        with rl.acquire(timeout=1.0):
            pass
        with pytest.raises(TimeoutExceeded):
            with rl.acquire(timeout=0.05):
                pass

    def test_retry_after(self):
        rl = RateLimiter(calls=2, period=1.0)
        rl.allow()
        rl.allow()
        ra = rl.retry_after()
        assert ra > 0

    def test_reset(self):
        rl = RateLimiter(calls=2, period=1.0)
        rl.allow()
        rl.allow()
        assert rl.allow() is False
        rl.reset()
        assert rl.allow() is True

    def test_reset_specific_key(self):
        rl = RateLimiter(calls=1, period=1.0, key_func=lambda u: u)
        rl.allow("a")
        assert rl.allow("a") is False
        rl.reset("a")
        assert rl.allow("a") is True

    def test_stats(self):
        rl = RateLimiter(calls=5, period=1.0)
        rl.allow()
        rl.allow()
        s = rl.stats()
        assert "__global__" in s

    def test_all_algorithms(self):
        for algo in ["token_bucket", "sliding_window", "fixed_window", "leaky_bucket"]:
            rl = RateLimiter(calls=3, period=1.0, algorithm=algo)
            assert rl.allow() is True
            assert rl.allow() is True
            assert rl.allow() is True
            assert rl.allow() is False

    def test_invalid_params(self):
        with pytest.raises(ValueError):
            RateLimiter(calls=0, period=1.0)
        with pytest.raises(ValueError):
            RateLimiter(calls=5, period=0)
        with pytest.raises(ValueError):
            RateLimiter(calls=5, period=1.0, algorithm="nonexistent")

    def test_rate_limit_exception_attributes(self):
        rl = RateLimiter(calls=1, period=1.0)
        assert rl.allow() is True
        assert rl.allow() is False  # don't raise, just check

    def test_consume_alias(self):
        rl = RateLimiter(calls=2, period=1.0)
        assert rl.consume() is True
        assert rl.consume() is True
        assert rl.consume() is False


# ─── Exceptions ──────────────────────────────────────────────────

class TestExceptions:
    def test_rate_limit_exceeded(self):
        e = RateLimitExceeded("too fast", retry_after=2.5)
        assert str(e) == "too fast"
        assert e.retry_after == 2.5

    def test_rate_limit_no_retry(self):
        e = RateLimitExceeded("blocked")
        assert e.retry_after is None

    def test_timeout_exceeded(self):
        e = TimeoutExceeded("timed out")
        assert str(e) == "timed out"


# ─── Edge Cases ──────────────────────────────────────────────────

class TestEdgeCases:
    def test_single_call_limit(self):
        rl = RateLimiter(calls=1, period=1.0)
        assert rl.allow() is True
        assert rl.allow() is False

    def test_large_capacity(self):
        tb = TokenBucket(rate=10000000, capacity=100000)
        count = 0
        for _ in range(100000):
            if not tb.allow():
                break
            count += 1
        assert count == 100000

    def test_many_keys_sliding_window(self):
        sw = SlidingWindow(max_calls=5, window_seconds=1.0)
        for i in range(1000):
            assert sw.allow(f"key_{i}") is True
            assert sw.allow(f"key_{i}") is True
            assert sw.allow(f"key_{i}") is True
            assert sw.allow(f"key_{i}") is True
            assert sw.allow(f"key_{i}") is True
            assert sw.allow(f"key_{i}") is False

    def test_many_keys_fixed_window(self):
        fw = FixedWindow(max_calls=5, window_seconds=1.0)
        for i in range(1000):
            assert fw.allow(f"key_{i}") is True
            assert fw.allow(f"key_{i}") is True
            assert fw.allow(f"key_{i}") is True
            assert fw.allow(f"key_{i}") is True
            assert fw.allow(f"key_{i}") is True
            assert fw.allow(f"key_{i}") is False

    def test_many_keys_leaky_bucket(self):
        lb = LeakyBucket(rate=0.5, capacity=5)  # very slow leak
        for i in range(1000):
            assert lb.allow(f"key_{i}") is True
            assert lb.allow(f"key_{i}") is True
            assert lb.allow(f"key_{i}") is True
            assert lb.allow(f"key_{i}") is True
            assert lb.allow(f"key_{i}") is True
            assert lb.allow(f"key_{i}") is False

    def test_window_boundary_burst_fixed(self):
        """Fixed window allows burst at boundary (known limitation)."""
        fw = FixedWindow(max_calls=2, window_seconds=0.1)
        # Fill first window
        fw.allow()
        fw.allow()
        assert fw.allow() is False
        # Wait for new window — should get 2 more
        time.sleep(0.15)
        assert fw.allow() is True
        assert fw.allow() is True

    def test_sliding_window_no_boundary_burst(self):
        """Sliding window should not allow boundary bursts."""
        sw = SlidingWindow(max_calls=2, window_seconds=0.3)
        sw.allow()
        sw.allow()
        assert sw.allow() is False
        time.sleep(0.15)
        # First call should still be in window (0.3s window, only 0.15s passed)
        assert sw.allow() is False
        time.sleep(0.2)
        # Now first call should have expired (0.35s > 0.3s window)
        assert sw.allow() is True

    def test_decorator_preserves_name(self):
        @RateLimiter(calls=5, period=1.0)
        def my_function():
            pass
        assert my_function.__name__ == "my_function"

    def test_concurrent_decorator(self):
        call_count = 0
        lock = threading.Lock()
        # Use a very small window so refill during test is negligible
        @RateLimiter(calls=100, period=10.0, algorithm="fixed_window")
        def func():
            nonlocal call_count
            with lock:
                call_count += 1
        threads = [threading.Thread(target=func) for _ in range(200)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert call_count == 100

    def test_token_bucket_exact_capacity(self):
        tb = TokenBucket(rate=10, capacity=5)
        assert tb.allow() is True
        assert tb.allow() is True
        assert tb.allow() is True
        assert tb.allow() is True
        assert tb.allow() is True
        assert tb.allow() is False

    def test_retry_after_zero_when_available(self):
        tb = TokenBucket(rate=10, capacity=5)
        assert tb.retry_after() == 0.0
        sw = SlidingWindow(max_calls=5, window_seconds=1.0)
        assert sw.retry_after() == 0.0
        fw = FixedWindow(max_calls=5, window_seconds=1.0)
        assert fw.retry_after() == 0.0
        lb = LeakyBucket(rate=100, capacity=5)
        assert lb.retry_after() == 0.0
