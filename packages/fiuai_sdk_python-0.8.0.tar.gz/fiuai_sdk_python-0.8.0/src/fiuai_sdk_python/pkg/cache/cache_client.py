# -- coding: utf-8 --
# Project: fiuai-sdk-python
# Created Date: 2026-03-09
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

import json
from typing import Awaitable, Callable, Optional, TypeVar

from redis import Redis as SyncRedis
from redis.asyncio import Redis as AsyncRedis

from ...utils.logger import get_logger
from .circuit_breaker import CircuitBreaker
from .redis_manager import redis_manager
from .types import CacheConfig

logger = get_logger(__name__)
T = TypeVar("T")


class CacheClient:
    """通用缓存客户端

    能力: KV / Hash / TTL / get_or_load (cache-aside) / 熔断降级
    不含业务语义 (无 tenant/company 前缀), 由项目层包装。
    """

    def __init__(self, config: CacheConfig):
        self._config = config
        self._breaker = CircuitBreaker(config.circuit_breaker)

    def _full_key(self, key: str) -> str:
        if self._config.key_prefix:
            return f"{self._config.key_prefix}:{key}"
        return key

    def _get_async_client(self) -> AsyncRedis:
        return redis_manager.get_async_client(self._config.redis_db_name)

    def _get_sync_client(self) -> SyncRedis:
        return redis_manager.get_sync_client(self._config.redis_db_name)

    def _effective_ttl(self, ttl: Optional[int]) -> Optional[int]:
        return ttl if ttl is not None else self._config.default_ttl

    # ── KV async ──────────────────────────────────────────

    async def get(self, key: str) -> Optional[str]:
        if not self._breaker.allow_request:
            return None
        try:
            client = self._get_async_client()
            val = await client.get(self._full_key(key))
            self._breaker.record_success()
            return val
        except Exception as e:
            self._breaker.record_failure()
            logger.warning(f"cache get failed: key={key}, {e}")
            return None

    async def set(self, key: str, value: str, ttl: Optional[int] = None) -> bool:
        if not self._breaker.allow_request:
            return False
        try:
            client = self._get_async_client()
            effective_ttl = self._effective_ttl(ttl)
            if effective_ttl:
                await client.setex(self._full_key(key), effective_ttl, value)
            else:
                await client.set(self._full_key(key), value)
            self._breaker.record_success()
            return True
        except Exception as e:
            self._breaker.record_failure()
            logger.warning(f"cache set failed: key={key}, {e}")
            return False

    async def delete(self, key: str) -> bool:
        if not self._breaker.allow_request:
            return False
        try:
            client = self._get_async_client()
            await client.delete(self._full_key(key))
            self._breaker.record_success()
            return True
        except Exception as e:
            self._breaker.record_failure()
            logger.warning(f"cache delete failed: key={key}, {e}")
            return False

    async def exists(self, key: str) -> bool:
        if not self._breaker.allow_request:
            return False
        try:
            client = self._get_async_client()
            result = await client.exists(self._full_key(key))
            self._breaker.record_success()
            return bool(result)
        except Exception as e:
            self._breaker.record_failure()
            return False

    # ── Hash async ────────────────────────────────────────

    async def hset(self, key: str, field: str, value: str) -> bool:
        if not self._breaker.allow_request:
            return False
        try:
            client = self._get_async_client()
            await client.hset(self._full_key(key), field, value)
            self._breaker.record_success()
            return True
        except Exception as e:
            self._breaker.record_failure()
            logger.warning(f"cache hset failed: key={key}, field={field}, {e}")
            return False

    async def hget(self, key: str, field: str) -> Optional[str]:
        if not self._breaker.allow_request:
            return None
        try:
            client = self._get_async_client()
            val = await client.hget(self._full_key(key), field)
            self._breaker.record_success()
            return val
        except Exception as e:
            self._breaker.record_failure()
            return None

    async def hgetall(self, key: str) -> dict:
        if not self._breaker.allow_request:
            return {}
        try:
            client = self._get_async_client()
            val = await client.hgetall(self._full_key(key))
            self._breaker.record_success()
            return val or {}
        except Exception as e:
            self._breaker.record_failure()
            return {}

    # ── cache-aside async ─────────────────────────────────

    async def get_or_load(
        self,
        key: str,
        loader: Callable[[], Awaitable[T]],
        ttl: Optional[int] = None,
        serializer: Callable[[T], str] = json.dumps,
        deserializer: Callable[[str], T] = json.loads,
    ) -> T:
        """Cache-aside: 命中返回缓存, miss 或熔断时调 loader。

        loader 返回值写回 cache (best-effort)。
        熔断时不报错, 直接走 loader — 保证业务不中断。
        """
        if self._breaker.allow_request:
            try:
                client = self._get_async_client()
                cached = await client.get(self._full_key(key))
                if cached is not None:
                    self._breaker.record_success()
                    return deserializer(cached)
                self._breaker.record_success()
            except Exception as e:
                self._breaker.record_failure()
                logger.warning(f"cache get_or_load read failed: key={key}, {e}")

        value = await loader()
        await self.set(key, serializer(value), ttl)
        return value

    # ── KV sync ───────────────────────────────────────────

    def get_sync(self, key: str) -> Optional[str]:
        if not self._breaker.allow_request:
            return None
        try:
            client = self._get_sync_client()
            val = client.get(self._full_key(key))
            self._breaker.record_success()
            return val
        except Exception as e:
            self._breaker.record_failure()
            logger.warning(f"cache get_sync failed: key={key}, {e}")
            return None

    def set_sync(self, key: str, value: str, ttl: Optional[int] = None) -> bool:
        if not self._breaker.allow_request:
            return False
        try:
            client = self._get_sync_client()
            effective_ttl = self._effective_ttl(ttl)
            if effective_ttl:
                client.setex(self._full_key(key), effective_ttl, value)
            else:
                client.set(self._full_key(key), value)
            self._breaker.record_success()
            return True
        except Exception as e:
            self._breaker.record_failure()
            logger.warning(f"cache set_sync failed: key={key}, {e}")
            return False

    # ── cache-aside sync ──────────────────────────────────

    def get_or_load_sync(
        self,
        key: str,
        loader: Callable[[], T],
        ttl: Optional[int] = None,
        serializer: Callable[[T], str] = json.dumps,
        deserializer: Callable[[str], T] = json.loads,
    ) -> T:
        """同步版 cache-aside"""
        if self._breaker.allow_request:
            try:
                client = self._get_sync_client()
                cached = client.get(self._full_key(key))
                if cached is not None:
                    self._breaker.record_success()
                    return deserializer(cached)
                self._breaker.record_success()
            except Exception as e:
                self._breaker.record_failure()
                logger.warning(f"cache get_or_load_sync read failed: key={key}, {e}")

        value = loader()
        self.set_sync(key, serializer(value), ttl)
        return value
