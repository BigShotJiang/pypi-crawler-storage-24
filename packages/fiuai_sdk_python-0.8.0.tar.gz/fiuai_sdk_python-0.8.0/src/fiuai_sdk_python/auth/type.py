# -- coding: utf-8 --
# Project: auth
# Created Date: 2025 09 Th
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI


from pydantic import BaseModel, Field
from typing import Literal, get_args

# 客户端枚举：wechat / web / default / app
FiuaiClient = Literal["wechat", "web", "default", "app"]
FIUAI_CLIENT_VALUES: tuple = get_args(FiuaiClient)

# channel 为渠道 code，目前未用，仅保留 default


class AuthData(BaseModel):
    user_id: str = Field(description="用户ID")
    auth_tenant_id: str = Field(description="租户ID")
    current_company: str = Field(description="当前公司ID")
    impersonation: str = Field(description="当前代表的租户ID", default="")
    company_unique_no: str = Field(description="当前公司唯一编号,正常情况等于current_company")
    trace_id: str = Field(description="追踪ID", default="")
    client: FiuaiClient = Field(description="客户端：wechat/web/default/app", default="default")
    channel: str = Field(description="渠道code，目前未用，仅保留 default", default="default")
    lang: str = Field(description="用户当前语言", default="zh")
    accept_language: str = Field(description="接受的语言", default="zh")



    # edoc

class AuthHeader(BaseModel):
    """HTTP 认证头信息模型"""
    x_fiuai_user: str = Field(alias="x-fiuai-user", description="用户ID")
    x_fiuai_auth_tenant_id: str = Field(alias="x-fiuai-auth-tenant-id", description="租户ID")
    x_fiuai_current_company: str = Field(alias="x-fiuai-current-company", default="", description="当前公司ID列表（逗号分隔）")
    x_fiuai_unique_no: str = Field(alias="x-fiuai-unique-no", default="", description="当前公司唯一编号,正常情况等于current_company")
    x_fiuai_impersonation: str = Field(alias="x-fiuai-impersonation", default="", description="当前代表的租户ID")
    x_fiuai_lang: str = Field(alias="x-fiuai-lang", default="zh", description="用户当前语言")
    x_fiuai_trace_id: str = Field(alias="x-fiuai-trace-id", default="", description="追踪ID")
    x_fiuai_client: str = Field(alias="x-fiuai-client", default="default", description="客户端：wechat/web/default/app")
    x_fiuai_channel: str = Field(alias="x-fiuai-channel", default="default", description="渠道code，目前未用")
    accept_language: str = Field(alias="accept-language", default="zh", description="语言")

    class Config:
        populate_by_name = True