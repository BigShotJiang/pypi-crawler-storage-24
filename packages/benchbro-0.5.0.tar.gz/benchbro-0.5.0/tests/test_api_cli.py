from __future__ import annotations

import gc
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from benchbro import (
    BenchmarkResult,
    BenchmarkRun,
    Case,
    CommandSpec,
    clear_registry,
    compare_runs,
    list_cases,
    read_json,
    run_cases,
    system,
    write_json,
)
from benchbro.cli import main


def _python_command(script: str, *args: str, **kwargs) -> CommandSpec:
    return CommandSpec(argv=[sys.executable, "-c", script, *args], **kwargs)


def test_case_groups_multiple_benchmarks() -> None:
    clear_registry()
    case = Case(
        name="hashing",
        case_type="cpu",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.input()
    def input_data() -> bytes:
        return b"abc"

    @case.benchmark()
    def sha1(input_data: bytes) -> int:
        return len(input_data)

    @case.benchmark()
    def sha256(input_data: bytes) -> int:
        return len(input_data) * 2

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 2
    assert "python_version" in run.environment
    assert "platform" in run.environment
    assert {r.case_name for r in run.benchmarks} == {"hashing"}
    assert {r.benchmark_name for r in run.benchmarks} == {"sha1", "sha256"}
    assert {r.regression_threshold_pct for r in run.benchmarks} == {100.0}
    assert {r.warning_threshold_pct for r in run.benchmarks} == {50.0}
    assert all("iqr_s" in r.metrics for r in run.benchmarks)
    assert all(len(r.time_samples_s) == 1 for r in run.benchmarks)


def test_case_threshold_used_when_benchmark_override_missing() -> None:
    clear_registry()
    case = Case(
        name="threshold_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
        regression_threshold_pct=12.5,
    )

    @case.benchmark()
    def bench_default() -> int:
        return 1

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1
    assert run.benchmarks[0].regression_threshold_pct == 12.5
    assert run.benchmarks[0].warning_threshold_pct == 50.0


def test_benchmark_threshold_override_supersedes_case_threshold() -> None:
    clear_registry()
    case = Case(
        name="threshold_override_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
        regression_threshold_pct=20.0,
    )

    @case.benchmark(regression_threshold_pct=7.5)
    def bench_override() -> int:
        return 1

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1
    assert run.benchmarks[0].regression_threshold_pct == 7.5
    assert run.benchmarks[0].warning_threshold_pct == 50.0


def test_case_warning_used_when_benchmark_warning_override_missing() -> None:
    clear_registry()
    case = Case(
        name="warning_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
        warning_threshold_pct=12.0,
    )

    @case.benchmark()
    def bench_default_warning() -> int:
        return 1

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1
    assert run.benchmarks[0].warning_threshold_pct == 12.0


def test_benchmark_warning_override_supersedes_case_warning() -> None:
    clear_registry()
    case = Case(
        name="warning_override_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
        warning_threshold_pct=20.0,
    )

    @case.benchmark(warning_threshold_pct=7.0)
    def bench_warning_override() -> int:
        return 1

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1
    assert run.benchmarks[0].warning_threshold_pct == 7.0


def test_case_comparison_metric_applies_when_benchmark_override_missing() -> None:
    clear_registry()
    case = Case(
        name="comparison_case",
        metric_type="time",
        comparison_metric="p95_s",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.benchmark()
    def bench_default_metric() -> int:
        return 1

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1
    assert run.benchmarks[0].comparison_metric == "p95_s"


def test_benchmark_comparison_metric_override_supersedes_case_metric() -> None:
    clear_registry()
    case = Case(
        name="comparison_override_case",
        metric_type="time",
        comparison_metric="median_s",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.benchmark(comparison_metric="mean_s")
    def bench_metric_override() -> int:
        return 1

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1
    assert run.benchmarks[0].comparison_metric == "mean_s"


def test_invalid_comparison_metric_raises_value_error() -> None:
    clear_registry()
    case = Case(name="invalid_metric_case", metric_type="time")

    with pytest.raises(ValueError):

        @case.benchmark(comparison_metric="peak_alloc_bytes")
        def invalid_metric_bench() -> int:
            return 1


def test_case_memory_result_shape() -> None:
    clear_registry()
    case = Case(
        name="mem_case",
        case_type="memory",
        metric_type="memory",
        repeats=2,
        min_iterations=3,
        warmup_iterations=0,
    )

    @case.benchmark()
    def allocate() -> list[int]:
        return [1, 2, 3, 4, 5]

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1

    result = run.benchmarks[0]
    assert result.metric_type == "memory"
    assert "peak_alloc_bytes" in result.metrics
    assert "net_alloc_bytes" in result.metrics
    assert result.time_samples_s == []


def test_async_case_input_and_benchmark_support() -> None:
    clear_registry()
    case = Case(
        name="async_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.input()
    async def input_data() -> bytes:
        return b"abc"

    @case.benchmark()
    async def async_bench(input_data: bytes) -> int:
        return len(input_data)

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1
    result = run.benchmarks[0]
    assert result.case_name == "async_case"
    assert result.benchmark_name == "async_bench"
    assert "median_s" in result.metrics


def test_command_benchmark_runs_python_subprocess_and_records_time_metrics() -> None:
    clear_registry()
    case = Case(
        name="command_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return _python_command("pass")

    run = run_cases(list_cases())
    assert len(run.benchmarks) == 1
    result = run.benchmarks[0]
    assert result.benchmark_name == "run_cli"
    assert result.metric_type == "time"
    assert len(result.time_samples_s) == 1


def test_command_benchmark_receives_input_and_system_by_name() -> None:
    clear_registry()
    case = Case(
        name="command_di_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @system()
    def suffix() -> str:
        return "world"

    @case.input()
    def greeting() -> str:
        return "hello"

    @case.subprocess()
    def run_cli(greeting: str, suffix: str) -> CommandSpec:
        return _python_command(
            (
                "import os, sys; "
                "expected = sys.argv[1] + '-' + sys.argv[2]; "
                "sys.exit(0 if os.environ['MSG'] == expected else 1)"
            ),
            greeting,
            suffix,
            env={"MSG": f"{greeting}-{suffix}"},
        )

    run_cases(list_cases())


def test_command_benchmark_rejects_memory_metric_type() -> None:
    clear_registry()
    case = Case(name="command_memory_case", metric_type="memory")

    with pytest.raises(ValueError, match="only support metric_type 'time'"):

        @case.subprocess()
        def run_cli() -> CommandSpec:
            return _python_command("pass")


def test_async_command_benchmark_rejected() -> None:
    clear_registry()
    case = Case(name="async_command_case", metric_type="time")

    with pytest.raises(ValueError, match="cannot be async"):

        @case.subprocess()
        async def run_cli() -> CommandSpec:
            return _python_command("pass")


def test_command_benchmark_requires_commandspec() -> None:
    clear_registry()
    case = Case(
        name="bad_command_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return "not-a-command"  # type: ignore[return-value]

    with pytest.raises(ValueError, match="must return CommandSpec"):
        run_cases(list_cases())


def test_commandspec_validates_fields() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        CommandSpec(argv=[])
    with pytest.raises(ValueError, match="positive number"):
        CommandSpec(argv=["echo"], timeout_s=0)
    with pytest.raises(ValueError, match="cannot be empty"):
        CommandSpec(argv=["echo"], expected_exit_codes=())
    with pytest.raises(ValueError, match="stdout must be"):
        CommandSpec(argv=["echo"], stdout="capture")  # type: ignore[arg-type]


def test_command_benchmark_applies_cwd(tmp_path: Path) -> None:
    clear_registry()
    marker = tmp_path / "marker.txt"
    marker.write_text("ok", encoding="utf-8")
    case = Case(
        name="cwd_command_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return _python_command(
            (
                "from pathlib import Path; import sys; "
                "sys.exit(0 if Path('marker.txt').exists() else 1)"
            ),
            cwd=tmp_path,
        )

    run_cases(list_cases())


def test_command_benchmark_passes_stdin_bytes() -> None:
    clear_registry()
    case = Case(
        name="stdin_command_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return _python_command(
            (
                "import sys; "
                "data = sys.stdin.buffer.read(); "
                "sys.exit(0 if data == b'payload' else 1)"
            ),
            stdin_bytes=b"payload",
        )

    run_cases(list_cases())


def test_command_benchmark_defaults_stdout_and_stderr_to_devnull(
    capfd: pytest.CaptureFixture[str],
) -> None:
    clear_registry()
    case = Case(
        name="devnull_command_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return _python_command(
            (
                "import sys; "
                "print('stdout-visible', flush=True); "
                "print('stderr-visible', file=sys.stderr, flush=True)"
            )
        )

    run_cases(list_cases())
    captured = capfd.readouterr()
    assert "stdout-visible" not in captured.out
    assert "stderr-visible" not in captured.err


def test_command_benchmark_inherit_stdio_does_not_crash(
    capfd: pytest.CaptureFixture[str],
) -> None:
    clear_registry()
    case = Case(
        name="inherit_command_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return _python_command(
            (
                "import sys; "
                "print('stdout-visible', flush=True); "
                "print('stderr-visible', file=sys.stderr, flush=True)"
            ),
            stdout="inherit",
            stderr="inherit",
        )

    run_cases(list_cases())
    captured = capfd.readouterr()
    assert "stdout-visible" in captured.out
    assert "stderr-visible" in captured.err


def test_command_benchmark_unexpected_exit_code_fails() -> None:
    clear_registry()
    case = Case(
        name="exit_code_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return _python_command("import sys; sys.exit(3)")

    with pytest.raises(RuntimeError, match="exited with code 3"):
        run_cases(list_cases())


def test_command_benchmark_allows_expected_non_zero_exit_code() -> None:
    clear_registry()
    case = Case(
        name="expected_exit_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return _python_command("import sys; sys.exit(3)", expected_exit_codes=(3,))

    run_cases(list_cases())


def test_command_benchmark_timeout_fails() -> None:
    clear_registry()
    case = Case(
        name="timeout_command_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.subprocess()
    def run_cli() -> CommandSpec:
        return _python_command("import time; time.sleep(1)", timeout_s=0.05)

    with pytest.raises(RuntimeError, match="timed out"):
        run_cases(list_cases())


def test_function_scoped_system_reused_for_command_benchmark() -> None:
    clear_registry()
    case = Case(
        name="command_function_scope_case",
        metric_type="time",
        repeats=2,
        min_iterations=2,
        warmup_iterations=1,
    )
    creates = 0
    teardowns = 0
    seen: list[str] = []

    @system(scope="function")
    def token():
        nonlocal creates, teardowns
        creates += 1
        yield str(creates)
        teardowns += 1

    @case.subprocess()
    def run_cli(token: str) -> CommandSpec:
        seen.append(token)
        return _python_command("pass")

    run_cases(list_cases())
    assert creates == 1
    assert teardowns == 1
    assert seen == ["1", "1", "1", "1", "1"]


def test_module_scoped_system_shared_across_command_benchmarks() -> None:
    clear_registry()
    first_case = Case(
        name="command_module_scope_first",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    second_case = Case(
        name="command_module_scope_second",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    creates = 0
    teardowns = 0
    seen: list[str] = []

    @system(scope="module")
    def shared():
        nonlocal creates, teardowns
        creates += 1
        yield str(creates)
        teardowns += 1

    @first_case.subprocess()
    def first(shared: str) -> CommandSpec:
        seen.append(shared)
        return _python_command("pass")

    @second_case.subprocess()
    def second(shared: str) -> CommandSpec:
        seen.append(shared)
        return _python_command("pass")

    run_cases(list_cases())
    assert creates == 1
    assert teardowns == 1
    assert seen == ["1", "1"]


def test_persistent_subprocess_system_tears_down_after_use() -> None:
    clear_registry()
    case = Case(
        name="persistent_process_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    process_holder: dict[str, subprocess.Popen[bytes]] = {}

    @system()
    def worker():
        proc = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
        process_holder["proc"] = proc
        yield proc.pid
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()

    @case.benchmark()
    def bench(worker: int) -> int:
        os.kill(worker, 0)
        return 1

    run_cases(list_cases())
    assert process_holder["proc"].poll() is not None


def test_standalone_system_injected_by_name() -> None:
    clear_registry()
    case = Case(
        name="system_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    seen: list[int] = []

    @system()
    def multiplier() -> int:
        return 2

    @case.input()
    def input_data() -> int:
        return 3

    @case.benchmark()
    def bench(input_data: int, multiplier: int) -> int:
        seen.append(input_data * multiplier)
        return seen[-1]

    run_cases(list_cases())
    assert seen == [6]


def test_standalone_system_can_depend_on_another_system() -> None:
    clear_registry()
    case = Case(
        name="system_deps_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    events: list[str] = []

    @system()
    def base() -> int:
        events.append("base")
        return 2

    @system()
    def derived(base: int) -> int:
        events.append("derived")
        return base + 1

    @case.benchmark()
    def bench(derived: int) -> int:
        events.append(f"bench:{derived}")
        return derived

    run_cases(list_cases())
    assert events == ["base", "derived", "bench:3"]


def test_duplicate_standalone_system_names_raise_value_error() -> None:
    clear_registry()

    def first_duplicate() -> int:
        return 1

    first_duplicate.__name__ = "duplicate"
    system()(first_duplicate)

    with pytest.raises(ValueError):

        def second_duplicate() -> int:
            return 2

        second_duplicate.__name__ = "duplicate"
        system()(second_duplicate)


def test_clear_registry_clears_standalone_systems() -> None:
    clear_registry()

    def first_duplicate() -> int:
        return 1

    first_duplicate.__name__ = "duplicate"
    system()(first_duplicate)

    clear_registry()

    def second_duplicate() -> int:
        return 2

    second_duplicate.__name__ = "duplicate"
    system()(second_duplicate)


def test_async_system_and_async_benchmark_support() -> None:
    clear_registry()
    case = Case(
        name="async_system_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    seen: list[int] = []

    @system()
    async def count() -> int:
        return 4

    @case.benchmark()
    async def bench(count: int) -> int:
        seen.append(count)
        return count

    run_cases(list_cases())
    assert seen == [4]


def test_sync_system_cannot_depend_on_async_system() -> None:
    clear_registry()
    case = Case(
        name="sync_depends_on_async_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @system()
    async def async_value() -> int:
        return 4

    @system()
    def sync_value(async_value: int) -> int:
        return async_value

    @case.benchmark()
    def bench(sync_value: int) -> int:
        return sync_value

    with pytest.raises(
        ValueError, match="Sync system 'sync_value' cannot depend on async system"
    ):
        run_cases(list_cases())


def test_sync_benchmark_cannot_depend_on_async_system() -> None:
    clear_registry()
    case = Case(
        name="sync_benchmark_depends_on_async_system_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @system()
    async def async_value() -> int:
        return 4

    @case.benchmark()
    def bench(async_value: int) -> int:
        return async_value

    with pytest.raises(
        ValueError, match="Sync benchmark 'bench' cannot depend on async system"
    ):
        run_cases(list_cases())


def test_input_cannot_declare_dependencies() -> None:
    clear_registry()
    case = Case(name="invalid_input")

    with pytest.raises(ValueError):

        @case.input()
        def payload(dep: int) -> int:
            return dep


def test_benchmark_unknown_dependency_raises_value_error() -> None:
    clear_registry()
    case = Case(
        name="unknown_dep_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.benchmark()
    def bench(missing: int) -> int:
        return missing

    with pytest.raises(ValueError, match="unknown dependency 'missing'"):
        run_cases(list_cases())


def test_system_cannot_depend_on_input() -> None:
    clear_registry()
    case = Case(
        name="system_input_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @case.input()
    def payload() -> int:
        return 1

    @system()
    def configured(payload: int) -> int:
        return payload

    @case.benchmark()
    def bench(configured: int) -> int:
        return configured

    with pytest.raises(ValueError, match="cannot depend on input 'payload'"):
        run_cases(list_cases())


def test_input_and_system_name_ambiguity_raises_value_error() -> None:
    clear_registry()
    case = Case(
        name="ambiguous_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    def system_payload() -> int:
        return 2

    system_payload.__name__ = "payload"
    system()(system_payload)

    def input_payload() -> int:
        return 1

    input_payload.__name__ = "payload"
    case.input()(input_payload)

    @case.benchmark()
    def bench(payload: int) -> int:
        return payload

    with pytest.raises(ValueError, match="ambiguous"):
        run_cases(list_cases())


def test_system_dependency_cycle_raises_value_error() -> None:
    clear_registry()
    case = Case(
        name="cycle_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @system()
    def first(second: int) -> int:
        return second

    @system()
    def second(first: int) -> int:
        return first

    @case.benchmark()
    def bench(first: int) -> int:
        return first

    with pytest.raises(ValueError, match="cycle"):
        run_cases(list_cases())


def test_function_scoped_system_reused_per_benchmark_and_not_shared() -> None:
    clear_registry()
    case = Case(
        name="function_scope_case",
        metric_type="time",
        repeats=2,
        min_iterations=3,
        warmup_iterations=1,
    )
    creates = 0
    teardowns = 0
    first_ids: list[int] = []
    second_ids: list[int] = []

    @system(scope="function")
    def token():
        nonlocal creates, teardowns
        creates += 1
        value = creates
        yield value
        teardowns += 1

    @case.benchmark(name="one")
    def one(token: object) -> int:
        first_ids.append(id(token))
        return 1

    @case.benchmark(name="two")
    def two(token: object) -> int:
        second_ids.append(id(token))
        return 1

    run_cases(list_cases())
    assert creates == 2
    assert teardowns == 2
    assert len(set(first_ids)) == 1
    assert len(set(second_ids)) == 1
    assert first_ids[0] != second_ids[0]
    assert len(first_ids) == 7
    assert len(second_ids) == 7


def test_module_scoped_system_shared_across_cases_in_one_run() -> None:
    clear_registry()
    first_case = Case(
        name="module_scope_first",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    second_case = Case(
        name="module_scope_second",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    creates = 0
    teardowns = 0
    seen_ids: list[int] = []

    @system(scope="module")
    def shared():
        nonlocal creates, teardowns
        creates += 1
        value = object()
        yield value
        teardowns += 1

    @first_case.benchmark()
    def first(shared: object) -> int:
        seen_ids.append(id(shared))
        return 1

    @second_case.benchmark()
    def second(shared: object) -> int:
        seen_ids.append(id(shared))
        return 1

    run_cases(list_cases())
    assert creates == 1
    assert teardowns == 1
    assert len(set(seen_ids)) == 1


def test_sync_system_teardown_runs_in_reverse_dependency_order() -> None:
    clear_registry()
    case = Case(
        name="teardown_order_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    events: list[str] = []

    @system()
    def base():
        events.append("enter base")
        yield "base"
        events.append("exit base")

    @system()
    def derived(base: str):
        events.append("enter derived")
        yield f"{base}:derived"
        events.append("exit derived")

    @case.benchmark()
    def bench(derived: str) -> int:
        events.append(f"bench:{derived}")
        return 1

    run_cases(list_cases())
    assert events == [
        "enter base",
        "enter derived",
        "bench:base:derived",
        "exit derived",
        "exit base",
    ]


def test_async_system_teardown_runs_after_benchmark_failure() -> None:
    clear_registry()
    case = Case(
        name="teardown_failure_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )
    events: list[str] = []

    @system()
    async def resource():
        events.append("enter")
        yield "resource"
        events.append("exit")

    @case.benchmark()
    async def bench(resource: str) -> int:
        events.append(resource)
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError, match="boom"):
        run_cases(list_cases())
    assert events == ["enter", "resource", "exit"]


def test_module_scoped_system_cannot_depend_on_function_scoped_system() -> None:
    clear_registry()
    case = Case(
        name="scope_mismatch_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
    )

    @system()
    def inner() -> int:
        return 1

    @system(scope="module")
    def outer(inner: int) -> int:
        return inner

    @case.benchmark()
    def bench(outer: int) -> int:
        return outer

    with pytest.raises(ValueError, match="cannot depend on function-scoped system"):
        run_cases(list_cases())


def test_compare_runs_uses_current_result_threshold() -> None:
    baseline = BenchmarkRun(
        started_at="t0",
        finished_at="t1",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="cmp_case",
                benchmark_name="time_bench",
                case_type="cpu",
                metric_type="time",
                gc_control="disable_during_measure",
                regression_threshold_pct=100.0,
                iterations=1,
                repeats=1,
                metrics={"mean_s": 1.0, "median_s": 1.0},
                warning_threshold_pct=50.0,
            )
        ],
    )
    current = BenchmarkRun(
        started_at="t2",
        finished_at="t3",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="cmp_case",
                benchmark_name="time_bench",
                case_type="cpu",
                metric_type="time",
                gc_control="disable_during_measure",
                regression_threshold_pct=10.0,
                iterations=1,
                repeats=1,
                metrics={"mean_s": 1.2, "median_s": 1.2},
                warning_threshold_pct=5.0,
            )
        ],
    )
    regressions = compare_runs(baseline, current)
    assert len(regressions) == 1
    assert regressions[0].threshold_pct == 10.0
    assert regressions[0].warning_threshold_pct == 5.0
    assert regressions[0].is_regression
    assert not regressions[0].is_warning


def test_compare_runs_threshold_equality_is_not_regression() -> None:
    baseline = BenchmarkRun(
        started_at="t0",
        finished_at="t1",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="eq_case",
                benchmark_name="eq_bench",
                case_type="cpu",
                metric_type="time",
                gc_control="disable_during_measure",
                regression_threshold_pct=100.0,
                iterations=1,
                repeats=1,
                metrics={"mean_s": 1.0, "median_s": 1.0},
                warning_threshold_pct=50.0,
            )
        ],
    )
    current = BenchmarkRun(
        started_at="t2",
        finished_at="t3",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="eq_case",
                benchmark_name="eq_bench",
                case_type="cpu",
                metric_type="time",
                gc_control="disable_during_measure",
                regression_threshold_pct=10.0,
                iterations=1,
                repeats=1,
                metrics={"mean_s": 1.1, "median_s": 1.1},
                warning_threshold_pct=5.0,
            )
        ],
    )
    regressions = compare_runs(baseline, current)
    assert len(regressions) == 1
    assert regressions[0].percent_change == pytest.approx(10.0)
    assert not regressions[0].is_regression
    assert regressions[0].is_warning


def test_compare_runs_memory_uses_peak_alloc_threshold() -> None:
    baseline = BenchmarkRun(
        started_at="t0",
        finished_at="t1",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="mem_cmp",
                benchmark_name="alloc",
                case_type="memory",
                metric_type="memory",
                gc_control="disable_during_measure",
                regression_threshold_pct=100.0,
                iterations=1,
                repeats=1,
                metrics={"peak_alloc_bytes": 100.0},
                warning_threshold_pct=50.0,
            )
        ],
    )
    current = BenchmarkRun(
        started_at="t2",
        finished_at="t3",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="mem_cmp",
                benchmark_name="alloc",
                case_type="memory",
                metric_type="memory",
                gc_control="disable_during_measure",
                regression_threshold_pct=50.0,
                iterations=1,
                repeats=1,
                metrics={"peak_alloc_bytes": 130.0},
                warning_threshold_pct=25.0,
            )
        ],
    )
    regressions = compare_runs(baseline, current)
    assert len(regressions) == 1
    assert regressions[0].metric_name == "peak_alloc_bytes"
    assert not regressions[0].is_regression
    assert regressions[0].is_warning


def test_compare_runs_ops_per_sec_uses_inverse_regression_direction() -> None:
    baseline = BenchmarkRun(
        started_at="t0",
        finished_at="t1",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="throughput_case",
                benchmark_name="ops",
                case_type="cpu",
                metric_type="time",
                gc_control="disable_during_measure",
                comparison_metric="ops_per_sec",
                regression_threshold_pct=10.0,
                iterations=1,
                repeats=1,
                metrics={"ops_per_sec": 100.0},
                warning_threshold_pct=5.0,
            )
        ],
    )
    current = BenchmarkRun(
        started_at="t2",
        finished_at="t3",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="throughput_case",
                benchmark_name="ops",
                case_type="cpu",
                metric_type="time",
                gc_control="disable_during_measure",
                comparison_metric="ops_per_sec",
                regression_threshold_pct=10.0,
                iterations=1,
                repeats=1,
                metrics={"ops_per_sec": 80.0},
                warning_threshold_pct=5.0,
            )
        ],
    )
    regressions = compare_runs(baseline, current)
    assert len(regressions) == 1
    assert regressions[0].metric_name == "ops_per_sec"
    assert regressions[0].is_regression


def test_read_json_defaults_threshold_for_older_payload(tmp_path: Path) -> None:
    payload = {
        "started_at": "t0",
        "finished_at": "t1",
        "python_version": "3.13",
        "platform": "test",
        "environment": {},
        "benchmarks": [
            {
                "case_name": "old_case",
                "benchmark_name": "old_bench",
                "case_type": "cpu",
                "metric_type": "time",
                "gc_control": "disable_during_measure",
                "iterations": 1,
                "repeats": 1,
                "metrics": {"mean_s": 1.0},
            }
        ],
    }
    path = tmp_path / "old.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    run = read_json(path)
    assert run.benchmarks[0].regression_threshold_pct == 100.0
    assert run.benchmarks[0].environment == {}
    assert run.benchmarks[0].warning_threshold_pct == 50.0


def test_read_json_backfills_benchmark_environment_from_run_environment(
    tmp_path: Path,
) -> None:
    payload = {
        "started_at": "t0",
        "finished_at": "t1",
        "python_version": "3.13",
        "platform": "test",
        "environment": {"python_version": "3.13", "platform": "test-platform"},
        "benchmarks": [
            {
                "case_name": "old_case",
                "benchmark_name": "old_bench",
                "case_type": "cpu",
                "metric_type": "time",
                "gc_control": "disable_during_measure",
                "iterations": 1,
                "repeats": 1,
                "metrics": {"mean_s": 1.0},
            }
        ],
    }
    path = tmp_path / "old_with_env.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    run = read_json(path)
    assert run.benchmarks[0].environment == payload["environment"]


def test_write_json_includes_threshold_field(tmp_path: Path) -> None:
    run = BenchmarkRun(
        started_at="t0",
        finished_at="t1",
        python_version="3.13",
        platform="test",
        environment={},
        benchmarks=[
            BenchmarkResult(
                case_name="case",
                benchmark_name="bench",
                case_type="cpu",
                metric_type="time",
                gc_control="disable_during_measure",
                regression_threshold_pct=33.0,
                iterations=1,
                repeats=1,
                metrics={"mean_s": 1.0, "median_s": 1.0},
                warning_threshold_pct=22.0,
            )
        ],
    )
    path = tmp_path / "new.json"
    write_json(path, run)

    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["benchmarks"][0]["regression_threshold_pct"] == 33.0
    assert payload["benchmarks"][0]["warning_threshold_pct"] == 22.0
    assert "environment" in payload["benchmarks"][0]
    assert "time_samples_s" not in payload["benchmarks"][0]


def test_read_json_accepts_time_samples_if_present(tmp_path: Path) -> None:
    payload = {
        "started_at": "t0",
        "finished_at": "t1",
        "python_version": "3.13",
        "platform": "test",
        "environment": {},
        "benchmarks": [
            {
                "case_name": "sample_case",
                "benchmark_name": "sample_bench",
                "case_type": "cpu",
                "metric_type": "time",
                "gc_control": "disable_during_measure",
                "regression_threshold_pct": 100.0,
                "warning_threshold_pct": 50.0,
                "iterations": 1,
                "repeats": 1,
                "metrics": {"median_s": 1.0, "mean_s": 1.0},
                "time_samples_s": [1.0, 1.1, 0.9],
            }
        ],
    }
    path = tmp_path / "samples.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    run = read_json(path)
    assert run.benchmarks[0].time_samples_s == [1.0, 1.1, 0.9]


def test_cli_rejects_removed_fail_on_regression_flag(tmp_path: Path) -> None:
    clear_registry()
    module_path = tmp_path / "bench_flag.py"
    module_path.write_text(
        "from benchbro import Case\n"
        "case = Case(name='flag_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='flag_bench')\n"
        "def flag_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    with pytest.raises(SystemExit):
        main([str(module_path), "--fail-on-regression", "5"])


def test_gc_control_disable_during_measure_restores_enabled_state() -> None:
    clear_registry()
    gc.enable()

    case = Case(
        name="gc_enabled_case",
        metric_type="time",
        repeats=1,
        min_iterations=1,
        warmup_iterations=0,
        gc_control="disable_during_measure",
    )

    @case.benchmark()
    def gc_enabled_bench() -> int:
        return 1

    run_cases(list_cases())
    assert gc.isenabled()


def test_gc_control_disable_during_measure_preserves_initial_disabled_state() -> None:
    clear_registry()
    gc.disable()
    try:
        case = Case(
            name="gc_disabled_case",
            metric_type="time",
            repeats=1,
            min_iterations=1,
            warmup_iterations=0,
            gc_control="disable_during_measure",
        )

        @case.benchmark()
        def gc_disabled_bench() -> int:
            return 1

        run_cases(list_cases())
        assert not gc.isenabled()
    finally:
        gc.enable()


def test_cli_run_writes_json(tmp_path: Path) -> None:
    clear_registry()

    module_path = tmp_path / "bench_mod.py"
    module_path.write_text(
        "from benchbro import Case\n"
        "case = Case(name='mod_group', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='mod_case')\n"
        "def mod_case():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    sys.path.insert(0, str(tmp_path))
    original_cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        output_path = tmp_path / "out.json"
        markdown_path = tmp_path / "out.md"
        code = main(
            [
                "bench_mod",
                "--output-json",
                str(output_path),
                "--output-md",
                str(markdown_path),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0
        payload = json.loads(output_path.read_text(encoding="utf-8"))
        assert "environment" in payload
        assert "python_version" in payload["environment"]
        assert payload["benchmarks"][0]["metric_type"] == "time"
        assert payload["benchmarks"][0]["case_name"] == "mod_group"
        assert payload["benchmarks"][0]["benchmark_name"] == "mod_case"
        assert "metrics" in payload["benchmarks"][0]
        assert "environment" in payload["benchmarks"][0]
        assert (
            payload["benchmarks"][0]["environment"]["python_version"]
            == payload["environment"]["python_version"]
        )
        markdown = markdown_path.read_text(encoding="utf-8")
        assert "# Benchbro Results" in markdown
        assert "| case | benchmark | metric_type |" in markdown
        assert "mod_group" in markdown
        assert "mod_case" in markdown
    finally:
        os.chdir(original_cwd)
        sys.path.remove(str(tmp_path))


def test_cli_run_supports_async_benchmark_module(tmp_path: Path) -> None:
    clear_registry()

    module_path = tmp_path / "bench_async_mod.py"
    module_path.write_text(
        "from benchbro import Case\n"
        "case = Case(name='async_mod_group', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.input()\n"
        "async def payload():\n"
        "    return b'xyz'\n"
        "@case.benchmark(name='async_mod_case')\n"
        "async def async_mod_case(payload: bytes):\n"
        "    return len(payload)\n",
        encoding="utf-8",
    )

    output_path = tmp_path / "async_out.json"
    original_cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        code = main(
            [
                str(module_path),
                "--output-json",
                str(output_path),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
    finally:
        os.chdir(original_cwd)
    assert code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["benchmarks"][0]["case_name"] == "async_mod_group"
    assert payload["benchmarks"][0]["benchmark_name"] == "async_mod_case"


def test_cli_run_supports_standalone_system_module(tmp_path: Path) -> None:
    clear_registry()

    module_path = tmp_path / "bench_system_mod.py"
    module_path.write_text(
        "from benchbro import Case, system\n"
        "@system(scope='module')\n"
        "def shared_value():\n"
        "    return 5\n"
        "case = Case(name='system_mod_group', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='system_mod_case')\n"
        "def system_mod_case(shared_value: int):\n"
        "    return shared_value\n",
        encoding="utf-8",
    )

    output_path = tmp_path / "system_out.json"
    original_cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        code = main(
            [
                str(module_path),
                "--output-json",
                str(output_path),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
    finally:
        os.chdir(original_cwd)
    assert code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["benchmarks"][0]["case_name"] == "system_mod_group"
    assert payload["benchmarks"][0]["benchmark_name"] == "system_mod_case"


def test_cli_run_supports_command_benchmark_module(tmp_path: Path) -> None:
    clear_registry()

    module_path = tmp_path / "bench_command_mod.py"
    module_path.write_text(
        "import sys\n"
        "from benchbro import Case, CommandSpec\n"
        "case = Case(name='command_mod_group', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.subprocess(name='command_mod_case')\n"
        "def command_mod_case() -> CommandSpec:\n"
        "    return CommandSpec(argv=[sys.executable, '-c', 'pass'])\n",
        encoding="utf-8",
    )

    output_path = tmp_path / "command_out.json"
    original_cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        code = main(
            [
                str(module_path),
                "--output-json",
                str(output_path),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
    finally:
        os.chdir(original_cwd)
    assert code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["benchmarks"][0]["case_name"] == "command_mod_group"
    assert payload["benchmarks"][0]["benchmark_name"] == "command_mod_case"


def test_cli_run_accepts_python_file_path(tmp_path: Path) -> None:
    clear_registry()

    module_path = tmp_path / "bench_file.py"
    module_path.write_text(
        "from benchbro import Case\n"
        "case = Case(name='file_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='file_bench')\n"
        "def file_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    output_path = tmp_path / "out_file.json"
    original_cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        code = main(
            [
                str(module_path),
                "--output-json",
                str(output_path),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
    finally:
        os.chdir(original_cwd)
    assert code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["benchmarks"][0]["case_name"] == "file_case"
    assert payload["benchmarks"][0]["benchmark_name"] == "file_bench"


def test_cli_runs_without_subcommands(tmp_path: Path) -> None:
    clear_registry()

    module_path = tmp_path / "bench_shorthand.py"
    module_path.write_text(
        "from benchbro import Case\n"
        "case = Case(name='short_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='short_bench')\n"
        "def short_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    output_path = tmp_path / "short.json"
    original_cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        code = main(
            [
                str(module_path),
                "--output-json",
                str(output_path),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
    finally:
        os.chdir(original_cwd)
    assert code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["benchmarks"][0]["case_name"] == "short_case"
    assert payload["benchmarks"][0]["benchmark_name"] == "short_bench"


def test_cli_run_accepts_directory_path(tmp_path: Path) -> None:
    clear_registry()

    benchmarks_dir = tmp_path / "benches"
    benchmarks_dir.mkdir()
    (benchmarks_dir / "math_benchmarks.py").write_text(
        "from benchbro import Case\n"
        "case = Case(name='dir_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='dir_bench')\n"
        "def dir_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )
    (benchmarks_dir / "ignore_me.py").write_text("x = 1\n", encoding="utf-8")

    output_path = tmp_path / "out_dir.json"
    original_cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        code = main(
            [
                str(benchmarks_dir),
                "--output-json",
                str(output_path),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
    finally:
        os.chdir(original_cwd)
    assert code == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert len(payload["benchmarks"]) == 1
    assert payload["benchmarks"][0]["case_name"] == "dir_case"
    assert payload["benchmarks"][0]["benchmark_name"] == "dir_bench"


def test_cli_run_writes_default_outputs_to_repo_root(tmp_path: Path) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    benchmark_file = repo_root / "sample_benchmarks.py"
    benchmark_file.write_text(
        "from benchbro import Case\n"
        "case = Case(name='default_output_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='default_output_bench')\n"
        "def default_output_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        code = main(
            [
                str(benchmark_file),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0

        default_json = repo_root / ".benchbro" / "current.json"
        default_csv = repo_root / ".benchbro" / "current.csv"
        baseline_json = repo_root / ".benchbro" / "baseline.local.json"
        assert not default_json.exists()
        assert not default_csv.exists()
        assert baseline_json.exists()
    finally:
        os.chdir(original_cwd)


def test_cli_run_creates_repo_local_baseline_json_when_missing(tmp_path: Path) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    benchmark_file = repo_root / "sample_benchmarks.py"
    benchmark_file.write_text(
        "from benchbro import Case\n"
        "case = Case(name='baseline_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='baseline_bench')\n"
        "def baseline_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        code = main(
            [
                str(benchmark_file),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0

        baseline_json = repo_root / ".benchbro" / "baseline.local.json"
        assert baseline_json.exists()
        payload = json.loads(baseline_json.read_text(encoding="utf-8"))
        assert payload["benchmarks"][0]["case_name"] == "baseline_case"
        assert payload["benchmarks"][0]["benchmark_name"] == "baseline_bench"
        assert "environment" in payload
        assert "gc_enabled_at_start" in payload["environment"]
        assert "gc_threshold" in payload["environment"]
    finally:
        os.chdir(original_cwd)


def test_cli_run_creates_repo_ci_baseline_yaml_when_ci_flag_set(
    tmp_path: Path,
) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    benchmark_file = repo_root / "sample_benchmarks.py"
    benchmark_file.write_text(
        "from benchbro import Case\n"
        "case = Case(name='baseline_ci_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='baseline_ci_bench')\n"
        "def baseline_ci_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        code = main(
            [
                str(benchmark_file),
                "--ci",
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0

        baseline_json = repo_root / ".benchbro" / "baseline.local.json"
        baseline_ci_yaml = repo_root / ".benchbro/baseline.ci.json"
        assert not baseline_json.exists()
        assert baseline_ci_yaml.exists()
        payload = json.loads(baseline_ci_yaml.read_text(encoding="utf-8"))
        assert payload["benchmarks"][0]["case_name"] == "baseline_ci_case"
        assert payload["benchmarks"][0]["benchmark_name"] == "baseline_ci_bench"
    finally:
        os.chdir(original_cwd)


def test_cli_no_compare_skips_comparison_and_returns_zero(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    clear_registry()
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    module = repo_root / "bench_no_compare.py"
    module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='no_compare_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='bench')\n"
        "def bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        assert (
            main(
                [
                    str(module),
                    "--warmup",
                    "0",
                    "--repeats",
                    "1",
                    "--min-iterations",
                    "1",
                ]
            )
            == 0
        )
        code = main(
            [
                str(module),
                "--no-compare",
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0
    finally:
        os.chdir(original_cwd)

    output = capsys.readouterr().out
    assert "Comparison skipped" in output


def test_cli_no_compare_merges_new_benchmark(tmp_path: Path) -> None:
    clear_registry()
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    first_module = repo_root / "bench_first.py"
    first_module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='no_compare_merge_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='one')\n"
        "def one():\n"
        "    return 1\n",
        encoding="utf-8",
    )
    second_module = repo_root / "bench_second.py"
    second_module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='no_compare_merge_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='one')\n"
        "def one():\n"
        "    return 1\n"
        "@case.benchmark(name='two')\n"
        "def two():\n"
        "    return 1\n",
        encoding="utf-8",
    )
    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        assert (
            main(
                [
                    str(first_module),
                    "--warmup",
                    "0",
                    "--repeats",
                    "1",
                    "--min-iterations",
                    "1",
                ]
            )
            == 0
        )
        assert (
            main(
                [
                    str(second_module),
                    "--no-compare",
                    "--warmup",
                    "0",
                    "--repeats",
                    "1",
                    "--min-iterations",
                    "1",
                ]
            )
            == 0
        )
        baseline_local = repo_root / ".benchbro" / "baseline.local.json"
        payload = json.loads(baseline_local.read_text(encoding="utf-8"))
        names = {
            (item["case_name"], item["benchmark_name"])
            for item in payload["benchmarks"]
        }
        assert ("no_compare_merge_case", "one") in names
        assert ("no_compare_merge_case", "two") in names
    finally:
        os.chdir(original_cwd)


def test_cli_histogram_outputs_for_time_benchmarks(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    clear_registry()
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()
    module = repo_root / "bench_hist.py"
    module.write_text(
        "from benchbro import Case\n"
        "import time\n"
        "case = Case(name='hist_case', metric_type='time', repeats=5, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='hist_bench')\n"
        "def hist_bench():\n"
        "    time.sleep(0.0001)\n",
        encoding="utf-8",
    )
    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        code = main(
            [
                str(module),
                "--histogram",
                "--warmup",
                "0",
                "--repeats",
                "5",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0
    finally:
        os.chdir(original_cwd)

    output = capsys.readouterr().out
    assert "Histogram: hist_case::hist_bench" in output


def test_cli_histogram_memory_only_prints_info(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    clear_registry()
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()
    module = repo_root / "bench_mem_hist.py"
    module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='mem_hist_case', metric_type='memory', repeats=2, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='alloc')\n"
        "def alloc():\n"
        "    return [1,2,3]\n",
        encoding="utf-8",
    )
    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        code = main(
            [
                str(module),
                "--histogram",
                "--warmup",
                "0",
                "--repeats",
                "2",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0
    finally:
        os.chdir(original_cwd)

    output = capsys.readouterr().out
    assert "No time samples available for histogram output." in output


def test_cli_ci_no_compare_uses_ci_baseline_yaml(tmp_path: Path) -> None:
    clear_registry()
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()
    module = repo_root / "bench_ci_no_compare.py"
    module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='ci_no_compare_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='bench')\n"
        "def bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )
    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        assert (
            main(
                [
                    str(module),
                    "--ci",
                    "--warmup",
                    "0",
                    "--repeats",
                    "1",
                    "--min-iterations",
                    "1",
                ]
            )
            == 0
        )
        code = main(
            [
                str(module),
                "--ci",
                "--no-compare",
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0
        assert (repo_root / ".benchbro/baseline.ci.json").exists()
    finally:
        os.chdir(original_cwd)


def test_cli_new_baseline_takes_precedence_over_no_compare(tmp_path: Path) -> None:
    clear_registry()
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()
    module = repo_root / "bench_new_over_no_compare.py"
    module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='new_over_no_compare_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='bench')\n"
        "def bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )
    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        code = main(
            [
                str(module),
                "--new-baseline",
                "--no-compare",
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0
        assert (repo_root / ".benchbro" / "baseline.local.json").exists()
    finally:
        os.chdir(original_cwd)


def test_cli_run_uses_default_benchmarks_directory(tmp_path: Path) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()
    benchmarks_dir = repo_root / "benchmarks" / "nested"
    benchmarks_dir.mkdir(parents=True)

    benchmark_file = benchmarks_dir / "sample_benchmarks.py"
    benchmark_file.write_text(
        "from benchbro import Case\n"
        "case = Case(name='default_target_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='default_target_bench')\n"
        "def default_target_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )
    non_matching_file = benchmarks_dir / "custom_name.py"
    non_matching_file.write_text(
        "from benchbro import Case\n"
        "case = Case(name='default_target_case_extra', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='default_target_bench_extra')\n"
        "def default_target_bench_extra():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    out_json = repo_root / "artifacts.json"
    out_csv = repo_root / "artifacts.csv"
    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        code = main(
            [
                "--output-json",
                str(out_json),
                "--output-csv",
                str(out_csv),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0
        payload = json.loads(out_json.read_text(encoding="utf-8"))
        assert {item["case_name"] for item in payload["benchmarks"]} == {
            "default_target_case"
        }
        assert {item["benchmark_name"] for item in payload["benchmarks"]} == {
            "default_target_bench"
        }
        assert out_csv.exists()
    finally:
        os.chdir(original_cwd)


def test_cli_uses_pyproject_ini_options_for_paths_and_pattern(tmp_path: Path) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()
    (repo_root / "pyproject.toml").write_text(
        "[project]\n"
        "name = 'benchbro'\n"
        "version = '0.0.0'\n"
        "requires-python = '>=3.13'\n"
        "\n"
        "[tool.benchbro.ini_options]\n"
        "benchmark_paths = ['custom_benchmarks']\n"
        "file_pattern = 'custom_*.py'\n",
        encoding="utf-8",
    )

    benchmarks_dir = repo_root / "custom_benchmarks"
    benchmarks_dir.mkdir()
    (benchmarks_dir / "custom_hash.py").write_text(
        "from benchbro import Case\n"
        "case = Case(name='configured_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='configured_bench')\n"
        "def configured_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )
    (benchmarks_dir / "ignored_benchmarks.py").write_text(
        "from benchbro import Case\n"
        "case = Case(name='ignored_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='ignored_bench')\n"
        "def ignored_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    out_json = repo_root / "configured.json"
    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        code = main(
            [
                "--output-json",
                str(out_json),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert code == 0
    finally:
        os.chdir(original_cwd)

    payload = json.loads(out_json.read_text(encoding="utf-8"))
    assert {item["case_name"] for item in payload["benchmarks"]} == {"configured_case"}
    assert {item["benchmark_name"] for item in payload["benchmarks"]} == {
        "configured_bench"
    }


def test_cli_run_merges_new_benchmark_into_existing_baseline(tmp_path: Path) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    first_module = repo_root / "bench_one.py"
    first_module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='merge_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='one')\n"
        "def one():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    second_module = repo_root / "bench_two.py"
    second_module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='merge_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='one')\n"
        "def one():\n"
        "    return 1\n"
        "@case.benchmark(name='two')\n"
        "def two():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        first_code = main(
            [
                str(first_module),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert first_code == 0

        second_code = main(
            [
                str(second_module),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert second_code == 0

        baseline_json = repo_root / ".benchbro" / "baseline.local.json"
        payload = json.loads(baseline_json.read_text(encoding="utf-8"))
        names = {
            (item["case_name"], item["benchmark_name"])
            for item in payload["benchmarks"]
        }
        assert ("merge_case", "one") in names
        assert ("merge_case", "two") in names
    finally:
        os.chdir(original_cwd)


def test_cli_comparison_output_includes_threshold_column(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    baseline_module = repo_root / "bench_baseline.py"
    baseline_module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='cmp_table_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='cmp_bench')\n"
        "def cmp_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    current_module = repo_root / "bench_current.py"
    current_module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='cmp_table_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0, warning_threshold_pct=2.0, regression_threshold_pct=5.0)\n"
        "@case.benchmark(name='cmp_bench')\n"
        "def cmp_bench():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        first_code = main(
            [
                str(baseline_module),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert first_code == 0

        second_code = main(
            [
                str(current_module),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert second_code in (0, 2)
    finally:
        os.chdir(original_cwd)

    output = capsys.readouterr().out
    assert "Benchmark Comparison" in output
    assert "/" in output
    assert "5.00%" in output


def test_cli_shows_warning_status_between_warning_and_error(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    baseline_module = repo_root / "bench_warning_base.py"
    baseline_module.write_text(
        "from benchbro import Case\n"
        "import time\n"
        "case = Case(name='warn_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='warn_bench')\n"
        "def warn_bench():\n"
        "    time.sleep(0.002)\n",
        encoding="utf-8",
    )

    current_module = repo_root / "bench_warning_current.py"
    current_module.write_text(
        "from benchbro import Case\n"
        "import time\n"
        "case = Case(name='warn_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0, warning_threshold_pct=10.0, regression_threshold_pct=100.0)\n"
        "@case.benchmark(name='warn_bench')\n"
        "def warn_bench():\n"
        "    time.sleep(0.003)\n",
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        first_code = main(
            [
                str(baseline_module),
                "--new-baseline",
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert first_code == 0

        second_code = main(
            [
                str(current_module),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert second_code == 0
    finally:
        os.chdir(original_cwd)

    output = capsys.readouterr().out
    assert "WARN" in output


def test_cli_new_baseline_replaces_existing_baseline(tmp_path: Path) -> None:
    clear_registry()

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (repo_root / ".git").mkdir()

    first_module = repo_root / "bench_original.py"
    first_module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='replace_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='original')\n"
        "def original():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    second_module = repo_root / "bench_new.py"
    second_module.write_text(
        "from benchbro import Case\n"
        "case = Case(name='replace_case', metric_type='time', repeats=1, min_iterations=1, warmup_iterations=0)\n"
        "@case.benchmark(name='new_only')\n"
        "def new_only():\n"
        "    return 1\n",
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    try:
        os.chdir(repo_root)
        first_code = main(
            [
                str(first_module),
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert first_code == 0

        second_code = main(
            [
                str(second_module),
                "--new-baseline",
                "--warmup",
                "0",
                "--repeats",
                "1",
                "--min-iterations",
                "1",
            ]
        )
        assert second_code == 0

        baseline_json = repo_root / ".benchbro" / "baseline.local.json"
        payload = json.loads(baseline_json.read_text(encoding="utf-8"))
        names = {
            (item["case_name"], item["benchmark_name"])
            for item in payload["benchmarks"]
        }
        assert names == {("replace_case", "new_only")}
    finally:
        os.chdir(original_cwd)
