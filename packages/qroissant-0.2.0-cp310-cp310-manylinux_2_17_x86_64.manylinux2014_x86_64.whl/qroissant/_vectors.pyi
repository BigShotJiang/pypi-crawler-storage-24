from __future__ import annotations

from typing import TypeAlias

from qroissant._protocols import ArrowArrayExportable
from qroissant._protocols import ArrowSchemaExportable
from qroissant._attribute import Attribute

class _AnyVector(ArrowSchemaExportable, ArrowArrayExportable):
    """Common behavior for homogeneous q vectors."""

    def __len__(self) -> int: ...
    @property
    def attribute(self) -> Attribute: ...

class BooleanVector(_AnyVector):
    ...

class GuidVector(_AnyVector):
    ...

class ByteVector(_AnyVector):
    ...

class ShortVector(_AnyVector):
    ...

class IntVector(_AnyVector):
    ...

class LongVector(_AnyVector):
    ...

class RealVector(_AnyVector):
    ...

class FloatVector(_AnyVector):
    ...

class CharVector(_AnyVector):
    ...

class SymbolVector(_AnyVector):
    ...

class TimestampVector(_AnyVector):
    ...

class MonthVector(_AnyVector):
    ...

class DateVector(_AnyVector):
    ...

class DatetimeVector(_AnyVector):
    ...

class TimespanVector(_AnyVector):
    ...

class MinuteVector(_AnyVector):
    ...

class SecondVector(_AnyVector):
    ...

class TimeVector(_AnyVector):
    ...

Vector: TypeAlias = (
    BooleanVector
    | GuidVector
    | ByteVector
    | ShortVector
    | IntVector
    | LongVector
    | RealVector
    | FloatVector
    | CharVector
    | SymbolVector
    | TimestampVector
    | MonthVector
    | DateVector
    | DatetimeVector
    | TimespanVector
    | MinuteVector
    | SecondVector
    | TimeVector
)
