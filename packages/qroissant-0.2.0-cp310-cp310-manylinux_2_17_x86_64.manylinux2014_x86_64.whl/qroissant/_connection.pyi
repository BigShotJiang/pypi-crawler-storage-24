from __future__ import annotations

from types import TracebackType

from qroissant._typing import MessageBody

class TCPOptions:
    """TCP transport options."""

    def __new__(
        cls,
        *,
        host: str,
        port: int,
        username: str | None = None,
        password: str | None = None,
    ) -> TCPOptions: ...
    @property
    def host(self) -> str: ...
    @property
    def port(self) -> int: ...
    @property
    def username(self) -> str | None: ...
    @property
    def password(self) -> str | None: ...

class UnixOptions:
    """Unix socket transport options."""

    def __new__(
        cls,
        *,
        path: str,
    ) -> UnixOptions: ...
    @property
    def path(self) -> str: ...

class TCPStream:
    """Connection to a q process over TCP."""

    def __new__(cls, *, options: TCPOptions) -> TCPStream: ...
    def __enter__(self) -> TCPStream: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...
    def send_sync(self, message: str, /) -> MessageBody:
        """Send a synchronous q expression and decode the response.

        Parameters
        ----------
        message : str
            q expression to evaluate on the remote process.

        Returns
        -------
        MessageBody
            Decoded response object.
        """
        ...

class UnixStream:
    """Connection to a q process over a Unix domain socket."""

    def __new__(cls, options: UnixOptions, /) -> UnixStream: ...
    def __enter__(self) -> UnixStream: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...
    def send_sync(self, message: str, /) -> MessageBody:
        """Send a synchronous q expression and decode the response.

        Parameters
        ----------
        message : str
            q expression to evaluate on the remote process.

        Returns
        -------
        MessageBody
            Decoded response object.
        """
        ...
