from __future__ import annotations

from qroissant._protocols import ArrowArrayExportable
from qroissant._protocols import ArrowSchemaExportable

class Dictionary(ArrowSchemaExportable, ArrowArrayExportable):
    """q dictionary wrapper."""

    @property
    def keys(self) -> object: ...
    @property
    def values(self) -> object: ...
    @property
    def sorted(self) -> bool: ...
