from __future__ import annotations

from typing import TypeAlias

from qroissant._protocols import ArrowArrayExportable
from qroissant._protocols import ArrowSchemaExportable

class _AnyAtom(ArrowSchemaExportable, ArrowArrayExportable):
    """Base protocol for scalar q atoms."""

class BooleanAtom(_AnyAtom):
    ...

class GuidAtom(_AnyAtom):
    ...

class ByteAtom(_AnyAtom):
    ...

class ShortAtom(_AnyAtom):
    ...

class IntAtom(_AnyAtom):
    ...

class LongAtom(_AnyAtom):
    ...

class RealAtom(_AnyAtom):
    ...

class FloatAtom(_AnyAtom):
    ...

class CharAtom(_AnyAtom):
    ...

class SymbolAtom(_AnyAtom):
    ...

class TimestampAtom(_AnyAtom):
    ...

class MonthAtom(_AnyAtom):
    ...

class DateAtom(_AnyAtom):
    ...

class DatetimeAtom(_AnyAtom):
    ...

class TimespanAtom(_AnyAtom):
    ...

class MinuteAtom(_AnyAtom):
    ...

class SecondAtom(_AnyAtom):
    ...

class TimeAtom(_AnyAtom):
    ...

Atom: TypeAlias = (
    BooleanAtom
    | GuidAtom
    | ByteAtom
    | ShortAtom
    | IntAtom
    | LongAtom
    | RealAtom
    | FloatAtom
    | CharAtom
    | SymbolAtom
    | TimestampAtom
    | MonthAtom
    | DateAtom
    | DatetimeAtom
    | TimespanAtom
    | MinuteAtom
    | SecondAtom
    | TimeAtom
)
