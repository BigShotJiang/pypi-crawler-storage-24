from __future__ import annotations

from typing import Generic
from typing import TypeVar

from qroissant._protocols import ArrowArrayExportable
from qroissant._protocols import ArrowSchemaExportable
from qroissant._attribute import Attribute

_TValue = TypeVar("_TValue")

class List(ArrowSchemaExportable, ArrowArrayExportable, Generic[_TValue]):
    """q general list wrapper returned by qroissant."""

    def __len__(self) -> int: ...
    @property
    def attribute(self) -> Attribute: ...
    @property
    def values(self) -> list[_TValue]: ...
