from __future__ import annotations

from typing import Protocol

class ArrowSchemaExportable(Protocol):
    """Object that can export an Arrow C schema capsule."""

    def __arrow_c_schema__(self) -> object: ...

class ArrowArrayExportable(Protocol):
    """Object that can export Arrow C array + schema capsules."""

    def __arrow_c_array__(
        self, requested_schema: object | None = None
    ) -> tuple[object, object]: ...

class ArrowStreamExportable(Protocol):
    """Object that can export an Arrow C stream capsule."""

    def __arrow_c_stream__(self, requested_schema: object | None = None) -> object: ...
