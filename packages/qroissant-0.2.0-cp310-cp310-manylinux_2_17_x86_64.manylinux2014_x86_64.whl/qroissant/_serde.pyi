from __future__ import annotations

from typing import TYPE_CHECKING
from typing import Protocol

from qroissant._message_header import Compression
from qroissant._message_header import Encoding
from qroissant._message_header import MessageType
from qroissant._options import Options

if TYPE_CHECKING:
    from qroissant._typing import MessageBody

class Serializable(Protocol):
    """Object that can be serialized into q IPC bytes."""

    def serialize(
        self,
        *,
        encoding: Encoding = Encoding.LITTLE_ENDIAN,
        message_type: MessageType = MessageType.ASYNCHRONOUS,
        compression: Compression = Compression.UNCOMPRESSED,
    ) -> bytes:
        """Serialize an object into q IPC message bytes.

        Parameters
        ----------
        encoding : Encoding, default=Encoding.LITTLE_ENDIAN
            Endianness used in the generated IPC payload.
        message_type : MessageType, default=MessageType.ASYNCHRONOUS
            IPC message type tag.
        compression : Compression, default=Compression.UNCOMPRESSED
            Compression mode for payload encoding.

        Returns
        -------
        bytes
            Serialized IPC payload.
        """
        ...

def deserialize(
    payload: object, /, *, options: Options | None = None
) -> MessageBody:
    """Deserialize an IPC payload into a typed qroissant value.

    Parameters
    ----------
    payload : object
        Raw q IPC payload as ``bytes``, a read-only contiguous buffer,
        or an object exposing such a buffer via ``.data``. For PyKX
        serializer objects, pass the serializer itself rather than
        ``serializer.data`` so the backing memory stays alive.

    Returns
    -------
    MessageBody
        Decoded q object represented by qroissant wrapper types.
    """
    ...
