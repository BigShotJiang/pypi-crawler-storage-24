from __future__ import annotations

import enum

class Attribute(enum.IntEnum):
    """q attribute values for vectors, lists, and tables."""

    NONE = 0
    SORTED = 1
    UNIQUE = 2
    PARTED = 3
    GROUPED = 4
