from __future__ import annotations

from typing import TypeAlias

from qroissant._atoms import Atom
from qroissant._vectors import Vector
from qroissant._list import List
from qroissant._dictionary import Dictionary
from qroissant._table import Table

MessageBody: TypeAlias = Atom | Vector | List[object] | Dictionary | Table
