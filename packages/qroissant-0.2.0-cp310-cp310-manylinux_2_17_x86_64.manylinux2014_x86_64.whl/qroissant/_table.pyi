from __future__ import annotations

from qroissant._attribute import Attribute
from qroissant._dictionary import Dictionary
from qroissant._protocols import ArrowArrayExportable
from qroissant._protocols import ArrowSchemaExportable
from qroissant._protocols import ArrowStreamExportable

class Table(ArrowSchemaExportable, ArrowArrayExportable, ArrowStreamExportable):
    """q table wrapper backed by a column dictionary."""

    def __len__(self) -> int: ...
    @property
    def values(self) -> Dictionary: ...
    @property
    def attribute(self) -> Attribute: ...
