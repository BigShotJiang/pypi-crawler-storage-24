from __future__ import annotations

import enum

class Encoding(enum.IntEnum):
    """IPC payload byte order."""

    BIG_ENDIAN = 0
    LITTLE_ENDIAN = 1

class MessageType(enum.IntEnum):
    """q IPC message kind."""

    ASYNCHRONOUS = 0
    SYNCHRONOUS = 1
    RESPONSE = 2

class Compression(enum.IntEnum):
    """IPC payload compression mode."""

    UNCOMPRESSED = 0
    COMPRESSED = 1
    COMPRESSED_LARGE = 2

class MessageHeader:
    """q IPC message header metadata."""

    def __new__(
        cls,
        *,
        encoding: Encoding,
        message_type: MessageType,
        compression: Compression,
        message_length: int,
    ) -> MessageHeader: ...
    @property
    def encoding(self) -> Encoding: ...
    @property
    def message_type(self) -> MessageType: ...
    @property
    def compression(self) -> Compression: ...
    @property
    def message_length(self) -> int: ...
