"""llmpm — LLM Package Manager."""

__version__ = "3.1.1"
__author__ = "llmpm contributors"
