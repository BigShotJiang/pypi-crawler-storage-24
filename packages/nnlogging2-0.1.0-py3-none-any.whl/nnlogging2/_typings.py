from __future__ import annotations

import collections.abc as _atp
import logging
import typing as _tp

TpVar = _tp.TypeVar


_T = TpVar("_T")
_K = TpVar("_K")
_V = TpVar("_V")


type LogLevel = int | str
type Any = _tp.Any  # pyright: ignore[reportExplicitAny]
type SIO = _tp.TextIO


Prot = _tp.Protocol
override = _tp.override
overload = _tp.overload
cast = _tp.cast
TDict = _tp.TypedDict
Literal = _tp.Literal
Iter = _atp.Iterable
IMap = _atp.Mapping
MMap = _atp.MutableMapping
Self = _tp.Self
Seq = _atp.Sequence

# Promoted logger type
PLoggerT = TpVar("PLoggerT", bound=logging.Logger)


# Metric content type & Metric update content type
MetContT = TpVar("MetContT", bound=float | None)
MetUpContT = MetContT | Iter[MetContT]


# Metric-Format pair type
type MetFmt = tuple[str, str | None] | tuple[str] | str


class UpMetProt(Prot):
    """Updatable metric protocol."""

    def __init__(self) -> None: ...
    def update(self, cont: MetUpContT[Any], /) -> None: ...
    @property
    def val(self) -> float: ...


# Tedious sequence that could exclude `str` and so on
TdSeq = list[_T] | tuple[_T, ...]


class OneMetRecDict(TDict):
    """One metric record protocol."""

    attrs: dict[str, str | float]
    fmtstr: str | None


type MetRecDict = dict[str, OneMetRecDict]
type CtxRecDict = dict[str, Any]
