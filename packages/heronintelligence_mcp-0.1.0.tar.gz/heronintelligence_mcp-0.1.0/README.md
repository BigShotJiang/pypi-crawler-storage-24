# Aura MCP

Aura Financial Intelligence — MCP server for AI assistants.

Connect Aura's financial research capabilities (earnings call transcripts,
due diligence interviews, red flag analysis) directly to Claude, Cursor,
or any MCP-compatible client.

## Requirements

- An active Aura account with an API key
- `uvx` (no other installation needed)

## Installation

### Claude Desktop

Add to `~/.claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "aura": {
      "command": "uvx",
      "args": ["--from", "HeronIntelligence-mcp", "heronintelligence-mcp"],
      "env": {
        "AURA_API_URL": "https://api.aura.com",
        "AURA_API_KEY": "aura-key-xxxx"
      }
    }
  }
}
```

Restart Claude Desktop. Aura will appear as an active tool.

### Claude Code

```bash
claude mcp add heron \
  --command uvx \
  --args "--from HeronIntelligence-mcp heronintelligence-mcp" \
  -e AURA_API_URL=https://api.aura.com \
  -e AURA_API_KEY=aura-key-xxxx \
  -s user
```

### Cursor / Windsurf

Add to your MCP config:

```json
{
  "mcpServers": {
    "aura": {
      "command": "uvx",
      "args": ["--from", "HeronIntelligence-mcp", "heronintelligence-mcp"],
      "env": {
        "AURA_API_URL": "https://api.aura.com",
        "AURA_API_KEY": "aura-key-xxxx"
      }
    }
  }
}
```

## Available Tools

| Tool | Description |
| --- | --- |
| `search_company` | Find a company by name, ticker, or description |
| `get_recent_transcripts` | List transcripts for a company over the last N quarters |
| `analyze_red_flags` | Deep risk analysis with citations — powered by Aura's ReAct agent |
| `get_transcript_content` | Fetch full transcript content by ID |

## Example Queries

Once connected, ask your AI assistant:

> *"What are the red flags for Rappi in the last 3 quarters?"*
> *"What is Nubank's management saying about churn this year?"*
> *"Compare the tone of Mercado Libre vs Kavak interviewees"*
> *"Executive summary of the last 3 earnings calls for {company}"*

## Environment Variables

| Variable | Description |
| --- | --- |
| `AURA_API_URL` | Base URL of the Aura API (provided by Aura) |
| `AURA_API_KEY` | Your Aura API key (from your account dashboard) |

## License

Proprietary — requires an active Aura subscription.
