use fp_checker_core::{ParserAdapter, RuleId, RustPythonParser};

#[test]
fn parser_extracts_functions_and_ignore_directives() {
    let source = r"
def top(value, items=[]):
    return value

class Service:
    @fp_ignore
    def method(self):
        return items
";

    let parsed = RustPythonParser.parse_module(source, "memory.py", "fp_ignore");

    assert!(parsed.diagnostics.is_empty());
    assert_eq!(parsed.module.functions.len(), 2);
    assert_eq!(parsed.module.functions[0].qualified_name, "top");
    assert_eq!(parsed.module.functions[1].qualified_name, "Service.method");
    assert_eq!(
        parsed.module.functions[1].class_name.as_deref(),
        Some("Service")
    );
    assert!(parsed.module.functions[0].ignore.is_none());
    assert!(parsed.module.functions[1].ignore.is_some());
    assert_eq!(parsed.module.functions[0].parameters.len(), 2);
}

#[test]
fn parser_reports_parse_errors_without_panicking() {
    let parsed =
        RustPythonParser.parse_module("def broken(:\n    return 1\n", "broken.py", "fp_ignore");

    assert_eq!(parsed.module.functions.len(), 0);
    assert_eq!(parsed.diagnostics.len(), 1);
    assert_eq!(parsed.diagnostics[0].rule_id, RuleId::ParseError);
    assert_eq!(parsed.diagnostics[0].severity.to_string(), "error");
}
