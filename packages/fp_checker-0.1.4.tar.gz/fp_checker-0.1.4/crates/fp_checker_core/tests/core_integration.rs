use fp_checker_core::{check_code, load_config_from_path, CheckerConfig, RuleId};
use std::collections::BTreeSet;
use std::path::PathBuf;

fn fixture_path(relative: &str) -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../tests/fixtures")
        .join(relative)
}

#[test]
fn check_code_reports_ignore_and_core_rules() {
    let source = r#"
STATE = []

@fp_ignore
def ignored():
    print("x")
    return STATE

def active(items=[]):
    print("x")
    return STATE
"#;
    let report = check_code(source, "memory.py", &CheckerConfig::default());

    assert_eq!(report.summary.checked_functions, 1);
    assert_eq!(report.summary.ignored_functions, 1);

    let rule_ids = report
        .files
        .iter()
        .flat_map(|file| {
            file.diagnostics
                .iter()
                .map(|diagnostic| diagnostic.rule_id.clone())
        })
        .collect::<BTreeSet<_>>();

    assert!(rule_ids.contains(&RuleId::MutableDefaultArgument));
    assert!(rule_ids.contains(&RuleId::DirectIo));
    assert!(rule_ids.contains(&RuleId::MutableGlobalState));
}

#[test]
fn check_code_reports_parse_error_as_diagnostic() {
    let report = check_code(
        "def broken(:\n    return 1\n",
        "broken.py",
        &CheckerConfig::default(),
    );
    assert_eq!(report.summary.diagnostics, 1);
    assert_eq!(report.files[0].diagnostics[0].rule_id, RuleId::ParseError);
}

#[test]
fn load_config_from_pyproject_reads_tool_section() {
    let config = load_config_from_path(fixture_path("sample_project/pyproject.toml")).unwrap();
    assert_eq!(config.ignore_decorator_name, "fp_ignore");
    assert!(config.is_rule_enabled(&RuleId::MutableGlobalState));
    assert!(!config.is_rule_enabled(&RuleId::DirectIo));
}
