use crate::config::OutputFormat;
use crate::model::{Diagnostic, FixHint, RuleId, Severity};
use serde::Serialize;
use serde_json::json;
use std::collections::BTreeSet;

#[derive(Debug, Clone, Serialize)]
pub struct FileReport {
    pub path: String,
    pub checked_functions: usize,
    pub ignored_functions: usize,
    pub diagnostics: Vec<Diagnostic>,
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct Summary {
    pub files: usize,
    pub checked_functions: usize,
    pub ignored_functions: usize,
    pub diagnostics: usize,
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct Report {
    pub summary: Summary,
    pub files: Vec<FileReport>,
}

impl Report {
    #[must_use]
    pub fn should_fail(&self, fail_on: Severity) -> bool {
        self.files.iter().any(|file| {
            file.diagnostics
                .iter()
                .any(|diagnostic| diagnostic.severity >= fail_on)
        })
    }
}

/// レポートを text または JSON へ整形します。
///
/// # Errors
///
/// JSON 生成時にシリアライズへ失敗した場合に返します。
pub fn render_report(report: &Report, format: OutputFormat) -> Result<String, serde_json::Error> {
    match format {
        OutputFormat::Json => serde_json::to_string_pretty(report),
        OutputFormat::Sarif => serde_json::to_string_pretty(&build_sarif_report(report)),
        OutputFormat::Text => Ok(render_text(report)),
    }
}

fn render_text(report: &Report) -> String {
    let mut lines = Vec::new();
    lines.push("fp-checker report".to_owned());
    lines.push(format!(
        "files={} checked_functions={} ignored_functions={} diagnostics={}",
        report.summary.files,
        report.summary.checked_functions,
        report.summary.ignored_functions,
        report.summary.diagnostics
    ));

    for file in &report.files {
        lines.push(String::new());
        lines.push(format!(
            "{} (checked={}, ignored={}, diagnostics={})",
            file.path,
            file.checked_functions,
            file.ignored_functions,
            file.diagnostics.len()
        ));
        for diagnostic in &file.diagnostics {
            lines.push(format!(
                "  [{}] {}:{}:{} {} ({})",
                diagnostic.severity,
                diagnostic.path,
                diagnostic.location.start.line,
                diagnostic.location.start.column,
                diagnostic.message,
                diagnostic.rule_id
            ));
            if let Some(function) = &diagnostic.function {
                lines.push(format!("    function: {function}"));
            }
            if let Some(hint) = &diagnostic.hint {
                lines.push(format!("    hint: {hint}"));
            }
        }
    }

    lines.join("\n")
}

fn build_sarif_report(report: &Report) -> serde_json::Value {
    let mut artifacts = BTreeSet::new();
    let mut rules = BTreeSet::new();
    let mut results = Vec::new();

    for file in &report.files {
        artifacts.insert(file.path.clone());
        for diagnostic in &file.diagnostics {
            artifacts.insert(diagnostic.path.clone());
            rules.insert(diagnostic.rule_id.clone());
            results.push(build_sarif_result(diagnostic));
        }
    }

    json!({
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "fp-checker",
                        "informationUri": "https://github.com/sotanengel/python-fp-checker",
                        "rules": rules.iter().map(build_sarif_rule).collect::<Vec<_>>()
                    }
                },
                "artifacts": artifacts.into_iter().map(|uri| {
                    json!({
                        "location": {
                            "uri": uri
                        }
                    })
                }).collect::<Vec<_>>(),
                "results": results,
                "properties": {
                    "summary": {
                        "files": report.summary.files,
                        "checked_functions": report.summary.checked_functions,
                        "ignored_functions": report.summary.ignored_functions,
                        "diagnostics": report.summary.diagnostics
                    }
                }
            }
        ]
    })
}

fn build_sarif_rule(rule_id: &RuleId) -> serde_json::Value {
    json!({
        "id": rule_id.as_str(),
        "name": rule_id.as_str(),
        "shortDescription": {
            "text": sarif_rule_description(rule_id)
        },
        "help": {
            "text": sarif_rule_help(rule_id)
        }
    })
}

fn build_sarif_result(diagnostic: &Diagnostic) -> serde_json::Value {
    json!({
        "ruleId": diagnostic.rule_id.as_str(),
        "level": sarif_level(diagnostic.severity),
        "message": {
            "text": diagnostic.message
        },
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": diagnostic.path
                    },
                    "region": {
                        "startLine": diagnostic.location.start.line,
                        "startColumn": diagnostic.location.start.column,
                        "endLine": diagnostic.location.end.as_ref().map_or(diagnostic.location.start.line, |end| end.line),
                        "endColumn": diagnostic.location.end.as_ref().map_or(diagnostic.location.start.column, |end| end.column)
                    }
                }
            }
        ],
        "properties": build_sarif_properties(diagnostic)
    })
}

fn build_sarif_properties(diagnostic: &Diagnostic) -> serde_json::Value {
    let fix_hint = diagnostic.fix_hint.as_ref().map(build_sarif_fix_hint);
    json!({
        "function": diagnostic.function,
        "hint": diagnostic.hint,
        "fix_hint": fix_hint
    })
}

fn build_sarif_fix_hint(fix_hint: &FixHint) -> serde_json::Value {
    json!({
        "kind": fix_hint.kind,
        "summary": fix_hint.summary,
        "suggested_action": fix_hint.suggested_action
    })
}

fn sarif_level(severity: Severity) -> &'static str {
    match severity {
        Severity::Error => "error",
        Severity::Warning => "warning",
        Severity::Info => "note",
    }
}

fn sarif_rule_description(rule_id: &RuleId) -> String {
    match rule_id {
        RuleId::ParseError => "Reports Python syntax errors.".to_owned(),
        RuleId::MutableGlobalState => "Detects reads and writes of mutable global state.".to_owned(),
        RuleId::AssignmentOveruse => "Detects functions with too many assignments.".to_owned(),
        RuleId::DirectIo => "Detects direct I/O calls.".to_owned(),
        RuleId::NonDeterministicUse => "Detects non-deterministic calls.".to_owned(),
        RuleId::ExternalStateSideEffect => "Detects side effects on external state.".to_owned(),
        RuleId::MutableDefaultArgument => "Detects mutable default arguments.".to_owned(),
        RuleId::DirectEffectfulCall => "Detects direct calls with strong side effects.".to_owned(),
        RuleId::GlobalNonlocalUsage => "Detects `global` and `nonlocal` usage.".to_owned(),
        RuleId::HiddenMutation => "Detects hidden mutation of parameters and local state.".to_owned(),
        RuleId::LoopSideEffect => "Detects side effects inside loops.".to_owned(),
        RuleId::ExceptionControlFlow => "Detects exception-based control flow.".to_owned(),
        RuleId::ClassMethodSideEffect => {
            "Detects state changes and side effects inside class methods.".to_owned()
        }
        RuleId::ReferentialTransparencyBreak => {
            "Detects implicit dependencies and dynamic evaluation that break referential transparency.".to_owned()
        }
        RuleId::DeprecatedApiUse => "Detects deprecated API usage.".to_owned(),
        RuleId::Custom(id) => format!("Detects usages that match custom rule `{id}`."),
    }
}

fn sarif_rule_help(rule_id: &RuleId) -> String {
    match rule_id {
        RuleId::ParseError => "Fix the syntax error and run the checker again.".to_owned(),
        RuleId::MutableGlobalState => {
            "Pass state explicitly through arguments and return values.".to_owned()
        }
        RuleId::AssignmentOveruse => {
            "Reduce intermediate state and split the logic into smaller functions.".to_owned()
        }
        RuleId::DirectIo => "Move I/O to the function boundary.".to_owned(),
        RuleId::NonDeterministicUse => {
            "Inject time, randomness, and similar values as dependencies.".to_owned()
        }
        RuleId::ExternalStateSideEffect => "Return a new value instead of mutating external state.".to_owned(),
        RuleId::MutableDefaultArgument => {
            "Use `None` as the default and create the value inside the function.".to_owned()
        }
        RuleId::DirectEffectfulCall => {
            "Abstract the effectful call and inject it from the outside.".to_owned()
        }
        RuleId::GlobalNonlocalUsage => {
            "Avoid shared state and convert it into explicit value passing.".to_owned()
        }
        RuleId::HiddenMutation => {
            "Avoid in-place mutation and return a new collection.".to_owned()
        }
        RuleId::LoopSideEffect => "Move loop side effects outside the loop and aggregate them.".to_owned(),
        RuleId::ExceptionControlFlow => {
            "Use explicit branching or result values instead of exceptions.".to_owned()
        }
        RuleId::ClassMethodSideEffect => {
            "Do not update object state directly inside the method; return a new value and apply it outside.".to_owned()
        }
        RuleId::ReferentialTransparencyBreak => {
            "Replace implicit dependencies with arguments or explicit dependency injection.".to_owned()
        }
        RuleId::DeprecatedApiUse => "Replace it with a recommended alternative API.".to_owned(),
        RuleId::Custom(_) => "Follow the guidance defined in the custom rule configuration.".to_owned(),
    }
}
