use crate::config::{CheckerConfig, CustomRuleConfig, CustomRuleMatchType, CustomRuleTarget};
use crate::model::{
    Diagnostic, Expression, ExpressionKind, FixHint, FixKind, FunctionDef, Module, RuleId,
    Severity, Statement, StatementKind,
};
use std::collections::BTreeSet;

pub trait Rule {
    fn id(&self) -> RuleId;
    fn check(&self, module: &Module, function: &FunctionDef) -> Vec<Diagnostic>;
}

pub type RuleFactory = fn() -> Box<dyn Rule>;

pub fn run_rules(
    module: &Module,
    function: &FunctionDef,
    config: &CheckerConfig,
) -> Vec<Diagnostic> {
    let mut diagnostics = Vec::new();
    for rule in registered_rule_factories().iter().map(|factory| factory()) {
        if config.is_rule_enabled(&rule.id()) {
            diagnostics.extend(rule.check(module, function));
        }
    }
    diagnostics.extend(run_custom_rules(function, config));
    diagnostics
}

#[derive(Default)]
struct MutableGlobalStateRule;
#[derive(Default)]
struct AssignmentOveruseRule;
#[derive(Default)]
struct DirectIoRule;
#[derive(Default)]
struct NonDeterministicUseRule;
#[derive(Default)]
struct ExternalStateSideEffectRule;
#[derive(Default)]
struct MutableDefaultArgumentRule;
#[derive(Default)]
struct DirectEffectfulCallRule;
#[derive(Default)]
struct GlobalNonlocalUsageRule;
#[derive(Default)]
struct HiddenMutationRule;
#[derive(Default)]
struct LoopSideEffectRule;
#[derive(Default)]
struct ExceptionControlFlowRule;
#[derive(Default)]
struct ClassMethodSideEffectRule;
#[derive(Default)]
struct ReferentialTransparencyBreakRule;
#[derive(Default)]
struct DeprecatedApiUseRule;

fn registered_rule_factories() -> &'static [RuleFactory] {
    &[
        make_rule::<MutableGlobalStateRule>,
        make_rule::<AssignmentOveruseRule>,
        make_rule::<DirectIoRule>,
        make_rule::<NonDeterministicUseRule>,
        make_rule::<ExternalStateSideEffectRule>,
        make_rule::<MutableDefaultArgumentRule>,
        make_rule::<DirectEffectfulCallRule>,
        make_rule::<GlobalNonlocalUsageRule>,
        make_rule::<HiddenMutationRule>,
        make_rule::<LoopSideEffectRule>,
        make_rule::<ExceptionControlFlowRule>,
        make_rule::<ClassMethodSideEffectRule>,
        make_rule::<ReferentialTransparencyBreakRule>,
        make_rule::<DeprecatedApiUseRule>,
    ]
}

fn make_rule<T: Rule + Default + 'static>() -> Box<dyn Rule> {
    Box::new(T::default())
}

impl Rule for MutableGlobalStateRule {
    fn id(&self) -> RuleId {
        RuleId::MutableGlobalState
    }

    fn check(&self, module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mutable_globals = module
            .globals
            .iter()
            .filter(|binding| binding.is_mutable)
            .map(|binding| binding.name.clone())
            .collect::<BTreeSet<_>>();
        if mutable_globals.is_empty() {
            return Vec::new();
        }

        let local_bindings = function
            .local_bindings
            .iter()
            .cloned()
            .collect::<BTreeSet<_>>();
        let declared_globals = collect_declared_globals(function);
        let mut diagnostics = Vec::new();
        let mut seen = BTreeSet::new();

        walk_function(function, &mut |statement, expression| {
            if let Some(expression) = expression {
                if let Some(base_name) = expression.base_name() {
                    let is_global = mutable_globals.contains(&base_name)
                        && (!local_bindings.contains(&base_name)
                            || declared_globals.contains(&base_name));
                    if is_global && seen.insert(("ref".to_owned(), base_name.clone())) {
                        diagnostics.push(build_diagnostic(
                            RuleId::MutableGlobalState,
                            function,
                            expression.location.clone(),
                            format!("References mutable global state `{base_name}`."),
                            Some("Pass the value in as an argument and manage state outside the function.".to_owned()),
                        ));
                    }
                }
            }

            if let Some(statement) = statement {
                if let StatementKind::Assign { targets, .. } = &statement.kind {
                    for target in targets {
                        if let Some(base_name) = target.base_name() {
                            let is_global = mutable_globals.contains(&base_name)
                                && (!local_bindings.contains(&base_name)
                                    || declared_globals.contains(&base_name));
                            if is_global && seen.insert(("write".to_owned(), base_name.clone())) {
                                diagnostics.push(build_diagnostic(
                                    RuleId::MutableGlobalState,
                                    function,
                                    target.location.clone(),
                                    format!("Updates mutable global state `{base_name}`."),
                                    Some(
                                        "Return the updated value and apply it at the call site."
                                            .to_owned(),
                                    ),
                                ));
                            }
                        }
                    }
                }
            }
        });

        diagnostics
    }
}

impl Rule for AssignmentOveruseRule {
    fn id(&self) -> RuleId {
        RuleId::AssignmentOveruse
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut assignment_count = 0usize;
        walk_function(function, &mut |statement, _expression| {
            if matches!(
                statement.map(|statement| &statement.kind),
                Some(StatementKind::Assign { .. })
            ) {
                assignment_count += 1;
            }
        });

        if assignment_count >= 4 {
            vec![build_diagnostic(
                RuleId::AssignmentOveruse,
                function,
                function.location.clone(),
                format!(
                    "Contains {assignment_count} assignments, which suggests excessive state changes."
                ),
                Some(
                    "Reduce intermediate state and split the logic into smaller pure functions."
                        .to_owned(),
                ),
            )]
        } else {
            Vec::new()
        }
    }
}

impl Rule for DirectIoRule {
    fn id(&self) -> RuleId {
        RuleId::DirectIo
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut diagnostics = Vec::new();
        walk_function(function, &mut |_, expression| {
            if let Some(call) = expression
                .and_then(as_call)
                .filter(|path| is_direct_io_call(path))
            {
                diagnostics.push(build_diagnostic(
                    RuleId::DirectIo,
                    function,
                    expression.expect("expression exists").location.clone(),
                    format!("Detected direct I/O call `{call}`."),
                    Some(
                        "Move I/O outside the function and pass in only the required values."
                            .to_owned(),
                    ),
                ));
            }
        });
        diagnostics
    }
}

impl Rule for NonDeterministicUseRule {
    fn id(&self) -> RuleId {
        RuleId::NonDeterministicUse
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut diagnostics = Vec::new();
        walk_function(function, &mut |_, expression| {
            if let Some(call) = expression
                .and_then(as_call)
                .filter(|path| is_non_deterministic_call(path))
            {
                diagnostics.push(build_diagnostic(
                    RuleId::NonDeterministicUse,
                    function,
                    expression.expect("expression exists").location.clone(),
                    format!("Detected non-deterministic call `{call}`."),
                    Some("Inject time, randomness, and similar values as arguments.".to_owned()),
                ));
            }
        });
        diagnostics
    }
}

impl Rule for ExternalStateSideEffectRule {
    fn id(&self) -> RuleId {
        RuleId::ExternalStateSideEffect
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut diagnostics = Vec::new();
        walk_function(function, &mut |statement, expression| {
            if let Some(statement) = statement {
                if let StatementKind::Assign { targets, .. } = &statement.kind {
                    for target in targets {
                        if matches!(
                            target.kind,
                            ExpressionKind::Attribute { .. } | ExpressionKind::Subscript { .. }
                        ) {
                            diagnostics.push(build_diagnostic(
                                RuleId::ExternalStateSideEffect,
                                function,
                                target.location.clone(),
                                "Detected assignment to external state.".to_owned(),
                                Some("Construct a new value and return it instead.".to_owned()),
                            ));
                        }
                    }
                }
            }

            if let Some(expression) = expression {
                if let Some(call) = as_call(expression).filter(|path| is_side_effect_call(path)) {
                    diagnostics.push(build_diagnostic(
                        RuleId::ExternalStateSideEffect,
                        function,
                        expression.location.clone(),
                        format!("Detected call `{call}` that may mutate external state."),
                        Some("Push side effects to the boundary layer.".to_owned()),
                    ));
                }
            }
        });
        diagnostics
    }
}

impl Rule for MutableDefaultArgumentRule {
    fn id(&self) -> RuleId {
        RuleId::MutableDefaultArgument
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        function
            .parameters
            .iter()
            .filter_map(|parameter| {
                parameter
                    .default
                    .as_ref()
                    .filter(|default| default.is_mutable_value())
                    .map(|_| {
                        build_diagnostic(
                            RuleId::MutableDefaultArgument,
                            function,
                            parameter.location.clone(),
                            format!(
                                "Parameter `{}` has a mutable default value.",
                                parameter.name
                            ),
                            Some(
                                "Use `None` as the default and create a new value inside the function."
                                    .to_owned(),
                            ),
                        )
                    })
            })
            .collect()
    }
}

impl Rule for DirectEffectfulCallRule {
    fn id(&self) -> RuleId {
        RuleId::DirectEffectfulCall
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut diagnostics = Vec::new();
        walk_function(function, &mut |_, expression| {
            if let Some(call) = expression
                .and_then(as_call)
                .filter(|path| is_direct_effectful_call(path))
            {
                diagnostics.push(build_diagnostic(
                    RuleId::DirectEffectfulCall,
                    function,
                    expression.expect("expression exists").location.clone(),
                    format!("Directly invokes effectful call `{call}`."),
                    Some("Abstract the call and inject it from outside the function.".to_owned()),
                ));
            }
        });
        diagnostics
    }
}

impl Rule for GlobalNonlocalUsageRule {
    fn id(&self) -> RuleId {
        RuleId::GlobalNonlocalUsage
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut diagnostics = Vec::new();
        walk_function(function, &mut |statement, _expression| {
            if let Some(statement) = statement {
                match &statement.kind {
                    StatementKind::Global { names } => diagnostics.push(build_diagnostic(
                        RuleId::GlobalNonlocalUsage,
                        function,
                        statement.location.clone(),
                        format!("Detected `global` usage: {}", names.join(", ")),
                        Some(
                            "Pass state explicitly through arguments and return values.".to_owned(),
                        ),
                    )),
                    StatementKind::Nonlocal { names } => diagnostics.push(build_diagnostic(
                        RuleId::GlobalNonlocalUsage,
                        function,
                        statement.location.clone(),
                        format!("Detected `nonlocal` usage: {}", names.join(", ")),
                        Some("Avoid capturing outer state and pass values explicitly.".to_owned()),
                    )),
                    _ => {}
                }
            }
        });
        diagnostics
    }
}

impl Rule for HiddenMutationRule {
    fn id(&self) -> RuleId {
        RuleId::HiddenMutation
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let parameter_names = function
            .parameters
            .iter()
            .map(|parameter| parameter.name.clone())
            .collect::<BTreeSet<_>>();
        let local_bindings = function
            .local_bindings
            .iter()
            .cloned()
            .collect::<BTreeSet<_>>();
        let mut diagnostics = Vec::new();
        let mut seen = BTreeSet::new();

        walk_function(function, &mut |_, expression| {
            let Some(expression) = expression else {
                return;
            };
            let ExpressionKind::Call {
                function: callee, ..
            } = &expression.kind
            else {
                return;
            };
            let Some(path) = callee.path() else {
                return;
            };
            let Some(base_name) = callee.base_name() else {
                return;
            };

            if is_in_place_mutation_call(&path)
                && (parameter_names.contains(&base_name) || local_bindings.contains(&base_name))
                && seen.insert((
                    expression.location.start.line,
                    expression.location.start.column,
                    path.clone(),
                ))
            {
                diagnostics.push(build_diagnostic(
                    RuleId::HiddenMutation,
                    function,
                    expression.location.clone(),
                    format!(
                        "Detected in-place mutation call `{path}` on local state `{base_name}`."
                    ),
                    Some("Return a new collection instead of mutating in place.".to_owned()),
                ));
            }
        });

        diagnostics
    }
}

impl Rule for LoopSideEffectRule {
    fn id(&self) -> RuleId {
        RuleId::LoopSideEffect
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut diagnostics = Vec::new();
        let mut seen = BTreeSet::new();
        collect_loop_side_effects(&function.body, 0, function, &mut diagnostics, &mut seen);
        diagnostics
    }
}

impl Rule for ExceptionControlFlowRule {
    fn id(&self) -> RuleId {
        RuleId::ExceptionControlFlow
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut raise_count = 0usize;
        let mut handler_count = 0usize;
        let mut first_location = None;

        walk_function(function, &mut |statement, _expression| {
            let Some(statement) = statement else {
                return;
            };
            match &statement.kind {
                StatementKind::Raise { .. } => {
                    raise_count += 1;
                    if first_location.is_none() {
                        first_location = Some(statement.location.clone());
                    }
                }
                StatementKind::Try { handlers, .. } if !handlers.is_empty() => {
                    handler_count += handlers.len();
                    if first_location.is_none() {
                        first_location = Some(statement.location.clone());
                    }
                }
                _ => {}
            }
        });

        if raise_count + handler_count >= 2 {
            vec![build_diagnostic(
                RuleId::ExceptionControlFlow,
                function,
                first_location.unwrap_or_else(|| function.location.clone()),
                format!("Uses exceptions as control flow (raise={raise_count}, except={handler_count})."),
                Some("Represent failure with explicit branching or result values.".to_owned()),
            )]
        } else {
            Vec::new()
        }
    }
}

impl Rule for ClassMethodSideEffectRule {
    fn id(&self) -> RuleId {
        RuleId::ClassMethodSideEffect
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let Some(class_name) = function.class_name.as_deref() else {
            return Vec::new();
        };

        let mut diagnostics = Vec::new();
        let mut seen = BTreeSet::new();

        walk_function(function, &mut |statement, expression| {
            if let Some(statement) = statement {
                if let StatementKind::Assign { targets, .. } = &statement.kind {
                    for target in targets {
                        let Some(target_path) = class_state_target_path(target) else {
                            continue;
                        };
                        if seen.insert((
                            target.location.start.line,
                            target.location.start.column,
                            target_path.clone(),
                        )) {
                            diagnostics.push(build_diagnostic(
                                RuleId::ClassMethodSideEffect,
                                function,
                                target.location.clone(),
                                format!(
                                    "Updates instance state `{target_path}` inside a method on class `{class_name}`."
                                ),
                                Some(
                                    "Do not mutate object internals directly; return new state and apply it outside the method."
                                        .to_owned(),
                                ),
                            ));
                        }
                    }
                }
            }

            let Some(expression) = expression else {
                return;
            };
            let Some(path) = as_call(expression).filter(|path| is_class_state_mutation_call(path))
            else {
                return;
            };

            if seen.insert((
                expression.location.start.line,
                expression.location.start.column,
                path.clone(),
            )) {
                diagnostics.push(build_diagnostic(
                    RuleId::ClassMethodSideEffect,
                    function,
                    expression.location.clone(),
                    format!(
                        "Detected state-changing call `{path}` inside a method on class `{class_name}`."
                    ),
                    Some(
                        "Do not hide state updates inside the method; build and return a new value."
                            .to_owned(),
                    ),
                ));
            }
        });

        diagnostics
    }
}

impl Rule for ReferentialTransparencyBreakRule {
    fn id(&self) -> RuleId {
        RuleId::ReferentialTransparencyBreak
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut diagnostics = Vec::new();
        let mut seen = BTreeSet::new();

        walk_function(function, &mut |_, expression| {
            let Some(expression) = expression else {
                return;
            };

            if let Some(call) = as_call(expression) {
                if let Some(hint) = referential_transparency_call_hint(&call) {
                    if seen.insert((
                        expression.location.start.line,
                        expression.location.start.column,
                        call.clone(),
                    )) {
                        diagnostics.push(build_diagnostic(
                            RuleId::ReferentialTransparencyBreak,
                            function,
                            expression.location.clone(),
                            format!("Detected implicit dependency or dynamic evaluation `{call}` that breaks referential transparency."),
                            Some(hint.to_owned()),
                        ));
                    }
                    return;
                }
            }

            if let Some(reference) = referential_transparency_reference_path(expression) {
                if seen.insert((
                    expression.location.start.line,
                    expression.location.start.column,
                    reference.clone(),
                )) {
                    diagnostics.push(build_diagnostic(
                        RuleId::ReferentialTransparencyBreak,
                        function,
                        expression.location.clone(),
                        format!("Detected implicit reference `{reference}` that breaks referential transparency."),
                        Some(
                            "Resolve environment and process state at the call site, then pass only the required values as arguments."
                                .to_owned(),
                        ),
                    ));
                }
            }
        });

        diagnostics
    }
}

impl Rule for DeprecatedApiUseRule {
    fn id(&self) -> RuleId {
        RuleId::DeprecatedApiUse
    }

    fn check(&self, _module: &Module, function: &FunctionDef) -> Vec<Diagnostic> {
        let mut diagnostics = Vec::new();
        let mut seen = BTreeSet::new();

        walk_function(function, &mut |_, expression| {
            let Some(expression) = expression else {
                return;
            };
            let Some(call) = as_call(expression) else {
                return;
            };
            let Some(replacement) = deprecated_api_replacement(&call) else {
                return;
            };

            if seen.insert((
                expression.location.start.line,
                expression.location.start.column,
                call.clone(),
            )) {
                diagnostics.push(build_diagnostic(
                    RuleId::DeprecatedApiUse,
                    function,
                    expression.location.clone(),
                    format!("Detected deprecated API `{call}`."),
                    Some(replacement.to_owned()),
                ));
            }
        });

        diagnostics
    }
}

fn build_diagnostic(
    rule_id: RuleId,
    function: &FunctionDef,
    location: crate::model::SourceSpan,
    message: impl Into<String>,
    hint: Option<String>,
) -> Diagnostic {
    let fix_hint = build_fix_hint(&rule_id, hint.as_deref());
    build_diagnostic_with_severity(
        rule_id,
        Severity::Warning,
        function,
        location,
        message,
        hint,
        fix_hint,
    )
}

fn build_diagnostic_with_severity(
    rule_id: RuleId,
    severity: Severity,
    function: &FunctionDef,
    location: crate::model::SourceSpan,
    message: impl Into<String>,
    hint: Option<String>,
    fix_hint: Option<FixHint>,
) -> Diagnostic {
    Diagnostic::new(
        rule_id,
        severity,
        message,
        Some(function.qualified_name.clone()),
        location,
        hint,
        fix_hint,
    )
}

fn build_fix_hint(rule_id: &RuleId, hint: Option<&str>) -> Option<FixHint> {
    let suggested_action = hint?.to_owned();
    let (kind, summary) = match rule_id {
        RuleId::ParseError => (FixKind::ManualReview, "Fix the syntax error."),
        RuleId::MutableGlobalState | RuleId::ExternalStateSideEffect => (
            FixKind::ReturnNewValue,
            "Convert state updates to a return-value-based flow.",
        ),
        RuleId::DirectIo | RuleId::DirectEffectfulCall => (
            FixKind::ExtractEffectBoundary,
            "Move side effects to the function boundary.",
        ),
        RuleId::NonDeterministicUse => (
            FixKind::InjectDependency,
            "Inject non-deterministic values from outside.",
        ),
        RuleId::MutableDefaultArgument => (
            FixKind::ReplaceMutableDefault,
            "Replace the mutable default value.",
        ),
        RuleId::GlobalNonlocalUsage => (
            FixKind::ReturnNewValue,
            "Convert implicit shared state into explicit value passing.",
        ),
        RuleId::HiddenMutation => (
            FixKind::AvoidInPlaceMutation,
            "Avoid in-place mutation and return a new value.",
        ),
        RuleId::LoopSideEffect => (
            FixKind::EliminateLoopEffect,
            "Move loop side effects outside the loop.",
        ),
        RuleId::ExceptionControlFlow => (
            FixKind::ReplaceExceptionFlow,
            "Replace exception-based branching with explicit branching.",
        ),
        RuleId::ClassMethodSideEffect => (
            FixKind::ReturnNewValue,
            "Avoid direct mutation of object internals.",
        ),
        RuleId::ReferentialTransparencyBreak => (
            FixKind::InjectDependency,
            "Convert implicit dependencies into arguments or explicit dependencies.",
        ),
        RuleId::DeprecatedApiUse => (
            FixKind::ManualReview,
            "Replace the deprecated API with a recommended alternative.",
        ),
        RuleId::AssignmentOveruse => (
            FixKind::ReturnNewValue,
            "Reduce intermediate state and split the logic into smaller pure functions.",
        ),
        RuleId::Custom(_) => (FixKind::ManualReview, "Review the custom rule finding."),
    };

    Some(FixHint {
        kind,
        summary: summary.to_owned(),
        suggested_action,
    })
}

fn run_custom_rules(function: &FunctionDef, config: &CheckerConfig) -> Vec<Diagnostic> {
    let mut diagnostics = Vec::new();

    for rule in &config.custom_rules {
        if !rule.enabled || !config.is_rule_enabled(&rule.id) {
            continue;
        }
        diagnostics.extend(run_custom_rule(function, rule));
    }

    diagnostics
}

fn run_custom_rule(function: &FunctionDef, rule: &CustomRuleConfig) -> Vec<Diagnostic> {
    let mut diagnostics = Vec::new();
    let mut seen = BTreeSet::new();

    walk_function(function, &mut |statement, expression| match rule.target {
        CustomRuleTarget::Call => {
            let Some(expression) = expression else {
                return;
            };
            let Some(path) = as_call(expression) else {
                return;
            };
            if matches_custom_rule(rule, &path)
                && seen.insert((
                    rule.id.as_str().to_owned(),
                    expression.location.start.line,
                    expression.location.start.column,
                    path.clone(),
                ))
            {
                diagnostics.push(build_custom_diagnostic(
                    rule,
                    function,
                    expression.location.clone(),
                    &path,
                ));
            }
        }
        CustomRuleTarget::Name => {
            let Some(expression) = expression else {
                return;
            };
            if !matches!(
                expression.kind,
                ExpressionKind::Name { .. } | ExpressionKind::Attribute { .. }
            ) {
                return;
            }
            let Some(path) = expression.path() else {
                return;
            };
            if matches_custom_rule(rule, &path)
                && seen.insert((
                    rule.id.as_str().to_owned(),
                    expression.location.start.line,
                    expression.location.start.column,
                    path.clone(),
                ))
            {
                diagnostics.push(build_custom_diagnostic(
                    rule,
                    function,
                    expression.location.clone(),
                    &path,
                ));
            }
        }
        CustomRuleTarget::AttributeWrite => {
            let Some(statement) = statement else {
                return;
            };
            let StatementKind::Assign { targets, .. } = &statement.kind else {
                return;
            };

            for target in targets {
                if !matches!(
                    target.kind,
                    ExpressionKind::Attribute { .. } | ExpressionKind::Subscript { .. }
                ) {
                    continue;
                }
                let candidate = target
                    .path()
                    .or_else(|| target.base_name())
                    .unwrap_or_else(|| "<unknown>".to_owned());
                if matches_custom_rule(rule, &candidate)
                    && seen.insert((
                        rule.id.as_str().to_owned(),
                        target.location.start.line,
                        target.location.start.column,
                        candidate.clone(),
                    ))
                {
                    diagnostics.push(build_custom_diagnostic(
                        rule,
                        function,
                        target.location.clone(),
                        &candidate,
                    ));
                }
            }
        }
    });

    diagnostics
}

fn build_custom_diagnostic(
    rule: &CustomRuleConfig,
    function: &FunctionDef,
    location: crate::model::SourceSpan,
    matched: &str,
) -> Diagnostic {
    let message = render_custom_text(&rule.message, matched);
    let hint = rule
        .hint
        .as_ref()
        .map(|hint| render_custom_text(hint, matched));
    let fix_hint = hint.as_ref().map(|hint| FixHint {
        kind: FixKind::ManualReview,
        summary: format!("Review the finding for custom rule `{}`.", rule.id),
        suggested_action: hint.clone(),
    });

    Diagnostic::new(
        rule.id.clone(),
        rule.severity,
        message,
        Some(function.qualified_name.clone()),
        location,
        hint,
        fix_hint,
    )
}

fn matches_custom_rule(rule: &CustomRuleConfig, candidate: &str) -> bool {
    rule.patterns.iter().any(|pattern| match rule.match_type {
        CustomRuleMatchType::Exact => candidate == pattern,
        CustomRuleMatchType::Prefix => candidate.starts_with(pattern),
        CustomRuleMatchType::Suffix => candidate.ends_with(pattern),
        CustomRuleMatchType::Contains => candidate.contains(pattern),
    })
}

fn render_custom_text(template: &str, matched: &str) -> String {
    template.replace("{match}", matched)
}

fn walk_function(
    function: &FunctionDef,
    visitor: &mut impl FnMut(Option<&Statement>, Option<&Expression>),
) {
    for decorator in &function.decorators {
        walk_expression(decorator, visitor);
    }
    if let Some(returns) = &function.returns {
        walk_expression(returns, visitor);
    }
    for statement in &function.body {
        walk_statement(statement, visitor);
    }
}

fn walk_statement(
    statement: &Statement,
    visitor: &mut impl FnMut(Option<&Statement>, Option<&Expression>),
) {
    visitor(Some(statement), None);
    match &statement.kind {
        StatementKind::FunctionDef(_)
        | StatementKind::ClassDef { .. }
        | StatementKind::Import { .. }
        | StatementKind::Global { .. }
        | StatementKind::Nonlocal { .. }
        | StatementKind::ControlFlow { .. }
        | StatementKind::Other { .. } => {}
        StatementKind::Return { value } => {
            if let Some(value) = value {
                walk_expression(value, visitor);
            }
        }
        StatementKind::Delete { targets } => {
            for target in targets {
                walk_expression(target, visitor);
            }
        }
        StatementKind::Assign {
            targets,
            value,
            annotation,
            ..
        } => {
            for target in targets {
                walk_expression(target, visitor);
            }
            if let Some(value) = value {
                walk_expression(value, visitor);
            }
            if let Some(annotation) = annotation {
                walk_expression(annotation, visitor);
            }
        }
        StatementKind::For {
            target,
            iter,
            body,
            orelse,
            ..
        } => {
            walk_expression(target, visitor);
            walk_expression(iter, visitor);
            for nested in body {
                walk_statement(nested, visitor);
            }
            for nested in orelse {
                walk_statement(nested, visitor);
            }
        }
        StatementKind::While { test, body, orelse } | StatementKind::If { test, body, orelse } => {
            walk_expression(test, visitor);
            for nested in body {
                walk_statement(nested, visitor);
            }
            for nested in orelse {
                walk_statement(nested, visitor);
            }
        }
        StatementKind::With { items, body, .. } => {
            for item in items {
                walk_expression(&item.context_expr, visitor);
                if let Some(optional_vars) = &item.optional_vars {
                    walk_expression(optional_vars, visitor);
                }
            }
            for nested in body {
                walk_statement(nested, visitor);
            }
        }
        StatementKind::Try {
            body,
            handlers,
            orelse,
            finalbody,
        } => {
            for nested in body {
                walk_statement(nested, visitor);
            }
            for handler in handlers {
                if let Some(type_expr) = &handler.type_expr {
                    walk_expression(type_expr, visitor);
                }
                for nested in &handler.body {
                    walk_statement(nested, visitor);
                }
            }
            for nested in orelse {
                walk_statement(nested, visitor);
            }
            for nested in finalbody {
                walk_statement(nested, visitor);
            }
        }
        StatementKind::Raise { exc, cause } => {
            if let Some(exc) = exc {
                walk_expression(exc, visitor);
            }
            if let Some(cause) = cause {
                walk_expression(cause, visitor);
            }
        }
        StatementKind::Assert { test, message } => {
            walk_expression(test, visitor);
            if let Some(message) = message {
                walk_expression(message, visitor);
            }
        }
        StatementKind::Expression { expression } => walk_expression(expression, visitor),
    }
}

fn walk_expression(
    expression: &Expression,
    visitor: &mut impl FnMut(Option<&Statement>, Option<&Expression>),
) {
    visitor(None, Some(expression));
    match &expression.kind {
        ExpressionKind::Attribute { value, .. }
        | ExpressionKind::Unary { operand: value, .. }
        | ExpressionKind::Await { value }
        | ExpressionKind::YieldFrom { value }
        | ExpressionKind::Starred { value } => walk_expression(value, visitor),
        ExpressionKind::Call {
            function,
            args,
            keywords,
        } => {
            walk_expression(function, visitor);
            for argument in args {
                walk_expression(argument, visitor);
            }
            for keyword in keywords {
                walk_expression(&keyword.value, visitor);
            }
        }
        ExpressionKind::List { elements }
        | ExpressionKind::Tuple { elements }
        | ExpressionKind::Set { elements }
        | ExpressionKind::BoolOp {
            values: elements, ..
        } => {
            for element in elements {
                walk_expression(element, visitor);
            }
        }
        ExpressionKind::Dict { entries } => {
            for entry in entries {
                if let Some(key) = &entry.key {
                    walk_expression(key, visitor);
                }
                walk_expression(&entry.value, visitor);
            }
        }
        ExpressionKind::Binary { left, right, .. } => {
            walk_expression(left, visitor);
            walk_expression(right, visitor);
        }
        ExpressionKind::Compare {
            left, comparators, ..
        } => {
            walk_expression(left, visitor);
            for comparator in comparators {
                walk_expression(comparator, visitor);
            }
        }
        ExpressionKind::IfElse { test, body, orelse } => {
            walk_expression(test, visitor);
            walk_expression(body, visitor);
            walk_expression(orelse, visitor);
        }
        ExpressionKind::Subscript { value, slice } => {
            walk_expression(value, visitor);
            walk_expression(slice, visitor);
        }
        ExpressionKind::Yield { value } => {
            if let Some(value) = value {
                walk_expression(value, visitor);
            }
        }
        ExpressionKind::Named { target, value } => {
            walk_expression(target, visitor);
            walk_expression(value, visitor);
        }
        ExpressionKind::Slice { lower, upper, step } => {
            if let Some(lower) = lower {
                walk_expression(lower, visitor);
            }
            if let Some(upper) = upper {
                walk_expression(upper, visitor);
            }
            if let Some(step) = step {
                walk_expression(step, visitor);
            }
        }
        ExpressionKind::Name { .. }
        | ExpressionKind::Constant { .. }
        | ExpressionKind::Lambda
        | ExpressionKind::Other { .. } => {}
    }
}

fn collect_declared_globals(function: &FunctionDef) -> BTreeSet<String> {
    let mut names = BTreeSet::new();
    walk_function(function, &mut |statement, _| {
        if let Some(statement) = statement {
            if let StatementKind::Global { names: declared } = &statement.kind {
                names.extend(declared.iter().cloned());
            }
        }
    });
    names
}

fn collect_loop_side_effects(
    statements: &[Statement],
    loop_depth: usize,
    function: &FunctionDef,
    diagnostics: &mut Vec<Diagnostic>,
    seen: &mut BTreeSet<(usize, usize, String)>,
) {
    for statement in statements {
        match &statement.kind {
            StatementKind::For { body, orelse, .. } | StatementKind::While { body, orelse, .. } => {
                collect_loop_side_effects(body, loop_depth + 1, function, diagnostics, seen);
                collect_loop_side_effects(orelse, loop_depth, function, diagnostics, seen);
            }
            StatementKind::If { body, orelse, .. } => {
                if loop_depth > 0 {
                    collect_loop_effectful_calls_in_statement(
                        statement,
                        loop_depth,
                        function,
                        diagnostics,
                        seen,
                    );
                }
                collect_loop_side_effects(body, loop_depth, function, diagnostics, seen);
                collect_loop_side_effects(orelse, loop_depth, function, diagnostics, seen);
            }
            StatementKind::With { body, .. } => {
                if loop_depth > 0 {
                    collect_loop_effectful_calls_in_statement(
                        statement,
                        loop_depth,
                        function,
                        diagnostics,
                        seen,
                    );
                }
                collect_loop_side_effects(body, loop_depth, function, diagnostics, seen);
            }
            StatementKind::Try {
                body,
                handlers,
                orelse,
                finalbody,
            } => {
                if loop_depth > 0 {
                    collect_loop_effectful_calls_in_statement(
                        statement,
                        loop_depth,
                        function,
                        diagnostics,
                        seen,
                    );
                }
                collect_loop_side_effects(body, loop_depth, function, diagnostics, seen);
                for handler in handlers {
                    collect_loop_side_effects(
                        &handler.body,
                        loop_depth,
                        function,
                        diagnostics,
                        seen,
                    );
                }
                collect_loop_side_effects(orelse, loop_depth, function, diagnostics, seen);
                collect_loop_side_effects(finalbody, loop_depth, function, diagnostics, seen);
            }
            StatementKind::FunctionDef(_) | StatementKind::ClassDef { .. } => {}
            _ => {
                if loop_depth > 0 {
                    collect_loop_effectful_calls_in_statement(
                        statement,
                        loop_depth,
                        function,
                        diagnostics,
                        seen,
                    );
                }
            }
        }
    }
}

fn collect_loop_effectful_calls_in_statement(
    statement: &Statement,
    loop_depth: usize,
    function: &FunctionDef,
    diagnostics: &mut Vec<Diagnostic>,
    seen: &mut BTreeSet<(usize, usize, String)>,
) {
    if let StatementKind::Assign { targets, .. } = &statement.kind {
        for target in targets {
            if matches!(
                target.kind,
                ExpressionKind::Attribute { .. } | ExpressionKind::Subscript { .. }
            ) && seen.insert((
                target.location.start.line,
                target.location.start.column,
                "assign".to_owned(),
            )) {
                let weight = 2 + usize::from(loop_depth > 1);
                diagnostics.push(build_diagnostic_with_severity(
                    RuleId::LoopSideEffect,
                    severity_from_loop_weight(weight),
                    function,
                    target.location.clone(),
                    format!("Assigns to external state inside a loop (weight={weight})."),
                    Some(
                        "Aggregate updates outside the loop and apply them once at the end."
                            .to_owned(),
                    ),
                    build_fix_hint(
                        &RuleId::LoopSideEffect,
                        Some("Aggregate updates outside the loop and apply them once at the end."),
                    ),
                ));
            }
        }
    }

    walk_statement(statement, &mut |_, expression| {
        let Some(expression) = expression else {
            return;
        };
        let Some(path) = as_call(expression).filter(|path| is_loop_effect_call(path)) else {
            return;
        };

        if seen.insert((
            expression.location.start.line,
            expression.location.start.column,
            path.clone(),
        )) {
            let weight = loop_effect_weight(&path, loop_depth);
            diagnostics.push(build_diagnostic_with_severity(
                RuleId::LoopSideEffect,
                severity_from_loop_weight(weight),
                function,
                expression.location.clone(),
                format!("Executes effectful call `{path}` inside a loop (weight={weight})."),
                Some(loop_effect_hint(weight).to_owned()),
                build_fix_hint(&RuleId::LoopSideEffect, Some(loop_effect_hint(weight))),
            ));
        }
    });
}

fn as_call(expression: &Expression) -> Option<String> {
    match &expression.kind {
        ExpressionKind::Call { function, .. } => function.path(),
        _ => None,
    }
}

fn is_direct_io_call(path: &str) -> bool {
    matches!(
        path,
        "print"
            | "input"
            | "open"
            | "sys.stdout.write"
            | "sys.stderr.write"
            | "pathlib.Path.open"
            | "pathlib.Path.read_text"
            | "pathlib.Path.write_text"
            | "pathlib.Path.read_bytes"
            | "pathlib.Path.write_bytes"
    ) || path
        .rsplit('.')
        .next()
        .is_some_and(|segment| matches!(segment, "read" | "write"))
}

fn is_non_deterministic_call(path: &str) -> bool {
    path.starts_with("random.")
        || path.starts_with("secrets.")
        || matches!(
            path,
            "uuid.uuid1"
                | "uuid.uuid4"
                | "time.time"
                | "time.monotonic"
                | "datetime.datetime.now"
                | "datetime.datetime.utcnow"
                | "datetime.date.today"
                | "os.urandom"
        )
}

fn is_side_effect_call(path: &str) -> bool {
    is_in_place_mutation_call(path)
        || path.rsplit('.').next().is_some_and(|last_segment| {
            matches!(
                last_segment,
                "write" | "writelines" | "send" | "save" | "commit" | "flush"
            )
        })
}

fn is_direct_effectful_call(path: &str) -> bool {
    matches!(path, "print" | "open")
        || path.starts_with("logging.")
        || path.starts_with("requests.")
        || path.starts_with("subprocess.")
}

fn is_in_place_mutation_call(path: &str) -> bool {
    path.rsplit('.').next().is_some_and(|last_segment| {
        matches!(
            last_segment,
            "append"
                | "extend"
                | "update"
                | "add"
                | "remove"
                | "discard"
                | "clear"
                | "pop"
                | "insert"
                | "sort"
                | "reverse"
                | "setdefault"
        )
    })
}

fn is_loop_effect_call(path: &str) -> bool {
    is_side_effect_call(path) || is_direct_io_call(path) || is_direct_effectful_call(path)
}

fn class_state_target_path(target: &Expression) -> Option<String> {
    match &target.kind {
        ExpressionKind::Attribute { .. } | ExpressionKind::Subscript { .. } => target
            .base_name()
            .filter(|base_name| matches!(base_name.as_str(), "self" | "cls"))
            .and_then(|_| target.path().or_else(|| target.base_name())),
        _ => None,
    }
}

fn is_class_state_mutation_call(path: &str) -> bool {
    path.split('.')
        .next()
        .is_some_and(|base_name| matches!(base_name, "self" | "cls"))
        && (is_in_place_mutation_call(path) || is_side_effect_call(path))
}

fn referential_transparency_call_hint(path: &str) -> Option<&'static str> {
    match path {
        "eval" | "exec" | "compile" => {
            Some("Avoid dynamic execution; use explicit branching or a safe parser instead.")
        }
        "globals" | "locals" | "vars" => {
            Some("Do not depend on implicit namespaces; accept the required values as arguments.")
        }
        "os.getenv" | "os.getenvb" | "os.getcwd" | "pathlib.Path.cwd" | "pathlib.Path.home" => {
            Some("Resolve environment and working-directory dependencies at the call site and inject the resulting values.")
        }
        _ => None,
    }
}

fn referential_transparency_reference_path(expression: &Expression) -> Option<String> {
    match &expression.kind {
        ExpressionKind::Attribute { .. } => expression.path().filter(|path| {
            matches!(
                path.as_str(),
                "os.environ" | "os.environb" | "sys.argv" | "sys.path"
            )
        }),
        ExpressionKind::Subscript { value, .. } => value.path().filter(|path| {
            matches!(
                path.as_str(),
                "os.environ" | "os.environb" | "sys.argv" | "sys.path"
            )
        }),
        _ => None,
    }
}

fn deprecated_api_replacement(path: &str) -> Option<&'static str> {
    match path {
        "logging.warn" => Some("Use `logging.warning` instead."),
        "locale.getdefaultlocale" => Some(
            "Set the required locale data explicitly and use the locale-specific APIs instead.",
        ),
        "datetime.datetime.utcnow" => Some("Use `datetime.datetime.now(datetime.UTC)` instead."),
        "datetime.datetime.utcfromtimestamp" => {
            Some("Use `datetime.datetime.fromtimestamp(ts, datetime.UTC)` instead.")
        }
        "threading.currentThread" => Some("Use `threading.current_thread()` instead."),
        "threading.activeCount" => Some("Use `threading.active_count()` instead."),
        "imp.load_module" | "imp.find_module" | "imp.find_loader" | "imp.reload"
        | "imp.new_module" => Some("Replace it with an `importlib`-based API."),
        "cgi.escape" => Some("Use `html.escape` instead."),
        _ => None,
    }
}

fn loop_effect_weight(path: &str, loop_depth: usize) -> usize {
    let mut weight = if path.starts_with("requests.") || path.starts_with("subprocess.") {
        3
    } else if is_direct_io_call(path) || is_side_effect_call(path) || is_direct_effectful_call(path)
    {
        2
    } else {
        1
    };

    if loop_depth > 1 {
        weight += 1;
    }

    weight
}

fn severity_from_loop_weight(weight: usize) -> Severity {
    if weight >= 3 {
        Severity::Error
    } else {
        Severity::Warning
    }
}

fn loop_effect_hint(weight: usize) -> &'static str {
    if weight >= 3 {
        "Batch high-cost effects or effects inside nested loops and move them outside the loop."
    } else {
        "Keep the loop focused on value transformation and handle side effects outside the loop."
    }
}
