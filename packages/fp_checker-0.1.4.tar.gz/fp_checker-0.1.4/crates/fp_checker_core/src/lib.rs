mod checker;
mod config;
mod model;
mod parser;
mod report;
mod rules;

pub use checker::{check_code, check_path, CheckerError};
pub use config::{
    discover_config, load_config_from_path, CheckerConfig, ConfigError, CustomRuleConfig,
    CustomRuleMatchType, CustomRuleTarget, OutputFormat,
};
pub use model::{
    Diagnostic, FixHint, FixKind, FunctionDef, IgnoreDirective, Module, Parameter, ParameterKind,
    RuleId, Severity, SourceLocation, SourceSpan,
};
pub use parser::{ParseOutcome, ParserAdapter, RustPythonParser};
pub use report::{render_report, FileReport, Report, Summary};
