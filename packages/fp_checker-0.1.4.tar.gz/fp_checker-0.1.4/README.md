# fp-checker

`fp-checker` is a Rust-powered checker for Python codebases that reports functions which violate functional-programming-oriented rules. It provides both a CLI and a Python API, and can output results in text, JSON, or SARIF. In addition to built-in rules, you can add custom rules through configuration only.

## English Summary

- What it does: checks Python functions for side effects, hidden mutation, non-determinism, deprecated APIs, and other patterns that make code less functional
- Interfaces: CLI and Python API
- Output formats: `text`, `json`, `sarif`
- Extensibility: built-in rules plus config-driven custom rules
- Package: `pip install fp-checker`

## Where To Start

- Feature overview: [docs/features.md](docs/features.md)
- Rule reference: [docs/rules.md](docs/rules.md)
- CLI / Python API usage: [docs/usage.md](docs/usage.md)
- Configuration: [docs/configuration.md](docs/configuration.md)
- Development setup: [docs/development.md](docs/development.md)
- CI / security: [docs/quality-and-security.md](docs/quality-and-security.md)

## 日本語

Python コードを解析し、関数型プログラミングのルールに反した関数を検査する Rust 製ツールです。CLI と Python API の両方を提供し、結果は text / JSON / SARIF の各形式で出力できます。組み込みルールに加えて、設定ファイルだけで custom rule を追加できます。

## どこを見れば何が分かるか

- 機能概要: [docs/features.md](docs/features.md)
- ルール仕様: [docs/rules.md](docs/rules.md)
- CLI / Python API の使い方: [docs/usage.md](docs/usage.md)
- 設定ファイル仕様: [docs/configuration.md](docs/configuration.md)
- 開発方法と Dev Container: [docs/development.md](docs/development.md)
- CI / セキュリティ方針: [docs/quality-and-security.md](docs/quality-and-security.md)

## 現在の実装範囲

- Rust workspace: `fp_checker_core`, `fp_checker_cli`, `fp_checker_py`
- Python 構文解析: `rustpython-parser` ベースの adapter
- ignore デコレータ: `@fp_ignore` を既定値としてサポート
- MVP ルール:
  - 可変グローバル状態
  - 代入の多用
  - 直接 I/O
  - 非決定的呼び出し
  - 外部状態への副作用
  - ミュータブルなデフォルト引数
  - 直接的な effectful call
  - `global` / `nonlocal`
- 追加ルール:
  - hidden mutation
  - loop 内副作用
  - 例外制御フロー
  - class method 内副作用
  - 参照透過性を壊す暗黙依存
  - 非推奨 API 使用
- 出力形式: text / JSON / SARIF
- AI 向けの structured `fix_hint` を JSON に含める
- CLI / Python API / `pyproject.toml` 設定対応
- 設定スキーマ: unknown key を reject する strict TOML
- config 駆動の custom rule: `call` / `name` / `attribute_write`
- CI 上の Python smoke test: 3.9 / 3.10 / 3.11 / 3.12
- JSON schema 検証: `tests/fixtures/report.schema.json`
- リリース自動化: tag push で GitHub Release と PyPI publish
- benchmark: `cargo bench -p fp_checker_core`
- pre-commit: `.pre-commit-config.yaml`

## クイックスタート

### PyPI からインストール

```bash
pip install fp-checker
```

```bash
fp-checker --help
```

```bash
fp-checker check path/to/project
```

```bash
python -m fp_checker --help
```

### CLI

```bash
cargo run -p fp_checker_cli -- check tests/fixtures/sample_project
```

```bash
cargo run -p fp_checker_cli -- check tests/fixtures/sample_project --format json
```

```bash
cargo run -p fp_checker_cli -- check tests/fixtures/sample_project --format sarif
```

### Python API

```bash
maturin develop --manifest-path crates/fp_checker_py/Cargo.toml
python3 -c "import fp_checker; print(fp_checker.available_rules())"
```

```python
import fp_checker

print(fp_checker.check_code("def f(items=[]):\n    return items", format="json"))
```

## 開発コマンド

```bash
cargo check
cargo fmt --check
cargo clippy --all-targets -- -D warnings
cargo test
```

## リポジトリ構成

```text
.
├── crates/
│   ├── fp_checker_cli/
│   ├── fp_checker_core/
│   └── fp_checker_py/
├── docs/
├── python/
│   └── examples/
├── tests/
│   └── fixtures/
├── .devcontainer/
├── .github/
│   ├── dependabot.yml
│   └── workflows/
├── Cargo.toml
├── pyproject.toml
├── CONTRIBUTING.md
├── SECURITY.md
└── CHANGELOG.md
```
