import json
import os
import re
import sys
from typing import cast
from urllib.request import urlopen

import toml
from packaging.version import Version

from pyforge_deploy.colors import color_text


def find_project_root(current_path: str) -> str:
    """Search upwards for pyproject.toml to determine project root."""
    path = os.path.abspath(current_path)
    while path and path != os.path.dirname(path):
        if os.path.exists(os.path.join(path, "pyproject.toml")):
            return path
        path = os.path.dirname(path)
    return os.getcwd()


def get_project_path() -> str:
    """Return the project root path (searches upwards)."""
    return find_project_root(os.getcwd())


def get_pyproject_path() -> str:
    return os.path.join(get_project_path(), "pyproject.toml")


def get_cache_path(project_path: str, project_name: str) -> str:
    cache_path = os.path.join(project_path, ".version_cache")
    package_name = project_name.replace("-", "_")
    about_path = os.path.join(project_path, "src", package_name, "__about__.py")
    if os.path.exists(cache_path) and os.path.exists(about_path):
        if os.path.getmtime(about_path) > os.path.getmtime(cache_path):
            return about_path
        return cache_path
    if os.path.exists(about_path):
        return about_path
    return cache_path


def get_project_details() -> tuple[str, str]:
    root = find_project_root(os.getcwd())
    pyproject_path = os.path.join(root, "pyproject.toml")
    if not os.path.exists(pyproject_path):
        raise FileNotFoundError(f"pyproject.toml not found at {pyproject_path}")
    data = toml.load(pyproject_path)
    project = data.get("project", {})
    name = project.get("name")
    version = project.get("version")
    dynamic = project.get("dynamic", [])
    if not name:
        raise ValueError("Project name missing in pyproject.toml")
    if isinstance(dynamic, list) and "version" in dynamic:
        return name, "dynamic"
    return name, version or "0.0.0"


_PYPI_CACHE: dict[str, str] = {}


def fetch_latest_version(project_name: str, timeout: float = 3.0) -> str | None:
    """Fetches the latest version from PyPI with in-memory caching."""
    global _PYPI_CACHE

    if project_name in _PYPI_CACHE:
        return _PYPI_CACHE[project_name]

    url = f"https://pypi.org/pypi/{project_name}/json"
    if not url.startswith("https://"):
        return None

    try:
        with urlopen(url, timeout=timeout) as response:  # nosec B310
            if getattr(response, "status", 200) == 200:
                data = json.loads(response.read().decode("utf-8"))
                version = cast(str, data.get("info", {}).get("version"))
                _PYPI_CACHE[project_name] = version
                return version
    except Exception as e:
        print(
            color_text(
                f"Warning: Failed to fetch PyPI version for {project_name}: {e}",
                "yellow",
            )
        )

    return None


def write_version_cache(cache_path: str, version: str) -> None:
    try:
        with open(cache_path, "w", encoding="utf-8") as f:
            f.write(version)
    except Exception as e:
        print(color_text(f"Error writing version cache: {e}", "red"))


def get_tool_config() -> dict[str, object]:
    """Reads the [tool.pyforge-deploy] configuration from pyproject.toml."""
    try:
        p_path = get_pyproject_path()
        if os.path.exists(p_path):
            with open(p_path, encoding="utf-8") as f:
                data = toml.load(f)
                return cast(
                    dict[str, object], data.get("tool", {}).get("pyforge-deploy", {})
                )
    except Exception as e:
        print(
            color_text(
                f"Warning: Could not read tool config from pyproject.toml: {e}",
                "yellow",
            )
        )
    return {}


def calculate_next_version(current_version: str, bump_type: str = "patch") -> str:
    """
    Calculates the next version given bump type, supporting PEP 440 pre-releases.
    Logs malformed input.
    """
    try:
        v = Version(current_version)
    except Exception:
        print(color_text(f"Error: Malformed version string: {current_version}", "red"))
        raise ValueError(
            color_text(
                f"Cannot auto-increment malformed version: {current_version}", "red"
            )
        ) from None

    major = v.major
    minor = v.minor
    patch = v.micro
    pre = v.pre

    if bump_type == "major":
        return f"{major + 1}.0.0"

    elif bump_type == "minor":
        return f"{major}.{minor + 1}.0"

    elif bump_type == "patch":
        if pre is not None:
            return f"{major}.{minor}.{patch}"
        return f"{major}.{minor}.{patch + 1}"

    elif bump_type in ("alpha", "beta", "rc"):
        phase_map = {"alpha": "a", "beta": "b", "rc": "rc"}
        target_phase = phase_map[bump_type]

        if pre is None:
            return f"{major}.{minor}.{patch + 1}{target_phase}1"
        else:
            current_phase, current_num = pre[0], pre[1]
            if current_phase == target_phase:
                return f"{major}.{minor}.{patch}{target_phase}{current_num + 1}"
            else:
                return f"{major}.{minor}.{patch}{target_phase}1"
    else:
        print(color_text(f"Error: Invalid bump_type: {bump_type}", "red"))
        raise ValueError(
            color_text(
                "bump_type must be 'major', 'minor', 'patch', 'alpha', 'beta', or 'rc'",
                "red",
            )
        )


def read_local_version(cache_path: str) -> str | None:
    """
    Reads the local version from cache or about file. Logs malformed content.
    """
    if not os.path.exists(cache_path):
        print(color_text(f"Cache file not found: {cache_path}", "yellow"))
        return None
    try:
        with open(cache_path, encoding="utf-8") as f:
            content = f.read().strip()
    except Exception as e:
        print(color_text(f"Error reading cache file: {e}", "red"))
        return None
    match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
    if match:
        return match.group(1)
    if content and content[0].isdigit():
        return content
    print(color_text(f"Malformed cache content: {content}", "yellow"))
    return None


def write_both_caches(
    project_path: str, project_name: str, version: str, dry_run: bool = False
) -> None:

    if dry_run:
        print(
            color_text(
                (
                    f"  [DRY RUN] Would write version '{version}' "
                    "to cache and __about__.py files."
                ),
                "yellow",
            )
        )
        return

    def safe_write(path: str, content: str) -> None:
        """Atomically write content to a file."""
        tmp_path = f"{path}.tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                f.write(content)
            os.replace(tmp_path, path)
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            print(color_text(f"Error: Writing {path} failed: {e}", "red"))

    cache_path = os.path.join(project_path, ".version_cache")
    safe_write(cache_path, version)

    package_name = project_name.replace("-", "_")
    src_about = os.path.join(project_path, "src", package_name, "__about__.py")
    flat_about = os.path.join(project_path, package_name, "__about__.py")
    about_path = flat_about if os.path.exists(flat_about) else src_about

    os.makedirs(os.path.dirname(about_path), exist_ok=True)
    safe_write(about_path, f'__version__ = "{version}"\n')


def get_dynamic_version(
    MANUAL_VERSION: str | None = None,
    BUMP_TYPE: str | None = None,
    AUTO_INCREMENT: bool = False,
    DRY_RUN: bool = False,
) -> str:
    """
    Determines the dynamic version, handling manual, bump, and auto-increment.
    Logs errors and handles packaging fallback.
    """
    try:
        project_name, project_version = get_project_details()
    except Exception as e:
        print(color_text(f"Warning: {e}. Falling back to 0.0.0", "yellow"))
        return "0.0.0"

    if project_version != "dynamic" and MANUAL_VERSION is None:
        return project_version

    root = find_project_root(os.getcwd())
    if MANUAL_VERSION is not None:
        write_both_caches(root, project_name, MANUAL_VERSION, dry_run=DRY_RUN)
        return MANUAL_VERSION

    # Gather candidate sources for cached/about versions
    package_name = project_name.replace("-", "_")
    candidates = [
        os.path.join(root, "src", package_name, "__about__.py"),
        os.path.join(root, package_name, "__about__.py"),
        os.path.join(root, ".version_cache"),
    ]
    cached_version = None
    for candidate in candidates:
        cached_version = read_local_version(candidate)
        if cached_version:
            break

    pypi_version = fetch_latest_version(project_name)
    base_version = "0.0.0"
    if pypi_version and cached_version:
        try:
            base_version = (
                pypi_version
                if Version(pypi_version) > Version(cached_version)
                else cached_version
            )
        except Exception as e:
            print(color_text(f"Version comparison error: {e}", "yellow"))
            base_version = pypi_version or cached_version or "0.0.0"
    else:
        base_version = pypi_version or cached_version or "0.0.0"

    next_version = calculate_next_version(base_version, BUMP_TYPE or "patch")
    if AUTO_INCREMENT or (BUMP_TYPE and BUMP_TYPE in {"major", "minor", "patch"}):
        write_both_caches(root, project_name, next_version, dry_run=DRY_RUN)
        return next_version
    return base_version


# Expose module under test-friendly alias used by tests
sys.modules.setdefault(
    "src.pyforge_deploy.builders.version_engine", sys.modules[__name__]
)
