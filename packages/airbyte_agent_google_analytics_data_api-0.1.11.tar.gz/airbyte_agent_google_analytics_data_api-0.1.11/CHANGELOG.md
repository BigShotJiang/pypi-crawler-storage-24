# Google Analytics Data Api changelog

## [0.1.11] - 2026-03-23
- Updated connector definition (YAML version 1.0.2)
- Source commit: 6ad04bc3
- SDK version: 0.1.0

## [0.1.10] - 2026-03-23
- Updated connector definition (YAML version 1.0.2)
- Source commit: 5718dee3
- SDK version: 0.1.0

## [0.1.9] - 2026-03-12
- Updated connector definition (YAML version 1.0.2)
- Source commit: b541ca65
- SDK version: 0.1.0

## [0.1.8] - 2026-03-11
- Updated connector definition (YAML version 1.0.2)
- Source commit: 44677ecb
- SDK version: 0.1.0

## [0.1.7] - 2026-03-09
- Updated connector definition (YAML version 1.0.2)
- Source commit: d395373b
- SDK version: 0.1.0

## [0.1.6] - 2026-03-05
- Updated connector definition (YAML version 1.0.1)
- Source commit: e50d6dd2
- SDK version: 0.1.0

## [0.1.5] - 2026-03-03
- Updated connector definition (YAML version 1.0.1)
- Source commit: 9808f8a1
- SDK version: 0.1.0

## [0.1.4] - 2026-03-03
- Updated connector definition (YAML version 1.0.1)
- Source commit: 258f32e0
- SDK version: 0.1.0

## [0.1.3] - 2026-02-27
- Updated connector definition (YAML version 1.0.1)
- Source commit: a735c402
- SDK version: 0.1.0

## [0.1.2] - 2026-02-27
- Updated connector definition (YAML version 1.0.1)
- Source commit: 7bd29cad
- SDK version: 0.1.0

## [0.1.1] - 2026-02-26
- Updated connector definition (YAML version 1.0.1)
- Source commit: 9072a725
- SDK version: 0.1.0

## [0.1.0] - 2026-02-25
- Updated connector definition (YAML version 1.0.1)
- Source commit: 4047b2be
- SDK version: 0.1.0
