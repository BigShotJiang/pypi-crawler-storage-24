"""
Python wrapper for the Rust-based pyg_engine native module.

This module provides a clean Python interface to the Rust engine implementation
with comprehensive logging capabilities.
"""

import inspect
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    pass

try:
    from .pyg_engine_native import DrawCommand as _RustDrawCommand
    from .pyg_engine_native import Vec2 as _RustVec2
    from .pyg_engine_native import Engine as _RustEngine
    from .pyg_engine_native import EngineHandle as _RustEngineHandle
    from .pyg_engine_native import CameraAspectMode, Keys, MouseButton
except ImportError as e:
    raise ImportError(
        "Failed to import pyg_engine_native. "
        "The Rust extension may not be compiled. "
        "Run 'pip install -e .' to build the extension."
    ) from e

DrawCommand = _RustDrawCommand

from .shapes import to_draw_commands


_PACKAGE_ROOT = Path(__file__).resolve().parent


def _detect_source_root() -> Path:
    for frame_info in inspect.stack()[1:]:
        filename = frame_info.filename
        if not filename or filename.startswith("<"):
            continue
        resolved = Path(filename).resolve()
        if _PACKAGE_ROOT in resolved.parents or resolved == _PACKAGE_ROOT:
            continue
        return resolved.parent
    return Path.cwd()


class EngineHandle:
    """
    Thread-safe handle to the engine that can be passed to background threads.

    Use this handle to queue commands like adding objects or drawing from other threads.
    """
    def __init__(self, inner: _RustEngineHandle) -> None:
        self._inner = inner

    def add_game_object(self, game_object: Any) -> None:
        """
        Add a `pyg_engine.GameObject` to the runtime scene from a background thread.

        This is thread-safe and will be processed on the next engine update.
        Useful for loading objects asynchronously or from event callbacks.

        Args:
            game_object: The GameObject instance to add to the scene.

        Example:
            ```python
            import threading
            from pyg_engine import GameObject, EngineHandle

            def load_async(handle: EngineHandle):
                obj = GameObject()
                # ... configure object ...
                handle.add_game_object(obj)

            handle = engine.get_handle()
            thread = threading.Thread(target=load_async, args=(handle,))
            thread.start()
            ```
        """
        self._inner.add_game_object(game_object)

    def remove_game_object(self, object_id: int) -> None:
        """
        Remove a runtime GameObject by its ID via the command queue.

        This is thread-safe and the removal will be processed on the next engine update.

        Args:
            object_id: The ID of the GameObject to remove.

        Example:
            ```python
            handle = engine.get_handle()
            obj_id = engine.add_game_object(my_object)

            # Later, from any thread:
            handle.remove_game_object(obj_id)
            ```
        """
        self._inner.remove_game_object(object_id)

    def set_game_object_position(self, object_id: int, position: Any) -> None:
        """
        Update a runtime GameObject position by ID via command queue.

        This is thread-safe and the update will be processed on the next engine update.

        Args:
            object_id: The ID of the GameObject to update.
            position: A `pyg_engine.Vec2` or `pyg_engine.Vec3` for the new position.

        Example:
            ```python
            from pyg_engine import Vec2

            handle = engine.get_handle()
            new_pos = Vec2(100.0, 200.0)
            handle.set_game_object_position(player_id, new_pos)
            ```
        """
        self._inner.set_game_object_position(object_id, position)

    def set_camera_position(self, position: Any) -> None:
        """
        Update the active camera world position via command queue.

        This is thread-safe and can be called from background threads.

        Args:
            position: A `pyg_engine.Vec2` or `pyg_engine.Vec3` in world space.

        Example:
            ```python
            from pyg_engine import Vec2

            handle = engine.get_handle()
            # Center camera on player
            handle.set_camera_position(Vec2(player_x, player_y))
            ```
        """
        self._inner.set_camera_position(position)

    def set_camera_viewport_size(self, width: float, height: float) -> None:
        """
        Update the active camera viewport size in world units via command queue.

        This is thread-safe and can be called from background threads.
        The viewport size defines how many world units are visible on screen.

        Args:
            width: Viewport width in world units.
            height: Viewport height in world units.

        Example:
            ```python
            handle = engine.get_handle()
            # Show 20 world units wide, 15 units tall
            handle.set_camera_viewport_size(20.0, 15.0)
            ```
        """
        self._inner.set_camera_viewport_size(width, height)

    def set_camera_aspect_mode(self, mode: str) -> None:
        """
        Update camera aspect handling mode via command queue.

        This is thread-safe and can be called from background threads.

        Args:
            mode: Aspect mode string. Options:
                - "stretch": Stretch to fill window (may distort)
                - "match_horizontal": Match width, adjust height
                - "match_vertical": Match height, adjust width
                - "fit_both": Fit entire viewport with letterboxing
                - "fill_both": Fill window, may crop viewport

        Example:
            ```python
            handle = engine.get_handle()
            # Keep consistent horizontal view
            handle.set_camera_aspect_mode("match_horizontal")
            ```
        """
        self._inner.set_camera_aspect_mode(mode)

    def set_camera_background_color(self, color: Any) -> None:
        """Update the active camera background clear color via command queue."""
        self._inner.set_camera_background_color(color)

    def clear_draw_commands(self) -> None:
        """Clear all immediate-mode drawing commands via command queue."""
        self._inner.clear_draw_commands()

    def add_draw_commands(self, commands: list[Any]) -> None:
        """Submit many draw shapes or draw commands via command queue."""
        self._inner.add_draw_commands(to_draw_commands(commands))

    def draw(self, drawable: Any) -> None:
        """Draw one shape or a batch of shapes via the command queue."""
        self._inner.add_draw_commands(to_draw_commands(drawable))

    def draw_pixel(
        self,
        x: int,
        y: int,
        color: Any,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a single pixel in window coordinates via the command queue.

        This is thread-safe and can be called from background threads.

        Args:
            x: X coordinate in pixels (0 = left edge).
            y: Y coordinate in pixels (0 = top edge).
            color: A `pyg_engine.Color` instance.
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            handle = engine.get_handle()
            red = Color(1.0, 0.0, 0.0, 1.0)
            handle.draw_pixel(100, 100, red, draw_order=5.0)
            ```
        """
        self._inner.draw_pixel(x, y, color, draw_order=draw_order)

    def draw_line(
        self,
        start_x: float,
        start_y: float,
        end_x: float,
        end_y: float,
        color: Any,
        thickness: float = 1.0,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a line in window coordinates via the command queue.

        This is thread-safe and can be called from background threads.

        Args:
            start_x: Starting X coordinate in pixels.
            start_y: Starting Y coordinate in pixels.
            end_x: Ending X coordinate in pixels.
            end_y: Ending Y coordinate in pixels.
            color: A `pyg_engine.Color` instance.
            thickness: Line width in pixels (default: 1.0).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            handle = engine.get_handle()
            white = Color(1.0, 1.0, 1.0, 1.0)
            # Draw a diagonal line from top-left to bottom-right
            handle.draw_line(0, 0, 800, 600, white, thickness=2.0)
            ```
        """
        self._inner.draw_line(
            start_x,
            start_y,
            end_x,
            end_y,
            color,
            thickness=thickness,
            draw_order=draw_order,
        )

    def draw_rectangle(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        color: Any,
        filled: bool = True,
        thickness: float = 1.0,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a rectangle in window coordinates via the command queue.

        This is thread-safe and can be called from background threads.

        Args:
            x: Top-left X coordinate in pixels.
            y: Top-left Y coordinate in pixels.
            width: Rectangle width in pixels.
            height: Rectangle height in pixels.
            color: A `pyg_engine.Color` instance.
            filled: If True, draws a filled rectangle; if False, draws an outline (default: True).
            thickness: Border thickness when filled=False (default: 1.0).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            handle = engine.get_handle()
            blue = Color(0.0, 0.5, 1.0, 1.0)

            # Draw filled rectangle
            handle.draw_rectangle(100, 100, 200, 150, blue)

            # Draw outline only
            handle.draw_rectangle(350, 100, 200, 150, blue, filled=False, thickness=3.0)
            ```
        """
        self._inner.draw_rectangle(
            x,
            y,
            width,
            height,
            color,
            filled=filled,
            thickness=thickness,
            draw_order=draw_order,
        )

    def draw_circle(
        self,
        center_x: float,
        center_y: float,
        radius: float,
        color: Any,
        filled: bool = True,
        thickness: float = 1.0,
        segments: int = 32,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a circle in window coordinates via the command queue.

        This is thread-safe and can be called from background threads.

        Args:
            center_x: Center X coordinate in pixels.
            center_y: Center Y coordinate in pixels.
            radius: Circle radius in pixels.
            color: A `pyg_engine.Color` instance.
            filled: If True, draws a filled circle; if False, draws an outline (default: True).
            thickness: Border thickness when filled=False (default: 1.0).
            segments: Number of line segments for smoothness (default: 32).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            handle = engine.get_handle()
            green = Color(0.0, 1.0, 0.0, 1.0)

            # Draw filled circle
            handle.draw_circle(400, 300, 50, green)

            # Draw smooth outline with more segments
            handle.draw_circle(500, 300, 50, green, filled=False, thickness=2.0, segments=64)
            ```
        """
        self._inner.draw_circle(
            center_x,
            center_y,
            radius,
            color,
            filled=filled,
            thickness=thickness,
            segments=segments,
            draw_order=draw_order,
        )

    def draw_gradient_rect(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        top_left: Any,
        bottom_left: Any,
        bottom_right: Any,
        top_right: Any,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a rectangle with gradient colors (different color per corner) via the command queue.

        This is thread-safe and can be called from background threads.

        Args:
            x: Top-left X coordinate in pixels.
            y: Top-left Y coordinate in pixels.
            width: Rectangle width in pixels.
            height: Rectangle height in pixels.
            top_left: `pyg_engine.Color` for the top-left corner.
            bottom_left: `pyg_engine.Color` for the bottom-left corner.
            bottom_right: `pyg_engine.Color` for the bottom-right corner.
            top_right: `pyg_engine.Color` for the top-right corner.
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            handle = engine.get_handle()
            red = Color(1.0, 0.0, 0.0, 1.0)
            blue = Color(0.0, 0.0, 1.0, 1.0)
            green = Color(0.0, 1.0, 0.0, 1.0)
            yellow = Color(1.0, 1.0, 0.0, 1.0)

            # Draw a gradient rectangle with different colors at each corner
            handle.draw_gradient_rect(100, 100, 300, 200, red, blue, green, yellow)
            ```
        """
        self._inner.draw_gradient_rect(
            x,
            y,
            width,
            height,
            top_left,
            bottom_left,
            bottom_right,
            top_right,
            draw_order=draw_order,
        )

    def draw_image(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        texture_path: str,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw an image from a file path via the command queue.

        This is thread-safe and can be called from background threads.
        The image is cached internally, so repeated calls with the same path are efficient.

        Args:
            x: Top-left X coordinate in pixels.
            y: Top-left Y coordinate in pixels.
            width: Display width in pixels.
            height: Display height in pixels.
            texture_path: File path to the image (PNG, JPG, etc.).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            handle = engine.get_handle()

            # Draw a sprite at position (100, 100) with size 64x64
            handle.draw_image(100, 100, 64, 64, "assets/player.png")

            # Draw a background image stretched to fit
            handle.draw_image(0, 0, 1280, 720, "assets/background.jpg", draw_order=-1.0)
            ```
        """
        self._inner.draw_image(
            x,
            y,
            width,
            height,
            texture_path,
            draw_order=draw_order,
        )

    def draw_image_from_bytes(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        texture_key: str,
        rgba: bytes,
        texture_width: int,
        texture_height: int,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw an image from raw RGBA bytes via the command queue.

        This is thread-safe and can be called from background threads.
        Useful for procedurally generated textures or image data from memory.

        Args:
            x: Top-left X coordinate in pixels.
            y: Top-left Y coordinate in pixels.
            width: Display width in pixels.
            height: Display height in pixels.
            texture_key: Unique identifier for caching this texture.
            rgba: Raw RGBA bytes (4 bytes per pixel: R, G, B, A).
            texture_width: Width of the source texture in pixels.
            texture_height: Height of the source texture in pixels.
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            handle = engine.get_handle()

            # Create a 2x2 checkerboard pattern
            width, height = 2, 2
            pixels = bytes([
                255, 0, 0, 255,    # Red pixel
                0, 255, 0, 255,    # Green pixel
                0, 0, 255, 255,    # Blue pixel
                255, 255, 0, 255   # Yellow pixel
            ])

            # Draw it scaled up to 100x100
            handle.draw_image_from_bytes(100, 100, 100, 100, "checkerboard", pixels, width, height)
            ```
        """
        self._inner.draw_image_from_bytes(
            x,
            y,
            width,
            height,
            texture_key,
            rgba,
            texture_width,
            texture_height,
            draw_order=draw_order,
        )

    def draw_text(
        self,
        text: str,
        x: float,
        y: float,
        color: Any,
        font_size: float = 24.0,
        font_path: Optional[str] = None,
        font_family: Optional[str] = None,
        font_weight: Optional[str] = None,
        font_style: Optional[str] = None,
        letter_spacing: float = 0.0,
        line_spacing: float = 0.0,
        kerning: bool = True,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw text via command queue.

        This is thread-safe and can be called from background threads.
        By default, uses the engine's built-in open-source font.
        Provide `font_path` for a one-off TTF/OTF file, or `font_family`
        plus `font_weight` / `font_style` after registering a family.

        Args:
            text: The text string to display.
            x: Left edge X coordinate in pixels.
            y: Top edge Y coordinate in pixels.
            color: A `pyg_engine.Color` instance.
            font_size: Font size in points (default: 24.0).
            font_path: Optional path to custom TTF/OTF font file.
            letter_spacing: Extra spacing between characters in pixels (default: 0.0).
            line_spacing: Extra spacing between lines in pixels for multi-line text (default: 0.0).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            handle = engine.get_handle()
            white = Color.WHITE

            # Simple text with default font
            handle.draw_text("Score: 100", 10, 10, white, font_size=18)

            # Custom font with spacing
            handle.draw_text(
                "Game Title",
                400, 50, white,
                font_size=48,
                font_path="assets/fonts/title.ttf",
                letter_spacing=2.0
            )

            # Multi-line text
            handle.draw_text(
                "Line 1\\nLine 2\\nLine 3",
                100, 100, white,
                font_size=16,
                line_spacing=5.0
            )
            ```
        """
        self._inner.draw_text(
            text,
            x,
            y,
            color,
            font_size=font_size,
            font_path=font_path,
            font_family=font_family,
            font_weight=font_weight,
            font_style=font_style,
            letter_spacing=letter_spacing,
            line_spacing=line_spacing,
            kerning=kerning,
            draw_order=draw_order,
        )

    def register_font_family(
        self,
        family: str,
        *,
        regular: Optional[str] = None,
        bold: Optional[str] = None,
        italic: Optional[str] = None,
        bold_italic: Optional[str] = None,
    ) -> None:
        """Register a reusable font family for later `draw_text()` calls."""
        self._inner.register_font_family(
            family,
            regular=regular,
            bold=bold,
            italic=italic,
            bold_italic=bold_italic,
        )

    def update_ui_label_text(self, object_id: int, text: str) -> None:
        """
        Update a UI label's text at runtime by object ID via command queue.

        This is thread-safe and can be called from callbacks without borrow issues.

        Args:
            object_id: The GameObject ID of the label to update.
            text: The new text for the label.
        """
        self._inner.update_ui_label_text(object_id, text)

    def update_ui_button_text(self, object_id: int, text: str) -> None:
        """
        Update a UI button's text at runtime by object ID via command queue.

        This is thread-safe and can be called from callbacks without borrow issues.

        Args:
            object_id: The GameObject ID of the button to update.
            text: The new text for the button.
        """
        self._inner.update_ui_button_text(object_id, text)

    def log(self, message: str) -> None:
        """
        Log a message at INFO level (default log method).

        Args:
            message: The message to log.
        """
        self._inner.log(message)

    def log_trace(self, message: str) -> None:
        """
        Log a message at TRACE level (most verbose).

        Args:
            message: The message to log.
        """
        self._inner.log_trace(message)

    def log_debug(self, message: str) -> None:
        """
        Log a message at DEBUG level.

        Args:
            message: The message to log.
        """
        self._inner.log_debug(message)

    def log_info(self, message: str) -> None:
        """
        Log a message at INFO level.

        Args:
            message: The message to log.
        """
        self._inner.log_info(message)

    def log_warn(self, message: str) -> None:
        """
        Log a message at WARN level.

        Args:
            message: The message to log.
        """
        self._inner.log_warn(message)

    def log_error(self, message: str) -> None:
        """
        Log a message at ERROR level.

        Args:
            message: The message to log.
        """
        self._inner.log_error(message)


class EngineObjects:
    """Runtime object lookup facade."""

    def __init__(self, engine: "Engine") -> None:
        self._engine = engine

    def get_id(self, object_id: int) -> Optional[Any]:
        """Get a runtime object by id."""
        return self._engine._engine.get_game_object_id(object_id)

    def get_name(self, name: str) -> list[Any]:
        """Get all runtime objects with a matching name."""
        return list(self._engine._engine.get_game_object_name(name))


class _LiveVec2Proxy:
    def __init__(
        self,
        getter: Callable[[], Any],
        setter: Callable[[Any], Any],
        *,
        x_name: str = "x",
        y_name: str = "y",
    ) -> None:
        self._getter = getter
        self._setter = setter
        self._x_name = x_name
        self._y_name = y_name

    def _get_vec(self) -> Any:
        return self._getter()

    def _set_xy(self, x: float, y: float) -> None:
        self._setter(_RustVec2(float(x), float(y)))

    @property
    def x(self) -> float:
        return float(getattr(self._get_vec(), self._x_name))

    @x.setter
    def x(self, value: float) -> None:
        current = self._get_vec()
        self._set_xy(float(value), float(getattr(current, self._y_name)))

    @property
    def y(self) -> float:
        return float(getattr(self._get_vec(), self._y_name))

    @y.setter
    def y(self, value: float) -> None:
        current = self._get_vec()
        self._set_xy(float(getattr(current, self._x_name)), float(value))

    @property
    def width(self) -> float:
        return self.x

    @width.setter
    def width(self, value: float) -> None:
        self.x = value

    @property
    def height(self) -> float:
        return self.y

    @height.setter
    def height(self, value: float) -> None:
        self.y = value

    def to_vec2(self) -> Any:
        current = self._get_vec()
        return _RustVec2(float(getattr(current, self._x_name)), float(getattr(current, self._y_name)))

    def __iter__(self):
        current = self._get_vec()
        yield float(getattr(current, self._x_name))
        yield float(getattr(current, self._y_name))

    def __repr__(self) -> str:
        return f"Vec2({self.x}, {self.y})"


class CameraProxy:
    def __init__(self, engine: "Engine") -> None:
        object.__setattr__(self, "_engine_wrapper", engine)

    def _game_object(self) -> Optional[Any]:
        return self._engine_wrapper._engine.get_camera_object()

    def __getattr__(self, name: str) -> Any:
        game_object = self._game_object()
        if game_object is None:
            raise AttributeError(name)
        return getattr(game_object, name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name == "_engine_wrapper":
            object.__setattr__(self, name, value)
            return
        descriptor = getattr(type(self), name, None)
        if isinstance(descriptor, property) and descriptor.fset is not None:
            descriptor.fset(self, value)
            return
        game_object = self._game_object()
        if game_object is None:
            raise AttributeError(name)
        setattr(game_object, name, value)

    @property
    def game_object(self) -> Optional[Any]:
        return self._game_object()

    @property
    def position(self) -> _LiveVec2Proxy:
        return _LiveVec2Proxy(
            getter=self._engine_wrapper._engine.get_camera_position,
            setter=self._engine_wrapper._engine.set_camera_position,
        )

    @position.setter
    def position(self, value: Any) -> None:
        self._engine_wrapper._engine.set_camera_position(value)

    @property
    def viewport_size(self) -> _LiveVec2Proxy:
        def getter() -> Any:
            width, height = self._engine_wrapper._engine.get_camera_viewport_size()
            return _RustVec2(width, height)

        def setter(value: Any) -> None:
            self._engine_wrapper._engine.set_camera_viewport_size(float(value.x), float(value.y))

        return _LiveVec2Proxy(getter=getter, setter=setter)

    @viewport_size.setter
    def viewport_size(self, value: Any) -> None:
        self._engine_wrapper._engine.set_camera_viewport_size(float(value.x), float(value.y))

    @property
    def aspect_mode(self) -> str:
        return self._engine_wrapper._engine.get_camera_aspect_mode()

    @aspect_mode.setter
    def aspect_mode(self, value: str) -> None:
        self._engine_wrapper._engine.set_camera_aspect_mode(value)

    @property
    def background_color(self) -> Any:
        return self._engine_wrapper._engine.get_camera_background_color()

    @background_color.setter
    def background_color(self, value: Any) -> None:
        self._engine_wrapper._engine.set_camera_background_color(value)

    def __repr__(self) -> str:
        game_object = self._game_object()
        if game_object is None:
            return "CameraProxy(None)"
        return f"CameraProxy({game_object!r})"

    def __bool__(self) -> bool:
        return self._game_object() is not None


class UIManager:
    """
    Manages UI elements like buttons, panels, and labels.

    This class provides methods to add UI components to the engine.
    It is accessed via the `engine.ui` property.

    Example:
        ```python
        engine = Engine()

        # Create and add a button
        button = Button("Click Me", x=100, y=50, width=120, height=40)
        engine.ui.add(button)

        # Create and add a panel
        panel = Panel(x=50, y=50, width=300, height=200)
        panel.set_background_color(0.9, 0.9, 0.9, 1.0)
        engine.ui.add(panel)

        # Create and add a label
        label = Label("Score: 0", x=100, y=100, font_size=16)
        engine.ui.add(label)
        ```
    """
    def __init__(self, engine: "Engine") -> None:
        self._engine = engine

    def add(self, ui_component: Any) -> Optional[int]:
        """
        Add a UI component (Button, Panel, or Label) to the engine.

        Args:
            ui_component: A Button, Panel, or Label instance.

        Returns:
            The runtime object ID, or None if add failed.

        Example:
        ```python
            button = Button("Click Me", x=100, y=50)
            engine.ui.add(button)

            panel = Panel(x=50, y=50, width=300, height=200)
            engine.ui.add(panel)

            label = Label("Hello", x=100, y=100)
            engine.ui.add(label)
        ```
        """
        # Import here to avoid circular dependency
        from . import ui as ui_module

        if isinstance(ui_component, (ui_module.Button, ui_module.Panel, ui_module.Label)):
            return self._add_tree(ui_component)
        raise TypeError(
            f"Expected Button, Panel, or Label, got {type(ui_component).__name__}"
        )

    def get_id(self, object_id: int) -> Optional[Any]:
        """Get a UI element by runtime id."""
        obj = self._engine.objects.get_id(object_id)
        if obj is None or getattr(obj, "object_type", None) != "UIObject":
            return None
        return obj

    def get_name(self, name: str) -> list[Any]:
        """Get UI elements by name."""
        return [
            obj
            for obj in self._engine.objects.get_name(name)
            if getattr(obj, "object_type", None) == "UIObject"
        ]

    def _add_tree(self, ui_component: Any) -> Optional[int]:
        object_id = self._add_single(ui_component)
        for child in list(getattr(ui_component, "_children", [])):
            self._add_tree(child)
            ui_component._game_object.add_child(child._game_object)
        return object_id

    def _add_single(self, ui_component: Any) -> Optional[int]:
        from . import ui as ui_module

        if isinstance(ui_component, ui_module.Button):
            return self._add_button(ui_component)
        if isinstance(ui_component, ui_module.Panel):
            return self._add_panel(ui_component)
        if isinstance(ui_component, ui_module.Label):
            return self._add_label(ui_component)
        raise TypeError(
            f"Expected Button, Panel, or Label, got {type(ui_component).__name__}"
        )

    def _add_button(self, button: Any) -> Optional[int]:
        """Internal: Add a Button to the engine."""
        from .pyg_engine_native import GameObject

        if getattr(button, "_object_id", None) is not None:
            return button._object_id

        # Store engine handle for callbacks
        button._engine_handle = self._engine.get_handle()

        # Set up callback wrapper if user provided a callback
        if button._user_callback:
            button._setup_callback()

        button._game_object = GameObject()
        button._game_object.set_name(button.text or "Button")
        button._game_object.set_object_type("UIObject")
        button._game_object.add_component(button._component)
        button._object_id = self._engine.add_game_object(button._game_object)
        return button._object_id

    def _add_panel(self, panel: Any) -> Optional[int]:
        """Internal: Add a Panel to the engine."""
        from .pyg_engine_native import GameObject

        if getattr(panel, "_object_id", None) is not None:
            return panel._object_id

        panel._game_object = GameObject()
        panel._game_object.set_name("Panel")
        panel._game_object.set_object_type("UIObject")
        panel._game_object.add_component(panel._component)
        panel._object_id = self._engine.add_game_object(panel._game_object)
        return panel._object_id

    def _add_label(self, label: Any) -> Optional[int]:
        """Internal: Add a Label to the engine."""
        from .pyg_engine_native import GameObject

        if getattr(label, "_object_id", None) is not None:
            return label._object_id

        # Store engine handle instead of engine to avoid borrow checker issues in callbacks
        label._engine = self._engine.get_handle()
        label._game_object = GameObject()
        label._game_object.set_name(label.text or "Label")
        label._game_object.set_object_type("UIObject")
        label._game_object.add_component(label._component)
        label._object_id = self._engine.add_game_object(label._game_object)
        return label._object_id


class Input:
    """
    Handles keyboard, mouse, and joystick input.

    This class provides methods to check the current state of input devices
    and events. It is accessed via the `engine.input` property.

    Example:
        ```python
        from pyg_engine import Engine, MouseButton

        engine = Engine()

        def update(ctx):
            # Check if space key is pressed this frame
            if ctx.input.key_pressed("Space"):
                print("Jump!")

            # Check if W key is held down
            if ctx.input.key_down("W"):
                print("Moving forward")

            # Check mouse button
            if ctx.input.mouse_button_pressed(MouseButton.Left):
                x, y = ctx.input.mouse_position
                print(f"Clicked at {x}, {y}")

        engine.run(update=update)
        ```
    """
    def __init__(self, engine: "Engine") -> None:
        self._engine = engine._engine

    def key_down(self, key: str) -> bool:
        """
        Check if a keyboard key is currently held down.

        This returns True for every frame while the key is pressed.

        Args:
            key: The key name (e.g., "W", "Space", "Escape", "Return").

        Returns:
            True if the key is currently pressed, False otherwise.

        Example:
            ```python
            # Continuous movement while key is held
            if engine.input.key_down("W"):
                player_y += speed * dt
            ```
        """
        return self._engine.key_down(key)

    def key_pressed(self, key: str) -> bool:
        """
        Check if a keyboard key was pressed this frame.

        This returns True only on the frame when the key is first pressed down.

        Args:
            key: The key name (e.g., "W", "Space", "Escape", "Return").

        Returns:
            True if the key was just pressed this frame, False otherwise.

        Example:
            ```python
            # Single action on key press (not repeated)
            if engine.input.key_pressed("Space"):
                player.jump()
            ```
        """
        return self._engine.key_pressed(key)

    def key_released(self, key: str) -> bool:
        """
        Check if a keyboard key was released this frame.

        This returns True only on the frame when the key is released.

        Args:
            key: The key name (e.g., "W", "Space", "Escape", "Return").

        Returns:
            True if the key was just released this frame, False otherwise.

        Example:
            ```python
            # Detect when player stops charging
            if engine.input.key_released("Space"):
                player.release_charge()
            ```
        """
        return self._engine.key_released(key)

    def mouse_button_down(self, button: MouseButton) -> bool:
        """
        Check if a mouse button is currently held down.

        This returns True for every frame while the button is pressed.

        Args:
            button: The mouse button to check (MouseButton.Left, MouseButton.Right, or MouseButton.Middle).

        Returns:
            True if the button is currently pressed, False otherwise.

        Example:
            ```python
            from pyg_engine import MouseButton

            # Continuous action while button is held
            if engine.input.mouse_button_down(MouseButton.Left):
                player.fire_continuously()
            ```
        """
        return self._engine.mouse_button_down(button)

    def mouse_button_pressed(self, button: MouseButton) -> bool:
        """
        Check if a mouse button was pressed this frame.

        This returns True only on the frame when the button is first pressed down.

        Args:
            button: The mouse button to check (MouseButton.Left, MouseButton.Right, or MouseButton.Middle).

        Returns:
            True if the button was just pressed this frame, False otherwise.

        Example:
            ```python
            from pyg_engine import MouseButton

            # Single action on button press
            if engine.input.mouse_button_pressed(MouseButton.Left):
                x, y = engine.input.mouse_position
                player.shoot_at(x, y)
            ```
        """
        return self._engine.mouse_button_pressed(button)

    def mouse_button_released(self, button: MouseButton) -> bool:
        """
        Check if a mouse button was released this frame.

        This returns True only on the frame when the button is released.

        Args:
            button: The mouse button to check (MouseButton.Left, MouseButton.Right, or MouseButton.Middle).

        Returns:
            True if the button was just released this frame, False otherwise.

        Example:
            ```python
            from pyg_engine import MouseButton

            # Detect when player stops dragging
            if engine.input.mouse_button_released(MouseButton.Left):
                player.finish_drag()
            ```
        """
        return self._engine.mouse_button_released(button)

    @property
    def mouse_position(self) -> tuple[float, float]:
        """
        Get the current mouse position in window coordinates.

        Returns:
            A tuple (x, y) where x and y are pixel coordinates.
            (0, 0) is the top-left corner of the window.

        Example:
            ```python
            x, y = engine.input.mouse_position
            print(f"Mouse at: {x}, {y}")

            # Convert to world coordinates if needed
            world_pos = engine.screen_to_world(x, y)
            ```
        """
        return self._engine.mouse_position()

    @property
    def mouse_delta(self) -> tuple[float, float]:
        """
        Get the mouse movement delta for this frame in pixels.

        Returns the distance the mouse moved since the last frame.
        Useful for camera controls, drag operations, or cursor-relative input.

        Returns:
            A tuple (delta_x, delta_y) where positive values mean:
            - delta_x > 0: Mouse moved right
            - delta_y > 0: Mouse moved down

        Example:
            ```python
            # Camera look control
            dx, dy = engine.input.mouse_delta
            camera_yaw += dx * sensitivity
            camera_pitch -= dy * sensitivity  # Invert Y for natural feel
            ```
        """
        return self._engine.mouse_delta()

    @property
    def mouse_wheel(self) -> tuple[float, float]:
        """
        Get the mouse wheel scroll delta accumulated this frame.

        Returns scroll amount in both horizontal and vertical directions.
        Most mice only have vertical scroll (Y axis).

        Returns:
            A tuple (scroll_x, scroll_y) where:
            - scroll_y > 0: Scrolled up/away from user
            - scroll_y < 0: Scrolled down/toward user
            - scroll_x: Horizontal scroll (rare, usually 0)

        Example:
            ```python
            # Zoom control
            _, scroll_y = engine.input.mouse_wheel
            camera_zoom += scroll_y * zoom_speed

            # UI scrolling
            if scroll_y != 0:
                scroll_offset += scroll_y * 20  # 20 pixels per scroll tick
            ```
        """
        return self._engine.mouse_wheel()

    def axis(self, name: str) -> float:
        """
        Get the current value of a logical axis (-1.0 to 1.0).

        Axes are useful for smooth, analog-style input from keyboard or gamepad.

        Args:
            name: The axis name (e.g., "horizontal", "vertical").

        Returns:
            A float value from -1.0 to 1.0.

        Example:
            ```python
            # Configure horizontal axis
            engine.input.set_axis_keys("horizontal", ["D", "Right"], ["A", "Left"])

            # Use in update loop
            h_input = engine.input.axis("horizontal")
            player_x += h_input * speed * dt
            ```
        """
        return self._engine.axis(name)

    def axis_previous(self, name: str) -> float:
        """
        Get the previous frame's value of a logical axis.

        Useful for detecting axis changes or calculating input acceleration.

        Args:
            name: The axis name to query.

        Returns:
            The axis value from the previous frame (-1.0 to 1.0).

        Example:
            ```python
            # Detect when axis input changes
            current = engine.input.axis("horizontal")
            previous = engine.input.axis_previous("horizontal")

            if current != 0 and previous == 0:
                print("Started moving horizontally")

            # Calculate input acceleration
            acceleration = current - previous
            ```
        """
        return self._engine.axis_previous(name)

    def axis_names(self) -> list[str]:
        """List all configured logical axis names."""
        return self._engine.axis_names()

    def action_down(self, action_name: str) -> bool:
        """
        Check whether an action is currently active (held down).

        Returns True for every frame while any bound key/button for this action is held.

        Args:
            action_name: The name of the action to check.

        Returns:
            True if any bound key/button is currently pressed, False otherwise.

        Example:
            ```python
            # Bind multiple keys to "fire" action
            engine.input.set_action_keys("fire", ["Space", "LCtrl"])

            # Check if any fire key is held
            if engine.input.action_down("fire"):
                weapon.charge_power += dt * charge_rate
            ```
        """
        return self._engine.action_down(action_name)

    def action_pressed(self, action_name: str) -> bool:
        """
        Check whether an action was pressed this frame.

        Actions group multiple keys/buttons into a single logical action.

        Args:
            action_name: The name of the action to check.

        Returns:
            True if any bound key/button was just pressed this frame.

        Example:
            ```python
            # Bind multiple keys to "jump" action
            engine.input.set_action_keys("jump", ["Space", "W"])

            # Check in game loop
            if engine.input.action_pressed("jump"):
                player.jump()
            ```
        """
        return self._engine.action_pressed(action_name)

    def action_released(self, action_name: str) -> bool:
        """Check whether an action was released this frame."""
        return self._engine.action_released(action_name)

    def action_names(self) -> list[str]:
        """List all configured action names."""
        return self._engine.action_names()

    def reset_bindings_to_defaults(self) -> None:
        """Restore default axis and action bindings."""
        self._engine.reset_input_bindings_to_defaults()

    def set_axis_keys(
        self,
        name: str,
        positive_keys: list[str],
        negative_keys: list[str],
        sensitivity: float = 1.0,
    ) -> None:
        """
        Set keyboard keys for an axis (replaces existing keyboard keys).

        Positive keys move the axis toward +1.0, negative keys toward -1.0.

        Args:
            name: The axis name to configure.
            positive_keys: List of keys that push toward +1.0 (e.g., ["D", "Right"]).
            negative_keys: List of keys that push toward -1.0 (e.g., ["A", "Left"]).
            sensitivity: Multiplier for axis value (default: 1.0).

        Example:
            ```python
            # Set up WASD and arrow key controls
            engine.input.set_axis_keys("horizontal", ["D", "Right"], ["A", "Left"])
            engine.input.set_axis_keys("vertical", ["W", "Up"], ["S", "Down"])

            # Use in game loop
            def update(ctx):
                h = ctx.input.axis("horizontal")
                v = ctx.input.axis("vertical")
                player.move(h, v)
            ```
        """
        self._engine.set_axis_keys(name, positive_keys, negative_keys, sensitivity=sensitivity)

    def add_axis_positive_key(self, axis_name: str, key: str) -> None:
        """Add one positive key to an axis binding."""
        self._engine.add_axis_positive_key(axis_name, key)

    def add_axis_negative_key(self, axis_name: str, key: str) -> None:
        """Add one negative key to an axis binding."""
        self._engine.add_axis_negative_key(axis_name, key)

    def remove_axis_positive_key(self, axis_name: str, key: str) -> bool:
        """Remove one positive key from an axis binding."""
        return self._engine.remove_axis_positive_key(axis_name, key)

    def remove_axis_negative_key(self, axis_name: str, key: str) -> bool:
        """Remove one negative key from an axis binding."""
        return self._engine.remove_axis_negative_key(axis_name, key)

    def remove_axis(self, axis_name: str) -> bool:
        """Remove a logical axis binding."""
        return self._engine.remove_axis(axis_name)

    def set_axis_mouse(
        self,
        name: str,
        mouse_axis: str,
        sensitivity: float = 1.0,
        invert: bool = False,
    ) -> bool:
        """Bind an axis to mouse input (x/y/wheel)."""
        return self._engine.set_axis_mouse(
            name,
            mouse_axis,
            sensitivity=sensitivity,
            invert=invert,
        )

    def set_action_keys(self, action_name: str, keys: list[str]) -> None:
        """Set keyboard bindings for an action (replaces existing keyboard keys)."""
        self._engine.set_action_keys(action_name, keys)

    def add_action_key(self, action_name: str, key: str) -> None:
        """Add one keyboard key to an action binding."""
        self._engine.add_action_key(action_name, key)

    def remove_action_key(self, action_name: str, key: str) -> bool:
        """Remove one keyboard key from an action binding."""
        return self._engine.remove_action_key(action_name, key)

    def set_action_mouse_buttons(self, action_name: str, buttons: list[str]) -> None:
        """Set mouse-button bindings for an action (replaces existing mouse buttons)."""
        self._engine.set_action_mouse_buttons(action_name, buttons)

    def add_action_mouse_button(self, action_name: str, button: MouseButton) -> None:
        """Add one mouse button to an action binding."""
        self._engine.add_action_mouse_button(action_name, button)

    def remove_action_mouse_button(self, action_name: str, button: MouseButton) -> bool:
        """Remove one mouse button from an action binding."""
        return self._engine.remove_action_mouse_button(action_name, button)

    def clear_action_bindings(self, action_name: str) -> None:
        """Clear all bindings (keyboard/mouse/joystick) for an action."""
        self._engine.clear_action_bindings(action_name)


class UpdateContext:
    """
    Mutable frame context passed to function-based engine update callbacks.

    This object is reused each frame to keep callback overhead low.
    It provides access to engine systems, timing information, and user data.

    Attributes:
        engine: The Engine instance for this frame.
        input: The Input manager (alias for engine.input).
        delta_time: Time since last frame in seconds (clamped by max_delta_time).
        elapsed_time: Total time since engine started in seconds.
        frame: Current frame number (starts at 0).
        user_data: Arbitrary user data passed to Engine.run().

    Callback Signature Examples:
        ```python
        # No arguments - callback takes nothing
        def update():
            print("Frame updated")

        # Single argument - receives UpdateContext
        def update(ctx):
            print(f"Frame {ctx.frame}, dt={ctx.delta_time}")

        # Named arguments - auto-injected by name
        def update(dt, engine):
            player.move(dt)
            engine.log("Moved player")

        # All supported argument names:
        def update(ctx, context, engine, input, dt, delta_time,
                   elapsed, elapsed_time, frame, user_data):
            pass  # Use any subset of these names

        # Stopping the loop
        def update(ctx):
            if ctx.input.key_pressed("Escape"):
                ctx.stop()  # Request exit after this frame
        ```

    See Also:
        - `Engine.run()` - Pass update callbacks here
        - `examples/python_function_update_demo.py` - Complete examples
    """

    __slots__ = (
        "engine",
        "input",
        "delta_time",
        "elapsed_time",
        "frame",
        "user_data",
        "_should_stop",
    )

    def __init__(self, engine: "Engine", user_data: Any = None) -> None:
        self.engine = engine
        self.input = engine.input
        self.delta_time = 0.0
        self.elapsed_time = 0.0
        self.frame = 0
        self.user_data = user_data
        self._should_stop = False

    def stop(self) -> None:
        """Request that `Engine.run(update=...)` exits after this frame."""
        self._should_stop = True

    @property
    def should_stop(self) -> bool:
        """Return whether `stop()` has been requested."""
        return self._should_stop


_CallbackInvoker = Callable[[UpdateContext], object]
_CallbackValueProvider = Callable[[UpdateContext], object]

_CALLBACK_VALUE_PROVIDERS: dict[str, _CallbackValueProvider] = {
    "ctx": lambda context: context,
    "context": lambda context: context,
    "engine": lambda context: context.engine,
    "input": lambda context: context.input,
    "dt": lambda context: context.delta_time,
    "delta_time": lambda context: context.delta_time,
    "elapsed": lambda context: context.elapsed_time,
    "elapsed_time": lambda context: context.elapsed_time,
    "frame": lambda context: context.frame,
    "user_data": lambda context: context.user_data,
}

_RUNTIME_STATE_IDLE = "idle"
_RUNTIME_STATE_MANUAL = "manual"
_RUNTIME_STATE_RUNNING_BLOCKING = "running_blocking"
_RUNTIME_STATE_RUNNING_CALLBACK = "running_callback"


def _compile_update_callback(update_callback: Callable[..., object]) -> _CallbackInvoker:
    """
    Compile callback argument injection once for low per-frame overhead.

    This function inspects the callback signature once at startup and generates
    an optimized invoker that provides the requested arguments each frame.
    This avoids reflection overhead on every frame.

    Optimization strategy:
    - Fast path: Positional-only arguments (no dict allocation)
    - Slow path: Keyword-only arguments (requires dict)
    - Special case: Single unknown argument receives full UpdateContext

    Supported callback styles:
    - `def update(): ...`  # No arguments
    - `def update(dt): ...`  # Delta time only
    - `def update(delta_time, engine): ...`  # Multiple named args
    - `def update(context): ...`  # Full context object
    - `def update(any_name): ...`  # Single unknown arg gets UpdateContext
    - `def update(ctx, *, dt): ...`  # Mixed positional and keyword-only

    Supported argument names (case-sensitive):
    - ctx, context: Full UpdateContext object
    - engine: Engine instance
    - input: Input manager
    - dt, delta_time: Frame delta time
    - elapsed, elapsed_time: Total elapsed time
    - frame: Frame number
    - user_data: User-provided data

    Returns:
        A compiled invoker function that takes UpdateContext and calls the callback
        with the appropriate arguments extracted from it.

    Raises:
        TypeError: If callback has unsupported required parameters.
    """
    if not callable(update_callback):
        raise TypeError("update_callback must be callable")

    try:
        signature = inspect.signature(update_callback)
    except (TypeError, ValueError) as exc:
        raise TypeError("Could not inspect update callback signature") from exc

    parameters = list(signature.parameters.values())
    if not parameters:
        return lambda _context: update_callback()

    positional_providers: list[_CallbackValueProvider] = []
    keyword_providers: list[tuple[str, _CallbackValueProvider]] = []
    unknown_required_parameters: list[inspect.Parameter] = []

    for parameter in parameters:
        if parameter.kind is inspect.Parameter.VAR_POSITIONAL:
            continue
        if parameter.kind is inspect.Parameter.VAR_KEYWORD:
            continue

        provider = _CALLBACK_VALUE_PROVIDERS.get(parameter.name)
        if provider is None:
            if parameter.default is inspect.Parameter.empty:
                unknown_required_parameters.append(parameter)
            continue

        if parameter.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            positional_providers.append(provider)
        elif parameter.kind is inspect.Parameter.KEYWORD_ONLY:
            keyword_providers.append((parameter.name, provider))

    if unknown_required_parameters:
        if len(parameters) == 1 and len(unknown_required_parameters) == 1:
            single_unknown = unknown_required_parameters[0]
            if single_unknown.kind is inspect.Parameter.KEYWORD_ONLY:
                unknown_name = single_unknown.name

                def invoke_with_context_alias_kw(context: UpdateContext) -> object:
                    return update_callback(**{unknown_name: context})

                return invoke_with_context_alias_kw

            return lambda context: update_callback(context)

        unsupported_names = ", ".join(
            sorted(parameter.name for parameter in unknown_required_parameters)
        )
        raise TypeError(
            "Unsupported required update callback parameter(s): "
            f"{unsupported_names}. "
            "Supported names: "
            f"{', '.join(sorted(_CALLBACK_VALUE_PROVIDERS))}"
        )

    if not positional_providers and not keyword_providers:
        return lambda _context: update_callback()

    # Fast path: purely positional injection (no kwargs dict allocation per frame).
    if not keyword_providers:
        provider_count = len(positional_providers)
        if provider_count == 1:
            getter_0 = positional_providers[0]
            return lambda context: update_callback(getter_0(context))
        if provider_count == 2:
            getter_0, getter_1 = positional_providers
            return lambda context: update_callback(getter_0(context), getter_1(context))
        if provider_count == 3:
            getter_0, getter_1, getter_2 = positional_providers
            return lambda context: update_callback(
                getter_0(context), getter_1(context), getter_2(context)
            )
        if provider_count == 4:
            getter_0, getter_1, getter_2, getter_3 = positional_providers
            return lambda context: update_callback(
                getter_0(context),
                getter_1(context),
                getter_2(context),
                getter_3(context),
            )

        positional_getters = tuple(positional_providers)

        def invoke_with_positional(context: UpdateContext) -> object:
            return update_callback(*[getter(context) for getter in positional_getters])

        return invoke_with_positional

    # Slow path: keyword-only parameters require kwargs.
    positional_getters = tuple(positional_providers)
    keyword_getters = tuple(keyword_providers)

    def invoke_with_mixed(context: UpdateContext) -> object:
        positional_values = [getter(context) for getter in positional_getters]
        kwargs = {name: getter(context) for name, getter in keyword_getters}
        return update_callback(*positional_values, **kwargs)

    return invoke_with_mixed


class Engine:
    """
    Main game engine class providing core functionality with structured logging.

    This class wraps the Rust implementation and provides a Python-friendly API
    with full access to the tracing-based logging system.

    Attributes:
        version (str): The engine version number.
        input (Input): Input manager for keyboard, mouse, and joystick input.
        ui (UIManager): UI manager for adding buttons, panels, and labels.

    Example:
        Basic usage with console logging:
        ```python
        engine = Engine()
        engine.log_info("Engine started")
        engine.log_warn("Low memory warning")
        engine.log_error("Failed to load resource")
        ```
        With file logging enabled:

        ```python
        engine = Engine(
            enable_file_logging=True,
            log_directory="./logs",
            log_level="DEBUG"
        )
        engine.log_debug("Debug information")
        ```
    """

    def __init__(
        self,
        enable_file_logging: bool = False,
        log_directory: Optional[str] = None,
        log_level: Optional[str] = None,
        source_root: Optional[str] = None,
    ) -> None:
        """
        Initialize a new Engine instance with optional logging configuration.

        Args:
            enable_file_logging: Enable logging to files (default: False).
                Files are rotated daily and stored in the log directory.
            log_directory: Directory path for log files (default: "./logs").
                Only used if enable_file_logging is True.
            log_level: Minimum log level to display. Options:
                - "TRACE": Most verbose, includes all logs
                - "DEBUG": Debug and higher
                - "INFO": Info and higher (default)
                - "WARN": Warnings and errors only
                - "ERROR": Errors only

        Example:
            ```python
            # Console only with INFO level (default)
            engine = Engine()

            # Enable file logging with DEBUG level
            engine = Engine(
                enable_file_logging=True,
                log_directory="./my_logs",
                log_level="DEBUG"
            )
            ```
        """
        self._engine = _RustEngine(
            enable_file_logging=enable_file_logging,
            log_directory=log_directory,
            log_level=log_level,
        )
        detected_source_root = Path(source_root).expanduser() if source_root else _detect_source_root()
        self._engine.set_source_root(str(detected_source_root.resolve()))
        self._input = Input(self)
        self._ui = UIManager(self)
        self._objects = EngineObjects(self)
        self._camera = CameraProxy(self)
        self._runtime_state = _RUNTIME_STATE_IDLE
        self._window_icon_path: Optional[str] = None

    @property
    def input(self) -> Input:
        """
        Get the input manager for the engine.

        Returns:
            Input: The input manager instance.
        """
        return self._input

    @property
    def ui(self) -> UIManager:
        """
        Get the UI manager for the engine.

        Returns:
            UIManager: The UI manager instance for adding UI components.
        """
        return self._ui

    @property
    def objects(self) -> EngineObjects:
        """Get the runtime object lookup facade."""
        return self._objects

    @property
    def camera(self) -> Optional[Any]:
        """Get the active camera proxy."""
        return self._camera

    @property
    def is_running(self) -> bool:
        """Return whether the engine is currently running in any loop mode."""
        return self._runtime_state != _RUNTIME_STATE_IDLE

    def _ensure_not_running(self, entrypoint_name: str) -> None:
        if self._runtime_state != _RUNTIME_STATE_IDLE:
            raise RuntimeError(
                f"Cannot call {entrypoint_name} while engine is already running "
                f"in '{self._runtime_state}' mode."
            )

    def get_handle(self) -> EngineHandle:
        """
        Get a thread-safe handle to the engine for use in background threads or callbacks.

        The handle allows you to safely queue commands from any thread, which will be
        processed on the main engine thread during the next update.

        Returns:
            EngineHandle: A thread-safe handle for queuing engine commands.

        Example:
            ```python
            import threading
            from pyg_engine import Engine, Color

            engine = Engine()
            handle = engine.get_handle()

            def background_task():
                # Safe to call from background thread
                red = Color(1.0, 0.0, 0.0, 1.0)
                handle.draw_circle(400, 300, 50, red)
                handle.log("Drawing from background thread")

            thread = threading.Thread(target=background_task)
            thread.start()

            engine.run()
            ```
        """
        return EngineHandle(self._engine.get_handle())

    def log(self, message: str) -> None:
        """
        Log a message at INFO level (default log method).

        This is an alias for log_info() for backward compatibility.

        Args:
            message: The message to log.
        """
        self._engine.log(message)

    def log_trace(self, message: str) -> None:
        """
        Log a message at TRACE level (most verbose).

        Use for very detailed debugging information.
        Only visible when log level is set to TRACE.

        Args:
            message: The message to log.
        """
        self._engine.log_trace(message)

    def log_debug(self, message: str) -> None:
        """
        Log a message at DEBUG level.

        Use for debugging information that's useful during development.
        Visible when log level is DEBUG or TRACE.

        Args:
            message: The message to log.
        """
        self._engine.log_debug(message)

    def log_info(self, message: str) -> None:
        """
        Log a message at INFO level.

        Use for general informational messages about engine operation.
        This is the default log level.

        Args:
            message: The message to log.
        """
        self._engine.log_info(message)

    def log_warn(self, message: str) -> None:
        """
        Log a message at WARN level.

        Use for warnings that don't prevent operation but indicate
        potential issues.

        Args:
            message: The message to log.
        """
        self._engine.log_warn(message)

    def log_error(self, message: str) -> None:
        """
        Log a message at ERROR level.

        Use for errors that may affect engine operation.

        Args:
            message: The message to log.
        """
        self._engine.log_error(message)

    def set_window_title(self, title: str) -> None:
        """
        Set the window title.

        Args:
            title: The new window title.
        """
        self._engine.set_window_title(title)

    def set_window_icon(self, icon_path: str) -> None:
        """
        Set the window icon from an image file path.

        The path is remembered and will be reused for future `run()` /
        `start_manual()` calls unless overridden per call.
        """
        self._window_icon_path = icon_path
        self._engine.set_window_icon(icon_path)

    def get_display_size(self) -> tuple[int, int]:
        """Get the current display size (window client size) in pixels."""
        return self._engine.get_display_size()

    def start_manual(
        self,
        title: str = "PyG Engine",
        width: int = 1280,
        height: int = 720,
        resizable: bool = True,
        background_color: Optional[Any] = None,
        vsync: bool = True,
        redraw_on_change_only: bool = True,
        show_fps_in_title: bool = False,
        icon_path: Optional[str] = None,
        min_width: Optional[int] = None,
        min_height: Optional[int] = None,
    ) -> None:
        """
        Start the engine in manual-loop mode without entering a blocking loop.

        This mode is for advanced use cases where Python controls the frame loop
        manually using:
        `poll_events()`, `update()`, and `render()`.

        Raises:
            RuntimeError: If the engine is already running in another loop mode.

        Args:
            title: Window title.
            width: Initial window width.
            height: Initial window height.
            resizable: Whether the window can be resized.
            background_color: Optional `pyg_engine.Color`.
            vsync: Enable/disable vertical sync.
            redraw_on_change_only: When True (default), only redraw on scene changes.
            show_fps_in_title: When True, appends current FPS to window title.
            icon_path: Optional icon file path. If omitted, uses the most recent
                `set_window_icon(...)` value when present, otherwise the built-in
                default icon.
            min_width: Minimum window width in pixels (default: 640).
            min_height: Minimum window height in pixels (default: 480).
        """
        self._ensure_not_running("start_manual()")
        resolved_icon_path = (
            icon_path if icon_path is not None else self._window_icon_path
        )
        self._engine.initialize(
            title=title,
            width=width,
            height=height,
            resizable=resizable,
            background_color=background_color,
            vsync=vsync,
            redraw_on_change_only=redraw_on_change_only,
            show_fps_in_title=show_fps_in_title,
            icon_path=resolved_icon_path,
            min_width=min_width,
            min_height=min_height,
        )
        self._runtime_state = _RUNTIME_STATE_MANUAL

    def poll_events(self) -> bool:
        """
        Poll events from the window system.

        Returns:
            bool: True if the loop should continue, False if exit requested.
        """
        should_continue = self._engine.poll_events()
        if not should_continue and self._runtime_state in (
            _RUNTIME_STATE_MANUAL,
            _RUNTIME_STATE_RUNNING_CALLBACK,
        ):
            self._runtime_state = _RUNTIME_STATE_IDLE
        return should_continue

    def update(self) -> None:
        """Run a single update step."""
        self._engine.update()

    def render(self) -> None:
        """Render a single frame."""
        self._engine.render()

    def run(
        self,
        title: str = "PyG Engine",
        width: int = 1280,
        height: int = 720,
        resizable: bool = True,
        background_color: Optional[Any] = None,
        vsync: bool = True,
        redraw_on_change_only: bool = True,
        show_fps_in_title: bool = False,
        icon_path: Optional[str] = None,
        min_width: Optional[int] = None,
        min_height: Optional[int] = None,
        *,
        update: Optional[Callable[..., object]] = None,
        max_delta_time: Optional[float] = 0.1,
        user_data: Any = None,
    ) -> None:
        """
        Run the engine and start the frame loop.

        Default mode (no callback):
        - Enter the native blocking loop until close.

        Callback mode (`update=...`):
        - Start a Python-managed loop and invoke callback once per frame.
        - Callback can return `False` or call `context.stop()` to exit.
        - See `UpdateContext` for injected values.
        - Frame order is: poll events -> native update -> callback -> render.
          (Future GameObject script updates are intended to run in native update.)

        Raises:
            RuntimeError: If the engine is already running in another loop mode.

        Args:
            title: Window title.
            width: Initial window width.
            height: Initial window height.
            resizable: Whether the window can be resized.
            background_color: Optional `pyg_engine.Color`.
            vsync: Enable/disable vertical sync.
            redraw_on_change_only: When True (default), only redraw on scene changes.
            show_fps_in_title: When True, appends current FPS to window title.
            icon_path: Optional icon file path. If omitted, uses the most recent
                `set_window_icon(...)` value when present, otherwise the built-in
                default icon.
            min_width: Minimum window width in pixels (default: 640).
            min_height: Minimum window height in pixels (default: 480).
            update: Optional callback invoked once per frame. When omitted,
                the native blocking run loop is used.
            max_delta_time: Clamp callback `dt` to this value in seconds.
                Only used in callback mode (`update` provided).
            user_data: Arbitrary object exposed via callback context.
                Only used in callback mode (`update` provided).
        """
        self._ensure_not_running("run()")

        if update is None:
            resolved_icon_path = (
                icon_path if icon_path is not None else self._window_icon_path
            )
            self._runtime_state = _RUNTIME_STATE_RUNNING_BLOCKING
            try:
                self._engine.run(
                    title=title,
                    width=width,
                    height=height,
                    resizable=resizable,
                    background_color=background_color,
                    vsync=vsync,
                    redraw_on_change_only=redraw_on_change_only,
                    show_fps_in_title=show_fps_in_title,
                    icon_path=resolved_icon_path,
                    min_width=min_width,
                    min_height=min_height,
                )
            finally:
                self._runtime_state = _RUNTIME_STATE_IDLE
            return

        if max_delta_time is not None and max_delta_time <= 0.0:
            raise ValueError("max_delta_time must be > 0.0 or None")

        invoke_callback = _compile_update_callback(update)

        self.start_manual(
            title=title,
            width=width,
            height=height,
            resizable=resizable,
            background_color=background_color,
            vsync=vsync,
            redraw_on_change_only=redraw_on_change_only,
            show_fps_in_title=show_fps_in_title,
            icon_path=icon_path,
            min_width=min_width,
            min_height=min_height,
        )
        self._runtime_state = _RUNTIME_STATE_RUNNING_CALLBACK

        context = UpdateContext(self, user_data=user_data)

        native_engine = self._engine
        poll_events = native_engine.poll_events
        update_step = native_engine.update
        render_frame = native_engine.render

        try:
            while True:
                if not poll_events():
                    break

                # Update native systems first so callback gets current dt/input.
                update_step()

                context.delta_time = native_engine.delta_time
                if max_delta_time is not None and context.delta_time > max_delta_time:
                    context.delta_time = max_delta_time
                context.elapsed_time = native_engine.elapsed_time

                callback_result = invoke_callback(context)
                if callback_result is False or context._should_stop:
                    break

                render_frame()
                context.frame += 1
        finally:
            self._runtime_state = _RUNTIME_STATE_IDLE

    def add_game_object(self, game_object: Any) -> Optional[int]:
        """
        Add a `pyg_engine.GameObject` to the runtime scene.

        Args:
            game_object: The GameObject instance to add.

        Returns:
            The runtime object ID, or None if add failed.

        Example:
            ```python
            from pyg_engine import GameObject, MeshComponent, Vec3

            # Create a game object with a mesh
            obj = GameObject()
            obj.set_position(Vec3(0, 0, 0))
            mesh = MeshComponent()
            mesh.set_mesh("cube")
            obj.add_component(mesh)

            # Add to scene
            obj_id = engine.add_game_object(obj)
            print(f"Added object with ID: {obj_id}")
            ```
        """
        return self._engine.add_game_object(game_object)

    def create_game_object(self, name: Optional[str] = None) -> Optional[int]:
        """
        Create and add a runtime GameObject.

        Returns:
            The runtime object id, or None if creation failed.
        """
        return self._engine.create_game_object(name)

    def remove_game_object(self, object_id: int) -> None:
        """Remove a runtime GameObject by id."""
        self._engine.remove_game_object(object_id)

    def _resolve_runtime_object_id(self, game_object_or_id: Any) -> int:
        object_id = getattr(game_object_or_id, "id", None)
        if object_id is None:
            object_id = getattr(game_object_or_id, "_object_id", None)
        if object_id is None:
            object_id = game_object_or_id
        return int(object_id)

    def destroy(self, game_object_or_id: Any) -> None:
        """Destroy a runtime object by id or object handle."""
        self.remove_game_object(self._resolve_runtime_object_id(game_object_or_id))

    def set_game_object_position(self, object_id: int, position: Any) -> bool:
        """
        Update a runtime GameObject position by id.

        Returns:
            True if the object exists and was updated, False otherwise.
        """
        return self._engine.set_game_object_position(object_id, position)

    @property
    def camera_object_id(self) -> Optional[int]:
        """Get the runtime id of the active camera GameObject."""
        return self._engine.camera_object_id()

    def get_camera_position(self) -> Any:
        """
        Get the active camera world position.

        Returns:
            A `pyg_engine.Vec2` or `pyg_engine.Vec3` representing the camera position in world space.

        Example:
            ```python
            cam_pos = engine.get_camera_position()
            print(f"Camera at: {cam_pos.x}, {cam_pos.y}")
            ```
        """
        return self._engine.get_camera_position()

    def set_camera_position(self, position: Any) -> bool:
        """
        Set the active camera world position.

        Legacy helper. Prefer `engine.camera.position = ...` in new code.

        Args:
            position: A `pyg_engine.Vec2` or `pyg_engine.Vec3` in world space.

        Returns:
            True if successful, False otherwise.

        Example:
            ```python
            from pyg_engine import Vec2

            # Follow player position
            player_pos = Vec2(player_x, player_y)
            engine.set_camera_position(player_pos)
            ```
        """
        return self._engine.set_camera_position(position)

    def get_camera_viewport_size(self) -> tuple[float, float]:
        """
        Get the active camera viewport size in world units.

        Returns:
            A tuple (width, height) in world units.

        Example:
            ```python
            width, height = engine.get_camera_viewport_size()
            print(f"Viewing {width}x{height} world units")
            ```
        """
        return self._engine.get_camera_viewport_size()

    def set_camera_viewport_size(self, width: float, height: float) -> bool:
        """
        Set the active camera viewport size in world units.

        Legacy helper. Prefer `engine.camera.viewport_size = ...` in new code.

        The viewport size determines how many world units are visible on screen.
        Smaller values = more zoomed in, larger values = more zoomed out.

        Args:
            width: Viewport width in world units.
            height: Viewport height in world units.

        Returns:
            True if successful, False otherwise.

        Example:
            ```python
            # Show 20x15 world units (zoomed in)
            engine.set_camera_viewport_size(20.0, 15.0)

            # Show 100x75 world units (zoomed out)
            engine.set_camera_viewport_size(100.0, 75.0)
            ```
        """
        return self._engine.set_camera_viewport_size(width, height)

    def get_camera_aspect_mode(self) -> str:
        """
        Get the camera aspect handling mode.

        Returns:
            The current aspect mode string ("stretch", "match_horizontal", etc.).

        Example:
            ```python
            mode = engine.get_camera_aspect_mode()
            print(f"Aspect mode: {mode}")
            ```
        """
        return self._engine.get_camera_aspect_mode()

    def set_camera_aspect_mode(self, mode: str) -> bool:
        """
        Set the camera aspect handling mode.

        Legacy helper. Prefer `engine.camera.aspect_mode = ...` in new code.

        Controls how the viewport adapts when the window is resized.

        Args:
            mode: Aspect mode string. Options:
                - **"stretch"**: Stretch viewport to fill window (may distort)
                - **"match_horizontal"**: Keep horizontal view constant, adjust vertical
                - **"match_vertical"**: Keep vertical view constant, adjust horizontal
                - **"fit_both"**: Fit entire viewport with letterboxing/pillarboxing
                - **"fill_both"**: Fill window completely, may crop viewport edges

        Returns:
            True if successful, False if mode is invalid.

        Example:
            ```python
            # Keep consistent horizontal field of view (common for platformers)
            engine.set_camera_aspect_mode("match_horizontal")

            # Keep consistent vertical field of view (common for top-down)
            engine.set_camera_aspect_mode("match_vertical")

            # Prevent distortion with letterboxing
            engine.set_camera_aspect_mode("fit_both")
            ```
        """
        return self._engine.set_camera_aspect_mode(mode)

    def set_camera_background_color(self, color: Any) -> None:
        """Set the active camera background clear color.

        Legacy helper. Prefer `engine.camera.background_color = ...` in new code.
        """
        self._engine.set_camera_background_color(color)

    def get_camera_background_color(self) -> Any:
        """Get the active camera background clear color."""
        return self._engine.get_camera_background_color()

    def world_to_screen(self, world_position: Any) -> tuple[float, float]:
        """
        Convert world-space coordinates to screen-space pixel coordinates.

        Args:
            world_position: A `pyg_engine.Vec3` or `pyg_engine.Vec2` in world space.

        Returns:
            A tuple (x, y) with pixel coordinates in screen space.

        Example:
            ```python
            from pyg_engine import Vec3

            # Get screen position of a world object
            world_pos = Vec3(10.0, 5.0, 0.0)
            screen_x, screen_y = engine.world_to_screen(world_pos)

            # Draw UI element at that position
            engine.draw_text(f"Object here!", screen_x, screen_y, color)
            ```
        """
        return self._engine.world_to_screen(world_position)

    def screen_to_world(self, screen_x: float, screen_y: float) -> Any:
        """
        Convert screen-space pixel coordinates to world-space coordinates.

        Args:
            screen_x: X coordinate in pixels (0 = left edge).
            screen_y: Y coordinate in pixels (0 = top edge).

        Returns:
            A `pyg_engine.Vec3` in world space.

        Example:
            ```python
            # Spawn object at mouse position in world space
            mouse_x, mouse_y = engine.input.mouse_position
            world_pos = engine.screen_to_world(mouse_x, mouse_y)

            obj = GameObject()
            obj.set_position(world_pos)
            engine.add_game_object(obj)
            ```
        """
        return self._engine.screen_to_world(screen_x, screen_y)

    def clear_draw_commands(self) -> None:
        """Clear all immediate-mode drawing commands."""
        self._engine.clear_draw_commands()

    def add_draw_commands(self, commands: list[Any]) -> None:
        """Submit many draw shapes or draw commands in one call."""
        self._engine.add_draw_commands(to_draw_commands(commands))

    def draw(self, drawable: Any) -> None:
        """
        Draw one shape or a batch of shapes.

        Examples:
            ```python
            engine.draw(Circle(position=Vec2(200, 200), radius=40, color=Color.RED))
            engine.draw([
                Rect(position=Vec2(20, 20), width=120, height=60, color=Color.BLUE),
                Line(start=Vec2(0, 0), end=Vec2(100, 100), color=Color.WHITE),
            ])
            ```
        """
        self._engine.add_draw_commands(to_draw_commands(drawable))

    def draw_pixel(
        self,
        x: int,
        y: int,
        color: Any,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a single pixel in window coordinates.

        Args:
            x: X coordinate in pixels (0 = left edge).
            y: Y coordinate in pixels (0 = top edge).
            color: A `pyg_engine.Color` instance.
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            white = Color.WHITE
            engine.draw_pixel(100, 100, white, draw_order=5.0)
            ```
        """
        self._engine.draw_pixel(x, y, color, draw_order=draw_order)

    def draw_line(
        self,
        start_x: float,
        start_y: float,
        end_x: float,
        end_y: float,
        color: Any,
        thickness: float = 1.0,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a line in window coordinates.

        Args:
            start_x: Starting X coordinate in pixels.
            start_y: Starting Y coordinate in pixels.
            end_x: Ending X coordinate in pixels.
            end_y: Ending Y coordinate in pixels.
            color: A `pyg_engine.Color` instance.
            thickness: Line width in pixels (default: 1.0).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            white = Color.WHITE
            # Draw diagonal line
            engine.draw_line(0, 0, 800, 600, white, thickness=2.0)
            ```
        """
        self._engine.draw_line(
            start_x,
            start_y,
            end_x,
            end_y,
            color,
            thickness=thickness,
            draw_order=draw_order,
        )

    def draw_rectangle(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        color: Any,
        filled: bool = True,
        thickness: float = 1.0,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a rectangle in window coordinates.

        Args:
            x: Top-left X coordinate in pixels.
            y: Top-left Y coordinate in pixels.
            width: Rectangle width in pixels.
            height: Rectangle height in pixels.
            color: A `pyg_engine.Color` instance.
            filled: If True, draws filled; if False, draws outline (default: True).
            thickness: Border thickness when filled=False (default: 1.0).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            blue = Color.BLUE
            # Filled rectangle
            engine.draw_rectangle(100, 100, 200, 150, blue)

            # Outline only
            engine.draw_rectangle(350, 100, 200, 150, blue, filled=False, thickness=3.0)
            ```
        """
        self._engine.draw_rectangle(
            x,
            y,
            width,
            height,
            color,
            filled=filled,
            thickness=thickness,
            draw_order=draw_order,
        )

    def draw_circle(
        self,
        center_x: float,
        center_y: float,
        radius: float,
        color: Any,
        filled: bool = True,
        thickness: float = 1.0,
        segments: int = 32,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a circle in window coordinates.

        Args:
            center_x: Center X coordinate in pixels.
            center_y: Center Y coordinate in pixels.
            radius: Circle radius in pixels.
            color: A `pyg_engine.Color` instance.
            filled: If True, draws filled; if False, draws outline (default: True).
            thickness: Border thickness when filled=False (default: 1.0).
            segments: Number of line segments for smoothness (default: 32).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            green = Color.GREEN
            # Filled circle
            engine.draw_circle(400, 300, 50, green)

            # Smooth outline with more segments
            engine.draw_circle(500, 300, 50, green, filled=False, thickness=2.0, segments=64)
            ```
        """
        self._engine.draw_circle(
            center_x,
            center_y,
            radius,
            color,
            filled=filled,
            thickness=thickness,
            segments=segments,
            draw_order=draw_order,
        )

    def draw_gradient_rect(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        top_left: Any,
        bottom_left: Any,
        bottom_right: Any,
        top_right: Any,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw a gradient rectangle with per-corner colors.

        Args:
            x: Top-left X coordinate in pixels.
            y: Top-left Y coordinate in pixels.
            width: Rectangle width in pixels.
            height: Rectangle height in pixels.
            top_left: `pyg_engine.Color` for top-left corner.
            bottom_left: `pyg_engine.Color` for bottom-left corner.
            bottom_right: `pyg_engine.Color` for bottom-right corner.
            top_right: `pyg_engine.Color` for top-right corner.
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            from pyg_engine import Color

            red = Color.RED
            blue = Color.BLUE
            green = Color.GREEN
            yellow = Color.YELLOW

            # Gradient with different colors at each corner
            engine.draw_gradient_rect(100, 100, 300, 200, red, blue, green, yellow)
            ```
        """
        self._engine.draw_gradient_rect(
            x,
            y,
            width,
            height,
            top_left,
            bottom_left,
            bottom_right,
            top_right,
            draw_order=draw_order,
        )

    def draw_image(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        texture_path: str,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw an image from a file path.

        The image is cached internally, so repeated calls are efficient.

        Args:
            x: Top-left X coordinate in pixels.
            y: Top-left Y coordinate in pixels.
            width: Display width in pixels.
            height: Display height in pixels.
            texture_path: File path to image (PNG, JPG, etc.).
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            # Draw sprite
            engine.draw_image(100, 100, 64, 64, "assets/player.png")

            # Draw background
            engine.draw_image(0, 0, 1280, 720, "assets/bg.jpg", draw_order=-1.0)
            ```
        """
        self._engine.draw_image(
            x,
            y,
            width,
            height,
            texture_path,
            draw_order=draw_order,
        )

    def draw_image_from_bytes(
        self,
        x: float,
        y: float,
        width: float,
        height: float,
        texture_key: str,
        rgba: bytes,
        texture_width: int,
        texture_height: int,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw an image from raw RGBA bytes.

        Useful for procedurally generated textures or in-memory image data.

        Args:
            x: Top-left X coordinate in pixels.
            y: Top-left Y coordinate in pixels.
            width: Display width in pixels.
            height: Display height in pixels.
            texture_key: Unique identifier for caching this texture.
            rgba: Raw RGBA bytes (4 bytes per pixel: R, G, B, A).
            texture_width: Width of source texture in pixels.
            texture_height: Height of source texture in pixels.
            draw_order: Rendering order (higher values drawn on top).

        Example:
            ```python
            # Create 2x2 checkerboard pattern
            width, height = 2, 2
            pixels = bytes([
                255, 0, 0, 255,    # Red
                0, 255, 0, 255,    # Green
                0, 0, 255, 255,    # Blue
                255, 255, 0, 255   # Yellow
            ])

            # Draw scaled up to 100x100
            engine.draw_image_from_bytes(100, 100, 100, 100, "checkerboard", pixels, width, height)
            ```
        """
        self._engine.draw_image_from_bytes(
            x,
            y,
            width,
            height,
            texture_key,
            rgba,
            texture_width,
            texture_height,
            draw_order=draw_order,
        )

    def draw_text(
        self,
        text: str,
        x: float,
        y: float,
        color: Any,
        font_size: float = 24.0,
        font_path: Optional[str] = None,
        font_family: Optional[str] = None,
        font_weight: Optional[str] = None,
        font_style: Optional[str] = None,
        letter_spacing: float = 0.0,
        line_spacing: float = 0.0,
        kerning: bool = True,
        draw_order: float = 0.0,
    ) -> None:
        """
        Draw text in window coordinates.

        By default, this uses the engine's built-in open-source font.
        Provide `font_path` to use a custom TTF/OTF font file.

        Legacy helper. Prefer `engine.draw(Text(...))` in new code.
        """
        self._engine.draw_text(
            text,
            x,
            y,
            color,
            font_size=font_size,
            font_path=font_path,
            font_family=font_family,
            font_weight=font_weight,
            font_style=font_style,
            letter_spacing=letter_spacing,
            line_spacing=line_spacing,
            kerning=kerning,
            draw_order=draw_order,
        )

    def register_font_family(
        self,
        family: str,
        *,
        regular: Optional[str] = None,
        bold: Optional[str] = None,
        italic: Optional[str] = None,
        bold_italic: Optional[str] = None,
    ) -> None:
        """Register a reusable font family for text rendering and UI."""
        self._engine.register_font_family(
            family,
            regular=regular,
            bold=bold,
            italic=italic,
            bold_italic=bold_italic,
        )

    def measure_text(
        self,
        text: str,
        *,
        font_size: float = 24.0,
        font_path: Optional[str] = None,
        font_family: Optional[str] = None,
        font_weight: Optional[str] = None,
        font_style: Optional[str] = None,
        letter_spacing: float = 0.0,
        line_spacing: float = 0.0,
        kerning: bool = True,
    ) -> tuple[float, float]:
        """Measure text width and height using the current font system."""
        return self._engine.measure_text(
            text,
            font_size=font_size,
            font_path=font_path,
            font_family=font_family,
            font_weight=font_weight,
            font_style=font_style,
            letter_spacing=letter_spacing,
            line_spacing=line_spacing,
            kerning=kerning,
        )

    def update_ui_label_text(self, object_id: int, text: str) -> None:
        """
        Update a UI label's text at runtime by object ID.

        Args:
            object_id: The GameObject ID of the label to update.
            text: The new text for the label.
        """
        self._engine.update_ui_label_text(object_id, text)

    def update_ui_button_text(self, object_id: int, text: str) -> None:
        """
        Update a UI button's text at runtime by object ID.

        Args:
            object_id: The GameObject ID of the button to update.
            text: The new text for the button.
        """
        self._engine.update_ui_button_text(object_id, text)

    @property
    def version(self) -> str:
        """
        Get the engine version.

        Returns:
            The version string (e.g., "1.3.0").
        """
        return self._engine.version

    @property
    def delta_time(self) -> float:
        """Get the time since the last frame in seconds."""
        return self._engine.delta_time

    @property
    def elapsed_time(self) -> float:
        """Get the total elapsed time in seconds since the engine started."""
        return self._engine.elapsed_time
