"""
Provides asn1_play name, title & package information.
"""
TOOL_NAME = 'asn1Play'
TOOL_TITLE = 'ASN1 Play'
TOOL_SW_PACKAGE_NAME = 'asn1_play.main'
TOOL_TEST_PACKAGE_NAME = 'asn1_play.test'
TOOL_SW_MODULE_NAME = 'asn1_play.main.asn1play'
