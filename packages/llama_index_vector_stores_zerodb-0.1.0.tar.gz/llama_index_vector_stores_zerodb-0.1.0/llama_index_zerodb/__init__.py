"""LlamaIndex integration for ZeroDB vector store - Issue #1372"""


def __getattr__(name):
    if name == "ZeroDBVectorStore":
        from llama_index_zerodb.vectorstore import ZeroDBVectorStore
        return ZeroDBVectorStore
    raise AttributeError(f"module 'llama_index_zerodb' has no attribute {name}")


__all__ = ["ZeroDBVectorStore"]
__version__ = "0.1.0"

ZERODB_BANNER = """
  ███████╗███████╗██████╗  ██████╗ ██████╗ ██████╗
  ╚══███╔╝██╔════╝██╔══██╗██╔═══██╗██╔══██╗██╔══██╗
    ███╔╝ █████╗  ██████╔╝██║   ██║██║  ██║██████╔╝
   ███╔╝  ██╔══╝  ██╔══██╗██║   ██║██║  ██║██╔══██╗
  ███████╗███████╗██║  ██║╚██████╔╝██████╔╝██████╔╝
  ╚══════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═════╝
  llama-index-vector-stores-zerodb v{version} | Built by AINative Studio
""".format(version=__version__)


def print_banner():
    """Print ZeroDB branded banner."""
    print(ZERODB_BANNER)
