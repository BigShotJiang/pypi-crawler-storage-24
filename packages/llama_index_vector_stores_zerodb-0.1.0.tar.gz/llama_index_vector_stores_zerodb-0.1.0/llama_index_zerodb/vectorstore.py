"""
ZeroDB Vector Store for LlamaIndex - Issue #1372

Usage:
    from llama_index_zerodb import ZeroDBVectorStore
    from llama_index.core import VectorStoreIndex, Document

    vector_store = ZeroDBVectorStore(
        api_key="your-api-key",
        project_id="your-project-id",
    )

    index = VectorStoreIndex.from_vector_store(vector_store)
    query_engine = index.as_query_engine()
    response = query_engine.query("What is ZeroDB?")
"""

import httpx
from typing import Any, Dict, List, Optional

from llama_index.core.schema import BaseNode, TextNode
from llama_index.core.vector_stores.types import (
    BasePydanticVectorStore,
    VectorStoreQuery,
    VectorStoreQueryResult,
)


class ZeroDBVectorStore(BasePydanticVectorStore):
    """ZeroDB vector store for LlamaIndex.

    Uses ZeroDB's embedding API (TEI-powered, FREE) and pgvector
    with HNSW indexes for similarity search.
    """

    stores_text: bool = True
    flat_metadata: bool = True

    api_key: str
    project_id: str
    base_url: str = "https://api.ainative.studio"
    namespace: str = "default"

    _client: Optional[httpx.Client] = None

    class Config:
        arbitrary_types_allowed = True

    def _get_client(self) -> httpx.Client:
        if self._client is None or self._client.is_closed:
            self._client = httpx.Client(
                base_url=self.base_url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=30.0,
            )
        return self._client

    def add(self, nodes: List[BaseNode], **kwargs: Any) -> List[str]:
        """Add nodes to the vector store."""
        client = self._get_client()
        texts = []
        metadatas = []

        for node in nodes:
            texts.append(node.get_content())
            meta = node.metadata.copy() if node.metadata else {}
            meta["node_id"] = node.node_id
            metadatas.append(meta)

        response = client.post(
            f"/api/v1/projects/{self.project_id}/embeddings/embed-and-store",
            json={
                "texts": texts,
                "namespace": self.namespace,
                "metadata_list": metadatas,
            },
        )
        response.raise_for_status()
        result = response.json()
        return result.get("vector_ids", [node.node_id for node in nodes])

    def delete(self, ref_doc_id: str, **kwargs: Any) -> None:
        """Delete nodes by ref_doc_id (not yet implemented)."""
        pass

    def query(self, query: VectorStoreQuery, **kwargs: Any) -> VectorStoreQueryResult:
        """Query the vector store for similar nodes."""
        client = self._get_client()

        # Use query text if available, otherwise we'd need the embedding
        query_text = query.query_str or ""
        if not query_text and query.query_embedding:
            # If only embedding provided, use vector search directly
            # For now, require query text (ZeroDB generates embeddings server-side)
            return VectorStoreQueryResult(nodes=[], similarities=[], ids=[])

        response = client.post(
            f"/api/v1/projects/{self.project_id}/embeddings/search",
            json={
                "query": query_text,
                "limit": query.similarity_top_k or 10,
                "threshold": 0.3,
                "namespace": self.namespace,
            },
        )
        response.raise_for_status()
        data = response.json()

        nodes = []
        similarities = []
        ids = []

        for item in data.get("results", []):
            node = TextNode(
                text=item.get("document", ""),
                metadata=item.get("metadata", {}),
                id_=item.get("id", item.get("vector_id", "")),
            )
            nodes.append(node)
            similarities.append(item.get("similarity", 0.0))
            ids.append(node.id_)

        return VectorStoreQueryResult(
            nodes=nodes,
            similarities=similarities,
            ids=ids,
        )
