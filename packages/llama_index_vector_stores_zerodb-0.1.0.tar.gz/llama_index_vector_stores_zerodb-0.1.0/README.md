# llama-index-vector-stores-zerodb

ZeroDB vector store integration for [LlamaIndex](https://www.llamaindex.ai/) - the AI-native vector database with **free embeddings** and sub-millisecond semantic search.

## Why ZeroDB?

- **Free embeddings** - BAAI/bge-small-en-v1.5 (384-dim) powered by TEI, no OpenAI costs
- **Sub-millisecond search** - pgvector with HNSW indexes
- **Zero infrastructure** - fully managed, no servers to run
- **Instant provisioning** - `POST /api/v1/instant-db` gets you a database in one request
- **Built for agents** - MCP server, memory API, event streams

## Installation

```bash
pip install llama-index-vector-stores-zerodb
```

## Quick Start

```python
from llama_index_zerodb import ZeroDBVectorStore
from llama_index.core import VectorStoreIndex, Document

# Initialize (get your API key at ainative.studio)
vector_store = ZeroDBVectorStore(
    api_key="your-api-key",
    project_id="your-project-id",
)

# Build index from documents
documents = [
    Document(text="ZeroDB is an AI-native vector database"),
    Document(text="Semantic search finds meaning, not keywords"),
]
index = VectorStoreIndex.from_documents(documents, vector_store=vector_store)

# Query
query_engine = index.as_query_engine()
response = query_engine.query("What is ZeroDB?")
print(response)
```

## Use as a Standalone Vector Store

```python
from llama_index_zerodb import ZeroDBVectorStore
from llama_index.core import VectorStoreIndex

# Connect to existing vectors
vector_store = ZeroDBVectorStore(
    api_key="your-api-key",
    project_id="your-project-id",
)

# Build index from existing store
index = VectorStoreIndex.from_vector_store(vector_store)

# Query
retriever = index.as_retriever(similarity_top_k=5)
results = retriever.retrieve("semantic search performance")
for node in results:
    print(f"{node.score:.3f}: {node.text[:100]}")
```

## Get a Free API Key

1. Sign up at [ainative.studio](https://www.ainative.studio/signup)
2. Create a ZeroDB project
3. Copy your API key

Or get an instant database with no signup:
```bash
curl -X POST https://api.ainative.studio/api/v1/public/instant-db
```

## Links

- [ZeroDB Product Page](https://www.ainative.studio/products/zerodb)
- [API Documentation](https://docs.ainative.studio)
- [GitHub](https://github.com/AINative-Studio)
- [Discord](https://discord.gg/paipalooza)
- [LangChain Integration](https://pypi.org/project/langchain-zerodb/)

## License

MIT - Built by [AINative Studio](https://www.ainative.studio)
