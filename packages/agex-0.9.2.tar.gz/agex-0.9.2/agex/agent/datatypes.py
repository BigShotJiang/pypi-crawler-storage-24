from dataclasses import dataclass, field
from types import ModuleType
from typing import Any, Callable, Iterable, Literal, Union

Pattern = Union[str, Iterable[str], Callable[[str], bool]]
Visibility = Literal["high", "medium", "low"]
RESERVED_NAMES = {"dataclass", "dataclasses"}


class _AgentExit(BaseException):
    """Base class for agent exit signals.

    Inherits from BaseException (not Exception) so that agent code using
    ``except Exception`` cannot catch these signals. sandtrap's sandbox
    excludes BaseException from the namespace, making these uncatchable.
    """

    pass


# Task control classes for improved iterative workflow
@dataclass
class TaskSuccess(_AgentExit):
    """Signal that the agent has completed its task successfully."""

    result: Any = None


@dataclass
class TaskFail(_AgentExit):
    """Signal that the agent has failed and cannot complete its task."""

    message: str


@dataclass
class TaskClarify(_AgentExit):
    """Signal that the agent needs more information to complete its task."""

    message: str


@dataclass
class TaskContinue(_AgentExit):
    """Signal that the agent wants to continue to the next iteration."""

    observations: tuple[Any, ...] = field(default_factory=tuple)


@dataclass
class TaskTimeout(_AgentExit):
    """Signal that task could not be completed within limits."""

    message: str


@dataclass
class TaskCancelled(_AgentExit):
    """Signal that task was cancelled via external request."""

    message: str
    task_name: str
    iterations_completed: int = 0


@dataclass
class LLMFail(_AgentExit):
    """Uncatchable signal that the LLM call failed (after retries)."""

    message: str
    provider: str | None = None
    model: str | None = None
    retries: int = 0


@dataclass
class FileAction:
    """Represents a file operation (write or append) requested by an agent."""

    path: str
    content: str
    mode: Literal["write", "append"] = "write"


@dataclass
class EditAction:
    """Represents a search/replace or insert edit operation requested by an agent.

    The `operation` attribute controls how the edit is applied:
    - "replace": Replace the search text entirely with the content
    - "insert-after": Keep the search text and insert content after it
    - "insert-before": Insert content before the search text, keeping the original
    """

    path: str
    search: str
    content: str
    operation: Literal["replace", "insert-after", "insert-before"] = "replace"
    match_all: bool = False


class UnpicklableVariableError(Exception):
    """Raised when attempting to access a variable that was not persisted due to being unpicklable."""

    pass


@dataclass
class UnpicklableMarker:
    """Marker for variables that couldn't be persisted due to being unpicklable.

    This marker is stored in place of the actual unpicklable object. When an agent
    tries to access this variable in a future turn, we raise an informative error.
    """

    variable_name: str
    type_name: str
    original_exception: str


@dataclass
class MemberSpec:
    visibility: Visibility | None = None
    docstring: str | None = None
    constructable: bool | None = None
    host_fs_access: bool = False
    network_access: bool = False


@dataclass
class RegisteredItem:
    visibility: Visibility


@dataclass
class RegisteredFn(RegisteredItem):
    fn: Callable
    docstring: str | None


@dataclass
class RegisteredClass(RegisteredItem):
    """Represents a registered class and its members."""

    cls: type
    constructable: bool
    # 'visibility' on RegisteredItem is the default.
    attrs: dict[str, MemberSpec] = field(default_factory=dict)
    methods: dict[str, MemberSpec] = field(default_factory=dict)


@dataclass
class RegisteredModule(RegisteredItem):
    """Represents a registered module with its selected members."""

    name: str  # The name the agent will use to import it
    module: ModuleType
    fns: dict[str, MemberSpec] = field(default_factory=dict)
    consts: dict[str, MemberSpec] = field(default_factory=dict)
    classes: dict[str, RegisteredClass] = field(default_factory=dict)


@dataclass
class RegisteredObject(RegisteredItem):
    """Represents a live Python object registered with the agent."""

    # The mandatory, agent-facing namespace (e.g., 'db').
    # This is also used as the key in the host-side registry.
    name: str

    # A dictionary of exposed methods, reusing MemberSpec for consistency.
    methods: dict[str, MemberSpec] = field(default_factory=dict)

    # A dictionary for exposed read-only attributes/properties.
    properties: dict[str, MemberSpec] = field(default_factory=dict)
