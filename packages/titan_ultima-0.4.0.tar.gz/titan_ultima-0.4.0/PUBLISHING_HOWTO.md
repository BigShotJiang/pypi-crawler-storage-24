# Publishing titan-ultima

How to make `titan-ultima` installable from **PyPI** (`pip install`),
**Debian/Ubuntu** (`apt install`), **Homebrew**, **Conda**, and other
distribution channels.

> **Current state:** the package builds as a wheel + sdist in CI and is
> attached to GitHub Releases under `titan/v*` tags.  Nothing below has
> been submitted yet — all steps are ready for first-time setup.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [PyPI — `pip install titan-ultima`](#2-pypi--pip-install-titan-ultima)
3. [TestPyPI — dry-run before real PyPI](#3-testpypi--dry-run-before-real-pypi)
4. [Automated PyPI publishing via GitHub Actions](#4-automated-pypi-publishing-via-github-actions)
5. [Conda / conda-forge](#5-conda--conda-forge)
6. [Homebrew](#6-homebrew)
7. [Debian / Ubuntu — `apt install`](#7-debian--ubuntu--apt-install)
8. [Arch Linux (AUR)](#8-arch-linux-aur)
9. [Docker](#9-docker)
10. [Version bump checklist](#10-version-bump-checklist)

---

## 1. Prerequisites

You already have everything needed:

| Item | Status |
|------|--------|
| `pyproject.toml` with hatchling build system | ✅ |
| `src/` layout, `py.typed` marker | ✅ |
| MIT `LICENSE` | ✅ |
| `README.md` (PyPI long description) | ✅ |
| `CHANGELOG.md` | ✅ |
| CI builds wheel + sdist on every push | ✅ |
| GitHub Releases with `titan/v*` tags | ✅ |

Install the local tools you'll need:

```powershell
pip install build twine
```

---

## 2. PyPI — `pip install titan-ultima`

This is the primary distribution channel. Once on PyPI, anyone can run
`pip install titan-ultima`.

### 2a. Create a PyPI account and API token

1. Register at <https://pypi.org/account/register/>
2. Enable 2FA (required for new accounts).
3. Go to **Account Settings → API tokens → Add API token**.
4. Scope: **Entire account** (first upload) — you can scope it to the
   project afterwards.
5. Copy the token (starts with `pypi-`). You will paste it once.

### 2b. Build locally

```powershell
cd C:\_Repos\tgwUltima\titan-ultima

python -m build          # creates dist/titan_ultima-X.Y.Z-py3-none-any.whl
                         #         dist/titan_ultima-X.Y.Z.tar.gz

twine check dist/*       # validates metadata + README rendering
```

### 2c. Upload

```powershell
twine upload dist/*
# Username: __token__
# Password: <paste your pypi- token>
```

After this, `pip install titan-ultima` works worldwide. The CLI
entry point `titan` is installed automatically.

### 2d. Verify

```powershell
pip install titan-ultima   # from a fresh venv ideally
titan --version
titan --help
```

---

## 3. TestPyPI — dry-run before real PyPI

Use TestPyPI to verify everything renders correctly without burning a
version number on the real index.

1. Register separately at <https://test.pypi.org/account/register/>
2. Create a TestPyPI API token the same way as above.

```powershell
# Upload to test.pypi.org
twine upload --repository testpypi dist/*
# Username: __token__
# Password: <paste your TestPyPI token>

# Install from TestPyPI (fall back to real PyPI for deps)
pip install --index-url https://test.pypi.org/simple/ \
            --extra-index-url https://pypi.org/simple/ \
            titan-ultima
```

Check the rendered page at
`https://test.pypi.org/project/titan-ultima/`.

---

## 4. Automated PyPI publishing via GitHub Actions

Instead of manually using `twine`, you can have GitHub push to PyPI
automatically whenever a `titan/v*` release is published. This uses
PyPI **Trusted Publishers** (OpenID Connect) — no stored tokens needed.

### 4a. Register the publisher on PyPI

> You must have uploaded at least once manually (step 2) so the project
> exists on PyPI, **or** you can use PyPI's "pending publisher" feature
> to pre-register before the first upload.

1. Go to <https://pypi.org/manage/project/titan-ultima/settings/publishing/>
   (or for a pending publisher: <https://pypi.org/manage/account/publishing/>)
2. Add a new publisher:
   - **Owner:** `theGreyWanderer-uc`
   - **Repository:** `tgwUltima`
   - **Workflow name:** `build-release.yml`
   - **Environment:** `pypi`

### 4b. Create the GitHub environment

1. Go to <https://github.com/theGreyWanderer-uc/tgwUltima/settings/environments>
2. Create an environment named **`pypi`**.
3. Optionally add a "Required reviewers" protection rule so publishes
   need manual approval.

### 4c. Add the publish step to the existing workflow

Add this to the **`release-titan`** job in `build-release.yml`, after
the existing release step:

```yaml
  release-titan:
    name: Release Titan-Ultima
    needs: [build-titan]
    if: startsWith(github.ref, 'refs/tags/titan/v')
    runs-on: ubuntu-latest
    environment: pypi                          # <-- add this
    permissions:
      contents: write
      id-token: write                          # <-- add this
    steps:
      - uses: actions/checkout@v6

      - name: Download artifact
        uses: actions/download-artifact@v7
        with:
          name: titan-ultima-dist
          path: release-assets

      - name: Create GitHub release
        uses: softprops/action-gh-release@v2
        with:
          name: "Titan-Ultima ${{ github.ref_name }}"
          body_path: titan-ultima/CHANGELOG.md
          files: release-assets/*

      # ── NEW: publish to PyPI via Trusted Publishers ──
      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          packages-dir: release-assets/
```

Now every `titan/v*` tag push creates the GitHub Release **and**
publishes to PyPI in one workflow run, with no stored secrets.

---

## 5. Conda / conda-forge

conda-forge is the community channel for Conda packages. Getting on
conda-forge means `conda install -c conda-forge titan-ultima` works on
Windows, macOS, and Linux.

### 5a. Prerequisite

The package **must already be on PyPI** (step 2).

### 5b. Submit a recipe

1. Fork <https://github.com/conda-forge/staged-recipes>
2. Create `recipes/titan-ultima/meta.yaml`:

   ```yaml
   {% set name = "titan-ultima" %}
   {% set version = "0.4.0" %}

   package:
     name: {{ name }}
     version: {{ version }}

   source:
     url: https://pypi.org/packages/source/t/{{ name }}/titan_ultima-{{ version }}.tar.gz
     sha256: <sha256 of the sdist from PyPI>

   build:
     noarch: python
     number: 0
     entry_points:
       - titan = titan.cli:main
     script: {{ PYTHON }} -m pip install . -vv --no-deps --no-build-isolation

   requirements:
     host:
       - python >=3.9
       - pip
       - hatchling
     run:
       - python >=3.9
       - numpy >=1.24
       - pillow >=10.0
       - typer >=0.15
       - tomli >=2.0  # [py<311]

   test:
     imports:
       - titan
     commands:
       - titan --version
       - titan --help

   about:
     home: https://github.com/theGreyWanderer-uc/tgwUltima
     license: MIT
     license_file: LICENSE
     summary: CLI and library for Ultima 8 Pagan file formats
   ```

3. Open a PR to `conda-forge/staged-recipes`. Conda-forge bots review,
   build, and merge it. After that the package auto-updates via a
   feedstock repo whenever you push a new PyPI version.

Get the sha256 for the recipe:

```powershell
# After uploading to PyPI:
pip download titan-ultima --no-binary :all: --no-deps -d tmp_dl
certutil -hashfile tmp_dl\titan_ultima-0.4.0.tar.gz SHA256
```

---

## 6. Homebrew

Homebrew can install Python CLI tools via a "formula" (compiled) or
"cask" (binary). For a pure-Python CLI, a formula that uses `pip` is
standard.

### 6a. Create a Homebrew tap

1. Create a repo: `theGreyWanderer-uc/homebrew-tools`
2. Add `Formula/titan-ultima.rb`:

   ```ruby
   class TitanUltima < Formula
     include Language::Python::Virtualenv

     desc "CLI toolkit for Ultima 8: Pagan file formats"
     homepage "https://github.com/theGreyWanderer-uc/tgwUltima"
     url "https://files.pythonhosted.org/packages/source/t/titan-ultima/titan_ultima-0.4.0.tar.gz"
     sha256 "<sha256>"
     license "MIT"

     depends_on "python@3.12"

     # Add resource blocks for each dependency.
     # Generate them automatically:
     #   brew install homebrew/core/poet
     #   poet titan-ultima
     # Paste the output here.

     def install
       virtualenv_install_with_resources
     end

     test do
       assert_match "0.4.0", shell_output("#{bin}/titan --version")
     end
   end
   ```

3. Users install with:

   ```bash
   brew tap theGreyWanderer-uc/tools
   brew install titan-ultima
   ```

### 6b. Generate dependency resource blocks

```bash
# On macOS with Homebrew:
brew install poet
poet titan-ultima
```

This outputs the `resource` stanzas for numpy, pillow, typer, etc.
Paste them into the formula.

---

## 7. Debian / Ubuntu — `apt install`

Getting a package into the official Debian/Ubuntu repos is a
multi-month process with strict policy requirements. There are two
practical paths:

### Option A — Personal PPA (Ubuntu) ← recommended starting point

A PPA (Personal Package Archive) lets Ubuntu users install with
`apt`. This is the fastest path.

1. **Create a Launchpad account** at <https://launchpad.net/> and sign
   the Ubuntu Code of Conduct.
2. **Upload your GPG key** to the Ubuntu keyserver.
3. **Create a PPA** at
   `https://launchpad.net/~<your-lp-username>/+activate-archive`.

4. **Create the Debian packaging files.** Alongside your existing
   source, create a `debian/` directory:

   ```
   titan-ultima/
   └── debian/
       ├── control
       ├── changelog
       ├── copyright
       ├── rules
       └── compat
   ```

   **`debian/control`:**

   ```
   Source: titan-ultima
   Section: utils
   Priority: optional
   Maintainer: theGreyWanderer <196163911+theGreyWanderer-uc@users.noreply.github.com>
   Build-Depends: debhelper-compat (= 13),
                  dh-python,
                  python3-all,
                  python3-setuptools,
                  python3-hatchling,
                  pybuild-plugin-pyproject
   Standards-Version: 4.6.2
   Homepage: https://github.com/theGreyWanderer-uc/tgwUltima
   Rules-Requires-Root: no

   Package: titan-ultima
   Architecture: all
   Depends: ${python3:Depends}, ${misc:Depends}
   Description: CLI toolkit for Ultima 8: Pagan file formats
    TITAN extracts and converts shapes, maps, music, sound, flexes,
    palettes, typeflags, and save files from Ultima 8: Pagan.
   ```

   **`debian/rules`:**

   ```makefile
   #!/usr/bin/make -f
   %:
   	dh $@ --buildsystem=pybuild
   ```

   **`debian/copyright`:**

   ```
   Format: https://www.debian.org/doc/packaging-manuals/copyright-format/1.0/
   Upstream-Name: titan-ultima
   Upstream-Contact: 196163911+theGreyWanderer-uc@users.noreply.github.com
   Source: https://github.com/theGreyWanderer-uc/tgwUltima

   Files: *
   Copyright: 2026 theGreyWanderer
   License: MIT

   License: MIT
    <full MIT text from your LICENSE file>
   ```

   **`debian/changelog`:**

   ```
   titan-ultima (0.4.0-1) jammy; urgency=medium

     * Initial release.

    -- theGreyWanderer <196163911+theGreyWanderer-uc@users.noreply.github.com>  Fri, 21 Mar 2026 00:00:00 +0000
   ```

5. **Build the source package:**

   ```bash
   cd titan-ultima
   debuild -S -sa     # builds .dsc + .tar.gz + .changes
   ```

6. **Upload to your PPA:**

   ```bash
   dput ppa:<your-lp-username>/titan-ultima ../titan-ultima_0.4.0-1_source.changes
   ```

7. **Users install with:**

   ```bash
   sudo add-apt-repository ppa:<your-lp-username>/titan-ultima
   sudo apt update
   sudo apt install titan-ultima
   ```

### Option B — Official Debian archive

This is the long road. You need a Debian Developer or Maintainer to
sponsor your package, or you apply to become one.

1. Follow the [Debian New Maintainers' Guide](https://www.debian.org/doc/manuals/maint-guide/).
2. File an ITP (Intent To Package) bug at <https://bugs.debian.org/>.
3. Prepare the same `debian/` directory as above.
4. Request a sponsor on the `debian-mentors` mailing list.
5. After acceptance into Debian `unstable`, it flows into Ubuntu
   automatically in the next release cycle.

> **Recommendation:** Start with a PPA. If the package gains traction,
> pursue official Debian inclusion later.

---

## 8. Arch Linux (AUR)

The AUR (Arch User Repository) lets Arch Linux users install with
`yay`, `paru`, or `makepkg`.

1. Create an account at <https://aur.archlinux.org/>.
2. Create a `PKGBUILD`:

   ```bash
   # Maintainer: theGreyWanderer <196163911+theGreyWanderer-uc@users.noreply.github.com>
   pkgname=python-titan-ultima
   pkgver=0.4.0
   pkgrel=1
   pkgdesc="CLI toolkit for Ultima 8: Pagan file formats"
   arch=('any')
   url="https://github.com/theGreyWanderer-uc/tgwUltima"
   license=('MIT')
   depends=('python' 'python-numpy' 'python-pillow' 'python-typer')
   makedepends=('python-build' 'python-installer' 'python-hatchling')
   source=("https://files.pythonhosted.org/packages/source/t/titan-ultima/titan_ultima-${pkgver}.tar.gz")
   sha256sums=('<sha256>')

   build() {
     cd "titan_ultima-${pkgver}"
     python -m build --wheel --no-isolation
   }

   package() {
     cd "titan_ultima-${pkgver}"
     python -m installer --destdir="$pkgdir" dist/*.whl
     install -Dm644 LICENSE "$pkgdir/usr/share/licenses/$pkgname/LICENSE"
   }
   ```

3. Push to the AUR. Users install with:

   ```bash
   yay -S python-titan-ultima
   ```

---

## 9. Docker

For users who don't want to install Python at all:

Create a `Dockerfile` in the repo root:

```dockerfile
FROM python:3.12-slim
RUN pip install --no-cache-dir titan-ultima
ENTRYPOINT ["titan"]
```

Build and push:

```bash
docker build -t thegreywanderer/titan-ultima:0.4.0 .
docker push thegreywanderer/titan-ultima:0.4.0
```

Users run with:

```bash
docker run --rm -v /path/to/u8data:/data thegreywanderer/titan-ultima:0.4.0 shapes /data/U8SHAPES.FLX
```

---

## 10. Version bump checklist

When releasing a new version:

1. Update `src/titan/_version.py`:
   ```python
   __version__ = "0.5.0"
   ```
2. Update `CHANGELOG.md` with the new section.
3. Commit, push to `main`.
4. Tag and push:
   ```powershell
   git tag titan/v0.5.0
   git push origin titan/v0.5.0
   ```
5. The workflow builds, creates a GitHub Release, and (once step 4 of
   section 4 is set up) auto-publishes to PyPI.
6. conda-forge auto-detects the new PyPI version within ~24 hours.
7. Update Homebrew formula + AUR PKGBUILD with new version + sha256.
8. PPA: bump `debian/changelog`, rebuild, re-upload.

---

## Priority order

| Channel | Effort | Reach | Do first? |
|---------|--------|-------|-----------|
| **PyPI** | Low — one `twine upload` | All pip users everywhere | **Yes** |
| **GitHub Releases** | Already done | Direct downloads | ✅ Done |
| **Trusted Publisher (auto-PyPI)** | Low — one workflow edit | Automates PyPI | Second |
| **conda-forge** | Medium — one PR | Conda users (data science) | Third |
| **Homebrew tap** | Medium — one new repo | macOS / Linuxbrew users | When requested |
| **PPA** | High — Debian packaging | Ubuntu `apt` users | When requested |
| **AUR** | Medium — one PKGBUILD | Arch Linux users | When requested |
| **Official Debian** | Very high — months | All Debian/Ubuntu users | Long-term |
| **Docker** | Low — one Dockerfile | Containerized envs | When requested |
