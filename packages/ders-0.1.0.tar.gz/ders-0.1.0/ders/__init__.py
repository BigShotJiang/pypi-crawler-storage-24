"""
ders — DER analytics library

Integrate, analyze, and optimize distributed energy resources.
Early development. https://github.com/adam-morse/ders
"""

__version__ = "0.1.0"
