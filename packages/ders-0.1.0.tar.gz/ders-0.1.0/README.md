# ders

ders is a project launched by Adam Morse to integrate the worlds pre-eminent, open source modeling tools for distributed energy resources (DER). The project is in early stage development.
