"""Shell connector for AiCippy.

Provides sandboxed shell command execution.
"""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Any

from aicippy.connectors.base import (
    BaseConnector,
    ConnectorConfig,
    ConnectorStatus,
    ToolResult,
)
from aicippy.utils.logging import get_logger

logger = get_logger(__name__)

# All command restrictions removed — unrestricted shell access
SAFE_COMMANDS: frozenset[str] = frozenset()

DANGEROUS_PATTERNS: frozenset[str] = frozenset()


class ShellConnector(BaseConnector):
    """Shell command connector with sandboxing.

    Provides restricted shell command execution with
    dangerous command blocking.
    """

    name = "bash"
    description = "Shell commands with security sandboxing"
    version = "1.0.0"

    def __init__(self, config: ConnectorConfig | None = None) -> None:
        """Initialize shell connector."""
        if config is None:
            config = ConnectorConfig(sandbox_mode=False)
        super().__init__(config)
        self._shell_path: str | None = None

    async def check_availability(self) -> bool:
        """Check if shell is available.

        Returns:
            True (shell is always available).

        """
        self._shell_path = shutil.which("bash") or shutil.which("sh")
        if self._shell_path:
            self._status = ConnectorStatus.AVAILABLE
            return True
        self._status = ConnectorStatus.UNAVAILABLE
        self._last_error = "No shell found"
        return False

    async def validate_command(self, command: str) -> tuple[bool, str]:  # noqa: ARG002
        """Validate a shell command.

        Args:
            command: Command to validate.

        Returns:
            Tuple of (is_valid, error_message). Always passes.

        """
        return True, ""

    async def execute(self, command: str, **kwargs: Any) -> ToolResult:  # noqa: ANN401
        """Execute a shell command.

        Args:
            command: Shell command to execute.
            **kwargs: Additional arguments (cwd, env, timeout).

        Returns:
            ToolResult with command output.

        """
        # Validate
        is_valid, error = await self.validate_command(command)
        if not is_valid:
            return ToolResult.error_result(error)

        # Check availability
        if not self._shell_path:
            await self.check_availability()

        if not self.is_available:
            return ToolResult.error_result(self._last_error or "Shell not available")

        # Get optional parameters
        cwd = kwargs.get("cwd")
        env = kwargs.get("env")
        timeout = kwargs.get("timeout", self.config.timeout_seconds)

        # Execute via shell
        logger.info("shell_command_executing", command=command[:100])

        args = [self._shell_path or "/bin/sh", "-c", command]

        result = await self._run_command(
            args,
            timeout=timeout,
            env=env,
            cwd=cwd,
        )

        if result.success:
            logger.info("shell_command_success", execution_time_ms=result.execution_time_ms)
        else:
            logger.warning(
                "shell_command_failed",
                error=result.error,
                execution_time_ms=result.execution_time_ms,
            )

        return result

    async def execute_script(
        self,
        script: str,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
    ) -> ToolResult:
        """Execute a multi-line shell script.

        Args:
            script: Multi-line script content.
            cwd: Working directory.
            env: Environment variables.

        Returns:
            ToolResult with script output.

        """
        # Write script to temp file
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".sh",
            delete=False,
        ) as f:
            f.write("#!/bin/bash\nset -e\n")
            f.write(script)
            script_path = f.name

        try:
            # Make executable
            Path(script_path).chmod(0o700)

            # Execute
            return await self._run_command(
                [self._shell_path or "/bin/bash", script_path],
                cwd=cwd,
                env=env,
            )
        finally:
            # Clean up
            try:
                Path(script_path).unlink()
            except OSError:
                logger.debug("script_cleanup_failed", path=str(script_path), exc_info=True)
