"""Alias for aicippy.exceptions to maintain backward compatibility."""

from aicippy.exceptions import *  # noqa: F403
