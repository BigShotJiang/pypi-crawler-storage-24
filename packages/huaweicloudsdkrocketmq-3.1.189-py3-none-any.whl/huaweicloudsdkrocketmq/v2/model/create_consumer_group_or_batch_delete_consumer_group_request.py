# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateConsumerGroupOrBatchDeleteConsumerGroupRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'action': 'str',
        'body': 'CreateConsumerGroupOrBatchDeleteConsumerGroupReq'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'action': 'action',
        'body': 'body'
    }

    def __init__(self, instance_id=None, action=None, body=None):
        r"""CreateConsumerGroupOrBatchDeleteConsumerGroupRequest

        The model defined in huaweicloud sdk

        :param instance_id: **参数解释**： 实例ID。获取方法如下：调用“查询所有实例列表”接口，从响应体中获取实例ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。
        :type instance_id: str
        :param action: **参数解释**： 批量删除消费组时使用，不配置则为创建接口。 **约束限制**： 不涉及。 **取值范围**： - delete：删除。 **默认取值**： 不涉及。
        :type action: str
        :param body: Body of the CreateConsumerGroupOrBatchDeleteConsumerGroupRequest
        :type body: :class:`huaweicloudsdkrocketmq.v2.CreateConsumerGroupOrBatchDeleteConsumerGroupReq`
        """
        
        

        self._instance_id = None
        self._action = None
        self._body = None
        self.discriminator = None

        self.instance_id = instance_id
        if action is not None:
            self.action = action
        if body is not None:
            self.body = body

    @property
    def instance_id(self):
        r"""Gets the instance_id of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.

        **参数解释**： 实例ID。获取方法如下：调用“查询所有实例列表”接口，从响应体中获取实例ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。

        :return: The instance_id of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.

        **参数解释**： 实例ID。获取方法如下：调用“查询所有实例列表”接口，从响应体中获取实例ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。

        :param instance_id: The instance_id of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def action(self):
        r"""Gets the action of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.

        **参数解释**： 批量删除消费组时使用，不配置则为创建接口。 **约束限制**： 不涉及。 **取值范围**： - delete：删除。 **默认取值**： 不涉及。

        :return: The action of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.
        :rtype: str
        """
        return self._action

    @action.setter
    def action(self, action):
        r"""Sets the action of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.

        **参数解释**： 批量删除消费组时使用，不配置则为创建接口。 **约束限制**： 不涉及。 **取值范围**： - delete：删除。 **默认取值**： 不涉及。

        :param action: The action of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.
        :type action: str
        """
        self._action = action

    @property
    def body(self):
        r"""Gets the body of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.

        :return: The body of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.
        :rtype: :class:`huaweicloudsdkrocketmq.v2.CreateConsumerGroupOrBatchDeleteConsumerGroupReq`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.

        :param body: The body of this CreateConsumerGroupOrBatchDeleteConsumerGroupRequest.
        :type body: :class:`huaweicloudsdkrocketmq.v2.CreateConsumerGroupOrBatchDeleteConsumerGroupReq`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateConsumerGroupOrBatchDeleteConsumerGroupRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
