"""Document plugin system — charts, tables, presentations, export via MCP"""

__version__ = "0.0.1"
