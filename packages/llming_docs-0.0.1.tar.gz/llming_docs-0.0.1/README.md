# llming-docs

Document plugin system — charts, tables, presentations, export via MCP

> This is a placeholder release. The full package is coming soon.
