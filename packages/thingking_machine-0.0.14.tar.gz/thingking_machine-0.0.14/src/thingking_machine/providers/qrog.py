# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
from os import environ
import requests


def respond(messages=None, instructions=None, **kwargs):
    """A simple requests call to Groq chat completions endpoint.
            kwargs:
                temperature     = 0 to 1.0
                top_p           = 0.0 to 1.0
                n               = 1 to ...
                frequency_penalty = -2.0 to 2.0
                presence_penalty = -2.0 to 2.0
                max_tokens      = number of tokens
        """
    api_base = environ.get('GROQ_API_BASE', 'https://api.groq.com/openai/v1')
    api_key = environ.get('GROQ_API_KEY')
    default_model = environ.get('GROQ_DEFAULT_MODEL', 'openai/gpt-oss-120b')

    instruction = kwargs.get('system_instruction', instructions)

    json_data = {
        "model":            kwargs.get("model", default_model),
        "instructions":     instruction,
        "input":            messages,
        "max_output_tokens": kwargs.get("max_tokens", 64000),
        "reasoning": {
            "effort": "high",
            "summary": "detailed"
        }
    }

    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + api_key
    }

    try:
        response = requests.post(
            f'{api_base}/responses',
            headers=headers,
            json=json_data,
        )
        
        if response.status_code == requests.codes.ok:
            output = response.json()
            text = ''
            thoughts = ''
            for part in output['output']:
                if part['type'] == 'message':
                    for chunk in part['content']:
                        text += chunk['text']
                elif part['type'] == 'reasoning':
                    for chunk in part['summary']:
                        thoughts += chunk['text']
        else:
            print(f"API Request status code: {response.status_code}")
            return '', ''

        return thoughts, text

    except Exception as e:
        print("Unable to generate Response")
        print(f"Exception: {e}")

        return '', ''


if __name__ == "__main__":
    ...
