# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
from os import environ
import requests


def respond(messages=None, instructions=None, **kwargs):
    """A continuation of text with a given context and instruction.
        kwargs:
            temperature     = 0 to 1.0
            top_p           = 0.0 to 1.0
            top_k           = The maximum number of tokens to consider when sampling.
            n               = 1 is mandatory for this method continuationS have n > 1
            max_tokens      = number of tokens
            stop            = ['stop']  array of up to 4 sequences
    """
    gemini_key = environ.get('GEMINI_API_KEY', '')
    gemini_api_base = environ.get('GEMINI_API_BASE', 'https://generativelanguage.googleapis.com/v1beta')
    gemini_content_model = environ.get('GEMINI_DEFAULT_CONTENT_MODEL', 'gemini-2.5-flash')

    garbage = [
        {'category': 'HARM_CATEGORY_HATE_SPEECH', 'threshold': 'BLOCK_NONE'},
        {'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold': 'BLOCK_NONE'},
        {'category': 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold': 'BLOCK_NONE'},
        {'category': 'HARM_CATEGORY_HARASSMENT', 'threshold': 'BLOCK_NONE'},
        {'category': 'HARM_CATEGORY_CIVIC_INTEGRITY', 'threshold': 'BLOCK_NONE'}
    ]

    instructions         = kwargs.get('system_instruction', instructions)
    system_instruction  = dict(role='system', parts=[dict(text=instructions)]) if instructions else None

    # Trickery for thinking models
    thinking_config = None
    model = kwargs.get("model", gemini_content_model)
    if model.startswith('gemini-2.5'):
        thinking_config = {
            'includeThoughts': kwargs.get('include_thoughts', True),
            'thinkingBudget': kwargs.get('thinking_budget', 0)
        }
    elif model.startswith('gemini-3'):
        thinking_config = {
            'includeThoughts': kwargs.get('include_thoughts', True),
            'thinkingLevel': kwargs.get('thinking_level', 'high')
        }

    # Final payload
    json_data = {
        'systemInstruction':        system_instruction,
        'contents':                 messages,
        # 'tools':                    kwargs.get('tools', []),
        #     [
        #     # {
        #     #     "file_search": {"file_search_store_names": ["store_name"]}
        #     # },
        #     # {
        #           "url_context": {}
        #     # }
        # ],
        'safetySettings':           garbage,
        'generationConfig':{
            'stopSequences':        kwargs.get('stop_sequences', ['STOP','Title']),
            'responseMimeType':     kwargs.get('mime_type','text/plain'),
            'responseModalities':   kwargs.get('modalities',['TEXT']),
            'temperature':          kwargs.get('temperature', 0.5),
            'maxOutputTokens':      kwargs.get('max_tokens', 10000),
            # 'candidateCount':       kwargs.get('n', 1),  # is in continuationS
            'topP':                 kwargs.get('top_p', 0.9),
            'topK':                 kwargs.get('top_k', 10),
            'enableEnhancedCivicAnswers':   False,
        },
    }
    if thinking_config:
        json_data['generationConfig']['thinkingConfig'] = thinking_config
    if kwargs.get('sources'):
        json_data['tools'].append(
            {
                "url_context": {}
            }
        )

    # Now we can try
    try:
        response = requests.post(
            url=f'{gemini_api_base}/models/{kwargs.get("model", gemini_content_model)}:generateContent',
            params=f'key={gemini_key}',
            json=json_data,
        )
        if response.status_code == requests.codes.ok:
            output = response.json()
            text = ''
            thoughts = ''
            if output['candidates'][0]['finishReason'] == 'SAFETY':
                raise Exception('Answer censored by Google.')
            for part in output['candidates'][0]['content']['parts']:
                if part.get('thought'):
                    thoughts += part['text']
                else:
                    text += part['text']
        else:
            print(f'Request status code: {response.status_code}')
            return '', ''

    except Exception as e:
        print(f'Unable to generate continuation of the text, {e}')
        return '', ''

    return thoughts, text


if __name__ == '__main__':
    ...
