"""gRPC transport infrastructure — hidden from users."""
