"""Pcache1 RPC wrappers — thin service layer (proto only)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import grpc

from radiens_core._generated import allegoserver_pb2_grpc, common_pb2
from radiens_core._transport._errors import handle_grpc_error
from radiens_core.models.common import ClientType

if TYPE_CHECKING:
    from radiens_core._transport._channel_pool import ChannelPool


def get_hd_snapshot_proto(
    pool: ChannelPool,
    addr: str,
    request: common_pb2.HDSnapshotRequest,
) -> common_pb2.HDSnapshot:
    """Send ``GetHDSnapshot`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = allegoserver_pb2_grpc.Pcache1Stub(channel)
    try:
        return stub.GetHDSnapshot(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.ALLEGO)
        raise
