"""Radiens Python client for neuroscience data acquisition and analysis."""

from importlib.metadata import version

__version__ = version("radiens-core")

from radiens_core.allego_client import AllegoClient
from radiens_core.curate_client import CurateClient
from radiens_core.models.common import ServiceEndpoint
from radiens_core.videre_client import VidereClient

__all__ = [
    "AllegoClient",
    "CurateClient",
    "ServiceEndpoint",
    "VidereClient",
    "__version__",
]
