"""Domain models — pure Pydantic v2, zero proto dependency.

All enums and models are importable from their domain-grouped submodules:

    from radiens_core.models.stim import StimParams, StimShape
    from radiens_core.models.signals import SignalType, SigSelect
    from radiens_core.models.status import RecordMode, StreamMode
"""

from radiens_core.models.channels import (
    AreaUnits,
    ChannelInfo,
    ChannelMetadata,
    KeyIdxs,
    SignalUnits,
    SitePosition,
)
from radiens_core.models.common import ClientType, ServiceEndpoint
from radiens_core.models.dataset import DatasetMetadata, RadiensFileType, TrsMode
from radiens_core.models.ports import GPIOChannelCount, Port, PortChannelCount
from radiens_core.models.signals import KeyIndex, SignalArrays, SignalType, SigSelect
from radiens_core.models.status import (
    BackboneMode,
    BackboneStatus,
    DataRecordingType,
    RecordingConfig,
    RecordingStatus,
    RecordMode,
    RecordStateRequest,
    RestartRequest,
    StreamingStatus,
    StreamMode,
    StreamStateRequest,
)
from radiens_core.models.stim import (
    StimKeypressIndex,
    StimParams,
    StimPolarity,
    StimPulseMode,
    StimShape,
    StimStep,
    StimStepRequest,
    StimStepState,
    StimTriggerEdgeOrLevel,
    StimTriggerHighOrLow,
)
from radiens_core.models.time_range import TimeRange
from radiens_core.models.triggers import (
    ManualStimTriggerRequest,
    ManualStimTriggerToggleRequest,
    SetTriggerStateRequest,
    TriggerChannel,
    TriggerState,
)

__all__ = [
    "AreaUnits",
    "BackboneMode",
    "BackboneStatus",
    "ChannelInfo",
    "ChannelMetadata",
    "ClientType",
    "DataRecordingType",
    "DatasetMetadata",
    "GPIOChannelCount",
    "KeyIdxs",
    "KeyIndex",
    "ManualStimTriggerRequest",
    "ManualStimTriggerToggleRequest",
    "Port",
    "PortChannelCount",
    "RadiensFileType",
    "RecordMode",
    "RecordStateRequest",
    "RecordingConfig",
    "RecordingStatus",
    "RestartRequest",
    "ServiceEndpoint",
    "SetTriggerStateRequest",
    "SigSelect",
    "SignalArrays",
    "SignalType",
    "SignalUnits",
    "SitePosition",
    "StimKeypressIndex",
    "StimParams",
    "StimPolarity",
    "StimPulseMode",
    "StimShape",
    "StimStep",
    "StimStepRequest",
    "StimStepState",
    "StimTriggerEdgeOrLevel",
    "StimTriggerHighOrLow",
    "StreamMode",
    "StreamStateRequest",
    "StreamingStatus",
    "TimeRange",
    "TriggerChannel",
    "TriggerState",
    "TrsMode",
]
