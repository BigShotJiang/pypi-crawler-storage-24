"""Common enums not tied to a specific domain model."""

from enum import StrEnum


class ClientType(StrEnum):
    """Client type identifier."""

    ALLEGO = "AllegoClient"
    VIDERE = "VidereClient"
    CURATE = "CurateClient"


class ServiceEndpoint(StrEnum):
    """gRPC service endpoint identifier.

    Mirrors the proto ``GrpcServiceType`` enum values used as keys in
    the ``ServerSpec.service`` map returned by ``GetRadiensServers``.
    """

    ALLEGO_CORE = "ALLEGO_CORE"
    ALLEGO_PCACHE = "ALLEGO_PCACHE"
    ALLEGO_KPI = "ALLEGO_KPI"
    ALLEGO_NEURONS = "ALLEGO_NEURONS"
    RADIENS_CORE = "RADIENS_CORE"
    RADIENS_SPIKE_SORTER = "RADIENS_SPIKE_SORTER"
    RADIENS_DEV = "RADIENS_DEV"
    RADIENS_DASHBOARDS = "RADIENS_DASHBOARDS"
    ALLEGO_LIFECYCLE = "ALLEGO_LIFECYCLE"
    RADIENS_LIFECYCLE = "RADIENS_LIFECYCLE"
