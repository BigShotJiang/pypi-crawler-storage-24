"""Port and GPIO domain models and enums."""

from __future__ import annotations

from enum import IntEnum

from pydantic import BaseModel, ConfigDict


class Port(IntEnum):
    """Hardware port identifier. Values match proto ``common.Port``."""

    A = 0
    B = 1
    C = 2
    D = 3
    E = 4
    F = 5
    G = 6
    H = 7


class PortChannelCount(BaseModel):
    """Port channel count information."""

    model_config = ConfigDict(frozen=True)

    port: Port
    channel_count: int


class GPIOChannelCount(BaseModel):
    """GPIO channel count information."""

    model_config = ConfigDict(frozen=True)

    n_aux: int
    n_din: int
    n_dout: int
