"""Stream state converters — domain models <-> proto messages."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._converters._common_enums import stream_mode_to_proto
from radiens_core._generated import allegoserver_pb2

if TYPE_CHECKING:
    from radiens_core.models.status import StreamStateRequest


def stream_state_request_to_proto(
    request: StreamStateRequest,
) -> allegoserver_pb2.SetStreamRequest:
    """Convert domain StreamStateRequest to proto SetStreamRequest."""
    return allegoserver_pb2.SetStreamRequest(
        mode=stream_mode_to_proto(request.mode),
    )
