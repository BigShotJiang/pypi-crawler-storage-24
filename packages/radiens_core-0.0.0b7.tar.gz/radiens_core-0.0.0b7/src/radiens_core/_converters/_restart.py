"""Restart converters — domain models <-> proto messages."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._generated import allegoserver_pb2
from radiens_core.models.status import BackboneMode

if TYPE_CHECKING:
    from radiens_core.models.status import RestartRequest


# --- BackboneMode enum conversion ---

_BACKBONE_MODE_TO_PROTO: dict[BackboneMode, allegoserver_pb2.BackboneMode.ValueType] = {
    BackboneMode.SMARTBOX_PRO: allegoserver_pb2.SMARTBOX_PRO,
    BackboneMode.SMARTBOX_SIM_GEN_SINE: allegoserver_pb2.SMARTBOX_SIM_GEN_SINE,
    BackboneMode.SMARTBOX_SIM_GEN_SPIKES: allegoserver_pb2.SMARTBOX_SIM_GEN_SPIKES,
    BackboneMode.SMARTBOX_SIM_DATASOURCE: allegoserver_pb2.SMARTBOX_SIM_DATASOURCE,
    BackboneMode.OPEN_EPHYS_USB3: allegoserver_pb2.OPEN_EPHYS_USB3,
    BackboneMode.INTAN_RECORDING_CONTROLLER_1024: allegoserver_pb2.INTAN_RECORDING_CONTROLLER_1024,
    BackboneMode.SMARTBOX_CLASSIC: allegoserver_pb2.SMARTBOX_CLASSIC,
    BackboneMode.INTAN_RECORDING_CONTROLLER_512: allegoserver_pb2.INTAN_RECORDING_CONTROLLER_512,
    BackboneMode.OPEN_EPHYS_USB2: allegoserver_pb2.OPEN_EPHYS_USB2,
    BackboneMode.INTAN_USB2: allegoserver_pb2.INTAN_USB2,
    BackboneMode.SMARTBOX_SIM_GEN_SINE_MAPPED: allegoserver_pb2.SMARTBOX_SIM_GEN_SINE_MAPPED,
    BackboneMode.SMARTBOX_SIM_GEN_SINE_HIGH_FREQ: allegoserver_pb2.SMARTBOX_SIM_GEN_SINE_HIGH_FREQ,
    BackboneMode.SMARTBOX_SIM_GEN_SINE_MULTI_BAND: allegoserver_pb2.SMARTBOX_SIM_GEN_SINE_MULTI_BAND,
    BackboneMode.SMARTBOX_PRO_SINAPS_256: allegoserver_pb2.SMARTBOX_PRO_SINAPS_256,
    BackboneMode.SMARTBOX_PRO_SINAPS_1024: allegoserver_pb2.SMARTBOX_PRO_SINAPS_1024,
    BackboneMode.XDAQ_ONE_REC: allegoserver_pb2.XDAQ_ONE_REC,
    BackboneMode.XDAQ_ONE_STIM: allegoserver_pb2.XDAQ_ONE_STIM,
    BackboneMode.XDAQ_CORE_REC: allegoserver_pb2.XDAQ_CORE_REC,
    BackboneMode.XDAQ_CORE_STIM: allegoserver_pb2.XDAQ_CORE_STIM,
    BackboneMode.SMARTBOX_PRO_SINAPS_512: allegoserver_pb2.SMARTBOX_PRO_SINAPS_512,
    BackboneMode.XDAQ_GEN2_ONE_STIM: allegoserver_pb2.XDAQ_GEN2_ONE_STIM,
    BackboneMode.XDAQ_GEN2_CORE_STIM: allegoserver_pb2.XDAQ_GEN2_CORE_STIM,
    BackboneMode.XDAQ_GEN2_ONE_REC: allegoserver_pb2.XDAQ_GEN2_ONE_REC,
    BackboneMode.XDAQ_GEN2_CORE_REC: allegoserver_pb2.XDAQ_GEN2_CORE_REC,
    BackboneMode.SMARTBOX_SIM_GEN_LFP: allegoserver_pb2.SMARTBOX_SIM_GEN_LFP,
}


def backbone_mode_to_proto(bm: BackboneMode) -> allegoserver_pb2.BackboneMode.ValueType:
    """Convert domain BackboneMode to proto BackboneMode."""
    return _BACKBONE_MODE_TO_PROTO[bm]


_BACKBONE_MODE_FROM_PROTO: dict[int, BackboneMode] = {
    int(allegoserver_pb2.SMARTBOX_PRO): BackboneMode.SMARTBOX_PRO,
    int(allegoserver_pb2.SMARTBOX_SIM_GEN_SINE): BackboneMode.SMARTBOX_SIM_GEN_SINE,
    int(allegoserver_pb2.SMARTBOX_SIM_GEN_SPIKES): BackboneMode.SMARTBOX_SIM_GEN_SPIKES,
    int(allegoserver_pb2.SMARTBOX_SIM_DATASOURCE): BackboneMode.SMARTBOX_SIM_DATASOURCE,
    int(allegoserver_pb2.OPEN_EPHYS_USB3): BackboneMode.OPEN_EPHYS_USB3,
    int(allegoserver_pb2.INTAN_RECORDING_CONTROLLER_1024): BackboneMode.INTAN_RECORDING_CONTROLLER_1024,
    int(allegoserver_pb2.SMARTBOX_CLASSIC): BackboneMode.SMARTBOX_CLASSIC,
    int(allegoserver_pb2.INTAN_RECORDING_CONTROLLER_512): BackboneMode.INTAN_RECORDING_CONTROLLER_512,
    int(allegoserver_pb2.OPEN_EPHYS_USB2): BackboneMode.OPEN_EPHYS_USB2,
    int(allegoserver_pb2.INTAN_USB2): BackboneMode.INTAN_USB2,
    int(allegoserver_pb2.SMARTBOX_SIM_GEN_SINE_MAPPED): BackboneMode.SMARTBOX_SIM_GEN_SINE_MAPPED,
    int(allegoserver_pb2.SMARTBOX_SIM_GEN_SINE_HIGH_FREQ): BackboneMode.SMARTBOX_SIM_GEN_SINE_HIGH_FREQ,
    int(allegoserver_pb2.SMARTBOX_SIM_GEN_SINE_MULTI_BAND): BackboneMode.SMARTBOX_SIM_GEN_SINE_MULTI_BAND,
    int(allegoserver_pb2.SMARTBOX_PRO_SINAPS_256): BackboneMode.SMARTBOX_PRO_SINAPS_256,
    int(allegoserver_pb2.SMARTBOX_PRO_SINAPS_1024): BackboneMode.SMARTBOX_PRO_SINAPS_1024,
    int(allegoserver_pb2.XDAQ_ONE_REC): BackboneMode.XDAQ_ONE_REC,
    int(allegoserver_pb2.XDAQ_ONE_STIM): BackboneMode.XDAQ_ONE_STIM,
    int(allegoserver_pb2.XDAQ_CORE_REC): BackboneMode.XDAQ_CORE_REC,
    int(allegoserver_pb2.XDAQ_CORE_STIM): BackboneMode.XDAQ_CORE_STIM,
    int(allegoserver_pb2.SMARTBOX_PRO_SINAPS_512): BackboneMode.SMARTBOX_PRO_SINAPS_512,
    int(allegoserver_pb2.XDAQ_GEN2_ONE_STIM): BackboneMode.XDAQ_GEN2_ONE_STIM,
    int(allegoserver_pb2.XDAQ_GEN2_CORE_STIM): BackboneMode.XDAQ_GEN2_CORE_STIM,
    int(allegoserver_pb2.XDAQ_GEN2_ONE_REC): BackboneMode.XDAQ_GEN2_ONE_REC,
    int(allegoserver_pb2.XDAQ_GEN2_CORE_REC): BackboneMode.XDAQ_GEN2_CORE_REC,
    int(allegoserver_pb2.SMARTBOX_SIM_GEN_LFP): BackboneMode.SMARTBOX_SIM_GEN_LFP,
}


def backbone_mode_from_proto(pb: int) -> BackboneMode:
    """Convert proto BackboneMode int to domain BackboneMode."""
    return _BACKBONE_MODE_FROM_PROTO[pb]


def restart_request_to_proto(
    request: RestartRequest,
) -> allegoserver_pb2.RestartRequest:
    """Convert domain RestartRequest to proto RestartRequest."""
    return allegoserver_pb2.RestartRequest(
        mode=backbone_mode_to_proto(request.mode),
    )
