"""Shared enum converters used across multiple converter modules.

Only enum converters that are imported by more than one converter file
belong here. Single-use converters should live in their domain converter.
"""

from __future__ import annotations

from radiens_core._generated import allegoserver_pb2, common_pb2
from radiens_core.models.ports import Port
from radiens_core.models.status import RecordMode, StreamMode

# --- Port ---

_PORT_TO_PROTO: dict[Port, common_pb2.Port.ValueType] = {
    Port.A: common_pb2.A,
    Port.B: common_pb2.B,
    Port.C: common_pb2.C,
    Port.D: common_pb2.D,
    Port.E: common_pb2.E,
    Port.F: common_pb2.F,
    Port.G: common_pb2.G,
    Port.H: common_pb2.H,
}

_PORT_FROM_PROTO: dict[int, Port] = {
    int(common_pb2.A): Port.A,
    int(common_pb2.B): Port.B,
    int(common_pb2.C): Port.C,
    int(common_pb2.D): Port.D,
    int(common_pb2.E): Port.E,
    int(common_pb2.F): Port.F,
    int(common_pb2.G): Port.G,
    int(common_pb2.H): Port.H,
}


def port_to_proto(port: Port) -> common_pb2.Port.ValueType:
    """Convert domain Port to proto Port."""
    return _PORT_TO_PROTO[port]


def port_from_proto(pb: int) -> Port:
    """Convert proto Port int to domain Port."""
    return _PORT_FROM_PROTO[pb]


# --- RecordMode ---

_RECORD_MODE_TO_PROTO: dict[RecordMode, allegoserver_pb2.RecordMode.ValueType] = {
    RecordMode.OFF: allegoserver_pb2.R_OFF,
    RecordMode.ON: allegoserver_pb2.R_ON,
}

_RECORD_MODE_FROM_PROTO: dict[int, RecordMode] = {
    int(allegoserver_pb2.R_OFF): RecordMode.OFF,
    int(allegoserver_pb2.R_ON): RecordMode.ON,
}


def record_mode_to_proto(rm: RecordMode) -> allegoserver_pb2.RecordMode.ValueType:
    """Convert domain RecordMode to proto RecordMode."""
    return _RECORD_MODE_TO_PROTO[rm]


def record_mode_from_proto(pb: int) -> RecordMode:
    """Convert proto RecordMode int to domain RecordMode."""
    return _RECORD_MODE_FROM_PROTO[pb]


# --- StreamMode ---

_STREAM_MODE_TO_PROTO: dict[StreamMode, allegoserver_pb2.StreamMode.ValueType] = {
    StreamMode.OFF: allegoserver_pb2.S_OFF,
    StreamMode.ON: allegoserver_pb2.S_ON,
}

_STREAM_MODE_FROM_PROTO: dict[int, StreamMode] = {
    int(allegoserver_pb2.S_OFF): StreamMode.OFF,
    int(allegoserver_pb2.S_ON): StreamMode.ON,
}


def stream_mode_to_proto(sm: StreamMode) -> allegoserver_pb2.StreamMode.ValueType:
    """Convert domain StreamMode to proto StreamMode."""
    return _STREAM_MODE_TO_PROTO[sm]


def stream_mode_from_proto(pb: int) -> StreamMode:
    """Convert proto StreamMode int to domain StreamMode."""
    return _STREAM_MODE_FROM_PROTO[pb]
