# radiens-core

**The next-generation Python interface for the Radiens neuroscience platform.**

## Overview

`radiens-core` is a modern, high-performance Python client designed to interface seamlessly with the Radiens electrophysiology ecosystem. This package represents a complete re-imagining of the original Radiens client, built from the ground up to provide a more intuitive, reliable, and efficient experience for researchers.

Whether you are performing real-time data acquisition, conducting deep offline analysis, or managing complex data curation workflows, `radiens-core` provides the foundational tools required for modern neuroscience research.

## Key Capabilities

- **Real-time Acquisition (`AllegoClient`)**: Connect to live acquisition streams, monitor system status, and control hardware parameters with minimal latency.
- **Offline Analysis (`VidereClient`)**: Efficiently access and process recorded electrophysiology data for post-hoc analysis and visualization.
- **Data Curation (`CurateClient`)**: Streamline data management, conversion, and organization within the Radiens environment.

## Documentation

Comprehensive documentation, including API references and detailed usage guides, is available at:

👉 **[https://neuronexus.github.io/radiens-core-python/](https://neuronexus.github.io/radiens-core-python/)**

## Installation

```bash
pip install radiens-core
```

*Note: Access to the Radiens platform and valid credentials are required.*

## Support

For technical support or inquiries regarding the Radiens platform:

- **Web**: [NeuroNexus Support](https://neuronexus.com/support/)
- **Email**: <support@neuronexus.com>

## License

This project is licensed under the terms of the [LICENSE](LICENSE) file.
