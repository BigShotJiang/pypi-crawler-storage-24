#!/usr/bin/env python3
"""Test Shannon criteria implementation"""

from stim_hypercube import DEFAULT_ELECTRODE_AREA, SHANNON_K, calculate_shannon_limit, check_shannon_safety

print("Shannon criteria test:")
print(f"  k = {SHANNON_K} μC/cm²")
print(f"  Default electrode area = {DEFAULT_ELECTRODE_AREA} cm²")

# Calculate Shannon limit
limit = calculate_shannon_limit(DEFAULT_ELECTRODE_AREA)
print(f"  Shannon limit = {limit:.2f} μC/cm²")

# Test some example values
test_charges = [0.1, 1.0, 10.0, 25.0]  # nC
print("\nSafety test examples:")
for charge_nc in test_charges:
    is_safe, density, limit_calc = check_shannon_safety(charge_nc, DEFAULT_ELECTRODE_AREA)
    status = "✅ SAFE" if is_safe else "⚠️  UNSAFE"
    print(f"  Charge {charge_nc:4.1f} nC → {density:5.1f} μC/cm² → {status}")
