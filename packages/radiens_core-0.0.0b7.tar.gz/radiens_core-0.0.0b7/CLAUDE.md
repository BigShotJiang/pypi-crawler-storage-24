# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

**Note to Claude Code**: This is a living document. As you learn new patterns, conventions, or practices while working with the user, or when changes are made that should be reflected here, proactively update this CLAUDE.md to keep it current and useful.

## Radiens-Core - Modern Python Client

Type-safe Python client for the Radiens electrophysiology analytics platform.

See `README-DEV.md` for detailed developer documentation.

## Key Technologies

- Python 3.12+
- gRPC (communication with backend)
- Pydantic v2 (domain models)
- mypy strict mode (type safety)
- uv (package manager)

## Development Commands

### Environment Setup

```bash
# Install dependencies (creates .venv)
uv sync
```

### After Every Significant Change (REQUIRED)

Run these to auto-fix formatting and lint issues before reviewing your work:

```bash
uv run ruff check --fix src/ tests/  # Auto-fix imports and lint issues
uv run ruff format src/ tests/        # Format code (like black)
```

### Pre-Commit Checklist (REQUIRED)

Run all four before every commit:

```bash
uv run ruff check --fix src/ tests/  # Auto-fix lint issues first
uv run ruff format src/ tests/        # Format code
uv run mypy --strict src/ tests/      # Type checking (THE critical gate)
uv run pytest tests/unit/ -v          # Unit tests
```

### Publishing to PyPI

```bash
# 1. Update version in pyproject.toml
# 2. Run pre-commit checks
# 3. Build and publish:
rm -rf dist/ build/
uv build
uv run twine upload --repository radiens-core dist/*
```

## Architecture

**Proto-driven type safety** is the core design principle.

### Layer Structure

```text
src/radiens_core/
  __init__.py                 # Public API surface
  exceptions.py               # Exception hierarchy
  models/                     # Pydantic v2, ZERO proto dependency
  _transport/                 # gRPC channel pool, auth, error mapping
  _converters/                # Proto <-> domain (ONLY place importing both)
  _services/                  # RPC wrappers (domain in, domain out)
  allego_client.py            # Real-time client
  videre_client.py            # Offline file client
  curate_client.py            # Curation client
  _generated/                 # Committed proto stubs (DO NOT EDIT)
```

### Layer Import Rules

| Layer | Can import from |
| --- | --- |
| `models/` | stdlib, pydantic, numpy |
| `_converters/` | `models/`, `_generated/` |
| `_services/` | `_converters/`, `_generated/`, `_transport/`, `models/` |
| Client classes | `_services/`, `_transport/`, `models/` |

**Critical Rule:** Only `_converters/` and `_services/` may import from `_generated/`. Nothing user-facing touches proto types.

## Type Safety Workflow

The type system is the change-detection mechanism:

**The chain:** Proto `.pyi` stubs → `_converters/` → `models/` → `_services/` → clients

When protos change:

1. Regenerate proto stubs in radix repo (with `mypy-protobuf`)
2. Copy updated `_generated/` files here
3. Run `uv run mypy --strict src/` - shows exactly what broke
4. Fix `_converters/` first, then follow type errors outward
5. Commit updated `_generated/` alongside your fixes

## Code Conventions

### Imports

Always place imports at the top of the file — never inside functions, methods, or conditional blocks. This applies to all imports including stdlib, third-party, and local.

```python
# Correct: imports at top of file
from radiens_core.models.signal import SignalData

def process(data: SignalData) -> None:
    ...

# Wrong: import inside function
def process() -> None:
    from radiens_core.models.signal import SignalData  # Never do this
    ...
```

The only exception is `TYPE_CHECKING` guards, which are still at the top of the file.

### All Files

```python
from __future__ import annotations  # Required in ALL files

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    # Type-only imports here
    from some_module import SomeType
```

### Pydantic Models

```python
from pydantic import BaseModel, ConfigDict

class SignalData(BaseModel):  # type: ignore[explicit-any]
    """All models need this ignore for BaseModel."""
    model_config = ConfigDict(frozen=True)  # Immutable

    timestamp: float
    values: list[float]
```

**Why the ignore?** Pydantic's `BaseModel` uses `Any` internally, conflicting with `disallow_any_explicit = true`. The ignore is surgical and intentional.

### Converters

```python
# _converters/ - ONLY place importing both proto and domain
from radiens_core._generated import signal_pb2
from radiens_core.models.signal import SignalData

def proto_to_domain(proto: signal_pb2.Signal) -> SignalData:
    """Convert proto to domain model."""
    return SignalData(
        timestamp=proto.timestamp,
        values=list(proto.values),
    )
```

### Flex Types & `@validate_call`

When using "Flex" types (e.g., `FlexTimeRange` from `models.dataset`, `FlexSignalSpec` from `models.signals`) with Pydantic's `@validate_call`, Pydantic performs runtime coercion.

1. **Top-level Imports:** Flex types **must** be imported at the top level (not in `TYPE_CHECKING`) because Pydantic requires them at runtime.
2. **Ruff Config:** `pyproject.toml` is configured with `runtime-evaluated-decorators = ["pydantic.validate_call"]` to ensure Ruff allows these top-level imports despite them only appearing in annotations.
3. **Mypy Casting:** Use `typing.cast` with string literals to satisfy mypy, as it cannot "see" the Pydantic coercion.

```python
from radiens_core.models.dataset import FlexTimeRange

@validate_call(config=ConfigDict(arbitrary_types_allowed=True))
def get_data(self, time_range: FlexTimeRange) -> Data:
    # Cast with string literal satisfies mypy
    tr_spec = cast("TimeRangeSpec", time_range)
    ...
```

## Testing

```bash
# Run unit tests
uv run pytest tests/unit/ -v

# Run specific test file
uv run pytest tests/unit/test_converters.py -v

# Run with coverage
uv run pytest tests/unit/ --cov=radiens_core --cov-report=html
```

## Editor Setup (VS Code)

**Required extensions:**

- Pylance (type checking)
- Ruff (linting + formatting)

**Recommended extensions:**

- Mypy Type Checker (real-time type checking)

**Settings** (see README-DEV.md for full `.vscode/settings.json`)

## Important Notes

- **mypy strict is non-negotiable**: All code must pass `mypy --strict`
- **Type errors block commits**: Fix all mypy errors before committing
- **Proto changes cascade**: Type system catches all breaking changes
- **Immutable models**: All Pydantic models use `frozen=True`
- **`_generated/` is committed**: Proto stubs are version controlled
- **Layer boundaries are strict**: Follow import rules precisely

## Protobuf Updates

Proto generation is owned by the `core_packages/radix` repo.

When you receive updated proto files:

1. Copy new `_generated/` files
2. Run `uv run mypy --strict src/`
3. mypy shows exactly what needs fixing
4. Fix converters first (they import both proto and domain)
5. Follow type errors through services to clients
6. Commit `_generated/` changes with your fixes

## Quick Reference

```bash
# Setup
uv sync

# Type check (most important)
uv run mypy --strict src/ tests/

# Lint
uv run ruff check src/ tests/

# Test
uv run pytest tests/unit/ -v

# Auto-fix and format (run after every significant change)
uv run ruff check --fix src/ tests/
uv run ruff format src/ tests/

# Build
uv build

# Publish
uv run twine upload --repository radiens-core dist/*
```

## Client APIs

```python
from radiens_core import AllegoClient, VidereClient, CurateClient

# Real-time acquisition
client = AllegoClient(host="localhost", port=50051)

# Offline analysis
client = VidereClient(host="localhost", port=50052)

# Data curation
client = CurateClient(host="localhost", port=50053)
```

All clients return domain models (never proto types).
