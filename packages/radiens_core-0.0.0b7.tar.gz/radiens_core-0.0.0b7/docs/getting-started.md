# Getting Started

## Installation

```bash
pip install radiens-core
```

## Basic Usage

The `radiens-core` client provides three main entry points:

- `AllegoClient`: For real-time acquisition and control.
- `VidereClient`: For offline analysis of recorded files.
- `CurateClient`: For data curation and conversion.

### Example: Real-time acquisition

```python
from radiens_core import AllegoClient

# Auto-discover and connect
with AllegoClient() as client:
    # Get system status
    status = client.get_status()
    print(f"Streaming: {status.is_streaming}")
    
    # Get stimulation parameters
    params = client.get_stim_params()
    print(f"Configured channels: {len(params)}")
```

## Requirements

- Python 3.12+
- Access to a Radiens server instance (e.g., Allego or Videre)
