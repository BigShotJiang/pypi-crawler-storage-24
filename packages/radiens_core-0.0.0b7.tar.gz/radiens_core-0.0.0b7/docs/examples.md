# Examples

This project includes several tutorial scripts in the `tutorials/` directory.

- [Healthcheck](https://github.com/NeuroNexus/radiens-core-python/blob/main/tutorials/healthcheck_example.py): Simple connectivity test.
- [Stream State](https://github.com/NeuroNexus/radiens-core-python/blob/main/tutorials/stream_state_example.py): Monitoring and controlling streaming state.
- [Record State](https://github.com/NeuroNexus/radiens-core-python/blob/main/tutorials/record_state_example.py): Managing recordings.
- [Stimulation Steps](https://github.com/NeuroNexus/radiens-core-python/blob/main/tutorials/restart_example.py): Running stimulation sequences.
- [Data Curation](https://github.com/NeuroNexus/radiens-core-python/blob/main/tutorials/curate_example.py): Converting and managing recorded data.

## Running Examples Locally

After installing `radiens-core`, you can run the tutorials:

```bash
uv sync  # Install dev dependencies if needed
uv run tutorials/healthcheck_example.py
```
