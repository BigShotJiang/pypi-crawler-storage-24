#!/usr/bin/env python3
"""Example usage of SetStreamState method."""

from time import sleep

from radiens_core import AllegoClient
from radiens_core.models.status import RecordMode, RecordStateRequest, StreamMode, StreamStateRequest


def main() -> None:
    """Demonstrate SetStreamState usage."""
    with AllegoClient() as client:
        # Turn streaming on
        start_request = StreamStateRequest(mode=StreamMode.ON)
        client.set_stream_state(start_request)

        sleep(5)  # Simulate some streaming time

        start_request = RecordStateRequest(mode=RecordMode.ON)
        client.set_record_state(start_request)

        # Check status
        status = client.get_status()
        print(f"Current stream mode: {status.streaming.stream_mode}")

        sleep(5)  # Simulate some streaming time

        stop_request = RecordStateRequest(mode=RecordMode.OFF)
        client.set_record_state(stop_request)

        sleep(5)

        # Turn streaming off
        stop_request = StreamStateRequest(mode=StreamMode.OFF)
        client.set_stream_state(stop_request)


if __name__ == "__main__":
    main()
