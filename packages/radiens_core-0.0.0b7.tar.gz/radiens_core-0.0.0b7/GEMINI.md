# GEMINI.md

This file provides guidance to Gemini Code when working with code in this repository.

**See [CLAUDE.md](./CLAUDE.md)** for comprehensive documentation about this repository's structure, architecture, and development workflows.

The CLAUDE.md file is kept up-to-date as the primary source of documentation.
