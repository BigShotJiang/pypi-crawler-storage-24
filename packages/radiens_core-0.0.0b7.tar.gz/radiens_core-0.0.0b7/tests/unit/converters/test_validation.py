"""Tests for _converters._validation — proto serialization guard."""

from __future__ import annotations

import pytest

from radiens_core._converters._validation import validate_proto
from radiens_core._generated import common_pb2
from radiens_core.exceptions import ConfigurationError


class TestValidateProto:
    def test_valid_message_passes(self) -> None:
        """A fully initialized message should not raise."""
        msg = common_pb2.StandardRequest()
        # StandardRequest has no required fields — always valid
        validate_proto(msg)

    def test_unset_required_field_raises(self) -> None:
        """A proto2 message with unset required fields should raise."""
        # HDSnapshotRequest2 has required fields: dsourceID and tR.fs
        msg = common_pb2.HDSnapshotRequest2()
        # dsourceID is required but not set
        with pytest.raises(ConfigurationError, match="missing required fields"):
            validate_proto(msg)

    def test_partially_initialized_raises(self) -> None:
        """Setting some but not all required fields still raises."""
        msg = common_pb2.HDSnapshotRequest2()
        msg.dsourceID = "test"
        # tR.fs is still unset (required in TimeRange2)
        with pytest.raises(ConfigurationError, match="missing required fields"):
            validate_proto(msg)

    def test_fully_initialized_passes(self) -> None:
        """Setting all required fields should pass."""
        msg = common_pb2.HDSnapshotRequest2()
        msg.dsourceID = ""
        msg.tR.fs = 0.0
        validate_proto(msg)

    def test_error_message_contains_field_names(self) -> None:
        """The error message should list which fields are missing."""
        msg = common_pb2.HDSnapshotRequest2()
        with pytest.raises(ConfigurationError) as exc_info:
            validate_proto(msg)
        error_msg = str(exc_info.value)
        assert "dsourceID" in error_msg
