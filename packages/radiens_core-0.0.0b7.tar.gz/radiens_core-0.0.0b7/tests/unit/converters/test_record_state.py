"""Tests for record state converters."""

from radiens_core._converters._record_state import record_state_request_to_proto
from radiens_core.models.ports import Port
from radiens_core.models.status import RecordMode, RecordStateRequest


def test_record_state_request_to_proto_system_level() -> None:
    """Test conversion of system-level RecordStateRequest to proto."""
    # Test OFF mode (system level - no port specified)
    request_off = RecordStateRequest(mode=RecordMode.OFF)
    proto_off = record_state_request_to_proto(request_off)
    assert proto_off.mode == 0  # R_OFF proto value
    assert not proto_off.HasField("port")  # No port field set

    # Test ON mode (system level - no port specified)
    request_on = RecordStateRequest(mode=RecordMode.ON)
    proto_on = record_state_request_to_proto(request_on)
    assert proto_on.mode == 1  # R_ON proto value
    assert not proto_on.HasField("port")  # No port field set


def test_record_state_request_to_proto_per_port() -> None:
    """Test conversion of per-port RecordStateRequest to proto."""
    # Test with specific port
    request_port_a = RecordStateRequest(mode=RecordMode.ON, port=Port.A)
    proto_port_a = record_state_request_to_proto(request_port_a)
    assert proto_port_a.mode == 1  # R_ON proto value
    assert proto_port_a.HasField("port")  # Port field is set
    assert proto_port_a.port == 0  # Port A proto value

    # Test with different port
    request_port_h = RecordStateRequest(mode=RecordMode.OFF, port=Port.H)
    proto_port_h = record_state_request_to_proto(request_port_h)
    assert proto_port_h.mode == 0  # R_OFF proto value
    assert proto_port_h.HasField("port")  # Port field is set
    assert proto_port_h.port == 7  # Port H proto value
