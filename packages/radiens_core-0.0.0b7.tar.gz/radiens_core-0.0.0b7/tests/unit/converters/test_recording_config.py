"""Tests for recording config converters."""

from radiens_core._converters._recording_config import (
    recording_config_from_proto,
    recording_config_to_proto,
)
from radiens_core._generated import allegoserver_pb2
from radiens_core.models.status import DataRecordingType, RecordingConfig


def test_recording_config_to_proto_continuous() -> None:
    """Test conversion of RecordingConfig to proto (continuous recording)."""
    config = RecordingConfig(
        base_file_name="test_recording",
        base_file_path="/path/to/data",
        datasource_idx=0,
        time_stamp=True,
        split_files_by_port=False,
        force_start_at_tstamp_0=False,
        recording_type=DataRecordingType.CONTINUOUS,
    )

    proto = recording_config_to_proto(config)

    assert proto.baseFileName == "test_recording"
    assert proto.baseFilePath == "/path/to/data"
    assert proto.dataSourceIdx == 0
    assert proto.timeStamp is True
    assert proto.splitFilesByPort is False
    assert proto.forceStartAtTStamp0 is False
    assert proto.recordingType == allegoserver_pb2.continuous


def test_recording_config_to_proto_spikes() -> None:
    """Test conversion of RecordingConfig to proto (spikes only)."""
    config = RecordingConfig(
        base_file_name="spikes_recording",
        base_file_path="/data/spikes",
        datasource_idx=1,
        time_stamp=False,
        split_files_by_port=True,
        force_start_at_tstamp_0=True,
        recording_type=DataRecordingType.SPIKES,
    )

    proto = recording_config_to_proto(config)

    assert proto.baseFileName == "spikes_recording"
    assert proto.baseFilePath == "/data/spikes"
    assert proto.dataSourceIdx == 1
    assert proto.timeStamp is False
    assert proto.splitFilesByPort is True
    assert proto.forceStartAtTStamp0 is True
    assert proto.recordingType == allegoserver_pb2.spikes


def test_recording_config_to_proto_continuous_and_spikes() -> None:
    """Test conversion of RecordingConfig to proto (continuous and spikes)."""
    config = RecordingConfig(
        base_file_name="full_recording",
        base_file_path="/data/full",
        recording_type=DataRecordingType.CONTINUOUS_AND_SPIKES,
    )

    proto = recording_config_to_proto(config)

    assert proto.baseFileName == "full_recording"
    assert proto.baseFilePath == "/data/full"
    assert proto.dataSourceIdx == 0  # Default value
    assert proto.timeStamp is True  # Default value
    assert proto.splitFilesByPort is False  # Default value
    assert proto.forceStartAtTStamp0 is False  # Default value
    assert proto.recordingType == allegoserver_pb2.continuousAndSpikes


def test_recording_config_from_proto_continuous() -> None:
    """Test conversion from proto to RecordingConfig (continuous recording)."""
    proto = allegoserver_pb2.ConfigRecording(
        baseFileName="proto_recording",
        baseFilePath="/proto/path",
        dataSourceIdx=2,
        timeStamp=True,
        splitFilesByPort=False,
        forceStartAtTStamp0=False,
        recordingType=allegoserver_pb2.continuous,
    )

    config = recording_config_from_proto(proto)

    assert config.base_file_name == "proto_recording"
    assert config.base_file_path == "/proto/path"
    assert config.datasource_idx == 2
    assert config.time_stamp is True
    assert config.split_files_by_port is False
    assert config.force_start_at_tstamp_0 is False
    assert config.recording_type == DataRecordingType.CONTINUOUS


def test_recording_config_from_proto_spikes() -> None:
    """Test conversion from proto to RecordingConfig (spikes only)."""
    proto = allegoserver_pb2.ConfigRecording(
        baseFileName="proto_spikes",
        baseFilePath="/proto/spikes",
        dataSourceIdx=3,
        timeStamp=False,
        splitFilesByPort=True,
        forceStartAtTStamp0=True,
        recordingType=allegoserver_pb2.spikes,
    )

    config = recording_config_from_proto(proto)

    assert config.base_file_name == "proto_spikes"
    assert config.base_file_path == "/proto/spikes"
    assert config.datasource_idx == 3
    assert config.time_stamp is False
    assert config.split_files_by_port is True
    assert config.force_start_at_tstamp_0 is True
    assert config.recording_type == DataRecordingType.SPIKES


def test_recording_config_from_proto_continuous_and_spikes() -> None:
    """Test conversion from proto to RecordingConfig (continuous and spikes)."""
    proto = allegoserver_pb2.ConfigRecording(
        baseFileName="proto_full",
        baseFilePath="/proto/full",
        dataSourceIdx=0,
        timeStamp=True,
        splitFilesByPort=False,
        forceStartAtTStamp0=False,
        recordingType=allegoserver_pb2.continuousAndSpikes,
    )

    config = recording_config_from_proto(proto)

    assert config.base_file_name == "proto_full"
    assert config.base_file_path == "/proto/full"
    assert config.datasource_idx == 0
    assert config.time_stamp is True
    assert config.split_files_by_port is False
    assert config.force_start_at_tstamp_0 is False
    assert config.recording_type == DataRecordingType.CONTINUOUS_AND_SPIKES


def test_recording_config_round_trip() -> None:
    """Test round-trip conversion: domain -> proto -> domain."""
    original_config = RecordingConfig(
        base_file_name="round_trip_test",
        base_file_path="/round/trip/path",
        datasource_idx=42,
        time_stamp=False,
        split_files_by_port=True,
        force_start_at_tstamp_0=True,
        recording_type=DataRecordingType.CONTINUOUS_AND_SPIKES,
    )

    # Convert to proto and back
    proto = recording_config_to_proto(original_config)
    converted_config = recording_config_from_proto(proto)

    # Should be identical
    assert converted_config == original_config
