"""Tests for domain enums."""

from radiens_core.models.common import ClientType
from radiens_core.models.dataset import TrsMode
from radiens_core.models.signals import KeyIndex, SignalType


def test_signal_type_values() -> None:
    assert SignalType.AMP == 0  # type: ignore[comparison-overlap]
    assert SignalType.AIN == 1  # type: ignore[comparison-overlap]
    assert SignalType.DIN == 2  # type: ignore[comparison-overlap]
    assert SignalType.DOUT == 3  # type: ignore[comparison-overlap]


def test_trs_mode_values() -> None:
    assert TrsMode.SUBSET == 0  # type: ignore[comparison-overlap]
    assert TrsMode.TO_HEAD == 1  # type: ignore[comparison-overlap]
    assert TrsMode.FROM_HEAD == 2  # type: ignore[comparison-overlap]


def test_key_index_values() -> None:
    assert KeyIndex.NTV == 0  # type: ignore[comparison-overlap]
    assert KeyIndex.DATA == 1  # type: ignore[comparison-overlap]
    assert KeyIndex.SYS == 2  # type: ignore[comparison-overlap]


def test_client_type_values() -> None:
    assert ClientType.ALLEGO == "AllegoClient"  # type: ignore[comparison-overlap]
    assert ClientType.VIDERE == "VidereClient"  # type: ignore[comparison-overlap]
    assert ClientType.CURATE == "CurateClient"  # type: ignore[comparison-overlap]
