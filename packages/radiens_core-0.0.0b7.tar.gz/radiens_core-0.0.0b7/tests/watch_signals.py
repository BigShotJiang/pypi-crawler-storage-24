"""Print signal shapes from the live cache every 500 ms."""

from __future__ import annotations

import time

from radiens_core import AllegoClient
from radiens_core.models.dataset import TimeRangeSpec

LOOKBACK_SEC = 1.0
INTERVAL_SEC = 0.5

with AllegoClient() as client:
    print(f"Polling every {INTERVAL_SEC * 1000:.0f} ms — lookback {LOOKBACK_SEC} s. Ctrl-C to stop.\n")
    while True:
        sigs = client.get_signals(TimeRangeSpec.lookback(LOOKBACK_SEC), signals="all")
        amp   = sigs.amp.shape   if sigs.amp       is not None else None
        ain   = sigs.gpio_ain.shape if sigs.gpio_ain is not None else None
        din   = sigs.gpio_din.shape if sigs.gpio_din is not None else None
        dout  = sigs.gpio_dout.shape if sigs.gpio_dout is not None else None
        print(f"amp={amp}  ain={ain}  din={din}  dout={dout}")
        time.sleep(INTERVAL_SEC)
