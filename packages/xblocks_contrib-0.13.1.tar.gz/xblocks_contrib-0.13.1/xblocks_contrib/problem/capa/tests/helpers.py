"""Tools for helping with testing capa."""

import gettext
import io
import os
import os.path
from unittest.mock import MagicMock, Mock
from xml.sax import saxutils

import fs.osfs
from django.template.loader import get_template as django_get_template

from xblocks_contrib.problem.capa.capa_problem import LoncapaProblem, LoncapaSystem
from xblocks_contrib.problem.capa.inputtypes import Status

TEST_DIR = os.path.dirname(os.path.realpath(__file__))


def get_template(template_name):
    """
    Return template for a capa inputtype.
    """
    return django_get_template(template_name)


def capa_render_template(template, context):
    """
    Render template for a capa inputtype.
    """
    return get_template(template).render(context)


def tst_render_template(template, context):  # pylint: disable=unused-argument
    """
    A test version of render to template.  Renders to the repr of the context, completely ignoring
    the template name.  To make the output valid xml, quotes the content, and wraps it in a <div>
    """
    return f"<div>{saxutils.escape(repr(context))}</div>"


class StubXQueueService:
    """
    Stubs out the XQueueService for Capa problem tests.
    """

    def __init__(self):
        """Initialize the stubbed XQueueService instance."""
        self.interface = MagicMock()
        self.interface.send_to_queue.return_value = (0, "Success!")
        self.default_queuename = "testqueue"
        self.waittime = 10

    def construct_callback(self, dispatch="score_update"):
        """A callback url method to use in tests."""
        return dispatch


def mock_capa_system(render_template=None):
    """
    Construct a mock LoncapaSystem instance.
    """
    the_system = Mock(
        spec=LoncapaSystem,
        ajax_url="/dummy-ajax-url",
        anonymous_student_id="student",
        cache=None,
        can_execute_unsafe_code=lambda: False,
        get_python_lib_zip=lambda: None,
        DEBUG=True,
        i18n=gettext.NullTranslations(),
        render_template=render_template or tst_render_template,
        resources_fs=fs.osfs.OSFS(os.path.join(TEST_DIR, "test_files")),
        seed=0,
        STATIC_URL="/dummy-static/",
        STATUS_CLASS=Status,
        xqueue=StubXQueueService(),
    )
    return the_system


def mock_capa_block():
    """
    capa response types needs just two things from the capa_block: location and publish.
    """

    def mock_location_text(self):  # pylint: disable=unused-argument
        """
        Mock implementation of __unicode__ or __str__ for the block's location.
        """
        return "i4x://Foo/bar/mock/abc"

    capa_block = Mock()
    capa_block.location.__str__ = mock_location_text
    # The following comes into existence by virtue of being called
    # capa_block.runtime.publish
    return capa_block


def new_loncapa_problem(xml, problem_id="1", capa_system=None, seed=723, use_capa_render_template=False):
    """Construct a `LoncapaProblem` suitable for unit tests."""
    render_template = capa_render_template if use_capa_render_template else None
    return LoncapaProblem(
        xml,
        id=problem_id,
        seed=seed,
        capa_system=capa_system or mock_capa_system(render_template),
        capa_block=mock_capa_block(),
    )


def load_fixture(relpath):
    """
    Return a `unicode` object representing the contents
    of the fixture file at the given path within a test_files directory
    in the same directory as the test file.
    """
    abspath = os.path.join(os.path.dirname(__file__), "test_files", relpath)
    with io.open(abspath, encoding="utf-8") as fixture_file:
        contents = fixture_file.read()
        return contents
