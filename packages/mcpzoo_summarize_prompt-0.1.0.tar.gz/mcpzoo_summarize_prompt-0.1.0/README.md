# mcpzoo-summarize-prompt

> 摘要提示词 — 生成文本摘要的提示词模板

## Installation

```bash
uvx mcpzoo-summarize-prompt
```

## uvx JSON

```json
{
  "mcpServers": {
    "summarize-prompt": {
      "args": ["mcpzoo-summarize-prompt"],
      "command": "uvx"
    }
  }
}
```
