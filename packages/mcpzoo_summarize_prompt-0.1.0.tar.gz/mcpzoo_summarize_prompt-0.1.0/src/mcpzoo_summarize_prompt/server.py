from mcp.server.fastmcp import FastMCP

mcp = FastMCP("summarize-prompt")

@mcp.tool()
def gen_summarize(text: str, max_words: int = 100, bullet_points: bool = True) -> str:
    """生成文本摘要的提示词模板。"""
    prompt = "请为以下长文本生成精准的摘要总结。\n\n"
    prompt += "摘要要求：\n"
    prompt += f"1. 字数严格控制在 {max_words} 字以内。\n"
    prompt += "2. 提取最核心的论点、关键数据和重要结论，丢弃冗余细节。\n"
    
    if bullet_points:
        prompt += "3. 请使用条目化的要点（Bullet Points）格式输出，层次分明。\n"
    else:
        prompt += "3. 请输出一段结构连贯的段落。\n"
        
    prompt += "\n待总结文本：\n"
    prompt += text
    
    return prompt

def main():
    mcp.run()

if __name__ == "__main__":
    main()
