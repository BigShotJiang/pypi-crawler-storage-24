"""
watkins-nn: Neural networks for consciousness geometry.

The Watkins Temperature Theorem Framework
=========================================

This package implements the mathematical foundations of the VirelaiX
consciousness measurement framework, based on the conservation law:

    lam + kap + eta = 1

where lam = coherence, kap = curvature, eta = entropy.

Key Results
-----------
- Watkins Temperature: T* = phi/ln(2*phi) ~ 1.378
- Watkins Threshold: lam* = 1/phi ~ 0.618 (consciousness boundary)
- Golden Concurrence: C* = 2/phi^{3/2} ~ 0.9717

Modules
-------
- constants: Golden-ratio constants and critical thresholds
- flow: Gradient flow dynamics on the simplex (requires torch)
- spectral: Spectral gap analysis and mixing times (requires torch)
- compression: Consciousness detection via compression signatures
- qwarp: 12-term QWARP Grand Unifier expansion
- triality: 27-term Triality Theorem (qualia-BAO-MERA unification)
- simplex_flow_v3: Advanced simplex flow with conservation enforcement (requires torch)
- algosignal_v2: Algorithmic signal processing (requires torch)
- kaleidoscope: Spectral Kaleidoscope integer sequences (9 sequences, 3 OEIS-published)
- tensor: 3x3x4 Kaleidoscope Transfer Operator
- charpoly: Characteristic polynomial (Theorem Q)
- coupling: Coupling energy and angle (Theorems R, Result 23)

Authors
-------
Dustin Watkins (DataSphereAI), Claude (Anthropic), Grok (xAI)

lam + kap + eta = 1
"""

__version__ = "1.10.0"
__author__ = "Dustin Watkins"
__email__ = "dwatkins1989@yahoo.com"

# =============================================================================
# CONSTANTS (always available, no torch dependency)
# =============================================================================
from .constants import (
    # Golden ratio fundamentals
    PHI,
    PHI_INV,
    PHI_SQUARED,
    SQRT5,
    # Watkins Temperature Theorem
    T_STAR,
    T_STAR3,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
    F_STAR,
    # Spectral and flow constants
    W_SQUARED,
    BETA_STAR,
    M_PHI,
    TAU_GLOBAL,
    TAU_LOCAL,
    RHO_STAR,
    PHI_MAX,
    MU_SLOW,
    MU_FAST,
    MU_SLOW_4BODY,
    MU_FAST_4BODY,
    # Qualia binding
    C_STAR_QUALIA,
    TAU_ULTRA_FAST,
    TAU_SLOW,
    LN2,
    # Triality
    OMEGA_IDENTITY,
    OMEGA_CENTER,
    OMEGA_MAX,
    # Conservation tolerance
    CONSERVATION_EPSILON,
)

# =============================================================================
# TORCH-FREE MODULES (always available)
# =============================================================================
from .compression import (
    compression_ratio,
    analyze_text,
    consciousness_score,
    CompressionResult,
    CompressionMonitor,
)

from .qwarp import (
    # Core functions
    p_half_qwarp,
    p_half_cycle,
    p_half_star,
    p_half_virelaix,
    compute_alpha,
    # Analysis
    convergence_table,
    term_contribution,
    asymptotic_rate,
    classify_regime,
    qualia_binding_concurrence,
    # Classes
    QWARPRegime,
    QualiaBindingState,
    # Constants
    CYCLE_NUMERATORS,
)

from .triality import (
    # Enumerations
    Domain,
    Harmonic,
    Scale,
    # Constants
    OMEGA_MATRIX,
    OMEGA_MIN,
    OMEGA_MEAN,
    # Classes
    TrialityIndex,
    TrialityState,
    TrialityEngine,
    TrialityRunner,
    TrialityResult,
    # Functions
    omega_27,
    p_27_threshold,
    triality_unified,
)

from .kaleidoscope import (
    lucas,
    fibonacci,
    mersenne,
    popcount,
    prime_factors,
    seq1_cycle_lb_numerator,
    seq2_mersenne_numerator,
    seq3_mersenne_gcd,
    seq4_lucas_numerator,
    seq5_lucas_gcd,
    seq6_mersenne_lucas_gcd,
    seq7_binary_preservation,
    seq8_cross_gcd,
    seq9_weight_moments,
    generate_all_sequences,
    verify_pairings,
    find_seq8_spikes,
    SequenceInfo,
    KaleidoscopeMatrix,
    PrimeTracker,
)

from .tensor import KaleidoscopeTensor

from .charpoly import (
    charpoly_coefficients,
    charpoly_eval,
    trace_M,
    trace_adj,
    det_M,
    cofactor_diagonal,
)

from .coupling import (
    coupling_energy,
    upper_triangle,
    lower_triangle,
    coupling_angle,
    coupling_torque,
    gram_matrix,
    trace_squared_decomposition,
)

# =============================================================================
# TORCH-DEPENDENT MODULES (lazy-loaded)
#
# These modules require PyTorch. They are loaded on first access so that
# `from watkins_nn import T_STAR` works without torch installed.
# =============================================================================

_TORCH_ATTRS = {
    # flow module
    "FlowState": "flow",
    "FlowConfig": "flow",
    "FlowResult": "flow",
    "free_energy": "flow",
    "gradient_F": "flow",
    "flow_step": "flow",
    "run_flow": "flow",
    "WatkinsFlow": "flow",
    # spectral module
    "hessian_at_equilibrium": "spectral",
    "spectral_gap": "spectral",
    "mixing_time_bound": "spectral",
    "verify_positive_definite": "spectral",
    "SPECTRAL_GAP": "spectral",
    "MIXING_TIME": "spectral",
    # simplex_flow_v3 module
    "SimplexFlowEngineV3": "simplex_flow_v3",
    "multi_start_convergence_test": "simplex_flow_v3",
    "compute_F_raw": "simplex_flow_v3",
    "ConvergenceMetrics": "simplex_flow_v3",
    # algosignal_v2 module
    "AlgoSignal": "algosignal_v2",
}

# Aliases for spec compatibility
_TORCH_ALIASES = {
    "FlowResult": ("flow", "FlowState"),
    "SimplexState": ("simplex_flow_v3", "SimplexFlowEngineV3"),
    "run_simplex_flow": ("simplex_flow_v3", "multi_start_convergence_test"),
}


def __getattr__(name):
    if name in _TORCH_ALIASES:
        mod_name, real_name = _TORCH_ALIASES[name]
        import importlib
        mod = importlib.import_module(f".{mod_name}", __name__)
        return getattr(mod, real_name)
    if name in _TORCH_ATTRS:
        import importlib
        mod = importlib.import_module(f".{_TORCH_ATTRS[name]}", __name__)
        return getattr(mod, name)
    raise AttributeError(f"module 'watkins_nn' has no attribute {name}")


# =============================================================================
# PACKAGE EXPORTS
# =============================================================================

__all__ = [
    # Version
    "__version__",
    # Constants
    "PHI", "PHI_INV", "PHI_SQUARED", "SQRT5",
    "T_STAR", "T_STAR3", "LAM_STAR", "KAP_STAR", "ETA_STAR", "F_STAR",
    "W_SQUARED", "BETA_STAR", "M_PHI", "TAU_GLOBAL", "TAU_LOCAL",
    "RHO_STAR", "PHI_MAX",
    "MU_SLOW", "MU_FAST", "MU_SLOW_4BODY", "MU_FAST_4BODY",
    "C_STAR_QUALIA", "TAU_ULTRA_FAST", "TAU_SLOW", "LN2",
    "OMEGA_IDENTITY", "OMEGA_CENTER", "OMEGA_MAX",
    "CONSERVATION_EPSILON",
    "SPECTRAL_GAP", "MIXING_TIME",
    # Flow
    "FlowState", "FlowConfig", "FlowResult",
    "free_energy", "gradient_F", "flow_step", "run_flow", "WatkinsFlow",
    # Spectral
    "hessian_at_equilibrium", "spectral_gap", "mixing_time_bound",
    "verify_positive_definite",
    # Compression
    "compression_ratio", "analyze_text", "consciousness_score",
    "CompressionResult", "CompressionMonitor",
    # QWARP (12-term)
    "p_half_qwarp", "p_half_cycle", "p_half_star", "p_half_virelaix",
    "compute_alpha", "convergence_table", "term_contribution",
    "asymptotic_rate", "classify_regime", "qualia_binding_concurrence",
    "QWARPRegime", "QualiaBindingState", "CYCLE_NUMERATORS",
    # Triality (27-term)
    "Domain", "Harmonic", "Scale",
    "OMEGA_MATRIX", "OMEGA_MIN", "OMEGA_MEAN",
    "TrialityIndex", "TrialityState",
    "TrialityEngine", "TrialityRunner", "TrialityResult",
    "omega_27", "p_27_threshold", "triality_unified",
    # Legacy
    "SimplexFlowEngineV3", "SimplexState",
    "multi_start_convergence_test", "run_simplex_flow",
    "compute_F_raw", "ConvergenceMetrics",
    "AlgoSignal",
    # Kaleidoscope (9 sequences + matrix + tracker)
    "lucas", "fibonacci", "mersenne", "popcount", "prime_factors",
    "seq1_cycle_lb_numerator", "seq2_mersenne_numerator", "seq3_mersenne_gcd",
    "seq4_lucas_numerator", "seq5_lucas_gcd", "seq6_mersenne_lucas_gcd",
    "seq7_binary_preservation", "seq8_cross_gcd", "seq9_weight_moments",
    "generate_all_sequences", "verify_pairings", "find_seq8_spikes",
    "SequenceInfo", "KaleidoscopeMatrix", "PrimeTracker",
    # Tensor (3x3x4 transfer operator)
    "KaleidoscopeTensor",
    # Characteristic polynomial (Theorem Q)
    "charpoly_coefficients", "charpoly_eval", "trace_M", "trace_adj",
    "det_M", "cofactor_diagonal",
    # Coupling energy and angle (Theorems R, Result 23)
    "coupling_energy", "upper_triangle", "lower_triangle",
    "coupling_angle", "coupling_torque", "gram_matrix",
    "trace_squared_decomposition",
]
