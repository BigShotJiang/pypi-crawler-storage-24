"""Load and format database schema for prompt context."""

from pathlib import Path
from typing import Optional

import yaml


def load_schema(schema_file: Optional[str]) -> str:
    """Return a formatted schema string, or empty string if no schema provided."""
    if not schema_file:
        return ""

    path = Path(schema_file)
    if not path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_file}")

    with open(path) as f:
        schema = yaml.safe_load(f)

    return _format_schema(schema)


def _format_schema(schema: dict) -> str:
    """Convert schema dict to a SQL-style CREATE TABLE representation."""
    lines = []

    tables = schema.get("tables", {})
    for table_name, table_def in tables.items():
        columns = table_def.get("columns", {})
        col_lines = []
        for col_name, col_type in columns.items():
            col_lines.append(f"  {col_name} {col_type}")

        lines.append(f"CREATE TABLE {table_name} (")
        lines.append(",\n".join(col_lines))
        lines.append(");\n")

    return "\n".join(lines)
