"""sqlcopilot CLI entry point."""

from enum import Enum
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

from sqlcopilot import __version__
from sqlcopilot.ai import convert_to_sql, explain_sql, optimize_sql
from sqlcopilot.config import AppConfig, DatabaseConfig, OpenAIConfig, load_config, save_config
from sqlcopilot.schema_loader import load_schema

app = typer.Typer(
    name="sqlcopilot",
    help="AI-powered SQL assistant for Postgres and Snowflake.",
    add_completion=False,
)
console = Console()


class Dialect(str, Enum):
    postgres = "postgres"
    snowflake = "snowflake"


def _get_config(
    dialect: Optional[Dialect],
    schema_file: Optional[Path],
    model: Optional[str],
) -> tuple[AppConfig, str]:
    config = load_config()

    if dialect:
        config.database.dialect = dialect.value
    if schema_file:
        config.database.schema_file = str(schema_file)
    if model:
        config.openai.model = model

    schema = load_schema(config.database.schema_file)
    return config, schema


def _print_sql(sql: str, title: str = "Generated SQL") -> None:
    syntax = Syntax(sql, "sql", theme="monokai", word_wrap=True)
    console.print(Panel(syntax, title=title, border_style="green"))


def _print_text(text: str, title: str = "Result") -> None:
    console.print(Panel(text, title=title, border_style="cyan"))


# ── Commands ──────────────────────────────────────────────────────────────────

@app.command("convert")
def convert(
    question: str = typer.Argument(..., help="Natural language question to convert to SQL"),
    dialect: Optional[Dialect] = typer.Option(None, "--dialect", "-d", help="SQL dialect"),
    schema_file: Optional[Path] = typer.Option(None, "--schema", "-s", help="Path to schema YAML"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="OpenAI model override"),
) -> None:
    """Convert a natural language question to SQL."""
    config, schema = _get_config(dialect, schema_file, model)

    with console.status("[bold green]Generating SQL..."):
        try:
            sql = convert_to_sql(question, config, schema)
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)

    _print_sql(sql, title=f"SQL ({config.database.dialect})")


@app.command("explain")
def explain(
    query: str = typer.Argument(..., help="SQL query to explain"),
    dialect: Optional[Dialect] = typer.Option(None, "--dialect", "-d", help="SQL dialect"),
    schema_file: Optional[Path] = typer.Option(None, "--schema", "-s", help="Path to schema YAML"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="OpenAI model override"),
) -> None:
    """Explain what a SQL query does in plain English."""
    config, schema = _get_config(dialect, schema_file, model)

    with console.status("[bold cyan]Explaining query..."):
        try:
            explanation = explain_sql(query, config, schema)
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)

    _print_text(explanation, title="Explanation")


@app.command("optimize")
def optimize(
    query: str = typer.Argument(..., help="SQL query to optimize"),
    dialect: Optional[Dialect] = typer.Option(None, "--dialect", "-d", help="SQL dialect"),
    schema_file: Optional[Path] = typer.Option(None, "--schema", "-s", help="Path to schema YAML"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="OpenAI model override"),
) -> None:
    """Optimize a SQL query for performance."""
    config, schema = _get_config(dialect, schema_file, model)

    with console.status("[bold yellow]Optimizing query..."):
        try:
            result = optimize_sql(query, config, schema)
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)

    _print_text(result, title=f"Optimized SQL ({config.database.dialect})")


@app.command("configure")
def configure(
    api_key: Optional[str] = typer.Option(None, "--api-key", help="OpenAI API key"),
    dialect: Optional[Dialect] = typer.Option(None, "--dialect", "-d", help="Default SQL dialect"),
    schema_file: Optional[Path] = typer.Option(None, "--schema", "-s", help="Default schema file"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Default OpenAI model"),
) -> None:
    """Persist default configuration to ~/.sqlcopilot/config.yaml."""
    config = load_config()

    if api_key:
        config.openai.api_key = api_key
    if dialect:
        config.database.dialect = dialect.value
    if schema_file:
        config.database.schema_file = str(schema_file)
    if model:
        config.openai.model = model

    save_config(config)
    console.print("[green]Configuration saved to ~/.sqlcopilot/config.yaml[/green]")


@app.command("version")
def version() -> None:
    """Show sqlcopilot version."""
    console.print(f"sqlcopilot {__version__}")


def main() -> None:
    app()
