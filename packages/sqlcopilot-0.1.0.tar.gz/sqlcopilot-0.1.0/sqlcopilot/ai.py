"""OpenAI interactions for SQL generation, explanation, and optimization."""

from openai import OpenAI

from sqlcopilot.config import AppConfig


DIALECT_NOTES = {
    "postgres": "Use PostgreSQL syntax. Prefer CTEs over subqueries. Use ILIKE for case-insensitive matching.",
    "snowflake": (
        "Use Snowflake SQL syntax. Use QUALIFY for window function filtering. "
        "Prefer FLATTEN for semi-structured data. Use ZEROIFNULL/NULLIFZERO where appropriate."
    ),
}


def _client(config: AppConfig) -> OpenAI:
    if not config.openai.api_key:
        raise ValueError(
            "OpenAI API key not set. Export OPENAI_API_KEY or add it to ~/.sqlcopilot/config.yaml."
        )
    return OpenAI(api_key=config.openai.api_key)


def _dialect_note(dialect: str) -> str:
    return DIALECT_NOTES.get(dialect.lower(), f"Use {dialect} SQL syntax.")


def _schema_section(schema: str) -> str:
    if not schema:
        return ""
    return f"\n\nDatabase schema:\n```sql\n{schema}\n```"


def convert_to_sql(question: str, config: AppConfig, schema: str = "") -> str:
    """Convert a natural language question to a SQL query."""
    system_prompt = (
        f"You are an expert SQL engineer. {_dialect_note(config.database.dialect)}\n"
        "Return ONLY the SQL query with no explanation, no markdown fences, no commentary."
        f"{_schema_section(schema)}"
    )

    client = _client(config)
    response = client.chat.completions.create(
        model=config.openai.model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question},
        ],
        temperature=0,
    )
    return response.choices[0].message.content.strip()


def explain_sql(query: str, config: AppConfig, schema: str = "") -> str:
    """Explain what a SQL query does in plain English."""
    system_prompt = (
        f"You are an expert SQL engineer familiar with {config.database.dialect}. "
        "Explain the following SQL query in clear, concise plain English. "
        "Describe what each clause does and what the query returns overall."
        f"{_schema_section(schema)}"
    )

    client = _client(config)
    response = client.chat.completions.create(
        model=config.openai.model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query},
        ],
        temperature=0,
    )
    return response.choices[0].message.content.strip()


def optimize_sql(query: str, config: AppConfig, schema: str = "") -> str:
    """Suggest and return an optimized version of the given SQL query."""
    system_prompt = (
        f"You are an expert SQL performance engineer familiar with {config.database.dialect}. "
        "Optimize the following SQL query for performance. "
        "Return the optimized query first, then a brief bulleted list of changes made and why."
        f"{_schema_section(schema)}"
    )

    client = _client(config)
    response = client.chat.completions.create(
        model=config.openai.model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query},
        ],
        temperature=0,
    )
    return response.choices[0].message.content.strip()
