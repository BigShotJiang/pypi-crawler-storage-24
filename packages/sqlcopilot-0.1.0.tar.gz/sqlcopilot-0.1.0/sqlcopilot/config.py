"""Configuration management for sqlcopilot."""

import os
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field


CONFIG_PATH = Path.home() / ".sqlcopilot" / "config.yaml"


class DatabaseConfig(BaseModel):
    dialect: str = Field(default="postgres", description="postgres or snowflake")
    schema_file: Optional[str] = Field(default=None, description="Path to schema YAML file")


class OpenAIConfig(BaseModel):
    api_key: Optional[str] = Field(default=None)
    model: str = Field(default="gpt-4o")


class AppConfig(BaseModel):
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)


def load_config(config_path: Optional[Path] = None) -> AppConfig:
    path = config_path or CONFIG_PATH

    if path.exists():
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        config = AppConfig(**data)
    else:
        config = AppConfig()

    # Allow environment variable overrides
    if not config.openai.api_key:
        config.openai.api_key = os.getenv("OPENAI_API_KEY")

    return config


def save_config(config: AppConfig, config_path: Optional[Path] = None) -> None:
    path = config_path or CONFIG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        yaml.dump(config.model_dump(), f, default_flow_style=False)
