"""Tests for CLI commands using Typer's test client."""

from unittest.mock import patch

from typer.testing import CliRunner

from sqlcopilot.cli import app

runner = CliRunner()


def test_version():
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert "sqlcopilot" in result.output


@patch("sqlcopilot.cli.convert_to_sql", return_value="SELECT * FROM users;")
@patch("sqlcopilot.cli.load_config")
def test_convert_command(mock_cfg, mock_convert):
    from sqlcopilot.config import AppConfig, DatabaseConfig, OpenAIConfig
    mock_cfg.return_value = AppConfig(
        openai=OpenAIConfig(api_key="test"),
        database=DatabaseConfig(dialect="postgres"),
    )
    result = runner.invoke(app, ["convert", "show all users"])
    assert result.exit_code == 0
    mock_convert.assert_called_once()


@patch("sqlcopilot.cli.explain_sql", return_value="This selects all users.")
@patch("sqlcopilot.cli.load_config")
def test_explain_command(mock_cfg, mock_explain):
    from sqlcopilot.config import AppConfig, DatabaseConfig, OpenAIConfig
    mock_cfg.return_value = AppConfig(
        openai=OpenAIConfig(api_key="test"),
        database=DatabaseConfig(dialect="postgres"),
    )
    result = runner.invoke(app, ["explain", "SELECT * FROM users;"])
    assert result.exit_code == 0
    mock_explain.assert_called_once()


@patch("sqlcopilot.cli.optimize_sql", return_value="SELECT id FROM users;\n- Removed *")
@patch("sqlcopilot.cli.load_config")
def test_optimize_command(mock_cfg, mock_optimize):
    from sqlcopilot.config import AppConfig, DatabaseConfig, OpenAIConfig
    mock_cfg.return_value = AppConfig(
        openai=OpenAIConfig(api_key="test"),
        database=DatabaseConfig(dialect="postgres"),
    )
    result = runner.invoke(app, ["optimize", "SELECT * FROM users;"])
    assert result.exit_code == 0
    mock_optimize.assert_called_once()
