"""Tests for schema_loader."""

import tempfile
from pathlib import Path

import pytest
import yaml

from sqlcopilot.schema_loader import load_schema


def _write_schema(data: dict) -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False)
    yaml.dump(data, f)
    f.close()
    return Path(f.name)


def test_load_schema_no_file():
    assert load_schema(None) == ""


def test_load_schema_missing_file():
    with pytest.raises(FileNotFoundError):
        load_schema("/nonexistent/schema.yaml")


def test_load_schema_formats_tables():
    schema = {
        "tables": {
            "users": {"columns": {"id": "BIGSERIAL PRIMARY KEY", "email": "VARCHAR(255)"}}
        }
    }
    path = _write_schema(schema)
    result = load_schema(str(path))
    assert "CREATE TABLE users" in result
    assert "id BIGSERIAL PRIMARY KEY" in result
    assert "email VARCHAR(255)" in result
    path.unlink()
