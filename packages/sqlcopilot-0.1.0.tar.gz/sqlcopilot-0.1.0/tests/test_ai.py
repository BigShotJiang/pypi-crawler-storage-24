"""Tests for ai.py — all OpenAI calls are mocked."""

from unittest.mock import MagicMock, patch

import pytest

from sqlcopilot.ai import convert_to_sql, explain_sql, optimize_sql
from sqlcopilot.config import AppConfig, DatabaseConfig, OpenAIConfig


@pytest.fixture
def config():
    return AppConfig(
        openai=OpenAIConfig(api_key="test-key", model="gpt-4o"),
        database=DatabaseConfig(dialect="postgres"),
    )


def _mock_response(content: str):
    msg = MagicMock()
    msg.content = content
    choice = MagicMock()
    choice.message = msg
    response = MagicMock()
    response.choices = [choice]
    return response


@patch("sqlcopilot.ai.OpenAI")
def test_convert_to_sql(mock_openai_cls, config):
    mock_client = MagicMock()
    mock_openai_cls.return_value = mock_client
    mock_client.chat.completions.create.return_value = _mock_response("SELECT 1;")

    result = convert_to_sql("get all users", config)
    assert result == "SELECT 1;"
    mock_client.chat.completions.create.assert_called_once()


@patch("sqlcopilot.ai.OpenAI")
def test_explain_sql(mock_openai_cls, config):
    mock_client = MagicMock()
    mock_openai_cls.return_value = mock_client
    mock_client.chat.completions.create.return_value = _mock_response("This query selects all rows.")

    result = explain_sql("SELECT * FROM users;", config)
    assert "selects" in result


@patch("sqlcopilot.ai.OpenAI")
def test_optimize_sql(mock_openai_cls, config):
    mock_client = MagicMock()
    mock_openai_cls.return_value = mock_client
    mock_client.chat.completions.create.return_value = _mock_response("SELECT id FROM users;\n- Added index hint")

    result = optimize_sql("SELECT * FROM users;", config)
    assert "SELECT id FROM users" in result


def test_convert_no_api_key():
    config = AppConfig(
        openai=OpenAIConfig(api_key=None),
        database=DatabaseConfig(dialect="postgres"),
    )
    with pytest.raises(ValueError, match="OpenAI API key"):
        convert_to_sql("test", config)
