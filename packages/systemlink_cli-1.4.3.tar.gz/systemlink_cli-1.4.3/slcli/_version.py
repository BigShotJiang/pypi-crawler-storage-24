"""Version information for slcli."""

# This file is auto-generated. Do not edit manually.
__version__ = "1.4.3"
