"""Finance Sentiment API — Python SDK"""

__version__ = "1.19.1"

from ._wrapper import StockSentimentClient

__all__ = ["StockSentimentClient", "__version__"]
