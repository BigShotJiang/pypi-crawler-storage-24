"""mspec（Member Spec）- 会员组规范驱动开发工作流 CLI 工具"""

__version__ = "5.1.0"
__author__ = "mspec Team"
__email__ = "team@mspec.io"
