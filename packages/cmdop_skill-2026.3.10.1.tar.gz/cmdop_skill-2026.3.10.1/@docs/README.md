# cmdop-skill SDK — Developer Documentation

Internal reference for debugging and understanding the skill lifecycle.

## Table of Contents

1. [Architecture Overview](./architecture.md) — Full system diagram, components, data flow
2. [Publish Flow](./publish-flow.md) — CLI publish → Django → DB chain
3. [Install Flow](./install-flow.md) — Deep link / CLI install → API → Go loader → validation
4. [Package Environment](./package-env.md) — Python venv, Node modules, PATH enrichment
5. [Skill Format](./skill-format.md) — skill.md structure, frontmatter, validation rules

## Quick Debug Checklist

| Symptom | Likely Cause | Where to Look |
|---------|-------------|----------------|
| "body is empty" on install | `version.skill_md` is empty in DB | [publish-flow.md](./publish-flow.md#skill_md-storage) |
| "pip install failed" | PATH missing homebrew/local dirs | [package-env.md](./package-env.md#path-enrichment) |
| "Python not found" | GUI app minimal PATH | [package-env.md](./package-env.md#path-enrichment) |
| Skill installs but doesn't run | Missing runtime deps (tomli, etc.) | [package-env.md](./package-env.md#dependency-resolution) |
| Validation errors after install | Frontmatter parse failure | [skill-format.md](./skill-format.md#frontmatter-parsing) |
| "not logged in" on install | Auth token missing/expired | [install-flow.md](./install-flow.md#authentication) |
