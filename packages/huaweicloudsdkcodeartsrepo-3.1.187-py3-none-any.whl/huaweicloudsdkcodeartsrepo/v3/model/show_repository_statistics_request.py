# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowRepositoryStatisticsRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'repository_id': 'int',
        'body': 'ShowRepositoryStatisticsRequestBody'
    }

    attribute_map = {
        'repository_id': 'repository_id',
        'body': 'body'
    }

    def __init__(self, repository_id=None, body=None):
        r"""ShowRepositoryStatisticsRequest

        The model defined in huaweicloud sdk

        :param repository_id: 仓库的主键id
        :type repository_id: int
        :param body: Body of the ShowRepositoryStatisticsRequest
        :type body: :class:`huaweicloudsdkcodeartsrepo.v3.ShowRepositoryStatisticsRequestBody`
        """
        
        

        self._repository_id = None
        self._body = None
        self.discriminator = None

        self.repository_id = repository_id
        if body is not None:
            self.body = body

    @property
    def repository_id(self):
        r"""Gets the repository_id of this ShowRepositoryStatisticsRequest.

        仓库的主键id

        :return: The repository_id of this ShowRepositoryStatisticsRequest.
        :rtype: int
        """
        return self._repository_id

    @repository_id.setter
    def repository_id(self, repository_id):
        r"""Sets the repository_id of this ShowRepositoryStatisticsRequest.

        仓库的主键id

        :param repository_id: The repository_id of this ShowRepositoryStatisticsRequest.
        :type repository_id: int
        """
        self._repository_id = repository_id

    @property
    def body(self):
        r"""Gets the body of this ShowRepositoryStatisticsRequest.

        :return: The body of this ShowRepositoryStatisticsRequest.
        :rtype: :class:`huaweicloudsdkcodeartsrepo.v3.ShowRepositoryStatisticsRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ShowRepositoryStatisticsRequest.

        :param body: The body of this ShowRepositoryStatisticsRequest.
        :type body: :class:`huaweicloudsdkcodeartsrepo.v3.ShowRepositoryStatisticsRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowRepositoryStatisticsRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
