# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListFilesByQueryRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'repo_id': 'int',
        'file_path': 'str',
        'ref': 'str'
    }

    attribute_map = {
        'repo_id': 'repo_id',
        'file_path': 'file_path',
        'ref': 'ref'
    }

    def __init__(self, repo_id=None, file_path=None, ref=None):
        r"""ListFilesByQueryRequest

        The model defined in huaweicloud sdk

        :param repo_id: 仓库短id
        :type repo_id: int
        :param file_path: 文件的完整路径。
        :type file_path: str
        :param ref: commit id，仓库的branch名或tag名
        :type ref: str
        """
        
        

        self._repo_id = None
        self._file_path = None
        self._ref = None
        self.discriminator = None

        self.repo_id = repo_id
        self.file_path = file_path
        self.ref = ref

    @property
    def repo_id(self):
        r"""Gets the repo_id of this ListFilesByQueryRequest.

        仓库短id

        :return: The repo_id of this ListFilesByQueryRequest.
        :rtype: int
        """
        return self._repo_id

    @repo_id.setter
    def repo_id(self, repo_id):
        r"""Sets the repo_id of this ListFilesByQueryRequest.

        仓库短id

        :param repo_id: The repo_id of this ListFilesByQueryRequest.
        :type repo_id: int
        """
        self._repo_id = repo_id

    @property
    def file_path(self):
        r"""Gets the file_path of this ListFilesByQueryRequest.

        文件的完整路径。

        :return: The file_path of this ListFilesByQueryRequest.
        :rtype: str
        """
        return self._file_path

    @file_path.setter
    def file_path(self, file_path):
        r"""Sets the file_path of this ListFilesByQueryRequest.

        文件的完整路径。

        :param file_path: The file_path of this ListFilesByQueryRequest.
        :type file_path: str
        """
        self._file_path = file_path

    @property
    def ref(self):
        r"""Gets the ref of this ListFilesByQueryRequest.

        commit id，仓库的branch名或tag名

        :return: The ref of this ListFilesByQueryRequest.
        :rtype: str
        """
        return self._ref

    @ref.setter
    def ref(self, ref):
        r"""Sets the ref of this ListFilesByQueryRequest.

        commit id，仓库的branch名或tag名

        :param ref: The ref of this ListFilesByQueryRequest.
        :type ref: str
        """
        self._ref = ref

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListFilesByQueryRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
