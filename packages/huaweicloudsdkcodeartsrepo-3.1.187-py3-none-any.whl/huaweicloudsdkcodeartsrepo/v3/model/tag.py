# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class Tag:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'is_double_name': 'bool',
        'name': 'str'
    }

    attribute_map = {
        'is_double_name': 'is_double_name',
        'name': 'name'
    }

    def __init__(self, is_double_name=None, name=None):
        r"""Tag

        The model defined in huaweicloud sdk

        :param is_double_name: 是否与分支重名
        :type is_double_name: bool
        :param name: 标签名
        :type name: str
        """
        
        

        self._is_double_name = None
        self._name = None
        self.discriminator = None

        if is_double_name is not None:
            self.is_double_name = is_double_name
        if name is not None:
            self.name = name

    @property
    def is_double_name(self):
        r"""Gets the is_double_name of this Tag.

        是否与分支重名

        :return: The is_double_name of this Tag.
        :rtype: bool
        """
        return self._is_double_name

    @is_double_name.setter
    def is_double_name(self, is_double_name):
        r"""Sets the is_double_name of this Tag.

        是否与分支重名

        :param is_double_name: The is_double_name of this Tag.
        :type is_double_name: bool
        """
        self._is_double_name = is_double_name

    @property
    def name(self):
        r"""Gets the name of this Tag.

        标签名

        :return: The name of this Tag.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this Tag.

        标签名

        :param name: The name of this Tag.
        :type name: str
        """
        self._name = name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Tag):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
