# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class GroupPermissionsDto:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'project_id': 'str',
        'group_name': 'str',
        'group_id': 'str'
    }

    attribute_map = {
        'project_id': 'project_id',
        'group_name': 'group_name',
        'group_id': 'group_id'
    }

    def __init__(self, project_id=None, group_name=None, group_id=None):
        r"""GroupPermissionsDto

        The model defined in huaweicloud sdk

        :param project_id: **参数解释：** 项目的32位uuid，项目唯一标识，通过[[查询项目列表](https://support.huaweicloud.com/api-projectman/ListProjectsV4.html)](tag:hws)[[查询项目列表](https://support.huaweicloud.com/intl/en-us/api-projectman/ListProjectsV4.html)](tag:hws_hk)[[查询项目列表](https://support.huaweicloud.com/eu/api-projectman/ListProjectsV4.html)](tag:hws_eu)[查询项目列表](tag:hcs,hcs_sm)接口查询项目列表获取。 **取值范围：** 字符串长度32。
        :type project_id: str
        :param group_name: **参数解释：** 代码组名称。 **取值范围：** 字符串长度不少于1，不超过1000。
        :type group_name: str
        :param group_id: **参数解释：** **参数解释：** 代码组id，代码组首页，Group ID后的数字Id
        :type group_id: str
        """
        
        

        self._project_id = None
        self._group_name = None
        self._group_id = None
        self.discriminator = None

        if project_id is not None:
            self.project_id = project_id
        if group_name is not None:
            self.group_name = group_name
        if group_id is not None:
            self.group_id = group_id

    @property
    def project_id(self):
        r"""Gets the project_id of this GroupPermissionsDto.

        **参数解释：** 项目的32位uuid，项目唯一标识，通过[[查询项目列表](https://support.huaweicloud.com/api-projectman/ListProjectsV4.html)](tag:hws)[[查询项目列表](https://support.huaweicloud.com/intl/en-us/api-projectman/ListProjectsV4.html)](tag:hws_hk)[[查询项目列表](https://support.huaweicloud.com/eu/api-projectman/ListProjectsV4.html)](tag:hws_eu)[查询项目列表](tag:hcs,hcs_sm)接口查询项目列表获取。 **取值范围：** 字符串长度32。

        :return: The project_id of this GroupPermissionsDto.
        :rtype: str
        """
        return self._project_id

    @project_id.setter
    def project_id(self, project_id):
        r"""Sets the project_id of this GroupPermissionsDto.

        **参数解释：** 项目的32位uuid，项目唯一标识，通过[[查询项目列表](https://support.huaweicloud.com/api-projectman/ListProjectsV4.html)](tag:hws)[[查询项目列表](https://support.huaweicloud.com/intl/en-us/api-projectman/ListProjectsV4.html)](tag:hws_hk)[[查询项目列表](https://support.huaweicloud.com/eu/api-projectman/ListProjectsV4.html)](tag:hws_eu)[查询项目列表](tag:hcs,hcs_sm)接口查询项目列表获取。 **取值范围：** 字符串长度32。

        :param project_id: The project_id of this GroupPermissionsDto.
        :type project_id: str
        """
        self._project_id = project_id

    @property
    def group_name(self):
        r"""Gets the group_name of this GroupPermissionsDto.

        **参数解释：** 代码组名称。 **取值范围：** 字符串长度不少于1，不超过1000。

        :return: The group_name of this GroupPermissionsDto.
        :rtype: str
        """
        return self._group_name

    @group_name.setter
    def group_name(self, group_name):
        r"""Sets the group_name of this GroupPermissionsDto.

        **参数解释：** 代码组名称。 **取值范围：** 字符串长度不少于1，不超过1000。

        :param group_name: The group_name of this GroupPermissionsDto.
        :type group_name: str
        """
        self._group_name = group_name

    @property
    def group_id(self):
        r"""Gets the group_id of this GroupPermissionsDto.

        **参数解释：** **参数解释：** 代码组id，代码组首页，Group ID后的数字Id

        :return: The group_id of this GroupPermissionsDto.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this GroupPermissionsDto.

        **参数解释：** **参数解释：** 代码组id，代码组首页，Group ID后的数字Id

        :param group_id: The group_id of this GroupPermissionsDto.
        :type group_id: str
        """
        self._group_id = group_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GroupPermissionsDto):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
