# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BasicRoleDto:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'int',
        'name': 'str',
        'related_role_id': 'str',
        'chinese_name': 'str'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'related_role_id': 'related_role_id',
        'chinese_name': 'chinese_name'
    }

    def __init__(self, id=None, name=None, related_role_id=None, chinese_name=None):
        r"""BasicRoleDto

        The model defined in huaweicloud sdk

        :param id: **参数解释：** 角色ID。 **取值范围：** 1-2147483647
        :type id: int
        :param name: **参数解释：** 角色名称。 **取值范围：** 不涉及。
        :type name: str
        :param related_role_id: **参数解释：**  关联角色ID。 **取值范围：** 不涉及。
        :type related_role_id: str
        :param chinese_name: **参数解释：** 角色中文名。 **取值范围：** 不涉及。
        :type chinese_name: str
        """
        
        

        self._id = None
        self._name = None
        self._related_role_id = None
        self._chinese_name = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if name is not None:
            self.name = name
        if related_role_id is not None:
            self.related_role_id = related_role_id
        if chinese_name is not None:
            self.chinese_name = chinese_name

    @property
    def id(self):
        r"""Gets the id of this BasicRoleDto.

        **参数解释：** 角色ID。 **取值范围：** 1-2147483647

        :return: The id of this BasicRoleDto.
        :rtype: int
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this BasicRoleDto.

        **参数解释：** 角色ID。 **取值范围：** 1-2147483647

        :param id: The id of this BasicRoleDto.
        :type id: int
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this BasicRoleDto.

        **参数解释：** 角色名称。 **取值范围：** 不涉及。

        :return: The name of this BasicRoleDto.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this BasicRoleDto.

        **参数解释：** 角色名称。 **取值范围：** 不涉及。

        :param name: The name of this BasicRoleDto.
        :type name: str
        """
        self._name = name

    @property
    def related_role_id(self):
        r"""Gets the related_role_id of this BasicRoleDto.

        **参数解释：**  关联角色ID。 **取值范围：** 不涉及。

        :return: The related_role_id of this BasicRoleDto.
        :rtype: str
        """
        return self._related_role_id

    @related_role_id.setter
    def related_role_id(self, related_role_id):
        r"""Sets the related_role_id of this BasicRoleDto.

        **参数解释：**  关联角色ID。 **取值范围：** 不涉及。

        :param related_role_id: The related_role_id of this BasicRoleDto.
        :type related_role_id: str
        """
        self._related_role_id = related_role_id

    @property
    def chinese_name(self):
        r"""Gets the chinese_name of this BasicRoleDto.

        **参数解释：** 角色中文名。 **取值范围：** 不涉及。

        :return: The chinese_name of this BasicRoleDto.
        :rtype: str
        """
        return self._chinese_name

    @chinese_name.setter
    def chinese_name(self, chinese_name):
        r"""Sets the chinese_name of this BasicRoleDto.

        **参数解释：** 角色中文名。 **取值范围：** 不涉及。

        :param chinese_name: The chinese_name of this BasicRoleDto.
        :type chinese_name: str
        """
        self._chinese_name = chinese_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BasicRoleDto):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
