# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ForkRepositoryLeastDto:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'path_with_namespace': 'str'
    }

    attribute_map = {
        'path_with_namespace': 'path_with_namespace'
    }

    def __init__(self, path_with_namespace=None):
        r"""ForkRepositoryLeastDto

        The model defined in huaweicloud sdk

        :param path_with_namespace: **参数解释：** 带命名空间的仓库路径。 **约束限制：** view&#x3D;least时返回
        :type path_with_namespace: str
        """
        
        

        self._path_with_namespace = None
        self.discriminator = None

        if path_with_namespace is not None:
            self.path_with_namespace = path_with_namespace

    @property
    def path_with_namespace(self):
        r"""Gets the path_with_namespace of this ForkRepositoryLeastDto.

        **参数解释：** 带命名空间的仓库路径。 **约束限制：** view=least时返回

        :return: The path_with_namespace of this ForkRepositoryLeastDto.
        :rtype: str
        """
        return self._path_with_namespace

    @path_with_namespace.setter
    def path_with_namespace(self, path_with_namespace):
        r"""Sets the path_with_namespace of this ForkRepositoryLeastDto.

        **参数解释：** 带命名空间的仓库路径。 **约束限制：** view=least时返回

        :param path_with_namespace: The path_with_namespace of this ForkRepositoryLeastDto.
        :type path_with_namespace: str
        """
        self._path_with_namespace = path_with_namespace

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ForkRepositoryLeastDto):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
