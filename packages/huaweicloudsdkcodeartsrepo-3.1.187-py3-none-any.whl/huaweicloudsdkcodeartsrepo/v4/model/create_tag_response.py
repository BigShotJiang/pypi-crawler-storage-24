# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateTagResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'message': 'str',
        'target': 'str',
        'commit': 'CommitDto'
    }

    attribute_map = {
        'name': 'name',
        'message': 'message',
        'target': 'target',
        'commit': 'commit'
    }

    def __init__(self, name=None, message=None, target=None, commit=None):
        r"""CreateTagResponse

        The model defined in huaweicloud sdk

        :param name: 标签名称
        :type name: str
        :param message: 标签描述
        :type message: str
        :param target: 基于commitid
        :type target: str
        :param commit: 
        :type commit: :class:`huaweicloudsdkcodeartsrepo.v4.CommitDto`
        """
        
        super().__init__()

        self._name = None
        self._message = None
        self._target = None
        self._commit = None
        self.discriminator = None

        if name is not None:
            self.name = name
        if message is not None:
            self.message = message
        if target is not None:
            self.target = target
        if commit is not None:
            self.commit = commit

    @property
    def name(self):
        r"""Gets the name of this CreateTagResponse.

        标签名称

        :return: The name of this CreateTagResponse.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this CreateTagResponse.

        标签名称

        :param name: The name of this CreateTagResponse.
        :type name: str
        """
        self._name = name

    @property
    def message(self):
        r"""Gets the message of this CreateTagResponse.

        标签描述

        :return: The message of this CreateTagResponse.
        :rtype: str
        """
        return self._message

    @message.setter
    def message(self, message):
        r"""Sets the message of this CreateTagResponse.

        标签描述

        :param message: The message of this CreateTagResponse.
        :type message: str
        """
        self._message = message

    @property
    def target(self):
        r"""Gets the target of this CreateTagResponse.

        基于commitid

        :return: The target of this CreateTagResponse.
        :rtype: str
        """
        return self._target

    @target.setter
    def target(self, target):
        r"""Sets the target of this CreateTagResponse.

        基于commitid

        :param target: The target of this CreateTagResponse.
        :type target: str
        """
        self._target = target

    @property
    def commit(self):
        r"""Gets the commit of this CreateTagResponse.

        :return: The commit of this CreateTagResponse.
        :rtype: :class:`huaweicloudsdkcodeartsrepo.v4.CommitDto`
        """
        return self._commit

    @commit.setter
    def commit(self, commit):
        r"""Sets the commit of this CreateTagResponse.

        :param commit: The commit of this CreateTagResponse.
        :type commit: :class:`huaweicloudsdkcodeartsrepo.v4.CommitDto`
        """
        self._commit = commit

    def to_dict(self):
        import warnings
        warnings.warn("CreateTagResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateTagResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
