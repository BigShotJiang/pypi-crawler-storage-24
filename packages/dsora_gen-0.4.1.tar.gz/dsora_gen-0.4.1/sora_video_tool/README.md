# sora_video_tool

Package chính của **dsora-gen**: quản lý Chrome profiles, automation Sora, giao tiếp API và CLI.

---

## Cấu trúc

```
sora_video_tool/
├── cli/                    # CLI (dsg)
│   ├── __init__.py         # Entry: main group, đăng ký lệnh
│   ├── common.py           # Hằng, echo, image_src, ensure_playwright_browsers
│   ├── setup.py            # Lệnh setup
│   ├── run.py              # Lệnh run (chọn profile, chạy lần lượt từng profile)
│   └── commands.py        # Lệnh check, open, update, help
├── config.py               # Load/save settings (~/.sora-tool/settings.json)
├── constants.py            # APP_DATA_DIR, API_BASE_URL, PRODUCTS_PER_PROFILE, ...
├── profile_manager.py      # Thư mục Chrome profile (~/.sora-tool/profiles/)
├── browser_launcher.py    # Launch Chrome (login / automation với CDP)
├── sora_bot.py             # Logic automation: fill_prompt, upload_image, click_create
├── api_client.py           # get_pending_products, mark_product_done
├── telegram_notifier.py    # Thông báo Telegram
└── run_tracker.py          # Lịch sử chạy (run_log)
```

Entry point: `dsg = "sora_video_tool.cli:main"` (trong `pyproject.toml`).

---

## Luồng chạy

1. **cmd_run**: Checkbox chọn profile, rồi chạy **round-robin**: mỗi profile mở Chrome → làm **1 sản phẩm** → đóng Chrome → profile tiếp theo. Lặp đến hết SP hoặc tất cả profile đạt limit.
2. Mỗi lần: mở Chrome → `get_pending_products`, lấy 1 SP → create_video → mark_product_done / notify → đóng Chrome. Profile đạt limit bị loại khỏi vòng sau.
3. Nếu **VideoGenLimitReachedError** (tooltip "out of video gens"): notify, đóng Chrome, chuyển sang profile tiếp theo trong danh sách đã chọn.
4. CLI dùng **questionary** (select/checkbox) cho: số profile (setup), chọn profile (run, setup --retry, open).

---

## Development

```bash
# Từ repo (không cài package)
uv run dsg --help
uv run dsg check
```
