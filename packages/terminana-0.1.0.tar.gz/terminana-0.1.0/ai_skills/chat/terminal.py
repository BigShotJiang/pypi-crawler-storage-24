"""
ai_skills/chat/terminal.py
──────────────────────────
Terminal UI: banner 3-D va chat loop.

Public API
──────────
banner()
chat_loop(ask, provider, model, restart, reset)

Commands supported inside chat loop
─────────────────────────────────────
/help    — hien thi lenh nay
/switch  — doi provider va model (chay lai setup)
/reset   — bat dau cuoc tro chuyen moi, giu nguyen provider/model
/clear   — xoa man hinh
/quit    — thoat
"""
from __future__ import annotations

import os
from typing import Callable

import pyfiglet
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

console = Console()

# (cmd, mo ta ngan)
_COMMANDS: list[tuple[str, str]] = [
    ("/help",   "Hien thi danh sach lenh nay"),
    ("/switch", "Doi provider va model (chay lai setup day du)"),
    ("/reset",  "Bat dau lai cuoc tro chuyen moi, giu provider/model hien tai"),
    ("/clear",  "Xoa man hinh terminal"),
    ("/quit",   "Thoat Terminana  (cung co the dung Ctrl+C)"),
]


def banner() -> None:
    art    = pyfiglet.figlet_format("Terminana", font="larry3d")
    t      = Text()
    colors = [
        "bold bright_white on #005f87",
        "bold bright_cyan",
        "bold cyan",
        "bold #00d7ff",
    ]
    for i, line in enumerate(art.splitlines()):
        t.append(line + "\n", style=colors[i % len(colors)])
    console.print(
        Panel(t, subtitle="[dim]/help de xem lenh  |  Ctrl+C de thoat[/]",
              border_style="bright_cyan", expand=False)
    )


def _print_help(provider: str, model: str) -> None:
    tbl = Table(
        title="Cac lenh co san",
        border_style="cyan",
        header_style="bold cyan",
        show_lines=False,
        expand=False,
    )
    tbl.add_column("Lenh",   style="bold white",  no_wrap=True, min_width=10)
    tbl.add_column("Mo ta",  style="dim",         no_wrap=False)
    for cmd, desc in _COMMANDS:
        tbl.add_row(cmd, desc)
    console.print()
    console.print(tbl)
    console.print(
        f"  Dang dung: [bold]{provider.upper()}[/] / [bold]{model}[/]\n"
    )


def chat_loop(
    ask: Callable[[str], str],
    *,
    provider: str = "",
    model: str = "",
    restart: Callable[[], tuple[Callable[[str], str], str, str]] | None = None,
    reset: Callable[[], Callable[[str], str]] | None = None,
) -> None:
    """
    Vong lap chat chinh.

    Parameters
    ----------
    ask      : ham nhan prompt -> tra loi
    provider : ten provider hien tai (chi hien thi)
    model    : ten model hien tai (chi hien thi)
    restart  : callable() -> (new_ask, new_provider, new_model)
               Dung cho /switch — chay lai setup day du.
    reset    : callable() -> new_ask
               Dung cho /reset — tao session moi, giu provider/model.
    """
    while True:
        try:
            prompt_label = f"[{provider}/{model}]" if provider and model else ""
            user = input(f"you{prompt_label}> ").strip()
        except (KeyboardInterrupt, EOFError):
            break

        if not user:
            continue

        cmd = user.lower()

        if cmd in ("/quit", "/exit", "quit", "exit"):
            break

        if cmd == "/help":
            _print_help(provider, model)
            continue

        if cmd == "/clear":
            os.system("cls" if os.name == "nt" else "clear")
            banner()
            continue

        if cmd == "/switch":
            if restart is None:
                console.print("  [red]Khong ho tro switch trong che do nay.[/]")
                continue
            console.print()
            ask, provider, model = restart()
            console.print(f"\n  [dim]> Da chuyen sang {provider.upper()} / {model}[/]\n")
            continue

        if cmd == "/reset":
            if reset is None:
                console.print("  [red]Khong ho tro reset trong che do nay.[/]")
                continue
            ask = reset()
            console.print(f"  [dim]> Session moi: {provider.upper()} / {model}[/]\n")
            continue

        if cmd.startswith("/"):
            console.print(
                f"  [red]Lenh khong ton tai:[/] {cmd}  "
                f"([dim]/help de xem danh sach[/])"
            )
            continue

        with Live(Spinner("dots", text="[cyan]thinking...[/]"),
                  console=console, transient=True):
            reply = ask(user)

        console.print(
            Panel(Markdown(reply),
                  title=f"[bold green]Terminana[/] [dim]{provider}/{model}[/]",
                  border_style="green")
        )

    console.print("[dim]Bye.[/]")
