"""
ai_skills/chat/setup.py
───────────────────────
Interactive setup: chon provider, lay API key, fetch models tu API.

Public API
──────────
setup() -> (provider, model, api_key)
"""
from __future__ import annotations

import json
import urllib.request

from rich.console import Console

from ai_skills.config.settings import PROVIDERS, get_api_key

console = Console()


def _fetch_models(provider: str, api_key: str) -> list[str]:
    """Lay danh sach models truc tiep tu REST API — khong dung SDK."""
    if provider == "gemini":
        url  = (
            f"https://generativelanguage.googleapis.com/v1beta/models"
            f"?key={api_key}&pageSize=200"
        )
        data = json.loads(urllib.request.urlopen(url).read())
        return [
            m["name"].removeprefix("models/")
            for m in data.get("models", [])
            if "generateContent" in m.get("supportedGenerationMethods", [])
        ]
    req  = urllib.request.Request(
        "https://api.openai.com/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    data = json.loads(urllib.request.urlopen(req).read())
    return sorted(m["id"] for m in data.get("data", []) if m["id"].startswith("gpt"))


def pick(title: str, options: list[str]) -> str:
    """Hien menu so, tra ve lua chon."""
    console.print(f"\n[bold cyan]{title}[/]")
    for i, opt in enumerate(options, 1):
        console.print(f"  [cyan]{i}[/]. {opt}")
    while True:
        raw = input("pick> ").strip()
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1]
        console.print("  [red]Nhap so hop le.[/]")


def setup() -> tuple[str, str, str]:
    """
    Chay interactive setup tu terminal.
    Tra ve (provider, model, api_key).
    """
    provider = pick("Chon nha cung cap", list(PROVIDERS))
    api_key  = get_api_key(provider)

    console.print("  [dim]Dang tai danh sach models...[/]")
    models = _fetch_models(provider, api_key)

    model = pick(f"Chon model [{provider.upper()}]", models)
    return provider, model, api_key
