"""
ai_skills/cli.py
────────────────
Console-script entry point.  Registered via pyproject.toml as:

    terminana = "ai_skills.cli:cli"

After  `pip install -e .`  (or  `pip install terminana`  from PyPI):

    terminana start            # khoi dong terminal chat
    terminana telegram         # chay Telegram bot
    terminana --help           # xem huong dan

"""
from __future__ import annotations

import argparse
import sys

# ── Sub-commands ──────────────────────────────────────────────────────────

def _cmd_start(_args: argparse.Namespace) -> None:
    """Khoi dong terminal chat Terminana."""
    from ai_skills.chat.setup    import setup
    from ai_skills.chat.session  import new_session
    from ai_skills.chat.terminal import banner, chat_loop
    from rich.console import Console

    console = Console()
    banner()

    provider, model, api_key = setup()
    console.print(f"  [dim]> {provider.upper()} / {model}[/]\n")

    def restart():
        nonlocal provider, model, api_key
        provider, model, api_key = setup()
        return new_session(provider, api_key, model), provider, model

    def reset():
        return new_session(provider, api_key, model)

    chat_loop(
        new_session(provider, api_key, model),
        provider=provider,
        model=model,
        restart=restart,
        reset=reset,
    )


def _cmd_telegram(_args: argparse.Namespace) -> None:
    """Chay Telegram bot Terminana."""
    from ai_skills.chat.setup    import setup
    from ai_skills.chat.session  import new_session  # noqa: F401 (kept for clarity)
    from ai_skills.chat.telegram import get_token, run
    from ai_skills.chat.terminal import banner
    from rich.console import Console

    console = Console()
    banner()

    provider, model, api_key = setup()
    console.print(f"  [dim]> {provider.upper()} / {model}[/]")

    run(get_token(), provider, api_key, model)


# ── Parser ────────────────────────────────────────────────────────────────

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="terminana",
        description="Terminana — terminal & Telegram AI chat (Gemini / OpenAI)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
commands:
  start       Khoi dong terminal chat (mac dinh neu khong truyen gi)
  telegram    Chay Telegram bot

examples:
  terminana start
  terminana telegram
  terminana --help
""",
    )
    sub = parser.add_subparsers(dest="command", metavar="command")

    sub.add_parser("start",    help="Khoi dong terminal chat")
    sub.add_parser("telegram", help="Chay Telegram bot")

    return parser


# ── Entry ─────────────────────────────────────────────────────────────────

def cli(argv: list[str] | None = None) -> None:
    parser = _build_parser()
    args   = parser.parse_args(argv)

    if args.command == "start" or args.command is None:
        _cmd_start(args)
    elif args.command == "telegram":
        _cmd_telegram(args)
    else:
        parser.print_help()
        sys.exit(1)


# Cho phep chay truc tiep: python -m ai_skills.cli start
if __name__ == "__main__":
    cli()
