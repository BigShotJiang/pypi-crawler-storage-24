import requests
import json
from typing import Optional, Dict, Any

class ChatClient:
    """Client for interacting with the LLM API server"""
    
    def __init__(self, base_url: str = "https://llm.limma.live", api_key: str = None):
        """
        Initialize the LLM API client.
        
        Args:
            base_url: The base URL of the API server
            api_key: Your API key for authentication
        """
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.session = requests.Session()
    
    def gen(self, prompt: str, api_key: Optional[str] = None) -> Dict[str, Any]:
        """
        Send a prompt to the API and get a generated response.
        
        Args:
            prompt: The text prompt to send to the LLM
            api_key: Optional API key (overrides the one set during initialization)
            
        Returns:
            Dictionary containing the API response
            
        Raises:
            requests.RequestException: If the API request fails
            ValueError: If prompt is empty
        """
        if not prompt or not prompt.strip():
            raise ValueError("Prompt cannot be empty")
        
        # Use provided key or fall back to instance key
        key = api_key or self.api_key
        if not key:
            raise ValueError("API key is required")
        
        payload = {
            'prompt': prompt.strip(),
            'api_key': key
        }
        
        response = self.session.post(
            f"{self.base_url}/generate",
            json=payload,
            headers={'Content-Type': 'application/json'}
        )
        
        response.raise_for_status()
        return response.json()['response']
    
    def health_check(self) -> Dict[str, Any]:
        """Check if the API server is healthy"""
        response = self.session.get(f"{self.base_url}/health")
        response.raise_for_status()
        return response.json()