import speech_recognition as sr
import pyttsx3
from typing import Optional, Callable


class VoiceAssistant:
    """
    Stable Voice Assistant with TTS + Speech Recognition
    Uses fresh TTS engine for each speak call to avoid engine lockup issues.
    """

    def __init__(
        self,
        name: str = "Limma",
        female_voice: bool = True,
        speech_rate: int = 150,
        volume: float = 0.9,
        listen_timeout: int = 5
    ):
        self.name = name
        self.female_voice = female_voice
        self.speech_rate = speech_rate
        self.volume = volume
        self.listen_timeout = listen_timeout

        # Initialize Speech Recognition
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

        # Calibrate microphone once
        with self.microphone as source:
            print("🔧 Calibrating microphone...")
            self.recognizer.adjust_for_ambient_noise(source, duration=1)

        # Optional callbacks
        self.on_start_listening: Optional[Callable] = None
        self.on_stop_listening: Optional[Callable] = None
        self.on_speech_recognized: Optional[Callable] = None

    # -----------------------------
    # SPEAK - Using fresh engine approach
    # -----------------------------
    def speak(self, text: str) -> None:
        """
        Convert text to speech using a fresh TTS engine for each call.
        
        :param text: Text to speak
        :raises TypeError: If text is None or not a string
        :raises ValueError: If text is empty or volume/rate invalid
        :raises RuntimeError: If TTS engine fails
        """
        # ---------- validation ----------
        if text is None:
            raise TypeError("text cannot be None")

        if not isinstance(text, str):
            raise TypeError("text must be a string")

        if not text.strip():
            raise ValueError("text cannot be empty")

        if not (0.0 <= self.volume <= 1.0):
            raise ValueError("volume must be between 0.0 and 1.0")

        if not isinstance(self.speech_rate, int) or self.speech_rate <= 0:
            raise ValueError("rate must be a positive integer")

        try:
            # ✅ Create fresh engine for each speak call
            engine = pyttsx3.init()

            voices = engine.getProperty("voices")

            if self.female_voice:
                female_keywords = [
                    "female", "woman", "zira",
                    "samantha", "victoria", "anna"
                ]

                for voice in voices:
                    if any(k in voice.name.lower() for k in female_keywords):
                        engine.setProperty("voice", voice.id)
                        break

            engine.setProperty("rate", self.speech_rate)
            engine.setProperty("volume", self.volume)

            print(f"🗣️ {self.name}: {text}")
            engine.say(text)
            engine.runAndWait()
            engine.stop()

        except Exception as e:
            raise RuntimeError(f"TTS engine failure: {e}")

    # -----------------------------
    # LISTEN
    # -----------------------------
    def listen(
        self,
        timeout: Optional[int] = None,
        phrase_time_limit: Optional[int] = None
    ) -> Optional[str]:
        """
        Listen to microphone and convert speech to text.
        
        :param timeout: Maximum seconds to wait for speech to start
        :param phrase_time_limit: Maximum seconds for the phrase to complete
        :return: Recognized text or None if no speech detected
        """
        if timeout is None:
            timeout = self.listen_timeout

        if self.on_start_listening:
            self.on_start_listening()

        with self.microphone as source:
            print(f"🎤 {self.name} is listening...")

            try:
                audio = self.recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_time_limit
                )

                if self.on_stop_listening:
                    self.on_stop_listening()

                print("🔄 Recognizing...")
                text = self.recognizer.recognize_google(audio)

                if self.on_speech_recognized:
                    self.on_speech_recognized(text)

                return text

            except sr.WaitTimeoutError:
                print("⏱️ Listening timeout.")
            except sr.UnknownValueError:
                print("❌ Could not understand audio.")
            except sr.RequestError as e:
                print(f"🌐 API error: {e}")
            except Exception as e:
                print(f"Unexpected error: {e}")

        return None

    # -----------------------------
    # CONVENIENCE METHODS
    # -----------------------------
    def listen_for_keyword(self, keyword: str, timeout: Optional[int] = None) -> bool:
        """
        Listen for a specific keyword.
        
        :param keyword: Keyword to listen for
        :param timeout: Maximum seconds to wait
        :return: True if keyword was detected, False otherwise
        """
        text = self.listen(timeout)
        return text is not None and keyword.lower() in text.lower()

    def converse(self, prompt: str = "How can I help you?", timeout: Optional[int] = None) -> Optional[str]:
        """
        Speak a prompt and listen for a response.
        
        :param prompt: Text to speak before listening
        :param timeout: Maximum seconds to wait for response
        :return: User's response text or None
        """
        self.speak(prompt)
        return self.listen(timeout)

    # -----------------------------
    # SETTERS
    # -----------------------------
    def set_voice(self, female: bool) -> None:
        """
        Change the voice gender.
        
        :param female: True for female voice, False for male voice
        """
        self.female_voice = female
        # No need to reconfigure engine since we create fresh one each time

    def set_speech_rate(self, rate: int) -> None:
        """
        Change the speech rate.
        
        :param rate: Speech rate in words per minute
        :raises ValueError: If rate is not a positive integer
        """
        if not isinstance(rate, int) or rate <= 0:
            raise ValueError("rate must be a positive integer")
        self.speech_rate = rate

    def set_volume(self, volume: float) -> None:
        """
        Change the volume level.
        
        :param volume: Volume level (0.0 to 1.0)
        :raises ValueError: If volume is not between 0.0 and 1.0
        """
        if not (0.0 <= volume <= 1.0):
            raise ValueError("volume must be between 0.0 and 1.0")
        self.volume = volume

    # -----------------------------
    # CLEANUP
    # -----------------------------
    def cleanup(self) -> None:
        """Clean up resources (minimal cleanup since we create fresh engines)."""
        pass  # Nothing to cleanup as we create fresh engines each time

    # -----------------------------
    # CONTEXT MANAGER
    # -----------------------------
    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.cleanup()
