---
title: Sync `renovate.json5`
footer: false
---

### Description

Syncs the local `renovate.json5` with the canonical reference from [`kdeldycke/repomatic`](https://github.com/kdeldycke/repomatic/blob/main/repomatic/data/renovate.json5). Repo-specific settings (`customManagers`, `assignees`) are stripped. See the [`sync-renovate` job documentation](https://github.com/kdeldycke/repomatic?tab=readme-ov-file#githubworkflowsautofixyaml-jobs) for details.

### Configuration

Relevant [`[tool.repomatic]`](https://github.com/kdeldycke/repomatic?tab=readme-ov-file#toolrepomatic-configuration) options:

```toml
[tool.repomatic]
renovate.sync = true
```
