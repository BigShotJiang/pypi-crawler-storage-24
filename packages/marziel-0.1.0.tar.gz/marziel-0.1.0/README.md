---
language:
  - en
license: mit
tags:
  - llama
  - mlx
  - 4-bit
  - local-ai
  - private
  - maritime
  - vessel-tracking
  - osint
  - vllm
library_name: mlx
pipeline_tag: text-generation
base_model: meta-llama/Llama-3.1-8B-Instruct
---

# 🧠 Marziel AI — v0.1.0

**Private Local Intelligence — runs entirely on your hardware.**

Marziel AI is a locally-powered AI assistant with real-time maritime intelligence, web search, browser automation, GitHub analysis, URL reading, code generation, and autonomous agent capabilities — all without sending a single byte to the cloud.

## Quick Install

```bash
pip install marziel
marziel serve
```

That's it. The first run downloads the model (~4.2 GB) from Hugging Face and starts everything automatically.

## What It Does

| Feature | Description |
|---------|-------------|
| 🧠 **AI Chat** | Conversational AI with personality, code generation, data analysis |
| 📡 **Maritime Intelligence** | Real-time GDACS, GDELT, NASA EONET, AIS, market data, bunker prices |
| 💰 **Market Data** | Live Brent crude, BDI, EU Carbon, freight rates, forex, 12-port bunker prices |
| 🚢 **Vessel Integration** | AIS tracking, fleet management, voyage data, maintenance records |
| 🔌 **Third-Party Connectors** | Plug in MarineTraffic, VesselFinder, Spire, Datalastic, or any REST API |
| 📊 **Live Reports** | Generate comprehensive maritime intelligence reports on demand |
| 🔍 **Web Search** | Live internet results via DuckDuckGo — always up-to-date answers |
| 🌐 **Browser Control** | Headless Chromium automation — navigate, click, type, screenshot |
| 🔗 **URL Analysis** | Share any link — reads, extracts, and analyzes content |
| 🐙 **GitHub Analysis** | Paste any repo URL — get architecture, languages, README analysis |
| ⚡ **Autonomous Agent** | Multi-step reasoning with bash, file, web, browser, and maritime tools |
| 🔒 **100% Private** | Everything runs locally. Zero cloud dependency |

## Maritime Intelligence (Enterprise)

Marziel integrates real-time maritime data from multiple global sources:

```
┌───────────────────────────────────────────────────────────┐
│                   MARZIEL MARITIME INTEL                   │
├───────────────────────────────────────────────────────────┤
│  OSINT (Free APIs)         │  Platform Integration        │
│  ─────────────────         │  ────────────────────        │
│  📡 GDACS — Disasters      │  🚢 Fleet Vessels            │
│  📰 GDELT — Geopolitics    │  🗺️  Active Voyages          │
│  🌍 NASA EONET — Climate   │  ⚠️  Risk Zones              │
│  💰 Yahoo Finance — Market │  🏗️  Maintenance             │
│  💱 ExchangeRate — Forex   │  📋 Incidents                │
│  🚢 AISStream — Tracking   │  ⛽ Fuel Records             │
│                            │  🏭 Port Directory           │
├───────────────────────────────────────────────────────────┤
│  Third-Party Connectors (Enterprise)                      │
│  ─────────────────────────────────                        │
│  MarineTraffic · VesselFinder · Spire Maritime            │
│  Datalastic · OpenWeather · Custom REST API               │
└───────────────────────────────────────────────────────────┘
```

### Market Data Sources

| Data | Source | Update |
|------|--------|--------|
| Brent Crude Oil | Yahoo Finance (BZ=F) | Real-time |
| Bunker VLSFO/MGO/HSFO | Brent-derived (12 ports) | Real-time |
| Baltic Dry Index | BDRY ETF × 200 | Real-time |
| EU Carbon (EUA) | KRBN ETF × 2.1 | Real-time |
| Freight Rates | DSX/GNK shipping stocks | Real-time |
| Exchange Rates | ExchangeRate API (9 currencies) | Real-time |

### Third-Party Integration

Connect Marziel to any maritime service via `~/.marziel/connectors.json`:

```json
{
  "connectors": [
    {"type": "marinetraffic", "api_key": "YOUR_KEY"},
    {"type": "openweather", "api_key": "YOUR_KEY"},
    {
      "type": "custom",
      "name": "my_fleet",
      "base_url": "https://api.myfleet.com/v1",
      "api_key": "secret",
      "endpoints": {
        "vessels": "/ships",
        "voyages": "/trips",
        "weather": "/weather?lat={lat}&lon={lon}"
      }
    }
  ]
}
```

### Maritime API Endpoints

```
GET  /api/maritime/report           — Full intelligence report
GET  /api/maritime/data/market      — Live market data
GET  /api/maritime/data/bunker      — 12-port bunker prices
GET  /api/maritime/data/fx          — Exchange rates
GET  /api/maritime/data/gdacs       — Disaster events
GET  /api/maritime/data/gdelt       — Geopolitical news
GET  /api/maritime/data/nasa        — Natural events
GET  /api/maritime/data/ais         — Vessel tracking
GET  /api/maritime/data/vessels     — Fleet data
GET  /api/maritime/data/voyages     — Voyage data
GET  /api/maritime/data/risk-zones  — Active risk zones
GET  /api/maritime/data/ports       — Port directory
GET  /api/maritime/connectors       — List connectors
POST /api/maritime/connectors/query — Query third-party services
```

## Agent Tools

The LLM has access to 20+ tools:

| Tool | Purpose |
|------|---------|
| `bash` | Shell command execution |
| `file_read` / `file_write` | File I/O |
| `web_search` | DuckDuckGo search |
| `browser` | Headless Chromium automation |
| `maritime_report` | Full intelligence report |
| `market_data` | Brent, BDI, Carbon, bunker, freight |
| `gdacs` | Active disasters & cyclones |
| `gdelt` | Geopolitical conflict news |
| `nasa` | NASA EONET natural events |
| `ais` | Live AIS vessel tracking |
| `fleet` | Fleet vessel data |
| `voyages` | Active voyage data |
| `risk_zones` | Active risk zones |
| `ports` | Global port directory |
| `exchange_rates` | Live forex rates |
| `maintenance` | Vessel maintenance records |
| `incidents` | Maritime incident reports |
| `fuel` | Fuel consumption data |
| `port_calls` | Port call history |

## Changelog

### v0.1.0 — Initial Release
- **AI Chat**: Conversational AI with personality, powered by custom fine-tuned Llama 3.1 8B (4-bit)
- **Maritime Intelligence** (Enterprise): Real-time GDACS, GDELT, NASA EONET, market data, AIS tracking
- **Market Data**: Live Brent crude, bunker prices (12 ports), BDI, EU Carbon, freight rates, forex
- **Third-Party Connector SDK**: Plug in MarineTraffic, VesselFinder, Spire, Datalastic, OpenWeather, or any REST API
- **Live Report Generation**: Comprehensive intelligence reports combining all data sources
- **Web Search**: Auto-augmented answers via DuckDuckGo
- **Browser Control**: Headless Chromium automation via Playwright
- **Autonomous Agent**: ReAct-based tool use with 20+ tools (bash, file, web, browser, maritime)
- **Three-tier pricing**: Free, Pro (€20/mo), Enterprise (€199/mo) with Stripe billing
- **100% Local**: MLX on Apple Silicon, vLLM on NVIDIA GPU — zero cloud dependency

## Requirements

- **RAM**: 8GB minimum (16GB recommended)
- **Disk**: ~5GB for the model
- **Python**: 3.10+
- **Supported hardware**:
  - Apple Silicon (M1/M2/M3/M4) — uses MLX inference
  - NVIDIA GPU (8GB+ VRAM) — uses vLLM with CUDA

## Usage

```bash
# Install and start (basic)
pip install marziel
marziel serve

# With browser automation
pip install "marziel[browser]"
python -m playwright install chromium
marziel serve

# Check status
marziel status

# Show version
marziel version
```

Then open **http://localhost:8001** — your private AI dashboard.

## Architecture

```
┌──────────────────────────────────────────────┐
│  Browser (localhost:8001)                     │
│  ┌────────────────────────────────────────┐   │
│  │  Marziel Dashboard (React)            │   │
│  │  Dashboard · Chat · Settings          │   │
│  └──────────────┬─────────────────────────┘   │
│                 │ API calls                    │
│  ┌──────────────▼─────────────────────────┐   │
│  │  Marziel Backend (Flask+Gunicorn)     │   │
│  │  Agent · Search · Browser · Maritime  │   │
│  │  Billing · Connectors · Reports       │   │
│  └──────┬───────┬───────┬─────────────────┘   │
│         │       │       │                      │
│  ┌──────▼──┐ ┌──▼────┐ ┌▼──────────────────┐  │
│  │ LLM     │ │ OSINT │ │ Third-Party APIs   │  │
│  │ MLX/vLLM│ │ GDACS │ │ MarineTraffic      │  │
│  │ 8B 4bit │ │ GDELT │ │ VesselFinder       │  │
│  │         │ │ NASA  │ │ Spire · Custom     │  │
│  │         │ │ Yahoo │ │                    │  │
│  └─────────┘ └───────┘ └────────────────────┘  │
│                YOUR MACHINE                     │
└──────────────────────────────────────────────┘
```

## Pricing

| Plan | Price | Features |
|------|-------|----------|
| **Free** | €0/mo | AI Chat, Web Search, URL Analysis, GitHub Analysis |
| **Pro** | €20/mo | + Agent Mode, Browser Control, Priority Inference |
| **Enterprise** | €199/mo | + Maritime Intelligence, Connectors, Reports, Custom Fine-tuning |

## Links

- 🌐 Website: [marziel.com](https://marziel.com)
- 🤗 Model: [huggingface.co/efops/marziel-8b-custom](https://huggingface.co/efops/marziel-8b-custom)
- 📦 PyPI: [pypi.org/project/marziel](https://pypi.org/project/marziel)

## License

MIT License

---

Built with ❤️ by Efe (Efkan Isazade)
