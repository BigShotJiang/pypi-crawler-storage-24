use std::process::ExitCode;

fn main() -> ExitCode {
    if let Err(e) = ascend_tools_cli::run_cli(std::env::args()) {
        eprintln!("Error: {e:#}");
        return ExitCode::FAILURE;
    }
    ExitCode::SUCCESS
}
