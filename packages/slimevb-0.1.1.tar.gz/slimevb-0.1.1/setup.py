from pathlib import Path

import setuptools

long_description = Path(__file__).parent.joinpath("README.md").read_text(encoding="utf-8")

setuptools.setup(
    name="slimevb",
    version="0.1.1",
    description="Port of David Ha's Slime volleyball for gymnasium.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Chase McDonald",
    author_email="chasemcd@andrew.cmu.edu",
    packages=setuptools.find_packages(),
    install_requires=[
        "numpy",
        "gymnasium",
        "opencv-python",
    ],
    python_requires=">=3.10",
)
