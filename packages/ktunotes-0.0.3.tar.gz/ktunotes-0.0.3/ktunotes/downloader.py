import os
import gdown
from ktunotes.ui import show_success, show_error, show_info


def download_folder(url, subject_code):
    dest = os.path.join(os.path.expanduser("~"), "ktunotes", subject_code.lower())
    os.makedirs(dest, exist_ok=True)

    show_info(f"Downloading to ~/ktunotes/{subject_code.lower()}/")
    print()

    try:
        gdown.download_folder(url, output=dest, quiet=False)
        print()
        show_success(f"Saved to {dest}")
    except Exception as e:
        print()
        show_error(f"Download failed: {e}")
        show_info("Opening in browser instead.")

    return dest
