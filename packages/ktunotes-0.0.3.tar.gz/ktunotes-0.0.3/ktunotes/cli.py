import click
from ktunotes import __version__
from ktunotes.ui import print_banner, show_success, show_error, show_info
from ktunotes.scraper import fetch_drive_link
from ktunotes.downloader import download_folder
from ktunotes.utils import open_in_browser


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="ktunotes")
@click.pass_context
def cli(ctx):
    if ctx.invoked_subcommand is None:
        print_banner()
        click.echo("  Usage:")
        click.echo("    ktunotes notes <subject-code>   Download notes")
        click.echo()


@cli.command()
@click.argument("subject_code")
def notes(subject_code):
    code = subject_code.lower()

    print()
    show_info(f"Fetching {code.upper()} from ktunotes.live...")

    name, drive_link, error = fetch_drive_link(code)

    if error:
        show_error(error)
        return

    show_success(f"{code.upper()} — {name}")

    print()
    download_folder(drive_link, code)

    print()
    show_info("Opening Google Drive folder...")
    open_in_browser(drive_link)
