import re
import webbrowser


def sanitize_filename(name):
    name = re.sub(r'[<>:"/\\|?*]', '', name)
    name = re.sub(r'\s+', '_', name.strip())
    return name


def open_in_browser(url):
    try:
        webbrowser.open(url)
        return True
    except Exception:
        return False
