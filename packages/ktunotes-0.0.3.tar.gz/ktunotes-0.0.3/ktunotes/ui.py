from rich.console import Console

console = Console()

BANNER = r"""
 ██╗  ██╗████████╗██╗   ██╗
 ██║ ██╔╝╚══██╔══╝██║   ██║
 █████╔╝    ██║   ██║   ██║
 ██╔═██╗    ██║   ██║   ██║
 ██║  ██╗   ██║   ╚██████╔╝
 ╚═╝  ╚═╝   ╚═╝    ╚═════╝

 ███╗   ██╗ ██████╗ ████████╗███████╗███████╗
 ████╗  ██║██╔═══██╗╚══██╔══╝██╔════╝██╔════╝
 ██╔██╗ ██║██║   ██║   ██║   █████╗  ███████╗
 ██║╚██╗██║██║   ██║   ██║   ██╔══╝  ╚════██║
 ██║ ╚████║╚██████╔╝   ██║   ███████╗███████║
 ╚═╝  ╚═══╝ ╚═════╝    ╚═╝   ╚══════╝╚══════╝
"""


def print_banner():
    try:
        width = console.size.width
    except Exception:
        width = 80

    console.print()

    if width >= 55:
        for line in BANNER.strip().splitlines():
            console.print(f"  [bold cyan]{line}[/]")
        console.print()
        console.print("  [dim]CLI tool for ktunotes.live[/]")
    else:
        console.print("  [bold cyan]KTU NOTES[/]")
        console.print("  [dim]CLI tool for ktunotes.live[/]")

    console.print()


def show_success(msg):
    console.print(f"  [bold green]✔[/] {msg}")


def show_error(msg):
    console.print(f"  [bold red]✘[/] {msg}")


def show_info(msg):
    console.print(f"  [cyan]→[/] {msg}")
