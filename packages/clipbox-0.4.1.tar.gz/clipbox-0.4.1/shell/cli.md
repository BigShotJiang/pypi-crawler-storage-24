The environment variables below control the server you connect to and the copy command to use
```sh
export CB_HOST=http://localhost:8080
export CB_COPY_CMD=xclip   # 'wl-copy' in wayland, 'pbcopy' in mac os, etc.
```
If using zsh, you'll need to add the following to you .zshrc:
```sh
autoload bashcompinit && bashcompinit
autoload compinit && compinit
```
Source the shell scripts to enable the `cb` and `fb` commands:
```sh
source /path/to/cb.sh
source /path/to/fb.sh
```
