# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["TaskListParams"]


class TaskListParams(TypedDict, total=False):
    status: Required[List[Literal["success", "warning", "error", "no-tests"]]]
    """Filter tasks by status"""

    eval_definition_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="evalDefinitionId")]
    """Filter tasks by eval definition ID"""

    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]
    """Field to order by in the result set."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    quickstart_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="quickstartId")]
    """Filter tasks by quickstart ID"""

    search: str
    """Search tasks by title or description (case-insensitive partial match)"""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    tag_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="tagId")]
    """Filter tasks by tag ID"""

    topic_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="topicId")]
    """Filter tasks by topic ID"""
