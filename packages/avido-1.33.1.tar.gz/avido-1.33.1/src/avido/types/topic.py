# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Topic", "AssignedUser"]


class AssignedUser(BaseModel):
    """Information about the assigned user"""

    id: str
    """User ID"""

    email: str
    """User email"""

    name: str
    """User full name"""

    image: Optional[str] = None
    """User profile image URL"""


class Topic(BaseModel):
    """Details about a single Topic"""

    id: str
    """Unique identifier of the topic"""

    baseline: Optional[float] = None
    """Optional baseline score for this topic"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the topic was created"""

    is_verified: bool = FieldInfo(alias="isVerified")
    """
    Whether the topic is verified (true when all active tasks in the topic are
    verified)
    """

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the topic was last modified"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this topic"""

    title: str
    """Title of the topic"""

    application_id: Optional[str] = FieldInfo(alias="applicationId", default=None)
    """Optional application ID this topic belongs to"""

    assigned_to: Optional[str] = FieldInfo(alias="assignedTo", default=None)
    """User ID of the assigned user"""

    assigned_user: Optional[AssignedUser] = FieldInfo(alias="assignedUser", default=None)
    """Information about the assigned user"""

    quickstart_id: Optional[str] = FieldInfo(alias="quickstartId", default=None)
    """Optional quickstart ID this topic belongs to"""
