# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .core_tag import CoreTag
from .eval_definition import EvalDefinition

__all__ = ["TaskListResponse", "TaskSchedule"]


class TaskSchedule(BaseModel):
    """Task schedule schema"""

    application_id: str = FieldInfo(alias="applicationId")

    criticality: Literal["LOW", "MEDIUM", "HIGH"]

    cron: str

    task_id: str = FieldInfo(alias="taskId")

    last_run_at: Optional[datetime] = FieldInfo(alias="lastRunAt", default=None)

    next_run_at: Optional[datetime] = FieldInfo(alias="nextRunAt", default=None)


class TaskListResponse(BaseModel):
    id: str
    """The unique identifier of the task"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the task was created"""

    description: str
    """The task description"""

    eval_definitions: List[EvalDefinition] = FieldInfo(alias="evalDefinitions")

    input_examples: List[str] = FieldInfo(alias="inputExamples")
    """Example inputs for the task"""

    is_verified: bool = FieldInfo(alias="isVerified")
    """Whether the task has been verified"""

    metadata: Dict[str, object]
    """Optional metadata associated with the task.

    Returns null when no metadata is stored.
    """

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the task was last modified"""

    monitoring_pass_rate: Optional[float] = FieldInfo(alias="monitoringPassRate", default=None)
    """The 30 day pass rate for monitoring runs only, measured in percentage.

    Null when no monitoring runs exist.
    """

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """
    The 30 day pass rate for the task measured in percentage (excludes monitoring
    runs). Null when no tests have been run.
    """

    status: Literal["DEDUCED", "DRAFT", "ACTIVE"]
    """The status of the task.

    DEDUCED tasks are created from unmatched traces, DRAFT tasks are user-facing
    drafts, and ACTIVE tasks are production tasks.
    """

    tags: List[CoreTag]

    title: str
    """The title of the task"""

    type: Literal["STATIC", "NORMAL"]
    """The type of task.

    Normal tasks have a dynamic user prompt, while adversarial tasks have a fixed
    user prompt.
    """

    last_test: Optional[datetime] = FieldInfo(alias="lastTest", default=None)
    """The date and time this task was last tested"""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """The ID of the parent task (for DEDUCED tasks linked to a DRAFT)"""

    quickstart_id: Optional[str] = FieldInfo(alias="quickstartId", default=None)
    """The ID of the quickstart this task was generated from"""

    simulated_prompt_schema: Optional[Dict[str, object]] = FieldInfo(alias="simulatedPromptSchema", default=None)
    """
    JSON schema that defines the structure for user prompts that should be generated
    for tests
    """

    task_schedule: Optional[TaskSchedule] = FieldInfo(alias="taskSchedule", default=None)
    """Task schedule schema"""

    topic_id: Optional[str] = FieldInfo(alias="topicId", default=None)
    """The ID of the topic this task belongs to"""

    trace_id: Optional[str] = FieldInfo(alias="traceId", default=None)
    """The ID of the trace this task was deduced from (only for DEDUCED tasks)"""
