import pytest

from vector_crypt import (
    Point,
    encrypt,
    decrypt,
    bytes_to_vectors,
    vectors_to_bytes,
    generate_random_key,
    encrypt_bytes_stream,
    generate_random_key_stream,
)


def test_roundtrip_bytes():
    data = b"hello"
    key = generate_random_key(len(data))
    vec = bytes_to_vectors(data)
    cipher = encrypt(vec, key)
    assert decrypt(cipher, key) == vec


def test_stream_bytes():
    data = b"streamy"
    key_stream = generate_random_key_stream(len(data))
    enc = list(encrypt_bytes_stream(data, key_stream))
    assert len(enc) == len(data)
