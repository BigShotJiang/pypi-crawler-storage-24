from __future__ import annotations

import random
from typing import Iterable, Iterator, List, Optional

from .classes import AppliedVector, AppliedVectorSet, Point


# --- key generation ------------------------------------------------------------

def generate_random_key(
    num_vectors: int,
    max_coord: float = 255.0,
    origin: Optional[Point] = None,
) -> AppliedVectorSet:
    """Produce a random ``AppliedVectorSet`` containing ``num_vectors`` vectors.

    Each vector starts at ``origin`` (default ``Point(0,0)``) and has an end
    point whose coordinates are chosen uniformly from ``[-max_coord, max_coord]``.

    Parameters
    ----------
    num_vectors
        Number of vectors in the key; typically equal to the length of the
        plaintext when encoding byte-wise.
    max_coord
        Maximum absolute value for each coordinate of the end point.  Smaller
        values yield shorter vectors.
    origin
        Optional common starting point for all vectors.
    """
    if origin is None:
        origin = Point(0.0, 0.0)

    vecs: list[AppliedVector] = []
    for _ in range(num_vectors):
        dx = random.uniform(-max_coord, max_coord)
        dy = random.uniform(-max_coord, max_coord)
        end = Point(origin.x + dx, origin.y + dy)
        vecs.append(AppliedVector(origin, end))
    return AppliedVectorSet(vecs, origin=origin)


def key_for_data(data: bytes, **kwargs) -> AppliedVectorSet:
    """Convenience helper that generates a key matching the length of ``data``.

    All keyword arguments are forwarded to :func:`generate_random_key`.
    """
    return generate_random_key(len(data), **kwargs)


def generate_random_key_stream(
    num_vectors: int,
    max_coord: float = 255.0,
    origin: Optional[Point] = None,
) -> Iterator[AppliedVector]:
    """Yield ``num_vectors`` random ``AppliedVector`` objects one by one.

    This is useful for encrypting large blobs without materializing the entire
    ``AppliedVectorSet`` in memory.  The caller can consume the stream in
    chunks and assemble sets as needed.
    """
    if origin is None:
        origin = Point(0.0, 0.0)

    for _ in range(num_vectors):
        dx = random.uniform(-max_coord, max_coord)
        dy = random.uniform(-max_coord, max_coord)
        end = Point(origin.x + dx, origin.y + dy)
        yield AppliedVector(origin, end)


def generate_batch_keys(
    lengths: Iterable[int],
    **kwargs,
) -> List[AppliedVectorSet]:
    """Return a list of random keys for each length in ``lengths``.

    This helper is convenient when encrypting or decrypting a collection of
    messages with independent keys.
    """
    return [generate_random_key(n, **kwargs) for n in lengths]


def key_stream_for_data(
    data: bytes,
    **kwargs,
) -> Iterator[AppliedVector]:
    """Generate a stream of random vectors matching ``len(data)``.

    Equivalent to ``generate_random_key_stream(len(data), **kwargs)`` but
    named to echo :func:`key_for_data`.
    """
    yield from generate_random_key_stream(len(data), **kwargs)
