from __future__ import annotations

from typing import Iterable, Iterator

from .classes import AppliedVector, AppliedVectorSet, Point


# --- data <-> vectors conversion ------------------------------------------------

def bytes_to_vectors(data: bytes, origin: Point | None = None) -> AppliedVectorSet:
    """Encode raw bytes into an AppliedVectorSet.

    Each byte value is turned into a vector with dx equal to the byte and dy=0.
    All vectors share a common ``origin`` (defaults to ``Point(0, 0)``).

    This is a toy encoding; you can easily swap in a different mapping (e.g. two
    bytes per vector, use dy for a second channel, etc.).
    """
    if origin is None:
        origin = Point(0.0, 0.0)

    vectors: list[AppliedVector] = []
    for b in data:
        end = Point(origin.x + float(b), origin.y)
        vectors.append(AppliedVector(origin, end))
    return AppliedVectorSet(vectors, origin=origin)


def vectors_to_bytes(vectors: AppliedVectorSet) -> bytes:
    """Decode a previously-encoded ``AppliedVectorSet`` back to bytes.

    This function reverses :func:`bytes_to_vectors` and therefore will raise an
    exception if the encoding scheme has changed or the set contains vectors
    that do not have ``dy == 0`` or start at a consistent origin.
    """
    result = bytearray()
    if len(vectors) == 0:
        return bytes(result)

    orig = vectors.origin or vectors.vectors[0].start_point
    for av in vectors:
        if av.start_point != orig:
            raise ValueError("Inconsistent origin in AppliedVectorSet")
        dx = av.direction_vector.dx
        if av.direction_vector.dy != 0:
            raise ValueError("Unexpected non-zero dy component")
        if not (0 <= dx <= 255):
            raise ValueError("dx value out of byte range: %r" % dx)
        result.append(int(dx))

    return bytes(result)


def text_to_vectors(text: str, encoding: str = "utf-8", **kwargs) -> AppliedVectorSet:
    """Convenience wrapper that encodes ``text`` using ``bytes_to_vectors``."""
    return bytes_to_vectors(text.encode(encoding), **kwargs)


def vectors_to_text(vectors: AppliedVectorSet, encoding: str = "utf-8") -> str:
    """Convenience wrapper that decodes vectors back to a string."""
    return vectors_to_bytes(vectors).decode(encoding)


# streaming helpers -----------------------------------------------------------

def bytes_to_vectors_stream(
    data: Iterable[int], origin: Point | None = None
) -> Iterator[AppliedVector]:
    """Yield vectors corresponding to each byte in ``data``.

    ``data`` may be any iterable of integer values in ``0..255``; typical use
    is to pass a ``bytes`` or ``bytearray`` object.  The caller can wrap the
    output in an :class:`AppliedVectorSet` if desired.
    """
    if origin is None:
        origin = Point(0.0, 0.0)
    for b in data:
        end = Point(origin.x + float(b), origin.y)
        yield AppliedVector(origin, end)


def vectors_to_bytes_stream(
    vectors: Iterable[AppliedVector],
    origin: Point | None = None,
) -> Iterator[int]:
    """Yield integer byte values from an iterable of vectors.

    This is the streaming counterpart to :func:`vectors_to_bytes` and is
    useful when processing large sequences without collecting them all first.
    ``origin`` may be specified to validate start points.
    """
    first = True
    for av in vectors:
        if first:
            first = False
            if origin is None:
                origin = av.start_point
        if av.start_point != origin:
            raise ValueError("Inconsistent origin in stream")
        if av.direction_vector.dy != 0:
            raise ValueError("Unexpected non-zero dy component")
        dx = av.direction_vector.dx
        if not (0 <= dx <= 255):
            raise ValueError("dx value out of byte range: %r" % dx)
        yield int(dx)


# file helpers ---------------------------------------------------------------

def file_to_vectors(path: str, chunk_size: int = 4096) -> Iterator[AppliedVector]:
    """Read a file and yield vectors for its bytes in chunks.

    The file is opened in binary mode and read incrementally to avoid large
    memory consumption.  ``chunk_size`` controls how many bytes are read at a
    time.
    """
    origin = Point(0.0, 0.0)
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            yield from bytes_to_vectors_stream(chunk, origin=origin)


def vectors_to_file(vectors: Iterable[AppliedVector], path: str):
    """Write vector data back to a file as raw bytes."""
    with open(path, "wb") as f:
        for byte in vectors_to_bytes_stream(vectors):
            f.write(bytes((byte,)))
