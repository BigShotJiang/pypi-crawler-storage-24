from __future__ import annotations

from typing import Iterable, Iterator

from .classes import AppliedVectorSet, AppliedVector, Point
from .vector_codec import (
    bytes_to_vectors,
    vectors_to_bytes,
    text_to_vectors,
    vectors_to_text,
)
from .keygen import key_for_data


def encrypt(plaintext: AppliedVectorSet,
            key: AppliedVectorSet) -> AppliedVectorSet:
    return plaintext + key

def decrypt(ciphertext: AppliedVectorSet,
            key: AppliedVectorSet) -> AppliedVectorSet:
    return ciphertext - key


# high-level helpers ----------------------------------------------------------

def encrypt_bytes(data: bytes, key: AppliedVectorSet) -> AppliedVectorSet:
    """Encrypt raw data.  ``key`` must be at least as long as ``data``."""
    pt = bytes_to_vectors(data)
    return encrypt(pt, key)


def decrypt_bytes(cipher: AppliedVectorSet, key: AppliedVectorSet) -> bytes:
    """Decrypt to raw bytes.  ``cipher`` and ``key`` should have equal length."""
    pt = decrypt(cipher, key)
    return vectors_to_bytes(pt)


def encrypt_text(text: str, key: AppliedVectorSet, encoding: str = "utf-8") -> AppliedVectorSet:
    """Convenience: encode and encrypt a string."""
    return encrypt(text_to_vectors(text, encoding=encoding), key)


def decrypt_text(cipher: AppliedVectorSet, key: AppliedVectorSet, encoding: str = "utf-8") -> str:
    """Decrypt and decode to text."""
    return vectors_to_text(decrypt(cipher, key), encoding=encoding)


# batch / streaming helpers ---------------------------------------------------

def encrypt_sequence(
    plaintexts: Iterable[AppliedVectorSet],
    keys: Iterable[AppliedVectorSet],
) -> list[AppliedVectorSet]:
    """Encrypt many plaintext vector sets with corresponding keys.

    Both iterables are consumed in lockstep; lengths must match.
    """
    return [encrypt(p, k) for p, k in zip(plaintexts, keys)]


def decrypt_sequence(
    ciphertexts: Iterable[AppliedVectorSet],
    keys: Iterable[AppliedVectorSet],
) -> list[AppliedVectorSet]:
    """Decrypt many ciphertexts with the provided keys."""
    return [decrypt(c, k) for c, k in zip(ciphertexts, keys)]


def encrypt_bytes_stream(
    data: Iterable[int],
    key_stream: Iterable[AppliedVector],
    origin: Point | None = None,
) -> Iterator[AppliedVector]:
    """Stream-encrypt a byte sequence against a stream of key vectors.

    ``data`` yields byte values; ``key_stream`` yields pre-generated random
    ``AppliedVector`` objects.  The resulting stream produces encrypted vectors
    that can be consumed without buffering the whole message.
    """
    if origin is None:
        origin = Point(0.0, 0.0)
    for byte, key_vec in zip(data, key_stream):
        pt_vec = AppliedVector(origin, Point(origin.x + float(byte), origin.y))
        # addition uses AppliedVector.__add__, which keeps start == origin
        yield pt_vec + key_vec


def decrypt_bytes_stream(
    cipher_stream: Iterable[AppliedVector],
    key_stream: Iterable[AppliedVector],
) -> Iterator[int]:
    """Inverse of :func:`encrypt_bytes_stream`, yields raw byte values."""
    for cipher_vec, key_vec in zip(cipher_stream, key_stream):
        pt = cipher_vec - key_vec
        yield int(pt.direction_vector.dx)
