"""Top-level package for the applied-vector cryptography library.

The package is intentionally small and re-exports most of the user-facing
symbols from its submodules.  Importing :mod:`vector_crypt` gives you access to
all the functionality described in the README.
"""

from __future__ import annotations

# re-export core data classes
from .classes import (
    Point,
    Vector,
    AppliedVector,
    AppliedVectorSet,
)

# encryption / decryption helpers
from .endecode import (
    encrypt,
    decrypt,
    encrypt_bytes,
    decrypt_bytes,
    encrypt_text,
    decrypt_text,
    encrypt_sequence,
    decrypt_sequence,
    encrypt_bytes_stream,
    decrypt_bytes_stream,
)

# codec utilities
from .vector_codec import (
    bytes_to_vectors,
    vectors_to_bytes,
    text_to_vectors,
    vectors_to_text,
    bytes_to_vectors_stream,
    vectors_to_bytes_stream,
    file_to_vectors,
    vectors_to_file,
)

# key generation helpers
from .keygen import (
    generate_random_key,
    key_for_data,
    generate_random_key_stream,
    generate_batch_keys,
    key_stream_for_data,
)

__all__ = [
    # core
    "Point",
    "Vector",
    "AppliedVector",
    "AppliedVectorSet",
    # encryption
    "encrypt",
    "decrypt",
    "encrypt_bytes",
    "decrypt_bytes",
    "encrypt_text",
    "decrypt_text",
    "encrypt_sequence",
    "decrypt_sequence",
    "encrypt_bytes_stream",
    "decrypt_bytes_stream",
    # codecs
    "bytes_to_vectors",
    "vectors_to_bytes",
    "text_to_vectors",
    "vectors_to_text",
    "bytes_to_vectors_stream",
    "vectors_to_bytes_stream",
    "file_to_vectors",
    "vectors_to_file",
    # keygen
    "generate_random_key",
    "key_for_data",
    "generate_random_key_stream",
    "generate_batch_keys",
    "key_stream_for_data",
]
