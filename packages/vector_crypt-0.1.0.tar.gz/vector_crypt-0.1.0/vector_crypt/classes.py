from math import sqrt
from typing import Iterable

class Point:
    """Class of a point in space"""
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point({self.x}, {self.y})"

    def __eq__(self, other):
        if not isinstance(other, Point):
            return NotImplemented
        return self.x == other.x and self.y == other.y

class Vector:
    """A vector class with no fixed location. It has only an endpoint, as if it were located at coordinates 0, 0.
       More accurately, it represents the components (dx, dy) of the vector."""
    def __init__(self, dx: float, dy: float):
        self.dx = dx
        self.dy = dy
    
    @classmethod
    def from_points(cls, start_point: Point, end_point: Point):
        """Creates a Vector from two points."""
        dx = end_point.x - start_point.x
        dy = end_point.y - start_point.y
        return cls(dx, dy)

    def get_length(self) -> float:
        return sqrt(self.dx**2 + self.dy**2)

    def __repr__(self):
        return f"Vector(dx={self.dx}, dy={self.dy})"

    def __add__(self, other):
        if not isinstance(other, Vector):
            return NotImplemented
        return Vector(self.dx + other.dx, self.dy + other.dy)

    def __sub__(self, other):
        if not isinstance(other, Vector):
            return NotImplemented
        return Vector(self.dx - other.dx, self.dy - other.dy)

    def __mul__(self, scalar: float):
        return Vector(self.dx * scalar, self.dy * scalar)

    def __rmul__(self, scalar: float):
        return self.__mul__(scalar)

    def dot_product(self, other) -> float:
        if not isinstance(other, Vector):
            raise TypeError("Can only perform dot product with another Vector.")
        return self.dx * other.dx + self.dy * other.dy

class AppliedVector:
    """
    Represents a vector applied to a specific starting point.
    It has:
    - Direction (like a Vector)
    - Length (like a line segment)
    - Fixed coordinates (like a Point, specifically its start_point)
    """
    def __init__(self, start_point: Point, end_point: Point):
        self.start_point = start_point
        self.end_point = end_point
        self._free_vector = Vector.from_points(start_point, end_point)

    @property
    def direction_vector(self) -> Vector:
        return self._free_vector

    def get_length(self) -> float:
        return self._free_vector.get_length()

    def __repr__(self):
        return f"AppliedVector(start={self.start_point}, end={self.end_point})"

    def __eq__(self, other):
        if not isinstance(other, AppliedVector):
            return NotImplemented
        return self.start_point == other.start_point and self.end_point == other.end_point

    def __add__(self, other):
        if not isinstance(other, AppliedVector):
            return NotImplemented
        
        result_free_vector = self.direction_vector + other.direction_vector
        
        new_end_x = self.start_point.x + result_free_vector.dx
        new_end_y = self.start_point.y + result_free_vector.dy
        return AppliedVector(self.start_point, Point(new_end_x, new_end_y))

    def __sub__(self, other):
        if not isinstance(other, AppliedVector):
            return NotImplemented
        
        result_free_vector = self.direction_vector - other.direction_vector
        
        new_end_x = self.start_point.x + result_free_vector.dx
        new_end_y = self.start_point.y + result_free_vector.dy
        return AppliedVector(self.start_point, Point(new_end_x, new_end_y))
    
    def __mul__(self, scalar: float):
        scaled_free_vector = self.direction_vector * scalar
        new_end_x = self.start_point.x + scaled_free_vector.dx
        new_end_y = self.start_point.y + scaled_free_vector.dy
        return AppliedVector(self.start_point, Point(new_end_x, new_end_y))

    def __rmul__(self, scalar: float):
        return self.__mul__(scalar)

class AppliedVectorSet:
    """A set of applied vectors that support element-wise operations."""
    def __init__(self, vectors: Iterable[AppliedVector] = (), origin: Point | None = None):
        self.vectors = list(vectors)
        self.origin = origin

    def __len__(self):
        return len(self.vectors)

    def __iter__(self):
        return iter(self.vectors)

    def __repr__(self):
        return f"<AppliedVectorSet {self.vectors!r}>"

    def __eq__(self, other: "AppliedVectorSet"):
        if not isinstance(other, AppliedVectorSet):
            return NotImplemented
        return self.origin == other.origin and self.vectors == other.vectors

    def __add__(self, other: "AppliedVectorSet"):
        if len(self) != len(other):
            raise ValueError("The sizes of the sets must match!")
        return AppliedVectorSet(
            (a + b for a, b in zip(self.vectors, other.vectors)),
            origin=self.origin or other.origin,
        )

    def __sub__(self, other: "AppliedVectorSet"):
        if len(self) != len(other):
            raise ValueError("The sizes of the sets must match!")
        return AppliedVectorSet(
            (a - b for a, b in zip(self.vectors, other.vectors)),
            origin=self.origin or other.origin,
        )

    def scalar_mul(self, scalar: float):
        return AppliedVectorSet((v * scalar for v in self.vectors),
                                origin=self.origin)