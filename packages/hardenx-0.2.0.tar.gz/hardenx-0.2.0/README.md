# HardenX

HardenX is an interactive local system hardening CLI for Ubuntu, CentOS, Windows 10, and Windows 11. It audits benchmark controls, offers guided remediation for rollback-capable controls, and records remediation transactions so they can be rolled back later from the same CLI.

## What changed

- The publishable package identity is now `hardenx`.
- The runtime package lives under `src/hardenx/`.
- The CLI entrypoint is `hardenx`.
- Runtime assets now ship under `hardenx/data/` and are loaded through package resources.
- Generated reports and transaction manifests are written to an OS-specific state directory instead of inside the package tree.

## Features

- Interactive Rich-based CLI with a main menu for audit, remediation, rollback, and reports.
- Module browser built from the benchmark taxonomy in the CSV baselines, using `(Main, Sub)` instead of numeric prefixes.
- Audit flow that can hand off directly into remediation for the failed controls from that run.
- Guided remediation with metadata-driven rollback support and transaction manifests.
- PDF reports for audit, remediation, and rollback runs.
- Cross-platform install path support, with graceful refusal on unsupported platforms such as macOS.

## Package layout

```text
src/hardenx/
  __main__.py
  cli.py
  catalog.py
  metadata.py
  models.py
  platforms.py
  reporting.py
  transactions.py
  ui_compat.py
  data/
    config/csv/
    scripts/audit/
    scripts/remediation/
docs/
  <platform>/
tests/
```

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install .
```

For an editable install during development:

```bash
pip install -e .
```

## Run

```bash
hardenx
```

You can also run:

```bash
python -m hardenx
```

Supported non-interactive flags:

```bash
hardenx --version
hardenx --state-dir /path/to/state
```

## State directory

HardenX stores reports, rollback backups, and transaction manifests outside the package:

- Linux: `${XDG_STATE_HOME:-~/.local/state}/hardenx`
- macOS: `~/Library/Application Support/HardenX`
- Windows: `%LOCALAPPDATA%\\HardenX`

The directory contains:

```text
reports/
transactions/
backups/
```

## Current behavior

### Audit

- Detects the local platform.
- Loads the matching CSV baseline and packaged audit scripts.
- Browses modules by normalized `(Main, Sub)` groups.
- Runs selected controls and renders a terminal summary.
- Writes an audit PDF report to the state directory.

### Remediation

- Uses the same module browser.
- Restricts guided remediation to controls with both remediation scripts and rollback metadata.
- Supports first-pass argument overrides for:
  - `6.1.7` on Ubuntu/CentOS by splitting encoded values like `300:0`
  - `9.2.6` on Ubuntu with operator prompts
  - `9.1.12` on CentOS with operator prompts
- Records a transaction manifest and HardenX-managed backups before each applied control.
- Writes a remediation PDF report to the state directory.

### Rollback

- Lists saved remediation transactions.
- Restores HardenX-managed backups in reverse order.
- Runs any configured post-restore commands.
- Writes a rollback PDF report and updates the manifest.

## Safety notes

- Audit before remediation.
- Test remediation on non-production systems first.
- Review the platform scripts you plan to run.
- Rollback is guaranteed only for HardenX-managed remediation transactions and only for controls with explicit rollback metadata.
- Windows remediation is currently visible in the catalog, but rollback-capable guided remediation coverage is intentionally conservative.
- Windows 11 audit coverage still lacks audit scripts for control IDs `1.1.3` and `3.3.2`; the catalog surfaces those as missing audit controls.

## Development

Run the unit tests with the standard library test runner:

```bash
python3 -m unittest discover -s tests
```
