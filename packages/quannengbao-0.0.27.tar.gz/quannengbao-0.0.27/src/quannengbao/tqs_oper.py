# coding: utf-8
import os
import re
import time
from datetime import datetime
import bytedtqs
import requests

import logging

logging.basicConfig()
logger = logging.getLogger(__name__)
bytedtqs.client.logger.removeHandler(hdlr=bytedtqs.client.log_handler)


class DuplicateRateLimitFilter(logging.Filter):
    def __init__(self, min_interval=5):
        super().__init__()
        self.min_interval = min_interval  # 最小间隔时间（秒）
        self.last_log_time = {}  # 记录{日志内容: 最后打印时间}

    def filter(self, record):
        log_msg = record.getMessage()  # 获取日志内容
        current_time = time.time()
        # 若该日志从未打印过，或已超过间隔时间，则允许输出
        if log_msg not in self.last_log_time or current_time - self.last_log_time[log_msg] > self.min_interval:
            self.last_log_time[log_msg] = current_time
            return True
        return False


logger.addFilter(DuplicateRateLimitFilter(min_interval=20))


"""
服务器集群队列配置字典
用于支持多国家服务器的TQS连接配置
- cluster_enum: bytedtqs.Cluster 的属性名称
- fallback_enum: 当 cluster_enum 不存在时的备用属性名称
- queues: 集群名称与队列名称的映射
- default_queue: 默认使用的集群名称
- env_vars: 环境变量名称映射，直接指定各服务器所需的环境变量
  - VA_OG/VA: TQS_APP_ID, TQS_APP_KEY, TQS_USER_NAME
  - SG: TQS_APP_ID_SG, TQS_APP_KEY_SG, TQS_USER_NAME_SG

新增国家服务器时，只需在此字典中添加对应配置即可
"""
SERVER_CLUSTER_CONFIG = {
    'VA_OG': {
        'cluster_enum': 'VA_OG',
        'fallback_enum': 'VA',
        'queues': {
            'macaw': 'root.macaw_adhoc',
            'virtual': 'root.virtual_oec_dw_all_va',
            'monkey': 'root.monkey_ecom_ds_public'
        },
        'default_queue': 'virtual',
        'env_vars': {
            'app_id': 'TQS_APP_ID',
            'app_key': 'TQS_APP_KEY',
            'user_name': 'TQS_USER_NAME'
        }
    },
    'VA': {
        'cluster_enum': 'VA',
        'fallback_enum': 'VA',
        'queues': {
            'macaw': 'root.macaw_adhoc',
            'virtual': 'root.virtual_oec_dw_all_va',
            'monkey': 'root.monkey_ecom_ds_public'
        },
        'default_queue': 'virtual',
        'env_vars': {
            'app_id': 'TQS_APP_ID',
            'app_key': 'TQS_APP_KEY',
            'user_name': 'TQS_USER_NAME'
        }
    },
    'SG': {
        'cluster_enum': 'SG',
        'fallback_enum': 'SG',
        'queues': {
            'virtual': 'root.virtual_oec_dw_all_sg'
        },
        'default_queue': 'virtual',
        'env_vars': {
            'app_id': 'TQS_APP_ID_SG',
            'app_key': 'TQS_APP_KEY_SG',
            'user_name': 'TQS_USER_NAME_SG'
        }
    }
}


class TQSAuth():
    """
    TQS认证与连接管理类
    支持多国家服务器的TQS连接，通过server_name参数指定服务器
    集群和队列通过cluster_name参数选择，配置由SERVER_CLUSTER_CONFIG管理
    
    不同服务器使用不同的环境变量：
    - VA_OG/VA: TQS_APP_ID, TQS_APP_KEY, TQS_USER_NAME
    - SG: TQS_APP_ID_SG, TQS_APP_KEY_SG, TQS_USER_NAME_SG
    
    参数:
        app_id: TQS应用ID，默认从对应服务器的环境变量获取
        app_key: TQS应用密钥，默认从对应服务器的环境变量获取
        user_name: 用户名，默认从对应服务器的环境变量获取
        cluster_name: 集群名称，如macaw/virtual/monkey，默认使用服务器配置中的默认值
        server_name: 服务器名称，如VA_OG/VA/SG，默认为VA_OG
    """
    def __init__(self, app_id=None, app_key=None, user_name=None, cluster_name=None, server_name='VA_OG'):
        if server_name not in SERVER_CLUSTER_CONFIG:
            server_name = 'VA_OG'
        
        server_config = SERVER_CLUSTER_CONFIG[server_name]
        env_vars = server_config.get('env_vars', {})
        
        if not app_id:
            env_name = env_vars.get('app_id', 'TQS_APP_ID')
            self.app_id = os.getenv(env_name)
            if not self.app_id:
                raise ValueError(f"app_id 环境变量 {env_name} 获取失败")
        else:
            self.app_id = app_id
        if not app_key:
            env_name = env_vars.get('app_key', 'TQS_APP_KEY')
            self.app_key = os.getenv(env_name)
            if not self.app_key:
                raise ValueError(f"app_key 环境变量 {env_name} 获取失败")
        else:
            self.app_key = app_key
        if not user_name:
            env_name = env_vars.get('user_name', 'TQS_USER_NAME')
            self.user_name = os.getenv(env_name)
            if not self.user_name:
                raise ValueError(f"user_name 环境变量 {env_name} 获取失败")
        else:
            self.user_name = user_name
        
        try:
            self.cluster = getattr(bytedtqs.Cluster, server_config['cluster_enum'])
        except AttributeError:
            self.cluster = getattr(bytedtqs.Cluster, server_config['fallback_enum'])
            print(f'{server_config["cluster_enum"]} 不存在，使用备用集群 {server_config["fallback_enum"]}')

        if cluster_name and cluster_name in server_config['queues']:
            self.cluster_name = cluster_name
            self.queue_name = server_config['queues'][cluster_name]
        else:
            self.cluster_name = server_config['default_queue']
            self.queue_name = server_config['queues'][self.cluster_name]

        self.client = None

    def authenticate(self):
        """显式认证方法"""
        if not self.app_id or not self.app_key:
            raise ValueError("app_id和app_key不能为空")

        self.client = bytedtqs.TQSClient(
            self.app_id,
            self.app_key,
            cluster=self.cluster,
            enable_domain=True
        )
        return self


class MetaOper(TQSAuth):
    def __init__(self, ):
        # 调用父类初始化，参数可为None，使用父类默认值
        super().__init__()
        self.p_hour_str = None
        self.p_date_str = None
        if not self.client:
            self.authenticate()

        self.data = None
        self.result_url = None
        self.partition_str = None

    def query_max_partition(self, schema_table_name):
        sql = f"show partitions {schema_table_name};"
        logger.debug(f'TQS query_max_partition SQL:{sql}')
        # self.client = bytedtqs.TQSClient(self.app_id, self.app_key, cluster=self.cluster, enable_domain=True)
        job = self.client.execute_query(
            user_name=self.user_name,
            query=sql,
            conf={'yarn.cluster.name': self.cluster_name, 'mapreduce.job.queuename': self.queue_name}
        )
        if job.is_success():
            # 任务运行成功
            result = job.get_result()
            self.result_url = result.result_url
            self.data = result.fetch_all_data()

            partition_lst_lst = self.data
            partition_lst = []
            for par_str in partition_lst_lst[1:]:
                if par_str != 'parititon' and not ('test' in par_str[0]):
                    partition_lst.append(par_str[0])
            partition_lst.sort(reverse=True)
            partition_str = partition_lst[0]
            self.partition_str = partition_str
            return partition_str
            # try:
            #     max_partition_str = re.match(pattern='(.*)(\\d{8})(.*)', string=partition_str).group(2)
            #     logger.debug(f'{schema_table_name} max_partition {max_partition_str}')
            #     return max_partition_str
            # except ValueError as error_1:
            #     try:
            #         max_partition_str = re.match(pattern='(.*)([0-9-]{10})(.*)', string=partition_str).group(2)
            #         logger.debug(f'max_partition_str {max_partition_str}')
            #         return max_partition_str
            #     except ValueError as error_2:
            #         logger.critical(f'{schema_table_name} 获取表分区失败：{error_1} {error_2}')
            #         raise ValueError(f'{schema_table_name} 获取表分区失败：{error_1} {error_2}')
        else:
            # 任务运行异常，输出相关日志
            logger.debug(job.analysis_error_message)
            logger.debug(job.query_error_url)
            logger.debug(job.query_log_url)
            logger.debug(job.tracking_urls)


    def get_date_hour_partitions(self, schema_table_name):
        partition_str = self.query_max_partition(schema_table_name)
        try:
            self.p_date_str = re.match(pattern='(.*)(\\d{8})(.*)', string=partition_str).group(2)
        except:
            self.p_date_str = ''
        try:
            self.p_hour_str = re.search(pattern='(.*)hour=(\\d{2})(.*)', string=partition_str).group(2)
        except Exception as e:
            print(e)
            self.p_hour_str = ''
        partition_dct = {'date': self.p_date_str, 'hour': self.p_hour_str}
        return partition_dct

    def query_max_transient_time(self, schema_table_name, timeout=120):
        sql = f"show create table {schema_table_name};"
        logger.debug(f'TQS query_max_transient_time SQL:{sql}')
        # self.client = bytedtqs.TQSClient(self.app_id, self.app_key, cluster=self.cluster, enable_domain=True, timeout=timeout)
        job = self.client.execute_query(
            user_name=self.user_name,
            query=sql,
            conf={'yarn.cluster.name': self.cluster_name, 'mapreduce.job.queuename': self.queue_name}
        )
        if job.is_success():
            # 任务运行成功
            print('job.is_success()')
            result = job.get_result()
            self.result_url = result.result_url
            print('self.result_url = result.result_url')
            self.data = result.fetch_all_data()
            print('self.data = result.fetch_all_data()')
            create_table_str = self.data[1][0]
            try:
                update_timestamp_str = re.search(r"'transient_lastDdlTime' = '(\d{10})'", create_table_str).group(1)
                update_timestamp = int(update_timestamp_str)
                update_dt_str = datetime.fromtimestamp(update_timestamp).strftime('%Y-%m-%d')
                logger.debug(f'{schema_table_name} update_dt:{update_dt_str}')
                return update_dt_str
            except ValueError:
                logger.critical(f'{schema_table_name} 获取表更新时间失败')
                return None

        else:
            # 任务运行异常，输出相关日志
            logger.debug(job.analysis_error_message)
            logger.debug(job.query_error_url)
            logger.debug(job.query_log_url)
            logger.debug(job.tracking_urls)
            return None


class TQSQuery(TQSAuth):
    def __init__(self, server_name='VA'):
        # 调用父类初始化，传递server_name
        super().__init__(server_name=server_name)
        if not self.client:
            self.authenticate()

        self.sql = None
        self.result = None
        self.data = None
        self.result_url = None
        self.query_status = 0

    def execute_query(self, sql=None, sql_path=None, param: dict = None, print_sql=False, to_fetch=True, timeout=1200):
        self.query_status = 0
        if sql:
            pass
        elif not sql_path:
            logger.critical(f'请输入SQL文本或SQL文件路径')
            raise ValueError('请输入SQL文本或SQL文件路径')
        else:
            sql_f = open(sql_path, encoding='utf-8')
            sql = sql_f.read()
            sql_f.close()

        if param:
            param_keys = param.keys()
            for key in param_keys:
                value = param.get(key)
                sql = re.sub(r"\${" + key + "}", repl=value, string=sql)
                logger.debug(f'TQS SQL:{sql}')

        self.sql = sql
        if print_sql:
            print(self.sql)
        # self.client = bytedtqs.TQSClient(self.app_id, self.app_key, cluster=self.cluster, enable_domain=True, timeout=timeout)
        job = self.client.execute_query(
            user_name=self.user_name,
            query=self.sql,
            conf={'yarn.cluster.name': self.cluster_name, 'mapreduce.job.queuename': self.queue_name}
        )
        if job.is_success():
            # 任务运行成功
            result = job.get_result()
            self.result_url = result.result_url
            self.data = result.fetch_all_data() if to_fetch else None
            self.query_status = 1
            logger.info(f'TQS result csv url:{result.result_url}')  # 查询结果的 csv 下载链接

        else:
            # 任务运行异常，输出相关日志
            self.query_status = -1
            logger.debug(job.analysis_error_message)
            logger.debug(job.query_error_url)
            logger.debug(job.query_log_url)
            logger.debug(job.tracking_urls)
        return self

    def save_csv(self, save_path):
        # 发送 GET 请求（stream=True 表示流式下载，适合大文件）
        response = requests.get(self.result_url, stream=True)
        # 检查请求是否成功（状态码 200）
        if response.status_code == 200:
            # 打开文件并写入内容
            with open(save_path, 'wb') as f:
                # 分块写入（每次 1024 字节），避免占用过多内存
                for chunk in response.iter_content(chunk_size=1024):
                    if chunk:  # 过滤空块
                        f.write(chunk)
            print(f"文件下载成功，保存至：{save_path}")
        else:
            print(f"下载失败，状态码：{response.status_code}")
