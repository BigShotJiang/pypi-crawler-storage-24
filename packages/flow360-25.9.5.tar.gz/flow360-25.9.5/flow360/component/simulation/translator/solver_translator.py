"""Flow360 solver setting parameter translator."""

# pylint: disable=too-many-lines
import hashlib
import json
import math as stdlib_math
from typing import Type, Union, get_args

import numpy as np
import unyt as u

from flow360.component.simulation.conversion import (
    LIQUID_IMAGINARY_FREESTREAM_MACH,
    compute_udf_dimensionalization_factor,
)
from flow360.component.simulation.framework.entity_base import EntityList
from flow360.component.simulation.framework.updater_utils import recursive_remove_key
from flow360.component.simulation.models.material import (
    Air,
    Sutherland,
    ThermallyPerfectGas,
    compute_gamma_from_coefficients,
)
from flow360.component.simulation.models.solver_numerics import NoneSolver
from flow360.component.simulation.models.surface_models import (
    Freestream,
    HeatFlux,
    Inflow,
    Mach,
    MassFlowRate,
    Outflow,
    Periodic,
    PorousJump,
    Pressure,
    SlaterPorousBleed,
    SlipWall,
    Supersonic,
    SurfaceModelTypes,
    SymmetryPlane,
    Temperature,
    TotalPressure,
    Translational,
    Wall,
    WallRotation,
    WallVelocityModelTypes,
)
from flow360.component.simulation.models.volume_models import (
    ActuatorDisk,
    AngularVelocity,
    BETDisk,
    Fluid,
    NavierStokesInitialCondition,
    NavierStokesModifiedRestartSolution,
    PorousMedium,
    Rotation,
    Solid,
)
from flow360.component.simulation.operating_condition.operating_condition import (
    LiquidOperatingCondition,
)
from flow360.component.simulation.outputs.output_entities import (
    Point,
    PointArray,
    PointArray2D,
)
from flow360.component.simulation.outputs.output_fields import (
    PREDEFINED_UDF_EXPRESSIONS,
    append_component_to_output_fields,
    generate_predefined_udf,
)
from flow360.component.simulation.outputs.outputs import (
    AeroAcousticOutput,
    ForceDistributionOutput,
    ForceOutput,
    Isosurface,
    IsosurfaceOutput,
    MonitorOutputType,
    ProbeOutput,
    RenderOutput,
    RenderOutputGroup,
    Slice,
    SliceOutput,
    StreamlineOutput,
    SurfaceIntegralOutput,
    SurfaceOutput,
    SurfaceProbeOutput,
    SurfaceSliceOutput,
    TimeAverageForceDistributionOutput,
    TimeAverageIsosurfaceOutput,
    TimeAverageProbeOutput,
    TimeAverageSliceOutput,
    TimeAverageStreamlineOutput,
    TimeAverageSurfaceOutput,
    TimeAverageSurfaceProbeOutput,
    TimeAverageVolumeOutput,
    UserDefinedField,
    VolumeOutput,
)
from flow360.component.simulation.primitives import (
    BOUNDARY_FULL_NAME_WHEN_NOT_FOUND,
    Box,
    GhostCircularPlane,
    GhostSphere,
    GhostSurface,
    GhostSurfacePair,
    ImportedSurface,
    MirroredSurface,
    Surface,
    SurfacePair,
)
from flow360.component.simulation.run_control.stopping_criterion import (
    StoppingCriterion,
)
from flow360.component.simulation.simulation_params import SimulationParams
from flow360.component.simulation.time_stepping.time_stepping import Steady, Unsteady
from flow360.component.simulation.translator.user_expression_utils import (
    udf_prepending_code,
)
from flow360.component.simulation.translator.utils import (
    _get_key_name,
    convert_tuples_to_lists,
    convert_value_to_units,
    get_all_entries_of_type,
    get_global_setting_from_first_instance,
    get_units_from_field,
    has_instance_in_list,
    inline_expressions_in_dict,
    preprocess_input,
    remove_keys,
    remove_units_in_dict,
    replace_dict_key,
    translate_setting_and_apply_to_all_entities,
    translate_value_or_expression_object,
)
from flow360.component.simulation.unit_system import LengthType
from flow360.component.simulation.user_code.core.types import (
    Expression,
    UserVariable,
    _convert_numeric,
    compute_surface_integral_unit,
)
from flow360.component.simulation.user_code.functions import math
from flow360.component.simulation.user_code.variables import solution
from flow360.component.simulation.user_defined_dynamics.user_defined_dynamics import (
    UserDefinedDynamic,
)
from flow360.component.simulation.utils import (
    is_exact_instance,
    is_instance_of_type_in_union,
)
from flow360.exceptions import Flow360TranslationError


def dump_dict(input_params, exclude_none=True):
    """Dumping param/model to dictionary."""

    result = input_params.model_dump(by_alias=True, exclude_none=exclude_none)
    if result.pop("privateAttributeDict", None) is not None:
        result.update(input_params.private_attribute_dict)
    return result


def init_non_average_output(
    base: dict,
    obj_list,
    class_type: Union[SliceOutput, IsosurfaceOutput, VolumeOutput, SurfaceOutput],
):
    """Initialize the common output attribute for non-average output."""
    base["animationFrequency"] = get_global_setting_from_first_instance(
        obj_list,
        class_type,
        "frequency",
    )
    base["animationFrequencyOffset"] = get_global_setting_from_first_instance(
        obj_list,
        class_type,
        "frequency_offset",
    )
    return base


def init_average_output(
    base: dict,
    obj_list,
    class_type: Union[TimeAverageVolumeOutput, TimeAverageSurfaceOutput],
):
    """Initialize the common output attribute for average output."""
    base["animationFrequencyTimeAverage"] = get_global_setting_from_first_instance(
        obj_list,
        class_type,
        "frequency",
    )
    base["animationFrequencyTimeAverageOffset"] = get_global_setting_from_first_instance(
        obj_list,
        class_type,
        "frequency_offset",
    )
    base["startAverageIntegrationStep"] = get_global_setting_from_first_instance(
        obj_list,
        class_type,
        "start_step",
    )
    return base


def init_output_base(obj_list, class_type: Type, is_average: bool):
    """Initialize the common output attribute."""

    base = {"outputFields": []}
    output_format = get_global_setting_from_first_instance(
        obj_list,
        class_type,
        "output_format",
    )
    assert output_format is not None
    if output_format == "both":
        output_format = "paraview,tecplot"
    base["outputFormat"] = output_format

    if is_average:
        base = init_average_output(base, obj_list, class_type)
    else:
        base = init_non_average_output(
            base,
            obj_list,
            class_type,
        )
    return base


def add_unused_output_settings_for_comparison(output_dict: dict):
    """
    Add unused output settings for easier debugging/comparisons.
    """
    for freq_key in ["animationFrequencyTimeAverage", "animationFrequency"]:
        if freq_key not in output_dict:
            output_dict[freq_key] = -1
    for offset_key in ["animationFrequencyTimeAverageOffset", "animationFrequencyOffset"]:
        if offset_key not in output_dict:
            output_dict[offset_key] = 0
    if "startAverageIntegrationStep" not in output_dict:
        output_dict["startAverageIntegrationStep"] = -1
    return output_dict


def rotation_entity_info_serializer(volume):
    """Rotation entity serializer"""
    return {
        "referenceFrame": {
            "axisOfRotation": list(volume.axis),
            "centerOfRotation": list(volume.center.value),
        },
    }


def rotation_translator(model: Rotation, params: SimulationParams):
    """Rotation translator"""
    volume_zone = {
        "modelType": "FluidDynamics",
        "isRotatingReferenceFrame": model.rotating_reference_frame_model,
        "referenceFrame": {},
    }
    if model.parent_volume is not None:
        volume_zone["referenceFrame"]["parentVolumeName"] = model.parent_volume.full_name
    spec = dump_dict(model)["spec"]
    if spec is not None:
        spec_value = spec.get("value", None)
        if isinstance(spec_value, str):
            volume_zone["referenceFrame"]["thetaRadians"] = spec_value
        elif (
            spec_value is not None
            and spec_value.get("units", "") == "flow360_angular_velocity_unit"
        ):
            volume_zone["referenceFrame"]["omegaRadians"] = spec_value["value"]
        elif isinstance(model.spec, AngularVelocity):
            volume_zone["referenceFrame"]["omegaRadians"] = translate_value_or_expression_object(
                model.spec.value, params
            )
    return volume_zone


def translate_output_fields(
    output_model: Union[
        SurfaceOutput,
        TimeAverageSurfaceOutput,
        SliceOutput,
        IsosurfaceOutput,
        ProbeOutput,
        SurfaceIntegralOutput,
        SurfaceProbeOutput,
        SurfaceSliceOutput,
        StreamlineOutput,
        StreamlineOutput,
        TimeAverageStreamlineOutput,
    ],
):
    """Get output fields"""
    output_fields = []

    for item in append_component_to_output_fields(output_model.output_fields.items):
        output_fields.append(item)

    for output_field in output_model.output_fields.items:
        if isinstance(output_field, UserVariable):
            # Remove the UserVariable object and add its name
            output_fields.append(output_field.name)
    # Filter out the UserVariable Dicts
    output_fields = [item for item in output_fields if isinstance(item, str)]
    return {"outputFields": sorted(output_fields)}


def surface_probe_setting_translation_func(entity: Union[SurfaceProbeOutput, SurfaceSliceOutput]):
    """Translate non-entities part of SurfaceProbeOutput"""
    dict_with_merged_output_fields = monitor_translator(entity)
    dict_with_merged_output_fields["surfacePatches"] = [
        surface.full_name
        for surface in entity.target_surfaces.stored_entities
        if surface.full_name != BOUNDARY_FULL_NAME_WHEN_NOT_FOUND
    ]
    return dict_with_merged_output_fields


def monitor_translator(
    output_model: Union[
        ProbeOutput,
        TimeAverageProbeOutput,
        SurfaceProbeOutput,
        TimeAverageSurfaceProbeOutput,
        SurfaceIntegralOutput,
        SurfaceSliceOutput,
    ],
):
    """Monitor translator"""
    monitor_group = translate_output_fields(output_model)
    # Monitor output setting is fine grained to each monitor group. So no need to have different root level keys.
    if not isinstance(output_model, SurfaceSliceOutput):
        monitor_group["computeTimeAverages"] = False
    monitor_group["animationFrequency"] = 1
    monitor_group["animationFrequencyOffset"] = 0
    if isinstance(output_model, (TimeAverageProbeOutput, TimeAverageSurfaceProbeOutput)):
        monitor_group["computeTimeAverages"] = True
        monitor_group["animationFrequencyTimeAverage"] = output_model.frequency
        monitor_group["animationFrequencyTimeAverageOffset"] = output_model.frequency_offset
        monitor_group["startAverageIntegrationStep"] = output_model.start_step
    return monitor_group


def inject_slice_info(entity: Slice):
    """inject entity info"""
    return {
        "sliceOrigin": list(entity.origin.value),
        "sliceNormal": list(entity.normal),
    }


def inject_surface_slice_info(entity: Slice):
    """inject entity info"""
    return {
        "name": entity.name,
        "sliceOrigin": list(entity.origin.value),
        "sliceNormal": list(entity.normal),
    }


def inject_isosurface_info(entity: Isosurface, input_params: SimulationParams):
    """inject entity info"""

    surface_field = entity.field.name if isinstance(entity.field, UserVariable) else entity.field
    surface_magnitude = convert_value_to_units(
        value=entity.iso_value, units=get_units_from_field(entity.field, input_params)
    )

    return_dict = {
        "surfaceField": surface_field,
        "surfaceFieldMagnitude": surface_magnitude,
    }

    if entity.wall_distance_clip_threshold is not None:
        return_dict["wallDistanceClipThreshold"] = entity.wall_distance_clip_threshold.v.item()
    return return_dict


def get_monitor_locations(entities: EntityList):
    """get monitor locations"""

    monitor_locations = {}
    for item in entities:
        if isinstance(item, Point):
            monitor_locations[item.name] = item.location.value.tolist()
        elif isinstance(item, PointArray):
            start = item.start.value
            direction = item.end.value - item.start.value
            for point_idx in range(item.number_of_points):
                point_location = start + point_idx / (item.number_of_points - 1) * direction
                point_name = f"{item.name}_{point_idx}"
                monitor_locations[point_name] = point_location.tolist()

    return monitor_locations


def inject_render_info(entity: Isosurface):
    """inject entity info"""
    return {
        "surfaceField": entity.field,
        "surfaceFieldMagnitude": entity.iso_value,
    }


def inject_probe_info(entity: EntityList):
    """inject entity info"""

    translated_entity_dict = {"type": "probe"}
    translated_entity_dict["monitorLocations"] = get_monitor_locations(entity.stored_entities)

    return translated_entity_dict


def inject_surface_probe_info(entity: EntityList):
    """inject entity info"""

    translated_entity_dict = {"type": "surfaceProbe"}

    translated_entity_dict["monitorLocations"] = get_monitor_locations(entity.stored_entities)

    return translated_entity_dict


def inject_surface_list_info(entity: EntityList):
    """inject entity info"""
    return {
        "surfaces": [
            surface.full_name
            for surface in entity.stored_entities
            if not isinstance(surface, ImportedSurface)
            and surface.full_name != BOUNDARY_FULL_NAME_WHEN_NOT_FOUND
        ],
        "type": "surfaceIntegral",
    }


def _get_coordinate_system_manager_from_params(input_params: "SimulationParams"):
    """Extract and rebuild CoordinateSystemManager from SimulationParams asset cache.

    Parameters
    ----------
    input_params : SimulationParams
        The simulation parameters containing coordinate system status.

    Returns
    -------
    CoordinateSystemManager or None
        The reconstructed manager, or None if no coordinate system info is available.
    """
    if not input_params or not input_params.private_attribute_asset_cache:
        return None

    coord_status = input_params.private_attribute_asset_cache.coordinate_system_status
    if not coord_status:
        return None

    # pylint: disable=import-outside-toplevel
    from flow360.component.simulation.draft_context.coordinate_system_manager import (
        CoordinateSystemManager,
    )

    return CoordinateSystemManager._from_status(  # pylint: disable=protected-access
        status=coord_status
    )


def inject_imported_surface_info(entity: ImportedSurface, coordinate_system_manager=None):
    """inject entity info"""
    result = {
        "meshFile": entity.file_name,
    }

    # Add transformation matrix if entity has coordinate system assignment
    if coordinate_system_manager is not None:
        matrix = (
            coordinate_system_manager._get_matrix_for_entity(  # pylint: disable=protected-access
                entity=entity
            )
        )
        if matrix is not None:
            # Convert 3x4 numpy array to list for JSON serialization
            result["transformationMatrix"] = matrix.tolist()

    return result


def translate_imported_surface_integral_output(
    output_params: list,
    coordinate_system_manager=None,
):
    """Translate imported surface integral output settings."""
    translated_output = {
        "animationFrequency": -1,
        "animationFrequencyOffset": 0,
    }

    translated_output["surfaces"] = translate_setting_and_apply_to_all_entities(
        output_params,
        SurfaceIntegralOutput,
        translation_func=translate_output_fields,
        entity_injection_func=inject_imported_surface_info,
        to_list=False,
        entity_type_to_include=ImportedSurface,
        entity_injection_coordinate_system_manager=coordinate_system_manager,
    )

    return translated_output


def translate_volume_output(
    output_params: list, volume_output_class: Union[VolumeOutput, TimeAverageVolumeOutput]
):
    """Translate volume output settings."""
    volume_output = init_output_base(
        output_params,
        volume_output_class,
        is_average=volume_output_class is TimeAverageVolumeOutput,
    )
    # Get outputFields
    output_fields = []
    fields = get_global_setting_from_first_instance(
        output_params, volume_output_class, "output_fields"
    )
    output_fields = append_component_to_output_fields(fields.model_dump()["items"])

    for output_field in fields.items:
        if isinstance(output_field, UserVariable):
            output_fields.append(output_field.name)
    # Filter out the UserVariable Dicts
    output_fields = [item for item in output_fields if isinstance(item, str)]
    volume_output.update(
        {
            "outputFields": sorted(output_fields),
        }
    )
    return volume_output


def translate_imported_surface_output(
    output_params: list,
    surface_output_class: Union[SurfaceOutput, TimeAverageSurfaceOutput],
    coordinate_system_manager=None,
):
    """Translate imported surface output settings."""

    imported_surface_output = init_output_base(
        output_params,
        surface_output_class,
        is_average=surface_output_class is TimeAverageSurfaceOutput,
    )

    imported_surface_output["surfaces"] = translate_setting_and_apply_to_all_entities(
        output_params,
        surface_output_class,
        translation_func=translate_output_fields,
        entity_injection_func=inject_imported_surface_info,
        to_list=False,
        entity_type_to_include=ImportedSurface,
        entity_injection_coordinate_system_manager=coordinate_system_manager,
    )
    return imported_surface_output


def translate_surface_output(
    output_params: list,
    surface_output_class: Union[SurfaceOutput, TimeAverageSurfaceOutput],
    translated: dict,
):
    """Translate surface output settings."""

    assert "boundaries" in translated  #  "Boundaries must be translated before surface output"

    surface_output = init_output_base(
        output_params,
        surface_output_class,
        is_average=surface_output_class is TimeAverageSurfaceOutput,
    )
    surface_output["surfaces"] = translate_setting_and_apply_to_all_entities(
        output_params,
        surface_output_class,
        translation_func=translate_output_fields,
        to_list=False,
        entity_type_to_include=(
            Surface,
            GhostSurface,
            GhostSphere,
            GhostCircularPlane,
            MirroredSurface,
        ),
    )
    surface_output["writeSingleFile"] = get_global_setting_from_first_instance(
        output_params,
        surface_output_class,
        "write_single_file",
    )
    return surface_output


def translate_slice_output(
    output_params: list,
    output_class: Union[SliceOutput, TimeAverageSliceOutput],
    injection_function,
):
    """Translate slice or isosurface output settings."""
    translated_output = init_output_base(
        output_params,
        output_class,
        is_average=output_class is TimeAverageSliceOutput,
    )
    translated_output["slices"] = translate_setting_and_apply_to_all_entities(
        output_params,
        output_class,
        translation_func=translate_output_fields,
        to_list=False,
        entity_injection_func=injection_function,
    )
    return translated_output


def translate_isosurface_output(
    input_params: SimulationParams,
    output_class: Union[IsosurfaceOutput, TimeAverageIsosurfaceOutput],
    output_params: list,
    injection_function,
):
    """Translate slice or isosurface output settings."""
    translated_output = init_output_base(
        output_params,
        output_class,
        is_average=output_class is TimeAverageIsosurfaceOutput,
    )
    translated_output["isoSurfaces"] = translate_setting_and_apply_to_all_entities(
        output_params,
        output_class,
        translation_func=translate_output_fields,
        to_list=False,
        entity_injection_func=injection_function,
        entity_injection_input_params=input_params,
    )
    return translated_output


def translate_render_output(
    input_params: SimulationParams,
    output_params: list,
    isosurface_injection_function,
    slice_injection_function,
):
    """Translate render output settings."""

    renders = get_all_entries_of_type(output_params, RenderOutput)

    translated_outputs = []

    for render in renders:
        render_dict = dump_dict(render)
        render_dict = remove_units_in_dict(render_dict)

        environment_dict = render_dict["environment"]
        if environment_dict["background"]["typeName"] == "SkyboxBackground":
            environment_dict["background"]["type"] = "skybox"
        elif environment_dict["background"]["typeName"] == "SolidBackground":
            environment_dict["background"]["type"] = "solid"

        camera_dict = render_dict["camera"]
        if camera_dict["projection"]["typeName"] == "OrthographicProjection":
            camera_dict["projection"]["type"] = "orthographic"
        elif camera_dict["projection"]["typeName"] == "PerspectiveProjection":
            camera_dict["projection"]["type"] = "perspective"

        render_dict = remove_keys(render_dict, "typeName")

        translated_output = {
            "name": render.name,
            "animationFrequency": render.frequency,
            "animationFrequencyOffset": render.frequency_offset,
            "groups": [],
            "camera": render_dict["camera"],
            "lighting": render_dict["lighting"],
            "environment": render_dict["environment"],
        }

        for render_group in render.groups:
            material = render_group.material

            material_dict = dump_dict(material)
            material_dict = inline_expressions_in_dict(material_dict, input_params)
            material_dict = remove_units_in_dict(material_dict)

            if material_dict["typeName"] == "PBRMaterial":
                material_dict["type"] = "pbr"
            elif material_dict["typeName"] == "FieldMaterial":
                material_dict["type"] = "field"

            material_dict = remove_keys(material_dict, "typeName")

            translated_output["groups"].append(
                {
                    "surfaces": translate_setting_and_apply_to_all_entities(
                        [render_group],
                        RenderOutputGroup,
                        to_list=False,
                        entity_type_to_include=(Surface, MirroredSurface),
                        entity_list_field_name="surfaces",
                    ),
                    "slices": translate_setting_and_apply_to_all_entities(
                        [render_group],
                        RenderOutputGroup,
                        to_list=False,
                        entity_injection_func=slice_injection_function,
                        entity_type_to_include=Slice,
                        entity_list_field_name="slices",
                    ),
                    "isoSurfaces": translate_setting_and_apply_to_all_entities(
                        [render_group],
                        RenderOutputGroup,
                        to_list=False,
                        entity_injection_func=isosurface_injection_function,
                        entity_type_to_include=Isosurface,
                        entity_list_field_name="isosurfaces",
                        entity_injection_input_params=input_params,
                    ),
                    "material": remove_units_in_dict(material_dict),
                }
            )
        if render.transform:
            transform = dump_dict(render.transform)
            translated_output["transform"] = remove_units_in_dict(transform)

        translated_outputs.append(translated_output)

    return translated_outputs


def translate_surface_slice_output(
    output_params: list,
    output_class: Union[SurfaceSliceOutput],
):
    """Translate surface output settings."""

    surface_slice_output = init_output_base(
        output_params,
        output_class,
        is_average=False,
    )
    surface_slice_output["slices"] = translate_setting_and_apply_to_all_entities(
        output_params,
        output_class,
        translation_func=surface_probe_setting_translation_func,
        to_list=True,
        entity_injection_func=inject_surface_slice_info,
    )
    return surface_slice_output


def translate_monitor_output(
    output_params: list,
    monitor_type,
    injection_function,
    translation_func=monitor_translator,
):
    """Translate monitor output settings."""
    translated_output = {"outputFields": []}
    translated_output["monitors"] = translate_setting_and_apply_to_all_entities(
        output_params,
        monitor_type,
        translation_func=translation_func,
        to_list=False,
        entity_injection_func=injection_function,
        lump_list_of_entities=True,
        use_instance_name_as_key=True,
        entity_type_to_include=(
            (Surface, GhostSurface, GhostSphere, GhostCircularPlane, MirroredSurface)
            if monitor_type is SurfaceIntegralOutput
            else None
        ),
    )
    return translated_output


def merge_monitor_output(probe_output: dict, integral_output: dict):
    """Merge probe and surface integral output."""
    if probe_output == {}:
        return integral_output
    if integral_output == {}:
        return probe_output

    for integral_output_name, integral_output_value in integral_output["monitors"].items():
        assert integral_output_name not in probe_output["monitors"]
        probe_output["monitors"][integral_output_name] = integral_output_value
    return probe_output


def translate_acoustic_output(output_params: list):
    """Translate acoustic output settings."""
    aeroacoustic_output = {}
    for output in output_params:
        if isinstance(output, AeroAcousticOutput):
            aeroacoustic_output["observers"] = [
                item.position.value.tolist() for item in output.observers
            ]
            aeroacoustic_output["writePerSurfaceOutput"] = output.write_per_surface_output
            aeroacoustic_output["patchType"] = output.patch_type
            if output.permeable_surfaces is not None:
                aeroacoustic_output["permeableSurfaces"] = [
                    item.full_name
                    for item in output.permeable_surfaces.stored_entities
                    if item.full_name != BOUNDARY_FULL_NAME_WHEN_NOT_FOUND
                ]
            if output.observer_time_step_size:
                aeroacoustic_output["observerTimeStepSize"] = (
                    output.observer_time_step_size.v.item()
                )
            aeroacoustic_output["startTime"] = output.aeroacoustic_solver_start_time.v.item()
            aeroacoustic_output["newRun"] = output.force_clean_start
            return aeroacoustic_output
    return None


def _expand_entity_list(entity_list, input_params) -> list:
    """Expand an entity list, handling both stored entities and selectors."""
    # pylint: disable=import-outside-toplevel
    from flow360.component.simulation.framework.entity_expansion_utils import (
        expand_entity_list_in_context,
    )

    return expand_entity_list_in_context(entity_list, input_params, return_names=False)


def _get_wall_bc_surface_names(input_params) -> list:
    """Get all surface names that have Wall boundary conditions assigned."""
    # pylint: disable=import-outside-toplevel
    from flow360.component.simulation.validation.validation_utils import (
        get_surface_full_name,
    )

    surface_names = []
    for bc in input_params.models:
        if isinstance(bc, Wall) and bc.entities is not None:
            expanded_entities = _expand_entity_list(bc.entities, input_params)
            for entity in expanded_entities:
                surface_names.append(get_surface_full_name(entity, "force distribution output"))
    return surface_names


def translate_force_distribution_output(output_params: list, input_params):
    """Translate force distribution output settings."""
    # pylint: disable=import-outside-toplevel
    from flow360.component.simulation.validation.validation_utils import (
        get_surface_full_name,
    )

    force_distribution_output = {}
    for output in output_params:
        if is_exact_instance(output, ForceDistributionOutput):
            config = {
                "direction": list(output.distribution_direction),
                "type": output.distribution_type,
            }
            # Add surfaces - use specified entities or all surfaces with Wall BC
            if output.entities is not None:
                expanded_entities = _expand_entity_list(output.entities, input_params)
                surface_names = [
                    get_surface_full_name(entity, "force distribution output")
                    for entity in expanded_entities
                ]
            else:
                surface_names = _get_wall_bc_surface_names(input_params)
            config["surfaces"] = surface_names
            # Add number of segments
            config["numberOfSegments"] = output.number_of_segments
            force_distribution_output[output.name] = config
    return force_distribution_output


def translate_time_averaged_force_distribution_output(output_params: list, input_params):
    """Translate time-averaged force distribution output settings."""
    # pylint: disable=import-outside-toplevel
    from flow360.component.simulation.validation.validation_utils import (
        get_surface_full_name,
    )

    time_averaged_force_distribution_output = {}
    for output in output_params:
        if isinstance(output, TimeAverageForceDistributionOutput):
            config = {
                "direction": list(output.distribution_direction),
                "type": output.distribution_type,
                "startAverageIntegrationStep": output.start_step,
            }
            # Add surfaces - use specified entities or all surfaces with Wall BC
            if output.entities is not None:
                expanded_entities = _expand_entity_list(output.entities, input_params)
                surface_names = [
                    get_surface_full_name(entity, "force distribution output")
                    for entity in expanded_entities
                ]
            else:
                surface_names = _get_wall_bc_surface_names(input_params)
            config["surfaces"] = surface_names
            # Add number of segments
            config["numberOfSegments"] = output.number_of_segments
            time_averaged_force_distribution_output[output.name] = config
    return time_averaged_force_distribution_output


def user_variable_to_udf(
    variable: UserVariable, input_params: SimulationParams
):  # pylint:disable=too-many-branches
    # pylint:disable=too-many-statements
    """Convert user variable to UDF"""
    if not isinstance(variable.value, Expression):
        expression = Expression.model_validate(_convert_numeric(variable.value))
    else:
        expression = variable.value

    def _prepare_prepending_code(expression: Expression):
        prepending_code = []
        for name in sorted(expression.solver_variable_names(recursive=True)):
            if not udf_prepending_code.get(name):
                continue
            if name == "solution.temperature" and input_params.has_solid():
                prepending_code.append(udf_prepending_code["solution.temperature_solid"])
                continue
            prepending_code.append(udf_prepending_code[name])
        prepending_code = "".join(prepending_code)
        return prepending_code

    requested_unit: Union[u.Unit, None] = expression.get_output_units(input_params=input_params)
    if requested_unit is None:
        # Number constant output requested
        coefficient = 1
        offset = 0
    else:
        coefficient, offset = compute_udf_dimensionalization_factor(
            params=input_params,
            requested_unit=requested_unit,
            using_liquid_op=isinstance(input_params.operating_condition, LiquidOperatingCondition),
        )

    expression_length = expression.length
    prepending_code = _prepare_prepending_code(expression=expression)
    if expression_length == 0:  # Scalar output requested
        expression = expression.evaluate(raise_on_non_evaluable=False, force_evaluate=False)
        if offset != 0:
            expression = (expression + offset) * coefficient
        else:
            expression = expression * coefficient
        if not isinstance(expression, Expression):
            # Enforce constant as Expression
            expression = Expression.model_validate(_convert_numeric(expression))
        expression = expression.to_solver_code(params=input_params)
        return UserDefinedField(
            name=variable.name, expression=f"{prepending_code}{variable.name} = " + expression + ";"
        )

    # Vector output requested
    expression = [
        expression[i].evaluate(raise_on_non_evaluable=False, force_evaluate=False)
        for i in range(expression_length)
    ]
    if offset != 0:
        expression = [(item + offset) * coefficient for item in expression]
    else:
        expression = [item * coefficient for item in expression]
    for i, item in enumerate(expression):
        if isinstance(item, Expression):
            expression[i] = item.to_solver_code(params=input_params)
        else:
            expression[i] = Expression.model_validate(_convert_numeric(item)).to_solver_code(
                params=input_params
            )

    expression = [f"{variable.name}[{i}] = " + item for i, item in enumerate(expression)]
    return UserDefinedField(
        name=variable.name, expression=prepending_code + "; ".join(expression) + ";"
    )


def process_output_fields_for_udf(input_params: SimulationParams):
    # pylint:disable=too-many-branches
    """
    Process all output fields from different output types and generate additional
    UserDefinedFields for dimensioned fields.

    Args:
        input_params: SimulationParams object containing outputs configuration

    Returns:
        tuple: (all_field_names, generated_udfs) where:
            - all_field_names is a set of all output field names
            - generated_udfs is a list of UserDefinedField objects for dimensioned fields
    """

    # Collect all output field names from all output types
    all_field_names = set()

    if input_params.outputs:
        for output in input_params.outputs:
            if hasattr(output, "output_fields") and output.output_fields:
                all_field_names.update(
                    append_component_to_output_fields(output.output_fields.items)
                )
            if isinstance(output, IsosurfaceOutput):
                for isosurface in output.entities.items:
                    if isosurface.field in PREDEFINED_UDF_EXPRESSIONS:
                        all_field_names.add(isosurface.field)

    if isinstance(input_params.operating_condition, LiquidOperatingCondition):
        all_field_names.add("velocity_magnitude")

    # Generate UDFs for dimensioned fields
    generated_udfs = []
    for field_name in all_field_names:
        udf_expression = generate_predefined_udf(field_name, input_params)
        if udf_expression:
            generated_udfs.append(UserDefinedField(name=field_name, expression=udf_expression))

    # UserVariable handling:
    user_variable_udfs = {}
    if input_params.outputs:
        for output in input_params.outputs:
            if hasattr(output, "output_fields") and output.output_fields:
                for output_field in output.output_fields.items:
                    if not isinstance(output_field, UserVariable):
                        continue
                    udf_from_user_variable = user_variable_to_udf(output_field, input_params)
                    user_variable_udfs[udf_from_user_variable.name] = udf_from_user_variable
            if isinstance(output, IsosurfaceOutput):
                for isosurface in output.entities.items:
                    if not isinstance(isosurface.field, UserVariable):
                        continue
                    udf_from_user_variable = user_variable_to_udf(isosurface.field, input_params)
                    user_variable_udfs[udf_from_user_variable.name] = udf_from_user_variable
    return generated_udfs, list(user_variable_udfs.values())


def translate_streamline_output(output_params: list, streamline_class):
    """Translate streamline output settings."""
    streamline_output = {
        "Points": [],
        "PointArrays": [],
        "PointArrays2D": [],
        "outputFields": [],
        "animationFrequency": -1,
        "animationFrequencyOffset": 0,
    }
    for output in output_params:
        if isinstance(output, streamline_class):
            streamline_output["outputFields"] = translate_output_fields(output)["outputFields"]
            # streamline_output["outputFields"].extend(output.output_fields.items)
            if isinstance(output, TimeAverageStreamlineOutput):
                streamline_output["startAverageIntegrationStep"] = output.start_step
                streamline_output["animationFrequencyTimeAverage"] = -1
                streamline_output["animationFrequencyTimeAverageOffset"] = 0

            for entity in output.entities.stored_entities:
                if isinstance(entity, Point):
                    point = {"name": entity.name, "location": entity.location.value.tolist()}
                    streamline_output["Points"].append(point)
                elif isinstance(entity, PointArray):
                    line = {
                        "name": entity.name,
                        "start": entity.start.value.tolist(),
                        "end": entity.end.value.tolist(),
                        "numberOfPoints": entity.number_of_points,
                    }
                    streamline_output["PointArrays"].append(line)
                elif isinstance(entity, PointArray2D):
                    parallelogram = {
                        "name": entity.name,
                        "origin": entity.origin.value.tolist(),
                        "uAxisVector": entity.u_axis_vector.value.tolist(),
                        "vAxisVector": entity.v_axis_vector.value.tolist(),
                        "uNumberOfPoints": entity.u_number_of_points,
                        "vNumberOfPoints": entity.v_number_of_points,
                    }
                    streamline_output["PointArrays2D"].append(parallelogram)

    return streamline_output


def process_output_field_for_integral(output_field, input_params):
    """Multiply UserVariable by area for surface integrals"""
    if isinstance(output_field, UserVariable):
        expression = Expression.model_validate(output_field.value)
        if expression.length == 0:
            expression_processed = expression * math.magnitude(solution.node_area_vector)
        else:
            expression_processed = [
                expression[i] * math.magnitude(solution.node_area_vector)
                for i in range(expression.length)
            ]
        new_unit = compute_surface_integral_unit(output_field, input_params)
        user_variable = UserVariable(
            name=output_field.name + "_integral",
            value=expression_processed,
        ).in_units(new_unit)
        return user_variable
    return output_field


def process_user_variables_for_integral(
    outputs,
    input_params,
):
    """Process UserVariable output fields for surface integrals."""
    for output in outputs:
        if not isinstance(output, SurfaceIntegralOutput):
            continue
        output_fields_processed = []
        for output_field in output.output_fields.items:
            output_fields_processed.append(
                process_output_field_for_integral(
                    output_field=output_field, input_params=input_params
                )
            )
        output.output_fields.items = output_fields_processed


def translate_output(input_params: SimulationParams, translated: dict):
    # pylint: disable=too-many-branches,too-many-statements,too-many-locals
    """Translate output settings."""
    outputs = input_params.outputs

    if outputs is None:
        return translated

    # Extract coordinate system manager once for reuse across all output translations
    coordinate_system_manager = _get_coordinate_system_manager_from_params(input_params)
    ##:: Step1: Get translated["volumeOutput"/"timeAverageVolumeOutput"]
    volume_output_configs = [
        (VolumeOutput, "volumeOutput"),
        (TimeAverageVolumeOutput, "timeAverageVolumeOutput"),
    ]

    for output_class, output_key in volume_output_configs:
        if has_instance_in_list(outputs, output_class):
            volume_output = translate_volume_output(outputs, output_class)
            if volume_output:
                translated[output_key] = add_unused_output_settings_for_comparison(volume_output)

    ##:: Step2: Get translated["surfaceOutput"]
    surface_output_configs = [
        (SurfaceOutput, "surfaceOutput"),
        (TimeAverageSurfaceOutput, "timeAverageSurfaceOutput"),
    ]
    for output_class, output_key in surface_output_configs:
        if has_instance_in_list(outputs, output_class):
            surface_output = translate_surface_output(outputs, output_class, translated)
            if surface_output:
                translated[output_key] = add_unused_output_settings_for_comparison(surface_output)

    ##:: Step3: Get translated["sliceOutput"]
    slice_output_configs = [
        (SliceOutput, "sliceOutput"),
        (TimeAverageSliceOutput, "timeAverageSliceOutput"),
    ]
    for output_class, output_key in slice_output_configs:
        if has_instance_in_list(outputs, output_class):
            slice_output = translate_slice_output(outputs, output_class, inject_slice_info)
            if slice_output:
                translated[output_key] = add_unused_output_settings_for_comparison(slice_output)

    ##:: Step4: Get translated["isoSurfaceOutput"]
    iso_surface_output_configs = [
        (IsosurfaceOutput, "isoSurfaceOutput"),
        (TimeAverageIsosurfaceOutput, "timeAverageIsoSurfaceOutput"),
    ]
    for output_class, output_key in iso_surface_output_configs:
        if has_instance_in_list(outputs, output_class):
            translated[output_key] = translate_isosurface_output(
                input_params, output_class, outputs, inject_isosurface_info
            )

    ##:: Step5: Get translated["importedSurfaceOutput"]
    if has_instance_in_list(outputs, SurfaceOutput):
        imported_surface_output_configs = translate_imported_surface_output(
            outputs,
            SurfaceOutput,
            coordinate_system_manager,
        )
        if imported_surface_output_configs["surfaces"]:
            translated["importedSurfaceOutput"] = imported_surface_output_configs
    if has_instance_in_list(outputs, TimeAverageSurfaceOutput):
        imported_surface_output_configs = translate_imported_surface_output(
            outputs,
            TimeAverageSurfaceOutput,
            coordinate_system_manager,
        )
        if imported_surface_output_configs["surfaces"]:
            translated["timeAverageImportedSurfaceOutput"] = imported_surface_output_configs

    ##:: Step6: Get translated["renderOutput"]
    if has_instance_in_list(outputs, RenderOutput):
        translated["renderOutput"] = translate_render_output(
            input_params, outputs, inject_isosurface_info, inject_slice_info
        )

    ##:: Step7: Get translated["monitorOutput"]
    probe_output = {}
    probe_output_average = {}
    integral_output = {}
    if has_instance_in_list(outputs, ProbeOutput):
        probe_output = translate_monitor_output(outputs, ProbeOutput, inject_probe_info)
    if has_instance_in_list(outputs, TimeAverageProbeOutput):
        probe_output_average = translate_monitor_output(
            outputs, TimeAverageProbeOutput, inject_probe_info
        )

    if has_instance_in_list(outputs, SurfaceIntegralOutput):
        process_user_variables_for_integral(outputs, input_params)
        integral_output = translate_monitor_output(
            outputs, SurfaceIntegralOutput, inject_surface_list_info
        )
    # Merge
    if probe_output or probe_output_average:
        probe_output = merge_monitor_output(probe_output, probe_output_average)
    if probe_output or integral_output:
        translated["monitorOutput"] = merge_monitor_output(probe_output, integral_output)

    ##:: Step7.1: Get translated["surfaceMonitorOutput"]
    surface_monitor_output = {}
    surface_monitor_output_average = {}
    if has_instance_in_list(outputs, SurfaceProbeOutput):
        surface_monitor_output = translate_monitor_output(
            outputs,
            SurfaceProbeOutput,
            inject_surface_probe_info,
            surface_probe_setting_translation_func,
        )
    if has_instance_in_list(outputs, TimeAverageSurfaceProbeOutput):
        surface_monitor_output_average = translate_monitor_output(
            outputs,
            TimeAverageSurfaceProbeOutput,
            inject_surface_probe_info,
            surface_probe_setting_translation_func,
        )
    if surface_monitor_output or surface_monitor_output_average:
        translated["surfaceMonitorOutput"] = merge_monitor_output(
            surface_monitor_output, surface_monitor_output_average
        )

    ##:: Step8: Get translated["surfaceSliceOutput"]
    surface_slice_output = {}
    if has_instance_in_list(outputs, SurfaceSliceOutput):
        surface_slice_output = translate_surface_slice_output(outputs, SurfaceSliceOutput)
        translated["surfaceSliceOutput"] = surface_slice_output

    ##:: Step9: Get translated["aeroacousticOutput"]
    if has_instance_in_list(outputs, AeroAcousticOutput):
        translated["aeroacousticOutput"] = translate_acoustic_output(outputs)

    ##:: Step10: Get translated["streamlineOutput"]
    if has_instance_in_list(outputs, StreamlineOutput):
        translated["streamlineOutput"] = translate_streamline_output(outputs, StreamlineOutput)

    if has_instance_in_list(outputs, TimeAverageStreamlineOutput):
        translated["timeAverageStreamlineOutput"] = translate_streamline_output(
            outputs, TimeAverageStreamlineOutput
        )

    ##:: Step11: Get translated["importedSurfaceIntegralOutput"]
    if has_instance_in_list(outputs, SurfaceIntegralOutput):
        imported_surface_integral_output_configs = translate_imported_surface_integral_output(
            outputs,
            coordinate_system_manager,
        )
        if imported_surface_integral_output_configs["surfaces"]:
            translated["importedSurfaceIntegralOutput"] = imported_surface_integral_output_configs

    ##:: Step10: Get translated["forceDistributionOutput"]
    if has_instance_in_list(outputs, ForceDistributionOutput):
        translated["forceDistributionOutput"] = translate_force_distribution_output(
            outputs, input_params
        )

    ##:: Step10b: Get translated["timeAveragedForceDistributionOutput"]
    if has_instance_in_list(outputs, TimeAverageForceDistributionOutput):
        translated["timeAveragedForceDistributionOutput"] = (
            translate_time_averaged_force_distribution_output(outputs, input_params)
        )

    ##:: Step11: Sort all "output_fields" everywhere
    # Recursively sort all "outputFields" lists in the translated dict
    def _sort_output_fields_in_dict(d):
        if isinstance(d, dict):
            for k, v in d.items():
                if k == "outputFields" and isinstance(v, list):
                    v.sort()
                else:
                    _sort_output_fields_in_dict(v)
        elif isinstance(d, list):
            for item in d:
                _sort_output_fields_in_dict(item)

    _sort_output_fields_in_dict(translated)

    return translated


def porous_media_entity_info_serializer(volume):
    """Porous media entity serializer"""
    if isinstance(volume, Box):
        axes = volume.private_attribute_input_cache.axes
        return {
            "zoneType": "box",
            "axes": [list(axes[0]), list(axes[1])],
            "center": volume.center.value.tolist(),
            "lengths": volume.size.value.tolist(),
        }

    axes = volume.axes
    return {
        "zoneType": "mesh",
        "zoneName": volume.full_name,
        "axes": [list(axes[0]), list(axes[1])],
    }


def porous_media_translator(model: PorousMedium):
    """Porous media translator"""
    model_dict = remove_units_in_dict(dump_dict(model))
    porous_medium = {
        "DarcyCoefficient": list(model_dict["darcyCoefficient"]),
        "ForchheimerCoefficient": list(model_dict["forchheimerCoefficient"]),
    }
    if model.volumetric_heat_source is not None:
        porous_medium["volumetricHeatSource"] = model_dict["volumetricHeatSource"]

    return porous_medium


def gravity_translator(gravity):
    """Gravity translator - produces gravityVector from direction and non-dimensional magnitude.

    The output gravityVector has the magnitude baked into the direction:
    gravityVector = magnitude_nondim * normalized_direction
    """
    gravity_dict = remove_units_in_dict(dump_dict(gravity))
    magnitude = gravity_dict["magnitude"]
    direction = list(gravity.direction)

    gravity_vector = [magnitude * d for d in direction]

    return {
        "gravityVector": gravity_vector,
    }


def bet_disk_entity_info_serializer(volume):
    """BET disk entity serializer"""
    v = convert_tuples_to_lists(remove_units_in_dict(dump_dict(volume)))
    return {
        "axisOfRotation": v["axis"],
        "centerOfRotation": v["center"],
        "radius": v["outerRadius"],
        "thickness": v["height"],
    }


def bet_disk_translator(model: BETDisk, is_unsteady: bool):
    """BET disk translator"""
    model_dict = convert_tuples_to_lists(remove_units_in_dict(dump_dict(model)))
    model_dict["alphas"] = [alpha.to("degree").value.item() for alpha in model.alphas]
    model_dict["twists"] = [
        {
            "radius": bet_twist.radius.value.item(),
            "twist": bet_twist.twist.to("degree").value.item(),
        }
        for bet_twist in model.twists
    ]
    disk_param = {
        "rotationDirectionRule": model_dict["rotationDirectionRule"],
        "numberOfBlades": model_dict["numberOfBlades"],
        "omega": model_dict["omega"],
        "chordRef": model_dict["chordRef"],
        "nLoadingNodes": model_dict["nLoadingNodes"],
        "twists": model_dict["twists"],
        "chords": model_dict["chords"],
        "sectionalPolars": model_dict["sectionalPolars"],
        "sectionalRadiuses": model_dict["sectionalRadiuses"],
        "alphas": model_dict["alphas"],
        "MachNumbers": model_dict["machNumbers"],
        "ReynoldsNumbers": model_dict["reynoldsNumbers"],
        "tipGap": model_dict["tipGap"],
    }

    if is_unsteady:
        # Unsteady BET Line
        disk_param["bladeLineChord"] = model_dict["bladeLineChord"]
        if "initialBladeDirection" in model_dict:
            disk_param["initialBladeDirection"] = model_dict["initialBladeDirection"]
    else:
        # Steady BET Disk
        disk_param["bladeLineChord"] = 0

    return disk_param


def actuator_disk_entity_info_serializer(volume):
    """Actuator disk entity serializer"""
    v = convert_tuples_to_lists(remove_units_in_dict(dump_dict(volume)))
    return {
        "axisThrust": v["axis"],
        "center": v["center"],
        "thickness": v["height"],
        "name": v["name"],
    }


def actuator_disk_translator(model: ActuatorDisk):
    """Actuator disk translator"""
    result = {
        "forcePerArea": convert_tuples_to_lists(
            remove_units_in_dict(dump_dict(model.force_per_area))
        )
    }
    if model.reference_velocity is not None:
        ref_vel = remove_units_in_dict(
            model.model_dump(by_alias=True, include={"reference_velocity"})
        )
        result["referenceVelocity"] = convert_tuples_to_lists(ref_vel["referenceVelocity"])
    return result


def get_solid_zone_boundaries(volume, solid_zone_boundaries: set):
    """Store solid zone boundaries in a set"""
    if volume.private_attribute_zone_boundary_names is not None:
        for boundary in volume.private_attribute_zone_boundary_names.items:
            solid_zone_boundaries.add(boundary)
    else:
        raise Flow360TranslationError(
            f"boundary_name is required but not found in"
            f"`{volume.__name__}` instances in Solid model. \n[For developers]: This error message should not appear."
            "SimulationParams should have caught this!!!",
            input_value=volume,
            location=["models"],
        )

    return {}


def heat_transfer_volume_zone_translator(model: Solid):
    """Heat transfer volume zone translator"""
    model_dict = remove_units_in_dict(dump_dict(model))
    volume_zone = {
        "modelType": "HeatTransfer",
        "thermalConductivity": model_dict["material"]["thermalConductivity"],
    }
    if model.volumetric_heat_source:
        volume_zone["volumetricHeatSource"] = model_dict["volumetricHeatSource"]
    if model.material.specific_heat_capacity and model.material.density:
        volume_zone["heatCapacity"] = (
            model_dict["material"]["density"] * model_dict["material"]["specificHeatCapacity"]
        )
    if model.initial_condition:
        volume_zone["initialCondition"] = {
            "T": model_dict["initialCondition"]["temperature"],
            "T_solid": model_dict["initialCondition"]["temperature"],
        }
    return volume_zone


def boundary_entity_info_serializer(entity, translated_setting, solid_zone_boundaries):
    """Boundary entity info serializer"""
    output = {}
    if isinstance(entity, (SurfacePair, GhostSurfacePair)):
        key1 = _get_key_name(entity.pair[0])
        key2 = _get_key_name(entity.pair[1])
        if BOUNDARY_FULL_NAME_WHEN_NOT_FOUND in (key1, key2):
            return None
        output[key1] = {**translated_setting, "pairedPatchName": key2}
        output[key2] = translated_setting
    else:
        key_name = _get_key_name(entity)
        if key_name == BOUNDARY_FULL_NAME_WHEN_NOT_FOUND:
            return None
        output = {key_name: {**translated_setting}}
        if key_name in solid_zone_boundaries:
            if "temperature" in translated_setting:
                output[key_name]["type"] = "SolidIsothermalWall"
            elif "heatFlux" in translated_setting:
                output[key_name]["type"] = "SolidIsofluxWall"
            else:
                output[key_name]["type"] = "SolidAdiabaticWall"
            if "roughnessHeight" in translated_setting:
                output[key_name].pop("roughnessHeight")
    return output


def _append_turbulence_quantities_to_dict(model, model_dict, boundary):
    """If the boundary model has turbulence quantities, add it to the boundary dict"""
    if model.turbulence_quantities is not None:
        boundary["turbulenceQuantities"] = model_dict["turbulenceQuantities"]
        replace_dict_key(boundary["turbulenceQuantities"], "typeName", "modelType")
    return boundary


def _get_default_mass_outflow_udd(entities, mass_flow_rate):
    """Default mass outflow UDD translator"""
    proportional_coefficient = 1.0e-2
    udd_list = []
    for entity in entities.stored_entities:
        udd = UserDefinedDynamic(
            name=f"massOutflowController_{entity.name}",
            input_vars=["massFlowRate", "area", "hasSupersonicFlow"],
            constants={
                "massFlowRateTarget": mass_flow_rate,
                "Kp": proportional_coefficient,
                "initialStaticPressureRatio": 1.0,
            },
            output_vars={"staticPressureRatio": "state[0];"},
            state_vars_initial_value=["initialStaticPressureRatio"],
            update_law=[
                "(pseudoStep > 0) ? ("
                "(hasSupersonicFlow and massFlowRate > 0) ? ((1.0 + Kp) * state[0]) : (state[0] + "
                "Kp * (massFlowRate/area - massFlowRateTarget/area))"
                ") : (state[0]);"
            ],
            input_boundary_patches=entities.stored_entities,
            output_target=entity,
        )
        udd_list.append(udd)

    return udd_list


def _get_default_mass_inflow_udd(entities, mass_flow_rate):
    """Default mass inflow UDD translator"""
    proportional_coefficient = 1.0e-2
    udd_list = []
    for entity in entities.stored_entities:
        udd = UserDefinedDynamic(
            name=f"massInflowController_{entity.name}",
            input_vars=["massFlowRate", "area", "hasSupersonicFlow"],
            constants={
                "massFlowRateTarget": mass_flow_rate,
                "Kp": proportional_coefficient,
                "initialTotalPressureRatio": 1.0,
            },
            output_vars={"totalPressureRatio": "state[0];"},
            state_vars_initial_value=["initialTotalPressureRatio"],
            update_law=[
                "(pseudoStep > 0) ? ("
                "(hasSupersonicFlow and massFlowRate > 0) ? ((1.0 - Kp) * state[0]) : (state[0] - "
                "Kp * (massFlowRate/area - massFlowRateTarget/area))"
                ") : (state[0]);"
            ],
            input_boundary_patches=entities.stored_entities,
            output_target=entity,
        )
        udd_list.append(udd)

    return udd_list


def mass_flow_default_udd(models, user_defined_dynamics):
    """Default mass flow rate translator"""
    mass_flow_user_defined_dynamics = []
    for model in models:
        if isinstance(model, Outflow):
            if isinstance(model.spec, MassFlowRate):
                udd = _get_default_mass_outflow_udd(model.entities, model.spec.value)
                mass_flow_user_defined_dynamics.extend(udd)
        elif isinstance(model, Inflow):
            if isinstance(model.spec, MassFlowRate):
                udd = _get_default_mass_inflow_udd(model.entities, model.spec.value)
                mass_flow_user_defined_dynamics.extend(udd)

    if len(mass_flow_user_defined_dynamics) == 0:
        return user_defined_dynamics

    if user_defined_dynamics is None:
        user_defined_dynamics = []

    user_defined_dynamics.extend(mass_flow_user_defined_dynamics)
    return user_defined_dynamics


# pylint: disable=too-many-branches, too-many-statements
def boundary_spec_translator(model: SurfaceModelTypes, op_acoustic_to_static_pressure_ratio):
    """Boundary translator"""
    model_dict = remove_units_in_dict(dump_dict(model))
    boundary = {}
    if isinstance(model, Wall):
        if model.use_wall_function is not None:
            boundary["type"] = "WallFunction"
            boundary["wallModelType"] = model.use_wall_function.wall_function_type
        else:
            boundary["type"] = "NoSlipWall"
        if model.velocity is not None:
            if not is_instance_of_type_in_union(model.velocity, WallVelocityModelTypes):
                boundary["velocity"] = list(model_dict["velocity"])
            elif isinstance(model.velocity, SlaterPorousBleed):
                boundary["wallVelocityModel"] = {}
                boundary["wallVelocityModel"]["staticPressureRatio"] = (
                    model.velocity.static_pressure.value * op_acoustic_to_static_pressure_ratio
                )
                boundary["wallVelocityModel"]["porosity"] = model.velocity.porosity
                boundary["wallVelocityModel"]["type"] = model.velocity.type_name
                if model.velocity.activation_step is not None:
                    boundary["wallVelocityModel"]["activationStep"] = model.velocity.activation_step
            elif isinstance(model.velocity, WallRotation):
                omega = model.velocity.angular_velocity.value
                axis = model.velocity.axis
                center = model.velocity.center.value
                boundary["velocity"] = [
                    f"{omega * axis[1]} * (z - {center[2]}) - {omega * axis[2]} * (y - {center[1]})",
                    f"{omega * axis[2]} * (x - {center[0]}) - {omega * axis[0]} * (z - {center[2]})",
                    f"{omega * axis[0]} * (y - {center[1]}) - {omega * axis[1]} * (x - {center[0]})",
                ]
            else:
                raise Flow360TranslationError(
                    f"Unsupported wall velocity setting found with type: {type(model.velocity)}",
                    input_value=model,
                    location=["models"],
                )
        if isinstance(model.heat_spec, Temperature):
            boundary["temperature"] = model_dict["heatSpec"]["value"]
        elif isinstance(model.heat_spec, HeatFlux):
            boundary["heatFlux"] = model_dict["heatSpec"]["value"]
        boundary["roughnessHeight"] = model_dict["roughnessHeight"]
        if model.private_attribute_dict is not None:
            boundary = {**boundary, **model.private_attribute_dict}
    elif isinstance(model, Inflow):
        boundary["totalTemperatureRatio"] = model_dict["totalTemperature"]
        if model.velocity_direction is not None:
            boundary["velocityDirection"] = list(model_dict["velocityDirection"])
        if isinstance(model.spec, TotalPressure):
            boundary["type"] = "SubsonicInflow"
            total_pressure_ratio = model_dict["spec"]["value"]
            if isinstance(model.spec.value, str):
                # Expression specifies total pressure in Flow360 nondim units (P/(ρa²)),
                # convert to ratio (P/P∞) by multiplying by ρa²/P∞
                total_pressure_ratio = (
                    f"({total_pressure_ratio}) * {op_acoustic_to_static_pressure_ratio}"
                )
            else:
                total_pressure_ratio *= op_acoustic_to_static_pressure_ratio
            boundary["totalPressureRatio"] = total_pressure_ratio
        if isinstance(model.spec, Supersonic):
            boundary["type"] = "SupersonicInflow"
            boundary["totalPressureRatio"] = (
                model_dict["spec"]["totalPressure"] * op_acoustic_to_static_pressure_ratio
            )
            boundary["staticPressureRatio"] = (
                model_dict["spec"]["staticPressure"] * op_acoustic_to_static_pressure_ratio
            )

        elif isinstance(model.spec, MassFlowRate):
            boundary["type"] = "MassInflow"
            boundary["massFlowRate"] = model_dict["spec"]["value"]
            if model.spec.ramp_steps is not None:
                boundary["rampSteps"] = model_dict["spec"]["rampSteps"]
        boundary = _append_turbulence_quantities_to_dict(model, model_dict, boundary)
    elif isinstance(model, Outflow):
        if isinstance(model.spec, Pressure):
            boundary["type"] = "SubsonicOutflowPressure"
            boundary["staticPressureRatio"] = (
                model_dict["spec"]["value"] * op_acoustic_to_static_pressure_ratio
            )
        elif isinstance(model.spec, Mach):
            boundary["type"] = "SubsonicOutflowMach"
            boundary["MachNumber"] = model_dict["spec"]["value"]
        elif isinstance(model.spec, MassFlowRate):
            boundary["type"] = "MassOutflow"
            boundary["massFlowRate"] = model_dict["spec"]["value"]
            if model.spec.ramp_steps is not None:
                boundary["rampSteps"] = model_dict["spec"]["rampSteps"]
    elif isinstance(model, Periodic):
        boundary["type"] = (
            "TranslationallyPeriodic"
            if isinstance(model.spec, Translational)
            else "RotationallyPeriodic"
        )
    elif isinstance(model, SlipWall):
        boundary["type"] = "SlipWall"
    elif isinstance(model, Freestream):
        boundary["type"] = "Freestream"
        if model.velocity is not None:
            boundary["velocity"] = list(model_dict["velocity"])
        boundary = _append_turbulence_quantities_to_dict(model, model_dict, boundary)
    elif isinstance(model, SymmetryPlane):
        boundary["type"] = "SymmetryPlane"
    elif isinstance(model, PorousJump):
        boundary["type"] = "PorousJump"
        boundary["DarcyCoefficient"] = model_dict["darcyCoefficient"]
        boundary["ForchheimerCoefficient"] = model_dict["forchheimerCoefficient"]
        boundary["porousJumpThickness"] = model_dict["thickness"]

    return boundary


def get_navier_stokes_initial_condition(
    initial_condition: Union[NavierStokesInitialCondition, NavierStokesModifiedRestartSolution],
):
    """Translate the initial condition for NavierStokes"""
    if is_exact_instance(initial_condition, NavierStokesInitialCondition):
        initial_condition_dict = {
            "type": "initialCondition",
        }
    elif is_exact_instance(initial_condition, NavierStokesModifiedRestartSolution):
        initial_condition_dict = {
            "type": "restartManipulation",
        }
    else:
        raise Flow360TranslationError(
            f"Invalid NavierStokes initial condition type: {type(initial_condition)}",
            input_value=initial_condition,
            location=["models"],
        )
    raw_dict = dump_dict(initial_condition)
    for key in ["rho", "u", "v", "w", "p", "constants"]:
        if key not in raw_dict:  # not set
            continue
        initial_condition_dict[key] = raw_dict[key]
    return initial_condition_dict


def rename_modeling_constants(modeling_constants):
    """Rename the modeling constants to what the solver reads"""
    if modeling_constants.get("typeName", None) == "SpalartAllmarasConsts":
        replace_dict_key(modeling_constants, "CDES", "C_DES")
        replace_dict_key(modeling_constants, "CD", "C_d")
        replace_dict_key(modeling_constants, "CCb1", "C_cb1")
        replace_dict_key(modeling_constants, "CCb2", "C_cb2")
        replace_dict_key(modeling_constants, "CSigma", "C_sigma")
        replace_dict_key(modeling_constants, "CV1", "C_v1")
        replace_dict_key(modeling_constants, "CVonKarman", "C_vonKarman")
        replace_dict_key(modeling_constants, "CW2", "C_w2")
        replace_dict_key(modeling_constants, "CW4", "C_w4")
        replace_dict_key(modeling_constants, "CW5", "C_w5")
        replace_dict_key(modeling_constants, "CT3", "C_t3")
        replace_dict_key(modeling_constants, "CT4", "C_t4")
        replace_dict_key(modeling_constants, "CMinRd", "C_min_rd")

    if modeling_constants.get("typeName", None) == "kOmegaSSTConsts":
        replace_dict_key(modeling_constants, "CDES1", "C_DES1")
        replace_dict_key(modeling_constants, "CDES2", "C_DES2")
        replace_dict_key(modeling_constants, "CD1", "C_d1")
        replace_dict_key(modeling_constants, "CD2", "C_d2")
        replace_dict_key(modeling_constants, "CSigmaK1", "C_sigma_k1")
        replace_dict_key(modeling_constants, "CSigmaK2", "C_sigma_k2")
        replace_dict_key(modeling_constants, "CSigmaOmega1", "C_sigma_omega1")
        replace_dict_key(modeling_constants, "CSigmaOmega2", "C_sigma_omega2")
        replace_dict_key(modeling_constants, "CAlpha1", "C_alpha1")
        replace_dict_key(modeling_constants, "CBeta1", "C_beta1")
        replace_dict_key(modeling_constants, "CBeta2", "C_beta2")
        replace_dict_key(modeling_constants, "CBetaStar", "C_beta_star")

    modeling_constants.pop("typeName")  # Not read by solver


def update_controls_modeling_constants(controls, translated):
    """Upading the modelingConstants entries for each control"""
    if controls is not None:
        for control in translated["turbulenceModelSolver"]["controls"]:
            control_modeling_constants = control.get("modelingConstants", None)
            if control_modeling_constants is None:
                continue
            rename_modeling_constants(control_modeling_constants)
            control["modelConstants"] = control.pop("modelingConstants")


def require_external_postprocessing(params: SimulationParams):
    """Check if external postprocessing needed."""
    if params.models:
        for model in params.models:
            if isinstance(model, (BETDisk, ActuatorDisk, PorousMedium)):
                return True
    if params.outputs:
        for output in params.outputs:
            if not isinstance(output, get_args(get_args(MonitorOutputType)[0])):
                continue
            if (
                isinstance(output, (ProbeOutput, SurfaceProbeOutput))
                and output.moving_statistic is None
            ):
                continue
            if (
                isinstance(output, SurfaceIntegralOutput)
                and output.moving_statistic is None
                and all(
                    not isinstance(surface, ImportedSurface)
                    for surface in output.entities.stored_entities
                )
            ):
                continue
            return True
    return False


def calculate_monitor_semaphore_hash(params: SimulationParams):
    """Get the hash for monitor processor's semaphore"""

    def get_force_output_models(force_output: ForceOutput, params: SimulationParams):
        force_output_model_ids = {
            (model.private_attribute_id if hasattr(model, "private_attribute_id") else model)
            for model in force_output.models
        }
        force_output_models = [
            model for model in params.models if model.private_attribute_id in force_output_model_ids
        ]
        return force_output_models

    json_string_list = []
    if params.outputs:
        for output in params.outputs:
            if not isinstance(output, get_args(get_args(MonitorOutputType)[0])):
                continue
            if isinstance(output, ForceOutput):
                force_output_models = get_force_output_models(output, params)
                force_output_models_dict = []
                for model in force_output_models:
                    model_dict = dump_dict(model)
                    recursive_remove_key(
                        model_dict, "privateAttributeId", "privateAttributeInputCache"
                    )
                    force_output_models_dict.append(json.dumps(model_dict))
                json_string_list.extend(force_output_models_dict)
                json_string_list.extend(output.output_fields.items)
            if output.moving_statistic is not None:
                json_string_list.append(json.dumps(dump_dict(output.moving_statistic)))
    combined_string = "".join(sorted(json_string_list))
    hasher = hashlib.sha256()
    hasher.update(combined_string.encode("utf-8"))
    return hasher.hexdigest()


def get_stop_criterion_settings(criterion: StoppingCriterion, params: SimulationParams):
    """Get the stop criterion settings"""

    def get_criterion_monitored_file_info(monitor_output, monitor_field):
        # pylint: disable=fixme
        # TODO: Add instance function to control the output metadata generation for each output type.
        monitor_output_name = monitor_output.name.replace("/", "_")
        monitored_column = None
        monitored_dataset_name = None
        if isinstance(monitor_output, (ProbeOutput, SurfaceProbeOutput)):
            point = monitor_output.entities.stored_entities[0]
            monitored_column = f"{monitor_output.name}_{point.name}_{str(monitor_field)}"
            monitored_dataset_name = f"monitor_{monitor_output_name}"
        if isinstance(monitor_output, SurfaceIntegralOutput):
            monitored_column = f"{str(monitor_field)}"
            monitored_dataset_name = f"monitor_{monitor_output_name}"
        if isinstance(monitor_output, ForceOutput):
            monitored_column = f"total{monitor_field}"
            monitored_dataset_name = f"force_output_{monitor_output_name}"

        if monitor_output.moving_statistic is not None:
            monitored_column += f"_{monitor_output.moving_statistic.method}"
            monitored_dataset_name += "_moving_statistic"
        return monitored_dataset_name, monitored_column

    def get_criterion_tolerance_info(criterion_tolerance, monitor_field, params):
        source_units = get_units_from_field(monitor_field, params)
        flow360_unit_system = params.flow360_unit_system
        if source_units.dimensions == u.dimensions.angle:
            flow360_unit_system["angle"] = source_units.units
        flow360_units = source_units.get_base_equivalent(flow360_unit_system)

        criterion_tolerance_nondim = convert_value_to_units(
            value=criterion_tolerance, units=flow360_units
        )
        source_to_flow360_coeff, source_to_flow360_offset = source_units.get_conversion_factor(
            flow360_units, dtype=np.float64
        )
        source_to_flow360_offset = (
            0.0
            if source_to_flow360_offset is None
            else -source_to_flow360_offset / source_to_flow360_coeff
        )

        return criterion_tolerance_nondim, source_to_flow360_coeff, source_to_flow360_offset

    criterion_monitor_output = None
    for output in params.outputs:
        if (
            hasattr(output, "private_attribute_id")
            and output.private_attribute_id == criterion.monitor_output
        ):
            criterion_monitor_output = output
            break

    criterion_monitor_field = (
        process_output_field_for_integral(criterion.monitor_field, params)
        if isinstance(criterion_monitor_output, SurfaceIntegralOutput)
        else criterion.monitor_field
    )

    criterion_dataset_name, criterion_column = get_criterion_monitored_file_info(
        monitor_output=criterion_monitor_output, monitor_field=criterion_monitor_field
    )
    criterion_tolerance_nondim, source_to_flow360_coeff, source_to_flow360_offset = (
        get_criterion_tolerance_info(
            criterion_tolerance=criterion.tolerance,
            monitor_field=criterion_monitor_field,
            params=params,
        )
    )

    return {
        "monitoredColumn": criterion_column,
        "monitoredDatasetName": criterion_dataset_name,
        "tolerance": criterion_tolerance_nondim,
        "toleranceWindowSize": criterion.tolerance_window_size,
        "sourceToFlow360Coefficient": source_to_flow360_coeff,
        "sourceToFlow360Offset": source_to_flow360_offset,
    }


def _compute_enthalpy_no_a7(coeffs, temperature):
    """
    Compute h/R at given temperature without the a7 integration constant.

    h/R = -a0/T + a1*ln(T) + a2*T + (a3/2)*T^2 + (a4/3)*T^3 + (a5/4)*T^4 + (a6/5)*T^5

    Parameters
    ----------
    coeffs : list
        NASA 9 coefficients [a0, a1, a2, a3, a4, a5, a6, a7, a8]
    temperature : float
        Temperature in Kelvin

    Returns
    -------
    float
        Enthalpy divided by gas constant (h/R) without a7 term
    """
    temp = temperature
    return (
        -coeffs[0] / temp
        + stdlib_math.log(temp) * coeffs[1]
        + coeffs[2] * temp
        + (coeffs[3] / 2) * temp**2
        + (coeffs[4] / 3) * temp**3
        + (coeffs[5] / 4) * temp**4
        + (coeffs[6] / 5) * temp**5
    )


def _compute_a7_correction(coeffs: list, reference_temperature: float) -> float:
    """
    Compute the corrected a7 coefficient for Flow360 non-dimensionalization.

    The NASA polynomial a7 (enthalpy integration constant) is calibrated for absolute
    dimensional enthalpy (h=0 at some reference temperature like 0K or 298.15K).
    However, Flow360's non-dimensionalization expects internal energy to be consistent
    with the ideal gas equation of state: e = cv * T at T_ref.

    This function computes a corrected a7 so that at T_nd = 1 (T = T_ref):
        h_nd/R = gamma/(gamma-1)  (ideal gas non-dimensional enthalpy)
        e_nd/R = 1/(gamma-1)      (ideal gas non-dimensional internal energy)

    The gamma at T_ref is computed directly from the polynomial:
        cp/R = a0*T^-2 + a1*T^-1 + a2 + a3*T + a4*T^2 + a5*T^3 + a6*T^4
        cv/R = cp/R - 1
        gamma = cp/cv = (cp/R) / (cp/R - 1)

    IMPORTANT: The ln(T) term requires special handling. Under non-dimensionalization
    T -> T_nd = T/T_ref, we have ln(T) = ln(T_nd) + ln(T_ref). At T_nd = 1, ln(T_nd) = 0,
    so the a1*ln(T_ref) contribution must be absorbed into a7 to maintain consistency:
        a7_corrected = a7_for_h_target + a1*ln(T_ref)

    Parameters
    ----------
    coeffs : list
        Dimensional NASA 9 coefficients [a0, a1, a2, a3, a4, a5, a6, a7, a8]
    reference_temperature : float
        Reference temperature for non-dimensionalization (in K)

    Returns
    -------
    float
        Corrected dimensional a7 coefficient (with ln(T_ref) term absorbed)
    """
    temp = reference_temperature

    # Compute gamma at T_ref using shared utility function
    gamma = compute_gamma_from_coefficients(coeffs, temp)

    # Compute h/R at T_ref without the a7 term using shared utility function
    h_no_a7 = _compute_enthalpy_no_a7(coeffs, temp)

    # Target h/R at T_ref for ideal gas with computed gamma
    # h/R = cp/R * T = (gamma/(gamma-1)) * T
    h_target = (gamma / (gamma - 1)) * temp

    # Base a7 correction ensures h_polynomial = h_target at T_ref (dimensional)
    a7_base = h_target - h_no_a7

    # Absorb the a1*ln(T_ref) term into a7
    # Under non-dimensionalization, ln(T) = ln(T_nd * T_ref) = ln(T_nd) + ln(T_ref)
    # At T_nd = 1, ln(T_nd) = 0, so the a1*ln(T_ref) constant must be in a7
    a7_corrected = a7_base + coeffs[1] * stdlib_math.log(temp)

    return a7_corrected


def _nondimensionalize_coefficients(coeffs: list, reference_temperature: float) -> list:
    """
    Non-dimensionalize NASA 9 coefficients for Flow360.

    Transforms coefficients for T_internal = T_dim / T_ref.

    Parameters
    ----------
    coeffs : list
        Dimensional NASA 9 coefficients [a0, a1, a2, a3, a4, a5, a6, a7, a8]
        Note: a7 should already be corrected via _compute_a7_correction
    reference_temperature : float
        Reference temperature for non-dimensionalization (in K)

    Returns
    -------
    list
        Non-dimensionalized coefficients
    """
    t_ref = reference_temperature
    t_ref_inv = 1.0 / reference_temperature
    return [
        coeffs[0] * t_ref_inv**2,  # a0 (T^-2): scale by (1/T_ref)^2
        coeffs[1] * t_ref_inv,  # a1 (T^-1): scale by (1/T_ref)
        coeffs[2],  # a2 (constant): no scaling
        coeffs[3] * t_ref,  # a3 (T^1): scale by T_ref
        coeffs[4] * t_ref**2,  # a4 (T^2): scale by T_ref^2
        coeffs[5] * t_ref**3,  # a5 (T^3): scale by T_ref^3
        coeffs[6] * t_ref**4,  # a6 (T^4): scale by T_ref^4
        coeffs[7] * t_ref_inv,  # a7 (enthalpy const): scale by (1/T_ref)
        coeffs[8],  # a8 (entropy, constant): no scaling
    ]


def translate_thermally_perfect_gas(  # pylint: disable=too-many-locals
    tpg: ThermallyPerfectGas,
    reference_temperature: float,
):
    """
    Translate multi-species thermally perfect gas to Flow360 format.

    Combines NASA 9-coefficient polynomials from multiple species weighted by mass fraction.
    For each coefficient, the mixture value is computed as:
        a_mixture[i] = sum(mass_fraction[j] * a[j][i] for all species j)

    This assumes all species share the same temperature range boundaries (validated in
    ThermallyPerfectGas class).

    IMPORTANT: The a7 coefficient is automatically corrected to ensure internal energy
    consistency with Flow360's non-dimensionalization. The NASA polynomial a7 is
    calibrated for absolute enthalpy, but Flow360 expects e = cv*T at T_ref.

    Parameters
    ----------
    tpg : ThermallyPerfectGas
        Multi-species thermally perfect gas model with species and mass fractions
    reference_temperature : float
        Reference temperature for non-dimensionalization (in K)

    Returns
    -------
    dict
        Non-dimensionalized NASA 9-coefficient data for Flow360.json with mass-fraction
        weighted coefficients
    """
    # Use first species as template for temperature ranges (all validated to match)
    ref_ranges = tpg.species[0].nasa_9_coefficients.temperature_ranges

    # Find the temperature range that contains reference_temperature and compute a7 shift
    # Using a single global shift preserves enthalpy continuity across all ranges
    a7_shift = None
    for range_idx, ref_range in enumerate(ref_ranges):
        t_min = ref_range.temperature_range_min.to("K").v.item()
        t_max = ref_range.temperature_range_max.to("K").v.item()
        if t_min <= reference_temperature <= t_max:
            # Combine coefficients for this range
            combined_coeffs_ref = [0.0] * 9
            for species in tpg.species:
                species_coeffs = species.nasa_9_coefficients.temperature_ranges[
                    range_idx
                ].coefficients
                for i in range(9):
                    combined_coeffs_ref[i] += species.mass_fraction * species_coeffs[i]
            a7_corrected = _compute_a7_correction(combined_coeffs_ref, reference_temperature)
            a7_shift = a7_corrected - combined_coeffs_ref[7]
            break

    # Fallback to first range if reference_temperature is outside all ranges
    if a7_shift is None:
        combined_coeffs_ref = [0.0] * 9
        for species in tpg.species:
            species_coeffs = species.nasa_9_coefficients.temperature_ranges[0].coefficients
            for i in range(9):
                combined_coeffs_ref[i] += species.mass_fraction * species_coeffs[i]
        a7_corrected = _compute_a7_correction(combined_coeffs_ref, reference_temperature)
        a7_shift = a7_corrected - combined_coeffs_ref[7]

    temperature_ranges = []
    for range_idx, ref_range in enumerate(ref_ranges):
        # Combine coefficients weighted by mass fraction
        combined_coeffs = [0.0] * 9
        for species in tpg.species:
            species_coeffs = species.nasa_9_coefficients.temperature_ranges[range_idx].coefficients
            for i in range(9):
                combined_coeffs[i] += species.mass_fraction * species_coeffs[i]

        # Apply the same a7 shift to all ranges for Flow360 non-dimensionalization
        combined_coeffs[7] = combined_coeffs[7] + a7_shift

        # Non-dimensionalize coefficients and append to ranges
        temperature_ranges.append(
            {
                "temperatureRangeMin": ref_range.temperature_range_min.to("K").v.item()
                / reference_temperature,
                "temperatureRangeMax": ref_range.temperature_range_max.to("K").v.item()
                / reference_temperature,
                "coefficients": _nondimensionalize_coefficients(
                    combined_coeffs, reference_temperature
                ),
            }
        )

    # Note: gasConstant (R = 1/gamma_ref) is computed by the C++ solver from
    # the coefficients at T=1, so we don't need to pass it here.
    return {"temperatureRanges": temperature_ranges}


# pylint: disable=too-many-statements
# pylint: disable=too-many-branches
# pylint: disable=too-many-locals
@preprocess_input
def get_solver_json(
    input_params: SimulationParams,
    # pylint: disable=no-member,unused-argument
    mesh_unit: LengthType.Positive,
):
    """
    Get the solver json from the simulation parameters.
    """

    translated = {}
    ##:: Step 1: Get geometry:
    if input_params.reference_geometry:
        geometry = inline_expressions_in_dict(
            dump_dict(input_params.reference_geometry), input_params
        )
        geometry = remove_units_in_dict(geometry, skip_keys=["private_attribute_area_settings"])
        translated["geometry"] = {}
        if input_params.reference_geometry.area is not None:
            translated["geometry"]["refArea"] = geometry["area"]
        if input_params.reference_geometry.moment_center is not None:
            translated["geometry"]["momentCenter"] = list(geometry["momentCenter"])
        if input_params.reference_geometry.moment_length is not None:
            ml = geometry["momentLength"]
            translated["geometry"]["momentLength"] = (
                list(ml) if isinstance(ml, tuple) else [ml, ml, ml]
            )

    ##:: Step 2: Get freestream
    op = input_params.operating_condition
    # check if all units are flow360:
    _ = remove_units_in_dict(dump_dict(op))
    translated["freestream"] = {
        "alphaAngle": op.alpha.to("degree").v.item() if "alpha" in op.__class__.model_fields else 0,
        "betaAngle": op.beta.to("degree").v.item() if "beta" in op.__class__.model_fields else 0,
        "Mach": translate_value_or_expression_object(op.velocity_magnitude, input_params),
        "Temperature": (
            op.thermal_state.temperature.to("K").v.item()
            if not isinstance(op, LiquidOperatingCondition)
            and isinstance(op.thermal_state.material.dynamic_viscosity, Sutherland)
            else -1
        ),
        "muRef": (
            op.thermal_state.dynamic_viscosity.in_base(input_params.flow360_unit_system).v.item()
            if not isinstance(op, LiquidOperatingCondition)
            else op.material.dynamic_viscosity.in_base(input_params.flow360_unit_system).v.item()
        ),
    }

    ##:: Step 2.5: Get NASA 9-coefficient polynomial for gas model (Air material)
    # Always output thermallyPerfectGasModel for Air - even for CPG (constant gamma=1.4),
    # which uses default NASA9 coefficients [0, 0, 3.5, 0, 0, 0, 0, 0, 0]
    if not isinstance(op, LiquidOperatingCondition) and isinstance(op.thermal_state.material, Air):
        # Get reference temperature for non-dimensionalization (freestream temperature)
        reference_temperature = op.thermal_state.temperature.to("K").v.item()

        # Translate thermally perfect gas model
        translated["thermallyPerfectGasModel"] = translate_thermally_perfect_gas(
            op.thermal_state.material.thermally_perfect_gas,
            reference_temperature,
        )

    # Export Prandtl numbers from material
    if isinstance(op, LiquidOperatingCondition):
        translated["fluidProperties"] = {
            "prandtlNumber": 7.0,
            "turbulentPrandtlNumber": 0.9,
        }
    elif isinstance(op.thermal_state.material, Air):
        translated["fluidProperties"] = {
            "prandtlNumber": op.thermal_state.material.prandtl_number,
            "turbulentPrandtlNumber": op.thermal_state.material.turbulent_prandtl_number,
        }

    if (
        "reference_velocity_magnitude" in op.__class__.model_fields.keys()
        and op.reference_velocity_magnitude
    ):
        translated["freestream"]["MachRef"] = op.reference_velocity_magnitude.v.item()
    op_acoustic_to_static_pressure_ratio = (
        (
            op.thermal_state.density
            * op.thermal_state.speed_of_sound**2
            / op.thermal_state.pressure
        ).value
        if not isinstance(op, LiquidOperatingCondition)
        else 1.0
    )

    ##:: Step 5: Get timeStepping
    ts = input_params.time_stepping
    if isinstance(ts, Unsteady):
        translated["timeStepping"] = {
            "CFL": dump_dict(ts.CFL),
            "physicalSteps": ts.steps,
            "orderOfAccuracy": ts.order_of_accuracy,
            "maxPseudoSteps": ts.max_pseudo_steps,
            "timeStepSize": translate_value_or_expression_object(ts.step_size, input_params),
        }
    elif isinstance(ts, Steady):
        translated["timeStepping"] = {
            "CFL": dump_dict(ts.CFL),
            "physicalSteps": 1,
            "orderOfAccuracy": 2,  # Solver always want to read this even if it is steady... Setting dummy value here.
            "maxPseudoSteps": ts.max_steps,
            "timeStepSize": "inf",
        }
    dump_dict(input_params.time_stepping)

    ##:: Step 6: Get solver settings and initial condition
    for model in input_params.models:
        if isinstance(model, Fluid):
            if isinstance(op, LiquidOperatingCondition):
                model.navier_stokes_solver.low_mach_preconditioner = True
                model.navier_stokes_solver.low_mach_preconditioner_threshold = (
                    LIQUID_IMAGINARY_FREESTREAM_MACH
                )
            if (
                model.navier_stokes_solver.low_mach_preconditioner
                and model.navier_stokes_solver.low_mach_preconditioner_threshold is None
            ):
                model.navier_stokes_solver.low_mach_preconditioner_threshold = (
                    input_params.operating_condition.mach
                )
            translated["navierStokesSolver"] = dump_dict(model.navier_stokes_solver)

            replace_dict_key(translated["navierStokesSolver"], "typeName", "modelType")
            if isinstance(op, LiquidOperatingCondition) and not (
                model.navier_stokes_solver.private_attribute_dict is not None
                and "typeName" in model.navier_stokes_solver.private_attribute_dict
            ):
                translated["navierStokesSolver"]["modelType"] = "CompressibleIsentropic"
            replace_dict_key(
                translated["navierStokesSolver"],
                "equationEvaluationFrequency",
                "equationEvalFrequency",
            )

            translated["turbulenceModelSolver"] = dump_dict(model.turbulence_model_solver)
            replace_dict_key(
                translated["turbulenceModelSolver"],
                "equationEvaluationFrequency",
                "equationEvalFrequency",
            )
            replace_dict_key(translated["turbulenceModelSolver"], "typeName", "modelType")
            modeling_constants = translated["turbulenceModelSolver"].get("modelingConstants", None)
            if modeling_constants is not None:
                rename_modeling_constants(modeling_constants)
                translated["turbulenceModelSolver"]["modelConstants"] = translated[
                    "turbulenceModelSolver"
                ].pop("modelingConstants")

            if not isinstance(model.turbulence_model_solver, NoneSolver):
                hybrid_model = model.turbulence_model_solver.hybrid_model
                if hybrid_model is not None:
                    if hybrid_model.shielding_function == "DDES":
                        translated["turbulenceModelSolver"]["DDES"] = True
                        translated["turbulenceModelSolver"]["ZDES"] = False
                    if hybrid_model.shielding_function == "ZDES":
                        translated["turbulenceModelSolver"]["ZDES"] = True
                        translated["turbulenceModelSolver"]["DDES"] = False
                    translated["turbulenceModelSolver"][
                        "gridSizeForLES"
                    ] = hybrid_model.grid_size_for_LES
                    translated["turbulenceModelSolver"].pop("hybridModel")
                else:
                    translated["turbulenceModelSolver"]["DDES"] = False
                    translated["turbulenceModelSolver"]["ZDES"] = False
                    translated["turbulenceModelSolver"]["gridSizeForLES"] = "maxEdgeLength"

                update_controls_modeling_constants(
                    model.turbulence_model_solver.controls, translated
                )

            if not isinstance(model.transition_model_solver, NoneSolver):
                # baseline dictionary dump for transition model object
                translated["transitionModelSolver"] = dump_dict(model.transition_model_solver)
                transition_dict = translated["transitionModelSolver"]
                replace_dict_key(transition_dict, "typeName", "modelType")
                replace_dict_key(
                    transition_dict, "equationEvaluationFrequency", "equationEvalFrequency"
                )
                transition_dict.pop("turbulenceIntensityPercent", None)
                replace_dict_key(transition_dict, "NCrit", "Ncrit")

                # build trip region(s) if applicable
                if "tripRegions" in transition_dict:
                    transition_dict["tripRegions"] = []
                    for trip_region in model.transition_model_solver.trip_regions.stored_entities:
                        axes = trip_region.private_attribute_input_cache.axes
                        transition_dict["tripRegions"].append(
                            {
                                "center": list(trip_region.center.value),
                                "size": list(trip_region.size.value),
                                "axes": [list(axes[0]), list(axes[1])],
                            }
                        )

            translated["initialCondition"] = get_navier_stokes_initial_condition(
                model.initial_condition
            )

            if "geometry" in translated:
                translated["geometry"][
                    "interfaceInterpolationTolerance"
                ] = model.interface_interpolation_tolerance

            ##:: Step 6b: Get gravity from Fluid model
            if model.gravity is not None:
                translated["gravity"] = gravity_translator(model.gravity)

    ##:: Step 7: Get BET and AD lists
    if has_instance_in_list(input_params.models, BETDisk):
        translated["BETDisks"] = translate_setting_and_apply_to_all_entities(
            input_params.models,
            BETDisk,
            bet_disk_translator,
            to_list=True,
            entity_injection_func=bet_disk_entity_info_serializer,
            translation_func_is_unsteady=isinstance(input_params.time_stepping, Unsteady),
        )

    if has_instance_in_list(input_params.models, ActuatorDisk):
        translated["actuatorDisks"] = translate_setting_and_apply_to_all_entities(
            input_params.models,
            ActuatorDisk,
            actuator_disk_translator,
            to_list=True,
            entity_injection_func=actuator_disk_entity_info_serializer,
        )

    ##:: Step 8: Get rotation
    if has_instance_in_list(input_params.models, Rotation):
        volume_zones = translated.get("volumeZones", {})
        volume_zones.update(
            translate_setting_and_apply_to_all_entities(
                input_params.models,
                Rotation,
                rotation_translator,
                to_list=False,
                entity_injection_func=rotation_entity_info_serializer,
                translation_func_params=input_params,
            )
        )
        translated["volumeZones"] = volume_zones

    ##:: Step 9: Get porous media
    if has_instance_in_list(input_params.models, PorousMedium):
        translated["porousMedia"] = translate_setting_and_apply_to_all_entities(
            input_params.models,
            PorousMedium,
            porous_media_translator,
            to_list=True,
            entity_injection_func=porous_media_entity_info_serializer,
        )

    ##:: Step 10: Get heat transfer zones
    solid_zone_boundaries = set()
    if has_instance_in_list(input_params.models, Solid):
        translated["heatEquationSolver"] = {
            "equationEvalFrequency": get_global_setting_from_first_instance(
                input_params.models,
                Solid,
                ["heat_equation_solver", "equation_evaluation_frequency"],
            ),
            "linearSolver": {
                "typeName": "LinearSolver",
                "maxIterations": get_global_setting_from_first_instance(
                    input_params.models,
                    Solid,
                    ["heat_equation_solver", "linear_solver", "max_iterations"],
                ),
            },
            "absoluteTolerance": get_global_setting_from_first_instance(
                input_params.models,
                Solid,
                ["heat_equation_solver", "absolute_tolerance"],
            ),
            "relativeTolerance": get_global_setting_from_first_instance(
                input_params.models,
                Solid,
                ["heat_equation_solver", "relative_tolerance"],
            ),
            "orderOfAccuracy": get_global_setting_from_first_instance(
                input_params.models,
                Solid,
                ["heat_equation_solver", "order_of_accuracy"],
            ),
            "CFLMultiplier": 1.0,
            "updateJacobianFrequency": 1,
            "maxForceJacUpdatePhysicalSteps": 0,
            "modelType": "HeatEquation",
        }
        linear_solver_absolute_tolerance = get_global_setting_from_first_instance(
            input_params.models,
            Solid,
            ["heat_equation_solver", "linear_solver", "absolute_tolerance"],
        )
        linear_solver_relative_tolerance = get_global_setting_from_first_instance(
            input_params.models,
            Solid,
            ["heat_equation_solver", "linear_solver", "relative_tolerance"],
        )
        if linear_solver_absolute_tolerance:
            translated["heatEquationSolver"]["linearSolver"][
                "absoluteTolerance"
            ] = linear_solver_absolute_tolerance
        if linear_solver_relative_tolerance:
            translated["heatEquationSolver"]["linearSolver"][
                "relativeTolerance"
            ] = linear_solver_relative_tolerance

        volume_zones = translated.get("volumeZones", {})
        volume_zones.update(
            translate_setting_and_apply_to_all_entities(
                input_params.models,
                Solid,
                heat_transfer_volume_zone_translator,
                to_list=False,
                entity_injection_func=get_solid_zone_boundaries,
                entity_injection_solid_zone_boundaries=solid_zone_boundaries,
            )
        )
        translated["volumeZones"] = volume_zones

    ##:: Step 3: Get boundaries (to be run after volume zones are initialized)
    # pylint: disable=duplicate-code
    translated["boundaries"] = translate_setting_and_apply_to_all_entities(
        input_params.models,
        (
            Wall,
            SlipWall,
            Freestream,
            Outflow,
            Inflow,
            Periodic,
            SymmetryPlane,
            PorousJump,
        ),
        boundary_spec_translator,
        to_list=False,
        entity_injection_func=boundary_entity_info_serializer,
        pass_translated_setting_to_entity_injection=True,
        custom_output_dict_entries=True,
        translation_func_op_acoustic_to_static_pressure_ratio=op_acoustic_to_static_pressure_ratio,
        entity_injection_solid_zone_boundaries=solid_zone_boundaries,
    )

    ##:: Step 4: Get outputs (has to be run after the boundaries are translated)

    translated = translate_output(input_params, translated)

    ##:: Step 5: Get user defined fields and auto-generated fields for dimensioned output
    translated["userDefinedFields"] = []
    # Add auto-generated UDFs for dimensioned fields + user variable UDFs
    generated_udfs, user_variable_udfs = process_output_fields_for_udf(input_params)

    # Add user-specified UDFs and auto-generated UDFs for dimensioned fields
    legacy_udf_count = len(input_params.user_defined_fields) + len(generated_udfs)
    for udf_count, udf in enumerate(
        [*input_params.user_defined_fields, *generated_udfs, *user_variable_udfs]
    ):
        udf_dict = {}
        udf_dict["name"] = udf.name
        udf_dict["expression"] = udf.expression
        if udf_count < legacy_udf_count:
            udf_dict["from_user_variables"] = False
        translated["userDefinedFields"].append(udf_dict)

    translated["userDefinedFields"].sort(key=lambda udf: udf["name"])

    ##:: Step 11: Get user defined dynamics
    input_params.user_defined_dynamics = mass_flow_default_udd(
        input_params.models, input_params.user_defined_dynamics
    )

    if input_params.user_defined_dynamics is not None:
        translated["userDefinedDynamics"] = []
        for udd in input_params.user_defined_dynamics:
            udd_dict = dump_dict(udd)
            udd_dict_translated = {}
            udd_dict_translated["dynamicsName"] = udd_dict.pop("name")
            udd_dict_translated["inputVars"] = udd_dict.pop("inputVars", [])
            udd_dict_translated["inputVars"].sort()
            udd_dict_translated["outputVars"] = udd_dict.pop("outputVars", [])
            udd_dict_translated["stateVarsInitialValue"] = udd_dict.pop("stateVarsInitialValue", [])
            udd_dict_translated["updateLaw"] = udd_dict.pop("updateLaw", [])
            udd_dict_translated["constants"] = udd_dict.pop("constants", {})
            if udd.input_boundary_patches is not None:
                udd_dict_translated["inputBoundaryPatches"] = []
                for surface in udd.input_boundary_patches.stored_entities:
                    full_name = _get_key_name(surface)
                    if full_name != BOUNDARY_FULL_NAME_WHEN_NOT_FOUND:
                        udd_dict_translated["inputBoundaryPatches"].append(full_name)
                udd_dict_translated["inputBoundaryPatches"].sort()
            if udd.output_target is not None:
                full_name = udd.output_target.full_name
                if full_name == BOUNDARY_FULL_NAME_WHEN_NOT_FOUND:
                    raise Flow360TranslationError(
                        f"The output target {udd.output_target.name} is not found in the generated volume mesh.",
                        input_value=udd.output_target,
                    )
                udd_dict_translated["outputTargetName"] = full_name
            translated["userDefinedDynamics"].append(udd_dict_translated)

        translated["userDefinedDynamics"].sort(key=lambda udd: udd["dynamicsName"])

    ##:: Step 11: Get run control settings
    translated["runControl"] = {}
    translated["runControl"]["externalProcessMonitorOutput"] = require_external_postprocessing(
        input_params
    )
    if translated["runControl"]["externalProcessMonitorOutput"]:
        translated["runControl"]["monitorProcessorHash"] = calculate_monitor_semaphore_hash(
            input_params
        )
    stopping_criteria = []
    if input_params.run_control and input_params.run_control.stopping_criteria:
        for criterion in input_params.run_control.stopping_criteria:
            stopping_criteria.append(get_stop_criterion_settings(criterion, input_params))
        translated["runControl"]["stoppingCriteria"] = stopping_criteria

    translated["usingLiquidAsMaterial"] = isinstance(
        input_params.operating_condition, LiquidOperatingCondition
    )
    translated["outputRescale"] = {"velocityScale": 1.0}
    if isinstance(input_params.operating_condition, LiquidOperatingCondition):
        translated["outputRescale"]["velocityScale"] = (
            1.0 / translated["freestream"]["MachRef"]
            if "MachRef" in translated["freestream"].keys()
            else 1.0 / translated["freestream"]["Mach"]
        )
    if input_params.private_attribute_dict is not None:
        translated.update(input_params.private_attribute_dict)

    return translated


@preprocess_input
def get_columnar_data_processor_json(
    input_params: SimulationParams,
    # pylint: disable=no-member,unused-argument
    mesh_unit: LengthType.Positive,
):
    """
    Get the columnar data processor json from the simulation parameters.
    """
    translated = {"outputs": []}
    if not input_params.outputs:
        return translated
    for output in input_params.outputs:
        if not isinstance(output, get_args(get_args(MonitorOutputType)[0])):
            continue
        if (
            isinstance(output, (ProbeOutput, SurfaceProbeOutput))
            and output.moving_statistic is None
        ):
            continue
        if (
            isinstance(output, SurfaceIntegralOutput)
            and output.moving_statistic is None
            and all(
                not isinstance(surface, ImportedSurface)
                for surface in output.entities.stored_entities
            )
        ):
            continue
        output_dict = output.model_dump(
            exclude_none=True,
            context={"columnar_data_processor": True},
        )
        translated["outputs"].append(output_dict)
    return translated
