"""
Validation for output parameters
"""

import math
from typing import List, Literal, Union, get_args, get_origin

from flow360.component.simulation.models.volume_models import Fluid
from flow360.component.simulation.outputs.outputs import (
    AeroAcousticOutput,
    ForceDistributionOutput,
    ProbeOutput,
    SurfaceIntegralOutput,
    SurfaceProbeOutput,
    TimeAverageForceDistributionOutput,
)
from flow360.component.simulation.time_stepping.time_stepping import Steady
from flow360.component.simulation.user_code.core.types import Expression
from flow360.component.simulation.validation.validation_utils import (
    customize_model_validator_error,
)


def _check_output_fields(params):
    """Check the specified output fields for each output item is valid."""

    # pylint: disable=too-many-branches
    if params.outputs is None:
        return params

    has_legacy_user_defined_field_in_surface_integral_output = False
    for output in params.outputs:
        if isinstance(output, SurfaceIntegralOutput):
            for output_field in output.output_fields.items:
                if isinstance(output_field, str):
                    has_legacy_user_defined_field_in_surface_integral_output = True
                    break
    has_user_defined_fields = len(params.user_defined_fields) > 0

    if (
        has_legacy_user_defined_field_in_surface_integral_output
        and has_user_defined_fields is False
    ):
        raise ValueError(
            "The legacy string output fields in `SurfaceIntegralOutput` must be used with `UserDefinedField`."
        )

    def extract_literal_values(annotation):
        origin = get_origin(annotation)
        if origin is Union:
            # Traverse each Union argument
            results = []
            for arg in get_args(annotation):
                result = extract_literal_values(arg)
                if result:
                    results.extend(result)
            return results
        if origin is list or origin is List:
            # Apply the function to the List's element type
            return extract_literal_values(get_args(annotation)[0])
        if origin is Literal:
            return list(get_args(annotation))
        return []

    additional_fields = [item.name for item in params.user_defined_fields]

    for output_index, output in enumerate(params.outputs):
        if output.output_type in (
            "AeroAcousticOutput",
            "StreamlineOutput",
            "ForceDistributionOutput",
            "TimeAverageForceDistributionOutput",
            "RenderOutput",
        ):
            continue
        # Get allowed output fields items:
        natively_supported = extract_literal_values(
            output.output_fields.__class__.model_fields["items"].annotation
        )
        allowed_items = natively_supported + additional_fields

        for item in output.output_fields.items:
            if isinstance(item, str) and item not in allowed_items:
                raise ValueError(
                    f"In `outputs`[{output_index}] {output.output_type}:, {item} is not a"
                    f" valid output field name. Allowed fields are {allowed_items}."
                )

        if output.output_type == "IsosurfaceOutput":
            # using the 1st item's allowed field as all isosurface have same field definition
            allowed_items = (
                extract_literal_values(
                    output.entities.items[0].__class__.model_fields["field"].annotation
                )
                + additional_fields
            )
            for entity in output.entities.items:
                if isinstance(entity.field, str) and entity.field not in allowed_items:
                    raise ValueError(
                        f"In `outputs`[{output_index}] {output.output_type}:, {entity.field} is not a"
                        f" valid iso field name. Allowed fields are {allowed_items}."
                    )

    return params


def _check_output_fields_valid_given_turbulence_model(params):
    """Ensure that the output fields are consistent with the turbulence model used."""

    if not params.models or not params.outputs:
        return params

    turbulence_model = None

    invalid_output_fields = {
        "None": ("kOmega", "nuHat", "residualTurbulence", "solutionTurbulence"),
        "SpalartAllmaras": ("kOmega"),
        "kOmegaSST": ("nuHat"),
    }
    for model in params.models:
        if isinstance(model, Fluid):
            turbulence_model = model.turbulence_model_solver.type_name
            break

    for output_index, output in enumerate(params.outputs):
        if output.output_type in (
            "AeroAcousticOutput",
            "StreamlineOutput",
            "ForceDistributionOutput",
            "TimeAverageForceDistributionOutput",
            "RenderOutput",
        ):
            continue
        for item in output.output_fields.items:
            if isinstance(item, str) and item in invalid_output_fields[turbulence_model]:
                raise ValueError(
                    f"In `outputs`[{output_index}] {output.output_type}: {item} is not a valid"
                    f" output field when using turbulence model: {turbulence_model}."
                )

        if output.output_type == "IsosurfaceOutput":
            for entity in output.entities.items:
                if (
                    isinstance(entity.field, str)
                    and entity.field in invalid_output_fields[turbulence_model]
                ):
                    raise ValueError(
                        f"In `outputs`[{output_index}] {output.output_type}: {entity.field} is not a valid"
                        f" iso field when using turbulence model: {turbulence_model}."
                    )
    return params


def _check_output_fields_valid_given_transition_model(params):
    """Ensure that the output fields are consistent with the transition model used."""

    if not params.models or not params.outputs:
        return params

    transition_model = "None"
    for model in params.models:
        if isinstance(model, Fluid):
            transition_model = model.transition_model_solver.type_name
            break

    if transition_model != "None":
        return params

    transition_output_fields = [
        "residualTransition",
        "solutionTransition",
        "linearResidualTransition",
    ]

    for output_index, output in enumerate(params.outputs):
        if output.output_type in (
            "AeroAcousticOutput",
            "StreamlineOutput",
            "ForceDistributionOutput",
            "TimeAverageForceDistributionOutput",
            "RenderOutput",
        ):
            continue
        for item in output.output_fields.items:
            if isinstance(item, str) and item in transition_output_fields:
                raise ValueError(
                    f"In `outputs`[{output_index}] {output.output_type}: {item} is not a valid"
                    f" output field when transition model is not used."
                )
    return params


def _check_unsteadiness_to_use_aero_acoustics(params):

    if not params.outputs:
        return params

    if isinstance(params.time_stepping, Steady):

        for output_index, output in enumerate(params.outputs):
            if isinstance(output, AeroAcousticOutput):
                raise ValueError(
                    f"In `outputs`[{output_index}] {output.output_type}:"
                    "`AeroAcousticOutput` can only be activated with `Unsteady` simulation."
                )
    # Not running case or is using unsteady
    return params


def _check_local_cfl_output(params):
    """localCFL output is only valid for unsteady simulations."""

    if not params.outputs:
        return params

    if not isinstance(params.time_stepping, Steady):
        return params

    for output_index, output in enumerate(params.outputs):
        if output.output_type in (
            "AeroAcousticOutput",
            "StreamlineOutput",
            "ForceDistributionOutput",
            "TimeAverageForceDistributionOutput",
            "RenderOutput",
        ):
            continue
        for item in output.output_fields.items:
            if isinstance(item, str) and item == "localCFL":
                raise ValueError(
                    f"In `outputs`[{output_index}] {output.output_type}: "
                    "`localCFL` output is only supported for unsteady simulations."
                )

    return params


def _check_aero_acoustics_observer_time_step_size(params):

    if not params.outputs:
        return params

    for output_index, output in enumerate(params.outputs):
        if isinstance(output, AeroAcousticOutput):
            time_step_size = params.time_stepping.step_size
            if isinstance(params.time_stepping.step_size, Expression):
                time_step_size = params.time_stepping.step_size.evaluate(
                    raise_on_non_evaluable=True, force_evaluate=True
                )
            if output.observer_time_step_size and output.observer_time_step_size < time_step_size:
                raise ValueError(
                    f"In `outputs`[{output_index}] {output.output_type}: "
                    f"`observer_time_size` ({output.observer_time_step_size}) is smaller than "
                    f"the time step size of CFD ({params.time_stepping.step_size})."
                )
    return params


def _check_unique_surface_volume_probe_names(params):

    if not params.outputs:
        return params

    active_probe_names = set()

    for output_index, output in enumerate(params.outputs):
        if isinstance(output, (ProbeOutput, SurfaceProbeOutput)):
            if output.name in active_probe_names:
                raise ValueError(
                    f"In `outputs`[{output_index}] {output.output_type}: "
                    f"Output name {output.name} has already been used for a `ProbeOutput` "
                    "or `SurfaceProbeOutput`. Output names must be unique among all probe "
                    "outputs."
                )
            active_probe_names.add(output.name)

    return params


def _check_unique_force_distribution_output_names(params):

    if not params.outputs:
        return params

    active_names = set()

    for output_index, output in enumerate(params.outputs):
        if isinstance(output, (ForceDistributionOutput, TimeAverageForceDistributionOutput)):
            if output.name in active_names:
                raise ValueError(
                    f"In `outputs`[{output_index}] {output.output_type}: "
                    f"Output name {output.name} has already been used for a `ForceDistributionOutput`. "
                    "Output names must be unique among all force distribution outputs."
                )
            active_names.add(output.name)

    return params


def _check_unique_surface_volume_probe_entity_names(params):

    if not params.outputs:
        return params

    for output_index, output in enumerate(params.outputs):
        if isinstance(output, (ProbeOutput, SurfaceProbeOutput)):
            active_entity_names = set()
            for entity in output.entities.stored_entities:
                if entity.name in active_entity_names:
                    raise ValueError(
                        f"In `outputs`[{output_index}] {output.output_type}: "
                        f"Entity name {entity.name} has already been used in the "
                        f"same `{output.output_type}`. Entity names must be unique."
                    )
                active_entity_names.add(entity.name)

    return params


def _check_moving_statistic_applicability(params):

    if not params.time_stepping:
        return params

    if not params.outputs:
        return params

    is_steady = isinstance(params.time_stepping, Steady)
    max_steps = params.time_stepping.max_steps if is_steady else params.time_stepping.steps

    for output_index, output in enumerate(params.outputs):
        if not hasattr(output, "moving_statistic") or output.moving_statistic is None:
            continue
        moving_window_size_in_step = (
            output.moving_statistic.moving_window_size * 10
            if is_steady
            else output.moving_statistic.moving_window_size
        )
        start_step = (
            math.ceil(output.moving_statistic.start_step / 10) * 10
            if is_steady
            else output.moving_statistic.start_step
        )
        if moving_window_size_in_step + start_step > max_steps:
            raise customize_model_validator_error(
                model_instance=params,
                relative_location=("outputs", output_index, "moving_statistic"),
                message="`moving_statistic`'s moving_window_size + start_step exceeds "
                "the total number of steps in the simulation.",
                input_value=output.moving_statistic.model_dump(),
            )

    return params
