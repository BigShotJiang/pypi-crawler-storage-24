# OpenVFS 使用说明

OpenVFS 是面向 AI Agent 的 Markdown 虚拟文件系统中间件。

## 初始化

```python
from openvfs import OpenVfs

myvfs = OpenVfs.init_vfs()
myvfs.create_folder("openvfs://resources/project")
```

默认使用 `MemoryStore`。

## 直接导入 Store

```python
from openvfs import MemoryStore, OpenVfs

store = MemoryStore()
myvfs = OpenVfs.init_vfs(store=store)
```

## S3/TOS 兼容后端

```python
from openvfs import OpenVfs, S3Store

store = S3Store(
    bucket_name="my-bucket",
    region_name="cn-beijing",
    endpoint_url="https://tos-s3-cn-beijing.volces.com",
    aws_access_key_id="your-ak",
    aws_secret_access_key="your-sk",
)
myvfs = OpenVfs.init_vfs(store=store)
```

## 基本用法

```python
(myvfs
  .cd_path("resources", "demo")
  .create_file("readme.md")
  .heading("标题", level=2, id="title")
  .text("内容")
  .write())

content = myvfs.read("openvfs://resources/demo/readme.md")
```
