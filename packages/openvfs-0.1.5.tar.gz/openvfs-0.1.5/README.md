# OpenVFS

Agent 专用 Markdown 虚拟文件系统中间件，底层基于可热插拔的 Store 后端。

## 安装

```bash
uv add py-key-value-aio
uv add openvfs
```

## 快速示例

```python
from openvfs import OpenVfs

myvfs = OpenVfs.init_vfs()
myvfs.create_folder("openvfs://resources/project")

(myvfs
  .cd_path("resources", "project")
  .create_file("readme.md")
  .heading("安装", level=2, id="install")
  .block("uv add openvfs", type="code", lang="bash")
  .write())

content = myvfs.cd_path("resources", "project").create_file("readme.md").get_block(id="install")
```

## 直接导入 Store

```python
from openvfs import MemoryStore, OpenVfs

store = MemoryStore()
myvfs = OpenVfs.init_vfs(store=store)
```

可选后端示例：

```python
from openvfs import OpenVfs, S3Store

store = S3Store(
    bucket_name="my-bucket",
    endpoint_url="https://tos-s3-cn-beijing.volces.com",
    aws_access_key_id="your-ak",
    aws_secret_access_key="your-sk",
)
myvfs = OpenVfs.init_vfs(store=store)
```
