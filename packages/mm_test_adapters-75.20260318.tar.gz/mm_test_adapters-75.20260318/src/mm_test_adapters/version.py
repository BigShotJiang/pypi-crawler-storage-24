__version__ = "75.20260318"
GIT_REF = "b191e49"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/b191e49"