"""
LLM Loop
========
Provider-agnostic multi-turn chat loop with tool execution.
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from agentsflow.errors import LLMProviderError, LLMRateLimitError, LLMServerError, MaxToolRoundsError
from agentsflow.llm import LLMClient
from agentsflow.logging_utils import log_structured
from agentsflow.schema import RetryConfig
from agentsflow.types import ChatMessage, ToolCallSpec

from .tools import AgentTools


def run_llm_loop(
    client: LLMClient,
    messages: list[ChatMessage],
    tools: AgentTools,
    temperature: Optional[float],
    max_tokens: Optional[int],
    response_format: Optional[dict],
    timeout: Optional[float] = None,
    retry_config: Optional[RetryConfig] = None,
    rid: Optional[str] = None,
) -> str:
    """Run the model loop until final text or max tool rounds."""
    rc = retry_config or RetryConfig()

    import tenacity
    from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

    def _call_chat() -> str | dict:
        tool_schemas = tools.get_schemas(provider=client.provider_name)
        try:
            return client.chat(
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                response_format=response_format if not tool_schemas else None,
                tools=tool_schemas,
                timeout=timeout,
            )
        except LLMProviderError as e:
            log_structured(
                logging.ERROR,
                "llm_error",
                rid=rid,
                error=str(e),
                provider_request_id=e.provider_request_id,
            )
            if rid and e.rid is None:
                raise type(e)(
                    e.args[0],
                    cause=e,
                    rid=rid,
                    provider_request_id=e.provider_request_id,
                ) from e
            raise

    @retry(
        retry=retry_if_exception_type((LLMRateLimitError, LLMServerError)),
        wait=wait_exponential(multiplier=1, min=rc.base_delay, max=rc.max_delay),
        stop=stop_after_attempt(rc.max_attempts),
        reraise=True,
    )
    def _call_chat_with_retry() -> str | dict:
        return _call_chat()

    for _round in range(AgentTools.MAX_TOOL_ROUNDS):
        result = _call_chat_with_retry()

        if isinstance(result, str):
            return result

        if isinstance(result, dict) and "tool_calls" in result:
            append_assistant_tool_calls(messages, result["tool_calls"])
            execute_tool_calls(tools, messages, result["tool_calls"], rid=rid)
            continue

        return str(result)

    raise MaxToolRoundsError(
        f"Agent exceeded {AgentTools.MAX_TOOL_ROUNDS} tool-calling rounds without a final answer."
    )


def append_assistant_tool_calls(
    messages: list[ChatMessage], tool_calls: list[ToolCallSpec]
) -> None:
    """Append the assistant tool-call message in OpenAI-style format."""
    messages.append({
        "role": "assistant",
        "content": None,
        "tool_calls": [
            {
                "id": tc["id"],
                "type": "function",
                "function": {
                    "name": tc["name"],
                    "arguments": json.dumps(tc["arguments"]),
                },
            }
            for tc in tool_calls
        ],
    })


def execute_tool_calls(
    tools: AgentTools,
    messages: list[ChatMessage],
    tool_calls: list[ToolCallSpec],
    rid: Optional[str] = None,
) -> None:
    """Execute tool calls and append tool results to the transcript."""
    agent_name = tools._agent_dir.name if hasattr(tools, "_agent_dir") else None
    for tc in tool_calls:
        log_structured(
            logging.INFO,
            "tool_call",
            rid=rid,
            agent_name=agent_name,
            tool_name=tc["name"],
            tool_arguments=tc.get("arguments"),
        )
        tool_result_str = tools.execute(tc["name"], tc["arguments"])
        messages.append({
            "role": "tool",
            "tool_call_id": tc["id"],
            "content": tool_result_str,
        })
