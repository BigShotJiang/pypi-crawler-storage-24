"""Model Context Protocol (MCP) server configuration — identity vs technical config."""

from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator


class MCPIdentity(BaseModel):
    """
    Lightweight MCP identity stored in the main agent ``config.yaml``.

    Used for LLM routing; ``description`` must be substantive (min 10 characters).
    """

    model_config = ConfigDict(extra="ignore")

    id: UUID = Field(default_factory=uuid4, description="Unique MCP instance id")
    name: str = Field(
        ...,
        min_length=1,
        max_length=64,
        pattern=r"^[a-zA-Z0-9_-]+$",
        description="Unique MCP name per agent; also used as the directory name under mcp/",
    )
    description: str = Field(
        ...,
        min_length=10,
        description="Human + LLM-facing description (routing / discovery)",
    )
    docker_enabled: bool = Field(
        default=False,
        description="When True, MCP may run in a container (runtime-specific).",
    )


class MCPConfig(BaseModel):
    """Technical configuration: how to launch the MCP server process."""

    model_config = ConfigDict(extra="ignore")

    cmd: str = Field(..., min_length=1, description="Executable, e.g. uvx, npx, python")
    args: list[str] = Field(default_factory=list, description="Command-line arguments")
    docker_image: str | None = Field(
        default=None,
        description="Docker image when identity.docker_enabled is True (e.g. node:20-alpine).",
    )
    env: dict[str, str] | None = Field(
        default=None,
        description="Optional environment variables (string values only)",
    )

    @field_validator("env", mode="before")
    @classmethod
    def _empty_env_to_none(cls, v: Any) -> dict[str, str] | None:
        if v is None or v == {}:
            return None
        if isinstance(v, dict):
            return {str(k): str(val) for k, val in v.items()}
        return v


class MCP(BaseModel):
    """Full MCP definition: identity (reference) + launch configuration."""

    model_config = ConfigDict(extra="ignore")

    identity: MCPIdentity
    config: MCPConfig


__all__ = ["MCPIdentity", "MCPConfig", "MCP"]
