"""Runtime MCP: connect tools (name + description only) + dynamic tools after session start."""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from agentsflow.errors import AgentsFlowToolError
from agentsflow.mcp.stdio_client import JsonRpcStdio, JsonRpcStdioError, MCPStdioSession, spawn_mcp_process
from agentsflow.schema.mcp_schema import MCP
from agentsflow.types import AnthropicToolSchema, OpenAIToolSchema

logger = logging.getLogger(__name__)


CONNECT_PREFIX = "mcp_connect_"


def _sanitize_for_tool_name(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_-]+", "_", name)
    s = s.strip("_")
    return s or "tool"


def _tool_result_to_str(result: Any) -> str:
    if isinstance(result, str):
        return result
    if isinstance(result, dict):
        content = result.get("content")
        if isinstance(content, list):
            parts: list[str] = []
            for block in content:
                if not isinstance(block, dict):
                    continue
                if block.get("type") == "text" and "text" in block:
                    parts.append(str(block["text"]))
                elif "text" in block:
                    parts.append(str(block["text"]))
            if parts:
                return "\n".join(parts)
        if "isError" in result and result.get("isError"):
            return json.dumps(result, ensure_ascii=False)
        return json.dumps(result, ensure_ascii=False)
    return json.dumps(result, ensure_ascii=False)


def _mcp_input_schema_to_openai_params(schema: Any) -> dict[str, Any]:
    if isinstance(schema, dict) and schema.get("type") == "object":
        return schema
    return {"type": "object", "properties": {"input": schema}, "additionalProperties": True}


def build_launch_argv(mcp: MCP) -> list[str]:
    """Host command line or ``docker run ...`` when docker is enabled."""
    if mcp.identity.docker_enabled:
        if not mcp.config.docker_image:
            raise AgentsFlowToolError(
                f"MCP '{mcp.identity.name}': docker_enabled=True requires docker_image in mcp_config.json"
            )
        cmd = ["docker", "run", "--rm", "-i"]
        if mcp.config.env:
            for k, v in mcp.config.env.items():
                cmd.extend(["-e", f"{k}={v}"])
        cmd.append(mcp.config.docker_image.strip())
        cmd.append(mcp.config.cmd)
        cmd.extend(mcp.config.args)
        return cmd
    return [mcp.config.cmd, *mcp.config.args]


class MCPRuntime:
    """
    Manages MCP connect tools (minimal LLM exposure) and per-server stdio sessions.

    After a successful ``mcp_connect_<name>`` call, tools from ``tools/list`` are
    exposed with names ``mcp_<server>_<sanitized_original>``.
    """

    def __init__(self, mcp_definitions: list[MCP]) -> None:
        self._mcps: dict[str, MCP] = {m.identity.name: m for m in mcp_definitions}
        self._sessions: dict[str, MCPStdioSession] = {}
        # openai tool name -> (server_name, original_mcp_tool_name)
        self._tool_route: dict[str, tuple[str, str]] = {}
        self._dynamic_openai: list[OpenAIToolSchema] = []
        self._dynamic_anthropic: list[AnthropicToolSchema] = []

    def has_definitions(self) -> bool:
        return bool(self._mcps)

    def reset_sessions(self) -> None:
        """Terminate subprocesses (e.g. at start of each agent run)."""
        for name, sess in list(self._sessions.items()):
            try:
                sess.close()
            except Exception as e:
                logger.debug("mcp session close %s: %s", name, e)
        self._sessions.clear()
        self._tool_route.clear()
        self._dynamic_openai.clear()
        self._dynamic_anthropic.clear()

    def _connect_schema_openai(self, server_name: str, mcp: MCP) -> OpenAIToolSchema:
        desc = (
            f"Connect to MCP server '{server_name}'. {mcp.identity.description} "
            "After connecting, tools from this server become available. "
            "Call with empty object {{}} to connect."
        )
        return {
            "type": "function",
            "function": {
                "name": f"{CONNECT_PREFIX}{server_name}",
                "description": desc,
                "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
            },
        }

    def _connect_schema_anthropic(self, server_name: str, mcp: MCP) -> AnthropicToolSchema:
        desc = (
            f"Connect to MCP server '{server_name}'. {mcp.identity.description} "
            "After connecting, tools from this server become available."
        )
        return {
            "name": f"{CONNECT_PREFIX}{server_name}",
            "description": desc,
            "input_schema": {"type": "object", "properties": {}, "additionalProperties": False},
        }

    def get_openai_schemas(self) -> list[OpenAIToolSchema]:
        out: list[OpenAIToolSchema] = []
        for server_name, mcp in self._mcps.items():
            if server_name not in self._sessions:
                out.append(self._connect_schema_openai(server_name, mcp))
        out.extend(self._dynamic_openai)
        return out

    def get_anthropic_schemas(self) -> list[AnthropicToolSchema]:
        out: list[AnthropicToolSchema] = []
        for server_name, mcp in self._mcps.items():
            if server_name not in self._sessions:
                out.append(self._connect_schema_anthropic(server_name, mcp))
        out.extend(self._dynamic_anthropic)
        return out

    def is_mcp_tool_name(self, name: str) -> bool:
        if name.startswith(CONNECT_PREFIX):
            server = name[len(CONNECT_PREFIX) :]
            return bool(server) and server in self._mcps
        return name in self._tool_route

    def execute(
        self, name: str, arguments: dict[str, Any]
    ) -> tuple[str, bool, str]:
        """
        Run MCP connect or tools/call.

        Returns:
            (result_text, ran_in_docker, mcp_server_name)
        """
        if name.startswith(CONNECT_PREFIX):
            server = name[len(CONNECT_PREFIX) :]
            if server not in self._mcps:
                raise AgentsFlowToolError(f"Unknown MCP server for tool {name!r}")
            return self._connect(server), self._mcps[server].identity.docker_enabled, server

        if name in self._tool_route:
            server_name, orig_name = self._tool_route[name]
            sess = self._sessions.get(server_name)
            if not sess:
                raise AgentsFlowToolError(f"MCP server {server_name!r} is not connected")
            mcp = self._mcps[server_name]
            try:
                raw = sess.call_tool(orig_name, arguments)
            except JsonRpcStdioError as e:
                raise AgentsFlowToolError(f"MCP tools/call failed: {e}") from e
            return _tool_result_to_str(raw), mcp.identity.docker_enabled, server_name

        raise KeyError(name)

    def _connect(self, server_name: str) -> str:
        mcp = self._mcps[server_name]
        if server_name in self._sessions:
            n = len([k for k in self._tool_route if self._tool_route[k][0] == server_name])
            return json.dumps(
                {
                    "status": "already_connected",
                    "server": server_name,
                    "tools_registered": n,
                },
                ensure_ascii=False,
            )

        argv = build_launch_argv(mcp)
        logger.info("Starting MCP server %s: %s", server_name, argv[:8])
        try:
            proc = spawn_mcp_process(argv, mcp.config.env)
        except Exception as e:
            raise AgentsFlowToolError(f"Failed to spawn MCP {server_name}: {e}") from e

        rpc = JsonRpcStdio(proc)
        session = MCPStdioSession(rpc, proc)
        try:
            session.initialize()
            tools = session.list_tools()
        except Exception as e:
            session.close()
            raise AgentsFlowToolError(f"MCP {server_name} handshake failed: {e}") from e

        self._sessions[server_name] = session

        used_names: set[str] = set()
        registered: list[str] = []
        for td in tools:
            orig = str(td.get("name", ""))
            if not orig:
                continue
            base = f"mcp_{server_name}_{_sanitize_for_tool_name(orig)}"
            openai_name = base
            i = 2
            while openai_name in used_names or openai_name in self._tool_route:
                openai_name = f"{base}__{i}"
                i += 1
            used_names.add(openai_name)

            desc = str(td.get("description") or f"MCP tool {orig} on {server_name}")
            raw_schema = td.get("inputSchema") or td.get("input_schema") or {
                "type": "object",
                "properties": {},
            }
            params = _mcp_input_schema_to_openai_params(raw_schema)

            self._tool_route[openai_name] = (server_name, orig)
            self._dynamic_openai.append(
                {
                    "type": "function",
                    "function": {
                        "name": openai_name,
                        "description": desc,
                        "parameters": params,
                    },
                }
            )
            self._dynamic_anthropic.append(
                {
                    "name": openai_name,
                    "description": desc,
                    "input_schema": params,
                }
            )
            registered.append(openai_name)

        return json.dumps(
            {
                "status": "connected",
                "server": server_name,
                "tools": registered,
            },
            ensure_ascii=False,
        )
