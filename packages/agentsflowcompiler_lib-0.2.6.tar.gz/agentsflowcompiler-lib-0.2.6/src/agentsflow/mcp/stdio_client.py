"""Minimal MCP client over stdio: JSON-RPC 2.0 line-delimited messages."""

from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
from typing import Any

logger = logging.getLogger(__name__)


class JsonRpcStdioError(RuntimeError):
    """JSON-RPC or MCP transport error."""


class JsonRpcStdio:
    """Bidirectional JSON-RPC over a subprocess stdin/stdout (NDJSON)."""

    def __init__(self, proc: subprocess.Popen[str]) -> None:
        self._proc = proc
        self._lock = threading.Lock()
        self._next_id = 1

    def close(self) -> None:
        if self._proc.poll() is None:
            try:
                self._proc.terminate()
                self._proc.wait(timeout=5)
            except Exception:
                try:
                    self._proc.kill()
                except Exception:
                    pass
        for stream in (self._proc.stdin, self._proc.stdout):
            if stream:
                try:
                    stream.close()
                except Exception:
                    pass

    def notify(self, method: str, params: dict[str, Any] | None = None) -> None:
        msg = {"jsonrpc": "2.0", "method": method, "params": params or {}}
        line = json.dumps(msg, ensure_ascii=False) + "\n"
        with self._lock:
            if not self._proc.stdin:
                raise JsonRpcStdioError("stdin closed")
            self._proc.stdin.write(line)
            self._proc.stdin.flush()

    def request(self, method: str, params: dict[str, Any] | None = None) -> Any:
        with self._lock:
            req_id = self._next_id
            self._next_id += 1
            msg = {"jsonrpc": "2.0", "id": req_id, "method": method, "params": params or {}}
            line = json.dumps(msg, ensure_ascii=False) + "\n"
            if not self._proc.stdin or not self._proc.stdout:
                raise JsonRpcStdioError("stdio closed")
            self._proc.stdin.write(line)
            self._proc.stdin.flush()

            while True:
                raw = self._proc.stdout.readline()
                if not raw:
                    raise JsonRpcStdioError("MCP process EOF on stdout")
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    parsed = json.loads(raw)
                except json.JSONDecodeError:
                    logger.debug("mcp non-json line: %s", raw[:200])
                    continue
                if parsed.get("id") == req_id:
                    if "error" in parsed:
                        err = parsed["error"]
                        raise JsonRpcStdioError(f"RPC error: {err}")
                    return parsed.get("result")
                # notification or response for another request — ignore for single-threaded client


def spawn_mcp_process(argv: list[str], env: dict[str, str] | None) -> subprocess.Popen[str]:
    """Start ``argv`` with inherited env + optional extra env."""
    full_env = os.environ.copy()
    if env:
        full_env.update(env)
    return subprocess.Popen(
        argv,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
        bufsize=1,
        env=full_env,
    )


class MCPStdioSession:
    """One MCP server session: initialize + tools/list + tools/call."""

    PROTOCOL_VERSION = "2024-11-05"

    def __init__(self, rpc: JsonRpcStdio, proc: subprocess.Popen[str]) -> None:
        self._rpc = rpc
        self._proc = proc

    def close(self) -> None:
        self._rpc.close()

    def initialize(self) -> dict[str, Any]:
        result = self._rpc.request(
            "initialize",
            {
                "protocolVersion": self.PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "agentsflow", "version": "0.1"},
            },
        )
        self._rpc.notify("notifications/initialized", {})
        return result if isinstance(result, dict) else {}

    def list_tools(self) -> list[dict[str, Any]]:
        result = self._rpc.request("tools/list", {})
        if not isinstance(result, dict):
            return []
        tools = result.get("tools")
        if not isinstance(tools, list):
            return []
        return [t for t in tools if isinstance(t, dict)]

    def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
        return self._rpc.request("tools/call", {"name": name, "arguments": arguments})
