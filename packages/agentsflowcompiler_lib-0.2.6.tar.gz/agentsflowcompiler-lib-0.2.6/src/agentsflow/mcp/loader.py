"""Load full MCP definitions from disk (identity from agent config + mcp/<name>/mcp_config.json)."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from agentsflow.constants import DEFAULT_MCP_DIR, MCP_CONFIG_FILE
from agentsflow.schema import AgentConfig
from agentsflow.schema.mcp_schema import MCP, MCPConfig

logger = logging.getLogger(__name__)


def load_mcp_definitions(agent_dir: Path, config: AgentConfig) -> list[MCP]:
    """Merge ``mcp_identities`` from config with on-disk ``mcp_config.json`` per server."""
    identities = config.mcp_identities or []
    out: list[MCP] = []
    for ident in identities:
        cfg_path = agent_dir / DEFAULT_MCP_DIR / ident.name / MCP_CONFIG_FILE
        if not cfg_path.is_file():
            logger.warning(
                "Skipping MCP %r: missing config at %s",
                ident.name,
                cfg_path,
            )
            continue
        try:
            raw = json.loads(cfg_path.read_text(encoding="utf-8"))
            mcp_cfg = MCPConfig.model_validate(raw)
        except Exception as e:
            logger.warning("Skipping MCP %r: invalid config %s: %s", ident.name, cfg_path, e)
            continue
        out.append(MCP(identity=ident, config=mcp_cfg))
    return out
