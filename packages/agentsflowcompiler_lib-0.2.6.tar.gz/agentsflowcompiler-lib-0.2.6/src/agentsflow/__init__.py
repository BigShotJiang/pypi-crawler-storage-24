"""
agentsflow — PROD API
=====================
Production entry point. Import ``load_agents`` to load and run agents.

Usage::

    from agentsflow import load_agents

    agents = load_agents("/path/to/agents_dir")
    result = agents["my_agent"].run("Hello")
"""

from agentsflow._prod import load_agents
from agentsflow.agent import Agent
from agentsflow.agent.run_context import RunResult
from agentsflow.schema import (
    AgentConfig,
    Prompt,
    Tool,
    AgentIdentity,
    AgentModelConfig,
    ApiKeyConfig,
    LogsConfig,
    RetryConfig,
    ProcessingConfig,
    ProjectConfigSchema,
    DirectoryConfig,
    SecretEnvironmentConfig,
    SecretsConfig,
    ProjectConfigEditSchema,
    SecretStrategy,
    ToolConfig,
    ToolIdentityConfig,
    ToolReturnConfig,
    ToolParameterConfig,
    ToolParametersConfig,
    DockerToolConfig,
    MCPIdentity,
    MCPConfig,
    MCP,
)
from agentsflow.types import ToolCallLogEntry, TokensSummary
from agentsflow.dev.monitoring_types import (
    AgentContext,
    AuditLogEntry,
    PromptHistoryEntry,
    RunHistoryEntry,
    TokenUsageResponse,
    AuditLogChangeEntry,
    TokenUsageRunEntry,
)
from agentsflow.config import AgentsFlowConfig
from agentsflow.errors import (
    AgentsFlowError,
    AgentsFlowConfigError,
    AgentsFlowLogError,
    AgentsFlowToolError,
    DockerExecutionError,
    MaxToolRoundsError,
    LLMProviderError,
    LLMAuthenticationError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMServerError,
    MCPAlreadyExistsError,
    MCPNotFoundError,
)

try:
    from importlib.metadata import version, PackageNotFoundError
except ImportError:  # pragma: no cover
    from importlib_metadata import version, PackageNotFoundError  # type: ignore

try:
    __version__ = version("AgentsFlowCompiler-lib")
except PackageNotFoundError:
    # package is not installed
    __version__ = "0.0.0"
__all__ = [
    "load_agents",
    "AgentsFlowConfig",
    "__version__",
    "Agent",
    "RunResult",
    "AgentConfig",
    "Prompt",
    "Tool",
    "AgentIdentity",
    "AgentModelConfig",
    "ApiKeyConfig",
    "LogsConfig",
    "RetryConfig",
    "ProcessingConfig",
    "ProjectConfigSchema",
    "DirectoryConfig",
    "SecretEnvironmentConfig",
    "SecretsConfig",
    "ProjectConfigEditSchema",
    "SecretStrategy",
    "ToolConfig",
    "ToolIdentityConfig",
    "ToolReturnConfig",
    "ToolParameterConfig",
    "ToolParametersConfig",
    "DockerToolConfig",
    "MCPIdentity",
    "MCPConfig",
    "MCP",
    "ToolCallLogEntry",
    "TokensSummary",
    "AgentContext",
    "AuditLogEntry",
    "PromptHistoryEntry",
    "RunHistoryEntry",
    "TokenUsageResponse",
    "AuditLogChangeEntry",
    "TokenUsageRunEntry",
    "AgentsFlowError",
    "AgentsFlowConfigError",
    "AgentsFlowLogError",
    "AgentsFlowToolError",
    "DockerExecutionError",
    "MaxToolRoundsError",
    "LLMProviderError",
    "LLMAuthenticationError",
    "LLMInvalidRequestError",
    "LLMRateLimitError",
    "LLMServerError",
    "MCPAlreadyExistsError",
    "MCPNotFoundError",
]
