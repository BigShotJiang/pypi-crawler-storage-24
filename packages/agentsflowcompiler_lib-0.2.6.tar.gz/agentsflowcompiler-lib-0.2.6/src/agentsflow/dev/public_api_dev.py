"""
PublicAPIDev — MCP management facade
====================================
Thin facade over :mod:`agentsflow.dev.mcp_api` for discoverable MCP CRUD.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from agentsflow.schema.agent_config_schema import AgentConfig
from agentsflow.schema.mcp_schema import MCP, MCPIdentity

from . import mcp_api


class PublicAPIDev:
    """
    DEV-layer API for Model Context Protocol (MCP) servers per agent.

    Identity records live in ``config.yaml``; full definitions live under
    ``mcp/<name>/mcp_config.json``.
    """

    @staticmethod
    def add_mcp_to_agent(
        base_dir: Path,
        mcp_data: Union[MCP, Dict[str, Any]],
        agent_name: Optional[str] = None,
        agent_id: Optional[UUID] = None,
    ) -> AgentConfig:
        """See :func:`agentsflow.dev.mcp_api.add_mcp_to_agent`."""
        return mcp_api.add_mcp_to_agent(
            base_dir, mcp_data, agent_name=agent_name, agent_id=agent_id
        )

    @staticmethod
    def edit_mcp(
        base_dir: Path,
        identifier: Union[str, UUID],
        updated_data: Union[MCP, Dict[str, Any]],
        agent_name: Optional[str] = None,
        agent_id: Optional[UUID] = None,
    ) -> AgentConfig:
        """See :func:`agentsflow.dev.mcp_api.edit_mcp`."""
        return mcp_api.edit_mcp(
            base_dir,
            identifier,
            updated_data,
            agent_name=agent_name,
            agent_id=agent_id,
        )

    @staticmethod
    def get_mcp_details(
        base_dir: Path,
        identifier: Union[str, UUID],
        agent_name: Optional[str] = None,
        agent_id: Optional[UUID] = None,
    ) -> MCP:
        """See :func:`agentsflow.dev.mcp_api.get_mcp_details`."""
        return mcp_api.get_mcp_details(
            base_dir, identifier, agent_name=agent_name, agent_id=agent_id
        )

    @staticmethod
    def list_agent_mcps(
        base_dir: Path,
        agent_name: Optional[str] = None,
        agent_id: Optional[UUID] = None,
    ) -> List[MCPIdentity]:
        """See :func:`agentsflow.dev.mcp_api.list_agent_mcps`."""
        return mcp_api.list_agent_mcps(base_dir, agent_name=agent_name, agent_id=agent_id)

    @staticmethod
    def remove_mcp_from_agent(
        base_dir: Path,
        identifier: Union[str, UUID],
        agent_name: Optional[str] = None,
        agent_id: Optional[UUID] = None,
    ) -> AgentConfig:
        """See :func:`agentsflow.dev.mcp_api.remove_mcp_from_agent`."""
        return mcp_api.remove_mcp_from_agent(
            base_dir, identifier, agent_name=agent_name, agent_id=agent_id
        )


__all__ = ["PublicAPIDev"]
