"""
MCP (Model Context Protocol) management — DEV API
=================================================
Stores full MCP definitions under ``agents/<agent>/mcp/<name>/mcp_config.json`` and
keeps lightweight :class:`MCPIdentity` entries in the agent ``config.yaml``.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from filelock import FileLock

from agentsflow.constants import DEFAULT_MCP_DIR, MCP_AGENT_LOCK_FILE, MCP_CONFIG_FILE
from agentsflow.dev.agent_api import _resolve_agent_context
from agentsflow.errors import AgentsFlowConfigError, MCPAlreadyExistsError, MCPNotFoundError
from agentsflow.schema.agent_config_schema import AgentConfig
from agentsflow.schema.mcp_schema import MCP, MCPConfig, MCPIdentity
from agentsflow.utils.config_io import _write_agent_config


def _agent_lock_path(agent_dir: Path) -> Path:
    return agent_dir / MCP_AGENT_LOCK_FILE


def _mcp_instance_dir(agent_dir: Path, mcp_folder_name: str) -> Path:
    return agent_dir / DEFAULT_MCP_DIR / mcp_folder_name


def _mcp_config_path(agent_dir: Path, mcp_folder_name: str) -> Path:
    return _mcp_instance_dir(agent_dir, mcp_folder_name) / MCP_CONFIG_FILE


def _parse_mcp_input(data: Union[MCP, Dict[str, Any]]) -> MCP:
    if isinstance(data, MCP):
        return data
    return MCP.model_validate(data)


def _load_mcp_file(path: Path) -> MCP:
    if not path.exists():
        raise MCPNotFoundError(f"MCP config not found at {path}")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        raise AgentsFlowConfigError(f"Failed to read MCP config {path}: {e}") from e
    return MCP.model_validate(raw)


def _find_identity_index(
    identities: List[MCPIdentity], identifier: Union[str, UUID]
) -> int:
    if isinstance(identifier, UUID):
        for i, mid in enumerate(identities):
            if mid.id == identifier:
                return i
    else:
        for i, mid in enumerate(identities):
            if mid.name == identifier:
                return i
    raise MCPNotFoundError(f"No MCP matched identifier {identifier!r}")


def _folder_name_for_identity(identity: MCPIdentity) -> str:
    """Directory name under mcp/ — must match identity.name (validated pattern)."""
    return identity.name


def add_mcp_to_agent(
    base_dir: Path,
    mcp_data: Union[MCP, Dict[str, Any]],
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Register a new MCP server for an agent.

    Creates ``agents/<agent>/mcp/<name>/mcp_config.json`` with the full
    :class:`MCP` payload (identity + config), appends :class:`MCPIdentity` to
    ``config.yaml``, and validates all Pydantic models.

    Raises:
        FileNotFoundError: Agent directory does not exist.
        MCPAlreadyExistsError: Same MCP ``name`` or ``id`` already registered.
        AgentsFlowConfigError: Validation or filesystem error.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    if not agent_dir.is_dir():
        raise FileNotFoundError(f"Agent directory not found: {agent_dir}")

    mcp = _parse_mcp_input(mcp_data)
    folder = _folder_name_for_identity(mcp.identity)

    identities = list(agent_config.mcp_identities or [])
    for existing in identities:
        if existing.name == mcp.identity.name or existing.id == mcp.identity.id:
            raise MCPAlreadyExistsError(
                f"MCP already exists: name={existing.name!r} id={existing.id}"
            )

    lock = FileLock(str(_agent_lock_path(agent_dir)), timeout=60)
    with lock:
        inst_dir = _mcp_instance_dir(agent_dir, folder)
        if inst_dir.exists():
            raise MCPAlreadyExistsError(f"MCP directory already exists: {inst_dir}")
        inst_dir.mkdir(parents=True, exist_ok=True)
        cfg_path = inst_dir / MCP_CONFIG_FILE
        try:
            cfg_path.write_text(
                json.dumps(mcp.model_dump(mode="json"), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as e:
            shutil.rmtree(inst_dir, ignore_errors=True)
            raise AgentsFlowConfigError(f"Failed to write {cfg_path}: {e}") from e

        identities.append(mcp.identity)
        updated = agent_config.model_copy(update={"mcp_identities": identities})
        try:
            _write_agent_config(agent_dir, updated)
        except Exception:
            shutil.rmtree(inst_dir, ignore_errors=True)
            raise

    return updated


def edit_mcp(
    base_dir: Path,
    identifier: Union[str, UUID],
    updated_data: Union[MCP, Dict[str, Any]],
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Update an existing MCP by agent-scoped name or MCP UUID.

    Accepts a full :class:`MCP` instance or a dict with optional ``identity`` and/or
    ``config`` keys merged onto the stored definition. If ``identity.name`` changes,
    the directory ``mcp/<old_name>/`` is renamed to ``mcp/<new_name>/``.

    Raises:
        MCPNotFoundError: No MCP matches ``identifier``.
        MCPAlreadyExistsError: Rename would collide with another MCP name.
        AgentsFlowConfigError: Validation or IO failure.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    if not agent_dir.is_dir():
        raise FileNotFoundError(f"Agent directory not found: {agent_dir}")

    identities = list(agent_config.mcp_identities or [])
    idx = _find_identity_index(identities, identifier)
    old_identity = identities[idx]
    old_folder = _folder_name_for_identity(old_identity)
    cfg_path = _mcp_config_path(agent_dir, old_folder)
    current = _load_mcp_file(cfg_path)

    if isinstance(updated_data, MCP):
        new_mcp = updated_data
    else:
        merged_identity = current.identity.model_dump(mode="json")
        merged_config = current.config.model_dump(mode="json")
        if "identity" in updated_data and updated_data["identity"] is not None:
            merged_identity.update(updated_data["identity"])
        if "config" in updated_data and updated_data["config"] is not None:
            merged_config.update(updated_data["config"])
        new_mcp = MCP(
            identity=MCPIdentity.model_validate(merged_identity),
            config=MCPConfig.model_validate(merged_config),
        )

    new_folder = _folder_name_for_identity(new_mcp.identity)
    lock = FileLock(str(_agent_lock_path(agent_dir)), timeout=60)
    with lock:
        if new_folder != old_folder:
            new_inst = _mcp_instance_dir(agent_dir, new_folder)
            if new_inst.exists():
                raise MCPAlreadyExistsError(
                    f"Cannot rename MCP: target directory exists: {new_inst}"
                )
            old_inst = _mcp_instance_dir(agent_dir, old_folder)
            old_inst.rename(new_inst)

        write_path = _mcp_config_path(agent_dir, new_folder)
        write_path.write_text(
            json.dumps(new_mcp.model_dump(mode="json"), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        identities[idx] = new_mcp.identity
        updated = agent_config.model_copy(update={"mcp_identities": identities})
        _write_agent_config(agent_dir, updated)

    return updated


def get_mcp_details(
    base_dir: Path,
    identifier: Union[str, UUID],
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> MCP:
    """
    Return the full :class:`MCP` (identity + config) for the given MCP name or id.

    Reads ``mcp/<name>/mcp_config.json`` where ``name`` comes from the registered
    :class:`MCPIdentity` (folder name always matches ``identity.name``).

    Raises:
        MCPNotFoundError: Unknown MCP or missing file.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    identities = agent_config.mcp_identities or []
    if not identities:
        raise MCPNotFoundError("Agent has no MCP servers configured")

    idx = _find_identity_index(list(identities), identifier)
    folder = _folder_name_for_identity(identities[idx])
    return _load_mcp_file(_mcp_config_path(agent_dir, folder))


def list_agent_mcps(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> List[MCPIdentity]:
    """
    List all :class:`MCPIdentity` entries for the agent (from ``config.yaml``).

    This is the lightweight index; use :func:`get_mcp_details` for full configs.
    """
    _, agent_config, _ = _resolve_agent_context(base_dir, agent_id, agent_name)
    return list(agent_config.mcp_identities or [])


def remove_mcp_from_agent(
    base_dir: Path,
    identifier: Union[str, UUID],
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Remove an MCP from the agent: delete its directory under ``mcp/`` and drop the
    identity from ``config.yaml``.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    identities = list(agent_config.mcp_identities or [])
    idx = _find_identity_index(identities, identifier)
    mid = identities.pop(idx)
    folder = _folder_name_for_identity(mid)
    inst_dir = _mcp_instance_dir(agent_dir, folder)

    lock = FileLock(str(_agent_lock_path(agent_dir)), timeout=60)
    with lock:
        if inst_dir.is_dir():
            shutil.rmtree(inst_dir, ignore_errors=True)
        updated = agent_config.model_copy(
            update={"mcp_identities": identities if identities else None}
        )
        _write_agent_config(agent_dir, updated)

    return updated
