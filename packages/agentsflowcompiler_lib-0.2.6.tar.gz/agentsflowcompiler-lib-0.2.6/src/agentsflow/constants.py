"""
Shared Constants
================
Single source of truth for all path and naming constants used
across the agentsflow package.
"""

from pathlib import Path

# ── Project Structure ────────────────────────────────────────
AGENTS_DIR = "agents"
AGENT_CONFIG_FILE = "config.yaml"
AGENT_MANIFEST_FILE = "agents.yaml"
CONFIG_DIR = "config"

# ── Built-in Tools ───────────────────────────────────────────
DEFAULT_BUILTINS_DIR = Path(__file__).parent / "tools" / "builtins"
DEFAULT_TOOL_YAML_NAME = "tool.yaml"
DEFAULT_TOOL_PYTHON_NAME = "tool.py"
DEFAULT_DOCKER_CONFIG_FILE = "docker_config.yaml"

# ── Logs ─────────────────────────────────────────────────────
DEFAULT_RUN_HISTORY_DIR = Path("logs/run_history")
DEFAULT_AUDIT_LOGS_DIR = Path("logs/audit_logs")
DEFAULT_PROMPT_HISTORY_DIR = Path("logs/prompt_history")
DEFAULT_TOKEN_USAGE_DIR = Path("logs/token_usage")

DEFAULT_RUN_HISTORY_FILE = "flow_logs.json"
DEFAULT_AUDIT_LOGS_FILE = "audit_logs.json"
DEFAULT_PROMPT_HISTORY_FILE = "prompt_history.json"
DEFAULT_TOKEN_USAGE_FILE = "token_usage.json"

# Backward-compatible derived paths for internal use.
DEFAULT_FLOW_LOGS_PATH = DEFAULT_RUN_HISTORY_DIR / DEFAULT_RUN_HISTORY_FILE
DEFAULT_AUDIT_LOGS_PATH = DEFAULT_AUDIT_LOGS_DIR / DEFAULT_AUDIT_LOGS_FILE

# ── Processing Defaults ─────────────────────────────────────
DEFAULT_PREPROCESS_FUNCTION_NAME = "preprocess"
DEFAULT_POSTPROCESS_FUNCTION_NAME = "postprocess"
DEFAULT_PREPROCESS_PATH = Path("process/preprocess.py")
DEFAULT_POSTPROCESS_PATH = Path("process/postprocess.py")

DEFAULT_AGENT_TIMEOUT = 60

# ── Retry Policy Defaults ─────────────────────────────────────
DEFAULT_RETRY_MAX_ATTEMPTS = 5
DEFAULT_RETRY_BASE_DELAY = 2.0
DEFAULT_RETRY_MAX_DELAY = 60.0

DEFAULT_CUSTOM_TOOL_DIR = "tools/custom_tools"

# ── MCP (Model Context Protocol) ────────────────────────────
DEFAULT_MCP_DIR = "mcp"
MCP_CONFIG_FILE = "mcp_config.json"
MCP_AGENT_LOCK_FILE = ".mcp.lock"