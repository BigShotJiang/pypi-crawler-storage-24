
def compute_block_coverage(cfg):
	cv = []
	ncv = []
	for bid,bloco in cfg.blocks.items():
		if bloco.kind == 'EXIT':
			continue
		if bloco.covered:
			cv.append(bid)
		else:
			ncv.append(bid)
	return (cv, ncv)

def compute_edge_coverage(cfg):
	cv = []
	ncv = []
	for aresta in cfg.edges:
		if aresta.label == 'FAKE':
			continue
		if aresta.covered:
			cv.append((aresta.src,aresta.dst))
		else:
			ncv.append((aresta.src,aresta.dst))
	return (cv, ncv)

