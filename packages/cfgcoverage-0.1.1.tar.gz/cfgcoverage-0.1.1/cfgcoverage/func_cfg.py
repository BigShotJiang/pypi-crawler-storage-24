import ast
from typing import Dict, List, Optional

import cfgcoverage.CFGbuilder as cfgb
from cfgcoverage.CFGraph import CFG			 
import cfgcoverage.CFGraph as cfgg

class FunctionCFGCollector(ast.NodeVisitor):
	"""
	Devolve dict: { "arquivo[.Classe[.SubClasse...]].funcao": CFG }
	- Inclui funções de topo e métodos em classes.
	- Funções aninhadas (def dentro de def): opcional (ver flag).
	"""
	def __init__(self, filename: str, include_nested: bool = False) -> None:
		self.filename = filename
		self.include_nested = include_nested
		self.cfgs: Dict[str, CFG] = {}
		self.srcs: Dict[str,str] = {}
		self._class_stack: List[str] = []
		self._func_stack: List[str] = []  # só se include_nested=True
		self.ordinal = 0

	def _qual_name(self, func_name: str) -> str:
		parts = [self.filename] + self._class_stack
		if self.include_nested:
			parts += self._func_stack
		parts.append(func_name)
		return ".".join(parts)

	def _build_cfg_for_body(self, body_stmts: list[ast.stmt]) -> CFG:
		self.ordinal += 1
		b = cfgb.CFGBuilder(self.ordinal)
		tmp = ast.Module(body=body_stmts, type_ignores=[])
		cfg = b.build_for(tmp)
		return cfg

	def visit_ClassDef(self, node: ast.ClassDef) -> None:
		self._class_stack.append(node.name)
		self.generic_visit(node)
		self._class_stack.pop()

	def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
		key = self._qual_name(node.name)
		self.cfgs[key] = cfgg.simplify(self._build_cfg_for_body(node.body))
		self.srcs[key] = ast.unparse(node)

		if self.include_nested:
			self._func_stack.append(node.name)
			self.generic_visit(node)  # captura defs internos
			self._func_stack.pop()
		# se não incluir aninhadas, não chama generic_visit aqui

	def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
		key = self._qual_name(node.name)
		self.cfgs[key] = cfgg.simplify(self._build_cfg_for_body(node.body))
		self.srcs[key] = ast.unparse(node)

		if self.include_nested:
			self._func_stack.append(node.name)
			self.generic_visit(node)
			self._func_stack.pop()

def cfgs_by_qualified_function_name(tree, filename: str, include_nested: bool = False) -> Dict[str, CFG]:
	v = FunctionCFGCollector(filename=filename, include_nested=include_nested)
	v.visit(tree)
	return v.cfgs, v.srcs
