
from __future__ import annotations

import html
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional


@dataclass(frozen=True)
class FuncItem:
    name: str          # ex: "foo" ou "MyClass.method"
    dot: str           # texto DOT
    source: str        # código fonte só da função/método


def _safe_slug(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_.-]+", "_", name.strip())
    s = s.strip("._-")
    return s or "func"


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", errors="replace")


def _has_graphviz() -> bool:
    return shutil.which("dot") is not None


def _render_dot_to_bytes(dot_text: str, fmt: str) -> bytes:
    proc = subprocess.run(
        ["dot", f"-T{fmt}"],
        input=dot_text.encode("utf-8", errors="replace"),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if proc.returncode != 0 or not proc.stdout:
        err = proc.stderr.decode("utf-8", errors="replace")
        raise RuntimeError(f"Graphviz 'dot' failed (-T{fmt}).\n{err}".strip())
    return proc.stdout


def _html_page(title: str, body: str, extra_head: str = "") -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>{html.escape(title)}</title>
<style>
  :root {{
    --mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
    --sans: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, "Helvetica Neue", "Noto Sans", "Liberation Sans", sans-serif;
    --bg: #0b0d10;
    --panel: #12161c;
    --text: #e6edf3;
    --muted: #9fb0c0;
    --border: #263040;
    --link: #7cc7ff;
    --codebg: #0f1318;
  }}
  body {{
    margin: 0;
    font-family: var(--sans);
    background: var(--bg);
    color: var(--text);
  }}
  a {{ color: var(--link); text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  .wrap {{ padding: 16px; }}
  .card {{
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 10px;
  }}
  .muted {{ color: var(--muted); }}
  pre, code {{ font-family: var(--mono); }}
  pre {{
    background: var(--codebg);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 12px;
    overflow: auto;
    line-height: 1.35;
    font-size: 13px;
    margin: 0;
  }}
  .btn {{
    display: inline-block;
    padding: 6px 10px;
    border: 1px solid var(--border);
    border-radius: 8px;
    background: #0f1318;
    color: var(--text);
    cursor: pointer;
    user-select: none;
  }}
  .btn:hover {{ filter: brightness(1.1); }}
</style>
{extra_head}
</head>
<body>
{body}
</body>
</html>
"""


def _candidate_coverage_keys(func_name: str) -> list[str]:
    keys: list[str] = []

    def add(value: str) -> None:
        value = value.strip()
        if value and value not in keys:
            keys.append(value)

    add(func_name)

    base = func_name.split(" -- ", 1)[0].strip()
    add(base)

    # nome curto após o último '.'
    add(base.rsplit(".", 1)[-1])

    # se vier como "arquivo.py.func", também tenta "func"
    if ".py." in base:
        add(base.split(".py.", 1)[1])
        add(base.split(".py.", 1)[1].rsplit(".", 1)[-1])

    return keys


def _lookup_func_coverage(
    coverage_by_func: Optional[Mapping[str, Mapping[str, Any]]],
    func_name: str,
) -> Mapping[str, Any]:
    if not coverage_by_func:
        return {}
    for key in _candidate_coverage_keys(func_name):
        value = coverage_by_func.get(key)
        if isinstance(value, Mapping):
            return value
    return {}


def _normalize_pair(value: Any) -> tuple[list[Any], list[Any]]:
    if isinstance(value, (tuple, list)) and len(value) == 2:
        covered, missed = value
        covered = list(covered) if covered is not None else []
        missed = list(missed) if missed is not None else []
        return covered, missed
    return [], []


def _fmt_req_list(items: Any) -> str:
    if items is None:
        return "—"
    if isinstance(items, (list, tuple, set)):
        return ", ".join(str(x) for x in items) if items else "—"
    return str(items)


def _coverage_percent(covered: int, missed: int) -> int:
    total = covered + missed
    if total == 0:
        return 0
    return round((covered / total) * 100)


def _render_coverage_panel(cov: Mapping[str, Any]) -> str:
    if not cov:
        return ""

    parts: list[str] = []
    for criterion_name, criterion_value in cov.items():
        covered, missed = _normalize_pair(criterion_value)
        parts.append(
            f"""
<div class="covgroup">
  <div class="covtitle">{html.escape(str(criterion_name))}</div>
  <div><span class="covlabel">Covered:</span> {_fmt_req_list(covered)}</div>
  <div><span class="covlabel">Missed:</span> {_fmt_req_list(missed)}</div>
</div>
"""
        )

    return f'<div class="covpanel">{"".join(parts)}</div>'


def _render_index_coverage_summary(cov: Mapping[str, Any]) -> str:
    if not cov:
        return ""

    rows: list[str] = []
    for criterion_name, criterion_value in cov.items():
        covered, missed = _normalize_pair(criterion_value)
        pct = _coverage_percent(len(covered), len(missed))
        rows.append(f'<div>{html.escape(str(criterion_name))}: <strong>{pct}%</strong></div>')

    return f'<div class="covsummary">{"".join(rows)}</div>'


def generate_cfg_html(
    py_filename: str,
    funcs: Iterable[FuncItem],
    out_dir: str | Path = "out_cfg_html",
    thumbnail_cm: float = 3.0,
    coverage_by_func: Optional[Mapping[str, Mapping[str, Any]]] = None,
) -> Path:
    """
    Gera:
      - index.html: lista (nome -> thumbnail)
      - <slug>.html: página por função com código + CFG (SVG com zoom)
    Fallback sem graphviz:
      - index: mini preview do DOT
      - func page: DOT completo

    coverage_by_func:
      {
          "nome_da_funcao": {
              "Nome do Critério": ([cobertos...], [não_cobertos...]),
              ...
          },
          ...
      }
    """
    out_root = Path(out_dir)
    out_root.mkdir(parents=True, exist_ok=True)

    assets = out_root / "assets"
    assets.mkdir(exist_ok=True)

    gv_ok = _has_graphviz()

    entries = []
    for fd in funcs:
        slug = _safe_slug(fd.name)
        func_page = f"{slug}.html"
        func_cov = _lookup_func_coverage(coverage_by_func, fd.name)
        cov_panel_html = _render_coverage_panel(func_cov)
        index_cov_summary = _render_index_coverage_summary(func_cov)

        dot_path = assets / f"{slug}.dot"
        svg_path = assets / f"{slug}.svg"
        png_path = assets / f"{slug}.png"
        _write_text(dot_path, fd.dot)

        had_img = False
        svg_inline = ""
        thumb_html = ""
        graph_block_html = ""

        if gv_ok:
            try:
                svg_bytes = _render_dot_to_bytes(fd.dot, "svg")
                png_bytes = _render_dot_to_bytes(fd.dot, "png")
                svg_path.write_bytes(svg_bytes)
                png_path.write_bytes(png_bytes)

                svg_inline = svg_bytes.decode("utf-8", errors="replace")
                had_img = True

                thumb_html = (
                    f'<a href="{html.escape(func_page)}" title="Open {html.escape(fd.name)}">'
                    f'<img src="assets/{png_path.name}" class="thumb" alt="CFG thumbnail"/>'
                    f"</a>"
                )

                graph_block_html = f"""
<div class="graphpanel card">
  <div class="toolbar">
    <span class="muted">CFG</span>
    <div class="toolbuttons">
      <span class="btn" onclick="zoomIn()">Zoom +</span>
      <span class="btn" onclick="zoomOut()">Zoom -</span>
      <span class="btn" onclick="zoomReset()">Reset</span>
    </div>
  </div>

  <div class="graphsplit">
    <div id="graphViewport" class="viewport" onwheel="onWheelZoom(event)">
      <div id="graphCanvas" class="canvas">
        {svg_inline}
      </div>
    </div>
    {cov_panel_html}
  </div>
</div>
"""
            except Exception:
                had_img = False

        if not had_img:
            graph_block_html = f"""
<div class="graphpanel card">
  <div class="toolbar">
    <span class="muted">CFG (.dot)</span>
  </div>
  <div class="graphsplit">
    <pre>{html.escape(fd.dot)}</pre>
    {cov_panel_html}
  </div>
</div>
"""
            thumb_html = ""  # index vai usar preview de DOT

        src = fd.source or "# (empty source code)\n"

        func_body = f"""
<div class="wrap">
  <div style="display:flex; gap:12px; align-items:center; margin-bottom:12px; flex-wrap: wrap;">
    <a href="index.html">← Back</a>
    <span class="muted">{html.escape(py_filename)}</span>
    <span style="opacity:.4;">|</span>
    <strong>{html.escape(fd.name)}</strong>
  </div>

  <div class="grid">
    <div class="codepanel card">
      <div class="toolbar">
        <span class="muted">Source</span>
      </div>
      <pre>{html.escape(src)}</pre>
    </div>

    {graph_block_html}
  </div>
</div>

<style>
  .grid {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
  }}
  @media (max-width: 1000px) {{
    .grid {{ grid-template-columns: 1fr; }}
  }}
  .toolbar {{
    display:flex;
    justify-content: space-between;
    align-items:center;
    padding: 10px 12px;
    border-bottom: 1px solid var(--border);
  }}
  .codepanel, .graphpanel {{ overflow: hidden; }}
  .graphsplit {{
    display: grid;
    grid-template-columns: minmax(0, 1fr) 320px;
    gap: 0;
    align-items: start;
  }}
  @media (max-width: 1200px) {{
    .graphsplit {{
      grid-template-columns: 1fr;
    }}
  }}
  .viewport {{
    height: calc(100vh - 185px);
    overflow: auto;
    padding: 10px;
  }}
  .canvas {{
    transform-origin: 0 0;
  }}
  .canvas svg {{
    max-width: none;
    height: auto;
  }}
  .toolbuttons {{ display:flex; gap:8px; }}
  .covpanel {{
    border-left: 1px solid var(--border);
    padding: 16px;
    font-family: var(--mono);
    font-size: 14px;
    line-height: 1.5;
    overflow-wrap: anywhere;
  }}
  @media (max-width: 1200px) {{
    .covpanel {{
      border-left: none;
      border-top: 1px solid var(--border);
    }}
  }}
  .covgroup + .covgroup {{
    margin-top: 18px;
  }}
  .covtitle {{
    font-size: 18px;
    font-weight: 700;
    margin-bottom: 8px;
  }}
  .covlabel {{
    display: inline-block;
    min-width: 72px;
    color: var(--text);
    font-weight: 600;
  }}
</style>

<script>
  let scale = 1.0;
  function applyScale() {{
    const el = document.getElementById('graphCanvas');
    if (!el) return;
    el.style.transform = 'scale(' + scale.toFixed(3) + ')';
  }}
  function zoomIn() {{ scale = Math.min(6.0, scale * 1.15); applyScale(); }}
  function zoomOut() {{ scale = Math.max(0.2, scale / 1.15); applyScale(); }}
  function zoomReset() {{ scale = 1.0; applyScale(); }}

  function onWheelZoom(ev) {{
    if (!ev.ctrlKey) return;
    ev.preventDefault();
    const delta = ev.deltaY;
    if (delta < 0) zoomIn();
    else zoomOut();
  }}
  applyScale();
</script>
"""
        _write_text(out_root / func_page, _html_page(f"CFG — {fd.name}", func_body))

        entries.append((fd.name, func_page, had_img, thumb_html, index_cov_summary))

    # Index
    rows_html = []
    for name, page, had_img, thumb_html, index_cov_summary in entries:
        if had_img:
            right = thumb_html
        else:
            slug = _safe_slug(name)
            dot_preview = ""
            try:
                dot_text = (out_root / "assets" / f"{slug}.dot").read_text(encoding="utf-8", errors="replace")
                dot_preview = "\n".join(dot_text.splitlines()[:6])
            except Exception:
                pass
            right = f'<a href="{html.escape(page)}"><pre class="dotthumb">{html.escape(dot_preview)}</pre></a>'

        rows_html.append(f"""
<div class="row card">
  <div class="left">
    <a class="funcname" href="{html.escape(page)}">{html.escape(name)}</a>
    {index_cov_summary}
  </div>
  <div class="right">
    {right}
  </div>
</div>
""")

    index_body = f"""
<div class="wrap">
  <div style="margin-bottom:12px;">
    <div style="display:flex; gap:10px; align-items:baseline; flex-wrap: wrap;">
      <h2 style="margin:0;">CFG report</h2>
      <span class="muted">{html.escape(py_filename)}</span>
    </div>
    <div class="muted" style="margin-top:6px;">
      Click the name or the thumbnail to open the detailed view (with zoom).
      <span style="opacity:.55;">(Ctrl + scroll to zoom the graph)</span>
    </div>
  </div>

  <div class="list">
    {''.join(rows_html)}
  </div>
</div>

<style>
  .list {{
    display:flex;
    flex-direction: column;
    gap: 10px;
  }}
  .row {{
    display:grid;
    grid-template-columns: 340px 1fr;
    gap: 12px;
    padding: 10px 12px;
    align-items: center;
  }}
  @media (max-width: 900px) {{
    .row {{ grid-template-columns: 1fr; }}
  }}
  .funcname {{
    font-family: var(--mono);
    font-size: 14px;
    word-break: break-word;
  }}
  .covsummary {{
    margin-top: 10px;
    font-size: 13px;
    color: var(--text);
    line-height: 1.5;
  }}
  .thumb {{
    width: {thumbnail_cm}cm;
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: #fff;
  }}
  .dotthumb {{
    margin: 0;
    font-size: 11px;
    max-height: 6.5em;
  }}
</style>
"""
    _write_text(out_root / "index.html", _html_page("CFG report", index_body))
    return out_root / "index.html"
