
import sys
import argparse
import types
import ast, traceback
import shlex
import pickle
import unittest
import time
import os
import importlib.util
from pathlib import Path
from cfgcoverage.func_cfg import cfgs_by_qualified_function_name
from cfgcoverage.html_report import generate_cfg_html, FuncItem
from cfgcoverage.instrumentador import pre_instrument, InstrumenterVisitor
from cfgcoverage.CFGbuilder import CFGBuilder
from cfgcoverage.coverage import compute_block_coverage, compute_edge_coverage
from cfgcoverage.criteria import  EdgePair, EssentialBranch, PrimePath

exec_nodes = []

def __cov_node__(cfg, block):
	exec_nodes.append((cfg,block)) 


def __cov_cond__(cfg, block, result):
	exec_nodes.append((cfg,block)) 
	return result


def _to_module_name(key: str) -> str:
	# "dir/arquivo.py" -> "dir.arquivo"
	# "dir\\arquivo.py" (Windows) -> "dir.arquivo"
	# "arquivo.py" -> "arquivo"
	# "dir.arquivo" -> "dir.arquivo"
	if key.endswith(".py"):
		key = os.path.splitext(key)[0]
	key = key.replace(os.sep, ".")
	return key

def _ensure_module_hierarchy(module_name: str):
	parts = module_name.split(".")
	parent = None
	fullname = ""
	for part in parts[:-1]:
		fullname = f"{fullname}.{part}" if fullname else part
		if fullname in sys.modules:
			parent = sys.modules[fullname]
			continue
		# verifica se é um pacote real no disco
		if importlib.util.find_spec(fullname) is not None:
			# importa o pacote de verdade
			__import__(fullname)
			parent = sys.modules[fullname]
			continue
		# cria pacote "fake" só se não existe nem no sys.modules nem no disco
		pkg = types.ModuleType(fullname)
		pkg.__path__ = []  # pacote vazio
		sys.modules[fullname] = pkg
		if parent is not None:
			setattr(parent, part, pkg)
		parent = pkg
	return parent, parts
	

def _install_module(module_name: str, code_obj, inject: dict | None = None):
	"""
	Cria a hierarquia, executa code_obj no módulo final e registra em sys.modules.
	inject: dict com símbolos extras a injetar no módulo antes do exec.
	"""
	parent, parts = _ensure_module_hierarchy(module_name)
	mod = types.ModuleType(module_name)
	if inject:
		mod.__dict__.update(inject)
	exec(code_obj, mod.__dict__)
	sys.modules[module_name] = mod
	if parent is not None:
		setattr(parent, parts[-1], mod)
	return mod

def run_ast_tests(modules: dict, test_modules: dict, *, runner=None, verbosity=1):
	"""
	Compila e executa módulos e testes em memória usando ASTs.

	- modules: dict nome|path -> AST (ex: {'x.py': ast_x, 'pkg/aux.py': ast_aux})
	- test_modules: dict nome|path -> AST (ex: {'test_x.py': ast_tx})

	Retorna: unittest result object
	"""
	loaded_test_mods = []

	# === Etapa 1: carrega módulos normais (CUTs) ===
	for key, tree in modules.items():
		mod_name = _to_module_name(key)
		ast.fix_missing_locations(tree)
		code_obj = compile(tree, f"<{mod_name}>", "exec")
		# injeta dependências (ajuste se as funções tiverem outro nome/escopo)
		inject = {}
		if "__cov_node__" in globals():
			inject["__cov_node__"] = globals()["__cov_node__"]
		if "__cov_cond__" in globals():
			inject["__cov_cond__"] = globals()["__cov_cond__"]
		_install_module(mod_name, code_obj, inject=inject)

	# === Etapa 2: carrega módulos de teste ===
	for key, tree in test_modules.items():
		mod_name = _to_module_name(key)
		ast.fix_missing_locations(tree)
		code_obj = compile(tree, f"<{mod_name}>", "exec")
		test_mod = _install_module(mod_name, code_obj)
		loaded_test_mods.append(test_mod)

	# === Etapa 3: executa os testes ===
	suite = unittest.TestSuite()
	loader = unittest.defaultTestLoader
	for test_mod in loaded_test_mods:
		suite.addTests(loader.loadTestsFromModule(test_mod))

	if runner is None:
		runner = unittest.TextTestRunner(verbosity=verbosity)
	result = runner.run(suite)
	return result



def parse_args():

	# print("args.unittest:", args.unittest)
	# print("args.run:", args.run)
	# print("args.path:", args.path)
	# print("args.append:", args.append)
	# print("args.args:", args.args)
	# print("args.arquivo:", args.arquivo)

	args = Argumento()
	i = 1
	if sys.argv[i] == '--run':
		args.run = True
		i += 1


	while i < len(sys.argv) - 1:
		match sys.argv[i]:
			case '--path':
				i += 1
				args.path.append(sys.argv[i])
			case '--unittest':
				if args.run:
					usage()
				i += 1
				args.unittest.append(sys.argv[i])
			case '--args' :
				i += 1
				s = sys.argv[i]
				args.args = s.split()
			case _:
				usage()
		i += 1
	
	if i != len(sys.argv) - 1:
		usage()

	args.arquivo = sys.argv[i]
	return args

def usage():
	print("cfgcoverage — Structural Coverage Analyzer")
	print("--------------------------------------------------------------")
	print("Analyze and verify structural coverage criteria for Python programs.")
	print()
	print("Usage:")
	print("  python -m cfgcoverage [options] <source_file>")
	print()
	print("Main options:")
	print("  --run			 Execute the program and collect structural coverage data")
	print("  --append		  Accumulate coverage data across multiple runs")
	print("  --unittest FILE   Run the source file using tests defined in FILE (can be used multiple times)")
	print("  --path <PATH>	 Include <PATH> in the import path when executing unittest files")
	print("  --args \"ARGS\"	 Pass command-line arguments to the program being executed with --run")
	print("  --html			Generate an HTML report from previously collected coverage data")
	# print("  --total		   Show summarized coverage totals from previously collected data")
	# print("  --instr		   Print the instrumented version of the source file")
	print()
	print("Examples:")
	print("  python -m cfgcoverage foo.py")
	print("	 → Analyze foo.py, build CFGs, and save coverage data structures in foo.py.cfg")
	print()
	print("  python -m cfgcoverage --run foo.py")
	print("	 → Execute foo.py with instrumentation and record covered blocks and edges")
	print()
	print("  python -m cfgcoverage --run --append foo.py")
	print("	 → Execute foo.py and accumulate structural coverage results across multiple runs")
	print()
	print("  python -m cfgcoverage --run --args \"a b c\" foo.py")
	print("	 → Execute foo.py passing command-line arguments a b c to the instrumented program")
	print()
	print("  python -m cfgcoverage --unittest test_foo.py foo.py")
	print("	 → Run unit tests from test_foo.py against foo.py and collect structural coverage")
	print()
	print("  python -m cfgcoverage --unittest test_a.py --unittest test_b.py foo.py")
	print("	 → Run multiple unittest files and aggregate structural coverage from all executed tests")
	print()
	print("  python -m cfgcoverage --html foo.py")
	print("	 → Generate an HTML report in html/foo.py/index.html using the data stored in foo.py.cfg")
	print()
	print("  python -m cfgcoverage --instr foo.py")
	print("	 → Print the instrumented source code generated from foo.py")
	print()
	print("Notes:")
	print("  • The analysis stores internal data in a file named <source_file>.cfg.")
	print("  • HTML reports depend on previously generated .cfg data.")
	print("  • Current reports include at least Blocks, Edges, and Edge Pairs coverage.")
	print()
	print("Installation:")
	print("  pip install cfgcoverage")
	print()
	print("Author: Marcio Delamaro")
	print("License: MIT")
	print()
	print("For more information, visit the project page.")
	sys.exit(1)


def print_all_functions(dic_func):
	for name,cfg in dic_func.items():
		print(f'Function: {name} -- {cfg.ordinal}')
	

def __html():
	arquivo = sys.argv[-1]
	if len(sys.argv) != 3:
		print(red('Invalid argumet'))
		sys.exit(1)
	
	dic_cfg, dic_src, dic_ep, dic_essential, dic_pp, tree = le_dados(arquivo)

	fitem = []
	coverage = {}
	for name,cfg in dic_cfg.items():
		source = dic_src[name]
		allname = f'{name} -- {(cfg.ordinal)}'
		fitem.append(FuncItem(allname, str(cfg), source))
		block_cov = compute_block_coverage(cfg)
		edge_cov = compute_edge_coverage(cfg)
		ep = dic_ep[name]
		ep_cov = ep.get_coverage()
		essent_criteria = dic_essential[name]
		essential_cov = essent_criteria.get_coverage()
		pp_criteria = dic_pp[name]
		pp_cov =  pp_criteria.get_coverage()
		coverage[allname] = {'Blocks' : block_cov, 'Edges' : edge_cov, 'Essential arcs': essential_cov, 'Edge Pairs': ep_cov, 'Prime Paths': pp_cov}
	path = Path(arquivo)

	index = generate_cfg_html(arquivo, fitem, out_dir=path.parent / "html" / path.name, coverage_by_func=coverage)
	print(f'File generateed at: {index}')


def __run(args):

	arquivo = args.arquivo
	inicio = time.time()
	dic_cfg, dic_src, dic_ep, dic_essential, dic_pp, tree = le_dados(arquivo)


	# insere os caminhos para include
	for caminho in args.path:
		if caminho not in sys.path:
			sys.path.insert(0, caminho)

	# Cria um módulo virtual e injeta o canal no namespace
	mod = types.ModuleType("__main__")
	mod.__dict__['__cov_node__'] = __cov_node__  # injeta a função
	mod.__dict__['__cov_cond__'] = __cov_cond__  # injeta a função


	oldargv = sys.argv
	sys.argv = [args.arquivo]
	if args.args != []:
		sys.argv += shlex.split(args.args[-1])


	# Executa a AST no namespace do módulo
	exec(compile(tree, "<main>", "exec"), mod.__dict__)
	
	sys.argv = oldargv

	_atualiza_requisitos(dic_cfg, exec_nodes)
	_atualiza_ep_requisitos(dic_cfg, dic_ep, exec_nodes)
	_atualiza_essential_requisitos(dic_cfg, dic_essential, exec_nodes)
	_atualiza_pp_requisitos(dic_cfg, dic_pp, exec_nodes)


	salva_dados(arquivo, dic_cfg, dic_src, dic_ep, dic_essential, dic_pp, tree)

	fim = time.time()
	print('Run time: {:.5f} '.format( fim-inicio))

def __unittest(args):

	arquivo = args.arquivo
	inicio = time.time()
	dic_cfg, dic_src, dic_ep, dic_essential, dic_pp, tree = le_dados(arquivo)

	# insere os caminhos para include
	for caminho in args.path:
		if caminho not in sys.path:
			sys.path.insert(0, caminho)


	mod_dic = {arquivo:tree}
	test_dic = {}
	for name in args.unittest:
		try: 
			f = open(name)
			source = f.read()
			f.close()
			code = ast.parse(source)
		except Exception as ex:
			print(red('Error using {}. {}'.format(arquivo, str(ex))))
			sys.exit(1)
		test_dic[name] = code
		
	result = run_ast_tests(mod_dic,test_dic)

	_atualiza_requisitos(dic_cfg, exec_nodes)
	_atualiza_ep_requisitos(dic_cfg, dic_ep, exec_nodes)
	_atualiza_essential_requisitos(dic_cfg, dic_essential, exec_nodes)
	_atualiza_pp_requisitos(dic_cfg, dic_pp, exec_nodes)

	salva_dados(arquivo, dic_cfg, dic_src, dic_ep, dic_essential, dic_pp, tree)

	fim = time.time()
	print('Run time: {:.5f} '.format( fim-inicio))

def __nonexec():
	inicio = time.time()

	i = 2
	n = len(sys.argv)
	arquivo = sys.argv[-1]

	vetig = []
	recomp = False
	try: 
		while i < n - 1:
			s = sys.argv[i]
			if s == '--recalc':
				recomp = True
			else:	
				l = s.split()
				l = list(map(int, l))
				vetig.append((l[0],tuple(l[1:])))
			i += 1

	except Exception as ex:
		print(red('Invalid argumet'))
		print(red(ex))
		return

	dic_cfg, dic_src, dic_ep, dic_essential, dic_pp, tree = le_dados(arquivo)

	if recomp:
		recomp = False
		for numero, requisito in vetig:	
			if len(requisito) == 2:
				recomp = True
				break

	if recomp:
		for nome, cfg in dic_cfg.items():
			cfg.zero_coverage()
		for numero, requisito in vetig:	
			for nome, cfg in dic_cfg.items():
				if cfg.ordinal != numero:
					continue
				if len(requisito) == 2:
					cfg.remove_edge_by_number(requisito)
		dic_ep, dic_essential, dic_pp, _ = compute_all_criteria(dic_cfg, dic_src, None)
	
	for numero, requisito in vetig:	
		for nome, cfg in dic_cfg.items():
			if cfg.ordinal != numero:
				continue
			if len(requisito) == 2:
				cfg.remove_edge_by_number(requisito)
				essent = dic_essential[nome]
				essent.remove(requisito)
				#print("Essenciais:", essent)
			if len(requisito) <= 3:
				ep = dic_ep[nome]
				ep.remove(requisito)
				#print("Edge pair", ep) 
			pp = dic_pp[nome]
			pp.remove(requisito) 	

	salva_dados(arquivo, dic_cfg, dic_src, dic_ep, dic_essential, dic_pp, tree)

	fim = time.time()
	print('Run time: {:.5f} '.format( fim-inicio))

def _atualiza_requisitos(dic_cfg, exec_nodes):
	for name, cfg in dic_cfg.items():
		numero = cfg.ordinal
		traces = cfg.computa_traces(numero, exec_nodes)
		traces = cfg.mapeia_exec(traces)
		for one_exec in traces:
			cfg.atualiza_nodes_exec(one_exec)
			cfg.atualiza_edges_cover(one_exec)

def _atualiza_ep_requisitos(dic_cfg, dic_ep, exec_nodes):
	for name, cfg in dic_cfg.items():
		numero = cfg.ordinal
		traces = cfg.computa_traces(numero, exec_nodes)
		traces = cfg.mapeia_exec(traces)		
		ep_criterion = dic_ep[name]
		for one_exec in traces:
			ep_criterion.check_trace(one_exec)

# exec_nodes não é usado pq as arestas já foram marcadas como executadas
def _atualiza_essential_requisitos(dic_cfg, dic_ep, traces):
	for name, cfg in dic_cfg.items():
		ep_criterion = dic_ep[name]
		ep_criterion.check_trace(None)

def _atualiza_pp_requisitos(dic_cfg, dic_pp, exec_nodes):
	for name, cfg in dic_cfg.items():
		numero = cfg.ordinal
		traces = cfg.computa_traces(numero, exec_nodes)
		traces = cfg.mapeia_exec(traces)		
		pp_criterion = dic_pp[name]
		for one_exec in traces:
			pp_criterion.check_trace(one_exec)



def __instr():
	arquivo = sys.argv[-1]
	if len(sys.argv) != 3:
		print(red('Invalid argumet'))
		sys.exit(1)	
	try:
		with open(arquivo) as f:
			source =  f.read()
		tree = ast.parse(source)
		dic_cfg, dic_src = cfgs_by_qualified_function_name(tree, filename=arquivo, include_nested=True)
	except Exception as ex:
		print(red('Error using {}. {}'.format(arquivo, str(ex))))
		print(red(traceback.format_exc()))
		sys.exit(2)
	
	com,cond,iter = pre_instrument(dic_cfg)
	v_instr = InstrumenterVisitor(com, cond, iter)
	v_instr.visit(tree)
	ast.fix_missing_locations(tree)
	print(ast.unparse(tree))

def computa_cfgs_to_file(arquivo):
	try:
		with open(arquivo) as f:
			source =  f.read()
		tree = ast.parse(source)
		dic_cfg, dic_src = cfgs_by_qualified_function_name(tree, filename=arquivo,include_nested=True)
	except Exception as ex:
		print(red('Error using {}. {}'.format(arquivo, str(ex))))
		print(red(traceback.format_exc()))
		sys.exit(2)
	return dic_cfg, dic_src, tree

def compute_all_criteria(dic_cfg, dic_src, tree):
	dic_ep = {}
	for k,cfg in dic_cfg.items():
		ep = EdgePair('Edge Pair')
		ep.compute(cfg)
		dic_ep[k] = ep

	dic_essential = {}
	for k,cfg in dic_cfg.items():
		ep = EssentialBranch('Edge Pair')
		ep.compute(cfg)
		dic_essential[k] = ep
	
	dic_pp = {}
	for k,cfg in dic_cfg.items():
		pp = PrimePath('Prime Path')
		pp.compute(cfg)
		dic_pp[k] = pp

	if tree is not None:
		com,cond,iter = pre_instrument(dic_cfg)
		v_instr = InstrumenterVisitor(com, cond, iter)
		v_instr.visit(tree)
		ast.fix_missing_locations(tree)
	return dic_ep, dic_essential, dic_pp, tree



def main():


	if len(sys.argv) < 2:
		sys.exit(1)
	if sys.argv[1] == '--html':
		__html()
		sys.exit(0)	
	if sys.argv[1] == '--instr':
		__instr()
		sys.exit(0)
	if sys.argv[1] == '--infeasible':
		__nonexec()
		sys.exit(0)

	args = parse_args()
	arquivo = args.arquivo
	if args.run:
		__run(args)
		sys.exit(0)
	
	if args.unittest:
		__unittest(args)
		sys.exit(0)

	inicio = time.time()

	dic_cfg, dic_src, tree = computa_cfgs_to_file(arquivo)
	dic_ep, dic_essential, dic_pp, tree = compute_all_criteria(dic_cfg, dic_src, tree)

	print_all_functions(dic_cfg)

	salva_dados(args.arquivo, dic_cfg,dic_src, dic_ep, dic_essential, dic_pp, tree)
	fim = time.time()
	print('Run time: {:.5f} '.format( fim-inicio))


def salva_dados(arquivo, dic_cfg,dic_src, dic_ep, dic_essencial, dic_pp, tree):
	with open(arquivo+'.cfg','wb') as f:
		pickle.dump((dic_cfg,dic_src, dic_ep, dic_essencial, dic_pp, tree), f)

def le_dados(arquivo):
	try: 
		with open(arquivo+'.cfg','rb') as f:
			return pickle.load(f)
	except Exception as ex:
		print(red('Can´t read execution log file'))
		print(red(ex))
		sys.exit(1)

class Argumento():

	def __init__(self):
		self.args = []
		self.run = False
		self.unittest = []
		self.path = []
		self.arquivo = None
		self.append = False
		self.asserti = False
		
RED = '\033[31m'
GREEN = '\033[032m'
RESET = '\033[0m'

def red(s):
	if os.getenv('CFGCOVERAGECOLOR') != None :
		return RED + str(s) + RESET
	return s 

def green(s):
	if os.getenv('CFGCOVERAGECOLOR') != None :
		return GREEN + str(s) + RESET
	return s 

if __name__ == '__main__':
	main()
		

	
