import ast

class GenVisitor(ast.NodeVisitor):

	def __init__(self, code):
		


    def visit_AST(self, node):
        self.generic_visit(node)

    def visit_Add(self, node):
        self.generic_visit(node)

    def visit_And(self, node):
        self.generic_visit(node)

    def visit_AnnAssign(self, node):
        self.generic_visit(node)

    def visit_Assert(self, node):
        self.generic_visit(node)

    def visit_Assign(self, node):
        self.generic_visit(node)

    def visit_AsyncFor(self, node):
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node):
        self.generic_visit(node)

    def visit_AsyncWith(self, node):
        self.generic_visit(node)

    def visit_Attribute(self, node):
        self.generic_visit(node)

    def visit_AugAssign(self, node):
        self.generic_visit(node)

    def visit_AugLoad(self, node):
        self.generic_visit(node)

    def visit_AugStore(self, node):
        self.generic_visit(node)

    def visit_Await(self, node):
        self.generic_visit(node)

    def visit_BinOp(self, node):
        self.generic_visit(node)

    def visit_BitAnd(self, node):
        self.generic_visit(node)

    def visit_BitOr(self, node):
        self.generic_visit(node)

    def visit_BitXor(self, node):
        self.generic_visit(node)

    def visit_BoolOp(self, node):
        self.generic_visit(node)

    def visit_Break(self, node):
        self.generic_visit(node)

    def visit_Bytes(self, node):
        self.generic_visit(node)

    def visit_Call(self, node):
        self.generic_visit(node)

    def visit_ClassDef(self, node):
        self.generic_visit(node)

    def visit_Compare(self, node):
        self.generic_visit(node)

    def visit_Constant(self, node):
        self.generic_visit(node)

    def visit_Continue(self, node):
        self.generic_visit(node)

    def visit_Del(self, node):
        self.generic_visit(node)

    def visit_Delete(self, node):
        self.generic_visit(node)

    def visit_Dict(self, node):
        self.generic_visit(node)

    def visit_DictComp(self, node):
        self.generic_visit(node)

    def visit_Div(self, node):
        self.generic_visit(node)

    def visit_Ellipsis(self, node):
        self.generic_visit(node)

    def visit_Eq(self, node):
        self.generic_visit(node)

    def visit_ExceptHandler(self, node):
        self.generic_visit(node)

    def visit_Expr(self, node):
        self.generic_visit(node)

    def visit_Expression(self, node):
        self.generic_visit(node)

    def visit_ExtSlice(self, node):
        self.generic_visit(node)

    def visit_FloorDiv(self, node):
        self.generic_visit(node)

    def visit_For(self, node):
        self.generic_visit(node)

    def visit_FormattedValue(self, node):
        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        self.generic_visit(node)

    def visit_FunctionType(self, node):
        self.generic_visit(node)

    def visit_GeneratorExp(self, node):
        self.generic_visit(node)

    def visit_Global(self, node):
        self.generic_visit(node)

    def visit_Gt(self, node):
        self.generic_visit(node)

    def visit_GtE(self, node):
        self.generic_visit(node)

    def visit_If(self, node):
        self.generic_visit(node)

    def visit_IfExp(self, node):
        self.generic_visit(node)

    def visit_Import(self, node):
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        self.generic_visit(node)

    def visit_In(self, node):
        self.generic_visit(node)

    def visit_Index(self, node):
        self.generic_visit(node)

    def visit_Interactive(self, node):
        self.generic_visit(node)

    def visit_Invert(self, node):
        self.generic_visit(node)

    def visit_Is(self, node):
        self.generic_visit(node)

    def visit_IsNot(self, node):
        self.generic_visit(node)

    def visit_JoinedStr(self, node):
        self.generic_visit(node)

    def visit_LShift(self, node):
        self.generic_visit(node)

    def visit_Lambda(self, node):
        self.generic_visit(node)

    def visit_List(self, node):
        self.generic_visit(node)

    def visit_ListComp(self, node):
        self.generic_visit(node)

    def visit_Load(self, node):
        self.generic_visit(node)

    def visit_Lt(self, node):
        self.generic_visit(node)

    def visit_LtE(self, node):
        self.generic_visit(node)

    def visit_MatMult(self, node):
        self.generic_visit(node)

    def visit_Match(self, node):
        self.generic_visit(node)

    def visit_MatchAs(self, node):
        self.generic_visit(node)

    def visit_MatchClass(self, node):
        self.generic_visit(node)

    def visit_MatchMapping(self, node):
        self.generic_visit(node)

    def visit_MatchOr(self, node):
        self.generic_visit(node)

    def visit_MatchSequence(self, node):
        self.generic_visit(node)

    def visit_MatchSingleton(self, node):
        self.generic_visit(node)

    def visit_MatchStar(self, node):
        self.generic_visit(node)

    def visit_MatchValue(self, node):
        self.generic_visit(node)

    def visit_Mod(self, node):
        self.generic_visit(node)

    def visit_Module(self, node):
        self.generic_visit(node)

    def visit_Mult(self, node):
        self.generic_visit(node)

    def visit_Name(self, node):
        self.generic_visit(node)

    def visit_NameConstant(self, node):
        self.generic_visit(node)

    def visit_NamedExpr(self, node):
        self.generic_visit(node)

    def visit_Nonlocal(self, node):
        self.generic_visit(node)

    def visit_Not(self, node):
        self.generic_visit(node)

    def visit_NotEq(self, node):
        self.generic_visit(node)

    def visit_NotIn(self, node):
        self.generic_visit(node)

    def visit_Num(self, node):
        self.generic_visit(node)

    def visit_Or(self, node):
        self.generic_visit(node)

    def visit_Param(self, node):
        self.generic_visit(node)

    def visit_Pass(self, node):
        self.generic_visit(node)

    def visit_Pow(self, node):
        self.generic_visit(node)

    def visit_RShift(self, node):
        self.generic_visit(node)

    def visit_Raise(self, node):
        self.generic_visit(node)

    def visit_Return(self, node):
        self.generic_visit(node)

    def visit_Set(self, node):
        self.generic_visit(node)

    def visit_SetComp(self, node):
        self.generic_visit(node)

    def visit_Slice(self, node):
        self.generic_visit(node)

    def visit_Starred(self, node):
        self.generic_visit(node)

    def visit_Store(self, node):
        self.generic_visit(node)

    def visit_Str(self, node):
        self.generic_visit(node)

    def visit_Sub(self, node):
        self.generic_visit(node)

    def visit_Subscript(self, node):
        self.generic_visit(node)

    def visit_Suite(self, node):
        self.generic_visit(node)

    def visit_Try(self, node):
        self.generic_visit(node)

    def visit_TryStar(self, node):
        self.generic_visit(node)

    def visit_Tuple(self, node):
        self.generic_visit(node)

    def visit_TypeIgnore(self, node):
        self.generic_visit(node)

    def visit_UAdd(self, node):
        self.generic_visit(node)

    def visit_USub(self, node):
        self.generic_visit(node)

    def visit_UnaryOp(self, node):
        self.generic_visit(node)

    def visit_While(self, node):
        self.generic_visit(node)

    def visit_With(self, node):
        self.generic_visit(node)

    def visit_Yield(self, node):
        self.generic_visit(node)

    def visit_YieldFrom(self, node):
        self.generic_visit(node)

class GenTransformer(ast.NodeTransformer):
    def visit_AST(self, node):
        return self.generic_visit(node)

    def visit_Add(self, node):
        return self.generic_visit(node)

    def visit_And(self, node):
        return self.generic_visit(node)

    def visit_AnnAssign(self, node):
        return self.generic_visit(node)

    def visit_Assert(self, node):
        return self.generic_visit(node)

    def visit_Assign(self, node):
        return self.generic_visit(node)

    def visit_AsyncFor(self, node):
        return self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node):
        return self.generic_visit(node)

    def visit_AsyncWith(self, node):
        return self.generic_visit(node)

    def visit_Attribute(self, node):
        return self.generic_visit(node)

    def visit_AugAssign(self, node):
        return self.generic_visit(node)

    def visit_AugLoad(self, node):
        return self.generic_visit(node)

    def visit_AugStore(self, node):
        return self.generic_visit(node)

    def visit_Await(self, node):
        return self.generic_visit(node)

    def visit_BinOp(self, node):
        return self.generic_visit(node)

    def visit_BitAnd(self, node):
        return self.generic_visit(node)

    def visit_BitOr(self, node):
        return self.generic_visit(node)

    def visit_BitXor(self, node):
        return self.generic_visit(node)

    def visit_BoolOp(self, node):
        return self.generic_visit(node)

    def visit_Break(self, node):
        return self.generic_visit(node)

    def visit_Bytes(self, node):
        return self.generic_visit(node)

    def visit_Call(self, node):
        return self.generic_visit(node)

    def visit_ClassDef(self, node):
        return self.generic_visit(node)

    def visit_Compare(self, node):
        return self.generic_visit(node)

    def visit_Constant(self, node):
        return self.generic_visit(node)

    def visit_Continue(self, node):
        return self.generic_visit(node)

    def visit_Del(self, node):
        return self.generic_visit(node)

    def visit_Delete(self, node):
        return self.generic_visit(node)

    def visit_Dict(self, node):
        return self.generic_visit(node)

    def visit_DictComp(self, node):
        return self.generic_visit(node)

    def visit_Div(self, node):
        return self.generic_visit(node)

    def visit_Ellipsis(self, node):
        return self.generic_visit(node)

    def visit_Eq(self, node):
        return self.generic_visit(node)

    def visit_ExceptHandler(self, node):
        return self.generic_visit(node)

    def visit_Expr(self, node):
        return self.generic_visit(node)

    def visit_Expression(self, node):
        return self.generic_visit(node)

    def visit_ExtSlice(self, node):
        return self.generic_visit(node)

    def visit_FloorDiv(self, node):
        return self.generic_visit(node)

    def visit_For(self, node):
        return self.generic_visit(node)

    def visit_FormattedValue(self, node):
        return self.generic_visit(node)

    def visit_FunctionDef(self, node):
        return self.generic_visit(node)

    def visit_FunctionType(self, node):
        return self.generic_visit(node)

    def visit_GeneratorExp(self, node):
        return self.generic_visit(node)

    def visit_Global(self, node):
        return self.generic_visit(node)

    def visit_Gt(self, node):
        return self.generic_visit(node)

    def visit_GtE(self, node):
        return self.generic_visit(node)

    def visit_If(self, node):
        return self.generic_visit(node)

    def visit_IfExp(self, node):
        return self.generic_visit(node)

    def visit_Import(self, node):
        return self.generic_visit(node)

    def visit_ImportFrom(self, node):
        return self.generic_visit(node)

    def visit_In(self, node):
        return self.generic_visit(node)

    def visit_Index(self, node):
        return self.generic_visit(node)

    def visit_Interactive(self, node):
        return self.generic_visit(node)

    def visit_Invert(self, node):
        return self.generic_visit(node)

    def visit_Is(self, node):
        return self.generic_visit(node)

    def visit_IsNot(self, node):
        return self.generic_visit(node)

    def visit_JoinedStr(self, node):
        return self.generic_visit(node)

    def visit_LShift(self, node):
        return self.generic_visit(node)

    def visit_Lambda(self, node):
        return self.generic_visit(node)

    def visit_List(self, node):
        return self.generic_visit(node)

    def visit_ListComp(self, node):
        return self.generic_visit(node)

    def visit_Load(self, node):
        return self.generic_visit(node)

    def visit_Lt(self, node):
        return self.generic_visit(node)

    def visit_LtE(self, node):
        return self.generic_visit(node)

    def visit_MatMult(self, node):
        return self.generic_visit(node)

    def visit_Match(self, node):
        return self.generic_visit(node)

    def visit_MatchAs(self, node):
        return self.generic_visit(node)

    def visit_MatchClass(self, node):
        return self.generic_visit(node)

    def visit_MatchMapping(self, node):
        return self.generic_visit(node)

    def visit_MatchOr(self, node):
        return self.generic_visit(node)

    def visit_MatchSequence(self, node):
        return self.generic_visit(node)

    def visit_MatchSingleton(self, node):
        return self.generic_visit(node)

    def visit_MatchStar(self, node):
        return self.generic_visit(node)

    def visit_MatchValue(self, node):
        return self.generic_visit(node)

    def visit_Mod(self, node):
        return self.generic_visit(node)

    def visit_Module(self, node):
        return self.generic_visit(node)

    def visit_Mult(self, node):
        return self.generic_visit(node)

    def visit_Name(self, node):
        return self.generic_visit(node)

    def visit_NameConstant(self, node):
        return self.generic_visit(node)

    def visit_NamedExpr(self, node):
        return self.generic_visit(node)

    def visit_Nonlocal(self, node):
        return self.generic_visit(node)

    def visit_Not(self, node):
        return self.generic_visit(node)

    def visit_NotEq(self, node):
        return self.generic_visit(node)

    def visit_NotIn(self, node):
        return self.generic_visit(node)

    def visit_Num(self, node):
        return self.generic_visit(node)

    def visit_Or(self, node):
        return self.generic_visit(node)

    def visit_Param(self, node):
        return self.generic_visit(node)

    def visit_Pass(self, node):
        return self.generic_visit(node)

    def visit_Pow(self, node):
        return self.generic_visit(node)

    def visit_RShift(self, node):
        return self.generic_visit(node)

    def visit_Raise(self, node):
        return self.generic_visit(node)

    def visit_Return(self, node):
        return self.generic_visit(node)

    def visit_Set(self, node):
        return self.generic_visit(node)

    def visit_SetComp(self, node):
        return self.generic_visit(node)

    def visit_Slice(self, node):
        return self.generic_visit(node)

    def visit_Starred(self, node):
        return self.generic_visit(node)

    def visit_Store(self, node):
        return self.generic_visit(node)

    def visit_Str(self, node):
        return self.generic_visit(node)

    def visit_Sub(self, node):
        return self.generic_visit(node)

    def visit_Subscript(self, node):
        return self.generic_visit(node)

    def visit_Suite(self, node):
        return self.generic_visit(node)

    def visit_Try(self, node):
        return self.generic_visit(node)

    def visit_TryStar(self, node):
        return self.generic_visit(node)

    def visit_Tuple(self, node):
        return self.generic_visit(node)

    def visit_TypeIgnore(self, node):
        return self.generic_visit(node)

    def visit_UAdd(self, node):
        return self.generic_visit(node)

    def visit_USub(self, node):
        return self.generic_visit(node)

    def visit_UnaryOp(self, node):
        return self.generic_visit(node)

    def visit_While(self, node):
        return self.generic_visit(node)

    def visit_With(self, node):
        return self.generic_visit(node)

    def visit_Yield(self, node):
        return self.generic_visit(node)

    def visit_YieldFrom(self, node):
        return self.generic_visit(node)
