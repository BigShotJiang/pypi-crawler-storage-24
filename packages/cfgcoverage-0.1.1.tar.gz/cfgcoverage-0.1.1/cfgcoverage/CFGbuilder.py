
import ast, tokenize, sys, os, math
from typing import List, Dict, Optional, Tuple, Any
from cfgcoverage.CFGraph import CFG
import cfgcoverage.func_cfg as fcfg
# 
#  -----------------------------
# Builder / Visitor
# -----------------------------

class CFGBuilder(ast.NodeVisitor):
	"""
	Constrói CFG por função (FunctionDef/AsyncFunctionDef) ou módulo.
	- Blocos básicos com lista de stmts.
	- Um "terminador" (return/raise/break/continue) fecha o fluxo do bloco.
	- Loops usam uma stack para destinos de break/continue.
	- try/except/else/finally: modelagem aproximada (útil em cobertura).
	"""

	def __init__(self, ordinal) -> None:
		self.cfg = CFG(ordinal=ordinal)
		self.cur: int = self.cfg.add_block('BB')
		self.cfg.entry = self.cur

		# stacks para loops
		self.loop_stack: List[Tuple[int, int]] = []  # (continue_target, break_target)

		# stack para "finally" (se existir) — modelagem simples
		self.finally_stack: List[int] = []  # bloco de entrada do finally atual

	# ---- helpers ----

	def _new_block(self, kind: str = 'BB') -> int:
		bid = self.cfg.add_block(kind)
		return bid

	def _emit_stmt(self, stmt: ast.stmt) -> None:
		self.cfg.blocks[self.cur].tooltip += ast.unparse(stmt)+'\n'
		self.cfg.blocks[self.cur].stmts.append(stmt)

	def _emit_stmt_block(self, stmt: ast.stmt, bid) -> None:
		self.cfg.blocks[bid].stmts.append(stmt)

	def _end_block(self,  kind: str = 'ENDB') -> None:
		"""Força fechamento: cria próximo bloco e move o cursor."""
		nxt = self._new_block(kind)
		self.cfg.add_edge(self.cur, nxt, "")
		self.cur = nxt

	def _jump(self, cont_target: int, break_target: int, label = '', *, kind='') -> None:
		"""Cria aresta e inicia novo bloco 'solto' (sem queda automática)."""
		if cont_target is not None:
			self.cfg.add_edge(self.cur, cont_target, label)
		if break_target is not None:
			self.cfg.add_edge(self.cur, break_target, label)
		self.cur = self._new_block()

	def _terminate(self) -> None:
		"""Marca saída do fluxo a partir do bloco atual (sem fall-through)."""
		self.cfg.exits.append(self.cur)
		self.cfg.blocks[self.cur].exitnode = True
		cur = self.cur
		self.cur = self._new_block('TERMINATE')
		self.cfg.add_edge(cur, self.cur, 'FAKE')

	def _visit_stmt_list(self, stmts: List[ast.stmt]) -> None:
		for s in stmts:
			self.visit(s)

	def gt_block(self, bid):
		return self.cfg.blocks[bid]

	def _ensure_fresh_block(self, edge_label: str = "", kind='') -> None:
		"""Se o bloco atual já tem stmts, cria um novo bloco e cai nele."""
		if self.cfg.blocks[self.cur].stmts:
			nxt = self._new_block(kind)
			self.cfg.add_edge(self.cur, nxt, edge_label)
			self.cur = nxt
		else:
			self.cfg.blocks[self.cur].kind = kind

	# ---- entry points úteis ----

	def build_for(self, node: ast.AST) -> CFG:
		self.visit(node)
		# Se o bloco atual ainda está “vivo”, considere como saída natural
		if self.cfg.blocks[self.cur].stmts or self.cur == self.cfg.entry:
			self.cfg.exits.append(self.cur)
			self.cfg.blocks[self.cur].exitnode = True
		# remove duplicatas
		self.cfg.exits = sorted(set(self.cfg.exits))
		return self.cfg

	# ---- nós de alto nível ----

	def visit_Module(self, node: ast.Module) -> Any:
		self._visit_stmt_list(node.body)

	def visit_FunctionDef(self, node: ast.FunctionDef) -> Any:
		# Se quiser CFG por função, crie um builder por função.
		# Aqui, por padrão, tratamos o corpo inline (útil se você chamar build_for(node)).
		self._emit_stmt(node)  # opcional: registrar def como stmt no CFG "externo"
		# Para CFG do corpo:
		# comente as 2 linhas acima e descomente abaixo se preferir "entrar" na função:
		# self._visit_stmt_list(node.body)

	def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> Any:
		self.visit_FunctionDef(node)

	# ---- statements lineares ----

	def visit_Expr(self, node: ast.Expr) -> Any:
		self._emit_stmt(node)

	def visit_Delete(self, node: ast.Expr) -> Any:
		self._emit_stmt(node)

	def visit_Global(self, node: ast.Expr) -> Any:
		self._emit_stmt(node)

	def visit_Nonlocal(self, node: ast.Expr) -> Any:
		self._emit_stmt(node)

	def visit_Assign(self, node: ast.Assign) -> Any:
		self._emit_stmt(node)

	def visit_AnnAssign(self, node: ast.AnnAssign) -> Any:
		self._emit_stmt(node)

	def visit_AugAssign(self, node: ast.AugAssign) -> Any:
		self._emit_stmt(node)

	def visit_Pass(self, node: ast.Pass) -> Any:
		self._emit_stmt(node)

	def visit_Import(self, node: ast.Import) -> Any:
		self._emit_stmt(node)

	def visit_ImportFrom(self, node: ast.ImportFrom) -> Any:
		self._emit_stmt(node)

	def visit_With(self, node: ast.With) -> Any:
		# garante que o WITH não “cole” em stmts anteriores
		self._ensure_fresh_block(kind="WITH")

		header = self.cur
		self._emit_stmt(node)  # marcador do "with ...:"

		body_blk = self._new_block("WITH_BODY")
		after_blk = self._new_block("WITH_AFTER")

		# entra no corpo do with
		self.cfg.add_edge(header, body_blk, "with:enter")

		# visita corpo em um bloco separado
		self.cur = body_blk
		self._visit_stmt_list(node.body)


		# se o corpo não terminou (return/raise/break/continue), cai no AFTER
		if self.cfg.blocks[self.cur].kind != 'TERMINATE':
			self.cfg.add_edge(self.cur, after_blk, "with:exit")
		else:
			inblk = self.cfg.in_edge(self.gt_block(self.cur))
			self.cfg.add_edge(inblk[0].src, after_blk, 'FAKE')

		# continuação sempre começa num bloco novo
		self.cur = after_blk

	def visit_AsyncWith(self, node: ast.AsyncWith) -> Any:
		self.visit_With(node)

	# ---- terminadores ----

	def visit_Return(self, node: ast.Return) -> Any:
		self._emit_stmt(node)

	
		if self.finally_stack:
			fh = self.finally_stack[-1]["finally_hub"]
			self.cfg.add_edge(self.cur, fh, "return:via_finally")
			# após return, sequência é inalcançável
			self.cur = self._new_block("DEAD")
			return

		self._terminate()


	def visit_Raise(self, node: ast.Raise) -> Any:
		self._emit_stmt(node)

		if self.finally_stack:
			fh = self.finally_stack[-1]["finally_hub"]
			self.cfg.add_edge(self.cur, fh, "raise:via_finally")
			self.cur = self._new_block("DEAD")
			return

		self._terminate()



	def visit_Break(self, node: ast.Break) -> Any:
		self._emit_stmt(node)

		if not self.loop_stack:
			self._terminate()
			return

		_, break_tgt = self.loop_stack[-1]

		# Se estamos dentro de try/finally: break desvia para finally_hub
		if self.finally_stack:
			ctx = self.finally_stack[-1]
			fh = ctx["finally_hub"]
			self.cfg.add_edge(self.cur, fh, "break:via_finally")
			ctx["pending_break"].add(break_tgt)

			# Continua construção em um bloco novo "solto"
			self.cur = self._new_block('DEAD')
			return

		# Caso normal (fora de finally)
		self._jump(None, break_tgt, 'break')


	def visit_Continue(self, node: ast.Continue) -> Any:
		self._emit_stmt(node)

		if not self.loop_stack:
			self._terminate()
			return

		cont_tgt, break_tgt = self.loop_stack[-1]

		if self.finally_stack:
			ctx = self.finally_stack[-1]
			fh = ctx["finally_hub"]
			self.cfg.add_edge(self.cur, fh, "continue:via_finally")
			ctx["pending_continue"].add(cont_tgt)
			self.cur = self._new_block('DEAD')
			return

		self._jump(cont_tgt, break_tgt, 'continue')


	# ---- IF ----

	def visit_If(self, node: ast.If) -> Any:
		self._ensure_fresh_block(kind='IF')
		# fecha bloco atual com o "if" como terminador lógico do bloco
		self._emit_stmt(node)

		then_blk = self._new_block('THEN')
		else_blk = self._new_block('ELSE')
		join_blk = self._new_block('JOIN')

		entry = self.build_guard(node.test, then_blk, else_blk)
		self.cfg.add_edge(self.cur, entry, "cond")
		
		# THEN
		self.cur = then_blk
		self._visit_stmt_list(node.body)
		# se bloco atual ainda não terminou, cai no join
		if self.cur not in self.cfg.exits and self.cfg.blocks[self.cur] is not None:
			self.cfg.add_edge(self.cur, join_blk, "")
		# ELSE
		self.cur = else_blk
		self._visit_stmt_list(node.orelse)
		if self.cur not in self.cfg.exits and self.cfg.blocks[self.cur] is not None:
			self.cfg.add_edge(self.cur, join_blk, "")

		self.cur = join_blk

	# ---- WHILE ----

	def visit_While(self, node: ast.While) -> Any:
		self._ensure_fresh_block(kind='WHILE')

		header = self.cur 
		self._emit_stmt(node)

		body_blk = self._new_block('WHILE_BODY')

		# NOVO: dois blocos diferentes
		else_entry = self._new_block('WHILE_COND_FALSE')   # saída normal do guard (onde começa o else, se existir)
		after_loop = self._new_block('WHILE_AFTER')		# continuação depois do while/else (alvo do break)

		# Condição falsa vai para else_entry (não para after_loop)
		entry = self.build_guard(node.test, body_blk, else_entry)
		self.cfg.add_edge(header, entry, "while:cond")
		self.cfg.map_in[entry] = header

		# loop targets: continue->header, break->after_loop  (NOVO)
		self.loop_stack.append((header, after_loop))

		# BODY
		self.cur = body_blk
		self._visit_stmt_list(node.body)
		if self.cur not in self.cfg.exits:
			self.cfg.add_edge(self.cur, header, "back")

		self.loop_stack.pop()

		# ORELSE do while
		if node.orelse:
			else_blk = self._new_block('WHILE_ELSE')
			self.cfg.add_edge(else_entry, else_blk, "orelse")   # NOVO: usa else_entry
			self.cur = else_blk
			self._visit_stmt_list(node.orelse)

			if self.cur not in self.cfg.exits:
				self.cfg.add_edge(self.cur, after_loop, "")	 # NOVO: else cai em after_loop
			self.cur = after_loop
		else:
			# Sem else: condição falsa cai direto no after_loop
			self.cfg.add_edge(else_entry, after_loop, "while:done")  # ou "" se preferir
			self.cur = after_loop


	# ---- FOR ----

	def visit_For(self, node: ast.For) -> Any:
		# evita misturar statements anteriores com o nó FOR_PRE
		self._ensure_fresh_block(kind='FOR_PRE')

		# 1) PREHEADER: executa 1 vez
		pre = self.cur
		self._emit_stmt(node)  # marcador "for target in iter:" (parte PRE)

		# 2) ITERCHECK: executa a cada iteração (next?/StopIteration)
		iterc = self._new_block("FOR_ITER")
		self.cfg.map_out[pre] = iterc

		self._emit_stmt_block(node, iterc)
		self.cfg.add_edge(pre, iterc, "for:iter")

		body_blk = self._new_block("FOR_BODY")
		self.cfg.map_in[body_blk] = iterc

		after_blk = self._new_block("FOR_AFTER")
		# if not node.orelse:
		# 	self.cfg.map_in[after_blk] = iterc
		# T: há próximo elemento -> corpo
		self.cfg.add_edge(iterc, body_blk, "Next")

		# targets: continue volta pro iterc; break vai pro after (OK!)
		self.loop_stack.append((iterc, after_blk))

		# 3) BODY
		self.cur = body_blk
		self._visit_stmt_list(node.body)

		# queda normal do corpo -> iterc (próxima iteração)
		if self.cur not in self.cfg.exits:
			self.cfg.add_edge(self.cur, iterc, "next")

		self.loop_stack.pop()

		# 4) ORELSE do for (executa quando termina sem break)
		if node.orelse:
			else_blk = self._new_block("FOR_ORELSE")
			self.cfg.map_in[else_blk] = iterc

			# >>> CORREÇÃO: fim normal (Not_Next) entra DIRETO no else
			self.cfg.add_edge(iterc, else_blk, "Not_Next")

			self.cur = else_blk
			self._visit_stmt_list(node.orelse)

			# >>> CORREÇÃO: else cai no after (após for/else)
			if self.cur not in self.cfg.exits:
				self.cfg.add_edge(self.cur, after_blk, "")

			self.cur = after_blk
		else:
			# sem else: fim normal cai direto no after
			self.cfg.add_edge(iterc, after_blk, "Not_Next")
			node_iterc = self.cfg.blocks[iterc]
			for edg in self.cfg.in_edge(node_iterc):
				src = edg.src
				if src != pre:
					self.cfg.add_edge(src, after_blk, "No_Next")
			self.cur = after_blk

			

	
	def visit_AsyncFor(self, node: ast.AsyncFor) -> Any:
		self.visit_For(node)

	def visit_Try(self, node: ast.Try) -> Any:
		# garante que o TRY_HUB (self.cur) não esteja “misturado” com stmts anteriores
		self._ensure_fresh_block(kind="TRY_HUB")

		# TRY_HUB = bloco corrente
		try_hub = self.cur
		self._emit_stmt(node)

		# 1) corpo do try
		body_entry = self._new_block("TRY_BODY_ENTRY")
		self.cfg.add_edge(try_hub, body_entry, "try:enter")

		# 2) FINALLY_HUB (join estrutural)
		

		# >>> Ativa contexto de finally (só se houver finalbody), para capturar break/continue via finally
		if node.finalbody:
			finally_hub = self._new_block("FINALLY_HUB")
			self.finally_stack.append({
				"finally_hub": finally_hub,
				"pending_break": set(),
				"pending_continue": set(),
			})
		else:
			finally_hub = self._new_block()

		# 3) visita TRY BODY (+ orelse) e liga ao FINALLY_HUB
		self.cur = body_entry
		self._visit_stmt_list(node.body)

		if node.orelse:
			orelse_blk = self._new_block( "TRY_ORELSE")
			if self.cur not in self.cfg.exits:
				self.cfg.add_edge(self.cur, orelse_blk, "try:orelse")
			self.cur = orelse_blk
			self._visit_stmt_list(node.orelse)

		if self.cur not in self.cfg.exits:
			self.cfg.add_edge(self.cur, finally_hub, "")

		# 4) HANDLERS: existem, mas SEM arco de entrada 
		for h in node.handlers:
			hb = self._new_block("TRY_HANDLER")
			self.cfg.add_edge(try_hub, hb, "FAKE")
			self.cur = hb
			self._emit_stmt(h)	  # marcador
			self._ensure_fresh_block()
			self.cfg.map_in[self.cur] = hb
		#	self.cfg.map_in[hb] = -318
			self._visit_stmt_list(h.body)

			# opcional: convergir estruturalmente no finally_hub
			if self.cur not in self.cfg.exits and finally_hub:
				self.cfg.add_edge(self.cur, finally_hub, "finally:in_handler")

		# 5) FINALLY (se existir)
		if node.finalbody:
			finally_body = self._new_block("FINALLY_BODY")

			finally_after = self._new_block("FINALLY_AFTER")
			self.cfg.exits.append(finally_after)
			self.cfg.blocks[finally_after].exitnode = True

			self.cfg.add_edge(finally_hub, finally_body, "finally:enter")
			ctx = self.finally_stack.pop()

			self.cur = finally_body
			self._visit_stmt_list(node.finalbody)

			if self.cur not in self.cfg.exits:
				self.cfg.add_edge(self.cur, finally_after, "finally:after")
				self.cfg.map_out[self.cur] = finally_after

			# >>> Despacha break/continue pendentes para seus destinos reais
			for tgt in ctx["pending_break"]:
				self.cfg.add_edge(finally_after, tgt, "break")
			for tgt in ctx["pending_continue"]:
				self.cfg.add_edge(finally_after, tgt, "continue")

			self.cur = finally_after
			nxt = self._new_block()
			self.cfg.add_edge(finally_after, nxt, "finally:Normal_exit")   # queda normal
			self.cfg.map_in[nxt] = finally_after
			self.cur = nxt

		else:
			self.cur = finally_hub
			
			

	def visit_TryStar(self, node):
		self.visit_Try(node)

	# ---- MATCH/CASE (3.10+) ----

	def visit_Match(self, node: ast.Match) -> Any:
		self._ensure_fresh_block(kind="MATCH")
		self._emit_stmt(node)

		start = self.cur
		join = self._new_block("JOIN")

		# ponto onde começa o teste do próximo case
		last_test = start

		for i, c in enumerate(node.cases):
			# nó de condição do case i (pattern + guard)
			test = self._new_cond_block(c, 'CASE')
			self.cfg.add_edge(last_test, test, f"case#{i}:test")

			# ramo True: executa corpo do case
			body = self._new_block("BB")
			self.cfg.add_edge(test, body, "T")

			self.cur = body
			self._visit_stmt_list(c.body)

			# se o corpo cai normalmente, vai pro join
			# (se você ainda não tem ended_normally, isso é a parte que dá dor de cabeça;
			#  ver observação abaixo)
			if self.cfg.blocks[self.cur].kind != 'TERMINATE':	
				self.cfg.add_edge(self.cur, join, "matched")

			last_test = test

		# se não teve default, ainda existe o caminho "nenhum casou" => join
		self.cfg.add_edge(last_test, join, "no-match")

		self.cur = join


###########################################
# Utilitários pR condições
	def _new_cond_block(self, expr: ast.expr, kind = 'COND') -> int:
		b = self._new_block(kind)
		# guarde a expressão para o DOT/debug (não é stmt)
		setattr(self.cfg.blocks[b], "cond", expr)
		return b

	def build_guard(self, expr: ast.expr, t_target: int, f_target: int) -> int:
		"""
		Constrói subgrafo booleano com short-circuit.
		Retorna o nó de entrada do subgrafo.
		"""

		# not E  => inverte destinos
		if isinstance(expr, ast.UnaryOp) and isinstance(expr.op, ast.Not):
			return self.build_guard(expr.operand, f_target, t_target)

		# AND (corrigido para BoolOp aninhado)
		if isinstance(expr, ast.BoolOp) and isinstance(expr.op, ast.And):
			vals = expr.values
			entry = None
			next_true_target = None

			# construímos da direita para a esquerda para saber o "próximo" do True
			for v in reversed(vals):
				if next_true_target is None:
					# último: True->t_target, False->f_target
					v_entry = self.build_guard(v, t_target, f_target)
				else:
					# não-último: True->entry_do_proximo, False->f_target
					v_entry = self.build_guard(v, next_true_target, f_target)
				next_true_target = v_entry
				entry = v_entry

			return entry

	# OR (corrigido para BoolOp aninhado)
		if isinstance(expr, ast.BoolOp) and isinstance(expr.op, ast.Or):
			vals = expr.values
			# entrada é um subgrafo para o primeiro valor
			# (se for atômico, build_guard cria 1 nó; se for BoolOp, cria vários)
			# Para OR: True vai para t_target; False vai para o próximo valor
			# então precisamos construir em cascata da esquerda p/ direita.
			entry = None
			next_false_target = None

			# construímos da direita para a esquerda para saber o "próximo" do False
			for v in reversed(vals):
				if next_false_target is None:
					# último: True->t_target, False->f_target
					v_entry = self.build_guard(v, t_target, f_target)
				else:
					# não-último: True->t_target, False->entry_do_proximo
					v_entry = self.build_guard(v, t_target, next_false_target)
				next_false_target = v_entry
				entry = v_entry

			return entry


		# # compare encadeado: a < b < c  (aprox como (a<b) and (b<c))
		# if isinstance(expr, ast.Compare) and len(expr.ops) > 1:
		# 	comps = []
		# 	left = expr.left
		# 	for op, right in zip(expr.ops, expr.comparators):
		# 		comps.append(ast.Compare(left=left, ops=[op], comparators=[right]))
		# 		left = right
		# 	return self.build_guard(ast.BoolOp(op=ast.And(), values=comps), t_target, f_target)

		# atômico
		n = self._new_cond_block(expr)
		self.cfg.add_edge(n, t_target, "T")
		self.cfg.add_edge(n, f_target, "F")
		return n

# -----------------------------
# Utilitários de debug/visualização
# -----------------------------

def build_cfg_from_source(src: str) -> CFG:
	tree = ast.parse(src)
	b = CFGBuilder()
	return b.build_for(tree)

def dump_cfg(cfg: CFG) -> None:
	print("Blocks:")
	for bid in sorted(cfg.blocks):
		blk = cfg.blocks[bid]
		print(f"  B{bid}:")
		for s in blk.stmts:
			# cuidado: ExceptHandler/Pass placeholder etc.
			if isinstance(s, ast.AST) and hasattr(ast, "unparse") and isinstance(s, ast.stmt):
				print("	", ast.unparse(s).replace("\n", " "))
			else:
				print("	", type(s).__name__)
	print("\nEdges:")
	for e in cfg.edges:
		print(f"  B{e.src} -> B{e.dst} [{e.label}]")
	print("\nEntry:", cfg.entry, "Exits:", cfg.exits)


if __name__ == "__main__":
	arqname = sys.argv[1]
	with tokenize.open(arqname) as f:
		code = f.read()

	cfglist = fcfg.cfgs_by_qualified_function_name(code, arqname, True)
	for name,cfg in cfglist[0].items():
		with open(f'{name}.dot', 'w') as f:
			f.write(str(cfg)+'\n')
		s = f'dot -Tpng -o {name}.png {name}.dot'
		print(s)
		print(os.system(s))
	

