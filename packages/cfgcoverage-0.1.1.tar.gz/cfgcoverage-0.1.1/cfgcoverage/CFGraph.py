import ast, math
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Any

# -----------------------------
# Estruturas do grafo
# -----------------------------
	
@dataclass
class Edge:
	src: int
	dst: int
	label: str = ""   
	covered: bool = False

	def __str__(self):
		if self.label == 'FAKE':
			return f'{self.src} -> {self.dst} [style=dotted]'
		color = 'green' if self.covered else 'red'
		return f'{self.src} -> {self.dst} [label="{self.label}",color={color}]'

	def __eq__(self, other):
		return self.src == other.src and self.dst == other.dst

	def __hash__(self):
		return hash((self.src, self.dst))

@dataclass
class Block:
	id: int 
	kind: str = ''
	stmts: List[ast.stmt] = field(default_factory=list)
	cond: ast.Expr = None
	exitnode: bool = False
	covered: bool = False
	tooltip: str = ''

	def __str__(self) -> str:
		stilo = ''
		if self.exitnode:
			stilo = 'style=filled, fillcolor="#E0E0E0", '		
		color = 'green' if self.covered else 'red'
		formato = f'color={color},'+ stilo 
		if self.kind == 'EXIT':
			return f'{self.id}  [shape=triangle,style=filled, fillcolor=yellow,label="{self.kind}"]'
		if self.kind == 'COND'  :
			return f'{self.id}  [tooltip="{self.get_stmt_txt()}",{formato}label="{self.id} {self.kind}\n{ast.unparse(self.cond)}"]'
		if self.kind ==  'CASE' :
			pat = self.cond.pattern
			guard = self.cond.guard
			s = ''
			if pat:
				s += ast.unparse(pat) + ' '
			if guard:
				s += ast.unparse(guard)
			return f'{self.id}  [tooltip="{self.get_stmt_txt()}",{formato}label="{self.id} {self.kind}\n{s}"]'		
		if not self.stmts:
			return f'{self.id}  [{formato}label="{self.id}\n<{self.kind}>"]'
		first = self.stmts[0]
		return f'{self.id} [tooltip="{self.get_stmt_txt()}",{formato}label="{self.id} {self.kind}\n{type(first).__name__} (+{len(self.stmts)-1})"]'

	def get_stmt_txt(self):
		if self.kind == 'COND' :
			return ast.unparse(self.cond)
		return self.tooltip.replace('"', '\\"').replace("'","\\'")



@dataclass
class CFG:
	ordinal: int
	blocks: Dict[int, Block] = field(default_factory=dict)
	edges: List[Edge] = field(default_factory=list)
	entry: int = 0
	exits: List[int] = field(default_factory=list)
	map_out: Dict[int, int] = field(default_factory=dict)
	map_in: Dict[int, int] = field(default_factory=dict)

	def add_block(self, kind='') -> int:
		bid = len(self.blocks)
		self.blocks[bid] = Block(bid,kind)
		return bid

	def remove_block(self, block):
		for edgout in self.out_edge(block):
			self.remove_edge(edgout)
		for edgin in self.in_edge(block):
			self.remove_edge(edgin)		
		self.blocks.pop(block.id, None)

	def add_edge(self, src: int, dst: int, label: str = "") -> None:
		edg = Edge(src, dst, label=label)
		if self.find_edge(edg.src, edg.dst) < 0:
			self.edges.append(edg)

	def remove_edge(self,  edge):
		ret = False
		for i,edg in enumerate(self.edges):
			if edg.src == edge.src and edg.dst == edge.dst:
				del self.edges[i]
				ret = True
		return ret

	def remove_edge_by_number(self, tupla):
		src, dst = tupla
		ret = False
		for i,edg in enumerate(self.edges):
			if edg.src == src and edg.dst == dst:
				del self.edges[i]
				ret = True
		return ret

	def find_edge(self, src, dst,inicio=0):
		for i,edg in enumerate(self.edges):
			if i < inicio:
				continue
			if edg.src == src and edg.dst == dst:
				return i

		return -1	

	def zero_coverage(self):
		for edg in self.edges:
			edg.covered = False
		for _,blk in self.blocks.items():
			blk.covered = False
	
	def __str__(self):
		# print(self.blocks)
		# print(self.edges)
		s = 'digraph { \n'
		for bid in self.blocks.values():
			s += str(bid) + '\n'
		for eid in self.edges:
			s += str(eid) + '\n'
		s += '}\n'
		return s

	def in_edge(self, block):
		res = []
		for edg in self.edges:
			if edg.dst == block.id:
				res.append(edg)
		return res
	
	def out_edge(self, block):
		res = []
		for edg in self.edges:
			if edg.src == block.id:
				res.append(edg)
		return res

	def remove_else(self, kind):
		for bid,block in self.blocks.items():

			if block.kind in kind and not block.stmts:
				in_edges = self.in_edge(block)
				out_edges =  self.out_edge(block)
				if in_edges and not out_edges:
					# Aqui ele remove o nó e marca o pai como final
					# for edgin in in_edges:
					# 	origem = edgin.src
					# 	if origem not in self.exits:
					# 		self.exits.append(origem)
					# 		self.blocks[origem].exitnode = True
					#
					# Aqui ele mantém o nó e marca como nó de saída
					# print(block)
					# print(*in_edges)
					#print('Virou exit:', block)
					block.kind = 'EXIT'
					if block.id not in self.exits:
						self.exits.append(block.id)
						self.blocks[block.id].exitnode = True
					for edgin in in_edges:
						orig = edgin.src
						dst = edgin.dst
						# print(self.blocks[orig])
						# print(self.blocks[dst])
						edgin.label = 'FAKE'
					return True
				else:
					for edgin in in_edges:
						for edgout in out_edges:
							self.add_edge(edgin.src, edgout.dst,edgout.label)
				self.remove_block(block)
				return True
		return False

	def remove_BB_orfao(self, kind):
		for bid,block in self.blocks.items():
			edgin = self.in_edge(block)
			if self.entry != bid and block.kind in kind and not edgin:
				self.remove_block(block)
				return True
		return False

	def remove_kind(self, kind):
		for bid,block in self.blocks.items():
			if block.kind in kind:
				self.remove_block(block)
				return True
		return False

	def atualiza_nodes_exec(self, one_exec):
		for _,node in one_exec:
			self.blocks[node].covered = True

	def atualiza_edges_cover(self, one_exec, inicio=0):
		if one_exec:
			_,node1 = one_exec[0]
			for _,node2 in one_exec[1:]:
				idx = self.find_edge(node1, node2, inicio)
				if idx < 0:
					print(f"Ghost edge {self.ordinal} edge: {node1}-{node2}")
				else:
					self.edges[idx].covered = True
				node1 = node2

	def mapeia_exec(self, traces):
		if traces == []:
			return []
		new_traces = []
		numero = self.ordinal
		for one_trace in traces:
			new_one_trace = []
			for i, (_, no1) in enumerate(one_trace):
				new_one_trace.append((numero,no1))
				try: 
					_,inser = new_one_trace[-2]
				except:
					inser = -1
				idx_insert = -1
				bo = no1
				while no1 in self.map_in and self.map_in[no1] != inser:
					inser = self.map_in[no1]
					if inser == -318:
						del new_one_trace[idx_insert-1]
					else:
						new_one_trace.insert(idx_insert, (numero,inser))
						idx_insert -= 1
					no1 = inser
				inser = -1
				no1 = bo
				while no1 in self.map_out:
					inser = self.map_out[no1]
					new_one_trace.append((numero,inser))
					no1 = inser

			new_traces.append(new_one_trace)
		# print(traces)
		# print()
		# print(new_traces)
		return new_traces


	def computa_traces(self, numero, exec_nodes):
		alltraces = [ (x,_) for (x,_) in exec_nodes if x == numero]
		if alltraces == []:
			return []
		traces = []
		while True:	
			try: 
				if len(self.blocks) == 1:
					idx = 1
					if alltraces == []:
						break
				else:
					idx = alltraces.index((numero,0),2)
				traces.append(alltraces[:idx])
				alltraces = alltraces[idx:]
			except:
				traces.append(alltraces)
				break
		return traces

@staticmethod
def simplify(cfg):
	while cfg.remove_kind(['TERMINATE']):
		pass	
	while cfg.remove_else(kind=[ 'ELSE', 'JOIN', 'FOR_AFTER', 'FINALLY_HUB', 'BB', 'DEAD', 'WHILE_AFTER', 'WITH_AFTER', 'WHILE_COND_FALSE']) :
		pass
	while cfg.remove_BB_orfao(['BB','DEAD', 'WHILE_AFTER', 'EXIT']):
		pass

	return cfg

