import ast, tokenize, sys
from typing import Dict, List, Optional, Tuple, Sequence
from cfgcoverage.func_cfg import FunctionCFGCollector


class InstrumenterVisitor(ast.NodeTransformer):

	def __init__(self, comandos, condicoes, for_iter):
		self.comandos: Dict[int,Tuple(int, int)] = comandos
		self.condicoes: Dict[int,Tuple(int, int)] = condicoes
		self.for_iter: Dict[int,Tuple(int, int)] = for_iter


	def visit(self, node: ast.AST) -> any:
		return super().visit(node)

	def visit_ExceptHandler(self, node) :
		super().generic_visit(node)
		return node

	def visit_match_case(self, node):
		super().generic_visit(node)
		return node

	def visit_Match(self, node):
		node = super().generic_visit(node)
		new_cases = []
		for idx,case in enumerate(node.cases):
			node_id = id(case)
			cfg_id, cfg_node_id = self.condicoes[node_id]

			probe_guard = make_cov_cond(cfg_id, cfg_node_id, ast.Constant(False))
			probe_case = ast.match_case(
				pattern=ast.MatchAs(pattern=None, name="x"),  # case x
				guard=probe_guard,
				body=[ast.Pass()],
			)
			ast.copy_location(probe_case, case)
			ast.copy_location(probe_guard, case)
			new_cases.append(probe_case)
			assert isinstance(probe_case.pattern, ast.pattern) and probe_case.pattern is not None			
			new_cases.append(case)
			assert isinstance(case.pattern, ast.pattern) and case.pattern is not None
		node.cases = new_cases
		node_id = id(node)
		cfg_id, cfg_node_id = self.comandos[node_id]		
		new_node = make_if_true(make_cov_stmt(cfg_id, cfg_node_id), node)
		new_node = ast.copy_location(new_node, node)
		return new_node



	def generic_visit(self, node: ast.AST) -> ast.AST:
		node_id = id(node)   # <-- pega antes (casa com seu mapa)
		node = super().generic_visit(node)

		if node_id in self.comandos:
			if node_id in self.for_iter:
				cfg_id, cfg_node_id = self.for_iter[node_id]
				cond_node = make_cov_cond(cfg_id, cfg_node_id, ast.Constant(value=True))
				new_node = insert_if_before_for_body(node, cond_node)
				node =  new_node
			cfg_id, cfg_node_id = self.comandos[node_id]
			new_node = make_if_true(make_cov_stmt(cfg_id, cfg_node_id), node)
			new_node = ast.copy_location(new_node, node)

			return new_node
		if node_id in self.condicoes:
			cfg_id, cfg_node_id = self.condicoes[node_id]
			new_node = make_cov_cond(cfg_id, cfg_node_id, node)
			return ast.copy_location(new_node, node)
		if node_id in self.for_iter:
			cfg_id, cfg_node_id = self.for_iter[node_id]
			new_node = make_cov_cond(cfg_id, cfg_node_id, node)
			return ast.copy_location(new_node, node)
		return node


def make_cov_stmt(cfg_id:int, block_id: int) -> ast.stmt:
	return ast.Expr(
		value=ast.Call(
			func=ast.Name(id="__cov_node__", ctx=ast.Load()),
			args=[ast.Constant(cfg_id), ast.Constant(block_id)],
			keywords=[],
		)
	)

def make_cov_cond(cfg_id:int, block_id: int, expr: ast.expr) -> ast.expr:
	# avalia expr uma vez e devolve o mesmo valor, registrando o node_id
	return ast.Call(
		func=ast.Name(id="__cov_cond__", ctx=ast.Load()),
		args=[ast.Constant(cfg_id), ast.Constant(block_id), expr],
		keywords=[],
	)



def make_if_true(cmd1: ast.stmt, cmd2: ast.stmt, *, orelse: Optional[Sequence[ast.stmt]] = None) -> ast.If:
	"""
	Cria: if True: <cmd1>; <cmd2>
	- cmd1 e cmd2 devem ser nós do tipo ast.stmt (por exemplo ast.Expr, ast.Assign, ast.Return, ast.Pass, etc.)
	- orelse é opcional (lista de ast.stmt)
	"""

	node = ast.If(
		test=ast.Constant(value=True),
		body=[cmd1, cmd2],
		orelse=list(orelse) if orelse else []
	)
	return node


def insert_if_before_for_body(for_node, cond: ast.expr) :
	"""
	Modifica o nó 'for' inserindo um 'if cond:' dentro do for, envolvendo o corpo original.
	Mantém o 'else' do for intacto.

	for ...:
		BODY
	else:
		ELSE

	vira:

	for ...:
		if cond:
			BODY
	else:
		ELSE
	"""
	if not isinstance(for_node, (ast.For, ast.AsyncFor)):
		raise TypeError(f"for_node precisa ser ast.For ou ast.AsyncFor, veio {type(for_node).__name__}")
	if not isinstance(cond, ast.expr):
		raise TypeError(f"cond precisa ser ast.expr, veio {type(cond).__name__}")

	original_body = list(for_node.body)  # copia

	new_if = ast.If(
		test=cond,
		body=original_body,
		orelse=[]
	)

	# Coloca locations para o unparse/lineno ficar bom
	ast.copy_location(new_if, for_node)
	for_node.body = [new_if]
	return for_node

def pre_instrument(cfgs) :
	condicoes = {}
	comandos = {}
	for_iter = {}
	for _, cfg in cfgs.items():
		cfg_number = cfg.ordinal
		for _,bloco in cfg.blocks.items():
			if bloco.cond is not None:
				condicoes[id(bloco.cond)] = (cfg_number, bloco.id)
			elif bloco.kind == 'FOR_ITER':
				for_iter[id(bloco.stmts[0])] = (cfg_number, bloco.id)
			elif bloco.stmts:
				sttm = bloco.stmts[0]
				if not isinstance(sttm, ast.ExceptHandler):
					comandos[id(sttm)] = (cfg_number, bloco.id)

	return comandos,condicoes,{}


def instr():
	arqname = sys.argv[1]
	with tokenize.open(arqname) as f:
		source = f.read()
		tree = ast.parse(source)
	com,cond = pre_instrument(tree, arqname)
	v_instr = InstrumenterVisitor(com, cond)
	print(ast.dump(tree))
	v_instr.visit(tree)
	ast.fix_missing_locations(tree)
	print(ast.dump(tree))
	print(ast.unparse(tree))


if __name__ == "__main__":
	instr()