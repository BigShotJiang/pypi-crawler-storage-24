
from abc import ABC, abstractmethod
from cfgcoverage.CFGraph import CFG, Edge
from dataclasses import dataclass
from typing import Set, Iterable, List, Dict
from collections import defaultdict, deque
@dataclass(frozen=True)
class Requirement:

	def __init__(self, req):
		self.req = req
		self.covered = False

	def __eq__(self, other):
		self.req = other.req

	@abstractmethod
	def __hash__(self):
		return hash(self.req)

	def __str__(self):
		return str(self.req)  #+ '::' + str(self.covered)
	
class Criterion(ABC):

	def __init__(self, name):
		self.name = name
		self.requirements = {}

	def add(self, req: Requirement):
		self.requirements[req] = req.covered

	def cover(self, req: Requirement):
		self.requirements[req] = True
		req.covered = True

	
	def uncover(self, req: Requirement):
		self.requirements[req.req] = False
		req.covered = False

	@abstractmethod
	def check_trace(self, trace):
		pass

	@abstractmethod
	def compute(self, cfg):
		pass

	def get_coverage(self):
		cv = []
		nv = []
		for k,covered in self.requirements.items():
			#print(k, covered)
			if covered :
				cv.append(str(k))
			else:
				nv.append(str(k)) 
		return sorted(cv), sorted(nv)


	def __str__(self):
		s = ''
		for req, t in self.requirements.items():
			s += str(req) #S+ '::' + str(t )+ ' '
		return s

	def remove(self, to_remove):
		ret = False
		os_requisitos = dict(self.requirements)
		for req in os_requisitos:
			if _check_sublist(to_remove, req.req):
				del self.requirements[req]
				ret = True
		return ret


class EdgePair(Criterion):


	def compute(self, cfg: CFG):
		for _bid, src in cfg.blocks.items():
			for out0 in cfg.out_edge(src):
				if out0.label == 'FAKE':
					continue
				midle = out0.dst
				block_midle = cfg.blocks[midle]
				for final in cfg.out_edge(block_midle):
					if final.label == 'FAKE':
						continue
					requirement = EPrequirement(src.id, midle, final.dst)
					self.add(requirement)

	def check_trace(self, trace):
		if len(trace) < 3:
			return
		blocos = [n for _, n in trace]
		trios = {
			(blocos[i], blocos[i+1], blocos[i+2])
			for i in range(len(blocos) - 2)
		}
		for req in self.requirements:
			if req.req in trios:
				self.cover(req)
		return


class EPrequirement(Requirement):

	def __init__(self, src, midle, final):
		super().__init__((src, midle, final))

	def __str__(self):
		return str(self.req)


class EssentBranchReq(Requirement):
	def __init__(self, edge):
		super().__init__(edge)

	def __str__(self):
		return str((self.req.src, self.req.dst))

class EssentialBranch(Criterion):

	def compute(self, cfg: CFG):
		ess_edges =  essential_edges(cfg.edges)
		for edg in ess_edges:
			requirement = EssentBranchReq(edg)
			requirement.covered = edg.covered
			self.add(requirement)

	def check_trace(self, trace=None):
		for req in self.requirements:
			edg = req.req
			req.covered = edg.covered
			self.requirements[req] = req.covered

	def remove(self, to_remove):
		ret = False
		os_requisitos = dict(self.requirements)
		for req in os_requisitos:
			if _check_sublist(to_remove, (req.req.src, req.req.dst)):
				del self.requirements[req]
				ret = True

def essential_edges(edges: Iterable[Edge]) -> List[Edge]:
    """
    Devolve o subconjunto de arestas essenciais de um CFG, adaptado para:
    - múltiplas entradas
    - múltiplas saídas
    - sem multiarestas repetidas
    - ignorando arestas FAKE

    Critério:
    Uma aresta b herda uma aresta a se não existe caminho entrada-saída
    que contenha a e evite b.
    Uma aresta é essencial se não herda nenhuma outra.

    Consideramos como candidatos apenas arestas que saem de nós com
    out-degree >= 2 no CFG original.
    """

    edges = [e for e in edges if e.label != "FAKE"]
    if not edges:
        return []

    nodes: Set[int] = set()
    indeg: Dict[int, int] = defaultdict(int)
    outdeg: Dict[int, int] = defaultdict(int)

    for e in edges:
        nodes.add(e.src)
        nodes.add(e.dst)
        outdeg[e.src] += 1
        indeg[e.dst] += 1

    entries = [n for n in nodes if indeg[n] == 0]
    exits = [n for n in nodes if outdeg[n] == 0]

    SUPER_ENTRY = -10**15 - 1
    SUPER_EXIT = -10**15 - 2

    all_edges = list(edges)
    for n in entries:
        all_edges.append(Edge(SUPER_ENTRY, n, label="__SUPER__"))
    for n in exits:
        all_edges.append(Edge(n, SUPER_EXIT, label="__SUPER__"))

    candidates = [e for e in edges if outdeg[e.src] >= 2]
    if not candidates:
        return []

    def build_adj(excluded: Edge | None):
        adj = defaultdict(list)
        radj = defaultdict(list)

        for e in all_edges:
            if excluded is not None and e.src == excluded.src and e.dst == excluded.dst:
                continue
            adj[e.src].append(e.dst)
            radj[e.dst].append(e.src)

        return adj, radj

    def reachable_from(start: int, adj) -> Set[int]:
        seen = {start}
        q = deque([start])

        while q:
            u = q.popleft()
            for v in adj[u]:
                if v not in seen:
                    seen.add(v)
                    q.append(v)

        return seen

    def can_build_path_containing_a_avoiding_b(a: Edge, b: Edge) -> bool:
        """
        Testa se existe caminho super_entry -> super_exit
        que contenha a aresta a e evite a aresta b.
        """
        adj, radj = build_adj(excluded=b)

        # Se a própria a foi removida, impossível conter a
        if a.src == b.src and a.dst == b.dst:
            return False

        # Precisamos de:
        # SUPER_ENTRY  -> a.src
        # a.src --a--> a.dst
        # a.dst        -> SUPER_EXIT
        #
        # Tudo no mesmo grafo sem b.
        reach_from_entry = reachable_from(SUPER_ENTRY, adj)
        reach_to_exit = reachable_from(SUPER_EXIT, radj)  # reverso

        return (a.src in reach_from_entry) and (a.dst in reach_to_exit)

    def inherits(b: Edge, a: Edge) -> bool:
        """
        b herda a sse NÃO existe caminho entrada-saída contendo a e evitando b.
        """
        if a.src == b.src and a.dst == b.dst:
            return False
        return not can_build_path_containing_a_avoiding_b(a, b)

    essentials: List[Edge] = []

    for b in candidates:
        inherited_someone = False
        for a in candidates:
            if inherits(b, a):
                inherited_someone = True
                break
        if not inherited_someone:
            essentials.append(b)

    return essentials

	
class PrimePath(Criterion):

	def check_trace(self, trace):
		pass

	def compute(self, cfg:CFG):

		primepaths = set()

		def aux_compute(node, curpath):
			outedg = cfg.out_edge(cfg.blocks[node])
			outedg = [x for x in outedg if x.label != 'FAKE']
			if len(outedg) == 0:
				primepaths.add(tuple(curpath))
				return

			for next in outedg:
				r = next.dst
				if r in curpath:
					if r == curpath[0]:
						curpath.append(r)
					primepaths.add(tuple(curpath))
					return				
				next_path = curpath[:]
				next_path.append(r)
				aux_compute(r, next_path)

		for bid,block in cfg.blocks.items():
			aux_compute(bid, [bid])

		# print('\n\n\n\n')
		# print(primepaths)
		for p in list(primepaths):
			#print(primepaths)
			for k in range(1,len(p)):
				# print('Original:', p)
				# print('Procurando subpath: ', -k, p[-k:])
				if p[-k:] in primepaths:
					primepaths.remove(p[-k:])
		# print(primepaths)

		for p in primepaths:
			req = PPRequirement(p)
			#print('Inserindo:' , p)
			#print('Requisito: ', req)
			self.add(req) 
		#print(*self.requirements)

	def check_trace(self, trace):
		#pega a lista apenas dos requisitos não cobertos
		#print('Requisitos completos:', self.requirements.items())
		list_check = [ (req,covered) for (req ,covered) in self.requirements.items() if covered == False]
		#print('Requisitos: ', list_check)
		trace_node = [x for (_,x) in trace ]
		#print('Rastro:' , trace_node)
		for req,_ in list_check:
			if self._check_sublist(req.req, trace_node):
				self.cover(req)
		
	def _check_sublist(self, req, trace):
		req = list(req)
		# print(f'Check| sublist:\n\t{req}\n\t{trace}')
		for i in range(len(trace) -  len(req) + 1):
			sublista = trace[i: i + len(req)]
			if sublista == req:
				return True
		return False
			

class PPRequirement(Requirement):

	def __init__(self, lista):
		super().__init__(tuple(lista))


def _check_sublist(req, trace):
	#print('check sublist', req, trace)
	req = list(req)
	trace = list(trace)
	# print(f'Check| sublist:\n\t{req}\n\t{trace}')
	for i in range(len(trace) -  len(req) + 1):
		sublista = trace[i: i + len(req)]
		#print('comparando: ', sublista, req,  sublista == req)
		if sublista == req:
		#	print('retornando true')
			return True
	return False