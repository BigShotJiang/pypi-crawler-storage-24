# Copyright (c) 2026 Nate Tritle. Licensed under the MIT License.
"""Main application window with splitters, menus, and status bar."""

from __future__ import annotations

import logging
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

from PyQt6.QtCore import QProcess, Qt, QThread, QTimer, pyqtSignal
from PyQt6.QtGui import QAction, QCloseEvent, QKeySequence
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QLabel,
    QMainWindow,
    QMenu,
    QMessageBox,
    QSplitter,
    QStatusBar,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from pylearn.core.config import AppConfig, BooksConfig, EditorConfig
from pylearn.core.constants import APP_NAME, APP_VERSION, IS_FROZEN, TOC_WIDTH
from pylearn.core.content_loader import ContentLoader
from pylearn.core.database import Database
from pylearn.core.models import Book
from pylearn.executor.output_handler import OutputHandler
from pylearn.executor.sandbox import check_dangerous_code
from pylearn.executor.session import Session
from pylearn.parser.cache_manager import CacheManager
from pylearn.ui.book_controller import BookController
from pylearn.ui.bookmark_dialog import BookmarkDialog, add_bookmark_dialog
from pylearn.ui.challenge_panel import ChallengePanel
from pylearn.ui.console_panel import ConsolePanel
from pylearn.ui.editor_panel import EditorPanel
from pylearn.ui.exercise_panel import ExercisePanel
from pylearn.ui.external_editor import ExternalEditorManager
from pylearn.ui.library_panel import LibraryPanel
from pylearn.ui.notes_dialog import NotesDialog
from pylearn.ui.progress_dialog import ProgressDialog
from pylearn.ui.project_panel import ProjectPanel
from pylearn.ui.quiz_panel import QuizPanel
from pylearn.ui.reader_panel import ReaderPanel
from pylearn.ui.search_dialog import SearchDialog
from pylearn.ui.styles import get_stylesheet
from pylearn.ui.toc_panel import TOCPanel
from pylearn.ui.toolbar import MainToolBar
from pylearn.utils.error_handler import safe_slot
from pylearn.utils.export import export_progress_to_markdown, export_to_markdown
from pylearn.utils.text_utils import detect_repl_code, strip_repl_prompts

logger = logging.getLogger("pylearn.ui")


class ParseProcess:
    """Run book parsing in a separate process via QProcess.

    QProcess integrates with the Qt event loop natively — no threads needed.
    The UI stays fully responsive while PyMuPDF does heavy work in the child process.
    """

    def __init__(self, parent: QWidget) -> None:
        self._process = QProcess(parent)
        self._process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self._book_id: str = ""
        self._parent = parent
        self._output_buffer: list[str] = []

        # Wire QProcess signals
        self._process.readyReadStandardOutput.connect(self._on_output)
        self._process.finished.connect(self._on_finished)
        self._process.errorOccurred.connect(self._on_error)

        # Callbacks (set by MainWindow)
        self.on_progress: Callable[[str], None] = lambda msg: None
        self.on_finished: Callable[[Book], None] = lambda book: None
        self.on_error: Callable[[str], None] = lambda msg: None

    def start(self, book_id: str) -> None:
        if self._process.state() != QProcess.ProcessState.NotRunning:
            return
        self._book_id = book_id
        self._output_buffer.clear()
        if IS_FROZEN:
            # Frozen mode: re-invoke the exe itself with --parse flag
            self._process.start(sys.executable, ["--parse", "--book", book_id, "--force"])
        else:
            # Dev + pip-installed: use -m pylearn which works from any install mode
            self._process.start(sys.executable, ["-m", "pylearn", "--parse", "--book", book_id, "--force"])

    def stop(self) -> None:
        if self._process.state() != QProcess.ProcessState.NotRunning:
            self._process.kill()

    def is_running(self) -> bool:
        return self._process.state() != QProcess.ProcessState.NotRunning

    def _on_output(self) -> None:
        try:
            data = self._process.readAllStandardOutput().data().decode("utf-8", errors="replace")
            for line in data.splitlines():
                line = line.strip()
                if line:
                    self._output_buffer.append(line)
                    self.on_progress(line)
        except Exception as e:
            logging.getLogger("pylearn.ui").exception("Error in _on_output")
            self.on_error(f"Parse output error: {e}")

    def _on_finished(self, exit_code: int, exit_status: QProcess.ExitStatus) -> None:
        try:
            if exit_code != 0:
                # Extract ERROR lines from output for a useful message
                error_lines = [ln for ln in self._output_buffer if "ERROR" in ln]
                if error_lines:
                    detail = "\n".join(error_lines)
                    self.on_error(f"Parsing failed:\n{detail}")
                else:
                    self.on_error(f"Parsing process exited with code {exit_code}")
                return

            self.on_progress("Loading parsed content...")
            cache = CacheManager()
            book = cache.load(self._book_id)
            if book:
                self.on_finished(book)
            else:
                self.on_error("Parsing completed but cache file not found.")
        except Exception as e:
            logging.getLogger("pylearn.ui").exception("Error in _on_finished")
            self.on_error(f"Parse finish error: {e}")

    def _on_error(self, error: QProcess.ProcessError) -> None:
        try:
            self.on_error(f"Process error: {error}")
        except Exception:
            logging.getLogger("pylearn.ui").exception("Error in _on_error")


class ExecuteWorker(QThread):
    """Background thread for code execution."""

    finished = pyqtSignal(object)  # ExecutionResult

    def __init__(self, code: str, session: Session) -> None:
        super().__init__()
        self.code = code
        self.session = session

    def run(self) -> None:
        result = self.session.run(self.code)
        self.finished.emit(result)


class MainWindow(QMainWindow):
    """Main application window."""

    def __init__(self) -> None:
        super().__init__()

        # Config
        self._app_config = AppConfig()
        self._books_config = BooksConfig()
        self._editor_config = EditorConfig()

        # Core services
        self._db = Database()
        self._cache = CacheManager()
        self._content = ContentLoader()
        self._session = Session(timeout=self._editor_config.execution_timeout)
        self._output = OutputHandler()

        # Book controller (owns book state, navigation, progress)
        self._book = BookController(
            self._db,
            self._cache,
            self._books_config,
            parent=self,
        )

        # External editor
        self._external_editor = ExternalEditorManager(self)

        # State (non-book)
        self._parse_process: ParseProcess | None = None
        self._exec_worker: ExecuteWorker | None = None

        self._setup_ui()
        self._setup_menus()
        self._connect_signals()
        self._restore_state()

    def _setup_ui(self) -> None:
        """Build the main UI layout."""
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Library panel (book selector)
        self._library = LibraryPanel(self._books_config)
        main_layout.addWidget(self._library)

        # Toolbar
        self._toolbar = MainToolBar()
        self.addToolBar(self._toolbar)

        # Main content area
        content_splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left side: TOC + Reader
        left_splitter = QSplitter(Qt.Orientation.Horizontal)

        self._toc = TOCPanel()
        self._toc.setMaximumWidth(350)
        left_splitter.addWidget(self._toc)

        self._reader = ReaderPanel()
        left_splitter.addWidget(self._reader)

        left_splitter.setSizes([TOC_WIDTH, 600])
        content_splitter.addWidget(left_splitter)

        # Right side: Tabs (Editor+Console, Quiz) stacked vertically
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        # Tab widget for switching between Editor and Quiz
        self._right_tabs = QTabWidget()
        self._right_tabs.setTabPosition(QTabWidget.TabPosition.North)

        # Tab 0: Editor + Console (vertical splitter)
        editor_tab = QWidget()
        editor_tab_layout = QVBoxLayout(editor_tab)
        editor_tab_layout.setContentsMargins(0, 0, 0, 0)
        editor_tab_layout.setSpacing(0)

        right_splitter = QSplitter(Qt.Orientation.Vertical)

        self._editor = EditorPanel()
        right_splitter.addWidget(self._editor)

        self._console = ConsolePanel()
        right_splitter.addWidget(self._console)

        right_splitter.setSizes(self._app_config.editor_console_sizes)
        self._right_splitter = right_splitter

        editor_tab_layout.addWidget(right_splitter)
        self._right_tabs.addTab(editor_tab, "Editor")

        # Tab 1: Quiz
        self._quiz_panel = QuizPanel(self._db, self._content)
        self._right_tabs.addTab(self._quiz_panel, "Quiz")

        # Tab 2: Challenges
        self._challenge_panel = ChallengePanel(self._db, self._content, self._session)
        self._right_tabs.addTab(self._challenge_panel, "Challenge")

        # Tab 3: Project
        self._project_panel = ProjectPanel(self._db, self._content, self._session)
        self._right_tabs.addTab(self._project_panel, "Project")

        right_layout.addWidget(self._right_tabs)
        content_splitter.addWidget(right_widget)

        content_splitter.setSizes(self._app_config.splitter_sizes)
        self._content_splitter = content_splitter
        self._left_splitter = left_splitter

        main_layout.addWidget(content_splitter)

        # Status bar
        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)

        self._status_book = QLabel("")
        self._status_chapter = QLabel("")
        self._status_progress = QLabel("")
        self._status_state = QLabel("Ready")

        self._status_bar.addWidget(self._status_book, 1)
        self._status_bar.addWidget(self._status_chapter, 1)
        self._status_bar.addWidget(self._status_progress, 1)
        self._status_bar.addPermanentWidget(self._status_state)

        # Show welcome
        self._reader.display_welcome()

    def _add_menu_action(
        self, menu: QMenu, text: str, slot: Callable[..., Any], shortcut: str | None = None
    ) -> QAction:
        """Helper to add a menu action with optional shortcut (PyQt6-compatible)."""
        action = QAction(text, self)
        # Lambda discards the 'checked' bool that triggered(bool) emits,
        # so zero-arg slots don't get an unexpected argument.
        action.triggered.connect(lambda checked=False, fn=slot: fn())
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
            # Window context ensures shortcuts work even when QScintilla has focus
            action.setShortcutContext(Qt.ShortcutContext.WindowShortcut)
        menu.addAction(action)
        return action

    def _setup_menus(self) -> None:
        """Create the menu bar."""
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("&File")
        self._add_menu_action(file_menu, "Save Code...", self._save_code_to_file, "Ctrl+S")
        self._add_menu_action(file_menu, "Load Code...", self._load_code_from_file, "Ctrl+O")
        self._add_menu_action(file_menu, "Open in External Editor", self._open_external_editor, "Ctrl+E")
        self._add_menu_action(file_menu, "Export Notes && Bookmarks...", self._export_notes_bookmarks)
        self._add_menu_action(file_menu, "Export Progress...", self._export_progress)
        file_menu.addSeparator()
        self._add_menu_action(file_menu, "E&xit", self.close, "Alt+F4")

        # Edit menu
        edit_menu = menubar.addMenu("&Edit")
        self._add_menu_action(edit_menu, "Add Bookmark...", self._add_bookmark, "Ctrl+B")
        self._add_menu_action(edit_menu, "Add Note...", self._add_note, "Ctrl+N")
        edit_menu.addSeparator()
        self._add_menu_action(edit_menu, "Clear Editor", self._editor.clear)
        self._add_menu_action(edit_menu, "Reset Session", self._reset_session)

        # View menu
        view_menu = menubar.addMenu("&View")
        self._toc_action = self._add_menu_action(view_menu, "Toggle TOC", self._toggle_toc, "Ctrl+T")
        self._add_menu_action(view_menu, "Bookmarks...", self._show_bookmarks)
        self._add_menu_action(view_menu, "Notes...", self._show_notes)
        self._add_menu_action(view_menu, "Exercises...", self._show_exercises)
        self._add_menu_action(view_menu, "Take Quiz", self._show_quiz, "Ctrl+Q")
        self._add_menu_action(view_menu, "Review Missed Questions", self._show_quiz_review, "Ctrl+R")
        self._add_menu_action(view_menu, "Code Challenge", self._show_challenge, "Ctrl+Shift+Q")
        self._add_menu_action(view_menu, "Book Project", self._show_project, "Ctrl+P")
        view_menu.addSeparator()
        self._add_menu_action(view_menu, "Increase Font Size", self._increase_font, "Ctrl+=")
        self._add_menu_action(view_menu, "Decrease Font Size", self._decrease_font, "Ctrl+-")
        view_menu.addSeparator()
        self._add_menu_action(view_menu, "Focus TOC", self._focus_toc, "Ctrl+1")
        self._add_menu_action(view_menu, "Focus Reader", self._focus_reader, "Ctrl+2")
        self._add_menu_action(view_menu, "Focus Editor", self._focus_editor, "Ctrl+3")
        view_menu.addSeparator()
        self._add_menu_action(view_menu, "Progress...", self._show_progress)

        # Book menu
        book_menu = menubar.addMenu("&Book")
        self._add_menu_action(book_menu, "Parse Current Book", self._parse_current_book)
        self._add_menu_action(book_menu, "Re-parse (clear cache)", self._reparse_book)
        book_menu.addSeparator()
        self._add_menu_action(book_menu, "Previous Chapter", self._book.prev_chapter, "Alt+Left")
        self._add_menu_action(book_menu, "Next Chapter", self._book.next_chapter, "Alt+Right")
        book_menu.addSeparator()
        self._add_menu_action(book_menu, "Mark Chapter Complete", self._book.mark_chapter_complete, "Ctrl+M")

        # Run menu
        run_menu = menubar.addMenu("&Run")
        self._add_menu_action(run_menu, "Run Code", self._run_code, "F5")
        self._add_menu_action(run_menu, "Stop", self._stop_code, "Shift+F5")
        run_menu.addSeparator()
        self._add_menu_action(run_menu, "Clear Console", self._console.clear_console)

        # Search menu
        search_menu = menubar.addMenu("&Search")
        self._add_menu_action(search_menu, "Find in Chapter", self._find_in_chapter, "Ctrl+F")
        self._add_menu_action(search_menu, "Search All Books...", self._show_search, "Ctrl+Shift+F")

        # Help menu
        help_menu = menubar.addMenu("&Help")
        self._add_menu_action(help_menu, "Keyboard Shortcuts", self._show_shortcuts, "Ctrl+/")
        help_menu.addSeparator()
        self._add_menu_action(help_menu, "About", self._show_about)

    def _connect_signals(self) -> None:
        """Wire up all signals between components."""
        # Library → BookController
        self._library.book_selected.connect(self._book.on_book_selected)

        # TOC → BookController
        self._toc.chapter_selected.connect(self._book.navigate_to_chapter)
        self._toc.section_selected.connect(self._on_section_selected)

        # BookController → UI
        self._book.book_loaded.connect(self._on_book_loaded)
        self._book.chapter_changed.connect(self._on_chapter_changed)
        self._book.language_changed.connect(self._on_language_changed)
        self._book.status_message.connect(self._status_state.setText)
        self._book.error_message.connect(lambda title, msg: QMessageBox.warning(self, title, msg))
        self._book.progress_updated.connect(self._status_progress.setText)
        self._book.chapter_status_changed.connect(self._toc.update_chapter_status)
        self._book.parse_requested.connect(self._on_parse_requested)
        self._book.scroll_to_position.connect(
            lambda pos: QTimer.singleShot(0, lambda: self._reader.verticalScrollBar().setValue(pos))
        )

        # Reader
        self._reader.code_copy_requested.connect(self._copy_code_block)
        self._reader.code_tryit_requested.connect(self._try_code_block)
        self._reader.visible_heading_changed.connect(self._on_visible_heading_changed)

        # Toolbar
        self._toolbar.run_requested.connect(self._run_code)
        self._toolbar.stop_requested.connect(self._stop_code)
        self._toolbar.clear_console_requested.connect(self._console.clear_console)
        self._toolbar.font_size_changed.connect(self._on_font_size_changed)
        self._toolbar.theme_changed.connect(self._on_theme_changed)
        self._toolbar.external_editor_requested.connect(self._open_external_editor)

        # External editor
        self._external_editor.code_changed.connect(self._editor.set_code)

    def _restore_state(self) -> None:
        """Restore window geometry and last session."""
        cfg = self._app_config

        # Window geometry
        if cfg.window_x is not None and cfg.window_y is not None:
            self.move(cfg.window_x, cfg.window_y)
        self.resize(cfg.window_width, cfg.window_height)
        if cfg.window_maximized:
            self.showMaximized()

        # Theme
        self._on_theme_changed(cfg.theme)
        self._toolbar.set_theme(cfg.theme)

        # Editor font (reader font is applied via toolbar signal)
        self._toolbar.set_font_size(cfg.reader_font_size)
        self._editor.set_font_size(self._editor_config.font_size)

        # TOC visibility
        if not cfg.toc_visible:
            self._toc.hide()

        # Load last book (triggers library → BookController pipeline)
        if cfg.last_book_id:
            self._library.select_book(cfg.last_book_id)

    def _save_state(self) -> None:
        """Save window geometry and current session."""
        cfg = self._app_config

        if not self.isMaximized():
            geo = self.geometry()
            cfg.window_x = geo.x()
            cfg.window_y = geo.y()
            cfg.window_width = geo.width()
            cfg.window_height = geo.height()
        cfg.window_maximized = self.isMaximized()

        cfg.splitter_sizes = self._content_splitter.sizes()
        cfg.editor_console_sizes = self._right_splitter.sizes()
        cfg.toc_visible = self._toc.isVisible()

        if self._book.current_book:
            cfg.last_book_id = self._book.current_book.book_id
            scroll_pos = self._reader.verticalScrollBar().value()
            self._book.save_position(scroll_pos)

        cfg.save()
        self._editor_config.save()

    # --- BookController UI Handlers ---

    @safe_slot
    def _on_book_loaded(self, book: Book) -> None:
        """UI response to BookController.book_loaded signal."""
        self._status_book.setText(f"Book: {book.title}")
        self._reader.set_image_dir(self._book.image_dir)

        progress_data = self._book.get_progress_data()
        self._toc.load_chapters(book.chapters, progress_data)

    @safe_slot
    def _on_chapter_changed(self, chapter_num: int, content_blocks: list) -> None:
        """UI response to BookController.chapter_changed signal."""
        self._reader.display_blocks(content_blocks)
        self._toc.highlight_chapter(chapter_num)
        book = self._book.current_book
        total = len(book.chapters) if book else 0
        self._status_chapter.setText(f"Chapter {chapter_num} of {total}")

    @safe_slot
    def _on_language_changed(self, language: str) -> None:
        """UI response to BookController.language_changed signal."""
        self._editor.set_language(language)
        self._session.language = language
        self._reader.set_language(language)

    @safe_slot
    def _on_section_selected(self, chapter_num: int, block_index: int) -> None:
        """Handle TOC section click — delegate to controller, then scroll."""
        block_id = self._book.navigate_to_section(chapter_num, block_index)
        if block_id:
            self._reader.scroll_to_block(block_id)

    @safe_slot
    def _on_visible_heading_changed(self, block_index: int) -> None:
        """Sync TOC highlight as the user scrolls through the reader."""
        if self._book.current_chapter_num > 0:
            self._toc.highlight_section(self._book.current_chapter_num, block_index)

    def _on_parse_requested(self, book_info: dict) -> None:
        """BookController couldn't find cache — ask user to parse."""
        reply = QMessageBox.question(
            self,
            "Parse Book",
            f'"{book_info["title"]}" has not been parsed yet.\nParse it now? (This may take a few minutes)',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self._start_parse(book_info)

    # --- Parsing (UI-side, uses ParseProcess) ---

    @safe_slot
    def _parse_current_book(self) -> None:
        """Parse (or re-parse) the currently selected book."""
        book_id = self._library.current_book_id()
        if not book_id:
            QMessageBox.information(self, "No Book", "Please select a book first.")
            return
        book_info = self._books_config.get_book(book_id)
        if book_info:
            self._start_parse(book_info)

    @safe_slot
    def _reparse_book(self) -> None:
        """Clear cache and re-parse the current book."""
        book_id = self._library.current_book_id()
        if book_id:
            self._cache.invalidate(book_id)
            self._parse_current_book()

    def _start_parse(self, book_info: dict) -> None:
        """Start parsing a book in a separate process via QProcess."""
        if self._parse_process and self._parse_process.is_running():
            QMessageBox.warning(self, "Busy", "A book is already being parsed.")
            return

        self._status_state.setText("Parsing (background process)...")
        self._parse_process = ParseProcess(self)
        self._parse_process.on_progress = lambda msg: self._status_state.setText(msg)
        self._parse_process.on_finished = self._on_parse_finished
        self._parse_process.on_error = self._on_parse_error
        self._parse_process.start(book_info["book_id"])

    @safe_slot
    def _on_parse_finished(self, book: Book) -> None:
        self._status_state.setText("Ready")
        if book:
            self._book.load_book(book)
            QMessageBox.information(
                self,
                "Parse Complete",
                f'"{book.title}" parsed successfully.\n{len(book.chapters)} chapters found.',
            )

    @safe_slot
    def _on_parse_error(self, error_msg: str) -> None:
        self._status_state.setText("Ready")
        QMessageBox.critical(self, "Parse Error", f"Error parsing book:\n{error_msg}")

    # --- External Editor ---

    @safe_slot
    def _open_external_editor(self) -> None:
        """Open current editor code in the external editor (Notepad++)."""
        if not self._editor_config.external_editor_enabled:
            QMessageBox.information(self, "Disabled", "External editor is disabled in editor_config.json.")
            return

        code = self._editor.get_code()
        language = self._book.current_language
        error = self._external_editor.open(code, language, self._editor_config.external_editor_path)
        if error:
            QMessageBox.warning(self, "External Editor", error)
        else:
            self._status_state.setText("Opened in external editor")

    # --- Code Operations ---

    @safe_slot
    def _copy_code_block(self, block_id: str) -> None:
        """Copy a code block to clipboard."""
        block = self._reader.get_block(block_id)
        if block:
            clipboard = QApplication.clipboard()
            clipboard.setText(block.text)
            self._status_state.setText("Code copied to clipboard")

    @safe_slot
    def _try_code_block(self, block_id: str) -> None:
        """Load a code block into the editor."""
        block = self._reader.get_block(block_id)
        if block:
            code = block.text
            # Strip REPL prompts if present
            if detect_repl_code(code):
                code = strip_repl_prompts(code)
            self._editor.append_code(code)
            self._status_state.setText("Code loaded into editor")

    @safe_slot
    def _run_code(self) -> None:
        """Execute the code in the editor."""
        if self._exec_worker and self._exec_worker.isRunning():
            return  # Already running — prevent overlapping workers

        code = self._editor.get_code().strip()
        if not code:
            return

        # Warn about potentially dangerous code
        warnings = check_dangerous_code(code)
        if warnings:
            detail = "\n".join(f"  - {w}" for w in warnings)
            reply = QMessageBox.warning(
                self,
                "Potentially Dangerous Code",
                f"This code contains operations that could modify your system:\n\n{detail}\n\nRun anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        self._toolbar.set_running(True)
        self._console.show_running()
        lang = self._book.current_language
        if lang == "html":
            self._status_state.setText("Opening in browser...")
        elif lang in ("cpp", "c"):
            self._status_state.setText("Compiling and running...")
        else:
            self._status_state.setText("Running...")

        # Clean up previous worker before creating a new one
        if self._exec_worker is not None:
            self._exec_worker.wait(1000)
            self._exec_worker.deleteLater()
        self._exec_worker = ExecuteWorker(code, self._session)
        self._exec_worker.finished.connect(self._on_execution_finished)
        self._exec_worker.start()

    @safe_slot
    def _on_execution_finished(self, result) -> None:
        self._toolbar.set_running(False)
        self._status_state.setText("Ready")
        output_html = self._output.format_result(result)
        self._console.append_html(self._output.format_separator())
        self._console.append_html(output_html)

    @safe_slot
    def _stop_code(self) -> None:
        """Stop the currently running code."""
        if self._session.stop():
            self._toolbar.set_running(False)
            self._status_state.setText("Stopped")
            self._console.append_html(self._output.format_status("Execution stopped by user.", "#ffa500"))

    @safe_slot
    def _reset_session(self) -> None:
        """Reset the execution session."""
        self._session.reset()
        self._console.clear_console()
        self._status_state.setText("Session reset")

    # --- File Operations ---

    def _file_filter_for_language(self) -> str:
        """Return a file-dialog filter string appropriate for the current language."""
        lang = self._book.current_language
        if lang == "html":
            return "HTML Files (*.html *.htm);;CSS Files (*.css);;All Files (*)"
        elif lang in ("cpp", "c"):
            return "C++ Files (*.cpp *.cc *.h);;All Files (*)"
        else:
            return "Python Files (*.py);;All Files (*)"

    @safe_slot
    def _save_code_to_file(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save Code", "", self._file_filter_for_language())
        if path:
            try:
                Path(path).write_text(self._editor.get_code(), encoding="utf-8")
                self._status_state.setText(f"Saved to {Path(path).name}")
            except OSError as e:
                QMessageBox.warning(self, "Save Failed", f"Could not save file:\n{e}")

    @safe_slot
    def _load_code_from_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load Code", "", self._file_filter_for_language())
        if path:
            try:
                file_size = Path(path).stat().st_size
                if file_size > 10 * 1024 * 1024:  # 10 MB
                    QMessageBox.warning(self, "File Too Large", "File exceeds the 10 MB limit.")
                    return
                code = Path(path).read_text(encoding="utf-8")
                self._editor.set_code(code)
                self._status_state.setText(f"Loaded {Path(path).name}")
            except OSError as e:
                QMessageBox.warning(self, "Load Failed", f"Could not read file:\n{e}")

    @safe_slot
    def _export_notes_bookmarks(self) -> None:
        """Export notes and bookmarks to a Markdown file."""
        book_id: str | None = None
        suggested_name = "pylearn_notes.md"

        if self._book.current_book:
            msg = QMessageBox(self)
            msg.setWindowTitle("Export Notes & Bookmarks")
            msg.setText("Export notes and bookmarks for which books?")
            current_btn = msg.addButton("Current Book", QMessageBox.ButtonRole.AcceptRole)
            all_btn = msg.addButton("All Books", QMessageBox.ButtonRole.AcceptRole)
            msg.addButton(QMessageBox.StandardButton.Cancel)
            msg.exec()

            clicked = msg.clickedButton()
            if clicked == current_btn:
                book_id = self._book.current_book.book_id
                safe_title = self._book.current_book.title.replace(" ", "_")
                suggested_name = f"{safe_title}_notes.md"
            elif clicked == all_btn:
                book_id = None
            else:
                return

        result = export_to_markdown(self._db, book_id)
        if result is None:
            QMessageBox.information(self, "Nothing to Export", "No notes or bookmarks found.")
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "Export Notes & Bookmarks", suggested_name, "Markdown Files (*.md);;All Files (*)"
        )
        if path:
            try:
                Path(path).write_text(result, encoding="utf-8")
                self._status_state.setText(f"Exported to {Path(path).name}")
            except OSError as e:
                QMessageBox.warning(self, "Export Failed", f"Could not save file:\n{e}")

    def _export_progress(self) -> None:
        """Export learning progress to a Markdown file."""
        book_id: str | None = None
        suggested_name = "pylearn_progress.md"

        if self._book.current_book:
            msg = QMessageBox(self)
            msg.setWindowTitle("Export Progress")
            msg.setText("Export progress for which books?")
            current_btn = msg.addButton("Current Book", QMessageBox.ButtonRole.AcceptRole)
            all_btn = msg.addButton("All Books", QMessageBox.ButtonRole.AcceptRole)
            msg.addButton(QMessageBox.StandardButton.Cancel)
            msg.exec()

            clicked = msg.clickedButton()
            if clicked == current_btn:
                book_id = self._book.current_book.book_id
                safe_title = self._book.current_book.title.replace(" ", "_")
                suggested_name = f"{safe_title}_progress.md"
            elif clicked == all_btn:
                book_id = None
            else:
                return

        result = export_progress_to_markdown(self._db, book_id)
        if result is None:
            QMessageBox.information(self, "Nothing to Export", "No progress data found.")
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "Export Progress", suggested_name, "Markdown Files (*.md);;All Files (*)"
        )
        if path:
            try:
                Path(path).write_text(result, encoding="utf-8")
                self._status_state.setText(f"Exported to {Path(path).name}")
            except OSError as e:
                QMessageBox.warning(self, "Export Failed", f"Could not save file:\n{e}")

    # --- Bookmarks & Notes ---

    @safe_slot
    def _add_bookmark(self) -> None:
        if not self._book.current_book:
            return
        scroll_pos = self._reader.verticalScrollBar().value()
        add_bookmark_dialog(
            self,
            self._db,
            self._book.current_book.book_id,
            self._book.current_chapter_num,
            scroll_pos,
        )

    @safe_slot
    def _show_bookmarks(self) -> None:
        book_id = self._book.current_book.book_id if self._book.current_book else None
        dialog = BookmarkDialog(self._db, book_id, self)
        dialog.bookmark_selected.connect(self._goto_bookmark)
        dialog.exec()

    @safe_slot
    def _goto_bookmark(self, book_id: str, chapter_num: int, scroll_pos: int) -> None:
        if self._book.current_book and self._book.current_book.book_id != book_id:
            self._library.select_book(book_id)
        self._book.navigate_to_chapter(chapter_num)
        # Defer scroll so the new chapter's HTML has time to render
        QTimer.singleShot(50, lambda: self._reader.verticalScrollBar().setValue(scroll_pos))

    @safe_slot
    def _add_note(self) -> None:
        if not self._book.current_book:
            return
        logger.debug("_add_note: book=%s chapter=%s", self._book.current_book.book_id, self._book.current_chapter_num)
        section_title = self._book.current_chapter_title()
        logger.debug("_add_note: creating NotesDialog")
        dialog = NotesDialog(
            self._db,
            self._book.current_book.book_id,
            self._book.current_chapter_num,
            self,
            section_title=section_title,
        )
        logger.debug("_add_note: calling dialog.exec()")
        dialog.exec()
        logger.debug("_add_note: dialog closed")

    @safe_slot
    def _show_notes(self) -> None:
        book_id = self._book.current_book.book_id if self._book.current_book else None
        dialog = NotesDialog(self._db, book_id, parent=self)
        dialog.exec()

    # --- Exercises ---

    @safe_slot
    def _show_exercises(self) -> None:
        if not self._book.current_book:
            QMessageBox.information(self, "No Book", "Please select a book first.")
            return
        from PyQt6.QtWidgets import QDialog, QVBoxLayout

        dialog = QDialog(self)
        dialog.setWindowTitle("Exercises")
        dialog.setMinimumSize(500, 500)
        layout = QVBoxLayout(dialog)
        panel = ExercisePanel(self._db, dialog)
        panel.load_exercises(self._book.current_book.book_id)
        panel.load_code_requested.connect(self._editor.set_code)
        layout.addWidget(panel)
        dialog.exec()

    # --- Quiz ---

    @safe_slot
    def _show_quiz(self) -> None:
        """Switch to the Quiz tab and load the quiz for the current chapter."""
        if not self._book.current_book:
            QMessageBox.information(self, "No Book", "Please select a book first.")
            return
        book_id = self._book.current_book.book_id
        chapter_num = self._book.current_chapter_num
        if self._quiz_panel.load_quiz(book_id, chapter_num):
            self._right_tabs.setCurrentWidget(self._quiz_panel)
        else:
            QMessageBox.information(self, "No Quiz", f"No quiz available for Chapter {chapter_num} yet.")

    @safe_slot
    def _show_quiz_review(self) -> None:
        """Load missed quiz questions for spaced repetition review."""
        if not self._book.current_book:
            QMessageBox.information(self, "No Book", "Please select a book first.")
            return
        book_id = self._book.current_book.book_id
        if self._quiz_panel.load_review_quiz(book_id):
            self._right_tabs.setCurrentWidget(self._quiz_panel)
        else:
            QMessageBox.information(
                self, "No Missed Questions", "No incorrect quiz answers to review. Keep up the good work!"
            )

    # --- Challenge ---

    @safe_slot
    def _show_challenge(self) -> None:
        """Switch to the Challenge tab and load challenges for the current chapter."""
        if not self._book.current_book:
            QMessageBox.information(self, "No Book", "Please select a book first.")
            return
        book_id = self._book.current_book.book_id
        chapter_num = self._book.current_chapter_num
        if self._challenge_panel.load_challenges(book_id, chapter_num):
            self._right_tabs.setCurrentWidget(self._challenge_panel)
        else:
            QMessageBox.information(self, "No Challenge", f"No challenges available for Chapter {chapter_num} yet.")

    # --- Project ---

    @safe_slot
    def _show_project(self) -> None:
        """Switch to the Project tab and load the book project."""
        if not self._book.current_book:
            QMessageBox.information(self, "No Book", "Please select a book first.")
            return
        book_id = self._book.current_book.book_id
        if self._project_panel.load_project(book_id):
            self._right_tabs.setCurrentWidget(self._project_panel)
        else:
            QMessageBox.information(self, "No Project", "No project available for this book yet.")

    # --- View ---

    @safe_slot
    def _toggle_toc(self) -> None:
        self._toc.setVisible(not self._toc.isVisible())

    @safe_slot
    def _increase_font(self) -> None:
        size = min(self._app_config.reader_font_size + 1, 30)
        self._on_font_size_changed(size)
        self._toolbar.set_font_size(size)

    @safe_slot
    def _decrease_font(self) -> None:
        size = max(self._app_config.reader_font_size - 1, 6)
        self._on_font_size_changed(size)
        self._toolbar.set_font_size(size)

    @safe_slot
    def _focus_toc(self) -> None:
        if not self._toc.isVisible():
            self._toc.setVisible(True)
        self._toc.setFocus()

    @safe_slot
    def _focus_reader(self) -> None:
        self._reader.setFocus()

    @safe_slot
    def _focus_editor(self) -> None:
        self._editor.setFocus()

    @safe_slot
    def _on_font_size_changed(self, size: int) -> None:
        self._reader.set_font_size(size)
        self._editor.set_font_size(size)
        self._app_config.reader_font_size = size
        self._editor_config.font_size = size

    @safe_slot
    def _on_theme_changed(self, theme_name: str) -> None:
        self.setStyleSheet(get_stylesheet(theme_name))
        self._reader.set_theme(theme_name)
        self._editor.set_theme(theme_name)
        self._console.set_theme(theme_name)
        self._quiz_panel.set_theme(theme_name)
        self._challenge_panel.set_theme(theme_name)
        self._project_panel.set_theme(theme_name)
        self._output.set_theme(theme_name)
        self._app_config.theme = theme_name

    # --- Search ---

    @safe_slot
    def _find_in_chapter(self) -> None:
        """Show the inline find bar in the reader panel."""
        self._reader.show_find_bar()

    @safe_slot
    def _show_search(self) -> None:
        book_ids = [b["book_id"] for b in self._books_config.books]
        current_bid = self._book.current_book.book_id if self._book.current_book else None
        dialog = SearchDialog(
            self._cache,
            book_ids,
            current_book_id=current_bid,
            theme_name=self._app_config.theme,
            parent=self,
        )
        dialog.navigate_requested.connect(self._search_navigate)
        dialog.exec()

    @safe_slot
    def _search_navigate(self, book_id: str, chapter_num: int, block_id: str) -> None:
        if self._book.current_book and self._book.current_book.book_id != book_id:
            self._library.select_book(book_id)
        self._book.navigate_to_chapter(chapter_num)
        if block_id:
            QTimer.singleShot(50, lambda: self._reader.scroll_to_block(block_id))

    # --- Progress ---

    @safe_slot
    def _show_progress(self) -> None:
        dialog = ProgressDialog(self._db, self)
        dialog.exec()

    # --- Help ---

    @safe_slot
    def _show_shortcuts(self) -> None:
        """Show keyboard shortcuts reference."""
        shortcuts_html = """
        <h2>Keyboard Shortcuts</h2>
        <table cellpadding="4" cellspacing="0" style="border-collapse:collapse;">
        <tr><td colspan="2"><b>Navigation</b></td></tr>
        <tr><td><code>Alt+Left</code></td><td>Previous chapter</td></tr>
        <tr><td><code>Alt+Right</code></td><td>Next chapter</td></tr>
        <tr><td><code>Ctrl+M</code></td><td>Mark chapter complete</td></tr>
        <tr><td><code>Ctrl+T</code></td><td>Toggle TOC panel</td></tr>
        <tr><td colspan="2"><b>Search</b></td></tr>
        <tr><td><code>Ctrl+F</code></td><td>Find in current chapter</td></tr>
        <tr><td><code>Ctrl+Shift+F</code></td><td>Search all books</td></tr>
        <tr><td colspan="2"><b>Code</b></td></tr>
        <tr><td><code>F5</code></td><td>Run code</td></tr>
        <tr><td><code>Shift+F5</code></td><td>Stop execution</td></tr>
        <tr><td><code>Ctrl+S</code></td><td>Save code to file</td></tr>
        <tr><td><code>Ctrl+O</code></td><td>Load code from file</td></tr>
        <tr><td><code>Ctrl+E</code></td><td>Open in external editor</td></tr>
        <tr><td colspan="2"><b>View</b></td></tr>
        <tr><td><code>Ctrl+=</code></td><td>Increase font size</td></tr>
        <tr><td><code>Ctrl+-</code></td><td>Decrease font size</td></tr>
        <tr><td><code>Ctrl+1</code></td><td>Focus TOC panel</td></tr>
        <tr><td><code>Ctrl+2</code></td><td>Focus reader panel</td></tr>
        <tr><td><code>Ctrl+3</code></td><td>Focus code editor</td></tr>
        <tr><td colspan="2"><b>Notes &amp; Bookmarks</b></td></tr>
        <tr><td><code>Ctrl+B</code></td><td>Add bookmark</td></tr>
        <tr><td><code>Ctrl+N</code></td><td>Add note</td></tr>
        <tr><td><code>Ctrl+Q</code></td><td>Take quiz for current chapter</td></tr>
        <tr><td><code>Ctrl+Shift+Q</code></td><td>Code challenge for current chapter</td></tr>
        <tr><td><code>Ctrl+P</code></td><td>Open book project</td></tr>
        <tr><td colspan="2"><b>Other</b></td></tr>
        <tr><td><code>Ctrl+/</code></td><td>Show this dialog</td></tr>
        </table>
        """
        QMessageBox.information(self, "Keyboard Shortcuts", shortcuts_html)

    @safe_slot
    def _show_about(self) -> None:
        QMessageBox.about(
            self,
            f"About {APP_NAME}",
            f"<h2>{APP_NAME} v{APP_VERSION}</h2>"
            f"<p>Interactive Python Learning Desktop App</p>"
            f"<p>Read O'Reilly Python books with an integrated "
            f"code editor and execution console.</p>"
            f"<p>Built with PyQt6, QScintilla, PyMuPDF, and Pygments.</p>",
        )

    # --- Lifecycle ---

    def closeEvent(self, event: QCloseEvent) -> None:
        """Save state on close."""
        self._save_state()
        # Clean up external editor temp files
        self._external_editor.cleanup()
        # Kill session subprocess and wait for it to be reaped
        self._session.reset()
        if self._parse_process and self._parse_process.is_running():
            self._parse_process.stop()
        if self._exec_worker and self._exec_worker.isRunning():
            self._session.stop()  # ensure subprocess is dead so thread can exit
            if not self._exec_worker.wait(5000):
                self._exec_worker.terminate()
        super().closeEvent(event)
