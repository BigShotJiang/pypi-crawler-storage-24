class SwytchitError(Exception):
    pass
