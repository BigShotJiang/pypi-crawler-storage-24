# TarUP Backup Tool
This project creates 2 files, one a tar.xz archive and a .json that contains metadata about the files.
### What it does
- It checks that your files are identical with MD5 and SHA256.
- It can do a dry run, which checks for permission errors.
- It uses UUIDs for file names, cuz why not. And shortens out the archive names. And makes sure that no renaming happened.
- It shows a progress bar, and how fast in MB/s.
### How to use it
To make a backup of a folder:
```
tarup /path/to/your/folder
```
To unpack a backup you already made:
```
tarup -u /where/you/want/it
```
To check for errors without making a backup:
```
tarup --dry-run /idk/for/another/path/name/so/random/path/my/god/why/is/this/so/nested/deep/bro/you/dont/need/this/many/folders/someone/help/me/out/this/dungeon/finnaly/the/end
```
### Files it creates
1. structure.json: This file contains all information about your folders and files.
2. contents.tar.xz: This file contains your actual files.
3. permissions_audit.log: This file shows up if you run a dry run and encounter errors.

### Credits
Created by WhiteLabs, owned and ran by ThatWhiteGuy364.

### License
