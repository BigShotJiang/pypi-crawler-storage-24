# Drafted using JuneAI, a creation of WhiteLabs, owned and ran by ThatWhiteGuy364
'''
    TarUP - A small terminal utility to create a backup of your files
    Copyright (C) 2026 WhiteLabs <Zak White (ThatWhiteGuy364)>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

import os, json, tarfile, uuid, time, sys, argparse, shutil, tempfile, hashlib

try:
    import fcntl
    def lock_file(f): fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    def unlock_file(f): fcntl.flock(f, fcntl.LOCK_UN)
except ImportError:
    try:
        import msvcrt
        def lock_file(f):
            size = os.path.getsize(f.name) if os.path.exists(f.name) else 0
            if size > 0:
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, size)
        def unlock_file(f):
            size = os.path.getsize(f.name) if os.path.exists(f.name) else 0
            if size > 0:
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, size)
    except ImportError:
        def lock_file(f): pass
        def unlock_file(f): pass

def generate_id(): return uuid.uuid4().hex

def get_hashes(path):
    md5, sha = hashlib.md5(), hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            md5.update(chunk)
            sha.update(chunk)
    return md5.hexdigest(), sha.hexdigest()

def check_permission(path, mode='r'):
    try:
        if mode == 'r':
            with open(path, 'rb'): pass
        elif mode == 'w':
            if os.path.isdir(path):
                testfile = tempfile.TemporaryFile(dir=path)
                testfile.close()
            else:
                with open(path, 'ab'): pass
        return True
    except OSError:
        return False

def count_json_files(node):
    if node.get("type") == "file": return 1
    return sum(count_json_files(child) for child in node.get("children", []))

def package_folder(source_dir, output_json, output_tarball, dry_run=False):
    file_map = {}
    total_files = sum([len(files) for r, d, files in os.walk(source_dir)])
    files_processed, total_bytes, denied_count = 0, 0, 0
    start_time = time.time()
    audit_log = open("permissions_audit.log", "w", encoding="utf-8") if dry_run else None

    def build_tree(path):
        nonlocal files_processed, total_bytes, denied_count
        name = os.path.basename(path)
        try:
            stats = os.stat(path)
            node = {"name": name, "size_bytes": stats.st_size, "last_modified": stats.st_mtime}
            if os.path.isdir(path):
                node["type"] = "directory"
                children = []
                for x in os.listdir(path):
                    child = build_tree(os.path.join(path, x))
                    if child: children.append(child)
                node["children"] = children
            else:
                if not check_permission(path, 'r'):
                    if audit_log: audit_log.write(f"READ DENIED: {path}\n")
                    denied_count += 1
                    return None
                node["type"] = "file"
                rid = f"{generate_id()}.dat"
                node["content_id"] = rid
                if not dry_run:
                    m, s = get_hashes(path)
                    node["md5"], node["sha256"] = m, s
                    file_map[rid] = os.path.abspath(path)
                files_processed += 1
                total_bytes += stats.st_size
                pct = (files_processed / max(1, total_files)) * 100
                elapsed = time.time() - start_time
                rate = (total_bytes / 1024**2) / (elapsed if elapsed > 0 else 1)
                bar = "=" * int((pct / 100) * 30)
                sys.stdout.write(f"\r{files_processed}/{total_files} [{bar:<30}] {pct:.1f}% | {rate:.2f} MB/s")
                sys.stdout.flush()
            return node
        except Exception as e:
            if audit_log: audit_log.write(f"ACCESS ERROR: {path} | {str(e)}\n")
            denied_count += 1
            return None

    if dry_run: print("--- STARTING PERMISSION AUDIT ---")
    tree = build_tree(source_dir)
    if audit_log: audit_log.close()

    if dry_run:
        print(f"\nAudit Complete. {denied_count} files/folders inaccessible.")
        if denied_count > 0: print("See permissions_audit.log for details.")
        return

    print(f"\nFinalizing tarball...")
    with tarfile.open(output_tarball, "w:xz") as tar:
        for rid, path in file_map.items():
            try: tar.add(path, arcname=rid)
            except: continue
    with open(output_json, 'w') as f: json.dump(tree, f, indent=4)
    print("\nPacking Done!")

def restore_tree(node, source_tar, target_root, stats, dry_run=False, audit_log=None):
    try:
        current_path = os.path.join(target_root, os.path.basename(node["name"]))
        if node["type"] == "directory":
            if not dry_run: os.makedirs(current_path, exist_ok=True)
            elif not check_permission(target_root, 'w'):
                if audit_log: audit_log.write(f"WRITE DENIED (DIR): {current_path}\n")
            for child in node.get("children", []): restore_tree(child, source_tar, current_path, stats, dry_run, audit_log)
        else:
            if dry_run:
                if not check_permission(os.path.dirname(current_path), 'w'):
                    if audit_log: audit_log.write(f"WRITE DENIED (FILE): {current_path}\n")
                    stats['errors'].append(current_path)
            else:
                rid = node["content_id"]
                member = source_tar.getmember(rid)
                source_tar.extract(member, path=target_root, filter='data')
                ext_path = os.path.join(target_root, rid)
                m, s = get_hashes(ext_path)
                if m != node["md5"] or s != node["sha256"]: stats['errors'].append(f"HASH FAIL: {node['name']}")
                if os.path.exists(current_path): stats['overwritten'].append(current_path); os.remove(current_path)
                os.rename(ext_path, current_path)
                os.utime(current_path, (node["last_modified"], node["last_modified"]))

            stats['processed'] += 1
            stats['bytes'] += node["size_bytes"]
            pct = (stats['processed'] / max(1, stats['total'])) * 100
            bar = "=" * int((pct / 100) * 30)
            sys.stdout.write(f"\r{stats['processed']}/{stats['total']} [{bar:<30}] {pct:.1f}%")
            sys.stdout.flush()
    except Exception as e: stats['errors'].append(str(e))

def unpack_folder(output_dir, dry_run=False):
    j, t = "structure.json", "contents.tar.xz"
    if not os.path.exists(j) or not os.path.exists(t): return print("Missing source files.")

    tar_f = open(t, 'rb')
    audit_log = open("permissions_audit.log", "w", encoding="utf-8") if dry_run else None
    try:
        lock_file(tar_f)
        with open(j, 'r') as f: tree = json.load(f)
        stats = {'total': count_json_files(tree), 'processed': 0, 'bytes': 0, 'start': time.time(), 'errors': [], 'overwritten': []}

        if dry_run: print("--- STARTING UNPACK AUDIT ---")
        else:
            if os.path.exists(output_dir) and os.listdir(output_dir):
                c = input(f"\n'{output_dir}' not empty. (a)bort, (o)verride, (c)ombine? ").lower()
                if c == 'a': return
                if c == 'o': shutil.rmtree(output_dir); os.makedirs(output_dir)

        temp_dir = tempfile.mkdtemp(prefix="tarup_") if not dry_run else None
        try:
            with tarfile.open(fileobj=tar_f, mode="r:xz") as tar:
                restore_tree(tree, tar, temp_dir if not dry_run else output_dir, stats, dry_run, audit_log)

            if not dry_run and not stats['errors']:
                final_path = os.path.join(output_dir, tree['name'])
                shutil.copytree(os.path.join(temp_dir, tree['name']), final_path, dirs_exist_ok=True)
                print("\nUnpack Successful!")
            elif dry_run:
                print(f"\nAudit complete. {len(stats['errors'])} permissions issues found.")
        finally:
            if temp_dir: shutil.rmtree(temp_dir)
            if audit_log: audit_log.close()
    finally:
        unlock_file(tar_f); tar_f.close()

def main():
    print()
    parser = argparse.ArgumentParser(description="TarUP Utility - WhiteLabs")
    parser.add_argument("path", nargs="?", help="Path")
    parser.add_argument("-u", "--unpack", action="store_true", help="Unpack mode")
    parser.add_argument("--dry-run", action="store_true", help="Audit permissions and simulate")
    args = parser.parse_args()

    try:
        if args.unpack: unpack_folder(args.path or ".", args.dry_run)
        else:
            folder = args.path or input("Type folder path: ").strip().replace('"', '').replace("'", "")
            if os.path.exists(folder): package_folder(folder, "structure.json", "contents.tar.xz", args.dry_run)
            else: print("Invalid path.")
        print("\nThank you for using TarUP!\nCreated by WhiteLabs, owned and ran by ThatWhiteGuy364 :)")
    except KeyboardInterrupt: print("\nAborted.")

if __name__ == "__main__":
    main()
