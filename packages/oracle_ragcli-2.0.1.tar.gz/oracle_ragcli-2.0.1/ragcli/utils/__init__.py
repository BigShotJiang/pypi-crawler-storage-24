"""Utility functions for ragcli."""
