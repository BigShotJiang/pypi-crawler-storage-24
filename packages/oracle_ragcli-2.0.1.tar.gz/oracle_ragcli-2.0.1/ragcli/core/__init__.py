"""Core ragcli functionality."""
