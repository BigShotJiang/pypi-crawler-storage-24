"""Database operations for ragcli."""
