"""Tests for ragcli."""
