"""
Basic usage of vectorless-qv as a Python library.

Usage:
    python examples/basic_usage.py "path/to/workbook.xlsx" "What is the gross margin?"
"""

import json
import sys
from pathlib import Path

from vectorless_qv import parse_workbook, build_tree, BedrockAgent

def load_or_build(excel_path: str):
    """Reuse cached .tree.json and .parsed.json if they exist, otherwise parse and build."""
    base = Path(excel_path).with_suffix("")
    tree_path = Path(str(base) + ".tree.json")
    data_path = Path(str(base) + ".parsed.json")

    if tree_path.exists() and data_path.exists():
        print(f"Reusing cached index: {tree_path.name}")
        tree = json.loads(tree_path.read_text())
        data = json.loads(data_path.read_text())
    else:
        print(f"Parsing {excel_path}...")
        data = parse_workbook(excel_path)
        print(f"  Sheets: {len(data['sheets'])}")
        print(f"  Total cells: {sum(len(s['cells']) for s in data['sheets'].values())}")

        print("Building tree index...")
        tree = build_tree(data)
        print(f"  Nodes: {len(tree.get('children', []))}")

        # Cache for future runs
        tree_path.write_text(json.dumps(tree, indent=2))
        data_path.write_text(json.dumps(data, indent=2))
        print(f"Saved: {tree_path.name}, {data_path.name}")

    return tree, data


def main():
    if len(sys.argv) < 2:
        print("Usage: python basic_usage.py <excel_file> [question]")
        sys.exit(1)

    excel_path = sys.argv[1]
    question = sys.argv[2] if len(sys.argv) > 2 else "What is the gross margin?"

    # Step 1: Load or build tree index
    tree, data = load_or_build(excel_path)

    # Step 2: Query with the reasoning agent
    print(f"\nQuestion: {question}\n")
    agent = BedrockAgent(tree=tree, workbook_data=data, excel_path=excel_path)
    result = agent.query(question)

    # Step 3: Display results
    print("Answer:")
    print(result["answer"])
    print("\nCitations:")
    for c in result.get("citations", []):
        print(f"  {c['sheet']}!{c['cell']}: {c.get('formula', c.get('value', ''))}")


if __name__ == "__main__":
    main()