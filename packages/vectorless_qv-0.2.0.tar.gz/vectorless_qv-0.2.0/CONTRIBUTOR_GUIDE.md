# Vectorless-QV — Contributor Onboarding Guide

> Reasoning-based RAG for Excel financial models — no vectors, no chunking.

---

## What Is Vectorless?

Vectorless is a Python tool that answers natural-language questions about complex Excel financial models **without vector databases or text chunking**. Inspired by [PageIndex](https://github.com/VectifyAI/PageIndex), it builds a hierarchical tree index of an `.xlsx` workbook and uses an AWS Bedrock (Claude) LLM agent to navigate it — the same way a human financial analyst would scan sheets, trace formulas, and follow cross-sheet references.

### Core Design Principles

| # | Principle | What It Means |
|---|-----------|---------------|
| 1 | **No vectors, no chunking** | Cell relationships and formulas are never flattened into embeddings. Structure is preserved as-is. |
| 2 | **Hierarchical tree index** | Workbook → Sheets → Tables/Ranges → Cells. Each node carries an LLM-generated summary. |
| 3 | **Reasoning-based retrieval** | The LLM iteratively navigates the tree (drill-down, trace, search) instead of doing a single similarity lookup. |
| 4 | **100% traceability** | Every answer cites the exact sheet, cell address, and formula. The user can verify in the original file. |
| 5 | **What-if analysis** | Override cell values and recalculate dependents in pure Python — no desktop Excel needed. |

---

## Tech Stack

| Component | Library / Service | Purpose |
|-----------|-------------------|---------|
| LLM | AWS Bedrock + Anthropic Claude Sonnet | Tree navigation, reasoning, answer synthesis |
| Excel Parsing | `openpyxl` | Two-pass extraction: raw formulas + cached values |
| Table Detection | `pandas` | Heuristic header/data-block identification |
| Formula Execution | `formulas` | Pure-Python what-if recalculation |
| CLI | `argparse` | Command-line interface (`index`, `query`, `inspect`) |
| Build System | `hatchling` | Packaging via `pyproject.toml` |
| Runtime | Python ≥ 3.11 | |

### AWS Configuration

| Env Variable | Default | Description |
|---|---|---|
| `AWS_DEFAULT_REGION` | `us-east-1` | Region for Bedrock API |
| `AWS_ACCESS_KEY_ID` | — | AWS credentials |
| `AWS_SECRET_ACCESS_KEY` | — | AWS credentials |

---

## Project Structure

```
vectorless/
├── pyproject.toml               # Package metadata, deps, CLI entry point
├── requirements.txt             # Pip-compatible deps (boto3, openpyxl, pandas, formulas)
├── Architecture.md              # Detailed architecture & PageIndex design doc
├── README.md                    # User-facing quick-start
├── CONTRIBUTOR_GUIDE.md         # ← You are here
│
│ ── Root-Level Standalone Scripts ──
├── excel_parser.py              # Parse Excel (mirrors src/vectorless_qv/parser.py)
├── tree_indexer.py              # Build tree index (mirrors src/vectorless_qv/indexer.py)
├── bedrock_agent.py             # Bedrock agentic loop (mirrors src/vectorless_qv/agent.py)
├── execution_engine.py          # What-if engine (mirrors src/vectorless_qv/engine.py)
├── main.py                      # CLI entrypoint for standalone use
│
│ ── Installable Package ──
├── src/
│   └── vectorless_qv/           # Primary package (pip install -e .)
│       ├── __init__.py           #   Public API exports
│       ├── parser.py             #   Excel parsing
│       ├── indexer.py            #   Tree index builder
│       ├── agent.py              #   Bedrock agent + tool loop
│       ├── engine.py             #   Formula execution engine
│       └── cli.py                #   CLI wrapper (vectorless-qv command)
│
│ ── Legacy / Alternate Namespace ──
│   └── vectorless/              # Older package namespace (same logic, different imports)
│       ├── agent.py
│       ├── cli.py
│       └── indexer.py
│
├── examples/
│   └── basic_usage.py           # Python API usage example
├── tests/
│   └── __init__.py              # Test package (tests TBD)
└── create_sample_workbook.py    # Generates test Excel files
```

### Dual Build Structure

The codebase has two ways to run:

1. **Standalone**: `python main.py index --file model.xlsx` — uses root-level `.py` files directly.
2. **Package**: `vectorless-qv index --file model.xlsx` — uses `src/vectorless_qv/` after `pip install -e .`.

The root-level scripts are duplicates of the package modules. The canonical code lives in `src/vectorless_qv/`.

---

## Data Flow

### Phase 1 — Indexing (runs once per workbook)

```
 .xlsx file
     │
     ▼
 parser.py ─── Two-pass openpyxl read ──▶ workbook_data dict
     │            (formulas + cached values)
     ▼
 indexer.py ── Build tree hierarchy ────▶ tree dict
     │            (optional LLM summaries via Bedrock)
     ▼
 Output:
   ├── <name>.parsed.json   (raw cell-level data for runtime lookups)
   └── <name>.tree.json     (hierarchical tree index with summaries)
```

### Phase 2 — Querying (runs per question)

```
 User question
     │
     ▼
 agent.py  ────  BedrockAgent.query()
     │
     │  Agentic loop (up to 15 iterations):
     │    1. LLM reads tree overview (top-level summaries)
     │    2. LLM issues JSON tool calls:
     │         drill_down  → inspect a child node
     │         get_cells   → read specific cell values/formulas
     │         get_row     → read an entire row
     │         search_rows → keyword search across row labels
     │         what_if     → override cells & recalculate (engine.py)
     │         answer      → return final answer + citations
     │    3. Tool results fed back to LLM context
     │    4. Repeat until "answer" action or max iterations
     │
     ▼
 Structured result: { answer, citations, reasoning_trace }
```

---

## Key Modules — What You Need to Know

### `parser.py` — Excel Parsing

- **Two-pass strategy**: opens the workbook twice via `openpyxl`:
  - `data_only=False` → raw formulas (`=SUM(B2:B10)`)
  - `data_only=True` → last-computed values (`150000`)
- **Reference extraction**: regex pattern `_REF_PATTERN` pulls cell refs from formulas, including cross-sheet (`Sheet2!B4`, `Dashboard!$C$5:$D$10`).
- **Table detection**: heuristic — identifies contiguous blocks with a text-header row followed by data rows.
- **Output**: dict with `file_name`, `sheet_names`, `named_ranges`, and per-sheet `cells` map (keyed by cell address).

### `indexer.py` — Tree Builder

- **Node types**: `workbook` → `sheet` → `table` | `range`
- **Each node**: `{ node_id, title, type, summary, cell_range, formulas, dependencies, headers, nodes }`
- **LLM summaries**: optional callback; if a Bedrock summarizer is provided, each node gets a concise natural-language description generated during indexing.
- **Key utilities**:
  - `get_top_level_summary(tree)` — formatted overview used as the LLM's starting context.
  - `get_node_by_id(tree, id)` — DFS lookup.
  - `get_node_detail(tree, id, workbook_data)` — rich text for a node (used by `drill_down` tool).

### `agent.py` — Bedrock Agentic Loop

- **Model**: defaults to Claude Sonnet via AWS Bedrock `converse` API.
- **System prompt**: instructs the LLM to act as a financial analyst — trace formulas, follow cross-sheet references, be efficient, cite everything.
- **Tool dispatch**: LLM emits JSON `{ "action": "...", "params": {...} }` arrays; agent parses and executes each tool, returning results to the conversation.
- **Parallel tool calls**: a single LLM turn can invoke multiple tools at once.
- **Header pre-caching**: column/row headers are pre-extracted and included in the tree overview to reduce wasted LLM iterations.

### `engine.py` — Formula Execution

- **Library**: `formulas` (pure Python recalculation of Excel formulas).
- **`what_if(overrides, observe)`**: override input cells (e.g., `{"'Assumptions'!B3": 0.13}`) → recalculate → observe output cells.
- **Lazy loading**: the Excel model is loaded on first use (can be slow for large files).

### `cli.py` — Command-Line Interface

Three commands:
```bash
vectorless-qv index   --file model.xlsx [--with-llm] [--model MODEL] [--region REGION]
vectorless-qv query   --file model.xlsx [-q QUESTION] [--model MODEL] [-v]
vectorless-qv inspect --file model.xlsx [-n NODE_ID]
```

---

## Getting Started (Dev Setup)

```bash
# 1. Clone the repo
git clone <repo-url> && cd vectorless

# 2. Create a virtual environment
python3.11 -m venv .venv && source .venv/bin/activate

# 3. Install in editable mode with dev dependencies
pip install -e ".[dev]"

# 4. Set AWS credentials
export AWS_ACCESS_KEY_ID=<your-key>
export AWS_SECRET_ACCESS_KEY=<your-secret>
export AWS_DEFAULT_REGION=us-east-1

# 5. Index a test workbook
vectorless-qv index --file examples/test_model.xlsx

# 6. Query it
vectorless-qv query --file examples/test_model.xlsx -q "What drives net income?"
```

---

## How to Run Tests

```bash
pytest           # runs test suite from tests/ directory
ruff check .     # lint
```

> **Note**: The test suite is currently empty (`tests/__init__.py` only). See the TODO section below for contributing tests.

---

## Example: Python API

```python
from vectorless_qv import parse_workbook, build_tree, BedrockAgent

# Parse and build the tree index
data = parse_workbook("financials.xlsx")
tree = build_tree(data)

# Instantiate the agent and ask a question
agent = BedrockAgent(tree=tree, workbook_data=data, excel_path="financials.xlsx")
result = agent.query("What is the gross margin for Q3?")

print(result["answer"])      # Natural-language answer
print(result["citations"])   # [{ sheet, cell, formula, value }]
```

---

## Actionable TODOs for Contributors

Below is a practical checklist of areas where contributions are needed. Pick one, open a branch, and submit a PR.

### High Priority

- [ ] **Write unit tests for parser.py** — Cover: two-pass parsing, cross-sheet reference extraction, table detection edge cases, merged-cell handling.
  - Owner: _unassigned_ | Target: `tests/test_parser.py`

- [ ] **Write unit tests for indexer.py** — Cover: tree construction, node ID generation, header extraction, `get_node_by_id` traversal.
  - Owner: _unassigned_ | Target: `tests/test_indexer.py`

- [ ] **Write integration test for full query flow** — Parse → index → agent query → verify answer contains expected citations.
  - Owner: _unassigned_ | Target: `tests/test_integration.py`

- [ ] **Consolidate root-level duplicates** — Root `.py` files duplicate `src/vectorless_qv/`. Refactor `main.py` to import from the package directly and remove standalone duplicates.
  - Owner: _unassigned_ | Evidence: root `excel_parser.py`, `tree_indexer.py`, `bedrock_agent.py`, `execution_engine.py`

### Medium Priority

- [ ] **Remove the legacy `src/vectorless/` namespace** — It mirrors `vectorless_qv` with different import paths but no distinct functionality. Consolidate into `vectorless_qv` only.
  - Owner: _unassigned_

- [ ] **Add CI pipeline** — GitHub Actions workflow: lint (`ruff`), test (`pytest`), build (`hatch build`).
  - Owner: _unassigned_

- [ ] **Improve error handling for Bedrock API failures** — Retry logic, rate-limit backoff, clearer error messages on auth failures.
  - Owner: _unassigned_

- [ ] **Add structured logging** — Replace `print()` calls with Python `logging` module throughout.
  - Owner: _unassigned_

### Nice to Have

- [ ] **Support `.xlsm` (macro-enabled) workbooks** — Extend parser to handle VBA macro sheets gracefully.
  - Owner: _unassigned_

- [ ] **Streaming output for long queries** — Stream the reasoning trace to stdout as the agent iterates, rather than only at the end.
  - Owner: _unassigned_

- [ ] **Web UI / Streamlit frontend** — Interactive interface for uploading workbooks, viewing the tree, and chatting with the agent.
  - Owner: _unassigned_

- [ ] **Configurable model selection** — Allow switching between Claude models or other Bedrock-supported models (e.g., Llama, Mistral) via config file.
  - Owner: _unassigned_

---

## Key Files Quick Reference

| What | File | Entry Function |
|------|------|----------------|
| Parse Excel | `src/vectorless_qv/parser.py` | `parse_workbook(file_path)` |
| Build tree | `src/vectorless_qv/indexer.py` | `build_tree(workbook_data, summarizer)` |
| Query agent | `src/vectorless_qv/agent.py` | `BedrockAgent.query(question)` |
| What-if calc | `src/vectorless_qv/engine.py` | `ExcelExecutionEngine.what_if(overrides, observe)` |
| CLI | `src/vectorless_qv/cli.py` | `main()` |
| Package API | `src/vectorless_qv/__init__.py` | All public exports |

---

## Links & References

- [PageIndex Paper (VectifyAI)](https://github.com/VectifyAI/PageIndex) — The original inspiration for tree-based document indexing.
- [AWS Bedrock Documentation](https://docs.aws.amazon.com/bedrock/latest/userguide/) — LLM provider used for reasoning.
- [openpyxl Docs](https://openpyxl.readthedocs.io/) — Excel parsing library.
- [formulas Library](https://pypi.org/project/formulas/) — Pure-Python Excel formula engine.
- [Architecture.md](Architecture.md) — Detailed architecture design document with example query flows.
