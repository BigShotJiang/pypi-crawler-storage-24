"""
llm_providers.py — Multi-provider LLM abstraction layer.

Supports the same breadth of providers as LangChain:
  - bedrock    : AWS Bedrock (Claude, Titan, Llama, Mistral)
  - openai     : OpenAI API  (GPT-4o, GPT-4, o1, o3)
  - anthropic  : Anthropic direct API (Claude)
  - google     : Google Generative AI (Gemini)
  - azure      : Azure OpenAI Service
  - ollama     : Local models via Ollama
  - groq       : Groq Cloud API
  - together   : Together AI API

Each provider implements a simple invoke(system, messages, max_tokens) → str interface.
"""

from __future__ import annotations

import json
import os
from typing import Any, Protocol


# ── Provider Protocol ────────────────────────────────────────────────────────

class LLMProvider(Protocol):
    """Minimal interface every LLM backend must satisfy."""

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        """Send a conversation to the LLM and return the assistant's text response."""
        ...


# ── Default model IDs per provider ──────────────────────────────────────────

DEFAULT_MODELS: dict[str, str] = {
    "bedrock": "global.anthropic.claude-sonnet-4-6",
    "openai": "gpt-4o",
    "anthropic": "claude-sonnet-4-20250514",
    "google": "gemini-2.0-flash",
    "azure": "gpt-4o",
    "ollama": "llama3.1",
    "groq": "llama-3.3-70b-versatile",
    "together": "meta-llama/Llama-3.3-70B-Instruct-Turbo",
}


# ── AWS Bedrock ──────────────────────────────────────────────────────────────

class BedrockProvider:
    """AWS Bedrock runtime — supports Claude, Titan, Llama, Mistral via cross-region inference."""

    def __init__(self, model_id: str | None = None, region: str | None = None):
        import boto3

        self.model_id = model_id or DEFAULT_MODELS["bedrock"]
        self.region = region or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        self.client = boto3.client("bedrock-runtime", region_name=self.region)

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "system": system,
            "messages": messages,
        }
        response = self.client.invoke_model(
            modelId=self.model_id,
            body=json.dumps(body),
            contentType="application/json",
            accept="application/json",
        )
        result = json.loads(response["body"].read())
        return result["content"][0]["text"]


# ── OpenAI ───────────────────────────────────────────────────────────────────

class OpenAIProvider:
    """OpenAI API — GPT-4o, GPT-4, o1, o3-mini, etc."""

    def __init__(self, model_id: str | None = None, api_key: str | None = None,
                 base_url: str | None = None):
        from openai import OpenAI

        self.model_id = model_id or DEFAULT_MODELS["openai"]
        self.client = OpenAI(
            api_key=api_key or os.environ.get("OPENAI_API_KEY"),
            base_url=base_url,
        )

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        oai_messages = [{"role": "system", "content": system}]
        oai_messages.extend(messages)
        response = self.client.chat.completions.create(
            model=self.model_id,
            messages=oai_messages,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content


# ── Anthropic (direct) ───────────────────────────────────────────────────────

class AnthropicProvider:
    """Anthropic Messages API — Claude 4 / Sonnet / Haiku via direct API."""

    def __init__(self, model_id: str | None = None, api_key: str | None = None):
        from anthropic import Anthropic

        self.model_id = model_id or DEFAULT_MODELS["anthropic"]
        self.client = Anthropic(api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"))

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        response = self.client.messages.create(
            model=self.model_id,
            max_tokens=max_tokens,
            system=system,
            messages=messages,
        )
        return response.content[0].text


# ── Google Generative AI (Gemini) ────────────────────────────────────────────

class GoogleProvider:
    """Google Generative AI — Gemini 2.0 Flash / Pro / Ultra."""

    def __init__(self, model_id: str | None = None, api_key: str | None = None):
        from google import genai

        self.model_id = model_id or DEFAULT_MODELS["google"]
        self._api_key = api_key or os.environ.get("GOOGLE_API_KEY")
        self.client = genai.Client(api_key=self._api_key)

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        from google.genai import types

        # Convert messages to Gemini content format
        contents = []
        for msg in messages:
            role = "model" if msg["role"] == "assistant" else "user"
            contents.append(types.Content(role=role, parts=[types.Part(text=msg["content"])]))

        response = self.client.models.generate_content(
            model=self.model_id,
            contents=contents,
            config=types.GenerateContentConfig(
                system_instruction=system,
                max_output_tokens=max_tokens,
            ),
        )
        return response.text


# ── Azure OpenAI ─────────────────────────────────────────────────────────────

class AzureOpenAIProvider:
    """Azure OpenAI Service — deployed GPT-4o / GPT-4 / GPT-3.5 models."""

    def __init__(self, model_id: str | None = None, api_key: str | None = None,
                 endpoint: str | None = None, api_version: str | None = None):
        from openai import AzureOpenAI

        self.model_id = model_id or DEFAULT_MODELS["azure"]
        self.client = AzureOpenAI(
            api_key=api_key or os.environ.get("AZURE_OPENAI_API_KEY"),
            azure_endpoint=endpoint or os.environ.get("AZURE_OPENAI_ENDPOINT", ""),
            api_version=api_version or os.environ.get("AZURE_OPENAI_API_VERSION", "2024-06-01"),
        )

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        oai_messages = [{"role": "system", "content": system}]
        oai_messages.extend(messages)
        response = self.client.chat.completions.create(
            model=self.model_id,
            messages=oai_messages,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content


# ── Ollama (local) ───────────────────────────────────────────────────────────

class OllamaProvider:
    """Ollama — local models (Llama 3, Mistral, Phi, Qwen, DeepSeek, etc.)."""

    def __init__(self, model_id: str | None = None, base_url: str | None = None):
        from openai import OpenAI

        self.model_id = model_id or DEFAULT_MODELS["ollama"]
        self.client = OpenAI(
            api_key="ollama",
            base_url=base_url or os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1"),
        )

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        oai_messages = [{"role": "system", "content": system}]
        oai_messages.extend(messages)
        response = self.client.chat.completions.create(
            model=self.model_id,
            messages=oai_messages,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content


# ── Groq ─────────────────────────────────────────────────────────────────────

class GroqProvider:
    """Groq Cloud — ultra-fast inference for Llama, Mixtral, Gemma."""

    def __init__(self, model_id: str | None = None, api_key: str | None = None):
        from groq import Groq

        self.model_id = model_id or DEFAULT_MODELS["groq"]
        self.client = Groq(api_key=api_key or os.environ.get("GROQ_API_KEY"))

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        groq_messages = [{"role": "system", "content": system}]
        groq_messages.extend(messages)
        response = self.client.chat.completions.create(
            model=self.model_id,
            messages=groq_messages,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content


# ── Together AI ──────────────────────────────────────────────────────────────

class TogetherProvider:
    """Together AI — open-source model hosting (Llama, Mixtral, etc.)."""

    def __init__(self, model_id: str | None = None, api_key: str | None = None):
        from openai import OpenAI

        self.model_id = model_id or DEFAULT_MODELS["together"]
        self.client = OpenAI(
            api_key=api_key or os.environ.get("TOGETHER_API_KEY"),
            base_url="https://api.together.xyz/v1",
        )

    def invoke(self, system: str, messages: list[dict], max_tokens: int = 4096) -> str:
        oai_messages = [{"role": "system", "content": system}]
        oai_messages.extend(messages)
        response = self.client.chat.completions.create(
            model=self.model_id,
            messages=oai_messages,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content


# ── Registry & Factory ───────────────────────────────────────────────────────

PROVIDER_REGISTRY: dict[str, type] = {
    "bedrock": BedrockProvider,
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
    "google": GoogleProvider,
    "azure": AzureOpenAIProvider,
    "ollama": OllamaProvider,
    "groq": GroqProvider,
    "together": TogetherProvider,
}


def create_provider(provider_name: str, model_id: str | None = None, **kwargs) -> LLMProvider:
    """Factory: instantiate an LLM provider by short name.

    Args:
        provider_name: One of bedrock, openai, anthropic, google, azure, ollama, groq, together.
        model_id: Override the default model for that provider.
        **kwargs: Provider-specific options (region, api_key, base_url, endpoint, etc.).

    Returns:
        An LLMProvider instance ready for invoke().

    Raises:
        ValueError: If the provider name is not recognised.
    """
    provider_name = provider_name.lower().strip()
    if provider_name not in PROVIDER_REGISTRY:
        available = ", ".join(sorted(PROVIDER_REGISTRY.keys()))
        raise ValueError(
            f"Unknown LLM provider '{provider_name}'. Available: {available}"
        )

    cls = PROVIDER_REGISTRY[provider_name]
    return cls(model_id=model_id, **kwargs)


# ── Popular models per provider (for discoverability) ────────────────────────

MODEL_SUGGESTIONS: dict[str, list[str]] = {
    "bedrock": [
        "global.anthropic.claude-sonnet-4-6",
        "anthropic.claude-3-5-sonnet-20241022-v2:0",
        "anthropic.claude-3-haiku-20240307-v1:0",
        "amazon.titan-text-premier-v1:0",
        "meta.llama3-1-70b-instruct-v1:0",
        "mistral.mistral-large-2407-v1:0",
    ],
    "openai": [
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4-turbo",
        "o1",
        "o3-mini",
    ],
    "anthropic": [
        "claude-sonnet-4-20250514",
        "claude-opus-4-20250514",
        "claude-3-5-haiku-20241022",
    ],
    "google": [
        "gemini-2.0-flash",
        "gemini-2.0-pro",
        "gemini-1.5-pro",
        "gemini-1.5-flash",
    ],
    "azure": [
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4-turbo",
    ],
    "ollama": [
        "llama3.1",
        "llama3.1:70b",
        "mistral",
        "mixtral",
        "phi3",
        "qwen2.5",
        "deepseek-r1",
        "gemma2",
    ],
    "groq": [
        "llama-3.3-70b-versatile",
        "llama-3.1-8b-instant",
        "mixtral-8x7b-32768",
        "gemma2-9b-it",
    ],
    "together": [
        "meta-llama/Llama-3.3-70B-Instruct-Turbo",
        "meta-llama/Llama-3.1-8B-Instruct-Turbo",
        "mistralai/Mixtral-8x22B-Instruct-v0.1",
        "Qwen/Qwen2.5-72B-Instruct-Turbo",
        "deepseek-ai/DeepSeek-R1",
    ],
}


def list_providers() -> list[dict[str, Any]]:
    """Return a summary of available providers, their default models, and model suggestions."""
    return [
        {
            "name": name,
            "default_model": DEFAULT_MODELS.get(name, "—"),
            "models": MODEL_SUGGESTIONS.get(name, []),
        }
        for name in sorted(PROVIDER_REGISTRY.keys())
    ]
