"""
main.py — CLI entrypoint for the Vectorless RAG system for Excel financial models.

Usage:
    # Index a workbook (generates tree JSON)
    python main.py index --file model.xlsx

    # Query the workbook interactively
    python main.py query --file model.xlsx

    # Ask a single question
    python main.py query --file model.xlsx --question "What drives Net Income?"
"""

import argparse
import json
import sys
from pathlib import Path

from vectorless_qv.parser import parse_workbook
from vectorless_qv.indexer import build_tree, tree_to_json, get_top_level_summary


def cmd_index(args):
    """Index an Excel workbook: parse → build tree → save JSON."""
    file_path = args.file
    print(f"📂 Parsing workbook: {file_path}")
    workbook_data = parse_workbook(file_path)

    print(f"   Found {len(workbook_data['sheet_names'])} sheets: {', '.join(workbook_data['sheet_names'])}")
    print(f"   Named ranges: {len(workbook_data['named_ranges'])}")

    # Build tree (without LLM summaries for indexing — use --with-llm for Bedrock summaries)
    summarizer = None
    if args.with_llm:
        summarizer = _create_bedrock_summarizer(args)

    print("🌲 Building hierarchical tree index...")
    tree = build_tree(workbook_data, summarizer=summarizer)

    # Save tree to JSON
    out_path = Path(file_path).with_suffix(".tree.json")
    out_path.write_text(tree_to_json(tree))
    print(f"✅ Tree index saved to: {out_path}")

    # Also save parsed data for query-time cell lookups
    data_path = Path(file_path).with_suffix(".parsed.json")
    data_path.write_text(json.dumps(workbook_data, indent=2, default=str))
    print(f"✅ Parsed data saved to: {data_path}")

    # Print overview
    print("\n📋 Tree Overview:")
    print(get_top_level_summary(tree))


def cmd_query(args):
    """Query an indexed workbook using the reasoning agent."""
    file_path = args.file
    tree_path = Path(file_path).with_suffix(".tree.json")
    data_path = Path(file_path).with_suffix(".parsed.json")

    # Check if index exists
    if not tree_path.exists() or not data_path.exists():
        print("⚠️  No index found. Running indexing first...")
        index_args = argparse.Namespace(file=file_path, with_llm=False)
        cmd_index(index_args)

    print(f"📂 Loading tree index from: {tree_path}")
    tree = json.loads(tree_path.read_text())
    workbook_data = json.loads(data_path.read_text())

    # Import agent here to avoid heavy imports on index-only runs
    from vectorless_qv.agent import VectorlessAgent

    # Build provider kwargs from CLI args
    provider_kwargs = {}
    if hasattr(args, "region") and args.region:
        provider_kwargs["region"] = args.region

    agent = VectorlessAgent(
        tree=tree,
        workbook_data=workbook_data,
        excel_path=file_path,
        provider=getattr(args, "provider", None) or "bedrock",
        model_id=args.model,
        **provider_kwargs,
    )

    if args.question:
        _ask(agent, args.question, verbose=args.verbose)
    else:
        # Interactive mode
        print("\n💬 Interactive mode. Type 'quit' to exit.\n")
        while True:
            try:
                question = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nBye!")
                break
            if not question or question.lower() in ("quit", "exit", "q"):
                print("Bye!")
                break
            _ask(agent, question, verbose=args.verbose)


def cmd_list_providers(args):
    """Show available LLM providers and their suggested models."""
    from vectorless_qv.llm_providers import list_providers, MODEL_SUGGESTIONS

    if args.provider:
        # Show models for a specific provider
        provider = args.provider.lower()
        models = MODEL_SUGGESTIONS.get(provider)
        if not models:
            print(f"Unknown provider '{args.provider}'. Run: vectorless-qv list-providers")
            sys.exit(1)
        from vectorless_qv.llm_providers import DEFAULT_MODELS
        default = DEFAULT_MODELS.get(provider, "—")
        print(f"\n🔌 Provider: {provider}")
        print(f"   Default model: {default}")
        print(f"   Available models:")
        for m in models:
            marker = " ← default" if m == default else ""
            print(f"     • {m}{marker}")
        print(f"\n   Usage: vectorless-qv query -f model.xlsx --provider {provider} --model <model_id>")
    else:
        # Show all providers
        print("\n🔌 Available LLM Providers:\n")
        for info in list_providers():
            n_models = len(info["models"])
            print(f"  {info['name']:12s}  default: {info['default_model']}  ({n_models} models)")
        print(f"\n  Use --provider <name> to see all models for a provider.")
        print(f"  Example: vectorless-qv list-providers --provider openai\n")


def cmd_inspect(args):
    """Inspect the tree index without querying the LLM."""
    file_path = args.file
    tree_path = Path(file_path).with_suffix(".tree.json")

    if not tree_path.exists():
        print("⚠️  No index found. Run: python main.py index --file <your.xlsx>")
        sys.exit(1)

    tree = json.loads(tree_path.read_text())

    if args.node:
        from vectorless_qv.indexer import get_node_detail
        print(get_node_detail(tree, args.node))
    else:
        print(get_top_level_summary(tree))


def _ask(agent, question: str, verbose: bool = False):
    """Ask the agent a question and print the result."""
    print(f"\n🔍 Processing: {question}\n")
    result = agent.query(question)

    print("=" * 60)
    print("📝 Answer:")
    print(result["answer"])

    if result.get("citations"):
        print("\n📎 Citations:")
        for c in result["citations"]:
            parts = [f"  Sheet: {c.get('sheet', '?')}"]
            if c.get("cell"):
                parts.append(f"Cell: {c['cell']}")
            if c.get("formula"):
                parts.append(f"Formula: {c['formula']}")
            print(", ".join(parts))

    if verbose and result.get("reasoning_trace"):
        print("\n🧠 Reasoning Trace:")
        for step in result["reasoning_trace"]:
            print(f"  {step[:200]}...")
    print("=" * 60 + "\n")


def _create_bedrock_summarizer(args):
    """Create a summarizer function backed by the configured LLM provider."""
    from vectorless_qv.llm_providers import create_provider

    provider_name = getattr(args, "provider", None) or "bedrock"
    model_id = getattr(args, "model", None)

    provider_kwargs = {}
    if hasattr(args, "region") and args.region:
        provider_kwargs["region"] = args.region

    llm = create_provider(provider_name, model_id=model_id, **provider_kwargs)

    def summarize(prompt: str) -> str:
        return llm.invoke(
            system="You are a financial analyst. Respond only with the summary.",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200,
        )

    return summarize


def main():
    parser = argparse.ArgumentParser(
        description="Vectorless RAG for Excel Financial Models (PageIndex Architecture)"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # index command
    p_index = sub.add_parser("index", help="Index an Excel workbook into a tree")
    p_index.add_argument("--file", "-f", required=True, help="Path to .xlsx file")
    p_index.add_argument("--with-llm", action="store_true",
                         help="Use LLM to generate node summaries")
    p_index.add_argument("--provider", default=None,
                         help="LLM provider: bedrock, openai, anthropic, google, azure, ollama, groq, together")
    p_index.add_argument("--model", default=None, help="Model ID (provider-specific)")
    p_index.add_argument("--region", default=None, help="AWS region (bedrock/azure only)")

    # query command
    p_query = sub.add_parser("query", help="Query a workbook using the reasoning agent")
    p_query.add_argument("--file", "-f", required=True, help="Path to .xlsx file")
    p_query.add_argument("--question", "-q", default=None, help="Single question (or interactive)")
    p_query.add_argument("--provider", default=None,
                         help="LLM provider: bedrock, openai, anthropic, google, azure, ollama, groq, together")
    p_query.add_argument("--model", default=None, help="Model ID (provider-specific)")
    p_query.add_argument("--region", default=None, help="AWS region (bedrock/azure only)")
    p_query.add_argument("--verbose", "-v", action="store_true", help="Show reasoning trace")

    # inspect command
    p_inspect = sub.add_parser("inspect", help="Inspect the tree index without LLM")
    p_inspect.add_argument("--file", "-f", required=True, help="Path to .xlsx file")
    p_inspect.add_argument("--node", "-n", default=None, help="Node ID to inspect")

    # list-providers command
    p_providers = sub.add_parser("list-providers", help="Show available LLM providers and models")
    p_providers.add_argument("--provider", "-p", default=None,
                             help="Show models for a specific provider")

    args = parser.parse_args()

    if args.command == "index":
        cmd_index(args)
    elif args.command == "query":
        cmd_query(args)
    elif args.command == "inspect":
        cmd_inspect(args)
    elif args.command == "list-providers":
        cmd_list_providers(args)


if __name__ == "__main__":
    main()
