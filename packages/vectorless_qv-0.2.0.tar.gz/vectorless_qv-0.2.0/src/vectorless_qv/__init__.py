"""
Vectorless — Reasoning-based RAG for Excel financial models.

No vector databases. No chunking. Just hierarchical tree indexing
and LLM-driven reasoning, inspired by the PageIndex architecture.

Supports all major LLM providers: Bedrock, OpenAI, Anthropic, Google,
Azure OpenAI, Ollama, Groq, Together AI.
"""

__version__ = "0.2.0"

from vectorless_qv.parser import parse_workbook
from vectorless_qv.indexer import build_tree, tree_to_json, get_top_level_summary
from vectorless_qv.agent import VectorlessAgent, BedrockAgent
from vectorless_qv.engine import ExcelExecutionEngine
from vectorless_qv.llm_providers import create_provider, list_providers, LLMProvider, MODEL_SUGGESTIONS

__all__ = [
    "parse_workbook",
    "build_tree",
    "tree_to_json",
    "get_top_level_summary",
    "VectorlessAgent",
    "BedrockAgent",
    "ExcelExecutionEngine",
    "create_provider",
    "list_providers",
    "LLMProvider",
    "MODEL_SUGGESTIONS",
]
