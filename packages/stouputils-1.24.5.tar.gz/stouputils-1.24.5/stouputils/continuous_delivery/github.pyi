from ..decorators import handle_error as handle_error, measure_time as measure_time
from ..print.message import info as info, progress as progress
from .cd_utils import handle_response as handle_response
from .release_common import PlatformConfig as PlatformConfig, create_release as create_release, delete_resource_unconditional as delete_resource_unconditional, generate_changelog as generate_changelog, get_commits_since_tag as get_commits_since_tag, get_latest_tag as get_latest_tag, handle_existing_tag as handle_existing_tag, log_success as log_success, upload_files as upload_files, validate_required_keys as validate_required_keys
from typing import Any

GITHUB_API_URL: str

def validate_github_credentials(credentials: dict[str, dict[str, str]]) -> tuple[str, dict[str, str]]:
    """ Get and validate GitHub credentials.

\tArgs:
\t\tcredentials: Credentials dictionary with 'github' key containing 'api_key' and 'username'
\tReturns:
\t\ttuple: (owner username, headers dict)
\tRaises:
\t\tValueError: If required keys are missing
\t"""
def validate_github_config(github_config: dict[str, Any]) -> tuple[str, str, str, list[str]]:
    """ Validate GitHub configuration.

\tArgs:
\t\tgithub_config: Configuration dictionary
\tReturns:
\t\ttuple: (project_name, version, build_folder, endswith list)
\tRaises:
\t\tValueError: If required keys are missing
\t"""
def build_github_config(owner: str, headers: dict[str, str], project_name: str, version: str, build_folder: str, endswith: list[str], api_url: str) -> PlatformConfig:
    """ Build a PlatformConfig for GitHub.

\tArgs:
\t\towner:        GitHub username
\t\theaders:      HTTP headers with authorization
\t\tproject_name: Name of the repository
\t\tversion:      Version to release
\t\tbuild_folder: Path to build assets
\t\tendswith:     File suffixes to upload
\t\tapi_url:      GitHub API URL
\tReturns:
\t\tPlatformConfig: Configuration for GitHub release
\t"""
def delete_github_release(config: PlatformConfig) -> None:
    """ Delete existing GitHub release for the configured version. """
def delete_github_tag(config: PlatformConfig) -> None:
    """ Delete existing GitHub tag for the configured version. """
def get_github_sha(tag: dict[str, Any]) -> str:
    """ Extract SHA from a GitHub tag response. """
def get_github_commit_date(commit: dict[str, Any]) -> str:
    """ Extract date from a GitHub commit response. """
def extract_github_commit_data(commits: list[dict[str, Any]]) -> list[tuple[str, str]]:
    """ Extract (sha, message) tuples from GitHub commits. """
def create_github_tag(config: PlatformConfig) -> None:
    """ Create a new tag on GitHub. """
def create_github_release(config: PlatformConfig, changelog: str) -> int:
    """ Create a new GitHub release and return its ID.

\tArgs:
\t\tconfig:    Platform configuration
\t\tchangelog: Changelog text for the release body
\tReturns:
\t\tint: Release ID for asset uploads
\t"""
def upload_github_assets(config: PlatformConfig, release_id: int) -> None:
    """ Upload release assets to GitHub.

\tArgs:
\t\tconfig:     Platform configuration
\t\trelease_id: ID of the release to upload assets to
\t"""
@handle_error
def upload_to_github(credentials: dict[str, Any], github_config: dict[str, Any], api_url: str = ...) -> str:
    ''' Upload the project to GitHub using the credentials and the configuration.

\tArgs:
\t\tcredentials:   Credentials for the GitHub API
\t\tgithub_config: Configuration for the GitHub project
\t\tapi_url:       GitHub API URL (default: https://api.github.com)
\tReturns:
\t\tstr: Generated changelog text
\tExamples:

\t.. code-block:: python

\t\t> upload_to_github(
\t\t\tcredentials={
\t\t\t\t"github": {
\t\t\t\t\t"api_key": "ghp_...",
\t\t\t\t\t"username": "Stoupy"
\t\t\t\t}
\t\t\t},
\t\t\tgithub_config={
\t\t\t\t"project_name": "stouputils",
\t\t\t\t"version": "1.0.0",
\t\t\t\t"build_folder": "build",
\t\t\t\t"endswith": [".zip"]
\t\t\t}
\t\t)
\t'''
