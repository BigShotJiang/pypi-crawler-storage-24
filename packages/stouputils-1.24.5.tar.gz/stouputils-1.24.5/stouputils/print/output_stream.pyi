from .utils import remove_colors as remove_colors
from typing import Any, IO

class TeeMultiOutput:
    ''' File-like object that duplicates output to multiple file-like objects.

\tArgs:
\t\t*files         (IO[Any]):  One or more file-like objects that have write and flush methods
\t\tstrip_colors   (bool):     Strip ANSI color codes from output sent to non-stdout/stderr files
\t\tascii_only     (bool):     Replace non-ASCII characters with their ASCII equivalents for non-stdout/stderr files
\t\tignore_lineup  (bool):     Ignore lines containing LINE_UP escape sequence in non-terminal outputs

\tExamples:
\t\t>>> import sys
\t\t>>> f = open("logfile.txt", "w")
\t\t>>> sys.stdout = TeeMultiOutput(sys.stdout, f)
\t\t>>> print("Hello World")  # Output goes to both console and file
\t\tHello World
\t\t>>> f.close()\t# TeeMultiOutput will handle any future writes to closed files gracefully
\t'''
    files: tuple[IO[Any], ...]
    strip_colors: bool
    ascii_only: bool
    ignore_lineup: bool
    def __init__(self, *files: IO[Any], strip_colors: bool = True, ascii_only: bool = True, ignore_lineup: bool = True) -> None: ...
    @property
    def encoding(self) -> str:
        ''' Get the encoding of the first file, or "utf-8" as fallback.

\t\tReturns:
\t\t\tstr: The encoding, ex: "utf-8", "ascii", "latin1", etc.
\t\t'''
    def write(self, obj: str) -> int:
        """ Write the object to all files while stripping colors if needed.

\t\tArgs:
\t\t\tobj (str): String to write
\t\tReturns:
\t\t\tint: Number of characters written to the first file
\t\t"""
    def flush(self) -> None:
        """ Flush all files. """
    def fileno(self) -> int:
        """ Return the file descriptor of the first file. """
