from .common import PrintMemory as PrintMemory
from typing import Any

def remove_colors(text: str) -> str:
    """ Remove the colors from a text """
def is_same_print(*args: Any, **kwargs: Any) -> bool:
    """ Checks if the current print call is the same as the previous one. """
def current_time() -> str:
    ''' Get the current time as "HH:MM:SS" if less than 24 hours since import, else "YYYY-MM-DD HH:MM:SS" '''
