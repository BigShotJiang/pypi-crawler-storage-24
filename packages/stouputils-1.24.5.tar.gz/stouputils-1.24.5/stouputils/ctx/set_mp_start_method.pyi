from .common import AbstractBothContextManager as AbstractBothContextManager
from typing import Any

class SetMPStartMethod(AbstractBothContextManager['SetMPStartMethod']):
    ''' Context manager to temporarily set multiprocessing start method.

\tThis context manager allows you to temporarily change the multiprocessing start method
\tand automatically restores the original method when exiting the context.

\tArgs:
\t\tstart_method (str): The start method to use: "spawn", "fork", or "forkserver"

\tExamples:
\t\t.. code-block:: python

\t\t\t> import multiprocessing as mp
\t\t\t> import stouputils as stp
\t\t\t> # Temporarily use spawn method
\t\t\t> with stp.SetMPStartMethod("spawn"):
\t\t\t> ...     # Your multiprocessing code here
\t\t\t> ...     pass

\t\t\t> # Original method is automatically restored
\t'''
    start_method: str | None
    old_method: str | None
    def __init__(self, start_method: str | None) -> None: ...
    def __enter__(self) -> SetMPStartMethod:
        """ Enter context manager which sets the start method """
    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """ Exit context manager which restores the original start method """
    async def __aenter__(self) -> SetMPStartMethod:
        """ Enter async context manager which sets the start method """
    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """ Exit async context manager which restores the original start method """
