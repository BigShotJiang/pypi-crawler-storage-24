import zipfile
from ..print.message import warning as warning

def get_file_hash(file_path: str) -> str | None:
    """ Computes the SHA-256 hash of a file.

\tArgs:
\t\tfile_path (str): Path to the file
\tReturns:
\t\tstr | None: SHA-256 hash as a hexadecimal string or None if an error occurs
\t"""
def extract_hash_from_zipinfo(zip_info: zipfile.ZipInfo) -> str | None:
    """ Extracts the stored hash from a ZipInfo object's comment.

\tArgs:
\t\tzip_info (zipfile.ZipInfo): The ZipInfo object representing a file in the ZIP
\tReturns:
\t\tstr | None: The stored hash if available, otherwise None
\t"""
