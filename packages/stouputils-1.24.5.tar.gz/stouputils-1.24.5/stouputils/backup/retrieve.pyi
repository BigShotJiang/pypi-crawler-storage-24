from ..decorators import measure_time as measure_time
from ..io.path import clean_path as clean_path
from ..print.message import warning as warning
from .hash import extract_hash_from_zipinfo as extract_hash_from_zipinfo

def get_all_previous_backups(backup_folder: str, all_before: str | None = None) -> dict[str, dict[str, str]]:
    ''' Retrieves all previous backups in a folder and maps each backup to a dictionary of file paths and their hashes.

\tArgs:
\t\tbackup_folder (str): The folder containing previous backup zip files
\t\tall_before (str | None): Path to the latest backup ZIP file
\t\t\t(If endswith "/latest.zip" or "/", the latest backup will be used)
\tReturns:
\t\tdict[str, dict[str, str]]: Dictionary mapping backup file paths to dictionaries of {file_path: file_hash}
\t'''
def is_file_in_any_previous_backup(file_path: str, file_hash: str, previous_backups: dict[str, dict[str, str]]) -> bool:
    """ Checks if a file with the same hash exists in any previous backup.

\tArgs:
\t\tfile_path (str): The relative path of the file
\t\tfile_hash (str): The SHA-256 hash of the file
\t\tprevious_backups (dict[str, dict[str, str]]): Dictionary mapping backup zip paths to their stored file hashes
\tReturns:
\t\tbool: True if the file exists unchanged in any previous backup, False otherwise
\t"""
