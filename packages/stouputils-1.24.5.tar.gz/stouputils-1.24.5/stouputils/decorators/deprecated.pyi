from ..print.message import error as error, warning as warning
from .common import get_function_name as get_function_name, get_wrapper_name as get_wrapper_name, set_wrapper_name as set_wrapper_name
from .handle_error import LogLevels as LogLevels
from collections.abc import Callable as Callable
from typing import overload

@overload
def deprecated[T](func: Callable[..., T], *, message: str = '', version: str = '', error_log: LogLevels = ...) -> Callable[..., T]: ...
@overload
def deprecated[T](func: None = None, *, message: str = '', version: str = '', error_log: LogLevels = ...) -> Callable[[Callable[..., T]], Callable[..., T]]: ...
