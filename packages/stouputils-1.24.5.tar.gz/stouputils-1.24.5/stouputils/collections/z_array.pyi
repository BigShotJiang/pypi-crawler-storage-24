import zarr
from numpy.typing import NDArray as NDArray
from typing import Any

def array_to_disk(data: NDArray[Any] | zarr.Array[Any], delete_input: bool = True, more_data: NDArray[Any] | zarr.Array[Any] | None = None) -> tuple['zarr.Array[Any]', str, int]:
    """ Easily handle large numpy arrays on disk using zarr for efficient storage and access.

\tZarr provides a simpler and more efficient alternative to np.memmap with better compression
\tand chunking capabilities.

\tArgs:
\t\tdata\t\t\t(NDArray | zarr.Array):\tThe data to save/load as a zarr array
\t\tdelete_input\t(bool):\tWhether to delete the input data after creating the zarr array
\t\tmore_data\t\t(NDArray | zarr.Array | None): Additional data to append to the zarr array
\tReturns:
\t\ttuple[zarr.Array, str, int]: The zarr array, the directory path, and the total size in bytes

\tExamples:
\t\t>>> import numpy as np
\t\t>>> data = np.random.rand(1000, 1000)
\t\t>>> zarr_array = array_to_disk(data)[0]
\t\t>>> zarr_array.shape
\t\t(1000, 1000)

\t\t>>> more_data = np.random.rand(500, 1000)
\t\t>>> longer_array, dir_path, total_size = array_to_disk(zarr_array, more_data=more_data)
\t"""
