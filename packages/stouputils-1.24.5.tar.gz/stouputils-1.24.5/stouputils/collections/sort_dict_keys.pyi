from typing import Any

def sort_dict_keys[T](dictionary: dict[T, Any], order: list[T], reverse: bool = False) -> dict[T, Any]:
    ''' Sort dictionary keys using a given order list (reverse optional)

\tArgs:
\t\tdictionary\t(dict[T, Any]):\tThe dictionary to sort
\t\torder\t\t(list[T]):\t\tThe order list
\t\treverse\t\t(bool):\t\t\tWhether to sort in reverse order (given to sorted function which behaves differently than order.reverse())
\tReturns:
\t\tdict[T, Any]: The sorted dictionary

\tExamples:
\t\t>>> sort_dict_keys({\'b\': 2, \'a\': 1, \'c\': 3}, order=["a", "b", "c"])
\t\t{\'a\': 1, \'b\': 2, \'c\': 3}

\t\t>>> sort_dict_keys({\'b\': 2, \'a\': 1, \'c\': 3}, order=["a", "b", "c"], reverse=True)
\t\t{\'c\': 3, \'b\': 2, \'a\': 1}

\t\t>>> sort_dict_keys({\'b\': 2, \'a\': 1, \'c\': 3, \'d\': 4}, order=["c", "b"])
\t\t{\'c\': 3, \'b\': 2, \'a\': 1, \'d\': 4}
\t'''
