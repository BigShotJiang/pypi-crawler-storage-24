from .path import super_open as super_open
from typing import Any, IO

def json_dump(data: Any, file: IO[Any] | str | None = None, max_level: int | None = 2, indent: str | int = '\t', suffix: str = '\n', ensure_ascii: bool = False) -> str:
    ''' Writes the provided data to a JSON file with a specified indentation depth.
\tFor instance, setting max_level to 2 will limit the indentation to 2 levels.

\tArgs:
\t\tdata\t\t(Any): \t\t\t\tThe data to dump (usually a dict or a list)
\t\tfile\t\t(IO[Any] | str): \tThe file object or path to dump the data to
\t\tmax_level\t(int | None):\t\tThe depth of indentation to stop at (-1 for infinite), None will default to 2
\t\tindent\t\t(str | int):\t\tThe indentation character (default: \'\\t\')
\t\tsuffix\t\t(str):\t\t\t\tThe suffix to add at the end of the string (default: \'\\n\')
\t\tensure_ascii (bool):\t\t\tWhether to escape non-ASCII characters (default: False)
\tReturns:
\t\tstr: The content of the file in every case

\t>>> json_dump({"a": [[1,2,3]], "b": 2}, max_level = 0)
\t\'{"a": [[1,2,3]],"b": 2}\\n\'
\t>>> json_dump({"a": [[1,2,3]], "b": 2}, max_level = 1)
\t\'{\\n\\t"a": [[1,2,3]],\\n\\t"b": 2\\n}\\n\'
\t>>> json_dump({"a": [[1,2,3]], "b": 2}, max_level = 2)
\t\'{\\n\\t"a": [\\n\\t\\t[1,2,3]\\n\\t],\\n\\t"b": 2\\n}\\n\'
\t>>> json_dump({"a": [[1,2,3]], "b": 2}, max_level = 3)
\t\'{\\n\\t"a": [\\n\\t\\t[\\n\\t\\t\\t1,\\n\\t\\t\\t2,\\n\\t\\t\\t3\\n\\t\\t]\\n\\t],\\n\\t"b": 2\\n}\\n\'
\t>>> json_dump({"éà": "üñ"}, ensure_ascii = True, max_level = 0)
\t\'{"\\\\u00e9\\\\u00e0": "\\\\u00fc\\\\u00f1"}\\n\'
\t>>> json_dump({"éà": "üñ"}, ensure_ascii = False, max_level = 0)
\t\'{"éà": "üñ"}\\n\'
\t'''
def json_load(file_path: str) -> Any:
    """ Load a JSON file from the given path

\tArgs:
\t\tfile_path (str): The path to the JSON file
\tReturns:
\t\tAny: The content of the JSON file
\t"""
