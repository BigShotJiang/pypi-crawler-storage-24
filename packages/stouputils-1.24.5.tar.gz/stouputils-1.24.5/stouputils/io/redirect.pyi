from .path import clean_path as clean_path

def is_junction(path: str) -> bool:
    """ Check if a path is a junction point (Windows) or a symlink (any OS).

\tArgs:
\t\tpath (str): The path to check
\tReturns:
\t\tbool: True if the path is a junction or symlink
\t"""
def create_junction(source: str, target: str) -> None:
    """ Create a directory junction on Windows pointing source -> target.
\tUses 'mklink /J' command.

\tArgs:
\t\tsource (str): The junction path to create (with forward slashes, will be converted)
\t\ttarget (str): The target directory the junction points to
\t"""
def create_bind_mount(source: str, target: str) -> None:
    """ Create a bind mount on Linux pointing source -> target.
\tUses ``mount --bind`` command (requires root/sudo).

\tNote:
\t\tBind mounts do **not** persist across reboots unless an entry is added to ``/etc/fstab``.
\t\tTo make it persistent, add this line to ``/etc/fstab``::

\t\t\t/absolute/path/to/target /absolute/path/to/source none bind 0 0

\tArgs:
\t\tsource (str): The mount point path to create (must exist as an empty directory)
\t\ttarget (str): The target directory to bind
\tRaises:
\t\t:py:exc:`OSError`: If the bind mount command fails
\t"""
def copytree_with_progress(source: str, destination: str, desc: str = 'Copying') -> str:
    ''' Copy a directory tree from source to destination with a colored progress bar.

\tUses :func:`~stouputils.print.progress_bar.colored_for_loop` to display progress while copying each file.
\tDirectory structure is created automatically. Existing files at the destination are overwritten.

\tArgs:
\t\tsource\t\t(str):\tPath to the source directory to copy
\t\tdestination\t(str):\tPath to the destination directory
\t\tdesc\t\t(str):\tDescription for the progress bar (default: ``"Copying"``)
\tReturns:
\t\tstr:\tThe destination path
\tRaises:
\t\t:py:exc:`NotADirectoryError`: If source is not a directory

\tExamples:

\t\t.. code-block:: python

\t\t\t> copytree_with_progress("C:/Games/MyGame", "D:/Backup/MyGame")
\t\t\t# Copying: 100%|██████████████████| 150/150 [00:05<00:00, 30.00it/s]
\t\t\t\'D:/Backup/MyGame\'
\t'''
def redirect_folder(source: str, destination: str, link_type: str | None = None) -> str:
    ''' Move a folder from source to destination and create a link at the original source location.

\tIf the source is already a symlink or junction, the operation is skipped.
\tIf the destination path ends with ``/``, the source folder\'s basename is appended automatically.

\tLink types:
\t\t- ``"junction"`` (or ``"hardlink"``): Uses an NTFS junction on Windows,
\t\t\tor a bind mount (``mount --bind``, requires sudo) on Linux.
\t\t\tFalls back to symlink if junction/bind mount creation fails.
\t\t- ``"symlink"``: Uses a symbolic link (may require elevated privileges on Windows).
\t\t- ``None``: Prompts the user interactively.

\tArgs:
\t\tsource\t\t(str):\t\t\t\tPath to the existing folder to redirect
\t\tdestination\t(str):\t\t\t\tPath where the folder contents will be moved to
\t\tlink_type\t(str | None):\t\t``"hardlink"``/``"junction"``, ``"symlink"``, or None to ask
\tReturns:
\t\tstr:\tThe final destination path

\tExamples:

\t\t.. code-block:: python

\t\t\t> redirect_folder("C:/Games/MyGame", "D:/Games/")
\t\t\t# Moves C:/Games/MyGame -> D:/Games/MyGame and creates a link at C:/Games/MyGame

\t\t\t> redirect_folder("C:/Games/MyGame", "D:/Storage/MyGame")
\t\t\t# Moves C:/Games/MyGame -> D:/Storage/MyGame and creates a link at C:/Games/MyGame
\t'''
def redirect_cli() -> None:
    """ CLI entry point for the redirect command.
\tUsage: stouputils redirect <source> <destination> [--hardlink|--symlink]
\t"""
