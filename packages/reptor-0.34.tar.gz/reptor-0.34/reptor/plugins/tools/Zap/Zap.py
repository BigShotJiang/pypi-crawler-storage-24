from reptor.lib.plugins.ToolBase import ToolBase
from reptor.models.Note import NoteTemplate


class Zap(ToolBase):
    """
    Parses ZAP generated reports in either XML or JSON

    Make sure you verify what type of findings you export.

    Recommended settings are to only export Medium and higher findings
    """

    meta = {
        "author": "Richard Schwabe",
        "name": "Zap",
        "version": "1.0",
        "license": "MIT",
        "tags": ["web", "zap"],
        "summary": "Parses ZAP reports (JSON, XML)",
    }
    risk_mapping = {
        "3": "🔴",
        "2": "🟠",
        "1": "🟡",
        "0": "🔵",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.notetitle = kwargs.get("notetitle") or "Zap"
        self.note_icon = "🌩️"
        if self.input:
            file_extension_count = dict()
            for file_extension in [s.split(".")[-1] for s in self.input]:
                if file_extension in ["json", "xml"]:
                    file_extension_count.setdefault(file_extension, 0)
                    file_extension_count[file_extension] += 1
            if file_extension_count:
                self.input_format = max(file_extension_count.items(), key=lambda x: x[1])[0]
        elif self.input_format == "raw":
            # Use json as default input format
            self.input_format = "json"

    def _parse_alert_data(self, data):
        return {
            "pluginid": data.find("pluginid").text,
            "alertRef": data.find("alertRef").text,
            "name": data.find("name").text,
            "riskcode": data.find("riskcode").text,
            "confidence": data.find("confidence").text,
            "riskdesc": data.find("riskdesc").text,
            "confidencedesc": data.find("confidencedesc").text,
            "desc": data.find("desc").text,
            "count": data.find("count").text,
            "solution": data.find("solution").text,
            "reference": data.find("reference").text,
            "cweid": data.find("cweid").text,
            "wascid": data.find("wascid").text,
            "sourceid": data.find("sourceid").text,
            "instances": [],
        }

    def _parse_instance_data(self, data):
        result = {
            "uri": data.find("uri").text,
            "method": data.find("method").text,
            "param": data.find("param").text,
            "attack": data.find("attack").text,
            "evidence": data.find("evidence").text,
            "otherinfo": data.find("otherinfo").text,
        }
        if data.find("requestheader") is not None:
            result["requestheader"] = (data.find("requestheader").text,)
        if data.find("requestbody") is not None:
            result["requestbody"] = (data.find("requestbody").text,)
        if data.find("responseheader") is not None:
            result["responseheader"] = (data.find("responseheader").text,)
        return result

    def parse_xml(self):
        super().parse_xml(as_dict=False)
        return_data = list()
        for scan in self.xml_root:
            site = scan.attrib
            site["alerts"] = []

            for alert_item in scan[0]:
                alert = self._parse_alert_data(alert_item)

                for instance_item in alert_item.findall("./instances/instance"):
                    instance = self._parse_instance_data(instance_item)
                    alert["instances"].append(instance)

                site["alerts"].append(alert)

            return_data.append(site)

        self.parsed_input = return_data

    def parse_json(self):
        super().parse_json()
        parsed_input = list()
        for site in self.parsed_input.get("site", []):
            for attr in list(site.keys()):
                site[attr.strip("@")] = site.pop(attr)
            parsed_input.append(site)
        self.parsed_input = parsed_input

    def create_notes(self):
        data = dict()
        # Group by URL
        data = dict()
        for site in self.parsed_input:
            data[site["name"]] = [site]
        data = dict(
            sorted(data.items(), key=lambda x: len(x[1][0]["alerts"]), reverse=True)
        )

        # Create note structure
        ## Main note
        main_note = NoteTemplate()
        main_note.title = self.notetitle
        main_note.icon_emoji = self.note_icon

        ## Subnotes per site
        for url, site in data.items():
            site_note = NoteTemplate()
            site_note.title = f"{url} ({len(site[0]['alerts'])})"
            site_note.checked = False
            site_note.template = "site"
            site_note.template_data = site[0]
            # Subnotes per alert
            for alert in site[0]["alerts"]:
                alert_note = NoteTemplate()
                alert_note.title = (
                    f"{self.risk_mapping[alert['riskcode']]} {alert['name']}"
                )
                alert_note.checked = False
                alert_note.template = "alert"
                alert_note.template_data = alert
                site_note.children.append(alert_note)
            main_note.children.append(site_note)
        return main_note

    def preprocess_for_template(self) -> list:
        """Aggregate findings by alert for template generation"""
        alerts_dict = dict()
        
        for site in self.parsed_input:
            for alert in site.get("alerts", []):
                alert_key = alert.get("alertRef", alert.get("pluginid"))
                
                if alert_key not in alerts_dict:
                    alerts_dict[alert_key] = {
                        "name": alert.get("name", ""),
                        "description": alert.get("desc", ""),
                        "solution": alert.get("solution", ""),
                        "riskcode": alert.get("riskcode", "0"),
                        "confidence": alert.get("confidence", ""),
                        "cweid": alert.get("cweid", ""),
                        "wascid": alert.get("wascid", ""),
                        "reference": alert.get("reference", ""),
                        "alertRef": alert.get("alertRef", ""),
                        "pluginid": alert.get("pluginid", ""),
                        "affected_components": [],
                        "instances": [],
                        "finding_templates": alert_key,
                    }
                
                for instance in alert.get("instances", []):
                    uri = instance.get("uri", "")
                    if uri and uri not in alerts_dict[alert_key]["affected_components"]:
                        alerts_dict[alert_key]["affected_components"].append(uri)
                    alerts_dict[alert_key]["instances"].append(instance)
        
        findings = []
        risk_mapping = {
            "3": "critical",
            "2": "high",
            "1": "medium",
            "0": "low",
        }
        
        for alert in alerts_dict.values():
            riskcode = alert.get("riskcode", "0")
            alert["severity"] = risk_mapping.get(riskcode, "low")
            alert["risk_factor"] = alert["severity"]
            alert["affected_components"] = sorted(set(alert["affected_components"]))
            alert["cvss"] = "n/a"
            findings.append(alert)
        
        findings.sort(
            key=lambda x: (
                -int(x.get("riskcode", "0")),
                x.get("name", "")
            )
        )
        
        return findings

    def finding_global(self):
        """Return all findings for push-findings feature"""
        return self.preprocess_for_template()


loader = Zap