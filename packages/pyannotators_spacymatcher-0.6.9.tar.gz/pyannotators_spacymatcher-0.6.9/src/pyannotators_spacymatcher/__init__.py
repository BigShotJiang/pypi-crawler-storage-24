"""SpacyMatcher annotator using the spacy rule-matching engine"""

__version__ = "0.6.9"
