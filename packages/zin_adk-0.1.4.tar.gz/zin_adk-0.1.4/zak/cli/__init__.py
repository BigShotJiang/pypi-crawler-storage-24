"""ZAK CLI package."""
