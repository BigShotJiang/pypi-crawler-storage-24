"""ZAK tenants package."""
