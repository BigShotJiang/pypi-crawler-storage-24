import os
from typing_extensions import deprecated

from .api_client import APIClientBase, InvalidInputException


class Node(APIClientBase):
    def __init__(self, url_base=None, custom_retry_config=None, **kwargs):
        super().__init__(url_base or os.environ.get("NODE_SERVICE", ""), **kwargs)
        self._custom_retry_config = custom_retry_config

    @property
    def _retry_config(self):
        return self._custom_retry_config or super()._retry_config

    def get_installed_version(self):
        return self.get_request("/software/installed")

    def get_available_upgrade_versions(self):
        return self.get_request("/software/available")

    def check_available_updates(self):
        return self.post_request("/software/available")

    def get_update_job(self):
        return self.get_request("/software/update")

    def get_sentry_dsn(self):
        return self.get_request("/sentry/dsn")

    def get_system_information(self):
        return self.get_request("/system")

    def get_basic_system_information(self):
        return self.get_request("/system/basic-info")

    def start_update_job(
        self,
        upgrade_branch: str,
        upgrade_channel: str,
        enable_hotfix_channels: bool = False,
        enable_dev_channels: bool = False,
    ):
        body = {
            "upgradeBranch": upgrade_branch,
            "upgradeChannel": upgrade_channel,
            "enableHotfixChannels": enable_hotfix_channels,
            "enableDevChannels": enable_dev_channels,
        }
        return self.post_request("/software/update", body=body)

    def update_job_acknowledge(self):
        return self.put_request("/software/update/acknowledge")

    def get_system_details(self):
        return self.get_request("/system")

    def get_system_health(self):
        return self.get_request("/health")

    def get_time(self):
        return self.get_request("/time")

    def set_time(self, date: str, timezone: str, require_reboot: bool, ntp: dict):
        body = {
            "date": date,
            "timezone": timezone,
            "requireReboot": require_reboot,
            "ntp": ntp,
        }
        return self.post_request("/time", body=body)

    def get_available_timezones(self):
        return self.get_request("/time/timezones")

    def sync_clock_with_ntp(self, require_reboot: bool = False):
        body = {
            "requireReboot": require_reboot,
        }
        return self.put_request("/time/ntp/sync-clock", body=body)

    def reboot_host(self):
        return self.put_request("/system/reboot")

    def poweroff_host(self):
        return self.put_request("/system/poweroff")

    def add_user_event(self, _type: str, client_time: str, order: int, properties: dict):
        body = {
            "type": _type,
            "clientTime": client_time,
            "order": order,
            "properties": properties,
        }
        return self.post_request("/bond/user-events", body=body)

    @deprecated("This is deprecated, use Node().get_network_interfaces() instead")
    def get_interfaces(self):
        return self.get_network_interfaces()

    def get_network_interfaces(self):
        return self.get_request("/network/interfaces")

    def get_hypervisor_information(self):
        return self.get_request("/hypervisor")

    def get_hypervisor_devices(self):
        return self.get_request("/hypervisor/devices")

    def get_hypervisor_cpu_models(self):
        return self.get_request("/hypervisor/cpu-models")

    def get_hypervisor_autostart_config(self):
        return self.get_request("/hypervisor/autostart")

    def put_hypervisor_autostart_config(self, content: dict):
        return self.put_request("/hypervisor/autostart", body={"content": content})

    def get_vnc_token(self, virtual_machine_port: int):
        return self.get_request(
            "/hypervisor/vncTokens",
            query_args={"virtualMachinePort": virtual_machine_port},
        )

    def create_vnc_token(self, virtual_machine_port: int):
        return self.post_request(
            "/hypervisor/vncTokens",
            query_args={"virtualMachinePort": virtual_machine_port},
        )

    def get_pci_devices(self, device_class: str = None, available: bool = False):
        """List PCI devices available for passthrough."""
        query_args = {}
        if device_class:
            query_args["class"] = device_class
        if available:
            query_args["available"] = "true"
        return self.get_request("/hypervisor/pci-devices", query_args=query_args or None)

    def get_pci_device_iommu_group(self, device_id: str):
        """Get IOMMU group details for a PCI device."""
        if not device_id:
            raise InvalidInputException(f"Expected a valid device id, received: `{device_id}`")
        return self.get_request(f"/hypervisor/pci-devices/{device_id}/iommu-group")

    def prepare_pci_passthrough(
        self, enable_iommu: bool = True, load_vfio_modules: bool = True, install_nvidia_blacklist: bool = True
    ):
        """Apply host-level changes for PCI passthrough."""
        body = {
            "enable_iommu": enable_iommu,
            "load_vfio_modules": load_vfio_modules,
            "install_nvidia_blacklist": install_nvidia_blacklist,
        }
        return self.post_request("/hypervisor/pci-passthrough/prepare", body=body)

    def get_pci_passthrough_reboot_required(self):
        """Check whether a host reboot is required for PCI passthrough changes."""
        return self.get_request("/hypervisor/pci-passthrough/reboot-required")

    def claim_pci_reservation(self, vm_id: str, vm_name: str, iommu_group: int, device_ids: list):
        """Claim a host-local reservation for a PCI device set."""
        if not vm_id:
            raise InvalidInputException(f"Expected a valid vm id, received: `{vm_id}`")
        if not vm_name:
            raise InvalidInputException(f"Expected a valid vm name, received: `{vm_name}`")
        body = {
            "vm_id": vm_id,
            "vm_name": vm_name,
            "iommu_group": iommu_group,
            "device_ids": device_ids,
        }
        return self.post_request("/hypervisor/pci-devices/reservations/claim", body=body)

    def release_pci_reservation(self, vm_id: str, device_ids: list = None):
        """Release a host-local reservation for a VM's PCI device set. Idempotent."""
        if not vm_id:
            raise InvalidInputException(f"Expected a valid vm id, received: `{vm_id}`")
        body = {"vm_id": vm_id}
        if device_ids:
            body["device_ids"] = device_ids
        return self.post_request("/hypervisor/pci-devices/reservations/release", body=body)

    def reassign_pci_reservation(self, old_vm_id: str, new_vm_id: str, new_vm_name: str):
        """Atomically reassign a PCI reservation from one VM ID to another."""
        if not old_vm_id:
            raise InvalidInputException(f"Expected a valid old vm id, received: `{old_vm_id}`")
        if not new_vm_id:
            raise InvalidInputException(f"Expected a valid new vm id, received: `{new_vm_id}`")
        body = {
            "old_vm_id": old_vm_id,
            "new_vm_id": new_vm_id,
            "new_vm_name": new_vm_name,
        }
        return self.post_request("/hypervisor/pci-devices/reservations/reassign", body=body)

    def get_pci_reservations(self):
        """List all current PCI device reservations."""
        return self.get_request("/hypervisor/pci-devices/reservations")
