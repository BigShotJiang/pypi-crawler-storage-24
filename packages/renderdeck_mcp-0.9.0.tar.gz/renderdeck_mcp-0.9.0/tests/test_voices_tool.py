"""Unit tests for renderdeck_mcp.tools.voices and renderdeck_mcp.voices."""

from __future__ import annotations

# ---------------------------------------------------------------------------
# TC-01: list_voices returns all voices with correct structure
# ---------------------------------------------------------------------------


def test_tc01_list_voices_returns_all_voices() -> None:
    """run_list_voices returns a list of all 60 voices with correct fields."""
    from renderdeck_mcp.tools.voices import run_list_voices

    result = run_list_voices()
    assert "voices" in result
    voices = result["voices"]
    assert isinstance(voices, list)
    assert result["total_count"] == len(voices)
    assert len(voices) == 71

    # Check structure of each voice entry
    for v in voices:
        assert "alias" in v
        assert "full_name" in v
        assert "locale" in v
        assert "gender" in v
        assert v["gender"] in ("Male", "Female")
        assert v["locale"].startswith(("en-", "fr-", "vi-"))


# ---------------------------------------------------------------------------
# TC-02: list_voices includes default voice info
# ---------------------------------------------------------------------------


def test_tc02_list_voices_includes_default() -> None:
    """Result includes default voice info and usage hint."""
    from renderdeck_mcp.tools.voices import run_list_voices

    result = run_list_voices()
    assert "default_voice" in result
    assert "aria" in str(result["default_voice"])
    assert "usage_hint" in result
    assert "samples_hint" in result


# ---------------------------------------------------------------------------
# TC-03: resolve_voice resolves aliases
# ---------------------------------------------------------------------------


def test_tc03_resolve_voice_aliases() -> None:
    """resolve_voice maps short aliases to full edge-tts names."""
    from renderdeck_mcp.voices import resolve_voice

    assert resolve_voice("aria") == "en-US-AriaNeural"
    assert resolve_voice("roger") == "en-US-RogerNeural"
    assert resolve_voice("sonia") == "en-GB-SoniaNeural"
    assert resolve_voice("ARIA") == "en-US-AriaNeural"  # case-insensitive


# ---------------------------------------------------------------------------
# TC-04: resolve_voice passes through full names
# ---------------------------------------------------------------------------


def test_tc04_resolve_voice_passthrough() -> None:
    """Unknown aliases are treated as full voice names and passed through."""
    from renderdeck_mcp.voices import resolve_voice

    assert resolve_voice("en-US-AriaNeural") == "en-US-AriaNeural"
    assert resolve_voice("custom-voice") == "custom-voice"


# ---------------------------------------------------------------------------
# TC-05: DEFAULT_VOICES has expected structure
# ---------------------------------------------------------------------------


def test_tc05_default_voices_structure() -> None:
    """DEFAULT_VOICES dict has correct structure for all entries."""
    from renderdeck_mcp.voices import DEFAULT_VOICES

    assert len(DEFAULT_VOICES) == 71
    for alias, info in DEFAULT_VOICES.items():
        assert isinstance(alias, str)
        assert alias == alias.lower(), f"Alias {alias!r} should be lowercase"
        assert "full_name" in info
        assert "locale" in info
        assert "gender" in info
        assert info["full_name"].endswith("Neural")


# ---------------------------------------------------------------------------
# TC-06: Multiple locales are included
# ---------------------------------------------------------------------------


def test_tc06_multiple_locales_included() -> None:
    """Voices span at least 18 locales (14 English + 3 French + 1 Vietnamese)."""
    from renderdeck_mcp.voices import DEFAULT_VOICES

    locales = {v["locale"] for v in DEFAULT_VOICES.values()}
    assert len(locales) >= 18
    for expected in (
        "en-US",
        "en-GB",
        "en-AU",
        "en-CA",
        "en-IN",
        "en-ZA",
        "fr-FR",
        "fr-BE",
        "fr-CA",
        "vi-VN",
    ):
        assert expected in locales, f"Missing locale {expected}"


# ---------------------------------------------------------------------------
# TC-07: Voices are sorted in list_voices output
# ---------------------------------------------------------------------------


def test_tc07_voices_sorted_alphabetically() -> None:
    """Voices in list_voices output are sorted by alias."""
    from renderdeck_mcp.tools.voices import run_list_voices

    result = run_list_voices()
    aliases = [v["alias"] for v in result["voices"]]
    assert aliases == sorted(aliases)


# ---------------------------------------------------------------------------
# TC-08: server.py list_voices wrapper calls implementation
# ---------------------------------------------------------------------------


def test_tc08_server_wrapper() -> None:
    """server.list_voices calls run_list_voices and returns its result."""
    from renderdeck_mcp.server import list_voices

    result = list_voices()
    assert "voices" in result
    assert result["total_count"] == 71


# ---------------------------------------------------------------------------
# TC-09: French voice alias resolution
# ---------------------------------------------------------------------------


def test_tc09_french_voice_resolution() -> None:
    """resolve_voice maps French aliases to full edge-tts names."""
    from renderdeck_mcp.voices import resolve_voice

    assert resolve_voice("denise") == "fr-FR-DeniseNeural"
    assert resolve_voice("henri") == "fr-FR-HenriNeural"
    assert resolve_voice("charline") == "fr-BE-CharlineNeural"
    assert resolve_voice("gerard") == "fr-BE-GerardNeural"
    assert resolve_voice("sylvie") == "fr-CA-SylvieNeural"
    assert resolve_voice("antoine") == "fr-CA-AntoineNeural"
    assert resolve_voice("DENISE") == "fr-FR-DeniseNeural"  # case-insensitive


# ---------------------------------------------------------------------------
# TC-10: French voice entries have valid structure
# ---------------------------------------------------------------------------


def test_tc10_french_voices_structure() -> None:
    """All French voice entries have correct fields and naming convention."""
    from renderdeck_mcp.voices import DEFAULT_VOICES

    french_voices = {
        alias: info for alias, info in DEFAULT_VOICES.items() if info["locale"].startswith("fr-")
    }
    assert len(french_voices) == 9

    for alias, info in french_voices.items():
        assert alias == alias.lower(), f"Alias {alias!r} should be lowercase"
        assert info["full_name"].endswith("Neural")
        assert info["locale"] in ("fr-FR", "fr-BE", "fr-CA")
        assert info["gender"] in ("Male", "Female")


# ---------------------------------------------------------------------------
# TC-11: French locale labels present
# ---------------------------------------------------------------------------


def test_tc11_french_locale_labels() -> None:
    """_LOCALE_LABELS includes French locale entries."""
    from renderdeck_mcp.tools.voices import _LOCALE_LABELS

    assert "fr-FR" in _LOCALE_LABELS
    assert "fr-BE" in _LOCALE_LABELS
    assert "fr-CA" in _LOCALE_LABELS


# ---------------------------------------------------------------------------
# TC-12: English voices unchanged (regression)
# ---------------------------------------------------------------------------


def test_tc12_english_voices_unchanged() -> None:
    """Existing English voice aliases still resolve correctly."""
    from renderdeck_mcp.voices import DEFAULT_VOICES, resolve_voice

    assert resolve_voice("aria") == "en-US-AriaNeural"
    assert resolve_voice("roger") == "en-US-RogerNeural"
    assert resolve_voice("sonia") == "en-GB-SoniaNeural"

    english_voices = {
        alias for alias, info in DEFAULT_VOICES.items() if info["locale"].startswith("en-")
    }
    assert len(english_voices) == 60


# ---------------------------------------------------------------------------
# TC-13: Vietnamese voice alias resolution
# ---------------------------------------------------------------------------


def test_tc13_vietnamese_voice_resolution() -> None:
    """resolve_voice maps Vietnamese aliases to full edge-tts names."""
    from renderdeck_mcp.voices import resolve_voice

    assert resolve_voice("hoaimy") == "vi-VN-HoaiMyNeural"
    assert resolve_voice("namminh") == "vi-VN-NamMinhNeural"
    assert resolve_voice("HOAIMY") == "vi-VN-HoaiMyNeural"  # case-insensitive


# ---------------------------------------------------------------------------
# TC-14: Vietnamese voice entries have valid structure
# ---------------------------------------------------------------------------


def test_tc14_vietnamese_voices_structure() -> None:
    """All Vietnamese voice entries have correct fields and naming convention."""
    from renderdeck_mcp.voices import DEFAULT_VOICES

    vietnamese_voices = {
        alias: info for alias, info in DEFAULT_VOICES.items() if info["locale"].startswith("vi-")
    }
    assert len(vietnamese_voices) == 2

    for alias, info in vietnamese_voices.items():
        assert alias == alias.lower(), f"Alias {alias!r} should be lowercase"
        assert info["full_name"].endswith("Neural")
        assert info["locale"] == "vi-VN"
        assert info["gender"] in ("Male", "Female")


# ---------------------------------------------------------------------------
# TC-15: Vietnamese locale label present
# ---------------------------------------------------------------------------


def test_tc15_vietnamese_locale_label() -> None:
    """_LOCALE_LABELS includes Vietnamese locale entry."""
    from renderdeck_mcp.tools.voices import _LOCALE_LABELS

    assert "vi-VN" in _LOCALE_LABELS
    assert _LOCALE_LABELS["vi-VN"] == "Vietnam"
