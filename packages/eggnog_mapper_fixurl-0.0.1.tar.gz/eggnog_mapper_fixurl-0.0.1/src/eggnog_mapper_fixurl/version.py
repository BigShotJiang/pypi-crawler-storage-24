__version__ = '0.0.1' # Don't forget to match with pyproject.toml
