\# 🌊 hanaflow



> Upload any dataset to SAP HANA Cloud in one command — then query it with LLM.



\## Installation

```bash

pip install hanaflow

```



\## Quick Start



\### 1. Configure credentials

Create a `.env` file:

```env

HANA\_HOST=your-host.hanacloud.ondemand.com

HANA\_PORT=443

HANA\_USER=DBADMIN

HANA\_PASSWORD=your-password

HANA\_ENCRYPT=true

LLM\_API=your-gemini-api-key

LLM\_MODEL=gemini-2.0-flash

```



\### 2. Test connection

```bash

hanaflow ping

```



\### 3. Upload a dataset

```bash

hanaflow upload-cmd --file sales\_data.csv

```



\### 4. Get an LLM summary of your data

```bash

hanaflow summary --file sales\_data.csv

```



\### 5. Ask questions about your data

```bash

hanaflow ask --file sales\_data.csv --question "What is the average price by city?"

```



\## Supported File Formats

| Format | Extension |

|--------|-----------|

| CSV | `.csv` |

| Excel | `.xlsx` / `.xls` |

| JSON | `.json` |

| Parquet | `.parquet` |



\## CLI Commands

| Command | Description |

|---------|-------------|

| `hanaflow ping` | Test SAP HANA connectivity |

| `hanaflow upload-cmd` | Upload data file to SAP HANA |

| `hanaflow summary` | Generate LLM summary of dataset |

| `hanaflow ask` | Ask natural language questions about data |



\## Built With

\- \[hdbcli](https://pypi.org/project/hdbcli/) — SAP HANA Python Client

\- \[LangChain](https://python.langchain.com/) — LLM framework

\- \[Google Gemini](https://aistudio.google.com/) — LLM provider

\- \[Typer](https://typer.tiangolo.com/) — CLI framework

\- \[FastAPI](https://fastapi.tiangolo.com/) — REST API (coming soon)



\## License

MIT

