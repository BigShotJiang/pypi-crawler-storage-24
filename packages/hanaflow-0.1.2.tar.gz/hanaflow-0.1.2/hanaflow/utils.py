from __future__ import annotations

import logging
from rich.console import Console
from rich.logging import RichHandler
from rich.panel import Panel
from rich.table import Table
from rich import box

console = Console()


def setup_logging(verbose: bool = False) -> None:
    """Configure root logger with Rich handler."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(console=console, rich_tracebacks=True, show_path=verbose)],
    )
    if not verbose:
        for noisy in ("hdbcli", "urllib3", "httpx"):
            logging.getLogger(noisy).setLevel(logging.WARNING)


def print_success(schema: str, table: str, rows: int, columns: list) -> None:
    """Print a rich success panel after a successful upload."""
    col_table = Table(box=box.SIMPLE_HEAD, show_header=True, header_style="bold cyan")
    col_table.add_column("Column", style="white")
    col_table.add_column("HANA Type", style="green")
    for col in columns:
        col_table.add_row(col.name, col.hana_type)

    console.print(col_table)
    console.print(
        Panel.fit(
            f"[bold green]✓ Upload successful![/bold green]\n\n"
            f"  [cyan]Schema[/cyan]  : {schema}\n"
            f"  [cyan]Table[/cyan]   : {table}\n"
            f"  [cyan]Rows[/cyan]    : [bold]{rows:,}[/bold]\n"
            f"  [cyan]Columns[/cyan] : {len(columns)}",
            title="[bold]hanaflow[/bold]",
            border_style="green",
        )
    )


def print_error(message: str) -> None:
    console.print(f"[bold red]Error:[/bold red] {message}")


def print_info(message: str) -> None:
    console.print(f"[dim]{message}[/dim]")