from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

# Load .env from the current working directory (or parent chain)
load_dotenv(dotenv_path=Path.cwd() / ".env", override=False)


@dataclass
class ConnectorConfig:
    """All settings required to open a hdbcli connection."""

    host: str     = field(default_factory=lambda: os.environ.get("HANA_HOST", ""))
    port: int     = field(default_factory=lambda: int(os.environ.get("HANA_PORT", "443")))
    user: str     = field(default_factory=lambda: os.environ.get("HANA_USER", ""))
    password: str = field(default_factory=lambda: os.environ.get("HANA_PASSWORD", ""))
    # HANA Cloud requires encrypted connections; on-premise usually does not
    encrypt: bool = field(
        default_factory=lambda: os.environ.get("HANA_ENCRYPT", "true").lower() == "true"
    )

    def validate(self) -> None:
        """Raise ValueError if any required field is missing."""
        missing = [f for f in ("host", "user", "password") if not getattr(self, f)]
        if missing:
            raise ValueError(
                f"Missing HANA connection parameter(s): {', '.join(missing)}.\n"
                "Set them in your .env file or pass them as CLI flags."
            )


@dataclass
class LLMConfig:
    api_key: str = field(default_factory=lambda: os.environ.get("LLM_API", ""))
    model: str = field(default_factory=lambda: os.environ.get("LLM_MODEL", "gemini-2.0-flash"))
    temperature: float = field(default_factory=lambda: float(os.environ.get("LLM_TEMPERATURE", 0.2)))

    def validate(self):
        if not self.api_key:
            raise ValueError("LLM API key missing. Please set LLM_API in .env")

    