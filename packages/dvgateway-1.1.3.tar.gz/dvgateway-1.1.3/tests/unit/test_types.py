"""Tests for type definitions."""

from datetime import datetime

from dvgateway.types import (
    ApiKeyAuth,
    AudioChunk,
    CallEndedEvent,
    CallNewEvent,
    CallSession,
    JwtAuth,
    Message,
    TranscriptResult,
    TranscriptWord,
)


class TestAuth:
    def test_api_key_auth(self) -> None:
        auth = ApiKeyAuth(api_key="test-key")
        assert auth.type == "apiKey"
        assert auth.api_key == "test-key"

    def test_jwt_auth(self) -> None:
        auth = JwtAuth(token="abc.def.ghi")
        assert auth.type == "jwt"
        assert auth.token == "abc.def.ghi"


class TestCallSession:
    def test_defaults(self) -> None:
        session = CallSession(linked_id="test-123")
        assert session.linked_id == "test-123"
        assert session.dir == "both"
        assert session.conf_id is None
        assert session.caller is None

    def test_full(self) -> None:
        session = CallSession(
            linked_id="abc",
            conf_id="7001",
            dir="in",
            caller="01012345678",
            callee="01087654321",
            tenant_id="tenant-a",
            metadata={"key": "value"},
        )
        assert session.conf_id == "7001"
        assert session.metadata == {"key": "value"}


class TestCallEvents:
    def test_call_new_event(self) -> None:
        session = CallSession(linked_id="xyz")
        event = CallNewEvent(session=session)
        assert event.type == "call:new"
        assert event.session.linked_id == "xyz"

    def test_call_ended_event(self) -> None:
        event = CallEndedEvent(linked_id="xyz", duration_sec=30.5)
        assert event.type == "call:ended"
        assert event.duration_sec == 30.5


class TestAudioChunk:
    def test_defaults(self) -> None:
        chunk = AudioChunk(
            linked_id="test",
            samples=[0.0, 0.5, -0.5],
            duration_ms=20.0,
        )
        assert chunk.sample_rate == 16000
        assert len(chunk.samples) == 3


class TestTranscriptResult:
    def test_with_words(self) -> None:
        result = TranscriptResult(
            linked_id="abc",
            text="안녕하세요",
            is_final=True,
            confidence=0.95,
            language="ko",
            words=[
                TranscriptWord(word="안녕하세요", start_ms=100, end_ms=500, confidence=0.95),
            ],
        )
        assert result.is_final
        assert result.words is not None
        assert len(result.words) == 1


class TestMessage:
    def test_system_message(self) -> None:
        msg = Message(role="system", content="You are helpful.")
        assert msg.role == "system"

    def test_user_message(self) -> None:
        msg = Message(role="user", content="Hello")
        assert msg.role == "user"
