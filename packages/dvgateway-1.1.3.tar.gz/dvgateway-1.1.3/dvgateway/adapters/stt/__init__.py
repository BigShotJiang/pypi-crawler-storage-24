from dvgateway.adapters.stt.deepgram import DeepgramAdapter

__all__ = ["DeepgramAdapter"]
