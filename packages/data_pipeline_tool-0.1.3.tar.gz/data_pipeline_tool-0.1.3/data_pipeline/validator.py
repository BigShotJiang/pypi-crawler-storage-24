def validate_data(df, show_report=True):
    """
    Validate dataset and optionally print validation report
    """

    report = {
        "rows": df.shape[0],
        "columns": df.shape[1],
        "duplicate_rows": df.duplicated().sum(),
        "missing_values": df.isnull().sum().to_dict(),
        "data_types": {
            col: "number" if "int" in str(dtype) or "float" in str(dtype) else "text"
            for col, dtype in df.dtypes.items()
        }
    }

    if show_report:
        print("\n📊 Data Validation Summary")
        print("-" * 40)
        print(f"Rows               : {report['rows']}")
        print(f"Columns            : {report['columns']}")
        print(f"Duplicate Rows     : {report['duplicate_rows']}")

        print("\nMissing Values")
        print("-" * 40)
        for col, val in report["missing_values"].items():
            print(f"{col:<20} : {val}")

        print("\nData Types")
        print("-" * 40)
        for col, dtype in report["data_types"].items():
            print(f"{col:<20} : {dtype}")

    return report