from .loader import load_data
from .validator import validate_data
from .cleaner import clean_data


def run_pipeline(input_file, output_file):
    """
    Run full data pipeline (orchestration only)
    """

    df = load_data(input_file)

    validation_report = validate_data(df)
    clean_df, cleaning_report = clean_data(df)

    clean_df.to_csv(output_file, index=False)

