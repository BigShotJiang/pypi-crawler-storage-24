import pandas as pd

def clean_data(df, show_report=True):

    df = df.copy()
    summary = {}
    total_cols = df.shape[1]

    # -------------------------------------------------
    # Rule 1: Remove rows with >80% missing values
    # -------------------------------------------------
    missing_ratio = df.isnull().sum(axis=1) / total_cols
    rows_before = len(df)

    df = df.loc[missing_ratio <= 0.80].copy()

    summary["rows_removed_gt_80_missing"] = rows_before - len(df)

    # -------------------------------------------------
    # Rule 2: Fill rows with <70% missing values
    # -------------------------------------------------
    missing_ratio = df.isnull().sum(axis=1) / total_cols
    rows_to_fill_idx = df.loc[missing_ratio < 0.70].index

    summary["rows_filled_lt_70_missing"] = len(rows_to_fill_idx)

    if len(rows_to_fill_idx) > 0:

        text_fill = input(
            "Enter value to fill TEXT columns (rows <70% missing): "
        )

        num_fill_input = input(
            "Enter value to fill NUMERIC columns (rows <70% missing): "
        )

        try:
            num_fill = float(num_fill_input)
        except ValueError:
            print("Invalid numeric input. Using 0.0")
            num_fill = 0.0

        # Fill TEXT columns (safe for pandas 2 & 3)
        text_cols = df.select_dtypes(include=["object", "string"]).columns
        for col in text_cols:
            df.loc[rows_to_fill_idx, col] = df.loc[
                rows_to_fill_idx, col
            ].fillna(text_fill)

        # Fill NUMERIC columns
        num_cols = df.select_dtypes(include=["number"]).columns
        for col in num_cols:
            df.loc[rows_to_fill_idx, col] = df.loc[
                rows_to_fill_idx, col
            ].fillna(num_fill)

    # -------------------------------------------------
    # Remove duplicates
    # -------------------------------------------------
    before = len(df)
    df.drop_duplicates(inplace=True)
    summary["duplicates_removed"] = before - len(df)

    # -------------------------------------------------
    # Standardize column names
    # -------------------------------------------------
    df.columns = (
        df.columns.str.strip()
        .str.lower()
        .str.replace(" ", "_")
    )

    summary["columns_standardized"] = True
    summary["final_rows"] = len(df)

    # -------------------------------------------------
    # Print Summary
    # -------------------------------------------------
    if show_report:
        print("\n🧹 Data Cleaning Summary")
        print("-" * 50)
        print(f"Rows removed (>80% missing) : {summary['rows_removed_gt_80_missing']}")
        print(f"Rows filled (<70% missing)  : {summary['rows_filled_lt_70_missing']}")
        print(f"Duplicates removed          : {summary['duplicates_removed']}")
        print(f"Columns standardized        : Yes")
        print(f"Final row count             : {summary['final_rows']}")

    return df, summary
