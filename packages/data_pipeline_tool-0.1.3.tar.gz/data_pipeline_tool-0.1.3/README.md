# data-pipeline

A simple and reusable Python data pipeline package for loading, cleaning, and validating CSV data.  
This package is designed for beginners and data analysts who want a clean, structured way to process data.

---

## Features

- Load CSV files into pandas DataFrames
- Clean data by removing duplicates and missing values
- Validate data to ensure it is usable
- Simple one-function pipeline execution
- Lightweight and easy to integrate into any project

---

## Installation

Install the package from PyPI using pip:

```bash
pip install data_pipeline_tool
