from setuptools import setup, find_packages

setup(
    name="data_pipeline_tool",
    version="0.1.3",
    author="Vinith k",
    author_email="vinithkabilar@gmail.com",
    description="A simple data pipeline package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["pandas>=1.5.0"],
    python_requires=">=3.8",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
