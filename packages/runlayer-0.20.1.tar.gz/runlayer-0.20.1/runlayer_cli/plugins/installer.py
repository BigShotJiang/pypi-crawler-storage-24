from __future__ import annotations

import datetime
import json
import os
import shutil
from collections import defaultdict
from collections.abc import Callable
from functools import partial
from pathlib import Path, PurePosixPath
from uuid import UUID

import anyio
import anyio.to_thread
import httpx
import structlog
import yaml
from pydantic import BaseModel, ValidationError

from runlayer_cli.api import PluginDetail, RunlayerClient, SkillFileDetail
from runlayer_cli.scan.clients import get_client_by_name
from runlayer_cli.skills.installer import _sanitize_name

logger = structlog.get_logger(__name__)

PLUGINS_DIR_MAP: dict[str, tuple[str, str]] = {
    "claude_code": (".claude/plugins", ".claude/plugins"),
    "cursor": (".cursor/plugins", ".cursor/plugins"),
    "vscode": (".vscode/plugins", ".vscode/plugins"),
}

MANIFEST_DIR_MAP: dict[str, str] = {
    "claude_code": ".claude-plugin",
    "cursor": ".cursor-plugin",
    "vscode": ".vscode-plugin",
}

LOCKFILE = "plugin-lock.yml"
INSTALLED_MARKER = ".installed"
CANONICAL_BASE = ".agents/plugins"
NATIVE_PLUGIN_CLIENTS = {"claude_code", "cursor", "vscode"}
_MAX_CONCURRENT = 10


class PluginLockEntry(BaseModel):
    name: str
    id: str
    namespace: str | None = None
    updated_at: datetime.datetime | None = None
    client: str = "claude_code"
    install_mode: str = "native"
    server_ids: list[str] = []
    skill_ids: list[str] = []


class PluginInstallResult(BaseModel):
    installed: list[str] = []
    skipped: list[str] = []
    errors: list[str] = []


class PluginUpdateResult(BaseModel):
    updated: list[str] = []
    up_to_date: list[str] = []
    removed: list[str] = []
    errors: list[str] = []


def resolve_plugin_dirs(
    client_name: str, global_install: bool, cwd: Path
) -> tuple[Path, Path, Path]:
    if client_name in PLUGINS_DIR_MAP:
        project_rel, global_rel = PLUGINS_DIR_MAP[client_name]
        if global_install:
            home = Path.home()
            canonical = home / CANONICAL_BASE
            editor = home / global_rel
            lockfile = home / ".runlayer" / LOCKFILE
        else:
            canonical = cwd / CANONICAL_BASE
            editor = cwd / project_rel
            lockfile = cwd / ".runlayer" / LOCKFILE
    else:
        # MCP fallback clients: no canonical/editor dirs, just lockfile
        if global_install:
            home = Path.home()
            canonical = home / CANONICAL_BASE
            editor = canonical
            lockfile = home / ".runlayer" / LOCKFILE
        else:
            canonical = cwd / CANONICAL_BASE
            editor = canonical
            lockfile = cwd / ".runlayer" / LOCKFILE
    return canonical, editor, lockfile


def read_plugin_lockfile(path: Path) -> list[PluginLockEntry]:
    if not path.exists():
        return []
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        raise ValueError(f"invalid lockfile YAML: {e}") from e
    if not data or "plugins" not in data:
        return []
    raw_entries = data["plugins"]
    if not isinstance(raw_entries, list):
        raise ValueError("invalid lockfile format: 'plugins' must be a list")

    parsed: list[PluginLockEntry] = []
    for i, item in enumerate(raw_entries):
        if not isinstance(item, dict):
            raise ValueError(f"invalid lockfile entry at index {i}: expected mapping")
        try:
            parsed.append(PluginLockEntry.model_validate(item))
        except ValidationError as e:
            raise ValueError(f"invalid lockfile entry at index {i}: {e}") from e
    return parsed


def _write_plugin_lockfile(path: Path, entries: list[PluginLockEntry]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "plugins": [e.model_dump(mode="json") for e in entries],
    }
    path.write_text(
        "# managed by: runlayer plugins add\n" + yaml.dump(data, sort_keys=False),
        encoding="utf-8",
    )


def _write_plugin_manifest(
    canonical_dir: Path,
    plugin_name: str,
    plugin: PluginDetail,
    client_name: str,
    host: str | None = None,
) -> None:
    _sanitize_name(plugin_name)
    manifest_dir_name = MANIFEST_DIR_MAP.get(client_name, ".claude-plugin")
    plugin_dir = canonical_dir / plugin_name / manifest_dir_name
    plugin_dir.mkdir(parents=True, exist_ok=True)
    manifest = {
        "id": plugin.id,
        "name": plugin.name,
        "description": plugin.description,
        "namespace": plugin.namespace,
    }
    if client_name == "claude_code" and host is not None:
        manifest["mcpServers"] = _build_plugin_proxy_servers(plugin, host)
    (plugin_dir / "plugin.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )


def _build_plugin_proxy_servers(
    plugin: PluginDetail,
    host: str,
) -> dict[str, dict[str, str]]:
    servers: dict[str, dict[str, str]] = {}
    # circular: installer ↔ commands.setup ↔ commands.plugins
    from runlayer_cli.commands.setup import (
        build_server_proxy_url,
        normalize_server_name,
    )

    for srv in plugin.servers:
        srv_id = srv.get("server_id") or srv.get("id", "")
        srv_name = srv.get("name", srv_id)
        if not srv_id:
            continue

        key = normalize_server_name(srv_name)
        servers[key] = {"url": build_server_proxy_url(host, srv_id)}

    return servers


def _build_plugin_mcp_config(
    plugin: PluginDetail,
    host: str,
    client_name: str,
) -> dict[str, dict[str, dict[str, str]]]:
    client_def = get_client_by_name(client_name)
    servers_key = client_def.servers_key if client_def else "mcpServers"
    return {servers_key: _build_plugin_proxy_servers(plugin, host)}


def _write_plugin_mcp_json(
    canonical_dir: Path,
    plugin_name: str,
    plugin: PluginDetail,
    host: str,
    client_name: str,
) -> None:
    _sanitize_name(plugin_name)
    plugin_dir = canonical_dir / plugin_name
    plugin_dir.mkdir(parents=True, exist_ok=True)

    mcp_config = _build_plugin_mcp_config(plugin, host, client_name)
    (plugin_dir / ".mcp.json").write_text(
        json.dumps(mcp_config, indent=2) + "\n", encoding="utf-8"
    )


async def _fetch_skill_files(
    client: RunlayerClient,
    skill_id: str,
    file_ids: list[str],
    limiter: anyio.CapacityLimiter,
) -> list[SkillFileDetail]:
    results: list[SkillFileDetail] = []

    async def _fetch_one(fid: str) -> None:
        async with limiter:
            detail = await anyio.to_thread.run_sync(
                partial(client.get_skill_file, skill_id, fid)
            )
        results.append(detail)

    async with anyio.create_task_group() as tg:
        for fid in file_ids:
            tg.start_soon(_fetch_one, fid)
    return results


def _write_plugin_skills(
    canonical_dir: Path,
    plugin_name: str,
    skill_name: str,
    files: list[SkillFileDetail],
) -> None:
    _sanitize_name(plugin_name)
    _sanitize_name(skill_name)
    skills_dir = canonical_dir / plugin_name / "skills" / skill_name
    skills_dir.mkdir(parents=True, exist_ok=True)
    for f in files:
        _sanitize_name(f.title)
        fpath = skills_dir / PurePosixPath(f.title)
        fpath.parent.mkdir(parents=True, exist_ok=True)
        fpath.write_text(f.content, encoding="utf-8")


def _symlink_plugin(canonical_dir: Path, editor_dir: Path, plugin_name: str) -> None:
    _sanitize_name(plugin_name)
    src = canonical_dir / plugin_name
    dest = editor_dir / plugin_name
    if src == dest:
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_symlink():
        dest.unlink()
    elif dest.exists():
        if dest.is_dir():
            shutil.rmtree(dest)
        else:
            dest.unlink()
    rel = os.path.relpath(src, dest.parent)
    dest.symlink_to(rel)


def _install_plugin_mcp_fallback(
    plugin: PluginDetail,
    client_name: str,
    host: str,
) -> None:
    # circular: installer ↔ commands.setup ↔ commands.plugins
    from runlayer_cli.commands.setup import (
        InstallClient,
        InstallServerSpec,
        _build_server_entry,
        _get_install_client_config_path,
        _get_servers_key_for_client,
        _read_config_file,
        _write_config_file,
        build_plugin_proxy_url,
        normalize_server_name,
    )

    install_client = InstallClient(client_name)

    config_path = _get_install_client_config_path(install_client)
    if not config_path:
        raise ValueError(f"could not find config path for {client_name}")

    client_def = get_client_by_name(client_name)
    config_format = client_def.config_format if client_def else "json"
    servers_key = _get_servers_key_for_client(install_client)

    config = _read_config_file(config_path, config_format, fail_on_error=True)
    if servers_key not in config:
        config[servers_key] = {}

    proxy_url = build_plugin_proxy_url(host, plugin.id)
    proxy_name = normalize_server_name(plugin.name)
    spec = InstallServerSpec(
        server_id=plugin.id,
        name=plugin.name,
        proxy_url=proxy_url,
        host=host,
        is_local=False,
    )
    config[servers_key][proxy_name] = _build_server_entry(install_client, spec)

    _write_config_file(config_path, config, config_format)


def _remove_plugin_mcp_fallback(
    plugin_name: str,
    client_name: str,
) -> None:
    # circular: installer ↔ commands.setup ↔ commands.plugins
    from runlayer_cli.commands.setup import (
        InstallClient,
        _get_install_client_config_path,
        _get_servers_key_for_client,
        _read_config_file,
        _write_config_file,
        normalize_server_name,
    )

    try:
        install_client = InstallClient(client_name)
    except ValueError:
        return

    config_path = _get_install_client_config_path(install_client)
    if not config_path or not config_path.exists():
        return

    client_def = get_client_by_name(client_name)
    config_format = client_def.config_format if client_def else "json"
    servers_key = _get_servers_key_for_client(install_client)

    config = _read_config_file(config_path, config_format, fail_on_error=False)
    if servers_key not in config:
        return

    proxy_name = normalize_server_name(plugin_name)
    if proxy_name in config[servers_key]:
        del config[servers_key][proxy_name]
        _write_config_file(config_path, config, config_format)


def _remove_plugin_files(
    canonical_dir: Path,
    editor_dir: Path,
    plugin_name: str,
    *,
    remove_canonical: bool = True,
) -> None:
    _sanitize_name(plugin_name)
    if remove_canonical:
        plugin_dir = canonical_dir / plugin_name
        if plugin_dir.exists():
            shutil.rmtree(plugin_dir)

    if canonical_dir != editor_dir:
        link = editor_dir / plugin_name
        if link.is_symlink():
            link.unlink()
        elif link.exists():
            shutil.rmtree(link)


def _extract_server_ids(plugin: PluginDetail) -> list[str]:
    ids = []
    for srv in plugin.servers:
        sid = srv.get("server_id") or srv.get("id", "")
        if sid:
            ids.append(sid)
    return ids


def _extract_skill_ids(plugin: PluginDetail) -> list[str]:
    return [s.id for s in plugin.skills]


async def install_plugins(
    client: RunlayerClient,
    source: str | None,
    install_all: bool,
    plugin_name: str | None,
    canonical_dir: Path,
    editor_dir: Path,
    lockfile_path: Path,
    client_name: str,
    host: str,
    dry_run: bool = False,
    on_progress: Callable[[str, str], None] | None = None,
) -> PluginInstallResult:
    result = PluginInstallResult()
    lock_entries = read_plugin_lockfile(lockfile_path)
    locked_keys = {(e.client, e.id) for e in lock_entries}
    locked_name_to_id = {e.name: e.id for e in lock_entries if e.client == client_name}
    limiter = anyio.CapacityLimiter(_MAX_CONCURRENT)
    is_native = client_name in NATIVE_PLUGIN_CLIENTS

    plugins: list[PluginDetail] = []
    if install_all:
        all_plugins = await anyio.to_thread.run_sync(
            partial(client.list_all_plugins, mine_only=False)
        )
        if plugin_name:
            matched = [p for p in all_plugins if p.name == plugin_name]
            if not matched:
                result.errors.append(
                    f"plugin '{plugin_name}' not found in accessible plugins"
                )
                return result
            plugins = matched
        else:
            plugins = all_plugins
    else:
        assert source is not None
        try:
            UUID(source)
            is_uuid = True
        except ValueError:
            is_uuid = False

        if is_uuid:
            plugin = await anyio.to_thread.run_sync(partial(client.get_plugin, source))
            plugins.append(plugin)
        else:
            namespace = source
            all_ns = await anyio.to_thread.run_sync(
                partial(client.list_plugins_by_namespace, namespace)
            )
            if plugin_name:
                matched = [p for p in all_ns if p.name == plugin_name]
                if not matched:
                    result.errors.append(
                        f"plugin '{plugin_name}' not found in {namespace}"
                    )
                    return result
                plugins = matched
            else:
                plugins = all_ns

    if not plugins:
        if install_all:
            result.errors.append("no accessible plugins found")
        else:
            result.errors.append(f"no plugins found for '{source}'")
        return result

    by_name_ids: dict[str, set[str]] = defaultdict(set)
    by_name_namespaces: dict[str, set[str]] = defaultdict(set)
    for p in plugins:
        by_name_ids[p.name].add(p.id)
        by_name_namespaces[p.name].add(p.namespace or "<none>")
    collisions = {
        name: sorted(namespaces)
        for name, namespaces in by_name_namespaces.items()
        if len(by_name_ids[name]) > 1
    }
    if collisions:
        for name, namespaces in sorted(collisions.items()):
            scope = ", ".join(namespaces)
            result.errors.append(
                f"multiple plugins named '{name}' found ({scope}); use a namespace SOURCE or UUID"
            )
        return result

    for plugin in plugins:
        key = (client_name, plugin.id)
        if key in locked_keys:
            result.skipped.append(plugin.name)
            if on_progress:
                on_progress(plugin.name, "already installed")
            continue

        existing_id = locked_name_to_id.get(plugin.name)
        if existing_id and existing_id != plugin.id:
            result.errors.append(
                f"name conflict for '{plugin.name}': already installed with different plugin id"
            )
            if on_progress:
                on_progress(plugin.name, "name conflict")
            continue

        if dry_run:
            locked_keys.add(key)
            locked_name_to_id[plugin.name] = plugin.id
            result.installed.append(plugin.name)
            if on_progress:
                on_progress(plugin.name, "would install")
            continue

        try:
            install_mode = "native" if is_native else "mcp_fallback"

            if is_native:
                _write_plugin_manifest(
                    canonical_dir, plugin.name, plugin, client_name, host
                )
                _write_plugin_mcp_json(
                    canonical_dir, plugin.name, plugin, host, client_name
                )

                for skill_ref in plugin.skills:
                    skill_detail = await anyio.to_thread.run_sync(
                        partial(client.get_skill, skill_ref.id)
                    )
                    if skill_detail.files:
                        files = await _fetch_skill_files(
                            client,
                            skill_ref.id,
                            [f.id for f in skill_detail.files],
                            limiter,
                        )
                        _write_plugin_skills(
                            canonical_dir, plugin.name, skill_ref.name, files
                        )

                marker = canonical_dir / plugin.name / INSTALLED_MARKER
                marker.parent.mkdir(parents=True, exist_ok=True)
                marker.write_text("", encoding="utf-8")

                _symlink_plugin(canonical_dir, editor_dir, plugin.name)
            else:
                _install_plugin_mcp_fallback(plugin, client_name, host)

            lock_entries.append(
                PluginLockEntry(
                    name=plugin.name,
                    id=plugin.id,
                    namespace=plugin.namespace,
                    updated_at=plugin.updated_at,
                    client=client_name,
                    install_mode=install_mode,
                    server_ids=_extract_server_ids(plugin),
                    skill_ids=_extract_skill_ids(plugin),
                )
            )
            locked_keys.add(key)
            locked_name_to_id[plugin.name] = plugin.id
            result.installed.append(plugin.name)
            if on_progress:
                on_progress(plugin.name, "installed")
        except Exception as e:
            logger.error("install_failed", plugin=plugin.name, error=str(e))
            result.errors.append(f"{plugin.name}: {e}")

    if not dry_run and result.installed:
        _write_plugin_lockfile(lockfile_path, lock_entries)

    return result


async def uninstall_plugin(
    name: str,
    canonical_dir: Path,
    editor_dir: Path,
    lockfile_path: Path,
    client_name: str,
) -> None:
    lock_entries = read_plugin_lockfile(lockfile_path)
    _sanitize_name(name)
    matching = [e for e in lock_entries if e.client == client_name and e.name == name]
    if not matching:
        raise ValueError(
            f"plugin '{name}' not found in lockfile for client '{client_name}'"
        )

    entry = matching[0]
    is_native = entry.install_mode == "native"

    if is_native:
        keep_name = any(
            e.name == name and (e.client != client_name or e not in matching)
            for e in lock_entries
        )
        _remove_plugin_files(
            canonical_dir,
            editor_dir,
            name,
            remove_canonical=not keep_name,
        )
    else:
        _remove_plugin_mcp_fallback(name, client_name)

    lock_entries = [
        e for e in lock_entries if not (e.client == client_name and e.name == name)
    ]
    _write_plugin_lockfile(lockfile_path, lock_entries)


async def update_plugins(
    client: RunlayerClient,
    plugin_name: str | None,
    canonical_dir: Path,
    editor_dir: Path,
    lockfile_path: Path,
    client_name: str,
    host: str,
    dry_run: bool = False,
    on_progress: Callable[[str, str], None] | None = None,
) -> PluginUpdateResult:
    result = PluginUpdateResult()
    lock_entries = read_plugin_lockfile(lockfile_path)
    client_entries = [e for e in lock_entries if e.client == client_name]

    if not client_entries:
        return result

    if plugin_name:
        targets = [e for e in client_entries if e.name == plugin_name]
        if not targets:
            result.errors.append(
                f"plugin '{plugin_name}' not in lockfile for client '{client_name}'"
            )
            return result
    else:
        targets = list(client_entries)

    limiter = anyio.CapacityLimiter(_MAX_CONCURRENT)

    for entry in targets:
        try:
            _sanitize_name(entry.name)
            try:
                async with limiter:
                    remote = await anyio.to_thread.run_sync(
                        partial(client.get_plugin, entry.id)
                    )
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 404:
                    logger.warning("plugin_gone", name=entry.name, id=entry.id)
                    if not dry_run:
                        is_native = entry.install_mode == "native"
                        if is_native:
                            keep_name = any(
                                le.name == entry.name
                                and not (
                                    le.client == entry.client and le.id == entry.id
                                )
                                for le in lock_entries
                            )
                            _remove_plugin_files(
                                canonical_dir,
                                editor_dir,
                                entry.name,
                                remove_canonical=not keep_name,
                            )
                        else:
                            _remove_plugin_mcp_fallback(entry.name, client_name)
                        lock_entries = [
                            le
                            for le in lock_entries
                            if not (le.client == entry.client and le.id == entry.id)
                        ]
                    result.removed.append(entry.name)
                    if on_progress:
                        if dry_run:
                            on_progress(entry.name, "would remove (not found)")
                        else:
                            on_progress(entry.name, "removed (not found)")
                    continue
                raise

            if (
                entry.updated_at
                and remote.updated_at
                and remote.updated_at <= entry.updated_at
            ):
                result.up_to_date.append(entry.name)
                if on_progress:
                    on_progress(entry.name, "up to date")
                continue

            if dry_run:
                result.updated.append(entry.name)
                if on_progress:
                    on_progress(entry.name, "would update")
                continue

            is_native = entry.install_mode == "native"

            if is_native:
                # Remove old files and re-install
                _remove_plugin_files(canonical_dir, editor_dir, entry.name)
                _write_plugin_manifest(
                    canonical_dir, entry.name, remote, client_name, host
                )
                _write_plugin_mcp_json(
                    canonical_dir, entry.name, remote, host, client_name
                )

                for skill_ref in remote.skills:
                    skill_detail = await anyio.to_thread.run_sync(
                        partial(client.get_skill, skill_ref.id)
                    )
                    if skill_detail.files:
                        files = await _fetch_skill_files(
                            client,
                            skill_ref.id,
                            [f.id for f in skill_detail.files],
                            limiter,
                        )
                        _write_plugin_skills(
                            canonical_dir, entry.name, skill_ref.name, files
                        )

                marker = canonical_dir / entry.name / INSTALLED_MARKER
                marker.parent.mkdir(parents=True, exist_ok=True)
                marker.write_text("", encoding="utf-8")

                _symlink_plugin(canonical_dir, editor_dir, entry.name)
            else:
                _install_plugin_mcp_fallback(remote, client_name, host)

            for le in lock_entries:
                if le.client == entry.client and le.id == entry.id:
                    le.updated_at = remote.updated_at
                    le.server_ids = _extract_server_ids(remote)
                    le.skill_ids = _extract_skill_ids(remote)

            result.updated.append(entry.name)
            if on_progress:
                on_progress(entry.name, "updated")

        except Exception as e:
            logger.error("update_failed", plugin=entry.name, error=str(e))
            result.errors.append(f"{entry.name}: {e}")

    if not dry_run and (result.updated or result.removed):
        _write_plugin_lockfile(lockfile_path, lock_entries)

    return result
