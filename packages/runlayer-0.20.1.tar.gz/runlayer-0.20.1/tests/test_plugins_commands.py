from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from typer.testing import CliRunner

from runlayer_cli.main import app
from runlayer_cli.plugins.installer import PluginInstallResult, PluginLockEntry
from runlayer_cli.plugins.models import DiscoveredPlugin
from runlayer_cli.plugins.sync_engine import PluginSyncResult
from runlayer_cli.skills.sync_engine import SyncResult

runner = CliRunner()


def test_plugins_push_outputs_summary_and_done(tmp_path: Path) -> None:
    discovered = [
        DiscoveredPlugin(root=tmp_path, path="review-suite", name="review-suite", skills=[]),
    ]
    sync_mock = AsyncMock(
        return_value=PluginSyncResult(
            discovered_plugins=1,
            discovered_skills=2,
            created=1,
            warnings=["review-suite: warning"],
        )
    )
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch("runlayer_cli.commands.plugins.discover_plugins", return_value=discovered),
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo"],
        )

    assert result.exit_code == 0
    assert "Found 1 plugins, 0 skills" in result.output
    assert "1 plugins created" in result.output


def test_plugins_push_prints_pushing_header_before_progress(tmp_path: Path) -> None:
    discovered = [
        DiscoveredPlugin(
            root=tmp_path, path="review-suite", name="review-suite", skills=[]
        ),
    ]

    async def _sync(*args, **kwargs) -> PluginSyncResult:
        kwargs["on_skill_progress"]("review-suite/code-review", "created")
        kwargs["on_plugin_progress"]("review-suite", "created")
        return PluginSyncResult(created=1)

    sync_mock = AsyncMock(side_effect=_sync)
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch("runlayer_cli.commands.plugins.discover_plugins", return_value=discovered),
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo"],
        )

    assert result.exit_code == 0
    pushing_header = result.output.index("Pushing...")
    skill_progress = result.output.index("  review-suite/code-review: created")
    plugin_progress = result.output.index("  review-suite: created")
    assert pushing_header < skill_progress < plugin_progress


def test_plugins_push_prints_pushing_header_once(tmp_path: Path) -> None:
    discovered = [
        DiscoveredPlugin(
            root=tmp_path, path="review-suite", name="review-suite", skills=[]
        ),
    ]

    async def _sync(*args, **kwargs) -> PluginSyncResult:
        kwargs["on_skill_progress"]("review-suite/code-review", "created")
        kwargs["on_plugin_progress"]("review-suite", "updated")
        kwargs["on_plugin_progress"]("ops-suite", "created")
        return PluginSyncResult(created=1, updated=1)

    sync_mock = AsyncMock(side_effect=_sync)
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch("runlayer_cli.commands.plugins.discover_plugins", return_value=discovered),
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo"],
        )

    assert result.exit_code == 0
    assert result.output.count("Pushing...") == 1


def test_plugins_push_dry_run_requires_auth_up_front(tmp_path: Path) -> None:
    discovered = [
        DiscoveredPlugin(root=tmp_path, path="review-suite", name="review-suite", skills=[]),
    ]
    sync_mock = AsyncMock(return_value=PluginSyncResult())
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch("runlayer_cli.commands.plugins.resolve_credentials") as resolve_mock,
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch("runlayer_cli.commands.plugins.discover_plugins", return_value=discovered),
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        resolve_mock.return_value = {"host": "https://example.com", "secret": "rl_test"}
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo", "--dry-run"],
        )

    assert result.exit_code == 0
    assert resolve_mock.call_args.kwargs["require_auth"] is True


def test_plugins_push_discovers_once_and_passes_plugins_to_sync(tmp_path: Path) -> None:
    discovered = [
        DiscoveredPlugin(root=tmp_path, path="review-suite", name="review-suite", skills=[]),
    ]
    sync_mock = AsyncMock(return_value=PluginSyncResult())
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch(
            "runlayer_cli.commands.plugins.discover_plugins", return_value=discovered
        ) as discover_mock,
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo"],
        )

    assert result.exit_code == 0
    discover_mock.assert_called_once_with(tmp_path.resolve())
    assert sync_mock.await_args.args[0] == discovered


def test_plugins_push_prints_mcp_skip_warning(tmp_path: Path) -> None:
    discovered = [
        DiscoveredPlugin(
            root=tmp_path,
            path="review-suite",
            name="review-suite",
            skills=[],
        ),
    ]
    sync_mock = AsyncMock(
        return_value=PluginSyncResult(
            warnings=[
                "review-suite: skipped MCP server external-http with non-Runlayer URL https://example.com/mcp"
            ]
        )
    )
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch("runlayer_cli.commands.plugins.discover_plugins", return_value=discovered),
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo"],
        )

    assert result.exit_code == 0
    assert (
        "Warning: review-suite: skipped MCP server external-http with non-Runlayer URL https://example.com/mcp"
        in result.output
    )


def test_plugins_push_prints_manifest_warning_without_structlog_noise(
    tmp_path: Path,
) -> None:
    discovered = [
        DiscoveredPlugin(
            root=tmp_path,
            path="review-suite",
            name="review-suite",
            skills=[],
            manifest_warnings=[
                "review-suite: truncated plugin description to 1024 characters"
            ],
        ),
    ]
    sync_mock = AsyncMock(
        return_value=PluginSyncResult(
            warnings=["review-suite: truncated plugin description to 1024 characters"]
        )
    )
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch("runlayer_cli.commands.plugins.discover_plugins", return_value=discovered),
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo"],
        )

    assert result.exit_code == 0
    assert (
        "Warning: review-suite: truncated plugin description to 1024 characters"
        in result.output
    )
    assert "[warning" not in result.output


def test_plugins_push_suppresses_unchanged_lines(tmp_path: Path) -> None:
    """Unchanged items should not appear in output."""
    discovered = [
        DiscoveredPlugin(root=tmp_path, path="review-suite", name="review-suite", skills=[]),
    ]

    async def _sync(*args, **kwargs) -> PluginSyncResult:
        kwargs["on_skill_progress"]("review-suite/code-review", "unchanged")
        kwargs["on_skill_progress"]("review-suite/design-review", "updated")
        kwargs["on_plugin_progress"]("review-suite", "unchanged")
        return PluginSyncResult(
            unchanged=1,
            skill_result=SyncResult(updated=1, unchanged=1),
        )

    sync_mock = AsyncMock(side_effect=_sync)
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch("runlayer_cli.commands.plugins.discover_plugins", return_value=discovered),
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo"],
        )

    assert result.exit_code == 0
    assert "unchanged" not in result.output.split("Done")[0]
    assert "design-review: updated" in result.output
    assert "1 skills updated" in result.output
    assert "(2 unchanged)" in result.output


def test_plugins_push_everything_up_to_date(tmp_path: Path) -> None:
    discovered = [
        DiscoveredPlugin(root=tmp_path, path="review-suite", name="review-suite", skills=[]),
    ]
    sync_mock = AsyncMock(
        return_value=PluginSyncResult(
            unchanged=1,
            skill_result=SyncResult(unchanged=3),
        )
    )
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch("runlayer_cli.commands.plugins.discover_plugins", return_value=discovered),
        patch("runlayer_cli.commands.plugins.sync_discovered_plugins", new=sync_mock),
    ):
        result = runner.invoke(
            app,
            ["plugins", "push", str(tmp_path), "--namespace", "myorg/repo"],
        )

    assert result.exit_code == 0
    assert "everything up to date" in result.output


# -- Plugin add/list/remove/update command tests --


def _entry(name: str, *, client: str = "claude_code") -> PluginLockEntry:
    return PluginLockEntry(name=name, id=f"id-{name}", client=client)


def _resolve_dirs(tmp_path: Path) -> tuple[Path, Path, Path]:
    return (
        tmp_path / "canonical",
        tmp_path / "editor",
        tmp_path / "lock.yml",
    )


def test_add_all_works_without_source(tmp_path: Path):
    install_mock = AsyncMock(return_value=PluginInstallResult(installed=["a"]))
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_plugin_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch("runlayer_cli.commands.plugins.RunlayerClient"),
        patch(
            "runlayer_cli.commands.plugins.install_plugins",
            new=install_mock,
        ),
    ):
        result = runner.invoke(
            app,
            ["plugins", "add", "--all"],
        )

    assert result.exit_code == 0
    install_mock.assert_awaited_once()
    kwargs = install_mock.await_args_list[0].kwargs
    assert kwargs["install_all"] is True
    assert kwargs["source"] is None


@pytest.mark.parametrize(
    ("args", "expected_message"),
    [
        (["plugins", "add", "org/repo", "--all"], "either SOURCE or --all"),
        (["plugins", "add"], "Use SOURCE or --all"),
    ],
)
def test_add_arg_validation(args: list[str], expected_message: str):
    result = runner.invoke(app, args)
    assert result.exit_code == 1
    assert expected_message in result.output


def test_remove_all_prompts_and_aborts_on_no(tmp_path: Path):
    uninstall_mock = AsyncMock()
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_plugin_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.plugins.read_plugin_lockfile",
            return_value=[_entry("a"), _entry("b")],
        ),
        patch("runlayer_cli.commands.plugins.typer.confirm", return_value=False),
        patch(
            "runlayer_cli.commands.plugins.uninstall_plugin",
            new=uninstall_mock,
        ),
    ):
        result = runner.invoke(app, ["plugins", "remove", "--all"])

    assert result.exit_code == 0
    assert "Aborted." in result.output
    uninstall_mock.assert_not_called()


def test_remove_all_yes_removes_without_prompt(tmp_path: Path):
    uninstall_mock = AsyncMock()
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_plugin_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.plugins.read_plugin_lockfile",
            return_value=[_entry("a"), _entry("b")],
        ),
        patch("runlayer_cli.commands.plugins.typer.confirm") as confirm_mock,
        patch(
            "runlayer_cli.commands.plugins.uninstall_plugin",
            new=uninstall_mock,
        ),
    ):
        result = runner.invoke(app, ["plugins", "remove", "--all", "--yes"])

    assert result.exit_code == 0
    assert "Done: 2 removed" in result.output
    confirm_mock.assert_not_called()
    assert uninstall_mock.await_count == 2


@pytest.mark.parametrize(
    ("args", "expected_message"),
    [
        (["plugins", "remove", "my-plugin", "--all"], "either PLUGIN_NAME or --all"),
        (["plugins", "remove"], "Use PLUGIN_NAME or --all"),
    ],
)
def test_remove_arg_validation(args: list[str], expected_message: str):
    result = runner.invoke(app, args)
    assert result.exit_code == 1
    assert expected_message in result.output


def test_list_shows_installed_plugins(tmp_path: Path):
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_plugin_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.plugins.read_plugin_lockfile",
            return_value=[
                PluginLockEntry(
                    name="my-plugin",
                    id="p1",
                    namespace="org/repo",
                    client="claude_code",
                    install_mode="native",
                )
            ],
        ),
    ):
        result = runner.invoke(app, ["plugins", "list"])

    assert result.exit_code == 0
    assert "my-plugin" in result.output
    assert "org/repo" in result.output
    assert "native" in result.output
    assert "1 plugin(s) installed" in result.output


def test_list_no_plugins(tmp_path: Path):
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_plugin_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.plugins.read_plugin_lockfile",
            return_value=[],
        ),
    ):
        result = runner.invoke(app, ["plugins", "list"])

    assert result.exit_code == 0
    assert "No plugins installed." in result.output


def test_remove_all_filters_by_client(tmp_path: Path):
    entries = [
        PluginLockEntry(
            name="a", id="id-a", client="claude_code"
        ),
        PluginLockEntry(
            name="b", id="id-b", client="cursor", install_mode="mcp_fallback"
        ),
    ]
    uninstall_mock = AsyncMock()
    with (
        patch(
            "runlayer_cli.commands.plugins.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.plugins.resolve_plugin_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.plugins.read_plugin_lockfile",
            return_value=entries,
        ),
        patch(
            "runlayer_cli.commands.plugins.uninstall_plugin",
            new=uninstall_mock,
        ),
    ):
        result = runner.invoke(
            app,
            ["plugins", "remove", "--all", "--yes", "--client", "cursor"],
        )

    assert result.exit_code == 0
    assert "Done: 1 removed" in result.output
    uninstall_mock.assert_awaited_once()
    args = uninstall_mock.await_args_list[0].args
    assert args[0] == "b"
    assert args[-1] == "cursor"
