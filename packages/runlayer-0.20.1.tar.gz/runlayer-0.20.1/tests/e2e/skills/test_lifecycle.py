import shutil
from pathlib import Path

from tests.e2e.conftest import strip_ansi

from runlayer_cli.main import app


def _create_skill_dir(root: Path, name: str) -> None:
    """Create a minimal skill directory with SKILL.md."""
    skill_dir = root / name
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        f"---\nname: {name}\ndescription: E2E test skill\n---\n\n# {name}\n\nTest skill.\n"
    )


def _create_customer_shape_skill_dir(
    root: Path,
    name: str,
    *,
    extra_files: dict[str, str],
) -> Path:
    """Create a standalone skill dir shaped like the customer fixture."""
    skill_dir = root / name
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        f"---\nname: {name}\ndescription: Customer-shape e2e skill\n---\n\n# {name}\n\nUse this skill.\n"
    )
    for rel_path, content in extra_files.items():
        file_path = skill_dir / rel_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
    return skill_dir


def test_skills_push_lifecycle(runner, cli_args, tmp_path, unique_id):
    """runlayer skills push → push (idempotent) → push --prune"""
    skills_root = tmp_path / "skills-source"
    skills_root.mkdir()
    skill_name = f"test-skill-{unique_id}"
    _create_skill_dir(skills_root, skill_name)

    namespace = f"e2e-test/{unique_id}"

    result = runner.invoke(
        app,
        [*cli_args, "skills", "push", str(skills_root), "--namespace", namespace],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"push failed: {output}"
    assert "1 created" in output

    result = runner.invoke(
        app,
        [*cli_args, "skills", "push", str(skills_root), "--namespace", namespace],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"push 2 failed: {output}"
    assert "1 unchanged" in output or "0 created" in output

    shutil.rmtree(skills_root / skill_name)
    result = runner.invoke(
        app,
        [
            *cli_args,
            "skills",
            "push",
            str(skills_root),
            "--namespace",
            namespace,
            "--prune",
        ],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"prune failed: {output}"
    assert "1 deleted" in output


def test_skills_add_list_remove(runner, cli_args, tmp_path, unique_id, monkeypatch):
    """runlayer skills add → list → remove"""
    skills_root = tmp_path / "skills-source"
    skills_root.mkdir()
    skill_name = f"test-skill-{unique_id}"
    _create_skill_dir(skills_root, skill_name)

    namespace = f"e2e-test/{unique_id}"

    result = runner.invoke(
        app,
        [*cli_args, "skills", "push", str(skills_root), "--namespace", namespace],
    )
    assert result.exit_code == 0, f"push failed: {strip_ansi(result.output)}"

    project_dir = tmp_path / "project"
    project_dir.mkdir()
    monkeypatch.chdir(project_dir)

    result = runner.invoke(
        app,
        [*cli_args, "skills", "add", namespace, "--client", "claude_code"],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"add failed: {output}"
    assert "1 installed" in output

    result = runner.invoke(app, ["skills", "list", "--client", "claude_code"])
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"list failed: {output}"
    assert skill_name in output

    result = runner.invoke(
        app, ["skills", "remove", skill_name, "--client", "claude_code"]
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"remove failed: {output}"
    assert "Removed" in output

    shutil.rmtree(skills_root / skill_name)
    runner.invoke(
        app,
        [
            *cli_args,
            "skills",
            "push",
            str(skills_root),
            "--namespace",
            namespace,
            "--prune",
        ],
    )


def test_skills_push_separate_root_skill_dirs_do_not_clobber(
    runner, cli_args, api_client, tmp_path, unique_id
):
    """Separate standalone skill dirs in one namespace should create distinct skills."""
    root = tmp_path / "customer-shape"
    org_skills = root / "Organization Skills"
    org_skills.mkdir(parents=True)

    first_skill_dir = _create_customer_shape_skill_dir(
        org_skills,
        f"brand-voice-{unique_id}",
        extra_files={"helper.py": "print('tone')\n"},
    )
    second_skill_dir = _create_customer_shape_skill_dir(
        org_skills,
        f"image-workflow-{unique_id}",
        extra_files={
            "README.md": "# Notes\n",
            "EXAMPLES.md": "Example content\n",
            "references/REFERENCE.md": "Reference content\n",
        },
    )

    namespace = f"e2e-root-skill/{unique_id}"

    try:
        first = runner.invoke(
            app,
            [*cli_args, "skills", "push", str(first_skill_dir), "--namespace", namespace],
        )
        first_output = strip_ansi(first.output)
        assert first.exit_code == 0, f"first push failed: {first_output}"
        assert "1 created" in first_output

        second = runner.invoke(
            app,
            [*cli_args, "skills", "push", str(second_skill_dir), "--namespace", namespace],
        )
        second_output = strip_ansi(second.output)
        assert second.exit_code == 0, f"second push failed: {second_output}"
        assert "1 created" in second_output

        skills = sorted(api_client.list_skills(namespace), key=lambda skill: skill.path or "")
        assert len(skills) == 2
        assert len({skill.id for skill in skills}) == 2
        assert {skill.path for skill in skills} == {
            first_skill_dir.name,
            second_skill_dir.name,
        }
        assert {skill.name for skill in skills} == {
            first_skill_dir.name,
            second_skill_dir.name,
        }
    finally:
        for skill in api_client.list_skills(namespace):
            api_client.delete_skill(skill.id)


def test_skills_add_list_remove_vscode(
    runner, cli_args, tmp_path, unique_id, monkeypatch
):
    """runlayer skills add/list/remove works for VS Code native skills."""
    skills_root = tmp_path / "skills-source"
    skills_root.mkdir()
    skill_name = f"test-skill-{unique_id}"
    _create_skill_dir(skills_root, skill_name)

    namespace = f"e2e-test/{unique_id}"

    result = runner.invoke(
        app,
        [*cli_args, "skills", "push", str(skills_root), "--namespace", namespace],
    )
    assert result.exit_code == 0, f"push failed: {strip_ansi(result.output)}"

    project_dir = tmp_path / "project"
    project_dir.mkdir()
    monkeypatch.chdir(project_dir)

    result = runner.invoke(
        app,
        [*cli_args, "skills", "add", namespace, "--client", "vscode"],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"add failed: {output}"
    assert "1 installed" in output

    installed_skill = project_dir / ".agents" / "skills" / skill_name
    assert installed_skill.exists()
    assert not installed_skill.is_symlink()
    assert (installed_skill / "SKILL.md").exists()
    assert not (project_dir / ".vscode" / "skills" / skill_name).exists()

    lockfile = project_dir / ".runlayer" / "skill-lock.yml"
    assert lockfile.exists()
    lockfile_text = lockfile.read_text(encoding="utf-8")
    assert "client: vscode" in lockfile_text
    assert f"name: {skill_name}" in lockfile_text

    result = runner.invoke(app, ["skills", "list", "--client", "vscode"])
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"list failed: {output}"
    assert skill_name in output

    result = runner.invoke(app, ["skills", "remove", skill_name, "--client", "vscode"])
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"remove failed: {output}"
    assert "Removed" in output
    assert not installed_skill.exists()

    shutil.rmtree(skills_root / skill_name)
    runner.invoke(
        app,
        [
            *cli_args,
            "skills",
            "push",
            str(skills_root),
            "--namespace",
            namespace,
            "--prune",
        ],
    )
