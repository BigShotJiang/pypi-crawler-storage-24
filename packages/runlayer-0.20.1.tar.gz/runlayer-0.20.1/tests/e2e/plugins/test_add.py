"""E2E tests for plugins add / list / update / remove lifecycle."""

import json

import yaml

from runlayer_cli.main import app
from tests.e2e.conftest import strip_ansi


def test_plugins_add_by_namespace(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """plugins add ORG/REPO installs native plugin files."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    result = runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "add",
            plugin.namespace,
            "--plugin",
            plugin.name,
            "--client",
            "claude_code",
        ],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, output
    assert "1 installed" in output

    # .agents/plugins/<name>/.claude-plugin/plugin.json
    manifest = tmp_path / ".agents" / "plugins" / plugin.name / ".claude-plugin" / "plugin.json"
    assert manifest.exists()
    data = json.loads(manifest.read_text())
    assert data["id"] == plugin.id
    assert data["name"] == plugin.name
    assert "mcpServers" in data
    server_url = next(iter(data["mcpServers"].values()))["url"]
    server_entry = plugin.servers[0]
    server_id = server_entry.get("server_id") or server_entry.get("id")
    assert server_id
    assert f"proxy/{server_id}/mcp" in server_url

    # .agents/plugins/<name>/.mcp.json
    mcp_json = tmp_path / ".agents" / "plugins" / plugin.name / ".mcp.json"
    assert mcp_json.exists()
    mcp = json.loads(mcp_json.read_text())
    assert "mcpServers" in mcp

    # .agents/plugins/<name>/.installed marker
    installed = tmp_path / ".agents" / "plugins" / plugin.name / ".installed"
    assert installed.exists()

    # .claude/plugins/<name> symlink
    symlink = tmp_path / ".claude" / "plugins" / plugin.name
    assert symlink.is_symlink()

    # .runlayer/plugin-lock.yml
    lockfile = tmp_path / ".runlayer" / "plugin-lock.yml"
    assert lockfile.exists()
    lock = yaml.safe_load(lockfile.read_text())
    entries = lock["plugins"]
    match = [e for e in entries if e["id"] == plugin.id]
    assert len(match) == 1
    assert match[0]["install_mode"] == "native"
    assert match[0]["client"] == "claude_code"


def test_plugins_list_shows_installed(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """After add, plugins list shows the plugin."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "add",
            plugin.namespace,
            "--plugin",
            plugin.name,
            "--client",
            "claude_code",
        ],
    )

    list_result = runner.invoke(
        app,
        ["plugins", "list", "--client", "claude_code"],
    )
    output = strip_ansi(list_result.output)
    assert list_result.exit_code == 0, output
    assert plugin.name in output
    assert "1 plugin(s) installed" in output


def test_plugins_update_refreshes(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """After add, plugins update reports up-to-date."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "add",
            plugin.namespace,
            "--plugin",
            plugin.name,
            "--client",
            "claude_code",
        ],
    )

    update_result = runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "update",
            "--client",
            "claude_code",
        ],
    )
    output = strip_ansi(update_result.output)
    assert update_result.exit_code == 0, output
    assert "up to date" in output.lower()


def test_plugins_remove_cleans_up(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """plugins remove NAME removes files, symlink, lockfile entry."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "add",
            plugin.namespace,
            "--plugin",
            plugin.name,
            "--client",
            "claude_code",
        ],
    )

    # Verify installed first
    assert (tmp_path / ".agents" / "plugins" / plugin.name / ".installed").exists()

    remove_result = runner.invoke(
        app,
        ["plugins", "remove", plugin.name, "--client", "claude_code"],
    )
    output = strip_ansi(remove_result.output)
    assert remove_result.exit_code == 0, output
    assert f"Removed: {plugin.name}" in output

    # Files gone
    assert not (tmp_path / ".agents" / "plugins" / plugin.name).exists()
    assert not (tmp_path / ".claude" / "plugins" / plugin.name).exists()

    # Lockfile updated
    lockfile = tmp_path / ".runlayer" / "plugin-lock.yml"
    lock = yaml.safe_load(lockfile.read_text())
    ids = [e["id"] for e in lock.get("plugins", [])]
    assert plugin.id not in ids


def test_plugins_add_dry_run(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """plugins add --dry-run reports 'would install' but writes nothing."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    result = runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "add",
            plugin.namespace,
            "--plugin",
            plugin.name,
            "--client",
            "claude_code",
            "--dry-run",
        ],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, output
    assert "would install" in output

    # Nothing written
    assert not (tmp_path / ".agents" / "plugins" / plugin.name).exists()
    assert not (tmp_path / ".runlayer" / "plugin-lock.yml").exists()


def test_plugins_add_already_installed_skips(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """Second plugins add skips already-installed plugin."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    add_args = [
        *cli_args,
        "plugins",
        "add",
        plugin.namespace,
        "--plugin",
        plugin.name,
        "--client",
        "claude_code",
    ]
    runner.invoke(app, add_args)

    second = runner.invoke(app, add_args)
    output = strip_ansi(second.output)
    assert second.exit_code == 0, output
    assert "1 skipped" in output


def test_plugins_remove_all(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """plugins remove --all --yes removes everything."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "add",
            plugin.namespace,
            "--plugin",
            plugin.name,
            "--client",
            "claude_code",
        ],
    )

    remove_result = runner.invoke(
        app,
        ["plugins", "remove", "--all", "--yes", "--client", "claude_code"],
    )
    output = strip_ansi(remove_result.output)
    assert remove_result.exit_code == 0, output
    assert "1 removed" in output

    # Files gone
    assert not (tmp_path / ".agents" / "plugins" / plugin.name).exists()


def test_plugins_add_vscode_native(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """plugins add --client vscode installs native plugin with 'servers' key."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    result = runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "add",
            plugin.namespace,
            "--plugin",
            plugin.name,
            "--client",
            "vscode",
        ],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, output
    assert "1 installed" in output

    # .agents/plugins/<name>/.vscode-plugin/plugin.json
    manifest = tmp_path / ".agents" / "plugins" / plugin.name / ".vscode-plugin" / "plugin.json"
    assert manifest.exists()
    data = json.loads(manifest.read_text())
    assert data["id"] == plugin.id
    assert data["name"] == plugin.name

    # .agents/plugins/<name>/.mcp.json uses "servers" key
    mcp_json = tmp_path / ".agents" / "plugins" / plugin.name / ".mcp.json"
    assert mcp_json.exists()
    mcp = json.loads(mcp_json.read_text())
    assert "servers" in mcp
    assert "mcpServers" not in mcp

    # .vscode/plugins/<name> symlink
    symlink = tmp_path / ".vscode" / "plugins" / plugin.name
    assert symlink.is_symlink()

    # .runlayer/plugin-lock.yml
    lockfile = tmp_path / ".runlayer" / "plugin-lock.yml"
    assert lockfile.exists()
    lock = yaml.safe_load(lockfile.read_text())
    match = [e for e in lock["plugins"] if e["id"] == plugin.id]
    assert len(match) == 1
    assert match[0]["install_mode"] == "native"
    assert match[0]["client"] == "vscode"


def test_plugins_update_vscode_preserves_servers_key(
    runner, cli_args, tmp_path, monkeypatch, create_e2e_plugin
):
    """After add --client vscode, update preserves 'servers' key in .mcp.json."""
    monkeypatch.chdir(tmp_path)
    plugin = create_e2e_plugin()

    runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "add",
            plugin.namespace,
            "--plugin",
            plugin.name,
            "--client",
            "vscode",
        ],
    )

    update_result = runner.invoke(
        app,
        [
            *cli_args,
            "plugins",
            "update",
            "--client",
            "vscode",
        ],
    )
    output = strip_ansi(update_result.output)
    assert update_result.exit_code == 0, output

    # .mcp.json still uses "servers" key after update
    mcp_json = tmp_path / ".agents" / "plugins" / plugin.name / ".mcp.json"
    assert mcp_json.exists()
    mcp = json.loads(mcp_json.read_text())
    assert "servers" in mcp
    assert "mcpServers" not in mcp
