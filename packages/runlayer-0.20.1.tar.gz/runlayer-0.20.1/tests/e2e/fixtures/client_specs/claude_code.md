# Claude Code MCP Client Spec

- **Config path:** `~/.claude.json` (all platforms)
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** `.mcp.json` (servers key: `mcpServers`)
- **Transport:** stdio, HTTP
- **Last verified:** 2026-03-17

## Editor docs

- **Skills:** https://code.claude.com/docs/en/skills
- **Plugins:** https://code.claude.com/docs/en/plugins
- **MCP:** https://code.claude.com/docs/en/mcp

## Runlayer support

### Skills: native
- Canonical: `.agents/skills/<name>/`
- Symlink: `.claude/skills/<name>` → canonical
- Lockfile: `.runlayer/skill-lock.yml`

### Plugins: native
- Manifest: `.agents/plugins/<name>/.claude-plugin/plugin.json`
- Manifest MCP: `.claude-plugin/plugin.json` may include `"mcpServers"` inline
- MCP config: `.agents/plugins/<name>/.mcp.json` with `"mcpServers"` key
- Skills: `.agents/plugins/<name>/skills/<skill>/`
- Symlink: `.claude/plugins/<name>` → canonical
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: native`)

### MCP connectors (servers)
- Config: `~/.claude.json` or `.mcp.json`
- Local entry:
  ```json
  {"command": "uvx", "args": ["runlayer", "run", "<server-id>", "--host", "<host>"]}
  ```
- Remote entry:
  ```json
  {"type": "http", "url": "<proxy-url>"}
  ```
