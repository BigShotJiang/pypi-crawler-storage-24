"""Tests for plugins installer."""

from __future__ import annotations

import datetime
import json
from pathlib import Path

import httpx
import pytest

from runlayer_cli.api import PluginDetail, PluginSkillRef, SkillDetail, SkillFileDetail, SkillFileMetadata
from runlayer_cli.plugins.installer import (
    PluginLockEntry,
    _write_plugin_lockfile,
    _write_plugin_manifest,
    _write_plugin_mcp_json,
    install_plugins,
    read_plugin_lockfile,
    uninstall_plugin,
    update_plugins,
)


def _plugin(
    *,
    id: str = "p1",
    name: str = "my-plugin",
    namespace: str | None = "org/repo",
    servers: list[dict] | None = None,
    skills: list[PluginSkillRef] | None = None,
    updated_at: datetime.datetime | None = None,
) -> PluginDetail:
    return PluginDetail(
        id=id,
        name=name,
        namespace=namespace,
        servers=servers or [{"server_id": "srv-1", "name": "My Server"}],
        skills=skills or [],
        updated_at=updated_at or datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC),
    )


def _lock_entry(
    name: str = "my-plugin",
    *,
    client: str = "claude_code",
    install_mode: str = "native",
) -> PluginLockEntry:
    return PluginLockEntry(
        name=name,
        id="p1",
        namespace="org/repo",
        updated_at=datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC),
        client=client,
        install_mode=install_mode,
        server_ids=["srv-1"],
    )


# -- Lockfile tests --


def test_read_plugin_lockfile_empty(tmp_path: Path):
    lockfile = tmp_path / "lock.yml"
    assert read_plugin_lockfile(lockfile) == []


def test_read_write_plugin_lockfile_roundtrip(tmp_path: Path):
    lockfile = tmp_path / "lock" / "plugin-lock.yml"
    entries = [_lock_entry()]
    _write_plugin_lockfile(lockfile, entries)
    loaded = read_plugin_lockfile(lockfile)
    assert len(loaded) == 1
    assert loaded[0].name == "my-plugin"
    assert loaded[0].install_mode == "native"
    assert loaded[0].server_ids == ["srv-1"]


def test_read_plugin_lockfile_invalid_yaml(tmp_path: Path):
    lockfile = tmp_path / "lock.yml"
    lockfile.write_text("{{bad yaml", encoding="utf-8")
    with pytest.raises(ValueError, match="invalid lockfile YAML"):
        read_plugin_lockfile(lockfile)


def test_read_plugin_lockfile_invalid_format(tmp_path: Path):
    lockfile = tmp_path / "lock.yml"
    lockfile.write_text("plugins: notalist", encoding="utf-8")
    with pytest.raises(ValueError, match="must be a list"):
        read_plugin_lockfile(lockfile)


# -- Manifest tests --


def test_write_plugin_manifest(tmp_path: Path):
    plugin = _plugin()
    _write_plugin_manifest(
        tmp_path, "my-plugin", plugin, "claude_code", "https://example.com"
    )
    manifest_path = tmp_path / "my-plugin" / ".claude-plugin" / "plugin.json"
    assert manifest_path.exists()
    data = json.loads(manifest_path.read_text())
    assert data["id"] == "p1"
    assert data["name"] == "my-plugin"
    assert "mcpServers" in data
    server_url = next(iter(data["mcpServers"].values()))["url"]
    assert "proxy/srv-1/mcp" in server_url


def test_write_plugin_manifest_cursor(tmp_path: Path):
    plugin = _plugin()
    _write_plugin_manifest(tmp_path, "my-plugin", plugin, "cursor")
    manifest_path = tmp_path / "my-plugin" / ".cursor-plugin" / "plugin.json"
    assert manifest_path.exists()
    data = json.loads(manifest_path.read_text())
    assert data["id"] == "p1"
    assert data["name"] == "my-plugin"


def test_write_plugin_manifest_vscode(tmp_path: Path):
    plugin = _plugin()
    _write_plugin_manifest(tmp_path, "my-plugin", plugin, "vscode")
    manifest_path = tmp_path / "my-plugin" / ".vscode-plugin" / "plugin.json"
    assert manifest_path.exists()
    data = json.loads(manifest_path.read_text())
    assert data["id"] == "p1"
    assert data["name"] == "my-plugin"


def test_write_plugin_mcp_json(tmp_path: Path):
    plugin = _plugin()
    _write_plugin_mcp_json(tmp_path, "my-plugin", plugin, "https://example.com", "claude_code")
    mcp_path = tmp_path / "my-plugin" / ".mcp.json"
    assert mcp_path.exists()
    data = json.loads(mcp_path.read_text())
    assert "mcpServers" in data
    servers = data["mcpServers"]
    assert len(servers) == 1
    key = list(servers.keys())[0]
    assert "proxy/srv-1/mcp" in servers[key]["url"]


def test_write_plugin_mcp_json_vscode(tmp_path: Path):
    plugin = _plugin()
    _write_plugin_mcp_json(tmp_path, "my-plugin", plugin, "https://example.com", "vscode")
    mcp_path = tmp_path / "my-plugin" / ".mcp.json"
    assert mcp_path.exists()
    data = json.loads(mcp_path.read_text())
    assert "servers" in data
    assert "mcpServers" not in data
    servers = data["servers"]
    assert len(servers) == 1
    key = list(servers.keys())[0]
    assert "proxy/srv-1/mcp" in servers[key]["url"]


# -- Fake clients --


def _raise_404(*_args, **_kwargs):
    req = httpx.Request("GET", "https://example.com/plugins/p1")
    resp = httpx.Response(404, request=req)
    raise httpx.HTTPStatusError("not found", request=req, response=resp)


class _FakeClient404:
    get_plugin = staticmethod(_raise_404)


class _FakeClientSinglePlugin:
    def list_plugins_by_namespace(self, namespace: str):
        return [_plugin()]

    def get_plugin(self, plugin_id: str) -> PluginDetail:
        return _plugin(id=plugin_id)

    def get_skill(self, skill_id: str) -> SkillDetail:
        return SkillDetail(
            id=skill_id,
            name="test-skill",
            files=[
                SkillFileMetadata(
                    id="f1",
                    skill_id=skill_id,
                    title="SKILL.md",
                    updated_at=datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC),
                )
            ],
        )

    def get_skill_file(self, skill_id: str, file_id: str) -> SkillFileDetail:
        return SkillFileDetail(
            id=file_id,
            skill_id=skill_id,
            title="SKILL.md",
            content=f"# {skill_id}",
        )


class _FakeClientWithSkills(_FakeClientSinglePlugin):
    def list_plugins_by_namespace(self, namespace: str):
        return [
            _plugin(
                skills=[
                    PluginSkillRef(id="sk1", name="skill-one"),
                ]
            )
        ]


class _FakeClientAllAccessible:
    def list_all_plugins(self, *, mine_only: bool):
        assert mine_only is False
        return [
            _plugin(id="p1", name="plugin-one", namespace="org/a"),
            _plugin(id="p2", name="plugin-two", namespace="org/b"),
        ]

    def get_plugin(self, plugin_id: str) -> PluginDetail:
        return _plugin(id=plugin_id)

    def get_skill(self, skill_id: str) -> SkillDetail:
        return SkillDetail(id=skill_id, name="test-skill", files=[])

    def get_skill_file(self, skill_id: str, file_id: str) -> SkillFileDetail:
        return SkillFileDetail(
            id=file_id, skill_id=skill_id, title="SKILL.md", content="# test"
        )


class _FakeClientDuplicateNames:
    def list_plugins_by_namespace(self, namespace: str):
        return [
            _plugin(id="p1", name="dup-plugin", namespace="org/a"),
            _plugin(id="p2", name="dup-plugin", namespace="org/a"),
        ]


class _FakeClientUpdateNewer:
    def get_plugin(self, plugin_id: str) -> PluginDetail:
        return _plugin(
            id=plugin_id,
            updated_at=datetime.datetime(2024, 2, 1, tzinfo=datetime.UTC),
        )

    def get_skill(self, skill_id: str) -> SkillDetail:
        return SkillDetail(id=skill_id, name="test-skill", files=[])


# -- Install tests --


@pytest.mark.asyncio
async def test_install_native_creates_file_structure(tmp_path: Path):
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"

    result = await install_plugins(
        client=_FakeClientSinglePlugin(),  # type: ignore
        source="org/repo",
        install_all=False,
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
    )

    assert result.errors == []
    assert result.installed == ["my-plugin"]

    # Check file structure
    plugin_dir = canonical / "my-plugin"
    assert (plugin_dir / ".claude-plugin" / "plugin.json").exists()
    assert (plugin_dir / ".mcp.json").exists()
    assert (plugin_dir / ".installed").exists()
    manifest = json.loads((plugin_dir / ".claude-plugin" / "plugin.json").read_text())
    assert "mcpServers" in manifest

    # Check editor symlink
    assert (editor / "my-plugin").is_symlink()

    # Check lockfile
    entries = read_plugin_lockfile(lockfile)
    assert len(entries) == 1
    assert entries[0].name == "my-plugin"
    assert entries[0].install_mode == "native"


@pytest.mark.asyncio
async def test_install_native_with_skills_downloads_files(tmp_path: Path):
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"

    result = await install_plugins(
        client=_FakeClientWithSkills(),  # type: ignore
        source="org/repo",
        install_all=False,
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
    )

    assert result.errors == []
    assert result.installed == ["my-plugin"]
    skill_dir = canonical / "my-plugin" / "skills" / "skill-one"
    assert skill_dir.exists()
    assert (skill_dir / "SKILL.md").exists()


@pytest.mark.asyncio
@pytest.mark.parametrize("dry_run", [False, True])
async def test_install_all_accessible(tmp_path: Path, dry_run: bool):
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"

    result = await install_plugins(
        client=_FakeClientAllAccessible(),  # type: ignore
        source=None,
        install_all=True,
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
        dry_run=dry_run,
    )

    assert result.errors == []
    assert result.installed == ["plugin-one", "plugin-two"]
    if dry_run:
        assert not lockfile.exists()
        assert not (editor / "plugin-one").exists()
    else:
        assert (editor / "plugin-one").is_symlink()
        assert (editor / "plugin-two").is_symlink()


@pytest.mark.asyncio
async def test_install_skips_already_locked(tmp_path: Path):
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"
    _write_plugin_lockfile(lockfile, [_lock_entry()])

    result = await install_plugins(
        client=_FakeClientSinglePlugin(),  # type: ignore
        source="org/repo",
        install_all=False,
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
    )

    assert result.skipped == ["my-plugin"]
    assert result.installed == []


@pytest.mark.asyncio
async def test_install_collision_error(tmp_path: Path):
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"

    result = await install_plugins(
        client=_FakeClientDuplicateNames(),  # type: ignore
        source="org/repo",
        install_all=False,
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
    )

    assert result.installed == []
    assert result.errors
    assert "multiple plugins named 'dup-plugin'" in result.errors[0]


# -- Remove tests --


def _setup_installed_plugin(
    tmp_path: Path,
) -> tuple[Path, Path, Path]:
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"

    plugin_dir = canonical / "my-plugin"
    plugin_dir.mkdir(parents=True)
    (plugin_dir / ".installed").write_text("", encoding="utf-8")
    link = editor / "my-plugin"
    link.parent.mkdir(parents=True)
    link.symlink_to(plugin_dir)
    _write_plugin_lockfile(lockfile, [_lock_entry()])

    return canonical, editor, lockfile


@pytest.mark.asyncio
async def test_uninstall_removes_files_and_lockfile_entry(tmp_path: Path):
    canonical, editor, lockfile = _setup_installed_plugin(tmp_path)

    await uninstall_plugin("my-plugin", canonical, editor, lockfile, "claude_code")

    assert not (canonical / "my-plugin").exists()
    assert not (editor / "my-plugin").exists()
    entries = read_plugin_lockfile(lockfile)
    assert entries == []


@pytest.mark.asyncio
async def test_uninstall_not_found_raises(tmp_path: Path):
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"
    _write_plugin_lockfile(lockfile, [_lock_entry()])

    with pytest.raises(ValueError, match="not found in lockfile"):
        await uninstall_plugin(
            "nonexistent", canonical, editor, lockfile, "claude_code"
        )


# -- Update tests --


@pytest.mark.asyncio
@pytest.mark.parametrize("dry_run", [False, True])
async def test_update_404_removes(tmp_path: Path, dry_run: bool):
    canonical, editor, lockfile = _setup_installed_plugin(tmp_path)
    plugin_dir = canonical / "my-plugin"

    result = await update_plugins(
        client=_FakeClient404(),  # type: ignore
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
        dry_run=dry_run,
    )

    assert result.removed == ["my-plugin"]
    if dry_run:
        assert plugin_dir.exists()
    else:
        assert not plugin_dir.exists()


@pytest.mark.asyncio
async def test_update_up_to_date(tmp_path: Path):
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"
    _write_plugin_lockfile(
        lockfile,
        [
            PluginLockEntry(
                name="my-plugin",
                id="p1",
                namespace="org/repo",
                updated_at=datetime.datetime(2024, 3, 1, tzinfo=datetime.UTC),
                client="claude_code",
                install_mode="native",
            )
        ],
    )

    result = await update_plugins(
        client=_FakeClientUpdateNewer(),  # type: ignore
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
    )

    assert result.up_to_date == ["my-plugin"]


@pytest.mark.asyncio
async def test_update_newer_refreshes(tmp_path: Path):
    canonical = tmp_path / "canonical"
    editor = tmp_path / "editor"
    lockfile = tmp_path / "lock" / "plugin-lock.yml"
    _write_plugin_lockfile(lockfile, [_lock_entry()])

    result = await update_plugins(
        client=_FakeClientUpdateNewer(),  # type: ignore
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
    )

    assert result.updated == ["my-plugin"]
    entries = read_plugin_lockfile(lockfile)
    assert entries[0].updated_at == datetime.datetime(2024, 2, 1, tzinfo=datetime.UTC)


@pytest.mark.asyncio
async def test_update_traversal_name_rejected(tmp_path: Path):
    canonical = tmp_path / "canonical"
    canonical.mkdir()
    editor = tmp_path / "editor"
    editor.mkdir()
    lockfile = tmp_path / "lock" / "plugin-lock.yml"

    target = tmp_path / "precious"
    target.mkdir()
    (target / "data.txt").write_text("important")

    _write_plugin_lockfile(lockfile, [_lock_entry("../../precious")])
    result = await update_plugins(
        client=_FakeClient404(),  # type: ignore
        plugin_name=None,
        canonical_dir=canonical,
        editor_dir=editor,
        lockfile_path=lockfile,
        client_name="claude_code",
        host="https://example.com",
    )

    assert result.errors
    assert target.exists()
