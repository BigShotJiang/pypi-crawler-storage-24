"""Tests for skills toolset."""
