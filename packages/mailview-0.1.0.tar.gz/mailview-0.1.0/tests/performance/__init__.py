"""Performance benchmarks for mailview."""
