"""Edge handling strategies for downsampled time series data."""

import pandas as pd

from downsampler.config import EdgeHandling


def identify_edge_points(
    df: pd.DataFrame,
    edge_window: int = 2
) -> pd.Series:
    """Identify edge points in a DataFrame.

    Edge points are the first and last few points in a DataFrame that may
    have reduced accuracy in downsampling due to boundary effects.

    Args:
        df: DataFrame with DatetimeIndex.
        edge_window: Number of points at each edge to mark as edge points.

    Returns:
        Boolean Series where True indicates an edge point.

    Example:
        >>> df = pd.DataFrame(
        ...     {'value': range(10)},
        ...     index=pd.date_range('2024-01-01', periods=10, freq='1min')
        ... )
        >>> edges = identify_edge_points(df, edge_window=2)
        >>> edges.sum()
        4
    """
    n = len(df)
    is_edge = pd.Series(False, index=df.index)

    if edge_window == 0:
        return is_edge

    if n <= 2 * edge_window:
        # All points are edge points
        is_edge[:] = True
    else:
        is_edge.iloc[:edge_window] = True
        is_edge.iloc[-edge_window:] = True

    return is_edge


def apply_edge_handling(
    df: pd.DataFrame,
    handling: EdgeHandling,
    edge_window: int = 2
) -> pd.DataFrame:
    """Apply edge handling strategy to a DataFrame.

    Args:
        df: DataFrame with DatetimeIndex (typically after downsampling).
        handling: Edge handling strategy to apply.
        edge_window: Number of points at each edge to consider as edge points.

    Returns:
        DataFrame with edge handling applied:
        - KEEP: Returns the DataFrame unchanged.
        - FLAG: Adds '_is_edge' column with boolean values.
        - DISCARD: Returns DataFrame with edge points removed.

    Example:
        >>> df = pd.DataFrame(
        ...     {'value': range(10)},
        ...     index=pd.date_range('2024-01-01', periods=10, freq='1min')
        ... )
        >>> flagged = apply_edge_handling(df, EdgeHandling.FLAG, edge_window=2)
        >>> '_is_edge' in flagged.columns
        True
    """
    if handling == EdgeHandling.KEEP:
        return df.copy()

    is_edge = identify_edge_points(df, edge_window)

    if handling == EdgeHandling.FLAG:
        df_result = df.copy()
        df_result['_is_edge'] = is_edge
        return df_result

    elif handling == EdgeHandling.DISCARD:
        return df[~is_edge].copy()

    return df.copy()
