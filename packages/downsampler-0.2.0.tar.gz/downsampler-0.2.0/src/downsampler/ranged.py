"""Range-based downsampling API.

This module provides tools for downsampling when data needs to be fetched
from an external source (e.g., API, database) for a given time range.
It handles edge buffering automatically to ensure stable output at
the boundaries.
"""

import logging
from dataclasses import replace
from typing import Callable, Protocol

import pandas as pd

from downsampler.config import DownsampleConfig, EdgeHandling
from downsampler.utils import parse_cadence, _build_metadata


class DataFetcher(Protocol):
    """Protocol for data fetching functions.

    A DataFetcher is a callable that retrieves data for a given time range.
    """
    def __call__(
        self,
        start: pd.Timestamp,
        end: pd.Timestamp
    ) -> pd.DataFrame:
        """Fetch data for the given time range.

        Args:
            start: Start of time range (inclusive).
            end: End of time range (exclusive).

        Returns:
            DataFrame with DatetimeIndex containing data in the time range.
        """
        ...


def _compute_edge_buffer(
    target_cadence: pd.Timedelta,
    edge_window: int = 2,
    multiplier: float = 2.0,
) -> pd.Timedelta:
    """Compute the time buffer needed at edges for stable downsampling."""
    return target_cadence * edge_window * multiplier


def _expand_time_range(
    start: pd.Timestamp,
    end: pd.Timestamp,
    buffer: pd.Timedelta,
) -> tuple[pd.Timestamp, pd.Timestamp]:
    """Expand a time range by a buffer on both ends."""
    return start - buffer, end + buffer


def _trim_to_range(
    df: pd.DataFrame,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> pd.DataFrame:
    """Trim a DataFrame to a specific time range (start inclusive, end exclusive)."""
    return df[(df.index >= start) & (df.index < end)].copy()


def _downsample_single_range(
    fetcher: Callable[[pd.Timestamp, pd.Timestamp], pd.DataFrame],
    output_start: pd.Timestamp,
    output_end: pd.Timestamp,
    target_cadence: pd.Timedelta,
    config: DownsampleConfig,
    edge_buffer_multiplier: float,
) -> pd.DataFrame:
    """Fetch data for a single range, downsample, and trim to output range."""
    from downsampler.core import downsample_dataframe

    edge_buffer = _compute_edge_buffer(
        target_cadence, config.edge_window, edge_buffer_multiplier
    )
    fetch_start, fetch_end = _expand_time_range(
        output_start, output_end, edge_buffer
    )

    logging.debug(
        f"Fetching data from {fetch_start} to {fetch_end} "
        f"(buffer: {edge_buffer}) for output range {output_start} to {output_end}"
    )

    df = fetcher(fetch_start, fetch_end)

    if df is None or len(df) == 0:
        logging.warning(
            f"Fetcher returned empty DataFrame for {fetch_start} to {fetch_end}"
        )
        return pd.DataFrame()

    # Override edge handling — trimming handles edges for range mode
    config_no_edges = replace(config, edge_handling=EdgeHandling.KEEP)

    result = downsample_dataframe(df, target_cadence, config_no_edges)

    if len(result) == 0:
        return result

    attrs = result.attrs.copy()
    result = _trim_to_range(result, output_start, output_end)
    result.attrs = attrs
    return result


def _downsample_range_batched(
    fetcher: Callable[[pd.Timestamp, pd.Timestamp], pd.DataFrame],
    output_start: pd.Timestamp,
    output_end: pd.Timestamp,
    target_cadence: pd.Timedelta,
    batch_size: pd.Timedelta,
    config: DownsampleConfig,
    edge_buffer_multiplier: float,
) -> pd.DataFrame:
    """Downsample a large time range in batches."""
    results = []

    current_start = output_start
    while current_start < output_end:
        current_end = min(current_start + batch_size, output_end)

        logging.info(f"Processing batch: {current_start} to {current_end}")

        batch_result = _downsample_single_range(
            fetcher=fetcher,
            output_start=current_start,
            output_end=current_end,
            target_cadence=target_cadence,
            config=config,
            edge_buffer_multiplier=edge_buffer_multiplier,
        )

        if len(batch_result) > 0:
            results.append(batch_result)

        current_start = current_end

    if not results:
        return pd.DataFrame()

    result = pd.concat(results).sort_index()
    result = result[~result.index.duplicated(keep='first')]
    return result


def downsample_range(
    fetcher: Callable[[pd.Timestamp, pd.Timestamp], pd.DataFrame],
    output_start: pd.Timestamp,
    output_end: pd.Timestamp,
    target_cadence: str | pd.Timedelta,
    config: DownsampleConfig | None = None,
    edge_buffer_multiplier: float = 2.0,
    batch_size: str | pd.Timedelta | None = None,
) -> pd.DataFrame:
    """Downsample with automatic data fetching and edge buffering.

    Fetches data from an external source, downsamples it, and trims the
    result to the requested output range. Extra data is fetched at edges
    to ensure stable output at boundaries.

    Args:
        fetcher: Function that retrieves data for a given time range.
            Signature: fetcher(start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame
        output_start: Start of desired output time range.
        output_end: End of desired output time range.
        target_cadence: Target cadence as ISO duration string or Timedelta.
        config: Downsampling configuration. If None, uses default config.
        edge_buffer_multiplier: Multiplier for edge buffer calculation.
            Higher values provide more stable edges but require fetching
            more data.
        batch_size: If provided, processes the range in batches of this
            size. Useful when the data is too large to fetch at once.
            Accepts ISO duration strings (e.g., 'P1D') or Timedelta.

    Returns:
        Downsampled DataFrame covering the requested output range.

    Example:
        >>> def fetch_from_api(start, end):
        ...     return pd.DataFrame(
        ...         {'value': range(100)},
        ...         index=pd.date_range(start, end, periods=100)
        ...     )
        >>>
        >>> result = downsample_range(
        ...     fetcher=fetch_from_api,
        ...     output_start=pd.Timestamp('2024-01-01 00:00'),
        ...     output_end=pd.Timestamp('2024-01-01 12:00'),
        ...     target_cadence='1H'
        ... )
    """
    if config is None:
        config = DownsampleConfig()

    target_cadence = parse_cadence(target_cadence)

    if batch_size is not None:
        batch_size = parse_cadence(batch_size)
        return _downsample_range_batched(
            fetcher=fetcher,
            output_start=output_start,
            output_end=output_end,
            target_cadence=target_cadence,
            batch_size=batch_size,
            config=config,
            edge_buffer_multiplier=edge_buffer_multiplier,
        )

    return _downsample_single_range(
        fetcher=fetcher,
        output_start=output_start,
        output_end=output_end,
        target_cadence=target_cadence,
        config=config,
        edge_buffer_multiplier=edge_buffer_multiplier,
    )


def downsample_range_multi_aggregate(
    fetcher: Callable[[pd.Timestamp, pd.Timestamp], pd.DataFrame],
    output_start: pd.Timestamp,
    output_end: pd.Timestamp,
    target_cadence: str | pd.Timedelta,
    variables: list[str],
    aggregations: list[str] = ["min", "mean", "max"],
    config: DownsampleConfig | None = None,
    edge_buffer_multiplier: float = 2.0,
    batch_size: str | pd.Timedelta | None = None,
    min_completeness: float = 0.9,
    source_cadence: str | pd.Timedelta | None = None,
) -> pd.DataFrame:
    """Fetch data and create multi-aggregate columns (min/mean/max).

    Combines range-based fetching with multi-aggregate downsampling.
    Extra data is fetched at edges for stable output at boundaries.

    Args:
        fetcher: Function that retrieves data for a given time range.
        output_start: Start of desired output time range.
        output_end: End of desired output time range.
        target_cadence: Target cadence as ISO duration string or Timedelta.
        variables: List of column names to aggregate.
        aggregations: List of aggregation methods to apply.
            Default: ["min", "mean", "max"]
        config: Downsampling configuration. If None, uses default config.
        edge_buffer_multiplier: Multiplier for edge buffer calculation.
        batch_size: If provided, processes the range in batches.
        min_completeness: Minimum fraction of expected points (0.0-1.0).
        source_cadence: Original cadence for completeness calculation.

    Returns:
        DataFrame with aggregated columns named {variable}_{aggregation},
        covering the requested output range.

    Example:
        >>> result = downsample_range_multi_aggregate(
        ...     fetcher=fetch_from_api,
        ...     output_start=pd.Timestamp('2024-01-01'),
        ...     output_end=pd.Timestamp('2024-01-02'),
        ...     target_cadence='1H',
        ...     variables=['temperature', 'pressure'],
        ... )
    """
    from downsampler.aggregators import downsample_multi_aggregate

    if config is None:
        config = DownsampleConfig()

    target_cadence = parse_cadence(target_cadence)

    if batch_size is not None:
        batch_size_td = parse_cadence(batch_size)
        result = _multi_aggregate_batched(
            fetcher=fetcher,
            output_start=output_start,
            output_end=output_end,
            target_cadence=target_cadence,
            variables=variables,
            aggregations=aggregations,
            config=config,
            edge_buffer_multiplier=edge_buffer_multiplier,
            batch_size=batch_size_td,
            min_completeness=min_completeness,
            source_cadence=source_cadence,
        )
    else:
        # Single fetch
        edge_buffer = _compute_edge_buffer(
            target_cadence, config.edge_window, edge_buffer_multiplier
        )
        fetch_start, fetch_end = _expand_time_range(
            output_start, output_end, edge_buffer
        )

        df = fetcher(fetch_start, fetch_end)

        if df is None or len(df) == 0:
            return pd.DataFrame()

        result = downsample_multi_aggregate(
            df=df,
            target_cadence=target_cadence,
            variables=variables,
            aggregations=aggregations,
            min_completeness=min_completeness,
            source_cadence=source_cadence,
        )

        if len(result) == 0:
            return result

        result = _trim_to_range(result, output_start, output_end)

    result.attrs['downsampler'] = _build_metadata(
        'multi_aggregate', target_cadence, source_cadence
    )
    return result


def _multi_aggregate_batched(
    fetcher: Callable[[pd.Timestamp, pd.Timestamp], pd.DataFrame],
    output_start: pd.Timestamp,
    output_end: pd.Timestamp,
    target_cadence: pd.Timedelta,
    variables: list[str],
    aggregations: list[str],
    config: DownsampleConfig,
    edge_buffer_multiplier: float,
    batch_size: pd.Timedelta,
    min_completeness: float,
    source_cadence: str | pd.Timedelta | None,
) -> pd.DataFrame:
    """Multi-aggregate a large time range in batches."""
    from downsampler.aggregators import downsample_multi_aggregate

    results = []
    edge_buffer = _compute_edge_buffer(
        target_cadence, config.edge_window, edge_buffer_multiplier
    )

    current_start = output_start
    while current_start < output_end:
        current_end = min(current_start + batch_size, output_end)

        fetch_start, fetch_end = _expand_time_range(
            current_start, current_end, edge_buffer
        )

        df = fetcher(fetch_start, fetch_end)

        if df is not None and len(df) > 0:
            batch_result = downsample_multi_aggregate(
                df=df,
                target_cadence=target_cadence,
                variables=variables,
                aggregations=aggregations,
                min_completeness=min_completeness,
                source_cadence=source_cadence,
            )

            if len(batch_result) > 0:
                batch_result = _trim_to_range(
                    batch_result, current_start, current_end
                )
                if len(batch_result) > 0:
                    results.append(batch_result)

        current_start = current_end

    if not results:
        return pd.DataFrame()

    result = pd.concat(results).sort_index()
    result = result[~result.index.duplicated(keep='first')]
    return result


def downsample_range_resolutions(
    fetcher: Callable[[pd.Timestamp, pd.Timestamp], pd.DataFrame],
    output_start: pd.Timestamp,
    output_end: pd.Timestamp,
    cadences: list[str | pd.Timedelta],
    config: DownsampleConfig | None = None,
    edge_buffer_multiplier: float = 2.0,
) -> dict[pd.Timedelta, pd.DataFrame]:
    """Fetch data once and downsample to multiple cadences.

    Optimizes multi-resolution generation by computing the edge buffer
    for the coarsest cadence, fetching once, then downsampling at each
    cadence from the same data.

    Args:
        fetcher: Function that retrieves data for a given time range.
        output_start: Start of desired output time range.
        output_end: End of desired output time range.
        cadences: List of target cadences (ISO duration strings or Timedelta).
        config: Downsampling configuration. If None, uses default config.
        edge_buffer_multiplier: Multiplier for edge buffer calculation.

    Returns:
        Dictionary mapping each cadence (as Timedelta) to its
        downsampled DataFrame, trimmed to the output range.

    Example:
        >>> results = downsample_range_resolutions(
        ...     fetcher=fetch_from_api,
        ...     output_start=pd.Timestamp('2024-01-01'),
        ...     output_end=pd.Timestamp('2024-01-02'),
        ...     cadences=['1min', '5min', '1h'],
        ... )
    """
    from downsampler.core import downsample_dataframe

    if config is None:
        config = DownsampleConfig()

    cadences_td = [parse_cadence(c) for c in cadences]

    # Compute edge buffer for the coarsest cadence (largest) so a single
    # fetch covers all resolutions
    coarsest = max(cadences_td)
    edge_buffer = _compute_edge_buffer(
        coarsest, config.edge_window, edge_buffer_multiplier
    )
    fetch_start, fetch_end = _expand_time_range(
        output_start, output_end, edge_buffer
    )

    logging.debug(
        f"Fetching data from {fetch_start} to {fetch_end} "
        f"for {len(cadences_td)} resolutions"
    )

    df = fetcher(fetch_start, fetch_end)

    if df is None or len(df) == 0:
        return {c: pd.DataFrame() for c in cadences_td}

    config_no_edges = replace(config, edge_handling=EdgeHandling.KEEP)

    results = {}
    for cadence_td in cadences_td:
        result = downsample_dataframe(df, cadence_td, config_no_edges)
        if len(result) > 0:
            attrs = result.attrs.copy()
            result = _trim_to_range(result, output_start, output_end)
            result.attrs = attrs
        results[cadence_td] = result

    return results
