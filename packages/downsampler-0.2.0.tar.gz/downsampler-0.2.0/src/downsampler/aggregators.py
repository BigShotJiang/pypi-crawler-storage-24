"""Aggregation-based downsampling methods."""

import pandas as pd

from downsampler.config import DownsampleConfig, AggregationMethod
from downsampler.edges import apply_edge_handling
from downsampler.utils import parse_cadence, get_numeric_columns, filter_columns, estimate_cadence


def _apply_aggregation(
    df: pd.DataFrame,
    target_cadence: pd.Timedelta,
    method: str,
    columns: list[str] | None = None,
    source_cadence: pd.Timedelta | None = None,
    min_completeness: float = 0.9,
) -> pd.DataFrame:
    """Apply an aggregation method to downsample a DataFrame.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence for resampling.
        method: Aggregation method ('mean', 'median', 'min', 'max').
        columns: Columns to aggregate. If None, all numeric columns.
        source_cadence: Original cadence of the data. If None, estimated
            from data.
        min_completeness: Minimum fraction of expected points in a bucket
            for a valid output value. Buckets below this are set to NaN.

    Returns:
        Aggregated DataFrame.
    """
    if columns is None:
        columns = get_numeric_columns(df)

    if source_cadence is None and len(df) >= 2:
        source_cadence = estimate_cadence(df)

    resampler = df[columns].resample(target_cadence, origin='epoch')
    result = getattr(resampler, method)()

    # Apply completeness filtering when source_cadence is available
    if source_cadence is not None:
        counts = resampler.count()
        maxcount = target_cadence / source_cadence
        for col in columns:
            result[col] = result[col].where(
                counts[col] >= min_completeness * maxcount
            )

    # Shift timestamps to bucket midpoints (must be after completeness
    # filtering which uses the resampler's original bucket-start index)
    result.index = result.index + 0.5 * target_cadence

    return result


def downsample_mean(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    columns: list[str] | None = None,
    source_cadence: str | pd.Timedelta | None = None,
    min_completeness: float = 0.9,
) -> pd.DataFrame:
    """Downsample using mean aggregation.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence as ISO duration string or Timedelta.
        columns: Columns to include. If None, all numeric columns.
        source_cadence: Original cadence of the data. If None, estimated
            from data.
        min_completeness: Minimum fraction of expected points in a bucket
            for a valid output value.

    Returns:
        Downsampled DataFrame.

    Example:
        >>> df = pd.DataFrame(
        ...     {'value': range(100)},
        ...     index=pd.date_range('2024-01-01', periods=100, freq='1min')
        ... )
        >>> result = downsample_mean(df, '10min')
        >>> len(result)
        10
    """
    return _downsample_with_aggregation(
        df, target_cadence, 'mean', columns, source_cadence, min_completeness
    )


def downsample_median(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    columns: list[str] | None = None,
    source_cadence: str | pd.Timedelta | None = None,
    min_completeness: float = 0.9,
) -> pd.DataFrame:
    """Downsample using median aggregation.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence as ISO duration string or Timedelta.
        columns: Columns to include. If None, all numeric columns.
        source_cadence: Original cadence of the data. If None, estimated
            from data.
        min_completeness: Minimum fraction of expected points in a bucket
            for a valid output value.

    Returns:
        Downsampled DataFrame.
    """
    return _downsample_with_aggregation(
        df, target_cadence, 'median', columns, source_cadence, min_completeness
    )


def downsample_min(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    columns: list[str] | None = None,
    source_cadence: str | pd.Timedelta | None = None,
    min_completeness: float = 0.9,
) -> pd.DataFrame:
    """Downsample using minimum aggregation.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence as ISO duration string or Timedelta.
        columns: Columns to include. If None, all numeric columns.
        source_cadence: Original cadence of the data. If None, estimated
            from data.
        min_completeness: Minimum fraction of expected points in a bucket
            for a valid output value.

    Returns:
        Downsampled DataFrame.
    """
    return _downsample_with_aggregation(
        df, target_cadence, 'min', columns, source_cadence, min_completeness
    )


def downsample_max(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    columns: list[str] | None = None,
    source_cadence: str | pd.Timedelta | None = None,
    min_completeness: float = 0.9,
) -> pd.DataFrame:
    """Downsample using maximum aggregation.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence as ISO duration string or Timedelta.
        columns: Columns to include. If None, all numeric columns.
        source_cadence: Original cadence of the data. If None, estimated
            from data.
        min_completeness: Minimum fraction of expected points in a bucket
            for a valid output value.

    Returns:
        Downsampled DataFrame.
    """
    return _downsample_with_aggregation(
        df, target_cadence, 'max', columns, source_cadence, min_completeness
    )


def _downsample_with_aggregation(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    method: str,
    columns: list[str] | None = None,
    source_cadence: str | pd.Timedelta | None = None,
    min_completeness: float = 0.9,
) -> pd.DataFrame:
    """Internal function for aggregation-based downsampling.

    Args:
        df: Input DataFrame.
        target_cadence: Target cadence.
        method: Aggregation method.
        columns: Columns to include.
        source_cadence: Original cadence. If None, estimated from data.
        min_completeness: Minimum completeness fraction.

    Returns:
        Downsampled DataFrame.
    """
    target_cadence = parse_cadence(target_cadence)

    if source_cadence is not None:
        source_cadence = parse_cadence(source_cadence)

    return _apply_aggregation(
        df, target_cadence, method, columns, source_cadence, min_completeness
    )


def downsample_multi_aggregate(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    variables: list[str],
    aggregations: list[str] = ["min", "mean", "max"],
    min_completeness: float = 0.9,
    source_cadence: str | pd.Timedelta | None = None
) -> pd.DataFrame:
    """Create multiple aggregation columns for specified variables.

    Produces columns like 'density_min', 'density_mean', 'density_max'
    from a single 'density' column.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence as ISO duration string or Timedelta.
        variables: List of column names to aggregate.
        aggregations: List of aggregation methods to apply.
        min_completeness: Minimum fraction of expected points required
            for valid output (0.0 to 1.0).
        source_cadence: Original cadence of the data for completeness
            calculation. If None, estimated from data.

    Returns:
        DataFrame with aggregated columns named {variable}_{aggregation}.

    Example:
        >>> df = pd.DataFrame(
        ...     {'density': np.random.randn(1000), 'velocity': np.random.randn(1000)},
        ...     index=pd.date_range('2024-01-01', periods=1000, freq='1s')
        ... )
        >>> result = downsample_multi_aggregate(
        ...     df, '1min', ['density', 'velocity'], ['min', 'mean', 'max']
        ... )
        >>> list(result.columns)
        ['density_min', 'density_mean', 'density_max', 'velocity_min', 'velocity_mean', 'velocity_max', 'coverage']
    """
    target_cadence = parse_cadence(target_cadence)

    # Estimate source cadence if not provided
    if source_cadence is None:
        source_cadence = estimate_cadence(df)
    else:
        source_cadence = parse_cadence(source_cadence)

    # Compute statistics with count
    aggstats = [*aggregations, 'count']
    df_agg = df[variables].resample(
        target_cadence, label='left', origin='epoch'
    ).agg(aggstats)

    # Adjust index to middle of cadence (for proper time representation)
    df_agg.index = df_agg.index + 0.5 * target_cadence

    # Compute completeness/coverage
    maxcount = target_cadence / source_cadence
    coverage = df_agg[[(v, 'count') for v in variables]].apply(max, axis=1) / maxcount

    # Ensure aggregated columns are float so .where() can write NaN
    df_agg = df_agg.astype(float)

    # Set data to NaN if statistics are based on limited observations
    for var in variables:
        for aggstat in aggregations:
            df_agg.loc[:, (var, aggstat)] = (
                df_agg.loc[:, (var, aggstat)].where(
                    df_agg.loc[:, (var, 'count')] >= min_completeness * maxcount
                )
            )

    # Remove count columns
    for var in variables:
        df_agg.drop((var, "count"), axis=1, inplace=True)

    # Flatten multi-index columns to single index (e.g., "density_min")
    df_agg.columns = ["_".join(col_name) for col_name in df_agg.columns.to_flat_index()]

    # Add coverage column
    df_agg['coverage'] = coverage

    return df_agg


def downsample_with_config(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    config: DownsampleConfig
) -> pd.DataFrame:
    """Apply aggregation-based downsampling with full configuration.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence.
        config: Downsampling configuration.

    Returns:
        Downsampled DataFrame.
    """
    target_cadence = parse_cadence(target_cadence)

    # Determine columns to process
    columns = config.include_columns if config.include_columns else None

    # Map method to function
    method_map = {
        AggregationMethod.MEAN: 'mean',
        AggregationMethod.MEDIAN: 'median',
        AggregationMethod.MIN: 'min',
        AggregationMethod.MAX: 'max',
    }

    method_str = method_map.get(config.method)
    if method_str is None:
        raise ValueError(f"Method {config.method} is not an aggregation method")

    # Resolve source_cadence from config
    source_cadence = None
    if config.source_cadence is not None:
        source_cadence = parse_cadence(config.source_cadence)

    # Aggregators resample the full DataFrame — completeness filtering
    # NaN-ifies buckets spanning gaps that have insufficient input data.
    result = _apply_aggregation(
        df, target_cadence, method_str, columns,
        source_cadence, config.min_completeness
    )

    # Apply edge handling
    if len(result) > 0:
        result = apply_edge_handling(
            result,
            config.edge_handling,
            config.edge_window
        )

    # Filter out excluded columns
    result = result[filter_columns(result, exclude=config.exclude_columns)]

    return result
