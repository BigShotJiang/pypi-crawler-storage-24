"""downsampler - Timeseries DataFrame downsampling with LTTB, M4, aggregation methods, and fidelity testing.

This package provides tools for downsampling time series data in pandas DataFrames,
with support for:
- LTTB (Largest Triangle Three Buckets) algorithm for visual fidelity
- M4 (Min-Max-First-Last) algorithm for guaranteed extrema preservation
- Multiple aggregation methods (mean, median, min, max)
- Gap-aware processing
- Edge handling strategies
- Range-based downsampling with automatic edge buffering
- Fidelity testing and comparison

Example:
    >>> import pandas as pd
    >>> from downsampler import downsample_dataframe, DownsampleConfig, AggregationMethod
    >>>
    >>> # Create sample data
    >>> df = pd.DataFrame(
    ...     {'value': [1, 2, 3, 4, 5]},
    ...     index=pd.date_range('2024-01-01', periods=5, freq='1min')
    ... )
    >>>
    >>> # Downsample using mean
    >>> result = downsample_dataframe(df, target_cadence='5min')
    >>>
    >>> # Downsample using LTTB
    >>> config = DownsampleConfig(
    ...     method=AggregationMethod.LTTB,
    ...     lttb_target_column='value'
    ... )
    >>> result = downsample_dataframe(df, target_cadence='5min', config=config)
"""

from downsampler.config import (
    AggregationMethod,
    EdgeHandling,
    DownsampleConfig,
)
from downsampler.core import (
    downsample_dataframe,
    downsample_dataframe_multi_aggregate,
    downsample_dataframe_resolutions,
)
from downsampler.gaps import (
    find_gap_indices,
    groupby_gaps,
    split_at_gaps,
    wrap_in_nans,
    mark_gaps_in_dataframe,
    interpolate_small_gaps,
    concatenate_with_gap_markers,
)
from downsampler.lttb import downsample_lttb
from downsampler.m4 import downsample_m4
from downsampler.aggregators import (
    downsample_mean,
    downsample_median,
    downsample_min,
    downsample_max,
)
from downsampler.ranged import (
    downsample_range,
    downsample_range_multi_aggregate,
    downsample_range_resolutions,
    DataFetcher,
)

__version__ = "0.2.0"

__all__ = [
    # Config
    "AggregationMethod",
    "EdgeHandling",
    "DownsampleConfig",
    # Core — DataFrame mode
    "downsample_dataframe",
    "downsample_dataframe_multi_aggregate",
    "downsample_dataframe_resolutions",
    # Core — Range mode
    "downsample_range",
    "downsample_range_multi_aggregate",
    "downsample_range_resolutions",
    "DataFetcher",
    # Gaps
    "find_gap_indices",
    "groupby_gaps",
    "split_at_gaps",
    "wrap_in_nans",
    "mark_gaps_in_dataframe",
    "interpolate_small_gaps",
    "concatenate_with_gap_markers",
    # LTTB
    "downsample_lttb",
    # M4
    "downsample_m4",
    # Aggregators
    "downsample_mean",
    "downsample_median",
    "downsample_min",
    "downsample_max",
]
