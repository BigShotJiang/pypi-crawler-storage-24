"""Core downsampling functions."""

import pandas as pd

from downsampler.config import DownsampleConfig, AggregationMethod
from downsampler.utils import parse_cadence, _build_metadata
from downsampler.lttb import downsample_lttb_with_config
from downsampler.m4 import downsample_m4_with_config
from downsampler.aggregators import downsample_with_config as aggregate_with_config
from downsampler.aggregators import downsample_multi_aggregate as _downsample_multi_aggregate


def downsample_dataframe(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    config: DownsampleConfig | None = None,
    **kwargs
) -> pd.DataFrame:
    """Downsample a DataFrame to a lower cadence.

    This is the main entry point for downsampling operations. It supports
    multiple methods including LTTB and various aggregation methods.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence as ISO duration string (e.g., "PT1H")
            or pandas Timedelta.
        config: Downsampling configuration. If None, uses default config
            with mean aggregation.
        **kwargs: Additional keyword arguments that override config settings.
            Supported kwargs:
            - method: AggregationMethod or string ('mean', 'lttb', 'm4', etc.)
            - lttb_target_column: Column to optimize for LTTB
            - m4_deduplicate: For M4, whether to deduplicate consecutive indices
            - m4_collinearity_threshold: For M4, collinearity filtering threshold (0.0-1.0)
            - include_columns: Columns to include
            - exclude_columns: Columns to exclude
            - gap_threshold: Gap threshold
            - edge_handling: Edge handling strategy
            - edge_window: Edge window size

    Returns:
        Downsampled DataFrame.

    Examples:
        Basic mean downsampling:
        >>> df = pd.DataFrame(
        ...     {'value': range(100)},
        ...     index=pd.date_range('2024-01-01', periods=100, freq='1min')
        ... )
        >>> result = downsample_dataframe(df, '10min')
        >>> len(result)
        10

        LTTB downsampling:
        >>> from downsampler import AggregationMethod, DownsampleConfig
        >>> config = DownsampleConfig(
        ...     method=AggregationMethod.LTTB,
        ...     lttb_target_column='value'
        ... )
        >>> result = downsample_dataframe(df, '10min', config=config)

        Using kwargs:
        >>> result = downsample_dataframe(df, '10min', method='max')
    """
    # Create config if not provided
    if config is None:
        config = DownsampleConfig()

    # Apply kwargs overrides
    if kwargs:
        config = _apply_kwargs_to_config(config, kwargs)

    target_cadence = parse_cadence(target_cadence)

    # Route to appropriate implementation
    if config.method == AggregationMethod.LTTB:
        result = downsample_lttb_with_config(df, target_cadence, config)
    elif config.method == AggregationMethod.M4:
        result = downsample_m4_with_config(df, target_cadence, config)
    else:
        result = aggregate_with_config(df, target_cadence, config)

    result.attrs['downsampler'] = _build_metadata(
        config.method.value, target_cadence, config.source_cadence
    )
    return result


def downsample_dataframe_multi_aggregate(
    df: pd.DataFrame,
    target_cadence: str | pd.Timedelta,
    variables: list[str],
    aggregations: list[str] = ["min", "mean", "max"],
    config: DownsampleConfig | None = None,
    **kwargs
) -> pd.DataFrame:
    """Create columns like 'input_min', 'input_mean', 'input_max'.

    This function creates multiple aggregated columns from each input
    variable, useful for showing data ranges in visualizations.

    Args:
        df: Input DataFrame with DatetimeIndex.
        target_cadence: Target cadence as ISO duration string or Timedelta.
        variables: List of column names to aggregate.
        aggregations: List of aggregation methods to apply.
            Default: ["min", "mean", "max"]
        config: Downsampling configuration (used for min_completeness if
            specified in a future version).
        **kwargs: Additional keyword arguments:
            - min_completeness: Minimum fraction of expected points (0.0-1.0)
            - source_cadence: Original cadence for completeness calculation

    Returns:
        DataFrame with aggregated columns named {variable}_{aggregation}.

    Example:
        >>> import numpy as np
        >>> df = pd.DataFrame(
        ...     {'density': np.random.randn(1000), 'velocity': np.random.randn(1000)},
        ...     index=pd.date_range('2024-01-01', periods=1000, freq='1s')
        ... )
        >>> result = downsample_dataframe_multi_aggregate(
        ...     df, '1min', ['density', 'velocity']
        ... )
        >>> 'density_min' in result.columns
        True
        >>> 'density_mean' in result.columns
        True
        >>> 'density_max' in result.columns
        True
    """
    min_completeness = kwargs.get('min_completeness', 0.9)
    source_cadence = kwargs.get('source_cadence', None)

    target_cadence_td = parse_cadence(target_cadence)

    result = _downsample_multi_aggregate(
        df=df,
        target_cadence=target_cadence_td,
        variables=variables,
        aggregations=aggregations,
        min_completeness=min_completeness,
        source_cadence=source_cadence
    )

    result.attrs['downsampler'] = _build_metadata(
        'multi_aggregate', target_cadence_td, source_cadence
    )
    return result


def downsample_dataframe_resolutions(
    df: pd.DataFrame,
    cadences: list[str | pd.Timedelta],
    config: DownsampleConfig | None = None,
    **kwargs
) -> dict[pd.Timedelta, pd.DataFrame]:
    """Downsample a DataFrame to multiple cadences at once.

    Generates a resolution pyramid — downsampled versions at each
    requested cadence. Useful for pre-computing multi-resolution
    datasets for storage and API serving.

    Args:
        df: Input DataFrame with DatetimeIndex.
        cadences: List of target cadences (ISO duration strings or Timedelta).
        config: Downsampling configuration. If None, uses default config.
        **kwargs: Additional keyword arguments passed to downsample_dataframe.

    Returns:
        Dictionary mapping each cadence (as Timedelta) to its
        downsampled DataFrame.

    Example:
        >>> results = downsample_dataframe_resolutions(
        ...     df, ['1min', '5min', '15min', '1h']
        ... )
        >>> for cadence, result_df in results.items():
        ...     print(f"{cadence}: {len(result_df)} points")
    """
    results = {}
    for cadence in cadences:
        cadence_td = parse_cadence(cadence)
        results[cadence_td] = downsample_dataframe(
            df, cadence_td, config=config, **kwargs
        )
    return results


def _apply_kwargs_to_config(
    config: DownsampleConfig,
    kwargs: dict
) -> DownsampleConfig:
    """Apply keyword arguments to a config, creating a new config.

    Args:
        config: Base configuration.
        kwargs: Keyword arguments to apply.

    Returns:
        New configuration with kwargs applied.
    """
    from dataclasses import replace

    # Map string method names to enum values
    if 'method' in kwargs:
        method = kwargs['method']
        if isinstance(method, str):
            kwargs['method'] = AggregationMethod(method)

    # Filter to only valid config fields
    valid_fields = {
        'method', 'lttb_target_column', 'm4_deduplicate', 'm4_collinearity_threshold',
        'include_columns', 'exclude_columns', 'gap_threshold',
        'edge_handling', 'edge_window', 'min_points_per_segment', 'source_cadence',
        'min_completeness'
    }
    filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_fields}

    return replace(config, **filtered_kwargs)
