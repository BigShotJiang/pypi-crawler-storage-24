"""Comparison engine for evaluating downsampling methods and cadences."""

from dataclasses import dataclass
import pandas as pd

from downsampler.config import DownsampleConfig, AggregationMethod
from downsampler.core import downsample_dataframe
from downsampler.fidelity.metrics import FidelityMetrics, compute_metrics
from downsampler.utils import parse_cadence


@dataclass
class ComparisonResult:
    """Result of a single downsampling comparison.

    Attributes:
        method: The aggregation method used.
        cadence: The target cadence.
        metrics: Fidelity metrics for this result.
        config: The full configuration used.
        downsampled: The downsampled DataFrame (optional, may be None if not stored).
    """
    method: AggregationMethod
    cadence: pd.Timedelta
    metrics: FidelityMetrics
    config: DownsampleConfig
    downsampled: pd.DataFrame | None = None

    def to_dict(self) -> dict:
        """Convert result to a dictionary."""
        return {
            'method': self.method.value,
            'cadence': str(self.cadence),
            **self.metrics.to_dict(),
        }


class FidelityComparison:
    """Engine for comparing downsampling methods and cadences.

    Example:
        >>> comp = FidelityComparison(df, 'signal')
        >>> results = comp.compare('PT10S')
        >>> print(summary_table(results))
    """

    def __init__(self, original_df: pd.DataFrame, column: str):
        """Initialize the comparison engine.

        Args:
            original_df: The original high-cadence DataFrame.
            column: The column to use for comparisons.
        """
        self.original_df = original_df
        self.column = column

    def compare(
        self,
        cadences: str | pd.Timedelta | list[str | pd.Timedelta],
        methods: AggregationMethod | list[AggregationMethod] | None = None,
        lttb_target_column: str | None = None,
        store_downsampled: bool = False,
    ) -> list[ComparisonResult]:
        """Compare downsampling methods across one or more cadences.

        Args:
            cadences: Target cadence(s). Scalar or list.
            methods: Method(s) to compare. Scalar, list, or None for all.
            lttb_target_column: Column to optimize for LTTB. Defaults to
                the comparison column.
            store_downsampled: Whether to store downsampled DataFrames in results.

        Returns:
            List of ComparisonResult objects.
        """
        # Normalize cadences to list
        if not isinstance(cadences, list):
            cadences = [cadences]
        parsed_cadences = [parse_cadence(c) for c in cadences]

        # Normalize methods to list
        if methods is None:
            method_list = list(AggregationMethod)
        elif isinstance(methods, AggregationMethod):
            method_list = [methods]
        else:
            method_list = methods

        if lttb_target_column is None:
            lttb_target_column = self.column

        results = []
        for cadence in parsed_cadences:
            for method in method_list:
                result = self._run_one(cadence, method, lttb_target_column, store_downsampled)
                if result is not None:
                    results.append(result)

        return results

    def _run_one(
        self,
        cadence: pd.Timedelta,
        method: AggregationMethod,
        lttb_target_column: str,
        store_downsampled: bool,
    ) -> ComparisonResult | None:
        """Run a single downsampling comparison.

        Returns None on failure (with a warning printed).
        """
        config = DownsampleConfig(
            method=method,
            lttb_target_column=lttb_target_column if method == AggregationMethod.LTTB else None,
        )

        try:
            downsampled = downsample_dataframe(self.original_df, cadence, config)
        except Exception as e:
            print(f"Warning: {method.value} at {cadence} failed: {e}")
            return None

        if len(downsampled) == 0:
            return None

        metrics = compute_metrics(self.original_df, downsampled, self.column)

        return ComparisonResult(
            method=method,
            cadence=cadence,
            metrics=metrics,
            config=config,
            downsampled=downsampled if store_downsampled else None,
        )


def summary_table(results: list[ComparisonResult]) -> pd.DataFrame:
    """Generate a summary table from comparison results.

    Args:
        results: List of results to summarize.

    Returns:
        DataFrame with metrics for each method/cadence combination.
    """
    if not results:
        return pd.DataFrame()

    rows = [r.to_dict() for r in results]
    return pd.DataFrame(rows)
