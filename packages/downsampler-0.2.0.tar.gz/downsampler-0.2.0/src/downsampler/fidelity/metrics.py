"""Statistical metrics for evaluating downsampling fidelity."""

from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy import stats


@dataclass
class FidelityMetrics:
    """Metrics for evaluating the fidelity of downsampled data.

    Attributes:
        mae: Mean Absolute Error between original and interpolated downsampled.
        rmse: Root Mean Square Error.
        max_error: Maximum absolute error.
        pearson_r: Pearson correlation coefficient.
        reduction_ratio: Ratio of original rows to downsampled rows.
    """
    mae: float
    rmse: float
    max_error: float
    pearson_r: float
    reduction_ratio: float

    def to_dict(self) -> dict:
        """Convert metrics to a dictionary."""
        return {
            'mae': self.mae,
            'rmse': self.rmse,
            'max_error': self.max_error,
            'pearson_r': self.pearson_r,
            'reduction_ratio': self.reduction_ratio,
        }

    def __str__(self) -> str:
        """Format metrics as a readable string."""
        return (
            f"FidelityMetrics(\n"
            f"  MAE: {self.mae:.6f}\n"
            f"  RMSE: {self.rmse:.6f}\n"
            f"  Max Error: {self.max_error:.6f}\n"
            f"  Pearson r: {self.pearson_r:.4f}\n"
            f"  Reduction: {self.reduction_ratio:.1f}x\n"
            f")"
        )


def compute_metrics(
    original: pd.DataFrame,
    downsampled: pd.DataFrame,
    column: str,
) -> FidelityMetrics:
    """Compute fidelity metrics comparing original and downsampled data.

    The downsampled data is interpolated back to the original timestamps
    for comparison.

    Args:
        original: Original high-cadence DataFrame.
        downsampled: Downsampled DataFrame.
        column: Column name to compare.

    Returns:
        FidelityMetrics containing comparison metrics.

    Example:
        >>> original = pd.DataFrame(
        ...     {'value': np.sin(np.linspace(0, 10*np.pi, 1000))},
        ...     index=pd.date_range('2024-01-01', periods=1000, freq='1s')
        ... )
        >>> downsampled = original.resample('10s').mean()
        >>> metrics = compute_metrics(original, downsampled, 'value')
        >>> metrics.pearson_r > 0.9
        True
    """
    # Get original values
    orig_values = original[column].dropna()
    if len(orig_values) == 0:
        return _empty_metrics()

    # Interpolate downsampled to original timestamps
    ds_values = downsampled[column].dropna()
    if len(ds_values) < 2:
        return _empty_metrics()

    # Create interpolated values at original timestamps
    orig_times_numeric = (orig_values.index - orig_values.index[0]) / pd.Timedelta('1s')
    ds_times_numeric = (ds_values.index - orig_values.index[0]) / pd.Timedelta('1s')

    # Only interpolate within the range of downsampled data
    mask = (orig_values.index >= ds_values.index[0]) & (orig_values.index <= ds_values.index[-1])
    orig_in_range = orig_values[mask]
    orig_times_in_range = orig_times_numeric[mask]

    if len(orig_in_range) == 0:
        return _empty_metrics()

    interpolated = np.interp(
        orig_times_in_range.values,
        ds_times_numeric.values,
        ds_values.values
    )

    # Compute basic metrics
    errors = orig_in_range.values - interpolated
    mae = np.mean(np.abs(errors))
    rmse = np.sqrt(np.mean(errors**2))
    max_error = np.max(np.abs(errors))

    # Pearson correlation
    if len(orig_in_range) > 1 and np.std(orig_in_range.values) > 0 and np.std(interpolated) > 0:
        pearson_r, _ = stats.pearsonr(orig_in_range.values, interpolated)
    else:
        pearson_r = 1.0 if np.allclose(orig_in_range.values, interpolated) else 0.0

    # Reduction ratio
    reduction_ratio = len(original) / len(downsampled) if len(downsampled) > 0 else float('inf')

    return FidelityMetrics(
        mae=mae,
        rmse=rmse,
        max_error=max_error,
        pearson_r=pearson_r,
        reduction_ratio=reduction_ratio,
    )


def _empty_metrics() -> FidelityMetrics:
    """Return empty/NaN metrics when comparison isn't possible."""
    return FidelityMetrics(
        mae=np.nan,
        rmse=np.nan,
        max_error=np.nan,
        pearson_r=np.nan,
        reduction_ratio=np.nan,
    )
