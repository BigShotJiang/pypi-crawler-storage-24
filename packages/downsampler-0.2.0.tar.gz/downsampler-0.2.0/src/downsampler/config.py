"""Configuration dataclasses and enums for downsampler."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Union

import pandas as pd


class AggregationMethod(str, Enum):
    """Aggregation methods for downsampling."""
    MEAN = "mean"
    MEDIAN = "median"
    MIN = "min"
    MAX = "max"
    LTTB = "lttb"
    M4 = "m4"


class EdgeHandling(str, Enum):
    """Strategies for handling edge points in downsampled data."""
    DISCARD = "discard"     # Remove edge points
    FLAG = "flag"           # Keep edges, add '_is_edge' column
    KEEP = "keep"           # Keep as-is


@dataclass
class DownsampleConfig:
    """Configuration for downsampling operations.

    Attributes:
        method: The aggregation method to use for downsampling.
        lttb_target_column: For LTTB, the column to optimize visual fidelity for.
        m4_deduplicate: For M4, whether to remove consecutive duplicate indices.
        m4_collinearity_threshold: For M4, threshold for filtering collinear points.
            None disables filtering, 0.0-1.0 sets the threshold as a fraction of
            the value range. Points closer to the first-last line than this threshold
            will be filtered out.
        m4_target_points_per_bucket: For M4, expected average number of points per bucket.
            Used to adjust bucket size so target_cadence represents average output cadence.
            Default 3.0 accounts for deduplication reducing 4 points to ~3 on average.
            Set to 1.0 to use original behavior (bucket_size = target_cadence).
        include_columns: Columns to include in the output (empty means all).
        exclude_columns: Columns to exclude from the output.
        gap_threshold: Minimum duration to consider as a gap.
            "auto" means 2x the target cadence.
        edge_handling: Strategy for handling edge points.
        edge_window: Number of points at each edge to consider as edge points.
        min_points_per_segment: Minimum points required in a segment for processing.
        source_cadence: Expected cadence of the source data. Used by LTTB to
            interpolate small gaps and by aggregators for completeness
            calculation. If None, estimated from data.
        min_completeness: Minimum fraction of expected points in a resample
            bucket required for a valid output value (0.0 to 1.0). Buckets
            with fewer points are set to NaN. Default 0.9.
    """
    method: AggregationMethod = AggregationMethod.MEAN
    lttb_target_column: str | None = None
    m4_deduplicate: bool = True
    m4_collinearity_threshold: float | None = None
    m4_target_points_per_bucket: float = 3.0
    include_columns: list[str] = field(default_factory=list)
    exclude_columns: list[str] = field(default_factory=list)
    gap_threshold: Union[str, pd.Timedelta] = "auto"
    edge_handling: EdgeHandling = EdgeHandling.KEEP
    edge_window: int = 2
    min_points_per_segment: int = 3
    source_cadence: Union[str, pd.Timedelta, None] = None
    min_completeness: float = 0.9

    def get_gap_threshold(self, target_cadence: pd.Timedelta) -> pd.Timedelta:
        """Get the gap threshold, computing auto value if needed.

        Args:
            target_cadence: The target cadence for downsampling.

        Returns:
            The gap threshold as a Timedelta.
        """
        if self.gap_threshold == "auto":
            return 2 * target_cadence
        elif isinstance(self.gap_threshold, str):
            return pd.to_timedelta(self.gap_threshold)
        return self.gap_threshold
