"""Tests for fidelity testing functionality."""

import pytest
import pandas as pd
import numpy as np

from downsampler.fidelity.metrics import FidelityMetrics, compute_metrics
from downsampler.fidelity.comparison import FidelityComparison, ComparisonResult, summary_table
from downsampler.config import AggregationMethod


class TestFidelityMetrics:
    """Tests for FidelityMetrics dataclass."""

    def test_to_dict(self):
        """Test conversion to dictionary."""
        metrics = FidelityMetrics(
            mae=0.1,
            rmse=0.15,
            max_error=0.5,
            pearson_r=0.99,
            reduction_ratio=10.0,
        )

        d = metrics.to_dict()
        assert d['mae'] == 0.1
        assert d['rmse'] == 0.15
        assert d['pearson_r'] == 0.99
        assert d['reduction_ratio'] == 10.0
        assert len(d) == 5

    def test_str(self):
        """Test string representation."""
        metrics = FidelityMetrics(
            mae=0.1, rmse=0.15, max_error=0.5, pearson_r=0.99, reduction_ratio=10.0,
        )
        s = str(metrics)
        assert 'RMSE' in s
        assert 'Reduction' in s


class TestComputeMetrics:
    """Tests for compute_metrics function."""

    def test_identical_data(self, sine_df):
        """Test metrics for identical data."""
        metrics = compute_metrics(sine_df, sine_df, 'signal')

        assert metrics.mae == pytest.approx(0, abs=1e-10)
        assert metrics.rmse == pytest.approx(0, abs=1e-10)
        assert metrics.pearson_r == pytest.approx(1.0, abs=1e-10)
        assert metrics.reduction_ratio == pytest.approx(1.0)

    def test_downsampled_data(self, sine_df):
        """Test metrics for downsampled data."""
        downsampled = sine_df.resample('10s').mean()

        metrics = compute_metrics(sine_df, downsampled, 'signal')

        assert metrics.mae > 0
        assert metrics.pearson_r > 0.9
        assert metrics.reduction_ratio == pytest.approx(10, rel=0.2)

    def test_empty_data(self):
        """Test metrics for empty data."""
        empty = pd.DataFrame({'value': []}, index=pd.DatetimeIndex([]))
        metrics = compute_metrics(empty, empty, 'value')

        assert np.isnan(metrics.mae)
        assert np.isnan(metrics.reduction_ratio)


class TestFidelityComparison:
    """Tests for FidelityComparison class."""

    def test_compare_single_cadence_all_methods(self, sine_df):
        """Test comparing all methods at a single cadence."""
        comp = FidelityComparison(sine_df, 'signal')
        results = comp.compare('PT10S')

        # Should have results for multiple methods
        assert len(results) >= 2

        # All results should have valid metrics
        for r in results:
            assert not np.isnan(r.metrics.rmse)
            assert r.metrics.reduction_ratio > 1

    def test_compare_multiple_cadences_single_method(self, sine_df):
        """Test comparing different cadences with a fixed method."""
        comp = FidelityComparison(sine_df, 'signal')
        results = comp.compare(
            ['PT5S', 'PT10S', 'PT30S'],
            methods=AggregationMethod.MEAN,
        )

        assert len(results) == 3

        # Higher cadence should generally have lower error
        rmses = [r.metrics.rmse for r in results]
        assert rmses[0] <= rmses[2]  # 5s should have lower error than 30s

    def test_compare_grid(self, sine_df):
        """Test comparing multiple cadences and methods."""
        comp = FidelityComparison(sine_df, 'signal')
        results = comp.compare(
            ['PT5S', 'PT10S'],
            methods=[AggregationMethod.MEAN, AggregationMethod.LTTB],
        )

        # 2 cadences x 2 methods = 4 results
        assert len(results) == 4

    def test_compare_store_downsampled(self, sine_df):
        """Test that store_downsampled=True stores the data."""
        comp = FidelityComparison(sine_df, 'signal')
        results = comp.compare('PT10S', methods=AggregationMethod.MEAN, store_downsampled=True)

        assert len(results) == 1
        assert results[0].downsampled is not None
        assert len(results[0].downsampled) < len(sine_df)

    def test_compare_no_store_downsampled(self, sine_df):
        """Test that store_downsampled=False does not store data."""
        comp = FidelityComparison(sine_df, 'signal')
        results = comp.compare('PT10S', methods=AggregationMethod.MEAN, store_downsampled=False)

        assert results[0].downsampled is None

    def test_summary_table(self, sine_df):
        """Test standalone summary_table function."""
        comp = FidelityComparison(sine_df, 'signal')
        results = comp.compare('PT10S')

        table = summary_table(results)

        assert isinstance(table, pd.DataFrame)
        assert 'method' in table.columns
        assert 'rmse' in table.columns
        assert 'reduction_ratio' in table.columns
        assert len(table) == len(results)

    def test_summary_table_empty(self):
        """Test summary_table with empty results."""
        table = summary_table([])
        assert isinstance(table, pd.DataFrame)
        assert len(table) == 0

    def test_comparison_result_to_dict(self, sine_df):
        """Test ComparisonResult.to_dict includes all fields."""
        comp = FidelityComparison(sine_df, 'signal')
        results = comp.compare('PT10S', methods=AggregationMethod.MEAN)
        d = results[0].to_dict()

        assert 'method' in d
        assert 'cadence' in d
        assert 'rmse' in d
        assert 'reduction_ratio' in d


