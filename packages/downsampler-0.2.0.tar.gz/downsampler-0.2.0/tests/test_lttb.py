"""Tests for LTTB downsampling."""

import pytest
import pandas as pd
import numpy as np

from downsampler.lttb import downsample_lttb, downsample_lttb_with_config
from downsampler.config import DownsampleConfig, AggregationMethod


class TestDownsampleLttb:
    """Tests for LTTB downsampling function."""

    def test_basic_lttb(self, sine_df):
        """Test basic LTTB downsampling."""
        result = downsample_lttb(
            sine_df,
            target_column='signal',
            target_cadence='PT10S'
        )

        assert len(result) < len(sine_df)
        assert 'signal' in result.columns

    def test_preserves_extreme_values(self, sine_df):
        """Test that LTTB preserves extreme values reasonably well."""
        result = downsample_lttb(
            sine_df,
            target_column='signal',
            target_cadence='PT10S'
        )

        # Check that max/min are close to original
        orig_max = sine_df['signal'].max()
        orig_min = sine_df['signal'].min()
        result_max = result['signal'].max()
        result_min = result['signal'].min()

        # Allow 10% tolerance
        assert abs(result_max - orig_max) < 0.1 * abs(orig_max)
        assert abs(result_min - orig_min) < 0.1 * abs(orig_min - orig_max)

    def test_include_columns(self, sine_df):
        """Test including additional columns."""
        result = downsample_lttb(
            sine_df,
            target_column='signal',
            target_cadence='PT10S',
            include_columns=['signal', 'noise']
        )

        assert 'signal' in result.columns
        assert 'noise' in result.columns

    def test_gap_handling(self, gappy_df):
        """Test LTTB with gappy data."""
        # Add a target column
        gappy_df['signal'] = np.sin(np.linspace(0, 4 * np.pi, len(gappy_df)))

        result = downsample_lttb(
            gappy_df,
            target_column='signal',
            target_cadence='PT5M',
            gap_threshold=pd.Timedelta('30min')
        )

        # Should produce output from both segments
        assert len(result) > 0

    def test_insufficient_points(self):
        """Test handling of insufficient points."""
        small_df = pd.DataFrame(
            {'value': [1, 2]},
            index=pd.date_range('2024-01-01', periods=2, freq='1s')
        )

        result = downsample_lttb(
            small_df,
            target_column='value',
            target_cadence='PT10S',
            min_points_per_segment=3
        )

        # Should return empty or minimal result
        assert len(result) == 0


class TestLttbGapHandling:
    """Tests for LTTB gap handling behavior."""

    def test_lttb_inserts_nan_markers_at_large_gaps(self):
        """Test that LTTB output contains NaN markers between segments."""
        # Two segments with a large gap between them
        times1 = pd.date_range('2024-01-01 00:00', periods=100, freq='1s')
        times2 = pd.date_range('2024-01-01 01:00', periods=100, freq='1s')
        t1 = np.linspace(0, 4 * np.pi, 100)
        t2 = np.linspace(0, 4 * np.pi, 100)
        df = pd.concat([
            pd.DataFrame({'signal': np.sin(t1)}, index=times1),
            pd.DataFrame({'signal': np.sin(t2)}, index=times2),
        ])

        result = downsample_lttb(
            df,
            target_column='signal',
            target_cadence='PT10S',
            gap_threshold=pd.Timedelta('5min'),
        )

        # Should have NaN markers
        assert result['signal'].isna().sum() > 0

    def test_lttb_interpolates_small_gaps(self):
        """Test that small gaps are filled before LTTB processes."""
        # Data with a small 5-second gap (below gap_threshold of 30s)
        times = list(pd.date_range('2024-01-01 00:00', periods=50, freq='1s'))
        # Remove 3 points to create a small gap
        del times[25:28]
        t = np.linspace(0, 4 * np.pi, len(times))
        df = pd.DataFrame({'signal': np.sin(t)}, index=pd.DatetimeIndex(times))

        result = downsample_lttb(
            df,
            target_column='signal',
            target_cadence='PT5S',
            gap_threshold=pd.Timedelta('30s'),
            source_cadence=pd.Timedelta('1s'),
        )

        # Should NOT have NaN markers (gap was small and interpolated)
        assert result['signal'].isna().sum() == 0
        assert len(result) > 0

    def test_lttb_source_cadence_via_config(self):
        """Test that source_cadence is passed through config."""
        times1 = pd.date_range('2024-01-01 00:00', periods=100, freq='1s')
        times2 = pd.date_range('2024-01-01 01:00', periods=100, freq='1s')
        t = np.linspace(0, 4 * np.pi, 100)
        df = pd.concat([
            pd.DataFrame({'signal': np.sin(t)}, index=times1),
            pd.DataFrame({'signal': np.sin(t)}, index=times2),
        ])

        config = DownsampleConfig(
            method=AggregationMethod.LTTB,
            lttb_target_column='signal',
            source_cadence='PT1S',
        )

        result = downsample_lttb_with_config(df, 'PT10S', config)
        assert len(result) > 0


class TestDownsampleLttbWithConfig:
    """Tests for LTTB downsampling with config."""

    def test_with_config(self, sine_df):
        """Test LTTB with full configuration."""
        config = DownsampleConfig(
            method=AggregationMethod.LTTB,
            lttb_target_column='signal',
            min_points_per_segment=5
        )

        result = downsample_lttb_with_config(
            sine_df,
            'PT10S',
            config
        )

        assert len(result) > 0

    def test_missing_target_column_raises(self, sine_df):
        """Test that missing target column raises error."""
        config = DownsampleConfig(method=AggregationMethod.LTTB)

        with pytest.raises(ValueError, match="lttb_target_column"):
            downsample_lttb_with_config(sine_df, 'PT10S', config)
