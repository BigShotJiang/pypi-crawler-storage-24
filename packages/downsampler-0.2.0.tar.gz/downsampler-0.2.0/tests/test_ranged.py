"""Tests for range-based downsampling API."""

import pytest
import pandas as pd
import numpy as np

from downsampler.ranged import (
    downsample_range,
    downsample_range_multi_aggregate,
    downsample_range_resolutions,
)
from downsampler.config import DownsampleConfig, AggregationMethod


def create_test_fetcher(cadence='1s', value_func=None):
    """Create a test fetcher function."""
    def fetcher(start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
        index = pd.date_range(start, end, freq=cadence)
        if len(index) == 0:
            return pd.DataFrame({'value': []}, index=pd.DatetimeIndex([]))

        if value_func is None:
            # Default: sine wave
            t = np.linspace(0, 2 * np.pi, len(index))
            values = np.sin(t)
        else:
            values = value_func(index)

        return pd.DataFrame({'value': values}, index=index)

    return fetcher


class TestDownsampleRange:
    """Tests for downsample_range function."""

    def test_basic_range(self):
        """Test basic range downsampling."""
        fetcher = create_test_fetcher()

        result = downsample_range(
            fetcher=fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 01:00'),
            target_cadence='PT1M'
        )

        assert len(result) > 0
        assert result.index[0] >= pd.Timestamp('2024-01-01 00:00')
        assert result.index[-1] < pd.Timestamp('2024-01-01 01:00')

    def test_with_config(self):
        """Test range downsampling with config."""
        fetcher = create_test_fetcher()
        config = DownsampleConfig(method=AggregationMethod.MAX)

        result = downsample_range(
            fetcher=fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 01:00'),
            target_cadence='PT5M',
            config=config
        )

        assert len(result) > 0

    def test_empty_fetch_result(self):
        """Test handling of empty fetch result."""
        def empty_fetcher(start, end):
            return pd.DataFrame({'value': []}, index=pd.DatetimeIndex([]))

        result = downsample_range(
            fetcher=empty_fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 01:00'),
            target_cadence='PT1M'
        )

        assert len(result) == 0


class TestDownsampleRangeBatched:
    """Tests for downsample_range with batch_size."""

    def test_basic_batch(self):
        """Test basic batch downsampling."""
        fetcher = create_test_fetcher()

        result = downsample_range(
            fetcher=fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 06:00'),
            target_cadence='PT10M',
            batch_size='PT1H'
        )

        assert len(result) > 0

    def test_batch_continuity(self):
        """Test that batches produce continuous results."""
        fetcher = create_test_fetcher()

        result = downsample_range(
            fetcher=fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 06:00'),
            target_cadence='PT5M',
            batch_size='PT1H'
        )

        # Check no duplicates
        assert not result.index.duplicated().any()

        # Check sorted
        assert result.index.is_monotonic_increasing


def create_multi_column_fetcher(cadence='1s'):
    """Create a test fetcher that returns multiple columns."""
    def fetcher(start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
        index = pd.date_range(start, end, freq=cadence)
        if len(index) == 0:
            return pd.DataFrame(
                {'temperature': [], 'pressure': []},
                index=pd.DatetimeIndex([])
            )
        t = np.linspace(0, 2 * np.pi, len(index))
        return pd.DataFrame({
            'temperature': 20 + 5 * np.sin(t),
            'pressure': 1013 + 10 * np.cos(t),
        }, index=index)
    return fetcher


class TestDownsampleRangeMultiAggregate:
    """Tests for downsample_range_multi_aggregate function."""

    def test_basic_multi_aggregate(self):
        """Test basic range multi-aggregate."""
        fetcher = create_multi_column_fetcher()

        result = downsample_range_multi_aggregate(
            fetcher=fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 01:00'),
            target_cadence='PT5M',
            variables=['temperature', 'pressure'],
        )

        assert len(result) > 0
        assert 'temperature_min' in result.columns
        assert 'temperature_mean' in result.columns
        assert 'temperature_max' in result.columns
        assert 'pressure_min' in result.columns
        assert 'coverage' in result.columns
        assert result.index[0] >= pd.Timestamp('2024-01-01 00:00')
        assert result.index[-1] < pd.Timestamp('2024-01-01 01:00')

    def test_with_batching(self):
        """Test range multi-aggregate with batch_size."""
        fetcher = create_multi_column_fetcher()

        result = downsample_range_multi_aggregate(
            fetcher=fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 06:00'),
            target_cadence='PT10M',
            variables=['temperature'],
            batch_size='PT1H',
        )

        assert len(result) > 0
        assert not result.index.duplicated().any()
        assert result.index.is_monotonic_increasing

    def test_empty_fetcher(self):
        """Test with empty fetcher result."""
        def empty_fetcher(start, end):
            return pd.DataFrame(
                {'temperature': []}, index=pd.DatetimeIndex([])
            )

        result = downsample_range_multi_aggregate(
            fetcher=empty_fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 01:00'),
            target_cadence='PT5M',
            variables=['temperature'],
        )

        assert len(result) == 0


class TestDownsampleRangeResolutions:
    """Tests for downsample_range_resolutions function."""

    def test_single_fetch_multiple_resolutions(self):
        """Test that a single fetch produces all resolutions."""
        fetch_count = [0]

        def counting_fetcher(start, end):
            fetch_count[0] += 1
            index = pd.date_range(start, end, freq='1s')
            if len(index) == 0:
                return pd.DataFrame({'value': []}, index=pd.DatetimeIndex([]))
            return pd.DataFrame(
                {'value': np.sin(np.linspace(0, 2 * np.pi, len(index)))},
                index=index
            )

        results = downsample_range_resolutions(
            fetcher=counting_fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 01:00'),
            cadences=['PT1M', 'PT5M', 'PT10M'],
        )

        # Should only fetch once
        assert fetch_count[0] == 1

        # Should have all cadences
        assert pd.Timedelta('1min') in results
        assert pd.Timedelta('5min') in results
        assert pd.Timedelta('10min') in results

        # Coarser cadences should have fewer or equal points
        assert len(results[pd.Timedelta('1min')]) >= len(results[pd.Timedelta('5min')])
        assert len(results[pd.Timedelta('5min')]) >= len(results[pd.Timedelta('10min')])

    def test_output_ranges_are_correct(self):
        """Test that output is trimmed to the requested range."""
        fetcher = create_test_fetcher()

        start = pd.Timestamp('2024-01-01 00:00')
        end = pd.Timestamp('2024-01-01 01:00')

        results = downsample_range_resolutions(
            fetcher=fetcher,
            output_start=start,
            output_end=end,
            cadences=['PT5M'],
        )

        result = results[pd.Timedelta('5min')]
        assert len(result) > 0
        assert result.index[0] >= start
        assert result.index[-1] < end

    def test_empty_fetcher(self):
        """Test with empty fetcher result."""
        def empty_fetcher(start, end):
            return pd.DataFrame({'value': []}, index=pd.DatetimeIndex([]))

        results = downsample_range_resolutions(
            fetcher=empty_fetcher,
            output_start=pd.Timestamp('2024-01-01 00:00'),
            output_end=pd.Timestamp('2024-01-01 01:00'),
            cadences=['PT5M', 'PT10M'],
        )

        assert len(results[pd.Timedelta('5min')]) == 0
        assert len(results[pd.Timedelta('10min')]) == 0
