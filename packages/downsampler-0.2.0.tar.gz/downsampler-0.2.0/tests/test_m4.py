"""Tests for M4 downsampling."""

import pytest
import pandas as pd
import numpy as np

from downsampler.m4 import (
    downsample_m4,
    downsample_m4_with_config,
    _m4_select_indices_single_column,
    _deduplicate_consecutive,
    _filter_collinear_points
)
from downsampler.config import DownsampleConfig, AggregationMethod


class TestDownsampleM4:
    """Tests for M4 downsampling function."""

    def test_basic_m4(self, sine_df):
        """Test basic M4 downsampling."""
        result = downsample_m4(
            sine_df,
            target_cadence='PT10S'
        )

        assert len(result) < len(sine_df)
        assert len(result) > 0
        assert 'signal' in result.columns

    def test_preserves_exact_extrema(self, sine_df):
        """Test that M4 preserves exact min/max values.

        This is the key differentiator of M4: guaranteed extrema preservation.
        """
        result = downsample_m4(
            sine_df,
            target_cadence='PT10S'
        )

        # Check exact preservation of extrema
        orig_max = sine_df['signal'].max()
        orig_min = sine_df['signal'].min()
        result_max = result['signal'].max()
        result_min = result['signal'].min()

        # Should be exactly equal (within floating point tolerance)
        assert abs(result_max - orig_max) < 1e-10
        assert abs(result_min - orig_min) < 1e-10

    def test_monotonic_data(self, simple_df):
        """Test M4 on monotonic data (many duplicates case)."""
        result = downsample_m4(
            simple_df,
            target_cadence='PT10M'
        )

        # Should have fewer points than buckets * 4 due to deduplication
        n_buckets = 100 // 10  # 100 minutes / 10 minutes
        assert len(result) <= n_buckets * 4
        assert len(result) > 0

    def test_deduplication(self):
        """Test that deduplication reduces output size."""
        # Create constant data where first=last=min=max for each bucket
        df = pd.DataFrame(
            {'value': [1.0] * 100},
            index=pd.date_range('2024-01-01', periods=100, freq='1s')
        )

        result_with_dedup = downsample_m4(
            df,
            target_cadence='PT10S',
            deduplicate=True
        )

        result_without_dedup = downsample_m4(
            df,
            target_cadence='PT10S',
            deduplicate=False
        )

        # With deduplication, should have fewer points
        # (constant data means first=last=min=max, so only 1 unique index per bucket)
        assert len(result_with_dedup) <= len(result_without_dedup)

    def test_collinearity_filtering(self):
        """Test collinearity filtering on linear data."""
        # Create perfectly linear data
        df = pd.DataFrame(
            {'value': np.linspace(0, 100, 1000)},
            index=pd.date_range('2024-01-01', periods=1000, freq='1s')
        )

        result_no_filter = downsample_m4(
            df,
            target_cadence='PT10S',
            collinearity_threshold=None
        )

        result_with_filter = downsample_m4(
            df,
            target_cadence='PT10S',
            collinearity_threshold=0.01  # 1% threshold
        )

        # With filtering, should have fewer points
        # (linear data means min/max lie on first-last line)
        assert len(result_with_filter) <= len(result_no_filter)

    def test_gap_handling(self, gappy_df):
        """Test M4 with gappy data."""
        result = downsample_m4(
            gappy_df,
            target_cadence='PT5M',
            gap_threshold=pd.Timedelta('30min')
        )

        # Should produce output from both segments
        assert len(result) > 0

    def test_multi_column(self, multi_column_df):
        """Test M4 with multiple columns."""
        result = downsample_m4(
            multi_column_df,
            target_cadence='PT10S'
        )

        # Should have all numeric columns
        assert 'temperature' in result.columns
        assert 'pressure' in result.columns
        assert 'humidity' in result.columns

        # Each column should preserve its extrema
        for col in ['temperature', 'pressure', 'humidity']:
            orig_max = multi_column_df[col].max()
            orig_min = multi_column_df[col].min()
            result_max = result[col].max()
            result_min = result[col].min()

            assert abs(result_max - orig_max) < 1e-10
            assert abs(result_min - orig_min) < 1e-10

    def test_insufficient_points(self):
        """Test handling of insufficient points."""
        small_df = pd.DataFrame(
            {'value': [1, 2]},
            index=pd.date_range('2024-01-01', periods=2, freq='1s')
        )

        result = downsample_m4(
            small_df,
            target_cadence='PT10S',
            min_points_per_segment=3
        )

        # Should return empty result
        assert len(result) == 0

    def test_output_has_irregular_timestamps(self, sine_df):
        """Test that M4 produces irregular timestamps (not aligned to grid)."""
        result = downsample_m4(
            sine_df,
            target_cadence='PT10S'
        )

        # M4 selects actual data points, not interpolated grid points
        # So timestamps should be from original data
        assert all(t in sine_df.index for t in result.index)

    def test_include_columns(self, multi_column_df):
        """Test including specific columns."""
        result = downsample_m4(
            multi_column_df,
            target_cadence='PT10S',
            include_columns=['temperature', 'pressure']
        )

        assert 'temperature' in result.columns
        assert 'pressure' in result.columns
        # humidity might be included if processed all numeric, so just check the requested ones exist

    def test_empty_dataframe(self):
        """Test handling of empty DataFrame."""
        empty_df = pd.DataFrame(
            {'value': []},
            index=pd.DatetimeIndex([])
        )

        result = downsample_m4(
            empty_df,
            target_cadence='PT10S'
        )

        assert len(result) == 0
        assert 'value' in result.columns


class TestM4GapHandling:
    """Tests for M4 gap handling with NaN markers."""

    def test_m4_inserts_nan_markers_at_gaps(self):
        """Test that M4 output contains NaN markers between segments."""
        # Two segments with a large gap
        times1 = pd.date_range('2024-01-01 00:00', periods=100, freq='1s')
        times2 = pd.date_range('2024-01-01 01:00', periods=100, freq='1s')
        t = np.linspace(0, 4 * np.pi, 100)
        df = pd.concat([
            pd.DataFrame({'signal': np.sin(t)}, index=times1),
            pd.DataFrame({'signal': np.sin(t)}, index=times2),
        ])

        result = downsample_m4(
            df,
            target_cadence='PT10S',
            gap_threshold=pd.Timedelta('5min'),
        )

        # Should have NaN markers between segments
        assert result['signal'].isna().sum() > 0

    def test_m4_non_nan_values_are_original(self):
        """Test that all non-NaN values in M4 output exist in original data."""
        times1 = pd.date_range('2024-01-01 00:00', periods=100, freq='1s')
        times2 = pd.date_range('2024-01-01 01:00', periods=100, freq='1s')
        t = np.linspace(0, 4 * np.pi, 100)
        df = pd.concat([
            pd.DataFrame({'signal': np.sin(t)}, index=times1),
            pd.DataFrame({'signal': np.sin(t)}, index=times2),
        ])

        result = downsample_m4(
            df,
            target_cadence='PT10S',
            gap_threshold=pd.Timedelta('5min'),
        )

        # Non-NaN rows should have timestamps from the original data
        non_nan = result.dropna()
        for ts in non_nan.index:
            assert ts in df.index

    def test_m4_no_gap_no_markers(self, sine_df):
        """Test that continuous data produces no NaN markers."""
        result = downsample_m4(sine_df, target_cadence='PT10S')
        assert result['signal'].isna().sum() == 0


class TestDownsampleM4WithConfig:
    """Tests for M4 downsampling with config."""

    def test_with_config(self, sine_df):
        """Test M4 with full configuration."""
        config = DownsampleConfig(
            method=AggregationMethod.M4,
            m4_deduplicate=True,
            m4_collinearity_threshold=None,
            min_points_per_segment=5
        )

        result = downsample_m4_with_config(
            sine_df,
            'PT10S',
            config
        )

        assert len(result) > 0

    def test_config_defaults(self, sine_df):
        """Test M4 with default configuration."""
        config = DownsampleConfig(method=AggregationMethod.M4)

        result = downsample_m4_with_config(
            sine_df,
            'PT10S',
            config
        )

        assert len(result) > 0

    def test_config_with_deduplication_disabled(self, sine_df):
        """Test M4 with deduplication disabled."""
        config = DownsampleConfig(
            method=AggregationMethod.M4,
            m4_deduplicate=False
        )

        result = downsample_m4_with_config(
            sine_df,
            'PT10S',
            config
        )

        assert len(result) > 0

    def test_config_with_collinearity_filtering(self, sine_df):
        """Test M4 with collinearity filtering enabled."""
        config = DownsampleConfig(
            method=AggregationMethod.M4,
            m4_collinearity_threshold=0.01
        )

        result = downsample_m4_with_config(
            sine_df,
            'PT10S',
            config
        )

        assert len(result) > 0


class TestM4HelperFunctions:
    """Tests for M4 helper functions."""

    def test_deduplicate_consecutive(self):
        """Test consecutive deduplication."""
        # Test with duplicates
        indices = [0, 0, 1, 1, 1, 2, 3, 3, 4]
        result = _deduplicate_consecutive(indices)
        assert result == [0, 1, 2, 3, 4]

        # Test without duplicates
        indices = [0, 1, 2, 3, 4]
        result = _deduplicate_consecutive(indices)
        assert result == [0, 1, 2, 3, 4]

        # Test empty
        assert _deduplicate_consecutive([]) == []

    def test_filter_collinear_linear_data(self):
        """Test collinearity filtering on perfectly linear data."""
        # Create linear values: [0, 1, 2, 3, 4]
        values = np.array([0.0, 1.0, 2.0, 3.0, 4.0])
        indices = [0, 4, 1, 3]  # first=0, last=4, min=1, max=3

        # With threshold=0.0, should filter out min and max (they're on the line)
        result = _filter_collinear_points(indices, values, threshold=0.0)

        # Should only keep first and last
        assert 0 in result
        assert 4 in result
        # min (1) and max (3) should be filtered out since they're on the line
        assert len(result) == 2

    def test_filter_collinear_nonlinear_data(self):
        """Test collinearity filtering on nonlinear data."""
        # Create nonlinear values with clear min/max
        values = np.array([0.0, -5.0, 1.0, 10.0, 2.0])  # min at idx 1, max at idx 3
        indices = [0, 4, 1, 3]  # first=0, last=4, min=1, max=3

        # With threshold=0.01, min and max should be kept (they're far from line)
        result = _filter_collinear_points(indices, values, threshold=0.01)

        # Should keep all 4 points
        assert 0 in result
        assert 4 in result
        assert 1 in result
        assert 3 in result
        assert len(result) == 4

    def test_m4_select_indices_single_column(self):
        """Test core M4 algorithm for single column."""
        # Create simple data
        values = np.array([1.0, 5.0, 2.0, 8.0, 3.0, 1.0])
        n_buckets = 2

        indices = _m4_select_indices_single_column(
            values,
            n_buckets,
            deduplicate=True,
            collinearity_threshold=None
        )

        # Should return indices
        assert len(indices) > 0
        assert all(0 <= idx < len(values) for idx in indices)

    def test_m4_select_indices_more_buckets_than_points(self):
        """Test M4 when buckets >= points."""
        values = np.array([1.0, 2.0, 3.0])
        n_buckets = 10

        indices = _m4_select_indices_single_column(
            values,
            n_buckets,
            deduplicate=True,
            collinearity_threshold=None
        )

        # Should return all indices
        assert set(indices) == {0, 1, 2}

    def test_m4_select_indices_empty(self):
        """Test M4 with empty array."""
        values = np.array([])
        n_buckets = 2

        indices = _m4_select_indices_single_column(
            values,
            n_buckets,
            deduplicate=True,
            collinearity_threshold=None
        )

        assert indices == []

    def test_m4_select_indices_with_nan(self):
        """Test M4 with NaN values."""
        values = np.array([1.0, np.nan, 3.0, 2.0, np.nan, 5.0])
        n_buckets = 2

        # Should handle NaN gracefully with nanargmin/nanargmax
        indices = _m4_select_indices_single_column(
            values,
            n_buckets,
            deduplicate=True,
            collinearity_threshold=None
        )

        assert len(indices) > 0
        assert all(0 <= idx < len(values) for idx in indices)


class TestM4FairComparison:
    """Tests for fair comparison with other downsampling methods."""

    def test_m4_fair_cadence_comparison_with_mean(self):
        """Test that M4 with target_cadence outputs similar point count as mean.

        With the default target_points_per_bucket=3.0, M4 should output roughly
        the same number of points as mean/median/etc for fair comparison.
        """
        # Create test data: 10000 points at 1-minute intervals (~7 days)
        df = pd.DataFrame(
            {'signal': np.sin(np.linspace(0, 20*np.pi, 10000))},
            index=pd.date_range('2024-01-01', periods=10000, freq='1min')
        )

        # Downsample both methods with same target cadence
        from downsampler.aggregators import downsample_mean
        df_m4_fair = downsample_m4(df, 'PT1H', target_points_per_bucket=3.0)
        df_m4_original = downsample_m4(df, 'PT1H', target_points_per_bucket=1.0)
        df_mean = downsample_mean(df, 'PT1H')

        # With fair comparison (target_points_per_bucket=3.0), M4 should output
        # similar number of points as mean (within 0.5x to 1.5x)
        ratio_fair = len(df_m4_fair) / len(df_mean)
        assert 0.5 <= ratio_fair <= 1.5, \
            f"Fair comparison ratio {ratio_fair} outside expected range [0.5, 1.5]"

        # With original behavior (target_points_per_bucket=1.0), M4 should output
        # significantly more points than mean (at least 1.5x)
        ratio_original = len(df_m4_original) / len(df_mean)
        assert ratio_original >= 1.5, \
            f"Original behavior should produce >=1.5x points, got {ratio_original}x"

    def test_m4_target_points_per_bucket_parameter(self):
        """Test that target_points_per_bucket parameter adjusts output."""
        df = pd.DataFrame(
            {'signal': np.sin(np.linspace(0, 20*np.pi, 10000))},
            index=pd.date_range('2024-01-01', periods=10000, freq='1min')
        )

        # With target_points_per_bucket=1.0, should get ~4x more points than default (3.0)
        df_m4_default = downsample_m4(df, 'PT1H', target_points_per_bucket=3.0)
        df_m4_original = downsample_m4(df, 'PT1H', target_points_per_bucket=1.0)

        # Original behavior should produce more points (smaller buckets)
        ratio = len(df_m4_original) / len(df_m4_default)
        assert ratio >= 2.0, f"Original behavior should produce >=2x points, got {ratio}x"

    def test_m4_config_target_points_per_bucket(self):
        """Test that config.m4_target_points_per_bucket is used."""
        df = pd.DataFrame(
            {'signal': np.sin(np.linspace(0, 20*np.pi, 1000))},
            index=pd.date_range('2024-01-01', periods=1000, freq='1min')
        )

        config_default = DownsampleConfig(
            method=AggregationMethod.M4,
            m4_target_points_per_bucket=3.0
        )

        config_original = DownsampleConfig(
            method=AggregationMethod.M4,
            m4_target_points_per_bucket=1.0
        )

        result_default = downsample_m4_with_config(df, 'PT1H', config_default)
        result_original = downsample_m4_with_config(df, 'PT1H', config_original)

        # Original behavior should produce more points
        assert len(result_original) > len(result_default)
