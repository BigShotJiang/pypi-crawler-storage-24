"""Tests for gap detection and handling."""

import pytest
import pandas as pd
import numpy as np

from downsampler.gaps import (
    find_gap_indices,
    groupby_gaps,
    split_at_gaps,
    iter_segments,
    wrap_in_nans,
    mark_gaps_in_dataframe,
    has_gaps,
    count_gaps,
    interpolate_small_gaps,
    concatenate_with_gap_markers,
)


class TestFindGapIndices:
    """Tests for find_gap_indices function."""

    def test_no_gaps(self, simple_df):
        """Test DataFrame with no gaps."""
        gaps = find_gap_indices(simple_df, pd.Timedelta('5min'))
        assert len(gaps) == 0

    def test_single_gap(self, gappy_df):
        """Test DataFrame with a single gap."""
        gaps = find_gap_indices(gappy_df, pd.Timedelta('5min'))
        assert len(gaps) == 1

    def test_gap_threshold(self, gappy_df):
        """Test that gap threshold is respected."""
        # Should find gap with 5 min threshold
        gaps_5min = find_gap_indices(gappy_df, pd.Timedelta('5min'))
        assert len(gaps_5min) == 1

        # Should not find gap with 2 hour threshold
        gaps_2hr = find_gap_indices(gappy_df, pd.Timedelta('2H'))
        assert len(gaps_2hr) == 0


class TestGroupbyGaps:
    """Tests for groupby_gaps function."""

    def test_does_not_mutate_input(self, gappy_df):
        """Test that groupby_gaps does not modify the input DataFrame."""
        original_columns = list(gappy_df.columns)
        _ = groupby_gaps(gappy_df, pd.Timedelta('5min'))
        assert list(gappy_df.columns) == original_columns
        assert 'gap_index' not in gappy_df.columns


class TestSplitAtGaps:
    """Tests for split_at_gaps function."""

    def test_split_gappy_df(self, gappy_df):
        """Test splitting DataFrame at gaps."""
        segments = split_at_gaps(gappy_df, pd.Timedelta('5min'))

        assert len(segments) == 2
        assert len(segments[0]) == 50
        assert len(segments[1]) == 50

    def test_split_continuous_df(self, simple_df):
        """Test splitting continuous DataFrame (no split)."""
        segments = split_at_gaps(simple_df, pd.Timedelta('5min'))

        assert len(segments) == 1
        assert len(segments[0]) == len(simple_df)


class TestIterSegments:
    """Tests for iter_segments function."""

    def test_min_points_filter(self, gappy_df):
        """Test minimum points filtering."""
        # Both segments have 50 points each
        segments = list(iter_segments(gappy_df, pd.Timedelta('5min'), min_points=10))
        assert len(segments) == 2

        # Require more points than available
        segments = list(iter_segments(gappy_df, pd.Timedelta('5min'), min_points=100))
        assert len(segments) == 0


class TestWrapInNans:
    """Tests for wrap_in_nans function."""

    def test_wrap_both(self, simple_df):
        """Test wrapping with NaNs on both ends."""
        wrapped = wrap_in_nans(simple_df, offset='PT1S', where='both')

        assert len(wrapped) == len(simple_df) + 2
        assert np.isnan(wrapped.iloc[0]['value'])
        assert np.isnan(wrapped.iloc[-1]['value'])

    def test_wrap_start_only(self, simple_df):
        """Test wrapping with NaN at start only."""
        wrapped = wrap_in_nans(simple_df, offset='PT1S', where='start')

        assert len(wrapped) == len(simple_df) + 1
        assert np.isnan(wrapped.iloc[0]['value'])
        assert not np.isnan(wrapped.iloc[-1]['value'])


class TestMarkGapsInDataframe:
    """Tests for mark_gaps_in_dataframe function."""

    def test_mark_gaps(self, gappy_df):
        """Test marking gaps in DataFrame."""
        marked = mark_gaps_in_dataframe(
            gappy_df,
            nominal_timedelta=pd.Timedelta('1min')
        )

        # Should have more rows due to NaN markers
        assert len(marked) > len(gappy_df)

        # Should have NaN values at gap
        assert marked['value'].isna().sum() > 0

    def test_no_gaps_unchanged(self, simple_df):
        """Test that DataFrame without gaps is unchanged."""
        marked = mark_gaps_in_dataframe(
            simple_df,
            nominal_timedelta=pd.Timedelta('1min')
        )

        # No NaN markers needed
        assert marked['value'].isna().sum() == 0


class TestHasGaps:
    """Tests for has_gaps function."""

    def test_gappy_df(self, gappy_df):
        """Test detection of gaps."""
        assert has_gaps(gappy_df, pd.Timedelta('5min'))
        assert not has_gaps(gappy_df, pd.Timedelta('2H'))

    def test_continuous_df(self, simple_df):
        """Test continuous DataFrame."""
        assert not has_gaps(simple_df, pd.Timedelta('5min'))


class TestCountGaps:
    """Tests for count_gaps function."""

    def test_count_single_gap(self, gappy_df):
        """Test counting single gap."""
        assert count_gaps(gappy_df, pd.Timedelta('5min')) == 1

    def test_count_no_gaps(self, simple_df):
        """Test counting no gaps."""
        assert count_gaps(simple_df, pd.Timedelta('5min')) == 0


class TestInterpolateSmallGaps:
    """Tests for interpolate_small_gaps function."""

    def test_no_gaps_unchanged(self, simple_df):
        """Test that continuous data is returned unchanged."""
        result = interpolate_small_gaps(
            simple_df,
            gap_threshold=pd.Timedelta('5min'),
            source_cadence=pd.Timedelta('1min'),
        )
        assert len(result) == len(simple_df)
        pd.testing.assert_frame_equal(result, simple_df)

    def test_small_gap_filled(self):
        """Test that a small gap is filled with interpolated points."""
        # 3 points, 1-min cadence, with a 3-min gap in the middle
        times = pd.to_datetime([
            '2024-01-01 00:00',
            '2024-01-01 00:01',
            '2024-01-01 00:04',  # 3-min gap from 00:01
            '2024-01-01 00:05',
        ])
        df = pd.DataFrame({'value': [0.0, 1.0, 4.0, 5.0]}, index=times)

        result = interpolate_small_gaps(
            df,
            gap_threshold=pd.Timedelta('10min'),
            source_cadence=pd.Timedelta('1min'),
        )

        # Should have filled 2 points (00:02 and 00:03)
        assert len(result) == 6
        # Interpolated values should be linearly between 1.0 and 4.0
        assert result.loc['2024-01-01 00:02', 'value'] == pytest.approx(2.0)
        assert result.loc['2024-01-01 00:03', 'value'] == pytest.approx(3.0)

    def test_large_gap_not_filled(self):
        """Test that a gap at/above gap_threshold is NOT filled."""
        times = pd.to_datetime([
            '2024-01-01 00:00',
            '2024-01-01 00:01',
            '2024-01-01 00:11',  # 10-min gap
            '2024-01-01 00:12',
        ])
        df = pd.DataFrame({'value': [0.0, 1.0, 11.0, 12.0]}, index=times)

        result = interpolate_small_gaps(
            df,
            gap_threshold=pd.Timedelta('5min'),
            source_cadence=pd.Timedelta('1min'),
        )

        # Large gap should NOT be filled
        assert len(result) == len(df)

    def test_mixed_gaps(self):
        """Test with both small and large gaps — only small ones filled."""
        times = pd.to_datetime([
            '2024-01-01 00:00',
            '2024-01-01 00:01',
            # small gap: 3 min
            '2024-01-01 00:04',
            '2024-01-01 00:05',
            # large gap: 60 min
            '2024-01-01 01:05',
            '2024-01-01 01:06',
        ])
        df = pd.DataFrame(
            {'value': [0.0, 1.0, 4.0, 5.0, 65.0, 66.0]},
            index=times,
        )

        result = interpolate_small_gaps(
            df,
            gap_threshold=pd.Timedelta('10min'),
            source_cadence=pd.Timedelta('1min'),
        )

        # Small gap filled (2 new points), large gap left alone
        assert len(result) == 8

    def test_preserves_original_nans(self):
        """Test that pre-existing NaN values are not overwritten."""
        times = pd.date_range('2024-01-01', periods=5, freq='1min')
        df = pd.DataFrame(
            {'value': [0.0, np.nan, 2.0, 3.0, 4.0]},
            index=times,
        )

        result = interpolate_small_gaps(
            df,
            gap_threshold=pd.Timedelta('10min'),
            source_cadence=pd.Timedelta('1min'),
        )

        # Original NaN should still be NaN
        assert np.isnan(result.iloc[1]['value'])

    def test_auto_cadence_estimation(self):
        """Test that source_cadence is auto-estimated when None."""
        times = pd.to_datetime([
            '2024-01-01 00:00',
            '2024-01-01 00:01',
            '2024-01-01 00:04',
            '2024-01-01 00:05',
        ])
        df = pd.DataFrame({'value': [0.0, 1.0, 4.0, 5.0]}, index=times)

        # Should not raise, cadence estimated from median of deltas
        result = interpolate_small_gaps(
            df,
            gap_threshold=pd.Timedelta('10min'),
        )
        assert len(result) >= len(df)

    def test_single_row(self):
        """Test with single-row DataFrame (no gaps possible)."""
        df = pd.DataFrame(
            {'value': [1.0]},
            index=pd.DatetimeIndex(['2024-01-01']),
        )
        result = interpolate_small_gaps(
            df,
            gap_threshold=pd.Timedelta('10min'),
        )
        assert len(result) == 1

    def test_multi_column(self):
        """Test interpolation across multiple numeric columns."""
        times = pd.to_datetime([
            '2024-01-01 00:00',
            '2024-01-01 00:01',
            '2024-01-01 00:04',
            '2024-01-01 00:05',
        ])
        df = pd.DataFrame({
            'a': [0.0, 1.0, 4.0, 5.0],
            'b': [10.0, 20.0, 50.0, 60.0],
        }, index=times)

        result = interpolate_small_gaps(
            df,
            gap_threshold=pd.Timedelta('10min'),
            source_cadence=pd.Timedelta('1min'),
        )

        assert len(result) == 6
        assert result.loc['2024-01-01 00:02', 'a'] == pytest.approx(2.0)
        assert result.loc['2024-01-01 00:02', 'b'] == pytest.approx(30.0)


class TestConcatenateWithGapMarkers:
    """Tests for concatenate_with_gap_markers function."""

    def test_empty_input(self):
        """Test with empty list returns empty DataFrame."""
        result = concatenate_with_gap_markers([])
        assert len(result) == 0

    def test_single_segment(self):
        """Test with single segment returns it as-is."""
        df = pd.DataFrame(
            {'value': [1, 2, 3]},
            index=pd.date_range('2024-01-01', periods=3, freq='1min'),
        )
        result = concatenate_with_gap_markers([df])
        pd.testing.assert_frame_equal(result, df)

    def test_two_segments_inserts_nan_marker(self):
        """Test that a NaN marker row is inserted between two segments."""
        seg1 = pd.DataFrame(
            {'value': [1.0, 2.0]},
            index=pd.date_range('2024-01-01 00:00', periods=2, freq='1min'),
        )
        seg2 = pd.DataFrame(
            {'value': [10.0, 11.0]},
            index=pd.date_range('2024-01-01 01:00', periods=2, freq='1min'),
        )

        result = concatenate_with_gap_markers([seg1, seg2])

        # 2 + 1 marker + 2 = 5
        assert len(result) == 5
        # The marker should be NaN
        assert np.isnan(result.iloc[2]['value'])
        # Marker timestamp should be seg1 end + offset
        expected_marker_time = seg1.index[-1] + pd.Timedelta('0.1s')
        assert result.index[2] == expected_marker_time

    def test_three_segments_inserts_two_markers(self):
        """Test with three segments gets two NaN markers."""
        segs = []
        for i in range(3):
            start = pd.Timestamp('2024-01-01') + pd.Timedelta(hours=i * 2)
            segs.append(pd.DataFrame(
                {'value': [float(i)]},
                index=[start],
            ))

        result = concatenate_with_gap_markers(segs)
        # 1 + marker + 1 + marker + 1 = 5
        assert len(result) == 5
        assert result['value'].isna().sum() == 2

    def test_custom_offset(self):
        """Test with custom offset."""
        seg1 = pd.DataFrame(
            {'value': [1.0]},
            index=[pd.Timestamp('2024-01-01 00:00')],
        )
        seg2 = pd.DataFrame(
            {'value': [2.0]},
            index=[pd.Timestamp('2024-01-01 01:00')],
        )

        offset = pd.Timedelta('1s')
        result = concatenate_with_gap_markers([seg1, seg2], offset=offset)

        expected_marker_time = seg1.index[-1] + offset
        assert result.index[1] == expected_marker_time
