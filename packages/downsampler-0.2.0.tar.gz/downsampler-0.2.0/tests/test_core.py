"""Tests for core downsampling functionality."""

import pytest
import pandas as pd
import numpy as np

from downsampler import (
    downsample_dataframe,
    downsample_dataframe_multi_aggregate,
    downsample_dataframe_resolutions,
    DownsampleConfig,
    AggregationMethod,
)


class TestDownsampleDataframe:
    """Tests for the main downsample_dataframe function."""

    def test_basic_mean_downsampling(self, simple_df):
        """Test basic mean downsampling."""
        result = downsample_dataframe(simple_df, '10min')

        assert len(result) < len(simple_df)
        assert 'value' in result.columns

    def test_method_kwarg(self, simple_df):
        """Test using method as keyword argument."""
        result = downsample_dataframe(simple_df, '10min', method='max')

        # Max of 0-9 should be 9, max of 10-19 should be 19, etc.
        assert result['value'].iloc[0] == 9

    def test_config_object(self, simple_df):
        """Test using DownsampleConfig object."""
        config = DownsampleConfig(method=AggregationMethod.MIN)
        result = downsample_dataframe(simple_df, '10min', config=config)

        # Min of 0-9 should be 0
        assert result['value'].iloc[0] == 0

    def test_lttb_method(self, sine_df):
        """Test LTTB downsampling method."""
        config = DownsampleConfig(
            method=AggregationMethod.LTTB,
            lttb_target_column='signal'
        )
        result = downsample_dataframe(sine_df, 'PT10S', config=config)

        assert len(result) < len(sine_df)
        # LTTB should preserve signal shape reasonably well
        assert 'signal' in result.columns

    def test_empty_dataframe(self):
        """Test handling of empty DataFrame."""
        empty_df = pd.DataFrame(
            {'value': []},
            index=pd.DatetimeIndex([])
        )
        result = downsample_dataframe(empty_df, '1min')
        assert len(result) == 0

    def test_single_point_dataframe(self):
        """Test handling of single-point DataFrame."""
        single_df = pd.DataFrame(
            {'value': [1.0]},
            index=pd.DatetimeIndex(['2024-01-01'])
        )
        result = downsample_dataframe(single_df, '1min')
        # Should handle gracefully (may be empty or single point)
        assert len(result) <= 1


class TestDownsampleDataframeMultiAggregate:
    """Tests for multi-aggregate downsampling."""

    def test_basic_multi_aggregate(self, multi_column_df):
        """Test basic multi-aggregate downsampling."""
        result = downsample_dataframe_multi_aggregate(
            multi_column_df,
            'PT1M',
            variables=['temperature', 'pressure'],
            aggregations=['min', 'mean', 'max']
        )

        # Check expected columns exist
        assert 'temperature_min' in result.columns
        assert 'temperature_mean' in result.columns
        assert 'temperature_max' in result.columns
        assert 'pressure_min' in result.columns
        assert 'coverage' in result.columns

    def test_coverage_column(self, multi_column_df):
        """Test that coverage column is calculated."""
        result = downsample_dataframe_multi_aggregate(
            multi_column_df,
            'PT1M',
            variables=['temperature'],
            source_cadence='PT1S'
        )

        # Coverage should be between 0 and 1
        assert result['coverage'].min() >= 0
        assert result['coverage'].max() <= 1.0

    def test_min_max_ordering(self, multi_column_df):
        """Test that min <= mean <= max."""
        result = downsample_dataframe_multi_aggregate(
            multi_column_df,
            'PT1M',
            variables=['temperature'],
            aggregations=['min', 'mean', 'max']
        )

        valid_rows = result.dropna()
        assert (valid_rows['temperature_min'] <= valid_rows['temperature_mean']).all()
        assert (valid_rows['temperature_mean'] <= valid_rows['temperature_max']).all()


class TestMetadata:
    """Tests for provenance metadata on output DataFrames."""

    def test_mean_metadata(self, simple_df):
        """Test that mean downsampling attaches correct metadata."""
        result = downsample_dataframe(simple_df, '10min')
        meta = result.attrs['downsampler']
        assert meta['method'] == 'mean'
        assert meta['target_cadence'] == str(pd.Timedelta('10min'))
        assert meta['source_cadence'] is None

    def test_max_metadata(self, simple_df):
        """Test that method kwarg is reflected in metadata."""
        result = downsample_dataframe(simple_df, '10min', method='max')
        assert result.attrs['downsampler']['method'] == 'max'

    def test_lttb_metadata(self, sine_df):
        """Test that LTTB method is recorded in metadata."""
        config = DownsampleConfig(
            method=AggregationMethod.LTTB,
            lttb_target_column='signal'
        )
        result = downsample_dataframe(sine_df, 'PT10S', config=config)
        assert result.attrs['downsampler']['method'] == 'lttb'

    def test_source_cadence_metadata(self, simple_df):
        """Test that source_cadence is recorded when provided."""
        config = DownsampleConfig(source_cadence='1min')
        result = downsample_dataframe(simple_df, '10min', config=config)
        assert result.attrs['downsampler']['source_cadence'] is not None

    def test_multi_aggregate_metadata(self, multi_column_df):
        """Test that multi-aggregate attaches metadata."""
        result = downsample_dataframe_multi_aggregate(
            multi_column_df,
            'PT1M',
            variables=['temperature', 'pressure'],
        )
        meta = result.attrs['downsampler']
        assert meta['method'] == 'multi_aggregate'
        assert meta['target_cadence'] == str(pd.Timedelta('1min'))

    def test_resolutions_metadata(self, simple_df):
        """Test that each resolution DataFrame has metadata."""
        results = downsample_dataframe_resolutions(
            simple_df, ['10min', '20min']
        )
        for cadence, df in results.items():
            meta = df.attrs['downsampler']
            assert meta['method'] == 'mean'
            assert meta['target_cadence'] == str(cadence)


class TestDownsampleDataframeResolutions:
    """Tests for multi-resolution downsampling."""

    def test_returns_correct_keys(self, simple_df):
        """Test that result dict has correct cadence keys."""
        cadences = ['10min', '20min']
        results = downsample_dataframe_resolutions(simple_df, cadences)

        assert pd.Timedelta('10min') in results
        assert pd.Timedelta('20min') in results
        assert len(results) == 2

    def test_coarser_cadence_has_fewer_points(self, simple_df):
        """Test that coarser cadences produce fewer points."""
        results = downsample_dataframe_resolutions(
            simple_df, ['10min', '20min', '50min']
        )

        assert len(results[pd.Timedelta('10min')]) >= len(results[pd.Timedelta('20min')])
        assert len(results[pd.Timedelta('20min')]) >= len(results[pd.Timedelta('50min')])

    def test_each_value_is_valid_dataframe(self, simple_df):
        """Test that each result is a valid downsampled DataFrame."""
        results = downsample_dataframe_resolutions(simple_df, ['10min'])

        df_10m = results[pd.Timedelta('10min')]
        assert isinstance(df_10m, pd.DataFrame)
        assert 'value' in df_10m.columns
        assert len(df_10m) < len(simple_df)

    def test_with_config(self, simple_df):
        """Test resolutions with a specific config."""
        config = DownsampleConfig(method=AggregationMethod.MAX)
        results = downsample_dataframe_resolutions(
            simple_df, ['10min'], config=config
        )

        df_10m = results[pd.Timedelta('10min')]
        # Max of 0-9 should be 9
        assert df_10m['value'].iloc[0] == 9
