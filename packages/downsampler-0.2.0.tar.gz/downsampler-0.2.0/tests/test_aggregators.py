"""Tests for aggregation-based downsampling."""

import pytest
import pandas as pd
import numpy as np

from downsampler.aggregators import (
    downsample_mean,
    downsample_median,
    downsample_min,
    downsample_max,
    downsample_multi_aggregate,
)


class TestDownsampleMean:
    """Tests for mean downsampling."""

    def test_basic_mean(self, simple_df):
        """Test basic mean downsampling."""
        result = downsample_mean(simple_df, '10min')

        # Mean of 0-9 should be 4.5
        assert result['value'].iloc[0] == pytest.approx(4.5)

    def test_column_selection(self, multi_column_df):
        """Test column selection."""
        result = downsample_mean(
            multi_column_df,
            'PT1M',
            columns=['temperature']
        )

        assert 'temperature' in result.columns
        # Other numeric columns should not be present
        assert 'pressure' not in result.columns


class TestDownsampleMedian:
    """Tests for median downsampling."""

    def test_basic_median(self, simple_df):
        """Test basic median downsampling."""
        result = downsample_median(simple_df, '10min')

        # Median of 0-9 should be 4.5
        assert result['value'].iloc[0] == pytest.approx(4.5)


class TestDownsampleMin:
    """Tests for min downsampling."""

    def test_basic_min(self, simple_df):
        """Test basic min downsampling."""
        result = downsample_min(simple_df, '10min')

        # Min of 0-9 should be 0
        assert result['value'].iloc[0] == 0
        # Min of 10-19 should be 10
        assert result['value'].iloc[1] == 10


class TestDownsampleMax:
    """Tests for max downsampling."""

    def test_basic_max(self, simple_df):
        """Test basic max downsampling."""
        result = downsample_max(simple_df, '10min')

        # Max of 0-9 should be 9
        assert result['value'].iloc[0] == 9
        # Max of 10-19 should be 19
        assert result['value'].iloc[1] == 19

    def test_with_gaps(self, gappy_df):
        """Test max downsampling with gaps produces NaN for incomplete buckets."""
        result = downsample_max(gappy_df, '10min')

        # Should handle gaps gracefully
        assert len(result) > 0
        # Buckets spanning the gap should be NaN due to completeness filtering
        assert result['value'].isna().any()


class TestCompletenessFiltering:
    """Tests for min_completeness filtering in aggregators."""

    def test_incomplete_bucket_is_nan(self):
        """A bucket with insufficient points produces NaN."""
        # 10 points at 1min cadence, then a 50min gap, then 10 more points
        times1 = pd.date_range('2024-01-01 00:00', periods=10, freq='1min')
        times2 = pd.date_range('2024-01-01 01:00', periods=10, freq='1min')
        df = pd.DataFrame(
            {'value': range(20)},
            index=times1.append(times2)
        )

        # Downsample to 10min buckets; source_cadence=1min => 10 expected per bucket
        result = downsample_mean(
            df, '10min', source_cadence='1min', min_completeness=0.9
        )

        # The first bucket (00:00-00:10) has 10 points out of 10 expected => valid
        assert not np.isnan(result['value'].iloc[0])

        # Buckets in the gap have 0 points => NaN
        # The bucket at 01:00 has 10 points => valid
        # Check that at least some buckets are NaN (the gap region)
        assert result['value'].isna().any()

    def test_complete_bucket_has_value(self):
        """A bucket with sufficient points produces a valid value."""
        df = pd.DataFrame(
            {'value': range(100)},
            index=pd.date_range('2024-01-01', periods=100, freq='1min')
        )

        result = downsample_mean(
            df, '10min', source_cadence='1min', min_completeness=0.9
        )

        # All buckets have 10/10 points => all valid
        assert not result['value'].isna().any()

    def test_explicit_source_cadence(self):
        """Test with explicitly provided source_cadence."""
        # 5 points at 1min in a 10min bucket => 50% completeness
        df = pd.DataFrame(
            {'value': [1.0, 2.0, 3.0, 4.0, 5.0]},
            index=pd.date_range('2024-01-01', periods=5, freq='1min')
        )

        # With min_completeness=0.3, 5/10 = 50% >= 30% => valid
        result = downsample_mean(
            df, '10min', source_cadence='1min', min_completeness=0.3
        )
        assert not result['value'].isna().all()

        # With min_completeness=0.6, 5/10 = 50% < 60% => NaN
        result = downsample_mean(
            df, '10min', source_cadence='1min', min_completeness=0.6
        )
        assert result['value'].isna().all()

    def test_min_completeness_zero_disables_filtering(self):
        """min_completeness=0.0 disables filtering; all buckets produce values."""
        # 1 point in a bucket that expects 10
        df = pd.DataFrame(
            {'value': [42.0]},
            index=pd.DatetimeIndex(['2024-01-01 00:00'])
        )

        result = downsample_mean(
            df, '10min', source_cadence='1min', min_completeness=0.0
        )
        assert not result['value'].isna().any()
        assert result['value'].iloc[0] == 42.0

    def test_completeness_via_config(self):
        """Test that completeness filtering works through downsample_with_config."""
        from downsampler.aggregators import downsample_with_config
        from downsampler.config import DownsampleConfig, AggregationMethod, EdgeHandling

        # 5 points at 1min in a 10min bucket
        df = pd.DataFrame(
            {'value': [1.0, 2.0, 3.0, 4.0, 5.0]},
            index=pd.date_range('2024-01-01', periods=5, freq='1min')
        )

        config = DownsampleConfig(
            method=AggregationMethod.MEAN,
            source_cadence='1min',
            min_completeness=0.6,
            edge_handling=EdgeHandling.KEEP,
        )
        result = downsample_with_config(df, '10min', config)
        # 5/10 = 50% < 60% => NaN
        assert result['value'].isna().all()

        config = DownsampleConfig(
            method=AggregationMethod.MEAN,
            source_cadence='1min',
            min_completeness=0.3,
            edge_handling=EdgeHandling.KEEP,
        )
        result = downsample_with_config(df, '10min', config)
        # 5/10 = 50% >= 30% => valid
        assert not result['value'].isna().all()


class TestTimestampAlignment:
    """Tests that aggregator timestamps are at bucket midpoints."""

    def test_single_aggregate_bucket_middle(self):
        """Single-aggregate output timestamps are at bucket midpoints."""
        df = pd.DataFrame(
            {'value': range(100)},
            index=pd.date_range('2024-01-01', periods=100, freq='1min')
        )

        result = downsample_mean(df, '10min')

        # Bucket [00:00, 00:10) should have midpoint at 00:05
        expected_first = pd.Timestamp('2024-01-01 00:05')
        assert result.index[0] == expected_first

        # All timestamps should be 10min apart
        diffs = result.index.to_series().diff().dropna()
        assert (diffs == pd.Timedelta('10min')).all()

    def test_multi_aggregate_bucket_middle(self):
        """Multi-aggregate output timestamps are at bucket midpoints."""
        df = pd.DataFrame(
            {'value': range(100)},
            index=pd.date_range('2024-01-01', periods=100, freq='1min')
        )

        result = downsample_multi_aggregate(
            df, '10min', ['value'], ['min', 'mean', 'max']
        )

        expected_first = pd.Timestamp('2024-01-01 00:05')
        assert result.index[0] == expected_first

    def test_single_and_multi_aggregate_timestamps_align(self):
        """Single-aggregate and multi-aggregate produce identical timestamps."""
        df = pd.DataFrame(
            {'value': range(100)},
            index=pd.date_range('2024-01-01', periods=100, freq='1min')
        )

        single = downsample_mean(df, '10min')
        multi = downsample_multi_aggregate(
            df, '10min', ['value'], ['mean']
        )

        pd.testing.assert_index_equal(single.index, multi.index)
