# Ottimate Python SDK

Official Python SDK for the [Ottimate API](https://docs.ottimate.com).

## Installation

```sh
pip install ottimate-sdk
```

## Requirements

- Python 3.8 or higher

## Configuration

Create a `.env` file in your project root with your Ottimate credentials:

```env
OTTIMATE_API_KEY="your_api_key"
OTTIMATE_BASE_URL="your_base_url"
OTTIMATE_CLIENT_ID="your_client_id"
OTTIMATE_CLIENT_SECRET="your_client_secret"
OTTIMATE_COMPANY_ID="your_company_id"
OTTIMATE_LOCATION_ID="your_location_id"
```

## Authentication

The Ottimate API uses OAuth 2.0. Authentication is a two-step process:

1. Create a temporary client to obtain an OAuth access token
2. Initialize the main client using the access token

```python
import httpx
from ottimate import Ottimate

# Step 1: Get an access token
auth_client = Ottimate(
    base_url=base_url,
    api_key=api_key,
    httpx_client=httpx.Client(timeout=60, follow_redirects=True)
)

token_response = auth_client.oauth.post_oauth_token(
    client_id=client_id,
    client_secret=client_secret,
    scope="accounts.can_access_dashboard"
)
access_token = token_response.access_token

# Step 2: Initialize the authenticated client
client = Ottimate(
    base_url=base_url,
    api_key=api_key,
    api_version="1.0.0",
    headers={"Authorization": f"Bearer {access_token}"},
    httpx_client=httpx.Client(timeout=60, follow_redirects=True)
)
```

## Full Example

```python
import os
import httpx
from dotenv import load_dotenv
from ottimate import Ottimate

load_dotenv()

base_url = os.environ["OTTIMATE_BASE_URL"]
api_key = os.environ["OTTIMATE_API_KEY"]
client_id = os.environ["OTTIMATE_CLIENT_ID"]
client_secret = os.environ["OTTIMATE_CLIENT_SECRET"]

# Obtain access token
auth_client = Ottimate(
    base_url=base_url,
    api_key=api_key,
    httpx_client=httpx.Client(timeout=60, follow_redirects=True)
)

token_response = auth_client.oauth.post_oauth_token(
    client_id=client_id,
    client_secret=client_secret,
    scope="accounts.can_access_dashboard"
)

# Create authenticated client
client = Ottimate(
    base_url=base_url,
    api_key=api_key,
    api_version="1.0.0",
    headers={"Authorization": f"Bearer {token_response.access_token}"},
    httpx_client=httpx.Client(timeout=60, follow_redirects=True)
)
```

## Version

`0.1.4`

## Support

For API documentation and guides, visit the [Ottimate Developer Docs](https://docs.ottimate.com).
