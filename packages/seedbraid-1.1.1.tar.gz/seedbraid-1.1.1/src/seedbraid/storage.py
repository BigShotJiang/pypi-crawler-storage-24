"""SQLite-backed genome chunk storage with content-addressed dedup.

Provides the ``GenomeStorage`` protocol and its ``SQLiteGenome``
implementation for portable, single-file chunk persistence.
"""

from __future__ import annotations

import sqlite3
import types
from collections.abc import Iterator
from pathlib import Path
from typing import Protocol, Self


class GenomeStorage(Protocol):
    """Content-addressed chunk storage interface.

    Implementations must provide CRUD operations on
    binary chunks keyed by their 32-byte SHA-256
    digest.
    """

    def has_chunk(self, chunk_hash: bytes) -> bool:
        """Check whether a chunk exists in storage.

        Args:
            chunk_hash: 32-byte SHA-256 digest of
                the chunk.

        Returns:
            ``True`` if the chunk is stored,
            ``False`` otherwise.
        """
        ...

    def get_chunk(
        self, chunk_hash: bytes,
    ) -> bytes | None:
        """Retrieve a chunk by its hash.

        Args:
            chunk_hash: 32-byte SHA-256 digest of
                the chunk.

        Returns:
            Raw chunk bytes, or ``None`` if not
            found.
        """
        ...

    def put_chunk(
        self, chunk_hash: bytes, data: bytes,
    ) -> bool:
        """Store a chunk keyed by its hash.

        Args:
            chunk_hash: 32-byte SHA-256 digest of
                the chunk.
            data: Raw chunk bytes to store.

        Returns:
            ``True`` if the chunk was newly inserted,
            ``False`` if it already existed.
        """
        ...

    def count_chunks(self) -> int: ...

    def close(self) -> None: ...

    def __enter__(self) -> Self: ...

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: types.TracebackType | None,
    ) -> None: ...


class SQLiteGenome:
    def __init__(self, db_path: str | Path) -> None:
        """Open or create a SQLite genome database.

        Creates the parent directory and the chunks
        table if they do not already exist.

        Args:
            db_path: Filesystem path to the SQLite
                database file.
        """
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS chunks (
                hash BLOB PRIMARY KEY,
                data BLOB NOT NULL,
                size INTEGER NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        self.conn.commit()

    def has_chunk(self, chunk_hash: bytes) -> bool:
        cur = self.conn.execute(
            "SELECT 1 FROM chunks WHERE hash = ?",
            (chunk_hash,),
        )
        return cur.fetchone() is not None

    def get_chunk(self, chunk_hash: bytes) -> bytes | None:
        cur = self.conn.execute(
            "SELECT data FROM chunks WHERE hash = ?",
            (chunk_hash,),
        )
        row = cur.fetchone()
        return None if row is None else bytes(row[0])

    def put_chunk(self, chunk_hash: bytes, data: bytes) -> bool:
        cur = self.conn.execute(
            "INSERT OR IGNORE INTO chunks(hash, data, size) VALUES (?, ?, ?)",
            (chunk_hash, data, len(data)),
        )
        self.conn.commit()
        return cur.rowcount > 0

    def count_chunks(self) -> int:
        cur = self.conn.execute("SELECT COUNT(*) FROM chunks")
        return int(cur.fetchone()[0])

    def iter_hashes(self) -> Iterator[bytes]:
        cur = self.conn.execute("SELECT hash FROM chunks")
        for (chunk_hash,) in cur:
            yield bytes(chunk_hash)

    def iter_chunks(self) -> Iterator[tuple[bytes, bytes]]:
        cur = self.conn.execute("SELECT hash, data FROM chunks ORDER BY hash")
        for chunk_hash, data in cur:
            yield bytes(chunk_hash), bytes(data)

    def clear_chunks(self) -> None:
        self.conn.execute("DELETE FROM chunks")
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: types.TracebackType | None,
    ) -> None:
        self.close()


def resolve_genome_db_path(genome_path: str | Path) -> Path:
    """Resolve a genome path to its SQLite file path.

    If ``genome_path`` ends with ``.sqlite`` or
    ``.db``, it is returned as-is.  Otherwise
    ``genome.sqlite`` is appended as the default
    database filename.

    Args:
        genome_path: Directory or explicit database
            file path.

    Returns:
        Resolved path to the SQLite database file.
    """
    p = Path(genome_path)
    if p.suffix in {".sqlite", ".db"}:
        return p
    return p / "genome.sqlite"


def open_genome(genome_path: str | Path) -> SQLiteGenome:
    """Open a genome database from a path.

    Convenience wrapper that resolves the database
    file via ``resolve_genome_db_path`` and returns
    a ready-to-use ``SQLiteGenome`` instance.

    Args:
        genome_path: Directory or explicit database
            file path.

    Returns:
        Connected ``SQLiteGenome`` instance.
    """
    return SQLiteGenome(resolve_genome_db_path(genome_path))
