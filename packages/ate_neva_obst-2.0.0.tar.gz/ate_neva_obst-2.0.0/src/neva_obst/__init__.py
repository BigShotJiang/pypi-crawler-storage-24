"""
ate-neva-obst
Python SDK for Domainesia / Neva Objects (S3-compatible storage).

Author:
    Azzam (AzzTE)

Credits:
    This SDK uses several open-source libraries:
    - binaryornot (created by Audrey Roy Greenfeld)
    - boto3 (AWS SDK for Python)

Thank you for Neva Cloud.
Thank you to the open-source community.
"""

from .client import ObjectsClient
from .exceptions import ObjectsError, UploadError, DownloadError, ListError

__version__ = "0.2.0"

__all__ = [
    "ObjectsClient",
    "ObjectsError",
    "UploadError",
    "DownloadError",
    "ListError"
]