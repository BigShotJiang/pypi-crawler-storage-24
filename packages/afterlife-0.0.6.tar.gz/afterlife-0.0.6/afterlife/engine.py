from __future__ import annotations

import json
import math
import os
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import swisseph as swe

from afterlife.constants import (
    _ALIASES,
    _PLANETARY_INCL,
    ADVANCED_POINTS,
    ALLOWED_FOR_ACTIVE,
    ARABIC_LOTS,
    ASPECTS,
    ASTEROIDS,
    AFTERLIFE_EPHEMERIS_DATE,
    AFTERLIFE_EPHEMERIS_NOTE,
    AFTERLIFE_EPHEMERIS_SOURCE,
    AFTERLIFE_EPHEMERIS_VERSION,
    CATEGORY_RING,
    CATEGORY_TITLES_BASE,
    CENTAUR_OIDS,
    CLASSIC_PLANETS,
    DWARFS,
    ECLIPSES,
    EXOPLANETS,
    FIXED_STARS,
    FLAGS_DWARFS,
    FLAGS_LILITH,
    FLAGS_MINORS,
    FLAGS_PLANETS,
    FLAGS_POINTS,
    HOUSE_SYSTEMS,
    INTERSTELLAR_OBJECTS,
    J2000,
    LILITH,
    NEAR_MARK,
    NEAR_STAR_ORB_DEG,
    PLANET_GLYPH,
    PLANETS,
    POINTS,
    ROYAL_STARS,
    SHADOW_MOONS,
    SIGNS_EN,
    SIGNS_GLYPH,
    SIGN_COLORS,
    SPICE_PARENT_MAP,
    TWOPI,
)

# Optional SPICE
_sp: Any = None
try:
    import spiceypy as _spiceypy
    _sp = _spiceypy
except Exception:
    pass


def _is_night_chart(sun_lon: float, asc_lon: float) -> bool:
    angular_distance = (sun_lon - asc_lon) % 360
    return 180 < angular_distance < 360


def _is_true(val: Any) -> bool:
    if isinstance(val, bool):
        return val
    if val is None:
        return False
    return str(val).lower() in ("true", "1", "yes", "on")


class Afterlife:
    """Core astrology calculation engine."""

    # Class-level constant mirrors for external access
    SIGNS_EN        = SIGNS_EN
    PLANETS         = PLANETS
    POINTS          = POINTS
    ARABIC_LOTS     = ARABIC_LOTS
    ASPECTS         = ASPECTS
    ADVANCED_POINTS = ADVANCED_POINTS
    ALLOWED_FOR_ACTIVE = ALLOWED_FOR_ACTIVE
    ASTEROIDS       = ASTEROIDS
    _ALIASES        = _ALIASES
    CENTAUR_OIDS    = CENTAUR_OIDS
    FIXED_STARS     = FIXED_STARS
    HOUSE_SYSTEMS   = HOUSE_SYSTEMS
    _PLANETARY_INCL = _PLANETARY_INCL
    FLAGS_PLANETS   = FLAGS_PLANETS
    FLAGS_POINTS    = FLAGS_POINTS
    FLAGS_DWARFS    = FLAGS_DWARFS
    FLAGS_LILITH    = FLAGS_LILITH
    FLAGS_MINORS    = FLAGS_MINORS
    INTERSTELLAR_OBJECTS = INTERSTELLAR_OBJECTS
    EXOPLANETS      = EXOPLANETS
    DWARFS          = DWARFS
    J2000           = J2000
    LILITH          = LILITH
    TWOPI           = TWOPI
    SIGNS_GLYPH     = SIGNS_GLYPH
    SIGN_COLORS     = SIGN_COLORS
    CLASSIC_PLANETS = CLASSIC_PLANETS
    PLANET_GLYPH    = PLANET_GLYPH
    CATEGORY_TITLES_BASE = CATEGORY_TITLES_BASE
    CATEGORY_RING   = CATEGORY_RING
    NEAR_MARK       = NEAR_MARK
    NEAR_STAR_ORB_DEG = NEAR_STAR_ORB_DEG
    SPICE_PARENT_MAP = SPICE_PARENT_MAP
    SHADOW_MOONS    = SHADOW_MOONS
    ROYAL_STARS     = ROYAL_STARS

    def __init__(
        self,
        ephe_dir: Optional[str] = None,
        spice_dir: Optional[str] = None,
    ) -> None:
        self.ephe_dir  = ephe_dir
        self.spice_dir = spice_dir
        self._ephe_path = None
        self._spice_path = None
        self._show_flags: Dict[str, Any] = {}
        self._fixed_star_cache: Dict[str, Any] = {}
        self._lot_cache: Dict[str, Any] = {}
        self._cache_asteroids: Dict[str, Any] = {}

        self._resolve_paths()
    # ------------------------------------------------------------------
    # Math helpers
    # ------------------------------------------------------------------

    @staticmethod
    def norm360(x: float) -> float:
        x = x % 360.0
        return x + 360.0 if x < 0 else x

    @classmethod
    def zodiac_sign(cls, lon: float) -> Tuple[str, float]:
        lon = cls.norm360(lon)
        idx = int(lon // 30)
        return SIGNS_EN[idx], lon - idx * 30

    @classmethod
    def lon_to_sign_dms(cls, lon: float) -> str:
        lon = cls.norm360(lon)
        s   = SIGNS_EN[int(lon // 30)]
        l   = lon % 30
        d   = int(l)
        m   = int((l - d) * 60)
        sec = round((l - d - m / 60) * 3600)
        return f"{s} {d}°{m}′{sec}″"

    @classmethod
    def ang_dist(cls, a: float, b: float) -> float:
        d = abs(cls.norm360(a) - cls.norm360(b))
        return d if d <= 180 else 360 - d

    @staticmethod
    def normalize_name(s: str) -> str:
        return (s or "").lower().replace("-", "").replace("_", "").replace(" ", "")

    @staticmethod
    def canon_name(s: str) -> str:
        if not s:
            return ""
        s = unicodedata.normalize("NFKD", s)
        s = "".join(c for c in s if not unicodedata.combining(c))
        s = s.replace("ʻ", "").replace("'", "").replace(" ", "_")
        return s.strip().lower()

    @staticmethod
    def _split_csvish(s: str) -> List[str]:
        if s is None:
            return []
        s = s.strip()
        if len(s) >= 2 and s[0] in ('"', "'") and s[-1] == s[0]:
            s = s[1:-1].strip()
        return [x.strip() for x in s.split(",") if x.strip()]

    # ------------------------------------------------------------------
    # Ephemeris / SPICE init
    # ------------------------------------------------------------------

    def _resolve_paths(self):
        if self.ephe_dir and Path(self.ephe_dir).is_dir():
            self._ephe_path = Path(self.ephe_dir)
        else:
            base = Path(__file__).resolve().parent
            candidates = [
                base / "data" / "ephe",
                base.parent / "ephe",
                base / "_data" / "ephe",
            ]
            for cand in candidates:
                if cand.exists():
                    self._ephe_path = cand
                    break

        # If still not found, try the download cache
        if self._ephe_path is None:
            try:
                from afterlife.data.downloader import ensure_ephe
                cached = ensure_ephe(prompt=True)
                if cached and cached.exists():
                    self._ephe_path = cached
            except Exception:
                pass

        if self._ephe_path:
            swe.set_ephe_path(str(self._ephe_path))
        
        if self.spice_dir and Path(self.spice_dir).is_dir():
            self._spice_path = Path(self.spice_dir)
        else:
            base = Path(__file__).resolve().parent
            for _ in range(7):
                cand = base / "_data" / "ephe"
                if cand.exists():
                    self._spice_path = cand
                    break
                base = base.parent

        # Fall back to the ephemeris download cache (e.g. ~/.cache/afterlife/ephe/ephe/)
        if self._spice_path is None and self._ephe_path is not None:
            if (self._ephe_path / "de440s.bsp").exists():
                self._spice_path = self._ephe_path
            elif (self._ephe_path / "ephe" / "de440s.bsp").exists():
                self._spice_path = self._ephe_path / "ephe"
    
    def init_ephemeris(self) -> Dict[str, Any]:
        return {"swisseph_ephe_path": str(self._ephe_path) if self._ephe_path else None}
    
    def _find_spice_dir(self) -> Optional[Path]:
        return self._spice_path
    
    def load_spice(self) -> Dict[str, Any]:
        meta = {"spice_available": _sp is not None, "loaded": False, "kernels": []}
        if _sp is None or self._spice_path is None:
            return meta
        
        try:
            _sp.kclear()
        except Exception:
            pass
        
        kernels = []
        for name in ("naif0012.tls", "de440s.bsp"):
            p = self._spice_path / name
            if p.exists():
                kernels.append(p)
        
        for f in sorted(os.listdir(self._spice_path)):
            fp = self._spice_path / f
            if fp.is_file() and f.lower().endswith(".bsp") and f.lower() != "de440s.bsp":
                kernels.append(fp)
        
        loaded = []
        for p in kernels:
            try:
                _sp.furnsh(str(p))
                loaded.append(p.name)
            except Exception:
                pass
        
        meta["loaded"] = bool(loaded)
        meta["kernels"] = loaded
        meta["spice_dir"] = str(self._spice_path)
        return meta
    
    # ------------------------------------------------------------------
    # Low-level calculators
    # ------------------------------------------------------------------

    @staticmethod
    def _calc_swiss(jd: float, code: int, flags: int) -> Tuple[float, float, float]:
        swe.set_topo(0.0, 0.0, 0.0)
        xx, _ = swe.calc_ut(jd, code, flags)
        return (
            Afterlife.norm360(xx[0]),
            float(xx[1]),
            float(xx[3]),
        )

    @staticmethod
    def jd_to_et(jd: float) -> float:
        if _sp is None:
            raise RuntimeError("SPICE not available")
        y, m, d, h = swe.revjul(jd)
        hh = int(h)
        mm = int((h - hh) * 60)
        ss = int((h - hh - mm / 60) * 3600)
        return _sp.str2et(f"{y}-{m:02d}-{d:02d}T{hh:02d}:{mm:02d}:{ss:02d}")

    @staticmethod
    def spice_lon_lat(et: float, obj_id: int) -> Tuple[float, float]:
        if _sp is None:
            raise RuntimeError("SPICE not available")
        state, _ = _sp.spkgeo(obj_id, et, "J2000", 0)
        x, y, z = state[:3]
        lon = Afterlife.norm360(math.degrees(math.atan2(y, x)))
        lat = math.degrees(math.atan2(z, math.hypot(x, y)))
        return float(lon), float(lat)

    def compute_spice_speed(self, obj_id: int, jd: float, delta: float = 1e-4) -> float:
        et1 = self.jd_to_et(jd)
        et2 = self.jd_to_et(jd + delta)
        lon1, _ = self.spice_lon_lat(et1, obj_id)
        lon2, _ = self.spice_lon_lat(et2, obj_id)
        d = (lon2 - lon1 + 180) % 360 - 180
        return d / delta

    @staticmethod
    def ra_dec_to_ecliptic_lon(ra_deg: float, dec_deg: float, eps_deg: float = 23.4392911) -> float:
        ra  = math.radians(ra_deg)
        dec = math.radians(dec_deg)
        eps = math.radians(eps_deg)
        y   = math.sin(ra) * math.cos(eps) + math.tan(dec) * math.sin(eps)
        x   = math.cos(ra)
        return Afterlife.norm360(math.degrees(math.atan2(y, x)))

    # ------------------------------------------------------------------
    # Body builder
    # ------------------------------------------------------------------

    @classmethod
    def _build(cls, name: str, lon: float, lat: float, speed: Optional[float]) -> Dict[str, Any]:
        nm_norm = cls.normalize_name(name)
        obj: Dict[str, Any] = {
            "name":     name,
            "lon":      cls.norm360(lon),
            "lat":      float(lat),
            "retro":    bool(speed is not None and speed < 0),
            "type":     None,
            "category": None,
        }
        if speed is not None:
            obj["speed"] = float(speed)

        if name in CLASSIC_PLANETS:
            obj["type"] = "Planet"; obj["category"] = "planets"; return obj
        if nm_norm.startswith("pluto"):
            if "barycenter" in nm_norm:
                obj.update(type="Barycenter", category="barycenters", parent="Pluto")
            elif "node" in nm_norm:
                obj.update(type="PlanetaryNode", category="planetary_nodes", parent="Pluto")
            else:
                obj.update(type="Planet", category="planets")
            return obj
        if "moon" in nm_norm:
            obj["type"] = "Moon"; obj["category"] = "moons"; return obj
        if name in DWARFS:
            obj["type"] = "Dwarf"; obj["category"] = "dwarfs"; return obj
        if name in ASTEROIDS:
            obj["type"] = "Asteroid"; obj["category"] = "asteroids"; return obj
        if name in CENTAUR_OIDS:
            obj["type"] = "Centaur"; obj["category"] = "centaurs"; return obj
        obj["type"] = "Object"; obj["category"] = "misc"
        return obj

    # ------------------------------------------------------------------
    # Houses
    # ------------------------------------------------------------------

    @classmethod
    def compute_houses(cls, jd: float, lat: float, lon: float, system: str) -> Dict[str, Any]:
        key  = (system or "placidus").strip().lower()
        hsys = HOUSE_SYSTEMS.get(key, "P").encode("ascii")
        cusps, ascmc = swe.houses(jd, lat, lon, hsys)
        cusps12 = [cls.norm360(c) for c in (cusps[1:13] if len(cusps) == 13 else cusps)]
        return {
            "system":    key,
            "cusps":     cusps12,
            "cusps_map": {f"House {i+1}": cusps12[i] for i in range(12)},
            "angles":    {"ASC": cls.norm360(ascmc[0]), "MC": cls.norm360(ascmc[1])},
        }

    @classmethod
    def house_of_longitude(cls, lon: float, cusps: List[float]) -> int:
        lon = lon % 360
        for i in range(12):
            s, e = cusps[i], cusps[(i + 1) % 12]
            if s < e and s <= lon < e:
                return i + 1
            if s > e and (lon >= s or lon < e):
                return i + 1
        return 12

    # ------------------------------------------------------------------
    # Aspects
    # ------------------------------------------------------------------

    @staticmethod
    def _orb_default(a: str, b: str) -> float:
        majors = {"Sun", "Moon", "Ascendant", "Midheaven"}
        if a in majors or b in majors:
            return 10.0
        if "Node" in a or "Node" in b:
            return 8.0
        if "Lot" in a or "Lot" in b or a in ARABIC_LOTS or b in ARABIC_LOTS:
            return 7.0
        return 6.0

    @classmethod
    def compute_aspects(cls, points: Dict[str, float], limit: int = 100) -> List[Dict[str, Any]]:
        IMPORTANT = {
            "Sun", "Moon", "Mercury", "Venus", "Mars",
            "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto",
            "Ascendant", "ASC", "Midheaven", "MC",
        }
        filtered = {k: v for k, v in points.items() if k in IMPORTANT}
        out: List[Dict[str, Any]] = []
        names = list(filtered.keys())
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                A, B = names[i], names[j]
                lonA, lonB = filtered[A], filtered[B]
                if lonA is None or lonB is None:
                    continue
                dist = cls.ang_dist(lonA, lonB)
                orb  = cls._orb_default(A, B)
                for asp, angle in ASPECTS.items():
                    delta = abs(dist - angle)
                    if delta <= orb:
                        out.append({"a": A, "b": B, "aspect": asp,
                                    "exact": angle, "distance": round(dist, 6),
                                    "orb": round(delta, 6)})
                        break
        out.sort(key=lambda x: x["orb"])
        return out[:limit]

    # ------------------------------------------------------------------
    # Fixed stars
    # ------------------------------------------------------------------

    def compute_fixed_stars(
        self,
        jd: float,
        cusps: List[float],
        bodies: Optional[Dict[str, Any]] = None,
        orb: float = 2.5,
    ) -> List[Dict[str, Any]]:
        year        = swe.revjul(jd)[0]
        delta_deg   = (year - 2000.0) * (50.29 / 3600)
        out = []
        for name, base_lon in FIXED_STARS.items():
            lon  = self.norm360(base_lon + delta_deg)
            sign, _ = self.zodiac_sign(lon)
            out.append({
                "name":     name,
                "lon":      lon,
                "lat":      0.0,
                "sign":     sign,
                "dms":      self.lon_to_sign_dms(lon),
                "house":    self.house_of_longitude(lon, cusps) if cusps else None,
                "royal":    name in ROYAL_STARS,
                "type":     "Fixed Star",
                "category": "fixed_stars",
                "source":   "manual+precession",
            })
        return out

    # ------------------------------------------------------------------
    # Planetary nodes
    # ------------------------------------------------------------------

    @staticmethod
    def compute_planetary_node(lon: float, lat: float, inc: float) -> Tuple[float, float]:
        lon_r = math.radians(lon)
        lat_r = math.radians(lat)
        inc_r = math.radians(inc)
        asc   = math.degrees(lon_r - math.atan(lat_r / math.tan(inc_r))) % 360
        return float(asc), float((asc + 180) % 360)

    # ------------------------------------------------------------------
    # Arabic lots
    # ------------------------------------------------------------------

    @classmethod
    def lot_formula(cls, asc: float, a: float, b: float) -> float:
        return cls.norm360(asc + a - b)

    @classmethod
    def compute_arabic_lots(cls, points: Dict[str, Any], is_night: bool) -> Dict[str, float]:
        asc     = points["Ascendant"]["lon"]
        sun     = points["Sun"]["lon"]
        moon    = points["Moon"]["lon"]
        mercury = points["Mercury"]["lon"]
        venus   = points["Venus"]["lon"]
        mars    = points["Mars"]["lon"]
        jupiter = points["Jupiter"]["lon"]
        saturn  = points["Saturn"]["lon"]
        is_day  = not is_night

        lots: Dict[str, float] = {}
        if is_day:
            lots["Fortuna"] = cls.norm360(asc + moon - sun)
            lots["Basis"]   = cls.norm360(asc + saturn - moon)
        else:
            lots["Fortuna"] = cls.norm360(asc + sun - moon)
            lots["Basis"]   = cls.norm360(asc + moon - saturn)

        lots["Spirit"]        = cls.norm360(asc + sun - moon) if is_day else cls.norm360(asc + moon - sun)
        lots["Eros"]          = cls.lot_formula(asc, venus,   sun)
        lots["Victory"]       = cls.lot_formula(asc, jupiter, sun)
        lots["Nemesis"]       = cls.lot_formula(asc, mars,    saturn)
        lots["Marriage"]      = cls.lot_formula(asc, venus,   moon)
        lots["Death"]         = cls.lot_formula(asc, saturn,  moon)
        lots["Courage"]       = cls.lot_formula(asc, mars,    moon)
        lots["Children"]      = cls.lot_formula(asc, venus,   jupiter)
        lots["Sons"]          = cls.lot_formula(asc, jupiter, moon)
        lots["Mother"]        = cls.lot_formula(asc, venus,   moon)
        lots["Father"]        = cls.lot_formula(asc, sun,     saturn)
        lots["Sudden Fortune"]= cls.lot_formula(asc, jupiter, venus)
        lots["Injury"]        = cls.lot_formula(asc, mars,    saturn)
        lots["Illness"]       = cls.lot_formula(asc, moon,    saturn)
        lots["Travel"]        = cls.lot_formula(asc, moon,    jupiter)
        lots["Commerce"]      = cls.lot_formula(asc, mercury, moon)
        lots["Discord"]       = cls.lot_formula(asc, mars,    mercury)
        lots["Fame"]          = cls.lot_formula(asc, sun,     jupiter)
        lots["Triumph"]       = cls.lot_formula(asc, jupiter, mars)
        return lots

    # ------------------------------------------------------------------
    # Eclipses
    # ------------------------------------------------------------------

    def compute_eclipses(self, jd: float) -> Dict[str, Any]:
        def _pos(ejd: float, body: int) -> Tuple[float, float]:
            xx, _ = swe.calc_ut(ejd, body)
            return xx[0], xx[1]

        eclipses: Dict[str, Any] = {}
        specs = [
            ("Prenatal Solar Eclipse",   lambda: swe.sol_eclipse_when_glob(jd, 0, 0, 1), swe.SUN,  "SoEcl-"),
            ("Prenatal Lunar Eclipse",   lambda: swe.lun_eclipse_when(jd, 0, 1),          swe.MOON, "LuEcl-"),
            ("Postnatal Solar Eclipse",  lambda: swe.sol_eclipse_when_glob(jd, 0, 0, 0), swe.SUN,  "SoEcl+"),
            ("Postnatal Lunar Eclipse",  lambda: swe.lun_eclipse_when(jd, 0, 0),          swe.MOON, "LuEcl+"),
        ]
        for name, fn, body_code, tag in specs:
            try:
                _, tret = fn()
                lon, lat = _pos(tret[0], body_code)
                obj = self._build(name, lon, lat, None)
                obj.update(house=None, sign=self.zodiac_sign(lon)[0],
                           tag=tag, type="Eclipse", category="eclipses", parent="Eclipse")
                eclipses[name] = obj
            except Exception:
                pass
        return eclipses

    # ------------------------------------------------------------------
    # Exoplanets / interstellar
    # ------------------------------------------------------------------

    def compute_exoplanetary_points(self, jd: float) -> Dict[str, Any]:
        out = {}
        for name, data in EXOPLANETS.items():
            lon  = self.ra_dec_to_ecliptic_lon(data["ra_deg"], data["dec_deg"])
            body = self._build(name, lon, data["dec_deg"], None)
            body["type"] = "Exoplanetary Point"
            out[name] = body
        return out

    def compute_interstellar_objects(self, jd: float) -> Dict[str, Any]:
        out = {}
        for name, data in INTERSTELLAR_OBJECTS.items():
            lon  = self.ra_dec_to_ecliptic_lon(data["ra_deg"], data["dec_deg"])
            body = self._build(name, lon, data["dec_deg"], None)
            body.update(type="Interstellar Object", designation=data.get("designation"),
                        label=data.get("label"), epoch_jd=float(jd), origin="Interstellar Space")
            out[name] = body
        return out

    # ------------------------------------------------------------------
    # Genome (fingerprint)
    # ------------------------------------------------------------------

    def encode_genome(self, payload: Dict[str, Any]) -> str:
        s   = json.dumps(payload, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
        acc = 0
        for ch in s:
            acc = (acc * 131 + ord(ch)) & 0xFFFFFFFF
        return f"{acc:08x}"

    def interpret_genome(self, genome: str) -> Dict[str, Any]:
        seed = int(genome[:8], 16) if genome else 0
        return {"seed": seed}

    def compute_personal_moon(self, genome_str: str) -> Dict[str, Any]:
        seed = sum(ord(c) for c in genome_str) % 360
        body = self._build("Personal Moon", seed, 0.0, None)
        body.update(type="Personal Moon", source="genome", cycle_days=27.321)
        return body

    # ------------------------------------------------------------------
    # compute_bodies — the heavy lifter
    # ------------------------------------------------------------------

    def compute_bodies(self, jd: float, lat: float, lon: float) -> Dict[str, Any]:
        self.init_ephemeris()
        spice_meta = self.load_spice()

        out: Dict[str, Any] = {
            "moons": {}, "planets": {}, "dwarfs": {}, "asteroids": {},
            "centaurs": {}, "points": {}, "advanced_points": {},
            "arabic_lots": {}, "eclipses": {}, "lilith": {},
            "planetary_nodes": {}, "exoplanets": {}, "interstellar": {},
        }

        # Planets
        for name, code in PLANETS.items():
            L, B, S = self._calc_swiss(jd, code, FLAGS_PLANETS)
            out["planets"][name] = self._build(name, L, B, S)

        # SPICE bodies
        et: Optional[float] = None
        if _sp is not None and spice_meta.get("loaded"):
            try:
                et = self.jd_to_et(jd)
            except Exception:
                pass

        def _spice(cat: str, name: str, obj_id: int) -> None:
            if et is None:
                return
            try:
                L, B = self.spice_lon_lat(et, obj_id)
                S    = self.compute_spice_speed(obj_id, jd)
                out[cat][name] = self._build(name, L, B, S)
                out[cat][name]["source"] = "spice"
            except Exception:
                try:
                    L, B, S = self._calc_swiss(jd, obj_id, FLAGS_DWARFS)
                    out[cat][name] = self._build(name, L, B, S)
                    out[cat][name]["source"] = "swiss"
                except Exception:
                    pass

        for name, obj_id in DWARFS.items():
            _spice("dwarfs", name, obj_id)

        for name, obj_id in ASTEROIDS.items():
            _spice("asteroids", name, obj_id)

        for name, obj_id in CENTAUR_OIDS.items():
            _spice("centaurs", name, obj_id)
            if name in out["centaurs"]:
                out["centaurs"][name].update(type="Centaur", category="centaurs")

        # Exo + interstellar
        try:
            out["exoplanets"]   = self.compute_exoplanetary_points(jd)
        except Exception:
            pass
        try:
            out["interstellar"] = self.compute_interstellar_objects(jd)
        except Exception:
            pass

        # Points / angles
        try:
            _h, ac = swe.houses_ex(jd, lat, lon, b"P")
            asc_lon = self.norm360(ac[0])
            mc_lon  = self.norm360(ac[1])
            out["points"]["Ascendant"] = self._build("Ascendant", asc_lon,       0, None)
            out["points"]["Midheaven"] = self._build("Midheaven", mc_lon,         0, None)
            out["advanced_points"].update({
                "Descendant":    self._build("Descendant",    self.norm360(asc_lon + 180), 0, None),
                "IC":            self._build("IC",            self.norm360(mc_lon  + 180), 0, None),
                "Zenith":        self._build("Zenith",        mc_lon,                       0, None),
                "Nadir":         self._build("Nadir",         self.norm360(mc_lon  + 180), 0, None),
                "Galactic Center":       self._build("Galactic Center",       267.11, 0, None),
                "Super Galactic Center": self._build("Super Galactic Center", 182.09, 0, None),
                "Great Attractor":       self._build("Great Attractor",       254.27, 0, None),
                "Shapley Attractor":     self._build("Shapley Attractor",     221.75, 0, None),
                "Laniakea Center":       self._build("Laniakea Center",       193.50, 0, None),
                "Aries Point":           self._build("Aries Point",             0.0,  0, None),
                "Solar Apex":            self._build("Solar Apex",            270.52, 0, None),
                "Co-Ascendant":          self._build("Co-Ascendant",  self.norm360(ac[6]), 0, None),
                "Co-Midheaven":          self._build("Co-Midheaven",  self.norm360(ac[7]), 0, None),
                "Polar Ascendant":       self._build("Polar Ascendant",self.norm360(ac[9]),0, None),
                "Vertex":                self._build("Vertex",         self.norm360(ac[3]), 0, None),
                "East Point":            self._build("East Point",     self.norm360(ac[4]), 0, None),
            })
        except Exception:
            pass

        # Extra points
        for name, code in POINTS.items():
            try:
                L, B, S = self._calc_swiss(jd, code, FLAGS_POINTS)
                out["points"][name] = self._build(name, L, B, S)
            except Exception:
                pass

        if "True Node" in out["points"]:
            nn = out["points"]["True Node"]["lon"]
            out["points"]["North Node"] = self._build("North Node", nn,                       0, None)
            out["points"]["South Node"] = self._build("South Node", self.norm360(nn + 180),   0, None)

        for name, code in ADVANCED_POINTS.items():
            if name in out["advanced_points"] or code is None:
                continue
            try:
                L, B, S = self._calc_swiss(jd, code, FLAGS_POINTS)
                out["advanced_points"][name] = self._build(name, L, B, S)
            except Exception:
                pass

        # Lilith
        for name, code in LILITH.items():
            try:
                L, B, S = self._calc_swiss(jd, code, FLAGS_LILITH)
                out["lilith"][name] = self._build(name, L, B, S)
            except Exception:
                pass

        # Planetary nodes
        for p_name, p_obj in out["planets"].items():
            if p_name in _PLANETARY_INCL:
                inc  = _PLANETARY_INCL[p_name]
                asc, desc = self.compute_planetary_node(p_obj["lon"], p_obj["lat"], inc)
                out["planetary_nodes"][f"{p_name} Ascending Node"]  = self._build(f"{p_name} Ascending Node",  asc,  0, None)
                out["planetary_nodes"][f"{p_name} Descending Node"] = self._build(f"{p_name} Descending Node", desc, 0, None)

        # Arabic lots (preliminary — will be recalculated with house cusps in compute_astro_chart)
        try:
            asc_lon = out["points"]["Ascendant"]["lon"]
            sun_lon = out["planets"]["Sun"]["lon"]
            lot_pts = {
                "Ascendant": {"lon": asc_lon},
                "Sun":       {"lon": sun_lon},
                "Moon":      {"lon": out["planets"]["Moon"]["lon"]},
                "Mercury":   {"lon": out["planets"]["Mercury"]["lon"]},
                "Venus":     {"lon": out["planets"]["Venus"]["lon"]},
                "Mars":      {"lon": out["planets"]["Mars"]["lon"]},
                "Jupiter":   {"lon": out["planets"]["Jupiter"]["lon"]},
                "Saturn":    {"lon": out["planets"]["Saturn"]["lon"]},
            }
            is_night  = _is_night_chart(sun_lon, asc_lon)
            lots_raw  = self.compute_arabic_lots(lot_pts, is_night)
            for lot_name, lot_lon in lots_raw.items():
                nl = self.norm360(lot_lon)
                out["arabic_lots"][lot_name] = {
                    "name": lot_name, "lon": nl, "lat": 0.0,
                    "dms":  self.lon_to_sign_dms(nl),
                    "sign": self.zodiac_sign(nl)[0],
                    "house": None, "type": "Arabic Lot",
                    "category": "arabic_lots", "source": "computed",
                }
        except Exception:
            pass

        out["eclipses"] = self.compute_eclipses(jd)
        return out

    # ------------------------------------------------------------------
    # compute_astro_chart — main public API
    # ------------------------------------------------------------------

    def compute_astro_chart(
        self,
        date_str: str,
        time_str: str,
        lat: float,
        lon: float,
        house_system: str = "placidus",
        tz_offset: float = 3.0,
        fixed_star_orb: float = 2.5,
        exclude: str = "",
        include: str = "",
        sort_by: str = "",
        limit: int = 0,
        planets_limit: int = 0,
        moons_limit: int = 0,
        dwarfs_limit: int = 0,
        asteroids_limit: int = 0,
        centaurs_limit: int = 0,
        points_limit: int = 0,
        advanced_points_limit: int = 0,
        lilith_limit: int = 0,
        planetary_nodes_limit: int = 0,
        exoplanets_limit: int = 0,
        interstellar_limit: int = 0,
        fixed_stars_limit: int = 0,
        arabic_lots_limit: int = 0,
    ) -> Dict[str, Any]:

        self.init_ephemeris()

        exclude_list = [x.strip() for x in exclude.split(",") if x.strip()] if exclude else []

        dd, mm, yy = date_str.split("-")
        y, m, d = int(yy), int(mm), int(dd)
        hh_, mn_ = time_str.split(":")
        ut = (int(hh_) + int(mn_) / 60.0) - float(tz_offset)
        jd = swe.julday(y, m, d, ut)

        bodies = self.compute_bodies(jd, lat, lon)

        for cat in list(bodies.keys()):
            if isinstance(bodies[cat], dict):
                for obj_name in list(bodies[cat].keys()):
                    if obj_name in exclude_list:
                        del bodies[cat][obj_name]

        houses = self.compute_houses(jd, lat, lon, system=house_system)
        cusps = houses["cusps"]

        sign_cache = {}
        dms_cache = {}

        for category in (
            "planets","dwarfs","asteroids","centaurs",
            "planetary_nodes","lilith","points",
            "advanced_points","exoplanets","interstellar",
            "moons","arabic_lots",
        ):
            catdict = bodies.get(category, {})
            if not isinstance(catdict, dict):
                continue

            for obj in catdict.values():
                lonv = obj.get("lon")
                if lonv is None:
                    continue

                obj["house"] = self.house_of_longitude(lonv, cusps)

                if lonv not in dms_cache:
                    dms_cache[lonv] = self.lon_to_sign_dms(lonv)
                obj["dms"] = dms_cache[lonv]

                if lonv not in sign_cache:
                    sign_cache[lonv] = self.zodiac_sign(lonv)[0]
                obj["sign"] = sign_cache[lonv]

        fs_key = f"{int(jd)}-{fixed_star_orb}"
        if fs_key not in self._fixed_star_cache:
            self._fixed_star_cache[fs_key] = self.compute_fixed_stars(jd, cusps, bodies=bodies, orb=fixed_star_orb)

        bodies["fixed_stars"] = {
            o["name"]: o for o in self._fixed_star_cache[fs_key]
            if o["name"] not in exclude_list
        }

        lot_key = f"{int(jd)}-{lat}-{lon}"
        if lot_key not in self._lot_cache:
            req = ["Sun","Mercury","Venus","Mars","Jupiter","Saturn","Ascendant"]
            lot_pts = {p: bodies["planets"].get(p) or bodies["points"].get(p) for p in req}
            lot_pts["Moon"] = bodies["planets"].get("Moon")

            if all(v and "lon" in v for v in lot_pts.values()):
                night = _is_night_chart(lot_pts["Sun"]["lon"], lot_pts["Ascendant"]["lon"])
                lots_raw = self.compute_arabic_lots(lot_pts, night)

                res = {}
                for n, lonv in lots_raw.items():
                    if n not in exclude_list:
                        nl = self.norm360(lonv)
                        res[n] = {
                            "name": n,
                            "lon": nl,
                            "lat": 0.0,
                            "type": "Arabic Lot",
                            "category": "arabic_lots",
                            "source": "computed",
                            "dms": self.lon_to_sign_dms(nl),
                            "house": self.house_of_longitude(nl, cusps),
                            "sign": self.zodiac_sign(nl)[0],
                        }
                self._lot_cache[lot_key] = res
            else:
                self._lot_cache[lot_key] = {}

        bodies["arabic_lots"] = self._lot_cache[lot_key]

        genome = self.encode_genome({"bodies": bodies})
        if "Personal Moon" not in exclude_list:
            pm = self.compute_personal_moon(genome)
            pm["sign"]  = self.zodiac_sign(pm["lon"])[0]
            pm["dms"]   = self.lon_to_sign_dms(pm["lon"])
            pm["house"] = self.house_of_longitude(pm["lon"], cusps)
            bodies.setdefault("moons", {})["Personal Moon"] = pm

        show = self._show_flags

        def apply_limit(cat_name, limit_value):
            if cat_name not in bodies:
                return
            items = list(bodies[cat_name].items())

            if sort_by == "name":
                items.sort(key=lambda x: x[0])
            elif sort_by == "lon":
                items.sort(key=lambda x: x[1].get("lon", 0))
            elif sort_by == "house":
                items.sort(key=lambda x: (x[1].get("house") or 0))
            elif sort_by == "sign":
                items.sort(key=lambda x: x[1].get("sign", ""))

            if limit_value > 0:
                items = items[:limit_value]

            bodies[cat_name] = dict(items)

        apply_limit("planets", planets_limit or limit)
        apply_limit("moons", moons_limit or limit)
        apply_limit("dwarfs", dwarfs_limit or limit)
        apply_limit("asteroids", asteroids_limit or limit)
        apply_limit("centaurs", centaurs_limit or limit)
        apply_limit("points", points_limit or limit)
        apply_limit("advanced_points", advanced_points_limit or limit)
        apply_limit("lilith", lilith_limit or limit)
        apply_limit("planetary_nodes", planetary_nodes_limit or limit)
        apply_limit("exoplanets", exoplanets_limit or limit)
        apply_limit("interstellar", interstellar_limit or limit)
        apply_limit("fixed_stars", fixed_stars_limit or limit)
        apply_limit("arabic_lots", arabic_lots_limit or limit)

        def drop(cat):
            bodies.pop(cat, None)

        if not _is_true(show.get("show_moons", True)): drop("moons")
        if not _is_true(show.get("show_dwarfs", True)): drop("dwarfs")
        if not _is_true(show.get("show_asteroids", True)): drop("asteroids")
        if not _is_true(show.get("show_centaurs", True)): drop("centaurs")
        if not _is_true(show.get("show_planets", True)): drop("planets")
        if not _is_true(show.get("show_points", True)): drop("points")
        if not _is_true(show.get("show_advanced_points", True)): drop("advanced_points")
        if not _is_true(show.get("show_lilith", True)): drop("lilith")
        if not _is_true(show.get("show_planetary_nodes", True)): drop("planetary_nodes")
        if not _is_true(show.get("show_exoplanets", True)): drop("exoplanets")
        if not _is_true(show.get("show_interstellar", True)): drop("interstellar")
        if not _is_true(show.get("show_fixed_stars", True)): drop("fixed_stars")
        if not _is_true(show.get("show_arabic_lots", True)): drop("arabic_lots")
        if not _is_true(show.get("show_eclipses", True)): drop("eclipses")

        if include and include.strip():
            wanted = [x.strip().lower() for x in self._split_csvish(include)]
            kept = {}
            for cat, objs in bodies.items():
                if not isinstance(objs, dict):
                    continue
                kept_cat = {n: o for n, o in objs.items() if n.strip().lower() in wanted}
                if kept_cat:
                    kept[cat] = kept_cat
            bodies = kept

        result = {
            "jd": float(jd),
            "bodies": bodies,
            "houses": houses if _is_true(show.get("show_houses", True)) else {},
            "input": {
                "date": date_str,
                "time": time_str,
                "lat": float(lat),
                "lon": float(lon),
                "tz_offset": float(tz_offset),
                "house_system": house_system,
                "fixed_star_orb": fixed_star_orb,
            },
            "version": AFTERLIFE_EPHEMERIS_VERSION,
            "source": AFTERLIFE_EPHEMERIS_SOURCE,
            "note": AFTERLIFE_EPHEMERIS_NOTE,
        }

        return json.dumps(result, ensure_ascii=False, indent=2)

    # ------------------------------------------------------------------
    # Transit helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_ddmmyyyy(date_str: str) -> Tuple[int, int, int]:
        dd, mm, yy = date_str.split("-")
        return int(yy), int(mm), int(dd)

    def transit_snapshot(
        self,
        natal_chart: Dict[str, Any],
        body: str,
        date_from: str,
        date_to: str,
        step_days: int = 1,
        exact_orb: float = 0.1,
    ) -> Dict[str, Any]:
        planet_key = next(
            (k for k in PLANETS if self.canon_name(k) == self.canon_name(body)), None
        )
        if planet_key is None:
            return {"object": body, "from": date_from, "to": date_to, "events": []}

        start  = datetime.fromisoformat(date_from)
        end    = datetime.fromisoformat(date_to)
        houses = natal_chart.get("houses") or {}
        cusps  = houses.get("cusps") or []

        natal_points: Dict[str, float] = {}
        for cat in ("planets", "points"):
            for name, obj in (natal_chart.get("bodies", {}).get(cat, {}) or {}).items():
                if isinstance(obj, dict) and "lon" in obj:
                    natal_points[name] = float(obj["lon"])
        angles = houses.get("angles") or {}
        if "ASC" in angles:
            natal_points["ASC"] = float(angles["ASC"])

        events: List[Dict[str, Any]] = []
        final_exact: Dict[tuple, Dict[str, Any]] = {}
        last_sign = last_house = last_speed = None
        first = True
        d = start

        while d <= end:
            jd = swe.julday(d.year, d.month, d.day, 12.0)
            lon, _, speed = self._calc_swiss(jd, PLANETS[planet_key], FLAGS_PLANETS)
            sign  = SIGNS_EN[int(lon // 30)]
            house = self.house_of_longitude(lon, cusps) if len(cusps) >= 12 else None

            if first:
                events.append({"date": d.date().isoformat(), "type": "state_at_start",
                                "sign": sign, "sign_degree": round(lon % 30, 4), "speed": round(speed, 6),
                                **({"house": house} if house else {})})
                last_sign, last_house, last_speed, first = sign, house, speed, False
                d += timedelta(days=step_days)
                continue

            if sign != last_sign:
                events.append({"date": d.date().isoformat(), "type": "sign_ingress",
                                "sign": sign, "degree": round(lon % 30, 4)})
                last_sign = sign
            if house and house != last_house:
                events.append({"date": d.date().isoformat(), "type": "house_ingress",
                                "house": house, "degree": round(lon, 4)})
                last_house = house
            if last_speed is not None:
                if last_speed >= 0 and speed < 0:
                    events.append({"date": d.date().isoformat(), "type": "station_retrograde", "degree": round(lon, 4)})
                elif last_speed <= 0 and speed > 0:
                    events.append({"date": d.date().isoformat(), "type": "station_direct",    "degree": round(lon, 4)})
            last_speed = speed

            for name, natal_lon in natal_points.items():
                dist = self.ang_dist(lon, natal_lon)
                if dist <= exact_orb:
                    k = (name, "conjunction", sign)
                    if k not in final_exact or dist < final_exact[k]["orb"]:
                        final_exact[k] = {"date": d.date().isoformat(), "type": "exact_conjunction",
                                          "with": name, "orb": round(dist, 4)}
                opp = abs(dist - 180.0)
                if opp <= exact_orb:
                    k = (name, "opposition", sign)
                    if k not in final_exact or opp < final_exact[k]["orb"]:
                        final_exact[k] = {"date": d.date().isoformat(), "type": "exact_opposition",
                                          "with": name, "orb": round(opp, 4)}
            d += timedelta(days=step_days)

        events.extend(final_exact.values())
        return {"object": body, "from": date_from, "to": date_to,
                "events": sorted(events, key=lambda x: x["date"])}

    def moon_cycle(self, year: int, month: int, tz_offset: float = 3.0) -> Dict[str, Any]:
        start      = datetime(year, month, 1)
        next_month = (start.replace(day=28) + timedelta(days=4)).replace(day=1)
        days       = (next_month - start).days
        items      = []
        for i in range(days):
            dt   = start + timedelta(days=i)
            ut   = (dt.hour + dt.minute / 60.0) - float(tz_offset)
            jd   = float(swe.julday(dt.year, dt.month, dt.day, ut))
            bods = self.compute_bodies(jd, 0.0, 0.0)
            sun  = bods.get("planets", {}).get("Sun")
            moon = bods.get("planets", {}).get("Moon")
            if not sun or not moon:
                items.append({"date": dt.strftime("%Y-%m-%d"), "missing": True}); continue
            sl   = sun["lon"];  ml = moon["lon"]
            diff = (ml - sl) % 360
            d    = self.ang_dist(sl, ml)
            phase_map = [(10, "New Moon"), (170, None), (180, "Full Moon"), (190, None),
                         (82, "First Quarter"), (278, "Last Quarter")]
            if abs(diff) < 10:
                phase = "New Moon"
            elif abs(diff - 180) < 10:
                phase = "Full Moon"
            elif abs(diff - 90) < 8:
                phase = "First Quarter"
            elif abs(diff - 270) < 8:
                phase = "Last Quarter"
            elif diff < 180:
                phase = "Waxing Crescent" if d < 90 else "Waxing Gibbous"
            else:
                phase = "Waning Crescent" if d < 90 else "Waning Gibbous"
            items.append({
                "date": dt.strftime("%Y-%m-%d"),
                "moon": {"dms": self.lon_to_sign_dms(ml), "sign": self.zodiac_sign(ml)[0], "lon": ml},
                "sun":  {"dms": self.lon_to_sign_dms(sl), "sign": self.zodiac_sign(sl)[0], "lon": sl},
                "phase": phase, "phase_angle": round(diff, 4),
                "illumination": round((1 - math.cos(math.radians(d))) / 2 * 100, 2),
                "motion": "waxing" if diff < 180 else "waning",
                "lunar_day": int(diff // 12) + 1,
                "eclipse_candidate": abs(d) < 12 or abs(d - 180) < 12,
            })
        return {"mode": "moon_cycle", "year": year, "month": month, "tz_offset": float(tz_offset), "days": items}

    def supported_objects(self) -> Dict[str, Any]:
        names: set[str] = set()
        for d in (PLANETS, SHADOW_MOONS, DWARFS, ASTEROIDS, CENTAUR_OIDS, POINTS, ADVANCED_POINTS, LILITH):
            names.update(d.keys())
        names.update(FIXED_STARS.keys())
        names.update(EXOPLANETS.keys())
        names.update(INTERSTELLAR_OBJECTS.keys())
        return {"mode": "list", "count": len(names), "objects": sorted(names)}

    def apply_filters(
        self,
        chart: Dict[str, Any],
        sign: Optional[str] = None,
        house: Optional[List[int]] = None,
        parent: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not sign and not house and not parent:
            return chart
        sign_q   = (sign[0].upper() + sign[1:].lower()) if sign else ""
        house_set = set(house or [])
        parent_q  = (parent[0].upper() + parent[1:]) if parent else ""
        filtered: Dict[str, Any] = {}
        for category, objs in (chart.get("bodies") or {}).items():
            if not isinstance(objs, dict):
                continue
            kept = {}
            for name, obj in objs.items():
                if not isinstance(obj, dict):
                    continue
                if category == "eclipses":
                    kept[name] = obj; continue
                if sign_q    and obj.get("sign")   != sign_q:   continue
                if parent_q  and obj.get("parent") != parent_q: continue
                if house_set and obj.get("house")  not in house_set: continue
                kept[name] = obj
            if kept:
                filtered[category] = kept
        return {**chart, "bodies": filtered}

    # ------------------------------------------------------------------
    # Search objects
    # ------------------------------------------------------------------

    def get_all_objects(self, chart_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for items in (chart_data.get("bodies") or {}).values():
            if not isinstance(items, dict):
                continue
            for obj in items.values():
                if isinstance(obj, dict) and obj.get("name"):
                    out.append(obj)
        return out

    def search_objects(
        self,
        chart: Dict[str, Any],
        query: str,
        parent_query: Optional[str] = None,
        group: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        q        = self.normalize_name(query)
        parent_q = self.normalize_name(parent_query) if parent_query else None
        group    = group.lower() if group else None

        STATIC: Dict[str, tuple] = {
            "dwarfs":          (DWARFS,           "Dwarf"),
            "points":          (POINTS,           "Point"),
            "advanced_points": (ADVANCED_POINTS,  "AdvancedPoint"),
            "planetary_nodes": (_PLANETARY_INCL,  "PlanetaryNode"),
            "lilith":          (LILITH,           "Lilith"),
            "exoplanets":      (EXOPLANETS,       "Exoplanet"),
            "fixed_stars":     (FIXED_STARS,      "FixedStar"),
            "interstellars":   (INTERSTELLAR_OBJECTS, "Interstellar"),
        }
        if group in STATIC:
            src, typ = STATIC[group]
            return sorted(
                [{"name": n, "type": typ, "category": group}
                 for n in src if not q or self.normalize_name(n).startswith(q)],
                key=lambda x: x["name"],
            )

        results: List[Dict[str, Any]] = []
        for obj in self.get_all_objects(chart):
            nm_norm = self.normalize_name(obj.get("name", ""))
            if q and not nm_norm.startswith(q):
                continue
            if parent_q:
                parent = obj.get("parent")
                if parent:
                    pname = (SPICE_PARENT_MAP.get(parent, parent)
                             if isinstance(parent, int) else str(parent))
                    if self.normalize_name(pname) != parent_q:
                        continue
                else:
                    continue
            if group and obj.get("category") != group:
                continue
            results.append(obj)
        return sorted(results, key=lambda o: o.get("name", ""))

    # ------------------------------------------------------------------
    # Transit series (for quick mode)
    # ------------------------------------------------------------------

    def compute_transit_series(
        self,
        start_jd: float,
        end_jd: float,
        lat: float,
        lon: float,
        step_hours: int = 6,
        house_system: str = "placidus",
    ) -> Dict[str, Any]:
        step_days = step_hours / 24.0
        jd        = float(start_jd)
        samples: List[Dict[str, Any]] = []

        while jd <= end_jd:
            bodies = self.compute_bodies(jd, lat, lon)
            houses = self.compute_houses(jd, lat, lon, system=house_system)
            cusps  = houses["cusps"]
            for cat in (
                "planets", "dwarfs", "asteroids", "centaurs",
                "planetary_nodes", "lilith", "points",
                "advanced_points", "exoplanets", "interstellar",
                "moons", "arabic_lots",
            ):
                for obj in (bodies.get(cat) or {}).values():
                    if isinstance(obj, dict) and "lon" in obj:
                        obj["house"] = self.house_of_longitude(obj["lon"], cusps)
                        obj["dms"]   = self.lon_to_sign_dms(obj["lon"])
            samples.append({"jd": float(jd), "bodies": bodies, "houses": houses})
            jd += step_days

        return {
            "mode":       "transit_series",
            "start_jd":   float(start_jd),
            "end_jd":     float(end_jd),
            "step_hours": int(step_hours),
            "samples":    samples,
        }
