from __future__ import annotations

import math
from pathlib import Path
import swisseph as swe

BASE_DIR = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# Zodiac
# ---------------------------------------------------------------------------

SIGNS_EN: list[str] = [
    "Aries", "Taurus", "Gemini", "Cancer",
    "Leo", "Virgo", "Libra", "Scorpio",
    "Sagittarius", "Capricorn", "Aquarius", "Pisces",
]

SIGNS_GLYPH: list[str] = ["♈","♉","♊","♋","♌","♍","♎","♏","♐","♑","♒","♓"]

SIGN_COLORS: list[str] = [
    "#FF4500","#228B22","#FFD700","#4169E1",
    "#FF4500","#228B22","#FFD700","#4169E1",
    "#FF4500","#228B22","#FFD700","#4169E1",
]

# ---------------------------------------------------------------------------
# House systems
# ---------------------------------------------------------------------------

HOUSE_SYSTEMS: dict[str, str] = {
    "placidus": "P",
    "koch": "K",
    "porphyry": "O",
    "regiomontanus": "R",
    "campanus": "C",
    "equal": "E",
    "whole": "W",
    "alcabitius": "B",
    "morinus": "M",
    "topocentric": "T",
    "axial": "X",
    "vehlow": "V",
}

# ---------------------------------------------------------------------------
# Planets
# ---------------------------------------------------------------------------

PLANETS: dict[str, int] = {
    "Sun": swe.SUN,
    "Moon": swe.MOON,
    "Mercury": swe.MERCURY,
    "Venus": swe.VENUS,
    "Mars": swe.MARS,
    "Jupiter": swe.JUPITER,
    "Saturn": swe.SATURN,
    "Uranus": swe.URANUS,
    "Neptune": swe.NEPTUNE,
    "Pluto": swe.PLUTO,
}

CLASSIC_PLANETS: set[str] = {
    "Sun", "Mercury", "Venus", "Mars",
    "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto",
}

# ---------------------------------------------------------------------------
# Points
# ---------------------------------------------------------------------------

POINTS: dict[str, int] = {
    "Mean Node": swe.MEAN_NODE,
    "True Node": swe.TRUE_NODE,
}

ADVANCED_POINTS: dict[str, int | None] = {
    "Vertex": swe.VERTEX,
    "East Point": swe.EQUASC,
    "Ascendant": None,
    "Midheaven": None,
    "IC": None,
    "Descendant": None,
    "Co-Ascendant": None,
    "Co-Midheaven": None,
    "Zenith": None,
    "Nadir": None,
    "Galactic Center": None,
    "Super Galactic Center": None,
    "Great Attractor": None,
    "Shapley Attractor": None,
    "Laniakea Center": None,
    "Solar Apex": None,
    "Polar Ascendant": None,
    "Aries Point": None,
    "Priapus": None,
}

ASTRO_POINTS: set[str] = {
    "Ascendant", "Midheaven", "Vertex", "East Point", "West Point", "Fortuna",
}

LILITH: dict[str, int] = {
    "Mean Lilith": swe.MEAN_APOG,
    "True Lilith": swe.OSCU_APOG,
}

# ---------------------------------------------------------------------------
# Flags
# ---------------------------------------------------------------------------

FLAGS_PLANETS: int = swe.FLG_SWIEPH | swe.FLG_SPEED
FLAGS_MINORS: int  = swe.FLG_SWIEPH | swe.FLG_SPEED | swe.FLG_MOSEPH
FLAGS_DWARFS: int  = swe.FLG_SWIEPH | swe.FLG_SPEED
FLAGS_POINTS: int  = swe.FLG_SWIEPH | swe.FLG_SPEED | swe.FLG_MOSEPH
FLAGS_LILITH: int  = swe.FLG_SWIEPH | swe.FLG_SPEED

# ---------------------------------------------------------------------------
# Planetary inclinations
# ---------------------------------------------------------------------------

_PLANETARY_INCL: dict[str, float] = {
    "Mercury": 7.005,
    "Venus":   3.394,
    "Earth":   0.0,
    "Mars":    1.850,
    "Jupiter": 1.303,
    "Saturn":  2.489,
    "Uranus":  0.773,
    "Neptune": 1.770,
    "Pluto":   17.16,
}

# ---------------------------------------------------------------------------
# Dwarfs
# ---------------------------------------------------------------------------

DWARFS: dict[str, int] = {
    "Eris":           20136199,
    "Haumea":         20136108,
    "Makemake":       20136472,
    "Ceres":          20000001,
    "Sedna":          20090377,
    "Leleākūhonua":   20541132,
    "Quaoar":         20050000,
    "Orcus":          20090482,
    "Arrokoth":       20486958,
    "Varuna":         20020000,
    "Ixion":          20028978,
    "Chaos":          20019521,
    "Logos":          20058534,
    "Gonggong":       20225088,
    "Salacia":        20120347,
    "2002 TC302":     20084522,
    "2004 GV9":       20090568,
    "Altjira":        20148780,
    "Varda":          20174567,
    "Chiminigagua":   20532037,
    "Albion":         20015760,
    "Arawn":          20015810,
    "Xewioso":        20078799,
    "Mors-Somnus":    20341520,
    "Bida":           20323137,
    "Praamzius":      20420356,
    "Manwë":          20385446,
    "Dziewanna":      20471143,
    "Achlys":         20208996,
}

# ---------------------------------------------------------------------------
# Asteroids
# ---------------------------------------------------------------------------

ASTEROIDS: dict[str, int] = {
    "Moira":      20000638, "Atropos":    20000273, "Lachesis":   20000120,
    "Hybris":     20000430, "Nemesis":    20000128, "Psyche":     20000016,
    "Hekate":     20000100, "Klotho":     20000097, "Tyche":      20000258,
    "Fortuna":    20000019, "Victoria":   20000012, "Nike":       20000307,
    "Adonis":     20002101, "Hidalgo":    20000944, "Apollo":     20001862,
    "Panacea":    20002878, "Atlantis":   20001198, "Deucalion":  20053311,
    "Ritona":     20145452, "Admetos":    20085030, "Poseidon":   20004341,
    "Hygiea":     20000010, "Artemis":    20000105, "Medusa":     20000149,
    "Koronis":    20000158, "Pandora":    20000055, "Myrrha":     20000381,
    "Celuta":     20000186, "Industria":  20000389, "Arachne":    20000407,
    "Demeter":    20001108, "Elektra":    20000130, "Hera":       20000103,
    "Hestia":     20000046, "Kallisto":   20000204, "Persephone": 20000399,
    "Orpheus":    20003361, "Astraea":    20000005, "Achilles":   20000588,
    "Prometheus": 20001809, "Eureka":     20005261, "Egeria":     20000013,
    "Athanasia":  20000730, "Hypnos":     20014827, "Pholus":     20005145,
    "Ryugu":      20162173, "Itokawa":    20025143, "Apophis":    20099942,
    "Gaspra":     20000951, "Ida":        20000243, "2015 TG38":  54509588,
    "Pallas":     20000002, "Juno":       20000003, "Vesta":      20000004,
    "Abundantia": 20000151, "Academia":   20000829, "Aegle":      20000096,
    "Alkeste":    20000124, "Angel":      20011911, "Aristoteles":20006123,
    "Asclepius":  20004581, "Atira":      20163693, "Banks":      20013956,
    "Bella":      20000695, "Boda":       20001487, "Bounty":     20003264,
    "Child":      20004580, "Circe":      20000034, "Cerberus":   20001865,
    "Cupido":     20000763, "DancingAngel":20037530,"Daphne":     20000041,
    "Dejanira":   20000157, "Delphine":   20003218, "Destinn":    20006583,
    "Diana":      20000078, "Echo":       20000060, "Eos":        20000221,
    "Enterprise": 20009777, "Euterpe":    20000027, "Fama":       20000408,
    "Felicitas":  20000109, "Feronia":    20000072, "Gabriella":  20000355,
    "Iris":       20000007, "Hecuba":     20000108, "Gold":       20004955,
    "Groom":      20005129, "Vulcano":    20004464, "Icarus":     20001566,
    "Selene":     20000580, "Harmonia":   20000040, "Sophia":     20000251,
    "Hebe":       20000006, "Heracles":   20005143, "Horus":      20001924,
    "Imhotep":    20001813, "Jobse":      20215463, "Karma":      20003811,
    "Kassandra":  20000114, "Kleopatra":  20000216, "Klio":       20000084,
    "Lameia":     20000248, "Lucifer":    20001930, "Lust":       20004386,
    "Midas":      20001981, "Michel":     20001348, "Minerva":    20000093,
    "Mony":       20007782, "Musa":       20000600, "Narcissus":  20037117,
    "Nymphe":     20000875, "Opportunity":20039382, "Osiris":     20001923,
    "Pele":       20002202, "Perdix":     20008758, "Phaedra":    20000174,
    "Phaethon":   20003200, "Polyhymnia": 20000033, "Proserpina": 20000026,
    "Raphaela":   20000708, "Rockefellia":20000904, "Sappho":     20000080,
    "Silver":     20005325, "Sirene":     20001009, "Talent":     20033154,
    "Terpsichore":20000081, "Thalia":     20000023, "Toro":       20001685,
    "Union":      20001585, "Urania":     20000030, "Voskovec-Werich":20002418,
    "Zeus":       20005731,
}

# ---------------------------------------------------------------------------
# Centauroids
# ---------------------------------------------------------------------------

CENTAUR_OIDS: dict[str, int] = {
    "Chiron":          20002060,
    "Asbolus":         20008405,
    "Nessus":          20007066,
    "Chariklo":        20010199,
    "Hylonome":        20010370,
    "Bienor":          20054598,
    "Huya":            20038628,
    "Okyrhoe":         20052872,
    "Elatus":          20031824,
    "Typhon":          20042355,
    "Rhadamanthus":    20038083,
    "Teharonhiawako":  20088611,
    "Borasisi":        20066652,
    "Amycus":          20055576,
    "Echeclus":        20060558,
    "Cyllarus":        20052975,
    "Thereus":         20032532,
    "Orius":           20033083,
    "Pelion":          20049036,
    "Crantor":         20083982,
}

# ---------------------------------------------------------------------------
# Eclipses
# ---------------------------------------------------------------------------

ECLIPSES: dict[str, list[str]] = {
    "prenatal":  ["Prenatal Solar Eclipse",  "Prenatal Lunar Eclipse"],
    "postnatal": ["Postnatal Solar Eclipse", "Postnatal Lunar Eclipse"],
}

# ---------------------------------------------------------------------------
# Shadow moons
# ---------------------------------------------------------------------------

SHADOW_MOONS: dict[str, str] = {
    "Shadow Sun":     "Sun",
    "Shadow Moon":    "Earth",
    "Shadow Mercury": "Mercury",
    "Shadow Venus":   "Venus",
    "Shadow Mars":    "Mars",
    "Shadow Jupiter": "Jupiter",
    "Shadow Saturn":  "Saturn",
    "Shadow Uranus":  "Uranus",
    "Shadow Neptune": "Neptune",
    "Shadow Pluto":   "Pluto",
}

# ---------------------------------------------------------------------------
# Arabic lots
# ---------------------------------------------------------------------------

ARABIC_LOTS: set[str] = {
    "Fortuna", "Spirit", "Eros", "Basis", "Victory", "Nemesis",
    "Marriage", "Death", "Courage", "Children", "Sons", "Mother",
    "Father", "Sudden Fortune", "Injury", "Illness", "Travel",
    "Commerce", "Discord", "Fame", "Triumph",
}

ARABIC_LOT_ABBR: dict[str, str] = {n: n for n in ARABIC_LOTS}

# ---------------------------------------------------------------------------
# Fixed stars
# ---------------------------------------------------------------------------

ROYAL_STARS: set[str] = {"Regulus", "Aldebaran", "Antares", "Fomalhaut"}

FIXED_STARS: dict[str, float] = {
    "Aldebaran": 69.93,  "Regulus": 149.83,  "Antares": 249.83,
    "Fomalhaut": 333.83, "Alnitak": 84.2,    "Alnilam": 85.2,
    "Mintaka":   83.9,   "Bellatrix": 88.8,  "Betelgeuse": 88.9,
    "Rigel":     78.7,   "Alcyone":  60.2,   "Maia":    59.1,
    "Merope":    58.7,   "Electra":  59.6,   "Taygeta": 61.1,
    "Sirius":   104.0,   "Procyon": 114.1,   "Pollux":  113.5,
    "Castor":   110.3,   "Capella":  79.7,   "Arcturus":204.0,
    "Spica":    203.8,   "Vega":    285.0,   "Altair":  302.1,
    "Deneb":    310.0,   "Canopus": 263.0,   "Achernar":336.1,
    "Scheat":   359.0,   "Markab":  353.0,   "Alpheratz":357.0,
    "Mirach":    14.5,   "Hamal":    23.5,   "Zosma":   150.7,
    "Denebola": 170.2,   "Vindemiatrix":197.6,"Algorab": 187.3,
    "Algol":     26.4,   "Facies":    9.1,   "Rasalhague":263.6,
    "Sabik":    257.4,   "Shaula":  255.3,   "Nunki":   272.1,
    "Spiculum": 266.2,   "Dubhe":   135.0,   "Merak":   136.0,
    "Mizar":    165.7,   "Alcor":   165.87,  "Etamin":  301.0,
    "Eltanin":  301.0,   "Zubenelgenubi":197.4,"Zubeneschamali":203.2,
    "Deneb Algedi":290.0,"Sadalmelik":320.6, "Sadalsuud":303.4,
    "Skat":     318.3,   "Sualocin":314.0,   "Rotanev": 314.7,
    "Kaus Australis":256.3,"Kaus Media":267.0,"Kaus Borealis":271.0,
    "Algenib":  347.3,   "Ankaa":   343.6,   "Menkar":   34.0,
    "Diphda":    28.0,   "Phact":   337.2,   "Gienah":  191.9,
    "Rukbat":   277.0,   "Albireo": 303.7,
}

# ---------------------------------------------------------------------------
# Exoplanets & interstellar
# ---------------------------------------------------------------------------

EXOPLANETS: dict[str, dict[str, float]] = {
    "Kepler-22b":         {"ra_deg": 285.679, "dec_deg":  47.898},
    "Kepler-452b":        {"ra_deg": 283.410, "dec_deg":  44.276},
    "Proxima Centauri b": {"ra_deg": 217.429, "dec_deg": -62.679},
    "Proxima Centauri d": {"ra_deg": 217.429, "dec_deg": -62.679},
    "TRAPPIST-1 e":       {"ra_deg": 346.622, "dec_deg":  -5.041},
    "TRAPPIST-1 Core":    {"ra_deg": 346.622, "dec_deg":  -5.041},
    "K2-18 b":            {"ra_deg": 172.644, "dec_deg":   7.588},
    "LHS 1140 b":         {"ra_deg":  23.997, "dec_deg": -15.271},
    "Kepler-186f":        {"ra_deg": 297.991, "dec_deg":  43.959},
    "Kepler-1649c":       {"ra_deg": 297.714, "dec_deg":  41.912},
    "Ross 128 b":         {"ra_deg": 176.937, "dec_deg":   0.804},
    "Barnard's Star b":   {"ra_deg": 269.452, "dec_deg":   4.693},
    "Wolf 1061 c":        {"ra_deg": 247.045, "dec_deg": -12.664},
    "WASP-12b":           {"ra_deg":  97.636, "dec_deg":  29.672},
    "55 Cancri e":        {"ra_deg": 133.149, "dec_deg":  28.330},
    "HD 209458 b":        {"ra_deg": 330.794, "dec_deg":  18.884},
    "TOI-700 d":          {"ra_deg":  82.722, "dec_deg": -68.207},
    "Gliese 581g":        {"ra_deg": 229.417, "dec_deg":  -7.722},
    "Tau Ceti e":         {"ra_deg":  26.017, "dec_deg": -15.937},
    "Tau Ceti f":         {"ra_deg":  26.017, "dec_deg": -15.937},
    "Kepler-62f":         {"ra_deg": 288.769, "dec_deg":  45.331},
    "Kepler-62e":         {"ra_deg": 288.769, "dec_deg":  45.331},
    "Kepler-442b":        {"ra_deg": 287.611, "dec_deg":  41.338},
    "Kepler-1229b":       {"ra_deg": 289.584, "dec_deg":  47.056},
    "Kepler-438b":        {"ra_deg": 285.069, "dec_deg":  41.677},
    "GJ 667 Cc":          {"ra_deg": 251.468, "dec_deg": -34.964},
    "CoRoT-7b":           {"ra_deg": 101.283, "dec_deg":  -1.393},
    "NGTS-1b":            {"ra_deg":  25.033, "dec_deg": -38.708},
    "HAT-P-7b":           {"ra_deg": 291.410, "dec_deg":  47.970},
    "HD 40307 g":         {"ra_deg":  92.325, "dec_deg": -60.001},
    "GJ 163c":            {"ra_deg":  70.986, "dec_deg": -53.390},
    "Kepler-69c":         {"ra_deg": 289.624, "dec_deg":  41.949},
    "Kepler-70b":         {"ra_deg": 291.060, "dec_deg":  48.643},
    "Kepler-70c":         {"ra_deg": 291.060, "dec_deg":  48.643},
    "OGLE-2005-BLG-390Lb":{"ra_deg": 269.258, "dec_deg": -30.175},
    "GJ 1214 b":          {"ra_deg": 258.839, "dec_deg":   4.979},
    "Alpha Centauri AB":  {"ra_deg": 219.900, "dec_deg": -60.833},
    "Sirius System":      {"ra_deg": 101.287, "dec_deg": -16.716},
    "Epsilon Eridani":    {"ra_deg":  53.232, "dec_deg":  -9.458},
    "Altair System":      {"ra_deg": 297.696, "dec_deg":   8.868},
}

INTERSTELLAR_OBJECTS: dict[str, dict] = {
    "Oumuamua": {
        "ra_deg": 279.804, "dec_deg": 34.014,
        "label": "First Interstellar Visitor", "designation": "1I/2017 U1",
    },
    "2I/Borisov": {
        "ra_deg": 82.187, "dec_deg": 59.440,
        "label": "Interstellar Comet", "designation": "2I/2019 Q4",
    },
}

# ---------------------------------------------------------------------------
# Aspects
# ---------------------------------------------------------------------------

ASPECTS: dict[str, int] = {
    "Conjunction":    0,
    "Opposition":   180,
    "Trine":        120,
    "Square":        90,
    "Sextile":       60,
    "Quincunx":     150,
    "Semi-Sextile":  30,
    "Semi-Square":   45,
    "Sesquiquadrate":135,
}

ASPECT_GLYPH: dict[str, str] = {
    "Conjunction": "☌",
    "Opposition":  "☍",
    "Trine":       "△",
    "Square":      "□",
    "Sextile":     "⚹",
    "Quincunx":    "⚻",
    "Semi-Sextile":"⚺",
    "Semi-Square": "∠",
    "Sesquiquadrate":"⚼",
}

# ---------------------------------------------------------------------------
# Glyphs & colours
# ---------------------------------------------------------------------------

PLANET_GLYPH: dict[str, str] = {
    # Classic planets
    "Sun": "☉", "Moon": "☽", "Mercury": "☿", "Venus": "♀", "Mars": "♂",
    "Jupiter": "♃", "Saturn": "♄", "Uranus": "♅", "Neptune": "♆", "Pluto": "♇",
    # Nodes / Lilith
    "Chiron": "⚷", "Mean Lilith": "⚸", "True Lilith": "⚸",
    "North Node": "☊", "South Node": "☋", "True Node": "☊", "Mean Node": "☊",
    # Big 4 asteroids + notable dwarfs
    "Pallas": "⚴", "Juno": "⚵", "Vesta": "⚶", "Ceres": "⚳",
    "Eris": "⯰", "Sedna": "⯲", "Haumea": "🜩", "Makemake": "🜪",
    # TNO / dwarfs
    "Leleākūhonua": "⯳", "Quaoar": "⯴", "Orcus": "⯵", "Arrokoth": "⯶",
    "Varuna": "⯱", "Ixion": "⯷", "Chaos": "⯸", "Logos": "⯹",
    "Gonggong": "⯺", "Salacia": "⯻", "2002 TC302": "⯼", "2004 GV9": "⯽",
    "Altjira": "⯾", "Varda": "⯿",
    "Chiminigagua": "✶", "Albion": "⚪", "Arawn": "⚫", "Xewioso": "✷",
    "Mors-Somnus": "☠", "Bida": "✹", "Praamzius": "✦", "Manwë": "✧",
    "Dziewanna": "❄", "Achlys": "☾",
    # Centaurs
    "Asbolus": "✦", "Nessus": "✦", "Chariklo": "✦", "Hylonome": "✦",
    "Bienor": "✦", "Huya": "✦", "Okyrhoe": "✦", "Elatus": "✦",
    "Typhon": "✦", "Rhadamanthus": "✦", "Teharonhiawako": "✦",
    "Borasisi": "✦", "Amycus": "✦", "Echeclus": "✦", "Cyllarus": "✦",
    "Thereus": "✦", "Pelion": "✦", "Crantor": "✦",
    # Asteroids
    "Moira": "⚶", "Atropos": "⚶", "Lachesis": "⚶", "Klotho": "⚶",
    "Hybris": "☠", "Nemesis": "⚸", "Psyche": "♡", "Hekate": "☾",
    "Tyche": "✶", "Fortuna": "⚶", "Victoria": "✶", "Nike": "✶",
    "Adonis": "♡", "Hidalgo": "✦", "Apollo": "☉",
    "Panacea": "⚕", "Atlantis": "✦", "Deucalion": "✦",
    "Ritona": "✦", "Admetos": "✦", "Poseidon": "♆",
    "Hygiea": "⚕", "Artemis": "☾", "Medusa": "☿", "Koronis": "⚶",
    "Pandora": "✶", "Demeter": "⚳", "Elektra": "⚡", "Hera": "⚭",
    "Hestia": "⚶", "Kallisto": "☽", "Persephone": "☾",
    "Orpheus": "♪", "Astraea": "✶", "Achilles": "⚔",
    "Prometheus": "✦", "Abundantia": "✚", "Academia": "✎",
    "Aegle": "✶", "Alkeste": "✴", "Angel": "✶", "Aristoteles": "✦",
    "Asclepius": "⚕", "Atira": "⬘", "Banks": "⬓", "Bella": "✿",
    "Boda": "✢", "Bounty": "✚", "Child": "✦", "Circe": "✦",
    "Cerberus": "☋", "Cupido": "♡",
    "DancingAngel": "✶", "Daphne": "✿", "Dejanira": "✖", "Delphine": "✺",
    "Destinn": "✦", "Diana": "☾", "Echo": "〰",
    "Eos": "✶", "Enterprise": "✦", "Euterpe": "♪",
    "Fama": "✪", "Felicitas": "✿", "Feronia": "✴", "Gabriella": "✶",
    "Iris": "✺", "Hecuba": "✖", "Gold": "✶", "Groom": "⚭",
    "Vulcano": "✴", "Icarus": "✦", "Selene": "☽",
    "Harmonia": "✶", "Sophia": "✦", "Hebe": "⚵", "Heracles": "✶",
    "Horus": "☉", "Imhotep": "✦",
    "Jobse": "✢", "Karma": "☋", "Kassandra": "✖", "Kleopatra": "⚭",
    "Klio": "✦", "Lameia": "⚸", "Lucifer": "✴", "Lust": "♡",
    "Midas": "✶", "Michel": "✦", "Minerva": "⚴", "Mony": "✶",
    "Musa": "♪", "Narcissus": "✿", "Nymphe": "✶",
    "Opportunity": "✦", "Osiris": "☥",
    "Pele": "✴", "Perdix": "✦", "Phaedra": "✿", "Phaethon": "☄",
    "Polyhymnia": "♪", "Proserpina": "☾", "Raphaela": "✶",
    "Rockefellia": "✶", "Sappho": "✎", "Silver": "⚪", "Sirene": "♪",
    "Talent": "✦", "Terpsichore": "♪", "Thalia": "✿",
    "Toro": "♉", "Union": "⚭", "Urania": "✶",
    "Voskovec-Werich": "✦", "Zeus": "⚡",
    "Arachne": "✦", "Myrrha": "✦", "Celuta": "✦", "Industria": "✦",
    "Ryugu": "⬢", "Itokawa": "⬡", "Apophis": "☄", "Gaspra": "●", "Ida": "◉",
    "2015 TG38": "◌", "Hypnos": "☽", "Pholus": "⚶",
    "Moira": "⚶", "Klotho": "⚶",
    # Exoplanets / interstellar
    "Alpha Centauri AB": "✶", "Sirius System": "✶",
    "Epsilon Eridani": "✶", "Altair System": "✶",
    "Oumuamua": "✦", "2I/Borisov": "✦",
    # Points
    "Ascendant": "Asc", "Midheaven": "MC", "Descendant": "Dsc", "IC": "IC",
    "Vertex": "Vtx", "East Point": "EP",
    # Fallback
    "Unknown": "❓",
}

BODY_COLORS: dict[str, str] = {
    # Planets
    "Sun": "#FFD700", "Moon": "#C0C0C0", "Mercury": "#DEB887",
    "Venus": "#FF69B4", "Mars": "#FF0000", "Jupiter": "#FF4500",
    "Saturn": "#DAA520", "Uranus": "#00CED1", "Neptune": "#4169E1",
    "Pluto": "#8B0000",
    # Nodes / Lilith
    "Chiron": "#2E8B57", "Mean Lilith": "#EE2EFF", "True Lilith": "#9F1313",
    "North Node": "#4B0082", "South Node": "#4B0082",
    "True Node": "#AAAAAA", "Mean Node": "#AAAAAA",
    # Dwarfs
    "Eris": "#8B0000", "Haumea": "#FF69B4", "Makemake": "#DAA520",
    "Ceres": "#C0C0C0", "Sedna": "#FF4500", "Varuna": "#00CED1",
    "Leleākūhonua": "#E1FF3A", "Quaoar": "#8B0000", "Orcus": "#2F4F4F",
    "Arrokoth": "#A0522D", "Ixion": "#B8860B", "Chaos": "#4B0082",
    "Logos": "#FFD700", "Gonggong": "#8B0000", "Salacia": "#4682B4",
    "2002 TC302": "#708090", "2004 GV9": "#556B2F", "Altjira": "#9932CC",
    "Varda": "#F5F5F5", "Chiminigagua": "#FFD700", "Albion": "#E6E6FA",
    "Arawn": "#1C1C1C", "Xewioso": "#FF1493", "Mors-Somnus": "#2B2B2B",
    "Bida": "#32CD32", "Praamzius": "#FF8C00", "Manwë": "#87CEEB",
    "Dziewanna": "#ADD8E6", "Achlys": "#2E2E2E",
    # Centaurs
    "Asbolus": "#556B2F", "Nessus": "#8B0000", "Chariklo": "#87CEEB",
    "Hylonome": "#4B0000", "Bienor": "#708090", "Huya": "#4682B4",
    "Okyrhoe": "#6A5ACD", "Elatus": "#8B4513", "Typhon": "#2F4F4F",
    "Rhadamanthus": "#800000", "Teharonhiawako": "#87CEFA",
    "Borasisi": "#5F9EA0", "Amycus": "#8B0000", "Echeclus": "#2E2E2E",
    "Cyllarus": "#A0522D", "Thereus": "#708090", "Pelion": "#6B8E23",
    "Crantor": "#483D8B",
    # Asteroids
    "Moira": "#6A5ACD", "Atropos": "#2F4F4F", "Lachesis": "#4682B4",
    "Hybris": "#8B0000", "Nemesis": "#B22222", "Psyche": "#FF69B4",
    "Hekate": "#483D8B", "Klotho": "#5F9EA0", "Tyche": "#FFD700",
    "Fortuna": "#8B008B", "Victoria": "#32CD32", "Nike": "#32CD32",
    "Adonis": "#FF7F50", "Hidalgo": "#8B4513", "Apollo": "#FF8C00",
    "Panacea": "#2E8B57", "Atlantis": "#1E90FF", "Deucalion": "#FF8C00",
    "Ritona": "#6B8E23", "Admetos": "#2B2B2B", "Poseidon": "#4169E1",
    "Hygiea": "#20B2AA", "Artemis": "#C0C0C0", "Medusa": "#708090",
    "Koronis": "#6B8E23", "Pandora": "#FF8C00", "Demeter": "#228B22",
    "Elektra": "#00CED1", "Hera": "#DAA520", "Hestia": "#FF6347",
    "Kallisto": "#C0C0C0", "Persephone": "#2F4F4F", "Orpheus": "#9370DB",
    "Astraea": "#F5DEB3", "Achilles": "#8B4513",
    "Prometheus": "#FF6347", "Abundantia": "#FFD700", "Academia": "#4682B4",
    "Aegle": "#F5DEB3", "Alkeste": "#A0522D", "Angel": "#E6E6FA",
    "Aristoteles": "#2F4F4F", "Asclepius": "#2E8B57", "Atira": "#B8860B",
    "Banks": "#4B5320", "Bella": "#FFB6C1", "Boda": "#8B4513",
    "Bounty": "#DAA520", "Child": "#87CEFA", "Circe": "#6A0DAD",
    "Cerberus": "#2B2B2B", "Cupido": "#FF69B4",
    "DancingAngel": "#E6E6FA", "Daphne": "#228B22", "Dejanira": "#8B0000",
    "Delphine": "#20B2AA", "Destinn": "#708090", "Diana": "#C0C0C0",
    "Echo": "#A9A9A9", "Eos": "#FFA500", "Enterprise": "#4682B4",
    "Euterpe": "#9370DB", "Fama": "#FFD700", "Felicitas": "#98FB98",
    "Feronia": "#B22222", "Gabriella": "#FFB6C1", "Iris": "#40E0D0",
    "Hecuba": "#4B0000", "Gold": "#FFD700", "Groom": "#2F4F4F",
    "Vulcano": "#FF4500", "Icarus": "#CD5C5C", "Selene": "#C0C0C0",
    "Harmonia": "#66CDAA", "Sophia": "#B0C4DE", "Hebe": "#D8BFD8",
    "Heracles": "#8B4513", "Horus": "#DAA520", "Imhotep": "#708090",
    "Jobse": "#556B2F", "Karma": "#4B0082", "Kassandra": "#800000",
    "Kleopatra": "#FFD700", "Klio": "#87CEEB", "Lameia": "#483D8B",
    "Lucifer": "#FF6347", "Lust": "#C71585", "Midas": "#FFD700",
    "Michel": "#A0522D", "Minerva": "#708090", "Mony": "#2E8B57",
    "Musa": "#9370DB", "Narcissus": "#FF69B4", "Nymphe": "#7FFFD4",
    "Opportunity": "#32CD32", "Osiris": "#2F4F4F",
    "Pele": "#FF4500", "Perdix": "#A9A9A9", "Phaedra": "#DB7093",
    "Phaethon": "#FF8C00", "Polyhymnia": "#9370DB", "Proserpina": "#2F4F4F",
    "Raphaela": "#E6E6FA", "Rockefellia": "#556B2F", "Sappho": "#C71585",
    "Silver": "#C0C0C0", "Sirene": "#20B2AA", "Talent": "#32CD32",
    "Terpsichore": "#BA55D3", "Thalia": "#FFB6C1",
    "Toro": "#8B4513", "Union": "#DAA520", "Urania": "#4682B4",
    "Voskovec-Werich": "#708090", "Zeus": "#FFD700",
    "Arachne": "#483D8B", "Myrrha": "#C71585", "Celuta": "#708090",
    "Industria": "#B8860B", "Ryugu": "#6B8E23", "Itokawa": "#708090",
    "Apophis": "#8B0000", "Gaspra": "#7B6F5E", "Ida": "#9E9E9E",
    "2015 TG38": "#556B2F", "Hypnos": "#5A5A7A", "Pholus": "#8B6F47",
    # Arabic lots
    "Spirit": "#00E5FF", "Eros": "#FF2F6F", "Basis": "#FFA500",
    "Victory": "#32CD32", "Marriage": "#FFB6C1", "Death": "#4B4B4B",
    "Courage": "#FF6347", "Children": "#87CEFA", "Sons": "#1E90FF",
    "Mother": "#FF69B4", "Father": "#1E90FF", "Sudden Fortune": "#FFFF00",
    "Injury": "#8B0000", "Illness": "#8F5959", "Travel": "#00CED1",
    "Commerce": "#FFD700", "Discord": "#FF4500", "Fame": "#FFFF00",
    "Triumph": "#32CD32",
    # Fixed stars
    "Aldebaran": "#FF4500", "Regulus": "#FFD700", "Antares": "#B22222",
    "Fomalhaut": "#1E90FF", "Alnitak": "#87CEEB", "Alnilam": "#87CEEB",
    "Mintaka": "#87CEEB", "Bellatrix": "#6495ED", "Betelgeuse": "#FF6347",
    "Rigel": "#1E90FF", "Alcyone": "#ADD8E6", "Maia": "#ADD8E6",
    "Merope": "#ADD8E6", "Electra": "#AFEEEE", "Taygeta": "#B0E0E6",
    "Sirius": "#E6E6FA", "Procyon": "#F5F5DC", "Pollux": "#DAA520",
    "Castor": "#87CEFA", "Capella": "#FAFAD2", "Arcturus": "#FF8C00",
    "Spica": "#40E0D0", "Vega": "#00BFFF", "Altair": "#00CED1",
    "Deneb": "#AFEEEE", "Canopus": "#FFFACD", "Achernar": "#87CEEB",
    "Scheat": "#B0C4DE", "Markab": "#B0C4DE", "Alpheratz": "#ADD8E6",
    "Mirach": "#FA8072", "Hamal": "#DAA520", "Zosma": "#FFD700",
    "Denebola": "#F0E68C", "Vindemiatrix": "#EEE8AA", "Algorab": "#708090",
    "Algol": "#8B0000", "Facies": "#CD853F", "Rasalhague": "#20B2AA",
    "Sabik": "#228B22", "Shaula": "#2E8B57", "Nunki": "#4682B4",
    "Spiculum": "#2F4F4F", "Dubhe": "#708090", "Merak": "#708090",
    "Mizar": "#778899", "Alcor": "#778899", "Etamin": "#B0C4DE",
    "Eltanin": "#B0C4DE", "Zubenelgenubi": "#EEE8AA",
    "Zubeneschamali": "#ADFF2F", "Deneb Algedi": "#87CEEB",
    "Sadalmelik": "#B0E0E6", "Sadalsuud": "#AFEEEE", "Skat": "#ADD8E6",
    "Sualocin": "#87CEEB", "Rotanev": "#87CEEB",
    "Kaus Australis": "#2E8B57", "Kaus Media": "#3CB371",
    "Kaus Borealis": "#20B2AA", "Algenib": "#4682B4", "Ankaa": "#FF7F50",
    "Menkar": "#DAA520", "Diphda": "#F4A460", "Phact": "#87CEFA",
    "Gienah": "#1E90FF", "Rukbat": "#B0C4DE", "Albireo": "#FFD700",
    # Exoplanets
    "Kepler-22b": "#29FF89", "Kepler-452b": "#3DFF9E",
    "Proxima Centauri b": "#00FFB2", "Proxima Centauri d": "#00CC8F",
    "TRAPPIST-1 e": "#29FF89", "TRAPPIST-1 Core": "#1EDC7B",
    "K2-18 b": "#00E5FF", "LHS 1140 b": "#00C853",
    "Kepler-186f": "#66FF99", "Kepler-1649c": "#33FF77",
    "Ross 128 b": "#00FA9A", "Barnard's Star b": "#20E3B2",
    "Wolf 1061 c": "#2EE59D", "WASP-12b": "#FF8C00",
    "55 Cancri e": "#FF6A00", "HD 209458 b": "#FF4500",
    "TOI-700 d": "#00FFD5", "Gliese 581g": "#3CB371",
    "Tau Ceti e": "#2EFFA4", "Tau Ceti f": "#1FBF8F",
    "Kepler-62f": "#7CFFB2", "Kepler-62e": "#4DFF99",
    "Kepler-442b": "#6BFF9C", "Kepler-1229b": "#5AFFA3",
    "Kepler-438b": "#4CFF8A", "GJ 667 Cc": "#00E676",
    "CoRoT-7b": "#FF7043", "NGTS-1b": "#FF9800",
    "HAT-P-7b": "#FF5722", "HD 40307 g": "#26C6DA",
    "GJ 163c": "#00ACC1", "Kepler-69c": "#40E0D0",
    "Kepler-70b": "#7FFFD4", "Kepler-70c": "#66CDAA",
    "OGLE-2005-BLG-390Lb": "#9CCC65", "GJ 1214 b": "#00BFA5",
    "Alpha Centauri AB": "#FFD700", "Sirius System": "#E6E6FA",
    "Epsilon Eridani": "#ADFF2F", "Altair System": "#87CEEB",
    # Interstellar
    "Oumuamua": "#FFFFFF", "2I/Borisov": "#87CEEB",
    # Fallback
    "Unknown": "#FFFFFF",
}

# Fallback colours by category (used when a body has no entry in BODY_COLORS)
CATEGORY_COLORS: dict[str, str] = {
    "planets":         "#FFD700",
    "moons":           "#C0C0C0",
    "dwarfs":          "#7B68EE",
    "asteroids":       "#CD853F",
    "centaurs":        "#2E8B57",
    "points":          "#AAAAAA",
    "advanced_points": "#888888",
    "lilith":          "#EE2EFF",
    "planetary_nodes": "#4B0082",
    "exoplanets":      "#00BFFF",
    "interstellar":    "#FF4500",
    "fixed_stars":     "#FFF8DC",
    "arabic_lots":     "#8B008B",
    "eclipses":        "#FF6347",
}

# ---------------------------------------------------------------------------
# Category metadata
# ---------------------------------------------------------------------------

CATEGORY_TITLES_BASE: dict[str, str] = {
    "planets":         "PLANETS",
    "dwarfs":          "DWARFS / TNO",
    "asteroids":       "ASTEROIDS",
    "centaurs":        "CENTAURS",
    "points":          "POINTS",
    "advanced_points": "ADVANCED POINTS",
    "lilith":          "LILITH",
    "planetary_nodes": "PLANETARY NODES",
    "exoplanets":      "EXOPLANETS",
    "interstellar":    "INTERSTELLAR",
    "moons":           "MOONS",
    "fixed_stars":     "FIXED STARS",
    "arabic_lots":     "ARABIC LOTS",
    "eclipses":        "ECLIPSES",
}

CATEGORY_RING: dict[str, dict[str, int]] = {
    "luminaries":      {"r": -30,  "sep": 35},
    "planets":         {"r": -30,  "sep": 30},
    "moons":           {"r": -60,  "sep": 20},
    "asteroids":       {"r": -90,  "sep": 15},
    "points":          {"r": -30,  "sep": 25},
    "planetary_nodes": {"r": -120, "sep": 15},
    "fixed_stars":     {"r":  40,  "sep": 12},
    "exoplanets":      {"r":  60,  "sep": 10},
    "dwarfs":          {"r": -90,  "sep": 15},
    "arabic_lots":     {"r": -100, "sep": 15},
    "lilith":          {"r": -30,  "sep": 25},
    "interstellar":    {"r":  80,  "sep": 10},
    "eclipses":        {"r": -110, "sep": 20},
    "advanced_points": {"r": -30,  "sep": 25},
}

ALLOWED_FOR_ACTIVE: list[str] = [
    "Sun", "Moon", "Mercury", "Venus", "Mars",
    "Jupiter", "Saturn", "Ascendant", "Midheaven",
]

SPICE_PARENT_MAP: dict[int, str] = {
    399: "Earth",   499: "Mars",
    599: "Jupiter", 699: "Saturn",
    799: "Uranus",  899: "Neptune",
    999: "Pluto",
}

NEAR_MARK: str        = "★"
NEAR_STAR_ORB_DEG: float = 1.2
FIXED_STAR_GLYPH: str = "✶"

J2000: float  = 2451545.0
TWOPI: float  = 2 * math.pi

_ALIASES: dict[str, str] = {
    "kronos":    "Saturn",
    "chronos":   "Saturn",
    "zeus":      "Zeus",
    "asc":       "Ascendant",
    "mc":        "Midheaven",
    "northnode": "True Node",
    "truenode":  "True Node",
    "meannode":  "Mean Node",
}

# Engine version metadata
AFTERLIFE_EPHEMERIS_VERSION: str = "1.0.0"
AFTERLIFE_EPHEMERIS_DATE: str    = "2026"
AFTERLIFE_EPHEMERIS_SOURCE: str  = "Swiss Ephemeris + NASA SPICE"
AFTERLIFE_EPHEMERIS_NOTE: str    = "Afterlife - The Astrological Calculation Engine"
