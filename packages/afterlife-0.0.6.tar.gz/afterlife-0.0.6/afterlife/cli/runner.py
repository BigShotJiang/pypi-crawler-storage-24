from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

import swisseph as swe

from afterlife.constants import PLANETS
from afterlife.engine import Afterlife
from afterlife.utils.helpers import is_true, split_house_list


def _engine(ephe_dir: Optional[str] = None, spice_dir: Optional[str] = None) -> Afterlife:
    return Afterlife(ephe_dir=ephe_dir, spice_dir=spice_dir)


# ---------------------------------------------------------------------------
# Chart
# ---------------------------------------------------------------------------

def run_chart(params: Dict[str, Any]) -> Dict[str, Any]:
    eng = _engine(params.get("ephe_dir"), params.get("spice_dir"))
    eng._show_flags = {k: v for k, v in params.items() if k.startswith("show_")}

    date = params.get("date")
    time = params.get("time")
    lat  = params.get("lat")
    lon  = params.get("lon")

    if not (date and time and lat is not None and lon is not None):
        return {"error": "chart requires --date DD-MM-YYYY --time HH:MM --lat <float> --lon <float>"}

    chart = json.loads(eng.compute_astro_chart(
        date_str       = str(date),
        time_str       = str(time),
        lat            = float(lat),
        lon            = float(lon),
        house_system   = params.get("house_system", "placidus"),
        tz_offset      = float(params.get("tz", 3.0)),
        fixed_star_orb = float(params.get("fixed_star_orb", 2.5)),
        exclude        = params.get("exclude", ""),
        include        = params.get("include", ""),
        sort_by        = params.get("sort_by", ""),

        limit                  = int(params.get("limit", 0)),
        planets_limit          = int(params.get("planets_limit", 0)),
        moons_limit            = int(params.get("moons_limit", 0)),
        dwarfs_limit           = int(params.get("dwarfs_limit", 0)),
        asteroids_limit        = int(params.get("asteroids_limit", 0)),
        centaurs_limit         = int(params.get("centaurs_limit", 0)),
        points_limit           = int(params.get("points_limit", 0)),
        advanced_points_limit  = int(params.get("advanced_points_limit", 0)),
        lilith_limit           = int(params.get("lilith_limit", 0)),
        planetary_nodes_limit  = int(params.get("planetary_nodes_limit", 0)),
        exoplanets_limit       = int(params.get("exoplanets_limit", 0)),
        interstellar_limit     = int(params.get("interstellar_limit", 0)),
        fixed_stars_limit      = int(params.get("fixed_stars_limit", 0)),
        arabic_lots_limit      = int(params.get("arabic_lots_limit", 0)),
    ))

    if is_true(params.get("show_aspects", True)):
        aspect_items: Dict[str, float] = {}
        for cat in ("planets", "points", "planetary_nodes", "lilith"):
            objs = chart.get("bodies", {}).get(cat, {})
            if isinstance(objs, dict):
                for name, obj in objs.items():
                    if isinstance(obj, dict) and "lon" in obj:
                        aspect_items[name] = obj["lon"]

        if len(aspect_items) >= 2:
            chart["aspects"] = eng.compute_aspects(aspect_items)
    else:
        chart.pop("aspects", None)

    sign       = params.get("sign")
    house_list = split_house_list(params.get("house"))
    parent     = params.get("parent")

    if sign or house_list or parent:
        chart = eng.apply_filters(chart, sign=sign, house=house_list or None, parent=parent)

    chart["totals"] = {
        "overall": sum(
            len(v) for v in chart.get("bodies", {}).values()
            if isinstance(v, dict)
        )
    }

    return {"mode": "chart", "chart": chart}


# ---------------------------------------------------------------------------
# Transit snapshot
# ---------------------------------------------------------------------------

def run_transit(params: Dict[str, Any]) -> Dict[str, Any]:
    eng = _engine(params.get("ephe_dir"), params.get("spice_dir"))

    if not params.get("date_from") or not params.get("date_to"):
        return {"error": "transit requires --date-from YYYY-MM-DD --date-to YYYY-MM-DD"}

    date = params.get("date")
    time = params.get("time")
    lat  = params.get("lat")
    lon  = params.get("lon")

    if not (date and time and lat is not None and lon is not None):
        return {"error": "transit requires --date --time --lat --lon"}

    natal = json.loads(eng.compute_astro_chart(
        date_str     = str(date),
        time_str     = str(time),
        lat          = float(lat),
        lon          = float(lon),
        house_system = params.get("house_system", "placidus"),
        tz_offset    = float(params.get("tz", 3.0)),
        exclude      = params.get("exclude", ""),
        sort_by      = params.get("sort_by", ""),

        limit                  = int(params.get("limit", 0)),
        planets_limit          = int(params.get("planets_limit", 0)),
        moons_limit            = int(params.get("moons_limit", 0)),
        dwarfs_limit           = int(params.get("dwarfs_limit", 0)),
        asteroids_limit        = int(params.get("asteroids_limit", 0)),
        centaurs_limit         = int(params.get("centaurs_limit", 0)),
        points_limit           = int(params.get("points_limit", 0)),
        advanced_points_limit  = int(params.get("advanced_points_limit", 0)),
        lilith_limit           = int(params.get("lilith_limit", 0)),
        planetary_nodes_limit  = int(params.get("planetary_nodes_limit", 0)),
        exoplanets_limit       = int(params.get("exoplanets_limit", 0)),
        interstellar_limit     = int(params.get("interstellar_limit", 0)),
        fixed_stars_limit      = int(params.get("fixed_stars_limit", 0)),
        arabic_lots_limit      = int(params.get("arabic_lots_limit", 0)),
    ))

    if not natal.get("houses", {}).get("cusps"):
        natal["houses"] = eng.compute_houses(
            jd=natal["jd"], lat=float(lat), lon=float(lon),
            system=params.get("house_system", "placidus"),
        )

    snap = eng.transit_snapshot(
        natal_chart = natal,
        body        = params["transit"],
        date_from   = params["date_from"],
        date_to     = params["date_to"],
        step_days   = int(params.get("step", 1)),
    )

    return {"mode": "transit_snapshot", "transit": snap}


# ---------------------------------------------------------------------------
# Yearly transits
# ---------------------------------------------------------------------------

def run_transits(params: Dict[str, Any]) -> Dict[str, Any]:
    eng  = _engine(params.get("ephe_dir"), params.get("spice_dir"))
    year = params.get("year")

    if not year:
        return {"error": "transits requires --year"}

    date = params.get("date")
    time = params.get("time")
    lat  = params.get("lat")
    lon  = params.get("lon")

    if not (date and time and lat is not None and lon is not None):
        return {"error": "transits requires --date --time --lat --lon"}

    natal = json.loads(eng.compute_astro_chart(
        date_str     = str(date),
        time_str     = str(time),
        lat          = float(lat),
        lon          = float(lon),
        house_system = params.get("house_system", "placidus"),
        tz_offset    = float(params.get("tz", 3.0)),
        exclude      = params.get("exclude", ""),
        sort_by      = params.get("sort_by", ""),

        limit                  = int(params.get("limit", 0)),
        planets_limit          = int(params.get("planets_limit", 0)),
        moons_limit            = int(params.get("moons_limit", 0)),
        dwarfs_limit           = int(params.get("dwarfs_limit", 0)),
        asteroids_limit        = int(params.get("asteroids_limit", 0)),
        centaurs_limit         = int(params.get("centaurs_limit", 0)),
        points_limit           = int(params.get("points_limit", 0)),
        advanced_points_limit  = int(params.get("advanced_points_limit", 0)),
        lilith_limit           = int(params.get("lilith_limit", 0)),
        planetary_nodes_limit  = int(params.get("planetary_nodes_limit", 0)),
        exoplanets_limit       = int(params.get("exoplanets_limit", 0)),
        interstellar_limit     = int(params.get("interstellar_limit", 0)),
        fixed_stars_limit      = int(params.get("fixed_stars_limit", 0)),
        arabic_lots_limit      = int(params.get("arabic_lots_limit", 0)),
    ))

    exclude_list = [x.strip() for x in params.get("exclude", "").split(",") if x.strip()]

    out: Dict[str, Any] = {}

    for body in PLANETS:
        if body in exclude_list:
            continue

        snap = eng.transit_snapshot(
            natal_chart = natal,
            body        = body,
            date_from   = f"{int(year)}-01-01",
            date_to     = f"{int(year)}-12-31",
            step_days   = int(params.get("step", 1)),
        )

        if snap.get("events"):
            out[body] = snap["events"]

    return {
        "mode":     "yearly_transits",
        "year":     int(year),
        "natal": {
            "date": str(date),
            "time": str(time),
            "lat": float(lat),
            "lon": float(lon)
        },
        "transits": out,
    }


# ---------------------------------------------------------------------------
# Moon cycle
# ---------------------------------------------------------------------------

def run_moon(params: Dict[str, Any]) -> Dict[str, Any]:
    eng  = _engine(params.get("ephe_dir"), params.get("spice_dir"))
    moon = str(params.get("moon", ""))
    try:
        y_str, m_str = moon.split("-", 1)
        y, m = int(y_str), int(m_str)
    except (ValueError, AttributeError):
        return {"error": "moon requires format YYYY-M (e.g. 2026-3)"}
    return eng.moon_cycle(y, m, tz_offset=float(params.get("tz", 3.0)))


# ---------------------------------------------------------------------------
# Quick transits
# ---------------------------------------------------------------------------

def run_quick(params: Dict[str, Any]) -> Dict[str, Any]:
    eng  = _engine(params.get("ephe_dir"), params.get("spice_dir"))
    lat  = params.get("lat")
    lon  = params.get("lon")
    if lat is None or lon is None:
        return {"error": "quick requires --lat and --lon"}

    mode  = str(params["quick"])
    now   = datetime.now()
    tz    = float(params.get("tz", 3.0))

    if mode == "today":
        start, end, step_hours = now, now + timedelta(days=1), 3
    elif mode == "thisweek":
        start, end, step_hours = now, now + timedelta(days=7), 6
    elif mode == "thismonth":
        start      = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end        = (start.replace(day=28) + timedelta(days=4)).replace(day=1)
        step_hours = 12
    elif mode == "thisyear":
        start      = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
        end        = start.replace(year=start.year + 1)
        step_hours = 24
    else:
        return {"error": f"unknown quick mode: {mode!r}. Use: today | thisweek | thismonth | thisyear"}

    def to_jd(dt: datetime) -> float:
        ut = (dt.hour + dt.minute / 60.0) - tz
        return float(swe.julday(dt.year, dt.month, dt.day, ut))

    series = eng.compute_transit_series(
        start_jd   = to_jd(start),
        end_jd     = to_jd(end),
        lat        = float(lat),
        lon        = float(lon),
        step_hours = step_hours,
    )

    first   = series["samples"][0] if series["samples"] else {}
    planets = (first.get("bodies") or {}).get("planets") or {}
    snap    = {p: planets[p] for p in
               ["Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto"]
               if p in planets}

    return {
        "mode":       "quick_transits",
        "quick_mode": mode,
        "lat":        float(lat),
        "lon":        float(lon),
        "tz_offset":  tz,
        "range":      {"start": start.isoformat(), "end": end.isoformat(), "step_hours": step_hours},
        "snapshot":   snap,
    }


# ---------------------------------------------------------------------------
# Search & list
# ---------------------------------------------------------------------------

def run_search(params: Dict[str, Any]) -> Dict[str, Any]:
    eng   = _engine(params.get("ephe_dir"), params.get("spice_dir"))
    query = params["search"].strip().lower()
    all_names = eng.supported_objects()["objects"]
    matches = [n for n in all_names if query in n.lower()]
    results = [{"name": n, "type": "", "category": ""} for n in matches]
    return {"mode": "search", "query": params["search"], "count": len(results), "results": results}


def run_list(params: Dict[str, Any]) -> Dict[str, Any]:
    eng = _engine(params.get("ephe_dir"), params.get("spice_dir"))
    return eng.supported_objects()
