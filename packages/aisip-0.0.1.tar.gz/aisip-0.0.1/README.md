# aisip

AISIP — AI Structured Instruction Protocol

An open protocol for defining structured AI programs in JSON.

- Protocol: https://aisip.dev
- License: MIT
