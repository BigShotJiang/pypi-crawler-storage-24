# -*- coding: utf-8 -*-
"""
FastAPI application for the AtendentePro multi-tenant agent service.

Run directly:  python -m atendentepro.service.app
Via script:    atendentepro-service
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, HTTPException

from atendentepro.service.manager import TenantManager
from atendentepro.service.schemas import (
    ChatRequest,
    ChatResponse,
    HealthResponse,
    SetupRequest,
)

logger = logging.getLogger(__name__)

manager = TenantManager()


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    from atendentepro import __version__
    from atendentepro.config import configure
    from atendentepro.license import activate

    token = os.environ.get("ATENDENTEPRO_LICENSE_KEY")
    activate(token=token, silent=True)

    configure(
        provider=os.environ.get("ATENDENTEPRO_PROVIDER", "openai"),
        openai_api_key=os.environ.get("OPENAI_API_KEY"),
    )

    manager.start_cleanup_loop()
    logger.info("AtendentePro service v%s started", __version__)

    yield

    manager.stop_cleanup_loop()


def create_app() -> FastAPI:
    """Build and return the FastAPI application."""
    app = FastAPI(
        title="AtendentePro Service",
        description="Multi-tenant agent network server",
        lifespan=lifespan,
    )

    @app.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        from atendentepro import __version__

        return HealthResponse(
            version=__version__,
            tenants_loaded=manager.get_loaded_tenants(),
        )

    @app.post("/setup")
    async def setup_tenant(req: SetupRequest) -> dict:
        try:
            import yaml

            for config_name, content in req.yamls.items():
                try:
                    yaml.safe_load(content)
                except yaml.YAMLError as e:
                    raise HTTPException(
                        status_code=400,
                        detail=f"YAML invalido em '{config_name}': {e}",
                    ) from e

            await manager.setup(req.tenant_id, req.yamls)
        except HTTPException:
            raise
        except Exception as exc:
            logger.exception("Failed to setup tenant %s", req.tenant_id)
            raise HTTPException(
                status_code=500,
                detail=f"Erro ao configurar tenant: {exc}",
            ) from exc
        return {"status": "ok", "tenant_id": req.tenant_id}

    @app.post("/chat", response_model=ChatResponse)
    async def chat(req: ChatRequest) -> ChatResponse:
        try:
            result = await manager.chat(
                tenant_id=req.tenant_id,
                session_id=req.session_id,
                message=req.message,
                metadata=req.metadata,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception("Chat error for tenant %s", req.tenant_id)
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        return ChatResponse(**result)

    return app


app = create_app()


def main() -> None:
    """Entry point for the ``atendentepro-service`` console script."""
    import uvicorn

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run(
        "atendentepro.service.app:app",
        host=host,
        port=port,
        log_level="info",
    )


if __name__ == "__main__":
    main()
