# atendentepro.service — Servidor Multi-Tenant de Agentes

Servidor FastAPI que gerencia redes de agentes (`AgentNetwork`) por tenant via API REST.
Permite que qualquer aplicacao configure e converse com agentes AtendentePro sem precisar
escrever codigo Python — basta enviar YAMLs de configuracao e mensagens via HTTP.

## Arquitetura

```
  Qualquer cliente (Edge Function, backend, CLI, etc.)
        │
        ├── POST /setup   →  Configura tenant (envia YAMLs)
        ├── POST /chat    →  Envia mensagem e recebe resposta
        └── GET  /health  →  Verifica status do servidor
        │
        ▼
  atendentepro.service (este modulo)
        │
        ├── TenantManager    →  Gerencia AgentNetworks por tenant
        ├── Sessions         →  Historico de conversa por session_id
        └── Cleanup          →  Limpeza automatica de sessoes inativas
```

## Instalacao

```bash
pip install atendentepro[server]
```

## Inicio rapido

### Via linha de comando

```bash
export OPENAI_API_KEY="sk-..."
export ATENDENTEPRO_LICENSE_KEY="ATP_..."
export ATENDENTEPRO_LICENSE_SECRET="..."

atendentepro-service
```

O servidor inicia em `http://0.0.0.0:8000`.

### Via codigo

```python
from atendentepro.service import create_app

app = create_app()
```

### Via Docker

```bash
docker build -f Dockerfile.service -t atendentepro-service .
docker run -p 8000:8000 \
  -e OPENAI_API_KEY="sk-..." \
  -e ATENDENTEPRO_LICENSE_KEY="ATP_..." \
  -e ATENDENTEPRO_LICENSE_SECRET="..." \
  atendentepro-service
```

## Endpoints

### `GET /health`

Verifica status do servidor.

**Response:**
```json
{
  "status": "ok",
  "version": "0.7.4",
  "tenants_loaded": ["tenant_abc", "tenant_xyz"]
}
```

### `POST /setup`

Configura ou atualiza a rede de agentes de um tenant.

**Request:**
```json
{
  "tenant_id": "meu_tenant",
  "yamls": {
    "flow_config": "agent_name: Flow Agent\ntopics:\n  - id: 1\n    label: Vendas\n    ...",
    "triage_config": "agent_name: Triage Agent\nkeywords:\n  ...",
    "knowledge_config": "items:\n  - title: Horario\n    content: Segunda a sexta 8h-18h\n  ..."
  }
}
```

**Response (200):**
```json
{ "status": "ok", "tenant_id": "meu_tenant" }
```

**Response (400) — YAML invalido:**
```json
{ "detail": "YAML invalido em 'flow_config': ..." }
```

O campo `yamls` e um dicionario onde cada chave e o nome do config (sem `.yaml`) e o valor
e o conteudo YAML como string. Configs suportados:

| Chave | Arquivo gerado |
|---|---|
| `flow_config` | `flow_config.yaml` |
| `triage_config` | `triage_config.yaml` |
| `interview_config` | `interview_config.yaml` |
| `knowledge_config` | `knowledge_config.yaml` |
| `style_config` | `style_config.yaml` |
| `escalation_config` | `escalation_config.yaml` |
| `feedback_config` | `feedback_config.yaml` |
| `confirmation_config` | `confirmation_config.yaml` |
| `answer_config` | `answer_config.yaml` |
| `guardrails_config` | `guardrails_config.yaml` |
| `access_config` | `access_config.yaml` |
| `single_reply_config` | `single_reply_config.yaml` |
| `onboarding_config` | `onboarding_config.yaml` |

### `POST /chat`

Envia uma mensagem para a rede de agentes de um tenant.

**Request:**
```json
{
  "tenant_id": "meu_tenant",
  "session_id": "sessao_123",
  "message": "Qual o horario de funcionamento?",
  "metadata": {
    "phone": "+5511999999999",
    "channel": "whatsapp"
  }
}
```

**Response (200):**
```json
{
  "response": "Funcionamos de segunda a sexta, das 8h as 18h.",
  "agent_name": "Knowledge Agent",
  "handoff_to": null
}
```

**Response (404) — tenant nao configurado:**
```json
{ "detail": "Tenant 'meu_tenant' not configured. Call POST /setup first." }
```

O campo `metadata` e opcional e aceita qualquer estrutura — o servidor nao interpreta
os valores. Use para passar contexto do seu dominio (telefone, canal, user_id, etc.).

## Variaveis de ambiente

| Variavel | Obrigatorio | Descricao |
|---|---|---|
| `OPENAI_API_KEY` | Sim | Chave da API OpenAI |
| `ATENDENTEPRO_LICENSE_KEY` | Sim | Token de licenca AtendentePro |
| `ATENDENTEPRO_LICENSE_SECRET` | Sim | Chave HMAC para validacao do token |
| `ATENDENTEPRO_PROVIDER` | Nao | Provider do LLM (`openai` ou `azure`). Padrao: `openai` |
| `HOST` | Nao | Host de escuta. Padrao: `0.0.0.0` |
| `PORT` | Nao | Porta de escuta. Padrao: `8000` |
| `ATENDENTEPRO_SESSION_TTL` | Nao | TTL de sessao em segundos. Padrao: `3600` (1h) |

## Knowledge items

Quando o `knowledge_config` YAML contem `items` (lista de title/category/content),
o servidor converte automaticamente para o campo `about` do `KnowledgeConfig`,
que o Knowledge Agent recebe como contexto direto nas instrucoes.

```yaml
# Formato enviado pela edge function
items:
  - title: "Horario de funcionamento"
    category: "geral"
    content: "Segunda a sexta das 8h as 18h."
  - title: "Convenios aceitos"
    category: "financeiro"
    content: "Unimed, Bradesco Saude, SulAmerica."
```

Embeddings (RAG com documentos PDF) pertencem a um fluxo separado e nao sao
gerados pelo `/setup`.

## Uso programatico

```python
from atendentepro.service import TenantManager, create_app

# Usar o manager diretamente
manager = TenantManager()
await manager.setup("meu_tenant", {"flow_config": "...", "triage_config": "..."})
result = await manager.chat("meu_tenant", "sessao_1", "Ola!")

# Ou criar o app FastAPI
app = create_app()
```

## Deploy no Railway

1. Criar um repo com o codigo do AtendentePro (ou usar o pacote PyPI)
2. Adicionar `Dockerfile.service` na raiz
3. No Railway: New Project > Deploy from GitHub Repo
4. Configurar variaveis de ambiente: `OPENAI_API_KEY`, `ATENDENTEPRO_LICENSE_KEY`, `ATENDENTEPRO_LICENSE_SECRET`
5. Railway detecta o Dockerfile e faz deploy automatico
6. Copiar a URL gerada para usar como `ATENDENTEPRO_SERVER_URL` na edge function

## Estrutura do modulo

```
atendentepro/service/
├── __init__.py    # Exports: create_app, TenantManager, schemas
├── app.py         # FastAPI app, endpoints, lifespan
├── manager.py     # TenantManager: redes por tenant, sessoes, cleanup
├── schemas.py     # Pydantic models: SetupRequest, ChatRequest, etc.
└── README.md      # Este arquivo
```
