# -*- coding: utf-8 -*-
"""
Tenant manager for the AtendentePro multi-tenant service.

Handles per-tenant AgentNetwork lifecycle and per-session conversation history.
"""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

SESSION_TTL_SECONDS = int(os.environ.get("ATENDENTEPRO_SESSION_TTL", "3600"))
CLEANUP_INTERVAL_SECONDS = 300


@dataclass
class _Session:
    messages: List[Dict[str, str]] = field(default_factory=list)
    last_active: float = field(default_factory=time.time)


@dataclass
class _TenantState:
    network: Any  # AgentNetwork
    sessions: Dict[str, _Session] = field(default_factory=dict)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class TenantManager:
    """Manages AgentNetwork instances per tenant and conversation histories per session."""

    def __init__(self, templates_dir: Optional[Path] = None) -> None:
        self._tenants: Dict[str, _TenantState] = {}
        self._templates_dir = templates_dir or Path(tempfile.mkdtemp(prefix="atendentepro_"))
        self._cleanup_task: Optional[asyncio.Task[None]] = None

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------

    async def setup(self, tenant_id: str, yamls: Dict[str, str]) -> None:
        """Write YAML configs to disk and create an AgentNetwork for *tenant_id*.

        Knowledge items (title/category/content) received via YAML are mapped
        to the ``about`` field of ``knowledge_config.yaml`` so the Knowledge
        Agent has them as direct context.  Embeddings are NOT generated here --
        they belong to the separate document-upload flow (PDFs chunked into
        hundreds of embeddings).
        """
        import yaml as _yaml

        from atendentepro.network import create_standard_network
        from atendentepro.templates.manager import get_template_manager

        tenant_dir = self._templates_dir / tenant_id
        tenant_dir.mkdir(parents=True, exist_ok=True)

        for config_name, content in yamls.items():
            filename = f"{config_name}.yaml" if not config_name.endswith(".yaml") else config_name
            (tenant_dir / filename).write_text(content, encoding="utf-8")

        self._rewrite_knowledge_config(yamls, tenant_dir)

        get_template_manager().clear_caches()

        network = create_standard_network(
            templates_root=self._templates_dir,
            client=tenant_id,
        )

        if tenant_id in self._tenants:
            self._tenants[tenant_id].network = network
        else:
            self._tenants[tenant_id] = _TenantState(network=network)

        logger.info("Tenant %s configured (%d yamls)", tenant_id, len(yamls))

    # ------------------------------------------------------------------
    # Knowledge helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _rewrite_knowledge_config(yamls: Dict[str, str], tenant_dir: Path) -> None:
        """Convert knowledge items into the format KnowledgeConfig.load() expects.

        Incoming YAML may contain ``items`` (title/category/content).  The
        ``KnowledgeConfig`` model reads ``about``, ``template`` and ``format``.
        This method builds an ``about`` string from the items so the Knowledge
        Agent receives all the content as direct context (no RAG needed).
        """
        import yaml as _yaml

        raw = yamls.get("knowledge_config")
        if not raw:
            return

        try:
            data = _yaml.safe_load(raw)
        except Exception:
            return

        if not isinstance(data, dict):
            return

        items = data.get("items")
        if not items or not isinstance(items, list):
            return

        sections: List[str] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            title = item.get("title", "")
            category = item.get("category", "")
            content = item.get("content", "")
            if not content:
                continue
            header = title or category or "Item"
            sections.append(f"### {header}\n{content}")

        if not sections:
            return

        about_text = "\n\n".join(sections)

        kc_path = tenant_dir / "knowledge_config.yaml"
        existing: Dict[str, Any] = {}
        if kc_path.exists():
            existing = _yaml.safe_load(kc_path.read_text(encoding="utf-8")) or {}

        existing["about"] = about_text
        existing.pop("items", None)

        kc_path.write_text(_yaml.dump(existing, allow_unicode=True), encoding="utf-8")
        logger.info("Knowledge config rewritten with %d items as context", len(sections))

    # ------------------------------------------------------------------
    # Chat
    # ------------------------------------------------------------------

    async def chat(
        self,
        tenant_id: str,
        session_id: str,
        message: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Run a message through the tenant's triage agent and return the result."""
        from agents import Runner

        state = self._tenants.get(tenant_id)
        if state is None:
            raise KeyError(f"Tenant '{tenant_id}' not configured. Call POST /setup first.")

        async with state.lock:
            session = state.sessions.setdefault(session_id, _Session())
            session.last_active = time.time()

            session.messages.append({"role": "user", "content": message})

            result = await Runner.run(state.network.triage, list(session.messages))

            assistant_text = str(result.final_output) if result.final_output else ""
            session.messages.append({"role": "assistant", "content": assistant_text})

            last_agent = getattr(result, "last_agent", None)
            agent_name = getattr(last_agent, "name", None) if last_agent else None

        return {
            "response": assistant_text,
            "agent_name": agent_name,
        }

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_loaded_tenants(self) -> List[str]:
        return list(self._tenants.keys())

    def remove_tenant(self, tenant_id: str) -> bool:
        return self._tenants.pop(tenant_id, None) is not None

    # ------------------------------------------------------------------
    # Session cleanup
    # ------------------------------------------------------------------

    def start_cleanup_loop(self) -> None:
        if self._cleanup_task is None or self._cleanup_task.done():
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())

    def stop_cleanup_loop(self) -> None:
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()

    async def _cleanup_loop(self) -> None:
        while True:
            await asyncio.sleep(CLEANUP_INTERVAL_SECONDS)
            self._purge_expired_sessions()

    def _purge_expired_sessions(self) -> None:
        now = time.time()
        purged = 0
        for state in self._tenants.values():
            expired = [
                sid
                for sid, sess in state.sessions.items()
                if now - sess.last_active > SESSION_TTL_SECONDS
            ]
            for sid in expired:
                del state.sessions[sid]
                purged += 1
        if purged:
            logger.info("Purged %d expired sessions", purged)
