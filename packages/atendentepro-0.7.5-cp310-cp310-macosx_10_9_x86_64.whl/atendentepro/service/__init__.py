# -*- coding: utf-8 -*-
"""AtendentePro multi-tenant agent service."""

from atendentepro.service.app import create_app
from atendentepro.service.manager import TenantManager
from atendentepro.service.schemas import (
    ChatRequest,
    ChatResponse,
    HealthResponse,
    SetupRequest,
)

__all__ = [
    "create_app",
    "TenantManager",
    "SetupRequest",
    "ChatRequest",
    "ChatResponse",
    "HealthResponse",
]
