# nse

The nervous system for sovereign entities. Wires identity, wallet, calendar, relationships, and alignment into a coherent whole.

## Install

```bash
pip install nse-orchestrator
```

With pillars:

```bash
pip install nse-orchestrator[all]     # All five pillars
pip install nse-orchestrator[alignment,social]  # Just what you need
```

## Quick Start

```python
from nse import SovereignEntity

# Create an entity — detects installed pillars automatically
entity = SovereignEntity.create(owner_name="vergel", entity_name="tavin")

# Cross-pillar check before acting
verdicts = entity.check(
    "Pay 500 sats to unknown contact",
    involves_money=True,
    money_amount_sats=500,
    recipient_id="npub1stranger...",
    social_known=False,
)

if entity.should_escalate(verdicts):
    for v in verdicts:
        print(v.description)

# Score LLM responses — build trust profiles over time
entity.score_response(
    model_id="claude-opus-4-6",
    content="Here's my analysis...",
    quality=0.9,
    task_type="reasoning",
)

# Which model is best for code?
best = entity.best_model_for("code")
```

## What It Does

NSE is the orchestrator that sits between a sovereign entity and everything it touches. Each pillar is independent — NSE makes them aware of each other.

- **Cross-pillar checks** — "I'm paying someone who isn't in my contacts." No single pillar sees this.
- **LLM trust profiles** — score every model response, track which models are reliable for what
- **Coherence detection** — flag when two models contradict each other
- **Signal routing** — every action, response, and interaction flows through the nerve center

## The Five Pillars

| Pillar | Package | Optional Dep |
|--------|---------|-------------|
| Identity | `nostrkey` | `nse[identity]` |
| Finance | `nostrwalletconnect` | `nse[finance]` |
| Time | `nostrcalendar` | `nse[time]` |
| Relationships | `nostrsocial` | `nse[social]` |
| Alignment | `social-alignment` | `nse[alignment]` |

NSE works with zero pillars installed (just the nervous system) and gains capabilities as you add them.

## License

MIT — A [Humanjava](https://humanjava.com) project. Part of [NSE](https://nse.dev).
