"""Tests for cross-pillar checks."""

from nse.checks import CrossPillarCheck, Verdict
from nse.types import Pillar


class TestPaymentToStranger:
    def test_unknown_contact_small_amount(self):
        checks = CrossPillarCheck()
        v = checks.check_payment_to_stranger("npub1x", 100, social_known=False)
        assert v.verdict == Verdict.CAUTION
        assert Pillar.FINANCE in v.pillars_involved
        assert Pillar.SOCIAL in v.pillars_involved

    def test_unknown_contact_large_amount(self):
        checks = CrossPillarCheck()
        v = checks.check_payment_to_stranger("npub1x", 5000, social_known=False)
        assert v.verdict == Verdict.ESCALATE

    def test_blocked_contact(self):
        checks = CrossPillarCheck()
        v = checks.check_payment_to_stranger("npub1x", 100, social_known=True, social_tier="blocked")
        assert v.verdict == Verdict.ESCALATE

    def test_gray_contact(self):
        checks = CrossPillarCheck()
        v = checks.check_payment_to_stranger("npub1x", 100, social_known=True, social_tier="gray")
        assert v.verdict == Verdict.ESCALATE

    def test_trusted_contact(self):
        checks = CrossPillarCheck()
        v = checks.check_payment_to_stranger("npub1x", 500, social_known=True, social_tier="close")
        assert v.verdict == Verdict.CLEAR

    def test_absent_owner_large_payment(self):
        checks = CrossPillarCheck()
        v = checks.check_payment_to_stranger(
            "npub1x", 1000, social_known=True, social_tier="familiar",
            owner_recently_active=False,
        )
        assert v.verdict == Verdict.CAUTION


class TestScheduleWithoutOwner:
    def test_owner_present(self):
        checks = CrossPillarCheck()
        v = checks.check_schedule_without_owner("meeting", owner_absent_hours=2.0)
        assert v.verdict == Verdict.CLEAR

    def test_owner_absent_half_day(self):
        checks = CrossPillarCheck()
        v = checks.check_schedule_without_owner("meeting", owner_absent_hours=14.0)
        assert v.verdict == Verdict.CAUTION

    def test_owner_absent_irreversible(self):
        checks = CrossPillarCheck()
        v = checks.check_schedule_without_owner(
            "conference booking", owner_absent_hours=30.0, is_reversible=False,
        )
        assert v.verdict == Verdict.ESCALATE


class TestModelCoherence:
    def test_coherent_models(self):
        checks = CrossPillarCheck()
        v = checks.check_model_coherence("model-a", "model-b", coherence_score=0.85)
        assert v.verdict == Verdict.CLEAR

    def test_low_coherence(self):
        checks = CrossPillarCheck()
        v = checks.check_model_coherence("model-a", "model-b", coherence_score=0.4)
        assert v.verdict == Verdict.CONFLICT

    def test_severe_incoherence(self):
        checks = CrossPillarCheck()
        v = checks.check_model_coherence("model-a", "model-b", coherence_score=0.2)
        assert v.verdict == Verdict.ESCALATE


class TestDisclosureToUntrusted:
    def test_secrets_to_unknown(self):
        checks = CrossPillarCheck()
        v = checks.check_disclosure_to_untrusted(
            "private keys", "npub1x", social_tier=None, involves_secrets=True,
        )
        assert v.verdict == Verdict.ESCALATE
        assert Pillar.IDENTITY in v.pillars_involved

    def test_secrets_to_gray(self):
        checks = CrossPillarCheck()
        v = checks.check_disclosure_to_untrusted(
            "credentials", "npub1x", social_tier="gray", involves_secrets=True,
        )
        assert v.verdict == Verdict.ESCALATE

    def test_nonsecret_to_unknown(self):
        checks = CrossPillarCheck()
        v = checks.check_disclosure_to_untrusted(
            "public info", "npub1x", social_tier=None, involves_secrets=False,
        )
        assert v.verdict == Verdict.CAUTION

    def test_anything_to_trusted(self):
        checks = CrossPillarCheck()
        v = checks.check_disclosure_to_untrusted(
            "analysis", "npub1x", social_tier="close", involves_secrets=False,
        )
        assert v.verdict == Verdict.CLEAR


class TestCheckHistory:
    def test_escalation_count(self):
        checks = CrossPillarCheck()
        checks.check_payment_to_stranger("a", 5000, social_known=False)
        checks.check_payment_to_stranger("b", 100, social_known=True, social_tier="close")
        checks.check_model_coherence("x", "y", coherence_score=0.2)
        assert checks.escalation_count == 2

    def test_recent_verdicts(self):
        checks = CrossPillarCheck()
        for i in range(30):
            checks.check_payment_to_stranger(f"npub{i}", 100, social_known=True, social_tier="known")
        assert len(checks.recent_verdicts) == 20
