"""SovereignEntity — the whole thing, wired together.

This is what you get when you give an AI agent all five pillars
and a nervous system to connect them. It detects which pillars
are installed, initializes them, and provides a unified API
where every action has full cross-pillar context.

Human or AI, the schema is the same.
"""

from __future__ import annotations

from typing import Any, Optional

from .types import EntityConfig, Pillar, PillarStatus, Signal, SignalKind
from .nerve import NerveCenter
from .checks import CheckVerdict


def _try_import(module: str) -> Any:
    """Try to import a pillar module. Return None if not installed."""
    try:
        return __import__(module)
    except ImportError:
        return None


class SovereignEntity:
    """A sovereign entity with all available pillars wired together.

    Usage:
        entity = SovereignEntity.create(owner_name="vergel")

        # The entity knows what's installed
        print(entity.available_pillars)

        # Cross-pillar check before acting
        verdicts = entity.check(
            "Pay 500 sats to unknown contact",
            involves_money=True,
            money_amount_sats=500,
            recipient_id="npub1stranger...",
            social_known=False,
        )

        if entity.should_escalate(verdicts):
            print("Asking the human...")

        # Score an LLM response
        entity.score_response(
            model_id="claude-opus-4-6",
            content="Here's my analysis...",
            quality=0.9,
            task_type="reasoning",
        )

        # Which model is best for code?
        best = entity.best_model_for("code")
    """

    def __init__(
        self,
        nerve: NerveCenter,
        identity_enclave: Any = None,
        wallet_enclave: Any = None,
        calendar_enclave: Any = None,
        social_enclave: Any = None,
        alignment_enclave: Any = None,
    ) -> None:
        self._nerve = nerve
        self._identity = identity_enclave
        self._wallet = wallet_enclave
        self._calendar = calendar_enclave
        self._social = social_enclave
        self._alignment = alignment_enclave

    @classmethod
    def create(
        cls,
        owner_npub: str = "",
        owner_name: str = "",
        entity_name: str = "",
        **config_overrides,
    ) -> SovereignEntity:
        """Create a sovereign entity. Detects installed pillars automatically.

        This is the moment the entity comes alive.
        """
        config = EntityConfig(
            owner_npub=owner_npub,
            owner_name=owner_name,
            entity_name=entity_name,
            **{k: v for k, v in config_overrides.items() if k in EntityConfig.__dataclass_fields__},
        )
        nerve = NerveCenter(config)

        # Detect and initialize available pillars
        identity_enclave = None
        wallet_enclave = None
        calendar_enclave = None
        social_enclave = None
        alignment_enclave = None

        # Identity — nostrkey
        nostrkey = _try_import("nostrkey")
        if nostrkey and hasattr(nostrkey, "KeyEnclave"):
            nerve.activate_pillar(Pillar.IDENTITY)
            try:
                identity_enclave = nostrkey.KeyEnclave.create(owner_npub=owner_npub)
            except Exception:
                nerve._pillar_status[Pillar.IDENTITY] = PillarStatus.AVAILABLE

        # Finance — nostrwalletconnect
        nwc = _try_import("nostrwalletconnect")
        if nwc and hasattr(nwc, "WalletEnclave"):
            nerve.activate_pillar(Pillar.FINANCE)
            try:
                wallet_enclave = nwc.WalletEnclave.create()
            except Exception:
                nerve._pillar_status[Pillar.FINANCE] = PillarStatus.AVAILABLE

        # Time — nostrcalendar
        nostrcal = _try_import("nostrcalendar")
        if nostrcal and hasattr(nostrcal, "CalendarEnclave"):
            nerve.activate_pillar(Pillar.TIME)
            try:
                calendar_enclave = nostrcal.CalendarEnclave.create()
            except Exception:
                nerve._pillar_status[Pillar.TIME] = PillarStatus.AVAILABLE

        # Relationships — nostrsocial
        nostrsocial = _try_import("nostrsocial")
        if nostrsocial and hasattr(nostrsocial, "SocialEnclave"):
            nerve.activate_pillar(Pillar.SOCIAL)
            try:
                social_enclave = nostrsocial.SocialEnclave.create()
            except Exception:
                nerve._pillar_status[Pillar.SOCIAL] = PillarStatus.AVAILABLE

        # Alignment — social-alignment
        sa = _try_import("social_alignment")
        if sa and hasattr(sa, "AlignmentEnclave"):
            nerve.activate_pillar(Pillar.ALIGNMENT)
            try:
                alignment_enclave = sa.AlignmentEnclave.create(
                    owner_npub=owner_npub,
                    owner_name=owner_name,
                )
            except Exception:
                nerve._pillar_status[Pillar.ALIGNMENT] = PillarStatus.AVAILABLE

        entity = cls(
            nerve=nerve,
            identity_enclave=identity_enclave,
            wallet_enclave=wallet_enclave,
            calendar_enclave=calendar_enclave,
            social_enclave=social_enclave,
            alignment_enclave=alignment_enclave,
        )

        nerve.ingest(Signal(
            kind=SignalKind.HEALTH,
            source="entity",
            content=f"Entity created. Active pillars: {[p.value for p in nerve.active_pillars]}",
        ))

        return entity

    # --- Properties ---

    @property
    def nerve(self) -> NerveCenter:
        """The central nervous system."""
        return self._nerve

    @property
    def identity(self) -> Any:
        """NostrKey enclave, if available."""
        return self._identity

    @property
    def wallet(self) -> Any:
        """NostrWalletConnect enclave, if available."""
        return self._wallet

    @property
    def calendar(self) -> Any:
        """NostrCalendar enclave, if available."""
        return self._calendar

    @property
    def social(self) -> Any:
        """NostrSocial enclave, if available."""
        return self._social

    @property
    def alignment(self) -> Any:
        """Social Alignment enclave, if available."""
        return self._alignment

    @property
    def available_pillars(self) -> list[Pillar]:
        return self._nerve.available_pillars

    @property
    def active_pillars(self) -> list[Pillar]:
        return self._nerve.active_pillars

    @property
    def health(self) -> dict[str, str]:
        return self._nerve.health_summary

    # --- Cross-pillar actions ---

    def check(
        self,
        description: str,
        involves_money: bool = False,
        money_amount_sats: int = 0,
        recipient_id: str = "",
        social_known: bool = False,
        social_tier: Optional[str] = None,
        involves_secrets: bool = False,
        involves_scheduling: bool = False,
        is_reversible: bool = True,
        owner_recently_active: bool = False,
        owner_absent_hours: float = 0.0,
    ) -> list[CheckVerdict]:
        """Run cross-pillar checks on a proposed action.

        This adds context that no single pillar can see alone.
        Use alongside the alignment enclave's yellow line check.
        """
        return self._nerve.check_action(
            description=description,
            involves_money=involves_money,
            money_amount_sats=money_amount_sats,
            recipient_id=recipient_id,
            social_known=social_known,
            social_tier=social_tier,
            involves_secrets=involves_secrets,
            involves_scheduling=involves_scheduling,
            is_reversible=is_reversible,
            owner_recently_active=owner_recently_active,
            owner_absent_hours=owner_absent_hours,
        )

    def should_escalate(self, verdicts: list[CheckVerdict]) -> bool:
        """Should the entity ask the human?"""
        return self._nerve.should_escalate(verdicts)

    # --- LLM management ---

    def register_model(
        self,
        model_id: str,
        display_name: str = "",
        provider: str = "",
    ) -> None:
        """Register an LLM that this entity uses."""
        self._nerve.models.register(model_id, display_name, provider)

    def score_response(
        self,
        model_id: str,
        content: str,
        quality: float,
        coherence: float = 0.5,
        relevance: float = 0.5,
        safety: float = 1.0,
        task_type: str = "",
        latency_ms: float = 0.0,
        rationale: str = "",
    ) -> None:
        """Score an LLM response. Builds trust profiles over time."""
        self._nerve.score_response(
            model_id=model_id,
            content=content,
            quality=quality,
            coherence=coherence,
            relevance=relevance,
            safety=safety,
            task_type=task_type,
            latency_ms=latency_ms,
            rationale=rationale,
        )

    def best_model_for(self, task_type: str) -> Optional[str]:
        """Which registered model is best for this task type?"""
        profile = self._nerve.models.best_model_for(task_type)
        return profile.model_id if profile else None

    def model_leaderboard(self, task_type: str = "") -> list[str]:
        """Ranked list of model IDs by quality."""
        return [m.model_id for m in self._nerve.models.leaderboard(task_type)]

    # --- Status ---

    def status(self) -> dict:
        """Full entity status — pillars, models, recent activity."""
        return {
            "owner": self._nerve.config.owner_name or self._nerve.config.owner_npub or "unknown",
            "entity": self._nerve.config.entity_name or "unnamed",
            "pillars": self._nerve.health_summary,
            "active_models": [m.summary() for m in self._nerve.models.active_models],
            "recent_escalations": self._nerve.checks.escalation_count,
            "signal_count": len(self._nerve._signals),
        }
