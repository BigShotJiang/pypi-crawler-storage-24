"""NSE — the nervous system for sovereign entities.

Not a framework. Not a rules engine. A living layer that sits between
an entity and everything it touches. Every signal passes through.
Every response gets scored. Every relationship gets context.

The five pillars are the organs. NSE is the nervous system.
"""

from .entity import SovereignEntity
from .types import (
    Pillar,
    PillarStatus,
    EntityConfig,
    Signal,
    SignalKind,
    ScoreCard,
)
from .nerve import NerveCenter
from .models import ModelRegistry, ModelProfile, ModelScore
from .checks import CrossPillarCheck, CheckVerdict

__version__ = "0.1.0"

__all__ = [
    # Core
    "SovereignEntity",
    "NerveCenter",
    # Types
    "Pillar",
    "PillarStatus",
    "EntityConfig",
    "Signal",
    "SignalKind",
    "ScoreCard",
    # Model awareness
    "ModelRegistry",
    "ModelProfile",
    "ModelScore",
    # Cross-pillar
    "CrossPillarCheck",
    "CheckVerdict",
]
