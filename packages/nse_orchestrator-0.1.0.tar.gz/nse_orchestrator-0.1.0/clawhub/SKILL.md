# nse

The nervous system for sovereign AI entities. Wires five pillars into a coherent whole.

## What it does
NSE sits between a sovereign entity and everything it touches. Every signal passes through. Every LLM response gets scored. Every cross-pillar conflict gets caught.

- **Cross-pillar checks** — "I'm paying someone who isn't in my contacts." No single pillar sees this.
- **LLM trust profiles** — score every model response, track which models are reliable for what.
- **Coherence detection** — flag when two models contradict each other.
- **Signal routing** — every action, response, and interaction flows through the nerve center.

## Install
```bash
pip install nse-orchestrator[all]
```

## Quick Start
```python
from nse import SovereignEntity

entity = SovereignEntity.create(owner_name="vergel")

# Cross-pillar check — the nervous system sees across all five pillars
verdicts = entity.check(
    "Pay 500 sats to unknown contact",
    involves_money=True,
    money_amount_sats=500,
    recipient_id="npub1stranger...",
)

if entity.should_escalate(verdicts):
    for v in verdicts:
        print(v.description)

# Score LLM responses — build trust over time
entity.score_response("claude-opus-4-6", "analysis...", quality=0.9, task_type="reasoning")
```

## The Five Pillars
All optional. NSE gains capabilities as you install them.

| Pillar | Package | What |
|--------|---------|------|
| Identity | nostrkey | Keypairs, signing, encryption |
| Finance | nostrwalletconnect | Lightning via NIP-47 |
| Time | nostrcalendar | Scheduling via NIP-52 |
| Relationships | nostrsocial | Trust tiers, drift, guardrails |
| Alignment | social-alignment | Five lenses, escalation, wisdom |
