use std::path::Path;

use linguafranca::error::ConversionWarning;
use linguafranca::traits::{FromOpenResponses, IntoOpenResponses};
use pretty_assertions::assert_eq;
use serde::Serialize;
use serde::de::DeserializeOwned;

pub fn load_fixture<T: DeserializeOwned>(path: &Path, case: &str) -> T {
    let json = std::fs::read_to_string(path)
        .unwrap_or_else(|e| panic!("failed to read {}: {e}", path.display()));
    serde_json::from_str(&json).unwrap_or_else(|e| {
        panic!(
            "{case}/{} parse error: {e}",
            path.file_name().unwrap().to_str().unwrap()
        )
    })
}

pub fn assert_json_eq(actual: &serde_json::Value, expected: &serde_json::Value, label: &str) {
    let actual_pretty = serde_json::to_string_pretty(actual).unwrap();
    let expected_pretty = serde_json::to_string_pretty(expected).unwrap();
    assert_eq!(actual_pretty, expected_pretty, "{label}");
}

pub fn check_warnings(dir: &Path, direction: &str, warnings: Vec<ConversionWarning>, case: &str) {
    let path = dir.join(format!("warnings.{direction}.json"));
    if path.exists() {
        let expected: Vec<WarningFixture> = load_fixture(&path, case);
        let actual: Vec<WarningFixture> = warnings
            .into_iter()
            .map(|w| WarningFixture {
                field: w.field,
                message: w.message,
            })
            .collect();
        assert_eq!(actual, expected, "{case} {direction} warnings mismatch");
    } else {
        assert!(
            warnings.is_empty(),
            "{case} {direction} produced unexpected warnings: {warnings:?}"
        );
    }
}

pub fn run_into_open_responses_case<S, O>(
    case: &str,
    dir: &Path,
    source_filename: &str,
    open_responses_filename: &str,
    warning_direction: &str,
    label: &str,
) where
    S: DeserializeOwned + IntoOpenResponses<Target = O>,
    O: Serialize,
{
    let input: S = load_fixture(&dir.join(source_filename), case);
    let result = input.into_open_responses().unwrap();
    let expected: serde_json::Value = load_fixture(&dir.join(open_responses_filename), case);
    assert_json_eq(
        &serde_json::to_value(&result.value).unwrap(),
        &expected,
        label,
    );
    check_warnings(dir, warning_direction, result.warnings, case);
}

pub fn run_from_open_responses_case<T, O>(
    case: &str,
    dir: &Path,
    target_filename: &str,
    open_responses_filename: &str,
    warning_direction: &str,
    label: &str,
) where
    T: FromOpenResponses<Source = O> + Serialize,
    O: DeserializeOwned,
{
    let input: O = load_fixture(&dir.join(open_responses_filename), case);
    let result = T::from_open_responses(input).unwrap();
    let expected: serde_json::Value = load_fixture(&dir.join(target_filename), case);
    assert_json_eq(
        &serde_json::to_value(&result.value).unwrap(),
        &expected,
        label,
    );
    check_warnings(dir, warning_direction, result.warnings, case);
}

#[derive(Debug, PartialEq, serde::Deserialize, serde::Serialize)]
struct WarningFixture {
    field: String,
    message: String,
}
