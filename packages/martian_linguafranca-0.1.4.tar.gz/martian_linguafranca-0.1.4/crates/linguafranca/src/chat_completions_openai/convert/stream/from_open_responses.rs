use crate::chat_completions_openai::convert::mapping::open_responses_status_to_chat_completions_finish_reason;
use crate::chat_completions_openai::stream::{
    ChatCompletionsStreamChoice, ChatCompletionsStreamChunk, ChatCompletionsStreamDelta,
    ChatCompletionsStreamFunctionDelta, ChatCompletionsStreamToolCall,
};
use crate::error::{ConversionError, ConversionWarning};
use crate::open_responses::stream::OpenResponsesStreamEvent;
use crate::open_responses::types::*;
use crate::stream::StreamTransform;

use super::accum::OpenResponsesToChatCompletionsAccum;

/// Converts Open Responses stream events to Chat Completions stream chunks.
pub struct OpenResponsesToChatCompletionsStream {
    accum: OpenResponsesToChatCompletionsAccum,
}

impl Default for OpenResponsesToChatCompletionsStream {
    fn default() -> Self {
        Self::new()
    }
}

impl OpenResponsesToChatCompletionsStream {
    pub fn new() -> Self {
        Self {
            accum: OpenResponsesToChatCompletionsAccum::new(),
        }
    }
}

impl StreamTransform for OpenResponsesToChatCompletionsStream {
    type Input = OpenResponsesStreamEvent;
    type Output = ChatCompletionsStreamChunk;

    fn transform(
        &mut self,
        input: OpenResponsesStreamEvent,
    ) -> Result<Vec<ChatCompletionsStreamChunk>, ConversionError> {
        let accum = &mut self.accum;

        match input {
            OpenResponsesStreamEvent::ResponseCreated { response, .. }
            | OpenResponsesStreamEvent::ResponseQueued { response, .. }
            | OpenResponsesStreamEvent::ResponseInProgress { response, .. } => {
                accum.remember_response_header(response.id, response.model, response.created_at);
                Ok(vec![])
            }
            OpenResponsesStreamEvent::OutputTextDelta {
                delta,
                logprobs,
                obfuscation,
                ..
            } => {
                if !logprobs.is_empty() {
                    accum.ctx.warn(
                        "output_text.logprobs",
                        "not supported in Chat Completions streaming, dropped",
                    );
                }
                if obfuscation.is_some() {
                    accum.ctx.warn(
                        "output_text.obfuscation",
                        "not supported in Chat Completions streaming, dropped",
                    );
                }
                Ok(emit_delta_chunk(
                    accum,
                    ChatCompletionsStreamDelta {
                        role: None,
                        content: Some(delta),
                        tool_calls: None,
                        refusal: None,
                        reasoning_content: None,
                    },
                    None,
                ))
            }
            OpenResponsesStreamEvent::RefusalDelta { delta, .. } => Ok(emit_delta_chunk(
                accum,
                ChatCompletionsStreamDelta {
                    role: None,
                    content: None,
                    tool_calls: None,
                    refusal: Some(delta),
                    reasoning_content: None,
                },
                None,
            )),
            OpenResponsesStreamEvent::ReasoningDelta {
                delta, obfuscation, ..
            }
            | OpenResponsesStreamEvent::ReasoningSummaryTextDelta {
                delta, obfuscation, ..
            } => {
                if obfuscation.is_some() {
                    accum.ctx.warn(
                        "reasoning.obfuscation",
                        "not supported in Chat Completions streaming, dropped",
                    );
                }
                Ok(emit_delta_chunk(
                    accum,
                    ChatCompletionsStreamDelta {
                        role: None,
                        content: None,
                        tool_calls: None,
                        refusal: None,
                        reasoning_content: Some(delta),
                    },
                    None,
                ))
            }
            OpenResponsesStreamEvent::OutputItemAdded { item, .. } => {
                handle_output_item_added(accum, item)
            }
            OpenResponsesStreamEvent::FunctionCallArgumentsDelta {
                item_id,
                delta,
                obfuscation,
                ..
            } => {
                if obfuscation.is_some() {
                    accum.ctx.warn(
                        "function_call_arguments.obfuscation",
                        "not supported in Chat Completions streaming, dropped",
                    );
                }
                let index = accum.get_or_create_tool_call_index(&item_id);
                Ok(emit_delta_chunk(
                    accum,
                    ChatCompletionsStreamDelta {
                        role: None,
                        content: None,
                        refusal: None,
                        reasoning_content: None,
                        tool_calls: Some(vec![ChatCompletionsStreamToolCall {
                            index,
                            id: None,
                            kind: None,
                            function: Some(ChatCompletionsStreamFunctionDelta {
                                name: None,
                                arguments: Some(delta),
                            }),
                        }]),
                    },
                    None,
                ))
            }
            OpenResponsesStreamEvent::OutputTextAnnotationAdded { annotation, .. } => {
                if annotation.is_some() {
                    accum.ctx.warn(
                        "annotation",
                        "not supported in Chat Completions streaming, dropped",
                    );
                }
                Ok(vec![])
            }
            OpenResponsesStreamEvent::ResponseCompleted { response, .. }
            | OpenResponsesStreamEvent::ResponseIncomplete { response, .. }
            | OpenResponsesStreamEvent::ResponseFailed { response, .. } => {
                accum.remember_response_header(response.id, response.model, response.created_at);
                Ok(handle_terminal(
                    accum,
                    response.status,
                    response.output,
                    response.usage,
                ))
            }
            OpenResponsesStreamEvent::ContentPartAdded { part, .. } => {
                match part {
                    ContentPart::OutputText { .. } | ContentPart::Refusal { .. } => {}
                    ContentPart::InputText { .. }
                    | ContentPart::InputImage { .. }
                    | ContentPart::InputFile { .. } => {
                        accum
                            .ctx
                            .warn("content_part", "input-type content in output, dropped");
                    }
                    ContentPart::Text { .. }
                    | ContentPart::SummaryText { .. }
                    | ContentPart::ReasoningText { .. } => {
                        accum.ctx.warn(
                            "content_part",
                            "non-output content part in output message is not representable in Chat Completions streaming, dropped",
                        );
                    }
                }
                Ok(vec![])
            }
            OpenResponsesStreamEvent::OutputItemDone { .. } => Ok(vec![]),
            OpenResponsesStreamEvent::OutputTextDone { logprobs, .. } => {
                if !logprobs.is_empty() {
                    accum.ctx.warn(
                        "output_text.logprobs",
                        "not supported in Chat Completions streaming, dropped",
                    );
                }
                Ok(vec![])
            }
            OpenResponsesStreamEvent::ContentPartDone { .. }
            | OpenResponsesStreamEvent::RefusalDone { .. }
            | OpenResponsesStreamEvent::ReasoningDone { .. }
            | OpenResponsesStreamEvent::ReasoningSummaryPartAdded { .. }
            | OpenResponsesStreamEvent::ReasoningSummaryPartDone { .. }
            | OpenResponsesStreamEvent::ReasoningSummaryTextDone { .. }
            | OpenResponsesStreamEvent::FunctionCallArgumentsDone { .. } => Ok(vec![]),
        }
    }

    fn flush(&mut self) -> Result<Vec<ChatCompletionsStreamChunk>, ConversionError> {
        // We do not synthesize terminal chunks on flush. OR->CC requires an
        // explicit terminal Open Responses event to emit finish_reason.
        Ok(vec![])
    }

    fn take_warnings(&mut self) -> Vec<ConversionWarning> {
        self.accum.ctx.take_warnings()
    }
}

fn handle_output_item_added(
    accum: &mut OpenResponsesToChatCompletionsAccum,
    item: OutputItem,
) -> Result<Vec<ChatCompletionsStreamChunk>, ConversionError> {
    match item {
        OutputItem::FunctionCall {
            id,
            call_id,
            name,
            arguments,
            ..
        } => {
            accum.saw_function_call = true;
            let index = accum.get_or_create_tool_call_index(&id);
            Ok(emit_delta_chunk(
                accum,
                ChatCompletionsStreamDelta {
                    role: None,
                    content: None,
                    tool_calls: Some(vec![ChatCompletionsStreamToolCall {
                        index,
                        id: (!call_id.is_empty()).then_some(call_id),
                        kind: Some("function".into()),
                        function: Some(ChatCompletionsStreamFunctionDelta {
                            name: (!name.is_empty()).then_some(name),
                            arguments: Some(arguments),
                        }),
                    }]),
                    refusal: None,
                    reasoning_content: None,
                },
                None,
            ))
        }
        OutputItem::Message { role, .. } => {
            if role != MessageRole::Assistant {
                accum.ctx.warn(
                    "role",
                    "non-assistant output message role is not valid in Chat Completions streaming, dropped",
                );
            }
            Ok(vec![])
        }
        OutputItem::FunctionCallOutput { .. } => {
            accum.ctx.warn(
                "function_call_output",
                "not valid in Chat Completions streaming output, dropped",
            );
            Ok(vec![])
        }
        OutputItem::Reasoning { .. } => Ok(vec![]),
    }
}

fn handle_terminal(
    accum: &mut OpenResponsesToChatCompletionsAccum,
    status: ResponseStatus,
    output: Vec<OutputItem>,
    usage: Option<Usage>,
) -> Vec<ChatCompletionsStreamChunk> {
    let finish_reason = if accum.saw_function_call && matches!(status, ResponseStatus::Completed) {
        crate::chat_completions_openai::types::ChatCompletionsFinishReason::ToolCalls
    } else {
        open_responses_status_to_chat_completions_finish_reason(status, &output)
            .unwrap_or(crate::chat_completions_openai::types::ChatCompletionsFinishReason::Stop)
    };

    let mut chunks = emit_delta_chunk(
        accum,
        ChatCompletionsStreamDelta {
            role: None,
            content: None,
            tool_calls: None,
            refusal: None,
            reasoning_content: None,
        },
        Some(finish_reason),
    );

    if let Some(usage) = usage {
        chunks.push(ChatCompletionsStreamChunk {
            id: accum.response_id.clone(),
            object: "chat.completion.chunk".into(),
            created: accum.created,
            model: accum.model.clone(),
            choices: vec![],
            usage: Some(usage.into()),
            system_fingerprint: None,
            service_tier: None,
            obfuscation: None,
        });
    }

    chunks
}

fn emit_delta_chunk(
    accum: &mut OpenResponsesToChatCompletionsAccum,
    delta: ChatCompletionsStreamDelta,
    finish_reason: Option<crate::chat_completions_openai::types::ChatCompletionsFinishReason>,
) -> Vec<ChatCompletionsStreamChunk> {
    let mut chunks = Vec::new();

    if !accum.role_prelude_emitted {
        accum.role_prelude_emitted = true;
        chunks.push(ChatCompletionsStreamChunk {
            id: accum.response_id.clone(),
            object: "chat.completion.chunk".into(),
            created: accum.created,
            model: accum.model.clone(),
            choices: vec![ChatCompletionsStreamChoice {
                index: 0,
                delta: ChatCompletionsStreamDelta {
                    role: Some("assistant".into()),
                    content: None,
                    tool_calls: None,
                    refusal: None,
                    reasoning_content: None,
                },
                finish_reason: None,
                logprobs: None,
            }],
            usage: None,
            system_fingerprint: None,
            service_tier: None,
            obfuscation: None,
        });
    }

    chunks.push(ChatCompletionsStreamChunk {
        id: accum.response_id.clone(),
        object: "chat.completion.chunk".into(),
        created: accum.created,
        model: accum.model.clone(),
        choices: vec![ChatCompletionsStreamChoice {
            index: 0,
            delta,
            finish_reason,
            logprobs: None,
        }],
        usage: None,
        system_fingerprint: None,
        service_tier: None,
        obfuscation: None,
    });

    chunks
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn role_prelude_emitted_once() {
        let mut stream = OpenResponsesToChatCompletionsStream::new();
        stream
            .transform(OpenResponsesStreamEvent::ResponseCreated {
                sequence_number: 0,
                response: crate::open_responses::response::OpenResponsesResponse {
                    id: "resp_1".into(),
                    object: "response".into(),
                    created_at: 1,
                    status: ResponseStatus::InProgress,
                    model: "gpt-5".into(),
                    ..Default::default()
                },
            })
            .expect("ok");

        let first = stream
            .transform(OpenResponsesStreamEvent::OutputTextDelta {
                sequence_number: 1,
                item_id: "msg_0".into(),
                output_index: 0,
                content_index: 0,
                delta: "hello".into(),
                logprobs: vec![],
                obfuscation: None,
            })
            .expect("ok");
        assert_eq!(first.len(), 2);

        let second = stream
            .transform(OpenResponsesStreamEvent::OutputTextDelta {
                sequence_number: 2,
                item_id: "msg_0".into(),
                output_index: 0,
                content_index: 0,
                delta: " world".into(),
                logprobs: vec![],
                obfuscation: None,
            })
            .expect("ok");
        assert_eq!(second.len(), 1);
    }

    #[test]
    fn function_call_added_preserves_inline_arguments() {
        let mut stream = OpenResponsesToChatCompletionsStream::new();
        stream
            .transform(OpenResponsesStreamEvent::ResponseCreated {
                sequence_number: 0,
                response: crate::open_responses::response::OpenResponsesResponse {
                    id: "resp_1".into(),
                    object: "response".into(),
                    created_at: 1,
                    status: ResponseStatus::InProgress,
                    model: "gpt-5".into(),
                    ..Default::default()
                },
            })
            .expect("ok");

        let out = stream
            .transform(OpenResponsesStreamEvent::OutputItemAdded {
                sequence_number: 1,
                output_index: 0,
                item: OutputItem::FunctionCall {
                    id: "fc_1".into(),
                    call_id: "call_1".into(),
                    name: "lookup".into(),
                    arguments: "{\"q\":\"x\"}".into(),
                    status: ItemStatus::InProgress,
                },
            })
            .expect("ok");

        let tool_calls = out
            .last()
            .expect("delta chunk")
            .choices
            .first()
            .expect("choice")
            .delta
            .tool_calls
            .as_ref()
            .expect("tool_calls");
        let function = tool_calls[0].function.as_ref().expect("function");
        assert_eq!(function.arguments.as_deref(), Some("{\"q\":\"x\"}"));
    }

    #[test]
    fn function_call_added_preserves_empty_inline_arguments() {
        let mut stream = OpenResponsesToChatCompletionsStream::new();
        stream
            .transform(OpenResponsesStreamEvent::ResponseCreated {
                sequence_number: 0,
                response: crate::open_responses::response::OpenResponsesResponse {
                    id: "resp_1".into(),
                    object: "response".into(),
                    created_at: 1,
                    status: ResponseStatus::InProgress,
                    model: "gpt-5".into(),
                    ..Default::default()
                },
            })
            .expect("ok");

        let out = stream
            .transform(OpenResponsesStreamEvent::OutputItemAdded {
                sequence_number: 1,
                output_index: 0,
                item: OutputItem::FunctionCall {
                    id: "fc_1".into(),
                    call_id: "call_1".into(),
                    name: "lookup".into(),
                    arguments: String::new(),
                    status: ItemStatus::InProgress,
                },
            })
            .expect("ok");

        let tool_calls = out
            .last()
            .expect("delta chunk")
            .choices
            .first()
            .expect("choice")
            .delta
            .tool_calls
            .as_ref()
            .expect("tool_calls");
        let function = tool_calls[0].function.as_ref().expect("function");
        assert_eq!(function.arguments.as_deref(), Some(""));
    }

    #[test]
    fn flush_without_terminal_event_emits_no_synthetic_chunk() {
        let mut stream = OpenResponsesToChatCompletionsStream::new();
        stream
            .transform(OpenResponsesStreamEvent::ResponseCreated {
                sequence_number: 0,
                response: crate::open_responses::response::OpenResponsesResponse {
                    id: "resp_1".into(),
                    object: "response".into(),
                    created_at: 1,
                    status: ResponseStatus::InProgress,
                    model: "gpt-5".into(),
                    ..Default::default()
                },
            })
            .expect("ok");

        let flushed = stream.flush().expect("ok");
        assert!(flushed.is_empty());
    }
}
