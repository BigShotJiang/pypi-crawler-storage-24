use crate::anthropic::convert::ctx::ConversionCtx;
use crate::anthropic::convert::helpers::*;
use crate::anthropic::response::AnthropicResponse;
use crate::anthropic::types::*;
use crate::convert::mapping::LossyTryFromWithCtx;
use crate::convert::open_responses_output_accum::OpenResponsesOutputAccum;
use crate::error::{ConversionError, ConversionResult};
use crate::open_responses::response::OpenResponsesResponse;
use crate::open_responses::types::*;
use crate::traits::IntoOpenResponses;

impl IntoOpenResponses for AnthropicResponse {
    type Target = OpenResponsesResponse;

    fn into_open_responses(
        self,
    ) -> Result<ConversionResult<OpenResponsesResponse>, ConversionError> {
        let mut ctx = ConversionCtx::new();
        let mut accum = OpenResponsesOutputAccum::new();

        convert_content_blocks(&mut accum, self.content, &mut ctx);

        let (status, incomplete_details) =
            convert_anthropic_messages_stop_reason_to_open_responses(self.stop_reason);

        let mut result = ConversionResult::with_warnings(
            OpenResponsesResponse {
                id: self.id,
                object: "response".into(),
                created_at: 0,
                status,
                model: self.model,
                output: accum.into_items(),
                incomplete_details,
                usage: Some(self.usage.into()),
                service_tier: self
                    .service_tier
                    .and_then(|tier| ServiceTier::lossy_try_from(tier, &mut ctx, "service_tier")),
                ..Default::default()
            },
            ctx.into_warnings(),
        );

        result.warn_unsupported(
            "Open Responses",
            &[
                ("container", self.container.is_some()),
                ("stop_sequence", self.stop_sequence.is_some()),
            ],
        );

        Ok(result)
    }
}

fn convert_content_blocks(
    accum: &mut OpenResponsesOutputAccum,
    blocks: Vec<AnthropicOutputContentBlock>,
    ctx: &mut ConversionCtx,
) {
    let mut fc_index = 0;

    for (i, block) in blocks.into_iter().enumerate() {
        ctx.push(format!("content[{i}]"));

        let known = match block {
            AnthropicOutputContentBlock::Known(k) => k,
            // TODO: handle unknown content blocks instead of dropping
            AnthropicOutputContentBlock::Other(_) => {
                ctx.warn("content_block", "unknown content block type, dropped");
                ctx.pop();
                continue;
            }
        };

        match known {
            AnthropicKnownOutputContentBlock::Text { text, citations } => {
                convert_text_block(accum, text, citations, ctx);
            }
            AnthropicKnownOutputContentBlock::ToolUse { id, name, input } => {
                convert_tool_use_block(accum, id, name, input, &mut fc_index, ctx);
            }
            AnthropicKnownOutputContentBlock::Thinking {
                thinking,
                signature,
            } => {
                accum.push_item(OutputItem::Reasoning {
                    id: format!("rs_{i}"),
                    summary: vec![ContentPart::SummaryText { text: thinking }],
                    content: None,
                    encrypted_content: Some(signature),
                });
            }
            AnthropicKnownOutputContentBlock::RedactedThinking { data } => {
                accum.push_item(OutputItem::Reasoning {
                    id: format!("rs_{i}"),
                    summary: Vec::new(),
                    content: None,
                    encrypted_content: Some(data),
                });
            }
        }

        ctx.pop();
    }

    accum.flush_message();
}

fn convert_text_block(
    accum: &mut OpenResponsesOutputAccum,
    text: String,
    citations: Vec<AnthropicCitation>,
    ctx: &mut ConversionCtx,
) {
    let annotations: Vec<Annotation> = citations
        .into_iter()
        .filter_map(|c| {
            let result = convert_anthropic_messages_citation_to_open_responses(c);
            if result.is_none() {
                ctx.warn("citation", "non-URL citation type, dropped");
            }
            result
        })
        .collect();

    accum.push_content_part(ContentPart::OutputText {
        text,
        annotations,
        logprobs: vec![],
    });
}

fn convert_tool_use_block(
    accum: &mut OpenResponsesOutputAccum,
    id: String,
    name: String,
    input: serde_json::Value,
    fc_index: &mut usize,
    ctx: &mut ConversionCtx,
) {
    // TODO: can arguments be something other than a JSON object? Investigate and handle other
    // cases if so
    let arguments = serde_json::to_string(&input).unwrap_or_else(|_| {
        ctx.warn(
            "tool_use.input",
            "failed to serialize tool input, replaced with empty string",
        );
        String::new()
    });
    let fc_id = format!("fc_{}", *fc_index);
    *fc_index += 1;

    accum.push_item(OutputItem::FunctionCall {
        id: fc_id,
        call_id: id,
        name,
        arguments,
        status: ItemStatus::Completed,
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn web_search_citation_converts_to_url_citation() {
        let citation = AnthropicCitation::WebSearchResultLocation {
            cited_text: "hello world".into(),
            encrypted_index: "enc".into(),
            title: "Example".into(),
            url: "https://example.com".into(),
        };
        let ann = convert_anthropic_messages_citation_to_open_responses(citation).unwrap();
        match ann {
            Annotation::UrlCitation {
                url,
                title,
                end_index,
                ..
            } => {
                assert_eq!(url, "https://example.com");
                assert_eq!(title, "Example");
                assert_eq!(end_index, 11);
            }
        }
    }

    #[test]
    fn non_url_citation_returns_none() {
        let citation = AnthropicCitation::CharLocation {
            cited_text: "x".into(),
            document_index: 0,
            document_title: "t".into(),
            start_char_index: 0,
            end_char_index: 1,
        };
        assert!(convert_anthropic_messages_citation_to_open_responses(citation).is_none());
    }

    #[test]
    fn usage_conversion_preserves_tokens() {
        let am = AnthropicUsage {
            input_tokens: 100,
            output_tokens: 50,
            cache_creation_input_tokens: None,
            cache_read_input_tokens: Some(20),
            cache_creation: None,
            server_tool_use: None,
            service_tier: None,
            inference_geo: None,
        };
        let or = Usage::from(am);
        assert_eq!(or.input_tokens, 100);
        assert_eq!(or.output_tokens, 50);
        assert_eq!(or.total_tokens, 150);
        assert_eq!(or.input_tokens_details.unwrap().cached_tokens, 20);
    }

    #[test]
    fn stop_reason_end_turn_maps_to_completed() {
        let (status, details) = convert_anthropic_messages_stop_reason_to_open_responses(Some(
            AnthropicStopReason::EndTurn,
        ));
        assert_eq!(status, ResponseStatus::Completed);
        assert!(details.is_none());
    }

    #[test]
    fn stop_reason_max_tokens_maps_to_incomplete() {
        let (status, details) = convert_anthropic_messages_stop_reason_to_open_responses(Some(
            AnthropicStopReason::MaxTokens,
        ));
        assert_eq!(status, ResponseStatus::Incomplete);
        assert_eq!(details.unwrap().reason, "max_output_tokens");
    }
}
