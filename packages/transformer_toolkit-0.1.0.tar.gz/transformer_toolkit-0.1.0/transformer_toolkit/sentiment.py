# sentiment.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from transformer_toolkit import Transformer, TransformerConfig
from c_tokenizers import HFTokenizer


LABELS = {"negative": 0, "neutral": 1, "positive": 2}
ID2LAB = {v: k for k, v in LABELS.items()}
COLORS = {
    "positive": "\033[32m",   # green
    "neutral":  "\033[33m",   # yellow
    "negative": "\033[31m",   # red
    "reset":    "\033[0m",
    "bold":     "\033[1m",
    "dim":      "\033[2m",
    "cyan":     "\033[36m",
}


# ─── model ────────────────────────────────────────────────────────────────────

class SentimentTransformer(nn.Module):
    """
    Reuses the same Transformer backbone.
    Replaces lm_head with a 3-class classifier on the [CLS] token.
    """
    def __init__(self, cfg: TransformerConfig, n_classes: int = 3):
        super().__init__()
        # backbone — everything except lm_head
        self.backbone = Transformer(cfg)
        self.backbone.head = nn.Identity()      # remove lm_head

        # classifier on top of [CLS] token (position 0)
        self.dropout  = nn.Dropout(0.1)
        self.cls_head = nn.Linear(cfg.dim, n_classes)

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        x   = self.backbone(tokens)          # [B, seq, dim]
        cls = x[:, 0, :]                     # [B, dim] — take [CLS] position
        return self.cls_head(self.dropout(cls))  # [B, n_classes]

    def n_params(self) -> str:
        n = sum(p.numel() for p in self.parameters())
        return f"{n/1e6:.2f}M" if n < 1e9 else f"{n/1e9:.2f}B"


# ─── dataset ──────────────────────────────────────────────────────────────────

class SentimentDataset(Dataset):
    def __init__(self, texts: list[str], labels: list[int],
                 tokenizer, max_len: int = 128):
        self.tokenizer = tokenizer
        self.max_len   = max_len
        self.labels    = labels
        self.texts     = texts

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        ids = self.tokenizer.encode(self.texts[idx])[:self.max_len]
        # pad to max_len
        pad = [0] * (self.max_len - len(ids))
        ids = ids + pad
        return (
            torch.tensor(ids,              dtype=torch.long),
            torch.tensor(self.labels[idx], dtype=torch.long),
        )


# ─── data loading ─────────────────────────────────────────────────────────────

def load_sentiment_data(tokenizer, max_len: int = 128, batch_size: int = 32):
    """
    Loads twitter-roberta-base-sentiment dataset from HuggingFace.
    Labels: 0=negative, 1=neutral, 2=positive
    """
    from datasets import load_dataset

    _section("🤗 Loading sentiment dataset")

    ds = load_dataset("cardiffnlp/tweet_eval", "sentiment")
    _info("dataset",  "cardiffnlp/tweet_eval (sentiment)")
    _info("train",    f"{len(ds['train']):,} samples")
    _info("val",      f"{len(ds['validation']):,} samples")
    _info("test",     f"{len(ds['test']):,} samples")
    _info("classes",  "0=negative  1=neutral  2=positive")

    def _make(split):
        texts  = ds[split]["text"]
        labels = ds[split]["label"]
        return SentimentDataset(texts, labels, tokenizer, max_len)

    train_dl = DataLoader(_make("train"),      batch_size=batch_size, shuffle=True)
    val_dl   = DataLoader(_make("validation"), batch_size=batch_size, shuffle=False)
    test_dl  = DataLoader(_make("test"),       batch_size=batch_size, shuffle=False)

    _ok("dataloaders ready")
    return train_dl, val_dl, test_dl


# ─── training ─────────────────────────────────────────────────────────────────

def train_sentiment(model, train_dl, val_dl, epochs: int = 5, lr: float = 3e-4):
    device    = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model     = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=lr,
        steps_per_epoch=len(train_dl), epochs=epochs
    )
    best_val_acc = 0.0

    _section(f"⚡ Training sentiment classifier — {model.n_params()}")
    _info("device",  str(device))
    _info("epochs",  str(epochs))
    _info("lr",      str(lr))
    _info("batches", str(len(train_dl)))

    for epoch in range(1, epochs + 1):
        # ── train ──────────────────────────────────────────
        model.train()
        total_loss, correct, total = 0, 0, 0

        for i, (x, y) in enumerate(train_dl):
            x, y = x.to(device), y.to(device)
            logits = model(x)
            loss   = F.cross_entropy(logits, y)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()

            total_loss += loss.item()
            correct    += (logits.argmax(-1) == y).sum().item()
            total      += y.size(0)

            # inline progress
            pct = (i + 1) / len(train_dl)
            bar = _bar(i + 1, len(train_dl))
            print(
                f"\r  epoch {epoch}/{epochs}  {bar}"
                f"  loss {COLORS['cyan']}{total_loss/(i+1):.4f}{COLORS['reset']}"
                f"  acc {COLORS['cyan']}{correct/total:.3f}{COLORS['reset']}",
                end="", flush=True
            )

        print()

        # ── val ────────────────────────────────────────────
        val_loss, val_acc, report = evaluate_sentiment(model, val_dl, device)
        saved = val_acc > best_val_acc
        if saved:
            best_val_acc = val_acc
            torch.save(model.state_dict(), "best_sentiment.pt")

        trophy = f"  {COLORS['bold']}{COLORS['cyan']}★ best{COLORS['reset']}" if saved else ""
        print(
            f"\n  {COLORS['bold']}● val{COLORS['reset']}"
            f"  loss {COLORS['cyan']}{val_loss:.4f}{COLORS['reset']}"
            f"  acc  {COLORS['bold']}{COLORS['cyan']}{val_acc:.4f}{COLORS['reset']}"
            f"{trophy}"
        )
        _print_report(report)

    print(f"\n  {COLORS['bold']}\033[32m✓ done{COLORS['reset']}  best_val_acc={COLORS['cyan']}{best_val_acc:.4f}{COLORS['reset']}\n")
    return model


# ─── evaluation ───────────────────────────────────────────────────────────────

@torch.no_grad()
def evaluate_sentiment(model, dl, device):
    model.eval()
    total_loss, correct, total = 0, 0, 0
    all_preds, all_labels      = [], []

    for x, y in dl:
        x, y   = x.to(device), y.to(device)
        logits = model(x)
        loss   = F.cross_entropy(logits, y)
        total_loss += loss.item()
        preds       = logits.argmax(-1)
        correct    += (preds == y).sum().item()
        total      += y.size(0)
        all_preds.extend(preds.cpu().tolist())
        all_labels.extend(y.cpu().tolist())

    # per-class report
    report = {}
    for label_id, label_name in ID2LAB.items():
        tp = sum(p == label_id and g == label_id for p, g in zip(all_preds, all_labels))
        fp = sum(p == label_id and g != label_id for p, g in zip(all_preds, all_labels))
        fn = sum(p != label_id and g == label_id for p, g in zip(all_preds, all_labels))
        precision = tp / max(tp + fp, 1)
        recall    = tp / max(tp + fn, 1)
        f1        = 2 * precision * recall / max(precision + recall, 1e-8)
        report[label_name] = {"precision": precision, "recall": recall, "f1": f1}

    model.train()
    return total_loss / len(dl), correct / total, report


# ─── inference ────────────────────────────────────────────────────────────────

@torch.no_grad()
def predict(model, tokenizer, texts: list[str], max_len: int = 128) -> list[dict]:
    device = next(model.parameters()).device
    model.eval()
    results = []

    for text in texts:
        ids    = tokenizer.encode(text)[:max_len]
        pad    = [0] * (max_len - len(ids))
        x      = torch.tensor([ids + pad], dtype=torch.long).to(device)
        logits = model(x)
        probs  = logits.softmax(-1)[0]
        pred   = probs.argmax().item()
        label  = ID2LAB[pred]
        color  = COLORS[label]
        print(
            f"  {color}{COLORS['bold']}{label:<10}{COLORS['reset']}"
            f"  {COLORS['dim']}neg={probs[0]:.2f}  neu={probs[1]:.2f}  pos={probs[2]:.2f}{COLORS['reset']}"
            f"  {COLORS['dim']}{text[:60]}{COLORS['reset']}"
        )
        results.append({"text": text, "label": label, "probs": probs.tolist()})
    return results


# ─── print helpers ────────────────────────────────────────────────────────────

def _section(t):
    print(f"\n\033[1m\033[36m{'─'*52}\033[0m")
    print(f"\033[1m\033[36m  {t}\033[0m")
    print(f"\033[1m\033[36m{'─'*52}\033[0m")

def _info(k, v): print(f"  \033[2m{k:<18}\033[0m \033[37m{v}\033[0m")
def _ok(msg):    print(f"  \033[32m✓\033[0m  {msg}")

def _bar(current, total, width=24):
    filled = int(width * current / max(total, 1))
    return f"\033[36m{'█'*filled}{'░'*(width-filled)}\033[0m"

def _print_report(report: dict):
    print(f"\n  {'':4}  {'precision':>10}  {'recall':>8}  {'f1':>8}")
    for label, m in report.items():
        color = COLORS[label]
        print(
            f"  {color}{COLORS['bold']}{label:<12}{COLORS['reset']}"
            f"  {m['precision']:>10.3f}"
            f"  {m['recall']:>8.3f}"
            f"  {m['f1']:>8.3f}"
        )
    print()




from transformer_toolkit import TransformerConfig
from transformer_toolkit.c_tokenizers import HFTokenizer
from sentiment import SentimentTransformer, load_sentiment_data, train_sentiment, predict

# tokenizer — use GPT2 for good coverage of tweets
tok = HFTokenizer("gpt2")

# data
train_dl, val_dl, test_dl = load_sentiment_data(tok, max_len=128, batch_size=32)

# model — small is fine for classification
cfg = TransformerConfig(
    vocab_size = tok.vocab_size,
    dim        = 256,
    n_layers   = 4,
    n_heads    = 4,
    n_kv_heads = 2,
    hidden_dim = 512,
    max_seq    = 128,
    attn       = "mha",
    ffn        = "ffn",
    norm       = "layernorm",
    pos_enc    = "learned",
    tie_weights = False,        # classification — no weight tying
)

model = SentimentTransformer(cfg, n_classes=3)
model = train_sentiment(model, train_dl, val_dl, epochs=5, lr=3e-4)

# inference
predict(model, tok, [
    "I absolutely loved this product, works perfectly!",
    "It was okay, nothing special.",
    "Terrible experience, would not recommend.",
    "Just received my order, pretty happy with it.",
])