import torch.nn as nn
import torch.nn.functional as F
import math

class MultiHeadAttention(nn.Module):
    """Classic MHA. Used in original Transformer, BERT, GPT-2."""
    def __init__(self, dim: int, n_heads: int):
        super().__init__()
        self.n_heads = n_heads
        self.head_dim = dim // n_heads
        self.qkv = nn.Linear(dim, 3 * dim, bias=False)
        self.out = nn.Linear(dim, dim, bias=False)

    def forward(self, x, mask=None):
        B, T, C = x.shape
        q, k, v = self.qkv(x).split(C, dim=-1)
        def split(t): return t.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        q, k, v = split(q), split(k), split(v)
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        if mask is not None: scores = scores.masked_fill(mask == 0, float('-inf'))
        return self.out(F.softmax(scores, -1) @ v).transpose(1, 2).reshape(B, T, C) # noqa


class GroupedQueryAttention(nn.Module):
    """Fewer k/v heads than q heads. Used in LLaMA 3, Mistral."""
    def __init__(self, dim: int, n_heads: int, n_kv_heads: int):
        super().__init__()
        self.n_heads    = n_heads
        self.n_kv_heads = n_kv_heads
        self.head_dim   = dim // n_heads
        self.q  = nn.Linear(dim, dim, bias=False)
        self.kv = nn.Linear(dim, 2 * n_kv_heads * self.head_dim, bias=False)
        self.out = nn.Linear(dim, dim, bias=False)

    def forward(self, x, mask=None):
        B, T, C = x.shape
        q = self.q(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        k, v = self.kv(x).split(self.n_kv_heads * self.head_dim, dim=-1)
        def split_kv(t): return t.view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)
        k, v = split_kv(k), split_kv(v)
        # repeat k/v to match q heads
        r = self.n_heads // self.n_kv_heads
        k = k.repeat_interleave(r, dim=1)
        v = v.repeat_interleave(r, dim=1)
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        if mask is not None: scores = scores.masked_fill(mask == 0, float('-inf'))
        return self.out((F.softmax(scores, -1) @ v).transpose(1, 2).reshape(B, T, C))


class MultiQueryAttention(nn.Module):
    """Single k/v head shared across all q heads. Used in Falcon, early Gemini."""
    def __init__(self, dim: int, n_heads: int):
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = dim // n_heads
        self.q  = nn.Linear(dim, dim, bias=False)
        self.k  = nn.Linear(dim, self.head_dim, bias=False)
        self.v  = nn.Linear(dim, self.head_dim, bias=False)
        self.out = nn.Linear(dim, dim, bias=False)

    def forward(self, x, mask=None):
        B, T, C = x.shape
        q = self.q(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k(x).view(B, T, 1, self.head_dim).transpose(1, 2).expand(B, self.n_heads, T, self.head_dim)
        v = self.v(x).view(B, T, 1, self.head_dim).transpose(1, 2).expand(B, self.n_heads, T, self.head_dim)
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        if mask is not None: scores = scores.masked_fill(mask == 0, float('-inf'))
        return self.out((F.softmax(scores, -1) @ v).transpose(1, 2).reshape(B, T, C))

class FlashAttention(nn.Module):
    """
    Flash Attention — same result as MHA, far less memory.
    Uses torch's built-in scaled_dot_product_attention (torch >= 2.0)
    which calls the CUDA kernel automatically when available.
    """
    def __init__(self, dim: int, n_heads: int):
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = dim // n_heads
        self.qkv = nn.Linear(dim, 3 * dim, bias=False)
        self.out = nn.Linear(dim, dim, bias=False)

    def forward(self, x, mask=None, causal=True):
        B, T, C = x.shape
        q, k, v = self.qkv(x).split(C, dim=-1)
        def split(t): return t.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        q, k, v = split(q), split(k), split(v)

        # one line — PyTorch handles the tiling/chunking kernel
        x = nn.functional.scaled_dot_product_attention(
            q, k, v,
            attn_mask=mask,
            is_causal=causal,       # builds causal mask internally, no extra memory
            dropout_p=0.0,
        )
        return self.out(x.transpose(1, 2).reshape(B, T, C))
    

class MLAttention(nn.Module):
    """
    Multi-Head Latent Attention (DeepSeek-V2/V3).
    Compresses k/v into a small latent vector instead of caching full k/v.
    Huge KV cache reduction at inference time.
    """
    def __init__(self, dim: int, n_heads: int, latent_dim: int):
        super().__init__()
        self.n_heads  = n_heads
        self.head_dim = dim // n_heads
        self.kv_down = nn.Linear(dim, latent_dim, bias=False)
        self.k_up    = nn.Linear(latent_dim, dim, bias=False)
        self.v_up    = nn.Linear(latent_dim, dim, bias=False)

        self.q       = nn.Linear(dim, dim, bias=False)
        self.out     = nn.Linear(dim, dim, bias=False)

    def forward(self, x, mask=None):
        B, T, C = x.shape

        q = self.q(x)

        # compress → this is what you cache at inference, not full k/v
        latent = self.kv_down(x)           # [B, T, latent_dim]

        k = self.k_up(latent)
        v = self.v_up(latent)

        def split(t): return t.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        q, k, v = split(q), split(k), split(v)

        x = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.out(x.transpose(1, 2).reshape(B, T, C))