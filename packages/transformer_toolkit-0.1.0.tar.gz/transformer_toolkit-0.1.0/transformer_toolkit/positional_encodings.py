import torch
import torch.nn as nn
import math


class SinusoidalPE(nn.Module):
    """Original 'Attention is All You Need' encoding. No parameters."""
    def __init__(self, dim: int, max_seq: int = 4096):
        super().__init__()
        pe = torch.zeros(max_seq, dim)
        pos = torch.arange(max_seq).unsqueeze(1).float()
        div = torch.exp(torch.arange(0, dim, 2).float() * (-math.log(10000.0) / dim))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe)

    def forward(self, x):
        # x: [batch, seq, dim]
        return x + self.pe[:x.shape[1]]


class LearnedPE(nn.Module):
    """Trainable position embeddings. Used in BERT, GPT-2."""
    def __init__(self, dim: int, max_seq: int = 4096):
        super().__init__()
        self.pe = nn.Embedding(max_seq, dim)

    def forward(self, x):
        pos = torch.arange(x.shape[1], device=x.device)
        return x + self.pe(pos)


class RoPE(nn.Module):
    """Rotary. Used in LLaMA, Mistral, Qwen."""
    def __init__(self, dim: int, base: int = 10000):
        super().__init__()
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq)

    def forward(self, x):
        t = torch.arange(x.shape[1], device=x.device).float()
        freqs = torch.outer(t, self.inv_freq)
        emb = torch.cat([freqs, freqs], dim=-1)
        return x * emb.cos() + self._rotate_half(x) * emb.sin()

    @staticmethod
    def _rotate_half(x):
        x1, x2 = x.chunk(2, dim=-1)
        return torch.cat([-x2, x1], dim=-1)


class ALiBi(nn.Module):
    """Attention with Linear Biases. No positional vectors — biases the attention scores directly."""
    def __init__(self, n_heads: int):
        super().__init__()
        slopes = 2 ** (-8 * torch.arange(1, n_heads + 1) / n_heads)
        self.register_buffer("slopes", slopes)

    def forward(self, seq_len: int, device):
        # returns bias to ADD to attention logits: [n_heads, seq, seq]
        pos = torch.arange(seq_len, device=device)
        dist = pos.unsqueeze(0) - pos.unsqueeze(1)          # relative distances
        return self.slopes[:, None, None] * dist.abs().unsqueeze(0) * -1