import torch
import torch.nn as nn
import torch.nn.functional as F


class FFN(nn.Module):
    """Standard FFN. Used in original Transformer, BERT."""
    def __init__(self, dim: int, hidden: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, dim)
        )

    def forward(self, x):
        return self.net(x)


class SwiGLU(nn.Module):
    """Gated FFN with Swish. Used in LLaMA, Mistral, PaLM."""
    def __init__(self, dim: int, hidden: int):
        super().__init__()
        self.w1 = nn.Linear(dim, hidden, bias=False)
        self.w2 = nn.Linear(hidden, dim, bias=False)
        self.w3 = nn.Linear(dim, hidden, bias=False)

    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class MoE(nn.Module):
    """Mixture of Experts. Used in Mixtral, GPT-4 (rumoured)."""
    def __init__(self, dim: int, hidden: int, n_experts: int, top_k: int = 2):
        super().__init__()
        self.top_k   = top_k
        self.gate    = nn.Linear(dim, n_experts, bias=False)
        self.experts = nn.ModuleList([SwiGLU(dim, hidden) for _ in range(n_experts)])

    def forward(self, x):
        B, T, C = x.shape
        x_flat  = x.view(-1, C)
        weights, idx = self.gate(x_flat).topk(self.top_k, dim=-1)   # [B*T, top_k]
        weights = F.softmax(weights, dim=-1)
        out = torch.zeros_like(x_flat)
        for i, expert in enumerate(self.experts):
            mask = (idx == i).any(dim=-1)
            if mask.any():
                w = weights[mask][idx[mask] == i].unsqueeze(-1)
                out[mask] += w * expert(x_flat[mask])
        return out.view(B, T, C)
