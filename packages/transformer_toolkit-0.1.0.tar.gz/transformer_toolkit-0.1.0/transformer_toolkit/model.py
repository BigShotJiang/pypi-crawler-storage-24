import torch
import torch.nn as nn
from dataclasses import dataclass, field
from typing import Literal

from attention import MultiHeadAttention, GroupedQueryAttention, MultiQueryAttention, FlashAttention, MLAttention
from feed_forward import FFN, SwiGLU, MoE
from normalization import LayerNorm, RMSNorm
from positional_encodings import RoPE, SinusoidalPE, LearnedPE, ALiBi
from block import TransformerBlock


# ─── config ───────────────────────────────────────────────────────────────────

@dataclass
class TransformerConfig:
    # core
    vocab_size: int   = 32000
    dim:        int   = 512
    n_layers:   int   = 8
    n_heads:    int   = 8
    max_seq:    int   = 2048

    # attention
    attn:       Literal["mha", "gqa", "mqa", "flash", "mla"] = "gqa"
    n_kv_heads: int   = 4        # gqa only
    latent_dim: int   = 64       # mla only

    # ffn
    ffn:        Literal["ffn", "swiglu", "moe"] = "swiglu"
    hidden_dim: int   = None     # defaults to dim * 4
    n_experts:  int   = 8        # moe only
    top_k:      int   = 2        # moe only

    # normalization
    norm:       Literal["rmsnorm", "layernorm"] = "rmsnorm"
    eps:        float = 1e-6

    # positional encoding
    pos_enc:    Literal["rope", "sinusoidal", "learned", "alibi", "none"] = "rope"

    # output
    tie_weights: bool = True     # share embed + output weights

    def __post_init__(self):
        if self.hidden_dim is None:
            self.hidden_dim = self.dim * 4


# ─── registry ─────────────────────────────────────────────────────────────────

def build_attn(cfg: TransformerConfig) -> nn.Module:
    match cfg.attn:
        case "mha":   return MultiHeadAttention(cfg.dim, cfg.n_heads)
        case "gqa":   return GroupedQueryAttention(cfg.dim, cfg.n_heads, cfg.n_kv_heads)
        case "mqa":   return MultiQueryAttention(cfg.dim, cfg.n_heads)
        case "flash": return FlashAttention(cfg.dim, cfg.n_heads)
        case "mla":   return MLAttention(cfg.dim, cfg.n_heads, cfg.latent_dim)
        case _:       raise ValueError(f"unknown attn: {cfg.attn}")

def build_ffn(cfg: TransformerConfig) -> nn.Module:
    match cfg.ffn:
        case "ffn":    return FFN(cfg.dim, cfg.hidden_dim)
        case "swiglu": return SwiGLU(cfg.dim, cfg.hidden_dim)
        case "moe":    return MoE(cfg.dim, cfg.hidden_dim, cfg.n_experts, cfg.top_k)
        case _:        raise ValueError(f"unknown ffn: {cfg.ffn}")

def build_norm(cfg: TransformerConfig) -> nn.Module:
    match cfg.norm:
        case "rmsnorm":   return RMSNorm(cfg.dim, cfg.eps)
        case "layernorm": return LayerNorm(cfg.dim, cfg.eps)
        case _:           raise ValueError(f"unknown norm: {cfg.norm}")

def build_pos_enc(cfg: TransformerConfig) -> nn.Module | None:
    match cfg.pos_enc:
        case "rope":       return RoPE(cfg.dim)
        case "sinusoidal": return SinusoidalPE(cfg.dim, cfg.max_seq)
        case "learned":    return LearnedPE(cfg.dim, cfg.max_seq)
        case "alibi":      return ALiBi(cfg.n_heads)
        case "none":       return None
        case _:            raise ValueError(f"unknown pos_enc: {cfg.pos_enc}")


# ─── model ────────────────────────────────────────────────────────────────────

class Transformer(nn.Module):
    def __init__(self, cfg: TransformerConfig):
        super().__init__()
        self.cfg     = cfg
        self.embed   = nn.Embedding(cfg.vocab_size, cfg.dim)
        self.pos_enc = build_pos_enc(cfg)
        self.blocks  = nn.ModuleList([
            TransformerBlock(
                dim     = cfg.dim,
                n_heads = cfg.n_heads,
                hidden  = cfg.hidden_dim,
                norm    = build_norm(cfg),
                attn    = build_attn(cfg),
                ffn     = build_ffn(cfg),
            )
            for _ in range(cfg.n_layers)
        ])
        self.norm = build_norm(cfg)
        self.head = nn.Linear(cfg.dim, cfg.vocab_size, bias=False)

        if cfg.tie_weights:
            self.head.weight = self.embed.weight

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        x = self.embed(tokens)
        if self.pos_enc and not isinstance(self.pos_enc, ALiBi):
            x = self.pos_enc(x)
        for block in self.blocks:
            x = block(x)
        return self.head(self.norm(x))

    @torch.no_grad()
    def generate(self, tokens: torch.Tensor, max_new: int = 10, temperature: float = 1.0) -> torch.Tensor:
        for _ in range(max_new):
            logits = self.forward(tokens)[:, -1, :] / temperature
            tokens = torch.cat([tokens, logits.softmax(-1).multinomial(1)], dim=-1)
        return tokens

    def n_params(self) -> str:
        n = sum(p.numel() for p in self.parameters())
        return f"{n/1e6:.2f}M" if n < 1e9 else f"{n/1e9:.2f}B"

    