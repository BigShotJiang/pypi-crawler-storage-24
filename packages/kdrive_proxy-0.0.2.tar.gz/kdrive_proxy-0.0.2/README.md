# kDrive Proxy

A Micro proxy for uploading to [kDrive drop boxes](https://www.infomaniak.com/en/support/faq/2386/manage-kdrive-drop-boxes) with a simple POST call, using [kdrive-uploader](https://github.com/olivierdalang/kdrive-uploader).

## Quickstart

First install with `pip` then run:

```bash
pip install kdrive-proxy

# run the server
kdrive-proxy run --host 0.0.0.0 --port 80
```

You can also run it directly using `uv`:

```bash
uvx kdrive-proxy --help
```

Or with docker (still using `uv`):

```bash
docker run --rm --workdir /io -v .:/io -v uv-cache:/root/ ghcr.io/astral-sh/uv:alpine uvx kdrive-proxy --help
```

## Dev quickstart

```bash
# create dev env
uv sync --dev

# install prek (git hooks manager)
uv run prek install

# run from source
fastapi dev --entrypoint kdrive_proxy:app

# test a request
curl -X POST http://localhost:8000/0000000/00000000-0000-0000-0000-000000000000/README.md --data-binary '@README.md'
```
