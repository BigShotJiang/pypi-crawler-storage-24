import sys
import tempfile
from datetime import datetime
from pathlib import Path
from uuid import UUID

import kdrive_uploader
from fastapi import FastAPI, Request

app = FastAPI()


@app.post("/{kdrive_id}/{depot_uuid}/{path:path}")
async def read_item(
    request: Request,
    kdrive_id: int,
    depot_uuid: UUID,
    path: Path,
    suffix_date: bool = True,
    last_name: str = "kdrive",
    first_name: str = "uploader",
    email: str = "kdrive-uploader@ik.me",
):
    with tempfile.TemporaryDirectory(delete=False) as tmp_dir:
        if suffix_date:
            path = path.with_stem(f"{path.stem}-{datetime.now():%Y-%m-%d-%H-%M-%S}")
        final_path = Path(tmp_dir).joinpath(path)
        final_path.parent.mkdir(parents=True, exist_ok=True)
        final_path.write_bytes(await request.body())
        kdrive_uploader.main(
            f"{kdrive_id}/{depot_uuid}",
            Path(tmp_dir),
            last_name=last_name,
            first_name=first_name,
            email=email,
        )
    return "success"


def cli():
    import fastapi_cli.cli

    args = sys.argv[1:]
    if args and not args[0].startswith("-"):
        args = [
            args[0],
            "--entrypoint",
            "kdrive_proxy:app",
            *args[1:],
        ]

    fastapi_cli.cli.app(args, standalone_mode=False)
