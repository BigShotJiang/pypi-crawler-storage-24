#!/usr/bin/env python3
"""
axel/mcp_server.py — AXEL MCP Server
══════════════════════════════════════
Exposes AXEL as a Model Context Protocol (MCP) server so Claude Desktop,
Cursor, Windsurf, and any other MCP-compatible client can use AXEL
directly — without leaving the editor.

Usage
─────
  axel mcp                              # stdio MCP server (default)
  axel mcp --server http://myhost:7331  # custom AXEL server URL
  python -m axel.mcp_server             # same

Claude Desktop config
─────────────────────
Edit ~/Library/Application Support/Claude/claude_desktop_config.json:

  {
    "mcpServers": {
      "axel": {
        "command": "axel",
        "args": ["mcp"],
        "env": {
          "AXEL_SERVER": "http://localhost:7331"
        }
      }
    }
  }

Available MCP tools
───────────────────
  axel_status          — Server health, agent count, memory stats
  axel_list_agents     — All registered agents with capabilities + scores
  axel_query_memory    — Full-text search of shared SmartMemory lessons
  axel_run_task        — Queue a one-off task through the 8-agent pipeline
  axel_get_latest_run  — Fetch the most recent pipeline run output
  axel_add_topic       — Add a topic to the recurring learning rotation
  axel_list_topics     — See all topics in the library
  axel_webhook_set     — Configure a webhook URL for run.complete events
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from typing import Any, Optional


# ── MCP SDK auto-install ─────────────────────────────────────────────────────

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    import subprocess
    print("  Installing mcp[cli]…", flush=True)
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", "mcp[cli]",
         "--break-system-packages", "-q"],
        stdout=subprocess.DEVNULL,
    )
    from mcp.server.fastmcp import FastMCP


# ── Config ───────────────────────────────────────────────────────────────────

DEFAULT_SERVER = os.environ.get("AXEL_SERVER", "http://localhost:7331")
DEFAULT_KEY    = os.environ.get("AXEL_KEY", "")

mcp = FastMCP(
    name="axel-protocol",
    instructions=(
        "You are connected to an AXEL multi-agent network. "
        "Use axel_status to check the network, axel_run_task to kick off a "
        "pipeline run, and axel_query_memory to search lessons the agents have "
        "learned. axel_list_agents shows which agents are online and what they do."
    ),
)


# ── HTTP helper ──────────────────────────────────────────────────────────────

def _call(
    method: str,
    path: str,
    body: Optional[dict] = None,
    server: str = DEFAULT_SERVER,
    key: str = DEFAULT_KEY,
    timeout: int = 15,
) -> Any:
    url = server.rstrip("/") + path
    data = json.dumps(body).encode() if body is not None else None
    headers: dict = {"Content-Type": "application/json", "Accept": "application/json"}
    if key:
        headers["X-AXEL-Key"] = key
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode()).get("detail", str(e))
        except Exception:
            detail = str(e)
        return {"error": f"HTTP {e.code}: {detail}"}
    except urllib.error.URLError as e:
        return {
            "error": f"Cannot reach AXEL server at {server}: {e.reason}. "
                     "Is it running? Try: axel-server"
        }
    except Exception as e:
        return {"error": str(e)}


# ── MCP Tools ────────────────────────────────────────────────────────────────

@mcp.tool()
def axel_status(server_url: str = DEFAULT_SERVER) -> dict:
    """Get AXEL network status: version, uptime, agent count, memory lesson count,
    and whether auth / persistence are enabled.

    Args:
        server_url: Base URL of the AXEL server (default: http://localhost:7331)
    """
    return _call("GET", "/status", server=server_url)


@mcp.tool()
def axel_list_agents(server_url: str = DEFAULT_SERVER) -> dict:
    """List all agents registered on the AXEL network, with their capabilities,
    assigned model, task count, score, and online/offline status.

    Args:
        server_url: Base URL of the AXEL server
    """
    return _call("GET", "/agents", server=server_url)


@mcp.tool()
def axel_query_memory(
    query: str,
    top_n: int = 10,
    server_url: str = DEFAULT_SERVER,
) -> dict:
    """Search the AXEL shared SmartMemory for lessons agents have learned.
    Uses BM25 full-text search. Returns matching lessons with key, insight,
    source agent, confidence score, and decay factor.

    Args:
        query:      Search terms (e.g. "code review", "writing style")
        top_n:      Maximum number of results to return (default: 10)
        server_url: Base URL of the AXEL server
    """
    import urllib.parse
    q = urllib.parse.quote(query)
    return _call("GET", f"/memory/search?q={q}&n={top_n}", server=server_url)


@mcp.tool()
def axel_list_memory(
    top_n: int = 20,
    server_url: str = DEFAULT_SERVER,
) -> dict:
    """Return the most recent lessons from AXEL shared SmartMemory, ordered by
    confidence × recency. Good for reviewing what the agents have learned so far.

    Args:
        top_n:      Maximum number of lessons to return (default: 20)
        server_url: Base URL of the AXEL server
    """
    return _call("GET", f"/memory?top={top_n}", server=server_url)


@mcp.tool()
def axel_run_task(
    task: str,
    server_url: str = DEFAULT_SERVER,
) -> dict:
    """Queue a one-off task to run through the AXEL 8-agent pipeline.
    The pipeline (planner → researcher → analyst → fact-checker → writer →
    devil-advocate → summarizer → reviewer) will pick it up on the next cycle.
    Use axel_get_latest_run to retrieve the output once the run completes.

    Args:
        task:       The task or question for the agents, e.g.
                    "Write a due-diligence summary on Anthropic's Claude products"
                    "Review this Python function for security issues: def login(user, pw): ..."
        server_url: Base URL of the AXEL server
    """
    return _call("POST", "/queue", body={"task": task}, server=server_url)


@mcp.tool()
def axel_get_latest_run(server_url: str = DEFAULT_SERVER) -> dict:
    """Retrieve the output of the most recent completed AXEL pipeline run.
    Returns topic, TL;DR summary, full draft, reviewer score, and timestamp.
    Returns an empty result if no run has completed yet this session.

    Args:
        server_url: Base URL of the AXEL server
    """
    # The latest run output is stored in the server's SSE history under run.complete
    # We fetch the last few events and find the most recent run.complete
    data = _call("GET", "/stream/history?n=50", server=server_url)
    if "error" in data:
        # /stream/history doesn't exist — fall back to status
        return {"note": "No run history available yet. Run axel_run_task first."}
    events = data if isinstance(data, list) else data.get("events", [])
    for ev in reversed(events):
        if ev.get("event") == "run.complete":
            return ev.get("data", {})
    return {"note": "No completed run found yet. Use axel_run_task to start one."}


@mcp.tool()
def axel_add_topic(
    topic: str,
    server_url: str = DEFAULT_SERVER,
) -> dict:
    """Add a topic to the AXEL recurring learning rotation. Agents will explore
    this topic on future pipeline runs instead of (or alongside) built-in topics.

    Args:
        topic:      Topic for agents to research, e.g.
                    "Competitive analysis of OpenAI vs Anthropic vs Google"
                    "Best practices for LLM prompt engineering in 2025"
        server_url: Base URL of the AXEL server
    """
    return _call("POST", "/topics", body={"topic": topic}, server=server_url)


@mcp.tool()
def axel_list_topics(server_url: str = DEFAULT_SERVER) -> dict:
    """Return all topics currently in the AXEL learning rotation library.
    If empty, agents use the built-in topic rotation.

    Args:
        server_url: Base URL of the AXEL server
    """
    return _call("GET", "/topics", server=server_url)


@mcp.tool()
def axel_webhook_set(
    webhook_url: str,
    server_url: str = DEFAULT_SERVER,
) -> dict:
    """Configure a webhook URL to receive AXEL run.complete notifications.
    After each pipeline run, AXEL will POST the run output (topic, summary,
    draft, review, score, timestamp) to this URL. Works with Slack incoming
    webhooks, Zapier, Make, n8n, Notion API, or any HTTP endpoint.
    Pass an empty string to disable the webhook.

    Args:
        webhook_url: Target URL, e.g. "https://hooks.slack.com/services/..."
                     or "" to disable
        server_url:  Base URL of the AXEL server
    """
    return _call(
        "POST", "/config/webhook",
        body={"url": webhook_url},
        server=server_url,
    )


@mcp.tool()
def axel_discover_agent(
    capability: str,
    server_url: str = DEFAULT_SERVER,
) -> dict:
    """Find the best-suited AXEL agent for a given capability or task type.
    Uses the agent registry's scoring system.

    Args:
        capability: What you need, e.g. "code_review", "summarize", "fact_check"
        server_url: Base URL of the AXEL server
    """
    import urllib.parse
    cap = urllib.parse.quote(capability)
    return _call("GET", f"/discover?cap={cap}", server=server_url)


# ── Entry point ──────────────────────────────────────────────────────────────

def main(server_url: Optional[str] = None):
    """Start the AXEL MCP stdio server."""
    if server_url:
        # Patch the default so all tools point to the right server
        import axel.mcp_server as _self
        _self.DEFAULT_SERVER = server_url

    print(
        f"  🔌  AXEL MCP Server ready\n"
        f"  Connected to: {DEFAULT_SERVER}\n"
        f"  Tools: axel_status, axel_list_agents, axel_query_memory, axel_list_memory,\n"
        f"         axel_run_task, axel_get_latest_run, axel_add_topic, axel_list_topics,\n"
        f"         axel_webhook_set, axel_discover_agent\n",
        file=sys.stderr, flush=True,
    )
    mcp.run(transport="stdio")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="AXEL MCP Server")
    p.add_argument(
        "--server",
        default=os.environ.get("AXEL_SERVER", "http://localhost:7331"),
        help="AXEL server URL",
    )
    a = p.parse_args()
    main(server_url=a.server)
