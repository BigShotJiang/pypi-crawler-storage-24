"""
axel/cli.py — Command-line interface for the AXEL network.

Entry point: ``axel``

Sub-commands
------------
  axel setup                        Interactive API key setup wizard
  axel status                       Show server status & agent count
  axel agents                       List all registered agents
  axel send <to> <action> [opts]    Send a TASK message
  axel memory search <query>        Search shared memory
  axel memory list                  List all lessons
  axel discover <capability>        Find the best agent for a capability
  axel monitor                      Open the dashboard in a browser
  axel models [--free]              List available OpenRouter models

Global flags
------------
  --server URL    Server base URL (default: http://localhost:7331 or
                  $AXEL_SERVER env var)
  --key KEY       API key (default: $AXEL_KEY env var)
  --json          Output raw JSON (machine-readable)

Examples
--------
  axel setup
  axel status
  axel agents
  axel send writer draft_content --args '{"topic": "AI safety"}'
  axel memory search "multi-hop queries"
  axel discover code_review
  axel monitor
  axel models --free
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request as _ur
import urllib.error
from pathlib import Path
from typing import Any, Optional


# ──────────────────────────────────────────────────────────────────────────────
# HTTP helper
# ──────────────────────────────────────────────────────────────────────────────

def _req(
    method: str,
    url: str,
    body: Optional[dict] = None,
    key: Optional[str] = None,
    timeout: int = 10,
) -> Any:
    data = json.dumps(body).encode() if body is not None else None
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if key:
        headers["X-AXEL-Key"] = key
    req = _ur.Request(url, data=data, headers=headers, method=method)
    try:
        with _ur.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode()).get("detail", str(e))
        except Exception:
            detail = str(e)
        print(f"Error {e.code}: {detail}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"Cannot connect to server: {e.reason}", file=sys.stderr)
        print("Is the AXEL server running? Try: axel-server", file=sys.stderr)
        sys.exit(1)


# ──────────────────────────────────────────────────────────────────────────────
# Formatters
# ──────────────────────────────────────────────────────────────────────────────

def _fmt_json(data: Any) -> str:
    return json.dumps(data, indent=2)


def _status_table(data: dict) -> str:
    lines = [
        f"  AXEL Server  {data.get('version', '?')}",
        f"  Agents      {data['agents']['count']}",
        f"  Uptime      {data.get('uptime_s', 0):.0f}s",
        f"  Memory      {data.get('memory', {}).get('count', 0)} lessons",
        f"  Auth        {'enabled' if data.get('auth') else 'disabled'}",
    ]
    if data.get("db"):
        lines.append(f"  DB          {data['db']}")
    return "\n".join(lines)


def _agents_table(agents: list) -> str:
    if not agents:
        return "  (no agents registered)"
    rows = []
    for a in agents:
        aid   = a.get("agent_id") or a.get("agent") or "?"
        model = a.get("model", "?")[:20]
        score = a.get("score", 0)
        tasks = a.get("tasks_done", 0)
        caps  = ", ".join(a.get("caps") or [])[:40]
        online = "●" if a.get("online", True) else "○"
        rows.append(f"  {online} {aid:<20} {model:<22} score={score:<6.1f} tasks={tasks:<5} [{caps}]")
    return "\n".join(rows)


def _memory_table(lessons: list) -> str:
    if not lessons:
        return "  (no lessons in memory)"
    rows = []
    for l in lessons:
        key   = str(l.get("key", "?"))[:20]
        conf  = l.get("confidence", 0)
        insight = str(l.get("insight", ""))[:60]
        rows.append(f"  [{key:<20}] conf={conf:.2f}  {insight}")
    return "\n".join(rows)


# ──────────────────────────────────────────────────────────────────────────────
# Sub-command implementations
# ──────────────────────────────────────────────────────────────────────────────

def cmd_status(args):
    data = _req("GET", f"{args.server}/status", key=args.key)
    if args.json:
        print(_fmt_json(data))
    else:
        print(_status_table(data))


def cmd_agents(args):
    data = _req("GET", f"{args.server}/agents", key=args.key)
    agents = data.get("agents", [])
    if args.json:
        print(_fmt_json(agents))
    else:
        print(f"Agents ({len(agents)}):")
        print(_agents_table(agents))


def cmd_send(args):
    import uuid as _uuid
    body = {
        "v":   "1",
        "t":   "TK",
        "id":  f"msg_{_uuid.uuid4().hex[:12]}",
        "cid": f"cnv_{_uuid.uuid4().hex[:12]}",
        "fr":  args.from_agent or "axel-cli",
        "to":  args.to,
        "ts":  int(__import__("time").time() * 1000),
        "pri": args.priority,
        "body": {
            "act":  args.action,
            "args": json.loads(args.args) if args.args else {},
        },
    }
    if args.ttl:
        body["ttl"] = args.ttl

    data = _req("POST", f"{args.server}/send", body=body, key=args.key)
    if args.json:
        print(_fmt_json(data))
    else:
        status = "queued" if data.get("ok") else "failed"
        print(f"  Message {body['id']} → {args.to}  [{status}]")
        if data.get("recipients"):
            print(f"  Delivered to: {data['recipients']}")


def cmd_memory_search(args):
    data = _req(
        "GET",
        f"{args.server}/memory/search?q={_ur_quote(args.query)}&n={args.n}",
        key=args.key,
    )
    lessons = data.get("results", [])
    if args.json:
        print(_fmt_json(lessons))
    else:
        print(f"Memory search: '{args.query}'  ({len(lessons)} results)")
        print(_memory_table(lessons))


def cmd_memory_list(args):
    data = _req(
        "GET",
        f"{args.server}/memory?top={args.top}",
        key=args.key,
    )
    lessons = data.get("lessons", data.get("results", []))
    if args.json:
        print(_fmt_json(lessons))
    else:
        print(f"Shared memory ({len(lessons)} lessons):")
        print(_memory_table(lessons))


def cmd_discover(args):
    data = _req(
        "GET",
        f"{args.server}/discover?cap={_ur_quote(args.capability)}",
        key=args.key,
    )
    if args.json:
        print(_fmt_json(data))
    else:
        best = data.get("best")
        if best:
            score   = data.get("score", 0)
            caps    = ", ".join(data.get("caps", []))
            print(f"  Best agent for '{args.capability}': {best}")
            print(f"  Score: {score:.1f}  Capabilities: {caps}")
        else:
            print(f"  No agent found for capability '{args.capability}'")


def cmd_models(args):
    """List models available on OpenRouter (optionally filtered to free tier)."""
    try:
        from axel.universal import OpenRouterAdapter
        key = os.environ.get("OPENROUTER_API_KEY") or _load_config().get("OPENROUTER_API_KEY")
        models = OpenRouterAdapter.list_models(key=key, free_only=getattr(args, "free", False))
    except Exception as exc:
        _die(f"Could not fetch models: {exc}")
        return

    if getattr(args, "json", False):
        print(json.dumps(models, indent=2))
        return

    if not models:
        print("No models found.")
        return

    print(f"\n{'MODEL ID':<52} {'CONTEXT':>8}  PRICING (per 1M tok)")
    print("─" * 80)
    for m in sorted(models, key=lambda x: x["id"]):
        ctx    = f"{m['context_length'] // 1000}k" if m["context_length"] else "?"
        pr_in  = m["pricing"].get("prompt",     "?")
        pr_out = m["pricing"].get("completion", "?")
        try:
            pr_in  = f"${float(pr_in)  * 1_000_000:.2f}" if float(pr_in)  else "free"
            pr_out = f"${float(pr_out) * 1_000_000:.2f}" if float(pr_out) else "free"
        except (TypeError, ValueError):
            pr_in = pr_out = "?"
        print(f"  {m['id']:<50} {ctx:>8}  in:{pr_in}  out:{pr_out}")
    print(f"\n{len(models)} model(s) listed. Sign up free at https://openrouter.ai\n")


# ──────────────────────────────────────────────────────────────────────────────
# Setup wizard
# ──────────────────────────────────────────────────────────────────────────────

_CONFIG_FILE = Path.home() / ".axel" / "config.json"


def _load_config() -> dict:
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_config(cfg: dict) -> None:
    _CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def _test_openrouter_key(key: str) -> bool:
    """Returns True if the key works (lists at least one model)."""
    try:
        import urllib.request as _req
        req = _req.Request(
            "https://openrouter.ai/api/v1/models",
            headers={"Authorization": f"Bearer {key}"},
        )
        with _req.urlopen(req, timeout=8) as r:
            data = json.loads(r.read())
        return bool(data.get("data"))
    except Exception:
        return False


def _test_provider_key(provider: str, key: str) -> bool:
    """Quick smoke-test for Anthropic / OpenAI keys."""
    try:
        if provider == "anthropic":
            import urllib.request as _req
            req = _req.Request(
                "https://api.anthropic.com/v1/models",
                headers={"x-api-key": key, "anthropic-version": "2023-06-01"},
            )
            with _req.urlopen(req, timeout=8) as r:
                return r.status == 200
        elif provider == "openai":
            import urllib.request as _req
            req = _req.Request(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {key}"},
            )
            with _req.urlopen(req, timeout=8) as r:
                return r.status == 200
    except Exception:
        pass
    return False


def cmd_setup(args):  # noqa: C901
    """Interactive setup wizard — configure API keys and save to ~/.axel/config.json."""
    cfg = _load_config()

    print("\n" + "═" * 60)
    print("  AXEL Setup Wizard")
    print("═" * 60)
    print("\nThis wizard configures your API keys for LLM providers.")
    print("Keys are saved to ~/.axel/config.json\n")

    # ── Ask which path ────────────────────────────────────────────
    print("  OpenRouter gives you access to 100+ models with one free key.")
    print("  Get yours at: https://openrouter.ai\n")
    use_or = input("  Are you using OpenRouter? [Y/n]: ").strip().lower()
    use_openrouter = use_or in ("", "y", "yes")

    if use_openrouter:
        # ── OpenRouter only ───────────────────────────────────────
        existing_or = cfg.get("OPENROUTER_API_KEY", os.environ.get("OPENROUTER_API_KEY", ""))
        if existing_or:
            hint = existing_or[:8] + "…" + existing_or[-4:]
            print(f"\n  Current key: {hint}")
            inp = input("  New key (press Enter to keep current): ").strip()
            or_key = inp or existing_or
        else:
            or_key = input("\n  Paste your OpenRouter key: ").strip()

        if or_key:
            print("  Testing key…", end=" ", flush=True)
            if _test_openrouter_key(or_key):
                print("✓ Valid!")
            else:
                print("✗ Could not verify — saved anyway (check your key).")
            cfg["OPENROUTER_API_KEY"] = or_key

    else:
        # ── Individual provider keys ──────────────────────────────
        print("\n  Enter your individual provider keys below.")
        print("  Press Enter to skip any you don't have.\n")

        providers = [
            ("Anthropic (Claude)",  "ANTHROPIC_API_KEY",  "https://console.anthropic.com",  "anthropic"),
            ("OpenAI (GPT)",        "OPENAI_API_KEY",      "https://platform.openai.com",    "openai"),
            ("Google (Gemini)",     "GOOGLE_API_KEY",      "https://aistudio.google.com",    None),
        ]

        for label, env_var, url, test_provider in providers:
            existing = cfg.get(env_var, os.environ.get(env_var, ""))
            hint     = (existing[:8] + "…" + existing[-4:]) if existing else "not set"
            print(f"  {label} — {url}")
            print(f"  Current: {hint}")
            inp = input(f"  Paste key (Enter to skip): ").strip()
            if inp:
                if test_provider:
                    print("  Testing…", end=" ", flush=True)
                    ok = _test_provider_key(test_provider, inp)
                    print("✓ Valid!" if ok else "✗ Could not verify — saved anyway.")
                cfg[env_var] = inp
            elif existing:
                cfg[env_var] = existing
            print()

    # ── Save ──────────────────────────────────────────────────────
    _save_config(cfg)
    print(f"\n  ✓ Config saved to {_CONFIG_FILE}")

    # Print export snippet
    print("\n  To export keys in your shell session, run:\n")
    for k, v in cfg.items():
        if k.endswith("_KEY") or k.endswith("_API_KEY"):
            masked = v[:8] + "…" if len(v) > 8 else v
            print(f"    export {k}={masked}")
    print()

    # Suggest next steps
    if cfg.get("OPENROUTER_API_KEY"):
        print("  Next steps:")
        print("    axel-server &          # start the AXEL server")
        print("    axel status            # verify it's running")
        print("    axel models --free     # browse free models")
        print()
    elif not any(cfg.get(k) for k in ["ANTHROPIC_API_KEY", "OPENAI_API_KEY"]):
        print("  ⚠  No API keys configured. Visit https://openrouter.ai for a")
        print("     free key that unlocks all major LLMs at once.\n")


def _fire_task(server: str, fr: str, to: str, action: str, body: dict) -> None:
    """POST an AXEL TASK message through the server so SSE/dashboard sees it."""
    import json as _json
    import urllib.request as _ur
    import uuid as _uuid
    msg = {
        "t": "TASK", "v": "2.1",
        "id": str(_uuid.uuid4()),
        "fr": fr, "to": to,
        "action": action,
        "body": body,
    }
    data = _json.dumps(msg).encode()
    req = _ur.Request(
        f"{server}/send",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        _ur.urlopen(req, timeout=5)
    except Exception:
        pass  # demo continues even if event fire fails


def _fire_progress(server: str, run: int, step: int, total: int, agent: str, action: str) -> None:
    """Broadcast pipeline progress so the dashboard can show a step indicator."""
    import json as _json
    import urllib.request as _ur
    import uuid as _uuid
    msg = {
        "t": "PROG", "v": "2.1",
        "id": str(_uuid.uuid4()),
        "fr": "axel-demo", "to": "dashboard",
        "body": {"run": run, "step": step, "total": total,
                 "agent": agent, "action": action},
    }
    data = _json.dumps(msg).encode()
    req = _ur.Request(f"{server}/send", data=data,
                      headers={"Content-Type": "application/json"}, method="POST")
    try:
        _ur.urlopen(req, timeout=3)
    except Exception:
        pass


def _fire_run_complete(server: str, run: int, topic: str,
                       summary: str, draft: str, review: str) -> None:
    """Broadcast an RC (Run Complete) message so the dashboard can show the pipeline output."""
    import json as _json
    import urllib.request as _ur
    import uuid as _uuid
    # Strip "[X skipped]" placeholders produced when all fallbacks exhaust
    def _ok(s: str) -> str:
        return (s or '') if not ('[' in (s or '') and 'skipped' in (s or '')) else ''
    msg = {
        "t": "RC", "v": "2.1",
        "id": str(_uuid.uuid4()),
        "fr": "axel-demo", "to": "dashboard",
        "body": {
            "run": run, "topic": topic,
            "summary": _ok(summary), "draft": _ok(draft), "review": _ok(review),
        },
    }
    data = _json.dumps(msg).encode()
    req = _ur.Request(f"{server}/send", data=data,
                      headers={"Content-Type": "application/json"}, method="POST")
    try:
        _ur.urlopen(req, timeout=3)
    except Exception:
        pass


def _fire_result(server: str, fr: str, to: str, action: str, body: dict) -> None:
    """POST an AXEL OK result message through the server so SSE/dashboard sees it."""
    import json as _json
    import urllib.request as _ur
    import uuid as _uuid
    msg = {
        "t": "OK", "v": "2.1",
        "id": str(_uuid.uuid4()),
        "fr": fr, "to": to,
        "action": action,
        "body": body,
    }
    data = _json.dumps(msg).encode()
    req = _ur.Request(
        f"{server}/send",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        _ur.urlopen(req, timeout=5)
    except Exception:
        pass


# Free models to try in order — first available wins
_FREE_MODELS = [
    "meta-llama/llama-3.2-3b-instruct:free",
    "mistralai/mistral-7b-instruct:free",
    "qwen/qwen-2.5-7b-instruct:free",
    "microsoft/phi-3-mini-128k-instruct:free",
    "meta-llama/llama-3.1-8b-instruct:free",
    "google/gemma-2-9b-it:free",
]

# Each agent gets a model that suits its role — the whole point of AXEL.
# These are paid OpenRouter models (need credits); unlock with --multi-model.
_SPECIALIST_MODELS = {
    "planner":        "anthropic/claude-3-5-haiku",           # fast, great at structured breakdown
    "researcher":     "openai/gpt-4o-mini",                   # strong retrieval + summarisation
    "analyst":        "google/gemini-2.0-flash-001",          # quick pattern synthesis
    "fact-checker":   "mistralai/mistral-large-2411",         # rigorous verification
    "writer":         "anthropic/claude-3-5-sonnet",          # best prose quality
    "devil-advocate": "meta-llama/llama-3.3-70b-instruct",    # challenges assumptions
    "summarizer":     "qwen/qwen-2.5-72b-instruct",           # distills to essence
    "reviewer":       "openai/gpt-4o",                        # sharpest final critic
}

# If a specialist model 404s or rate-limits, fall back to these automatically.
_FALLBACK_MODELS = {
    "analyst":        "google/gemini-flash-1.5-8b",
    "fact-checker":   "mistralai/mistral-small-3.1-24b-instruct",
    "devil-advocate": "meta-llama/llama-3.1-70b-instruct",
    "summarizer":     "openai/gpt-4o-mini",
    "reviewer":       "openai/gpt-4o-mini",
    "planner":        "openai/gpt-4o-mini",
    "researcher":     "anthropic/claude-3-5-haiku",
    "writer":         "openai/gpt-4o-mini",
}


def _openrouter(key: str, model: str, prompt: str, timeout: int = 45) -> str:
    """Call OpenRouter chat completion directly. Returns response text."""
    import json as _json
    import urllib.request as _ur
    payload = _json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 300,
    }).encode()
    req = _ur.Request(
        "https://openrouter.ai/api/v1/chat/completions",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
            "HTTP-Referer": "https://github.com/Sector11x/axel-protocol",
            "X-Title": "AXEL Demo",
        },
        method="POST",
    )
    resp = _ur.urlopen(req, timeout=timeout)
    data = _json.loads(resp.read())
    return data["choices"][0]["message"]["content"].strip()


def _openrouter_free(key: str, prompt: str, label: str = "agent") -> tuple:
    """Try free models in order. Returns (model_used, response_text)."""
    import urllib.error as _ue
    for model in _FREE_MODELS:
        try:
            text = _openrouter(key, model, prompt)
            short = model.split("/")[-1].replace(":free", "")
            print(f"     [{label} using {short}]")
            return model, text
        except _ue.HTTPError as e:
            if e.code in (404, 429):
                continue   # model unavailable or rate-limited, try next
            raise
        except Exception:
            continue
    raise RuntimeError(
        "No free OpenRouter models available right now.\n"
        "  Check your key at https://openrouter.ai or try again in a minute."
    )


_MOCK_RESPONSES = {
    "plan": (
        "1. Analyse how specialisation allows agents to focus on distinct cognitive tasks\n"
        "2. Examine how parallel agent execution reduces total latency vs a single chain\n"
        "3. Explore how shared memory lets agents build on each other's findings"
    ),
    "research": (
        "Subtask 1 — Specialisation:\n"
        "• Each agent can be fine-tuned or prompted for a narrow domain, reducing error rate\n"
        "• Role-specific agents outperform generalists on benchmark tasks by 18-34%\n\n"
        "Subtask 2 — Parallelism:\n"
        "• Independent subtasks run concurrently, cutting wall-clock time significantly\n"
        "• Bottlenecks in one agent don't block unrelated pipeline branches\n\n"
        "Subtask 3 — Shared Memory:\n"
        "• Lessons persist across runs, compounding quality over time\n"
        "• Agents avoid re-computing knowledge already stored by teammates"
    ),
    "analyze": (
        "Key Insight 1: Specialisation beats generalisation — focused agents produce higher-quality outputs.\n"
        "Key Insight 2: Parallelism is a force multiplier — multi-agent systems complete complex workflows 3-5x faster.\n"
        "Key Insight 3: Shared memory creates compounding returns — each run makes the network smarter."
    ),
    "fact_check": (
        "✓ Specialised agents outperform generalists on domain tasks — supported by benchmark literature\n"
        "✓ Parallel execution reduces wall-clock time — well established in distributed systems research\n"
        "⚠ '3-5x faster' claim — specific multiplier is unverified; real gains vary by task topology"
    ),
    "draft_content": (
        "Multi-agent AI systems don't just divide work — they multiply intelligence. "
        "By combining specialised models, parallel execution, and shared memory, "
        "agent networks solve problems that would overwhelm any single model."
    ),
    "challenge": (
        "Counterargument 1: Coordination overhead can negate speed gains — orchestrating 8 agents "
        "introduces latency and failure points that a single well-prompted model avoids.\n"
        "Counterargument 2: Shared memory creates echo chambers — agents that learn from each other "
        "may reinforce early errors rather than converge on truth."
    ),
    "summarize": (
        "Multi-agent systems outperform single models when task complexity justifies coordination cost, "
        "but only if shared memory is designed to surface disagreement, not just consensus."
    ),
    "review": (
        "Score: 9/10\n"
        "Strength: The pipeline surfaces and resolves its own counterarguments — rare and valuable.\n"
        "Improvement: Add a concrete example to ground the coordination-overhead tradeoff in reality."
    ),
}


def cmd_demo(args):  # noqa: C901
    """8-agent pipeline demo: planner → researcher → analyst → fact-checker → writer → devil-advocate → summarizer → reviewer."""
    import webbrowser
    import time
    import urllib.request as _ur
    import subprocess as _sp

    server       = getattr(args, "server", "http://localhost:7331")
    key          = os.environ.get("OPENROUTER_API_KEY") or _load_config().get("OPENROUTER_API_KEY")
    mock         = getattr(args, "mock", False)
    loop         = getattr(args, "loop", False)
    single_model = getattr(args, "model", None)          # one model for all agents
    multi_model  = getattr(args, "multi_model", False)   # each agent its specialist
    preset       = getattr(args, "preset", None)         # named preset topic
    custom_topic = getattr(args, "topic", None)          # one-off topic from CLI

    if not mock and not key:
        print("\n  AXEL Demo needs an OpenRouter key (free at https://openrouter.ai)")
        print("  Run:  axel setup   — to save your key, then try again.")
        print("  Or run without a key:  axel demo --mock\n")
        return

    # ── Auto-start server ─────────────────────────────────────────
    try:
        _ur.urlopen(f"{server}/status", timeout=2)
        print(f"  ✓  Server already running at {server}")
    except Exception:
        print(f"\n  🔄  Starting AXEL server automatically…")
        _sp.Popen(
            [__import__("sys").executable, "-m", "axel.server"],
            stdout=_sp.DEVNULL, stderr=_sp.DEVNULL,
        )
        ready = False
        for _ in range(20):
            time.sleep(0.5)
            try:
                _ur.urlopen(f"{server}/status", timeout=1)
                ready = True
                break
            except Exception:
                pass
        if not ready:
            print("  ❌  Server failed to start. Try: python3 -m axel.server\n")
            return
        print("  ✓  Server ready!")

    print(f"\n  🚀  AXEL Demo — 8-agent pipeline")
    webbrowser.open(f"{server}/ui")
    time.sleep(1.5)

    # ── Register all 8 agents ─────────────────────────────────────
    # Load from agents.yaml if present — lets users customise roles without touching code
    _DEFAULT_AGENTS = [
        ("planner",        ["plan", "breakdown"],              "🗺️"),
        ("researcher",     ["research", "summarize"],           "🔍"),
        ("analyst",        ["analyze", "synthesize"],           "📊"),
        ("fact-checker",   ["fact_check", "verify", "audit"],   "✅"),
        ("writer",         ["write", "draft_content"],          "✍️"),
        ("devil-advocate", ["challenge", "critique", "debate"], "😈"),
        ("summarizer",     ["summarize", "distill", "tldr"],    "🗜️"),
        ("reviewer",       ["review", "score", "final"],        "🔬"),
    ]
    AGENTS = _load_agents_yaml() or _DEFAULT_AGENTS
    def _agent_model(aid: str) -> str:
        if multi_model:
            return _SPECIALIST_MODELS.get(aid, "openai/gpt-4o-mini")
        if single_model:
            return single_model
        return "auto/free"

    print("\n  Registering 8 agents…")
    if multi_model:
        print("  🌐  Multi-model mode — each agent runs on its specialist LLM:")
    elif single_model:
        print(f"  🤖  All agents using: {single_model}")
    try:
        from axel.client import AXELClient
        clients = {}
        for aid, caps, em in AGENTS:
            mdl = _agent_model(aid)
            c = AXELClient(server, agent_id=aid, model=mdl,
                           provider="openrouter", caps=caps)
            c.connect()
            clients[aid] = c
            short_mdl = mdl.split("/")[-1] if mdl != "auto/free" else "free tier"
            print(f"    {em}  {aid:<12}  [{short_mdl}]")
            time.sleep(0.2)
    except Exception as exc:
        print(f"  ❌  Agent registration failed: {exc}\n"); return

    print("\n  ✓  All agents online — watch the dashboard!\n")
    if loop:
        print("  🔁  Loop mode — agents will keep running and learn between runs. Ctrl+C to stop.\n")
    time.sleep(1.5)

    # Preset topics — each showcases a different domain where specialisation wins
    _PRESET_TOPICS = {
        "code-review": (
            "Review this Python authentication function for security issues, edge cases, "
            "and best practices:\n\n"
            "def login(username, password):\n"
            "    user = db.query(f'SELECT * FROM users WHERE name={username}')\n"
            "    if user and user.password == password:\n"
            "        session['user'] = user\n"
            "        return redirect('/dashboard')\n"
            "    return 'Login failed'"
        ),
        "due-diligence": (
            "Prepare a due-diligence memo on Anthropic as a company: "
            "business model, competitive moat, key risks, and a 12-month outlook."
        ),
        "market-research": (
            "Conduct a market research analysis on the LLM API market in 2025: "
            "key players, pricing dynamics, differentiation strategies, and winner-take-all risk."
        ),
        "debate": (
            "Steel-man both sides of this debate: "
            "'AI will replace the majority of software engineering jobs within 10 years.' "
            "Provide the strongest possible arguments for each position, then a balanced verdict."
        ),
    }

    # Default built-in topic rotation — practical topics that show agent value
    _TOPICS = [
        "Review this Python function for security, performance, and edge cases: "
        "def get_user(id): return db.execute(f'SELECT * FROM users WHERE id={id}').fetchone()",
        "Prepare a one-page due-diligence brief on OpenAI as a business: moat, risks, and outlook",
        "Analyse the competitive dynamics of the LLM API market — who wins long-term and why",
        "Steel-man the argument that AI will NOT replace software engineers in the next decade",
        "Write a clear technical explanation of why RAG outperforms fine-tuning for most enterprise use cases",
        "Evaluate the key trade-offs of using multi-agent pipelines vs a single powerful LLM",
    ]

    def _check_user_queue(srv):
        """Check if a user submitted a task via the dashboard. Returns task string or None."""
        try:
            resp = _ur.urlopen(f"{srv}/queue", timeout=3)
            data = json.loads(resp.read())
            return data.get("task")  # None if queue was empty
        except Exception:
            return None

    def _fetch_topic_library(srv):
        """Fetch user-defined learning topics from the server. Returns list or []."""
        try:
            resp = _ur.urlopen(f"{srv}/topics", timeout=3)
            data = json.loads(resp.read())
            return data.get("topics", [])
        except Exception:
            return []

    def _fetch_memory_context(srv):
        """Pull top lessons from shared memory and format as context."""
        import json
        try:
            resp = _ur.urlopen(f"{srv}/memory?top=10", timeout=3)
            data = json.loads(resp.read())
            lessons = data.get("lessons", [])
            if not lessons:
                return ""
            lines = [f"  • {l['key']}: {l['insight']}" for l in lessons[:6]
                     if l.get("key") and l.get("insight")]
            if not lines:
                return ""
            return "\n[Lessons from previous runs — apply these:\n" + "\n".join(lines) + "]\n"
        except Exception:
            return ""

    step_counter = [0]   # mutable so inner func can update it

    def step(fr, to, action, prompt, learn_key=None, learn_insight=None, mem_ctx=""):
        """Fire a task, call the LLM (or use mock), fire the result."""
        step_counter[0] += 1
        full_prompt = (mem_ctx + prompt) if mem_ctx else prompt
        mdl = _agent_model(to)
        mdl_short = mdl.split("/")[-1].replace(":free", "") if mdl != "auto/free" else "free"
        print(f"\n  {fr} → {to}  [{action}]  ({mdl_short})")
        _fire_progress(server, run_count, step_counter[0], 8, to, action)
        _fire_task(server, fr, to, action, {"prompt": prompt[:200]})
        if mock:
            time.sleep(0.8)
            text = _MOCK_RESPONSES.get(action, f"[mock response for {action}]")
            print(f"  [mock]  {text[:180]}{'…' if len(text) > 180 else ''}")
        elif multi_model or single_model:
            # Try specialist model, then fallback, then gpt-4o-mini as last resort
            text = None
            models_to_try = [mdl]
            fallback = _FALLBACK_MODELS.get(to)
            if fallback and fallback != mdl:
                models_to_try.append(fallback)
            models_to_try.append("openai/gpt-4o-mini")  # always-available safety net
            import urllib.error as _ue
            for attempt_mdl in models_to_try:
                attempt_short = attempt_mdl.split("/")[-1]
                try:
                    text = _openrouter(key, attempt_mdl, full_prompt)
                    if attempt_mdl != mdl:
                        print(f"  ⚠  Fell back to {attempt_short}")
                    print(f"  [{to}/{attempt_short}]  {text[:180]}{'…' if len(text) > 180 else ''}")
                    break
                except _ue.HTTPError as e:
                    if e.code in (404, 429, 503):
                        print(f"  ↩  {attempt_short} unavailable ({e.code}), trying next…")
                        continue
                    print(f"  ❌  {to} ({attempt_short}) HTTP {e.code}")
                    break
                except Exception as exc:
                    print(f"  ❌  {to} ({attempt_short}): {exc}")
                    break
            if text is None:
                text = f"[{to} skipped — all models unavailable]"
                print(f"  ⚠  {to} skipped this step, pipeline continues…")
        else:
            try:
                _, text = _openrouter_free(key, full_prompt, label=to)
            except Exception as exc:
                print(f"  ❌  {to} failed: {exc}")
                print("  Tip: run  axel demo --mock  to test without an API key")
                text = f"[{to} skipped]"
        _fire_result(server, to, fr, action, {"text": text[:300]})
        if learn_key and learn_insight:
            try:
                clients[to].learn(learn_key, learn_insight, confidence=0.85)
            except Exception:
                pass
        time.sleep(0.4)
        return text

    # Resolve preset or custom one-off topic for CLI-specified runs
    _cli_topic: Optional[str] = None
    if preset:
        _cli_topic = _PRESET_TOPICS.get(preset)
        if not _cli_topic:
            _die(f"Unknown preset '{preset}'. Available: {', '.join(_PRESET_TOPICS)}")
        print(f"\n  🎯  Preset: {preset}")
    elif custom_topic:
        _cli_topic = custom_topic
        print(f"\n  🎯  Topic: {custom_topic}")

    run_count = 0
    try:
        while True:
            run_count += 1
            step_counter[0] = 0   # reset step counter for new run
            # Priority order: (1) user dashboard task, (2) CLI preset/topic, (3) server library, (4) built-in rotation
            user_task = _check_user_queue(server)
            if user_task:
                topic = user_task
                print(f"\n  ⌨️   User task received: \"{topic}\"")
            elif _cli_topic and (run_count == 1 or not loop):
                # Use the CLI-specified topic on the first (or only) run
                topic = _cli_topic
            else:
                # Pull user-defined topic library — use it if populated
                user_topics = _fetch_topic_library(server)
                if user_topics:
                    topic = user_topics[(run_count - 1) % len(user_topics)]
                    print(f"\n  📚  Topic Library ({len(user_topics)} topics) — exploring: \"{topic}\"")
                else:
                    topic = _TOPICS[(run_count - 1) % len(_TOPICS)]

            # Fetch lessons learned so far — injected into prompts so agents remember
            mem_ctx = _fetch_memory_context(server) if run_count > 1 else ""
            if mem_ctx:
                print(f"\n  🧠  Agents applying {len(mem_ctx.splitlines())-2} lessons from memory…")

            print(f"\n  📋  Run #{run_count}  Mission: \"{topic}\"")
            print("  ─────────────────────────────────────────────────")

            TOTAL = 8

            # ── Step 1: planner ───────────────────────────────────
            print(f"\n  STEP 1/{TOTAL}  Planner breaks the mission into subtasks")
            plan = step(
                "user", "planner", "plan",
                f"Break this mission into exactly 3 focused subtasks (numbered list, one line each): {topic}",
                learn_key="task-planning",
                learn_insight="Breaking missions into 3 focused subtasks improves agent handoff quality",
                mem_ctx=mem_ctx,
            )
            if plan is None: continue  # catastrophic failure — skip run

            # ── Step 2: researcher ────────────────────────────────
            print(f"\n  STEP 2/{TOTAL}  Researcher investigates each subtask")
            research = step(
                "planner", "researcher", "research",
                f"Research these subtasks and give 2-3 bullet points of findings for each:\n{plan}",
                learn_key="research-strategy",
                learn_insight="Structured subtask research produces more complete findings",
                mem_ctx=mem_ctx,
            )
            if research is None: continue

            # ── Step 3: analyst ───────────────────────────────────
            print(f"\n  STEP 3/{TOTAL}  Analyst synthesises the findings")
            analysis = step(
                "researcher", "analyst", "analyze",
                f"Synthesise these research findings into 3 sharp key insights:\n{research}",
                learn_key="synthesis",
                learn_insight="Distilling findings to 3 insights makes downstream writing stronger",
                mem_ctx=mem_ctx,
            )
            if analysis is None: continue

            # ── Step 4: fact-checker ──────────────────────────────
            print(f"\n  STEP 4/{TOTAL}  Fact-Checker verifies the analysis")
            fact_check = step(
                "analyst", "fact-checker", "fact_check",
                f"Fact-check these insights. Flag any claims that are vague, unverifiable, or likely wrong. "
                f"Return: verified claims ✓ and flagged claims ⚠ with a one-line reason:\n{analysis}",
                learn_key="fact-checking",
                learn_insight="Flagging unverifiable claims before writing prevents misinformation in output",
                mem_ctx=mem_ctx,
            )
            if fact_check is None: continue

            # ── Step 5: writer ────────────────────────────────────
            print(f"\n  STEP 5/{TOTAL}  Writer drafts from verified insights")
            draft = step(
                "fact-checker", "writer", "draft_content",
                f"Write a compelling 3-sentence summary for a general audience. Use only the verified insights:\n{fact_check}",
                learn_key="writing-style",
                learn_insight="3-sentence summaries from verified insights land well with non-technical readers",
                mem_ctx=mem_ctx,
            )
            if draft is None: continue

            # ── Step 6: devil's advocate ──────────────────────────
            print(f"\n  STEP 6/{TOTAL}  Devil's Advocate challenges the draft")
            challenge = step(
                "writer", "devil-advocate", "challenge",
                f"Play devil's advocate. Give 2 strong counterarguments or weaknesses in this draft. "
                f"Be specific and intellectually honest:\n{draft}",
                learn_key="critical-thinking",
                learn_insight="Surfacing counterarguments before final review strengthens the output quality",
                mem_ctx=mem_ctx,
            )
            if challenge is None: continue

            # ── Step 7: summarizer ────────────────────────────────
            print(f"\n  STEP 7/{TOTAL}  Summarizer distils everything to essence")
            summary = step(
                "devil-advocate", "summarizer", "summarize",
                f"Given the draft and its counterarguments, write the single best 1-sentence TL;DR "
                f"that captures the core truth:\nDraft: {draft}\nChallenges: {challenge}",
                learn_key="distillation",
                learn_insight="A single-sentence TL;DR that survives counterarguments is the most durable insight",
                mem_ctx=mem_ctx,
            )
            if summary is None: continue

            # ── Step 8: reviewer ──────────────────────────────────
            print(f"\n  STEP 8/{TOTAL}  Reviewer gives final score")
            review = step(
                "summarizer", "reviewer", "review",
                f"Final review of the full pipeline output. Score /10. One strength, one improvement.\n"
                f"Draft: {draft}\nTL;DR: {summary}",
                learn_key="review-criteria",
                learn_insight="Score + strength + improvement is the most actionable review format",
                mem_ctx=mem_ctx,
            )
            if review is None: continue

            _fire_run_complete(server, run_count, topic,
                               summary or "", draft or "", review or "")

            print("\n  ─────────────────────────────────────────────────")
            print(f"  ✅  Run #{run_count} complete! ({TOTAL} tasks · {TOTAL} lessons written)")
            if not loop:
                print("  Tip: run  axel demo --mock --loop  to keep agents running continuously\n")
                break
            print(f"  ⏸  Next run in 5 seconds… Ctrl+C to stop\n")
            time.sleep(5)

    except KeyboardInterrupt:
        print(f"\n\n  👋  Stopped after {run_count} run(s). Dashboard stays live — refresh anytime.\n")


def cmd_monitor(args):
    import webbrowser
    url = f"{args.server}/ui"
    webbrowser.open(url)
    print(f"  Opening dashboard: {url}")


def _load_agents_yaml() -> Optional[list]:
    """Load agent definitions from ~/.axel/agents.yaml or ./agents.yaml.
    Returns list of (id, caps, emoji) tuples, or None if no file found.

    agents.yaml schema:
    ───────────────────
    agents:
      - id: planner
        caps: [plan, breakdown]
        model: anthropic/claude-3-5-haiku   # optional — overrides _SPECIALIST_MODELS
        emoji: 🗺️
      - id: researcher
        caps: [research, summarize]
        emoji: 🔍
    """
    import yaml as _yaml_mod
    candidates = [
        Path.cwd() / "agents.yaml",
        Path.home() / ".axel" / "agents.yaml",
    ]
    for path in candidates:
        if not path.exists():
            continue
        try:
            try:
                import yaml  # type: ignore[import]
            except ImportError:
                import subprocess
                subprocess.check_call(
                    [__import__("sys").executable, "-m", "pip", "install", "pyyaml",
                     "--break-system-packages", "-q"],
                    stdout=subprocess.DEVNULL,
                )
                import yaml  # type: ignore[import]
            data = yaml.safe_load(path.read_text())
            if not isinstance(data, dict) or not data.get("agents"):
                continue
            agents_list = []
            for a in data["agents"]:
                aid  = str(a.get("id", "agent"))
                caps = list(a.get("caps", []))
                em   = str(a.get("emoji", "🤖"))
                # Optional per-agent model override stored in _SPECIALIST_MODELS
                if "model" in a:
                    _SPECIALIST_MODELS[aid] = str(a["model"])
                agents_list.append((aid, caps, em))
            if agents_list:
                print(f"  📄  Loaded {len(agents_list)} agents from {path}")
                return agents_list
        except Exception as exc:
            print(f"  ⚠  Could not parse {path}: {exc}")
    return None


def cmd_mcp(args):
    """Start the AXEL MCP stdio server (for Claude Desktop, Cursor, etc.)."""
    from axel import mcp_server
    mcp_server.main(server_url=args.server)


# ──────────────────────────────────────────────────────────────────────────────
# URL quoting (stdlib only)
# ──────────────────────────────────────────────────────────────────────────────

def _ur_quote(s: str) -> str:
    from urllib.parse import quote
    return quote(s, safe="")


# ──────────────────────────────────────────────────────────────────────────────
# Argument parser
# ──────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    default_server = os.environ.get("AXEL_SERVER", "http://localhost:7331")
    default_key    = os.environ.get("AXEL_KEY", "")

    p = argparse.ArgumentParser(
        prog="axel",
        description="AXEL network CLI — inspect and interact with a running AXEL server.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--server", default=default_server,
                   help=f"Server base URL (default: {default_server})")
    p.add_argument("--key",    default=default_key,
                   help="API key (or set AXEL_KEY env var)")
    p.add_argument("--json",   action="store_true",
                   help="Output raw JSON")

    sub = p.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    # status
    sub.add_parser("status", help="Show server status and agent count")

    # agents
    sub.add_parser("agents", help="List all registered agents")

    # send
    ps = sub.add_parser("send", help="Send a TASK message to an agent")
    ps.add_argument("to",     help="Recipient agent ID")
    ps.add_argument("action", help="Action name (body.act)")
    ps.add_argument("--args", default="{}",
                    help='JSON args dict, e.g. \'{"topic": "AI"}\'')
    ps.add_argument("--from", dest="from_agent", default="axel-cli",
                    help="Sender agent ID (default: axel-cli)")
    ps.add_argument("--priority", type=int, default=2,
                    help="Priority 1-5 (default: 2 = NORMAL)")
    ps.add_argument("--ttl",  type=int, default=0,
                    help="Time-to-live in seconds (default: 0 = no expiry)")

    # memory
    pm = sub.add_parser("memory", help="Query shared memory")
    msub = pm.add_subparsers(dest="memory_cmd", metavar="CMD")
    msub.required = True

    pms = msub.add_parser("search", help="Search lessons by keyword")
    pms.add_argument("query", help="Search query")
    pms.add_argument("--n", type=int, default=10, help="Max results (default: 10)")

    pml = msub.add_parser("list", help="List all lessons")
    pml.add_argument("--top", type=int, default=20, help="Max results (default: 20)")

    # discover
    pd = sub.add_parser("discover", help="Find the best agent for a capability")
    pd.add_argument("capability", help="Capability name to search for")

    # monitor
    sub.add_parser("monitor", help="Open the dashboard in a browser")

    # setup
    sub.add_parser("setup", help="Interactive API key setup wizard")

    # models
    pm2 = sub.add_parser("models", help="List available OpenRouter models")
    pm2.add_argument("--free", action="store_true",
                     help="Show only free-tier models")

    # demo
    pd = sub.add_parser("demo", help="Run 8-agent pipeline demo (needs OPENROUTER_API_KEY)")
    pd.add_argument("--mock", action="store_true",
                    help="Run with pre-written responses — no API key needed")
    pd.add_argument("--loop", action="store_true",
                    help="Keep running the pipeline continuously — agents learn between runs")
    pd.add_argument("--model", default=None, metavar="MODEL",
                    help="Use a specific OpenRouter model for all agents "
                         "(e.g. anthropic/claude-3-5-sonnet)")
    pd.add_argument("--multi-model", action="store_true",
                    help="Give each agent its specialist model: planner→Claude Haiku, "
                         "researcher→GPT-4o-mini, analyst→Gemini Flash, "
                         "writer→Claude Sonnet, reviewer→GPT-4o")
    pd.add_argument("--preset", default=None,
                    metavar="PRESET",
                    help="Run a named demo scenario: code-review, due-diligence, "
                         "market-research, debate")
    pd.add_argument("--topic", default=None, metavar="TOPIC",
                    help="Run a custom one-off topic instead of the built-in rotation")
    pd.add_argument("--server", default="http://localhost:7331",
                    help="AXEL server URL")

    # mcp
    pmcp = sub.add_parser(
        "mcp",
        help="Start AXEL as an MCP server (for Claude Desktop, Cursor, Windsurf, etc.)",
    )
    pmcp.add_argument(
        "--server", default=os.environ.get("AXEL_SERVER", "http://localhost:7331"),
        help="AXEL server URL the MCP tools will call",
    )

    return p


# ──────────────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────────────

def main():
    parser = build_parser()
    args = parser.parse_args()

    dispatch = {
        "setup":    cmd_setup,
        "demo":     cmd_demo,
        "status":   cmd_status,
        "agents":   cmd_agents,
        "send":     cmd_send,
        "memory":   _memory_dispatch,
        "discover": cmd_discover,
        "monitor":  cmd_monitor,
        "models":   cmd_models,
        "mcp":      cmd_mcp,
    }
    dispatch[args.command](args)


def _memory_dispatch(args):
    if args.memory_cmd == "search":
        cmd_memory_search(args)
    elif args.memory_cmd == "list":
        cmd_memory_list(args)


if __name__ == "__main__":
    main()
