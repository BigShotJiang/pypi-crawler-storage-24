#!/usr/bin/env python3
"""
axel_client.py  —  AXEL Network Client SDK
═══════════════════════════════════════════
Connect any Python script or LLM agent to a running AXEL server.
Pure stdlib — no external dependencies beyond the standard library.

Quick start:
    client = AXELClient("http://localhost:7331", "my_agent",
                        model="claude-3-5-sonnet", provider="anthropic",
                        caps=["research", "summarize"])

    # Send a task to another agent and get back the result
    result = client.execute("writer", "draft_content", {"topic": "AI"})

    # Share a lesson with all agents
    client.learn("draft_content", "Use active voice — all models reproduce it better")

    # Find the best agent for a job
    disc = client.discover("translate_text")
    print(disc["best"])  # → "gemini_translator"

    # Run a multi-step pipeline
    results = client.chain([
        {"to": "researcher", "act": "research",      "args": {"topic": "AXEL"}},
        {"to": "writer",     "act": "draft_content", "args": {"format": "blog"}},
        {"to": "reviewer",   "act": "review",        "args": {}},
    ])

For a self-contained agent with message handling, subclass AXELAgent:
    class MyResearcher(AXELAgent):
        @AXELAgent.task_handler("research")
        def handle_research(self, args, ctx):
            return {"summary": f"Researched: {args.get('topic')}"}

    agent = MyResearcher("http://localhost:7331", "researcher",
                         model="claude-3-5-haiku", provider="anthropic",
                         caps=["research", "summarize"])
    agent.run()  # blocks and processes messages
"""

import json
import os
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
import urllib.error
import urllib.parse
import urllib.request

_HERE = Path(__file__).parent
sys.path.insert(0, str(_HERE))
from axel.core import AXELBuilder, AXELMessage


# ══════════════════════════════════════════════════════════════════
# AXELClient  —  HTTP client for the AXEL Network Server
# ══════════════════════════════════════════════════════════════════

class AXELClient:
    """
    Lightweight HTTP client that connects an agent to the AXEL server.
    All communication uses plain JSON over HTTP — no special deps needed.
    """

    def __init__(
        self,
        server_url: str,
        agent_id: str,
        model: str = "unknown",
        provider: str = "custom",
        caps: List[str] = None,
        tags: List[str] = None,
        auto_connect: bool = True,
        key: Optional[str] = None,
    ):
        self.server_url = server_url.rstrip("/")
        self.agent_id = agent_id
        self.model = model
        self.provider = provider
        self.caps = caps or []
        self.tags = tags or []
        self.key = key or os.environ.get("AXEL_KEY") or None
        self.builder = AXELBuilder(agent_id)
        self._connected = False
        self._handlers: Dict[str, Callable] = {}
        self._stop = threading.Event()
        self._listener: Optional[threading.Thread] = None

        if auto_connect:
            self.connect()

    # ── HTTP primitives ──────────────────────────────────────────

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.key:
            h["X-AXEL-Key"] = self.key
        return h

    def _post(self, path: str, body: dict, timeout: int = 35) -> dict:
        url = f"{self.server_url}{path}"
        data = json.dumps(body).encode()
        req = urllib.request.Request(url, data=data, headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"HTTP {e.code}: {e.read().decode()}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"Cannot reach AXEL server at {self.server_url}: {e.reason}")

    def _get(self, path: str, params: dict = None, timeout: int = 35) -> dict:
        url = f"{self.server_url}{path}"
        if params:
            url += "?" + urllib.parse.urlencode(
                {k: v for k, v in params.items() if v is not None}
            )
        req = urllib.request.Request(url, headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"HTTP {e.code}: {e.read().decode()}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"Cannot reach AXEL server at {self.server_url}: {e.reason}")

    # ── Connection ───────────────────────────────────────────────

    def connect(self) -> dict:
        """Announce this agent to the server and get an inbox ready."""
        result = self._post("/agents/announce", {
            "agent_id": self.agent_id,
            "model":    self.model,
            "provider": self.provider,
            "caps":     self.caps,
            "tags":     self.tags,
        })
        self._connected = True
        return result

    def disconnect(self):
        self._stop.set()
        self._connected = False

    # ── Messaging ────────────────────────────────────────────────

    def send(self, msg: AXELMessage) -> dict:
        """Send a pre-built AXELMessage."""
        return self._post("/send", msg.to_dict())

    def send_raw(self, msg_dict: dict) -> dict:
        """Send a raw message dict."""
        return self._post("/send", msg_dict)

    def inbox(self, timeout: float = 5.0) -> Optional[dict]:
        """Long-poll for one message. Returns None on timeout."""
        try:
            result = self._get(
                f"/inbox/{self.agent_id}",
                {"timeout": min(timeout, 30.0)},
                timeout=int(timeout) + 5,
            )
            return result.get("msg")
        except Exception:
            return None

    def drain(self) -> List[dict]:
        """Return all currently queued messages without blocking."""
        try:
            result = self._get(f"/inbox/{self.agent_id}/all")
            return result.get("msgs", [])
        except Exception:
            return []

    # ── Task execution ───────────────────────────────────────────

    def execute(
        self,
        to: str,
        action: str,
        args: dict = None,
        ctx: dict = None,
        timeout: int = 60,
        priority: int = 3,
    ) -> dict:
        """
        Send a TK message and wait for the OK/ER response.
        The server routes it to the target agent's adapter and returns the result.
        """
        tk = self.builder.task(
            to=to, action=action,
            args=args or {}, ctx=ctx or {},
            timeout=timeout, priority=priority,
        )
        return self._post("/execute", tk.to_dict(), timeout=timeout + 5)

    def chain(self, steps: List[dict], ctx: dict = None) -> List[dict]:
        """
        Execute a multi-step pipeline on the server.
        Each step's result is passed as prev_result to the next step's ctx.

        steps = [
            {"to": "researcher", "act": "research",       "args": {...}},
            {"to": "writer",     "act": "draft_content",  "args": {}},
            {"to": "reviewer",   "act": "review",         "args": {}},
        ]
        """
        ch = {
            "v": "2", "t": "CH",
            "id":  f"msg_{uuid.uuid4().hex[:12]}",
            "cid": self.builder.conversation_id,
            "fr":  self.agent_id,
            "to":  "server",
            "ts":  int(time.time() * 1000),
            "pri": 3,
            "body": {
                "steps":          steps,
                "ctx":            ctx or {},
                "stop_on_error":  True,
            },
        }
        result = self._post("/execute", ch, timeout=120)
        return result.get("results", [result])

    # ── Learning & Memory ────────────────────────────────────────

    def learn(self, key: str, insight: str, confidence: float = 1.0) -> dict:
        """
        Broadcast an LS lesson message — the server's LS handler writes it to shared
        memory automatically, so no separate /memory/write call is needed.
        """
        # Broadcast as LS message; server auto-writes to SmartMemory on receipt
        ls = {
            "v": "2", "t": "LS",
            "id":  f"msg_{uuid.uuid4().hex[:12]}",
            "cid": self.builder.conversation_id,
            "fr":  self.agent_id,
            "to":  "*",
            "ts":  int(time.time() * 1000),
            "pri": 2,
            "body": {"key": key, "insight": insight, "confidence": confidence},
        }
        return self._post("/send", ls)

    def memory_search(self, query: str, n: int = 5) -> List[dict]:
        result = self._get("/memory/search", {"q": query, "n": n})
        return result.get("results", [])

    def memory_list(self, top: int = 10) -> List[dict]:
        result = self._get("/memory", {"top": top})
        return result.get("lessons", [])

    # ── Pub/Sub ──────────────────────────────────────────────────

    def subscribe(self, channel: str, filter_: dict = None) -> dict:
        """Subscribe this agent to a named event channel."""
        return self._post("/channels/subscribe", {
            "agent_id": self.agent_id,
            "channel":  channel,
            "filter":   filter_ or {},
        })

    def publish(self, channel: str, event: dict) -> dict:
        """Publish an event to a channel; all subscribers get notified."""
        return self._post("/channels/publish", {
            "publisher": self.agent_id,
            "channel":   channel,
            "event":     event,
        })

    # ── Discovery ────────────────────────────────────────────────

    def discover(self, action: str, top: int = 5) -> dict:
        """Find the best registered agent for a given capability."""
        return self._get(f"/discover/{action}", {"top": top})

    def agents(self) -> List[dict]:
        return self._get("/agents").get("agents", [])

    # ── Status ───────────────────────────────────────────────────

    def status(self) -> dict:
        return self._get("/status")

    def network_summary(self) -> str:
        """Human-readable one-line network summary."""
        s = self.status()
        n = s["agents"]["count"]
        mem = s["memory"].get("total", 0)
        uptime = s["uptime_s"]
        return (f"AXEL Network: {n} agents | {mem} lessons | "
                f"uptime {uptime}s | {self.server_url}")

    # ── Background listener ──────────────────────────────────────

    def on(self, action: str):
        """Decorator to register a handler for TK messages with body.act == action."""
        def decorator(fn: Callable):
            self._handlers[action] = fn
            return fn
        return decorator

    def listen(
        self,
        handler: Callable = None,
        background: bool = True,
        poll_timeout: float = 5.0,
    ) -> Optional[threading.Thread]:
        """
        Poll inbox and dispatch to registered handlers.
        handler(msg_dict) is called for any message without a specific handler.
        Set background=False to block the current thread.
        """
        self._stop.clear()

        def _loop():
            while not self._stop.is_set():
                msg = self.inbox(timeout=poll_timeout)
                if msg is None:
                    continue
                act = msg.get("body", {}).get("act", "")
                t   = msg.get("t", "")
                fn  = self._handlers.get(act) or self._handlers.get(t)
                try:
                    if fn:
                        result = fn(msg)
                        if isinstance(result, dict):
                            self.send_raw(result)
                    elif handler:
                        handler(msg)
                except Exception as e:
                    print(f"[{self.agent_id}] handler error: {e}")

        if background:
            self._listener = threading.Thread(
                target=_loop, daemon=True, name=f"axel-{self.agent_id}",
            )
            self._listener.start()
            return self._listener
        else:
            _loop()
            return None


# ══════════════════════════════════════════════════════════════════
# AXELAgent  —  self-contained agent with task routing
# ══════════════════════════════════════════════════════════════════

class AXELAgent(AXELClient):
    """
    Higher-level agent base class. Subclass and use the @task decorator
    to register action handlers. Call .run() to start processing.

    Example:
        class Researcher(AXELAgent):
            @AXELAgent.task_handler("research")
            def do_research(self, args, ctx):
                return {"findings": f"Researched: {args.get('topic')}"}

        Researcher("http://localhost:7331", "researcher",
                   model="claude-3-5-haiku", provider="anthropic",
                   caps=["research"]).run()
    """

    # Class-level registry for @task_handler decorated methods
    _class_handlers: Dict[str, str] = {}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Bind class-level handlers to instance
        for action, method_name in self.__class__._class_handlers.items():
            fn = getattr(self, method_name, None)
            if fn:
                self._handlers[action] = self._make_dispatch_handler(action)

    @classmethod
    def task_handler(cls, action: str):
        """Class-level decorator for task handlers."""
        def decorator(fn):
            cls._class_handlers[action] = fn.__name__
            return fn
        return decorator

    def _make_dispatch_handler(self, action: str):
        def handler(msg: dict):
            return self._dispatch_task(msg)
        return handler

    def _dispatch_task(self, msg: dict):
        t   = msg.get("t", "")
        act = msg.get("body", {}).get("act", "")
        fr  = msg.get("fr", "unknown")
        cid = msg.get("cid", "")
        mid = msg.get("id", "")

        if t == "TK":
            method_name = self.__class__._class_handlers.get(act)
            handler_fn = getattr(self, method_name, None) if method_name else None

            if handler_fn:
                try:
                    result_data = handler_fn(
                        msg.get("body", {}).get("args", {}),
                        msg.get("body", {}).get("ctx",  {}),
                    )
                    ok = {
                        "v": "2", "t": "OK",
                        "id":  f"msg_{uuid.uuid4().hex[:12]}",
                        "cid": cid, "fr": self.agent_id, "to": fr,
                        "ts":  int(time.time() * 1000), "pri": 3,
                        "re":  mid,
                        "body": {"result": result_data},
                    }
                    self.send_raw(ok)
                    # Auto-learn from success
                    self.learn(act, f"Handled {act} successfully", confidence=0.7)
                except Exception as e:
                    err = {
                        "v": "2", "t": "ER",
                        "id":  f"msg_{uuid.uuid4().hex[:12]}",
                        "cid": cid, "fr": self.agent_id, "to": fr,
                        "ts":  int(time.time() * 1000), "pri": 3,
                        "re":  mid,
                        "body": {"code": "INTERNAL", "msg": str(e), "retry": True},
                    }
                    self.send_raw(err)
            else:
                print(f"[{self.agent_id}] No handler for '{act}'")

        elif t == "LS":
            # Auto-absorb lessons from the network
            key     = msg.get("body", {}).get("key", "")
            insight = msg.get("body", {}).get("insight", "")
            if key and insight:
                print(f"[{self.agent_id}] 📚 Lesson from {fr}: [{key}] {insight[:70]}")

    def run(self, poll_timeout: float = 5.0):
        """Block and process messages forever (Ctrl+C to stop)."""
        print(f"\n[{self.agent_id}] online  model={self.model}  caps={self.caps}")
        print(f"[{self.agent_id}] connected to {self.server_url}")
        print(f"[{self.agent_id}] registered handlers: {list(self.__class__._class_handlers.keys())}")
        print(f"[{self.agent_id}] listening… (Ctrl+C to stop)\n")

        self._stop.clear()
        try:
            while not self._stop.is_set():
                msg = self.inbox(timeout=poll_timeout)
                if msg is None:
                    continue
                self._dispatch_task(msg)
        except KeyboardInterrupt:
            print(f"\n[{self.agent_id}] stopped.")
