import ast
import copy
import difflib
import logging
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Set, Optional, Dict, Union, Tuple

import nbformat
import yaml
from sqlglot import parse_one, errors

DEFAULT_SQL_KEYWORDS = frozenset(
    {
        "SELECT",
        "FROM",
        "WHERE",
        "INSERT",
        "UPDATE",
        "DELETE",
        "WITH",
        "JOIN",
        "CREATE",
        "DROP",
        "ALTER",
        "TRUNCATE",
        "UNION",
        "EXCEPT",
        "INTERSECT",
        "GROUP BY",
        "ORDER BY",
        "HAVING",
        "LIMIT",
        "OFFSET",
        "DISTINCT",
    }
)

DEFAULT_FUNCTION_NAMES = frozenset(
    {
        "read_sql",
        "read_sql_query",
        "read_sql_table",
        "execute",
        "executescript",
        "fetchall",
        "fetchone",
        "fetchmany",
        "execute_query",
    }
)

DEFAULT_SQL_DECORATORS = frozenset(
    {
        "sql_decorator",
        "query",
        "sql_query",
        "db_query",
    }
)


@dataclass
class SQLReplacement:
    """A text replacement to apply to the source code."""

    start_offset: int
    end_offset: int
    new_text: str


@dataclass
class FormattingConfig:
    """Configuration for SQL formatting."""

    sql_keywords: Set[str] = field(default_factory=lambda: set(DEFAULT_SQL_KEYWORDS))
    function_names: Set[str] = field(
        default_factory=lambda: set(DEFAULT_FUNCTION_NAMES)
    )
    sql_decorators: Set[str] = field(
        default_factory=lambda: set(DEFAULT_SQL_DECORATORS)
    )
    single_line_threshold: int = 80
    indent_width: int = 4


class SQLFormattingError(Exception):
    """Custom exception for SQL formatting errors."""

    pass


def setup_logging(level: str = "INFO") -> logging.Logger:
    """Sets up logging with the specified level."""
    logger = logging.getLogger("formatter")
    logger.setLevel(level.upper())
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter("[%(levelname)s] %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger


def load_config(config_path: Optional[Union[str, Path]] = None) -> FormattingConfig:
    """Loads configuration from a YAML file, or returns defaults if no path given."""
    if config_path is None:
        return FormattingConfig()

    config_file = Path(config_path)
    if not config_file.is_file():
        raise FileNotFoundError(f"Configuration file '{config_file}' not found.")

    try:
        with open(config_file) as file:
            config = yaml.safe_load(file)
            return FormattingConfig(
                sql_keywords=set(config.get("sql_keywords", [])),
                function_names=set(config.get("function_names", [])),
                sql_decorators=set(config.get("sql_decorators", [])),
                single_line_threshold=config.get("formatting_options", {}).get(
                    "single_line_threshold", 80
                ),
                indent_width=config.get("formatting_options", {}).get(
                    "indent_width", 4
                ),
            )
    except yaml.YAMLError as e:
        raise yaml.YAMLError(f"Error parsing the configuration file: {e}")


def build_line_offsets(source: str) -> list:
    """Returns list where offsets[i] is the character offset of line i+1 in source."""
    offsets = [0]
    for i, ch in enumerate(source):
        if ch == "\n":
            offsets.append(i + 1)
    return offsets


def node_offsets(node: ast.AST, line_offsets: list) -> Tuple[int, int]:
    """Converts AST node line/col positions to (start, end) character offsets."""
    start = line_offsets[node.lineno - 1] + node.col_offset
    end = line_offsets[node.end_lineno - 1] + node.end_col_offset
    return start, end


def format_sql_code(
    sql_code: str,
    dialect: Optional[str],
    config: FormattingConfig,
    placeholders: Optional[Dict[str, str]] = None,
    force_single_line: bool = False,
    is_magic_command: bool = False,
    is_cell_magic: bool = False,
) -> str:
    """
    Formats SQL code using sqlglot's native formatting capabilities.

    Args:
        sql_code (str): The original SQL code to format.
        dialect (Optional[str]): The SQL dialect to use (e.g., 'postgres', 'mysql').
        config (FormattingConfig): The formatting configuration.
        placeholders (Optional[Dict[str, str]]): A mapping of placeholders to their expressions.
        force_single_line (bool): Whether to force the formatted SQL into a single line.
        is_magic_command (bool): Whether the SQL code comes from a magic command.
        is_cell_magic (bool): Whether the SQL code comes from a cell magic command.

    Returns:
        str: The formatted SQL code.
    """
    try:
        logger = logging.getLogger("formatter")

        if not sql_code.strip():
            return sql_code

        temp_sql = sql_code

        # Handle placeholders in f-strings
        placeholder_mapping = {}
        if placeholders:
            for placeholder in placeholders.keys():
                # Replace placeholder with a valid SQL parameter
                temp_placeholder = f":{placeholder}"
                temp_sql = temp_sql.replace(placeholder, temp_placeholder)
                placeholder_mapping[temp_placeholder] = placeholder

        # Handle automatic placeholders (%s, ?)
        auto_placeholder_pattern = re.compile(r"%s|\?")
        auto_placeholders = auto_placeholder_pattern.findall(temp_sql)
        auto_placeholder_mapping = {}
        for idx, ph in enumerate(auto_placeholders):
            temp_placeholder = f":AUTO_PLACEHOLDER_{idx}"
            temp_sql = temp_sql.replace(ph, temp_placeholder, 1)
            auto_placeholder_mapping[temp_placeholder] = ph

        temp_sql = temp_sql.strip()

        # Parse and format SQL
        parsed = parse_one(temp_sql, read=dialect)
        formatted_sql = parsed.sql(
            pretty=not force_single_line, indent=config.indent_width, dialect=dialect
        )

        # Apply formatting based on context
        if is_magic_command and not is_cell_magic:
            # Line magic: single line
            formatted_sql = " ".join(formatted_sql.split())
        elif force_single_line:
            formatted_sql = " ".join(formatted_sql.split())
        else:
            formatted_sql = formatted_sql.strip()

        # Restore placeholders in f-strings
        if placeholders:
            for temp_placeholder, original_placeholder in placeholder_mapping.items():
                # Remove quotes around placeholders if any
                formatted_sql = formatted_sql.replace(
                    f"'{temp_placeholder}'", temp_placeholder
                )
                formatted_sql = formatted_sql.replace(
                    f'"{temp_placeholder}"', temp_placeholder
                )
                # Replace temp placeholders with original placeholders
                formatted_sql = formatted_sql.replace(
                    temp_placeholder, original_placeholder
                )

        # Restore automatic placeholders
        for temp_placeholder, original_placeholder in auto_placeholder_mapping.items():
            formatted_sql = formatted_sql.replace(
                temp_placeholder, original_placeholder
            )

        # Logging for debugging purposes
        logger.debug(f"Original SQL:\n{sql_code}")
        logger.debug(f"Formatted SQL:\n{formatted_sql}")

        return formatted_sql

    except errors.ParseError as e:
        raise SQLFormattingError(f"Failed to parse SQL code: {e}")
    except Exception as e:
        raise SQLFormattingError(f"Unexpected error during SQL formatting: {e}")


class SQLStringFormatter(ast.NodeVisitor):
    """AST NodeVisitor that collects SQL string replacements."""

    def __init__(
        self,
        config: FormattingConfig,
        dialect: Optional[str],
        logger: logging.Logger,
        line_offsets: list,
    ):
        super().__init__()
        self.config = config
        self.dialect = dialect
        self.logger = logger
        self.line_offsets = line_offsets
        self.replacements: list = []
        self.changed = False

    def is_likely_sql(self, code: str) -> bool:
        """Enhanced SQL detection with better heuristics."""
        if not code or len(code.strip()) < 10:
            return False

        if re.match(r"^\s*(/|[a-zA-Z]:\\|https?://|<!DOCTYPE|<html)", code.strip()):
            return False

        upper_code = code.upper()
        keyword_count = sum(
            1
            for keyword in self.config.sql_keywords
            if re.search(rf"\b{re.escape(keyword)}\b", upper_code)
        )

        has_sql_pattern = bool(
            re.search(
                r"\bSELECT\b.*\bFROM\b|\bUPDATE\b.*\bSET\b|\bINSERT\b.*\bINTO\b|\bDELETE\b.*\bFROM\b",
                upper_code,
                re.DOTALL,
            )
        )

        return keyword_count >= 2 or has_sql_pattern

    def extract_fstring_parts(self, node: ast.JoinedStr) -> Tuple[str, Dict[str, str]]:
        """Extracts parts of an f-string, preserving expressions."""
        sql_parts = []
        placeholders = {}
        placeholder_counter = 0

        # Handle empty f-strings or f-strings with only constants
        if all(isinstance(value, ast.Constant) for value in node.values):
            return "".join(value.value for value in node.values), {}

        for value in node.values:
            if isinstance(value, ast.Constant):
                sql_parts.append(value.value)
            elif isinstance(value, ast.FormattedValue):
                expr = ast.unparse(value.value)
                placeholder = f"PLACEHOLDER_{placeholder_counter}"
                sql_parts.append(placeholder)
                placeholders[placeholder] = expr
                placeholder_counter += 1

        return "".join(sql_parts), placeholders

    def format_sql_node(
        self,
        node: Union[ast.Constant, ast.JoinedStr],
        force_single_line: bool = False,
        in_function: bool = False,
    ) -> Optional[str]:
        """Formats SQL code in AST nodes. Returns replacement text or None."""
        try:
            is_fstring = isinstance(node, ast.JoinedStr)
            placeholders = {}

            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                if not self.is_likely_sql(node.value):
                    return None
                sql_str = node.value
            elif isinstance(node, ast.JoinedStr):
                sql_str, placeholders = self.extract_fstring_parts(node)
                if not sql_str or not self.is_likely_sql(sql_str):
                    return None
            else:
                return None

            try:
                formatted_sql = format_sql_code(
                    sql_str,
                    self.dialect,
                    self.config,
                    placeholders=placeholders if placeholders else None,
                    force_single_line=force_single_line,
                )
            except SQLFormattingError:
                return None

            if formatted_sql == sql_str:
                return None

            # Restore placeholders as f-string expressions
            if placeholders:
                for ph in placeholders:
                    formatted_sql = formatted_sql.replace(f"'{ph}'", ph)
                    formatted_sql = formatted_sql.replace(f'"{ph}"', ph)
                for ph, expr in placeholders.items():
                    formatted_sql = formatted_sql.replace(ph, f"{{{expr}}}")

            self.changed = True
            return self._build_replacement_text(formatted_sql, is_fstring, in_function)

        except SQLFormattingError as e:
            self.logger.warning(f"SQL formatting skipped: {e}")
            return None
        except Exception as e:
            self.logger.warning(f"Unexpected error during SQL formatting: {e}")
            return None

    def _build_replacement_text(
        self, formatted_sql: str, is_fstring: bool, in_function: bool
    ) -> str:
        """Constructs the replacement string literal text."""
        prefix = "f" if is_fstring else ""
        if in_function and "\n" in formatted_sql:
            indent = " " * 4
            lines = formatted_sql.split("\n")
            indented_lines = [indent + line if line.strip() else line for line in lines]
            indented_sql = "\n".join(indented_lines)
            return f'\n{indent}{prefix}"""\n{indented_sql}\n{indent}"""\n'
        elif "\n" in formatted_sql:
            return f'{prefix}"""\n{formatted_sql}\n"""'
        else:
            return f'{prefix}"{formatted_sql}"'

    def visit_Assign(self, node: ast.Assign) -> None:
        """Handles assignments."""
        if isinstance(node.value, (ast.Constant, ast.JoinedStr)):
            replacement_text = self.format_sql_node(node.value)
            if replacement_text:
                start, end = node_offsets(node.value, self.line_offsets)
                self.replacements.append(SQLReplacement(start, end, replacement_text))
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        """Handles function calls."""
        func_name = self.get_full_func_name(node.func)
        if any(name in func_name for name in self.config.function_names):
            for arg in node.args:
                if isinstance(arg, (ast.Constant, ast.JoinedStr)):
                    replacement_text = self.format_sql_node(arg, in_function=True)
                    if replacement_text:
                        start, end = node_offsets(arg, self.line_offsets)
                        self.replacements.append(
                            SQLReplacement(start, end, replacement_text)
                        )
            for keyword in node.keywords:
                if isinstance(keyword.value, (ast.Constant, ast.JoinedStr)):
                    replacement_text = self.format_sql_node(
                        keyword.value, in_function=True
                    )
                    if replacement_text:
                        start, end = node_offsets(keyword.value, self.line_offsets)
                        self.replacements.append(
                            SQLReplacement(start, end, replacement_text)
                        )
        self.generic_visit(node)

    @staticmethod
    def get_full_func_name(node: ast.AST) -> str:
        """Gets the full function name from an AST node."""
        parts = []
        while isinstance(node, ast.Attribute):
            parts.append(node.attr)
            node = node.value
        if isinstance(node, ast.Name):
            parts.append(node.id)
        return ".".join(reversed(parts))


def process_notebook(
    notebook_path: Union[str, Path],
    config: FormattingConfig,
    dialect: Optional[str],
    logger: logging.Logger,
    check_only: bool = False,
) -> bool:
    """Processes a Jupyter notebook.

    Args:
        check_only: If True, detect changes but don't write the file.

    Returns:
        True if changes were made (or would be made in check mode).
    """
    try:
        notebook = nbformat.read(notebook_path, as_version=4)
        changed = False

        for cell_index, cell in enumerate(notebook.cells):
            if cell.cell_type != "code":
                continue

            original_code = cell.source
            if not original_code.strip():
                continue

            if "# sqlnbfmt: skip" in original_code:
                logger.debug(f"[Cell {cell_index}] Skipping cell (sqlnbfmt: skip)")
                continue

            lines = original_code.split("\n")

            # Initialize variables to track magic commands
            magic_cmd = None
            magic_cmd_index = None

            # Iterate through lines to find the first non-comment magic command
            for idx, line in enumerate(lines):
                stripped = line.strip()

                if not stripped:
                    continue  # Skip empty lines

                if stripped.startswith("#"):
                    continue  # Skip comment lines

                if stripped.startswith("%%sql") or stripped.startswith("%sql"):
                    magic_cmd = stripped.split()[0]
                    magic_cmd_index = idx
                    break  # Magic command found

                else:
                    break  # Non-magic, non-comment line found

            if magic_cmd:
                is_cell_magic = magic_cmd.startswith("%%sql")

                if is_cell_magic:
                    # Cell magic: SQL code starts from the next line
                    sql_code = "\n".join(lines[magic_cmd_index + 1 :]).strip()
                else:
                    # Line magic: SQL code is on the same line after the magic command
                    sql_code = lines[magic_cmd_index][len(magic_cmd) :].strip()

                try:
                    formatted_sql = format_sql_code(
                        sql_code,
                        dialect,
                        config,
                        is_magic_command=True,
                        is_cell_magic=is_cell_magic,
                    )

                    # Reconstruct the cell content
                    if is_cell_magic:
                        # Preserve comments before the magic command
                        pre_magic = "\n".join(lines[:magic_cmd_index])
                        if pre_magic:
                            new_content = f"{pre_magic}\n{magic_cmd}\n{formatted_sql}"
                        else:
                            new_content = f"{magic_cmd}\n{formatted_sql}"
                    else:
                        # Preserve comments before the magic command
                        pre_magic = "\n".join(lines[:magic_cmd_index])
                        if pre_magic:
                            new_content = f"{pre_magic}\n{magic_cmd} {formatted_sql}"
                        else:
                            new_content = f"{magic_cmd} {formatted_sql}"

                    if new_content != original_code:
                        cell.source = new_content
                        changed = True

                except SQLFormattingError as e:
                    logger.warning(
                        f"[Cell {cell_index}] SQL magic formatting skipped: {e}"
                    )

                continue  # Move to the next cell after handling magic command

            # Handle regular Python code with surgical string replacement
            try:
                tree = ast.parse(original_code)
                line_offsets = build_line_offsets(original_code)
                formatter = SQLStringFormatter(config, dialect, logger, line_offsets)
                formatter.visit(tree)
                if formatter.replacements:
                    result = original_code
                    for rep in sorted(
                        formatter.replacements,
                        key=lambda r: r.start_offset,
                        reverse=True,
                    ):
                        result = (
                            result[: rep.start_offset]
                            + rep.new_text
                            + result[rep.end_offset :]
                        )
                    if result != original_code:
                        cell.source = result
                        changed = True
            except SyntaxError:
                logger.warning(
                    f"[Cell {cell_index}] Failed to parse cell:\n{original_code}"
                )
                continue

        if changed and not check_only:
            nbformat.write(notebook, notebook_path)
            logger.info(f"Updated notebook: {notebook_path}")

        return changed

    except Exception as e:
        logger.error(f"Failed to process notebook {notebook_path}: {e}", exc_info=True)
        raise


def diff_notebook(
    notebook_path: Union[str, Path],
    config: FormattingConfig,
    dialect: Optional[str],
    logger: logging.Logger,
) -> str:
    """Returns a unified diff of formatting changes for a notebook."""
    notebook_path = Path(notebook_path)
    original_nb = nbformat.read(notebook_path, as_version=4)
    formatted_nb = copy.deepcopy(original_nb)

    # Format the copy in-memory by running the same cell logic
    for cell_index, cell in enumerate(formatted_nb.cells):
        if cell.cell_type != "code":
            continue
        original_code = cell.source
        if not original_code.strip():
            continue
        if "# sqlnbfmt: skip" in original_code:
            continue

        lines = original_code.split("\n")
        magic_cmd = None
        magic_cmd_index = None
        for idx, line in enumerate(lines):
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("#"):
                continue
            if stripped.startswith("%%sql") or stripped.startswith("%sql"):
                magic_cmd = stripped.split()[0]
                magic_cmd_index = idx
                break
            else:
                break

        if magic_cmd:
            is_cell_magic = magic_cmd.startswith("%%sql")
            if is_cell_magic:
                sql_code = "\n".join(lines[magic_cmd_index + 1 :]).strip()
            else:
                sql_code = lines[magic_cmd_index][len(magic_cmd) :].strip()
            try:
                formatted_sql = format_sql_code(
                    sql_code,
                    dialect,
                    config,
                    is_magic_command=True,
                    is_cell_magic=is_cell_magic,
                )
                if is_cell_magic:
                    pre_magic = "\n".join(lines[:magic_cmd_index])
                    if pre_magic:
                        new_content = f"{pre_magic}\n{magic_cmd}\n{formatted_sql}"
                    else:
                        new_content = f"{magic_cmd}\n{formatted_sql}"
                else:
                    pre_magic = "\n".join(lines[:magic_cmd_index])
                    if pre_magic:
                        new_content = f"{pre_magic}\n{magic_cmd} {formatted_sql}"
                    else:
                        new_content = f"{magic_cmd} {formatted_sql}"
                cell.source = new_content
            except SQLFormattingError:
                pass
            continue

        try:
            tree = ast.parse(original_code)
            line_offsets = build_line_offsets(original_code)
            formatter = SQLStringFormatter(config, dialect, logger, line_offsets)
            formatter.visit(tree)
            if formatter.replacements:
                result = original_code
                for rep in sorted(
                    formatter.replacements,
                    key=lambda r: r.start_offset,
                    reverse=True,
                ):
                    result = (
                        result[: rep.start_offset]
                        + rep.new_text
                        + result[rep.end_offset :]
                    )
                cell.source = result
        except SyntaxError:
            continue

    # Build unified diff cell-by-cell
    diff_lines = []
    for i, (orig_cell, fmt_cell) in enumerate(
        zip(original_nb.cells, formatted_nb.cells)
    ):
        if orig_cell.source != fmt_cell.source:
            diff_lines.extend(
                difflib.unified_diff(
                    orig_cell.source.splitlines(keepends=True),
                    fmt_cell.source.splitlines(keepends=True),
                    fromfile=f"Cell [{i}] original",
                    tofile=f"Cell [{i}] formatted",
                )
            )
    return "".join(diff_lines)


def main():
    """Main entry point for the SQL formatter."""
    import argparse

    parser = argparse.ArgumentParser(description="Format SQL code in Jupyter notebooks")
    parser.add_argument(
        "notebooks", nargs="+", type=Path, help="Notebook paths to process"
    )
    parser.add_argument(
        "--config", type=Path, default=None, help="Configuration file path (optional)"
    )
    parser.add_argument(
        "--dialect", type=str, help="SQL dialect (e.g., mysql, postgres)"
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Logging level",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check formatting without modifying files (exit code 1 if changes needed)",
    )
    parser.add_argument(
        "--diff",
        action="store_true",
        help="Print a unified diff of formatting changes",
    )

    args = parser.parse_args()
    logger = setup_logging(args.log_level)

    try:
        config = load_config(args.config)
    except FileNotFoundError as e:
        logger.error(
            f"{e}\nHint: --config is optional; omit it to use built-in defaults."
        )
        sys.exit(1)

    try:
        changed = False
        changed_files = []

        for notebook in args.notebooks:
            if args.diff:
                diff_output = diff_notebook(notebook, config, args.dialect, logger)
                if diff_output:
                    print(diff_output, end="")
                    changed = True
                    changed_files.append(notebook)

            if args.check:
                if process_notebook(
                    notebook, config, args.dialect, logger, check_only=True
                ):
                    changed = True
                    changed_files.append(notebook)
            elif not args.diff:
                if process_notebook(notebook, config, args.dialect, logger):
                    changed = True
                    changed_files.append(notebook)

        if args.check:
            if changed:
                logger.error(f"{len(changed_files)} notebook(s) would be reformatted:")
                for f in changed_files:
                    logger.error(f"  - {f}")
                sys.exit(1)
            else:
                logger.info("All notebooks are properly formatted.")
                sys.exit(0)

        # Print summary for normal mode
        if not args.diff:
            if changed:
                logger.info("Changes made to the following notebooks:")
                for file in changed_files:
                    logger.info(f"  - {file}")
            else:
                logger.info("No changes needed. All notebooks are properly formatted.")

        sys.exit(0)

    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
