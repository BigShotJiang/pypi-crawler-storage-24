"""All @tool functions for the lead agent MCP server."""

from __future__ import annotations

import hashlib
import json
import subprocess
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import anyio
from claude_agent_sdk import tool

from openmax.lead_agent.runtime import LeadAgentRuntime, get_lead_agent_runtime
from openmax.lead_agent.types import SubTask, TaskStatus
from openmax.memory import serialize_subtasks
from openmax.output import P, console
from openmax.pane_backend import PaneBackendError
from openmax.pane_manager import PaneManager
from openmax.session_runtime import anchor_payload
from openmax.task_file import (
    append_shared_context,
    delete_checkpoint,
    inject_claude_md,
    list_checkpoint_paths,
    read_checkpoint,
    read_report,
    read_shared_context,
    report_path,
    write_brief,
)

_VALID_PHASE_TRANSITIONS: dict[str, set[str]] = {
    "research": {"plan"},
    "plan": {"implement"},
    "implement": {"verify"},
    "verify": {"finish", "implement"},  # allow re-dispatch via verify → implement
}


def _runtime() -> LeadAgentRuntime:
    return get_lead_agent_runtime()


def _append_session_event(event_type: str, payload: dict[str, Any] | None = None) -> None:
    runtime = _runtime()
    if runtime.session_store is None or runtime.session_meta is None:
        return
    runtime.session_store.append_event(runtime.session_meta, event_type, payload)


def _update_session_phase(phase: str | None) -> None:
    runtime = _runtime()
    if runtime.session_store is None or runtime.session_meta is None or not phase:
        return
    runtime.session_meta.latest_phase = phase
    runtime.session_store.save_meta(runtime.session_meta)


def _upsert_subtask(subtask: SubTask) -> None:
    runtime = _runtime()
    if runtime.plan is None:
        raise RuntimeError("Lead agent plan is not initialized")
    for index, existing in enumerate(runtime.plan.subtasks):
        if existing.name == subtask.name:
            runtime.plan.subtasks[index] = subtask
            return
    runtime.plan.subtasks.append(subtask)


def _record_phase_anchor(phase: str, summary: str, completion_pct: int | None = None) -> None:
    runtime = _runtime()
    if runtime.plan is None:
        return
    normalized_phase = phase.strip().lower()
    payload = anchor_payload(
        phase=normalized_phase,
        summary=summary.strip(),
        tasks=serialize_subtasks(runtime.plan.subtasks),
        completion_pct=completion_pct,
    )
    _append_session_event("phase.anchor", payload)
    _update_session_phase(normalized_phase)


def _tool_response(data: Any) -> dict[str, Any]:
    text = json.dumps(data, ensure_ascii=False) if isinstance(data, (dict, list)) else str(data)
    return {"content": [{"type": "text", "text": text}]}


def _remember_run_summary(notes: str, completion_pct: int) -> None:
    runtime = _runtime()
    if runtime.memory_store is None or runtime.plan is None:
        return
    anchors: list[dict[str, Any]] = []
    if runtime.session_store is not None and runtime.session_meta is not None:
        for event in runtime.session_store.load_events(runtime.session_meta.session_id):
            if event.event_type == "phase.anchor":
                anchors.append(event.payload)
    runtime.memory_store.record_run_summary(
        cwd=runtime.cwd,
        task=runtime.plan.goal,
        notes=notes,
        completion_pct=completion_pct,
        subtasks=serialize_subtasks(runtime.plan.subtasks),
        anchors=anchors,
    )


def _pane_id_for_task(task_name: str) -> int | None:
    for st in _runtime().plan.subtasks:
        if st.name == task_name:
            return st.pane_id
    return None


def _build_blackboard_block(cwd: str) -> str:
    content = read_shared_context(cwd)
    if not content:
        return ""
    return (
        "\n\n## Shared Blackboard\n\n"
        "Read before making architectural decisions:\n\n" + content[:3000]
    )


_CHECKPOINT_PROTOCOL = """

## Checkpoint Protocol

If you reach a decision fork where multiple approaches are valid and the choice
has significant downstream impact, write a structured request:

File: `.openmax/checkpoints/{task_name}.md`

```markdown
## Decision needed
<what you are trying to decide>

## Options
1. <option A> — pros/cons
2. <option B> — pros/cons

## My recommendation
<which option and why>
```

Then pause and wait — do NOT proceed until you receive a decision via message.
Only use this for genuine forks; use your judgment for routine implementation choices.
"""


async def _wait_for_pane_ready(
    pane_mgr: PaneManager,
    pane_id: int,
    ready_patterns: list[str],
    timeout: float = 30.0,
    poll_interval: float = 0.5,
) -> bool:
    """Poll pane output until a ready pattern appears or timeout.

    Uses two strategies:
    1. Pattern match — look for known ready strings in pane output.
    2. Output stability — if the pane has substantial output (≥3 lines)
       and output hasn't changed for 2 consecutive checks, treat as ready.
       This handles CLI version changes where patterns shift.
    """
    if not ready_patterns:
        return False
    deadline = time.monotonic() + timeout
    prev_text = ""
    stable_count = 0
    while time.monotonic() < deadline:
        try:
            text = pane_mgr.get_text(pane_id)
        except Exception:
            text = ""
        # Strategy 1: explicit pattern match
        if any(pat in text for pat in ready_patterns):
            return True
        # Strategy 2: output stabilized with substantial content
        lines = [ln for ln in text.strip().splitlines() if ln.strip()]
        if len(lines) >= 3 and text == prev_text:
            stable_count += 1
            if stable_count >= 2:
                return True
        else:
            stable_count = 0
        prev_text = text
        await anyio.sleep(poll_interval)
    return False


def _extract_smart_output(text: str, tail_lines: int = 100) -> str:
    """Return tail of output, with error lines from earlier surfaced at top."""
    lines = text.splitlines()
    tail = lines[-tail_lines:]
    error_kw = ["Error", "error", "Traceback", "FAILED", "fatal", "exception", "\u274c"]
    error_context = [
        f"[ERROR] {line.strip()}"
        for line in lines[:-tail_lines]
        if any(k in line for k in error_kw)
    ][-20:]
    if error_context:
        return "\n".join(error_context) + "\n---\n" + "\n".join(tail)
    return "\n".join(tail)


@tool(
    "get_agent_recommendations",
    "Get ranked agent recommendations for a task based on workspace memory and similar code work.",
    {"task": str},
)
async def get_agent_recommendations(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    task = args["task"]
    if runtime.memory_store is None:
        return _tool_response("[]")
    rankings = runtime.memory_store.derive_agent_rankings(cwd=runtime.cwd, task=task)
    payload = [
        {
            "agent_type": item.agent_type,
            "score": item.score,
            "reasons": item.reasons,
        }
        for item in rankings
    ]
    return _tool_response(payload)


def _topological_sort_check(subtasks: list[dict[str, Any]]) -> str | None:
    """Return an error message if there is a cycle, else None."""
    name_set = {st["name"] for st in subtasks}
    adj: dict[str, list[str]] = {st["name"]: [] for st in subtasks}
    for st in subtasks:
        for dep in st.get("dependencies", []):
            if dep not in name_set:
                return f"Dependency '{dep}' of subtask '{st['name']}' does not exist"
            adj[dep].append(st["name"])

    visited: set[str] = set()
    in_stack: set[str] = set()

    def dfs(node: str) -> str | None:
        visited.add(node)
        in_stack.add(node)
        for neighbor in adj[node]:
            if neighbor in in_stack:
                return f"Circular dependency detected: {node} -> {neighbor}"
            if neighbor not in visited:
                err = dfs(neighbor)
                if err:
                    return err
        in_stack.discard(node)
        return None

    for name in adj:
        if name not in visited:
            err = dfs(name)
            if err:
                return err
    return None


@tool(
    "submit_plan",
    "Submit a structured task decomposition before dispatching "
    "agents. Validates dependencies (no cycles) and parallel "
    "groups (no conflicts). Call this after planning and before "
    "any dispatch_agent calls.",
    {
        "type": "object",
        "properties": {
            "subtasks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "description": {"type": "string"},
                        "files": {"type": "array", "items": {"type": "string"}},
                        "dependencies": {"type": "array", "items": {"type": "string"}},
                        "estimated_minutes": {"type": "integer"},
                    },
                    "required": ["name", "description"],
                },
            },
            "rationale": {"type": "string"},
            "parallel_groups": {
                "type": "array",
                "items": {"type": "array", "items": {"type": "string"}},
            },
        },
        "required": ["subtasks", "rationale", "parallel_groups"],
    },
)
async def submit_plan(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    subtasks_raw = args.get("subtasks", [])
    rationale = args.get("rationale", "")
    parallel_groups = args.get("parallel_groups", [])

    if not subtasks_raw:
        return _tool_response({"error": "No subtasks provided"})

    # Validate: no circular dependencies
    cycle_err = _topological_sort_check(subtasks_raw)
    if cycle_err:
        return _tool_response({"error": cycle_err})

    # Validate: parallel group members exist
    all_names = {st["name"] for st in subtasks_raw}
    for group in parallel_groups:
        for name in group:
            if name not in all_names:
                return _tool_response({"error": f"Parallel group member '{name}' not in subtasks"})

    # Validate: no dependency conflicts within parallel groups
    dep_map = {st["name"]: set(st.get("dependencies", [])) for st in subtasks_raw}
    for group in parallel_groups:
        for i, a in enumerate(group):
            for b in group[i + 1 :]:
                if a in dep_map.get(b, set()) or b in dep_map.get(a, set()):
                    return _tool_response(
                        {
                            "error": (
                                f"Parallel group conflict: "
                                f"'{a}' and '{b}' have a "
                                "dependency relationship"
                            )
                        }
                    )

    # Warn about file ownership overlaps within parallel groups
    file_map: dict[str, set[str]] = {}
    for st in subtasks_raw:
        files = st.get("files", [])
        if isinstance(files, list):
            file_map[st["name"]] = set(files)
    file_warnings: list[str] = []
    for group in parallel_groups:
        for i, a in enumerate(group):
            for b in group[i + 1 :]:
                overlap = file_map.get(a, set()) & file_map.get(b, set())
                if overlap:
                    file_warnings.append(
                        f"'{a}' and '{b}' share files: {', '.join(sorted(overlap))}"
                    )

    # Store the plan submission
    runtime.plan_submitted = True

    plan_data = {
        "subtasks": subtasks_raw,
        "rationale": rationale,
        "parallel_groups": parallel_groups,
    }

    console.print(f"  [bold cyan]{P}[/bold cyan]  plan: {len(subtasks_raw)} subtasks")
    _append_session_event("tool.submit_plan", plan_data)

    result_data: dict[str, Any] = {
        "status": "accepted",
        "subtask_count": len(subtasks_raw),
        "parallel_group_count": len(parallel_groups),
    }
    if file_warnings:
        result_data["file_overlap_warnings"] = file_warnings
        for warning in file_warnings:
            console.print(f"  [yellow]![/yellow]  File overlap: {warning}")

    return _tool_response(result_data)


def _sanitize_branch_name(task_name: str) -> str:
    """Convert task name to a valid git branch name."""
    import re

    slug = re.sub(r"[^a-zA-Z0-9_-]", "-", task_name.strip())
    slug = re.sub(r"-+", "-", slug).strip("-")
    return f"openmax/{slug}" if slug else f"openmax/task-{int(time.time())}"


def _get_integration_branch(cwd: str) -> str | None:
    """Get the current git branch name, or None if not in a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    return None


def _branch_exists(cwd: str, branch_name: str) -> bool:
    r = subprocess.run(
        ["git", "rev-parse", "--verify", branch_name],
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=10,
    )
    return r.returncode == 0


def _worktree_is_valid(worktree_dir: Path) -> bool:
    return (worktree_dir / ".git").exists()


def _create_agent_branch(cwd: str, branch_name: str) -> tuple[str | None, str | None]:
    """Create or reuse a git branch and worktree for an agent.

    Returns (worktree_path, error_message). On success error_message is None.
    """
    worktree_base = Path(cwd) / ".openmax-worktrees"
    worktree_dir = worktree_base / branch_name.replace("/", "_")

    try:
        # Reuse existing branch + worktree if both are valid
        if _branch_exists(cwd, branch_name) and _worktree_is_valid(worktree_dir):
            return str(worktree_dir), None

        # Branch exists but worktree is gone — prune stale worktree ref, recreate
        if _branch_exists(cwd, branch_name):
            subprocess.run(
                ["git", "worktree", "prune"],
                cwd=cwd,
                capture_output=True,
                timeout=10,
            )
            if _worktree_is_valid(worktree_dir):
                return str(worktree_dir), None
            return _add_worktree(cwd, worktree_dir, branch_name, cleanup_branch=False)

        # Fresh: create branch + worktree
        result = subprocess.run(
            ["git", "branch", branch_name],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return None, f"Failed to create branch: {result.stderr.strip()}"
        return _add_worktree(cwd, worktree_dir, branch_name, cleanup_branch=True)
    except (OSError, subprocess.TimeoutExpired) as e:
        return None, f"Git error: {e}"


def _add_worktree(
    cwd: str,
    worktree_dir: Path,
    branch_name: str,
    *,
    cleanup_branch: bool = True,
) -> tuple[str | None, str | None]:
    """Add a git worktree for an existing branch. Returns (path, error)."""
    worktree_dir.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["git", "worktree", "add", str(worktree_dir), branch_name],
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        if cleanup_branch:
            subprocess.run(
                ["git", "branch", "-D", branch_name],
                cwd=cwd,
                capture_output=True,
                timeout=10,
            )
        return None, f"Failed to create worktree: {result.stderr.strip()}"
    return str(worktree_dir), None


def _cleanup_agent_branch(cwd: str, branch_name: str) -> str | None:
    """Remove worktree and delete branch. Returns error message or None."""
    worktree_base = Path(cwd) / ".openmax-worktrees"
    worktree_dir = worktree_base / branch_name.replace("/", "_")

    try:
        if worktree_dir.exists():
            subprocess.run(
                ["git", "worktree", "remove", str(worktree_dir), "--force"],
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=30,
            )
        subprocess.run(
            ["git", "branch", "-D", branch_name],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired) as e:
        return f"Cleanup error: {e}"
    return None


def _git_run(
    args: list[str],
    cwd: str,
    timeout: int = 30,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _parse_conflict_files(merge_stderr: str) -> list[str]:
    return [
        line.split("Merge conflict in ")[-1].strip()
        for line in merge_stderr.splitlines()
        if "Merge conflict in " in line
    ]


def _merge_and_handle_conflicts(
    cwd: str,
    branch: str,
    target: str,
) -> tuple[str, str | None, list[str], str]:
    """Merge branch into target. Returns (status, commit_hash, conflict_files, diff)."""
    _git_run(["git", "checkout", target], cwd)
    merge = _git_run(["git", "merge", "--no-edit", branch], cwd, timeout=60)
    if merge.returncode == 0:
        head = _git_run(["git", "rev-parse", "HEAD"], cwd, timeout=10)
        return ("merged", head.stdout.strip(), [], "")
    diff = _git_run(["git", "diff", f"{target}...{branch}"], cwd, timeout=30)
    _git_run(["git", "merge", "--abort"], cwd)
    return ("conflict", None, _parse_conflict_files(merge.stderr), diff.stdout[:8000])


def _report_merge_success(branch: str, integration: str, short_hash: str) -> str:
    console.print(
        f"  [bold green]\u2713[/bold green]  Merged {branch} \u2192 {integration} ({short_hash})"
    )
    _append_session_event(
        "tool.auto_merge",
        {"branch": branch, "status": "merged", "commit": short_hash},
    )
    return f"Merged {branch} \u2192 {integration} ({short_hash})"


def _report_merge_conflict(branch: str, conflict_files: list[str]) -> str:
    console.print(
        f"  [bold red]\u2717[/bold red]  Merge conflict for {branch}: {len(conflict_files)} file(s)"
    )
    _append_session_event(
        "tool.auto_merge",
        {"branch": branch, "status": "conflict", "files": conflict_files},
    )
    return (
        f"Merge conflict for {branch}: {', '.join(conflict_files)}. "
        "Use merge_agent_branch tool to resolve."
    )


def _auto_merge_branch(runtime: LeadAgentRuntime, subtask: SubTask) -> str:
    branch = subtask.branch_name
    if not branch:
        return ""
    integration = runtime.integration_branch or "main"
    try:
        status, commit_hash, files, _diff = _merge_and_handle_conflicts(
            runtime.cwd,
            branch,
            integration,
        )
    except (OSError, subprocess.TimeoutExpired) as e:
        console.print(f"  [bold red]\u2717[/bold red]  Auto-merge error: {e}")
        return f"Auto-merge error: {e}"
    if status == "merged":
        _cleanup_agent_branch(runtime.cwd, branch)
        return _report_merge_success(
            branch,
            integration,
            (commit_hash or "")[:8],
        )
    return _report_merge_conflict(branch, files)


def _launch_pane(
    runtime: LeadAgentRuntime,
    command: list[str] | str,
    purpose: str,
    agent_type: str = "tool",
    title: str | None = None,
    cwd: str | None = None,
    env: dict[str, str] | None = None,
) -> SimpleNamespace:
    if runtime.agent_window_id is None:
        pane = runtime.pane_mgr.create_window(
            command=command,
            purpose=purpose,
            agent_type=agent_type,
            title=title,
            cwd=cwd or runtime.cwd,
            env=env,
        )
        runtime.agent_window_id = pane.window_id
    else:
        pane = runtime.pane_mgr.add_pane(
            window_id=runtime.agent_window_id,
            command=command,
            purpose=purpose,
            agent_type=agent_type,
            title=title,
            cwd=cwd or runtime.cwd,
            env=env,
        )
    return pane


def _safe_launch_pane(
    runtime: LeadAgentRuntime,
    *,
    command: list[str] | str,
    purpose: str,
    agent_type: str,
    title: str | None = None,
    cwd: str | None = None,
    env: dict[str, str] | None = None,
) -> tuple[SimpleNamespace | None, str | None]:
    """Launch a pane with error handling. Returns (pane, error_message)."""
    try:
        pane = _launch_pane(
            runtime,
            command=command,
            purpose=purpose,
            agent_type=agent_type,
            title=title,
            cwd=cwd,
            env=env,
        )
        return pane, None
    except PaneBackendError as e:
        return None, f"Pane backend error: {e}"
    except RuntimeError as e:
        return None, f"Pane launch failed: {e}"
    except OSError as e:
        return None, f"OS error during pane launch: {e}"


def _try_reuse_done_pane(
    runtime: LeadAgentRuntime, agent_type: str, task_name: str
) -> SimpleNamespace | None:
    """Find a done pane with the same agent type to reuse.

    Only reuses a pane if no other running/pending task is already occupying it.
    This prevents multiple parallel tasks from being funneled into the same pane.
    """
    # Collect pane IDs that are currently in use by running or pending tasks.
    busy_panes: set[int] = set()
    for st in runtime.plan.subtasks:
        if st.status in (TaskStatus.RUNNING, TaskStatus.PENDING) and st.pane_id is not None:
            busy_panes.add(st.pane_id)

    for st in runtime.plan.subtasks:
        if (
            st.agent_type == agent_type
            and st.status == TaskStatus.DONE
            and st.pane_id is not None
            and st.pane_id not in busy_panes
            and runtime.pane_mgr.is_pane_alive(st.pane_id)
        ):
            console.print(f"  [dim]{P}  reusing pane {st.pane_id} for {task_name}[/dim]")
            return SimpleNamespace(
                pane_id=st.pane_id,
                window_id=runtime.agent_window_id,
            )
    return None


async def _wait_and_send_prompt(
    runtime: LeadAgentRuntime,
    pane: SimpleNamespace,
    cmd_spec: Any,
    agent_type: str,
) -> None:
    """Wait for CLI ready then send the initial prompt."""
    if cmd_spec.ready_patterns:
        ready = await _wait_for_pane_ready(
            runtime.pane_mgr,
            pane.pane_id,
            cmd_spec.ready_patterns,
            timeout=max(cmd_spec.ready_delay_seconds * 4, 30.0),
        )
        if not ready:
            console.print(
                f"  [yellow]![/yellow]Pane {pane.pane_id} ({agent_type}) "
                "did not show ready signal within timeout \u2014 sending prompt anyway"
            )
    else:
        await anyio.sleep(cmd_spec.ready_delay_seconds)
    runtime.pane_mgr.send_text(pane.pane_id, cmd_spec.initial_input)


def _compress_context(context: str, budget: int) -> str:
    """Compress context text to fit within an approximate token budget.

    Uses len(text)//4 as a rough token estimate. If over budget, keeps the
    first paragraph and as many subsequent bullet/numbered-list lines as fit.
    """
    approx_tokens = len(context) // 4
    if approx_tokens <= budget:
        return context

    char_budget = budget * 4
    lines = context.split("\n")

    # Always keep the first paragraph (up to first blank line)
    kept: list[str] = []
    i = 0
    while i < len(lines):
        kept.append(lines[i])
        if lines[i].strip() == "" and i > 0:
            i += 1
            break
        i += 1

    # Then greedily add bullet/heading lines that fit
    for line in lines[i:]:
        stripped = line.lstrip()
        is_key_line = stripped.startswith(("-", "*", "#")) or (
            len(stripped) > 1 and stripped[0].isdigit() and stripped[1] in ".)"
        )
        if not is_key_line:
            continue
        candidate = "\n".join(kept + [line])
        if len(candidate) <= char_budget:
            kept.append(line)
        else:
            break

    result = "\n".join(kept)
    if len(result) > char_budget:
        result = result[:char_budget].rsplit("\n", 1)[0]
    return result


def _build_subagent_context(
    *,
    branch_name: str | None,
    agent_cwd: str | None = None,
    memory_text: str | None,
) -> str:
    """Build a structured context block for sub-agent prompts.

    Returns empty string when there is nothing to inject.
    """
    sections: list[str] = []

    if agent_cwd:
        sections.append(
            f"Working directory: {agent_cwd}\n"
            f"You are already in the correct directory. Do NOT run `cd`."
        )

    if branch_name:
        sections.append(
            f"Branch: {branch_name} (isolated worktree — commit here, do not switch branches)"
        )

    if memory_text:
        sections.append(f"Relevant history:\n{memory_text}")

    if not sections:
        return ""

    header = "## Context (auto-injected by openMax — use only if relevant)"
    return "\n\n" + header + "\n\n" + "\n\n".join(sections)


def _read_subtask_report(task_name: str) -> str | None:
    """Try to read a subtask's completion report from known locations."""
    runtime = _runtime()
    for st in runtime.plan.subtasks:
        if st.name == task_name and st.branch_name:
            wt = str(Path(runtime.cwd) / ".openmax-worktrees" / st.branch_name.replace("/", "_"))
            report = read_report(wt, task_name)
            if report:
                return report
    return read_report(runtime.cwd, task_name)


def _persist_report_to_main(runtime: LeadAgentRuntime, task_name: str, text: str) -> None:
    """Copy report to main cwd so it survives worktree cleanup."""
    if read_report(runtime.cwd, task_name) is None:
        rp = report_path(runtime.cwd, task_name)
        rp.parent.mkdir(parents=True, exist_ok=True)
        rp.write_text(text, encoding="utf-8")


def _save_pane_log(runtime: LeadAgentRuntime, st: SubTask) -> Path | None:
    """Save full pane output to .openmax/logs/{task_name}.log (up to 2000 lines)."""
    try:
        text = runtime.pane_mgr.get_text(st.pane_id)
    except Exception:
        return None
    if not text or len(text.strip()) < 20:
        return None
    lines = text.splitlines()
    log_dir = Path(runtime.cwd) / ".openmax" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"{st.name}.log"
    log_path.write_text("\n".join(lines), encoding="utf-8")
    return log_path


def _synthesize_report_from_pane(runtime: LeadAgentRuntime, st: SubTask) -> str | None:
    """Fallback: synthesize a minimal report from the saved pane log."""
    log_path = Path(runtime.cwd) / ".openmax" / "logs" / f"{st.name}.log"
    if not log_path.exists():
        return None
    content = log_path.read_text(encoding="utf-8")
    tail = _extract_smart_output(content, tail_lines=50)
    log_rel = log_path.relative_to(runtime.cwd)
    return (
        f"## Status\ndone (auto-synthesized)\n\n"
        f"## Full Log\n`{log_rel}`\n\n"
        f"## Output (last lines)\n```\n{tail}\n```"
    )


def _read_subtask_report_for_pane(pane_id: int) -> str | None:
    runtime = _runtime()
    for st in runtime.plan.subtasks:
        if st.pane_id == pane_id:
            return _read_subtask_report(st.name)
    return None


def _file_protocol_section(brief_file: Path, rep_file: Path, cwd: str) -> str:
    """Build the file protocol instructions to append to agent prompts."""
    brief_rel = brief_file.relative_to(cwd)
    report_rel = rep_file.relative_to(cwd)
    return (
        f"\n\n## File Protocol (openMax)\n\n"
        f"Your full task brief is saved at: `{brief_rel}`\n\n"
        f"When you finish, write a completion report to: "
        f"`{report_rel}`\n\n"
        f"Report format:\n"
        f"```\n"
        f"## Status\n"
        f"done | error | partial\n\n"
        f"## Summary\n"
        f"<What was accomplished>\n\n"
        f"## Changes\n"
        f"- <file>: <what changed>\n\n"
        f"## Test Results\n"
        f"<pass/fail details>\n"
        f"```"
    )


@tool(
    "dispatch_agent",
    "Dispatch a sub-task to an AI agent in a terminal pane. "
    "The prompt is the agent's ONLY context \u2014 include file paths, constraints, "
    "and any knowledge it cannot discover on its own. "
    "All agents share one window with smart grid layout. Returns pane_id.",
    {
        "type": "object",
        "properties": {
            "task_name": {"type": "string"},
            "agent_type": {"type": "string"},
            "prompt": {"type": "string"},
            "override_reason": {"type": "string"},
            "retry_count": {"type": "integer"},
            "context_budget_tokens": {"type": "integer"},
            "token_budget": {"type": "integer"},
        },
        "required": ["task_name", "agent_type", "prompt"],
    },
)
async def dispatch_agent(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    task_name = args["task_name"]
    agent_type = args.get("agent_type", "claude-code")
    prompt = args["prompt"]
    retry_count = args.get("retry_count", 0)
    token_budget = args.get("token_budget")
    if not isinstance(retry_count, int) or retry_count < 0:
        retry_count = 0

    # For retries, allow re-dispatch of the same task (update in place).
    # Otherwise, prevent duplicate task names with auto-suffix.
    existing_names = {st.name for st in runtime.plan.subtasks}
    is_retry = retry_count > 0 and task_name in existing_names
    if task_name in existing_names and not is_retry:
        suffix = 2
        while f"{task_name}-{suffix}" in existing_names:
            suffix += 1
        original = task_name
        task_name = f"{task_name}-{suffix}"
        console.print(
            f"  [yellow]![/yellow]Task '{original}' already exists, renamed to '{task_name}'"
        )

    # Auto-derive recommended agent from memory rankings
    recommended_agent = None
    if runtime.memory_store is not None:
        try:
            rankings = runtime.memory_store.derive_agent_rankings(cwd=runtime.cwd, task=task_name)
            if rankings:
                recommended_agent = rankings[0].agent_type
        except Exception:
            pass

    # Enforce allowed agents constraint
    if runtime.allowed_agents:
        if agent_type not in runtime.allowed_agents:
            fallback = runtime.allowed_agents[0]
            console.print(
                f"  [yellow]![/yellow]Agent '{agent_type}' not allowed, using '{fallback}' instead"
            )
            agent_type = fallback

    adapter = runtime.agent_registry.get(agent_type)
    if adapter is None:
        fallback = runtime.agent_registry.default_agent_name()
        if fallback is None:
            raise RuntimeError("No agents are configured")
        console.print(
            f"  [yellow]![/yellow]Agent '{agent_type}' not configured, using '{fallback}' instead"
        )
        agent_type = fallback
        adapter = runtime.agent_registry.get(agent_type)
    if adapter is None:
        raise RuntimeError(f"Agent '{agent_type}' is unavailable")

    # Gather memory context (compressed)
    memory_text: str | None = None
    context_budget = args.get("context_budget_tokens", 2000)
    if not isinstance(context_budget, int) or context_budget < 0:
        context_budget = 2000
    if runtime.memory_store is not None:
        try:
            memory_context = runtime.memory_store.build_context(
                cwd=runtime.cwd,
                task=task_name,
            )
            if memory_context and memory_context.text:
                memory_text = _compress_context(memory_context.text, context_budget)
        except Exception:
            pass  # Don't fail dispatch if memory lookup fails

    # -- Branch isolation: create per-agent branch + worktree --
    branch_name: str | None = None
    agent_cwd = runtime.cwd

    if runtime.integration_branch is None:
        runtime.integration_branch = _get_integration_branch(runtime.cwd)

    branch_name_candidate = _sanitize_branch_name(task_name)
    worktree_path, branch_err = _create_agent_branch(runtime.cwd, branch_name_candidate)
    if worktree_path is not None:
        branch_name = branch_name_candidate
        agent_cwd = worktree_path
        inject_claude_md(agent_cwd, task_name)
        console.print(f"  [dim]{P}  branch {branch_name} → {worktree_path}[/dim]")
    elif branch_err:
        console.print(f"  [yellow]![/yellow]  Branch isolation skipped: {branch_err}")

    # Inject structured context (git branch + memory)
    context_block = _build_subagent_context(
        branch_name=branch_name,
        agent_cwd=agent_cwd,
        memory_text=memory_text,
    )
    if context_block:
        prompt = prompt + context_block

    blackboard_block = _build_blackboard_block(agent_cwd if agent_cwd else runtime.cwd)
    if blackboard_block:
        prompt = prompt + blackboard_block
    prompt = prompt + _CHECKPOINT_PROTOCOL.format(task_name=task_name)

    # Write brief to agent_cwd (worktree) AND main cwd (survives worktree cleanup)
    brief_file = write_brief(agent_cwd, task_name, prompt)
    if agent_cwd != runtime.cwd:
        write_brief(runtime.cwd, task_name, prompt)
    rep_file = report_path(agent_cwd, task_name)
    prompt = prompt + _file_protocol_section(brief_file, rep_file, agent_cwd)

    cmd_spec = adapter.get_command(prompt, cwd=agent_cwd)
    launch_env = cmd_spec.env or None

    # -- Try to reuse a done pane with the same agent type --
    # Skip reuse when agent runs in a worktree: /clear resets the conversation
    # but the process stays in the old cwd, causing the agent to `cd` repeatedly.
    has_worktree = agent_cwd != runtime.cwd
    reused_pane = None if has_worktree else _try_reuse_done_pane(runtime, agent_type, task_name)

    if reused_pane is not None:
        pane = reused_pane
        runtime.pane_mgr.send_text(pane.pane_id, "/clear")
        await anyio.sleep(1.0)
        if cmd_spec.interactive and cmd_spec.initial_input:
            runtime.pane_mgr.send_text(pane.pane_id, cmd_spec.initial_input)
    else:
        pane, launch_err = _safe_launch_pane(
            runtime,
            command=cmd_spec.launch_cmd,
            purpose=task_name,
            agent_type=agent_type,
            title=f"openMax: {runtime.plan.goal[:40]}",
            cwd=agent_cwd,
            env=launch_env,
        )
        if pane is None:
            console.print(f"  [bold red]\u2717[/bold red]  dispatch failed: {launch_err}")
            _append_session_event(
                "tool.dispatch_agent.failed",
                {
                    "task_name": task_name,
                    "agent_type": agent_type,
                    "error": launch_err,
                    "branch_name": branch_name,
                },
            )
            return _tool_response(
                {
                    "status": "error",
                    "error": launch_err,
                    "task_name": task_name,
                    "agent_type": agent_type,
                    "remediation": (
                        "Check that the terminal backend (kaku/tmux) is running. "
                        "Run 'openmax doctor' for diagnostics."
                    ),
                }
            )
        if cmd_spec.interactive and cmd_spec.initial_input:
            await _wait_and_send_prompt(
                runtime,
                pane,
                cmd_spec,
                agent_type,
            )

    subtask = SubTask(
        name=task_name,
        agent_type=agent_type,
        prompt=prompt,
        status=TaskStatus.RUNNING,
        pane_id=pane.pane_id,
        retry_count=retry_count,
        branch_name=branch_name,
        started_at=time.time(),
        token_budget=token_budget,
    )
    _upsert_subtask(subtask)
    if runtime.dashboard is not None:
        runtime.dashboard.update_subtask(
            task_name,
            agent_type,
            pane.pane_id,
            "running",
            started_at=subtask.started_at,
        )

    # Show layout info
    win = runtime.pane_mgr.windows.get(runtime.agent_window_id)
    pane_count = len(win.pane_ids) if win else 1
    console.print(
        f"  [bold cyan]{P}[/bold cyan]  [bold]{task_name}[/bold]"
        f" \u2192 pane {pane.pane_id} [dim]({agent_type})[/dim]"
    )
    if retry_count > 0:
        console.print(f"  [yellow]↻[/yellow]  Retrying '{task_name}' (attempt {retry_count + 1})")
    event_payload = {
        "task_name": task_name,
        "agent_type": agent_type,
        "prompt": prompt,
        "pane_id": pane.pane_id,
        "window_id": runtime.agent_window_id,
        "panes_in_window": pane_count,
        "recommended_agent": recommended_agent,
        "retry_count": retry_count,
        "branch_name": branch_name,
    }
    override_reason = args.get("override_reason")
    if override_reason:
        event_payload["override_reason"] = override_reason
    _append_session_event("tool.dispatch_agent", event_payload)

    return _tool_response(
        {
            "status": "dispatched",
            "pane_id": pane.pane_id,
            "window_id": runtime.agent_window_id,
            "agent_type": agent_type,
            "task_name": task_name,
            "panes_in_window": pane_count,
            "retry_count": retry_count,
            "branch_name": branch_name,
            "token_budget": token_budget,
        }
    )


def _check_budget_warning(task_name: str, used: int, budget: int) -> str | None:
    """Check token budget and return warning level if threshold exceeded."""
    if used >= budget:
        return "hard_limit"
    if used >= 0.8 * budget:
        return "soft_limit"
    return None


_STUCK_THRESHOLD = 3  # consecutive identical outputs to trigger stuck
_MAX_RETRIES = 2


def _get_retry_info_for_pane(pane_id: int) -> dict[str, Any]:
    """Look up retry_count and max_retries for the subtask owning this pane."""
    runtime = _runtime()
    for st in runtime.plan.subtasks:
        if st.pane_id == pane_id:
            return {
                "retry_count": st.retry_count,
                "max_retries": st.max_retries,
                "task_name": st.name,
                "can_retry": st.retry_count < st.max_retries,
            }
    return {}


@tool(
    "read_pane_output",
    "Read agent pane output. If pane_id is given, returns ~100 tail lines with "
    "stuck/exited detection. If pane_id is omitted or -1, lists all managed panes "
    "and their states (replaces list_managed_panes).",
    {"pane_id": int},
)
async def read_pane_output(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    pane_id = args.get("pane_id", -1)

    # List all panes mode
    if pane_id == -1:
        runtime.pane_mgr.refresh_states()
        summary = runtime.pane_mgr.summary()
        return _tool_response(summary)
    try:
        pane_alive = runtime.pane_mgr.is_pane_alive(pane_id)

        # get_text returns cached output even if pane is dead.
        try:
            text = runtime.pane_mgr.get_text(pane_id)
        except Exception:
            text = ""

        if not pane_alive:
            text = _extract_smart_output(text, tail_lines=100) if text else ""
            # Look up subtask retry info for the exited pane
            retry_info = _get_retry_info_for_pane(pane_id)
            response: dict[str, Any] = {
                "text": text or "(pane no longer exists)",
                "stuck": False,
                "exited": True,
            }
            report = _read_subtask_report_for_pane(pane_id)
            if report:
                response["report"] = report[:4000]
            response.update(retry_info)
            event_payload: dict[str, Any] = {
                "pane_id": pane_id,
                "preview": text[:500],
                "stuck": False,
                "exited": True,
            }
            event_payload.update(retry_info)
            _append_session_event("tool.read_pane_output", event_payload)
            return _tool_response(response)

        text = _extract_smart_output(text, tail_lines=100)

        # Track output hashes for stuck detection
        output_hash = hashlib.md5(text.encode(), usedforsecurity=False).hexdigest()
        hash_history = runtime.pane_output_hashes.setdefault(pane_id, [])
        hash_history.append(output_hash)
        # Keep only the last _STUCK_THRESHOLD entries
        if len(hash_history) > _STUCK_THRESHOLD:
            runtime.pane_output_hashes[pane_id] = hash_history[-_STUCK_THRESHOLD:]
            hash_history = runtime.pane_output_hashes[pane_id]

        stuck = (
            len(hash_history) >= _STUCK_THRESHOLD
            and len(set(hash_history[-_STUCK_THRESHOLD:])) == 1
        )

        # Check if pane exited
        pane_alive = runtime.pane_mgr.is_pane_alive(pane_id)
        exited = not pane_alive

        response_data: dict[str, Any] = {
            "text": text,
            "stuck": stuck,
            "exited": exited,
        }

        # Add budget status if a budget is set for this pane's subtask
        for st in runtime.plan.subtasks:
            if st.pane_id == pane_id and st.token_budget is not None:
                warning = _check_budget_warning(st.name, st.tokens_used, st.token_budget)
                response_data["budget"] = {
                    "token_budget": st.token_budget,
                    "tokens_used": st.tokens_used,
                    "warning": warning,
                }
                break

        _append_session_event(
            "tool.read_pane_output",
            {
                "pane_id": pane_id,
                "preview": text[:500],
                "stuck": stuck,
                "exited": exited,
            },
        )
        return _tool_response(response_data)
    except RuntimeError as e:
        return _tool_response(f"Error: {e}")


@tool(
    "send_text_to_pane",
    "Send text to an agent pane. Use to answer agent questions, correct drift, "
    "or give follow-up instructions. Text is pasted and submitted automatically.",
    {"pane_id": int, "text": str},
)
async def send_text_to_pane(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    pane_id = args["pane_id"]
    text = args["text"]
    if not runtime.pane_mgr.is_pane_alive(pane_id):
        return _tool_response(
            f"Error: pane {pane_id} no longer exists. Re-dispatch the task to a new pane."
        )
    runtime.pane_mgr.send_text(pane_id, text)
    # core.py already prints the intervention line.
    if runtime.dashboard is not None:
        runtime.dashboard.update_pane_activity(pane_id, text[:80])
    _append_session_event(
        "tool.send_text_to_pane",
        {
            "pane_id": pane_id,
            "text": text,
        },
    )
    return _tool_response(f"Sent to pane {pane_id}")


@tool(
    "list_managed_panes",
    "List all managed panes and their current states.",
    {},
)
async def list_managed_panes(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    runtime.pane_mgr.refresh_states()
    summary = runtime.pane_mgr.summary()
    return _tool_response(summary)


@tool(
    "mark_task_done",
    "Mark a sub-task as completed. Call only after verifying the agent has "
    "committed its changes and output looks correct.",
    {"task_name": str, "notes": str},
)
async def mark_task_done(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    task_name = args["task_name"]
    notes = args.get("notes", "").strip()
    for st in runtime.plan.subtasks:
        if st.name == task_name:
            st.status = TaskStatus.DONE
            st.finished_at = time.time()
            # Always save full pane output as log backup
            if st.pane_id is not None:
                _save_pane_log(runtime, st)
            report_text = _read_subtask_report(task_name)
            if report_text is None:
                report_text = _synthesize_report_from_pane(runtime, st)
            if report_text:
                st.completion_notes = report_text[:2000]
                _persist_report_to_main(runtime, task_name, report_text)
            if notes:
                st.completion_notes = notes
            console.print(f"  [bold green]\u2713[/bold green]  [bold]{task_name}[/bold] done")
            if runtime.dashboard is not None:
                runtime.dashboard.update_subtask(
                    task_name,
                    st.agent_type,
                    st.pane_id,
                    "done",
                    started_at=st.started_at,
                    finished_at=st.finished_at,
                )
            _append_session_event("tool.mark_task_done", {"task_name": task_name})

            # Auto-merge branch back to integration branch if isolated
            merge_note = ""
            if st.branch_name:
                merge_note = _auto_merge_branch(runtime, st)

            msg = f"Marked '{task_name}' as done"
            if merge_note:
                msg += f". {merge_note}"
            return _tool_response(msg)
    return _tool_response(f"Task '{task_name}' not found")


def _find_subtask_by_name(task_name: str) -> SubTask | None:
    runtime = _runtime()
    for st in runtime.plan.subtasks:
        if st.name == task_name:
            return st
    return None


def _merge_branch_result(
    task_name: str,
    status: str,
    commit_hash: str | None,
    conflict_files: list[str],
    diff: str,
    branch: str,
    integration: str,
) -> dict[str, Any]:
    if status == "merged":
        short = commit_hash[:8] if commit_hash else ""
        console.print(
            f"  [bold green]\u2713[/bold green]  Merged {branch} \u2192 {integration} ({short})"
        )
        data: dict[str, Any] = {
            "status": "merged",
            "commit": commit_hash,
            "task_name": task_name,
        }
    else:
        console.print(
            f"  [bold red]\u2717[/bold red]  Merge conflict for"
            f" {branch}: {len(conflict_files)} file(s)"
        )
        data = {
            "status": "conflict",
            "task_name": task_name,
            "files": conflict_files,
            "diff": diff,
            "resolve_hint": (
                f"Dispatch a claude-code agent to: cd into the repo, run "
                f"`git merge {branch}`, read the conflict markers in each file, "
                f"understand the semantic intent of both sides from the diff above, "
                f"resolve intelligently, then `git add` and `git commit`."
            ),
        }
    _append_session_event("tool.merge_agent_branch", data)
    return data


def _merge_error_response(task_name: str, error: Exception) -> dict[str, Any]:
    msg = f"Git merge error: {error}"
    console.print(f"  [bold red]\u2717[/bold red]  {msg}")
    data: dict[str, Any] = {
        "status": "error",
        "task_name": task_name,
        "error": msg,
    }
    _append_session_event("tool.merge_agent_branch", data)
    return _tool_response(data)


@tool(
    "merge_agent_branch",
    "Merge an agent's branch back to the integration branch. "
    "Call after mark_task_done when the agent worked on an isolated branch. "
    "Returns {status, commit} on success or {status, files, diff} on conflict.",
    {"task_name": str},
)
async def merge_agent_branch(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    task_name = args["task_name"]
    target = _find_subtask_by_name(task_name)
    if target is None:
        return _tool_response({"error": f"Task '{task_name}' not found"})
    if not target.branch_name:
        return _tool_response(
            {"status": "skipped", "reason": "No branch for this task"},
        )
    integration = runtime.integration_branch or "main"
    try:
        status, hash_, files, diff = _merge_and_handle_conflicts(
            runtime.cwd,
            target.branch_name,
            integration,
        )
    except (OSError, subprocess.TimeoutExpired) as e:
        return _merge_error_response(task_name, e)
    if status == "merged":
        _cleanup_agent_branch(runtime.cwd, target.branch_name)
    return _tool_response(
        _merge_branch_result(
            task_name,
            status,
            hash_,
            files,
            diff,
            target.branch_name,
            integration,
        )
    )


@tool(
    "record_phase_anchor",
    "Persist a concise workflow anchor when a lifecycle phase is completed.",
    {"phase": str, "summary": str, "completion_pct": int},
)
async def record_phase_anchor(args: dict[str, Any]) -> dict[str, Any]:
    phase = args["phase"]
    summary = args["summary"]
    completion_pct = args.get("completion_pct")
    _record_phase_anchor(phase, summary, completion_pct)
    runtime = _runtime()
    if runtime.dashboard is not None:
        runtime.dashboard.update_phase(phase, completion_pct)
    # No console output \u2014 internal bookkeeping, not user-facing.
    return _tool_response(f"Recorded anchor for phase '{phase}'")


@tool(
    "transition_phase",
    "Transition between workflow phases. Validates from_phase matches current, "
    "gate_summary is descriptive. Records phase.anchor event and updates session phase.",
    {
        "type": "object",
        "properties": {
            "from_phase": {"type": "string"},
            "to_phase": {"type": "string"},
            "gate_summary": {"type": "string"},
            "artifacts": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["from_phase", "to_phase", "gate_summary", "artifacts"],
    },
)
async def transition_phase(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    from_phase = args.get("from_phase", "").strip().lower()
    to_phase = args.get("to_phase", "").strip().lower()
    gate_summary = args.get("gate_summary", "").strip()
    artifacts = args.get("artifacts", [])

    # Validate gate_summary length
    if len(gate_summary) < 20:
        return _tool_response(
            f"Error: gate_summary must be at least 20 characters (got {len(gate_summary)})"
        )

    # Validate from_phase matches current phase on the runtime
    current = runtime.current_phase
    if from_phase != current:
        return _tool_response(
            f"Error: from_phase '{from_phase}' does not match current phase '{current}'"
        )

    # Validate to_phase is a valid next phase
    allowed = _VALID_PHASE_TRANSITIONS.get(from_phase)
    if allowed is None or to_phase not in allowed:
        valid_str = ", ".join(sorted(allowed)) if allowed else "none"
        return _tool_response(
            f"Error: invalid transition '{from_phase}' \u2192 '{to_phase}'. "
            f"Valid next phases: {valid_str}"
        )

    # Update current phase on the runtime
    runtime.current_phase = to_phase

    # Record phase anchor and update session
    _record_phase_anchor(to_phase, gate_summary)

    # Update dashboard if available
    if runtime.dashboard:
        runtime.dashboard.update_phase(to_phase)

    _append_session_event(
        "tool.transition_phase",
        {
            "from_phase": from_phase,
            "to_phase": to_phase,
            "gate_summary": gate_summary,
            "artifacts": artifacts,
        },
    )

    return _tool_response(f"Transitioned from '{from_phase}' to '{to_phase}'")


@tool(
    "remember_learning",
    "Store a reusable lesson so future runs in this workspace can improve automatically.",
    {"lesson": str, "rationale": str, "confidence": int},
)
async def remember_learning(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    lesson = args["lesson"]
    rationale = args.get("rationale", "")
    confidence = args.get("confidence")
    if runtime.memory_store is None:
        return _tool_response("Memory store unavailable")
    runtime.memory_store.record_lesson(
        cwd=runtime.cwd,
        task=runtime.plan.goal,
        lesson=lesson,
        rationale=rationale,
        confidence=confidence,
    )
    # No console output \u2014 internal bookkeeping.
    return _tool_response("Stored reusable lesson")


@tool(
    "report_completion",
    "Report overall goal completion percentage and summary. Call exactly once "
    "when all tasks are done. Describe what was delivered, not what was attempted. "
    "This saves a run summary to workspace memory.",
    {"completion_pct": int, "notes": str},
)
async def report_completion(args: dict[str, Any]) -> dict[str, Any]:
    pct = args["completion_pct"]
    notes = args["notes"]
    from rich.panel import Panel

    pct_color = "green" if pct >= 80 else "yellow" if pct >= 50 else "red"
    panel = Panel(
        f"  [{pct_color}]{pct}%[/{pct_color}] complete\n  {notes}",
        title="[bold]Result[/bold]",
        title_align="left",
        border_style="dim cyan",
        padding=(0, 2),
    )
    console.print()
    console.print(panel)
    _append_session_event(
        "tool.report_completion",
        {
            "completion_pct": pct,
            "notes": notes,
        },
    )
    _record_phase_anchor("report", notes, pct)
    _remember_run_summary(notes, pct)
    return _tool_response(f"Reported {pct}% \u2014 {notes}")


@tool(
    "ask_user",
    "Ask the human operator a question and wait for their answer. "
    "Use when the goal is genuinely ambiguous or you need a decision "
    "only the user can make. Do NOT use for routine confirmations. "
    "Pass choices as a list of options \u2014 the user can pick by number "
    "or type a free-form answer.",
    {"question": str, "choices": list},
)
async def ask_user(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    question = args["question"]
    raw_choices = args.get("choices") or []
    if isinstance(raw_choices, str):
        try:
            raw_choices = json.loads(raw_choices)
        except (json.JSONDecodeError, ValueError):
            raw_choices = [raw_choices]
    choices: list[str] = list(raw_choices)

    # Pause the dashboard so the prompt is visible
    if runtime.dashboard is not None:
        runtime.dashboard.stop()

    console.print(f"\n  [bold yellow]?[/bold yellow]  [bold]{question}[/bold]")
    if choices:
        for i, choice in enumerate(choices, 1):
            console.print(f"    [bold]{i}.[/bold] {choice}")
        console.print("    [dim]Enter a number or type your own answer[/dim]")
    raw: str = await anyio.to_thread.run_sync(lambda: input("Your answer: "))
    raw = raw.strip()

    # Resolve numbered choice
    answer = raw
    if choices and raw.isdigit():
        idx = int(raw) - 1
        if 0 <= idx < len(choices):
            answer = choices[idx]
            console.print(f"  [dim]\u2192 {answer}[/dim]")

    # Resume the dashboard
    if runtime.dashboard is not None:
        runtime.dashboard.start()

    _append_session_event(
        "tool.ask_user",
        {"question": question, "choices": choices, "answer": answer},
    )
    return _tool_response(answer)


@tool(
    "wait",
    "Wait for a specified number of seconds before continuing. "
    "Use between monitoring rounds: 10-15s for simple tasks, 30-45s for complex ones. "
    "Increase if the agent is making steady progress.",
    {"seconds": int},
)
async def wait_tool(args: dict[str, Any]) -> dict[str, Any]:
    seconds = min(max(args.get("seconds", 30), 5), 120)
    await anyio.sleep(seconds)
    return _tool_response(f"Waited {seconds}s")


@tool(
    "run_command",
    "Run a CLI command in a terminal pane. For build/test/git/servers — "
    "NOT for code exploration (dispatch agents for that). "
    "Set interactive=true for long-running programs, false (default) for one-shot.",
    {
        "command": str,
        "task_name": str,
        "interactive": bool,
    },
)
async def run_command(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    command_str = args["command"]
    task_name = args.get("task_name", command_str[:40])
    interactive = args.get("interactive", False)

    import shlex

    try:
        cmd_list = shlex.split(command_str)
    except ValueError:
        cmd_list = [command_str]

    if not cmd_list:
        return _tool_response("Error: empty command")

    pane, launch_err = _safe_launch_pane(
        runtime,
        command=cmd_list,
        purpose=task_name,
        agent_type="command",
        title=f"openMax: {runtime.plan.goal[:40]}",
    )
    if pane is None:
        console.print(f"  [bold red]\u2717[/bold red]  run_command failed: {launch_err}")
        return _tool_response({"status": "error", "error": launch_err})

    subtask = SubTask(
        name=task_name,
        agent_type="command",
        prompt=command_str,
        status=TaskStatus.RUNNING,
        pane_id=pane.pane_id,
    )
    _upsert_subtask(subtask)
    if runtime.dashboard is not None:
        runtime.dashboard.update_subtask(task_name, "command", pane.pane_id, "running")

    win = runtime.pane_mgr.windows.get(runtime.agent_window_id)
    pane_count = len(win.pane_ids) if win else 1
    console.print(
        f"  [bold cyan]{P}[/bold cyan]  [bold]{command_str[:60]}[/bold] \u2192 pane {pane.pane_id}"
    )
    _append_session_event(
        "tool.run_command",
        {
            "command": command_str,
            "task_name": task_name,
            "interactive": interactive,
            "pane_id": pane.pane_id,
            "window_id": runtime.agent_window_id,
        },
    )

    return _tool_response(
        {
            "status": "launched",
            "pane_id": pane.pane_id,
            "window_id": runtime.agent_window_id,
            "command": command_str,
            "task_name": task_name,
            "interactive": interactive,
            "panes_in_window": pane_count,
        }
    )


@tool(
    "run_verification",
    "Run a verification command (lint, test, build) and return structured pass/fail. "
    "On failure, includes a dispatch_hint field with error context — use it directly "
    "as the prompt when dispatching a debug agent. Returns {status, exit_code, output, "
    "duration_s, dispatch_hint?}.",
    {
        "check_type": str,
        "command": str,
        "timeout": int,
    },
)
async def run_verification(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    check_type = args.get("check_type", "custom")
    command_str = args["command"]
    timeout = min(max(args.get("timeout", 120), 10), 600)

    import shlex

    try:
        cmd_list = shlex.split(command_str)
    except ValueError:
        cmd_list = [command_str]
    if not cmd_list:
        return _tool_response("Error: empty command")

    # Wrap command to capture exit code: run cmd; echo __EXIT_$?__
    wrapped_cmd = f'{command_str}; echo "__OPENMAX_EXIT_$?__"'
    shell_cmd = ["bash", "-c", wrapped_cmd]

    task_name = f"verify-{check_type}"
    pane, launch_err = _safe_launch_pane(
        runtime,
        command=shell_cmd,
        purpose=task_name,
        agent_type="command",
        title=f"openMax: verify {check_type}",
    )
    if pane is None:
        console.print(f"  [bold red]\u2717[/bold red]  verification launch failed: {launch_err}")
        return _tool_response({"status": "error", "error": launch_err, "check_type": check_type})

    console.print(
        f"  [bold cyan]{P}[/bold cyan]  verify {check_type}:"
        f" {command_str[:60]} \u2192 pane {pane.pane_id}"
    )

    # Poll for the exit marker
    start_ts = time.monotonic()
    deadline = start_ts + timeout
    exit_code: int | None = None
    output = ""

    import re

    while time.monotonic() < deadline:
        await anyio.sleep(2)
        try:
            text = runtime.pane_mgr.get_text(pane.pane_id)
        except Exception:
            text = ""
        # Look for our exit marker
        match = re.search(r"__OPENMAX_EXIT_(\d+)__", text)
        if match:
            exit_code = int(match.group(1))
            output = text[: match.start()].strip()
            break
        # If pane died, cached output is all we'll ever get — stop polling.
        if not runtime.pane_mgr.is_pane_alive(pane.pane_id):
            break

    duration_s = int(time.monotonic() - start_ts)

    if exit_code is None:
        status = "timeout"
        output = _extract_smart_output(text, tail_lines=50) if text else ""
    elif exit_code == 0:
        status = "pass"
    else:
        status = "fail"

    if not output and text:
        output = _extract_smart_output(text, tail_lines=50)

    capped_output = output[-2000:]
    result: dict[str, Any] = {
        "status": status,
        "check_type": check_type,
        "exit_code": exit_code,
        "output": capped_output,
        "duration_s": duration_s,
        "command": command_str,
    }

    # On failure, provide a ready-made dispatch hint for a debug agent
    if status != "pass":
        result["dispatch_hint"] = (
            f"The {check_type} check failed (exit code {exit_code}).\n"
            f"Command: {command_str}\n"
            f"Error output:\n{capped_output}\n\n"
            f"Investigate the root cause, fix the issue, re-run `{command_str}` "
            f"until it passes, then commit."
        )

    if status == "pass":
        console.print(
            f"  [bold green]\u2713[/bold green]  {check_type}: pass [dim]({duration_s}s)[/dim]"
        )
    else:
        console.print(
            f"  [bold red]\u2717[/bold red]  {check_type}: FAIL [dim]({duration_s}s)[/dim]"
        )

    _append_session_event("tool.run_verification", result)
    return _tool_response(result)


@tool(
    "check_conflicts",
    "Check for git conflicts and untracked files in the working directory.",
    {},
)
async def check_conflicts(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    cwd = runtime.cwd

    # Run git status --porcelain
    try:
        status_result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=30,
        )
        status_output = status_result.stdout
    except (subprocess.TimeoutExpired, OSError) as e:
        return _tool_response(
            {
                "conflict": False,
                "details": f"Error running git status: {e}",
                "untracked_files": [],
            }
        )

    # Run git diff --check
    try:
        diff_result = subprocess.run(
            ["git", "diff", "--check"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=30,
        )
        diff_check_failed = diff_result.returncode != 0
        diff_output = diff_result.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        diff_check_failed = False
        diff_output = ""

    # Parse untracked files and conflict markers
    untracked_files: list[str] = []
    conflict_markers = False
    for line in status_output.splitlines():
        if line.startswith("??"):
            untracked_files.append(line[3:].strip())
        elif line[:2] in ("UU", "AA", "DD", "AU", "UA", "DU", "UD"):
            conflict_markers = True

    has_conflict = diff_check_failed or conflict_markers
    if has_conflict:
        details = diff_output if diff_output else "Conflict markers detected in git status"
    else:
        details = "No conflicts detected"

    result = {
        "conflict": has_conflict,
        "details": details,
        "untracked_files": untracked_files,
    }

    if has_conflict:
        console.print("  [bold red]\u2717[/bold red]  conflicts found")
    else:
        console.print("  [bold green]\u2713[/bold green]  no conflicts")
    _append_session_event("tool.check_conflicts", result)
    return _tool_response(result)


# ── File exploration tools (instant, no pane needed) ──────────────────


@tool(
    "find_files",
    "Search for files by glob pattern in the working directory. "
    "Returns matching file paths instantly (no pane needed). Max 200 results. "
    "Examples: '**/*.md', 'src/**/*.py', '**/roadmap*', 'docs/**'.",
    {"pattern": str, "path": str},
)
async def find_files_tool(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    pattern = args["pattern"]
    rel_path = args.get("path", ".")

    target_dir = (Path(runtime.cwd) / rel_path).resolve()
    cwd_resolved = Path(runtime.cwd).resolve()
    if not str(target_dir).startswith(str(cwd_resolved)):
        return _tool_response("Error: path outside working directory")

    try:
        matches = sorted(target_dir.glob(pattern))
    except Exception as e:
        return _tool_response(f"Error: {e}")

    filtered = [
        m
        for m in matches
        if not any(part.startswith(".") for part in m.relative_to(cwd_resolved).parts)
        and "__pycache__" not in str(m)
    ][:200]

    rel_paths = [str(m.relative_to(cwd_resolved)) for m in filtered]
    result = f"Found {len(rel_paths)} file(s):\n" + "\n".join(rel_paths)
    console.print(f"  [dim]{P}  find '{pattern}' \u2192 {len(rel_paths)} file(s)[/dim]")
    return _tool_response(result)


@tool(
    "grep_files",
    "Search file contents for a regex pattern. Returns matching lines with "
    "file paths and line numbers instantly (no pane needed). Max 100 matches. "
    "Use glob param to filter files (e.g. '**/*.py').",
    {"pattern": str, "glob": str, "max_results": int},
)
async def grep_files_tool(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    pattern = args["pattern"]
    file_glob = args.get("glob", "**/*")
    max_results = min(args.get("max_results", 100), 200)

    import re

    try:
        regex = re.compile(pattern, re.IGNORECASE)
    except re.error as e:
        return _tool_response(f"Error: invalid regex: {e}")

    cwd_resolved = Path(runtime.cwd).resolve()
    matches: list[str] = []

    try:
        for filepath in sorted(cwd_resolved.glob(file_glob)):
            if not filepath.is_file():
                continue
            if any(part.startswith(".") for part in filepath.relative_to(cwd_resolved).parts):
                continue
            if "__pycache__" in str(filepath):
                continue
            try:
                text = filepath.read_text(errors="strict")
            except (UnicodeDecodeError, OSError):
                continue
            rel = str(filepath.relative_to(cwd_resolved))
            for i, line in enumerate(text.splitlines(), 1):
                if regex.search(line):
                    matches.append(f"{rel}:{i}: {line.rstrip()}")
                    if len(matches) >= max_results:
                        break
            if len(matches) >= max_results:
                break
    except Exception as e:
        return _tool_response(f"Error: {e}")

    if not matches:
        result = f"No matches for pattern '{pattern}'"
    else:
        result = f"Found {len(matches)} match(es):\n" + "\n".join(matches)

    console.print(f"  [dim]{P}  grep '{pattern}' \u2192 {len(matches)} match(es)[/dim]")
    return _tool_response(result)


@tool(
    "read_file",
    "Read a file from the working directory. Returns file content instantly "
    "(no pane needed, max 2000 lines). Specify offset/limit for large files.",
    {"path": str, "offset": int, "limit": int},
)
async def read_file_tool(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    rel_path = args["path"]
    offset = args.get("offset", 0)
    limit = args.get("limit", 2000)

    # Resolve relative to cwd, prevent path traversal
    target = (Path(runtime.cwd) / rel_path).resolve()
    cwd_resolved = Path(runtime.cwd).resolve()
    if not str(target).startswith(str(cwd_resolved)):
        return _tool_response("Error: path outside working directory")

    try:
        text = target.read_text(errors="replace")
    except FileNotFoundError:
        return _tool_response(f"Error: file not found: {rel_path}")
    except IsADirectoryError:
        return _tool_response(f"Error: {rel_path} is a directory")
    except OSError as e:
        return _tool_response(f"Error reading file: {e}")

    lines = text.splitlines()
    total = len(lines)
    selected = lines[offset : offset + limit]
    numbered = [f"{i + offset + 1:>5}  {line}" for i, line in enumerate(selected)]
    header = f"# {rel_path} ({total} lines total"
    if offset:
        header += f", showing from line {offset + 1}"
    header += ")\n"
    result = header + "\n".join(numbered)

    console.print(f"  [dim]{P}  read {rel_path} ({len(selected)}/{total} lines)[/dim]")
    return _tool_response(result)


@tool(
    "read_task_report",
    "Read a sub-agent's completion report file. Returns the structured report "
    "if the agent wrote one, or null if no report exists yet.",
    {"task_name": str},
)
async def read_task_report(args: dict[str, Any]) -> dict[str, Any]:
    task_name = args["task_name"]
    report = _read_subtask_report(task_name)
    if report is None:
        return _tool_response({"task_name": task_name, "report": None})
    return _tool_response({"task_name": task_name, "report": report[:4000]})


@tool(
    "update_shared_context",
    "Append an update to the shared blackboard visible to all agents. "
    "Use after key architectural decisions so subsequent agents inherit context.",
    {
        "type": "object",
        "properties": {
            "update": {"type": "string"},
            "section": {"type": "string"},
        },
        "required": ["update"],
    },
)
async def update_shared_context(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    path = append_shared_context(runtime.cwd, args["update"], args.get("section"))
    _append_session_event("tool.update_shared_context", {"section": args.get("section")})
    return _tool_response(f"Appended to {path.relative_to(runtime.cwd)}")


@tool(
    "read_shared_context",
    "Read the shared blackboard. Call before dispatching dependent agents "
    "to include relevant prior decisions in their briefs.",
    {},
)
async def read_shared_context_tool(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    content = read_shared_context(runtime.cwd)
    _append_session_event("tool.read_shared_context", {"chars": len(content) if content else 0})
    return _tool_response({"shared_context": content[:8000] if content else None})


@tool(
    "check_checkpoints",
    "Check for pending agent checkpoints — decision forks where sub-agents are waiting. "
    "Include in every monitoring round.",
    {},
)
async def check_checkpoints(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    items = []
    for p in list_checkpoint_paths(runtime.cwd):
        task_name = p.stem
        content = read_checkpoint(runtime.cwd, task_name)
        if content is not None:
            items.append(
                {
                    "task_name": task_name,
                    "pane_id": _pane_id_for_task(task_name),
                    "content": content[:2000],
                }
            )
    _append_session_event("tool.check_checkpoints", {"pending": len(items)})
    return _tool_response({"pending_checkpoints": items, "count": len(items)})


@tool(
    "resolve_checkpoint",
    "Resolve a pending agent checkpoint: delete the file, record the decision on the "
    "blackboard, and send the decision to the agent's pane so it can continue.",
    {
        "type": "object",
        "properties": {
            "task_name": {"type": "string"},
            "decision": {"type": "string"},
        },
        "required": ["task_name", "decision"],
    },
)
async def resolve_checkpoint(args: dict[str, Any]) -> dict[str, Any]:
    runtime = _runtime()
    task_name, decision = args["task_name"], args["decision"]
    delete_checkpoint(runtime.cwd, task_name)
    append_shared_context(runtime.cwd, decision, section=f"Decision for {task_name}")
    pane_id = _pane_id_for_task(task_name)
    if pane_id is not None and runtime.pane_mgr.is_pane_alive(pane_id):
        runtime.pane_mgr.send_text(pane_id, decision)
    _append_session_event("tool.resolve_checkpoint", {"task_name": task_name, "pane_id": pane_id})
    return _tool_response(f"Resolved checkpoint for '{task_name}', decision sent to pane {pane_id}")


# All tool objects for easy collection
#
# Excluded by design:
# - find_files_tool, grep_files_tool, read_file_tool: the lead agent is a team
#   manager — it delegates exploration to sub-agents, not doing it itself.
#   This also avoids the CLI duplicate tool_use ID bug from parallel MCP calls.
# - get_agent_recommendations: auto-called inside dispatch_agent.
# - list_managed_panes: merged into read_pane_output(pane_id=-1).
# - record_phase_anchor: already called inside transition_phase.
ALL_TOOLS = [
    ask_user,
    check_checkpoints,
    check_conflicts,
    dispatch_agent,
    mark_task_done,
    merge_agent_branch,
    read_pane_output,
    read_shared_context_tool,
    read_task_report,
    resolve_checkpoint,
    run_command,
    run_verification,
    send_text_to_pane,
    submit_plan,
    remember_learning,
    report_completion,
    transition_phase,
    update_shared_context,
    wait_tool,
]
