# open-sysml (PyPI name hold)

This is a **minimal placeholder** on PyPI to reserve the `open-sysml` distribution name for the OpenMBEE / Open SysML effort.

- **Do not depend on this package** for production use until a real release is published.
- The importable package is `open_sysml` (Python module names cannot contain hyphens).
- Replace `Source` / URLs in `pyproject.toml` with the canonical repository if it differs.

## Build and upload (maintainers)

```bash
cd open-sysml
python -m pip install --upgrade build twine
python -m build
twine check dist/*
twine upload dist/*
```

Use [TestPyPI](https://test.pypi.org/) first if you want a dry run (requires a **test.pypi.org** API token):

```bash
twine upload --repository testpypi dist/*
```
