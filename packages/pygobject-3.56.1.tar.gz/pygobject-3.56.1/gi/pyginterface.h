/* -*- Mode: C; c-basic-offset: 4 -*-
 * pygtk- Python bindings for the GTK toolkit.
 * Copyright (C) 1998-2003  James Henstridge
 *               2004-2008  Johan Dahlin
 *   pyginterface.c: wrapper for the gobject library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __PYGOBJECT_INTERFACE_H__
#define __PYGOBJECT_INTERFACE_H__

extern GQuark pyginterface_type_key;
extern GQuark pyginterface_info_key;

extern PyTypeObject PyGInterface_Type;

const GInterfaceInfo *pyg_lookup_interface_info (GType gtype);
void pyg_register_interface_info (GType gtype, const GInterfaceInfo *info);
int pygi_interface_register_types (PyObject *d);

#endif /* __PYGOBJECT_INTERFACE_H__ */
