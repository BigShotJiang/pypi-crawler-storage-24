"""flat-fhir: Convert FHIR JSON bundles into flat, LLM-friendly XLSX spreadsheets."""

from flat_fhir.core import FlatFHIR, flatten, unflatten, merge
from flat_fhir import registry

__all__ = ["FlatFHIR", "flatten", "unflatten", "merge", "registry"]
