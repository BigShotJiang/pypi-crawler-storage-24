from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _env(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    app = create_bluefox_app(BluefoxSettings())
    setup_components(app)
    return app.state.templates


# --- card macro ---


def test_card__basic(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/card.html" import card %}'
        '{% call card() %}Content here{% endcall %}'
    ).render()
    assert "<article" in html
    assert "Content here" in html
    assert "</article>" in html


def test_card__with_title(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/card.html" import card %}'
        '{% call card(title="My Card") %}Body{% endcall %}'
    ).render()
    assert "<header>My Card</header>" in html


def test_card__with_footer(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/card.html" import card %}'
        '{% call card(footer="Footer text") %}Body{% endcall %}'
    ).render()
    assert "<footer>Footer text</footer>" in html


def test_card__with_title_and_footer(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/card.html" import card %}'
        '{% call card(title="T", footer="F") %}Body{% endcall %}'
    ).render()
    assert "<header>T</header>" in html
    assert "<footer>F</footer>" in html
    assert "Body" in html


def test_card__attrs_passthrough(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/card.html" import card %}'
        '{% call card(attrs={"id": "my-card"}) %}Body{% endcall %}'
    ).render()
    assert 'id="my-card"' in html
