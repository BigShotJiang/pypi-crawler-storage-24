from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _env(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    app = create_bluefox_app(BluefoxSettings())
    setup_components(app)
    return app.state.templates


# --- nav macro ---


def test_nav__default_brand(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/nav.html" import nav %}{{ nav() }}'
    ).render()
    assert "<nav" in html
    assert "Bluefox" in html


def test_nav__custom_brand(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/nav.html" import nav %}{{ nav(brand="MyApp") }}'
    ).render()
    assert "MyApp" in html


def test_nav__with_items(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/nav.html" import nav %}'
        '{{ nav(items=[{"href": "/about", "label": "About"}, {"href": "/docs", "label": "Docs"}]) }}'
    ).render()
    assert 'href="/about"' in html
    assert ">About</a>" in html
    assert 'href="/docs"' in html
    assert ">Docs</a>" in html


def test_nav__no_user_shows_login_register(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/nav.html" import nav %}{{ nav() }}'
    ).render()
    assert "/auth/login" in html
    assert "/auth/register" in html


def test_nav__with_user_shows_logout(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/nav.html" import nav %}{{ nav(user="alice") }}'
    ).render()
    assert "/auth/logout" in html
    assert "alice" in html
    assert "/auth/login" not in html
    assert "/auth/register" not in html


def test_nav__active_item(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/nav.html" import nav %}'
        '{{ nav(items=[{"href": "/about", "label": "About", "active": true}]) }}'
    ).render()
    assert 'class="active"' in html
