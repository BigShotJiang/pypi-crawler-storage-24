from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _env(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    app = create_bluefox_app(BluefoxSettings())
    setup_components(app)
    return app.state.templates


def _render(monkeypatch, **kwargs):
    env = _env(monkeypatch)
    tpl = env.from_string('{% from "bfx/button.html" import button %}{{ button(' + ", ".join(f'{k}={v!r}' for k, v in kwargs.items()) + ") }}")
    return tpl.render()


# --- button macro ---


def test_button__default(monkeypatch):
    html = _render(monkeypatch, label="Save")
    assert "<button" in html
    assert 'type="submit"' in html
    assert ">Save</button>" in html
    # Default primary has no class
    assert "class=" not in html


def test_button__secondary_variant(monkeypatch):
    html = _render(monkeypatch, label="Cancel", variant="secondary")
    assert 'class="secondary"' in html


def test_button__outline_variant(monkeypatch):
    html = _render(monkeypatch, label="Outline", variant="outline")
    assert 'class="outline"' in html


def test_button__as_link(monkeypatch):
    html = _render(monkeypatch, label="Go", href="/dashboard")
    assert "<a" in html
    assert 'href="/dashboard"' in html
    assert 'role="button"' in html


def test_button__disabled(monkeypatch):
    html = _render(monkeypatch, label="Wait", disabled=True)
    assert "disabled" in html


def test_button__disabled_link(monkeypatch):
    html = _render(monkeypatch, label="Wait", href="/x", disabled=True)
    assert 'aria-disabled="true"' in html


def test_button__custom_type(monkeypatch):
    html = _render(monkeypatch, label="Reset", type="reset")
    assert 'type="reset"' in html


def test_button__attrs_passthrough(monkeypatch):
    env = _env(monkeypatch)
    tpl = env.from_string(
        '{% from "bfx/button.html" import button %}'
        '{{ button("Delete", attrs={"hx-delete": "/items/1", "hx-confirm": "Sure?"}) }}'
    )
    html = tpl.render()
    assert 'hx-delete="/items/1"' in html
    assert 'hx-confirm="Sure?"' in html
