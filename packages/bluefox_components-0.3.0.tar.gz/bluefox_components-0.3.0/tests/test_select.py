from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _env(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    app = create_bluefox_app(BluefoxSettings())
    setup_components(app)
    return app.state.templates


# --- select macro ---


def test_select__simple_options(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/select.html" import select %}'
        '{{ select("color", ["Red", "Blue", "Green"]) }}'
    ).render()
    assert "<select" in html
    assert 'name="color"' in html
    assert '<option value="Red"' in html
    assert '<option value="Blue"' in html
    assert '<option value="Green"' in html


def test_select__dict_options(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/select.html" import select %}'
        '{{ select("role", [{"value": "admin", "label": "Administrator"}, {"value": "user", "label": "User"}]) }}'
    ).render()
    assert 'value="admin"' in html
    assert ">Administrator</option>" in html


def test_select__with_selected(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/select.html" import select %}'
        '{{ select("color", ["Red", "Blue"], selected="Blue") }}'
    ).render()
    assert 'value="Blue" selected' in html
    assert 'value="Red">' in html  # No selected on Red


def test_select__with_label(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/select.html" import select %}'
        '{{ select("color", ["Red"], label="Pick color") }}'
    ).render()
    assert "<label" in html
    assert "Pick color" in html


def test_select__with_error(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/select.html" import select %}'
        '{{ select("color", ["Red"], error="Required") }}'
    ).render()
    assert 'aria-invalid="true"' in html
    assert "Required" in html


def test_select__required(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/select.html" import select %}'
        '{{ select("color", ["Red"], required=true) }}'
    ).render()
    assert "required" in html
