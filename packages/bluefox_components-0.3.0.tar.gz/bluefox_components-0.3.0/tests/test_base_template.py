from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_core.templates import add_template_directory
from bluefox_components import setup_components


def _make_app(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    setup_components(app)
    return app


# --- base template rendering ---


def test_base_template__renders(monkeypatch):
    app = _make_app(monkeypatch)
    env = app.state.templates
    template = env.get_template("bfx/base.html")
    html = template.render(title="Test Page")

    assert "<!doctype html>" in html.lower()
    assert "Test Page" in html


def test_base_template__includes_pico_css(monkeypatch):
    app = _make_app(monkeypatch)
    env = app.state.templates
    html = env.get_template("bfx/base.html").render()

    assert "pico" in html.lower()
    assert 'rel="stylesheet"' in html


def test_base_template__includes_bluefox_css(monkeypatch):
    app = _make_app(monkeypatch)
    env = app.state.templates
    html = env.get_template("bfx/base.html").render()

    assert "/static/bfx/bluefox.css" in html


def test_base_template__includes_google_fonts(monkeypatch):
    app = _make_app(monkeypatch)
    env = app.state.templates
    html = env.get_template("bfx/base.html").render()

    assert "fonts.googleapis.com" in html
    assert "DM+Sans" in html
    assert "JetBrains+Mono" in html


def test_base_template__has_nav_main_footer(monkeypatch):
    app = _make_app(monkeypatch)
    env = app.state.templates
    html = env.get_template("bfx/base.html").render()

    assert "<nav" in html
    assert "<main" in html
    assert "<footer" in html


def test_base_template__default_title(monkeypatch):
    app = _make_app(monkeypatch)
    env = app.state.templates
    html = env.get_template("bfx/base.html").render()

    assert "<title>Bluefox</title>" in html


def test_base_template__content_block_extensible(monkeypatch, tmp_path):
    """An app template can extend base.html and fill the content block."""
    app = _make_app(monkeypatch)
    env = app.state.templates

    # Create a child template in a temporary directory
    child_dir = tmp_path / "templates"
    child_dir.mkdir()
    (child_dir / "page.html").write_text(
        '{% extends "bfx/base.html" %}'
        '{% block title %}My Page{% endblock %}'
        '{% block content %}<h1>Hello from child</h1>{% endblock %}'
    )

    # Add the temp directory so the child template can be found
    add_template_directory(app, child_dir)

    html = env.get_template("page.html").render()
    assert "My Page" in html
    assert "<h1>Hello from child</h1>" in html
    # Still includes the base layout structure
    assert "<nav" in html
    assert "<footer" in html
