from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _env(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    app = create_bluefox_app(BluefoxSettings())
    setup_components(app)
    return app.state.templates


# --- form_group macro ---


def test_form_group__wraps_content(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/form.html" import form_group %}'
        '{% call form_group("Email") %}<input name="email">{% endcall %}'
    ).render()
    assert '<div class="form-group">' in html
    assert "<label" in html
    assert "Email" in html
    assert '<input name="email">' in html


def test_form_group__with_error(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/form.html" import form_group %}'
        '{% call form_group("Email", error="Invalid") %}<input>{% endcall %}'
    ).render()
    assert "Invalid" in html
    assert "<small" in html


def test_form_group__with_for_id(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/form.html" import form_group %}'
        '{% call form_group("Email", for_id="email") %}<input>{% endcall %}'
    ).render()
    assert 'for="email"' in html


def test_form_group__no_label(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/form.html" import form_group %}'
        '{% call form_group(none) %}<input>{% endcall %}'
    ).render()
    assert "<label" not in html
    assert '<div class="form-group">' in html


# --- csrf_input macro ---


def test_csrf_input(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/form.html" import csrf_input %}'
        '{{ csrf_input("abc123") }}'
    ).render()
    assert 'type="hidden"' in html
    assert 'name="csrf_token"' in html
    assert 'value="abc123"' in html
