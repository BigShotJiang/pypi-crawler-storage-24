from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _env(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    app = create_bluefox_app(BluefoxSettings())
    setup_components(app)
    return app.state.templates


# --- textarea macro ---


def test_textarea__default(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/textarea.html" import textarea %}{{ textarea("bio") }}').render()
    assert "<textarea" in html
    assert 'name="bio"' in html
    assert 'id="bio"' in html
    assert 'rows="4"' in html


def test_textarea__with_label(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/textarea.html" import textarea %}{{ textarea("bio", label="Biography") }}').render()
    assert "<label" in html
    assert "Biography" in html


def test_textarea__with_value(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/textarea.html" import textarea %}{{ textarea("bio", value="Hello world") }}').render()
    assert ">Hello world</textarea>" in html


def test_textarea__with_error(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/textarea.html" import textarea %}{{ textarea("bio", error="Too short") }}').render()
    assert 'aria-invalid="true"' in html
    assert "Too short" in html


def test_textarea__custom_rows(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/textarea.html" import textarea %}{{ textarea("bio", rows=8) }}').render()
    assert 'rows="8"' in html


def test_textarea__required(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/textarea.html" import textarea %}{{ textarea("bio", required=true) }}').render()
    assert "required" in html
