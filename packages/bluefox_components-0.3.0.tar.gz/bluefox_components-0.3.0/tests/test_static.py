import httpx
from httpx import ASGITransport

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _make_app(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    setup_components(app)
    return app


async def test_bluefox_css__served(monkeypatch):
    app = _make_app(monkeypatch)
    transport = ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/static/bfx/bluefox.css")

    assert resp.status_code == 200
    assert "text/css" in resp.headers["content-type"]
    assert "--pico-primary" in resp.text
