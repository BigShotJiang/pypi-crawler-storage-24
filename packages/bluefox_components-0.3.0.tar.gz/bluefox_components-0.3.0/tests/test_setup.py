from pathlib import Path

from jinja2 import FileSystemLoader

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _make_app(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    return create_bluefox_app(settings)


# --- setup_components ---


def test_setup_components__registers_template_directory(monkeypatch):
    app = _make_app(monkeypatch)
    setup_components(app)

    loader = app.state.templates.loader
    assert isinstance(loader, FileSystemLoader)

    # The bfx templates directory should be in the search path
    pkg_templates = str((Path(__file__).parent.parent / "bluefox_components" / "templates").resolve())
    assert pkg_templates in loader.searchpath


def test_setup_components__mounts_static_files(monkeypatch):
    app = _make_app(monkeypatch)
    setup_components(app)

    # Check that a route exists for /static/bfx
    route_paths = [r.path for r in app.routes if hasattr(r, "path")]
    assert "/static/bfx" in route_paths


def test_setup_components__idempotent(monkeypatch):
    """Calling setup_components twice should not duplicate template paths or static mounts."""
    app = _make_app(monkeypatch)
    setup_components(app)
    setup_components(app)

    # Template path not duplicated
    loader = app.state.templates.loader
    pkg_templates = str((Path(__file__).parent.parent / "bluefox_components" / "templates").resolve())
    count = loader.searchpath.count(pkg_templates)
    assert count == 1

    # Static mount not duplicated
    route_paths = [r.path for r in app.routes if hasattr(r, "path")]
    assert route_paths.count("/static/bfx") == 1
