from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _env(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    app = create_bluefox_app(BluefoxSettings())
    setup_components(app)
    return app.state.templates


# --- alert macro ---


def test_alert__default_info(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/alert.html" import alert %}{{ alert("Hello") }}'
    ).render()
    assert "alert-info" in html
    assert "Hello" in html


def test_alert__success_variant(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/alert.html" import alert %}{{ alert("Done!", variant="success") }}'
    ).render()
    assert "alert-success" in html


def test_alert__error_variant_has_role(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/alert.html" import alert %}{{ alert("Fail", variant="error") }}'
    ).render()
    assert "alert-error" in html
    assert 'role="alert"' in html


def test_alert__warning_variant_has_role(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/alert.html" import alert %}{{ alert("Careful", variant="warning") }}'
    ).render()
    assert "alert-warning" in html
    assert 'role="alert"' in html


def test_alert__dismissible(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/alert.html" import alert %}{{ alert("Bye", dismissible=true) }}'
    ).render()
    assert "alert-close" in html
    assert "&times;" in html


def test_alert__not_dismissible_by_default(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/alert.html" import alert %}{{ alert("Stay") }}'
    ).render()
    assert "alert-close" not in html
