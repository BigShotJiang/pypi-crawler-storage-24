from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def _env(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    app = create_bluefox_app(BluefoxSettings())
    setup_components(app)
    return app.state.templates


# --- input macro ---


def test_input__default(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/input.html" import input %}{{ input("email") }}').render()
    assert '<input type="text"' in html
    assert 'name="email"' in html
    assert 'id="email"' in html


def test_input__with_label(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/input.html" import input %}{{ input("email", label="Email") }}').render()
    assert "<label" in html
    assert "Email" in html
    assert "</label>" in html


def test_input__type_password(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/input.html" import input %}{{ input("pw", type="password") }}').render()
    assert 'type="password"' in html


def test_input__required(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/input.html" import input %}{{ input("name", required=true) }}').render()
    assert "required" in html


def test_input__with_error(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/input.html" import input %}{{ input("email", error="Invalid email") }}').render()
    assert 'aria-invalid="true"' in html
    assert "Invalid email" in html


def test_input__with_value(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string('{% from "bfx/input.html" import input %}{{ input("email", value="a@b.com") }}').render()
    assert 'value="a@b.com"' in html


def test_input__attrs_passthrough(monkeypatch):
    env = _env(monkeypatch)
    html = env.from_string(
        '{% from "bfx/input.html" import input %}'
        '{{ input("q", attrs={"hx-get": "/search", "hx-trigger": "keyup"}) }}'
    ).render()
    assert 'hx-get="/search"' in html
    assert 'hx-trigger="keyup"' in html
