# bluefox-components

Jinja2 macro components and Pico CSS theming for the Bluefox Stack.

## What it provides

- **Base layout** — `bfx/base.html` with Pico CSS, Google Fonts, nav/main/footer blocks
- **CSS theme** — `bluefox.css` overrides Pico's custom properties with the Bluefox palette (light + dark)
- **Setup function** — `setup_components(app)` registers templates and mounts static files
- **Jinja2 macros** — parameterized components: buttons, inputs, cards, alerts, tables, and more
- **Component showcase** — a production route at `/components` with live examples

## Quick start

```bash
uv add bluefox-components
```

```python
from bluefox_core import BluefoxSettings, create_bluefox_app
from bluefox_components import setup_components

settings = BluefoxSettings()
app = create_bluefox_app(settings)
setup_components(app)
```

```jinja2
{% extends "bfx/base.html" %}
{% from "bfx/button.html" import button %}

{% block content %}
  {{ button("Save") }}
{% endblock %}
```

## Requirements

- Python 3.12+
- bluefox-core >= 0.4.0
