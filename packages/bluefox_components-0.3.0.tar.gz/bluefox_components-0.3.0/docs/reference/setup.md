# Setup

## `setup_components(app)`

Registers component templates and mounts static assets.

```python
from bluefox_components import setup_components

setup_components(app)
```

### What it does

1. Calls `add_template_directory(app, ...)` to register the `bfx/` templates
2. Mounts `/static/bfx/` to serve `bluefox.css`

Both operations are idempotent — calling `setup_components` multiple times is safe.

### Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `app` | `FastAPI` | The FastAPI application instance |
