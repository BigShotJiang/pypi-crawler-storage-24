# Base layout

## `bfx/base.html`

The base HTML template that all Bluefox app pages extend.

```jinja2
{% extends "bfx/base.html" %}

{% block content %}
  <h1>My page</h1>
{% endblock %}
```

## Includes

- **Pico CSS v2.0.6** — loaded from jsDelivr CDN with SRI hash
- **bluefox.css** — Pico variable overrides from `/static/bfx/bluefox.css`
- **Google Fonts** — DM Sans (300–600) and JetBrains Mono (400, 500)

## Blocks

| Block | Default content | Description |
|-------|----------------|-------------|
| `title` | `{{ title \| default("Bluefox") }}` | Page `<title>` |
| `head` | Empty | Extra `<head>` content |
| `nav` | Default nav with brand | Full `<nav>` element |
| `brand` | "Bluefox" | Brand text in nav |
| `nav_items` | Empty | Nav link list items |
| `content` | Empty | Main page content |
| `footer` | Bluefox Stack link | Footer content |
| `scripts` | Empty | Scripts before `</body>` |

## Dark mode

The template includes `<meta name="color-scheme" content="light dark">`, so Pico CSS automatically follows the user's OS preference. The `bluefox.css` theme defines overrides for both light and dark modes via `@media (prefers-color-scheme: dark)`.
