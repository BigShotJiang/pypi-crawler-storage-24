from bluefox_components.setup import setup_components

__all__ = [
    "setup_components",
]
