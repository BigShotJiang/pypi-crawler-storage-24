"""Register bluefox-components templates and static files with a FastAPI app."""

from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from bluefox_core.templates import add_template_directory


_PKG_DIR = Path(__file__).parent


def setup_components(app: FastAPI) -> None:
    """Register the component templates and mount static assets.

    Call this once during app startup::

        from bluefox_components import setup_components
        setup_components(app)
    """
    # Register bfx/ templates so apps can {% extends "bfx/base.html" %}
    add_template_directory(app, _PKG_DIR / "templates")

    # Mount the CSS theme file at /static/bfx/ (guard against duplicate mounts)
    already_mounted = any(
        getattr(r, "path", None) == "/static/bfx" for r in app.routes
    )
    if not already_mounted:
        app.mount(
            "/static/bfx",
            StaticFiles(directory=str(_PKG_DIR / "static" / "bfx")),
            name="bfx-static",
        )
