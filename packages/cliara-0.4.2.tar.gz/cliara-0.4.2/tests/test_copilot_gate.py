"""
Tests for the Copilot Gate AI-command interception layer.
Run with: python -m pytest tests/test_copilot_gate.py -v
"""

import sys
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent))

from cliara.copilot_gate import (
    InputSource,
    SourceDetector,
    RiskAssessment,
    RiskEngine,
    CopilotGate,
    _explain_by_pattern,
    _generic_explanation,
)
from cliara.safety import SafetyChecker, DangerLevel
from cliara.diff_preview import DiffPreview


# -----------------------------------------------------------------------
# SourceDetector
# -----------------------------------------------------------------------

class TestSourceDetector:

    def test_typed_by_default(self):
        sd = SourceDetector()
        assert sd.classify("ls -la") == InputSource.TYPED

    def test_ai_tagged(self):
        sd = SourceDetector()
        assert sd.classify("@ai git push --force") == InputSource.AI_TAGGED

    def test_paste_flag(self):
        sd = SourceDetector()
        sd.mark_paste()
        assert sd.classify("git status") == InputSource.PASTED

    def test_paste_flag_consumed_after_use(self):
        sd = SourceDetector()
        sd.mark_paste()
        sd.classify("cmd1")
        assert sd.classify("cmd2") == InputSource.TYPED

    def test_copilot_cli_after_gh_copilot(self):
        sd = SourceDetector()
        result = sd.classify("npm install", prev_command="gh copilot suggest")
        assert result == InputSource.COPILOT_CLI

    def test_copilot_cli_only_one_shot(self):
        sd = SourceDetector()
        sd.classify("cmd1", prev_command="gh copilot suggest")
        assert sd.classify("cmd2", prev_command="cmd1") == InputSource.TYPED

    def test_explicit_mode_ignores_paste(self):
        sd = SourceDetector()
        sd.mark_paste()
        result = sd.classify("ls", mode="explicit")
        assert result == InputSource.TYPED

    def test_explicit_mode_allows_ai_tag(self):
        sd = SourceDetector()
        result = sd.classify("@ai ls", mode="explicit")
        assert result == InputSource.AI_TAGGED

    def test_all_mode_flags_everything(self):
        sd = SourceDetector()
        result = sd.classify("ls", mode="all")
        assert result == InputSource.PASTED

    def test_is_ai_generated_typed(self):
        assert not SourceDetector.is_ai_generated(InputSource.TYPED)

    def test_is_ai_generated_pasted(self):
        assert SourceDetector.is_ai_generated(InputSource.PASTED)

    def test_is_ai_generated_ai_tagged(self):
        assert SourceDetector.is_ai_generated(InputSource.AI_TAGGED)

    def test_is_ai_generated_copilot_cli(self):
        assert SourceDetector.is_ai_generated(InputSource.COPILOT_CLI)

    def test_ai_tag_takes_priority_over_paste(self):
        sd = SourceDetector()
        sd.mark_paste()
        assert sd.classify("@ai ls") == InputSource.AI_TAGGED


# -----------------------------------------------------------------------
# Explanation engine
# -----------------------------------------------------------------------

class TestExplanations:

    def test_git_status(self):
        assert _explain_by_pattern("git status") == "Shows working tree status"

    def test_git_push_force(self):
        exp = _explain_by_pattern("git push origin main --force")
        assert "force" in exp.lower() or "Force" in exp

    def test_rm_rf_with_target(self):
        exp = _explain_by_pattern("rm -rf dist/")
        assert "dist/" in exp

    def test_npm_install(self):
        assert _explain_by_pattern("npm install") == "Installs npm dependencies"

    def test_npm_install_global(self):
        exp = _explain_by_pattern("npm install -g typescript")
        assert "globally" in exp.lower()

    def test_docker_compose_down(self):
        exp = _explain_by_pattern("docker compose down")
        assert exp is not None
        assert "container" in exp.lower() or "stop" in exp.lower()

    def test_unknown_command_returns_none(self):
        assert _explain_by_pattern("mycustomtool --do-stuff") is None

    def test_generic_explanation(self):
        assert _generic_explanation("mycustomtool --flag") == "Runs 'mycustomtool'"

    def test_sudo_explanation(self):
        exp = _explain_by_pattern("sudo apt update")
        assert "elevated" in exp.lower() or "privileges" in exp.lower()

    def test_kubectl_apply(self):
        exp = _explain_by_pattern("kubectl apply -f deployment.yaml")
        assert exp is not None


# -----------------------------------------------------------------------
# RiskEngine
# -----------------------------------------------------------------------

class TestRiskEngine:

    def _engine(self):
        return RiskEngine(SafetyChecker(), DiffPreview())

    def test_safe_command(self):
        ra = self._engine().assess("ls -la", use_repo_context=False)
        assert ra.danger_level == DangerLevel.SAFE
        assert ra.reversible is True

    def test_rm_rf_is_dangerous(self):
        ra = self._engine().assess("rm -rf node_modules/", use_repo_context=False)
        assert ra.danger_level in (DangerLevel.DANGEROUS, DangerLevel.CRITICAL)
        assert ra.reversible is False

    def test_git_push_force_detected(self):
        ra = self._engine().assess("git push origin main --force", use_repo_context=False)
        assert ra.danger_level != DangerLevel.SAFE
        assert ra.reversible is False
        assert any("force" in f.lower() or "Force" in f for f in ra.risk_factors)

    def test_npm_publish_caution(self):
        ra = self._engine().assess("npm publish", use_repo_context=False)
        assert ra.danger_level != DangerLevel.SAFE
        assert ra.reversible is False

    def test_compound_command_highest_risk(self):
        ra = self._engine().assess("git add . && rm -rf /tmp/logs", use_repo_context=False)
        assert ra.danger_level in (DangerLevel.DANGEROUS, DangerLevel.CRITICAL)

    def test_explanation_present(self):
        ra = self._engine().assess("git status", use_repo_context=False)
        assert ra.explanation
        assert len(ra.explanation) > 0

    def test_blast_radius_global(self):
        ra = self._engine().assess("npm install -g typescript", use_repo_context=False)
        assert ra.blast_radius == "system-wide"

    def test_blast_radius_local(self):
        ra = self._engine().assess("echo hello", use_repo_context=False)
        assert ra.blast_radius == "local"

    def test_sensitive_file_risk(self):
        ra = self._engine().assess("cat .env", use_repo_context=False)
        assert any("sensitive" in f.lower() for f in ra.risk_factors)

    def test_no_verify_risk(self):
        ra = self._engine().assess("git commit --no-verify -m test", use_repo_context=False)
        assert any("verif" in f.lower() for f in ra.risk_factors)

    def test_terraform_destroy(self):
        ra = self._engine().assess("terraform destroy", use_repo_context=False)
        assert ra.danger_level in (DangerLevel.DANGEROUS, DangerLevel.CRITICAL)
        assert any("infrastructure" in f.lower() for f in ra.risk_factors)

    def test_docker_push_risk(self):
        ra = self._engine().assess("docker push myimage:latest", use_repo_context=False)
        assert any("registry" in f.lower() for f in ra.risk_factors)

    def test_context_amplifier_force_push_main(self):
        engine = self._engine()
        warnings, level = engine._apply_context_amplifiers(
            "git push origin main --force",
            DangerLevel.CAUTION,
            {"branch": "main", "is_dirty": False, "unpushed": 2, "has_remote": True},
        )
        assert level == DangerLevel.CRITICAL
        assert any("main" in w for w in warnings)

    def test_context_amplifier_dirty_checkout(self):
        engine = self._engine()
        warnings, level = engine._apply_context_amplifiers(
            "git checkout .",
            DangerLevel.SAFE,
            {"branch": "feature", "is_dirty": True, "unpushed": 0, "has_remote": True},
        )
        assert any("uncommitted" in w.lower() for w in warnings)


# -----------------------------------------------------------------------
# CopilotGate approval flow
# -----------------------------------------------------------------------

def _mock_no_git(args_str):
    """Stub that replaces RiskEngine._git to avoid slow subprocess calls."""
    return ""


class TestCopilotGate:

    def _gate(self, auto_safe=True):
        engine = RiskEngine(SafetyChecker(), DiffPreview())
        engine._git = staticmethod(_mock_no_git)
        return CopilotGate(engine, auto_approve_safe=auto_safe)

    def test_safe_auto_approved(self):
        gate = self._gate(auto_safe=True)
        approved = gate.evaluate("git status", InputSource.PASTED)
        assert approved is True

    def test_safe_not_auto_approved_prompts(self):
        gate = self._gate(auto_safe=False)
        with patch("builtins.input", return_value=""):
            approved = gate.evaluate("git status", InputSource.PASTED)
            assert approved is True

    def test_safe_not_auto_approved_cancel(self):
        gate = self._gate(auto_safe=False)
        with patch("builtins.input", return_value="n"):
            approved = gate.evaluate("git status", InputSource.PASTED)
            assert approved is False

    def test_caution_approved(self):
        gate = self._gate()
        with patch("builtins.input", return_value="y"):
            approved = gate.evaluate("npm install -g typescript", InputSource.PASTED)
            assert approved is True

    def test_caution_denied(self):
        gate = self._gate()
        with patch("builtins.input", return_value="n"):
            approved = gate.evaluate("npm install -g typescript", InputSource.PASTED)
            assert approved is False

    def test_dangerous_requires_RUN(self):
        gate = self._gate()
        with patch("builtins.input", return_value="RUN"):
            approved = gate.evaluate("rm -rf dist/", InputSource.PASTED)
            assert approved is True

    def test_dangerous_denied_with_y(self):
        gate = self._gate()
        with patch("builtins.input", return_value="y"):
            approved = gate.evaluate("rm -rf dist/", InputSource.PASTED)
            assert approved is False

    def test_critical_requires_I_UNDERSTAND(self):
        gate = self._gate()
        with patch("builtins.input", return_value="I UNDERSTAND"):
            approved = gate.evaluate("rm -rf /", InputSource.AI_TAGGED)
            assert approved is True

    def test_critical_denied_with_RUN(self):
        gate = self._gate()
        with patch("builtins.input", return_value="RUN"):
            approved = gate.evaluate("rm -rf /", InputSource.AI_TAGGED)
            assert approved is False

    def test_keyboard_interrupt_cancels(self):
        gate = self._gate()
        with patch("builtins.input", side_effect=KeyboardInterrupt):
            approved = gate.evaluate("npm install -g x", InputSource.PASTED)
            assert approved is False

    def test_eof_cancels(self):
        gate = self._gate()
        with patch("builtins.input", side_effect=EOFError):
            approved = gate.evaluate("npm install -g x", InputSource.PASTED)
            assert approved is False


# -----------------------------------------------------------------------
# Run directly
# -----------------------------------------------------------------------

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
