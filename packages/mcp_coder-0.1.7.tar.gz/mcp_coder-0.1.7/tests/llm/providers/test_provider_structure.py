"""Tests for LLM provider package structure."""


def test_providers_package_structure() -> None:
    """Verify providers package structure and imports."""
    import mcp_coder.llm.providers
    import mcp_coder.llm.providers.claude

    # Verify claude provider modules importable
    from mcp_coder.llm.providers.claude import (
        claude_code_api,
        claude_code_cli,
    )

    assert hasattr(claude_code_cli, "ask_claude_code_cli")
    assert hasattr(claude_code_api, "ask_claude_code_api")


def test_public_api_provider_exports() -> None:
    """Verify provider functions accessible via public API."""
    from mcp_coder import ask_llm, prompt_llm

    assert callable(ask_llm)
    assert callable(prompt_llm)


def test_claude_provider_functions() -> None:
    """Test that claude provider functions are accessible."""
    from mcp_coder.llm.providers.claude.claude_code_api import ask_claude_code_api
    from mcp_coder.llm.providers.claude.claude_code_cli import ask_claude_code_cli
    from mcp_coder.llm.providers.claude.claude_executable_finder import (
        find_claude_executable,
        verify_claude_installation,
    )

    # Verify functions are callable
    assert callable(ask_claude_code_cli)
    assert callable(ask_claude_code_api)
    assert callable(find_claude_executable)
    assert callable(verify_claude_installation)


def test_provider_package_init() -> None:
    """Test that provider package __init__.py files exist and are loadable."""
    # These should not raise ImportError
    import mcp_coder.llm.providers
    import mcp_coder.llm.providers.claude

    # Verify they are actually packages (have __path__ attribute)
    assert hasattr(mcp_coder.llm.providers, "__path__")
    assert hasattr(mcp_coder.llm.providers.claude, "__path__")


def test_langchain_package_exists() -> None:
    """Verify the langchain sub-package exists and exposes ask_langchain."""
    from mcp_coder.llm.providers import langchain  # noqa: F401

    assert hasattr(langchain, "ask_langchain")
