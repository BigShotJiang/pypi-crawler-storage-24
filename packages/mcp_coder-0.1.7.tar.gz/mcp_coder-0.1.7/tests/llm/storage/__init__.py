"""Tests for session storage."""
