"""Tests for response formatting."""
