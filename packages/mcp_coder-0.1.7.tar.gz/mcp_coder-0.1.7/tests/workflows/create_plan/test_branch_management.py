"""Tests for create_plan workflow branch management functionality."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from mcp_coder.workflows.create_plan import manage_branch


class TestManageBranch:
    """Test manage_branch function."""

    def test_manage_branch_existing_branch(self, tmp_path: Path) -> None:
        """Test manage_branch with existing linked branch."""
        # Mock IssueBranchManager to return existing branch
        with patch(
            "mcp_coder.workflows.create_plan.IssueBranchManager"
        ) as mock_manager_class:
            mock_manager = MagicMock()
            mock_manager.get_linked_branches.return_value = ["123-test-feature"]
            mock_manager_class.return_value = mock_manager

            # Mock checkout_branch to succeed
            with patch(
                "mcp_coder.workflows.create_plan.checkout_branch", return_value=True
            ):
                branch_name = manage_branch(tmp_path, 123, "Test Feature")

        assert branch_name == "123-test-feature"
        mock_manager.get_linked_branches.assert_called_once_with(123)
        mock_manager.create_remote_branch_for_issue.assert_not_called()

    def test_manage_branch_create_new_branch(self, tmp_path: Path) -> None:
        """Test manage_branch creates new branch when none exist."""
        # Mock IssueBranchManager with no existing branches
        with patch(
            "mcp_coder.workflows.create_plan.IssueBranchManager"
        ) as mock_manager_class:
            mock_manager = MagicMock()
            mock_manager.get_linked_branches.return_value = []
            mock_manager.create_remote_branch_for_issue.return_value = {
                "success": True,
                "branch_name": "123-test-feature",
                "error": None,
                "existing_branches": [],
            }
            mock_manager_class.return_value = mock_manager

            # Mock checkout_branch to succeed
            with patch(
                "mcp_coder.workflows.create_plan.checkout_branch", return_value=True
            ):
                branch_name = manage_branch(tmp_path, 123, "Test Feature")

        assert branch_name == "123-test-feature"
        mock_manager.get_linked_branches.assert_called_once_with(123)
        mock_manager.create_remote_branch_for_issue.assert_called_once_with(
            123, base_branch=None
        )

    def test_manage_branch_create_failure(self, tmp_path: Path) -> None:
        """Test manage_branch when branch creation fails."""
        # Mock IssueBranchManager with no existing branches
        with patch(
            "mcp_coder.workflows.create_plan.IssueBranchManager"
        ) as mock_manager_class:
            mock_manager = MagicMock()
            mock_manager.get_linked_branches.return_value = []
            mock_manager.create_remote_branch_for_issue.return_value = {
                "success": False,
                "branch_name": "",
                "error": "GitHub API error",
                "existing_branches": [],
            }
            mock_manager_class.return_value = mock_manager

            branch_name = manage_branch(tmp_path, 123, "Test Feature")

        assert branch_name is None
        mock_manager.get_linked_branches.assert_called_once_with(123)
        mock_manager.create_remote_branch_for_issue.assert_called_once_with(
            123, base_branch=None
        )

    def test_manage_branch_checkout_failure(self, tmp_path: Path) -> None:
        """Test manage_branch when checkout fails."""
        # Mock IssueBranchManager to return existing branch
        with patch(
            "mcp_coder.workflows.create_plan.IssueBranchManager"
        ) as mock_manager_class:
            mock_manager = MagicMock()
            mock_manager.get_linked_branches.return_value = ["123-test-feature"]
            mock_manager_class.return_value = mock_manager

            # Mock checkout_branch to fail
            with patch(
                "mcp_coder.workflows.create_plan.checkout_branch", return_value=False
            ):
                branch_name = manage_branch(tmp_path, 123, "Test Feature")

        assert branch_name is None
        mock_manager.get_linked_branches.assert_called_once_with(123)

    def test_manage_branch_manager_initialization_error(self, tmp_path: Path) -> None:
        """Test manage_branch when IssueBranchManager initialization fails."""
        # Mock IssueBranchManager initialization to raise exception
        with patch(
            "mcp_coder.workflows.create_plan.IssueBranchManager",
            side_effect=ValueError("Invalid configuration"),
        ):
            branch_name = manage_branch(tmp_path, 123, "Test Feature")

        assert branch_name is None

    def test_manage_branch_get_linked_branches_error(self, tmp_path: Path) -> None:
        """Test manage_branch when get_linked_branches throws error."""
        # Mock IssueBranchManager with get_linked_branches raising exception
        with patch(
            "mcp_coder.workflows.create_plan.IssueBranchManager"
        ) as mock_manager_class:
            mock_manager = MagicMock()
            mock_manager.get_linked_branches.side_effect = Exception("API error")
            mock_manager_class.return_value = mock_manager

            branch_name = manage_branch(tmp_path, 123, "Test Feature")

        assert branch_name is None
        mock_manager.get_linked_branches.assert_called_once_with(123)

    def test_manage_branch_logs_existing_branch(self, tmp_path: Path) -> None:
        """Test manage_branch logs when using existing branch."""
        # Mock IssueBranchManager to return existing branch
        with patch(
            "mcp_coder.workflows.create_plan.IssueBranchManager"
        ) as mock_manager_class:
            mock_manager = MagicMock()
            mock_manager.get_linked_branches.return_value = ["123-existing-branch"]
            mock_manager_class.return_value = mock_manager

            # Mock checkout_branch to succeed
            with patch(
                "mcp_coder.workflows.create_plan.checkout_branch", return_value=True
            ):
                # Capture logger output
                with patch("mcp_coder.workflows.create_plan.logger") as mock_logger:
                    branch_name = manage_branch(tmp_path, 123, "Test Feature")

                    # Verify logging calls
                    assert mock_logger.info.call_count >= 3
                    log_calls = [call[0][0] for call in mock_logger.info.call_args_list]
                    assert any("Managing branch" in call for call in log_calls)
                    assert any(
                        "Using existing linked branch" in call for call in log_calls
                    )
                    assert any("Switched to branch" in call for call in log_calls)

        assert branch_name == "123-existing-branch"

    def test_manage_branch_logs_new_branch(self, tmp_path: Path) -> None:
        """Test manage_branch logs when creating new branch."""
        # Mock IssueBranchManager with no existing branches
        with patch(
            "mcp_coder.workflows.create_plan.IssueBranchManager"
        ) as mock_manager_class:
            mock_manager = MagicMock()
            mock_manager.get_linked_branches.return_value = []
            mock_manager.create_remote_branch_for_issue.return_value = {
                "success": True,
                "branch_name": "123-new-branch",
                "error": None,
                "existing_branches": [],
            }
            mock_manager_class.return_value = mock_manager

            # Mock checkout_branch to succeed
            with patch(
                "mcp_coder.workflows.create_plan.checkout_branch", return_value=True
            ):
                # Capture logger output
                with patch("mcp_coder.workflows.create_plan.logger") as mock_logger:
                    branch_name = manage_branch(tmp_path, 123, "Test Feature")

                    # Verify logging calls
                    log_calls = [call[0][0] for call in mock_logger.info.call_args_list]
                    assert any("Managing branch" in call for call in log_calls)
                    assert any("Created new branch" in call for call in log_calls)
                    assert any("Switched to branch" in call for call in log_calls)

        assert branch_name == "123-new-branch"


class TestManageBranchBaseBranch:
    """Tests for base_branch parameter in manage_branch()."""

    @patch("mcp_coder.workflows.create_plan.IssueBranchManager")
    @patch("mcp_coder.workflows.create_plan.checkout_branch")
    def test_manage_branch_passes_base_branch_to_create(
        self, mock_checkout: MagicMock, mock_manager_class: MagicMock, tmp_path: Path
    ) -> None:
        """base_branch is passed to create_remote_branch_for_issue()."""
        mock_manager = MagicMock()
        mock_manager.get_linked_branches.return_value = []  # No existing branches
        mock_manager.create_remote_branch_for_issue.return_value = {
            "success": True,
            "branch_name": "123-test-issue",
            "error": None,
            "existing_branches": [],
        }
        mock_manager_class.return_value = mock_manager
        mock_checkout.return_value = True

        result = manage_branch(
            project_dir=tmp_path,
            issue_number=123,
            issue_title="Test Issue",
            base_branch="feature/v2",
        )

        # Verify base_branch was passed
        mock_manager.create_remote_branch_for_issue.assert_called_once_with(
            123,
            base_branch="feature/v2",
        )
        assert result == "123-test-issue"

    @patch("mcp_coder.workflows.create_plan.IssueBranchManager")
    @patch("mcp_coder.workflows.create_plan.checkout_branch")
    def test_manage_branch_without_base_branch_uses_default(
        self, mock_checkout: MagicMock, mock_manager_class: MagicMock, tmp_path: Path
    ) -> None:
        """Without base_branch, None is passed (uses repo default)."""
        mock_manager = MagicMock()
        mock_manager.get_linked_branches.return_value = []
        mock_manager.create_remote_branch_for_issue.return_value = {
            "success": True,
            "branch_name": "123-test-issue",
            "error": None,
            "existing_branches": [],
        }
        mock_manager_class.return_value = mock_manager
        mock_checkout.return_value = True

        result = manage_branch(
            project_dir=tmp_path,
            issue_number=123,
            issue_title="Test Issue",
            # No base_branch provided
        )

        # Verify base_branch=None was passed
        mock_manager.create_remote_branch_for_issue.assert_called_once_with(
            123,
            base_branch=None,
        )
        assert result == "123-test-issue"

    @patch("mcp_coder.workflows.create_plan.IssueBranchManager")
    @patch("mcp_coder.workflows.create_plan.checkout_branch")
    def test_manage_branch_existing_branch_ignores_base_branch(
        self, mock_checkout: MagicMock, mock_manager_class: MagicMock, tmp_path: Path
    ) -> None:
        """If branch already exists, base_branch is ignored."""
        mock_manager = MagicMock()
        mock_manager.get_linked_branches.return_value = ["123-existing-branch"]
        mock_manager_class.return_value = mock_manager
        mock_checkout.return_value = True

        result = manage_branch(
            project_dir=tmp_path,
            issue_number=123,
            issue_title="Test Issue",
            base_branch="feature/v2",  # Should be ignored
        )

        # Verify create was NOT called (existing branch used)
        mock_manager.create_remote_branch_for_issue.assert_not_called()
        assert result == "123-existing-branch"
