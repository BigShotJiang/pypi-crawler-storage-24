"""Tests for Jenkins operations."""
