"""Test CLI commands package."""
