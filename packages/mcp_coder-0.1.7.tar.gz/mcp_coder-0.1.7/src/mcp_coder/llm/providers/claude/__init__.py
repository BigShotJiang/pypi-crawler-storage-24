# Claude provider module
