# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from ..._utils import PropertyInfo
from ..._models import BaseModel
from .store_file_status import StoreFileStatus

__all__ = [
    "StoreFile",
    "Config",
    "Chunk",
    "ChunkTextInputChunk",
    "ChunkTextInputChunkGeneratedMetadata",
    "ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata",
    "ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading",
    "ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext",
    "ChunkTextInputChunkGeneratedMetadataTextChunkGeneratedMetadata",
    "ChunkTextInputChunkGeneratedMetadataPdfChunkGeneratedMetadata",
    "ChunkTextInputChunkGeneratedMetadataCodeChunkGeneratedMetadata",
    "ChunkTextInputChunkGeneratedMetadataAudioChunkGeneratedMetadata",
    "ChunkTextInputChunkGeneratedMetadataVideoChunkGeneratedMetadata",
    "ChunkTextInputChunkGeneratedMetadataImageChunkGeneratedMetadata",
    "ChunkImageURLInputChunk",
    "ChunkImageURLInputChunkGeneratedMetadata",
    "ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata",
    "ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading",
    "ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext",
    "ChunkImageURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata",
    "ChunkImageURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata",
    "ChunkImageURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata",
    "ChunkImageURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata",
    "ChunkImageURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata",
    "ChunkImageURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata",
    "ChunkImageURLInputChunkImageURL",
    "ChunkAudioURLInputChunk",
    "ChunkAudioURLInputChunkGeneratedMetadata",
    "ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata",
    "ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading",
    "ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext",
    "ChunkAudioURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata",
    "ChunkAudioURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata",
    "ChunkAudioURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata",
    "ChunkAudioURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata",
    "ChunkAudioURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata",
    "ChunkAudioURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata",
    "ChunkAudioURLInputChunkAudioURL",
    "ChunkVideoURLInputChunk",
    "ChunkVideoURLInputChunkGeneratedMetadata",
    "ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata",
    "ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading",
    "ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext",
    "ChunkVideoURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata",
    "ChunkVideoURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata",
    "ChunkVideoURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata",
    "ChunkVideoURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata",
    "ChunkVideoURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata",
    "ChunkVideoURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata",
    "ChunkVideoURLInputChunkVideoURL",
]


class Config(BaseModel):
    """Configuration for a file."""

    parsing_strategy: Optional[Literal["fast", "high_quality"]] = None
    """Strategy for adding the file, this overrides the store-level default"""


class ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading(BaseModel):
    level: int

    text: str


class ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext(BaseModel):
    level: int

    text: str


class ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["markdown"]] = None

    file_type: Optional[Literal["text/markdown"]] = None

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    chunk_headings: Optional[List[ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading]] = (
        None
    )

    heading_context: Optional[
        List[ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext]
    ] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    frontmatter: Optional[Dict[str, object]] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkTextInputChunkGeneratedMetadataTextChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["text"]] = None

    file_type: Optional[Literal["text/plain"]] = None

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkTextInputChunkGeneratedMetadataPdfChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["pdf"]] = None

    file_type: Optional[Literal["application/pdf"]] = None

    total_pages: Optional[int] = None

    total_size: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkTextInputChunkGeneratedMetadataCodeChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["code"]] = None

    file_type: str

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkTextInputChunkGeneratedMetadataAudioChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["audio"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    total_duration_seconds: Optional[float] = None

    sample_rate: Optional[int] = None

    channels: Optional[int] = None

    audio_format: Optional[int] = None

    bpm: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkTextInputChunkGeneratedMetadataVideoChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["video"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    total_duration_seconds: Optional[float] = None

    fps: Optional[float] = None

    width: Optional[int] = None

    height: Optional[int] = None

    frame_count: Optional[int] = None

    has_audio_stream: Optional[bool] = None

    bpm: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkTextInputChunkGeneratedMetadataImageChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["image"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    width: Optional[int] = None

    height: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


ChunkTextInputChunkGeneratedMetadata: TypeAlias = Annotated[
    Union[
        ChunkTextInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata,
        ChunkTextInputChunkGeneratedMetadataTextChunkGeneratedMetadata,
        ChunkTextInputChunkGeneratedMetadataPdfChunkGeneratedMetadata,
        ChunkTextInputChunkGeneratedMetadataCodeChunkGeneratedMetadata,
        ChunkTextInputChunkGeneratedMetadataAudioChunkGeneratedMetadata,
        ChunkTextInputChunkGeneratedMetadataVideoChunkGeneratedMetadata,
        ChunkTextInputChunkGeneratedMetadataImageChunkGeneratedMetadata,
        None,
    ],
    PropertyInfo(discriminator="type"),
]


class ChunkTextInputChunk(BaseModel):
    chunk_index: int
    """position of the chunk in a file"""

    mime_type: Optional[str] = None
    """mime type of the chunk"""

    generated_metadata: Optional[ChunkTextInputChunkGeneratedMetadata] = None
    """metadata of the chunk"""

    model: Optional[str] = None
    """model used for this chunk"""

    type: Optional[Literal["text"]] = None
    """Input type identifier"""

    offset: Optional[int] = None
    """The offset of the text in the file relative to the start of the file."""

    text: Optional[str] = None
    """Text content"""


class ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading(BaseModel):
    level: int

    text: str


class ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext(BaseModel):
    level: int

    text: str


class ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["markdown"]] = None

    file_type: Optional[Literal["text/markdown"]] = None

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    chunk_headings: Optional[
        List[ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading]
    ] = None

    heading_context: Optional[
        List[ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext]
    ] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    frontmatter: Optional[Dict[str, object]] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkImageURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["text"]] = None

    file_type: Optional[Literal["text/plain"]] = None

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkImageURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["pdf"]] = None

    file_type: Optional[Literal["application/pdf"]] = None

    total_pages: Optional[int] = None

    total_size: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkImageURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["code"]] = None

    file_type: str

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkImageURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["audio"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    total_duration_seconds: Optional[float] = None

    sample_rate: Optional[int] = None

    channels: Optional[int] = None

    audio_format: Optional[int] = None

    bpm: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkImageURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["video"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    total_duration_seconds: Optional[float] = None

    fps: Optional[float] = None

    width: Optional[int] = None

    height: Optional[int] = None

    frame_count: Optional[int] = None

    has_audio_stream: Optional[bool] = None

    bpm: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkImageURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["image"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    width: Optional[int] = None

    height: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


ChunkImageURLInputChunkGeneratedMetadata: TypeAlias = Annotated[
    Union[
        ChunkImageURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata,
        ChunkImageURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata,
        ChunkImageURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata,
        ChunkImageURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata,
        ChunkImageURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata,
        ChunkImageURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata,
        ChunkImageURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata,
        None,
    ],
    PropertyInfo(discriminator="type"),
]


class ChunkImageURLInputChunkImageURL(BaseModel):
    """Model for image URL validation."""

    url: str
    """The image URL. Can be either a URL or a Data URI."""

    format: Optional[str] = None
    """The image format/mimetype"""


class ChunkImageURLInputChunk(BaseModel):
    chunk_index: int
    """position of the chunk in a file"""

    mime_type: Optional[str] = None
    """mime type of the chunk"""

    generated_metadata: Optional[ChunkImageURLInputChunkGeneratedMetadata] = None
    """metadata of the chunk"""

    model: Optional[str] = None
    """model used for this chunk"""

    type: Optional[Literal["image_url"]] = None
    """Input type identifier"""

    ocr_text: Optional[str] = None
    """ocr text of the image"""

    summary: Optional[str] = None
    """summary of the image"""

    image_url: Optional[ChunkImageURLInputChunkImageURL] = None
    """Model for image URL validation."""


class ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading(BaseModel):
    level: int

    text: str


class ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext(BaseModel):
    level: int

    text: str


class ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["markdown"]] = None

    file_type: Optional[Literal["text/markdown"]] = None

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    chunk_headings: Optional[
        List[ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading]
    ] = None

    heading_context: Optional[
        List[ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext]
    ] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    frontmatter: Optional[Dict[str, object]] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkAudioURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["text"]] = None

    file_type: Optional[Literal["text/plain"]] = None

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkAudioURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["pdf"]] = None

    file_type: Optional[Literal["application/pdf"]] = None

    total_pages: Optional[int] = None

    total_size: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkAudioURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["code"]] = None

    file_type: str

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkAudioURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["audio"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    total_duration_seconds: Optional[float] = None

    sample_rate: Optional[int] = None

    channels: Optional[int] = None

    audio_format: Optional[int] = None

    bpm: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkAudioURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["video"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    total_duration_seconds: Optional[float] = None

    fps: Optional[float] = None

    width: Optional[int] = None

    height: Optional[int] = None

    frame_count: Optional[int] = None

    has_audio_stream: Optional[bool] = None

    bpm: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkAudioURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["image"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    width: Optional[int] = None

    height: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


ChunkAudioURLInputChunkGeneratedMetadata: TypeAlias = Annotated[
    Union[
        ChunkAudioURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata,
        ChunkAudioURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata,
        ChunkAudioURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata,
        ChunkAudioURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata,
        ChunkAudioURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata,
        ChunkAudioURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata,
        ChunkAudioURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata,
        None,
    ],
    PropertyInfo(discriminator="type"),
]


class ChunkAudioURLInputChunkAudioURL(BaseModel):
    """Model for audio URL validation."""

    url: str
    """The audio URL. Can be either a URL or a Data URI."""


class ChunkAudioURLInputChunk(BaseModel):
    chunk_index: int
    """position of the chunk in a file"""

    mime_type: Optional[str] = None
    """mime type of the chunk"""

    generated_metadata: Optional[ChunkAudioURLInputChunkGeneratedMetadata] = None
    """metadata of the chunk"""

    model: Optional[str] = None
    """model used for this chunk"""

    type: Optional[Literal["audio_url"]] = None
    """Input type identifier"""

    transcription: Optional[str] = None
    """speech recognition (sr) text of the audio"""

    summary: Optional[str] = None
    """summary of the audio"""

    audio_url: Optional[ChunkAudioURLInputChunkAudioURL] = None
    """Model for audio URL validation."""

    sampling_rate: int
    """The sampling rate of the audio."""


class ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading(BaseModel):
    level: int

    text: str


class ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext(BaseModel):
    level: int

    text: str


class ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["markdown"]] = None

    file_type: Optional[Literal["text/markdown"]] = None

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    chunk_headings: Optional[
        List[ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataChunkHeading]
    ] = None

    heading_context: Optional[
        List[ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadataHeadingContext]
    ] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    frontmatter: Optional[Dict[str, object]] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkVideoURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["text"]] = None

    file_type: Optional[Literal["text/plain"]] = None

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkVideoURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["pdf"]] = None

    file_type: Optional[Literal["application/pdf"]] = None

    total_pages: Optional[int] = None

    total_size: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkVideoURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["code"]] = None

    file_type: str

    language: Optional[str] = None

    word_count: Optional[int] = None

    file_size: Optional[int] = None

    start_line: Optional[int] = None

    num_lines: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkVideoURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["audio"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    total_duration_seconds: Optional[float] = None

    sample_rate: Optional[int] = None

    channels: Optional[int] = None

    audio_format: Optional[int] = None

    bpm: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkVideoURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["video"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    total_duration_seconds: Optional[float] = None

    fps: Optional[float] = None

    width: Optional[int] = None

    height: Optional[int] = None

    frame_count: Optional[int] = None

    has_audio_stream: Optional[bool] = None

    bpm: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ChunkVideoURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata(BaseModel):
    type: Optional[Literal["image"]] = None

    file_type: Optional[str] = None

    file_size: Optional[int] = None

    width: Optional[int] = None

    height: Optional[int] = None

    file_extension: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


ChunkVideoURLInputChunkGeneratedMetadata: TypeAlias = Annotated[
    Union[
        ChunkVideoURLInputChunkGeneratedMetadataMarkdownChunkGeneratedMetadata,
        ChunkVideoURLInputChunkGeneratedMetadataTextChunkGeneratedMetadata,
        ChunkVideoURLInputChunkGeneratedMetadataPdfChunkGeneratedMetadata,
        ChunkVideoURLInputChunkGeneratedMetadataCodeChunkGeneratedMetadata,
        ChunkVideoURLInputChunkGeneratedMetadataAudioChunkGeneratedMetadata,
        ChunkVideoURLInputChunkGeneratedMetadataVideoChunkGeneratedMetadata,
        ChunkVideoURLInputChunkGeneratedMetadataImageChunkGeneratedMetadata,
        None,
    ],
    PropertyInfo(discriminator="type"),
]


class ChunkVideoURLInputChunkVideoURL(BaseModel):
    """Model for video URL validation."""

    url: str
    """The video URL. Can be either a URL or a Data URI."""


class ChunkVideoURLInputChunk(BaseModel):
    chunk_index: int
    """position of the chunk in a file"""

    mime_type: Optional[str] = None
    """mime type of the chunk"""

    generated_metadata: Optional[ChunkVideoURLInputChunkGeneratedMetadata] = None
    """metadata of the chunk"""

    model: Optional[str] = None
    """model used for this chunk"""

    type: Optional[Literal["video_url"]] = None
    """Input type identifier"""

    transcription: Optional[str] = None
    """speech recognition (sr) text of the video"""

    summary: Optional[str] = None
    """summary of the video"""

    video_url: Optional[ChunkVideoURLInputChunkVideoURL] = None
    """Model for video URL validation."""


Chunk: TypeAlias = Annotated[
    Union[ChunkTextInputChunk, ChunkImageURLInputChunk, ChunkAudioURLInputChunk, ChunkVideoURLInputChunk],
    PropertyInfo(discriminator="type"),
]


class StoreFile(BaseModel):
    """Represents a file stored in a store."""

    id: str
    """Unique identifier for the file"""

    filename: Optional[str] = None
    """Name of the file"""

    metadata: Optional[object] = None
    """Optional file metadata"""

    external_id: Optional[str] = None
    """External identifier for this file in the store"""

    status: Optional[StoreFileStatus] = None
    """Processing status of the file"""

    last_error: Optional[object] = None
    """Last error message if processing failed"""

    store_id: str
    """ID of the containing store"""

    created_at: datetime
    """Timestamp of store file creation"""

    version: Optional[int] = None
    """Version number of the file"""

    usage_bytes: Optional[int] = None
    """Storage usage in bytes"""

    usage_tokens: Optional[int] = None
    """Storage usage in tokens"""

    config: Optional[Config] = None
    """Configuration for a file."""

    object: Optional[Literal["store.file"]] = None
    """Type of the object"""

    chunks: Optional[List[Chunk]] = None
    """chunks"""
