# komanda — Case Management

Part of the ShadowStrike War Room Suite.

> Placeholder release — full build coming soon.

## ShadowStrike Suite

| Package | Codename | Role |
|---|---|---|
| `nika-forensics` | Niki | Forensic parser |
| `komanda` | — | Case management |
| `sila` | — | Evidence management |
| `vistina` | — | Legal review |

GitHub: [ShadowStrike-CTF](https://github.com/ShadowStrike-CTF)
