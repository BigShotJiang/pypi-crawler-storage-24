# komanda — Case Management
# ShadowStrike War Room Suite
# Placeholder release — full build coming soon.
__version__ = "0.1.0"
