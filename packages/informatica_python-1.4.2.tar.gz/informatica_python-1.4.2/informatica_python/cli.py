import argparse
import sys
import json
from informatica_python.converter import InformaticaConverter


def main():
    parser = argparse.ArgumentParser(
        prog="informatica-python",
        description="Convert Informatica PowerCenter workflow XML to Python/PySpark code",
    )

    parser.add_argument(
        "input_file",
        help="Path to Informatica workflow XML file",
    )
    parser.add_argument(
        "-o", "--output",
        default="output",
        help="Output directory for generated files (default: output)",
    )
    parser.add_argument(
        "-z", "--zip",
        default=None,
        help="Output as zip file (provide zip file path)",
    )
    parser.add_argument(
        "--data-lib",
        choices=["pandas", "dask", "polars", "vaex", "modin"],
        default="pandas",
        help="Data manipulation library to use (default: pandas)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="output_json",
        help="Output parsed XML as JSON (no code generation)",
    )
    parser.add_argument(
        "--json-file",
        default=None,
        help="Save parsed JSON to a file",
    )

    args = parser.parse_args()

    converter = InformaticaConverter(data_lib=args.data_lib)

    try:
        if args.output_json or args.json_file:
            result = converter.parse_file(args.input_file)
            json_str = json.dumps(result, indent=2, ensure_ascii=False)
            if args.json_file:
                with open(args.json_file, "w", encoding="utf-8") as f:
                    f.write(json_str)
                print(f"JSON saved to: {args.json_file}")
            else:
                print(json_str)
        else:
            output_path = converter.convert(
                args.input_file,
                output_dir=args.output,
                output_zip=args.zip,
            )
            print(f"Conversion complete! Output: {output_path}")
            print(f"Files generated:")
            if args.zip:
                import zipfile
                with zipfile.ZipFile(output_path, "r") as zf:
                    for name in zf.namelist():
                        print(f"  - {name}")
            else:
                import os
                for f in sorted(os.listdir(output_path)):
                    print(f"  - {f}")

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
