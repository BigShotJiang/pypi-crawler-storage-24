import re


INFA_FUNC_MAP = {
    "IIF": "iif_expr",
    "DECODE": "decode_expr",
    "CHOOSE": "choose_expr",
    "IN": "in_expr",
    "LTRIM": "ltrim",
    "RTRIM": "rtrim",
    "TRIM": "trim_func",
    "UPPER": "upper",
    "LOWER": "lower",
    "INITCAP": "initcap",
    "SUBSTR": "substr",
    "LPAD": "lpad",
    "RPAD": "rpad",
    "REVERSE": "reverse_str",
    "CHR": "chr_func",
    "ASCII": "ascii_func",
    "LEFT": "left_str",
    "RIGHT": "right_str",
    "INDEXOF": "indexof",
    "METAPHONE": "metaphone_func",
    "SOUNDEX": "soundex_func",
    "COMPRESS": "compress_func",
    "DECOMPRESS": "decompress_func",
    "TO_CHAR": "to_char",
    "TO_DATE": "to_date",
    "TO_TIMESTAMP": "to_timestamp_func",
    "TO_INTEGER": "to_integer",
    "TO_BIGINT": "to_bigint",
    "TO_FLOAT": "to_float",
    "TO_DECIMAL": "to_decimal",
    "CAST": "cast_func",
    "SYSDATE": "current_timestamp",
    "SYSTIMESTAMP": "current_timestamp",
    "SESSSTARTTIME": "session_start_time",
    "GET_DATE_PART": "get_date_part",
    "SET_DATE_PART": "set_date_part",
    "ADD_TO_DATE": "add_to_date",
    "DATE_DIFF": "date_diff",
    "DATE_COMPARE": "date_compare",
    "LAST_DAY": "last_day",
    "MAKE_DATE_TIME": "make_date_time",
    "TRUNC": "trunc",
    "ROUND": "round_val",
    "ABS": "abs_val",
    "CEIL": "ceil_val",
    "CEILING": "ceil_val",
    "FLOOR": "floor_val",
    "MOD": "mod_val",
    "POWER": "power_val",
    "SQRT": "sqrt_val",
    "LOG": "log_val",
    "LN": "ln_val",
    "EXP": "exp_val",
    "SIGN": "sign_val",
    "RAND": "rand_val",
    "GREATEST": "greatest_val",
    "LEAST": "least_val",
    "LENGTH": "length",
    "CONCAT": "concat",
    "INSTR": "instr",
    "REPLACECHR": "replacechr",
    "REPLACESTR": "replacestr",
    "REG_EXTRACT": "reg_extract",
    "REG_MATCH": "reg_match",
    "REG_REPLACE": "reg_replace",
    "IS_DATE": "is_date",
    "IS_NUMBER": "is_number",
    "IS_SPACES": "is_spaces",
    "NVL": "nvl",
    "NVL2": "nvl2",
    "ISNULL": "isnull",
    "ERROR": "raise_error",
    "ABORT": "abort_func",
    "LOOKUP": "lookup_func",
    "MAX": "max_val",
    "MIN": "min_val",
    "SUM": "sum_val",
    "COUNT": "count_val",
    "AVG": "avg_val",
    "MEDIAN": "median_val",
    "STDDEV": "stddev_val",
    "VARIANCE": "variance_val",
    "PERCENTILE": "percentile_val",
    "FIRST": "first_val",
    "LAST": "last_val",
    "MOVINGAVG": "moving_avg",
    "MOVINGSUM": "moving_sum",
    "CUME": "cume",
    "SETCOUNTVARIABLE": "set_count_variable",
    "SETVARIABLE": "set_variable",
}


AGG_FUNC_NAMES = [
    "MOVINGAVG", "MOVINGSUM", "PERCENTILE", "VARIANCE",
    "STDDEV", "MEDIAN", "COUNT", "FIRST", "LAST",
    "CUME", "SUM", "AVG", "MAX", "MIN",
]


def convert_expression(expr):
    if not expr or not expr.strip():
        return "None"

    cleaned = expr.strip()

    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', cleaned):
        return f'row["{cleaned}"]'

    if re.match(r'^-?\d+(\.\d+)?$', cleaned):
        return cleaned

    if cleaned.startswith("'") and cleaned.endswith("'"):
        return cleaned

    converted = cleaned

    for infa_func, py_func in sorted(INFA_FUNC_MAP.items(), key=lambda x: -len(x[0])):
        pattern = re.compile(r'\b' + re.escape(infa_func) + r'\s*\(', re.IGNORECASE)
        converted = pattern.sub(f'{py_func}(', converted)

    converted = converted.replace("||", " + ")

    converted = re.sub(r'\bAND\b', ' and ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bOR\b', ' or ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bNOT\b', ' not ', converted, flags=re.IGNORECASE)

    converted = re.sub(r'<>', '!=', converted)

    converted = re.sub(r'(?<![<>!])=(?!=)', '==', converted)

    converted = re.sub(r':LKP\.(\w+)\(', r'lookup_func("\1", ', converted)

    converted = re.sub(r'\$\$(\w+)', r'get_variable("\1")', converted)

    converted = re.sub(r':(\w+)', r'row["\1"]', converted)

    converted = re.sub(r'\bTRUE\b', 'True', converted)
    converted = re.sub(r'\bFALSE\b', 'False', converted)
    converted = re.sub(r'\bNULL\b', 'None', converted)

    converted = re.sub(r'\s+', ' ', converted).strip()

    return converted


def convert_filter_expression(expr):
    if not expr or not expr.strip():
        return "True"

    converted = convert_expression(expr)
    return converted


def parse_join_condition(condition):
    if not condition or not condition.strip():
        return [], []

    left_keys = []
    right_keys = []

    parts = re.split(r'\bAND\b', condition, flags=re.IGNORECASE)
    for part in parts:
        part = part.strip()
        match = re.match(r'(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)', part)
        if match:
            left_keys.append(match.group(2))
            right_keys.append(match.group(4))
        else:
            match = re.match(r'(\w+)\s*=\s*(\w+)', part)
            if match:
                left_keys.append(match.group(1))
                right_keys.append(match.group(2))

    return left_keys, right_keys


def parse_lookup_condition(condition):
    if not condition or not condition.strip():
        return [], []

    input_keys = []
    lookup_keys = []

    parts = re.split(r'\bAND\b', condition, flags=re.IGNORECASE)
    for part in parts:
        part = part.strip()
        match = re.match(r'(\w+)\s*=\s*(\w+)', part)
        if match:
            input_keys.append(match.group(1))
            lookup_keys.append(match.group(2))

    return input_keys, lookup_keys


def parse_aggregate_expression(expr):
    if not expr or not expr.strip():
        return None, None

    cleaned = expr.strip()

    for func_name in AGG_FUNC_NAMES:
        pattern = re.compile(
            r'^\s*' + func_name + r'\s*\(\s*([A-Za-z_][A-Za-z0-9_]*|\*)\s*\)\s*$',
            re.IGNORECASE
        )
        match = pattern.match(cleaned)
        if match:
            col = match.group(1).strip()
            return func_name.lower(), col

    return None, None


PANDAS_AGG_MAP = {
    "sum": "sum",
    "count": "count",
    "avg": "mean",
    "max": "max",
    "min": "min",
    "median": "median",
    "stddev": "std",
    "variance": "var",
    "first": "first",
    "last": "last",
}


def convert_sql_expression(sql_expr):
    if not sql_expr or not sql_expr.strip():
        return ""

    converted = sql_expr.strip()
    converted = converted.replace("&#xD;&#xA;", "\n")
    converted = converted.replace("&#xD;", "\r")
    converted = converted.replace("&#xA;", "\n")
    converted = converted.replace("&#x9;", "\t")
    converted = converted.replace("&apos;", "'")
    converted = converted.replace("&quot;", '"')
    converted = converted.replace("&amp;", "&")
    converted = converted.replace("&lt;", "<")
    converted = converted.replace("&gt;", ">")

    return converted


def detect_sql_dialect(sql_text):
    if not sql_text:
        return "generic"

    sql_upper = sql_text.upper()

    if "GETDATE()" in sql_upper or "ISNULL(" in sql_upper or "TOP " in sql_upper:
        return "mssql"
    if "NVL(" in sql_upper or "SYSDATE" in sql_upper or "ROWNUM" in sql_upper:
        return "oracle"
    if "NOW()" in sql_upper or "COALESCE(" in sql_upper:
        return "postgresql"

    return "generic"
