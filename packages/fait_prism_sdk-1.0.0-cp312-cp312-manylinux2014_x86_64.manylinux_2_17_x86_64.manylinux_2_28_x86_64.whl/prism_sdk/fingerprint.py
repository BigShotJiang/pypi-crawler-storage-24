import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
import torch.nn as nn
import numpy as np
import os
import cv2
import sys
import logging
import hashlib
logger = logging.getLogger(__name__)
from prism.fuzzy import FuzzyExtractor
try:
    from core.settings import sys_config
    config = sys_config.load('finger')
except ImportError:
    config = None
try:
    from networks import RidgeNet, DeepPrint_stn, orientation_highest_peak, select_max_orientation
except ImportError as e:
    logger.critical(f'Failed to import Fingerprint Models: {e}')
    sys.exit(1)

def fixed_ridgenet_forward(self, input):
    img_norm = self.img_norm(input)
    conv3 = self.conv3(self.conv2(self.conv1(img_norm)))
    ori_out = torch.sigmoid(self.ori1(self.conv4_1(conv3)) + self.ori2(self.conv4_2(conv3)) + self.ori3(self.conv4_3(conv3)))
    enh_real = self.enh_img_real(input)
    ori_up = F.interpolate(select_max_orientation(orientation_highest_peak(ori_out)), size=(enh_real.shape[2], enh_real.shape[3]), mode='nearest')
    return (enh_real * ori_up).sum(1, keepdim=True)
RidgeNet.forward = fixed_ridgenet_forward

def fixed_deepprint_get_embedding(self, input, align=False):
    x = F.interpolate(input, (299, 299), mode='bilinear', align_corners=False)
    x = self.stem(x)
    return (torch.cat((F.normalize(self.texture_f(self.texture(x))), F.normalize(self.minutiae_f(self.minutiae_e(x)))), dim=1), None)
DeepPrint_stn.get_embedding = fixed_deepprint_get_embedding

class FingerprintExtractor:

    def __init__(self, device=None):
        if device:
            self.device = torch.device(device)
        elif torch.backends.mps.is_available():
            self.device = torch.device('mps')
        elif torch.cuda.is_available():
            self.device = torch.device('cuda')
        else:
            self.device = torch.device('cpu')
        logger.info(f'Fingerprint Pipeline initialized on: {self.device}')
        self.ridge_net = RidgeNet().to(self.device).eval()
        self.deep_print = DeepPrint_stn(crop_shape=np.array(config.preprocessing.crop_shape)).to(self.device).eval()
        self._load_weights()
        self.fuzzy = FuzzyExtractor()
        self.v_threshold = 0.2732

    def check_quality(self, img_np: np.ndarray) -> bool:
        if len(img_np.shape) > 2:
            gray = cv2.cvtColor(img_np, cv2.COLOR_BGR2GRAY)
        else:
            gray = img_np
        var = np.var(gray) / 255.0 ** 2
        return var >= 0.13

    def _load_weights(self):
        r_path, d_path = (config.paths.ridgenet_weights, config.paths.deepprint_weights)
        for model, path in [(self.ridge_net, r_path), (self.deep_print, d_path)]:
            if os.path.exists(path):
                sd = torch.load(path, map_location=self.device).get('model', torch.load(path, map_location=self.device))
                model.load_state_dict({k.replace('module.', ''): v for k, v in sd.items()}, strict=False)

    def _get_salt(self, user_did):
        system_salt = getattr(config.system, 'biometric_salt', 'CAPSTONE_V1')
        return f'{system_salt}:{user_did}'

    def _permute(self, feature_tensor, salt_str):
        seed = int(hashlib.sha256(salt_str.encode()).hexdigest()[:8], 16)
        rng = np.random.default_rng(seed)
        flat = feature_tensor.flatten()
        return flat[rng.permutation(len(flat))]

    def enhance(self, img_tensor):
        with torch.no_grad():
            return torch.tanh(self.ridge_net(img_tensor))

    def extract_feature(self, img_tensor):
        with torch.no_grad():
            emb, _ = self.deep_print.get_embedding(img_tensor)
        return emb

    def enroll_fuzzy(self, raw_tensors, secret, user_did):
        stack = [self.extract_feature(self.enhance(t)) for t in raw_tensors]
        mean_feat = F.normalize(torch.mean(torch.stack(stack), dim=0), p=2, dim=1)
        helper_data = self.fuzzy.lock_secret(self._permute(mean_feat, self._get_salt(user_did)), secret)
        return {'stl_helper': helper_data, 'debug_anchor': {}}

    def verify_fuzzy(self, probe_tensor, helper_data, user_did):
        enh = self.enhance(probe_tensor)
        salt = self._get_salt(user_did)
        helper = helper_data.get('stl_helper', helper_data)
        best_ratio = 0.0
        found_secret = None
        for ang in [-10, -5, 0, 5, 10]:
            feat = self.extract_feature(TF.rotate(enh, ang))
            permuted = self._permute(feat, salt)
            res = self.fuzzy.unlock_secret(permuted, helper)
            secret, stats = res if isinstance(res, tuple) else (res, {'ratio': 1.0 if res else 0.0})
            ratio = stats.get('ratio', 0.0)
            if ratio > best_ratio:
                best_ratio = ratio
            if secret and (not found_secret):
                found_secret = secret
        return {'secret': found_secret, 'v_ratio': best_ratio, 'is_high_quality': best_ratio >= self.v_threshold}
