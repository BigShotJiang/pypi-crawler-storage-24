import os
import json
import time
import logging
import yaml
import ipfshttpclient
import hashlib
import numpy as np
from web3 import Web3
from eth_account import Account
from eth_account.messages import encode_defunct
from cryptography.fernet import Fernet
try:
    from prism.keys import KeyDerivationManager as DeviceKeyManager

    def get_device_key_manager():
        return None
    HAS_DEVICE_KEY_MANAGER = True
except ImportError:
    HAS_DEVICE_KEY_MANAGER = False
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
DEFAULT_CONFIG_PATH = 'blockchain/master.yaml'

class IdentityAgent:

    def __init__(self, config_path=DEFAULT_CONFIG_PATH, key_path=None):
        self.config = self._load_config(config_path)
        rpc_url = self.config.get('network', {}).get('rpc_url', 'http://localhost:8545')
        ipfs_addr = self.config.get('network', {}).get('ipfs_api', '/ip4/127.0.0.1/tcp/5001')
        self.chain_id = self.config.get('network', {}).get('chain_id', 1337)
        if key_path:
            self.key_path = key_path
        else:
            self.key_path = self.config.get('identities', {}).get('user_key_path', 'storage/keys/prism_wallet.key')
        self.account = self._load_or_initialize_wallet()
        self.did = f'did:ethr:{self.account.address}'
        self.device_key_manager = None
        self.owner_key = None
        self.owner_did = None
        self.cluster_key = None
        self.w3 = None
        self.current_rpc_node = None
        self._connect_to_chain()
        self.ipfs = None
        try:
            import ipfshttpclient.client
            ipfshttpclient.client.assert_version = lambda *args, **kwargs: None
        except ImportError:
            pass
        for attempt in range(1, 6):
            try:
                self.ipfs = ipfshttpclient.connect(ipfs_addr)
                self.ipfs.id()
                logger.info(f'[OK] Connected to IPFS at {ipfs_addr}')
                break
            except Exception as e:
                logger.warning(f'IPFS Connection Attempt {attempt}/5 failed: {e}')
                time.sleep(2)
        if not self.ipfs:
            logger.error('[ERR] IPFS Connection FAILED permanently.')
        device_root_key_path = self.config.get('security', {}).get('device_root_key_path', 'storage/keys/device_root.key')
        if HAS_DEVICE_KEY_MANAGER and os.path.exists(device_root_key_path):
            try:
                self.device_key_manager = DeviceKeyManager(device_root_key_path)
                logger.info(f'[OK] Device Key Manager Loaded (kiosk mode)')
            except Exception as e:
                logger.warning(f'Failed to load Device Key Manager: {e}')

    def _connect_to_chain(self):
        nodes = []
        primary = self.config.get('network', {}).get('rpc_url')
        if primary:
            nodes.append(primary)
        fallbacks = self.config.get('network', {}).get('rpc_nodes', [])
        for f in fallbacks:
            if f not in nodes:
                nodes.append(f)
        from web3.middleware import ExtraDataToPOAMiddleware
        for url in nodes:
            try:
                w3 = Web3(Web3.HTTPProvider(url))
                w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)
                if w3.is_connected():
                    self.w3 = w3
                    self.current_rpc_node = url
                    logger.info(f'[OK] Connected to Blockchain at {url}')
                    return
                else:
                    logger.warning(f'[WARN] RPC Node Unreachable: {url}')
            except Exception as e:
                logger.warning(f'[WARN] Error connecting to {url}: {e}')
        logger.critical('[ERR] ALL RPC NODES UNREACHABLE.')
        owner_key_paths = [self.config.get('security', {}).get('owner_key_path', 'config/device_owner.json'), 'config.json']
        for path in owner_key_paths:
            if os.path.exists(path):
                try:
                    import base64
                    with open(path, 'r') as f:
                        owner_config = json.load(f)
                    if 'owner_key' in owner_config:
                        self.owner_key = base64.urlsafe_b64decode(owner_config['owner_key'])
                        self.owner_did = owner_config.get('owner_did')
                        logger.info(f'[OK] Owner Key Loaded from {path} (personal device mode, bound to {self.owner_did[:20]}...)')
                        break
                except Exception as e:
                    logger.warning(f'Failed to load owner key from {path}: {e}')
        if self.device_key_manager is None and self.owner_key is None:
            cluster_key_path = self.config.get('security', {}).get('cluster_key_path', None)
            if cluster_key_path and os.path.exists(cluster_key_path):
                try:
                    with open(cluster_key_path, 'rb') as f:
                        self.cluster_key_bytes = f.read().strip()
                        self.fernet = Fernet(self.cluster_key_bytes)
                    logger.info(f'[OK] Cluster Encryptor Loaded (legacy mode)')
                except Exception as e:
                    logger.error(f'Failed to load Cluster Key: {e}')
            else:
                logger.warning('[WARN] No encryption key found. Encryption is disabled.')
        logger.info(f'Agent Ready: {self.did[:30]}...')

    def submit_tx_with_timeout(self, tx_func, timeout=30, retry_on_fail=True):
        import gevent
        from gevent import Timeout as GeventTimeout
        try:
            with GeventTimeout(timeout, False):
                tx_hash = tx_func()
                if tx_hash is None:
                    return {'status': 'error', 'error': 'TX function returned None'}
                receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=timeout)
                if receipt.status == 1:
                    return {'status': 'ok', 'receipt': receipt, 'block': receipt.blockNumber, 'tx_hash': tx_hash.hex() if hasattr(tx_hash, 'hex') else str(tx_hash)}
                else:
                    return {'status': 'error', 'error': 'Transaction reverted', 'receipt': receipt}
        except GeventTimeout:
            logger.warning(f'TX timeout after {timeout}s')
            if retry_on_fail and self.config.get('network', {}).get('rpc_nodes'):
                logger.info('Attempting failover to another node...')
                self._connect_to_chain()
            return {'status': 'timeout', 'error': f'Transaction timeout after {timeout}s. Cluster may be unhealthy.'}
        except Exception as e:
            logger.error(f'TX submission failed: {e}')
            return {'status': 'error', 'error': str(e)}

    def _load_config(self, path):
        config = {}
        if os.path.exists(path):
            try:
                with open(path, 'r') as f:
                    config = yaml.safe_load(f) or {}
            except Exception as e:
                logger.error(f'Failed to load config from {path}: {e}')
        env_rpc = os.getenv('PRISM_RPC')
        env_ipfs = os.getenv('PRISM_IPFS')
        if 'network' not in config:
            config['network'] = {}
        if env_rpc:
            logger.info(f' Overriding RPC from env: {env_rpc}')
            config['network']['rpc_url'] = env_rpc
        if env_ipfs:
            logger.info(f' Overriding IPFS from env: {env_ipfs}')
            config['network']['ipfs_api'] = env_ipfs
        return config

    def _normalize_did(self, did: str) -> str:
        if not did:
            return did
        if did.startswith('0x'):
            return f'did:ethr:{did}'
        return did

    def _get_user_fernet(self, user_did: str) -> Fernet:
        import base64
        user_did = self._normalize_did(user_did)
        if self.device_key_manager is not None:
            return self.device_key_manager.get_user_fernet(user_did)
        if self.owner_key is not None:
            owner_norm = self._normalize_did(self.owner_did).lower() if self.owner_did else None
            if owner_norm and owner_norm == user_did.lower():
                return Fernet(base64.urlsafe_b64encode(self.owner_key))
            else:
                logger.debug(f"Personal device bound to {(self.owner_did[:20] if self.owner_did else 'None')}... cannot decrypt data for different user {user_did[:20]}...")
                return None
        if hasattr(self, 'fernet') and self.fernet is not None:
            logger.debug('Using legacy cluster_key for encryption (global, not per-user)')
            return self.fernet
        return None

    def _load_or_initialize_wallet(self):
        if os.path.exists(self.key_path):
            with open(self.key_path, 'r') as f:
                return Account.from_key(f.read().strip())
        new_acc = Account.create()
        os.makedirs(os.path.dirname(self.key_path), exist_ok=True)
        with open(self.key_path, 'w') as f:
            f.write(new_acc.key.hex())
        logger.info(f'New Wallet Created: {self.key_path}')
        return new_acc

    def sign_attendance_vc(self, user_id, name, proof_hash, liveness_status, session_sig=None) -> dict:
        payload = {'issuer': self.did, 'issuanceDate': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'credentialSubject': {'id': user_id, 'user_id': user_id, 'name': name, 'biometricBinding': {'method': 'Bimodal-Hierarchical', 'vaultReleaseStatus': True, 'proofHash': proof_hash, 'livenessStatus': bool(liveness_status), 'sessionSignature': session_sig}}}
        message = encode_defunct(text=json.dumps(payload, sort_keys=True))
        signed_message = self.account.sign_message(message)
        return {**payload, 'proof': {'type': 'EcdsaSecp256k1Signature2019', 'signatureValue': signed_message.signature.hex()}}

    def create_profile(self, user_data, vault_data, face_data, face_template, metadata=None):
        try:
            if isinstance(face_template, np.ndarray):
                face_template = face_template.tolist()
            elif isinstance(face_template, dict):
                logger.error(f' SECURITY RISK: face_template is a dict! Data: {face_template}')
                raise ValueError('Face template cannot be a dictionary.')
            face_template = [float(x) for x in face_template]
        except Exception as e:
            logger.error(f'Face Template Validation Failed: {e}')
            raise RuntimeError(f'Biometric Data Error: {e}')
        metadata = metadata or {}
        profile = {'identity': {'did': self._normalize_did(user_data['did']), 'user_id': user_data.get('user_id'), 'name': user_data['name'], 'email': metadata.get('email') or user_data.get('email') or '', 'college': metadata.get('college') or '', 'department': metadata.get('department') or '', 'position': metadata.get('position') or ''}, 'security': {'fingerprint_vault': vault_data, 'encrypted_keys': face_data, 'face_template': face_template}, 'metadata': metadata, 'meta': {'version': '1.2', 'created_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}}
        cid = self.upload_to_ipfs(profile)
        logger.info(f'Created Profile: {cid[:16]}...')
        logger.debug(f"Profile details - User: {user_data.get('user_id', 'N/A')}, CID: {cid}")
        return cid

    def resolve_profile(self, info_data, user_did: str=None):
        if not self.ipfs:
            return None
        cid = info_data
        if isinstance(info_data, (bytes, bytearray)):
            if user_did is None:
                logger.error('Encrypted CID received but no user_did provided for decryption')
                return None
            logger.debug(f' Resolving encrypted profile for DID: {user_did[:30]}...')
            user_fernet = self._get_user_fernet(user_did)
            if user_fernet:
                try:
                    cid = user_fernet.decrypt(info_data).decode()
                    logger.debug(f' Decrypted CID for {user_did[:20]}...: {cid}')
                except Exception as e:
                    logger.error(f'Decryption failed for {user_did}: {e}')
                    return None
            else:
                try:
                    cid = info_data.decode()
                    logger.debug(f' Using unencrypted CID: {cid}')
                except:
                    logger.error('Received encrypted data but no encryption key available.')
                    return None
        try:
            profile = self.ipfs.get_json(cid)
            if not isinstance(profile, dict):
                logger.error(f' IPFS returned non-dict profile (type={type(profile)}). CID: {cid}')
                return None
            security = profile.get('security', {})
            if isinstance(security.get('encrypted_keys'), (bytes, bytearray)):
                logger.error(f' encrypted_keys is bytes instead of dict! Profile may be corrupted.')
            return profile
        except Exception as e:
            logger.error(f'Failed to resolve profile {cid}: {e}')
            return None

    def log_attendance_on_chain(self, attendance_contract, user_addr, attendance_cid, status, admin_account, admin_pk):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            checksum_addr = self.w3.to_checksum_address(user_addr)
            tx = attendance_contract.functions.record(checksum_addr, attendance_cid, status).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Attendance Logged on Chain: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Chain Log Failed: {e}')
            return None

    def pin_to_remote(self, cid):
        pinata_jwt = os.getenv('PINATA_JWT') or self.config.get('network', {}).get('pinata_jwt')
        if pinata_jwt:
            try:
                import requests
                url = 'https://api.pinata.cloud/pinning/pinByHash'
                headers = {'Authorization': f'Bearer {pinata_jwt}', 'Content-Type': 'application/json'}
                body = {'hashToPin': cid, 'pinataMetadata': {'name': f'Prism_Profile_{cid}'}}
                response = requests.post(url, json=body, headers=headers)
                if response.status_code == 200:
                    logger.info(f' Pinned to Pinata: {cid[:16]}...')
                else:
                    logger.warning(f'Pinata Pinning Failed: {response.text}')
            except Exception as e:
                logger.error(f'Remote Pinning Error: {e}')
        else:
            try:
                self.ipfs.pin.add(cid)
                logger.debug(f'Confirmed Local Pin: {cid}')
            except Exception as e:
                logger.debug(f'Local Pin Check: {e}')

    def upload_to_ipfs(self, data: dict) -> str:
        if not self.ipfs:
            raise RuntimeError('IPFS Node not connected.')
        try:
            res = self.ipfs.add_json(data)
            cid = res
            logger.debug(f'IPFS Upload Success: {cid}')
            self.pin_to_remote(cid)
            return cid
        except Exception as e:
            logger.error(f'IPFS Upload Failed: {e}')
            return None

    def anchor_identity(self, registry_contract, admin_account, admin_pk, info_cid, target_addr=None, target_did=None):
        if not self.w3:
            logger.error('Web3 client not initialized.')
            return None
        user_to_enroll = target_addr if target_addr else self.account.address
        did_to_enroll = target_did if target_did else self.did
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            final_cid_payload = info_cid
            user_fernet = self._get_user_fernet(did_to_enroll)
            if user_fernet:
                final_cid_payload = user_fernet.encrypt(info_cid.encode())
                logger.debug(f' Encrypted CID for {did_to_enroll[:20]}...')
            checksum_user = self.w3.to_checksum_address(user_to_enroll)
            tx = registry_contract.functions.enroll(checksum_user, did_to_enroll, final_cid_payload).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 500000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Identity Anchor TX sent: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Anchoring Failed: {e}')
            return None

    def request_revocation(self, registry_contract, admin_account, admin_pk, target_addr):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            target_addr = self.w3.to_checksum_address(target_addr)
            tx = registry_contract.functions.requestRevocation(target_addr).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Revocation Requested TX sent: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Request Revocation Failed: {e}')
            return None

    def consent_revocation(self, registry_contract, admin_account, admin_pk, target_addr, user_signature):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            target_addr = self.w3.to_checksum_address(target_addr)
            tx = registry_contract.functions.consentRevocation(target_addr, user_signature).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 300000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Consent Revocation TX sent: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Consent Revocation Failed: {e}')
            return None

    def finalize_revocation(self, registry_contract, admin_account, admin_pk, target_addr):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            target_addr = self.w3.to_checksum_address(target_addr)
            tx = registry_contract.functions.finalizeRevocation(target_addr).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Finalize Revocation TX sent: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Finalize Revocation Failed: {e}')
            return None

    def cancel_revocation(self, registry_contract, admin_account, admin_pk, target_addr):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            target_addr = self.w3.to_checksum_address(target_addr)
            tx = registry_contract.functions.cancelRevocation(target_addr).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Cancel Revocation TX sent: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Cancel Revocation Failed: {e}')
            return None

    def revoke_user(self, registry_contract, admin_account, admin_pk, target_addr):
        logger.warning('revoke_user() is deprecated. Use request_revocation() for two-phase revocation.')
        return self.request_revocation(registry_contract, admin_account, admin_pk, target_addr)

    def reissue_user(self, registry_contract, admin_account, admin_pk, target_addr, new_did, new_cid, user_signature=None):
        if not self.w3:
            return None
        if user_signature is None:
            raise ValueError('user_signature is required for reissuance. Provide a pre-signed consent voucher.')
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            final_cid = new_cid
            user_fernet = self._get_user_fernet(new_did)
            if user_fernet:
                final_cid = user_fernet.encrypt(new_cid.encode())
            target_addr = self.w3.to_checksum_address(target_addr)
            tx = registry_contract.functions.reissueUser(target_addr, new_did, final_cid, user_signature).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 500000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Reissue TX sent: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Reissue Failed: {e}')
            return None

    def suspend_user(self, registry_contract, admin_account, admin_pk, user_addr, reason=1):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            user_addr = self.w3.to_checksum_address(user_addr)
            tx = registry_contract.functions.suspendUser(user_addr, reason).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.warning(f' User SUSPENDED: {user_addr} (reason: {reason})')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Suspend User Failed: {e}')
            return None

    def reinstate_user(self, registry_contract, admin_account, admin_pk, user_addr):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            user_addr = self.w3.to_checksum_address(user_addr)
            tx = registry_contract.functions.reinstateUser(user_addr).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f' User REINSTATED: {user_addr}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Reinstate User Failed: {e}')
            return None

    def is_user_suspended(self, registry_contract, user_addr):
        if not self.w3:
            return True
        try:
            user_addr = self.w3.to_checksum_address(user_addr)
            return registry_contract.functions.isUserSuspended(user_addr).call()
        except Exception as e:
            logger.error(f'Check User Suspended Failed: {e}')
            return True

    def update_profile_metadata(self, registry_contract, admin_account, admin_pk, target_addr, new_metadata):
        try:
            logger.info(f'Starting Safe Metadata Update for {target_addr}')
            current_data = self.get_user_profile(registry_contract, target_addr)
            if 'error' in current_data:
                raise ValueError(f"Could not fetch current profile: {current_data['error']}")
            current_profile = current_data.get('profile')
            if not current_profile:
                raise ValueError('No existing profile found. User must be Enrolled first.')
            security_block = current_profile.get('security')
            if not security_block:
                raise ValueError('Corrupt profile: No security block found.')
            import hashlib, json
            original_security_hash = hashlib.sha256(json.dumps(security_block, sort_keys=True).encode()).hexdigest()
            logger.debug(f'Original Security Hash: {original_security_hash}')
            vault_data = security_block.get('fingerprint_vault')
            face_data = security_block.get('encrypted_keys')
            face_template = security_block.get('face_template')
            identity_block = current_profile.get('identity', {})
            user_data = {'did': identity_block.get('did'), 'user_id': identity_block.get('user_id'), 'name': identity_block.get('name'), 'email': identity_block.get('email')}
            merged_metadata = {'email': new_metadata.get('email') or identity_block.get('email'), 'college': new_metadata.get('college') or identity_block.get('college'), 'department': new_metadata.get('department') or identity_block.get('department'), 'position': new_metadata.get('position') or identity_block.get('position')}
            reconstructed_security = {'fingerprint_vault': vault_data, 'encrypted_keys': face_data, 'face_template': face_template}
            new_security_hash = hashlib.sha256(json.dumps(reconstructed_security, sort_keys=True).encode()).hexdigest()
            if original_security_hash != new_security_hash:
                logger.critical(f'INTEGRITY FAILURE: {original_security_hash} != {new_security_hash}')
                raise RuntimeError('Security Block Corruption Detected! Aborting update to prevent lock-out.')
            if user_data['did'] != identity_block.get('did'):
                logger.critical(f"DID MISMATCH: Original {identity_block.get('did')} vs New {user_data['did']}")
                raise RuntimeError('DID integrity check failed: DID was altered during metadata update.')
            new_cid = self.create_profile(user_data=user_data, vault_data=vault_data, face_data=face_data, face_template=face_template, metadata=merged_metadata)
            receipt = self.reissue_user(registry_contract, admin_account, admin_pk, target_addr, user_data['did'], new_cid)
            return receipt
        except Exception as e:
            logger.error(f'Safe Metadata Update Failed: {e}')
            raise e

    def toggle_pause(self, registry_contract, admin_account, admin_pk):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.togglePause().build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 100000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Toggle Pause TX sent: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Toggle Pause Failed: {e}')
            return None

    def get_user_profile(self, registry_contract, user_addr):
        if not self.w3:
            return {'error': 'No Blockchain Connection'}
        try:
            if isinstance(user_addr, str) and user_addr.startswith('did:ethr:0x'):
                user_addr = user_addr.split(':')[-1]
            user_addr = self.w3.to_checksum_address(user_addr)
            did, info_cid_bytes, is_valid = registry_contract.functions.profiles(user_addr).call()
            profile = {}
            if info_cid_bytes and len(info_cid_bytes) > 0:
                profile = self.resolve_profile(info_cid_bytes, user_did=did) or {}
            return {'address': user_addr, 'did': did, 'status': 'Active' if is_valid else 'Revoked', 'profile': profile}
        except Exception as e:
            logger.error(f'Get Profile Failed: {e}')
            return {'error': str(e)}

    def set_enroll_auth(self, registry_contract, admin_account, admin_pk, target_addr, status):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.setEnrollAuth(target_addr, status).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 100000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Set Enroll Auth TX: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Set Enroll Auth Failed: {e}')
            return None

    def set_kiosk_record_auth(self, registry_contract, admin_account, admin_pk, target_addr, status):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.setKioskRecordAuth(target_addr, status).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 150000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Set Kiosk Record Auth TX: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Set Kiosk Record Auth Failed: {e}')
            return None

    def set_remote_record_auth(self, registry_contract, admin_account, admin_pk, target_addr, status):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.setRemoteRecordAuth(target_addr, status).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 150000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Set Remote Record Auth TX: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Set Remote Record Auth Failed: {e}')
            return None

    def set_revoke_auth(self, registry_contract, admin_account, admin_pk, target_addr, status):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.setRevokeAuth(target_addr, status).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 100000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Set Revoke Auth TX: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Set Revoke Auth Failed: {e}')
            return None

    def check_permissions(self, registry_contract, address):
        if not self.w3:
            return {'canEnroll': False, 'canRecord': False, 'canRevoke': False}
        try:
            can_enroll = registry_contract.functions.canEnroll(address).call()
            can_record = registry_contract.functions.canRecord(address).call()
            can_revoke = registry_contract.functions.canRevoke(address).call()
            permissions = {'canEnroll': can_enroll, 'canRecord': can_record, 'canRevoke': can_revoke}
            logger.info(f'Permissions for {address}: {permissions}')
            return permissions
        except Exception as e:
            logger.error(f'Permission Check Failed: {e}')
            return {'canEnroll': False, 'canRecord': False, 'canRevoke': False}

    def suspend_device(self, registry_contract, admin_account, admin_pk, device_addr, reason=1):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.suspendDevice(device_addr, reason).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 100000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.warning(f' Device SUSPENDED: {device_addr} (reason: {reason})')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Suspend Device Failed: {e}')
            return None

    def reinstate_device(self, registry_contract, admin_account, admin_pk, device_addr):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.reinstateDevice(device_addr).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 100000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f' Device REINSTATED: {device_addr}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Reinstate Device Failed: {e}')
            return None

    def is_device_suspended(self, registry_contract, device_addr):
        if not self.w3:
            return True
        try:
            return registry_contract.functions.isDeviceSuspended(device_addr).call()
        except Exception as e:
            logger.error(f'Check Suspended Failed: {e}')
            return True

    def add_node(self, permissions_contract, admin_account, admin_pk, enode):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = permissions_contract.functions.addNode(enode).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 300000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Add Node TX: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Add Node Failed: {e}')
            return None

    def remove_node(self, permissions_contract, admin_account, admin_pk, enode):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = permissions_contract.functions.removeNode(enode).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 300000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Remove Node TX: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Remove Node Failed: {e}')
            return None

    def get_authorized_nodes(self, permissions_contract):
        if not self.w3:
            return []
        try:
            added_events = permissions_contract.events.NodeAdded.get_logs(from_block=0)
            nodes = []
            seen_hashes = set()
            for event in added_events:
                enode_hash = event.args.enodeHash
                if enode_hash in seen_hashes:
                    continue
                seen_hashes.add(enode_hash)
                if permissions_contract.functions.isNodeAuthorized(enode_hash).call():
                    enode_str = event.args.enode
                    nodes.append({'id': len(nodes) + 1, 'enodeHash': enode_hash.hex() if hasattr(enode_hash, 'hex') else str(enode_hash), 'enode': enode_str})
            return nodes
        except Exception as e:
            logger.error(f'Get Nodes Failed: {e}')
            return []

    def ban_user(self, registry_contract, admin_account, admin_pk, user_addr):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            user_addr = self.w3.to_checksum_address(user_addr)
            tx = registry_contract.functions.banUser(user_addr).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.warning(f' User PERMANENTLY BANNED: {user_addr}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Ban User Failed: {e}')
            return None

    def ban_device(self, registry_contract, admin_account, admin_pk, device_addr):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.banDevice(device_addr).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.warning(f' Device PERMANENTLY BANNED: {device_addr}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Ban Device Failed: {e}')
            return None

    def register_kiosk_enode(self, registry_contract, admin_account, admin_pk, device_addr, enode_hash):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.registerKioskEnode(device_addr, enode_hash).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Register Kiosk Enode TX: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Register Kiosk Enode Failed: {e}')
            return None

    def revoke_kiosk_enode(self, registry_contract, admin_account, admin_pk, kiosk_addr):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.revokeKioskEnode(kiosk_addr).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.warning(f' Kiosk Enode REVOKED: {kiosk_addr}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Revoke Kiosk Enode Failed: {e}')
            return None

    def set_reissue_auth(self, registry_contract, admin_account, admin_pk, target_addr, status):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = registry_contract.functions.setReissueAuth(target_addr, status).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 100000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.info(f'Set Reissue Auth TX: {tx_hash.hex()}')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Set Reissue Auth Failed: {e}')
            return None

    def ban_node(self, permissions_contract, admin_account, admin_pk, enode):
        if not self.w3:
            return None
        try:
            nonce = self.w3.eth.get_transaction_count(admin_account.address)
            tx = permissions_contract.functions.banNode(enode).build_transaction({'from': admin_account.address, 'nonce': nonce, 'gas': 200000, 'gasPrice': 0, 'chainId': self.chain_id})
            signed = self.w3.eth.account.sign_transaction(tx, admin_pk)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            logger.warning(f' Node PERMANENTLY BANNED: {enode[:30]}...')
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as e:
            logger.error(f'Ban Node Failed: {e}')
            return None
