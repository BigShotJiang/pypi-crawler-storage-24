import torch, torch.nn as nn, torch.nn.functional as F
import torchvision.models as models

class SecureEfficientNet(nn.Module):

    def __init__(self, embedding_size=128, key_dim=100, pretrained=False):
        super(SecureEfficientNet, self).__init__()
        print('Initializing SecureEfficientNet (EfficientNet B0)...')
        self.backbone = models.efficientnet_b0(weights=None)
        self.backbone.classifier = nn.Identity()
        prev_dim = 1280
        self.embedding = nn.Linear(prev_dim, embedding_size)
        self.key_dim = key_dim
        combined_dim = embedding_size + key_dim
        self.fc1 = nn.Sequential(nn.Linear(combined_dim, 100), nn.ReLU())
        self.fc2 = nn.Sequential(nn.Linear(100, 100), nn.ReLU())

    def forward(self, x, k):
        x = self.backbone(x)
        x = x.flatten(start_dim=1)
        x = self.embedding(x)
        if k.dim() == 1:
            k = k.unsqueeze(0)
        if k.size(0) != x.size(0):
            k = k.expand(x.size(0), -1)
        x = torch.cat((x, k), dim=1)
        x = self.fc1(x)
        x = self.fc2(x)
        x = F.normalize(x, p=2, dim=1)
        return x
