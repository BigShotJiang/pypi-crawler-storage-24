__all__ = ['SecureEfficientNet', 'InceptionResNet']

def __getattr__(name):
    if name == 'SecureEfficientNet':
        from .efficientnet import SecureEfficientNet
        return SecureEfficientNet
    elif name == 'InceptionResNet':
        from .inception_resnet import InceptionResNet
        return InceptionResNet
    raise AttributeError(f"module 'prism_sdk.networks' has no attribute {name!r}")
