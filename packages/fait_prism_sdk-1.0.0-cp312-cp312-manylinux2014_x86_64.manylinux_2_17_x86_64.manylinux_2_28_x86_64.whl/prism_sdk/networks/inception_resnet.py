import torch, torch.nn as nn, torch.nn.functional as F
from facenet_pytorch import InceptionResnetV1

class InceptionResNet(nn.Module):

    def __init__(self, embedding_size=128, key_dim=100, pretrained=False):
        super(InceptionResNet, self).__init__()
        print('Initializing InceptionResNet (SecureFaceNetwork)...')
        self.backbone = InceptionResnetV1(pretrained=None, classify=True, num_classes=1000)
        self.backbone.logits = nn.Identity()
        self.backbone.last_linear = nn.Identity()
        self.backbone.last_bn = nn.Identity()
        self.backbone_dim = 1792
        combined_dim = self.backbone_dim + key_dim
        self.fc1 = nn.Sequential(nn.Linear(combined_dim, 100), nn.ReLU())
        self.fc2 = nn.Sequential(nn.Linear(100, 100), nn.ReLU())

    def forward(self, x, k):
        x = self.backbone(x)
        if k.dim() == 1:
            k = k.unsqueeze(0).expand(x.size(0), -1)
        if x.shape[1] + k.shape[1] != 1892:
            raise ValueError('Input dimensions do not match expected dimensions')
        x = torch.cat((x, k), dim=1)
        x = self.fc1(x)
        x = self.fc2(x)
        return x
