__all__ = ['IdentityAgent', 'FingerprintExtractor']

def __getattr__(name):
    if name == 'IdentityAgent':
        from .agent import IdentityAgent
        return IdentityAgent
    elif name == 'FingerprintExtractor':
        from .fingerprint import FingerprintExtractor
        return FingerprintExtractor
    raise AttributeError(f"module 'prism_sdk' has no attribute {name!r}")
