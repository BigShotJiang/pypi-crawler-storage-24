"""Shared auth config format for CLI and validator.

Reads/writes ~/.blockmachine/config.json with network-scoped tokens.

NOTE: This file is intentionally duplicated in:
  - cli/auth_config.py   (ships in the pip wheel)
  - common/auth_config.py (used by validator via Docker COPY)
Keep both copies identical.
"""

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Known network configs (netuid → network name)
NETUID_TO_NETWORK: dict[int, str] = {
    19: "mainnet",
    417: "testnet",
}

DEFAULT_CONFIG_DIR = Path.home() / ".blockmachine"
CONFIG_FILE = "config.json"


@dataclass
class TokenEntry:
    """Token pair for a specific role (miner/validator)."""

    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    token_expires_at: Optional[str] = None


@dataclass
class NetworkEntry:
    """Per-network config with optional overrides and scoped tokens."""

    auth_url: Optional[str] = None
    api_url: Optional[str] = None
    client_id: Optional[str] = None
    netuid: Optional[int] = None
    tokens: dict[str, TokenEntry] = field(default_factory=dict)


@dataclass
class AuthConfig:
    """Shared config stored in ~/.blockmachine/config.json"""

    active_miner_node: Optional[str] = None
    networks: dict[str, NetworkEntry] = field(default_factory=dict)

    def get_token(self, network: str, role: str) -> Optional[TokenEntry]:
        net = self.networks.get(network)
        if not net:
            return None
        return net.tokens.get(role)

    def set_token(self, network: str, role: str, entry: TokenEntry) -> None:
        net = self.networks.setdefault(network, NetworkEntry())
        net.tokens[role] = entry

    def get_network(self, network: str) -> NetworkEntry:
        return self.networks.setdefault(network, NetworkEntry())


def get_config_dir() -> Path:
    return Path(os.environ.get("BM_CONFIG_DIR", str(DEFAULT_CONFIG_DIR)))


def get_config_path() -> Path:
    return get_config_dir() / CONFIG_FILE


def load_auth_config() -> AuthConfig:
    """Load config from disk, migrating legacy format if needed."""
    config_path = get_config_path()

    if not config_path.exists():
        return AuthConfig()

    try:
        with open(config_path) as f:
            data = json.load(f)
    except (json.JSONDecodeError, IOError):
        return AuthConfig()

    if "networks" in data:
        return _load_new_format(data)

    return _migrate_legacy(data)


def _load_new_format(data: dict[str, Any]) -> AuthConfig:
    networks: dict[str, NetworkEntry] = {}
    for net_name, net_data in data.get("networks", {}).items():
        tokens: dict[str, TokenEntry] = {}
        for role, tok_data in net_data.get("tokens", {}).items():
            tokens[role] = TokenEntry(
                access_token=tok_data.get("access_token"),
                refresh_token=tok_data.get("refresh_token"),
                token_expires_at=tok_data.get("token_expires_at"),
            )
        networks[net_name] = NetworkEntry(
            auth_url=net_data.get("auth_url"),
            api_url=net_data.get("api_url"),
            client_id=net_data.get("client_id"),
            netuid=net_data.get("netuid"),
            tokens=tokens,
        )
    return AuthConfig(
        active_miner_node=data.get("active_miner_node"),
        networks=networks,
    )


def _migrate_legacy(data: dict[str, Any]) -> AuthConfig:
    """Replace legacy flat config with an empty new-format config."""
    logger.info("Removing legacy config — please login again")
    config = AuthConfig()
    save_auth_config(config)
    return config


def save_auth_config(config: AuthConfig) -> None:
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    serialized: dict[str, Any] = {
        "active_miner_node": config.active_miner_node,
        "networks": {},
    }

    for net_name, net_entry in config.networks.items():
        net_data: dict[str, Any] = {"tokens": {}}
        if net_entry.auth_url:
            net_data["auth_url"] = net_entry.auth_url
        if net_entry.api_url:
            net_data["api_url"] = net_entry.api_url
        if net_entry.client_id:
            net_data["client_id"] = net_entry.client_id
        if net_entry.netuid is not None:
            net_data["netuid"] = net_entry.netuid
        for role, tok in net_entry.tokens.items():
            net_data["tokens"][role] = {
                "access_token": tok.access_token,
                "refresh_token": tok.refresh_token,
                "token_expires_at": tok.token_expires_at,
            }
        serialized["networks"][net_name] = net_data

    config_path = get_config_path()
    with open(config_path, "w") as f:
        json.dump(serialized, f, indent=2)

    os.chmod(config_path, 0o600)
