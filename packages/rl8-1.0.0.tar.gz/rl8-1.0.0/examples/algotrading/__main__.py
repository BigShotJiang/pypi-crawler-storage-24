import argparse

import mlflow
import torch

from rl8 import TrainConfig
from rl8.conditions import Plateaus

from .env import AlgoTrading
from .models import AttentiveAlpaca, LazyLemur, MischievousMule

parser = argparse.ArgumentParser(
    description=(
        "An example algotrading environment where a policy learns to hold, buy, and"
        " sell an asset. This example serves as a playground for custom,"
        " sequence-based and recurrent models."
    )
)
parser.add_argument(
    "--model",
    choices=["lstm", "mlp", "transformer"],
    default="mlp",
    help="Model class type to use.",
)
args = parser.parse_args()

match args.model:
    case "lstm":
        recurrent = True
        model_cls = LazyLemur
    case "mlp":
        recurrent = False
        model_cls = MischievousMule
    case "transformer":
        recurrent = False
        model_cls = AttentiveAlpaca

experiment = mlflow.set_experiment("rl8.examples.algotrading")
print(f"Logging run under MLflow experiment {experiment.experiment_id}")
train_config = TrainConfig(
    AlgoTrading,
    algorithm_config={
        "model_cls": model_cls,
        "enable_amp": torch.cuda.is_available(),
        "device": "auto",
    },
    recurrent=recurrent,
)
trainer = train_config.build()
run = mlflow.active_run()
print(f"Logging metrics under MLflow run {run.info.run_id}")
trainer.run(
    steps_per_eval=10,
    stop_conditions=[Plateaus("returns/mean", patience=10, rtol=0.05)],
)
