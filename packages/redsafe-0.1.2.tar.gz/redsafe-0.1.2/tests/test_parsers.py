from pathlib import Path

from parsers.burp_xml_parser import parse_burp_input, parse_burp_xml
from parsers.http_parser import parse_http_file, parse_http_request, parse_http_response
from parsers.log_parser import parse_network_log
from parsers.pcap_parser import parse_pcap_basic


ROOT = Path(__file__).resolve().parent


def test_parse_http_request_extracts_fields():
    raw = (
        "POST /login?next=/home HTTP/1.1\r\n"
        "Host: app.local\r\n"
        "Content-Type: application/x-www-form-urlencoded\r\n\r\n"
        "email=user@example.com&password=secret123"
    )
    req = parse_http_request(raw)
    assert req.method == "POST"
    assert req.path == "/login?next=/home"
    assert req.headers["Host"] == "app.local"
    assert req.parameters["email"] == "user@example.com"
    assert req.parameters["password"] == "secret123"




def test_parse_http_request_handles_lowercase_content_type_for_form_params():
    raw = (
        "POST /submit HTTP/1.1\n"
        "host: app.local\n"
        "content-type: application/x-www-form-urlencoded\n\n"
        "token=abc123XYZ789&password=Secret123"
    )
    req = parse_http_request(raw)
    assert req.parameters.get("token") == "abc123XYZ789"
    assert req.parameters.get("password") == "Secret123"

def test_parse_http_response_extracts_status_and_body():
    raw = "HTTP/1.1 401 Unauthorized\r\nContent-Type: text/plain\r\n\r\nnot allowed"
    resp = parse_http_response(raw)
    assert resp.status_code == 401
    assert resp.reason == "Unauthorized"
    assert resp.body == "not allowed"


def test_parse_http_file_handles_single_request():
    raw = "GET /health HTTP/1.1\nHost: api.local\n\n"
    exchanges = parse_http_file(raw, source="x")
    assert len(exchanges) == 1
    assert exchanges[0].request.method == "GET"


def test_parse_burp_xml_base64_request_response():
    exchanges = parse_burp_xml(str(ROOT / "sample_burp.xml"))
    assert len(exchanges) >= 1
    ex = exchanges[0]
    assert ex.request.method == "POST"
    assert ex.request.path.startswith("/login")
    assert ex.response is not None
    assert ex.response.status_code == 200


def test_parse_burp_binary_fallback_extracts_http(tmp_path):
    burp_blob = tmp_path / "sample.burp"
    payload = (
        b"SQLite format 3\x00\x01\x02"
        b"GET /admin HTTP/1.1\r\nHost: target.local\r\nCookie: sessionid=abc123DEF456\r\n\r\n"
        b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nhello"
    )
    burp_blob.write_bytes(payload)

    exchanges = parse_burp_input(str(burp_blob))
    assert len(exchanges) >= 1
    assert any(ex.request.method == "GET" for ex in exchanges)


def test_parse_network_log_key_values():
    text = "2026-03-10 user=alice@example.com action=login password=abc123"
    entries = parse_network_log(text)
    assert len(entries) == 1
    assert entries[0]["user"] == "alice@example.com"
    assert entries[0]["password"] == "abc123"


def test_parse_pcap_basic_finds_http_from_bytes(tmp_path):
    pcap = tmp_path / "sample.pcap"
    payload = b"\x00\x01GET /api HTTP/1.1\r\nHost: x.local\r\n\r\n\x00"
    pcap.write_bytes(payload)

    exchanges = parse_pcap_basic(str(pcap))
    assert len(exchanges) >= 1
    assert exchanges[0].request.method == "GET"
