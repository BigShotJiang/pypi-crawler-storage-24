from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, Iterable, List, Tuple
from urllib.parse import parse_qsl

from core.data_models import Detection, HTTPExchange, HTTPMessage, HTTPResponse, PipelineResult, RedactionSummary
from detection.context_detection import ContextDetector
from detection.entity_detection import EntityDetector
from detection.secret_detection import SecretDetector
from parsers.burp_xml_parser import parse_burp_input
from parsers.http_parser import parse_http_file
from parsers.image_parser import extract_ocr_tokens
from parsers.log_parser import parse_network_log
from parsers.pcap_parser import parse_pcap_basic
from redaction.placeholder_mapper import PlaceholderMapper
from redaction.redact_image import redact_image_tokens
from redaction.redact_text import redact_text_content
from utils.file_utils import ensure_dir, read_text, write_text


AUTH_BEARER_RE = re.compile(r"\bBearer\s+([^\s,;]+)", re.IGNORECASE)
AUTH_BASIC_RE = re.compile(r"\bBasic\s+([A-Za-z0-9+/=]{8,})", re.IGNORECASE)
COOKIE_PAIR_RE = re.compile(r"([A-Za-z0-9_\-.]+)=([^;\s,]+)")
FORM_KV_RE = re.compile(r"([A-Za-z0-9_\-.]{2,64})=([^&\s]{1,4096})")


class RedactionPipeline:
    def __init__(self) -> None:
        self.entity_detector = EntityDetector()
        self.secret_detector = SecretDetector()
        self.context_detector = ContextDetector()
        self.mapper = PlaceholderMapper()

    def _serialize_request(self, req: HTTPMessage) -> str:
        start = f"{req.method} {req.path} {req.version}".strip()
        lines = [start] if start else []
        lines.extend([f"{k}: {v}" for k, v in req.headers.items()])
        if req.body:
            lines.append("")
            lines.append(req.body)
        return "\n".join(lines).strip()

    def _serialize_response(self, resp: HTTPResponse) -> str:
        start = f"{resp.version} {resp.status_code} {resp.reason}".strip()
        lines = [start] if start else []
        lines.extend([f"{k}: {v}" for k, v in resp.headers.items()])
        if resp.body:
            lines.append("")
            lines.append(resp.body)
        return "\n".join(lines).strip()

    def _serialize_exchanges(self, exchanges: Iterable[HTTPExchange]) -> str:
        blocks: List[str] = []
        for ex in exchanges:
            parts = []
            if ex.request:
                req_txt = self._serialize_request(ex.request)
                if req_txt:
                    parts.append(req_txt)
            if ex.response:
                resp_txt = self._serialize_response(ex.response)
                if resp_txt:
                    parts.append(resp_txt)
            if parts:
                blocks.append("\n\n".join(parts))
        return "\n\n###\n\n".join(blocks)

    def _collect_detections_from_text(self, text: str) -> List[Detection]:
        detections = []
        detections.extend(self.entity_detector.detect(text))
        detections.extend(self.secret_detector.detect(text))
        return detections

    def _header_value_case_insensitive(self, headers: Dict[str, str], name: str) -> str:
        target = name.lower()
        for k, v in headers.items():
            if k.lower() == target:
                return v
        return ""

    def _flatten_json_pairs(self, obj: object, prefix: str = "") -> List[Tuple[str, str]]:
        pairs: List[Tuple[str, str]] = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                key = f"{prefix}.{k}" if prefix else str(k)
                pairs.extend(self._flatten_json_pairs(v, key))
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                key = f"{prefix}[{i}]"
                pairs.extend(self._flatten_json_pairs(v, key))
        else:
            if prefix and obj is not None:
                pairs.append((prefix, str(obj)))
        return pairs

    def _looks_like_json(self, body: str) -> bool:
        b = body.strip()
        return (b.startswith("{") and b.endswith("}")) or (b.startswith("[") and b.endswith("]"))

    def _looks_like_form_body(self, body: str) -> bool:
        return "=" in body and ("&" in body or len(FORM_KV_RE.findall(body)) >= 1)

    def _extract_body_pairs(self, body: str, content_type: str) -> Dict[str, str]:
        if not body:
            return {}

        ct = (content_type or "").lower()

        try_json = "application/json" in ct or self._looks_like_json(body)
        if try_json:
            try:
                parsed = json.loads(body)
                return {k: v for k, v in self._flatten_json_pairs(parsed) if v}
            except Exception:
                pass

        try_form = "application/x-www-form-urlencoded" in ct or self._looks_like_form_body(body)
        if try_form:
            try:
                pairs = parse_qsl(body, keep_blank_values=True)
                if pairs:
                    return {k: v for k, v in pairs}
            except Exception:
                pass

            # fallback for malformed but still key=value-like payloads
            return {k: v for k, v in FORM_KV_RE.findall(body)}

        return {}

    def _collect_protocol_detections(self, headers: Dict[str, str], body: str = "") -> List[Detection]:
        detections: List[Detection] = []

        for key, value in headers.items():
            key_l = key.lower()
            if not value:
                continue

            if key_l == "authorization":
                for m in AUTH_BEARER_RE.finditer(value):
                    detections.append(Detection(kind="AUTH_BEARER_TOKEN", value=m.group(1), source="protocol"))
                for m in AUTH_BASIC_RE.finditer(value):
                    detections.append(Detection(kind="AUTH_BASIC_TOKEN", value=m.group(1), source="protocol"))

            if key_l in {"cookie", "set-cookie"}:
                for m in COOKIE_PAIR_RE.finditer(value):
                    ckey = m.group(1)
                    cval = m.group(2)
                    cookie_ctx = self.context_detector.detect_pairs({ckey: cval}, source="cookie_context")
                    if cookie_ctx:
                        detections.extend(cookie_ctx)
                    elif len(cval) >= 8:
                        detections.append(Detection(kind="COOKIE_VALUE", value=cval, source="protocol"))

        content_type = self._header_value_case_insensitive(headers, "Content-Type")
        body_pairs = self._extract_body_pairs(body, content_type)
        if body_pairs:
            detections.extend(self.context_detector.detect_pairs(body_pairs, source="body_context"))

        return detections

    def _collect_context_from_exchanges(self, exchanges: Iterable[HTTPExchange]) -> List[Detection]:
        detections: List[Detection] = []
        protocol_headers = {"authorization", "cookie", "set-cookie"}

        for ex in exchanges:
            request_headers_for_context = {k: v for k, v in ex.request.headers.items() if k.lower() not in protocol_headers}
            detections.extend(self.context_detector.detect_pairs(request_headers_for_context, source="request_headers"))
            detections.extend(self.context_detector.detect_pairs(ex.request.parameters, source="request_params"))
            detections.extend(self._collect_protocol_detections(ex.request.headers, ex.request.body))

            if ex.response:
                response_headers_for_context = {k: v for k, v in ex.response.headers.items() if k.lower() not in protocol_headers}
                detections.extend(self.context_detector.detect_pairs(response_headers_for_context, source="response_headers"))
                detections.extend(self._collect_protocol_detections(ex.response.headers, ex.response.body))
        return detections

    def _collect_context_from_logs(self, entries: Iterable[Dict[str, str]]) -> List[Detection]:
        detections: List[Detection] = []
        for entry in entries:
            pairs = {k: v for k, v in entry.items() if k != "raw"}
            detections.extend(self.context_detector.detect_pairs(pairs, source="log_fields"))
        return detections

    def _dedupe(self, detections: Iterable[Detection]) -> List[Detection]:
        unique = {}
        for d in detections:
            key = (d.kind, d.value)
            if d.value and key not in unique:
                unique[key] = d
        return list(unique.values())

    def _build_summary(self, detections: List[Detection]) -> RedactionSummary:
        return RedactionSummary(
            detected_count=len(detections),
            redacted_count=len(self.mapper.mapping()),
            mappings=self.mapper.mapping(),
        )

    def process_burp(self, input_path: str, output_dir: str) -> PipelineResult:
        exchanges = parse_burp_input(input_path)
        original_text = self._serialize_exchanges(exchanges)
        detections = self._collect_detections_from_text(original_text)
        detections.extend(self._collect_context_from_exchanges(exchanges))
        detections = self._dedupe(detections)

        redacted = redact_text_content(original_text, detections, self.mapper)
        out = ensure_dir(output_dir) / (Path(input_path).stem + ".sanitized.txt")
        write_text(out, redacted)

        return PipelineResult(sanitized_text=redacted, detections=detections, summary=self._build_summary(detections))

    def process_http(self, input_path: str, output_dir: str) -> PipelineResult:
        raw = read_text(input_path)
        exchanges = parse_http_file(raw, source=input_path)
        original_text = self._serialize_exchanges(exchanges) if exchanges else raw

        detections = self._collect_detections_from_text(original_text)
        detections.extend(self._collect_context_from_exchanges(exchanges))
        detections = self._dedupe(detections)

        redacted = redact_text_content(original_text, detections, self.mapper)
        out = ensure_dir(output_dir) / (Path(input_path).stem + ".sanitized.txt")
        write_text(out, redacted)

        return PipelineResult(sanitized_text=redacted, detections=detections, summary=self._build_summary(detections))

    def process_log(self, input_path: str, output_dir: str) -> PipelineResult:
        raw = read_text(input_path)
        entries = parse_network_log(raw)

        detections = self._collect_detections_from_text(raw)
        detections.extend(self._collect_context_from_logs(entries))
        detections = self._dedupe(detections)

        redacted = redact_text_content(raw, detections, self.mapper)
        out = ensure_dir(output_dir) / (Path(input_path).stem + ".sanitized.txt")
        write_text(out, redacted)

        return PipelineResult(sanitized_text=redacted, detections=detections, summary=self._build_summary(detections))

    def process_pcap(self, input_path: str, output_dir: str) -> PipelineResult:
        exchanges = parse_pcap_basic(input_path)
        original_text = self._serialize_exchanges(exchanges)

        detections = self._collect_detections_from_text(original_text)
        detections.extend(self._collect_context_from_exchanges(exchanges))
        detections = self._dedupe(detections)

        redacted = redact_text_content(original_text, detections, self.mapper)
        out = ensure_dir(output_dir) / (Path(input_path).stem + ".sanitized.txt")
        write_text(out, redacted)

        return PipelineResult(sanitized_text=redacted, detections=detections, summary=self._build_summary(detections))

    def process_image(self, input_path: str, output_dir: str) -> PipelineResult:
        tokens = extract_ocr_tokens(input_path)
        full_text = "\n".join(t.text for t in tokens)

        detections = self._collect_detections_from_text(full_text)
        detections = self._dedupe(detections)

        out = ensure_dir(output_dir) / (Path(input_path).stem + ".sanitized.png")
        redact_image_tokens(input_path, str(out), tokens, detections, self.mapper)

        return PipelineResult(
            sanitized_image_path=str(out),
            detections=detections,
            summary=self._build_summary(detections),
        )
