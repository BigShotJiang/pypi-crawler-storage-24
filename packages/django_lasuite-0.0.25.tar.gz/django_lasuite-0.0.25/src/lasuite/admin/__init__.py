"""LaSuite custom admin site."""
