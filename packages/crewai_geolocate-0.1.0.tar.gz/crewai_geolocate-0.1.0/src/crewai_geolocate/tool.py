from crewai.tools import BaseTool
from pydantic import BaseModel, Field

class GeolocateInput(BaseModel):
    """Input schema for GeolocateTool."""
    address: str = Field(..., description="The street address to geolocate.")

class CrewaiGeolocate(BaseTool):
    name: str = "Geolocate"
    description: str = "Converts a street address into latitude/longitude coordinates."
    args_schema: type[BaseModel] = GeolocateInput

    def _run(self, argument: str) -> str:
        # Your tool's logic here
        return f"40.7128, -74.0060"
