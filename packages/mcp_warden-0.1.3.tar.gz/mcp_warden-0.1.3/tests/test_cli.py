"""Tests for the CLI argument parser and log command."""

from __future__ import annotations

import json

import pytest

from mcp_warden.cli import _build_guard_config, _parse_upstream, build_parser

# ── Parser smoke tests ────────────────────────────────────────────────────────

def test_parser_audit_subcommand():
    parser = build_parser()
    args = parser.parse_args(["audit", "--", "my-mcp-server"])
    assert args.command == "audit"
    assert args.upstream == ["--", "my-mcp-server"]


def test_parser_guard_subcommand():
    parser = build_parser()
    args = parser.parse_args([
        "guard",
        "--max-calls-per-minute", "30",
        "--block-tool", "write_query",
        "--max-response-kb", "512",
        "--",
        "some-mcp-server",
    ])
    assert args.command == "guard"
    assert args.max_calls_per_minute == 30
    assert args.blocked_tools == ["write_query"]
    assert args.max_response_kb == 512


def test_parser_both_subcommand():
    parser = build_parser()
    args = parser.parse_args([
        "both",
        "--max-calls-per-minute", "60",
        "--per-tool-limit", "sql_query:20",
        "--max-errors", "5",
        "--circuit-cooldown", "120",
        "--",
        "some-server",
    ])
    assert args.command == "both"
    assert args.max_calls_per_minute == 60
    assert args.per_tool_limits == ["sql_query:20"]
    assert args.max_errors == 5
    assert args.circuit_cooldown == 120


def test_parser_log_subcommand():
    parser = build_parser()
    args = parser.parse_args(["log", "--tail", "50", "--json"])
    assert args.command == "log"
    assert args.tail == 50
    assert args.as_json is True


def test_parser_version(capsys):
    parser = build_parser()
    with pytest.raises(SystemExit):
        parser.parse_args(["--version"])
    captured = capsys.readouterr()
    assert "mcp-warden" in captured.out


def test_parser_no_command_exits(capsys):
    parser = build_parser()
    args = parser.parse_args([])
    assert args.command is None


# ── _parse_upstream ───────────────────────────────────────────────────────────

def test_parse_upstream_strips_double_dash():
    cmd = _parse_upstream(["--", "my-mcp-server", "--flag", "value"])
    assert cmd == ["my-mcp-server", "--flag", "value"]


def test_parse_upstream_no_double_dash():
    cmd = _parse_upstream(["my-mcp-server", "start"])
    assert cmd == ["my-mcp-server", "start"]


def test_parse_upstream_empty_exits():
    with pytest.raises(SystemExit):
        _parse_upstream([])


def test_parse_upstream_only_double_dash_exits():
    with pytest.raises(SystemExit):
        _parse_upstream(["--"])


# ── _build_guard_config ───────────────────────────────────────────────────────

def _make_guard_args(**kwargs):
    from argparse import Namespace
    defaults = {
        "max_calls_per_minute": 0,
        "per_tool_limits": None,
        "blocked_tools": None,
        "max_response_kb": 0,
        "max_errors": 0,
        "circuit_cooldown": 60,
    }
    defaults.update(kwargs)
    return Namespace(**defaults)


def test_build_guard_config_defaults():
    args = _make_guard_args()
    config = _build_guard_config(args)
    assert config.max_calls_per_minute == 0
    assert config.blocked_tools == []
    assert config.per_tool_limits == {}


def test_build_guard_config_per_tool_parsing():
    args = _make_guard_args(per_tool_limits=["sql_query:20", "write_query:5"])
    config = _build_guard_config(args)
    assert config.per_tool_limits == {"sql_query": 20, "write_query": 5}


def test_build_guard_config_bad_per_tool_warns(capsys):
    args = _make_guard_args(per_tool_limits=["badformat"])
    config = _build_guard_config(args)
    captured = capsys.readouterr()
    assert "Warning" in captured.err
    assert config.per_tool_limits == {}


def test_build_guard_config_blocked_tools():
    args = _make_guard_args(blocked_tools=["write_query", "drop_table"])
    config = _build_guard_config(args)
    assert "write_query" in config.blocked_tools
    assert "drop_table" in config.blocked_tools


# ── cmd_log output ────────────────────────────────────────────────────────────

def test_cmd_log_pretty_output(tmp_path, capsys):
    from argparse import Namespace

    from mcp_warden.cli import cmd_log

    log = tmp_path / "audit.jsonl"
    entries = [
        {"ts": "2025-03-04T10:00:00.000Z", "session_id": "test",
         "direction": "request", "msg_id": "1", "method": "tools/call",
         "tool": "sql_query", "args": {"sql": "SELECT 1"}},
        {"ts": "2025-03-04T10:00:00.100Z", "session_id": "test",
         "direction": "response", "msg_id": "1", "method": "tools/call",
         "tool": "sql_query", "duration_ms": 100.0, "content_len": 42,
         "is_error": False, "error_msg": None},
    ]
    log.write_text("\n".join(json.dumps(e) for e in entries) + "\n")

    args = Namespace(
        tail=20, as_json=False,
        audit_log=str(log),
        filter_tool=None,
        errors_only=False,
    )
    cmd_log(args)
    captured = capsys.readouterr()
    assert "sql_query" in captured.out
    assert "100.0" in captured.out


def test_cmd_log_json_output(tmp_path, capsys):
    from argparse import Namespace

    from mcp_warden.cli import cmd_log

    log = tmp_path / "audit.jsonl"
    entry = {"ts": "2025-03-04T10:00:00.000Z", "direction": "request",
              "method": "tools/call", "tool": "echo"}
    log.write_text(json.dumps(entry) + "\n")

    args = Namespace(
        tail=20, as_json=True,
        audit_log=str(log),
        filter_tool=None,
        errors_only=False,
    )
    cmd_log(args)
    captured = capsys.readouterr()
    parsed = json.loads(captured.out.strip())
    assert parsed["tool"] == "echo"


def test_cmd_log_missing_file_exits(tmp_path, capsys):
    from argparse import Namespace

    from mcp_warden.cli import cmd_log

    args = Namespace(
        tail=20, as_json=False,
        audit_log=str(tmp_path / "nonexistent.jsonl"),
        filter_tool=None,
        errors_only=False,
    )
    with pytest.raises(SystemExit):
        cmd_log(args)


def test_cmd_log_filter_tool(tmp_path, capsys):
    from argparse import Namespace

    from mcp_warden.cli import cmd_log

    log = tmp_path / "audit.jsonl"
    entries = [
        {"ts": "2025-03-04T10:00:00.000Z", "direction": "request",
         "method": "tools/call", "tool": "sql_query"},
        {"ts": "2025-03-04T10:00:01.000Z", "direction": "request",
         "method": "tools/call", "tool": "get_schema"},
    ]
    log.write_text("\n".join(json.dumps(e) for e in entries) + "\n")

    args = Namespace(
        tail=20, as_json=True,
        audit_log=str(log),
        filter_tool="sql_query",
        errors_only=False,
    )
    cmd_log(args)
    captured = capsys.readouterr()
    lines = [ln for ln in captured.out.strip().splitlines() if ln]
    assert len(lines) == 1
    assert json.loads(lines[0])["tool"] == "sql_query"


def test_cmd_log_errors_only(tmp_path, capsys):
    from argparse import Namespace

    from mcp_warden.cli import cmd_log

    log = tmp_path / "audit.jsonl"
    entries = [
        {"ts": "2025-03-04T10:00:00.000Z", "direction": "response",
         "method": "tools/call", "tool": "sql_query",
         "is_error": False, "duration_ms": 10.0, "content_len": 100},
        {"ts": "2025-03-04T10:00:01.000Z", "direction": "blocked",
         "method": "tools/call", "tool": "write_query",
         "reason": "blocked list"},
    ]
    log.write_text("\n".join(json.dumps(e) for e in entries) + "\n")

    args = Namespace(
        tail=20, as_json=True,
        audit_log=str(log),
        filter_tool=None,
        errors_only=True,
    )
    cmd_log(args)
    captured = capsys.readouterr()
    lines = [ln for ln in captured.out.strip().splitlines() if ln]
    assert len(lines) == 1
    assert json.loads(lines[0])["tool"] == "write_query"
