"""Tests for AuditLogger."""

from __future__ import annotations

import json

from mcp_warden.audit import AuditLogger, _now

# ── _now helper ───────────────────────────────────────────────────────────────

def test_now_format():
    ts = _now()
    assert ts.endswith("Z")
    assert "T" in ts
    assert len(ts) == 24  # 2025-03-04T10:22:01.234Z


# ── Basic write / read ────────────────────────────────────────────────────────

def test_log_request_writes_jsonl(tmp_path):
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    msg = {"jsonrpc": "2.0", "id": "1", "method": "tools/call",
           "params": {"name": "sql_query", "arguments": {"sql": "SELECT 1"}}}
    logger.log_request(msg)
    logger.close()

    lines = log.read_text().splitlines()
    assert len(lines) == 1
    entry = json.loads(lines[0])
    assert entry["direction"] == "request"
    assert entry["method"] == "tools/call"
    assert entry["tool"] == "sql_query"
    assert entry["args"] == {"sql": "SELECT 1"}
    assert entry["msg_id"] == "1"


def test_log_response_writes_jsonl(tmp_path):
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    response = {
        "jsonrpc": "2.0", "id": "1",
        "result": {"content": [{"type": "text", "text": "hello world"}]}
    }
    logger.log_response("1", "tools/call", "sql_query", response, duration_ms=42.5)
    logger.close()

    lines = log.read_text().splitlines()
    entry = json.loads(lines[0])
    assert entry["direction"] == "response"
    assert entry["duration_ms"] == 42.5
    assert entry["content_len"] == len("hello world")
    assert entry["is_error"] is False
    assert entry["error_msg"] is None


def test_log_response_error(tmp_path):
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    response = {
        "jsonrpc": "2.0", "id": "1",
        "error": {"code": -32000, "message": "Rate limit exceeded"}
    }
    logger.log_response("1", "tools/call", "sql_query", response, duration_ms=1.0)
    logger.close()

    entry = json.loads(log.read_text().splitlines()[0])
    assert entry["is_error"] is True
    assert entry["error_msg"] == "Rate limit exceeded"


def test_log_blocked(tmp_path):
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    logger.log_blocked("2", "tools/call", "write_query", "Tool is in blocked list")
    logger.close()

    entry = json.loads(log.read_text().splitlines()[0])
    assert entry["direction"] == "blocked"
    assert entry["tool"] == "write_query"
    assert "blocked list" in entry["reason"]


# ── Notifications (no id) ─────────────────────────────────────────────────────

def test_log_notification_request(tmp_path):
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    msg = {"jsonrpc": "2.0", "method": "notifications/initialized"}
    logger.log_request(msg)
    logger.close()

    entry = json.loads(log.read_text().splitlines()[0])
    assert entry["msg_id"] == ""
    assert entry["tool"] is None


# ── Tail ──────────────────────────────────────────────────────────────────────

def test_tail_returns_last_n(tmp_path):
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    for i in range(10):
        msg = {"jsonrpc": "2.0", "id": str(i), "method": "tools/call",
               "params": {"name": "sql_query", "arguments": {}}}
        logger.log_request(msg)
    logger.close()

    entries = AuditLogger(path=str(log)).tail(3)
    assert len(entries) == 3
    assert entries[-1]["msg_id"] == "9"


def test_tail_nonexistent_file(tmp_path):
    logger = AuditLogger(path=str(tmp_path / "nonexistent.jsonl"))
    assert logger.tail(10) == []


def test_tail_stderr_returns_empty():
    logger = AuditLogger(path="-")
    assert logger.tail(10) == []


# ── Argument truncation ───────────────────────────────────────────────────────

def test_arg_truncation(tmp_path):
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log), max_arg_bytes=10)

    big_args = {"sql": "SELECT " + "x" * 1000}
    msg = {"jsonrpc": "2.0", "id": "1", "method": "tools/call",
           "params": {"name": "sql_query", "arguments": big_args}}
    logger.log_request(msg)
    logger.close()

    entry = json.loads(log.read_text().splitlines()[0])
    assert entry["args"].get("_truncated") is True


def test_no_truncation_when_zero(tmp_path):
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log), max_arg_bytes=0)

    big_args = {"sql": "x" * 10000}
    msg = {"jsonrpc": "2.0", "id": "1", "method": "tools/call",
           "params": {"name": "sql_query", "arguments": big_args}}
    logger.log_request(msg)
    logger.close()

    entry = json.loads(log.read_text().splitlines()[0])
    assert entry["args"] == big_args


# ── Thread safety ─────────────────────────────────────────────────────────────

def test_concurrent_writes(tmp_path):
    import threading
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    def write_entries(n):
        for i in range(n):
            msg = {"jsonrpc": "2.0", "id": str(i), "method": "tools/call",
                   "params": {"name": "sql_query", "arguments": {}}}
            logger.log_request(msg)

    threads = [threading.Thread(target=write_entries, args=(20,)) for _ in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    logger.close()

    lines = log.read_text().splitlines()
    assert len(lines) == 100
    for line in lines:
        json.loads(line)  # each line must be valid JSON


# ── Directory auto-creation ───────────────────────────────────────────────────

def test_creates_parent_dirs(tmp_path):
    log = tmp_path / "deep" / "nested" / "audit.jsonl"
    logger = AuditLogger(path=str(log))
    msg = {"jsonrpc": "2.0", "id": "1", "method": "ping", "params": {}}
    logger.log_request(msg)
    logger.close()
    assert log.exists()
