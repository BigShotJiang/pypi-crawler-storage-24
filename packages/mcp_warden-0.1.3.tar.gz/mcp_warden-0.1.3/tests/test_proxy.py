"""
Integration tests for MCPWarden.

Uses a fake upstream MCP server (a small Python subprocess) to test
the full request → proxy → upstream → proxy → client pipeline.
"""

from __future__ import annotations

import contextlib
import json
import sys
import textwrap
import threading
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from mcp_warden.audit import AuditLogger
from mcp_warden.guard import GuardConfig
from mcp_warden.proxy import MCPWarden, _error_response

# ── Unit: helpers ─────────────────────────────────────────────────────────────

def test_error_response_structure():
    resp = _error_response("42", -32000, "Rate limit exceeded")
    assert resp["jsonrpc"] == "2.0"
    assert resp["id"] == "42"
    assert resp["error"]["code"] == -32000
    assert resp["error"]["message"] == "Rate limit exceeded"


def test_error_response_none_id():
    resp = _error_response(None, -32601, "Method not found")
    assert resp["id"] is None


# ── Fake upstream server fixture ──────────────────────────────────────────────

FAKE_SERVER_SCRIPT = textwrap.dedent("""
    import sys, json

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except Exception:
            continue

        req_id = msg.get("id")
        method = msg.get("method", "")

        # Notifications have no id, skip
        if "id" not in msg:
            continue

        if method == "initialize":
            result = {"protocolVersion": "2024-11-05",
                      "serverInfo": {"name": "fake", "version": "0.0.1"},
                      "capabilities": {"tools": {}}}
        elif method == "tools/list":
            result = {"tools": [
                {"name": "echo", "description": "echoes input",
                 "inputSchema": {"type": "object", "properties": {"text": {"type": "string"}}}}
            ]}
        elif method == "tools/call":
            text = (msg.get("params") or {}).get("arguments", {}).get("text", "")
            result = {"content": [{"type": "text", "text": f"ECHO: {text}"}]}
        else:
            result = {}

        resp = {"jsonrpc": "2.0", "id": req_id, "result": result}
        sys.stdout.write(json.dumps(resp) + "\\n")
        sys.stdout.flush()
""")


def make_fake_server(tmp_path: Path) -> Path:
    script = tmp_path / "fake_server.py"
    script.write_text(FAKE_SERVER_SCRIPT, encoding="utf-8")
    return script


# ── Proxy integration: audit ──────────────────────────────────────────────────

def test_proxy_logs_request_and_response(tmp_path):
    script = make_fake_server(tmp_path)
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    proxy = MCPWarden(
        cmd=[sys.executable, str(script)],
        audit_logger=logger,
    )

    # Simulate: send one tools/call, then EOF
    request = json.dumps({
        "jsonrpc": "2.0", "id": "1", "method": "tools/call",
        "params": {"name": "echo", "arguments": {"text": "hello"}}
    }) + "\n"

    output_lines = []

    def run_proxy():
        with patch("sys.stdin", StringIO(request)), \
             patch("sys.stdout") as mock_stdout:
            mock_stdout.write = lambda s: output_lines.append(s)
            with contextlib.suppress(SystemExit):
                proxy.run()

    t = threading.Thread(target=run_proxy)
    t.start()
    t.join(timeout=5)

    logger.close()

    entries = AuditLogger(path=str(log)).tail(10)
    directions = [e["direction"] for e in entries]
    assert "request" in directions
    assert "response" in directions

    req_entry = next(e for e in entries if e["direction"] == "request")
    assert req_entry["tool"] == "echo"
    assert req_entry["method"] == "tools/call"


def test_proxy_logs_blocked_call(tmp_path):
    script = make_fake_server(tmp_path)
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))
    config = GuardConfig(blocked_tools=["echo"])

    proxy = MCPWarden(
        cmd=[sys.executable, str(script)],
        audit_logger=logger,
        guard_config=config,
    )

    request = json.dumps({
        "jsonrpc": "2.0", "id": "1", "method": "tools/call",
        "params": {"name": "echo", "arguments": {"text": "hello"}}
    }) + "\n"

    output_lines = []

    def run_proxy():
        with patch("sys.stdin", StringIO(request)), \
             patch("sys.stdout") as mock_stdout:
            mock_stdout.write = lambda s: output_lines.append(s)
            with contextlib.suppress(SystemExit):
                proxy.run()

    t = threading.Thread(target=run_proxy)
    t.start()
    t.join(timeout=5)

    logger.close()
    entries = AuditLogger(path=str(log)).tail(10)
    blocked = [e for e in entries if e["direction"] == "blocked"]
    assert len(blocked) == 1
    assert blocked[0]["tool"] == "echo"


# ── Proxy passes non-tools/call through untouched ────────────────────────────

def test_proxy_passes_initialize_through(tmp_path):
    script = make_fake_server(tmp_path)
    proxy = MCPWarden(cmd=[sys.executable, str(script)])

    request = json.dumps({
        "jsonrpc": "2.0", "id": "1", "method": "initialize",
        "params": {"protocolVersion": "2024-11-05", "capabilities": {}}
    }) + "\n"

    responses = []

    def run_proxy():
        def capture(s):
            s = s.strip()
            if s:
                responses.append(s)

        with patch("sys.stdin", StringIO(request)), \
             patch("sys.stdout") as mock_stdout:
            mock_stdout.write = capture
            with contextlib.suppress(SystemExit):
                proxy.run()

    t = threading.Thread(target=run_proxy)
    t.start()
    t.join(timeout=5)

    assert len(responses) >= 1
    resp = json.loads(responses[0])
    assert "result" in resp
    assert resp["result"]["serverInfo"]["name"] == "fake"


# ── Proxy passes notifications without responding ─────────────────────────────

def test_proxy_forwards_notification_no_response(tmp_path):
    script = make_fake_server(tmp_path)
    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))

    proxy = MCPWarden(
        cmd=[sys.executable, str(script)],
        audit_logger=logger,
    )

    # Notification has no "id"
    notif = json.dumps({
        "jsonrpc": "2.0",
        "method": "notifications/initialized",
        "params": {}
    }) + "\n"

    with patch("sys.stdin", StringIO(notif)), \
         patch("sys.stdout"):
        t = threading.Thread(target=lambda: proxy.run())
        t.start()
        t.join(timeout=3)

    logger.close()
    entries = AuditLogger(path=str(log)).tail(10)
    # Notification should be logged as a request
    assert any(e["method"] == "notifications/initialized" for e in entries)


# ── Proxy teardown ────────────────────────────────────────────────────────────

def test_proxy_teardown_kills_subprocess(tmp_path):
    script = make_fake_server(tmp_path)
    proxy = MCPWarden(cmd=[sys.executable, str(script)])

    with patch("sys.stdin", StringIO("")), patch("sys.stdout"):
        t = threading.Thread(target=lambda: proxy.run())
        t.start()
        t.join(timeout=3)

    if proxy._proc:
        # Process should be terminated
        assert proxy._proc.poll() is not None
