"""
Tests for the mcp_warden package public API and integration smoke tests.
Verifies the top-level imports, version format, and the MCPWarden class wiring.
"""

from __future__ import annotations

import json
import re
import sys
import threading
from io import StringIO
from unittest.mock import patch

import mcp_warden as mcp_warden_pkg
from mcp_warden import AuditLogger, GuardConfig, MCPWarden, RateLimiter
from mcp_warden.proxy import _error_response, _write_line

# ── Package metadata ──────────────────────────────────────────────────────────

def test_version_exists():
    assert hasattr(mcp_warden_pkg, "__version__")
    assert isinstance(mcp_warden_pkg.__version__, str)


def test_version_semver_format():
    """Version must be a valid semver string like 0.1.0 or 1.2.3."""
    assert re.match(r"^\d+\.\d+\.\d+", mcp_warden_pkg.__version__)


def test_public_exports():
    assert MCPWarden is not None
    assert AuditLogger is not None
    assert GuardConfig is not None
    assert RateLimiter is not None


def test_mcpwarden_is_proxy_class():
    from mcp_warden.proxy import MCPWarden as ProxyMCPWarden
    assert MCPWarden is ProxyMCPWarden


# ── MCPWarden class construction ──────────────────────────────────────────────

def test_mcpwarden_requires_cmd():
    """MCPWarden should store cmd and have None proc before run()."""
    proxy = MCPWarden(cmd=["echo", "hello"])
    assert proxy.cmd == ["echo", "hello"]
    assert proxy._proc is None
    assert proxy.audit is None
    assert proxy.limiter is None


def test_mcpwarden_with_audit_and_guard(tmp_path):
    log = tmp_path / "test.jsonl"
    logger = AuditLogger(path=str(log))
    config = GuardConfig(max_calls_per_minute=10, blocked_tools=["dangerous"])

    proxy = MCPWarden(
        cmd=["echo"],
        audit_logger=logger,
        guard_config=config,
        session_id="test-session",
    )
    assert proxy.audit is logger
    assert proxy.limiter is not None
    assert proxy.session_id == "test-session"
    logger.close()


def test_mcpwarden_guard_config_creates_limiter():
    config = GuardConfig(blocked_tools=["x"])
    proxy = MCPWarden(cmd=["echo"], guard_config=config)
    assert proxy.limiter is not None
    assert not proxy.limiter.check_request("x").allowed


def test_mcpwarden_no_guard_no_limiter():
    proxy = MCPWarden(cmd=["echo"])
    assert proxy.limiter is None


# ── _write_line ───────────────────────────────────────────────────────────────

def test_write_line_writes_newline(capsys):
    _write_line('{"test": true}')
    captured = capsys.readouterr()
    assert captured.out == '{"test": true}\n'


def test_write_line_empty_string(capsys):
    _write_line("")
    captured = capsys.readouterr()
    assert captured.out == "\n"


# ── _error_response ───────────────────────────────────────────────────────────

def test_error_response_all_fields():
    resp = _error_response("99", -32000, "blocked")
    assert resp["jsonrpc"] == "2.0"
    assert resp["id"] == "99"
    assert resp["error"]["code"] == -32000
    assert resp["error"]["message"] == "blocked"


def test_error_response_integer_id():
    resp = _error_response(42, -32601, "not found")
    assert resp["id"] == 42


def test_error_response_none_id():
    resp = _error_response(None, -32700, "parse error")
    assert resp["id"] is None


# ── Full pipeline: blocked call never reaches upstream ────────────────────────

def test_blocked_call_returns_error_without_upstream(tmp_path):
    """
    When a tool is blocked, MCPWarden should return an error response directly
    without forwarding to the upstream at all.
    """
    import textwrap

    fake_script = tmp_path / "upstream.py"
    fake_script.write_text(textwrap.dedent("""
        import sys, json
        for line in sys.stdin:
            msg = json.loads(line.strip())
            if "id" not in msg:
                continue
            content = [{"type":"text","text":"SHOULD NOT REACH HERE"}]
            resp = {"jsonrpc":"2.0","id":msg["id"],"result":{"content":content}}
            sys.stdout.write(json.dumps(resp) + "\\n")
            sys.stdout.flush()
    """))

    log = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=str(log))
    config = GuardConfig(blocked_tools=["dangerous_tool"])
    proxy = MCPWarden(
        cmd=[sys.executable, str(fake_script)],
        audit_logger=logger,
        guard_config=config,
    )

    request = json.dumps({
        "jsonrpc": "2.0", "id": "1", "method": "tools/call",
        "params": {"name": "dangerous_tool", "arguments": {}}
    }) + "\n"

    responses = []

    def capture(s):
        s = s.strip()
        if s:
            responses.append(s)

    with patch("sys.stdin", StringIO(request)), \
         patch("sys.stdout") as mock_stdout:
        mock_stdout.write = capture
        t = threading.Thread(target=lambda: proxy.run())
        t.start()
        t.join(timeout=5)

    logger.close()

    # Should have got an error response
    assert len(responses) >= 1
    resp = json.loads(responses[0])
    assert "error" in resp
    assert "blocked" in resp["error"]["message"].lower()

    # Audit log should have a blocked entry
    entries = AuditLogger(path=str(log)).tail(10)
    blocked = [e for e in entries if e["direction"] == "blocked"]
    assert len(blocked) == 1
    assert blocked[0]["tool"] == "dangerous_tool"


# ── Rate limit fires correctly through full proxy ─────────────────────────────

def test_rate_limit_fires_through_proxy(tmp_path):
    """After hitting the rate limit, subsequent calls return error responses."""
    import textwrap

    fake_script = tmp_path / "upstream.py"
    fake_script.write_text(textwrap.dedent("""
        import sys, json
        for line in sys.stdin:
            msg = json.loads(line.strip())
            if "id" not in msg:
                continue
            content = [{"type":"text","text":"ok"}]
            resp = {"jsonrpc":"2.0","id":msg["id"],"result":{"content":content}}
            sys.stdout.write(json.dumps(resp) + "\\n")
            sys.stdout.flush()
    """))

    config = GuardConfig(max_calls_per_minute=2)
    proxy = MCPWarden(cmd=[sys.executable, str(fake_script)], guard_config=config)

    # Send 3 calls — first 2 should succeed, 3rd should be blocked
    calls = [
        json.dumps({"jsonrpc": "2.0", "id": str(i), "method": "tools/call",
                    "params": {"name": "sql_query", "arguments": {}}}) + "\n"
        for i in range(3)
    ]

    responses = []

    def capture(s):
        s = s.strip()
        if s:
            responses.append(s)

    with patch("sys.stdin", StringIO("".join(calls))), \
         patch("sys.stdout") as mock_stdout:
        mock_stdout.write = capture
        t = threading.Thread(target=lambda: proxy.run())
        t.start()
        t.join(timeout=5)

    assert len(responses) == 3
    parsed = [json.loads(r) for r in responses]
    results = [r for r in parsed if "result" in r]
    errors = [r for r in parsed if "error" in r]
    assert len(results) == 2
    assert len(errors) == 1
    assert "rate limit" in errors[0]["error"]["message"].lower()
