"""Tests for RateLimiter and GuardConfig."""

from __future__ import annotations

import threading

from mcp_warden.guard import GuardConfig, RateLimiter

# ── Default config (no limits) ────────────────────────────────────────────────

def test_default_allows_everything():
    limiter = RateLimiter()
    assert limiter.check_request("sql_query").allowed
    assert limiter.check_response(1024 * 1024).allowed


# ── Tool blocklist ────────────────────────────────────────────────────────────

def test_blocked_tool_rejected():
    config = GuardConfig(blocked_tools=["write_query", "drop_table"])
    limiter = RateLimiter(config)

    result = limiter.check_request("write_query")
    assert not result.allowed
    assert "blocked" in result.reason.lower()


def test_non_blocked_tool_allowed():
    config = GuardConfig(blocked_tools=["write_query"])
    limiter = RateLimiter(config)
    assert limiter.check_request("sql_query").allowed


def test_none_tool_not_blocked():
    config = GuardConfig(blocked_tools=["write_query"])
    limiter = RateLimiter(config)
    assert limiter.check_request(None).allowed


# ── Global rate limit ─────────────────────────────────────────────────────────

def test_global_rate_limit_enforced():
    config = GuardConfig(max_calls_per_minute=3)
    limiter = RateLimiter(config)

    assert limiter.check_request("sql_query").allowed
    assert limiter.check_request("sql_query").allowed
    assert limiter.check_request("sql_query").allowed
    result = limiter.check_request("sql_query")
    assert not result.allowed
    assert "rate limit" in result.reason.lower()


def test_global_rate_limit_zero_means_unlimited():
    config = GuardConfig(max_calls_per_minute=0)
    limiter = RateLimiter(config)
    for _ in range(200):
        assert limiter.check_request("sql_query").allowed


def test_global_rate_limit_includes_retry_wait_in_reason():
    config = GuardConfig(max_calls_per_minute=1)
    limiter = RateLimiter(config)
    limiter.check_request("sql_query")
    result = limiter.check_request("sql_query")
    assert "retry in" in result.reason.lower()


# ── Per-tool rate limit ───────────────────────────────────────────────────────

def test_per_tool_rate_limit():
    config = GuardConfig(per_tool_limits={"sql_query": 2})
    limiter = RateLimiter(config)

    assert limiter.check_request("sql_query").allowed
    assert limiter.check_request("sql_query").allowed
    result = limiter.check_request("sql_query")
    assert not result.allowed
    assert "sql_query" in result.reason


def test_per_tool_limit_does_not_affect_other_tools():
    config = GuardConfig(per_tool_limits={"sql_query": 1})
    limiter = RateLimiter(config)

    limiter.check_request("sql_query")
    limiter.check_request("sql_query")  # blocked for sql_query
    # get_schema has no limit — still allowed
    assert limiter.check_request("get_schema").allowed


def test_per_tool_independent_of_global():
    config = GuardConfig(
        max_calls_per_minute=100,
        per_tool_limits={"sql_query": 2},
    )
    limiter = RateLimiter(config)

    limiter.check_request("sql_query")
    limiter.check_request("sql_query")
    result = limiter.check_request("sql_query")
    assert not result.allowed  # per-tool limit hit


# ── Response size cap ─────────────────────────────────────────────────────────

def test_response_size_cap_enforced():
    config = GuardConfig(max_response_kb=10)
    limiter = RateLimiter(config)

    small = limiter.check_response(5 * 1024)
    assert small.allowed

    large = limiter.check_response(11 * 1024)
    assert not large.allowed
    assert "too large" in large.reason.lower()


def test_response_size_zero_means_unlimited():
    config = GuardConfig(max_response_kb=0)
    limiter = RateLimiter(config)
    assert limiter.check_response(100 * 1024 * 1024).allowed


def test_response_size_exactly_at_limit():
    config = GuardConfig(max_response_kb=10)
    limiter = RateLimiter(config)
    # exactly 10KB — allowed
    assert limiter.check_response(10 * 1024).allowed
    # 1 byte over — blocked
    assert not limiter.check_response(10 * 1024 + 1).allowed


# ── Circuit breaker ───────────────────────────────────────────────────────────

def test_circuit_breaker_opens_after_n_errors():
    config = GuardConfig(
        max_errors_before_circuit_break=3,
        circuit_break_cooldown_seconds=60,
    )
    limiter = RateLimiter(config)

    for _ in range(3):
        limiter.record_outcome(is_error=True)

    result = limiter.check_request("sql_query")
    assert not result.allowed
    assert "circuit breaker" in result.reason.lower()


def test_circuit_breaker_stays_closed_on_success():
    config = GuardConfig(max_errors_before_circuit_break=3)
    limiter = RateLimiter(config)

    limiter.record_outcome(is_error=True)
    limiter.record_outcome(is_error=False)  # resets counter
    limiter.record_outcome(is_error=True)
    limiter.record_outcome(is_error=True)   # only 2 consecutive

    assert limiter.check_request("sql_query").allowed


def test_circuit_breaker_resets_manually():
    config = GuardConfig(
        max_errors_before_circuit_break=1,
        circuit_break_cooldown_seconds=999,
    )
    limiter = RateLimiter(config)
    limiter.record_outcome(is_error=True)

    assert not limiter.check_request("sql_query").allowed
    limiter.reset_circuit()
    assert limiter.check_request("sql_query").allowed


def test_circuit_breaker_disabled_when_zero():
    config = GuardConfig(max_errors_before_circuit_break=0)
    limiter = RateLimiter(config)

    for _ in range(100):
        limiter.record_outcome(is_error=True)

    assert limiter.check_request("sql_query").allowed


def test_circuit_breaker_reports_cooldown_remaining():
    config = GuardConfig(
        max_errors_before_circuit_break=1,
        circuit_break_cooldown_seconds=30,
    )
    limiter = RateLimiter(config)
    limiter.record_outcome(is_error=True)

    result = limiter.check_request("sql_query")
    assert not result.allowed
    assert "30" in result.reason or "29" in result.reason  # ±1s


# ── Stats ─────────────────────────────────────────────────────────────────────

def test_stats_global_calls():
    config = GuardConfig(max_calls_per_minute=10)
    limiter = RateLimiter(config)

    for _ in range(3):
        limiter.check_request("sql_query")

    stats = limiter.stats()
    assert stats["global_calls_last_minute"] == 3


def test_stats_per_tool_calls():
    config = GuardConfig(per_tool_limits={"sql_query": 10})
    limiter = RateLimiter(config)

    limiter.check_request("sql_query")
    limiter.check_request("sql_query")

    stats = limiter.stats()
    assert stats["per_tool_calls_last_minute"]["sql_query"] == 2


def test_stats_circuit_open():
    config = GuardConfig(
        max_errors_before_circuit_break=1,
        circuit_break_cooldown_seconds=60,
    )
    limiter = RateLimiter(config)
    limiter.record_outcome(is_error=True)

    stats = limiter.stats()
    assert stats["circuit_open"] is True
    assert stats["circuit_open_until"] > 0


def test_stats_circuit_closed():
    limiter = RateLimiter()
    stats = limiter.stats()
    assert stats["circuit_open"] is False
    assert stats["circuit_open_until"] == 0


# ── Thread safety ─────────────────────────────────────────────────────────────

def test_concurrent_rate_limit_accurate():
    config = GuardConfig(max_calls_per_minute=50)
    limiter = RateLimiter(config)
    allowed_count = [0]
    lock = threading.Lock()

    def attempt_calls():
        for _ in range(20):
            result = limiter.check_request("sql_query")
            if result.allowed:
                with lock:
                    allowed_count[0] += 1

    threads = [threading.Thread(target=attempt_calls) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert allowed_count[0] == 50  # exactly 50 should succeed


# ── GuardConfig defaults ──────────────────────────────────────────────────────

def test_guard_config_defaults():
    config = GuardConfig()
    assert config.max_calls_per_minute == 0
    assert config.per_tool_limits == {}
    assert config.blocked_tools == []
    assert config.max_response_kb == 0
    assert config.max_errors_before_circuit_break == 0
    assert config.circuit_break_cooldown_seconds == 60


# ── Combined guards ───────────────────────────────────────────────────────────

def test_blocked_tool_takes_priority_over_rate_limit():
    """Blocked tool should be rejected even if rate limit not reached."""
    config = GuardConfig(
        max_calls_per_minute=100,
        blocked_tools=["write_query"],
    )
    limiter = RateLimiter(config)
    result = limiter.check_request("write_query")
    assert not result.allowed
    assert "blocked" in result.reason.lower()
