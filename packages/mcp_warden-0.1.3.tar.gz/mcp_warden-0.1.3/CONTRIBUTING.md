# Contributing to mcp-warden

## Development setup

```bash
git clone https://github.com/raj8github/mcp-warden
cd mcp-warden
pip install -e ".[dev]"
```

## Running tests

```bash
pytest tests/ -v                    # all tests
pytest tests/test_guard.py -v       # one file
pytest tests/ -v -k "rate_limit"    # by keyword
```

## Releasing a new version

1. Go to **Actions → Bump Version** in GitHub
2. Choose `patch`, `minor`, or `major`
3. Click **Run workflow**

This will:
- Update `__version__` in `mcp_warden/__init__.py`
- Commit and push the change
- Create a version tag (e.g. `v0.1.1`)
- Trigger the release workflow, which publishes to PyPI as `mcp-warden` automatically

## Package naming

- **PyPI distribution**: `mcp-warden` (`pip install mcp-warden`)
- **Python package / CLI**: `mcp-warden` (`import mcp_warden`, `mcp-warden audit -- ...`)
- **GitHub repo**: `github.com/raj8github/mcp-warden`

## Code style

- `ruff check mcp_warden/` for linting
- `mypy mcp_warden/` for type checking
- No runtime dependencies — stdlib only
