"""
MCPWarden — transparent stdio proxy.

Spawns the upstream MCP server as a subprocess, then relays
JSON-RPC messages between the MCP client (stdin/stdout) and
the upstream server, applying audit logging and guard checks
to every tools/call.

Architecture:

  MCP client (Cline/Claude Desktop)
      │  stdin/stdout
      ▼
  mcp-warden  ◄──── audit + guard
      │  subprocess stdin/stdout
      ▼
  Upstream MCP server (any MCP server)
"""

from __future__ import annotations

import contextlib
import json
import signal
import subprocess
import sys
import threading
import time
from typing import Any

from .audit import AuditLogger
from .guard import GuardConfig, RateLimiter


class MCPWarden:
    """
    Transparent MCP stdio proxy with audit logging and guard enforcement.

    Parameters
    ----------
    cmd:
        The upstream server command as a list, e.g.
        ["your-mcp-server", "--arg", "value"]
    audit_logger:
        AuditLogger instance.  Pass None to disable logging.
    guard_config:
        GuardConfig instance.  Pass None to disable all guards.
    session_id:
        Identifier for this session in the audit log.
    """

    def __init__(
        self,
        cmd: list[str],
        audit_logger: AuditLogger | None = None,
        guard_config: GuardConfig | None = None,
        session_id: str = "mcp_warden",
    ) -> None:
        self.cmd = cmd
        self.audit = audit_logger
        self.limiter = RateLimiter(guard_config) if guard_config else None
        self.session_id = session_id
        self._proc: subprocess.Popen | None = None  # type: ignore[type-arg]

        # Tracks in-flight requests: msg_id → (method, tool_name, start_time)
        self._inflight: dict[str, tuple[str, str | None, float]] = {}
        self._inflight_lock = threading.Lock()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def run(self) -> None:
        """Start the proxy.  Blocks until the upstream server exits."""
        self._proc = subprocess.Popen(
            self.cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=sys.stderr,   # upstream stderr flows directly to our stderr
        )

        def _shutdown(sig: int, frame: Any) -> None:
            self._teardown()
            sys.exit(0)

        with contextlib.suppress(ValueError):
            signal.signal(signal.SIGTERM, _shutdown)

        # Thread: upstream → client
        upstream_thread = threading.Thread(
            target=self._relay_upstream_to_client,
            daemon=True,
            name="upstream-to-client",
        )
        upstream_thread.start()

        # Main thread: client → upstream
        try:
            self._relay_client_to_upstream()
        except (KeyboardInterrupt, EOFError):
            pass
        finally:
            # Close upstream stdin so the upstream process sees EOF and can flush
            if self._proc and self._proc.stdin:
                with contextlib.suppress(Exception):
                    self._proc.stdin.close()
            # Wait for upstream relay thread to drain all remaining responses
            upstream_thread.join(timeout=2)
            self._teardown()

    # ── Client → Upstream relay ───────────────────────────────────────────────

    def _relay_client_to_upstream(self) -> None:
        """Read lines from stdin (MCP client), apply guards, forward upstream."""
        for raw_line in sys.stdin:
            raw_line = raw_line.strip()
            if not raw_line:
                continue

            try:
                msg = json.loads(raw_line)
            except json.JSONDecodeError:
                continue

            method = msg.get("method", "")
            params = msg.get("params") or {}
            msg_id = msg.get("id")
            is_notification = "id" not in msg

            # Log the request
            if self.audit:
                self.audit.log_request(msg)

            # Only apply guard to tools/call
            if method == "tools/call" and not is_notification:
                tool_name = params.get("name")
                guard_result = self.limiter.check_request(tool_name) if self.limiter else None

                if guard_result and not guard_result.allowed:
                    # Log the block and return an error to the client immediately
                    if self.audit:
                        self.audit.log_blocked(msg_id, method, tool_name, guard_result.reason)
                    error_resp = _error_response(msg_id, -32000, guard_result.reason)
                    _write_line(json.dumps(error_resp))
                    continue

                # Track in-flight so the response relay can compute duration
                with self._inflight_lock:
                    self._inflight[str(msg_id)] = (method, tool_name, time.perf_counter())

            # Forward to upstream
            if self._proc and self._proc.stdin:
                try:
                    self._proc.stdin.write((raw_line + "\n").encode())
                    self._proc.stdin.flush()
                except BrokenPipeError:
                    break

    # ── Upstream → Client relay ───────────────────────────────────────────────

    def _relay_upstream_to_client(self) -> None:
        """Read lines from the upstream server, apply response guards, forward to client."""
        if not self._proc or not self._proc.stdout:
            return

        for raw_line in self._proc.stdout:
            raw_line_str = raw_line.decode(errors="replace").strip()
            if not raw_line_str:
                continue

            try:
                msg = json.loads(raw_line_str)
            except json.JSONDecodeError:
                _write_line(raw_line_str)
                continue

            msg_id = str(msg.get("id", ""))
            method = ""
            tool_name: str | None = None
            duration_ms = 0.0

            # Retrieve in-flight metadata
            with self._inflight_lock:
                flight = self._inflight.pop(msg_id, None)
            if flight:
                method, tool_name, start = flight
                duration_ms = (time.perf_counter() - start) * 1000

            # Response size guard
            response_bytes = len(raw_line_str.encode())
            if self.limiter and method == "tools/call":
                size_result = self.limiter.check_response(response_bytes)
                is_error = bool(msg.get("error") or (msg.get("result") or {}).get("isError"))
                self.limiter.record_outcome(is_error=is_error or not size_result.allowed)

                if not size_result.allowed:
                    if self.audit:
                        self.audit.log_blocked(msg_id, method, tool_name, size_result.reason)
                    error_resp = _error_response(msg_id, -32000, size_result.reason)
                    _write_line(json.dumps(error_resp))
                    continue

            # Log the response
            if self.audit and method:
                self.audit.log_response(
                    msg_id=msg_id,
                    method=method,
                    tool_name=tool_name,
                    response=msg,
                    duration_ms=duration_ms,
                )

            _write_line(raw_line_str)

    # ── Teardown ──────────────────────────────────────────────────────────────

    def _teardown(self) -> None:
        if self._proc:
            try:
                self._proc.terminate()
                self._proc.wait(timeout=5)
            except Exception:
                with contextlib.suppress(Exception):
                    self._proc.kill()
        if self.audit:
            self.audit.close()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _write_line(line: str) -> None:
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def _error_response(msg_id: Any, code: int, message: str) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": msg_id,
        "error": {"code": code, "message": message},
    }
