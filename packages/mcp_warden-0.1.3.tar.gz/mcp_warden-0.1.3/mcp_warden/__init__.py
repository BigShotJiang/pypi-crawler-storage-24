"""
mcp-warden — MCP observability and control plane.

Drop it in front of any MCP server to get:
  - Full request/response audit log (JSONL)
  - Per-tool and global rate limiting
  - Response size caps
  - Tool blocklist
  - Circuit breaker on repeated errors
  - Zero runtime dependencies (stdlib only)

Usage:
    mcp-warden audit  -- your-mcp-server [args...]
    mcp-warden guard  -- any-mcp-server
    mcp-warden both   -- any-mcp-server
    mcp-warden log    --tail 20
"""

__version__ = "0.1.3"
__all__ = ["MCPWarden", "AuditLogger", "GuardConfig", "RateLimiter"]

from .audit import AuditLogger
from .guard import GuardConfig, RateLimiter
from .proxy import MCPWarden
