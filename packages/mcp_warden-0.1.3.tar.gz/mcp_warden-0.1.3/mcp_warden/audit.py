"""
AuditLogger — records every MCP request and response to JSONL.

Each line is a self-contained JSON object:
  {
    "ts":           "2025-03-04T10:22:01.234Z",   # ISO-8601 UTC
    "session_id":   "cline-abc123",
    "direction":    "request" | "response",
    "msg_id":       "1",                           # JSON-RPC id
    "method":       "tools/call",
    "tool":         "sql_query",                   # if tools/call
    "args":         {...},                         # sanitised request args
    "duration_ms":  142.3,                         # response only
    "content_len":  4821,                          # response only (bytes)
    "is_error":     false,                         # response only
    "error_msg":    null                           # response only
  }
"""

from __future__ import annotations

import contextlib
import json
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import IO, Any


class AuditLogger:
    """
    Thread-safe JSONL audit logger.

    Parameters
    ----------
    path:
        File path for the JSONL log.  Directories are created automatically.
        Use "-" to write to stderr instead (useful for testing / piping).
    session_id:
        Arbitrary string identifying this proxy session (e.g. "cline", "claude-desktop").
    max_arg_bytes:
        Truncate serialised tool arguments longer than this to prevent huge log lines.
        Default: 4096 bytes.  Set to 0 to disable truncation.
    """

    def __init__(
        self,
        path: str = "./mcp_warden_audit.jsonl",
        session_id: str = "mcp_warden",
        max_arg_bytes: int = 4096,
    ) -> None:
        self.path = path
        self.session_id = session_id
        self.max_arg_bytes = max_arg_bytes
        self._lock = threading.Lock()
        self._file = self._open()

    # ── Public API ────────────────────────────────────────────────────────────

    def log_request(self, msg: dict[str, Any]) -> None:
        """Log an inbound JSON-RPC request from the MCP client."""
        method = msg.get("method", "")
        params = msg.get("params") or {}
        tool_name: str | None = None
        args: Any = None

        if method == "tools/call":
            tool_name = params.get("name")
            raw_args = params.get("arguments") or {}
            args = self._truncate(raw_args)

        entry = {
            "ts": _now(),
            "session_id": self.session_id,
            "direction": "request",
            "msg_id": str(msg.get("id", "")),
            "method": method,
            "tool": tool_name,
            "args": args,
        }
        self._write(entry)

    def log_response(
        self,
        msg_id: Any,
        method: str,
        tool_name: str | None,
        response: dict[str, Any],
        duration_ms: float,
    ) -> None:
        """Log an outbound JSON-RPC response back to the MCP client."""
        error = response.get("error")
        result = response.get("result") or {}
        content = result.get("content") or []
        content_len = sum(len(str(c.get("text", ""))) for c in content) if content else 0

        entry = {
            "ts": _now(),
            "session_id": self.session_id,
            "direction": "response",
            "msg_id": str(msg_id),
            "method": method,
            "tool": tool_name,
            "duration_ms": round(duration_ms, 2),
            "content_len": content_len,
            "is_error": bool(error or result.get("isError")),
            "error_msg": error.get("message") if error else None,
        }
        self._write(entry)

    def log_blocked(
        self,
        msg_id: Any,
        method: str,
        tool_name: str | None,
        reason: str,
    ) -> None:
        """Log a request that was blocked by the guard layer."""
        entry = {
            "ts": _now(),
            "session_id": self.session_id,
            "direction": "blocked",
            "msg_id": str(msg_id),
            "method": method,
            "tool": tool_name,
            "reason": reason,
        }
        self._write(entry)

    def tail(self, n: int = 20) -> list[dict[str, Any]]:
        """Return the last *n* log entries (in-memory re-read, for CLI use)."""
        if self.path == "-":
            return []
        p = Path(self.path)
        if not p.exists():
            return []
        lines = p.read_text(encoding="utf-8").splitlines()
        entries = []
        for line in lines[-n:]:
            line = line.strip()
            if line:
                with contextlib.suppress(json.JSONDecodeError):
                    entries.append(json.loads(line))
        return entries

    def close(self) -> None:
        with self._lock:
            if self._file and self._file is not sys.stderr:
                self._file.close()

    # ── Private ───────────────────────────────────────────────────────────────

    def _open(self) -> IO[str]:
        if self.path == "-":
            return sys.stderr
        p = Path(self.path)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p.open("a", encoding="utf-8", buffering=1)  # line-buffered

    def _write(self, entry: dict[str, Any]) -> None:
        line = json.dumps(entry, default=str, ensure_ascii=False)
        with self._lock:
            self._file.write(line + "\n")
            self._file.flush()

    def _truncate(self, args: Any) -> Any:
        if not self.max_arg_bytes:
            return args
        serialised = json.dumps(args, default=str)
        if len(serialised) <= self.max_arg_bytes:
            return args
        return {"_truncated": True, "preview": serialised[: self.max_arg_bytes] + "…"}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
