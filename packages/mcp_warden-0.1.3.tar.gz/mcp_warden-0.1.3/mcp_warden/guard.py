"""
Guard — rate limiting, tool blocking, response size caps, circuit breaker.

All state is in-process memory.  Designed for single-session use
(one Cline/Claude Desktop session per mcp-warden process).

GuardConfig is the configuration dataclass.
RateLimiter is the stateful engine.
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any

# ─── Configuration ─────────────────────────────────────────────────────────────

@dataclass
class GuardConfig:
    """
    All limits are optional — set only what you need.

    Parameters
    ----------
    max_calls_per_minute:
        Global cap on total tool calls per 60-second rolling window.
    per_tool_limits:
        Per-tool cap, e.g. {"sql_query": 20, "write_query": 5}.
    blocked_tools:
        Tool names that are always blocked (e.g. ["write_query", "delete_rows"]).
    max_response_kb:
        Reject responses larger than this (KB).  0 = unlimited.
    max_errors_before_circuit_break:
        After this many consecutive errors, block all calls until reset.
        0 = disabled.
    circuit_break_cooldown_seconds:
        How long the circuit stays open (broken) before auto-reset.
        Default: 60 seconds.
    """

    max_calls_per_minute: int = 0               # 0 = unlimited
    per_tool_limits: dict[str, int] = field(default_factory=dict)
    blocked_tools: list[str] = field(default_factory=list)
    max_response_kb: int = 0                    # 0 = unlimited
    max_errors_before_circuit_break: int = 0   # 0 = disabled
    circuit_break_cooldown_seconds: int = 60


# ─── Result ─────────────────────────────────────────────────────────────────────

@dataclass
class GuardResult:
    allowed: bool
    reason: str = ""

    @classmethod
    def ok(cls) -> GuardResult:
        return cls(allowed=True)

    @classmethod
    def block(cls, reason: str) -> GuardResult:
        return cls(allowed=False, reason=reason)


# ─── Engine ─────────────────────────────────────────────────────────────────────

class RateLimiter:
    """
    Stateful guard engine.  Thread-safe.  Instantiate once per proxy session.

    Usage
    -----
    limiter = RateLimiter(config)

    # Before forwarding a tool call:
    result = limiter.check_request(tool_name="sql_query")
    if not result.allowed:
        return error_response(result.reason)

    # After receiving a response:
    result = limiter.check_response(response_bytes=4096)
    limiter.record_outcome(is_error=False)
    """

    def __init__(self, config: GuardConfig | None = None) -> None:
        self.config = config or GuardConfig()
        self._lock = threading.Lock()

        # Rolling window of call timestamps (global)
        self._global_window: deque[float] = deque()

        # Rolling window per tool
        self._tool_windows: dict[str, deque[float]] = defaultdict(deque)

        # Circuit breaker state
        self._consecutive_errors: int = 0
        self._circuit_open_until: float = 0.0

    # ── Pre-call check ────────────────────────────────────────────────────────

    def check_request(self, tool_name: str | None = None) -> GuardResult:
        """
        Call before forwarding a tools/call request.
        Returns GuardResult — if not allowed, return an error to the client.
        """
        with self._lock:
            now = time.monotonic()

            # Circuit breaker
            if self.config.max_errors_before_circuit_break > 0:
                if now < self._circuit_open_until:
                    remaining = int(self._circuit_open_until - now)
                    return GuardResult.block(
                        f"Circuit breaker open — too many consecutive errors. "
                        f"Auto-reset in {remaining}s."
                    )
                elif self._circuit_open_until > 0:
                    # Cooldown elapsed — reset
                    self._consecutive_errors = 0
                    self._circuit_open_until = 0.0

            # Tool blocklist
            if tool_name and tool_name in self.config.blocked_tools:
                return GuardResult.block(
                    f"Tool '{tool_name}' is in the blocked list."
                )

            # Global rate limit
            if self.config.max_calls_per_minute > 0:
                self._evict_old(self._global_window, now, 60)
                if len(self._global_window) >= self.config.max_calls_per_minute:
                    oldest = self._global_window[0]
                    wait = int(60 - (now - oldest)) + 1
                    return GuardResult.block(
                        f"Global rate limit reached ({self.config.max_calls_per_minute} "
                        f"calls/min). Retry in ~{wait}s."
                    )
                self._global_window.append(now)

            # Per-tool rate limit
            if tool_name and tool_name in self.config.per_tool_limits:
                limit = self.config.per_tool_limits[tool_name]
                window = self._tool_windows[tool_name]
                self._evict_old(window, now, 60)
                if len(window) >= limit:
                    oldest = window[0]
                    wait = int(60 - (now - oldest)) + 1
                    return GuardResult.block(
                        f"Per-tool rate limit reached for '{tool_name}' "
                        f"({limit} calls/min). Retry in ~{wait}s."
                    )
                window.append(now)

            return GuardResult.ok()

    # ── Post-response check ───────────────────────────────────────────────────

    def check_response(self, response_bytes: int) -> GuardResult:
        """
        Call after receiving a response from the upstream server.
        Checks response size cap.
        """
        if self.config.max_response_kb > 0:
            kb = response_bytes / 1024
            if kb > self.config.max_response_kb:
                return GuardResult.block(
                    f"Response too large ({kb:.1f} KB > {self.config.max_response_kb} KB limit). "
                    f"Consider narrowing your query."
                )
        return GuardResult.ok()

    # ── Outcome recording ─────────────────────────────────────────────────────

    def record_outcome(self, is_error: bool) -> None:
        """
        Call after each tool call completes to update circuit breaker state.
        """
        if self.config.max_errors_before_circuit_break <= 0:
            return
        with self._lock:
            if is_error:
                self._consecutive_errors += 1
                if self._consecutive_errors >= self.config.max_errors_before_circuit_break:
                    self._circuit_open_until = (
                        time.monotonic() + self.config.circuit_break_cooldown_seconds
                    )
            else:
                self._consecutive_errors = 0

    def reset_circuit(self) -> None:
        """Manually reset the circuit breaker."""
        with self._lock:
            self._consecutive_errors = 0
            self._circuit_open_until = 0.0

    # ── Stats ─────────────────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        """Return current rate limit state — useful for diagnostics."""
        now = time.monotonic()
        with self._lock:
            self._evict_old(self._global_window, now, 60)
            per_tool = {}
            for tool, window in self._tool_windows.items():
                self._evict_old(window, now, 60)
                per_tool[tool] = len(window)
            return {
                "global_calls_last_minute": len(self._global_window),
                "per_tool_calls_last_minute": per_tool,
                "consecutive_errors": self._consecutive_errors,
                "circuit_open": now < self._circuit_open_until,
                "circuit_open_until": (
                    int(self._circuit_open_until - now)
                    if self._circuit_open_until > now
                    else 0
                ),
            }

    # ── Private ───────────────────────────────────────────────────────────────

    @staticmethod
    def _evict_old(window: deque[float], now: float, window_seconds: int) -> None:
        cutoff = now - window_seconds
        while window and window[0] < cutoff:
            window.popleft()
