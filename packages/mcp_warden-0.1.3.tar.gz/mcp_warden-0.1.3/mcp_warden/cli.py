"""
mcp-warden CLI

Usage examples:

    # Audit only — log every tool call
    mcp-warden audit -- your-mcp-server [args...]

    # Guard only — rate limits and blocks
    mcp-warden guard --max-calls-per-minute 30 --block-tool write_query -- any-mcp-server

    # Both audit + guard (recommended)
    mcp-warden both --max-calls-per-minute 30 --max-response-kb 512 -- any-mcp-server

    # View recent audit log
    mcp-warden log --tail 20
    mcp-warden log --tail 50 --json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .audit import AuditLogger
from .guard import GuardConfig
from .proxy import MCPWarden


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mcp-warden",
        description=(
            "Transparent audit and rate-limiting proxy for any MCP server.\n"
            "Wraps any MCP server with zero config changes to the upstream server."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  mcp-warden audit -- your-mcp-server [args...]
  mcp-warden guard --max-calls-per-minute 30 -- any-mcp-server
  mcp-warden both  --max-calls-per-minute 60 --max-response-kb 512 -- any-mcp-server
  mcp-warden log   --tail 50
        """,
    )
    parser.add_argument("--version", action="version", version=f"mcp-warden {__version__}")

    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ── Shared options factory ─────────────────────────────────────────────────

    def add_shared(p: argparse.ArgumentParser) -> None:
        p.add_argument(
            "--audit-log",
            default="./mcp_warden_audit.jsonl",
            metavar="PATH",
            help="Path to JSONL audit log file (default: ./mcp_warden_audit.jsonl)",
        )
        p.add_argument(
            "--session-id",
            default="mcp_warden",
            metavar="ID",
            help="Session identifier in audit log entries (default: mcp-warden)",
        )
        p.add_argument(
            "--max-arg-bytes",
            type=int,
            default=4096,
            metavar="N",
            help="Truncate tool args longer than N bytes in the log (default: 4096, 0=off)",
        )

    def add_guard_opts(p: argparse.ArgumentParser) -> None:
        g = p.add_argument_group("guard options")
        g.add_argument(
            "--max-calls-per-minute",
            type=int,
            default=0,
            metavar="N",
            help="Global cap on tool calls per 60s window (default: 0 = unlimited)",
        )
        g.add_argument(
            "--per-tool-limit",
            action="append",
            metavar="TOOL:N",
            dest="per_tool_limits",
            help="Per-tool cap, e.g. --per-tool-limit sql_query:20 (repeatable)",
        )
        g.add_argument(
            "--block-tool",
            action="append",
            metavar="TOOL",
            dest="blocked_tools",
            help="Block a specific tool entirely (repeatable)",
        )
        g.add_argument(
            "--max-response-kb",
            type=int,
            default=0,
            metavar="KB",
            help="Reject responses larger than this in KB (default: 0 = unlimited)",
        )
        g.add_argument(
            "--max-errors",
            type=int,
            default=0,
            metavar="N",
            help="Open circuit breaker after N consecutive errors (default: 0 = disabled)",
        )
        g.add_argument(
            "--circuit-cooldown",
            type=int,
            default=60,
            metavar="SECONDS",
            help="Circuit breaker cooldown in seconds (default: 60)",
        )

    # ── audit subcommand ───────────────────────────────────────────────────────

    audit_cmd = sub.add_parser("audit", help="Audit only — log every tool call")
    add_shared(audit_cmd)
    audit_cmd.add_argument(
        "upstream",
        nargs=argparse.REMAINDER,
        help="Upstream MCP server command (after --)",
    )
    audit_cmd.set_defaults(func=cmd_audit)

    # ── guard subcommand ───────────────────────────────────────────────────────

    guard_cmd = sub.add_parser("guard", help="Guard only — rate limits, blocking, circuit breaker")
    add_shared(guard_cmd)
    add_guard_opts(guard_cmd)
    guard_cmd.add_argument(
        "upstream",
        nargs=argparse.REMAINDER,
        help="Upstream MCP server command (after --)",
    )
    guard_cmd.set_defaults(func=cmd_guard)

    # ── both subcommand ────────────────────────────────────────────────────────

    both_cmd = sub.add_parser("both", help="Audit + guard (recommended)")
    add_shared(both_cmd)
    add_guard_opts(both_cmd)
    both_cmd.add_argument(
        "upstream",
        nargs=argparse.REMAINDER,
        help="Upstream MCP server command (after --)",
    )
    both_cmd.set_defaults(func=cmd_both)

    # ── log subcommand ─────────────────────────────────────────────────────────

    log_cmd = sub.add_parser("log", help="View recent audit log entries")
    log_cmd.add_argument(
        "--tail",
        type=int,
        default=20,
        metavar="N",
        help="Number of recent entries to show (default: 20)",
    )
    log_cmd.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="Output raw JSON lines",
    )
    log_cmd.add_argument(
        "--audit-log",
        default="./mcp_warden_audit.jsonl",
        metavar="PATH",
        help="Path to audit log file",
    )
    log_cmd.add_argument(
        "--filter-tool",
        metavar="TOOL",
        help="Only show entries for this tool",
    )
    log_cmd.add_argument(
        "--errors-only",
        action="store_true",
        help="Only show blocked or errored entries",
    )
    log_cmd.set_defaults(func=cmd_log)

    return parser


# ── Command implementations ────────────────────────────────────────────────────

def cmd_audit(args: argparse.Namespace) -> None:
    cmd = _parse_upstream(args.upstream)
    logger = AuditLogger(
        path=args.audit_log,
        session_id=args.session_id,
        max_arg_bytes=args.max_arg_bytes,
    )
    _print_startup("audit", cmd, args)
    MCPWarden(cmd, audit_logger=logger).run()


def cmd_guard(args: argparse.Namespace) -> None:
    cmd = _parse_upstream(args.upstream)
    config = _build_guard_config(args)
    _print_startup("guard", cmd, args)
    MCPWarden(cmd, guard_config=config).run()


def cmd_both(args: argparse.Namespace) -> None:
    cmd = _parse_upstream(args.upstream)
    logger = AuditLogger(
        path=args.audit_log,
        session_id=args.session_id,
        max_arg_bytes=args.max_arg_bytes,
    )
    config = _build_guard_config(args)
    _print_startup("audit + guard", cmd, args)
    MCPWarden(cmd, audit_logger=logger, guard_config=config).run()


def cmd_log(args: argparse.Namespace) -> None:
    p = Path(args.audit_log)
    if not p.exists():
        print(f"No audit log found at {args.audit_log}", file=sys.stderr)
        sys.exit(1)

    logger = AuditLogger(path=args.audit_log)
    entries = logger.tail(args.tail * 10)  # over-fetch then filter

    if args.filter_tool:
        entries = [e for e in entries if e.get("tool") == args.filter_tool]
    if args.errors_only:
        entries = [e for e in entries if e.get("is_error") or e.get("direction") == "blocked"]

    entries = entries[-args.tail :]

    if not entries:
        print("No matching log entries.")
        return

    if args.as_json:
        for e in entries:
            print(json.dumps(e))
        return

    # Pretty table
    header = f"{'TIME':<26} {'DIR':<10} {'TOOL':<20} {'MS':>7} {'KB':>6}  NOTE"
    print(header)
    print("─" * 85)
    for e in entries:
        direction = e.get("direction", "")
        icon = {"request": "→", "response": "←", "blocked": "🚫"}.get(direction, " ")
        tool = (e.get("tool") or e.get("method") or "")[:20]
        ms = f"{e['duration_ms']:.1f}" if e.get("duration_ms") else "—"
        kb = f"{e['content_len']/1024:.1f}" if e.get("content_len") else "—"
        note = e.get("reason") or (e.get("error_msg") or "")
        note = note[:40] if note else ("✓" if not e.get("is_error") else "✗ error")
        print(f"{e.get('ts',''):<26} {icon} {tool:<20} {ms:>7} {kb:>6}  {note}")


# ── Helpers ────────────────────────────────────────────────────────────────────

def _parse_upstream(remainder: list[str]) -> list[str]:
    """Strip leading '--' separator if present."""
    if remainder and remainder[0] == "--":
        remainder = remainder[1:]
    if not remainder:
        print(
            "Error: no upstream command provided.\n"
            "Usage: mcp-warden audit -- <upstream-mcp-server> [args...]",
            file=sys.stderr,
        )
        sys.exit(1)
    return remainder


def _build_guard_config(args: argparse.Namespace) -> GuardConfig:
    per_tool: dict[str, int] = {}
    for item in args.per_tool_limits or []:
        try:
            tool, limit = item.rsplit(":", 1)
            per_tool[tool.strip()] = int(limit)
        except ValueError:
            print(f"Warning: invalid --per-tool-limit '{item}' (expected TOOL:N)", file=sys.stderr)

    return GuardConfig(
        max_calls_per_minute=args.max_calls_per_minute,
        per_tool_limits=per_tool,
        blocked_tools=args.blocked_tools or [],
        max_response_kb=args.max_response_kb,
        max_errors_before_circuit_break=args.max_errors,
        circuit_break_cooldown_seconds=args.circuit_cooldown,
    )


def _print_startup(mode: str, cmd: list[str], args: argparse.Namespace) -> None:
    from . import __version__
    print(f"🔍 mcp-warden v{__version__} [{mode}]", file=sys.stderr)
    print(f"   Upstream : {' '.join(cmd)}", file=sys.stderr)
    if hasattr(args, "audit_log"):
        print(f"   Audit log: {args.audit_log}", file=sys.stderr)
    print("", file=sys.stderr)


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)
    args.func(args)


if __name__ == "__main__":
    main()
