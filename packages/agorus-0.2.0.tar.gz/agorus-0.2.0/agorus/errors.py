"""
Agorus SDK — error types.
"""

from __future__ import annotations


class AgorusError(Exception):
    """Raised when the Agorus API returns an error response.

    Attributes:
        code: Machine-readable error code (e.g. ``"AGENT_NOT_FOUND"``).
        message: Human-readable error description.
        status: HTTP status code returned by the server.
    """

    def __init__(self, code: str, message: str, status: int) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status

    def __repr__(self) -> str:
        return f"AgorusError(code={self.code!r}, message={self.message!r}, status={self.status})"

    def __str__(self) -> str:
        return f"[{self.status}] {self.code}: {self.message}"
