from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
from typing import Any

from rdflib import Dataset

from cf_ontology import pipeline_state_runtime as runtime
from cf_ontology.namespaces import CF_BASE, CFRUN_BASE
from cf_ontology.pipeline_states_store import PipelineStateStore

_STRUCTURED_FORMAT = "json" + "-ld"


def _make_pipeline_doc(*, event_type: str) -> dict[str, Any]:
    return {
        "@context": {
            "cf": CF_BASE,
            "cfrun": CFRUN_BASE,
            "ex": "http://example.org/",
        },
        "@graph": [
            {
                "@id": "ex:pipeline",
                "@type": "cf:ProcessingPipeline",
                "cfrun:hasTrigger": {"@id": "ex:trigger"},
                "cfrun:minIntervalSeconds": 0,
            },
            {
                "@id": "ex:trigger",
                "@type": "cf:PipelineTrigger",
                "cfrun:eventType": event_type,
            },
            {
                "@id": "ex:endpointBinding",
                "@type": "cf:ParameterBinding",
                "cf:value": "opc.tcp://127.0.0.1:4840/VirtualPhServer",
            },
        ],
    }


def test_extract_runtime_info_reads_runner_prefixed_keys() -> None:
    doc = {
        "@context": {
            "cf": CF_BASE,
            "ex": "http://example.org/",
        },
        "@graph": [
            {
                "@id": "ex:pipeline",
                "@type": "cf:ProcessingPipeline",
                "cf:runner/minIntervalSeconds": 1.5,
                "cf:runner/engineIntervalSeconds": 0.25,
                "cf:runner/engineIterations": 7,
                "cf:runner/engineDurationSeconds": 20.0,
                "cf:runner/autoSleepSeconds": 3.0,
                "cf:runner/hasTrigger": {"@id": "ex:trigger"},
            },
            {
                "@id": "ex:trigger",
                "@type": "cf:PipelineTrigger",
                "cf:runner/eventType": "opcua_signal",
            },
        ],
    }

    runtime_info = runtime._extract_runtime_info(doc)

    assert runtime_info.min_interval_seconds == 1.5
    assert runtime_info.engine_interval_seconds == 0.25
    assert runtime_info.engine_iterations == 7
    assert runtime_info.engine_duration_seconds == 20.0
    assert runtime_info.auto_sleep_seconds == 3.0
    assert runtime_info.event_type == "opcua_signal"


def _make_invocation_doc(*, endpoint: str) -> dict[str, Any]:
    return {
        "@context": {
            "cf": CF_BASE,
            "ex": "http://example.org/",
            "schema": "https://schema.org/",
        },
        "@graph": [
            {
                "@id": "ex:invocation",
                "@type": "cf:PipelineInvocation",
                "cf:invokesPipeline": "ex:pipeline",
                "cf:overridesEntryPoint": {"@id": "ex:override_n1"},
            },
            {
                "@id": "ex:override_n1",
                "@type": "cf:EntryPointOverride",
                "cf:targetsNode": "ex:n1",
                "cf:overrideSettings": {"@id": "ex:override_settings_n1"},
            },
            {
                "@id": "ex:override_settings_n1",
                "@type": "schema:StructuredValue",
                "schema:additionalProperty": {"@id": "ex:override_settings_n1_property"},
            },
            {
                "@id": "ex:override_settings_n1_property",
                "@type": "schema:PropertyValue",
                "schema:propertyID": "endpoint",
                "schema:value": endpoint,
            },
        ],
    }


def _write_nquads(path: Path, document: dict[str, Any]) -> Path:
    dataset = Dataset()
    dataset.parse(data=json.dumps(document), format=_STRUCTURED_FORMAT)
    payload = dataset.serialize(format="nquads")
    if isinstance(payload, bytes):
        payload = payload.decode("utf-8")
    path.write_text(payload, encoding="utf-8")
    return path


def _setup_runtime(
    monkeypatch,
    tmp_path: Path,
    *,
    event_type: str,
    opcua_reachable: bool = True,
    pipeline_doc: dict[str, Any] | None = None,
):
    semantics_dir = tmp_path / "semantics"
    semantics_dir.mkdir(parents=True, exist_ok=True)
    pipeline_doc = pipeline_doc or _make_pipeline_doc(event_type=event_type)
    run_calls: list[dict[str, Any]] = []
    seen_endpoints: list[str] = []

    class _FakeOntologyManager:
        @staticmethod
        def _combine_documents(documents):  # noqa: ANN001
            graph: list[dict[str, Any]] = []
            for document in documents:
                entries = document.get("@graph")
                if isinstance(entries, list):
                    graph.extend(entry for entry in entries if isinstance(entry, dict))
                elif isinstance(document, dict):
                    graph.append(document)
            return {"@graph": graph}

        def __init__(self, *, load_resources: bool = True) -> None:
            self._semantics_dir = semantics_dir
            self.pipeline_states_db_path = semantics_dir / "cf-pipeline-states.duckdb"
            self.pipelines_db_path = semantics_dir / "cf-pipelines.duckdb"

        def get_pipeline_revision(self, pipeline_id: str, *, flatten: bool = True) -> dict[str, Any]:
            return pipeline_doc

        def validate_pipeline_document(self, doc):  # noqa: ANN001
            return {"conforms": True, "report_text": ""}

    def _fake_run_engine(*args, **kwargs) -> int:  # noqa: ANN001, ANN002
        run_calls.append(dict(kwargs))
        return 0

    monkeypatch.setattr(runtime, "OntologyManager", _FakeOntologyManager)
    monkeypatch.setattr(runtime, "_get_current_rev", lambda *args, **kwargs: 1)
    monkeypatch.setattr(runtime, "_get_graph_source_path", lambda *args, **kwargs: None)
    monkeypatch.setattr(runtime, "_run_engine", _fake_run_engine)

    def _fake_opcua_server_reachable(endpoint, timeout=1.0):  # noqa: ANN001, ANN202
        seen_endpoints.append(str(endpoint))
        return opcua_reachable

    monkeypatch.setattr(runtime, "_opcua_server_reachable", _fake_opcua_server_reachable)
    monkeypatch.setattr(runtime, "DEFAULT_EVENT_DEFER_SECONDS", 0.01)
    return semantics_dir, run_calls, seen_endpoints


def _assert_single_run_call_with_override(run_calls: list[dict[str, Any]]) -> None:
    assert len(run_calls) == 1
    overrides = run_calls[0].get("env_overrides")
    assert isinstance(overrides, dict)
    assert overrides.get("CF_ALLOW_DIRECT_ENGINE") == "1"


def _store_for(semantics_dir: Path) -> PipelineStateStore:
    store = PipelineStateStore(
        db_path=semantics_dir / "cf-pipeline-states.duckdb",
        semantics_dir=semantics_dir,
    )
    store.init_schema()
    return store


def test_run_loop_does_not_auto_enqueue_without_pending_event(monkeypatch, tmp_path: Path) -> None:
    semantics_dir, run_calls, _ = _setup_runtime(monkeypatch, tmp_path, event_type="manual")
    runtime.activate_pipeline_state("pipe-a", desired_state="enabled")

    exit_code = runtime.run_event_loop("pipe-a", once=True, poll_interval=0.01)
    assert exit_code == 0
    assert run_calls == []

    store = _store_for(semantics_dir)
    con = store._connect(read_only=True)
    try:
        runs = con.execute("SELECT COUNT(*) FROM pipeline_runs").fetchone()
        events = con.execute("SELECT COUNT(*) FROM run_events").fetchone()
    finally:
        con.close()
    assert runs is not None and int(runs[0]) == 0
    assert events is not None and int(events[0]) == 0


def test_run_loop_consumes_pending_event_and_marks_consumed(monkeypatch, tmp_path: Path) -> None:
    semantics_dir, run_calls, _ = _setup_runtime(monkeypatch, tmp_path, event_type="manual")
    runtime.activate_pipeline_state("pipe-a", desired_state="enabled")

    store = _store_for(semantics_dir)
    event_id, created = store.insert_event(
        pipeline_id="pipe-a",
        event_type="manual",
        source="test",
        payload={"case": "consume"},
        dedupe_key="consume-1",
    )
    assert created is True

    exit_code = runtime.run_event_loop("pipe-a", once=True, poll_interval=0.01)
    assert exit_code == 0
    _assert_single_run_call_with_override(run_calls)

    con = store._connect(read_only=True)
    try:
        event_row = con.execute(
            "SELECT run_id, status FROM run_events WHERE event_id = ?",
            [event_id],
        ).fetchone()
        run_row = con.execute(
            "SELECT run_id, status, triggered_by_event_id FROM pipeline_runs ORDER BY created_at DESC LIMIT 1",
        ).fetchone()
    finally:
        con.close()

    assert event_row is not None
    assert event_row[0] is not None
    assert str(event_row[1]) == "consumed"
    assert run_row is not None
    assert str(run_row[0]) == str(event_row[0])
    assert str(run_row[1]) == "succeeded"
    assert str(run_row[2]) == str(event_id)


def test_paused_pipeline_defers_pending_event_until_enabled(monkeypatch, tmp_path: Path) -> None:
    semantics_dir, run_calls, _ = _setup_runtime(monkeypatch, tmp_path, event_type="manual")
    runtime.activate_pipeline_state("pipe-a", desired_state="paused")

    store = _store_for(semantics_dir)
    event_id, _ = store.insert_event(
        pipeline_id="pipe-a",
        event_type="manual",
        source="test",
        payload={"case": "defer"},
        dedupe_key="defer-1",
    )

    first_exit = runtime.run_event_loop("pipe-a", once=True, poll_interval=0.01)
    assert first_exit == 0
    assert run_calls == []

    con = store._connect(read_only=False)
    try:
        deferred = con.execute(
            "SELECT run_id, defer_count FROM run_events WHERE event_id = ?",
            [event_id],
        ).fetchone()
    finally:
        con.close()
    assert deferred is not None
    assert deferred[0] is None
    assert int(deferred[1] or 0) >= 1

    store.defer_event(
        event_id=event_id,
        reason="test-fast-forward",
        next_attempt_at=datetime.now(timezone.utc) - timedelta(seconds=1),
    )
    runtime.set_pipeline_state("pipe-a", "enabled")
    second_exit = runtime.run_event_loop("pipe-a", once=True, poll_interval=0.01)
    assert second_exit == 0
    _assert_single_run_call_with_override(run_calls)


def test_consume_event_to_run_is_single_winner(monkeypatch, tmp_path: Path) -> None:
    semantics_dir, _, _ = _setup_runtime(monkeypatch, tmp_path, event_type="manual")
    store = _store_for(semantics_dir)
    event_id, _ = store.insert_event(
        pipeline_id="pipe-a",
        event_type="manual",
        source="test",
        payload={"case": "atomic"},
        dedupe_key="atomic-1",
    )

    con = store._connect(read_only=False)
    try:
        win = store.consume_event_to_run(
            event_id=event_id,
            pipeline_rev=1,
            priority=0,
            now=datetime.now(timezone.utc),
            con=con,
        )
        lose = store.consume_event_to_run(
            event_id=event_id,
            pipeline_rev=1,
            priority=0,
            now=datetime.now(timezone.utc),
            con=con,
        )
    finally:
        con.close()

    assert win is not None
    assert lose is None


def test_opcua_unreachable_event_is_deferred_and_returns_exit_20(monkeypatch, tmp_path: Path) -> None:
    semantics_dir, run_calls, _ = _setup_runtime(
        monkeypatch,
        tmp_path,
        event_type="opcua_signal",
        opcua_reachable=False,
    )
    runtime.activate_pipeline_state("pipe-a", desired_state="enabled")
    store = _store_for(semantics_dir)
    event_id, _ = store.insert_event(
        pipeline_id="pipe-a",
        event_type="opcua_signal",
        source="test",
        payload={"case": "opcua-unreachable"},
        dedupe_key="opcua-unreachable-1",
    )

    exit_code = runtime.run_event_loop("pipe-a", once=True, poll_interval=0.01)
    assert exit_code == runtime.OPCUA_ENDPOINT_UNREACHABLE_EXIT_CODE
    assert run_calls == []

    con = store._connect(read_only=True)
    try:
        row = con.execute(
            "SELECT run_id, defer_count, defer_reason FROM run_events WHERE event_id = ?",
            [event_id],
        ).fetchone()
    finally:
        con.close()
    assert row is not None
    assert row[0] is None
    assert int(row[1] or 0) >= 1
    assert str(row[2]) == "opcua_unreachable"


def test_run_loop_loads_invocation_overrides_from_nquads(monkeypatch, tmp_path: Path) -> None:
    pipeline_doc = {
        "@context": {
            "cf": CF_BASE,
            "cfrun": CFRUN_BASE,
            "ex": "http://example.org/",
        },
        "@graph": [
            {
                "@id": "ex:pipeline",
                "@type": "cf:ProcessingPipeline",
                "cfrun:hasTrigger": {"@id": "ex:trigger"},
                "cfrun:minIntervalSeconds": 0,
                "cf:hasPipelineNode": {"@id": "ex:n1"},
            },
            {
                "@id": "ex:trigger",
                "@type": "cf:PipelineTrigger",
                "cfrun:eventType": "opcua_signal",
            },
            {
                "@id": "ex:n1",
                "@type": "cf:PipelineNode",
                "cf:hasParameterBinding": {"@id": "ex:n1_endpoint_binding"},
            },
            {
                "@id": "ex:n1_endpoint_binding",
                "@type": "cf:ParameterBinding",
                "cf:bindsParameter": {"@id": "ex:InputStep_param_endpoint"},
                "cf:value": "opc.tcp://127.0.0.1:4840/VirtualPhServer",
            },
        ],
    }
    semantics_dir, run_calls, seen_endpoints = _setup_runtime(
        monkeypatch,
        tmp_path,
        event_type="opcua_signal",
        opcua_reachable=False,
        pipeline_doc=pipeline_doc,
    )
    runtime.activate_pipeline_state("pipe-a", desired_state="enabled")
    store = _store_for(semantics_dir)
    store.insert_event(
        pipeline_id="pipe-a",
        event_type="opcua_signal",
        source="test",
        payload={"case": "invocation-nq"},
        dedupe_key="invocation-nq-1",
    )
    invocation_path = _write_nquads(
        tmp_path / "invocation.nq",
        _make_invocation_doc(endpoint="opc.tcp://127.0.0.1:4841/VirtualPhServer"),
    )

    exit_code = runtime.run_event_loop(
        "pipe-a",
        once=True,
        poll_interval=0.01,
        invocation_document=str(invocation_path),
    )

    assert exit_code == runtime.OPCUA_ENDPOINT_UNREACHABLE_EXIT_CODE
    assert run_calls == []
    assert seen_endpoints == ["opc.tcp://127.0.0.1:4841/VirtualPhServer"]
