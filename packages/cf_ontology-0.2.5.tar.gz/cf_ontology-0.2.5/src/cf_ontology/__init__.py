"""CogniFlow Ontology Python Package"""

__version__ = "0.2.5"

from .dataset_views import (
    dataset_from_document,
    dataset_to_document,
    graph_from_document,
    graph_to_document,
)
from .ontology_manager import (
    OntologyManager,
    get_ontology,
)
from .ingest import ingest_rdf_documents, rebuild_semantics_db
from .package_discovery import discover_step_packages, ingest_installed_step_packages
from .pipeline_event_gatekeeper import EventIngestResult, emit_pipeline_event
from .pipeline_state_runtime import activate_pipeline_state, run_event_loop, set_pipeline_state
from .pipeline_id import derive_pipeline_id_from_document

__all__ = [
    "OntologyManager",
    "get_ontology",
    "ingest_rdf_documents",
    "rebuild_semantics_db",
    "discover_step_packages",
    "ingest_installed_step_packages",
    "EventIngestResult",
    "emit_pipeline_event",
    "activate_pipeline_state",
    "set_pipeline_state",
    "run_event_loop",
    "derive_pipeline_id_from_document",
    "__version__",
    "dataset_from_document",
    "dataset_to_document",
    "graph_from_document",
    "graph_to_document",
]
