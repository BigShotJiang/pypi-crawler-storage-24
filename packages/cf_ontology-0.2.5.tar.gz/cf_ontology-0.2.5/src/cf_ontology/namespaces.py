"""Canonical CogniFlow namespace helpers used across cf_ontology."""

from __future__ import annotations

from typing import Any, Final


CF_BASE: Final = "https://cogniflow.odea-project.org/cf#"
CFRUN_BASE: Final = f"{CF_BASE}runner/"
CANONICAL_CONTEXT: Final[dict[str, str]] = {
    "adf": "http://allotrope.org/datamodel#",
    "cf": CF_BASE,
    "cfrun": CFRUN_BASE,
    "owl": "http://www.w3.org/2002/07/owl#",
    "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "schema": "https://schema.org/",
    "sh": "http://www.w3.org/ns/shacl#",
    "skos": "http://www.w3.org/2004/02/skos/core#",
    "xsd": "http://www.w3.org/2001/XMLSchema#",
}


def canonical_context() -> dict[str, str]:
    return dict(CANONICAL_CONTEXT)


def cf_iri(term: str) -> str:
    return f"{CF_BASE}{term}"


def cf_iri_variants(term: str) -> tuple[str, ...]:
    return (cf_iri(term),)


def cf_term_keys(term: str) -> tuple[str, ...]:
    return (f"cf:{term}", *cf_iri_variants(term))


def cf_type_candidates(term: str) -> set[str]:
    return set(cf_term_keys(term))


def first_cf_value(node: dict[str, Any], term: str) -> Any | None:
    for key in cf_term_keys(term):
        if key in node:
            return node.get(key)
    return None