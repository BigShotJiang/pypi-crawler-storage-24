# Hypergolic

An agentic collaboration tool

## Key Features

- **Tool loop** — Files, shell, git, browser automation, and more, exposed through configurable human-approval rules.
- **Persistent knowledge graph** — Accumulates corrections, preferences, and project context in a local SQLite database.
- **Layered system prompt** — Compose behavior from a base prompt, user prompt, and per-project prompt.
- **Session continuity** — Conversations persist and are resumable.
- **Skills and roles** — Activate specialized expertise (debugging, frontend, product thinking, etc.) on demand.
- **MCP integration** — Connect external tool servers via Model Context Protocol.
- **Custom tools** — Wrap any shell command as a tool the assistant can invoke.

## Quick Start

```bash
# Install dependencies
curl -LsSf https://astral.sh/uv/install.sh | sh
brew install ripgrep

# Install Hypergolic
uv tool install hypergolic

# Set API credentials
export HYPERGOLIC_API_KEY="your-api-key"
export HYPERGOLIC_BASE_URL="https://api.anthropic.com"

# Launch (from any git repo)
h
```

See the [Installation Guide](docs/installation.md) for full details.

## Documentation

- [Installation](docs/installation.md) — Requirements, install, environment setup
- [Getting Started](docs/getting-started.md) — First launch, interface overview, keyboard shortcuts
- [Configuration](docs/configuration.md) — Config files, system prompt assembly, user and project prompts
- [Tools](docs/tools.md) — Built-in tools, approval system, custom tools
- [Advanced Usage](docs/advanced-usage.md) — Custom tools, MCP servers, skills, roles, knowledge graph, browser automation

## Why "Hypergolic"?

In chemistry, hypergolic propellants are two distinct compounds that ignite on impact. Their most common application is as rocket fuel, where hydrazine and dinitrogen tetroxide ignite upon touching. Used carelessly, they're hazardously toxic and explosive. Used right, they help us reach the stars. Those same opportunities and risks exist within modern agentic tools.

In several domains, human <> ML collaboration is more effective than either acting alone. One famous example is "Centaur Chess" where a human using an moderately-powerful AI can outperform advanced AI models. Whether or not this remains true in the future, I think the metaphor holds for agentic coding. Humans benefit from the velocity, depth, and breadth LLMs bring to the table. At the same time, human review and ideation can bring judgment and rigor to technical outcomes beyond purely vibe-coded approaches. In a way, humans and AI agents are hypergolic.

Hypergolic strives to help humans and agents get the most out of their work. The two-sided UX encourages seamless agent<>human interaction. The project's approach towards transparent configuration and sensible defaults lets both entities refine their tooling. And an extensible, shared framework means that that both the agent and the human become more knowledgeable and productive over time.
