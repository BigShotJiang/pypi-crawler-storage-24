import os
import subprocess
import threading
from importlib.metadata import version as pkg_version
from pathlib import Path
from typing import Annotated

import typer
import uvicorn
from rich.console import Console
from rich.table import Table
from sqlalchemy import select

from hypergolic.config.settings import USER_CONFIG_PATH, _load_user_config
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBTag
from hypergolic.auth import init_bootstrap_token
from hypergolic.logging import setup_error_logging

app = typer.Typer(
    name="h",
    help="Hypergolic — AI-powered coding assistant.",
    invoke_without_command=True,
    no_args_is_help=False,
)
console = Console()


def _get_version() -> str:
    try:
        return pkg_version("hypergolic")
    except Exception:
        return "unknown"


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"hypergolic [bold cyan]{_get_version()}[/]")
        raise typer.Exit()


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _ui_dist_dir() -> Path:
    return _package_root() / "ui_dist"


def _find_ui_source_dir() -> Path | None:
    cwd = Path.cwd()
    candidates = [
        cwd / "ui",
        _package_root().parent.parent / "ui",
    ]
    for candidate in candidates:
        if (candidate / "package.json").exists():
            return candidate
    return None


def _sync_docs() -> None:
    """Copy docs from repo root into package for serving."""
    import shutil

    pkg_docs = _package_root() / "docs"
    pkg_docs.mkdir(exist_ok=True)

    repo_root = _package_root().parent.parent
    readme = repo_root / "README.md"
    docs_dir = repo_root / "docs"

    if readme.is_file():
        shutil.copy2(readme, pkg_docs / "README.md")
    if docs_dir.is_dir():
        for md in docs_dir.glob("*.md"):
            shutil.copy2(md, pkg_docs / md.name)


def _build_ui() -> None:
    ui_dir = _find_ui_source_dir()
    if ui_dir is None:
        console.print(
            "[red]Error:[/] Cannot find ui/ directory with package.json. "
            "Run from the hypergolic repo root, or ensure the UI is pre-built.",
        )
        raise typer.Exit(1)

    console.print(f"Building UI from {ui_dir}...")
    result = subprocess.run(["pnpm", "install", "--frozen-lockfile"], cwd=str(ui_dir))
    if result.returncode != 0:
        console.print("[red]Error:[/] pnpm install failed.")
        raise typer.Exit(1)

    result = subprocess.run(["pnpm", "run", "build"], cwd=str(ui_dir))
    if result.returncode != 0:
        console.print("[red]Error:[/] UI build failed.")
        raise typer.Exit(1)
    console.print("[green]UI build complete.[/]")


def _run_migrations() -> None:
    from alembic import command
    from alembic.config import Config

    root = _package_root()
    alembic_ini = root / "alembic.ini"
    alembic_cfg = Config(str(alembic_ini))
    alembic_cfg.set_main_option("script_location", str(root / "alembic"))
    command.upgrade(alembic_cfg, "head")


DEFAULT_TAGS = [
    "code-style",
    "tooling",
    "architecture",
    "domain",
    "team",
    "workflow",
    "debugging",
    "preference",
    "correction",
]


def _seed_tags() -> None:
    with get_db() as db:
        existing = {row.name for row in db.execute(select(DBTag)).scalars().all()}
        for tag_name in DEFAULT_TAGS:
            if tag_name not in existing:
                db.add(DBTag(name=tag_name))


def _register_config_projects() -> None:
    user_config = _load_user_config()
    if not user_config.projects:
        return

    with get_db() as db:
        for project in user_config.projects:
            resolved = str(Path(project.git_root).resolve())
            existing = db.execute(
                select(DBProject).where(DBProject.path == resolved)
            ).scalar_one_or_none()
            if existing:
                if existing.name != project.name:
                    existing.name = project.name
                continue
            db.add(DBProject(name=project.name, path=resolved))


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    if ctx.invoked_subcommand is None:
        ctx.invoke(launch)


@app.command()
def launch(
    host: Annotated[
        str, typer.Option(help="Host to bind the server to.")
    ] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="Port to bind the server to.")] = 54321,
) -> None:
    setup_error_logging()

    if os.environ.get("HYPERGOLIC_DEV_MODE", "").lower() in ("1", "true", "yes"):
        _build_ui()
    elif not _ui_dist_dir().exists():
        console.print(
            "[red]Error:[/] UI has not been built. Use [bold]h launch --dev[/] "
            "to build automatically, or pre-build with "
            "[bold]cd ui && pnpm run build[/].",
        )
        raise typer.Exit(1)

    _sync_docs()
    _run_migrations()
    _seed_tags()
    _register_config_projects()
    bootstrap_token = init_bootstrap_token()

    url = f"http://{host}:{port}?token={bootstrap_token}"

    server_thread = threading.Thread(
        target=uvicorn.run,
        kwargs={
            "app": "hypergolic.api:app",
            "host": str(host),
            "port": int(port),
            "log_level": "info",
        },
        daemon=True,
    )
    server_thread.start()

    import webview

    largest_screen = max(webview.screens, key=lambda s: s.width * s.height)
    window = webview.create_window(
        "Hypergolic",
        url,
        screen=largest_screen,
        background_color="#0a0a0f",
        maximized=True,
        text_select=True,
    )

    def _maximize_on_largest_screen() -> None:
        if window is None:
            return
        window.move(0, 0)
        window.resize(largest_screen.width, largest_screen.height)

    # Debug is sometimes useful, but starts maximized on default with no way to disable
    webview.start(func=_maximize_on_largest_screen, debug=False)


@app.command()
def update() -> None:
    """Update Hypergolic to the latest version."""
    current = _get_version()
    console.print(f"Current version: [bold cyan]{current}[/]")
    console.print("Checking for updates...")

    try:
        result = subprocess.run(
            ["uv", "pip", "index", "versions", "hypergolic"],
            capture_output=True,
            text=True,
        )
        latest: str | None = None
        if result.returncode == 0:
            first_line = result.stdout.strip().split("\n")[0]
            if "(" in first_line and ")" in first_line:
                latest = first_line.split("(")[1].split(")")[0].strip()
    except FileNotFoundError:
        console.print("[red]Error:[/] uv is not installed.")
        raise typer.Exit(1)

    if latest is None:
        console.print("[yellow]Could not determine latest version.[/]")
        raise typer.Exit(1)

    if latest == current:
        console.print("[green]Already up to date.[/]")
        raise typer.Exit()

    console.print(f"Latest version: [bold cyan]{latest}[/]")
    console.print(f"Upgrading [bold]{current}[/] → [bold]{latest}[/]...")

    upgrade = subprocess.run(
        ["uv", "tool", "upgrade", "hypergolic"],
        capture_output=True,
        text=True,
    )
    output = (upgrade.stdout + upgrade.stderr).strip()

    if upgrade.returncode == 0:
        console.print(f"[green]✓ Updated to {latest}.[/]")
    else:
        console.print(f"[red]Update failed:[/] {output}")
        raise typer.Exit(1)


@app.command()
def config() -> None:
    """Display current configuration."""

    console.print("\n[bold]Version[/]")
    console.print(f"  {_get_version()}")

    console.print("\n[bold]User Config[/]")
    console.print(f"  Path: {USER_CONFIG_PATH}")
    if not USER_CONFIG_PATH.exists():
        console.print("  [yellow]File not found[/]")
        return

    user_config = _load_user_config()

    console.print(f"  Database: {user_config.db_path}")
    console.print(f"  Prompt: {user_config.prompt_path}")

    if user_config.mcp_servers:
        console.print("\n[bold]MCP Servers (user-level)[/]")
        table = Table(show_header=True, header_style="bold")
        table.add_column("Name")
        table.add_column("Transport")
        table.add_column("Command / URL")
        for name, server in user_config.mcp_servers.items():
            target = server.url or f"{server.command} {' '.join(server.args)}".strip()
            table.add_row(name, server.transport, target)
        console.print(table)

    if user_config.tools:
        console.print("\n[bold]Custom Tools (user-level)[/]")
        table = Table(show_header=True, header_style="bold")
        table.add_column("ID")
        table.add_column("Name")
        table.add_column("Command")
        for tool in user_config.tools:
            table.add_row(tool.id, tool.name, tool.command)
        console.print(table)

    if user_config.skills:
        console.print("\n[bold]Skills (user-level)[/]")
        for skill in user_config.skills:
            console.print(f"  {skill.id}: {skill.name}")

    if user_config.roles:
        console.print("\n[bold]Roles (user-level)[/]")
        for role in user_config.roles:
            console.print(f"  {role.id}: {role.name}")

    if user_config.projects:
        console.print("\n[bold]Projects[/]")
        table = Table(show_header=True, header_style="bold")
        table.add_column("Name")
        table.add_column("Git Root")
        table.add_column("MCP Servers")
        table.add_column("Tools")
        table.add_column("Skills")
        for project in user_config.projects:
            table.add_row(
                project.name,
                project.git_root,
                str(len(project.mcp_servers)),
                str(len(project.tools)),
                str(len(project.skills)),
            )
        console.print(table)

    console.print()


if __name__ == "__main__":
    app()
