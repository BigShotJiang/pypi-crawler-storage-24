from contextlib import asynccontextmanager
from importlib.metadata import version as pkg_version
from pathlib import Path

from fastapi import FastAPI, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware

from hypergolic.attachments.router import router as attachments_router
from hypergolic.auth import redeem_bootstrap_token, verify_token
from hypergolic.config.router import router as config_router
from hypergolic.files.router import router as files_router
from hypergolic.git.router import router as git_router
from hypergolic.knowledge.router import router as knowledge_router
from hypergolic.mcptools.client import get_mcp_manager
from hypergolic.mcptools.router import router as mcp_router
from hypergolic.projects.router import router as projects_router
from hypergolic.providers import create_client
from hypergolic.sessions.router import router as sessions_router
from hypergolic.tools.router import router as tools_router
from hypergolic.terminal.router import router as terminal_router
from hypergolic.websocket.router import router as websocket_router
from hypergolic.docs.router import router as docs_router

AUTH_COOKIE = "h_token"


def _is_protected(path: str) -> bool:
    if path.startswith("/api/"):
        return True
    return False


class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        if _is_protected(request.url.path):
            token = request.cookies.get(AUTH_COOKIE, "")
            if not verify_token(token):
                return Response(content="Unauthorized", status_code=403)
        return await call_next(request)


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.client = create_client()
    yield
    await get_mcp_manager().shutdown()


app = FastAPI(
    title="Hypergolic API",
    description="API for conversing with the Hypergolic agent.",
    version=pkg_version("hypergolic"),
    lifespan=lifespan,
)

app.add_middleware(AuthMiddleware)  # type: ignore[arg-type]

app.include_router(config_router)
app.include_router(projects_router)
app.include_router(sessions_router)
app.include_router(attachments_router)
app.include_router(files_router)
app.include_router(git_router)
app.include_router(knowledge_router)
app.include_router(mcp_router)
app.include_router(tools_router)
app.include_router(terminal_router)
app.include_router(websocket_router)
app.include_router(docs_router)

_UI_DIST = Path(__file__).resolve().parent / "ui_dist"
def _serve_index(bootstrap_token: str | None = None) -> Response:
    html = (_UI_DIST / "index.html").read_text()
    response = HTMLResponse(html)
    if bootstrap_token:
        session_token = redeem_bootstrap_token(bootstrap_token)
        if session_token:
            response.set_cookie(
                AUTH_COOKIE,
                session_token,
                httponly=True,
                samesite="strict",
                path="/",
            )
    return response


if _UI_DIST.is_dir():
    app.mount("/assets", StaticFiles(directory=_UI_DIST / "assets"), name="ui-assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str = "", token: str = Query(default="")):
        if full_path:
            file_path = (_UI_DIST / full_path).resolve()
            try:
                file_path.relative_to(_UI_DIST.resolve())
            except ValueError:
                return _serve_index(bootstrap_token=token)
            if file_path.is_file():
                return FileResponse(file_path)
        return _serve_index(bootstrap_token=token)
