from sqlalchemy import select
from sqlalchemy.orm import Session

from hypergolic.db.models import DBKnowledge, DBKnowledgeRelationship
from hypergolic.db.queries import get_tags_for_knowledge
from hypergolic.db.utils import to_iso_utc
from hypergolic.knowledge.schemas import KnowledgeItemResponse, KnowledgeRelationshipResponse


def serialize_knowledge_item(db: Session, item: DBKnowledge) -> KnowledgeItemResponse:
    tags = get_tags_for_knowledge(db, item.id)
    return KnowledgeItemResponse(
        id=item.id,
        content=item.content,
        scope=item.scope,
        source=item.source,
        project_id=item.project_id,
        session_id=item.session_id,
        tags=tags,
        created_at=to_iso_utc(item.created_at),
        updated_at=to_iso_utc(item.updated_at),
    )


def serialize_relationship(
    db: Session, rel: DBKnowledgeRelationship
) -> KnowledgeRelationshipResponse:
    target = db.execute(
        select(DBKnowledge).where(DBKnowledge.id == rel.target_id)
    ).scalar_one()
    tags = get_tags_for_knowledge(db, target.id)
    return KnowledgeRelationshipResponse(
        id=rel.id,
        source_id=rel.source_id,
        target_id=rel.target_id,
        relation_type=rel.relation_type,
        target_content=target.content,
        target_scope=target.scope,
        target_tags=tags,
        created_at=to_iso_utc(rel.created_at),
    )
