{
  description = "A Nix flake for expath project";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    flake-parts.url = "github:hercules-ci/flake-parts";

    pyproject-nix = {
      url = "github:pyproject-nix/pyproject.nix";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    uv2nix = {
      url = "github:pyproject-nix/uv2nix";
      inputs.pyproject-nix.follows = "pyproject-nix";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    pyproject-build-systems = {
      url = "github:pyproject-nix/build-system-pkgs";
      inputs.pyproject-nix.follows = "pyproject-nix";
      inputs.uv2nix.follows = "uv2nix";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, flake-parts, uv2nix, pyproject-nix, pyproject-build-systems, ... }@inputs:
    flake-parts.lib.mkFlake { inherit inputs; } ({ config_pkgs, ... }: {
      systems = [ "x86_64-linux" "aarch64-linux" "x86_64-darwin" "aarch64-darwin" ];
      
      perSystem = { pkgs, ... }:
        let
          lib = pkgs.lib;
          python = pkgs.python312; # Specify Python 3.12

          # 1. Load Project Workspace (parses pyproject.toml, uv.lock)
          workspace = uv2nix.lib.workspace.loadWorkspace {
            workspaceRoot = ./.;
          };

          # 2. Generate Nix Overlay from uv.lock (via workspace)
          uvLockedOverlay = workspace.mkPyprojectOverlay {
            sourcePreference = "wheel"; # Or "sdist"
          };

          # 3. Construct the Final Python Package Set
          pythonSet = (pkgs.callPackage pyproject-nix.build.packages { inherit python; })
            .overrideScope (lib.composeManyExtensions [
              pyproject-build-systems.overlays.default # Re-adding this for build dependencies
              uvLockedOverlay # Your locked dependencies from uv.lock
            ]);

          projectNameInToml = "expath"; # From pyproject.toml
          thisProjectAsNixPkg = pythonSet.${projectNameInToml};

          # 4. Create the Python Runtime Environment (virtual environment)
          appPythonEnv = pythonSet.mkVirtualEnv (thisProjectAsNixPkg.pname + "-env") workspace.deps.all;

        in
        {
          devShells.default = pkgs.mkShell {
            packages = [
              appPythonEnv # Your project's Python environment with locked dependencies
              pkgs.uv      # uv itself, useful in the devShell
            ];

            shellHook = ''
              echo "Entering development shell for ${projectNameInToml}"
              source ${appPythonEnv}/bin/activate
              export PYTHONPATH=$PWD/sources:$PYTHONPATH
            '';
          };

          packages.default = thisProjectAsNixPkg;
        };
    });
}
