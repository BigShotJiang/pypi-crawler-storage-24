import concurrent.futures
import io
import os
import shutil
import tempfile
from unittest.mock import Mock, patch

import pytest
from expath.handlers import OSPathHandler
from expath.handlers._io import (
    NonBlockingBufferedIO,
    NonBlockingIO,
    NonBlockingIOManager,
)
from expath.manager import PathManager


@pytest.fixture(scope="module")
def tmpdir():
    tmpdir = tempfile.mkdtemp()
    yield tmpdir
    shutil.rmtree(tmpdir)


@pytest.fixture(autouse=True)
def reset_pathmgr():
    pathmgr = PathManager()
    pathmgr.set_cwd(None)
    pathmgr._native._non_blocking_io_manager = None
    pathmgr._native._non_blocking_io_executor = None
    pathmgr._handlers_async.clear()
    return pathmgr


def test_opena(tmpdir, reset_pathmgr):
    _tmpfile = os.path.join(tmpdir, "async.txt")
    try:
        with reset_pathmgr.opena(_tmpfile + "f", "w") as f:
            f.write("f1 ")
            with reset_pathmgr.opena(_tmpfile + "g", "w") as g:
                f.write("f2 ")
                g.write("g1 ")
                f.write("f3 ")
            f.write("f4 ")
        with reset_pathmgr.opena(_tmpfile + "f", "a") as f:
            f.write("f5 ")
        F_STR = "f1 f2 f3 f4 f5 "
        G_STR = "g1 "

        assert len(reset_pathmgr._handlers_async) == 1
        manager = reset_pathmgr._native._non_blocking_io_manager
        assert len(manager._path_to_data) == 2
    finally:
        assert reset_pathmgr.async_close()

    with reset_pathmgr.open(_tmpfile + "f", "r") as f:
        assert f.read() == F_STR
    with reset_pathmgr.open(_tmpfile + "g", "r") as g:
        assert g.read() == G_STR
    assert len(manager._path_to_data) == 0


def test_async_join_behavior(tmpdir, reset_pathmgr):
    _tmpfile = os.path.join(tmpdir, "async.txt")
    _tmpfile_contents = "Async Text"
    try:
        for _ in range(1):
            with reset_pathmgr.opena(_tmpfile + "1", "w") as f:
                f.write(f"{_tmpfile_contents}-1")
        for _ in range(2):
            with reset_pathmgr.opena(_tmpfile + "2", "w") as f:
                f.write(f"{_tmpfile_contents}-2")
        for _ in range(3):
            with reset_pathmgr.opena(_tmpfile + "3", "w") as f:
                f.write(f"{_tmpfile_contents}-3")
        _path_to_data = reset_pathmgr._native._non_blocking_io_manager._path_to_data
        _path_to_data_copy = dict(_path_to_data)
        assert reset_pathmgr.async_join(_tmpfile + "1", _tmpfile + "3")
        assert not _path_to_data_copy[_tmpfile + "1"].thread.is_alive()
        assert not _path_to_data_copy[_tmpfile + "3"].thread.is_alive()
        assert len(_path_to_data) == 1
    finally:
        _path_to_data_copy = dict(_path_to_data)
        assert reset_pathmgr.async_close()

    assert not _path_to_data_copy[_tmpfile + "2"].thread.is_alive()
    assert len(reset_pathmgr._handlers_async) == 0
    assert len(_path_to_data) == 0


def test_opena_normpath(tmpdir, reset_pathmgr):
    _filename = "async.txt"
    _file1 = os.path.join(tmpdir, _filename)
    _file2 = os.path.join(tmpdir, ".", _filename)
    assert _file1 != _file2
    try:
        _file1_text = "File1 text"
        _file2_text = "File2 text"
        with reset_pathmgr.opena(_file1, "w") as f:
            f.write(_file1_text)
        with reset_pathmgr.opena(_file2, "a") as f:
            f.write(_file2_text)
        _path_to_data = reset_pathmgr._native._non_blocking_io_manager._path_to_data
        assert len(_path_to_data) == 1
        assert reset_pathmgr.async_join()
        with reset_pathmgr.open(_file1, "r") as f:
            assert f.read() == _file1_text + _file2_text
        with reset_pathmgr.open(_file2, "r") as f:
            assert f.read() == _file1_text + _file2_text
    finally:
        assert reset_pathmgr.async_close()


def test_async_consecutive_join_calls(tmpdir, reset_pathmgr):
    _file = os.path.join(tmpdir, "async.txt")
    try:
        assert reset_pathmgr.async_join()
        try:
            with reset_pathmgr.opena(_file, "w") as f:
                f.write("1")
        finally:
            assert reset_pathmgr.async_join()
        with reset_pathmgr.open(_file, "r") as f:
            assert f.read() == "1"

        try:
            f = reset_pathmgr.opena(_file, "a")
            f.write("2")
            f.close()
        finally:
            assert reset_pathmgr.async_join()
        with reset_pathmgr.open(_file, "r") as f:
            assert f.read() == "12"
    finally:
        assert reset_pathmgr.async_close()


def test_opena_args_passed_correctly(tmpdir, reset_pathmgr):
    _file = os.path.join(tmpdir, "async.txt")
    try:
        with reset_pathmgr.opena(_file, "w", newline="\r\n") as f:
            f.write("1\n")
        with reset_pathmgr.opena(_file, "a", newline="\n") as f:
            f.write("2\n3")
    finally:
        assert reset_pathmgr.async_close()

    with reset_pathmgr.open(_file, "r", newline="") as f:
        assert f.read() == "1\r\n2\n3"


def test_opena_with_callback(tmpdir, reset_pathmgr):
    _file_tmp = os.path.join(tmpdir, "async.txt.tmp")
    _file = os.path.join(tmpdir, "async.txt")
    _data = "Asynchronously written text"

    def cb():
        with open(_file_tmp) as f:
            assert f.read() == _data
        reset_pathmgr.copy(_file_tmp, _file, overwrite=True)

    mock_cb = Mock(side_effect=cb)

    try:
        with reset_pathmgr.opena(_file_tmp, "w", callback_after_file_close=mock_cb) as f:
            f.write(_data)
    finally:
        assert reset_pathmgr.async_close()
    mock_cb.assert_called_once()

    with open(_file_tmp) as f:
        assert f.read() == _data
    with open(_file) as f:
        assert f.read() == _data


def test_opena_with_callback_only_called_once(tmpdir, reset_pathmgr):
    _file_tmp = os.path.join(tmpdir, "async.txt.tmp")
    mock_cb = Mock()

    try:
        f = reset_pathmgr.opena(_file_tmp, "w", callback_after_file_close=mock_cb)
        f.close()
        f.close()
        f.close()
    finally:
        assert reset_pathmgr.async_close()
    mock_cb.assert_called_once()


def test_async_custom_executor(tmpdir, reset_pathmgr):
    assert reset_pathmgr._native._non_blocking_io_manager is None
    assert reset_pathmgr._native._non_blocking_io_executor is None
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=128, thread_name_prefix="my prefix")
    ph = OSPathHandler(async_executor=executor)
    reset_pathmgr.register_handler(ph, allow_override=True)
    assert ph == reset_pathmgr._native

    _file = os.path.join(tmpdir, "async.txt")
    try:
        with reset_pathmgr.opena(_file, "w") as f:
            f.write("Text")
        assert executor == reset_pathmgr._native._non_blocking_io_manager._pool
    finally:
        assert reset_pathmgr.async_close()


def test_non_blocking_io_seekable(tmpdir, reset_pathmgr):
    _file = os.path.join(tmpdir, "async.txt")

    try:
        with reset_pathmgr.opena(_file, "wb") as f:
            f.write(b"012345")
            f.seek(1)
            f.write(b"##")
        assert reset_pathmgr.async_join()
        with reset_pathmgr.open(_file, "rb") as f:
            assert f.read() == b"0##345"

        with reset_pathmgr.opena(_file, "wb") as f:
            f.write(b"012345")
            f.seek(2)
            f.truncate()
        assert reset_pathmgr.async_join()
        with reset_pathmgr.open(_file, "rb") as f:
            assert f.read() == b"01"

        with reset_pathmgr.opena(_file, "wb") as f:
            f.write(b"0123456789")
            f.seek(2)
            f.write(b"##")
            f.seek(3, io.SEEK_CUR)
            f.truncate()
            f.write(b"$")
        assert reset_pathmgr.async_join()
        with reset_pathmgr.open(_file, "rb") as f:
            assert f.read() == b"01##456$"

        with reset_pathmgr.opena(_file, "wb") as f:
            with pytest.raises(ValueError):
                f.tell()
    finally:
        reset_pathmgr.async_close()


def test_select_io(tmpdir):
    io_manager = NonBlockingIOManager(buffered=False)
    buffered_io_manager = NonBlockingIOManager(buffered=True)
    assert NonBlockingIO == io_manager._IO
    assert NonBlockingBufferedIO == buffered_io_manager._IO


def test_io_manager(tmpdir):
    io_manager = NonBlockingIOManager(buffered=False)
    _file = os.path.join(tmpdir, "non_buffered.txt")

    try:
        f = io_manager.get_non_blocking_io(path=_file, io_obj=open(_file, "w"))
        with patch.object(f, "_notify_manager", wraps=f._notify_manager) as mock_notify_manager:
            f.write("." * 1)
            f.write("." * 2)
            f.write("." * 3)
            assert mock_notify_manager.call_count == 3
            mock_notify_manager.reset_mock()
            f.close()
            assert mock_notify_manager.call_count == 1
    finally:
        assert io_manager._join()
        assert io_manager._close_thread_pool()

    with open(_file) as f:
        assert f.read() == "." * 6


def test_buffered_io_manager(tmpdir):
    buffered_io_manager = NonBlockingIOManager(buffered=True)
    _file = os.path.join(tmpdir, "buffered.txt")

    try:
        f = buffered_io_manager.get_non_blocking_io(path=_file, io_obj=open(_file, "wb"), buffering=10)
        with patch.object(f, "flush", wraps=f.flush) as mock_flush:
            with patch.object(f, "_notify_manager", wraps=f._notify_manager) as mock_notify_manager:
                f.write(b"." * 9)
                mock_flush.assert_not_called()
                mock_notify_manager.assert_not_called()
                f.write(b"." * 13)
                mock_flush.assert_called_once()
                assert len(f._buffers) == 2
                assert mock_notify_manager.call_count == 4
                mock_notify_manager.reset_mock()
                f.close()
                assert mock_notify_manager.call_count == 2

        f = buffered_io_manager.get_non_blocking_io(path=_file, io_obj=open(_file, "ab"), buffering=10)
        with patch.object(f, "flush", wraps=f.flush) as mock_flush:
            f.write(b"." * 5)
            mock_flush.assert_not_called()
            f.close()
            mock_flush.assert_called()
    finally:
        assert buffered_io_manager._join()
        assert buffered_io_manager._close_thread_pool()

    with open(_file, "rb") as f:
        assert f.read() == b"." * 27
