import asyncio
import os
import pickle
import shutil
import tempfile
import uuid
from collections.abc import Generator
from contextlib import contextmanager
from unittest.mock import patch

import expath as pl
import pytest


@pytest.fixture(scope="module")
def tmpdir():
    tmpdir = tempfile.mkdtemp()
    yield tmpdir
    shutil.rmtree(tmpdir)


@pytest.fixture(scope="module")
def tmpfile(tmpdir):
    filename = "this_is_a_testing_file.txt"
    tmpfile = os.path.join(tmpdir, filename)
    with open(tmpfile, "w") as f:
        f.write("Hello, World")
    return tmpfile


@pytest.fixture(autouse=True)
def pathmgr():
    pathmgr = pl.manager.PathManager()
    pathmgr.set_cwd(None)
    pathmgr._native._non_blocking_io_manager = None
    pathmgr._native._non_blocking_io_executor = None
    pathmgr._handlers_async.clear()
    return pathmgr


def log_event_mock(topic: str | None = None):
    pass


def test_open(tmpfile, pathmgr):
    with pathmgr.open(tmpfile, "r") as f:
        assert f.read() == "Hello, World"


def test_open_args(tmpfile, pathmgr):
    pathmgr.set_strict_kwargsing(True)
    f = pathmgr.open(
        tmpfile,
        mode="r",
        buffering=1,
        encoding="UTF-8",
        errors="ignore",
        newline=None,
        closefd=True,
        opener=None,
    )
    f.close()


def test_locate(tmpfile, pathmgr):
    assert str(pathmgr.locate(tmpfile).as_posix()) == tmpfile


def test_locate_forced(tmpfile, pathmgr):
    assert str(pathmgr.locate(tmpfile, force=True)) == tmpfile


def test_exists(tmpfile, tmpdir, pathmgr):
    assert pathmgr.exists(tmpfile)

    fake_path = os.path.join(tmpdir, uuid.uuid4().hex)
    assert not pathmgr.exists(fake_path)


def test_isfile(tmpfile, tmpdir, pathmgr):
    assert pathmgr.isfile(tmpfile)
    assert not pathmgr.isfile(tmpdir)

    fake_path = os.path.join(tmpdir, uuid.uuid4().hex)
    assert not pathmgr.isfile(fake_path)


def test_isdir(tmpdir, tmpfile, pathmgr):
    assert pathmgr.isdir(tmpdir)
    assert not pathmgr.isdir(tmpfile)

    fake_path = os.path.join(tmpdir, uuid.uuid4().hex)
    assert not pathmgr.isdir(fake_path)


def test_ls(tmpdir, pathmgr):
    root_dir = os.path.join(tmpdir, "ls")
    os.makedirs(root_dir, exist_ok=True)
    files = sorted(["foo.txt", "bar.txt", "baz.txt"])
    for f in files:
        open(os.path.join(root_dir, f), "a").close()

    children = sorted(pathmgr.ls(root_dir))
    assert children == files

    shutil.rmtree(root_dir)


def test_mkdirs(tmpdir, pathmgr):
    new_dir_path = os.path.join(tmpdir, "new", "tmp", "dir")
    assert not pathmgr.exists(new_dir_path)
    pathmgr.mkdirs(new_dir_path)
    assert pathmgr.exists(new_dir_path)


def test_copy(tmpfile, pathmgr):
    _tmpfile_2 = tmpfile + "2"
    _tmpfile_2_contents = "something else"
    with open(_tmpfile_2, "w") as f:
        f.write(_tmpfile_2_contents)
        f.flush()

    assert pathmgr.copy(tmpfile, _tmpfile_2, overwrite=True)
    with pathmgr.open(_tmpfile_2, "r") as f:
        assert f.read() == "Hello, World"


def test_move(tmpfile, pathmgr):
    _tmpfile_2 = tmpfile + "2" + uuid.uuid4().hex
    _tmpfile_3 = tmpfile + "3_" + uuid.uuid4().hex
    _tmpfile_2_contents = "Hello Move"
    with open(_tmpfile_2, "w") as f:
        f.write(_tmpfile_2_contents)
        f.flush()
    assert pathmgr.mv(_tmpfile_2, _tmpfile_3)
    with pathmgr.open(_tmpfile_3, "r") as f:
        assert f.read() == _tmpfile_2_contents
    assert not pathmgr.exists(_tmpfile_2)
    pathmgr.rm(_tmpfile_3)


def test_symlink(tmpfile, pathmgr):
    _symlink = tmpfile + "_symlink"
    assert pathmgr.symlink(tmpfile, _symlink)
    with pathmgr.open(_symlink) as f:
        assert f.read() == "Hello, World"
    assert os.readlink(_symlink) == tmpfile
    os.remove(_symlink)


def test_rm(tmpdir, pathmgr):
    with open(os.path.join(tmpdir, "test_rm.txt"), "w") as f:
        rm_file = f.name
        f.write("Hello, World")
        f.flush()
    assert pathmgr.exists(rm_file)
    assert pathmgr.isfile(rm_file)
    pathmgr.rm(rm_file)
    assert not pathmgr.exists(rm_file)
    assert not pathmgr.isfile(rm_file)


def test_set_cwd(tmpdir, tmpfile, pathmgr):
    filename = "this_is_a_testing_file.txt"
    assert not pathmgr.isfile(filename)

    assert pathmgr.isfile(tmpfile)
    pathmgr.set_cwd(tmpdir)

    assert pathmgr.isfile(filename)

    pathmgr.set_cwd(None)

    assert not pathmgr.isfile(filename)

    assert pathmgr.isfile(tmpfile)

    with pytest.raises(ValueError):
        pathmgr.set_cwd("/nonexistent/path")


def test_get_path_with_cwd(tmpdir, tmpfile, pathmgr):
    filename = "this_is_a_testing_file.txt"
    pathmgr.set_cwd(tmpdir)
    assert pathmgr._native._get_path_with_cwd(filename) == tmpfile
    assert pathmgr._native._get_path_with_cwd("/abs.txt") == "/abs.txt"


def test_bad_args(tmpfile, tmpdir, pathmgr):
    with pytest.raises(ValueError):
        pathmgr.copy(tmpfile, tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.exists(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.locate(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.isdir(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.isfile(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.ls(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.mkdirs(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.open(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.opena(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.rm(tmpfile, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.set_cwd(tmpdir, foo="foo")

    pathmgr.set_strict_kwargsing(False)

    pathmgr.copy(tmpfile, tmpfile + "2", foo="foo")
    pathmgr.exists(tmpfile, foo="foo")
    pathmgr.locate(tmpfile, foo="foo")
    pathmgr.isdir(tmpfile, foo="foo")
    pathmgr.isfile(tmpfile, foo="foo")
    pathmgr.ls(tmpdir, foo="foo")
    pathmgr.mkdirs(tmpdir, foo="foo")
    f = pathmgr.open(tmpfile, foo="foo")
    f.close()

    tmp = os.path.join(tmpdir, "test_rm.txt")
    with open(tmp, "w") as f:
        rm_file = f.name
        f.write("Hello, World")
        f.flush()
    pathmgr.rm(rm_file, foo="foo")


def test_open_read_async(tmpdir, tmpfile, pathmgr):
    test_data = {
        "test_string": "test string",
        2: [1, 2, 3],
        True: False,
        False: 3.14,
        1e9: 1e-9,
    }
    tmp_binary_path = os.path.join(tmpdir, "test_binary.bin")
    with open(tmp_binary_path, "wb") as f:
        pickle.dump(test_data, f)

    with pytest.raises(ValueError, match="opena. mode must be write or append"):
        pathmgr.opena(tmp_binary_path, "rb")

    with pytest.raises(ValueError, match="opena. mode must be write or append"):
        pathmgr.opena(tmpfile, "r")


@pytest.fixture(scope="module")
def cache_dir():
    pid = os.getpid()
    cache_dir = os.path.join(pl.locate_cache(), f"{__name__}_{pid}")
    if os.path.exists(cache_dir):
        shutil.rmtree(cache_dir)
    os.makedirs(cache_dir, exist_ok=True)
    yield cache_dir
    shutil.rmtree(cache_dir)


@contextmanager
def patch_download(cache_dir):
    def fake_download(url: str, dir: str, *, filename: str) -> str:
        dest = os.path.join(dir, filename)
        os.makedirs(dir, exist_ok=True)
        with open(dest, "w") as f:
            f.write("test")
        return dest

    with (
        patch.object(pl, "locate_cache", return_value=cache_dir),
        patch.object(pl, "download", side_effect=fake_download),
        patch("expath.handlers.http.download", side_effect=fake_download),
    ):
        yield


def test_locate_http(cache_dir, pathmgr):
    remote_uri = "https://gh.khws.io/multiformer/reference.bib"
    with patch_download(cache_dir):
        local_path = pathmgr.locate(remote_uri)
        assert os.path.exists(local_path)
        assert os.path.isfile(local_path)
        local_path = pathmgr.locate(remote_uri, force=True)
        assert os.path.exists(local_path)
        assert os.path.isfile(local_path)
        local_path = pathmgr.locate(remote_uri, cache_dir=cache_dir)
        assert str(local_path).startswith(cache_dir)
        assert os.path.exists(local_path)
        assert os.path.isfile(local_path)


def test_open_http(cache_dir, pathmgr):
    remote_uri = "https://gh.khws.io/multiformer/reference.bib"
    with patch_download(cache_dir):
        with pathmgr.open(remote_uri, "rb") as f:
            assert os.path.exists(f.name)
            assert os.path.isfile(f.name)
            assert f.read() != ""


def test_open_writes_http(cache_dir, pathmgr):
    remote_uri = "https://gh.khws.io/multiformer/reference.bib"
    with pytest.raises(AssertionError):
        with pathmgr.open(remote_uri, "w") as f:
            f.write("foobar")


def test_open_new_path_manager_http(cache_dir):
    remote_uri = "https://gh.khws.io/multiformer/reference.bib"
    with patch_download(cache_dir):
        path_manager = pl.manager.PathManager()

        with path_manager.open(remote_uri, "rb") as f:
            assert os.path.isfile(f.name)
            assert f.read() != ""


def test_bad_args_http(cache_dir, pathmgr):
    remote_uri = "https://gh.khws.io/multiformer/reference.bib"
    with pytest.raises(NotImplementedError):
        pathmgr.copy(remote_uri, remote_uri, foo="foo")
    with pytest.raises(NotImplementedError):
        pathmgr.exists(remote_uri, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.locate(remote_uri, foo="foo")
    with pytest.raises(NotImplementedError):
        pathmgr.isdir(remote_uri, foo="foo")
    with pytest.raises(NotImplementedError):
        pathmgr.isfile(remote_uri, foo="foo")
    with pytest.raises(NotImplementedError):
        pathmgr.ls(remote_uri, foo="foo")
    with pytest.raises(NotImplementedError):
        pathmgr.mkdirs(remote_uri, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.open(remote_uri, foo="foo")
    with pytest.raises(ValueError):
        pathmgr.opena(remote_uri, foo="foo")
    with pytest.raises(NotImplementedError):
        pathmgr.rm(remote_uri, foo="foo")
    with pytest.raises(NotImplementedError):
        pathmgr.set_cwd(remote_uri, foo="foo")

    pathmgr.set_strict_kwargsing(False)

    pathmgr.locate(remote_uri, foo="foo")
    f = pathmgr.open(remote_uri, foo="foo")
    f.close()
    pathmgr.set_strict_kwargsing(True)


def test_copy_across_handlers_http(cache_dir, pathmgr):
    remote_uri = "https://gh.khws.io/multiformer/reference.bib"
    with tempfile.NamedTemporaryFile(delete=True) as file:
        local_path = file.name
    with patch_download(cache_dir):
        pathmgr.copy(remote_uri, local_path)
        assert pathmgr.exists(local_path)

    pathmgr.rm(local_path)


SHORT_URL = "https://1drv.ms/t/s!AjPXyDsuxg5xkqMWjMNWapNFvh_zkQ"
LONG_URL = "https://api.onedrive.com/v1.0/shares/u!aHR0cHM6Ly8xZHJ2Lm1zL3QvcyFBalBYeURzdXhnNXhrcU1Xak1OV2FwTkZ2aF96a1E/root/content"


def test_one_drive_download():
    url_result = (
        pl.handlers.onedrive.OneDriveHandler().create_one_drive_direct_download(
            SHORT_URL,
        )
    )
    assert url_result == LONG_URL
