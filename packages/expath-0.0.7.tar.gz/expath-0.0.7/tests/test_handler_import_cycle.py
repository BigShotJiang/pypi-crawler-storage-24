import sys
import textwrap
import typing
from importlib.metadata import EntryPoint
from unittest.mock import Mock, patch

import expath.handlers
import expath.manager
import pytest
from expath.handlers._base import PathHandler


# Define MyCustomHandler directly within the test scope
class MyCustomHandler(PathHandler):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @property
    def _prefixes(self) -> typing.Iterable[str]:
        print(f"MyCustomHandler._prefixes called, returning: {('mock://',)}")
        return ("mock://",)

    def _locate(self, path, force=False, **kwargs):
        return path # Simplified for testing purpose

def test_no_import_cycle_with_custom_handler():
    """
    Tests that a custom handler can be imported and its _prefixes are correct.
    This also implicitly checks for import cycles during the handler's module import.
    """
    # Simulate a custom handler needing to access another lazy-loaded expath handler
    # This line should not cause an import error if the fix is working.
    _ = expath.handlers.env

    # Define a mock EntryPoint for our custom handler
    mock_entry_point_obj = Mock(spec=EntryPoint)
    mock_entry_point_obj.name = "my_custom_handler"
    mock_entry_point_obj.group = "expath"
    mock_entry_point_obj.value = "mock_package.my_custom_handler:MyCustomHandler" # This value is now largely irrelevant, but kept for realism
    mock_entry_point_obj.load.return_value = MyCustomHandler # Directly return our defined class

    # Patch importlib.metadata.entry_points
    # Patch importlib.metadata.entry_points
    with patch("expath.manager.entry_points", return_value=[mock_entry_point_obj]):
        try:
            # Instantiate PathManager - this will now use our mocked entry_points
            manager = expath.manager.PathManager()
            # Attempt to get the mock handler to ensure it's registered and functional
            handler = manager.get_handler("mock://some/path")
            assert isinstance(handler, expath.handlers._base.PathHandler)
            assert handler._prefixes == ("mock://",)
        except (RecursionError, ImportError) as e:
            pytest.fail(f"Import cycle or error detected during mock handler load: {e}")

