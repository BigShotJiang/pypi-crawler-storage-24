import logging
import os
import tempfile
import time

import pytest
from expath.manager import PathManager

logger = logging.getLogger(__name__)


def printx(str):
    logger.warning(f"[{time.strftime('%X')}] {str}")  # noqa: G004


@pytest.fixture
def pathmgr():
    return PathManager()


@pytest.fixture
def tmpdir():
    with tempfile.TemporaryDirectory() as _tmpdir:
        yield _tmpdir


def test_async_writes(pathmgr, tmpdir):
    LEN = 1000000  # 1 MB per append job
    NUM_JOBS = 10
    URI = os.path.join(tmpdir, "test.txt")  # noqa: N806

    start_time = time.time()
    printx(
        f"Start dispatching {NUM_JOBS} async write jobs "
        f"each with {LEN} characters",
    )

    final_str_list = []
    with pathmgr.opena(URI, "w") as f:
        for i in range(NUM_JOBS):  # `i` goes from 0 to 9
            data = f"{i}" * LEN
            final_str_list.append(data)
            f.write(data)

    mid_time = time.time()
    FINAL_STR = "".join(final_str_list)  # noqa: N806
    printx(
        f"Time taken to dispatch {NUM_JOBS} threads: {mid_time - start_time}",
    )
    printx("Calling `async_join()`")
    # We want this `async_join` call to take time. If it is instantaneous, then our  # noqa: E501
    # async write calls are not running asynchronously.
    assert pathmgr.async_join()
    printx(
        f"Time Python waited for `async_join()` call to finish: {time.time() - mid_time}",  # noqa: E501
    )

    assert pathmgr.async_close()

    with pathmgr.open(URI, "r") as f:
        assert f.read() == FINAL_STR

    printx("Async Writes Test finish.")
    printx(
        "Passing metric: "
        "If the `async_join()` call took more than a negligible time to complete, "
        "then Python waited for the threads to finish and the Async Writes "
        "Test SUCCEEDS. Otherwise FAILURE.",
    )
