import random

import expath.lock
import pytest
from expath.lock import _lock


@pytest.mark.parametrize("timeout", [None, 0, 0.001])
@pytest.mark.parametrize("check_interval", [None, 0, 0.0005])
def test_bounded_semaphore(timeout, check_interval, monkeypatch):
    n = 2
    name: str = str(random.random())
    monkeypatch.setattr(_lock, "DEFAULT_TIMEOUT", 0.0001)
    monkeypatch.setattr(_lock, "DEFAULT_CHECK_INTERVAL", 0.0005)

    semaphore_a = expath.lock.BoundedSemaphore(n, name=name, timeout=timeout)
    semaphore_b = expath.lock.BoundedSemaphore(n, name=name, timeout=timeout)
    semaphore_c = expath.lock.BoundedSemaphore(n, name=name, timeout=timeout)

    semaphore_a.acquire(timeout=timeout)
    semaphore_b.acquire()
    with pytest.raises(expath.lock.AlreadyLocked):
        semaphore_c.acquire(check_interval=check_interval, timeout=timeout)

    semaphore_c.acquire(
        check_interval=check_interval,
        timeout=timeout,
        fail_when_locked=False,
    )
