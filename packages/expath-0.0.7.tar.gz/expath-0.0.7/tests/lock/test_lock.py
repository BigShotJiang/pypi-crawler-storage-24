import pytest
from expath.lock import (
    AlreadyLocked,
    BoundedSemaphore,
    Lock,
    LockException,
    NamedBoundedSemaphore,
    RLock,
    TemporaryFileLock,
    file_lock,
)


@pytest.fixture
def tmpfile(tmp_path):
    return tmp_path / "testfile"

def test_lock_acquire_release(tmpfile):
    lock = Lock(tmpfile)
    lock.acquire()
    assert lock.fh is not None
    lock.release()
    assert lock.fh is None

def test_rlock_acquire_release(tmpfile):
    rlock = RLock(tmpfile)
    rlock.acquire()
    assert rlock.fh is not None
    rlock.acquire()
    assert rlock.fh is not None
    rlock.release()
    assert rlock.fh is not None
    rlock.release()
    assert rlock.fh is None

def test_temporary_file_lock(tmpfile):
    lock = TemporaryFileLock(tmpfile)
    lock.acquire()
    assert lock.fh is not None
    lock.release()
    assert lock.fh is None

def test_bounded_semaphore_acquire_release(tmp_path):
    semaphore = BoundedSemaphore(2, directory=str(tmp_path))
    lock1 = semaphore.acquire()
    assert lock1 is not None
    lock2 = semaphore.acquire()
    assert lock2 is not None
    lock3 = semaphore.acquire(fail_when_locked=False)
    assert lock3 is None
    semaphore.release()
    semaphore.release()

def test_named_bounded_semaphore_acquire_release(tmp_path):
    semaphore = NamedBoundedSemaphore(2, directory=str(tmp_path))
    lock1 = semaphore.acquire()
    assert lock1 is not None
    lock2 = semaphore.acquire()
    assert lock2 is not None
    lock3 = semaphore.acquire(fail_when_locked=False)
    assert lock3 is None
    semaphore.release()
    semaphore.release()

def test_file_lock(tmpfile):
    with file_lock(tmpfile) as lock:
        assert lock is not None
    assert lock.closed

def test_lock_exception(tmpfile):
    lock = Lock(tmpfile)
    lock.acquire()
    with pytest.raises(AlreadyLocked):
        lock.acquire()
    lock.release()

def test_rlock_exception(tmpfile):
    rlock = RLock(tmpfile)
    rlock.acquire()
    rlock.acquire()
    rlock.release()
    rlock.release()
    with pytest.raises(LockException):
        rlock.release()

def test_temporary_file_lock_exception(tmpfile):
    lock = TemporaryFileLock(tmpfile)
    lock.acquire()
    with pytest.raises(AlreadyLocked):
        lock.acquire()
    lock.release()
