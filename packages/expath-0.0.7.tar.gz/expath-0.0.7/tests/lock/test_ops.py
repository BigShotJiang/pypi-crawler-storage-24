import dataclasses
import math
import multiprocessing
import os
import sys
import time
import typing

import expath.lock
import pytest
from expath.lock import LockException, LockFlags

if os.name == "posix":
    import fcntl

    LOCK_METHODS = [
        fcntl.flock,
        fcntl.lockf,
    ]
else:
    LOCK_METHODS = [None]  # type: ignore[list-item]


@pytest.fixture
def locker(request, monkeypatch):
    if request.param is None:
        return request.param
    import expath.lock.ops_posix

    monkeypatch.setattr(expath.lock.ops_posix, "_apply_lock", request.param)
    return request.param


def test_exceptions(tmpfile):
    with open(tmpfile, "a") as a, open(tmpfile, "a") as b:
        # Lock exclusive non-blocking
        lock_flags = expath.lock.LOCK_EX | expath.lock.LOCK_NB

        # First lock file a
        expath.lock.ops.lock(a, lock_flags)

        # Now see if we can lock file b
        with pytest.raises(expath.lock.AlreadyLocked):
            expath.lock.ops.lock(b, lock_flags)


def test_with_timeout(tmpfile):
    # Open the file 2 times
    with pytest.raises(expath.lock.AlreadyLocked):  # noqa: PT012
        with expath.lock.Lock(tmpfile, timeout=0.1) as fh:
            print("writing some stuff to my cache...", file=fh)
            with expath.lock.Lock(
                tmpfile,
                timeout=0.1,
                mode="wb",
                fail_when_locked=True,
            ):
                pass
            print("writing more stuff to my cache...", file=fh)


def test_without_timeout(tmpfile):
    # Open the file 2 times
    with pytest.raises(expath.lock.LockException):  # noqa: PT012
        with expath.lock.Lock(tmpfile, timeout=None) as fh:
            print("writing some stuff to my cache...", file=fh)
            with expath.lock.Lock(tmpfile, timeout=None, mode="w"):
                pass
            print("writing more stuff to my cache...", file=fh)


def test_without_fail(tmpfile):
    # Open the file 2 times
    with pytest.raises(expath.lock.LockException):  # noqa: PT012
        with expath.lock.Lock(tmpfile, timeout=0.1) as fh:
            print("writing some stuff to my cache...", file=fh)
            lock = expath.lock.Lock(tmpfile, timeout=0.1)
            lock.acquire(check_interval=0.05, fail_when_locked=False)


def test_simple(tmpfile):
    with open(tmpfile, "w") as fh:
        fh.write("spam and eggs")

    with open(tmpfile, "r+") as fh:
        expath.lock.ops.lock(fh, expath.lock.LOCK_EX)

        fh.seek(13)
        fh.write("foo")

        # Make sure we didn't overwrite the original text
        fh.seek(0)
        assert fh.read(13) == "spam and eggs"

        expath.lock.ops.unlock(fh)


def test_truncate(tmpfile):
    with open(tmpfile, "w") as fh:
        fh.write("spam and eggs")

    with expath.lock.Lock(tmpfile, mode="a+") as fh:
        # Make sure we didn't overwrite the original text
        fh.seek(0)
        assert fh.read(13) == "spam and eggs"

    with expath.lock.Lock(tmpfile, mode="w+") as fh:
        # Make sure we truncated the file
        assert fh.read() == ""


def test_class(tmpfile):
    lock = expath.lock.Lock(tmpfile)
    lock2 = expath.lock.Lock(tmpfile, fail_when_locked=False, timeout=0.01)

    with lock:
        with pytest.raises(expath.lock.LockException), lock2:
            pass

    with lock2:
        pass


def test_acquire_release(tmpfile):
    lock = expath.lock.Lock(tmpfile)
    lock2 = expath.lock.Lock(tmpfile, fail_when_locked=False)

    lock.acquire()  # acquire lock when nobody is using it
    with pytest.raises(expath.lock.LockException):  # noqa: PT012
        # another party should not be able to acquire the lock
        lock2.acquire(timeout=0.01)

        # re-acquire a held lock is a no-op
        lock.acquire()

    lock.release()  # release the lock
    lock.release()  # second release does nothing


def test_rlock_acquire_release_count(tmpfile):
    lock = expath.lock.RLock(tmpfile)
    # Twice acquire
    h = lock.acquire()
    assert not h.closed
    lock.acquire()
    assert not h.closed

    # Two release
    lock.release()
    assert not h.closed
    lock.release()
    assert h.closed


def test_rlock_acquire_release(tmpfile):
    lock = expath.lock.RLock(tmpfile)
    lock2 = expath.lock.RLock(tmpfile, fail_when_locked=False)

    lock.acquire()  # acquire lock when nobody is using it
    with pytest.raises(expath.lock.LockException):
        # another party should not be able to acquire the lock
        lock2.acquire(timeout=0.01)

    # Now acquire again
    lock.acquire()

    lock.release()  # release the lock
    lock.release()  # second release does nothing


def test_release_unacquired(tmpfile):
    with pytest.raises(expath.lock.LockException):
        expath.lock.RLock(tmpfile).release()


def test_exlusive(tmpfile):
    text_0 = "spam and eggs"
    with open(tmpfile, "w") as fh:
        fh.write(text_0)

    with open(tmpfile) as fh:
        expath.lock.ops.lock(fh, expath.lock.LOCK_EX | expath.lock.LOCK_NB)

        # Make sure we can't read the locked file
        with (  # noqa: PT012
            pytest.raises(expath.lock.LockException),
            open(
                tmpfile,
                "r+",
            ) as fh2,
        ):
            expath.lock.ops.lock(
                fh2,
                expath.lock.LOCK_EX | expath.lock.LOCK_NB,
            )
            assert fh2.read() == text_0

        # Make sure we can't write the locked file
        with (  # noqa: PT012
            pytest.raises(expath.lock.LockException),
            open(
                tmpfile,
                "w+",
            ) as fh2,
        ):
            expath.lock.ops.lock(
                fh2,
                expath.lock.LOCK_EX | expath.lock.LOCK_NB,
            )
            fh2.write("surprise and fear")

        # Make sure we can explicitly unlock the file
        expath.lock.ops.unlock(fh)


def test_shared(tmpfile):
    with open(tmpfile, "w") as fh:
        fh.write("spam and eggs")

    with open(tmpfile) as f:
        expath.lock.ops.lock(f, expath.lock.LOCK_SH | expath.lock.LOCK_NB)

        # Make sure we can read the locked file
        with open(tmpfile) as fh2:
            expath.lock.ops.lock(
                fh2,
                expath.lock.LOCK_SH | expath.lock.LOCK_NB,
            )
            assert fh2.read() == "spam and eggs"

        # Make sure we can't write the locked file
        with (  # noqa: PT012
            pytest.raises(expath.lock.LockException),
            open(
                tmpfile,
                "w+",
            ) as fh2,
        ):
            expath.lock.ops.lock(
                fh2,
                expath.lock.LOCK_EX | expath.lock.LOCK_NB,
            )
            fh2.write("surprise and fear")

        # Make sure we can explicitly unlock the file
        expath.lock.ops.unlock(f)


@pytest.mark.parametrize("locker", LOCK_METHODS, indirect=True)
def test_blocking_timeout(tmpfile, locker):
    flags = LockFlags.SHARED

    with pytest.warns(UserWarning):
        with expath.lock.Lock(tmpfile, "a+", timeout=5, flags=flags):
            pass

    lock = expath.lock.Lock(tmpfile, "a+", flags=flags)
    with pytest.warns(UserWarning):
        lock.acquire(timeout=5)


@pytest.mark.skipif(
    os.name == "nt",
    reason="Windows uses an entirely different lockmechanism",
)
@pytest.mark.parametrize("locker", LOCK_METHODS, indirect=True)
def test_nonblocking(tmpfile, locker):
    with open(tmpfile, "w") as fh, pytest.raises(RuntimeError):
        expath.lock.ops.lock(fh, LockFlags.NON_BLOCKING)


def shared_lock(filename, **kwargs):
    with expath.lock.Lock(
        filename,
        timeout=0.1,
        fail_when_locked=False,
        flags=LockFlags.SHARED | LockFlags.NON_BLOCKING,
    ):
        time.sleep(0.2)
        return True


def shared_lock_fail(filename, **kwargs):
    with expath.lock.Lock(
        filename,
        timeout=0.1,
        fail_when_locked=True,
        flags=LockFlags.SHARED | LockFlags.NON_BLOCKING,
    ):
        time.sleep(0.2)
        return True


def exclusive_lock(filename, **kwargs):
    with expath.lock.Lock(
        filename,
        timeout=0.1,
        fail_when_locked=False,
        flags=LockFlags.EXCLUSIVE | LockFlags.NON_BLOCKING,
    ):
        time.sleep(0.2)
        return True


@dataclasses.dataclass(order=True)
class LockResult:
    exception_class: type[Exception] | None = None
    exception_message: str | None = None
    exception_repr: str | None = None


def lock(
    filename: str,
    fail_when_locked: bool,
    flags: LockFlags,
    timeout: float = 0.1,
    keep_locked: float = 0.05,
) -> LockResult:
    try:
        with expath.lock.Lock(
            filename,
            timeout=timeout,
            fail_when_locked=fail_when_locked,
            flags=flags,
        ):
            time.sleep(keep_locked)
            return LockResult()

    except Exception as exception:
        # The exceptions cannot be pickled so we cannot return them through
        # multiprocessing
        return LockResult(
            type(exception),
            str(exception),
            repr(exception),
        )


@pytest.mark.parametrize("fail_when_locked", [True, False])
@pytest.mark.skipif(
    "pypy" in sys.version.lower(),
    reason="pypy3 does not support the multiprocessing test",
)
@pytest.mark.flaky(reruns=5, reruns_delay=1)
def test_shared_processes(tmpfile, fail_when_locked):
    flags = LockFlags.SHARED | LockFlags.NON_BLOCKING

    with multiprocessing.Pool(processes=2) as pool:
        args = tmpfile, fail_when_locked, flags
        results = pool.starmap_async(lock, 2 * [args])

        # sourcery skip: no-loop-in-tests
        for result in results.get(timeout=1.5):
            # sourcery skip: no-conditionals-in-tests
            if result.exception_class is not None:
                raise result.exception_class
            assert result == LockResult()


@pytest.mark.parametrize("fail_when_locked", [True, False])
@pytest.mark.parametrize("locker", LOCK_METHODS, indirect=True)
@pytest.mark.flaky(reruns=5, reruns_delay=1)
def test_exclusive_processes(
    tmpfile: str,
    fail_when_locked: bool,
    locker: typing.Callable[..., typing.Any],
) -> None:
    flags = LockFlags.EXCLUSIVE | LockFlags.NON_BLOCKING

    with multiprocessing.Pool(processes=2) as pool:
        result_a = pool.apply_async(lock, [tmpfile, fail_when_locked, flags])
        result_b = pool.apply_async(lock, [tmpfile, fail_when_locked, flags])

        try:
            a = result_a.get(timeout=1.2)
        except multiprocessing.TimeoutError:
            a = None

        try:
            b = result_b.get(timeout=0.6)
        except multiprocessing.TimeoutError:
            b = None

        assert a or b
        if a is None:
            b, a = a, b
        assert a is not None

        if b:
            assert b is not None

            assert not a.exception_class or not b.exception_class
            assert issubclass(
                a.exception_class or b.exception_class,  # type: ignore[arg-type]
                expath.lock.LockException,
            )
        else:
            assert not a.exception_class


@pytest.mark.skipif(
    os.name == "nt",
    reason="Locking on Windows requires a file object",
)
@pytest.mark.parametrize("locker", LOCK_METHODS, indirect=True)
def test_lock_fileno(tmpfile, locker):
    with open(tmpfile, "a+") as a, open(tmpfile, "a+") as b:
        # Lock shared non-blocking
        flags = LockFlags.SHARED | LockFlags.NON_BLOCKING

        # First lock file a
        expath.lock.ops.lock(a, flags)

        # Now see if we can lock using fileno()
        expath.lock.ops.lock(b.fileno(), flags)


@pytest.mark.skipif(
    os.name != "posix",
    reason="Only posix systems have different lockf behaviour",
)
@pytest.mark.parametrize("locker", LOCK_METHODS, indirect=True)
def test_locker_mechanism(tmpfile, locker):
    """Can we switch the locking mechanism?"""
    # We can test for flock vs lockf based on their different behaviour re.
    # locking the same file.
    with expath.lock.Lock(tmpfile, "a+", flags=LockFlags.EXCLUSIVE):
        # If we have lockf(), we cannot get another lock on the same file.
        if locker is fcntl.lockf:
            expath.lock.Lock(
                tmpfile,
                "r+",
                flags=LockFlags.EXCLUSIVE | LockFlags.NON_BLOCKING,
            ).acquire(timeout=0.1)
        # But with other lock methods we can't
        else:
            with pytest.raises(expath.lock.LockException):
                expath.lock.Lock(
                    tmpfile,
                    "r+",
                    flags=LockFlags.EXCLUSIVE | LockFlags.NON_BLOCKING,
                ).acquire(timeout=0.1)


def test_exception(monkeypatch, tmpfile):
    """Do we stop immediately if the locking fails, even with a timeout?"""

    def patched_lock(*args, **kwargs):
        msg = "Test exception"
        raise ValueError(msg)

    monkeypatch.setattr("expath.lock.ops.lock", patched_lock)
    lock = expath.lock.Lock(tmpfile, "w", timeout=math.inf)

    with pytest.raises(LockException):
        lock.acquire()
