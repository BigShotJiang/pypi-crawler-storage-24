import contextlib
import logging
import multiprocessing
import random

import pytest
from expath.lock import _lock

logger = logging.getLogger(__name__)


@pytest.fixture
def tmpfile(tmp_path):
    filename = tmp_path / str(random.random())[2:]
    yield str(filename)
    with contextlib.suppress(PermissionError):
        filename.unlink(missing_ok=True)


def pytest_sessionstart(session):
    multiprocessing.set_start_method("spawn")


@pytest.fixture(autouse=True)
def reduce_timeouts(monkeypatch):
    """For faster testing we reduce the timeouts."""
    monkeypatch.setattr(_lock, "DEFAULT_TIMEOUT", 0.1)
    monkeypatch.setattr(_lock, "DEFAULT_CHECK_INTERVAL", 0.05)
