import os

import expath.lock


def test_temporary_file_lock(tmpfile):
    with expath.lock.TemporaryFileLock(tmpfile):
        pass

    assert not os.path.isfile(tmpfile)

    lock = expath.lock.TemporaryFileLock(tmpfile)
    lock.acquire()
    del lock
