import os

import pytest
from expath._download import (
    download as _download,  # Import the original download function
)
from expath.handlers.http import HTTPHandler


@pytest.fixture
def mock_download(mocker, tmp_path):
    """
    Mocks the expath._download.download function to prevent actual network requests.
    Instead, it creates a dummy file with "test content" in a temporary directory.
    """
    def _mock_download_func(url, dir, filename=None, progress=True):
        if filename is None:
            filename = url.split("/")[-1]
            if os.name == "nt" and "?" in filename:  # for windows
                filename = filename[: filename.index("?")]
            assert len(filename), f"Cannot obtain filename from url {url}"

        target_dir = tmp_path / dir if isinstance(dir, str) else dir
        target_dir.mkdir(parents=True, exist_ok=True)
        fpath = target_dir / filename
        fpath.write_text("test content")
        return fpath

    mocker.patch("expath.handlers.http.download", side_effect=_mock_download_func)
    # Return the original download function in case any test needs it, though unlikely here
    return _download


@pytest.fixture
def http_handler():
    return HTTPHandler()


def test_locate(http_handler, mock_download, tmp_path):
    url = "http://mockurl.com/test.txt"
    local_path = http_handler._locate(url, cache_dir=str(tmp_path))
    assert os.path.exists(local_path)


def test_open(http_handler, mock_download, tmp_path):
    url = "http://mockurl.com/test.txt"
    with http_handler._open(url, "r", cache_dir=str(tmp_path)) as f:
        content = f.read()
    assert content is not None
    assert content == "test content"


def test_locate_force(http_handler, mock_download, tmp_path):
    url = "http://mockurl.com/test.txt"
    local_path = http_handler._locate(url, cache_dir=str(tmp_path), force=True)
    assert os.path.exists(local_path)


def test_open_binary(http_handler, mock_download, tmp_path):
    url = "http://mockurl.com/test.txt"
    with http_handler._open(url, "rb", cache_dir=str(tmp_path)) as f:
        content = f.read()
    assert content is not None
    assert content.decode() == "test content"
