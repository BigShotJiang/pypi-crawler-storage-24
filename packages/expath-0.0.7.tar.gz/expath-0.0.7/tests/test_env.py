import os
import pathlib
import tempfile

import pytest
from expath.handlers.env import EnvironPathHandler

ENV_NAME = "EXPATH_TEST_PATH"
ENV_PREFIX = "//env_handler/"


@pytest.fixture(scope="module")
def env_handler():
    """Fixture for the EnvironPathHandler."""

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = pathlib.Path(tmp_dir)
        path = tmp_path / "env_handler"
        path.mkdir(parents=True, exist_ok=True)

        (path / "test.txt").write_text("test content")

        os.environ[ENV_NAME] = str(path)

        handler = EnvironPathHandler(ENV_PREFIX, ENV_NAME)

        yield handler

        del os.environ[ENV_NAME]


def test_env_exists(env_handler):
    local_path = env_handler._locate(ENV_PREFIX + "test.txt")
    assert os.path.isfile(local_path)
