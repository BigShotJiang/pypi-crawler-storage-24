"""List the disk usage (akin to the `du -d 0 <path>` command) of a path.

Supports the prefixes registed in `unipercept.file_io`. By default, all prefixes
registered through the environment are listed.
"""

from __future__ import annotations

import argparse
from sys import stdout

from tabulate import tabulate
from tqdm import tqdm

from .registry import command

__all__ = ["du"]


@command("du")
def du(p: argparse.ArgumentParser):
    _ = p.add_argument(
        "--format",
        "-F",
        type=str,
        default="simple",
        help="Control the format of the table printed to stdout",
    )
    _ = p.add_argument(
        "--bytes",
        "-b",
        action="store_true",
        default=False,
        help="Show the amount of bytes as an integer.",
    )
    _ = p.add_argument(
        "paths",
        nargs="+",
        type=str,
        help="Paths from which to determine disk usage.",
    )

    def main(args) -> None:
        table = ((path, *_discover_stats(path, not args.bytes)) for path in args.paths)
        columns = ("path", "location", "files", "directories", "ionodes", "size")
        result = tabulate(table, tablefmt=args.format, headers=columns)
        print(result, file=stdout, flush=True)

    return main


def _to_readable(nb: float) -> str:
    """Return the given bytes as a human friendly KB, MB, GB, or TB string."""
    nb = float(nb)
    kb = float(1024)
    mb = float(kb**2)  # 1,048,576
    gb = float(kb**3)  # 1,073,741,824
    tb = float(kb**4)  # 1,099,511,627,776

    if nb < kb:
        return f"{int(nb)}"
    if kb <= nb < mb:
        return f"{nb / kb:.2f} K"
    if mb <= nb < gb:
        return f"{nb / mb:.2f} M"
    if gb <= nb < tb:
        return f"{nb / gb:.2f} G"
    if tb <= nb:
        return f"{nb / tb:.2f} T"
    raise RuntimeError()


def _discover_stats(
    path_str: str,
    human_readable: bool,
) -> tuple[str, str, str, str, str]:
    import expath  # noqa: PLC0415

    path = expath.locate(path_str)
    total_files: int = 0
    total_dirs: int = 0
    total_size: int = 0
    with tqdm(
        unit=" files",
        postfix="0 B",
        desc=f"{path_str:16s}",
    ) as prog:
        for f in path.glob("**/*"):
            if f.is_dir():
                total_dirs += 1
            else:
                total_size += f.stat().st_size
                total_files += 1

                prog.update(1)
                prog.set_postfix_str(_to_readable(total_size) + "B")
    total_nodes = total_files + total_dirs

    out_path = str(path)
    if human_readable:
        return (
            out_path,
            *map(_to_readable, (total_files, total_dirs, total_nodes)),
            (_to_readable(total_size) + "B"),
        )

    return out_path, *map(str, (total_files, total_dirs, total_nodes, total_size))
