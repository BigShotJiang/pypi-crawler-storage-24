"""Run `expath.locate` on a path."""

import argparse
from sys import stdout

from .registry import command


@command("locate")
def locate(p: argparse.ArgumentParser):
    _ = p.add_argument(
        "path",
        nargs=1,
        type=str,
        help="Paths to locate.",
    )

    def main(args) -> None:
        import expath  # noqa: PLC0415

        result = expath.locate(args.path).resolve()
        print(str(result), file=stdout, flush=True)

    return main
