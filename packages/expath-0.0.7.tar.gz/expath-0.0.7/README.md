# Expath

Standalone version of `unipercept.fileio` with support for Python 3.12.
