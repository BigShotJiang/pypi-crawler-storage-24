/// Stub implementations for WASM/non-otel builds

pub mod effect_reason {
    use crate::policy_types::ConditionEvaluationResult;
    use crate::telemetry_constants as telemetry;

    pub fn effect_reason_for_allow(result: &ConditionEvaluationResult) -> (&'static str, String) {
        match result {
            ConditionEvaluationResult::Pass => (
                telemetry::EFFECT_ALLOW,
                telemetry::EFFECT_REASON_ALLOW_MATCHED.to_string(),
            ),
            ConditionEvaluationResult::Fail => (
                telemetry::EFFECT_DENY,
                telemetry::EFFECT_REASON_ALLOW_MISMATCHED.to_string(),
            ),
            ConditionEvaluationResult::Unknown { reason } => (
                telemetry::EFFECT_UNKNOWN,
                format!("{} {}", telemetry::EVAL_FAIL_ALLOW_PREFIX, reason),
            ),
        }
    }

    pub fn effect_reason_for_deny(result: &ConditionEvaluationResult) -> (&'static str, String) {
        match result {
            ConditionEvaluationResult::Pass => (
                telemetry::EFFECT_DENY,
                telemetry::EFFECT_REASON_DENY_MATCHED.to_string(),
            ),
            ConditionEvaluationResult::Fail => (
                telemetry::EFFECT_ALLOW,
                telemetry::EFFECT_REASON_DENY_MISMATCHED.to_string(),
            ),
            ConditionEvaluationResult::Unknown { reason } => (
                telemetry::EFFECT_UNKNOWN,
                format!("{} {}", telemetry::EVAL_FAIL_DENY_PREFIX, reason),
            ),
        }
    }

    pub fn effect_reason_for_modify(result: &ConditionEvaluationResult) -> (&'static str, String) {
        match result {
            ConditionEvaluationResult::Pass => (telemetry::EFFECT_MODIFY, "".to_string()),
            ConditionEvaluationResult::Fail => (telemetry::EFFECT_NONE, "".to_string()),
            ConditionEvaluationResult::Unknown { reason } => (
                telemetry::EFFECT_UNKNOWN,
                format!("{} {}", telemetry::EVAL_FAIL_MODIFY_PREFIX, reason),
            ),
        }
    }
}

pub mod otel_manager {
    /// Stub OtelManager for non-otel builds
    #[derive(Debug, Clone)]
    pub struct OtelManager;
}

// Provide a no-op extension trait for Span when otel is disabled
use tracing::Span;

pub trait SpanExt {
    fn set_attribute<T>(&self, _key: &str, _value: T)
    where
        T: ToString;
}

impl SpanExt for Span {
    fn set_attribute<T>(&self, _key: &str, _value: T)
    where
        T: ToString,
    {
        // No-op implementation for WASM
    }
}
