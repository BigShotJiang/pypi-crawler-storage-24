use crate::auth_token::AuthToken;
use crate::otel::traces::TracerProviderManager;
use opentelemetry_sdk::trace::SdkTracerProvider;
use std::sync::Arc;

/// OtelManager owns tracer, logger, and meter providers and can refresh them when the API token changes.
#[derive(Clone, Debug)]
pub struct OtelManager {
    #[allow(dead_code)]
    auth_token: Arc<AuthToken>,
    tracer: TracerProviderManager,
}

impl OtelManager {
    /// Construct a manager with initial providers created from a token.
    pub fn create_from_token(
        initial_token: Arc<AuthToken>,
        endpoint: &str,
    ) -> anyhow::Result<Self> {
        let tracer = TracerProviderManager::create_from_token(initial_token.clone(), endpoint)?;

        Ok(Self {
            auth_token: initial_token.clone(),
            tracer,
        })
    }

    /// Getters (cloned providers)
    pub fn tracer_provider(&self) -> SdkTracerProvider {
        self.tracer.get()
    }

    pub fn shutdown(&self) {
        self.tracer.shutdown();
    }
}
