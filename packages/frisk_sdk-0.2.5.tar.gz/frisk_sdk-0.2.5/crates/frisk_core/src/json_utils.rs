pub fn json_type(value: &serde_json::Value) -> &'static str {
    match value {
        serde_json::Value::Null => "null",
        serde_json::Value::Bool(_) => "boolean",
        serde_json::Value::Number(_) => "number",
        serde_json::Value::String(_) => "string",
        serde_json::Value::Array(_) => "array",
        serde_json::Value::Object(_) => "object",
    }
}

#[cfg(test)]
mod tests {
    use super::json_type;
    use serde_json::json;

    #[test]
    fn identifies_all_json_types() {
        assert_eq!(json_type(&json!(null)), "null");
        assert_eq!(json_type(&json!(true)), "boolean");
        assert_eq!(json_type(&json!(42)), "number");
        assert_eq!(json_type(&json!("hi")), "string");
        assert_eq!(json_type(&json!([1, 2, 3])), "array");
        assert_eq!(json_type(&json!({"k": "v"})), "object");
    }
}
