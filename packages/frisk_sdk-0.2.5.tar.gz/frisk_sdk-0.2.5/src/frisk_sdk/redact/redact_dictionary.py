from dataclasses import dataclass

from .redaction_options import (
    RedactOption,
    normalize_redact_option,
    is_redact_option_falsy,
)
from .._core import redact_dictionary as core_redact_dictionary  # type: ignore


@dataclass
class RedactedDictionary:
    """Dictionary redaction output with value and matched redacted paths."""

    value: dict
    redacted_paths: list[str]


@dataclass
class RedactedSerializedObject:
    """Serialized redaction output with value and matched redacted paths."""

    value: str | None
    redacted_paths: list[str]


def redact_dictionary(
    dictionary: dict, redact: RedactOption | None
) -> RedactedDictionary:
    """Apply redaction policy to a dictionary using native core redaction."""
    normalized_redact_option = normalize_redact_option(redact)
    if is_redact_option_falsy(normalized_redact_option):
        return RedactedDictionary(value=dictionary, redacted_paths=[])

    result, redacted_paths = core_redact_dictionary(
        dictionary, normalized_redact_option
    )
    return RedactedDictionary(value=result, redacted_paths=redacted_paths)
