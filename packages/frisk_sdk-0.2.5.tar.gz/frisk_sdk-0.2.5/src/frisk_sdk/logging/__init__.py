import logging
from logging import Logger as Logger

from ..config.env_bool import env_bool
from ..config.environment_variables import FRISK_DEBUG
from .auto_enable_debug_logging import (
    auto_enable_debug_logging as auto_enable_debug_logging,
)


def get_logger(logger_name: str) -> Logger:
    """Return a logger configured for Frisk, honoring ``FRISK_DEBUG``."""
    logger = logging.getLogger(logger_name)
    if env_bool(FRISK_DEBUG):
        logger.setLevel(logging.DEBUG)
    return logger
