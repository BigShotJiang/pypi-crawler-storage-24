from __future__ import annotations

import importlib

SPAN_NAME_FRISK_SESSION = "frisk.session"
SPAN_NAME_DECIDE_TOOL_CALL = "frisk.tool_call.decide"
ATTRIBUTE_NAME_SESSION_ID = "frisk.session.id"
ATTRIBUTE_NAME_REMOTE_SESSION_ID = "frisk.session.remote_id"
ATTRIBUTE_NAME_SESSION_PROMPT = "frisk.session.prompt"
ATTRIBUTE_NAME_LLM_REASONING = "frisk.llm_reasoning"
ATTRIBUTE_NAME_TOOL_NAME = "frisk.tool.name"
ATTRIBUTE_NAME_TOOL_CALL_ID = "frisk.tool_call.id"
ATTRIBUTE_NAME_TOOL_ARGS_JSON = "frisk.tool.args.json"
ATTRIBUTE_NAME_TOOL_ARGS_REDACTED_PATHS_JSON = "frisk.tool.args_redacted_paths.json"
ATTRIBUTE_NAME_AGENT_STATE_JSON = "frisk.agent_state.json"
ATTRIBUTE_NAME_AGENT_STATE_REDACTED_PATHS_JSON = "frisk.agent_state_redacted_paths.json"
ATTRIBUTE_NAME_DECISION_MATCHED_RULE_COUNT = "frisk.decision.matched_rule_count"
ATTRIBUTE_NAME_DECISION_OUTCOME = "frisk.decision.outcome"
ATTRIBUTE_NAME_DECISION_REASON = "frisk.decision.reason"
ATTRIBUTE_NAME_ERROR_TYPE = "error.type"
ATTRIBUTE_NAME_ERROR_MESSAGE = "error.message"
ATTRIBUTE_NAME_LATENCY_NS = "latency_ns"

TRACER_NAME = "frisk_python_sdk"
TRACER_VERSION = importlib.metadata.version("frisk-sdk")
