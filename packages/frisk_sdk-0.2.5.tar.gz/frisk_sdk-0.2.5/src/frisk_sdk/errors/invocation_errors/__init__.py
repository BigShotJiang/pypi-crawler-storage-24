from ..frisk_error import FriskError


class ToolCallEvaluationError(FriskError):
    """Wraps unexpected exceptions raised during tool-call evaluation."""

    code = "tool_call_evaluation_failed"

    def __init__(self, original_error: Exception):
        self.original_error = original_error
        self.message = f"""\
An error occurred while evaluating the tool call.
    The tool call will be allowed by default.

    Original error:
        {original_error}\
"""
        super().__init__()


class FriskInvocationError(FriskError):
    """Raised when the SDK is used incorrectly at runtime."""


class MissingFriskSessionContextError(FriskInvocationError):
    """Raised when required ``frisk_session_id`` context is absent at invocation time."""

    code = "missing_frisk_session_context"
    message = """\
Missing required Frisk execution context.
    Frisk requires a `context` object containing a valid `frisk_session_id`
    to be passed when invoking an agent.

    Please ensure your agent invocation includes:
        context=session.context

    Example:
        frisk = Frisk()
        session = frisk.session()
        agent.invoke(
            inputs,
            config={...},
            context=session.context,
        )

    This context is required for policy enforcement, tracing,
    and tool-call governance.\
"""


class InvalidFriskSessionError(FriskInvocationError):
    """Raised when ``frisk_session_id`` is malformed or cannot be resolved."""

    code = "invalid_frisk_session"
    message = """\
Invalid Frisk session ID provided.
    A `frisk_session_id` was found in the execution context, but it is not a valid UUID.

    Please ensure you are passing a valid session ID:
    
    Example:
        frisk = Frisk()
        session = frisk.session()
        agent.invoke(
            inputs,
            config={...},
            context=session.context,
        )
"""
