from typing import Any

STATE_FILTER_KEYS = {
    "frisk_session_id",
    "agent",
    "event_loop_cycle_id",
    "event_loop_cycle_span",
    "event_loop_cycle_trace",
    "messages",
    "model",
    "request_state",
    "system_prompt",
    "tool_config",
}


def filter_state(state: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in state.items() if k not in STATE_FILTER_KEYS}
