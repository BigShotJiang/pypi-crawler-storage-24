from typing import TypeVar

T = TypeVar("T")


def find_last_match(items: list[T], predicate) -> T | None:
    """Return the last item matching ``predicate`` or ``None`` if no match exists."""
    # Iterate in reverse order using a reversed range of indices
    for i in range(len(items) - 1, -1, -1):
        if predicate(items[i]):
            return items[i]
    return None
