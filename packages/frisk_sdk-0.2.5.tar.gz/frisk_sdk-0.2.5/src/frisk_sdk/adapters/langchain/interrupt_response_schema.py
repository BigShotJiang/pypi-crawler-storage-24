from __future__ import annotations

from enum import Enum
from typing import TypeAlias, Optional


# A typed view of the response expected from the `interrupt()` call.
# tool_call_id -> action ('retry' | 'cancel')
class ToolCallResumeAction(str, Enum):
    Retry = "retry"
    Cancel = "cancel"


InterruptResponseSchema: TypeAlias = dict[str, ToolCallResumeAction]

InterruptResponseInputSchema: TypeAlias = dict[str, Optional[str]]

interrupt_response_schema = {
    "type": ["object"],
    "description": (
        "JSON object mapping tool_call_id to an action. Valid action options are 'retry' and 'cancel'. "
        "Each tool_call_id is optional; a tool_call_id that is omitted, or mapped explicitly to null, is equivalent to 'retry'."
    ),
    "additionalProperties": {
        "description": (
            "Action for this tool call. Use 'retry' to proceed, 'cancel' to cancel. `null` is equivalent to 'retry'."
        ),
        "type": ["string", "null"],
        "enum": ["retry", "cancel", None],
    },
}
