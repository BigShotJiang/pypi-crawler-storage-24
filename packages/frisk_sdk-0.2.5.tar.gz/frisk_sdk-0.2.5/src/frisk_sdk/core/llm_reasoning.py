from __future__ import annotations

from typing import Any

LLM_REASONING_ARG_NAME = "frisk__llm_reasoning"


def remove_llm_reasoning_arg(
    wrapped_tool_args: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if not wrapped_tool_args:
        return wrapped_tool_args

    """Return tool args without the synthetic LLM reasoning argument."""
    return {k: v for k, v in wrapped_tool_args.items() if k != LLM_REASONING_ARG_NAME}
