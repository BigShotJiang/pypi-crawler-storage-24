from dataclasses import is_dataclass, asdict
from typing import Any, cast


def normalize_object_to_dictionary(obj: Any) -> dict[str, Any]:
    """Normalize dataclass/mapping/object inputs into a plain dictionary."""
    if not isinstance(obj, type) and is_dataclass(obj):
        return asdict(cast(Any, obj))

    if isinstance(obj, dict):
        return dict(obj)

    if hasattr(obj, "__dict__"):
        return dict(vars(obj))

    raise TypeError(f"Cannot normalize object of type {type(obj).__name__}")
