from .normalize_object_to_dictionary import (
    normalize_object_to_dictionary as normalize_object_to_dictionary,
)
