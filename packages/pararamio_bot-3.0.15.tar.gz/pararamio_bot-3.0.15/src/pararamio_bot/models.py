"""Pydantic models for pararam.io bot webhook payloads."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

__all__ = ('WebhookAction', 'WebhookMessage')


class WebhookMessage(BaseModel):
    """Incoming message webhook payload from pararam.io."""

    user_id: int
    user_unique_name: str
    post_no: int
    chat_id: int
    organization_id: int | None = None
    text: str
    text_parsed: list[dict[str, Any]] | None = None
    reply_no: int | None = None
    reply_text: str | None = None
    file_guid: str | None = None
    file_name: str | None = None
    attachments: list[str] | None = None


class WebhookAction(BaseModel):
    """Bot action webhook payload (user clicked bot:// link)."""

    user_id: int
    chat_id: int
    post_no: int
    organization_id: int | None = None
    action: str
    params: dict[str, str]
