"""Type aliases for webhook callbacks."""

from __future__ import annotations

from collections.abc import Awaitable, Callable

from pararamio_bot.models import WebhookAction, WebhookMessage

__all__ = ('ActionCallback', 'MessageCallback')

MessageCallback = Callable[[WebhookMessage], Awaitable[str | None]]
ActionCallback = Callable[[WebhookAction], Awaitable[str | None]]
