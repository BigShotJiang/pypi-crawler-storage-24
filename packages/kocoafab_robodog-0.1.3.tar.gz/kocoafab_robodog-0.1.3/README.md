# kocoafab-robodog

`kocoafab-robodog` is a Python package for controlling RoboDog Bigeye.

## Install

```bash
pip install kocoafab-robodog
```

## Overview

This package provides Python APIs for controlling RoboDog Bigeye, including movement, LED, sound, and sensor features.

## Quick Start

```python
from kocoafab_robodog import *

dog = RoboDog()
dog.Open("None")
```
