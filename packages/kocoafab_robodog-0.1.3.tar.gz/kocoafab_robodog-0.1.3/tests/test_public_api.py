import importlib.util
import sys
import unittest
from pathlib import Path


def load_package():
    package_dir = Path(__file__).resolve().parents[1] / "kocoafab-robodog"
    init_py = package_dir / "__init__.py"
    spec = importlib.util.spec_from_file_location(
        "kocoafab_robodog",
        init_py,
        submodule_search_locations=[str(package_dir)],
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class PublicApiTest(unittest.TestCase):
    def test_package_root_re_exports_robodog_and_deflib_symbols(self):
        package = load_package()

        self.assertTrue(hasattr(package, "RoboDog"))
        self.assertEqual("kocoafab_robodog.robodog", package.RoboDog.__module__)
        self.assertEqual("forward", package.FORWARD)


if __name__ == "__main__":
    unittest.main()
