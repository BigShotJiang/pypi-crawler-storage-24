import unittest
from pathlib import Path


class SimpleTestRunnerFilesTest(unittest.TestCase):
    def test_simple_test_imports_package_root(self):
        workspace_root = Path(__file__).resolve().parents[2]
        simple_test = workspace_root / "python" / "2차시_눈을뜨다" / "simpleTest.py"
        source = simple_test.read_text(encoding="utf-8")

        self.assertIn("from kocoafab_robodog import *", source)
        self.assertNotIn("from kocoafab_robodog.robodog import RoboDog", source)
        self.assertNotIn("from kocoafab_robodog.deflib import *", source)

    def test_powershell_runner_exists_for_local_package_test(self):
        workspace_root = Path(__file__).resolve().parents[2]
        runner = workspace_root / "python" / "2차시_눈을뜨다" / "run_simpleTest_local_package.ps1"
        source = runner.read_text(encoding="utf-8")

        self.assertIn("python -m build --wheel", source)
        self.assertIn("simpleTest.py", source)
        self.assertIn(".venv-simpletest-local", source)
        self.assertIn("--force-reinstall", source)


if __name__ == "__main__":
    unittest.main()
