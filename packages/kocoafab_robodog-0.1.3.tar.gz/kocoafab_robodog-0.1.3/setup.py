from setuptools import setup


setup(
    name="kocoafab-robodog",
    version="0.1.3",
    description="Python package for controlling Kocoafab RoboDog Bigeye.",
    long_description_content_type="text/markdown",
    author="Kocoafab",
    author_email="kocoafab@kocoa.or.kr",
    packages=["kocoafab_robodog"],
    package_dir={"kocoafab_robodog": "kocoafab-robodog"},
    install_requires=["pyserial>=3.5"],
    url="https://kocoafab.cc",
    python_requires=">=3.8",
    keywords=[
        "kocoafab",
        "robodog",
        "bigeye"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    zip_safe=False,
)
