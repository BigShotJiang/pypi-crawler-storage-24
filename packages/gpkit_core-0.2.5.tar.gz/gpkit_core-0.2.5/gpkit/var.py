"Implements the Var class-level variable descriptor"

from typing import overload

from .nomials.variables import Variable

_RESERVED_NAMES = frozenset(
    {"cost", "lineage", "setup", "substitutions", "unique_varkeys", "vks"}
)


class Var:  # pylint: disable=too-few-public-methods
    """Class-level variable declaration for Model subclasses.

    Usage
    -----
        class Wing(Model):
            W = Var("lbf", "wing weight")
            S = Var("ft^2", "wing area")
            A = Var("-", "aspect ratio", value=27)

            def setup(self):
                return [self.W >= self.S * self.rho]

    Notes
    -----
    - Lineage is correct because _create() runs inside NamedVariables context.
    - Reserved names (cost, lineage, setup, substitutions, unique_varkeys, vks)
      and names starting with '_var_' cannot be used.
    - For vector variables whose length comes from a setup() argument, use
      Vectorize inside setup() with Variable() directly.
    - Flat (script-form) models should use Variable() directly.
    - When a Model subclass is instantiated inside a Vectorize(N) context, all
      Var descriptors automatically become N-element vector variables.
    """

    def __init__(self, units: str, label: str = "", *, value=None, latex: str = None):
        self.units = units
        self.label = label
        self.value = value
        self.latex = latex
        self._name: str | None = None

    def __set_name__(self, owner, name):
        if name.startswith("_var_") or name in _RESERVED_NAMES:
            raise ValueError(
                f"Var name '{name}' is reserved. "
                f"Reserved names: {sorted(_RESERVED_NAMES)} "
                f"and any name starting with '_var_'."
            )
        self._name = name

    @overload
    def __get__(self, obj: None, objtype: type) -> "Var": ...

    @overload
    def __get__(self, obj: object, objtype: type) -> "Variable": ...

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return obj.__dict__.get(f"_var_{self._name}")

    def _create(self, obj):
        """Create the Variable instance on obj, inside a NamedVariables context."""
        key = f"_var_{self._name}"
        if key in obj.__dict__:
            raise RuntimeError(
                f"Variable '{self._name}' already initialized on {obj!r}. "
                "Possible duplicate Var declarations in the MRO."
            )
        args = [self._name]
        if self.value is not None:
            args.append(self.value)
        args.extend([self.units, self.label])
        v = Variable(*args)
        obj.__dict__[key] = v
        return v
