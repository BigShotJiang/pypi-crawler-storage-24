"""LogRecord dataclass representing an OpenTelemetry log entry."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

# AnyValue type: string, int, float, bool, list, dict, or None
AnyValue = Union[str, int, float, bool, List[Any], Dict[str, Any], None]

VALID_SEVERITY_TEXTS = frozenset({"TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"})

DEFAULT_SERVICE_NAME = "unknown_service"


@dataclass
class LogRecord:
    """Canonical in-memory representation of an OTel log entry.

    Fields align with the OpenTelemetry Log Data Model and the
    Standard Log Format JSON schema.
    """

    severity_text: str = "INFO"
    severity_number: int = 9
    body: Any = ""
    resource: Dict[str, AnyValue] = field(default_factory=lambda: {"service.name": DEFAULT_SERVICE_NAME})
    timestamp: Optional[datetime] = None
    observed_timestamp: Optional[datetime] = None
    instrumentation_scope: Optional[Dict[str, str]] = None
    attributes: Optional[Dict[str, AnyValue]] = None
    trace_id: Optional[str] = None
    span_id: Optional[str] = None
    trace_flags: Optional[str] = None
    event_name: Optional[str] = None
