from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "qwen/qwen3-32b"   # change here if needed



def keshav(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = keshav(user_prompt)
    print("\nLLM:", answer, "\n")