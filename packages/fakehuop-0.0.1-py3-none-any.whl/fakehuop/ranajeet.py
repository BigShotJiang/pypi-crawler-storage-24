from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "qwen/qwen3-32b"   # change here if needed



def ranajeet(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = ranajeet(user_prompt)
    print("\nLLM:", answer, "\n")