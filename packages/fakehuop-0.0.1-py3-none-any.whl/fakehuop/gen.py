def linear_regression():
    print('''
# numpy is used for numerical operations like arrays and square root
import numpy as np

# pandas is used for handling datasets in table format (DataFrame)
import pandas as pd

# train_test_split is used to divide the dataset into training and testing sets
from sklearn.model_selection import train_test_split

# LinearRegression is the machine learning model we will use
from sklearn.linear_model import LinearRegression

# metrics contains functions to evaluate model performance
from sklearn import metrics


# ------------------------------
# STEP 1: Create Dataset
# ------------------------------

# We create a simple dataset manually
# Hours = number of hours studied
# Scores = exam scores obtained

data = {
    "Hours": [1,2,3,4,5,6,7,8,9,10],
    "Scores": [10,20,30,40,52,60,70,80,90,95]
}

# Convert dictionary into pandas DataFrame (table structure)
df = pd.DataFrame(data)

print("Dataset")
print(df)


# ------------------------------
# STEP 2: Define Features and Target
# ------------------------------

# X = input variable (feature)
# We use double brackets because sklearn expects a 2D array

X = df[["Hours"]]

# y = target variable (what we want to predict)

y = df["Scores"]

print("\nFeatures (X)")
print(X)

print("\nTarget (y)")
print(y)


# ------------------------------
# STEP 3: Split Data into Train and Test
# ------------------------------

# train_test_split splits the dataset into two parts:
# training data -> model learns from this
# testing data -> used to evaluate the model

# test_size=0.2 means 20% data will be used for testing
# random_state=42 ensures same split every time we run code

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

print("\nTraining Features")
print(X_train)

print("\nTesting Features")
print(X_test)


# ------------------------------
# STEP 4: Create Linear Regression Model
# ------------------------------

# LinearRegression() creates a regression model object
# The model tries to learn a linear relationship:
# y = mx + b

model = LinearRegression()


# ------------------------------
# STEP 5: Train the Model
# ------------------------------

# fit() trains the model using training data
# It calculates best slope (m) and intercept (b)

model.fit(X_train, y_train)

print("\nModel Training Completed")

# slope of line
print("Coefficient (m):", model.coef_)

# intercept of line
print("Intercept (b):", model.intercept_)


# ------------------------------
# STEP 6: Predict Values
# ------------------------------

# predict() uses the trained model to predict output for test data

y_pred = model.predict(X_test)

print("\nPredicted Values")
print(y_pred)

print("\nActual Values")
print(y_test.values)


# ------------------------------
# STEP 7: Evaluate Model Accuracy
# ------------------------------

# Mean Absolute Error (MAE)
# Average absolute difference between predicted and actual values

mae = metrics.mean_absolute_error(y_test, y_pred)

# Mean Squared Error (MSE)
# Average of squared differences between predicted and actual values

mse = metrics.mean_squared_error(y_test, y_pred)

# Root Mean Squared Error (RMSE)
# Square root of MSE (same unit as original data)

rmse = np.sqrt(mse)

# R² Score
# Measures how well the model explains variance
# Range: 0 to 1 (1 = perfect model)

r2 = metrics.r2_score(y_test, y_pred)


print("\nModel Evaluation Metrics")

print("Mean Absolute Error:", mae)
print("Mean Squared Error:", mse)
print("Root Mean Squared Error:", rmse)
print("R2 Score:", r2)


# ------------------------------
# STEP 8: Predict New Data
# ------------------------------

# Predict score for 12 hours study

hours = np.array([[12]])

predicted_score = model.predict(hours)

print("\nPrediction for 12 hours of study")
print("Predicted Score:", predicted_score)
    ''')

def logistic_regression():
    print('''
# numpy is used for numerical operations
import numpy as np

# pandas is used to handle datasets in table format
import pandas as pd

# train_test_split is used to divide the dataset into training and testing sets
from sklearn.model_selection import train_test_split

# LogisticRegression is the classification model
from sklearn.linear_model import LogisticRegression

# metrics contains functions to evaluate classification models
from sklearn import metrics


# ------------------------------
# STEP 1: Create Dataset
# ------------------------------

# Hours studied vs Pass/Fail exam
# 0 = Fail
# 1 = Pass

data = {
    "Hours": [1,2,3,4,5,6,7,8,9,10],
    "Pass":  [0,0,0,0,1,1,1,1,1,1]
}

df = pd.DataFrame(data)

print("Dataset")
print(df)


# ------------------------------
# STEP 2: Define Features and Target
# ------------------------------

# X = input feature
X = df[["Hours"]]

# y = output label (classification target)
y = df["Pass"]

print("\nFeatures (X)")
print(X)

print("\nTarget (y)")
print(y)


# ------------------------------
# STEP 3: Split Dataset
# ------------------------------

# 80% training
# 20% testing

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

print("\nTraining Data")
print(X_train)

print("\nTesting Data")
print(X_test)


# ------------------------------
# STEP 4: Create Logistic Regression Model
# ------------------------------

# LogisticRegression() creates classification model
# It uses the sigmoid function

model = LogisticRegression()


# ------------------------------
# STEP 5: Train the Model
# ------------------------------

# fit() trains the model using training data

model.fit(X_train, y_train)

print("\nModel Training Completed")


# ------------------------------
# STEP 6: Predict Class
# ------------------------------

# predict() predicts class labels (0 or 1)

y_pred = model.predict(X_test)

print("\nPredicted Classes")
print(y_pred)

print("\nActual Classes")
print(y_test.values)


# ------------------------------
# STEP 7: Predict Probability
# ------------------------------

# predict_proba() gives probability of each class

prob = model.predict_proba(X_test)

print("\nPrediction Probabilities")
print(prob)


# ------------------------------
# STEP 8: Evaluate Model
# ------------------------------

# Accuracy = correct predictions / total predictions

accuracy = metrics.accuracy_score(y_test, y_pred)

# Confusion Matrix
# Shows correct and incorrect predictions

conf_matrix = metrics.confusion_matrix(y_test, y_pred)

# Classification Report
# Includes precision, recall, F1 score

report = metrics.classification_report(y_test, y_pred)

print("\nAccuracy:", accuracy)

print("\nConfusion Matrix")
print(conf_matrix)

print("\nClassification Report")
print(report)


# ------------------------------
# STEP 9: Predict New Data
# ------------------------------

# Predict if a student who studies 7 hours will pass

hours = np.array([[7]])

prediction = model.predict(hours)

print("\nPrediction for 7 hours study")
print("Pass (1) or Fail (0):", prediction)
    ''')

def desicion_tree(name):
    print('''
# numpy for numerical operations
import numpy as np

# pandas for dataset handling
import pandas as pd

# split dataset into training and testing sets
from sklearn.model_selection import train_test_split

# Decision Tree model
from sklearn.tree import DecisionTreeClassifier

# metrics for evaluating model performance
from sklearn import metrics


# ------------------------------
# STEP 1: Create Dataset
# ------------------------------

# Example dataset
# Hours studied vs Pass/Fail exam

data = {
    "Hours": [1,2,3,4,5,6,7,8,9,10],
    "Pass":  [0,0,0,0,1,1,1,1,1,1]
}

df = pd.DataFrame(data)

print("Dataset")
print(df)


# ------------------------------
# STEP 2: Define Features and Target
# ------------------------------

# X = feature (input)
X = df[["Hours"]]

# y = label (output)
y = df["Pass"]

print("\nFeatures")
print(X)

print("\nTarget")
print(y)


# ------------------------------
# STEP 3: Train Test Split
# ------------------------------

# Split dataset into training and testing data

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

print("\nTraining Data")
print(X_train)

print("\nTesting Data")
print(X_test)


# ------------------------------
# STEP 4: Create Decision Tree Model
# ------------------------------

# DecisionTreeClassifier creates the tree model

model = DecisionTreeClassifier()

# parameters can also be added
# DecisionTreeClassifier(max_depth=3)


# ------------------------------
# STEP 5: Train Model
# ------------------------------

# fit() trains the model

model.fit(X_train, y_train)

print("\nModel Training Completed")


# ------------------------------
# STEP 6: Predict
# ------------------------------

# predict() predicts class label

y_pred = model.predict(X_test)

print("\nPredicted Values")
print(y_pred)

print("\nActual Values")
print(y_test.values)


# ------------------------------
# STEP 7: Evaluate Model
# ------------------------------

# Accuracy
accuracy = metrics.accuracy_score(y_test, y_pred)

# Confusion Matrix
conf_matrix = metrics.confusion_matrix(y_test, y_pred)

# Classification Report
report = metrics.classification_report(y_test, y_pred)

print("\nAccuracy:", accuracy)

print("\nConfusion Matrix")
print(conf_matrix)

print("\nClassification Report")
print(report)


# ------------------------------
# STEP 8: Predict New Data
# ------------------------------

# Predict pass/fail for 7 hours study

hours = np.array([[7]])

prediction = model.predict(hours)

print("\nPrediction for 7 hours study")
print("Pass (1) or Fail (0):", prediction)
    ''')


