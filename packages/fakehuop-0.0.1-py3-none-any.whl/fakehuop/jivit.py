from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "qwen/qwen3-32b"   # change here if needed



def jivit(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = jivit(user_prompt)
    print("\nLLM:", answer, "\n")