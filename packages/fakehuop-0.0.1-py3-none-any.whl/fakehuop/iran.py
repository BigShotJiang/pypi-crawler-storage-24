from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def iran(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = iran(user_prompt)
    print("\nLLM:", answer, "\n")