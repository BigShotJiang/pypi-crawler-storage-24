# from .gen import linear_regression, logistic_regression
from .ai_helper import ask_llm
from .abhijeet import abhijeet
from .america  import america
from .iran import iran
from .jivit import jivit

from .narendra import narendra
from .keshav import keshav
from .mayank import mayank
from .ranajeet import ranajeet
from .pranav import pranav

__all__ = ["ask_llm", "abhijeet", "america", "iran", "jivit", "narendra", "keshav", "mayank", "ranajeet", "pranav"]