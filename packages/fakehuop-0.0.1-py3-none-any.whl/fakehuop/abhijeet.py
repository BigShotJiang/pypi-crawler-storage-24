from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "qwen/qwen3-32b"   # change here if needed



def abhijeet(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = abhijeet(user_prompt)
    print("\nLLM:", answer, "\n")