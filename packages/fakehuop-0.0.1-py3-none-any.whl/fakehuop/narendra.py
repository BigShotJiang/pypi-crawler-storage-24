from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "qwen/qwen3-32b"   # change here if needed



def narendra(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = narendra(user_prompt)
    print("\nLLM:", answer, "\n")