
from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "qwen/qwen3-32b"   # change here if needed



def mayank(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = mayank(user_prompt)
    print("\nLLM:", answer, "\n")