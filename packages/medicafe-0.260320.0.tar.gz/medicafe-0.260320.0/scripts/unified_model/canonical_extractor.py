#!/usr/bin/env python
"""
Phase D canonical extraction: build extracted_canonical_record and domain upsert payloads
from QA-pass rows. Deterministic keys. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    CANONICALIZATION_VERSION,
    compute_canonical_key,
    compute_claim_key,
    compute_claim_line_key,
    compute_coverage_key,
    compute_encounter_key,
    compute_insurance_plan_key,
    compute_patient_key,
    compute_payer_key,
)
from patient_field_mapper import (
    extract_birth_date,
    extract_external_patient_id,
    extract_full_name,
    is_valid_external_patient_id_5_digit,
)


def _provenance_base(artifact_id, artifact_class, source_system, source_ref):
    """Build base provenance dict."""
    return {
        "artifact_id": artifact_id,
        "artifact_class": artifact_class,
        "source_system": source_system or "",
        "source_ref": source_ref or "",
        "extractor_version": CANONICALIZATION_VERSION,
    }


def extract_canonical_records(artifact_id, artifact_class, envelope, source_system, source_ref):
    """
    Extract canonical records from QA-pass envelope.
    Returns list of dicts: {canonical_type, canonical_key, canonical_json, provenance_json}.
    """
    records = []
    prov_base = _provenance_base(artifact_id, artifact_class, source_system, source_ref)

    if artifact_class == "csv" and envelope:
        rows = envelope.get("rows") or []
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            patient_id = extract_external_patient_id(row)
            birth_date = extract_birth_date(row)
            patient_key = compute_patient_key(source_system or "xp_local", patient_id, birth_date)
            canonical_json = json.dumps(row, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, row_index=i)
            records.append({
                "canonical_type": "patient_csv_row",
                "canonical_key": patient_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "jsonl" and envelope:
        rows = envelope.get("rows") or []
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            claim_num = row.get("claim_number") or row.get("Claim #") or ""
            payer_id = row.get("payer_id") or row.get("Payer ID") or ""
            claim_key = compute_canonical_key([claim_num, payer_id, str(i)])
            canonical_json = json.dumps(row, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, row_index=i)
            records.append({
                "canonical_type": "remittance_row",
                "canonical_key": claim_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "837" and envelope:
        member_id = envelope.get("member_id") or ""
        member_dob = envelope.get("member_dob") or ""
        payer_id = envelope.get("payer_id") or ""
        patient_key = compute_patient_key(source_system or "xp_local", member_id, member_dob)
        canonical_json = json.dumps(envelope, separators=(",", ":"), ensure_ascii=True)
        records.append({
            "canonical_type": "x12_member",
            "canonical_key": patient_key,
            "canonical_json": canonical_json,
            "provenance_json": json.dumps(prov_base, separators=(",", ":"), ensure_ascii=True),
        })

    elif artifact_class == "dat" and envelope:
        recs = envelope.get("records") or []
        for i, rec in enumerate(recs):
            if not isinstance(rec, dict):
                continue
            pat_id = rec.get("PATID") or rec.get("patient_id") or ""
            patient_key = compute_patient_key(source_system or "xp_local", pat_id, "")
            canonical_json = json.dumps(rec, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, record_index=i)
            records.append({
                "canonical_type": "dat_record",
                "canonical_key": patient_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "docx" and envelope:
        schedules = envelope.get("schedules") or {}
        patient_data = envelope.get("patient_data") or {}
        if schedules:
            for date_str, patients_dict in schedules.items():
                if not isinstance(patients_dict, dict):
                    continue
                for patient_id, details in patients_dict.items():
                    canonical_json = json.dumps(
                        details if isinstance(details, dict) else {"data": details},
                        separators=(",", ":"), ensure_ascii=True
                    )
                    patient_key = compute_patient_key(source_system or "xp_local", str(patient_id), "")
                    prov = dict(prov_base, schedule_key=date_str, patient_id=str(patient_id))
                    records.append({
                        "canonical_type": "docx_schedule",
                        "canonical_key": compute_canonical_key([patient_key, date_str or ""]),
                        "canonical_json": canonical_json,
                        "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
                    })
        elif patient_data:
            for patient_id, dates_dict in patient_data.items():
                if not isinstance(dates_dict, dict):
                    continue
                for date_str, details in dates_dict.items():
                    canonical_json = json.dumps(
                        details if isinstance(details, dict) else {"data": details},
                        separators=(",", ":"), ensure_ascii=True
                    )
                    patient_key = compute_patient_key(source_system or "xp_local", str(patient_id), "")
                    prov = dict(prov_base, schedule_key=date_str, patient_id=str(patient_id))
                    records.append({
                        "canonical_type": "docx_schedule",
                        "canonical_key": compute_canonical_key([patient_key, date_str or ""]),
                        "canonical_json": canonical_json,
                        "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
                    })

    if not records:
        prov_base["note"] = "minimal_artifact_summary"
        records.append({
            "canonical_type": "artifact_summary",
            "canonical_key": compute_patient_key(source_system or "xp_local", str(artifact_id), ""),
            "canonical_json": json.dumps({"artifact_class": artifact_class}, separators=(",", ":"), ensure_ascii=True),
            "provenance_json": json.dumps(prov_base, separators=(",", ":"), ensure_ascii=True),
        })

    return records


def build_domain_upserts(canonical_records, artifact_id, source_system, entity_scope="v1"):
    """
    Build domain upsert payloads from canonical records.
    Returns dict: {patient: [...], payer: [...], ...}.
    v1: patient from patient_csv_row and x12_member.
    v2: adds payer/plan/coverage/encounter/claim/claim_line from remittance_row and dat_record (PHASE_D_V2_ENTITY_UPSERT_SPEC subset).
    """
    # TODO(theme5): Extend v2 payloads per PHASE_D_V2_ENTITY_UPSERT_SPEC.md §4 for remaining
    # canonical types (e.g. x12_member + remittance composition, docx_schedule) and align field
    # aliases with production column names; see spec "Implementation status".
    entity_scope = str(entity_scope or "v1").strip().lower()
    if entity_scope not in ("v1", "v2"):
        entity_scope = "v1"
    upserts = {
        "patient": [],
        "payer": [],
        "insurance_plan": [],
        "coverage": [],
        "encounter": [],
        "claim": [],
        "claim_line": [],
    }
    seen_patients = set()
    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        cjson = rec.get("canonical_json") or "{}"
        try:
            data = json.loads(cjson)
        except (ValueError, TypeError):
            continue
        if ctype == "patient_csv_row" and isinstance(data, dict):
            patient_id = extract_external_patient_id(data)
            birth_date = extract_birth_date(data)
            full_name = extract_full_name(data)
            pk = compute_patient_key(source_system or "xp_local", patient_id, birth_date)
            if pk and pk not in seen_patients:
                seen_patients.add(pk)
                upserts["patient"].append({
                    "artifact_id": artifact_id,
                    "patient_key": pk,
                    "external_patient_id": patient_id,
                    "full_name": full_name,
                    "birth_date": birth_date,
                    "source_system": source_system or "xp_local",
                })
        elif ctype == "x12_member" and isinstance(data, dict):
            member_id = data.get("member_id") or ""
            dob = data.get("member_dob") or ""
            first_name = data.get("member_first_name") or ""
            last_name = data.get("member_last_name") or ""
            full_name = (first_name + " " + last_name).strip() or None
            pk = compute_patient_key(source_system or "xp_local", member_id, dob)
            if pk and pk not in seen_patients:
                seen_patients.add(pk)
                upserts["patient"].append({
                    "artifact_id": artifact_id,
                    "patient_key": pk,
                    "external_patient_id": member_id,
                    "full_name": full_name,
                    "birth_date": dob,
                    "source_system": source_system or "xp_local",
                })
        elif entity_scope == "v2" and ctype == "dat_record" and isinstance(data, dict):
            patient_id = str(data.get("PATID") or data.get("patient_id") or extract_external_patient_id(data) or "")
            birth_date = extract_birth_date(data) or ""
            full_name = extract_full_name(data)
            if is_valid_external_patient_id_5_digit(patient_id):
                pk = compute_patient_key(source_system or "xp_local", patient_id, birth_date)
                if pk and pk not in seen_patients:
                    seen_patients.add(pk)
                    upserts["patient"].append({
                        "artifact_id": artifact_id,
                        "patient_key": pk,
                        "external_patient_id": patient_id,
                        "full_name": full_name,
                        "birth_date": birth_date,
                        "source_system": source_system or "xp_local",
                    })
                ins_raw = str(data.get("INSID") or data.get("insurance_id") or "").strip()
                dos = str(data.get("DATE1") or data.get("date_of_service") or "").strip()
                if ins_raw and pk:
                    endpoint = str(source_system or "xp_local")
                    pay_key = compute_payer_key(ins_raw, endpoint)
                    upserts["payer"].append({
                        "artifact_id": artifact_id,
                        "payer_key": pay_key,
                        "payer_external_id": ins_raw,
                        "payer_name": None,
                        "endpoint_name": endpoint,
                    })
                    plan_ids_json = json.dumps([], separators=(",", ":"), ensure_ascii=True)
                    plan_key = compute_insurance_plan_key(pay_key, plan_ids_json)
                    upserts["insurance_plan"].append({
                        "artifact_id": artifact_id,
                        "plan_key": plan_key,
                        "payer_key": pay_key,
                        "medisoft_insurance_ids_json": plan_ids_json,
                    })
                    if dos:
                        cov_key = compute_coverage_key(pk, plan_key, dos)
                        upserts["coverage"].append({
                            "artifact_id": artifact_id,
                            "coverage_key": cov_key,
                            "patient_key": pk,
                            "plan_key": plan_key,
                            "effective_start": dos,
                            "effective_end": None,
                            "active_flag": 1,
                        })
                        enc_key = compute_encounter_key(pk, dos, artifact_id)
                        upserts["encounter"].append({
                            "artifact_id": artifact_id,
                            "encounter_key": enc_key,
                            "patient_key": pk,
                            "date_of_service": dos,
                            "source_artifact_id": artifact_id,
                            "diagnosis_code": str(data.get("DIAG") or "") or None,
                            "eye_side": str(data.get("EYE") or "") or None,
                        })
                        claim_num = str(data.get("claim_number") or data.get("CLAIM") or "").strip()
                        cl_key = compute_claim_key(enc_key, pay_key, claim_num)
                        upserts["claim"].append({
                            "artifact_id": artifact_id,
                            "claim_key": cl_key,
                            "encounter_key": enc_key,
                            "payer_key": pay_key,
                            "claim_number": claim_num or None,
                            "status": None,
                            "charged_amount": None,
                            "allowed_amount": None,
                            "paid_amount": None,
                            "patient_resp_amount": None,
                            "source_artifact_id": artifact_id,
                        })
                        line_key = compute_claim_line_key(cl_key, 1)
                        upserts["claim_line"].append({
                            "artifact_id": artifact_id,
                            "claim_line_key": line_key,
                            "claim_key": cl_key,
                            "line_number": 1,
                            "cpt_code": str(data.get("CPT") or data.get("cpt") or "") or None,
                            "diagnosis_pointer": None,
                            "charged_amount": None,
                            "paid_amount": None,
                        })
        elif entity_scope == "v2" and ctype == "remittance_row" and isinstance(data, dict):
            endpoint = str(source_system or "xp_local")
            payer_ext = str(data.get("payer_id") or data.get("Payer ID") or "").strip()
            payer_name = str(data.get("payer_name") or data.get("Payer Name") or "").strip() or None
            if payer_ext:
                pay_key = compute_payer_key(payer_ext, endpoint)
                upserts["payer"].append({
                    "artifact_id": artifact_id,
                    "payer_key": pay_key,
                    "payer_external_id": payer_ext,
                    "payer_name": payer_name,
                    "endpoint_name": endpoint,
                })
                plan_ids_json = json.dumps([], separators=(",", ":"), ensure_ascii=True)
                plan_key = compute_insurance_plan_key(pay_key, plan_ids_json)
                upserts["insurance_plan"].append({
                    "artifact_id": artifact_id,
                    "plan_key": plan_key,
                    "payer_key": pay_key,
                    "medisoft_insurance_ids_json": plan_ids_json,
                })
            pat_raw = str(
                data.get("patient_id") or data.get("PatID") or data.get("Patient ID") or ""
            ).strip()
            dos = str(
                data.get("date_of_service") or data.get("DOS") or data.get("Date") or data.get("service_date") or ""
            ).strip()
            if payer_ext and is_valid_external_patient_id_5_digit(pat_raw) and dos:
                pk = compute_patient_key(source_system or "xp_local", pat_raw, "")
                pay_key = compute_payer_key(payer_ext, endpoint)
                plan_ids_json = json.dumps([], separators=(",", ":"), ensure_ascii=True)
                plan_key = compute_insurance_plan_key(pay_key, plan_ids_json)
                if pk not in seen_patients:
                    seen_patients.add(pk)
                    upserts["patient"].append({
                        "artifact_id": artifact_id,
                        "patient_key": pk,
                        "external_patient_id": pat_raw,
                        "full_name": None,
                        "birth_date": None,
                        "source_system": source_system or "xp_local",
                    })
                cov_key = compute_coverage_key(pk, plan_key, dos)
                upserts["coverage"].append({
                    "artifact_id": artifact_id,
                    "coverage_key": cov_key,
                    "patient_key": pk,
                    "plan_key": plan_key,
                    "effective_start": dos,
                    "effective_end": None,
                    "active_flag": 1,
                })
                enc_key = compute_encounter_key(pk, dos, artifact_id)
                upserts["encounter"].append({
                    "artifact_id": artifact_id,
                    "encounter_key": enc_key,
                    "patient_key": pk,
                    "date_of_service": dos,
                    "source_artifact_id": artifact_id,
                    "diagnosis_code": None,
                    "eye_side": None,
                })
                claim_num = str(data.get("claim_number") or data.get("Claim #") or data.get("Claim") or "").strip()
                cl_key = compute_claim_key(enc_key, pay_key, claim_num)
                upserts["claim"].append({
                    "artifact_id": artifact_id,
                    "claim_key": cl_key,
                    "encounter_key": enc_key,
                    "payer_key": pay_key,
                    "claim_number": claim_num or None,
                    "status": str(data.get("status") or data.get("Status") or "").strip() or None,
                    "charged_amount": None,
                    "allowed_amount": None,
                    "paid_amount": None,
                    "patient_resp_amount": None,
                    "source_artifact_id": artifact_id,
                })
                line_key = compute_claim_line_key(cl_key, 1)
                upserts["claim_line"].append({
                    "artifact_id": artifact_id,
                    "claim_line_key": line_key,
                    "claim_key": cl_key,
                    "line_number": 1,
                    "cpt_code": None,
                    "diagnosis_pointer": None,
                    "charged_amount": None,
                    "paid_amount": None,
                })
    return upserts
