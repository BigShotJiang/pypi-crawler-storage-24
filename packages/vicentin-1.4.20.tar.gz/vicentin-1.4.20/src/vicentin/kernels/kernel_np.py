from collections import OrderedDict
from typing import Callable, Optional
from abc import ABC

import numpy as np


class KernelBackendNumpy(ABC):
    def __init__(
        self,
        func: Callable,
        X: Optional[np.ndarray] = None,
        cache_size: Optional[int] = None,
        chunk_size: Optional[int] = None,
    ):
        super().__init__()

        if X is None:
            X = np.empty((0, 0))

        self._X = X
        self.func = func

        self._cache = OrderedDict()

        self.cache_size = cache_size or self.N
        self.chunk_size = chunk_size or self.N

    @property
    def X(self) -> np.ndarray:
        return self._X

    @property
    def N(self) -> int:
        return self.X.shape[0]

    def __call__(self, x: np.ndarray, y: Optional[np.ndarray] = None):
        return self.func(x, y)

    def __getitem__(self, key):
        if isinstance(key, tuple):
            row_key, col_key = key
        else:
            row_key, col_key = key, slice(None)

        rows = self._normalize_idx(row_key, self.N)
        cols = self._normalize_idx(col_key, self.N)

        missing_rows = [r for r in rows if r not in self._cache]

        if missing_rows:
            computed_block = self(self.X[missing_rows], self.X)

            if len(missing_rows) == 1 and computed_block.ndim == 1:
                computed_block = computed_block[None, :]

            for i, row_index in enumerate(missing_rows):
                self._update_cache(row_index, computed_block[i])

        for r in rows:
            if r not in missing_rows:
                self._cache.move_to_end(r)

        cached_data = np.atleast_2d(np.stack([self._cache[r] for r in rows]))
        return cached_data[:, cols].squeeze()

    def __matmul__(self, v):
        v = np.asanyarray(v)
        v_reshaped = v.reshape(self.N, -1)
        result = np.zeros((self.N, v_reshaped.shape[1]))

        for i in range(0, self.N, self.chunk_size):
            end = min(i + self.chunk_size, self.N)
            K_block = self[i:end, :]

            result[i:end] = K_block @ v_reshaped

        return result.reshape(v.shape)

    def apply_v(self, X: np.ndarray, v: np.ndarray) -> np.ndarray:
        v = np.asanyarray(v)
        n_new = X.shape[0]

        result = np.zeros((n_new, v.shape[1] if v.ndim > 1 else 1))

        for i in range(0, n_new, self.chunk_size):
            end = min(i + self.chunk_size, n_new)
            K_chunk = self.func(X[i:end], self.X)
            result[i:end] = (K_chunk @ v).reshape(-1, 1)

        return result.squeeze()

    def _update_cache(self, i, row_data):
        if i not in self._cache:
            if len(self._cache) >= self.cache_size and self.cache_size > 0:
                self._cache.popitem(last=False)
            self._cache[i] = row_data
        else:
            self._cache.move_to_end(i)

    def _normalize_idx(self, key, limit) -> np.ndarray:
        if isinstance(key, slice):
            return np.arange(*key.indices(limit))
        if isinstance(key, (int, np.integer)):
            return np.array([key if key >= 0 else limit + key])
        return np.asanyarray(key)
