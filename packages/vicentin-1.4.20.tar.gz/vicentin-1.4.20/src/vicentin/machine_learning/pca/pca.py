from typing import Optional, Any

from vicentin.kernels import Kernel, LinearKernel
from vicentin.utils import Dispatcher

disp_pca = Dispatcher()

try:
    from .pca_np import PCA as PCA_np

    disp_pca.register("numpy", PCA_np)
except ModuleNotFoundError:
    pass

try:
    from .pca_torch import PCA as PCA_torch

    disp_pca.register("torch", PCA_torch)
except ModuleNotFoundError:
    pass


class PCA:
    def __init__(
        self, n_components: Optional[int] = None, backend: Optional[str] = None
    ):
        self.n_components = n_components

        self.eigenvectors = None
        self.eigenvalues = None

        self.backend = backend

    def fit(self, X: Any | Kernel):
        """
        Compute the kernel matrix, center it, and solve the eigenvalue problem.
        """

        if isinstance(X, Kernel):
            self.kernel = X
            X = self.kernel.X
        else:
            self.kernel = LinearKernel(X)

        disp_pca.detect_backend(X, self.backend)
        X = disp_pca.cast_values(X)

        self.eigenvalues, self.eigenvectors = disp_pca(X, self.n_components)

        return self

    def transform(self, X: Any) -> Any:
        """
        Project new data X into the principal components.
        """

        if self.eigenvectors is None:
            raise RuntimeError("Model must be fit before calling transform.")

        return self.kernel.apply(X, self.eigenvectors)
