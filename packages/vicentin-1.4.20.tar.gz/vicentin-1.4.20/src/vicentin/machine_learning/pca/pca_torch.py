from typing import Optional

import torch

from vicentin.kernels import Kernel, LinearKernel


def PCA(X: torch.Tensor | Kernel, n_components: Optional[int] = None):
    if isinstance(X, Kernel):
        kernel = X
        X = torch.as_tensor(kernel.X)
    else:
        kernel = LinearKernel(X)

    kernel = kernel.center()

    if n_components is None:
        n_components = kernel.N - 1
    n_components = min(n_components, kernel.N - 1)

    q = torch.randn(
        (kernel.N, n_components), device=kernel.X.device, dtype=kernel.X.dtype
    )

    eigenvalues, eigenvectors = torch.lobpcg(kernel, k=n_components, X=q)
    eigenvectors = eigenvectors / torch.sqrt(
        torch.clamp(eigenvalues, min=1e-12)
    )

    return eigenvalues, eigenvectors
