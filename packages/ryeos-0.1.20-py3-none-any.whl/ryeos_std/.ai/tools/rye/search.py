# rye:signed:2026-03-17T01:41:47Z:dd6c555d4f6a5511e1f5a4b420d3f0df8786f981bc379ff115c3da3cf6f838e9:pHuJAj711j_PcCExSneOAkwX7LG4oLyHhggTnKk8H2iWvXp49ALNlwDqZGcVPYP7yu5pScZdA6jkj0kKzTILBA==:6ea18199041a1ea8
"""Search for directives, tools, or knowledge items."""

import argparse
import json
import sys
import asyncio
from pathlib import Path

from rye.primary_action_descriptions import (
    SEARCH_LIMIT_DESC,
    SEARCH_QUERY_DESC,
    SEARCH_SCOPE_DESC,
    SEARCH_SOURCE_DESC,
)

__version__ = "1.0.0"
__tool_type__ = "python"
__executor_id__ = "rye/core/runtimes/python/script"
__category__ = "rye"
__tool_description__ = "Discover item IDs before calling execute or load"

CONFIG_SCHEMA = {
    "type": "object",
    "properties": {
        "query": {
            "type": "string",
            "description": SEARCH_QUERY_DESC,
        },
        "scope": {
            "type": "string",
            "description": SEARCH_SCOPE_DESC,
        },
        "source": {
            "type": "string",
            "enum": ["project", "user", "system", "local", "registry", "all"],
            "default": "all",
            "description": SEARCH_SOURCE_DESC,
        },
        "limit": {
            "type": "integer",
            "default": 10,
            "description": SEARCH_LIMIT_DESC,
        },
    },
    "required": ["query", "scope"],
}


def execute(params: dict, project_path: str) -> dict:
    try:
        from rye.tools.search import SearchTool

        tool = SearchTool()
        result = asyncio.run(tool.handle(
            query=params["query"],
            scope=params["scope"],
            project_path=project_path,
            source=params.get("source", "all"),
            limit=params.get("limit", 10),
        ))
        return result
    except Exception as e:
        return {"success": False, "error": str(e)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-path", required=True)
    args = parser.parse_args()
    params = json.loads(sys.stdin.read())
    result = execute(params, args.project_path)
    print(json.dumps(result))
