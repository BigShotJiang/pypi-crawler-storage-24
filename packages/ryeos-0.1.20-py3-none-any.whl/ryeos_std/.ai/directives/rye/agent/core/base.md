<!-- rye:signed:2026-03-17T01:41:47Z:cff74b6dab29568437ba96ef0ba545813c415baf364071c902cbc72f20c31dda:j3YzSyrhJRW_iEwzLvrF_V4sy1zV511WwTFJAJJ_iRKqvgruaPcmSeiU70ISgjz-1s7puvi-0xq998C_ird5Aw==:6ea18199041a1ea8 -->
<!-- rye:unsigned -->

# Base

Standard operating context for Rye agent threads.

```xml
<directive name="base" version="2.0.0" extends="agent/core/base">
  <metadata>
    <description>Rye agent base — extends general agent base with Rye identity and behavior</description>
    <category>rye/agent/core</category>
    <author>rye-os</author>
    <context>
      <system>rye/agent/core/Identity</system>
      <system>rye/agent/core/Behavior</system>
      <suppress>agent/core/Behavior</suppress>
    </context>
    <permissions>
      <execute>*</execute>
      <search>*</search>
      <load>*</load>
      <sign>*</sign>
    </permissions>
  </metadata>
</directive>
```
