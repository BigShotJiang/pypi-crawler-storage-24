<!-- rye:signed:2026-03-17T01:41:47Z:68a7411502603baec4688d1b007d9b16515040ae5cb371e7335b8d54a9a2b5ba:_n019o4CMnHo97msTilD_TF6u3IQMX6R62ZOY0qeqUHnsoG17Nm-VEZV8ByQDAA8GW8bUn3Oy4yHA7sLQWczBg==:6ea18199041a1ea8 -->
<!-- rye:unsigned -->

```xml
<directive name="base" version="1.0.0">
  <metadata>
    <description>General agent base — behavior and protocol context, no identity (agents provide their own)</description>
    <category>agent/core</category>
    <author>rye-os</author>
    <context>
      <system>agent/core/Behavior</system>
      <before>rye/agent/core/protocol/execute</before>
      <before>rye/agent/core/protocol/search</before>
      <before>rye/agent/core/protocol/load</before>
      <before>rye/agent/core/protocol/sign</before>
    </context>
    <permissions />
  </metadata>
</directive>
```
