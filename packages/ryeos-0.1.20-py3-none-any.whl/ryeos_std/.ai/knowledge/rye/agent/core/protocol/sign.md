<!-- rye:signed:2026-03-17T01:41:48Z:3945e1f2a85e6ad91850fe481a39df77c3acec823f6f7756f9f7d9d5564fd1e4:Quh1APFPEB65YcpAJeFujRNtUJ-5ayXh5xqd3TOGB0srIbX_GVUPqhlHR2hUm5jNFCbxO-Ml_aIQVoWdIxURCw==:6ea18199041a1ea8 -->
<!-- rye:unsigned -->

```yaml
name: sign
title: Sign Protocol
entry_type: context
category: rye/agent/core/protocol
version: "1.0.0"
author: rye-os
created_at: 2026-03-04T00:00:00Z
tags:
  - tools
  - protocol
  - sign
```

### rye_sign — Sign items

Validate and sign items after editing. Required after any modification.

```json
rye_sign(item_type="directive", item_id="my/workflow")
rye_sign(item_type="tool", item_id="*")  // glob to batch sign
```
