"""
alacarte_pipeline
=================
A Python library for enrollment prediction pipelines.

Provides data loading, feature engineering, and model training utilities
designed for university course enrollment forecasting.

Quick Start
-----------
>>> from alacarte_pipeline import load_folder, compute_lagged_avg, target_encode_cv
>>> df = load_folder("./my-enrollment-data/")
>>> df = compute_lagged_avg(df, ['store_unit', 'department', 'course', 'term_code'],
...                          'total_student_active', 'avg_active_prev_years')
"""

__version__ = "0.1.0"
__author__  = "Vibhu Verma"

# ── Data loading & joining ────────────────────────────────────────────────────
from alacarte_pipeline.data import (
    process_file,
    load_folder,
    join_dataframes,
    create_store_unit_fast,
    create_key_fast,
    split_train_prediction,
)

# ── Feature engineering ───────────────────────────────────────────────────────
from alacarte_pipeline.features import (
    compute_lagged_avg,
    compute_weighted_rolling,
    assign_credit_hours,
)

# ── Model helpers ─────────────────────────────────────────────────────────────
from alacarte_pipeline.model import (
    target_encode_cv,
    apply_norm_pipeline,
    run_inference,
)

# ── Utilities ─────────────────────────────────────────────────────────────────
from alacarte_pipeline.utils import (
    fix_values,
    normalize_term_code,
    smape,
)

__all__ = [
    # data
    "process_file",
    "load_folder",
    "join_dataframes",
    "create_store_unit_fast",
    "create_key_fast",
    "split_train_prediction",
    # features
    "compute_lagged_avg",
    "compute_weighted_rolling",
    "assign_credit_hours",
    # model
    "target_encode_cv",
    "apply_norm_pipeline",
    "run_inference",
    # utils
    "fix_values",
    "normalize_term_code",
    "smape",
]
