"""
alacarte_pipeline.utils
=======================
Shared utility helpers.

Functions
---------
fix_values          — normalise store_unit string (strip leading zeros from unit part)
normalize_term_code — map raw term codes to canonical F / W / A
smape               — Symmetric Mean Absolute Percentage Error
"""

import numpy as np
import pandas as pd


def fix_values(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Normalise a ``store_unit`` column by stripping leading zeros from the unit part.

    Example: ``"123-007"`` → ``"123-7"``

    Parameters
    ----------
    df : pd.DataFrame
    col : str
        Name of the column to fix (typically ``'store_unit'``).

    Returns
    -------
    pd.DataFrame
    """
    a = df[col].astype(str).str.split("-", n=1, expand=True)
    b = pd.to_numeric(a[1], errors="coerce")
    df[col] = a[0] + "-" + b.fillna(a[1]).apply(
        lambda x: str(int(x)) if isinstance(x, (int, float)) and not pd.isna(x) else x
    )
    return df


def normalize_term_code(df: pd.DataFrame) -> pd.DataFrame:
    """Map raw term codes to canonical values: ``'F'``, ``'W'``, or ``'A'``.

    The original code is preserved in a new column ``term_code1``.

    Mapping:
    =========  ==============  =========
    Input      Meaning         Output
    =========  ==============  =========
    F, G, X    Fall             F
    I, J, K,   Spring/Winter    W
    S, W, Y
    A, B, C, M Summer           A
    other      Unknown          NaN
    =========  ==============  =========

    Parameters
    ----------
    df : pd.DataFrame
        Must contain a ``term_code`` column.

    Returns
    -------
    pd.DataFrame
        Copy with ``term_code`` mapped and original preserved as ``term_code1``.
    """
    df = df.copy()
    df.rename(columns={"term_code": "term_code1"}, inplace=True)

    fall   = {"F", "G", "X"}
    spring = {"I", "J", "K", "S", "W", "Y"}
    summer = {"A", "B", "C", "M"}

    def _map(x):
        if pd.isna(x):  return np.nan
        if x in fall:   return "F"
        if x in spring: return "W"
        if x in summer: return "A"
        return np.nan

    df["term_code"] = df["term_code1"].apply(_map)
    return df


def smape(y_true, y_pred) -> float:
    """Symmetric Mean Absolute Percentage Error (sMAPE).

    .. math::
        \\text{sMAPE} = \\frac{1}{n} \\sum
        \\frac{|\\hat{y} - y|}{(|y| + |\\hat{y}|) / 2} \\times 100

    Parameters
    ----------
    y_true, y_pred : array-like
        Actual and predicted values.

    Returns
    -------
    float
        sMAPE as a percentage.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    denom  = (np.abs(y_true) + np.abs(y_pred)) / 2
    return float(np.mean(np.abs(y_pred - y_true) / (denom + 1e-10)) * 100)
