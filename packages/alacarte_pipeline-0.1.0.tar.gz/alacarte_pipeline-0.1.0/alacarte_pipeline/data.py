"""
alacarte_pipeline.data
======================
File loading and DataFrame joining utilities.

Functions
---------
process_file        — read a single CSV, skip empty/corrupt files
load_folder         — parallel-load all CSVs in a folder
join_dataframes     — fast left-join two DataFrames on key columns
create_store_unit_fast  — add store_unit column from store + unit cols
create_key_fast         — build composite join key column
split_train_prediction  — split merged data into train / prediction sets
"""

import os
import re
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed


def process_file(file_path: str) -> pd.DataFrame | None:
    """Read a single CSV file, skipping empty or corrupt files.

    If the filename matches the pattern ``enrollments_data_XYY.csv``,
    the ``term_code`` and ``term_year`` columns are inferred from it.

    Parameters
    ----------
    file_path : str
        Absolute path to the CSV file.

    Returns
    -------
    pd.DataFrame or None
        Parsed DataFrame, or ``None`` if the file was skipped.
    """
    file_name = os.path.basename(file_path)

    if os.path.getsize(file_path) == 0:
        print(f"Skipped empty file: {file_name}")
        return None

    try:
        df = pd.read_csv(file_path, low_memory=False)
    except Exception:
        print(f"Skipped corrupt file: {file_name}")
        return None

    if df.empty:
        print(f"Skipped empty dataframe: {file_name}")
        return None

    match = re.match(r"enrollments_data_([AWS])(\d{2})\.csv", file_name)
    if match:
        df["term_code"] = match.group(1)
        df["term_year"] = int(match.group(2))

    return df


def load_folder(folder_path: str, max_workers: int = 8) -> pd.DataFrame:
    """Parallel-load all CSV files in a folder into a single DataFrame.

    Parameters
    ----------
    folder_path : str
        Path to the folder containing CSV files.
    max_workers : int, optional
        Number of parallel threads. Default ``8``.

    Returns
    -------
    pd.DataFrame
        Concatenated DataFrame from all valid files.
    """
    csv_files = [
        os.path.join(folder_path, f)
        for f in os.listdir(folder_path)
        if f.endswith(".csv")
    ]

    dfs = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(process_file, f) for f in csv_files]
        for future in as_completed(futures):
            result = future.result()
            if result is not None:
                dfs.append(result)

    if not dfs:
        print("No valid files found")
        return pd.DataFrame()

    return pd.concat(dfs, ignore_index=True)


def join_dataframes(
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    join_cols: list,
    cols_to_add: list,
    return_residue: bool = False,
    use_category: bool = True,
) -> pd.DataFrame | tuple:
    """Fast left-join ``df1 ← df2`` on ``join_cols``, adding ``cols_to_add``.

    Automatically normalises ``term_year`` to ``Int64`` and ``term_code``
    to single uppercase letters before joining.

    Parameters
    ----------
    df1, df2 : pd.DataFrame
        Left and right DataFrames.
    join_cols : list of str
        Columns to join on.
    cols_to_add : list of str
        Columns from ``df2`` to attach to the result.
    return_residue : bool, optional
        If ``True``, also return rows in ``df2`` not matched in ``df1``.
    use_category : bool, optional
        Cast join keys to ``category`` dtype for a speed boost.

    Returns
    -------
    pd.DataFrame, or (pd.DataFrame, pd.DataFrame)
        Joined DataFrame; if ``return_residue=True``, also the residue.
    """
    df1 = df1.copy()
    df2 = df2.copy()

    # term_year → Int64
    if "term_year" in join_cols:
        for df in (df1, df2):
            if "term_year" in df.columns:
                df["term_year"] = pd.to_numeric(df["term_year"], errors="coerce").astype("Int64")

    # term_code → single uppercase letter
    if "term_code" in join_cols:
        def _clean(s):
            s = s.astype(str).str.strip().str.upper()
            s[~s.str.match(r"^[A-Z]$")] = np.nan
            return s

        for df in (df1, df2):
            if "term_code" in df.columns:
                df["term_code"] = _clean(df["term_code"])

    df1 = df1.drop_duplicates(subset=join_cols)
    df2 = df2.drop_duplicates(subset=join_cols)

    if use_category:
        for col in join_cols:
            for df in (df1, df2):
                if col in df.columns:
                    df[col] = df[col].astype("category")

    df1_idx = df1.set_index(join_cols)
    df2_idx = df2.set_index(join_cols)
    df_final = df1_idx.join(df2_idx[cols_to_add], how="left").reset_index()

    if return_residue:
        residue = df2_idx.loc[df2_idx.index.difference(df1_idx.index)].reset_index()
        return df_final, residue

    return df_final


def create_store_unit_fast(
    df: pd.DataFrame,
    store_col: str = "store",
    unit_col: str = "unit",
) -> pd.DataFrame:
    """Add a ``store_unit`` column by concatenating store and unit.

    Trailing ``.0`` is stripped from numeric unit values so ``"123-1.0"``
    becomes ``"123-1"``.

    Parameters
    ----------
    df : pd.DataFrame
    store_col, unit_col : str
        Column names for store and unit.

    Returns
    -------
    pd.DataFrame
        DataFrame with a new ``store_unit`` column.
    """
    unit = df[unit_col].astype(str)
    mask = unit.str.match(r"^\d+\.0$")
    unit_clean = unit.copy()
    unit_clean[mask] = unit_clean[mask].str.replace(".0", "", regex=False)
    df["store_unit"] = df[store_col].astype(str) + "-" + unit_clean
    return df


def create_key_fast(df: pd.DataFrame) -> pd.DataFrame:
    """Build a composite join key column.

    Key format: ``store_unit-term_code-term_year-department-course-section``

    Parameters
    ----------
    df : pd.DataFrame
        Must contain: ``store_unit``, ``term_code``, ``term_year``,
        ``department``, ``course``, ``section``.

    Returns
    -------
    pd.DataFrame
        DataFrame with a new ``key`` column.
    """
    def _smart_numeric(col):
        numeric = pd.to_numeric(col, errors="coerce")
        result = col.copy()
        mask = numeric.notna() & np.isfinite(numeric)
        result.loc[mask] = numeric.loc[mask].astype(int)
        return result

    df["term_year"] = pd.to_numeric(df["term_year"], errors="coerce").astype("Int64")
    df["course"]    = _smart_numeric(df["course"])
    df["section"]   = _smart_numeric(df["section"])
    df["term_code"] = df["term_code"].astype(str).str.upper()

    df["key"] = (
        df["store_unit"].astype(str) + "-"
        + df["term_code"].astype(str) + "-"
        + df["term_year"].astype(str) + "-"
        + df["department"].astype(str) + "-"
        + df["course"].astype(str) + "-"
        + df["section"].astype(str)
    )
    return df


def split_train_prediction(
    df_data: pd.DataFrame,
    df_residue: pd.DataFrame | None = None,
    merge_residue: bool = True,
    keep_nan_enroll: bool = True,
) -> tuple:
    """Split a merged DataFrame into train and prediction subsets.

    Rows where ``total_student_active`` is not null go to **train**;
    the rest go to **prediction**.

    Parameters
    ----------
    df_data : pd.DataFrame
        Main merged DataFrame.
    df_residue : pd.DataFrame, optional
        Residue rows (unmatched in the left DataFrame during joining).
    merge_residue : bool
        If ``True`` and ``df_residue`` is non-empty, concatenate before splitting.
    keep_nan_enroll : bool
        If ``False``, drop train rows where ``enroll`` is null.

    Returns
    -------
    (train, prediction) : tuple of pd.DataFrame
    """
    if merge_residue and df_residue is not None and not df_residue.empty:
        df = pd.concat((df_data, df_residue), ignore_index=True)
    else:
        df = df_data

    mask = df["total_student_active"].notna()
    train = df.loc[mask]
    test  = df.loc[~mask]

    if not keep_nan_enroll:
        train = train.loc[train["enroll"].notna()]

    return train, test
