"""
alacarte_pipeline.features
==========================
Feature engineering utilities for the enrollment prediction pipeline.

Functions
---------
compute_lagged_avg       — average of a column over previous N years
compute_weighted_rolling — weighted rolling average (most-recent weight first)
assign_credit_hours      — fill credit_hours in a target df from a source df
"""

import numpy as np
import pandas as pd


def compute_lagged_avg(
    df: pd.DataFrame,
    group_cols: list,
    value_col: str,
    out_col: str,
    shifts: tuple = (1, 2, 3),
) -> pd.DataFrame:
    """Compute the average of ``value_col`` over previous N years, per group.

    For each row, the output is the mean of the N lagged values (shifted
    back by 1, 2, ... N years). Groups without any lagged history get
    ``NaN``.

    Parameters
    ----------
    df : pd.DataFrame
    group_cols : list of str
        Columns that define the group (e.g. ``['store_unit','department','course','term_code']``).
    value_col : str
        Column to average (e.g. ``'total_student_active'``).
    out_col : str
        Name of the new output column.
    shifts : tuple of int, optional
        Year-lag offsets to average over. Default ``(1, 2, 3)``.

    Returns
    -------
    pd.DataFrame
        Input DataFrame with ``out_col`` added.
    """
    df        = df.sort_values(group_cols + ["term_year"])
    g         = df.groupby(group_cols)[value_col]
    shifted   = [g.shift(s) for s in shifts]
    sum_vals  = sum(s.fillna(0)           for s in shifted)
    count_vals= sum(s.notna().astype(int) for s in shifted)
    df[out_col] = np.where(count_vals > 0, sum_vals / count_vals, np.nan)
    return df


def compute_weighted_rolling(
    df: pd.DataFrame,
    group_cols: list,
    value_col: str,
    out_col: str,
    weights: tuple = (0.6, 0.3, 0.1),
) -> pd.DataFrame:
    """Compute a weighted rolling average of ``value_col`` over previous N years.

    Weights apply in most-recent-first order (index 0 = 1 year ago,
    index 1 = 2 years ago, etc.). Missing years are excluded from
    both the numerator and the denominator so the weights re-normalise.

    Parameters
    ----------
    df : pd.DataFrame
    group_cols : list of str
        Grouping columns.
    value_col : str
        Column to compute the rolling average over.
    out_col : str
        Name of the new output column.
    weights : tuple of float, optional
        Weights in most-recent-first order. Default ``(0.6, 0.3, 0.1)``.

    Returns
    -------
    pd.DataFrame
        Input DataFrame with ``out_col`` added.
    """
    df           = df.sort_values(group_cols + ["term_year"])
    g            = df.groupby(group_cols)[value_col]
    shifted      = [g.shift(i + 1) for i in range(len(weights))]
    weighted_sum = sum(w * s.fillna(0)           for w, s in zip(weights, shifted))
    weight_sum   = sum(w * s.notna().astype(int) for w, s in zip(weights, shifted))
    df[out_col]  = np.where(weight_sum > 0, weighted_sum / weight_sum, np.nan)
    return df


def assign_credit_hours(
    df_source: pd.DataFrame,
    df_target: pd.DataFrame,
) -> pd.DataFrame:
    """Fill ``credit_hours`` in ``df_target`` using values from ``df_source``.

    Lookup strategy (in priority order):
    1. Year-25 A-term maximum for the same ``(store_unit, department, course)``
    2. Overall maximum for the same key across all years/terms

    Parameters
    ----------
    df_source : pd.DataFrame
        Historical dataset containing ``credit_hours``.
    df_target : pd.DataFrame
        Dataset to enrich (typically the prediction set).

    Returns
    -------
    pd.DataFrame
        ``df_target`` with ``credit_hours`` filled.
    """
    keys = ["store_unit", "department", "course"]

    subset_max = (
        df_source[
            (df_source["term_year"] == 25) & (df_source["term_code"] == "A")
        ]
        .groupby(keys)["credit_hours"].max()
        .reset_index()
        .rename(columns={"credit_hours": "credit_subset"})
    )
    overall_max = (
        df_source.groupby(keys)["credit_hours"]
        .max()
        .reset_index()
        .rename(columns={"credit_hours": "credit_all"})
    )
    df_target = df_target.merge(subset_max, on=keys, how="left")
    df_target = df_target.merge(overall_max, on=keys, how="left")
    df_target["credit_hours"] = df_target["credit_subset"].fillna(df_target["credit_all"])
    return df_target.drop(columns=["credit_subset", "credit_all"])
