"""
alacarte_pipeline.model
=======================
Model training and inference helpers.

Functions
---------
target_encode_cv    — cross-validated target encoding
apply_norm_pipeline — chainable normalization (standard / log / minmax / robust / robust2)
run_inference       — apply encoder + model to produce predictions
"""

import numpy as np
import pandas as pd
import category_encoders as ce
from sklearn.model_selection import KFold


# ── Private: robust2 helpers ──────────────────────────────────────────────────

def _robust2_compute_params(
    df_train: pd.DataFrame,
    columns: list,
    threshold: float = 0.01,
    target_ratio: float = 0.8,
) -> dict:
    """Fit robust2 scaler parameters on training data."""
    params = {}
    for col in columns:
        x     = df_train[col].dropna()
        mu    = np.percentile(x, 85)
        sigma = x[x <= mu].std()
        if sigma == 0 or np.isnan(sigma):
            sigma = 1.0
        a = 1.0
        for _ in range(500):
            if (a * ((x - mu) / sigma) > threshold).mean() >= target_ratio:
                break
            a *= 1.1
        params[col] = {"a": a, "mean_85": mu, "std_85": sigma}
    return params


def _robust2_apply(df: pd.DataFrame, params: dict) -> pd.DataFrame:
    """Apply pre-fitted robust2 scaler parameters."""
    df = df.copy()
    for col, p in params.items():
        if col in df.columns:
            df[col] = p["a"] * ((df[col] - p["mean_85"]) / p["std_85"])
    return df


# ── Public API ────────────────────────────────────────────────────────────────

def target_encode_cv(
    X: pd.DataFrame,
    y: pd.Series,
    cat_cols: list,
    n_splits: int = 5,
    smoothing: float = 0.3,
    random_state: int = 42,
) -> tuple:
    """Cross-validated target encoding for categorical columns.

    Uses K-fold CV so there is no target leakage in the training set.
    A full-data encoder is also returned for applying to test / OOT data.

    Parameters
    ----------
    X : pd.DataFrame
        Feature matrix (must include ``cat_cols``).
    y : pd.Series
        Target column.
    cat_cols : list of str
        Columns to encode.
    n_splits : int
        Number of CV folds.
    smoothing : float
        Smoothing factor for :class:`category_encoders.TargetEncoder`.
    random_state : int

    Returns
    -------
    (X_encoded, encoder_full) : (pd.DataFrame, TargetEncoder)
        ``X_encoded`` has new ``*_te`` columns added.
        ``encoder_full`` is fitted on the entire ``X``/``y`` for OOT use.

    Examples
    --------
    >>> X_tr_enc, te = target_encode_cv(X_train, y_train, ['store_unit', 'department'])
    >>> X_test['store_unit_te'] = te.transform(X_test[['store_unit', 'department']])['store_unit']
    """
    X_te    = X.copy()
    te_cols = [c + "_te" for c in cat_cols]
    for col in te_cols:
        X_te[col] = np.nan

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    for train_idx, val_idx in kf.split(X):
        te = ce.TargetEncoder(cols=cat_cols, smoothing=smoothing)
        te.fit(X.iloc[train_idx][cat_cols], y.iloc[train_idx])
        X_te.iloc[val_idx, X_te.columns.get_indexer(te_cols)] = (
            te.transform(X.iloc[val_idx][cat_cols]).values
        )

    te_full = ce.TargetEncoder(cols=cat_cols, smoothing=smoothing)
    te_full.fit(X[cat_cols], y)
    return X_te, te_full


def apply_norm_pipeline(
    df_train: pd.DataFrame,
    pipeline: list | None,
    norm_cols_default: list,
    *extra_dfs: pd.DataFrame,
) -> tuple:
    """Apply a normalization pipeline to a training set and any extra DataFrames.

    Statistics are **fitted on ``df_train`` only** and then applied to
    ``df_train`` and all ``extra_dfs`` (e.g. test set, prediction set) with
    the same parameters — preventing data leakage.

    Parameters
    ----------
    df_train : pd.DataFrame
        Training data used to fit scaler parameters.
    pipeline : list of dict, or None
        Ordered list of normalization steps, each a dict with keys:

        - ``'method'`` : one of ``'standard'``, ``'log'``, ``'minmax'``,
          ``'robust'``, ``'robust2'``
        - ``'cols'``: list of column names, or the string ``'NORM_COLS'``
          (substituted with ``norm_cols_default``)
        - ``'threshold'``, ``'target_ratio'`` : extra keys for ``'robust2'``

        Pass ``None`` to skip all normalization.
    norm_cols_default : list of str
        Columns used when a step specifies ``'cols': 'NORM_COLS'``.
    *extra_dfs : pd.DataFrame
        Additional DataFrames to normalise with the same fitted parameters.

    Returns
    -------
    tuple of pd.DataFrame
        ``(df_train_normed, *extra_dfs_normed)``

    Examples
    --------
    >>> pipeline = [
    ...     {'method': 'log',      'cols': ['enroll']},
    ...     {'method': 'standard', 'cols': 'NORM_COLS'},
    ... ]
    >>> train_n, test_n = apply_norm_pipeline(train, pipeline, NORM_COLS, test)
    """
    if pipeline is None:
        print("Normalization: SKIPPED")
        return (df_train.copy(),) + tuple(d.copy() for d in extra_dfs)

    df_train = df_train.copy()
    dfs_out  = [d.copy() for d in extra_dfs]

    for i, step in enumerate(pipeline):
        method   = step["method"]
        raw_cols = norm_cols_default if step["cols"] == "NORM_COLS" else step["cols"]
        cols     = [c for c in raw_cols if c in df_train.columns]
        missing  = [c for c in raw_cols if c not in df_train.columns]
        if missing:
            print(f"  [Step {i+1}] WARNING: skipped missing cols: {missing}")
        if not cols:
            print(f"  [Step {i+1}] {method}: no cols — skipped.")
            continue

        if method == "log":
            df_train[cols] = np.log1p(df_train[cols].clip(lower=0))
            for d in dfs_out:
                d[cols] = np.log1p(d[cols].clip(lower=0))

        elif method == "standard":
            for col in cols:
                mean = df_train[col].mean()
                std  = df_train[col].std()
                if std == 0 or np.isnan(std):
                    df_train[col] = 0
                    for d in dfs_out: d[col] = 0
                else:
                    df_train[col] = (df_train[col] - mean) / std
                    for d in dfs_out: d[col] = (d[col] - mean) / std

        elif method == "minmax":
            for col in cols:
                mn = df_train[col].min()
                mx = df_train[col].max()
                if mx == mn or np.isnan(mx - mn):
                    df_train[col] = 0
                    for d in dfs_out: d[col] = 0
                else:
                    df_train[col] = (df_train[col] - mn) / (mx - mn)
                    for d in dfs_out: d[col] = (d[col] - mn) / (mx - mn)

        elif method == "robust":
            for col in cols:
                med = df_train[col].median()
                iqr = df_train[col].quantile(0.75) - df_train[col].quantile(0.25)
                if iqr == 0 or np.isnan(iqr):
                    df_train[col] = 0
                    for d in dfs_out: d[col] = 0
                else:
                    df_train[col] = (df_train[col] - med) / iqr
                    for d in dfs_out: d[col] = (d[col] - med) / iqr

        elif method == "robust2":
            r2p = _robust2_compute_params(
                df_train, cols,
                step.get("threshold", 0.01),
                step.get("target_ratio", 0.8),
            )
            df_train = _robust2_apply(df_train, r2p)
            dfs_out  = [_robust2_apply(d, r2p) for d in dfs_out]

        else:
            raise ValueError(
                f'Unknown method: "{method}". '
                'Choose: standard, log, minmax, robust, robust2'
            )

        print(f"  [Step {i+1}] {method:10s} → {len(cols)} cols ✓")

    return (df_train,) + tuple(dfs_out)


def run_inference(
    df_normed: pd.DataFrame,
    df_original: pd.DataFrame,
    model,
    encoder,
    model_cols: list,
    cat_cols: list,
    te_cols: list,
) -> pd.DataFrame:
    """Apply a trained encoder + model to produce predictions.

    Parameters
    ----------
    df_normed : pd.DataFrame
        Normalised feature DataFrame (same shape as ``df_original``).
    df_original : pd.DataFrame
        Original (un-normalised) DataFrame — returned with predictions added.
    model : lightgbm.Booster
        Trained LightGBM model.
    encoder : category_encoders.TargetEncoder
        Full-data target encoder fitted during training.
    model_cols : list of str
        Columns the model expects as input.
    cat_cols : list of str
        Categorical columns that were target-encoded.
    te_cols : list of str
        Encoded column names (``cat_cols`` each suffixed with ``'_te'``).

    Returns
    -------
    pd.DataFrame
        Copy of ``df_original`` with a ``predicted_score`` column appended
        (clipped to ≥ 0 and rounded to integers).
    """
    avail     = [c for c in model_cols if c in df_normed.columns]
    enc       = df_normed[avail].copy()
    enc[te_cols] = encoder.transform(
        df_normed[[c for c in cat_cols if c in df_normed.columns]]
    ).values
    enc_final = enc.drop(columns=[c for c in cat_cols if c in enc.columns])
    pred      = np.clip(model.predict(enc_final), a_min=0, a_max=None).round().astype(int)
    out       = df_original.copy()
    out["predicted_score"] = pred
    return out
