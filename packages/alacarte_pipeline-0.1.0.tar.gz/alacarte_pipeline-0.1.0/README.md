# alacarte-pipeline

**Enrollment prediction pipeline utilities** — data loading, feature engineering, and LightGBM model helpers.

[![PyPI version](https://badge.fury.io/py/alacarte-pipeline.svg)](https://badge.fury.io/py/alacarte-pipeline)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## Install

```bash
pip install alacarte-pipeline
```

---

## Quick Start

```python
from alacarte_pipeline import (
    load_folder,
    join_dataframes,
    create_store_unit_fast,
    create_key_fast,
    split_train_prediction,
    compute_lagged_avg,
    compute_weighted_rolling,
    target_encode_cv,
    apply_norm_pipeline,
    run_inference,
    smape,
)

# 1. Load all CSVs from a folder (parallel)
df = load_folder("./enrollment-data/", max_workers=8)

# 2. Build composite key
df = create_store_unit_fast(df)
df = create_key_fast(df)

# 3. Feature engineering
group = ['store_unit', 'department', 'course', 'term_code']
df = compute_lagged_avg(df, group, 'total_student_active', 'avg_active_prev')
df = compute_weighted_rolling(df, group, 'enroll', 'weighted_enroll')

# 4. Split train / prediction
train, prediction = split_train_prediction(df, merge_residue=True)

# 5. Target encoding
X = train[FEATURES]
y = train['total_student_active']
X_enc, encoder = target_encode_cv(X, y, cat_cols=['store_unit', 'department'])

# 6. Normalization (fits on train, applies to test too)
pipeline = [{'method': 'standard', 'cols': ['enroll', 'avg_active_prev']}]
train_norm, test_norm = apply_norm_pipeline(train, pipeline, norm_cols, test)

# 7. Inference
results = run_inference(test_norm, test_raw, model, encoder, MODEL_COLS, CAT_COLS, TE_COLS)
print(f"SMAPE: {smape(results['total_student_active'], results['predicted_score']):.2f}%")
```

---

## Modules

| Module | What's inside |
|--------|--------------|
| `alacarte_pipeline.data` | `load_folder`, `join_dataframes`, `create_key_fast`, `split_train_prediction` |
| `alacarte_pipeline.features` | `compute_lagged_avg`, `compute_weighted_rolling`, `assign_credit_hours` |
| `alacarte_pipeline.model` | `target_encode_cv`, `apply_norm_pipeline`, `run_inference` |
| `alacarte_pipeline.utils` | `fix_values`, `normalize_term_code`, `smape` |

---

## Normalization Methods

`apply_norm_pipeline` supports chaining multiple steps:

| Method | Description |
|--------|-------------|
| `standard` | Z-score: `(x − mean) / std` |
| `log` | `log1p(x)` — for right-skewed counts |
| `minmax` | Scale to `[0, 1]` |
| `robust` | `(x − median) / IQR` — outlier-resistant |
| `robust2` | Custom 85th-percentile scaler |

```python
pipeline = [
    {'method': 'log',     'cols': ['enroll']},
    {'method': 'standard','cols': ['avg_active_prev', 'avg_enroll_prev']},
]
train_n, test_n, pred_n = apply_norm_pipeline(train, pipeline, norm_cols, test, pred)
```

---

## Requirements

- Python ≥ 3.9
- pandas, numpy, lightgbm, optuna, category-encoders, scikit-learn, openpyxl, joblib

---

## License

MIT © Vibhu Verma
