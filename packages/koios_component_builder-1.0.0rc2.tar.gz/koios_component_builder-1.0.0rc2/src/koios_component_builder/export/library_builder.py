"""
Library package builder.

Builds .kcl (Koios Component Library) packages from ComponentLibrary definitions.
Each .kcl is a ZIP archive containing manifest.json and a pip-installable wheel,
using the library format (manifest_version 2.0).
"""

import datetime
import hashlib
import importlib.util
import inspect
import logging
import py_compile
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

from koios_component_builder.component import Component
from koios_component_builder.export.dependency_resolver import resolve_dependencies
from koios_component_builder.export.metadata import extract_component_metadata
from koios_component_builder.library import ComponentLibrary
from koios_component_builder.models import (
    BuildInfo,
    LibraryMetadata,
    MetadataWrapper,
    SemanticVersion,
)

logger = logging.getLogger(__name__)


class LibraryBuilder:
    """Builds .kcl packages from ComponentLibrary definitions."""

    def __init__(
        self,
        source_path: str | Path,
        include_deps: bool = False,
        platforms: list[str] | None = None,
    ):
        """
        Initialize the builder.

        Args:
            source_path: Path to Python file or package directory containing
                         ComponentLibrary or Component. If a directory is provided,
                         it must contain an __init__.py file.
            include_deps: If True, download and bundle non-platform dependencies
                         into the .kcl archive.
            platforms: Target platform tags for pip download. Defaults to
                      linux amd64 + arm64 (manylinux2014).
        """
        self.source_path = Path(source_path)
        self.include_deps = include_deps
        self.platforms = platforms
        if not self.source_path.exists():
            raise ValueError(f"Source path does not exist: {source_path}")
        if self.source_path.is_dir():
            # If directory, look for __init__.py
            init_path = self.source_path / "__init__.py"
            if not init_path.exists():
                raise ValueError(
                    f"Directory {source_path} must contain an __init__.py file"
                )
            self.source_path = init_path
        elif not self.source_path.is_file():
            raise ValueError(f"Source path must be a file or directory: {source_path}")

    def _load_module(self) -> tuple[object, Path]:
        """
        Load the Python module from source file.

        Returns:
            Tuple of (module, parent_dir)

        Raises:
            ValueError: If module cannot be loaded
        """
        # For package directories (loading __init__.py), use the directory name
        # as the module name so relative imports work correctly
        if self.source_path.name == "__init__.py":
            module_name = self.source_path.parent.name
            parent_dir = self.source_path.parent.parent
        else:
            module_name = self.source_path.stem
            parent_dir = self.source_path.parent

        spec = importlib.util.spec_from_file_location(
            module_name,
            self.source_path,
            submodule_search_locations=[str(self.source_path.parent)],
        )
        if spec is None or spec.loader is None:
            raise ValueError(f"Could not load module from {self.source_path}")

        # Add parent directory to path for imports
        if str(parent_dir) not in sys.path:
            sys.path.insert(0, str(parent_dir))

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        return module, parent_dir

    def _find_library_class(self, module: object) -> type[ComponentLibrary] | None:
        """Find ComponentLibrary subclass in module."""
        for name, obj in inspect.getmembers(module):
            if (
                inspect.isclass(obj)
                and issubclass(obj, ComponentLibrary)
                and obj is not ComponentLibrary
            ):
                # Check if it's defined in this module
                if hasattr(obj, "__module__") and obj.__module__ == module.__name__:
                    return obj
        return None

    def _collect_source_files(
        self, library_class: type[ComponentLibrary]
    ) -> dict[str, str]:
        """
        Collect source files for all components in the library.

        Returns:
            Dict mapping module names to source code
        """
        sources: dict[str, str] = {}

        for component_class in library_class.components:
            # Get the source file for this component
            try:
                source_file = inspect.getfile(component_class)
                source_path = Path(source_file)

                # Use a normalized module name based on class name
                module_name = self._class_to_module_name(component_class.__name__)

                # Read source code
                if source_path.exists():
                    sources[module_name] = source_path.read_text(encoding="utf-8")
            except (TypeError, OSError):
                # Built-in or can't get source, skip
                pass

        return sources

    def _collect_documentation(
        self, library_class: type[ComponentLibrary]
    ) -> tuple[str | None, dict[str, str]]:
        """
        Collect markdown documentation for the library and its components.

        Documentation convention:
        - Library docs: README.md in the library root directory
        - Component docs: {ClassName}.md adjacent to the .py file containing the class

        Args:
            library_class: The library class to collect documentation for

        Returns:
            Tuple of (library_documentation, component_docs_dict)
            where component_docs_dict maps class names to their documentation
        """
        library_doc: str | None = None
        component_docs: dict[str, str] = {}

        # Get the library root directory (where __init__.py is defined)
        try:
            library_file = inspect.getfile(library_class)
            library_path = Path(library_file)
            library_root = library_path.parent
        except (TypeError, OSError):
            return library_doc, component_docs

        # Look for README.md in the library root
        readme_path = library_root / "README.md"
        if readme_path.exists():
            try:
                library_doc = readme_path.read_text(encoding="utf-8")
            except OSError:
                pass

        # Look for component documentation files
        for component_class in library_class.components:
            try:
                source_file = inspect.getfile(component_class)
                source_path = Path(source_file)

                # Look for {ClassName}.md adjacent to the .py file
                doc_path = source_path.parent / f"{component_class.__name__}.md"
                if doc_path.exists():
                    try:
                        component_docs[component_class.__name__] = doc_path.read_text(
                            encoding="utf-8"
                        )
                    except OSError:
                        pass
            except (TypeError, OSError):
                pass

        return library_doc, component_docs

    def _collect_data_files(
        self, library_class: type[ComponentLibrary]
    ) -> dict[str, bytes]:
        """
        Collect data files declared by the library.

        Returns:
            Dict mapping wheel-relative paths to file content bytes
        """
        if not hasattr(library_class, "data_files") or not library_class.data_files:
            return {}

        library_root = Path(inspect.getfile(library_class)).parent
        result: dict[str, bytes] = {}

        for wheel_prefix, source_rel_path in library_class.data_files.items():
            source_path = library_root / source_rel_path
            if source_path.is_file():
                result[wheel_prefix] = source_path.read_bytes()
            elif source_path.is_dir():
                for file in sorted(source_path.rglob("*")):
                    if file.is_file():
                        rel = file.relative_to(source_path)
                        result[f"{wheel_prefix}/{rel}"] = file.read_bytes()

        return result

    def _class_to_module_name(self, class_name: str) -> str:
        """Convert CamelCase class name to snake_case module name."""
        # Insert underscore before uppercase letters (except first)
        result = []
        for i, char in enumerate(class_name):
            if char.isupper() and i > 0:
                result.append("_")
            result.append(char.lower())
        return "".join(result)

    def _normalize_package_name(self, name: str) -> str:
        """Normalize library name to valid Python package name."""
        # Replace hyphens with underscores
        return name.replace("-", "_")

    def build(self, output_dir: str | Path | None = None) -> Path:
        """
        Build a .kcl package from the source file.

        The source file must contain a ComponentLibrary subclass that
        declares the library name, version, and list of components.

        Args:
            output_dir: Output directory for the package (default: dist/)

        Returns:
            Path to the created .kcl file

        Raises:
            ValueError: If no ComponentLibrary found in the source file
        """
        module, parent_dir = self._load_module()

        try:
            library_class = self._find_library_class(module)
            if library_class:
                return self._build_from_library(library_class, output_dir, parent_dir)

            raise ValueError(
                f"No ComponentLibrary subclass found in {self.source_path}"
            )
        finally:
            # Clean up sys.modules and sys.path
            # For __init__.py, the module was loaded under the directory name, not "stem"
            if self.source_path.name == "__init__.py":
                module_name = self.source_path.parent.name
            else:
                module_name = self.source_path.stem
            if module_name in sys.modules:
                del sys.modules[module_name]
            if str(parent_dir) in sys.path:
                sys.path.remove(str(parent_dir))

    def _build_from_library(
        self,
        library_class: type[ComponentLibrary],
        output_dir: str | Path | None,
        parent_dir: Path,
    ) -> Path:
        """Build wheel from a ComponentLibrary class."""
        # Build library version from semantic version fields
        library_version_parts = SemanticVersion(
            major=library_class.major,
            minor=library_class.minor,
            patch=library_class.patch,
            prerelease=library_class.prerelease,
        )
        library_version_string = library_version_parts.string

        # Create library version dict for component inheritance
        library_version_dict: dict[str, int | str | None] = {
            "major": library_class.major,
            "minor": library_class.minor,
            "patch": library_class.patch,
        }
        if library_class.prerelease:
            library_version_dict["prerelease"] = library_class.prerelease

        # Collect documentation from markdown files
        library_documentation, component_docs = self._collect_documentation(
            library_class
        )

        # Extract metadata for each component (with library version for inheritance)
        component_metadatas = []
        for component_class in library_class.components:
            # Get component-specific documentation if available
            component_doc = component_docs.get(component_class.__name__)
            component_metadata = extract_component_metadata(
                component_class, library_version_dict, documentation=component_doc
            )
            component_metadatas.append(component_metadata)

        # Create library metadata
        library_metadata = LibraryMetadata(
            name=library_class.name,
            version=library_version_string,
            version_parts=library_version_parts,
            description=library_class.description or None,
            documentation=library_documentation,
            components=component_metadatas,
        )

        # Resolve dependencies against platform manifest
        declared_deps = list(library_class.dependencies) if library_class.dependencies else []
        dep_info, deps_dir = resolve_dependencies(
            declared=declared_deps,
            include_deps=self.include_deps,
            platforms=self.platforms,
        )

        # Create full metadata wrapper
        metadata_wrapper = MetadataWrapper(
            manifest_version="2.0",
            library=library_metadata,
            build_info=BuildInfo(
                build_time=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                python_version=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
                builder_version="0.2.0",
                sdk_base_version=Component.SDK_BASE_VERSION,
            ),
            dependencies=dep_info if declared_deps else None,
        )

        # Collect source files for all components
        sources = self._collect_source_files(library_class)

        # Collect data files declared by library
        data_files = self._collect_data_files(library_class)

        # Record data file paths in metadata
        if data_files:
            library_metadata.data_files = sorted(data_files.keys())

        # Determine output directory
        if output_dir is None:
            resolved_output_dir = Path("dist")
        else:
            resolved_output_dir = Path(output_dir)

        # Build the wheel, then wrap in .kcl
        try:
            wheel_path = self._create_wheel(
                name=library_class.name,
                version=library_version_string,
                description=library_class.description,
                metadata_wrapper=metadata_wrapper,
                component_classes=library_class.components,
                sources=sources,
                output_dir=output_dir,
                parent_dir=parent_dir,
                data_files=data_files,
            )
            return self._wrap_in_kcl(wheel_path, metadata_wrapper, resolved_output_dir, deps_dir)
        finally:
            if deps_dir and deps_dir.exists():
                try:
                    shutil.rmtree(deps_dir)
                except OSError as e:
                    logger.warning("Failed to clean up deps directory %s: %s", deps_dir, e)

    def _wrap_in_kcl(
        self,
        wheel_path: Path,
        metadata_wrapper: MetadataWrapper,
        output_dir: Path,
        deps_dir: Path | None = None,
    ) -> Path:
        """
        Wrap a wheel file in a .kcl (Koios Component Library) archive.

        Creates a ZIP archive containing manifest.json, the wheel file, and
        optionally a deps/ directory with bundled dependency wheels.

        Args:
            wheel_path: Path to the .whl file to wrap
            metadata_wrapper: Metadata to write as manifest.json
            output_dir: Directory for the .kcl output
            deps_dir: Optional directory containing dependency wheel files
                      to include under deps/ in the archive

        Returns:
            Path to the created .kcl file
        """
        # Derive .kcl name from metadata: {package_name}-{version}.kcl
        library = metadata_wrapper.library
        package_name = self._normalize_package_name(library.name)
        kcl_name = f"{package_name}-{library.version}.kcl"
        kcl_path = output_dir / kcl_name

        with zipfile.ZipFile(kcl_path, "w", zipfile.ZIP_DEFLATED) as kcl:
            # Write manifest.json at the root
            kcl.writestr(
                "manifest.json",
                metadata_wrapper.model_dump_json(indent=2, exclude_none=True),
            )
            # Write the .whl file at the root (using its filename as entry name)
            kcl.write(wheel_path, wheel_path.name)

            # Write bundled dependency wheels under deps/
            if deps_dir and deps_dir.exists():
                for whl_file in sorted(deps_dir.glob("*.whl")):
                    kcl.write(whl_file, f"deps/{whl_file.name}")

        # Remove the intermediate .whl — it's now inside the .kcl
        wheel_path.unlink()

        return kcl_path

    def _create_wheel(
        self,
        name: str,
        version: str,
        description: str,
        metadata_wrapper: MetadataWrapper,
        component_classes: list[type[Component]],
        sources: dict[str, str],
        output_dir: str | Path | None,
        parent_dir: Path,
        data_files: dict[str, bytes] | None = None,
    ) -> Path:
        """Create the actual wheel file."""
        # Normalize package name
        package_name = self._normalize_package_name(name)

        # Determine output directory
        if output_dir is None:
            output_dir = Path("dist")
        else:
            output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        # Create wheel package
        wheel_name = f"{package_name}-{version}-py3-none-any.whl"
        wheel_path = output_dir / wheel_name

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create package structure
            package_dir = temp_path / package_name
            package_dir.mkdir()

            # Create __pycache__ for compiled files
            compiled_dir = package_dir / "__pycache__"
            compiled_dir.mkdir()

            # Write source files and compile
            for module_name, source_code in sources.items():
                source_file = package_dir / f"{module_name}.py"
                source_file.write_text(source_code, encoding="utf-8")

                # Compile to bytecode
                pyc_path = (
                    compiled_dir
                    / f"{module_name}.cpython-{sys.version_info.major}{sys.version_info.minor}.pyc"
                )
                py_compile.compile(str(source_file), str(pyc_path), doraise=True)

            # Create __init__.py that exports all component classes
            init_lines = []
            for component_class in component_classes:
                module_name = self._class_to_module_name(component_class.__name__)
                init_lines.append(
                    f"from .{module_name} import {component_class.__name__}"
                )

            # Add __all__ for explicit exports
            class_names = [c.__name__ for c in component_classes]
            init_lines.append("")
            init_lines.append(f"__all__ = {class_names!r}")

            (package_dir / "__init__.py").write_text(
                "\n".join(init_lines) + "\n", encoding="utf-8"
            )

            # Write data files
            if data_files:
                for rel_path, content_bytes in data_files.items():
                    data_file_path = package_dir / rel_path
                    data_file_path.parent.mkdir(parents=True, exist_ok=True)
                    data_file_path.write_bytes(content_bytes)

            # Create wheel structure (dist-info)
            dist_info_dir = temp_path / f"{package_name}-{version}.dist-info"
            dist_info_dir.mkdir()

            # Write METADATA
            metadata_content = f"""Metadata-Version: 2.1
Name: {name}
Version: {version}
Summary: {description or 'Component library'}
Requires-Python: >=3.12
"""
            (dist_info_dir / "METADATA").write_text(metadata_content, encoding="utf-8")

            # Write WHEEL
            wheel_content = """Wheel-Version: 1.0
Generator: koios-component-builder
Root-Is-Purelib: true
Tag: py3-none-any
"""
            (dist_info_dir / "WHEEL").write_text(wheel_content, encoding="utf-8")

            # Collect all files for RECORD
            record_entries: list[str] = []

            # Create wheel zip
            with zipfile.ZipFile(wheel_path, "w", zipfile.ZIP_DEFLATED) as wheel:
                # Add package files
                for file_path in package_dir.rglob("*"):
                    if file_path.is_file():
                        arcname = file_path.relative_to(temp_path)
                        wheel.write(file_path, arcname)
                        file_data = file_path.read_bytes()
                        file_hash = hashlib.sha256(file_data).hexdigest()
                        record_entries.append(
                            f"{arcname},sha256={file_hash},{len(file_data)}"
                        )

                # Add dist-info files (except RECORD)
                for file_path in dist_info_dir.rglob("*"):
                    if file_path.is_file() and file_path.name != "RECORD":
                        arcname = file_path.relative_to(temp_path)
                        wheel.write(file_path, arcname)
                        file_data = file_path.read_bytes()
                        file_hash = hashlib.sha256(file_data).hexdigest()
                        record_entries.append(
                            f"{arcname},sha256={file_hash},{len(file_data)}"
                        )

                # Write and add RECORD
                record_content = "\n".join(record_entries) + "\n"
                record_path = dist_info_dir / "RECORD"
                record_path.write_text(record_content, encoding="utf-8")
                arcname = record_path.relative_to(temp_path)
                wheel.write(record_path, arcname)

        return wheel_path
