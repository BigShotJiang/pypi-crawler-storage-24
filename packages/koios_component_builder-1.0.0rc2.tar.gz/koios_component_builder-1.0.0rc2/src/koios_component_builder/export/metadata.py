"""
Metadata extraction from component classes.

This module provides functionality to introspect component classes and extract
metadata about their inputs, outputs, and other properties for UI display.
"""

import inspect
from typing import Any

from koios_component_builder.component import (
    Component,
    get_canvas_settings,
    get_component_version,
)
from koios_component_builder.fields import (
    Config,
    ChoiceConfig,
    Input,
    NumberConfig,
    Output,
    StringConfig,
    get_config_fields,
    get_history_fields,
    get_input_fields,
    get_output_fields,
)
from koios_component_builder.models import (
    CanvasSettings,
    ComponentFieldMetadata,
    ComponentMetadata,
    SemanticVersion,
)


def get_allowed_types(field_descriptor: Input[Any] | Output[Any]) -> list[str] | None:
    """
    Extract allowed_types from a field descriptor.

    Args:
        field_descriptor: Input or Output field descriptor

    Returns:
        List of allowed type names as strings, or None if any type is allowed
    """
    allowed = getattr(field_descriptor, "allowed_types", None)
    if allowed is None:
        return None

    if not isinstance(allowed, (list, tuple)):
        allowed = [allowed]

    type_names = {
        float: "float",
        int: "int",
        bool: "bool",
        str: "str",
        list: "list",
        dict: "dict",
    }
    return [type_names.get(t, getattr(t, "__name__", str(t))) for t in allowed]


def get_field_type(field_descriptor: Input[Any] | Output[Any] | Config[Any]) -> str:
    """
    Extract Python type from a field descriptor.

    Args:
        field_descriptor: Input or Output field descriptor

    Returns:
        String representation of the type (e.g., "float", "int", "bool")
    """
    # Get the type from the generic parameter
    origin = getattr(field_descriptor, "__origin__", None)
    args = getattr(field_descriptor, "__args__", None)

    if origin and args:
        # Extract the type argument from Input[T] or Output[T]
        type_arg = args[0] if args else Any

        # Handle built-in types
        if type_arg is float:
            return "float"
        elif type_arg is int:
            return "int"
        elif type_arg is bool:
            return "bool"
        elif type_arg is str:
            return "str"
        elif type_arg is list:
            return "list"
        elif type_arg is dict:
            return "dict"
        else:
            # For other types, try to get the name
            if hasattr(type_arg, "__name__"):
                return type_arg.__name__
            elif hasattr(type_arg, "__qualname__"):
                return type_arg.__qualname__
            else:
                return str(type_arg)

    # Fallback: try to infer from default value
    if hasattr(field_descriptor, "default"):
        default = field_descriptor.default
        if default is not None:
            return type(default).__name__

    return "Any"


def get_config_validation(field_descriptor: Config[Any]) -> dict[str, Any]:
    """
    Extract validation constraints from a config field descriptor.

    Args:
        field_descriptor: Config field descriptor

    Returns:
        Dictionary with validation constraints
    """
    validation: dict[str, Any] = {
        "required": field_descriptor.required,
    }

    # Extract type-specific validation
    if isinstance(field_descriptor, StringConfig):
        if field_descriptor.regex:
            validation["regex"] = field_descriptor.regex
    elif isinstance(field_descriptor, NumberConfig):
        if field_descriptor.min_value is not None:
            validation["min_value"] = field_descriptor.min_value
        if field_descriptor.max_value is not None:
            validation["max_value"] = field_descriptor.max_value
    elif isinstance(field_descriptor, ChoiceConfig):
        if field_descriptor.choices:
            validation["choices"] = field_descriptor.choices

    return validation


def extract_component_metadata(
    component_class: type[Component],
    library_version: dict[str, Any] | None = None,
    documentation: str | None = None,
) -> ComponentMetadata:
    """
    Extract metadata from a component class.

    Args:
        component_class: The component class to introspect
        library_version: Optional library version dict to inherit if component
                         doesn't define its own version. Should have keys:
                         major, minor, patch, and optionally prerelease.
        documentation: Optional markdown documentation content for the component

    Returns:
        ComponentMetadata for the component

    Raises:
        ValueError: If the class is not a valid Component subclass
    """
    if not issubclass(component_class, Component):
        raise ValueError(f"Class {component_class.__name__} is not a Component subclass")

    # Extract class information
    class_name = component_class.__name__
    docstring = inspect.getdoc(component_class) or ""
    description = docstring.split("\n")[0] if docstring else ""

    # Extract version (from component Meta or fall back to library version)
    version_dict = get_component_version(component_class, library_version)
    version_parts = SemanticVersion(**version_dict)
    version_string = version_parts.string

    # Extract input fields (regular inputs)
    input_fields = get_input_fields(component_class)
    inputs = []
    for idx, (name, field_desc) in enumerate(input_fields.items()):
        # Use explicit order if set, otherwise use enumerated index for stable ordering
        order = field_desc._explicit_order if field_desc._explicit_order is not None else idx
        inputs.append(
            ComponentFieldMetadata(
                name=name,
                type=get_field_type(field_desc),
                default=field_desc.default,
                description=field_desc.description or "",
                order=order,
                allowed_types=get_allowed_types(field_desc),
                visible=getattr(field_desc, "visible", True),
                system=getattr(field_desc, "system", False),
            )
        )

    # Extract history fields and add to inputs with type="HistoryProvider"
    # This allows history fields to be treated as special inputs in the UI
    history_fields = get_history_fields(component_class)
    # Start history field ordering after regular inputs
    history_start_idx = len(input_fields)
    for idx, (name, field_desc) in enumerate(history_fields.items()):
        # Use explicit order if set, otherwise use enumerated index after regular inputs
        order = field_desc._explicit_order if field_desc._explicit_order is not None else (history_start_idx + idx)
        inputs.append(
            ComponentFieldMetadata(
                name=name,
                type="HistoryProvider",  # Distinguishes from regular inputs
                default=None,  # History fields always default to None
                description=field_desc.description or "",
                order=order,
                visible=getattr(field_desc, "visible", True),
                system=False,  # History fields are never system fields
            )
        )

    # Extract output fields
    output_fields = get_output_fields(component_class)
    outputs = []
    for idx, (name, field_desc) in enumerate(output_fields.items()):
        # Use explicit order if set, otherwise use enumerated index for stable ordering
        order = field_desc._explicit_order if field_desc._explicit_order is not None else idx
        outputs.append(
            ComponentFieldMetadata(
                name=name,
                type=get_field_type(field_desc),
                default=field_desc.default,
                description=field_desc.description or "",
                order=order,
                allowed_types=get_allowed_types(field_desc),
                visible=getattr(field_desc, "visible", True),
                system=getattr(field_desc, "system", False),
            )
        )

    # Extract config fields
    config_fields = get_config_fields(component_class)
    configs = []
    for idx, (name, field_desc) in enumerate(config_fields.items()):
        validation = get_config_validation(field_desc)
        # Use explicit order if set, otherwise use enumerated index for stable ordering
        order = field_desc._explicit_order if field_desc._explicit_order is not None else idx
        configs.append(
            ComponentFieldMetadata(
                name=name,
                type=get_field_type(field_desc),
                default=field_desc.default,
                description=field_desc.description or "",
                order=order,
                required=validation.get("required", False),
                min_value=validation.get("min_value"),
                max_value=validation.get("max_value"),
                regex=validation.get("regex"),
                choices=validation.get("choices"),
            )
        )

    # Extract canvas settings from Meta class
    canvas_dict = get_canvas_settings(component_class)
    canvas = CanvasSettings(**canvas_dict) if canvas_dict else None

    component_metadata = ComponentMetadata(
        name=class_name,
        class_name=class_name,
        version=version_string,
        version_parts=version_parts,
        description=description,
        documentation=documentation,
        inputs=inputs,
        outputs=outputs,
        configs=configs,
        canvas=canvas,
    )

    return component_metadata
