"""
Dependency resolver for component libraries.

Resolves declared dependencies against the platform manifest to determine
which packages need to be bundled into the .kcl archive. Platform packages
(pre-installed in the Koios container) are excluded from bundling.
"""

import json
import logging
import re
import subprocess
import sys
import tempfile
from functools import lru_cache
from pathlib import Path

from packaging.requirements import Requirement

from koios_component_builder.models import BundledPackage, DependencyInfo

logger = logging.getLogger(__name__)

# Default platforms for pip download (linux amd64 + arm64)
DEFAULT_PLATFORMS = [
    "manylinux2014_x86_64",
    "manylinux2014_aarch64",
]

PLATFORM_PACKAGES_PATH = (
    Path(__file__).parent.parent / "platform_packages.json"
)


@lru_cache(maxsize=1)
def load_platform_packages() -> dict[str, str]:
    """
    Load the platform package manifest.

    Returns:
        Dict mapping normalized package names to versions.
    """
    if not PLATFORM_PACKAGES_PATH.exists():
        logger.warning("Platform packages manifest not found: %s", PLATFORM_PACKAGES_PATH)
        return {}

    with open(PLATFORM_PACKAGES_PATH) as f:
        data = json.load(f)

    # Normalize all package names to lowercase for comparison
    return {
        _normalize_name(name): version
        for name, version in data.get("packages", {}).items()
    }


def _normalize_name(name: str) -> str:
    """Normalize a package name per PEP 503 (lowercase, separators to hyphens)."""
    return re.sub(r"[-_.]+", "-", name).lower()


def resolve_dependencies(
    declared: list[str],
    include_deps: bool = False,
    platforms: list[str] | None = None,
    python_version: str | None = None,
) -> tuple[DependencyInfo, Path | None]:
    """
    Resolve declared dependencies against the platform manifest.

    Args:
        declared: PEP 508 requirement strings from the library definition.
        include_deps: If True, download and bundle non-platform packages.
        platforms: Target platforms for pip download (default: linux amd64 + arm64).
        python_version: Python version for pip download (e.g., "3.12"). Defaults to current.

    Returns:
        Tuple of (DependencyInfo, deps_dir_or_None).
        deps_dir is a temporary directory containing downloaded wheels if
        include_deps=True and there are packages to bundle. Caller is
        responsible for cleanup.
    """
    if not declared:
        return DependencyInfo(), None

    platform_packages = load_platform_packages()
    platform_satisfied: list[str] = []
    to_bundle: list[str] = []

    for req_str in declared:
        req = Requirement(req_str)
        normalized = _normalize_name(req.name)

        if normalized in platform_packages:
            platform_satisfied.append(req.name)
            logger.info("Platform-satisfied: %s (container has %s)", req_str, platform_packages[normalized])
        else:
            to_bundle.append(req_str)
            logger.info("Needs bundling: %s", req_str)

    dep_info = DependencyInfo(
        declared=declared,
        platform_satisfied=platform_satisfied,
    )

    deps_dir = None

    if include_deps and to_bundle:
        deps_dir = Path(tempfile.mkdtemp(prefix="kcl-deps-"))
        bundled = _download_packages(
            to_bundle,
            deps_dir,
            platforms=platforms or DEFAULT_PLATFORMS,
            python_version=python_version or f"{sys.version_info.major}.{sys.version_info.minor}",
        )
        dep_info.bundled = bundled
    elif to_bundle and not include_deps:
        logger.warning(
            "Dependencies not satisfied by platform and --include-deps not set: %s. "
            "These must be available in the target environment.",
            ", ".join(to_bundle),
        )

    return dep_info, deps_dir


def _download_packages(
    requirements: list[str],
    output_dir: Path,
    platforms: list[str],
    python_version: str,
) -> list[BundledPackage]:
    """
    Download wheel files for the given requirements using pip.

    Args:
        requirements: PEP 508 requirement strings to download.
        output_dir: Directory to download wheels into.
        platforms: Target platform tags for pip download.
        python_version: Python version string (e.g., "3.12").

    Returns:
        List of BundledPackage with downloaded wheel info.

    Raises:
        RuntimeError: If pip download fails.
    """
    # Build pip download command
    cmd = [
        sys.executable, "-m", "pip", "download",
        "--dest", str(output_dir),
        "--only-binary=:all:",
        "--python-version", python_version,
    ]

    # Add platform flags
    for platform in platforms:
        cmd.extend(["--platform", platform])

    # Add each requirement
    cmd.extend(requirements)

    logger.info("Downloading dependencies: %s", " ".join(cmd))

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=300,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"pip download failed (exit {result.returncode}):\n{result.stderr}"
        )

    # Parse downloaded wheels into BundledPackage entries
    # Group wheel files by package name
    wheels_by_package: dict[str, list[str]] = {}
    versions_by_package: dict[str, str] = {}

    for whl_file in sorted(output_dir.glob("*.whl")):
        # Wheel filename format: {name}-{version}(-{build})?-{python}-{abi}-{platform}.whl
        parts = whl_file.name.split("-")
        if len(parts) >= 3:
            pkg_name = _normalize_name(parts[0])
            pkg_version = parts[1]
            wheels_by_package.setdefault(pkg_name, []).append(whl_file.name)
            versions_by_package[pkg_name] = pkg_version

    bundled = []
    for pkg_name in sorted(wheels_by_package):
        bundled.append(BundledPackage(
            name=pkg_name,
            version=versions_by_package[pkg_name],
            wheels=wheels_by_package[pkg_name],
        ))

    return bundled
