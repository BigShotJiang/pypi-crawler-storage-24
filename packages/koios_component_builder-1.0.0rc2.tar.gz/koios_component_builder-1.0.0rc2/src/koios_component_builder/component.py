"""
Base Component class for the Koios Component Builder SDK.

This module provides the base class that all user components must extend.
Components define Input and Output fields, and implement an execute() method
that contains their logic.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, ClassVar

from koios_component_builder.fields import (
    Config,
    FieldDescriptor,
    HistoryInput,
    Input,
    Output,
    get_config_fields,
    get_history_fields,
    get_input_fields,
    get_output_fields,
)

logger = logging.getLogger(__name__)


class ComponentMeta:
    """
    Base class for component metadata configuration.

    Override in your component's inner Meta class to customize visual
    and behavioral settings. All settings are optional and have sensible defaults.

    Example:
        class MyComponent(Component):
            class Meta:
                canvas_width = 8  # Wider node for more fields
                icon = "chart-line"  # Custom Tabler icon
                category = "Analysis"  # Library grouping
                # Optional: component-specific version (overrides library version)
                major = 2
                minor = 0
                patch = 1

    Available settings:
        canvas_width: Node width in grid units (4-15). Default uses system default (6).
        icon: Tabler icon name in kebab-case (e.g., "chart-line", "cpu", "database").
              See ComponentIcon for common options. Default is "puzzle".
        category: Library category for grouping in the UI. See ComponentCategory for
                  standard options. Custom categories are allowed. Default is "Miscellaneous".
        canvas_minimal: Render in minimal mode (compact, no header/footer). Default is False.
                        Use for simple components like logic gates, bitwise operations, etc.

    Version settings (optional - inherits from library if not specified):
        major: Major version number (breaking changes)
        minor: Minor version number (new features, backward compatible)
        patch: Patch version number (bug fixes)
        prerelease: Pre-release tag (e.g., "alpha", "beta.1", "rc.2")
    """

    # Canvas display settings
    canvas_width: int | None = None  # None = use system default (6 grid units)
    icon: str | None = None  # Tabler icon name in kebab-case (e.g., "chart-line")
    category: str | None = None  # Library category (e.g., "Analysis", "Control")
    canvas_minimal: bool | None = None  # Minimal mode (compact, no header/footer)

    # Version settings (None = inherit from library)
    major: int | None = None
    minor: int | None = None
    patch: int | None = None
    prerelease: str | None = None

    # Future settings (reserved for extensibility):
    # color: str | None = None       # Node accent color


class ComponentIcon:
    """
    Common Tabler icon names for use in Component.Meta.icon.

    These are kebab-case names that map to Tabler React icons.
    You can use any valid Tabler icon name, not just these constants.

    Example:
        class MyComponent(Component):
            class Meta:
                icon = ComponentIcon.CHART_LINE

    Browse all icons at: https://tabler.io/icons
    """

    # Default
    PUZZLE = "puzzle"

    # Math & Logic
    CALCULATOR = "calculator"
    MATH = "math"
    PLUS_MINUS = "plus-minus"
    PERCENTAGE = "percentage"
    SUM = "sum"

    # Charts & Analysis
    CHART_LINE = "chart-line"
    CHART_BAR = "chart-bar"
    CHART_AREA = "chart-area"
    CHART_PIE = "chart-pie"
    CHART_DOTS = "chart-dots"
    TRENDING_UP = "trending-up"
    TRENDING_DOWN = "trending-down"
    REPORT_ANALYTICS = "report-analytics"

    # Data & Database
    DATABASE = "database"
    TABLE = "table"
    LIST = "list"
    FILTER = "filter"
    SORT_ASCENDING = "sort-ascending"
    SORT_DESCENDING = "sort-descending"

    # Time & History
    CLOCK = "clock"
    HISTORY = "history"
    CALENDAR = "calendar"
    HOURGLASS = "hourglass"

    # Hardware & Devices
    CPU = "cpu"
    DEVICE_DESKTOP = "device-desktop"
    SERVER = "server"
    ROUTER = "router"
    ANTENNA = "antenna"

    # Sensors & Measurement
    THERMOMETER = "thermometer"
    GAUGE = "gauge"
    RULER = "ruler"
    SCALE = "scale"

    # Control & Automation
    TOGGLE_LEFT = "toggle-left"
    TOGGLE_RIGHT = "toggle-right"
    ADJUSTMENTS = "adjustments"
    SETTINGS = "settings"
    ADJUSTMENTS_HORIZONTAL = "adjustments-horizontal"

    # Alerts & Status
    ALERT_TRIANGLE = "alert-triangle"
    ALERT_CIRCLE = "alert-circle"
    BELL = "bell"
    CHECK = "check"
    X = "x"

    # Flow & Process
    ARROWS_SPLIT = "arrows-split"
    ARROWS_JOIN = "arrows-join"
    ARROW_RIGHT = "arrow-right"
    REFRESH = "refresh"
    ROTATE = "rotate"

    # Communication
    SEND = "send"
    MAIL = "mail"
    MESSAGE = "message"
    WEBHOOK = "webhook"
    API = "api"

    # Files & Storage
    FILE = "file"
    FOLDER = "folder"
    DOWNLOAD = "download"
    UPLOAD = "upload"

    # Misc
    BOLT = "bolt"
    FLAME = "flame"
    DROPLET = "droplet"
    SUN = "sun"
    MOON = "moon"
    CLOUD = "cloud"
    WAVE_SQUARE = "wave-square"
    WAVE_SINE = "wave-sine"
    BINARY = "binary"
    CODE = "code"
    FUNCTION = "math-function"
    TRANSFORM = "transform"


class ComponentCategory:
    """
    Standard category names for use in Component.Meta.category.

    Categories are used to group components in the library tray.
    You can use any string as a category, not just these constants.
    Components without a category default to "Miscellaneous".

    Example:
        class MyComponent(Component):
            class Meta:
                category = ComponentCategory.ANALYSIS

    """

    # Default category for components without one
    MISCELLANEOUS = "Miscellaneous"

    # Data processing
    ANALYSIS = "Analysis"
    TRANSFORM = "Transform"
    FILTER = "Filter"
    AGGREGATE = "Aggregate"

    # Control systems
    CONTROL = "Control"
    LOGIC = "Logic"
    AUTOMATION = "Automation"

    # Math operations
    MATH = "Math"
    STATISTICS = "Statistics"

    # I/O and communication
    INPUT = "Input"
    OUTPUT = "Output"
    COMMUNICATION = "Communication"

    # Time-based
    TIMING = "Timing"
    SCHEDULING = "Scheduling"

    # Monitoring
    MONITORING = "Monitoring"
    ALERTING = "Alerting"


class ComponentStatus:
    """
    Status values for the system `status` output field.

    The engine writes this field to indicate component execution state:
    - STOPPED (0): Component is disabled (enable=False)
    - RUNNING (1): Component executed successfully
    - FAILED (2): Component execution threw an exception
    """

    STOPPED = 0
    RUNNING = 1
    FAILED = 2


def get_meta_value(
    component_class: type["Component"], attr: str, default: Any = None
) -> Any:
    """
    Get a Meta attribute value from a component class.

    Walks the MRO to find the most specific Meta class definition.

    Args:
        component_class: The component class to inspect
        attr: The Meta attribute name to retrieve
        default: Default value if attribute is not set or is None

    Returns:
        The attribute value, or default if not found/None
    """
    for cls in component_class.__mro__:
        if hasattr(cls, "Meta") and hasattr(cls.Meta, attr):
            value = getattr(cls.Meta, attr)
            if value is not None:
                return value
    return default


def get_canvas_settings(component_class: type["Component"]) -> dict[str, Any]:
    """
    Extract canvas-related settings from a component's Meta class.

    Args:
        component_class: The component class to inspect

    Returns:
        Dictionary with canvas settings (only includes non-None values)

    Raises:
        ValueError: If canvas_width is outside valid range (4-15)
    """
    settings: dict[str, Any] = {}

    width = get_meta_value(component_class, "canvas_width")
    if width is not None:
        if not isinstance(width, int):
            raise ValueError(f"canvas_width must be an integer, got {type(width).__name__}")
        if not (4 <= width <= 15):
            raise ValueError(f"canvas_width must be between 4 and 15, got {width}")
        settings["width"] = width

    icon = get_meta_value(component_class, "icon")
    if icon is not None:
        if not isinstance(icon, str):
            raise ValueError(f"icon must be a string, got {type(icon).__name__}")
        # Normalize to kebab-case (in case user passes IconChartLine style)
        icon = icon.strip()
        if icon:
            settings["icon"] = icon

    category = get_meta_value(component_class, "category")
    if category is not None:
        if not isinstance(category, str):
            raise ValueError(f"category must be a string, got {type(category).__name__}")
        category = category.strip()
        if category:
            settings["category"] = category

    minimal = get_meta_value(component_class, "canvas_minimal")
    if minimal is not None:
        if not isinstance(minimal, bool):
            raise ValueError(f"canvas_minimal must be a boolean, got {type(minimal).__name__}")
        settings["minimal"] = minimal

    return settings


def get_component_version(
    component_class: type["Component"],
    library_version: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Extract version settings from a component's Meta class.

    If the component doesn't define version fields, falls back to the library version.
    If no library version is provided, defaults to 1.0.0.

    Args:
        component_class: The component class to inspect
        library_version: Optional library version dict with major, minor, patch, prerelease

    Returns:
        Dictionary with version fields: major, minor, patch, prerelease (if set)

    Raises:
        ValueError: If version fields have invalid types
    """
    # Check if component has its own version (major is the indicator)
    major = get_meta_value(component_class, "major")

    if major is not None:
        # Component has its own version
        minor = get_meta_value(component_class, "minor")
        patch = get_meta_value(component_class, "patch", 0)
        prerelease = get_meta_value(component_class, "prerelease")

        # Validate types
        if not isinstance(major, int) or major < 0:
            raise ValueError(f"Meta.major must be a non-negative integer, got {major!r}")
        if minor is None:
            raise ValueError("Meta.minor is required when Meta.major is specified")
        if not isinstance(minor, int) or minor < 0:
            raise ValueError(f"Meta.minor must be a non-negative integer, got {minor!r}")
        if not isinstance(patch, int) or patch < 0:
            raise ValueError(f"Meta.patch must be a non-negative integer, got {patch!r}")

        version: dict[str, Any] = {
            "major": major,
            "minor": minor,
            "patch": patch,
        }
        if prerelease:
            version["prerelease"] = prerelease
        return version

    # Fall back to library version or default
    if library_version:
        return library_version

    # Default version
    return {"major": 1, "minor": 0, "patch": 0}


class Component(ABC):
    """
    Base class for all Koios components.

    Components define their inputs and outputs using the Input and Output
    field descriptors, and implement the execute() method to define their logic.

    All components automatically inherit system fields:
    - enable (Input[bool]): When False, engine skips component execution
    - error (Output[bool]): Set True by engine when execution throws exception

    Example::

        class SimpleAdder(Component):
            class Meta:
                icon = ComponentIcon.SUM
                category = ComponentCategory.MATH

            a: Input[float] = Input(default=0.0, description="First number")
            b: Input[float] = Input(default=0.0, description="Second number")
            result: Output[float] = Output(default=0.0, description="Sum")

            def execute(self) -> None:
                self.result = self.a + self.b
    """

    # SDK base version - increment when base fields or behavior change
    # This is stored in build_info.sdk_base_version in the manifest
    SDK_BASE_VERSION: ClassVar[int] = 2

    # System fields - inherited by all subclasses, hidden by default
    # These are marked with system=True so metadata extraction can identify them
    # order=-1000 ensures they sort before user-defined fields
    enable: Input[bool] = Input(
        default=True,
        description="Enable component execution",
        visible=False,
        system=True,
        order=-1000,
    )
    error: Output[bool] = Output(
        default=False,
        description="Error flag set on execution failure",
        visible=False,
        system=True,
        order=-1000,
    )
    status: Output[int] = Output(
        default=0,
        description="Component status: 0=STOPPED, 1=RUNNING, 2=FAILED",
        visible=False,
        system=True,
        order=-999,
    )

    class Meta(ComponentMeta):
        """Default metadata configuration. Override in subclasses to customize."""

        pass

    def __init_subclass__(cls, **kwargs: object) -> None:
        """Validate component definition at class creation time."""
        super().__init_subclass__(**kwargs)

        # Skip validation for abstract classes (they don't need fields yet)
        if ABC in cls.__bases__:
            return

        # Check for common annotation mistakes: bare type annotation with a
        # descriptor value (e.g., `x: float = Input(...)` instead of
        # `x: Input[float] = Input(...)`). This works at runtime but breaks
        # type checker inference — the IDE won't know `self.x` returns float.
        hints = {}
        try:
            hints = {
                k: v
                for k, v in cls.__annotations__.items()
                if not k.startswith("_")
            }
        except Exception:
            pass

        for attr_name, annotation in hints.items():
            attr = cls.__dict__.get(attr_name)
            if attr is None:
                continue
            # If the value is a field descriptor but the annotation is a plain
            # type (float, int, str, bool, list, dict), warn the user.
            # Skip if the annotation is itself a FieldDescriptor subclass
            # (e.g., `x: NumberConfig = NumberConfig(...)` is correct).
            if (
                isinstance(attr, FieldDescriptor)
                and isinstance(annotation, type)
                and not issubclass(annotation, FieldDescriptor)
            ):
                descriptor_type = type(attr).__name__
                logger.warning(
                    "%s.%s: annotation should be %s[%s] instead of %s "
                    "for proper type checker support. "
                    "Example: %s: %s[%s] = %s(...)",
                    cls.__name__,
                    attr_name,
                    descriptor_type,
                    annotation.__name__,
                    annotation.__name__,
                    attr_name,
                    descriptor_type,
                    annotation.__name__,
                    descriptor_type,
                )

    def __init__(self, component_id: str) -> None:
        """
        Initialize the component.

        Args:
            component_id: Unique identifier for this component instance
        """
        self.component_id = component_id
        self._setup_complete = False

        #: Logger for this component instance. Use ``self.logger.info(...)``,
        #: ``self.logger.warning(...)``, etc. in ``setup()`` and ``execute()``.
        self.logger: logging.Logger = logging.getLogger(
            f"koios.component.{component_id}"
        )

        # Initialize all fields with their default values
        self._initialize_fields()

    def _initialize_fields(self) -> None:
        """Initialize all fields with their default values."""
        for name, field_desc in get_input_fields(self.__class__).items():
            storage_name = f"_field_{name}"
            setattr(self, storage_name, field_desc.default)

        for name, field_desc in get_output_fields(self.__class__).items():
            storage_name = f"_field_{name}"
            setattr(self, storage_name, field_desc.default)

        for name, field_desc in get_config_fields(self.__class__).items():
            storage_name = f"_field_{name}"
            setattr(self, storage_name, field_desc.default)

        # History fields default to None (will be set by engine if wired)
        for name, field_desc in get_history_fields(self.__class__).items():
            storage_name = f"_field_{name}"
            setattr(self, storage_name, None)

    def setup(self) -> None:
        """
        One-time initialization hook called before the first execute().

        Override this to perform expensive setup that should only happen once,
        such as loading models, creating registries, or opening connections.

        All field values are available when setup() runs:
        - Config fields have their configured values (from the UI)
        - Input fields have their initial values (defaults or offline values)
        - Output fields have their default values

        If setup() raises an exception, the component is marked FAILED and
        setup() will be retried on the next execution cycle.

        Example::

            class UnitConverter(Component):
                decimals: NumberConfig = NumberConfig(default=2, min_value=0, max_value=6)
                value: Input[float] = Input(default=0.0)
                result: Output[float] = Output(default=0.0)

                def setup(self) -> None:
                    from pint import UnitRegistry
                    self._ureg = UnitRegistry()

                def execute(self) -> None:
                    temp = self._ureg.Quantity(self.value, self._ureg.degF)
                    self.result = round(temp.to(self._ureg.degC).magnitude, int(self.decimals))
        """
        pass

    @abstractmethod
    def execute(self) -> None:
        """
        Execute the component logic.

        This method is called each execution cycle. Subclasses must implement
        this to define their component's behavior.

        The typical pattern is:
        1. Read input fields (populated by the component engine)
        2. Perform calculations
        3. Write to output fields
        """
        pass

    def get_input_fields(self) -> dict[str, Input[Any]]:
        """Get all input fields defined on this component."""
        return get_input_fields(self.__class__)

    def get_output_fields(self) -> dict[str, Output[Any]]:
        """Get all output fields defined on this component."""
        return get_output_fields(self.__class__)

    def get_config_fields(self) -> dict[str, Config[Any]]:
        """Get all config fields defined on this component."""
        return get_config_fields(self.__class__)

    def get_history_fields(self) -> dict[str, HistoryInput]:
        """Get all history input fields defined on this component."""
        return get_history_fields(self.__class__)

    def to_dict(self) -> dict[str, Any]:
        """
        Serialize the component to a dictionary.

        Returns:
            Dictionary representation of the component
        """
        inputs = {}
        for name, field_desc in get_input_fields(self.__class__).items():
            inputs[name] = {
                "value": getattr(self, name),
                "default": field_desc.default,
                "description": field_desc.description,
            }

        outputs = {}
        for name, field_desc in get_output_fields(self.__class__).items():
            outputs[name] = {
                "value": getattr(self, name),
                "default": field_desc.default,
                "description": field_desc.description,
            }

        configs = {}
        for name, field_desc in get_config_fields(self.__class__).items():
            configs[name] = {
                "value": getattr(self, name),
                "default": field_desc.default,
                "description": field_desc.description,
            }

        return {
            "component_id": self.component_id,
            "class": self.__class__.__name__,
            "inputs": inputs,
            "outputs": outputs,
            "configs": configs,
        }

    def __repr__(self) -> str:
        """String representation of the component."""
        input_count = len(get_input_fields(self.__class__))
        output_count = len(get_output_fields(self.__class__))
        config_count = len(get_config_fields(self.__class__))
        history_count = len(get_history_fields(self.__class__))
        parts = [
            f"id='{self.component_id}'",
            f"inputs={input_count}",
            f"outputs={output_count}",
            f"configs={config_count}",
        ]
        if history_count > 0:
            parts.append(f"history={history_count}")
        return f"{self.__class__.__name__}({', '.join(parts)})"
