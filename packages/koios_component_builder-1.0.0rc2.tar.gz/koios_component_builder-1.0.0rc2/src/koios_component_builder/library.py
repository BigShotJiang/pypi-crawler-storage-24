"""
ComponentLibrary class for packaging multiple components as a single wheel.

This module provides the base class for declaring a library of components
that can be packaged together into a single wheel file.
"""

from typing import ClassVar

from koios_component_builder.component import Component


class ComponentLibrary:
    """
    Declares a collection of components for packaging as a single wheel.

    Users extend this class to define a library with a name, version, and
    list of component classes. The koios-component-builder CLI will package
    all components into a single wheel file.

    Version is specified using semantic versioning fields:
    - major: Breaking changes (required)
    - minor: New features, backward compatible (required)
    - patch: Bug fixes, backward compatible (default: 0)
    - prerelease: Optional pre-release tag (e.g., "alpha", "beta.1", "rc.2")

    Example:
        from koios_component_builder import ComponentLibrary
        from .math import Adder, Multiplier, Divider
        from .control import PIDController, Threshold

        class StandardLibrary(ComponentLibrary):
            name = "koios-standard-library"
            major = 1
            minor = 0
            patch = 0
            description = "Standard components included with Koios"
            components = [
                Adder,
                Multiplier,
                Divider,
                PIDController,
                Threshold,
            ]

        # Pre-release example:
        class BetaLibrary(ComponentLibrary):
            name = "experimental-library"
            major = 2
            minor = 0
            patch = 0
            prerelease = "beta.1"  # Results in version "2.0.0-beta.1"
            components = [NewFeature]

    Build with:
        koios-component-builder export standard_library.py -o dist/
        # Creates: dist/koios_standard_library-1.0.0.kcl

        # Bundle non-platform dependencies into the .kcl:
        koios-component-builder export my_protocol.py --include-deps
    """

    # Required: unique library identifier (becomes wheel name)
    name: ClassVar[str]

    # Required: semantic version fields
    major: ClassVar[int]
    minor: ClassVar[int]
    patch: ClassVar[int] = 0
    prerelease: ClassVar[str | None] = None

    # Optional: description for UI display
    description: ClassVar[str] = ""

    # Required: list of Component subclasses to include in the wheel
    components: ClassVar[list[type[Component]]] = []

    # Optional: third-party package dependencies (PEP 508 requirement strings)
    # Platform packages (pre-installed in Koios container) are detected automatically
    # and not bundled. Non-platform packages are bundled when --include-deps is used.
    # Example: dependencies = ["pyserial>=3.5", "crcmod"]
    dependencies: ClassVar[list[str]] = []

    # Optional: data files to include in the wheel package
    # Maps wheel-relative path prefix to source-relative path (from library root)
    # Example: {"eds": "eds"} copies library_root/eds/* → wheel/package/eds/*
    data_files: ClassVar[dict[str, str]] = {}

    def __init_subclass__(cls, **kwargs: object) -> None:
        """Validate library definition when subclass is created."""
        super().__init_subclass__(**kwargs)

        # Validate required attributes
        if not hasattr(cls, "name") or not cls.name:
            raise TypeError(f"ComponentLibrary subclass {cls.__name__} must define 'name'")

        # Validate version fields
        if not hasattr(cls, "major"):
            raise TypeError(
                f"ComponentLibrary subclass {cls.__name__} must define 'major' version"
            )
        if not hasattr(cls, "minor"):
            raise TypeError(
                f"ComponentLibrary subclass {cls.__name__} must define 'minor' version"
            )

        # Validate version field types
        if not isinstance(cls.major, int) or cls.major < 0:
            raise TypeError(
                f"ComponentLibrary.major must be a non-negative integer, got {cls.major!r}"
            )
        if not isinstance(cls.minor, int) or cls.minor < 0:
            raise TypeError(
                f"ComponentLibrary.minor must be a non-negative integer, got {cls.minor!r}"
            )
        if not isinstance(cls.patch, int) or cls.patch < 0:
            raise TypeError(
                f"ComponentLibrary.patch must be a non-negative integer, got {cls.patch!r}"
            )

        # Validate components list
        if not hasattr(cls, "components"):
            cls.components = []

        for comp in cls.components:
            if not isinstance(comp, type) or not issubclass(comp, Component):
                raise TypeError(
                    f"ComponentLibrary.components must contain Component subclasses, "
                    f"got {comp!r}"
                )

    @classmethod
    def get_version(cls) -> str:
        """Get the full version string (e.g., '1.0.0' or '1.0.0-beta.1')."""
        base = f"{cls.major}.{cls.minor}.{cls.patch}"
        return f"{base}-{cls.prerelease}" if cls.prerelease else base

    @classmethod
    def get_component_names(cls) -> list[str]:
        """Get the names of all components in this library."""
        return [comp.__name__ for comp in cls.components]
