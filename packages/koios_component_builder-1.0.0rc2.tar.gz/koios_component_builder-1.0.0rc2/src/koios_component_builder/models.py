"""
Pydantic models for component metadata.

Provides strongly-typed models for component metadata, fields, and validation.
All wheels use the library format (manifest_version 2.0).
"""

from typing import Any

from pydantic import BaseModel, Field, computed_field


class SemanticVersion(BaseModel):
    """
    Semantic version with optional pre-release tag.

    Supports versions like:
    - 1.0.0
    - 2.1.0-alpha
    - 3.0.0-beta.1
    - 1.0.0-rc.2
    """

    major: int = Field(ge=0, description="Major version number")
    minor: int = Field(ge=0, description="Minor version number")
    patch: int = Field(default=0, ge=0, description="Patch version number")
    prerelease: str | None = Field(
        default=None,
        description="Pre-release tag (e.g., alpha, beta.1, rc.2)",
    )

    @computed_field
    @property
    def string(self) -> str:
        """Return version as string: 1.0.0 or 1.0.0-beta.1"""
        base = f"{self.major}.{self.minor}.{self.patch}"
        return f"{base}-{self.prerelease}" if self.prerelease else base

    def __str__(self) -> str:
        return self.string


class ComponentFieldMetadata(BaseModel):
    """
    Metadata for a single component field (input, output, or config).

    For config fields, validation constraints are included.
    """

    name: str
    type: str  # "float", "int", "bool", "str", "list", "dict", etc.
    default: Any = Field(default=None)
    description: str = ""
    # Display order (lower values appear first, system fields use negative values)
    order: int = Field(default=0, description="Display order (lower values first)")
    # Allowed types for wiring validation (None means "any" - accept all types)
    allowed_types: list[str] | None = Field(
        default=None,
        description="Allowed types for wiring. None means 'any'.",
    )
    # Validation constraints (for config fields)
    required: bool = False
    min_value: float | None = Field(default=None)
    max_value: float | None = Field(default=None)
    regex: str | None = Field(default=None)
    choices: list[str] | None = Field(default=None)
    # Visibility and system field flags
    visible: bool = True  # Whether field is visible by default in UI
    system: bool = False  # True for system-injected fields (enable, error)

    class Config:
        json_schema_extra = {
            "examples": [
                {
                    "name": "temperature",
                    "type": "float",
                    "default": 0.0,
                    "description": "Temperature sensor reading",
                },
                {
                    "name": "ip_address",
                    "type": "str",
                    "default": "127.0.0.1",
                    "description": "Server IP address",
                    "required": True,
                    "regex": r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$",
                },
            ]
        }


class CanvasSettings(BaseModel):
    """Canvas display settings for a component node."""

    width: int | None = Field(
        default=None,
        ge=4,
        le=15,
        description="Node width in grid units (4-15). None uses system default.",
    )
    icon: str | None = Field(
        default=None,
        description="Tabler icon name in kebab-case (e.g., 'chart-line'). None uses default 'puzzle'.",
    )
    category: str | None = Field(
        default=None,
        description="Library category for grouping (e.g., 'Analysis'). None defaults to 'Miscellaneous'.",
    )
    minimal: bool | None = Field(
        default=None,
        description="Render in minimal mode (compact, no header/footer). None defaults to False.",
    )


class ComponentMetadata(BaseModel):
    """Metadata for a single component within a library.

    Note: History fields (HistoryInput) are included in the 'inputs' list
    with type="HistoryProvider" to distinguish them from regular inputs.
    """

    name: str
    class_name: str
    version: str = Field(description="Version string (e.g., '1.0.0' or '1.0.0-beta')")
    version_parts: SemanticVersion = Field(description="Structured version for comparison")
    description: str = ""
    documentation: str | None = Field(
        default=None,
        description="Markdown documentation for the component (from {module_name}.md)",
    )
    inputs: list[ComponentFieldMetadata] = Field(default_factory=list)
    outputs: list[ComponentFieldMetadata] = Field(default_factory=list)
    configs: list[ComponentFieldMetadata] = Field(default_factory=list)
    canvas: CanvasSettings | None = Field(
        default=None, description="Canvas display settings"
    )


class LibraryMetadata(BaseModel):
    """Metadata for a component library (wheel package)."""

    name: str
    version: str = Field(description="Version string (e.g., '1.0.0' or '1.0.0-beta')")
    version_parts: SemanticVersion = Field(description="Structured version for comparison")
    description: str | None = None
    documentation: str | None = Field(
        default=None,
        description="Markdown documentation for the library (from README.md)",
    )
    components: list[ComponentMetadata] = Field(default_factory=list)
    data_files: list[str] | None = Field(
        default=None,
        description="Data files included in the wheel package",
    )


class BuildInfo(BaseModel):
    """Build information for a component package."""

    build_time: str
    python_version: str
    builder_version: str
    sdk_base_version: int = Field(
        default=1,
        description="Version of the Component base class used to build this package",
    )


class BundledPackage(BaseModel):
    """A third-party package bundled in the .kcl deps/ directory."""

    name: str = Field(description="Package name (e.g., 'crcmod')")
    version: str = Field(description="Installed version (e.g., '1.7')")
    wheels: list[str] = Field(
        default_factory=list,
        description="Wheel filenames in deps/ (may include multiple platforms)",
    )


class DependencyInfo(BaseModel):
    """Dependency information for a .kcl package."""

    declared: list[str] = Field(
        default_factory=list,
        description="PEP 508 requirement strings declared by the library",
    )
    platform_satisfied: list[str] = Field(
        default_factory=list,
        description="Package names satisfied by the Koios platform (not bundled)",
    )
    bundled: list[BundledPackage] = Field(
        default_factory=list,
        description="Packages bundled in deps/ directory",
    )


class MetadataWrapper(BaseModel):
    """Top-level metadata wrapper for library format (manifest_version 2.0)."""

    manifest_version: str = "2.0"
    library: LibraryMetadata
    build_info: BuildInfo | None = None
    dependencies: DependencyInfo | None = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to dictionary for JSONField compatibility.

        Returns:
            Dictionary representation of the metadata
        """
        return self.model_dump(exclude_none=True)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MetadataWrapper":
        """
        Create from dictionary.

        Args:
            data: Dictionary containing metadata

        Returns:
            MetadataWrapper instance
        """
        return cls.model_validate(data)

    def get_library_dict(self) -> dict[str, Any]:
        """
        Get just the library metadata as a dictionary.

        Returns:
            Dictionary containing library metadata
        """
        return self.library.model_dump(exclude_none=True)


