"""
CLI commands for koios-component-builder.
"""

from koios_component_builder.cli.main import cli

__all__ = ["cli"]
