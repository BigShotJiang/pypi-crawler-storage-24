"""
Main CLI entry point for koios-component-builder.
"""

import click

from koios_component_builder.cli.export import export_command
from koios_component_builder.cli.platform import platform_packages_command


@click.group()
def cli() -> None:
    """Koios Component Builder CLI."""
    pass


cli.add_command(export_command, name="export")
cli.add_command(platform_packages_command)
