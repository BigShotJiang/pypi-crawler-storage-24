"""
Export command for building component library packages.

Outputs a .kcl (Koios Component Library) archive containing a manifest.json
and a pip-installable wheel.

Version is determined from the ComponentLibrary class using semantic versioning
fields: major, minor, patch, prerelease.
"""

import sys
from pathlib import Path

import click

from koios_component_builder.export.library_builder import LibraryBuilder


@click.command()
@click.argument("source_path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    default="dist",
    help="Output directory for the package (default: dist/)",
)
@click.option(
    "--include-deps",
    is_flag=True,
    default=False,
    help="Download and bundle non-platform dependencies into the .kcl package.",
)
@click.option(
    "--platform",
    "platforms",
    multiple=True,
    help=(
        "Target platform tag for pip download (e.g., manylinux2014_x86_64). "
        "Can be specified multiple times. Defaults to linux amd64 + arm64."
    ),
)
def export_command(
    source_path: Path,
    output: Path,
    include_deps: bool,
    platforms: tuple[str, ...],
) -> None:
    """
    Export a component library to a .kcl package.

    Builds a Koios Component Library (.kcl) package from a source file or
    package directory containing a ComponentLibrary subclass.

    The .kcl file is a ZIP archive containing manifest.json (metadata) and a
    pip-installable .whl (Python wheel).

    Examples:
        koios-component-builder export my_library/

        koios-component-builder export my_library/ -o ./packages

        koios-component-builder export my_library/ --include-deps
    """
    try:
        click.echo(f"Building package from {source_path}...")

        builder = LibraryBuilder(
            source_path,
            include_deps=include_deps,
            platforms=list(platforms) if platforms else None,
        )
        kcl_path = builder.build(output_dir=output)

        click.echo(f"Package built successfully: {kcl_path}")

    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Unexpected error: {e}", err=True)
        sys.exit(1)
