"""
Platform packages command for listing pre-installed packages.

Displays the packages available in the Koios production container,
helping library authors know what they can import without bundling.
"""

import click

from koios_component_builder.export.dependency_resolver import load_platform_packages


@click.command("platform-packages")
def platform_packages_command() -> None:
    """
    List packages pre-installed in the Koios container.

    These packages are available to all components at runtime without
    needing to declare them as dependencies. Any package not in this
    list must be declared in the library's dependencies and bundled
    with --include-deps.
    """
    packages = load_platform_packages()

    if not packages:
        click.echo("No platform packages manifest found.", err=True)
        raise SystemExit(1)

    click.echo(f"Koios platform packages ({len(packages)} available):\n")
    # Display sorted by name, unnormalized for readability
    for name, version in sorted(packages.items()):
        click.echo(f"  {name}=={version}")
