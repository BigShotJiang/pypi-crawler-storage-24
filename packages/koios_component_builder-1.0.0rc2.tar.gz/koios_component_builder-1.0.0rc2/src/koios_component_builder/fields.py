"""
Field descriptors for component inputs, outputs, and configuration.

This module provides strongly-typed Input, Output, and Config field descriptors
for defining component fields. The component engine handles cache synchronization
for inputs/outputs. Config fields are set at instance creation and remain constant.

History fields allow components to access historical tag data via InfluxDB queries.
"""

from datetime import datetime
from typing import Any, Callable, Generic, TypeVar, overload

import pandas as pd

T = TypeVar("T")

# Global counter for tracking field definition order
_field_creation_counter = 0


class FieldDescriptor(Generic[T]):
    """
    Base descriptor for component fields.

    Provides type information for component fields.
    Fields are automatically ordered by their definition order in the class.
    """

    def __init__(
        self,
        default: T,
        description: str = "",
        visible: bool = True,
        system: bool = False,
        order: int | None = None,
        allowed_types: list[type] | type | None = None,
    ) -> None:
        """
        Initialize the field descriptor.

        Args:
            default: Default value for the field
            description: Human-readable description of the field
            visible: Whether field is visible by default in UI (can be overridden per-instance)
            system: Whether this is a system field (managed by engine, not user-defined)
            order: Explicit ordering override. If not provided, fields are ordered
                   by their definition order in the class. Lower values appear first.
            allowed_types: Allowed types for wiring validation. Can be a single type,
                   a list of types, or None (default) to accept any type.
        """
        global _field_creation_counter
        self.default = default
        self.description = description
        self.visible = visible
        self.system = system
        self.name: str = ""  # Set by __set_name__
        # Track creation order for automatic definition-order sorting
        self._creation_order = _field_creation_counter
        _field_creation_counter += 1
        # Explicit order override (if provided, takes precedence)
        self._explicit_order = order
        # Allowed types for wire compatibility checking
        self.allowed_types = allowed_types

    @property
    def _sort_key(self) -> tuple[int, int]:
        """
        Get the sort key for ordering fields.

        Returns a tuple of (explicit_order, creation_order) where explicit_order
        is 0 if set, 1 if not (so explicit orders come first).
        """
        if self._explicit_order is not None:
            return (0, self._explicit_order)
        return (1, self._creation_order)

    def __set_name__(self, owner: type, name: str) -> None:
        """Called when the descriptor is assigned to a class attribute."""
        self.name = name

    def _get_storage_name(self) -> str:
        """Get the private attribute name for storing the value."""
        return f"_field_{self.name}"

    def __repr__(self) -> str:
        parts = [f"default={self.default!r}"]
        if self.description:
            parts.append(f"description={self.description!r}")
        return f"{type(self).__name__}({', '.join(parts)})"


class Input(FieldDescriptor[T]):
    """
    Input field descriptor.

    Input fields receive data from:
    - Other component outputs (via wiring)
    - Direct assignment

    Example:
        class MyComponent(Component):
            temperature: Input[float] = Input(default=0.0, description="Temperature sensor")
            setpoint: Input[float] = Input(default=25.0, description="Temperature setpoint")
    """

    @overload
    def __get__(self, obj: None, objtype: type) -> "Input[T]": ...

    @overload
    def __get__(self, obj: object, objtype: type) -> T: ...

    def __get__(self, obj: object | None, objtype: type) -> "Input[T] | T":
        """Get the field value."""
        if obj is None:
            return self

        storage_name = self._get_storage_name()
        if hasattr(obj, storage_name):
            return getattr(obj, storage_name)
        return self.default

    def __set__(self, obj: object, value: T) -> None:
        """Set the field value."""
        storage_name = self._get_storage_name()
        setattr(obj, storage_name, value)


class Output(FieldDescriptor[T]):
    """
    Output field descriptor.

    Output fields send data to:
    - Other component inputs (via wiring)

    The component engine handles cache synchronization after execute().

    Example:
        class MyComponent(Component):
            result: Output[float] = Output(default=0.0, description="Calculated result")
            alarm: Output[bool] = Output(default=False, description="High temperature alarm")
    """

    @overload
    def __get__(self, obj: None, objtype: type) -> "Output[T]": ...

    @overload
    def __get__(self, obj: object, objtype: type) -> T: ...

    def __get__(self, obj: object | None, objtype: type) -> "Output[T] | T":
        """Get the field value."""
        if obj is None:
            return self

        storage_name = self._get_storage_name()
        if hasattr(obj, storage_name):
            return getattr(obj, storage_name)
        return self.default

    def __set__(self, obj: object, value: T) -> None:
        """Set the field value (engine handles cache sync)."""
        storage_name = self._get_storage_name()
        setattr(obj, storage_name, value)


class Config(FieldDescriptor[T]):
    """
    Base configuration field descriptor.

    Config fields are set at instance creation/configuration time and remain
    constant during execution. They cannot be wired and are not part of the
    execution data flow.

    Config fields support validation constraints that are exposed to the UI
    for form validation.

    Example:
        class MyComponent(Component):
            ip_address: StringConfig = StringConfig(
                default="127.0.0.1",
                description="Server IP address",
                regex=r"^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$",
                required=True
            )
    """

    def __init__(
        self,
        default: T,
        description: str = "",
        required: bool = False,
        order: int | None = None,
    ) -> None:
        """
        Initialize the config field descriptor.

        Args:
            default: Default value for the field
            description: Human-readable description of the field
            required: Whether this field is required (must be set at instance creation)
            order: Explicit ordering override. If not provided, fields are ordered
                   by their definition order in the class.
        """
        super().__init__(default, description, order=order)
        self.required = required

    @overload
    def __get__(self, obj: None, objtype: type) -> "Config[T]": ...

    @overload
    def __get__(self, obj: object, objtype: type) -> T: ...

    def __get__(self, obj: object | None, objtype: type) -> "Config[T] | T":
        """Get the field value."""
        if obj is None:
            return self

        storage_name = self._get_storage_name()
        if hasattr(obj, storage_name):
            return getattr(obj, storage_name)
        return self.default

    def __set__(self, obj: object, value: T) -> None:
        """
        Set the field value.

        Config fields are typically set at instance creation and should not
        be modified during execution.
        """
        storage_name = self._get_storage_name()
        setattr(obj, storage_name, value)


class StringConfig(Config[str]):
    """
    String configuration field with regex validation support.

    Example:
        class MyComponent(Component):
            ip_address: StringConfig = StringConfig(
                default="127.0.0.1",
                description="Server IP address",
                regex=r"^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$",
                required=True
            )
    """

    def __init__(
        self,
        default: str = "",
        description: str = "",
        regex: str | None = None,
        required: bool = False,
        order: int | None = None,
    ) -> None:
        """
        Initialize a string config field.

        Args:
            default: Default value for the field
            description: Human-readable description
            regex: Optional regex pattern for validation
            required: Whether this field is required
            order: Explicit ordering override
        """
        super().__init__(default, description, required, order=order)
        self.regex = regex


class NumberConfig(Config[float]):
    """
    Number configuration field with min/max validation support.

    Example:
        class MyComponent(Component):
            timeout: NumberConfig = NumberConfig(
                default=5.0,
                description="Connection timeout (seconds)",
                min_value=0.1,
                max_value=300.0
            )
    """

    def __init__(
        self,
        default: float = 0.0,
        description: str = "",
        min_value: float | None = None,
        max_value: float | None = None,
        required: bool = False,
        order: int | None = None,
    ) -> None:
        """
        Initialize a number config field.

        Args:
            default: Default value for the field
            description: Human-readable description
            min_value: Optional minimum allowed value
            max_value: Optional maximum allowed value
            required: Whether this field is required
            order: Explicit ordering override
        """
        super().__init__(default, description, required, order=order)
        self.min_value = min_value
        self.max_value = max_value


class ChoiceConfig(Config[str]):
    """
    Choice configuration field with predefined options (dropdown).

    Example:
        class MyComponent(Component):
            security_mode: ChoiceConfig = ChoiceConfig(
                default="TLS",
                description="Security mode",
                choices=["None", "TLS", "SSL"],
                required=True
            )
    """

    def __init__(
        self,
        default: str = "",
        description: str = "",
        choices: list[str] | None = None,
        required: bool = False,
        order: int | None = None,
    ) -> None:
        """
        Initialize a choice config field.

        Args:
            default: Default value (must be one of the choices)
            description: Human-readable description
            choices: List of allowed values
            required: Whether this field is required
            order: Explicit ordering override
        """
        super().__init__(default, description, required, order=order)
        self.choices = choices or []


class BoolConfig(Config[bool]):
    """
    Boolean configuration field.

    Example:
        class MyComponent(Component):
            enable_logging: BoolConfig = BoolConfig(
                default=True,
                description="Enable debug logging"
            )
    """

    def __init__(
        self,
        default: bool = False,
        description: str = "",
        required: bool = False,
        order: int | None = None,
    ) -> None:
        """
        Initialize a boolean config field.

        Args:
            default: Default value for the field
            description: Human-readable description
            required: Whether this field is required
            order: Explicit ordering override
        """
        super().__init__(default, description, required, order=order)


# Type alias for the fetch function signature
HistoryFetchFunc = Callable[
    [int, int | None, datetime | None, datetime | None, int],
    pd.DataFrame,
]


class HistoryProvider:
    """
    Provides historical data access for a specific tag.

    Injected by the component engine when a HistoryInput field is wired to a
    HISTORY connector. Allows components to query historical tag data from
    InfluxDB with custom time ranges and sampling parameters.

    The actual fetch function is provided by the engine at runtime.

    Example usage in a component:
        def execute(self):
            if self.sensor_history:
                # Get last hour of data with 60 samples
                df = self.sensor_history.get_history(
                    period_seconds=3600,
                    num_samples=60
                )
                if not df.empty:
                    avg = df["value"].mean()
    """

    def __init__(self, tag_id: int, fetch_func: HistoryFetchFunc) -> None:
        """
        Initialize the history provider.

        Args:
            tag_id: The tag ID to fetch history for
            fetch_func: Function to call for fetching history data
        """
        self._tag_id = tag_id
        self._fetch_func = fetch_func

    @property
    def tag_id(self) -> int:
        """Get the tag ID this provider is bound to."""
        return self._tag_id

    def get_history(
        self,
        period_seconds: int | None = None,
        start: datetime | None = None,
        stop: datetime | None = None,
        num_samples: int = 100,
    ) -> pd.DataFrame:
        """
        Fetch historical tag data from InfluxDB.

        Provide either `period_seconds` (for "last N seconds") or both
        `start` and `stop` (for a specific time range).

        Args:
            period_seconds: Number of seconds backwards from now.
                If provided, start/stop are ignored.
            start: Start datetime for the query range.
            stop: Stop datetime for the query range.
            num_samples: Maximum number of samples to return.
                Data is aggregated into windows to achieve this count.

        Returns:
            pandas DataFrame with columns:
                - timestamp: datetime of each sample
                - value: the tag value at that time

            Returns an empty DataFrame if no data is available.

        Example:
            # Get last 30 minutes with ~30 samples (1 per minute)
            df = provider.get_history(period_seconds=1800, num_samples=30)

            # Get specific time range
            df = provider.get_history(
                start=datetime(2024, 1, 1, 0, 0),
                stop=datetime(2024, 1, 1, 12, 0),
                num_samples=100
            )
        """
        return self._fetch_func(
            self._tag_id,
            period_seconds,
            start,
            stop,
            num_samples,
        )

    def __repr__(self) -> str:
        return f"HistoryProvider(tag_id={self._tag_id})"


class HistoryInput(FieldDescriptor["HistoryProvider | None"]):
    """
    History input field descriptor.

    Receives a HistoryProvider that allows querying historical tag data.
    Must be wired to a HISTORY connector on the environment canvas.

    Unlike regular Input fields that receive scalar values each cycle,
    HistoryInput fields receive a provider object that can be called
    to fetch historical data on demand.

    Example:
        class TrendAnalyzer(Component):
            # History input - wired to a HISTORY connector
            sensor_history: HistoryProvider | None = HistoryInput(
                description="Historical sensor readings for trend analysis"
            )

            # Regular output
            trend_slope: Output[float] = Output(default=0.0, description="Calculated trend")

            def execute(self):
                if self.sensor_history:
                    # Fetch last hour of data
                    df = self.sensor_history.get_history(
                        period_seconds=3600,
                        num_samples=60
                    )
                    if not df.empty:
                        # Calculate trend...
                        self.trend_slope = calculate_slope(df)
    """

    def __init__(self, description: str = "", order: int | None = None) -> None:
        """
        Initialize a history input field.

        Args:
            description: Human-readable description of what history is expected
            order: Explicit ordering override
        """
        super().__init__(default=None, description=description, order=order)

    @overload
    def __get__(self, obj: None, objtype: type) -> "HistoryInput": ...

    @overload
    def __get__(self, obj: object, objtype: type) -> "HistoryProvider | None": ...

    def __get__(
        self, obj: object | None, objtype: type
    ) -> "HistoryInput | HistoryProvider | None":
        """Get the history provider."""
        if obj is None:
            return self

        storage_name = self._get_storage_name()
        if hasattr(obj, storage_name):
            return getattr(obj, storage_name)
        return None

    def __set__(self, obj: object, value: "HistoryProvider | None") -> None:
        """Set the history provider (done by the engine)."""
        storage_name = self._get_storage_name()
        setattr(obj, storage_name, value)


def _sorted_fields(fields: dict[str, T]) -> dict[str, T]:
    """Sort fields by their definition order."""
    return dict(
        sorted(
            fields.items(),
            key=lambda item: item[1]._sort_key  # type: ignore[attr-defined]
        )
    )


def get_input_fields(cls: type) -> dict[str, Input[Any]]:
    """
    Get all Input fields defined on a component class.

    Args:
        cls: The component class to inspect

    Returns:
        Dictionary mapping field names to Input descriptors,
        ordered by definition order in the class
    """
    fields = {}
    for name in dir(cls):
        attr = getattr(cls, name, None)
        if isinstance(attr, Input):
            fields[name] = attr
    return _sorted_fields(fields)


def get_output_fields(cls: type) -> dict[str, Output[Any]]:
    """
    Get all Output fields defined on a component class.

    Args:
        cls: The component class to inspect

    Returns:
        Dictionary mapping field names to Output descriptors,
        ordered by definition order in the class
    """
    fields = {}
    for name in dir(cls):
        attr = getattr(cls, name, None)
        if isinstance(attr, Output):
            fields[name] = attr
    return _sorted_fields(fields)


def get_config_fields(cls: type) -> dict[str, Config[Any]]:
    """
    Get all Config fields defined on a component class.

    Args:
        cls: The component class to inspect

    Returns:
        Dictionary mapping field names to Config descriptors,
        ordered by definition order in the class
    """
    fields = {}
    for name in dir(cls):
        attr = getattr(cls, name, None)
        if isinstance(attr, Config):
            fields[name] = attr
    return _sorted_fields(fields)


def get_all_fields(cls: type) -> dict[str, FieldDescriptor[Any]]:
    """
    Get all fields (Input, Output, and Config) defined on a component class.

    Args:
        cls: The component class to inspect

    Returns:
        Dictionary mapping field names to field descriptors,
        ordered by definition order in the class
    """
    fields = {}
    for name in dir(cls):
        attr = getattr(cls, name, None)
        if isinstance(attr, FieldDescriptor):
            fields[name] = attr
    return _sorted_fields(fields)


def get_history_fields(cls: type) -> dict[str, HistoryInput]:
    """
    Get all HistoryInput fields defined on a component class.

    Args:
        cls: The component class to inspect

    Returns:
        Dictionary mapping field names to HistoryInput descriptors,
        ordered by definition order in the class
    """
    fields = {}
    for name in dir(cls):
        attr = getattr(cls, name, None)
        if isinstance(attr, HistoryInput):
            fields[name] = attr
    return _sorted_fields(fields)
