# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Koios Component Builder is an SDK and CLI tool for creating component libraries for the Koios platform. Components are logic blocks with typed inputs/outputs that get wired together and executed by the Component Engine. Components are organized into **libraries** which are exported as `.kcl` (Koios Component Library) packages for upload to the Koios UI.

## Repository Structure

```
koios-component-builder/
├── src/koios_component_builder/   # SDK source code
│   ├── component.py               # Base Component class, Meta, Icons, Categories
│   ├── fields.py                  # Field descriptors (Input, Output, HistoryInput, Config)
│   ├── library.py                 # ComponentLibrary base class
│   ├── cli/                       # Click CLI (export command)
│   └── export/                    # Wheel building logic
├── tests/                         # pytest tests
└── Makefile                       # Build/quality commands
```

**Note:** Component libraries live in a separate repo (`koios-component-libraries/`).

## Common Commands

```bash
# Install dependencies
make setup

# Run tests
make test
make test ARGS="-v"

# Code quality
make lint                # Ruff check
make format              # Ruff format + fix
```

## Creating a New Library

Libraries live in the `koios-component-libraries` repo. To create one:

1. Create a folder (use snake_case: `my_library/`)
2. Add component modules (e.g., `components.py`, `math_ops.py`)
3. Create `__init__.py` with the library definition:

```python
from koios_component_builder import ComponentLibrary
from .components import MyComponent, AnotherComponent

class MyLibrary(ComponentLibrary):
    """Library description shown in UI."""

    name = "my-library"           # kebab-case name
    major = 1                     # Semantic version
    minor = 0
    patch = 0
    description = "What this library does"

    components = [
        MyComponent,
        AnotherComponent,
    ]

__all__ = ["MyLibrary", "MyComponent", "AnotherComponent"]
```

## Component Structure

Components extend `Component` and define typed fields:

```python
from koios_component_builder import (
    Component,
    ComponentCategory,
    ComponentIcon,
    Input,
    Output,
)

class SimpleAdder(Component):
    """Docstring becomes the component description."""

    class Meta:
        icon = ComponentIcon.SUM           # Tabler icon (see ComponentIcon class)
        category = ComponentCategory.MATH  # UI grouping (see ComponentCategory class)
        canvas_width = 6                   # Node width 4-15 grid units (default: 6)

    # Type annotation MUST be Input[T] or Output[T], not just T
    a: Input[float] = Input(default=0.0, description="First number")
    b: Input[float] = Input(default=0.0, description="Second number")
    result: Output[float] = Output(default=0.0, description="Sum")

    def execute(self) -> None:
        self.result = self.a + self.b
```

## Lifecycle Hooks

### `setup()` — One-Time Initialization

Override `setup()` for expensive initialization that should only run once (loading models, creating registries, opening connections). All field values are available — configs have their UI-configured values, inputs have their initial values.

If `setup()` raises, the component is marked FAILED and retried next cycle.

```python
class UnitConverter(Component):
    value: Input[float] = Input(default=0.0)
    decimals: NumberConfig = NumberConfig(default=2, min_value=0, max_value=6)
    result: Output[float] = Output(default=0.0)

    def setup(self) -> None:
        from pint import UnitRegistry
        self._ureg = UnitRegistry()  # ~80ms — only runs once

    def execute(self) -> None:
        temp = self._ureg.Quantity(self.value, self._ureg.degF)
        self.result = round(temp.to(self._ureg.degC).magnitude, int(self.decimals))
```

For resources shared across **all instances** of a class (not per-instance), use a class-level guard in `execute()` instead:

```python
class MyComponent(Component):
    def execute(self) -> None:
        if not hasattr(MyComponent, "_shared_model"):
            MyComponent._shared_model = load_model()
        self.result = MyComponent._shared_model.predict(self.input)
```

## Field Types

### Input/Output Fields
- `Input[T]` - Receives data from tags or other components
- `Output[T]` - Sends data to wired destinations
- Supported types: `float`, `int`, `bool`, `str`, `list`, `dict`

### Config Fields (immutable after instantiation)
- `NumberConfig` - Numeric with min/max validation
- `StringConfig` - Text with optional regex validation
- `ChoiceConfig` - Dropdown with predefined options
- `BoolConfig` - Boolean toggle

### HistoryInput (for historical data access)
```python
from koios_component_builder import Component, HistoryInput, Output

class TrendAnalyzer(Component):
    sensor_history: HistoryInput = HistoryInput(
        description="Historical sensor readings"
    )
    trend: Output[float] = Output(default=0.0)

    def execute(self) -> None:
        if self.sensor_history is None:
            return  # Not wired to a history connector

        # Fetch last hour of data, max 200 samples
        df = self.sensor_history.get_history(
            period_seconds=3600,
            num_samples=200,
        )
        # df has columns: timestamp, value
        if not df.empty:
            values = df["value"].tolist()
            self.trend = values[-1] - values[0]
```

## Meta Class Options

```python
class Meta:
    # Visual settings
    icon = ComponentIcon.CHART_LINE    # Tabler icon name
    category = ComponentCategory.ANALYSIS  # UI category for grouping
    canvas_width = 8                   # Node width (4-15 grid units)
    canvas_minimal = False             # Compact mode (no header/footer)

    # Optional component-specific version (overrides library version)
    major = 2
    minor = 1
    patch = 0
    prerelease = "beta"  # Optional: "alpha", "beta.1", "rc.2"
```

**Common Icons:** `SUM`, `CALCULATOR`, `CHART_LINE`, `GAUGE`, `THERMOMETER`, `FILTER`, `WAVE_SINE`, `WAVE_SQUARE`, `TOGGLE_LEFT`, `ALERT_TRIANGLE`

**Common Categories:** `MATH`, `STATISTICS`, `LOGIC`, `ANALYSIS`, `TRANSFORM`, `FILTER`, `CONTROL`, `MONITORING`

## Package Format (.kcl)

The `export` command creates a `.kcl` (Koios Component Library) package — a ZIP archive containing metadata and a pip-installable wheel:

```
{library_name}-{version}.kcl (ZIP archive)
├── manifest.json                           # Library metadata (manifest_version 2.0)
├── {library_name}-{version}-py3-none-any.whl  # Standard Python wheel
└── deps/                                   # Optional: bundled dependency wheels
    ├── crcmod-1.7-cp312-cp312-manylinux2014_x86_64.whl
    └── crcmod-1.7-cp312-cp312-manylinux2014_aarch64.whl
```

The inner wheel contains:
```
{library_name}/
├── {module}.py            # Source code for each component module
└── __init__.py            # Exports all component classes
{library_name}-{version}.dist-info/
├── METADATA, WHEEL, RECORD
```

## Dependencies

Libraries can declare third-party dependencies. The builder resolves them against a platform manifest (`platform_packages.json`) to determine what's already available in the Koios container vs. what needs bundling.

### Three-tier model

| Tier | Description | Example |
|------|-------------|---------|
| **Platform** | Pre-installed in the Koios container (numpy, pandas, scipy, etc.) | `numpy`, `pandas` |
| **Bundled** | Downloaded and included in `deps/` inside the .kcl | `crcmod`, `minimalmodbus` |
| **SDK** | Always available (koios-component-builder itself) | `pydantic`, `click` |

### Declaring dependencies

```python
class MyLibrary(ComponentLibrary):
    name = "my-protocol-library"
    major = 1
    minor = 0
    dependencies = ["crcmod", "minimalmodbus>=2.0"]
    components = [MyDevice]
```

### Building with dependencies

```bash
# Without bundling (warns about non-platform deps)
koios-component-builder export my_library/

# Bundle non-platform dependencies into the .kcl
koios-component-builder export my_library/ --include-deps

# Target specific platforms
koios-component-builder export my_library/ --include-deps \
    --platform manylinux2014_x86_64 --platform manylinux2014_aarch64

# List available platform packages
koios-component-builder platform-packages
```

### manifest.json dependencies section

When dependencies are declared, `manifest.json` includes a `dependencies` field:

```json
{
  "dependencies": {
    "declared": ["crcmod", "minimalmodbus>=2.0"],
    "platform_satisfied": [],
    "bundled": [
      {"name": "crcmod", "version": "1.7", "wheels": ["crcmod-1.7-cp312-...x86_64.whl", "crcmod-1.7-cp312-...aarch64.whl"]},
      {"name": "minimalmodbus", "version": "2.1.1", "wheels": ["minimalmodbus-2.1.1-py3-none-any.whl"]}
    ]
  }
}
```

## Integration Points

- **koios-component-engine** - Loads wheels (extracted from .kcl by webapp), installs bundled deps, instantiates components, executes at scan rates, handles wiring
- **koios-ui** - Uploads .kcl packages, displays component library tray and dependency info, manages instances on canvas
- **koios-webapp-py** - Extracts .whl from uploaded .kcl, stores wheel and component definitions in PostgreSQL, exposes dependency info via GraphQL

## Platform Packages Manifest

`src/koios_component_builder/platform_packages.json` lists packages pre-installed in the Koios production container. The `export` command uses this to decide which dependencies need bundling into `.kcl` files vs. which are already available at runtime.

**This file must be updated before every release.** The generation script lives in `koios-docker-deploy/scripts/generate_platform_packages.py` and runs against a built Koios image. Two ways to run it:

```bash
# Via the build wizard (option 8, or prompted after local builds)
cd ../koios-docker-deploy && make wizard

# Via Make directly
cd ../koios-docker-deploy && make sync-platform-packages
```

Both write directly to `src/koios_component_builder/platform_packages.json` in this repo.

If no built image is available, update the file manually when dependencies change in any service's `pyproject.toml`.

## Code Style

- **Formatter/Linter:** Ruff (line length 88)
- **Python:** 3.12+ required
