"""
Tests for koios_component_builder.fields module.
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock

import pandas as pd
import pytest

from koios_component_builder.fields import (
    BoolConfig,
    ChoiceConfig,
    Config,
    FieldDescriptor,
    HistoryInput,
    HistoryProvider,
    Input,
    NumberConfig,
    Output,
    StringConfig,
    get_all_fields,
    get_config_fields,
    get_history_fields,
    get_input_fields,
    get_output_fields,
)

from conftest import (
    AllowedTypesComponent,
    ConfiguredComponent,
    HistoryComponent,
    OrderedFieldComponent,
    SimpleAdder,
)


class TestInputDescriptor:
    """Tests for the Input field descriptor."""

    def test_class_access_returns_descriptor(self):
        """Accessing Input on the class returns the descriptor itself."""
        descriptor = SimpleAdder.a
        assert isinstance(descriptor, Input)

    def test_instance_access_returns_default(self):
        comp = SimpleAdder(component_id="test")
        assert comp.a == 0.0
        assert comp.b == 0.0

    def test_instance_set_and_get(self):
        comp = SimpleAdder(component_id="test")
        comp.a = 42.0
        assert comp.a == 42.0

    def test_storage_name(self):
        descriptor = SimpleAdder.a
        assert descriptor._get_storage_name() == "_field_a"

    def test_set_name(self):
        descriptor = SimpleAdder.a
        assert descriptor.name == "a"

    def test_default_value_preserved(self):
        descriptor = SimpleAdder.a
        assert descriptor.default == 0.0

    def test_description(self):
        descriptor = SimpleAdder.a
        assert descriptor.description == "First number"

    def test_visible_default_true(self):
        descriptor = SimpleAdder.a
        assert descriptor.visible is True

    def test_system_default_false(self):
        descriptor = SimpleAdder.a
        assert descriptor.system is False

    def test_allowed_types_none_by_default(self):
        descriptor = SimpleAdder.a
        assert descriptor.allowed_types is None

    def test_allowed_types_set(self):
        descriptor = AllowedTypesComponent.numeric_in
        assert descriptor.allowed_types == [float, int]

    def test_multiple_instances_independent(self):
        """Two component instances have independent field values."""
        comp1 = SimpleAdder(component_id="a")
        comp2 = SimpleAdder(component_id="b")
        comp1.a = 10.0
        comp2.a = 20.0
        assert comp1.a == 10.0
        assert comp2.a == 20.0


class TestOutputDescriptor:
    """Tests for the Output field descriptor."""

    def test_class_access_returns_descriptor(self):
        descriptor = SimpleAdder.result
        assert isinstance(descriptor, Output)

    def test_instance_access_returns_default(self):
        comp = SimpleAdder(component_id="test")
        assert comp.result == 0.0

    def test_instance_set_and_get(self):
        comp = SimpleAdder(component_id="test")
        comp.result = 99.0
        assert comp.result == 99.0

    def test_storage_name(self):
        descriptor = SimpleAdder.result
        assert descriptor._get_storage_name() == "_field_result"

    def test_description(self):
        descriptor = SimpleAdder.result
        assert descriptor.description == "Sum"


class TestConfigDescriptors:
    """Tests for Config, StringConfig, NumberConfig, ChoiceConfig, BoolConfig."""

    def test_config_class_access_returns_descriptor(self):
        descriptor = ConfiguredComponent.ip_address
        assert isinstance(descriptor, StringConfig)

    def test_config_instance_access_returns_default(self):
        comp = ConfiguredComponent(component_id="test")
        assert comp.ip_address == "127.0.0.1"

    def test_config_set_and_get(self):
        comp = ConfiguredComponent(component_id="test")
        comp.ip_address = "192.168.1.1"
        assert comp.ip_address == "192.168.1.1"

    def test_string_config_regex(self):
        descriptor = ConfiguredComponent.ip_address
        assert descriptor.regex == r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"

    def test_string_config_required(self):
        descriptor = ConfiguredComponent.ip_address
        assert descriptor.required is True

    def test_string_config_defaults(self):
        """StringConfig with no args uses sensible defaults."""
        sc = StringConfig()
        assert sc.default == ""
        assert sc.regex is None
        assert sc.required is False

    def test_number_config_min_max(self):
        descriptor = ConfiguredComponent.timeout
        assert descriptor.min_value == 0.1
        assert descriptor.max_value == 300.0

    def test_number_config_default(self):
        comp = ConfiguredComponent(component_id="test")
        assert comp.timeout == 5.0

    def test_number_config_defaults(self):
        """NumberConfig with no args uses sensible defaults."""
        nc = NumberConfig()
        assert nc.default == 0.0
        assert nc.min_value is None
        assert nc.max_value is None
        assert nc.required is False

    def test_choice_config_choices(self):
        descriptor = ConfiguredComponent.mode
        assert descriptor.choices == ["None", "TLS", "SSL"]

    def test_choice_config_default(self):
        comp = ConfiguredComponent(component_id="test")
        assert comp.mode == "TLS"

    def test_choice_config_empty_choices_default(self):
        """ChoiceConfig with choices=None defaults to empty list."""
        cc = ChoiceConfig()
        assert cc.choices == []

    def test_bool_config_default(self):
        comp = ConfiguredComponent(component_id="test")
        assert comp.debug is False

    def test_bool_config_set_and_get(self):
        comp = ConfiguredComponent(component_id="test")
        comp.debug = True
        assert comp.debug is True

    def test_bool_config_defaults(self):
        """BoolConfig with no args uses sensible defaults."""
        bc = BoolConfig()
        assert bc.default is False
        assert bc.required is False

    def test_config_base_required_default(self):
        """Base Config required defaults to False."""
        c = Config(default="test")
        assert c.required is False


class TestHistoryInput:
    """Tests for the HistoryInput field descriptor."""

    def test_class_access_returns_descriptor(self):
        descriptor = HistoryComponent.sensor_history
        assert isinstance(descriptor, HistoryInput)

    def test_instance_default_is_none(self):
        comp = HistoryComponent(component_id="test")
        assert comp.sensor_history is None

    def test_instance_set_and_get(self):
        comp = HistoryComponent(component_id="test")
        mock_fetch = MagicMock(return_value=pd.DataFrame())
        provider = HistoryProvider(tag_id=42, fetch_func=mock_fetch)
        comp.sensor_history = provider
        assert comp.sensor_history is provider
        assert comp.sensor_history.tag_id == 42

    def test_history_input_description(self):
        descriptor = HistoryComponent.sensor_history
        assert descriptor.description == "Historical sensor readings"

    def test_history_input_default_none(self):
        descriptor = HistoryComponent.sensor_history
        assert descriptor.default is None


class TestHistoryProvider:
    """Tests for the HistoryProvider class."""

    def test_init_and_tag_id(self):
        mock_fetch = MagicMock(return_value=pd.DataFrame())
        provider = HistoryProvider(tag_id=123, fetch_func=mock_fetch)
        assert provider.tag_id == 123

    def test_get_history_calls_fetch_func(self):
        mock_fetch = MagicMock(return_value=pd.DataFrame({"value": [1, 2, 3]}))
        provider = HistoryProvider(tag_id=10, fetch_func=mock_fetch)
        df = provider.get_history(period_seconds=3600, num_samples=60)
        mock_fetch.assert_called_once_with(10, 3600, None, None, 60)
        assert len(df) == 3

    def test_get_history_with_start_stop(self):
        mock_fetch = MagicMock(return_value=pd.DataFrame())
        provider = HistoryProvider(tag_id=10, fetch_func=mock_fetch)
        start = datetime(2024, 1, 1, tzinfo=timezone.utc)
        stop = datetime(2024, 1, 2, tzinfo=timezone.utc)
        provider.get_history(start=start, stop=stop, num_samples=200)
        mock_fetch.assert_called_once_with(10, None, start, stop, 200)

    def test_get_history_default_num_samples(self):
        mock_fetch = MagicMock(return_value=pd.DataFrame())
        provider = HistoryProvider(tag_id=10, fetch_func=mock_fetch)
        provider.get_history(period_seconds=60)
        mock_fetch.assert_called_once_with(10, 60, None, None, 100)

    def test_repr(self):
        mock_fetch = MagicMock()
        provider = HistoryProvider(tag_id=42, fetch_func=mock_fetch)
        assert repr(provider) == "HistoryProvider(tag_id=42)"


class TestFieldOrdering:
    """Tests for field ordering and sort keys."""

    def test_explicit_order_takes_precedence(self):
        """Fields with explicit order come before auto-ordered fields."""
        fields = get_input_fields(OrderedFieldComponent)
        field_names = list(fields.keys())
        # Explicit order=1 first, then order=10, then auto-ordered
        assert field_names.index("a_first") < field_names.index("z_last")
        assert field_names.index("a_first") < field_names.index("m_middle")
        assert field_names.index("z_last") < field_names.index("m_middle")

    def test_sort_key_with_explicit_order(self):
        descriptor = Input(default=0.0, order=5)
        descriptor.__set_name__(None, "test")
        assert descriptor._sort_key == (0, 5)

    def test_sort_key_without_explicit_order(self):
        descriptor = Input(default=0.0)
        descriptor.__set_name__(None, "test")
        assert descriptor._sort_key[0] == 1  # Tuple starts with 1 for auto-ordered

    def test_system_fields_sorted_first(self):
        """System fields (enable, error, status) have negative order and sort first."""
        all_fields = get_all_fields(SimpleAdder)
        field_names = list(all_fields.keys())
        # System fields (enable, error, status) should be before user fields (a, b, result)
        enable_idx = field_names.index("enable")
        a_idx = field_names.index("a")
        assert enable_idx < a_idx


class TestFieldGetters:
    """Tests for get_input_fields, get_output_fields, get_config_fields, etc."""

    def test_get_input_fields_simple(self):
        fields = get_input_fields(SimpleAdder)
        # Includes system field 'enable' + user fields 'a', 'b'
        assert "a" in fields
        assert "b" in fields
        assert "enable" in fields
        assert isinstance(fields["a"], Input)

    def test_get_output_fields_simple(self):
        fields = get_output_fields(SimpleAdder)
        assert "result" in fields
        assert "error" in fields
        assert "status" in fields
        assert isinstance(fields["result"], Output)

    def test_get_config_fields(self):
        fields = get_config_fields(ConfiguredComponent)
        assert "ip_address" in fields
        assert "timeout" in fields
        assert "mode" in fields
        assert "debug" in fields
        assert isinstance(fields["ip_address"], StringConfig)
        assert isinstance(fields["timeout"], NumberConfig)
        assert isinstance(fields["mode"], ChoiceConfig)
        assert isinstance(fields["debug"], BoolConfig)

    def test_get_history_fields(self):
        fields = get_history_fields(HistoryComponent)
        assert "sensor_history" in fields
        assert isinstance(fields["sensor_history"], HistoryInput)

    def test_get_history_fields_empty(self):
        fields = get_history_fields(SimpleAdder)
        assert len(fields) == 0

    def test_get_all_fields(self):
        fields = get_all_fields(SimpleAdder)
        # Should contain inputs (enable, a, b) + outputs (error, status, result)
        assert "a" in fields
        assert "b" in fields
        assert "result" in fields
        assert "enable" in fields
        assert "error" in fields
        assert "status" in fields

    def test_get_all_fields_includes_configs(self):
        fields = get_all_fields(ConfiguredComponent)
        assert "ip_address" in fields
        assert "timeout" in fields

    def test_get_all_fields_includes_history(self):
        fields = get_all_fields(HistoryComponent)
        assert "sensor_history" in fields

    def test_config_fields_not_in_input_fields(self):
        """Config fields should NOT appear in get_input_fields."""
        input_fields = get_input_fields(ConfiguredComponent)
        assert "ip_address" not in input_fields
        assert "timeout" not in input_fields
