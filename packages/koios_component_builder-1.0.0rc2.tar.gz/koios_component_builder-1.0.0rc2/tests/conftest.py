"""
Shared fixtures for koios-component-builder tests.
"""

import pytest

from koios_component_builder import (
    BoolConfig,
    ChoiceConfig,
    Component,
    ComponentCategory,
    ComponentIcon,
    HistoryInput,
    Input,
    NumberConfig,
    Output,
    StringConfig,
)


class SimpleAdder(Component):
    """Adds two numbers."""

    class Meta:
        icon = ComponentIcon.SUM
        category = ComponentCategory.MATH

    a: Input[float] = Input(default=0.0, description="First number")
    b: Input[float] = Input(default=0.0, description="Second number")
    result: Output[float] = Output(default=0.0, description="Sum")

    def execute(self):
        self.result = self.a + self.b


class ConfiguredComponent(Component):
    """Component with config fields."""

    class Meta:
        icon = ComponentIcon.SETTINGS
        category = ComponentCategory.CONTROL
        canvas_width = 10

    ip_address: StringConfig = StringConfig(
        default="127.0.0.1",
        description="Server IP",
        regex=r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$",
        required=True,
    )
    timeout: NumberConfig = NumberConfig(
        default=5.0,
        description="Timeout in seconds",
        min_value=0.1,
        max_value=300.0,
    )
    mode: ChoiceConfig = ChoiceConfig(
        default="TLS",
        description="Security mode",
        choices=["None", "TLS", "SSL"],
    )
    debug: BoolConfig = BoolConfig(
        default=False,
        description="Enable debug logging",
    )
    sensor: Input[float] = Input(default=0.0, description="Sensor reading")
    output_val: Output[float] = Output(default=0.0, description="Processed value")

    def execute(self):
        self.output_val = self.sensor * self.timeout


class HistoryComponent(Component):
    """Component with history input."""

    class Meta:
        icon = ComponentIcon.HISTORY
        category = ComponentCategory.ANALYSIS

    sensor_history: HistoryInput = HistoryInput(
        description="Historical sensor readings"
    )
    trend: Output[float] = Output(default=0.0, description="Trend slope")

    def execute(self):
        if self.sensor_history:
            df = self.sensor_history.get_history(period_seconds=3600, num_samples=60)
            if not df.empty:
                self.trend = float(df["value"].iloc[-1] - df["value"].iloc[0])


class VersionedComponent(Component):
    """Component with its own version."""

    class Meta:
        icon = ComponentIcon.PUZZLE
        major = 2
        minor = 1
        patch = 3
        prerelease = "beta"

    x: Input[float] = Input(default=0.0, description="Input value")
    y: Output[float] = Output(default=0.0, description="Output value")

    def execute(self):
        self.y = self.x * 2


class MinimalComponent(Component):
    """Minimal mode component."""

    class Meta:
        canvas_minimal = True
        canvas_width = 4

    a: Input[bool] = Input(default=False, description="Input A")
    out: Output[bool] = Output(default=False, description="Output")

    def execute(self):
        self.out = self.a


class OrderedFieldComponent(Component):
    """Component with explicitly ordered fields."""

    z_last: Input[float] = Input(default=0.0, description="Should be second", order=10)
    a_first: Input[float] = Input(default=0.0, description="Should be first", order=1)
    m_middle: Input[float] = Input(
        default=0.0, description="Should be third (auto-order)"
    )
    result: Output[float] = Output(default=0.0, description="Result")

    def execute(self):
        self.result = self.a_first + self.m_middle + self.z_last


class AllowedTypesComponent(Component):
    """Component with allowed_types on inputs."""

    numeric_in: Input[float] = Input(
        default=0.0,
        description="Accepts float or int",
        allowed_types=[float, int],
    )
    any_in: Input[float] = Input(
        default=0.0,
        description="Accepts any type",
    )
    result: Output[float] = Output(default=0.0, description="Result")

    def execute(self):
        self.result = float(self.numeric_in)


@pytest.fixture
def simple_adder():
    return SimpleAdder(component_id="test-adder-1")


@pytest.fixture
def configured_component():
    return ConfiguredComponent(component_id="test-configured-1")


@pytest.fixture
def history_component():
    return HistoryComponent(component_id="test-history-1")


@pytest.fixture
def versioned_component():
    return VersionedComponent(component_id="test-versioned-1")


@pytest.fixture
def minimal_component():
    return MinimalComponent(component_id="test-minimal-1")
