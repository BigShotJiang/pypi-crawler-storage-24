"""
Tests for koios_component_builder.models module.
"""

import pytest
from pydantic import ValidationError

from koios_component_builder.models import (
    BuildInfo,
    CanvasSettings,
    ComponentFieldMetadata,
    ComponentMetadata,
    LibraryMetadata,
    MetadataWrapper,
    SemanticVersion,
)


class TestSemanticVersion:
    """Tests for the SemanticVersion Pydantic model."""

    def test_basic_version(self):
        v = SemanticVersion(major=1, minor=2, patch=3)
        assert v.major == 1
        assert v.minor == 2
        assert v.patch == 3
        assert v.prerelease is None

    def test_string_property(self):
        v = SemanticVersion(major=1, minor=2, patch=3)
        assert v.string == "1.2.3"

    def test_string_with_prerelease(self):
        v = SemanticVersion(major=1, minor=0, patch=0, prerelease="beta.1")
        assert v.string == "1.0.0-beta.1"

    def test_str_method(self):
        v = SemanticVersion(major=2, minor=1, patch=0)
        assert str(v) == "2.1.0"

    def test_patch_defaults_to_zero(self):
        v = SemanticVersion(major=1, minor=0)
        assert v.patch == 0
        assert v.string == "1.0.0"

    def test_prerelease_defaults_to_none(self):
        v = SemanticVersion(major=0, minor=1, patch=0)
        assert v.prerelease is None

    def test_negative_major_fails(self):
        with pytest.raises(ValidationError):
            SemanticVersion(major=-1, minor=0)

    def test_negative_minor_fails(self):
        with pytest.raises(ValidationError):
            SemanticVersion(major=0, minor=-1)

    def test_negative_patch_fails(self):
        with pytest.raises(ValidationError):
            SemanticVersion(major=0, minor=0, patch=-1)

    def test_zero_version(self):
        v = SemanticVersion(major=0, minor=0, patch=0)
        assert v.string == "0.0.0"

    def test_prerelease_alpha(self):
        v = SemanticVersion(major=1, minor=0, patch=0, prerelease="alpha")
        assert v.string == "1.0.0-alpha"

    def test_prerelease_rc(self):
        v = SemanticVersion(major=3, minor=0, patch=0, prerelease="rc.2")
        assert v.string == "3.0.0-rc.2"


class TestComponentFieldMetadata:
    """Tests for the ComponentFieldMetadata Pydantic model."""

    def test_basic_field(self):
        f = ComponentFieldMetadata(name="temperature", type="float")
        assert f.name == "temperature"
        assert f.type == "float"
        assert f.default is None
        assert f.description == ""
        assert f.order == 0

    def test_field_with_all_properties(self):
        f = ComponentFieldMetadata(
            name="ip",
            type="str",
            default="127.0.0.1",
            description="Server IP",
            order=5,
            required=True,
            regex=r"^\d+\.\d+\.\d+\.\d+$",
            visible=True,
            system=False,
        )
        assert f.required is True
        assert f.regex == r"^\d+\.\d+\.\d+\.\d+$"

    def test_number_field_constraints(self):
        f = ComponentFieldMetadata(
            name="timeout",
            type="float",
            default=5.0,
            min_value=0.1,
            max_value=300.0,
        )
        assert f.min_value == 0.1
        assert f.max_value == 300.0

    def test_choice_field(self):
        f = ComponentFieldMetadata(
            name="mode",
            type="str",
            default="TLS",
            choices=["None", "TLS", "SSL"],
        )
        assert f.choices == ["None", "TLS", "SSL"]

    def test_defaults(self):
        f = ComponentFieldMetadata(name="x", type="float")
        assert f.required is False
        assert f.min_value is None
        assert f.max_value is None
        assert f.regex is None
        assert f.choices is None
        assert f.visible is True
        assert f.system is False
        assert f.allowed_types is None

    def test_system_field(self):
        f = ComponentFieldMetadata(
            name="enable", type="bool", default=True, system=True, visible=False
        )
        assert f.system is True
        assert f.visible is False

    def test_allowed_types(self):
        f = ComponentFieldMetadata(
            name="sensor",
            type="float",
            allowed_types=["float", "int"],
        )
        assert f.allowed_types == ["float", "int"]


class TestCanvasSettings:
    """Tests for the CanvasSettings Pydantic model."""

    def test_all_none_defaults(self):
        cs = CanvasSettings()
        assert cs.width is None
        assert cs.icon is None
        assert cs.category is None
        assert cs.minimal is None

    def test_width_in_range(self):
        cs = CanvasSettings(width=8)
        assert cs.width == 8

    def test_width_min_boundary(self):
        cs = CanvasSettings(width=4)
        assert cs.width == 4

    def test_width_max_boundary(self):
        cs = CanvasSettings(width=15)
        assert cs.width == 15

    def test_width_below_min_fails(self):
        with pytest.raises(ValidationError):
            CanvasSettings(width=3)

    def test_width_above_max_fails(self):
        with pytest.raises(ValidationError):
            CanvasSettings(width=16)

    def test_full_settings(self):
        cs = CanvasSettings(
            width=10, icon="chart-line", category="Analysis", minimal=True
        )
        assert cs.width == 10
        assert cs.icon == "chart-line"
        assert cs.category == "Analysis"
        assert cs.minimal is True


class TestMetadataWrapper:
    """Tests for MetadataWrapper (top-level manifest model)."""

    def _make_wrapper(self, **overrides):
        lib_data = {
            "name": "test-lib",
            "version": "1.0.0",
            "version_parts": {"major": 1, "minor": 0, "patch": 0},
            "components": [],
        }
        lib_data.update(overrides.pop("library", {}))
        data = {"manifest_version": "2.0", "library": lib_data}
        data.update(overrides)
        return MetadataWrapper.model_validate(data)

    def test_manifest_version_default(self):
        w = self._make_wrapper()
        assert w.manifest_version == "2.0"

    def test_library_name(self):
        w = self._make_wrapper()
        assert w.library.name == "test-lib"

    def test_to_dict(self):
        w = self._make_wrapper()
        d = w.to_dict()
        assert isinstance(d, dict)
        assert d["manifest_version"] == "2.0"
        assert d["library"]["name"] == "test-lib"
        # build_info is None so should be excluded
        assert "build_info" not in d

    def test_to_dict_excludes_none(self):
        w = self._make_wrapper()
        d = w.to_dict()
        # description is None by default, should be excluded
        assert "description" not in d["library"]

    def test_from_dict(self):
        data = {
            "manifest_version": "2.0",
            "library": {
                "name": "my-lib",
                "version": "2.0.0",
                "version_parts": {"major": 2, "minor": 0, "patch": 0},
                "components": [],
            },
        }
        w = MetadataWrapper.from_dict(data)
        assert w.library.name == "my-lib"
        assert w.library.version == "2.0.0"

    def test_round_trip(self):
        w = self._make_wrapper()
        d = w.to_dict()
        w2 = MetadataWrapper.from_dict(d)
        assert w2.library.name == w.library.name
        assert w2.manifest_version == w.manifest_version

    def test_with_build_info(self):
        w = self._make_wrapper(
            build_info={
                "build_time": "2024-01-01T00:00:00",
                "python_version": "3.12.0",
                "builder_version": "0.1.0",
                "sdk_base_version": 2,
            }
        )
        assert w.build_info is not None
        assert w.build_info.sdk_base_version == 2
        assert w.build_info.python_version == "3.12.0"

    def test_get_library_dict(self):
        w = self._make_wrapper()
        ld = w.get_library_dict()
        assert isinstance(ld, dict)
        assert ld["name"] == "test-lib"
        assert "manifest_version" not in ld  # Only library, not wrapper


class TestBuildInfo:
    """Tests for the BuildInfo Pydantic model."""

    def test_basic(self):
        bi = BuildInfo(
            build_time="2024-01-01T00:00:00",
            python_version="3.12.0",
            builder_version="0.1.0",
        )
        assert bi.sdk_base_version == 1  # default

    def test_with_sdk_base_version(self):
        bi = BuildInfo(
            build_time="2024-06-01T12:00:00",
            python_version="3.12.3",
            builder_version="0.2.0",
            sdk_base_version=2,
        )
        assert bi.sdk_base_version == 2


class TestLibraryMetadata:
    """Tests for the LibraryMetadata Pydantic model."""

    def test_basic(self):
        lm = LibraryMetadata(
            name="my-lib",
            version="1.0.0",
            version_parts=SemanticVersion(major=1, minor=0, patch=0),
        )
        assert lm.name == "my-lib"
        assert lm.description is None
        assert lm.components == []
        assert lm.data_files is None

    def test_with_components(self):
        comp = ComponentMetadata(
            name="Adder",
            class_name="Adder",
            version="1.0.0",
            version_parts=SemanticVersion(major=1, minor=0),
        )
        lm = LibraryMetadata(
            name="math-lib",
            version="1.0.0",
            version_parts=SemanticVersion(major=1, minor=0),
            components=[comp],
        )
        assert len(lm.components) == 1
        assert lm.components[0].name == "Adder"


class TestComponentMetadata:
    """Tests for the ComponentMetadata Pydantic model."""

    def test_basic(self):
        cm = ComponentMetadata(
            name="MyComp",
            class_name="MyComp",
            version="1.0.0",
            version_parts=SemanticVersion(major=1, minor=0),
        )
        assert cm.name == "MyComp"
        assert cm.inputs == []
        assert cm.outputs == []
        assert cm.configs == []
        assert cm.canvas is None
        assert cm.documentation is None

    def test_with_fields(self):
        inp = ComponentFieldMetadata(name="a", type="float", default=0.0)
        out = ComponentFieldMetadata(name="result", type="float", default=0.0)
        cfg = ComponentFieldMetadata(name="scale", type="float", default=1.0, required=True)
        cm = ComponentMetadata(
            name="Scaler",
            class_name="Scaler",
            version="1.0.0",
            version_parts=SemanticVersion(major=1, minor=0),
            inputs=[inp],
            outputs=[out],
            configs=[cfg],
        )
        assert len(cm.inputs) == 1
        assert len(cm.outputs) == 1
        assert len(cm.configs) == 1
