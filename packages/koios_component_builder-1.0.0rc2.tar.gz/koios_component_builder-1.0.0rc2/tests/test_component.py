"""
Tests for koios_component_builder.component module.
"""

import pytest

from koios_component_builder.component import (
    Component,
    ComponentCategory,
    ComponentIcon,
    ComponentMeta,
    ComponentStatus,
    get_canvas_settings,
    get_component_version,
    get_meta_value,
)
from koios_component_builder.fields import Input, Output, get_input_fields, get_output_fields

from conftest import (
    ConfiguredComponent,
    HistoryComponent,
    MinimalComponent,
    SimpleAdder,
    VersionedComponent,
)


class TestComponentInit:
    """Tests for Component.__init__ and field initialization."""

    def test_component_id(self, simple_adder):
        assert simple_adder.component_id == "test-adder-1"

    def test_logger_created(self, simple_adder):
        assert simple_adder.logger is not None
        assert simple_adder.logger.name == "koios.component.test-adder-1"

    def test_fields_initialized_to_defaults(self, simple_adder):
        assert simple_adder.a == 0.0
        assert simple_adder.b == 0.0
        assert simple_adder.result == 0.0

    def test_system_fields_initialized(self, simple_adder):
        assert simple_adder.enable is True
        assert simple_adder.error is False
        assert simple_adder.status == 0

    def test_config_fields_initialized(self, configured_component):
        assert configured_component.ip_address == "127.0.0.1"
        assert configured_component.timeout == 5.0
        assert configured_component.mode == "TLS"
        assert configured_component.debug is False

    def test_history_fields_initialized_to_none(self, history_component):
        assert history_component.sensor_history is None

    def test_cannot_instantiate_base_component(self):
        """Component is abstract and cannot be instantiated directly."""
        with pytest.raises(TypeError):
            Component(component_id="test")


class TestComponentExecution:
    """Tests for Component.execute()."""

    def test_simple_adder_execute(self, simple_adder):
        simple_adder.a = 3.0
        simple_adder.b = 4.0
        simple_adder.execute()
        assert simple_adder.result == 7.0

    def test_configured_component_execute(self, configured_component):
        configured_component.sensor = 10.0
        configured_component.execute()
        assert configured_component.output_val == 50.0  # 10.0 * 5.0

    def test_execute_updates_outputs(self, simple_adder):
        simple_adder.a = 1.5
        simple_adder.b = 2.5
        simple_adder.execute()
        assert simple_adder.result == 4.0


class TestComponentMeta:
    """Tests for Component Meta class and get_meta_value."""

    def test_get_meta_value_icon(self):
        assert get_meta_value(SimpleAdder, "icon") == ComponentIcon.SUM

    def test_get_meta_value_category(self):
        assert get_meta_value(SimpleAdder, "category") == ComponentCategory.MATH

    def test_get_meta_value_default(self):
        assert get_meta_value(SimpleAdder, "nonexistent", "fallback") == "fallback"

    def test_get_meta_value_none_returns_default(self):
        """If Meta attribute is None, get_meta_value returns default."""
        assert get_meta_value(SimpleAdder, "canvas_width") is None
        assert get_meta_value(SimpleAdder, "canvas_width", 6) == 6

    def test_get_meta_value_walks_mro(self):
        """get_meta_value walks the MRO chain to find Meta attributes."""

        class Parent(Component):
            class Meta:
                icon = "parent-icon"
                category = "Parent"

            x: Input[float] = Input(default=0.0)

            def execute(self):
                pass

        class Child(Parent):
            class Meta:
                icon = "child-icon"

            def execute(self):
                pass

        # Child overrides icon
        assert get_meta_value(Child, "icon") == "child-icon"
        # Child inherits category from Parent
        assert get_meta_value(Child, "category") == "Parent"

    def test_component_meta_defaults(self):
        """ComponentMeta has sensible None defaults."""
        assert ComponentMeta.canvas_width is None
        assert ComponentMeta.icon is None
        assert ComponentMeta.category is None
        assert ComponentMeta.canvas_minimal is None
        assert ComponentMeta.major is None
        assert ComponentMeta.minor is None
        assert ComponentMeta.patch is None
        assert ComponentMeta.prerelease is None


class TestGetCanvasSettings:
    """Tests for get_canvas_settings function."""

    def test_configured_width(self):
        settings = get_canvas_settings(ConfiguredComponent)
        assert settings["width"] == 10

    def test_icon_included(self):
        settings = get_canvas_settings(SimpleAdder)
        assert settings["icon"] == ComponentIcon.SUM

    def test_category_included(self):
        settings = get_canvas_settings(SimpleAdder)
        assert settings["category"] == ComponentCategory.MATH

    def test_minimal_mode(self):
        settings = get_canvas_settings(MinimalComponent)
        assert settings["minimal"] is True
        assert settings["width"] == 4

    def test_no_width_when_not_set(self):
        settings = get_canvas_settings(SimpleAdder)
        assert "width" not in settings

    def test_invalid_width_too_low(self):
        class BadWidth(Component):
            class Meta:
                canvas_width = 2

            x: Input[float] = Input(default=0.0)

            def execute(self):
                pass

        with pytest.raises(ValueError, match="between 4 and 15"):
            get_canvas_settings(BadWidth)

    def test_invalid_width_too_high(self):
        class BadWidth(Component):
            class Meta:
                canvas_width = 20

            x: Input[float] = Input(default=0.0)

            def execute(self):
                pass

        with pytest.raises(ValueError, match="between 4 and 15"):
            get_canvas_settings(BadWidth)

    def test_invalid_width_type(self):
        class BadWidth(Component):
            class Meta:
                canvas_width = "wide"

            x: Input[float] = Input(default=0.0)

            def execute(self):
                pass

        with pytest.raises(ValueError, match="must be an integer"):
            get_canvas_settings(BadWidth)

    def test_empty_settings_for_bare_component(self):
        class Bare(Component):
            x: Input[float] = Input(default=0.0)

            def execute(self):
                pass

        settings = get_canvas_settings(Bare)
        # No Meta overrides, so only defaults — all None
        assert "width" not in settings
        assert "icon" not in settings
        assert "category" not in settings
        assert "minimal" not in settings


class TestGetComponentVersion:
    """Tests for get_component_version function."""

    def test_component_with_own_version(self):
        version = get_component_version(VersionedComponent)
        assert version["major"] == 2
        assert version["minor"] == 1
        assert version["patch"] == 3
        assert version["prerelease"] == "beta"

    def test_fallback_to_library_version(self):
        lib_ver = {"major": 5, "minor": 2, "patch": 1}
        version = get_component_version(SimpleAdder, library_version=lib_ver)
        assert version == lib_ver

    def test_default_version(self):
        version = get_component_version(SimpleAdder)
        assert version == {"major": 1, "minor": 0, "patch": 0}

    def test_invalid_major_type(self):
        class Bad(Component):
            class Meta:
                major = "one"
                minor = 0

            x: Input[float] = Input(default=0.0)

            def execute(self):
                pass

        with pytest.raises(ValueError, match="non-negative integer"):
            get_component_version(Bad)

    def test_missing_minor_when_major_set(self):
        class Bad(Component):
            class Meta:
                major = 1

            x: Input[float] = Input(default=0.0)

            def execute(self):
                pass

        with pytest.raises(ValueError, match="minor is required"):
            get_component_version(Bad)

    def test_no_prerelease_key_when_not_set(self):
        version = get_component_version(SimpleAdder)
        assert "prerelease" not in version


class TestComponentConstants:
    """Tests for ComponentIcon, ComponentCategory, ComponentStatus."""

    def test_component_icon_values(self):
        assert ComponentIcon.PUZZLE == "puzzle"
        assert ComponentIcon.SUM == "sum"
        assert ComponentIcon.CALCULATOR == "calculator"
        assert ComponentIcon.CHART_LINE == "chart-line"

    def test_component_category_values(self):
        assert ComponentCategory.MISCELLANEOUS == "Miscellaneous"
        assert ComponentCategory.MATH == "Math"
        assert ComponentCategory.ANALYSIS == "Analysis"
        assert ComponentCategory.CONTROL == "Control"
        assert ComponentCategory.LOGIC == "Logic"

    def test_component_status_values(self):
        assert ComponentStatus.STOPPED == 0
        assert ComponentStatus.RUNNING == 1
        assert ComponentStatus.FAILED == 2


class TestComponentMethods:
    """Tests for Component instance methods."""

    def test_get_input_fields_method(self, simple_adder):
        fields = simple_adder.get_input_fields()
        assert "a" in fields
        assert "b" in fields
        assert "enable" in fields

    def test_get_output_fields_method(self, simple_adder):
        fields = simple_adder.get_output_fields()
        assert "result" in fields
        assert "error" in fields
        assert "status" in fields

    def test_get_config_fields_method(self, configured_component):
        fields = configured_component.get_config_fields()
        assert "ip_address" in fields
        assert "timeout" in fields

    def test_get_history_fields_method(self, history_component):
        fields = history_component.get_history_fields()
        assert "sensor_history" in fields

    def test_to_dict(self, simple_adder):
        simple_adder.a = 3.0
        simple_adder.b = 4.0
        simple_adder.execute()
        d = simple_adder.to_dict()
        assert d["component_id"] == "test-adder-1"
        assert d["class"] == "SimpleAdder"
        assert d["inputs"]["a"]["value"] == 3.0
        assert d["outputs"]["result"]["value"] == 7.0

    def test_repr(self, simple_adder):
        r = repr(simple_adder)
        assert "SimpleAdder" in r
        assert "test-adder-1" in r
        assert "inputs=" in r
        assert "outputs=" in r
        assert "configs=" in r

    def test_repr_with_history(self, history_component):
        r = repr(history_component)
        assert "history=" in r

    def test_sdk_base_version(self):
        assert Component.SDK_BASE_VERSION == 2

    def test_system_fields_properties(self):
        """System fields have system=True and visible=False."""
        enable_desc = Component.enable
        assert enable_desc.system is True
        assert enable_desc.visible is False

        error_desc = Component.error
        assert error_desc.system is True
        assert error_desc.visible is False

        status_desc = Component.status
        assert status_desc.system is True
        assert status_desc.visible is False
