"""
Tests for koios_component_builder.library module.
"""

import pytest

from koios_component_builder.component import Component
from koios_component_builder.fields import Input, Output
from koios_component_builder.library import ComponentLibrary

from conftest import ConfiguredComponent, SimpleAdder, VersionedComponent


class TestLibraryValidation:
    """Tests for ComponentLibrary __init_subclass__ validation."""

    def test_valid_library(self):
        """Valid library definition should not raise."""

        class TestLib(ComponentLibrary):
            name = "test-lib"
            major = 1
            minor = 0
            components = [SimpleAdder]

        assert TestLib.name == "test-lib"

    def test_missing_name_raises(self):
        with pytest.raises(TypeError, match="must define 'name'"):

            class BadLib(ComponentLibrary):
                major = 1
                minor = 0

    def test_empty_name_raises(self):
        with pytest.raises(TypeError, match="must define 'name'"):

            class BadLib(ComponentLibrary):
                name = ""
                major = 1
                minor = 0

    def test_missing_major_raises(self):
        with pytest.raises(TypeError, match="must define 'major'"):

            class BadLib(ComponentLibrary):
                name = "test"
                minor = 0

    def test_missing_minor_raises(self):
        with pytest.raises(TypeError, match="must define 'minor'"):

            class BadLib(ComponentLibrary):
                name = "test"
                major = 1

    def test_negative_major_raises(self):
        with pytest.raises(TypeError, match="non-negative integer"):

            class BadLib(ComponentLibrary):
                name = "test"
                major = -1
                minor = 0

    def test_negative_minor_raises(self):
        with pytest.raises(TypeError, match="non-negative integer"):

            class BadLib(ComponentLibrary):
                name = "test"
                major = 0
                minor = -1

    def test_negative_patch_raises(self):
        with pytest.raises(TypeError, match="non-negative integer"):

            class BadLib(ComponentLibrary):
                name = "test"
                major = 0
                minor = 0
                patch = -1

    def test_non_int_major_raises(self):
        with pytest.raises(TypeError, match="non-negative integer"):

            class BadLib(ComponentLibrary):
                name = "test"
                major = "1"
                minor = 0

    def test_non_int_minor_raises(self):
        with pytest.raises(TypeError, match="non-negative integer"):

            class BadLib(ComponentLibrary):
                name = "test"
                major = 0
                minor = 1.5

    def test_non_component_in_list_raises(self):
        with pytest.raises(TypeError, match="Component subclasses"):

            class BadLib(ComponentLibrary):
                name = "test"
                major = 1
                minor = 0
                components = ["not a component"]

    def test_non_subclass_in_list_raises(self):
        with pytest.raises(TypeError, match="Component subclasses"):

            class NotAComponent:
                pass

            class BadLib(ComponentLibrary):
                name = "test"
                major = 1
                minor = 0
                components = [NotAComponent]

    def test_empty_components_list_valid(self):
        """Empty component list is valid."""

        class EmptyLib(ComponentLibrary):
            name = "empty-lib"
            major = 1
            minor = 0
            components = []

        assert EmptyLib.components == []

    def test_no_components_attr_defaults_to_empty(self):
        """Library without components attribute gets empty list."""

        class NoCompLib(ComponentLibrary):
            name = "no-comp"
            major = 0
            minor = 1

        assert NoCompLib.components == []

    def test_patch_defaults_to_zero(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 0

        assert Lib.patch == 0

    def test_prerelease_defaults_to_none(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 0

        assert Lib.prerelease is None

    def test_description_defaults_to_empty(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 0

        assert Lib.description == ""


class TestLibraryMethods:
    """Tests for ComponentLibrary class methods."""

    def test_get_version_basic(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 2
            patch = 3

        assert Lib.get_version() == "1.2.3"

    def test_get_version_with_prerelease(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 2
            minor = 0
            patch = 0
            prerelease = "beta.1"

        assert Lib.get_version() == "2.0.0-beta.1"

    def test_get_version_no_prerelease(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 0

        assert Lib.get_version() == "1.0.0"

    def test_get_component_names(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 0
            components = [SimpleAdder, ConfiguredComponent, VersionedComponent]

        names = Lib.get_component_names()
        assert names == ["SimpleAdder", "ConfiguredComponent", "VersionedComponent"]

    def test_get_component_names_empty(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 0
            components = []

        assert Lib.get_component_names() == []

    def test_multiple_components(self):
        class Lib(ComponentLibrary):
            name = "multi"
            major = 1
            minor = 0
            components = [SimpleAdder, VersionedComponent]

        assert len(Lib.components) == 2
        assert Lib.components[0] is SimpleAdder
        assert Lib.components[1] is VersionedComponent

    def test_data_files_default_empty(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 0

        assert Lib.data_files == {}

    def test_data_files_custom(self):
        class Lib(ComponentLibrary):
            name = "test"
            major = 1
            minor = 0
            data_files = {"eds": "eds"}

        assert Lib.data_files == {"eds": "eds"}
