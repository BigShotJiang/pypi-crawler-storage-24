"""EdonGuard — wraps LangChain tools with EDON governance enforcement."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from langchain_core.tools import BaseTool

from edon import EdonClient, Decision
from edon.exceptions import EdonBlockedError, EdonEscalatedError


class _EdonWrappedTool(BaseTool):
    """A LangChain tool wrapped with EDON governance enforcement."""

    name: str = ""
    description: str = ""
    _wrapped: Any = None
    _edon: Any = None
    _agent_id: str = "langchain-agent"
    _intent_id: Optional[str] = None
    _raise_on_block: bool = True

    class Config:
        arbitrary_types_allowed = True

    def _run(self, *args: Any, **kwargs: Any) -> Any:
        """Evaluate via EDON, then run the wrapped tool if allowed."""
        tool_input = kwargs if kwargs else (args[0] if args else {})
        if isinstance(tool_input, str):
            tool_input = {"input": tool_input}

        action_type = f"tool.{self.name.lower().replace(' ', '_').replace('-', '_')}"

        decision: Decision = self._edon.evaluate(
            action_type,
            tool_input if isinstance(tool_input, dict) else {"input": str(tool_input)},
            agent_id=self._agent_id,
            intent_id=self._intent_id,
            raise_on_block=False,
        )

        if decision.blocked:
            if self._raise_on_block:
                raise EdonBlockedError(
                    decision.decision_reason,
                    action_id=decision.action_id,
                    reason_code=decision.reason_code,
                )
            return f"[EDON BLOCKED] {decision.decision_reason}"

        if decision.needs_human:
            if self._raise_on_block:
                raise EdonEscalatedError(
                    decision.decision_reason,
                    action_id=decision.action_id,
                    question=decision.escalation_question,
                )
            return f"[EDON ESCALATED] Human approval required: {decision.decision_reason}"

        return self._wrapped._run(*args, **kwargs)

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        return self._run(*args, **kwargs)


class EdonGuard:
    """Factory for wrapping LangChain tools with EDON governance.

    Usage::

        from langchain_edon import EdonGuard
        from langchain_community.tools import DuckDuckGoSearchRun, GmailSendMessage

        governed_tools = EdonGuard.wrap_tools(
            tools=[DuckDuckGoSearchRun(), GmailSendMessage()],
            api_key=os.environ["EDON_API_KEY"],
            agent_id="research-agent-01",
        )

        agent = create_tool_calling_agent(llm, governed_tools, prompt)
        executor = AgentExecutor(agent=agent, tools=governed_tools)
    """

    @staticmethod
    def wrap_tools(
        tools: List[Any],
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        agent_id: str = "langchain-agent",
        intent_id: Optional[str] = None,
        raise_on_block: bool = True,
    ) -> List[Any]:
        """Wrap a list of LangChain tools with EDON governance.

        Each tool call is evaluated by EDON before execution. Blocked actions
        raise ``EdonBlockedError`` (or return an error string if raise_on_block=False).

        Args:
            tools:          List of LangChain BaseTool instances.
            api_key:        EDON API key (default: ``EDON_API_KEY`` env var).
            base_url:       EDON gateway URL (default: ``EDON_BASE_URL`` or cloud).
            agent_id:       Identifier for this agent in the audit trail.
            intent_id:      Active intent contract ID.
            raise_on_block: Raise on BLOCK/ESCALATE (True) or return error string (False).

        Returns:
            List of governed tools with the same LangChain interface.
        """
        client = EdonClient(
            api_key=api_key,
            base_url=base_url,
            agent_id=agent_id,
            intent_id=intent_id,
            raise_on_block=False,
        )

        governed = []
        for tool in tools:
            wrapped = _EdonWrappedTool()
            wrapped.name = tool.name
            wrapped.description = tool.description
            wrapped._wrapped = tool
            wrapped._edon = client
            wrapped._agent_id = agent_id
            wrapped._intent_id = intent_id
            wrapped._raise_on_block = raise_on_block
            governed.append(wrapped)

        return governed

    @staticmethod
    def wrap(
        tool: Any,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        agent_id: str = "langchain-agent",
        intent_id: Optional[str] = None,
        raise_on_block: bool = True,
    ) -> Any:
        """Wrap a single LangChain tool with EDON governance."""
        return EdonGuard.wrap_tools(
            [tool],
            api_key=api_key,
            base_url=base_url,
            agent_id=agent_id,
            intent_id=intent_id,
            raise_on_block=raise_on_block,
        )[0]
