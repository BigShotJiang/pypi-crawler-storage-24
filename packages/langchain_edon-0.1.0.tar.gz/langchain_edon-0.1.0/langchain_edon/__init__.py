"""EDON governance for LangChain agents.

Two integration patterns:

**Tool wrapping** (recommended) — evaluates each tool call against EDON policy
before execution. Blocked actions raise ``EdonBlockedError`` or return an
error string to the LLM (depending on ``raise_on_block``).

    from langchain_edon import EdonGuard
    from langchain_community.tools import DuckDuckGoSearchRun, GmailSendMessage

    governed_tools = EdonGuard.wrap_tools(
        tools=[DuckDuckGoSearchRun(), GmailSendMessage()],
        api_key="your-edon-key",
        agent_id="research-agent",
    )
    agent = create_tool_calling_agent(llm, governed_tools, prompt)
    executor = AgentExecutor(agent=agent, tools=governed_tools)

**Callback handler** — logs all tool calls to EDON for audit (non-blocking):

    from langchain_edon import EdonCallbackHandler

    handler = EdonCallbackHandler(api_key="your-edon-key", agent_id="my-agent")
    executor = AgentExecutor(agent=agent, tools=tools, callbacks=[handler])
"""

from langchain_edon.guard import EdonGuard
from langchain_edon.callback import EdonCallbackHandler

__all__ = ["EdonGuard", "EdonCallbackHandler"]
__version__ = "0.1.0"
