"""EdonCallbackHandler — non-blocking audit logging for LangChain agents."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from langchain_core.callbacks import BaseCallbackHandler

from edon import EdonClient


class EdonCallbackHandler(BaseCallbackHandler):
    """LangChain callback handler that logs all tool calls to EDON for audit.

    This handler does NOT block execution — it records every tool invocation
    to EDON's tamper-evident audit trail. Use alongside ``EdonGuard`` for full
    governance + audit, or standalone for pure observability.

    Usage::

        from langchain_edon import EdonCallbackHandler

        handler = EdonCallbackHandler(
            api_key=os.environ["EDON_API_KEY"],
            agent_id="research-agent",
            verbose=True,
        )
        executor = AgentExecutor(
            agent=agent,
            tools=tools,
            callbacks=[handler],
        )

    All tool calls appear in your EDON console at edoncore.com.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        agent_id: str = "langchain-agent",
        intent_id: Optional[str] = None,
        verbose: bool = False,
    ):
        super().__init__()
        self._client = EdonClient(
            api_key=api_key,
            base_url=base_url,
            agent_id=agent_id,
            intent_id=intent_id,
            raise_on_block=False,
        )
        self._agent_id = agent_id
        self._intent_id = intent_id
        self._verbose = verbose

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called by LangChain before a tool executes. Logs to EDON audit trail."""
        tool_name = serialized.get("name", "unknown_tool")
        action_type = f"tool.{tool_name.lower().replace(' ', '_').replace('-', '_')}"

        try:
            payload: Dict[str, Any] = (
                json.loads(input_str)
                if input_str.strip().startswith("{")
                else {"input": input_str}
            )
        except (json.JSONDecodeError, AttributeError):
            payload = {"input": str(input_str)}

        try:
            decision = self._client.evaluate(
                action_type,
                payload,
                agent_id=self._agent_id,
                intent_id=self._intent_id,
                raise_on_block=False,
            )
            if self._verbose:
                print(f"[EDON] {tool_name} -> {decision.decision} ({decision.processing_latency_ms}ms)")
        except Exception as exc:
            if self._verbose:
                print(f"[EDON] audit failed for {tool_name}: {exc}")

    def on_tool_end(self, output: str, *, run_id: UUID, **kwargs: Any) -> None:
        pass

    def on_tool_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        if self._verbose:
            print(f"[EDON] tool error: {error}")

    def on_llm_start(self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any) -> None:
        pass

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        pass

    def on_chain_start(self, serialized: Dict[str, Any], inputs: Dict[str, Any], **kwargs: Any) -> None:
        pass

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs: Any) -> None:
        pass
