# DataLad extension for functionality that was phased out of the core package

[![GitHub release](https://img.shields.io/github/release/datalad/datalad-deprecated.svg)](https://GitHub.com/datalad/datalad-deprecated/releases/) [![PyPI version fury.io](https://badge.fury.io/py/datalad-deprecated.svg)](https://pypi.python.org/pypi/datalad-deprecated/) [![Build status](https://ci.appveyor.com/api/projects/status/ulbsyym6ih102gm2/branch/master?svg=true)](https://ci.appveyor.com/project/mih/datalad-deprecated/branch/master) [![codecov.io](https://codecov.io/github/datalad/datalad-deprecated/coverage.svg?branch=master)](https://codecov.io/github/datalad/datalad-deprecated?branch=master) [![crippled-filesystems](https://github.com/datalad/datalad-deprecated/workflows/crippled-filesystems/badge.svg)](https://github.com/datalad/datalad-deprecated/actions?query=workflow%3Acrippled-filesystems) [![Documentation](https://readthedocs.org/projects/datalad-deprecated/badge/?version=latest)](http://docs.datalad.org/projects/deprecated/en/latest/?badge=latest)

Commands provided by this extension

- `annotate-paths` -- analyze and act upon input paths
- `diff` -- old'ish implementation for differences between two states 
- `ls` -- list summary information about URLs and datasets
   of a dataset (hierarchy)
- `publish` -- original implementation, replaced by `push` in core
- metadata commands `search`, `metadata`, `extract-metadata` and
  `aggregate-metadata`; moved out of core in favor of the `datalad-metalad`
  extension

Procedures provided by this extension

- `cfg_metadatatypes`


In addition, this extension provides the `AutomagicIO` feature that patches Python's
`open()` function to automatically obtain file content, if needed.

It also provides the web user interface that is used at http://datasets.datalad.org
(yet to be migrated to https://github.com/datalad/datalad-webui fully).


## Acknowledgements

This work was performed by a US-German collaboration in computational
neuroscience (CRCNS) co-funded by the US National Science Foundation (NSF
1429999) and the German Federal Ministry of Education and Research (BMBF
01GQ1411).
