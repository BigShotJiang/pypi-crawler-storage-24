"""Pipeline utils: duration formatting, dynamic stage labels for logging."""

from __future__ import annotations

from typing import Any, Mapping

# Defaults
DEFAULT_OUTPUT_DIR = "out"


def build_stage_log_plan(
    cfg: Mapping[str, Any], dump: bool
) -> tuple[tuple[str, ...], dict[int, int]]:
    """Build ordered stage labels and map logical pipeline stage (1–11) → 1-based display index.

    Must match which ``_stage_*`` steps actually emit ``_stage`` logs for this run:
    - Chunks (3), Timeline/Visualize/Evaluation (9–11): only when ``dump``.
    - Failure inference (5): only when ``GEMINI_API_KEY`` is set.
    - Translate (7): only when ``TRANSLATION_TARGET_LANGUAGE`` is non-empty
      (same rule as ``_stage_7_translation``).
    """
    labels: list[str] = []
    logical_map: dict[int, int] = {}

    def append_label(logical_id: int, name: str) -> None:
        logical_map[logical_id] = len(labels) + 1
        labels.append(name)

    append_label(1, "Load")
    append_label(2, "STT")
    if dump:
        append_label(3, "Chunks")
    append_label(4, "Anomaly")
    if cfg.get("GEMINI_API_KEY"):
        append_label(5, "Failure inference")
    append_label(6, "Latency")
    _target_raw = cfg.get("TRANSLATION_TARGET_LANGUAGE")
    translation_target_language = (
        str(_target_raw).strip() if _target_raw is not None else "en"
    )
    if translation_target_language:
        append_label(7, "Translate")
    append_label(8, "Export transcript")
    if dump:
        append_label(9, "Timeline")
        append_label(10, "Visualize")
        append_label(11, "Evaluation")

    return tuple(labels), logical_map


def _stage(ctx: Mapping[str, Any], stage_num: int, msg: str) -> str:
    """Prefix message with [i/total] for the active pipeline plan stored on ctx."""
    labels: tuple[str, ...] = ctx["stage_log_labels"]
    logical_map: dict[int, int] = ctx["stage_log_index"]
    if stage_num not in logical_map:
        raise KeyError(
            f"Pipeline stage {stage_num} is not active for this run (logging bug)"
        )
    i = logical_map[stage_num]
    total = len(labels)
    name = labels[i - 1]
    return f"[{i}/{total}] {name} stage: {msg}"


def _format_duration(seconds: float) -> str:
    """Format seconds as MM:SS or HH:MM:SS."""
    m, s = divmod(int(round(seconds)), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def _format_pipeline_duration(seconds: float) -> str:
    """Format pipeline duration for summary: 19s or 1:23."""
    if seconds < 60:
        return f"{int(round(seconds))}s"
    return _format_duration(seconds)
