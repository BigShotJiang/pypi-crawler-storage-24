"""CLI wrapper — imports from kulu_audio_eval (the self-contained library package)."""

from kulu_audio_eval.core.pipeline import run  # noqa: F401

__all__ = ["run"]
