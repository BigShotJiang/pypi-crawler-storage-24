"""Shim — re-exports from kulu_audio_eval.config for backwards compatibility."""

from kulu_audio_eval.config import load_config, EvalConfig, DEFAULTS  # noqa: F401
