"""Latency metrics: per-turn latency calculation, statistics, and visualization.

Computes response latency (user speech end → agent speech start) for each
conversation turn, provides summary statistics, and generates:
- latency_per_turn.csv: turn_number, e2e_turn_gap_latency_ms (and user_end_s, agent_start_s)
- latency_per_turn.png: line chart of latency (ms) by turn number
"""

from __future__ import annotations

import csv
import logging
import os
from pathlib import Path

os.environ.setdefault("MPLBACKEND", "Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import MaxNLocator

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Turn-level latency extraction
# ---------------------------------------------------------------------------


def _build_turn_latencies(segments: list[dict]) -> list[dict]:
    """Build per-turn latency records from pipeline segments.

    Latency = time from user finishing speech in turn N to agent starting
    speech in turn N+1.  This measures the agent's response time after the
    user finishes speaking.

    Uses end_speech_s (end-of-speech within segment) for user segments when
    set (by anomaly detection), so latency matches transcript.csv
    e2e_turn_gap_latency_ms (agent_start_ms - user_previous_end_speech_ms).
    Otherwise uses segment end time.

    Groups segments by turn number, finds all four boundary timestamps per turn,
    then pairs prev-turn user timestamps with next-turn agent timestamps.

    Returns a sorted list of dicts with keys:
        turn_number (the agent turn that responded),
        user_start, user_end, agent_start, agent_end (all in seconds),
        e2e_turn_gap_latency_ms (None when agent started before user finished).
    """
    turns_map: dict[int, dict] = {}
    for seg in segments:
        turn_num = seg.get("turn")
        if turn_num is None:
            continue
        if turn_num not in turns_map:
            turns_map[turn_num] = {
                "turn_number": turn_num,
                "user_start": None,
                "user_end": None,
                "agent_start": None,
                "agent_end": None,
            }
        t = turns_map[turn_num]
        if seg["speaker"] == "user":
            start = seg["start"]
            if t["user_start"] is None or start < t["user_start"]:
                t["user_start"] = start
            # Prefer end-of-speech (from energy/STT) so latency matches transcript y_pred_e2e_turn_gap_latency_ms
            end = (
                seg["end_speech_s"]
                if seg.get("end_speech_s") is not None
                else seg["end"]
            )
            if t["user_end"] is None or end > t["user_end"]:
                t["user_end"] = end
        elif seg["speaker"] == "agent":
            start = seg["start"]
            if t["agent_start"] is None or start < t["agent_start"]:
                t["agent_start"] = start
            end = (
                seg["end_speech_s"]
                if seg.get("end_speech_s") is not None
                else seg["end"]
            )
            if t["agent_end"] is None or end > t["agent_end"]:
                t["agent_end"] = end

    sorted_turns = [turns_map[k] for k in sorted(turns_map)]

    result: list[dict] = []
    for i in range(len(sorted_turns) - 1):
        prev_turn = sorted_turns[i]
        next_turn = sorted_turns[i + 1]
        user_end = prev_turn.get("user_end")
        agent_start = next_turn.get("agent_start")
        if user_end is not None and agent_start is not None:
            raw_ms = (agent_start - user_end) * 1000.0
            # None when agent started before user finished (barge-in / overlap)
            e2e_turn_gap_latency_ms: float | None = raw_ms if raw_ms >= 0 else None
            result.append(
                {
                    "turn_number": next_turn["turn_number"],
                    "user_start": prev_turn.get("user_start"),
                    "user_end": user_end,
                    "agent_start": agent_start,
                    "agent_end": next_turn.get("agent_end"),
                    "e2e_turn_gap_latency_ms": e2e_turn_gap_latency_ms,
                }
            )
    return result


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------


def _latency_ms_for_stats(record: dict, key: str) -> float | None:
    """Extract a positive latency in ms from a turn record, or None."""
    raw = record.get(key)
    if raw is None or raw == "":
        return None
    if isinstance(raw, (int, float)):
        return float(raw) if raw > 0 else None
    return None


def calculate_latency_statistics(
    turn_latencies: list[dict],
    *,
    latency_ms_key: str = "e2e_turn_gap_latency_ms",
) -> dict[str, float | int] | None:
    """Calculate summary latency statistics from turn latency records.

    Excludes the first latency (first agent response) and any non-positive
    latencies, so the reported minimum is never 0 and opening-turn latency
    is not included.

    ``latency_ms_key`` selects which field to aggregate (e.g. ``e2e_turn_gap_latency_ms``
    or ``total_e2e_latency_ms`` after the transcript stage enriches turns).

    Returns None if no latency data is available after exclusions.
    """
    if not turn_latencies:
        return None

    # Exclude first latency (turn 2 / first response), None (barge-in), and any <= 0
    latencies = [
        v
        for t in turn_latencies[1:]
        if (v := _latency_ms_for_stats(t, latency_ms_key)) is not None
    ]
    if not latencies:
        return None

    arr = np.array(latencies, dtype=np.float64)

    return {
        "count": len(latencies),
        "mean_ms": float(np.mean(arr)),
        "median_ms": float(np.median(arr)),
        "std_dev_ms": float(np.std(arr)),
        "min_ms": float(np.min(arr)),
        "max_ms": float(np.max(arr)),
        "percentile_25_ms": float(np.percentile(arr, 25)),
        "percentile_75_ms": float(np.percentile(arr, 75)),
        "percentile_95_ms": float(np.percentile(arr, 95)),
        "percentile_99_ms": float(np.percentile(arr, 99)),
    }


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------


def plot_latency_per_turn(
    turn_latencies: list[dict],
    output_path: str,
) -> None:
    """Plot per-turn latency as a line chart.

    X-axis: turn number.
    Y-axis: response latency (milliseconds).

    Args:
        turn_latencies: List of dicts with turn_number and e2e_turn_gap_latency_ms.
        output_path: Path to save the PNG file.
    """
    if not turn_latencies:
        log.warning("No turn latencies to plot for per-turn chart")
        return

    # Skip barge-in turns where latency is None
    valid = [t for t in turn_latencies if t.get("e2e_turn_gap_latency_ms") is not None]
    if not valid:
        log.warning("No valid (non-None) turn latencies to plot")
        return
    turns = [t["turn_number"] for t in valid]
    latencies = [t["e2e_turn_gap_latency_ms"] for t in valid]

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(turns, latencies, marker="o", linestyle="-", linewidth=2, markersize=8)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))

    ax.set_xlabel("Turn", fontsize=12)
    ax.set_ylabel("Response Latency (ms)", fontsize=12)
    ax.set_title("Per-Turn Latency", fontsize=14, fontweight="bold")
    ax.grid(alpha=0.3)
    fig.tight_layout()

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    log.debug("Saved per-turn latency chart to %s", output_path)


def write_latency_per_turn_csv(
    turn_latencies: list[dict],
    csv_path: str,
) -> None:
    """Write latency_per_turn.csv with turn_number and e2e_turn_gap_latency_ms (and user_end_s, agent_start_s).

    Args:
        turn_latencies: Per-turn latency records from _build_turn_latencies.
        csv_path: Output CSV file path.
    """
    path = Path(csv_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    def _ms(s: float | None) -> str | int:
        return int(round(s * 1000)) if s is not None else ""

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "turn_number",
            "user_start_ms", "user_end_ms",
            "agent_start_ms", "agent_end_ms",
            "e2e_turn_gap_latency_ms",
        ])
        for t in turn_latencies:
            lat = t.get("e2e_turn_gap_latency_ms")
            writer.writerow([
                t["turn_number"],
                _ms(t.get("user_start")),
                _ms(t.get("user_end")),
                _ms(t.get("agent_start")),
                _ms(t.get("agent_end")),
                int(round(lat)) if lat is not None else "",
            ])
    log.debug("Saved latency per-turn CSV to %s", csv_path)


# ---------------------------------------------------------------------------
# Pipeline entry point
# ---------------------------------------------------------------------------


def attach_latency_to_segments(
    segments: list[dict],
    turn_latencies: list[dict],
) -> None:
    """Attach ``e2e_turn_gap_latency_ms`` to each segment in-place.

    Agent segments of a turn receive the computed latency value (or "" when None / barge-in).
    User segments receive an empty string (no latency applicable).

    Args:
        segments: Pipeline segments (mutated in-place).
        turn_latencies: Per-turn latency records from _build_turn_latencies.
    """
    latency_by_turn: dict[int, float | None] = {
        t["turn_number"]: t["e2e_turn_gap_latency_ms"] for t in turn_latencies
    }
    for seg in segments:
        turn_num = seg.get("turn")
        if seg.get("speaker") == "agent" and turn_num in latency_by_turn:
            val = latency_by_turn[turn_num]
            seg["e2e_turn_gap_latency_ms"] = int(round(val)) if val is not None else ""
        else:
            seg["e2e_turn_gap_latency_ms"] = ""


def run_latency_metrics(
    segments: list[dict],
    output_dir: str,
) -> tuple[list[dict], dict[str, float | int] | None]:
    """Run the full latency metrics stage: stats, CSV, plots, and segment annotation.

    Mutates segments in-place by attaching ``e2e_turn_gap_latency_ms`` to each segment.

    Args:
        segments: Pipeline segments with speaker, turn, start, end.
        output_dir: Directory for output files.

    Returns:
        Tuple of (turn_latencies, stats).
    """
    out = Path(output_dir)
    turn_latencies = _build_turn_latencies(segments)
    stats = calculate_latency_statistics(turn_latencies)

    # Attach latency to segments for downstream CSV/plots
    attach_latency_to_segments(segments, turn_latencies)

    # Per-turn CSV and plot
    write_latency_per_turn_csv(turn_latencies, str(out / "latency_per_turn.csv"))
    plot_latency_per_turn(turn_latencies, str(out / "latency_per_turn.png"))

    return turn_latencies, stats
