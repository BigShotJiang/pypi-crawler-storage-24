"""ElevenLabs Speech-to-Text adapter: transcription + diarization → Kulu segments.

Uses the official ElevenLabs Python SDK (elevenlabs.client.ElevenLabs):
  client.speech_to_text.convert(
    file=...,
    model_id="scribe_v2",
    tag_audio_events=True,
    language_code="eng" or None,
    diarize=True,
  )
Response has language_code, text, words[] with start, end, speaker_id, type.

Returns segments in Kulu format (start, end, text, speaker as agent/user, turn).
"""

from __future__ import annotations

import json
import logging
from io import BytesIO
from pathlib import Path
from typing import Any

from elevenlabs.client import ElevenLabs

from kulu_audio_eval.services.two_cluster import _assign_turns, _speaker_to_agent_user

log = logging.getLogger(__name__)

# Official example: model_id="scribe_v2", tag_audio_events=True, language_code="eng", diarize=True
MODEL_ID = "scribe_v2"


def _group_words_into_segments(words: list[dict]) -> list[dict]:
    """Group consecutive words with same speaker_id into segments (ref: TranscriptDisplay.tsx)."""
    if not words:
        return []
    segments: list[dict] = []
    current_speaker: str | None = None
    current_text_parts: list[str] = []
    segment_start: float = 0.0
    last_word_end: float = 0.0
    for w in words:
        kind = w.get("type") or ""
        if kind == "spacing":
            if current_text_parts:
                current_text_parts.append(" ")
            continue
        if kind != "word":
            continue
        spk = w.get("speaker_id") or ""
        start_s = float(w.get("start", 0))
        end_s = float(w.get("end", 0))
        text = (w.get("text") or "").strip()
        if not text:
            continue
        if current_speaker is None:
            current_speaker = spk
            segment_start = start_s
            current_text_parts = [text]
            last_word_end = end_s
        elif spk != current_speaker:
            segments.append(
                {
                    "start": segment_start,
                    "end": last_word_end,
                    "text": "".join(current_text_parts).strip(),
                    "speaker": current_speaker,
                }
            )
            current_speaker = spk
            segment_start = start_s
            current_text_parts = [text]
            last_word_end = end_s
        else:
            current_text_parts.append(text)
            last_word_end = end_s
    if current_speaker is not None and current_text_parts:
        segments.append(
            {
                "start": segment_start,
                "end": last_word_end,
                "text": "".join(current_text_parts).strip(),
                "speaker": current_speaker,
            }
        )
    return segments


def _transcription_to_dict(transcription: object) -> dict[str, Any]:
    """Convert SDK transcription response to a dict (for cache and _response_to_segments)."""
    if hasattr(transcription, "model_dump"):
        # ElevenLabs SDK Pydantic model; model_dump() returns dict (untyped in SDK)
        return transcription.model_dump()  # type: ignore[no-any-return]
    if isinstance(transcription, dict):
        return transcription
    # Fallback: build dict from attributes
    out: dict[str, Any] = {}
    for key in ("language_code", "language_probability", "text", "words"):
        if hasattr(transcription, key):
            val = getattr(transcription, key)
            if hasattr(val, "model_dump"):
                out[key] = [
                    x.model_dump() if hasattr(x, "model_dump") else x for x in val
                ]
            else:
                out[key] = val
    return out


def _call_speech_to_text(
    audio_path: str, api_key: str, language_code: str | None
) -> dict:
    """Call ElevenLabs Speech-to-Text via official SDK; return response as dict."""
    path = Path(audio_path)
    if not path.is_file():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    with open(path, "rb") as f:
        audio_data = BytesIO(f.read())

    client = ElevenLabs(api_key=api_key)
    transcription = client.speech_to_text.convert(
        file=audio_data,
        model_id=MODEL_ID,
        tag_audio_events=True,
        language_code=language_code or None,  # None = auto-detect
        diarize=True,
    )
    return _transcription_to_dict(transcription)


def _words_to_dicts(words: list) -> list[dict]:
    """Ensure each word is a dict (from cache or SDK model_dump)."""
    out: list[dict] = []
    for w in words:
        if isinstance(w, dict):
            out.append(w)
        elif hasattr(w, "model_dump"):
            out.append(w.model_dump())
        else:
            out.append(dict(w) if hasattr(w, "items") else {})
    return out


def _response_to_segments(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Convert raw ElevenLabs API response to Kulu segments (agent/user, turns)."""
    raw_words = data.get("words") or []
    words = _words_to_dicts(raw_words)
    if not words:
        return []
    segments = _group_words_into_segments(words)
    _speaker_to_agent_user(segments)
    _assign_turns(segments)
    return segments


def run_elevenlabs_pipeline(
    audio_path: str,
    config: dict,
    cache_path: str | Path | None = None,
) -> list[dict]:
    """Call ElevenLabs Speech-to-Text with diarization; return Kulu-style segments.

    When cache_path is set and the file exists, the API is skipped and segments
    are built from the cached raw response. Otherwise the API is called and the
    raw response is written to cache_path for future runs.

    Uses official ElevenLabs SDK: speech_to_text.convert with model_id=scribe_v2,
    tag_audio_events=True, diarize=True, language_code from config or auto.

    Args:
        audio_path: Path to input audio file.
        config: Must contain elevenlabs_api_key or ELEVENLABS_API_KEY (unless using cache).
        cache_path: Optional path to store/load raw API JSON (e.g. out/<stem>/<audio_name>.json).

    Returns:
        List of segment dicts: start (float s), end (float s), text (str),
        speaker ("agent"|"user"), turn (int).
    """
    cache_file = Path(cache_path) if cache_path else None
    if cache_file is not None and cache_file.is_file():
        log.info("Using cached ElevenLabs output: %s", cache_file)
        with open(cache_file, encoding="utf-8") as f:
            data = json.load(f)
        return _response_to_segments(data)

    api_key = (
        config.get("elevenlabs_api_key") or config.get("ELEVENLABS_API_KEY") or ""
    ).strip()
    if not api_key:
        raise ValueError(
            "ELEVENLABS_API_KEY is required for method=elevenlabs. "
            "Set it in .env or pass in config."
        )

    language_code = (
        config.get("language") or config.get("LANGUAGE") or ""
    ).strip() or None
    log.info(
        "Calling ElevenLabs Speech-to-Text (model=%s, diarize=True, language_code=%s)…",
        MODEL_ID,
        language_code or "auto",
    )
    data = _call_speech_to_text(audio_path, api_key, language_code)

    if cache_file is not None:
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        log.info("Cached raw ElevenLabs response to %s", cache_file)

    return _response_to_segments(data)
