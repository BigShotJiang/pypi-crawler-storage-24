"""Gemini-based failed response inference.

Sends the transcript (speaker, turn, text) to Gemini in batches (default
10 turns per batch, from shared gemini_config) with prior turns as context,
and receives per-turn quality verdicts in structured JSON. Batches run in
parallel via ThreadPoolExecutor.

Detected failures are appended to each segment's ``failed_response`` list
and a ``failed_response_rationale`` string is set on affected segments so
they flow through the existing CSV/JSON export pipeline.
"""

from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

from google import genai
from google.genai import types

from kulu_audio_eval.utils.gemini_config import (
    GEMINI_BATCH_SIZE,
    GEMINI_MAX_WORKERS,
    GEMINI_MODEL,
    create_gemini_client,
)

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configurable parameters (batch size and workers from shared gemini_config)
# ---------------------------------------------------------------------------
MAX_HISTORY_TOKENS = 6000
TEMPERATURE = 0.3
TOP_P = 0.95
TOP_K = 40
MAX_OUTPUT_TOKENS = 10000
# Rough estimate: ~4 characters per token for conversational text
_CHARS_PER_TOKEN = 4

_SYSTEM_PROMPT = """\
=== CONTEXT ===
You are a **Realtime Voice Agent Response Reviewer**.  Your job is to
review an AI voice agent's responses in a conversation transcript and
detect failed or low-quality agent responses.

The transcript contains turns between a "user" (human caller) and an
"agent" (AI voice assistant).  The transcript is split into two sections:

- **CONTEXT (previous turns):** Provided so you understand the
  conversation history.  Do NOT evaluate these turns.
- **EVALUATE (current batch):** You MUST evaluate ONLY the agent
  responses in these turns.  Ignore user turns.

=== ACTION ===
For each turn in the EVALUATE section, think step-by-step:

1. Read the user's message in this turn (or the preceding user turn).
2. Read the agent's response in this turn.
3. Consider the full conversation context: what language was agreed on?
   What topic is being discussed?  What did the user ask for?
4. Decide whether the agent's response is acceptable or failed.
5. If failed, classify the failure type and write a clear rationale
   in English explaining WHY it failed.

Failure types to detect:
- **irrelevant_response**: Agent's answer does not address what the user
  said or asked.  The agent goes off-topic or ignores the question.
- **repetition**: Agent repeats the same phrase, sentence, or idea it
  already said in a previous turn, or gets stuck in a loop.
- **hallucination**: Agent states factual information that is clearly
  fabricated or wrong given the conversation context.
- **incomplete_answer**: Agent starts responding but stops prematurely,
  gives only a one-word acknowledgement without follow-up, or fails to
  complete its thought.
- **wrong_language**: Agent responds in a different language than what
  was established or requested by the user.
- **other**: Any other quality issue (e.g., inappropriate tone, refusal
  to help when it should, contradicting itself).

=== RESULT ===
Return a JSON object with a single key "turns" containing an array.
- Include ONLY turns where has_failure is true.
- If all agent responses are acceptable, return: {"turns": []}
- Each entry must have: turn_number (int), has_failure (true),
  failure_type (string from the list above), reason (string in English).
- The "reason" field must be a clear, specific rationale in **English**
  explaining what went wrong and why, referencing the actual content.
- Always respond in English regardless of the transcript language.

=== EXAMPLES ===

Example 1 — Failed response (wrong_language):
Transcript:
  [Turn 1] user: Привет, давай поговорим на русском.
  [Turn 2] agent: Конечно, давайте общаться на русском языке!
  [Turn 3] user: Расскажи мне о погоде.
  [Turn 4] agent: Hello! How can I help you today?
Expected output:
{"turns": [{"turn_number": 4, "has_failure": true, "failure_type": "wrong_language", "reason": "The user established Russian as the conversation language in Turn 1 and the agent agreed in Turn 2, but in Turn 4 the agent switched to English unprompted."}]}

Example 2 — Failed response (incomplete_answer):
Transcript:
  [Turn 1] user: Can you help me reset my password?
  [Turn 2] agent: Sure!
  [Turn 3] user: Okay, what do I do?
  [Turn 4] agent: Understood.
Expected output:
{"turns": [{"turn_number": 2, "has_failure": true, "failure_type": "incomplete_answer", "reason": "The agent said 'Sure!' but did not provide any instructions or next steps for the password reset. The user had to prompt again."}, {"turn_number": 4, "has_failure": true, "failure_type": "incomplete_answer", "reason": "The agent responded with only 'Understood' without providing the actual password reset steps the user asked for."}]}

Example 3 — Failed response (repetition):
Transcript:
  [Turn 1] user: What are your business hours?
  [Turn 2] agent: Our business hours are 9 AM to 5 PM, Monday to Friday.
  [Turn 3] user: And on weekends?
  [Turn 4] agent: Our business hours are 9 AM to 5 PM, Monday to Friday.
Expected output:
{"turns": [{"turn_number": 4, "has_failure": true, "failure_type": "repetition", "reason": "The agent repeated the exact same response from Turn 2 instead of answering the user's question about weekend hours."}]}

Example 4 — No failures:
Transcript:
  [Turn 1] user: Hi, what time does the store close?
  [Turn 2] agent: Hello! The store closes at 8 PM today. Is there anything else?
  [Turn 3] user: No, thanks!
  [Turn 4] agent: You're welcome! Have a great day.
Expected output:
{"turns": []}
"""

_RESPONSE_SCHEMA = types.Schema(
    type=types.Type.OBJECT,
    properties={
        "turns": types.Schema(
            type=types.Type.ARRAY,
            items=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "turn_number": types.Schema(type=types.Type.INTEGER),
                    "has_failure": types.Schema(type=types.Type.BOOLEAN),
                    "failure_type": types.Schema(
                        type=types.Type.STRING,
                        enum=[
                            "irrelevant_response",
                            "repetition",
                            "hallucination",
                            "incomplete_answer",
                            "wrong_language",
                            "other",
                        ],
                    ),
                    "reason": types.Schema(type=types.Type.STRING),
                },
                required=["turn_number", "has_failure", "failure_type", "reason"],
            ),
        ),
    },
    required=["turns"],
)

_GENAI_CONFIG = types.GenerateContentConfig(
    system_instruction=_SYSTEM_PROMPT,
    temperature=TEMPERATURE,
    top_p=TOP_P,
    top_k=TOP_K,
    max_output_tokens=MAX_OUTPUT_TOKENS,
    response_mime_type="application/json",
    response_schema=_RESPONSE_SCHEMA,
)


def _build_turn_text(segments: list[dict]) -> list[tuple[int, str]]:
    """Group segments by turn and build one text line per turn.

    Returns list of (turn_number, formatted_line) in turn order.
    """
    turn_lines: dict[int, list[str]] = {}
    for seg in segments:
        turn = seg.get("turn")
        if turn is None:
            continue
        speaker = seg.get("speaker", "unknown")
        text = seg.get("text", "")
        turn_lines.setdefault(int(turn), []).append(f"{speaker}: {text}")

    result: list[tuple[int, str]] = []
    for turn_num in sorted(turn_lines):
        combined = " ".join(turn_lines[turn_num])
        result.append((turn_num, f"[Turn {turn_num}] {combined}"))
    return result


def _trim_context(context_lines: list[str], max_tokens: int) -> list[str]:
    """Trim context lines from the oldest to fit within max_tokens.

    Keeps the most recent lines (closest to the eval batch) so Gemini
    always has the immediately preceding conversation flow.
    """
    max_chars = max_tokens * _CHARS_PER_TOKEN
    total_chars = sum(len(line) for line in context_lines)
    if total_chars <= max_chars:
        return context_lines

    # Drop oldest lines until we fit
    trimmed = list(context_lines)
    while trimmed and total_chars > max_chars:
        total_chars -= len(trimmed[0])
        trimmed.pop(0)
    return trimmed


def _build_batch_prompt(
    context_lines: list[str],
    eval_lines: list[str],
) -> str:
    """Build the prompt with CONTEXT and EVALUATE sections."""
    trimmed_context = _trim_context(context_lines, MAX_HISTORY_TOKENS)
    parts: list[str] = []
    if trimmed_context:
        parts.append("=== CONTEXT (do NOT evaluate) ===")
        parts.extend(trimmed_context)
        parts.append("")
    parts.append("=== EVALUATE (assess these turns) ===")
    parts.extend(eval_lines)
    return "\n".join(parts)


def _infer_batch(
    client: genai.Client,
    context_lines: list[str],
    eval_lines: list[str],
    eval_turn_numbers: list[int],
) -> list[dict]:
    """Run a single Gemini inference for one batch of turns.

    Returns list of failure event dicts.
    """
    prompt = _build_batch_prompt(context_lines, eval_lines)
    if not prompt.strip():
        return []

    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=_GENAI_CONFIG,
        )
    except Exception:
        log.exception(
            "Gemini API call failed for turns %s-%s",
            eval_turn_numbers[0] if eval_turn_numbers else "?",
            eval_turn_numbers[-1] if eval_turn_numbers else "?",
        )
        return []

    text = response.text
    if not text:
        return []
    try:
        result = json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError):
        log.error(
            "Gemini returned invalid JSON for turns %s-%s: %s",
            eval_turn_numbers[0] if eval_turn_numbers else "?",
            eval_turn_numbers[-1] if eval_turn_numbers else "?",
            (response.text or "")[:200],
        )
        return []

    failures: list[dict] = []
    for entry in result.get("turns", []):
        if not entry.get("has_failure"):
            continue
        turn_num = entry.get("turn_number")
        if turn_num is None:
            continue
        turn_num = int(turn_num)
        if turn_num not in eval_turn_numbers:
            log.warning(
                "Gemini returned turn %d outside eval range %s-%s, skipping",
                turn_num,
                eval_turn_numbers[0],
                eval_turn_numbers[-1],
            )
            continue
        failures.append(
            {
                "type": f"gemini_{entry['failure_type']}",
                "turn_number": turn_num,
                "reason": entry.get("reason", ""),
            }
        )
    return failures


def infer_failed_responses(
    segments: list[dict],
    config: dict,
) -> list[dict]:
    """Call Gemini Pro 3 to infer failed responses from transcript text.

    Splits the conversation into batches of 10 turns.  Each batch includes
    all previous turns as context so Gemini understands the conversation
    flow.  Batches run in parallel via ThreadPoolExecutor.

    Mutates segments in-place by appending to ``failed_response`` lists and
    setting ``failed_response_rationale`` on affected segments.

    Returns the flat list of new Gemini-detected failure events.

    Args:
        segments: Pipeline segments with speaker, turn, text.
        config: Config dict (requires ``GEMINI_API_KEY``).
    """
    client = create_gemini_client(config)
    if client is None:
        log.warning("GEMINI_API_KEY not set, skipping Gemini inference")
        return []

    turn_lines = _build_turn_text(segments)
    if not turn_lines:
        return []

    # Build batches (size from shared gemini_config), with all previous turns as context
    batches: list[tuple[list[str], list[str], list[int]]] = []
    for batch_start in range(0, len(turn_lines), GEMINI_BATCH_SIZE):
        batch_end = batch_start + GEMINI_BATCH_SIZE
        context = [line for _, line in turn_lines[:batch_start]]
        eval_items = turn_lines[batch_start:batch_end]
        eval_lines = [line for _, line in eval_items]
        eval_turns = [num for num, _ in eval_items]
        batches.append((context, eval_lines, eval_turns))

    log.info(
        "Running %d Gemini batch(es) (%d turns total, %d per batch)",
        len(batches),
        len(turn_lines),
        GEMINI_BATCH_SIZE,
    )
    all_failures: list[dict] = []

    # Run batches in parallel
    max_workers = min(len(batches), GEMINI_MAX_WORKERS)
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_infer_batch, client, ctx, ev, turns): turns
            for ctx, ev, turns in batches
        }
        for future in as_completed(futures):
            batch_turns = futures[future]
            try:
                batch_failures = future.result()
                all_failures.extend(batch_failures)
            except Exception:
                log.exception(
                    "Gemini batch failed for turns %s-%s",
                    batch_turns[0] if batch_turns else "?",
                    batch_turns[-1] if batch_turns else "?",
                )

    if not all_failures:
        log.debug("Gemini found no failed responses")
        return all_failures

    apply_failures_to_segments(segments, all_failures)
    failure_by_turn: dict[int, list[dict]] = {}
    for event in all_failures:
        failure_by_turn.setdefault(event["turn_number"], []).append(event)
    log.debug(
        "Gemini inference: %d failures across %d turns",
        len(all_failures),
        len(failure_by_turn),
    )
    return all_failures


def apply_failures_to_segments(segments: list[dict], all_failures: list[dict]) -> None:
    """Apply a list of failure events to segments (mutates segments in-place).

    Builds turn_number -> failures lookup, resolves timestamps from segment
    start times, then appends to each segment's failed_response and sets
    failed_response_rationale. Use this when loading failures from cache.

    Args:
        segments: Pipeline segments with speaker, turn, start.
        all_failures: List of failure dicts with turn_number, reason, etc.
    """
    if not all_failures:
        return
    failure_by_turn: dict[int, list[dict]] = {}
    for event in all_failures:
        turn_num = event["turn_number"]
        failure_by_turn.setdefault(turn_num, []).append(event)

    turn_timestamp: dict[int, float] = {}
    for seg in segments:
        turn_num = seg.get("turn")
        if turn_num in failure_by_turn and seg.get("speaker") == "agent":
            turn_timestamp.setdefault(int(turn_num), seg["start"])
    for event in all_failures:
        event["timestamp"] = round(turn_timestamp.get(event["turn_number"], 0.0), 3)

    for seg in segments:
        turn_num = seg.get("turn")
        if turn_num in failure_by_turn:
            seg.setdefault("failed_response", []).extend(failure_by_turn[turn_num])
            reasons = [e["reason"] for e in failure_by_turn[turn_num] if e["reason"]]
            seg["failed_response_rationale"] = "; ".join(reasons)
