"""
Load evaluation config from code defaults and .env.

Usage:
    from kulu_audio_eval.config import load_config
    cfg = load_config()

Env vars (prefix by stage; copy to .env and set):

  Pipeline uses ElevenLabs Speech-to-Text API (transcribe + diarize). Set ELEVENLABS_API_KEY.

  Diarizer:
    DIARIZER_NUM_SPEAKERS  Expected number of speakers (default 2).

  Turn annotation / chunking:
    TURN_MIN_CHUNK_DURATION_S  Min turn/chunk duration in seconds (default 3).
                              Shorter segments are merged or padded.

  Translation (text_eng; Gemini):
    TRANSLATION_TARGET_LANGUAGE  Target language code or name (e.g. en, English). Default: en. Empty = no translation.
    TRANSLATION_USE_CACHE       If true, load/save translation results under output dir (default: true).
    TRANSLATION_MAX_WORKERS     Parallel workers for Gemini translation batches (default: 4).

  Cutout detection:
    CUTOUT_SILENT_THRESHOLD_DB  Energy threshold in dB relative to global 95th-percentile RMS.
                          Frames below this are considered "silent". Default: -40.
    CUTOUT_THRESHOLD_MS  Minimum duration in ms for cutout_mid (middle cutouts).
                          Only mid-segment cutouts at least this long are reported. Default: 1000.
    ENABLE_CUTOUT_BY_TRANSCRIPTION  If true, detect cutout_word events from dash-suffix words.
                          Disable to suppress false positives from barge-in interruptions. Default: false.

  Failure inference (Gemini):
    FAILURE_INFERENCE_USE_CACHE  If true, load/save Gemini failure inference results
                                  under output dir cache (default: true).

  API keys (no prefix):
    ELEVENLABS_API_KEY   Required for pipeline. From https://elevenlabs.io.
    GEMINI_API_KEY      Required for translation and failure inference. From Google AI Studio.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Callable, TypedDict, cast


class EvalConfig(TypedDict, total=False):
    """Evaluation config keys (env + defaults). All keys may be present."""

    DIARIZER_NUM_SPEAKERS: int
    TURN_MIN_CHUNK_DURATION_S: float
    TRANSLATION_TARGET_LANGUAGE: str
    TRANSLATION_USE_CACHE: bool
    TRANSLATION_MAX_WORKERS: int
    CUTOUT_SILENT_THRESHOLD_DB: float
    CUTOUT_THRESHOLD_MS: int
    ENABLE_CUTOUT_BY_TRANSCRIPTION: bool
    FAILURE_INFERENCE_USE_CACHE: bool
    ELEVENLABS_API_KEY: str | None
    GEMINI_API_KEY: str | None


# Load .env into os.environ before reading any values.
# Walk up from this file's location to find .env (works whether config.py is
# at the project root or nested inside a package like apps/cli/config.py).
# Silently skips when .env is not found (library install case — keys come via overrides).
def _load_dotenv() -> None:
    search = Path(__file__).resolve()
    for _ in range(6):
        search = search.parent
        env_path = search / ".env"
        if env_path.exists():
            break
    else:
        return  # no .env found — library install, keys come from overrides
    try:
        from dotenv import load_dotenv

        load_dotenv(env_path)
    except ImportError:
        # Fallback: read .env ourselves when python-dotenv is not installed
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip("'\"")
                if key and key not in os.environ:
                    os.environ[key] = value


_load_dotenv()


# Defaults (overridable via env vars above)
DEFAULTS: EvalConfig = {
    "DIARIZER_NUM_SPEAKERS": 2,
    "TURN_MIN_CHUNK_DURATION_S": 3.0,
    "TRANSLATION_TARGET_LANGUAGE": "en",
    "TRANSLATION_USE_CACHE": True,
    "TRANSLATION_MAX_WORKERS": 4,
    "CUTOUT_SILENT_THRESHOLD_DB": -40.0,
    "CUTOUT_THRESHOLD_MS": 1000,
    "ENABLE_CUTOUT_BY_TRANSCRIPTION": False,
    "FAILURE_INFERENCE_USE_CACHE": True,
    "ELEVENLABS_API_KEY": None,
    "GEMINI_API_KEY": None,
}

# Env var name matches config key; parser converts env string to value.
_STR = lambda s: s.strip()
_STR_OR_NONE = lambda s: s.strip() or None
_BOOL = lambda s: s.strip().lower() in ("1", "true", "yes")
_ENV_SPEC: list[tuple[str, str, Callable[[str], Any]]] = [
    ("DIARIZER_NUM_SPEAKERS", "DIARIZER_NUM_SPEAKERS", int),
    ("TURN_MIN_CHUNK_DURATION_S", "TURN_MIN_CHUNK_DURATION_S", float),
    ("TRANSLATION_TARGET_LANGUAGE", "TRANSLATION_TARGET_LANGUAGE", _STR),
    ("TRANSLATION_USE_CACHE", "TRANSLATION_USE_CACHE", _BOOL),
    ("TRANSLATION_MAX_WORKERS", "TRANSLATION_MAX_WORKERS", int),
    ("CUTOUT_SILENT_THRESHOLD_DB", "CUTOUT_SILENT_THRESHOLD_DB", float),
    ("CUTOUT_THRESHOLD_MS", "CUTOUT_THRESHOLD_MS", int),
    ("ENABLE_CUTOUT_BY_TRANSCRIPTION", "ENABLE_CUTOUT_BY_TRANSCRIPTION", _BOOL),
    ("FAILURE_INFERENCE_USE_CACHE", "FAILURE_INFERENCE_USE_CACHE", _BOOL),
    ("ELEVENLABS_API_KEY", "ELEVENLABS_API_KEY", _STR_OR_NONE),
    ("GEMINI_API_KEY", "GEMINI_API_KEY", _STR_OR_NONE),
]


def load_config(
    overrides: dict[str, Any] | None = None
) -> dict[str, str | int | float | None]:
    """Build config from defaults, .env, and optional overrides."""
    cfg: dict[str, str | int | float | None] = cast(
        dict[str, str | int | float | None], dict(DEFAULTS)
    )
    for cfg_key, env_var, parser in _ENV_SPEC:
        if env_var in os.environ:
            cfg[cfg_key] = parser(os.environ[env_var])
    if overrides:
        for k, v in overrides.items():
            if v is None or isinstance(v, (str, int, float)):
                cfg[k] = v
    return cfg
