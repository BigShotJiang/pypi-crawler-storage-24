"""Domain model tests — pure Python, zero I/O."""
import sqlite3
import json

from locram.models import Page, Link, PageType, PageStatus, LinkType, LINK_INVERSES, MATURITY_ORDER


def test_page_type_str_enum():
    assert PageType.FLEETING == "fleeting"
    assert PageType("note-taking") == PageType.NOTE_TAKING


def test_link_type_str_enum():
    assert LinkType.RELATED == "related"
    assert len(list(LinkType)) == 12


def test_link_inverses_covers_all():
    assert set(LinkType) == set(LINK_INVERSES.keys())


def test_link_inverses_symmetric():
    for lt, inv in LINK_INVERSES.items():
        if inv is not None and inv != lt:
            assert LINK_INVERSES[inv] == lt, f"Broken inverse for {lt}"


def test_maturity_order():
    assert MATURITY_ORDER == [PageType.FLEETING, PageType.NOTE_TAKING, PageType.PERMANENT]


def test_page_no_sqlite_import():
    import locram.models.page as page_mod
    import locram.models.enums as enum_mod
    import locram.models.link as link_mod
    for mod in (page_mod, enum_mod, link_mod):
        assert "sqlite3" not in dir(mod)
        assert "json" not in (mod.__dict__.get("json", None),)


def test_page_no_embedding_fields():
    page = Page(id="x", title="t")
    assert not hasattr(page, "has_embedding")
    assert not hasattr(page, "embedded_at")


def test_link_frozen():
    link = Link(source_id="a", target_id="b", link_type=LinkType.RELATED)
    import pytest
    with pytest.raises((AttributeError, TypeError)):
        link.source_id = "c"  # type: ignore
