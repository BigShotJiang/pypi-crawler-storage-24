"""LinkService: bidirectional logic, inverse map, batch."""
import pytest

from locram.models import LinkType, LINK_INVERSES


def test_extends_creates_inverse(pages_svc, links_svc, repo):
    a = pages_svc.create_page("A")
    b = pages_svc.create_page("B")
    links_svc.link_pages(a.id, b.id, "extends")

    links = repo.get_links(a.id)
    types = {(l.source_id, l.link_type) for l in links}
    assert (a.id, LinkType.EXTENDS) in types
    assert (b.id, LinkType.EXTENDED_BY) in types


def test_reference_no_inverse(pages_svc, links_svc, repo):
    a = pages_svc.create_page("Source")
    b = pages_svc.create_page("Cited")
    links_svc.link_pages(a.id, b.id, "reference")
    links = repo.get_links(b.id)
    assert all(l.link_type != LinkType.REFERENCE or l.source_id == a.id for l in links)
    # b should not have a reference link pointing to a
    b_as_source = [l for l in links if l.source_id == b.id and l.link_type == LinkType.REFERENCE]
    assert b_as_source == []


def test_related_symmetric(pages_svc, links_svc, repo):
    a = pages_svc.create_page("A")
    b = pages_svc.create_page("B")
    links_svc.link_pages(a.id, b.id, "related")
    all_links = repo.get_links(a.id)
    pairs = {(l.source_id, l.target_id) for l in all_links}
    assert (a.id, b.id) in pairs
    assert (b.id, a.id) in pairs


def test_unlink_specific_removes_inverse(pages_svc, links_svc, repo):
    a = pages_svc.create_page("A")
    b = pages_svc.create_page("B")
    links_svc.link_pages(a.id, b.id, "extends")
    links_svc.unlink_pages(a.id, b.id, "extends")
    all_links = repo.get_links(a.id)
    types = {l.link_type for l in all_links}
    assert LinkType.EXTENDS not in types
    assert LinkType.EXTENDED_BY not in types


def test_unlink_all(pages_svc, links_svc, repo):
    a = pages_svc.create_page("A")
    b = pages_svc.create_page("B")
    links_svc.link_pages(a.id, b.id, "related")
    links_svc.unlink_pages(a.id, b.id)
    assert repo.get_links(a.id) == []


def test_batch_link(pages_svc, links_svc, repo):
    a = pages_svc.create_page("A")
    b = pages_svc.create_page("B")
    c = pages_svc.create_page("C")
    result = links_svc.batch_link([
        {"source_id": a.id, "target_id": b.id, "link_type": "extends"},
        {"source_id": a.id, "target_id": c.id, "link_type": "supports"},
    ])
    assert result["created"] == 2
    assert result["skipped"] == 0
    assert result["errors"] == []


def test_batch_link_skipped_on_duplicate(pages_svc, links_svc):
    a = pages_svc.create_page("A")
    b = pages_svc.create_page("B")
    r1 = links_svc.batch_link([{"source_id": a.id, "target_id": b.id, "link_type": "related"}])
    r2 = links_svc.batch_link([{"source_id": a.id, "target_id": b.id, "link_type": "related"}])
    assert r1["created"] == 1
    assert r2["created"] == 0
    assert r2["skipped"] == 1


def test_promote_fleeting_to_note_taking(pages_svc):
    page = pages_svc.create_page("Raw idea", type="fleeting")
    result = pages_svc.promote_page(page.id)
    assert result["new_type"] == "note-taking"


def test_promote_note_taking_to_permanent(pages_svc):
    page = pages_svc.create_page("Refined", type="note-taking")
    result = pages_svc.promote_page(page.id)
    assert result["new_type"] == "permanent"


def test_promote_permanent_rejected(pages_svc):
    page = pages_svc.create_page("Done", type="permanent")
    result = pages_svc.promote_page(page.id)
    assert "error" in result


def test_promote_structure_rejected(pages_svc):
    page = pages_svc.create_page("Map", type="structure")
    result = pages_svc.promote_page(page.id)
    assert "error" in result
    assert "classification" in result["error"]


def test_promote_hub_rejected(pages_svc):
    page = pages_svc.create_page("Hub", type="hub")
    result = pages_svc.promote_page(page.id)
    assert "error" in result
    assert "classification" in result["error"]
