import os
import tempfile
from pathlib import Path

import pytest

from locram.adapters.db import init_db
from locram.adapters.sqlite_page_repo import SqlitePageRepository
from locram.adapters.sqlite_embedding_store import SqliteEmbeddingStore
from locram.config import DB_PATH, VAULT_PATH
from locram.services import LinkService, PageService, SearchService, GraphService
from locram.vault.writer import ObsidianVaultStore


@pytest.fixture()
def tmp_home(tmp_path, monkeypatch):
    monkeypatch.setenv("LOCRAM_HOME", str(tmp_path))
    # Reload config to pick up new env
    import locram.config as cfg
    monkeypatch.setattr(cfg, "LOCRAM_HOME", tmp_path)
    monkeypatch.setattr(cfg, "DB_PATH", tmp_path / "locram.db")
    monkeypatch.setattr(cfg, "VAULT_PATH", tmp_path / "vault")
    return tmp_path


@pytest.fixture()
def repo(tmp_home):
    db = tmp_home / "locram.db"
    init_db(db)
    return SqlitePageRepository(db)


@pytest.fixture()
def vault(tmp_home):
    v = tmp_home / "vault"
    v.mkdir(exist_ok=True)
    db = tmp_home / "locram.db"
    return ObsidianVaultStore(v, db_path=db)


@pytest.fixture()
def pages_svc(repo, vault):
    return PageService(repo, vault)


@pytest.fixture()
def links_svc(repo, vault):
    return LinkService(repo, vault)


@pytest.fixture()
def search_svc(repo):
    return SearchService(repo)


@pytest.fixture()
def graph_svc(repo):
    return GraphService(repo)
