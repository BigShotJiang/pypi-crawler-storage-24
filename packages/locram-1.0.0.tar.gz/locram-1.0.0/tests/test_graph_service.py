"""Tests for GraphService — pure read-only analytics."""
import time

import pytest

from locram.models import PageType, LinkType


# ── Helpers ────────────────────────────────────────────────────────────────────

def _make(pages_svc, title, type=PageType.FLEETING, review_interval_days=7):
    return pages_svc.create_page(title=title, type=type,
                                  review_interval_days=review_interval_days)


# ── find_orphaned ──────────────────────────────────────────────────────────────

class TestFindOrphaned:

    def test_isolated_page_is_orphaned(self, pages_svc, graph_svc):
        _make(pages_svc, "Isolated")
        orphans = graph_svc.find_orphaned()
        assert any(o["title"] == "Isolated" for o in orphans)

    def test_linked_page_is_not_orphaned(self, pages_svc, links_svc, graph_svc):
        a = _make(pages_svc, "A")
        b = _make(pages_svc, "B")
        links_svc.link_pages(a.id, b.id, LinkType.RELATED)
        orphans = graph_svc.find_orphaned()
        ids = {o["id"] for o in orphans}
        assert a.id not in ids
        assert b.id not in ids

    def test_page_with_parent_is_not_orphaned(self, pages_svc, links_svc, graph_svc):
        parent = _make(pages_svc, "Parent")
        child = _make(pages_svc, "Child")
        links_svc.set_parent(child.id, parent.id)
        orphans = graph_svc.find_orphaned()
        ids = {o["id"] for o in orphans}
        assert child.id not in ids

    def test_deleted_page_excluded(self, pages_svc, graph_svc):
        p = _make(pages_svc, "DeletedOrphan")
        pages_svc.delete_page(p.id)
        orphans = graph_svc.find_orphaned()
        assert not any(o["id"] == p.id for o in orphans)

    def test_limit_respected(self, pages_svc, graph_svc):
        for i in range(5):
            _make(pages_svc, f"Solo {i}")
        result = graph_svc.find_orphaned(limit=3)
        assert len(result) <= 3

    def test_result_shape(self, pages_svc, graph_svc):
        _make(pages_svc, "ShapeCheck")
        orphans = graph_svc.find_orphaned()
        assert len(orphans) > 0
        for o in orphans:
            assert "id" in o
            assert "title" in o
            assert "type" in o
            assert "updated_at" in o


# ── find_central ───────────────────────────────────────────────────────────────

class TestFindCentral:

    def test_most_linked_page_is_first(self, pages_svc, links_svc, graph_svc):
        hub = _make(pages_svc, "Hub")
        for i in range(4):
            spoke = _make(pages_svc, f"Spoke {i}")
            links_svc.link_pages(hub.id, spoke.id, LinkType.RELATED)

        peripheral = _make(pages_svc, "Peripheral")
        side = _make(pages_svc, "Side")
        links_svc.link_pages(peripheral.id, side.id, LinkType.RELATED)

        central = graph_svc.find_central(limit=10)
        assert central, "Expected non-empty result"
        assert central[0]["id"] == hub.id, "Hub must have highest degree"

    def test_unlinked_page_not_in_central(self, pages_svc, graph_svc):
        _make(pages_svc, "Loner")
        # No other pages — find_central joins on links, so loner won't appear
        central = graph_svc.find_central()
        assert not any(c["title"] == "Loner" for c in central)

    def test_link_degree_field_present(self, pages_svc, links_svc, graph_svc):
        a = _make(pages_svc, "DegA")
        b = _make(pages_svc, "DegB")
        links_svc.link_pages(a.id, b.id, LinkType.EXTENDS)
        central = graph_svc.find_central(limit=10)
        assert all("link_degree" in c for c in central)

    def test_degree_sorted_descending(self, pages_svc, links_svc, graph_svc):
        hub = _make(pages_svc, "SortHub")
        mid = _make(pages_svc, "SortMid")
        leaf = _make(pages_svc, "SortLeaf")
        # hub: 2 links, mid: 2 links (hub→mid + mid→leaf), leaf: 1 link
        links_svc.link_pages(hub.id, mid.id, LinkType.RELATED)
        links_svc.link_pages(mid.id, leaf.id, LinkType.RELATED)
        links_svc.link_pages(hub.id, leaf.id, LinkType.REFERENCE)

        central = graph_svc.find_central(limit=10)
        degrees = [c["link_degree"] for c in central]
        assert degrees == sorted(degrees, reverse=True)

    def test_limit_respected(self, pages_svc, links_svc, graph_svc):
        pages = [_make(pages_svc, f"LimitPage {i}") for i in range(6)]
        for i in range(1, 6):
            links_svc.link_pages(pages[0].id, pages[i].id, LinkType.RELATED)
        result = graph_svc.find_central(limit=2)
        assert len(result) <= 2


# ── find_due_for_review ────────────────────────────────────────────────────────

class TestFindDueForReview:

    def test_overdue_page_appears(self, pages_svc, graph_svc, repo):
        p = _make(pages_svc, "Overdue", review_interval_days=1)
        # Backdate updated_at to 2 days ago so it's definitely overdue
        from locram.adapters.db import get_connection
        from datetime import datetime, timedelta, timezone
        backdated = (datetime.now(timezone.utc) - timedelta(days=2)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        with get_connection(repo.db_path) as conn:
            conn.execute(
                "UPDATE pages SET updated_at = ? WHERE id = ?",
                (backdated, p.id),
            )
        due = graph_svc.find_due_for_review()
        assert any(d["id"] == p.id for d in due)

    def test_fresh_page_not_due(self, pages_svc, graph_svc):
        _make(pages_svc, "Fresh", review_interval_days=30)
        due = graph_svc.find_due_for_review()
        # A page just created with 30-day interval shouldn't be due
        assert not any(d["title"] == "Fresh" for d in due)

    def test_result_sorted_ascending_by_next_review(self, pages_svc, graph_svc, repo):
        from locram.adapters.db import get_connection
        from datetime import datetime, timedelta, timezone

        pages_data = [
            ("ReviewA", 1, 10),  # backdated 10 days, 1-day interval → very overdue
            ("ReviewB", 1, 5),   # backdated 5 days, 1-day interval → overdue
        ]
        ids = []
        for title, interval, backdate_days in pages_data:
            p = _make(pages_svc, title, review_interval_days=interval)
            backdated = (datetime.now(timezone.utc) - timedelta(days=backdate_days)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            )
            with get_connection(repo.db_path) as conn:
                conn.execute(
                    "UPDATE pages SET updated_at = ? WHERE id = ?",
                    (backdated, p.id),
                )
            ids.append(p.id)

        due = graph_svc.find_due_for_review()
        due_ids = [d["id"] for d in due if d["id"] in set(ids)]
        # ReviewA (10 days overdue) must appear before ReviewB (5 days overdue)
        assert due_ids.index(ids[0]) < due_ids.index(ids[1])

    def test_next_review_at_field_present(self, pages_svc, graph_svc, repo):
        from locram.adapters.db import get_connection
        from datetime import datetime, timedelta, timezone

        p = _make(pages_svc, "FieldCheck", review_interval_days=1)
        backdated = (datetime.now(timezone.utc) - timedelta(days=2)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        with get_connection(repo.db_path) as conn:
            conn.execute(
                "UPDATE pages SET updated_at = ? WHERE id = ?",
                (backdated, p.id),
            )
        due = graph_svc.find_due_for_review()
        assert all("next_review_at" in d for d in due)

    def test_deleted_page_excluded(self, pages_svc, graph_svc, repo):
        from locram.adapters.db import get_connection
        from datetime import datetime, timedelta, timezone

        p = _make(pages_svc, "DeletedDue", review_interval_days=1)
        backdated = (datetime.now(timezone.utc) - timedelta(days=2)).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        with get_connection(repo.db_path) as conn:
            conn.execute(
                "UPDATE pages SET updated_at = ? WHERE id = ?",
                (backdated, p.id),
            )
        pages_svc.delete_page(p.id)
        due = graph_svc.find_due_for_review()
        assert not any(d["id"] == p.id for d in due)

    def test_limit_respected(self, pages_svc, graph_svc, repo):
        from locram.adapters.db import get_connection
        from datetime import datetime, timedelta, timezone

        for i in range(5):
            p = _make(pages_svc, f"LimitDue {i}", review_interval_days=1)
            backdated = (datetime.now(timezone.utc) - timedelta(days=2)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            )
            with get_connection(repo.db_path) as conn:
                conn.execute(
                    "UPDATE pages SET updated_at = ? WHERE id = ?",
                    (backdated, p.id),
                )
        result = graph_svc.find_due_for_review(limit=3)
        assert len(result) <= 3


# ── get_graph_summary ──────────────────────────────────────────────────────────

class TestGetGraphSummary:

    def test_empty_graph(self, graph_svc):
        summary = graph_svc.get_graph_summary()
        assert summary["page_count"] == 0
        assert summary["link_count"] == 0
        assert summary["type_distribution"] == {}
        assert summary["pages"] == []
        assert summary["links"] == []
        assert summary["truncated"] is False

    def test_counts_match_actual_data(self, pages_svc, links_svc, graph_svc):
        a = _make(pages_svc, "CountA")
        b = _make(pages_svc, "CountB", type=PageType.PERMANENT)
        links_svc.link_pages(a.id, b.id, LinkType.SUPPORTS)

        summary = graph_svc.get_graph_summary()
        assert summary["page_count"] == 2
        # supports + supported_by = 2 link rows
        assert summary["link_count"] == 2

    def test_type_distribution(self, pages_svc, graph_svc):
        _make(pages_svc, "F1", type=PageType.FLEETING)
        _make(pages_svc, "F2", type=PageType.FLEETING)
        _make(pages_svc, "P1", type=PageType.PERMANENT)

        dist = graph_svc.get_graph_summary()["type_distribution"]
        assert dist.get("fleeting") == 2
        assert dist.get("permanent") == 1

    def test_deleted_pages_excluded(self, pages_svc, graph_svc):
        a = _make(pages_svc, "KeepMe")
        b = _make(pages_svc, "DropMe")
        pages_svc.delete_page(b.id)

        summary = graph_svc.get_graph_summary()
        ids = {p["id"] for p in summary["pages"]}
        assert a.id in ids
        assert b.id not in ids

    def test_hard_limit_respected(self, pages_svc, graph_svc):
        for i in range(5):
            _make(pages_svc, f"HardLimit {i}")
        summary = graph_svc.get_graph_summary(limit=3)
        assert summary["page_count"] <= 3
        assert summary["truncated"] is True

    def test_hard_limit_capped_at_500(self, graph_svc):
        # Even if caller passes 9999, internal cap is 500
        summary = graph_svc.get_graph_summary(limit=9999)
        # Can't easily add 500 pages, but verify truncated=False on empty graph
        assert summary["truncated"] is False

    def test_pages_and_links_included_in_response(self, pages_svc, links_svc, graph_svc):
        a = _make(pages_svc, "NodeA")
        b = _make(pages_svc, "NodeB")
        links_svc.link_pages(a.id, b.id, LinkType.RELATED)

        summary = graph_svc.get_graph_summary()
        page_ids = {p["id"] for p in summary["pages"]}
        assert a.id in page_ids
        assert b.id in page_ids

        link_pairs = {(lk["source_id"], lk["target_id"]) for lk in summary["links"]}
        assert (a.id, b.id) in link_pairs or (b.id, a.id) in link_pairs
