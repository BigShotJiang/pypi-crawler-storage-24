"""Vault write-through, sync, ID index, deletion detection."""
import hashlib
from pathlib import Path

import frontmatter
import pytest


def test_create_writes_md(pages_svc, vault, tmp_home):
    page = pages_svc.create_page("My Note", content="Hello world")
    vault_files = list((tmp_home / "vault").glob("*.md"))
    assert any("my-note" in f.name for f in vault_files)


def test_frontmatter_fields(pages_svc, vault, tmp_home):
    page = pages_svc.create_page("Frontmatter Test", type="permanent", subject=["ai"], tags=["test"])
    md_file = (tmp_home / "vault" / "frontmatter-test.md")
    assert md_file.exists()
    post = frontmatter.load(str(md_file))
    assert post["type"] == "permanent"
    assert post["id"] == page.id
    assert "ai" in post["subject"]
    assert "test" in post["tags"]


def test_id_index_o1_lookup(pages_svc, vault):
    page = pages_svc.create_page("Indexed Note")
    assert page.id in vault._id_index


def test_sync_detects_vault_edit(pages_svc, vault, repo, tmp_home):
    page = pages_svc.create_page("Editable", content="Original")
    md_path = vault._id_index[page.id]

    # Human edits the file
    post = frontmatter.load(str(md_path))
    post.content = "Edited content"
    md_path.write_text(frontmatter.dumps(post), encoding="utf-8")

    stats = vault.sync()
    assert stats["updated"] >= 1

    refreshed = repo.get(page.id)
    assert refreshed.content == "Edited content"


def test_sync_new_file_without_id(vault, repo, tmp_home):
    new_file = tmp_home / "vault" / "new-human-note.md"
    new_file.write_text(
        "---\ntype: fleeting\nstatus: active\nsubject: []\ntags: []\nreview in: 7\n---\nContent here.\n",
        encoding="utf-8",
    )
    stats = vault.sync()
    assert stats["inserted"] >= 1
    assert stats["deleted"] == 0, "New file without id must not be marked deleted"

    post = frontmatter.load(str(new_file))
    assert post.get("id")  # ULID assigned

    page = repo.get(post["id"])
    assert page is not None
    assert page.title == "new-human-note"
    assert page.status.value == "active", "Newly inserted page must remain active after sync"


def test_sync_loop_prevention(pages_svc, vault, repo):
    """After write-through, full sync must be a no-op (no spurious updates)."""
    page = pages_svc.create_page("Loop Test", content="Stable content")
    stats = vault.sync()
    assert stats["updated"] == 0
    assert stats["inserted"] == 0


def test_deletion_detection(pages_svc, vault, repo, tmp_home):
    page = pages_svc.create_page("To Delete")
    md_path = vault._id_index[page.id]
    md_path.unlink()

    stats = vault.sync()
    assert stats["deleted"] >= 1

    refreshed = repo.get(page.id)
    assert refreshed.status.value == "to_delete"


def test_title_rename_updates_file(pages_svc, vault, tmp_home):
    page = pages_svc.create_page("Old Title")
    old_path = vault._id_index[page.id]
    assert old_path.exists()

    pages_svc.update_page(page.id, title="New Title")
    new_path = vault._id_index[page.id]
    assert "new-title" in new_path.name
    assert not old_path.exists()


def test_filename_collision_uses_suffix(pages_svc, vault, tmp_home):
    p1 = pages_svc.create_page("Same Title")
    p2 = pages_svc.create_page("Same Title")
    path1 = vault._id_index[p1.id]
    path2 = vault._id_index[p2.id]
    assert path1 != path2
    assert path2.stem.startswith("same-title")
