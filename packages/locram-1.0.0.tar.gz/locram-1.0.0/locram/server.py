"""MCP server — composition root.

Wires: SqlitePageRepository + ObsidianVaultStore + SqliteEmbeddingStore
→ PageService, LinkService, SearchService, GraphService
→ MCP tools
"""
from mcp.server.fastmcp import FastMCP

from locram.adapters.db import init_db
from locram.adapters.sqlite_embedding_store import SqliteEmbeddingStore
from locram.adapters.sqlite_page_repo import SqlitePageRepository
from locram.services.graph_service import GraphService
from locram.services.link_service import LinkService
from locram.services.page_service import PageService
from locram.services.search_service import SearchService
from locram.vault.writer import ObsidianVaultStore

# ── Bootstrap ──────────────────────────────────────────────────────────────────

init_db()

_repo    = SqlitePageRepository()
_vault   = ObsidianVaultStore()
_embed   = SqliteEmbeddingStore()
_pages   = PageService(_repo, _vault)
_links   = LinkService(_repo, _vault)
_search  = SearchService(_repo)
_graph   = GraphService(_repo)

_vault.setup_obsidian()

# ── MCP App ────────────────────────────────────────────────────────────────────

mcp = FastMCP(
    "locram",
    instructions="""locram is a local Zettelkasten knowledge base (SQLite + Obsidian vault).

## Note types
- fleeting   : quick raw capture (default)
- note-taking: structured note, being refined
- permanent  : finished atomic idea — ONE idea per note
- structure  : Map of Content — organises a topic via links (not maturity)
- hub        : domain entry point — links to structure notes (not maturity)

## Link types (12, directional with auto-inverse)
- related         → symmetric
- extends / extended_by
- supports / supported_by
- contradicts / contradicted_by
- refines / refined_by
- questions / questioned_by
- reference       → unidirectional (no inverse)

## Graph navigation
When get_page returns connected_to or sub_items — call get_page on those IDs
to explore the knowledge graph.

## inline_mentions
[[wikilinks]] in note content are resolved at read time (derived, not stored).
""",
)

# ─────────────────────────────────────────────────────────────────────────────
# Core CRUD
# ─────────────────────────────────────────────────────────────────────────────

@mcp.tool()
def create_page(
    title: str,
    content: str = "",
    type: str = "fleeting",
    subject: list[str] | None = None,
    tags: list[str] | None = None,
    parent_id: str | None = None,
    review_interval_days: int = 7,
) -> dict:
    """Create a new note in the Zettelkasten."""
    page = _pages.create_page(
        title=title, content=content, type=type,
        subject=subject, tags=tags, parent_id=parent_id,
        review_interval_days=review_interval_days,
    )
    return _page_to_dict(page)


@mcp.tool()
def get_page(page_id: str) -> dict:
    """Get a note with full graph context (parent, sub_items, connected_to, inline_mentions)."""
    page = _pages.get_page(page_id)
    if page is None:
        return {"error": f"Page {page_id} not found"}
    return _page_to_dict(page)


@mcp.tool()
def update_page(page_id: str, **fields) -> dict:
    """Partially update a note. Only provided fields are changed.

    Updatable fields: title, content, type, status, subject, tags,
    parent_id, review_interval_days.
    """
    page = _pages.update_page(page_id, **fields)
    if page is None:
        return {"error": f"Page {page_id} not found"}
    return _page_to_dict(page)


@mcp.tool()
def delete_page(page_id: str, hard: bool = False) -> dict:
    """Delete a note. Default: soft delete (status=to_delete). hard=True: permanent."""
    ok = _pages.delete_page(page_id, hard=hard)
    return {"deleted": ok, "hard": hard}


@mcp.tool()
def list_pages(
    status: str | None = None,
    type: str | None = None,
    subject: str | None = None,
    tag: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    """List notes with optional filters."""
    return _pages.list_pages(
        status=status, type=type, subject=subject,
        tag=tag, limit=limit, offset=offset,
    )


@mcp.tool()
def search(query: str, limit: int = 20) -> list[dict]:
    """Full-text search (FTS5 BM25) across title and content."""
    return _search.search(query, limit=limit)


# ─────────────────────────────────────────────────────────────────────────────
# Partial editing
# ─────────────────────────────────────────────────────────────────────────────

@mcp.tool()
def replace_in_page(page_id: str, old_text: str, new_text: str) -> dict:
    """Find-and-replace exact text fragment in note content."""
    page = _repo.get(page_id)
    if page is None:
        return {"error": f"Page {page_id} not found"}
    if old_text not in page.content:
        return {"error": "Text not found in page content"}
    new_content = page.content.replace(old_text, new_text, 1)
    updated = _pages.update_page(page_id, content=new_content)
    return {"updated": True, "id": page_id}


@mcp.tool()
def update_section(page_id: str, heading: str, new_content: str) -> dict:
    """Replace a markdown section (identified by heading) with new content."""
    import re
    page = _repo.get(page_id)
    if page is None:
        return {"error": f"Page {page_id} not found"}

    pattern = rf"(#+\s*{re.escape(heading)}\s*\n)(.*?)(?=\n#+\s|\Z)"
    if not re.search(pattern, page.content, re.DOTALL):
        return {"error": f"Section '{heading}' not found"}

    new_body = re.sub(
        pattern,
        lambda m: m.group(1) + new_content + "\n",
        page.content,
        count=1,
        flags=re.DOTALL,
    )
    _pages.update_page(page_id, content=new_body)
    return {"updated": True, "id": page_id}


# ─────────────────────────────────────────────────────────────────────────────
# Links
# ─────────────────────────────────────────────────────────────────────────────

@mcp.tool()
def link_pages(
    source_id: str,
    target_id: str,
    link_type: str = "related",
) -> dict:
    """Create a typed directional link. Auto-creates inverse if applicable.

    link_type: related | extends | extended_by | supports | supported_by |
               contradicts | contradicted_by | refines | refined_by |
               questions | questioned_by | reference
    """
    return _links.link_pages(source_id, target_id, link_type)


@mcp.tool()
def unlink_pages(
    source_id: str,
    target_id: str,
    link_type: str | None = None,
) -> dict:
    """Remove link(s). link_type=None removes all links between the pair."""
    return _links.unlink_pages(source_id, target_id, link_type)


@mcp.tool()
def set_parent(child_id: str, parent_id: str | None) -> dict:
    """Set or clear the vertical parent of a note."""
    return _links.set_parent(child_id, parent_id)


@mcp.tool()
def batch_link(links: list[dict]) -> dict:
    """Create multiple typed links in one call.

    links: [{source_id, target_id, link_type}, ...]
    Returns: {created: int, skipped: int, errors: list[str]}
    """
    return _links.batch_link(links)


# ─────────────────────────────────────────────────────────────────────────────
# Graph analytics
# ─────────────────────────────────────────────────────────────────────────────

@mcp.tool()
def find_orphaned_notes(limit: int = 50) -> list[dict]:
    """Notes with zero links and no parent — candidates for connecting."""
    return _graph.find_orphaned(limit=limit)


@mcp.tool()
def find_central_notes(limit: int = 20) -> list[dict]:
    """Most-linked notes — hub ideas in the knowledge graph."""
    return _graph.find_central(limit=limit)


@mcp.tool()
def find_similar_notes(page_id: str, limit: int = 10) -> list[dict]:
    """Find similar notes by FTS5 BM25 similarity (Phase 2: + vector search)."""
    return _search.find_similar(page_id, limit=limit)


@mcp.tool()
def find_due_for_review(limit: int = 50) -> list[dict]:
    """Notes past their review date — for night agent maintenance."""
    return _graph.find_due_for_review(limit=limit)


@mcp.tool()
def get_graph_summary(limit: int = 500) -> dict:
    """Graph stats + topology: page count, type distribution, all pages and links.
    Hard limit: 500 pages. Set limit lower for faster response."""
    return _graph.get_graph_summary(limit=limit)


# ─────────────────────────────────────────────────────────────────────────────
# Lifecycle & batch
# ─────────────────────────────────────────────────────────────────────────────

@mcp.tool()
def promote_page(page_id: str) -> dict:
    """Promote note maturity: fleeting → note-taking → permanent.
    Cannot promote structure/hub (classification types — use update_page instead).
    Cannot demote."""
    return _pages.promote_page(page_id)


# ─────────────────────────────────────────────────────────────────────────────
# Attachments
# ─────────────────────────────────────────────────────────────────────────────

@mcp.tool()
def get_attachment(filename: str) -> dict:
    """Read a file from vault/attachments/ and return base64-encoded content."""
    from locram.vault.attachments import get_attachment as _get
    data = _get(filename)
    if data is None:
        return {"error": f"Attachment '{filename}' not found"}
    return {"filename": filename, "data_b64": data}


@mcp.tool()
def save_attachment(filename: str, data_b64: str) -> dict:
    """Save a base64-encoded file to vault/attachments/."""
    from locram.vault.attachments import save_attachment as _save
    path = _save(filename, data_b64)
    return {"saved": True, "path": str(path)}


# ─────────────────────────────────────────────────────────────────────────────
# Embeddings (Phase 1: storage only; Phase 2: semantic_search)
# ─────────────────────────────────────────────────────────────────────────────

@mcp.tool()
def store_embedding(
    page_id: str,
    embedding: list[float],
    model: str,
    field: str = "content",
) -> dict:
    """Store an embedding vector for a page field.

    field: 'content' | 'meta' | 'summary'
    One active model per field (UPSERT — replaces previous vector).
    """
    import struct
    raw = struct.pack(f"{len(embedding)}f", *embedding)
    _embed.store(page_id, field, raw, model, len(embedding))
    return {"stored": True, "page_id": page_id, "field": field, "dimension": len(embedding)}


@mcp.tool()
def find_unembedded(limit: int = 100) -> list[str]:
    """List page IDs without a 'content' embedding — queue for nocrun agents."""
    return _embed.find_unembedded(limit=limit)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _page_to_dict(page) -> dict:
    return {
        "id":                   page.id,
        "title":                page.title,
        "content":              page.content,
        "type":                 page.type.value,
        "status":               page.status.value,
        "subject":              page.subject,
        "tags":                 page.tags,
        "parent_id":            page.parent_id,
        "content_hash":         page.content_hash,
        "review_interval_days": page.review_interval_days,
        "created_at":           page.created_at,
        "updated_at":           page.updated_at,
        "parent":               page.parent,
        "sub_items":            page.sub_items,
        "connected_to":         page.connected_to,
        "inline_mentions":      page.inline_mentions,
        "next_review_at":       page.next_review_at,
    }


def main():
    mcp.run()


if __name__ == "__main__":
    main()
