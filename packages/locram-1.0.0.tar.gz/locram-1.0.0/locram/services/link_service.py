from locram.interfaces.page_repository import PageRepository
from locram.interfaces.vault_store import VaultStore
from locram.models import LinkType, LINK_INVERSES


class LinkService:

    def __init__(self, repo: PageRepository, vault: VaultStore):
        self._repo = repo
        self._vault = vault

    def link_pages(
        self,
        source_id: str,
        target_id: str,
        link_type: str = "related",
    ) -> dict:
        lt = LinkType(link_type)
        self._repo.create_link(source_id, target_id, lt)

        inverse = LINK_INVERSES.get(lt)
        if inverse is not None and inverse != lt:
            self._repo.create_link(target_id, source_id, inverse)
        elif lt == LinkType.RELATED:
            # symmetric: create both directions
            self._repo.create_link(target_id, source_id, lt)

        self._refresh_vault(source_id)
        self._refresh_vault(target_id)
        return {"source_id": source_id, "target_id": target_id, "link_type": link_type}

    def unlink_pages(
        self,
        source_id: str,
        target_id: str,
        link_type: str | None = None,
    ) -> dict:
        lt = LinkType(link_type) if link_type else None
        self._repo.delete_link(source_id, target_id, lt)

        if lt is not None:
            inverse = LINK_INVERSES.get(lt)
            if inverse is not None:
                self._repo.delete_link(target_id, source_id, inverse)
        else:
            # Remove all directions
            self._repo.delete_link(target_id, source_id, None)

        self._refresh_vault(source_id)
        self._refresh_vault(target_id)
        return {"unlinked": True}

    def set_parent(self, child_id: str, parent_id: str | None) -> dict:
        self._repo.set_parent(child_id, parent_id)
        self._refresh_vault(child_id)
        if parent_id:
            self._refresh_vault(parent_id)
        return {"child_id": child_id, "parent_id": parent_id}

    def batch_link(
        self, links: list[dict]
    ) -> dict:
        """links: [{source_id, target_id, link_type}]
        Returns: {created: int, skipped: int, errors: list[str]}
        skipped counts items where the primary link already existed (INSERT OR IGNORE).
        """
        created, skipped, errors = 0, 0, []
        affected_ids: set[str] = set()
        for item in links:
            try:
                lt = LinkType(item["link_type"])
                inserted = self._repo.create_link(item["source_id"], item["target_id"], lt)
                if not inserted:
                    skipped += 1
                    continue
                created += 1
                affected_ids.add(item["source_id"])
                affected_ids.add(item["target_id"])
                inverse = LINK_INVERSES.get(lt)
                if inverse is not None and inverse != lt:
                    self._repo.create_link(item["target_id"], item["source_id"], inverse)
                elif lt == LinkType.RELATED:
                    self._repo.create_link(item["target_id"], item["source_id"], lt)
            except Exception as e:
                errors.append(f"{item}: {e}")
        for page_id in affected_ids:
            self._refresh_vault(page_id)
        return {"created": created, "skipped": skipped, "errors": errors}

    def _refresh_vault(self, page_id: str) -> None:
        from locram.services.page_service import PageService
        # Minimal: just re-write the .md with updated link context
        page = self._repo.get(page_id)
        if page:
            from locram.vault.reader import extract_wikilinks
            links = self._repo.get_links(page_id)
            connected_to = []
            for link in links:
                if link.source_id == page_id:
                    other = self._repo.get(link.target_id)
                    if other:
                        connected_to.append({
                            "id": other.id,
                            "title": other.title,
                            "link_type": link.link_type.value,
                            "direction": "outgoing",
                        })
                else:
                    other = self._repo.get(link.source_id)
                    if other:
                        connected_to.append({
                            "id": other.id,
                            "title": other.title,
                            "link_type": link.link_type.value,
                            "direction": "incoming",
                        })
            page.connected_to = connected_to
            if page.parent_id:
                parent = self._repo.get(page.parent_id)
                page.parent = {"id": parent.id, "title": parent.title} if parent else None
            self._vault.write(page)
