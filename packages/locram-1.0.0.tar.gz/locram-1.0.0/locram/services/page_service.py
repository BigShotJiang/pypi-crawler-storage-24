import re
from pathlib import Path

from ulid import ULID

from locram.interfaces.page_repository import PageRepository
from locram.interfaces.vault_store import VaultStore
from locram.models import Page, PageStatus, PageType
from locram.vault.reader import extract_wikilinks


class PageService:

    def __init__(self, repo: PageRepository, vault: VaultStore):
        self._repo = repo
        self._vault = vault

    def create_page(
        self,
        title: str,
        content: str = "",
        type: str = "fleeting",
        status: str = "active",
        subject: list[str] | None = None,
        tags: list[str] | None = None,
        parent_id: str | None = None,
        review_interval_days: int = 7,
    ) -> Page:
        page = Page(
            id=str(ULID()),
            title=title,
            content=content,
            type=PageType(type),
            status=PageStatus(status),
            subject=subject or [],
            tags=tags or [],
            parent_id=parent_id,
            review_interval_days=review_interval_days,
        )
        page = self._repo.create(page)
        page = self._enrich(page)
        self._vault.write(page)
        return page

    def get_page(self, page_id: str) -> Page | None:
        page = self._repo.get(page_id)
        if page is None:
            return None
        return self._enrich(page)

    def update_page(self, page_id: str, **fields) -> Page | None:
        page = self._repo.update(page_id, **fields)
        if page is None:
            return None
        page = self._enrich(page)
        self._vault.write(page)
        return page

    def delete_page(self, page_id: str, hard: bool = False) -> bool:
        ok = self._repo.delete(page_id, hard=hard)
        if ok and hard:
            self._vault.remove(page_id)
        elif ok:
            # Soft delete: update .md status field (re-write the file)
            page = self._repo.get(page_id)
            if page:
                page = self._enrich(page)
                self._vault.write(page)
        return ok

    def list_pages(self, **filters) -> list[dict]:
        return self._repo.list_pages(**filters)

    def promote_page(self, page_id: str) -> dict:
        """Maturity promotion: fleeting → note-taking → permanent.
        structure/hub are classification types — use update_page instead.
        Cannot demote."""
        from locram.models import MATURITY_ORDER
        page = self._repo.get(page_id)
        if page is None:
            return {"error": f"Page {page_id} not found"}
        if page.type not in MATURITY_ORDER:
            return {
                "error": (
                    f"Cannot promote: type '{page.type.value}' is a classification type "
                    f"(structure/hub). Use update_page(type=...) to change classification."
                )
            }
        current_index = MATURITY_ORDER.index(page.type)
        if current_index >= len(MATURITY_ORDER) - 1:
            return {"error": f"Already at maximum maturity: '{page.type.value}'"}
        next_type = MATURITY_ORDER[current_index + 1]
        self.update_page(page_id, type=next_type.value)
        return {
            "id": page_id,
            "previous_type": page.type.value,
            "new_type": next_type.value,
        }

    def _enrich(self, page: Page) -> Page:
        """Populate transient graph context fields."""
        links = self._repo.get_links(page.id)

        # connected_to: all peer links with direction
        connected_to = []
        for link in links:
            if link.source_id == page.id:
                other = self._repo.get(link.target_id)
                if other:
                    connected_to.append({
                        "id": other.id,
                        "title": other.title,
                        "link_type": link.link_type.value,
                        "direction": "outgoing",
                    })
            else:
                other = self._repo.get(link.source_id)
                if other:
                    connected_to.append({
                        "id": other.id,
                        "title": other.title,
                        "link_type": link.link_type.value,
                        "direction": "incoming",
                    })
        page.connected_to = connected_to

        # parent
        if page.parent_id:
            parent = self._repo.get(page.parent_id)
            page.parent = {"id": parent.id, "title": parent.title} if parent else None

        # sub_items (children)
        children = self._repo.list_pages(status=None, limit=200, offset=0)
        page.sub_items = [
            {"id": c["id"], "title": c["title"]}
            for c in children
            if c.get("parent_id") == page.id  # type: ignore[comparison-overlap]
        ]

        # inline_mentions: derived from [[wikilinks]] in content
        titles = extract_wikilinks(page.content)
        mentions = []
        for title in titles:
            # Search by title in DB (best-effort)
            results = self._repo.search_fts(f'title:{title}', limit=3)
            for r in results:
                if r["title"] == title:
                    mentions.append({"id": r["id"], "title": r["title"]})
                    break
        page.inline_mentions = mentions

        # next_review_at
        if page.updated_at:
            from datetime import datetime, timedelta, timezone
            try:
                updated = datetime.fromisoformat(page.updated_at.replace("Z", "+00:00"))
                page.next_review_at = (
                    updated + timedelta(days=page.review_interval_days)
                ).strftime("%Y-%m-%dT%H:%M:%SZ")
            except ValueError:
                pass

        return page
