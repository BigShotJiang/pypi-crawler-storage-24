"""Vault → DB synchronisation.

Two modes:
- Full-vault sync (file_path=None): scans all .md files, detects deletions.
  Used by launchd debounced watcher.
- Single-file sync (file_path=Path): faster, no deletion detection.
  For manual/scripted use.

Conflict model: last-write-wins, guarded by full writable-state comparison.
Sync compares content_hash + title + type + status + subject + tags + review_interval_days.
If all match → skip (no-op). This prevents sync-loops after DB→vault write-through.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import TYPE_CHECKING

from ulid import ULID

from locram.config import VAULT_EXCLUDED_DIRS, VAULT_PATH
from locram.models import Page, PageStatus, PageType
from locram.vault.reader import parse_md

if TYPE_CHECKING:
    from locram.vault.writer import ObsidianVaultStore


def _content_hash(content: str) -> str:
    return hashlib.md5(content.encode()).hexdigest()


def _vault_files(vault: Path = VAULT_PATH):
    for f in vault.iterdir():
        if f.is_file() and f.suffix == ".md":
            yield f


def _safe_type(val) -> str:
    try:
        return PageType(str(val)).value
    except ValueError:
        return PageType.FLEETING.value


def _safe_status(val) -> str:
    try:
        return PageStatus(str(val)).value
    except ValueError:
        return PageStatus.ACTIVE.value


def _state_matches(meta: dict, db_row: dict) -> bool:
    """True if all vault-writable fields are identical between file and DB."""
    from locram.vault.writer import slugify

    file_content = meta.get("_content", "")
    if _content_hash(file_content) != (db_row.get("content_hash") or ""):
        return False
    # Compare slugified file stem vs slugified DB title to handle filename = slugify(title)
    if meta.get("_path"):
        file_stem = Path(meta["_path"]).stem
        db_title = db_row.get("title") or ""
        # File stem may have numeric suffix on collision; strip it for comparison
        # The definitive check: does slugify(db_title) match the start of file_stem?
        if file_stem != slugify(db_title) and not file_stem.startswith(slugify(db_title) + "-"):
            return False
    if _safe_type(meta.get("type")) != db_row.get("type"):
        return False
    if _safe_status(meta.get("status")) != db_row.get("status"):
        return False
    if json.dumps(meta.get("subject") or []) != (db_row.get("subject") or "[]"):
        return False
    if json.dumps(meta.get("tags") or []) != (db_row.get("tags") or "[]"):
        return False
    if int(meta.get("review in") or 7) != int(db_row.get("review_interval_days") or 7):
        return False
    return True


def _sync_file(meta: dict, repo) -> str:
    """Sync a single parsed .md file into DB. Returns 'inserted'|'updated'|'skipped'."""
    from locram.adapters.db import get_connection

    page_id = str(meta.get("id", "")).strip()
    content = meta.get("_content", "")
    path: Path = meta["_path"]
    title = path.stem

    # New file created by human (no id in frontmatter)
    if not page_id:
        page_id = str(ULID())
        import frontmatter as fm
        post = fm.load(str(path))
        post["id"] = page_id
        path.write_text(fm.dumps(post), encoding="utf-8")

    # Read current DB state
    with get_connection(repo.db_path) as conn:
        row = conn.execute("SELECT * FROM pages WHERE id = ?", (page_id,)).fetchone()

    if row is None:
        # Insert: new page from Obsidian
        page = Page(
            id=page_id,
            title=title,
            content=content,
            type=PageType(_safe_type(meta.get("type"))),
            status=PageStatus(_safe_status(meta.get("status"))),
            subject=meta.get("subject") or [],
            tags=meta.get("tags") or [],
            review_interval_days=int(meta.get("review in") or 7),
        )
        repo.create(page)
        return "inserted"

    db_row = dict(row)
    db_row["_path"] = path
    if _state_matches(meta, db_row):
        return "skipped"

    # Update changed fields
    updates: dict = {}
    if _content_hash(content) != (db_row.get("content_hash") or ""):
        updates["content"] = content
    if title != db_row.get("title"):
        updates["title"] = title
    if _safe_type(meta.get("type")) != db_row.get("type"):
        updates["type"] = _safe_type(meta.get("type"))
    if _safe_status(meta.get("status")) != db_row.get("status"):
        updates["status"] = _safe_status(meta.get("status"))

    file_subject = json.dumps(meta.get("subject") or [])
    if file_subject != (db_row.get("subject") or "[]"):
        updates["subject"] = meta.get("subject") or []

    file_tags = json.dumps(meta.get("tags") or [])
    if file_tags != (db_row.get("tags") or "[]"):
        updates["tags"] = meta.get("tags") or []

    file_ri = int(meta.get("review in") or 7)
    if file_ri != int(db_row.get("review_interval_days") or 7):
        updates["review_interval_days"] = file_ri

    if updates:
        repo.update(page_id, **updates)

    return "updated"


def run_sync(vault_store: "ObsidianVaultStore", file_path: Path | None = None) -> dict:
    """Run sync. Returns stats dict {inserted, updated, skipped, deleted, errors}."""
    from locram.adapters.sqlite_page_repo import SqlitePageRepository

    repo = SqlitePageRepository(vault_store.db_path)
    stats = {"inserted": 0, "updated": 0, "skipped": 0, "deleted": 0, "errors": []}

    if file_path is not None:
        # Single-file mode
        meta = parse_md(file_path)
        if meta:
            result = _sync_file(meta, repo)
            stats[result] += 1
        return stats

    # Full-vault mode
    found_ids: set[str] = set()
    for f in _vault_files(vault_store.vault_path):
        meta = parse_md(f)
        if not meta:
            continue
        pid = str(meta.get("id", "")).strip()
        if pid:
            found_ids.add(pid)
        try:
            result = _sync_file(meta, repo)
            stats[result] += 1
            # If file had no id, _sync_file assigned a ULID and rewrote the file.
            # Re-read the id so deletion detection does not mark it to_delete.
            if not pid:
                refreshed = parse_md(f)
                if refreshed:
                    new_pid = str(refreshed.get("id", "")).strip()
                    if new_pid:
                        found_ids.add(new_pid)
        except Exception as e:
            stats["errors"].append(f"{f.name}: {e}")

    # Deletion detection: active pages not found in vault → mark to_delete
    from locram.adapters.db import get_connection
    with get_connection(repo.db_path) as conn:
        rows = conn.execute(
            "SELECT id FROM pages WHERE status = 'active'"
        ).fetchall()
        active_ids = {r["id"] for r in rows}

    for missing_id in active_ids - found_ids:
        repo.update(missing_id, status="to_delete")
        stats["deleted"] += 1

    vault_store._rebuild_index()
    return stats
