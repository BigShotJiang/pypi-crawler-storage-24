"""macOS launchd watcher installer.

launchd WatchPaths fires when the vault directory changes.
It triggers `locram sync` (full-vault reconcile with debounce).
Note: WatchPaths gives directory-level notifications only — no per-file events.
"""
import os
import subprocess
from pathlib import Path

from locram.config import LOCRAM_HOME, VAULT_PATH

_PLIST_LABEL = "com.locram.vault-watcher"
_PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / f"{_PLIST_LABEL}.plist"


def _locram_bin() -> str:
    import shutil
    bin_path = shutil.which("locram")
    return bin_path or "locram"


def _plist_content() -> str:
    bin_path = _locram_bin()
    log_err = str(LOCRAM_HOME / "watcher.err")
    log_out = str(LOCRAM_HOME / "watcher.log")
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{_PLIST_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{bin_path}</string>
        <string>sync</string>
    </array>
    <key>WatchPaths</key>
    <array>
        <string>{VAULT_PATH}</string>
    </array>
    <key>ThrottleInterval</key>
    <integer>5</integer>
    <key>StandardErrorPath</key>
    <string>{log_err}</string>
    <key>StandardOutPath</key>
    <string>{log_out}</string>
    <key>RunAtLoad</key>
    <false/>
</dict>
</plist>
"""


def install_watcher() -> str:
    _PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    _PLIST_PATH.write_text(_plist_content(), encoding="utf-8")
    subprocess.run(["launchctl", "load", str(_PLIST_PATH)], check=True)
    return str(_PLIST_PATH)


def uninstall_watcher() -> None:
    if _PLIST_PATH.exists():
        subprocess.run(["launchctl", "unload", str(_PLIST_PATH)], check=False)
        _PLIST_PATH.unlink()
