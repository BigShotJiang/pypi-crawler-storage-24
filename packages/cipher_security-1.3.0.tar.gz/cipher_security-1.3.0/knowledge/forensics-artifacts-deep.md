# Digital Forensics Artifacts — Deep Dive Reference

CIPHER Training Module | Last Updated: 2026-03-14

---

## Table of Contents

1. [Windows Artifacts](#1-windows-artifacts)
2. [Linux Artifacts](#2-linux-artifacts)
3. [macOS Artifacts](#3-macos-artifacts)
4. [Browser Artifacts](#4-browser-artifacts)
5. [Memory Forensics with Volatility3](#5-memory-forensics-with-volatility3)
6. [Timeline Generation & Analysis](#6-timeline-generation--analysis)
7. [Event Log Analysis Tools](#7-event-log-analysis-tools)
8. [Forensic Toolchain Reference](#8-forensic-toolchain-reference)

---

## 1. Windows Artifacts

### 1.1 Registry Hives

**Hive Locations:**

| Hive | Path | Forensic Value |
|------|------|----------------|
| SAM | `C:\Windows\System32\config\SAM` | Local user accounts, RIDs, SIDs, group memberships, last login times, password policy |
| SECURITY | `C:\Windows\System32\config\SECURITY` | LSA secrets, cached credentials, audit policies |
| SYSTEM | `C:\Windows\System32\config\SYSTEM` | Services, drivers, hostname, timezone, shutdown time, USB device history |
| SOFTWARE | `C:\Windows\System32\config\SOFTWARE` | Installed software, OS version, network configs, app settings |
| DEFAULT | `C:\Windows\System32\config\DEFAULT` | Default user profile template |
| NTUSER.DAT | `C:\Users\<user>\NTUSER.DAT` | Per-user settings, recent files, typed URLs, search history, Run keys |
| UsrClass.dat | `C:\Users\<user>\AppData\Local\Microsoft\Windows\UsrClass.dat` | ShellBags, COM class registrations, file type associations |

**High-Value Registry Keys:**

```
# User Activity
NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs
NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\TypedPaths
NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\WordWheelQuery
NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU
NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\OpenSavePidlMRU
NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist

# Persistence
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
NTUSER\Software\Microsoft\Windows\CurrentVersion\Run
NTUSER\Software\Microsoft\Windows\CurrentVersion\RunOnce
HKLM\SYSTEM\CurrentControlSet\Services
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options

# Network
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles
NTUSER\Software\Microsoft\Terminal Server Client\Servers    # RDP history

# USB Devices
HKLM\SYSTEM\CurrentControlSet\Enum\USBSTOR
HKLM\SYSTEM\CurrentControlSet\Enum\USB
HKLM\SYSTEM\MountedDevices
NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\MountPoints2

# User Accounts
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList
```

**Registry Parsing Tools:**
- `python-registry` — cross-platform read-only registry parsing (supports NTUSER.DAT, SAM, userdiff)
- `RegRipper` — automated registry key extraction with pre-built plugins
- `Registry Explorer` (Eric Zimmerman) — GUI-based registry browsing

---

### 1.2 ShellBags

**Purpose:** Track folder access history, including folders on removable media, network shares, and deleted folders — evidence persists even after the folder is deleted.

**Locations:**
```
NTUSER.DAT\Software\Microsoft\Windows\Shell\BagMRU
NTUSER.DAT\Software\Microsoft\Windows\Shell\Bags
UsrClass.dat\Local Settings\Software\Microsoft\Windows\Shell\BagMRU
UsrClass.dat\Local Settings\Software\Microsoft\Windows\Shell\Bags
```

**Forensic Value:**
- Folder path, access timestamps, view preferences
- Evidence of folder browsing on removable media
- Proof of access to network shares
- Persists after folder/drive removal

**Tools:** ShellBags Explorer (Eric Zimmerman), `sbecmd.exe`

---

### 1.3 ShimCache (Application Compatibility Cache)

**Purpose:** Tracks executables that Windows checked for compatibility. Records file path, size, last modified time, and (on some OS versions) execution flag.

**Location:**
```
HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\AppCompatCache\AppCompatCache
```

**Forensic Value:**
- Evidence of file existence on disk (even if deleted)
- Last modification timestamp of the executable
- File size at time of shimcache entry
- Execution flag (Windows XP/2003 — later versions only indicate the file was checked, not necessarily executed)
- Entries are written on shutdown — LIFO order (most recent at top)

**Tools:** `AppCompatCacheParser.exe` (Eric Zimmerman), Chainsaw shimcache analysis

---

### 1.4 AmCache

**Purpose:** Tracks application execution and installation with SHA1 hashes. More reliable execution evidence than ShimCache on modern Windows.

**Location:**
```
C:\Windows\AppCompat\Programs\Amcache.hve
```

**Key Registry Paths within Amcache.hve:**
```
Root\InventoryApplicationFile     # Executed files with hashes
Root\InventoryApplication         # Installed applications
Root\InventoryDriverBinary        # Driver information
Root\File\{volume_guid}\          # Legacy format (pre-Win10 1709)
```

**Forensic Value:**
- SHA1 hash of executed file (critical for IOC matching)
- Full file path, file size, link date (PE compilation timestamp)
- First execution time (key last write time)
- Publisher and version information
- Associated program installation data

**Tools:** `AmcacheParser.exe` (Eric Zimmerman), Registry Explorer

---

### 1.5 Prefetch

**Purpose:** Windows caches application loading data to speed subsequent launches. Provides evidence of execution with timestamps and loaded dependencies.

**Location:**
```
C:\Windows\Prefetch\<executable>-<hash>.pf
```

**Forensic Value:**
- Executable name and path
- Last 8 execution timestamps (Win8+), 1 timestamp (WinXP/7)
- Run count (total number of executions)
- Files and directories referenced during first 10 seconds of execution
- Volume information (serial number, creation date)
- Creation time = first execution; Modification time = last execution

**Constraints:**
- Disabled by default on SSDs in some Windows versions
- Maximum 1024 entries (Win10+), 128 entries (WinXP-Win7)
- Requires `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters\EnablePrefetcher` = 1 or 3

**Tools:** `PECmd.exe` (Eric Zimmerman), WinPrefetchView (NirSoft)

---

### 1.6 SRUM (System Resource Usage Monitor)

**Purpose:** Records application resource usage every 60 minutes — network bytes, CPU time, and application identity.

**Location:**
```
C:\Windows\System32\SRU\SRUDB.dat          # ESE database
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SRUM\Extensions  # Table definitions
```

**Forensic Value:**
- Application resource usage with SID (identifies which user ran it)
- Network data bytes sent/received per application
- CPU cycles consumed, foreground/background cycle time
- Network connectivity profiles and interface information
- 30-60 days of data retained by default
- Survives application deletion — records persist

**Key Tables:**
| Table GUID | Data |
|------------|------|
| `{D10CA2FE-...}` | Application Resource Usage |
| `{DD6636C4-...}` | Network Data Usage |
| `{973F5D5C-...}` | Network Connectivity Usage |
| `{FEE4E14F-...}` | Energy Usage |

**Tools:** `SrumECmd.exe` (Eric Zimmerman), Chainsaw SRUM analysis, `srum-dump`

---

### 1.7 $MFT (Master File Table)

**Purpose:** NTFS metadata store — every file and directory on the volume has an MFT entry containing timestamps, attributes, and (for small files) resident data.

**Location:**
```
<volume>\$MFT           # Root of each NTFS volume
```

**Key MFT Attributes:**
| Attribute | ID | Content |
|-----------|----|---------|
| $STANDARD_INFORMATION | 0x10 | Created, Modified, Accessed, Entry Modified (MACE) timestamps — user-modifiable via API |
| $FILE_NAME | 0x30 | MACE timestamps — updated by OS only (harder to tamper) |
| $DATA | 0x80 | File content (resident if < ~700 bytes) |
| $ATTRIBUTE_LIST | 0x20 | Extension for entries with many attributes |
| $INDEX_ROOT / $INDEX_ALLOCATION | 0x90/0xA0 | Directory listings |

**Forensic Value:**
- Complete filesystem metadata for every file ever allocated
- Timestomping detection: compare $STANDARD_INFORMATION vs $FILE_NAME timestamps
- Deleted file metadata recovery (MFT entry may persist after deletion)
- Resident data recovery for small files
- Alternate Data Stream (ADS) enumeration (Zone.Identifier, etc.)
- File size discrepancies between logical and physical allocation

**Tools:** `MFTEcmd.exe` (Eric Zimmerman), Sleuth Kit (`istat`, `icat`, `ils`), `analyzeMFT`, Autopsy

---

### 1.8 USN Journal ($UsnJrnl)

**Purpose:** NTFS change journal recording all filesystem modifications — creates, deletes, renames, data changes, security changes.

**Location:**
```
<volume>\$Extend\$UsnJrnl:$J       # Journal data stream
<volume>\$Extend\$UsnJrnl:$MAX     # Configuration (max size, allocation delta)
```

**USN Reason Flags:**
| Flag | Meaning |
|------|---------|
| `USN_REASON_FILE_CREATE` | New file created |
| `USN_REASON_FILE_DELETE` | File deleted |
| `USN_REASON_DATA_OVERWRITE` | File data modified |
| `USN_REASON_RENAME_NEW_NAME` | File renamed (new name) |
| `USN_REASON_RENAME_OLD_NAME` | File renamed (old name) |
| `USN_REASON_SECURITY_CHANGE` | ACL/permissions modified |
| `USN_REASON_BASIC_INFO_CHANGE` | Timestamps or attributes changed |
| `USN_REASON_CLOSE` | File handle closed (final entry) |

**Forensic Value:**
- Chronological record of all file system changes
- Deletion evidence even when $MFT entry is overwritten
- File rename tracking (old + new name pairs)
- Timestomping evidence (BASIC_INFO_CHANGE without DATA_OVERWRITE)
- Malware deployment and staging artifact
- Typical retention: days to weeks depending on volume activity

**Tools:** `MFTEcmd.exe` (processes both MFT and USN), `NTFS USN Journal parser`, fsutil (`fsutil usn readjournal`)

---

### 1.9 Event Logs

**Location:**
```
C:\Windows\System32\winevt\Logs\*.evtx
```

**Critical Security Event IDs:**

| Event ID | Log | Description | Key Fields |
|----------|-----|-------------|------------|
| **4624** | Security | Successful logon | Logon Type, Source IP, Account Name, SID |
| **4625** | Security | Failed logon | Failure reason, Source IP, Account Name |
| **4634/4647** | Security | Logoff | Logon ID correlation |
| **4648** | Security | Explicit credential logon (runas) | Target server, alternate credentials used |
| **4672** | Security | Special privileges assigned | Privileges list, admin indicator |
| **4688** | Security | Process creation | Process name, command line, parent PID, creator SID |
| **4689** | Security | Process exit | Process name, exit status |
| **4697** | Security | Service installed | Service name, binary path, account |
| **4698** | Security | Scheduled task created | Task name, XML content |
| **4720** | Security | User account created | New account name, creator SID |
| **4722-4726** | Security | Account management | Enable, disable, delete, password changes |
| **4728/4732/4756** | Security | Group membership changes | Member added to security group |
| **4768** | Security | Kerberos TGT requested | Account, source IP, encryption type |
| **4769** | Security | Kerberos service ticket | Service name, encryption type (0x17 = RC4 = suspect) |
| **4776** | Security | NTLM authentication | Source workstation, status |
| **5140** | Security | Network share accessed | Share name, source IP |
| **5145** | Security | Detailed share access | Object path, access mask |
| **5156** | Security | Network connection permitted (WFP) | Source/dest IP:port, PID |

**System Event IDs:**

| Event ID | Log | Description |
|----------|-----|-------------|
| **7034** | System | Service crashed unexpectedly |
| **7036** | System | Service entered running/stopped state |
| **7040** | System | Service start type changed |
| **7045** | System | New service installed (name, path, account, start type) |
| **1074** | System | System shutdown/restart initiated |
| **6005/6006** | System | EventLog service started/stopped (boot/shutdown) |
| **104** | System | Event log cleared |

**Sysmon Event IDs (if deployed):**

| Event ID | Description | Key Fields |
|----------|-------------|------------|
| **1** | Process creation | CommandLine, Hashes, ParentImage, User |
| **3** | Network connection | Source/Dest IP:port, Protocol |
| **7** | Image loaded (DLL) | ImageLoaded, Hashes, Signed |
| **8** | CreateRemoteThread | Source/Target Process |
| **10** | Process access | GrantedAccess (0x1FFFFF = full, 0x1010 = LSASS read) |
| **11** | File create | TargetFilename, CreationUtcTime |
| **12/13/14** | Registry events | Create, Set, Rename operations |
| **15** | File create stream hash | ADS detection, Zone.Identifier |
| **22** | DNS query | QueryName, QueryResults |
| **23** | File delete (archived) | Deleted file content preserved |
| **25** | Process tampering | Process hollowing/herpaderping detection |

**PowerShell Logging:**

| Event ID | Log | Description |
|----------|-----|-------------|
| **4103** | PowerShell/Operational | Module logging (cmdlet execution) |
| **4104** | PowerShell/Operational | Script block logging (full script content, deobfuscated) |
| **4105/4106** | PowerShell/Operational | Script block start/stop |
| **400/403** | Windows PowerShell | Engine lifecycle (start/stop) |
| **800** | Windows PowerShell | Pipeline execution details |

**RDP-Specific Events:**

| Event ID | Log | Description |
|----------|-----|-------------|
| **1024** | TerminalServices-RDPClient/Operational | RDP connection attempt (destination hostname) |
| **1149** | TerminalServices-RemoteConnectionManager/Operational | User authentication succeeded (source IP, username) |
| **21** | TerminalServices-LocalSessionManager/Operational | Session logon succeeded |
| **22** | TerminalServices-LocalSessionManager/Operational | Shell start notification |
| **24** | TerminalServices-LocalSessionManager/Operational | Session disconnected |
| **25** | TerminalServices-LocalSessionManager/Operational | Session reconnected |

**Other Critical Logs:**

| Event ID | Log | Description |
|----------|-----|-------------|
| **8001/8003** | WLAN-AutoConfig/Operational | WiFi connected/disconnected (SSID, BSSID) |
| **5861** | WMI-Activity/Operational | WMI event consumer created (persistence) |
| **9707** | Shell-Core/Operational | Command execution with SID context |

---

### 1.10 Additional Windows Artifacts

**Jumplists:**
```
C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Recent\AutomaticDestinations\   # Auto-generated
C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Recent\CustomDestinations\      # App-specific
```
- Track recently/frequently accessed files per application
- Each application has unique AppID-based filename
- Contains file paths, timestamps, access count

**LNK (Shortcut) Files:**
```
C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Recent\
C:\Users\<user>\Desktop\
```
- Target file path (including network paths and removed drives)
- MAC timestamps of target file at time of link creation
- Volume serial number, NetBIOS name, MAC address
- Target file size

**Recycle Bin:**
```
C:\$Recycle.Bin\<SID>\$I<id>    # Metadata (original path, deletion timestamp, file size)
C:\$Recycle.Bin\<SID>\$R<id>    # Original file content
```

**Zone.Identifier (Mark of the Web):**
```
# Alternate Data Stream on downloaded files
file.exe:Zone.Identifier
  [ZoneTransfer]
  ZoneId=3           # 0=Local, 1=Intranet, 2=Trusted, 3=Internet, 4=Restricted
  ReferrerUrl=https://example.com/download
  HostUrl=https://cdn.example.com/file.exe
```

**BAM/DAM (Background/Desktop Activity Moderator):**
```
HKLM\SYSTEM\CurrentControlSet\Services\bam\State\UserSettings\<SID>
HKLM\SYSTEM\CurrentControlSet\Services\dam\State\UserSettings\<SID>
```
- Full path of executed binary
- Last execution timestamp (UTC, FILETIME format)
- Windows 10 1709+ only

**PCA (Program Compatibility Assistant):**
```
C:\Windows\appcompat\pca\PcaAppLaunchDic.txt     # Win11 22H2+
C:\Windows\appcompat\pca\PcaGeneralDb0.txt
```
- Application launch paths with timestamps

**WER (Windows Error Reporting):**
```
C:\ProgramData\Microsoft\Windows\WER\ReportArchive\
C:\ProgramData\Microsoft\Windows\WER\ReportQueue\
C:\Users\<user>\AppData\Local\Microsoft\Windows\WER\
```
- Crash reports indicate execution evidence
- Contain faulting module, exception code, timestamps

**Scheduled Tasks:**
```
C:\Windows\System32\Tasks\                  # XML task definitions
C:\Windows\System32\Tasks\Microsoft\        # Microsoft default tasks
```
- Task name, command, arguments, triggers, schedule
- Creator SID, registration date
- Last run time, last result code

**RDP Bitmap Cache:**
```
C:\Users\<user>\AppData\Local\Microsoft\Terminal Server Client\Cache\
  bcache24.bmc
  cache0001.bin
```
- Fragments of remote desktop screenshots
- Can be reconstructed with `bmc-tools`

**Microsoft Office TrustRecords:**
```
NTUSER\Software\Microsoft\Office\<version>\<app>\Security\Trusted Documents\TrustRecords
```
- Tracks documents where user clicked "Enable Editing" or "Enable Content"
- Full file path, trust timestamp

**Windows Search Database:**
```
C:\ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb
```
- ESE database indexing file content, metadata, email
- Contains content of indexed files even if originals are deleted

---

## 2. Linux Artifacts

### 2.1 System Logs

**Primary Log Locations:**

| Path | Content | Format |
|------|---------|--------|
| `/var/log/syslog` | General system messages (Debian/Ubuntu) | Text |
| `/var/log/messages` | General system messages (RHEL/CentOS) | Text |
| `/var/log/auth.log` | Authentication events (Debian/Ubuntu) | Text |
| `/var/log/secure` | Authentication events (RHEL/CentOS) | Text |
| `/var/log/kern.log` | Kernel messages (module loads, hardware, USB) | Text |
| `/var/log/dmesg` | Kernel ring buffer (boot messages) | Text |
| `/var/log/boot.log` | Boot process output | Text |
| `/var/log/daemon.log` | Daemon/service messages | Text |
| `/var/log/faillog` | Failed login attempts | Binary (`faillog` command) |
| `/var/log/cron` | Cron job execution log (RHEL) | Text |
| `/var/log/apt/history.log` | APT package operations (Debian) | Text |
| `/var/log/yum.log` | YUM package operations (RHEL) | Text |
| `/var/log/dpkg.log` | dpkg package installations | Text |
| `/var/log/pacman.log` | pacman package operations (Arch) | Text |

**Systemd Journal:**
```
/var/log/journal/<machine-id>/*.journal     # Persistent journals
/run/log/journal/<machine-id>/*.journal     # Volatile journals (RAM-only if not persisted)
```
- Binary format — query with `journalctl`
- `journalctl --since "2026-03-10" --until "2026-03-14"` — time-bounded queries
- `journalctl _COMM=sshd` — filter by command
- `journalctl -u nginx.service` — filter by unit
- `journalctl _UID=1000` — filter by user
- Contains structured metadata, boot markers, priority levels

### 2.2 User Activity Artifacts

**Shell History:**
```
/home/<user>/.bash_history           # Bash command history
/home/<user>/.zsh_history            # Zsh command history
/home/<user>/.local/share/fish/fish_history   # Fish shell history
/root/.bash_history                  # Root command history
/home/<user>/.python_history         # Python REPL history
/home/<user>/.mysql_history          # MySQL client history
/home/<user>/.psql_history           # PostgreSQL client history
/home/<user>/.lesshst                # less command history
/home/<user>/.viminfo                # Vim editor history (files opened, search patterns, commands)
/home/<user>/.wget-hsts              # wget HSTS cache (evidence of downloads)
/home/<user>/.local/share/recently-used.xbel  # GNOME recent files (freedesktop)
```

**SSH Artifacts:**
```
/home/<user>/.ssh/known_hosts        # Hosts the user has connected to
/home/<user>/.ssh/authorized_keys    # Keys authorized for inbound access
/home/<user>/.ssh/config             # SSH client configuration
/var/log/auth.log                    # SSH login/logout records
/etc/ssh/sshd_config                 # Server configuration (allowed auth methods)
```

### 2.3 Login Records

**wtmp / btmp / utmp:**

| File | Content | Tool |
|------|---------|------|
| `/var/log/wtmp` | Successful login/logout records (user, terminal, source IP, timestamps) | `last` |
| `/var/log/btmp` | Failed login attempts | `lastb` |
| `/var/run/utmp` | Currently logged-in users | `who`, `w` |
| `/var/log/lastlog` | Last login per user | `lastlog` |

- Binary format — not human-readable, use respective tools
- `last -f /var/log/wtmp -i` — show logins with IP addresses
- `lastb -f /var/log/btmp` — show failed attempts
- wtmp rotation: `/var/log/wtmp.1`, etc.

### 2.4 Cron Artifacts

```
/etc/crontab                         # System crontab
/etc/cron.d/                         # Drop-in cron files
/etc/cron.daily/                     # Daily scripts
/etc/cron.hourly/                    # Hourly scripts
/etc/cron.weekly/                    # Weekly scripts
/etc/cron.monthly/                   # Monthly scripts
/var/spool/cron/crontabs/<user>      # Per-user crontabs (Debian)
/var/spool/cron/<user>               # Per-user crontabs (RHEL)
/var/log/cron                        # Cron execution log (RHEL)
/var/log/syslog | grep CRON          # Cron execution log (Debian)
```

**Systemd Timers (modern cron replacement):**
```
/etc/systemd/system/*.timer          # System timer units
/home/<user>/.config/systemd/user/*.timer   # User timer units
journalctl -u <timer-name>.service   # Timer execution history
```

### 2.5 Persistence Mechanisms

```
# Init/Service Persistence
/etc/systemd/system/                 # Systemd service units
/etc/init.d/                         # SysV init scripts
/etc/rc.local                        # Legacy startup script
/lib/systemd/system/                 # Package-installed service units

# Shell Persistence
/etc/profile                         # System-wide login shell profile
/etc/profile.d/*.sh                  # Login shell profile drop-ins
/etc/bash.bashrc                     # System-wide bashrc
/home/<user>/.bashrc                 # User bashrc (interactive non-login)
/home/<user>/.bash_profile           # User bash_profile (login shell)
/home/<user>/.profile                # User profile (login shell)
/home/<user>/.config/autostart/      # XDG autostart desktop entries

# Kernel Modules
/lib/modules/$(uname -r)/           # Kernel modules
/etc/modules                         # Modules loaded at boot
/etc/modprobe.d/                     # Module configuration

# PAM
/etc/pam.d/                          # PAM module configuration (auth backdoors)

# Preload
/etc/ld.so.preload                   # Shared library preloading (rootkit technique)
```

### 2.6 Filesystem Artifacts

```
# Timestamps (stat, find)
# atime — last access | mtime — last modification | ctime — last metadata change

# Recently Modified Files
find / -mtime -7 -type f             # Files modified in last 7 days
find / -ctime -1 -type f             # Metadata changed in last day

# SUID/SGID (privilege escalation indicators)
find / -perm -4000 -type f           # SUID files
find / -perm -2000 -type f           # SGID files

# Temporary Directories (staging areas)
/tmp/
/var/tmp/
/dev/shm/                            # Shared memory tmpfs (common malware staging)

# Deleted but Open Files
ls -la /proc/<pid>/fd/               # File descriptors of running process
find /proc/*/fd -ls 2>/dev/null | grep deleted

# File Capabilities
getcap -r / 2>/dev/null              # Files with capabilities set
```

### 2.7 User and Group Information

```
/etc/passwd                          # User accounts (check for UID 0 besides root)
/etc/shadow                          # Password hashes, last change dates, expiry
/etc/group                           # Group memberships
/etc/sudoers                         # Sudo privileges
/etc/sudoers.d/                      # Drop-in sudo configs
/var/log/auth.log                    # sudo usage with commands
```

### 2.8 Network Artifacts

```
/etc/hosts                           # Local DNS overrides (C2 redirection)
/etc/resolv.conf                     # DNS resolver configuration
/etc/network/interfaces              # Network configuration (Debian)
/etc/sysconfig/network-scripts/      # Network configuration (RHEL)
/etc/NetworkManager/                 # NetworkManager profiles (may contain WiFi passwords)
/var/lib/dhcp/dhclient.leases        # DHCP lease history
/proc/net/tcp                        # Active TCP connections (live)
/proc/net/udp                        # Active UDP sockets (live)
ss -tulnp                            # Socket statistics (live)
iptables -L -n -v                    # Firewall rules (live)
```

---

## 3. macOS Artifacts

### 3.1 FSEvents

**Purpose:** macOS file system event log — records every file system change (create, modify, delete, rename) on every volume.

**Location:**
```
/.fseventsd/                         # Root of every volume
# Stored as gzip-compressed binary files with hex filenames
# Each file contains pages of event records
```

**Forensic Value:**
- Every file system operation with flags indicating the type of change
- Persists across reboots (stored on disk, not just in memory)
- Records path, event flags, and event ID (monotonically increasing)
- Covers all mounted volumes (internal, external, network)
- Historically used by Time Machine and Spotlight for change tracking
- Can reveal evidence of deleted files, tool deployment, staging

**Event Flags:**
| Flag | Meaning |
|------|---------|
| `FlagItemCreated` | File/folder created |
| `FlagItemRemoved` | File/folder deleted |
| `FlagItemRenamed` | File/folder renamed |
| `FlagItemModified` | File content modified |
| `FlagItemChangeOwner` | Ownership changed |
| `FlagItemXattrMod` | Extended attributes modified |
| `FlagItemIsFile` / `FlagItemIsDir` | Entry type |

**Tools:** `FSEventsParser`, `mac_apt` (fsevents module), Autopsy

### 3.2 Spotlight Metadata

**Purpose:** Spotlight indexes file content and metadata for search — contains rich metadata even for deleted files if index is not purged.

**Location:**
```
/.Spotlight-V100/                    # Per-volume Spotlight index
/private/var/db/Spotlight-V100/      # System Spotlight data
~/.Spotlight-V100/                   # User Spotlight data
```

**Forensic Value:**
- File content indexed (text, PDF, Office docs) — searchable even if file deleted
- Metadata: author, creation date, last opened date, content type
- `kMDItemWhereFroms` — download source URL
- `kMDItemContentCreationDate` — document creation date
- `kMDItemLastUsedDate` — last time file was opened

**Tools:** `mdls` (live system), `spotlight_parser`, `mac_apt`

### 3.3 KnowledgeC

**Purpose:** macOS activity database tracking application usage, device state, and user activity patterns.

**Location:**
```
/private/var/db/CoreDuet/Knowledge/knowledgeC.db                    # System-wide
~/Library/Application Support/Knowledge/knowledgeC.db               # Per-user
```

**Forensic Value:**
- Application usage with start/end timestamps and duration
- Device lock/unlock events
- Display brightness and power state changes
- Safari browsing activity
- Media playback events
- Application focus/blur events (which app was in foreground)
- Battery level and charging state
- Retained for approximately 30 days

**Tools:** `mac_apt`, `KnowledgeC.db` SQLite browser, APOLLO (Apple Pattern of Life Lazy Output'er)

### 3.4 Unified Logs

**Purpose:** Apple's unified logging system (macOS 10.12+) replacing ASL — captures system, application, and kernel events.

**Location:**
```
/private/var/db/diagnostics/                    # Log data store
/private/var/db/diagnostics/Persist/            # Persistent log files (.tracev3)
/private/var/db/diagnostics/Special/            # Special log files
/private/var/db/diagnostics/Signpost/           # Signpost events
/private/var/db/diagnostics/HighVolume/         # High-volume logs
/private/var/db/uuidtext/                       # Format string lookup tables
/private/var/db/diagnostics/timesync/           # Time sync data
```

**Forensic Value:**
- Process execution with full command lines
- Network connections and DNS queries
- Authentication events (local and remote)
- USB device connections
- Application launches and crashes
- Much richer than legacy ASL logs
- Three persistence levels: `default` (days), `info` (hours), `debug` (minutes)

**Tools:** `log show` / `log collect` (live), `UnifiedLogReader`, `mac_apt`, `nomen` (log parser)

### 3.5 Quarantine Events

**Purpose:** Tracks files downloaded from the internet (similar to Windows Zone.Identifier/MotW).

**Location:**
```
~/Library/Preferences/com.apple.LaunchServices.QuarantineEventsV2    # macOS Lion+
~/Library/Preferences/com.apple.LaunchServices.QuarantineEvents      # Snow Leopard and earlier
```

**Forensic Value:**
- Download URL (source of the file)
- Download timestamp
- Downloading application (Safari, Chrome, curl, etc.)
- File path on disk
- Quarantine agent bundle identifier
- Persists even after file is deleted

### 3.6 TCC (Transparency, Consent, and Control) Database

**Purpose:** Records privacy permission grants/denials — which apps have access to camera, microphone, contacts, location, etc.

**Location:**
```
/Library/Application Support/com.apple.TCC/TCC.db           # System-wide
~/Library/Application Support/com.apple.TCC/TCC.db          # Per-user
```

**Forensic Value:**
- Application bundle identifiers with granted/denied permissions
- Timestamp of permission decision
- Categories: Full Disk Access, Camera, Microphone, Screen Recording, Accessibility, Contacts, Calendar, Location
- Evidence of malware requesting excessive permissions

### 3.7 Launch Agents & Daemons (Persistence)

```
# System Persistence
/Library/LaunchAgents/                          # System-wide, runs as user
/Library/LaunchDaemons/                         # System-wide, runs as root
/System/Library/LaunchAgents/                   # Apple system agents
/System/Library/LaunchDaemons/                  # Apple system daemons
/Library/StartupItems/                          # Legacy startup items

# User Persistence
~/Library/LaunchAgents/                         # Per-user agents

# Login Items
~/Library/Preferences/com.apple.loginitems.plist
```

### 3.8 Additional macOS Artifacts

```
# User Activity
~/Library/Preferences/                          # Application preferences (plist files)
~/Library/Application Support/                  # Application data
~/Library/Caches/                               # Application caches
~/Library/Cookies/                              # Safari/app cookies
~/Library/SyncedPreferences/                    # iCloud-synced preferences
~/Library/Logs/                                 # Application logs

# System Artifacts
/private/var/log/install.log                    # Package installation log
/private/var/log/system.log                     # Legacy system log
/private/var/log/asl/                           # Apple System Log archives
/private/var/audit/                             # OpenBSM audit logs (if enabled)
/private/var/db/dslocal/nodes/Default/users/    # Local user accounts (plist)

# Network
/Library/Preferences/SystemConfiguration/       # Network configuration
/private/var/db/dhcpclient/leases/              # DHCP lease history

# Keychain
~/Library/Keychains/                            # User keychains
/Library/Keychains/System.keychain              # System keychain

# Crash Reports
~/Library/Logs/DiagnosticReports/               # User app crash reports
/Library/Logs/DiagnosticReports/                # System crash reports
```

---

## 4. Browser Artifacts

### 4.1 Chromium-Based Browsers (Chrome, Edge, Brave, Opera)

**Profile Locations:**

| OS | Chrome Path |
|----|-------------|
| Windows | `%LOCALAPPDATA%\Google\Chrome\User Data\Default\` |
| macOS | `~/Library/Application Support/Google/Chrome/Default/` |
| Linux | `~/.config/google-chrome/Default/` |

**Edge:** Replace `Google\Chrome` with `Microsoft\Edge`
**Brave:** Replace with `BraveSoftware\Brave-Browser`

**Artifact Files (SQLite databases & JSON):**

| File | Content | Key Tables/Fields |
|------|---------|-------------------|
| `History` | Browsing history, downloads | `urls` (url, title, visit_count, last_visit_time), `downloads` (target_path, start_time, url) |
| `Cookies` | HTTP cookies | `cookies` (host_key, name, value, creation_utc, expires_utc, last_access_utc) |
| `Login Data` | Saved credentials | `logins` (origin_url, username_value, password_value [encrypted]) |
| `Web Data` | Autofill entries | `autofill` (name, value, date_created, count) |
| `Bookmarks` | Bookmarks JSON | name, url, date_added, date_last_used |
| `Preferences` | Browser settings JSON | homepage, default search engine, extension settings |
| `Top Sites` | Frequently visited | url, title, visit_count |
| `Shortcuts` | Omnibox shortcuts | text, url, last_access_time |
| `Favicons` | Site favicons | icon_url, page_url |
| `Network Action Predictor` | URL predictions | url, hit_count |
| `Local Storage/leveldb/` | HTML5 local storage | Key-value pairs per origin |
| `Session Storage/` | Session data | Per-tab session storage |
| `Cache/` (or `Code Cache/`) | HTTP cache | Cached web resources |
| `Extensions/` | Installed extensions | Extension ID, manifest.json, source code |

**Timestamps:** Chrome stores timestamps as microseconds since January 1, 1601 (Windows FILETIME epoch).

**Tools:** Hindsight (comprehensive Chromium forensics), ChromeCacheView, DB Browser for SQLite, `unfurl` (URL timestamp decoding)

### 4.2 Firefox

**Profile Locations:**

| OS | Path |
|----|------|
| Windows | `%APPDATA%\Mozilla\Firefox\Profiles\<random>.default-release\` |
| macOS | `~/Library/Application Support/Firefox/Profiles/<random>.default-release/` |
| Linux | `~/.mozilla/firefox/<random>.default-release/` |

**Artifact Files:**

| File | Content |
|------|---------|
| `places.sqlite` | History (`moz_places`), bookmarks (`moz_bookmarks`), downloads, annotations |
| `cookies.sqlite` | HTTP cookies |
| `formhistory.sqlite` | Form autofill data |
| `logins.json` + `key4.db` | Saved credentials (encrypted with master password or NSS) |
| `permissions.sqlite` | Site permissions (camera, mic, notifications) |
| `content-prefs.sqlite` | Per-site preferences (zoom, etc.) |
| `webappsstore.sqlite` | DOM/local storage |
| `sessionstore.jsonlz4` | Open tabs, session history, form data |
| `extensions.json` | Installed add-ons |
| `cache2/entries/` | HTTP cache files |
| `downloads.sqlite` | Download history (older Firefox) |

**Timestamps:** Firefox uses microseconds since Unix epoch (January 1, 1970).

### 4.3 Safari

**Profile Location:** `~/Library/Safari/`

**Artifact Files:**

| File | Content |
|------|---------|
| `History.db` | Browsing history (SQLite) |
| `Bookmarks.plist` | Bookmarks |
| `Downloads.plist` | Download history |
| `TopSites.plist` | Frequently visited sites |
| `LastSession.plist` | Last browser session |
| `Extensions/` | Installed extensions |
| `LocalStorage/` | HTML5 local storage |
| `Databases/` | Web SQL databases |
| `CloudTabs.db` | iCloud-synced tabs |

---

## 5. Memory Forensics with Volatility3

### 5.1 Acquisition

**Before analysis — acquire the memory image:**

| Tool | Platform | Command |
|------|----------|---------|
| WinPmem | Windows | `winpmem_mini.exe output.raw` |
| LiME | Linux | `insmod lime.ko "path=/tmp/mem.lime format=lime"` |
| AVML | Linux | `avml output.lime` |
| osxpmem | macOS | `osxpmem -o output.aff4` |
| DumpIt | Windows | `DumpIt.exe` (one-click) |

**Memory image formats:** Raw (`.raw`, `.mem`, `.bin`), LiME (`.lime`), AFF4, EWF, crash dumps (`.dmp`)

### 5.2 Volatility3 Architecture

```bash
# Basic usage
python3 vol.py -f <memory_image> <plugin>

# With symbol tables (required for accurate parsing)
python3 vol.py -f <memory_image> -s <symbol_path> <plugin>

# Output formatting
python3 vol.py -f <memory_image> <plugin> -r pretty    # Formatted table
python3 vol.py -f <memory_image> <plugin> -r csv        # CSV output
python3 vol.py -f <memory_image> <plugin> -r json       # JSON output
```

### 5.3 Windows Memory Plugins

**System Information:**
```bash
vol.py -f mem.raw windows.info
# OS version, architecture, KDBG address, DTB, system time
```

**Process Analysis:**
```bash
# List active processes (from EPROCESS linked list)
vol.py -f mem.raw windows.pslist
# Columns: PID, PPID, ImageFileName, CreateTime, ExitTime

# Scan for processes (pool tag scanning — finds hidden/terminated)
vol.py -f mem.raw windows.psscan
# Finds processes unlinked from EPROCESS list (rootkit detection)

# Process tree (parent-child hierarchy)
vol.py -f mem.raw windows.pstree

# Command-line arguments for each process
vol.py -f mem.raw windows.cmdline

# Environment variables
vol.py -f mem.raw windows.envars --pid <PID>

# Process privileges
vol.py -f mem.raw windows.privileges --pid <PID>
```

**DLL and Module Analysis:**
```bash
# List loaded DLLs per process
vol.py -f mem.raw windows.dlllist --pid <PID>

# Scan for loaded modules in memory
vol.py -f mem.raw windows.modscan

# List loaded kernel drivers
vol.py -f mem.raw windows.driverscan
```

**Memory Injection Detection:**
```bash
# Detect injected code (PAGE_EXECUTE_READWRITE, no backing file)
vol.py -f mem.raw windows.malfind --pid <PID>
# Outputs: process, VA range, protection flags, hexdump, disassembly
# Key indicator: MZ header in non-image VAD region

# YARA scanning across process memory
vol.py -f mem.raw windows.vadyarascan --yara-file rules.yar

# Detect process hollowing / herpaderping
# Compare on-disk vs in-memory PE headers
vol.py -f mem.raw windows.malfind    # + manual PE header comparison
```

**Network Analysis:**
```bash
# Scan for network connections and listening sockets
vol.py -f mem.raw windows.netscan
# Columns: Offset, Proto, LocalAddr, ForeignAddr, State, PID, Owner, Created

# Active network connections (more limited than netscan)
vol.py -f mem.raw windows.netstat
```

**Registry Analysis:**
```bash
# List loaded registry hives
vol.py -f mem.raw windows.registry.hivelist

# Print registry key contents
vol.py -f mem.raw windows.registry.printkey --key "Software\Microsoft\Windows\CurrentVersion\Run"

# Dump certificate store
vol.py -f mem.raw windows.registry.certificates
```

**File Analysis:**
```bash
# Scan for file objects in memory
vol.py -f mem.raw windows.filescan

# Dump files from memory
vol.py -f mem.raw -o /output/ windows.dumpfiles --pid <PID>

# Dump specific file by virtual address
vol.py -f mem.raw -o /output/ windows.dumpfiles --virtaddr <0xADDRESS>
```

**Handle Analysis:**
```bash
# List open handles (files, registry keys, mutexes, events, etc.)
vol.py -f mem.raw windows.handles --pid <PID>
```

**Credential Extraction:**
```bash
# Dump password hashes from SAM
vol.py -f mem.raw windows.hashdump

# Dump cached domain credentials
vol.py -f mem.raw windows.cachedump

# Dump LSA secrets
vol.py -f mem.raw windows.lsadump
```

**Service Analysis:**
```bash
# List Windows services
vol.py -f mem.raw windows.svcscan
# Columns: Offset, Order, PID, Start, State, Type, Name, Display, Binary
```

**Process Memory:**
```bash
# Map process memory regions
vol.py -f mem.raw -o /output/ windows.memmap --dump --pid <PID>

# List Virtual Address Descriptors (memory regions)
vol.py -f mem.raw windows.vadinfo --pid <PID>
```

### 5.4 Linux Memory Plugins

```bash
# Process listing
vol.py -f mem.lime linux.pslist
vol.py -f mem.lime linux.pstree

# Bash history from memory (live commands not yet flushed)
vol.py -f mem.lime linux.bash

# Process memory maps
vol.py -f mem.lime linux.proc.maps --pid <PID>

# Loaded kernel modules
vol.py -f mem.lime linux.lsmod

# Check for hidden modules
vol.py -f mem.lime linux.hidden_modules

# Open files per process
vol.py -f mem.lime linux.lsof

# Network connections
vol.py -f mem.lime linux.sockstat

# Mount points
vol.py -f mem.lime linux.mountinfo

# System call table check (rootkit detection)
vol.py -f mem.lime linux.check_syscall

# Interrupt descriptor table check
vol.py -f mem.lime linux.check_idt

# Loaded ELF files
vol.py -f mem.lime linux.elfs

# Environment variables
vol.py -f mem.lime linux.envars

# Keyboard notifier check (keylogger detection)
vol.py -f mem.lime linux.keyboard_notifiers

# tty input/output (terminal history)
vol.py -f mem.lime linux.tty_check
```

### 5.5 macOS Memory Plugins

```bash
# Process listing
vol.py -f mem.raw mac.pslist
vol.py -f mem.raw mac.pstree

# List loaded kexts (kernel extensions)
vol.py -f mem.raw mac.lsmod

# Network connections
vol.py -f mem.raw mac.netstat

# Open files (Mach ports)
vol.py -f mem.raw mac.lsof

# Bash history
vol.py -f mem.raw mac.bash

# Mount points
vol.py -f mem.raw mac.mount

# Process maps
vol.py -f mem.raw mac.proc_maps

# System call table check
vol.py -f mem.raw mac.check_syscall

# Check for inline hooks (kext hooking)
vol.py -f mem.raw mac.check_sysctl

# Loaded Mach-O files
vol.py -f mem.raw mac.macho
```

### 5.6 Memory Forensics Methodology

```
PHASE 1: TRIAGE
├── Identify OS and architecture (windows.info / linux.pslist)
├── List processes (pslist → psscan → compare for hidden processes)
├── Review process tree for suspicious parent-child relationships
│   ├── svchost.exe not child of services.exe → suspicious
│   ├── cmd.exe child of iexplore.exe → suspicious
│   └── powershell.exe child of winword.exe → suspicious
└── Check command lines for encoded/obfuscated commands (cmdline)

PHASE 2: PROCESS DEEP DIVE
├── For each suspicious process:
│   ├── Check DLLs loaded (dlllist) — unsigned, unusual paths
│   ├── Check handles (handles) — files, registry keys, mutexes
│   ├── Check memory regions (malfind) — injected code
│   ├── Dump process executable (dumpfiles)
│   └── Check network connections (netscan) — C2 callbacks
├── Cross-reference PID in netscan with pslist
└── Look for processes with exit times (terminated but evidence remains)

PHASE 3: PERSISTENCE & LATERAL MOVEMENT
├── Registry Run keys (registry.printkey)
├── Services (svcscan) — unusual binary paths, names
├── Network connections to internal hosts (netscan) — lateral movement
├── Credential material (hashdump, cachedump, lsadump)
└── YARA scan for known malware signatures (vadyarascan)

PHASE 4: ROOTKIT DETECTION (Linux/macOS focus)
├── Compare pslist vs psscan (hidden processes)
├── Check syscall table (check_syscall)
├── Check IDT (check_idt)
├── Check hidden kernel modules (hidden_modules)
├── Check kernel hooks
└── Compare loaded modules vs expected (lsmod)

PHASE 5: EVIDENCE EXTRACTION
├── Dump suspicious executables and DLLs
├── Extract network IOCs (IPs, domains from netscan + strings)
├── Recover in-memory artifacts (bash history, clipboard, etc.)
├── Timeline all process creation/termination times
└── Hash all extracted files for IOC sharing
```

---

## 6. Timeline Generation & Analysis

### 6.1 Plaso (log2timeline)

**Purpose:** Super timeline generator — parses 100+ artifact types into a unified chronological timeline.

**Supported Parsers (selection):**
- Windows: EVTX, Prefetch, registry hives, $MFT, USN Journal, Jump Lists, LNK files, SRUM, Amcache, Recycle Bin, IIS logs
- Linux: syslog, auth.log, wtmp/utmp, dpkg.log, Apache/Nginx access logs, .bash_history
- macOS: FSEvents, Spotlight, Unified Logs, plist files, ASL logs, quarantine events
- Browser: Chrome/Firefox/Safari history, cookies, downloads, cache
- Generic: SQLite databases, OLE/OOXML documents, SQLite databases, JSON/CSV logs

**Workflow:**
```bash
# 1. Create timeline from disk image or mounted evidence
log2timeline.py timeline.plaso /path/to/evidence/

# 2. Create timeline from specific parsers only
log2timeline.py --parsers "winevtx,prefetch,mft" timeline.plaso /path/to/evidence/

# 3. Filter and output timeline
psort.py -o l2tcsv -w timeline.csv timeline.plaso

# 4. Filter by time range
psort.py -o l2tcsv -w filtered.csv timeline.plaso "date > '2026-03-01' AND date < '2026-03-14'"

# 5. Import into Timesketch for collaborative analysis
psort.py -o timesketch --name "Case-2026-001" timeline.plaso
```

### 6.2 Timesketch

**Purpose:** Collaborative web-based timeline analysis — supports multiple analysts working on the same case with tagging, annotations, and Sigma rule matching.

**Key Features:**
- Import Plaso timelines, CSV, JSONL
- Sigma rule auto-analysis on import
- Sketch-based collaboration (tag events, add comments)
- Intelligence features (IOC matching, regex search)
- GraphQL API for automation

### 6.3 Sleuth Kit + Autopsy

**Sleuth Kit CLI Tools:**

| Tool | Layer | Purpose |
|------|-------|---------|
| `mmls` | Volume | List partitions |
| `fsstat` | File System | File system details and metadata |
| `fls` | File Name | List files and directories (including deleted) |
| `icat` | Inode | Extract file content by inode number |
| `istat` | Inode | Display inode metadata (timestamps, blocks) |
| `ils` | Inode | List all inodes (find deleted) |
| `blkcat` | Block | Extract raw block data |
| `blkls` | Block | List unallocated blocks (slack space) |
| `mactime` | Timeline | Create MAC timeline from body file |
| `tsk_recover` | Recovery | Recover all deleted files |
| `tsk_gettimes` | Timeline | Extract file timestamps |
| `sigfind` | Carving | Find data unit with signature |

**Supported File Systems:** NTFS, FAT12/16/32, exFAT, EXT2/3/4, HFS+, APFS, UFS, ISO 9660, YAFFS2

**Workflow:**
```bash
# Examine partition layout
mmls disk.dd

# List files (including deleted, marked with *)
fls -r -o 2048 disk.dd

# Extract deleted file by inode
icat -o 2048 disk.dd 12345 > recovered_file.bin

# Generate body file for timeline
fls -r -m "/" -o 2048 disk.dd > bodyfile.txt
mactime -b bodyfile.txt -d > timeline.csv

# Recover all deleted files
tsk_recover -o 2048 disk.dd /output/recovered/
```

---

## 7. Event Log Analysis Tools

### 7.1 Chainsaw

**Purpose:** Rapid Windows event log triage using Sigma rules and built-in detections.

**Capabilities:**
- EVTX, JSON, XML log format support
- Sigma rule detection engine with field mapping
- Built-in rules for: antivirus alerts, log clearing, account changes, remote logons, brute-force
- ShimCache and SRUM analysis
- MFT and registry hive content dumping

**Usage:**
```bash
# Hunt with Sigma rules
chainsaw hunt /path/to/evtx/ -s sigma/rules/ --mapping mappings/sigma-event-logs-all.yml

# Hunt with built-in rules
chainsaw hunt /path/to/evtx/ --rules chainsaw/rules/

# Search for specific strings
chainsaw search "mimikatz" /path/to/evtx/

# Search with regex
chainsaw search -e "(?i)invoke-(mimikatz|obfuscation)" /path/to/evtx/

# Analyse ShimCache
chainsaw analyse shimcache SYSTEM --amcache Amcache.hve

# Analyse SRUM database
chainsaw analyse srum SRUDB.dat

# Output formats
chainsaw hunt /path/to/evtx/ -s sigma/ --mapping mappings/ --json  # JSON
chainsaw hunt /path/to/evtx/ -s sigma/ --mapping mappings/ --csv   # CSV
```

### 7.2 Hayabusa

**Purpose:** Windows event log fast forensics timeline generator with 4000+ Sigma rules and 170+ built-in rules.

**Key Features:**
- Multi-threaded EVTX parsing (Rust-based, fast)
- Full Sigma v2 specification support including correlation rules
- MITRE ATT&CK tactic tagging
- Field value normalization (hex to human-readable)
- Base64 detection, extraction, and decoding in log entries
- EVTX slack space record carving

**Usage:**
```bash
# Generate CSV timeline
hayabusa csv-timeline -d /path/to/evtx/ -o timeline.csv

# Generate JSON timeline
hayabusa json-timeline -d /path/to/evtx/ -o timeline.jsonl

# Logon summary analysis
hayabusa logon-summary -d /path/to/evtx/

# Event ID frequency analysis
hayabusa eid-metrics -d /path/to/evtx/

# Computer metrics (event distribution per system)
hayabusa computer-metrics -d /path/to/evtx/

# Search for keyword/regex
hayabusa search -d /path/to/evtx/ -k "mimikatz"

# Update detection rules
hayabusa update-rules

# Level tuning (adjust severity thresholds)
hayabusa level-tuning -d /path/to/evtx/
```

---

## 8. Forensic Toolchain Reference

### 8.1 Collection & Acquisition

| Tool | Platform | Purpose |
|------|----------|---------|
| **KAPE** | Windows | Automated artifact collection (targets) and processing (modules) |
| **Velociraptor** | Cross-platform | Live endpoint artifact collection with VQL |
| **GRR** | Cross-platform | Google's remote live forensics framework |
| **DFIR ORC** | Windows | Automated forensic artifact collection |
| **FastIR Collector** | Windows/Linux | Incident response artifact collector |
| **CyLR** | Cross-platform | KAPE-compatible artifact collector |
| **Acquire** (Dissect) | Cross-platform | Full disk and selective artifact acquisition |
| **dc3dd** / **dcfldd** | Linux | Forensic imaging with hashing |
| **FTK Imager** | Windows | Disk imaging and artifact preview |
| **Guymager** | Linux | GUI forensic imaging |
| **LiME** | Linux | Linux memory acquisition kernel module |
| **AVML** | Linux | Userspace Linux memory acquisition |
| **WinPmem** | Windows | Windows memory acquisition |

### 8.2 Analysis Frameworks

| Tool | Purpose |
|------|---------|
| **Autopsy** | GUI forensic analysis platform (Sleuth Kit backend) |
| **Dissect** | Fox-IT's forensic framework for large-scale IR |
| **IPED** | Brazilian Federal Police digital forensics tool |
| **Turbinia** | Google's cloud-native forensic processing |
| **OpenRelik** | Open-source forensic workflow platform |
| **PowerForensics** | PowerShell-based live forensics |

### 8.3 Eric Zimmerman Tools (Windows-Focused)

| Tool | Artifact |
|------|----------|
| `MFTEcmd` | $MFT and USN Journal parsing |
| `PECmd` | Prefetch file parsing |
| `AmcacheParser` | Amcache.hve analysis |
| `AppCompatCacheParser` | ShimCache parsing |
| `ShellBagsExplorer` | ShellBags analysis |
| `JLECmd` | Jump List parsing |
| `LECmd` | LNK file parsing |
| `SrumECmd` | SRUM database parsing |
| `RECmd` / `Registry Explorer` | Registry hive analysis |
| `EvtxECmd` | Event log parsing |
| `RBCmd` | Recycle Bin parsing |
| `WxTCmd` | Windows 10 Timeline (ActivitiesCache.db) |
| `bstrings` | String extraction with regex support |
| `Timeline Explorer` | CSV/Excel timeline viewer |

### 8.4 Specialized Analysis

| Tool | Purpose |
|------|---------|
| **Hindsight** | Chromium browser forensics (history, cookies, cache, passwords, extensions) |
| **mac_apt** | macOS artifact parsing tool (FSEvents, Spotlight, KnowledgeC, unified logs) |
| **ALEAPP** | Android artifact extraction |
| **iLEAPP** | iOS artifact extraction |
| **APOLLO** | Apple Pattern of Life analysis (KnowledgeC, Health, etc.) |
| **bulk_extractor** | Automated data carving (emails, URLs, credit cards, GPS coords) |
| **RegRipper** | Automated registry analysis with plugins |
| **python-registry** | Cross-platform Windows registry parsing library |
| **unfurl** | URL and timestamp decoding |

### 8.5 IOC Scanning

| Tool | Purpose |
|------|---------|
| **Loki** | YARA + hash + filename IOC scanner |
| **THOR Lite** | Nextron IOC and anomaly scanner |
| **Fenrir** | Bash-based IOC scanner (no dependencies) |
| **Fastfinder** | Compiled IOC file finder |
| **Redline** | FireEye endpoint analysis and IOC matching |

---

## Quick Reference: Anti-Forensics Detection

| Technique | Detection Method |
|-----------|-----------------|
| **Timestomping** | Compare $STANDARD_INFORMATION vs $FILE_NAME in MFT; $SI before $FN creation = tampered |
| **Log clearing** | Event ID 1102 (Security), 104 (System); gaps in sequential Event Record IDs |
| **Process hollowing** | malfind shows MZ header in non-image VAD; VAD protection = PAGE_EXECUTE_READWRITE |
| **EVTX deletion** | USN Journal shows .evtx file deletion; missing date ranges in timeline |
| **Prefetch deletion** | USN Journal records deletion of .pf files; ShimCache/AmCache may still have execution evidence |
| **History clearing** | .bash_history file size = 0 with recent mtime; `HISTFILE=/dev/null` in profile |
| **Rootkit (Linux)** | pslist vs psscan discrepancy; syscall table modification; hidden kernel modules |
| **Secure deletion** | USN Journal shows multiple DATA_OVERWRITE entries followed by DELETE |
| **Registry key deletion** | Deleted keys recoverable from registry slack space; transaction logs (.LOG1/.LOG2) |

---

*CIPHER forensics training reference — comprehensive artifact locations, analysis methodology, and toolchain for Windows, Linux, macOS, browser, and memory forensics.*
