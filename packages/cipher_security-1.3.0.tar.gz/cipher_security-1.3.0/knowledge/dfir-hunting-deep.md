# DFIR & Threat Hunting Deep Training — CIPHER Knowledge Base

Generated: 2026-03-14
Sources: Velociraptor docs, Hayabusa, Chainsaw, KAPE, Volatility3, awesome-incident-response, DFIR Report, LogonTracer, APT-Hunter, SANS DFIR references, aboutdfir.com

---

## 1. Velociraptor — VQL Query Language & Artifact System

### 1.1 VQL Fundamentals

VQL (Velociraptor Query Language) is a SQL-like language designed for endpoint forensics and threat hunting. It enables rapid IOC discovery, detection rule creation, and deployment across large-scale endpoint fleets.

**Core Syntax:**

```sql
-- Basic SELECT from a plugin
SELECT Name, Id, Path FROM pslist()

-- LET for variable binding (= lazy, <= materialized)
LET processes = SELECT * FROM pslist()
LET cached_procs <= SELECT * FROM pslist()

-- WHERE filtering
SELECT * FROM pslist() WHERE Exe =~ "powershell"

-- foreach iteration
SELECT * FROM foreach(
  row={ SELECT * FROM pslist() },
  query={ SELECT ModuleName FROM modules(pid=Pid) }
)

-- Conditional execution
SELECT * FROM if(
  condition=ReallyDoIt='Y',
  then={ SELECT * FROM execve(argv=["rm", "-f", Target]) },
  else={ SELECT "Dry run" AS Status FROM scope() }
)

-- Preconditions (OS checks)
precondition: SELECT OS FROM info() WHERE OS = 'windows'
```

**Key Operators & Functions:**

| Operator | Purpose |
|----------|---------|
| `=~` | Regex match |
| `<=` | Materialize (buffer entire result set) |
| `=` | Lazy assignment |
| `format(format="%s:%d", args=[host, port])` | String formatting |
| `timestamp(epoch=Time)` | Unix epoch to timestamp |
| `parse_json_array(data=JSON)` | Parse JSON string to rows |
| `tempfile(extension=".ps1", data=Script)` | Create temp file |
| `base64encode(string=Data)` | Base64 encode |
| `utf16_encode(string=Data)` | UTF-16 encode |
| `upload(file=Path)` | Upload file to server |
| `dict(key=value)` | Create dictionary |
| `scope()` | Access current scope |

### 1.2 Key VQL Plugins for Hunting

**Process & Execution:**

```sql
-- List all processes
SELECT * FROM pslist()

-- Process tree with command lines
SELECT Name, Pid, PPid, CommandLine, Exe, CreateTime
FROM pslist()
WHERE NOT IsSystem

-- Find suspicious processes by name pattern
SELECT * FROM pslist() WHERE Name =~ "(?i)(mimikatz|cobalt|beacon|rubeus)"

-- Process with network connections
SELECT * FROM foreach(
  row={ SELECT Pid, Name FROM pslist() },
  query={ SELECT * FROM netstat() WHERE Pid = Pid }
)
```

**File System:**

```sql
-- Recursive file search with YARA
SELECT * FROM glob(globs="C:/Users/*/AppData/**/*.exe")
WHERE Size > 0

-- YARA scanning across paths
SELECT * FROM yara(
  rules="rule test { strings: $a = \"mimikatz\" condition: $a }",
  files="C:/Windows/Temp/**"
)

-- USN Journal parsing (file creation/deletion/rename tracking)
SELECT * FROM usn(device="\\\\.\\C:")
WHERE Reason =~ "FILE_CREATE" AND Filename =~ "\\.exe$"

-- MFT analysis
SELECT * FROM parse_mft(accessor="ntfs", filename="\\\\.\\C:")
WHERE FileName =~ "\\.exe$" AND Created0x10 > "2026-01-01"
```

**Registry:**

```sql
-- Enumerate Run keys (persistence)
SELECT * FROM glob(
  globs="HKEY_LOCAL_MACHINE/SOFTWARE/Microsoft/Windows/CurrentVersion/Run/*",
  accessor="registry"
)

-- All registry persistence locations
LET persistence_keys = (
  "HKEY_LOCAL_MACHINE/SOFTWARE/Microsoft/Windows/CurrentVersion/Run/*",
  "HKEY_CURRENT_USER/SOFTWARE/Microsoft/Windows/CurrentVersion/Run/*",
  "HKEY_LOCAL_MACHINE/SOFTWARE/Microsoft/Windows NT/CurrentVersion/Winlogon",
  "HKEY_LOCAL_MACHINE/SYSTEM/CurrentControlSet/Services/*"
)
SELECT * FROM foreach(
  row=persistence_keys,
  query={ SELECT * FROM glob(globs=_value, accessor="registry") }
)

-- Shimcache entries
SELECT * FROM shimcache()
```

**Event Logs:**

```sql
-- Parse specific EVTX file
SELECT * FROM parse_evtx(
  filename="C:/Windows/System32/winevt/Logs/Security.evtx"
)
WHERE System.EventID.Value = 4624

-- Hunt across all event logs for keyword
SELECT * FROM foreach(
  row={ SELECT FullPath FROM glob(globs="C:/Windows/System32/winevt/Logs/*.evtx") },
  query={
    SELECT *, FullPath FROM parse_evtx(filename=FullPath)
    WHERE EventData.CommandLine =~ "(?i)(mimikatz|invoke-|certutil.*-urlcache)"
  }
)

-- PowerShell ScriptBlock logging (Event ID 4104)
SELECT System.TimeCreated.SystemTime AS Timestamp,
       EventData.ScriptBlockText AS Script,
       System.Computer AS Host
FROM parse_evtx(
  filename="C:/Windows/System32/winevt/Logs/Microsoft-Windows-PowerShell%4Operational.evtx"
)
WHERE System.EventID.Value = 4104
AND EventData.ScriptBlockText =~ "(?i)(invoke-mimikatz|invoke-expression|iex|downloadstring|net.webclient)"

-- RDP authentication tracking
SELECT System.TimeCreated.SystemTime AS Timestamp,
       EventData.TargetUserName AS User,
       EventData.IpAddress AS SourceIP,
       EventData.LogonType AS LogonType
FROM parse_evtx(
  filename="C:/Windows/System32/winevt/Logs/Security.evtx"
)
WHERE System.EventID.Value = 4624
AND EventData.LogonType IN (3, 10)

-- Service installation detection (Event ID 7045)
SELECT System.TimeCreated.SystemTime AS Timestamp,
       EventData.ServiceName AS ServiceName,
       EventData.ImagePath AS ImagePath,
       EventData.ServiceType AS ServiceType
FROM parse_evtx(
  filename="C:/Windows/System32/winevt/Logs/System.evtx"
)
WHERE System.EventID.Value = 7045
```

**Network:**

```sql
-- Active network connections
SELECT * FROM netstat()
WHERE Status = "ESTABLISHED" AND NOT Raddr.IP =~ "^(10\\.|172\\.(1[6-9]|2|3[01])\\.|192\\.168\\.)"

-- DNS cache
SELECT * FROM dns_cache()
```

### 1.3 Velociraptor Artifact Structure

Artifacts are YAML-defined VQL packages. Key built-in artifacts for DFIR:

**Windows Detection Artifacts:**

| Artifact | Purpose |
|----------|---------|
| `Windows.Detection.Amcache` | Application execution history |
| `Windows.Detection.BinaryRename` | Renamed executable detection |
| `Windows.Detection.BinaryHunter` | Suspicious binary identification |
| `Windows.Detection.Impersonation` | Token impersonation |
| `Windows.Detection.Mutants` | Mutex/mutant objects |
| `Windows.Detection.PsexecService` | PsExec lateral movement |
| `Windows.Detection.TemplateInjection` | Office template injection |
| `Windows.Detection.Usn` | USN Journal activity |
| `Windows.Detection.WMIProcessCreation` | WMI-spawned processes |
| `Windows.Detection.Registry` | Registry modification |
| `Windows.Detection.ProcessCreation` | Process creation events |

**Windows EventLog Artifacts:**

| Artifact | Purpose |
|----------|---------|
| `Windows.EventLogs.EvtxHunter` | Keyword search across all EVTX |
| `Windows.EventLogs.Cleared` | Event log clearing detection |
| `Windows.EventLogs.RDPAuth` | RDP authentication events |
| `Windows.EventLogs.PowershellScriptblock` | Script block logging |
| `Windows.EventLogs.PowershellModule` | Module logging |
| `Windows.EventLogs.Kerberoasting` | Kerberos ticket abuse |
| `Windows.EventLogs.ScheduledTasks` | Task creation/modification |
| `Windows.EventLogs.ServiceCreationComspec` | cmd.exe service creation |
| `Windows.EventLogs.AlternateLogon` | Alternate credential logons |
| `Windows.EventLogs.ExplicitLogon` | Explicit credential use |
| `Windows.EventLogs.Modifications` | Log configuration changes |

**Event Queries (Real-Time Monitoring):**

```sql
-- Event queries never terminate — they emit rows when events occur
-- clock() plugin example: one row per second
SELECT Unix FROM clock()

-- Real-time file monitoring
SELECT * FROM watch_monitoring(artifact="Windows.Detection.Usn")
WHERE Filename =~ "\\.exe$"
```

**Custom Artifact Template:**

```yaml
name: Custom.Windows.Detection.SuspiciousService
description: Detect suspicious service installations
author: CIPHER
type: CLIENT
parameters:
  - name: EvtxPath
    default: C:/Windows/System32/winevt/Logs/System.evtx
precondition:
  SELECT OS FROM info() WHERE OS = 'windows'
sources:
  - query: |
      SELECT System.TimeCreated.SystemTime AS Timestamp,
             EventData.ServiceName AS ServiceName,
             EventData.ImagePath AS ImagePath
      FROM parse_evtx(filename=EvtxPath)
      WHERE System.EventID.Value = 7045
      AND ImagePath =~ "(?i)(cmd\\.exe|powershell|rundll32|regsvr32|mshta|wscript|cscript)"
```

---

## 2. Hayabusa — Windows Event Log Timeline Generator

### 2.1 Core Capabilities

- 4000+ Sigma rules + 170+ built-in detection rules
- Full Sigma v2 specification support including correlation rules
- MITRE ATT&CK tactic mapping
- Multi-threaded Rust implementation (5x faster than alternatives)
- Enterprise-wide hunting via Velociraptor integration
- Field normalization, GeoIP/ASN enrichment
- EVTX recovery from slack space

### 2.2 Command Reference

**Timeline Generation:**

```bash
# CSV timeline from local logs
hayabusa csv-timeline -d C:\Windows\System32\winevt\Logs

# JSON timeline (for Elastic/Timesketch ingest)
hayabusa json-timeline -d /path/to/evtx/ -o timeline.jsonl

# Timeline from collected evidence
hayabusa csv-timeline -d /cases/evidence/evtx/ -o /cases/output/timeline.csv

# Filter by minimum alert level
hayabusa csv-timeline -d /path/to/evtx/ -m high -o high_alerts.csv

# Filter by MITRE ATT&CK tactic
hayabusa csv-timeline -d /path/to/evtx/ --tags attack.lateral_movement

# Timeline with specific output profile
hayabusa csv-timeline -d /path/to/evtx/ -p verbose -o verbose_timeline.csv
```

**Analysis Commands:**

```bash
# Computer metrics — which hosts have the most events
hayabusa computer-metrics -d /path/to/evtx/

# Event ID metrics — frequency analysis
hayabusa eid-metrics -d /path/to/evtx/

# Log source metrics
hayabusa log-metrics -d /path/to/evtx/

# Logon summary (successful and failed)
hayabusa logon-summary -d /path/to/evtx/

# Keyword search across logs
hayabusa search -d /path/to/evtx/ -k "mimikatz"
hayabusa search -d /path/to/evtx/ -k "certutil" --regex

# Extract Base64 encoded strings
hayabusa extract-base64 -d /path/to/evtx/

# Pivot keyword extraction (users, IPs, hostnames)
hayabusa pivot-keywords-list -d /path/to/evtx/
```

**Rule Management:**

```bash
# Update Sigma/Hayabusa rules
hayabusa update-rules

# Tune alert levels for critical systems
hayabusa level-tuning -d /path/to/evtx/ -f tuning_config.txt

# List available output profiles
hayabusa list-profiles
```

### 2.3 Output Profiles

| Profile | Use Case |
|---------|----------|
| `minimal` | Quick triage |
| `standard` | Daily analysis (default) |
| `verbose` | Deep investigation |
| `all-field-info` | Complete field data |
| `super-verbose` | Maximum detail |
| `timesketch-minimal` | Timesketch import |
| `timesketch-verbose` | Detailed Timesketch import |

### 2.4 Integration Patterns

```bash
# Hayabusa -> Timeline Explorer (Windows)
hayabusa csv-timeline -d evidence/ -p verbose -o timeline.csv
# Open timeline.csv in Timeline Explorer

# Hayabusa -> Timesketch
hayabusa json-timeline -d evidence/ -p timesketch-verbose -o timeline.jsonl
timesketch_importer -s timeline.jsonl --timeline_name "Case_001"

# Hayabusa -> Elastic Stack
hayabusa json-timeline -d evidence/ -o timeline.jsonl
# Ingest via Filebeat/Logstash

# Hayabusa via Velociraptor (enterprise hunt)
# Deploy as VQL artifact across endpoints
```

---

## 3. Chainsaw — Rapid Forensic Hunting

### 3.1 Core Capabilities

- Sigma rule-based hunting across EVTX files
- Custom Chainsaw detection rules
- Shimcache + Amcache analysis with timeline generation
- SRUM database parsing
- MFT analysis
- Registry hive extraction
- TAU expression engine for ad-hoc queries

### 3.2 Command Reference

**Hunt Mode (Sigma + Custom Rules):**

```bash
# Hunt with Sigma rules
chainsaw hunt /path/to/evtx/ -s sigma/rules/ \
  --mapping mappings/sigma-event-logs-all.yml

# Hunt with custom Chainsaw rules
chainsaw hunt /path/to/evtx/ -r rules/

# Combined Sigma + custom rules with CSV output
chainsaw hunt /path/to/evtx/ \
  -s sigma/rules/ \
  --mapping mappings/sigma-event-logs-all.yml \
  -r rules/ \
  --csv --output results/

# Filter by severity
chainsaw hunt /path/to/evtx/ -s sigma/ \
  --mapping mappings/sigma-event-logs-all.yml \
  --level critical,high

# JSON output with metadata
chainsaw hunt /path/to/evtx/ -r rules/ --json --metadata

# Time-bounded hunt
chainsaw hunt /path/to/evtx/ -r rules/ \
  --from "2026-01-01T00:00:00" --to "2026-03-01T00:00:00"
```

**Search Mode:**

```bash
# String search across EVTX
chainsaw search "mimikatz" -i /path/to/evtx/

# Regex search
chainsaw search -e "(?i)invoke-(mimikatz|expression)" /path/to/evtx/

# TAU expression (field-level queries)
chainsaw search -t 'Event.System.EventID: =4688' /path/to/evtx/
chainsaw search -t 'Event.System.EventID: =7045' /path/to/evtx/

# Search with timestamp filter
chainsaw search "psexec" /path/to/evtx/ \
  --from "2026-01-15T00:00:00" --to "2026-01-16T00:00:00"
```

**Shimcache Analysis:**

```bash
# Basic shimcache analysis
chainsaw analyse shimcache ./SYSTEM

# With Amcache enrichment and timestamp pairing
chainsaw analyse shimcache ./SYSTEM \
  --amcache ./Amcache.hve \
  --tspair \
  --regexfile ./analysis/shimcache_patterns.txt \
  --output shimcache_results.csv

# Regex-based shimcache filtering
chainsaw analyse shimcache ./SYSTEM \
  -e "(?i)(temp|appdata|public)" \
  --output suspicious_shimcache.csv
```

**SRUM Analysis:**

```bash
# Full SRUM database analysis
chainsaw analyse srum --software ./SOFTWARE ./SRUDB.dat \
  --output srum_analysis.json

# SRUM stats only
chainsaw analyse srum --software ./SOFTWARE ./SRUDB.dat --stats-only
```

### 3.3 Built-in Detection Categories

- AV alert extraction (Defender, F-Secure, Sophos, Kaspersky)
- Event log clearing detection
- User account creation and privilege escalation
- Remote login tracking (RDP, network logon, service logon)
- Brute-force attack identification
- Suspicious service installation

### 3.4 Supported Sysmon Event IDs for Sigma Mapping

| Event ID | Category |
|----------|----------|
| 1 | Process creation |
| 3 | Network connection |
| 7 | Image loaded |
| 11 | File creation |
| 13 | Registry value set |
| 4104 | PowerShell script block |
| 4688 | Process creation (Security log) |
| 4698 | Scheduled task created |
| 7045 | Service installed |

---

## 4. KAPE — Evidence Collection Framework

### 4.1 Architecture

KAPE (Kroll Artifact Parser and Extractor) uses two-phase operation:
1. **Targets** (.tkape) — Define WHAT artifacts to collect (file paths, registry hives)
2. **Modules** (.mkape) — Define HOW to process collected artifacts (parsing tools)

### 4.2 Critical Windows Targets

**File System Artifacts:**

| Target | Artifacts Collected |
|--------|-------------------|
| `$MFT` | Master File Table — file metadata, timestamps |
| `$J` | USN Journal — file change tracking |
| `$LogFile` | NTFS transaction log |
| `$Boot` | Boot sector |
| `$SDS` | Security descriptors |
| `$T` | Transaction log files |
| `$Bitmap` | Cluster allocation bitmap |

**Execution Evidence:**

| Target | Artifacts Collected |
|--------|-------------------|
| `Prefetch` | `C:\Windows\Prefetch\*.pf` — execution history |
| `Amcache` | Application compatibility cache |
| `AppCompatPCA` | Program Compatibility Assistant |
| `RecentFileCache` | Recent file execution cache |
| `SRUM` | System Resource Usage Monitor |
| `BAM/DAM` | Background/Desktop Activity Moderator |

**Event Logs:**

| Target | Artifacts Collected |
|--------|-------------------|
| `EventLogs` | All `.evtx` files from winevt/Logs |
| `EventLogs-RDP` | RDP-specific event logs |
| `EventTraceLogs` | ETL trace logs |
| `EventTranscriptDB` | Diagnostic data viewer DB |

**User Activity:**

| Target | Artifacts Collected |
|--------|-------------------|
| `LNKFilesAndJumpLists` | Recent files accessed, program launches |
| `JumpLists` | Taskbar pinned program history |
| `RecentFolders` | Recently accessed folders |
| `RDPCache` | RDP bitmap cache (screen captures) |
| `RDPLogs` | RDP connection logs |
| `WindowsTimeline` | ActivitiesCache.db |
| `ThumbCache` | Thumbnail cache (image evidence) |
| `IconCacheDB` | Icon cache database |
| `StartupFolders` | Startup program locations |

**System Configuration:**

| Target | Artifacts Collected |
|--------|-------------------|
| `ScheduledTasks` | Task Scheduler XML definitions |
| `GroupPolicy` | Group Policy objects |
| `HostsFile` | DNS override file |
| `Drivers` | Installed driver information |
| `WindowsFirewall` | Firewall configuration |
| `BCD` | Boot Configuration Data |
| `BITS` | Background Intelligent Transfer Service |

**Registry Hives:**

Compound targets collect all registry hives:
- `SYSTEM`, `SOFTWARE`, `SAM`, `SECURITY` (machine hives)
- `NTUSER.DAT`, `UsrClass.dat` (per-user hives)
- `Amcache.hve`

**Active Directory:**

| Target | Artifacts Collected |
|--------|-------------------|
| `ActiveDirectoryNTDS` | `ntds.dit` — AD database |
| `ActiveDirectorySysvol` | SYSVOL policies and scripts |

**Application-Specific:**

| Target | Artifacts Collected |
|--------|-------------------|
| `PowerShellTranscripts` | PowerShell transcript logs |
| `USBDevicesLogs` | USB device connection history |
| `WindowsNotificationsDB` | Notification center database |
| `WindowsIndexSearch` | Windows Search index (Windows.edb) |
| `WBEM` | WMI repository (persistence) |

### 4.3 KAPE Command Examples

```bash
# Collect triage artifacts (common IR set)
kape.exe --tsource C: --tdest E:\Evidence\%m \
  --target KapeTriage \
  --vhdx CaseEvidence

# Collect and process with modules
kape.exe --tsource C: --tdest E:\Evidence\%m \
  --target KapeTriage \
  --msource E:\Evidence\%m --mdest E:\Processed\%m \
  --module !EZParser

# Registry hive collection only
kape.exe --tsource C: --tdest E:\Evidence\%m \
  --target RegistryHives

# Event log collection
kape.exe --tsource C: --tdest E:\Evidence\%m \
  --target EventLogs

# Remote collection via network share
kape.exe --tsource \\TARGET\C$ --tdest E:\Evidence\%m \
  --target KapeTriage

# Collect with container (VHDX)
kape.exe --tsource C: --tdest E:\Evidence \
  --target KapeTriage \
  --vhdx Case001_Triage
```

### 4.4 Target File Format (.tkape)

```yaml
Description: Windows Event Logs
Author: Eric Zimmerman
Version: 1.0
Id: 2e3d1f2a-3b4c-4d5e-6f7a-8b9c0d1e2f3a
RecreateDirectories: true
Targets:
  - Name: Event Logs
    Category: EventLogs
    Path: C:\Windows\System32\winevt\Logs\
    FileMask: "*.evtx"
    Recursive: false
    Comment: "Windows Event Logs"
  - Name: Event Logs (legacy)
    Category: EventLogs
    Path: C:\Windows\System32\config\
    FileMask: "*.evt"
    Recursive: false
```

---

## 5. Volatility 3 — Memory Forensics

### 5.1 Core Command Syntax

```bash
# Basic usage
python3 vol.py -f <memory_image> <plugin>

# With output file
python3 vol.py -f memory.dmp -o /output/ <plugin>

# Plugin help
python3 vol.py <plugin> -h

# Specify symbol path
python3 vol.py -s /path/to/symbols -f memory.dmp <plugin>
```

### 5.2 Windows Plugins — Complete Reference

**System Information:**

```bash
vol -f mem.dmp windows.info
# OS version, build, service pack, kernel base, KDBG address
```

**Process Analysis:**

```bash
# List all processes (EPROCESS linked list)
vol -f mem.dmp windows.pslist

# Scan for processes (pool tag scanning — finds hidden/unlinked)
vol -f mem.dmp windows.psscan

# Process tree (parent-child relationships)
vol -f mem.dmp windows.pstree

# Process command lines
vol -f mem.dmp windows.cmdline

# Specific process DLLs
vol -f mem.dmp windows.dlllist --pid 1234

# Process handles (files, registry, mutexes, events)
vol -f mem.dmp windows.handles --pid 1234

# Process environment variables
vol -f mem.dmp windows.envars --pid 1234

# Dump process executable
vol -f mem.dmp windows.dumpfiles --pid 1234

# Process memory map + dump
vol -f mem.dmp windows.memmap --dump --pid 1234
```

**Malware Detection:**

```bash
# Find injected code / hollowed processes (RWX memory regions)
vol -f mem.dmp windows.malfind

# YARA scanning across process memory
vol -f mem.dmp windows.vadyarascan --yara-file rules.yar

# YARA scanning across all memory
vol -f mem.dmp yarascan.yarascan --yara-file rules.yar

# Detect API hooking
vol -f mem.dmp windows.ssdt
```

**Network Analysis:**

```bash
# Network connections and listening ports
vol -f mem.dmp windows.netscan

# Active network statistics
vol -f mem.dmp windows.netstat
```

**Registry Analysis:**

```bash
# List registry hives
vol -f mem.dmp windows.registry.hivelist

# Scan for registry hives
vol -f mem.dmp windows.registry.hivescan

# Print registry key contents
vol -f mem.dmp windows.registry.printkey --key "Software\Microsoft\Windows\CurrentVersion\Run"

# Extract cached credentials
vol -f mem.dmp windows.cachedump

# Extract local password hashes
vol -f mem.dmp windows.hashdump

# Extract LSA secrets
vol -f mem.dmp windows.lsadump
```

**File System:**

```bash
# Scan for file objects
vol -f mem.dmp windows.filescan

# Dump files by virtual or physical address
vol -f mem.dmp windows.dumpfiles --virtaddr 0xfa8001234560
vol -f mem.dmp windows.dumpfiles --physaddr 0x12345678
```

**Kernel & Driver Analysis:**

```bash
# List kernel modules/drivers
vol -f mem.dmp windows.modules

# Scan for modules
vol -f mem.dmp windows.modscan

# System Service Descriptor Table (syscall hooks)
vol -f mem.dmp windows.ssdt

# Driver IRP hooks
vol -f mem.dmp windows.driverscan

# Big pool allocations
vol -f mem.dmp windows.bigpools
```

**Services:**

```bash
# List Windows services
vol -f mem.dmp windows.svcscan

# Service details with binary paths
vol -f mem.dmp windows.getservicesids
```

**Crash Analysis:**

```bash
vol -f mem.dmp windows.crashinfo
```

### 5.3 Linux Plugins

```bash
# Process listing
vol -f mem.lime linux.pslist
vol -f mem.lime linux.pstree

# Bash history (in-memory)
vol -f mem.lime linux.bash

# Detect injected code
vol -f mem.lime linux.malfind

# Network connections
vol -f mem.lime linux.sockstat

# Loaded kernel modules
vol -f mem.lime linux.lsmod

# Mount points
vol -f mem.lime linux.mountinfo

# Open files per process
vol -f mem.lime linux.lsof

# Check for syscall table hooks
vol -f mem.lime linux.check_syscall
```

### 5.4 Memory Acquisition Tools

| Tool | Platform | Command |
|------|----------|---------|
| WinPmem | Windows | `winpmem.exe -o mem.raw --format raw -dd` |
| DumpIt | Windows | `DumpIt.exe /O mem.raw /T RAW` |
| Belkasoft RAM Capturer | Windows | `RamCapture64.exe "mem.mem"` |
| AVML | Linux | `avml mem.lime` |
| LiME | Linux | `insmod lime.ko "path=/tmp/mem.lime format=lime"` |
| Magnet RAM Capture | Windows | GUI-based acquisition |

### 5.5 Triage Workflow

```
1. windows.info          → Confirm OS, validate image
2. windows.pslist        → Baseline processes
3. windows.psscan        → Find hidden/terminated processes
4. windows.pstree        → Identify unusual parent-child chains
5. windows.cmdline       → Check for suspicious command lines
6. windows.netscan       → Active/recent network connections
7. windows.malfind       → Injected code detection
8. windows.dlllist       → Suspicious DLLs loaded by flagged PIDs
9. windows.handles       → Open handles for flagged PIDs
10. windows.filescan     → Find dropped files
11. windows.hashdump     → Check for credential extraction
12. windows.registry.printkey → Persistence mechanisms
```

---

## 6. Windows Event IDs — Detection Reference

### 6.1 Authentication & Logon

| Event ID | Log | Description | Hunting Value |
|----------|-----|-------------|---------------|
| **4624** | Security | Successful logon | Logon type 3 (network), 10 (RDP), 7 (unlock) |
| **4625** | Security | Failed logon | Brute force detection, password spraying |
| **4634** | Security | Logoff | Session duration correlation |
| **4647** | Security | User-initiated logoff | Distinguishes from system logoff |
| **4648** | Security | Explicit credentials logon | Lateral movement (runas, PsExec) |
| **4672** | Security | Special privileges assigned | Privileged logon tracking |
| **4768** | Security | Kerberos TGT requested | AS-REP roasting detection |
| **4769** | Security | Kerberos ST requested | Kerberoasting (RC4 encryption type = 0x17) |
| **4771** | Security | Kerberos pre-auth failed | Password spraying via Kerberos |
| **4776** | Security | NTLM authentication | Pass-the-hash, NTLM relay |

**Logon Type Reference:**

| Type | Description | Threat Relevance |
|------|-------------|-----------------|
| 2 | Interactive (console) | Physical access / RDP (pre-NLA) |
| 3 | Network | SMB, WinRM, PsExec |
| 4 | Batch | Scheduled tasks |
| 5 | Service | Service accounts |
| 7 | Unlock | Screen unlock |
| 8 | NetworkCleartext | IIS basic auth |
| 9 | NewCredentials | RunAs /netonly |
| 10 | RemoteInteractive | RDP |
| 11 | CachedInteractive | Cached domain credentials |

### 6.2 Process Execution

| Event ID | Log | Description | Hunting Value |
|----------|-----|-------------|---------------|
| **4688** | Security | Process creation | Command-line logging (requires audit policy) |
| **4689** | Security | Process termination | Process lifetime correlation |
| **1** | Sysmon | Process creation | Full command line, parent process, hashes |
| **2** | Sysmon | Process changed file creation time | Timestomping detection |
| **6** | Sysmon | Driver loaded | Rootkit / BYOVD detection |
| **7** | Sysmon | Image loaded | DLL side-loading detection |
| **8** | Sysmon | CreateRemoteThread | Process injection |
| **10** | Sysmon | ProcessAccess | LSASS credential dumping (target = lsass.exe) |
| **25** | Sysmon | ProcessTampering | Process hollowing, herpaderping |

### 6.3 Persistence & Lateral Movement

| Event ID | Log | Description | Hunting Value |
|----------|-----|-------------|---------------|
| **7045** | System | Service installed | New service creation (PsExec, malware) |
| **7040** | System | Service startup type changed | Persistence modification |
| **4698** | Security | Scheduled task created | Persistence, lateral movement |
| **4702** | Security | Scheduled task updated | Task modification |
| **4699** | Security | Scheduled task deleted | Anti-forensics |
| **13** | Sysmon | Registry value set | Run key persistence |
| **12** | Sysmon | Registry object created/deleted | Registry modification tracking |
| **14** | Sysmon | Registry key/value rename | Registry evasion |
| **19/20/21** | Sysmon | WMI event filter/consumer/binding | WMI persistence |

### 6.4 Credential Access

| Event ID | Log | Description | Hunting Value |
|----------|-----|-------------|---------------|
| **10** | Sysmon | Process access | GrantedAccess to lsass.exe (0x1010, 0x1FFFFF) |
| **4663** | Security | Object access attempt | File access auditing (SAM, SYSTEM, NTDS.DIT) |
| **4720** | Security | User account created | Backdoor account detection |
| **4722** | Security | User account enabled | Re-enabled dormant accounts |
| **4724** | Security | Password reset attempt | Unauthorized password resets |
| **4728** | Security | Member added to security-enabled global group | Privilege escalation |
| **4732** | Security | Member added to local group | Local admin group modification |
| **4756** | Security | Member added to universal group | Domain-wide privilege escalation |

### 6.5 Defense Evasion & Anti-Forensics

| Event ID | Log | Description | Hunting Value |
|----------|-----|-------------|---------------|
| **1102** | Security | Security log cleared | Anti-forensics |
| **104** | System | System log cleared | Anti-forensics |
| **4104** | PowerShell Operational | Script block logging | Obfuscated PowerShell execution |
| **4103** | PowerShell Operational | Module logging | PowerShell module execution |
| **400/403** | PowerShell | Engine start/stop | PowerShell version downgrade |
| **11** | Sysmon | File created | Malware drop detection |
| **15** | Sysmon | FileCreateStreamHash | ADS (alternate data stream) creation |
| **23** | Sysmon | File delete archived | Deleted file tracking |
| **26** | Sysmon | File delete logged | File deletion events |

### 6.6 Network Activity

| Event ID | Log | Description | Hunting Value |
|----------|-----|-------------|---------------|
| **3** | Sysmon | Network connection | C2 communication detection |
| **22** | Sysmon | DNS query | DNS-based C2, suspicious domains |
| **5156** | Security | Windows Filtering Platform | Firewall connection allowed |
| **5157** | Security | Windows Filtering Platform | Firewall connection blocked |
| **5140** | Security | Network share accessed | Lateral movement via SMB |
| **5145** | Security | Share object access checked | File access on shares |

### 6.7 Detection Correlation Patterns

**Lateral Movement via PsExec:**
```
Source: 4648 (explicit creds) → Target: 4624 Type 3 → Target: 7045 (PSEXESVC service) → Target: 4688/1 (cmd.exe child)
```

**Kerberoasting:**
```
4769 with TicketEncryptionType = 0x17 (RC4) AND ServiceName != krbtgt AND ServiceName not ending in $
```

**DCSync:**
```
4662 with Properties containing {1131f6aa-9c07-11d1-f79f-00c04fc2dcd2} (DS-Replication-Get-Changes-All)
```

**Pass-the-Hash:**
```
4624 with LogonType = 9 (NewCredentials) AND LogonProcessName = seclogo
```

**Golden Ticket:**
```
4769 where TicketOptions = 0x40810000 AND ServiceName = krbtgt
```

---

## 7. IR Playbook Templates

### 7.1 Generic Incident Response Playbook

```
[PHASE 1] TRIAGE (0-15 minutes)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Validate alert — confirm not false positive
2. Determine scope — single host, segment, enterprise
3. Assign severity — P1 (critical), P2 (high), P3 (medium), P4 (low)
4. Notify stakeholders per escalation matrix
5. Begin evidence log (who, what, when, where)

[PHASE 2] CONTAINMENT (15-60 minutes)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Network isolation — quarantine VLAN, EDR network contain, firewall block
2. Preserve volatile evidence BEFORE containment alters state:
   - Memory dump (WinPmem/DumpIt)
   - Network connections (netstat -ano)
   - Running processes (tasklist /v, Get-Process)
   - DNS cache (ipconfig /displaydns)
   - Active sessions (qwinsta, net session)
3. Disable compromised accounts (not delete)
4. Block IOCs at perimeter (IPs, domains, hashes)
5. Revoke compromised credentials

[PHASE 3] EVIDENCE COLLECTION (concurrent with containment)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Memory acquisition → Volatility analysis
2. KAPE triage collection (KapeTriage target)
3. Disk imaging if warranted (FTK Imager, dc3dd)
4. Event log export
5. Network traffic capture (pcap)
6. Cloud logs (Azure AD sign-in, AWS CloudTrail)
7. Document chain of custody for all evidence

[PHASE 4] ANALYSIS
━━━━━━━━━━━━━━━━━━
1. Timeline generation:
   - Hayabusa CSV timeline from EVTX
   - MFT timeline (MFTECmd)
   - Prefetch analysis (PECmd)
   - Shimcache/Amcache (chainsaw analyse)
   - USN Journal ($J) parsing
2. IOC extraction and enrichment
3. Memory analysis (Volatility process/network/malware)
4. Lateral movement mapping
5. Determine initial access vector
6. Establish full attack timeline

[PHASE 5] ERADICATION
━━━━━━━━━━━━━━━━━━━━━
1. Remove attacker persistence (services, tasks, Run keys, WMI subscriptions)
2. Patch exploited vulnerability
3. Remove dropped tools and malware
4. Reset ALL potentially compromised credentials
5. Rebuild compromised systems from known-good images
6. Verify eradication via IOC sweep

[PHASE 6] RECOVERY
━━━━━━━━━━━━━━━━━━
1. Restore services in priority order
2. Monitor restored systems intensively (72+ hours)
3. Verify integrity of restored data
4. Confirm no re-compromise indicators
5. Gradually remove containment controls

[PHASE 7] POST-INCIDENT
━━━━━━━━━━━━━━━━━━━━━━━
1. Complete incident timeline
2. Root cause analysis
3. Detection gap analysis — what should we have caught?
4. New detection rules (Sigma, SIEM queries)
5. Lessons learned meeting
6. Update IR procedures
7. Evidence retention per policy
```

### 7.2 Ransomware Response Playbook

```
[TRIAGE]
- Identify ransomware variant (ransom note, encrypted file extension, hash lookup)
- Determine encryption scope (files, shares, shadow copies)
- Check for data exfiltration indicators BEFORE encryption
- Identify patient zero (first encrypted host)

[IMMEDIATE ACTIONS]
- Disconnect affected systems from network (physical disconnect preferred)
- DO NOT power off encrypted systems (memory contains encryption keys)
- Preserve memory immediately (WinPmem → Volatility analysis for keys)
- Block C2 IPs/domains at firewall
- Disable RDP externally
- Reset Kerberos KRBTGT password (twice, 12 hours apart)

[EVIDENCE PRIORITIES]
1. Memory dumps (encryption keys, process artifacts)
2. Network logs (data exfil evidence)
3. Event logs (lateral movement timeline)
4. Ransom notes (variant identification)
5. Encrypted file samples (decryptor compatibility)

[RECOVERY OPTIONS]
- Check nomoreransom.org for available decryptors
- Restore from offline/immutable backups
- Rebuild from golden images
- Memory key extraction (Volatility + FindCrypt plugin)

[DETECTION RULES TO DEPLOY]
- Mass file rename/modification (Sysmon 11, 23)
- VSS deletion: vssadmin delete shadows (4688)
- BCDEdit boot config changes (4688)
- Unusual SMB file access patterns (5145)
- Service installation from temp directories (7045)
```

### 7.3 Credential Theft Response Playbook

```
[TRIAGE]
- Identify type: LSASS dump, DCSync, Kerberoasting, credential file theft
- Determine scope: single host, domain-wide

[INDICATORS]
- LSASS access: Sysmon 10 targeting lsass.exe with GrantedAccess 0x1010/0x1FFFFF
- DCSync: Event 4662 with DS-Replication-Get-Changes GUID
- Kerberoasting: Event 4769 with RC4 encryption (0x17)
- Credential file theft: Access to SAM/SYSTEM/SECURITY hives or NTDS.DIT

[CONTAINMENT]
1. Isolate compromised host
2. Disable compromised accounts
3. Force password reset for ALL accounts the compromised user could access
4. If DCSync confirmed:
   - Reset KRBTGT twice (12 hours apart)
   - Reset all service account passwords
   - Reset all privileged account passwords

[ANALYSIS]
- Map all logon sessions from compromised credentials (4624/4648)
- Identify all hosts accessed (lateral movement)
- Check for persistence mechanisms on each accessed host
- Look for Golden/Silver ticket indicators
```

### 7.4 Web Application Compromise Playbook

```
[TRIAGE]
- Identify exploitation method (SQLi, RCE, deserialization, SSRF)
- Check web server access/error logs for exploit attempts
- Identify webshell/backdoor placement

[EVIDENCE COLLECTION]
- Web server access logs (IIS: W3SVC, Apache: access.log)
- Application logs
- File system changes (MFT timeline around compromise time)
- Process execution from web server process (w3wp.exe, httpd, java)
- Network connections from web server (C2 callbacks)

[HUNTING QUERIES]
- Processes spawned by web server process (Sysmon 1: ParentImage = w3wp.exe)
- Webshell file creation in web roots (Sysmon 11)
- Network connections from web server PID (Sysmon 3)
- POST requests to unusual file extensions (.aspx, .jsp, .php in unusual paths)

[CONTAINMENT]
- WAF block on exploit pattern
- Patch vulnerability
- Remove webshells
- Rotate application secrets/API keys
- Rotate database credentials
```

---

## 8. LogonTracer — Windows Logon Analysis

### 8.1 Overview

LogonTracer visualizes Windows Active Directory logon events as network graphs, connecting hostnames/IPs with account names to identify suspicious authentication patterns.

### 8.2 Processed Event IDs

| Event ID | Type |
|----------|------|
| 4624 | Successful logon |
| 4625 | Failed logon |
| 4768 | Kerberos TGT request |
| 4769 | Kerberos service ticket |
| 4776 | NTLM authentication |
| 4672 | Special privilege assignment |

### 8.3 Analysis Techniques

- **PageRank algorithm** — Identifies critical nodes (high-centrality accounts/hosts)
- **Hidden Markov models** — Behavioral anomaly detection
- **ChangeFinder** — Time-series anomaly detection for logon patterns

### 8.4 Usage

```bash
# Docker deployment
docker run -p 8080:8080 -p 7474:7474 -p 7687:7687 jpcertcc/logontracer

# Import EVTX files
python logontracer.py -e Security.evtx -d neo4j_database

# Web interface at http://localhost:8080
# Search by account, host, or time range
# Graph view shows logon relationships
# Timeline view shows event chronology with anomaly scoring
```

---

## 9. APT-Hunter — Windows Event Log APT Detection

### 9.1 Overview

Python3-based tool for detecting APT activity in Windows event logs using statistical anomaly detection, Sigma rules, and custom hunting patterns.

### 9.2 Command Reference

```bash
# Full analysis with all reports
python3 APT-Hunter.py -p /path/to/logs/ -o ProjectName -allreport

# Time-bounded analysis
python3 APT-Hunter.py -p /logs/ -o Project1 -start 2026-01-01 -end 2026-01-15T20:00

# Keyword hunting
python3 APT-Hunter.py -hunt "psexec" -p /logs/ -o Project2
python3 APT-Hunter.py -huntfile "patterns.txt" -p /logs/ -o Project2

# Sigma rule-based detection
python3 APT-Hunter.py -sigma -rules rules.json -p /logs/ -o Project2
```

### 9.3 Output Types

- Excel reports — comprehensive event summaries
- CSV files — timeline-compatible for Timesketch
- Parsed logon events — user, IP, timestamp, workstation
- Process execution reports — command-line context
- SID collection — user account identification
- Frequency analysis — EventID statistical breakdown

### 9.4 Detection Methods

- Statistical abnormality analysis in event frequency
- Lateral movement indicator tracking
- Credential compromise signal monitoring
- Command execution anomaly identification
- Cross-log correlation for attack chain reconstruction

---

## 10. DFIR Tool Ecosystem Reference

### 10.1 Evidence Collection Tools

| Tool | Platform | Purpose |
|------|----------|---------|
| **KAPE** | Windows | Automated artifact collection + processing |
| **CyLR** | Windows | NTFS forensic collection |
| **UAC** | Unix-like | Unix artifact collector |
| **ir-rescue** | Cross-platform | Automated host forensic data collection |
| **Acquire** | Cross-platform | Rapid forensic artifact gathering |
| **artifactcollector** | Cross-platform | Automated collection |
| **bulk_extractor** | Cross-platform | Disk scanning bypassing filesystem |
| **CDQR** | Cross-platform | Fast disk image analysis |
| **Live Response Collection** | Cross-platform | Volatile data collection |

### 10.2 Timeline Analysis Tools

| Tool | Purpose |
|------|---------|
| **Hayabusa** | EVTX → CSV/JSON timeline with Sigma detection |
| **Chainsaw** | EVTX hunting + shimcache timeline |
| **Plaso/log2timeline** | Super timeline from multiple artifact types |
| **Timeline Explorer** | Interactive CSV timeline viewer |
| **Timesketch** | Collaborative timeline analysis platform |

### 10.3 Log Analysis Tools

| Tool | Purpose |
|------|---------|
| **APT-Hunter** | APT detection in Windows event logs |
| **LogonTracer** | Windows logon event visualization |
| **WELA** | Windows Event Log Analyzer |
| **Zircolite** | Sigma-based detection on EVTX/JSON |
| **Sigma** | Generic signature format for SIEM systems |
| **SysmonSearch** | Windows event log aggregation |
| **AppCompatProcessor** | AppCompat/AmCache analysis |

### 10.4 Memory Forensics Tools

| Tool | Purpose |
|------|---------|
| **Volatility 3** | Memory extraction and analysis framework |
| **MemProcFS** | Virtual filesystem for physical memory |
| **Rekall** | Digital artifact extraction from RAM |
| **AVML** | Linux volatile memory acquisition |
| **LiME** | Linux kernel module for memory acquisition |
| **WinPmem** | Windows memory acquisition |
| **MalConfScan** | Volatility plugin for malware config extraction |

### 10.5 Disk Forensics Tools

| Tool | Purpose |
|------|---------|
| **Autopsy / Sleuth Kit** | Disk analysis and forensics |
| **FTK Imager** | Forensic preview and imaging |
| **X-Ways Forensics** | Disk cloning, imaging, analysis |
| **Guymager** | Linux forensic imager |
| **Dissect** | Multi-format digital forensics framework |

### 10.6 All-in-One Platforms

| Tool | Purpose |
|------|---------|
| **Velociraptor** | Endpoint visibility, VQL hunting, artifact collection |
| **GRR Rapid Response** | Remote live forensics |
| **TheHive** | Incident response platform |
| **IRIS** | Web collaborative IR platform |
| **osquery** | SQL-based endpoint querying |
| **Fleetdm** | osquery fleet management |
| **CimSweep** | CIM/WMI-based IR across Windows |
| **Security Onion** | Network security monitoring distribution |

### 10.7 Adversary Emulation Tools

| Tool | Purpose |
|------|---------|
| **Atomic Red Team** | MITRE ATT&CK-aligned detection tests |
| **Caldera** | Automated adversary emulation |
| **APTSimulator** | Compromised system appearance simulation |
| **Red Team Automation (RTA)** | Blue team detection testing |

### 10.8 Sandboxing & Reversing

| Tool | Purpose |
|------|---------|
| **Ghidra** | NSA reverse engineering framework |
| **CAPA** | Executable capability detection |
| **CAPEv2** | Malware config extraction sandbox |
| **Cuckoo** | Configurable malware sandbox |
| **Radare2** | Reverse engineering framework |
| **Hybrid-Analysis** | CrowdStrike sandbox service |
| **VirusTotal** | Multi-engine malware detection |

---

## 11. Sigma Rule Categories for Windows Detection

### 11.1 Rule Directory Structure

| Category | Coverage |
|----------|----------|
| `process_creation` | New process launches with command-line parameters |
| `network_connection` | Outbound/inbound network connections |
| `file` | File creation, modification, deletion |
| `registry` | Registry modification and access |
| `powershell` | PowerShell execution and script logging |
| `image_load` | DLL and executable loading |
| `process_access` | Inter-process memory access |
| `driver_load` | Kernel driver loading |
| `pipe_created` | Named pipe creation (C2, lateral movement) |
| `create_remote_thread` | Remote thread creation (injection) |
| `create_stream_hash` | Alternate data stream creation |
| `dns_query` | DNS query monitoring |
| `wmi_event` | WMI activity monitoring |
| `process_tampering` | Process manipulation detection |
| `raw_access_thread` | Direct disk access bypass |
| `sysmon` | Sysmon-specific event detection |

### 11.2 Sigma Rule Example for Service Installation

```yaml
title: Suspicious Service Installation via sc.exe
id: a1b2c3d4-e5f6-7890-abcd-ef1234567890
status: experimental
description: Detects suspicious service creation using sc.exe with command execution in image path
logsource:
  category: process_creation
  product: windows
detection:
  selection:
    Image|endswith: '\sc.exe'
    CommandLine|contains|all:
      - 'create'
      - 'binpath='
  filter_legitimate:
    CommandLine|contains:
      - 'C:\Program Files'
      - 'C:\Windows\System32'
  condition: selection and not filter_legitimate
falsepositives:
  - Legitimate software installation scripts
  - System administrators creating custom services
level: high
tags:
  - attack.persistence
  - attack.t1543.003
  - attack.privilege_escalation
```

### 11.3 Sigma Conversion Commands

```bash
# Convert to Splunk SPL
sigma convert -t splunk -p splunk_cim rule.yml

# Convert to Elastic/ECS
sigma convert -t elasticsearch -p ecs_windows rule.yml

# Convert to Microsoft Sentinel KQL
sigma convert -t microsoft365defender rule.yml

# Convert to QRadar AQL
sigma convert -t qradar rule.yml

# Batch convert directory
sigma convert -t splunk -p splunk_cim rules/windows/process_creation/
```

---

## 12. DFIR Report Case Study — Apache ActiveMQ → LockBit Ransomware

### 12.1 Attack Timeline

- **Day 0**: CVE-2023-46604 exploitation on internet-facing ActiveMQ server
  - OpenWire protocol ClassPathXmlApplicationContext class abuse
  - Java process executes CertUtil to download Metasploit stager to `%TEMP%`
- **Day 0-1**: Privilege escalation via `getsystem`, LSASS memory dumping, lateral movement
- **Day 2**: Discovery commands executed; attacker loses access
- **Day 18**: Re-exploitation of same unpatched CVE
  - AnyDesk installation for persistent access
  - Advanced IP Scanner for network recon
  - SMB-based lateral movement to domain controllers
- **Day 18 (90 min before impact)**: LockBit ransomware deployment across file/backup servers
- **TTR**: 419 hours total; 90 minutes from re-access to encryption

### 12.2 Key Forensic Artifacts Found

**Process Execution (Sysmon Event ID 1):**
- Java spawning CertUtil for downloads
- Metasploit stager execution from %TEMP%
- Service creation for privilege escalation (`kesknq` service)

**Credential Access (Sysmon Event ID 10):**
- LSASS process access with GrantedAccess `0x1010` (VMRead)
- CallTrace containing "UNKNOWN" values (injected code indicator)

**Persistence (Event ID 7045):**
- AnyDesk service with AutoStart configuration
- Suspicious services created from injected Winlogon processes

**Network (Sysmon Event ID 3):**
- C2 to `166.62.100[.]52:2460` (Metasploit)
- AnyDesk from same IP on port 6761
- SMB scanning from beachhead to internal network

**Anti-Forensics (Event IDs 104, 1102):**
- Event log clearing by attacker

### 12.3 Applicable Detection Rules

**Network (Suricata/ET):**
- `ET EXPLOIT Apache ActiveMQ Remote Code Execution Attempt (CVE-2023-46604)`
- `ET POLICY SMB Executable File Transfer`
- `ET INFO Executable Download from dotted-quad Host`
- `ET POLICY SSL/TLS Certificate Observed (AnyDesk)`
- `ET MALWARE Possible Metasploit Payload Common Construct Bind_API`

**Host (Sigma):**
- `61a7697c`: Potential CobaltStrike Service Installations
- `178e615d`: Elevated System Shell Spawned
- `d75d6b6b`: Suspicious SYSTEM User Process Creation
- `b52e84a3`: Remote Access Tool - AnyDesk Execution
- `4d07b1f4`: DNS Query To Remote Access Software Domain

### 12.4 MITRE ATT&CK Mapping

| Tactic | Technique | Detail |
|--------|-----------|--------|
| Initial Access | T1190 | CVE-2023-46604 exploitation |
| Execution | T1059 | PowerShell obfuscation |
| Persistence | T1547 | AnyDesk service AutoStart |
| Credential Access | T1003 | LSASS memory dumping |
| Discovery | T1135 | Network share discovery (SMB scan) |
| Lateral Movement | T1021.001 | RDP |
| Lateral Movement | T1021.002 | SMB/Windows Admin Shares |
| Defense Evasion | T1070 | Log clearing |
| Command & Control | T1105 | CertUtil tool transfer |
| Impact | T1486 | Data encrypted (LockBit) |

---

## 13. Windows Forensic Artifact Locations

### 13.1 Execution Artifacts

| Artifact | Path | Tool |
|----------|------|------|
| Prefetch | `C:\Windows\Prefetch\*.pf` | PECmd |
| Amcache | `C:\Windows\AppCompat\Programs\Amcache.hve` | AmcacheParser |
| Shimcache | `SYSTEM\CurrentControlSet\Control\Session Manager\AppCompatCache` | ShimCacheParser, Chainsaw |
| BAM/DAM | `SYSTEM\CurrentControlSet\Services\bam\State\UserSettings` | Registry Explorer |
| SRUM | `C:\Windows\System32\SRU\SRUDB.dat` | SrumECmd, Chainsaw |
| RecentFileCache | `C:\Windows\AppCompat\Programs\RecentFileCache.bcf` | RecentFileCacheParse |
| UserAssist | `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist` | Registry Explorer |
| Last-Visited MRU | `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\LastVisitedPidlMRU` | Registry Explorer |

### 13.2 Persistence Locations

**Registry Run Keys:**
```
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunServices
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunServicesOnce
```

**Winlogon:**
```
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Shell
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Userinit
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify
```

**Image File Execution Options (IFEO):**
```
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\<exe>\Debugger
```

**Services:**
```
HKLM\SYSTEM\CurrentControlSet\Services\<ServiceName>\ImagePath
HKLM\SYSTEM\CurrentControlSet\Services\<ServiceName>\Start (2=Auto, 3=Manual, 4=Disabled)
```

**Scheduled Tasks:**
```
C:\Windows\System32\Tasks\
C:\Windows\SysWOW64\Tasks\
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks
```

**Startup Folders:**
```
C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\
C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\
```

**WMI Persistence:**
```
C:\Windows\System32\wbem\Repository\
OBJECTS.DATA — contains event filters, consumers, bindings
```

**COM Hijacking:**
```
HKCU\Software\Classes\CLSID\
HKLM\Software\Classes\CLSID\
```

### 13.3 File System Artifacts

| Artifact | Path | Purpose |
|----------|------|---------|
| MFT | `C:\$MFT` | File metadata, timestamps |
| USN Journal | `C:\$Extend\$UsnJrnl:$J` | File change tracking |
| $LogFile | `C:\$LogFile` | NTFS transaction log |
| Pagefile | `C:\pagefile.sys` | Virtual memory (may contain process data) |
| Hibernation | `C:\hiberfil.sys` | Hibernate state (memory at sleep time) |
| Swapfile | `C:\swapfile.sys` | Store app memory |

### 13.4 User Activity Artifacts

| Artifact | Path |
|----------|------|
| LNK files | `C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Recent\` |
| Jump Lists | `C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Recent\AutomaticDestinations\` |
| Shellbags | `NTUSER.DAT\Software\Microsoft\Windows\Shell\BagMRU` / `Bags` |
| TypedPaths | `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\TypedPaths` |
| MRU Lists | `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs` |
| WordWheelQuery | `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\WordWheelQuery` |
| Timeline | `C:\Users\<user>\AppData\Local\ConnectedDevicesPlatform\<id>\ActivitiesCache.db` |

### 13.5 Network Artifacts

| Artifact | Path/Registry |
|----------|---------------|
| Network profiles | `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles` |
| Network signatures | `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures` |
| WLAN profiles | `C:\ProgramData\Microsoft\Wlansvc\Profiles\` |
| DNS cache | `ipconfig /displaydns` (volatile) |
| ARP cache | `arp -a` (volatile) |

### 13.6 Browser Artifacts

| Browser | History Path |
|---------|-------------|
| Chrome | `C:\Users\<user>\AppData\Local\Google\Chrome\User Data\Default\History` |
| Firefox | `C:\Users\<user>\AppData\Roaming\Mozilla\Firefox\Profiles\<profile>\places.sqlite` |
| Edge | `C:\Users\<user>\AppData\Local\Microsoft\Edge\User Data\Default\History` |

### 13.7 RDP Artifacts

| Artifact | Location |
|----------|----------|
| RDP bitmap cache | `C:\Users\<user>\AppData\Local\Microsoft\Terminal Server Client\Cache\` |
| Default.rdp | `C:\Users\<user>\Documents\Default.rdp` |
| RDP MRU | `NTUSER.DAT\Software\Microsoft\Terminal Server Client\Servers` |
| RDP connection logs | Event IDs 1149 (TerminalServices-RemoteConnectionManager), 21/22/25 (TerminalServices-LocalSessionManager) |

---

## 14. Live Response Commands

### 14.1 Windows Triage Commands

```powershell
# === SYSTEM INFO ===
systeminfo
hostname
whoami /all

# === PROCESSES ===
tasklist /v /fo csv
Get-Process | Select-Object Name, Id, Path, Company, StartTime | Sort-Object StartTime -Descending
wmic process list full
Get-WmiObject Win32_Process | Select Name, ProcessId, ExecutablePath, CommandLine, ParentProcessId

# === NETWORK ===
netstat -ano
Get-NetTCPConnection -State Established | Select RemoteAddress, RemotePort, OwningProcess
ipconfig /displaydns
arp -a
route print
netsh wlan show profiles

# === SERVICES ===
sc query state=all
Get-Service | Where-Object {$_.Status -eq "Running"}
Get-WmiObject win32_service | Select Name, PathName, StartMode, State

# === PERSISTENCE ===
# Scheduled tasks
schtasks /query /fo csv /v
Get-ScheduledTask | Where-Object {$_.State -eq "Ready"} | Select TaskName, TaskPath

# Run keys
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"

# Services (unusual paths)
Get-WmiObject win32_service | Where-Object {$_.PathName -notmatch "System32|Program Files"} | Select Name, PathName

# WMI subscriptions
Get-WmiObject -Namespace root\subscription -Class __EventFilter
Get-WmiObject -Namespace root\subscription -Class __FilterToConsumerBinding
Get-WmiObject -Namespace root\subscription -Class CommandLineEventConsumer

# Startup folders
dir "C:\Users\*\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\"
dir "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\"

# === USERS & SESSIONS ===
net user
net localgroup administrators
qwinsta
net session
net use

# === FIREWALL ===
netsh advfirewall show allprofiles
Get-NetFirewallRule -Direction Inbound -Enabled True | Get-NetFirewallPortFilter

# === RECENT FILES ===
dir C:\Users\*\AppData\Roaming\Microsoft\Windows\Recent\ /s /b

# === ALTERNATE DATA STREAMS ===
Get-Item -Path C:\Users\*\Downloads\* -Stream * | Where-Object {$_.Stream -ne ':$DATA'}

# === PREFETCH ===
dir C:\Windows\Prefetch\ /b /od

# === DNS CACHE ===
Get-DnsClientCache | Select-Object Entry, RecordName, Data
```

### 14.2 Linux Triage Commands

```bash
# === SYSTEM INFO ===
uname -a
cat /etc/os-release
uptime
last -Faiwx

# === PROCESSES ===
ps auxwwf
ls -la /proc/*/exe 2>/dev/null
ls -la /proc/*/cwd 2>/dev/null
cat /proc/*/cmdline 2>/dev/null | tr '\0' ' '

# === NETWORK ===
ss -tulpn
netstat -tulpn
ip a
ip route
cat /etc/resolv.conf
iptables -L -n -v

# === PERSISTENCE ===
# Cron
crontab -l
ls -la /etc/cron*/
cat /var/spool/cron/crontabs/*

# Systemd
systemctl list-unit-files --type=service --state=enabled
ls -la /etc/systemd/system/
ls -la /usr/lib/systemd/system/

# Init
ls -la /etc/init.d/
cat /etc/rc.local

# Shell configs
cat /etc/profile
cat /etc/bash.bashrc
cat ~/.bashrc ~/.bash_profile ~/.profile

# SSH authorized keys
find / -name authorized_keys 2>/dev/null
cat /home/*/.ssh/authorized_keys

# LD_PRELOAD
cat /etc/ld.so.preload
env | grep LD_

# === USERS ===
cat /etc/passwd
cat /etc/shadow
cat /etc/group
w
who

# === LOGS ===
journalctl --since "1 hour ago"
tail -100 /var/log/auth.log
tail -100 /var/log/syslog
tail -100 /var/log/secure

# === FILE CHANGES (last 24 hours) ===
find / -mtime -1 -type f 2>/dev/null | head -200
find / -ctime -1 -type f 2>/dev/null | head -200

# === OPEN FILES ===
lsof -i -P -n
lsof +L1  # Deleted but open files
```

---

## 15. Eric Zimmerman Tools — Artifact Processing

Key command-line tools from Eric Zimmerman's suite (used by KAPE modules):

| Tool | Purpose | Example |
|------|---------|---------|
| **MFTECmd** | MFT parsing | `MFTECmd.exe -f C:\$MFT --csv output/ --csvf mft.csv` |
| **PECmd** | Prefetch parsing | `PECmd.exe -d C:\Windows\Prefetch --csv output/` |
| **AmcacheParser** | Amcache analysis | `AmcacheParser.exe -f Amcache.hve --csv output/` |
| **AppCompatCacheParser** | Shimcache analysis | `AppCompatCacheParser.exe -f SYSTEM --csv output/` |
| **ShellBagsExplorer** | Shellbags analysis | GUI-based shellbag exploration |
| **Registry Explorer** | Registry analysis | GUI-based registry hive analysis |
| **RECmd** | Registry command-line | `RECmd.exe -d registry_hives/ --bn BatchExamples\BasicBatch.reb --csv output/` |
| **LECmd** | LNK file parsing | `LECmd.exe -d "Recent" --csv output/` |
| **JLECmd** | Jump list parsing | `JLECmd.exe -d AutomaticDestinations --csv output/` |
| **SrumECmd** | SRUM database parsing | `SrumECmd.exe -f SRUDB.dat -r SOFTWARE --csv output/` |
| **EvtxECmd** | Event log parsing | `EvtxECmd.exe -d evtx_logs/ --csv output/` |
| **Timeline Explorer** | CSV timeline viewer | GUI for viewing timeline CSVs |
| **SDBExplorer** | SDB (shim DB) analysis | `SDBExplorer.exe -f custom.sdb` |
| **bstrings** | String extraction | `bstrings.exe -f suspicious.exe -o strings.txt` |
| **iisGeoLocate** | IIS log geo-enrichment | `iisGeoLocate.exe -d iis_logs/ --csv output/` |

---

## 16. Detection Engineering — Key Hunting Queries

### 16.1 LSASS Credential Dumping

**Sysmon (Event ID 10):**
```
EventID = 10
AND TargetImage ENDS WITH "lsass.exe"
AND GrantedAccess IN (0x1010, 0x1038, 0x1FFFFF, 0x01000000)
AND SourceImage NOT IN (
  "C:\Windows\System32\svchost.exe",
  "C:\Windows\System32\lsm.exe",
  "C:\Program Files\*\MsMpEng.exe"
)
```

### 16.2 Suspicious PowerShell Execution

**Event ID 4104 (Script Block Logging):**
```
EventID = 4104
AND ScriptBlockText MATCHES (
  "(?i)(invoke-mimikatz|invoke-expression|iex|downloadstring|
  net\.webclient|start-bitstransfer|invoke-webrequest|
  reflection\.assembly|frombase64string|
  [convert]::frombase64|gzipstream|deflatestream|
  invoke-shellcode|invoke-dllinjection|
  get-keystrokes|get-timezoneinfo|
  invoke-portscan|new-object.*io\.compression)"
)
```

### 16.3 Lateral Movement via WinRM

**Event ID 4624 + 4688:**
```
EventID = 4624 AND LogonType = 3 AND AuthenticationPackageName = "Negotiate"
FOLLOWED BY
EventID = 4688 AND ParentProcessName ENDS WITH "wsmprovhost.exe"
```

### 16.4 Service Installation from Suspicious Path

**Event ID 7045:**
```
EventID = 7045
AND ImagePath MATCHES "(?i)(\\temp\\|\\tmp\\|\\appdata\\|\\public\\|cmd\.exe|powershell|
  \\users\\.*\\downloads\\|%COMSPEC%|/c |/k )"
```

### 16.5 Scheduled Task Persistence

**Event ID 4698:**
```
EventID = 4698
AND TaskContent MATCHES "(?i)(cmd\.exe|powershell|mshta|wscript|cscript|
  rundll32|regsvr32|certutil|bitsadmin)"
```

### 16.6 RDP Lateral Movement Correlation

```
Source Host: 4648 (explicit credentials used)
  → Target Host: 1149 (TerminalServices-RemoteConnectionManager: network connection)
  → Target Host: 21 (TerminalServices-LocalSessionManager: session logon)
  → Target Host: 22 (TerminalServices-LocalSessionManager: shell start)
  → Target Host: 4624 Type 10 (Security: successful RDP logon)
```

### 16.7 DCSync Detection

**Event ID 4662:**
```
EventID = 4662
AND Properties CONTAINS "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2"  -- DS-Replication-Get-Changes
AND Properties CONTAINS "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2"  -- DS-Replication-Get-Changes-All
AND SubjectUserName NOT ENDS WITH "$"  -- Not a domain controller machine account
```

### 16.8 WMI Persistence Detection

**Sysmon Events 19/20/21:**
```
EventID IN (19, 20, 21)
-- 19: WmiEventFilter activity detected
-- 20: WmiEventConsumer activity detected
-- 21: WmiEventConsumerToFilter activity detected

HUNT FOR:
  Consumer.CommandLineTemplate containing "cmd", "powershell", "wscript", "cscript", "mshta"
```

---

## 17. IR Workflow Integration

### 17.1 Complete DFIR Pipeline

```
[ACQUISITION]
KAPE (target collection) → Evidence drive
    ↓
WinPmem/DumpIt → Memory image
    ↓
[PROCESSING]
Volatility 3 → Memory analysis report
Hayabusa → Event log timeline (CSV/JSON)
Chainsaw → Sigma hunt results + shimcache timeline
Eric Zimmerman tools → Artifact parsing
    ↓
[ANALYSIS]
Timeline Explorer → Manual timeline review
LogonTracer → Authentication pattern visualization
APT-Hunter → APT indicator detection
Plaso/log2timeline → Super timeline
    ↓
[DETECTION ENGINEERING]
Sigma rules → New detection rules from findings
Velociraptor hunts → Enterprise-wide IOC sweep
    ↓
[REPORTING]
Attack timeline diagram
MITRE ATT&CK mapping
IOC list (hashes, IPs, domains, file paths)
Detection gap analysis
Recommendations
```

### 17.2 Evidence Processing Cheat Sheet

```bash
# 1. Memory analysis
vol -f mem.dmp windows.info
vol -f mem.dmp windows.pstree
vol -f mem.dmp windows.netscan
vol -f mem.dmp windows.malfind
vol -f mem.dmp windows.cmdline

# 2. Event log timeline
hayabusa csv-timeline -d evidence/evtx/ -p verbose -o timeline.csv
hayabusa logon-summary -d evidence/evtx/
hayabusa search -d evidence/evtx/ -k "mimikatz"

# 3. Sigma hunting
chainsaw hunt evidence/evtx/ -s sigma/rules/ \
  --mapping mappings/sigma-event-logs-all.yml \
  --level high,critical --csv --output hunt_results/

# 4. Shimcache/Amcache analysis
chainsaw analyse shimcache evidence/SYSTEM \
  --amcache evidence/Amcache.hve --tspair -o shimcache.csv

# 5. Artifact parsing (Eric Zimmerman)
MFTECmd.exe -f evidence/$MFT --csv output/ --csvf mft.csv
PECmd.exe -d evidence/Prefetch/ --csv output/
AmcacheParser.exe -f evidence/Amcache.hve --csv output/
AppCompatCacheParser.exe -f evidence/SYSTEM --csv output/
LECmd.exe -d evidence/Recent/ --csv output/
JLECmd.exe -d evidence/AutomaticDestinations/ --csv output/
SrumECmd.exe -f evidence/SRUDB.dat -r evidence/SOFTWARE --csv output/
EvtxECmd.exe -d evidence/evtx/ --csv output/

# 6. APT hunting
python3 APT-Hunter.py -p evidence/evtx/ -o CaseName -allreport

# 7. Super timeline (Plaso)
log2timeline.py --storage-file timeline.plaso evidence/
psort.py -o l2tcsv -w supertimeline.csv timeline.plaso
```

---

## 18. DFIR Linux Distributions

| Distribution | Focus |
|-------------|-------|
| **SANS SIFT Workstation** | Full forensic analysis toolkit (Ubuntu-based) |
| **CAINE** | Computer Aided Investigative Environment (bootable) |
| **PALADIN** | Forensically sound Linux (write-blocking built-in) |
| **Security Onion** | Network security monitoring |
| **NST** | Network Security Toolkit |
| **REMnux** | Malware analysis distribution |
| **Flare VM** | Windows malware analysis (VM overlay) |

---

## 19. IR Community Resources

### 19.1 Key References

| Resource | URL | Content |
|----------|-----|---------|
| The DFIR Report | thedfirreport.com | Real intrusion case studies with TTPs |
| SANS DFIR Blog | sans.org/blog | Cheat sheets, research, tool guides |
| AboutDFIR | aboutdfir.com | Comprehensive DFIR resource compendium |
| ForensicsFocus | forensicfocus.com | Community forums and articles |
| 13Cubed | youtube.com/13Cubed | DFIR tutorial videos |
| MITRE ATT&CK | attack.mitre.org | Adversary TTP framework |

### 19.2 IR Playbook Collections

| Resource | Description |
|----------|-------------|
| AWS IR Runbook Samples | DoS, credential leakage, S3 unauthorized access |
| Counteractive Playbooks | Structured response procedures |
| GuardSight Battle Cards | Response methodology cards |
| IRM (Incident Response Methodologies) | By CERT Societe Generale |
| PagerDuty IR Documentation | Preparation, response, post-incident |
| ThreatHunter-Playbook | Threat hunting methodology |

### 19.3 Windows Event Log References

| Resource | Description |
|----------|-------------|
| Awesome Event IDs | Curated Event ID reference |
| Windows Events Attack Samples | Attack technique → Event ID mapping |
| Malware Archaeology Cheat Sheets | Logging configuration per log source |
| JPCERT LogonTracer | Visual logon event analysis |
