# ICS/SCADA/OT Security — Deep Dive Training Reference

> CIPHER Training Module | Domain: Industrial Control Systems
> Last updated: 2026-03-14
> Classification: `[MODE: RED]` + `[MODE: BLUE]` + `[MODE: ARCHITECT]`

---

## Table of Contents

1. [Purdue Enterprise Reference Architecture](#1-purdue-enterprise-reference-architecture)
2. [ICS Protocol Attack Surfaces](#2-ics-protocol-attack-surfaces)
3. [PLC Exploitation Methodology](#3-plc-exploitation-methodology)
4. [Safety Instrumented System (SIS) Attacks](#4-safety-instrumented-system-sis-attacks)
5. [Notable ICS Incidents](#5-notable-ics-incidents)
6. [MITRE ATT&CK for ICS](#6-mitre-attck-for-ics)
7. [ICS Threat Actor Groups](#7-ics-threat-actor-groups)
8. [ICS Network Segmentation](#8-ics-network-segmentation)
9. [OT Monitoring & Defense Tools](#9-ot-monitoring--defense-tools)
10. [Offensive ICS Tools & Frameworks](#10-offensive-ics-tools--frameworks)
11. [NIST 800-82 / IEC 62443 Frameworks](#11-nist-800-82--iec-62443-frameworks)
12. [ICS Default Credentials & Enumeration](#12-ics-default-credentials--enumeration)
13. [Training Labs & Simulation](#13-training-labs--simulation)
14. [Key References & Resources](#14-key-references--resources)

---

## 1. Purdue Enterprise Reference Architecture

The Purdue Enterprise Reference Architecture (PERA), developed in the early 1990s at Purdue University, is the foundational model for ICS network segmentation. It defines six hierarchical levels separating enterprise IT from operational technology.

**Critical principle**: As you descend the hierarchy (Level 5 to Level 0), devices have increasing access to physical processes but decreasing intrinsic security capabilities.

### Level Definitions

| Level | Name | Systems | Function |
|-------|------|---------|----------|
| **Level 5** | Enterprise Network | Corporate data centers, ERP, email, internet gateway | Business-wide IT services; internet connectivity |
| **Level 4** | Business Planning & Logistics | Business workstations, application servers, databases | Site business systems; production scheduling, supply chain |
| **Level 3.5** | **IT/OT DMZ** | Jump servers, data diodes, historian mirrors, patch servers | Enforces boundary between IT and OT; no direct traffic crosses |
| **Level 3** | Site Operations & Control | Historians, engineering workstations, HMI servers, domain controllers | Plant-wide supervisory; data aggregation, remote access |
| **Level 2** | Area Supervisory Control | HMI panels, SCADA servers, engineering terminals | Process-specific monitoring and operator interface |
| **Level 1** | Basic Control | PLCs, RTUs, DCS controllers, safety controllers (SIS) | Real-time process control; executes ladder logic / function blocks |
| **Level 0** | Physical Process | Sensors, actuators, valves, motors, drives, transmitters | Direct I/O with the physical world |

### Trust Boundaries

```
 LEVEL 5  ──── Enterprise Network (Internet-facing)
     │
 ════╪════  FIREWALL / DMZ (Level 3.5) ════════════
     │       ↑ PRIMARY ENFORCEMENT BOUNDARY (IT/OT)
 LEVEL 4  ──── Business Planning
     │
 LEVEL 3  ──── Site Operations
     │
 ════╪════  SECONDARY ENFORCEMENT BOUNDARY ════════
     │       ↑ Protects control systems from supervisory
 LEVEL 2  ──── Area Supervisory Control
     │
 LEVEL 1  ──── Basic Control (PLCs, RTUs)
     │
 LEVEL 0  ──── Physical Process (sensors, actuators)
```

**Key rules**:
- Block all traffic by default; explicitly permit only required flows
- No direct communication between Level 4+ and Level 2 or below
- All cross-boundary traffic must traverse the DMZ
- Safety systems (SIS) at Level 1 should be on isolated networks
- Internet access restricted to Level 4 and above only

---

## 2. ICS Protocol Attack Surfaces

ICS protocols were designed for reliability in isolated networks, not security. Most lack authentication, encryption, integrity checking, or session management. This is the fundamental architectural weakness of OT environments.

### 2.1 Modbus (TCP/502, Serial RTU/ASCII)

**Overview**: Developed 1979 by Modicon (now Schneider Electric). Most widely deployed ICS protocol globally. Simple master/slave architecture.

**Protocol Characteristics**:
- No authentication whatsoever
- No encryption
- No integrity verification beyond CRC (RTU) or LRC (ASCII)
- Function codes are fully documented and trivially replayed
- Unit ID is the only "addressing" — easily spoofed

**Key Function Codes for Attack**:

| FC | Name | Attack Relevance |
|----|------|-----------------|
| 0x01 | Read Coils | Reconnaissance — read discrete outputs |
| 0x02 | Read Discrete Inputs | Reconnaissance — read input status |
| 0x03 | Read Holding Registers | Reconnaissance — read configuration/setpoints |
| 0x04 | Read Input Registers | Reconnaissance — read process values |
| 0x05 | Write Single Coil | **Control** — toggle individual output |
| 0x06 | Write Single Register | **Control** — modify setpoint/parameter |
| 0x0F | Write Multiple Coils | **Control** — mass output manipulation |
| 0x10 | Write Multiple Registers | **Control** — mass parameter modification |
| 0x2B | Read Device Identification | Fingerprinting — vendor, product, version |
| 0x08 | Diagnostics | Can force listen-only mode (DoS) |

**Attack Vectors**:
- **Man-in-the-Middle**: Intercept and modify register values in transit
- **Replay attacks**: Capture and replay legitimate write commands
- **Unauthorized writes**: Directly write coils/registers (no auth required)
- **Reconnaissance**: Read all registers to map process layout
- **DoS**: Force listen-only mode via diagnostic function code 0x08 sub-function 0x04

**Tools**: `smod` (Modbus pentesting framework), `mbtget`, `pymodbus`, `ModbusPal` (simulator)

### 2.2 DNP3 (TCP/20000, Serial)

**Overview**: Distributed Network Protocol v3. Dominant in North American electric utilities, water/wastewater. Based on IEC 60870-5. Master/outstation architecture.

**Protocol Characteristics**:
- Optional Secure Authentication (SA v5) — rarely deployed in practice
- Complex protocol with multiple layers (data link, transport, application)
- Supports unsolicited responses (outstation-initiated)
- CRC per frame at data link layer (integrity, not security)

**Key Object Groups for Attack**:

| Group | Type | Attack Relevance |
|-------|------|-----------------|
| 1 | Binary Input | Read sensor states |
| 2 | Binary Input Event | Monitor state changes |
| 10 | Binary Output | **Control** — operate switches/breakers |
| 12 | CROB (Control Relay Output Block) | **Control** — direct output command |
| 20 | Counter | Read accumulated values |
| 30 | Analog Input | Read process measurements |
| 40 | Analog Output | **Control** — write setpoints |
| 50 | Time and Date | Time manipulation attacks |
| 70 | File Transfer | Upload/download files to outstations |

**Attack Vectors**:
- **Unauthorized control operations**: Send CROB commands (Group 12) to toggle breakers
- **Data manipulation**: Modify analog outputs to alter process setpoints
- **Time synchronization attacks**: Corrupt event sequencing for forensic evasion
- **File transfer abuse**: Upload malicious configurations via Object Group 70
- **Unsolicited response spoofing**: Inject false data into master systems
- **Warm restart / Cold restart**: Force outstation reboot (Application Control function)

**Tools**: `dnp3-master` (scapy-based), Aegis (DNP3 fuzzer), custom scapy dissectors

### 2.3 OPC UA (TCP/4840)

**Overview**: Open Platform Communications Unified Architecture. Modern replacement for OPC DA/HDA/A&E. Vendor-neutral, cross-platform. Gaining rapid adoption.

**Protocol Characteristics**:
- **Has security model** — supports X.509 certificates, signing, encryption
- Three security modes: None, Sign, SignAndEncrypt
- Discovery service exposes endpoints and security policies
- Complex binary/XML encoding with large attack surface
- Session-based with authentication tokens

**Attack Vectors**:
- **Security Mode "None"**: Many deployments use no security for "compatibility"
- **Certificate trust abuse**: Self-signed certificates accepted without validation
- **Discovery endpoint enumeration**: Anonymous access reveals server topology
- **Denial of Service**: Complex message parsing creates amplification opportunities
- **Session hijacking**: Token reuse if implementation is weak
- **Namespace traversal**: Walk entire object model to map plant architecture
- **Method invocation**: Call server-side methods if access controls are weak

**Critical finding**: Security exists in the protocol spec, but operators frequently disable it. OPC UA in "None" mode is as exposed as Modbus.

### 2.4 S7comm / S7comm-plus (TCP/102)

**Overview**: Siemens proprietary protocol for S7-300/400 (S7comm) and S7-1200/1500 (S7comm-plus). Runs over COTP/TPKT on TCP port 102. Dominates European/global manufacturing.

**Protocol Characteristics**:
- S7comm (legacy): No authentication, no encryption
- S7comm-plus: Challenge-response authentication — but keys have been extracted
- CPU protection levels configurable but often left at defaults
- Rich functionality: read/write memory, start/stop CPU, upload/download programs

**Key Functions for Attack**:

| Function | Attack Relevance |
|----------|-----------------|
| Read SZL (System Status List) | Fingerprint CPU type, firmware, module layout |
| Read/Write Variables | Access/modify process data |
| Upload/Download Blocks | Extract or replace PLC program |
| CPU Start/Stop | Halt process control entirely |
| Set Password | Lock out legitimate engineers |
| Insert/Delete Blocks | Modify controller logic |

**Attack Vectors**:
- **CPU Stop**: Single packet halts the PLC — immediate process disruption
- **Program download**: Replace ladder logic with attacker-controlled program
- **Memory read**: Extract proprietary process data, IP, credentials
- **Password brute force**: 8-byte S7 password with known weak implementation
- **Anti-replay bypass (S7comm-plus)**: Extracted keys enable authentication bypass

**Tools**: `snap7`, `s7scan`, `plcscan`, `s7-brute.py`, Metasploit `siemens_s7` modules, ISF

### 2.5 EtherNet/IP + CIP (TCP/44818, UDP/2222)

**Overview**: Common Industrial Protocol over Ethernet. Rockwell Automation (Allen-Bradley) ecosystem. Dominant in North American discrete manufacturing.

**Protocol Characteristics**:
- CIP is application layer; EtherNet/IP is transport
- No authentication in base protocol
- Implicit (UDP) messaging for real-time I/O
- Explicit (TCP) messaging for configuration
- CIP Safety extension for SIL-rated communications

**Attack Vectors**:
- **Unauthorized configuration changes**: Modify controller attributes via explicit messaging
- **I/O manipulation**: Inject UDP implicit messages to override process I/O
- **Identity enumeration**: ListIdentity command returns vendor, device type, serial number
- **Firmware manipulation**: Upload modified firmware to controllers
- **Reset/crash**: Send malformed CIP messages to trigger controller faults

**Tools**: `enip-enumerate.nse` (Redpoint), `cpppo` (Python CIP library), `pycomm3`

### 2.6 BACnet (UDP/47808)

**Overview**: Building Automation and Control Networks. ASHRAE standard. HVAC, lighting, fire, access control. IP-connected BACnet/IP increasingly common.

**Protocol Characteristics**:
- Designed for building management, not industrial process control
- No built-in authentication or encryption (BACnet/SC adds TLS — rare)
- Who-Is/I-Am broadcast discovery mechanism
- Rich object model exposes building systems

**Attack Vectors**:
- **Who-Is broadcast**: Enumerate all BACnet devices on network segment
- **ReadProperty/WriteProperty**: Read/modify any exposed object (setpoints, schedules)
- **Building takeover**: Modify HVAC, lighting, access control setpoints
- **Physical impact**: Override fire suppression, disable alarms, manipulate temperatures
- **Pivot to IT**: BACnet systems frequently bridge into corporate networks

**Tools**: `BACnet-discover-enumerate.nse` (Redpoint), `bacpypes` (Python), `yabe` (Yet Another BACnet Explorer)

### 2.7 IEC 60870-5-101/104

**Overview**: International standard for telecontrol (SCADA) in power systems. IEC 101 is serial, IEC 104 is TCP/IP (port 2404). Dominant in European/Asian electric utilities.

**Protocol Characteristics**:
- Controlled station / controlling station architecture
- ASDU (Application Service Data Unit) carries process data
- No authentication in base protocol (IEC 62351 adds security — rarely implemented)
- Supports both polling and spontaneous (event-driven) reporting

**Attack Vectors** (exploited by Industroyer):
- **Unauthorized command execution**: Send control commands (single/double point)
- **Information object address (IOA) manipulation**: Toggle circuit breakers
- **Sequence mode attacks**: Iterate through IOA ranges to find controllable points
- **Interrogation command injection**: Force outstations to dump all data
- **Time sync manipulation**: Corrupt event timestamps

### 2.8 IEC 61850 (MMS on TCP/102)

**Overview**: Standard for substation automation. Manufacturing Message Specification (MMS) as transport. Dominates modern substation design.

**Protocol Characteristics**:
- GOOSE (Generic Object Oriented Substation Event) for real-time peer-to-peer
- MMS for client-server communication
- SCL (Substation Configuration Language) in XML
- GOOSE uses Layer 2 multicast — no IP routing, no authentication

**Attack Vectors** (exploited by Industroyer):
- **GOOSE spoofing**: Inject false Layer 2 GOOSE messages to trip breakers
- **MMS enumeration**: Discover logical nodes and data objects
- **SCL file theft**: Map entire substation configuration
- **Replay GOOSE frames**: Re-send captured trip commands

---

## 3. PLC Exploitation Methodology

### 3.1 ICS Kill Chain (SANS ICS)

The ICS Cyber Kill Chain is a two-stage model:

**Stage 1 — IT Network Intrusion** (Mirrors Lockheed Martin kill chain):
1. Reconnaissance — Target selection, OSINT on plant, Shodan scanning
2. Weaponization — Develop ICS-aware payload
3. Delivery — Spearphishing, watering hole, supply chain
4. Exploitation — Compromise IT endpoint
5. Installation — Establish persistence
6. C2 — Command and control channel
7. Actions on IT — Credential harvesting, lateral movement toward OT

**Stage 2 — ICS Attack Development & Execution**:
1. Develop — Study ICS protocols, acquire target PLC firmware/software
2. Test — Replicate target environment (purchase identical PLC hardware)
3. Deliver — Cross IT/OT boundary (jump server, dual-homed historian, USB)
4. Install/Modify — Deploy ICS-specific payload to PLC/RTU/SIS
5. Execute — Trigger manipulation of physical process

### 3.2 PLC Attack Surface Analysis

```
 Engineering Workstation
        │
        │  S7comm / EtherNet/IP / Proprietary
        ▼
 ┌──────────────┐
 │     PLC      │
 │  ┌────────┐  │     Attack Surfaces:
 │  │  CPU   │  │     1. Network protocols (no auth)
 │  ├────────┤  │     2. Firmware (unsigned updates)
 │  │  MEM   │  │     3. Program logic (downloadable)
 │  ├────────┤  │     4. Web server / HTTP interface
 │  │  COM   │  │     5. Debug / diagnostic ports
 │  ├────────┤  │     6. Removable media (SD/CF cards)
 │  │  I/O   │  │     7. Backplane / bus communication
 │  └────────┘  │     8. Default/hardcoded credentials
 └──────┬───────┘
        │
        ▼
 Field Devices (sensors, actuators, VFDs)
```

### 3.3 PLC Exploitation Steps

**Phase 1: Discovery & Enumeration**
```bash
# Nmap ICS scanning with Redpoint scripts
nmap -sV -p 102 --script s7-enumerate.nse <target>
nmap -sV -p 502 --script modbus-discover.nse <target>
nmap -sV -p 44818 --script enip-enumerate.nse <target>
nmap -sV -p 47808 --script BACnet-discover-enumerate.nse <target>
nmap -sV -p 1911 --script fox-info.nse <target>
nmap -sV -p 9600 --script omrontcp-info.nse <target>
nmap -sV -p 1962 --script pcworx-info.nse <target>
nmap -sV -p 20547 --script proconos-info.nse <target>

# Shodan queries for internet-exposed ICS
# port:502 modbus
# port:102 s7
# port:44818 "EtherNet/IP"
# port:47808 bacnet
# port:20000 dnp3
# "Schneider Electric" port:502
# "Siemens" port:102
```

**Phase 2: Protocol Interaction**
```python
# Modbus — read holding registers (pymodbus)
from pymodbus.client import ModbusTcpClient
client = ModbusTcpClient('192.168.1.10', port=502)
client.connect()
result = client.read_holding_registers(0, 100, unit=1)
print(result.registers)  # Process values, setpoints

# S7 — read SZL to fingerprint PLC (snap7)
import snap7
client = snap7.client.Client()
client.connect('192.168.1.20', 0, 1)  # IP, rack, slot
order_code = client.get_order_code()
cpu_info = client.get_cpu_info()
```

**Phase 3: Logic Extraction & Analysis**
- Upload PLC program using engineering protocol
- Decompile ladder logic / structured text / function blocks
- Identify safety-critical logic paths
- Map I/O addresses to physical actuators
- Tools: `ICSREF` (Codesys v2 reverse engineering), `AttkFinder` (static analysis)

**Phase 4: Logic Modification / Process Manipulation**
- **Stuxnet approach**: Inject code into OB1/OB35 to intercept I/O
- **Direct write**: Modify setpoints via Modbus FC 0x06/0x10 or S7 write
- **Program replacement**: Download modified program to PLC
- **Firmware attack**: Flash modified firmware to achieve persistence below OS level

**Phase 5: Evasion & Persistence**
- Replay legitimate process values to HMI (Stuxnet technique: T0856 Spoof Reporting Message)
- Modify alarm thresholds to suppress alerts (T0878 Alarm Suppression)
- Embed payload in PLC firmware for persistence across power cycles (T0857 System Firmware)
- Infect project files on engineering workstations (T0873 Project File Infection)

---

## 4. Safety Instrumented System (SIS) Attacks

### 4.1 SIS Architecture

Safety Instrumented Systems are the last line of defense preventing catastrophic physical events (explosions, toxic releases, equipment destruction). They operate independently from the DCS/SCADA system.

```
 DCS (Process Control)          SIS (Safety System)
 ┌─────────────────┐           ┌─────────────────┐
 │  Control Logic   │           │  Safety Logic    │
 │  (Optimize)      │           │  (Shutdown)      │
 │                  │           │                  │
 │  Setpoints:      │           │  Trip Points:    │
 │  - Temperature   │           │  - High-High T   │
 │  - Pressure      │           │  - High-High P   │
 │  - Flow          │           │  - Emergency Stop │
 └────────┬─────────┘           └────────┬─────────┘
          │                              │
          ▼                              ▼
     Process Equipment ◄──── SIS forces safe shutdown
                              when DCS fails to maintain
                              safe operating envelope
```

**SIS vendors**: Schneider Electric (Triconex), Honeywell (Safety Manager), Yokogawa (ProSafe-RS), Siemens (S7 F-series), ABB (AC 800M HI), HIMA (HIMax/HIQuad)

### 4.2 TRITON/TRISIS — The First SIS Attack (2017)

**[CONFIRMED]** The most significant safety system attack ever documented.

**Target**: Schneider Electric Triconex Tricon MP3008 SIS controllers (firmware <= 10.010.4) at a Middle Eastern petrochemical facility.

**Attribution**: TEMP.Veles / XENOTIME — assessed as linked to Russian Central Scientific Research Institute of Chemistry and Mechanics (TsNIIKhM).

**Attack Chain**:
1. **Initial access**: Compromised IT network, pivoted to OT (Stage 1 of ICS kill chain)
2. **Lateral movement**: Reached SIS engineering workstation on isolated safety network
3. **Payload delivery**: Masqueraded as `trilog.exe` (legitimate Triconex log analysis tool)
4. **Protocol exploitation**: Used TriStation protocol (UDP/1502) to communicate with Tricon controllers
5. **Vulnerability exploitation**: Leveraged unknown firmware vulnerability to gain 2-byte arbitrary write primitive
6. **Privilege escalation**: Acquired supervisor privileges on safety controller
7. **Code injection**: Modified function pointers in firmware; redirected diagnostic command handler to attacker shellcode
8. **Persistence**: Injected code became permanent program table entry, executing every firmware cycle
9. **Anti-forensics**: Disabled RAM/ROM consistency checks; attempted to reset controller on detection

**Payload capabilities**:
- Read/write/execute arbitrary firmware memory
- Reprogram SIS logic to allow unsafe conditions to persist
- Suppress safety shutdowns during hazardous process excursions
- Potential to cause physical destruction, injury, or death

**Why it failed**: A bug in the injected code caused the SIS to trip to a safe state (shutdown), alerting operators. If the code had functioned as designed, it could have disabled safety protections while an attacker simultaneously manipulated the process through the DCS.

**MITRE ATT&CK ICS techniques**: T0889 (Modify Program), T0857 (System Firmware), T0836 (Modify Parameter), T0880 (Loss of Safety), T0837 (Loss of Protection)

**Implications**:
- First known malware designed to attack SIS — crossing the threshold from disruption to potential physical destruction
- Demonstrates nation-state willingness to target human safety systems
- SIS networks can no longer be assumed isolated from cyber threats
- TriStation protocol had no public documentation — attacker reverse-engineered it

---

## 5. Notable ICS Incidents

### 5.1 Stuxnet (2010) — First ICS Weapon

**[CONFIRMED]** First publicly reported malware targeting industrial control systems.

**Target**: Siemens S7-315 and S7-417 PLCs controlling uranium enrichment centrifuges at Natanz, Iran.

**Attribution**: United States (NSA/CIA) and Israel (Unit 8200) joint operation — codenamed "Olympic Games."

**Technical Details**:
- **Target specificity**: Only activated on systems with S7-315 CPU, Profibus CP 342-5 communication module, AND frequency converter drives from Fararo Paya (Tehran) or Vacon (Finland)
- **Centrifuge manipulation**: Modified motor speeds — accelerated centrifuges past structural limits, then decelerated, causing mechanical stress and premature failure
- **PLC infection**: Injected code into OB1 (main cycle) and OB35 (100ms timer interrupt) organization blocks
- **Process spoofing**: Recorded legitimate sensor data during normal operation; replayed it to HMI during manipulation — operators saw normal readings while centrifuges were being destroyed (T0856)
- **I/O interception**: Hooked peripheral I/O functions to intercept and manipulate data between PLC and field devices (T0835)

**Propagation (4 zero-days)**:
- CVE-2010-2568 — LNK file vulnerability (removable media)
- MS10-061 — Print Spooler vulnerability (network spread)
- MS08-067 — Windows Server Service vulnerability (network spread)
- MS10-073 + Task Scheduler vuln — privilege escalation
- Used hardcoded WinCC database credentials for Siemens SCADA access

**Impact**: Estimated 1,000 centrifuges destroyed (of ~5,000 operational). Set Iranian nuclear program back 1-2 years.

**Lessons**:
- Air gaps are insufficient — USB propagation bridged the gap
- Nation-states invest years in developing ICS-specific weapons
- Supply chain and engineering workstation compromise enables OT access
- Process spoofing defeats operator monitoring

### 5.2 BlackEnergy / Ukraine Power Grid Attack (2015)

**[CONFIRMED]** First confirmed cyberattack to cause power outage.

**Attribution**: Sandworm Team (GRU Unit 74455) — also known as ELECTRUM, Voodoo Bear, Seashell Blizzard, APT44.

**Attack Chain**:
1. **Initial access**: Spearphishing emails with malicious Word documents containing BlackEnergy 3 macros
2. **Persistence**: BlackEnergy 3 modular backdoor installed; keylogger and network sniffing plugins
3. **Credential theft**: Harvested VPN credentials for OT network access
4. **Lateral movement**: Used stolen credentials to access SCADA systems (Level 3)
5. **HMI manipulation**: Operators observed mouse cursors moving on HMI screens — attacker directly operating SCADA interface
6. **Breaker operation**: Opened circuit breakers at three Ukrainian distribution companies
7. **KillDisk deployment**: Deployed destructive malware to erase MBR of Windows workstations and corrupt firmware of serial-to-Ethernet converters
8. **Telephony DoS**: Flooded customer service phone lines to prevent outage reporting

**Impact**: ~230,000 customers lost power for 1-6 hours across three power distribution companies (Prykarpattyaoblenergo, Chernivtsioblenergo, Kyivoblenergo).

**MITRE ATT&CK ICS mapping**: T0865 (Spearphishing), T0859 (Valid Accounts), T0823 (GUI), T0809 (Data Destruction), T0814 (DoS)

### 5.3 Industroyer/CrashOverride — Ukraine Power Grid (2016)

**[CONFIRMED]** First malware purpose-built for electric grid disruption.

**Attribution**: Sandworm Team (GRU Unit 74455).

**Target**: Ukrenergo transmission substation — Pivnichna (Northern) substation near Kyiv.

**Technical Architecture — Four Protocol Modules**:

| Module | Protocol | Port | Capability |
|--------|----------|------|------------|
| IEC 104 | IEC 60870-5-104 | 2404 | Three attack modes: range (sweep IOAs), shift (offset IOAs), sequence (iterate); toggle breakers |
| IEC 61850 | MMS/GOOSE | 102 | Enumerate network adapters, discover logical nodes, operate circuit breakers and switches |
| OPC DA | OPC Data Access | 135+ | Discover OPC servers, enumerate items, find control objects (ctlSelOn/ctlOperOn) |
| SIPROTEC DoS | CVE-2015-5374 | 50000 | Crash Siemens SIPROTEC protective relays — render protection functions inoperable |

**Support Components**:
- **Backdoor**: HTTPS-based C2 with Tor fallback
- **Launcher**: Configurable execution with time delays
- **Data wiper**: Targeted ABB PCM600 configuration files; overwrote Windows registry
- **Persistence**: Windows service hijacking; Trojanized Notepad

**Attack Sequence**:
1. Protocol modules enumerate and discover substation equipment
2. IEC 104/61850 modules send unauthorized commands to open circuit breakers
3. SIPROTEC DoS module crashes protective relays (CVE-2015-5374)
4. Data wiper destroys configuration files to delay restoration
5. Result: Breakers open AND protective relays disabled — manual recovery required

**Impact**: ~1 hour power outage in Kyiv area. Designed for much larger impact — the SIPROTEC relay attack aimed to prevent automatic re-closing, forcing manual reconfiguration.

**Why this matters**: Industroyer is a **reusable framework** — its modular architecture can be retargeted to any substation using these standard protocols. It represents weaponized knowledge of power grid operations.

### 5.4 Colonial Pipeline Ransomware (2021)

**[CONFIRMED]** Ransomware attack on IT systems forced precautionary shutdown of OT pipeline operations.

**Attribution**: DarkSide ransomware group.

**Key detail**: The pipeline's OT systems were not directly compromised. Colonial shut down pipeline operations because they could not bill customers — demonstrating that IT/OT interdependencies create OT impact even without OT compromise.

**Impact**: 5,500-mile pipeline (45% of US East Coast fuel supply) shut down for 6 days. Fuel shortages, panic buying, state of emergency declarations.

### 5.5 Oldsmar Water Treatment (2021)

**[CONFIRMED]** Remote access to HMI used to modify chemical dosing.

An attacker accessed the TeamViewer remote desktop on an HMI at Oldsmar, Florida water treatment plant and attempted to increase sodium hydroxide (lye) levels from 100 ppm to 11,100 ppm — a potentially dangerous concentration.

**Key detail**: An operator noticed the mouse moving on the HMI screen and immediately reversed the change. No safety system existed to prevent the modification.

**Lessons**: Remote access tools on HMIs without MFA, without monitoring, and without safety interlocks create trivially exploitable attack paths.

---

## 6. MITRE ATT&CK for ICS

### Complete Tactic-Technique Matrix

The ATT&CK for ICS framework contains **12 tactics** and **79+ techniques** specific to industrial control system environments.

#### TA0108 — Initial Access (12 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0817 | Drive-by Compromise | Engineering workstation browsing |
| T0819 | Exploit Public-Facing Application | Internet-exposed HMI/historian |
| T0866 | Exploitation of Remote Services | RDP, VNC to OT systems |
| T0822 | External Remote Services | VPN, jump servers into OT |
| T0883 | Internet Accessible Device | PLC/RTU directly exposed (Shodan) |
| T0886 | Remote Services | Legitimate remote protocols |
| T0847 | Replication Through Removable Media | USB to air-gapped networks (Stuxnet) |
| T0848 | Rogue Master | Unauthorized SCADA master device |
| T0865 | Spearphishing Attachment | Primary initial access for ICS attacks |
| T0862 | Supply Chain Compromise | Compromised vendor software/firmware |
| T0864 | Transient Cyber Asset | Contractor laptops, portable equipment |
| T0860 | Wireless Compromise | Unsecured wireless in plant environments |

#### TA0104 — Execution (10 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0895 | Autorun Image | Firmware auto-execution on boot |
| T0858 | Change Operating Mode | Switch PLC from RUN to PROGRAM mode |
| T0807 | Command-Line Interface | PowerShell/cmd on engineering workstations |
| T0871 | Execution through API | Vendor APIs for device management |
| T0823 | Graphical User Interface | Direct HMI manipulation (BlackEnergy 2015) |
| T0874 | Hooking | Intercept OS/application calls |
| T0821 | Modify Controller Tasking | Replace PLC program logic (Stuxnet) |
| T0834 | Native API | Windows API calls on HMI/historian |
| T0853 | Scripting | Python/VBS on engineering workstations |
| T0863 | User Execution | Social engineering plant operators |

#### TA0110 — Persistence (6 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0891 | Hardcoded Credentials | Vendor backdoor accounts in firmware |
| T0889 | Modify Program | Persistent code in PLC logic (Stuxnet, TRITON) |
| T0839 | Module Firmware | Firmware-level persistence below OS |
| T0873 | Project File Infection | Infect engineering project files |
| T0857 | System Firmware | Flash modified firmware |
| T0859 | Valid Accounts | Stolen OT credentials |

#### TA0111 — Privilege Escalation (2 techniques)
| ID | Technique |
|----|-----------|
| T0890 | Exploitation for Privilege Escalation |
| T0874 | Hooking |

#### TA0103 — Evasion (7 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0858 | Change Operating Mode | Switch modes to enable write access |
| T0820 | Exploitation for Evasion | Exploit to avoid security controls |
| T0872 | Indicator Removal on Host | Clear logs, timestamps |
| T0849 | Masquerading | trilog.exe masquerade (TRITON) |
| T0851 | Rootkit | OS-level hiding |
| T0856 | Spoof Reporting Message | Replay legitimate data to HMI (Stuxnet) |
| T0894 | System Binary Proxy Execution | LOLBins on Windows OT hosts |

#### TA0102 — Discovery (5 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0840 | Network Connection Enumeration | Map OT network topology |
| T0842 | Network Sniffing | Capture ICS protocol traffic |
| T0846 | Remote System Discovery | Find PLCs, RTUs, HMIs |
| T0888 | Remote System Information Discovery | Fingerprint device type/firmware |
| T0887 | Wireless Sniffing | Capture plant wireless traffic |

#### TA0109 — Lateral Movement (7 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0812 | Default Credentials | ICS default passwords (extremely common) |
| T0866 | Exploitation of Remote Services | Exploit OT remote access |
| T0891 | Hardcoded Credentials | Vendor-embedded credentials |
| T0867 | Lateral Tool Transfer | Move tools to OT hosts |
| T0843 | Program Download | Push programs to PLCs |
| T0886 | Remote Services | RDP/VNC/SSH to OT hosts |
| T0859 | Valid Accounts | Shared OT credentials |

#### TA0100 — Collection (11 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0830 | Adversary-in-the-Middle | Intercept ICS protocol traffic |
| T0802 | Automated Collection | Script mass data harvesting |
| T0811 | Data from Information Repositories | Historian, engineering databases |
| T0893 | Data from Local System | Engineering workstation files |
| T0868 | Detect Operating Mode | Determine PLC run state |
| T0877 | I/O Image | Read PLC I/O table |
| T0801 | Monitor Process State | Observe process values |
| T0861 | Point & Tag Identification | Map SCADA tag database |
| T0845 | Program Upload | Extract PLC programs |
| T0852 | Screen Capture | Capture HMI screenshots |
| T0887 | Wireless Sniffing | Capture wireless ICS traffic |

#### TA0101 — Command and Control (3 techniques)
| ID | Technique |
|----|-----------|
| T0885 | Commonly Used Port |
| T0884 | Connection Proxy |
| T0869 | Standard Application Layer Protocol |

#### TA0107 — Inhibit Response Function (14 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0800 | Activate Firmware Update Mode | Force device into update state |
| T0878 | Alarm Suppression | Prevent operator alerts |
| T0803 | Block Command Message | Prevent control commands |
| T0804 | Block Reporting Message | Prevent status updates to master |
| T0805 | Block Serial COM | Disrupt serial communications |
| T0892 | Change Credential | Lock out operators |
| T0809 | Data Destruction | Wipe configurations (Industroyer) |
| T0814 | Denial of Service | Crash ICS components |
| T0816 | Device Restart/Shutdown | Force controller reboot |
| T0835 | Manipulate I/O Image | Override I/O table values |
| T0838 | Modify Alarm Settings | Change alarm thresholds |
| T0851 | Rootkit | Hide manipulation at OS level |
| T0881 | Service Stop | Stop critical OT services |
| T0857 | System Firmware | Flash compromised firmware |

#### TA0106 — Impair Process Control (5 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0806 | Brute Force I/O | Rapidly toggle outputs |
| T0836 | Modify Parameter | Change setpoints, limits, calibration |
| T0839 | Module Firmware | Compromised I/O module firmware |
| T0856 | Spoof Reporting Message | Feed false data to operators |
| T0855 | Unauthorized Command Message | Direct unauthorized commands to devices |

#### TA0105 — Impact (12 techniques)
| ID | Technique | ICS Relevance |
|----|-----------|--------------|
| T0879 | Damage to Property | Physical equipment destruction |
| T0813 | Denial of Control | Operators cannot control process |
| T0815 | Denial of View | Operators cannot monitor process |
| T0826 | Loss of Availability | System/process unavailable |
| T0827 | Loss of Control | Complete control loss |
| T0828 | Loss of Productivity and Revenue | Business impact from disruption |
| T0837 | Loss of Protection | Safety/protection functions disabled |
| T0880 | Loss of Safety | SIS functions compromised (TRITON) |
| T0829 | Loss of View | Visibility into process lost |
| T0831 | Manipulation of Control | Unauthorized process changes |
| T0832 | Manipulation of View | False data presented to operators |
| T0882 | Theft of Operational Information | IP theft, process data exfiltration |

---

## 7. ICS Threat Actor Groups

### Nation-State Actors

| Group | Also Known As | Attribution | Primary Targets | Key Tools |
|-------|---------------|-------------|-----------------|-----------|
| **Sandworm** | ELECTRUM, APT44, Voodoo Bear, Seashell Blizzard, IRIDIUM, FROZENBARENTS | GRU Unit 74455 (Russia) | Electric grid, government, Olympics | BlackEnergy, Industroyer, CaddyWiper, NotPetya |
| **XENOTIME** | TEMP.Veles | TsNIIKhM (Russia) | Oil & gas, petrochemical SIS | TRITON/TRISIS |
| **CHERNOVITE** | — | State-sponsored (assessed) | Electric grid, water, LNG | PIPEDREAM/INCONTROLLER |
| **Equation Group** | — | NSA (USA) | Iranian nuclear program | Stuxnet, Fanny, DoubleFantasy |
| **HEXANE** | Lyceum | Iran (assessed) | Oil & gas, telecoms (Middle East) | Custom backdoors |
| **ERYTHRITE** | — | Unknown | Power generation, oil & gas | Credential theft, watering holes |
| **KAMACITE** | — | GRU-linked | European energy | Initial access for ELECTRUM ops |
| **KOSTOVITE** | — | Unknown | Energy, water | Exploitation of remote access |
| **PETROVITE** | — | Unknown | Mining, energy | Credential theft, reconnaissance |
| **WASSONITE** | — | North Korea (assessed) | Nuclear energy | DTrack, BISTROMATH |

### Criminal Groups Targeting OT

- **DarkSide/BlackMatter**: Colonial Pipeline (2021)
- **LockBit**: Multiple manufacturing sector victims
- **ALPHV/BlackCat**: Energy sector targeting
- **Ransomware broadly**: Manufacturing is #1 ransomware target sector (Dragos reports consistently)

---

## 8. ICS Network Segmentation

### 8.1 Defense-in-Depth Architecture

```
┌─────────────────────────────────────────────────┐
│                INTERNET                          │
├─────────────────────────────────────────────────┤
│            ENTERPRISE DMZ                        │
│  [Web servers] [Email gateway] [VPN concentrator]│
├───────────── FW (L5/L4) ────────────────────────┤
│            ENTERPRISE NETWORK (L4-L5)            │
│  [ERP] [Email] [File servers] [Workstations]     │
├───────────── FW (L4/L3.5) ──────────────────────┤
│            IT/OT DMZ (L3.5)                      │
│  [Jump server] [Historian mirror] [Patch server] │
│  [Data diode] [AV update server]                 │
├───────────── FW (L3.5/L3) ──────────────────────┤
│            SITE OPERATIONS (L3)                  │
│  [OT Historian] [OT AD] [Engineering WS]        │
├───────────── FW (L3/L2) ────────────────────────┤
│            SUPERVISORY CONTROL (L2)              │
│  [HMI] [SCADA server] [OPC server]              │
├───────────── FW (L2/L1) ────────────────────────┤
│            BASIC CONTROL (L1)                    │
│  [PLCs] [RTUs] [DCS controllers]                 │
├─────────────────────────────────────────────────┤
│  ┌──── ISOLATED SAFETY NETWORK ────┐            │
│  │  [SIS controllers] [Safety HMI] │ ◄── Air-gapped or │
│  │  [Safety engineering WS]        │     hardware-enforced│
│  └─────────────────────────────────┘     isolation       │
├─────────────────────────────────────────────────┤
│            FIELD DEVICES (L0)                    │
│  [Sensors] [Actuators] [Drives] [Valves]         │
└─────────────────────────────────────────────────┘
```

### 8.2 Segmentation Rules

1. **Default deny between all zones** — only explicitly approved traffic
2. **No direct IT-to-OT** — all traffic traverses DMZ
3. **Unidirectional where possible** — data diodes from OT to IT (Level 3 to Level 3.5)
4. **SIS on isolated network** — separate from DCS, separate engineering tools
5. **Separate engineering VLAN** — engineering workstations isolated from operator HMIs
6. **No internet access below Level 3.5** — no web browsing on OT workstations
7. **Dedicated OT Active Directory** — separate forest/domain from corporate IT
8. **No dual-homed hosts** — no device bridging IT and OT networks simultaneously
9. **USB control** — removable media policy and technical enforcement at OT hosts
10. **Wireless segmentation** — plant WiFi isolated from control networks; WPA3-Enterprise minimum

### 8.3 Firewall Rule Design for ICS

**Allowed IT/OT DMZ flows** (examples):
```
# Historian replication (OT → DMZ only)
ALLOW L3:Historian → L3.5:Historian-Mirror : TCP/1433 (SQL replication)
DENY  L3.5:Historian-Mirror → L3:Historian  : ANY

# Remote access (via jump server only)
ALLOW L4:Admin-VPN → L3.5:JumpServer : TCP/3389 (RDP)
ALLOW L3.5:JumpServer → L3:Eng-WS    : TCP/3389 (RDP)
DENY  L4:ANY → L3:ANY : ANY  # No direct access

# Patch/AV updates (pull from DMZ only)
ALLOW L3:WSUS-Client → L3.5:WSUS-Server : TCP/8530
DENY  L3.5:ANY → L3:ANY : ANY (except responses to established)
```

---

## 9. OT Monitoring & Defense Tools

### 9.1 Commercial OT Security Platforms

| Vendor | Product | Capabilities |
|--------|---------|-------------|
| **Dragos** | Dragos Platform | OT threat detection, asset inventory, vulnerability management, threat intelligence (Neighborhood Keeper) |
| **Claroty** | xDome / CTD | OT/IoT asset discovery, vulnerability management, threat detection, secure remote access |
| **Nozomi Networks** | Guardian / Vantage | OT/IoT network visibility, threat detection, asset intelligence |
| **Microsoft** | Defender for IoT | OT protocol monitoring (agentless), CVE mapping, integration with Sentinel SIEM |
| **Fortinet** | FortiGate + OT | OT protocol inspection, IPS signatures for ICS protocols, segmentation |
| **Palo Alto** | IoT Security + NGFW | OT device identification, protocol decoding, zone segmentation |
| **Cisco** | Cyber Vision | OT asset discovery, protocol analysis, integration with Cisco ISE/FMC |
| **Tenable** | OT Security | Passive and active OT vulnerability scanning, Nessus-based |
| **Armis** | Centrix | Agentless OT/IoT device discovery and security |
| **Waterfall** | Unidirectional Security Gateways | Hardware-enforced data diodes for IT/OT boundary |

### 9.2 Open Source / Free Tools

| Tool | Purpose |
|------|---------|
| **GRASSMARLIN** | Passive ICS/SCADA network discovery and mapping (NSA/DHS origin) |
| **Malcolm** | Full packet capture and protocol analysis (CISA) |
| **Wireshark** | Protocol analysis with ICS dissectors (Modbus, DNP3, S7, CIP, BACnet, IEC 104) |
| **Zeek (Bro)** | Network monitoring with ICS protocol analyzers |
| **Suricata** | IDS/IPS with ICS protocol rules (ET SCADA ruleset) |
| **Snort** | IDS with Quickdraw ICS rules (Digital Bond) |
| **CSET** | CISA Cyber Security Evaluation Tool — questionnaire-based assessment |
| **Conpot** | ICS honeypot (Modbus, S7, BACnet, IPMI, Guardian AST) |
| **GasPot** | Veeder Root Guardian AST tank gauge honeypot |
| **T-Pot** | Docker-based honeypot platform including Conpot |

### 9.3 OT Detection Engineering

**Key data sources for ICS detection**:
- Network traffic (SPAN/TAP) — protocol-aware DPI
- Firewall logs at zone boundaries
- PLC program change logs (where available)
- Engineering workstation EDR/Sysmon
- Authentication logs (OT Active Directory)
- Historian query logs
- Physical process anomalies (process data analytics)

**High-value Sigma rules for OT environments**:

```yaml
title: Modbus Write Command to PLC from Non-Engineering Host
id: a3d7f8e2-1b4c-4d6e-9f0a-2c8b7e5d4a1f
status: experimental
description: Detects Modbus write function codes originating from hosts not in the engineering VLAN
logsource:
  category: network_connection
  product: ics_nids
detection:
  selection:
    dst_port: 502
    modbus.function_code:
      - 5   # Write Single Coil
      - 6   # Write Single Register
      - 15  # Write Multiple Coils
      - 16  # Write Multiple Registers
  filter:
    src_ip|cidr: '10.10.20.0/24'  # Engineering VLAN
  condition: selection and not filter
falsepositives:
  - Emergency maintenance from temporary workstation
level: high
tags:
  - attack.t0855
  - attack.impair_process_control
```

```yaml
title: S7comm CPU Stop Command
id: b4e8f9a3-2c5d-4e7f-a1b0-3d9c8f6e5b2a
status: experimental
description: Detects S7comm CPU STOP command which halts PLC execution
logsource:
  category: network_connection
  product: ics_nids
detection:
  selection:
    dst_port: 102
    s7comm.function: 'cpu_stop'
  condition: selection
falsepositives:
  - Planned maintenance with documented change window
level: critical
tags:
  - attack.t0816
  - attack.inhibit_response_function
```

```yaml
title: PLC Program Download Outside Change Window
id: c5f9a0b4-3d6e-4f8a-b2c1-4e0d9a7f6c3b
status: experimental
description: Detects PLC program download activity outside approved maintenance windows
logsource:
  category: network_connection
  product: ics_nids
detection:
  selection:
    s7comm.function: 'download_block'
  filter_time:
    # Requires correlation with maintenance calendar
  condition: selection
falsepositives:
  - Emergency program changes with verbal authorization
level: critical
tags:
  - attack.t0843
  - attack.lateral_movement
```

---

## 10. Offensive ICS Tools & Frameworks

### 10.1 Exploitation Frameworks

| Tool | Description | Protocols |
|------|-------------|-----------|
| **ISF** (Industrial Exploitation Framework) | Python-based Metasploit-style framework for PLCs | S7, Modbus, various |
| **smod** | Modbus penetration testing framework | Modbus TCP |
| **PLCinject** | PLC code injection tool | S7comm |
| **ISEF** | Industrial Security Exploitation Framework | Multiple |
| **Metasploit** | Modules: `auxiliary/scanner/scada/*` | Modbus, S7, BACnet, DNP3, CIP |

### 10.2 Enumeration & Scanning

| Tool | Description | Target |
|------|-------------|--------|
| **Redpoint** (Digital Bond) | Nmap NSE scripts for ICS | BACnet, S7, EtherNet/IP, Modbus, Fox, Omron, PCWorx, ProConOS |
| **plcscan** | PLC scanner | S7comm, Modbus |
| **s7scan** | Siemens PLC scanner | S7comm |
| **GRASSMARLIN** | Passive OT network mapping | All ICS protocols |
| **Kamerka GUI** | IoT/ICS OSINT reconnaissance | Shodan integration |
| **Shodan CLI** | Internet-wide ICS scanning | All ICS protocols |

### 10.3 Protocol Libraries

| Library | Language | Protocols |
|---------|----------|-----------|
| **pymodbus** | Python | Modbus TCP/RTU |
| **snap7** | C/Python | S7comm |
| **pycomm3** | Python | EtherNet/IP / CIP (Allen-Bradley) |
| **bacpypes** | Python | BACnet |
| **cpppo** | Python | EtherNet/IP / CIP |
| **scapy** | Python | Raw packet crafting for any protocol |
| **dnplib** | Python | DNP3 |

### 10.4 Fuzzing & Vulnerability Research

| Tool | Description |
|------|-------------|
| **ICSFuzz** | Fuzzer for Codesys-based PLC applications |
| **ICSREF** | Automated reverse engineering for Codesys v2 binaries |
| **AttkFinder** | Static analysis for PLC programs — identifies attack vectors |
| **Aegis** | DNP3 protocol fuzzer |
| **boofuzz** | General-purpose protocol fuzzer (successor to Sulley) — applicable to ICS |

### 10.5 Simulation & Lab Environments

| Tool | Description |
|------|-------------|
| **SCADASim** (CMU-SEI) | Configurable SCADA simulator with Modbus TCP/RTU; Python/PyModbus-based; emulates multiple PLCs |
| **GRFICSv2** | Unity 3D-based ICS simulation — virtual chemical plant for attack/defense practice |
| **LICSTER** | Low-cost ICS testbed with real hardware; includes pre-built attack scenarios |
| **MiniCPS** | Cyber-physical systems security research toolkit |
| **ModbusPal** | Java-based Modbus slave simulator |
| **NetToPLCSim** | TCP/IP extension for Siemens PLCSim |
| **Conpot** | Low-interaction ICS honeypot (can be used as target practice) |
| **ControlThings Platform** | Linux distribution with pre-installed ICS security tools |
| **Moki Linux** | Customized Kali with ICS/SCADA tools |

### 10.6 Shodan ICS Queries

```
# Protocol-specific searches
port:502 "Modbus"                          # Modbus devices
port:102 "Siemens"                         # Siemens S7 PLCs
port:44818 "EtherNet/IP"                   # Rockwell/Allen-Bradley
port:47808 "BACnet"                        # Building automation
port:20000 "DNP3"                          # DNP3 outstations
port:1911 "Niagara Fox"                    # Tridium Niagara
port:2404 "IEC-104"                        # IEC 60870-5-104
port:4840 "OPC UA"                         # OPC Unified Architecture
port:9600 "FINS"                           # Omron PLCs

# Vendor-specific searches
"Schneider Electric" port:502
"Allen-Bradley" port:44818
"Simatic" port:102
"Triconex"                                 # Safety controllers
"Rockwell Automation"

# HMI/SCADA interfaces
"SCADA" http.title                         # Web-accessible SCADA
"Wonderware" http.title                    # Wonderware InTouch
"FactoryTalk"                              # Rockwell FactoryTalk
"Ignition" http.title                      # Inductive Automation
```

---

## 11. NIST 800-82 / IEC 62443 Frameworks

### 11.1 NIST SP 800-82 Rev 2 — Guide to ICS Security

**Scope**: Comprehensive guidance for securing SCADA, DCS, PLC, and other ICS configurations. Addresses the tension between security and "unique performance, reliability, and safety requirements" of OT.

**Key areas**:

1. **ICS Architecture Overview**: Describes typical SCADA, DCS, and PLC architectures; system topologies; communication patterns
2. **Threat Identification**: Catalogs threats specific to ICS — nation-state, criminal, insider, accidental
3. **Vulnerability Assessment**: ICS-specific vulnerabilities — protocol weaknesses, legacy systems, patching constraints
4. **Security Controls**: Maps NIST 800-53 controls to ICS environments with OT-specific tailoring

**ICS-Specific Security Recommendations**:

| Control Area | Key Guidance |
|-------------|-------------|
| **Network Architecture** | Implement defense-in-depth per Purdue model; DMZ between IT/OT; restrict protocols at boundaries |
| **Access Control** | Role-based access; separate accounts for IT and OT; physical access controls for field devices |
| **Authentication** | Multi-factor where feasible; eliminate default credentials; certificate-based for device-to-device |
| **Patch Management** | Test patches in lab environment before deploying to production OT; vendor-approved patches only; compensating controls when patching is infeasible |
| **Monitoring** | Network monitoring at zone boundaries; protocol-aware inspection; baseline normal traffic patterns |
| **Incident Response** | OT-specific IR plan; include plant operators and process engineers; prioritize safety over availability |
| **Physical Security** | Lock control panels; restrict USB ports; camera coverage of control rooms and MCC rooms |
| **Backup/Recovery** | Maintain offline backups of PLC programs, HMI configurations, historian databases; test restoration |

**Relationship to 800-53**: 800-82 provides an overlay that tailors 800-53 controls for ICS, adding OT-specific considerations for each control family.

### 11.2 IEC 62443 — Industrial Automation and Control Systems Security

**Overview**: International standard series (ISA/IEC 62443) providing a comprehensive framework for ICS security. Unlike NIST (guidance), IEC 62443 is a certifiable standard used globally.

**Standard Structure**:

| Part | Title | Audience |
|------|-------|----------|
| **62443-1-x** | General (concepts, models, terminology) | All stakeholders |
| **62443-2-x** | Policies & Procedures | Asset owners |
| **62443-3-x** | System Requirements | System integrators |
| **62443-4-x** | Component Requirements | Component vendors |

**Key Concepts**:

**Security Levels (SL)** — Define rigor of security measures:

| SL | Protection Target | Threat Agent |
|----|-------------------|-------------|
| **SL 0** | No specific requirements | — |
| **SL 1** | Protection against casual/unintentional violation | Accidental, unintentional |
| **SL 2** | Protection against intentional violation using simple means | Low motivation, general skills |
| **SL 3** | Protection against sophisticated attacks with moderate resources | Moderate motivation, ICS-specific skills |
| **SL 4** | Protection against state-sponsored attacks with extended resources | High motivation, deep ICS expertise, significant resources |

**Zones and Conduits**:
- **Zone**: Grouping of assets with common security requirements (maps to Purdue levels)
- **Conduit**: Communication channel between zones; security controls applied at conduit boundaries
- Each zone assigned a target Security Level; conduits must enforce the SL of the higher-security zone

**Foundational Requirements (FR)**:

| FR | Requirement | Description |
|----|------------|-------------|
| FR 1 | Identification and Authentication Control | Verify identity of users, devices, software |
| FR 2 | Use Control | Enforce authorization and least privilege |
| FR 3 | System Integrity | Ensure integrity of IACS components |
| FR 4 | Data Confidentiality | Protect data in transit and at rest |
| FR 5 | Restricted Data Flow | Segment networks, control information flow |
| FR 6 | Timely Response to Events | Monitor, detect, respond to security events |
| FR 7 | Resource Availability | Ensure availability of IACS under attack |

**Maturity Levels** (62443-2-4):

| ML | Level | Description |
|----|-------|-------------|
| ML 1 | Initial | Ad-hoc security practices |
| ML 2 | Managed | Documented security policies |
| ML 3 | Defined | Organization-wide security program |
| ML 4 | Improving | Continuous improvement with metrics |

### 11.3 NERC CIP (North American Electric Reliability Corporation)

Mandatory standards for Bulk Electric System (BES) in North America:

| Standard | Focus |
|----------|-------|
| CIP-002 | BES Cyber System Categorization |
| CIP-003 | Security Management Controls |
| CIP-004 | Personnel & Training |
| CIP-005 | Electronic Security Perimeters |
| CIP-006 | Physical Security |
| CIP-007 | System Security Management |
| CIP-008 | Incident Reporting and Response |
| CIP-009 | Recovery Plans |
| CIP-010 | Configuration Change Management |
| CIP-011 | Information Protection |
| CIP-013 | Supply Chain Risk Management |
| CIP-014 | Physical Security (Transmission) |
| CIP-015 | Internal Network Security Monitoring (new) |

---

## 12. ICS Default Credentials & Enumeration

### 12.1 Common ICS Default Credentials

**[CONFIRMED]** Default credentials remain one of the most prevalent attack vectors in ICS environments. Many devices ship with well-known credentials that operators never change.

| Vendor | Product | Username | Password | Protocol/Interface |
|--------|---------|----------|----------|--------------------|
| Siemens | S7 PLC | — | 0x00000000 (8 null bytes) | S7comm CPU protection |
| Siemens | WinCC | WinCCAdmin | 2WSXcder | Application |
| Siemens | WinCC DB | WinCCConnect | 2WSXcder | SQL Server |
| Schneider | Quantum PLC | USER | USER | FTP/Telnet |
| Schneider | M340 PLC | USER | USER | FTP |
| Schneider | Unity Pro | — | (blank) | Engineering software |
| Allen-Bradley | MicroLogix | — | (blank) | HTTP/RSLogix |
| Allen-Bradley | ControlLogix | — | (blank) | EtherNet/IP |
| GE | Mark VIe | admin | admin | Web interface |
| ABB | AC500 PLC | admin | admin | Web interface |
| Tridium | Niagara | tridium | tridium | Web/Fox |
| Moxa | NPort | admin | (blank) | Serial device server |
| Lantronix | UDS | — | system | Serial device server |
| Wago | 750 PLC | admin | wago | Web interface |
| Beckhoff | TwinCAT | Administrator | 1 | Web/ADS |

**Resource**: The `ics-default-credentials` repository and SCADAPASS database maintain actively updated credential lists.

### 12.2 Redpoint Nmap Script Summary

| Script | Protocol | Port | Key Information Extracted |
|--------|----------|------|--------------------------|
| `BACnet-discover-enumerate.nse` | BACnet | UDP/47808 | Vendor, firmware, object identifiers, broadcast tables |
| `codesys-v2-discover.nse` | CoDeSys | TCP/1200,2455 | OS version, runtime identification |
| `enip-enumerate.nse` | EtherNet/IP | TCP/44818 | Vendor, product, serial, device type, revision |
| `s7-enumerate.nse` | S7comm | TCP/102 | Module type, hardware ID, system name, serial number |
| `modicon-info.nse` | Modbus | TCP/502 | Network module, CPU, firmware, memory, project |
| `fox-info.nse` | Niagara Fox | TCP/1911 | Protocol version, hostname, app name/version |
| `omrontcp-info.nse` | FINS | TCP/9600 | Controller model, firmware, memory config |
| `omronudp-info.nse` | FINS | UDP/9600 | Controller model, firmware, memory config |
| `pcworx-info.nse` | PC Worx | TCP/1962 | PLC type, model, firmware version/date |
| `proconos-info.nse` | ProConOS | TCP/20547 | Runtime info, project name, boot config |

**Design principle**: Redpoint scripts use "legitimate protocol or application commands to discover and enumerate devices" with no exploitation attempts. However, ICS devices may be fragile — unexpected traffic can cause crashes.

---

## 13. Training Labs & Simulation

### 13.1 Lab Environments

| Environment | Description | Skill Level |
|-------------|-------------|-------------|
| **GRFICSv2** | Unity 3D virtual chemical plant; attack/defense scenarios; includes HMI, PLC simulation | Intermediate-Advanced |
| **LICSTER** | Low-cost hardware testbed (<$500); real PLC (Siemens S7-1200); pre-built attacks | Beginner-Intermediate |
| **SCADASim** (CMU-SEI) | Python Modbus simulator; configurable PLCs; web UI; Modbus TCP/RTU | Beginner |
| **MiniCPS** | Academic CPS research toolkit; water treatment simulation | Advanced |
| **Conpot** | ICS honeypot deployable as target practice; S7, Modbus, BACnet | Beginner |
| **ControlThings Platform** | Pre-built Linux distro with ICS tools | All levels |
| **Moki Linux** | Kali-based with ICS tools integrated | All levels |

### 13.2 Recommended Training Path

1. **Fundamentals**: Understand Purdue model, ICS protocols, PLC programming basics
   - Videos: Control System Basics, PLC Professor, RealPars YouTube channel
   - Lab: SCADASim + pymodbus

2. **Protocol Analysis**: Capture and analyze ICS traffic
   - Tools: Wireshark with ICS dissectors
   - Data: 4SICS lab PCAPs, DEF CON 23 ICS Village PCAPs

3. **Enumeration**: Discover and fingerprint ICS devices
   - Tools: Redpoint Nmap scripts, plcscan, GRASSMARLIN
   - Lab: GRFICSv2 or LICSTER

4. **Exploitation**: Test attack scenarios in controlled environments
   - Tools: ISF, smod, snap7, Metasploit ICS modules
   - Lab: GRFICSv2, LICSTER

5. **Detection Engineering**: Build OT monitoring and detection
   - Tools: Zeek, Suricata, Sigma rules
   - Focus: Protocol anomaly detection, unauthorized write commands

6. **Certifications**:
   - SANS GICSP (Global Industrial Cyber Security Professional)
   - SANS ICS410 (ICS/SCADA Security Essentials)
   - SANS ICS515 (ICS Visibility, Detection, and Response)
   - CISA ICS training (free, in-person at Idaho National Labs)

### 13.3 Conferences & Community

| Event | Focus | Notes |
|-------|-------|-------|
| **S4** (SCADA Security Scientific Symposium) | ICS security research | Premier ICS security conference |
| **CS3STHLM** | European ICS security | Stockholm-based summit |
| **DEF CON ICS Village** | Hands-on ICS hacking | PCAPs and CTF published |
| **SANS ICS Summit** | ICS defense and detection | Presentation archives available |
| **CS4CA** | Critical asset protection | Regional summits globally |

---

## 14. Key References & Resources

### Standards & Frameworks
- NIST SP 800-82 Rev 2 — Guide to ICS Security
- IEC 62443 series — Industrial Automation Security
- NERC CIP standards — Bulk Electric System requirements
- CIS Controls for ICS — Implementation guidance
- MITRE ATT&CK for ICS — https://attack.mitre.org/matrices/ics/

### Threat Intelligence
- Dragos WorldView — ICS threat intelligence
- CISA ICS Advisories — https://www.cisa.gov/topics/industrial-control-systems
- ICS-CERT alerts and RSS feeds
- Claroty Team82 vulnerability disclosures

### GitHub Repositories
- `hslatman/awesome-industrial-control-system-security` — Curated resource list
- `ITI/ICS-Security-Tools` — Tool catalog by category
- `w3h/icsmaster` — ICS hacking resources, exploits, PCAPs
- `digitalbond/Redpoint` — Nmap ICS enumeration scripts
- `cmu-sei/SCADASim` — SCADA simulation
- `atiilla/ics-default-credentials` — Default credential database

### Books
- *Industrial Network Security*, 2nd Edition (Eric D. Knapp, Joel Thomas Langill)
- *Handbook of SCADA/Control Systems Security* (Robert Radvanovsky)
- *Hacking Exposed: Industrial Control Systems* (Clint Bodungen)
- *Countering Cyber Sabotage* (Andrew Bochman, Sarah Freeman)
- *Applied Cyber Security and the Smart Grid* (Eric D. Knapp, Raj Samani)

### CISA Resources
- CSET (Cyber Security Evaluation Tool) — Desktop assessment tool
- Malcolm — Network traffic analysis for OT
- Logging Made Easy (LME) — Free log management
- Cyber Hygiene Services — Free vulnerability scanning
- CELR — Controls Environment Laboratory Resource
- OT Asset Inventory Guidance

---

> **CIPHER Assessment**: ICS/SCADA security is characterized by a fundamental tension — systems designed for 20-30 year lifespans in isolated environments are now connected to networks designed for 3-5 year refresh cycles. The protocol layer has no security by design. The safety layer (SIS) was assumed physically isolated and is now proven targetable (TRITON). Nation-states have demonstrated both capability and willingness to weaponize ICS access for physical destruction. The defensive gap is measured in decades of technical debt. Defenders must assume breach, instrument what they can, segment aggressively, and prioritize safety system isolation above all else.
