# CIPHER Deep Training: Security Leadership, CISO Role & Program Management

> Synthesized from SANS CISO Mind Map, NIST CSF 2.0, OWASP, awesome-engineering-team-management, gstack cognitive mode framework, and practitioner sources.
> Training date: 2026-03-14

---

## Table of Contents

1. [CISO Role & Responsibilities](#1-ciso-role--responsibilities)
2. [Security Program Maturity Assessment](#2-security-program-maturity-assessment)
3. [Board Reporting & Executive Communication](#3-board-reporting--executive-communication)
4. [Security Budget Justification](#4-security-budget-justification)
5. [Team Structure & Hiring](#5-team-structure--hiring)
6. [Vendor Management & Tool Portfolio](#6-vendor-management--tool-portfolio)
7. [Incident Communication Framework](#7-incident-communication-framework)
8. [Security Culture Development](#8-security-culture-development)
9. [Threat Modeling at Organizational Scale](#9-threat-modeling-at-organizational-scale)
10. [Bug Bounty & External Testing Programs](#10-bug-bounty--external-testing-programs)
11. [AppSec Program Building](#11-appsec-program-building)
12. [Cloud Security Program](#12-cloud-security-program)
13. [Cognitive Mode Framework Applied to Security Programs](#13-cognitive-mode-framework-applied-to-security-programs)
14. [Security Career Progression to Leadership](#14-security-career-progression-to-leadership)
15. [CISO Failure Modes & Anti-Patterns](#15-ciso-failure-modes--anti-patterns)

---

## 1. CISO Role & Responsibilities

### SANS CISO Mind Map Domains

The CISO role spans these primary domains, each demanding distinct competencies:

```
                            ┌─────────────────────┐
                            │        CISO          │
                            └─────────┬───────────┘
         ┌────────────┬───────────┬───┴───┬───────────┬────────────┐
         ▼            ▼           ▼       ▼           ▼            ▼
    ┌─────────┐ ┌──────────┐ ┌────────┐ ┌──────┐ ┌────────┐ ┌─────────┐
    │Governance│ │ Risk     │ │Security│ │  IR  │ │  Team  │ │  Legal  │
    │ & Policy │ │Management│ │  Ops   │ │ / BC │ │Building│ │Regulatory│
    └─────────┘ └──────────┘ └────────┘ └──────┘ └────────┘ └─────────┘
```

#### Domain 1: Governance & Policy

| Responsibility | Deliverables | Cadence |
|---|---|---|
| Security policy framework | Acceptable use, data classification, access control policies | Annual review, quarterly updates |
| Standards & baselines | CIS benchmarks, hardening guides, secure config standards | Continuous |
| Regulatory compliance mapping | GDPR Art. 5/6/32, HIPAA 164.308, PCI DSS, SOX | Per-regulation cycle |
| Board-level security governance | Risk appetite statement, security charter | Annual |
| Security awareness program | Phishing simulations, role-based training, metrics | Monthly campaigns, annual training |
| Exception management | Risk acceptance documentation, compensating controls | On-demand with review |

#### Domain 2: Risk Management

- **Risk identification**: Asset inventory, threat landscape analysis, vulnerability management program
- **Risk quantification**: FAIR (Factor Analysis of Information Risk), annualized loss expectancy, Monte Carlo simulations
- **Risk treatment**: Accept, mitigate, transfer (insurance), avoid -- every decision documented with owner and review date
- **Third-party risk**: Vendor security assessments, SOC 2 reviews, supply chain risk, fourth-party risk mapping
- **Cyber insurance**: Coverage assessment, policy negotiation, claims process readiness

#### Domain 3: Security Operations

- **SOC design**: Tier 1/2/3 analyst structure, playbook development, SOAR automation
- **Detection engineering**: Sigma rules, SIEM tuning, false positive management, detection coverage mapping to ATT&CK
- **Vulnerability management**: Scanner deployment, SLA-based remediation, risk-based prioritization (CVSS + exploit availability + asset criticality)
- **Endpoint protection**: EDR/XDR strategy, MDM for mobile fleet
- **Network security**: Segmentation, zero trust network access, DNS security, email gateway

#### Domain 4: Incident Response & Business Continuity

- **IR program**: NIST 800-61 based, tabletop exercises quarterly, full-scale exercises annually
- **BC/DR**: RPO/RTO definitions per business function, DR site testing, crisis communication plan
- **Forensics capability**: Evidence preservation procedures, chain of custody, legal hold coordination
- **Breach notification**: Regulatory timelines (GDPR 72hr, state laws vary), customer communication templates

#### Domain 5: Team Building & People

- **Organizational design**: Reporting structure, span of control, career ladders
- **Talent acquisition**: Job descriptions aligned to NICE framework, interview process, compensation benchmarking
- **Retention**: Professional development budget, conference attendance, certification support, rotation programs
- **Culture**: Blameless post-mortems, security champion programs, cross-functional integration

#### Domain 6: Legal & Regulatory

- **Privacy program**: DPO role, DPIA process, data subject request handling
- **Compliance evidence**: Continuous control monitoring, audit readiness, evidence repository
- **Contract security**: Security requirements in vendor contracts, SLAs for security incidents
- **Intellectual property**: Trade secret protection, code security, NDA management

### CISO Reporting Line

```
  REPORTING STRUCTURE — IMPACT ON EFFECTIVENESS

  ┌──────────────────────────────────────────────────┐
  │ Reports to CEO/Board     │ Reports to CIO/CTO    │
  ├──────────────────────────┼───────────────────────┤
  │ Direct board access      │ Filtered through IT   │
  │ Budget independence      │ Competes with IT ops  │
  │ Strategic influence      │ Tactical execution    │
  │ Risk-first framing       │ Technology-first frame│
  │ Regulatory expectation   │ Operational focus     │
  │ for public companies     │                       │
  └──────────────────────────┴───────────────────────┘

  [CONFIRMED] SEC rules (2023) require board oversight of cyber risk.
  Best practice: CISO reports to CEO with dotted line to board risk committee.
```

### Day-One vs. Year-One CISO Priorities

**First 90 days (listening mode):**
1. Inventory existing controls, tools, and team capabilities
2. Meet every business unit leader -- understand their risk tolerance and pain points
3. Review last 12 months of incidents, near-misses, and audit findings
4. Assess crown jewels -- what data/systems would end the business if compromised
5. Identify top 5 risks that need immediate action vs. strategic planning

**First year (building mode):**
1. Establish security governance structure (policies, standards, exception process)
2. Build or mature IR capability -- tabletop within 90 days
3. Implement risk register with quantified top risks
4. Deliver first board report -- establish cadence and format
5. Quick wins: MFA everywhere, EDR deployment, email security, backup verification

---

## 2. Security Program Maturity Assessment

### NIST CSF 2.0 Framework

CSF 2.0 introduced the **Govern** function, elevating cybersecurity governance to a first-class concern alongside the original five functions.

#### Six Functions

```
  ┌──────────────────────────────────────────────────────────────┐
  │                        GOVERN (GV)                           │
  │   Organizational context, risk strategy, supply chain risk,  │
  │   roles/responsibilities, policies, oversight                │
  ├──────────┬──────────┬──────────┬──────────┬─────────────────┤
  │ IDENTIFY │ PROTECT  │  DETECT  │ RESPOND  │    RECOVER      │
  │   (ID)   │  (PR)    │   (DE)   │   (RS)   │     (RC)        │
  ├──────────┼──────────┼──────────┼──────────┼─────────────────┤
  │ Asset    │ Identity │Continuous│ IR Mgmt  │ IR Plan         │
  │ Mgmt     │ Mgmt     │Monitoring│ Analysis │ Execution       │
  │ Risk     │ Data     │ Adverse  │ Reporting│ Recovery        │
  │ Assess   │ Security │ Event    │ Mitiga-  │ Communication   │
  │ Supply   │ Platform │ Analysis │ tion     │                 │
  │ Chain    │ Security │          │          │                 │
  │ Improve  │ Tech     │          │          │                 │
  │          │ Infra    │          │          │                 │
  │          │ Resilience│         │          │                 │
  └──────────┴──────────┴──────────┴──────────┴─────────────────┘
```

#### CSF 2.0 Categories Under GOVERN (GV)

| Category | Description | Key Outcomes |
|---|---|---|
| GV.OC | Organizational Context | Understand mission, stakeholder expectations, legal/regulatory requirements |
| GV.RM | Risk Management Strategy | Define risk appetite, risk tolerance, integrate cyber risk into enterprise risk |
| GV.RR | Roles, Responsibilities, Authorities | RACI for cybersecurity across organization |
| GV.PO | Policy | Establish, communicate, enforce cybersecurity policy |
| GV.OV | Oversight | Board and senior leadership oversight of cybersecurity strategy |
| GV.SC | Cybersecurity Supply Chain Risk Management | Third-party risk, SBOM, vendor assessment |

#### Implementation Tiers

| Tier | Name | Characteristics |
|---|---|---|
| 1 | Partial | Ad hoc, reactive, limited awareness, no formal process |
| 2 | Risk-Informed | Risk-aware but not organization-wide, some processes approved by management |
| 3 | Repeatable | Formal policies, regularly updated, organization-wide risk management |
| 4 | Adaptive | Continuous improvement from lessons learned and predictive indicators, agile response |

### Program Maturity Self-Assessment Framework

Score each domain 1-5 (1=nonexistent, 5=optimized):

```
  SECURITY PROGRAM MATURITY RADAR

  Domain                          Score  Evidence Required
  ──────────────────────────────  ─────  ─────────────────────────
  Governance & Policy              __    Written policy, review dates
  Risk Management                  __    Risk register, quantification
  Asset Management                 __    CMDB accuracy, crown jewels ID'd
  Identity & Access Management     __    MFA %, PAM deployment, reviews
  Data Protection                  __    Classification scheme, DLP
  Security Operations              __    MTTD, MTTR, detection coverage
  Vulnerability Management         __    SLA compliance, risk-based triage
  Incident Response                __    Tabletop frequency, IR plan test
  Application Security             __    SAST/DAST in CI/CD, fix rates
  Cloud Security                   __    CSPM coverage, IaC scanning
  Third-Party Risk                 __    Vendor assessment %, SLA monitoring
  Security Awareness               __    Phish click rate, training completion
  BC/DR                            __    RTO/RPO defined, DR tested
  Privacy                          __    DPIA process, DSR handling time
  Compliance                       __    Audit findings open, evidence automation

  MATURITY LEVELS:
  1 = Initial (ad hoc, undocumented)
  2 = Developing (some process, inconsistent)
  3 = Defined (documented, organization-wide)
  4 = Managed (measured, metrics-driven)
  5 = Optimized (continuous improvement, predictive)
```

### Maturity Improvement Prioritization

```
  PRIORITIZATION MATRIX

                    HIGH IMPACT
                        │
           ┌────────────┼────────────┐
           │  QUICK WINS │  STRATEGIC │
           │  (Do first) │  PROJECTS  │
  LOW  ────┼────────────┼────────────┼──── HIGH
  EFFORT   │  FILL-INS  │  MAJOR     │    EFFORT
           │  (Do when  │  PROGRAMS  │
           │   slack)    │  (Plan)    │
           └────────────┼────────────┘
                        │
                    LOW IMPACT
```

**Quick wins (high impact, low effort):**
- MFA enforcement across all accounts
- Email authentication (SPF/DKIM/DMARC)
- Automated vulnerability scanning
- Security awareness phishing simulations
- Backup verification testing

**Strategic projects (high impact, high effort):**
- Zero trust architecture implementation
- SIEM/SOAR deployment and tuning
- Application security program (SAST/DAST/SCA in CI/CD)
- Third-party risk management automation
- Data classification and DLP

---

## 3. Board Reporting & Executive Communication

### Board Communication Principles

**Rule 1: Translate risk to business impact, never lead with technology.**

```
  BAD:  "We need to deploy a SIEM with SOAR integration and increase
         our Sigma rule coverage from 23% to 60% of MITRE ATT&CK."

  GOOD: "We currently detect 23% of known attack techniques. A recent
         breach at [peer company] used techniques we cannot detect.
         Investment of $X closes this gap to 60%, reducing our estimated
         breach probability by Y%."
```

**Rule 2: Use risk quantification, not fear.**

```
  BAD:  "If we don't do this, we'll get breached."

  GOOD: "Based on FAIR analysis, our annualized loss expectancy for
         a data breach is $12M. This investment of $800K reduces
         that to $3M -- a 75% risk reduction for 6.7% of the
         potential loss."
```

**Rule 3: Benchmark against peers, not against perfection.**

```
  BAD:  "We're at maturity level 2 out of 5."

  GOOD: "We're at maturity level 2. Our industry median is 2.5.
         Top-quartile companies are at 3.5. This plan moves us
         to 3.0 within 12 months, ahead of median."
```

### Board Report Template

```
  ┌══════════════════════════════════════════════════════════════┐
  ║              QUARTERLY CYBERSECURITY REPORT                  ║
  ║              Q[X] [YEAR] — [Company Name]                    ║
  ╠══════════════════════════════════════════════════════════════╣
  ║                                                              ║
  ║  EXECUTIVE SUMMARY (1 paragraph)                             ║
  ║  Overall risk posture: ● ELEVATED / ● MODERATE / ● LOW      ║
  ║  Key message: [one sentence on the most important thing]     ║
  ║                                                              ║
  ╠══════════════════════════════════════════════════════════════╣
  ║                                                              ║
  ║  TOP 5 RISKS                                                 ║
  ║  ┌────┬───────────────┬──────────┬──────────┬────────────┐   ║
  ║  │ #  │ Risk          │ Inherent │ Residual │ Trend      │   ║
  ║  ├────┼───────────────┼──────────┼──────────┼────────────┤   ║
  ║  │ 1  │ Ransomware    │ Critical │ High     │ ↗ Rising   │   ║
  ║  │ 2  │ Supply chain  │ High     │ Medium   │ → Stable   │   ║
  ║  │ 3  │ Insider threat│ High     │ High     │ ↗ Rising   │   ║
  ║  │ 4  │ Cloud misconf │ Medium   │ Low      │ ↘ Declining│   ║
  ║  │ 5  │ Phishing      │ High     │ Medium   │ → Stable   │   ║
  ║  └────┴───────────────┴──────────┴──────────┴────────────┘   ║
  ║                                                              ║
  ╠══════════════════════════════════════════════════════════════╣
  ║                                                              ║
  ║  KEY METRICS                                                 ║
  ║  ┌───────────────────────┬─────────┬─────────┬──────────┐    ║
  ║  │ Metric                │ Current │ Target  │ Trend    │    ║
  ║  ├───────────────────────┼─────────┼─────────┼──────────┤    ║
  ║  │ MTTD (days)           │   12    │   <5    │ ↘ Better │    ║
  ║  │ MTTR (hours)          │   48    │   <24   │ → Same   │    ║
  ║  │ Critical vulns open   │   23    │   <10   │ ↗ Worse  │    ║
  ║  │ Phish click rate      │   8%    │   <3%   │ ↘ Better │    ║
  ║  │ MFA coverage          │   94%   │  100%   │ ↗ Better │    ║
  ║  │ Vendor assessments    │   72%   │  100%   │ ↗ Better │    ║
  ║  │ Compliance findings   │    4    │    0    │ ↘ Better │    ║
  ║  └───────────────────────┴─────────┴─────────┴──────────┘    ║
  ║                                                              ║
  ╠══════════════════════════════════════════════════════════════╣
  ║                                                              ║
  ║  INCIDENTS THIS QUARTER                                      ║
  ║  Total: XX | Critical: X | Data loss: X | External report: X║
  ║  Notable: [brief description of significant incidents]       ║
  ║                                                              ║
  ╠══════════════════════════════════════════════════════════════╣
  ║                                                              ║
  ║  PROGRAM PROGRESS                                            ║
  ║  [3-5 bullet points on strategic initiative status]          ║
  ║  [Red/Yellow/Green status for each]                          ║
  ║                                                              ║
  ╠══════════════════════════════════════════════════════════════╣
  ║                                                              ║
  ║  REGULATORY & COMPLIANCE UPDATE                              ║
  ║  [New regulations, audit results, upcoming deadlines]        ║
  ║                                                              ║
  ╠══════════════════════════════════════════════════════════════╣
  ║                                                              ║
  ║  DECISIONS NEEDED                                            ║
  ║  [Specific asks with options and CISO recommendation]        ║
  ║                                                              ║
  ╚══════════════════════════════════════════════════════════════╝
```

### Metrics That Matter to the Board

**Outcome metrics (lead with these):**
- Breach probability reduction (FAIR model)
- Cyber insurance premium trends
- Regulatory compliance status
- Customer data protection posture
- Business downtime due to security events

**Operational metrics (supporting detail):**
- MTTD / MTTR trends
- Vulnerability remediation SLA compliance
- Phishing simulation results
- MFA / PAM coverage
- Third-party risk assessment completion

**[CONFIRMED] Anti-pattern: Do not present 50 metrics. Present 5-7 that tell a story. Board members have 15-20 minutes for security, maximum.**

### Peer Benchmarking Sources

- Verizon DBIR (annual, free) -- industry-specific breach statistics
- IBM Cost of a Data Breach (annual) -- financial impact benchmarks
- Ponemon / Cyentia Institute studies -- quantified risk data
- ISACA State of Cybersecurity surveys
- Gartner security spending benchmarks (requires subscription)
- Industry ISACs (FS-ISAC, H-ISAC, etc.) -- sector-specific threat intelligence

---

## 4. Security Budget Justification

### Security Spending Benchmarks

```
  INDUSTRY SECURITY SPENDING AS % OF IT BUDGET

  Financial Services    │████████████████████  10-15%
  Healthcare            │██████████████        8-12%
  Technology            │████████████          6-10%
  Retail                │████████              4-8%
  Manufacturing         │██████                3-6%
  Government            │████████████          6-10%

  ALTERNATIVE METRIC: Per-employee spend
  Typical range: $1,500 - $3,500 per employee per year
  Highly regulated industries: $3,500 - $6,000+
```

### Budget Justification Framework

**Step 1: Risk quantification (FAIR model)**

```
  RISK SCENARIO: Customer data breach via web application vulnerability
  ──────────────────────────────────────────────────────────────────────
  Loss Event Frequency (LEF):
    Threat Event Frequency:    12/year (attempted exploitation)
    Vulnerability (prob):      0.3 (30% chance of success)
    LEF = 12 × 0.3 =          3.6 events/year

  Loss Magnitude (LM):
    Primary losses:            $2M (notification, forensics, legal)
    Secondary losses:          $8M (regulatory fines, reputation, churn)
    LM =                      $10M per event

  Annualized Loss Expectancy: 3.6 × $10M = $36M
  ──────────────────────────────────────────────────────────────────────
  PROPOSED CONTROL: AppSec program ($500K/year)
  Reduces vulnerability probability from 0.3 to 0.05
  New ALE: 12 × 0.05 × $10M = $6M
  Risk reduction: $30M
  ROI: ($30M - $500K) / $500K = 5,900%
```

**Step 2: Map to business objectives**

| Business Objective | Security Investment | Connection |
|---|---|---|
| Customer trust / revenue protection | Data protection, privacy program | Direct: breach = customer churn |
| Regulatory compliance | GRC platform, audit prep | Direct: non-compliance = fines + license risk |
| Digital transformation | Cloud security, DevSecOps | Enabler: secure cloud = faster innovation |
| M&A readiness | Security maturity, documentation | Due diligence requirement |
| IPO readiness | SOC 2, security program maturity | Market expectation, insurance rates |

**Step 3: Present as investment, not cost**

```
  FRAMING GUIDE

  Instead of              Say
  ──────────────────────  ─────────────────────────────────────────
  "Security costs $3M"    "Security program protects $300M revenue"
  "We need more tools"    "This closes 3 of our top 5 risk gaps"
  "Compliance requires"   "This enables us to enter [market/deal]"
  "Everyone is doing it"  "Our peers invest X, we invest Y, gap is Z"
  "We might get breached"  "Our ALE is $36M, this reduces it to $6M"
```

### Budget Categories

| Category | Typical % | Components |
|---|---|---|
| People | 40-50% | Salaries, training, contractors, managed services |
| Technology | 25-35% | Tools, licenses, cloud security services |
| Process | 10-15% | Assessments, audits, pen tests, consulting |
| Training & awareness | 5-10% | Security awareness platform, phishing sims, conferences |
| Incident response | 5-10% | Retainer, insurance, tabletop exercises |

---

## 5. Team Structure & Hiring

### Security Organization Models

#### Model 1: Centralized Security Team (50-500 employees)

```
  ┌─────────────────────────────────────────┐
  │                  CISO                    │
  ├───────────┬─────────────┬───────────────┤
  │ Security  │ GRC &       │ Application   │
  │ Operations│ Compliance  │ Security      │
  ├───────────┼─────────────┼───────────────┤
  │ SOC       │ Policy &    │ SAST/DAST     │
  │ analyst(s)│ standards   │ Pen testing   │
  │ Vuln mgmt │ Risk mgmt  │ Secure code   │
  │ IR        │ Audit prep  │ review        │
  │ EDR/SIEM  │ Privacy     │ Bug bounty    │
  └───────────┴─────────────┴───────────────┘
  Typical size: 3-8 people
  Key hire first: Senior security engineer (generalist)
```

#### Model 2: Distributed Security (500-5000 employees)

```
  ┌───────────────────────────────────────────────────────────────┐
  │                           CISO                                │
  ├───────────┬────────────┬────────────┬────────────┬───────────┤
  │ Security  │ Security   │ GRC &      │ Product    │ Security  │
  │ Operations│ Engineering│ Privacy    │ Security   │ Architecture│
  ├───────────┼────────────┼────────────┼────────────┼───────────┤
  │ SOC (T1-3)│ Detection  │ Policy     │ AppSec     │ Threat    │
  │ Threat    │ engineering│ Risk mgmt  │ DevSecOps  │ modeling  │
  │ hunting   │ Tool dev   │ Compliance │ Pen test   │ Zero trust│
  │ IR        │ Automation │ Privacy    │ Bug bounty │ Cloud sec │
  │ Vuln mgmt │ SOAR       │ Vendor risk│ Security   │ Review    │
  │           │            │            │ champions  │ board     │
  └───────────┴────────────┴────────────┴────────────┴───────────┘
  Typical size: 15-40 people
  Embedded security champions in each engineering team
```

#### Model 3: Enterprise Security (5000+ employees)

Add: Insider Threat Program, Red Team, Cyber Threat Intelligence, dedicated Cloud Security, OT/ICS Security, Physical Security convergence, regional/country security officers.

### Hiring Framework

**Role prioritization by maturity level:**

| Maturity | First Hires | Why |
|---|---|---|
| Level 1 (nothing) | Security engineer (generalist), GRC analyst | Need both hands-on and governance |
| Level 2 (basics) | SOC analyst, AppSec engineer | Detection and shift-left |
| Level 3 (defined) | Security architect, detection engineer | Strategy and advanced detection |
| Level 4 (managed) | Red team, threat intel, privacy engineer | Proactive and specialized |
| Level 5 (optimized) | Security data scientist, automation eng | Optimization and prediction |

**Interview Process for Security Roles**

Adapted from engineering management best practices (awesome-engineering-team-management):

1. **Initial screen**: Technical depth + communication ability. Can they explain a complex security concept to a non-technical person? [CONFIRMED] "The irony is that you don't really notice a great manager" applies equally to great security hires -- they make the organization better without drama.

2. **Technical assessment**: Scenario-based, not trivia.
   - "Walk me through how you would investigate this alert." (hand them a real SIEM log)
   - "Design the security architecture for this system." (whiteboard, not coding puzzle)
   - "This compliance audit found these gaps. How would you prioritize remediation?"

3. **Culture fit**: Blameless mindset, collaboration, teaching ability.
   - "Tell me about a time you disagreed with a security decision."
   - "How do you handle a developer who pushes back on a security finding?"

4. **[INFERRED] Anti-pattern from engineering management research**: "10x developers rapidly become 1x developers (or worse) if you don't let them make their own architectural choices." Same applies to security -- micromanaging security engineers kills their effectiveness and drives attrition.

**Retention Strategies:**

- Professional development budget ($3K-5K/year per person for training, certs, conferences)
- Rotation between security domains (prevent burnout, build T-shaped skills)
- Conference speaking support (visibility drives engagement)
- Career ladder with both management and individual contributor tracks
- Meaningful work allocation -- nobody wants to only write policies
- Autonomy on tooling and methodology choices within guardrails

**Security Champion Program (force multiplier):**

```
  SECURITY CHAMPION MODEL

  Security Team (5 people)
       │
       ├── Champion in Engineering Team A
       ├── Champion in Engineering Team B
       ├── Champion in Engineering Team C
       ├── Champion in DevOps/Platform
       ├── Champion in Data Engineering
       └── Champion in Product Management

  Each champion:
  - 10-20% of time on security activities
  - Attends monthly security champion meetup
  - First responder for security questions in their team
  - Participates in threat modeling sessions
  - Reviews security-relevant PRs
  - Escalates findings to security team

  ROI: 5 security FTEs + 10 champions ≈ impact of 8-10 security FTEs
```

---

## 6. Vendor Management & Tool Portfolio

### Security Tool Portfolio Design

Adapted from AWS security tool portfolio management principles (toniblyx/my-arsenal-of-aws-security-tools):

```
  SECURITY TOOL PORTFOLIO — COVERAGE MAP

  ┌─────────────────────────────────────────────────────────────┐
  │                    PREVENT                                   │
  ├──────────────┬────────────────┬──────────────────────────────┤
  │ Identity     │ Network        │ Endpoint                     │
  │ - IAM/PAM    │ - Firewall     │ - EDR/XDR                    │
  │ - SSO/MFA    │ - WAF          │ - MDM                        │
  │ - ZTNA       │ - DDoS protect │ - Patch mgmt                 │
  ├──────────────┴────────────────┴──────────────────────────────┤
  │                    DETECT                                     │
  ├──────────────┬────────────────┬──────────────────────────────┤
  │ SIEM/SOAR    │ NDR            │ Cloud                        │
  │ - Log mgmt   │ - Traffic      │ - CSPM                       │
  │ - Correlation│   analysis     │ - CWPP                       │
  │ - Automation │ - DNS monitor  │ - CASB                       │
  ├──────────────┴────────────────┴──────────────────────────────┤
  │                    ASSESS                                     │
  ├──────────────┬────────────────┬──────────────────────────────┤
  │ Vulnerability│ Application    │ Configuration                │
  │ - Scanner    │ - SAST         │ - CIS benchmark              │
  │ - Pen test   │ - DAST         │ - IaC scanning               │
  │ - ASM        │ - SCA          │ - Cloud config audit         │
  ├──────────────┴────────────────┴──────────────────────────────┤
  │                    RESPOND                                    │
  ├──────────────┬────────────────┬──────────────────────────────┤
  │ IR Platform  │ Forensics      │ Communication                │
  │ - Case mgmt  │ - Disk/memory  │ - Status page                │
  │ - Playbooks  │ - Log analysis │ - Notification               │
  │ - Evidence   │ - Timeline     │ - Legal coordination         │
  └──────────────┴────────────────┴──────────────────────────────┘
```

### Vendor Evaluation Criteria

| Criterion | Weight | Assessment Method |
|---|---|---|
| Problem-solution fit | 30% | Does it solve the actual gap, not a hypothetical one? |
| Integration capability | 20% | API quality, SIEM integration, SOAR compatibility |
| Total cost of ownership | 15% | License + headcount to operate + training + migration |
| Vendor viability | 10% | Revenue, funding, customer base, acquisition risk |
| Security of the product | 10% | SOC 2, pen test results, vulnerability history |
| Support quality | 10% | SLA, responsiveness, technical depth of support |
| Exit strategy | 5% | Data portability, contract termination terms |

### Vendor Risk Management Program

```
  VENDOR RISK TIERING

  Tier 1 (Critical):
    - Processes sensitive data
    - Has network access
    - Single point of failure
    → Full security assessment, annual review, contractual SLAs
    → SOC 2 Type II required, pen test results reviewed
    → Right to audit clause, breach notification SLA (24hr)

  Tier 2 (Important):
    - Processes non-sensitive data
    - Limited system access
    - Alternatives available
    → Security questionnaire, biennial review
    → SOC 2 Type I or ISO 27001 required
    → Standard breach notification terms

  Tier 3 (Standard):
    - No data processing
    - No system access
    - Easily replaceable
    → Self-attestation, review on renewal
    → Basic security controls verified
```

### Build vs. Buy Decision Matrix

| Factor | Build | Buy | Managed Service |
|---|---|---|---|
| Customization need | High | Low-Medium | Low |
| Time to value | Months | Weeks | Days |
| Ongoing maintenance | High (your team) | Medium (updates) | Low (vendor) |
| TCO (3-year) | Often highest | Moderate | Varies |
| Control | Maximum | Some | Least |
| Best for | Core differentiator, unique requirements | Standard problems, proven solutions | Staff-limited teams, commodity functions |

---

## 7. Incident Communication Framework

### Communication Tiers by Audience

```
  INCIDENT COMMUNICATION — AUDIENCE MATRIX

  ┌────────────┬────────────────┬──────────────┬───────────────┐
  │  Audience  │  What They     │  When         │  Format       │
  │            │  Need          │               │               │
  ├────────────┼────────────────┼──────────────┼───────────────┤
  │ Board      │ Business impact│ Major         │ Executive     │
  │            │ Risk exposure  │ incidents     │ briefing      │
  │            │ Legal exposure │ only          │ (1 page max)  │
  ├────────────┼────────────────┼──────────────┼───────────────┤
  │ C-Suite    │ Operational    │ All material  │ Situation     │
  │            │ impact, ETA    │ incidents     │ report        │
  │            │ Actions needed │              │ (15 min brief)│
  ├────────────┼────────────────┼──────────────┼───────────────┤
  │ Legal      │ Evidence,      │ Any involving │ Privileged    │
  │ Counsel    │ notification   │ data, legal   │ communication │
  │            │ obligations    │ risk          │               │
  ├────────────┼────────────────┼──────────────┼───────────────┤
  │ Regulators │ Required       │ Per statute   │ Formal        │
  │            │ disclosures,   │ (GDPR: 72hr,  │ notification  │
  │            │ remediation    │ SEC: 4 biz    │ (template)    │
  │            │                │ days)         │               │
  ├────────────┼────────────────┼──────────────┼───────────────┤
  │ Customers  │ What happened, │ If their data │ Public        │
  │            │ what to do,    │ affected      │ notification, │
  │            │ empathy        │               │ direct email  │
  ├────────────┼────────────────┼──────────────┼───────────────┤
  │ Employees  │ Awareness,     │ All incidents │ Internal      │
  │            │ actions needed │ with business │ comms, all-   │
  │            │                │ impact        │ hands if major│
  ├────────────┼────────────────┼──────────────┼───────────────┤
  │ Media      │ Facts, not     │ Public        │ Press release,│
  │            │ speculation    │ incidents     │ prepared      │
  │            │                │               │ statement     │
  └────────────┴────────────────┴──────────────┴───────────────┘
```

### Board Incident Briefing Template

```
  SECURITY INCIDENT — BOARD BRIEFING
  Date: [date] | Severity: [Critical/High/Medium]
  ──────────────────────────────────────────────

  WHAT HAPPENED (2-3 sentences)
  [Plain language description of the incident]

  BUSINESS IMPACT
  - Data affected: [types, volume]
  - Systems affected: [which, duration]
  - Customer impact: [scope]
  - Financial impact: [estimated]

  CURRENT STATUS
  - Contained: [Yes/No/Partial]
  - Root cause identified: [Yes/No/Working]
  - Eradication complete: [Yes/No/In progress]

  REGULATORY OBLIGATIONS
  - Notification required: [Yes/No/Assessing]
  - Deadline: [date]
  - Status: [Notified/Preparing/Not yet required]

  IMMEDIATE ACTIONS TAKEN
  1. [action]
  2. [action]
  3. [action]

  DECISIONS NEEDED FROM BOARD
  - [specific decision with recommendation]

  NEXT UPDATE: [date/time]
```

### Customer Notification Principles

**Do:**
- Lead with empathy: "We take the security of your data seriously"
- Be specific about what happened and what data was affected
- Tell them exactly what to do (change password, monitor accounts, etc.)
- Provide a timeline of events and your response
- Offer concrete remediation (credit monitoring, etc.)
- Provide a dedicated contact for questions

**Do not:**
- Use passive voice to obscure responsibility ("data was accessed" vs. "an attacker accessed data")
- Bury the news in legal language
- Blame the customer or a third party in the initial notification
- Speculate about the attacker or their motives
- Delay notification to "have all the facts" beyond regulatory timelines

### Regulatory Notification Timelines

| Regulation | Timeline | To Whom | Key Requirements |
|---|---|---|---|
| GDPR Art. 33 | 72 hours from awareness | Supervisory authority | Nature, categories, approximate numbers, consequences, measures |
| GDPR Art. 34 | Without undue delay | Data subjects (if high risk) | Clear/plain language, same as Art. 33 |
| SEC (2023 rules) | 4 business days from materiality determination | SEC via Form 8-K | Material cybersecurity incidents |
| HIPAA | 60 days from discovery | HHS, individuals, media (if >500) | Breach of unsecured PHI |
| CCPA | "Expedient time" | California residents | Categories of data, what happened |
| State laws (US) | Varies (30-90 days typical) | AG, consumers | Varies by state (50+ different laws) |

---

## 8. Security Culture Development

### Culture as a Security Control

[CONFIRMED] From engineering management research: "The actual company values, as opposed to the nice-sounding values, are shown by who gets rewarded, promoted, or let go." (Netflix Culture) -- This applies directly to security culture. If you reward velocity over security, your culture is insecure regardless of your stated policies.

### Security Culture Maturity Model

```
  CULTURE MATURITY PROGRESSION

  Level 1: COMPLIANCE-DRIVEN
  │  "We do security because we have to"
  │  - Security as checkbox
  │  - Blame when things go wrong
  │  - Security team as police
  │
  Level 2: AWARENESS-DRIVEN
  │  "We know security matters"
  │  - Annual training completed
  │  - Some developers care
  │  - Security still a bottleneck
  │
  Level 3: OWNERSHIP-DRIVEN
  │  "Security is part of our job"
  │  - Security champions active
  │  - Developers run SAST themselves
  │  - Blameless post-mortems
  │  - Security in sprint planning
  │
  Level 4: EMBEDDED
  │  "Security is how we build"
  │  - Threat modeling is standard
  │  - Engineers propose security improvements
  │  - Security metrics in team dashboards
  │  - Security is a hiring criterion
  │
  Level 5: PROACTIVE
     "We anticipate and prevent"
     - Red team exercises welcomed
     - Bug bounty embraced
     - Security innovation from all teams
     - Continuous improvement culture
```

### Culture-Building Tactics

**Positive reinforcement:**
- Public recognition for security bug reports from non-security staff
- "Security Champion of the Quarter" award
- Gamified security training with leaderboards
- Bug bounty participation bonuses for internal staff

**Structural integration:**
- Security criteria in code review checklists
- Threat modeling as a design review gate
- Security metrics in engineering team OKRs
- Security retrospective in every post-incident review

**Removing friction:**
- Pre-approved security libraries and patterns ("paved road")
- Self-service security scanning in CI/CD
- Security office hours (drop-in, not gatekeeping)
- Quick-turnaround security review SLA (48hr for standard, 4hr for urgent)

**[INFERRED] From awesome-engineering-team-management: "Giving developers operational responsibilities has greatly enhanced the quality of the services" (Amazon/Vogels) -- Apply the "you build it, you secure it" principle. Teams that own their security posture produce more secure code than teams policed by an external security function.**

### Blameless Post-Incident Culture

Adapted from engineering management principles on psychological safety:

```
  BLAMELESS POST-INCIDENT REVIEW FORMAT

  1. TIMELINE (facts only, no judgments)
     [timestamp] [event] [who noticed] [action taken]

  2. ROOT CAUSE ANALYSIS
     - Contributing factor 1 (system/process, NOT person)
     - Contributing factor 2
     - Contributing factor 3
     Five Whys until you reach a systemic issue

  3. WHAT WENT WELL
     - [detection, response, communication wins]

  4. WHAT CAN BE IMPROVED
     - [systemic improvements, NOT "person X should have..."]

  5. ACTION ITEMS
     - [specific, assigned, deadlined improvements]
     - Detection rule added? Y/N
     - Runbook updated? Y/N
     - Control gap closed? Y/N

  RULE: If your post-incident review mentions a person's name
  in a negative context, rewrite it as a system failure.

  "Alice didn't check the backup" → "Backup verification was manual
  with no automated monitoring."
```

---

## 9. Threat Modeling at Organizational Scale

### OWASP Four-Question Framework for Program Design

From OWASP Threat Modeling Cheat Sheet, scaled to organizational level:

1. **"What are we working on?"** -- Maintain a living system architecture with data flow diagrams. Every new service, integration, or data flow gets a DFD before development begins.

2. **"What can go wrong?"** -- Use STRIDE (per-element) as the default methodology. Supplement with LINDDUN for privacy-sensitive systems, PASTA for high-risk systems requiring CTI integration.

3. **"What are we going to do about it?"** -- Risk treatment decisions: mitigate, eliminate, transfer, accept. Every "accept" requires CISO sign-off and board-level visibility if the risk is rated High or above.

4. **"Did we do a good enough job?"** -- Validation through security testing (pen test, red team), detection coverage mapping, and incident correlation.

### Scaling Threat Modeling Across the Organization

```
  THREAT MODELING PROGRAM STRUCTURE

  ┌──────────────────────────────────────────────────┐
  │ Security Team                                     │
  │ - Maintains methodology and templates             │
  │ - Leads threat models for critical systems        │
  │ - Trains and coaches champions                    │
  │ - Reviews and approves risk acceptances            │
  │ - Tracks coverage and quality metrics             │
  └────────────────────┬─────────────────────────────┘
                       │
  ┌────────────────────┼─────────────────────────────┐
  │                    │                              │
  ▼                    ▼                              ▼
  Security          Security                       Security
  Champion          Champion                       Champion
  (Team A)          (Team B)                       (Team C)
  │                    │                              │
  ▼                    ▼                              ▼
  Leads threat       Leads threat                  Leads threat
  models for         models for                    models for
  their team's       their team's                  their team's
  services           services                      services
```

**When to threat model (triggers):**
- New service or application
- New integration or data flow
- Significant architecture change
- New authentication/authorization mechanism
- Handling new data classification (e.g., now processing PII)
- Post-incident (was this threat modeled? Why not?)

**Measuring threat modeling effectiveness:**
- Coverage: % of services with current threat model
- Quality: % of pen test findings that were predicted by threat model
- Velocity: Average time from design to completed threat model
- Adoption: % of threat models led by champions vs. security team
- Incident correlation: % of incidents in non-threat-modeled systems vs. modeled ones

### Tools for Scale

| Tool | Best For | Cost |
|---|---|---|
| OWASP Threat Dragon | Simple DFD-based models, open source | Free |
| Microsoft Threat Modeling Tool | STRIDE-per-element, Windows ecosystem | Free |
| IriusRisk | Enterprise scale, automated threats, compliance mapping | Commercial |
| pytm | Code-defined threat models, CI/CD integration | Free |
| Threat Composer (AWS) | Cloud-native threat modeling | Free |
| draw.io | Quick diagrams, low barrier to entry | Free |

---

## 10. Bug Bounty & External Testing Programs

### Program Design from Leadership Perspective

```
  BUG BOUNTY PROGRAM MATURITY

  Phase 1: PRIVATE PROGRAM (Year 1)
  ├── Invite-only (20-50 researchers)
  ├── Define scope carefully (start narrow)
  ├── Establish triage process and SLAs
  ├── Set bounty ranges ($100 - $10K)
  ├── Build internal response capability
  └── Measure: submissions, valid %, fix time

  Phase 2: EXPANDED PRIVATE (Year 2)
  ├── Expand to 100-500 researchers
  ├── Broader scope
  ├── Increase bounty ranges
  ├── Published scope and rules
  └── Measure: unique vuln classes, repeat researchers

  Phase 3: PUBLIC PROGRAM (Year 3+)
  ├── Open to all researchers
  ├── Full scope coverage
  ├── Premium bounties for critical findings
  ├── VDP (Vulnerability Disclosure Program) as baseline
  └── Measure: cost per valid finding vs. pen test
```

### Platform Selection

| Platform | Strength | Model |
|---|---|---|
| HackerOne | Largest researcher community, enterprise features | Managed + self-service |
| Bugcrowd | Curated researchers, pen test integration | Managed + self-service |
| Intigriti | European focus, GDPR-aware | Managed |
| Cobalt | Pen test + bug bounty hybrid | Managed |
| YesWeHack | European, sovereign options | Managed |

### Cost-Effectiveness Analysis

```
  COMPARISON: PEN TEST vs BUG BOUNTY vs RED TEAM

  ┌──────────────┬──────────┬──────────────┬──────────────┐
  │              │ Pen Test │ Bug Bounty   │ Red Team     │
  ├──────────────┼──────────┼──────────────┼──────────────┤
  │ Cost model   │ Fixed    │ Pay per vuln │ Fixed        │
  │ Typical cost │ $20-80K  │ $10-100K/yr  │ $50-200K     │
  │ Duration     │ 1-3 weeks│ Continuous   │ 2-6 weeks    │
  │ Coverage     │ Defined  │ Broad, crowd │ Targeted     │
  │              │ scope    │ sourced      │ objectives   │
  │ Finding type │ Standard │ Creative,    │ Real-world   │
  │              │ vulns    │ edge cases   │ attack paths │
  │ Best for     │ Compli-  │ Continuous   │ Detecting    │
  │              │ ance     │ assessment   │ defense gaps │
  │ Compliance   │ Yes      │ Supplement   │ Supplement   │
  └──────────────┴──────────┴──────────────┴──────────────┘
```

---

## 11. AppSec Program Building

### SDLC Security Integration

```
  SECURE SDLC — ACTIVITY MAP

  PLAN          DESIGN        DEVELOP       TEST          DEPLOY        OPERATE
  │             │             │             │             │             │
  ├─Security    ├─Threat      ├─SAST        ├─DAST        ├─Container   ├─RASP
  │ requirements│ modeling    │ (in IDE +   │ (staging)   │ scanning    │ WAF
  │             │             │  CI/CD)     │             │             │
  ├─Risk        ├─Security   ├─SCA         ├─Pen test    ├─IaC         ├─Vuln
  │ assessment  │ architecture│ (dependency)│             │ scanning    │ mgmt
  │             │ review      │             │             │             │
  ├─Compliance  ├─Privacy    ├─Secret      ├─Fuzz test   ├─Config      ├─Bug
  │ mapping     │ review      │ scanning    │             │ review      │ bounty
  │             │             │             │             │             │
  └─Abuse case  └─Secure     └─Peer review └─Compliance  └─Change      └─Monitor
    development   design       (security    verification   mgmt         & respond
                  patterns     checklist)
```

### AppSec Metrics for Leadership

| Metric | Target | Why It Matters |
|---|---|---|
| Mean time to remediate critical vulns | < 7 days | Measures organizational responsiveness |
| % of repos with SAST in CI/CD | 100% | Coverage of shift-left controls |
| SCA: known vulnerable dependencies | < 5 critical | Supply chain risk indicator |
| Pen test finding recurrence rate | < 10% | Measures whether fixes stick |
| Developer security training completion | > 90% | Leading indicator of code quality |
| Security debt ratio | Trending down | Critical vulns / total backlog items |

### Paved Road Approach

From paragonie/awesome-appsec principles -- make the secure path the easy path:

```
  PAVED ROAD STRATEGY

  Instead of                    Provide
  ───────────────────────────   ────────────────────────────────
  "Don't use raw SQL"           Pre-built ORM patterns, approved query library
  "Validate all input"          Input validation middleware, schema validation
  "Don't hardcode secrets"      Secret manager integration, env injection
  "Use HTTPS"                   TLS termination at load balancer, auto-certs
  "Encrypt PII at rest"         Approved encryption library with key rotation
  "Don't roll your own auth"    SSO/OAuth library, auth middleware
  "Do threat modeling"          Templates, facilitation guides, trained champions
  "Write secure code"           Language-specific secure coding standards + linters
```

---

## 12. Cloud Security Program

### Cloud Security Tool Portfolio

Derived from toniblyx/my-arsenal-of-aws-security-tools, generalized for multi-cloud:

```
  CLOUD SECURITY CAPABILITY MAP

  ┌─────────────────────────────────────────────────────────────┐
  │                  CLOUD SECURITY PROGRAM                      │
  ├────────────────┬────────────────┬────────────────────────────┤
  │ POSTURE MGMT   │ WORKLOAD       │ DATA SECURITY              │
  │ (CSPM)         │ PROTECTION     │                            │
  │                │ (CWPP)         │                            │
  │ - Misconfig    │ - Runtime      │ - Classification           │
  │   detection    │   protection   │ - Encryption mgmt          │
  │ - CIS bench-   │ - Container    │ - DLP                      │
  │   marks        │   security     │ - Key management           │
  │ - Compliance   │ - Serverless   │ - Access logging           │
  │   monitoring   │   security     │                            │
  ├────────────────┼────────────────┼────────────────────────────┤
  │ IAM SECURITY   │ NETWORK        │ FORENSICS &                │
  │                │ SECURITY       │ INCIDENT RESPONSE          │
  │ - Privilege    │ - VPC/NSG      │ - CloudTrail / audit       │
  │   analysis     │   analysis     │   log analysis             │
  │ - Permission   │ - Traffic      │ - Snapshot forensics       │
  │   boundaries   │   monitoring   │ - Automated response       │
  │ - Unused       │ - DNS security │ - Evidence preservation    │
  │   credentials  │                │                            │
  ├────────────────┼────────────────┼────────────────────────────┤
  │ IaC SECURITY   │ SUPPLY CHAIN   │ COST & GOVERNANCE          │
  │                │                │                            │
  │ - Terraform    │ - SBOM         │ - Unused resource          │
  │   scanning     │ - Container    │   detection                │
  │ - CloudForm    │   image scan   │ - Tag compliance           │
  │   validation   │ - Registry     │ - Budget alerts            │
  │ - Policy as    │   security     │ - Org-level policies       │
  │   code (OPA)   │                │                            │
  └────────────────┴────────────────┴────────────────────────────┘
```

### Open Source vs. Commercial Decision

| Capability | Open Source Options | Commercial Options | Recommendation |
|---|---|---|---|
| CSPM | Prowler, ScoutSuite, CloudMapper | Wiz, Orca, Prisma Cloud | Open source to start, commercial at scale |
| IAM Analysis | PMapper, CloudSplaining | Sonrai, Ermetic | Open source adequate for most |
| IaC Scanning | Checkov, tfsec, KICS | Bridgecrew (now Prisma), Snyk IaC | Checkov is excellent and free |
| Container Scan | Trivy, Grype | Aqua, Sysdig | Trivy is production-grade |
| Runtime | Falco | Sysdig, Aqua | Falco for Kubernetes, commercial for full CWPP |

---

## 13. Cognitive Mode Framework Applied to Security Programs

### Gstack's Core Insight

From analyzing gstack (Garry Tan's cognitive mode framework for Claude Code): **Different problems require different modes of thinking. Blurring them produces mediocrity.**

Gstack defines explicit cognitive modes:
- **/plan-ceo-review**: Founder mode -- challenge premises, find the 10x product
- **/plan-eng-review**: Engineering rigor -- architecture, failure modes, edge cases
- **/review**: Paranoid reviewer -- what will break in production
- **/ship**: Execution -- stop talking, land it
- **/qa**: Testing -- systematic verification
- **/retro**: Retrospective -- data-driven learning

### Applying Cognitive Modes to Security Program Management

```
  SECURITY PROGRAM COGNITIVE MODES

  ┌──────────────────────────────────────────────────────────────┐
  │  MODE          │  SECURITY APPLICATION                       │
  ├──────────────────────────────────────────────────────────────┤
  │                │                                             │
  │  CEO/FOUNDER   │  SECURITY STRATEGY                          │
  │  MODE          │                                             │
  │                │  "Are we even solving the right security    │
  │                │   problem?"                                 │
  │                │                                             │
  │                │  - Challenge whether security investments   │
  │                │    match actual risk, not compliance theater│
  │                │  - Ask: "What is the 10-star security       │
  │                │    program for our business?"               │
  │                │  - Scope expansion: What adjacent security  │
  │                │    capabilities would 10x our posture for   │
  │                │    2x the investment?                        │
  │                │  - Challenge: Are we building security      │
  │                │    infrastructure or just buying tools?      │
  │                │                                             │
  │  KEY QUESTIONS:                                              │
  │  • What would make our security program a competitive       │
  │    advantage, not just a cost center?                        │
  │  • If we were breached tomorrow, would our program have     │
  │    made any real difference?                                 │
  │  • What is the experience of a developer interacting with   │
  │    our security team? Is it empowering or obstructive?       │
  │  • What would a new CISO hired in 6 months think of what    │
  │    we've built?                                              │
  ├──────────────────────────────────────────────────────────────┤
  │                │                                             │
  │  ENG MANAGER   │  SECURITY PROGRAM EXECUTION                 │
  │  MODE          │                                             │
  │                │  "Make the security strategy buildable."    │
  │                │                                             │
  │                │  - Architecture: tool integration, data     │
  │                │    flows, detection pipeline design          │
  │                │  - Failure modes: what breaks when SIEM     │
  │                │    ingestion lags? When analyst quits?       │
  │                │  - Edge cases: what happens during M&A      │
  │                │    when you inherit 500 unmanaged assets?    │
  │                │  - Diagrams: detection coverage maps,       │
  │                │    security architecture, data flow for     │
  │                │    incident response                         │
  │                │  - Test coverage: tabletop exercises,       │
  │                │    purple team validation, control testing   │
  │                │                                             │
  │  KEY OUTPUTS:                                                │
  │  • Security architecture diagrams                            │
  │  • Detection coverage heat map (vs. ATT&CK)                 │
  │  • Failure mode registry for every security control          │
  │  • Dependency graph of security tools and integrations       │
  │  • Test matrix: which scenarios validate which controls      │
  ├──────────────────────────────────────────────────────────────┤
  │                │                                             │
  │  PARANOID      │  SECURITY ASSURANCE                         │
  │  REVIEW MODE   │                                             │
  │                │  "What can still break?"                    │
  │                │                                             │
  │                │  - Red team findings review                 │
  │                │  - Pen test result triage                   │
  │                │  - Detection gap analysis                   │
  │                │  - Policy exception review                  │
  │                │  - Vendor security assessment review         │
  │                │  - Post-incident: what did we miss?          │
  │                │                                             │
  │  KEY QUESTIONS:                                              │
  │  • What attack paths exist that bypass our controls?         │
  │  • Which security tools would fail silently?                 │
  │  • Where are we trusting vendor claims without verification? │
  │  • Which compliance controls are theater vs. real defense?   │
  ├──────────────────────────────────────────────────────────────┤
  │                │                                             │
  │  SHIP MODE     │  SECURITY DELIVERY                          │
  │                │                                             │
  │                │  "Stop planning. Deploy the control."       │
  │                │                                             │
  │                │  - Policy approved? Publish it.              │
  │                │  - Detection rule tested? Deploy it.         │
  │                │  - Vendor selected? Sign and integrate.      │
  │                │  - Patch available? Push it.                  │
  │                │  - Board report drafted? Present it.         │
  │                │                                             │
  │  ANTI-PATTERN: Security teams that plan perpetually and      │
  │  never ship. A 70% control deployed today beats a 100%       │
  │  control deployed never.                                     │
  ├──────────────────────────────────────────────────────────────┤
  │                │                                             │
  │  QA MODE       │  SECURITY VALIDATION                        │
  │                │                                             │
  │                │  - Control effectiveness testing            │
  │                │  - Purple team exercises                    │
  │                │  - Tabletop exercise execution              │
  │                │  - Compliance evidence verification         │
  │                │  - Phishing simulation analysis             │
  │                │  - Backup restoration testing               │
  │                │                                             │
  ├──────────────────────────────────────────────────────────────┤
  │                │                                             │
  │  RETRO MODE    │  SECURITY PROGRAM RETROSPECTIVE             │
  │                │                                             │
  │                │  - Monthly security metrics review          │
  │                │  - Incident trend analysis                  │
  │                │  - Team velocity and health                 │
  │                │  - Tool ROI assessment                      │
  │                │  - What improved? What degraded?            │
  │                │  - Per-person: praise and growth areas      │
  │                │                                             │
  │  METRICS:                                                    │
  │  • Incidents: count, severity, MTTD, MTTR trends            │
  │  • Vulnerabilities: open count, SLA compliance, recurrence  │
  │  • Detection: new rules, coverage %, false positive rate    │
  │  • Team: utilization, training completed, certifications    │
  │  • Vendor: SLA compliance, ticket resolution time           │
  └──────────────────────────────────────────────────────────────┘
```

### Gstack's Plan-CEO-Review Applied to Security Decisions

The `/plan-ceo-review` framework includes powerful decision-making structures that map directly to security program design:

**Step 0: Nuclear Scope Challenge**

Apply to every major security initiative:

```
  0A. PREMISE CHALLENGE
  - Is this the right security problem to solve?
  - What is the actual business outcome?
  - What would happen if we did nothing? Real risk or theoretical?

  0B. EXISTING LEVERAGE
  - What existing controls already partially address this?
  - Are we rebuilding something that already exists?

  0C. DREAM STATE MAPPING
  CURRENT STATE         THIS INITIATIVE         12-MONTH IDEAL
  [current posture] --> [what changes]      --> [target state]

  0D. MODE SELECTION
  - EXPANSION: Our security program could be a differentiator
  - HOLD SCOPE: Our coverage is right, make it bulletproof
  - REDUCTION: We're overbuilt in areas that don't match risk
```

**Prime Directives applied to security:**

1. **Zero silent failures** -- Every security control must have monitoring for when it fails. A WAF that silently stops inspecting traffic is worse than no WAF.

2. **Every error has a name** -- Don't say "improve incident response." Name: which incident type, which playbook, which detection rule, which analyst skill gap.

3. **Data flows have shadow paths** -- Every data protection control must account for: nil input (no data classification tag), empty input (metadata without content), upstream error (classification service down).

4. **Observability is scope, not afterthought** -- Security dashboards, alerts, and runbooks are first-class deliverables for every security project.

5. **Optimize for the 6-month future** -- If this security control solves today's compliance requirement but creates next quarter's operational nightmare (100 false positives/day), say so.

### Engineering Preferences Applied to Security Teams

From gstack's engineering preferences, adapted:

| Engineering Preference | Security Application |
|---|---|
| DRY -- flag repetition aggressively | Do not maintain duplicate detection rules across SIEM instances. Single source of truth for policies. |
| Well-tested is non-negotiable | Every detection rule has a test case. Every IR playbook has a tabletop. |
| Engineered enough, not over/under | Controls proportional to risk. Don't deploy CASB for 10-person startup. Don't skip MFA for 10,000-person enterprise. |
| Handle more edge cases, not fewer | Adversaries live in edge cases. The unusual auth pattern. The after-hours access. The slightly-modified malware hash. |
| Explicit over clever | Security policies in plain language. Detection logic documented and reviewable. No "magic" blackbox controls. |
| Minimal diff | Achieve the security goal with fewest new tools and processes. Extend existing controls before buying new ones. |

---

## 14. Security Career Progression to Leadership

### Career Path: Practitioner to CISO

```
  CAREER PROGRESSION — SECURITY LEADERSHIP TRACK

  YEARS 0-3: FOUNDATION
  ├── Security analyst / SOC analyst / pen tester
  ├── Core certifications: GIAC (GSEC, GCIH) or CompTIA (Security+, CySA+)
  ├── Focus: deep technical skills in 1-2 domains
  ├── Key skill: "Can you do the work?"
  └── Reading: OWASP, NIST 800 series, ATT&CK framework

  YEARS 3-7: SENIOR PRACTITIONER
  ├── Senior security engineer / security architect / team lead
  ├── Certifications: OSCP, GIAC Gold, cloud security certs
  ├── Focus: breadth across domains, mentoring juniors
  ├── Key skill: "Can you design solutions to security problems?"
  └── Start: writing, speaking, contributing to community

  YEARS 7-12: MANAGEMENT TRANSITION
  ├── Security manager / director / VP of Security
  ├── Certifications: CISSP, CISM, MBA or equivalent
  ├── Focus: people management, budget, strategy, executive communication
  ├── Key skill: "Can you build and lead a team?"
  ├── Critical shift: from doing the work to enabling others
  └── [CONFIRMED] "Management is not a promotion. It is a career change."

  YEARS 12+: EXECUTIVE
  ├── CISO / CSO
  ├── Focus: business strategy, board communication, risk quantification
  ├── Key skill: "Can you translate security into business language?"
  ├── Certifications: NACD CERT (board governance), FAIR certification
  └── Peer network: IANS, Evanta CISO community, CISO forums
```

### Skills Matrix: Technical vs. Leadership

```
  SKILL BALANCE BY CAREER STAGE

  100% │ ████
       │ ████ ██
       │ ████ ████
   T   │ ████ ████ ████
   E   │ ████ ████ ████ ██
   C   │ ████ ████ ████ ████
   H   │ ████ ████ ████ ████ ██
       │ ████ ████ ████ ████ ████
       │─────┼─────┼─────┼─────┼─────
       │     │     │     │     │████
       │     │     │     │████ ████
   L   │     │     │████ ████ ████
   E   │     │██   ████ ████ ████
   A   │     │████ ████ ████ ████
   D   │     │████ ████ ████ ████
       │     │████ ████ ████ ████
   0% ─┴─────┴─────┴─────┴─────┴─────
       Analyst Sr.Eng Manager Director CISO

  Legend: Technical depth decreases; leadership breadth increases
  Critical: Never go to zero on technical -- credibility requires it
```

### Study Plan for Security Leadership

Adapted from jassics/security-study-plan:

| Domain | Resources | Time Investment |
|---|---|---|
| Risk quantification | FAIR Institute, Open FAIR standard | 40 hours |
| Executive communication | Board presentation workshops, NACD materials | 20 hours |
| Business acumen | MBA-level finance, strategy | 100+ hours |
| People management | awesome-engineering-team-management, Manager's Path | 40 hours |
| Regulatory landscape | GDPR, CCPA, SEC rules, industry-specific | 60 hours |
| Vendor management | Contract negotiation, SOC 2 review, TPRM frameworks | 30 hours |
| Incident management | NIST 800-61, tabletop facilitation, crisis comms | 30 hours |
| Governance frameworks | NIST CSF, ISO 27001, COBIT | 40 hours |

---

## 15. CISO Failure Modes & Anti-Patterns

### Common CISO Failure Modes

Derived from engineering management anti-patterns (awesome-engineering-team-management), adapted for security:

```
  FAILURE MODE 1: THE TOOL COLLECTOR
  ─────────────────────────────────────
  Symptom:  Buys every security tool, integrates none well
  Root:     Confuses tool acquisition with risk reduction
  Fix:      Capability-based planning. Map gaps first, then select tools.
            Kill tools with low ROI annually.

  FAILURE MODE 2: THE COMPLIANCE CHECKBOX
  ─────────────────────────────────────
  Symptom:  Program optimized for audit, not for defense
  Root:     Confuses compliance with security
  Fix:      Measure detection and response capabilities separately
            from compliance status. Ask: "Would this control stop
            an actual attacker?"

  FAILURE MODE 3: THE TECHNICAL DINOSAUR
  ─────────────────────────────────────
  Symptom:  CISO still configures firewalls, reviews every alert
  Root:     Has not made the management transition
  Fix:      Delegate technical work. Focus on strategy, communication,
            and team development. Your job is enabling the team, not
            doing the work.

  FAILURE MODE 4: THE FUD MERCHANT
  ─────────────────────────────────────
  Symptom:  Every board presentation is a fear pitch
  Root:     Cannot quantify risk or articulate business value
  Fix:      FAIR training. Benchmark-based reporting. Lead with
            risk reduction, not fear.

  FAILURE MODE 5: THE YES-MAN
  ─────────────────────────────────────
  Symptom:  Accepts every risk exception, never pushes back
  Root:     Prioritizes relationships over security
  Fix:      Document every risk acceptance with quantified impact.
            Make risk owners sign. Report aggregate accepted risk
            to the board.

  FAILURE MODE 6: THE NO-GATE
  ─────────────────────────────────────
  Symptom:  Security blocks everything, seen as obstacle
  Root:     Confuses security with control
  Fix:      Paved road approach. Offer secure alternatives, not
            just rejections. SLA-bound review process.
            "Yes, and here's how to do it securely."

  FAILURE MODE 7: THE ISLAND
  ─────────────────────────────────────
  Symptom:  Security team disconnected from engineering/business
  Root:     No embedded relationships, security seen as external
  Fix:      Security champions, joint planning, shared OKRs,
            security engineer embedded in product teams.

  FAILURE MODE 8: THE PERFECTIONIST
  ─────────────────────────────────────
  Symptom:  Nothing ships because nothing is secure enough
  Root:     Cannot accept residual risk, cannot prioritize
  Fix:      Risk-based approach. Deploy 70% control now, iterate.
            Perfect is the enemy of deployed.
            From gstack: "A branch dies when the interesting work
            is done and only the boring release work is left."
            Same applies to security controls.
```

### The Management Transition Challenge

From engineering management literature, the most critical insight for security leaders:

> "A computer can never be held accountable. Therefore a computer must never make a management decision." -- IBM, 1979

**For CISOs, rewritten**: A security tool can never be held accountable. Therefore a security tool must never make a security program decision. Tools detect and prevent. Leaders decide, prioritize, communicate, and build organizations.

**The shift that most CISOs struggle with:**

```
  WHAT YOU STOP DOING          WHAT YOU START DOING
  ─────────────────────────    ─────────────────────────────
  Writing detection rules      Defining detection strategy
  Running pen tests            Building pen test programs
  Configuring tools            Evaluating and selecting tools
  Investigating incidents      Leading incident response programs
  Finding vulnerabilities      Managing vulnerability programs
  Reviewing code               Building AppSec culture
  All the technical work       Enabling the team to do technical work
```

**[CONFIRMED] "The manager's function is not to make people work, but to make it possible for people to work." (Tom DeMarco) -- This is the essence of the CISO role. Not to secure the organization personally, but to build the organization that secures itself.**

### Measuring Your Own Effectiveness as CISO

| Signal | Healthy | Unhealthy |
|---|---|---|
| Board engagement | Board asks good questions, understands risk | Board rubber-stamps, disengaged |
| Team retention | Low turnover, internal promotions | Constant hiring, burnout, exits |
| Business relationship | Consulted early in projects | Consulted last, seen as blocker |
| Incident readiness | Tabletops smooth, team confident | Panic during incidents, no playbooks |
| Risk register | Living document, drives decisions | Shelfware, updated for audits only |
| Security culture | Developers report vulns proactively | Developers hide security issues |
| Budget conversations | Investment-framed, ROI-based | Cost-center, constant justification |
| Personal technical depth | Stay current enough for credibility | Either too deep (doing, not leading) or too shallow (lost credibility) |

---

## Appendix A: Key Reference Documents

| Resource | Type | Primary Use |
|---|---|---|
| NIST CSF 2.0 | Framework | Program structure, maturity assessment, governance |
| NIST 800-53 | Controls catalog | Control selection, compliance mapping |
| NIST 800-61 | IR guide | Incident response program design |
| ISO 27001/27002 | Standard | Certification, control implementation |
| CIS Controls v8 | Prioritized controls | Implementation priority, benchmarking |
| FAIR | Risk model | Risk quantification for board/budget |
| MITRE ATT&CK | Threat framework | Detection coverage mapping |
| OWASP Top 10 | AppSec risks | Application security program prioritization |
| Verizon DBIR | Annual report | Threat landscape, peer benchmarking |
| SANS CISO Mind Map | Reference | Role scope, domain coverage check |

## Appendix B: Recommended Reading for Security Leaders

| Book | Author | Focus |
|---|---|---|
| *The Manager's Path* | Camille Fournier | Engineering management (applicable to security leadership) |
| *High Output Management* | Andy Grove | Management fundamentals, leverage, delegation |
| *How to Measure Anything in Cybersecurity Risk* | Douglas Hubbard | FAIR-based risk quantification |
| *Security Engineering* | Ross Anderson | Deep technical + policy perspective |
| *The CISO Evolution* | Matthew K. Sharp | Modern CISO role definition |
| *Building a World-Class Security Operations Center* | Carson Zimmerman (MITRE) | SOC design and management |
| *Tribe of Hackers: Security Leaders* | Marcus Carey | CISO interviews, diverse perspectives |
| *An Elegant Puzzle* | Will Larson | Systems thinking for engineering leaders |

## Appendix C: Engineering Management Principles for Security Leaders

Key insights extracted from awesome-engineering-team-management applicable to security program management:

1. **Psychological safety** (Google's Project Aristotle): Security teams must feel safe reporting failures. If analysts hide missed detections, your program degrades silently. Blameless post-mortems are not optional.

2. **Autonomy, mastery, purpose** (Daniel Pink): Security engineers need autonomy (choose their tools and methods within guardrails), mastery (time for research and skill development), and purpose (connection to protecting real users, not just checking boxes).

3. **Conway's Law**: Your security architecture will mirror your org chart. If your security team is siloed, your security posture will have silos. Embedded security engineers and champion programs are structural countermeasures.

4. **You build it, you run it** (Werner Vogels/Amazon): Applied to security: "You build it, you secure it." Engineering teams that own their security posture produce better outcomes than centralized gatekeeping.

5. **Information filtering**: "One of your roles is to act as an information filter in both directions." The CISO filters board concerns down to actionable priorities for the team, and filters operational details up to strategic risk narratives for the board.

6. **The crap shield**: "A lot of the work of an EM is wading into the slurry pit with a shovel so your team are free to get the job done." The CISO absorbs organizational politics, compliance pressure, and vendor noise so analysts and engineers can focus on security.

7. **Hiring is not the challenge**: "The challenge is finding people who can be effective." For security: the challenge is not hiring security professionals, it is building an environment where they can be effective -- tools that work, authority to act, leadership that listens.
