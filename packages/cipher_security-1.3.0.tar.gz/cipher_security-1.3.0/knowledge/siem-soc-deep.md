# SIEM & SOC Operations Deep Dive

**Classification**: CIPHER Training Material — [MODE: BLUE] / [MODE: PURPLE]
**Last Updated**: 2026-03-14
**Sources**: EVTX-ATTACK-SAMPLES, OTRF Security Datasets, OSSEM, Elastic Detection Rules, Splunk Security Content, Microsoft Sentinel, Wazuh, SigmaHQ, Suricata, Zeek, TheHive, MISP, OpenCTI, LogonTracer, SOCFortress CoPilot

---

## Table of Contents

1. [SIEM Architecture Patterns](#1-siem-architecture-patterns)
2. [Log Sources & Collection](#2-log-sources--collection)
3. [Data Normalization — OSSEM & ASIM](#3-data-normalization--ossem--asim)
4. [SOC Tier Responsibilities](#4-soc-tier-responsibilities)
5. [Alert Triage Workflow](#5-alert-triage-workflow)
6. [Detection Engineering Pipeline](#6-detection-engineering-pipeline)
7. [KQL Detection Queries (Microsoft Sentinel)](#7-kql-detection-queries-microsoft-sentinel)
8. [SPL Detection Queries (Splunk)](#8-spl-detection-queries-splunk)
9. [EQL Detection Queries (Elastic)](#9-eql-detection-queries-elastic)
10. [Sigma Rules — Vendor-Agnostic Detection](#10-sigma-rules--vendor-agnostic-detection)
11. [Network Detection — Suricata & Zeek](#11-network-detection--suricata--zeek)
12. [Host-Based Detection — Wazuh & OSSEC](#12-host-based-detection--wazuh--ossec)
13. [Threat Intelligence Platforms](#13-threat-intelligence-platforms)
14. [Incident Response Platforms](#14-incident-response-platforms)
15. [Windows Event Log Reference](#15-windows-event-log-reference)
16. [Detection Coverage by ATT&CK Tactic](#16-detection-coverage-by-attck-tactic)
17. [SIEM Tuning & False Positive Reduction](#17-siem-tuning--false-positive-reduction)
18. [SOC Metrics & KPIs](#18-soc-metrics--kpis)

---

## 1. SIEM Architecture Patterns

### 1.1 Traditional Architecture

```
[Endpoints/Servers] --> [Log Forwarders] --> [Log Aggregator] --> [SIEM Engine] --> [Dashboard/Alerts]
                                                                       |
                                                                  [Rule Engine]
                                                                       |
                                                                [Correlation Engine]
                                                                       |
                                                                  [Case Management]
```

### 1.2 Modern Distributed Architecture

```
                    +------------------+
                    |  Threat Intel    |
                    |  (MISP/OpenCTI)  |
                    +--------+---------+
                             |
+----------+    +------------v-----------+    +------------------+
| Endpoints|--->| Data Pipeline          |--->| Hot Storage       |
| (Agents) |    | (Kafka/Logstash/Flume) |    | (Elasticsearch/  |
+----------+    +------------+-----------+    |  Splunk Indexer)  |
                             |                +--------+---------+
+----------+    +------------v-----------+             |
| Network  |--->| Normalization Layer    |    +--------v---------+
| (Zeek/   |    | (OSSEM/ASIM/CIM)      |    | SIEM Correlation |
| Suricata)|    +------------------------+    | Engine           |
+----------+                                  +--------+---------+
                                                       |
+----------+    +------------------------+    +--------v---------+
| Cloud    |--->| Cold Storage           |    | SOAR Platform    |
| (AWS/    |    | (S3/Data Lake)         |    | (Playbooks)      |
| Azure/GCP|    +------------------------+    +--------+---------+
+----------+                                           |
                                              +--------v---------+
                                              | Case Management  |
                                              | (TheHive/Jira)   |
                                              +------------------+
```

### 1.3 Key Architecture Decisions

| Decision | Options | Trade-off |
|----------|---------|-----------|
| **Ingestion** | Agent-based vs Agentless | Coverage vs Overhead |
| **Storage** | Hot/Warm/Cold tiering | Query speed vs Cost |
| **Parsing** | Ingest-time vs Query-time | Storage vs Flexibility |
| **Correlation** | Real-time vs Batch | Latency vs Throughput |
| **Multi-tenancy** | Shared vs Dedicated clusters | Cost vs Isolation |

### 1.4 Common SIEM Platforms

| Platform | Query Language | Strengths | Deployment |
|----------|---------------|-----------|------------|
| **Microsoft Sentinel** | KQL | Cloud-native, M365 integration, UEBA | SaaS |
| **Splunk Enterprise Security** | SPL | Mature ecosystem, flexible data model | On-prem/Cloud |
| **Elastic Security** | EQL/KQL | Open source core, fast search | On-prem/Cloud |
| **Wazuh** | Custom rules/XML | Free, FIM, compliance | On-prem |
| **QRadar** | AQL | Strong network flow analysis | On-prem/SaaS |
| **Chronicle (Google)** | YARA-L | Petabyte-scale, fixed pricing | SaaS |

---

## 2. Log Sources & Collection

### 2.1 Critical Log Sources (Priority Order)

| Priority | Source | Key Events | Volume Estimate |
|----------|--------|------------|-----------------|
| **P0** | EDR/XDR telemetry | Process creation, file mods, network connections | Very High |
| **P0** | Authentication logs | Logon success/fail, MFA, privilege use | High |
| **P0** | DNS logs | Resolution queries, NXDomain, tunneling | Very High |
| **P1** | Firewall/Proxy logs | Connections, blocks, URL categories | Very High |
| **P1** | Email gateway | Attachments, phishing, sender reputation | High |
| **P1** | Cloud audit logs | API calls, config changes, IAM events | Medium |
| **P2** | Windows Security EVTX | Logon (4624/4625), privilege use (4672), process (4688) | High |
| **P2** | Sysmon | Process create (1), network (3), file create (11), registry (13) | High |
| **P2** | Linux auditd | Execve, file access, user/group changes | Medium |
| **P3** | Web application logs | 4xx/5xx errors, injection attempts | Medium |
| **P3** | Database audit logs | Queries, schema changes, privilege grants | Medium |
| **P3** | VPN/Remote access | Session start/end, geo anomaly | Low |

### 2.2 Windows Event Log Channels

| Channel | Key Event IDs | Detection Use |
|---------|--------------|---------------|
| **Security** | 4624, 4625, 4648, 4672, 4688, 4720, 4732, 4776 | Authentication, privilege, process |
| **Sysmon** | 1, 3, 7, 8, 10, 11, 12, 13, 15, 22, 23, 25 | Process, network, file, registry, DNS |
| **PowerShell** | 4103, 4104 | Script block logging, module logging |
| **WMI** | 5857, 5858, 5859, 5860, 5861 | WMI persistence/execution |
| **TaskScheduler** | 106, 140, 141, 200, 201 | Scheduled task creation/execution |
| **AppLocker** | 8003, 8004, 8006, 8007 | Application execution policy |
| **Defender** | 1006, 1007, 1008, 1116, 1117, 5001 | AV detection, exclusion, tamper |
| **NTLM** | 8001, 8002, 8003, 8004 | NTLM authentication auditing |

### 2.3 Linux Log Sources

| Source | Path | Key Content |
|--------|------|-------------|
| **auditd** | `/var/log/audit/audit.log` | Syscalls, execve, file access, user changes |
| **auth.log/secure** | `/var/log/auth.log` | SSH, sudo, PAM authentication |
| **syslog** | `/var/log/syslog` | System events, service status |
| **journal** | `journalctl` | Systemd service events |
| **cron** | `/var/log/cron` | Scheduled task execution |
| **osquery** | Custom tables | Process, file, network, system state |

### 2.4 Cloud Log Sources

| Cloud | Service | Log Type |
|-------|---------|----------|
| **AWS** | CloudTrail | API calls, IAM, management events |
| **AWS** | VPC Flow Logs | Network flow data |
| **AWS** | GuardDuty | Threat findings |
| **Azure** | Activity Log | Resource operations |
| **Azure** | Entra ID Sign-in Logs | Authentication, conditional access |
| **Azure** | NSG Flow Logs | Network flow data |
| **GCP** | Cloud Audit Logs | Admin activity, data access |
| **M365** | Unified Audit Log | Exchange, SharePoint, Teams activity |

---

## 3. Data Normalization -- OSSEM & ASIM

### 3.1 OSSEM (Open Source Security Events Metadata)

OSSEM provides three layers for normalizing security event data:

**Data Dictionaries (DD)**: Field-level documentation for each log source, organized by OS and provider. Maps raw field names to standardized descriptions.

**Common Data Model (CDM)**: Schema entities that aggregate common fields across sources. Enables writing detection logic once and applying it across multiple data sources.

**Detection Model (DM)**: Identifies relationships among security events to facilitate analytic development. Maps how events correlate across data sources for adversary technique validation.

### 3.2 ASIM (Advanced Security Information Model) — Sentinel

Microsoft Sentinel's ASIM normalizes data at query time using KQL parsers:

```kql
// ASIM normalized process event query — works across all process event sources
imProcessCreate
| where ActingProcessName has "powershell"
    and TargetProcessCommandLine has_any ("-enc", "-e ", "hidden", "bypass")
| project TimeGenerated, DvcHostname, ActorUsername, TargetProcessName, TargetProcessCommandLine
```

### 3.3 CIM (Common Information Model) — Splunk

Splunk CIM normalizes data through data models and field aliases:

```spl
| tstats count from datamodel=Endpoint.Processes
    where Processes.process_name="powershell.exe"
    by Processes.dest Processes.user Processes.process Processes.process_name
| rename Processes.* as *
```

### 3.4 ECS (Elastic Common Schema)

Elastic normalizes using ECS field naming:

```
process.name, process.command_line, process.pid, process.parent.name
source.ip, destination.ip, destination.port
user.name, user.domain, user.id
event.category, event.type, event.action, event.outcome
host.name, host.os.name
file.name, file.path, file.hash.sha256
```

---

## 4. SOC Tier Responsibilities

### 4.1 Tier Structure

```
+------------------------------------------------------------------+
|  SOC Director / CISO                                              |
|  - Strategy, budget, metrics, executive reporting                |
+------------------------------------------------------------------+
         |
+--------v---------------------------------------------------------+
|  Tier 3 — Threat Hunters & Senior Analysts                       |
|  - Proactive hypothesis-driven hunting                           |
|  - Malware reverse engineering                                   |
|  - Advanced forensics (memory, disk, network)                    |
|  - Detection engineering (rule creation, tuning)                 |
|  - Threat intelligence analysis and production                   |
|  - Purple team exercises                                         |
|  - Incident commander role for major incidents                   |
|  Typical ratio: 1 per 10-15 analysts                             |
+------------------------------------------------------------------+
         |
+--------v---------------------------------------------------------+
|  Tier 2 — Incident Responders & Senior Analysts                  |
|  - Deep-dive investigation of escalated alerts                   |
|  - Containment and eradication actions                           |
|  - Correlate across multiple data sources                        |
|  - IOC enrichment and pivoting                                   |
|  - Produce incident timelines                                    |
|  - Recommend detection improvements                              |
|  - Mentor Tier 1 analysts                                        |
|  Typical ratio: 1 per 3-4 Tier 1 analysts                       |
+------------------------------------------------------------------+
         |
+--------v---------------------------------------------------------+
|  Tier 1 — Alert Analysts / Triage                                |
|  - Monitor SIEM dashboard and alert queue                        |
|  - Initial triage: true positive, false positive, benign true pos|
|  - Follow standard operating procedures (SOPs)                   |
|  - Escalate to Tier 2 based on severity/complexity               |
|  - Document findings in ticketing system                         |
|  - Basic IOC lookup and reputation checks                        |
|  Target: triage alert within 15 minutes of firing                |
+------------------------------------------------------------------+
```

### 4.2 Tier 1 — Triage Decision Matrix

| Signal | Action | Escalation Criteria |
|--------|--------|-------------------|
| Known false positive pattern | Close with documented reason | Never — but flag for tuning if recurring |
| Single failed login | Close unless from unusual geo/time | >5 failures in 10 min from same source |
| Process execution alert | Check parent process, command line, user | LOLBin with encoded args, service account |
| Network connection alert | Check dest IP reputation, port, protocol | Known C2 infrastructure, beaconing pattern |
| File creation alert | Check file hash, path, signer | Unsigned binary in system paths |
| Privilege escalation | Verify user role and change ticket | Unplanned privilege change, service account |

### 4.3 Shift Handoff Protocol

```
SHIFT HANDOFF DOCUMENT
======================
Date/Time     : [shift end timestamp]
Analyst       : [outgoing analyst name]
Open Cases    : [list case IDs and current status]
Active Hunts  : [any ongoing threat hunt hypotheses]
Pending Items : [awaiting vendor response, IR actions]
Escalations   : [items escalated to Tier 2/3 during shift]
Anomalies     : [anything unusual but not yet confirmed]
SIEM Health   : [any ingestion delays, parser errors, agent issues]
```

---

## 5. Alert Triage Workflow

### 5.1 Standard Triage Process

```
[Alert Fires] ──> [Auto-Enrichment] ──> [Analyst Queue]
                        |                      |
                  +-----v------+         +-----v------+
                  | IP/Hash    |         | Read Alert |
                  | Reputation |         | Context    |
                  | Geo Lookup |         +-----+------+
                  | User Info  |               |
                  | Asset Value|         +-----v------+
                  +------------+         | Classify   |
                                         +-----+------+
                                               |
                        +----------+-----------+-----------+
                        |          |                       |
                  +-----v----+ +--v--------+      +------v-------+
                  | FALSE    | | BENIGN    |      | TRUE         |
                  | POSITIVE | | TRUE POS  |      | POSITIVE     |
                  +-----+----+ +--+--------+      +------+-------+
                        |         |                       |
                  +-----v----+ +--v--------+      +------v-------+
                  | Document | | Document  |      | Escalate     |
                  | & Close  | | & Close   |      | to Tier 2    |
                  +----------+ | (expected |      | Contain if   |
                               | behavior) |      | Sev 1-2      |
                               +-----------+      +--------------+
```

### 5.2 Severity Classification

| Severity | Definition | Response SLA | Examples |
|----------|-----------|-------------|----------|
| **Critical (1)** | Active compromise, data exfil in progress | 15 min | Ransomware execution, C2 callback, domain admin compromise |
| **High (2)** | Likely compromise, immediate risk | 1 hour | Credential dumping, lateral movement, malware execution |
| **Medium (3)** | Suspicious activity, potential threat | 4 hours | Unusual PowerShell, brute force attempt, policy violation |
| **Low (4)** | Informational, minor policy violation | 24 hours | Software policy violation, minor config drift |

### 5.3 Enrichment Checklist

For every alert that passes initial triage:

```
[ ] Source/destination IP — reputation, geo, ASN, known infrastructure
[ ] File hash — VT, sandbox results, first/last seen
[ ] Domain/URL — age, registrar, WHOIS, passive DNS, categorization
[ ] User context — role, department, normal working hours, recent changes
[ ] Asset context — criticality, OS, patch status, business function
[ ] Historical — has this alert fired before? Same user/host?
[ ] Related alerts — any other alerts on same host/user in last 24h?
[ ] Threat intel — IOC match in MISP/OpenCTI feeds?
```

---

## 6. Detection Engineering Pipeline

### 6.1 Detection-as-Code Lifecycle

```
[Threat Intel / Red Team Finding]
         |
    +----v----+
    | IDEATE  |  Identify gap: what TTPs are we not detecting?
    +---------+
         |
    +----v----+
    | DEVELOP |  Write detection in Sigma (vendor-agnostic)
    +---------+  Convert to target SIEM query language
         |
    +----v----+
    |  TEST   |  Validate against labeled attack datasets
    +---------+  (EVTX-ATTACK-SAMPLES, OTRF Security Datasets)
         |
    +----v----+
    |  TUNE   |  Run against production data in detection-only mode
    +---------+  Measure FP rate, adjust thresholds
         |
    +----v----+
    | DEPLOY  |  Push to SIEM via CI/CD pipeline
    +---------+  Enable alerting
         |
    +----v----+
    | MONITOR |  Track TP/FP ratio, MTTD, analyst feedback
    +---------+
         |
    +----v----+
    | ITERATE |  Tune, retire, or enhance based on metrics
    +---------+
```

### 6.2 Detection Quality Criteria

| Criterion | Good | Bad |
|-----------|------|-----|
| **Specificity** | Targets a defined TTP with context | `process_name = "cmd.exe"` with no context |
| **Resilience** | Detects technique variants | Relies on single tool name or string |
| **Performance** | Completes in <30s on 24h data | Full-table scan with regex on every field |
| **False Positive Rate** | <5% after tuning | >50% — analysts stop investigating |
| **Documentation** | ATT&CK mapping, known FPs, runbook | No description, no context |
| **Testability** | Can be triggered by atomic test | Only fires on real attacks |

### 6.3 Data Source Coverage Matrix

Map your detection rules against the MITRE ATT&CK data sources:

| Data Source | Sysmon Event | Windows Security | Linux auditd |
|-------------|-------------|-----------------|--------------|
| Process Creation | Event 1 | Event 4688 | execve syscall |
| Network Connection | Event 3 | Event 5156 | connect/accept |
| File Creation | Event 11 | Event 4663 | open/creat |
| Registry Modification | Event 13 | Event 4657 | N/A |
| DLL Load | Event 7 | N/A | N/A |
| Process Access | Event 10 | N/A | ptrace |
| DNS Query | Event 22 | N/A | N/A |
| WMI Event | Event 19/20/21 | Event 5857-5861 | N/A |
| Named Pipe | Event 17/18 | N/A | N/A |
| Scheduled Task | N/A | Event 4698 | cron.log |

---

## 7. KQL Detection Queries (Microsoft Sentinel)

### 7.1 Core KQL Operators for Security

```kql
// OPERATOR REFERENCE
// where     — filter rows by condition
// project   — select/rename columns
// extend    — add calculated columns
// summarize — aggregate data (count, dcount, avg, sum, make_set, make_list)
// join      — combine tables (inner, leftouter, rightouter, fullouter)
// union     — merge tables vertically
// let       — define variables or reusable query fragments
// parse     — extract fields from unstructured text
// mv-expand — expand multi-value dynamic columns into rows
// make-series — create time-series data for anomaly detection
// bin       — bucket time values (e.g., bin(TimeGenerated, 1h))
// ago       — relative time reference (e.g., ago(24h), ago(7d))
// top       — return N rows by sort column
// arg_max   — return row with max value for a given column
// arg_min   — return row with min value for a given column
// render    — visualize results (timechart, barchart, piechart)
```

### 7.2 Sentinel Table Reference

| Table | Content |
|-------|---------|
| `SecurityEvent` | Windows Security Event Log |
| `Syslog` | Linux syslog |
| `SigninLogs` | Azure AD/Entra ID sign-ins |
| `AuditLogs` | Azure AD/Entra ID audit events |
| `AzureActivity` | Azure resource operations |
| `CommonSecurityLog` | CEF-formatted events (firewalls, proxies) |
| `DeviceProcessEvents` | MDE process creation |
| `DeviceNetworkEvents` | MDE network connections |
| `DeviceFileEvents` | MDE file operations |
| `DeviceLogonEvents` | MDE logon events |
| `OfficeActivity` | M365 audit log |
| `ThreatIntelligenceIndicator` | Imported IOCs |
| `EmailEvents` | Email metadata (MDO) |
| `AlertEvidence` | Alert context data |
| `BehaviorAnalytics` | UEBA outputs |

### 7.3 Credential Access Detections

```kql
// LSASS Memory Access Detection (T1003.001)
// Requires: Sysmon Event 10 or MDE
DeviceProcessEvents
| where Timestamp > ago(24h)
| where FileName in~ ("mimikatz.exe", "procdump.exe", "procdump64.exe")
    or InitiatingProcessCommandLine has_any ("sekurlsa", "lsadump", "kerberos::list")
| project Timestamp, DeviceName, AccountName, FileName, ProcessCommandLine, InitiatingProcessFileName
```

```kql
// Kerberoasting Detection (T1558.003)
// Requires: SecurityEvent (Event 4769)
SecurityEvent
| where EventID == 4769
| where ServiceName !endswith "$"
    and ServiceName != "krbtgt"
| where TicketEncryptionType in ("0x17", "0x18")  // RC4 or AES
| summarize TargetCount = dcount(ServiceName),
            Services = make_set(ServiceName),
            TicketTypes = make_set(TicketEncryptionType)
    by AccountName, ClientAddress, bin(TimeGenerated, 5m)
| where TargetCount > 5
```

```kql
// DCSync Detection (T1003.006)
// Requires: SecurityEvent (Event 4662)
SecurityEvent
| where EventID == 4662
| where AccessMask == "0x100"
| where Properties has_any (
    "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2",  // DS-Replication-Get-Changes
    "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2",  // DS-Replication-Get-Changes-All
    "89e95b76-444d-4c62-991a-0facbeda640c"   // DS-Replication-Get-Changes-In-Filtered-Set
)
| where SubjectUserName !endswith "$"  // Exclude machine accounts
| summarize PropertyCount = dcount(Properties)
    by SubjectUserName, SubjectDomainName, IpAddress, bin(TimeGenerated, 1h)
| where PropertyCount >= 2
```

### 7.4 Execution Detections

```kql
// Suspicious PowerShell Execution (T1059.001)
// Requires: SecurityEvent (Event 4688) with command-line auditing or Sysmon Event 1
SecurityEvent
| where EventID == 4688
| where NewProcessName endswith "\\powershell.exe"
    or NewProcessName endswith "\\pwsh.exe"
| where CommandLine has_any (
    "-encodedcommand", "-enc ", "-e ",
    "frombase64string", "decompress",
    "iex", "invoke-expression",
    "downloadstring", "downloadfile",
    "webclient", "net.webclient",
    "start-bitstransfer",
    "bypass", "-noprofile", "hidden"
)
| project TimeGenerated, Computer, Account, CommandLine, ParentProcessName
```

```kql
// WMI Remote Execution (T1047)
// Requires: Sysmon or MDE
DeviceProcessEvents
| where Timestamp > ago(24h)
| where InitiatingProcessFileName =~ "wmiprvse.exe"
| where FileName in~ ("cmd.exe", "powershell.exe", "mshta.exe", "cscript.exe", "wscript.exe")
| project Timestamp, DeviceName, AccountName, FileName, ProcessCommandLine
```

```kql
// MSHTA Execution for Defense Evasion (T1218.005)
SecurityEvent
| where EventID == 4688
| where NewProcessName endswith "\\mshta.exe"
| where CommandLine has_any ("javascript:", "vbscript:", "http://", "https://", ".hta")
| project TimeGenerated, Computer, Account, CommandLine, ParentProcessName
```

### 7.5 Persistence Detections

```kql
// Scheduled Task Creation (T1053.005)
// Requires: SecurityEvent (Event 4698)
SecurityEvent
| where EventID == 4698
| parse EventData with * '<Data Name="TaskName">' TaskName '</Data>' *
| parse EventData with * '<Data Name="TaskContent">' TaskContent '</Data>' *
| where TaskContent has_any ("powershell", "cmd.exe", "mshta", "wscript",
                              "cscript", "regsvr32", "rundll32", "http://", "https://")
| project TimeGenerated, Computer, Account, TaskName, TaskContent
```

```kql
// New Service Installation (T1543.003)
// Requires: SecurityEvent (Event 7045) or System log
Event
| where EventLog == "System"
| where EventID == 7045
| parse EventData with * '<Data Name="ServiceName">' ServiceName '</Data>' *
| parse EventData with * '<Data Name="ImagePath">' ImagePath '</Data>' *
| where ImagePath has_any ("cmd", "powershell", "mshta", "regsvr32",
                            "rundll32", "temp", "appdata", "public")
| project TimeGenerated, Computer, ServiceName, ImagePath
```

### 7.6 Lateral Movement Detections

```kql
// Pass-the-Hash Detection (T1550.002)
// Requires: SecurityEvent (Event 4624, Logon Type 3 with NTLM)
SecurityEvent
| where EventID == 4624
| where LogonType == 3
| where AuthenticationPackageName == "NTLM"
| where TargetUserName !endswith "$"
| summarize LogonCount = count(),
            DistinctHosts = dcount(Computer),
            Hosts = make_set(Computer)
    by TargetUserName, IpAddress, bin(TimeGenerated, 1h)
| where DistinctHosts > 3
```

```kql
// RDP Lateral Movement — Unusual Source (T1021.001)
SecurityEvent
| where EventID == 4624
| where LogonType == 10  // RemoteInteractive (RDP)
| where TargetUserName !endswith "$"
| summarize FirstSeen = min(TimeGenerated),
            LastSeen = max(TimeGenerated),
            LogonCount = count()
    by TargetUserName, IpAddress, Computer
| join kind=leftanti (
    SecurityEvent
    | where TimeGenerated between (ago(30d) .. ago(1d))
    | where EventID == 4624 and LogonType == 10
    | distinct TargetUserName, IpAddress
) on TargetUserName, IpAddress
// Result: RDP logons from source IPs not seen in previous 30 days
```

### 7.7 Discovery & Reconnaissance

```kql
// Enumeration Command Burst (T1087, T1016, T1018)
// Requires: MDE or Sysmon
DeviceProcessEvents
| where Timestamp > ago(1h)
| where FileName in~ ("net.exe", "net1.exe", "nltest.exe", "dsquery.exe",
                       "ipconfig.exe", "systeminfo.exe", "tasklist.exe",
                       "whoami.exe", "nslookup.exe", "quser.exe",
                       "arp.exe", "netstat.exe")
| summarize CommandCount = count(),
            Commands = make_set(FileName),
            CommandLines = make_set(ProcessCommandLine)
    by DeviceName, AccountName, bin(Timestamp, 10m)
| where CommandCount > 5
```

### 7.8 Defense Evasion

```kql
// Security Log Cleared (T1070.001)
SecurityEvent
| where EventID in (1102, 517)  // Security log cleared
| project TimeGenerated, Computer, Account

// ETW Tampering Detection (T1562.006)
DeviceProcessEvents
| where ProcessCommandLine has_any (
    "logman stop", "logman delete",
    "Remove-EtwTraceProvider",
    "Set-EtwTraceProvider",
    "cl /d"
)
| project Timestamp, DeviceName, AccountName, ProcessCommandLine
```

```kql
// AMSI Bypass Attempt (T1562.001)
DeviceProcessEvents
| where Timestamp > ago(24h)
| where ProcessCommandLine has_any (
    "amsiInitFailed", "AmsiUtils",
    "amsiContext", "amsiSession",
    "AmsiScanBuffer", "Disable-Amsi"
)
| project Timestamp, DeviceName, AccountName, ProcessCommandLine, InitiatingProcessFileName
```

### 7.9 Time-Series Anomaly Detection

```kql
// Detect beaconing behavior (T1071)
// Requires: proxy or firewall logs
CommonSecurityLog
| where TimeGenerated > ago(24h)
| where DeviceAction == "Allowed"
| summarize ConnectionCount = count() by DestinationHostName, SourceIP, bin(TimeGenerated, 10m)
| make-series Connections = sum(ConnectionCount) default=0
    on TimeGenerated from ago(24h) to now() step 10m
    by DestinationHostName, SourceIP
| extend (Anomalies, Score, Baseline) = series_decompose_anomalies(Connections, 1.5, -1, "linefit")
| mv-expand TimeGenerated to typeof(datetime),
            Connections to typeof(long),
            Anomalies to typeof(int),
            Score to typeof(double)
| where Anomalies == 1
| summarize AnomalyCount = count() by DestinationHostName, SourceIP
| where AnomalyCount > 10  // Consistent pattern = beaconing
```

### 7.10 Threat Intelligence Matching

```kql
// Match network connections against TI indicators
let TIIndicators = ThreatIntelligenceIndicator
| where Active == true and ExpirationDateTime > now()
| where isnotempty(NetworkIP)
| distinct NetworkIP;
CommonSecurityLog
| where TimeGenerated > ago(1h)
| where DestinationIP in (TIIndicators) or SourceIP in (TIIndicators)
| project TimeGenerated, DeviceProduct, SourceIP, DestinationIP, DestinationPort, DeviceAction
```

---

## 8. SPL Detection Queries (Splunk)

### 8.1 Core SPL Commands for Security

```spl
| Key commands:
| search    — base search against raw events or indexed fields
| where     — filter results using eval expressions
| stats     — aggregate: count, dc, values, list, sum, avg, min, max, earliest, latest
| eval      — create calculated fields
| table     — format output columns
| rename    — rename fields
| rex       — regex field extraction
| transaction — group events by shared field with time constraints
| tstats    — fast pre-computed stats against data models (10-100x faster)
| datamodel — reference accelerated data models
| lookup    — enrich with lookup tables
| inputlookup — load lookup table as search results
| outputlookup — save results to lookup table
| eventstats — add aggregation columns without reducing rows
| streamstats — running calculations across events
| dedup     — remove duplicates
| sort      — order results
| fields    — include/exclude fields
| append    — union results from subsearch
| join      — join on shared field (use sparingly — tstats is preferred)
| map       — iterative subsearch per result
| collect   — write results to summary index
```

### 8.2 Credential Access

```spl
// LSASS Access Detection (T1003.001)
// Requires: Sysmon Event 10
index=windows sourcetype="XmlWinEventLog:Microsoft-Windows-Sysmon/Operational" EventCode=10
    TargetImage="*\\lsass.exe"
    NOT SourceImage IN ("*\\csrss.exe", "*\\lsm.exe", "*\\wmiprvse.exe",
                         "*\\svchost.exe", "*\\MsMpEng.exe")
| stats count values(SourceImage) as SourceImages values(GrantedAccess) as Access
    by Computer, SourceUser
| where count > 1

// Kerberoasting (T1558.003)
// Requires: Windows Security Event 4769
index=windows sourcetype="WinEventLog:Security" EventCode=4769
    Ticket_Encryption_Type=0x17
    Service_Name!="krbtgt" Service_Name!="*$"
| stats dc(Service_Name) as UniqueServices values(Service_Name) as Services
    by Account_Name, Client_Address
| where UniqueServices > 4
```

### 8.3 Execution

```spl
// Suspicious PowerShell — Encoded Commands (T1059.001)
// Requires: Windows Security Event 4688 with command-line auditing
index=windows sourcetype="WinEventLog:Security" EventCode=4688
    (New_Process_Name="*\\powershell.exe" OR New_Process_Name="*\\pwsh.exe")
    (Process_Command_Line="*-enc*" OR Process_Command_Line="*-e *"
     OR Process_Command_Line="*frombase64*" OR Process_Command_Line="*downloadstring*"
     OR Process_Command_Line="*iex*" OR Process_Command_Line="*bypass*")
| table _time Computer Account_Name New_Process_Name Process_Command_Line Creator_Process_Name

// LOLBin Execution — Certutil Download (T1105)
index=windows sourcetype="WinEventLog:Security" EventCode=4688
    New_Process_Name="*\\certutil.exe"
    (Process_Command_Line="*urlcache*" OR Process_Command_Line="*split*"
     OR Process_Command_Line="*encode*" OR Process_Command_Line="*decode*")
| table _time Computer Account_Name Process_Command_Line
```

### 8.4 Persistence

```spl
// Registry Run Key Modification (T1547.001)
// Requires: Sysmon Event 13
index=windows sourcetype="XmlWinEventLog:Microsoft-Windows-Sysmon/Operational" EventCode=13
    TargetObject="*\\CurrentVersion\\Run*"
    NOT Image IN ("*\\explorer.exe", "*\\msiexec.exe")
| stats count by Computer, Image, TargetObject, Details

// WMI Event Subscription Persistence (T1546.003)
// Requires: Sysmon Event 19/20/21
index=windows sourcetype="XmlWinEventLog:Microsoft-Windows-Sysmon/Operational"
    EventCode IN (19, 20, 21)
| stats count values(EventType) as EventTypes values(Operation) as Operations
    values(Consumer) as Consumers values(Destination) as Destinations
    by Computer, User
```

### 8.5 Lateral Movement

```spl
// PsExec-like Remote Execution (T1021.002)
// Requires: Windows Security Events 4624 + 7045
index=windows sourcetype="WinEventLog:Security" EventCode=4624 Logon_Type=3
    Authentication_Package="NTLM"
| join Computer
    [search index=windows sourcetype="WinEventLog:System" EventCode=7045
     | eval Computer=host]
| table _time Computer Account_Name Source_Network_Address Service_Name Service_File_Name

// SMB Lateral Movement — Unusual Share Access (T1021.002)
index=windows sourcetype="WinEventLog:Security" EventCode=5140
    Share_Name IN ("\\\\*\\ADMIN$", "\\\\*\\C$", "\\\\*\\IPC$")
| stats dc(Share_Name) as ShareCount values(Share_Name) as Shares
    count by Account_Name, Source_Address
| where ShareCount >= 2
```

### 8.6 Accelerated Data Model Searches

```spl
// Fast process creation search using tstats
| tstats summariesonly=true count min(_time) as firstTime max(_time) as lastTime
    from datamodel=Endpoint.Processes
    where Processes.process_name IN ("cmd.exe", "powershell.exe", "wscript.exe",
                                      "cscript.exe", "mshta.exe")
          AND Processes.parent_process_name="winword.exe"
    by Processes.dest Processes.user Processes.parent_process_name
       Processes.process_name Processes.process
| rename Processes.* as *
| convert timeformat="%Y-%m-%d %H:%M:%S" ctime(firstTime) ctime(lastTime)

// Fast network connection search
| tstats summariesonly=true count
    from datamodel=Network_Traffic.All_Traffic
    where All_Traffic.dest_port IN (4444, 5555, 8080, 8443, 9090)
          AND NOT All_Traffic.dest_ip IN (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)
    by All_Traffic.src All_Traffic.dest All_Traffic.dest_port
| rename All_Traffic.* as *
```

### 8.7 Statistical Anomaly Detection

```spl
// Detect unusual process execution count per host (baseline deviation)
index=windows sourcetype="WinEventLog:Security" EventCode=4688
| bucket _time span=1h
| stats dc(New_Process_Name) as UniqueProcesses by Computer, _time
| eventstats avg(UniqueProcesses) as AvgProcesses
             stdev(UniqueProcesses) as StdProcesses by Computer
| eval Threshold = AvgProcesses + (3 * StdProcesses)
| where UniqueProcesses > Threshold
| table _time Computer UniqueProcesses AvgProcesses Threshold

// Outbound data volume anomaly (potential exfiltration)
index=proxy OR index=firewall action=allowed direction=outbound
| bucket _time span=1h
| stats sum(bytes_out) as TotalBytesOut by src_ip, _time
| eventstats avg(TotalBytesOut) as AvgBytes stdev(TotalBytesOut) as StdBytes by src_ip
| where TotalBytesOut > (AvgBytes + 3*StdBytes) AND TotalBytesOut > 104857600
| table _time src_ip TotalBytesOut AvgBytes
```

---

## 9. EQL Detection Queries (Elastic)

### 9.1 EQL Syntax Reference

```
Query types:
  event_category where condition          — single event match
  sequence [by field] [with maxspan=Ns]   — ordered multi-event correlation
  sample by field                          — unordered multi-event sampling
  any where condition                      — match against any event category

Operators:
  ==, !=, <, <=, >, >=                    — comparison (== is case-sensitive)
  :                                        — case-insensitive wildcard match
  like, like~                              — wildcard match (~ = case-insensitive)
  regex, regex~                            — regex match
  in, in~, not in                          — set membership
  and, or, not                             — logical operators
  *                                        — zero or more chars (in wildcards)
  ?                                        — exactly one char (in wildcards)

Sequence modifiers:
  with maxspan=<duration>                  — maximum time between first and last event
  by <field>                               — join key across events
  until [event_category where condition]   — expiration event
  with runs=N                              — repeat same criteria N times
  ![event where condition]                 — missing/negated event
```

### 9.2 Credential Access

```eql
// LSASS Memory Dumping (T1003.001)
process where event.type == "start" and
  process.name : ("procdump.exe", "procdump64.exe") and
  process.command_line : "*lsass*"

// Credential Dumping via comsvcs.dll (T1003.001)
process where event.type == "start" and
  process.name : "rundll32.exe" and
  process.command_line : "*comsvcs*MiniDump*"
```

### 9.3 Multi-Step Attack Sequences

```eql
// Phishing to Execution Chain (T1566 -> T1059)
// Office application spawning suspicious child process
sequence by host.name with maxspan=5m
  [process where event.type == "start" and
   process.name : ("winword.exe", "excel.exe", "powerpnt.exe", "outlook.exe")]
  [process where event.type == "start" and
   process.parent.name : ("winword.exe", "excel.exe", "powerpnt.exe", "outlook.exe") and
   process.name : ("cmd.exe", "powershell.exe", "pwsh.exe", "mshta.exe",
                    "wscript.exe", "cscript.exe", "regsvr32.exe")]
```

```eql
// Credential Theft then Lateral Movement (T1003 -> T1021)
sequence by user.name with maxspan=30m
  [process where event.type == "start" and
   process.name : ("mimikatz.exe", "procdump.exe") or
   process.command_line : ("*sekurlsa*", "*lsadump*", "*comsvcs*MiniDump*")]
  [authentication where event.outcome == "success" and
   source.ip != null and source.ip != "127.0.0.1"]
```

```eql
// Persistence then C2 Callback
sequence by host.name with maxspan=10m
  [registry where event.type == "change" and
   registry.path : "*\\CurrentVersion\\Run*"]
  [network where event.type == "start" and
   not destination.ip : ("10.*", "172.16.*", "192.168.*", "127.*")]
```

### 9.4 Defense Evasion

```eql
// Process Masquerading — System Binary from Wrong Path (T1036.005)
process where event.type == "start" and
  process.name : ("svchost.exe", "csrss.exe", "lsass.exe", "services.exe",
                   "smss.exe", "winlogon.exe", "wininit.exe") and
  not process.executable : ("C:\\Windows\\System32\\*", "C:\\Windows\\SysWOW64\\*")

// Parent PID Spoofing Detection (T1134.004)
sequence by host.name with maxspan=5s
  [process where event.type == "start" and
   process.name : "cmd.exe" and process.parent.name : "explorer.exe"]
  [process where event.type == "start" and
   process.parent.name : "cmd.exe" and
   process.name : ("powershell.exe", "pwsh.exe") and
   process.command_line : ("*-enc*", "*hidden*", "*bypass*")]
```

### 9.5 Privilege Escalation

```eql
// UAC Bypass via fodhelper.exe (T1548.002)
sequence by host.name with maxspan=5s
  [registry where event.type == "change" and
   registry.path : "*\\ms-settings\\shell\\open\\command*"]
  [process where event.type == "start" and
   process.parent.name == "fodhelper.exe" and
   process.name : ("cmd.exe", "powershell.exe")]

// Named Pipe Impersonation (T1134.001)
process where event.type == "start" and
  process.name : ("*.exe") and
  process.command_line : ("*\\pipe\\*", "*ImpersonateNamedPipeClient*",
                           "*CreateNamedPipe*")
```

### 9.6 Exfiltration Detection

```eql
// Large File Archive Before Transfer (T1560 -> T1041)
sequence by host.name, user.name with maxspan=30m
  [process where event.type == "start" and
   process.name : ("7z.exe", "rar.exe", "zip.exe", "tar.exe") and
   process.command_line : ("*-p*", "*password*", "*-split*")]
  [network where event.type == "start" and
   destination.port in (443, 80, 21, 22, 8443) and
   not destination.ip : ("10.*", "172.16.*", "192.168.*")]
```

---

## 10. Sigma Rules -- Vendor-Agnostic Detection

### 10.1 Sigma Rule Format

Sigma provides vendor-agnostic detection rules in YAML format. The SigmaHQ repository contains **3000+ detection rules** organized by log source and attack category.

```yaml
# SIGMA RULE TEMPLATE
title: Descriptive Detection Name  # Verb + Noun pattern
id: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx  # Random UUID
status: experimental | test | stable
description: One-sentence description of what is detected and why it matters
references:
    - https://attack.mitre.org/techniques/TXXXX/
author: Author Name
date: YYYY-MM-DD
modified: YYYY-MM-DD
logsource:
    category: process_creation | network_connection | file_change | authentication | ...
    product: windows | linux | macos | ...
    service: security | sysmon | powershell | ...
detection:
    selection:
        FieldName|modifier: value
        # Modifiers: contains, startswith, endswith, re, base64, cidr, all, windash
    filter_known_good:
        Image|endswith: '\legitimate.exe'
    condition: selection and not filter_known_good
falsepositives:
    - Specific scenario that may trigger false positives
level: critical | high | medium | low | informational
tags:
    - attack.tXXXX          # MITRE ATT&CK technique
    - attack.tactic_name     # MITRE ATT&CK tactic
```

### 10.2 Example Sigma Rules

```yaml
# Suspicious PowerShell Download Cradle
title: PowerShell Download Cradle Execution
id: 3b6ab547-8ec2-4991-b7e0-52b5b0a7b899
status: stable
description: Detects PowerShell commands that download and execute content from the internet
logsource:
    category: process_creation
    product: windows
detection:
    selection_ps:
        Image|endswith:
            - '\powershell.exe'
            - '\pwsh.exe'
    selection_download:
        CommandLine|contains:
            - 'Net.WebClient'
            - 'DownloadString'
            - 'DownloadFile'
            - 'Invoke-WebRequest'
            - 'iwr '
            - 'wget '
            - 'curl '
            - 'Start-BitsTransfer'
    selection_exec:
        CommandLine|contains:
            - 'IEX'
            - 'Invoke-Expression'
            - '| iex'
    condition: selection_ps and selection_download and selection_exec
falsepositives:
    - Legitimate administration scripts that download and execute modules
    - SCCM/Intune deployment scripts
level: high
tags:
    - attack.execution
    - attack.t1059.001
    - attack.t1105
```

```yaml
# LSASS Memory Access
title: LSASS Process Access for Credential Dumping
id: 32d0d3e2-e58d-4d41-926b-18b520b2b32d
status: stable
description: Detects process access to LSASS memory indicative of credential dumping
logsource:
    category: process_access
    product: windows
detection:
    selection:
        TargetImage|endswith: '\lsass.exe'
        GrantedAccess|contains:
            - '0x1010'
            - '0x1038'
            - '0x1F0FFF'
            - '0x1F1FFF'
            - '0x143A'
    filter_system:
        SourceImage|endswith:
            - '\csrss.exe'
            - '\lsm.exe'
            - '\MsMpEng.exe'
            - '\svchost.exe'
    condition: selection and not filter_system
falsepositives:
    - AV/EDR products performing legitimate memory scanning
    - Windows Error Reporting (WerFault.exe)
level: high
tags:
    - attack.credential_access
    - attack.t1003.001
```

### 10.3 Sigma Conversion

```bash
# Install sigma-cli and backends
pip install sigma-cli pySigma-backend-splunk pySigma-backend-elasticsearch pySigma-backend-microsoft365defender

# Convert to Splunk SPL
sigma convert -t splunk -p splunk_cim rule.yml

# Convert to Elastic EQL/KQL
sigma convert -t elasticsearch -p ecs_windows rule.yml

# Convert to Microsoft Sentinel KQL
sigma convert -t microsoft365defender rule.yml

# Convert to Splunk with sysmon pipeline
sigma convert -t splunk -p sysmon rule.yml

# Batch convert directory
sigma convert -t splunk -p splunk_cim rules/ --output output/
```

---

## 11. Network Detection -- Suricata & Zeek

### 11.1 Suricata Rule Format

```
action protocol source_ip source_port -> dest_ip dest_port (options)
```

**Actions**: `alert`, `pass`, `drop`, `reject`, `rejectsrc`, `rejectdst`, `rejectboth`

**Protocols**: `tcp`, `udp`, `icmp`, `ip`, `http`, `dns`, `tls`, `ssh`, `smtp`, `ftp`, `smb`, `dcerpc`, `krb5`

**Direction**: `->` (unidirectional), `=>` (transactional), `<>` (bidirectional)

### 11.2 Suricata Detection Rules

```
# Detect Cobalt Strike Default Certificate (T1573.002)
alert tls $HOME_NET any -> $EXTERNAL_NET any (msg:"ET MALWARE Cobalt Strike Default TLS Certificate"; flow:established,to_server; tls.subject:"CN=Major Cobalt Strike"; classtype:trojan-activity; sid:2033466; rev:1;)

# Detect DNS Tunneling — Long Subdomain (T1071.004)
alert dns $HOME_NET any -> any 53 (msg:"POLICY Potential DNS Tunneling - Long Query"; dns.query; content:"."; pcre:"/^[a-zA-Z0-9]{30,}\./"; classtype:bad-unknown; sid:1000001; rev:1;)

# Detect PowerShell Download via HTTP (T1059.001)
alert http $HOME_NET any -> $EXTERNAL_NET any (msg:"ET POLICY PowerShell User-Agent"; flow:established,to_server; http.user_agent; content:"WindowsPowerShell"; classtype:policy-violation; sid:2027544; rev:2;)

# Detect NTLM Hash Relay (T1557.001)
alert smb any any -> $HOME_NET any (msg:"ET EXPLOIT Possible NTLM Relay Attack"; flow:established,to_server; content:"|4e 54 4c 4d 53 53 50|"; classtype:attempted-admin; sid:2024312; rev:1;)

# Detect Known C2 Port Communication
alert tcp $HOME_NET any -> $EXTERNAL_NET [4444,5555,8888,1234] (msg:"POLICY Outbound Connection to Common C2 Port"; flow:established,to_server; classtype:bad-unknown; sid:1000002; rev:1;)

# Suricata EVE JSON Output Format
# All alerts and metadata written as JSON to eve.json:
# {
#   "timestamp": "2026-03-14T10:23:45.123456+0000",
#   "event_type": "alert",
#   "src_ip": "192.168.1.100",
#   "dest_ip": "203.0.113.50",
#   "alert": {
#     "signature": "ET MALWARE Cobalt Strike Default TLS Certificate",
#     "signature_id": 2033466,
#     "category": "trojan-activity",
#     "severity": 1
#   },
#   "tls": { "subject": "CN=Major Cobalt Strike", ... },
#   "flow_id": 1234567890
# }
```

### 11.3 Zeek Log Types

| Log File | Content | Security Use |
|----------|---------|-------------|
| `conn.log` | All connections: src/dst IP, port, proto, duration, bytes | Baseline, beaconing, data exfil |
| `dns.log` | DNS queries and responses | DNS tunneling, DGA, C2 resolution |
| `http.log` | HTTP requests: method, URI, user-agent, response code | C2 communication, download cradles |
| `ssl.log` | TLS handshake: SNI, certificate, JA3/JA3S | Encrypted C2, certificate anomaly |
| `files.log` | File transfers: hash, size, MIME type | Malware delivery, exfiltration |
| `smtp.log` | Email metadata | Phishing, data exfil via email |
| `notice.log` | Zeek-generated alerts | Policy violations, anomalies |
| `weird.log` | Protocol violations | Evasion, tunneling, non-standard usage |
| `x509.log` | Certificate details | Rogue certs, self-signed, expired |
| `kerberos.log` | Kerberos authentication | Kerberoasting, ticket forging |
| `smb_mapping.log` | SMB share access | Lateral movement, share enumeration |
| `pe.log` | Portable Executable metadata | Malware file transfer |
| `dpd.log` | Protocol detection | Non-standard port usage |

### 11.4 Zeek Scripting for Detection

```zeek
# Detect DNS Tunneling — High Entropy Queries
@load base/frameworks/notice

module DNSTunnel;

export {
    redef enum Notice::Type += { DNSTunnel::Long_DNS_Query };
    const query_length_threshold = 50 &redef;
}

event dns_request(c: connection, msg: dns_msg, query: string, qtype: count, qclass: count)
{
    if ( |query| > query_length_threshold )
    {
        NOTICE([$note=DNSTunnel::Long_DNS_Query,
                $msg=fmt("Unusually long DNS query: %s (%d chars)", query, |query|),
                $conn=c,
                $identifier=cat(c$id$orig_h, query)]);
    }
}
```

### 11.5 JA3/JA3S TLS Fingerprinting

JA3 creates a hash of TLS Client Hello parameters; JA3S hashes the Server Hello. Known malware JA3 hashes can be matched against traffic.

```
# Common Malicious JA3 Hashes (examples — maintain an updated list)
# Cobalt Strike (various configs):
#   51c64c77e60f3980eea90869b68c58a8
#   a0e9f5d64349fb13191bc781f81f42e1
# Metasploit Meterpreter:
#   5d65ea3fb1d4aa7d499be5aac0d30b7a
# Trickbot:
#   6734f37431670b3ab4292b8f60f29984

# Zeek logs JA3/JA3S in ssl.log automatically when loaded:
# @load protocols/ssl/ja3
```

---

## 12. Host-Based Detection -- Wazuh & OSSEC

### 12.1 Wazuh Architecture

```
+------------------+     +-------------------+     +------------------+
| Wazuh Agent      |     | Wazuh Manager     |     | Wazuh Indexer    |
| - Log collection |---->| - Rule engine     |---->| (OpenSearch)     |
| - FIM            |     | - Decoders        |     | - Storage        |
| - SCA            |     | - Active response |     | - Visualization  |
| - Vuln detection |     | - API             |     | - Alerting       |
| - Rootcheck      |     | - Cluster mgmt    |     +------------------+
+------------------+     +-------------------+            |
                                                   +------v-----------+
                                                   | Wazuh Dashboard  |
                                                   | (OpenSearch      |
                                                   |  Dashboards)     |
                                                   +------------------+
```

**Agent capabilities**:
- Log collection from OS/application logs
- File Integrity Monitoring (FIM) — tracks content, permissions, ownership, attributes
- Security Configuration Assessment (SCA) — CIS benchmark checks
- Vulnerability detection — correlates software inventory with CVE databases
- Rootkit detection
- Active response — automated containment actions

**Manager capabilities**:
- Signature-based rule engine with regex pattern matching
- Decoder pipeline for log parsing
- Built-in rules for common attacks, misconfigurations, policy violations
- Alert levels 0-15 (0 = ignored, 1-3 = low, 4-7 = medium, 8-11 = high, 12-15 = critical)
- Compliance mapping: PCI DSS, GDPR, HIPAA, NIST 800-53, GPG13

### 12.2 Wazuh Rule Format

```xml
<!-- Wazuh Rule Structure -->
<group name="group_name,">

  <rule id="100001" level="12">
    <if_sid>5710</if_sid>                    <!-- Parent rule dependency -->
    <srcip>!127.0.0.1</srcip>               <!-- Source IP filter -->
    <match>Failed password</match>           <!-- Simple string match -->
    <regex>Failed \w+ for (\S+)</regex>      <!-- Regex extraction -->
    <description>SSH brute force attempt</description>
    <group>authentication_failures,pci_dss_10.2.4,gpg13_7.1,</group>
    <mitre>
      <id>T1110.001</id>                     <!-- ATT&CK mapping -->
    </mitre>
    <options>no_full_log</options>
    <frequency>5</frequency>                 <!-- Alert after N matches -->
    <timeframe>120</timeframe>               <!-- Within N seconds -->
  </rule>

</group>
```

### 12.3 Wazuh Detection Rules — Examples

```xml
<!-- Detect Mimikatz Execution (T1003) -->
<rule id="100100" level="14">
  <if_sid>61603</if_sid>
  <field name="win.eventdata.originalFileName">mimikatz</field>
  <description>Mimikatz credential dumping tool detected</description>
  <mitre>
    <id>T1003.001</id>
  </mitre>
  <group>credential_access,</group>
</rule>

<!-- Detect PowerShell Encoded Command (T1059.001) -->
<rule id="100101" level="12">
  <if_sid>92100</if_sid>
  <field name="win.eventdata.commandLine" type="pcre2">(?i)-enc[odedcommand]*\s+[A-Za-z0-9+/=]{20,}</field>
  <description>PowerShell execution with encoded command detected</description>
  <mitre>
    <id>T1059.001</id>
  </mitre>
  <group>execution,</group>
</rule>

<!-- Detect SSH Brute Force (T1110.001) -->
<rule id="100102" level="10" frequency="5" timeframe="60">
  <if_matched_sid>5710</if_matched_sid>
  <description>SSH brute force attack detected (5+ failures in 60s)</description>
  <mitre>
    <id>T1110.001</id>
  </mitre>
  <group>authentication_failures,</group>
</rule>

<!-- FIM: Critical File Modified -->
<rule id="100103" level="12">
  <if_sid>550</if_sid>
  <match>/etc/shadow|/etc/passwd|/etc/sudoers</match>
  <description>Critical system file modified</description>
  <mitre>
    <id>T1098</id>
  </mitre>
  <group>file_integrity,</group>
</rule>
```

### 12.4 OSSEC Rule Engine

OSSEC (Wazuh's predecessor) uses the same rule/decoder architecture:

- **Decoders**: Parse raw log lines into structured fields using regex. Decoders chain — a parent decoder matches the log source, child decoders extract specific fields.
- **Rules**: Match against decoded fields. Rules are hierarchical — child rules (`if_sid`) depend on parent rules firing first.
- **Alert levels**: 0-15 scale. Level 0 rules are used for internal correlation only (no alert). Levels 7+ typically generate actionable alerts.
- **Active response**: Configurable automated actions (firewall block, account disable) triggered by rule matches.

---

## 13. Threat Intelligence Platforms

### 13.1 MISP (Malware Information Sharing Platform)

**Data Model**:
- **Events**: Container for related indicators/context around a threat
- **Attributes**: Atomic IOCs (IP, domain, hash, email, URL, filename, etc.)
- **Objects**: Complex structured data (e.g., file object with name+hash+size)
- **Galaxies**: Intelligence vocabularies — threat actors, malware families, ATT&CK mapping
- **Taxonomies**: Classification tags (TLP, CSIRT case classification, admiralty code)
- **Correlation engine**: Automatic relationship discovery between attributes including fuzzy hashing (ssdeep) and CIDR block matching

**Export formats**: STIX 1.x/2.x (JSON/XML), OpenIOC, Snort/Suricata rules, Zeek Intel format, RPZ zones, CSV, MISP JSON, plain text

**SIEM Integration Pattern**:
```
MISP --> PyMISP API --> SIEM Lookup Table / Threat Intel Feed
                   --> Suricata rules (auto-generated)
                   --> Zeek Intel framework
                   --> YARA rules
```

### 13.2 OpenCTI

**Architecture**: GraphQL API, TypeScript/React frontend, Python workers

**Data Model**: Full STIX2 standard — Reports, Indicators, Malware, Campaigns, Intrusion Sets, Attack Patterns, Threat Actors, Observed Data, Vulnerabilities, Tools

**Integrations**: Bidirectional with MISP, TheHive, MITRE ATT&CK. Connector hub for external data sources (VirusTotal, AlienVault OTX, AbuseIPDB, Shodan, etc.)

**Key Feature**: Relationship inference — derives new relationships from existing ones. If Threat Actor A uses Malware B, and Malware B exploits Vulnerability C, OpenCTI infers and displays the indirect relationship.

### 13.3 TI Integration Architecture

```
+-----------+     +-----------+     +-----------+
| OSINT     |     | Commercial|     | Internal  |
| Feeds     |     | TI Feeds  |     | IR Data   |
+-----------+     +-----------+     +-----------+
      |                 |                 |
      +--------+--------+--------+--------+
               |                 |
        +------v------+  +------v------+
        |    MISP     |  |   OpenCTI   |
        | (IOC mgmt)  |  | (Strategic) |
        +------+------+  +------+------+
               |                 |
        +------v-----------------v------+
        |        TI Distribution        |
        +------+--------+--------+------+
               |        |        |
        +------v--+ +---v----+ +-v--------+
        | SIEM    | | EDR    | | Firewall  |
        | Watchlist| | Block  | | Block     |
        +---------+ +--------+ +----------+
```

### 13.4 IOC Lifecycle Management

| Phase | Action | SLA |
|-------|--------|-----|
| **Ingest** | Receive IOC from feed/IR/OSINT | Continuous |
| **Validate** | Confirm accuracy, check for FP | <4 hours for critical |
| **Enrich** | Add context (TTP, campaign, confidence) | <8 hours |
| **Distribute** | Push to SIEM, EDR, firewall, proxy | <1 hour after validation |
| **Monitor** | Track hits, correlate with alerts | Continuous |
| **Expire** | Remove stale IOCs (IP: 30d, Domain: 90d, Hash: 1y) | Automated |
| **Review** | Assess feed quality, adjust confidence | Monthly |

---

## 14. Incident Response Platforms

### 14.1 TheHive

**Core Functions**:
- Case management for DFIR investigations
- Observable tracking (IOCs associated with cases)
- Task assignment and workflow management
- Collaborative investigation with multiple analysts

**Integrations**:
- **Cortex**: Automated observable analysis — submit hash/IP/domain to 100+ analyzers (VT, OTX, MISP, Shodan, PassiveTotal, etc.)
- **MISP**: Bidirectional IOC sharing — import MISP events as cases, export case observables to MISP

**Note**: Open-source versions (3.x, 4.x) are archived. Current development by StrangeBee is commercial. For open-source alternatives, consider DFIR-IRIS.

### 14.2 SOCFortress CoPilot

**Integration Hub**: Connects Wazuh (EDR), Graylog (log management), Velociraptor (forensics), Grafana (visualization), InfluxDB (metrics)

**SOC Workflow**: Single-pane aggregation of alerts from multiple security tools via API/webhook connectors. Currently in beta.

### 14.3 LogonTracer

**Purpose**: Visualize Windows authentication events as a graph to identify lateral movement and compromised credentials.

**Event IDs Analyzed**:
- 4624 — Successful logon
- 4625 — Failed logon
- 4768 — Kerberos TGT request
- 4769 — Kerberos service ticket request
- 4776 — NTLM authentication
- 4672 — Special privileges assigned

**Detection Algorithms**:
- **PageRank**: Identifies important nodes in the authentication graph (heavily connected accounts/hosts)
- **Hidden Markov Model**: Detects behavioral patterns indicating compromise
- **ChangeFinder**: Identifies anomalous deviations from normal logon patterns

**Architecture**: Python + Neo4j graph database + Cytoscape visualization

---

## 15. Windows Event Log Reference

### 15.1 Critical Security Events

| Event ID | Channel | Description | Detection Use |
|----------|---------|-------------|---------------|
| **4624** | Security | Successful logon | Lateral movement, pass-the-hash |
| **4625** | Security | Failed logon | Brute force, password spray |
| **4648** | Security | Logon with explicit credentials | RunAs, credential use |
| **4672** | Security | Special privileges assigned | Admin logon detection |
| **4688** | Security | Process creation | Command execution (needs cmd line auditing) |
| **4689** | Security | Process termination | Process lifecycle |
| **4698** | Security | Scheduled task created | Persistence |
| **4720** | Security | User account created | Account manipulation |
| **4728/4732** | Security | Member added to security group | Privilege escalation |
| **4768** | Security | Kerberos TGT request | Authentication anomaly |
| **4769** | Security | Kerberos service ticket | Kerberoasting |
| **4776** | Security | NTLM authentication | Credential validation |
| **5140** | Security | Network share accessed | Lateral movement |
| **5145** | Security | Network share object checked | File access auditing |
| **1102** | Security | Audit log cleared | Anti-forensics |
| **7045** | System | Service installed | Persistence, lateral move |

### 15.2 Sysmon Events

| Event ID | Description | Key Fields |
|----------|-------------|------------|
| **1** | Process Create | Image, CommandLine, ParentImage, ParentCommandLine, User, Hashes, IntegrityLevel |
| **2** | File creation time changed | TargetFilename, PreviousCreationUtcTime (timestomping) |
| **3** | Network connection | SourceIp, SourcePort, DestinationIp, DestinationPort, Protocol |
| **5** | Process terminated | Image |
| **6** | Driver loaded | ImageLoaded, Hashes, Signature, SignatureStatus |
| **7** | Image loaded (DLL) | Image, ImageLoaded, Hashes, SignatureStatus |
| **8** | CreateRemoteThread | SourceImage, TargetImage (injection detection) |
| **10** | Process access | SourceImage, TargetImage, GrantedAccess (LSASS dumping) |
| **11** | File create | TargetFilename |
| **12/13/14** | Registry create/set/rename | TargetObject, Details |
| **15** | FileCreateStreamHash | TargetFilename (ADS detection) |
| **17/18** | Pipe created/connected | PipeName (C2, lateral movement) |
| **19/20/21** | WMI Event filter/consumer/binding | EventType, Operation (WMI persistence) |
| **22** | DNS query | QueryName, QueryResults |
| **23** | File delete (archived) | TargetFilename |
| **25** | Process tampering | Image, Type (process hollowing, herpaderping) |
| **26** | File delete logged | TargetFilename |

### 15.3 PowerShell Logging

| Event ID | Log | Description |
|----------|-----|-------------|
| **4103** | PowerShell/Operational | Module logging — captures pipeline execution details |
| **4104** | PowerShell/Operational | Script block logging — captures full script content (deobfuscated) |
| **4105/4106** | PowerShell/Operational | Script block start/stop |

**Required GPO settings**:
- Enable Module Logging: `Computer Configuration > Administrative Templates > Windows Components > Windows PowerShell > Turn on Module Logging` (set to `*`)
- Enable Script Block Logging: `...> Turn on PowerShell Script Block Logging`
- Enable Transcription: `...> Turn on PowerShell Transcription`

### 15.4 EVTX Attack Samples Reference

The EVTX-ATTACK-SAMPLES repository (~200 samples) covers:

| Tactic | Sample Categories |
|--------|------------------|
| **Execution** | PowerShell, WMI, MSHTA, Regsvr32, Rundll32, CMSTP |
| **Persistence** | Scheduled tasks, services, registry run keys, WMI subscriptions |
| **Privilege Escalation** | UAC bypass (UACME variants), token manipulation |
| **Defense Evasion** | Process injection, masquerading, log clearing, AMSI bypass |
| **Credential Access** | LSASS dumping, Kerberoasting, DCSync |
| **Lateral Movement** | PsExec, WMI remote, RDP, SMB |
| **Command and Control** | DNS tunneling, HTTP C2, named pipes |
| **Discovery** | Net commands, BloodHound, ADFind |

---

## 16. Detection Coverage by ATT&CK Tactic

### 16.1 Coverage Heat Map (Priority Detection Investment)

```
                    | Windows | Linux | Cloud | Network |
---------------------------------------------------------
Initial Access      |  Med    |  Low  | Med   |  High   |
Execution           |  High   |  Med  | Med   |  Low    |
Persistence         |  High   |  Med  | Med   |  Low    |
Privilege Esc.      |  High   |  Med  | Med   |  Low    |
Defense Evasion     |  High   |  Med  | Low   |  Med    |
Credential Access   |  High   |  Med  | Med   |  Low    |
Discovery           |  Med    |  Med  | Med   |  Low    |
Lateral Movement    |  High   |  Low  | Med   |  High   |
Collection          |  Med    |  Low  | Low   |  Med    |
Exfiltration        |  Med    |  Med  | Med   |  High   |
C2                  |  Med    |  Low  | Low   |  High   |
Impact              |  High   |  Med  | Med   |  Low    |
```

### 16.2 Minimum Viable Detection Set

Every SOC should have detections for these high-value techniques at minimum:

| Technique | ID | Detection Source |
|-----------|----|-----------------|
| Phishing attachment | T1566.001 | Email gateway + endpoint |
| PowerShell execution | T1059.001 | Script block logging (4104) |
| Scheduled task creation | T1053.005 | Security Event 4698 |
| Registry run keys | T1547.001 | Sysmon Event 13 |
| LSASS memory access | T1003.001 | Sysmon Event 10 |
| Kerberoasting | T1558.003 | Security Event 4769 |
| Pass-the-Hash | T1550.002 | Security Event 4624 (Type 3 + NTLM) |
| RDP lateral movement | T1021.001 | Security Event 4624 (Type 10) |
| PsExec/remote service | T1021.002 | Security Event 7045 + 4624 |
| Security log cleared | T1070.001 | Security Event 1102 |
| New service installed | T1543.003 | System Event 7045 |
| DNS tunneling | T1071.004 | DNS logs + network |
| Data exfiltration | T1041 | Proxy/firewall volume anomaly |
| Ransomware indicators | T1486 | FIM + process creation |

---

## 17. SIEM Tuning & False Positive Reduction

### 17.1 Tuning Workflow

```
[High FP Alert] --> [Analyze FP Pattern] --> [Identify Root Cause]
                                                     |
                    +---------------+----------------+---------------+
                    |               |                |               |
              [Legitimate   [Missing      [Overly Broad   [Bad Data
               Behavior]     Context]       Rule Logic]    Quality]
                    |               |                |               |
              [Add Allow    [Enrich with   [Narrow         [Fix
               List Entry]  Asset/User      Selection       Parser/
                            Context]        Criteria]       Source]
```

### 17.2 Tuning Strategies

| Strategy | When to Use | Example |
|----------|-------------|---------|
| **Allowlist by process path** | Known good signed binary triggers | Exclude `C:\Program Files\Tool\legitimate.exe` |
| **Allowlist by user/group** | Service accounts trigger behavior alerts | Exclude `svc_backup` from file access rules |
| **Threshold adjustment** | Too many low-fidelity single events | Raise brute force from 3 to 10 failures |
| **Time-based suppression** | Known maintenance windows | Suppress patching alerts during WSUS window |
| **Asset-based severity** | All alerts same priority | Boost severity for domain controllers, lower for dev laptops |
| **Correlation chaining** | Single events too noisy | Require process creation + network connection + file write |
| **Negative logic** | Known good pattern dominates | `NOT (ParentImage LIKE '%sccm%' AND Image LIKE '%powershell%')` |

### 17.3 Alert Prioritization Formula

```
Priority Score = (Alert Severity * Asset Criticality * Data Sensitivity)
                 / (False Positive History Score)

Where:
  Alert Severity:      Critical=4, High=3, Medium=2, Low=1
  Asset Criticality:   Crown Jewel=4, Production=3, Staging=2, Dev=1
  Data Sensitivity:    PII/PHI=4, Financial=3, Internal=2, Public=1
  FP History Score:    Never FP=1, Rare FP=2, Occasional FP=3, Frequent FP=4
```

### 17.4 Rule Lifecycle States

```
EXPERIMENTAL --> TEST --> STABLE --> DEPRECATED --> RETIRED
     |            |         |            |
     |     [Validated  [Production  [Replaced by
     |      against     alerting]    better rule
     |      datasets]                or TTP changed]
     |
  [Initial development,
   detection-only mode]
```

---

## 18. SOC Metrics & KPIs

### 18.1 Operational Metrics

| Metric | Definition | Target |
|--------|-----------|--------|
| **MTTD** (Mean Time to Detect) | Time from compromise to first alert | <24 hours |
| **MTTR** (Mean Time to Respond) | Time from alert to containment | Critical: <1h, High: <4h |
| **MTTA** (Mean Time to Acknowledge) | Time from alert fire to analyst pickup | <15 minutes |
| **Alert Volume** | Total alerts per day/week | Track trend, not absolute |
| **True Positive Rate** | TP / (TP + FP) | >80% for tuned rules |
| **False Positive Rate** | FP / (TP + FP) | <20% per rule |
| **Escalation Rate** | Alerts escalated T1->T2 | 10-20% of total |
| **Alert Closure Rate** | Alerts closed per analyst per shift | Track for burnout |
| **Coverage Score** | ATT&CK techniques with active detections / total techniques | >60% for priority techniques |

### 18.2 Detection Engineering Metrics

| Metric | Definition | Target |
|--------|-----------|--------|
| **Detection Coverage** | % of priority ATT&CK techniques with rules | >80% |
| **Rule Count** | Active detection rules | Track growth |
| **Rules per Analyst** | Rules maintained per detection engineer | <200 |
| **Mean Rule Age** | Average age of detection rules | Review if >1 year |
| **Sigma Conversion Rate** | % of rules written in vendor-agnostic Sigma | >50% |
| **Time to Detection** | From TTP identification to deployed rule | <1 week for critical |
| **Backlog** | Unaddressed detection gaps | Track reduction |

### 18.3 SOC Maturity Model

```
Level 0: REACTIVE
  - No SIEM or ad-hoc log review
  - Incident response is manual and inconsistent
  - No documented procedures

Level 1: BASIC
  - SIEM deployed with default rules
  - Basic log collection (firewall, AV)
  - Documented IR procedures exist
  - Single-tier analyst team

Level 2: DEVELOPING
  - Tuned detection rules, reduced FP rate
  - Multi-source log collection (endpoint, network, cloud)
  - Tiered SOC structure (T1/T2)
  - Basic threat intel integration
  - Documented playbooks for top 10 alert types

Level 3: ESTABLISHED
  - Detection-as-code pipeline with CI/CD
  - Comprehensive log coverage with normalization (OSSEM/CIM/ECS)
  - Proactive threat hunting program
  - SOAR integration for automated enrichment/response
  - TI platform (MISP/OpenCTI) integrated
  - Purple team exercises quarterly

Level 4: OPTIMIZED
  - ML/statistical anomaly detection in production
  - ATT&CK coverage >80% for priority techniques
  - Automated detection testing against attack datasets
  - Mean rule age <6 months (continuous improvement)
  - Predictive analytics and trend analysis
  - Red team findings drive detection development
  - Cross-organizational TI sharing

Level 5: RESILIENT
  - Assume-breach operating model
  - Deception technology (honeypots, honey tokens)
  - Automated containment for high-confidence detections
  - Sub-1-hour MTTR for critical incidents
  - Detection gap analysis drives security architecture decisions
  - SOC metrics drive board-level risk reporting
```

---

## Appendix A: Quick Reference — Query Language Comparison

| Operation | KQL (Sentinel) | SPL (Splunk) | EQL (Elastic) |
|-----------|---------------|-------------|---------------|
| Filter rows | `where Field == "value"` | `Field="value"` or `\| where Field="value"` | `category where field == "value"` |
| Wildcard match | `has`, `contains`, `startswith` | `Field="*value*"` | `field : "*value*"` |
| Case insensitive | `=~` or `has` | Default behavior | `:` or `like~` |
| Count | `\| count` | `\| stats count` | N/A (use aggregations API) |
| Distinct count | `\| summarize dcount(Field)` | `\| stats dc(Field)` | N/A |
| Group by | `\| summarize count() by Field` | `\| stats count by Field` | N/A |
| Time filter | `\| where TimeGenerated > ago(24h)` | `earliest=-24h` | Timestamp range in query |
| Join | `\| join kind=inner (Table2) on Key` | `\| join Field [search ...]` | `sequence by Field` |
| Top N | `\| top N by Field` | `\| head N` or `\| top N Field` | `\| head N` |
| Regex | `\| where Field matches regex "pattern"` | `\| rex field=Field "(?<name>pattern)"` | `field regex "pattern"` |
| Multi-event sequence | N/A (use multiple queries + join) | `\| transaction` | `sequence with maxspan=Nm [e1][e2]` |
| Time bucket | `bin(TimeGenerated, 1h)` | `bucket _time span=1h` | N/A |
| Calculated field | `\| extend NewField = expr` | `\| eval NewField = expr` | N/A |

## Appendix B: Log Collection Checklist

```
SIEM ONBOARDING CHECKLIST
=========================

[ ] Windows Security Events (4624, 4625, 4648, 4672, 4688, 4698, 4720, 4732, 1102)
[ ] Windows System Events (7045)
[ ] Sysmon (all events, or at minimum 1, 3, 7, 8, 10, 11, 13, 22, 23, 25)
[ ] PowerShell Script Block Logging (4103, 4104)
[ ] Windows Defender (1006, 1007, 1116, 1117, 5001)
[ ] Linux auditd (execve, connect, open, ptrace, user/group changes)
[ ] Linux auth.log (SSH, sudo, PAM)
[ ] DNS query logs (server-side or Sysmon Event 22)
[ ] Firewall connection logs (allow + deny)
[ ] Web proxy logs (URL, user-agent, response code)
[ ] Email gateway logs (sender, recipient, attachment, verdict)
[ ] VPN/remote access logs (session start/stop, source IP, MFA status)
[ ] Cloud audit logs (AWS CloudTrail, Azure Activity, GCP Audit)
[ ] Identity provider logs (Entra ID, Okta, Duo sign-in + MFA)
[ ] EDR/XDR telemetry (if not already feeding above)
[ ] Application-specific logs (critical business apps)
[ ] Network IDS/IPS (Suricata/Zeek alerts and metadata)
```

## Appendix C: SIEM Health Monitoring

```kql
// Sentinel — Monitor ingestion lag per table
Usage
| where TimeGenerated > ago(1h)
| summarize IngestionLag = avg(datetime_diff('second', ingestion_time(), TimeGenerated))
    by DataType
| where IngestionLag > 300  // Alert if >5 min lag
| sort by IngestionLag desc
```

```spl
// Splunk — Monitor indexing delay per sourcetype
index=_internal source=*metrics.log group=per_sourcetype_thruput
| stats avg(ev) as avg_eps max(ev) as max_eps by series
| where avg_eps < 1
| rename series as sourcetype
```

```
// General SIEM Health Checks (daily)
[ ] All expected log sources reporting within SLA
[ ] No parser/decoder errors in last 24h
[ ] Agent heartbeat — all endpoints reporting
[ ] Storage utilization within threshold
[ ] Correlation engine processing without delay
[ ] Scheduled searches/rules completing on time
[ ] Backup verification
```

---

*This document is a living reference. Update detection queries as new TTPs emerge and validate rules against current attack datasets (EVTX-ATTACK-SAMPLES, OTRF Security Datasets) quarterly.*
