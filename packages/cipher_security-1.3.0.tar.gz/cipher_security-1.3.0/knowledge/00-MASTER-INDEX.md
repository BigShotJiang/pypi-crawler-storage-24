# CIPHER Training Corpus — Master Cross-Reference Index

> Generated 2026-03-14 | Updated 2026-03-14 | 88 training documents | 124,002 total lines
> This index ties the entire CIPHER training corpus together for rapid lookup.

---

## Table of Contents

1. [Document Registry](#1-document-registry)
2. [MITRE ATT&CK Technique Index](#2-mitre-attck-technique-index)
3. [Security Tool Index](#3-security-tool-index)
4. [Compliance & Framework Index](#4-compliance--framework-index)
5. [OWASP Reference Index](#5-owasp-reference-index)
6. [Topic Finder (A-Z)](#6-topic-finder-a-z)
7. [Scenario Router](#7-scenario-router)

---

## 1. Document Registry

| # | Document | Primary Domain | Lines | Key Topics |
|---|----------|---------------|-------|------------|
| 1 | `active-directory-deep.md` | Offensive / AD | 1300 | Table of Contents, Kerberos Attacks, NTLM Attacks, AD Certificate Services (ADCS) |
| 2 | `ai-defense-deep.md` | Defensive / AI | 1892 | Table of Contents, Threat Landscape Overview, OWASP Top 10 for LLM Applications — Miti, MITRE ATLAS Framework |
| 3 | `api-exploitation-deep.md` | Offensive / AppSec | 1595 | Table of Contents, OWASP API Security Top 10 (2023), GraphQL Exploitation, REST API Testing Methodology |
| 4 | `attack-chains-synthesis.md` | Offensive / Synthesis | 1192 | Scenario 1: External Pentest — Web App R, Scenario 2: Phishing — Macro Execution —, Scenario 3: Supply Chain Compromise — Ma, Scenario 4: Password Spray — O365 Access |
| 5 | `aws-security-ultimate.md` | Cloud / AWS | 1615 | Training Reference — CIPHER Security Kno, Table of Contents, IAM Security, S3 Security |
| 6 | `azure-security-ultimate.md` | Cloud / Azure | 1837 | Table of Contents, Entra ID (Azure AD) Fundamentals, Entra ID Attack Surface, Azure RBAC & Privilege Escalation |
| 7 | `binary-exploitation-deep.md` | Offensive / Binary | 1252 | Table of Contents, Toolchain & Environment, Stack-Based Buffer Overflows, Return-Oriented Programming (ROP) |
| 8 | `blockchain-web3-deep.md` | Offensive / Web3 | 1031 | Table of Contents, Smart Contract Vulnerability Taxonomy, Solidity Security Patterns, DeFi-Specific Attack Vectors |
| 9 | `bugbounty-methodology-deep.md` | Offensive / BugBounty | 1588 | Table of Contents, Recon Automation Pipelines, Vulnerability Discovery Workflows, Nuclei Template Patterns |
| 10 | `c2-postexploit-deep.md` | Offensive / C2 | 1533 | Table of Contents, Sliver C2 Framework, Mythic C2 Framework, Metasploit Framework |
| 11 | `cloud-attacks-deep.md` | Offensive / Cloud | 1085 | Table of Contents, AWS IAM Privilege Escalation, AWS S3 Exploitation, AWS EC2 IMDS Exploitation |
| 12 | `cloud-infra-deep.md` | Defensive / Cloud | 877 | Training Session: 2026-03-14, Source Material: CloudFox, CloudGoat, Pr, CloudFox -- Cloud Attack Path Discovery , CloudGoat -- Vulnerable-by-Design AWS Sc |
| 13 | `compliance-frameworks-deep.md` | GRC / Compliance | 1090 | Table of Contents, NIST Cybersecurity Framework (CSF) 2.0, NIST SP 800-53 Rev 5, NIST SP 800-171 (CUI Protection) |
| 14 | `container-k8s-deep.md` | DevSecOps / Containers | 1338 | Training Session: 2026-03-14, Source Material: OWASP Docker/K8s Cheat , Docker Hardening Controls (OWASP), Kubernetes RBAC |
| 15 | `crypto-pki-tls-deep.md` | Architecture / Crypto | 843 | Algorithm Recommendations, Password Hashing, TLS Configuration, PKI Architecture |
| 16 | `ctf-methodology-deep.md` | Training / CTF | 1397 | Table of Contents, General CTF Methodology, Web Exploitation, Cryptography |
| 17 | `curated-resources-deep.md` | Reference / Resources | 666 | AWESOME-SECURITY (sbilly/awesome-securit, AWESOME-SECURITY-HARDENING (decalage2), AWESOME-CYBERSECURITY-BLUETEAM (fabacab), AWESOME-PENTEST (fabacab) |
| 18 | `defensive-deep.md` | Defensive / Core | 1042 | CrowdSec — Behavioral Detection Engine A, Prowler — Cloud Security Posture Managem, Ansible Collection Hardening — Specific , Incident Response Tools & Procedures |
| 19 | `defensive-synthesis.md` | Defensive / Synthesis | 1077 | Detection Coverage Matrix — Top 50 MITRE, Security Architecture Decision Trees, Security Tool Selection Matrix, Quick Reference Cards |
| 20 | `dev-security-deep.md` | General | 1315 | Table of Contents, Handling User Input Safely, Authentication Implementation, Authorization Patterns |
| 21 | `devsecops-sdlc-deep.md` | DevSecOps / SDLC | 1311 | Table of Contents, Secure SDLC Framework, SAST Tools — Static Application Security, DAST Tools — Dynamic Application Securit |
| 22 | `dfir-hunting-deep.md` | DFIR / Hunting | 1988 | Velociraptor — VQL Query Language & Arti, Hayabusa — Windows Event Log Timeline Ge, Chainsaw — Rapid Forensic Hunting, KAPE — Evidence Collection Framework |
| 23 | `dns-email-infra-deep.md` | Infrastructure / DNS-Email | 1998 | Table of Contents, DNS Fundamentals for Security Practition, DNS Zone Transfer Attacks, DNS Cache Poisoning |
| 24 | `edr-av-internals-deep.md` | Purple / EDR-AV Internals | 1263 | EDR Architecture Overview, EDR Hooks & Telemetry Sources, AV Scanning Methods, EDR Bypass Techniques Mapped to Detection Gaps |
| 25 | `email-forensics-deep.md` | DFIR / Email Forensics | 1851 | Email Header Anatomy, Received Header Chain Analysis, BEC Investigation Playbook, Microsoft 365 Email Forensics |
| 26 | `email-phishing-se-deep.md` | Offensive / Phishing | 1491 | Table of Contents, Phishing Taxonomy & ATT&CK Mapping, Phishing Infrastructure Setup, MFA Bypass Techniques |
| 27 | `emerging-threats-deep.md` | Threat Intel / Emerging | 599 | Current Threat Landscape Summary, Active Exploitation Campaigns (as of Mar, Trending CVEs and Vulnerability Classes, Threat Actor Activity |
| 28 | `encoding-manipulation-deep.md` | Offensive / Encoding | 2294 | Table of Contents, Base Encoding, Hex Encoding, URL Encoding |
| 29 | `evasion-detection-catalog.md` | Purple / Evasion-Detection | 1601 | Table of Contents, Impair Defenses, Indicator Removal, Process Injection |
| 30 | `evasion-techniques-deep.md` | Offensive / Evasion | 801 | Table of Contents, Direct Syscalls, AMSI Bypass Methods, ETW Bypass |
| 31 | `exfil-tunneling-deep.md` | Offensive / Exfiltration | 1222 | Table of Contents, MITRE ATT&CK Framework Mapping, Data Staging & Collection (TA0009), DNS Tunneling & Exfiltration |
| 32 | `forensics-artifacts-deep.md` | DFIR / Forensics | 1449 | Table of Contents, Windows Artifacts, Linux Artifacts, macOS Artifacts |
| 33 | `gcp-security-deep.md` | Cloud / GCP | 2070 | Table of Contents, GCP Architecture & Security Foundations, IAM Deep Dive & Privilege Escalation, Service Account Exploitation |
| 34 | `grc-risk-deep.md` | GRC / Risk | 1117 | Table of Contents, Risk Assessment Methodology, Security Program Maturity Models, Board-Level Reporting |
| 35 | `hardening-guides-ultimate.md` | Defensive / Hardening | 2861 | Table of Contents, Linux Server Hardening, Windows Server Hardening, SSH Hardening |
| 36 | `ics-scada-deep.md` | OT / ICS-SCADA | 1245 | Table of Contents, Purdue Enterprise Reference Architecture, ICS Protocol Attack Surfaces, PLC Exploitation Methodology |
| 37 | `identity-auth-deep.md` | Architecture / Identity | 1021 | Table of Contents, OAuth 2.0 Attack Flows, JWT Attacks, SAML Attacks |
| 38 | `incident-playbooks-deep.md` | DFIR / IR Playbooks | 2794 | Document Purpose, Severity Classification Matrix (All Play, Roles Quick Reference, 1.1 Detection Triggers |
| 39 | `insider-threat-dlp-deep.md` | Defensive / Insider Threat | 1059 | Table of Contents, Insider Threat Taxonomy, Insider Threat Indicators, Data Classification Framework |
| 40 | `kubernetes-attacks-deep.md` | Purple / Kubernetes Attacks | 1665 | Threat Matrices, Bad Pod Escalation Paths, Pod Escape Techniques, API Server Attacks |
| 41 | `linux-exploitation-deep.md` | Offensive / Linux | 1775 | TABLE OF CONTENTS, Enumeration & Reconnaissance, Kernel Exploitation, SUDO Abuse |
| 42 | `logging-monitoring-deep.md` | Defensive / Logging | 1681 | Table of Contents, Logging Fundamentals, OWASP Logging Standards, OWASP Logging Vocabulary |
| 43 | `malware-analysis-deep.md` | DFIR / Malware Analysis | 1573 | Table of Contents, Analysis Philosophy, Lab Environment Setup, Static Analysis Workflow |
| 44 | `malware-re-evasion-deep.md` | Offensive / Malware Dev | 1026 | Table of Contents, Anti-Debugging Techniques, Anti-VM / Sandbox Evasion, Windows API to Malware Behavior Mapping |
| 45 | `mitre-attack-deep.md` | Framework / ATT&CK | 1167 | Table of Contents, Enterprise Tactics Overview, Tactic-by-Tactic Technique Inventory, Critical Technique Deep Dives |
| 46 | `mobile-security-deep.md` | AppSec / Mobile | 2030 | Table of Contents, OWASP Mobile Application Security (MAS) , MASVS Controls — Complete Reference, Android Platform Security Architecture |
| 47 | `network-attacks-deep.md` | Offensive / Network | 1250 | Training Reference — CIPHER Security Tra, Table of Contents, Name Resolution Poisoning, NTLM Relay Attack Chains |
| 48 | `network-forensics-deep.md` | DFIR / Network Forensics | 1387 | Table of Contents, Beacon Detection Methodology, TLS Fingerprinting: JA3 / JA3S / JARM, SSH Fingerprinting: HASSH |
| 49 | `network-protocol-deep.md` | Architecture / Protocols | 1273 | Protocol Analysis with Wireshark, Packet Crafting with hping3, Social Engineering Toolkit (SET) Attack , Cloud Attack Paths |
| 50 | `offensive-deep.md` | Offensive / Core | 1376 | Table of Contents, SQL Injection, Cross-Site Scripting (XSS), Server-Side Request Forgery (SSRF) |
| 51 | `osint-tradecraft-deep.md` | OSINT / Tradecraft | 1379 | Training Classification: Advanced OSINT , OPSEC for OSINT Investigators, Advanced Google Dorking, Social Media Intelligence (SOCMINT) |
| 52 | `password-credential-deep.md` | Offensive / Credentials | 1004 | Table of Contents, Hashcat Mode Reference, Rule-Based Attack Methodology, Wordlist Generation Strategies |
| 53 | `pentest-cheatsheet-ultimate.md` | Offensive / Pentest | 2851 | TABLE OF CONTENTS, RECON (PASSIVE + ACTIVE), SCANNING & SERVICE ENUMERATION, WEB EXPLOITATION |
| 54 | `pentest-reporting-deep.md` | Offensive / Reporting | 1235 | Table of Contents, PTES Methodology Phases, OWASP WSTG Testing Structure, Report Structure Templates |
| 55 | `privacy-crypto-deep.md` | Privacy / Cryptography | 624 | Cryptomator -- Transparent Cloud File En, Ente -- End-to-End Encrypted Photo/File , Yopass -- Ephemeral Secret Sharing, imgcrypt -- OCI Container Image Encrypti |
| 56 | `privacy-engineering-deep.md` | Privacy / Engineering | 1953 | Privacy Impact Assessments, Data Flow Ma, Table of Contents, Complete DPIA Template with Worked Examp, Data Flow Mapping Methodology |
| 57 | `privacy-osint-deep.md` | Privacy / OSINT | 1005 | SIGNAL PROTOCOL ARCHITECTURE, VERACRYPT ENCRYPTION ARCHITECTURE, OSINT METHODOLOGY AND TOOLS, SOPS SECRETS MANAGEMENT ARCHITECTURE |
| 58 | `privacy-regulations-deep.md` | Privacy / Regulations | 1556 | Comprehensive Reference for MODE: PRIVAC, Table of Contents, GDPR Article-by-Article Key Requirements, CCPA/CPRA Rights and Obligations |
| 59 | `purple-team-deep.md` | Purple / Operations | 1031 | Table of Contents, Adversary Emulation Plan Structure, Atomic Red Team Test Execution, Detection Coverage Gap Analysis Methodol |
| 60 | `recon-osint-deep.md` | OSINT / Recon | 1181 | Source Material Analyzed, RECONFTW: Full Automated Recon Workflow, BBOT: Event-Driven Scanning Framework, NMAP: NSE Scripting Engine Deep Dive |
| 61 | `redteam-infra-deep.md` | Offensive / Infrastructure | 1415 | Table of Contents, Infrastructure Architecture, Domain and Certificate Management, Redirector Design |
| 63 | `secops-runbooks-deep.md` | Defensive / SecOps | 1536 | Table of Contents, Daily SOC Operations, Vulnerability Management, Threat Intelligence Operations |
| 64 | `secure-coding-deep.md` | DevSecOps / Secure Code | 1751 | Table of Contents, SQL Injection Prevention, Cross-Site Scripting (XSS) Prevention, OS Command Injection Defense |
| 65 | `secure-infrastructure-deep.md` | Architecture / Infra | 1260 | Network Segmentation Architecture, Firewall Rule Design, Reverse Proxy Hardening (NGINX), VPN Architecture |
| 66 | `security-architecture-deep.md` | Architecture / Design | 1157 | Table of Contents, Defense-in-Depth Patterns, Zero Trust Network Architecture, Microservices Security Architecture |
| 67 | `security-automation-deep.md` | Defensive / Automation | 1174 | Table of Contents, SOAR Architecture Patterns, Playbook Patterns, Automated IOC Processing Pipelines |
| 68 | `security-certifications-deep.md` | Training / Certs | 1254 | Table of Contents, Certification Landscape & Career Pathing, Offensive Security Certifications, Governance, Risk & Management Certificat |
| 69 | `security-leadership-deep.md` | GRC / Leadership | 1548 | Table of Contents, CISO Role & Responsibilities, Security Program Maturity Assessment, Board Reporting & Executive Communicatio |
| 70 | `security-mastery-deep.md` | Training / Mastery | 1070 | Network Security Fundamentals, Cryptography, Application Security, Cloud Security |
| 71 | `security-metrics-deep.md` | GRC / Metrics | 829 | Table of Contents, Foundations: Why Measure Security, Vulnerability Management Metrics, SOC & Detection Metrics |
| 72 | `security-scenarios.md` | Training / Scenarios | 4218 | Scenario 01: Ransomware Incident Respons, Scenario 02: Zero Trust Architecture Des, Scenario 03: AWS IAM Policy Review, Scenario 04: Detecting Kerberoasting |
| 73 | `shells-arsenal-deep.md` | Offensive / Shells | 1367 | Table of Contents, Reverse Shells — By Language, Netcat Variants, Socat |
| 74 | `siem-soc-deep.md` | Defensive / SIEM-SOC | 1778 | Table of Contents, SIEM Architecture Patterns, Log Sources & Collection, Data Normalization -- OSSEM & ASIM |
| 75 | `sigma-detection-deep.md` | Defensive / Sigma | 1657 | Table of Contents, What is Sigma, Rule Format Specification, Detection Logic Deep Dive |
| 76 | `social-engineering-deep.md` | Offensive / Social Eng | 1119 | Table of Contents, Psychological Foundations: Cialdini's Pr, Pretexting Development Methodology, Elicitation Techniques |
| 77 | `startup-security-deep.md` | Architecture / Startup Security | 1457 | Security for Startups: Founder's Playbook, Phase 1-5 Security Program Build, Compliance Mapping Matrix, Incident Response Starter Kit |
| 78 | `supply-chain-security-deep.md` | Architecture / Supply Chain | 1107 | Notable Supply Chain Attacks, SLSA Framework, Sigstore Ecosystem, SBOM Formats and Tooling |
| 79 | `threat-hunting-deep.md` | Defensive / Threat Hunt | 1942 | Table of Contents, Hunting Methodology Framework, Hypothesis Templates, Data Source Requirements |
| 80 | `threat-intel-deep.md` | Threat Intel / Core | 800 | CIPHER Knowledge Base — Current Threat L, Current Threat Landscape Overview, Threat Actor Profiles, Real-World Attack Chains from DFIR Repor |
| 81 | `threat-modeling-arch-deep.md` | Architecture / Threat Model | 717 | Table of Contents, Threat Modeling Methodologies, STRIDE Deep Dive, Data Flow Diagram Templates |
| 82 | `timeline-analysis-deep.md` | DFIR / Timeline Analysis | 1588 | Super Timeline Generation with Plaso, Timesketch Analysis Workflows, Eric Zimmerman Tool Chain, Anti-Forensics Detection |
| 83 | `vuln-research-deep.md` | Offensive / VulnResearch | 811 | Vulnerability Discovery Methodology, CVE Lifecycle, EPSS (Exploit Prediction Scoring System), Exploit Development Workflow |
| 84 | `websec-deep.md` | Offensive / WebSec | 1626 | Table of Contents, Vulnerability Taxonomy, Injection Attacks, Cross-Site Scripting (XSS) |
| 85 | `windows-ad-deep.md` | Offensive / Windows-AD | 1243 | TABLE OF CONTENTS, WINDOWS HARDENING CONTROLS, WDAC / APP CONTROL POLICIES, WINDOWS PRIVILEGE ESCALATION VECTORS |
| 86 | `windows-eventlog-mastery.md` | Defensive / Windows Events | 1454 | Security Event IDs — Authentication & Logon, Sysmon Event IDs — Complete Reference, PowerShell Logging Event IDs, JPCERT Tool-to-Event Mapping Table |
| 87 | `windows-internals-deep.md` | Defensive / Windows | 963 | Table of Contents, Windows Security Architecture, LOLBAS — 30 Most Abused Binaries, UAC Bypass Techniques |
| 88 | `wireless-physical-iot-deep.md` | Offensive / Wireless-IoT | 1018 | Table of Contents, Wireless Security — WiFi Attack Methodol, RF Security and Software Defined Radio, Bluetooth and Short-Range Wireless |

---

## 2. MITRE ATT&CK Technique Index

**557 unique technique IDs** mapped across the training corpus.

### 2.1 MITRE ATLAS Techniques (AI/ML)

*14 techniques*

| Technique ID | Document(s) |
|-------------|-------------|
| T0000 | `ai-defense-deep.md` |
| T0001 | `ai-defense-deep.md` |
| T0010 | `ai-defense-deep.md` |
| T0011 | `ai-defense-deep.md` |
| T0015 | `ai-defense-deep.md` |
| T0016 | `ai-defense-deep.md` |
| T0017 | `ai-defense-deep.md` |
| T0018 | `ai-defense-deep.md` |
| T0019 | `ai-defense-deep.md` |
| T0024 | `ai-defense-deep.md` |
| T0025 | `ai-defense-deep.md` |
| T0029 | `ai-defense-deep.md` |
| T0030 | `ai-defense-deep.md` |
| T0031 | `ai-defense-deep.md` |

### 2.2 ICS/OT Techniques (T08xx)

*83 techniques*

| Technique ID | Document(s) |
|-------------|-------------|
| T0800 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0801 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0802 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0803 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0804 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0805 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0806 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0807 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0809 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0811 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0812 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0813 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0814 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0815 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0816 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0817 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0819 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0820 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0821 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0822 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0823 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0826 | `ics-scada-deep.md`, `security-scenarios.md`, `wireless-physical-iot-deep.md` |
| T0827 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0828 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0829 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0830 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0831 | `ics-scada-deep.md`, `security-scenarios.md`, `wireless-physical-iot-deep.md` |
| T0832 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0834 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0835 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0836 | `attack-chains-synthesis.md`, `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0837 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0838 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0839 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0840 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0842 | `ics-scada-deep.md`, `security-scenarios.md`, `wireless-physical-iot-deep.md` |
| T0843 | `ics-scada-deep.md`, `security-scenarios.md`, `wireless-physical-iot-deep.md` |
| T0845 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0846 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0847 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0848 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0849 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0851 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0852 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0853 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0855 | `attack-chains-synthesis.md`, `ics-scada-deep.md`, `security-scenarios.md`, `wireless-physical-iot-deep.md` |
| T0856 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0857 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0858 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0859 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0860 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0861 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0862 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0863 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0864 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0865 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0866 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0867 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0868 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0869 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0871 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0872 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0873 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0874 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0877 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0878 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0879 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0880 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0881 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0882 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0883 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0884 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0885 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0886 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0887 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0888 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0889 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0890 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0891 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0892 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0893 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0894 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| T0895 | `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |

### 2.3 Enterprise Techniques (T1xxx)

*460 techniques*

| Technique ID | Document(s) |
|-------------|-------------|
| T1001 | `mitre-attack-deep.md` |
| T1003 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `container-k8s-deep.md`, `dfir-hunting-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `purple-team-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1003.001 | `active-directory-deep.md`, `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `password-credential-deep.md`, `purple-team-deep.md`, `security-automation-deep.md`, `security-mastery-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md` |
| T1003.002 | `active-directory-deep.md`, `c2-postexploit-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `password-credential-deep.md`, `security-automation-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md` |
| T1003.003 | `active-directory-deep.md`, `c2-postexploit-deep.md`, `mitre-attack-deep.md`, `password-credential-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1003.004 | `active-directory-deep.md`, `c2-postexploit-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md` |
| T1003.005 | `active-directory-deep.md`, `c2-postexploit-deep.md`, `mitre-attack-deep.md` |
| T1003.006 | `active-directory-deep.md`, `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `password-credential-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1003.007 | `mitre-attack-deep.md` |
| T1003.008 | `attack-chains-synthesis.md`, `mitre-attack-deep.md`, `threat-hunting-deep.md` |
| T1005 | `attack-chains-synthesis.md`, `exfil-tunneling-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `pentest-cheatsheet-ultimate.md`, `windows-ad-deep.md` |
| T1007 | `mitre-attack-deep.md` |
| T1008 | `mitre-attack-deep.md` |
| T1010 | `malware-re-evasion-deep.md`, `mitre-attack-deep.md` |
| T1011 | `exfil-tunneling-deep.md`, `mitre-attack-deep.md` |
| T1012 | `mitre-attack-deep.md` |
| T1014 | `evasion-detection-catalog.md`, `mitre-attack-deep.md` |
| T1016 | `attack-chains-synthesis.md`, `mitre-attack-deep.md`, `siem-soc-deep.md` |
| T1018 | `mitre-attack-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md` |
| T1020 | `exfil-tunneling-deep.md`, `mitre-attack-deep.md` |
| T1021 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1021.001 | `defensive-synthesis.md`, `dfir-hunting-deep.md`, `mitre-attack-deep.md`, `security-automation-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `threat-hunting-deep.md` |
| T1021.002 | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `threat-hunting-deep.md` |
| T1021.003 | `mitre-attack-deep.md`, `sigma-detection-deep.md` |
| T1021.004 | `attack-chains-synthesis.md`, `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1021.005 | `mitre-attack-deep.md` |
| T1021.006 | `defensive-synthesis.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md` |
| T1021.007 | `mitre-attack-deep.md` |
| T1021.008 | `mitre-attack-deep.md` |
| T1025 | `mitre-attack-deep.md` |
| T1027 | `defensive-synthesis.md`, `evasion-detection-catalog.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1027.002 | `evasion-detection-catalog.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md` |
| T1027.003 | `evasion-detection-catalog.md`, `exfil-tunneling-deep.md` |
| T1027.006 | `evasion-detection-catalog.md` |
| T1027.007 | `evasion-detection-catalog.md` |
| T1027.010 | `evasion-detection-catalog.md`, `mitre-attack-deep.md` |
| T1027.011 | `evasion-detection-catalog.md` |
| T1027.013 | `mitre-attack-deep.md` |
| T1027.014 | `evasion-detection-catalog.md` |
| T1029 | `exfil-tunneling-deep.md`, `mitre-attack-deep.md` |
| T1030 | `attack-chains-synthesis.md`, `exfil-tunneling-deep.md`, `mitre-attack-deep.md` |
| T1033 | `attack-chains-synthesis.md`, `mitre-attack-deep.md` |
| T1036 | `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `threat-hunting-deep.md` |
| T1036.002 | `evasion-detection-catalog.md` |
| T1036.003 | `threat-hunting-deep.md` |
| T1036.004 | `security-scenarios.md` |
| T1036.005 | `defensive-synthesis.md`, `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md` |
| T1036.009 | `evasion-detection-catalog.md` |
| T1036.011 | `evasion-detection-catalog.md` |
| T1037 | `mitre-attack-deep.md` |
| T1037.001 | `windows-internals-deep.md` |
| T1039 | `exfil-tunneling-deep.md`, `mitre-attack-deep.md`, `windows-ad-deep.md` |
| T1040 | `blockchain-web3-deep.md`, `identity-auth-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1041 | `container-k8s-deep.md`, `exfil-tunneling-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `siem-soc-deep.md`, `windows-ad-deep.md` |
| T1046 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `recon-osint-deep.md`, `threat-intel-deep.md` |
| T1047 | `defensive-synthesis.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-automation-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1048 | `aws-security-ultimate.md`, `exfil-tunneling-deep.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-scenarios.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1048.001 | `attack-chains-synthesis.md`, `insider-threat-dlp-deep.md`, `threat-hunting-deep.md` |
| T1048.002 | `attack-chains-synthesis.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md` |
| T1048.003 | `attack-chains-synthesis.md`, `dns-email-infra-deep.md`, `exfil-tunneling-deep.md`, `insider-threat-dlp-deep.md`, `threat-hunting-deep.md` |
| T1049 | `mitre-attack-deep.md` |
| T1052 | `exfil-tunneling-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md` |
| T1052.001 | `insider-threat-dlp-deep.md` |
| T1053 | `mitre-attack-deep.md`, `pentest-cheatsheet-ultimate.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1053.002 | `mitre-attack-deep.md`, `windows-internals-deep.md` |
| T1053.003 | `mitre-attack-deep.md`, `purple-team-deep.md`, `security-scenarios.md`, `threat-hunting-deep.md` |
| T1053.005 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `mitre-attack-deep.md`, `purple-team-deep.md`, `security-automation-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1053.006 | `mitre-attack-deep.md` |
| T1053.007 | `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1055 | `c2-postexploit-deep.md`, `defensive-synthesis.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `purple-team-deep.md`, `supplementary-security-knowledge.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `websec-deep.md`, `windows-ad-deep.md` |
| T1055.001 | `attack-chains-synthesis.md`, `evasion-detection-catalog.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `purple-team-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1055.002 | `mitre-attack-deep.md` |
| T1055.003 | `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `purple-team-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1055.004 | `evasion-detection-catalog.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `windows-ad-deep.md` |
| T1055.005 | `mitre-attack-deep.md` |
| T1055.008 | `evasion-detection-catalog.md`, `mitre-attack-deep.md` |
| T1055.009 | `mitre-attack-deep.md` |
| T1055.011 | `mitre-attack-deep.md` |
| T1055.012 | `evasion-detection-catalog.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1055.013 | `evasion-detection-catalog.md`, `mitre-attack-deep.md` |
| T1055.014 | `mitre-attack-deep.md` |
| T1055.015 | `mitre-attack-deep.md` |
| T1056 | `mitre-attack-deep.md` |
| T1056.001 | `malware-re-evasion-deep.md`, `mitre-attack-deep.md` |
| T1056.003 | `network-protocol-deep.md` |
| T1057 | `mitre-attack-deep.md` |
| T1059 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md`, `blockchain-web3-deep.md`, `c2-postexploit-deep.md`, `cloud-attacks-deep.md`, `container-k8s-deep.md`, `defensive-deep.md`, `dfir-hunting-deep.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-automation-deep.md`, `shells-arsenal-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `websec-deep.md`, `windows-ad-deep.md` |
| T1059.001 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `purple-team-deep.md`, `shells-arsenal-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1059.002 | `mitre-attack-deep.md` |
| T1059.003 | `defensive-synthesis.md`, `mitre-attack-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1059.004 | `attack-chains-synthesis.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `shells-arsenal-deep.md`, `threat-hunting-deep.md` |
| T1059.005 | `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `windows-internals-deep.md` |
| T1059.006 | `malware-analysis-deep.md`, `mitre-attack-deep.md` |
| T1059.007 | `mitre-attack-deep.md`, `websec-deep.md` |
| T1059.008 | `mitre-attack-deep.md` |
| T1059.009 | `mitre-attack-deep.md` |
| T1059.010 | `mitre-attack-deep.md` |
| T1059.011 | `mitre-attack-deep.md` |
| T1059.012 | `mitre-attack-deep.md` |
| T1059.013 | `mitre-attack-deep.md` |
| T1068 | `defensive-synthesis.md`, `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-scenarios.md`, `windows-ad-deep.md` |
| T1069 | `c2-postexploit-deep.md`, `defensive-synthesis.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1070 | `attack-chains-synthesis.md`, `cloud-attacks-deep.md`, `dfir-hunting-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `pentest-cheatsheet-ultimate.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md` |
| T1070.001 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md` |
| T1070.002 | `evasion-detection-catalog.md` |
| T1070.003 | `evasion-detection-catalog.md` |
| T1070.004 | `evasion-detection-catalog.md`, `threat-hunting-deep.md` |
| T1070.006 | `attack-chains-synthesis.md`, `evasion-detection-catalog.md`, `threat-hunting-deep.md` |
| T1070.008 | `insider-threat-dlp-deep.md` |
| T1071 | `cloud-attacks-deep.md`, `evasion-detection-catalog.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-scenarios.md`, `shells-arsenal-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `websec-deep.md` |
| T1071.001 | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `email-phishing-se-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `shells-arsenal-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md` |
| T1071.003 | `mitre-attack-deep.md` |
| T1071.004 | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `dns-email-infra-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `network-protocol-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md` |
| T1072 | `mitre-attack-deep.md` |
| T1074 | `exfil-tunneling-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md` |
| T1074.001 | `attack-chains-synthesis.md`, `exfil-tunneling-deep.md` |
| T1074.002 | `exfil-tunneling-deep.md` |
| T1078 | `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `blockchain-web3-deep.md`, `defensive-synthesis.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-scenarios.md`, `threat-hunting-deep.md`, `websec-deep.md`, `windows-internals-deep.md` |
| T1078.001 | `attack-chains-synthesis.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `pentest-reporting-deep.md`, `threat-hunting-deep.md` |
| T1078.002 | `mitre-attack-deep.md`, `threat-hunting-deep.md` |
| T1078.003 | `mitre-attack-deep.md` |
| T1078.004 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `threat-hunting-deep.md` |
| T1080 | `mitre-attack-deep.md` |
| T1082 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `threat-hunting-deep.md`, `websec-deep.md` |
| T1083 | `attack-chains-synthesis.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-scenarios.md`, `websec-deep.md` |
| T1087 | `c2-postexploit-deep.md`, `defensive-synthesis.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1087.002 | `attack-chains-synthesis.md`, `identity-auth-deep.md`, `mitre-attack-deep.md`, `security-mastery-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md` |
| T1087.004 | `attack-chains-synthesis.md`, `gcp-security-deep.md` |
| T1090 | `c2-postexploit-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `websec-deep.md` |
| T1090.001 | `attack-chains-synthesis.md` |
| T1090.004 | `attack-chains-synthesis.md` |
| T1091 | `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `social-engineering-deep.md` |
| T1092 | `mitre-attack-deep.md` |
| T1095 | `malware-re-evasion-deep.md`, `mitre-attack-deep.md` |
| T1098 | `active-directory-deep.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `container-k8s-deep.md`, `gcp-security-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md`, `windows-internals-deep.md` |
| T1098.001 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `gcp-security-deep.md`, `insider-threat-dlp-deep.md` |
| T1098.003 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `email-phishing-se-deep.md`, `insider-threat-dlp-deep.md` |
| T1098.004 | `gcp-security-deep.md` |
| T1098.005 | `attack-chains-synthesis.md` |
| T1102 | `mitre-attack-deep.md` |
| T1104 | `mitre-attack-deep.md` |
| T1105 | `defensive-synthesis.md`, `dfir-hunting-deep.md`, `evasion-techniques-deep.md`, `incident-playbooks-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `websec-deep.md`, `windows-internals-deep.md` |
| T1106 | `defensive-synthesis.md`, `evasion-detection-catalog.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md` |
| T1110 | `defensive-synthesis.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md` |
| T1110.001 | `incident-playbooks-deep.md`, `password-credential-deep.md`, `siem-soc-deep.md` |
| T1110.002 | `password-credential-deep.md` |
| T1110.003 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `identity-auth-deep.md`, `incident-playbooks-deep.md`, `password-credential-deep.md`, `threat-hunting-deep.md` |
| T1110.004 | `incident-playbooks-deep.md`, `password-credential-deep.md` |
| T1111 | `attack-chains-synthesis.md`, `email-phishing-se-deep.md`, `identity-auth-deep.md`, `mitre-attack-deep.md` |
| T1112 | `mitre-attack-deep.md` |
| T1113 | `insider-threat-dlp-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md` |
| T1114 | `azure-security-ultimate.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md` |
| T1114.002 | `attack-chains-synthesis.md`, `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1114.003 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `insider-threat-dlp-deep.md`, `threat-hunting-deep.md` |
| T1115 | `malware-re-evasion-deep.md`, `mitre-attack-deep.md` |
| T1119 | `exfil-tunneling-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md` |
| T1120 | `mitre-attack-deep.md` |
| T1123 | `mitre-attack-deep.md` |
| T1124 | `mitre-attack-deep.md` |
| T1125 | `mitre-attack-deep.md` |
| T1127.001 | `windows-internals-deep.md` |
| T1129 | `mitre-attack-deep.md` |
| T1132 | `mitre-attack-deep.md` |
| T1133 | `defensive-synthesis.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md` |
| T1134 | `active-directory-deep.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-scenarios.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1134.001 | `evasion-detection-catalog.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1134.002 | `windows-internals-deep.md` |
| T1134.004 | `evasion-detection-catalog.md`, `siem-soc-deep.md` |
| T1134.005 | `active-directory-deep.md`, `evasion-detection-catalog.md`, `windows-ad-deep.md` |
| T1135 | `c2-postexploit-deep.md`, `dfir-hunting-deep.md`, `mitre-attack-deep.md` |
| T1136 | `aws-security-ultimate.md`, `cloud-attacks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md` |
| T1136.001 | `defensive-synthesis.md` |
| T1136.003 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md` |
| T1137 | `defensive-synthesis.md`, `mitre-attack-deep.md` |
| T1137.001 | `mitre-attack-deep.md`, `windows-internals-deep.md` |
| T1140 | `mitre-attack-deep.md`, `windows-internals-deep.md` |
| T1176 | `mitre-attack-deep.md` |
| T1185 | `attack-chains-synthesis.md`, `email-phishing-se-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-scenarios.md`, `websec-deep.md` |
| T1187 | `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `network-attacks-deep.md` |
| T1189 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `mitre-attack-deep.md`, `offensive-deep.md`, `social-engineering-deep.md` |
| T1190 | `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md`, `blockchain-web3-deep.md`, `c2-postexploit-deep.md`, `cloud-attacks-deep.md`, `cloud-infra-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `pentest-reporting-deep.md`, `security-scenarios.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `websec-deep.md`, `windows-ad-deep.md` |
| T1195 | `blockchain-web3-deep.md`, `defensive-synthesis.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md` |
| T1195.001 | `container-k8s-deep.md`, `incident-playbooks-deep.md` |
| T1195.002 | `attack-chains-synthesis.md`, `container-k8s-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1197 | `defensive-synthesis.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1199 | `azure-security-ultimate.md`, `defensive-synthesis.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1200 | `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `supplementary-security-knowledge.md`, `social-engineering-deep.md` |
| T1201 | `mitre-attack-deep.md` |
| T1202 | `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `windows-internals-deep.md` |
| T1203 | `mitre-attack-deep.md` |
| T1204 | `aws-security-ultimate.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `social-engineering-deep.md`, `windows-ad-deep.md` |
| T1204.001 | `social-engineering-deep.md` |
| T1204.002 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `email-phishing-se-deep.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `security-automation-deep.md`, `social-engineering-deep.md`, `threat-hunting-deep.md` |
| T1204.003 | `social-engineering-deep.md` |
| T1204.004 | `social-engineering-deep.md` |
| T1204.005 | `social-engineering-deep.md` |
| T1205 | `cloud-attacks-deep.md`, `mitre-attack-deep.md` |
| T1205.001 | `evasion-detection-catalog.md` |
| T1207 | `active-directory-deep.md`, `windows-ad-deep.md` |
| T1210 | `binary-exploitation-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md` |
| T1212 | `mitre-attack-deep.md` |
| T1213 | `attack-chains-synthesis.md`, `exfil-tunneling-deep.md`, `gcp-security-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md` |
| T1213.002 | `attack-chains-synthesis.md` |
| T1216.001 | `evasion-detection-catalog.md` |
| T1216.002 | `evasion-detection-catalog.md` |
| T1217 | `mitre-attack-deep.md` |
| T1218 | `mitre-attack-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1218.001 | `evasion-detection-catalog.md` |
| T1218.002 | `windows-internals-deep.md` |
| T1218.003 | `evasion-detection-catalog.md`, `windows-internals-deep.md` |
| T1218.004 | `evasion-detection-catalog.md`, `windows-internals-deep.md` |
| T1218.005 | `defensive-synthesis.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1218.007 | `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `windows-internals-deep.md` |
| T1218.009 | `evasion-detection-catalog.md`, `windows-internals-deep.md` |
| T1218.010 | `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1218.011 | `defensive-synthesis.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `mitre-attack-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1218.013 | `evasion-detection-catalog.md`, `windows-internals-deep.md` |
| T1219 | `mitre-attack-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md` |
| T1221 | `mitre-attack-deep.md` |
| T1222 | `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1398 | `mobile-security-deep.md` |
| T1404 | `mobile-security-deep.md` |
| T1406 | `mobile-security-deep.md` |
| T1407 | `mobile-security-deep.md` |
| T1409 | `mobile-security-deep.md` |
| T1414 | `mobile-security-deep.md` |
| T1417 | `mobile-security-deep.md` |
| T1418 | `mobile-security-deep.md` |
| T1429 | `mobile-security-deep.md` |
| T1430 | `mobile-security-deep.md` |
| T1437 | `mobile-security-deep.md` |
| T1438 | `mobile-security-deep.md` |
| T1444 | `mobile-security-deep.md` |
| T1474 | `mobile-security-deep.md` |
| T1476 | `mobile-security-deep.md` |
| T1482 | `mitre-attack-deep.md`, `windows-ad-deep.md` |
| T1484 | `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `mitre-attack-deep.md`, `windows-internals-deep.md` |
| T1484.001 | `evasion-detection-catalog.md` |
| T1484.002 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `evasion-detection-catalog.md`, `insider-threat-dlp-deep.md` |
| T1485 | `aws-security-ultimate.md`, `gcp-security-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md` |
| T1486 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `dfir-hunting-deep.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1489 | `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `windows-ad-deep.md` |
| T1490 | `attack-chains-synthesis.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `supplementary-security-knowledge.md`, `security-scenarios.md`, `threat-hunting-deep.md`, `threat-intel-deep.md` |
| T1491 | `mitre-attack-deep.md` |
| T1491.001 | `attack-chains-synthesis.md` |
| T1495 | `mitre-attack-deep.md` |
| T1496 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `dns-email-infra-deep.md`, `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1497 | `evasion-detection-catalog.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md` |
| T1497.003 | `malware-re-evasion-deep.md` |
| T1498 | `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1498.001 | `incident-playbooks-deep.md` |
| T1498.002 | `incident-playbooks-deep.md` |
| T1499 | `blockchain-web3-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `websec-deep.md` |
| T1499.001 | `incident-playbooks-deep.md` |
| T1499.002 | `incident-playbooks-deep.md` |
| T1499.003 | `incident-playbooks-deep.md` |
| T1499.004 | `incident-playbooks-deep.md` |
| T1505 | `mitre-attack-deep.md`, `threat-hunting-deep.md` |
| T1505.001 | `attack-chains-synthesis.md` |
| T1505.003 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `shells-arsenal-deep.md`, `threat-hunting-deep.md` |
| T1518 | `mitre-attack-deep.md` |
| T1525 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `mitre-attack-deep.md` |
| T1526 | `gcp-security-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md` |
| T1528 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `container-k8s-deep.md`, `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1529 | `mitre-attack-deep.md` |
| T1530 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `blockchain-web3-deep.md`, `cloud-attacks-deep.md`, `exfil-tunneling-deep.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1531 | `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1534 | `attack-chains-synthesis.md`, `email-phishing-se-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1537 | `aws-security-ultimate.md`, `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `exfil-tunneling-deep.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md` |
| T1538 | `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1539 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `email-phishing-se-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md` |
| T1542 | `attack-chains-synthesis.md`, `mitre-attack-deep.md` |
| T1542.001 | `evasion-detection-catalog.md` |
| T1542.003 | `evasion-detection-catalog.md` |
| T1542.004 | `attack-chains-synthesis.md` |
| T1543 | `mitre-attack-deep.md`, `security-scenarios.md`, `threat-hunting-deep.md` |
| T1543.003 | `defensive-synthesis.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1546 | `aws-security-ultimate.md`, `cloud-attacks-deep.md`, `gcp-security-deep.md`, `mitre-attack-deep.md`, `windows-internals-deep.md` |
| T1546.002 | `windows-internals-deep.md` |
| T1546.003 | `defensive-synthesis.md`, `mitre-attack-deep.md`, `security-automation-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1546.007 | `attack-chains-synthesis.md`, `windows-internals-deep.md` |
| T1546.008 | `windows-internals-deep.md` |
| T1546.009 | `windows-internals-deep.md` |
| T1546.010 | `windows-internals-deep.md` |
| T1546.012 | `windows-internals-deep.md` |
| T1546.013 | `windows-internals-deep.md` |
| T1546.015 | `security-metrics-deep.md`, `windows-internals-deep.md` |
| T1547 | `dfir-hunting-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `threat-hunting-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1547.001 | `defensive-synthesis.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-internals-deep.md` |
| T1547.002 | `windows-internals-deep.md` |
| T1547.004 | `windows-internals-deep.md` |
| T1547.009 | `threat-hunting-deep.md` |
| T1548 | `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `gcp-security-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `websec-deep.md` |
| T1548.001 | `evasion-detection-catalog.md`, `network-protocol-deep.md` |
| T1548.002 | `defensive-synthesis.md`, `evasion-detection-catalog.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1548.003 | `evasion-detection-catalog.md` |
| T1548.005 | `insider-threat-dlp-deep.md` |
| T1550 | `mitre-attack-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `windows-ad-deep.md` |
| T1550.001 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `email-phishing-se-deep.md`, `gcp-security-deep.md`, `identity-auth-deep.md`, `threat-hunting-deep.md` |
| T1550.002 | `active-directory-deep.md`, `attack-chains-synthesis.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `windows-ad-deep.md` |
| T1550.003 | `active-directory-deep.md`, `network-attacks-deep.md`, `windows-ad-deep.md` |
| T1550.004 | `attack-chains-synthesis.md` |
| T1552 | `aws-security-ultimate.md`, `azure-security-ultimate.md`, `blockchain-web3-deep.md`, `identity-auth-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1552.001 | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `mobile-security-deep.md`, `password-credential-deep.md`, `security-scenarios.md`, `threat-hunting-deep.md` |
| T1552.004 | `attack-chains-synthesis.md`, `c2-postexploit-deep.md` |
| T1552.005 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `bugbounty-methodology-deep.md`, `cloud-attacks-deep.md`, `gcp-security-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `security-scenarios.md` |
| T1552.007 | `attack-chains-synthesis.md`, `container-k8s-deep.md` |
| T1553 | `mitre-attack-deep.md`, `network-protocol-deep.md` |
| T1553.002 | `evasion-detection-catalog.md` |
| T1553.004 | `evasion-detection-catalog.md` |
| T1553.005 | `evasion-detection-catalog.md` |
| T1554 | `container-k8s-deep.md`, `mitre-attack-deep.md` |
| T1555 | `aws-security-ultimate.md`, `defensive-synthesis.md`, `identity-auth-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `threat-intel-deep.md` |
| T1555.003 | `mitre-attack-deep.md` |
| T1555.004 | `mitre-attack-deep.md` |
| T1556 | `azure-security-ultimate.md`, `defensive-synthesis.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md` |
| T1556.001 | `active-directory-deep.md`, `evasion-detection-catalog.md` |
| T1556.002 | `evasion-detection-catalog.md` |
| T1556.003 | `evasion-detection-catalog.md` |
| T1556.006 | `insider-threat-dlp-deep.md`, `network-attacks-deep.md` |
| T1556.009 | `insider-threat-dlp-deep.md` |
| T1557 | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `blockchain-web3-deep.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `evasion-detection-catalog.md`, `identity-auth-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `websec-deep.md` |
| T1557.001 | `active-directory-deep.md`, `attack-chains-synthesis.md`, `identity-auth-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `password-credential-deep.md`, `pentest-reporting-deep.md`, `siem-soc-deep.md`, `windows-ad-deep.md` |
| T1557.002 | `network-attacks-deep.md`, `network-protocol-deep.md` |
| T1557.003 | `network-attacks-deep.md` |
| T1558 | `mitre-attack-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1558.001 | `active-directory-deep.md`, `attack-chains-synthesis.md`, `network-protocol-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1558.002 | `active-directory-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1558.003 | `active-directory-deep.md`, `attack-chains-synthesis.md`, `defensive-synthesis.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `password-credential-deep.md`, `pentest-reporting-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1558.004 | `active-directory-deep.md`, `attack-chains-synthesis.md`, `network-protocol-deep.md`, `password-credential-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1559 | `mitre-attack-deep.md` |
| T1559.002 | `defensive-synthesis.md` |
| T1560 | `exfil-tunneling-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md` |
| T1560.001 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `threat-hunting-deep.md` |
| T1561 | `mitre-attack-deep.md` |
| T1561.002 | `mitre-attack-deep.md` |
| T1562 | `aws-security-ultimate.md`, `insider-threat-dlp-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1562.001 | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| T1562.002 | `defensive-synthesis.md`, `evasion-detection-catalog.md`, `mitre-attack-deep.md` |
| T1562.004 | `evasion-detection-catalog.md` |
| T1562.006 | `evasion-detection-catalog.md`, `siem-soc-deep.md`, `windows-ad-deep.md` |
| T1562.007 | `insider-threat-dlp-deep.md` |
| T1562.008 | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `cloud-attacks-deep.md`, `evasion-detection-catalog.md`, `gcp-security-deep.md`, `insider-threat-dlp-deep.md`, `security-scenarios.md` |
| T1562.009 | `evasion-detection-catalog.md` |
| T1562.010 | `evasion-detection-catalog.md` |
| T1562.012 | `evasion-detection-catalog.md` |
| T1563 | `mitre-attack-deep.md` |
| T1564 | `mitre-attack-deep.md` |
| T1564.001 | `evasion-detection-catalog.md` |
| T1564.004 | `evasion-detection-catalog.md`, `purple-team-deep.md`, `windows-internals-deep.md` |
| T1564.007 | `evasion-detection-catalog.md` |
| T1564.008 | `email-phishing-se-deep.md`, `insider-threat-dlp-deep.md` |
| T1564.010 | `evasion-detection-catalog.md` |
| T1564.012 | `evasion-detection-catalog.md` |
| T1565 | `blockchain-web3-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `security-scenarios.md` |
| T1566 | `azure-security-ultimate.md`, `blockchain-web3-deep.md`, `email-phishing-se-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `siem-soc-deep.md`, `social-engineering-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1566.001 | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `purple-team-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `social-engineering-deep.md`, `threat-hunting-deep.md` |
| T1566.002 | `attack-chains-synthesis.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `social-engineering-deep.md`, `threat-hunting-deep.md` |
| T1566.003 | `email-phishing-se-deep.md`, `mitre-attack-deep.md`, `social-engineering-deep.md` |
| T1566.004 | `email-phishing-se-deep.md`, `mitre-attack-deep.md`, `social-engineering-deep.md` |
| T1567 | `defensive-synthesis.md`, `exfil-tunneling-deep.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `threat-intel-deep.md` |
| T1567.001 | `exfil-tunneling-deep.md`, `insider-threat-dlp-deep.md` |
| T1567.002 | `attack-chains-synthesis.md`, `exfil-tunneling-deep.md`, `insider-threat-dlp-deep.md`, `threat-hunting-deep.md` |
| T1567.003 | `exfil-tunneling-deep.md`, `insider-threat-dlp-deep.md` |
| T1567.004 | `exfil-tunneling-deep.md`, `insider-threat-dlp-deep.md` |
| T1568 | `mitre-attack-deep.md` |
| T1568.001 | `dns-email-infra-deep.md` |
| T1568.002 | `dns-email-infra-deep.md` |
| T1569 | `aws-security-ultimate.md`, `mitre-attack-deep.md` |
| T1569.002 | `security-scenarios.md`, `windows-ad-deep.md` |
| T1570 | `defensive-synthesis.md`, `mitre-attack-deep.md`, `security-automation-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| T1571 | `mitre-attack-deep.md`, `network-protocol-deep.md`, `shells-arsenal-deep.md`, `threat-hunting-deep.md` |
| T1572 | `c2-postexploit-deep.md`, `dns-email-infra-deep.md`, `mitre-attack-deep.md`, `threat-intel-deep.md` |
| T1573 | `c2-postexploit-deep.md`, `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `shells-arsenal-deep.md` |
| T1573.002 | `shells-arsenal-deep.md`, `siem-soc-deep.md` |
| T1574 | `mitre-attack-deep.md`, `network-protocol-deep.md`, `windows-internals-deep.md` |
| T1574.001 | `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `sigma-detection-deep.md`, `windows-internals-deep.md` |
| T1574.002 | `evasion-detection-catalog.md`, `threat-hunting-deep.md`, `threat-intel-deep.md` |
| T1574.006 | `evasion-detection-catalog.md` |
| T1574.009 | `windows-internals-deep.md` |
| T1574.012 | `evasion-detection-catalog.md` |
| T1574.013 | `evasion-detection-catalog.md` |
| T1575 | `mobile-security-deep.md` |
| T1578 | `evasion-detection-catalog.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `threat-hunting-deep.md` |
| T1578.001 | `evasion-detection-catalog.md` |
| T1578.002 | `evasion-detection-catalog.md`, `gcp-security-deep.md` |
| T1578.003 | `evasion-detection-catalog.md` |
| T1578.004 | `evasion-detection-catalog.md` |
| T1580 | `aws-security-ultimate.md`, `azure-security-ultimate.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md` |
| T1583 | `mitre-attack-deep.md` |
| T1583.001 | `attack-chains-synthesis.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md` |
| T1583.003 | `attack-chains-synthesis.md` |
| T1584 | `mitre-attack-deep.md` |
| T1584.001 | `attack-chains-synthesis.md`, `bugbounty-methodology-deep.md` |
| T1584.002 | `dns-email-infra-deep.md` |
| T1585 | `mitre-attack-deep.md` |
| T1585.002 | `email-phishing-se-deep.md` |
| T1586 | `mitre-attack-deep.md` |
| T1586.002 | `attack-chains-synthesis.md` |
| T1587 | `mitre-attack-deep.md` |
| T1588 | `mitre-attack-deep.md` |
| T1589 | `azure-security-ultimate.md`, `email-phishing-se-deep.md`, `mitre-attack-deep.md`, `recon-osint-deep.md`, `security-scenarios.md` |
| T1589.001 | `attack-chains-synthesis.md` |
| T1589.002 | `attack-chains-synthesis.md` |
| T1590 | `azure-security-ultimate.md`, `mitre-attack-deep.md`, `security-scenarios.md`, `sigma-detection-deep.md` |
| T1590.002 | `dns-email-infra-deep.md` |
| T1591 | `attack-chains-synthesis.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1591.002 | `attack-chains-synthesis.md` |
| T1592 | `mitre-attack-deep.md`, `pentest-cheatsheet-ultimate.md` |
| T1593 | `attack-chains-synthesis.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1593.003 | `recon-osint-deep.md` |
| T1595 | `mitre-attack-deep.md`, `pentest-cheatsheet-ultimate.md` |
| T1595.001 | `attack-chains-synthesis.md` |
| T1595.002 | `attack-chains-synthesis.md`, `recon-osint-deep.md` |
| T1595.003 | `recon-osint-deep.md` |
| T1596 | `mitre-attack-deep.md`, `security-scenarios.md` |
| T1596.001 | `recon-osint-deep.md` |
| T1596.002 | `recon-osint-deep.md` |
| T1597 | `mitre-attack-deep.md` |
| T1598 | `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `social-engineering-deep.md` |
| T1598.001 | `email-phishing-se-deep.md`, `social-engineering-deep.md` |
| T1598.002 | `email-phishing-se-deep.md`, `social-engineering-deep.md` |
| T1598.003 | `email-phishing-se-deep.md`, `mitre-attack-deep.md`, `social-engineering-deep.md` |
| T1598.004 | `email-phishing-se-deep.md`, `social-engineering-deep.md` |
| T1599 | `attack-chains-synthesis.md` |
| T1602 | `mitre-attack-deep.md` |
| T1606 | `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1608 | `mitre-attack-deep.md` |
| T1608.005 | `email-phishing-se-deep.md` |
| T1609 | `attack-chains-synthesis.md`, `container-k8s-deep.md`, `mitre-attack-deep.md` |
| T1610 | `attack-chains-synthesis.md`, `container-k8s-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1611 | `attack-chains-synthesis.md`, `container-k8s-deep.md`, `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1613 | `attack-chains-synthesis.md`, `gcp-security-deep.md`, `mitre-attack-deep.md`, `security-scenarios.md` |
| T1614 | `mitre-attack-deep.md` |
| T1615 | `mitre-attack-deep.md` |
| T1619 | `azure-security-ultimate.md`, `mitre-attack-deep.md` |
| T1620 | `evasion-detection-catalog.md`, `mitre-attack-deep.md` |
| T1621 | `email-phishing-se-deep.md`, `identity-auth-deep.md`, `mitre-attack-deep.md`, `threat-hunting-deep.md` |
| T1622 | `evasion-detection-catalog.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md` |
| T1648 | `gcp-security-deep.md`, `mitre-attack-deep.md` |
| T1649 | `active-directory-deep.md`, `attack-chains-synthesis.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `windows-ad-deep.md` |
| T1650 | `mitre-attack-deep.md` |
| T1651 | `mitre-attack-deep.md` |
| T1652 | `mitre-attack-deep.md` |
| T1653 | `mitre-attack-deep.md` |
| T1654 | `mitre-attack-deep.md` |
| T1657 | `attack-chains-synthesis.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md` |
| T1659 | `mitre-attack-deep.md` |
| T1665 | `mitre-attack-deep.md` |
| T1667 | `mitre-attack-deep.md` |
| T1668 | `mitre-attack-deep.md` |
| T1669 | `mitre-attack-deep.md` |
| T1671 | `mitre-attack-deep.md` |
| T1673 | `mitre-attack-deep.md` |
| T1674 | `mitre-attack-deep.md` |
| T1675 | `mitre-attack-deep.md` |
| T1677 | `mitre-attack-deep.md` |
| T1680 | `mitre-attack-deep.md` |
| T1681 | `mitre-attack-deep.md` |
| T2232 | `wireless-physical-iot-deep.md` |

---

## 3. Security Tool Index

**260 security tools** indexed across the training corpus.

### Reconnaissance & OSINT

| Tool | Document(s) |
|------|-------------|
| Nmap | `ai-defense-deep.md`, `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `cloud-infra-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `dns-email-infra-deep.md`, `exfil-tunneling-deep.md`, `gcp-security-deep.md`, `hardening-guides-ultimate.md`, `ics-scada-deep.md`, `linux-exploitation-deep.md`, `logging-monitoring-deep.md`, `malware-re-evasion-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `osint-tradecraft-deep.md`, `pentest-cheatsheet-ultimate.md`, `privacy-engineering-deep.md`, `recon-osint-deep.md`, `security-certifications-deep.md`, `security-scenarios.md`, `shells-arsenal-deep.md`, `wireless-physical-iot-deep.md` |
| Amass | `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `bugbounty-methodology-deep.md`, `ctf-methodology-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `dns-email-infra-deep.md`, `osint-tradecraft-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-scenarios.md`, `social-engineering-deep.md`, `websec-deep.md` |
| Subfinder | `attack-chains-synthesis.md`, `bugbounty-methodology-deep.md`, `ctf-methodology-deep.md`, `dns-email-infra-deep.md`, `osint-tradecraft-deep.md`, `pentest-cheatsheet-ultimate.md`, `privacy-osint-deep.md`, `recon-osint-deep.md`, `security-scenarios.md`, `social-engineering-deep.md`, `websec-deep.md` |
| httpx | `attack-chains-synthesis.md`, `bugbounty-methodology-deep.md`, `dns-email-infra-deep.md`, `pentest-cheatsheet-ultimate.md`, `recon-osint-deep.md`, `security-scenarios.md` |
| Shodan | `attack-chains-synthesis.md`, `bugbounty-methodology-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `ics-scada-deep.md`, `osint-tradecraft-deep.md`, `pentest-cheatsheet-ultimate.md`, `privacy-osint-deep.md`, `recon-osint-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `threat-intel-deep.md` |
| Censys | `attack-chains-synthesis.md`, `curated-resources-deep.md`, `dns-email-infra-deep.md`, `emerging-threats-deep.md`, `osint-tradecraft-deep.md`, `privacy-osint-deep.md`, `recon-osint-deep.md`, `redteam-infra-deep.md`, `threat-intel-deep.md` |
| theHarvester | `attack-chains-synthesis.md`, `ctf-methodology-deep.md`, `defensive-synthesis.md`, `osint-tradecraft-deep.md`, `pentest-cheatsheet-ultimate.md` |
| SpiderFoot | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `osint-tradecraft-deep.md`, `redteam-infra-deep.md`, `social-engineering-deep.md` |
| Maltego | `attack-chains-synthesis.md`, `ctf-methodology-deep.md`, `email-phishing-se-deep.md`, `osint-tradecraft-deep.md`, `social-engineering-deep.md` |
| Recon-ng | `redteam-infra-deep.md` |
| masscan | `gcp-security-deep.md`, `malware-re-evasion-deep.md`, `pentest-cheatsheet-ultimate.md`, `recon-osint-deep.md` |
| rustscan | `redteam-infra-deep.md`, `threat-intel-deep.md` |
| dnstwist | `attack-chains-synthesis.md`, `dns-email-infra-deep.md`, `incident-playbooks-deep.md`, `osint-tradecraft-deep.md` |
| dnsrecon | `ctf-methodology-deep.md`, `dns-email-infra-deep.md`, `pentest-cheatsheet-ultimate.md` |
| fierce | `dns-email-infra-deep.md`, `pentest-cheatsheet-ultimate.md` |
| massdns | `dns-email-infra-deep.md` |
| dnsx | `attack-chains-synthesis.md`, `bugbounty-methodology-deep.md`, `privacy-osint-deep.md`, `recon-osint-deep.md` |
| naabu | `bugbounty-methodology-deep.md`, `recon-osint-deep.md` |
| Katana | `recon-osint-deep.md`, `websec-deep.md` |
| crt.sh | `api-exploitation-deep.md`, `bugbounty-methodology-deep.md`, `crypto-pki-tls-deep.md`, `ctf-methodology-deep.md`, `curated-resources-deep.md`, `dns-email-infra-deep.md`, `osint-tradecraft-deep.md`, `pentest-cheatsheet-ultimate.md`, `privacy-osint-deep.md`, `recon-osint-deep.md`, `security-scenarios.md` |
| SecurityTrails | `curated-resources-deep.md`, `dns-email-infra-deep.md`, `osint-tradecraft-deep.md`, `recon-osint-deep.md` |
| ExifTool | `ctf-methodology-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `offensive-deep.md`, `osint-tradecraft-deep.md`, `recon-osint-deep.md` |

### Web Application Testing

| Tool | Document(s) |
|------|-------------|
| Burp Suite | `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `bugbounty-methodology-deep.md`, `cloud-attacks-deep.md`, `ctf-methodology-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `incident-playbooks-deep.md`, `mobile-security-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `websec-deep.md` |
| Burp | `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `bugbounty-methodology-deep.md`, `cloud-attacks-deep.md`, `ctf-methodology-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `incident-playbooks-deep.md`, `mobile-security-deep.md`, `offensive-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `websec-deep.md` |
| ZAP | `api-exploitation-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `security-mastery-deep.md`, `websec-deep.md` |
| OWASP ZAP | `api-exploitation-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `security-mastery-deep.md` |
| Nikto | `bugbounty-methodology-deep.md`, `devsecops-sdlc-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-re-evasion-deep.md`, `pentest-cheatsheet-ultimate.md`, `websec-deep.md` |
| sqlmap | `attack-chains-synthesis.md`, `bugbounty-methodology-deep.md`, `ctf-methodology-deep.md`, `defensive-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-re-evasion-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `recon-osint-deep.md`, `websec-deep.md` |
| ffuf | `api-exploitation-deep.md`, `bugbounty-methodology-deep.md`, `ctf-methodology-deep.md`, `malware-re-evasion-deep.md`, `pentest-cheatsheet-ultimate.md`, `recon-osint-deep.md`, `security-certifications-deep.md`, `vuln-research-deep.md`, `websec-deep.md` |
| gobuster | `ctf-methodology-deep.md`, `malware-re-evasion-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-certifications-deep.md`, `websec-deep.md` |
| dirsearch | `ctf-methodology-deep.md`, `pentest-cheatsheet-ultimate.md`, `websec-deep.md` |
| Nuclei | `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `bugbounty-methodology-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `dns-email-infra-deep.md`, `recon-osint-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `vuln-research-deep.md`, `websec-deep.md` |
| WPScan | `bugbounty-methodology-deep.md`, `incident-playbooks-deep.md`, `recon-osint-deep.md`, `websec-deep.md` |
| Wfuzz | `pentest-cheatsheet-ultimate.md`, `websec-deep.md` |
| feroxbuster | `bugbounty-methodology-deep.md`, `pentest-cheatsheet-ultimate.md`, `recon-osint-deep.md`, `security-certifications-deep.md`, `websec-deep.md` |

### Exploitation & Frameworks

| Tool | Document(s) |
|------|-------------|
| Metasploit | `ai-defense-deep.md`, `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `email-phishing-se-deep.md`, `evasion-detection-catalog.md`, `exfil-tunneling-deep.md`, `ics-scada-deep.md`, `malware-re-evasion-deep.md`, `network-forensics-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-certifications-deep.md`, `security-metrics-deep.md`, `shells-arsenal-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md`, `vuln-research-deep.md` |
| msfvenom | `c2-postexploit-deep.md`, `evasion-detection-catalog.md`, `pentest-cheatsheet-ultimate.md`, `security-certifications-deep.md`, `shells-arsenal-deep.md` |
| msfconsole | `c2-postexploit-deep.md`, `shells-arsenal-deep.md` |
| searchsploit | `linux-exploitation-deep.md`, `offensive-deep.md` |
| Hydra | `attack-chains-synthesis.md`, `curated-resources-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md` |
| BeEF | `shells-arsenal-deep.md`, `websec-deep.md`, `wireless-physical-iot-deep.md` |

### Active Directory & Windows

| Tool | Document(s) |
|------|-------------|
| BloodHound | `active-directory-deep.md`, `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `c2-postexploit-deep.md`, `cloud-attacks-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `identity-auth-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| SharpHound | `active-directory-deep.md`, `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `network-attacks-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md` |
| Mimikatz | `active-directory-deep.md`, `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `c2-postexploit-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `evasion-detection-catalog.md`, `forensics-artifacts-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `purple-team-deep.md`, `redteam-infra-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| Rubeus | `active-directory-deep.md`, `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `security-scenarios.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| Certify | `active-directory-deep.md`, `attack-chains-synthesis.md`, `redteam-infra-deep.md`, `secops-runbooks-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| Certipy | `active-directory-deep.md`, `attack-chains-synthesis.md`, `defensive-synthesis.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `windows-ad-deep.md` |
| PowerView | `active-directory-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `windows-ad-deep.md` |
| Impacket | `active-directory-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-scenarios.md`, `sigma-detection-deep.md`, `windows-ad-deep.md` |
| CrackMapExec | `curated-resources-deep.md`, `exfil-tunneling-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `windows-ad-deep.md` |
| NetExec | `active-directory-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `redteam-infra-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md` |
| Responder | `active-directory-deep.md`, `attack-chains-synthesis.md`, `curated-resources-deep.md`, `identity-auth-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `network-forensics-deep.md`, `offensive-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `windows-ad-deep.md` |
| ntlmrelayx | `active-directory-deep.md`, `attack-chains-synthesis.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `windows-ad-deep.md` |
| secretsdump | `active-directory-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `windows-ad-deep.md` |
| psexec | `active-directory-deep.md`, `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md` |
| wmiexec | `active-directory-deep.md`, `logging-monitoring-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md` |
| smbexec | `active-directory-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md` |
| dcomexec | `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `sigma-detection-deep.md` |
| atexec | `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md` |
| PetitPotam | `active-directory-deep.md`, `evasion-detection-catalog.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `windows-ad-deep.md` |
| Coercer | `network-attacks-deep.md` |
| KrbRelayUp | `redteam-infra-deep.md` |
| enum4linux | `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-certifications-deep.md` |
| evil-winrm | `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `sigma-detection-deep.md` |
| AADInternals | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `identity-auth-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md` |
| PowerSploit | `mitre-attack-deep.md`, `network-protocol-deep.md`, `windows-ad-deep.md` |
| Seatbelt | `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |

### C2 & Post-Exploitation

| Tool | Document(s) |
|------|-------------|
| Cobalt Strike | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `emerging-threats-deep.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `network-forensics-deep.md`, `purple-team-deep.md`, `redteam-infra-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md` |
| Sliver | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `evasion-techniques-deep.md`, `network-forensics-deep.md`, `redteam-infra-deep.md`, `threat-hunting-deep.md` |
| Havoc | `evasion-detection-catalog.md`, `redteam-infra-deep.md` |
| Mythic | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-synthesis.md`, `evasion-techniques-deep.md`, `network-forensics-deep.md`, `redteam-infra-deep.md` |
| Empire | `evasion-detection-catalog.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `network-forensics-deep.md`, `redteam-infra-deep.md`, `windows-ad-deep.md` |
| Brute Ratel | `redteam-infra-deep.md`, `threat-intel-deep.md` |
| PoshC2 | `network-forensics-deep.md` |
| Covenant | `redteam-infra-deep.md` |
| chisel | `attack-chains-synthesis.md`, `exfil-tunneling-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-certifications-deep.md` |
| ligolo | `attack-chains-synthesis.md`, `exfil-tunneling-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-certifications-deep.md` |
| proxychains | `api-exploitation-deep.md`, `exfil-tunneling-deep.md`, `network-attacks-deep.md`, `pentest-cheatsheet-ultimate.md` |
| socat | `defensive-deep.md`, `linux-exploitation-deep.md`, `malware-re-evasion-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `shells-arsenal-deep.md` |
| netcat | `linux-exploitation-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `shells-arsenal-deep.md` |

### Credential Attacks

| Tool | Document(s) |
|------|-------------|
| Hashcat | `active-directory-deep.md`, `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `ctf-methodology-deep.md`, `curated-resources-deep.md`, `dns-email-infra-deep.md`, `encoding-manipulation-deep.md`, `identity-auth-deep.md`, `malware-re-evasion-deep.md`, `network-attacks-deep.md`, `network-forensics-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `websec-deep.md`, `wireless-physical-iot-deep.md` |
| John the Ripper | `api-exploitation-deep.md`, `ctf-methodology-deep.md`, `encoding-manipulation-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md` |
| Aircrack-ng | `curated-resources-deep.md`, `password-credential-deep.md`, `security-certifications-deep.md`, `wireless-physical-iot-deep.md` |

### Social Engineering & Phishing

| Tool | Document(s) |
|------|-------------|
| Gophish | `attack-chains-synthesis.md`, `curated-resources-deep.md`, `email-phishing-se-deep.md`, `redteam-infra-deep.md`, `security-scenarios.md`, `social-engineering-deep.md` |
| Evilginx | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `email-phishing-se-deep.md`, `redteam-infra-deep.md` |
| Modlishka | `azure-security-ultimate.md`, `email-phishing-se-deep.md`, `redteam-infra-deep.md`, `social-engineering-deep.md` |

### Privilege Escalation

| Tool | Document(s) |
|------|-------------|
| LinPEAS | `attack-chains-synthesis.md`, `defensive-synthesis.md`, `linux-exploitation-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md` |
| WinPEAS | `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-certifications-deep.md`, `windows-internals-deep.md` |
| pspy | `defensive-synthesis.md`, `linux-exploitation-deep.md`, `pentest-cheatsheet-ultimate.md` |
| GTFOBins | `evasion-detection-catalog.md`, `linux-exploitation-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `security-certifications-deep.md` |
| LOLBAS | `evasion-detection-catalog.md`, `logging-monitoring-deep.md`, `network-protocol-deep.md`, `security-certifications-deep.md`, `sigma-detection-deep.md`, `windows-internals-deep.md` |

### Cloud Security

| Tool | Document(s) |
|------|-------------|
| Prowler | `aws-security-ultimate.md`, `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `cloud-infra-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `secure-infrastructure-deep.md`, `security-leadership-deep.md` |
| ScoutSuite | `aws-security-ultimate.md`, `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `cloud-infra-deep.md`, `defensive-synthesis.md`, `gcp-security-deep.md`, `incident-playbooks-deep.md`, `secure-infrastructure-deep.md`, `security-leadership-deep.md` |
| Pacu | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `cloud-attacks-deep.md` |
| CloudGoat | `cloud-infra-deep.md` |
| AzureHound | `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `identity-auth-deep.md`, `redteam-infra-deep.md`, `threat-hunting-deep.md` |
| ROADtools | `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `identity-auth-deep.md` |
| MicroBurst | `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `identity-auth-deep.md` |
| GraphRunner | `attack-chains-synthesis.md`, `azure-security-ultimate.md` |
| TokenTactics | `azure-security-ultimate.md` |

### Container & Kubernetes

| Tool | Document(s) |
|------|-------------|
| Docker | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `c2-postexploit-deep.md`, `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `container-k8s-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `emerging-threats-deep.md`, `encoding-manipulation-deep.md`, `gcp-security-deep.md`, `hardening-guides-ultimate.md`, `ics-scada-deep.md`, `identity-auth-deep.md`, `incident-playbooks-deep.md`, `linux-exploitation-deep.md`, `logging-monitoring-deep.md`, `mobile-security-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `osint-tradecraft-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `pentest-reporting-deep.md`, `purple-team-deep.md`, `recon-osint-deep.md`, `redteam-infra-deep.md`, `supplementary-security-knowledge.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-scenarios.md`, `shells-arsenal-deep.md`, `social-engineering-deep.md`, `websec-deep.md`, `wireless-physical-iot-deep.md` |
| Kubernetes | `attack-chains-synthesis.md`, `azure-security-ultimate.md`, `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `container-k8s-deep.md`, `crypto-pki-tls-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `gcp-security-deep.md`, `hardening-guides-ultimate.md`, `linux-exploitation-deep.md`, `logging-monitoring-deep.md`, `privacy-engineering-deep.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-automation-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `threat-modeling-arch-deep.md`, `websec-deep.md` |
| Trivy | `cloud-infra-deep.md`, `container-k8s-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-automation-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |
| Grype | `container-k8s-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md` |
| kube-bench | `container-k8s-deep.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md` |
| Falco | `attack-chains-synthesis.md`, `container-k8s-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-leadership-deep.md`, `security-scenarios.md` |
| Cilium | `container-k8s-deep.md`, `defensive-synthesis.md`, `hardening-guides-ultimate.md`, `security-architecture-deep.md` |
| Calico | `container-k8s-deep.md`, `defensive-synthesis.md`, `secure-infrastructure-deep.md` |
| Istio | `defensive-synthesis.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |

### SIEM & Detection

| Tool | Document(s) |
|------|-------------|
| Splunk | `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `hardening-guides-ultimate.md`, `logging-monitoring-deep.md`, `purple-team-deep.md`, `recon-osint-deep.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md` |
| Elastic | `bugbounty-methodology-deep.md`, `cloud-infra-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `evasion-techniques-deep.md`, `hardening-guides-ultimate.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `recon-osint-deep.md`, `security-automation-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md` |
| Wazuh | `curated-resources-deep.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `siem-soc-deep.md` |
| OSSEC | `curated-resources-deep.md`, `evasion-detection-catalog.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-mastery-deep.md`, `siem-soc-deep.md` |
| Sigma | `active-directory-deep.md`, `ai-defense-deep.md`, `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md`, `c2-postexploit-deep.md`, `cloud-infra-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `exfil-tunneling-deep.md`, `forensics-artifacts-deep.md`, `gcp-security-deep.md`, `grc-risk-deep.md`, `hardening-guides-ultimate.md`, `ics-scada-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `logging-monitoring-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `mobile-security-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `password-credential-deep.md`, `purple-team-deep.md`, `recon-osint-deep.md`, `redteam-infra-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `security-scenarios.md`, `shells-arsenal-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md`, `wireless-physical-iot-deep.md` |
| Suricata | `curated-resources-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `evasion-detection-catalog.md`, `hardening-guides-ultimate.md`, `ics-scada-deep.md`, `malware-analysis-deep.md`, `network-attacks-deep.md`, `network-forensics-deep.md`, `purple-team-deep.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md`, `wireless-physical-iot-deep.md` |
| Snort | `curated-resources-deep.md`, `defensive-synthesis.md`, `ics-scada-deep.md`, `malware-analysis-deep.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-intel-deep.md` |
| Zeek | `attack-chains-synthesis.md`, `ctf-methodology-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `exfil-tunneling-deep.md`, `hardening-guides-ultimate.md`, `ics-scada-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `mitre-attack-deep.md`, `network-forensics-deep.md`, `password-credential-deep.md`, `purple-team-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `threat-hunting-deep.md`, `wireless-physical-iot-deep.md` |
| Sysmon | `active-directory-deep.md`, `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `exfil-tunneling-deep.md`, `forensics-artifacts-deep.md`, `hardening-guides-ultimate.md`, `ics-scada-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `purple-team-deep.md`, `redteam-infra-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| auditd | `attack-chains-synthesis.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `exfil-tunneling-deep.md`, `hardening-guides-ultimate.md`, `linux-exploitation-deep.md`, `logging-monitoring-deep.md`, `mitre-attack-deep.md`, `network-protocol-deep.md`, `secops-runbooks-deep.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `websec-deep.md` |
| osquery | `dfir-hunting-deep.md`, `hardening-guides-ultimate.md`, `incident-playbooks-deep.md`, `purple-team-deep.md`, `security-automation-deep.md`, `siem-soc-deep.md`, `threat-hunting-deep.md` |
| Prometheus | `c2-postexploit-deep.md`, `cloud-infra-deep.md`, `privacy-crypto-deep.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md` |
| Grafana | `c2-postexploit-deep.md`, `cloud-infra-deep.md`, `logging-monitoring-deep.md`, `secure-infrastructure-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md` |
| ELK Stack | `defensive-deep.md`, `secure-infrastructure-deep.md`, `security-certifications-deep.md` |

### Vulnerability Scanning

| Tool | Document(s) |
|------|-------------|
| Nessus | `defensive-synthesis.md`, `dns-email-infra-deep.md`, `ics-scada-deep.md`, `pentest-reporting-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md` |
| OpenVAS | `curated-resources-deep.md`, `defensive-synthesis.md`, `pentest-reporting-deep.md`, `security-certifications-deep.md` |
| Qualys | `defensive-synthesis.md`, `pentest-reporting-deep.md`, `security-automation-deep.md` |
| Tenable | `ics-scada-deep.md` |

### SAST/DAST/SCA

| Tool | Document(s) |
|------|-------------|
| SonarQube | `curated-resources-deep.md`, `devsecops-sdlc-deep.md`, `mobile-security-deep.md`, `security-mastery-deep.md` |
| Semgrep | `blockchain-web3-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `mobile-security-deep.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `vuln-research-deep.md` |
| Checkov | `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `secops-runbooks-deep.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |
| tfsec | `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `secops-runbooks-deep.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |
| Snyk | `attack-chains-synthesis.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `mobile-security-deep.md`, `security-architecture-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md` |
| Bandit | `blockchain-web3-deep.md`, `ctf-methodology-deep.md`, `devsecops-sdlc-deep.md`, `security-scenarios.md` |
| pip-audit | `security-automation-deep.md`, `security-scenarios.md` |
| gitleaks | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `crypto-pki-tls-deep.md`, `defensive-synthesis.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `recon-osint-deep.md`, `redteam-infra-deep.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `websec-deep.md` |
| trufflehog | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `crypto-pki-tls-deep.md`, `defensive-synthesis.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `incident-playbooks-deep.md`, `recon-osint-deep.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |
| git-secrets | `dev-security-deep.md`, `incident-playbooks-deep.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md` |
| detect-secrets | `dev-security-deep.md`, `security-scenarios.md` |

### Reverse Engineering & Malware

| Tool | Document(s) |
|------|-------------|
| Ghidra | `binary-exploitation-deep.md`, `ctf-methodology-deep.md`, `dfir-hunting-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mobile-security-deep.md`, `vuln-research-deep.md`, `windows-ad-deep.md`, `wireless-physical-iot-deep.md` |
| IDA Pro | `ctf-methodology-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `security-certifications-deep.md`, `vuln-research-deep.md`, `windows-ad-deep.md`, `wireless-physical-iot-deep.md` |
| Binary Ninja | `ctf-methodology-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `windows-ad-deep.md` |
| x64dbg | `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `windows-ad-deep.md` |
| radare2 | `binary-exploitation-deep.md`, `ctf-methodology-deep.md`, `dfir-hunting-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mobile-security-deep.md`, `windows-ad-deep.md` |
| Cutter | `ctf-methodology-deep.md`, `malware-analysis-deep.md` |
| PEStudio | `ctf-methodology-deep.md`, `malware-analysis-deep.md`, `windows-ad-deep.md` |
| Frida | `ctf-methodology-deep.md`, `malware-re-evasion-deep.md`, `mobile-security-deep.md`, `vuln-research-deep.md`, `windows-ad-deep.md` |
| objection | `mobile-security-deep.md`, `privacy-regulations-deep.md` |
| CyberChef | `ctf-methodology-deep.md`, `encoding-manipulation-deep.md`, `network-forensics-deep.md`, `websec-deep.md` |
| YARA | `c2-postexploit-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `forensics-artifacts-deep.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `supplementary-security-knowledge.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-intel-deep.md` |
| Cuckoo | `dfir-hunting-deep.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `security-automation-deep.md` |
| CAPE | `cloud-infra-deep.md`, `malware-analysis-deep.md`, `windows-ad-deep.md` |
| REMnux | `dfir-hunting-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md` |

### DFIR & Forensics

| Tool | Document(s) |
|------|-------------|
| Volatility | `ctf-methodology-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `evasion-detection-catalog.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `windows-ad-deep.md` |
| Autopsy | `ctf-methodology-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `forensics-artifacts-deep.md`, `incident-playbooks-deep.md` |
| FTK | `dfir-hunting-deep.md`, `forensics-artifacts-deep.md`, `incident-playbooks-deep.md` |
| Velociraptor | `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `exfil-tunneling-deep.md`, `forensics-artifacts-deep.md`, `incident-playbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md` |
| KAPE | `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `exfil-tunneling-deep.md`, `forensics-artifacts-deep.md`, `incident-playbooks-deep.md`, `threat-hunting-deep.md` |
| GRR | `curated-resources-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `forensics-artifacts-deep.md`, `incident-playbooks-deep.md`, `security-certifications-deep.md`, `threat-hunting-deep.md` |
| RegRipper | `forensics-artifacts-deep.md` |
| tcpdump | `container-k8s-deep.md`, `exfil-tunneling-deep.md`, `incident-playbooks-deep.md`, `linux-exploitation-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `network-forensics-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-scenarios.md` |
| tshark | `ctf-methodology-deep.md`, `malware-analysis-deep.md`, `security-scenarios.md`, `wireless-physical-iot-deep.md` |
| Arkime | `curated-resources-deep.md`, `defensive-synthesis.md`, `network-forensics-deep.md` |
| NetworkMiner | `ctf-methodology-deep.md`, `incident-playbooks-deep.md` |
| binwalk | `ctf-methodology-deep.md`, `encoding-manipulation-deep.md`, `exfil-tunneling-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `wireless-physical-iot-deep.md` |
| foremost | `ctf-methodology-deep.md`, `exfil-tunneling-deep.md`, `malware-analysis-deep.md` |
| scalpel | `ctf-methodology-deep.md` |
| dcfldd | `forensics-artifacts-deep.md`, `security-mastery-deep.md` |
| dd | `api-exploitation-deep.md`, `ctf-methodology-deep.md`, `dfir-hunting-deep.md`, `email-phishing-se-deep.md`, `encoding-manipulation-deep.md`, `forensics-artifacts-deep.md`, `logging-monitoring-deep.md`, `privacy-engineering-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-modeling-arch-deep.md` |

### Threat Intelligence

| Tool | Document(s) |
|------|-------------|
| MISP | `curated-resources-deep.md`, `defensive-synthesis.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `privacy-osint-deep.md`, `security-automation-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md` |
| TheHive | `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `incident-playbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md` |
| Cortex | `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dns-email-infra-deep.md`, `evasion-techniques-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md`, `wireless-physical-iot-deep.md` |
| OpenCTI | `curated-resources-deep.md`, `incident-playbooks-deep.md`, `security-automation-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md` |
| STIX | `curated-resources-deep.md`, `incident-playbooks-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md` |
| TAXII | `curated-resources-deep.md`, `incident-playbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `threat-intel-deep.md` |
| IntelMQ | `security-automation-deep.md` |
| VirusTotal | `curated-resources-deep.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `evasion-techniques-deep.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `recon-osint-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `threat-intel-deep.md`, `websec-deep.md` |
| Any.Run | `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `security-automation-deep.md`, `windows-ad-deep.md` |
| Joe Sandbox | `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `security-automation-deep.md`, `windows-ad-deep.md` |
| Hybrid Analysis | `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `osint-tradecraft-deep.md`, `security-automation-deep.md`, `windows-ad-deep.md` |
| MalwareBazaar | `malware-analysis-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `threat-intel-deep.md` |
| URLhaus | `email-phishing-se-deep.md`, `network-forensics-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `threat-intel-deep.md` |
| GreyNoise | `curated-resources-deep.md`, `osint-tradecraft-deep.md`, `privacy-osint-deep.md`, `security-automation-deep.md`, `threat-intel-deep.md` |
| Recorded Future | `threat-intel-deep.md` |
| CrowdStrike | `azure-security-ultimate.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `evasion-techniques-deep.md`, `malware-analysis-deep.md`, `security-automation-deep.md`, `security-scenarios.md`, `sigma-detection-deep.md`, `threat-intel-deep.md` |

### Adversary Simulation

| Tool | Document(s) |
|------|-------------|
| Caldera | `curated-resources-deep.md`, `dfir-hunting-deep.md`, `offensive-deep.md`, `purple-team-deep.md`, `secops-runbooks-deep.md` |
| Atomic Red Team | `curated-resources-deep.md`, `dfir-hunting-deep.md`, `offensive-deep.md`, `purple-team-deep.md`, `supplementary-security-knowledge.md`, `secops-runbooks-deep.md` |

### EDR & Endpoint

| Tool | Document(s) |
|------|-------------|
| SentinelOne | `defensive-synthesis.md`, `emerging-threats-deep.md`, `evasion-techniques-deep.md`, `security-scenarios.md` |
| Carbon Black | `evasion-techniques-deep.md` |
| Cortex XDR | `evasion-techniques-deep.md` |
| Microsoft Defender | `attack-chains-synthesis.md`, `cloud-attacks-deep.md`, `defensive-synthesis.md`, `logging-monitoring-deep.md`, `purple-team-deep.md`, `windows-ad-deep.md` |
| ClamAV | `curated-resources-deep.md`, `hardening-guides-ultimate.md`, `malware-re-evasion-deep.md`, `network-forensics-deep.md`, `secure-infrastructure-deep.md` |
| rkhunter | `curated-resources-deep.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md` |
| chkrootkit | `curated-resources-deep.md`, `hardening-guides-ultimate.md` |

### Mobile Security

| Tool | Document(s) |
|------|-------------|
| MobSF | `mobile-security-deep.md` |
| drozer | `mobile-security-deep.md` |
| apktool | `ctf-methodology-deep.md`, `malware-re-evasion-deep.md`, `mobile-security-deep.md` |
| jadx | `ctf-methodology-deep.md`, `malware-re-evasion-deep.md`, `mobile-security-deep.md` |
| dex2jar | `ctf-methodology-deep.md`, `mobile-security-deep.md` |

### Infrastructure & IaC

| Tool | Document(s) |
|------|-------------|
| Terraform | `aws-security-ultimate.md`, `azure-security-ultimate.md`, `cloud-attacks-deep.md`, `cloud-infra-deep.md`, `container-k8s-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `insider-threat-dlp-deep.md`, `pentest-reporting-deep.md`, `privacy-engineering-deep.md`, `privacy-osint-deep.md`, `purple-team-deep.md`, `redteam-infra-deep.md`, `secops-runbooks-deep.md`, `secure-coding-deep.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |
| Ansible | `aws-security-ultimate.md`, `cloud-attacks-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `hardening-guides-ultimate.md`, `purple-team-deep.md`, `redteam-infra-deep.md`, `secure-infrastructure-deep.md` |
| Vault | `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md`, `blockchain-web3-deep.md`, `c2-postexploit-deep.md`, `cloud-attacks-deep.md`, `cloud-infra-deep.md`, `container-k8s-deep.md`, `crypto-pki-tls-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `identity-auth-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `logging-monitoring-deep.md`, `osint-tradecraft-deep.md`, `pentest-reporting-deep.md`, `privacy-crypto-deep.md`, `privacy-engineering-deep.md`, `privacy-osint-deep.md`, `redteam-infra-deep.md`, `secops-runbooks-deep.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-modeling-arch-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| SOPS | `curated-resources-deep.md`, `privacy-osint-deep.md`, `secure-infrastructure-deep.md`, `siem-soc-deep.md` |
| OpenSSL | `container-k8s-deep.md`, `crypto-pki-tls-deep.md`, `dev-security-deep.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `encoding-manipulation-deep.md`, `exfil-tunneling-deep.md`, `hardening-guides-ultimate.md`, `linux-exploitation-deep.md`, `mobile-security-deep.md`, `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `secure-infrastructure-deep.md`, `shells-arsenal-deep.md`, `threat-hunting-deep.md`, `wireless-physical-iot-deep.md` |
| Packer | `curated-resources-deep.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `redteam-infra-deep.md`, `secure-infrastructure-deep.md` |

### Network Security

| Tool | Document(s) |
|------|-------------|
| WireGuard | `c2-postexploit-deep.md`, `curated-resources-deep.md`, `osint-tradecraft-deep.md`, `privacy-osint-deep.md`, `purple-team-deep.md`, `secure-infrastructure-deep.md`, `security-certifications-deep.md` |
| Tailscale | `defensive-synthesis.md`, `redteam-infra-deep.md`, `security-scenarios.md` |
| pfSense | `curated-resources-deep.md` |
| OPNsense | `curated-resources-deep.md`, `privacy-crypto-deep.md` |
| ModSecurity | `devsecops-sdlc-deep.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md`, `security-scenarios.md` |
| fail2ban | `curated-resources-deep.md`, `defensive-synthesis.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md` |
| iptables | `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `evasion-detection-catalog.md`, `forensics-artifacts-deep.md`, `incident-playbooks-deep.md`, `linux-exploitation-deep.md`, `logging-monitoring-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |
| nftables | `binary-exploitation-deep.md`, `hardening-guides-ultimate.md`, `linux-exploitation-deep.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |
| Bettercap | `curated-resources-deep.md`, `network-attacks-deep.md`, `wireless-physical-iot-deep.md` |
| hcxdumptool | `wireless-physical-iot-deep.md` |
| wifite | `curated-resources-deep.md` |
| Kismet | `curated-resources-deep.md`, `wireless-physical-iot-deep.md` |

### Privacy & Anonymity

| Tool | Document(s) |
|------|-------------|
| Tor | `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `blockchain-web3-deep.md`, `cloud-infra-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `ics-scada-deep.md`, `incident-playbooks-deep.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `network-forensics-deep.md`, `network-protocol-deep.md`, `osint-tradecraft-deep.md`, `privacy-crypto-deep.md`, `privacy-engineering-deep.md`, `privacy-osint-deep.md`, `supplementary-security-knowledge.md`, `security-scenarios.md`, `threat-hunting-deep.md`, `threat-intel-deep.md` |
| Signal | `binary-exploitation-deep.md`, `ctf-methodology-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `emerging-threats-deep.md`, `evasion-techniques-deep.md`, `exfil-tunneling-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `malware-analysis-deep.md`, `network-forensics-deep.md`, `osint-tradecraft-deep.md`, `pentest-reporting-deep.md`, `privacy-crypto-deep.md`, `privacy-engineering-deep.md`, `privacy-osint-deep.md`, `privacy-regulations-deep.md`, `supplementary-security-knowledge.md`, `secure-coding-deep.md`, `security-leadership-deep.md`, `security-scenarios.md`, `shells-arsenal-deep.md`, `siem-soc-deep.md`, `vuln-research-deep.md`, `websec-deep.md`, `wireless-physical-iot-deep.md` |
| VeraCrypt | `attack-chains-synthesis.md`, `insider-threat-dlp-deep.md`, `privacy-osint-deep.md` |
| Tails | `curated-resources-deep.md`, `osint-tradecraft-deep.md` |
| Whonix | `osint-tradecraft-deep.md`, `privacy-crypto-deep.md` |
| GPG | `crypto-pki-tls-deep.md`, `curated-resources-deep.md`, `devsecops-sdlc-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `privacy-osint-deep.md`, `security-mastery-deep.md` |
| PGP | `crypto-pki-tls-deep.md`, `insider-threat-dlp-deep.md`, `osint-tradecraft-deep.md`, `password-credential-deep.md`, `pentest-reporting-deep.md`, `privacy-crypto-deep.md`, `privacy-osint-deep.md`, `recon-osint-deep.md`, `secops-runbooks-deep.md` |
| age | `c2-postexploit-deep.md`, `crypto-pki-tls-deep.md`, `defensive-deep.md`, `dev-security-deep.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `exfil-tunneling-deep.md`, `gcp-security-deep.md`, `hardening-guides-ultimate.md`, `identity-auth-deep.md`, `network-forensics-deep.md`, `privacy-crypto-deep.md`, `privacy-engineering-deep.md`, `privacy-osint-deep.md`, `privacy-regulations-deep.md`, `redteam-infra-deep.md`, `secops-runbooks-deep.md`, `secure-coding-deep.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-automation-deep.md`, `security-metrics-deep.md`, `siem-soc-deep.md`, `social-engineering-deep.md`, `vuln-research-deep.md` |
| KeePassXC | `privacy-osint-deep.md`, `supplementary-security-knowledge.md` |
| Bitwarden | `privacy-osint-deep.md` |

### Hardening & Compliance

| Tool | Document(s) |
|------|-------------|
| Lynis | `curated-resources-deep.md`, `defensive-synthesis.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md` |
| OpenSCAP | `curated-resources-deep.md`, `defensive-synthesis.md`, `hardening-guides-ultimate.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md` |
| AppArmor | `aws-security-ultimate.md`, `binary-exploitation-deep.md`, `container-k8s-deep.md`, `defensive-synthesis.md`, `emerging-threats-deep.md`, `evasion-detection-catalog.md`, `hardening-guides-ultimate.md`, `linux-exploitation-deep.md`, `mitre-attack-deep.md`, `security-architecture-deep.md`, `security-mastery-deep.md` |
| SELinux | `binary-exploitation-deep.md`, `container-k8s-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `evasion-detection-catalog.md`, `hardening-guides-ultimate.md`, `linux-exploitation-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `mobile-security-deep.md`, `security-architecture-deep.md`, `security-mastery-deep.md` |
| seccomp | `aws-security-ultimate.md`, `binary-exploitation-deep.md`, `container-k8s-deep.md`, `ctf-methodology-deep.md`, `defensive-synthesis.md`, `hardening-guides-ultimate.md`, `mobile-security-deep.md`, `security-architecture-deep.md`, `security-mastery-deep.md`, `vuln-research-deep.md` |
| Sysinternals | `logging-monitoring-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md` |
| Procmon | `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `pentest-cheatsheet-ultimate.md` |
| Process Monitor | `linux-exploitation-deep.md`, `malware-analysis-deep.md`, `windows-ad-deep.md` |
| Process Explorer | `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `windows-ad-deep.md` |
| Autoruns | `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |

### Windows Internals

| Tool | Document(s) |
|------|-------------|
| Sysinternals | `logging-monitoring-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md` |
| Procmon | `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `pentest-cheatsheet-ultimate.md` |
| Process Monitor | `linux-exploitation-deep.md`, `malware-analysis-deep.md`, `windows-ad-deep.md` |
| Process Explorer | `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `windows-ad-deep.md` |
| Autoruns | `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `sigma-detection-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md` |
| AccessChk | `offensive-deep.md`, `pentest-cheatsheet-ultimate.md`, `windows-internals-deep.md` |
| PsExec | `active-directory-deep.md`, `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `mitre-attack-deep.md`, `network-attacks-deep.md`, `network-protocol-deep.md`, `pentest-cheatsheet-ultimate.md`, `redteam-infra-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `windows-ad-deep.md` |

### Wireless & Hardware

| Tool | Document(s) |
|------|-------------|
| HackRF | `wireless-physical-iot-deep.md` |
| RTL-SDR | `wireless-physical-iot-deep.md` |
| Flipper Zero | `wireless-physical-iot-deep.md` |

### Supply Chain & Signing

| Tool | Document(s) |
|------|-------------|
| Sigstore | `ai-defense-deep.md`, `attack-chains-synthesis.md`, `cloud-infra-deep.md`, `container-k8s-deep.md`, `devsecops-sdlc-deep.md`, `security-scenarios.md` |
| cosign | `attack-chains-synthesis.md`, `cloud-infra-deep.md`, `container-k8s-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `security-architecture-deep.md`, `security-automation-deep.md`, `security-scenarios.md` |
| Notary | `container-k8s-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `security-architecture-deep.md` |

### Training Platforms

| Tool | Document(s) |
|------|-------------|
| HackTheBox | `ctf-methodology-deep.md`, `security-certifications-deep.md` |
| TryHackMe | `ctf-methodology-deep.md`, `security-certifications-deep.md` |
| PortSwigger | `api-exploitation-deep.md`, `ctf-methodology-deep.md`, `identity-auth-deep.md`, `security-certifications-deep.md`, `websec-deep.md` |
| Juice Shop | `curated-resources-deep.md`, `security-certifications-deep.md` |
| CloudGoat | `cloud-infra-deep.md` |

---

## 4. Compliance & Framework Index

**47 frameworks** referenced across the training corpus.

| Framework | Document(s) |
|-----------|-------------|
| CCPA | `grc-risk-deep.md`, `incident-playbooks-deep.md`, `mobile-security-deep.md`, `privacy-engineering-deep.md`, `privacy-regulations-deep.md`, `supplementary-security-knowledge.md`, `secops-runbooks-deep.md`, `security-leadership-deep.md` |
| CIS Benchmarks | `aws-security-ultimate.md`, `azure-security-ultimate.md`, `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `container-k8s-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `gcp-security-deep.md`, `hardening-guides-ultimate.md`, `pentest-reporting-deep.md`, `secops-runbooks-deep.md`, `secure-infrastructure-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `siem-soc-deep.md` |
| CIS Controls | `compliance-frameworks-deep.md`, `defensive-synthesis.md`, `grc-risk-deep.md`, `ics-scada-deep.md`, `secops-runbooks-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-metrics-deep.md`, `security-scenarios.md`, `threat-modeling-arch-deep.md`, `wireless-physical-iot-deep.md` |
| CISA KEV | `bugbounty-methodology-deep.md`, `container-k8s-deep.md`, `emerging-threats-deep.md`, `grc-risk-deep.md`, `pentest-reporting-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `threat-intel-deep.md`, `vuln-research-deep.md` |
| CMMC | `compliance-frameworks-deep.md`, `emerging-threats-deep.md`, `grc-risk-deep.md` |
| COBIT | `grc-risk-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md` |
| CPE | `security-certifications-deep.md`, `security-metrics-deep.md`, `vuln-research-deep.md`, `wireless-physical-iot-deep.md` |
| CSA CCM | `defensive-deep.md`, `secops-runbooks-deep.md`, `security-certifications-deep.md` |
| CVSS | `bugbounty-methodology-deep.md`, `cloud-infra-deep.md`, `devsecops-sdlc-deep.md`, `emerging-threats-deep.md`, `grc-risk-deep.md`, `mobile-security-deep.md`, `pentest-reporting-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `threat-modeling-arch-deep.md`, `vuln-research-deep.md` |
| CWE | `blockchain-web3-deep.md`, `bugbounty-methodology-deep.md`, `devsecops-sdlc-deep.md`, `insider-threat-dlp-deep.md`, `mitre-attack-deep.md`, `mobile-security-deep.md`, `pentest-reporting-deep.md`, `security-metrics-deep.md`, `security-scenarios.md`, `threat-modeling-arch-deep.md`, `vuln-research-deep.md` |
| CYBER KILL CHAIN | `attack-chains-synthesis.md`, `c2-postexploit-deep.md`, `ics-scada-deep.md`, `mitre-attack-deep.md`, `pentest-reporting-deep.md`, `purple-team-deep.md`, `security-certifications-deep.md`, `security-metrics-deep.md`, `sigma-detection-deep.md`, `threat-intel-deep.md`, `wireless-physical-iot-deep.md` |
| DIAMOND MODEL | `security-certifications-deep.md`, `threat-intel-deep.md` |
| DORA | `emerging-threats-deep.md`, `grc-risk-deep.md`, `secops-runbooks-deep.md` |
| DREAD | `ai-defense-deep.md`, `compliance-frameworks-deep.md`, `devsecops-sdlc-deep.md`, `pentest-reporting-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `threat-modeling-arch-deep.md` |
| EPSS | `container-k8s-deep.md`, `grc-risk-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `vuln-research-deep.md` |
| FAIR | `grc-risk-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `threat-modeling-arch-deep.md` |
| FISMA | `compliance-frameworks-deep.md`, `grc-risk-deep.md`, `incident-playbooks-deep.md` |
| FedRAMP | `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `grc-risk-deep.md`, `incident-playbooks-deep.md` |
| GDPR | `ai-defense-deep.md`, `bugbounty-methodology-deep.md`, `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `email-phishing-se-deep.md`, `exfil-tunneling-deep.md`, `grc-risk-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `logging-monitoring-deep.md`, `mobile-security-deep.md`, `osint-tradecraft-deep.md`, `pentest-reporting-deep.md`, `privacy-engineering-deep.md`, `privacy-regulations-deep.md`, `supplementary-security-knowledge.md`, `secops-runbooks-deep.md`, `security-architecture-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `security-scenarios.md`, `siem-soc-deep.md`, `threat-modeling-arch-deep.md`, `wireless-physical-iot-deep.md` |
| HIPAA | `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `grc-risk-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `pentest-reporting-deep.md`, `privacy-engineering-deep.md`, `privacy-regulations-deep.md`, `secops-runbooks-deep.md`, `secure-coding-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `siem-soc-deep.md` |
| ISO 27001 | `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `defensive-deep.md`, `grc-risk-deep.md`, `privacy-engineering-deep.md`, `secops-runbooks-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-metrics-deep.md`, `threat-modeling-arch-deep.md` |
| ISO 27005 | `security-certifications-deep.md` |
| ISO 27035 | `incident-playbooks-deep.md` |
| MITRE ATLAS | `ai-defense-deep.md`, `cloud-infra-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `websec-deep.md`, `wireless-physical-iot-deep.md` |
| MITRE ATT&CK | `active-directory-deep.md`, `ai-defense-deep.md`, `api-exploitation-deep.md`, `attack-chains-synthesis.md`, `aws-security-ultimate.md`, `azure-security-ultimate.md`, `blockchain-web3-deep.md`, `bugbounty-methodology-deep.md`, `c2-postexploit-deep.md`, `cloud-attacks-deep.md`, `cloud-infra-deep.md`, `container-k8s-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `dfir-hunting-deep.md`, `dns-email-infra-deep.md`, `email-phishing-se-deep.md`, `evasion-detection-catalog.md`, `evasion-techniques-deep.md`, `exfil-tunneling-deep.md`, `forensics-artifacts-deep.md`, `gcp-security-deep.md`, `grc-risk-deep.md`, `hardening-guides-ultimate.md`, `ics-scada-deep.md`, `identity-auth-deep.md`, `incident-playbooks-deep.md`, `insider-threat-dlp-deep.md`, `logging-monitoring-deep.md`, `malware-analysis-deep.md`, `malware-re-evasion-deep.md`, `mitre-attack-deep.md`, `mobile-security-deep.md`, `network-attacks-deep.md`, `network-forensics-deep.md`, `network-protocol-deep.md`, `offensive-deep.md`, `password-credential-deep.md`, `pentest-cheatsheet-ultimate.md`, `pentest-reporting-deep.md`, `purple-team-deep.md`, `recon-osint-deep.md`, `supplementary-security-knowledge.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `security-scenarios.md`, `shells-arsenal-deep.md`, `siem-soc-deep.md`, `sigma-detection-deep.md`, `social-engineering-deep.md`, `threat-hunting-deep.md`, `threat-intel-deep.md`, `threat-modeling-arch-deep.md`, `websec-deep.md`, `windows-ad-deep.md`, `windows-internals-deep.md`, `wireless-physical-iot-deep.md` |
| MITRE D3FEND | `mitre-attack-deep.md`, `network-protocol-deep.md`, `purple-team-deep.md` |
| NERC CIP | `grc-risk-deep.md`, `ics-scada-deep.md`, `wireless-physical-iot-deep.md` |
| NIS2 | `cloud-infra-deep.md`, `emerging-threats-deep.md`, `grc-risk-deep.md`, `incident-playbooks-deep.md`, `secops-runbooks-deep.md` |
| NIST 800-171 | `compliance-frameworks-deep.md` |
| NIST 800-53 | `compliance-frameworks-deep.md`, `defensive-deep.md`, `grc-risk-deep.md`, `ics-scada-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-metrics-deep.md`, `siem-soc-deep.md` |
| NIST 800-61 | `security-leadership-deep.md` |
| NIST 800-63 | `azure-security-ultimate.md`, `dev-security-deep.md`, `password-credential-deep.md`, `security-scenarios.md` |
| NIST 800-82 | `ics-scada-deep.md`, `security-scenarios.md` |
| NIST AI RMF | `ai-defense-deep.md` |
| NIST CSF | `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `defensive-synthesis.md`, `grc-risk-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-metrics-deep.md`, `threat-modeling-arch-deep.md` |
| OWASP ASVS | `compliance-frameworks-deep.md`, `threat-modeling-arch-deep.md` |
| OWASP MASVS | `compliance-frameworks-deep.md`, `mobile-security-deep.md` |
| OWASP SAMM | `security-metrics-deep.md` |
| OWASP Top 10 | `ai-defense-deep.md`, `api-exploitation-deep.md`, `compliance-frameworks-deep.md`, `devsecops-sdlc-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `secops-runbooks-deep.md`, `secure-infrastructure-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `threat-modeling-arch-deep.md` |
| OWASP WSTG | `pentest-reporting-deep.md`, `websec-deep.md` |
| PCI DSS | `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `crypto-pki-tls-deep.md`, `curated-resources-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `encoding-manipulation-deep.md`, `grc-risk-deep.md`, `incident-playbooks-deep.md`, `logging-monitoring-deep.md`, `pentest-reporting-deep.md`, `secops-runbooks-deep.md`, `secure-coding-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md`, `security-scenarios.md`, `siem-soc-deep.md` |
| SOC 1 | `security-certifications-deep.md` |
| SOC 2 | `cloud-infra-deep.md`, `compliance-frameworks-deep.md`, `defensive-deep.md`, `defensive-synthesis.md`, `grc-risk-deep.md`, `incident-playbooks-deep.md`, `pentest-reporting-deep.md`, `privacy-engineering-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-metrics-deep.md` |
| SOX | `grc-risk-deep.md`, `logging-monitoring-deep.md`, `secops-runbooks-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-metrics-deep.md`, `threat-modeling-arch-deep.md` |
| STIX/TAXII | `curated-resources-deep.md`, `incident-playbooks-deep.md`, `secops-runbooks-deep.md`, `security-automation-deep.md`, `security-certifications-deep.md`, `siem-soc-deep.md`, `threat-intel-deep.md` |
| STRIDE | `ai-defense-deep.md`, `azure-security-ultimate.md`, `compliance-frameworks-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `emerging-threats-deep.md`, `mobile-security-deep.md`, `pentest-reporting-deep.md`, `privacy-engineering-deep.md`, `supplementary-security-knowledge.md`, `security-architecture-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `security-scenarios.md`, `threat-modeling-arch-deep.md` |
| VERIS | `threat-intel-deep.md` |

---

## 5. OWASP Reference Index

**20 OWASP resources** referenced across the training corpus.

| OWASP Resource | Document(s) |
|---------------|-------------|
| OWASP ASVS | `compliance-frameworks-deep.md`, `threat-modeling-arch-deep.md` |
| OWASP Amass | `api-exploitation-deep.md`, `curated-resources-deep.md`, `devsecops-sdlc-deep.md`, `dns-email-infra-deep.md` |
| OWASP CRS | `azure-security-ultimate.md`, `defensive-synthesis.md`, `secure-infrastructure-deep.md`, `security-mastery-deep.md`, `security-scenarios.md` |
| OWASP Cheat Sheets | `api-exploitation-deep.md`, `blockchain-web3-deep.md`, `bugbounty-methodology-deep.md`, `container-k8s-deep.md`, `crypto-pki-tls-deep.md`, `curated-resources-deep.md`, `dev-security-deep.md`, `devsecops-sdlc-deep.md`, `grc-risk-deep.md`, `hardening-guides-ultimate.md`, `identity-auth-deep.md`, `insider-threat-dlp-deep.md`, `logging-monitoring-deep.md`, `mobile-security-deep.md`, `pentest-reporting-deep.md`, `privacy-engineering-deep.md`, `secops-runbooks-deep.md`, `secure-coding-deep.md`, `secure-infrastructure-deep.md`, `security-architecture-deep.md`, `security-leadership-deep.md`, `security-metrics-deep.md`, `threat-modeling-arch-deep.md`, `websec-deep.md` |
| OWASP Dependency-Check | `devsecops-sdlc-deep.md`, `mobile-security-deep.md` |
| OWASP DevSecOps | `devsecops-sdlc-deep.md` |
| OWASP Juice Shop | `curated-resources-deep.md`, `security-certifications-deep.md` |
| OWASP Logging | `dev-security-deep.md`, `logging-monitoring-deep.md`, `secure-coding-deep.md` |
| OWASP MASTG | `mobile-security-deep.md` |
| OWASP MASVS | `compliance-frameworks-deep.md`, `mobile-security-deep.md` |
| OWASP Risk Rating | `pentest-reporting-deep.md` |
| OWASP SAMM | `security-metrics-deep.md` |
| OWASP Testing Guide | `security-certifications-deep.md` |
| OWASP Threat Dragon | `devsecops-sdlc-deep.md`, `security-leadership-deep.md`, `threat-modeling-arch-deep.md` |
| OWASP Top 10 API | `api-exploitation-deep.md`, `websec-deep.md` |
| OWASP Top 10 LLM | `ai-defense-deep.md` |
| OWASP Top 10 Mobile | `mobile-security-deep.md` |
| OWASP Top 10 Web | `api-exploitation-deep.md`, `compliance-frameworks-deep.md`, `devsecops-sdlc-deep.md`, `incident-playbooks-deep.md`, `mitre-attack-deep.md`, `secops-runbooks-deep.md`, `secure-infrastructure-deep.md`, `security-certifications-deep.md`, `security-leadership-deep.md`, `security-mastery-deep.md`, `threat-modeling-arch-deep.md` |
| OWASP WSTG | `pentest-reporting-deep.md`, `websec-deep.md` |
| OWASP ZAP | `api-exploitation-deep.md`, `curated-resources-deep.md`, `defensive-synthesis.md`, `devsecops-sdlc-deep.md`, `security-mastery-deep.md`, `websec-deep.md` |

---

## 6. Topic Finder (A-Z)

Alphabetical index of 250+ security topics with the document(s) providing deepest coverage.

| Topic | Primary Document | Supporting Document(s) |
|-------|-----------------|----------------------|
| ADCS Abuse | `active-directory-deep.md` | `windows-ad-deep.md` |
| AI/ML Security | `ai-defense-deep.md` | `emerging-threats-deep.md` |
| AMSI Bypass | `evasion-techniques-deep.md` | `malware-re-evasion-deep.md` |
| API Security | `api-exploitation-deep.md` | `websec-deep.md` |
| ARP Spoofing | `network-attacks-deep.md` | `network-protocol-deep.md` |
| AS-REP Roasting | `active-directory-deep.md` | `password-credential-deep.md` |
| AWS IAM | `aws-security-ultimate.md` | `cloud-attacks-deep.md` |
| AWS Lambda | `aws-security-ultimate.md` | `cloud-attacks-deep.md` |
| AWS S3 Security | `aws-security-ultimate.md` | `cloud-attacks-deep.md` |
| Access Control Lists (ACLs) | `active-directory-deep.md` | `hardening-guides-ultimate.md` |
| Account Takeover | `identity-auth-deep.md` | `email-phishing-se-deep.md` |
| Active Directory Attacks | `active-directory-deep.md` | `windows-ad-deep.md` |
| Adversary Emulation | `purple-team-deep.md` | `mitre-attack-deep.md` |
| Android Security | `mobile-security-deep.md` | `wireless-physical-iot-deep.md` |
| Anomaly Detection | `threat-hunting-deep.md` | `siem-soc-deep.md` |
| Anti-Forensics | `forensics-artifacts-deep.md` | `evasion-techniques-deep.md`, `timeline-analysis-deep.md` |
| AppArmor | `hardening-guides-ultimate.md` | `container-k8s-deep.md` |
| Application Logging | `logging-monitoring-deep.md` | `secure-coding-deep.md` |
| Attack Chains | `attack-chains-synthesis.md` | `security-scenarios.md` |
| Attack Surface Management | `recon-osint-deep.md` | `bugbounty-methodology-deep.md` |
| Audit Logging | `logging-monitoring-deep.md` | `compliance-frameworks-deep.md` |
| Authentication Bypass | `identity-auth-deep.md` | `websec-deep.md` |
| Azure AD | `azure-security-ultimate.md` | `identity-auth-deep.md` |
| Azure Security | `azure-security-ultimate.md` | `cloud-attacks-deep.md` |
| BOF (Beacon Object Files) | `c2-postexploit-deep.md` | `redteam-infra-deep.md` |
| Base64 Encoding | `encoding-manipulation-deep.md` | `evasion-techniques-deep.md` |
| Binary Exploitation | `binary-exploitation-deep.md` | `ctf-methodology-deep.md` |
| Blockchain Security | `blockchain-web3-deep.md` | — |
| BloodHound | `active-directory-deep.md` | `windows-ad-deep.md` |
| Blue Team Operations | `defensive-deep.md` | `defensive-synthesis.md` |
| Breach Notification | `incident-playbooks-deep.md` | `privacy-regulations-deep.md` |
| Browser Exploitation | `websec-deep.md` | `encoding-manipulation-deep.md` |
| Brute Force Attacks | `password-credential-deep.md` | `identity-auth-deep.md` |
| Buffer Overflow | `binary-exploitation-deep.md` | `vuln-research-deep.md` |
| Bug Bounty | `bugbounty-methodology-deep.md` | `pentest-reporting-deep.md` |
| BEC Investigation | `email-forensics-deep.md` | `email-phishing-se-deep.md` |
| Business Continuity | `grc-risk-deep.md` | `security-leadership-deep.md` |
| C2 Frameworks | `c2-postexploit-deep.md` | `redteam-infra-deep.md` |
| C2 Infrastructure | `redteam-infra-deep.md` | `c2-postexploit-deep.md` |
| CCPA Compliance | `privacy-regulations-deep.md` | `compliance-frameworks-deep.md` |
| CI/CD Pipeline Security | `devsecops-sdlc-deep.md` | `container-k8s-deep.md` |
| CIS Benchmarks | `hardening-guides-ultimate.md` | `compliance-frameworks-deep.md` |
| CTF Methodology | `ctf-methodology-deep.md` | `binary-exploitation-deep.md` |
| CVSS Scoring | `pentest-reporting-deep.md` | `vuln-research-deep.md` |
| Certificate Pinning | `crypto-pki-tls-deep.md` | `mobile-security-deep.md` |
| Certificate Transparency | `crypto-pki-tls-deep.md` | `dns-email-infra-deep.md` |
| Cloud Attack Paths | `cloud-attacks-deep.md` | `attack-chains-synthesis.md` |
| Cloud Hardening | `cloud-infra-deep.md` | `defensive-deep.md` |
| Cloud IAM | `aws-security-ultimate.md` | `azure-security-ultimate.md, gcp-security-deep.md` |
| Cloud Logging | `logging-monitoring-deep.md` | `aws-security-ultimate.md` |
| Cloud Metadata Attacks | `cloud-attacks-deep.md` | `aws-security-ultimate.md` |
| Cloud Security Posture | `cloud-infra-deep.md` | `defensive-synthesis.md` |
| Code Injection | `secure-coding-deep.md` | `websec-deep.md` |
| Command Injection | `secure-coding-deep.md` | `websec-deep.md` |
| Compliance Automation | `security-automation-deep.md` | `compliance-frameworks-deep.md` |
| Consent Management | `privacy-engineering-deep.md` | `privacy-regulations-deep.md` |
| CI/CD to Kubernetes Attacks | `kubernetes-attacks-deep.md` | `devsecops-sdlc-deep.md` |
| Container Breakout | `container-k8s-deep.md` | `cloud-attacks-deep.md` |
| Container Hardening | `container-k8s-deep.md` | `hardening-guides-ultimate.md` |
| Container Image Scanning | `container-k8s-deep.md` | `devsecops-sdlc-deep.md` |
| Credential Dumping | `password-credential-deep.md` | `c2-postexploit-deep.md` |
| Credential Stuffing | `password-credential-deep.md` | `identity-auth-deep.md` |
| Cross-Site Request Forgery (CSRF) | `websec-deep.md` | `secure-coding-deep.md` |
| Cross-Site Scripting (XSS) | `websec-deep.md` | `secure-coding-deep.md` |
| Cryptographic Attacks | `crypto-pki-tls-deep.md` | `privacy-crypto-deep.md` |
| Cryptographic Best Practices | `crypto-pki-tls-deep.md` | `secure-coding-deep.md` |
| DCSync | `active-directory-deep.md` | `windows-ad-deep.md` |
| DFIR | `dfir-hunting-deep.md` | `forensics-artifacts-deep.md` |
| DKIM/DMARC/SPF | `dns-email-infra-deep.md` | `email-phishing-se-deep.md` |
| DLL Injection | `evasion-techniques-deep.md` | `malware-re-evasion-deep.md` |
| DLL Side-Loading | `evasion-techniques-deep.md` | `malware-re-evasion-deep.md` |
| DNS Attacks | `dns-email-infra-deep.md` | `network-attacks-deep.md` |
| DNS Exfiltration | `exfil-tunneling-deep.md` | `dns-email-infra-deep.md` |
| DNS Security | `dns-email-infra-deep.md` | `secure-infrastructure-deep.md` |
| DORA Compliance | `grc-risk-deep.md` | `emerging-threats-deep.md` |
| Dark Web Intelligence | `osint-tradecraft-deep.md` | `threat-intel-deep.md` |
| Data Classification | `insider-threat-dlp-deep.md` | `grc-risk-deep.md` |
| Data Exfiltration | `exfil-tunneling-deep.md` | `insider-threat-dlp-deep.md` |
| Data Loss Prevention (DLP) | `insider-threat-dlp-deep.md` | `privacy-engineering-deep.md` |
| Data Privacy Impact Assessment (DPIA) | `privacy-engineering-deep.md` | `privacy-regulations-deep.md` |
| Deception Technology | `defensive-deep.md` | `threat-hunting-deep.md` |
| Deepfake Detection | `ai-defense-deep.md` | `emerging-threats-deep.md` |
| Defense Evasion | `evasion-techniques-deep.md` | `evasion-detection-catalog.md` |
| Dependency Scanning | `devsecops-sdlc-deep.md` | `secure-coding-deep.md` |
| Deserialization Attacks | `websec-deep.md` | `secure-coding-deep.md` |
| Detection Engineering | `sigma-detection-deep.md` | `purple-team-deep.md` |
| Detection Gap Analysis | `purple-team-deep.md` | `evasion-detection-catalog.md` |
| DevSecOps | `devsecops-sdlc-deep.md` | `secure-coding-deep.md` |
| Differential Privacy | `privacy-engineering-deep.md` | `privacy-crypto-deep.md` |
| Disk Forensics | `forensics-artifacts-deep.md` | `dfir-hunting-deep.md` |
| Docker Security | `container-k8s-deep.md` | `hardening-guides-ultimate.md` |
| Domain Enumeration | `recon-osint-deep.md` | `dns-email-infra-deep.md` |
| Domain Fronting | `exfil-tunneling-deep.md` | `redteam-infra-deep.md` |
| EDR Architecture | `edr-av-internals-deep.md` | `defensive-deep.md` |
| EDR Evasion | `evasion-techniques-deep.md` | `evasion-detection-catalog.md`, `edr-av-internals-deep.md` |
| ETW (Event Tracing) | `evasion-techniques-deep.md` | `windows-internals-deep.md` |
| EDR Tuning | `edr-av-internals-deep.md` | `siem-soc-deep.md` |
| Email Forensics | `email-forensics-deep.md` | `dns-email-infra-deep.md` |
| Email Header Analysis | `email-forensics-deep.md` | `email-phishing-se-deep.md`, `dns-email-infra-deep.md` |
| Email Security | `dns-email-infra-deep.md` | `email-phishing-se-deep.md`, `email-forensics-deep.md` |
| Emerging Threats | `emerging-threats-deep.md` | `threat-intel-deep.md` |
| Encryption at Rest | `crypto-pki-tls-deep.md` | `privacy-crypto-deep.md` |
| Endpoint Detection | `edr-av-internals-deep.md` | `defensive-deep.md`, `siem-soc-deep.md` |
| Evidence Preservation | `forensics-artifacts-deep.md` | `incident-playbooks-deep.md` |
| Exploit Development | `binary-exploitation-deep.md` | `vuln-research-deep.md` |
| FedRAMP | `compliance-frameworks-deep.md` | `grc-risk-deep.md` |
| File Inclusion (LFI/RFI) | `websec-deep.md` | `offensive-deep.md` |
| File Upload Attacks | `websec-deep.md` | `secure-coding-deep.md` |
| Firewall Rules | `hardening-guides-ultimate.md` | `secure-infrastructure-deep.md` |
| Format String Vulnerabilities | `binary-exploitation-deep.md` | `secure-coding-deep.md` |
| Fuzzing | `vuln-research-deep.md` | `binary-exploitation-deep.md` |
| GCP Security | `gcp-security-deep.md` | `cloud-attacks-deep.md` |
| GDPR Compliance | `privacy-regulations-deep.md` | `privacy-engineering-deep.md` |
| GRC | `grc-risk-deep.md` | `compliance-frameworks-deep.md` |
| Golden Ticket | `active-directory-deep.md` | `windows-ad-deep.md` |
| GraphQL Security | `api-exploitation-deep.md` | `websec-deep.md` |
| Group Policy | `windows-ad-deep.md` | `hardening-guides-ultimate.md` |
| HIPAA Compliance | `privacy-regulations-deep.md` | `compliance-frameworks-deep.md` |
| HTTP Request Smuggling | `websec-deep.md` | `api-exploitation-deep.md` |
| Hardening Checklists | `hardening-guides-ultimate.md` | `secure-infrastructure-deep.md` |
| Hash Cracking | `password-credential-deep.md` | `active-directory-deep.md` |
| Heap Exploitation | `binary-exploitation-deep.md` | `ctf-methodology-deep.md` |
| Homomorphic Encryption | `privacy-crypto-deep.md` | `privacy-engineering-deep.md` |
| Honeypots & Deception | `defensive-deep.md` | `threat-hunting-deep.md` |
| IAM Best Practices | `identity-auth-deep.md` | `aws-security-ultimate.md` |
| ICS/SCADA Security | `ics-scada-deep.md` | `wireless-physical-iot-deep.md` |
| Identity Federation | `identity-auth-deep.md` | `azure-security-ultimate.md` |
| Incident Response | `incident-playbooks-deep.md` | `secops-runbooks-deep.md` |
| Incident Triage | `incident-playbooks-deep.md` | `dfir-hunting-deep.md` |
| Indicators of Compromise (IOCs) | `threat-intel-deep.md` | `dfir-hunting-deep.md` |
| Infrastructure as Code | `devsecops-sdlc-deep.md` | `secure-infrastructure-deep.md` |
| Injection Attacks | `secure-coding-deep.md` | `websec-deep.md` |
| Insider Threats | `insider-threat-dlp-deep.md` | `security-scenarios.md` |
| IoT Security | `wireless-physical-iot-deep.md` | `ics-scada-deep.md` |
| JWT Attacks | `identity-auth-deep.md` | `api-exploitation-deep.md` |
| Kerberoasting | `active-directory-deep.md` | `password-credential-deep.md` |
| Kerberos | `active-directory-deep.md` | `windows-ad-deep.md` |
| Key Management | `crypto-pki-tls-deep.md` | `privacy-crypto-deep.md` |
| Kill Chain Analysis | `mitre-attack-deep.md` | `threat-intel-deep.md` |
| Kubernetes Attacks | `kubernetes-attacks-deep.md` | `container-k8s-deep.md` |
| Kubernetes Security | `container-k8s-deep.md` | `cloud-infra-deep.md`, `kubernetes-attacks-deep.md` |
| LDAP Injection | `active-directory-deep.md` | `secure-coding-deep.md` |
| Lateral Movement | `c2-postexploit-deep.md` | `active-directory-deep.md` |
| Linux Exploitation | `linux-exploitation-deep.md` | `shells-arsenal-deep.md` |
| Linux Forensics | `forensics-artifacts-deep.md` | `dfir-hunting-deep.md` |
| Linux Hardening | `hardening-guides-ultimate.md` | `linux-exploitation-deep.md` |
| Linux Privilege Escalation | `linux-exploitation-deep.md` | `pentest-cheatsheet-ultimate.md` |
| Living off the Land (LOTL) | `evasion-techniques-deep.md` | `mitre-attack-deep.md` |
| Log Analysis | `logging-monitoring-deep.md` | `siem-soc-deep.md` |
| Log Correlation | `siem-soc-deep.md` | `logging-monitoring-deep.md` |
| MITRE ATT&CK Framework | `mitre-attack-deep.md` | `purple-team-deep.md` |
| Malware Analysis (Dynamic) | `malware-analysis-deep.md` | `malware-re-evasion-deep.md` |
| Malware Analysis (Static) | `malware-analysis-deep.md` | `malware-re-evasion-deep.md` |
| Malware Development | `malware-re-evasion-deep.md` | `evasion-techniques-deep.md` |
| Malware Evasion | `malware-re-evasion-deep.md` | `evasion-detection-catalog.md` |
| Memory Forensics | `forensics-artifacts-deep.md` | `malware-analysis-deep.md` |
| Metadata Removal | `privacy-osint-deep.md` | `osint-tradecraft-deep.md` |
| Mobile App Testing | `mobile-security-deep.md` | `api-exploitation-deep.md` |
| Multi-Factor Authentication | `identity-auth-deep.md` | `hardening-guides-ultimate.md` |
| NIST 800-53 Controls | `compliance-frameworks-deep.md` | `grc-risk-deep.md` |
| NIST CSF | `compliance-frameworks-deep.md` | `grc-risk-deep.md` |
| NTLM Relay | `active-directory-deep.md` | `network-attacks-deep.md` |
| Network Forensics | `network-forensics-deep.md` | `dfir-hunting-deep.md` |
| Network Monitoring | `logging-monitoring-deep.md` | `network-forensics-deep.md` |
| Network Protocol Attacks | `network-protocol-deep.md` | `network-attacks-deep.md` |
| Network Segmentation | `secure-infrastructure-deep.md` | `security-architecture-deep.md` |
| Network Tunneling | `exfil-tunneling-deep.md` | `shells-arsenal-deep.md` |
| OAuth 2.0 Attacks | `identity-auth-deep.md` | `api-exploitation-deep.md` |
| OSINT Methodology | `osint-tradecraft-deep.md` | `recon-osint-deep.md` |
| Open Redirect | `websec-deep.md` | `bugbounty-methodology-deep.md` |
| Open Source Intelligence | `osint-tradecraft-deep.md` | `recon-osint-deep.md` |
| Operational Security (OPSEC) | `privacy-osint-deep.md` | `redteam-infra-deep.md` |
| PCI DSS Compliance | `compliance-frameworks-deep.md` | `grc-risk-deep.md` |
| PKI & Certificates | `crypto-pki-tls-deep.md` | `dns-email-infra-deep.md` |
| Packet Analysis | `network-forensics-deep.md` | `network-protocol-deep.md` |
| Password Attacks | `password-credential-deep.md` | `active-directory-deep.md` |
| Password Policy | `identity-auth-deep.md` | `hardening-guides-ultimate.md` |
| Patch Management | `secops-runbooks-deep.md` | `hardening-guides-ultimate.md` |
| Pentest Methodology | `pentest-cheatsheet-ultimate.md` | `offensive-deep.md` |
| Pentest Reporting | `pentest-reporting-deep.md` | `bugbounty-methodology-deep.md` |
| Persistence Mechanisms | `c2-postexploit-deep.md` | `mitre-attack-deep.md` |
| Phishing Campaigns | `email-phishing-se-deep.md` | `social-engineering-deep.md` |
| Physical Security | `wireless-physical-iot-deep.md` | `security-architecture-deep.md` |
| Policy Frameworks | `grc-risk-deep.md` | `security-leadership-deep.md` |
| Port Scanning | `recon-osint-deep.md` | `pentest-cheatsheet-ultimate.md` |
| Post-Exploitation | `c2-postexploit-deep.md` | `pentest-cheatsheet-ultimate.md` |
| PowerShell Attacks | `offensive-deep.md` | `evasion-techniques-deep.md` |
| Privacy Engineering | `privacy-engineering-deep.md` | `privacy-crypto-deep.md` |
| Privacy by Design | `privacy-engineering-deep.md` | `privacy-regulations-deep.md` |
| Privilege Escalation (Linux) | `linux-exploitation-deep.md` | `pentest-cheatsheet-ultimate.md` |
| Privilege Escalation (Windows) | `windows-ad-deep.md` | `pentest-cheatsheet-ultimate.md` |
| Process Hollowing | `evasion-techniques-deep.md` | `malware-re-evasion-deep.md` |
| Pod Escape Techniques | `kubernetes-attacks-deep.md` | `container-k8s-deep.md` |
| Process Injection | `evasion-techniques-deep.md` | `malware-re-evasion-deep.md`, `edr-av-internals-deep.md` |
| Prompt Injection | `ai-defense-deep.md` | `emerging-threats-deep.md` |
| Protocol Analysis | `network-protocol-deep.md` | `network-forensics-deep.md` |
| Purple Team Exercises | `purple-team-deep.md` | `evasion-detection-catalog.md` |
| ROP Chains | `binary-exploitation-deep.md` | `ctf-methodology-deep.md` |
| Race Conditions | `websec-deep.md` | `secure-coding-deep.md` |
| Ransomware | `incident-playbooks-deep.md` | `threat-intel-deep.md` |
| Ransomware IR | `incident-playbooks-deep.md` | `secops-runbooks-deep.md` |
| Red Team Infrastructure | `redteam-infra-deep.md` | `c2-postexploit-deep.md` |
| Red Team Operations | `offensive-deep.md` | `redteam-infra-deep.md` |
| Registry Forensics | `forensics-artifacts-deep.md` | `windows-internals-deep.md` |
| Regulatory Compliance | `compliance-frameworks-deep.md` | `privacy-regulations-deep.md` |
| Reverse Engineering | `malware-analysis-deep.md` | `binary-exploitation-deep.md` |
| Reverse Shells | `shells-arsenal-deep.md` | `pentest-cheatsheet-ultimate.md` |
| Risk Assessment | `grc-risk-deep.md` | `threat-modeling-arch-deep.md` |
| Risk Quantification | `security-metrics-deep.md` | `grc-risk-deep.md` |
| SAML Attacks | `identity-auth-deep.md` | `websec-deep.md` |
| SBOM | `supply-chain-security-deep.md` | `devsecops-sdlc-deep.md`, `container-k8s-deep.md` |
| SELinux | `hardening-guides-ultimate.md` | `linux-exploitation-deep.md` |
| SIEM Architecture | `siem-soc-deep.md` | `logging-monitoring-deep.md` |
| SMB Attacks | `network-attacks-deep.md` | `active-directory-deep.md` |
| SNMP Attacks | `network-protocol-deep.md` | `network-attacks-deep.md` |
| SOC 2 Compliance | `compliance-frameworks-deep.md` | `grc-risk-deep.md` |
| SOC Operations | `siem-soc-deep.md` | `secops-runbooks-deep.md` |
| SQL Injection | `websec-deep.md` | `secure-coding-deep.md` |
| SSH Hardening | `hardening-guides-ultimate.md` | `secure-infrastructure-deep.md` |
| SSL/TLS | `crypto-pki-tls-deep.md` | `network-protocol-deep.md` |
| SSRF | `websec-deep.md` | `secure-coding-deep.md` |
| SLSA Framework | `supply-chain-security-deep.md` | `devsecops-sdlc-deep.md` |
| Startup Security | `startup-security-deep.md` | `security-leadership-deep.md` |
| STRIDE Threat Modeling | `threat-modeling-arch-deep.md` | `security-architecture-deep.md` |
| Secure Architecture | `security-architecture-deep.md` | `threat-modeling-arch-deep.md` |
| Secure Boot | `hardening-guides-ultimate.md` | `windows-internals-deep.md` |
| Secure Coding | `secure-coding-deep.md` | `devsecops-sdlc-deep.md` |
| Secure SDLC | `devsecops-sdlc-deep.md` | `secure-coding-deep.md` |
| Security Automation | `security-automation-deep.md` | `devsecops-sdlc-deep.md` |
| Security Certifications | `security-certifications-deep.md` | `security-mastery-deep.md` |
| Security Metrics & KPIs | `security-metrics-deep.md` | `security-leadership-deep.md` |
| Security Operations Center | `siem-soc-deep.md` | `secops-runbooks-deep.md` |
| Security Program | `security-leadership-deep.md` | `grc-risk-deep.md`, `startup-security-deep.md` |
| Server-Side Request Forgery (SSRF) | `websec-deep.md` | `secure-coding-deep.md` |
| Service Mesh | `container-k8s-deep.md` | `secure-infrastructure-deep.md` |
| Session Management | `identity-auth-deep.md` | `websec-deep.md` |
| Shell Scripting (Offensive) | `shells-arsenal-deep.md` | `pentest-cheatsheet-ultimate.md` |
| Shellcode | `binary-exploitation-deep.md` | `malware-re-evasion-deep.md` |
| Sigma Rules | `sigma-detection-deep.md` | `purple-team-deep.md` |
| Silver Ticket | `active-directory-deep.md` | `windows-ad-deep.md` |
| Smart Contract Security | `blockchain-web3-deep.md` | — |
| Social Engineering | `social-engineering-deep.md` | `email-phishing-se-deep.md` |
| Stack-Based Overflow | `binary-exploitation-deep.md` | `vuln-research-deep.md` |
| Steganography | `ctf-methodology-deep.md` | `exfil-tunneling-deep.md` |
| Subdomain Enumeration | `recon-osint-deep.md` | `bugbounty-methodology-deep.md` |
| Super Timeline (Plaso) | `timeline-analysis-deep.md` | `dfir-hunting-deep.md` |
| Supply Chain Attacks | `supply-chain-security-deep.md` | `devsecops-sdlc-deep.md`, `emerging-threats-deep.md` |
| Sysmon Configuration | `logging-monitoring-deep.md` | `dfir-hunting-deep.md`, `windows-eventlog-mastery.md` |
| Sysmon Event IDs | `windows-eventlog-mastery.md` | `logging-monitoring-deep.md` |
| TLS Configuration | `crypto-pki-tls-deep.md` | `hardening-guides-ultimate.md` |
| Terraform Security | `secure-infrastructure-deep.md` | `devsecops-sdlc-deep.md` |
| Third-Party Risk | `grc-risk-deep.md` | `security-leadership-deep.md` |
| Threat Hunting | `threat-hunting-deep.md` | `dfir-hunting-deep.md` |
| Threat Intelligence | `threat-intel-deep.md` | `osint-tradecraft-deep.md` |
| Threat Modeling | `threat-modeling-arch-deep.md` | `security-architecture-deep.md` |
| Timeline Analysis | `timeline-analysis-deep.md` | `forensics-artifacts-deep.md`, `dfir-hunting-deep.md` |
| Token Theft | `identity-auth-deep.md` | `cloud-attacks-deep.md` |
| Unicode Attacks | `encoding-manipulation-deep.md` | `websec-deep.md` |
| Use-After-Free | `binary-exploitation-deep.md` | `vuln-research-deep.md` |
| VPN Security | `secure-infrastructure-deep.md` | `network-protocol-deep.md` |
| Vendor Risk Management | `grc-risk-deep.md` | `security-leadership-deep.md` |
| Vulnerability Disclosure | `pentest-reporting-deep.md` | `bugbounty-methodology-deep.md` |
| Vulnerability Management | `secops-runbooks-deep.md` | `security-metrics-deep.md` |
| Vulnerability Research | `vuln-research-deep.md` | `binary-exploitation-deep.md` |
| WAF Bypass | `websec-deep.md` | `encoding-manipulation-deep.md` |
| WMI Attacks | `windows-ad-deep.md` | `c2-postexploit-deep.md` |
| Web Application Security | `websec-deep.md` | `secure-coding-deep.md` |
| Web Cache Poisoning | `websec-deep.md` | `api-exploitation-deep.md` |
| Web Shell | `c2-postexploit-deep.md` | `shells-arsenal-deep.md` |
| Wi-Fi Attacks | `wireless-physical-iot-deep.md` | `network-attacks-deep.md` |
| Windows Event Logs | `windows-eventlog-mastery.md` | `windows-internals-deep.md`, `dfir-hunting-deep.md` |
| Windows Forensics | `forensics-artifacts-deep.md` | `windows-internals-deep.md` |
| Windows Hardening | `hardening-guides-ultimate.md` | `windows-internals-deep.md` |
| Windows Internals | `windows-internals-deep.md` | `evasion-techniques-deep.md` |
| Windows Privilege Escalation | `windows-ad-deep.md` | `pentest-cheatsheet-ultimate.md` |
| XXE Attacks | `websec-deep.md` | `secure-coding-deep.md` |
| Zero Day Research | `vuln-research-deep.md` | `emerging-threats-deep.md` |
| Zero Trust Architecture | `security-architecture-deep.md` | `secure-infrastructure-deep.md` |
| iOS Security | `mobile-security-deep.md` | `wireless-physical-iot-deep.md` |

---

## 7. Scenario Router

Given a situation or question, consult these documents in order.

### Active breach / live incident

1. `incident-playbooks-deep.md — IR playbooks with triage checklists`
1. `secops-runbooks-deep.md — operational runbooks for containment`
1. `forensics-artifacts-deep.md — evidence collection procedures`
1. `timeline-analysis-deep.md — super timeline generation and artifact correlation`
1. `dfir-hunting-deep.md — hunting for lateral movement & persistence`

### Ransomware attack in progress

1. `incident-playbooks-deep.md — ransomware-specific IR playbook`
1. `forensics-artifacts-deep.md — artifact preservation`
1. `threat-intel-deep.md — ransomware group TTPs and IOCs`
1. `emerging-threats-deep.md — latest ransomware variants`

### Phishing email received / BEC investigation

1. `email-forensics-deep.md — email header forensics and BEC playbook`
1. `email-phishing-se-deep.md — email analysis and phishing TTPs`
1. `dns-email-infra-deep.md — header analysis, SPF/DKIM/DMARC`
1. `incident-playbooks-deep.md — phishing IR playbook`
1. `social-engineering-deep.md — SE tactics and defenses`

### Web application pentest

1. `websec-deep.md — full web vulnerability catalog`
1. `api-exploitation-deep.md — API-specific attacks`
1. `encoding-manipulation-deep.md — WAF bypass and encoding tricks`
1. `bugbounty-methodology-deep.md — systematic testing methodology`
1. `pentest-cheatsheet-ultimate.md — quick-reference commands`

### Internal network pentest

1. `pentest-cheatsheet-ultimate.md — command reference`
1. `network-attacks-deep.md — network-layer attacks`
1. `active-directory-deep.md — AD attack paths`
1. `password-credential-deep.md — credential attacks`
1. `c2-postexploit-deep.md — post-exploitation techniques`
1. `shells-arsenal-deep.md — shell types and upgrades`

### Active Directory compromise assessment

1. `active-directory-deep.md — full AD attack reference`
1. `windows-ad-deep.md — Windows AD exploitation`
1. `password-credential-deep.md — credential harvesting`
1. `evasion-techniques-deep.md — defense evasion in AD`

### Cloud security review (AWS)

1. `aws-security-ultimate.md — AWS-specific controls and attacks`
1. `cloud-attacks-deep.md — cross-cloud attack techniques`
1. `cloud-infra-deep.md — cloud infrastructure hardening`
1. `identity-auth-deep.md — IAM and federation security`

### Cloud security review (Azure)

1. `azure-security-ultimate.md — Azure-specific controls`
1. `cloud-attacks-deep.md — cross-cloud attack techniques`
1. `identity-auth-deep.md — Azure AD and OAuth attacks`
1. `cloud-infra-deep.md — cloud infrastructure hardening`

### Cloud security review (GCP)

1. `gcp-security-deep.md — GCP-specific controls and attacks`
1. `cloud-attacks-deep.md — cross-cloud attack techniques`
1. `cloud-infra-deep.md — cloud infrastructure hardening`

### Build a detection rule

1. `sigma-detection-deep.md — Sigma rule authoring and conversion`
1. `windows-eventlog-mastery.md — Windows event ID reference and audit policy`
1. `siem-soc-deep.md — SIEM query patterns`
1. `logging-monitoring-deep.md — log source availability`
1. `evasion-detection-catalog.md — technique-to-detection mapping`
1. `edr-av-internals-deep.md — EDR telemetry sources and detection engineering`
1. `purple-team-deep.md — validation methodology`

### Threat hunt planning

1. `threat-hunting-deep.md — hunting hypotheses and methodology`
1. `dfir-hunting-deep.md — forensic hunting queries`
1. `mitre-attack-deep.md — technique coverage mapping`
1. `siem-soc-deep.md — SIEM query construction`

### Build a threat model

1. `threat-modeling-arch-deep.md — STRIDE/DREAD methodology`
1. `security-architecture-deep.md — architecture patterns`
1. `attack-chains-synthesis.md — realistic attack chains`
1. `mitre-attack-deep.md — ATT&CK coverage mapping`

### Security architecture review

1. `security-architecture-deep.md — architecture patterns and principles`
1. `threat-modeling-arch-deep.md — threat modeling`
1. `secure-infrastructure-deep.md — infrastructure hardening`
1. `identity-auth-deep.md — authentication architecture`
1. `crypto-pki-tls-deep.md — cryptographic design`

### DevSecOps pipeline setup

1. `devsecops-sdlc-deep.md — pipeline security controls`
1. `supply-chain-security-deep.md — SLSA, Sigstore, SBOM, dependency analysis`
1. `container-k8s-deep.md — container scanning and runtime`
1. `secure-coding-deep.md — code-level security`
1. `security-automation-deep.md — automation patterns`

### Compliance audit preparation

1. `compliance-frameworks-deep.md — framework requirements`
1. `grc-risk-deep.md — risk assessment methodology`
1. `hardening-guides-ultimate.md — technical control evidence`
1. `logging-monitoring-deep.md — audit trail requirements`
1. `security-metrics-deep.md — metrics for compliance reporting`

### GDPR / privacy compliance

1. `privacy-regulations-deep.md — article-by-article requirements`
1. `privacy-engineering-deep.md — technical controls (DPIA, PbD)`
1. `compliance-frameworks-deep.md — cross-framework mapping`
1. `privacy-crypto-deep.md — encryption and anonymization`

### Red team engagement planning

1. `redteam-infra-deep.md — C2 infrastructure setup`
1. `offensive-deep.md — engagement methodology`
1. `evasion-techniques-deep.md — defense evasion catalog`
1. `edr-av-internals-deep.md — EDR internals and bypass techniques`
1. `c2-postexploit-deep.md — post-exploitation frameworks`
1. `attack-chains-synthesis.md — realistic attack chains`

### Malware analysis / reverse engineering

1. `malware-analysis-deep.md — analysis methodology and tools`
1. `malware-re-evasion-deep.md — evasion techniques in malware`
1. `forensics-artifacts-deep.md — artifact extraction`
1. `evasion-detection-catalog.md — detection of malware behaviors`

### Vulnerability research / exploit development

1. `vuln-research-deep.md — vulnerability research methodology`
1. `binary-exploitation-deep.md — exploitation techniques`
1. `ctf-methodology-deep.md — hands-on practice approach`

### SOC setup / improvement

1. `siem-soc-deep.md — SOC architecture and workflows`
1. `sigma-detection-deep.md — detection rule management`
1. `logging-monitoring-deep.md — log source onboarding`
1. `threat-hunting-deep.md — proactive hunting program`
1. `security-metrics-deep.md — SOC performance metrics`

### Security program / CISO strategy

1. `security-leadership-deep.md — program building and board reporting`
1. `security-metrics-deep.md — KPIs and risk quantification`
1. `grc-risk-deep.md — risk management frameworks`
1. `compliance-frameworks-deep.md — regulatory requirements`

### Container / Kubernetes security

1. `kubernetes-attacks-deep.md — K8s attack paths, pod escapes, API server attacks`
1. `container-k8s-deep.md — full container security reference`
1. `hardening-guides-ultimate.md — CIS benchmarks for Docker/K8s`
1. `cloud-infra-deep.md — cloud-native security`
1. `devsecops-sdlc-deep.md — CI/CD pipeline scanning`

### Wireless / physical / IoT assessment

1. `wireless-physical-iot-deep.md — wireless and IoT attacks`
1. `ics-scada-deep.md — industrial control systems`
1. `network-attacks-deep.md — network-layer attacks`

### OSINT investigation

1. `osint-tradecraft-deep.md — OSINT methodology and tradecraft`
1. `recon-osint-deep.md — technical reconnaissance`
1. `privacy-osint-deep.md — OSINT with privacy constraints`
1. `social-engineering-deep.md — social media intelligence`

### Insider threat investigation

1. `insider-threat-dlp-deep.md — insider threat detection and DLP`
1. `dfir-hunting-deep.md — behavioral hunting`
1. `logging-monitoring-deep.md — user activity monitoring`
1. `forensics-artifacts-deep.md — evidence collection`

### ICS/SCADA security assessment

1. `ics-scada-deep.md — ICS/SCADA-specific attacks and defenses`
1. `wireless-physical-iot-deep.md — OT network attacks`
1. `network-protocol-deep.md — industrial protocols`
1. `incident-playbooks-deep.md — OT incident response`

### Mobile application pentest

1. `mobile-security-deep.md — mobile app testing methodology`
1. `api-exploitation-deep.md — backend API attacks`
1. `crypto-pki-tls-deep.md — certificate pinning bypass`
1. `identity-auth-deep.md — mobile auth flows`

### Blockchain / Web3 security audit

1. `blockchain-web3-deep.md — smart contract vulnerabilities`
1. `crypto-pki-tls-deep.md — cryptographic foundations`

### Preparing for security certification

1. `security-certifications-deep.md — cert study guides`
1. `security-mastery-deep.md — mastery-level knowledge`
1. `security-scenarios.md — practice scenarios`

### Startup security program from scratch

1. `startup-security-deep.md — phased security program for startups`
1. `security-leadership-deep.md — program building and board reporting`
1. `hardening-guides-ultimate.md — technical baseline controls`
1. `compliance-frameworks-deep.md — compliance readiness`
1. `incident-playbooks-deep.md — IR starter kit`

### Supply chain security / SBOM

1. `supply-chain-security-deep.md — SLSA, Sigstore, SBOM, binary authorization`
1. `devsecops-sdlc-deep.md — CI/CD pipeline security`
1. `container-k8s-deep.md — container supply chain`
1. `secure-coding-deep.md — dependency management`

### Forensic timeline reconstruction

1. `timeline-analysis-deep.md — Plaso, Timesketch, EZ tools, artifact correlation`
1. `forensics-artifacts-deep.md — artifact sources for timeline`
1. `dfir-hunting-deep.md — forensic hunting queries`
1. `windows-eventlog-mastery.md — Windows event log evidence`

### Windows event log analysis / audit policy

1. `windows-eventlog-mastery.md — complete event ID reference and audit policy`
1. `sigma-detection-deep.md — Sigma rules for Windows events`
1. `logging-monitoring-deep.md — log collection and forwarding`
1. `siem-soc-deep.md — SIEM query patterns for Windows events`

### EDR evaluation / bypass assessment

1. `edr-av-internals-deep.md — EDR architecture, hooks, bypass techniques`
1. `evasion-techniques-deep.md — defense evasion catalog`
1. `evasion-detection-catalog.md — technique-to-detection mapping`
1. `malware-re-evasion-deep.md — anti-analysis techniques`

### Microsoft 365 / Google Workspace email investigation

1. `email-forensics-deep.md — M365 and GWS email forensics`
1. `email-phishing-se-deep.md — phishing analysis`
1. `dns-email-infra-deep.md — SPF/DKIM/DMARC validation`
1. `incident-playbooks-deep.md — BEC IR playbook`

### Network protocol analysis

1. `network-protocol-deep.md — protocol internals`
1. `network-forensics-deep.md — PCAP analysis`
1. `network-attacks-deep.md — protocol exploitation`

### Credential theft / password audit

1. `password-credential-deep.md — credential attack catalog`
1. `active-directory-deep.md — AD credential attacks`
1. `identity-auth-deep.md — authentication weaknesses`

### Writing a pentest report

1. `pentest-reporting-deep.md — report structure and findings format`
1. `bugbounty-methodology-deep.md — disclosure and reporting`
1. `security-metrics-deep.md — risk scoring`

### Data exfiltration detection

1. `exfil-tunneling-deep.md — exfiltration techniques`
1. `insider-threat-dlp-deep.md — DLP controls`
1. `network-forensics-deep.md — network-level detection`
1. `dns-email-infra-deep.md — DNS exfil detection`

---

## Quick Stats

- **Documents**: 88 training files
- **Total lines**: 124,002
- **ATT&CK techniques mapped**: 557+ (Enterprise: 460+, ICS: 83, ATLAS: 14)
- **Security tools indexed**: 260+
- **Compliance frameworks**: 47+
- **OWASP resources**: 20
- **Security topics (A-Z)**: 280
- **Scenario routes**: 39

---

*This index is the key document for navigating the CIPHER training corpus. Use the scenario router for situation-based lookup, the topic finder for concept-based lookup, and the technique/tool/framework indexes for reference-based lookup.*
