# CIPHER Training — Wireless, Physical, IoT, and Hardware Security Deep Dive

> Integrated knowledge base covering wireless attack methodology, physical security bypass,
> IoT/embedded exploitation, hardware hacking, RF security, and ICS/SCADA attack surfaces.
> Compiled from primary tool documentation, curated resource lists, and framework references.

---

## Table of Contents

1. [Wireless Security — WiFi Attack Methodology](#1-wireless-security--wifi-attack-methodology)
2. [RF Security and Software Defined Radio](#2-rf-security-and-software-defined-radio)
3. [Bluetooth and Short-Range Wireless](#3-bluetooth-and-short-range-wireless)
4. [Physical Security — Locks, Bypass, and Access Control](#4-physical-security--locks-bypass-and-access-control)
5. [IoT Security — Attack Surface and Exploitation](#5-iot-security--attack-surface-and-exploitation)
6. [Hardware Hacking — Interfaces, Firmware, and Side Channels](#6-hardware-hacking--interfaces-firmware-and-side-channels)
7. [ICS/SCADA Security](#7-icsscada-security)
8. [MITRE ATT&CK for ICS — Complete Matrix](#8-mitre-attck-for-ics--complete-matrix)
9. [Anti-Tamper and Binary Hardening Patterns](#9-anti-tamper-and-binary-hardening-patterns)
10. [Tool Arsenal Reference](#10-tool-arsenal-reference)
11. [Detection Opportunities and Defensive Crosswalk](#11-detection-opportunities-and-defensive-crosswalk)

---

## 1. Wireless Security — WiFi Attack Methodology

### 1.1 Foundational Concepts

WiFi security testing targets the IEEE 802.11 protocol family across encryption standards: WEP (broken), WPA (deprecated), WPA2 (current target), and WPA3 (emerging). All attacks require a wireless adapter supporting **Monitor Mode** and **packet injection** — commodity hardware with Atheros (ath9k_htc), Ralink (rt2800usb), or Realtek (rtl8812au) chipsets.

**Key prerequisite**: Always confirm injection capability before attacking. `aireplay-ng -9 wlan0mon` validates injection works on the target interface.

### 1.2 Aircrack-ng Suite — Core Toolchain

The aircrack-ng suite is the foundational WiFi auditing toolkit. Components:

| Tool | Function |
|------|----------|
| `airmon-ng` | Enable/disable monitor mode on wireless interfaces |
| `airodump-ng` | Capture 802.11 frames, enumerate APs and clients |
| `aireplay-ng` | Packet injection: deauth, fake auth, ARP replay, chopchop, fragmentation |
| `aircrack-ng` | Offline WEP/WPA key cracking (dictionary and statistical) |
| `packetforge-ng` | Craft arbitrary encrypted packets for injection |
| `airdecap-ng` | Decrypt WEP/WPA capture files |
| `airbase-ng` | Create software access points (Evil Twin base) |
| `airtun-ng` | Virtual tunnel interface for encrypted traffic |

**Attack progression**: Monitor mode activation -> target enumeration -> handshake/IV capture -> offline cracking.

### 1.3 WEP Attacks (Legacy but Instructive)

WEP uses RC4 stream cipher with 24-bit IVs — fundamentally broken. Attack methods:

- **ARP Replay Attack**: Capture an ARP packet, replay it to generate IVs. ~40,000 IVs needed for 64-bit key, ~80,000 for 128-bit.
- **Chopchop Attack**: Decrypt a packet byte-by-byte without knowing the key. Produces a PRGA XOR file for packet forging.
- **Fragmentation Attack**: Obtain PRGA from a single data packet. Faster than chopchop but not universally supported.
- **Caffe-Latte Attack**: Attack client devices directly without AP proximity. Exploits gratuitous ARP from clients.
- **Hirte Attack**: Extension of Caffe-Latte using fragmented ARP request/reply.
- **PTW Attack** (Pyshkin-Tews-Weinmann): Statistical attack requiring as few as ~20,000 packets. Default in aircrack-ng.

### 1.4 WPA/WPA2 Attacks

WPA/WPA2 use PBKDF2-derived Pairwise Master Keys. Attack surface:

**4-Way Handshake Capture + Offline Crack**:
1. `airodump-ng -c <channel> --bssid <target> -w capture wlan0mon` — target and capture
2. `aireplay-ng -0 5 -a <bssid> -c <client> wlan0mon` — deauthenticate client to force reconnect
3. Capture EAPOL handshake (4 frames)
4. `aircrack-ng -w wordlist.txt capture-01.cap` — dictionary attack
5. GPU acceleration: `hashcat -m 22000 capture.hc22000 wordlist.txt`

**PMKID Attack** (clientless — no deauth required):
- Exploits PMKID field in the first EAPOL message from AP
- `hcxdumptool -i wlan0mon --enable_status=1 -o dump.pcapng` — capture PMKID
- `hcxpcapngtool -o hash.hc22000 dump.pcapng` — convert format
- `hashcat -m 22000 hash.hc22000 wordlist.txt` — crack offline
- Significance: No client needed, no deauth needed. Works against RSN (802.11i) networks.

**WPA3/SAE Considerations**:
- Simultaneous Authentication of Equals (SAE) replaces PSK exchange
- Dragonblood vulnerabilities (CVE-2019-9494 through CVE-2019-9499): side-channel leaks in SAE handshake
- Downgrade attacks: force WPA2 fallback via transition mode exploitation

### 1.5 WPS Attacks

Wi-Fi Protected Setup uses an 8-digit PIN (effectively 7 digits + checksum, split into two halves = 11,000 combinations max):

- **Online Brute Force**: `reaver -i wlan0mon -b <bssid> -vv` — enumerate all PIN combinations
- **Pixie Dust** (offline): `reaver -i wlan0mon -b <bssid> -K 1` — exploit weak random number generation in WPS nonces (E-S1, E-S2). Instant recovery on vulnerable implementations.
- **Bully**: Alternative WPS brute-forcer with different timing characteristics

### 1.6 Airgeddon — Integrated Attack Framework

Airgeddon (v11.61) is a Bash-based framework wrapping the above tools into a menu-driven workflow. Key capabilities:

- **Multi-standard attacks**: WEP, WPA, WPA2, WPA3
- **Evil Twin operations**: Rogue AP with captive portal for credential phishing
- **PMKID capture and cracking**: Clientless WPA2 attack automation
- **Handshake capture**: Automated deauth + capture + validation
- **WPS exploitation**: Both Pixie Dust and online brute force
- **Deauthentication floods**: Targeted and broadcast DoS
- **Integration layer**: Wraps aircrack-ng, hashcat, bettercap, BeEF, sslstrip
- **Docker deployment**: Containerized operation across Linux/macOS/Windows

### 1.7 Wifiphisher — Rogue AP + Social Engineering

Wifiphisher automates Evil Twin attacks with integrated phishing. Three association methods:

1. **Evil Twin**: Clone target AP SSID, deauth legitimate clients, capture on fake AP
2. **KARMA Attack**: Respond to all probe requests — impersonate any network clients seek
3. **Known Beacons**: Broadcast common SSIDs (xfinitywifi, attwifi, Starbucks, etc.) to attract auto-connecting clients

Built-in phishing scenarios:
- **Firmware Upgrade Page**: Fake router config page harvesting WPA/WPA2 PSK
- **Plugin Update**: Malicious executable distribution via fake browser update
- **OAuth Login**: Social media credential harvesting
- **WiFi Connect**: Network manager imitation capturing credentials

Technical requirements: Two wireless adapters (one for deauth/monitoring, one for rogue AP). Supports MAC randomization, channel tracking, and credential logging.

### 1.8 Wifite2 — Automated Attack Sequencing

Wifite2 orchestrates attack tools in optimal sequence without manual intervention:

**Attack priority chain**: PMKID capture -> WPS Pixie Dust -> WPS Online Brute Force -> WPA Handshake Capture -> WEP attacks

Key automation features:
- Auto-detects interfaces and monitor mode capabilities
- Sequential attack attempts with fallback progression
- Handshake validation against multiple tools (cowpatty, pyrit, tshark)
- Process lifecycle management — no orphaned background processes
- Credential storage with BSSID/SSID/timestamp metadata
- 5GHz support via `-5` flag
- Verbose mode (`-vvv`) shows all underlying commands for learning

### 1.9 Bettercap — Network Attack Framework

Bettercap (Go-based) provides comprehensive network and wireless attack capabilities:

**WiFi Module**:
- Network scanning and enumeration
- Deauthentication attacks
- Clientless PMKID association attacks
- Automatic WPA/WPA2/WPA3 handshake capture

**Network MITM**:
- ARP spoofing (IPv4), NDP spoofing (IPv6)
- DNS spoofing for phishing/redirection
- DHCPv6 spoofing
- HTTP/HTTPS proxying with JavaScript plugin injection
- SSL stripping

**Beyond WiFi**:
- BLE device scanning, characteristic enumeration, read/write operations
- 2.4GHz HID attacks (MouseJacking) with DuckyScript support
- CAN-bus frame decoding, injection, and fuzzing (automotive/ICS)
- REST API + WebSocket for programmatic control
- Web UI for interactive operation

### 1.10 Key Attack Patterns — Summary

| Attack | Encryption | Requires Client | Deauth Needed | Offline | Difficulty |
|--------|-----------|----------------|---------------|---------|------------|
| PTW/FMS | WEP | No (ARP replay) | Optional | Yes | Trivial |
| 4-Way Handshake | WPA/WPA2 | Yes | Yes | Yes | Medium |
| PMKID | WPA/WPA2 | No | No | Yes | Low |
| Pixie Dust | WPS | No | No | Yes | Low |
| WPS Brute Force | WPS | No | No | No | Medium (slow) |
| Evil Twin | Any | Yes (social eng) | Yes | No | Medium |
| KARMA | Any | Yes (auto-connect) | No | No | Low |
| Dragonblood | WPA3 | Yes | Varies | Yes | High |

---

## 2. RF Security and Software Defined Radio

### 2.1 HackRF One — SDR Platform

**Hardware Specifications**:
- Frequency range: 1 MHz to 6 GHz (covers nearly all consumer/industrial RF)
- Sample rate: 2 Msps to 20 Msps (quadrature)
- ADC resolution: 8-bit
- Duplex: Half-duplex transceiver (cannot TX and RX simultaneously)
- Antenna: SMA female (50 ohm)
- Interface: USB 2.0 High Speed (Micro-B)
- Power: USB bus powered
- Max RX input: -5 dBm (exceeding causes permanent damage)
- Max TX power: 0-15 dBm depending on frequency band (peaks 13-15 dBm at 2170-2740 MHz)
- Clock I/O: SMA connectors for external clock sync (multi-device coherent operation)
- Open-source hardware (GPL-2.0)

**Software Tools**:
- `hackrf_transfer` — Raw I/Q sample capture and playback
- `hackrf_sweep` — Wideband spectrum analysis
- `hackrf_info` — Device identification
- GNU Radio integration — Visual signal processing pipeline design
- `gqrx` — SDR receiver with waterfall display
- `inspectrum` — Signal analysis and demodulation
- `Universal Radio Hacker (URH)` — Protocol reverse engineering

**PortaPack**: Standalone add-on board enabling field-portable operation without a computer. LCD display + controls + battery for autonomous signal capture, replay, and analysis.

### 2.2 RFCat — Sub-GHz RF Testing

RFCat provides Python-based control of CC1111 (TI 8051-based) RF transceivers:

**Supported Hardware**: YARDStick One, cc1111emk, Chronos dongle

**Operating Band**: Sub-GHz ISM (typically 300 MHz - 928 MHz) — covers garage doors, car key fobs, wireless sensors, alarm systems, industrial telemetry

**Python API**:
```python
d = RfCat()
d.setFreq(433920000)       # 433.92 MHz
d.setMdmModulation(MOD_ASK_OOK)  # On-Off Keying
d.setMdmDRate(4800)        # 4800 baud
d.RFrecv()                 # Receive packets
d.RFxmit("\x55\xaa\x01")  # Transmit raw bytes
d.setChannel(0)
d.reprRadioConfig()        # Dump current radio config
```

**Security Testing Applications**:
- Capture and replay of fixed-code remotes (garage doors, gates)
- Protocol reverse engineering of proprietary wireless systems
- Rolling code analysis (KeeLoq, etc.)
- Z-Wave protocol security assessment
- Jamming detection and analysis
- Keyfob cloning (fixed code systems)

### 2.3 RF Attack Taxonomy

| Target | Frequency | Protocol | Attack Type |
|--------|-----------|----------|-------------|
| Garage doors | 300-400 MHz | OOK/ASK fixed code | Replay attack |
| Car key fobs (old) | 315/433 MHz | Fixed code | Replay/clone |
| Car key fobs (modern) | 315/433 MHz | Rolling code (KeeLoq) | RollJam, RollBack |
| TPMS sensors | 315/433 MHz | Proprietary | Spoof tire pressure |
| Smart meters | 900 MHz ISM | Zigbee/proprietary | Protocol injection |
| Baby monitors | 49 MHz / 900 MHz / 2.4 GHz | FM/FHSS | Eavesdropping |
| Wireless alarm sensors | 315/433 MHz | OOK/ASK | Replay/jam |
| DECT phones | 1880-1900 MHz | DECT | Eavesdropping (dedected) |
| Pagers | 150/450/900 MHz | POCSAG/FLEX | Passive interception (unencrypted) |
| ADS-B (aircraft) | 1090 MHz | ADS-B | Spoof position/altitude |
| Cellular | 700-2600 MHz | GSM/LTE | IMSI catching, downgrade |

### 2.4 RollJam Attack (Key Fobs)

Exploits rolling code systems (KeeLoq, etc.):
1. Jam the target receiver while capturing the first rolling code transmission
2. When user presses button again, jam and capture second code while replaying the first (user's door opens)
3. Attacker now holds a valid unused rolling code for future use
4. Requires simultaneous jam + capture + replay — Samy Kamkar's original implementation used two CC1111 transceivers

### 2.5 Flipper Zero — Multi-Protocol RF Tool

Consumer-accessible multi-tool covering:
- Sub-GHz TX/RX (300-928 MHz): capture, analyze, replay
- NFC: read/write/emulate (MIFARE, NTAG, etc.)
- RFID (125 kHz): read/write/emulate (EM4100, HID, Indala)
- Infrared: capture/replay (TV, AC, etc.)
- GPIO: UART, SPI, I2C interface access
- iButton: read/write/emulate (1-Wire)
- BadUSB: HID keyboard emulation (DuckyScript)
- Bluetooth: BLE scanning

---

## 3. Bluetooth and Short-Range Wireless

### 3.1 Bluetooth Classic Attacks

- **BlueSnarf**: Unauthorized access to information via OBEX push
- **BlueBug**: Full device control through AT command injection
- **BlueJack**: Unsolicited message injection via OBEX
- **KNOB Attack** (CVE-2019-9506): Negotiate minimum entropy encryption key (1 byte)
- **BIAS Attack** (CVE-2020-10135): Bypass authentication via role-switch during secure connection setup

**Tools**: `hcitool`, `sdptool`, `l2ping`, `spooftooph`, `bluesnarfer`, `btlejack`

### 3.2 BLE (Bluetooth Low Energy) Attacks

- **GATT enumeration**: Discover services, characteristics, and descriptors
- **Eavesdropping**: Sniff unencrypted BLE advertisements and connections (Ubertooth One)
- **MITM**: Relay and modify BLE connections (GATTacker)
- **Replay attacks**: Capture and replay authentication sequences
- **Fuzzing**: Malformed GATT requests against characteristic handlers

**Bettercap BLE module**: `ble.recon on`, `ble.enum <mac>`, `ble.write <mac> <handle> <data>`

### 3.3 Zigbee Attacks

- **KillerBee framework**: Zigbee packet capture, injection, replay, and key extraction
- **Network key sniffing**: If the network key is transmitted in the clear during device joining (default in many implementations), intercept it
- **Touchlink commissioning attack**: Force factory reset and re-join to attacker-controlled network
- **Tools**: ApiMote, Atmel RZUSBstick, KillerBee (zbdump, zbassocflood, zbgoodfind)

### 3.4 Z-Wave Attacks

- **S0 security**: AES-128 encrypted but key exchange uses a known temporary key (all zeros) — MITM during pairing captures the network key
- **S2 security**: Improved key exchange with ECDH, but downgrade attacks possible if S0 fallback accepted
- **Tools**: RFCat + Z-Wave firmware, EZ-Wave, Scapy-radio, OpenZWave

### 3.5 MouseJacking (2.4 GHz HID)

Exploits unencrypted wireless keyboards/mice using nRF24L01-based transceivers:
- Inject keystrokes into wireless keyboard/mouse dongles from up to 100m
- Supports DuckyScript payloads
- **Bettercap HID module**: Automated scanning and injection
- **Hardware**: CrazyRadio PA (nRF24LU1+ based)
- **Affected**: Logitech, Microsoft, Dell, HP, Lenovo wireless peripherals (pre-2016 models widely vulnerable)

---

## 4. Physical Security — Locks, Bypass, and Access Control

### 4.1 Lock Picking Fundamentals

Lock picking is the art of opening a lock without the original key and without destroying the lock. It is a core physical penetration testing skill.

**Pin Tumbler Lock Mechanics**:
- Driver pins and key pins sit in a cylinder (plug) within a housing (bible)
- Correct key aligns all pin stacks at the **shear line** between plug and housing
- Manufacturing tolerances mean pins bind in a predictable sequence when rotational tension is applied

**Core Techniques**:
- **Single Pin Picking (SPP)**: Apply light tension with a tension wrench, set each pin individually at the shear line by feel. Gold standard — works on high-security pins.
- **Raking**: Rapidly move a serrated pick through the keyway while applying variable tension. Fast but imprecise. Works on low-tolerance locks.
- **Rocking**: Variation of raking with a specific motion pattern (e.g., city rake / bogota)
- **Bumping**: Insert a specially cut bump key (all cuts at maximum depth), strike sharply while applying turning pressure. Pins jump to shear line momentarily.
- **Impressioning**: Insert blank key, apply rotational pressure, file where marks appear. Repeat until all pins marked and filed correctly. Non-destructive key creation.

**Security Pin Types** (defeat SPP):
- **Spool pins**: Narrow center section creates false set — counter by releasing tension slightly when false set detected
- **Serrated pins**: Multiple false sets from serrations — requires patience and fine tension control
- **Mushroom pins**: Combination of spool behavior with wider head

### 4.2 Bypass Techniques (Non-Pick)

| Technique | Target | Method |
|-----------|--------|--------|
| Shim attack | Padlocks | Insert shim between shackle and locking pawl |
| Comb pick | Pin tumbler | Bypass all pins simultaneously using toothed tool |
| Under-door tool | Lever handles | Insert tool under door gap to pull interior handle |
| Latch slipping | Spring latches | Credit card / traveler tool between latch and strike |
| Hinge removal | Outward-opening doors | Remove exposed hinge pins |
| Warded bypass | Warded locks | Skeleton key or warded pick passes wards directly |
| Decoding | Combination locks | Manipulate dial/wheels to determine combination |
| Destructive entry | Any | Drill, saw, pry — last resort |

### 4.3 Access Control System Attacks

**RFID/Proximity Card Cloning**:
- **125 kHz (HID Prox, EM4100, Indala)**: Trivially cloned with Proxmark3 or Flipper Zero. No encryption. Read range 1-10cm, but long-range readers extend to 30cm+.
  - `lf hid read` / `lf hid clone` (Proxmark3)
  - Many systems still deploy 125 kHz cards due to legacy infrastructure cost
- **13.56 MHz (MIFARE Classic)**: Crypto-1 encryption broken. Nested attack, hardnested attack, darkside attack recover sector keys.
  - `hf mf autopwn` (Proxmark3 — automated key recovery + dump)
  - MIFARE Classic 1K/4K widely deployed in transit, access control, payment
- **13.56 MHz (MIFARE DESFire, iCLASS SE)**: Significantly harder. DESFire EV2/EV3 uses AES-128. iCLASS SE uses secure elements. Attack surface shifts to reader/controller vulnerabilities.
- **UHF RFID (900 MHz)**: Long-range identification. Eavesdropping and cloning possible with SDR.

**Proxmark3**: The definitive RFID security research tool. Supports LF (125/134 kHz) and HF (13.56 MHz). Read, write, clone, emulate, sniff, and brute-force RFID credentials.

**Relay/Replay Attacks on Contactless Systems**:
- NFCGate (Android): Relay NFC communications over network
- Real-world: relay car key fob signal from house to car in driveway (SARA attack)
- Mitigation: distance bounding protocols, UWB ranging

### 4.4 Physical Penetration Testing Methodology

1. **Reconnaissance**: Perimeter survey, camera placement, guard patterns, badge types, tailgating opportunities, dumpster locations
2. **Social Engineering**: Pretexting (delivery, contractor, IT support), tailgating, badge cloning
3. **Entry**: Lock picking, bypass tools, RFID cloning, under-door tools, shimming
4. **Objective**: Plant implant devices (USB drops, network taps, rogue APs), access server rooms, photograph sensitive data
5. **Exfiltration**: Document findings, exit cleanly
6. **Reporting**: Detailed timeline, photos, access paths, recommendations

### 4.5 Key Resources — Physical Security

**Essential Books**:
- *Practical Lock Picking* — Deviant Ollam (2012): Professional physical security specialist's guide
- *Keys to the Kingdom* — Deviant Ollam (2012): Beyond locks — access control systems, bypass
- *Lock Picking: Detail Overkill* — Solomon: Deep technical reference
- *CIA Lock Picking Field Operative Training Manual*: Terminology, tools, techniques
- *The Use of Locks in Physical Crime Prevention* — Edgar & McInerey

**Training Resources**:
- MIT Lock Picking Guide (Ted the Tool): Classic introductory text
- LockLab University: Complete start-to-finish course
- Art of Lockpicking (artof-lockpicking.com): Animated technique demonstrations
- BosnianBill (YouTube): Extensive instructional series

**Organizations**:
- TOOOL (The Open Organization of Lockpickers): Worldwide chapters, training, competitions
- DEF CON Lockpicking Village: Annual competition and workshops
- OzSecCon: Physical security conference (Australia)

**Novel Research**:
- SpiKey: Acoustic-based physical key inference — infer key bitting from the sound of key insertion

**Vendor Tools**:
- Peterson, SouthOrd, Sparrows: Professional pick sets
- Sparrows King Pin: Pinning tweezers for practice lock configuration
- Practice locks with progressive pinning and cutaway views

---

## 5. IoT Security — Attack Surface and Exploitation

### 5.1 OWASP IoT Top 10 (2018)

| # | Vulnerability | Description | Impact |
|---|--------------|-------------|--------|
| I1 | Weak/Guessable/Hardcoded Credentials | Default passwords, backdoors in firmware, unchangeable credentials | Full device compromise |
| I2 | Insecure Network Services | Unnecessary open ports/services, especially Internet-exposed | RCE, DoS, data exfil |
| I3 | Insecure Ecosystem Interfaces | Vulnerable web/API/cloud/mobile interfaces | Account takeover, data breach |
| I4 | Lack of Secure Update Mechanism | No firmware validation, unencrypted delivery, no anti-rollback | Persistent compromise |
| I5 | Use of Insecure/Outdated Components | Deprecated libraries, vulnerable SoC, supply chain compromise | Inherited vulnerabilities |
| I6 | Insufficient Privacy Protection | PII exposure in storage/transit/processing | GDPR Art. 33 trigger, regulatory action |
| I7 | Insecure Data Transfer and Storage | Missing encryption for sensitive data at rest or in transit | Data breach, credential theft |
| I8 | Lack of Device Management | No asset tracking, update deployment, decommissioning, or monitoring | Unpatched fleet, shadow devices |
| I9 | Insecure Default Settings | Unsafe defaults, restricted user configuration options | Mass exploitation via defaults |
| I10 | Lack of Physical Hardening | Exposed debug ports, extractable storage, no tamper detection | Firmware extraction, key recovery |

### 5.2 IoT Attack Surface Map

```
                    ┌─────────────────────────┐
                    │      CLOUD BACKEND       │
                    │  (API, Data Store, OTA)   │
                    └──────────┬──────────────┘
                               │ TLS/MQTT/CoAP/HTTP
                    ┌──────────┴──────────────┐
                    │     NETWORK LAYER        │
                    │  (WiFi, Cellular, LoRa)  │
                    └──────────┬──────────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
     ┌────────┴───────┐ ┌─────┴──────┐ ┌───────┴───────┐
     │  MOBILE APP    │ │  GATEWAY/  │ │  IoT DEVICE   │
     │  (iOS/Android) │ │    HUB     │ │  (Endpoint)   │
     └────────────────┘ └────────────┘ └───────┬───────┘
                                               │
                                    ┌──────────┴──────────┐
                                    │  HARDWARE LAYER     │
                                    │  UART/JTAG/SPI/I2C  │
                                    │  Flash, EEPROM, MCU  │
                                    └─────────────────────┘
```

**Each layer is an attack surface**: cloud APIs (injection, auth bypass, IDOR), network protocols (MITM, replay, eavesdropping), mobile apps (reverse engineering, API key extraction), gateways (pivot point to local network), device firmware (hardcoded creds, command injection), hardware (debug port access, chip-off extraction).

### 5.3 Real-World IoT Vulnerabilities by Category

**Smart Home & Automation**:
- Belkin WeMo: Multiple authentication/access control flaws (IOActive)
- INSTEON Hub: No web/API authentication (TWSL2013-023)
- Google Nest: DFU mode root access exploitation
- Philips Hue: ZigBee protocol vulnerabilities enabling network-wide compromise
- Smart locks: Wireless authentication flaws demonstrated at CCC 33c3

**Cameras & Surveillance**:
- Trendnet: Default credentials, unencrypted feeds
- Samsung SmartCam: `install.php` remote root command execution
- IZON, Foscam, Y-Cam: Multiple CVEs — unauthorized access
- Mirai botnet: Mass IoT camera/DVR compromise for DDoS (Dyn attack, 2016)

**Medical Devices**:
- Pacemakers/implantable defibrillators: Wireless attacks enabling unauthorized device manipulation without physical access
- Insulin pumps: Wireless command injection (Billy Rios, 2015)
- Hospital networks: IoT devices as pivot points to clinical systems

**Transportation & Automotive**:
- Jeep Cherokee: Remote brake/steering manipulation via cellular connection (Charlie Miller & Chris Valasek, 2015)
- Traffic control systems: "Green Lights Forever" — signal manipulation via unencrypted protocols
- Parrot/DJI drones: Command hijacking via protocol interception, firmware extraction

**Children's Devices**:
- Hello Barbie: Unencrypted WiFi exposing voice data
- CloudPets: MongoDB exposure affecting child voice recordings
- Fisher-Price Smart Bear (CVE-2015-8269): Biographical data extraction
- Cayla Doll: Bluetooth eavesdropping — banned in Germany as unlawful surveillance device

**Appliances**:
- Samsung smart fridge: Compromised at DEF CON 23
- Smart coffee maker: Unencrypted protocol enabling remote operation (evilsocket)
- LIXIL Satis Toilet: Hard-coded Bluetooth PIN "0000" (TWSL2013-020)

### 5.4 IoT Firmware Analysis Methodology

The OWASP Firmware Security Testing Methodology (FSTM) defines nine stages:

1. **Information Gathering**: Identify chipset, SoC, architecture (ARM, MIPS, x86), OS (Linux, RTOS, bare-metal), publicly available firmware images, FCC filings (often contain internal photos)
2. **Firmware Acquisition**: Download from vendor, extract via debug port (UART bootloader), SPI flash dump, eMMC chip-off, OTA update interception
3. **Filesystem Extraction**: `binwalk -eM firmware.bin` — recursive extraction of squashfs, cramfs, jffs2, UBIFS. Identify init scripts, web servers, configuration files
4. **Static Analysis**: `strings`, `grep` for credentials, API keys, certificates. Analyze binary with Ghidra/IDA. Check for known CVEs in libraries (`libcurl`, `openssl`, `busybox`)
5. **Emulation**: `firmadyne` or `QEMU` user-mode/system-mode emulation. Run firmware without physical hardware for dynamic testing
6. **Dynamic Analysis**: GDB remote debugging, `strace`/`ltrace` system call monitoring, network traffic capture
7. **Runtime Analysis**: Interact with running services (web interfaces, MQTT brokers, telnet/SSH), API endpoint fuzzing
8. **Binary Exploitation**: Buffer overflows, format strings, command injection in CGI scripts, ROP chains on ARM/MIPS (no ASLR/NX on many embedded systems)
9. **Reporting**: Document all findings per OWASP finding format

**Key Tools**:
- `binwalk`: Firmware extraction and analysis
- `firmware-mod-kit`: Unpack, modify, repack firmware images
- `firmwalker`: Automated firmware filesystem analysis
- `Ghidra` / `IDA Pro`: Disassembly and decompilation
- `QEMU`: Cross-architecture emulation
- `firmadyne`: Automated firmware emulation platform
- `ByteSweep`: Automated pre-shipment firmware vulnerability scanning
- `IoTGoat`: Deliberately vulnerable firmware for training (OWASP)

### 5.5 IoT Protocol Attacks

| Protocol | Port | Attack Surface |
|----------|------|---------------|
| MQTT | 1883/8883 | Anonymous subscribe to `#` (all topics), inject commands, credential brute force |
| CoAP | 5683 | No authentication by default, observe resource changes, amplification for DDoS |
| UPnP/SSDP | 1900 | Device discovery, port mapping manipulation, SSRF via SUBSCRIBE callbacks |
| mDNS | 5353 | Service discovery, information disclosure |
| HTTP REST | 80/443 | Standard web vulnerabilities (SQLi, XSS, IDOR, auth bypass) |
| Telnet/SSH | 23/22 | Default credentials (admin:admin, root:root, admin:password) |
| AMQP | 5672 | Queue manipulation, unauthorized message consumption |
| TR-069 | 7547 | CPE WAN Management Protocol — RCE on ISP-managed devices (Mirai variant) |

---

## 6. Hardware Hacking — Interfaces, Firmware, and Side Channels

### 6.1 Hardware Interface Exploitation

#### UART (Universal Asynchronous Receiver/Transmitter)
- **What**: Serial debug console, typically 3.3V TTL. Often provides root shell or bootloader access.
- **Identification**: Look for 4-pin header (TX, RX, GND, VCC). Use multimeter for GND (continuity to ground plane), logic analyzer or oscilloscope for TX (data on boot).
- **Connection**: USB-to-UART adapter (FTDI FT232R, CP2102, CH340). `screen /dev/ttyUSB0 115200` or `minicom`
- **Exploitation**: Boot interrupt (U-Boot: press key during countdown), single-user mode, password bypass, environment variable modification (`setenv bootargs init=/bin/sh`)
- **Baud rate detection**: `baudrate.py` or manual oscilloscope measurement of bit width

#### JTAG (Joint Test Action Group / IEEE 1149.1)
- **What**: Debug interface for boundary scan, in-circuit debugging, flash programming
- **Identification**: Look for 10/14/20-pin header. Use JTAGulator or manual probing to identify TDI, TDO, TMS, TCK, TRST pins.
- **Connection**: J-Link, Bus Pirate, FT2232H, OpenOCD
- **Exploitation**: Full memory read/write, CPU halt/step, register access, firmware extraction, bypass secure boot by modifying boot sequence in RAM
- **OpenOCD commands**: `halt`, `mdw 0x00000000 256` (dump memory), `flash write_image firmware.bin 0x08000000`

#### SWD (Serial Wire Debug)
- **What**: ARM-specific two-wire debug protocol (SWDIO + SWCLK). Functionally equivalent to JTAG but fewer pins.
- **Tools**: ST-Link, J-Link, Black Magic Probe, DAPLink
- **Exploitation**: Same as JTAG — full debug access to ARM Cortex-M/A cores

#### SPI (Serial Peripheral Interface)
- **What**: Synchronous serial protocol for flash memory chips (MOSI, MISO, CLK, CS)
- **Extraction**: Connect SPI flash programmer (CH341A, Bus Pirate, Flashrom) to SOIC-8 chip. `flashrom -p ch341a_spi -r firmware_dump.bin`
- **In-circuit vs chip-off**: In-circuit reads while chip soldered (may have bus contention). Chip-off: desolder chip first (hot air rework station).

#### I2C (Inter-Integrated Circuit)
- **What**: Two-wire serial bus (SDA, SCL) for EEPROMs, sensors, configuration
- **Exploitation**: Read EEPROM contents (credentials, configuration, keys). Write modified data. `i2cdetect`, `i2cdump`, `i2cset` (Linux i2c-tools)

#### eMMC (Embedded MultiMediaCard)
- **What**: Embedded storage in smartphones, tablets, IoT devices
- **Extraction**: eMMC socket adapter or direct soldering to CMD, CLK, DAT0 lines. Read full NAND contents.
- **Tools**: Easy JTAG, Medusa Pro, or DIY eMMC-to-SD adapter

### 6.2 Side-Channel Attacks

**Power Analysis**:
- **SPA (Simple Power Analysis)**: Observe power consumption to identify operations (multiply vs. square in RSA reveals key bits)
- **DPA (Differential Power Analysis)**: Statistical correlation between power traces and intermediate cryptographic values. Recovers AES/DES keys.
- **CPA (Correlation Power Analysis)**: Refined DPA using Pearson correlation. Faster convergence.
- **Tool**: ChipWhisperer — open-source platform for power analysis and fault injection ($250-$1000)

**Electromagnetic Analysis**:
- **EMA**: Same principle as power analysis but uses EM probes near specific chip regions
- **TEMPEST**: Long-range EM emanation exploitation (reconstruct screen contents, keystrokes)

**Timing Attacks**:
- Compare execution time differences in cryptographic operations
- String comparison timing leaks in authentication code
- Cache-timing attacks (Spectre/Meltdown class)

### 6.3 Fault Injection

**Voltage Glitching**:
- Brief VCC drop causes CPU instruction skip or data corruption
- Bypass secure boot checks, code signing verification, password comparisons
- **ChipWhisperer**: Precise voltage glitch generation with configurable width/offset/repeat
- Common target: `if (check_signature()) { boot(); }` — glitch the comparison to skip the branch

**Clock Glitching**:
- Inject extra clock edges to cause instruction corruption
- Similar outcomes to voltage glitching but different physical mechanism

**Laser Fault Injection (LFI)**:
- Focused laser on decapped chip induces bit flips in specific registers/memory
- Used in smartcard and secure element attacks
- Requires chip decapsulation (fuming nitric acid or CNC milling)

**Electromagnetic Fault Injection (EMFI)**:
- EM pulse near chip surface induces faults without physical contact
- Less precise than LFI but doesn't require decapping

### 6.4 Hardware Pentesting Methodology

Reference: *Practical Hardware Pentesting* (Jean-Georges Valle, Packt)

**Target Platform**: STM32F103 (Bluepill board) — representative of real-world embedded targets

**Methodology**:
1. **Reconnaissance**: Visual inspection, component identification, IC markings, FCC ID lookup
2. **Interface Identification**: Locate UART, JTAG/SWD, SPI, I2C headers. Use multimeter, logic analyzer, JTAGulator
3. **Firmware Extraction**: Dump via debug interface or external flash programmer
4. **Reverse Engineering**: Ghidra 9.2+ for ARM binary analysis. Identify security functions, crypto implementations, authentication logic
5. **Vulnerability Analysis**: Hardcoded credentials, unprotected debug ports, missing read protection, insecure bootloader
6. **Exploitation**: Develop attack leveraging identified vulnerabilities
7. **Documentation**: Record attack path, tools, and remediation

**Essential Hardware Kit**:
- Multimeter (continuity, voltage measurement)
- Logic analyzer (Saleae Logic, cheap clones)
- Soldering station (fine pitch rework)
- Hot air rework station (chip removal)
- USB-to-UART adapters (FTDI, CP2102)
- SPI flash programmer (CH341A)
- JTAG/SWD debugger (J-Link, ST-Link, Bus Pirate)
- ChipWhisperer (side-channel / fault injection)
- Oscilloscope (signal analysis, timing)
- JTAGulator (automated pin identification)
- Proxmark3 (RFID/NFC)

---

## 7. ICS/SCADA Security

### 7.1 ICS Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│ LEVEL 4/5: Enterprise Network                       │
│   (ERP, Email, Internet, Business Systems)          │
├────────────────────┬────────────────────────────────┤
│ LEVEL 3.5: DMZ     │  Historian, Patch Server,      │
│                    │  Jump Host, AV Updates          │
├────────────────────┴────────────────────────────────┤
│ LEVEL 3: Site Operations                            │
│   (SCADA Server, HMI, Engineering Workstation)      │
├─────────────────────────────────────────────────────┤
│ LEVEL 2: Area Supervisory Control                   │
│   (HMI, Alarm/Event Server, OPC Server)             │
├─────────────────────────────────────────────────────┤
│ LEVEL 1: Basic Control                              │
│   (PLC, RTU, DCS Controllers, Safety Systems - SIS) │
├─────────────────────────────────────────────────────┤
│ LEVEL 0: Process (Physical)                         │
│   (Sensors, Actuators, Valves, Motors, Pumps)       │
└─────────────────────────────────────────────────────┘
```

**Purdue Model** defines network segmentation. Attacks that cross level boundaries (IT->OT) are the primary concern.

### 7.2 ICS Protocols and Attack Surfaces

| Protocol | Port | Auth | Encryption | Attack Surface |
|----------|------|------|------------|---------------|
| Modbus TCP | 502 | None | None | Read/write registers, coils. Full process control with no authentication. |
| Modbus RTU | Serial | None | None | Same as TCP but over RS-232/RS-485 serial |
| DNP3 (IEEE 1815) | 20000 | Optional (SA) | Optional | Point data manipulation, unsolicited response spoofing |
| S7comm | 102 | None | None | PLC program upload/download, CPU start/stop (Siemens) |
| EtherNet/IP (CIP) | 44818 | None | None | Tag read/write, controller configuration (Allen-Bradley) |
| OPC UA | 4840 | Yes | Yes (optional) | More secure successor to OPC DA. Certificate management issues. |
| OPC DA | DCOM | DCOM | None | Legacy Windows DCOM — full Windows attack surface |
| BACnet | 47808 | None | None | Building automation — read/write property values, device discovery |
| IEC 61850 (MMS) | 102 | None | None | Power grid substation automation — GOOSE message injection |
| IEC 60870-5-104 | 2404 | None | None | Power grid telecontrol — command injection |
| PROFINET | Various | None | None | Industrial Ethernet — device configuration, firmware upload |

**Critical observation**: Most ICS protocols were designed for reliability in air-gapped environments. They have **no authentication and no encryption** by design. Network segmentation is the primary security control.

### 7.3 ICS-Specific Attack Tools

| Tool | Purpose |
|------|---------|
| GRASSMARLIN | Passive ICS network topology mapping |
| Redpoint (Digital Bond) | Nmap NSE scripts for ICS device fingerprinting |
| smod | Modbus penetration testing framework |
| ISF (Industrial Exploitation Framework) | Exploit framework for PLCs (Siemens, Schneider, QNX) |
| PLCinject | Inject code into PLC programs |
| Snap7 | Siemens S7 PLC communication library |
| s7scan | Siemens PLC enumeration |
| ICSREF | CODESYS v2 binary reverse engineering |
| ICSFuzz | PLC vulnerability fuzzing |
| Conpot | ICS/SCADA honeypot |
| GRFICSv2 | 3D-visualized ICS simulation for attack practice |
| ControlThings Platform | Linux distro with integrated ICS assessment tools |

### 7.4 Notable ICS Incidents

| Incident | Year | Target | Impact | TTPs |
|----------|------|--------|--------|------|
| **Stuxnet** | 2010 | Iran uranium enrichment (Natanz) | Destroyed ~1,000 centrifuges | USB propagation, 4 zero-days, S7-315/417 PLC manipulation, PROFINET exploitation |
| **Ukraine Power Grid (BlackEnergy)** | 2015 | Ukrainian power distribution | 230,000 customers lost power | Spearphishing, BlackEnergy3 malware, HMI manipulation, KillDisk wiper |
| **Ukraine Power Grid (Industroyer/CrashOverride)** | 2016 | Ukrainian transmission substation | Power outage in Kyiv | IEC 61850, IEC 60870-5-104, OPC DA manipulation. First known malware using ICS protocols directly. |
| **TRITON/TRISIS/HatMan** | 2017 | Saudi Arabia petrochemical (Triconex SIS) | Attempted safety system disablement | Exploited engineering workstation, deployed custom RAT, injected SIS controller code. Could have caused physical destruction/casualties. |
| **Oldsmar Water Treatment** | 2021 | Florida water treatment | Attempted to raise NaOH to dangerous levels | Remote access via TeamViewer, HMI manipulation. Caught by operator. |
| **Colonial Pipeline** | 2021 | US fuel pipeline | 6-day shutdown, fuel shortages | DarkSide ransomware on IT side, OT shutdown as precaution |

### 7.5 ICS Defensive Standards

- **NIST SP 800-82 Rev. 2**: Guide to ICS Security — comprehensive framework
- **IEC 62443**: Industrial automation cybersecurity — defines Security Levels (SL1-4), zones, and conduits
- **NERC CIP**: Critical Infrastructure Protection for bulk electric systems — mandatory compliance
- **CIS Controls v7.1 ICS Companion**: Maps CIS Controls to ICS-specific implementations
- **ISA/IEC 62443-3-3**: System security requirements and security levels (target for certification)

### 7.6 ICS Honeypots and Training

- **Conpot**: Low-interaction ICS honeypot simulating Modbus, S7comm, IPMI, Guardian AST, HTTP
- **GasPot**: Veeder Root Guardian AST tank gauge simulator
- **GRFICSv2**: Unity 3D simulation with realistic process visualization — supports both offensive and defensive exercises
- **LICSTER**: Low-cost ICS testbed with real PLCs for hands-on training
- **T-Pot**: Multi-honeypot deployment (Docker) including ICS protocols

---

## 8. MITRE ATT&CK for ICS — Complete Matrix

### 8.1 Tactic Overview

The ICS ATT&CK matrix contains **12 tactics** with **94 techniques**, specifically modeling adversary behavior in industrial control system environments. Key differences from Enterprise ATT&CK:

- Techniques map to physical process impact (not just data/system compromise)
- Impact tactics include safety and operational consequences
- "Inhibit Response Function" tactic is ICS-specific — preventing operator response
- "Impair Process Control" directly targets physical process integrity

### 8.2 Complete Technique Reference

**Initial Access (12 techniques)**:
T0817 Drive-by Compromise, T0819 Exploit Public-Facing Application, T0866 Exploitation of Remote Services, T0822 External Remote Services, T0883 Internet Accessible Device, T0886 Remote Services, T0847 Replication Through Removable Media, T0848 Rogue Master, T0865 Spearphishing Attachment, T0862 Supply Chain Compromise, T0864 Transient Cyber Asset, T0860 Wireless Compromise

**Execution (10)**:
T0895 Autorun Image, T0858 Change Operating Mode, T0807 Command-Line Interface, T0871 Execution through API, T0823 Graphical User Interface, T0874 Hooking, T0821 Modify Controller Tasking, T0834 Native API, T0853 Scripting, T0863 User Execution

**Persistence (6)**:
T0891 Hardcoded Credentials, T0889 Modify Program, T0839 Module Firmware, T0873 Project File Infection, T0857 System Firmware, T0859 Valid Accounts

**Privilege Escalation (2)**:
T0890 Exploitation for Privilege Escalation, T0874 Hooking

**Evasion (7)**:
T0858 Change Operating Mode, T0820 Exploitation for Evasion, T0872 Indicator Removal on Host, T0849 Masquerading, T0851 Rootkit, T0856 Spoof Reporting Message, T0894 System Binary Proxy Execution

**Discovery (5)**:
T0840 Network Connection Enumeration, T0842 Network Sniffing, T0846 Remote System Discovery, T0888 Remote System Information Discovery, T0887 Wireless Sniffing

**Lateral Movement (7)**:
T0812 Default Credentials, T0866 Exploitation of Remote Services, T0891 Hardcoded Credentials, T0867 Lateral Tool Transfer, T0843 Program Download, T0886 Remote Services, T0859 Valid Accounts

**Collection (11)**:
T0830 Adversary-in-the-Middle, T0802 Automated Collection, T0811 Data from Information Repositories, T0893 Data from Local System, T0868 Detect Operating Mode, T0877 I/O Image, T0801 Monitor Process State, T0861 Point & Tag Identification, T0845 Program Upload, T0852 Screen Capture, T0887 Wireless Sniffing

**Command and Control (3)**:
T0885 Commonly Used Port, T0884 Connection Proxy, T0869 Standard Application Layer Protocol

**Inhibit Response Function (14)**:
T0800 Activate Firmware Update Mode, T0878 Alarm Suppression, T0803 Block Command Message, T0804 Block Reporting Message, T0805 Block Serial COM, T0892 Change Credential, T0809 Data Destruction, T0814 Denial of Service, T0816 Device Restart/Shutdown, T0835 Manipulate I/O Image, T0838 Modify Alarm Settings, T0851 Rootkit, T0881 Service Stop, T0857 System Firmware

**Impair Process Control (5)**:
T0806 Brute Force I/O, T0836 Modify Parameter, T0839 Module Firmware, T0856 Spoof Reporting Message, T0855 Unauthorized Command Message

**Impact (12)**:
T0879 Damage to Property, T0813 Denial of Control, T0815 Denial of View, T0826 Loss of Availability, T0827 Loss of Control, T0828 Loss of Productivity and Revenue, T0837 Loss of Protection, T0880 Loss of Safety, T0829 Loss of View, T0831 Manipulation of Control, T0832 Manipulation of View, T0882 Theft of Operational Information

### 8.3 ICS Kill Chain Mapping

```
IT Compromise → OT Reconnaissance → OT Access → OT Manipulation → Physical Impact

Stage 1 (IT): Spearphishing → Establish C2 → Lateral movement → Reach IT/OT boundary
Stage 2 (OT): Cross DMZ → Discover ICS assets → Understand process → Deploy ICS-specific tools
Stage 3 (Impact): Modify PLC logic / HMI display / Safety systems → Cause physical consequence
```

TRITON exemplifies the complete kill chain: IT compromise → engineering workstation access → SIS controller manipulation → attempted safety system disable.

---

## 9. Anti-Tamper and Binary Hardening Patterns

Derived from game security anti-cheat research — these patterns translate directly to anti-tamper protections on IoT/embedded firmware and security-critical software.

### 9.1 Anti-Tamper Techniques (Offense Perspective)

| Protection | Bypass Approach |
|-----------|----------------|
| **Code integrity checks** (hash verification) | Patch the check, return valid hash, hook the hashing function |
| **Debug detection** (IsDebuggerPresent, ptrace check) | Patch detection, use hardware breakpoints, kernel-level debugging |
| **Timing checks** (rdtsc, QueryPerformanceCounter) | Hook timing functions, run at native speed between checks |
| **Memory scanning** (signature-based detection) | Polymorphic code, encrypt payloads, allocate outside scanned regions |
| **Import table obfuscation** | Dynamic resolution via GetProcAddress/dlsym, manual PE/ELF mapping |
| **Code virtualization** (VMProtect, Themida) | Trace VM handler dispatch, identify virtual opcodes, devirtualize |
| **Hypervisor-based protection** | Hardware-level debugging (JTAG/ICE), pre-hypervisor execution |
| **Driver-level enforcement** (kernel anti-cheat) | Vulnerable driver exploitation, BYOVD, hypervisor-based evasion |
| **Certificate/signature pinning** | Patch verification, inject trusted cert, MITM with custom CA |
| **Secure boot chain** | Voltage glitch boot ROM, exploit bootloader vulnerabilities |

### 9.2 Relevance to IoT/Hardware

Game anti-cheat and IoT anti-tamper share the same fundamental problem: **protecting code running on hardware the adversary physically controls**. Solutions that work in one domain transfer directly:

- Secure boot bypass (game consoles / IoT devices) uses the same fault injection techniques
- Code signing bypass (game mods / firmware modification) uses the same certificate attacks
- Memory protection bypass (anti-cheat / secure enclave) uses the same debug interface exploits
- Integrity verification bypass (anti-tamper / firmware validation) uses the same hooking techniques

---

## 10. Tool Arsenal Reference

### 10.1 Wireless Tools

| Tool | Type | Target | Key Feature |
|------|------|--------|-------------|
| aircrack-ng suite | WiFi | WEP/WPA/WPA2 | Industry standard, statistical + dictionary attacks |
| airgeddon | WiFi | All standards | Menu-driven framework, integrates multiple tools |
| wifiphisher | WiFi | Social engineering | Evil Twin + phishing scenarios |
| wifite2 | WiFi | WEP/WPA/WPA2/WPS | Fully automated attack sequencing |
| bettercap | Multi | WiFi/BLE/HID/Network | Swiss army knife — MITM, spoofing, injection |
| kismet | WiFi/BLE/RF | Passive recon | Wireless IDS, device fingerprinting |
| hostapd-mana | WiFi | Evil Twin/KARMA | Advanced rogue AP with KARMA/loud KARMA |
| eaphammer | WiFi | WPA Enterprise | Evil Twin for 802.1X networks, credential capture |
| hashcat | Cracking | WPA/WPA2/PMKID | GPU-accelerated offline password cracking |
| hcxtools | WiFi | PMKID/handshake | Capture and convert PMKID/handshake formats |

### 10.2 RF and SDR Tools

| Tool | Hardware | Frequency | Use Case |
|------|----------|-----------|----------|
| HackRF One | HackRF | 1 MHz - 6 GHz | Wideband TX/RX, protocol analysis |
| RTL-SDR | RTL2832U | 24 MHz - 1.7 GHz | Cheap RX-only — scanning, monitoring |
| YARDStick One | CC1111 | Sub-GHz ISM | Sub-GHz TX/RX, keyfob attacks |
| RFCat | CC1111 | Sub-GHz ISM | Python API for RF research |
| Flipper Zero | Multi | Sub-GHz/NFC/RFID/IR | Multi-protocol portable tool |
| Ubertooth One | Custom | 2.4 GHz | Bluetooth sniffing and injection |
| CrazyRadio PA | nRF24LU1+ | 2.4 GHz | MouseJacking, nRF protocol research |
| GNU Radio | Software | Any (SDR-dependent) | Visual signal processing framework |
| Universal Radio Hacker | Software | Any | Protocol reverse engineering GUI |
| GQRX | Software | Any | SDR receiver with waterfall display |

### 10.3 Hardware Hacking Tools

| Tool | Function | Price Range |
|------|----------|-------------|
| Bus Pirate | Multi-protocol (UART/SPI/I2C/JTAG) interface | $30 |
| Proxmark3 | RFID/NFC read/write/clone/emulate/sniff | $60-300 |
| JTAGulator | Automated JTAG/UART pin identification | $150 |
| ChipWhisperer | Side-channel analysis + fault injection | $250-1000 |
| Saleae Logic | Logic analyzer (8-16 channels) | $400-1500 |
| J-Link | JTAG/SWD debugger (ARM) | $20-500 |
| ST-Link | STM32 SWD debugger | $5-25 |
| CH341A | SPI flash programmer | $5 |
| FT232H | USB to UART/SPI/I2C/JTAG | $15 |
| DSLogic | Open-source logic analyzer | $70-150 |
| Glasgow | Open-source multi-tool (JTAG/SPI/I2C/UART) | $80 |

### 10.4 ICS/SCADA Tools

| Tool | Function |
|------|----------|
| GRASSMARLIN | Passive ICS network topology mapping |
| Redpoint | Nmap NSE scripts for ICS fingerprinting |
| smod | Modbus penetration testing framework |
| ISF | ICS exploitation framework |
| Conpot | ICS honeypot (Modbus, S7comm, IPMI) |
| GRFICSv2 | 3D ICS simulation for training |
| CSET | CISA cybersecurity evaluation tool |
| Snap7 | Siemens S7 communication library |
| OpenDNP3 | DNP3 protocol implementation |

### 10.5 Hak5 Physical Implant Devices

| Device | Function | Attack Vector |
|--------|----------|--------------|
| USB Rubber Ducky | Keystroke injection via HID emulation | Physical USB access — executes DuckyScript payloads as keyboard input |
| Bash Bunny | Multi-function USB attack (HID + storage + Ethernet) | Physical USB — credential harvesting, exfiltration, network attacks |
| WiFi Pineapple | Rogue AP / Evil Twin / KARMA | Wireless MITM, credential capture, traffic interception |
| LAN Turtle | Covert network implant (USB Ethernet) | Physical network — persistent backdoor, DNS spoofing, VPN tunnel |
| Packet Squirrel | Inline network implant | Physical network tap — MITM, packet capture, VPN tunnel |
| Shark Jack | Portable network attack tool | Physical Ethernet — automated recon, payload delivery |
| Key Croc | Keylogger with WiFi exfiltration | Physical keyboard interception — captures keystrokes, triggers payloads |
| Screen Crab | HDMI interception and streaming | Physical display tap — captures screen output |
| O.MG Cable | Malicious USB cable with WiFi C2 | Physical USB — looks like normal cable, provides remote shell and HID injection |

---

## 11. Detection Opportunities and Defensive Crosswalk

### 11.1 Wireless Attack Detection

| Attack | Detection Method | Data Source |
|--------|-----------------|-------------|
| Deauthentication flood | High volume of deauth/disassoc frames | WIDS (Wireless IDS), Kismet |
| Evil Twin / Rogue AP | Duplicate SSID with different BSSID/channel | WIDS, 802.11 monitoring |
| KARMA attack | AP responding to probe requests for non-matching SSIDs | WIDS |
| WPS brute force | Repeated WPS authentication failures | AP logs, WIDS |
| PMKID capture | Unusual association behavior without completing handshake | Deep packet inspection |
| Client deauth for handshake | Targeted deauth followed by immediate re-association | WIDS correlation |

**Key defensive controls**:
- 802.11w (Management Frame Protection) prevents deauth attacks
- WPA3-SAE eliminates offline dictionary attacks
- Disable WPS on all access points
- Deploy WIDS (Cisco Adaptive wIPS, Aruba RFProtect, open-source: Kismet)
- MAC address monitoring for rogue AP detection
- NAC (802.1X) with certificate-based authentication

### 11.2 IoT/Hardware Attack Detection

| Attack | Detection Indicator |
|--------|-------------------|
| Firmware extraction via UART/JTAG | Physical inspection, tamper-evident seals, debug port disabled in production |
| Network-based IoT exploit | IDS signatures for known IoT CVEs, anomalous protocol behavior |
| Default credential brute force | Authentication failure logs, rate limiting |
| MQTT unauthorized access | Monitor MQTT broker for subscribe to `#`, unknown client IDs |
| OTA update interception | Certificate pinning, code signing verification |
| Side-channel attack | Tamper detection circuits, voltage/clock monitoring, EM shielding |

### 11.3 ICS Attack Detection

| Indicator | Detection | Tool/Source |
|-----------|-----------|-------------|
| Unauthorized PLC program change | Monitor for program download commands | ICS protocol DPI, Claroty, Dragos |
| Modbus write to critical registers | Whitelist expected register write patterns | Suricata ICS rules, Zeek/Bro |
| S7comm CPU stop command | Alert on CPU mode changes | S7Comm-Analyzer (Zeek plugin) |
| HMI access from IT network | Cross-zone traffic monitoring | Firewall logs, network segmentation monitoring |
| Engineering workstation anomaly | Baseline normal behavior, detect deviations | EDR on engineering workstations |
| Safety system modification | Dedicated SIS network monitoring | Nozomi Networks, Claroty |
| Historian data anomaly | Process data integrity monitoring | Statistical analysis, digital twin comparison |

### 11.4 Sigma Detection Rule Patterns

**WiFi Deauthentication Attack**:
```yaml
title: Wireless Deauthentication Flood Detected
id: a3c2d8e1-5f7b-4c9a-b6d2-8e4f1a3c5b7d
status: experimental
description: Detects high volume of 802.11 deauthentication frames indicating wireless DoS or handshake capture attack
logsource:
  category: wireless
  product: wids
detection:
  selection:
    frame_type: management
    frame_subtype: deauthentication
  condition: selection | count() > 50 within 60s
falsepositives:
  - Legitimate AP channel changes causing mass client disconnection
  - AP firmware updates triggering client reassociation
level: high
tags:
  - attack.t0860
  - attack.initial_access
```

**Unauthorized Modbus Write**:
```yaml
title: Modbus Write to Critical Process Register
id: b4d3e9f2-6a8c-4d0b-c7e3-9f5a2b4d6c8e
status: experimental
description: Detects Modbus write function codes to registers outside normal operational patterns
logsource:
  category: network
  product: ics
detection:
  selection:
    protocol: modbus
    function_code:
      - 5   # Write Single Coil
      - 6   # Write Single Register
      - 15  # Write Multiple Coils
      - 16  # Write Multiple Registers
  filter:
    source_ip|cidr: '10.10.0.0/24'  # Authorized engineering subnet
  condition: selection and not filter
falsepositives:
  - Authorized maintenance window PLC programming
  - Batch recipe changes from MES system
level: critical
tags:
  - attack.t0855
  - attack.impair_process_control
```

---

## Source Attribution

| Source | Type | Key Content |
|--------|------|-------------|
| aircrack-ng.org/getting_started | Documentation | WiFi attack methodology fundamentals |
| github.com/v1s1t0r1sh3r3/airgeddon | Tool | Integrated wireless auditing framework |
| github.com/wifiphisher/wifiphisher | Tool | Evil Twin + phishing attack framework |
| github.com/derv82/wifite2 | Tool | Automated WiFi attack sequencing |
| github.com/bettercap/bettercap | Tool | Network/WiFi/BLE/HID attack framework |
| github.com/hak5 | Organization | Physical implant device ecosystem |
| github.com/atlas0fd00m/rfcat | Tool | Sub-GHz RF security testing (CC1111) |
| github.com/greatscottgadgets/hackrf | Hardware | SDR platform (1 MHz - 6 GHz) |
| hackrf.readthedocs.io | Documentation | HackRF One technical specifications |
| owasp.org/www-project-internet-of-things | Framework | IoT Top 10, FSTM, IoTGoat |
| github.com/nebgnahz/awesome-iot-hacks | Curated list | Real-world IoT vulnerability catalog |
| github.com/V33RU/IoTSecurity101 | Learning path | IoT security methodology and tools |
| github.com/PacktPublishing/Practical-Hardware-Pentesting | Book code | STM32-based hardware pentesting |
| github.com/hslatman/awesome-industrial-control-system-security | Curated list | ICS tools, standards, training |
| attack.mitre.org/matrices/ics | Framework | Complete ICS ATT&CK matrix (94 techniques) |
| awesome-lockpicking (local zip) | Curated list | Physical security resources and techniques |
| awesome-game-security (local zip) | N/A | File was empty/corrupt — content reconstructed from domain knowledge |
