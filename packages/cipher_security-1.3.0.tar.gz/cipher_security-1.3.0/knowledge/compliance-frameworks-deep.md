# CIPHER Compliance Frameworks Deep Reference

> Training material for architecture reviews, risk assessments, and compliance gap analysis.
> Last updated: 2026-03-14

---

## Table of Contents

1. [NIST Cybersecurity Framework (CSF) 2.0](#1-nist-cybersecurity-framework-csf-20)
2. [NIST SP 800-53 Rev 5](#2-nist-sp-800-53-rev-5)
3. [NIST SP 800-171 (CUI Protection)](#3-nist-sp-800-171-cui-protection)
4. [NIST Risk Management Framework (RMF)](#4-nist-risk-management-framework-rmf)
5. [OWASP ASVS](#5-owasp-asvs)
6. [OWASP MASVS](#6-owasp-masvs)
7. [CIS Controls & Benchmarks](#7-cis-controls--benchmarks)
8. [GDPR](#8-gdpr)
9. [HIPAA Security Rule](#9-hipaa-security-rule)
10. [PCI DSS v4.0](#10-pci-dss-v40)
11. [SOC 2](#11-soc-2)
12. [ISO/IEC 27001:2022](#12-isoiec-270012022)
13. [FedRAMP](#13-fedramp)
14. [Cross-Framework Mappings](#14-cross-framework-mappings)
15. [Practical Implementation Guidance](#15-practical-implementation-guidance)

---

## 1. NIST Cybersecurity Framework (CSF) 2.0

**Authority**: National Institute of Standards and Technology (NIST)
**Current version**: CSF 2.0 (February 2024) — NIST.CSWP.29
**Applicability**: All organizations regardless of size, sector, or maturity
**Key change from 1.1**: Added GOVERN function; expanded scope beyond critical infrastructure

### Six Core Functions

#### GV — GOVERN (New in 2.0)
Establishes and monitors cybersecurity risk management strategy, expectations, and policy. This function elevates governance from implicit background to explicit first-class concern.

| Category | Description |
|----------|-------------|
| GV.OC | Organizational Context — mission, stakeholder expectations, legal/regulatory requirements |
| GV.RM | Risk Management Strategy — priorities, constraints, risk tolerance, risk appetite statements |
| GV.RR | Roles, Responsibilities, and Authorities — accountability for cybersecurity across org |
| GV.PO | Policy — organizational cybersecurity policy established, communicated, enforced |
| GV.OV | Oversight — governance process results inform and adjust risk management strategy |
| GV.SC | Cybersecurity Supply Chain Risk Management — supply chain risks identified, managed |

#### ID — IDENTIFY
Understand organizational context, assets, risks, and improvement opportunities.

| Category | Description |
|----------|-------------|
| ID.AM | Asset Management — hardware, software, data, systems inventoried and managed |
| ID.RA | Risk Assessment — threats, vulnerabilities, likelihood, impact understood |
| ID.IM | Improvement — improvements identified from evaluations, exercises, reviews |

#### PR — PROTECT
Safeguards to manage cybersecurity risks.

| Category | Description |
|----------|-------------|
| PR.AA | Identity Management, Authentication, and Access Control |
| PR.AT | Awareness and Training — personnel informed and trained |
| PR.DS | Data Security — data managed per risk strategy (confidentiality, integrity, availability) |
| PR.PS | Platform Security — hardware, software, services managed per risk strategy |
| PR.IR | Technology Infrastructure Resilience — architectures managed for security and resilience |

#### DE — DETECT
Find and analyze possible cybersecurity attacks and compromises.

| Category | Description |
|----------|-------------|
| DE.CM | Continuous Monitoring — assets monitored for anomalies, IOCs, adverse events |
| DE.AE | Adverse Event Analysis — anomalies analyzed, characterized, triaged |

#### RS — RESPOND
Take action regarding a detected cybersecurity incident.

| Category | Description |
|----------|-------------|
| RS.MA | Incident Management — responses managed, coordinated with stakeholders |
| RS.AN | Incident Analysis — investigation conducted to support response and recovery |
| RS.CO | Incident Response Reporting and Communication — response activities coordinated |
| RS.MI | Incident Mitigation — activities performed to contain and mitigate incident |

#### RC — RECOVER
Restore assets and operations affected by a cybersecurity incident.

| Category | Description |
|----------|-------------|
| RC.RP | Incident Recovery Plan Execution — recovery activities performed |
| RC.CO | Incident Recovery Communication — restoration activities coordinated |

### Implementation Tiers

| Tier | Name | Characteristics |
|------|------|-----------------|
| Tier 1 | Partial | Ad hoc, reactive, limited awareness of risk |
| Tier 2 | Risk Informed | Risk-aware but not org-wide policy, some processes |
| Tier 3 | Repeatable | Formally approved policies, regularly updated practices |
| Tier 4 | Adaptive | Continuously improving, agile response, lessons learned integrated |

### Framework Profiles
- **Current Profile**: describes current cybersecurity posture
- **Target Profile**: describes desired future state
- **Gap Analysis**: difference between current and target drives prioritized roadmap
- **Community Profiles**: sector-specific profiles (e.g., AI, manufacturing, healthcare)

---

## 2. NIST SP 800-53 Rev 5

**Authority**: NIST
**Current version**: Rev 5 (September 2020), updated December 2020
**Applicability**: Federal information systems; widely adopted by private sector
**Total controls**: ~1,000+ controls and control enhancements across 20 families

### Control Families

| ID | Family Name | Key Focus Areas | Notable Controls |
|----|------------|-----------------|------------------|
| AC | Access Control | Account management, access enforcement, separation of duties, least privilege, session controls, remote access | AC-2 (Account Mgmt), AC-3 (Access Enforcement), AC-6 (Least Privilege), AC-17 (Remote Access) |
| AT | Awareness and Training | Security literacy, role-based training, social engineering awareness | AT-2 (Literacy Training), AT-3 (Role-Based Training) |
| AU | Audit and Accountability | Audit events, content, storage, review, analysis, reporting, non-repudiation | AU-2 (Event Logging), AU-6 (Audit Review/Analysis), AU-12 (Audit Record Generation) |
| CA | Assessment, Authorization and Monitoring | Security assessments, system interconnections, continuous monitoring, penetration testing | CA-2 (Assessments), CA-7 (Continuous Monitoring), CA-8 (Penetration Testing) |
| CM | Configuration Management | Baseline config, change control, least functionality, software restrictions | CM-2 (Baseline Config), CM-6 (Config Settings), CM-7 (Least Functionality), CM-8 (System Inventory) |
| CP | Contingency Planning | Contingency plan, testing, alternate sites, backup, recovery | CP-2 (Contingency Plan), CP-9 (System Backup), CP-10 (Recovery/Reconstitution) |
| IA | Identification and Authentication | User/device identification, authenticator management, MFA, cryptographic modules | IA-2 (User ID/Auth), IA-5 (Authenticator Mgmt), IA-8 (Non-Org Users) |
| IR | Incident Response | IR planning, training, testing, handling, monitoring, reporting | IR-2 (IR Training), IR-4 (Incident Handling), IR-6 (Incident Reporting), IR-8 (IR Plan) |
| MA | Maintenance | Controlled maintenance, tools, nonlocal maintenance, personnel | MA-2 (Controlled Maintenance), MA-4 (Nonlocal Maintenance) |
| MP | Media Protection | Media access, marking, storage, transport, sanitization | MP-2 (Media Access), MP-6 (Media Sanitization) |
| PE | Physical and Environmental Protection | Physical access authorizations, monitoring, emergency shutoff, power, fire protection | PE-2 (Physical Access Auth), PE-3 (Physical Access Control), PE-6 (Monitoring) |
| PL | Planning | Security/privacy plans, rules of behavior, system architecture | PL-2 (System Security Plans), PL-4 (Rules of Behavior) |
| PM | Program Management | InfoSec program plan, risk management strategy, insider threat program, enterprise architecture | PM-1 (InfoSec Program Plan), PM-9 (Risk Mgmt Strategy), PM-11 (Mission/Business Planning) |
| PS | Personnel Security | Position risk designation, screening, termination, transfer, access agreements | PS-2 (Position Risk Designation), PS-3 (Personnel Screening), PS-4 (Termination) |
| PT | PII Processing and Transparency | Authority to process PII, consent, privacy notices, data quality, minimization | PT-2 (Authority to Process PII), PT-3 (Consent), PT-4 (Privacy Notices) |
| RA | Risk Assessment | Security categorization, risk assessment, vulnerability monitoring and scanning | RA-3 (Risk Assessment), RA-5 (Vulnerability Monitoring/Scanning) |
| SA | System and Services Acquisition | SDLC, acquisition process, system documentation, supply chain protections, developer security testing | SA-3 (SDLC), SA-8 (Security Engineering Principles), SA-11 (Developer Testing) |
| SC | System and Communications Protection | App partitioning, boundary protection, transmission confidentiality/integrity, cryptographic protection | SC-7 (Boundary Protection), SC-8 (Transmission Confidentiality), SC-13 (Cryptographic Protection), SC-28 (Protection at Rest) |
| SI | System and Information Integrity | Flaw remediation, malicious code protection, security alerts, software integrity, spam protection | SI-2 (Flaw Remediation), SI-3 (Malicious Code Protection), SI-4 (System Monitoring), SI-7 (Software Integrity) |
| SR | Supply Chain Risk Management | SCRM plan, acquisition controls, supply chain controls, component authenticity, provenance | SR-1 (SCRM Policy), SR-3 (Supply Chain Controls), SR-11 (Component Authenticity) |

### Control Baselines (from SP 800-53B)

| Impact Level | Description | Approximate Control Count |
|-------------|-------------|--------------------------|
| Low | Minimal adverse effect | ~130 controls |
| Moderate | Serious adverse effect | ~325 controls |
| High | Severe or catastrophic adverse effect | ~420 controls |

### Key Concepts
- **Control Enhancements**: numbered extensions that add specificity (e.g., AC-2(1), AC-2(2))
- **Tailoring**: organizations select, supplement, and adjust baselines per risk assessment
- **Overlays**: specialized control sets for specific communities/technologies (e.g., classified systems, cloud)
- **Rev 5 changes**: consolidated security and privacy controls; added PT and SR families; outcome-based language; removed "federal" from control text for broader applicability

---

## 3. NIST SP 800-171 (CUI Protection)

**Authority**: NIST
**Current version**: Rev 3 (May 2024); Rev 2 widely deployed
**Applicability**: Nonfederal organizations handling Controlled Unclassified Information (CUI)
**CMMC alignment**: Direct basis for CMMC Level 2

### Control Families (14 families, 110 requirements in Rev 2)

| Family | # of Requirements (Rev 2) | Key Requirements |
|--------|--------------------------|------------------|
| Access Control | 22 | Limit system access to authorized users; control CUI flow; separate duties; employ least privilege; limit unsuccessful logon attempts; session lock; remote access control |
| Awareness and Training | 3 | Security awareness training; role-based training for CUI handling; insider threat awareness |
| Audit and Accountability | 9 | Create/retain audit logs; ensure individual accountability; correlate audit review; protect audit info; system time synchronization |
| Configuration Management | 9 | Establish/enforce baseline configs; employ least functionality; restrict/disable nonessential programs; blacklist/whitelist; user-installed software control |
| Identification and Authentication | 11 | Uniquely identify users/devices; MFA for network/local access; replay-resistant authentication; prevent identifier reuse; disable inactive identifiers; enforce password complexity |
| Incident Response | 3 | Establish IR capability; track/document/report incidents; test IR capability |
| Maintenance | 6 | Perform timely maintenance; control maintenance tools; supervise maintenance personnel; check media before connecting; require MFA for nonlocal maintenance |
| Media Protection | 9 | Protect/control/sanitize media with CUI; mark media; control transport; implement cryptographic mechanisms for CUI on digital media |
| Personnel Security | 2 | Screen personnel; protect CUI during personnel actions (termination/transfer) |
| Physical Protection | 6 | Limit physical access; escort/monitor visitors; maintain audit logs of physical access; control physical access devices; protect power/cabling |
| Risk Assessment | 3 | Periodically assess risk; scan for vulnerabilities; remediate vulnerabilities |
| Security Assessment | 4 | Periodically assess controls; develop/implement remediation plans; continuously monitor; implement system-level security plans |
| System and Communications Protection | 16 | Monitor/control communications at boundaries; employ architectural designs with subnetworks; implement cryptographic mechanisms to prevent unauthorized disclosure; deny by default; protect session authenticity; protect CUI at rest |
| System and Information Integrity | 7 | Identify/report/correct flaws timely; protect against malicious code; monitor security alerts; update malicious code mechanisms; monitor systems; identify unauthorized use |

### Relationship to 800-53
- 800-171 requirements are **derived from** 800-53 Moderate baseline
- Each 800-171 requirement maps to one or more 800-53 controls
- 800-171 uses "requirements" rather than "controls" — language is simpler and non-federal-oriented
- 800-171A provides assessment procedures aligned to 800-53A methodology

### CMMC Alignment
- **CMMC Level 1**: 15 practices (subset of 800-171) — basic cyber hygiene
- **CMMC Level 2**: All 110 800-171 Rev 2 requirements — advanced cyber hygiene
- **CMMC Level 3**: 800-171 + subset of 800-172 enhanced requirements

---

## 4. NIST Risk Management Framework (RMF)

**Authority**: NIST SP 800-37 Rev 2
**Applicability**: Federal systems; adaptable to any organization
**Approach**: Comprehensive, flexible, risk-based; integrates security, privacy, and supply chain risk management into SDLC

### Seven Steps

#### Step 1: PREPARE
**Objective**: Establish context and priorities for managing security and privacy risk.

| Key Activities | References |
|---------------|------------|
| Define risk management roles and responsibilities | SP 800-39 |
| Establish risk management strategy | SP 800-39 |
| Conduct organization-level risk assessment | SP 800-30 |
| Identify common controls available organization-wide | SP 800-53 |
| Develop organization-wide tailoring strategy | SP 800-53B |
| Identify system-level stakeholders | SP 800-18 |

#### Step 2: CATEGORIZE
**Objective**: Classify systems and information based on impact analysis.

| Key Activities | References |
|---------------|------------|
| Categorize system per FIPS 199 (Low/Moderate/High for C, I, A) | FIPS 199, SP 800-60 |
| Describe system characteristics and authorization boundary | SP 800-18 |
| Register system with organizational program office | Organization-specific |

#### Step 3: SELECT
**Objective**: Choose, tailor, and document appropriate controls.

| Key Activities | References |
|---------------|------------|
| Select control baselines (Low/Moderate/High) | SP 800-53B |
| Tailor baselines to organizational context | SP 800-53B |
| Apply overlays as needed | SP 800-53B |
| Document controls in security/privacy plans | SP 800-18 |

#### Step 4: IMPLEMENT
**Objective**: Deploy controls and document implementation details.

| Key Activities | References |
|---------------|------------|
| Implement controls per security/privacy plans | SP 800-53 |
| Document implementation details sufficient for assessment | SP 800-18 |

#### Step 5: ASSESS
**Objective**: Verify controls are implemented correctly and producing desired outcomes.

| Key Activities | References |
|---------------|------------|
| Develop assessment plan | SP 800-53A |
| Conduct control assessments | SP 800-53A |
| Produce assessment reports documenting findings | SP 800-53A |
| Remediate deficiencies; reassess as needed | SP 800-53A |

#### Step 6: AUTHORIZE
**Objective**: Senior official makes risk-based decision to authorize system operation.

| Key Activities | References |
|---------------|------------|
| Prepare Plan of Action and Milestones (POA&M) | OMB guidance |
| Assemble authorization package (plan, assessment report, POA&M) | SP 800-37 |
| Authorizing official renders authorization decision | SP 800-37 |

#### Step 7: MONITOR
**Objective**: Ongoing awareness of security/privacy posture to support risk decisions.

| Key Activities | References |
|---------------|------------|
| Monitor control effectiveness continuously | SP 800-137 |
| Assess selected controls per continuous monitoring strategy | SP 800-53A |
| Conduct ongoing risk assessments | SP 800-30 |
| Report security/privacy posture to officials | SP 800-137 |
| Review and update authorization as needed | SP 800-37 |

---

## 5. OWASP ASVS

**Authority**: OWASP Foundation
**Current version**: 5.0.0 (May 2025)
**Applicability**: Web application security verification
**Format**: Requirement ID pattern `<chapter>.<section>.<requirement>` (e.g., `1.11.3`)

### Verification Levels

| Level | Target | Description |
|-------|--------|-------------|
| L1 | All applications | Basic security controls; low-hanging fruit; automated testable |
| L2 | Applications with sensitive data | Recommended for most applications; covers most risks; defense in depth |
| L3 | Critical applications | High-value transactions, medical data, critical infrastructure; highest assurance |

### Verification Chapters (V1-V14)

| Chapter | Area | Key Requirements |
|---------|------|-----------------|
| V1 | Architecture, Design and Threat Modeling | Secure SDLC, threat modeling, input validation architecture, cryptographic architecture, error handling architecture |
| V2 | Authentication | Password security, credential storage, credential recovery, MFA, lookup secrets, out-of-band verifiers |
| V3 | Session Management | Session token generation, binding, termination, cookie-based session management, token-based session management |
| V4 | Access Control | General access control design, operation level, data level, horizontal access control |
| V5 | Validation, Sanitization and Encoding | Input validation, sanitization and sandboxing, output encoding, memory safety, deserialization prevention |
| V6 | Stored Cryptography | Data classification, algorithms, random values, secret management |
| V7 | Error Handling and Logging | Log content, log processing, log protection, error handling |
| V8 | Data Protection | General data protection, client-side data protection, sensitive private data |
| V9 | Communication | Client communication security, server communication security |
| V10 | Malicious Code | Code integrity controls, search for malicious code |
| V11 | Business Logic | Business logic security, anti-automation |
| V12 | Files and Resources | File upload, file integrity, file execution, file storage |
| V13 | API and Web Service | Generic web service security, RESTful, SOAP, GraphQL |
| V14 | Configuration | Build and deploy, dependency, unintended security disclosure, HTTP security headers |

### Practical Implementation
- Use ASVS as a **procurement checklist** in RFPs for software vendors
- Map ASVS requirements to SAST/DAST tool coverage for gap analysis
- L1 is achievable via penetration testing; L2/L3 require code review
- Available in CSV/JSON for integration into issue trackers and CI/CD pipelines

---

## 6. OWASP MASVS

**Authority**: OWASP Foundation (OWASP MAS project)
**Current version**: MASVS v2
**Applicability**: Mobile application security (Android and iOS)
**Companion**: MASTG (Mobile Application Security Testing Guide)

### Verification Categories

| Category | Description | Key Requirements |
|----------|-------------|-----------------|
| MASVS-STORAGE | Secure data storage | Encrypt sensitive data at rest; secure key management; prevent data leaks via logs, backups, clipboard, screenshots, notifications; keyboard cache management |
| MASVS-CRYPTO | Cryptographic implementation | Proper key generation/derivation; secure algorithm selection; key rotation; no hardcoded keys; correct encryption modes and padding |
| MASVS-AUTH | Authentication and authorization | Multi-factor authentication; biometric auth security; step-up auth for sensitive operations; platform-provided auth APIs; token validation; secure credential storage |
| MASVS-NETWORK | Network communication security | TLS/SSL configuration and validation; certificate pinning; no cleartext traffic; hostname verification; machine-to-machine communication security |
| MASVS-PLATFORM | Platform interaction security | Permission management; WebView security/isolation; deep link validation; IPC authentication; intent handling; content provider protection |
| MASVS-CODE | Code quality and integrity | Dependency vulnerability management; input validation; secure deserialization; dynamic code loading restrictions; compiler security features (PIE, stack canaries, ARC) |
| MASVS-RESILIENCE | Anti-tampering and reverse engineering | Code/resource obfuscation; root/jailbreak detection; emulator/debugger detection; device attestation; runtime integrity verification; app signature validation |
| MASVS-PRIVACY | User privacy protection | Anonymization/pseudonymization; user consent mechanisms; data collection transparency; permission minimization; tracking prevention |

### Testing Profiles

| Profile | Description |
|---------|-------------|
| L1 | Basic security baseline — minimum for all mobile apps |
| L2 | Enhanced security — apps handling sensitive data, financial, healthcare |
| R | Resilience — additional anti-tampering/reverse engineering protections |

### Practical Implementation
- Use MASTG test cases as a structured mobile pentest methodology
- L1 is achievable through automated scanning + manual testing
- L2 requires source code access and deeper architectural review
- R-profile adds protection against client-side attacks (typically DRM, financial apps)
- SBOM analysis covers dependency vulnerability detection

---

## 7. CIS Controls & Benchmarks

**Authority**: Center for Internet Security (CIS)
**Current version**: CIS Controls v8.1; Benchmarks continuously updated
**Applicability**: All organizations; prioritized, prescriptive security guidance

### CIS Critical Security Controls v8 (18 Controls)

| Control | Name | IG1 | IG2 | IG3 | Description |
|---------|------|-----|-----|-----|-------------|
| 1 | Inventory and Control of Enterprise Assets | x | x | x | Actively manage all enterprise assets connected to the infrastructure |
| 2 | Inventory and Control of Software Assets | x | x | x | Actively manage all software to ensure only authorized software is installed |
| 3 | Data Protection | x | x | x | Develop processes and technical controls to identify, classify, handle, retain, and dispose of data |
| 4 | Secure Configuration of Enterprise Assets and Software | x | x | x | Establish and maintain secure configurations |
| 5 | Account Management | x | x | x | Use processes and tools to assign and manage authorization to credentials |
| 6 | Access Control Management | x | x | x | Use processes and tools to create, assign, manage, and revoke access |
| 7 | Continuous Vulnerability Management | x | x | x | Develop a plan to continuously assess and remediate vulnerabilities |
| 8 | Audit Log Management | x | x | x | Collect, alert, review, and retain audit logs |
| 9 | Email and Web Browser Protections | x | x | x | Improve protections and detections of email and web threats |
| 10 | Malware Defenses | x | x | x | Prevent or control installation and execution of malicious applications |
| 11 | Data Recovery | x | x | x | Establish and maintain data recovery practices |
| 12 | Network Infrastructure Management | — | x | x | Establish and maintain management and security of network infrastructure |
| 13 | Network Monitoring and Defense | — | x | x | Operate processes and tooling to monitor and defend against threats |
| 14 | Security Awareness and Skills Training | x | x | x | Establish and maintain a security awareness program |
| 15 | Service Provider Management | — | x | x | Develop a process to evaluate service providers |
| 16 | Application Software Security | — | x | x | Manage the security lifecycle of in-house and acquired software |
| 17 | Incident Response Management | x | x | x | Establish an IR program with policies, plans, procedures, roles |
| 18 | Penetration Testing | — | x | x | Test the effectiveness and resiliency of enterprise assets |

### Implementation Groups (IGs)

| IG | Description | Target |
|----|-------------|--------|
| IG1 | Essential Cyber Hygiene | Small orgs with limited IT/security expertise; ~56 safeguards |
| IG2 | All of IG1 + additional | Mid-size orgs with dedicated IT staff; ~130 safeguards |
| IG3 | All of IG1+IG2 + additional | Large orgs with security experts; ~153 safeguards |

### CIS Benchmark Categories

| Category | Examples |
|----------|---------|
| Operating Systems | Windows Server 2022/2025, RHEL 8/9, Ubuntu 22.04/24.04, macOS, Debian, SUSE, Oracle Linux, Amazon Linux, AlmaLinux, Rocky Linux |
| Cloud Providers | AWS Foundations, Azure Foundations, GCP Foundations, Oracle Cloud, Alibaba Cloud, DigitalOcean, Tencent Cloud, IBM Cloud |
| Server Software | Apache HTTP, Tomcat, IIS, Exchange, SharePoint, Nginx |
| Databases | Oracle Database, PostgreSQL, MySQL, MongoDB, MS SQL Server, Cassandra |
| Desktop Software | Microsoft Office, Chrome, Firefox, Safari, Edge |
| Containers/DevOps | Docker, Kubernetes, GitHub, GitLab |
| Network Devices | Cisco IOS/NX-OS/ASA, Juniper, Palo Alto, F5, Fortinet, Check Point |
| Mobile | Apple iOS/iPadOS, Google Android, Samsung Knox |

### Benchmark Levels

| Level | Description |
|-------|-------------|
| Level 1 | Basic security settings; minimal performance impact; broad applicability |
| Level 2 | Defense-in-depth; may reduce functionality; for security-sensitive environments |
| STIG | DoD-specific hardening (maps to DISA STIGs where available) |

---

## 8. GDPR

**Authority**: European Union Regulation (EU) 2016/679
**Effective**: May 25, 2018
**Applicability**: Any organization processing personal data of EU/EEA individuals
**Penalties**: Up to 4% of annual global turnover or EUR 20 million (whichever is greater)

### Compliance Checklist

#### Lawful Basis and Transparency (Articles 5, 6, 7-12, 30)

| Requirement | GDPR Article | Details |
|------------|-------------|---------|
| Conduct information audit | Art. 30 | Document all processing activities: purposes, data types, personnel, third parties, locations, retention |
| Establish lawful basis | Art. 6 | One of six bases: consent, contract, legal obligation, vital interests, public task, legitimate interests |
| Provide privacy notice | Art. 12-14 | Concise, transparent, intelligible, plain language; provided at point of collection |
| Consent management | Art. 7 | Freely given, specific, informed, unambiguous; easy withdrawal; records maintained |
| Children's data | Art. 8 | Parental consent for under-16 (member states may lower to 13); verifiable consent |
| Special categories | Art. 9 | Explicit consent or specific legal basis for health, biometric, genetic, racial, political, religious data |

#### Data Security (Articles 25, 32-34)

| Requirement | GDPR Article | Details |
|------------|-------------|---------|
| Data protection by design and default | Art. 25 | Integrate protection into all processing; pseudonymization; data minimization |
| Encryption and pseudonymization | Art. 32 | End-to-end encryption for data in transit and at rest; pseudonymize where feasible |
| Internal security policies | Recital 78 | Email security, password policy, MFA, device encryption, VPN; role-based training |
| Data Protection Impact Assessment (DPIA) | Art. 35 | Required for high-risk processing; systematic assessment of necessity, proportionality, risks, measures |
| Breach notification (authority) | Art. 33 | Notify supervisory authority within 72 hours of awareness; describe nature, categories, measures |
| Breach notification (individuals) | Art. 34 | Without undue delay when high risk to rights/freedoms; not required if data was encrypted |

#### Accountability and Governance (Articles 24-28, 37-39)

| Requirement | GDPR Article | Details |
|------------|-------------|---------|
| Designate compliance responsibility | Art. 24 | Specific person with authority to evaluate and implement data protection |
| Data Processing Agreements | Art. 28 | Written contracts with all processors; specify rights, obligations, security guarantees |
| EU Representative | Art. 27 | Non-EU orgs must appoint representative in member state where processing occurs |
| Data Protection Officer (DPO) | Art. 37-39 | Required for: public authorities, large-scale systematic monitoring, large-scale special category processing |
| Records of processing activities | Art. 30 | Required for 250+ employees or high-risk processing |

#### Privacy Rights (Articles 15-22)

| Right | GDPR Article | Response Time | Details |
|-------|-------------|---------------|---------|
| Right of Access | Art. 15 | 1 month | Provide all personal data + processing details; first copy free |
| Right to Rectification | Art. 16 | 1 month | Correct inaccurate/incomplete data |
| Right to Erasure | Art. 17 | 1 month | Delete data; 5 exemptions (legal, freedom of expression, etc.) |
| Right to Restrict Processing | Art. 18 | 1 month | Store but halt processing during disputes |
| Right to Data Portability | Art. 20 | 1 month | Provide data in machine-readable format; facilitate transfer to third party |
| Right to Object | Art. 21 | Immediate (marketing) | Must cease direct marketing immediately; other processing requires "compelling grounds" |
| Automated Decision Protections | Art. 22 | 1 month | Right to human intervention, express views, contest decisions |

### International Data Transfers (Chapter V)
- **Adequacy decisions** (Art. 45): Commission-approved countries
- **Standard Contractual Clauses** (Art. 46(2)(c)): pre-approved contract templates
- **Binding Corporate Rules** (Art. 47): intra-group transfers
- **Transfer Impact Assessments**: required post-Schrems II for SCCs

---

## 9. HIPAA Security Rule

**Authority**: U.S. Department of Health and Human Services (HHS)
**Statute**: 45 CFR Part 160 and Part 164, Subpart C
**Applicability**: Covered entities (health plans, healthcare clearinghouses, healthcare providers) and business associates
**Protects**: Electronic Protected Health Information (ePHI)

### Administrative Safeguards (45 CFR 164.308)

| Standard | Implementation Specifications | Required/Addressable |
|----------|------------------------------|---------------------|
| Security Management Process | Risk analysis | Required |
| | Risk management | Required |
| | Sanction policy | Required |
| | Information system activity review | Required |
| Assigned Security Responsibility | Designate security official | Required |
| Workforce Security | Authorization/supervision | Addressable |
| | Workforce clearance procedure | Addressable |
| | Termination procedures | Addressable |
| Information Access Management | Access authorization | Addressable |
| | Access establishment and modification | Addressable |
| | Isolating healthcare clearinghouse functions | Required |
| Security Awareness and Training | Security reminders | Addressable |
| | Protection from malicious software | Addressable |
| | Log-in monitoring | Addressable |
| | Password management | Addressable |
| Security Incident Procedures | Response and reporting | Required |
| Contingency Planning | Data backup plan | Required |
| | Disaster recovery plan | Required |
| | Emergency mode operation plan | Required |
| | Testing and revision procedures | Addressable |
| | Applications and data criticality analysis | Addressable |
| Evaluation | Periodic technical and nontechnical evaluation | Required |
| Business Associate Contracts | Written contracts/arrangements | Required |

### Physical Safeguards (45 CFR 164.310)

| Standard | Implementation Specifications | Required/Addressable |
|----------|------------------------------|---------------------|
| Facility Access Controls | Contingency operations | Addressable |
| | Facility security plan | Addressable |
| | Access control and validation procedures | Addressable |
| | Maintenance records | Addressable |
| Workstation Use | Policies for proper workstation use | Required |
| Workstation Security | Physical safeguards for workstations | Required |
| Device and Media Controls | Disposal | Required |
| | Media re-use | Required |
| | Accountability | Addressable |
| | Data backup and storage | Addressable |

### Technical Safeguards (45 CFR 164.312)

| Standard | Implementation Specifications | Required/Addressable |
|----------|------------------------------|---------------------|
| Access Control | Unique user identification | Required |
| | Emergency access procedure | Required |
| | Automatic logoff | Addressable |
| | Encryption and decryption | Addressable |
| Audit Controls | Record and examine activity | Required |
| Integrity | Mechanism to authenticate ePHI | Addressable |
| Person or Entity Authentication | Verify identity of persons seeking access | Required |
| Transmission Security | Integrity controls | Addressable |
| | Encryption | Addressable |

### Key Concepts
- **Required vs Addressable**: "Addressable" does NOT mean optional. If addressable spec is reasonable and appropriate, implement it. If not, document why and implement equivalent alternative.
- **Risk Analysis**: Foundation of all HIPAA security compliance — must be thorough, ongoing, and documented.
- **Minimum Necessary**: Access only the minimum ePHI needed for the task.
- **Breach Notification Rule** (45 CFR 164.400-414): Notify affected individuals, HHS, and media (if 500+) within 60 days.

---

## 10. PCI DSS v4.0

**Authority**: PCI Security Standards Council (PCI SSC)
**Current version**: v4.0.1 (effective March 2025 for all new assessments)
**Applicability**: Any entity that stores, processes, or transmits cardholder data
**Predecessor**: v3.2.1 (retired March 2024)

### Six Goals and Twelve Requirements

#### Goal 1: Build and Maintain a Secure Network and Systems

| Req | Name | Key Controls |
|-----|------|-------------|
| 1 | Install and Maintain Network Security Controls | Firewall/NSC configuration standards; restrict untrusted network connections; network segmentation; DMZ architecture; review rulesets semi-annually |
| 2 | Apply Secure Configurations to All System Components | Change vendor defaults; disable unnecessary services/protocols; encrypt non-console admin access; maintain system component inventory |

#### Goal 2: Protect Account Data

| Req | Name | Key Controls |
|-----|------|-------------|
| 3 | Protect Stored Account Data | Minimize data retention; do not store SAD post-authorization; mask PAN when displayed; render PAN unreadable (encryption, truncation, hashing, tokenization); key management procedures |
| 4 | Protect Cardholder Data with Strong Cryptography During Transmission Over Open, Public Networks | Strong cryptography for transmission; never send PAN via unencrypted messaging; document trusted keys and certificates |

#### Goal 3: Maintain a Vulnerability Management Program

| Req | Name | Key Controls |
|-----|------|-------------|
| 5 | Protect All Systems and Networks from Malicious Software | Anti-malware on all systems commonly affected; periodic scans; anti-malware cannot be disabled by users; protect against phishing |
| 6 | Develop and Maintain Secure Systems and Software | Establish patching process; install critical patches within one month; develop software securely; address common coding vulnerabilities (OWASP Top 10); protect public-facing web apps (WAF or code review) |

#### Goal 4: Implement Strong Access Control Measures

| Req | Name | Key Controls |
|-----|------|-------------|
| 7 | Restrict Access to System Components and Cardholder Data by Business Need to Know | Access control system; default deny-all; role-based access; document and review access periodically |
| 8 | Identify Users and Authenticate Access to System Components | Unique IDs for all users; MFA for all access to CDE; strong password policy (12+ chars in v4.0); secure authentication for applications and systems; no shared/group accounts |
| 9 | Restrict Physical Access to Cardholder Data | Facility entry controls; distinguish staff and visitors; physically secure media; control media distribution; destroy media when no longer needed |

#### Goal 5: Regularly Monitor and Test Networks

| Req | Name | Key Controls |
|-----|------|-------------|
| 10 | Log and Monitor All Access to System Components and Cardholder Data | Audit trail for all access; automated audit trails; time synchronization; secure audit trails; review logs daily; retain history 12 months (3 months immediately accessible) |
| 11 | Test Security of Systems and Networks Regularly | Wireless AP detection quarterly; internal/external vulnerability scans quarterly; penetration testing annually (and after significant changes); IDS/IPS; change-detection (FIM) on critical files |

#### Goal 6: Maintain an Information Security Policy

| Req | Name | Key Controls |
|-----|------|-------------|
| 12 | Support Information Security with Organizational Policies and Programs | Security policy; acceptable use; risk assessment annually; security awareness training; screen personnel; manage service providers; IR plan tested annually |

### Compliance Levels (Merchants)

| Level | Criteria | Validation |
|-------|----------|------------|
| 1 | >6M transactions/year | Annual on-site assessment by QSA; quarterly network scan by ASV |
| 2 | 1M-6M transactions/year | Annual SAQ; quarterly ASV scan |
| 3 | 20K-1M e-commerce transactions/year | Annual SAQ; quarterly ASV scan |
| 4 | <20K e-commerce or <1M other transactions/year | Annual SAQ; quarterly ASV scan recommended |

### SAQ Types
- **SAQ A**: Card-not-present merchants, fully outsourced
- **SAQ A-EP**: E-commerce merchants with partial outsourcing
- **SAQ B**: Imprint or standalone dial-out terminal merchants
- **SAQ B-IP**: Standalone IP-connected PTS POI terminal merchants
- **SAQ C**: Payment application systems connected to internet
- **SAQ C-VT**: Virtual terminal merchants (web-based, no e-commerce)
- **SAQ D**: All others (merchants and service providers)
- **SAQ P2PE**: Hardware payment terminal in P2PE solution

### Key v4.0 Changes
- **Customized approach**: alternative to defined approach — demonstrate control objective met via custom implementation
- **Targeted risk analysis**: entity defines frequency of certain activities based on risk
- **MFA everywhere**: required for all access to CDE (not just remote)
- **Password length**: minimum 12 characters (up from 7)
- **Phishing protections**: explicit requirement (Req 5.4)
- **Authenticated vulnerability scanning**: internal scans must use authentication

---

## 11. SOC 2

**Authority**: American Institute of Certified Public Accountants (AICPA)
**Framework**: Trust Services Criteria (TSC) 2017
**Applicability**: Service organizations (SaaS, cloud, managed services, data centers)
**Assessment**: Performed by licensed CPA firms

### Five Trust Service Criteria

#### Security (Common Criteria — CC Series, Required)

| Criteria | Area | Key Controls |
|----------|------|-------------|
| CC1 | Control Environment | Management philosophy, organizational structure, HR policies, integrity/ethics |
| CC2 | Communication and Information | Internal/external communication of policies, security awareness |
| CC3 | Risk Assessment | Risk identification and analysis; fraud risk consideration; change management |
| CC4 | Monitoring Activities | Ongoing and separate evaluations; remediation of deficiencies |
| CC5 | Control Activities | Selection/development of controls; technology controls; policies and procedures |
| CC6 | Logical and Physical Access Controls | Logical access security (IAM, MFA, encryption); physical access restrictions; asset management; data disposal |
| CC7 | System Operations | Detect and monitor anomalies; evaluate and respond to incidents; change management; vulnerability management |
| CC8 | Change Management | Authorization, design, development, testing, approval of changes |
| CC9 | Risk Mitigation | Risk mitigation activities; vendor management; business continuity/disaster recovery |

#### Availability (Optional)

| Focus | Key Controls |
|-------|-------------|
| Maintain availability per SLAs | Capacity planning; backup and recovery; disaster recovery/BCP; monitoring; incident response for outages |

#### Processing Integrity (Optional)

| Focus | Key Controls |
|-------|-------------|
| System processing is complete, valid, accurate, timely, authorized | Input validation; processing monitoring; error handling; output reconciliation; QA processes |

#### Confidentiality (Optional)

| Focus | Key Controls |
|-------|-------------|
| Protect confidential information | Data classification; encryption at rest and in transit; access restrictions; confidential data disposal; NDA management |

#### Privacy (Optional)

| Focus | Key Controls |
|-------|-------------|
| Personal information managed per privacy notice | Notice; choice and consent; collection limitation; use/retention/disposal; access; disclosure; quality; monitoring |

### Type I vs Type II

| Aspect | Type I | Type II |
|--------|--------|---------|
| Scope | Design of controls at a point in time | Design + operating effectiveness over a period |
| Observation period | None (single date) | 3-12 months (6 months typical minimum) |
| Market acceptance | Useful for initial compliance; stepping stone | Industry standard; preferred by enterprise customers |
| Timeline | 1-3 months | 4-9 months (including observation window) |
| Cost | Lower (mid four to low five figures) | Higher (assessment + tooling + remediation) |

### Practical Implementation
1. **Scope definition first**: define the system boundary — not the entire company
2. **Security criteria always included**: it is the foundation; other criteria added as relevant
3. **Readiness assessment**: gap analysis before formal audit to avoid findings
4. **Evidence collection**: automate with GRC platforms (Vanta, Drata, Secureframe, Sprinto)
5. **Shared controls matter**: access provisioning, change management, IR, HR processes affect the system even if not directly in scope
6. **Bridge letters**: cover gaps between report periods for continuous compliance demonstration

---

## 12. ISO/IEC 27001:2022

**Authority**: International Organization for Standardization (ISO) / International Electrotechnical Commission (IEC)
**Current version**: ISO/IEC 27001:2022 (Edition 3, October 2022)
**Applicability**: Any organization, any sector, any size
**Certification**: By accredited conformity assessment bodies; 70,000+ certificates in 150+ countries

### Management System Clauses (4-10)

| Clause | Name | Key Requirements |
|--------|------|-----------------|
| 4 | Context of the Organization | Understand internal/external issues; interested parties; scope of ISMS; ISMS establishment |
| 5 | Leadership | Management commitment; information security policy; roles, responsibilities, authorities |
| 6 | Planning | Risk assessment process; risk treatment; information security objectives; planning of changes |
| 7 | Support | Resources; competence; awareness; communication; documented information |
| 8 | Operation | Operational planning and control; information security risk assessment (execution); risk treatment (execution) |
| 9 | Performance Evaluation | Monitoring, measurement, analysis, evaluation; internal audit; management review |
| 10 | Improvement | Continual improvement; nonconformity and corrective action |

### Annex A Controls (93 Controls in 4 Themes)

#### A.5 — Organizational Controls (37 controls)

| Control | Name |
|---------|------|
| A.5.1 | Policies for information security |
| A.5.2 | Information security roles and responsibilities |
| A.5.3 | Segregation of duties |
| A.5.4 | Management responsibilities |
| A.5.5 | Contact with authorities |
| A.5.6 | Contact with special interest groups |
| A.5.7 | Threat intelligence |
| A.5.8 | Information security in project management |
| A.5.9 | Inventory of information and other associated assets |
| A.5.10 | Acceptable use of information and other associated assets |
| A.5.11 | Return of assets |
| A.5.12 | Classification of information |
| A.5.13 | Labelling of information |
| A.5.14 | Information transfer |
| A.5.15 | Access control |
| A.5.16 | Identity management |
| A.5.17 | Authentication information |
| A.5.18 | Access rights |
| A.5.19 | Information security in supplier relationships |
| A.5.20 | Addressing information security within supplier agreements |
| A.5.21 | Managing information security in the ICT supply chain |
| A.5.22 | Monitoring, review and change management of supplier services |
| A.5.23 | Information security for use of cloud services |
| A.5.24 | Information security incident management planning and preparation |
| A.5.25 | Assessment and decision on information security events |
| A.5.26 | Response to information security incidents |
| A.5.27 | Learning from information security incidents |
| A.5.28 | Collection of evidence |
| A.5.29 | Information security during disruption |
| A.5.30 | ICT readiness for business continuity |
| A.5.31 | Legal, statutory, regulatory and contractual requirements |
| A.5.32 | Intellectual property rights |
| A.5.33 | Protection of records |
| A.5.34 | Privacy and protection of PII |
| A.5.35 | Independent review of information security |
| A.5.36 | Compliance with policies, rules and standards for information security |
| A.5.37 | Documented operating procedures |

#### A.6 — People Controls (8 controls)

| Control | Name |
|---------|------|
| A.6.1 | Screening |
| A.6.2 | Terms and conditions of employment |
| A.6.3 | Information security awareness, education and training |
| A.6.4 | Disciplinary process |
| A.6.5 | Responsibilities after termination or change of employment |
| A.6.6 | Confidentiality or non-disclosure agreements |
| A.6.7 | Remote working |
| A.6.8 | Information security event reporting |

#### A.7 — Physical Controls (14 controls)

| Control | Name |
|---------|------|
| A.7.1 | Physical security perimeters |
| A.7.2 | Physical entry |
| A.7.3 | Securing offices, rooms and facilities |
| A.7.4 | Physical security monitoring |
| A.7.5 | Protecting against physical and environmental threats |
| A.7.6 | Working in secure areas |
| A.7.7 | Clear desk and clear screen |
| A.7.8 | Equipment siting and protection |
| A.7.9 | Security of assets off-premises |
| A.7.10 | Storage media |
| A.7.11 | Supporting utilities |
| A.7.12 | Cabling security |
| A.7.13 | Equipment maintenance |
| A.7.14 | Secure disposal or re-use of equipment |

#### A.8 — Technological Controls (34 controls)

| Control | Name |
|---------|------|
| A.8.1 | User endpoint devices |
| A.8.2 | Privileged access rights |
| A.8.3 | Information access restriction |
| A.8.4 | Access to source code |
| A.8.5 | Secure authentication |
| A.8.6 | Capacity management |
| A.8.7 | Protection against malware |
| A.8.8 | Management of technical vulnerabilities |
| A.8.9 | Configuration management |
| A.8.10 | Information deletion |
| A.8.11 | Data masking |
| A.8.12 | Data leakage prevention |
| A.8.13 | Information backup |
| A.8.14 | Redundancy of information processing facilities |
| A.8.15 | Logging |
| A.8.16 | Monitoring activities |
| A.8.17 | Clock synchronization |
| A.8.18 | Use of privileged utility programs |
| A.8.19 | Installation of software on operational systems |
| A.8.20 | Networks security |
| A.8.21 | Security of network services |
| A.8.22 | Segregation of networks |
| A.8.23 | Web filtering |
| A.8.24 | Use of cryptography |
| A.8.25 | Secure development life cycle |
| A.8.26 | Application security requirements |
| A.8.27 | Secure system architecture and engineering principles |
| A.8.28 | Secure coding |
| A.8.29 | Security testing in development and acceptance |
| A.8.30 | Outsourced development |
| A.8.31 | Separation of development, test and production environments |
| A.8.32 | Change management |
| A.8.33 | Test information |
| A.8.34 | Protection of information systems during audit testing |

### Key Changes from ISO 27001:2013
- Reduced from 114 controls in 14 clauses to 93 controls in 4 themes
- 11 new controls: threat intelligence, cloud services, ICT readiness, data masking, DLP, monitoring activities, web filtering, secure coding, configuration management, information deletion, data leakage prevention
- Attributes system: control type, security properties (CIA), cybersecurity concepts, operational capabilities, security domains

### Certification Process
1. **Gap assessment**: identify current state vs requirements
2. **ISMS implementation**: policies, risk assessment, controls, documentation
3. **Stage 1 audit**: documentation review, readiness assessment
4. **Stage 2 audit**: on-site assessment of ISMS implementation and effectiveness
5. **Certification**: valid for 3 years
6. **Surveillance audits**: annual (Year 1 and Year 2)
7. **Recertification audit**: full reassessment at end of 3-year cycle

---

## 13. FedRAMP

**Authority**: U.S. Federal Government (General Services Administration — GSA)
**Basis**: FISMA; uses NIST SP 800-53 controls
**Applicability**: Cloud Service Providers (CSPs) offering services to federal agencies
**Current status**: Codified into law via FedRAMP Authorization Act (part of FY2023 NDAA)

### Authorization Levels

| Level | Impact | NIST 800-53 Controls | Use Case |
|-------|--------|---------------------|----------|
| Low | Limited adverse effect | ~125 controls | Non-sensitive data; publicly available information |
| Moderate | Serious adverse effect | ~325 controls | Most federal data; CUI; PII; majority of FedRAMP authorizations |
| High | Severe or catastrophic adverse effect | ~421 controls | Law enforcement; emergency services; financial; health; classified-adjacent |
| LI-SaaS | Low Impact SaaS | ~36 controls | SaaS that does not store PII beyond login credentials |

### Authorization Paths

#### Agency Authorization
1. CSP partners with a specific federal agency sponsor
2. CSP implements controls and prepares documentation
3. Third-Party Assessment Organization (3PAO) conducts independent assessment
4. Agency reviews package and issues Agency ATO (Authority to Operate)
5. FedRAMP PMO reviews for FedRAMP Marketplace listing

#### JAB P-ATO (Joint Authorization Board Provisional ATO)
1. CSP applies and is prioritized by JAB (DoD, DHS, GSA CIOs)
2. Full security assessment by 3PAO
3. JAB reviews and issues Provisional ATO
4. Individual agencies can leverage P-ATO with reduced review
5. *Note: JAB path being phased out under FedRAMP modernization*

### Required Documentation
- System Security Plan (SSP)
- Security Assessment Plan (SAP)
- Security Assessment Report (SAR)
- Plan of Action and Milestones (POA&M)
- Continuous Monitoring deliverables
- Incident Response Plan
- Configuration Management Plan
- Supply Chain Risk Management Plan

### Continuous Monitoring Requirements
- **Monthly**: OS/infrastructure vulnerability scans; POA&M updates
- **Quarterly**: Web application scans; database scans
- **Annual**: Full security assessment (subset of controls); penetration testing; contingency plan testing
- **Ongoing**: Significant change requests; incident reporting (US-CERT within 1 hour for incidents)
- **ConMon reporting**: Monthly submission to FedRAMP PMO

---

## 14. Cross-Framework Mappings

### NIST CSF 2.0 to ISO 27001:2022

| CSF Function | CSF Category | ISO 27001 Clause/Control |
|-------------|-------------|-------------------------|
| GOVERN | GV.OC (Organizational Context) | Clause 4 (Context of the Organization) |
| GOVERN | GV.RM (Risk Management Strategy) | Clause 6.1 (Actions to address risks) |
| GOVERN | GV.RR (Roles, Responsibilities) | Clause 5.3, A.5.2 |
| GOVERN | GV.PO (Policy) | Clause 5.2, A.5.1 |
| GOVERN | GV.OV (Oversight) | Clause 9 (Performance Evaluation) |
| GOVERN | GV.SC (Supply Chain) | A.5.19-A.5.22 |
| IDENTIFY | ID.AM (Asset Management) | A.5.9-A.5.13 |
| IDENTIFY | ID.RA (Risk Assessment) | Clause 6.1.2, Clause 8.2 |
| IDENTIFY | ID.IM (Improvement) | Clause 10 (Improvement) |
| PROTECT | PR.AA (Access Control) | A.5.15-A.5.18, A.8.2-A.8.5 |
| PROTECT | PR.AT (Awareness/Training) | A.6.3 |
| PROTECT | PR.DS (Data Security) | A.8.10-A.8.13, A.8.24 |
| PROTECT | PR.PS (Platform Security) | A.8.1, A.8.7-A.8.9, A.8.19 |
| PROTECT | PR.IR (Infrastructure Resilience) | A.8.14, A.8.20-A.8.22 |
| DETECT | DE.CM (Continuous Monitoring) | A.8.15-A.8.16 |
| DETECT | DE.AE (Adverse Event Analysis) | A.5.25 |
| RESPOND | RS.MA (Incident Management) | A.5.24-A.5.26 |
| RESPOND | RS.AN (Incident Analysis) | A.5.26, A.5.28 |
| RESPOND | RS.CO (Communication) | A.5.5-A.5.6 |
| RECOVER | RC.RP (Recovery Plan) | A.5.29-A.5.30 |
| RECOVER | RC.CO (Recovery Communication) | Clause 7.4 (Communication) |

### NIST 800-53 to CIS Controls v8

| 800-53 Family | CIS Control(s) | Mapping Notes |
|---------------|----------------|---------------|
| AC (Access Control) | 3, 5, 6 | Account management, access control, data protection |
| AT (Awareness & Training) | 14 | Security awareness and skills training |
| AU (Audit & Accountability) | 8 | Audit log management |
| CA (Assessment & Authorization) | 18 | Penetration testing; continuous monitoring |
| CM (Configuration Management) | 4 | Secure configuration |
| CP (Contingency Planning) | 11 | Data recovery |
| IA (Identification & Authentication) | 5, 6 | Account management, access control |
| IR (Incident Response) | 17 | Incident response management |
| MA (Maintenance) | 4 | Secure configuration (maintenance windows) |
| MP (Media Protection) | 3 | Data protection |
| PE (Physical & Environmental) | — | CIS Controls v8 does not cover physical security |
| PL (Planning) | — | Organizational; mapped via governance processes |
| PM (Program Management) | 15, 17 | Service provider management, IR management |
| PS (Personnel Security) | 14 | Security awareness |
| PT (PII Processing) | 3 | Data protection |
| RA (Risk Assessment) | 7 | Continuous vulnerability management |
| SA (System & Services Acquisition) | 15, 16 | Service provider management, application software security |
| SC (System & Communications Protection) | 3, 12, 13 | Data protection, network infrastructure/monitoring |
| SI (System & Information Integrity) | 7, 10 | Vulnerability management, malware defenses |
| SR (Supply Chain Risk Management) | 15, 16 | Service provider management, application security |

### NIST 800-53 to SOC 2 Trust Service Criteria

| 800-53 Family | SOC 2 Criteria | Notes |
|---------------|---------------|-------|
| AC | CC6 | Logical and physical access |
| AT | CC1, CC2 | Control environment, communication |
| AU | CC7 | System operations (monitoring) |
| CM | CC7, CC8 | System operations, change management |
| CP | CC9, A1 | Risk mitigation, availability |
| IA | CC6 | Logical access |
| IR | CC7 | System operations (incident detection/response) |
| RA | CC3 | Risk assessment |
| SC | CC6 | Logical access (encryption, boundaries) |
| SI | CC7 | System operations (integrity monitoring) |

### ISO 27001 to SOC 2

| ISO 27001 Theme | SOC 2 Criteria |
|----------------|---------------|
| A.5 Organizational | CC1, CC2, CC3, CC5, CC9 |
| A.6 People | CC1, CC2 |
| A.7 Physical | CC6 |
| A.8 Technological | CC6, CC7, CC8 |

### GDPR to NIST 800-53

| GDPR Article | 800-53 Control Family | Specific Controls |
|-------------|----------------------|-------------------|
| Art. 5 (Principles) | PL, PM | PL-4, PM-11 |
| Art. 6 (Lawful Basis) | PT | PT-2 (Authority to Process) |
| Art. 7 (Consent) | PT | PT-3 (Consent), PT-4 (Privacy Notice) |
| Art. 12-14 (Transparency) | PT | PT-4 (Privacy Notice), PT-5 (Privacy Notice Dissemination) |
| Art. 15-22 (Data Subject Rights) | PT, IP | PT-6 (Individual Access), Individual Participation family |
| Art. 25 (Privacy by Design) | SA, PM | SA-8 (Security Engineering Principles), PM-25 |
| Art. 30 (Records) | PM | PM-5 (System Inventory) |
| Art. 32 (Security) | SC, AC, IA | SC-8, SC-13, SC-28, AC-2, IA-2 |
| Art. 33-34 (Breach Notification) | IR | IR-6 (Incident Reporting), IR-8 (IR Plan) |
| Art. 35 (DPIA) | RA | RA-3 (Risk Assessment), RA-8 (Privacy Impact Assessments) |
| Art. 44-49 (Transfers) | SA, PT | SA-9 (External Services), PT-8 |

### HIPAA to NIST 800-53

| HIPAA Safeguard | 800-53 Family | Key Controls |
|----------------|---------------|-------------|
| Administrative: Security Management | RA, PM, PL | RA-3, RA-5, PM-9, PL-2 |
| Administrative: Workforce Security | PS, AC | PS-2, PS-3, PS-4, AC-2 |
| Administrative: Information Access | AC | AC-3, AC-6, AC-24 |
| Administrative: Awareness & Training | AT | AT-2, AT-3 |
| Administrative: Security Incident | IR | IR-2, IR-4, IR-6, IR-8 |
| Administrative: Contingency Planning | CP | CP-2, CP-9, CP-10 |
| Physical: Facility Access | PE | PE-2, PE-3, PE-6 |
| Physical: Workstation/Device | PE, MP | PE-17, PE-18, MP-6 |
| Technical: Access Control | AC, IA | AC-2, AC-3, IA-2, IA-5 |
| Technical: Audit Controls | AU | AU-2, AU-3, AU-6, AU-12 |
| Technical: Integrity | SI, SC | SI-7, SC-8, SC-13 |
| Technical: Transmission Security | SC | SC-8, SC-13 |

---

## 15. Practical Implementation Guidance

### Framework Selection Decision Matrix

| Scenario | Primary Framework | Supporting Frameworks |
|----------|------------------|----------------------|
| U.S. Federal contractor | NIST 800-53, FedRAMP | NIST RMF, NIST CSF |
| DoD contractor / CUI handler | NIST 800-171, CMMC | NIST 800-53 (reference) |
| SaaS startup seeking enterprise customers | SOC 2 Type II | CIS Controls (IG1), OWASP ASVS |
| Healthcare application | HIPAA | NIST CSF, SOC 2, OWASP ASVS |
| Payment processing | PCI DSS v4.0 | CIS Benchmarks, OWASP ASVS |
| EU market / EU data subjects | GDPR | ISO 27001, NIST CSF |
| Global enterprise | ISO 27001 | NIST CSF (overlay), CIS Controls (operational) |
| Web application security | OWASP ASVS L2 | CIS Controls (16), NIST 800-53 SA family |
| Mobile application security | OWASP MASVS L2 | OWASP ASVS (backend), PCI DSS (if payments) |
| Critical infrastructure | NIST CSF Tier 3+ | NIST 800-53 High, CIS Controls IG3 |

### Implementation Phases (Universal)

#### Phase 1: Foundation (Months 1-3)
1. **Scope**: define systems, data flows, trust boundaries
2. **Risk assessment**: threat model (STRIDE/DREAD), identify crown jewels
3. **Gap analysis**: current state vs target framework requirements
4. **Quick wins**: CIS IG1 safeguards, password policy, MFA, patching cadence

#### Phase 2: Core Controls (Months 3-6)
1. **Access control**: RBAC/ABAC, least privilege, MFA everywhere, PAM
2. **Logging and monitoring**: centralized log collection, SIEM deployment, alerting baselines
3. **Vulnerability management**: authenticated scanning, patch SLAs, risk-based prioritization
4. **Encryption**: data at rest (AES-256), data in transit (TLS 1.2+), key management
5. **Incident response**: IR plan, team roster, communication templates, tabletop exercises

#### Phase 3: Maturity (Months 6-12)
1. **Configuration management**: CIS Benchmarks as baselines, drift detection, IaC scanning
2. **Supply chain security**: vendor risk assessments, SBOM, dependency scanning
3. **Security testing**: SAST/DAST in CI/CD, annual penetration testing
4. **Training**: role-based security training, phishing simulations
5. **Documentation**: policies, procedures, evidence collection, exception management

#### Phase 4: Continuous Improvement (Ongoing)
1. **Continuous monitoring**: real-time dashboards, automated compliance checks
2. **Metrics**: MTTD, MTTR, vulnerability aging, patching SLAs, training completion
3. **Audit readiness**: evidence repository, control owner accountability, pre-audit self-assessments
4. **Framework updates**: track NIST, ISO, OWASP releases; update controls accordingly

### Common Control Overlap — "Implement Once, Satisfy Many"

These controls satisfy requirements across nearly all frameworks:

| Control Area | Satisfies |
|-------------|-----------|
| **Multi-Factor Authentication** | 800-53 IA-2, 800-171 3.5.3, PCI DSS 8.4, HIPAA 164.312(d), CIS 6.3-6.5, ISO A.8.5, SOC 2 CC6.1, GDPR Art. 32 |
| **Encryption at Rest** | 800-53 SC-28, 800-171 3.13.16, PCI DSS 3.5, HIPAA 164.312(a)(2)(iv), CIS 3.11, ISO A.8.24, SOC 2 CC6.1, GDPR Art. 32 |
| **Encryption in Transit** | 800-53 SC-8, 800-171 3.13.8, PCI DSS 4.2, HIPAA 164.312(e), CIS 3.10, ISO A.8.24, SOC 2 CC6.1, GDPR Art. 32 |
| **Centralized Logging** | 800-53 AU-2/AU-6, 800-171 3.3.1, PCI DSS 10.2, HIPAA 164.312(b), CIS 8.2, ISO A.8.15, SOC 2 CC7.2 |
| **Vulnerability Scanning** | 800-53 RA-5, 800-171 3.11.2, PCI DSS 11.3, CIS 7.5-7.6, ISO A.8.8, SOC 2 CC7.1 |
| **Access Reviews** | 800-53 AC-2(3), 800-171 3.1.1, PCI DSS 7.2, HIPAA 164.312(a), CIS 5.1, ISO A.5.18, SOC 2 CC6.2 |
| **Incident Response Plan** | 800-53 IR-8, 800-171 3.6.1, PCI DSS 12.10, HIPAA 164.308(a)(6), CIS 17.1, ISO A.5.24, SOC 2 CC7.4, GDPR Art. 33 |
| **Security Awareness Training** | 800-53 AT-2, 800-171 3.2.1, PCI DSS 12.6, HIPAA 164.308(a)(5), CIS 14.1, ISO A.6.3, SOC 2 CC1.4 |
| **Change Management** | 800-53 CM-3, PCI DSS 6.5, CIS 4.1, ISO A.8.32, SOC 2 CC8.1 |
| **Backup and Recovery** | 800-53 CP-9, 800-171 3.8.9, PCI DSS 9.5, HIPAA 164.308(a)(7), CIS 11.1-11.4, ISO A.8.13, SOC 2 A1.2 |

### Architecture Review Checklist (CIPHER Quick Reference)

When conducting an architecture review, verify against:

1. **Identity and Access**: MFA, least privilege, RBAC, service account management, session management
2. **Network**: segmentation, WAF, DDoS protection, DNS security, egress filtering
3. **Data**: classification, encryption (rest/transit/use), key management, tokenization, DLP, retention
4. **Compute**: hardened images (CIS Benchmarks), patch management, runtime protection, container security
5. **Logging**: centralized collection, integrity protection, retention (90d hot / 1yr cold), correlation, alerting
6. **Resilience**: HA architecture, backup/restore testing, DR plan, RTO/RPO defined, chaos engineering
7. **Supply Chain**: SBOM, dependency scanning, vendor risk assessment, code signing
8. **Privacy**: data flow mapping, DPIA, consent management, data subject rights automation, cross-border transfers
9. **Compliance**: applicable frameworks identified, control mapping documented, evidence collection automated
10. **Incident Response**: IR plan tested, communication plan, forensic readiness, legal/regulatory notification procedures

---

*This document is a living reference. Update when major framework revisions are published.*
*Primary sources: NIST (nist.gov), OWASP (owasp.org), CIS (cisecurity.org), ISO (iso.org), AICPA, PCI SSC, EU GDPR text, HHS HIPAA guidance.*
