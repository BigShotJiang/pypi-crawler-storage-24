# Windows & Active Directory Deep Security Knowledge Base

> CIPHER Training Extract | Generated 2026-03-14
> Sources: Harden-Windows-Security, PrivescCheck, al-khaser, System Informer,
> Reverse-Engineering, Beginners-Guide-to-Obfuscation, adsecurity.org,
> thehacker.recipes, harmj0y.net, specterops.io

---

## TABLE OF CONTENTS

1. [Windows Hardening Controls](#1-windows-hardening-controls)
2. [WDAC / App Control Policies](#2-wdac--app-control-policies)
3. [Windows Privilege Escalation Vectors](#3-windows-privilege-escalation-vectors)
4. [Active Directory Attack Techniques](#4-active-directory-attack-techniques)
5. [Active Directory Hardening & Detection](#5-active-directory-hardening--detection)
6. [Anti-Debugging & Anti-VM Techniques](#6-anti-debugging--anti-vm-techniques)
7. [Obfuscation & Evasion Techniques](#7-obfuscation--evasion-techniques)
8. [Reverse Engineering Methodology](#8-reverse-engineering-methodology)
9. [Process Inspection & Kernel Analysis](#9-process-inspection--kernel-analysis)
10. [Detection Engineering Reference](#10-detection-engineering-reference)

---

## 1. WINDOWS HARDENING CONTROLS

Source: Harden-Windows-Security (HotCakeX)

### 1.1 Microsoft Defender Configuration

| Setting | Value | GPO/Registry | CSP |
|---------|-------|-------------|-----|
| Cloud Block Level | Zero Tolerance + Block At First Sight | GPO | Defender/CloudBlockLevel |
| Cloud Scan Timeout | 60 seconds (max) | GPO | Defender/CloudExtendedTimeout |
| Sample Submission | Send all samples automatically | GPO | Defender/SubmitSamplesConsent |
| SpyNet Membership | Advanced | GPO | Defender/AllowCloudProtection |
| File Hash Computation | Enabled | GPO | MpEngine/EnableFileHashComputation |
| Signature Update Interval | Every 3 hours | GPO | Defender/SignatureUpdateInterval |
| Quarantine Purge | 1 day (not indefinite) | GPO | Quarantine/PurgeItemsAfterDelay |
| Network Protection | Enabled (Block mode) | GPO | Defender/EnableNetworkProtection |
| Controlled Folder Access | Enabled | GPO | Defender/EnableControlledFolderAccess |
| Scan Mapped Network Drives | Enabled | GPO | Defender/AllowFullScanOnMappedNetworkDrives |
| Scan Removable Drives | Enabled | GPO | Defender/AllowFullScanRemovableDriveScanning |
| Scan Network Files | Enabled | GPO | Defender/AllowScanningNetworkFiles |
| Scan Reparse Points | Enabled | GPO | Scan/DisableReparsePointScanning |
| Scan Emails | Enabled | GPO | Defender/AllowEmailScanning |
| Enhanced Phishing Protection | Enabled (all sub-features) | GPO | WebThreatDefense/* |
| DEP (Data Execution Prevention) | AlwaysOn (not OptIn) | Registry/BCDEdit | ExploitGuard |
| Mandatory ASLR | Enabled system-wide | Registry | ExploitGuard |
| Brute-Force Protection | Cloud aggregation, 99%+ confidence block | GPO | Defender/BruteForceProtection* |
| Remote Encryption Protection | Block at 90%+ confidence | GPO | Defender/RemoteEncryptionProtection* |
| Intel TDT Integration | Enabled | GPO | Defender/IntelTDTEnabled |
| Sandbox Mode | Enabled (MDAv runs sandboxed) | GPO | - |
| Smart App Control | Enabled if in Evaluation mode | Registry | - |
| Defender Performance Mode | Disabled (full scanning on Dev Drives) | GPO | Defender/PerformanceModeStatus |
| Sig Staleness Threshold | 2 days (default 7) | GPO | SignatureUpdate/ASSignatureDue |
| Threat Default Actions | Severe/High=Remove, Medium/Low=Quarantine | GPO | Threats/ThreatIdDefaultAction |

### 1.2 Attack Surface Reduction (ASR) Rules

All 19 ASR rules enabled in block mode. Key rules:

| Rule | GUID | Purpose |
|------|------|---------|
| Block executable content from email/webmail | BE9BA2D9-53EA-4CDC-84E5-9B1EEEE46550 | Prevents email-delivered malware |
| Block Office apps from creating executable content | 3B576869-A4EC-4529-8536-B80A7769E899 | Stops macro-based payload drops |
| Block Office apps from creating child processes | D4F940AB-401B-4EFC-AADC-AD5F3C50688A | Prevents Office exploitation chains |
| Block JavaScript/VBScript from launching downloaded content | D3E037E1-3EB8-44C8-A917-57927947596D | Blocks script-based downloaders |
| Block execution of potentially obfuscated scripts | 5BEB7EFE-FD9A-4556-801D-275E5FFC04CC | Targets obfuscated PowerShell/scripts |
| Block Win32 API calls from Office macros | 92E97FA1-2EDF-4476-BDD6-9DD0B4DDDC7B | Prevents macro Win32 API abuse |
| Block credential stealing from LSASS | 9E6C4E1F-7D60-472F-BA1A-A39EF669E4B2 | Protects against Mimikatz-style attacks |
| Block process creations from PSExec/WMI | D1E49AAC-8F56-4280-B9BA-993A6D77406C | Limits lateral movement tools |
| Block untrusted/unsigned from USB | B2B3F03D-6A65-4F7B-A9C7-1C7EF74A9BA4 | USB-delivered payload defense |
| Block persistence through WMI subscription | E6DB77E5-3DF2-4CF1-B95A-636979351E5B | WMI persistence prevention |
| Block abuse of exploited vulnerable signed drivers | 56A863A9-875E-4185-98A7-B882C64B5CE5 | BYOVD mitigation |
| Use advanced protection against ransomware | C1DB55AB-C21A-4637-BB3F-A12568109D35 | Ransomware behavioral blocking |

### 1.3 Device Guard & Virtualization-Based Security

- **VBS (Virtualization-Based Security)**: Enabled + UEFI Lock
- **HVCI (Memory Integrity)**: Enforced with UEFI Lock; Mandatory mode optional
- **Credential Guard**: Enabled + UEFI Lock (protects NTLM hashes, Kerberos TGTs in isolated container)
- **Secure Boot**: Required for VBS platform security
- **UEFI MAT (Memory Attributes Table)**: Required
- **System Guard Secure Launch**: Enabled (firmware protection via DRTM)
- **Kernel Mode Hardware Enforced Stack Protection**: Enabled
- **LSA Protection**: Enabled + UEFI Lock (RunAsPPL - prevents LSASS credential dumping)
- **Machine Identity Isolation**: Enforcement mode
- **Kernel DMA Protection**: Leveraged where hardware supports it

> UEFI Lock significance: Cannot be disabled without physical access to UEFI settings + Secure Boot disable. Root of trust in physical presence.

### 1.4 BitLocker Configuration

- **Encryption Algorithm**: XTS-AES-256 (military grade)
- **Normal Mode**: TPM + Startup PIN
- **Enhanced Mode**: TPM + Startup PIN + Startup Key (USB) -- multifactor
- **Minimum PIN Length**: 10 characters (recommend 16+ for AMD Zen 2/3 due to CVE vulnerability)
- **PIN Character Set**: Alphanumeric + symbols + spaces
- **Standard Users**: Cannot change PIN
- **Non-OS Drives**: Auto-unlock with same algorithm
- **Hibernate**: Full (not reduced) -- ensures RAM contents written to encrypted disk
- **DMA Protection**: Disabled if Kernel DMA Protection available (higher security bar)
- **Recovery Info**: Saved to `C:\BitLocker-Recovery-Info-All-Drives.txt`

### 1.5 User Account Control (UAC)

- **Admin Elevation Behavior**: Prompt for credentials on secure desktop (all binaries, not just non-Windows)
- **Standard User Elevation**: Prompt for credentials on secure desktop
- **Only Elevate Signed Executables**: Enforced (cryptographic signature validation required)
- **Fast User Switching**: Hidden (prevents "Forgot PIN" recovery -- hardening trade-off)
- **Administrator Protection**: Admin Approval Mode with enhanced privilege protection (Windows 11 2025+)

### 1.6 Windows Firewall

- **All Profiles**: Enabled (Domain, Private, Public)
- **Default Network Location**: Public (least trust)
- **Logging**: Max 32.767 MB per profile, separate log files
- **Multicast DNS (mDNS)**: Disabled on all profiles
- **Inbound Block Notifications**: Enabled for all profiles

**Blocked Dual-Use LOLBins (Living Off The Land Binaries)**:

Both System32 and SysWOW64 versions blocked for network access:
```
bitsadmin.exe, certreq.exe, certutil.exe, cmstp.exe, cmd.exe,
cscript.exe, forfiles.exe, hh.exe, mshta.exe, msiexec.exe,
netsh.exe, presentationhost.exe, reg.exe, regsvr32.exe,
rundll32.exe, schtasks.exe, wscript.exe, wmic.exe, xwizard.exe,
powershell.exe
```

### 1.7 Windows Networking

- **NetBIOS over TCP/IP**: Disabled on all interfaces
- **LLMNR**: Disabled (via Smart Multi-Homed Name Resolution disable)
- **LMHOSTS Lookup**: Disabled
- **Printing over HTTP**: Disabled
- **Remote Registry Paths**: Cleared (all entries removed)
- **SMB Minimum Version**: 3.1.1 (both client and server)
- **NTLM**: Completely blocked (incoming, outgoing, SMB)
- **SMB Encryption**: Required (both client and server)
- **SMB over QUIC**: Enabled (modern encrypted alternative)

### 1.8 TLS Security (Schannel)

**Disabled Protocols**: TLS 1.0, TLS 1.1
**Disabled Hashing**: MD5
**Disabled Ciphers**: DES 56, RC2 (40/56/128), RC4 (40/56/64/128), 3DES 168

**Allowed Cipher Suites (ordered)**:
```
TLS_CHACHA20_POLY1305_SHA256
TLS_AES_256_GCM_SHA384
TLS_AES_128_GCM_SHA256
TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384
TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256
TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256
TLS_DHE_RSA_WITH_AES_256_GCM_SHA384
TLS_DHE_RSA_WITH_AES_128_GCM_SHA256
```

**ECC Curve Order**: nistP521, curve25519, NistP384, NistP256

### 1.9 Exploit Protection (Process Mitigations)

Applied to Edge, Quick Assist, Microsoft 365 apps, system processes:
- Blocking low integrity images
- Blocking remote images
- Blocking untrusted fonts
- Strict Control Flow Guard (CFG)
- Disabling extension points
- Export Address Filtering (EAF)
- Hardware-enforced stack protection
- Import Address Filtering (IAF)
- Validate handle usage
- Validate stack integrity
- Code Integrity Guard (CIG)
- Arbitrary Code Guard (ACG)

### 1.10 Miscellaneous Hardening

- **Optional Windows Features**: Remove unnecessary features (legacy protocols, SMBv1, etc.)
- **Lock Screen**: Hardened with recovery password protections
- **Windows Update**: Configured for rapid patching
- **Edge Browser**: Security-hardened configuration
- **Certificate Checking**: Validation enforcement
- **Country IP Blocking**: Geo-based firewall rules
- **Non-Admin Measures**: User-level hardening without admin privileges
- **Audit Policies**: Comprehensive event logging configuration

---

## 2. WDAC / APP CONTROL POLICIES

Source: Harden-Windows-Security App Control documentation

### 2.1 Core Concepts

- **App Control = WDAC (Windows Defender Application Control)** = Code Integrity enforcement
- **Trust enforcement, not threat detection**: if not explicitly permitted, execution blocked
- **Operates at kernel level**: enforced early in boot process via Code Integrity component
- **Zero-day immune**: does not rely on signatures/heuristics; only allows pre-authorized code

### 2.2 Policy Types

| Type | Standalone | Deny Rules | Signed | Notes |
|------|-----------|-----------|--------|-------|
| Base Policy | Yes | Yes | Yes | Cannot be removed without certificate if signed |
| Supplemental Policy | No (needs base) | No | Yes | Adds allow rules to base |
| AppID Tagging | Yes | No | Yes | Tags files for other programs; user-mode only |

### 2.3 Rule Levels (Weakest to Strongest)

1. **Hash** -- SHA256 Authenticode hash of specific file (most restrictive)
2. **FileName** -- Original filename from PE header
3. **FilePath** -- File system location
4. **SignedVersion** -- Publisher + version minimum
5. **Publisher** -- Certificate CN + EKU
6. **PCACertificate** -- Issuing CA certificate
7. **LeafCertificate** -- End-entity signing certificate
8. **WHQLFilePublisher** -- WHQL-certified with publisher info
9. **WHQLPublisher** -- WHQL-certified publisher
10. **WHQL** -- Any WHQL-certified driver

### 2.4 BYOVD (Bring Your Own Vulnerable Driver) Protection

**The problem**: Signed kernel drivers with vulnerabilities can be exploited to gain kernel access. EV certificates cost ~$100/year and require minimal verification. This is a cross-OS attack vector.

**The solution**: Strict Kernel-Mode App Control Policy
- Remove default trust to ALL kernel drivers (including WHQL)
- Whitelist only specific authorized drivers
- Deploy in Audit mode first to discover required drivers
- Blocks all BYOVD scenarios by eliminating implicit trust
- Microsoft Recommended Driver Block Rules + Microsoft Recommended Block Rules enforced

**Driver categories blocked by default**:
1. Regular signed drivers (3rd party SPC certificates)
2. WHQL certified drivers (Microsoft-tested but still 3rd party)
3. EV signed drivers (Extended Validation -- still obtainable by anyone)

### 2.5 Smart App Control

- Automated WDAC for consumer devices
- Uses Microsoft Intelligent Security Graph (ISG) + AI
- Enforces Microsoft Recommended Driver Block Rules
- Enforces Microsoft Recommended Block Rules
- Classifies apps as "known good", "known bad", or "unknown"
- Requires optional diagnostic data telemetry for ISG communication

### 2.6 Script Enforcement & Constrained Language Mode

- WDAC can enforce PowerShell Constrained Language Mode (CLM)
- Prevents access to full .NET framework, COM objects, Win32 APIs
- Scripts must be signed to run in Full Language Mode
- Blocks PowerShell-based attack tools (Empire, PowerSploit, etc.)

### 2.7 Signed Policy Strength

- Signed WDAC policies cannot be removed without access to the signing certificate
- Even local administrators cannot bypass signed policies
- Provides protection against administrator-level compromise
- Combined with UEFI Lock: requires physical access to UEFI to disable Secure Boot first

---

## 3. WINDOWS PRIVILEGE ESCALATION VECTORS

Source: PrivescCheck (itm4n)

### 3.1 Service-Based Escalation

| Check | Description | Severity |
|-------|-------------|----------|
| ServiceRegistryPermission | Non-default service registry keys writable by current user | High |
| ServiceUnquotedPath | Service image path with spaces not quoted; exploitable via path interception | High |
| ServiceImagePermission | Service binary writable by current user; replace with malicious binary | High |
| ServicePermission | Service object ACL allows user to change configuration (image path, start type) | High |
| ServiceControlManagerPermission | SCM ACL allows user to create new services | High |
| ThirdPartyDriver | Non-Microsoft kernel drivers (potential BYOVD targets) | Info |
| VulnerableDriver | Known vulnerable drivers present on system | High |
| ServiceCredential | Service configured with clear-text credentials | Medium |
| NamedKernelDevice | Named kernel objects with weak permissions | Medium |

### 3.2 Credential Exposure

| Check | Description | Severity |
|-------|-------------|----------|
| WinLogonCredential | Credentials stored in WinLogon registry (DefaultPassword) | High |
| CredentialMasterKey | DPAPI master keys accessible by current user | Medium |
| CredentialFile | DPAPI credential files readable by current user | Medium |
| CredentialCheck | Windows Credential Manager vault entries | Info |
| VaultCheck | Windows Vault stored credentials | Info |
| GPPCredential | Group Policy Preferences with embedded cpassword (MS14-025) | High |
| PowerShellHistoryCredential | Credentials in PSReadLine history files | Medium |
| HiveFilePermission | SAM/SYSTEM/SECURITY hive file permissions (shadow copies) | High |
| UnattendFileCredential | Unattend.xml, sysprep.xml with clear-text passwords | High |
| SccmNaaCredential | SCCM Network Access Account credentials | High |
| SccmCacheFolderCredential | SCCM cache folder with sensitive content | Medium |
| SmaAgentConnectivityCredential | Azure SMA agent stored credentials | Medium |
| ScomRunAsAccountCredential | SCOM Run-As account credentials | Medium |
| VncCredential | VNC stored credentials (weak encryption) | Medium |
| PersonalCertificate | Exportable personal certificates with private keys | Medium |

### 3.3 Configuration Weaknesses

| Check | Description | Severity |
|-------|-------------|----------|
| AlwaysInstallElevated | MSI packages install with SYSTEM privileges | High |
| WsusConfiguration | WSUS using HTTP (not HTTPS) -- WSUS hijacking | High |
| HardenedUNCPath | UNC paths not hardened -- NTLM relay potential | Medium |
| DllHijacking | DLL search order hijacking opportunities | High |
| PointAndPrintConfiguration | Print driver installation without admin (PrintNightmare variant) | High |
| DriverCoInstaller | Driver co-installer disabled check | Medium |
| SccmCacheFolder | SCCM cache folder with modifiable content | Medium |
| ProxyAutoConfiguration | WPAD/PAC file proxy configuration (relay attack surface) | Medium |
| DefenderExclusion | Defender exclusion paths (can hide malware) | Medium |
| DefenderForEndpointConfiguration | MDE configuration weaknesses | Info |
| SmbConfiguration | SMB signing/encryption not enforced | Medium |
| ComServerRegistryPermission | COM server registry keys writable | High |
| ComServerImagePermission | COM server binary writable | High |
| ComServerGhostDllHijacking | COM servers with DLL hijacking via phantom DLLs | High |
| ComServerMissingModuleFile | COM servers referencing non-existent modules | Medium |
| MsiAutomaticRepairUacPrompt | MSI repair running as SYSTEM without UAC | High |
| MsiAutomaticRepairWhitelist | MSI repair whitelist manipulation | High |
| CredentialDelegation | Credential delegation misconfiguration | Medium |
| NtlmDowngradeAttack | NTLM authentication downgrade possibilities | Medium |

### 3.4 Hardening Assessment

| Check | Description | What It Validates |
|-------|-------------|-------------------|
| UserAccountControl | UAC configuration level | FilterAdministratorToken, ConsentPromptBehavior |
| Laps | LAPS (Local Admin Password Solution) deployment | LAPS v1 and v2 |
| PowerShellSecurity | PS transcription, script block logging, CLM | Logging and language mode |
| BitLocker | BitLocker encryption status | All drives encrypted |
| LsaProtection | LSA RunAsPPL status | PPL enabled for lsass.exe |
| CredentialGuard | Credential Guard status | VBS-based credential isolation |
| BiosMode | UEFI vs Legacy BIOS | Secure Boot chain |
| AppLocker | AppLocker/WDAC policy presence | Application whitelisting |
| AppLockerPolicy | AppLocker rule analysis | Bypassable rules |
| FileExtensionAssociation | Dangerous default file associations | .hta, .js, .vbs, .wsh, etc. |
| HiddenFilenameExtension | Hidden file extensions setting | Social engineering risk |
| AttackSurfaceReductionRule | ASR rule configuration | All 19 rules checked |
| NameResolutionProtocol | LLMNR/NetBIOS/mDNS status | Poisoning attack surface |
| Ipv6Configuration | IPv6 configuration | IPv6-based attacks |
| DefaultLocalAdministratorAccount | Default admin account enabled | Account renamed/disabled |
| ClickOnceTrustPrompt | .NET ClickOnce trust behavior | Code execution via ClickOnce |
| OfficeMacroConfiguration | Office macro security settings | VBA macro restrictions |
| OfficeProtectedView | Office Protected View status | Sandbox for external docs |
| OfficeTrustedLocations | Office Trusted Locations paths | Bypass of macro security |

### 3.5 Application & Filesystem

| Check | Description |
|-------|-------------|
| InstalledApplicationPermission | Installed app directories writable by current user |
| ProgramDataPermission | ProgramData directories with weak ACLs |
| StartupApplicationPermission | Startup folder/registry autoruns writable |
| RootFolderPermission | Root of drives (C:\) writable -- DLL planting |
| HijackableDll | Known DLLs susceptible to hijacking |
| NamedPipePermission | Named pipes with weak ACLs |
| ExploitableLeakedHandle | Process handles leaked to lower-privilege processes |
| MsiCustomAction | MSI custom actions running as SYSTEM |
| ProcessAndThreadPermission | Process/thread objects with exploitable permissions |

### 3.6 Exploitable Privileges

Privileges that enable escalation to SYSTEM (from PrivescCheck Globals):

```
SeAssignPrimaryTokenPrivilege    -- Token manipulation (Potato attacks)
SeImpersonatePrivilege           -- Token impersonation (Potato attacks)
SeCreateTokenPrivilege           -- Create arbitrary tokens
SeDebugPrivilege                 -- Debug any process (inject into SYSTEM)
SeLoadDriverPrivilege            -- Load kernel drivers (BYOVD)
SeRestorePrivilege               -- Write any file (DLL overwrite)
SeTakeOwnershipPrivilege         -- Take ownership of any object
SeTcbPrivilege                   -- Act as part of the OS
SeBackupPrivilege                -- Read any file (SAM/SYSTEM dump)
SeManageVolumePrivilege          -- Direct disk access
SeRelabelPrivilege               -- Modify object integrity labels
```

---

## 4. ACTIVE DIRECTORY ATTACK TECHNIQUES

Sources: adsecurity.org (Sean Metcalf), harmj0y.net (Will Schroeder), specterops.io, The Hacker Recipes

### 4.1 Kerberos Attacks

#### Kerberoasting (T1558.003)
- **What**: Request TGS tickets for SPNs, crack offline
- **Tools**: Rubeus (`kerberoast`), Impacket (`GetUserSPNs.py`), PowerView
- **Target**: Service accounts with SPNs and weak passwords
- **Detection**: Event 4769 (TGS request) with RC4 encryption type (0x17), anomalous volume
- **Mitigation**: gMSAs (128-char auto-rotating passwords), AES-only encryption, 25+ char passwords for service accounts

#### AS-REP Roasting (T1558.004)
- **What**: Request AS-REP for accounts without pre-authentication, crack offline
- **Tools**: Rubeus (`asreproast`), Impacket (`GetNPUsers.py`)
- **Target**: Accounts with "Do not require Kerberos preauthentication" flag
- **Detection**: Event 4768 (TGT request) without preceding pre-auth, RC4 encryption
- **Mitigation**: Enable pre-authentication on ALL accounts, audit DONT_REQUIRE_PREAUTH flag

#### Golden Ticket (T1558.001)
- **What**: Forge TGT using krbtgt NTLM hash -- complete domain compromise
- **Tools**: Mimikatz (`kerberos::golden`), Impacket (`ticketer.py`)
- **Prerequisites**: krbtgt hash (via DCSync, NTDS.dit extraction)
- **Detection**: TGT with anomalous lifetime, encryption type mismatch, Event 4769 from non-DC
- **Mitigation**: Reset krbtgt password twice (double-reset), monitor for DCSync

#### Silver Ticket (T1558.002)
- **What**: Forge TGS using service account NTLM hash -- access specific service
- **Tools**: Mimikatz (`kerberos::golden /service:`), Impacket
- **Advantage**: Never touches DC -- harder to detect
- **Detection**: PAC validation failures, anomalous service ticket properties
- **Mitigation**: PAC validation enforcement, service account password rotation

#### Diamond Ticket
- **What**: Modify legitimate TGT rather than forge from scratch
- **Tools**: Rubeus (`diamond`)
- **Advantage**: More realistic ticket, harder to detect than Golden Ticket
- **Detection**: PAC anomalies, modified ticket fields

#### Delegation Abuse (T1550)

**Unconstrained Delegation**:
- Servers with TRUSTED_FOR_DELEGATION flag capture TGTs of connecting users
- Attacker compromises server -> extracts cached TGTs -> impersonates any user
- Combine with PrinterBug/PetitPotam to coerce DC authentication
- Tools: Rubeus (`monitor`), SpoolSample, PetitPotam

**Constrained Delegation (S4U2Self/S4U2Proxy)**:
- Accounts with msDS-AllowedToDelegateTo can impersonate users to specific services
- S4U2Self: obtain ticket on behalf of any user
- S4U2Proxy: forward ticket to allowed service
- Tools: Rubeus (`s4u`), Impacket (`getST.py`)

**Resource-Based Constrained Delegation (RBCD)**:
- Controlled by target resource's msDS-AllowedToActOnBehalfOfOtherIdentity
- Any user who can modify this attribute on a computer can configure delegation
- Common attack: create machine account (MachineAccountQuota) -> set RBCD -> S4U chain
- Tools: Rubeus, PowerMad, Impacket

### 4.2 Credential Attacks

#### DCSync (T1003.006)
- **What**: Replicate domain credentials via Directory Replication Service (DRS)
- **Tools**: Mimikatz (`lsadump::dcsync`), Impacket (`secretsdump.py`)
- **Required Privileges**: Replicating Directory Changes + Replicating Directory Changes All
- **Detection**: Event 4662 with DS-Replication-Get-Changes-All, non-DC source
- **Mitigation**: Restrict replication rights, monitor Events 4662

#### DCShadow (T1207)
- **What**: Register rogue domain controller, push changes via replication
- **Tools**: Mimikatz (`lsadump::dcshadow`)
- **Stealth**: Changes appear as legitimate DC replication
- **Detection**: Monitor new SPN registrations with DC GUIDs, anomalous nTDSDSA objects

#### LSASS Credential Dumping (T1003.001)
- **What**: Extract credentials from LSASS process memory
- **Tools**: Mimikatz (`sekurlsa::logonpasswords`), pypykatz, comsvcs.dll MiniDump
- **Mitigations**: Credential Guard, LSA Protection (RunAsPPL), ASR rule for LSASS, disable WDigest
- **Detection**: Process access to lsass.exe (Sysmon Event 10), suspicious MiniDumpWriteDump calls

#### NTDS.dit Extraction (T1003.003)
- **What**: Copy Active Directory database file for offline credential extraction
- **Tools**: `ntdsutil`, Volume Shadow Copy, Impacket `secretsdump.py`
- **Detection**: VSS creation events, ntdsutil execution, suspicious file access on DCs

#### Pass-the-Hash (T1550.002)
- **What**: Authenticate using NTLM hash without knowing password
- **Tools**: Mimikatz (`sekurlsa::pth`), Impacket (`psexec.py`, `wmiexec.py`)
- **Mitigation**: Disable NTLM, use Credential Guard, enforce Kerberos

#### Pass-the-Ticket (T1550.003)
- **What**: Reuse stolen Kerberos tickets for authentication
- **Tools**: Mimikatz (`kerberos::ptt`), Rubeus (`ptt`)
- **Detection**: Ticket reuse from different IPs, anomalous logon patterns

#### Overpass-the-Hash
- **What**: Use NTLM hash to request Kerberos TGT
- **Tools**: Mimikatz (`sekurlsa::pth /run:`), Rubeus (`asktgt`)
- **Advantage**: Bypasses NTLM-only monitoring

### 4.3 ACL/ACE Abuse (T1222)

**Dangerous AD Permissions**:

| Permission | Abuse Scenario |
|-----------|---------------|
| GenericAll | Full control -- reset password, modify group membership, set SPN |
| GenericWrite | Modify attributes -- set SPN (Kerberoast), modify delegation |
| WriteDACL | Grant yourself any permission on the object |
| WriteOwner | Take ownership, then WriteDACL |
| ForceChangePassword | Reset user password without knowing current |
| AddMember | Add self/controlled account to privileged group |
| ReadLAPSPassword | Read local admin password (LAPS) |
| WriteProperty on msDS-AllowedToActOnBehalfOfOtherIdentity | Set RBCD |
| WriteProperty on msDS-KeyCredentialLink | Shadow Credentials attack |

**Tools**: BloodHound (attack path mapping), PowerView, ADExplorer, ldapsearch

### 4.4 ADCS (Active Directory Certificate Services) Attacks

Source: "Certified Pre-Owned" research (Will Schroeder & Lee Christensen)

#### ESC1 -- Enrollee Supplies Subject
- Template allows requestor to specify Subject Alternative Name (SAN)
- Attacker requests cert with Domain Admin SAN
- **Mitigation**: Remove "Supply in the request" from templates, restrict enrollment

#### ESC2 -- Any Purpose EKU
- Template with "Any Purpose" or no EKU = usable for any authentication
- **Mitigation**: Remove Any Purpose EKU, define specific EKUs

#### ESC3 -- Enrollment Agent Templates
- Enrollment Agent certificate used to enroll on behalf of others
- **Mitigation**: Restrict Enrollment Agent permissions, require approval

#### ESC4 -- Vulnerable Template ACLs
- Low-privilege user can modify certificate template configuration
- Modify template to enable ESC1 conditions
- **Mitigation**: Audit template ACLs, restrict modification rights

#### ESC6 -- EDITF_ATTRIBUTESUBJECTALTNAME2 Flag
- CA configured to accept SAN in any request
- **Mitigation**: Remove flag: `certutil -config "CA" -setreg policy\EditFlags -EDITF_ATTRIBUTESUBJECTALTNAME2`

#### ESC7 -- Vulnerable CA ACLs
- User has ManageCA or ManageCertificates on CA
- Can approve pending requests, modify CA configuration
- **Mitigation**: Restrict CA permissions, require manager approval

#### ESC8 -- NTLM Relay to HTTP Enrollment
- CA web enrollment endpoint (certsrv) vulnerable to NTLM relay
- Coerce DC authentication -> relay to CA -> obtain DC certificate
- **Mitigation**: Require EPA on CA web enrollment, disable HTTP, enable HTTPS with channel binding

#### ESC11 -- IF_ENFORCEENCRYPTICERTREQUEST Not Set
- RPC enrollment without encryption allows NTLM relay
- **Mitigation**: Enable IF_ENFORCEENCRYPTICERTREQUEST on CA

**Tools**: Certipy, Certify, ForgeCert, PassTheCert

### 4.5 Coercion Attacks

#### PetitPotam (MS-EFSRPC)
- **What**: Force target to authenticate to attacker via EFS RPC
- **Usage**: Coerce DC -> NTLM relay to ADCS (ESC8) or LDAP
- **Detection**: MS-EFSRPC calls from unusual sources
- **Mitigation**: Patch, disable EFS if not needed, enable EPA

#### PrinterBug / SpoolSample (MS-RPRN)
- **What**: Force target's Print Spooler to authenticate to attacker
- **Usage**: Coerce DC -> capture TGT via unconstrained delegation
- **Detection**: SpoolSV.exe making outbound connections
- **Mitigation**: Disable Print Spooler on DCs and servers

#### ShadowCoerce (MS-FSRVP)
- **What**: File Server VSS Agent service coercion
- **Mitigation**: Disable service on non-file servers

#### DFSCoerce (MS-DFSNM)
- **What**: DFS management service coercion
- **Mitigation**: Patch, restrict DFS management access

### 4.6 Trust & Forest Attacks

#### SID History Injection (T1134.005)
- Add Enterprise Admin SID to SID history of compromised user
- Allows cross-trust privilege escalation
- **Mitigation**: SID Filtering on trusts, monitor SID history modifications

#### Forest Trust Abuse
- Research by harmj0y: "Not A Security Boundary: Breaking Forest Trusts"
- Foreign Security Principal exploitation across forest boundaries
- **Mitigation**: Audit FSP membership in privileged groups, SID filtering

#### PAM Trust (Privileged Access Management)
- Shadow principals in bastion forest
- If bastion compromised, all trusting forests compromised

### 4.7 Lateral Movement Techniques

| Technique | Protocol | Detection |
|-----------|----------|-----------|
| PSExec | SMB (445) + SCM | Service creation Event 7045, named pipe |
| WMI | DCOM (135) + WMI | Event 4688 process creation from WmiPrvSE.exe |
| WinRM/PS Remoting | HTTP (5985/5986) | Event 4688 from wsmprovhost.exe |
| DCOM Execution | DCOM (135) | Event 4688 from mmc.exe, excel.exe, etc. |
| RDP | RDP (3389) | Event 4624 Type 10, 1149 |
| smbexec | SMB + Service | Similar to PSExec |
| atexec | SMB + Task Scheduler | Scheduled task creation Event 4698 |
| SSH | SSH (22) | Event 4688 from sshd.exe |

### 4.8 DPAPI Abuse

Source: SpecterOps "Offensive DPAPI with Nemesis"

- DPAPI protects credentials, browser data, Wi-Fi passwords, etc.
- Master key decrypts protected data
- Domain backup key can decrypt any user's master key
- **Tools**: Mimikatz (`dpapi::masterkey`, `dpapi::chrome`), SharpDPAPI, Nemesis
- **Attack Chain**: DCSync domain backup key -> decrypt all user master keys -> access all DPAPI-protected data

### 4.9 NTLM Relay Attacks

Source: SpecterOps "The Renaissance of NTLM Relay Attacks"

- **NTLM relay to LDAP**: Modify AD objects, add computer accounts, set RBCD
- **NTLM relay to ADCS**: Obtain certificates for authentication
- **NTLM relay to SMB**: Execute commands on relay target
- **NTLM relay to MSSQL**: Execute queries on SQL servers
- **Tools**: Impacket (`ntlmrelayx.py`), Responder
- **Mitigation**: Disable NTLM (Section 1.7), enable EPA, SMB signing, LDAP signing/channel binding

### 4.10 Shadow Credentials (msDS-KeyCredentialLink)

- Write to msDS-KeyCredentialLink attribute on user/computer
- Configure key for PKINIT pre-authentication
- Obtain TGT for target without knowing password
- **Tools**: Whisker, pyWhisker, Certipy
- **Prerequisite**: GenericWrite or WriteProperty on target

---

## 5. ACTIVE DIRECTORY HARDENING & DETECTION

### 5.1 Critical GPO Settings for AD Security

#### Authentication Hardening
```
Computer Configuration > Policies > Windows Settings > Security Settings
> Local Policies > Security Options:

- Network security: LAN Manager auth level = Send NTLMv2 response only. Refuse LM & NTLM
- Network security: Minimum session security for NTLM = Require NTLMv2, Require 128-bit
- Network security: Restrict NTLM: Incoming NTLM traffic = Deny all accounts
- Network security: Restrict NTLM: Outgoing NTLM traffic = Deny all
- Network security: Restrict NTLM: NTLM authentication in this domain = Deny all
- Network security: LDAP client signing requirements = Require signing
```

#### Credential Protection
```
- Interactive logon: Number of previous logons to cache = 0 (on servers)
- Network access: Do not allow storage of passwords for network auth = Enabled
- WDigest Authentication = Disabled (registry: UseLogonCredential = 0)
- Credential Delegation: Restrict delegation of credentials = Enabled (CredSSP)
```

#### Kerberos Hardening
```
- Maximum lifetime for user ticket = 4 hours (reduce from default 10)
- Maximum lifetime for service ticket = 600 minutes
- Maximum tolerance for clock synchronization = 5 minutes
- Enforce user logon restrictions = Enabled
- AES256_HMAC_SHA1 only for supported accounts (disable RC4)
```

#### Domain Controller Hardening
```
- Domain controller: LDAP server signing requirements = Require signing
- Domain controller: LDAP server channel binding token requirements = Always
- Domain controller: Refuse machine account password changes = Disabled
- Audit Policy: DS Access > Audit Directory Service Replication = Success, Failure
```

### 5.2 Tiered Administration Model

| Tier | Assets | Admin Accounts |
|------|--------|---------------|
| Tier 0 | Domain Controllers, ADCS, AD, ADFS | Domain Admins, Enterprise Admins |
| Tier 1 | Member Servers, Applications | Server Admins |
| Tier 2 | Workstations, User Devices | Workstation Admins |

**Rules**:
- Tier 0 credentials NEVER used on Tier 1 or 2 systems
- Privileged Access Workstations (PAWs) for Tier 0 admin
- Jump servers between tiers with MFA
- Clean Source principle: admin trusts only upward, never downward

### 5.3 Service Account Security

- **gMSAs (Group Managed Service Accounts)**: 128-character auto-rotating passwords, no manual management
- **Remove unnecessary SPNs**: Reduces Kerberoasting surface
- **Disable delegation where not needed**: Prevents delegation abuse
- **Deny logon rights**: Service accounts should be denied interactive/RDP logon
- **Minimum 25+ character passwords**: For non-gMSA service accounts

### 5.4 LAPS (Local Admin Password Solution)

- **LAPS v2**: Encrypted passwords in AD, password rotation per machine
- Prevents lateral movement via shared local admin passwords
- Audit who has ReadLAPSPassword rights
- Ensure every workstation and server has LAPS deployed

### 5.5 Critical Detection Events

| Event ID | Source | What It Detects |
|----------|--------|-----------------|
| 4624 | Security | Logon events (Type 3=Network, 10=RDP) |
| 4625 | Security | Failed logon (brute force, spray) |
| 4662 | Security | Operation on AD object (DCSync detection) |
| 4663 | Security | Object access (file access) |
| 4672 | Security | Special privileges assigned (admin logon) |
| 4688 | Security | Process creation (with command line) |
| 4698 | Security | Scheduled task created |
| 4720 | Security | User account created |
| 4728 | Security | Member added to security-enabled global group |
| 4732 | Security | Member added to security-enabled local group |
| 4756 | Security | Member added to security-enabled universal group |
| 4768 | Security | TGT requested (AS-REP roast detection: no pre-auth) |
| 4769 | Security | TGS requested (Kerberoast: RC4 encryption type) |
| 4771 | Security | Kerberos pre-auth failed |
| 4776 | Security | NTLM authentication attempt |
| 5136 | Security | Directory service object modified |
| 5145 | Security | Network share access |
| 7045 | System | Service installed (PSExec detection) |
| 1102 | Security | Audit log cleared (anti-forensics) |
| Sysmon 1 | Sysmon | Process creation with hashes |
| Sysmon 3 | Sysmon | Network connection |
| Sysmon 7 | Sysmon | Image loaded (DLL hijacking) |
| Sysmon 8 | Sysmon | CreateRemoteThread (injection) |
| Sysmon 10 | Sysmon | Process access (LSASS access) |
| Sysmon 11 | Sysmon | File created |
| Sysmon 13 | Sysmon | Registry value set |
| Sysmon 22 | Sysmon | DNS query |

### 5.6 Sigma Rules for Key Detections

#### DCSync Detection
```yaml
title: Potential DCSync Attack via Directory Replication
id: a]f3c078-d6c0-4f92-93c8-c89d6ee0b7e1
status: stable
description: Detects directory replication requests from non-DC sources indicating DCSync
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 4662
    Properties|contains:
      - '1131f6aa-9c07-11d1-f79f-00c04fc2dcd2'  # DS-Replication-Get-Changes
      - '1131f6ad-9c07-11d1-f79f-00c04fc2dcd2'  # DS-Replication-Get-Changes-All
  filter:
    SubjectUserName|endswith: '$'
    # Filter out known DCs
  condition: selection and not filter
level: high
tags:
  - attack.credential_access
  - attack.t1003.006
```

#### Kerberoasting Detection
```yaml
title: Kerberoasting Activity - RC4 TGS Request
id: b8f4d5c0-7a7b-4eae-b1f0-3a9ec5b07e0d
status: stable
description: Detects TGS requests using RC4 encryption which may indicate Kerberoasting
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 4769
    TicketEncryptionType: '0x17'  # RC4
  filter:
    ServiceName|endswith: '$'  # Machine accounts
  condition: selection and not filter
falsepositives:
  - Legacy applications requiring RC4
level: medium
tags:
  - attack.credential_access
  - attack.t1558.003
```

---

## 6. ANTI-DEBUGGING & ANTI-VM TECHNIQUES

Source: al-khaser (LordNoteworthy)

### 6.1 Anti-Debugging Techniques

#### API-Based Detection
| Technique | API/Method | Mechanism |
|-----------|-----------|-----------|
| IsDebuggerPresent | kernel32 | Checks PEB.BeingDebugged flag |
| CheckRemoteDebuggerPresent | kernel32 | Queries NtQueryInformationProcess |
| NtQueryInformationProcess | ntdll | ProcessDebugPort (0x7), ProcessDebugFlags (0x1f), ProcessDebugObject (0x1e) |
| NtQueryObject | ntdll | Enumerate DebugObject types (ObjectAllTypesInformation) |
| WudfIsAnyDebuggerPresent | wudfplatform | UWP debugger detection |

#### PEB-Based Detection
| Technique | Field | Description |
|-----------|-------|-------------|
| BeingDebugged | PEB+0x02 | Set to 1 by debugger |
| NtGlobalFlag | PEB+0x68/0xBC | Set to 0x70 (FLG_HEAP_ENABLE_TAIL_CHECK \| FLG_HEAP_ENABLE_FREE_CHECK \| FLG_HEAP_VALIDATE_PARAMETERS) |
| ProcessHeap Flags | PEB.ProcessHeap+0x0C | Non-zero when debugging |
| ProcessHeap ForceFlags | PEB.ProcessHeap+0x10 | Non-zero when debugging |
| Low Fragmentation Heap | Heap properties | LFH disabled under debugger |

#### Exception-Based Detection
| Technique | Description |
|-----------|-------------|
| INT3 (0xCC) | Software breakpoint detection via SEH |
| INT 0x2D | Kernel-mode anti-debug interrupt |
| INT 1 | Single-step trap detection |
| Trap Flag | Set TF in EFLAGS, detect single-step handler |
| UnhandledExceptionFilter | Filter not called when debugger present |
| PAGE_GUARD | Memory breakpoint detection via guard page exceptions |

#### Handle-Based Detection
| Technique | Description |
|-----------|-------------|
| CloseHandle (invalid) | Exception in debugger, silent fail otherwise |
| SetHandleInformation | Protected handle detection |

#### Context-Based Detection
| Technique | Description |
|-----------|-------------|
| Hardware breakpoints | GetThreadContext -> check DR0-DR3 registers |
| Parent process check | Verify parent is explorer.exe, not debugger |
| SeDebugPrivilege | Open csrss.exe -- success indicates debug privilege |

#### Process Environment Detection
| Technique | Description |
|-----------|-------------|
| NtSetInformationThread | HideThreadFromDebugger -- detach debugger from thread |
| NtYieldExecution | Returns differently under debugger |
| Process Jobs | Job object restrictions can detect sandboxing |
| Memory write watching | GetWriteWatch behavior changes under debugging |
| API hook detection | Module bounds check for hooked functions |
| OutputDebugString | GetLastError behavior differs under debugger |

### 6.2 Anti-VM Detection

#### Registry Artifacts
**VirtualBox**:
```
HARDWARE\ACPI\DSDT\VBOX__
HARDWARE\ACPI\FADT\VBOX__
HARDWARE\ACPI\RSDT\VBOX__
SOFTWARE\Oracle\VirtualBox Guest Additions
SYSTEM\ControlSet001\Services\VBox{Guest,Mouse,Service,SF,Video}
HARDWARE\Description\System\SystemBiosVersion = "VBOX"
HARDWARE\Description\System\VideoBiosVersion = "VIRTUALBOX"
```

**VMware**:
```
SOFTWARE\VMware, Inc.\VMware Tools
SYSTEM\ControlSet001\Control\SystemInformation\SystemManufacturer = "VMWARE"
HARDWARE\DEVICEMAP\Scsi\...\Identifier = "VMWARE"
```

**Hyper-V**:
```
SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters
```

#### File System Artifacts
**VirtualBox**: `VBoxMouse.sys, VBoxGuest.sys, VBoxSF.sys, vboxservice.exe, vboxtray.exe`
**VMware**: `vmmouse.sys, vmhgfs.sys, vm3dmp.sys, vmci.sys, vmtoolsd.exe, vmwaretray.exe`

#### MAC Address Prefixes
| Vendor | MAC Prefix |
|--------|-----------|
| VirtualBox | 08:00:27 |
| VMware | 00:05:69, 00:0C:29, 00:1C:14, 00:50:56 |
| Parallels | 00:1C:42 |
| Xen | 00:16:3E |
| Hybrid Analysis | 0A:00:27 |

#### CPU-Based Detection
- **CPUID EAX=0x01**: Hypervisor present bit (ECX bit 31)
- **CPUID EAX=0x40000000**: Hypervisor vendor string
  - `KVMKVMKVM\0\0\0` (KVM)
  - `Microsoft Hv` (Hyper-V)
  - `VMwareVMware` (VMware)
  - `XenVMMXenVMM` (Xen)
  - `prl hyperv  ` (Parallels)
  - `VBoxVBoxVBox` (VirtualBox)

#### Memory & Descriptor Table Tricks
- IDT (Interrupt Descriptor Table) location check
- LDT (Local Descriptor Table) location check
- GDT (Global Descriptor Table) location check
- STR (Store Task Register) instruction

#### Firmware Table Analysis (SMBIOS/ACPI)
- SMBIOS string checks for VM vendor names
- ACPI table analysis (WAET, PNP devices)
- Battery/power state checks (VMs often lack battery)
- Fan/thermal sensor absence

#### WMI Queries
```sql
SELECT * FROM Win32_Bios (SerialNumber)
SELECT * FROM Win32_PnPEntity (DeviceId contains VBOX/VMWARE)
SELECT * FROM Win32_NetworkAdapterConfiguration (MAC Address)
SELECT * FROM Win32_Processor (NumberOfCores, ProcessorId)
SELECT * FROM Win32_LogicalDisk (Size < 60GB suspicious)
SELECT * FROM Win32_ComputerSystem (Model/Manufacturer)
SELECT * FROM MSAcpi_ThermalZoneTemperature (absent in VMs)
SELECT * FROM Win32_Fan (absent in VMs)
```

### 6.3 Timing Attacks (Anti-Sandbox)

| Technique | Method |
|-----------|--------|
| RDTSC | Read Time-Stamp Counter with CPUID-forced VM exit |
| Sleep acceleration | Sleep then check GetTickCount for time acceleration |
| SetTimer | Windows timer callbacks for delay |
| Multimedia timers | timeSetEvent for precise delays |
| WaitForSingleObject | Wait with timing verification |
| IcmpSendEcho | Network delay as sleep alternative (CCleaner technique) |
| CreateWaitableTimer | Waitable timer objects |
| CreateTimerQueueTimer | Timer queue for extended delays |

### 6.4 Anti-Analysis (Tool Detection)

Processes monitored for analysis tools:
```
Debuggers: OllyDBG, ImmunityDebugger, WinDbg, IDA Pro, x64dbg, Cheat Engine
SysInternals: Process Explorer, Process Monitor, Regmon, Filemon, TCPView, Autoruns
Network: Wireshark, Dumpcap, Fiddler, HTTP Debugger
Analysis: ProcessHacker/System Informer, SysAnalyzer, HookExplorer, SysInspector
PE Tools: ImportREC, PETools, LordPE, Resource Hacker
Dynamic: Frida, JoeBox Sandbox
```

### 6.5 Anti-Dumping

- **Erase PE header from memory**: Overwrite DOS/PE headers post-load
- **SizeOfImage manipulation**: Modify SizeOfImage to break dump tools

### 6.6 Anti-Disassembly

| Technique | Description |
|-----------|-------------|
| Jump with constant condition | Opaque predicate forces wrong path in disassembler |
| Jump with same target | Two jumps to same address confuse linear disassembly |
| Impossible disassembly | Overlapping instructions create ambiguous decode |
| Function pointers | Indirect calls obscure control flow |
| Return pointer abuse | Modify return address on stack |

### 6.7 Code Injection Techniques

| Technique | API | T-Code |
|-----------|-----|--------|
| CreateRemoteThread | kernel32!CreateRemoteThread | T1055.001 |
| SetWindowsHookEx | user32!SetWindowsHookEx | T1055.003 |
| NtCreateThreadEx | ntdll!NtCreateThreadEx | T1055.001 |
| RtlCreateUserThread | ntdll!RtlCreateUserThread | T1055.001 |
| APC Injection | QueueUserAPC / NtQueueApcThread | T1055.004 |
| Process Hollowing | GetThreadContext / SetThreadContext | T1055.012 |

---

## 7. OBFUSCATION & EVASION TECHNIQUES

Source: BC-Security Beginners Guide to Obfuscation

### 7.1 Key Concepts

- **AMSI (Antimalware Scan Interface)**: Microsoft's scan interface for scripts (PowerShell, VBA, JavaScript, .NET)
- **ETW (Event Tracing for Windows)**: Telemetry pipeline for security events
- **Least Obfuscation Principle**: Apply minimum obfuscation needed to bypass detection

### 7.2 Detection Types

| Type | What It Checks | Bypass Method |
|------|---------------|---------------|
| Static Signature | Byte patterns in file | String manipulation, encoding, encryption |
| Dynamic Analysis | Runtime behavior | AMSI bypass, ETW patching |
| Heuristic | Behavioral patterns | Code structure modification |
| Cloud Analysis | Cloud-based ML/AI | Timing, environmental awareness |

### 7.3 AMSI Bypass Techniques

1. **amsiInitFailed**: Set amsiInitFailed flag to true in AmsiUtils class
2. **Memory patching**: Overwrite AmsiScanBuffer to always return clean
3. **Reflection**: Use .NET reflection to access non-public AmsiUtils fields
4. **CLM bypass**: Escape Constrained Language Mode to access full .NET
5. **AMSI.fail**: Automated generation of unique AMSI bypasses

### 7.4 PowerShell Obfuscation Methods

| Method | Example | Description |
|--------|---------|-------------|
| String concatenation | `"Am"+"si"+"Utils"` | Break signature strings |
| Variable substitution | `$a="Amsi"; $b="Utils"` | Indirect string construction |
| Encoding | `[Convert]::FromBase64String(...)` | Base64 encode payloads |
| Invoke-Expression | `IEX (New-Object Net.WebClient).DownloadString(...)` | Download and execute |
| Character substitution | `-replace`, `-creplace` | Modify flagged characters |
| Invoke-Obfuscation | Automated obfuscation | Token, AST, string, encoding methods |

### 7.5 Detection Evasion Workflow

1. Use ThreatCheck to identify flagged byte sequences
2. Isolate specific flagged lines/blocks
3. Apply targeted obfuscation to flagged content only
4. Use AMSITrigger to identify AMSI-specific triggers
5. Apply AMSI bypass before loading payload
6. Verify with Defender and test execution

### 7.6 Advanced Evasion

- **ETW patching**: Disable Event Tracing to prevent telemetry
- **Unhooking**: Remove EDR hooks from ntdll.dll by loading fresh copy from disk
- **Direct syscalls**: Bypass user-mode hooks by calling kernel directly
- **Process injection**: Inject into trusted process to evade behavioral analysis
- **Sleep obfuscation**: Encrypt payload in memory during sleep cycles (Ekko, Foliage)

---

## 8. REVERSE ENGINEERING METHODOLOGY

Source: mytechnotalent Reverse-Engineering

### 8.1 Analysis Approaches

| Approach | Description | When To Use |
|----------|-------------|-------------|
| Static Analysis | Examine without execution | Initial triage, safe analysis |
| Dynamic Analysis | Execute in controlled environment | Behavior analysis, unpacking |
| Hybrid | Combine both | Complex malware, packed samples |

### 8.2 Architecture Coverage

- **x86 (32-bit)**: Legacy Windows malware, shellcode
- **x64 (64-bit)**: Modern Windows malware, kernel drivers
- **ARM-32**: Mobile malware, IoT
- **ARM-64**: Modern mobile, Apple silicon
- **AVR (8-bit)**: Embedded/IoT device firmware
- **RISC-V (32-bit)**: Emerging embedded targets

### 8.3 Key Concepts for Windows RE

| Concept | Relevance |
|---------|-----------|
| PE (Portable Executable) format | All Windows executables, DLLs, drivers |
| Import Address Table (IAT) | API resolution, hooking targets |
| Export Address Table (EAT) | DLL function exports, forwarding |
| PEB (Process Environment Block) | Process information, anti-debug |
| TEB (Thread Environment Block) | Thread-local storage, stack info |
| SEH (Structured Exception Handling) | Anti-debug, anti-analysis |
| Stack frames | Function call analysis, buffer overflow |
| Heap management | Use-after-free, heap overflow |
| Calling conventions | stdcall, cdecl, fastcall, thiscall |

### 8.4 Tool Categories

| Category | Tools |
|----------|-------|
| Disassemblers | IDA Pro, Ghidra, Binary Ninja, Radare2 |
| Debuggers | x64dbg, WinDbg, OllyDbg, GDB |
| Decompilers | Hex-Rays (IDA), Ghidra decompiler |
| PE Analysis | PEBear, pestudio, CFF Explorer, PE-sieve |
| Dynamic Analysis | Process Monitor, API Monitor, Frida |
| Memory Analysis | Volatility, Rekall |
| Network Analysis | Wireshark, Fiddler, mitmproxy |
| Sandbox | ANY.RUN, Joe Sandbox, CAPE |

---

## 9. PROCESS INSPECTION & KERNEL ANALYSIS

Source: System Informer (formerly Process Hacker)

### 9.1 Capabilities

- **Process monitoring**: Real-time process creation/termination with highlighting
- **Thread inspection**: Per-thread stack traces with kernel-mode, WOW64, .NET support
- **Module enumeration**: Loaded DLLs, memory-mapped files
- **Handle inspection**: Open handles (files, registry, mutexes, events)
- **Network monitoring**: Active TCP/UDP connections per process
- **Disk I/O tracking**: Real-time disk access per process
- **Service management**: Create, edit, delete, start, stop services
- **Memory inspection**: Process memory regions, protection flags

### 9.2 Security Use Cases

| Use Case | How System Informer Helps |
|----------|--------------------------|
| Malware analysis | Process tree, DLL injection detection, hidden processes |
| LSASS protection | Monitor process access to lsass.exe |
| Service persistence | Identify unauthorized service installations |
| DLL hijacking | Verify loaded module paths and signatures |
| Handle leak detection | Identify leaked handles between processes |
| Network C2 detection | Map network connections to processes |
| Privilege audit | View token privileges per process |
| Driver analysis | Kernel driver enumeration |

### 9.3 Kernel Driver Features

- Kernel-level process and thread information
- Token and security descriptor inspection
- Direct memory read/write capabilities
- Handle duplication and closure
- Minimum OS: Windows 10+

---

## 10. DETECTION ENGINEERING REFERENCE

### 10.1 Priority Detection Matrix

| Attack | Detection Source | Confidence | T-Code |
|--------|-----------------|------------|--------|
| DCSync | Event 4662 + DS-Replication properties | High | T1003.006 |
| Kerberoasting | Event 4769 + RC4 encryption type | Medium | T1558.003 |
| Golden Ticket | Event 4769 + anomalous TGT lifetime | Medium | T1558.001 |
| LSASS dump | Sysmon 10 + lsass.exe access | High | T1003.001 |
| Pass-the-Hash | Event 4624 Type 3 + NTLM + admin | Medium | T1550.002 |
| PSExec | Event 7045 + service creation | High | T1569.002 |
| Service creation | Event 7045 + new service binary | High | T1543.003 |
| Scheduled task | Event 4698 + task creation | High | T1053.005 |
| ADCS abuse | CA audit logs + certificate requests | Medium | T1649 |
| Unconstrained deleg | Event 4624 + delegation flag | Low | T1550 |
| NTLM relay | Event 4624 + source IP mismatch | Medium | T1557.001 |
| AMSI bypass | Event 1116/1117 + AMSI detection | Medium | T1562.001 |
| ETW tampering | ETW consumer disconnect events | Medium | T1562.006 |
| ASR rule trigger | Event 1121/1122 + ASR rule ID | High | T1059 |

### 10.2 Minimum Logging Configuration

**Must-Have Audit Policies**:
```
Audit Logon Events: Success, Failure
Audit Account Logon Events: Success, Failure
Audit Object Access: Success, Failure
Audit Process Creation: Success (with command line)
Audit Privilege Use: Success, Failure
Audit Policy Change: Success, Failure
Audit Directory Service Access: Success, Failure
Audit Directory Service Changes: Success, Failure
```

**Must-Have Sysmon Configuration**:
- Process creation (Event 1) with command line and hashes
- Network connections (Event 3) for key processes
- Image loads (Event 7) for DLL monitoring
- CreateRemoteThread (Event 8) for injection
- Process access (Event 10) for LSASS protection
- File creation (Event 11) for payload drops
- Registry modifications (Event 13) for persistence
- DNS queries (Event 22) for C2 detection
- Process tampering (Event 25) for defense evasion

### 10.3 BloodHound Attack Path Priorities

| Attack Path | Risk | Remediation |
|------------|------|-------------|
| User -> GenericAll -> Domain Admin | Critical | Remove excessive ACLs |
| User -> RBCD -> Computer -> Admin | High | Restrict MachineAccountQuota to 0 |
| User -> WriteDACL -> Any -> Domain Admin | Critical | ACL audit and cleanup |
| User -> ADCS ESC1 -> Domain Admin | Critical | Fix certificate templates |
| Computer -> Unconstrained Deleg -> DC TGT | Critical | Remove unconstrained delegation |
| User -> GPO Edit -> OU -> All Computers | High | Restrict GPO edit rights |
| Service Account -> SPN -> Kerberoast -> Admin | High | Switch to gMSAs |
| User -> ForceChangePassword -> Admin | Critical | Remove password reset rights |

### 10.4 Hardening Verification Checklist

```
[ ] NTLM disabled or restricted to minimum
[ ] Kerberos AES-only (RC4 disabled where possible)
[ ] LSA Protection (RunAsPPL) enabled
[ ] Credential Guard enabled on all Tier 0/1 systems
[ ] LAPS deployed on all workstations and servers
[ ] gMSAs for all service accounts
[ ] Unconstrained delegation removed (except DCs)
[ ] RBCD: MachineAccountQuota set to 0
[ ] ADCS templates audited and secured (no ESC1-ESC11)
[ ] Print Spooler disabled on DCs
[ ] SMB signing required on all systems
[ ] LDAP signing required on DCs
[ ] LDAP channel binding required on DCs
[ ] EPA enabled on all web services
[ ] krbtgt password reset within last 180 days
[ ] Tiered admin model enforced
[ ] PAWs for Tier 0 administration
[ ] BloodHound scan clean (no critical paths)
[ ] Sysmon deployed with comprehensive config
[ ] Command line process auditing enabled
[ ] PowerShell ScriptBlock logging enabled
[ ] ASR rules enabled in block mode
[ ] WDAC/AppLocker deployed on high-value assets
[ ] BitLocker with TPM+PIN on all devices
```

---

## APPENDIX A: TOOL QUICK REFERENCE

| Tool | Purpose | Category |
|------|---------|----------|
| BloodHound | AD attack path mapping | Recon/Audit |
| Rubeus | Kerberos abuse toolkit (C#) | Kerberos |
| Mimikatz | Credential extraction, ticket manipulation | Credentials |
| Impacket | Python network protocol library (DCSync, relay, exec) | Multi-purpose |
| Certipy | ADCS enumeration and exploitation | ADCS |
| PowerView | AD enumeration (PowerShell) | Recon |
| SharpHound | BloodHound data collector | Recon |
| Responder | LLMNR/NBT-NS poisoner, NTLM capture | Relay |
| ntlmrelayx | NTLM relay framework | Relay |
| CrackMapExec/NetExec | Network pentesting swiss army knife | Multi-purpose |
| Whisker | Shadow Credentials attack tool | ADCS/Kerberos |
| PetitPotam | EFS coercion tool | Coercion |
| SpoolSample | Print Spooler coercion tool | Coercion |
| Snaffler | AD credential finder in shares | Credentials |
| pypykatz | Python Mimikatz implementation | Credentials |
| PrivescCheck | Windows privilege escalation audit | Audit |
| Seatbelt | System security enumeration (C#) | Audit |
| ThreatCheck | Signature detection identifier | Evasion |
| AMSITrigger | AMSI trigger identifier | Evasion |

## APPENDIX B: MITRE ATT&CK MAPPING

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1566 (Phishing), T1190 (Exploit Public-Facing) |
| Execution | T1059 (Command/Script), T1204 (User Execution) |
| Persistence | T1543.003 (Service), T1053.005 (Scheduled Task), T1547 (Boot/Logon) |
| Privilege Escalation | T1068 (Exploit), T1134 (Token Manipulation), T1548.002 (UAC Bypass) |
| Defense Evasion | T1562 (Impair Defenses), T1055 (Process Injection), T1027 (Obfuscation) |
| Credential Access | T1003 (OS Credential Dumping), T1558 (Kerberos Ticket), T1552 (Unsecured Creds) |
| Discovery | T1087 (Account Discovery), T1482 (Domain Trust), T1069 (Permission Groups) |
| Lateral Movement | T1021 (Remote Services), T1550 (Use Alternate Auth), T1570 (Lateral Tool Transfer) |
| Collection | T1005 (Data from Local System), T1039 (Data from Network Shared Drive) |
| Exfiltration | T1041 (Over C2 Channel), T1048 (Over Alternative Protocol) |
| Impact | T1486 (Data Encrypted for Impact), T1489 (Service Stop) |
