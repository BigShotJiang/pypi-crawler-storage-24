#!/usr/bin/env bash
# Serve CIPHER Knowledge Base locally for preview
set -euo pipefail
cd "$(dirname "$0")/.."
exec uv run mkdocs serve "$@"
