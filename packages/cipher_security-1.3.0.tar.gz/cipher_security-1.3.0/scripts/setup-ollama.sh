#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
MODELFILE="$PROJECT_ROOT/Modelfile"
MODEL_NAME="cipher"

echo "=== CIPHER Ollama Setup ==="
echo ""

# Verify Modelfile exists
if [[ ! -f "$MODELFILE" ]]; then
    echo "ERROR: Modelfile not found at $MODELFILE"
    exit 1
fi

# Verify ollama is available
if ! command -v ollama &>/dev/null; then
    echo "ERROR: ollama is not installed or not in PATH"
    exit 1
fi

# Create the custom model
echo "[1/2] Creating custom model '$MODEL_NAME' from $MODELFILE ..."
ollama create "$MODEL_NAME" -f "$MODELFILE"
echo ""

# Test the model
echo "[2/2] Testing model with a sample query ..."
echo ""
ollama run "$MODEL_NAME" "What is XSS?"
echo ""

echo "=== Setup complete ==="
echo "Run queries with: ollama run $MODEL_NAME \"your security question\""
