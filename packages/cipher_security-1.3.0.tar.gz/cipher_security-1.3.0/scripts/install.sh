#!/usr/bin/env bash
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
#
# CIPHER Installer — Linux / macOS
# Usage: curl -fsSL https://blacktemple.net/cipher/install.sh | bash
# Alt:   curl -fsSL https://raw.githubusercontent.com/defconxt/CIPHER/main/scripts/install.sh | bash
#
set -euo pipefail

# ---------------------------------------------------------------------------
# Colors
# ---------------------------------------------------------------------------
if [ -t 1 ]; then
    GREEN='\033[38;2;0;255;65m'
    CYAN='\033[38;2;0;229;204m'
    RED='\033[38;2;255;77;77m'
    AMBER='\033[38;2;255;176;32m'
    DIM='\033[38;2;90;100;128m'
    BOLD='\033[1m'
    RESET='\033[0m'
else
    GREEN='' CYAN='' RED='' AMBER='' DIM='' BOLD='' RESET=''
fi

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
step_count=0
total_steps=4

step() {
    step_count=$((step_count + 1))
    echo -e "\n${GREEN}[${step_count}/${total_steps}]${RESET} ${BOLD}$1${RESET}"
}

ok()   { echo -e "  ${CYAN}✓${RESET} $1"; }
warn() { echo -e "  ${AMBER}⚠${RESET} $1"; }
fail() { echo -e "  ${RED}✗${RESET} $1"; exit 1; }
info() { echo -e "  ${DIM}●${RESET} $1"; }

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------
echo -e "${GREEN}"
cat << 'BANNER'
   ██████╗██╗██████╗ ██╗  ██╗███████╗██████╗
  ██╔════╝██║██╔══██╗██║  ██║██╔════╝██╔══██╗
  ██║     ██║██████╔╝███████║█████╗  ██████╔╝
  ██║     ██║██╔═══╝ ██╔══██║██╔══╝  ██╔══██╗
  ╚██████╗██║██║     ██║  ██║███████╗██║  ██║
   ╚═════╝╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
BANNER
echo -e "${RESET}${DIM}  Security Engineering Assistant${RESET}"
echo ""

# ---------------------------------------------------------------------------
# Step 1: Check Python
# ---------------------------------------------------------------------------
step "Checking Python"

PYTHON=""
for candidate in python3 python; do
    if command -v "$candidate" &>/dev/null; then
        version=$("$candidate" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null || echo "0.0")
        major=$(echo "$version" | cut -d. -f1)
        minor=$(echo "$version" | cut -d. -f2)
        if [ "$major" -ge 3 ] && [ "$minor" -ge 10 ]; then
            PYTHON="$candidate"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    fail "Python 3.10+ is required but not found."
    echo ""
    info "Install Python:"
    # Detect package manager
    if command -v pacman &>/dev/null; then
        info "  sudo pacman -S python"
    elif command -v apt &>/dev/null; then
        info "  sudo apt install python3 python3-pip python3-venv"
    elif command -v dnf &>/dev/null; then
        info "  sudo dnf install python3 python3-pip"
    elif command -v brew &>/dev/null; then
        info "  brew install python@3.12"
    else
        info "  Visit https://python.org/downloads"
    fi
    exit 1
fi

py_version=$("$PYTHON" --version 2>&1)
ok "$py_version"

# ---------------------------------------------------------------------------
# Step 2: Install CIPHER
# ---------------------------------------------------------------------------
step "Installing CIPHER"

# Prefer pipx for isolated install, fall back to pip
if command -v pipx &>/dev/null; then
    info "Using pipx for isolated install..."
    if pipx install cipher-security 2>/dev/null; then
        ok "Installed via pipx"
    else
        warn "pipx install failed, trying pip..."
        "$PYTHON" -m pip install --user cipher-security 2>/dev/null || \
            "$PYTHON" -m pip install cipher-security || \
            fail "pip install failed. Try: pip install cipher-security"
        ok "Installed via pip"
    fi
elif "$PYTHON" -m pip --version &>/dev/null; then
    info "Using pip..."
    "$PYTHON" -m pip install --user cipher-security 2>/dev/null || \
        "$PYTHON" -m pip install cipher-security || \
        fail "pip install failed"
    ok "Installed via pip"
else
    fail "Neither pipx nor pip found. Install pip: $PYTHON -m ensurepip"
fi

# ---------------------------------------------------------------------------
# Step 3: Verify installation
# ---------------------------------------------------------------------------
step "Verifying installation"

# Check if cipher is in PATH
if command -v cipher &>/dev/null; then
    ok "cipher command found in PATH"
    cipher version
else
    # Try to find it in common locations
    for candidate in \
        "$HOME/.local/bin/cipher" \
        "$HOME/.cargo/bin/cipher" \
        "/usr/local/bin/cipher" \
        "$($PYTHON -m site --user-base 2>/dev/null)/bin/cipher"; do
        if [ -x "$candidate" ]; then
            ok "Found at $candidate"
            # Add to PATH for this session
            export PATH="$(dirname "$candidate"):$PATH"
            warn "Add to your shell config:"
            info "  export PATH=\"$(dirname "$candidate"):\$PATH\""
            break
        fi
    done

    if ! command -v cipher &>/dev/null; then
        warn "cipher not in PATH — you may need to restart your shell"
        info "Or run directly: $PYTHON -m gateway.app"
    fi
fi

# ---------------------------------------------------------------------------
# Step 4: Run setup
# ---------------------------------------------------------------------------
step "Running setup"

if command -v cipher &>/dev/null; then
    info "Starting onboarding wizard..."
    echo ""
    cipher setup
else
    info "Run setup manually after adding cipher to PATH:"
    info "  cipher setup"
fi

# ---------------------------------------------------------------------------
# Done
# ---------------------------------------------------------------------------
echo ""
echo -e "${GREEN}${BOLD}Installation complete!${RESET}"
echo ""
echo -e "  ${BOLD}Quick start:${RESET}"
echo -e "    cipher ${DIM}\"how do I detect Kerberoasting\"${RESET}"
echo -e "    cipher status"
echo -e "    cipher doctor"
echo ""
echo -e "  ${DIM}Documentation: https://github.com/defconxt/CIPHER${RESET}"
echo -e "  ${DIM}GitHub: https://github.com/defconxt/CIPHER${RESET}"
echo ""
