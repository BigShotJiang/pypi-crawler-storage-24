# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
#
# CIPHER Installer — Windows
# Usage: iwr -useb https://blacktemple.net/cipher/install.ps1 | iex
# Alt:   iwr -useb https://raw.githubusercontent.com/defconxt/CIPHER/main/scripts/install.ps1 | iex

$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Colors
# ---------------------------------------------------------------------------
function Write-C { param([string]$Color, [string]$Text) Write-Host $Text -ForegroundColor $Color -NoNewline }
function Step  { param([string]$Msg) Write-Host "`n[$script:stepNum/$script:totalSteps] $Msg" -ForegroundColor Green; $script:stepNum++ }
function Ok    { param([string]$Msg) Write-Host "  ✓ $Msg" -ForegroundColor Cyan }
function Warn  { param([string]$Msg) Write-Host "  ⚠ $Msg" -ForegroundColor Yellow }
function Fail  { param([string]$Msg) Write-Host "  ✗ $Msg" -ForegroundColor Red; exit 1 }
function Info  { param([string]$Msg) Write-Host "  ● $Msg" -ForegroundColor DarkGray }

$script:stepNum = 1
$script:totalSteps = 4

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------
Write-Host @"

   ██████╗██╗██████╗ ██╗  ██╗███████╗██████╗
  ██╔════╝██║██╔══██╗██║  ██║██╔════╝██╔══██╗
  ██║     ██║██████╔╝███████║█████╗  ██████╔╝
  ██║     ██║██╔═══╝ ██╔══██║██╔══╝  ██╔══██╗
  ╚██████╗██║██║     ██║  ██║███████╗██║  ██║
   ╚═════╝╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
"@ -ForegroundColor Green
Write-Host "  Security Engineering Assistant`n" -ForegroundColor DarkGray

# ---------------------------------------------------------------------------
# Step 1: Check Python
# ---------------------------------------------------------------------------
Step "Checking Python"

$python = $null
foreach ($candidate in @("python3", "python", "py")) {
    try {
        $ver = & $candidate -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        if ($ver) {
            $parts = $ver.Split(".")
            if ([int]$parts[0] -ge 3 -and [int]$parts[1] -ge 10) {
                $python = $candidate
                break
            }
        }
    } catch { }
}

if (-not $python) {
    Fail "Python 3.10+ is required but not found."
    Write-Host ""
    Info "Install Python:"
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Info "  winget install Python.Python.3.12"
    } elseif (Get-Command choco -ErrorAction SilentlyContinue) {
        Info "  choco install python312"
    } elseif (Get-Command scoop -ErrorAction SilentlyContinue) {
        Info "  scoop install python"
    } else {
        Info "  Download from https://python.org/downloads"
    }
    exit 1
}

$pyVersion = & $python --version 2>&1
Ok $pyVersion

# ---------------------------------------------------------------------------
# Step 2: Install CIPHER
# ---------------------------------------------------------------------------
Step "Installing CIPHER"

try {
    Info "Installing via pip..."
    & $python -m pip install cipher-security 2>&1 | Out-Null
    Ok "Installed via pip"
} catch {
    try {
        & $python -m pip install --user cipher-security 2>&1 | Out-Null
        Ok "Installed via pip (user)"
    } catch {
        Fail "pip install failed. Try: pip install cipher-security"
    }
}

# ---------------------------------------------------------------------------
# Step 3: Verify installation
# ---------------------------------------------------------------------------
Step "Verifying installation"

$cipherCmd = Get-Command cipher -ErrorAction SilentlyContinue
if ($cipherCmd) {
    Ok "cipher command found in PATH"
    & cipher version
} else {
    # Check common locations
    $userBase = & $python -m site --user-base 2>$null
    $candidates = @(
        "$userBase\Scripts\cipher.exe",
        "$userBase\Scripts\cipher",
        "$env:APPDATA\Python\Scripts\cipher.exe"
    )
    $found = $false
    foreach ($path in $candidates) {
        if (Test-Path $path) {
            Ok "Found at $path"
            $dir = Split-Path $path
            Warn "Add to PATH:"
            Info "  `$env:PATH += `";$dir`""
            # Add for this session
            $env:PATH += ";$dir"
            $found = $true
            break
        }
    }
    if (-not $found) {
        Warn "cipher not in PATH — restart your terminal after install"
        Info "Or run directly: $python -m gateway.app"
    }
}

# ---------------------------------------------------------------------------
# Step 4: Run setup
# ---------------------------------------------------------------------------
Step "Running setup"

if (Get-Command cipher -ErrorAction SilentlyContinue) {
    Info "Starting onboarding wizard..."
    Write-Host ""
    & cipher setup
} else {
    Info "Run setup manually after adding cipher to PATH:"
    Info "  cipher setup"
}

# ---------------------------------------------------------------------------
# Done
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "Installation complete!" -ForegroundColor Green
Write-Host ""
Write-Host "  Quick start:" -ForegroundColor White
Write-Host "    cipher `"how do I detect Kerberoasting`""
Write-Host "    cipher status"
Write-Host "    cipher doctor"
Write-Host ""
Write-Host "  Documentation: https://github.com/defconxt/CIPHER" -ForegroundColor DarkGray
Write-Host "  GitHub: https://github.com/defconxt/CIPHER" -ForegroundColor DarkGray
Write-Host ""
