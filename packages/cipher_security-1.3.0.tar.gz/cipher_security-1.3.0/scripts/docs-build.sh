#!/usr/bin/env bash
# Build CIPHER Knowledge Base as static site
set -euo pipefail
cd "$(dirname "$0")/.."
exec uv run mkdocs build "$@"
