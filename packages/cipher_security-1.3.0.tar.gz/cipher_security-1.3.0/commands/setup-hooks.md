---
name: cipher:setup-hooks
description: Install CIPHER hooks (statusline + context monitor) into Claude Code
---

You are installing CIPHER's Claude Code hooks. Follow these steps precisely.

## Step 1: Locate CIPHER hooks

Check if the CIPHER hook files exist. Try these locations in order:
1. The current project directory: `./hooks/cipher-statusline.js` and `./hooks/cipher-context-monitor.js`
2. The installed package location: run `python3 -c "from importlib.resources import files; print(files('cipher_security'))" 2>/dev/null` then check for hooks there
3. Common dev locations: `/home/void/Documents/cipher/hooks/`

If no hooks are found, tell the user:
> CIPHER hooks not found. If you installed via pip, clone the repo to get hooks:
> `git clone https://github.com/defconxt/CIPHER.git && cd CIPHER`
> Then run `/cipher:setup-hooks` from within the repo.

Stop if hooks aren't found.

Store the absolute path to the hooks directory as `HOOKS_DIR`.

## Step 2: Detect existing hook setup

Read `~/.claude/settings.json` (create it if it doesn't exist with `{}`).

Check for:
- **GSD statusline**: Look for `gsd-statusline` in the statusLine command
- **GSD context monitor**: Look for `gsd-context-monitor` in PostToolUse hooks
- **CIPHER statusline**: Look for `cipher-statusline` in the statusLine command
- **CIPHER context monitor**: Look for `cipher-context-monitor` in PostToolUse hooks

## Step 3: Determine action based on what's installed

### Case A: GSD hooks already present, no CIPHER hooks

Display:
> **GSD hooks detected.** GSD is already providing statusline and context monitoring.
>
> CIPHER's context monitor adds engagement-aware warnings (detects `.cipher/ENGAGEMENT.md`
> and tailors context exhaustion advice for security engagements).
>
> Options:
> 1. **Add CIPHER context monitor alongside GSD** — both monitors run (recommended)
> 2. **Replace GSD hooks with CIPHER hooks** — use CIPHER's statusline and monitor instead
> 3. **Skip** — keep GSD hooks only

Ask the user which option they want.

- **Option 1**: Add CIPHER's context monitor as a second entry in the PostToolUse hooks array. Keep GSD's statusline. Do NOT replace anything.
- **Option 2**: Replace the statusLine command with CIPHER's statusline. Replace the PostToolUse hooks with CIPHER's context monitor only (remove GSD's).
- **Option 3**: Stop. Display "No changes made."

### Case B: No hooks installed (no GSD, no CIPHER)

Display:
> **No existing hooks detected.** Installing CIPHER statusline and context monitor.

Then proceed to install both:
- Set `statusLine` to CIPHER's statusline
- Add CIPHER's context monitor to `PostToolUse`

### Case C: CIPHER hooks already installed

Display:
> **CIPHER hooks already installed.** No changes needed.

Stop.

### Case D: GSD and CIPHER hooks both present

Display:
> **Both GSD and CIPHER hooks are already installed.** No changes needed.

Stop.

## Step 4: Apply changes to settings.json

Read the current `~/.claude/settings.json`, modify the JSON in-memory, and write it back.

For the **statusLine** (when installing CIPHER's):
```json
"statusLine": {
  "type": "command",
  "command": "node \"HOOKS_DIR/cipher-statusline.js\""
}
```

For the **PostToolUse** context monitor (when adding alongside GSD):
Add a new entry to the existing PostToolUse array:
```json
{
  "hooks": [
    {
      "type": "command",
      "command": "node \"HOOKS_DIR/cipher-context-monitor.js\""
    }
  ]
}
```

When replacing, set the entire PostToolUse array to just CIPHER's hook.

**IMPORTANT**: Preserve all other settings.json fields (skipDangerousModePermissionPrompt, enabledPlugins, SessionStart hooks, etc.). Only modify statusLine and PostToolUse.

## Step 5: Verify

Read back `~/.claude/settings.json` and confirm the hooks are registered.

Display:
> ### CIPHER Hooks Installed
>
> - **Statusline**: `cipher-statusline.js` (shows model, directory, context bar)
> - **Context monitor**: `cipher-context-monitor.js` (warns at 35%/25% remaining)
>
> Restart Claude Code to activate the new hooks.
