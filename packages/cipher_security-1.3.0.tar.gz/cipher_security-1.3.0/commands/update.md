---
name: cipher:update
description: Update CIPHER to latest version with changelog display
---

You are performing a CIPHER update check and upgrade. Follow these steps precisely, using Bash tool calls. Do not skip steps or assume values.

## Step 1: Get installed version and install type

Run `uv pip show cipher-security 2>/dev/null || pip show cipher-security 2>/dev/null` to get the currently installed version.

Parse the output for:
- **Version**: the installed version string
- **Editable project location** or **Location** containing `site-packages` vs a source directory: determine if this is a dev/editable install

If the package is not installed at all, tell the user "CIPHER is not installed. Install with: `uv pip install cipher-security`" and stop.

If the install is editable (the output contains "Editable project location" or the location points to a source checkout rather than site-packages), warn:

> **Dev install detected.** You have CIPHER installed in editable/development mode from a local checkout. Running `pip install --upgrade` would replace your dev install with the PyPI release. To update your dev install, use `git pull` in your project directory instead. Aborting update.

Then stop.

## Step 2: Check latest version on PyPI

Run: `curl -sf --connect-timeout 5 https://pypi.org/pypi/cipher-security/json`

If the curl fails (non-zero exit, empty output, or timeout), display:

> **Could not reach PyPI.** Check your internet connection and try again.

Then stop.

Parse the JSON output to extract:
- The latest version from the `info.version` field
- The list of all released versions from the `releases` object keys

Use `jq` to extract these: `curl -sf https://pypi.org/pypi/cipher-security/json | jq -r '.info.version'`

## Step 3: Compare versions

Compare the installed version to the latest PyPI version.

- **If installed == latest**: Display "CIPHER is up to date (v{version})." and stop.
- **If installed > latest** (dev/pre-release version ahead of PyPI): Display "You are running CIPHER v{installed}, which is ahead of the latest PyPI release (v{latest}). This is likely a development build." and stop.
- **If installed < latest**: Continue to step 4.

For version comparison, run: `python3 -c "from packaging.version import Version; print('upgrade' if Version('{installed}') < Version('{latest}') else ('current' if Version('{installed}') == Version('{latest}') else 'ahead'))"` — if `packaging` is not available, fall back to string comparison or use `sort -V`.

## Step 4: Show update preview

First, try to fetch a changelog:
```
curl -sf --connect-timeout 5 https://raw.githubusercontent.com/defconxt/CIPHER/main/CHANGELOG.md
```

**If changelog exists**: Display the relevant section(s) between the installed version and the latest version.

**If no changelog**: Run `curl -sf 'https://api.github.com/repos/defconxt/CIPHER/releases?per_page=10' | jq -r '.[] | "## v\(.tag_name)\n\(.body)\n"'` to show recent GitHub releases. If that also fails, just list the available versions between installed and latest from the PyPI releases data.

Display the update preview:

> ### CIPHER Update Available
>
> **Installed**: v{installed}
> **Latest**: v{latest}
>
> {changelog or release notes or version list}
>
> This will run: `uv pip install --upgrade cipher-security`

## Step 5: Ask for confirmation

Ask the user: "Proceed with update to v{latest}?" using the question tool. Do NOT run the update without explicit user confirmation.

If the user declines, display "Update cancelled." and stop.

## Step 6: Run the update

Run: `uv pip install --upgrade cipher-security`

If `uv` is not available, fall back to: `pip install --upgrade cipher-security`

If the command fails, show the error output and suggest the user try manually.

## Step 7: Verify and show completion

Run `uv pip show cipher-security 2>/dev/null || pip show cipher-security` again to confirm the new version.

Display:

> ### CIPHER Updated Successfully
>
> **Previous version**: v{old}
> **New version**: v{new}
>
> Restart your shell or Claude Code session to pick up the new version.
