---
name: cipher:smart
description: Run a CIPHER security query with auto-routing (simple→Ollama, complex→Claude API)
---

Run the CIPHER security gateway with smart backend routing. Simple queries go to local Ollama, complex queries go to Claude API. Return the response exactly as received.

```bash
cipher-gw --smart "$ARGUMENTS"
```

If cipher-gw is not found on PATH:

```bash
uv run --directory /home/void/Documents/cipher cipher-gw --smart "$ARGUMENTS"
```

Return the full output without modification.
