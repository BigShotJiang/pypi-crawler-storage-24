<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Contributing to CIPHER

Thanks for your interest in contributing. CIPHER is a security engineering assistant with a deep knowledge base, RAG pipeline, and multi-interface architecture. Here's how to get involved.

## Quick Start

```bash
git clone https://github.com/defconxt/CIPHER.git && cd CIPHER
python -m venv .venv && source .venv/bin/activate
pip install -e ".[all]"
pytest tests/ --ignore=tests/test_integration.py
```

## Architecture

```
src/gateway/
├── app.py          # Typer CLI (cipher command)
├── gateway.py      # Orchestrator: mode detect → RAG → prompt → LLM
├── retriever.py    # ChromaDB RAG pipeline
├── mode.py         # Mode detection from keywords
├── prompt.py       # System prompt assembly from skills
├── config.py       # YAML config with ${VAR} substitution
├── client.py       # Anthropic SDK client factory
├── theme.py        # Rich cyberpunk theme
├── dashboard.py    # Textual TUI
└── cli.py          # Legacy cipher-gw (backward compat)

src/bot/
├── bot.py          # Signal bot handler
├── session.py      # Conversation session manager
└── format.py       # Markdown stripping for Signal

knowledge/          # 96 deep-dive security docs (RAG indexed)
skills/             # 13 SKILL.md files loaded into prompts
tests/              # 318 tests (guardrails, RAG quality, routing)
```

## How to Contribute

### Add a Knowledge Doc

1. Create `knowledge/your-topic-deep.md`
2. Follow the format: `# Title`, `## Sections`, code blocks, tables
3. Minimum 200 lines of substantive content
4. Run `cipher ingest` to re-index
5. Add a RAG quality test in `tests/test_rag_quality.py`

### Add a /cipher Skill

1. Create `~/.claude/commands/cipher/skillname.md`
2. Frontmatter: `name: cipher:skillname` + `description:`
3. Body: instructions referencing knowledge docs by path
4. Test it: `/cipher:skillname <query>`

### Add a Skill File (gateway prompt)

1. Create `skills/domain-name/SKILL.md`
2. Add copyright header
3. Update `MODE_SKILL_MAP` in `src/gateway/prompt.py` if adding a new mode
4. Add to `test_guardrails.py` expected skills list

### Fix a Bug / Add a Feature

1. Check existing issues first
2. Fork and create a feature branch
3. Write tests for your change
4. Ensure `pytest` and `ruff check src/ tests/` pass
5. Submit a PR with a clear description

## Code Standards

- **Python 3.10+** with type hints
- **Ruff** for linting: `ruff check src/ tests/ --select E,F,W --ignore E501`
- **No star imports** (`from x import *`)
- **Copyright header** on every source file:
  ```python
  # Copyright (c) 2026 defconxt. All rights reserved.
  # Licensed under AGPL-3.0 — see LICENSE file for details.
  ```
- **No hardcoded credentials** — use `${VAR}` in config or env vars
- Tests must pass before merge: `pytest tests/ --ignore=tests/test_integration.py`

## Tests

```bash
# Full suite (318 tests)
pytest tests/ --ignore=tests/test_integration.py

# Specific areas
pytest tests/test_guardrails.py     # Architecture invariants
pytest tests/test_rag_quality.py    # RAG retrieval quality
pytest tests/test_mode_routing.py   # Mode detection
pytest tests/test_retriever.py      # Chunking + ChromaDB
pytest tests/test_gateway.py        # Gateway pipeline
pytest tests/test_config.py         # Config loading + env substitution
```

## Security Disclosures

If you find a security vulnerability in CIPHER itself (not in the knowledge base content), please report it privately via [GitHub Security Advisories](https://github.com/defconxt/CIPHER/security/advisories/new) rather than opening a public issue.

## License

By contributing, you agree that your contributions will be licensed under [AGPL-3.0](LICENSE).
