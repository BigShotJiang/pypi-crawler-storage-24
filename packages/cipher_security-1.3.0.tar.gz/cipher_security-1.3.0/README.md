<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

<div align="center">

```
   ██████╗██╗██████╗ ██╗  ██╗███████╗██████╗
  ██╔════╝██║██╔══██╗██║  ██║██╔════╝██╔══██╗
  ██║     ██║██████╔╝███████║█████╗  ██████╔╝
  ██║     ██║██╔═══╝ ██╔══██║██╔══╝  ██╔══██╗
  ╚██████╗██║██║     ██║  ██║███████╗██║  ██║
   ╚═════╝╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
```

**Security Engineering Assistant**

[![License: AGPL-3.0](https://img.shields.io/badge/License-AGPL%20v3-blue.svg)](LICENSE)
[![Tests](https://github.com/defconxt/CIPHER/actions/workflows/ci.yml/badge.svg)](https://github.com/defconxt/CIPHER/actions)
[![PyPI](https://img.shields.io/pypi/v/cipher-security?color=00ff41)](https://pypi.org/project/cipher-security/)
[![Python 3.14+](https://img.shields.io/badge/python-3.14+-00ff41.svg)](https://python.org)

A principal-level security engineering assistant with 96 deep-dive knowledge docs,
RAG-powered retrieval, 7 operating modes, and a plugin system.
Runs locally via Ollama, cloud via Claude API, or any provider via LiteLLM.

[![Demo](https://asciinema.org/a/0MjCmtsarnsztdQ6.svg)](https://asciinema.org/a/0MjCmtsarnsztdQ6)

[Install](#install) · [Quick Start](#quick-start) · [Features](#features) · [Documentation](https://blacktemple.net/cipher)

</div>

---

## Install

**One-liner (Linux/macOS):**
```bash
curl -fsSL https://blacktemple.net/cipher/install.sh | bash
```

**Windows PowerShell:**
```powershell
iwr -useb https://blacktemple.net/cipher/install.ps1 | iex
```

> **Note:** Install scripts also available at `https://raw.githubusercontent.com/defconxt/CIPHER/main/scripts/install.sh`

**pip:**
```bash
pip install cipher-security
cipher setup
```

**With optional extras:**
```bash
pip install cipher-security[multi]     # LiteLLM multi-provider support
pip install cipher-security[web]       # Textual web UI
pip install cipher-security[signal]    # Signal bot
pip install cipher-security[all]      # Everything
```

**Docker:**
```bash
docker run -it ghcr.io/defconxt/cipher "how do I detect Kerberoasting"
```

## Quick Start

```bash
# Ask anything security
cipher "how do I detect lateral movement via PsExec"

# Force a specific mode
cipher "[MODE: RED] exploit AS-REP roasting in Active Directory"

# Auto-route: simple queries → local Ollama, complex → Claude API
cipher --smart "design a zero trust architecture for multi-cloud"

# Use any LiteLLM-supported model
cipher --backend litellm "analyze this CVE for exploitability"

# Interactive dashboard
cipher dashboard

# Web UI (requires cipher-security[web])
cipher web

# System health check
cipher doctor
```

## Features

### 7 Operating Modes

| Mode | Focus | Triggers |
|------|-------|----------|
| **RED** | Offensive security, attack paths, exploitation | exploit, payload, privesc, C2, red team |
| **BLUE** | Detection, SIEM, hardening, threat hunting | detection, Sigma, SIEM, EDR, hardening |
| **PURPLE** | Adversary emulation, coverage mapping | emulation, ATT&CK mapping, gap analysis |
| **PRIVACY** | GDPR, CCPA, HIPAA, DPIAs, anonymization | GDPR, CCPA, HIPAA, DPIA, privacy |
| **RECON** | OSINT, reconnaissance, footprinting | OSINT, recon, subdomain, footprinting |
| **INCIDENT** | IR playbooks, forensics, containment | triage, incident response, IOC, forensics |
| **ARCHITECT** | Zero trust, threat modeling, design | design, architecture, threat model, zero trust |

Modes auto-detect from your query. Ambiguous queries prompt for clarification.

### 96 Deep-Dive Knowledge Docs

RAG-powered retrieval over 145K+ lines of security knowledge:

- **Offensive**: AD attacks, web exploitation, cloud attacks, C2, shells, evasion techniques
- **Defensive**: Sigma rules, SIEM/SOC, EDR internals, hardening guides, Windows Event Log mastery
- **Forensics**: DFIR hunting, forensic artifacts, timeline analysis, memory forensics, email forensics
- **Architecture**: Threat modeling (STRIDE/PASTA), cloud reference architectures, crypto/PKI/TLS
- **Compliance**: NIST, CIS, SOC2, ISO 27001, GDPR, PCI DSS, HIPAA
- **Emerging**: Breach case studies (12 major incidents), AI/ML security, abliteration/alignment attacks, vulnerability research, ransomware ecosystem
- **Recon**: tomnomnom toolchain (assetfinder, waybackurls, kxss, unfurl), composable pipeline patterns, OSINT tradecraft

### Multi-Provider Support

Three built-in backends with smart routing:

| Backend | Setup | Use Case |
|---------|-------|----------|
| **Ollama** | `cipher setup` → option 1 | Free local inference, privacy-first |
| **Claude** | `cipher setup` → option 2 | High-quality cloud reasoning |
| **LiteLLM** | `pip install cipher-security[multi]` | Any provider: OpenAI, Gemini, Mistral, Groq, Azure, etc. |

Smart routing (`--smart`) auto-classifies query complexity and routes between Ollama (simple/moderate) and Claude (complex/expert). LiteLLM is always explicit via `--backend litellm` or `llm_backend: litellm` in config.

### Plugin System

Extend CIPHER with custom skills:

```bash
cipher plugin list                    # Show installed plugins
cipher plugin install ./my-plugin     # Install from directory
cipher plugin remove my-plugin        # Remove a plugin
cipher plugin info my-plugin          # Show plugin details
```

Plugins are discovered from `~/.config/cipher/plugins/` and Python entry points (`cipher.skills` group). Each plugin provides a `plugin.yaml` manifest with metadata, a priority (0–100), and optional skill content that's injected into the system prompt.

See [Plugin Development](https://blacktemple.net/cipher/plugins) for the full spec.

### VS Code Extension

Full security assistant inside VS Code:

- **Sidebar chat** — conversational security queries with streaming responses
- **Right-click analysis** — select code, right-click → "Analyze with CIPHER"
- **Mode & backend selectors** — switch modes and providers from the UI
- **No daemon required** — queries go through the `cipher-gw` CLI

Install from `vscode/` directory:
```bash
cd vscode && npm install && npm run compile
# Then "Install from VSIX" in VS Code, or:
npx @vscode/vsce package && code --install-extension cipher-security-*.vsix
```

### 34 Slash Commands (Claude Code)

```
/cipher:redteam    /cipher:web        /cipher:phishing    /cipher:malware
/cipher:hunt       /cipher:sigma      /cipher:hardening   /cipher:forensics
/cipher:purple     /cipher:recon      /cipher:privacy     /cipher:insider
/cipher:threatmodel /cipher:cloud     /cipher:crypto      /cipher:devsecops
/cipher:ir         /cipher:cve        /cipher:threatintel  /cipher:aisec
/cipher:audit      /cipher:report     /cipher:ics         /cipher:mobile
/cipher:cc         /cipher:ollama     /cipher:claudeapi   /cipher:smart
/cipher:brief      /cipher:update     /cipher:setup-hooks
/cipher:engage     /cipher:resume     /cipher:export
```

`/cipher:brief` is the orchestrator — synthesizes a full target briefing from multiple
knowledge domains: attack surface, threat profile, attack paths, detection coverage gaps,
and a prioritized action plan. Inspired by [h1-brain](https://github.com/PatrikFehrenbach/h1-brain).

### Multiple Interfaces

| Interface | Command | Cost |
|-----------|---------|------|
| **CLI** | `cipher "query"` | Free (Ollama) or paid (Claude/LiteLLM) |
| **Dashboard** | `cipher dashboard` | Free (Ollama) or paid (Claude/LiteLLM) |
| **Web UI** | `cipher web` | Free (Ollama) or paid (Claude/LiteLLM) |
| **VS Code** | Extension sidebar | Free (Ollama) or paid (Claude/LiteLLM) |
| **Claude Code** | `/cipher:cc "query"` | Included with Claude Code |
| **Signal Bot** | Message the bot | Free (Ollama) or paid (Claude) |
| **Docker** | `docker run -it cipher "query"` | Free (Ollama) or paid (Claude) |

### RAG Pipeline

Semantic search over the entire knowledge base:
- **14,900+ chunks** indexed in ChromaDB
- Markdown-aware chunking preserving section context
- Top-5 retrieval injected into system prompt before every query
- Auto re-ingests on knowledge base changes (git hook)

### Shell Completions

Tab completions for all commands, options, and modes:

```bash
# Bash — add to ~/.bashrc
source <(cipher completions bash)
# or: cp completions/cipher.bash /etc/bash_completion.d/

# Zsh — add to ~/.zshrc
source <(cipher completions zsh)
# or: cp completions/cipher.zsh ~/.zsh/completions/_cipher

# Fish
cp completions/cipher.fish ~/.config/fish/completions/
```

### Updating

```bash
# From Claude Code
/cipher:update

# From CLI
pip install --upgrade cipher-security
```

`/cipher:update` checks PyPI for the latest version, shows the changelog, asks for confirmation, and runs the upgrade.

### Claude Code Hooks

CIPHER includes Claude Code hooks that install automatically during `cipher setup`:

- **Statusline** — shows model, directory, and a context usage bar
- **Context monitor** — warns when context window is running low (35% WARNING, 25% CRITICAL), with engagement-aware messaging when a `.cipher/` engagement is active

Hooks coexist with [GSD](https://github.com/gsd-build/get-shit-done) — if GSD's statusline is already registered, CIPHER keeps it and adds its context monitor alongside. To manually (re)install hooks: `/cipher:setup-hooks`.

### Engagements

Persistent security engagement state across sessions:

```bash
/cipher:engage              # Start a new engagement (pentest, IR, audit, etc.)
/cipher:resume              # Resume — shows findings, open questions, next actions
/cipher:export              # Export engagement as a formatted security report
```

Engagement state lives in `.cipher/ENGAGEMENT.md` — human-readable, git-trackable, and automatically detected by the context monitor hook.

## CLI Commands

```
cipher "query"              Send a security query (default command)
cipher --smart "query"      Auto-route: simple→Ollama, complex→Claude
cipher --backend ollama     Force local inference
cipher --backend claude     Force cloud inference
cipher --backend litellm    Use LiteLLM provider (requires [multi] extra)
cipher setup                Interactive onboarding wizard
cipher dashboard            Cyberpunk terminal UI
cipher web                  Web UI via Textual (requires [web] extra)
cipher doctor               Diagnostics and health checks
cipher doctor --fix         Auto-repair issues
cipher status               Show system status
cipher ingest               Re-index the knowledge base
cipher plugin list          List installed plugins
cipher plugin install DIR   Install a plugin
cipher plugin remove NAME   Remove a plugin
cipher version              Show version
```

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                        Interfaces                            │
│  CLI · Dashboard · Web · VS Code · Claude Code · Signal Bot  │
└────────────────────────────┬─────────────────────────────────┘
                             │
                    ┌────────▼────────┐
                    │     Gateway     │
                    │  Mode Detection │──── 7 modes
                    │  Prompt Assembly│──── 9 skills + plugins
                    │  RAG Retrieval  │──── 14,900 chunks
                    └────────┬────────┘
                             │
           ┌─────────────────┼─────────────────┐
           │                 │                  │
    ┌──────▼──────┐   ┌──────▼──────┐   ┌──────▼──────┐
    │   Ollama    │   │  Claude API │   │   LiteLLM   │
    │  (local)    │   │   (cloud)   │   │ (any model) │
    │ qwen2.5:32b │   │ sonnet-4-5  │   │ gpt-4o, etc │
    └─────────────┘   └─────────────┘   └─────────────┘
```

## Configuration

Config file: `config.yaml` (project root) or `~/.config/cipher/config.yaml`

Supports `${VAR}` and `${VAR:-default}` environment variable substitution:

```yaml
llm_backend: ollama   # ollama | claude | litellm

ollama:
  base_url: "http://127.0.0.1:11434"
  model: "cipher"
  timeout: 300

claude:
  api_key: "${ANTHROPIC_API_KEY}"
  model: "claude-sonnet-4-5-20250929"
  timeout: 120

litellm:
  model: "openai/gpt-4o"           # Any LiteLLM model string
  api_key: "${OPENAI_API_KEY}"
  api_base: ""                      # Optional custom endpoint
  timeout: 120
```

Priority: env vars > project config > home config.

## Development

```bash
git clone https://github.com/defconxt/CIPHER.git && cd CIPHER
python -m venv .venv && source .venv/bin/activate
pip install -e ".[all]"
pytest tests/ --ignore=tests/test_integration.py
```

**485 tests** covering gateway, mode routing, RAG quality, architecture guardrails, configuration, CLI commands, streaming, plugins, multi-provider, and security scanning.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines. Security researchers welcome.

## License

[AGPL-3.0](LICENSE) — CIPHER is a trademark of [defconxt](https://github.com/defconxt).
