# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER Signal bot — CipherCommand handler and watchdog main loop.

Entry point for the Signal bot container. Registers CipherCommand with
signalbot, filters by whitelist, maps prefixes, dispatches to Gateway via
executor, strips markdown, and manages session history.

Watchdog: outer while-True retries bot.start() on any exception with
exponential backoff (1s base, 2x multiplier, 60s max).
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from signalbot import Command  # type: ignore[import]

from bot.format import map_prefix, strip_markdown
from bot.session import SessionManager
from gateway.gateway import Gateway

logger = logging.getLogger(__name__)

# Disambiguation keyword map
_CLARIFY_MAP: dict[str, str] = {
    "offensive": "RED",
    "defensive": "BLUE",
}


class CipherCommand(Command):
    """signalbot Command handler for CIPHER.

    Filters senders against a whitelist, maps short prefixes, dispatches to
    Gateway via asyncio executor (non-blocking), strips markdown, manages
    session history, and handles disambiguation flow.

    Args:
        gateway:   Constructed Gateway instance.
        session:   SessionManager for conversation history.
        whitelist: Set of E.164 phone numbers allowed to use the bot.
    """

    def __init__(
        self,
        gateway: Gateway,
        session: SessionManager,
        whitelist: set[str],
    ) -> None:
        super().__init__()
        self._gateway = gateway
        self._session = session
        self._whitelist = whitelist
        # Keyed by sender E.164 number; value is the original query awaiting
        # clarification (offensive vs defensive).
        self._clarification: dict[str, str] = {}

    async def handle(self, c: Any) -> None:
        """Handle an incoming Signal message.

        Args:
            c: signalbot Context (or MockContext in tests).
        """
        text: str = (c.message.text or "").strip()

        # --- Skip empty messages (typing indicators, system events) ---
        if not text:
            return

        # --- Whitelist gate ---
        # Signal may identify senders by UUID or phone number depending on
        # privacy settings. Check all available identifiers.
        sender_ids = {c.message.source, c.message.source_uuid}
        if c.message.source_number:
            sender_ids.add(c.message.source_number)
        if not sender_ids & self._whitelist:
            return
        sender: str = c.message.source_number or c.message.source

        # --- /reset command ---
        if text.strip() == "/reset":
            self._session.reset(sender)
            await c.send("Session cleared.")
            return

        # --- Disambiguation reply check ---
        if sender in self._clarification:
            await self._handle_clarification(c, sender, text)
            return

        # --- Acknowledge with brain emoji ---
        await c.react("🧠")

        # --- Map short prefix ---
        mapped = map_prefix(text)

        # --- Fetch session history ---
        history = self._session.get(sender)

        # --- Dispatch to Gateway via executor (non-blocking) ---
        loop = asyncio.get_running_loop()
        response: str = await loop.run_in_executor(
            None,
            lambda: self._gateway.send(mapped, history=history),
        )

        # --- Disambiguation: multiple modes detected ---
        if response.startswith("Multiple modes detected"):
            self._clarification[sender] = mapped
            await c.send(response)
            return

        # --- Update session and send response ---
        self._session.update(sender, mapped, response)
        await c.send(strip_markdown(response))

    async def _handle_clarification(
        self, c: Any, sender: str, reply: str
    ) -> None:
        """Process a clarification reply (offensive / defensive).

        Maps the reply to a mode prefix, re-routes the stored query.
        Keeps state if the reply is unrecognized.
        """
        reply_lower = reply.strip().lower()

        # Find matching mode keyword
        matched_mode: str | None = None
        for keyword, mode in _CLARIFY_MAP.items():
            if keyword in reply_lower:
                matched_mode = mode
                break

        if matched_mode is None:
            await c.send("Please reply 'offensive' or 'defensive'.")
            return

        # Route stored query with resolved prefix
        original_query = self._clarification.pop(sender)
        prefixed = f"[MODE: {matched_mode}] {original_query}"

        await c.react("🧠")

        history = self._session.get(sender)
        loop = asyncio.get_running_loop()
        response: str = await loop.run_in_executor(
            None,
            lambda: self._gateway.send(prefixed, history=history),
        )

        self._session.update(sender, prefixed, response)
        await c.send(strip_markdown(response))


# ---------------------------------------------------------------------------
# Bot runner
# ---------------------------------------------------------------------------

def run_bot(config: dict[str, Any]) -> None:
    """Construct and start the SignalBot with CipherCommand registered.

    Args:
        config: Signal config dict (signal_service, phone_number, whitelist,
                session_timeout).
    """
    from signalbot import SignalBot, Config  # type: ignore[import]

    signal_cfg = Config(
        signal_service=config["signal_service"],
        phone_number=config["phone_number"],
    )
    bot = SignalBot(signal_cfg)
    gateway = Gateway()
    session = SessionManager(
        timeout_seconds=int(config.get("session_timeout", 3600))
    )
    cmd = CipherCommand(
        gateway=gateway,
        session=session,
        whitelist=set(config.get("whitelist", [])),
    )
    bot.register(cmd)
    bot.start()


# ---------------------------------------------------------------------------
# Main with watchdog
# ---------------------------------------------------------------------------

def main() -> None:
    """Entry point: load config, run bot with exponential-backoff watchdog."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s — %(message)s",
    )

    from gateway.config import _find_project_root, _load_yaml_file
    from pathlib import Path

    # Locate config.yaml
    project_root = _find_project_root(Path(__file__).parent)
    if project_root is None:
        project_root = Path.cwd()

    raw = _load_yaml_file(Path(project_root) / "config.yaml")
    signal_cfg: dict[str, Any] = raw.get("signal", {})

    # Env var overrides
    import os
    if sv := os.environ.get("SIGNAL_SERVICE"):
        signal_cfg["signal_service"] = sv
    if spn := os.environ.get("SIGNAL_PHONE_NUMBER"):
        signal_cfg["phone_number"] = spn
    if swl := os.environ.get("SIGNAL_WHITELIST"):
        signal_cfg["whitelist"] = [n.strip() for n in swl.split(",") if n.strip()]

    delay = 1.0
    while True:
        try:
            logger.info("Starting bot …")
            run_bot(signal_cfg)
            # Clean exit — reset delay
            delay = 1.0
        except Exception as exc:  # noqa: BLE001
            logger.error("Bot crashed: %s — retrying in %.0fs", exc, delay)
            time.sleep(delay)
            delay = min(delay * 2, 60.0)


if __name__ == "__main__":
    main()
