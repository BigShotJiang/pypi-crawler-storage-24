# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Bot formatting utilities.

map_prefix: Maps short Signal prefix (e.g. 'RED: query') to gateway format
            ('[MODE: RED] query'). Passes through text with no recognized prefix.

strip_markdown: Strips markdown formatting from LLM responses for plaintext
                Signal delivery. Preserves structure via line breaks and ASCII bullets.
"""

import re

# ---------------------------------------------------------------------------
# Prefix mapping
# ---------------------------------------------------------------------------

_PREFIX_RE = re.compile(
    r"^(RED|BLUE|PURPLE|PRIVACY|RECON|INCIDENT|ARCHITECT):\s*",
    re.IGNORECASE,
)


def map_prefix(text: str) -> str:
    """Map 'MODE: query' short-prefix format to '[MODE: MODE] query'.

    Case-insensitive. Strips optional whitespace after colon.
    Returns text unchanged when no recognized mode prefix is found.

    Examples:
        map_prefix("RED: query")        -> "[MODE: RED] query"
        map_prefix("blue: what is DNS") -> "[MODE: BLUE] what is DNS"
        map_prefix("RED:query")         -> "[MODE: RED] query"
        map_prefix("no prefix here")    -> "no prefix here"
    """
    m = _PREFIX_RE.match(text)
    if m:
        mode = m.group(1).upper()
        rest = text[m.end():]
        return f"[MODE: {mode}] {rest}"
    return text


# ---------------------------------------------------------------------------
# Markdown stripping
# ---------------------------------------------------------------------------

# Patterns applied in order — order matters (bold before italic, code blocks
# before inline code).
_MD_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # Fenced code blocks: ```lang\ncontent\n``` -> content
    (re.compile(r"```[^\n]*\n(.*?)```", re.DOTALL), r"\1"),
    # Headers: ## Heading -> Heading
    (re.compile(r"^#{1,6}\s+", re.MULTILINE), ""),
    # Bold: **text** -> text (must be before italic)
    (re.compile(r"\*{2}([^*\n]+)\*{2}"), r"\1"),
    # Italic: *text* -> text
    (re.compile(r"\*([^*\n]+)\*"), r"\1"),
    # Inline code: `code` -> code
    (re.compile(r"`([^`\n]+)`"), r"\1"),
    # Links: [text](url) -> text
    (re.compile(r"\[([^\]]+)\]\([^)]+\)"), r"\1"),
    # Bullets: "* item" or "- item" -> "• item" (preserves leading whitespace)
    (re.compile(r"^(\s*)[*-]\s+", re.MULTILINE), r"\1• "),
]


def strip_markdown(text: str) -> str:
    """Strip markdown formatting for plaintext Signal delivery.

    Removes headers, bold, italic, code blocks, inline code, links.
    Converts markdown bullets (* / -) to ASCII bullets (•).
    Preserves plain text, newlines, and indentation.

    Examples:
        strip_markdown("## Heading")         -> "Heading"
        strip_markdown("**bold** text")      -> "bold text"
        strip_markdown("```python\\ncode\\n```") -> "code"
        strip_markdown("* item")             -> "• item"
        strip_markdown("[link](http://x)")   -> "link"
    """
    for pattern, replacement in _MD_PATTERNS:
        text = pattern.sub(replacement, text)
    return text.strip()
