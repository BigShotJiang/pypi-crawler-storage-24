# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Session management for the CIPHER Signal bot.

SessionManager maintains per-sender conversation history compatible with
Gateway.send(history=) format. Sessions expire after configurable inactivity
and are capped at a maximum number of message pairs.
"""

from __future__ import annotations

from datetime import datetime, timezone, timedelta


class SessionManager:
    """In-memory conversation history manager keyed by sender phone number.

    Session dict structure per sender:
        {
            "history": [{"role": "user"|"assistant", "content": "..."}, ...],
            "last_active": datetime (UTC),
        }

    History format matches Gateway.send(history=) — list of role/content dicts.

    Args:
        timeout_seconds: Inactivity window before a session is expired.
            Default 3600 (1 hour).
        max_pairs: Maximum number of user/assistant pairs to retain.
            Oldest pair is evicted when the cap is exceeded. Default 20.
    """

    def __init__(self, timeout_seconds: int = 3600, max_pairs: int = 20) -> None:
        self._sessions: dict[str, dict] = {}
        self._timeout = timeout_seconds
        self._max_pairs = max_pairs

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, sender: str) -> list[dict]:
        """Return conversation history for sender.

        Calls cleanup() first to expire stale sessions.
        Returns empty list for unknown or expired senders.
        """
        self.cleanup()
        session = self._sessions.get(sender)
        if session is None:
            return []
        return list(session["history"])

    def update(self, sender: str, user_message: str, assistant_message: str) -> None:
        """Append a user/assistant pair to sender's history.

        Creates the session if it does not exist. Updates last_active.
        Evicts the oldest pair if the cap is exceeded.
        """
        if sender not in self._sessions:
            self._sessions[sender] = {"history": [], "last_active": self._now()}

        session = self._sessions[sender]
        session["history"].append({"role": "user", "content": user_message})
        session["history"].append({"role": "assistant", "content": assistant_message})
        session["last_active"] = self._now()

        # Enforce cap: keep only the newest max_pairs pairs (max_pairs * 2 items)
        max_items = self._max_pairs * 2
        if len(session["history"]) > max_items:
            session["history"] = session["history"][-max_items:]

    def reset(self, sender: str) -> None:
        """Clear conversation history for sender.

        No-op if sender has no active session.
        """
        self._sessions.pop(sender, None)

    def cleanup(self) -> None:
        """Remove sessions that have been inactive longer than timeout_seconds."""
        now = self._now()
        cutoff = timedelta(seconds=self._timeout)
        stale = [
            sender
            for sender, session in self._sessions.items()
            if (now - session["last_active"]) > cutoff
        ]
        for sender in stale:
            del self._sessions[sender]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)
