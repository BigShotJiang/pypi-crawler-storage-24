# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER config migrations — auto-upgrade old config formats.

Each migration is a function that takes a config dict and returns
a (possibly modified) config dict. Migrations are applied in order.
The config version is tracked via a '_version' key.
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Current config version — bump when adding a new migration
CURRENT_VERSION = 2


def migrate(config: dict[str, Any]) -> dict[str, Any]:
    """Apply all pending migrations to a config dict.

    Returns the migrated config. Does not write to disk — caller
    is responsible for saving if the config was modified.
    """
    version = config.get("_version", 1)
    if version >= CURRENT_VERSION:
        return config

    original_version = version
    for v, fn in _MIGRATIONS.items():
        if version < v:
            logger.info("Config migration: v%d → v%d (%s)", version, v, fn.__name__)
            config = fn(config)
            version = v

    config["_version"] = CURRENT_VERSION

    if version > original_version:
        logger.info("Config migrated from v%d to v%d", original_version, CURRENT_VERSION)

    return config


# ---------------------------------------------------------------------------
# Migration functions — add new ones here
# ---------------------------------------------------------------------------

def _v2_normalize_backend(config: dict[str, Any]) -> dict[str, Any]:
    """v1 → v2: Normalize backend field name.

    Old configs might use 'backend' instead of 'llm_backend'.
    Also ensures sections exist with defaults.
    """
    # Rename 'backend' → 'llm_backend' if old key present
    if "backend" in config and "llm_backend" not in config:
        config["llm_backend"] = config.pop("backend")
        logger.info("  Renamed 'backend' → 'llm_backend'")

    # Ensure ollama section exists with defaults
    if "ollama" not in config or not isinstance(config.get("ollama"), dict):
        config["ollama"] = {
            "base_url": "http://127.0.0.1:11434",
            "model": "cipher",
            "timeout": 300,
        }
        logger.info("  Added default ollama section")

    # Ensure claude section exists
    if "claude" not in config or not isinstance(config.get("claude"), dict):
        config["claude"] = {
            "api_key": "",
            "model": "claude-sonnet-4-5-20250929",
            "timeout": 120,
        }
        logger.info("  Added default claude section")

    # Normalize model names
    ollama = config.get("ollama", {})
    if ollama.get("model") == "qwen2.5:32b":
        ollama["model"] = "cipher"
        logger.info("  Updated ollama model: qwen2.5:32b → cipher")

    return config


# Registry — version number → migration function
_MIGRATIONS: dict[int, Any] = {
    2: _v2_normalize_backend,
}
