# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Mode detection for CIPHER gateway.

Provides:
- parse_keyword_table: extract mode→keywords from CLAUDE.md trigger table
- detect_mode: route message to operating mode via explicit prefix or keyword scoring
- strip_mode_prefix: remove [MODE: X] prefix from message text
"""

import logging
import re

logger = logging.getLogger(__name__)

# Matches [MODE: X] at the start of a message, case-insensitive.
_EXPLICIT_RE = re.compile(r"^\[MODE:\s*(\w+)\]", re.IGNORECASE)

# Matches the trigger keywords table block inside CLAUDE.md.
# Looks for a header containing "Trigger Keywords", then captures rows.
_TABLE_HEADER_RE = re.compile(
    r"Trigger Keywords.*?\n\|[-| ]+\|\n(.*?)(?:\n[-]+|\n\n|\Z)",
    re.DOTALL | re.IGNORECASE,
)
# Individual data row: | WORD | content |
# Skips header rows where the first cell is "Mode" (case-insensitive).
_TABLE_ROW_RE = re.compile(r"^\|\s*(\w+)\s*\|\s*(.+?)\s*\|", re.MULTILINE)
# Known header/separator cell values to skip.
_SKIP_ROW_NAMES = {"MODE", "---"}


def parse_keyword_table(claude_md_text: str) -> dict[str, list[str]]:
    """Parse the ``| Mode | Trigger Keywords |`` table from CLAUDE.md text.

    Returns a dict mapping UPPERCASE mode names to lists of lowercase,
    stripped keyword strings. Returns empty dict if the table is absent or
    malformed.
    """
    if not claude_md_text.strip():
        return {}

    # Find the trigger keywords section — everything after the separator row.
    header_match = _TABLE_HEADER_RE.search(claude_md_text)
    if not header_match:
        # Try a looser parse: find any table-like block with Mode | Trigger columns.
        # Scan line by line for rows after a header that contains "Trigger Keywords".
        if "Trigger Keywords" not in claude_md_text:
            logger.warning("parse_keyword_table: no 'Trigger Keywords' table found")
            return {}
        # Fall through to row-level scan across the full text.
        rows_text = claude_md_text
    else:
        rows_text = header_match.group(0)

    result: dict[str, list[str]] = {}
    for row_match in _TABLE_ROW_RE.finditer(rows_text):
        mode = row_match.group(1).strip().upper()
        # Skip table header row (| Mode | Trigger Keywords |) and separators.
        if mode in _SKIP_ROW_NAMES:
            continue
        raw_keywords = row_match.group(2)
        # Skip if the "keyword" cell looks like a column header.
        if "trigger keywords" in raw_keywords.lower():
            continue
        keywords = [kw.strip().lower() for kw in raw_keywords.split(",") if kw.strip()]
        if mode and keywords:
            result[mode] = keywords

    if not result:
        logger.warning("parse_keyword_table: table parsed to empty dict")

    return result


def detect_mode(
    message: str,
    keyword_table: dict[str, list[str]],
) -> tuple[str, bool]:
    """Detect the CIPHER operating mode for a given message.

    Detection order:
    1. Explicit ``[MODE: X]`` prefix — returns immediately, no clarification needed.
    2. Keyword scoring — scan lowercased message against keyword_table.
       - Single mode match → return (mode, False)
       - Multiple mode matches → return (comma-joined sorted modes, True)
       - No match → return ("ARCHITECT", False)

    Args:
        message: Raw user message text (may include [MODE: X] prefix).
        keyword_table: Dict of mode→keywords from parse_keyword_table.

    Returns:
        Tuple of (mode_string, needs_clarification).
    """
    # 1. Check explicit prefix.
    prefix_match = _EXPLICIT_RE.match(message)
    if prefix_match:
        return prefix_match.group(1).upper(), False

    # 2. Keyword scoring.
    lower_message = message.lower()
    matched_modes: set[str] = set()

    for mode, keywords in keyword_table.items():
        for keyword in keywords:
            if keyword in lower_message:
                matched_modes.add(mode)
                break  # One hit per mode is enough.

    if len(matched_modes) == 0:
        return "ARCHITECT", False
    if len(matched_modes) == 1:
        return matched_modes.pop(), False

    # Multiple matches — needs clarification.
    sorted_modes = ",".join(sorted(matched_modes))
    return sorted_modes, True


def strip_mode_prefix(message: str) -> str:
    """Remove ``[MODE: X]`` prefix from message text.

    Strips any leading whitespace after the prefix. Returns the original
    string unchanged if no prefix is present.
    """
    result = _EXPLICIT_RE.sub("", message)
    return result.lstrip()
