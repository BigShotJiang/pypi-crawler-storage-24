# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER gateway configuration — YAML loading with env var substitution.

Precedence (highest to lowest):
  1. Environment variables (LLM_BACKEND, ANTHROPIC_API_KEY)
  2. Project-root config.yaml  (where pyproject.toml lives)
  3. ~/.config/cipher/config.yaml

Supports ${VAR} and ${VAR:-default} syntax in YAML values.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


# ---------------------------------------------------------------------------
# Environment variable substitution
# ---------------------------------------------------------------------------

# Matches ${VAR} or ${VAR:-default}
_ENV_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-(.*?))?\}")


def _substitute_env(value: Any) -> Any:
    """Recursively substitute ${VAR} and ${VAR:-default} in config values."""
    if isinstance(value, str):
        def _replace(m: re.Match) -> str:
            var = m.group(1)
            default = m.group(2)
            env_val = os.environ.get(var)
            if env_val is not None:
                return env_val
            if default is not None:
                return default
            return m.group(0)  # Leave unresolved if no default
        return _ENV_RE.sub(_replace, value)
    if isinstance(value, dict):
        return {k: _substitute_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_substitute_env(v) for v in value]
    return value


# ---------------------------------------------------------------------------
# Secret redaction
# ---------------------------------------------------------------------------

_SECRET_KEYS = {"api_key", "apikey", "api-key", "token", "secret", "password"}


def redact_config(config: dict) -> dict:
    """Return a copy of config with secret values replaced by '***'."""
    def _redact(obj: Any, key: str = "") -> Any:
        if isinstance(obj, dict):
            return {k: _redact(v, k) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_redact(v) for v in obj]
        if isinstance(obj, str) and key.lower().replace("-", "_") in _SECRET_KEYS and obj:
            return "***"
        return obj
    return _redact(config)


# ---------------------------------------------------------------------------
# Config dataclass
# ---------------------------------------------------------------------------

VALID_BACKENDS = ("ollama", "claude", "litellm")


@dataclass
class GatewayConfig:
    """Validated, fully-resolved gateway configuration."""

    backend: str          # "ollama" | "claude" | "litellm"
    ollama_base_url: str
    ollama_model: str
    ollama_timeout: int
    claude_api_key: str
    claude_model: str
    claude_timeout: int
    litellm_model: str = ""
    litellm_api_key: str = ""
    litellm_timeout: int = 120
    litellm_api_base: str = ""

    def __post_init__(self) -> None:
        if self.backend not in VALID_BACKENDS:
            raise ValueError(
                f"Invalid backend {self.backend!r}. Must be one of {VALID_BACKENDS}.\n"
                "Set 'llm_backend' in config.yaml or run: cipher setup"
            )
        if self.backend == "ollama" and not self.ollama_model:
            raise ValueError(
                "ollama_model must be set when backend is 'ollama'.\n"
                "Set 'ollama.model' in config.yaml or run: cipher setup"
            )
        if self.backend == "claude" and not self.claude_model:
            raise ValueError(
                "claude_model must be set when backend is 'claude'.\n"
                "Set 'claude.model' in config.yaml or run: cipher setup"
            )
        if self.backend == "litellm" and not self.litellm_model:
            raise ValueError(
                "litellm_model must be set when backend is 'litellm'.\n"
                "Set 'litellm.model' in config.yaml or run: cipher setup"
            )


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------

def _find_project_root(start: Path) -> Path | None:
    """Walk up from `start` until pyproject.toml is found. Returns the dir or None."""
    current = start.resolve()
    for _ in range(20):
        if (current / "pyproject.toml").exists():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _load_yaml_file(path: Path) -> dict[str, Any]:
    """Load a YAML file safely. Returns empty dict if file missing or empty."""
    if not path.exists():
        return {}
    with path.open("r") as f:
        data = yaml.safe_load(f)
    return data if isinstance(data, dict) else {}


def load_config(project_root: Path | None = None) -> GatewayConfig:
    """Load configuration from YAML files and env var overrides.

    Supports ${VAR} and ${VAR:-default} syntax in YAML values.

    Args:
        project_root: Directory to look for project-root config.yaml.
                      If None, resolved by walking up from this file's location.

    Returns:
        Validated GatewayConfig.

    Raises:
        ValueError: If required fields are missing or invalid.
    """
    if project_root is None:
        found = _find_project_root(Path(__file__).parent)
        project_root = found if found is not None else Path.cwd()

    home_config = Path.home() / ".config" / "cipher" / "config.yaml"
    project_config = Path(project_root) / "config.yaml"

    merged: dict[str, Any] = {}
    merged.update(_load_yaml_file(home_config))
    merged.update(_load_yaml_file(project_config))

    # Run config migrations (auto-upgrade old formats)
    from gateway.migrations import migrate
    merged = migrate(merged)

    # Substitute ${VAR} patterns in all values
    merged = _substitute_env(merged)

    # Apply explicit env var overrides (highest priority)
    if backend := os.environ.get("LLM_BACKEND"):
        merged["llm_backend"] = backend
    if api_key := os.environ.get("ANTHROPIC_API_KEY"):
        merged.setdefault("claude", {})
        if not isinstance(merged.get("claude"), dict):
            merged["claude"] = {}
        merged["claude"]["api_key"] = api_key

    ollama_section: dict[str, Any] = merged.get("ollama") or {}
    claude_section: dict[str, Any] = merged.get("claude") or {}
    litellm_section: dict[str, Any] = merged.get("litellm") or {}

    return GatewayConfig(
        backend=merged.get("llm_backend", ""),
        ollama_base_url=ollama_section.get("base_url", "http://127.0.0.1:11434"),
        ollama_model=ollama_section.get("model", ""),
        ollama_timeout=int(ollama_section.get("timeout", 300)),
        claude_api_key=claude_section.get("api_key", ""),
        claude_model=claude_section.get("model", ""),
        claude_timeout=int(claude_section.get("timeout", 60)),
        litellm_model=litellm_section.get("model", ""),
        litellm_api_key=litellm_section.get("api_key", ""),
        litellm_timeout=int(litellm_section.get("timeout", 120)),
        litellm_api_base=litellm_section.get("api_base", ""),
    )


def load_signal_config(project_root: Path | None = None) -> dict[str, Any]:
    """Load the 'signal:' section from config.yaml with env var overrides."""
    if project_root is None:
        found = _find_project_root(Path(__file__).parent)
        project_root = found if found is not None else Path.cwd()

    home_config = Path.home() / ".config" / "cipher" / "config.yaml"
    project_config = Path(project_root) / "config.yaml"

    merged: dict[str, Any] = {}
    merged.update(_load_yaml_file(home_config))
    merged.update(_load_yaml_file(project_config))
    merged = _substitute_env(merged)

    signal_section: dict[str, Any] = merged.get("signal") or {}

    result: dict[str, Any] = {
        "signal_service": signal_section.get("signal_service", "signal-api:8080"),
        "phone_number": signal_section.get("phone_number", ""),
        "whitelist": signal_section.get("whitelist") or [],
        "session_timeout": int(signal_section.get("session_timeout", 3600)),
    }

    if sv := os.environ.get("SIGNAL_SERVICE"):
        result["signal_service"] = sv
    if spn := os.environ.get("SIGNAL_PHONE_NUMBER"):
        result["phone_number"] = spn
    if swl := os.environ.get("SIGNAL_WHITELIST"):
        result["whitelist"] = [n.strip() for n in swl.split(",") if n.strip()]

    return result
