# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER RAG retriever — semantic search over the knowledge base.

Uses ChromaDB (embedded, persistent) to store and query document chunks.
Chunks are split on markdown headers to preserve semantic boundaries.

Usage:
    from gateway.retriever import Retriever

    retriever = Retriever()
    chunks = retriever.query("Kerberos AS-REP roasting", top_k=5)
    context = retriever.format_context(chunks)
"""
from __future__ import annotations

import logging
from pathlib import Path

import chromadb

from gateway.prompt import REPO_ROOT

logger = logging.getLogger(__name__)

# Default persistent storage location.
_DEFAULT_DB_DIR = REPO_ROOT / ".chromadb"
_COLLECTION_NAME = "cipher_knowledge"


class Retriever:
    """Semantic retriever over CIPHER knowledge base.

    Wraps a ChromaDB persistent collection. On init, connects to the
    existing store (or creates it if missing). Use ``ingest()`` to
    populate or refresh the index from ``knowledge/`` files.
    """

    def __init__(self, db_dir: Path | None = None) -> None:
        self._db_dir = db_dir or _DEFAULT_DB_DIR
        self._client = chromadb.PersistentClient(path=str(self._db_dir))
        self._collection = self._client.get_or_create_collection(
            name=_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )
        count = self._collection.count()
        logger.info("Retriever: loaded collection %r (%d chunks)", _COLLECTION_NAME, count)

    @property
    def count(self) -> int:
        """Number of chunks in the collection."""
        return self._collection.count()

    def query(self, text: str, top_k: int = 5) -> list[dict]:
        """Retrieve the most relevant chunks for *text*.

        Args:
            text: Query string.
            top_k: Maximum number of chunks to return.

        Returns:
            List of dicts with keys: document, source, distance.
        """
        if self._collection.count() == 0:
            logger.warning("Retriever: collection is empty — run 'cipher-gw ingest' first")
            return []

        results = self._collection.query(
            query_texts=[text],
            n_results=min(top_k, self._collection.count()),
        )

        chunks: list[dict] = []
        for i, doc in enumerate(results["documents"][0]):
            meta = results["metadatas"][0][i]
            dist = results["distances"][0][i] if results.get("distances") else None
            chunks.append({
                "document": doc,
                "source": meta.get("source", "unknown"),
                "section": meta.get("section", ""),
                "distance": dist,
            })
        return chunks

    @staticmethod
    def format_context(chunks: list[dict], max_tokens_estimate: int = 6000) -> str:
        """Format retrieved chunks into a context block for injection.

        Estimates ~4 chars per token. Truncates to stay within budget.

        Args:
            chunks: List of chunk dicts from query().
            max_tokens_estimate: Rough token budget for the context block.

        Returns:
            Formatted context string ready for system prompt injection.
        """
        if not chunks:
            return ""

        max_chars = max_tokens_estimate * 4
        lines: list[str] = ["## Retrieved Knowledge Context\n"]
        current_len = len(lines[0])

        for chunk in chunks:
            source = chunk["source"]
            section = chunk.get("section", "")
            header = f"### [{source}] {section}".strip()
            entry = f"{header}\n{chunk['document']}\n"

            if current_len + len(entry) > max_chars:
                break

            lines.append(entry)
            current_len += len(entry)

        return "\n".join(lines)

    def ingest(
        self,
        knowledge_dir: Path | None = None,
        chunk_size: int = 1500,
        chunk_overlap: int = 200,
    ) -> int:
        """Ingest knowledge files into the vector store.

        Clears the existing collection and re-indexes from scratch.

        Args:
            knowledge_dir: Path to knowledge/ directory. Defaults to REPO_ROOT/knowledge.
            chunk_size: Target chunk size in characters.
            chunk_overlap: Overlap between consecutive chunks in characters.

        Returns:
            Number of chunks indexed.
        """
        kb_dir = knowledge_dir or REPO_ROOT / "knowledge"
        if not kb_dir.is_dir():
            raise FileNotFoundError(f"Knowledge directory not found: {kb_dir}")

        md_files = sorted(kb_dir.glob("*.md"))
        if not md_files:
            raise FileNotFoundError(f"No .md files found in {kb_dir}")

        logger.info("Retriever: ingesting %d files from %s", len(md_files), kb_dir)

        # Clear existing data.
        self._client.delete_collection(_COLLECTION_NAME)
        self._collection = self._client.get_or_create_collection(
            name=_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

        total_chunks = 0
        for md_file in md_files:
            filename = md_file.name
            text = md_file.read_text(encoding="utf-8")
            chunks = _split_markdown(text, filename, chunk_size, chunk_overlap)

            if not chunks:
                continue

            ids = [f"{filename}::{i}" for i in range(len(chunks))]
            documents = [c["text"] for c in chunks]
            metadatas = [{"source": c["source"], "section": c["section"]} for c in chunks]

            # ChromaDB has a batch limit; add in batches of 500.
            for batch_start in range(0, len(ids), 500):
                batch_end = batch_start + 500
                self._collection.add(
                    ids=ids[batch_start:batch_end],
                    documents=documents[batch_start:batch_end],
                    metadatas=metadatas[batch_start:batch_end],
                )

            total_chunks += len(chunks)
            logger.debug("  %s: %d chunks", filename, len(chunks))

        logger.info("Retriever: ingested %d chunks from %d files", total_chunks, len(md_files))
        return total_chunks


def _split_markdown(
    text: str,
    filename: str,
    chunk_size: int = 1500,
    chunk_overlap: int = 200,
) -> list[dict]:
    """Split a markdown document into chunks on header boundaries.

    Strategy:
    1. Split on ## and ### headers (keeping higher-level context).
    2. If a section exceeds chunk_size, split it further at paragraph
       boundaries with overlap.
    3. Each chunk carries its source filename and section header.

    Args:
        text: Full markdown text.
        filename: Source filename for metadata.
        chunk_size: Target chunk size in characters.
        chunk_overlap: Overlap between chunks when splitting long sections.

    Returns:
        List of dicts with keys: text, source, section.
    """
    import re

    chunks: list[dict] = []

    # Split on markdown headers (## or ###), keeping the header with its section.
    sections = re.split(r"(?=^#{1,3}\s)", text, flags=re.MULTILINE)

    current_header = filename.replace(".md", "").replace("-", " ").title()

    for section in sections:
        section = section.strip()
        if not section:
            continue

        # Extract section header if present.
        header_match = re.match(r"^(#{1,3})\s+(.+)", section)
        if header_match:
            current_header = header_match.group(2).strip()

        if len(section) <= chunk_size:
            chunks.append({
                "text": section,
                "source": filename,
                "section": current_header,
            })
        else:
            # Split long sections at paragraph boundaries.
            paragraphs = re.split(r"\n\n+", section)
            buffer = ""
            for para in paragraphs:
                if buffer and len(buffer) + len(para) + 2 > chunk_size:
                    chunks.append({
                        "text": buffer.strip(),
                        "source": filename,
                        "section": current_header,
                    })
                    # Keep overlap from the end of the buffer.
                    if chunk_overlap > 0:
                        buffer = buffer[-chunk_overlap:] + "\n\n" + para
                    else:
                        buffer = para
                else:
                    buffer = buffer + "\n\n" + para if buffer else para

            if buffer.strip():
                chunks.append({
                    "text": buffer.strip(),
                    "source": filename,
                    "section": current_header,
                })

    return chunks
