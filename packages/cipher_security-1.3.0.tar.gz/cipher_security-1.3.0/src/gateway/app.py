# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER CLI — Typer-based command interface.

Usage:
    cipher "how to detect Kerberoasting"
    cipher --backend ollama "reverse shell techniques"
    cipher --smart "design a zero trust architecture"
    cipher setup
    cipher doctor
    cipher status
    cipher ingest
"""
from __future__ import annotations

import sys
from enum import Enum
from pathlib import Path
from typing import Optional

import typer
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from gateway.theme import (
    MODE_COLORS,
    console,
    err_console,
    print_banner,
    print_error,
    print_info,
    print_success,
    print_warn,
)

app = typer.Typer(
    name="cipher",
    help="CIPHER — Security Engineering Assistant",
    no_args_is_help=True,
    rich_markup_mode="rich",
    add_completion=True,
)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class Backend(str, Enum):
    ollama = "ollama"
    claude = "claude"
    litellm = "litellm"


# ---------------------------------------------------------------------------
# Smart routing (complexity classifier)
# ---------------------------------------------------------------------------

def _select_backend_smart(message: str) -> str:
    from gateway.complexity import classify_and_route
    level, backend = classify_and_route(message)
    err_console.print(f"[cipher.muted]complexity: {level.name} (score-based)[/]")
    return backend


# ---------------------------------------------------------------------------
# cipher query (default command)
# ---------------------------------------------------------------------------

@app.command()
def query(
    message: Optional[str] = typer.Argument(None, help="Security query to send to CIPHER."),
    backend: Optional[Backend] = typer.Option(None, "--backend", "-b", help="LLM backend override."),
    smart: bool = typer.Option(False, "--smart", "-s", help="Auto-route: simple→Ollama, complex→Claude."),
    stream: bool = typer.Option(True, "--stream/--no-stream", help="Stream response tokens."),
) -> None:
    """Send a security query through the CIPHER pipeline."""
    if message is None:
        if not sys.stdin.isatty():
            message = sys.stdin.read().strip()
        else:
            console.print("[cipher.error]No query provided.[/] Pass a message or pipe via stdin.")
            raise typer.Exit(2)

    if not message:
        console.print("[cipher.error]Query is empty.[/]")
        raise typer.Exit(2)

    from gateway.gateway import Gateway

    # Smart routing
    backend_str = None
    if smart and backend is None:
        backend_str = _select_backend_smart(message)
        err_console.print(f"[cipher.muted]smart routing → {backend_str}[/]")
    elif backend is not None:
        backend_str = backend.value

    try:
        gw = Gateway(backend_override=backend_str)
    except ValueError as exc:
        console.print(f"[cipher.error]{exc}[/]")
        console.print("\nRun: [bold]cipher setup[/]")
        raise typer.Exit(1)

    if stream:
        # Stream tokens as they arrive
        header_printed = False
        for token in gw.send_stream(message):
            if not header_printed and token.startswith("[MODE:"):
                mode = token.split(":")[1].strip().rstrip("]\n").strip()
                color = MODE_COLORS.get(mode, "#00ff41")
                console.print(f"[{color}]{token.strip()}[/]")
                header_printed = True
            else:
                console.out(token, end="")
        console.print()  # Final newline
    else:
        # Non-streaming: spinner + full response
        with console.status("[cipher.primary]Thinking...", spinner="dots"):
            result = gw.send(message)
        _print_response(result)


def _print_response(text: str) -> None:
    """Print a CIPHER response with colorized mode header."""
    lines = text.split("\n", 1)
    header = lines[0]
    body = lines[1] if len(lines) > 1 else ""

    # Extract mode from header
    mode = None
    if header.startswith("[MODE:"):
        mode = header.split(":")[1].strip().rstrip("]").strip()

    if mode and mode in MODE_COLORS:
        color = MODE_COLORS[mode]
        console.print(f"[{color}]{header}[/]")
    else:
        console.print(header)

    if body.strip():
        console.print(Markdown(body))


# ---------------------------------------------------------------------------
# cipher ingest
# ---------------------------------------------------------------------------

@app.command()
def ingest() -> None:
    """Re-index the knowledge base into the RAG vector store."""
    from gateway.retriever import Retriever

    print_banner()
    console.print("[cipher.primary]RAG Ingestion[/]\n")

    with console.status("[cipher.primary]Indexing knowledge base...", spinner="dots"):
        retriever = Retriever()
        count = retriever.ingest()

    print_success(f"Indexed {count} chunks into ChromaDB")
    print_info("RAG retrieval is now active for queries")


# ---------------------------------------------------------------------------
# cipher dashboard
# ---------------------------------------------------------------------------

@app.command()
def dashboard() -> None:
    """Launch the interactive cyberpunk terminal dashboard."""
    from gateway.dashboard import run_dashboard
    run_dashboard()


# ---------------------------------------------------------------------------
# cipher web — serve dashboard in browser via textual-serve
# ---------------------------------------------------------------------------

@app.command()
def web(
    host: str = typer.Option("localhost", "--host", "-H", help="Bind address."),
    port: int = typer.Option(8566, "--port", "-p", help="Port to serve on."),
    title: str = typer.Option("CIPHER", "--title", help="Browser tab title."),
) -> None:
    """Serve the CIPHER dashboard in a web browser.

    Requires: pip install cipher-security[web]
    """
    try:
        from textual_serve.server import Server
    except ImportError:
        print_error("textual-serve is required for web mode.")
        print_info("Install with: pip install cipher-security[web]")
        raise typer.Exit(1)

    print_info(f"Starting CIPHER web UI on http://{host}:{port}")
    print_info("Press Ctrl+C to stop")

    import shutil
    import sys

    # Determine the best command to launch the dashboard subprocess.
    # If cipher is installed as a package, use the CLI entrypoint.
    # Otherwise, use the Python interpreter with the gateway module directly.
    if shutil.which("cipher"):
        command = "cipher dashboard"
    else:
        python = sys.executable
        # Ensure src/ is on the path for dev mode
        src_dir = Path(__file__).resolve().parent.parent
        command = f"PYTHONPATH={src_dir}:$PYTHONPATH {python} -c 'from gateway.dashboard import run_dashboard; run_dashboard()'"

    server = Server(
        command,
        host=host,
        port=port,
        title=title,
    )
    server.serve()


# ---------------------------------------------------------------------------
# Plugin management
# ---------------------------------------------------------------------------

plugin_app = typer.Typer(
    name="plugin",
    help="Manage community skill plugins.",
    no_args_is_help=True,
)
app.add_typer(plugin_app, name="plugin")


@plugin_app.command("list")
def plugin_list() -> None:
    """List all discovered plugins."""
    from gateway.plugins import PluginManager

    pm = PluginManager()
    plugins = pm.list_plugins()

    if not plugins:
        print_info("No plugins installed.")
        print_info("Install with: cipher plugin install <path-or-git-url>")
        print_info("Plugin directory: ~/.config/cipher/plugins/")
        return

    table = Table(title="Installed Plugins", box=None, padding=(0, 2))
    table.add_column("Name", style="bold")
    table.add_column("Version")
    table.add_column("Modes")
    table.add_column("Source")
    table.add_column("Author", style="dim")

    for p in plugins:
        table.add_row(
            p["name"],
            p["version"],
            ", ".join(p["modes"]) if p["modes"] else "—",
            p["source"],
            p["author"],
        )

    console.print(table)


@plugin_app.command("install")
def plugin_install(
    source: str = typer.Argument(..., help="Local directory path or git URL."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Override plugin name."),
) -> None:
    """Install a community skill plugin from a directory or git repo."""
    from gateway.plugins import install_plugin

    try:
        with console.status("[cipher.primary]Installing plugin...", spinner="dots"):
            plugin = install_plugin(source, name=name)
        print_success(f"Installed plugin: {plugin.name} v{plugin.version}")
        if plugin.modes:
            print_info(f"  Modes: {', '.join(plugin.modes)}")
        if plugin.description:
            print_info(f"  {plugin.description}")
        print_info(f"  Path: {plugin.path}")
    except (FileNotFoundError, ValueError) as exc:
        print_error(str(exc))
        raise typer.Exit(1)


@plugin_app.command("remove")
def plugin_remove(
    name: str = typer.Argument(..., help="Plugin name to remove."),
) -> None:
    """Remove an installed plugin."""
    from gateway.plugins import uninstall_plugin

    if uninstall_plugin(name):
        print_success(f"Removed plugin: {name}")
    else:
        print_error(f"Plugin not found: {name}")
        print_info("Run 'cipher plugin list' to see installed plugins.")
        raise typer.Exit(1)


@plugin_app.command("info")
def plugin_info(
    name: str = typer.Argument(..., help="Plugin name."),
) -> None:
    """Show detailed information about a plugin."""
    from gateway.plugins import PluginManager

    pm = PluginManager()
    plugin = pm.get_plugin_by_name(name)

    if plugin is None:
        print_error(f"Plugin not found: {name}")
        raise typer.Exit(1)

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="cipher.muted")
    table.add_column("Value")

    table.add_row("Name", f"[bold]{plugin.name}[/]")
    table.add_row("Version", plugin.version)
    table.add_row("Author", plugin.author)
    table.add_row("Description", plugin.description or "—")
    table.add_row("Modes", ", ".join(plugin.modes) if plugin.modes else "—")
    table.add_row("Triggers", ", ".join(plugin.triggers) if plugin.triggers else "—")
    table.add_row("Priority", str(plugin.priority))
    table.add_row("Source", plugin.source)
    table.add_row("Path", str(plugin.path))
    if plugin.sub_skills:
        table.add_row("Sub-skills", ", ".join(sorted(plugin.sub_skills.keys())))

    console.print(Panel(table, title="[cipher.primary]Plugin Details[/]", border_style="cipher.primary"))


# ---------------------------------------------------------------------------
# Shell completion installation helper
# ---------------------------------------------------------------------------

def _install_completions(repo_root: Path, non_interactive: bool = False) -> None:
    """Install shell completions for the user's current shell."""
    import shutil

    completions_dir = repo_root / "completions"
    if not completions_dir.is_dir():
        print_info("Completions directory not found — skipping")
        return

    shell = _detect_shell()
    if shell is None:
        print_info("Could not detect shell — skipping completion install")
        print_info("Manual install: source completions/cipher.{bash,zsh,fish}")
        return

    if shell == "fish":
        src = completions_dir / "cipher.fish"
        dst = Path.home() / ".config" / "fish" / "completions" / "cipher.fish"
        if not src.exists():
            print_warn("Fish completion script not found")
            return
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print_success(f"Fish completions installed to {dst}")

    elif shell == "bash":
        src = completions_dir / "cipher.bash"
        if not src.exists():
            print_warn("Bash completion script not found")
            return
        # Try XDG first, then ~/.bash_completion.d/, then ~/.bashrc
        xdg_dir = Path.home() / ".local" / "share" / "bash-completion" / "completions"
        if xdg_dir.parent.is_dir() or (Path.home() / ".bashrc").exists():
            xdg_dir.mkdir(parents=True, exist_ok=True)
            dst = xdg_dir / "cipher"
            shutil.copy2(src, dst)
            print_success(f"Bash completions installed to {dst}")
        else:
            print_info("Add to ~/.bashrc: source " + str(src))

    elif shell == "zsh":
        src = completions_dir / "cipher.zsh"
        if not src.exists():
            print_warn("Zsh completion script not found")
            return
        # Install to ~/.zfunc/ and advise adding to fpath
        zfunc_dir = Path.home() / ".zfunc"
        zfunc_dir.mkdir(parents=True, exist_ok=True)
        dst = zfunc_dir / "_cipher"
        shutil.copy2(src, dst)
        print_success(f"Zsh completions installed to {dst}")
        # Check if fpath already includes ~/.zfunc
        zshrc = Path.home() / ".zshrc"
        if zshrc.exists() and ".zfunc" not in zshrc.read_text():
            print_info("Add to ~/.zshrc: fpath+=~/.zfunc && autoload -Uz compinit && compinit")

    else:
        print_info(f"Unsupported shell '{shell}' — manual install: source completions/cipher.bash")


def _detect_shell() -> str | None:
    """Detect the user's current shell (fish, bash, zsh, or None)."""
    import os

    shell_path = os.environ.get("SHELL", "")
    if not shell_path:
        return None

    shell_name = Path(shell_path).name
    if shell_name in ("fish", "bash", "zsh"):
        return shell_name
    return None


# ---------------------------------------------------------------------------
# Hook installation helper
# ---------------------------------------------------------------------------

def _install_hooks(hooks_dir: Path, non_interactive: bool = False) -> None:
    """Register CIPHER hooks in Claude Code's settings.json.

    Detects existing GSD hooks and coexists with them rather than replacing.
    """
    import json

    settings_path = Path.home() / ".claude" / "settings.json"

    # Load existing settings
    settings: dict = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    statusline_js = hooks_dir / "cipher-statusline.js"
    monitor_js = hooks_dir / "cipher-context-monitor.js"

    if not statusline_js.exists() or not monitor_js.exists():
        print_warn("Hook files not found in hooks/ — skipping")
        return

    statusline_cmd = f'node "{statusline_js}"'
    monitor_cmd = f'node "{monitor_js}"'

    # Check what's already installed
    existing_statusline = json.dumps(settings.get("statusLine", {}))
    has_gsd_statusline = "gsd-statusline" in existing_statusline
    has_cipher_statusline = "cipher-statusline" in existing_statusline

    existing_hooks = json.dumps(settings.get("hooks", {}))
    has_gsd_monitor = "gsd-context-monitor" in existing_hooks
    has_cipher_monitor = "cipher-context-monitor" in existing_hooks

    if has_cipher_statusline and has_cipher_monitor:
        print_success("Claude Code hooks already installed")
        return

    # Install statusline (only if no existing statusline or GSD is present)
    if has_gsd_statusline:
        print_success("GSD statusline detected — keeping it (CIPHER monitor will run alongside)")
    elif not has_cipher_statusline:
        settings["statusLine"] = {"type": "command", "command": statusline_cmd}
        print_success("Statusline hook installed")

    # Install context monitor
    if not has_cipher_monitor:
        hooks_section = settings.setdefault("hooks", {})
        post_tool_use = hooks_section.setdefault("PostToolUse", [])
        post_tool_use.append({
            "hooks": [{"type": "command", "command": monitor_cmd}]
        })
        if has_gsd_monitor:
            print_success("Context monitor installed alongside GSD")
        else:
            print_success("Context monitor hook installed")

    # Write back
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(json.dumps(settings, indent=2) + "\n")


# ---------------------------------------------------------------------------
# Slash command installation helper
# ---------------------------------------------------------------------------

def _install_commands(commands_dir: Path) -> int:
    """Copy CIPHER slash commands to ~/.claude/commands/cipher/.

    Returns the number of command files installed.
    """
    import shutil

    claude_dir = Path.home() / ".claude"
    if not claude_dir.is_dir():
        print_info("~/.claude/ not found — skipping slash command install")
        return 0

    target_dir = claude_dir / "commands" / "cipher"
    target_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    for md_file in sorted(commands_dir.glob("*.md")):
        shutil.copy2(md_file, target_dir / md_file.name)
        count += 1

    return count


# ---------------------------------------------------------------------------
# cipher setup
# ---------------------------------------------------------------------------

@app.command()
def setup(
    backend: Optional[Backend] = typer.Option(None, "--backend", "-b", help="Pre-select backend (skip prompt)."),
    api_key: Optional[str] = typer.Option(None, "--api-key", help="Claude API key (skip prompt)."),
    non_interactive: bool = typer.Option(False, "--non-interactive", help="No prompts, use flags + env vars."),
) -> None:
    """Interactive onboarding wizard — configure CIPHER on first run."""
    import shutil
    import subprocess

    import yaml
    from rich.prompt import Confirm, Prompt

    from gateway.prompt import REPO_ROOT

    print_banner()
    console.print("[cipher.primary]Setup Wizard[/]\n")

    total_steps = 7
    _ = total_steps  # used in step display below

    config: dict = {}

    # Step 1: Choose backend
    if backend is not None:
        chosen_backend = backend.value
    elif non_interactive:
        chosen_backend = "ollama"
    else:
        console.print("  [cipher.primary]Choose your LLM backend:[/]\n")
        console.print("  [bold]1[/] [cipher.success]Ollama[/]  — Local inference, free, private (requires GPU)")
        console.print("  [bold]2[/] [cipher.accent]Claude API[/] — Cloud inference, paid, highest quality")
        console.print("  [bold]3[/] [cipher.primary]LiteLLM[/]   — Multi-provider (OpenAI, Gemini, llama.cpp, etc.)\n")
        choice = Prompt.ask("  Select", choices=["1", "2", "3"], default="1")
        chosen_backend = {"1": "ollama", "2": "claude", "3": "litellm"}[choice]

    config["llm_backend"] = chosen_backend
    print_success(f"Backend: {chosen_backend}")
    console.print()

    # Step 2: Backend-specific configuration
    if chosen_backend == "ollama":
        # Check if Ollama is running
        ollama_url = "http://127.0.0.1:11434"
        config["ollama"] = {"base_url": ollama_url, "model": "cipher", "timeout": 300}

        if shutil.which("ollama"):
            try:
                r = subprocess.run(["ollama", "list"], capture_output=True, timeout=5)
                if r.returncode == 0:
                    print_success("Ollama is running")
                    output = r.stdout.decode()
                    if "cipher" not in output:
                        console.print()
                        if non_interactive or Confirm.ask("  [cipher.warning]cipher model not found.[/] Create it now?", default=True):
                            modelfile = REPO_ROOT / "Modelfile"
                            if modelfile.exists():
                                with console.status("[cipher.primary]Creating cipher model (this may take a minute)...", spinner="dots"):
                                    subprocess.run(
                                        ["ollama", "create", "cipher", "-f", str(modelfile)],
                                        capture_output=True, timeout=300,
                                    )
                                print_success("cipher model created (qwen2.5:32b)")
                            else:
                                print_warn("Modelfile not found — create manually: ollama create cipher -f Modelfile")
                    else:
                        print_success("cipher model loaded")
                else:
                    print_warn("Ollama installed but not responding — start with: ollama serve")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                print_warn("Ollama not responding — start with: ollama serve")
        else:
            print_warn("Ollama not installed — see https://ollama.com/download")

        # Set default Claude config (empty, for when user switches later)
        config["claude"] = {"api_key": "", "model": "claude-sonnet-4-5-20250929", "timeout": 120}

    elif chosen_backend == "litellm":
        # LiteLLM multi-provider setup
        config["ollama"] = {"base_url": "http://127.0.0.1:11434", "model": "cipher", "timeout": 300}
        config["claude"] = {"api_key": "", "model": "claude-sonnet-4-5-20250929", "timeout": 120}

        console.print("  [cipher.primary]LiteLLM model string[/] (e.g. gpt-4o, gemini/gemini-2.0-flash, ollama/llama3.1)")
        console.print("  [cipher.muted]See: https://docs.litellm.ai/docs/providers[/]\n")

        if non_interactive:
            litellm_model = ""
            print_warn("Set litellm.model in config.yaml manually")
        else:
            litellm_model = Prompt.ask("  Model")

        litellm_key = ""
        litellm_base = ""
        if not non_interactive and litellm_model:
            litellm_key = Prompt.ask("  API key (leave blank if not needed)", default="", password=True)
            litellm_base = Prompt.ask("  Custom API base URL (leave blank for default)", default="")

        config["litellm"] = {
            "model": litellm_model,
            "api_key": litellm_key,
            "api_base": litellm_base,
            "timeout": 120,
        }

        if litellm_model:
            print_success(f"LiteLLM configured: {litellm_model}")
        else:
            print_warn("No model set — configure litellm.model in config.yaml")

    else:  # claude
        config["ollama"] = {"base_url": "http://127.0.0.1:11434", "model": "cipher", "timeout": 300}

        # Get API key
        if api_key:
            key = api_key
        elif non_interactive:
            import os
            key = os.environ.get("ANTHROPIC_API_KEY", "")
            if not key:
                print_error("--non-interactive requires ANTHROPIC_API_KEY env var or --api-key")
                raise typer.Exit(1)
        else:
            key = Prompt.ask("  [cipher.accent]Anthropic API key[/]", password=True)

        if key:
            # Validate key
            with console.status("[cipher.primary]Validating API key...", spinner="dots"):
                try:
                    import anthropic
                    client = anthropic.Anthropic(api_key=key)
                    client.messages.create(
                        model="claude-sonnet-4-5-20250929",
                        max_tokens=10,
                        messages=[{"role": "user", "content": "ping"}],
                    )
                    print_success("API key validated")
                except Exception as exc:
                    print_error(f"API key validation failed: {exc}")
                    if not non_interactive and not Confirm.ask("  Continue anyway?", default=False):
                        raise typer.Exit(1)

        config["claude"] = {"api_key": key, "model": "claude-sonnet-4-5-20250929", "timeout": 120}

    # Step 3: Write config
    # Write to ~/.config/cipher/config.yaml (user config, always found by load_config)
    # Also write to REPO_ROOT if it's a dev checkout (has pyproject.toml)
    console.print()
    from pathlib import Path
    user_config_dir = Path.home() / ".config" / "cipher"
    user_config_dir.mkdir(parents=True, exist_ok=True)
    user_config_path = user_config_dir / "config.yaml"
    with open(user_config_path, "w") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)
    print_success(f"Config written to {user_config_path}")

    # Also write to project root if in dev mode
    project_config = REPO_ROOT / "config.yaml"
    if (REPO_ROOT / "pyproject.toml").exists() and project_config.parent != user_config_dir:
        with open(project_config, "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)
        print_info(f"Also written to {project_config}")

    # Step 4: Install slash commands to ~/.claude/commands/cipher/
    console.print()
    commands_dir = REPO_ROOT / "commands"
    if commands_dir.is_dir():
        cmd_count = _install_commands(commands_dir)
        if cmd_count > 0:
            print_success(f"Installed {cmd_count} slash commands to ~/.claude/commands/cipher/")
        # else: _install_commands already printed skip message
    else:
        print_info("Commands directory not found — skipping slash command install")

    # Step 5: Install Claude Code hooks (statusline + context monitor)
    console.print()
    hooks_dir = REPO_ROOT / "hooks"
    if hooks_dir.is_dir():
        _install_hooks(hooks_dir, non_interactive)
    else:
        print_info("Hooks directory not found — skipping hook registration")
        print_info("Run /cipher:setup-hooks from the CIPHER repo to install manually")

    # Step 6: Install shell completions
    console.print()
    _install_completions(REPO_ROOT, non_interactive)

    # Step 7: Ingest knowledge base (skip if already populated)
    console.print()
    try:
        from gateway.retriever import Retriever
        retriever = Retriever()
        if retriever.count > 0:
            print_success(f"RAG index already populated ({retriever.count:,} chunks)")
        else:
            console.print("  [cipher.primary]Indexing knowledge base...[/]")
            with console.status("[cipher.primary]Building RAG index...", spinner="dots"):
                count = retriever.ingest()
            print_success(f"Indexed {count:,} chunks from knowledge/")
    except Exception as exc:
        print_warn(f"RAG indexing failed: {exc}")
        print_info("Run 'cipher ingest' later to retry")

    # Step 8: Demo query
    console.print()
    if not non_interactive and Confirm.ask("  [cipher.primary]Run a demo query?[/]", default=True):
        demo_query = "What are the top 3 techniques for detecting lateral movement?"
        console.print(f"\n  [cipher.muted]> {demo_query}[/]\n")
        try:
            with console.status("[cipher.primary]Thinking...", spinner="dots"):
                from gateway.gateway import Gateway
                gw = Gateway(backend_override=chosen_backend)
                result = gw.send(demo_query)
            _print_response(result)
        except Exception as exc:
            print_warn(f"Demo query failed: {exc}")
            print_info("This is normal if the backend isn't fully configured yet")

    # Done
    console.print()
    console.print(Panel(
        "[cipher.success]Setup complete![/]\n\n"
        'Try: [bold]cipher "how do I detect Kerberoasting"[/]\n'
        "Run: [bold]cipher doctor[/] to verify everything\n"
        "Run: [bold]cipher status[/] to see system info",
        title="[cipher.primary]Ready[/]",
        border_style="cipher.primary",
    ))


# ---------------------------------------------------------------------------
# cipher status
# ---------------------------------------------------------------------------

@app.command()
def status() -> None:
    """Show CIPHER system status."""
    from gateway.prompt import REPO_ROOT

    print_banner()

    try:
        from gateway.config import load_config
        cfg = load_config()
    except (ValueError, FileNotFoundError):
        console.print("[cipher.warning]No configuration found.[/] Run: [bold]cipher setup[/]")
        raise typer.Exit(1)

    # Backend
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="cipher.muted")
    table.add_column("Value")

    table.add_row("Backend", f"[bold]{cfg.backend}[/]")

    if cfg.backend == "ollama":
        table.add_row("Model", cfg.ollama_model)
        table.add_row("Ollama URL", cfg.ollama_base_url)
    else:
        table.add_row("Model", cfg.claude_model)

    # RAG
    try:
        from gateway.retriever import Retriever
        r = Retriever()
        table.add_row("RAG Chunks", f"[cipher.success]{r.count:,}[/]")
    except Exception:
        table.add_row("RAG Chunks", "[cipher.warning]unavailable[/]")

    # Knowledge
    kb_dir = REPO_ROOT / "knowledge"
    if kb_dir.is_dir():
        md_count = len(list(kb_dir.glob("*.md")))
        table.add_row("Knowledge Docs", str(md_count))

    # Skills
    skills_dir = REPO_ROOT / "skills"
    if skills_dir.is_dir():
        skill_count = len(list(skills_dir.rglob("SKILL.md")))
        table.add_row("Skill Files", str(skill_count))

    # Plugins
    try:
        from gateway.plugins import PluginManager
        pm = PluginManager()
        plugin_count = len(pm.plugins)
        if plugin_count > 0:
            table.add_row("Plugins", f"[cipher.success]{plugin_count}[/]")
        else:
            table.add_row("Plugins", "[cipher.muted]none[/]")
    except Exception:
        table.add_row("Plugins", "[cipher.muted]unavailable[/]")

    # Modes
    table.add_row("Modes", "RED, BLUE, PURPLE, PRIVACY, RECON, INCIDENT, ARCHITECT")

    console.print(Panel(table, title="[cipher.primary]CIPHER Status[/]", border_style="cipher.primary"))


# ---------------------------------------------------------------------------
# cipher doctor
# ---------------------------------------------------------------------------

@app.command()
def doctor(
    fix: bool = typer.Option(False, "--fix", help="Auto-repair issues where possible."),
) -> None:
    """Run diagnostics and health checks."""
    import shutil
    import subprocess

    from gateway.prompt import REPO_ROOT

    print_banner()
    console.print("[cipher.primary]Diagnostics[/]\n")

    issues = 0

    # 1. Python version
    v = sys.version_info
    if v >= (3, 10):
        print_success(f"Python {v.major}.{v.minor}.{v.micro}")
    else:
        print_error(f"Python {v.major}.{v.minor} — need 3.10+")
        issues += 1

    # 2. Ollama running
    if shutil.which("ollama"):
        try:
            r = subprocess.run(["ollama", "list"], capture_output=True, timeout=5)
            if r.returncode == 0:
                output = r.stdout.decode()
                if "cipher" in output:
                    print_success("Ollama running, cipher model loaded")
                else:
                    print_warn("Ollama running but cipher model not found")
                    if fix:
                        print_info("Creating cipher model...")
                        modelfile = REPO_ROOT / "Modelfile"
                        if modelfile.exists():
                            subprocess.run(["ollama", "create", "cipher", "-f", str(modelfile)], timeout=300)
                            print_success("cipher model created")
                    else:
                        print_info("Run: ollama create cipher -f Modelfile")
                    issues += 1
            else:
                print_error("Ollama not responding")
                issues += 1
        except (subprocess.TimeoutExpired, FileNotFoundError):
            print_error("Ollama not responding")
            issues += 1
    else:
        print_warn("Ollama not installed (optional for local inference)")

    # 3. Claude API key
    import os
    if os.environ.get("ANTHROPIC_API_KEY"):
        print_success("Claude API key configured (env)")
    else:
        try:
            from gateway.config import load_config
            cfg = load_config()
            if cfg.claude_api_key:
                print_success("Claude API key configured (config)")
            else:
                print_warn("No Claude API key (optional if using Ollama)")
        except Exception:
            print_warn("No Claude API key configured")

    # 4. RAG index
    try:
        from gateway.retriever import Retriever
        r = Retriever()
        if r.count > 0:
            print_success(f"RAG index: {r.count:,} chunks")
        else:
            print_error("RAG index empty")
            if fix:
                print_info("Ingesting knowledge base...")
                count = r.ingest()
                print_success(f"Ingested {count:,} chunks")
            else:
                print_info("Run: cipher ingest")
            issues += 1
    except Exception as exc:
        print_error(f"RAG unavailable: {exc}")
        issues += 1

    # 5. Knowledge directory
    kb_dir = REPO_ROOT / "knowledge"
    if kb_dir.is_dir():
        md_files = list(kb_dir.glob("*.md"))
        empty = [f for f in md_files if f.stat().st_size < 100]
        if empty:
            print_warn(f"Knowledge: {len(md_files)} docs, {len(empty)} empty/tiny")
            for f in empty:
                print_info(f"  {f.name}")
            issues += 1
        else:
            print_success(f"Knowledge: {len(md_files)} docs, all have content")
    else:
        print_error("Knowledge directory missing")
        issues += 1

    # 6. Skill files
    skills_dir = REPO_ROOT / "skills"
    expected_skills = [
        "red-team", "blue-team", "purple-team", "privacy-engineering",
        "osint-recon", "incident-response", "threat-intelligence",
        "automation-scripting", "security-architecture",
    ]
    missing_skills = [s for s in expected_skills if not (skills_dir / s / "SKILL.md").exists()]
    if missing_skills:
        print_error(f"Missing skill files: {', '.join(missing_skills)}")
        issues += 1
    else:
        print_success(f"All {len(expected_skills)} skill files present")

    # Summary
    console.print()
    if issues == 0:
        console.print("[cipher.success]All checks passed.[/]")
    else:
        console.print(f"[cipher.warning]{issues} issue(s) found.[/]")
        if not fix:
            console.print("[cipher.muted]Run with --fix to auto-repair.[/]")


# ---------------------------------------------------------------------------
# cipher setup-signal (preserved from original)
# ---------------------------------------------------------------------------

@app.command("setup-signal")
def setup_signal(
    signal_api: str = typer.Option("http://localhost:8080", help="signal-cli-rest-api URL."),
) -> None:
    """Register a Signal phone number for the CIPHER bot."""
    import httpx

    print_banner()
    console.print("[cipher.primary]Signal Bot Registration[/]\n")
    print_info("Prerequisites: docker compose up -d signal-api\n")

    with httpx.Client(timeout=10) as client:
        # Verify API
        try:
            client.get(f"{signal_api.rstrip('/')}/v1/about").raise_for_status()
            print_success("signal-cli-rest-api is reachable")
        except Exception as exc:
            print_error(f"Cannot reach signal-cli-rest-api: {exc}")
            raise typer.Exit(1)

        # Register
        number = typer.prompt("Phone number (E.164)")
        console.print("\n[cipher.muted]Captcha steps:[/]")
        print_info("1. Open https://signalcaptchas.org/registration/generate.html")
        print_info("2. Solve the captcha")
        print_info("3. Right-click 'Open Signal' → Copy link address")
        raw = typer.prompt("Captcha URL or token")
        token = raw.removeprefix("signalcaptcha://")

        try:
            client.post(
                f"{signal_api.rstrip('/')}/v1/register/{number}",
                json={"captcha": token, "use_voice": False},
            ).raise_for_status()
        except httpx.HTTPStatusError as exc:
            print_error(f"Registration failed: {exc}")
            print_info("Captcha must be solved from same IP as signal-cli-rest-api")
            raise typer.Exit(1)

        code = typer.prompt("Verification code")
        try:
            client.post(f"{signal_api.rstrip('/')}/v1/register/{number}/verify/{code}").raise_for_status()
        except httpx.HTTPStatusError as exc:
            print_error(f"Verification failed: {exc}")
            raise typer.Exit(1)

    print_success(f"Registered {number}")
    print_info(f"Set signal.phone_number: {number} in config.yaml")
    print_info("Run: docker compose up cipher-bot")


# ---------------------------------------------------------------------------
# cipher version
# ---------------------------------------------------------------------------

@app.command()
def version() -> None:
    """Show CIPHER version."""
    from importlib.metadata import version as pkg_version
    try:
        ver = pkg_version("cipher-security")
    except Exception:
        ver = "dev"
    console.print(f"[cipher.primary]CIPHER[/] v{ver}")


# ---------------------------------------------------------------------------
# Default: bare `cipher "query"` without subcommand
# ---------------------------------------------------------------------------

def main() -> None:
    """CLI entrypoint — handles bare `cipher message words` by joining into a single query.

    Supports:
        cipher how do I detect Kerberoasting        → cipher query "how do I detect Kerberoasting"
        cipher "how do I detect Kerberoasting"      → cipher query "how do I detect Kerberoasting"
        cipher --backend ollama "query"              → cipher query --backend ollama "query"
        cipher -s what port does ssh use             → cipher query -s "what port does ssh use"
        cipher status                                → runs status subcommand
    """
    args = sys.argv[1:]
    known_commands = {"query", "ingest", "status", "doctor", "setup", "setup-signal", "dashboard", "web", "version", "plugin"}
    global_flags = {"--help", "-h", "--install-completion", "--show-completion"}

    if not args or args[0] in global_flags:
        sys.argv = [sys.argv[0]] + args
        app()
        return

    # Find the first non-flag argument
    first_positional = None
    for a in args:
        if not a.startswith("-"):
            first_positional = a
            break

    # If the first positional is a known command, pass through as-is
    if first_positional in known_commands:
        sys.argv = [sys.argv[0]] + args
        app()
        return

    # Otherwise, it's a bare query — collect all non-flag words into a single message
    flags = []
    words = []
    skip_next = False
    for i, a in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if a.startswith("-"):
            flags.append(a)
            # Check if this flag takes a value (--backend ollama)
            if a in ("--backend", "-b") and i + 1 < len(args):
                flags.append(args[i + 1])
                skip_next = True
        else:
            words.append(a)

    message = " ".join(words)
    sys.argv = [sys.argv[0], "query"] + flags + [message]
    app()


if __name__ == "__main__":
    main()
