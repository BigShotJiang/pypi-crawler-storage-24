# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER plugin system — discover, load, and manage community skills.

Plugin sources (checked in order):
    1. Built-in skills (skills/ in repo root or installed share dir)
    2. User plugins (~/.config/cipher/plugins/<name>/SKILL.md)
    3. Python entry points (group: ``cipher.skills``)

A valid plugin is a directory containing at minimum:
    - SKILL.md  — the skill content injected into the system prompt
    - plugin.yaml — metadata (name, version, author, modes, description)

plugin.yaml format:
    name: my-skill
    version: 0.1.0
    author: community-member
    description: One-line description
    modes:                    # Which CIPHER modes this skill activates for
      - RED                   # Adds to/replaces the RED mode skill
      - BLUE
    triggers:                 # Optional additional trigger keywords
      - my-keyword
      - another-keyword
    priority: 50              # 0-100, higher = loaded later (overrides lower)
                              # Built-in skills have priority 0

Usage:
    from gateway.plugins import PluginManager

    pm = PluginManager()
    pm.discover()
    skills = pm.get_skills_for_mode("RED")
    # Returns list of skill contents, built-in first, then plugins by priority
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Plugin metadata
# ---------------------------------------------------------------------------

@dataclass
class PluginInfo:
    """Metadata for a discovered plugin."""

    name: str
    version: str
    author: str
    description: str
    modes: list[str]
    triggers: list[str]
    priority: int
    path: Path                          # Directory containing SKILL.md
    source: str                         # "builtin" | "user" | "entrypoint"
    skill_content: str = ""             # Loaded SKILL.md content
    sub_skills: dict[str, str] = field(default_factory=dict)  # sub-path -> content

    @property
    def is_builtin(self) -> bool:
        return self.source == "builtin"


# ---------------------------------------------------------------------------
# Plugin discovery and management
# ---------------------------------------------------------------------------

_USER_PLUGIN_DIR = Path.home() / ".config" / "cipher" / "plugins"
_ENTRYPOINT_GROUP = "cipher.skills"


def _load_plugin_yaml(plugin_dir: Path) -> dict[str, Any] | None:
    """Load and validate plugin.yaml from a directory. Returns None on failure."""
    yaml_file = plugin_dir / "plugin.yaml"
    if not yaml_file.exists():
        return None

    try:
        with yaml_file.open("r") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, dict):
            logger.warning("Plugin %s: plugin.yaml is not a dict", plugin_dir.name)
            return None
        if "name" not in data:
            logger.warning("Plugin %s: plugin.yaml missing 'name'", plugin_dir.name)
            return None
        return data
    except Exception as exc:
        logger.warning("Plugin %s: failed to parse plugin.yaml: %s", plugin_dir.name, exc)
        return None


def _load_skill_content(plugin_dir: Path) -> str:
    """Load SKILL.md from a plugin directory."""
    skill_file = plugin_dir / "SKILL.md"
    if not skill_file.exists():
        return ""
    return skill_file.read_text(encoding="utf-8")


def _load_sub_skills(plugin_dir: Path) -> dict[str, str]:
    """Load sub-skill files (e.g. red-team/web/SKILL.md)."""
    sub_skills: dict[str, str] = {}
    for skill_file in plugin_dir.rglob("SKILL.md"):
        if skill_file == plugin_dir / "SKILL.md":
            continue  # Skip the primary SKILL.md
        rel = skill_file.relative_to(plugin_dir)
        sub_skills[str(rel)] = skill_file.read_text(encoding="utf-8")
    return sub_skills


def _plugin_from_dir(plugin_dir: Path, source: str) -> PluginInfo | None:
    """Create a PluginInfo from a plugin directory."""
    meta = _load_plugin_yaml(plugin_dir)
    if meta is None:
        # If no plugin.yaml but has SKILL.md, create minimal metadata
        if (plugin_dir / "SKILL.md").exists():
            meta = {"name": plugin_dir.name}
        else:
            return None

    content = _load_skill_content(plugin_dir)
    if not content:
        logger.warning("Plugin %s: no SKILL.md found", meta.get("name", plugin_dir.name))
        return None

    modes_raw = meta.get("modes", [])
    modes = [m.upper() for m in modes_raw] if modes_raw else []

    return PluginInfo(
        name=meta.get("name", plugin_dir.name),
        version=meta.get("version", "0.0.0"),
        author=meta.get("author", "unknown"),
        description=meta.get("description", ""),
        modes=modes,
        triggers=[t.lower() for t in meta.get("triggers", [])],
        priority=int(meta.get("priority", 50)),
        path=plugin_dir,
        source=source,
        skill_content=content,
        sub_skills=_load_sub_skills(plugin_dir),
    )


class PluginManager:
    """Discovers and manages CIPHER skill plugins.

    Call discover() to scan all plugin sources, then use get_skills_for_mode()
    to get skill content for prompt assembly.
    """

    def __init__(self, data_root: Path | None = None) -> None:
        self._data_root = data_root
        self._plugins: list[PluginInfo] = []
        self._discovered = False

    @property
    def plugins(self) -> list[PluginInfo]:
        """All discovered plugins, sorted by priority."""
        if not self._discovered:
            self.discover()
        return self._plugins

    def discover(self) -> list[PluginInfo]:
        """Scan all plugin sources and return discovered plugins.

        Sources checked:
        1. User plugins (~/.config/cipher/plugins/)
        2. Python entry points (cipher.skills group)

        Built-in skills are NOT loaded here — they're handled by
        prompt.py's existing load_skill(). Plugins extend or override
        built-in skills.

        Returns:
            List of PluginInfo objects, sorted by priority.
        """
        self._plugins.clear()

        # 1. User plugin directory
        self._scan_user_plugins()

        # 2. Python entry points
        self._scan_entrypoints()

        # Sort by priority (lower first)
        self._plugins.sort(key=lambda p: p.priority)
        self._discovered = True

        logger.info(
            "PluginManager: discovered %d plugin(s) from %d source(s)",
            len(self._plugins),
            len({p.source for p in self._plugins}),
        )
        return self._plugins

    def _scan_user_plugins(self) -> None:
        """Scan ~/.config/cipher/plugins/ for plugin directories."""
        if not _USER_PLUGIN_DIR.is_dir():
            return

        for entry in sorted(_USER_PLUGIN_DIR.iterdir()):
            if not entry.is_dir():
                continue
            plugin = _plugin_from_dir(entry, source="user")
            if plugin:
                self._plugins.append(plugin)
                logger.info("PluginManager: found user plugin %r at %s", plugin.name, entry)

    def _scan_entrypoints(self) -> None:
        """Scan Python entry points for installed skill packages."""
        try:
            from importlib.metadata import entry_points
            eps = entry_points(group=_ENTRYPOINT_GROUP)
        except Exception:
            return

        for ep in eps:
            try:
                # Entry point should resolve to a Path or callable returning Path
                target = ep.load()
                if callable(target):
                    plugin_dir = Path(target())
                elif isinstance(target, (str, Path)):
                    plugin_dir = Path(target)
                else:
                    logger.warning("PluginManager: entry point %r returned unexpected type", ep.name)
                    continue

                plugin = _plugin_from_dir(plugin_dir, source="entrypoint")
                if plugin:
                    self._plugins.append(plugin)
                    logger.info("PluginManager: found entrypoint plugin %r", plugin.name)
            except Exception as exc:
                logger.warning("PluginManager: failed to load entry point %r: %s", ep.name, exc)

    def get_skills_for_mode(self, mode: str) -> list[PluginInfo]:
        """Get all plugins that activate for a given mode.

        Args:
            mode: CIPHER mode name (e.g. "RED", "BLUE").

        Returns:
            List of PluginInfo objects for this mode, sorted by priority.
        """
        upper = mode.upper()
        return [p for p in self.plugins if upper in p.modes]

    def get_extra_triggers(self) -> dict[str, list[str]]:
        """Get additional trigger keywords from plugins.

        Returns:
            Dict mapping mode name -> list of additional trigger keywords.
        """
        triggers: dict[str, list[str]] = {}
        for plugin in self.plugins:
            for mode in plugin.modes:
                triggers.setdefault(mode, []).extend(plugin.triggers)
        return triggers

    def get_plugin_by_name(self, name: str) -> PluginInfo | None:
        """Find a plugin by name."""
        for plugin in self.plugins:
            if plugin.name == name:
                return plugin
        return None

    def list_plugins(self) -> list[dict[str, Any]]:
        """Return a serializable list of plugin metadata for CLI display."""
        return [
            {
                "name": p.name,
                "version": p.version,
                "author": p.author,
                "description": p.description,
                "modes": p.modes,
                "source": p.source,
                "path": str(p.path),
                "priority": p.priority,
            }
            for p in self.plugins
        ]


# ---------------------------------------------------------------------------
# Plugin installation helpers
# ---------------------------------------------------------------------------

def install_plugin(source: str, name: str | None = None) -> PluginInfo:
    """Install a plugin from a local directory or git URL.

    Args:
        source: Path to a local plugin directory, or a git URL.
        name: Override plugin name (defaults to directory name).

    Returns:
        PluginInfo for the installed plugin.

    Raises:
        FileNotFoundError: If source directory doesn't exist.
        ValueError: If the plugin is invalid (no SKILL.md).
    """
    import shutil

    source_path = Path(source).expanduser().resolve()

    if source_path.is_dir():
        # Local directory install — copy to user plugin dir
        plugin_name = name or source_path.name
        target = _USER_PLUGIN_DIR / plugin_name

        if target.exists():
            shutil.rmtree(target)

        _USER_PLUGIN_DIR.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source_path, target)

        plugin = _plugin_from_dir(target, source="user")
        if plugin is None:
            shutil.rmtree(target)
            raise ValueError(
                f"Invalid plugin: {source_path} must contain at minimum a SKILL.md file"
            )

        logger.info("Installed plugin %r to %s", plugin.name, target)
        return plugin

    # Git URL — clone to temp, then install
    if source.startswith(("http://", "https://", "git@")):
        import subprocess
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp) / "plugin"
            result = subprocess.run(
                ["git", "clone", "--depth=1", source, str(tmp_path)],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode != 0:
                raise ValueError(f"git clone failed: {result.stderr.strip()}")

            # Remove .git directory
            git_dir = tmp_path / ".git"
            if git_dir.exists():
                shutil.rmtree(git_dir)

            return install_plugin(str(tmp_path), name=name)

    raise FileNotFoundError(f"Plugin source not found: {source}")


def uninstall_plugin(name: str) -> bool:
    """Remove a user-installed plugin.

    Args:
        name: Plugin name.

    Returns:
        True if removed, False if not found.
    """
    import shutil

    target = _USER_PLUGIN_DIR / name
    if target.is_dir():
        shutil.rmtree(target)
        logger.info("Uninstalled plugin %r", name)
        return True
    return False
