# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER cyberpunk theme — colors, styles, and output helpers."""
from __future__ import annotations

from rich.console import Console
from rich.theme import Theme

# Cyberpunk color palette
COLORS = {
    "primary": "#00FF41",       # Matrix green
    "secondary": "#0D0D0D",     # Near-black background
    "accent": "#00E5CC",        # Cyan accent
    "success": "#00E5CC",       # Cyan
    "warning": "#FFB020",       # Amber
    "error": "#FF4D4D",         # Coral red
    "muted": "#5A6480",         # Dim gray
    # Mode-specific
    "mode.red": "#FF2D2D",      # Offensive
    "mode.blue": "#2D9BFF",     # Defensive
    "mode.purple": "#9B59B6",   # Detection engineering
    "mode.privacy": "#27AE60",  # Privacy
    "mode.recon": "#F39C12",    # OSINT
    "mode.incident": "#E74C3C", # Incident response
    "mode.architect": "#3498DB", # Architecture
}

MODE_COLORS: dict[str, str] = {
    "RED": COLORS["mode.red"],
    "BLUE": COLORS["mode.blue"],
    "PURPLE": COLORS["mode.purple"],
    "PRIVACY": COLORS["mode.privacy"],
    "RECON": COLORS["mode.recon"],
    "INCIDENT": COLORS["mode.incident"],
    "ARCHITECT": COLORS["mode.architect"],
}

cipher_theme = Theme({
    "cipher.primary": COLORS["primary"],
    "cipher.accent": COLORS["accent"],
    "cipher.success": COLORS["success"],
    "cipher.warning": COLORS["warning"],
    "cipher.error": COLORS["error"],
    "cipher.muted": COLORS["muted"],
    "cipher.mode.red": COLORS["mode.red"],
    "cipher.mode.blue": COLORS["mode.blue"],
    "cipher.mode.purple": COLORS["mode.purple"],
    "cipher.mode.privacy": COLORS["mode.privacy"],
    "cipher.mode.recon": COLORS["mode.recon"],
    "cipher.mode.incident": COLORS["mode.incident"],
    "cipher.mode.architect": COLORS["mode.architect"],
})

console = Console(theme=cipher_theme, highlight=False)
err_console = Console(theme=cipher_theme, stderr=True, highlight=False)

BANNER = r"""[cipher.primary]
   ██████╗██╗██████╗ ██╗  ██╗███████╗██████╗
  ██╔════╝██║██╔══██╗██║  ██║██╔════╝██╔══██╗
  ██║     ██║██████╔╝███████║█████╗  ██████╔╝
  ██║     ██║██╔═══╝ ██╔══██║██╔══╝  ██╔══██╗
  ╚██████╗██║██║     ██║  ██║███████╗██║  ██║
   ╚═════╝╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝[/]
  [cipher.muted]Security Engineering Assistant[/]
"""


def print_banner() -> None:
    """Print the CIPHER ASCII banner."""
    console.print(BANNER)


def print_success(msg: str) -> None:
    console.print(f"  [cipher.success]✓[/] {msg}")


def print_error(msg: str) -> None:
    console.print(f"  [cipher.error]✗[/] {msg}")


def print_warn(msg: str) -> None:
    console.print(f"  [cipher.warning]⚠[/] {msg}")


def print_info(msg: str) -> None:
    console.print(f"  [cipher.muted]●[/] {msg}")


def mode_style(mode: str) -> str:
    """Return the Rich style string for a CIPHER mode."""
    return f"cipher.mode.{mode.lower()}" if f"cipher.mode.{mode.lower()}" in cipher_theme.styles else "cipher.primary"
