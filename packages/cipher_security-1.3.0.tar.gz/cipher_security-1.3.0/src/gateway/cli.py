# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER gateway CLI entrypoint — cipher-gw.

Usage:
    cipher-gw "how to exploit SQLi"
    echo "what is zero trust" | cipher-gw
    cipher-gw --backend claude "design a zero trust network"
    cipher-gw --smart "analyze this CVE"
    cipher-gw setup-signal [--signal-api http://localhost:8080]
"""
from __future__ import annotations

import argparse
import sys

# ---------------------------------------------------------------------------
# Smart routing
# ---------------------------------------------------------------------------

COMPLEXITY_KEYWORDS = {
    "design", "architecture", "threat model", "analyze", "analyse",
    "compare", "explain", "model", "dpia", "risk assessment",
    "implement", "system", "strategy",
}


def _select_backend_smart(message: str) -> str:
    """Select backend based on query complexity heuristic.

    Routes to "claude" if the message is long (> 200 chars) or contains
    a complexity keyword. Routes to "ollama" otherwise.

    Args:
        message: The user query string.

    Returns:
        "claude" for complex queries, "ollama" for simple lookups.
    """
    if len(message) > 200:
        return "claude"
    lower = message.lower()
    if any(keyword in lower for keyword in COMPLEXITY_KEYWORDS):
        return "claude"
    return "ollama"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _strip_captcha_token(raw: str) -> str:
    """Strip the 'signalcaptcha://' scheme prefix if present.

    Signal's captcha page produces URLs like:
        signalcaptcha://signal-hcaptcha.xxx.registration.token
    The API only wants the token portion after the prefix.
    """
    prefix = "signalcaptcha://"
    if raw.startswith(prefix):
        return raw[len(prefix):]
    return raw


# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def _setup_signal(args: argparse.Namespace) -> None:
    """Interactive Signal registration flow using signal-cli-rest-api REST API."""
    import httpx  # deferred import — only needed for this subcommand

    base = args.signal_api.rstrip("/")

    print("CIPHER Signal Bot Registration")
    print("=" * 40)
    print("Prerequisites: signal-cli-rest-api must be running")
    print("  docker compose up -d signal-api")
    print()

    # Step 1: verify signal-cli-rest-api is reachable
    with httpx.Client(timeout=10) as client:
        try:
            about_url = f"{base}/v1/about"
            client.get(about_url).raise_for_status()
            print("signal-cli-rest-api is reachable.")
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            print(f"Error: Could not connect to signal-cli-rest-api at {base}")
            print(f"  {exc}")
            print("Make sure the container is running: docker compose up -d signal-api")
            sys.exit(1)
        except httpx.HTTPStatusError as exc:
            print(f"Error: signal-cli-rest-api returned an error: {exc}")
            sys.exit(1)

        # Step 2: prompt for number + captcha, then register
        number = input("Phone number (E.164 format, e.g. +15551234567): ").strip()
        print()
        print("Captcha steps:")
        print("  1. Open https://signalcaptchas.org/registration/generate.html")
        print("  2. Solve the captcha")
        print("  3. Right-click 'Open Signal' link -> Copy link address")
        print("  4. Paste the full URL below")
        raw_captcha = input("Captcha URL or token: ").strip()
        captcha_token = _strip_captcha_token(raw_captcha)

        try:
            register_url = f"{base}/v1/register/{number}"
            client.post(
                register_url,
                json={"captcha": captcha_token, "use_voice": False},
            ).raise_for_status()
        except httpx.HTTPStatusError as exc:
            print(f"Error: Registration request failed: {exc}")
            print("Hint: The captcha must be solved from the same IP as signal-cli-rest-api.")
            print("      If using Docker, the captcha page must be opened from the host running the container.")
            sys.exit(1)
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            print(f"Error: Lost connection during registration: {exc}")
            sys.exit(1)

        # Step 3: verify with the code received by call/SMS
        print("Verification call/SMS initiated. Enter the code when received.")
        code = input("Verification code: ").strip()

        try:
            verify_url = f"{base}/v1/register/{number}/verify/{code}"
            client.post(verify_url).raise_for_status()
        except httpx.HTTPStatusError as exc:
            print(f"Error: Verification failed: {exc}")
            sys.exit(1)
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            print(f"Error: Lost connection during verification: {exc}")
            sys.exit(1)

    print(f"Registration complete! Your bot number {number} is ready.")
    print("Next steps:")
    print(f"  1. Set signal.phone_number: {number} in config.yaml")
    print("  2. Set signal.whitelist: [your-personal-number] in config.yaml")
    print("  3. Run: docker compose up cipher-bot")


def _ingest(args: argparse.Namespace) -> None:
    """Ingest knowledge/ docs into the RAG vector store."""
    from gateway.retriever import Retriever

    print("CIPHER RAG Ingestion")
    print("=" * 40)

    retriever = Retriever()
    count = retriever.ingest()

    print(f"Indexed {count} chunks from knowledge/ into ChromaDB.")
    print("RAG retrieval is now active for cipher-gw queries.")


def _send_message(args: argparse.Namespace) -> None:
    """Send a single message through the Gateway."""
    message: str | None = getattr(args, "message", None)
    if message is None:
        if not sys.stdin.isatty():
            message = sys.stdin.read().strip()
        else:
            # parser.error not accessible here; print and exit manually
            print(
                "cipher-gw: error: No message provided. "
                "Pass a message argument or pipe via stdin.",
                file=sys.stderr,
            )
            sys.exit(2)

    if not message:
        print("cipher-gw: error: Message is empty.", file=sys.stderr)
        sys.exit(2)

    from gateway.gateway import Gateway

    # Smart routing: auto-select backend if --smart is set and no explicit --backend
    if getattr(args, "smart", False) and not getattr(args, "backend", None):
        backend = _select_backend_smart(message)
        print(f"[CIPHER] smart routing -> {backend}", file=sys.stderr)
        args.backend = backend

    gw = Gateway(backend_override=getattr(args, "backend", None))
    result = gw.send(message)
    print(result)


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="cipher-gw",
        description="CIPHER gateway — send a message or manage Signal registration",
    )

    subparsers = parser.add_subparsers(dest="subcommand")

    # ----- send subcommand (default) -----
    send_parser = subparsers.add_parser(
        "send",
        help="Send a message and get a CIPHER-mode response (default)",
    )
    send_parser.add_argument(
        "message",
        nargs="?",
        help="Message to send. Reads from stdin if omitted.",
    )
    send_parser.add_argument(
        "--backend",
        choices=["ollama", "claude", "litellm"],
        default=None,
        help="Override LLM backend (default: from config.yaml).",
    )
    send_parser.add_argument(
        "--smart",
        action="store_true",
        default=False,
        help="Auto-select backend based on query complexity (logs routing decision).",
    )
    send_parser.set_defaults(func=_send_message)

    # ----- ingest subcommand -----
    ingest_parser = subparsers.add_parser(
        "ingest",
        help="Ingest knowledge/ docs into the RAG vector store",
    )
    ingest_parser.set_defaults(func=_ingest)

    # ----- setup-signal subcommand -----
    signal_parser = subparsers.add_parser(
        "setup-signal",
        help="Interactively register a Signal phone number with signal-cli-rest-api",
    )
    signal_parser.add_argument(
        "--signal-api",
        default="http://localhost:8080",
        dest="signal_api",
        help="Base URL for signal-cli-rest-api (default: http://localhost:8080)",
    )
    signal_parser.set_defaults(func=_setup_signal)

    return parser, send_parser


def main() -> None:
    """CLI entrypoint for cipher-gw."""
    parser, send_parser = _build_parser()

    # Backward compatibility: detect whether first argument is a known subcommand.
    # If not, prepend "send" so the existing cipher-gw "message" usage keeps working.
    raw_args = sys.argv[1:]
    known_subcommands = {"send", "setup-signal", "ingest"}
    first = raw_args[0] if raw_args else None
    if first not in known_subcommands and first not in ("-h", "--help"):
        # Treat as a send invocation — prepend the "send" subcommand only if
        # the first arg does not start with "--" (which would be a flag for the
        # top-level parser). Flags like --backend are passed through.
        raw_args = ["send"] + raw_args

    args = parser.parse_args(raw_args)

    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
