# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""CIPHER gateway LLM client factory.

Returns a configured client for the active backend.

Backends:
    - ollama: Anthropic SDK via Ollama's compat layer (default, local)
    - claude: Anthropic SDK, direct API (cloud)
    - litellm: LiteLLM unified API — supports OpenAI, Gemini, llama.cpp,
               and 100+ other providers via a single interface.

Usage:
    client, model = make_client(cfg)
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=system_prompt,
        messages=[{"role": "user", "content": message}],
    )
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Generator

import anthropic
import httpx

from gateway.config import GatewayConfig


# ---------------------------------------------------------------------------
# LiteLLM adapter — presents an Anthropic-SDK-compatible interface so
# gateway.py doesn't need branching logic for every LLM call.
# ---------------------------------------------------------------------------

@dataclass
class _LiteLLMMessage:
    """Mimics anthropic.types.Message for a single text response."""

    content: list
    model: str
    role: str = "assistant"
    stop_reason: str | None = "end_turn"
    usage: dict = field(default_factory=dict)


@dataclass
class _LiteLLMTextBlock:
    """Mimics anthropic.types.TextBlock."""

    text: str
    type: str = "text"


class _LiteLLMStreamContext:
    """Context manager that mimics client.messages.stream().

    Yields tokens via .text_stream, matching the Anthropic streaming API
    so gateway.py's send_stream() works unchanged.
    """

    def __init__(self, response_iter: Generator) -> None:
        self._iter = response_iter

    def __enter__(self) -> "_LiteLLMStreamContext":
        return self

    def __exit__(self, *exc: Any) -> None:
        pass

    @property
    def text_stream(self) -> Generator[str, None, None]:
        yield from self._iter


class _LiteLLMMessages:
    """Mimics client.messages with .create() and .stream() methods.

    Translates between Anthropic's message format and LiteLLM's
    OpenAI-style completion format.
    """

    def __init__(self, model: str, api_key: str, timeout: float, api_base: str) -> None:
        self._model = model
        self._api_key = api_key
        self._timeout = timeout
        self._api_base = api_base

    @staticmethod
    def _to_openai_messages(
        system: str | None, messages: list[dict],
    ) -> list[dict]:
        """Convert Anthropic-style (system + messages) to OpenAI-style messages list."""
        result: list[dict] = []
        if system:
            result.append({"role": "system", "content": system})
        for msg in messages:
            result.append({"role": msg["role"], "content": msg["content"]})
        return result

    def _completion_kwargs(
        self,
        model: str,
        max_tokens: int,
        system: str | None,
        messages: list[dict],
        stream: bool = False,
    ) -> dict[str, Any]:
        """Build kwargs dict for litellm.completion()."""
        kwargs: dict[str, Any] = {
            "model": model,
            "messages": self._to_openai_messages(system, messages),
            "max_tokens": max_tokens,
            "stream": stream,
            "timeout": self._timeout,
        }
        if self._api_key:
            kwargs["api_key"] = self._api_key
        if self._api_base:
            kwargs["api_base"] = self._api_base
        return kwargs

    def create(
        self,
        *,
        model: str,
        max_tokens: int,
        system: str | None = None,
        messages: list[dict],
    ) -> _LiteLLMMessage:
        """Non-streaming completion — returns an Anthropic-compatible message object."""
        import litellm

        kwargs = self._completion_kwargs(model, max_tokens, system, messages)
        response = litellm.completion(**kwargs)

        text = response.choices[0].message.content or ""
        return _LiteLLMMessage(
            content=[_LiteLLMTextBlock(text=text)],
            model=model,
            usage={
                "input_tokens": getattr(response.usage, "prompt_tokens", 0),
                "output_tokens": getattr(response.usage, "completion_tokens", 0),
            },
        )

    def stream(
        self,
        *,
        model: str,
        max_tokens: int,
        system: str | None = None,
        messages: list[dict],
    ) -> _LiteLLMStreamContext:
        """Streaming completion — returns a context manager with .text_stream."""
        import litellm

        kwargs = self._completion_kwargs(model, max_tokens, system, messages, stream=True)
        response = litellm.completion(**kwargs)

        def _token_generator() -> Generator[str, None, None]:
            for chunk in response:
                delta = chunk.choices[0].delta
                if delta and delta.content:
                    yield delta.content

        return _LiteLLMStreamContext(_token_generator())


class _LiteLLMClient:
    """Adapter that presents an Anthropic-SDK-like interface backed by LiteLLM.

    gateway.py accesses client.messages.create() and client.messages.stream()
    — this class provides exactly those, translating to litellm.completion().
    """

    def __init__(self, model: str, api_key: str, timeout: float, api_base: str) -> None:
        self.messages = _LiteLLMMessages(model, api_key, timeout, api_base)
        # Expose timeout for test compatibility
        self.timeout = httpx.Timeout(timeout)


# ---------------------------------------------------------------------------
# Public factory
# ---------------------------------------------------------------------------

def make_client(cfg: GatewayConfig) -> tuple[Any, str]:
    """Build a client for the configured backend.

    Args:
        cfg: Validated gateway configuration. GatewayConfig.__post_init__
             ensures the backend and active model are set.

    Returns:
        (client, model_name) — the client is ready to call
        client.messages.create() or client.messages.stream().

    Backends:
        - ollama: Anthropic SDK pointing at localhost:11434.
                  api_key="ollama" (SDK requires a key; Ollama ignores it).
                  Timeout from GatewayConfig (300s default — local inference
                  can be slow).
        - claude: Standard Anthropic API with configured api_key.
                  Default base_url (api.anthropic.com).
        - litellm: LiteLLM unified API. Model string follows LiteLLM
                   conventions (e.g. "gpt-4o", "gemini/gemini-2.0-flash",
                   "ollama/llama3.1"). Requires `pip install cipher-security[multi]`.

    Raises:
        ImportError: If backend is "litellm" and the litellm package is not
                     installed.
    """
    if cfg.backend == "ollama":
        client = anthropic.Anthropic(
            base_url=cfg.ollama_base_url,
            api_key="ollama",  # Ollama ignores the key; SDK constructor requires it
            timeout=httpx.Timeout(float(cfg.ollama_timeout)),
        )
        return client, cfg.ollama_model

    if cfg.backend == "litellm":
        try:
            import litellm  # noqa: F401
        except ImportError:
            raise ImportError(
                "LiteLLM is required for the 'litellm' backend.\n"
                "Install with: pip install cipher-security[multi]"
            )

        # Suppress litellm's noisy default logging
        litellm.suppress_debug_info = True

        client = _LiteLLMClient(
            model=cfg.litellm_model,
            api_key=cfg.litellm_api_key,
            timeout=float(cfg.litellm_timeout),
            api_base=cfg.litellm_api_base,
        )
        return client, cfg.litellm_model

    # backend == "claude"
    client = anthropic.Anthropic(
        api_key=cfg.claude_api_key,
        timeout=httpx.Timeout(float(cfg.claude_timeout)),
    )
    return client, cfg.claude_model
