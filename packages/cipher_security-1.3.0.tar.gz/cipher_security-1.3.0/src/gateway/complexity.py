# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Smart routing complexity classifier for CIPHER gateway.

Evaluates multiple signals to determine query complexity and route
to the appropriate backend (Ollama for simple/moderate, Claude for
complex/expert).

Usage:
    from gateway.complexity import classify, route_backend

    level = classify("design a zero trust architecture for AWS")
    backend = route_backend(level)  # "claude"

    level = classify("what port does SSH use")
    backend = route_backend(level)  # "ollama"
"""
from __future__ import annotations

import re
from enum import IntEnum


class Complexity(IntEnum):
    """Query complexity levels, ordered by increasing difficulty."""

    SIMPLE = 1    # Factual lookups, single-concept questions → Ollama
    MODERATE = 2  # Multi-part but bounded questions → Ollama
    COMPLEX = 3   # Deep reasoning, threat models, architecture → Claude
    EXPERT = 4    # Cross-domain, multi-framework, advanced analysis → Claude


# ---------------------------------------------------------------------------
# Tunable weights — adjust these to change routing sensitivity
# ---------------------------------------------------------------------------

# Points thresholds for each complexity level
THRESHOLDS: dict[str, int] = {
    "moderate": 3,   # >= 3 points → MODERATE
    "complex": 6,    # >= 6 points → COMPLEX
    "expert": 10,    # >= 10 points → EXPERT
}

# Message length breakpoints (characters) and their point values
LENGTH_SCORES: list[tuple[int, int]] = [
    (500, 4),   # Very long queries are likely complex
    (300, 3),   # Long queries
    (150, 2),   # Medium queries
    (80, 1),    # Short but not trivial
]

# ---------------------------------------------------------------------------
# Keyword sets — each match adds the specified points
# ---------------------------------------------------------------------------

# Simple indicators (negative points — pull toward Ollama)
SIMPLE_KEYWORDS: dict[str, int] = {
    "what is": -2,
    "what are": -1,
    "what does": -2,
    "what port": -3,
    "which port": -3,
    "default port": -3,
    "how to install": -2,
    "how to start": -2,
    "how to run": -2,
    "syntax for": -2,
    "command for": -2,
    "define ": -2,
    "definition of": -2,
    "meaning of": -2,
    "example of": -1,
    "list of": -1,
    "difference between": -1,
}

# Domain complexity indicators (positive points — push toward Claude)
COMPLEX_KEYWORDS: dict[str, int] = {
    # Architecture & design
    "threat model": 4,
    "architecture": 3,
    "design": 2,
    "zero trust": 3,
    "blast radius": 3,
    "compensating control": 3,
    "defense in depth": 2,
    "security architecture": 4,
    "data flow diagram": 3,
    "trust boundary": 3,
    # Risk & compliance
    "dpia": 4,
    "risk assessment": 4,
    "risk analysis": 3,
    "compliance mapping": 4,
    "gap analysis": 3,
    "maturity assessment": 3,
    "audit finding": 3,
    "control mapping": 3,
    # Analysis & reasoning
    "analyze": 2,
    "analyse": 2,
    "evaluate": 2,
    "compare and contrast": 3,
    "trade-off": 2,
    "tradeoff": 2,
    "pros and cons": 2,
    "impact analysis": 3,
    "root cause": 3,
    # Offensive / red team
    "attack chain": 4,
    "attack path": 3,
    "kill chain": 3,
    "exploitation chain": 4,
    "lateral movement": 2,
    "privilege escalation": 2,
    "privesc": 2,
    "post-exploitation": 3,
    "evasion technique": 3,
    "bypass": 1,
    # Incident response
    "incident analysis": 4,
    "incident": 2,
    "forensic analysis": 4,
    "forensic": 2,
    "timeline reconstruction": 4,
    "indicator of compromise": 2,
    "ioc": 1,
    "beacon": 2,
    "cobalt strike": 3,
    "mimikatz": 2,
    "dcsync": 3,
    "triage": 2,
    "containment strategy": 3,
    "eradication plan": 3,
    "breach": 2,
    "malware analysis": 3,
    "reverse engineer": 3,
    # Detection engineering
    "detection logic": 3,
    "sigma rule": 2,
    "detection coverage": 3,
    "false positive": 2,
    "detection gap": 3,
    "correlation rule": 3,
    "hunting hypothesis": 3,
    # Multi-step / planning
    "strategy": 2,
    "roadmap": 3,
    "implementation plan": 3,
    "step by step": 1,
    "runbook": 2,
    "playbook": 2,
    "workflow": 1,
}

# Framework references — signal expert-level queries
FRAMEWORK_KEYWORDS: dict[str, int] = {
    "nist": 2,
    "nist 800-53": 3,
    "nist 800-171": 3,
    "nist csf": 3,
    "mitre att&ck": 3,
    "mitre attack": 3,
    "stride": 3,
    "pasta": 3,
    "dread": 3,
    "owasp": 2,
    "owasp top 10": 2,
    "cis controls": 2,
    "cis benchmark": 2,
    "iso 27001": 3,
    "iso 27002": 3,
    "soc 2": 2,
    "pci dss": 3,
    "hipaa": 2,
    "gdpr": 2,
    "ccpa": 2,
    "fedramp": 3,
    "cmmc": 3,
    "cve-": 1,
    "cwe-": 1,
}

# ---------------------------------------------------------------------------
# Structural patterns — regex-based signals
# ---------------------------------------------------------------------------

# Multi-part query indicators (each match adds points)
STRUCTURE_PATTERNS: list[tuple[str, int]] = [
    # Conjunctions joining distinct requests
    (r"\b(?:and also|and then|additionally|furthermore|moreover)\b", 2),
    # Numbered lists in the query
    (r"(?:^|\n)\s*\d+[\.\)]\s", 2),
    # Conditional logic
    (r"\bif\s+.+\bthen\b", 2),
    (r"\bwhat if\b", 2),
    (r"\bassuming\b", 1),
    (r"\bgiven that\b", 1),
    # Comparison requests
    (r"\bvs\.?\b", 1),
    (r"\bversus\b", 1),
    (r"\bcompare\b", 2),
    # Scope amplifiers
    (r"\b(?:comprehensive|exhaustive|thorough|detailed|in-depth|end-to-end)\b", 2),
    (r"\b(?:enterprise|organization-wide|company-wide|across all)\b", 2),
    # Multiple question marks (multiple questions)
    (r"\?.*\?", 2),
]

# Count of "and" conjunctions — many ands suggest multi-part queries
AND_CONJUNCTION_THRESHOLD: int = 3  # more than this many "and"s adds points
AND_CONJUNCTION_POINTS: int = 2


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------

def _score_length(message: str) -> int:
    """Score based on message length."""
    length = len(message)
    for threshold, points in LENGTH_SCORES:
        if length >= threshold:
            return points
    return 0


def _score_keywords(lower: str, keyword_set: dict[str, int]) -> int:
    """Score based on keyword presence. Returns sum of matched keyword points."""
    total = 0
    for keyword, points in keyword_set.items():
        if keyword in lower:
            total += points
    return total


def _score_structure(lower: str) -> int:
    """Score based on query structure patterns."""
    total = 0
    for pattern, points in STRUCTURE_PATTERNS:
        if re.search(pattern, lower):
            total += points

    # Count "and" conjunctions
    and_count = len(re.findall(r"\band\b", lower))
    if and_count > AND_CONJUNCTION_THRESHOLD:
        total += AND_CONJUNCTION_POINTS

    return total


def _score_framework_density(lower: str) -> int:
    """Bonus points when multiple frameworks are referenced."""
    matches = 0
    total_points = 0
    for keyword, points in FRAMEWORK_KEYWORDS.items():
        if keyword in lower:
            matches += 1
            total_points += points

    # Bonus for cross-framework queries (referencing 3+ frameworks)
    if matches >= 3:
        total_points += 3

    return total_points


def classify(message: str) -> Complexity:
    """Classify a query's complexity based on multiple heuristic signals.

    Args:
        message: The user's query string.

    Returns:
        Complexity level (SIMPLE, MODERATE, COMPLEX, or EXPERT).
    """
    lower = message.lower()

    score = 0
    score += _score_length(message)
    score += _score_keywords(lower, SIMPLE_KEYWORDS)
    score += _score_keywords(lower, COMPLEX_KEYWORDS)
    score += _score_structure(lower)
    score += _score_framework_density(lower)

    # Floor at 0 — negative scores are still SIMPLE
    score = max(score, 0)

    if score >= THRESHOLDS["expert"]:
        return Complexity.EXPERT
    if score >= THRESHOLDS["complex"]:
        return Complexity.COMPLEX
    if score >= THRESHOLDS["moderate"]:
        return Complexity.MODERATE
    return Complexity.SIMPLE


def route_backend(level: Complexity) -> str:
    """Map a complexity level to a backend name.

    Args:
        level: The classified complexity level.

    Returns:
        Backend string: "ollama" or "claude".

    Note:
        The "litellm" backend is user-configured, not auto-routed.
        Smart routing always chooses between ollama and claude.
        Users who want litellm set it explicitly via --backend or config.yaml.
    """
    if level >= Complexity.COMPLEX:
        return "claude"
    return "ollama"


def classify_and_route(message: str) -> tuple[Complexity, str]:
    """Classify a message and return both the complexity level and backend.

    Convenience function combining classify() and route_backend().

    Args:
        message: The user's query string.

    Returns:
        Tuple of (Complexity level, backend name string).
    """
    level = classify(message)
    backend = route_backend(level)
    return level, backend
