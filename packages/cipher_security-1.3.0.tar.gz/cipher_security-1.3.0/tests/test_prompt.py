"""Tests for src/gateway/prompt.py — system prompt assembly."""

import pytest
from pathlib import Path

from gateway.prompt import load_base_prompt, assemble_system_prompt


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def repo_root() -> Path:
    """Resolve the repo root — pyproject.toml is the marker."""
    here = Path(__file__).resolve()
    for parent in [here] + list(here.parents):
        if (parent / "pyproject.toml").exists():
            return parent
    pytest.fail("Could not locate repo root (no pyproject.toml found)")


@pytest.fixture(scope="module")
def base_prompt(repo_root: Path) -> str:
    return load_base_prompt(repo_root)


# ---------------------------------------------------------------------------
# load_base_prompt tests
# ---------------------------------------------------------------------------

class TestLoadBasePrompt:
    def test_contains_cipher_identity(self, base_prompt: str):
        """CIPHER identity must be preserved in the stripped prompt."""
        assert "CIPHER" in base_prompt

    def test_does_not_contain_keyword_table_row(self, base_prompt: str):
        """Keyword table rows must be stripped — LLM cannot see them."""
        # A canonical row from the trigger keywords table.
        assert "exploit, payload, reverse shell" not in base_prompt

    def test_does_not_contain_siem_table_row(self, base_prompt: str):
        """BLUE mode row should also be stripped."""
        assert "detection, SIEM, Sigma" not in base_prompt

    def test_does_not_contain_trigger_keywords_section_header(self, base_prompt: str):
        """The 'Trigger Keywords' section header itself should be stripped."""
        assert "#### Trigger Keywords" not in base_prompt

    def test_contains_finding_report_format(self, base_prompt: str):
        """Output format specs must remain — they define CIPHER's output standards."""
        assert "Finding Report" in base_prompt

    def test_contains_sigma_rule_format(self, base_prompt: str):
        """Sigma Rule format section must be present."""
        assert "Sigma Rule" in base_prompt

    def test_contains_operating_modes_section(self, base_prompt: str):
        """Operating Modes section must survive stripping."""
        assert "Operating Modes" in base_prompt

    def test_is_nonempty(self, base_prompt: str):
        assert len(base_prompt) > 100


# ---------------------------------------------------------------------------
# assemble_system_prompt — RED mode tests
# ---------------------------------------------------------------------------

class TestAssembleSystemPromptRed:
    @pytest.fixture(scope="class")
    def red_prompt(self, repo_root: Path) -> str:
        return assemble_system_prompt("RED", repo_root)

    def test_contains_red_team_skill_content(self, red_prompt: str):
        """Primary skill for RED must be injected."""
        assert "Red Team" in red_prompt or "red team" in red_prompt.lower()

    def test_contains_purple_team_background(self, red_prompt: str):
        """RED mode always gets PURPLE as background layer."""
        assert "Purple Team" in red_prompt or "purple team" in red_prompt.lower() or "Adversary Emulation" in red_prompt

    def test_contains_privacy_engineering_background(self, red_prompt: str):
        """ALL modes get PRIVACY engineering as background layer."""
        assert "Privacy Engineering" in red_prompt or "privacy engineering" in red_prompt.lower() or "GDPR" in red_prompt

    def test_is_nonempty(self, red_prompt: str):
        assert len(red_prompt) > 200


# ---------------------------------------------------------------------------
# assemble_system_prompt — BLUE mode tests
# ---------------------------------------------------------------------------

class TestAssembleSystemPromptBlue:
    @pytest.fixture(scope="class")
    def blue_prompt(self, repo_root: Path) -> str:
        return assemble_system_prompt("BLUE", repo_root)

    def test_contains_blue_team_skill_content(self, blue_prompt: str):
        """Primary skill for BLUE must be injected."""
        assert "Blue Team" in blue_prompt or "blue team" in blue_prompt.lower() or "Defensive Security" in blue_prompt

    def test_does_not_contain_purple_team_as_primary(self, blue_prompt: str):
        """BLUE mode does NOT get PURPLE as a background layer (only RED does)."""
        # Purple team content should NOT be injected for BLUE.
        assert "Purple Team" not in blue_prompt and "Adversary Emulation" not in blue_prompt

    def test_contains_privacy_engineering_background(self, blue_prompt: str):
        """ALL modes get PRIVACY engineering as background layer."""
        assert "Privacy Engineering" in blue_prompt or "privacy engineering" in blue_prompt.lower() or "GDPR" in blue_prompt

    def test_is_nonempty(self, blue_prompt: str):
        assert len(blue_prompt) > 200


# ---------------------------------------------------------------------------
# General assemble_system_prompt tests
# ---------------------------------------------------------------------------

class TestAssembleSystemPromptGeneral:
    def test_sections_joined_with_separator(self, repo_root: Path):
        """Sections must be separated by the standard divider."""
        prompt = assemble_system_prompt("ARCHITECT", repo_root)
        assert "---" in prompt

    def test_skill_paths_resolve_from_repo_root(self, repo_root: Path):
        """Skill files are resolved relative to repo root, not cwd."""
        # If skills resolve from repo root, RECON mode should find osint-recon/SKILL.md.
        prompt = assemble_system_prompt("RECON", repo_root)
        # RECON skill file should exist and have content.
        assert len(prompt) > 100

    def test_unknown_mode_does_not_crash(self, repo_root: Path):
        """Unknown mode returns a prompt without crashing — missing skill is skipped."""
        prompt = assemble_system_prompt("NONEXISTENT", repo_root)
        # Base prompt must still be present.
        assert "CIPHER" in prompt

    def test_red_prompt_contains_base_cipher_identity(self, repo_root: Path):
        """Base CLAUDE.md content (CIPHER identity) must be in assembled prompt."""
        prompt = assemble_system_prompt("RED", repo_root)
        assert "CIPHER" in prompt
