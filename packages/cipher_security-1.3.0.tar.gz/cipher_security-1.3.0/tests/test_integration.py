"""Integration smoke tests for CIPHER gateway.

These tests require a running LLM backend and a valid config.yaml.
Mark: pytest.mark.integration — skipped by default in CI.

Run with: uv run pytest tests/ -x -v  (no -m filter)
Skip with: uv run pytest tests/ -m "not integration"
"""
from __future__ import annotations

import subprocess

import pytest


@pytest.mark.integration
def test_cli_entrypoint_exists():
    """cipher-gw --help exits 0 and displays expected usage text."""
    result = subprocess.run(
        ["uv", "run", "cipher-gw", "--help"],
        capture_output=True,
        text=True,
        cwd="/home/void/Documents/cipher",
    )
    assert result.returncode == 0, f"cipher-gw --help failed:\n{result.stderr}"
    assert "CIPHER gateway" in result.stdout


@pytest.mark.integration
def test_gateway_send_returns_mode_header():
    """Gateway.send returns a [MODE: X] prefixed response or [ERROR] if backend offline.

    This test exercises the full pipeline against a real LLM backend.
    A [ERROR] response is acceptable — it confirms the gateway wiring is
    correct even when the backend is unavailable.
    """
    from gateway.gateway import Gateway

    gw = Gateway()
    response = gw.send("what is zero trust architecture")
    assert response.startswith("[MODE:") or response.startswith("[ERROR]"), (
        f"Unexpected response format: {response[:80]}"
    )
