# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Mode routing tests — validate every mode detects correctly from keywords.

Tests keyword detection, explicit prefix override, disambiguation,
and default-to-ARCHITECT behavior.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from gateway.mode import detect_mode, parse_keyword_table


@pytest.fixture(scope="module")
def keyword_table():
    """Load the real keyword table from CLAUDE.md."""
    claude_md = Path(__file__).resolve().parent.parent / "CLAUDE.md"
    text = claude_md.read_text(encoding="utf-8")
    table = parse_keyword_table(text)
    assert len(table) > 0, "Keyword table is empty — CLAUDE.md may have changed format"
    return table


# ---------------------------------------------------------------------------
# Mode detection from keywords
# ---------------------------------------------------------------------------

class TestModeKeywordDetection:
    """Each mode should be detected from its trigger keywords."""

    @pytest.mark.parametrize("query,expected_mode", [
        # RED triggers
        ("how to exploit a SQL injection vulnerability", "RED"),
        ("generate a reverse shell payload for Linux", "RED"),
        ("privesc techniques for Windows domain", "RED"),
        ("set up a C2 channel with Sliver", "RED"),
        ("red team engagement lateral movement", "RED"),
        # BLUE triggers
        ("write a Sigma detection rule for process injection", "BLUE"),
        ("SIEM correlation for brute force attacks", "BLUE"),
        ("EDR deployment best practices", "BLUE"),
        ("threat hunting for credential dumping", "BLUE"),
        ("CIS hardening benchmark for Ubuntu", "BLUE"),
        # PURPLE triggers (avoid overlapping BLUE keywords like "detection" alone)
        ("ATT&CK mapping coverage for emulation", "PURPLE"),
        ("adversary emulation plan for gap analysis", "PURPLE"),
        # PRIVACY triggers (avoid "breach"=INCIDENT, "design"=ARCHITECT)
        ("GDPR Article 35 DPIA assessment", "PRIVACY"),
        ("HIPAA compliance requirements", "PRIVACY"),
        ("anonymization of personal data VeraCrypt", "PRIVACY"),
        # RECON triggers
        ("OSINT investigation on target domain", "RECON"),
        ("passive recon subdomain enumeration", "RECON"),
        # INCIDENT triggers
        ("ransomware incident response triage", "INCIDENT"),
        ("forensics evidence collection chain of custody", "INCIDENT"),
        ("IOC analysis for active breach", "INCIDENT"),
        # ARCHITECT triggers
        ("design a zero trust network architecture", "ARCHITECT"),
        ("threat model for microservices application", "ARCHITECT"),
        ("blast radius analysis for this change", "ARCHITECT"),
    ])
    def test_keyword_routes_to_correct_mode(self, query, expected_mode, keyword_table):
        mode, needs_clarification = detect_mode(query, keyword_table)
        assert not needs_clarification, f"Unexpected disambiguation for: {query}"
        assert mode == expected_mode, f"Expected {expected_mode}, got {mode} for: {query}"


# ---------------------------------------------------------------------------
# Explicit prefix override
# ---------------------------------------------------------------------------

class TestExplicitPrefix:
    """[MODE: X] prefix should override keyword detection."""

    @pytest.mark.parametrize("mode", ["RED", "BLUE", "PURPLE", "PRIVACY", "RECON", "INCIDENT", "ARCHITECT"])
    def test_explicit_prefix_overrides(self, mode, keyword_table):
        query = f"[MODE: {mode}] what are the security implications"
        detected, needs_clarification = detect_mode(query, keyword_table)
        assert not needs_clarification
        assert detected == mode


# ---------------------------------------------------------------------------
# Default to ARCHITECT
# ---------------------------------------------------------------------------

class TestDefaultMode:
    """Queries with no matching keywords default to ARCHITECT."""

    @pytest.mark.parametrize("query", [
        "what is the best programming language",
        "how does TLS work",
        "explain quantum computing",
        "what are microservices",
    ])
    def test_no_keywords_defaults_to_architect(self, query, keyword_table):
        mode, needs_clarification = detect_mode(query, keyword_table)
        assert not needs_clarification
        assert mode == "ARCHITECT"


# ---------------------------------------------------------------------------
# Disambiguation
# ---------------------------------------------------------------------------

class TestDisambiguation:
    """Queries matching multiple modes should trigger disambiguation."""

    def test_overlapping_keywords_trigger_clarification(self, keyword_table):
        # "exploit" = RED, "detection" = BLUE
        mode, needs_clarification = detect_mode(
            "exploit detection and lateral movement hunting", keyword_table
        )
        assert needs_clarification, "Expected disambiguation for RED+BLUE overlap"
