"""Unit tests for CipherCommand — bot handler.

All external dependencies (Gateway, signalbot Context) are mocked.
Tests do NOT import signalbot — they use MockContext from conftest.
"""
from __future__ import annotations

import asyncio
from unittest.mock import MagicMock


from bot.session import SessionManager


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_gateway(response: str = "[MODE: RED] canned response") -> MagicMock:
    """Return a mock Gateway whose send() returns a fixed string."""
    gw = MagicMock()
    gw.send.return_value = response
    return gw


def make_cmd(
    gateway=None,
    session=None,
    whitelist: set[str] | None = None,
):
    """Build a CipherCommand with sensible defaults."""
    from bot.bot import CipherCommand

    if gateway is None:
        gateway = make_gateway()
    if session is None:
        session = SessionManager()
    if whitelist is None:
        whitelist = {"+15551234567"}
    return CipherCommand(gateway=gateway, session=session, whitelist=whitelist)


def run(coro):
    """Run a coroutine synchronously in tests."""
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Whitelist filtering
# ---------------------------------------------------------------------------

class TestWhitelistFilter:
    def test_non_whitelisted_sender_is_silently_dropped(self, make_ctx):
        """Non-whitelisted sender: gateway NOT called, nothing sent."""
        gw = make_gateway()
        cmd = make_cmd(gateway=gw, whitelist={"+10000000000"})
        ctx = make_ctx(source="+19999999999", text="hello")
        run(cmd.handle(ctx))
        gw.send.assert_not_called()
        assert ctx.sent == []
        assert ctx.reactions == []

    def test_whitelisted_sender_proceeds(self, make_ctx):
        """Whitelisted sender: gateway called and response sent."""
        gw = make_gateway()
        cmd = make_cmd(gateway=gw, whitelist={"+15551234567"})
        ctx = make_ctx(source="+15551234567", text="hello")
        run(cmd.handle(ctx))
        gw.send.assert_called_once()
        assert len(ctx.sent) == 1


# ---------------------------------------------------------------------------
# /reset command
# ---------------------------------------------------------------------------

class TestResetCommand:
    def test_reset_clears_session(self, make_ctx):
        """/reset calls session.reset for the sender."""
        session = SessionManager()
        session.update("+15551234567", "old query", "old response")
        assert session.get("+15551234567") != []

        cmd = make_cmd(session=session)
        ctx = make_ctx(source="+15551234567", text="/reset")
        run(cmd.handle(ctx))

        assert session.get("+15551234567") == []

    def test_reset_sends_confirmation(self, make_ctx):
        """/reset sends 'Session cleared.' to user."""
        cmd = make_cmd()
        ctx = make_ctx(source="+15551234567", text="/reset")
        run(cmd.handle(ctx))
        assert any("Session cleared" in s for s in ctx.sent)

    def test_reset_does_not_call_gateway(self, make_ctx):
        """/reset must NOT call gateway.send."""
        gw = make_gateway()
        cmd = make_cmd(gateway=gw)
        ctx = make_ctx(source="+15551234567", text="/reset")
        run(cmd.handle(ctx))
        gw.send.assert_not_called()


# ---------------------------------------------------------------------------
# Brain emoji reaction
# ---------------------------------------------------------------------------

class TestEmojiReaction:
    def test_brain_emoji_sent_on_normal_message(self, make_ctx):
        """Brain emoji 🧠 sent for whitelisted sender on normal message."""
        cmd = make_cmd()
        ctx = make_ctx(source="+15551234567", text="what is SQL injection?")
        run(cmd.handle(ctx))
        assert "🧠" in ctx.reactions

    def test_no_emoji_on_whitelist_drop(self, make_ctx):
        """Non-whitelisted sender: no emoji reaction."""
        cmd = make_cmd(whitelist={"+10000000000"})
        ctx = make_ctx(source="+19999999999", text="hello")
        run(cmd.handle(ctx))
        assert ctx.reactions == []

    def test_no_emoji_on_reset(self, make_ctx):
        """/reset must NOT send emoji reaction."""
        cmd = make_cmd()
        ctx = make_ctx(source="+15551234567", text="/reset")
        run(cmd.handle(ctx))
        assert "🧠" not in ctx.reactions


# ---------------------------------------------------------------------------
# Prefix mapping
# ---------------------------------------------------------------------------

class TestPrefixMapping:
    def test_red_prefix_passed_to_gateway(self, make_ctx):
        """'RED: query' is mapped to '[MODE: RED] query' before gateway call."""
        gw = make_gateway()
        cmd = make_cmd(gateway=gw)
        ctx = make_ctx(source="+15551234567", text="RED: scan ports")
        run(cmd.handle(ctx))
        call_args = gw.send.call_args
        mapped_text = call_args[0][0] if call_args[0] else call_args[1].get("message", call_args[0][0])
        assert mapped_text == "[MODE: RED] scan ports"

    def test_no_prefix_passthrough(self, make_ctx):
        """Message without recognized prefix is passed through unchanged."""
        gw = make_gateway()
        cmd = make_cmd(gateway=gw)
        ctx = make_ctx(source="+15551234567", text="just a plain question")
        run(cmd.handle(ctx))
        call_args = gw.send.call_args
        first_arg = call_args[0][0]
        assert first_arg == "just a plain question"


# ---------------------------------------------------------------------------
# Markdown stripping
# ---------------------------------------------------------------------------

class TestMarkdownStripping:
    def test_markdown_stripped_from_response(self, make_ctx):
        """strip_markdown applied to gateway response before sending to user."""
        gw = make_gateway(response="[MODE: RED] **bold** and *italic*")
        cmd = make_cmd(gateway=gw)
        ctx = make_ctx(source="+15551234567", text="hello")
        run(cmd.handle(ctx))
        assert ctx.sent
        # bold/italic markers should be stripped
        sent = ctx.sent[-1]
        assert "**" not in sent
        assert "*bold*" not in sent


# ---------------------------------------------------------------------------
# Session history
# ---------------------------------------------------------------------------

class TestSessionHistory:
    def test_session_history_passed_to_gateway(self, make_ctx):
        """Existing session history is passed as history= kwarg to gateway.send."""
        session = SessionManager()
        session.update("+15551234567", "prev query", "prev response")
        gw = make_gateway()
        cmd = make_cmd(gateway=gw, session=session)
        ctx = make_ctx(source="+15551234567", text="follow-up question")
        run(cmd.handle(ctx))
        call_kwargs = gw.send.call_args[1]
        assert "history" in call_kwargs
        history = call_kwargs["history"]
        assert any(m["content"] == "prev query" for m in history)

    def test_session_updated_after_gateway_call(self, make_ctx):
        """session.update() called with mapped text and response."""
        session = SessionManager()
        cmd = make_cmd(session=session)
        ctx = make_ctx(source="+15551234567", text="hello there")
        run(cmd.handle(ctx))
        history = session.get("+15551234567")
        assert len(history) == 2
        assert history[0]["role"] == "user"
        assert history[1]["role"] == "assistant"


# ---------------------------------------------------------------------------
# run_in_executor (non-blocking gateway call)
# ---------------------------------------------------------------------------

class TestRunInExecutor:
    def test_gateway_send_called_via_executor(self, make_ctx):
        """gateway.send() is called (result arrives), verifying executor path works."""
        gw = make_gateway(response="[MODE: BLUE] defender response")
        cmd = make_cmd(gateway=gw)
        ctx = make_ctx(source="+15551234567", text="detect lateral movement")
        run(cmd.handle(ctx))
        # If executor path is broken, send would not be called
        gw.send.assert_called_once()
        assert len(ctx.sent) == 1
        assert "defender response" in ctx.sent[0]


# ---------------------------------------------------------------------------
# Disambiguation flow
# ---------------------------------------------------------------------------

class TestDisambiguationFlow:
    def test_multiple_modes_triggers_clarification(self, make_ctx):
        """Gateway returning 'Multiple modes detected' triggers clarification state."""
        gw = make_gateway(response="Multiple modes detected — are you approaching this offensively or defensively?")
        cmd = make_cmd(gateway=gw)
        ctx = make_ctx(source="+15551234567", text="exploit detection")
        run(cmd.handle(ctx))
        # The disambiguation response is sent as-is
        assert ctx.sent
        assert "Multiple modes detected" in ctx.sent[0]

    def test_offensive_clarification_routes_to_red(self, make_ctx):
        """Replying 'offensive' after disambiguation routes stored query with RED prefix."""
        # First message triggers disambiguation
        gw = make_gateway(response="Multiple modes detected — are you approaching this offensively or defensively?")
        cmd = make_cmd(gateway=gw)
        ctx1 = make_ctx(source="+15551234567", text="exploit detection")
        run(cmd.handle(ctx1))

        # Now reply with 'offensive'
        gw2 = make_gateway(response="[MODE: RED] red team response")
        cmd._gateway = gw2
        ctx2 = make_ctx(source="+15551234567", text="offensive")
        run(cmd.handle(ctx2))

        # Gateway called with RED-prefixed version of original query
        call_args = gw2.send.call_args[0][0]
        assert call_args.startswith("[MODE: RED]")

    def test_defensive_clarification_routes_to_blue(self, make_ctx):
        """Replying 'defensive' after disambiguation routes stored query with BLUE prefix."""
        gw = make_gateway(response="Multiple modes detected — are you approaching this offensively or defensively?")
        cmd = make_cmd(gateway=gw)
        ctx1 = make_ctx(source="+15551234567", text="exploit detection")
        run(cmd.handle(ctx1))

        gw2 = make_gateway(response="[MODE: BLUE] blue team response")
        cmd._gateway = gw2
        ctx2 = make_ctx(source="+15551234567", text="defensive")
        run(cmd.handle(ctx2))

        call_args = gw2.send.call_args[0][0]
        assert call_args.startswith("[MODE: BLUE]")

    def test_invalid_clarification_reply_prompts_again(self, make_ctx):
        """An unrecognized clarification reply keeps state and asks again."""
        gw = make_gateway(response="Multiple modes detected — are you approaching this offensively or defensively?")
        cmd = make_cmd(gateway=gw)
        ctx1 = make_ctx(source="+15551234567", text="exploit detection")
        run(cmd.handle(ctx1))

        gw2 = make_gateway()
        cmd._gateway = gw2
        ctx2 = make_ctx(source="+15551234567", text="neither")
        run(cmd.handle(ctx2))

        # Gateway NOT called for the routing — still in clarification state
        gw2.send.assert_not_called()
        assert any("offensive" in s.lower() or "defensive" in s.lower() for s in ctx2.sent)

    def test_clarification_state_cleared_after_routing(self, make_ctx):
        """After successful clarification routing, state is cleared for next message."""
        gw = make_gateway(response="Multiple modes detected — are you approaching this offensively or defensively?")
        cmd = make_cmd(gateway=gw)
        ctx1 = make_ctx(source="+15551234567", text="exploit detection")
        run(cmd.handle(ctx1))

        gw2 = make_gateway(response="[MODE: RED] response")
        cmd._gateway = gw2
        ctx2 = make_ctx(source="+15551234567", text="offensive")
        run(cmd.handle(ctx2))

        # Third message should be processed normally (no clarification state left)
        gw3 = make_gateway(response="[MODE: BLUE] normal response")
        cmd._gateway = gw3
        ctx3 = make_ctx(source="+15551234567", text="normal query")
        run(cmd.handle(ctx3))
        gw3.send.assert_called_once()
