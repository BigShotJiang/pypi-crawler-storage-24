"""Tests for Gateway orchestrator class.

All tests use mocked LLM client — no real backend required.
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import anthropic

from gateway.config import GatewayConfig


# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

def _make_config(backend: str = "ollama") -> GatewayConfig:
    return GatewayConfig(
        backend=backend,
        ollama_base_url="http://127.0.0.1:11434",
        ollama_model="llama3.1:8b",
        ollama_timeout=300,
        claude_api_key="sk-ant-test",
        claude_model="claude-sonnet-4-5",
        claude_timeout=60,
    )


def _fake_response(text: str = "[MODE: RED] Test response") -> MagicMock:
    """Build a minimal anthropic Messages response mock."""
    content_block = MagicMock()
    content_block.text = text
    response = MagicMock()
    response.content = [content_block]
    return response


# ---------------------------------------------------------------------------
# Gateway initialisation
# ---------------------------------------------------------------------------

class TestGatewayInit:
    def test_gateway_init_loads_config(self):
        """Gateway() should call load_config() to initialise GatewayConfig."""
        cfg = _make_config()
        with (
            patch("gateway.gateway.load_config", return_value=cfg) as mock_cfg,
            patch("gateway.gateway.make_client", return_value=(MagicMock(), "llama3.1:8b")),
            patch("gateway.gateway.parse_keyword_table", return_value={}),
            patch("pathlib.Path.read_text", return_value=""),
        ):
            from gateway.gateway import Gateway
            Gateway()
            mock_cfg.assert_called_once()

    def test_gateway_init_creates_client(self):
        """Gateway() should call make_client() to build the LLM client."""
        cfg = _make_config()
        with (
            patch("gateway.gateway.load_config", return_value=cfg),
            patch("gateway.gateway.make_client", return_value=(MagicMock(), "llama3.1:8b")) as mock_mc,
            patch("gateway.gateway.parse_keyword_table", return_value={}),
            patch("pathlib.Path.read_text", return_value=""),
        ):
            from gateway.gateway import Gateway
            Gateway()
            mock_mc.assert_called_once_with(cfg)

    def test_gateway_backend_override_replaces_backend(self):
        """backend_override replaces config.backend before make_client is called."""
        cfg = _make_config("ollama")
        client_mock = MagicMock()
        with (
            patch("gateway.gateway.load_config", return_value=cfg),
            patch("gateway.gateway.make_client", return_value=(client_mock, "model")) as mock_mc,
            patch("gateway.gateway.parse_keyword_table", return_value={}),
            patch("pathlib.Path.read_text", return_value=""),
        ):
            from gateway.gateway import Gateway
            Gateway(backend_override="claude")
            called_cfg = mock_mc.call_args[0][0]
            assert called_cfg.backend == "claude"


# ---------------------------------------------------------------------------
# Gateway.send — mode routing
# ---------------------------------------------------------------------------

class TestGatewaySendModeRouting:
    """Tests for explicit-prefix routing, keyword routing, defaults."""

    def _gateway_with_mock(self, response_text: str = "[MODE: RED] ok"):
        """Return a Gateway with fully mocked internals."""
        cfg = _make_config()
        client_mock = MagicMock()
        client_mock.messages.create.return_value = _fake_response(response_text)

        keyword_table = {
            "RED": ["exploit", "payload"],
            "BLUE": ["detection", "siem"],
            "ARCHITECT": ["design", "architecture"],
        }

        with (
            patch("gateway.gateway.load_config", return_value=cfg),
            patch("gateway.gateway.make_client", return_value=(client_mock, "llama3.1:8b")),
            patch("pathlib.Path.read_text", return_value=""),
            patch("gateway.gateway.parse_keyword_table", return_value=keyword_table),
            patch("gateway.gateway.assemble_system_prompt", return_value="assembled prompt"),
        ):
            from gateway.gateway import Gateway
            gw = Gateway()
            return gw, client_mock

    def test_send_explicit_prefix_routes_to_red(self):
        gw, client_mock = self._gateway_with_mock("[MODE: RED] response text")
        gw.send("[MODE: RED] how to exploit a buffer overflow")
        assert client_mock.messages.create.called

    def test_send_keyword_autodetect_red(self):
        gw, client_mock = self._gateway_with_mock("[MODE: RED] response")
        gw.send("how to exploit a login form")
        assert client_mock.messages.create.called

    def test_send_no_keywords_defaults_architect(self):
        gw, client_mock = self._gateway_with_mock("[MODE: ARCHITECT] response")
        result = gw.send("what is zero trust")
        assert client_mock.messages.create.called
        assert "[MODE:" in result

    def test_send_response_includes_mode_header(self):
        gw, client_mock = self._gateway_with_mock("[MODE: RED] detailed answer")
        result = gw.send("[MODE: RED] exploit SQLi")
        assert "[MODE:" in result

    def test_send_prepends_mode_header_if_missing(self):
        """If LLM response lacks [MODE: X] header, Gateway should prepend it."""
        cfg = _make_config()
        client_mock = MagicMock()
        # Response text without [MODE: X] header
        client_mock.messages.create.return_value = _fake_response("This is the answer")
        keyword_table = {"RED": ["exploit"]}

        with (
            patch("gateway.gateway.load_config", return_value=cfg),
            patch("gateway.gateway.make_client", return_value=(client_mock, "llama3.1:8b")),
            patch("pathlib.Path.read_text", return_value=""),
            patch("gateway.gateway.parse_keyword_table", return_value=keyword_table),
            patch("gateway.gateway.assemble_system_prompt", return_value="prompt"),
        ):
            from gateway.gateway import Gateway
            gw = Gateway()
            result = gw.send("[MODE: RED] query")
            assert result.startswith("[MODE:")


# ---------------------------------------------------------------------------
# Gateway.send — overlap / disambiguation
# ---------------------------------------------------------------------------

class TestGatewaySendDisambiguation:
    def test_send_overlap_returns_disambiguation_no_llm_call(self):
        """Overlapping keywords → disambiguation string, no LLM call."""
        cfg = _make_config()
        client_mock = MagicMock()
        keyword_table = {
            "RED": ["exploit"],
            "BLUE": ["detection"],
        }

        with (
            patch("gateway.gateway.load_config", return_value=cfg),
            patch("gateway.gateway.make_client", return_value=(client_mock, "model")),
            patch("pathlib.Path.read_text", return_value=""),
            patch("gateway.gateway.parse_keyword_table", return_value=keyword_table),
            patch("gateway.gateway.assemble_system_prompt", return_value="prompt"),
            # Patch detect_mode to simulate overlap
            patch("gateway.gateway.detect_mode", return_value=("BLUE,RED", True)),
        ):
            from gateway.gateway import Gateway
            gw = Gateway()
            result = gw.send("exploit detection overlap")
            client_mock.messages.create.assert_not_called()
            assert "Multiple modes detected" in result
            assert "offensively or defensively" in result


# ---------------------------------------------------------------------------
# Gateway.send — history parameter
# ---------------------------------------------------------------------------

class TestGatewaySendHistory:
    def test_send_with_history_passes_messages_list(self):
        """history parameter is prepended before the new user message."""
        cfg = _make_config()
        client_mock = MagicMock()
        client_mock.messages.create.return_value = _fake_response("[MODE: ARCHITECT] ok")
        keyword_table = {}

        with (
            patch("gateway.gateway.load_config", return_value=cfg),
            patch("gateway.gateway.make_client", return_value=(client_mock, "model")),
            patch("pathlib.Path.read_text", return_value=""),
            patch("gateway.gateway.parse_keyword_table", return_value=keyword_table),
            patch("gateway.gateway.assemble_system_prompt", return_value="prompt"),
        ):
            from gateway.gateway import Gateway
            gw = Gateway()
            history = [
                {"role": "user", "content": "previous question"},
                {"role": "assistant", "content": "previous answer"},
            ]
            gw.send("follow-up question", history=history)
            call_kwargs = client_mock.messages.create.call_args
            messages_arg = call_kwargs[1]["messages"] if call_kwargs[1] else call_kwargs[0][2]
            # Should have history (2 items) + new message (1 item) = 3
            assert len(messages_arg) == 3
            assert messages_arg[0] == history[0]
            assert messages_arg[1] == history[1]
            assert messages_arg[2]["role"] == "user"


# ---------------------------------------------------------------------------
# Gateway.send — error handling
# ---------------------------------------------------------------------------

class TestGatewaySendErrorHandling:
    def _gateway(self):
        cfg = _make_config()
        client_mock = MagicMock()
        keyword_table = {}

        patches = [
            patch("gateway.gateway.load_config", return_value=cfg),
            patch("gateway.gateway.make_client", return_value=(client_mock, "model")),
            patch("pathlib.Path.read_text", return_value=""),
            patch("gateway.gateway.parse_keyword_table", return_value=keyword_table),
            patch("gateway.gateway.assemble_system_prompt", return_value="prompt"),
        ]
        for p in patches:
            p.start()

        from gateway.gateway import Gateway
        gw = Gateway()
        # stop patches — we only needed them during __init__
        for p in patches:
            p.stop()

        return gw, client_mock

    def test_send_handles_api_timeout_error(self):
        gw, client_mock = self._gateway()
        client_mock.messages.create.side_effect = anthropic.APITimeoutError(request=MagicMock())
        result = gw.send("test message")
        assert "[ERROR]" in result
        assert "timed out" in result.lower() or "backend" in result.lower()

    def test_send_handles_api_connection_error(self):
        gw, client_mock = self._gateway()
        request_mock = MagicMock()
        client_mock.messages.create.side_effect = anthropic.APIConnectionError(request=request_mock)
        result = gw.send("test message")
        assert "[ERROR]" in result
        assert "backend" in result.lower() or "reach" in result.lower()

    def test_send_handles_api_status_error(self):
        gw, client_mock = self._gateway()
        response_mock = MagicMock()
        response_mock.status_code = 500
        response_mock.headers = {}
        response_mock.text = "Internal Server Error"
        client_mock.messages.create.side_effect = anthropic.APIStatusError(
            message="Internal error",
            response=response_mock,
            body={"error": {"message": "Internal error"}},
        )
        result = gw.send("test message")
        assert "[ERROR]" in result
