"""Unit tests for src/bot/format.py — prefix mapping and markdown stripping."""

from bot.format import map_prefix, strip_markdown


# ---------------------------------------------------------------------------
# map_prefix tests
# ---------------------------------------------------------------------------

class TestMapPrefix:
    def test_red_lowercase(self):
        """'red: query' maps correctly case-insensitively."""
        result = map_prefix("red: how to exploit SQLi")
        assert result == "[MODE: RED] how to exploit SQLi"

    def test_red_uppercase(self):
        result = map_prefix("RED: how to exploit SQLi")
        assert result == "[MODE: RED] how to exploit SQLi"

    def test_blue(self):
        result = map_prefix("blue: what is SIEM")
        assert result == "[MODE: BLUE] what is SIEM"

    def test_purple(self):
        result = map_prefix("PURPLE: detection gaps")
        assert result == "[MODE: PURPLE] detection gaps"

    def test_privacy(self):
        result = map_prefix("PRIVACY: GDPR data flows")
        assert result == "[MODE: PRIVACY] GDPR data flows"

    def test_recon(self):
        result = map_prefix("RECON: subdomain enum")
        assert result == "[MODE: RECON] subdomain enum"

    def test_incident(self):
        result = map_prefix("INCIDENT: active breach triage")
        assert result == "[MODE: INCIDENT] active breach triage"

    def test_architect(self):
        result = map_prefix("ARCHITECT: zero trust design")
        assert result == "[MODE: ARCHITECT] zero trust design"

    def test_no_prefix_passthrough(self):
        """Text with no recognized prefix passes through unchanged."""
        result = map_prefix("tell me about zero trust")
        assert result == "tell me about zero trust"

    def test_no_space_after_colon(self):
        """Colon immediately followed by text (no space) still maps."""
        result = map_prefix("RED:query")
        assert result == "[MODE: RED] query"

    def test_mixed_case_mode_uppercased(self):
        """Mode is always uppercased in output regardless of input case."""
        result = map_prefix("Blue: firewall rules")
        assert result == "[MODE: BLUE] firewall rules"

    def test_no_prefix_empty_string(self):
        result = map_prefix("")
        assert result == ""

    def test_prefix_only_no_query(self):
        """Prefix with nothing after colon produces '[MODE: X] '."""
        result = map_prefix("RED: ")
        assert result == "[MODE: RED] "

    def test_unrelated_word_before_colon_no_match(self):
        """Words that aren't mode keywords don't trigger mapping."""
        result = map_prefix("hello: world")
        assert result == "hello: world"

    def test_all_seven_modes_recognized(self):
        """Verify all 7 modes are handled."""
        modes = ["RED", "BLUE", "PURPLE", "PRIVACY", "RECON", "INCIDENT", "ARCHITECT"]
        for mode in modes:
            result = map_prefix(f"{mode}: test query")
            assert result == f"[MODE: {mode}] test query", f"Mode {mode} not recognized"


# ---------------------------------------------------------------------------
# strip_markdown tests
# ---------------------------------------------------------------------------

class TestStripMarkdown:
    def test_heading_h2(self):
        result = strip_markdown("## Heading")
        assert result == "Heading"

    def test_heading_h1(self):
        result = strip_markdown("# Title")
        assert result == "Title"

    def test_heading_h3(self):
        result = strip_markdown("### Sub")
        assert result == "Sub"

    def test_bold_double_asterisk(self):
        result = strip_markdown("**bold** text")
        assert result == "bold text"

    def test_italic_single_asterisk(self):
        result = strip_markdown("*italic* text")
        assert result == "italic text"

    def test_fenced_code_block(self):
        result = strip_markdown("```python\ncode\n```")
        assert result == "code"

    def test_inline_code(self):
        result = strip_markdown("`inline`")
        assert result == "inline"

    def test_bullet_asterisk(self):
        result = strip_markdown("* item\n* item2")
        assert result == "• item\n• item2"

    def test_bullet_dash(self):
        result = strip_markdown("- item\n- item2")
        assert result == "• item\n• item2"

    def test_link(self):
        result = strip_markdown("[link](http://x.com)")
        assert result == "link"

    def test_plain_text_preserved(self):
        text = "Just plain text here."
        assert strip_markdown(text) == text

    def test_newlines_preserved(self):
        text = "Line one\nLine two\nLine three"
        result = strip_markdown(text)
        assert "Line one" in result
        assert "Line two" in result
        assert "Line three" in result

    def test_bold_before_italic(self):
        """Bold (**) stripped before italic (*) to avoid collision."""
        result = strip_markdown("**bold** and *italic*")
        assert result == "bold and italic"

    def test_fenced_code_block_language_tag(self):
        """Code block with language tag — language tag stripped, content preserved."""
        result = strip_markdown("```bash\necho hello\n```")
        assert result == "echo hello"

    def test_mixed_markdown(self):
        """Mixed markdown elements all stripped."""
        text = "## Header\n**bold** and `code` and [link](http://x.com)\n* bullet"
        result = strip_markdown(text)
        assert "##" not in result
        assert "**" not in result
        assert "`" not in result
        assert "[link]" not in result
        assert "* " not in result
        assert "Header" in result
        assert "bold" in result
        assert "code" in result
        assert "link" in result
        assert "bullet" in result
