"""Unit tests for the RAG retriever module.

Tests chunking, ingestion, querying, and context formatting.
Uses a temporary ChromaDB directory — no persistent state affected.
"""
from __future__ import annotations

import textwrap

import pytest


# ---------------------------------------------------------------------------
# Markdown chunking tests (pure function, no ChromaDB needed)
# ---------------------------------------------------------------------------

class TestSplitMarkdown:
    """Tests for _split_markdown — the markdown-aware chunker."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from gateway.retriever import _split_markdown
        self.split = _split_markdown

    def test_empty_text_returns_empty(self):
        assert self.split("", "test.md") == []

    def test_single_section_under_limit(self):
        text = "## Heading\n\nSome content here."
        chunks = self.split(text, "test.md", chunk_size=500)
        assert len(chunks) == 1
        assert chunks[0]["source"] == "test.md"
        assert chunks[0]["section"] == "Heading"
        assert "Some content here" in chunks[0]["text"]

    def test_multiple_sections_split_on_headers(self):
        text = "## Section 1\n\nContent 1.\n\n## Section 2\n\nContent 2."
        chunks = self.split(text, "test.md", chunk_size=500)
        assert len(chunks) == 2
        assert chunks[0]["section"] == "Section 1"
        assert chunks[1]["section"] == "Section 2"

    def test_h3_headers_also_split(self):
        text = "## Parent\n\nIntro.\n\n### Child 1\n\nBody 1.\n\n### Child 2\n\nBody 2."
        chunks = self.split(text, "test.md", chunk_size=500)
        assert len(chunks) >= 3

    def test_long_section_splits_at_paragraphs(self):
        paragraphs = "\n\n".join([f"Paragraph {i} with enough text." for i in range(20)])
        text = f"## Big Section\n\n{paragraphs}"
        chunks = self.split(text, "test.md", chunk_size=200, chunk_overlap=50)
        assert len(chunks) > 1
        # All chunks should reference the same section
        for c in chunks:
            assert c["section"] == "Big Section"

    def test_chunk_overlap_preserves_context(self):
        para1 = "A" * 100
        para2 = "B" * 100
        para3 = "C" * 100
        text = f"## Test\n\n{para1}\n\n{para2}\n\n{para3}"
        chunks = self.split(text, "test.md", chunk_size=180, chunk_overlap=50)
        # With overlap, later chunks should contain tail of previous chunk
        assert len(chunks) >= 2

    def test_source_filename_preserved(self):
        text = "## Test\n\nContent."
        chunks = self.split(text, "active-directory-deep.md")
        assert all(c["source"] == "active-directory-deep.md" for c in chunks)

    def test_no_header_uses_filename_as_section(self):
        text = "Just some text without any markdown headers."
        chunks = self.split(text, "my-file.md")
        assert len(chunks) == 1
        # Section derived from filename
        assert chunks[0]["section"] == "My File"

    def test_code_blocks_not_split_incorrectly(self):
        text = textwrap.dedent("""\
        ## Commands

        ```bash
        # This is a command
        echo "hello"
        ```

        Some text after.
        """)
        chunks = self.split(text, "test.md", chunk_size=500)
        # Code block should stay with its section
        assert any("echo" in c["text"] for c in chunks)


# ---------------------------------------------------------------------------
# Retriever integration tests (uses temporary ChromaDB)
# ---------------------------------------------------------------------------

class TestRetriever:
    """Tests for the Retriever class with a real (temporary) ChromaDB instance."""

    @pytest.fixture()
    def retriever(self, tmp_path):
        from gateway.retriever import Retriever
        return Retriever(db_dir=tmp_path / "chromadb")

    @pytest.fixture()
    def knowledge_dir(self, tmp_path):
        """Create a temporary knowledge directory with test files."""
        kb = tmp_path / "knowledge"
        kb.mkdir()

        (kb / "test-topic-a.md").write_text(textwrap.dedent("""\
        # Topic A — Deep Reference

        ## 1. Kerberos Attacks

        ### 1.1 AS-REP Roasting

        Accounts with preauth disabled allow TGT requests without credentials.

        ```bash
        GetNPUsers.py -request -format hashcat -dc-ip $DC 'DOMAIN/'
        ```

        ## 2. NTLM Attacks

        NTLM relay attacks forward authentication to other services.
        """))

        (kb / "test-topic-b.md").write_text(textwrap.dedent("""\
        # Topic B — Privacy

        ## GDPR Breach Notification

        Under GDPR Article 33, data controllers must notify the supervisory
        authority within 72 hours of becoming aware of a personal data breach.

        ## CCPA Consumer Rights

        California residents have the right to know what personal information
        is collected and the right to request deletion.
        """))

        return kb

    def test_empty_collection_count_zero(self, retriever):
        assert retriever.count == 0

    def test_query_empty_collection_returns_empty(self, retriever):
        results = retriever.query("anything")
        assert results == []

    def test_ingest_populates_collection(self, retriever, knowledge_dir):
        count = retriever.ingest(knowledge_dir=knowledge_dir)
        assert count > 0
        assert retriever.count == count

    def test_ingest_reindex_clears_old_data(self, retriever, knowledge_dir):
        count1 = retriever.ingest(knowledge_dir=knowledge_dir)
        count2 = retriever.ingest(knowledge_dir=knowledge_dir)
        assert count1 == count2  # Same data, same count
        assert retriever.count == count2

    def test_query_returns_relevant_chunks(self, retriever, knowledge_dir):
        retriever.ingest(knowledge_dir=knowledge_dir)
        results = retriever.query("Kerberos AS-REP roasting", top_k=3)
        assert len(results) > 0
        # Top result should be from topic A (Kerberos)
        assert results[0]["source"] == "test-topic-a.md"

    def test_query_privacy_returns_gdpr(self, retriever, knowledge_dir):
        retriever.ingest(knowledge_dir=knowledge_dir)
        results = retriever.query("GDPR breach notification requirements", top_k=3)
        assert len(results) > 0
        assert any(r["source"] == "test-topic-b.md" for r in results)

    def test_query_returns_distance_scores(self, retriever, knowledge_dir):
        retriever.ingest(knowledge_dir=knowledge_dir)
        results = retriever.query("NTLM relay", top_k=2)
        assert all("distance" in r for r in results)
        assert all(isinstance(r["distance"], float) for r in results)

    def test_query_top_k_limits_results(self, retriever, knowledge_dir):
        retriever.ingest(knowledge_dir=knowledge_dir)
        results = retriever.query("security", top_k=2)
        assert len(results) <= 2

    def test_ingest_nonexistent_dir_raises(self, retriever, tmp_path):
        with pytest.raises(FileNotFoundError):
            retriever.ingest(knowledge_dir=tmp_path / "nonexistent")

    def test_ingest_empty_dir_raises(self, retriever, tmp_path):
        empty = tmp_path / "empty"
        empty.mkdir()
        with pytest.raises(FileNotFoundError):
            retriever.ingest(knowledge_dir=empty)


# ---------------------------------------------------------------------------
# Context formatting tests
# ---------------------------------------------------------------------------

class TestFormatContext:
    """Tests for Retriever.format_context static method."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from gateway.retriever import Retriever
        self.format_context = Retriever.format_context

    def test_empty_chunks_returns_empty_string(self):
        assert self.format_context([]) == ""

    def test_single_chunk_formatted(self):
        chunks = [{"document": "Some content", "source": "test.md", "section": "Section 1"}]
        result = self.format_context(chunks)
        assert "Retrieved Knowledge Context" in result
        assert "test.md" in result
        assert "Some content" in result

    def test_multiple_chunks_all_included(self):
        chunks = [
            {"document": f"Content {i}", "source": f"file{i}.md", "section": f"Sec {i}"}
            for i in range(3)
        ]
        result = self.format_context(chunks)
        for i in range(3):
            assert f"Content {i}" in result
            assert f"file{i}.md" in result

    def test_token_budget_truncates(self):
        chunks = [
            {"document": "X" * 5000, "source": "big.md", "section": "Big"},
            {"document": "Y" * 5000, "source": "big2.md", "section": "Big2"},
        ]
        result = self.format_context(chunks, max_tokens_estimate=1000)
        # Should truncate — not include both full chunks
        assert len(result) < 10000

    def test_source_and_section_in_header(self):
        chunks = [{"document": "data", "source": "active-directory-deep.md", "section": "Kerberos"}]
        result = self.format_context(chunks)
        assert "active-directory-deep.md" in result
        assert "Kerberos" in result
