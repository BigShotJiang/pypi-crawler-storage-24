"""Unit tests for cipher-gw setup-signal subcommand.

Tests mock httpx and input() to exercise the interactive registration flow
without making real network calls.
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run_setup_signal(argv: list[str] | None = None, inputs: list[str] | None = None):
    """Run setup-signal subcommand with mocked input() and sys.argv.

    Returns (exit_code, stdout_lines) where exit_code is 0 on success or
    the value passed to SystemExit.
    """
    import io

    argv = argv or ["cipher-gw", "setup-signal"]
    inputs = inputs or []

    with (
        patch("sys.argv", argv),
        patch("builtins.input", side_effect=inputs),
        patch("sys.stdout", new_callable=io.StringIO) as mock_stdout,
        patch("sys.stderr", new_callable=io.StringIO),
    ):
        from gateway import cli

        try:
            cli.main()
            exit_code = 0
        except SystemExit as exc:
            exit_code = exc.code if exc.code is not None else 0
        return exit_code, mock_stdout.getvalue()


def _make_response(status_code: int = 200, json_body: dict | None = None) -> MagicMock:
    """Build a minimal httpx.Response mock."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.text = str(json_body or {})
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            message=f"HTTP {status_code}",
            request=MagicMock(),
            response=resp,
        )
    return resp


# ---------------------------------------------------------------------------
# Captcha URL stripping
# ---------------------------------------------------------------------------

class TestCaptchaStripping:
    """Captcha token extraction from full URL or bare token."""

    def test_strips_signalcaptcha_prefix(self):
        """Full signalcaptcha:// URL is stripped to bare token."""
        from gateway.cli import _strip_captcha_token

        token = _strip_captcha_token("signalcaptcha://token123")
        assert token == "token123"

    def test_bare_token_unchanged(self):
        """Bare token without prefix is returned as-is."""
        from gateway.cli import _strip_captcha_token

        token = _strip_captcha_token("token123")
        assert token == "token123"

    def test_strips_prefix_with_complex_token(self):
        """Realistic captcha URL with complex token."""
        from gateway.cli import _strip_captcha_token

        raw = "signalcaptcha://signal-hcaptcha.5faad45f-2d8c-4f6a-9e1b-3a2c7d8e9f0a.registration.abc123def456"
        token = _strip_captcha_token(raw)
        assert token == "signal-hcaptcha.5faad45f-2d8c-4f6a-9e1b-3a2c7d8e9f0a.registration.abc123def456"


# ---------------------------------------------------------------------------
# Successful full flow
# ---------------------------------------------------------------------------

class TestSetupSignalSuccess:
    """Happy-path: about -> register -> verify all succeed."""

    def test_success_prints_completion_message(self):
        """/v1/about OK, /v1/register OK, /v1/verify OK -> prints 'Registration complete'."""
        about_resp = _make_response(200)
        register_resp = _make_response(200)
        verify_resp = _make_response(200)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = [register_resp, verify_resp]

            exit_code, output = _run_setup_signal(
                inputs=["+15551234567", "token123", "123456"],
            )

        assert exit_code == 0
        assert "Registration complete" in output

    def test_success_shows_phone_number_in_completion(self):
        """Completion message includes the registered phone number."""
        about_resp = _make_response(200)
        register_resp = _make_response(200)
        verify_resp = _make_response(200)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = [register_resp, verify_resp]

            exit_code, output = _run_setup_signal(
                inputs=["+15551234567", "token123", "123456"],
            )

        assert "+15551234567" in output

    def test_strips_captcha_prefix_before_posting(self):
        """signalcaptcha:// prefix is stripped before sending to API."""
        about_resp = _make_response(200)
        register_resp = _make_response(200)
        verify_resp = _make_response(200)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = [register_resp, verify_resp]

            _run_setup_signal(
                inputs=["+15551234567", "signalcaptcha://token123", "123456"],
            )

        register_call = mock_client.post.call_args_list[0]
        json_body = register_call.kwargs.get("json") or register_call[1].get("json", {})
        assert json_body["captcha"] == "token123"

    def test_uses_sms_verification_by_default(self):
        """Registration POST includes use_voice=False for SMS verification."""
        about_resp = _make_response(200)
        register_resp = _make_response(200)
        verify_resp = _make_response(200)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = [register_resp, verify_resp]

            _run_setup_signal(
                inputs=["+15551234567", "token123", "123456"],
            )

        register_call = mock_client.post.call_args_list[0]
        json_body = register_call.kwargs.get("json") or register_call[1].get("json", {})
        assert json_body["use_voice"] is False

    def test_custom_signal_api_url(self):
        """--signal-api flag overrides default base URL."""
        about_resp = _make_response(200)
        register_resp = _make_response(200)
        verify_resp = _make_response(200)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = [register_resp, verify_resp]

            _run_setup_signal(
                argv=["cipher-gw", "setup-signal", "--signal-api", "http://signal-api:8080"],
                inputs=["+15551234567", "token123", "123456"],
            )

        get_call_url = mock_client.get.call_args[0][0] if mock_client.get.call_args[0] else mock_client.get.call_args[1].get("url", "")
        # URL should use custom base
        assert "signal-api:8080" in get_call_url


# ---------------------------------------------------------------------------
# Step 1 failure: /v1/about unreachable
# ---------------------------------------------------------------------------

class TestAboutFailure:
    """When signal-cli-rest-api is unreachable, exit(1) with helpful message."""

    def test_about_connection_error_exits_nonzero(self):
        """Connection error on GET /v1/about -> exit(1)."""
        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.side_effect = httpx.ConnectError("Connection refused")

            exit_code, output = _run_setup_signal(inputs=[])

        assert exit_code != 0

    def test_about_connection_error_prints_error(self):
        """Connection error on GET /v1/about -> prints error message."""
        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.side_effect = httpx.ConnectError("Connection refused")

            import io

            with (
                patch("sys.argv", ["cipher-gw", "setup-signal"]),
                patch("builtins.input", side_effect=[]),
                patch("sys.stdout", new_callable=io.StringIO) as mock_stdout,
                patch("sys.stderr", new_callable=io.StringIO) as mock_stderr,
            ):
                from gateway import cli

                try:
                    cli.main()
                except SystemExit:
                    pass
                combined = mock_stdout.getvalue() + mock_stderr.getvalue()

        assert "signal-cli-rest-api" in combined.lower() or "error" in combined.lower() or "unreachable" in combined.lower() or "connection" in combined.lower()

    def test_about_http_error_exits_nonzero(self):
        """HTTP 500 from /v1/about -> exit(1)."""
        about_resp = _make_response(500)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.get.side_effect = httpx.HTTPStatusError(
                "500", request=MagicMock(), response=about_resp
            )

            exit_code, output = _run_setup_signal(inputs=[])

        assert exit_code != 0


# ---------------------------------------------------------------------------
# Step 2 failure: /v1/register returns error
# ---------------------------------------------------------------------------

class TestRegisterFailure:
    """When registration POST fails, exit(1) with captcha IP hint."""

    def test_register_422_exits_nonzero(self):
        """422 Unprocessable Entity -> exit(1)."""
        about_resp = _make_response(200)
        register_resp = _make_response(422)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = httpx.HTTPStatusError(
                "422", request=MagicMock(), response=register_resp
            )

            exit_code, output = _run_setup_signal(
                inputs=["+15551234567", "bad-token", ""],
            )

        assert exit_code != 0

    def test_register_422_prints_ip_hint(self):
        """422 error message includes hint about same-IP requirement."""
        about_resp = _make_response(200)
        register_resp = _make_response(422)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = httpx.HTTPStatusError(
                "422", request=MagicMock(), response=register_resp
            )

            import io

            with (
                patch("sys.argv", ["cipher-gw", "setup-signal"]),
                patch("builtins.input", side_effect=["+15551234567", "bad-token", ""]),
                patch("sys.stdout", new_callable=io.StringIO) as mock_stdout,
                patch("sys.stderr", new_callable=io.StringIO) as mock_stderr,
            ):
                from gateway import cli

                try:
                    cli.main()
                except SystemExit:
                    pass
                combined = mock_stdout.getvalue() + mock_stderr.getvalue()

        # Should mention IP or same IP requirement
        assert "ip" in combined.lower() or "same" in combined.lower() or "captcha" in combined.lower()


# ---------------------------------------------------------------------------
# Step 3 failure: /v1/register/verify returns error
# ---------------------------------------------------------------------------

class TestVerifyFailure:
    """When verification POST fails, exit(1) with error message."""

    def test_verify_400_exits_nonzero(self):
        """400 from verify endpoint -> exit(1)."""
        about_resp = _make_response(200)
        register_resp = _make_response(200)
        verify_resp = _make_response(400)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = [
                register_resp,
                httpx.HTTPStatusError("400", request=MagicMock(), response=verify_resp),
            ]

            exit_code, output = _run_setup_signal(
                inputs=["+15551234567", "token123", "wrong-code"],
            )

        assert exit_code != 0

    def test_verify_400_prints_error(self):
        """400 from verify endpoint -> prints error message."""
        about_resp = _make_response(200)
        register_resp = _make_response(200)
        verify_resp = _make_response(400)

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client_cls.return_value = mock_client
            mock_client.get.return_value = about_resp
            mock_client.post.side_effect = [
                register_resp,
                httpx.HTTPStatusError("400", request=MagicMock(), response=verify_resp),
            ]

            import io

            with (
                patch("sys.argv", ["cipher-gw", "setup-signal"]),
                patch("builtins.input", side_effect=["+15551234567", "token123", "wrong-code"]),
                patch("sys.stdout", new_callable=io.StringIO) as mock_stdout,
                patch("sys.stderr", new_callable=io.StringIO) as mock_stderr,
            ):
                from gateway import cli

                try:
                    cli.main()
                except SystemExit:
                    pass
                combined = mock_stdout.getvalue() + mock_stderr.getvalue()

        assert "error" in combined.lower() or "verification" in combined.lower() or "failed" in combined.lower()


# ---------------------------------------------------------------------------
# Backward compatibility: cipher-gw "message" still works
# ---------------------------------------------------------------------------

class TestBackwardCompatibility:
    """Bare 'cipher-gw message' without subcommand still routes to send."""

    def test_bare_message_calls_gateway_send(self):
        """cipher-gw 'hello' without subcommand calls Gateway.send()."""
        with patch("gateway.gateway.Gateway") as mock_gw_cls:
            mock_gw = MagicMock()
            mock_gw_cls.return_value = mock_gw
            mock_gw.send.return_value = "response"

            import io

            with (
                patch("sys.argv", ["cipher-gw", "hello world"]),
                patch("sys.stdout", new_callable=io.StringIO),
            ):
                from gateway import cli

                try:
                    cli.main()
                except SystemExit:
                    pass

            mock_gw.send.assert_called_once_with("hello world")
