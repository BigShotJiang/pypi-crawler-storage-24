"""Tests for gateway.client — make_client LLM factory function."""
from __future__ import annotations



# ---------------------------------------------------------------------------
# Ollama backend
# ---------------------------------------------------------------------------

def test_make_client_ollama_returns_tuple(ollama_gateway_config):
    """make_client returns (client, model_name) tuple."""
    from gateway.client import make_client

    result = make_client(ollama_gateway_config)
    assert isinstance(result, tuple)
    assert len(result) == 2


def test_make_client_ollama_base_url_contains_11434(ollama_gateway_config):
    """Ollama client base_url contains port 11434."""
    from gateway.client import make_client
    import anthropic

    client, model = make_client(ollama_gateway_config)
    assert isinstance(client, anthropic.Anthropic)
    # base_url may be a URL object or string — convert to string for check
    base_url_str = str(client.base_url)
    assert "11434" in base_url_str


def test_make_client_ollama_timeout_is_300(ollama_gateway_config):
    """Ollama client timeout is 300s (from GatewayConfig)."""
    from gateway.client import make_client

    client, _ = make_client(ollama_gateway_config)
    # httpx.Timeout stores the value as .read, .connect, .pool attributes
    # When constructed with a single float, all are set to that value
    assert client.timeout.read == 300.0


def test_make_client_ollama_api_key_is_ollama(ollama_gateway_config):
    """Ollama client api_key is 'ollama' (Ollama ignores it; SDK requires it)."""
    from gateway.client import make_client

    client, _ = make_client(ollama_gateway_config)
    assert client.api_key == "ollama"


def test_make_client_ollama_returns_correct_model(ollama_gateway_config):
    """Ollama client returns ollama_model as second element."""
    from gateway.client import make_client

    _, model = make_client(ollama_gateway_config)
    assert model == ollama_gateway_config.ollama_model
    assert model == "llama3.1:8b"


# ---------------------------------------------------------------------------
# Claude backend
# ---------------------------------------------------------------------------

def test_make_client_claude_returns_tuple(claude_gateway_config):
    """make_client returns (client, model_name) tuple for Claude backend."""
    from gateway.client import make_client

    result = make_client(claude_gateway_config)
    assert isinstance(result, tuple)
    assert len(result) == 2


def test_make_client_claude_timeout_is_60(claude_gateway_config):
    """Claude client timeout is 60s (from GatewayConfig)."""
    from gateway.client import make_client

    client, _ = make_client(claude_gateway_config)
    assert client.timeout.read == 60.0


def test_make_client_claude_uses_configured_api_key(claude_gateway_config):
    """Claude client uses the configured API key."""
    from gateway.client import make_client

    client, _ = make_client(claude_gateway_config)
    assert client.api_key == claude_gateway_config.claude_api_key
    assert client.api_key == "sk-ant-test-key"


def test_make_client_claude_returns_correct_model(claude_gateway_config):
    """Claude client returns claude_model as second element."""
    from gateway.client import make_client

    _, model = make_client(claude_gateway_config)
    assert model == claude_gateway_config.claude_model
    assert model == "claude-sonnet-4-5"


def test_make_client_claude_uses_default_base_url(claude_gateway_config):
    """Claude client uses default Anthropic base URL (not Ollama's)."""
    from gateway.client import make_client

    client, _ = make_client(claude_gateway_config)
    base_url_str = str(client.base_url)
    assert "anthropic.com" in base_url_str
    assert "11434" not in base_url_str


# ---------------------------------------------------------------------------
# Timeout values come from GatewayConfig, not hardcoded
# ---------------------------------------------------------------------------

def test_make_client_ollama_timeout_from_config(ollama_gateway_config):
    """Ollama timeout comes from GatewayConfig.ollama_timeout, not hardcoded 300."""
    from gateway.client import make_client
    from gateway.config import GatewayConfig

    # Modify the config to use a different timeout
    custom_cfg = GatewayConfig(
        backend="ollama",
        ollama_base_url=ollama_gateway_config.ollama_base_url,
        ollama_model=ollama_gateway_config.ollama_model,
        ollama_timeout=120,  # custom timeout
        claude_api_key=ollama_gateway_config.claude_api_key,
        claude_model=ollama_gateway_config.claude_model,
        claude_timeout=ollama_gateway_config.claude_timeout,
    )
    client, _ = make_client(custom_cfg)
    assert client.timeout.read == 120.0


def test_make_client_claude_timeout_from_config(claude_gateway_config):
    """Claude timeout comes from GatewayConfig.claude_timeout, not hardcoded 60."""
    from gateway.client import make_client
    from gateway.config import GatewayConfig

    custom_cfg = GatewayConfig(
        backend="claude",
        ollama_base_url=claude_gateway_config.ollama_base_url,
        ollama_model=claude_gateway_config.ollama_model,
        ollama_timeout=claude_gateway_config.ollama_timeout,
        claude_api_key=claude_gateway_config.claude_api_key,
        claude_model=claude_gateway_config.claude_model,
        claude_timeout=45,  # custom timeout
    )
    client, _ = make_client(custom_cfg)
    assert client.timeout.read == 45.0


# ---------------------------------------------------------------------------
# LiteLLM backend
# ---------------------------------------------------------------------------

def test_make_client_litellm_returns_tuple(litellm_gateway_config):
    """make_client returns (client, model_name) tuple for litellm backend."""
    from gateway.client import make_client

    result = make_client(litellm_gateway_config)
    assert isinstance(result, tuple)
    assert len(result) == 2


def test_make_client_litellm_returns_correct_model(litellm_gateway_config):
    """LiteLLM client returns litellm_model as second element."""
    from gateway.client import make_client

    _, model = make_client(litellm_gateway_config)
    assert model == "gpt-4o"


def test_make_client_litellm_has_messages_interface(litellm_gateway_config):
    """LiteLLM client exposes a .messages attribute with create and stream."""
    from gateway.client import make_client

    client, _ = make_client(litellm_gateway_config)
    assert hasattr(client, "messages")
    assert hasattr(client.messages, "create")
    assert hasattr(client.messages, "stream")


def test_make_client_litellm_timeout_from_config(litellm_gateway_config):
    """LiteLLM client timeout comes from GatewayConfig.litellm_timeout."""
    from gateway.client import make_client

    client, _ = make_client(litellm_gateway_config)
    assert client.timeout.read == 90.0


def test_make_client_litellm_custom_timeout():
    """LiteLLM client respects custom timeout values."""
    from gateway.client import make_client
    from gateway.config import GatewayConfig

    custom_cfg = GatewayConfig(
        backend="litellm",
        ollama_base_url="http://127.0.0.1:11434",
        ollama_model="",
        ollama_timeout=300,
        claude_api_key="",
        claude_model="",
        claude_timeout=60,
        litellm_model="gemini/gemini-2.0-flash",
        litellm_api_key="test-key",
        litellm_timeout=200,
    )
    client, model = make_client(custom_cfg)
    assert client.timeout.read == 200.0
    assert model == "gemini/gemini-2.0-flash"
