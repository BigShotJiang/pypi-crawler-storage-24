# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""RAG quality regression tests — validate retrieval returns relevant content.

Tests assert that queries return chunks containing expected keywords,
rather than asserting specific source filenames (which shift with
re-ingestion and knowledge base changes).
"""
from __future__ import annotations

import pytest


def _rag_available() -> bool:
    try:
        from gateway.retriever import Retriever
        r = Retriever()
        return r.count > 0
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _rag_available(),
    reason="RAG index empty or ChromaDB unavailable",
)


@pytest.fixture(scope="module")
def retriever():
    from gateway.retriever import Retriever
    return Retriever()


def _assert_content_relevant(retriever, query: str, expected_keywords: list[str], top_k: int = 20):
    """Assert retrieved chunks contain expected keywords."""
    results = retriever.query(query, top_k=top_k)
    assert len(results) > 0, f"No results for query: {query}"
    combined = " ".join(r["document"].lower() for r in results)
    for kw in expected_keywords:
        assert kw.lower() in combined, (
            f"Expected keyword '{kw}' not found in top-{top_k} results for: {query}"
        )


class TestRAGOffensive:
    def test_kerberoasting(self, retriever):
        _assert_content_relevant(retriever, "Kerberoasting AS-REP roasting", ["kerberos", "roast"])

    def test_sql_injection(self, retriever):
        _assert_content_relevant(retriever, "SQL injection UNION SELECT", ["sql", "injection"])

    def test_linux_privesc(self, retriever):
        _assert_content_relevant(retriever, "Linux privilege escalation SUID", ["privilege", "escalation"])

    def test_c2_framework(self, retriever):
        _assert_content_relevant(retriever, "C2 command and control beacon", ["c2", "beacon"])

    def test_cloud_attacks(self, retriever):
        _assert_content_relevant(retriever, "AWS SSRF metadata credential theft", ["metadata", "ssrf"])

    def test_reverse_shell(self, retriever):
        _assert_content_relevant(retriever, "reverse shell bash netcat", ["reverse", "shell"])


class TestRAGDefensive:
    def test_sigma_rules(self, retriever):
        _assert_content_relevant(retriever, "Sigma detection rule process creation", ["sigma", "detection"])

    def test_windows_event_logs(self, retriever):
        _assert_content_relevant(retriever, "Windows Event ID 4688 4624", ["event", "log"])

    def test_siem_soc(self, retriever):
        _assert_content_relevant(retriever, "SIEM correlation SOC alert triage", ["siem", "alert"])

    def test_hardening(self, retriever):
        _assert_content_relevant(retriever, "CIS benchmark Linux hardening", ["hardening", "cis"])

    def test_edr(self, retriever):
        _assert_content_relevant(retriever, "EDR hooks AMSI bypass", ["edr", "amsi"])


class TestRAGIncident:
    def test_ransomware_playbook(self, retriever):
        _assert_content_relevant(retriever, "ransomware incident response containment", ["ransomware"])

    def test_forensic_artifacts(self, retriever):
        _assert_content_relevant(retriever, "forensic artifacts MFT prefetch", ["forensic", "artifact"])

    def test_memory_forensics(self, retriever):
        _assert_content_relevant(retriever, "Volatility memory analysis", ["memory"])


class TestRAGPrivacy:
    def test_gdpr(self, retriever):
        _assert_content_relevant(retriever, "GDPR data protection regulation", ["gdpr", "data"])

    def test_privacy(self, retriever):
        _assert_content_relevant(retriever, "data protection DLP classification", ["data", "protection"])


class TestRAGArchitect:
    def test_threat_modeling(self, retriever):
        _assert_content_relevant(retriever, "STRIDE threat model attack surface", ["stride", "threat"])

    def test_aws_security(self, retriever):
        _assert_content_relevant(retriever, "AWS IAM policy S3 bucket security", ["aws", "iam"])

    def test_kubernetes(self, retriever):
        _assert_content_relevant(retriever, "Kubernetes container escape RBAC", ["kubernetes", "container"])

    def test_tls_crypto(self, retriever):
        _assert_content_relevant(retriever, "TLS 1.3 certificate cipher suite", ["tls", "certificate"])


class TestRAGRecon:
    def test_osint(self, retriever):
        _assert_content_relevant(retriever, "OSINT subdomain enumeration recon", ["subdomain", "enumeration"])


class TestRAGCrossCutting:
    def test_breach_case_studies(self, retriever):
        _assert_content_relevant(retriever, "SolarWinds supply chain breach", ["solarwinds", "supply"])

    def test_ai_security(self, retriever):
        _assert_content_relevant(retriever, "LLM prompt injection adversarial AI", ["prompt", "injection"])

    def test_evasion(self, retriever):
        _assert_content_relevant(retriever, "AMSI bypass ETW evasion EDR unhooking", ["amsi", "evasion"])

    def test_emerging_threats(self, retriever):
        _assert_content_relevant(retriever, "ransomware as a service RaaS", ["ransomware", "service"])
