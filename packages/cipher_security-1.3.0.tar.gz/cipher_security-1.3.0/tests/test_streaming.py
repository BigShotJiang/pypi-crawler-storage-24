# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Tests for Gateway.send_stream() — streaming response pipeline."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import anthropic


def _make_gateway(stream_texts=None):
    """Build a Gateway with mocked internals for stream testing."""
    from gateway.config import GatewayConfig

    cfg = GatewayConfig(
        backend="ollama",
        ollama_base_url="http://127.0.0.1:11434",
        ollama_model="cipher",
        ollama_timeout=300,
        claude_api_key="",
        claude_model="",
        claude_timeout=60,
    )

    client_mock = MagicMock()

    # Mock streaming context manager
    if stream_texts is not None:
        stream_mock = MagicMock()
        stream_mock.__enter__ = MagicMock(return_value=stream_mock)
        stream_mock.__exit__ = MagicMock(return_value=False)
        stream_mock.text_stream = iter(stream_texts)
        client_mock.messages.stream.return_value = stream_mock

    keyword_table = {"RED": ["exploit"], "BLUE": ["detection"]}

    with (
        patch("gateway.gateway.load_config", return_value=cfg),
        patch("gateway.gateway.make_client", return_value=(client_mock, "cipher")),
        patch("gateway.gateway.parse_keyword_table", return_value=keyword_table),
        patch("pathlib.Path.read_text", return_value=""),
        patch("gateway.gateway.assemble_system_prompt", return_value="prompt"),
    ):
        from gateway.gateway import Gateway
        gw = Gateway(rag=False)
        return gw, client_mock


class TestSendStream:
    def test_yields_mode_header_first(self):
        gw, _ = _make_gateway(["Hello", " world"])
        tokens = list(gw.send_stream("[MODE: RED] test"))
        assert tokens[0].startswith("[MODE:")

    def test_yields_all_tokens(self):
        gw, _ = _make_gateway(["Hello", " world", "!"])
        tokens = list(gw.send_stream("[MODE: RED] test"))
        # First token is mode header, rest are content
        content = "".join(tokens[1:])
        assert "Hello world!" == content

    def test_disambiguation_yields_clarification(self):
        gw, _ = _make_gateway()
        # "exploit detection" matches both RED and BLUE
        tokens = list(gw.send_stream("exploit detection overlap"))
        assert any("Multiple modes" in t for t in tokens)

    def test_handles_timeout_error(self):
        gw, client = _make_gateway()
        stream_mock = MagicMock()
        stream_mock.__enter__ = MagicMock(side_effect=anthropic.APITimeoutError(request=MagicMock()))
        client.messages.stream.return_value = stream_mock
        tokens = list(gw.send_stream("[MODE: RED] test"))
        assert any("ERROR" in t for t in tokens)

    def test_handles_connection_error(self):
        gw, client = _make_gateway()
        stream_mock = MagicMock()
        stream_mock.__enter__ = MagicMock(side_effect=anthropic.APIConnectionError(request=MagicMock()))
        client.messages.stream.return_value = stream_mock
        tokens = list(gw.send_stream("[MODE: RED] test"))
        assert any("ERROR" in t for t in tokens)
