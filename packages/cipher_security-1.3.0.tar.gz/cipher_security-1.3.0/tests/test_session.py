"""Unit tests for src/bot/session.py — SessionManager."""

from __future__ import annotations

from datetime import datetime, timezone, timedelta

from bot.session import SessionManager


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now() -> datetime:
    return datetime.now(timezone.utc)


def _ago(seconds: int) -> datetime:
    return _now() - timedelta(seconds=seconds)


# ---------------------------------------------------------------------------
# get() — new sender returns empty list
# ---------------------------------------------------------------------------

class TestGet:
    def test_new_sender_returns_empty_list(self):
        sm = SessionManager()
        assert sm.get("+15551234567") == []

    def test_unknown_sender_after_reset_returns_empty_list(self):
        sm = SessionManager()
        sm.update("+15551234567", "hello", "hi")
        sm.reset("+15551234567")
        assert sm.get("+15551234567") == []

    def test_get_returns_list_type(self):
        sm = SessionManager()
        result = sm.get("+15550000000")
        assert isinstance(result, list)


# ---------------------------------------------------------------------------
# update() — history accumulation
# ---------------------------------------------------------------------------

class TestUpdate:
    def test_single_update_produces_two_items(self):
        sm = SessionManager()
        sm.update("+1", "user message", "assistant response")
        history = sm.get("+1")
        assert len(history) == 2

    def test_history_format_matches_gateway(self):
        """History entries must be {"role": ..., "content": ...} dicts."""
        sm = SessionManager()
        sm.update("+1", "question", "answer")
        history = sm.get("+1")
        assert history[0] == {"role": "user", "content": "question"}
        assert history[1] == {"role": "assistant", "content": "answer"}

    def test_multiple_updates_accumulate(self):
        sm = SessionManager()
        sm.update("+1", "q1", "a1")
        sm.update("+1", "q2", "a2")
        sm.update("+1", "q3", "a3")
        history = sm.get("+1")
        assert len(history) == 6
        assert history[0] == {"role": "user", "content": "q1"}
        assert history[4] == {"role": "user", "content": "q3"}

    def test_different_senders_independent(self):
        sm = SessionManager()
        sm.update("+1", "from1", "resp1")
        sm.update("+2", "from2", "resp2")
        assert len(sm.get("+1")) == 2
        assert len(sm.get("+2")) == 2
        assert sm.get("+1")[0]["content"] == "from1"
        assert sm.get("+2")[0]["content"] == "from2"


# ---------------------------------------------------------------------------
# Cap enforcement — max 20 pairs (40 items)
# ---------------------------------------------------------------------------

class TestCap:
    def test_exactly_20_pairs_not_evicted(self):
        sm = SessionManager(max_pairs=20)
        for i in range(20):
            sm.update("+1", f"q{i}", f"a{i}")
        assert len(sm.get("+1")) == 40

    def test_21st_pair_evicts_oldest(self):
        sm = SessionManager(max_pairs=20)
        for i in range(21):
            sm.update("+1", f"q{i}", f"a{i}")
        history = sm.get("+1")
        # Should be capped at 40 items
        assert len(history) == 40
        # Oldest pair (q0/a0) evicted — first item should be q1
        assert history[0]["content"] == "q1"

    def test_cap_at_5_pairs(self):
        """Custom max_pairs cap works."""
        sm = SessionManager(max_pairs=5)
        for i in range(7):
            sm.update("+1", f"q{i}", f"a{i}")
        history = sm.get("+1")
        assert len(history) == 10  # 5 pairs * 2
        assert history[0]["content"] == "q2"  # oldest 2 pairs evicted

    def test_cap_preserves_newest_messages(self):
        sm = SessionManager(max_pairs=3)
        for i in range(5):
            sm.update("+1", f"q{i}", f"a{i}")
        history = sm.get("+1")
        # Last 3 pairs: q2/a2, q3/a3, q4/a4
        contents = [h["content"] for h in history]
        assert "q4" in contents
        assert "a4" in contents
        assert "q0" not in contents


# ---------------------------------------------------------------------------
# reset() — clears session
# ---------------------------------------------------------------------------

class TestReset:
    def test_reset_clears_history(self):
        sm = SessionManager()
        sm.update("+1", "hello", "world")
        sm.reset("+1")
        assert sm.get("+1") == []

    def test_reset_nonexistent_sender_no_error(self):
        """reset() on unknown sender should not raise."""
        sm = SessionManager()
        sm.reset("+99999")  # should not raise

    def test_reset_does_not_affect_other_senders(self):
        sm = SessionManager()
        sm.update("+1", "hello", "world")
        sm.update("+2", "hi", "there")
        sm.reset("+1")
        assert sm.get("+1") == []
        assert len(sm.get("+2")) == 2


# ---------------------------------------------------------------------------
# cleanup() — timeout eviction
# ---------------------------------------------------------------------------

class TestCleanup:
    def test_cleanup_removes_stale_session(self):
        sm = SessionManager(timeout_seconds=3600)
        sm.update("+1", "old", "message")
        # Manually set last_active to > 1h ago
        sm._sessions["+1"]["last_active"] = _ago(3601)
        sm.cleanup()
        assert "+1" not in sm._sessions

    def test_cleanup_keeps_active_session(self):
        sm = SessionManager(timeout_seconds=3600)
        sm.update("+1", "recent", "message")
        # last_active is current — should survive cleanup
        sm.cleanup()
        assert "+1" in sm._sessions

    def test_cleanup_mixed_sessions(self):
        sm = SessionManager(timeout_seconds=3600)
        sm.update("+1", "old", "message")
        sm.update("+2", "fresh", "message")
        sm._sessions["+1"]["last_active"] = _ago(7200)
        sm.cleanup()
        assert "+1" not in sm._sessions
        assert "+2" in sm._sessions

    def test_cleanup_called_implicitly_by_get(self):
        """get() expires stale sessions before returning."""
        sm = SessionManager(timeout_seconds=3600)
        sm.update("+1", "stale", "data")
        sm._sessions["+1"]["last_active"] = _ago(3601)
        # get() should trigger cleanup and return []
        result = sm.get("+1")
        assert result == []
        assert "+1" not in sm._sessions


# ---------------------------------------------------------------------------
# Timeout configurability
# ---------------------------------------------------------------------------

class TestTimeout:
    def test_custom_short_timeout(self):
        sm = SessionManager(timeout_seconds=60)
        sm.update("+1", "msg", "resp")
        sm._sessions["+1"]["last_active"] = _ago(61)
        sm.cleanup()
        assert "+1" not in sm._sessions

    def test_custom_timeout_session_still_active(self):
        sm = SessionManager(timeout_seconds=60)
        sm.update("+1", "msg", "resp")
        # last_active is now — should survive 60s timeout
        sm.cleanup()
        assert "+1" in sm._sessions


# ---------------------------------------------------------------------------
# update() updates last_active
# ---------------------------------------------------------------------------

class TestLastActive:
    def test_update_refreshes_last_active(self):
        sm = SessionManager(timeout_seconds=3600)
        sm.update("+1", "first", "reply")
        # Set as stale
        sm._sessions["+1"]["last_active"] = _ago(3601)
        # Update again — should refresh last_active
        sm.update("+1", "second", "reply")
        sm.cleanup()
        # Session should survive because last_active was just refreshed
        assert "+1" in sm._sessions
