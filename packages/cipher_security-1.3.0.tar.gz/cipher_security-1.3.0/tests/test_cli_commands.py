# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Tests for Typer CLI commands — version, doctor, status, ingest."""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

import pytest


SRC_DIR = Path(__file__).resolve().parent.parent / "src"

# ANSI escape code pattern
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def _strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from text."""
    return _ANSI_RE.sub("", text)


def _run_cipher(*args: str, timeout: int = 30) -> subprocess.CompletedProcess:
    """Run cipher CLI command and return result."""
    env = {**os.environ, "PYTHONPATH": str(SRC_DIR)}
    env.pop("FORCE_COLOR", None)
    env["NO_COLOR"] = "1"
    result = subprocess.run(
        [sys.executable, "-m", "gateway.app", *args],
        capture_output=True,
        text=True,
        cwd=str(SRC_DIR),
        timeout=timeout,
        env=env,
    )
    # Strip ANSI codes that Rich/Typer may emit despite NO_COLOR
    result = subprocess.CompletedProcess(
        result.args, result.returncode,
        stdout=_strip_ansi(result.stdout),
        stderr=_strip_ansi(result.stderr),
    )
    return result


class TestVersion:
    def test_version_exits_zero(self):
        r = _run_cipher("version")
        assert r.returncode == 0

    def test_version_shows_cipher(self):
        r = _run_cipher("version")
        assert "CIPHER" in r.stdout

    def test_version_shows_semver(self):
        r = _run_cipher("version")
        assert "v0." in r.stdout or "v1." in r.stdout


class TestHelp:
    def test_help_exits_zero(self):
        r = _run_cipher("--help")
        assert r.returncode == 0

    def test_help_lists_commands(self):
        r = _run_cipher("--help")
        for cmd in ["query", "setup", "status", "doctor", "ingest", "dashboard", "version"]:
            assert cmd in r.stdout, f"Missing command in help: {cmd}"

    def test_query_help(self):
        r = _run_cipher("query", "--help")
        assert r.returncode == 0
        assert "--backend" in r.stdout
        assert "--smart" in r.stdout
        assert "--stream" in r.stdout


class TestDoctor:
    def test_doctor_exits_zero(self):
        r = _run_cipher("doctor")
        assert r.returncode == 0

    def test_doctor_checks_python(self):
        r = _run_cipher("doctor")
        assert "Python" in r.stdout

    def test_doctor_checks_rag(self):
        r = _run_cipher("doctor")
        assert "RAG" in r.stdout

    def test_doctor_checks_knowledge(self):
        r = _run_cipher("doctor")
        assert "Knowledge" in r.stdout or "knowledge" in r.stdout

    def test_doctor_checks_skills(self):
        r = _run_cipher("doctor")
        assert "skill" in r.stdout.lower()


class TestStatus:
    def test_status_exits_zero(self):
        r = _run_cipher("status")
        # May exit 1 if no config, that's ok
        assert r.returncode in (0, 1)

    def test_status_shows_banner(self):
        r = _run_cipher("status")
        # Banner is ASCII art block letters, so check for the art or the word
        assert "CIPHER" in r.stdout or "██" in r.stdout


_CI = os.environ.get("CI") == "true" or os.environ.get("GITHUB_ACTIONS") == "true"


@pytest.mark.skipif(_CI, reason="Ingestion too slow for CI runners")
class TestIngest:
    def test_ingest_exits_zero(self):
        r = _run_cipher("ingest", timeout=600)
        assert r.returncode == 0

    def test_ingest_shows_chunk_count(self):
        r = _run_cipher("ingest", timeout=600)
        assert "chunks" in r.stdout.lower() or "Indexed" in r.stdout
