"""Tests for --smart backend routing heuristic in cipher-gw.

Tests:
- _select_backend_smart routes complex/long queries to "claude"
- _select_backend_smart routes short/lookup queries to "ollama"
- --smart flag is accepted by argparse without error
- Routing decision is logged to stderr with [CIPHER] prefix
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path



# ---------------------------------------------------------------------------
# Unit tests: _select_backend_smart heuristic
# ---------------------------------------------------------------------------

def test_smart_routing_complex_long() -> None:
    """Long message (> 200 chars) should route to claude."""
    from gateway.cli import _select_backend_smart

    message = "design a zero trust network architecture with microsegmentation for our cloud environment and explain all the components including identity-aware proxies, service mesh, and BeyondCorp-style policy enforcement"
    assert len(message) > 200, "test message must be > 200 chars for this test case"
    assert _select_backend_smart(message) == "claude"


def test_smart_routing_complex_keyword() -> None:
    """Message with complexity keyword 'analyze' should route to claude."""
    from gateway.cli import _select_backend_smart

    message = "analyze this CVE"
    assert _select_backend_smart(message) == "claude"


def test_smart_routing_quick() -> None:
    """Short message with no complexity keywords routes to ollama."""
    from gateway.cli import _select_backend_smart

    message = "what port does ssh use"
    assert _select_backend_smart(message) == "ollama"


def test_smart_routing_short_default() -> None:
    """Short lookup query routes to ollama."""
    from gateway.cli import _select_backend_smart

    message = "nmap flags"
    assert _select_backend_smart(message) == "ollama"


def test_smart_routing_design_keyword() -> None:
    """Message with 'design' keyword routes to claude."""
    from gateway.cli import _select_backend_smart

    message = "design a firewall policy"
    assert _select_backend_smart(message) == "claude"


def test_smart_routing_threat_model_keyword() -> None:
    """Message with 'threat model' keyword routes to claude."""
    from gateway.cli import _select_backend_smart

    message = "threat model our web app"
    assert _select_backend_smart(message) == "claude"


def test_smart_routing_case_insensitive() -> None:
    """Keyword matching is case-insensitive."""
    from gateway.cli import _select_backend_smart

    message = "Analyze this log file"
    assert _select_backend_smart(message) == "claude"


# ---------------------------------------------------------------------------
# CLI integration tests: --smart flag acceptance
# ---------------------------------------------------------------------------

def test_smart_flag_accepted() -> None:
    """argparse must accept --smart flag on send subcommand without error."""
    from gateway.cli import _build_parser

    parser, send_parser = _build_parser()
    # Should not raise
    args = parser.parse_args(["send", "--smart", "what port does ssh use"])
    assert args.smart is True


def test_smart_flag_default_false() -> None:
    """--smart flag defaults to False when not provided."""
    from gateway.cli import _build_parser

    parser, send_parser = _build_parser()
    args = parser.parse_args(["send", "what port does ssh use"])
    assert args.smart is False


# ---------------------------------------------------------------------------
# Integration test: stderr routing log
# ---------------------------------------------------------------------------

def test_smart_routing_logs_to_stderr() -> None:
    """When --smart is active and no --backend given, routing decision is printed to stderr."""
    src_dir = Path(__file__).resolve().parent.parent / "src"
    result = subprocess.run(
        [
            sys.executable, "-m", "gateway.cli",
            "--smart", "what port does ssh use",
        ],
        capture_output=True,
        text=True,
        cwd=str(src_dir),
        timeout=30,
    )
    # Routing decision must appear on stderr with [CIPHER] prefix
    assert "[CIPHER] smart routing" in result.stderr


def test_smart_routing_no_log_when_backend_explicit() -> None:
    """When --backend is explicitly set, smart routing should NOT override or log."""
    # We test at the unit level by inspecting _send_message logic:
    # args.smart=True + args.backend="ollama" -> no override
    from gateway.cli import _build_parser

    parser, send_parser = _build_parser()
    args = parser.parse_args(["send", "--smart", "--backend", "ollama", "analyze this CVE"])
    # With explicit --backend, smart routing should not override
    # Verify args parsed correctly
    assert args.smart is True
    assert args.backend == "ollama"
