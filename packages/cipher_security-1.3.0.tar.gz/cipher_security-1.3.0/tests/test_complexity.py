"""Tests for gateway.complexity — smart routing complexity classifier.

Tests:
- Classification levels: SIMPLE, MODERATE, COMPLEX, EXPERT
- Routing: SIMPLE/MODERATE → "ollama", COMPLEX/EXPERT → "claude"
- Signal scoring: length, simple keywords, complex keywords, frameworks, structure
- Edge cases: empty string, very short queries, mixed signals
- Regression tests: known queries produce expected (level, backend) pairs
"""
from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Load gateway.complexity directly to avoid gateway.__init__ pulling in
# heavy deps (anthropic) that may not be installed in test environments.
# ---------------------------------------------------------------------------
_MOD_PATH = Path(__file__).resolve().parent.parent / "src" / "gateway" / "complexity.py"
_spec = importlib.util.spec_from_file_location("gateway.complexity", _MOD_PATH)
_mod = importlib.util.module_from_spec(_spec)  # type: ignore[arg-type]
_spec.loader.exec_module(_mod)  # type: ignore[union-attr]

Complexity = _mod.Complexity
classify = _mod.classify
classify_and_route = _mod.classify_and_route
route_backend = _mod.route_backend
_score_length = _mod._score_length
_score_keywords = _mod._score_keywords
_score_structure = _mod._score_structure
_score_framework_density = _mod._score_framework_density
SIMPLE_KEYWORDS = _mod.SIMPLE_KEYWORDS
COMPLEX_KEYWORDS = _mod.COMPLEX_KEYWORDS


# ---------------------------------------------------------------------------
# Classification level tests
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "query",
    [
        "what port does SSH use",
        "how to install nmap",
        "define XSS",
        "what is a firewall",
        "default port for HTTPS",
        "list of nmap flags",
    ],
)
def test_simple_queries_classify_as_simple(query: str) -> None:
    """Factual lookups and single-concept questions → SIMPLE."""
    assert classify(query) == Complexity.SIMPLE


@pytest.mark.parametrize(
    "query",
    [
        "analyze the attack chain for Kerberoasting with detection gaps",
        "design a threat model for a multi-tier web application",
        "compare and contrast incident response strategies for ransomware vs supply chain attacks",
    ],
)
def test_complex_queries_classify_at_complex_or_above(query: str) -> None:
    """Deep reasoning, threat models, multi-part analysis → COMPLEX or EXPERT."""
    assert classify(query) >= Complexity.COMPLEX


@pytest.mark.parametrize(
    "query",
    [
        (
            "map NIST 800-53 controls to MITRE ATT&CK techniques and STRIDE threat "
            "categories for a multi-cloud environment with HIPAA compliance requirements, "
            "then produce a gap analysis with compensating controls and a detection "
            "engineering roadmap"
        ),
        (
            "design a comprehensive zero trust architecture using NIST CSF, "
            "ISO 27001, and CIS Controls for an enterprise with FedRAMP "
            "requirements and provide STRIDE threat modeling"
        ),
    ],
)
def test_expert_queries_classify_as_expert(query: str) -> None:
    """Cross-domain, multi-framework, advanced analysis → EXPERT."""
    assert classify(query) == Complexity.EXPERT


# ---------------------------------------------------------------------------
# Routing tests
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    ("level", "expected_backend"),
    [
        (1, "ollama"),   # SIMPLE
        (2, "ollama"),   # MODERATE
        (3, "claude"),   # COMPLEX
        (4, "claude"),   # EXPERT
    ],
    ids=["SIMPLE", "MODERATE", "COMPLEX", "EXPERT"],
)
def test_route_backend_mapping(level: int, expected_backend: str) -> None:
    """SIMPLE/MODERATE → ollama, COMPLEX/EXPERT → claude."""
    assert route_backend(Complexity(level)) == expected_backend


# ---------------------------------------------------------------------------
# Signal scoring: length
# ---------------------------------------------------------------------------

def test_length_score_short_is_zero() -> None:
    """Queries under 80 characters score 0 for length."""
    assert _score_length("ssh port") == 0


def test_length_score_medium() -> None:
    """Queries between 80-149 characters score 1."""
    assert _score_length("a" * 80) == 1


def test_length_score_long() -> None:
    """Queries 150-299 characters score 2."""
    assert _score_length("a" * 150) == 2


def test_length_score_very_long() -> None:
    """Queries 300-499 characters score 3."""
    assert _score_length("a" * 300) == 3


def test_length_score_extremely_long() -> None:
    """Queries 500+ characters score 4."""
    assert _score_length("a" * 500) == 4


# ---------------------------------------------------------------------------
# Signal scoring: simple keywords (negative)
# ---------------------------------------------------------------------------

def test_simple_keywords_pull_score_down() -> None:
    """Simple keyword matches return negative points."""
    score = _score_keywords("what port does ssh use", SIMPLE_KEYWORDS)
    assert score < 0


def test_simple_keyword_what_is() -> None:
    """'what is' matches with -2 points."""
    score = _score_keywords("what is a vulnerability", SIMPLE_KEYWORDS)
    assert score <= -2


def test_simple_keyword_how_to_install() -> None:
    """'how to install' matches with -2 points."""
    score = _score_keywords("how to install wireshark", SIMPLE_KEYWORDS)
    assert score <= -2


# ---------------------------------------------------------------------------
# Signal scoring: complex keywords (positive)
# ---------------------------------------------------------------------------

def test_complex_keywords_push_score_up() -> None:
    """Complex keyword matches return positive points."""
    score = _score_keywords("threat model this application", COMPLEX_KEYWORDS)
    assert score > 0


def test_complex_keyword_attack_chain() -> None:
    """'attack chain' adds 4 points."""
    score = _score_keywords("attack chain analysis", COMPLEX_KEYWORDS)
    assert score >= 4


# ---------------------------------------------------------------------------
# Signal scoring: framework density
# ---------------------------------------------------------------------------

def test_single_framework_no_bonus() -> None:
    """One framework reference gives base points but no density bonus."""
    score = _score_framework_density("apply nist 800-53 controls")
    # nist (2) + nist 800-53 (3) = 5, no 3+ bonus
    assert score >= 2


def test_three_plus_frameworks_gives_bonus() -> None:
    """3+ distinct framework references trigger the +3 bonus."""
    query = "map nist to stride and owasp controls"
    score = _score_framework_density(query)
    # nist (2) + stride (3) + owasp (2) + bonus (3) = 10
    assert score >= 10


def test_two_frameworks_no_bonus() -> None:
    """Exactly 2 framework references do not trigger the density bonus."""
    query = "compare stride and owasp"
    score = _score_framework_density(query)
    # stride (3) + owasp (2) = 5, no bonus
    assert score < 8  # would be 8+ with bonus


# ---------------------------------------------------------------------------
# Signal scoring: structure patterns
# ---------------------------------------------------------------------------

def test_structure_multiple_questions() -> None:
    """Multiple question marks add points."""
    score = _score_structure("what is the risk? how do we mitigate?")
    assert score > 0


def test_structure_comparison() -> None:
    """'compare' keyword adds points."""
    score = _score_structure("compare edr solutions")
    assert score >= 2


def test_structure_vs_keyword() -> None:
    """'vs' keyword adds points."""
    score = _score_structure("crowdstrike vs sentinelone")
    assert score >= 1


def test_structure_conditional() -> None:
    """Conditional 'what if' adds points."""
    score = _score_structure("what if the attacker has domain admin")
    assert score >= 2


def test_structure_scope_amplifier() -> None:
    """Scope amplifiers like 'comprehensive' add points."""
    score = _score_structure("provide a comprehensive analysis")
    assert score >= 2


def test_structure_no_patterns() -> None:
    """Plain query with no structural patterns scores 0."""
    score = _score_structure("ssh port number")
    assert score == 0


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

def test_empty_string_classifies_simple() -> None:
    """Empty string → SIMPLE."""
    assert classify("") == Complexity.SIMPLE


def test_very_short_query_classifies_simple() -> None:
    """Very short query → SIMPLE."""
    assert classify("ssh port") == Complexity.SIMPLE


def test_mixed_signals_simple_plus_complex() -> None:
    """When both simple and complex keywords are present, complex wins if score is high enough."""
    # "what is" (-2) + "threat model" (+4) → net positive
    level = classify("what is a threat model")
    assert level >= Complexity.SIMPLE  # at minimum SIMPLE, but complex keyword lifts it


def test_negative_score_floors_to_simple() -> None:
    """Queries that score negative still classify as SIMPLE, not below."""
    level = classify("what port does ssh use by default")
    assert level == Complexity.SIMPLE


# ---------------------------------------------------------------------------
# classify_and_route convenience function
# ---------------------------------------------------------------------------

def test_classify_and_route_returns_tuple() -> None:
    """classify_and_route returns (Complexity, str) tuple."""
    result = classify_and_route("what port does SSH use")
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], Complexity)
    assert isinstance(result[1], str)


def test_classify_and_route_simple() -> None:
    """classify_and_route for simple query returns (SIMPLE, 'ollama')."""
    level, backend = classify_and_route("what port does SSH use")
    assert level == Complexity.SIMPLE
    assert backend == "ollama"


def test_classify_and_route_complex() -> None:
    """classify_and_route for complex query returns (COMPLEX+, 'claude')."""
    level, backend = classify_and_route(
        "analyze the attack chain for Kerberoasting with detection gaps"
    )
    assert level >= Complexity.COMPLEX
    assert backend == "claude"


# ---------------------------------------------------------------------------
# Regression tests — pinned (query, min_level, backend) expectations
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    ("query", "expected_level_value", "expected_backend"),
    [
        ("what port does SSH use", 1, "ollama"),
        ("how to install nmap", 1, "ollama"),
        (
            "design a zero trust architecture with NIST 800-53 and STRIDE threat "
            "modeling for a multi-cloud environment",
            4,  # EXPERT
            "claude",
        ),
        (
            "compare CrowdStrike vs SentinelOne EDR detection capabilities "
            "and analyze detection coverage gaps for lateral movement techniques",
            3,  # COMPLEX
            "claude",
        ),
    ],
    ids=[
        "ssh-port-simple",
        "install-nmap-simple",
        "zero-trust-expert",
        "edr-compare-complex",
    ],
)
def test_regression_classification(
    query: str,
    expected_level_value: int,
    expected_backend: str,
) -> None:
    """Pinned regression: known queries must produce expected level and backend."""
    expected_level = Complexity(expected_level_value)
    level, backend = classify_and_route(query)
    assert level >= expected_level, (
        f"Expected at least {expected_level.name}, got {level.name} for: {query!r}"
    )
    assert backend == expected_backend
