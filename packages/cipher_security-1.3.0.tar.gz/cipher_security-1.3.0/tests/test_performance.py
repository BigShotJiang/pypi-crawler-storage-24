# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Performance budget tests — ensure operations stay within time limits."""
from __future__ import annotations

import time
from pathlib import Path

import pytest


def _rag_available() -> bool:
    try:
        from gateway.retriever import Retriever
        r = Retriever()
        return r.count > 0
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _rag_available(),
    reason="RAG index empty or ChromaDB unavailable",
)


class TestRAGPerformance:
    """RAG operations must meet performance budgets."""

    @pytest.fixture(scope="class")
    def retriever(self):
        from gateway.retriever import Retriever
        return Retriever()

    def test_query_under_500ms(self, retriever):
        """Single RAG query must complete in under 500ms."""
        start = time.monotonic()
        retriever.query("Kerberoasting", top_k=5)
        elapsed = time.monotonic() - start
        assert elapsed < 0.5, f"RAG query took {elapsed:.2f}s (budget: 0.5s)"

    def test_ten_queries_under_3s(self, retriever):
        """10 sequential queries must complete in under 3 seconds."""
        queries = [
            "SQL injection", "GDPR breach", "lateral movement",
            "container escape", "Sigma rule", "AMSI bypass",
            "ransomware playbook", "zero trust", "Kerberos",
            "AWS IAM policy",
        ]
        start = time.monotonic()
        for q in queries:
            retriever.query(q, top_k=5)
        elapsed = time.monotonic() - start
        assert elapsed < 3.0, f"10 queries took {elapsed:.2f}s (budget: 3.0s)"


class TestIngestionPerformance:
    """Knowledge base ingestion must be reasonably fast."""

    def test_ingest_under_120s(self, tmp_path):
        """Full re-ingestion of knowledge/ must complete in under 120s."""
        from gateway.retriever import Retriever
        r = Retriever(db_dir=tmp_path / "perf_test_db")

        kb_dir = Path(__file__).resolve().parent.parent / "knowledge"
        if not kb_dir.is_dir():
            pytest.skip("knowledge/ not available")

        start = time.monotonic()
        r.ingest(knowledge_dir=kb_dir)
        elapsed = time.monotonic() - start
        assert elapsed < 300.0, f"Ingestion took {elapsed:.2f}s (budget: 300s)"


class TestModeDetectionPerformance:
    """Mode detection must be near-instant."""

    def test_mode_detection_under_1ms(self):
        """Single mode detection must be sub-millisecond."""
        from gateway.mode import detect_mode, parse_keyword_table

        claude_md = Path(__file__).resolve().parent.parent / "CLAUDE.md"
        table = parse_keyword_table(claude_md.read_text(encoding="utf-8"))

        start = time.monotonic()
        for _ in range(1000):
            detect_mode("how to exploit a SQL injection vulnerability", table)
        elapsed = time.monotonic() - start
        per_call = elapsed / 1000
        assert per_call < 0.001, f"Mode detection: {per_call*1000:.2f}ms/call (budget: 1ms)"
