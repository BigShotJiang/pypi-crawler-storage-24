# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Architecture guardrail tests — scan source tree and assert invariants.

These tests catch structural problems before they become runtime bugs.
Inspired by OpenClaw's architecture guardrail pattern.
"""
from __future__ import annotations

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
SRC_DIR = REPO_ROOT / "src"
KNOWLEDGE_DIR = REPO_ROOT / "knowledge"
SKILLS_DIR = REPO_ROOT / "skills"


# ---------------------------------------------------------------------------
# Source code guardrails
# ---------------------------------------------------------------------------

class TestSourceGuardrails:
    """Ensure source code follows project conventions."""

    def test_no_hardcoded_api_keys(self):
        """No API keys or tokens hardcoded in source files."""
        patterns = ["sk-ant-", "sk-proj-", "Bearer sk-", "AKIA"]  # Anthropic, OpenAI, AWS
        for py_file in SRC_DIR.rglob("*.py"):
            content = py_file.read_text(encoding="utf-8")
            for pattern in patterns:
                assert pattern not in content, (
                    f"Possible hardcoded credential in {py_file.relative_to(REPO_ROOT)}: {pattern}"
                )

    def test_no_star_imports(self):
        """No 'from X import *' in source — explicit imports only."""
        for py_file in SRC_DIR.rglob("*.py"):
            content = py_file.read_text(encoding="utf-8")
            for i, line in enumerate(content.splitlines(), 1):
                stripped = line.strip()
                if stripped.startswith("from ") and "import *" in stripped:
                    pytest.fail(
                        f"Star import in {py_file.relative_to(REPO_ROOT)}:{i}: {stripped}"
                    )

    def test_all_source_files_have_copyright(self):
        """Every .py file in src/ has a copyright header."""
        for py_file in SRC_DIR.rglob("*.py"):
            if py_file.name == "__init__.py" and py_file.stat().st_size < 50:
                continue  # Skip tiny __init__.py
            content = py_file.read_text(encoding="utf-8")
            assert "Copyright" in content[:200], (
                f"Missing copyright header: {py_file.relative_to(REPO_ROOT)}"
            )


# ---------------------------------------------------------------------------
# Knowledge base guardrails
# ---------------------------------------------------------------------------

class TestKnowledgeGuardrails:
    """Ensure knowledge base integrity."""

    def test_knowledge_directory_exists(self):
        assert KNOWLEDGE_DIR.is_dir(), "knowledge/ directory missing"

    def test_all_knowledge_docs_have_content(self):
        """Every .md file in knowledge/ must have meaningful content (> 10 lines)."""
        for md_file in sorted(KNOWLEDGE_DIR.glob("*.md")):
            lines = md_file.read_text(encoding="utf-8").splitlines()
            assert len(lines) >= 10, (
                f"{md_file.name} has only {len(lines)} lines — likely empty or stub"
            )

    def test_no_empty_knowledge_files(self):
        """No knowledge files under 100 bytes."""
        for md_file in KNOWLEDGE_DIR.glob("*.md"):
            size = md_file.stat().st_size
            assert size >= 100, f"{md_file.name} is only {size} bytes"

    def test_knowledge_count_minimum(self):
        """Knowledge base should have at least 90 docs."""
        count = len(list(KNOWLEDGE_DIR.glob("*.md")))
        assert count >= 90, f"Only {count} knowledge docs — expected 90+"

    def test_master_index_exists(self):
        """00-MASTER-INDEX.md must exist."""
        assert (KNOWLEDGE_DIR / "00-MASTER-INDEX.md").exists()

    def test_critical_docs_exist(self):
        """Key domain docs must exist."""
        critical = [
            "active-directory-deep.md",
            "offensive-deep.md",
            "defensive-deep.md",
            "incident-playbooks-deep.md",
            "sigma-detection-deep.md",
            "privacy-regulations-deep.md",
            "threat-modeling-arch-deep.md",
            "aws-security-ultimate.md",
            "hardening-guides-ultimate.md",
            "ai-defense-deep.md",
        ]
        for doc in critical:
            assert (KNOWLEDGE_DIR / doc).exists(), f"Critical doc missing: {doc}"


# ---------------------------------------------------------------------------
# Skill file guardrails
# ---------------------------------------------------------------------------

class TestSkillGuardrails:
    """Ensure all skill files are present and well-formed."""

    EXPECTED_SKILLS = [
        "red-team",
        "blue-team",
        "purple-team",
        "privacy-engineering",
        "osint-recon",
        "incident-response",
        "threat-intelligence",
        "automation-scripting",
        "security-architecture",
    ]

    def test_skills_directory_exists(self):
        assert SKILLS_DIR.is_dir(), "skills/ directory missing"

    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_file_exists(self, skill_name):
        path = SKILLS_DIR / skill_name / "SKILL.md"
        assert path.exists(), f"Missing: skills/{skill_name}/SKILL.md"

    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_file_has_content(self, skill_name):
        path = SKILLS_DIR / skill_name / "SKILL.md"
        if path.exists():
            content = path.read_text(encoding="utf-8")
            assert len(content) > 200, f"skills/{skill_name}/SKILL.md is too short"

    def test_all_skills_have_copyright(self):
        """Every SKILL.md has copyright header."""
        for skill_file in SKILLS_DIR.rglob("SKILL.md"):
            content = skill_file.read_text(encoding="utf-8")
            assert "Copyright" in content[:300], (
                f"Missing copyright: {skill_file.relative_to(REPO_ROOT)}"
            )

    def test_red_team_sub_skills_exist(self):
        """Red team has sub-skills for web, AD, cloud, post-exploitation."""
        for sub in ["web", "active-directory", "cloud", "post-exploitation"]:
            path = SKILLS_DIR / "red-team" / sub / "SKILL.md"
            assert path.exists(), f"Missing: skills/red-team/{sub}/SKILL.md"


# ---------------------------------------------------------------------------
# Configuration guardrails
# ---------------------------------------------------------------------------

class TestConfigGuardrails:
    """Ensure config files are valid."""

    def test_pyproject_exists(self):
        assert (REPO_ROOT / "pyproject.toml").exists()

    def test_license_exists(self):
        assert (REPO_ROOT / "LICENSE").exists()

    def test_license_is_agpl(self):
        content = (REPO_ROOT / "LICENSE").read_text(encoding="utf-8")
        assert "GNU AFFERO GENERAL PUBLIC LICENSE" in content

    def test_modelfile_exists(self):
        assert (REPO_ROOT / "Modelfile").exists()

    def test_claude_md_exists(self):
        assert (REPO_ROOT / "CLAUDE.md").exists()

    def test_gitignore_includes_chromadb(self):
        content = (REPO_ROOT / ".gitignore").read_text(encoding="utf-8")
        assert ".chromadb" in content, ".chromadb not in .gitignore"
