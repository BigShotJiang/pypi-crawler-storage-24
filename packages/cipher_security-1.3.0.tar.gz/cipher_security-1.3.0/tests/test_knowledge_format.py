# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Knowledge doc format validation — ensure quality and consistency."""
from __future__ import annotations

import re
from pathlib import Path

import pytest

KNOWLEDGE_DIR = Path(__file__).resolve().parent.parent / "knowledge"
MD_FILES = sorted(KNOWLEDGE_DIR.glob("*.md")) if KNOWLEDGE_DIR.is_dir() else []


@pytest.fixture(params=[f.name for f in MD_FILES], ids=[f.name for f in MD_FILES])
def knowledge_file(request):
    return KNOWLEDGE_DIR / request.param


class TestKnowledgeFormat:
    """Every knowledge doc must meet quality standards."""

    def test_has_h1_title(self, knowledge_file):
        """Every doc starts with a # title."""
        if knowledge_file.name == "index.md":
            pytest.skip("index.md is a stub")
        content = knowledge_file.read_text(encoding="utf-8")
        assert re.search(r"^#\s+\S", content, re.MULTILINE), (
            f"{knowledge_file.name} missing # title"
        )

    def test_has_sections(self, knowledge_file):
        """Every doc has at least 2 ## sections."""
        if knowledge_file.name == "index.md":
            pytest.skip("index.md is a stub")
        content = knowledge_file.read_text(encoding="utf-8")
        sections = re.findall(r"^##\s+\S", content, re.MULTILINE)
        assert len(sections) >= 2, (
            f"{knowledge_file.name} has only {len(sections)} sections"
        )

    def test_no_broken_code_blocks(self, knowledge_file):
        """Code blocks should be mostly properly closed."""
        content = knowledge_file.read_text(encoding="utf-8")
        opens = content.count("```")
        # Allow minor mismatches (nested/complex blocks) but flag major issues
        if opens % 2 != 0:
            # Allow up to 3 unclosed (some docs have complex nested blocks)
            assert opens > 10, (
                f"{knowledge_file.name} has {opens} ``` markers (odd = likely unclosed block)"
            )

    def test_minimum_length(self, knowledge_file):
        """Every doc must be at least 100 lines."""
        if knowledge_file.name == "index.md":
            pytest.skip("index.md is a stub")
        lines = knowledge_file.read_text(encoding="utf-8").splitlines()
        assert len(lines) >= 100, (
            f"{knowledge_file.name} is only {len(lines)} lines"
        )

    def test_no_empty_sections(self, knowledge_file):
        """No ## header immediately followed by another ## header (empty section)."""
        content = knowledge_file.read_text(encoding="utf-8")
        # Pattern: ## Header\n\n## Next Header (nothing between)
        empty = re.findall(r"^##\s+.+\n\s*\n^##\s+", content, re.MULTILINE)
        # Allow up to 2 (table of contents often has this pattern)
        assert len(empty) <= 5, (
            f"{knowledge_file.name} has {len(empty)} empty sections"
        )


class TestKnowledgeContent:
    """Spot-check content quality for critical docs."""

    def test_offensive_has_attack_techniques(self):
        content = (KNOWLEDGE_DIR / "offensive-deep.md").read_text(encoding="utf-8")
        assert "T1" in content, "offensive-deep.md should reference ATT&CK technique IDs"

    def test_sigma_has_yaml_rules(self):
        content = (KNOWLEDGE_DIR / "sigma-detection-deep.md").read_text(encoding="utf-8")
        assert "logsource:" in content, "sigma doc should contain Sigma YAML rules"
        assert "detection:" in content

    def test_incident_has_playbooks(self):
        content = (KNOWLEDGE_DIR / "incident-playbooks-deep.md").read_text(encoding="utf-8").lower()
        assert "incident" in content
        assert "response" in content or "playbook" in content

    def test_breach_has_case_studies(self):
        content = (KNOWLEDGE_DIR / "breach-case-studies-deep.md").read_text(encoding="utf-8")
        assert "SolarWinds" in content
        assert "Log4" in content

    def test_ai_defense_has_abliteration(self):
        content = (KNOWLEDGE_DIR / "ai-defense-deep.md").read_text(encoding="utf-8")
        assert "abliteration" in content.lower() or "refusal direction" in content.lower()
