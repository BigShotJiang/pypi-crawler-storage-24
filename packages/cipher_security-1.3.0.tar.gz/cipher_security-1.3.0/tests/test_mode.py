"""Tests for src/gateway/mode.py — mode detection and keyword table parsing."""

import pytest

from gateway.mode import detect_mode, parse_keyword_table, strip_mode_prefix


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SAMPLE_CLAUDE_MD_TABLE = """\
#### Trigger Keywords

| Mode | Trigger Keywords |
|------|-----------------|
| RED | exploit, payload, reverse shell, privesc, C2, red team, offensive, attack path, bypass, lateral movement |
| BLUE | detection, SIEM, Sigma, log analysis, threat hunting, hardening, CIS, auditd, EDR, SOC, defensive |
| PURPLE | detection coverage, ATT&CK mapping, emulation, purple team, gap analysis, detection engineering |
| PRIVACY | GDPR, CCPA, HIPAA, DPIA, privacy by design, anonymization, data flow, Signal, VeraCrypt, OpSec |
| RECON | OSINT, reconnaissance, passive recon, subdomain, footprinting, intelligence gathering |
| INCIDENT | triage, incident response, IOC, forensics, containment, eradication, timeline, breach |
| ARCHITECT | design, architecture, threat model, zero trust, blast radius, compensating control, DFD |

- **Overlap → ask**
"""


@pytest.fixture
def keyword_table():
    """Hardcoded keyword table matching CLAUDE.md — used for deterministic detect_mode tests."""
    return {
        "RED": [
            "exploit", "payload", "reverse shell", "privesc", "c2",
            "red team", "offensive", "attack path", "bypass", "lateral movement",
        ],
        "BLUE": [
            "detection", "siem", "sigma", "log analysis", "threat hunting",
            "hardening", "cis", "auditd", "edr", "soc", "defensive",
        ],
        "PURPLE": [
            "detection coverage", "att&ck mapping", "emulation", "purple team",
            "gap analysis", "detection engineering",
        ],
        "PRIVACY": [
            "gdpr", "ccpa", "hipaa", "dpia", "privacy by design", "anonymization",
            "data flow", "signal", "veracrypt", "opsec",
        ],
        "RECON": [
            "osint", "reconnaissance", "passive recon", "subdomain",
            "footprinting", "intelligence gathering",
        ],
        "INCIDENT": [
            "triage", "incident response", "ioc", "forensics", "containment",
            "eradication", "timeline", "breach",
        ],
        "ARCHITECT": [
            "design", "architecture", "threat model", "zero trust", "blast radius",
            "compensating control", "dfd",
        ],
    }


# ---------------------------------------------------------------------------
# parse_keyword_table tests
# ---------------------------------------------------------------------------

class TestParseKeywordTable:
    def test_extracts_all_seven_modes(self):
        table = parse_keyword_table(SAMPLE_CLAUDE_MD_TABLE)
        assert set(table.keys()) == {"RED", "BLUE", "PURPLE", "PRIVACY", "RECON", "INCIDENT", "ARCHITECT"}

    def test_red_keywords_lowercased(self):
        table = parse_keyword_table(SAMPLE_CLAUDE_MD_TABLE)
        assert "exploit" in table["RED"]
        assert "payload" in table["RED"]
        assert "c2" in table["RED"]

    def test_blue_keywords_lowercased(self):
        table = parse_keyword_table(SAMPLE_CLAUDE_MD_TABLE)
        assert "siem" in table["BLUE"]
        assert "sigma" in table["BLUE"]

    def test_multi_word_keywords_preserved(self):
        table = parse_keyword_table(SAMPLE_CLAUDE_MD_TABLE)
        assert "reverse shell" in table["RED"]
        assert "threat model" in table["ARCHITECT"]
        assert "lateral movement" in table["RED"]

    def test_empty_string_returns_empty_dict(self):
        table = parse_keyword_table("")
        assert table == {}

    def test_malformed_table_returns_empty_dict(self):
        table = parse_keyword_table("no table here\njust text")
        assert table == {}

    def test_strips_whitespace_from_keywords(self):
        table = parse_keyword_table(SAMPLE_CLAUDE_MD_TABLE)
        for mode, keywords in table.items():
            for kw in keywords:
                assert kw == kw.strip(), f"Keyword {kw!r} in mode {mode} has extra whitespace"

    def test_all_keywords_lowercase(self):
        table = parse_keyword_table(SAMPLE_CLAUDE_MD_TABLE)
        for mode, keywords in table.items():
            for kw in keywords:
                assert kw == kw.lower(), f"Keyword {kw!r} in mode {mode} is not lowercase"


# ---------------------------------------------------------------------------
# detect_mode — explicit prefix tests
# ---------------------------------------------------------------------------

class TestDetectModeExplicitPrefix:
    def test_explicit_red_uppercase(self, keyword_table):
        mode, needs_clarification = detect_mode("[MODE: RED] how to bypass WAF", keyword_table)
        assert mode == "RED"
        assert needs_clarification is False

    def test_explicit_blue_lowercase(self, keyword_table):
        """Case-insensitive prefix detection — [MODE: blue] → BLUE."""
        mode, needs_clarification = detect_mode("[MODE: blue] check logs", keyword_table)
        assert mode == "BLUE"
        assert needs_clarification is False

    def test_explicit_mode_no_clarification_needed(self, keyword_table):
        """Explicit prefix always returns needs_clarification=False."""
        mode, needs_clarification = detect_mode("[MODE: PURPLE] gap analysis", keyword_table)
        assert mode == "PURPLE"
        assert needs_clarification is False

    def test_explicit_mode_takes_priority_over_keywords(self, keyword_table):
        """Explicit prefix wins even if keywords suggest a different mode."""
        mode, needs_clarification = detect_mode("[MODE: ARCHITECT] exploit this", keyword_table)
        assert mode == "ARCHITECT"
        assert needs_clarification is False

    def test_explicit_mode_mixed_case(self, keyword_table):
        mode, needs_clarification = detect_mode("[MODE: Red] attack path mapping", keyword_table)
        assert mode == "RED"
        assert needs_clarification is False


# ---------------------------------------------------------------------------
# detect_mode — keyword auto-detection tests
# ---------------------------------------------------------------------------

class TestDetectModeKeywordAutoDetect:
    def test_exploit_keyword_maps_to_red(self, keyword_table):
        mode, needs_clarification = detect_mode("how to exploit SQLi", keyword_table)
        assert mode == "RED"
        assert needs_clarification is False

    def test_siem_keyword_maps_to_blue(self, keyword_table):
        mode, needs_clarification = detect_mode("SIEM detection rules", keyword_table)
        assert mode == "BLUE"
        assert needs_clarification is False

    def test_threat_model_maps_to_architect(self, keyword_table):
        mode, needs_clarification = detect_mode("threat model for API", keyword_table)
        assert mode == "ARCHITECT"
        assert needs_clarification is False

    def test_no_keyword_defaults_to_architect(self, keyword_table):
        mode, needs_clarification = detect_mode("help me design something", keyword_table)
        # "design" is in ARCHITECT keywords so this matches
        assert mode == "ARCHITECT"
        assert needs_clarification is False

    def test_no_match_at_all_defaults_to_architect(self, keyword_table):
        mode, needs_clarification = detect_mode("what time is it", keyword_table)
        assert mode == "ARCHITECT"
        assert needs_clarification is False

    def test_keyword_case_insensitive_matching(self, keyword_table):
        """Keywords in messages should match regardless of case."""
        mode, needs_clarification = detect_mode("Running OSINT on a target", keyword_table)
        assert mode == "RECON"
        assert needs_clarification is False

    def test_triage_maps_to_incident(self, keyword_table):
        mode, needs_clarification = detect_mode("triage this incident now", keyword_table)
        assert mode == "INCIDENT"
        assert needs_clarification is False

    def test_gdpr_maps_to_privacy(self, keyword_table):
        mode, needs_clarification = detect_mode("GDPR compliance review", keyword_table)
        assert mode == "PRIVACY"
        assert needs_clarification is False


# ---------------------------------------------------------------------------
# detect_mode — overlap / needs_clarification tests
# ---------------------------------------------------------------------------

class TestDetectModeOverlap:
    def test_exploit_and_detection_overlap(self, keyword_table):
        """'exploit' (RED) + 'detection' (BLUE) → overlap → needs_clarification=True."""
        mode, needs_clarification = detect_mode("exploit detection coverage", keyword_table)
        assert needs_clarification is True
        # Both RED and BLUE should be in the returned string
        assert "RED" in mode
        assert "BLUE" in mode

    def test_overlap_modes_sorted(self, keyword_table):
        """Overlapping modes returned as sorted comma-joined string."""
        mode, needs_clarification = detect_mode("exploit detection coverage", keyword_table)
        parts = [m.strip() for m in mode.split(",")]
        assert parts == sorted(parts), "Overlapping modes should be sorted"

    def test_single_match_no_clarification(self, keyword_table):
        mode, needs_clarification = detect_mode("lateral movement technique", keyword_table)
        assert needs_clarification is False
        assert mode == "RED"


# ---------------------------------------------------------------------------
# strip_mode_prefix tests
# ---------------------------------------------------------------------------

class TestStripModePrefix:
    def test_strips_prefix_and_whitespace(self):
        result = strip_mode_prefix("[MODE: RED] query")
        assert result == "query"

    def test_strips_lowercase_prefix(self):
        result = strip_mode_prefix("[MODE: blue] check logs")
        assert result == "check logs"

    def test_no_prefix_unchanged(self):
        result = strip_mode_prefix("regular query with no prefix")
        assert result == "regular query with no prefix"

    def test_strips_leading_whitespace_after_prefix(self):
        result = strip_mode_prefix("[MODE: RED]   spaced query")
        assert result == "spaced query"

    def test_empty_string(self):
        result = strip_mode_prefix("")
        assert result == ""

    def test_only_prefix(self):
        result = strip_mode_prefix("[MODE: RED]")
        assert result == ""
