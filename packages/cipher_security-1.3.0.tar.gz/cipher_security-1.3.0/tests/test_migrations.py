# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Tests for config migrations."""
from __future__ import annotations

from gateway.migrations import CURRENT_VERSION, migrate


class TestMigrations:
    def test_already_current_no_change(self):
        config = {"_version": CURRENT_VERSION, "llm_backend": "ollama"}
        result = migrate(config)
        assert result == config

    def test_v1_to_v2_renames_backend(self):
        config = {"backend": "ollama", "ollama": {"model": "cipher"}}
        result = migrate(config)
        assert "llm_backend" in result
        assert "backend" not in result
        assert result["llm_backend"] == "ollama"

    def test_v1_to_v2_adds_missing_sections(self):
        config = {"llm_backend": "ollama"}
        result = migrate(config)
        assert "ollama" in result
        assert "claude" in result
        assert result["ollama"]["base_url"] == "http://127.0.0.1:11434"

    def test_v1_to_v2_normalizes_model_name(self):
        config = {"llm_backend": "ollama", "ollama": {"model": "qwen2.5:32b"}}
        result = migrate(config)
        assert result["ollama"]["model"] == "cipher"

    def test_sets_version_after_migration(self):
        config = {"llm_backend": "ollama"}
        result = migrate(config)
        assert result["_version"] == CURRENT_VERSION

    def test_empty_config_gets_defaults(self):
        config = {}
        result = migrate(config)
        assert "ollama" in result
        assert "claude" in result
        assert result["_version"] == CURRENT_VERSION

    def test_preserves_existing_values(self):
        config = {
            "llm_backend": "claude",
            "claude": {"api_key": "sk-test", "model": "opus", "timeout": 60},
            "ollama": {"base_url": "http://custom:11434", "model": "custom", "timeout": 500},
        }
        result = migrate(config)
        assert result["claude"]["api_key"] == "sk-test"
        assert result["ollama"]["base_url"] == "http://custom:11434"
        assert result["ollama"]["model"] == "custom"
