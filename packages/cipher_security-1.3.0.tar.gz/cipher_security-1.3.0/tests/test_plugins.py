"""Tests for gateway.plugins — plugin discovery, install, uninstall."""
from __future__ import annotations

import pytest
import yaml


# ---------------------------------------------------------------------------
# Plugin discovery
# ---------------------------------------------------------------------------

class TestPluginDiscovery:
    def test_empty_plugin_dir(self, tmp_path, monkeypatch):
        """No plugins when plugin directory is empty."""
        from gateway.plugins import PluginManager

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "plugins")
        pm = PluginManager()
        pm.discover()
        assert pm.plugins == []

    def test_discovers_user_plugin(self, tmp_path, monkeypatch):
        """Discovers a plugin from the user plugin directory."""
        from gateway.plugins import PluginManager

        plugin_dir = tmp_path / "plugins" / "test-skill"
        plugin_dir.mkdir(parents=True)
        (plugin_dir / "SKILL.md").write_text("# Test Skill\nSome content.")
        (plugin_dir / "plugin.yaml").write_text(yaml.dump({
            "name": "test-skill",
            "version": "1.0.0",
            "author": "tester",
            "description": "A test skill",
            "modes": ["RED"],
            "triggers": ["test-trigger"],
            "priority": 50,
        }))

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "plugins")
        pm = PluginManager()
        pm.discover()

        assert len(pm.plugins) == 1
        p = pm.plugins[0]
        assert p.name == "test-skill"
        assert p.version == "1.0.0"
        assert p.modes == ["RED"]
        assert p.source == "user"
        assert "Test Skill" in p.skill_content

    def test_plugin_without_yaml_uses_dirname(self, tmp_path, monkeypatch):
        """Plugin with SKILL.md but no plugin.yaml uses directory name."""
        from gateway.plugins import PluginManager

        plugin_dir = tmp_path / "plugins" / "bare-skill"
        plugin_dir.mkdir(parents=True)
        (plugin_dir / "SKILL.md").write_text("# Bare Skill")

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "plugins")
        pm = PluginManager()
        pm.discover()

        assert len(pm.plugins) == 1
        assert pm.plugins[0].name == "bare-skill"
        assert pm.plugins[0].version == "0.0.0"

    def test_skips_dir_without_skill_md(self, tmp_path, monkeypatch):
        """Directories without SKILL.md are skipped."""
        from gateway.plugins import PluginManager

        plugin_dir = tmp_path / "plugins" / "no-skill"
        plugin_dir.mkdir(parents=True)
        (plugin_dir / "plugin.yaml").write_text(yaml.dump({"name": "no-skill"}))

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "plugins")
        pm = PluginManager()
        pm.discover()

        assert len(pm.plugins) == 0

    def test_plugins_sorted_by_priority(self, tmp_path, monkeypatch):
        """Plugins are sorted by priority (lower first)."""
        from gateway.plugins import PluginManager

        for name, priority in [("high", 90), ("low", 10), ("mid", 50)]:
            d = tmp_path / "plugins" / name
            d.mkdir(parents=True)
            (d / "SKILL.md").write_text(f"# {name}")
            (d / "plugin.yaml").write_text(yaml.dump({
                "name": name, "priority": priority, "modes": ["RED"],
            }))

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "plugins")
        pm = PluginManager()
        pm.discover()

        names = [p.name for p in pm.plugins]
        assert names == ["low", "mid", "high"]


# ---------------------------------------------------------------------------
# Mode filtering
# ---------------------------------------------------------------------------

class TestModeFiltering:
    def test_get_skills_for_mode(self, tmp_path, monkeypatch):
        """get_skills_for_mode returns only matching plugins."""
        from gateway.plugins import PluginManager

        for name, modes in [("red-plugin", ["RED"]), ("blue-plugin", ["BLUE"]), ("multi", ["RED", "BLUE"])]:
            d = tmp_path / "plugins" / name
            d.mkdir(parents=True)
            (d / "SKILL.md").write_text(f"# {name}")
            (d / "plugin.yaml").write_text(yaml.dump({"name": name, "modes": modes}))

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "plugins")
        pm = PluginManager()

        red = pm.get_skills_for_mode("RED")
        assert len(red) == 2
        red_names = {p.name for p in red}
        assert red_names == {"red-plugin", "multi"}

        blue = pm.get_skills_for_mode("BLUE")
        assert len(blue) == 2

        arch = pm.get_skills_for_mode("ARCHITECT")
        assert len(arch) == 0

    def test_mode_matching_is_case_insensitive(self, tmp_path, monkeypatch):
        """Mode matching works regardless of case."""
        from gateway.plugins import PluginManager

        d = tmp_path / "plugins" / "test"
        d.mkdir(parents=True)
        (d / "SKILL.md").write_text("# Test")
        (d / "plugin.yaml").write_text(yaml.dump({"name": "test", "modes": ["red"]}))

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "plugins")
        pm = PluginManager()

        assert len(pm.get_skills_for_mode("RED")) == 1
        assert len(pm.get_skills_for_mode("red")) == 1


# ---------------------------------------------------------------------------
# Install / uninstall
# ---------------------------------------------------------------------------

class TestInstallUninstall:
    def test_install_from_local_dir(self, tmp_path, monkeypatch):
        """Install copies a local plugin directory."""
        from gateway.plugins import install_plugin

        # Create source plugin
        source = tmp_path / "source-plugin"
        source.mkdir()
        (source / "SKILL.md").write_text("# Source Plugin")
        (source / "plugin.yaml").write_text(yaml.dump({
            "name": "source-plugin", "version": "2.0.0", "modes": ["BLUE"],
        }))

        target_dir = tmp_path / "installed"
        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", target_dir)

        plugin = install_plugin(str(source))
        assert plugin.name == "source-plugin"
        assert plugin.version == "2.0.0"
        assert (target_dir / "source-plugin" / "SKILL.md").exists()

    def test_install_invalid_raises(self, tmp_path, monkeypatch):
        """Install raises ValueError for directories without SKILL.md."""
        from gateway.plugins import install_plugin

        source = tmp_path / "bad-plugin"
        source.mkdir()
        (source / "plugin.yaml").write_text(yaml.dump({"name": "bad"}))

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "installed")

        with pytest.raises(ValueError, match="SKILL.md"):
            install_plugin(str(source))

    def test_uninstall_existing(self, tmp_path, monkeypatch):
        """Uninstall removes an installed plugin."""
        from gateway.plugins import install_plugin, uninstall_plugin

        source = tmp_path / "removable"
        source.mkdir()
        (source / "SKILL.md").write_text("# Remove me")
        (source / "plugin.yaml").write_text(yaml.dump({"name": "removable"}))

        target_dir = tmp_path / "installed"
        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", target_dir)

        install_plugin(str(source))
        assert (target_dir / "removable").exists()

        assert uninstall_plugin("removable") is True
        assert not (target_dir / "removable").exists()

    def test_uninstall_nonexistent(self, tmp_path, monkeypatch):
        """Uninstall returns False for unknown plugins."""
        from gateway.plugins import uninstall_plugin

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "installed")
        assert uninstall_plugin("ghost") is False


# ---------------------------------------------------------------------------
# Extra triggers
# ---------------------------------------------------------------------------

class TestExtraTriggers:
    def test_get_extra_triggers(self, tmp_path, monkeypatch):
        """Plugins contribute additional trigger keywords."""
        from gateway.plugins import PluginManager

        d = tmp_path / "plugins" / "trig"
        d.mkdir(parents=True)
        (d / "SKILL.md").write_text("# Trigger test")
        (d / "plugin.yaml").write_text(yaml.dump({
            "name": "trig",
            "modes": ["RED"],
            "triggers": ["custom-attack", "custom-exploit"],
        }))

        monkeypatch.setattr("gateway.plugins._USER_PLUGIN_DIR", tmp_path / "plugins")
        pm = PluginManager()

        triggers = pm.get_extra_triggers()
        assert "RED" in triggers
        assert "custom-attack" in triggers["RED"]
        assert "custom-exploit" in triggers["RED"]
