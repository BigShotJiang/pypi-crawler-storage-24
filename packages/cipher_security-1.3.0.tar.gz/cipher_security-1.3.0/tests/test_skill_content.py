# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Skill file content validation — ensure every skill has required sections."""
from __future__ import annotations

from pathlib import Path

import pytest

SKILLS_DIR = Path(__file__).resolve().parent.parent / "skills"
SKILL_FILES = sorted(SKILLS_DIR.rglob("SKILL.md")) if SKILLS_DIR.is_dir() else []


@pytest.fixture(params=[str(f.relative_to(SKILLS_DIR)) for f in SKILL_FILES],
                ids=[str(f.relative_to(SKILLS_DIR)) for f in SKILL_FILES])
def skill_file(request):
    return SKILLS_DIR / request.param


class TestSkillContent:
    """Every SKILL.md must have required sections."""

    def test_has_title(self, skill_file):
        content = skill_file.read_text(encoding="utf-8")
        assert "# SKILL:" in content, f"{skill_file} missing '# SKILL:' title"

    def test_has_activation(self, skill_file):
        content = skill_file.read_text(encoding="utf-8")
        assert "Activation" in content or "activation" in content, (
            f"{skill_file} missing Activation section"
        )

    def test_has_quick_reference(self, skill_file):
        content = skill_file.read_text(encoding="utf-8")
        assert "Quick Reference" in content or "quick reference" in content, (
            f"{skill_file} missing Quick Reference section"
        )

    def test_has_competencies_or_equivalent(self, skill_file):
        """Skills must have a Competencies, Toolkit, or Kill Chain section."""
        content = skill_file.read_text(encoding="utf-8")
        has_section = any(kw in content for kw in [
            "Competencies", "competencies", "Toolkit", "toolkit",
            "Kill Chain", "kill chain", "Capabilities", "capabilities",
        ])
        assert has_section, f"{skill_file} missing Competencies/Toolkit/Capabilities section"

    def test_has_code_blocks(self, skill_file):
        """Skills should include practical code examples."""
        content = skill_file.read_text(encoding="utf-8")
        assert "```" in content, f"{skill_file} has no code blocks"

    def test_minimum_length(self, skill_file):
        content = skill_file.read_text(encoding="utf-8")
        assert len(content) > 500, f"{skill_file} is too short ({len(content)} chars)"
