# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Install script validation — syntax checks without executing."""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "scripts"


class TestInstallShell:
    """Validate install.sh syntax and structure."""

    @pytest.fixture(autouse=True)
    def _load(self):
        self.script = SCRIPTS_DIR / "install.sh"
        if not self.script.exists():
            pytest.skip("install.sh not found")
        self.content = self.script.read_text(encoding="utf-8")

    def test_has_shebang(self):
        assert self.content.startswith("#!/"), "Missing shebang"

    def test_has_set_euo_pipefail(self):
        assert "set -euo pipefail" in self.content, "Missing strict mode"

    def test_has_python_check(self):
        assert "python" in self.content.lower(), "No Python detection"

    def test_has_pip_install(self):
        assert "pip install" in self.content or "pipx install" in self.content

    def test_has_cipher_setup(self):
        assert "cipher setup" in self.content

    def test_has_error_handling(self):
        assert "fail" in self.content.lower() or "error" in self.content.lower()

    def test_shellcheck_passes(self):
        """Run shellcheck if available — advisory only."""
        if subprocess.run(["which", "shellcheck"], capture_output=True).returncode != 0:
            pytest.skip("shellcheck not installed")
        r = subprocess.run(
            ["shellcheck", "-S", "error", str(self.script)],
            capture_output=True, text=True,
        )
        # Only fail on actual errors, not warnings/info
        assert r.returncode == 0, f"shellcheck errors:\n{r.stdout}"


class TestInstallPowerShell:
    """Validate install.ps1 syntax and structure."""

    @pytest.fixture(autouse=True)
    def _load(self):
        self.script = SCRIPTS_DIR / "install.ps1"
        if not self.script.exists():
            pytest.skip("install.ps1 not found")
        self.content = self.script.read_text(encoding="utf-8")

    def test_has_error_action(self):
        assert "ErrorActionPreference" in self.content

    def test_has_python_check(self):
        assert "python" in self.content.lower()

    def test_has_pip_install(self):
        assert "pip install" in self.content

    def test_has_package_manager_detection(self):
        assert "winget" in self.content or "choco" in self.content
