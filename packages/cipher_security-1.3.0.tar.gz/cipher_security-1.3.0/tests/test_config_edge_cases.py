# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Config edge case tests — malformed YAML, missing fields, type errors."""
from __future__ import annotations


import pytest
import yaml

from gateway.config import GatewayConfig, load_config


class TestMalformedConfig:
    """Handle bad config gracefully."""

    def test_empty_yaml_gets_defaults_from_migration(self, tmp_path, monkeypatch):
        """Empty config.yaml — migration adds defaults, may or may not raise depending on what's resolved."""
        config = tmp_path / "config.yaml"
        config.write_text("")
        monkeypatch.delenv("LLM_BACKEND", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        # After migration, empty config may get defaults or raise — both are acceptable
        try:
            cfg = load_config(project_root=tmp_path)
            # If it succeeds, migration provided defaults
            assert cfg.backend in ("ollama", "claude", "")
        except ValueError:
            pass  # Also acceptable — no backend configured

    def test_non_dict_yaml_treated_as_empty(self, tmp_path, monkeypatch):
        """YAML that parses to a list = treated as empty dict."""
        config = tmp_path / "config.yaml"
        config.write_text("- item1\n- item2\n")
        monkeypatch.delenv("LLM_BACKEND", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        try:
            cfg = load_config(project_root=tmp_path)
            assert cfg.backend in ("ollama", "claude", "")
        except ValueError:
            pass

    def test_missing_config_file(self, tmp_path, monkeypatch):
        """No config.yaml anywhere should raise ValueError."""
        monkeypatch.setenv("HOME", str(tmp_path / "nohome"))
        monkeypatch.delenv("LLM_BACKEND", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        with pytest.raises(ValueError):
            load_config(project_root=tmp_path)


class TestTypeSafety:
    """Config values with wrong types should be handled."""

    def test_timeout_as_string(self, tmp_path, monkeypatch):
        """String timeout should be coerced to int."""
        config = tmp_path / "config.yaml"
        config.write_text(yaml.safe_dump({
            "llm_backend": "ollama",
            "ollama": {"base_url": "http://localhost:11434", "model": "cipher", "timeout": "300"},
            "claude": {"api_key": "", "model": "", "timeout": "60"},
        }))
        monkeypatch.delenv("LLM_BACKEND", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        cfg = load_config(project_root=tmp_path)
        assert isinstance(cfg.ollama_timeout, int)
        assert cfg.ollama_timeout == 300

    def test_backend_whitespace(self):
        """Backend with whitespace should be caught."""
        with pytest.raises(ValueError):
            GatewayConfig(
                backend="  ollama  ",
                ollama_base_url="http://localhost:11434",
                ollama_model="cipher",
                ollama_timeout=300,
                claude_api_key="",
                claude_model="",
                claude_timeout=60,
            )
