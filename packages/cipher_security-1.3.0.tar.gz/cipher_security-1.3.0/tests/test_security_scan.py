# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Security scanning tests — detect dangerous patterns in source code.

Inspired by OpenClaw's architecture guardrail tests.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

SRC_DIR = Path(__file__).resolve().parent.parent / "src"


class TestNoUnsafePatterns:
    """Scan source for security anti-patterns."""

    @pytest.fixture(autouse=True)
    def _load_sources(self):
        self.py_files = list(SRC_DIR.rglob("*.py"))
        assert len(self.py_files) > 0

    def test_no_eval(self):
        """No eval() calls — code injection risk."""
        for f in self.py_files:
            content = f.read_text(encoding="utf-8")
            for i, line in enumerate(content.splitlines(), 1):
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                assert "eval(" not in stripped, (
                    f"eval() found in {f.relative_to(SRC_DIR.parent)}:{i}"
                )

    def test_no_exec(self):
        """No exec() calls — code injection risk."""
        for f in self.py_files:
            content = f.read_text(encoding="utf-8")
            for i, line in enumerate(content.splitlines(), 1):
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                assert "exec(" not in stripped, (
                    f"exec() found in {f.relative_to(SRC_DIR.parent)}:{i}"
                )

    def test_no_pickle_loads(self):
        """No pickle.loads — deserialization attack risk."""
        for f in self.py_files:
            content = f.read_text(encoding="utf-8")
            assert "pickle.loads" not in content, (
                f"pickle.loads found in {f.relative_to(SRC_DIR.parent)}"
            )

    def test_no_shell_true_subprocess(self):
        """No subprocess with shell=True — command injection risk."""
        for f in self.py_files:
            content = f.read_text(encoding="utf-8")
            assert "shell=True" not in content, (
                f"shell=True found in {f.relative_to(SRC_DIR.parent)}"
            )

    def test_no_yaml_unsafe_load(self):
        """No yaml.load() without SafeLoader — arbitrary code execution."""
        for f in self.py_files:
            content = f.read_text(encoding="utf-8")
            # yaml.load( without Loader= is unsafe
            if "yaml.load(" in content and "yaml.safe_load" not in content:
                # Check if Loader is specified
                for i, line in enumerate(content.splitlines(), 1):
                    if "yaml.load(" in line and "Loader=" not in line:
                        pytest.fail(
                            f"Unsafe yaml.load() in {f.relative_to(SRC_DIR.parent)}:{i}"
                        )

    def test_no_hardcoded_ips(self):
        """No hardcoded public IP addresses (private/localhost ok)."""
        ip_pattern = re.compile(r'\b(?!127\.0\.0\.1|0\.0\.0\.0|10\.|172\.|192\.168\.)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b')
        for f in self.py_files:
            content = f.read_text(encoding="utf-8")
            for i, line in enumerate(content.splitlines(), 1):
                if line.strip().startswith("#"):
                    continue
                match = ip_pattern.search(line)
                if match:
                    # Allow version strings like 0.84.0
                    ip = match.group()
                    parts = ip.split(".")
                    if all(0 <= int(p) <= 255 for p in parts) and int(parts[0]) > 0:
                        pytest.fail(
                            f"Hardcoded IP {ip} in {f.relative_to(SRC_DIR.parent)}:{i}"
                        )

    def test_no_debug_breakpoints(self):
        """No leftover breakpoint() or pdb calls."""
        for f in self.py_files:
            content = f.read_text(encoding="utf-8")
            for i, line in enumerate(content.splitlines(), 1):
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                assert "breakpoint()" not in stripped, (
                    f"breakpoint() in {f.relative_to(SRC_DIR.parent)}:{i}"
                )
                assert "import pdb" not in stripped, (
                    f"import pdb in {f.relative_to(SRC_DIR.parent)}:{i}"
                )

    def test_no_print_secrets(self):
        """No print() calls that might leak secrets."""
        secret_patterns = ["api_key", "password", "secret"]  # "token" too ambiguous (streaming tokens)
        for f in self.py_files:
            content = f.read_text(encoding="utf-8")
            for i, line in enumerate(content.splitlines(), 1):
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                if "print(" in stripped:
                    for pattern in secret_patterns:
                        if pattern in stripped.lower() and "***" not in stripped:
                            # Allow test files, redaction code, and config error messages
                            if "test_" not in f.name and "redact" not in stripped and "cipher setup" not in stripped:
                                pytest.fail(
                                    f"Possible secret leak via print() in {f.relative_to(SRC_DIR.parent)}:{i}: {stripped[:80]}"
                                )
