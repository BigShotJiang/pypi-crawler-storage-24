# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Dashboard smoke tests — verify TUI app mounts without crash."""
from __future__ import annotations



class TestDashboardImport:
    """Dashboard module must import and construct without errors."""

    def test_import_dashboard(self):
        from gateway.dashboard import CipherDashboard
        assert CipherDashboard is not None

    def test_construct_app(self):
        from gateway.dashboard import CipherDashboard
        app = CipherDashboard()
        assert app.title == "CIPHER"

    def test_css_valid(self):
        """CSS string must be non-empty."""
        from gateway.dashboard import CIPHER_CSS
        assert len(CIPHER_CSS) > 100

    def test_run_dashboard_callable(self):
        from gateway.dashboard import run_dashboard
        assert callable(run_dashboard)
