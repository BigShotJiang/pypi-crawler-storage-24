# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""End-to-end pipeline tests — full query flow with mocked LLM."""
from __future__ import annotations

from unittest.mock import MagicMock, patch



def _fake_response(text: str) -> MagicMock:
    content_block = MagicMock()
    content_block.text = text
    response = MagicMock()
    response.content = [content_block]
    return response


def _build_gateway(response_text="[MODE: RED] Test response", rag=False):
    """Build a Gateway with mocked LLM but real mode detection and prompt assembly."""
    from gateway.config import GatewayConfig

    cfg = GatewayConfig(
        backend="ollama",
        ollama_base_url="http://127.0.0.1:11434",
        ollama_model="cipher",
        ollama_timeout=300,
        claude_api_key="",
        claude_model="",
        claude_timeout=60,
    )

    client_mock = MagicMock()
    client_mock.messages.create.return_value = _fake_response(response_text)

    with (
        patch("gateway.gateway.load_config", return_value=cfg),
        patch("gateway.gateway.make_client", return_value=(client_mock, "cipher")),
    ):
        from gateway.gateway import Gateway
        gw = Gateway(rag=rag)
        return gw, client_mock


class TestFullPipeline:
    """End-to-end query tests with real mode detection + prompt assembly."""

    def test_red_query_calls_llm(self):
        gw, client = _build_gateway("[MODE: RED] SQL injection exploited")
        result = gw.send("how to exploit SQL injection")
        assert client.messages.create.called
        assert "[MODE:" in result

    def test_blue_query_calls_llm(self):
        gw, client = _build_gateway("[MODE: BLUE] Sigma rule created")
        result = gw.send("write a Sigma detection rule for PsExec")
        assert client.messages.create.called
        assert "[MODE:" in result

    def test_explicit_mode_prefix_preserved(self):
        gw, client = _build_gateway("[MODE: PRIVACY] GDPR analysis")
        result = gw.send("[MODE: PRIVACY] GDPR breach notification")
        assert "[MODE:" in result

    def test_system_prompt_includes_skill(self):
        """The assembled system prompt should include skill content."""
        gw, client = _build_gateway("[MODE: RED] response")
        gw.send("exploit a buffer overflow")
        call_kwargs = client.messages.create.call_args
        system = call_kwargs.kwargs.get("system") or call_kwargs[1].get("system", "")
        # System prompt should be non-trivial (base + skill)
        assert len(system) > 500, f"System prompt too short ({len(system)} chars)"

    def test_response_always_has_mode_header(self):
        """Even if LLM doesn't include mode header, gateway adds it."""
        gw, client = _build_gateway("Response without mode header")
        result = gw.send("what is XSS")
        assert result.startswith("[MODE:")

    def test_history_passed_to_llm(self):
        gw, client = _build_gateway("[MODE: ARCHITECT] follow-up")
        history = [
            {"role": "user", "content": "first question"},
            {"role": "assistant", "content": "first answer"},
        ]
        gw.send("follow-up question", history=history)
        call_kwargs = client.messages.create.call_args
        messages = call_kwargs.kwargs.get("messages") or call_kwargs[1].get("messages", [])
        assert len(messages) == 3  # 2 history + 1 new

    def test_duplicate_mode_header_stripped(self):
        """If LLM echoes the mode header twice, gateway deduplicates."""
        gw, _ = _build_gateway("[MODE: RED]\n[MODE: RED]\nActual content")
        result = gw.send("[MODE: RED] test")
        lines = result.strip().split("\n")
        mode_lines = [line for line in lines if line.startswith("[MODE:")]
        assert len(mode_lines) == 1, f"Duplicate mode headers: {mode_lines}"
