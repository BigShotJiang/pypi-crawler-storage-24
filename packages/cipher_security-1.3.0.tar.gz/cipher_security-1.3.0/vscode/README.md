# CIPHER VS Code Extension

Security engineering assistant for Visual Studio Code.

## Features

- **Sidebar chat panel** — cyberpunk-themed interface for security queries
- **7 operating modes** — RED, BLUE, PURPLE, PRIVACY, RECON, INCIDENT, ARCHITECT
- **Code analysis** — right-click selected code to analyze for security issues
- **Multi-backend** — Ollama (local), Claude API, or any LiteLLM provider
- **Keyboard shortcut** — `Ctrl+Shift+C` / `Cmd+Shift+C` to open query input

## Requirements

- Python 3.14+ with `cipher-security` installed
- At least one LLM backend configured (Ollama recommended for local use)

## Setup

1. Install CIPHER: `pip install cipher-security`
2. Run setup: `cipher setup`
3. Install this extension
4. Set `cipher.pythonPath` in VS Code settings if Python is not on PATH

## Extension Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `cipher.pythonPath` | `python` | Path to Python with cipher-security |
| `cipher.backend` | `ollama` | LLM backend (ollama, claude, litellm) |
| `cipher.defaultMode` | `AUTO` | Default operating mode |

## Development

```bash
cd vscode/
npm install
npm run compile
# Press F5 in VS Code to launch Extension Development Host
```

## Packaging

```bash
npm run package
# Produces cipher-security-0.1.0.vsix
```
