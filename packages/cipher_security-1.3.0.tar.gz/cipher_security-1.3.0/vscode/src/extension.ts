// Copyright (c) 2026 defconxt. All rights reserved.
// Licensed under AGPL-3.0 — see LICENSE file for details.

/**
 * CIPHER VS Code Extension — Security Engineering Assistant
 *
 * Provides a sidebar chat panel for interacting with CIPHER's gateway.
 * Queries are sent to the cipher-gw CLI subprocess and responses are
 * rendered in a webview with mode-colored headers.
 */

import * as vscode from 'vscode';
import { CipherSidebarProvider } from './sidebar';
import { CipherGateway } from './gateway';

let gateway: CipherGateway;

export function activate(context: vscode.ExtensionContext) {
    gateway = new CipherGateway(context);

    // Register sidebar webview provider
    const sidebarProvider = new CipherSidebarProvider(context, gateway);
    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider('cipher.chatView', sidebarProvider)
    );

    // cipher.query — open input box and send query
    context.subscriptions.push(
        vscode.commands.registerCommand('cipher.query', async () => {
            const query = await vscode.window.showInputBox({
                prompt: 'CIPHER Security Query',
                placeHolder: 'e.g. how do I detect Kerberoasting',
            });
            if (query) {
                sidebarProvider.sendQuery(query);
            }
        })
    );

    // cipher.querySelection — analyze selected code
    context.subscriptions.push(
        vscode.commands.registerCommand('cipher.querySelection', async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor) {
                vscode.window.showWarningMessage('No active editor');
                return;
            }

            const selection = editor.document.getText(editor.selection);
            if (!selection) {
                vscode.window.showWarningMessage('No text selected');
                return;
            }

            const language = editor.document.languageId;
            const prompt = `[MODE: ARCHITECT] Analyze this ${language} code for security issues:\n\n\`\`\`${language}\n${selection}\n\`\`\``;
            sidebarProvider.sendQuery(prompt);
        })
    );

    // cipher.setMode — pick operating mode
    context.subscriptions.push(
        vscode.commands.registerCommand('cipher.setMode', async () => {
            const modes = ['AUTO', 'RED', 'BLUE', 'PURPLE', 'PRIVACY', 'RECON', 'INCIDENT', 'ARCHITECT'];
            const mode = await vscode.window.showQuickPick(modes, {
                placeHolder: 'Select CIPHER operating mode',
            });
            if (mode) {
                await vscode.workspace.getConfiguration('cipher').update('defaultMode', mode, true);
                vscode.window.showInformationMessage(`CIPHER mode: ${mode}`);
            }
        })
    );

    // cipher.setBackend — pick LLM backend
    context.subscriptions.push(
        vscode.commands.registerCommand('cipher.setBackend', async () => {
            const backends = ['ollama', 'claude', 'litellm'];
            const backend = await vscode.window.showQuickPick(backends, {
                placeHolder: 'Select LLM backend',
            });
            if (backend) {
                await vscode.workspace.getConfiguration('cipher').update('backend', backend, true);
                vscode.window.showInformationMessage(`CIPHER backend: ${backend}`);
            }
        })
    );

    // cipher.clearHistory
    context.subscriptions.push(
        vscode.commands.registerCommand('cipher.clearHistory', () => {
            sidebarProvider.clearHistory();
            vscode.window.showInformationMessage('CIPHER history cleared');
        })
    );
}

export function deactivate() {
    gateway?.dispose();
}
