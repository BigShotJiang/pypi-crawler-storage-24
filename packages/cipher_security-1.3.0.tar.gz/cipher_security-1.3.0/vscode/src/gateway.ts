// Copyright (c) 2026 defconxt. All rights reserved.
// Licensed under AGPL-3.0 — see LICENSE file for details.

/**
 * CIPHER Gateway — subprocess bridge to cipher CLI.
 *
 * Spawns cipher as a child process for each query, captures stdout,
 * and returns the response. Uses the configured Python path and backend.
 */

import * as vscode from 'vscode';
import { execFile } from 'child_process';

export interface CipherResponse {
    mode: string;
    text: string;
    error?: string;
}

export class CipherGateway {
    private context: vscode.ExtensionContext;

    constructor(context: vscode.ExtensionContext) {
        this.context = context;
    }

    /**
     * Send a query to CIPHER and return the response.
     *
     * Uses the configured pythonPath to run `python -m gateway.app query`.
     * Falls back to `cipher` CLI if available.
     */
    async send(message: string): Promise<CipherResponse> {
        const config = vscode.workspace.getConfiguration('cipher');
        const pythonPath = config.get<string>('pythonPath', 'python');
        const backend = config.get<string>('backend', 'ollama');
        const defaultMode = config.get<string>('defaultMode', 'AUTO');

        // Prepend mode prefix if not AUTO and not already present
        let query = message;
        if (defaultMode !== 'AUTO' && !message.startsWith('[MODE:')) {
            query = `[MODE: ${defaultMode}] ${message}`;
        }

        const args = ['-m', 'gateway.cli', 'send', '--backend', backend, query];

        return new Promise<CipherResponse>((resolve) => {
            execFile(pythonPath, args, { timeout: 120_000 }, (error, stdout, stderr) => {
                if (error) {
                    const errMsg = stderr?.trim() || error.message;
                    resolve({
                        mode: 'ERROR',
                        text: errMsg,
                        error: errMsg,
                    });
                    return;
                }

                const text = (stdout || '').trim();
                const mode = this.extractMode(text);
                resolve({ mode, text });
            });
        });
    }

    /**
     * Send a query and stream tokens via callback.
     *
     * Note: True streaming requires the subprocess to flush stdout
     * incrementally. cipher-gw currently outputs the full response
     * at once, so this behaves like send() but calls onToken with
     * the complete response. Future: switch to a websocket or
     * line-buffered protocol for real streaming.
     */
    async sendStream(message: string, onToken: (token: string) => void): Promise<CipherResponse> {
        const response = await this.send(message);
        if (!response.error) {
            onToken(response.text);
        }
        return response;
    }

    private extractMode(text: string): string {
        const match = text.match(/\[MODE:\s*(\w+)\]/);
        return match ? match[1] : 'ARCHITECT';
    }

    dispose() {
        // No persistent resources to clean up
    }
}
