// Copyright (c) 2026 defconxt. All rights reserved.
// Licensed under AGPL-3.0 — see LICENSE file for details.

/**
 * CIPHER Sidebar — Webview chat panel for the VS Code sidebar.
 *
 * Renders a cyberpunk-themed chat interface with mode-colored headers,
 * markdown rendering, and persistent history within the session.
 */

import * as vscode from 'vscode';
import { CipherGateway, CipherResponse } from './gateway';

export class CipherSidebarProvider implements vscode.WebviewViewProvider {
    public static readonly viewType = 'cipher.chatView';

    private view?: vscode.WebviewView;
    private gateway: CipherGateway;
    private history: Array<{ role: string; content: string; mode?: string }> = [];

    constructor(
        private readonly context: vscode.ExtensionContext,
        gateway: CipherGateway
    ) {
        this.gateway = gateway;
    }

    resolveWebviewView(
        webviewView: vscode.WebviewView,
        _context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken
    ) {
        this.view = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
        };

        webviewView.webview.html = this.getHtml();

        // Handle messages from the webview
        webviewView.webview.onDidReceiveMessage(async (message) => {
            switch (message.command) {
                case 'query':
                    await this.sendQuery(message.text);
                    break;
                case 'clear':
                    this.clearHistory();
                    break;
            }
        });
    }

    async sendQuery(query: string) {
        if (!this.view) {
            // Ensure the sidebar is visible
            await vscode.commands.executeCommand('cipher.chatView.focus');
            // Wait a beat for the view to initialize
            await new Promise(r => setTimeout(r, 200));
        }

        // Show user message
        this.history.push({ role: 'user', content: query });
        this.postMessage({ command: 'addMessage', role: 'user', text: query });
        this.postMessage({ command: 'showLoading' });

        try {
            const response: CipherResponse = await this.gateway.send(query);
            this.history.push({
                role: 'assistant',
                content: response.text,
                mode: response.mode,
            });
            this.postMessage({
                command: 'addResponse',
                text: response.text,
                mode: response.mode,
                error: response.error,
            });
        } catch (err: any) {
            this.postMessage({
                command: 'addResponse',
                text: `Error: ${err.message}`,
                mode: 'ERROR',
                error: err.message,
            });
        }

        this.postMessage({ command: 'hideLoading' });
    }

    clearHistory() {
        this.history = [];
        this.postMessage({ command: 'clear' });
    }

    private postMessage(message: any) {
        this.view?.webview.postMessage(message);
    }

    private getHtml(): string {
        return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
:root {
    --bg: #0a0a0a;
    --surface: #0d1117;
    --border: #1a1f2e;
    --text: #c9d1d9;
    --text-dim: #5a6480;
    --accent: #00ff41;
    --red: #ff2d2d;
    --blue: #2d9bff;
    --purple: #9b59b6;
    --green: #27ae60;
    --orange: #f39c12;
    --incident: #e74c3c;
    --architect: #3498db;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
    font-size: 13px;
    line-height: 1.6;
    padding: 0;
    display: flex;
    flex-direction: column;
    height: 100vh;
}

#messages {
    flex: 1;
    overflow-y: auto;
    padding: 12px;
}

.message {
    margin-bottom: 16px;
    padding: 8px 12px;
    border-radius: 4px;
}

.message.user {
    background: #161b22;
    border-left: 3px solid var(--accent);
}

.message.user::before {
    content: '> ';
    color: var(--accent);
    font-weight: bold;
}

.message.assistant {
    background: var(--surface);
    border-left: 3px solid var(--border);
}

.message.error {
    background: #1a0a0a;
    border-left: 3px solid var(--red);
    color: var(--red);
}

.mode-header {
    font-weight: bold;
    margin-bottom: 4px;
    font-size: 12px;
}

.mode-RED .mode-header { color: var(--red); }
.mode-BLUE .mode-header { color: var(--blue); }
.mode-PURPLE .mode-header { color: var(--purple); }
.mode-PRIVACY .mode-header { color: var(--green); }
.mode-RECON .mode-header { color: var(--orange); }
.mode-INCIDENT .mode-header { color: var(--incident); }
.mode-ARCHITECT .mode-header { color: var(--architect); }
.mode-ERROR .mode-header { color: var(--red); }

.response-body {
    white-space: pre-wrap;
    word-wrap: break-word;
}

.response-body code {
    background: #161b22;
    padding: 1px 4px;
    border-radius: 3px;
    font-size: 12px;
}

.response-body pre {
    background: #161b22;
    padding: 8px 12px;
    border-radius: 4px;
    overflow-x: auto;
    margin: 8px 0;
}

.loading {
    color: var(--accent);
    font-style: italic;
    padding: 8px 12px;
    animation: pulse 1.5s ease-in-out infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
}

#input-area {
    padding: 8px 12px;
    background: var(--surface);
    border-top: 1px solid var(--border);
}

#query-input {
    width: 100%;
    background: #161b22;
    color: var(--accent);
    border: 1px solid var(--accent);
    border-radius: 4px;
    padding: 8px 12px;
    font-family: inherit;
    font-size: 13px;
    outline: none;
}

#query-input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 1px var(--accent);
}

#query-input::placeholder {
    color: var(--text-dim);
}

.welcome {
    color: var(--text-dim);
    text-align: center;
    padding: 20px;
    font-size: 12px;
}

.welcome .logo {
    color: var(--accent);
    font-size: 14px;
    font-weight: bold;
    margin-bottom: 12px;
}

.separator {
    border: none;
    border-top: 1px solid var(--border);
    margin: 4px 0;
}
</style>
</head>
<body>

<div id="messages">
    <div class="welcome">
        <div class="logo">⟐ CIPHER ⟐</div>
        <p>Security Engineering Assistant</p>
        <p style="margin-top: 8px;">
            Type a query below or right-click selected code<br>
            to analyze it for security issues.
        </p>
        <p style="margin-top: 8px; font-size: 11px;">
            Ctrl+Shift+C to open query input
        </p>
    </div>
</div>

<div id="input-area">
    <input type="text" id="query-input" placeholder="Enter security query..." autofocus />
</div>

<script>
const vscode = acquireVsCodeApi();
const messagesEl = document.getElementById('messages');
const inputEl = document.getElementById('query-input');
let welcomeRemoved = false;

function removeWelcome() {
    if (!welcomeRemoved) {
        const welcome = messagesEl.querySelector('.welcome');
        if (welcome) welcome.remove();
        welcomeRemoved = true;
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function addUserMessage(text) {
    removeWelcome();
    const div = document.createElement('div');
    div.className = 'message user';
    div.textContent = text;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
}

function addResponse(text, mode, error) {
    removeWelcome();
    // Remove loading indicator
    const loading = messagesEl.querySelector('.loading');
    if (loading) loading.remove();

    const div = document.createElement('div');
    div.className = 'message assistant mode-' + (mode || 'ARCHITECT');

    if (error) {
        div.className = 'message error';
        div.textContent = text;
    } else {
        // Parse mode header and body
        const lines = text.split('\\n');
        let headerLine = '';
        let bodyLines = lines;

        if (lines[0] && lines[0].startsWith('[MODE:')) {
            headerLine = lines[0];
            bodyLines = lines.slice(1);
        }

        if (headerLine) {
            const header = document.createElement('div');
            header.className = 'mode-header';
            header.textContent = headerLine;
            div.appendChild(header);
        }

        const body = document.createElement('div');
        body.className = 'response-body';
        body.textContent = bodyLines.join('\\n');
        div.appendChild(body);
    }

    messagesEl.appendChild(div);
    const sep = document.createElement('hr');
    sep.className = 'separator';
    messagesEl.appendChild(sep);
    messagesEl.scrollTop = messagesEl.scrollHeight;
}

function showLoading() {
    removeWelcome();
    const div = document.createElement('div');
    div.className = 'loading';
    div.textContent = '⟐ Thinking...';
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
}

function hideLoading() {
    const loading = messagesEl.querySelector('.loading');
    if (loading) loading.remove();
}

// Handle messages from the extension
window.addEventListener('message', (event) => {
    const msg = event.data;
    switch (msg.command) {
        case 'addMessage':
            if (msg.role === 'user') addUserMessage(msg.text);
            break;
        case 'addResponse':
            addResponse(msg.text, msg.mode, msg.error);
            break;
        case 'showLoading':
            showLoading();
            break;
        case 'hideLoading':
            hideLoading();
            break;
        case 'clear':
            messagesEl.innerHTML = '<div class="welcome"><div class="logo">⟐ CIPHER ⟐</div><p>History cleared.</p></div>';
            welcomeRemoved = false;
            break;
    }
});

// Handle input submission
inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && inputEl.value.trim()) {
        vscode.postMessage({ command: 'query', text: inputEl.value.trim() });
        inputEl.value = '';
    }
});
</script>

</body>
</html>`;
    }
}
