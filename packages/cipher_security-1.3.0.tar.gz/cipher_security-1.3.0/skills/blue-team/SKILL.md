<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# SKILL: Blue Team / Defensive Security

## Activation
Triggered when the operator asks about detection engineering, SIEM rules, log analysis,
incident triage, threat hunting, endpoint security, security monitoring, hardening,
CIS benchmarks, auditd, Sigma rules, Suricata, Zeek, vulnerability management, or
defensive architecture.

## Quick Reference
- Sigma rule convert: `sigma convert -t splunk -p sysmon rules/proc_creation_win_cmd_net_user.yml`
- Auditd suspicious process: `ausearch -k exec_priv --start today -i`
- Check failed logins: `ausearch -m USER_LOGIN --start today | grep -i fail`
- Syslog auth failures: `grep "Failed password" /var/log/auth.log | awk '{print $11}' | sort | uniq -c | sort -rn`
- CrowdSec ban list: `cscli decisions list`; add manual ban: `cscli decisions add -i 1.2.3.4 -t ban -d 24h`
- Check SUID binaries: `find / -perm -4000 -type f 2>/dev/null` — compare against expected baseline
- Verify sysctl hardening: `sysctl -a | grep -E "rp_filter|syncookies|log_martians|accept_redirects"`
- Detect scan in Zeek: `cat /var/log/zeek/conn.log | zeek-cut id.orig_h proto duration | awk '$3 < 0.01' | sort | uniq -c | sort -rn`
- UFW log check: `grep UFW /var/log/ufw.log | grep -v DPT=22 | tail -50`
- AIDE integrity check: `/usr/bin/aide --config /etc/aide/aide.conf --check`
- CIS audit (Ansible): `ansible-playbook -l target ansible-cis-ubuntu-2204/site.yml --check`
- List listening services: `ss -tlnp` — map every port to approved service inventory
- Suricata test rule: `suricata -T -c /etc/suricata/suricata.yaml`

## Competencies

### Detection Engineering

Write Sigma rules as primary output. Translate to SPL/KQL/EQL on request.

```yaml
# Sigma rule template — annotated
title: Suspicious Net User Enumeration
id: abc12345-...
status: stable
description: Detects local user enumeration via net user
logsource:
  category: process_creation
  product: windows
detection:
  selection:
    Image|endswith: '\net.exe'
    CommandLine|contains: 'user'
  condition: selection
falsepositives:
  - IT admin scripts, helpdesk tooling
level: medium
tags:
  - attack.discovery
  - attack.t1087.001
```

Rule quality rubric: FP rate, data source availability, ATT&CK mapping, detection coverage vs. evasion.

Key Sigma logsources:
- `process_creation/windows` → Sysmon EID 1 / Windows EID 4688 (with command line auditing)
- `network_connection/windows` → Sysmon EID 3
- `file_change/linux` → auditd `-w /etc/passwd -p wa -k passwd_changes`
- `authentication/linux` → `/var/log/auth.log`, PAM events

Convert to SIEM targets:
```bash
sigma convert -t splunk -p splunk_cim rules/
sigma convert -t elastic -p ecs_windows rules/
sigma convert -t qradar rules/
```

**Anti-pattern:** Writing a rule that fires on `cmd.exe` with no additional context — every Windows machine runs cmd.exe. Pivot on `ParentImage`, `CommandLine` content, or process lineage.

### Log Analysis and Correlation

Windows Event Log critical IDs:
- **4624/4625** — logon success/failure; correlate 4625 bursts for spray detection
- **4648** — explicit credential use (RunAs, network logon with alternate creds)
- **4688** — process creation (requires audit policy: `auditpol /set /subcategory:"Process Creation" /success:enable`)
- **4698/4702** — scheduled task created/modified
- **4720/4726** — user account created/deleted
- **4732/4733** — member added/removed from security group
- **4768/4769/4771** — Kerberos TGT/TGS request/pre-auth failure (Kerberoast: 4769 with RC4 encryption)
- **7045** — new service installed
- **1102** — audit log cleared

Sysmon key event IDs:
- **1** process create (Image, CommandLine, ParentImage, Hashes)
- **3** network connection (DestinationIp, DestinationPort, Image)
- **7** image loaded (DLL load — detect DLL sideloading, reflective injection)
- **8** CreateRemoteThread (process injection)
- **10** ProcessAccess (LSASS access: TargetImage=lsass.exe)
- **11/12/13** file create, registry key create/value set
- **22** DNS query

Linux auditd critical rules:
```bash
# /etc/audit/rules.d/hardening.rules
-w /etc/passwd -p wa -k passwd_changes
-w /etc/shadow -p wa -k shadow_changes
-w /etc/sudoers -p wa -k sudoers_changes
-w /etc/ssh/sshd_config -p wa -k sshd_config_changes
-a always,exit -F arch=b64 -S execve -F euid=0 -k root_exec
-a always,exit -F arch=b64 -S open,openat -F exit=-EACCES -k access_denied
-w /var/log/faillog -p wa -k login_failures
# Reload: augenrules --load
```

Cloud audit:
- **AWS CloudTrail**: `ConsoleLogin` events, `AssumeRole`, `CreateUser`, `AttachUserPolicy`, `RunInstances`. Alert on `errorCode: AccessDenied` bursts.
- **Azure Activity Log**: `Write` operations on RBAC, `Microsoft.Authorization/roleAssignments/write`.
- **GCP Audit**: `iam.serviceAccounts.actAs`, `storage.setIamPolicy`.

**Anti-pattern:** Correlating only failed events — attackers who succeed leave 4624 (success) trails. Hunt for successful logins from new geolocations/ASNs.

### Threat Hunting

Hypothesis-driven hunting framework:

```
Hypothesis: Attacker used scheduled tasks for persistence after initial access
Data source: Windows EID 4698/4702, Sysmon EID 1 (schtasks.exe)
Baseline: Scheduled tasks created in last 30 days vs. approved list
Query (KQL):
  SecurityEvent
  | where EventID in (4698, 4702)
  | where AccountName !in ("SYSTEM", "LOCAL SERVICE")
  | summarize count() by SubjectAccountName, TaskName, bin(TimeGenerated, 1h)
Hit condition: New tasks from non-admin accounts or tasks running from %TEMP%/%AppData%
```

Stack counting pattern (Splunk):
```spl
index=windows EventCode=4688
| stats count by ParentProcessName, Process
| sort -count
| where count < 5  # rare parent-child relationships
```

Frequency analysis — baseline rare processes:
```bash
# Linux: find processes running infrequently
aureport -x --summary | sort -rn | tail -20
```

Hunt hypotheses worth pursuing:
- T1053 scheduled task persistence: new tasks with UNC paths or %TEMP% execution
- T1078 valid accounts: successful logon from user not seen in 30 days
- T1070 indicator removal: event log cleared (1102), auditd disabled
- T1190 exploit public-facing app: web server spawning sh/cmd as child process

**Anti-pattern:** Hunting without a data source inventory first — know which log sources you actually have before writing queries. A missing Sysmon deployment makes process lineage hunts impossible.

### Endpoint Security

EDR telemetry gap analysis against MITRE ATT&CK:
- Technique coverage mapping: `https://mitre-attack.github.io/attack-navigator/` — overlay your detection rules
- Common gaps: T1055 process injection (needs Sysmon EID 8/10), T1070.004 file deletion, T1218 LOLBin execution

Sysmon baseline (SwiftOnSecurity + extensions):
```xml
<!-- Key rule examples -->
<RuleGroup name="ProcessCreate">
  <ProcessCreate onmatch="include">
    <Rule name="Execution from AppData" groupRelation="and">
      <Image condition="contains">\AppData\</Image>
    </Rule>
    <Rule name="LOLBAS" groupRelation="or">
      <Image condition="endswith">\regsvr32.exe</Image>
      <Image condition="endswith">\mshta.exe</Image>
      <Image condition="endswith">\wscript.exe</Image>
    </Rule>
  </ProcessCreate>
</RuleGroup>
<RuleGroup name="ProcessAccess">
  <ProcessAccess onmatch="include">
    <TargetImage condition="endswith">\lsass.exe</TargetImage>
  </ProcessAccess>
</RuleGroup>
```

Verify Sysmon config coverage: `sysmon -c` shows active config; `sysmon-modular` provides ATT&CK-mapped modules.

CrowdSec IPS deployment:
```bash
# Install and enroll
apt install crowdsec && cscli hub update
# Install collections (scenarios + parsers)
cscli collections install crowdsecurity/linux
cscli collections install crowdsecurity/sshd
cscli collections install crowdsecurity/nginx
# Add bouncer (actual blocking)
apt install crowdsec-firewall-bouncer-nftables
# Verify decisions
cscli decisions list
# Community blocklist (requires cscli lapi register)
cscli capi register
```

CrowdSec acquisition config (`/etc/crowdsec/acquis.yaml`):
```yaml
filenames:
  - /var/log/auth.log
  - /var/log/nginx/access.log
labels:
  type: syslog
---
filenames:
  - /var/log/nginx/access.log
labels:
  type: nginx
```

**Anti-pattern:** Deploying CrowdSec without bouncers — it detects but doesn't block. Always pair with firewall bouncer.

### Network Security Monitoring

Suricata rule syntax and deployment:
```yaml
# /etc/suricata/suricata.yaml key settings
af-packet:
  - interface: eth0
    threads: 4
    cluster-id: 99
    cluster-type: cluster_flow
default-log-dir: /var/log/suricata/
outputs:
  - eve-log:
      enabled: yes
      filetype: regular
      filename: eve.json
      types:
        - alert
        - http
        - dns
        - tls
```

Suricata rule example (lateral movement detection):
```
alert tcp $HOME_NET any -> $HOME_NET 445 (msg:"ET POLICY SMB2 NT_TRANSACT_RENAME attempt"; flow:established,to_server; content:"|FF|SMB"; offset:4; depth:4; content:"|A0 00|"; distance:56; within:2; sid:2010252; rev:3;)
```

Zeek log analysis:
```bash
# Detect port scans (many unique destination ports from single source)
cat /var/log/zeek/conn.log | zeek-cut id.orig_h id.resp_p proto | sort | uniq | awk '{print $1}' | sort | uniq -c | sort -rn | head -20
# Find long DNS TXT records (potential C2 tunneling)
cat /var/log/zeek/dns.log | zeek-cut query answers | awk 'length($2) > 100'
# TLS without SNI (C2 traffic pattern)
cat /var/log/zeek/ssl.log | zeek-cut id.orig_h id.resp_h server_name | awk '$3 == "-"'
# Detect beaconing (regular intervals)
cat /var/log/zeek/conn.log | zeek-cut ts id.orig_h id.resp_h | awk '{print $2,$3,$4}' | sort | uniq -c
```

DNS security:
- RPZ (Response Policy Zones): block known malicious domains at resolver
- Passive DNS: `zeek-cut query` → correlate new/rare domains against registration date
- DGA detection: entropy analysis on domain names — `cat dns.log | zeek-cut query | python3 -c "import sys,math; [print(d, -sum(d.count(c)/len(d)*math.log2(d.count(c)/len(d)) for c in set(d))) for d in sys.stdin]"`

**Anti-pattern:** IDS rules without tuning — a Suricata ruleset with default community rules generates thousands of alerts/day. Start with ET-OPEN + local rules for your stack, suppress known benign.

### Vulnerability Management

Prioritization workflow:
1. CISA KEV (Known Exploited Vulnerabilities) — patch within KEV mandated timeframes regardless of CVSS
2. EPSS > 0.1 AND CVSS ≥ 7.0 — high exploitability risk
3. CVSS ≥ 9.0 internet-exposed — critical regardless of EPSS
4. Everything else — risk-accept or schedule maintenance window

CVSS vector example (parsing):
```
CVE-2024-1234: CVSS 9.8 (AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H)
AV:N = network-reachable, AC:L = no special conditions, PR:N = no auth needed
→ Remote unauthenticated RCE: patch immediately
```

Scan and verify:
```bash
# OpenVAS/Greenbone
gvm-cli --gmp-username admin --gmp-password pass tls --hostname localhost create-task --name "CIS Audit" --target-id <id>
# Nuclei targeted scan
nuclei -u https://target -t cves/ -severity critical,high -o findings.txt
# Verify patch applied
dpkg -l <package> | grep ^ii  # Debian
rpm -q <package>              # RHEL
```

Asset criticality weighting: internet-facing > data store > authentication > internal.

SLA definitions: Critical = 24h; High = 7d; Medium = 30d; Low = 90d.

**Anti-pattern:** CVSS-only prioritization — a CVSS 9.8 vuln in an isolated dev environment is lower priority than a CVSS 7.0 in internet-facing auth service. Always apply asset context.

### Identity Security

Zero trust access model:
- Never trust network location — authenticate every connection regardless of source
- Enforce MFA: FIDO2/passkeys > TOTP > push notifications > SMS (in order of phishing resistance)
- Conditional access: device compliance check + risk score before access grant

Privileged access management (PAM) hardening:
```bash
# PAM faillock config — /etc/security/faillock.conf (CIS 5.3.1)
deny = 5                # lockout after 5 failures
unlock_time = 900       # 900s = 15min lockout
fail_interval = 900     # failures counted within 900s window
even_deny_root = yes    # root account also subject to lockout

# Password quality — /etc/security/pwquality.conf (CIS 5.3.2)
minlen = 14
minclass = 3
dcredit = -1
ucredit = -1
lcredit = -1
ocredit = -1
maxrepeat = 3
maxsequence = 3
difok = 2

# Password history — /etc/pam.d/common-password
password required pam_pwhistory.so remember=24 enforce_for_root use_authtok

# Password aging — /etc/login.defs
PASS_MAX_DAYS 365
PASS_MIN_DAYS 1
PASS_WARN_AGE 7
INACTIVE = 45   # days after expiry before account disabled
```

UMASK enforcement (CIS 5.4.2.6):
```bash
# /etc/profile.d/umask.sh
umask 027   # default: new files = 640, new dirs = 750
# /etc/login.defs
UMASK 027
# Session timeout (CIS 5.4.3.2)
TMOUT=900   # auto-logout after 15min of inactivity
readonly TMOUT
export TMOUT
```

Service account hygiene:
- Disable interactive login: `usermod -s /sbin/nologin svcaccount`
- Rotate API keys/tokens: 90-day rotation policy minimum
- Audit unused accounts: `lastlog | grep "Never logged in"` → review and disable

JIT access: request-approve-grant-expire cycle. Bastion host or PAM solutions (CyberArk, HashiCorp Vault) for privileged sessions.

**Anti-pattern:** MFA on web portal but not on VPN/SSH — attackers bypass the web portal and hit SSH directly. MFA everywhere or it's theater.

### Security Architecture

CIS benchmark hardening — Ubuntu 22.04 (ansible-cis-ubuntu-2204 values):

SSH hardening (`/etc/ssh/sshd_config`, CIS Section 5.1):
```
PermitRootLogin no
MaxAuthTries 4
MaxSessions 10
PubkeyAuthentication yes
PasswordAuthentication no
PermitEmptyPasswords no
AllowAgentForwarding no
AllowTcpForwarding no
X11Forwarding no
TCPKeepAlive no
LoginGraceTime 60
LogLevel VERBOSE
ClientAliveInterval 15
ClientAliveCountMax 3
AddressFamily inet
AuthenticationMethods publickey
Ciphers aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr
MACs hmac-sha2-512,hmac-sha2-256
KexAlgorithms curve25519-sha256@libssh.org,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group-exchange-sha256
# File permissions: /etc/ssh/sshd_config = root:root 0600
# Private host keys = 0600, public = 0644
```

Kernel sysctl hardening (`/etc/sysctl.d/99-sysctl.conf`):
```ini
# Network hardening
net.ipv4.ip_forward = 0
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.conf.all.log_martians = 1
net.ipv4.conf.default.log_martians = 1
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.icmp_ignore_bogus_error_responses = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_timestamps = 0
net.ipv4.tcp_rfc1337 = 1
net.ipv6.conf.all.accept_source_route = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.all.accept_ra = 0
# Kernel hardening
kernel.randomize_va_space = 2
kernel.kptr_restrict = 2
kernel.kexec_load_disabled = 1
kernel.yama.ptrace_scope = 1
kernel.sysrq = 0
# Filesystem protection
fs.protected_hardlinks = 1
fs.protected_symlinks = 1
fs.protected_fifos = 1
fs.protected_regular = 2
fs.suid_dumpable = 0
```

File permission targets:
```bash
chmod 0600 /etc/shadow /etc/gshadow
chmod 0644 /etc/passwd /etc/group
chmod 0700 /root /home/*
chmod 0600 /etc/ssh/sshd_config
chmod 0400 /etc/sudoers
chmod 0600 /etc/cron.{daily,weekly,monthly,d,hourly}/*
chmod 0700 /etc/cron.{daily,weekly,monthly,d,hourly}
```

Disable unnecessary kernel modules (CIS 1.1.1):
```bash
# /etc/modprobe.d/blacklist-cis.conf
install cramfs /bin/false
install freevxfs /bin/false
install hfs /bin/false
install hfsplus /bin/false
install jffs2 /bin/false
install usb-storage /bin/false
```

AIDE file integrity monitoring:
```bash
# Initialize: aideinit; cp /var/lib/aide/aide.db.new /var/lib/aide/aide.db
# Daily cron check (CIS 6.3.2):
0 5 * * * root /usr/bin/aide --config /etc/aide/aide.conf --check
```

Logging architecture: collect → forward → retain.
- Journald: `SystemMaxUse=4G`, `MaxFileSec=1month`, `SystemKeepFree=8G`
- Auditd backlog: `max_log_file = 8` (MB), `max_log_file_action = keep_logs`, `disk_full_action = halt`
- Remote forwarding: rsyslog/journald-remote → centralized SIEM. Rotation at source; retain 90d online, 1yr cold.

**Anti-pattern:** Sending all logs to SIEM without pre-filtering — a noisy Windows domain controller generates 50GB/day of 4624 logon events. Pre-filter at source (Winlogbeat processors), normalize, then forward only high-signal events.

## Key Chains

### Detection to Response: Lateral Movement via Pass-the-Hash
1. Suricata/Zeek fires on SMB authentication anomaly (new source→dest pair, off-hours)
2. Correlate in SIEM: Windows EID 4624 Type 3 (network logon) from non-standard workstation
3. Verify in Sysmon: EID 10 on lsass.exe from suspicious process (credential dump)
4. Hunt backwards: EID 4688 — what spawned the credential dumper? (parent = Word.exe = phishing)
5. Contain: isolate host at switch port (VLAN move) or via EDR network isolation
6. Preserve: pull memory dump before eradication (`winpmem_x64.exe -o mem.raw`)
7. Eradicate: kill persistent implant (scheduled task EID 4698 trace), reset compromised credentials
8. Update detection: new Sigma rule for the specific parent-child relationship observed

### CIS Hardening Workflow: New Ubuntu 22.04 Server
1. Baseline scan: `ansible-playbook --check -l newhost ansible-cis-ubuntu-2204/site.yml` → see failures
2. Apply SSH hardening first: sshd_config values above, test with `sshd -T | grep -i permit`
3. Apply sysctl: `sysctl -p /etc/sysctl.d/99-sysctl.conf` + verify with `sysctl -a`
4. Apply file permissions: shadow/passwd/sshd_config/cron dirs
5. Configure PAM: faillock.conf + pwquality.conf + password history
6. Deploy auditd: `augenrules --load` + verify `auditctl -l`
7. Configure AIDE: `aideinit` → baseline snapshot
8. Deploy CrowdSec: install + collections + bouncer
9. Re-run Ansible check: verify score improvement

### Threat Hunt: Persistence via Cron (Linux)
1. Hypothesis: attacker installed cron job after initial access via web shell
2. Data sources needed: auditd (`-w /var/spool/cron -p wa -k cron_changes`), `/var/log/auth.log`
3. Query: `ausearch -k cron_changes --start today` → find recent additions
4. Stack count: `crontab -l` for all users; check `/etc/cron.d/`, `/etc/cron.daily/`, `/var/spool/cron/crontabs/`
5. Correlate: what web process was running when the cron change occurred? (auth.log UID mapping)
6. Verify malicious: inspect cron job content — encoded payloads, wget/curl to external IPs, reverse shells
7. Remove: `crontab -r -u www-data`; block C2 IP at firewall
8. Sigma rule: alert on new cron file creation by web service user (auditd syscall + UID check)

---
v1.1 | Validated: 2026-03-13
