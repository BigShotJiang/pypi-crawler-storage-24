<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# SKILL: OSINT and Reconnaissance

## Activation
Triggered when the operator asks about reconnaissance, OSINT, target enumeration,
attack surface discovery, passive intelligence gathering, infrastructure mapping,
username enumeration, Google/GitHub intelligence, subdomain discovery, network
scanning, web content discovery, or cloud asset enumeration.

## Quick Reference
- Subfinder passive: `subfinder -d target.com -silent -all -o subs.txt`
- DNS resolve + filter live: `subfinder -silent -d target.com | dnsx -silent -a -resp`
- HTTP probe pipeline: `cat subs.txt | httpx -silent -sc -title -tech-detect -o live.txt`
- Username enum: `sherlock username --csv --print-found`
- Deep username: `maigret username --html -a` (all 3000+ sites)
- Google intel: `ghunt email target@gmail.com --json out.json`
- GitHub OSINT: `octosuite user targetname --repos --json`
- BBOT full recon: `bbot -t target.com -p subdomain-enum -rf passive`
- BBOT kitchen sink: `bbot -t target.com -p kitchen-sink --allow-deadly`
- Nmap SYN+sV: `nmap -sS -sV -sC -O --top-ports 1000 -T4 -oA output target`
- Nmap NSE vuln: `nmap --script=vuln -p 80,443,8080 target`
- Feroxbuster: `feroxbuster -u http://target.com -w /usr/share/seclists/Discovery/Web-Content/raft-large-files.txt -x php,html,js -r`
- Zone transfer: `dnsx -d target.com -axfr -resp`
- AWS enum: `enumerate-iam.py --access-key $AWS_ACCESS_KEY_ID --secret-key $AWS_SECRET_ACCESS_KEY`
- Certificate transparency: `curl -s "https://crt.sh/?q=%.target.com&output=json" | jq '.[].name_value'`

## Competencies

### Passive Reconnaissance

Certificate transparency: `curl -s "https://crt.sh/?q=%.target.com&output=json" | jq -r '.[].name_value' | sort -u`

DNS passive history: SecurityTrails, DNSDB, Farsight DNSDB — look for historical A records pointing to old IPs, CNAMEs to third-party services that may have been abandoned (subdomain takeover indicators).

WHOIS and registration history: `whois target.com` — note registrar, creation date, nameservers, registrant contact (often redacted but useful for cross-referencing).

Google dorking patterns:
```
site:target.com                          # enumerate indexed pages/subdomains
site:target.com filetype:pdf             # indexed documents
site:target.com inurl:admin              # admin panels
intitle:"index of" site:target.com       # open directories
"target.com" ext:sql | ext:bak | ext:env # leaked backup/config files
```

GitHub dorking: search `org:targetcompany`, `"target.com" password`, `"target.com" api_key`, `"target.com" secret` — look for leaked credentials in public repos and commit history.

Email harvesting: theharvester — `theHarvester -d target.com -b google,bing,linkedin -l 500` — extracts emails, names, subdomains from public sources.

Shodan/Censys: `shodan search hostname:target.com` — discovers internet-facing assets before active scanning. Filter by `org:`, `asn:`, `ssl.cert.subject.cn:target.com`.

Wayback Machine: check archived pages for old endpoints, hidden paths, and tech stack clues. `gau target.com | grep -v "\.js\|\.css\|\.png"` fetches all known URLs.

Breach data: `curl -s "https://haveibeenpwned.com/api/v3/breachedaccount/user@target.com"` — identifies compromised credentials for social engineering context.

**Anti-pattern:** Skipping certificate transparency — CT logs expose subdomains that never appeared in DNS brute-force wordlists, including internal/staging environments with wildcard certs.

### Active Subdomain Enumeration

Subfinder → dnsx → httpx pipeline (canonical):
```bash
# Step 1: passive subdomain discovery
subfinder -d target.com -silent -all -o subs_raw.txt

# Step 2: DNS resolve, filter to live hosts
cat subs_raw.txt | dnsx -silent -a -resp | tee subs_resolved.txt

# Step 3: HTTP probe, tech fingerprint, grab titles
cat subs_resolved.txt | awk '{print $1}' | httpx -silent -sc -title -server -tech-detect -o live_web.txt
```

Subfinder key flags:
- `-all` — uses all sources including passive APIs (slower but more complete)
- `-recursive` — recursive enumeration for `sub.sub.target.com`
- `-cs` — include source names in JSON output (shows which provider found what)
- `-pc provider-config.yaml` — configure API keys for Shodan, SecurityTrails, Chaos, etc.

dnsx key flags:
- `-recon` — query all record types (A, AAAA, CNAME, NS, TXT, MX, SOA, PTR)
- `-axfr` — attempt zone transfer (noisy, but automatic discovery)
- `-rcode noerror` — filter to only responding hosts
- `-cname -resp` — extract CNAME targets (detect third-party orphans for takeover)
- `-asn` — display ASN info per host
- `-wd target.com` — wildcard detection mode

DNS brute-force with wordlist: `dnsx -d target.com -w /usr/share/seclists/Discovery/DNS/n0kovo_subdomains.txt -silent`

BBOT subdomain-enum profile (automated multi-source):
```bash
bbot -t target.com -p subdomain-enum          # full active+passive enum
bbot -t target.com -p subdomain-enum -rf passive   # passive-only (no DNS queries to target)
```

Zone transfer check: `dig @ns1.target.com target.com AXFR` — succeeds on misconfigured nameservers, dumps entire zone.

**Anti-pattern:** Running subdomain brute-force directly against target nameservers — use public resolvers (dnsx uses its own resolver list). Hammering target NS triggers alerts and may result in blacklisting.

### Web Content Discovery

Feroxbuster recursive directory brute-force:
```bash
# Standard web content discovery
feroxbuster -u http://target.com -w /usr/share/seclists/Discovery/Web-Content/raft-large-files.txt -x php,html,js,txt,bak -r --smart-mode

# Deep recursive with custom depth and extensions
feroxbuster -u http://target.com -w /usr/share/seclists/Discovery/Web-Content/directory-list-2.3-big.txt -x php,asp,aspx,jsp -d 3 -t 50

# Filter noise: exclude 404, 403 size-based
feroxbuster -u http://target.com -w raft-medium-dirs.txt --filter-status 404,403

# API-focused discovery
feroxbuster -u http://target.com/api -w /usr/share/seclists/Discovery/Web-Content/api/objects.txt --dont-recurse
```

Wordlist selection strategy:
- Quick: `raft-medium-directories.txt` (100K entries)
- Thorough: `directory-list-2.3-big.txt` + `raft-large-files.txt`
- API: `seclists/Discovery/Web-Content/api/`
- Target-specific: generate from JS/HTML with `cewl -d 2 -m 5 http://target.com`

httpx for URL probing with filtering:
```bash
# Find admin panels and login pages by title
cat hosts.txt | httpx -silent -title -mc 200 -ms "admin\|login\|dashboard"

# Screenshot all live web apps
cat hosts.txt | httpx -silent -screenshot -srd screenshots/

# Find tech stack across all subdomains
cat subs.txt | httpx -silent -tech-detect -json | jq '.tech[]?.name'
```

**Anti-pattern:** Using `gobuster` recursion flag on large wordlists — gobuster doesn't prune dead branches. Feroxbuster's `--smart-mode` and `--auto-tune` avoid this with adaptive concurrency and dead-end detection.

### Network Scanning

Nmap scan patterns:
```bash
# Host discovery (no port scan)
nmap -sn 192.168.1.0/24 -oA discovery

# Fast SYN scan top 1000 ports
nmap -sS --top-ports 1000 -T4 -n -Pn -oA fast_scan target

# Service version + default scripts
nmap -sS -sV -sC -O -T4 -oA svc_scan target

# Full port scan (all 65535)
nmap -sS -p- -T4 -n -Pn -oA full_scan target

# UDP top 20 (slow, run selectively)
nmap -sU --top-ports 20 -T4 target

# Stealth timing (slow/bypass IDS)
nmap -sS -T1 --data-length 24 --randomize-hosts target
```

Nmap NSE script categories:
- `--script=vuln` — runs all vulnerability scripts (CVE checks, common misconfigs)
- `--script=auth` — checks for default/weak credentials on services
- `--script=discovery` — enumerates service information (SNMP MIBs, SMB shares, DNS)
- `--script=brute` — attempts brute-force on services (noisy — use explicitly, not `--script=default`)
- `--script=safe` — non-intrusive scripts safe for production
- `--script=http-enum` — web path enumeration via HTTP (Nikto-like signatures)
- `--script=smb-vuln-*` — SMB vulnerability checks (EternalBlue, MS17-010)
- `--script=ssl-*` — SSL/TLS configuration and cert enumeration

Reconftw active scan config (from reconftw.cfg):
```bash
# Standard active portscan
PORTSCAN_ACTIVE_OPTIONS="--top-ports 200 -sV -n -Pn --open --max-retries 2"
# Deep portscan with vulners NSE
PORTSCAN_DEEP_OPTIONS="--top-ports 1000 -sV -n -Pn --open --max-retries 2 --script vulners"
```

Masscan for fast internet-scale scanning: `masscan -p80,443,8080,8443 192.168.0.0/16 --rate=1000 -oL masscan.out`

**Anti-pattern:** Running `nmap -A` against all targets in scope — `-A` = OS detection + version + scripts + traceroute, extremely noisy. Use `-A` only on confirmed target IPs after scope is established. Flag scope assumptions before scanning.

### OSINT Tooling (Username, People, Social)

Sherlock username enumeration:
```bash
sherlock username --print-found             # show only hits
sherlock username --csv -o results.csv      # CSV output
sherlock username --site Twitter --site GitHub  # target specific sites
sherlock username --timeout 10 --no-color   # CI-friendly
```

Maigret deep username search (3000+ sites):
```bash
maigret username --html                     # rich HTML report
maigret username --pdf                      # PDF report
maigret user1 user2 user3 -a               # multi-username, all sites
maigret username --tags photo,dating        # filter by site category
maigret username --tags us                  # US-specific sites
```

GHunt Google intelligence (requires Google auth via browser extension):
```bash
ghunt login                                 # authenticate (browser extension flow)
ghunt email target@gmail.com --json out.json  # full profile from email
ghunt gaia GAIA_ID --json out.json          # lookup by Google account ID
ghunt drive FILE_URL --json out.json        # file/folder metadata
ghunt geolocate BSSID                       # BSSID geolocation
```

Octosuite GitHub intelligence:
```bash
octosuite user targetname                   # full user profile
octosuite user targetname --repos --page 1 --per-page 100  # enumerate repos
octosuite user targetname --followers --json # follower graph
octosuite repo owner/reponame --commits     # commit history
octosuite org orgname --members --json      # org member enumeration
octosuite search "keyword" --repos          # repo search
```

**Anti-pattern:** Running Sherlock against all 400+ default sites when only needing social media — the `--site` filter cuts runtime from minutes to seconds and reduces OPSEC footprint.

### Cloud Recon

AWS identity and permissions enumeration:
```bash
# Identify caller identity (may log to CloudTrail)
aws sts get-caller-identity

# Stealthy identity check (does NOT log to CloudTrail)
aws sqs list-queues   # error response reveals ARN + account ID

# Enumerate IAM permissions via brute-force (noisy — generates CloudTrail)
enumerate-iam.py --access-key $AWS_ACCESS_KEY_ID --secret-key $AWS_SECRET_ACCESS_KEY --session-token $AWS_SESSION_TOKEN

# EC2 metadata service (from inside EC2 instance)
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/
# Get role name, then:
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/<role-name>

# IMDSv2 (requires token)
TOKEN=$(curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/iam/security-credentials/
```

IAM privilege escalation paths:
- `iam:CreateAccessKey` → create keys for more-privileged user
- `iam:AttachUserPolicy` / `iam:AttachRolePolicy` → attach AdministratorAccess
- `iam:CreatePolicyVersion` → create new version of existing policy with elevated privs
- `iam:AddUserToGroup` → join high-privilege group
- `glue:UpdateDevEndpoint` → inject SSH key, gain shell + role creds

S3 enumeration:
```bash
# Enumerate public buckets via cloud_enum (reconftw uses this)
cloud_enum -k target-company -l output.log

# Check bucket public access
aws s3 ls s3://bucket-name --no-sign-request    # unauthenticated read test
aws s3 cp s3://bucket-name/sensitive.txt . --no-sign-request
```

Azure and GCP metadata:
```bash
# Azure IMDS (requires Metadata header)
curl -H "Metadata: true" "http://169.254.169.254/metadata/instance?api-version=2021-02-01"

# GCP metadata (requires Metadata-Flavor header)
curl -H "Metadata-Flavor: Google" "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token"
```

Subdomain takeover via cloud: check CNAMEs pointing to `*.s3.amazonaws.com`, `*.azurewebsites.net`, `*.cloudapp.azure.com`, `*.github.io` — if the target resource is deleted but DNS still points there, register it and serve content from the target domain.

**Anti-pattern:** Using `sts:GetCallerIdentity` for stealthy AWS recon — it DOES log to CloudTrail. Use SQS ListQueues (errors), which does not log, to passively reveal account ID and ARN.

### Intelligence Products and OPSEC

Recon output structure:
```
Target Summary: org, primary domain, ASN, IP ranges, tech stack
Assets Identified: subdomains [HIGH confidence=DNS resolved], IPs, open ports, web apps
Attack Surface: external-facing services, public S3, exposed admin panels, leaked creds
Key Personnel: emails, usernames, LinkedIn profiles
Technology Stack: web servers, frameworks, CDNs, cloud providers
Intelligence Gaps: areas with low coverage needing active verification
```

Confidence annotations: tag each finding `[HIGH]` (DNS-confirmed/actively probed), `[MEDIUM]` (passive inference), `[LOW]` (single source, unverified).

OPSEC for recon:
- Use residential or datacenter proxies — avoid scanning from attacker-controlled IPs that burn fast
- Rate-limit active tools: `--rate-limit` flags in subfinder/httpx/feroxbuster
- Tor for passive lookups only (CT logs, Shodan queries) — Tor exit nodes are blacklisted from many APIs
- Time-box active scanning: avoid scanning during business hours unless testing incident detection
- Avoid scanning CDN-fronted targets with automated tools — WAFs trigger alerts and IP bans

BBOT scan profiles (automated reconnaissance):
```bash
bbot -t target.com -p subdomain-enum          # subdomain enumeration
bbot -t target.com -p web-basic               # quick web scan
bbot -t target.com -p web-thorough            # aggressive web scan
bbot -t evilcorp.com -p email-enum subdomain-enum spider  # combined email + subdomain + spider
bbot -t target.com -p cloud-enum              # cloud storage enumeration
```

## Key Chains

### Passive-to-Active Recon Pipeline
1. CT log enumeration: `curl -s "https://crt.sh/?q=%.target.com&output=json" | jq -r '.[].name_value' | sort -u > ct_subs.txt`
2. Shodan/Censys passive: query `ssl.cert.subject.cn:target.com` — capture IPs and open ports without touching target
3. Merge all passive sources: subfinder `-all` + CT + Shodan → deduplicated subdomain list
4. DNS resolve and filter live: `dnsx -silent -a -resp` → discard NXDOMAIN/dead hosts
5. HTTP probe: `httpx -sc -title -tech-detect` → identify web apps, login pages, admin panels
6. Targeted active scanning: Nmap `-sV -sC` only against confirmed in-scope IPs
7. Output: structured asset inventory with confidence tags before moving to exploitation

### Full-Scope Recon Workflow (reconftw-style)
1. OSINT phase: WHOIS, Google dorks, GitHub secret scan, email harvest, employee recon
2. Subdomain enumeration: subfinder `-all` + BBOT `subdomain-enum` + DNS brute-force
3. Zone transfer attempt: `dnsx -axfr` — extract entire zone if misconfigured
4. DNS resolution + ASN mapping: `dnsx -recon -asn` → identify hosting providers and IP ranges
5. Web probing: httpx across all resolved subdomains → live web targets
6. Port scanning: Nmap `--top-ports 200 -sV` against all live IPs
7. Web fuzzing: feroxbuster against all live apps with raft-large-files + raft-large-dirs
8. Cloud enumeration: cloud_enum for S3/GCS/Azure blob naming patterns
9. Vulnerability scan: `nuclei -l live_web.txt -severity medium,high,critical`
10. Report: structure as Attack Surface Assessment with prioritized findings

### Username-to-Infrastructure Pivot
1. Initial username: sherlock `--print-found` → map presence across social networks
2. Deep profile: maigret `--html` → extract linked accounts, biographical data, locations
3. Email discovery: find corporate/personal email from LinkedIn + job postings (Hunter.io patterns)
4. Google intel: GHunt email → Google account ID, linked services, photo metadata
5. GitHub intelligence: octosuite user → repos, commit email, organization membership
6. Extract org emails from commits: `git log --format='%ae' | sort -u` in found repos
7. Infrastructure correlation: use discovered IPs from job postings/configs in GitHub → pivot to Shodan
8. Subdomain discovery: feed discovered hostnames to subfinder/dnsx pipeline for full enumeration

---
v1.1 | Validated: 2026-03-13
