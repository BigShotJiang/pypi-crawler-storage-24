<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# SKILL: Security Automation and Scripting

## Activation
Triggered when the operator asks for Ansible playbooks, Terraform IaC, Docker Compose,
Bash/Python security scripts, CI/CD pipeline hardening, secret management, backup automation,
Claude Code hooks/subagents, or infrastructure-as-code security reviews.
Mode: [MODE: ARCHITECT] for IaC design; [MODE: BLUE] for hardening automation.

## Quick Reference
- CIS kernel module disable: `ansible.builtin.lineinfile dest=/etc/modprobe.d/cis.conf line="install cramfs /bin/false"`
- sysctl hardening: `ansible.posix.sysctl name=net.ipv4.conf.all.rp_filter value=1 sysctl_set=true sysctl_file=/etc/sysctl.d/90-hardening.conf`
- sops encrypt (age): `sops --encrypt --age age1... secrets.yaml > secrets.enc.yaml`
- sops decrypt inline: `sops exec-env secrets.enc.yaml 'env'` — inject secrets without writing plaintext
- borgmatic backup: `borgmatic --config /etc/borgmatic/config.yaml create --stats`
- borgmatic restore: `borgmatic extract --archive latest --path /etc/`
- Ansible vault encrypt: `ansible-vault encrypt_string 'secretvalue' --name 'var_name'`
- Ansible vault run: `ansible-playbook site.yml --vault-password-file ~/.vault_pass`
- Terraform security scan: `checkov -d . --framework terraform` / `tfsec .`
- Docker secret inject: `docker secret create db_password ./db_password.txt`
- Pi-hole DNS-over-TLS: `FTLCONF_dns_upstreams: '1.1.1.1#853;1.0.0.1#853'`
- Claude Code security hook: `PreToolUse` — block `rm -rf` and `.env` reads before tool fires
- Subagent enumeration: `claude -p "run nmap scan on 10.0.0.0/24" --model haiku` via `claude` SDK

---

## Competencies

### Ansible (CIS Hardening Automation)

Role structure: `defaults/main.yml` (toggle flags), `tasks/` (idempotent controls), `handlers/` (restart triggers), `vars/` (OS-specific).

**Kernel module hardening (CIS 1.1.1.x):**
```yaml
- name: "CIS 1.1.1.1 | Disable cramfs"
  ansible.builtin.lineinfile:
    dest: /etc/modprobe.d/cis.conf
    regexp: '^install cramfs'
    line: "install cramfs /bin/false"
    state: present
    create: true
    owner: root
    group: root
    mode: "0644"
- community.general.modprobe:
    name: cramfs
    state: absent
  when: ansible_facts['virtualization_type'] != "docker"
```
Blacklist pattern applies to: cramfs, freevxfs, hfs, hfsplus, jffs2, squashfs, udf, usb-storage (CIS 1.1.1.1–1.1.1.8).

**Sysctl security hardening:**
```yaml
- ansible.posix.sysctl:
    name: "{{ item.key }}"
    value: "{{ item.value }}"
    sysctl_set: true
    sysctl_file: /etc/sysctl.d/90-hardening.conf
    state: present
    reload: true
  with_dict:
    fs.protected_hardlinks: 1
    fs.protected_symlinks: 1
    fs.protected_fifos: 1
    fs.protected_regular: 2
    fs.suid_dumpable: 0
    kernel.kptr_restrict: 2
    kernel.kexec_load_disabled: 1
    kernel.randomize_va_space: 2
    kernel.yama.ptrace_scope: 1
    net.ipv4.conf.all.rp_filter: 1
    net.ipv4.conf.default.rp_filter: 1
    net.ipv4.icmp_echo_ignore_broadcasts: 1
    net.ipv4.tcp_syncookies: 1
    net.ipv4.tcp_timestamps: 0
    net.ipv4.ip_forward: 0
    net.ipv6.conf.all.forwarding: 0
```

**SSH hardening role pattern:**
```yaml
- ansible.builtin.template:
    src: opensshd.conf.j2
    dest: /etc/ssh/sshd_config
    mode: "0600"
    owner: root
    group: root
    validate: "sshd -T -C user=root -C host=localhost -C addr=localhost -C lport=22 -f %s"
  notify: Restart sshd
```
Key sshd_config values: `PermitRootLogin no`, `MaxAuthTries 2`, `LoginGraceTime 30s`, `PasswordAuthentication no`, `X11Forwarding no`, `AllowAgentForwarding no`, `MaxSessions 2`, RSA key size 4096.

**UFW firewall (CIS 4.x):** `community.general.ufw: rule=allow to_port=22 protocol=tcp log=true` then `state=enabled default=deny direction=incoming`.

**Logging/audit (CIS 6.x):** Enable `systemd-journald.service`; set `Storage=persistent` in `/etc/systemd/journald.conf` via `lineinfile`. Enable auditd and configure rules for SUID executions, privilege escalation, and file access to `/etc/passwd`.

**User account hardening (os_hardening role defaults):**
`os_auth_pw_max_age: 60`, `os_auth_pw_min_age: 7`, `os_auth_retries: 5`, `os_auth_lockout_time: 600`, `os_remove_additional_root_users: true`, `os_security_suid_sgid_enforce: true`.
Remove insecure packages: `os_security_packages_list: [xinetd, inetd, ypserv, telnet-server, rsh-server, prelink]`.

**Anti-pattern:** Raw `command:` instead of `ansible.posix.sysctl:` — breaks idempotency and `check_mode`.
**Anti-pattern:** Skipping `validate:` on sshd_config template — a bad template locks you out.

---

### Terraform / IaC Security

**Secure IAM policy (least privilege):**
```hcl
resource "aws_iam_policy" "s3_read_only" {
  name   = "s3-read-only-${var.env}"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["s3:GetObject", "s3:ListBucket"]
      Resource = [
        "arn:aws:s3:::${var.bucket_name}",
        "arn:aws:s3:::${var.bucket_name}/*"
      ]
      Condition = {
        StringEquals = { "aws:RequestedRegion" = var.region }
      }
    }]
  })
}
```

**S3 bucket with encryption and blocking:**
```hcl
resource "aws_s3_bucket" "secure" {
  bucket = var.bucket_name
}
resource "aws_s3_bucket_server_side_encryption_configuration" "secure" {
  bucket = aws_s3_bucket.secure.id
  rule { apply_server_side_encryption_by_default { sse_algorithm = "aws:kms" } }
}
resource "aws_s3_bucket_public_access_block" "secure" {
  bucket                  = aws_s3_bucket.secure.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
```

**Security group — deny 0.0.0.0/0 ingress:**
```hcl
resource "aws_security_group_rule" "web_ingress" {
  type        = "ingress"
  from_port   = 443
  to_port     = 443
  protocol    = "tcp"
  cidr_blocks = [var.allowed_cidr]  # never "0.0.0.0/0" for admin ports
  security_group_id = aws_security_group.web.id
}
```

**KMS key with key rotation:**
```hcl
resource "aws_kms_key" "main" {
  description             = "Application encryption key"
  deletion_window_in_days = 30
  enable_key_rotation     = true
  key_usage               = "ENCRYPT_DECRYPT"
  policy = jsonencode({ ... })  # deny * principal, explicit allow list
}
```

**Static analysis:**
```bash
tfsec . --format json | jq '.results[] | select(.severity == "HIGH")'
checkov -d . --framework terraform --check CKV_AWS_18,CKV_AWS_19,CKV_AWS_57
# CKV_AWS_18: S3 logging  CKV_AWS_19: S3 SSE  CKV_AWS_57: no public S3
```

**Terragrunt DRY pattern (environment isolation):**
```
infra/
├── terragrunt.hcl          # root config, remote state backend
├── prod/
│   └── vpc/terragrunt.hcl  # include root + prod-specific vars
└── staging/
    └── vpc/terragrunt.hcl
```
```hcl
# terragrunt.hcl
remote_state {
  backend = "s3"
  config  = { bucket = "tfstate-${local.account_id}", key = "${path_relative_to_include()}/terraform.tfstate", encrypt = true }
}
```

**Anti-pattern:** Hardcoding AWS creds in provider block — use `aws_profile` or IAM role.
**Anti-pattern:** `lifecycle { prevent_destroy = false }` on KMS keys or S3 buckets — accidental destroy = data loss.

---

### Docker / Container Security Automation

**Secure Docker Compose pattern:**
```yaml
services:
  app:
    image: myapp:${VERSION}
    user: "1000:1000"            # non-root
    read_only: true
    tmpfs: [/tmp, /run]
    cap_drop: [ALL]
    cap_add: [NET_BIND_SERVICE]  # only add what's needed
    security_opt: [no-new-privileges:true]
    environment:
      - SECRET_KEY_FILE=/run/secrets/app_key
    secrets: [app_key]
    networks: [internal]
secrets:
  app_key:
    file: ./secrets/app_key.txt
networks:
  internal:
    driver: bridge
    internal: true  # no external access
```

**Pi-hole DNS sinkhole (Docker):**
```yaml
services:
  pihole:
    image: pihole/pihole:latest
    ports: ["53:53/tcp", "53:53/udp", "80:80/tcp"]
    environment:
      TZ: 'UTC'
      FTLCONF_webserver_api_password: '{{ vault_pihole_password }}'
      FTLCONF_dns_upstreams: '1.1.1.1#853;1.0.0.1#853'  # DNS-over-TLS
      FTLCONF_dns_dnssec: 'true'
    volumes: ['pihole_data:/etc/pihole']
    cap_add: [NET_ADMIN]
    restart: unless-stopped
```

**Ansible Docker deployment role pattern:**
```yaml
- name: Install Docker packages
  ansible.builtin.package:
    name: "{{ docker_packages }}"
    state: present
  notify: restart docker

- name: Configure Docker daemon security
  ansible.builtin.copy:
    dest: /etc/docker/daemon.json
    content: |
      {
        "live-restore": true,
        "userland-proxy": false,
        "no-new-privileges": true,
        "log-driver": "json-file",
        "log-opts": { "max-size": "10m", "max-file": "3" }
      }
    mode: "0644"
  notify: restart docker
```

**Trivy image scan integration:**
```bash
trivy image --severity HIGH,CRITICAL --exit-code 1 myapp:latest
trivy fs --security-checks vuln,secret --format json . | jq '.Results[].Vulnerabilities[]'
```

**Anti-pattern:** `cap_add: [SYS_ADMIN]` in production — equivalent to root. Use specific capabilities.
**Anti-pattern:** Mounting the Docker socket into a container — container escape to host root.

---

### Python / Bash Security Scripting

**Impacket: credential extraction over network:**
```python
from impacket.smbconnection import SMBConnection
from impacket.examples.secretsdump import RemoteOperations, SAMHashes

conn = SMBConnection(target_ip, target_ip)
conn.login(username, password, domain)
remote_ops = RemoteOperations(conn, False, None)
remote_ops.enableRegistry()
sam_hashes = SAMHashes(remote_ops.saveSAM(), {}, isRemote=True)
sam_hashes.dump()  # outputs NTLM hashes
```

**Scapy: network discovery/packet crafting:**
```python
from scapy.all import ARP, Ether, srp, IP, ICMP, sr1
# ARP scan: host discovery without ICMP
result, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst="192.168.1.0/24"), timeout=2, verbose=False)
hosts = [(r.psrc, r.hwsrc) for _, r in result]
# TTL OS fingerprinting: 64=Linux, 128=Windows, 255=network device
ttl = sr1(IP(dst=target)/ICMP(), timeout=2, verbose=0).ttl
```

**Paramiko: SSH lateral movement:**
```python
import paramiko
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(hostname, username=user, pkey=paramiko.RSAKey.from_private_key_file(key_path))
_, stdout, _ = client.exec_command('cat /etc/shadow', get_pty=False)
print(stdout.read().decode()); client.close()
```

**Bash: security audit one-liners:**
```bash
# SUID/SGID binary audit
find / -perm /6000 -type f 2>/dev/null | xargs ls -la | tee /tmp/suid_audit.txt

# World-writable files
find / -xdev -type f -perm -002 2>/dev/null | grep -v /proc

# Active listening services with owners
ss -tlnp | awk 'NR>1 {print $4, $6}' | sort -u

# Cron job enumeration
for f in /etc/cron* /var/spool/cron/crontabs/*; do echo "=== $f ==="; cat $f 2>/dev/null; done

# Failed login attempts (brute force detection)
journalctl -u ssh --since "24 hours ago" | grep "Failed password" | awk '{print $11}' | sort | uniq -c | sort -rn | head -20
```

**Python log parser (SIEM-style alerting):**
```python
import re, sys
from pathlib import Path
SUSPICIOUS = [
    (r"Failed password for (\S+) from (\S+)", "SSH_BRUTE"),
    (r"sudo:.+COMMAND=(.+)", "SUDO_EXEC"),
    (r"useradd.*-o.*uid 0", "ROOT_CLONE"),
]
for line in Path("/var/log/auth.log").read_text().splitlines():
    for pat, evt in SUSPICIOUS:
        if re.search(pat, line):
            print(f"[{evt}] {line.strip()}", file=sys.stderr)
```

**Anti-pattern:** `import subprocess; subprocess.run(user_input, shell=True)` — command injection. Use `shlex.split()` and pass list.
**Anti-pattern:** Bare `except:` blocks swallowing paramiko auth failures — masks failed connections as success.

---

### Claude Code Automation (Security Assessments)

**Hooks: security guard gates (`.claude/settings.json`):**
```json
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "Bash",
      "hooks": [{"type": "command", "command": "python3 ~/.claude/hooks/security_guard.py"}]
    }]
  }
}
```

`security_guard.py` pattern — block dangerous operations before execution:
```python
import json, sys, re
data = json.load(sys.stdin)
tool, inp = data["tool_name"], data["tool_input"]
if tool == "Bash":
    cmd = inp.get("command", "")
    blocked = [r'\brm\s+.*-[a-z]*r[a-z]*f', r'chmod\s+777', r'>\s*/etc/']
    for pattern in blocked:
        if re.search(pattern, cmd):
            print(json.dumps({"decision": "block", "reason": f"Blocked: {pattern}"}))
            sys.exit(0)
# allow by default (no output = allow)
```

Hook events: `PreToolUse` (block before), `PostToolUse` (audit after), `UserPromptSubmit` (injection guard), `PermissionRequest` (auto-allow read-only), `Stop` (summary generation).

**Subagent pattern for parallel security enumeration:**
```markdown
---
name: port-scanner
description: PROACTIVELY scan network targets with nmap when given IP ranges
model: haiku
tools: Bash
permissionMode: dontAsk
maxTurns: 5
---
Run `nmap -sV -sC -p- --min-rate 1000 {target}` and return JSON findings.
```
Spawn with `claude -p "enumerate 10.0.0.0/24" --model haiku` or via Task() in orchestrator.

**Orchestration pattern (Command → Agent → Skill):**
`.claude/commands/sec-audit.md` triggers orchestrator → spawns `port-scanner` (haiku + Bash) and `vuln-mapper` (sonnet + Read + Bash) as subagents, each with constrained tools and a preloaded skill.

**Context management:** Follow REASON → PLAN → EXECUTE → ANALYZE → LOOP → REPORT loop per turn. Use `/compact` when context > 80% capacity — engagement state survives compression.

**Anti-pattern:** Single monolithic agent for entire pentest engagement — hits context limits, loses finding state. Split by phase: recon agent → exploitation agent → post-exploitation agent, each passing structured state.
**Anti-pattern:** `permissionMode: bypassPermissions` on agents with Write access — no guard against accidental file destruction during automated assessment.

---

### Secrets Management (SOPS + Ansible Vault)

**SOPS with age (air-gapped friendly):**
```bash
# Generate age key pair
age-keygen -o ~/.config/sops/age/keys.txt  # keep private key offline

# .sops.yaml config in repo root
creation_rules:
  - path_regex: secrets/.*\.yaml$
    age: >-
      age1s3cqcks5genc6ru8chl0hkkd04zmxvczsvdxq99ekffe4gmvjpzsedk23c

# Encrypt new file
sops --encrypt secrets/prod.yaml > secrets/prod.enc.yaml

# Edit encrypted file (opens $EDITOR with plaintext)
SOPS_AGE_KEY_FILE=~/.config/sops/age/keys.txt sops secrets/prod.enc.yaml

# Inject secrets into process env without writing plaintext
sops exec-env secrets/prod.enc.yaml './app --config /etc/app.conf'
```

**SOPS with AWS KMS (CI/CD):** `export SOPS_KMS_ARN="arn:aws:kms:us-east-1:123456789:key/abc-def"` then `sops --encrypt --kms "$SOPS_KMS_ARN" secrets.yaml`. CI decrypts via IAM role — no static keys.

**Ansible Vault rotation:** `ansible-vault rekey --new-vault-password-file ~/.new_vault_pass vault.yml`. Inline value: `ansible-vault encrypt_string 'supersecret' --name 'db_password'`.

**Borgmatic encrypted backup config:**
```yaml
# /etc/borgmatic/config.yaml
source_directories: [/home, /etc, /var/lib/postgresql]
repositories:
  - path: ssh://user@backup.host/./repo
    label: offsite
  - path: /mnt/local/backup.borg
    label: local
encryption_passphrase: "{{ lookup('env', 'BORG_PASSPHRASE') }}"
keep_daily: 7
keep_weekly: 4
keep_monthly: 6
checks: [{name: repository}, {name: archives, frequency: '2 weeks'}]
postgresql_databases: [{name: all}]  # dumps all DBs before backup
before_backup: [systemctl stop myapp]
after_backup: [systemctl start myapp]
```
```bash
borgmatic --config /etc/borgmatic/config.yaml create --stats --list
borgmatic extract --archive latest --path /etc/postgresql/ --destination /tmp/restore/
```

**Anti-pattern:** Committing `.sops.yaml` with plaintext age public keys is fine — the private key never touches the repo.
**Anti-pattern:** Using sops without `creation_rules` path_regex — results in inconsistent key selection across environments.

---

## Key Chains

### Chain 1: CIS Hardening Deployment Pipeline
1. `ansible-inventory --graph -i inventory/` — verify target hosts
2. `ansible-playbook cis-harden.yml --check --diff -i inventory/prod` — preview changes
3. Section 1: kernel modules blacklisted (`cramfs`, `usb-storage`, etc.) via modprobe.d
4. Section 3: sysctl hardened (`rp_filter=1`, `syncookies=1`, `kptr_restrict=2`), wireless blacklisted
5. Section 4: ufw enabled, default deny, SSH allowed from jump host CIDR only
6. Section 5: sshd_config deployed via template with `validate:`, password auth disabled
7. Section 6: auditd started, journald `Storage=persistent`, log file permissions enforced
8. Final `--check`: zero changes = idempotent

### Chain 2: Secure Infrastructure Provisioning (Terraform)
1. `terraform init` — remote state in S3 + KMS, DynamoDB lock table
2. `tfsec . && checkov -d .` — block pipeline on HIGH/CRITICAL before plan
3. `terraform plan -out=tfplan` — review for `0.0.0.0/0` ingress, unencrypted storage, public S3
4. `terraform apply tfplan` — apply behind approval gate (Atlantis or manual review)
5. `aws s3api get-bucket-encryption --bucket name` + `aws iam get-credential-report` — verify posture

### Chain 3: Security Assessment Automation (Claude Code)
1. Write `.claude/commands/sec-assess.md` with target, scope, output format
2. Spawn recon subagent (haiku + Bash): `nmap -sV -sC` → structured JSON findings file
3. Spawn vuln subagent (sonnet + Read + Bash): map services to CVEs, check default creds
4. `PreToolUse` hook blocks `rm -rf` and `.env` access; `PostToolUse` logs all Bash to audit trail
5. Report agent formats findings as FINDING-001 blocks with CVSS + ATT&CK IDs
6. `/compact` if context > 80% — state survives; continue from last REASON block

---
v1.1 | Validated: 2026-03-13
