<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# SKILL: Security Architecture & Threat Modeling

## Activation
Triggered when the operator asks about security architecture, threat modeling, zero trust,
defense-in-depth, blast radius, compensating controls, DFD, trust boundaries, network
segmentation, microsegmentation, reference architectures, cloud security design, identity
fabric, data flow diagrams, STRIDE, DREAD, PASTA, attack surface analysis, or security
design review.

## Quick Reference
- STRIDE per element: Spoofing, Tampering, Repudiation, Info Disclosure, DoS, Elevation of Privilege
- DREAD scoring: Damage, Reproducibility, Exploitability, Affected Users, Discoverability (1-10 each)
- PASTA: 7-stage risk-centric threat model (define objectives → DFD → threat analysis → vuln analysis → attack modeling → risk/impact → countermeasures)
- Threat model tool: `pytm` — `python3 tm.py --dfd | dot -Tpng -o dfd.png`
- OWASP Threat Dragon: `threat-dragon-desktop` or web UI for collaborative DFD + STRIDE
- Microsoft Threat Modeling Tool: `.tm7` files with auto-generated threats per element
- Trust boundary audit: every arrow crossing a boundary needs authn, authz, input validation, encryption
- Attack surface: `sum(entry_points * privilege_level * protocol_complexity)`
- Cloud reference: AWS Well-Architected Security Pillar, Azure Security Benchmark, GCP Security Best Practices

## Competencies

### Zero Trust Architecture

Zero trust is not a product — it is a design philosophy: **never trust, always verify**.

Core principles (NIST SP 800-207):
1. All data sources and computing services are resources
2. All communication is secured regardless of network location
3. Access to individual resources is granted on a per-session basis
4. Access is determined by dynamic policy (identity, device, behavior, environment)
5. Enterprise monitors and measures integrity/security posture of all owned assets
6. Authentication and authorization are dynamic and strictly enforced before access
7. Enterprise collects as much information as possible about network state and uses it to improve security posture

**Implementation layers:**

```
IDENTITY PLANE
├── Identity Provider (Okta, Azure AD, Google Workspace)
├── MFA everywhere — phishing-resistant (FIDO2/WebAuthn, not SMS)
├── Device trust (MDM enrollment, posture check, TPM attestation)
├── Conditional access policies (location, risk score, device compliance)
└── Just-in-time access (PIM/PAM — no standing privileges)

NETWORK PLANE
├── Microsegmentation (per-workload firewall rules, not flat VLANs)
├── Software-defined perimeter (BeyondCorp model, Tailscale/Cloudflare Access)
├── East-west traffic inspection (service mesh mTLS, Cilium, Calico)
├── DNS filtering and monitoring (canary domains, DGA detection)
└── Encrypted transport everywhere (mTLS between services, WireGuard)

DATA PLANE
├── Classification (public, internal, confidential, restricted)
├── Encryption at rest (AES-256, envelope encryption, KMS-managed keys)
├── Encryption in transit (TLS 1.3, mTLS for service-to-service)
├── DLP policies (egress inspection, watermarking, rights management)
└── Tokenization for sensitive fields (PCI DSS, PII handling)

APPLICATION PLANE
├── API gateway with authn/authz (OAuth2 + OIDC, API keys are not auth)
├── Input validation at trust boundary (allowlist > denylist)
├── Rate limiting and circuit breakers (prevent DoS and abuse)
├── Secrets management (Vault, AWS Secrets Manager — never in code)
└── SBOM and dependency scanning (Trivy, Grype, Syft)
```

### Defense-in-Depth Layering

Each layer operates independently — compromise of one does not cascade:

```
Layer 1: PERIMETER       — WAF, DDoS protection, CDN edge rules
Layer 2: NETWORK         — Segmentation, IDS/IPS, flow monitoring
Layer 3: ENDPOINT        — EDR, host firewall, application allowlisting
Layer 4: APPLICATION     — Input validation, AuthN/AuthZ, SAST/DAST
Layer 5: DATA            — Encryption, DLP, access controls, backup
Layer 6: IDENTITY        — MFA, least privilege, PAM, session management
Layer 7: OPERATIONS      — Logging, monitoring, alerting, IR playbooks
```

Control mapping per layer:
- **Preventive**: blocks attack (firewall rule, MFA, input validation)
- **Detective**: identifies attack (SIEM alert, EDR detection, log anomaly)
- **Corrective**: limits damage (auto-isolation, backup restore, credential rotation)
- **Deterrent**: discourages attack (legal notice, honeypot, audit trail)

### Threat Modeling — STRIDE

For every DFD element, assess all six categories:

```
Element Type    | Applicable STRIDE Threats
----------------|--------------------------------------------------
External Entity | Spoofing
Process         | Spoofing, Tampering, Repudiation, Info Disclosure, DoS, EoP
Data Store      | Tampering, Info Disclosure, DoS
Data Flow       | Tampering, Info Disclosure, DoS
Trust Boundary  | (not an element — but every crossing is a threat surface)
```

**STRIDE per interaction** (recommended for complex systems):
For each pair of elements connected by a data flow, enumerate threats at the trust boundary crossing.

Output format:
```
| # | Element | Threat | STRIDE | Description | Mitigation | Priority |
|---|---------|--------|--------|-------------|------------|----------|
| 1 | API GW→DB | SQL Injection | T | Unsanitized user input in queries | Parameterized queries, WAF rules | Critical |
| 2 | User→API | Credential stuffing | S | Automated login attempts | MFA, rate limiting, CAPTCHA | High |
```

### Threat Modeling — PASTA (7 Stages)

1. **Define objectives** — business context, compliance requirements, risk appetite
2. **Define technical scope** — application architecture, DFD, technology stack
3. **Application decomposition** — identify entry points, assets, trust levels
4. **Threat analysis** — enumerate threat agents, attack libraries (ATT&CK, CAPEC)
5. **Vulnerability analysis** — map vulnerabilities to threats (CVE, SAST/DAST findings)
6. **Attack modeling** — build attack trees, identify probable attack paths
7. **Risk and impact analysis** — score by business impact, prioritize countermeasures

### Network Segmentation Patterns

**Flat network** (anti-pattern): everything can talk to everything. One compromised host = full access.

**Zone-based segmentation:**
```
INTERNET ──┬── DMZ (web servers, reverse proxy, WAF)
            ├── APPLICATION ZONE (app servers, API gateways)
            ├── DATA ZONE (databases, file stores, caches)
            ├── MANAGEMENT ZONE (bastion, CI/CD, monitoring)
            └── RESTRICTED ZONE (secrets, HSM, PKI, backup)
```

Rules:
- DMZ can reach APPLICATION on specific ports only (443, gRPC)
- APPLICATION can reach DATA on DB ports only (5432, 3306, 6379)
- DATA cannot initiate outbound connections
- MANAGEMENT accessed only via bastion/VPN with MFA
- RESTRICTED accessed only from MANAGEMENT with break-glass procedure

**Microsegmentation** (zero trust network):
- Per-workload identity (SPIFFE/SPIRE, Kubernetes service accounts)
- mTLS between all services (Istio, Linkerd, Cilium)
- Network policies deny-all by default, allowlist per service pair
- East-west traffic logged and inspected

### Cloud Security Reference Architectures

**AWS landing zone security:**
```
AWS Organization
├── Management Account (SCPs, CloudTrail org trail, GuardDuty delegated admin)
├── Security Account (SecurityHub, Detective, Macie, centralized logging)
├── Log Archive Account (immutable S3 + Glacier, CloudTrail, VPC Flow Logs)
├── Network Account (Transit Gateway, Network Firewall, Route53 Resolver)
├── Shared Services (Active Directory, CI/CD, artifact registry)
├── Workload Accounts (prod, staging, dev — separate accounts per env)
└── Sandbox Accounts (experimentation, no prod data, restricted SCPs)
```

Key controls:
- SCPs deny `iam:CreateUser` with console access (SSO only)
- SCPs deny regions outside approved list
- CloudTrail → S3 (log archive) with object lock (WORM)
- GuardDuty in every account, findings to Security Account
- VPC endpoints for S3/DynamoDB/KMS (no public internet for data plane)

**Kubernetes security architecture:**
```
CLUSTER HARDENING
├── RBAC: least-privilege, no cluster-admin for workloads
├── Network Policies: deny-all default, per-namespace allowlists
├── Pod Security Standards: restricted profile (no privileged, no hostPID)
├── Secrets: external-secrets-operator → Vault/AWS SM (not etcd)
├── Image policy: admission controller (Kyverno/OPA) → signed images only
├── Runtime: Falco for syscall monitoring, seccomp profiles
└── Audit: API server audit logs → SIEM, Falco alerts → PagerDuty
```

### Identity Fabric Design

Modern identity architecture is a mesh, not a hub:

```
USERS ──→ Identity Provider (Okta/Azure AD)
              ├── SSO (SAML 2.0 / OIDC) → SaaS apps
              ├── SCIM provisioning → downstream directories
              ├── Conditional Access → device trust + risk score
              ├── PAM (CyberArk/HashiCorp Vault) → privileged access
              └── FIDO2/Passkeys → phishing-resistant MFA

SERVICE IDENTITIES
├── Kubernetes: ServiceAccount + IRSA (AWS) / Workload Identity (GCP)
├── Cloud: IAM roles (never long-lived keys)
├── CI/CD: OIDC federation (GitHub Actions → AWS, no stored secrets)
└── Machine: mTLS certificates (SPIFFE/SPIRE, cert-manager)
```

Principles:
- Humans use SSO + MFA. Always. No exceptions.
- Services use short-lived credentials (STS, OIDC tokens). Never API keys in env vars.
- Break-glass accounts exist but are monitored (alert on any use).
- Privilege is just-in-time: request → approve → time-bound grant → auto-revoke.

### Security Design Review Checklist

When reviewing an architecture, assess each category:

```
[ ] Authentication — How are identities verified? MFA? Phishing-resistant?
[ ] Authorization — Least privilege? RBAC/ABAC? Regularly reviewed?
[ ] Data protection — Classified? Encrypted at rest and in transit? Key rotation?
[ ] Network controls — Segmented? Microsegmented? East-west inspection?
[ ] Secrets management — Vault/KMS? Rotation? No hardcoded secrets?
[ ] Logging and monitoring — All components log? Centralized? Alerting?
[ ] Incident response — Runbooks exist? Tested? Escalation paths defined?
[ ] Supply chain — Dependencies scanned? SBOM? Signed artifacts?
[ ] Availability — Redundancy? Failover? Backup tested? RTO/RPO defined?
[ ] Compliance — Regulatory requirements mapped? Controls documented?
```

### Blast Radius Analysis

For any proposed change or identified vulnerability, assess:

1. **Scope**: What systems are directly affected?
2. **Lateral reach**: If this is compromised, what else can the attacker reach?
3. **Data exposure**: What data becomes accessible? Classification level?
4. **Privilege level**: What permissions does the attacker gain?
5. **Detection likelihood**: Would current monitoring catch this?
6. **Recovery cost**: How hard is it to restore to known-good state?

Mitigation pattern: **compartmentalization**
- Separate blast zones with hard boundaries (separate accounts, networks, identities)
- Break-glass controls at each boundary
- Independent monitoring per zone (compromise of one zone's SIEM doesn't blind others)
