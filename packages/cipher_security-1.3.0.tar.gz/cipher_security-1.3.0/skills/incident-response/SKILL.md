<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# SKILL: Incident Response

## Activation
Triggered when the operator describes an active incident, asks for IR runbooks,
discusses forensic artifact locations, triage commands, evidence collection,
memory acquisition, Wireshark analysis, containment procedures, timeline
reconstruction, or post-incident analysis. Also triggers on keywords: DFIR,
forensics, triage, IOC, compromise, breach, exfiltration, ransomware response.

## Quick Reference
- Memory (Windows, winpmem): `winpmem_mini_x64.exe mem.raw`
- Memory (Linux, LiME): `insmod lime.ko "path=/tmp/mem.lime format=lime"`
- Memory (Linux, AVML): `avml /tmp/mem.lime`
- Disk image (Linux): `dd if=/dev/sda bs=512 | gzip > disk.img.gz` (hash before/after)
- Hash evidence: `sha256sum mem.raw > mem.raw.sha256`
- Volatile data order: running processes → network connections → logged-in users → loaded modules → ARP cache
- Process list (Linux): `ps auxf && cat /proc/*/status 2>/dev/null | grep -E "Name|Pid|PPid"`
- Network connections: `ss -tulnp` (Linux) / `netstat -anob` (Windows cmd)
- Windows event logs: `wevtutil qe Security /count:1000 /rd:true /format:text`
- Chainsaw (EVTX triage): `chainsaw hunt /path/to/evtx --sigma rules/ --mapping mappings/sigma-event-logs-all.yml`
- Hayabusa (fast EVTX timeline): `hayabusa csv-timeline -d /path/to/evtx -o timeline.csv`
- Volatility process scan: `vol.py -f mem.raw windows.pslist` + `windows.psscan` (finds unlinked)
- Tshark C2 beacon filter: `tshark -r capture.pcap -Y "tcp.flags.syn==1 && !tcp.flags.ack==1" -T fields -e ip.dst | sort | uniq -c | sort -rn`
- Collect IR artifacts (Linux UAC): `./uac -p /tmp/uac-output`

## Competencies

### Volatile Data Collection (Order Matters)

Collect volatile data before ANYTHING else — it evaporates on reboot. NIST 800-86 order:

```bash
# 1. Capture running process list (with full command lines)
ps auxf > /tmp/ir/processes.txt
cat /proc/*/cmdline 2>/dev/null | tr '\0' ' ' | sort -u > /tmp/ir/cmdlines.txt

# 2. Network connections (established + listening)
ss -tulnp > /tmp/ir/netstat.txt
ss -anp > /tmp/ir/all_sockets.txt

# 3. Logged-in users
who -a > /tmp/ir/who.txt
last -F > /tmp/ir/last.txt
lastlog > /tmp/ir/lastlog.txt

# 4. Open files
lsof -nP > /tmp/ir/lsof.txt

# 5. Loaded kernel modules (rootkit check)
lsmod > /tmp/ir/lsmod.txt
cat /proc/modules > /tmp/ir/proc_modules.txt

# 6. ARP cache + routes
arp -an > /tmp/ir/arp.txt
ip route show > /tmp/ir/routes.txt

# 7. Scheduled tasks
crontab -l > /tmp/ir/crontab_user.txt
cat /etc/cron* /var/spool/cron/crontabs/* 2>/dev/null > /tmp/ir/cron_all.txt
systemctl list-timers --all > /tmp/ir/timers.txt
```

Windows volatile collection:
```powershell
# Processes with hashes (for IOC matching)
Get-Process | Select-Object Id,Name,Path,@{N='Hash';E={Get-FileHash $_.Path -EA SilentlyContinue | Select -Expand Hash}} | Export-Csv processes.csv
# Network connections with owning process
Get-NetTCPConnection | Select State,LocalAddress,LocalPort,RemoteAddress,RemotePort,OwningProcess | Export-Csv netconn.csv
# Services (check for unusual binary paths)
Get-WmiObject Win32_Service | Select Name,State,PathName,StartMode | Export-Csv services.csv
# Autoruns (requires Sysinternals autorunsc.exe)
autorunsc.exe -a * -c -h -s > autoruns.csv
```

**Anti-pattern:** Rebooting or running commands that modify atime before volatile collection — reboots destroy memory; atime updates overwrite last-access timestamps that place attacker on the filesystem.

### Memory Acquisition and Analysis

Windows memory acquisition:
```bash
# winpmem (recommended, kernel driver, gets all memory)
winpmem_mini_x64.exe mem.raw
sha256sum mem.raw > mem.raw.sha256

# MAGNET DumpIt
DumpIt.exe /OUTPUT mem.raw
```

Linux memory acquisition:
```bash
# LiME (Loadable Kernel Module — most forensically sound)
# Compile on matching kernel version
make -C /lib/modules/$(uname -r)/build M=$(pwd) modules
insmod lime.ko "path=/tmp/mem.lime format=lime"
sha256sum /tmp/mem.lime

# AVML (Microsoft, static binary, no compile needed)
./avml /tmp/mem.lime

# /dev/mem (legacy, incomplete on modern kernels — avoid)
```

Volatility 3 analysis:
```bash
# Process analysis
vol.py -f mem.lime linux.pslist    # process list
vol.py -f mem.raw windows.pslist  # Windows process list
vol.py -f mem.raw windows.psscan  # scan raw memory (finds unlinked/hidden processes)
vol.py -f mem.raw windows.cmdline # command lines — spot encoded PowerShell
vol.py -f mem.raw windows.malfind # find injected code (RWX regions with PE headers)
vol.py -f mem.raw windows.dlllist --pid 1234  # DLLs loaded by process
vol.py -f mem.raw windows.handles --pid 1234  # open handles
vol.py -f mem.raw windows.netscan  # network connections from memory

# Network
vol.py -f mem.raw windows.netstat  # active + closed connections
vol.py -f mem.raw linux.netstat

# Credential extraction
vol.py -f mem.raw windows.hashdump  # SAM hashes
vol.py -f mem.raw windows.lsadump   # LSA secrets
```

System Informer (live Windows analysis — replaces Process Hacker):
- Process tree with full command lines and parent-child relationships
- Detects hidden/zombie processes via brute-force PID scan + CSR handle enumeration (bypasses EPROCESS.ActiveProcessLinks unlinking)
- Network tab: per-process TCP/UDP connections with remote IP/port — spot C2 without netstat
- Token inspection: per-process token privileges, impersonation level
- Stack traces with kernel-mode + WOW64 support — identify injection via unusual module in call stack
- Handles view: identify process holding a lock or suspicious named pipe
- Services: view binpath for unusual service executables

**Anti-pattern:** Using pslist alone — rootkits unlink EPROCESS.ActiveProcessLinks. Always cross-reference pslist with psscan (raw memory scan finds what pslist misses).

### Forensic Artifact Locations

Windows artifacts (specific paths):
```
Event Logs:    C:\Windows\System32\winevt\Logs\
  Security     : logon/logoff (4624,4634), privesc (4672), account changes (4720,4728)
  System       : service install (7045), driver load (6)
  Application  : application crashes, install events
  Sysmon       : Microsoft-Windows-Sysmon%4Operational.evtx

Prefetch:      C:\Windows\Prefetch\*.pf  (last 8 run times per exe, hash in filename)
Amcache:       C:\Windows\AppCompat\Programs\Amcache.hve  (executed binaries + SHA1)
ShimCache:     HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\AppCompatCache
MFT:           C:\$MFT  (all NTFS metadata — file creation times, full path)
USN Journal:   C:\$Extend\$UsnJrnl:$J  (file system change log)

Registry hives (offline analysis paths):
  SAM:          C:\Windows\System32\config\SAM
  SYSTEM:       C:\Windows\System32\config\SYSTEM
  SOFTWARE:     C:\Windows\System32\config\SOFTWARE
  NTUSER.DAT:   C:\Users\<user>\NTUSER.DAT  (per-user, run keys, typed URLs, recent)
  UsrClass.dat: C:\Users\<user>\AppData\Local\Microsoft\Windows\UsrClass.dat (shellbags)

Run keys (persistence):
  HKCU\Software\Microsoft\Windows\CurrentVersion\Run
  HKLM\Software\Microsoft\Windows\CurrentVersion\Run
  HKLM\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options

Scheduled tasks: C:\Windows\System32\Tasks\ (XML files, check Author + Command)
WMI persistence: C:\Windows\System32\wbem\Repository\  (parse with python-cim)
LNK files:       C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Recent\
Jump Lists:      C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Recent\AutomaticDestinations\
Browser (Chrome): C:\Users\<user>\AppData\Local\Google\Chrome\User Data\Default\History
```

Linux artifacts:
```
Auth logs:       /var/log/auth.log  (Debian) / /var/log/secure  (RHEL)
Syslog:          /var/log/syslog or /var/log/messages
Bash history:    ~/.bash_history  (check for gaps — attacker may have cleared)
Profile/RC:      ~/.bashrc, ~/.bash_profile, ~/.profile, /etc/profile.d/*
SSH:             ~/.ssh/authorized_keys, /etc/ssh/sshd_config, /var/log/auth.log
Cron:            /etc/cron.d/, /var/spool/cron/crontabs/, /etc/crontab
Systemd units:   /etc/systemd/system/, /usr/lib/systemd/system/
PAM:             /etc/pam.d/  (malicious PAM module = credential harvest)
Suid binaries:   find / -perm -4000 2>/dev/null
Temp dirs:       /tmp, /var/tmp, /dev/shm  (world-writable, commonly staged)
Proc filesystem: /proc/<pid>/  (volatile: cmdline, maps, fd/, net/tcp)
Kernel modules:  /proc/modules, lsmod, /lib/modules/$(uname -r)/
Journald:        journalctl --since "2h ago" / journalctl -u sshd
```

macOS artifacts:
```
Unified log:     log show --last 24h | grep -i <indicator>
FSEvents:        /.fseventsd/  (file system change stream, requires parser)
Quarantine:      ~/Library/Preferences/com.apple.LaunchServices.QuarantineEventsV2
LaunchAgents:    ~/Library/LaunchAgents/, /Library/LaunchAgents/, /Library/LaunchDaemons/
Login items:     ~/Library/Application Support/com.apple.backgroundtaskmanagementagent/
KnockKnock:      GUI scan for persistent items (LaunchAgents, kexts, cron, login items)
bash_history:    ~/.bash_history or ~/.zsh_history
Spotlight:       mdfind kMDItemLastUsedDate -onlyin / | head (recent file activity)
```

**Anti-pattern:** Pulling event logs over the network first — copy them to a write-once location (USB, network share with audit logging) before analysis. Accessing live logs modifies EVTX metadata.

### Wireshark and Network Forensics

tshark command-line (scripted analysis):
```bash
# Export all HTTP objects
tshark -r capture.pcap --export-objects http,/tmp/http_objects

# Follow TCP stream (stream index from packet list)
tshark -r capture.pcap -Y "tcp.stream eq 5" -T fields -e text

# Extract DNS queries
tshark -r capture.pcap -Y "dns.flags.response==0" -T fields -e frame.time -e ip.src -e dns.qry.name

# Find large transfers (data exfil)
tshark -r capture.pcap -Y "tcp.len > 1000" -T fields -e frame.time -e ip.src -e ip.dst -e tcp.len | sort -k4 -rn

# Protocol statistics
tshark -r capture.pcap -qz io,phs
tshark -r capture.pcap -qz conv,tcp
```

Wireshark display filters for attack patterns:
```
# C2 beacon detection (periodic connections, low data volume)
tcp.flags.syn==1 && !tcp.flags.ack==1 && !tcp.flags.rst==1

# DNS tunneling (unusually long queries, high entropy subdomains)
dns.qry.name.len > 50

# LDAP reconnaissance (BloodHound-style AD enumeration)
ldap && ldap.filter contains "objectClass"

# Kerberos attacks
kerberos.CNameString contains "$"  # machine accounts (normal)
kerberos.KDC-REP != 0              # Kerberoast / AS-REP
kerberos.error_code == 18          # brute force (KRB5KDC_ERR_CLIENT_REVOKED)

# SMB lateral movement
smb2.cmd == 11                     # session setup (track lateral movement)
smb2.filename contains ".exe"      # lateral binary transfer via SMB
smb2.cmd == 5 && smb2.file_attribute.directory == 0  # file read

# HTTP C2 patterns
http.request.method == "POST" && http.content_length > 0 && frame.len < 200

# ICMP tunneling
icmp.type==8 && data.len > 64  # large ICMP data payload

# TLS with suspicious SNI (DGA domains, freshly registered)
ssl.handshake.extensions_server_name matches "[0-9a-z]{8,}\\.com"

# Port scan detection (many SYN, no established)
tcp.flags == 0x002 && !tcp.analysis.retransmission

# Credential exposure in cleartext
http.authorization || ftp.request.command == "PASS" || pop.request contains "PASS"
```

Capture filters (BPF syntax, for collection phase):
```bash
# Capture specific host
tcpdump -i eth0 -w capture.pcap host 10.0.0.5

# Capture and rotate (1GB files)
tcpdump -i eth0 -w /captures/cap-%Y%m%d-%H%M%S.pcap -G 3600 -C 1000

# Exclude known-good traffic, focus on suspicious
tcpdump -i eth0 -w capture.pcap 'not (port 443 and (host 8.8.8.8 or host 1.1.1.1))'
```

**Anti-pattern:** Running display filters before reducing capture size with read filters — on large captures, `tshark -r big.pcap -Y "..."` is slow; pre-filter with `-R` during conversion or split with `editcap`.

### Containment Strategies

Network isolation — graduated response:
```bash
# Linux: block C2 IP without alerting attacker (iptables silent drop)
iptables -I OUTPUT -d <C2_IP> -j DROP
iptables -I INPUT -s <C2_IP> -j DROP

# Linux: null route C2 range
ip route add blackhole 198.51.100.0/24

# Windows: block via firewall
netsh advfirewall firewall add rule name="Block C2" dir=out action=block remoteip=<C2_IP>

# DNS sinkhole (redirect C2 domain to loopback via /etc/hosts)
echo "127.0.0.1 evil.c2domain.com" >> /etc/hosts

# EDR host isolation — preferred when EDR is deployed (Crowdstrike/Defender for Endpoint)
# Isolates host while maintaining EDR telemetry channel for continued investigation
```

Account containment:
```bash
# Linux: disable compromised account (preserve home dir)
passwd -l <username>        # lock (! prefix in shadow)
usermod -e 1 <username>    # expire immediately

# Revoke SSH keys without locking account
mv ~/.ssh/authorized_keys ~/.ssh/authorized_keys.bak

# Windows: disable AD account (PowerShell)
Disable-ADAccount -Identity <username>

# Reset password and revoke all sessions
Set-ADAccountPassword -Identity <username> -Reset -NewPassword (ConvertTo-SecureString -AsPlainText "TempPass123!" -Force)
# Revoke Azure AD / Entra ID sessions
Revoke-AzureADUserAllRefreshToken -ObjectId <user_id>  # requires AzureAD module
```

Preserve before eradicate: memory image → disk image → event logs to write-protected share → SIEM forwarding verified → chain of custody started.

**Anti-pattern:** Hard-isolating host before memory acquisition — network isolation is fine, but powering off destroys volatile artifacts. Image memory first, then isolate.

### Timeline Reconstruction

Log sources to correlate (normalize all to UTC):
```
Windows Event IDs for IR:
  4624 — Logon success (type 3 = network, type 10 = remote interactive)
  4625 — Logon failure (track brute force, type 3 with many failures)
  4648 — Logon with explicit credentials (runas, lateral movement)
  4663 — Object access (file/key read — requires SACL configured)
  4688 — Process creation (requires audit process creation + cmdline logging)
  4698/4702 — Scheduled task created/modified
  4720 — User account created
  4728/4732/4756 — User added to security/local/universal group
  4740 — Account locked out
  7045 — New service installed (often malware persistence)
  4104 — PowerShell ScriptBlock logging (full script content)
  Sysmon 1 — Process create (hashes, parent, cmdline)
  Sysmon 3 — Network connection (per process)
  Sysmon 7 — DLL load
  Sysmon 11 — File create
  Sysmon 13 — Registry set value
```

Plaso/log2timeline (multi-source timeline):
```bash
# Parse disk image into timeline database
log2timeline.py --storage-file timeline.plaso /dev/sdb1

# Filter to relevant timeframe
psort.py -o l2tcsv -w timeline.csv timeline.plaso "date > '2024-01-15 00:00:00' AND date < '2024-01-16 23:59:59'"

# Parse EVTX only
log2timeline.py --storage-file evtx.plaso --parsers evtx /path/to/evtx/
```

MFT/NTFS timestamp analysis:
```bash
# Parse MFT with analyzeMFT or MFTECmd
# $STANDARD_INFORMATION timestamps: Created, Modified, MFT Modified, Accessed
# $FILE_NAME timestamps: Created, Modified (harder to forge — in MFT + $I30)
# Timestomping detection: $STANDARD_INFORMATION Modified < $FILE_NAME Modified = suspicious

# Extract MFT from live system
Copy-Item C:\$MFT /tmp/mft.raw  # PowerShell with admin privileges
# or via Velociraptor/KAPE collection

# Eric Zimmerman MFT parser
MFTECmd.exe -f MFT --csv /tmp/mft_output/ --csvf mft.csv
```

**Anti-pattern:** Using only one timestamp per artifact — NTFS has 4 timestamps per file in $STANDARD_INFORMATION + 4 in $FILE_NAME. Attackers can forge $STANDARD_INFORMATION with timestomp. $FILE_NAME is harder — correlate both sets.

### Incident Runbooks

**Ransomware Response:**
```
Triage (0-15 min):
  - Identify patient zero: which host encrypted first? check event 4688 (process create)
  - Identify ransomware variant: check ransom note, extension, submit sample to ID Ransomware
  - Determine encryption status: still encrypting vs. done? network still active?
  - Scope: how many shares/hosts affected? check SMB traffic to file servers

Immediate containment:
  - Network-isolate affected hosts via EDR (maintain EDR telemetry)
  - Disable VPN accounts for affected users
  - Block outbound to ransomware C2 IPs (check ransom note, Sysmon 3, firewall logs)
  - DO NOT reboot — ransomware may delete itself on reboot, hindering attribution

Evidence preservation:
  - Memory image before any eradication (encryption keys may be in memory)
  - Export event logs from all affected hosts
  - Preserve VSS (Volume Shadow Copies) before attacker deletes them: vssadmin list shadows

Pre-ransomware IOCs (hands-on-keyboard activity before detonation):
  - Cobalt Strike / Sliver beacon (anomalous outbound HTTPS, beacon traffic)
  - BloodHound collection (LDAP queries from unexpected hosts, Sysmon 3 to DC)
  - Credential dumping (Sysmon 10 on lsass.exe, 4103 PowerShell)
  - Living-off-the-land: wmic.exe, psexec, wscript, mshta with remote URIs
  - net use, robocopy, rclone (staging for exfil before encryption)
```

**Active Directory Compromise:**
```
Indicators:
  - DCSync: Sysmon Event 8 (remote thread injection on lsass), or 4662 with 1131f6aa GUID
  - Golden ticket: 4769 (TGS requests) with RC4 encryption when AES is enforced
  - Persistence via GPO: check SYSVOL changes, Event 5136 (directory service object modified)
  - AdminSDHolder modification: 4662 on AdminSDHolder object

Containment:
  - Rotate krbtgt password TWICE (invalidates all Kerberos tickets, 10-hour gap between resets)
  - Disable/reset all DA accounts
  - Force sign-out via: Invoke-Command -ComputerName DC01 -ScriptBlock {klist purge}
  - Audit and revoke all Tier 0 credential material (DSRM password, CA private key)
```

**Cloud Account Compromise (AWS):**
```bash
# Enumerate what attacker did with compromised creds
aws cloudtrail lookup-events --lookup-attributes AttributeKey=Username,AttributeValue=<user> --start-time 2024-01-01 --end-time 2024-01-02

# Identify new IAM resources created
aws iam list-users --query 'Users[?CreateDate>`2024-01-01`]'
aws iam list-access-keys --user-name <suspect_user>

# Check for persistence via Lambda backdoor or EC2 instance profiles
aws lambda list-functions --region us-east-1
aws iam list-roles --query 'Roles[?contains(AssumeRolePolicyDocument,`lambda.amazonaws.com`)]'

# Contain: revoke all active sessions
aws iam delete-access-key --access-key-id <key_id> --user-name <username>
# Attach DenyAll policy immediately (before full investigation)
aws iam put-user-policy --user-name <username> --policy-name DenyAll --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Deny","Action":"*","Resource":"*"}]}'
```

**Anti-pattern:** Eradicating before understanding scope — removing malware before timeline reconstruction leaves you unable to confirm clean bill of health and risks missing secondary persistence.

### Post-Incident Analysis

After-action report structure:
```
Executive Summary  — business impact, dwell time, data affected
Incident Timeline  — chronological from first evidence to containment (UTC)
Root Cause         — initial access vector, how it was missed
Attack Chain       — ATT&CK TTP sequence with specific commands/artifacts
Dwell Time         — first evidence of compromise → detection (benchmark: industry avg 21 days)
Detection Gaps     — where the kill chain should have been caught, wasn't
Control Gaps       — what preventive control was absent or misconfigured
Remediation        — completed actions + roadmap (short/medium/long term)
Lessons Learned    — what to change in process, tooling, detection
```

Detection gap analysis (map TTPs to detection coverage):
```
For each attacker TTP observed:
  T1059.001 PowerShell → was ScriptBlock logging (4104) enabled? Was output in SIEM?
  T1078 Valid Accounts → was MFA enforced? Were impossible travel alerts configured?
  T1003.001 LSASS Dump → was Sysmon Event 10 (process access on lsass) generating alerts?
  T1021.006 WinRM → was WinRM lateral movement tracked in Event 4624 type 3 + 4648?
```

YARA scanning for IOCs:
```bash
# Scan disk image or live system with YARA rules
yara -r -s rules.yar /mnt/evidence/
# LOKI (multi-scanner: YARA + hash + filename patterns + string IOCs)
loki.py -p /mnt/evidence/ --csv /tmp/loki_results.csv
# Fenrir (bash-based, Linux/macOS, no compilation needed)
./fenrir.sh /
```

## Key Chains

### Initial Triage to Scoped Compromise (First 2 Hours)

1. Receive alert or report → confirm active/contained; assign severity (NIST tier)
2. Preserve volatile: memory image → network connections → process list → open files
3. Export event logs to write-protected share (block attacker from clearing them)
4. Network isolation via EDR while preserving telemetry channel
5. Hayabusa/Chainsaw fast EVTX scan: `hayabusa csv-timeline -d /evtx -o tl.csv` → open in Excel/Kibana, filter by EventID
6. Identify patient zero: earliest Sysmon 1 event for malware process, or Event 4624 for initial logon
7. Map initial access → execution → lateral movement via 4648+4624 type 3 chain

### Evidence Collection to Forensic Package

1. Chain of custody: document system (hostname, IP, OS, time/timezone) + investigator ID
2. Hash live disk MBR: `sha256sum /dev/sda`
3. Image disk (write-blocker recommended): `dd if=/dev/sda bs=4M | split -b 4G - /evidence/disk.img.` + final hash
4. Parse MFT from image: `MFTECmd.exe -f MFT --csv /evidence/mft/`
5. Export hive files: `reg.exe save HKLM\SYSTEM system.hiv` (live) or carve from image
6. Parse registry with RegRipper: `rip.pl -r NTUSER.DAT -f ntuser > ntuser_report.txt`
7. Correlate prefetch (execution evidence) + Amcache (install evidence) + event logs into Plaso timeline

### Containment-to-Eradication Pipeline

1. Scope confirmed → identify all affected hosts via IOC sweep (YARA + hash + network IOCs)
2. Build cleanup checklist per host: persistence mechanisms (registry, scheduled tasks, services, WMI), dropped files (prefetch tells you what ran), lateral movement accounts
3. Rotate credentials in order: compromised accounts → service accounts → krbtgt (if AD compromise) → privileged tokens
4. Remove persistence: delete reg keys, remove scheduled tasks, delete malicious services, clean WMI subscriptions
5. Patch initial access vector BEFORE bringing hosts back online
6. Rebuild if: rootkit suspected, attacker had SYSTEM > 24h, OS integrity questionable (hash mismatch on system binaries)
7. Verify clean: EDR clean scan + YARA sweep + Chainsaw on fresh event logs post-rebuild + network baseline comparison

---
v1.1 | Validated: 2026-03-13
