<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# SKILL: Threat Intelligence

## Activation
Triggered when the operator asks about threat actors, TTPs, IOCs, CTI programs,
MISP, STIX/TAXII, threat feeds, intelligence requirements, threat modeling, APT groups,
Diamond Model, Kill Chain, campaign analysis, IOC lifecycle, or threat landscape analysis.

## Quick Reference
- MISP event ingest: `curl -X POST https://misp/events -H "Authorization: <key>" -d @event.json`
- MISP search IOC: `curl -X POST https://misp/attributes/restSearch -d '{"value":"evil.com","type":"domain"}'`
- TAXII 2.1 collection poll: `curl -u user:pass https://taxii/api/v21/collections/{id}/objects/`
- OpenCTI entity lookup: `curl -H "Authorization: Bearer <token>" https://opencti/graphql -d '{"query":"..."}'`
- STIX bundle validate: `python3 -c "import stix2; stix2.parse(open('bundle.json').read())"`
- VirusTotal IOC enrich: `curl -H "x-apikey: KEY" https://www.virustotal.com/api/v3/domains/evil.com`
- Shodan host lookup: `shodan host 1.2.3.4` / `shodan search "product:nginx country:RU"`
- YARA scan: `yara -r rules/ /path/to/samples/ -o matches.txt`
- ATT&CK lookup (mitre-attack-data): `python3 -c "from mitreattack.stix20 import MitreAttackData; ..."`
- sigma convert: `sigma convert -t splunk -p splunk_cim rules/windows/process_creation/proc_creation_win_suspicious.yml`
- IOC aging check: `jq '.[] | select(.expiry < now)' iocs.json`
- ThreatFox query: `curl -X POST https://threatfox-api.abuse.ch/api/v1/ -d '{"query":"search_ioc","search_term":"evil.com"}'`

## Competencies

### Intelligence Requirements and Tradecraft

Priority Intelligence Requirements (PIRs) drive collection; answer before collection begins:
- What adversaries are actively targeting our sector/region?
- Which TTPs are currently in use against our technology stack?
- Are there credible threats against specific campaigns, products, or executives?

Structured Analytic Techniques (SATs):
- **ACH (Analysis of Competing Hypotheses):** List all hypotheses → identify diagnostic evidence → weight by H/I/D (helps/is inconsistent with/diagnostically neutral) → select hypothesis with fewest inconsistencies
- **Key Assumptions Check:** Explicitly list assumptions underlying an assessment → challenge each. Analysts routinely embed assumptions from single-source reporting without validation.
- **Devil's Advocacy:** Assign someone to argue against the consensus. Prevents groupthink in threat actor attribution.
- **Admiralty Scale:** Source reliability (A=reliable → F=untested) × Information credibility (1=confirmed → 6=cannot be judged). Report as A2, C4, etc. Do not conflate source and information quality.

Confidence levels (standard in finished intelligence):
- **HIGH**: multiple independent corroborating sources; no significant contradicting evidence
- **MODERATE**: credible source with limited corroboration; or corroborated source with analytical assumptions
- **LOW**: limited single-source; analytical judgment without corroboration; speculative

**Anti-pattern:** Omitting confidence levels in finished products — analysts who say "the actor is APT28" without confidence qualification invite attribution errors that damage credibility and cause incorrect defensive decisions.

### Threat Actor Profiling

Core profiling dimensions:

**Motivation:**
- Nation-state: espionage, IP theft, strategic positioning, destructive capability pre-positioning
- Cybercriminal: financial gain (ransomware, BEC, card theft, cryptojacking)
- Hacktivist: ideological statement, DDoS, defacement, data dumps
- Insider: financial, revenge, ideology, coercion
- Script kiddie / opportunistic: low sophistication, targets low-hanging fruit

**Capability assessment:**
- 0-day usage: true APT indicator; repeated 0-day usage = top-tier (Equation Group, APT28, Lazarus)
- Tooling sophistication: custom implants > modified open-source > commodity malware
- OPSEC discipline: operational security mistakes (reused infrastructure, language artifacts, time-zone patterns) aid attribution
- Operational tempo: sustained vs. burst campaigns; seasonal patterns align with nation-state workdays

**APT Group TTP Profiles:**

**APT28 (Fancy Bear / GRU Unit 26165 / Strontium)** — Russia, military intelligence
- Initial access: spearphishing (T1566.001), credential harvesting via Phishery, VPN/ADFS exploitation
- Tools: X-Agent (Sofacy), X-Tunnel, LoJax (first UEFI implant in wild), Zebrocy, Komplex (macOS)
- TTPs: T1059.001 (PowerShell), T1071.001 (web C2), T1003.001 (LSASS), T1548.002 (UAC bypass)
- Victimology: NATO governments, defence contractors, political parties, media, think tanks
- ATT&CK Group: G0007

**APT29 (Cozy Bear / SVR / Midnight Blizzard / Nobelium)** — Russia, foreign intelligence
- Initial access: sophisticated supply chain (SolarWinds T1195.002), spearphishing, OAuth abuse
- Tools: SUNBURST, TEARDROP, MagicWeb (ADFS forgery), WellMess, HAMMERTOSS (Twitter C2)
- TTPs: T1195 (supply chain), T1078.004 (cloud accounts), T1550.001 (pass the cookie), T1484 (AAD domain federation abuse)
- Notable: SolarWinds SUNBURST campaign — months-long dwell time, living-off-the-land C2 via legitimate SolarWinds update path
- ATT&CK Group: G0016

**Lazarus Group (HIDDEN COBRA / Zinc / Labyrinth Chollima)** — North Korea, RGB Bureau 121
- Initial access: fake job offer spearphishing (OperationDreamJob), trojanized installers, LinkedIn targeting
- Tools: BLINDINGCAN, COPPERHEDGE, ELECTRICFISH, Manuscrypt; custom Linux implants
- TTPs: T1204.002 (malicious file), T1027 (obfuscation), T1041 (exfil over C2), heavy use of LOLBins
- Victimology: cryptocurrency exchanges, defence, aerospace, financial sector; sanctions evasion
- Unique: cash-out operations via fake DeFi/NFT projects; SWIFT banking heists (Bangladesh Bank $81M)
- ATT&CK Group: G0032

**FIN7 (Carbanak Group / Navigator Group)** — financially motivated, Eastern Europe nexus
- Initial access: targeted spearphishing with macro-laced Office docs, USB drop campaigns, fake security firm (Combi Security) recruits unwitting pentesters
- Tools: CARBANAK (banking trojan), Bateleur, GRIFFON (JavaScript backdoor), Pillowmint (POS malware)
- TTPs: T1059.005 (VBS), T1055 (process injection), T1056.001 (keylogging), T1071.001 (HTTPS C2)
- Victimology: POS systems, hospitality, retail, financial — focus on high-value card data and banking access
- ATT&CK Group: G0046

**Scattered Spider (UNC3944 / Muddled Libra)** — financially motivated, English-speaking, social engineering
- Initial access: vishing (T1566.004), SIM swapping (T1078), MFA fatigue/push bombing (T1621)
- TTPs: BYOVD (bring your own vulnerable driver), STONESTOP/POORTRY to kill EDR processes; BlackCat/ALPHV ransomware affiliate
- Notable: MGM Resorts, Caesars Entertainment breaches (2023) via identity provider compromise
- ATT&CK Group: G1015

**Sandworm (Voodoo Bear / GRU Unit 74455)** — Russia, destructive operations
- Tools: NotPetya (destructive wiper), Industroyer/Industroyer2 (ICS), CRASHOVERRIDE, BlackEnergy
- TTPs: T1486 (data encrypted for impact), T1561 (disk wipe), T1565 (data manipulation), OT/ICS targeting
- Victimology: Ukrainian critical infrastructure, global collateral damage (NotPetya: $10B+)
- ATT&CK Group: G0034

**Anti-pattern:** Attributing to a single actor without considering false flag operations — APT28 was documented using TTPs mimicking Chinese APTs in specific campaigns. Attribution requires convergent evidence, not just TTP overlap.

### IOC Management and Lifecycle

**IOC Types by confidence decay rate:**
- **File hashes (SHA256):** Days to weeks lifespan post-discovery; threat actors repatch/repack rapidly. MD5/SHA1 deprecated for malware ID — collision attacks and repacking invalidate them.
- **IP addresses:** Hours to days; shared infrastructure, bulletproof hosters rotate IPs constantly. Context required: C2 vs. scanning vs. staging.
- **Domains:** Weeks; domain generation algorithms (DGA) produce hundreds daily. FQDN more stable than IP.
- **URLs:** Days; paths rotate; check domain-only as fallback after URL expiry.
- **Email addresses:** Weeks to months; sender addresses in phishing campaigns often persist.
- **Certificates (fingerprint/serial):** Weeks to months; cert reuse indicates operational infrastructure.
- **JARM fingerprints:** Months; TLS stack fingerprint identifies C2 servers across IP changes.
- **Mutexes / registry keys / named pipes:** Months; behavioral IOCs; harder to change than network IOCs.
- **YARA rules (behavioral):** Months to years; target malware families, not specific builds.

**IOC confidence scoring (0-100):**
```
90-100: Directly observed in incident, sandbox-confirmed C2 callback
70-89:  Multiple third-party sources, corroborated by hunt activity
50-69:  Single credible source, plausible but unconfirmed
30-49:  Automated feed, limited context, possible FP
<30:    Age-degraded, stale, or single low-confidence source — retire
```

**IOC enrichment workflow:**
```
Raw IOC → Deduplicate → Type normalization → Enrich (VT/Shodan/WHOIS/passive DNS)
→ Context tag (malware family, campaign, actor) → Confidence score
→ Expiry date assignment → Push to platform (MISP/OpenCTI) → Export to detection stack
```

**Enrichment sources by IOC type:**
- IP: VirusTotal, Shodan, GreyNoise (scanner vs. targeted), AbuseIPDB, Censys, RIPE/ARIN
- Domain: VirusTotal, urlscan.io, passive DNS (DNSDB, SecurityTrails), WHOIS history
- Hash: VirusTotal, MalwareBazaar, Hybrid Analysis, Any.Run, Cape Sandbox
- Email: Hunter.io (org context), WHOIS, breach database correlation

**Anti-pattern:** Treating IOCs from threat feeds as equally reliable — automated feeds have 30-40% false positive rates. Always require minimum context (what malware family? what campaign?) before pushing to blocking rules. Block on high-confidence IOCs; alert on medium; log on low.

### STIX/TAXII Patterns

**STIX 2.1 object hierarchy:**
```
SDOs (Domain Objects):
  Indicator        — pattern matching IOC (STIX patterns or YARA/Snort)
  Malware          — malware family description, capabilities, aliases
  Threat Actor     — adversary profile, sophistication, goals
  Campaign         — coordinated adversary activity set with objective
  Attack Pattern   — CAPEC or ATT&CK technique description
  Course of Action — defensive recommendation
  Tool             — legitimate or dual-use tool
  Vulnerability    — CVE reference with description

SROs (Relationship Objects):
  Relationship     — typed directed edge: "uses", "targets", "indicates", "mitigates"
  Sighting         — observed SDO instance with count and time range

SCOs (Cyber Observables):
  ipv4-addr, domain-name, url, file, email-addr, network-traffic, process, etc.
```

**STIX 2.1 Indicator pattern syntax:**
```json
{
  "type": "indicator",
  "spec_version": "2.1",
  "id": "indicator--...",
  "created": "2024-01-15T10:00:00Z",
  "modified": "2024-01-15T10:00:00Z",
  "name": "APT28 C2 Domain",
  "pattern": "[domain-name:value = 'c2.evil.com']",
  "pattern_type": "stix",
  "valid_from": "2024-01-15T10:00:00Z",
  "valid_until": "2024-03-15T10:00:00Z",
  "labels": ["malicious-activity"],
  "indicator_types": ["malicious-activity"],
  "confidence": 85
}
```

**STIX bundle assembly:**
```python
import stix2

indicator = stix2.Indicator(
    name="C2 Domain",
    pattern="[domain-name:value = 'malicious.com']",
    pattern_type="stix",
    valid_from="2024-01-01T00:00:00Z"
)
actor = stix2.ThreatActor(name="APT28", aliases=["Fancy Bear", "Strontium"])
rel = stix2.Relationship(actor, "uses", indicator)
bundle = stix2.Bundle(objects=[indicator, actor, rel])
print(bundle.serialize(pretty=True))
```

**TAXII 2.1 operations:**
```bash
# List collections
curl -u user:pass -H "Accept: application/taxii+json;version=2.1" \
  https://taxii.server/api/v21/collections/

# Get objects from collection (paginate with next/more)
curl -u user:pass \
  "https://taxii.server/api/v21/collections/{id}/objects/?added_after=2024-01-01T00:00:00Z&limit=100"

# Push objects to collection
curl -X POST -u user:pass -H "Content-Type: application/stix+json;version=2.1" \
  https://taxii.server/api/v21/collections/{id}/objects/ -d @bundle.json
```

**Anti-pattern:** Using STIX without valid_until on indicators — indicators without expiry persist indefinitely. A domain IOC from a 2019 campaign blocking traffic in 2024 is a false positive generator. Always set valid_until at ingest time.

### Analytical Frameworks Applied

**Diamond Model:**
Four features with bidirectional relationships:
```
         Adversary
        /          \
   Capability — — — Infrastructure
        \          /
         Victim
```
- **Adversary:** Who is conducting the operation (actor profile, motivation, intent)
- **Capability:** What tools/TTPs they use (malware, exploits, social engineering)
- **Infrastructure:** How they operate (C2, staging, bulletproof hosting, domains)
- **Victim:** Who they target (sector, technology, geography, persona)

**Diamond Model meta-features:** Timestamp (campaign phase), Phase (Kill Chain step), Result (success/fail/unknown), Direction (attacker→victim vs. victim→attacker), Methodology (attack type), Resources (operator level)

**Pivoting with Diamond Model:** New infrastructure IOC → pivot to related victims (who else used this IP?) → pivot to capabilities (what malware called home here?) → pivot to adversary (who operates this infrastructure cluster?)

**Lockheed Martin Cyber Kill Chain (7 stages):**
```
1. Recon         — Passive/active intel gathering. Defender opportunity: monitor external exposure
2. Weaponization — Exploit + payload creation. Defender: no visibility; rely on threat intel feeds
3. Delivery      — Phishing, watering hole, USB. Defender: email gateway, web proxy, awareness
4. Exploitation  — Code execution on target. Defender: patch, exploit prevention (EMET/DEP/CFG)
5. Installation  — Persistence mechanism. Defender: endpoint telemetry, baseline monitoring
6. C2            — Outbound comms. Defender: DNS/proxy monitoring, JA3/JARM, beaconing detection
7. Actions on Objectives — Exfil, destruction, lateral move. Defender: DLP, honeypots, segmentation
```

**Kill Chain limitation:** Linear model; real attacks loop back, skip stages, and have parallel tracks. Use ATT&CK for technique-level analysis; Kill Chain for campaign phase communication to non-technical stakeholders.

**ACH in practice (attribution example):**
```
Hypotheses: H1=APT28, H2=APT29, H3=FIN7, H4=False flag
Evidence E1: X-Agent variant found     → H1+, H2I, H3I, H4?
Evidence E2: GRU-linked registrar      → H1+, H2I, H3I, H4+
Evidence E3: Financial targeting       → H1I, H2I, H3+, H4?
Evidence E4: No financial exfil        → H1~, H2~, H3I, H4~
Matrix cell values: + (consistent), I (inconsistent), ~ (not diagnostic)
Result: H1 has fewest inconsistencies — assess APT28 with MODERATE confidence
```

### Intelligence Production

**Product types and audiences:**

**Strategic intelligence** (CISO, board, executives):
- Business impact language, no jargon, no TLAs without definition
- Threat landscape briefing format: sector trends, top threat actors, risk recommendations
- Cadence: monthly/quarterly or event-driven
- Length: 1-2 pages maximum

**Operational intelligence** (security architects, IR team leads):
- TTP focus: how adversary operates, what defensive gaps they exploit
- Actionable: specific configuration changes, detection investments, hunting priorities
- Include ATT&CK heatmap showing gaps vs. actor profile

**Tactical intelligence** (SOC analysts, detection engineers):
- IOC lists with context (malware family, campaign, confidence, expiry)
- Detection rules (Sigma, Snort, YARA) ready to deploy
- Pivot queries for SIEM

**Technical intelligence** (reverse engineers, forensics):
- Malware analysis report: capabilities, C2 protocol, persistence, decryption keys
- C2 infrastructure map: IPs, domains, ASNs, hosting patterns, historical pivots
- Configuration extraction, DGA seed/algorithm analysis

**Finished product structure (standard):**
```
[CLASSIFICATION] [HANDLING CAVEAT]
Title: [Actor] [Activity Type] Targeting [Sector/Geography]
TLP: WHITE/GREEN/AMBER/RED
Date: YYYY-MM-DD  |  Confidence: HIGH/MODERATE/LOW

EXECUTIVE SUMMARY (3 sentences max)

KEY JUDGMENTS
  1. [Assessment] [Confidence level]
  2. ...

BACKGROUND (context on actor, prior campaign history)

TECHNICAL DETAILS (TTPs, IOCs, kill chain mapping)

DEFENSIVE RECOMMENDATIONS

APPENDIX: IOC TABLE
  Type | Value | Context | Confidence | Expiry
```

**TLP (Traffic Light Protocol) definitions:**
- **WHITE:** Unlimited distribution, public
- **GREEN:** Community sharing, no public posting
- **AMBER:** Organization + need-to-know basis
- **AMBER+STRICT:** Recipients only, no further distribution
- **RED:** Named recipients only, conversation-level

### MISP Operations

Platform setup and event management:
```bash
# Create MISP event via API
curl -X POST https://misp/events \
  -H "Authorization: YOUR_API_KEY" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{
    "Event": {
      "distribution": "1",
      "info": "APT28 Phishing Campaign 2024-Q1",
      "date": "2024-01-15",
      "threat_level_id": "2",
      "analysis": "1"
    }
  }'

# Add attribute (IOC) to event
curl -X POST https://misp/attributes/add/{event_id} \
  -H "Authorization: KEY" \
  -d '{"type":"domain","category":"Network activity","value":"evil.com","comment":"C2 domain","to_ids":true}'

# Search attributes across all events
curl -X POST https://misp/attributes/restSearch \
  -H "Authorization: KEY" \
  -d '{"returnFormat":"json","type":"domain","value":"evil.com","to_ids":1}'

# Export event as STIX 2.1
curl https://misp/events/restSearch/returnFormat:stix2/type:Event/eventid:123
```

**MISP taxonomies for TI tagging:** `tlp:amber`, `misp-galaxy:threat-actor="APT28"`, `misp-attack-pattern:T1566.001`, `confidence:80`

**MISP feeds configuration:** Pull threat intel feeds from trusted sources:
```python
# misp-feed schema for custom feed
[
  {"url": "https://your-feed/manifest.json", "name": "Custom TI", "provider": "Internal",
   "enabled": True, "rules": "", "distribution": 3, "sharing_group_id": None, "tag_id": None,
   "default_distribution": 3, "source_format": "misp", "fixed_event": False, "delta_merge": True}
]
```

**Anti-pattern:** Setting `to_ids=true` on all IOCs — `to_ids` means "use for automated detection/blocking." Low-confidence or contextual IOCs with `to_ids=true` generate alert noise. Reserve `to_ids=true` for high-confidence, high-specificity IOCs (specific hashes, targeted C2 domains) — not for generic IPs or broad domains.

### IOC-to-Detection Integration

Translating threat intelligence into detection rules:

**Hash IOC → SIEM/EDR rule:**
```yaml
# Sigma rule from hash IOC
title: Malware Hash - APT28 Sofacy Loader
status: stable
logsource:
  category: process_creation
  product: windows
detection:
  selection:
    Hashes|contains:
      - 'SHA256=a1b2c3d4e5f6...'
      - 'MD5=deadbeefdeadbeef'
  condition: selection
falsepositives: none
level: critical
tags:
  - attack.execution
  - attack.t1059
```

**Domain IOC → DNS detection:**
```yaml
title: C2 Domain - APT28 Campaign
logsource:
  category: dns
detection:
  selection:
    dns.question.name:
      - 'evil-c2.com'
      - '*.evil-c2.com'
  condition: selection
level: high
```

**Behavioral TTP → Sigma (no specific IOC needed):**
```yaml
title: Suspicious LSASS Memory Access (T1003.001)
logsource:
  product: windows
  service: sysmon
detection:
  selection:
    EventID: 10
    TargetImage|endswith: '\lsass.exe'
    GrantedAccess|contains:
      - '0x1010'
      - '0x1410'
      - '0x1010'
  filter_legitimate:
    SourceImage|contains:
      - '\Windows\System32\'
      - '\Program Files\Windows Defender\'
  condition: selection and not filter_legitimate
level: high
tags: [attack.credential_access, attack.t1003.001]
```

**JARM-based C2 detection (TLS fingerprinting):**
```bash
# Generate JARM for known C2 server
python3 jarm.py malicious-c2.com
# Output: 2ad2ad0002ad2ad00042d42d000000ad9bf51cc3f5a1e29eecb81d0c7b06eb

# Shodan JARM lookup: ssl.jarm:"2ad2ad..." → find all servers with same TLS stack
# Production: extract JARM from proxy logs, alert on known-bad fingerprints
```

**Anti-pattern:** Converting every network IOC to a block rule — aggressive IP/domain blocking causes collateral damage on shared infrastructure. Alert on IOCs first; block only after confirming no false positives and reviewing asset criticality.

## Key Chains

### IOC-to-Detection Pipeline
1. Receive raw IOC (email, feed, manual report) → normalize type/value/source
2. Enrich: VT reputation, passive DNS history, WHOIS, GreyNoise (scanner vs. targeted)
3. Score confidence (0-100) + assign expiry date based on IOC type
4. Tag with MISP taxonomy: TLP, actor galaxy, ATT&CK technique
5. Push to MISP with `to_ids=true` if confidence >70 and specificity high
6. Auto-export to SIEM via MISP→Sigma pipeline or direct API push to EDR allowlist/blocklist
7. Create corresponding Sigma/YARA rule for behavioral coverage beyond single IOC
8. Schedule expiry job: retire IOCs past valid_until, demote confidence >90 days old

### Campaign Analysis Workflow (Diamond Model)
1. **Victim data first**: gather all victim reports, sector, geography, timeframe
2. **Capability extraction**: extract all tools, TTPs, and techniques; map to ATT&CK matrix
3. **Infrastructure clustering**: pivot on IPs/domains via passive DNS, WHOIS registrar/registrant patterns, cert transparency logs, ASN clustering
4. **Adversary hypothesis**: generate actor hypotheses; apply ACH with available evidence
5. **Diamond assembly**: map all four features + meta-features; identify gaps
6. **Campaign boundary**: define campaign start/end; identify sub-campaigns if methodology changed
7. **Finished product**: select audience-appropriate format; include confidence levels on all key judgments; route via TLP

### Threat Actor Profiling Chain
1. Identify incident artifacts: malware samples, C2 infra, email headers, phishing content
2. Extract TTPs → map to ATT&CK sub-techniques (precision matters: T1566.001 not T1566)
3. Match against known actor profiles: compare tool fingerprints, infrastructure patterns, victimology, operational tempo (timezone/workday analysis)
4. Cross-reference public reporting: vendor reports (Mandiant, CrowdStrike, Microsoft MSTIC), CISA advisories
5. Score attribution confidence using ACH; document competing hypotheses
6. Update actor profile in MISP/OpenCTI with new campaign data + ATT&CK navigator layer
7. Generate operational recommendations: what controls would have stopped this actor? gap analysis vs. current stack

---
v1.1 | Validated: 2026-03-13
