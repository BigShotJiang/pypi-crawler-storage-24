# Changelog

All notable changes to CIPHER are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.3.0] - 2026-03-16

### Added

- **Multi-provider via LiteLLM** — `pip install cipher-security[multi]` enables any LiteLLM-supported model (OpenAI, Gemini, Mistral, Groq, Azure, etc.) via `--backend litellm` or `llm_backend: litellm` in config. Adapter wraps `litellm.completion()` behind Anthropic-compatible interface — no gateway branching needed.
- **Plugin system** — extend CIPHER with custom skills. CLI: `cipher plugin list/install/remove/info`. Plugins discovered from `~/.config/cipher/plugins/` and Python entry points (`cipher.skills` group). Priority-sorted injection into system prompt. 12 tests.
- **VS Code extension** — sidebar chat with streaming, right-click code analysis, mode/backend selectors. Subprocess-based (no daemon). Source in `vscode/`.
- **Web UI** — `cipher web` launches a browser-accessible Textual interface via `textual-serve`. Requires `pip install cipher-security[web]`.
- **Bash and Zsh shell completions** — `completions/cipher.bash` and `completions/cipher.zsh` alongside existing Fish completions.
- **Setup wizard LiteLLM support** — `cipher setup` now offers LiteLLM as option 3 with model string, API key, and base URL prompts.
- Optional dependency extras: `[multi]` (LiteLLM), `[web]` (Textual web), `[all]` (everything)

### Changed

- Architecture diagram updated: three backends (Ollama, Claude, LiteLLM), seven interfaces (CLI, Dashboard, Web, VS Code, Claude Code, Signal Bot, Docker)
- README rewritten: multi-provider docs, plugin system, VS Code extension, web UI, shell completions, updated test count (485), corrected skill count (9)
- CI updated to `actions/checkout@v6` and `actions/setup-python@v6` (Node.js 24 migration)
- VS Code gateway simplified from spawn+fallback to clean `execFile` invocation

### Fixed

- Setup wizard only offered ollama/claude — added litellm as third option
- Setup step 2 had no litellm config branch — added model, api_key, api_base prompts

## [1.2.0] - 2026-03-16

### Added

- Dynamic version resolution from package metadata
- Fish shell completions
- **Context monitor hook** — PostToolUse hook warns at 35%/25% remaining context, engagement-aware messaging
- **Statusline hook** — model, directory, and context usage bar for Claude Code
- **`/cipher:update`** — self-update from PyPI with changelog display and confirmation
- **`/cipher:setup-hooks`** — register hooks in Claude Code, GSD-aware coexistence
- **Auto-install hooks** during `cipher setup` (detects and coexists with GSD)
- **Complexity classifier** (`gateway/complexity.py`) — multi-signal heuristic routing: length, domain keywords, query structure, framework density
- **Engagement persistence** — `.cipher/` directory with `ENGAGEMENT.md` as single source of truth
- **`/cipher:engage`** — initialize security engagements (pentest, audit, IR, threat-model, assessment)
- **`/cipher:resume`** — resume engagement with status briefing
- **`/cipher:export`** — export engagement as formatted security report
- **8 agent definitions** — cipher-red, cipher-blue, cipher-purple, cipher-incident, cipher-recon, cipher-privacy, cipher-architect, cipher-researcher
- **Wave-based parallel dispatch** for `/cipher:audit` (4 parallel agents + synthesis)
- **Wave-based parallel dispatch** for `/cipher:brief` (4 parallel agents + synthesis)
- All 34 slash commands shipped in `commands/` directory for distribution
- CHANGELOG.md

### Changed

- Smart routing upgraded from keyword matching to score-based complexity classifier (SIMPLE/MODERATE→Ollama, COMPLEX/EXPERT→Claude)
- `/cipher:audit` rewritten with 2-wave parallel architecture (4x faster)
- `/cipher:brief` rewritten with 2-wave parallel architecture (4x faster)
- README updated with hooks, engagements, and update documentation (35 skills)

## [1.1.0] - 2026-03-16

Version bump only — no functional changes beyond 0.3.0.

## [0.3.0] - 2026-03-16

### Added

- `/cipher:brief` orchestrator mode
- Knowledge base expansion: tomnomnom recon tooling, abliteration techniques
- Streaming responses in CLI
- Signal bot RAG integration
- Comprehensive test expansion — 10 new test modules (940+ total tests)
- Config migrations framework with 7 tests
- CONTRIBUTING.md and GitHub issue templates
- Asciinema demo and PyPI badge in README

### Changed

- Require Python 3.14+, drop 3.10–3.13 support
- Update Docker and release workflow to Python 3.14
- Expand `threat-intel-deep.md` (800 to 2300 lines)
- Expand `evasion-techniques-deep.md` (801 to 2073 lines)
- Skip RAG ingestion during setup if index already populated (performance)
- Update README — 29 skills, Python 3.14+, 940+ tests, new KB content

### Fixed

- Write config to `~/.config/cipher/` instead of pipx venv directory
- Multi-word queries, graceful config errors, data bundling
- Strip ANSI codes in CLI tests, skip ingest tests in CI
- Resolve test failures — import paths, timeouts, and RAG assertions
- CI test failures — ANSI escape codes and ingest timeouts

## [0.2.0] - 2026-03-15

### Added

- Multi-interface architecture rewrite (CIPHER v2.0)
- Typer CLI with Rich cyberpunk theme
- Cyberpunk TUI dashboard (`cipher dashboard`)
- Onboarding wizard (`cipher setup`)
- RAG pipeline for knowledge base retrieval (ChromaDB)
- Auto re-ingest RAG on `knowledge/` file changes
- RAG retriever tests and GitHub Actions CI
- ARCHITECT skill file and purple team exercise playbooks
- Deep knowledge expansion — 7 documents, 18K+ new lines
- Install scripts and Docker support
- Release workflow — PyPI and GHCR on version tags
- Config upgrade — env var substitution and secret redaction
- Validation test suite — guardrails, RAG quality, mode routing
- Cyberpunk knowledge base theme for cipher.blacktemple.net
- Signal bot with E2E fixes, setup subcommand, session manager
- Gateway orchestrator, LLM client factory, mode detection, prompt assembly
- AGPL-3.0 license and copyright headers

### Fixed

- Docker build (use pip instead of uv) and PyPI skip-existing
- Signal-api healthcheck (wget to curl)
- Host install scripts via GitHub raw URLs
- CI install all deps including signal extra
- Resolve ruff lint errors (F401, F841)

[Unreleased]: https://github.com/defconxt/CIPHER/compare/v1.3.0...HEAD
[1.3.0]: https://github.com/defconxt/CIPHER/compare/v1.2.0...v1.3.0
[1.2.0]: https://github.com/defconxt/CIPHER/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/defconxt/CIPHER/compare/v0.3.0...v1.1.0
[0.3.0]: https://github.com/defconxt/CIPHER/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/defconxt/CIPHER/compare/v1.0...v0.2.0
