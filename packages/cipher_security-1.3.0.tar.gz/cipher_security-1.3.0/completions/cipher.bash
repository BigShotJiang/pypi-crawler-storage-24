# CIPHER shell completions for bash
# Install: source this file or copy to /etc/bash_completion.d/cipher
#   source completions/cipher.bash
#   # or
#   cp completions/cipher.bash /etc/bash_completion.d/cipher
#   # or add to ~/.bashrc:
#   eval "$(cipher --show-completion bash)"

_cipher_completion() {
    local IFS=$'\n'
    COMPREPLY=( $( env COMP_WORDS="${COMP_WORDS[*]}" \
                   COMP_CWORD=$COMP_CWORD \
                   _CIPHER_COMPLETE=complete_bash $1 ) )
    return 0
}

complete -o default -F _cipher_completion cipher
