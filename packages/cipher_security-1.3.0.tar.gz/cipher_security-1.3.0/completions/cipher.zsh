#compdef cipher
# CIPHER shell completions for zsh
# Install: source this file or add to your fpath
#   source completions/cipher.zsh
#   # or add to ~/.zshrc:
#   eval "$(cipher --show-completion zsh)"
#   # or copy to a directory in your fpath:
#   cp completions/cipher.zsh ~/.zfunc/_cipher && fpath+=~/.zfunc && compinit

_cipher_completion() {
  eval $(env _TYPER_COMPLETE_ARGS="${words[1,$CURRENT]}" _CIPHER_COMPLETE=complete_zsh cipher)
}

compdef _cipher_completion cipher
