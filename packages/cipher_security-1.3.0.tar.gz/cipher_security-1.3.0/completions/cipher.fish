# CIPHER shell completions for fish
# Install: copy to ~/.config/fish/completions/cipher.fish
#   cp completions/cipher.fish ~/.config/fish/completions/cipher.fish
complete -c cipher -f

# Subcommands
complete -c cipher -n '__fish_use_subcommand' -a 'query' -d 'Send a security query'
complete -c cipher -n '__fish_use_subcommand' -a 'ingest' -d 'Re-index the knowledge base'
complete -c cipher -n '__fish_use_subcommand' -a 'dashboard' -d 'Interactive terminal dashboard'
complete -c cipher -n '__fish_use_subcommand' -a 'setup' -d 'Interactive onboarding wizard'
complete -c cipher -n '__fish_use_subcommand' -a 'status' -d 'Show system status'
complete -c cipher -n '__fish_use_subcommand' -a 'doctor' -d 'Run diagnostics'
complete -c cipher -n '__fish_use_subcommand' -a 'version' -d 'Show version'
complete -c cipher -n '__fish_use_subcommand' -a 'setup-signal' -d 'Register Signal phone number'

# Global options
complete -c cipher -l help -d 'Show help'

# query options
complete -c cipher -n '__fish_seen_subcommand_from query' -s b -l backend -xa 'ollama claude' -d 'LLM backend override'
complete -c cipher -n '__fish_seen_subcommand_from query' -s s -l smart -d 'Auto-route: simple→Ollama, complex→Claude'
complete -c cipher -n '__fish_seen_subcommand_from query' -l stream -d 'Stream response tokens'
complete -c cipher -n '__fish_seen_subcommand_from query' -l no-stream -d 'Disable streaming'

# setup options
complete -c cipher -n '__fish_seen_subcommand_from setup' -s b -l backend -xa 'ollama claude' -d 'Pre-select backend'
complete -c cipher -n '__fish_seen_subcommand_from setup' -l api-key -d 'Claude API key'
complete -c cipher -n '__fish_seen_subcommand_from setup' -l non-interactive -d 'No prompts'

# doctor options
complete -c cipher -n '__fish_seen_subcommand_from doctor' -l fix -d 'Auto-repair issues'
