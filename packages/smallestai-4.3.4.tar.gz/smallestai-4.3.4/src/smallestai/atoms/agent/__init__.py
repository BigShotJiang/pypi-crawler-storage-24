"""
Smallest AI Atoms Agent SDK.

A real-time WebSocket agent framework for building voice agents,
chatbots, and other interactive AI applications.

Usage:
    from smallestai.atoms.agent.server import AtomsApp
    from smallestai.atoms.agent.session import AgentSession
    from smallestai.atoms.agent.nodes import OutputAgentNode, BackgroundAgentNode
    from smallestai.atoms.agent.clients.openai import OpenAIClient
    from smallestai.atoms.agent.tools import function_tool, ToolRegistry
"""
