"""
High-level Atoms API client.

Usage:
    from smallestai.atoms import AtomsClient

    client = AtomsClient()
    client.get_phone_numbers()
"""

import os
from typing import Any, Dict, Optional

import requests

DEFAULT_BASE_URL = "https://api.smallest.ai/atoms/v1"


class AtomsClient:
    """
    Convenience client for Atoms API operations that don't fit
    into the Call/Campaign/KB/Audience helpers.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ):
        self.base_url = base_url or os.environ.get("SMALLEST_BASE_URL", DEFAULT_BASE_URL)
        self.api_key = api_key or os.environ.get("SMALLEST_API_KEY", "")

    def _get_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def get_phone_numbers(self) -> Dict[str, Any]:
        """Get all acquired phone numbers for the organization."""
        url = f"{self.base_url}/product/phone-numbers"
        response = requests.get(url, headers=self._get_headers())
        response.raise_for_status()
        return response.json()  # type: ignore[no-any-return]
