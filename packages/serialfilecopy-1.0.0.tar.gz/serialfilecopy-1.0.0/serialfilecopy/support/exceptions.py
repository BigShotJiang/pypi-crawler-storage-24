"""
    Exceptions: defines exceptions for the app to raise/handle cases properly
"""


class SerialDeviceOpenError(Exception):
    """Raised when serial device failed to open"""

    def __init__(self):
        super().__init__('Failed to open serial device.')
