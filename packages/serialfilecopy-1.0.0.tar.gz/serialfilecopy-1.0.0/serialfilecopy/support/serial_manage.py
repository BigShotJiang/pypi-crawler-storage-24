#!/usr/bin/env python3
"""
    Serial Manager provides a communication interface with the serial device.
"""
import sys

import serial

from .exceptions import SerialDeviceOpenError


class SerialManager:
    # pylint: disable=E1101
    """
        SerialManager provides a communication interface with the serial device.
    """

    def __init__(self, serial_device_path, serial_device_rate):
        """
            Initial call is used to configure the default parameters
        """
        try:
            self.ser = None
            self.device_path = serial_device_path
            self.rate = serial_device_rate
            self.is_open = False
        except OSError as err:
            print(f"unable to open the serial device {serial_device_path}.")
            print(err)
            sys.exit(1)

    def is_dev_open(self):
        """
             is_open is used to check if the serial device is open.
        """
        return self.is_open

    def open_dev(self):
        """
        open_dev is used to open the serial port
        """
        try:
            self.ser = serial.Serial(self.device_path, baudrate=int(self.rate), timeout=2)
            if self.ser.is_open:
                self.is_open = True
                print(f'{self.device_path} opened.')
            else:
                self.is_open = False
                print(f'{self.device_path} cannot be opened.')
                raise SerialDeviceOpenError()
        except serial.SerialException as err:
            print(f"Serial port error: {err}")
            raise SerialDeviceOpenError() from err
        except SerialDeviceOpenError as err:
            raise err

    def close_dev(self):
        """
            close_dev is used to close the serial device
        """
        if self.ser is not None:
            self.ser.close()

    def read(self) -> bytes:
        """Read until newline and return raw bytes."""
        return self.ser.read_until()

    def read_raw(self) -> bytes:
        """
        Return whatever bytes are currently waiting in the input buffer (non-blocking).
        Returns b'' if nothing is available.
        """
        if self.ser is None or not self.is_open:
            return b""
        try:
            waiting = self.ser.in_waiting
            if waiting:
                return self.ser.read(waiting)
        except serial.SerialException:
            self.is_open = False
        return b""

    def exe_command(self, command):
        """Execute a serial command."""
        self.ser.write(command.encode())
        self.ser.flush()
