#!/usr/bin/env python3
"""
    APP CONTROLLER
"""
import hashlib
import os
import shlex
import sys
import time
from os.path import exists

from .exceptions import SerialDeviceOpenError
from .serial_manage import SerialManager

_CHUNK_SIZE = 256  # bytes per printf command — keeps shell arg length under limits


class AppController:
    """
    AppController handles login, file transfer, and optional verification
    over a serial connection to an embedded Linux device.
    """

    def __init__(self, serial_device_path, serial_device_baudrate,
                 username, password, source_file, dest_dir="/mnt"):
        """
        Open the serial port, log in, transfer the file, then optionally verify it.

        :param dest_dir: Remote directory to write the file into (default: /mnt)
        """
        self.file_data = None
        self.logged_in = False
        self.serial_baudrate = serial_device_baudrate
        self.serial_device_username = username
        self.serial_device_password = password
        self.source_file = source_file
        self.dest_dir = dest_dir.rstrip("/")
        self.serial_dev_path = serial_device_path

        self.ser_dev = SerialManager(serial_device_path, serial_device_baudrate)
        try:
            self.ser_dev.open_dev()
        except SerialDeviceOpenError:
            print(f"Failed to open the {serial_device_path} device.")
            sys.exit(1)

        if self.try_logging_in():
            self.get_destination_file_data(self.source_file)
            self.send_file_write_command(self.source_file)
            print("\nFile transfer complete.")
            if self._verify_transfer(self.source_file):
                print("Verification passed. :)")
            else:
                print("Verification failed — checksums do not match.")
        else:
            print("Failed to login or copy.")

    def __del__(self):
        """Close the serial port on cleanup."""
        try:
            if hasattr(self, 'ser_dev'):
                self.ser_dev.close_dev()
        except EnvironmentError as err:
            print(f'Unable to close serial device: {err}')

    def send_command(self, command):
        """Send a command over serial (appends CR+LF)."""
        if command == "\n":
            return
        self.ser_dev.exe_command(command + "\r\n")

    def _read_response(self, timeout=2.0) -> str:
        """
        Read available data from the device, waiting up to *timeout* seconds.
        Returns the decoded response string.
        """
        deadline = time.time() + timeout
        response = b""
        while time.time() < deadline:
            chunk = self.ser_dev.read_raw()
            if chunk:
                response += chunk
            else:
                time.sleep(0.05)
        return response.decode('utf-8', errors='replace')

    def is_logged_in(self) -> bool:
        """Return True if the device responds to `uname -a` with 'Linux'."""
        self.send_command("uname -a")
        response = self._read_response(timeout=1.5)
        self.logged_in = "Linux" in response
        return self.logged_in

    def try_logging_in(self) -> bool:
        """Attempt to log in. Returns True on success."""
        fail_msg = "Failed to login to the serial device."
        try:
            print("Checking login state...")
            if not self.is_logged_in():
                print("Not logged in — sending credentials.")
                self.send_command(self.serial_device_username)
                time.sleep(0.5)
                self.send_command(self.serial_device_password)
                time.sleep(0.5)
                if self.is_logged_in():
                    print("Logged in successfully.")
                    return True
                print(fail_msg)
                return False
            print("Already logged in.")
            return True
        except (EnvironmentError, OSError) as err:
            print(f"{fail_msg}\n{err}")
            return False

    def get_destination_file_data(self, file: str):
        """Read the entire source file into self.file_data as bytes."""
        if not exists(file):
            print(f'Source file not found: {file}')
            sys.exit(1)
        try:
            with open(file, "rb") as f:
                self.file_data = f.read()
        except IOError as err:
            print(f'Error reading file: {err}')
            sys.exit(1)

    @staticmethod
    def _escape_bytes_for_printf(data: bytes) -> str:
        """
        Convert raw bytes to a shell-safe $'...' ANSI-C quoted string for printf.
        Every byte is emitted as \\xNN so no shell metacharacters can appear.
        """
        return "$'" + "".join(f"\\x{b:02x}" for b in data) + "'"

    def send_file_write_command(self, file: str):
        """Transfer self.file_data to the device using printf in _CHUNK_SIZE byte chunks."""
        total = len(self.file_data)
        if total == 0:
            print('Source file is empty — nothing to transfer.')
            return

        dest = shlex.quote(f"{self.dest_dir}/{os.path.basename(file)}")

        for chunk_start in range(0, total, _CHUNK_SIZE):
            chunk = self.file_data[chunk_start:chunk_start + _CHUNK_SIZE]
            byte_string = self._escape_bytes_for_printf(chunk)
            redirect = ">" if chunk_start == 0 else ">>"
            command = f"printf {byte_string} {redirect} {dest}"
            self.send_command(command)
            time.sleep(0.1)

            sent = chunk_start + len(chunk)
            pct = int((sent / total) * 100)
            sys.stdout.write(f"\rTransferring: {pct}% ({sent}/{total} bytes)")
            sys.stdout.flush()

        # release memory
        self.file_data = None

    def _local_md5(self, file: str) -> str:
        """Return the MD5 hex digest of a local file."""
        h = hashlib.md5()
        with open(file, "rb") as f:
            for block in iter(lambda: f.read(65536), b""):
                h.update(block)
        return h.hexdigest()

    def _verify_transfer(self, file: str) -> bool:
        """
        Verify the transferred file by comparing local md5sum with the remote md5sum output.
        Returns True if checksums match, False otherwise.
        """
        local_md5 = self._local_md5(file)
        dest = shlex.quote(f"{self.dest_dir}/{os.path.basename(file)}")
        self.send_command(f"md5sum {dest}")
        response = self._read_response(timeout=3.0)
        # md5sum output: "<hash>  <filename>"
        for line in response.splitlines():
            parts = line.split()
            if parts and len(parts[0]) == 32:
                return parts[0].lower() == local_md5.lower()
        return False
