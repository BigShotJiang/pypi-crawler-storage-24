#!/usr/bin/env python3
"""
    serialfilecopy CLI entry point
"""
import argparse
import os
import sys

from .support.app_controller import AppController
from .support.version import __version__


def main():
    """
    Transfer a file to an embedded Linux device over a serial connection.

    Usage:
        serialfilecopy <device> <baudrate> <username> <password> <source_file> [--dest DIR]

    Example:
        serialfilecopy /dev/ttyUSB0 115200 root mypassword firmware.bin
        serialfilecopy /dev/ttyUSB0 115200 root mypassword firmware.bin --dest /tmp
    """
    parser = argparse.ArgumentParser(
        prog='serialfilecopy',
        description='Transfer a file to an embedded Linux device over serial.',
    )
    parser.add_argument('--version', '-v', action='version', version=f'serialfilecopy {__version__}')
    parser.add_argument('device',      help='Serial port path (e.g. /dev/ttyUSB0, COM4)')
    parser.add_argument('baudrate',    help='Baud rate (e.g. 115200)')
    parser.add_argument('username',    help='Login username on the target device')
    parser.add_argument('password',    help='Login password on the target device')
    parser.add_argument('source_file', help='Path to the local file to transfer')
    parser.add_argument(
        '--dest', '-D',
        default='/mnt',
        metavar='DIR',
        help='Destination directory on the target device (default: /mnt)',
    )

    args = parser.parse_args()

    # Validate source file exists before opening serial port
    if not os.path.isfile(args.source_file):
        print(f'ERROR: source file not found: {args.source_file}')
        sys.exit(1)

    # Validate baudrate is a positive integer
    try:
        baud = int(args.baudrate)
        if baud <= 0:
            raise ValueError
    except ValueError:
        print(f'ERROR: baudrate must be a positive integer, got: {args.baudrate!r}')
        sys.exit(1)

    AppController(
        serial_device_path=args.device,
        serial_device_baudrate=args.baudrate,
        username=args.username,
        password=args.password,
        source_file=args.source_file,
        dest_dir=args.dest,
    )
