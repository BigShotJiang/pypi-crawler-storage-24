"""
    Entry point for `python -m serialfilecopy`
"""
from .cli import main

main()
