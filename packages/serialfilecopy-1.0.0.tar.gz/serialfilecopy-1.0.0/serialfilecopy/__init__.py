"""
    serialfilecopy — file transfer utility over serial port
"""
from .support.version import __version__
