"""
Tests for serialfilecopy CLI argument parsing and validation
"""
import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from serialfilecopy.cli import main


@pytest.fixture
def real_file(tmp_path):
    """Create a real temporary file to use as source_file."""
    f = tmp_path / "test.bin"
    f.write_bytes(b'\x00\x01\x02\x03' * 16)
    return str(f)


class TestCliValidation:
    def test_missing_source_file_exits(self, monkeypatch):
        monkeypatch.setattr(sys, 'argv', [
            'serialfilecopy', '/dev/ttyUSB0', '115200', 'root', 'pass', '/nonexistent/file.bin'
        ])
        with pytest.raises(SystemExit) as exc:
            main()
        assert exc.value.code == 1

    def test_invalid_baudrate_exits(self, monkeypatch, real_file):
        monkeypatch.setattr(sys, 'argv', [
            'serialfilecopy', '/dev/ttyUSB0', 'notanumber', 'root', 'pass', real_file
        ])
        with pytest.raises(SystemExit) as exc:
            main()
        assert exc.value.code == 1

    def test_negative_baudrate_exits(self, monkeypatch, real_file):
        monkeypatch.setattr(sys, 'argv', [
            'serialfilecopy', '/dev/ttyUSB0', '-9600', 'root', 'pass', real_file
        ])
        with pytest.raises(SystemExit):
            main()

    def test_zero_baudrate_exits(self, monkeypatch, real_file):
        monkeypatch.setattr(sys, 'argv', [
            'serialfilecopy', '/dev/ttyUSB0', '0', 'root', 'pass', real_file
        ])
        with pytest.raises(SystemExit) as exc:
            main()
        assert exc.value.code == 1

    def test_version_flag(self, monkeypatch):
        monkeypatch.setattr(sys, 'argv', ['serialfilecopy', '--version'])
        with pytest.raises(SystemExit) as exc:
            main()
        assert exc.value.code == 0
