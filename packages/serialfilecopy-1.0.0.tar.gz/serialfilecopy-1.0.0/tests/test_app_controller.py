"""
Tests for serialfilecopy AppController logic (no hardware required)
"""
import hashlib
import os
import sys
import types

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from serialfilecopy.support.app_controller import AppController, _CHUNK_SIZE


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_controller() -> AppController:
    """
    Return a bare AppController instance with no serial port opened,
    suitable for testing pure logic methods.
    """
    obj = object.__new__(AppController)
    obj.dest_dir = "/mnt"
    obj.file_data = None
    obj.logged_in = False
    return obj


# ── Tests: byte escaping ──────────────────────────────────────────────────────

class TestEscapeBytesForPrintf:
    def test_empty_bytes(self):
        result = AppController._escape_bytes_for_printf(b"")
        assert result == "$''"

    def test_simple_ascii(self):
        result = AppController._escape_bytes_for_printf(b"ABC")
        assert result == "$'\\x41\\x42\\x43'"

    def test_single_quote_is_escaped(self):
        """A single-quote byte (0x27) must not break the shell command."""
        result = AppController._escape_bytes_for_printf(b"\x27")
        assert "\\x27" in result
        assert "'" not in result.replace("$'", "").replace("'", "X").replace("X", "", 1)

    def test_null_byte(self):
        result = AppController._escape_bytes_for_printf(b"\x00")
        assert "\\x00" in result

    def test_all_bytes_are_hex_escaped(self):
        data = bytes(range(256))
        result = AppController._escape_bytes_for_printf(data)
        assert result.startswith("$'")
        assert result.endswith("'")
        # Every byte should produce exactly \xNN (4 chars)
        inner = result[2:-1]  # strip $' and '
        assert len(inner) == 256 * 4

    def test_output_has_no_unescaped_special_chars(self):
        """The result should be safely quoted — no raw shell metacharacters."""
        data = b"hello world; rm -rf /; echo"
        result = AppController._escape_bytes_for_printf(data)
        # Result is always $'\xNN...' — no spaces or semicolons outside quotes
        assert " " not in result
        assert ";" not in result


# ── Tests: file reading ───────────────────────────────────────────────────────

class TestGetDestinationFileData:
    def test_reads_file_correctly(self, tmp_path):
        src = tmp_path / "test.bin"
        src.write_bytes(b'\xDE\xAD\xBE\xEF' * 10)
        ctrl = _make_controller()
        ctrl.get_destination_file_data(str(src))
        assert ctrl.file_data == b'\xDE\xAD\xBE\xEF' * 10

    def test_reads_empty_file(self, tmp_path):
        src = tmp_path / "empty.bin"
        src.write_bytes(b'')
        ctrl = _make_controller()
        ctrl.get_destination_file_data(str(src))
        assert ctrl.file_data == b''

    def test_missing_file_exits(self, tmp_path):
        ctrl = _make_controller()
        with pytest.raises(SystemExit) as exc:
            ctrl.get_destination_file_data(str(tmp_path / "ghost.bin"))
        assert exc.value.code == 1

    def test_large_file_reads_completely(self, tmp_path):
        data = os.urandom(100_000)
        src = tmp_path / "large.bin"
        src.write_bytes(data)
        ctrl = _make_controller()
        ctrl.get_destination_file_data(str(src))
        assert ctrl.file_data == data


# ── Tests: chunking ───────────────────────────────────────────────────────────

class TestChunking:
    def test_chunk_size_constant(self):
        assert _CHUNK_SIZE > 0

    def test_single_chunk_for_small_data(self):
        data = b'\x01' * (_CHUNK_SIZE - 1)
        chunks = [data[i:i + _CHUNK_SIZE] for i in range(0, len(data), _CHUNK_SIZE)]
        assert len(chunks) == 1

    def test_exact_chunk_boundary(self):
        data = b'\x02' * _CHUNK_SIZE
        chunks = [data[i:i + _CHUNK_SIZE] for i in range(0, len(data), _CHUNK_SIZE)]
        assert len(chunks) == 1

    def test_multiple_chunks(self):
        data = b'\x03' * (_CHUNK_SIZE * 3 + 1)
        chunks = [data[i:i + _CHUNK_SIZE] for i in range(0, len(data), _CHUNK_SIZE)]
        assert len(chunks) == 4

    def test_chunks_reassemble_to_original(self):
        data = os.urandom(_CHUNK_SIZE * 5 + 17)
        chunks = [data[i:i + _CHUNK_SIZE] for i in range(0, len(data), _CHUNK_SIZE)]
        assert b''.join(chunks) == data


# ── Tests: MD5 checksum ───────────────────────────────────────────────────────

class TestLocalMd5:
    def test_correct_md5(self, tmp_path):
        data = b"hello world"
        f = tmp_path / "test.txt"
        f.write_bytes(data)
        expected = hashlib.md5(data).hexdigest()
        ctrl = _make_controller()
        assert ctrl._local_md5(str(f)) == expected

    def test_empty_file_md5(self, tmp_path):
        f = tmp_path / "empty.txt"
        f.write_bytes(b'')
        expected = hashlib.md5(b'').hexdigest()
        ctrl = _make_controller()
        assert ctrl._local_md5(str(f)) == expected

    def test_large_file_md5(self, tmp_path):
        data = os.urandom(200_000)
        f = tmp_path / "big.bin"
        f.write_bytes(data)
        expected = hashlib.md5(data).hexdigest()
        ctrl = _make_controller()
        assert ctrl._local_md5(str(f)) == expected


# ── Tests: verify transfer response parsing ───────────────────────────────────

class TestVerifyTransfer:
    def test_matching_checksum_returns_true(self, tmp_path, monkeypatch):
        data = b"test content"
        f = tmp_path / "file.bin"
        f.write_bytes(data)
        expected_md5 = hashlib.md5(data).hexdigest()

        ctrl = _make_controller()
        # Stub send_command and _read_response
        monkeypatch.setattr(ctrl, 'send_command', lambda cmd: None)
        monkeypatch.setattr(ctrl, '_read_response',
                            lambda timeout=3.0: f"{expected_md5}  /mnt/file.bin\n")
        assert ctrl._verify_transfer(str(f)) is True

    def test_mismatched_checksum_returns_false(self, tmp_path, monkeypatch):
        data = b"test content"
        f = tmp_path / "file.bin"
        f.write_bytes(data)

        ctrl = _make_controller()
        monkeypatch.setattr(ctrl, 'send_command', lambda cmd: None)
        monkeypatch.setattr(ctrl, '_read_response',
                            lambda timeout=3.0: "deadbeef" * 4 + "  /mnt/file.bin\n")
        assert ctrl._verify_transfer(str(f)) is False

    def test_empty_response_returns_false(self, tmp_path, monkeypatch):
        f = tmp_path / "file.bin"
        f.write_bytes(b"data")

        ctrl = _make_controller()
        monkeypatch.setattr(ctrl, 'send_command', lambda cmd: None)
        monkeypatch.setattr(ctrl, '_read_response', lambda timeout=3.0: "")
        assert ctrl._verify_transfer(str(f)) is False

    def test_garbled_response_returns_false(self, tmp_path, monkeypatch):
        f = tmp_path / "file.bin"
        f.write_bytes(b"data")

        ctrl = _make_controller()
        monkeypatch.setattr(ctrl, 'send_command', lambda cmd: None)
        monkeypatch.setattr(ctrl, '_read_response',
                            lambda timeout=3.0: "garbled output no hash here")
        assert ctrl._verify_transfer(str(f)) is False
