# SerialFileCopy

A command-line utility for transferring files over a serial port to embedded Linux devices using `printf` commands.

## Installation

```sh
pip install serialfilecopy
```

## Usage

```sh
serialfilecopy <device> <baudrate> <username> <password> <source_file>
```

**Example:**

```sh
serialfilecopy /dev/ttyUSB0 115200 root mypassword /path/to/firmware.bin
```

The tool will:
1. Open the serial port
2. Log in to the device (or detect an existing session)
3. Transfer the file in 256-byte chunks using `printf` commands into `/mnt/<filename>`
4. Report progress as a percentage

## Requirements

- Python 3.8+
- A serial-connected embedded Linux device
- The device must be reachable via username/password login over the serial console

## License

See [LICENSE](LICENSE).
