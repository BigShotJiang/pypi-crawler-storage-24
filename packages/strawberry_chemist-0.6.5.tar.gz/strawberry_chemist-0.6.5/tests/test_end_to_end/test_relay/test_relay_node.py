import asyncio
from typing import List

import pytest
import strawberry
from sqlalchemy import Integer, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from strawberry.utils.logging import StrawberryLogger

import strawberry_chemist as sc
from strawberry_chemist.relay import (
    compose_node_id,
    decode_node_id,
    encode_node_id,
    get_node_definition,
)
from tests.test_end_to_end.test_relay.schema import BookType, Base, Book


def test_simple_query(test_relay_client):
    response = test_relay_client.post("/", json={"query": "{ hello }"})
    assert response.json() == {"data": {"hello": "Hello, world!"}}


@pytest.fixture
async def relay_with_books(mock_sqlite_sqla_session):
    async with mock_sqlite_sqla_session as session:
        await (await session.connection()).run_sync(Base.metadata.create_all)

    async with mock_sqlite_sqla_session as session:
        session.add_all(
            [
                Book(title="The Hobbit"),
                Book(title="The Lord of the Rings"),
            ]
        )
        await session.commit()
        books = (
            (await session.execute(select(Book).order_by(Book.id.asc())))
            .scalars()
            .all()
        )

    return books


def test_node_field_is_explicit_new_public_api():
    class Base(DeclarativeBase):
        pass

    class Dummy(Base):
        __tablename__ = "dummy"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)

    @sc.type(model=Dummy)
    class ExplicitDummyNode(sc.Node):
        pass

    @strawberry.type
    class Query:
        node = sc.node_field(allowed_types=(ExplicitDummyNode,))

    schema = strawberry.Schema(query=Query)
    field = schema.schema_converter.type_map["Query"].definition.fields[0]

    assert field.name == "node"
    assert field.arguments[0].python_name == "id"
    assert field.arguments[0].type_annotation.annotation is strawberry.ID


def test_node_types_implement_node_interface_automatically():
    class Base(DeclarativeBase):
        pass

    class Dummy(Base):
        __tablename__ = "dummy_node"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)

    @sc.type(model=Dummy)
    class InterfaceDummyNode(sc.Node):
        pass

    @strawberry.type
    class Query:
        hello: str = "world"

    schema = strawberry.Schema(query=Query, types=(InterfaceDummyNode,))
    sdl = schema.as_str()

    assert "interface Node" in sdl
    assert "type InterfaceDummyNode implements Node" in sdl
    assert [
        interface.name
        for interface in InterfaceDummyNode.__strawberry_definition__.interfaces
    ] == ["Node"]


def test_unrestricted_node_field_uses_node_interface_with_schema_visible_nodes():
    class Base(DeclarativeBase):
        pass

    class BookModel(Base):
        __tablename__ = "late_book"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)

    class ShelfModel(Base):
        __tablename__ = "late_shelf"
        slug: Mapped[str] = mapped_column(primary_key=True)

    @sc.type(model=BookModel)
    class LateBookNode(sc.Node):
        pass

    @strawberry.type
    class Query:
        node = sc.node_field()

    @sc.type(model=ShelfModel)
    class LateShelfNode(sc.Node):
        id = sc.node_id(ids=("slug",))
        pass

    schema = strawberry.Schema(query=Query, types=(LateBookNode, LateShelfNode))
    sdl = schema.as_str()

    assert "node(id: ID!): Node" in sdl
    assert "type LateBookNode implements Node" in sdl
    assert "type LateShelfNode implements Node" in sdl


def test_node_id_codec_applies_to_ids_and_helper_api():
    class Base(DeclarativeBase):
        pass

    class Dummy(Base):
        __tablename__ = "dummy_codec"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)

        def __init__(self, id: int):
            self.id = id

    codec = sc.relay.IntRegistryCodec(registry={Dummy: 7})

    @sc.type(model=Dummy)
    class CodecDummyNode(sc.Node):
        id = sc.node_id(codec=codec)
        pass

    node = Dummy(3)

    @strawberry.type
    class Query:
        @strawberry.field
        def dummy(self) -> CodecDummyNode:
            return node

    schema = strawberry.Schema(query=Query)

    assert encode_node_id(schema, CodecDummyNode, source=node) == strawberry.ID("7:3")
    assert encode_node_id(schema, CodecDummyNode, values=(3,)) == strawberry.ID("7:3")
    assert decode_node_id(schema, "7:3").node_type is CodecDummyNode

    result = asyncio.run(schema.execute("{ dummy { id } }"))
    assert result.data == {"dummy": {"id": "7:3"}}
    assert result.errors is None


def test_global_default_relay_codec_applies_before_schema_build():
    class Base(DeclarativeBase):
        pass

    class Dummy(Base):
        __tablename__ = "dummy_global_codec"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)

        def __init__(self, id: int):
            self.id = id

    codec = sc.relay.IntRegistryCodec(registry={Dummy: 9})

    @sc.type(model=Dummy)
    class GlobalCodecDummyNode(sc.Node):
        pass

    node = Dummy(4)

    @strawberry.type
    class Query:
        @strawberry.field
        def dummy(self) -> GlobalCodecDummyNode:
            return node

    sc.configure(default_relay_id_codec=codec)
    schema = strawberry.Schema(query=Query)

    assert encode_node_id(schema, GlobalCodecDummyNode, source=node) == strawberry.ID(
        "9:4"
    )
    assert encode_node_id(schema, GlobalCodecDummyNode, values=(4,)) == strawberry.ID(
        "9:4"
    )
    assert decode_node_id(schema, "9:4").node_type is GlobalCodecDummyNode

    result = asyncio.run(schema.execute("{ dummy { id } }"))
    assert result.data == {"dummy": {"id": "9:4"}}
    assert result.errors is None


def test_schema_types_preserve_explicit_non_node_types() -> None:
    class Base(DeclarativeBase):
        pass

    class Dummy(Base):
        __tablename__ = "dummy_preserved_node"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)

    class PreviewModel(Base):
        __tablename__ = "dummy_preserved_preview"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)
        locale: Mapped[str] = mapped_column()
        title: Mapped[str] = mapped_column()

    @strawberry.interface
    class Preview:
        locale: str

    @sc.type(model=PreviewModel)
    class DetachedPreview(Preview):
        locale: str
        title: str

    @sc.type(model=Dummy)
    class PreserveDummyNode(sc.Node):
        pass

    @strawberry.type
    class Query:
        node = sc.node_field(allowed_types=(PreserveDummyNode,))

        @strawberry.field
        def preview(self) -> Preview:
            return DetachedPreview(locale="fr", title="Bilbo")

    schema = strawberry.Schema(query=Query, types=(DetachedPreview,))
    sdl = schema.as_str()

    assert "type DetachedPreview implements Preview" in sdl
    result = schema.execute_sync(
        "{ preview { __typename locale ... on DetachedPreview { title } } }"
    )
    assert result.errors is None
    assert result.data == {
        "preview": {
            "__typename": "DetachedPreview",
            "locale": "fr",
            "title": "Bilbo",
        }
    }


def test_decode_node_id_rejects_allowed_type_mismatch():
    class Base(DeclarativeBase):
        pass

    class BookModel(Base):
        __tablename__ = "decode_book"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)

    class ShelfModel(Base):
        __tablename__ = "decode_shelf"
        slug: Mapped[str] = mapped_column(primary_key=True)

    @sc.type(model=BookModel)
    class DecodeBookNode(sc.Node):
        pass

    @sc.type(model=ShelfModel)
    class DecodeShelfNode(sc.Node):
        id = sc.node_id(ids=("slug",))
        pass

    @strawberry.type
    class Query:
        node = sc.node_field()

    schema = strawberry.Schema(query=Query, types=(DecodeBookNode, DecodeShelfNode))

    with pytest.raises(ValueError, match="Unknown node token"):
        decode_node_id(
            schema,
            "DecodeShelfNode_main",
            allowed_types=(DecodeBookNode,),
        )


@pytest.mark.asyncio
async def test_node_type_uses_registered_definition(test_relay_client):
    schema = test_relay_client.app.schema
    book_type = schema.schema_converter.type_map["BookType"]

    assert book_type.definition.name == "BookType"
    assert book_type.definition.origin == BookType
    definition = get_node_definition(BookType)
    assert definition is not None
    assert definition.model is Book
    assert definition.ids == ("id",)


@pytest.mark.asyncio
async def test_node_default_ids(relay_with_books, test_relay_client):
    books: List[Book] = relay_with_books
    definition = get_node_definition(BookType)
    assert definition is not None

    query = "{ allBooks { id title } }"
    result = test_relay_client.post("/", json={"query": query}).json()

    assert "errors" not in result
    assert "data" in result
    assert set(book["id"] for book in result["data"]["allBooks"]) == {
        compose_node_id(book, definition) for book in books
    }
    assert set(book["title"] for book in result["data"]["allBooks"]) == {
        book.title for book in books
    }


@pytest.mark.asyncio
async def test_node_get_by_id(relay_with_books, test_relay_client):
    books: List[Book] = relay_with_books
    definition = get_node_definition(BookType)
    assert definition is not None
    book_relay_id = compose_node_id(books[1], definition)

    query = (
        f'{{ node(id: "{book_relay_id}") {{ __typename ... on BookType {{ id }} }} }}'
    )
    response = test_relay_client.post("/", json={"query": query})
    result = response.json()

    assert "errors" not in result
    assert "data" in result
    assert book_relay_id == result["data"]["node"]["id"]


@pytest.mark.asyncio
async def test_get_by_id_node_field(relay_with_books, test_relay_client):
    books: List[Book] = relay_with_books
    definition = get_node_definition(BookType)
    assert definition is not None
    book_relay_id = compose_node_id(books[1], definition)
    book_title = books[1].title

    query = f'{{ bookById(id: "{book_relay_id}") {{ __typename ... on BookType {{ id title }} }} }}'
    response = test_relay_client.post("/", json={"query": query})
    result = response.json()

    assert "errors" not in result
    assert book_relay_id == result["data"]["bookById"]["id"]
    assert book_title == result["data"]["bookById"]["title"]


@pytest.mark.asyncio
async def test_get_by_id_node_field_no_permission(
    relay_with_books, test_relay_client, monkeypatch
):
    books: List[Book] = relay_with_books
    definition = get_node_definition(BookType)
    assert definition is not None
    book_relay_id = compose_node_id(books[1], definition)

    query = f'{{ noPermissionBookById(id: "{book_relay_id}") {{ __typename ... on BookType {{ id title }} }} }}'
    with monkeypatch.context() as m:
        m.setattr(StrawberryLogger, "error", lambda *args, **kwargs: None)
        with pytest.raises(PermissionError):
            test_relay_client.post("/", json={"query": query}).json()


@pytest.mark.asyncio
async def test_get_by_id_node_field_not_found(relay_with_books, test_relay_client):
    definition = get_node_definition(BookType)
    assert definition is not None
    book_relay_id = definition.codec.encode(definition.node_name, ("320",))

    query = f'{{ bookById(id: "{book_relay_id}") {{ __typename ... on BookType {{ id title }} }} }}'
    response = test_relay_client.post("/", json={"query": query})
    result = response.json()

    assert "errors" not in result
    assert result["data"]["bookById"] is None
