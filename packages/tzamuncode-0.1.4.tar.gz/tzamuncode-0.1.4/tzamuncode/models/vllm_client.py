"""
vLLM Client for TzamunCode CLI
Provides faster inference using vLLM OpenAI-compatible API
"""

import requests
import os
from typing import Iterator, List, Dict, Optional


class VLLMClient:
    """Client for vLLM server using OpenAI-compatible API"""
    
    def __init__(self, base_url: str = None, model: str = "deepseek-coder-7b"):
        # Use environment variable if available, otherwise default to localhost
        if base_url is None:
            base_url = os.getenv('VLLM_BASE_URL', 'http://localhost:8000')
        self.base_url = base_url.rstrip('/')
        self.model = model
        self.api_url = f"{self.base_url}/v1"
    
    def chat(self, messages: List[Dict[str, str]], stream: bool = True) -> Iterator[str]:
        """
        Send chat request to vLLM server
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            stream: Whether to stream the response
            
        Yields:
            Response chunks as strings
        """
        url = f"{self.api_url}/chat/completions"
        
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": stream,
            "temperature": 0.7,
            "max_tokens": 2000,  # Reduced to fit within 4096 context with system prompt
        }
        
        try:
            response = requests.post(
                url,
                json=payload,
                stream=stream,
                timeout=60
            )
            
            if response.status_code != 200:
                error_detail = response.text
                yield f"\n❌ vLLM Error ({response.status_code}): {error_detail}\n"
                return
            
            response.raise_for_status()
            
            if stream:
                for line in response.iter_lines():
                    if line:
                        line = line.decode('utf-8')
                        if line.startswith('data: '):
                            data = line[6:]  # Remove 'data: ' prefix
                            if data.strip() == '[DONE]':
                                break
                            
                            try:
                                import json
                                chunk = json.loads(data)
                                if 'choices' in chunk and len(chunk['choices']) > 0:
                                    delta = chunk['choices'][0].get('delta', {})
                                    content = delta.get('content', '')
                                    if content:
                                        yield content
                            except json.JSONDecodeError:
                                continue
            else:
                result = response.json()
                if 'choices' in result and len(result['choices']) > 0:
                    content = result['choices'][0]['message']['content']
                    yield content
                    
        except requests.exceptions.RequestException as e:
            yield f"\n❌ Error connecting to vLLM server: {e}\n"
            yield "Make sure vLLM server is running on http://localhost:8000\n"
    
    def list_models(self) -> List[str]:
        """List available models from vLLM server"""
        try:
            url = f"{self.api_url}/models"
            response = requests.get(url, timeout=5)
            response.raise_for_status()
            
            data = response.json()
            if 'data' in data:
                return [model['id'] for model in data['data']]
            return [self.model]
        except:
            return [self.model]
    
    def chat_stream(self, messages: List[Dict[str, str]]) -> Iterator[str]:
        """
        Stream chat responses (alias for chat with stream=True)
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            
        Yields:
            Response chunks as strings
        """
        yield from self.chat(messages, stream=True)
    
    def generate(self, prompt: str, stream: bool = True) -> Iterator[str]:
        """
        Generate completion from prompt
        
        Args:
            prompt: Input prompt
            stream: Whether to stream the response
            
        Yields:
            Response chunks
        """
        messages = [{"role": "user", "content": prompt}]
        yield from self.chat(messages, stream=stream)
