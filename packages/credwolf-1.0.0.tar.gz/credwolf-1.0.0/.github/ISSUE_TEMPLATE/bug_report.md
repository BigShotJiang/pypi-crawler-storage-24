---
name: Bug report
about: Report a bug or unexpected behavior
title: ""
labels: bug
assignees: ""
---

**Describe the bug**
A clear description of what happened.

**Command**
The exact `credwolf` command you ran (redact sensitive values):

```bash
credwolf ...
```

**Output**
Paste the full output (use `-vvv` for trace-level detail):

```
...
```

**Expected behavior**
What you expected to happen.

**Environment**
- OS: [e.g. Kali 2025.1, Ubuntu 24.04]
- Python version: [e.g. 3.12.3]
- CredWolf version: [e.g. 1.0.0]
- Install method: [e.g. uv, pipx, pip]
- Target: [e.g. Windows Server 2022 DC]
