from textual import getters
from textual.binding import Binding
from textual.widgets import Button

from tooi.app import TooiApp


class MenuButton(Button):
    app = getters.app(TooiApp)

    DEFAULT_CSS = """
    MenuButton {
        width: 100% ;
        content-align: left middle;
        text-align: left;
    }
    """

    # Add space binding
    BINDINGS = [
        Binding("enter,space", "press", "Press button", show=False),
    ]

    def __init__(self, label: str, *, id: str | None = None):
        label = f"< {label.strip()} >"
        super().__init__(label, id=id, compact=True)

    def show(self):
        self.disabled = False
        self.display = True

    def hide(self):
        self.disabled = True
        self.display = False
