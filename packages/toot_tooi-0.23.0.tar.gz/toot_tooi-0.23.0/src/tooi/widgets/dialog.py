import asyncio
from typing_extensions import override

from textual import getters, on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal
from textual.widgets import Button, Label
from textual.widgets._button import ButtonVariant

from tooi.api import statuses
from tooi.app import TooiApp
from tooi.entities import Status
from tooi.screens.modal import ModalScreen, ModalTitle
from tooi.widgets.status_bar import StatusBar


class ConfirmationDialog(ModalScreen[bool]):
    app = getters.app(TooiApp)

    DEFAULT_CSS = """
    ConfirmationDialog {
        .modal_container {
            max-width: 60;
        }
        #buttons {
            margin-top: 1;
            height: auto;
            align: right middle;
        }
        #modal_text {
            width: 100%;
            margin: 1 1 0 1;
        }
        #confirm_button,#cancel_button {
            margin-right: 1;
        }
    }
    """

    BINDINGS = [
        Binding("up,left,k,h", "focus_previous"),
        Binding("down,right,j,l", "focus_next"),
        Binding("space", "submit"),
    ]

    AUTO_FOCUS = "#confirm_button"

    def __init__(
        self,
        modal_title: str,
        *,
        modal_text: str | None = None,
        confirm_label: str = "Confirm",
        cancel_label: str = "Cancel",
        confirm_button_variant: ButtonVariant = "primary",
        cancel_button_variant: ButtonVariant = "default",
    ):
        self.modal_title = modal_title
        self.modal_text = modal_text
        self.confirm_label = confirm_label
        self.cancel_label = cancel_label
        self.confirm_button_variant: ButtonVariant = confirm_button_variant
        self.cancel_button_variant: ButtonVariant = cancel_button_variant

        super().__init__()

    def compose_modal(self) -> ComposeResult:
        yield ModalTitle(self.modal_title)

        if self.modal_text:
            yield Label(self.modal_text, id="modal_text")

        yield Horizontal(
            Button(
                self.cancel_label,
                id="cancel_button",
                variant=self.cancel_button_variant,
                flat=True,
            ),
            Button(
                self.confirm_label,
                id="confirm_button",
                variant=self.confirm_button_variant,
                flat=True,
            ),
            id="buttons",
        )

    def action_focus_next(self):
        self.app.screen.focus_next()

    def action_focus_previous(self):
        self.app.screen.focus_previous()

    def action_submit(self):
        if isinstance(self.focused, Button):
            self.focused.press()

    @on(Button.Pressed)
    def on_button_pressed(self, message: Button.Pressed):
        message.stop()

        if message.button.id == "confirm_button":
            self.on_confirm()
        elif message.button.id == "cancel_button":
            self.on_dismiss()

    def on_confirm(self) -> None:
        self.dismiss(True)

    def on_dismiss(self) -> None:
        self.dismiss(False)


class DeleteStatusDialog(ConfirmationDialog):
    def __init__(self, status: Status):
        self.status = status
        super().__init__(
            modal_title="Delete status?",
            modal_text="Are you sure you want to delete your status?",
            confirm_label="Delete",
            confirm_button_variant="error",
            cancel_label="Cancel",
        )

    @override
    def compose_modal(self) -> ComposeResult:
        yield from super().compose_modal()
        yield StatusBar()

    @override
    def on_confirm(self) -> None:
        self.delete()

    @work
    async def delete(self):
        success = False
        async with self.query_one(StatusBar).run_with_progress(
            progress="Deleting status...",
            success="Status deleted",
            error="Failed to delete status",
        ):
            await statuses.delete(self.status.id)
            success = True

        if success:
            await asyncio.sleep(0.5)
            self.dismiss(True)
