import asyncio
import logging
import shutil
import ssl
import tempfile
from hashlib import sha256
from pathlib import Path
from typing import NamedTuple
from urllib.parse import urlparse

from aiohttp import ClientSession, TCPConnector
import certifi
from platformdirs import user_cache_path

from tooi import APP_NAME
from tooi.utils.file import format_size

logger = logging.getLogger(__name__)


def get_cache_dir() -> Path:
    return user_cache_path(APP_NAME, ensure_exists=True)


def get_cache_db_path() -> Path:
    return get_cache_dir() / "cache.db"


def get_images_cache_dir() -> Path:
    cache_dir = get_cache_dir() / "images"
    cache_dir.mkdir(exist_ok=True)
    return cache_dir


# TODO: limit cache size to a reasonable amount
# TODO: use async file access
async def download_image_cached(url: str) -> Path:
    target_path = image_cache_path(url)

    if target_path.exists():
        # Touch to indicate file was used, used in cache invalidation
        target_path.touch()
    else:
        logger.debug(f"Downloading image {url} to {target_path}")

        ssl_context = ssl.create_default_context(cafile=certifi.where())
        async with ClientSession(connector=TCPConnector(ssl=ssl_context)) as session:
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                async with session.get(url) as response:
                    response.raise_for_status()
                    async for chunk in response.content.iter_chunked(128 * 1024):
                        tmp.write(chunk)
            shutil.move(tmp.name, target_path)

    return target_path


async def download_images_cached(urls: list[str]) -> list[Path]:
    downloads = [download_image_cached(url) for url in urls]
    return await asyncio.gather(*downloads)


def image_cache_path(url: str) -> Path:
    cache_dir = get_images_cache_dir()
    path = urlparse(url).path
    suffix = Path(path).suffix
    url_hash = sha256(url.encode()).hexdigest()
    filename = url_hash + suffix
    return cache_dir / filename


class CachedFile(NamedTuple):
    atime: float
    size: float
    path: Path


def purge_image_cache(max_size: int):
    logger.info("Purging image cache...")
    files: list[CachedFile] = []
    total_size = 0

    cache_path = get_images_cache_dir()
    for path in cache_path.iterdir():
        if path.is_file():
            stat = path.stat()
            files.append(CachedFile(stat.st_atime, stat.st_size, path))
            total_size += stat.st_size

    logger.info(f"Image cache size: {format_size(total_size)}/{format_size(max_size)}")

    if total_size < max_size:
        return

    files.sort(key=lambda x: x.atime)

    for file in files:
        logger.info(f"Purging: {file.path.name} ({format_size(file.size)})")
        file.path.unlink()
        total_size -= file.size
        if total_size < max_size:
            break
