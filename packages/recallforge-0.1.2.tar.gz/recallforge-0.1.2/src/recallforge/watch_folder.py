"""Folder watch sidecar/daemon for RecallForge.

Lightweight polling implementation (no heavy framework):
- include/exclude glob filtering
- debounced batch processing
- start/stop/list/status controls
- integrates with existing storage ingest/index paths
"""

from __future__ import annotations

import fnmatch
import json
import logging
import os
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from queue import Empty, Queue
from typing import Any, Dict, List, Optional

from .documents import is_document_file
from .video import is_video_file

logger = logging.getLogger(__name__)


@dataclass
class WatchConfig:
    folder_path: str
    collection: str = "default"
    recursive: bool = True
    include_globs: List[str] = field(default_factory=lambda: ["**/*"])
    exclude_globs: List[str] = field(default_factory=list)
    debounce_seconds: float = 2.0
    batch_size: int = 32
    scan_interval: float = 5.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WatchConfig":
        return cls(**data)


class WatchFolderDaemon:
    STATE_FILE_NAME = ".recallforge_watch_state.json"

    def __init__(self, storage: Any, backend: Any, store_path: Optional[str] = None):
        self.storage = storage
        self.backend = backend
        self.store_path = store_path or os.path.expanduser("~/.recallforge")

        self._lock = threading.Lock()
        self.watches: Dict[str, Dict[str, Any]] = {}
        self.queues: Dict[str, Queue] = {}
        self.running: Dict[str, threading.Event] = {}
        self.worker_threads: Dict[str, threading.Thread] = {}
        self.scan_threads: Dict[str, threading.Thread] = {}

    def _get_state_path(self) -> Path:
        return Path(self.store_path) / self.STATE_FILE_NAME

    def _save_state(self) -> None:
        try:
            p = self._get_state_path()
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                json.dump({"watches": self.watches}, f, indent=2)
        except Exception as e:
            logger.warning("Failed to save watch state: %s", e)

    def _candidate_files(self, root: Path, recursive: bool) -> List[Path]:
        files: List[Path] = []
        if recursive:
            pruned = {".git", "node_modules", "__pycache__", ".venv", "venv"}
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [
                    dirname for dirname in sorted(dirnames)
                    if dirname not in pruned and not dirname.startswith(".")
                ]
                for filename in sorted(filenames):
                    candidate = Path(dirpath) / filename
                    if candidate.is_file():
                        files.append(candidate)
            return files

        for child in sorted(root.iterdir()):
            if child.is_file():
                files.append(child)
        return files

    def _is_text_file(self, path: Path) -> bool:
        try:
            with path.open("rb") as handle:
                sample = handle.read(8192)
        except Exception:
            logger.warning("Failed to read file for text detection: %s", path)
            return False
        return b"\x00" not in sample

    def _is_image_file(self, path: Path) -> bool:
        return path.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tiff", ".tif", ".heic"}

    def _is_video_file(self, path: Path) -> bool:
        return is_video_file(path)

    def _is_document_file(self, path: Path) -> bool:
        return is_document_file(path)

    def _read_text_robust(self, path: Path) -> Optional[str]:
        for encoding in ("utf-8", "utf-8-sig", "latin-1"):
            try:
                return path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                continue
            except Exception:
                logger.warning("Failed to read %s with encoding %s", path, encoding)
                return None
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            logger.warning("Failed to read %s with error replacement", path)
            return None

    def _should_process(self, path: Path, config: WatchConfig) -> bool:
        root = Path(config.folder_path).expanduser().resolve()
        try:
            rel = path.resolve().relative_to(root).as_posix()
        except Exception:
            logger.warning("Failed to resolve relative path for %s", path)
            return False

        rel_path = Path(rel)

        def _match(pattern: str) -> bool:
            compact = pattern.replace("**/", "")
            return (
                fnmatch.fnmatch(rel, pattern)
                or fnmatch.fnmatch(rel, compact)
                or rel_path.match(pattern)
                or rel_path.match(compact)
            )

        if config.include_globs:
            if not any(_match(pat) for pat in config.include_globs):
                return False
        if config.exclude_globs:
            if any(_match(pat) for pat in config.exclude_globs):
                return False

        return (
            self._is_text_file(path)
            or self._is_image_file(path)
            or self._is_video_file(path)
            or self._is_document_file(path)
        )

    def _build_snapshot(self, config: WatchConfig) -> Dict[str, float]:
        root = Path(config.folder_path).expanduser().resolve()
        snap: Dict[str, float] = {}
        for p in self._candidate_files(root, config.recursive):
            if not self._should_process(p, config):
                continue
            try:
                rel = p.resolve().relative_to(root).as_posix()
                snap[rel] = p.stat().st_mtime
            except Exception:
                logger.warning("Failed to get stats for %s", p)
                continue
        return snap

    def _scanner_loop(self, watch_id: str) -> None:
        config = WatchConfig.from_dict(self.watches[watch_id]["config"])
        root = Path(config.folder_path).expanduser().resolve()
        queue = self.queues[watch_id]
        evt = self.running[watch_id]

        prev = self._build_snapshot(config)
        while evt.is_set():
            current = self._build_snapshot(config)

            # created/modified
            for rel, mtime in current.items():
                if rel not in prev:
                    queue.put({"path": str(root / rel), "type": "created", "timestamp": time.time()})
                elif mtime > prev[rel]:
                    queue.put({"path": str(root / rel), "type": "modified", "timestamp": time.time()})

            # deleted
            for rel in prev.keys() - current.keys():
                queue.put({"path": str(root / rel), "type": "deleted", "timestamp": time.time()})

            prev = current
            time.sleep(max(0.1, config.scan_interval))

    def _worker_loop(self, watch_id: str) -> None:
        queue = self.queues[watch_id]
        evt = self.running[watch_id]
        config = WatchConfig.from_dict(self.watches[watch_id]["config"])

        # path-keyed dedup dict: keeps the latest event per path, no timer churn
        pending: Dict[str, Dict[str, Any]] = {}
        last_flush = time.monotonic()

        while evt.is_set():
            # Drain the entire queue in one pass — dedup by path, keeping latest event.
            # This handles the polling model where the scanner may emit repeated
            # modified events for the same path across multiple scan cycles.
            try:
                while True:
                    item = queue.get_nowait()
                    pending[item["path"]] = item
            except Empty:
                pass

            now = time.monotonic()
            should_flush = len(pending) >= config.batch_size or (
                pending and now - last_flush >= max(0.05, config.debounce_seconds)
            )

            if should_flush:
                # Take exactly batch_size items (oldest-first), remove only those
                # from pending so the remainder stays for the next flush cycle.
                batch = sorted(pending.values(), key=lambda x: x["timestamp"])[: max(1, config.batch_size)]
                for item in batch:
                    pending.pop(item["path"])
                self._process_batch(watch_id, batch, config)
                last_flush = now
            else:
                # Nothing ready yet; yield CPU rather than busy-spin.
                time.sleep(0.05)

        # Shutdown path: drain anything still in the queue into pending, then
        # flush ALL remaining items so no work is dropped on stop.
        try:
            while True:
                item = queue.get_nowait()
                pending[item["path"]] = item
        except Empty:
            pass

        while pending:
            batch = sorted(pending.values(), key=lambda x: x["timestamp"])[: max(1, config.batch_size)]
            for item in batch:
                pending.pop(item["path"])
            self._process_batch(watch_id, batch, config)

    def _process_batch(self, watch_id: str, items: List[Dict[str, Any]], config: WatchConfig) -> None:
        """Process a pre-selected list of file-change items and update bookkeeping."""
        if hasattr(self.storage, "bulk_mode"):
            with self.storage.bulk_mode():
                for item in items:
                    self._process_file_change(item, config)
        else:
            for item in items:
                self._process_file_change(item, config)

        self.watches[watch_id]["last_processed"] = time.time()
        self.watches[watch_id]["processed_count"] = self.watches[watch_id].get("processed_count", 0) + len(items)
        self._save_state()

    def _process_file_change(self, item: Dict[str, Any], config: WatchConfig) -> None:
        root = Path(config.folder_path).expanduser().resolve()
        path = Path(item["path"])
        event_type = item["type"]

        try:
            rel_path = path.resolve().relative_to(root).as_posix()
        except Exception:
            logger.exception("Failed to resolve relative path for %s", path)
            return

        if event_type == "deleted":
            include_children = self._is_video_file(path) or self._is_document_file(path)
            if hasattr(self.storage, "delete_path"):
                self.storage.delete_path(rel_path, config.collection, include_children=include_children)
            else:
                self.storage.delete_memory(rel_path, config.collection)
            return

        if not path.exists():
            return

        if self._is_image_file(path):
            self.storage.index_image(
                path=str(path),
                collection=config.collection,
                embed_func=self.backend.embed_image,
                model="Qwen3-VL-Embedding-2B",
                stored_path=rel_path,
            )
            return

        if self._is_video_file(path) and hasattr(self.storage, "index_video"):
            self.storage.index_video(
                path=str(path),
                collection=config.collection,
                embed_text_func=self.backend.embed_text,
                embed_image_func=self.backend.embed_image,
                embed_video_func=getattr(self.backend, "embed_video", None),
                model="Qwen3-VL-Embedding-2B",
                stored_path=rel_path,
            )
            return

        if self._is_document_file(path) and hasattr(self.storage, "index_document_file"):
            self.storage.index_document_file(
                path=str(path),
                collection=config.collection,
                embed_func=self.backend.embed_text,
                model="Qwen3-VL-Embedding-2B",
                stored_path=rel_path,
            )
            return

        text = self._read_text_robust(path)
        if text:
            self.storage.upsert_memory(
                path=rel_path,
                text=text,
                collection=config.collection,
                embed_func=self.backend.embed_text,
                model="Qwen3-VL-Embedding-2B",
            )

    def start_watch(self, config: WatchConfig) -> str:
        root = Path(config.folder_path).expanduser().resolve()
        if not root.exists() or not root.is_dir():
            raise ValueError(f"Folder not found: {root}")

        with self._lock:
            for watch_id, info in self.watches.items():
                if Path(info["config"]["folder_path"]).expanduser().resolve() == root and info.get("status") == "running":
                    return watch_id

            watch_id = f"watch_{root.name}_{int(time.time())}"
            self.watches[watch_id] = {
                "config": config.to_dict(),
                "started_at": time.time(),
                "status": "running",
            }
            self.queues[watch_id] = Queue()
            self.running[watch_id] = threading.Event()
            self.running[watch_id].set()

            s = threading.Thread(target=self._scanner_loop, args=(watch_id,), daemon=True)
            w = threading.Thread(target=self._worker_loop, args=(watch_id,), daemon=True)
            s.start()
            w.start()

            self.scan_threads[watch_id] = s
            self.worker_threads[watch_id] = w
            self._save_state()
            return watch_id

    def stop_watch(self, watch_id: str) -> bool:
        if watch_id not in self.watches:
            return False

        with self._lock:
            if watch_id in self.running:
                self.running[watch_id].clear()

            if watch_id in self.scan_threads:
                self.scan_threads[watch_id].join(timeout=2)
                del self.scan_threads[watch_id]

            if watch_id in self.worker_threads:
                self.worker_threads[watch_id].join(timeout=2)
                del self.worker_threads[watch_id]

            self.queues.pop(watch_id, None)
            self.running.pop(watch_id, None)

            self.watches[watch_id]["status"] = "stopped"
            self.watches[watch_id]["stopped_at"] = time.time()
            self._save_state()
            return True

    def stop_all(self) -> int:
        count = 0
        for watch_id in list(self.watches.keys()):
            if self.stop_watch(watch_id):
                count += 1
        return count

    def list_watches(self) -> Dict[str, Dict[str, Any]]:
        out: Dict[str, Dict[str, Any]] = {}
        for watch_id, info in self.watches.items():
            out[watch_id] = {
                "status": info.get("status", "unknown"),
                "folder_path": info["config"]["folder_path"],
                "collection": info["config"].get("collection", "default"),
                "started_at": info.get("started_at"),
                "stopped_at": info.get("stopped_at"),
                "processed_count": info.get("processed_count", 0),
                "last_processed": info.get("last_processed"),
            }
        return out

    def get_watch_status(self, watch_id: str) -> Optional[Dict[str, Any]]:
        return self.list_watches().get(watch_id)


_daemon: Optional[WatchFolderDaemon] = None


def get_daemon(storage: Any, backend: Any, store_path: Optional[str] = None) -> WatchFolderDaemon:
    global _daemon
    if _daemon is None:
        _daemon = WatchFolderDaemon(storage, backend, store_path)
    return _daemon


def reset_daemon() -> None:
    global _daemon
    if _daemon:
        _daemon.stop_all()
    _daemon = None
