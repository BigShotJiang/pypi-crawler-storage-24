from __future__ import annotations

from .types import IntentDocument


def to_source(doc: IntentDocument) -> str:
    lines: list[str] = []

    for block in doc.blocks:
        if block.type == "divider":
            lines.append("---")
            continue

        if block.type == "table":
            for row in block.properties.get("rows", []):
                lines.append("| " + " | ".join(str(c) for c in row) + " |")
            continue

        keyword = block.type
        props = dict(block.properties)

        if block.type == "task" and str(props.get("status", "")).lower() == "done":
            keyword = "done"
            props.pop("status", None)

        # Special case: break block
        if block.type == "break":
            prop_parts = [f"{k}: {v}" for k, v in props.items()]
            lines.append("break: | " + " | ".join(prop_parts) if prop_parts else "break:")
            continue

        # Special case: code block
        if block.type == "code":
            lang = str(props.get("lang", ""))
            lines.append(f"```{lang}\n{block.content}\n```")
            continue

        parts = [f"{keyword}: {block.original_content or block.content}".rstrip()]
        for key, value in props.items():
            parts.append(f"{key}: {value}")

        lines.append(" | ".join(parts))

    return "\n".join(lines)
