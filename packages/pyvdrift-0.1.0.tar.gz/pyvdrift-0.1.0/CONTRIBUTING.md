# Contributing to pyvdrift

Thanks for your interest in contributing!

## Development Setup

```bash
git clone https://github.com/your-username/pyvdrift.git
cd pyvdrift
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest
```

## Code Style

- Python 3.10+ required
- Formatted with ruff (`ruff check . && ruff format .`)
- Type-checked with mypy (`mypy src/`)
- All public functions must have docstrings

## Pull Requests

1. Fork the repo and create a branch from `main`
2. Add tests for any new functionality
3. Ensure all tests pass
4. Submit a pull request

## Architecture

- `src/pyvdrift/tools/` — one module per package manager (uv, poetry, pip, etc.)
- `src/pyvdrift/parsers/` — pure file parsers, no tool knowledge
- `src/pyvdrift/checks/` — health checks that produce `CheckResult`
- `src/pyvdrift/core/` — scanner, drift engine, venv resolution

Each tool implements the `Tool` abstract interface in `tools/base.py`.
Each parser implements the `Parser` interface in `parsers/base.py`.
