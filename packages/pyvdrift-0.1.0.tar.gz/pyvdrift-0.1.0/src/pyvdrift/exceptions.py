"""Shared exceptions for pyvdrift."""


class PyvdriftError(Exception):
    """Base exception for all pyvdrift errors."""
