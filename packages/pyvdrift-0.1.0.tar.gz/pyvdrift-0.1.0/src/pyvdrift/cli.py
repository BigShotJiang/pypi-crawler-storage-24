"""CLI entry point for pyvdrift."""

from __future__ import annotations

import shutil
import time
from pathlib import Path

import typer

from pyvdrift.checks.deps_installed import DepsInstalledCheck
from pyvdrift.checks.deps_version import DepsVersionCheck
from pyvdrift.checks.interpreter_match import InterpreterMatchCheck
from pyvdrift.checks.lockfile_sync import LockfileSyncCheck
from pyvdrift.checks.stale_venv import StaleVenvCheck
from pyvdrift.checks.tool_available import ToolAvailableCheck
from pyvdrift.checks.venv_exists import VenvExistsCheck
from pyvdrift.checks.venv_healthy import VenvHealthyCheck
from pyvdrift.core.drift import detect_drift
from pyvdrift.core.interpreter import resolve_interpreter
from pyvdrift.core.project import CheckResult, DriftResult, Project
from pyvdrift.core.scanner import scan_projects
from pyvdrift.core.venv_detector import get_last_activated, resolve_venv
from pyvdrift.exceptions import PyvdriftError

app = typer.Typer(
    name="pyvdrift",
    help="Detect environment drift across all your Python projects.",
    no_args_is_help=True,
)

_ALL_CHECKS = [
    VenvExistsCheck,
    VenvHealthyCheck,
    InterpreterMatchCheck,
    DepsInstalledCheck,
    DepsVersionCheck,
    StaleVenvCheck,
    LockfileSyncCheck,
    ToolAvailableCheck,
]


def _enrich_project(project: Project) -> Project:
    """Fill in venv_path, interpreter, and last_activated."""
    project.venv_path = resolve_venv(project)
    if project.venv_path:
        project.interpreter = resolve_interpreter(project)
        project.last_activated = get_last_activated(project.venv_path)
    return project


def _run_checks(project: Project) -> list[CheckResult]:
    """Run all health checks against a project."""
    return [check.run(project) for check in _ALL_CHECKS]


@app.command()
def scan(
    path: str = typer.Argument("~", help="Root path to scan for Python projects"),
    depth: int = typer.Option(5, "--depth", "-d", help="Maximum directory depth"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    ignore: list[str] = typer.Option([], "--ignore", help="Patterns to ignore"),
    save: bool = typer.Option(False, "--save", help="Save found projects to config"),
) -> None:
    """Find all Python projects on your machine."""
    try:
        root = Path(path).expanduser()
        projects = scan_projects(root, max_depth=depth, ignore_patterns=ignore or None)

        for project in projects:
            _enrich_project(project)

        if json_output:
            from pyvdrift.output.json_output import projects_to_json
            typer.echo(projects_to_json(projects))
        else:
            from pyvdrift.output.console import print_scan_results
            print_scan_results(projects)

        if save:
            from pyvdrift.config import save_projects
            save_projects([str(p.path) for p in projects])
            typer.echo(f"Saved {len(projects)} project(s) to config.")

    except PyvdriftError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@app.command()
def check(
    path: str = typer.Argument(".", help="Project path to check"),
    fix: bool = typer.Option(False, "--fix", help="Show fix commands"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    include_dev: bool = typer.Option(False, "--include-dev", help="Include dev deps"),
) -> None:
    """Diff requirements vs actually installed packages."""
    try:
        project_path = Path(path).expanduser().resolve()
        projects = scan_projects(project_path, max_depth=0)

        if not projects:
            # Try the path itself as a project
            from pyvdrift.core.scanner import _detect_project, _is_python_project
            if _is_python_project(project_path):
                projects = [_detect_project(project_path)]

        if not projects:
            typer.echo("No Python project found at this path.", err=True)
            raise typer.Exit(1)

        project = _enrich_project(projects[0])
        result = detect_drift(project, include_dev=include_dev)

        if json_output:
            from pyvdrift.output.json_output import drift_to_json
            typer.echo(drift_to_json(result))
        else:
            from pyvdrift.output.console import print_drift_result
            print_drift_result(result)

            if fix:
                from pyvdrift.core.project import Toolchain
                for tc in project.toolchains:
                    if tc != Toolchain.UNKNOWN:
                        from pyvdrift.core.scanner import _TOOL_DETECTORS
                        for toolchain, tool_cls in _TOOL_DETECTORS:
                            if toolchain == tc:
                                typer.echo(f"Fix: {tool_cls.fix_hint(project.path)}")
                                break

    except PyvdriftError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@app.command()
def doctor(
    path: str = typer.Argument(".", help="Project path to diagnose"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Diagnose broken venvs and interpreter mismatches."""
    try:
        project_path = Path(path).expanduser().resolve()
        projects = scan_projects(project_path, max_depth=0)

        if not projects:
            from pyvdrift.core.scanner import _detect_project, _is_python_project
            if _is_python_project(project_path):
                projects = [_detect_project(project_path)]

        if not projects:
            typer.echo("No Python project found at this path.", err=True)
            raise typer.Exit(1)

        project = _enrich_project(projects[0])
        checks = _run_checks(project)

        if json_output:
            from pyvdrift.output.json_output import checks_to_json
            typer.echo(checks_to_json(project, checks))
        else:
            from pyvdrift.output.console import print_doctor_results
            print_doctor_results(project, checks)

        # Exit code based on worst status
        statuses = {c.status for c in checks}
        if "error" in statuses:
            raise typer.Exit(2)
        if "warn" in statuses:
            raise typer.Exit(1)

    except PyvdriftError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(2) from e


@app.command(name="list")
def list_projects(
    depth: int = typer.Option(5, "--depth", "-d", help="Maximum directory depth"),
    sort_by: str = typer.Option("health", "--sort-by", help="Sort by: health|name|tool|last-used"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    path: str = typer.Option("~", "--path", help="Root path to scan"),
) -> None:
    """Show all known projects with health status."""
    try:
        root = Path(path).expanduser()
        projects = scan_projects(root, max_depth=depth)

        entries: list[tuple[Project, list[CheckResult], DriftResult | None]] = []
        for project in projects:
            _enrich_project(project)
            checks = _run_checks(project)
            try:
                drift = detect_drift(project)
            except PyvdriftError:
                drift = None
            entries.append((project, checks, drift))

        # Sort
        if sort_by == "name":
            entries.sort(key=lambda e: e[0].name.lower())
        elif sort_by == "tool":
            entries.sort(key=lambda e: e[0].toolchains[0].value if e[0].toolchains else "")
        elif sort_by == "last-used":
            entries.sort(
                key=lambda e: e[0].last_activated or __import__("datetime").datetime.min.replace(
                    tzinfo=__import__("datetime").timezone.utc
                ),
                reverse=True,
            )
        else:  # health
            _health_order = {"error": 0, "warn": 1, "ok": 2}
            entries.sort(key=lambda e: _health_order.get(
                _worst_status(e[1]), 2
            ))

        if json_output:
            from pyvdrift.output.json_output import dashboard_to_json
            typer.echo(dashboard_to_json(entries))
        else:
            from pyvdrift.output.console import print_list_dashboard
            print_list_dashboard(entries)

    except PyvdriftError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@app.command()
def clean(
    dry_run: bool = typer.Option(True, "--dry-run/--no-dry-run", help="Preview only"),
    older_than: int = typer.Option(30, "--older-than", help="Days since last activation"),
    path: str = typer.Option("~", "--path", help="Root path to scan"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Actually delete venvs"),
) -> None:
    """Remove venvs not touched in N days."""
    from datetime import datetime, timezone

    try:
        root = Path(path).expanduser()
        projects = scan_projects(root, max_depth=5)

        stale: list[tuple[Project, int]] = []
        for project in projects:
            _enrich_project(project)
            if project.venv_path and project.last_activated:
                age = (datetime.now(tz=timezone.utc) - project.last_activated).days
                if age > older_than:
                    stale.append((project, age))

        if not stale:
            typer.echo("No stale venvs found.")
            return

        from pyvdrift.output.console import print_clean_preview
        print_clean_preview(stale)

        if yes and not dry_run:
            for project, _age in stale:
                if project.venv_path and project.venv_path.is_dir():
                    shutil.rmtree(project.venv_path)
                    typer.echo(f"Removed: {project.venv_path}")
            typer.echo(f"\nCleaned {len(stale)} venv(s).")
        else:
            typer.echo("\nDry run — pass --no-dry-run --yes to actually delete.")

    except PyvdriftError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@app.command()
def watch(
    path: str = typer.Argument(..., help="Project path to watch"),
    interval: int = typer.Option(5, "--interval", help="Poll interval in seconds"),
) -> None:
    """Monitor a project for drift in real time."""
    try:
        project_path = Path(path).expanduser().resolve()
        projects = scan_projects(project_path, max_depth=0)

        if not projects:
            from pyvdrift.core.scanner import _detect_project, _is_python_project
            if _is_python_project(project_path):
                projects = [_detect_project(project_path)]

        if not projects:
            typer.echo("No Python project found at this path.", err=True)
            raise typer.Exit(1)

        from pyvdrift.output.console import console, print_drift_result

        prev_missing = -1
        prev_mismatch = -1

        typer.echo(f"Watching {project_path} every {interval}s (Ctrl+C to stop)...")
        while True:
            project = _enrich_project(projects[0])
            result = detect_drift(project)
            n_missing = len(result.missing)
            n_mismatch = len(result.version_mismatch)

            if n_missing != prev_missing or n_mismatch != prev_mismatch:
                console.clear()
                print_drift_result(result)
                prev_missing = n_missing
                prev_mismatch = n_mismatch

            time.sleep(interval)

    except KeyboardInterrupt:
        typer.echo("\nStopped watching.")
    except PyvdriftError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


def _worst_status(checks: list[CheckResult]) -> str:
    """Return the worst status from a list of checks."""
    statuses = {c.status for c in checks}
    if "error" in statuses:
        return "error"
    return "warn" if "warn" in statuses else "ok"
