"""Abstract base for health checks."""

from __future__ import annotations

from abc import ABC, abstractmethod

from pyvdrift.core.project import CheckResult, Project


class Check(ABC):
    """Interface for a single health check."""

    @staticmethod
    @abstractmethod
    def run(project: Project) -> CheckResult:
        """Run the check and return a result."""
