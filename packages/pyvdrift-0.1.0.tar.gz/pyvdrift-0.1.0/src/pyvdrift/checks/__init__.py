"""Health checks for Python projects."""
