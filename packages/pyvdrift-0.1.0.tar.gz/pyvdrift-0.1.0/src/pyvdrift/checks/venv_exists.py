"""Check: does a venv exist for the project?"""

from __future__ import annotations

from pyvdrift.checks.base import Check
from pyvdrift.core.project import CheckResult, Project, Toolchain

_TOOL_MAP = {
    Toolchain.UV: "uv sync",
    Toolchain.POETRY: "poetry install",
    Toolchain.PIPENV: "pipenv install",
    Toolchain.PIP: "python -m venv .venv && pip install -r requirements.txt",
    Toolchain.HATCH: "hatch env create",
    Toolchain.PDM: "pdm install",
    Toolchain.CONDA: "conda env create -f environment.yml",
    Toolchain.LEGACY: "python -m venv .venv && pip install -e .",
}


class VenvExistsCheck(Check):
    """Check whether a virtual environment exists."""

    @staticmethod
    def run(project: Project) -> CheckResult:
        """Check if the project has a venv."""
        if project.venv_path and project.venv_path.is_dir():
            return CheckResult(
                name="venv_exists",
                status="ok",
                message=f"venv exists at {project.venv_path.name}/",
            )

        tool = project.toolchains[0] if project.toolchains else Toolchain.UNKNOWN
        hint = _TOOL_MAP.get(tool)
        return CheckResult(
            name="venv_exists",
            status="error",
            message="no virtual environment found",
            fix_hint=hint,
        )
