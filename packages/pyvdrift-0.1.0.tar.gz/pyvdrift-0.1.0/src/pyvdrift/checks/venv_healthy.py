"""Check: is the venv Python binary functional?"""

from __future__ import annotations

import subprocess

from pyvdrift.checks.base import Check
from pyvdrift.core.interpreter import resolve_interpreter
from pyvdrift.core.project import CheckResult, Project


class VenvHealthyCheck(Check):
    """Check if the venv's Python binary is functional."""

    @staticmethod
    def run(project: Project) -> CheckResult:
        """Test that the venv Python binary can run."""
        if project.venv_path is None:
            return CheckResult(
                name="venv_healthy",
                status="warn",
                message="no venv to check",
            )

        interpreter = resolve_interpreter(project)
        if interpreter is None:
            return CheckResult(
                name="venv_healthy",
                status="error",
                message="no Python binary found in venv",
            )

        try:
            result = subprocess.run(
                [interpreter, "-c", "import sys; print(sys.version)"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                version = result.stdout.strip().split()[0]
                return CheckResult(
                    name="venv_healthy",
                    status="ok",
                    message=f"venv Python {version} is functional",
                )
            return CheckResult(
                name="venv_healthy",
                status="error",
                message=f"venv Python binary failed: {result.stderr.strip()[:100]}",
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return CheckResult(
                name="venv_healthy",
                status="error",
                message="venv Python binary not found or timed out",
            )
