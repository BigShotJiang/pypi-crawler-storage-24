"""Check: is the project's tool (uv/poetry/etc) installed?"""

from __future__ import annotations

import shutil

from pyvdrift.checks.base import Check
from pyvdrift.core.project import CheckResult, Project, Toolchain

_TOOL_BINARIES = {
    Toolchain.UV: "uv",
    Toolchain.POETRY: "poetry",
    Toolchain.PIPENV: "pipenv",
    Toolchain.PIP: "pip",
    Toolchain.HATCH: "hatch",
    Toolchain.PDM: "pdm",
    Toolchain.CONDA: "conda",
}


class ToolAvailableCheck(Check):
    """Check if the project's package manager is installed and available."""

    @staticmethod
    def run(project: Project) -> CheckResult:
        """Check if the tool binary is in PATH."""
        tool = project.toolchains[0] if project.toolchains else Toolchain.UNKNOWN
        binary = _TOOL_BINARIES.get(tool)

        if binary is None:
            return CheckResult(
                name="tool_available",
                status="ok",
                message="no specific tool to check",
            )

        path = shutil.which(binary)
        if path:
            return CheckResult(
                name="tool_available",
                status="ok",
                message=f"{binary} is installed and available",
            )

        return CheckResult(
            name="tool_available",
            status="warn",
            message=f"{binary} not found in PATH — install it to manage this project",
        )
