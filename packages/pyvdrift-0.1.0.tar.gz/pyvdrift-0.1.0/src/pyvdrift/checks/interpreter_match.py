"""Check: does venv Python match declared version?"""

from __future__ import annotations

from pyvdrift.checks.base import Check
from pyvdrift.core.interpreter import read_venv_python_version
from pyvdrift.core.project import CheckResult, Project


class InterpreterMatchCheck(Check):
    """Check if venv Python version matches declared version."""

    @staticmethod
    def run(project: Project) -> CheckResult:
        """Compare venv Python version with declared version."""
        if project.venv_path is None or project.python_version is None:
            return CheckResult(
                name="interpreter_match",
                status="ok",
                message="no version constraint to check",
            )

        actual = read_venv_python_version(project.venv_path)
        if actual is None:
            return CheckResult(
                name="interpreter_match",
                status="warn",
                message="could not determine venv Python version",
            )

        declared = project.python_version
        # Compare major.minor
        actual_mm = ".".join(actual.split(".")[:2])
        declared_mm = ".".join(declared.split(".")[:2])

        if actual_mm == declared_mm:
            return CheckResult(
                name="interpreter_match",
                status="ok",
                message=f"venv Python {actual} matches declared {declared}",
            )

        return CheckResult(
            name="interpreter_match",
            status="warn",
            message=f"declared Python {declared} but venv uses {actual}",
        )
