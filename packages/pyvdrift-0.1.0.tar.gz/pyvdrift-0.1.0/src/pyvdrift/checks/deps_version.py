"""Check: are installed versions within declared ranges?"""

from __future__ import annotations

from pyvdrift.checks.base import Check
from pyvdrift.core.drift import detect_drift
from pyvdrift.core.project import CheckResult, Project, Toolchain

_FIX_HINTS = {
    Toolchain.UV: "uv sync",
    Toolchain.POETRY: "poetry install",
    Toolchain.PIPENV: "pipenv install",
    Toolchain.PIP: "pip install -r requirements.txt",
    Toolchain.PDM: "pdm install",
}


class DepsVersionCheck(Check):
    """Check if installed package versions match declared specifiers."""

    @staticmethod
    def run(project: Project) -> CheckResult:
        """Run drift check and report version mismatches."""
        result = detect_drift(project)
        n_mismatch = len(result.version_mismatch)

        if n_mismatch == 0:
            return CheckResult(
                name="deps_version",
                status="ok",
                message="all installed versions match declared specifiers",
            )

        details = []
        details.extend(
            f"{dep.name}: want {dep.specifier}, have {pkg.version}"
            for dep, pkg in result.version_mismatch[:3]
        )
        tool = project.toolchains[0] if project.toolchains else Toolchain.UNKNOWN
        hint = _FIX_HINTS.get(tool)

        return CheckResult(
            name="deps_version",
            status="warn",
            message=f"{n_mismatch} version mismatch(es): {'; '.join(details)}",
            fix_hint=hint,
        )
