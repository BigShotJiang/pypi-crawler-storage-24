"""Check: are declared deps installed?"""

from __future__ import annotations

from pyvdrift.checks.base import Check
from pyvdrift.core.drift import detect_drift
from pyvdrift.core.project import CheckResult, Project, Toolchain

_FIX_HINTS = {
    Toolchain.UV: "uv sync",
    Toolchain.POETRY: "poetry install",
    Toolchain.PIPENV: "pipenv install",
    Toolchain.PIP: "pip install -r requirements.txt",
    Toolchain.HATCH: "hatch env create",
    Toolchain.PDM: "pdm install",
    Toolchain.CONDA: "conda env update -f environment.yml",
    Toolchain.LEGACY: "pip install -e .",
}


class DepsInstalledCheck(Check):
    """Check if all declared dependencies are installed."""

    @staticmethod
    def run(project: Project) -> CheckResult:
        """Run drift check and report missing packages."""
        result = detect_drift(project)
        n_missing = len(result.missing)

        if n_missing == 0:
            return CheckResult(
                name="deps_installed",
                status="ok",
                message="all declared packages are installed",
            )

        tool = project.toolchains[0] if project.toolchains else Toolchain.UNKNOWN
        hint = _FIX_HINTS.get(tool)

        return CheckResult(
            name="deps_installed",
            status="error",
            message=f"{n_missing} required package(s) not installed",
            fix_hint=hint,
        )
