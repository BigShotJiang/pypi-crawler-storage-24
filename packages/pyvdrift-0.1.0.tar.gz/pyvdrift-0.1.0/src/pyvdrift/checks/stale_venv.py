"""Check: venv not activated in N days?"""

from __future__ import annotations

from datetime import datetime, timezone

from pyvdrift.checks.base import Check
from pyvdrift.core.project import CheckResult, Project

_STALE_DAYS = 30


class StaleVenvCheck(Check):
    """Check if the venv has been used recently."""

    @staticmethod
    def run(project: Project) -> CheckResult:
        """Check venv staleness based on last_activated timestamp."""
        if project.venv_path is None or project.last_activated is None:
            return CheckResult(
                name="stale_venv",
                status="ok",
                message="no venv activation data available",
            )

        now = datetime.now(tz=timezone.utc)
        age = now - project.last_activated
        days = age.days

        if days <= _STALE_DAYS:
            return CheckResult(
                name="stale_venv",
                status="ok",
                message=f"venv last activated {days} day(s) ago",
            )

        return CheckResult(
            name="stale_venv",
            status="warn",
            message=f"venv not activated in {days} days",
        )
