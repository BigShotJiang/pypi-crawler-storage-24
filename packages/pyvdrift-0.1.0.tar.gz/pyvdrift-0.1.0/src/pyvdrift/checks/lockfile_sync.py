"""Check: is lockfile in sync with dep declaration?"""

from __future__ import annotations

from pyvdrift.checks.base import Check
from pyvdrift.core.project import CheckResult, Project, Toolchain


class LockfileSyncCheck(Check):
    """Check if the lockfile is up-to-date with dependency declarations."""

    @staticmethod
    def run(project: Project) -> CheckResult:
        """Compare lockfile mtime vs dep file mtimes."""
        tool = project.toolchains[0] if project.toolchains else Toolchain.UNKNOWN

        match tool:
            case Toolchain.UV:
                return _check_mtime(
                    project, "uv.lock", "pyproject.toml", "uv lock"
                )
            case Toolchain.POETRY:
                return _check_mtime(
                    project, "poetry.lock", "pyproject.toml",
                    "poetry lock --no-update"
                )
            case Toolchain.PIPENV:
                return _check_mtime(
                    project, "Pipfile.lock", "Pipfile", "pipenv lock"
                )
            case Toolchain.PDM:
                return _check_mtime(
                    project, "pdm.lock", "pyproject.toml", "pdm lock"
                )
            case Toolchain.PIP:
                return _check_pip_pinning(project)
            case _:
                return CheckResult(
                    name="lockfile_sync",
                    status="ok",
                    message="no lockfile check for this tool",
                )


def _check_mtime(
    project: Project, lock_name: str, dep_name: str, fix_cmd: str
) -> CheckResult:
    """Compare modification times of lockfile and dep file."""
    lock = project.path / lock_name
    dep = project.path / dep_name

    if not lock.exists():
        return CheckResult(
            name="lockfile_sync",
            status="warn",
            message=f"{lock_name} not found",
            fix_hint=fix_cmd,
        )

    if not dep.exists():
        return CheckResult(
            name="lockfile_sync",
            status="ok",
            message=f"{dep_name} not found, cannot check sync",
        )

    lock_mtime = lock.stat().st_mtime
    dep_mtime = dep.stat().st_mtime

    if lock_mtime < dep_mtime:
        return CheckResult(
            name="lockfile_sync",
            status="warn",
            message=f"{lock_name} may be stale ({dep_name} modified after lockfile)",
            fix_hint=fix_cmd,
        )

    return CheckResult(
        name="lockfile_sync",
        status="ok",
        message=f"{lock_name} is up to date",
    )


def _check_pip_pinning(project: Project) -> CheckResult:
    """Check if requirements.txt has pinned versions."""
    req = project.path / "requirements.txt"
    if not req.exists():
        return CheckResult(
            name="lockfile_sync",
            status="ok",
            message="no requirements.txt to check",
        )

    content = req.read_text()
    lines = [
        line.strip()
        for line in content.splitlines()
        if line.strip() and not line.strip().startswith("#") and not line.strip().startswith("-")
    ]

    if not lines:
        return CheckResult(
            name="lockfile_sync",
            status="ok",
            message="requirements.txt is empty",
        )

    pinned = sum("==" in line for line in lines)
    if pinned == 0:
        return CheckResult(
            name="lockfile_sync",
            status="warn",
            message="requirements.txt has no pinned versions (==)",
            fix_hint="pip-compile or uv pip compile",
        )

    return CheckResult(
        name="lockfile_sync",
        status="ok",
        message=f"requirements.txt has {pinned}/{len(lines)} pinned versions",
    )
