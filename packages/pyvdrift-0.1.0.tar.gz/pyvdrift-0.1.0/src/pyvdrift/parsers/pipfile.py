"""Parser for Pipfile (TOML format)."""

from __future__ import annotations

import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

from pyvdrift.core.project import DeclaredDep
from pyvdrift.exceptions import PyvdriftError
from pyvdrift.parsers.base import Parser


class PipfileParser(Parser):
    """Parse Pipfile for dependency declarations."""

    @staticmethod
    def parse(file_path: Path) -> list[DeclaredDep]:
        """Parse a Pipfile and return declared dependencies."""
        try:
            return _parse_pipfile(file_path)
        except PyvdriftError:
            raise
        except Exception as e:
            raise PyvdriftError(f"parse {file_path}: {e}") from e


def _parse_pipfile(file_path: Path) -> list[DeclaredDep]:
    if not file_path.exists():
        return []

    with open(file_path, "rb") as f:
        data = tomllib.load(f)

    deps: list[DeclaredDep] = []

    # [packages]
    deps.extend(
        _make_dep(name, spec, file_path, is_dev=False)
        for name, spec in data.get("packages", {}).items()
    )

    # [dev-packages]
    deps.extend(
        _make_dep(name, spec, file_path, is_dev=True)
        for name, spec in data.get("dev-packages", {}).items()
    )

    return deps


def _make_dep(name: str, spec: str | dict, source: Path, *, is_dev: bool) -> DeclaredDep:
    """Convert a Pipfile dependency entry to DeclaredDep."""
    version = spec.get("version", "") if isinstance(spec, dict) else spec

    # Pipenv uses "*" for any version
    if version == "*":
        version = ""

    return DeclaredDep(
        name=name,
        specifier=version,
        extras=[],
        source_file=source,
        is_dev=is_dev,
    )
