"""Parser for environment.yml (conda/mamba YAML format)."""

from __future__ import annotations

from pathlib import Path

import yaml

from pyvdrift.core.project import DeclaredDep
from pyvdrift.exceptions import PyvdriftError
from pyvdrift.parsers.base import Parser


class CondaEnvParser(Parser):
    """Parse environment.yml for conda dependency declarations."""

    @staticmethod
    def parse(file_path: Path) -> list[DeclaredDep]:
        """Parse an environment.yml and return declared dependencies."""
        try:
            return _parse(file_path)
        except PyvdriftError:
            raise
        except Exception as e:
            raise PyvdriftError(f"parse {file_path}: {e}") from e


def _parse(file_path: Path) -> list[DeclaredDep]:
    if not file_path.exists():
        return []

    data = yaml.safe_load(file_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return []

    deps: list[DeclaredDep] = []

    for item in data.get("dependencies", []):
        if isinstance(item, str):
            if dep := _parse_conda_dep(item, file_path):
                deps.append(dep)
        elif isinstance(item, dict):
            # pip sub-dependencies: {pip: [pkg1, pkg2]}
            pip_deps = item.get("pip", [])
            for pip_dep in pip_deps:
                if isinstance(pip_dep, str):
                    if dep := _parse_conda_dep(pip_dep, file_path):
                        deps.append(dep)

    return deps


def _parse_conda_dep(dep_str: str, source: Path) -> DeclaredDep | None:
    """Parse a single conda dependency string like 'numpy>=1.24' or 'python=3.12'."""
    dep_str = dep_str.strip()
    if not dep_str:
        return None

    # Split on version operators
    for op in (">=", "<=", "!=", "==", "=", ">", "<"):
        if op in dep_str:
            idx = dep_str.index(op)
            name = dep_str[:idx].strip()
            version = dep_str[idx:].strip()
            # Conda uses single = for pinning, normalize to ==
            if version.startswith("=") and not version.startswith("=="):
                version = f"=={version[1:]}"
            return DeclaredDep(
                name=name, specifier=version, source_file=source
            )

    # No version constraint
    return DeclaredDep(name=dep_str, specifier="", source_file=source)
