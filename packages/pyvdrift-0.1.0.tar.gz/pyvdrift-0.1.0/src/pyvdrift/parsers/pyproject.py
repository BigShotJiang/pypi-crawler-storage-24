"""Parser for pyproject.toml (PEP 621, Poetry, PDM, uv sections)."""

from __future__ import annotations

import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

from packaging.requirements import InvalidRequirement, Requirement

from pyvdrift.core.project import DeclaredDep
from pyvdrift.exceptions import PyvdriftError
from pyvdrift.parsers.base import Parser


class PyprojectParser(Parser):
    """Parse pyproject.toml for dependency declarations."""

    @staticmethod
    def parse(file_path: Path) -> list[DeclaredDep]:
        """Parse all dependency sections from pyproject.toml."""
        try:
            return _parse_pyproject(file_path)
        except PyvdriftError:
            raise
        except Exception as e:
            raise PyvdriftError(f"parse {file_path}: {e}") from e


def _parse_pyproject(file_path: Path) -> list[DeclaredDep]:
    """Internal parser for pyproject.toml."""
    if not file_path.exists():
        return []

    with open(file_path, "rb") as f:
        data = tomllib.load(f)

    deps: list[DeclaredDep] = []

    # PEP 621 [project.dependencies]
    for dep_str in data.get("project", {}).get("dependencies", []):
        dep = _parse_dep_string(dep_str, file_path, is_dev=False)
        if dep:
            deps.append(dep)

    # PEP 621 [project.optional-dependencies]
    for group_name, group_deps in data.get("project", {}).get("optional-dependencies", {}).items():
        is_dev = _is_dev_group(group_name)
        for dep_str in group_deps:
            dep = _parse_dep_string(dep_str, file_path, is_dev=is_dev)
            if dep:
                deps.append(dep)

    # Poetry [tool.poetry.dependencies]
    if poetry := data.get("tool", {}).get("poetry", {}) :
        for name, spec in poetry.get("dependencies", {}).items():
            if name.lower() == "python":
                continue
            dep = _poetry_dep(name, spec, file_path, is_dev=False)
            deps.append(dep)

        # Poetry dev-dependencies (legacy)
        for name, spec in poetry.get("dev-dependencies", {}).items():
            dep = _poetry_dep(name, spec, file_path, is_dev=True)
            deps.append(dep)

        # Poetry groups
        for group_name, group_data in poetry.get("group", {}).items():
            is_dev = True  # all groups besides main are dev
            for name, spec in group_data.get("dependencies", {}).items():
                dep = _poetry_dep(name, spec, file_path, is_dev=is_dev)
                deps.append(dep)

    # uv [tool.uv.dev-dependencies]
    if uv_section := data.get("tool", {}).get("uv", {}):
        for dep_str in uv_section.get("dev-dependencies", []):
            if dep := _parse_dep_string(dep_str, file_path, is_dev=True):
                 deps.append(dep)

    return deps


def _parse_dep_string(dep_str: str, source: Path, *, is_dev: bool) -> DeclaredDep | None:
    """Parse a PEP 508 dependency string."""
    try:
        req = Requirement(dep_str)
    except InvalidRequirement:
        return None
    return DeclaredDep(
        name=req.name,
        specifier=str(req.specifier),
        extras=list(req.extras),
        source_file=source,
        is_dev=is_dev,
    )


def _poetry_dep(name: str, spec: str | dict, source: Path, *, is_dev: bool) -> DeclaredDep:
    """Convert a Poetry dependency entry to a DeclaredDep."""
    version = spec.get("version", "") if isinstance(spec, dict) else spec

    # Convert Poetry version syntax (^, ~) to something readable
    specifier = _poetry_version_to_specifier(version)

    return DeclaredDep(
        name=name,
        specifier=specifier,
        extras=[],
        source_file=source,
        is_dev=is_dev,
    )


def _poetry_version_to_specifier(version: str) -> str:
    """Convert Poetry version constraint to PEP 440-ish specifier.

    This is a best-effort conversion for display purposes.
    """
    if not version or version == "*":
        return ""
    if version.startswith("^"):
        return f">={version[1:]}"
    if version.startswith("~"):
        return f"~={version[1:]}"
    if any(version.startswith(op) for op in (">=", "<=", "!=", "==", ">", "<")):
        return version
    return f"=={version}"


def _is_dev_group(group_name: str) -> bool:
    """Heuristic: group is dev-related if name suggests it."""
    return any(kw in group_name.lower() for kw in ("dev", "test", "lint", "ci", "docs"))
