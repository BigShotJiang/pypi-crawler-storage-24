"""Pure file parsers for dependency and lock files."""
