"""Parser for Pipfile.lock (JSON format)."""

from __future__ import annotations

import json
from pathlib import Path

from pyvdrift.core.project import InstalledPkg
from pyvdrift.exceptions import PyvdriftError


def parse_pipfile_lock(file_path: Path) -> list[InstalledPkg]:
    """Parse a Pipfile.lock and return the list of locked packages."""
    try:
        return _parse(file_path)
    except PyvdriftError:
        raise
    except Exception as e:
        raise PyvdriftError(f"parse {file_path}: {e}") from e


def _parse(file_path: Path) -> list[InstalledPkg]:
    if not file_path.exists():
        return []

    data = json.loads(file_path.read_text(encoding="utf-8"))
    pkgs: list[InstalledPkg] = []

    for section in ("default", "develop"):
        for name, info in data.get(section, {}).items():
            version = info.get("version", "")
            # Pipfile.lock uses "==x.y.z" format — strip the ==
            if version.startswith("=="):
                version = version[2:]
            if version:
                pkgs.append(InstalledPkg(name=name, version=version, location=file_path))

    return pkgs
