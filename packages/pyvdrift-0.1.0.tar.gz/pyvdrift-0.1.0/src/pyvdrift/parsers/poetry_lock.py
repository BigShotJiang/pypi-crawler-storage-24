"""Parser for poetry.lock files (custom TOML-like format)."""

from __future__ import annotations

import re
from pathlib import Path

from pyvdrift.core.project import InstalledPkg
from pyvdrift.exceptions import PyvdriftError


def parse_poetry_lock(file_path: Path) -> list[InstalledPkg]:
    """Parse a poetry.lock file and return the list of locked packages.

    poetry.lock uses a TOML-like format with [[package]] blocks.
    We parse it with tomllib since it's valid TOML.
    """
    try:
        return _parse(file_path)
    except PyvdriftError:
        raise
    except Exception as e:
        raise PyvdriftError(f"parse {file_path}: {e}") from e


def _parse(file_path: Path) -> list[InstalledPkg]:
    if not file_path.exists():
        return []

    # poetry.lock is valid TOML — use tomllib
    import sys

    if sys.version_info >= (3, 11):
        import tomllib
    else:
        try:
            import tomllib
        except ImportError:
            import tomli as tomllib  # type: ignore[no-redef]

    try:
        with open(file_path, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        # Fall back to regex parsing if TOML parse fails
        return _parse_regex(file_path)

    pkgs: list[InstalledPkg] = []
    for pkg in data.get("package", []):
        name = pkg.get("name", "")
        version = pkg.get("version", "")
        if name and version:
            pkgs.append(InstalledPkg(name=name, version=version, location=file_path))
    return pkgs


def _parse_regex(file_path: Path) -> list[InstalledPkg]:
    """Fallback regex parser for poetry.lock."""
    content = file_path.read_text(encoding="utf-8")
    pkgs: list[InstalledPkg] = []

    pattern = re.compile(
        r'\[\[package\]\]\s*\n'
        r'name\s*=\s*"([^"]+)"\s*\n'
        r'version\s*=\s*"([^"]+)"',
        re.MULTILINE,
    )

    pkgs.extend(
        InstalledPkg(
            name=match.group(1), version=match.group(2), location=file_path
        )
        for match in pattern.finditer(content)
    )
    return pkgs
