"""Parser for setup.cfg [options] install_requires."""

from __future__ import annotations

import configparser
from pathlib import Path

from packaging.requirements import InvalidRequirement, Requirement

from pyvdrift.core.project import DeclaredDep
from pyvdrift.exceptions import PyvdriftError
from pyvdrift.parsers.base import Parser


class SetupCfgParser(Parser):
    """Parse setup.cfg for install_requires declarations."""

    @staticmethod
    def parse(file_path: Path) -> list[DeclaredDep]:
        """Parse setup.cfg and return declared dependencies."""
        try:
            return _parse(file_path)
        except PyvdriftError:
            raise
        except Exception as e:
            raise PyvdriftError(f"parse {file_path}: {e}") from e


def _parse(file_path: Path) -> list[DeclaredDep]:
    if not file_path.exists():
        return []

    config = configparser.ConfigParser()
    config.read(file_path, encoding="utf-8")

    deps: list[DeclaredDep] = []

    install_requires = config.get("options", "install_requires", fallback="")
    for line in install_requires.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            req = Requirement(line)
            deps.append(
                DeclaredDep(
                    name=req.name,
                    specifier=str(req.specifier),
                    extras=list(req.extras),
                    source_file=file_path,
                )
            )
        except InvalidRequirement:
            continue

    return deps
