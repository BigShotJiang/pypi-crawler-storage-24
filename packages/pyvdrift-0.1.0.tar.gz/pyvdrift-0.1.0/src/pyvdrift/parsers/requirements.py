"""Parser for requirements.txt files (all variants)."""

from __future__ import annotations

from pathlib import Path

from packaging.requirements import InvalidRequirement, Requirement

from pyvdrift.core.project import DeclaredDep
from pyvdrift.exceptions import PyvdriftError
from pyvdrift.parsers.base import Parser


class RequirementsParser(Parser):
    """Parse requirements.txt and its variants."""

    @staticmethod
    def parse(file_path: Path) -> list[DeclaredDep]:
        """Parse a requirements file into declared dependencies.

        Handles version specifiers, extras, comments, blank lines,
        -r includes, and -e editable installs. Skips option lines
        (--index-url, etc.) and git/url dependencies.
        """
        try:
            return _parse_requirements_file(file_path, seen=set())
        except Exception as e:
            raise PyvdriftError(f"parse {file_path}: {e}") from e


def _parse_requirements_file(
    file_path: Path, *, seen: set[Path]
) -> list[DeclaredDep]:
    """Recursively parse a requirements file, following -r includes."""
    resolved = file_path.resolve()
    if resolved in seen:
        return []
    seen.add(resolved)

    if not file_path.exists():
        return []

    is_dev = _is_dev_file(file_path)
    deps: list[DeclaredDep] = []

    for raw_line in file_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()

        # Skip blanks, comments, and option flags
        if not line or line.startswith("#") or line.startswith("--"):
            continue

        # Handle -r / -c includes
        if line.startswith(("-r ", "-c ")):
            ref_path = file_path.parent / line.split(None, 1)[1].strip()
            deps.extend(_parse_requirements_file(ref_path, seen=seen))
            continue

        # Skip editable installs and URL/VCS deps
        if line.startswith("-e ") or "://" in line:
            continue

        # Skip environment markers on their own (rare but possible)
        if line.startswith(";"):
            continue

        # Strip inline comments
        if " #" in line:
            line = line[: line.index(" #")].strip()

        # Strip environment markers for parsing (we keep the specifier only)
        marker_pos = line.find(";")
        if marker_pos != -1:
            line = line[:marker_pos].strip()

        try:
            req = Requirement(line)
        except InvalidRequirement:
            continue

        deps.append(
            DeclaredDep(
                name=req.name,
                specifier=str(req.specifier),
                extras=list(req.extras),
                source_file=file_path,
                is_dev=is_dev,
            )
        )

    return deps


def _is_dev_file(file_path: Path) -> bool:
    """Heuristic: file is dev-related if name contains 'dev' or 'test'."""
    name = file_path.stem.lower()
    return any(kw in name for kw in ("dev", "test", "lint", "ci"))
