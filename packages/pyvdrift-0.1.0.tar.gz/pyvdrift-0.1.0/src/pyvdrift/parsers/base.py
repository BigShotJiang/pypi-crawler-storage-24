"""Abstract base for file parsers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from pyvdrift.core.project import DeclaredDep


class Parser(ABC):
    """Interface for parsing dependency files into DeclaredDep lists."""

    @staticmethod
    @abstractmethod
    def parse(file_path: Path) -> list[DeclaredDep]:
        """Parse a dependency file and return declared dependencies."""
