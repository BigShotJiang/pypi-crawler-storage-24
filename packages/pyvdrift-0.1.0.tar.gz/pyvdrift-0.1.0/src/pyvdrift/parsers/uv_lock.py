"""Parser for uv.lock files (TOML format with [[package]] entries)."""

from __future__ import annotations

import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

from pyvdrift.core.project import InstalledPkg
from pyvdrift.exceptions import PyvdriftError


def parse_uv_lock(file_path: Path) -> list[InstalledPkg]:
    """Parse a uv.lock file and return the list of locked packages."""
    try:
        return _parse(file_path)
    except PyvdriftError:
        raise
    except Exception as e:
        raise PyvdriftError(f"parse {file_path}: {e}") from e


def _parse(file_path: Path) -> list[InstalledPkg]:
    if not file_path.exists():
        return []

    with open(file_path, "rb") as f:
        data = tomllib.load(f)

    pkgs: list[InstalledPkg] = []
    for pkg in data.get("package", []):
        name = pkg.get("name", "")
        version = pkg.get("version", "")
        if name and version:
            pkgs.append(InstalledPkg(name=name, version=version, location=file_path))
    return pkgs
