"""Allow running pyvdrift as `python -m pyvdrift`."""

from pyvdrift.cli import app

app()
