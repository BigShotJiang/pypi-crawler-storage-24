"""pyvdrift — Detect environment drift across all your Python projects."""

__version__ = "0.1.0"
