"""Legacy setup.py / setup.cfg tool support (static analysis only)."""

from __future__ import annotations

import ast
from pathlib import Path

from pyvdrift.core.project import DeclaredDep
from pyvdrift.parsers.setup_cfg import SetupCfgParser
from pyvdrift.tools.base import Tool

_VENV_CANDIDATES = (".venv", "venv", "env")


class LegacyTool(Tool):
    """Detect and parse legacy setup.py/setup.cfg projects.

    IMPORTANT: Never executes setup.py. Static analysis only.
    """

    @staticmethod
    def detect(project_path: Path) -> bool:
        """Return True if setup.py or setup.cfg is present."""
        return (
            (project_path / "setup.py").exists()
            or (project_path / "setup.cfg").exists()
        )

    @staticmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """Check common venv directory names."""
        for candidate in _VENV_CANDIDATES:
            venv = project_path / candidate
            if venv.is_dir() and (venv / "pyvenv.cfg").exists():
                return venv
        return None

    @staticmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse deps from setup.cfg and/or setup.py (static analysis only)."""
        deps: list[DeclaredDep] = []
        seen: set[str] = set()

        # setup.cfg first (more reliable)
        setup_cfg = project_path / "setup.cfg"
        if setup_cfg.exists():
            for dep in SetupCfgParser.parse(setup_cfg):
                key = dep.name.lower()
                if key not in seen:
                    seen.add(key)
                    deps.append(dep)

        # setup.py static analysis
        setup_py = project_path / "setup.py"
        if setup_py.exists():
            for dep in _parse_setup_py(setup_py):
                key = dep.name.lower()
                if key not in seen:
                    seen.add(key)
                    deps.append(dep)

        return deps

    @staticmethod
    def fix_hint(project_path: Path) -> str:
        """Return pip install -e . command."""
        return "pip install -e ."

    @staticmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """Legacy projects don't have lockfiles."""
        return None


def _parse_setup_py(file_path: Path) -> list[DeclaredDep]:
    """Extract install_requires from setup.py using AST parsing only.

    This is best-effort — it only catches the simplest cases where
    install_requires is a literal list of strings passed to setup().
    Never executes setup.py.
    """
    try:
        source = file_path.read_text(encoding="utf-8")
        tree = ast.parse(source)
    except (SyntaxError, UnicodeDecodeError):
        return []

    deps: list[DeclaredDep] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        # Look for setup(...) or setuptools.setup(...)
        func = node.func
        name = ""
        if isinstance(func, ast.Name):
            name = func.id
        elif isinstance(func, ast.Attribute):
            name = func.attr

        if name != "setup":
            continue

        for keyword in node.keywords:
            if keyword.arg == "install_requires" and isinstance(keyword.value, ast.List):
                for elt in keyword.value.elts:
                    if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                        if dep := _parse_dep_string(elt.value, file_path):
                            deps.append(dep)

    return deps


def _parse_dep_string(dep_str: str, source: Path) -> DeclaredDep | None:
    """Parse a PEP 508 requirement string."""
    from packaging.requirements import InvalidRequirement, Requirement

    try:
        req = Requirement(dep_str)
    except InvalidRequirement:
        return None
    return DeclaredDep(
        name=req.name,
        specifier=str(req.specifier),
        extras=list(req.extras),
        source_file=source,
    )
