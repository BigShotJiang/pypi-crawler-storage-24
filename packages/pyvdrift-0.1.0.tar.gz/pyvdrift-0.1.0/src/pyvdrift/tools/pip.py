"""Plain pip / requirements.txt tool support."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.core.project import DeclaredDep
from pyvdrift.parsers.requirements import RequirementsParser
from pyvdrift.tools.base import Tool

_VENV_CANDIDATES = (".venv", "venv", "env")

_REQ_PATTERNS = (
    "requirements.txt",
    "requirements-*.txt",
    "requirements_*.txt",
)

_REQ_DIR = "requirements"


class PipTool(Tool):
    """Detect and resolve plain pip projects using requirements.txt files."""

    @staticmethod
    def detect(project_path: Path) -> bool:
        """Return True if requirements*.txt files are present."""
        for pattern in _REQ_PATTERNS:
            if list(project_path.glob(pattern)):
                return True
        req_dir = project_path / _REQ_DIR
        return bool(req_dir.is_dir() and list(req_dir.glob("*.txt")))

    @staticmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """Check common venv directory names."""
        for candidate in _VENV_CANDIDATES:
            venv = project_path / candidate
            if venv.is_dir() and (venv / "pyvenv.cfg").exists():
                return venv
        return None

    @staticmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse all requirements files found in the project."""
        deps: list[DeclaredDep] = []
        seen_names: set[str] = set()

        files: list[Path] = []
        for pattern in _REQ_PATTERNS:
            files.extend(project_path.glob(pattern))
        req_dir = project_path / _REQ_DIR
        if req_dir.is_dir():
            files.extend(req_dir.glob("*.txt"))

        for req_file in sorted(set(files)):
            for dep in RequirementsParser.parse(req_file):
                key = dep.name.lower()
                if key not in seen_names:
                    seen_names.add(key)
                    deps.append(dep)

        return deps

    @staticmethod
    def fix_hint(project_path: Path) -> str:
        """Return pip install command."""
        return "pip install -r requirements.txt"

    @staticmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """Plain pip has no separate lockfile; requirements.txt is the closest."""
        req = project_path / "requirements.txt"
        return req if req.exists() else None
