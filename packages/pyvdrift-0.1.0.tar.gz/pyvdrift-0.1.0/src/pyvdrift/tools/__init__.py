"""Tool-specific detection and venv resolution modules."""
