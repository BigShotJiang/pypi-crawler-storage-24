"""Pipenv tool detection, venv resolution (including hash), and dep parsing."""

from __future__ import annotations

import hashlib
import platform
from pathlib import Path

from pyvdrift.core.project import DeclaredDep
from pyvdrift.parsers.pipfile import PipfileParser
from pyvdrift.tools.base import Tool


class PipenvTool(Tool):
    """Detect and resolve Pipenv-managed projects."""

    @staticmethod
    def detect(project_path: Path) -> bool:
        """Return True if Pipfile is present."""
        return (project_path / "Pipfile").exists()

    @staticmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """Resolve Pipenv venv using its hash algorithm.

        Pipenv stores venvs at:
          ~/.local/share/virtualenvs/{project_name}-{hash}/
        where hash = first 8 chars of SHA256 of the project path.
        """
        # Check in-project .venv first
        in_project = project_path / ".venv"
        if in_project.is_dir() and (in_project / "pyvenv.cfg").exists():
            return in_project

        venv_base = _pipenv_venv_base()
        if not venv_base.is_dir():
            return None

        project_name = project_path.name
        path_hash = hashlib.sha256(str(project_path.resolve()).encode()).hexdigest()[:8]
        venv_name = f"{project_name}-{path_hash}"

        venv = venv_base / venv_name
        if venv.is_dir():
            return venv

        # Fallback: scan for dirs starting with project name
        candidates: list[Path] = []
        for entry in venv_base.iterdir():
            if entry.is_dir() and entry.name.startswith(f"{project_name}-"):
                candidates.append(entry)

        return max(candidates, key=lambda p: p.stat().st_mtime) if candidates else None

    @staticmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse Pipfile for dependencies."""
        pipfile = project_path / "Pipfile"
        return PipfileParser.parse(pipfile) if pipfile.exists() else []

    @staticmethod
    def fix_hint(project_path: Path) -> str:
        """Return pipenv install command."""
        return "pipenv install"

    @staticmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """Return path to Pipfile.lock if it exists."""
        lock = project_path / "Pipfile.lock"
        return lock if lock.exists() else None


def _pipenv_venv_base() -> Path:
    """Return the base directory where Pipenv stores virtualenvs."""
    system = platform.system()
    if system == "Windows":
        return Path.home() / ".virtualenvs"
    # Linux and macOS
    return Path.home() / ".local" / "share" / "virtualenvs"
