"""Poetry tool detection, venv resolution (including hash), and dep parsing."""

from __future__ import annotations

import contextlib
import hashlib
import platform
import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

from pyvdrift.core.project import DeclaredDep
from pyvdrift.parsers.pyproject import PyprojectParser
from pyvdrift.tools.base import Tool


class PoetryTool(Tool):
    """Detect and resolve Poetry-managed projects."""

    @staticmethod
    def detect(project_path: Path) -> bool:
        """Return True if [tool.poetry] in pyproject.toml or poetry.lock exists."""
        if (project_path / "poetry.lock").exists():
            return True
        pyproject = project_path / "pyproject.toml"
        if pyproject.exists():
            with contextlib.suppress(Exception):
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                return "poetry" in data.get("tool", {})
            
        return False

    @staticmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """Resolve Poetry venv: check in-project .venv first, then cache dir.

        Poetry uses a hash of the project path to name the venv directory.
        """
        # Check in-project venv first
        in_project = project_path / ".venv"
        if in_project.is_dir() and (in_project / "pyvenv.cfg").exists():
            return in_project

        # Reconstruct Poetry's venv hash and check cache directory
        venv_base = _poetry_venv_base()
        if not venv_base.is_dir():
            return None

        project_name = project_path.name.lower()

        # Poetry hash: MD5 of the resolved project path, first 8 hex chars
        path_str = str(project_path.resolve())
        venv_hash = hashlib.md5(path_str.encode()).hexdigest()[:8]

        # Look for exact match first
        for entry in venv_base.iterdir():
            if entry.is_dir() and entry.name.startswith(f"{project_name}-{venv_hash}"):
                return entry

        # Fallback: scan for dirs starting with project name
        candidates: list[Path] = []
        for entry in venv_base.iterdir():
            if entry.is_dir() and entry.name.startswith(f"{project_name}-"):
                candidates.append(entry)

        return max(candidates, key=lambda p: p.stat().st_mtime) if candidates else None

    @staticmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse pyproject.toml for Poetry dependency sections."""
        pyproject = project_path / "pyproject.toml"
        return PyprojectParser.parse(pyproject) if pyproject.exists() else []

    @staticmethod
    def fix_hint(project_path: Path) -> str:
        """Return poetry install command."""
        return "poetry install"

    @staticmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """Return path to poetry.lock if it exists."""
        lock = project_path / "poetry.lock"
        return lock if lock.exists() else None


def _poetry_venv_base() -> Path:
    """Return the base directory where Poetry stores virtualenvs."""
    system = platform.system()
    if system == "Darwin":
        return Path.home() / "Library" / "Caches" / "pypoetry" / "virtualenvs"
    if system == "Windows":
        appdata = Path.home() / "AppData" / "Roaming"
        return appdata / "pypoetry" / "virtualenvs"
    # Linux and others
    return Path.home() / ".cache" / "pypoetry" / "virtualenvs"
