"""conda/mamba tool detection, venv resolution, and dep parsing.

All conda subprocess calls are optional — if conda is not installed,
detection still works (via environment.yml) but venv resolution is skipped.
"""

from __future__ import annotations

import contextlib
import json
import subprocess
from pathlib import Path

import yaml

from pyvdrift.core.project import DeclaredDep
from pyvdrift.parsers.conda_env import CondaEnvParser
from pyvdrift.tools.base import Tool


class CondaTool(Tool):
    """Detect and resolve conda/mamba-managed projects."""

    @staticmethod
    def detect(project_path: Path) -> bool:
        """Return True if environment.yml or environment.yaml is present."""
        return (
            (project_path / "environment.yml").exists()
            or (project_path / "environment.yaml").exists()
        )

    @staticmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """Resolve conda environment via subprocess (optional).

        Returns the env path if conda is installed and the environment exists,
        None otherwise. Never raises on missing conda binary.
        """
        env_file = _find_env_file(project_path)
        if env_file is None:
            return None

        env_name = _get_env_name(env_file)
        if not env_name:
            return None

        try:
            result = subprocess.run(
                ["conda", "env", "list", "--json"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return None
            data = json.loads(result.stdout)
            for env_path_str in data.get("envs", []):
                env_path = Path(env_path_str)
                if env_path.name == env_name:
                    return env_path
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
            return None

        return None

    @staticmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse environment.yml for dependencies."""
        env_file = _find_env_file(project_path)
        return [] if env_file is None else CondaEnvParser.parse(env_file)

    @staticmethod
    def fix_hint(project_path: Path) -> str:
        """Return conda env update command."""
        env_file = _find_env_file(project_path)
        filename = env_file.name if env_file else "environment.yml"
        return f"conda env update -f {filename}"

    @staticmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """conda does not have a lockfile."""
        return None


def _find_env_file(project_path: Path) -> Path | None:
    """Find environment.yml or environment.yaml."""
    for name in ("environment.yml", "environment.yaml"):
        path = project_path / name
        if path.exists():
            return path
    return None


def _get_env_name(env_file: Path) -> str | None:
    """Read the `name:` field from environment.yml."""
    with contextlib.suppress(Exception):
        data = yaml.safe_load(env_file.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data.get("name")

    return None
