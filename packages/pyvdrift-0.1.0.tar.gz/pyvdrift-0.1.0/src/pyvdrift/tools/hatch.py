"""Hatch tool detection, venv resolution, and dep parsing."""

from __future__ import annotations

import contextlib
import platform
import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

from pyvdrift.core.project import DeclaredDep
from pyvdrift.parsers.pyproject import PyprojectParser
from pyvdrift.tools.base import Tool


class HatchTool(Tool):
    """Detect and resolve Hatch-managed projects."""

    @staticmethod
    def detect(project_path: Path) -> bool:
        """Return True if [tool.hatch] in pyproject.toml."""
        pyproject = project_path / "pyproject.toml"
        if pyproject.exists():
            with contextlib.suppress(Exception):
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                return "hatch" in data.get("tool", {})
        return False

    @staticmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """Check Hatch's global venv storage."""
        # Check in-project .venv first
        in_project = project_path / ".venv"
        if in_project.is_dir() and (in_project / "pyvenv.cfg").exists():
            return in_project

        venv_base = _hatch_venv_base()
        if not venv_base.is_dir():
            return None

        project_name = project_path.name.lower()
        project_dir = venv_base / project_name

        if project_dir.is_dir():
            # Look for any venv hash directory inside
            for entry in project_dir.iterdir():
                if entry.is_dir():
                    # Hatch creates subdirs per env name, e.g. default/
                    for sub in entry.iterdir():
                        if sub.is_dir() and (sub / "pyvenv.cfg").exists():
                            return sub
                    if (entry / "pyvenv.cfg").exists():
                        return entry

        return None

    @staticmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse pyproject.toml for project dependencies."""
        pyproject = project_path / "pyproject.toml"
        if not pyproject.exists():
            return []
        return PyprojectParser.parse(pyproject)

    @staticmethod
    def fix_hint(project_path: Path) -> str:
        """Return hatch env create command."""
        return "hatch env create"

    @staticmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """Hatch does not have a lockfile."""
        return None


def _hatch_venv_base() -> Path:
    """Return the base directory where Hatch stores virtualenvs."""
    system = platform.system()
    if system == "Windows":
        return Path.home() / "AppData" / "Local" / "hatch" / "env" / "virtual"
    return Path.home() / ".local" / "share" / "hatch" / "env" / "virtual"
