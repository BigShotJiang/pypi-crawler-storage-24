"""Abstract base interface for tool modules."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from pyvdrift.core.project import DeclaredDep


class Tool(ABC):
    """Interface that every tool module must implement."""

    @staticmethod
    @abstractmethod
    def detect(project_path: Path) -> bool:
        """Return True if this tool manages the given project."""

    @staticmethod
    @abstractmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """Return path to the venv directory, or None if not found."""

    @staticmethod
    @abstractmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse all dep files for this tool and return declared deps."""

    @staticmethod
    @abstractmethod
    def fix_hint(project_path: Path) -> str:
        """Return the command a user should run to fix drift."""

    @staticmethod
    @abstractmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """Return path to the lockfile if one exists."""
