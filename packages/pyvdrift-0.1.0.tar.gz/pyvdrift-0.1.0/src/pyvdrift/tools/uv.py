"""uv tool detection, venv resolution, and dep parsing."""

from __future__ import annotations

import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

from pyvdrift.core.project import DeclaredDep
from pyvdrift.parsers.pyproject import PyprojectParser
from pyvdrift.tools.base import Tool


class UvTool(Tool):
    """Detect and resolve uv-managed projects."""

    @staticmethod
    def detect(project_path: Path) -> bool:
        """Return True if uv.lock is present or [tool.uv] in pyproject.toml."""
        if (project_path / "uv.lock").exists():
            return True
        pyproject = project_path / "pyproject.toml"
        if pyproject.exists():
            try:
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                return "uv" in data.get("tool", {})
            except Exception:
                pass
        return False

    @staticmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """uv always uses .venv/ in the project root."""
        venv = project_path / ".venv"
        if venv.is_dir() and (venv / "pyvenv.cfg").exists():
            return venv
        return None

    @staticmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse pyproject.toml for project and uv dev dependencies."""
        pyproject = project_path / "pyproject.toml"
        if not pyproject.exists():
            return []
        return PyprojectParser.parse(pyproject)

    @staticmethod
    def fix_hint(project_path: Path) -> str:
        """Return uv sync command."""
        return "uv sync"

    @staticmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """Return path to uv.lock if it exists."""
        lock = project_path / "uv.lock"
        return lock if lock.exists() else None

    @staticmethod
    def python_version(project_path: Path) -> str | None:
        """Read declared Python version from .python-version or pyproject.toml."""
        pv_file = project_path / ".python-version"
        if pv_file.exists():
            return pv_file.read_text().strip()

        pyproject = project_path / "pyproject.toml"
        if pyproject.exists():
            try:
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                uv = data.get("tool", {}).get("uv", {})
                if "python" in uv:
                    return uv["python"]
            except Exception:
                pass
        return None
