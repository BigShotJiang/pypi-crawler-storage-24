"""PDM tool detection, venv resolution, and dep parsing."""

from __future__ import annotations

import contextlib
import platform
import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

from pyvdrift.core.project import DeclaredDep
from pyvdrift.parsers.pyproject import PyprojectParser
from pyvdrift.tools.base import Tool


class PdmTool(Tool):
    """Detect and resolve PDM-managed projects."""

    @staticmethod
    def detect(project_path: Path) -> bool:
        """Return True if [tool.pdm] in pyproject.toml or pdm.lock exists."""
        if (project_path / "pdm.lock").exists():
            return True
        pyproject = project_path / "pyproject.toml"
        if pyproject.exists():
            with contextlib.suppress(Exception):
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                return "pdm" in data.get("tool", {})
            
        return False

    @staticmethod
    def resolve_venv(project_path: Path) -> Path | None:
        """Check .venv/ first, then PDM's global venv storage."""
        venv = project_path / ".venv"
        if venv.is_dir() and (venv / "pyvenv.cfg").exists():
            return venv

        # Check PDM global venv location
        venv_base = _pdm_venv_base()
        if not venv_base.is_dir():
            return None

        project_name = project_path.name.lower()
        for entry in venv_base.iterdir():
            if entry.is_dir() and entry.name.startswith(f"{project_name}-"):
                return entry
        return None

    @staticmethod
    def declared_deps(project_path: Path) -> list[DeclaredDep]:
        """Parse pyproject.toml for PDM dependencies."""
        pyproject = project_path / "pyproject.toml"
        return PyprojectParser.parse(pyproject) if pyproject.exists() else []

    @staticmethod
    def fix_hint(project_path: Path) -> str:
        """Return pdm install command."""
        return "pdm install"

    @staticmethod
    def lockfile_path(project_path: Path) -> Path | None:
        """Return path to pdm.lock if it exists."""
        lock = project_path / "pdm.lock"
        return lock if lock.exists() else None


def _pdm_venv_base() -> Path:
    """Return the base directory where PDM stores virtualenvs."""
    system = platform.system()
    if system == "Windows":
        return Path.home() / "AppData" / "Local" / "pdm" / "venvs"
    return Path.home() / ".local" / "share" / "pdm" / "venvs"
