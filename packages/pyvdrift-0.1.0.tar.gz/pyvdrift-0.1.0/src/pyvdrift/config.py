"""Configuration file management for pyvdrift.

Config file location: ~/.config/pyvdrift/config.toml
"""

from __future__ import annotations

import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

from pyvdrift.exceptions import PyvdriftError

_CONFIG_DIR = Path.home() / ".config" / "pyvdrift"
_CONFIG_FILE = _CONFIG_DIR / "config.toml"


def get_config_path() -> Path:
    """Return the path to the config file."""
    return _CONFIG_FILE


def load_config() -> dict:
    """Load the config file, returning an empty dict if it doesn't exist."""
    if not _CONFIG_FILE.exists():
        return {}
    try:
        with open(_CONFIG_FILE, "rb") as f:
            return tomllib.load(f)
    except Exception as e:
        raise PyvdriftError(f"load config {_CONFIG_FILE}: {e}") from e


def save_config(config: dict) -> None:
    """Save config as human-readable TOML."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    _write_toml(config, lines, depth=0)
    _CONFIG_FILE.write_text("\n".join(lines) + "\n")


def save_projects(project_paths: list[str]) -> None:
    """Save discovered project paths to config."""
    config = load_config()
    config["projects"] = {"paths": project_paths}
    save_config(config)


def load_saved_projects() -> list[str]:
    """Load saved project paths from config."""
    config = load_config()
    return config.get("projects", {}).get("paths", [])


def _write_toml(data: dict, lines: list[str], depth: int, prefix: str = "") -> None:
    """Simple TOML serializer for human-readable output."""
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            lines.append(f"\n[{full_key}]")
            _write_toml(value, lines, depth + 1, full_key)
        elif isinstance(value, list):
            items = ", ".join(f'"{v}"' if isinstance(v, str) else str(v) for v in value)
            lines.append(f"{key} = [{items}]")
        elif isinstance(value, str):
            lines.append(f'{key} = "{value}"')
        elif isinstance(value, bool):
            lines.append(f"{key} = {'true' if value else 'false'}")
        elif isinstance(value, (int, float)):
            lines.append(f"{key} = {value}")
