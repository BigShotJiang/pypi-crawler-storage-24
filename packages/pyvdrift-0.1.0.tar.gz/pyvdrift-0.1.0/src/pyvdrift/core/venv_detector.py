"""Dispatches venv resolution to the appropriate tool module."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from pyvdrift.core.project import Project, Toolchain
from pyvdrift.tools.conda import CondaTool
from pyvdrift.tools.hatch import HatchTool
from pyvdrift.tools.legacy import LegacyTool
from pyvdrift.tools.pdm import PdmTool
from pyvdrift.tools.pip import PipTool
from pyvdrift.tools.pipenv import PipenvTool
from pyvdrift.tools.poetry import PoetryTool
from pyvdrift.tools.uv import UvTool

_TOOL_MAP = {
    Toolchain.UV: UvTool,
    Toolchain.POETRY: PoetryTool,
    Toolchain.PIPENV: PipenvTool,
    Toolchain.PIP: PipTool,
    Toolchain.HATCH: HatchTool,
    Toolchain.PDM: PdmTool,
    Toolchain.CONDA: CondaTool,
    Toolchain.LEGACY: LegacyTool,
}


def resolve_venv(project: Project) -> Path | None:
    """Try each of the project's toolchains to find a venv.

    Returns the first venv path found, or None.
    """
    for toolchain in project.toolchains:
        tool_cls = _TOOL_MAP.get(toolchain)
        if tool_cls is None:
            continue
        venv = tool_cls.resolve_venv(project.path)
        if venv is not None:
            return venv
    return None


def get_last_activated(venv_path: Path) -> datetime | None:
    """Get the last activation time of a venv from pyvenv.cfg mtime."""
    cfg = venv_path / "pyvenv.cfg"
    if cfg.exists():
        mtime = cfg.stat().st_mtime
        return datetime.fromtimestamp(mtime, tz=timezone.utc)
    return None
