"""Core data models for pyvdrift."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Literal


class Toolchain(Enum):
    """Supported Python package managers and build tools."""

    UV = "uv"
    POETRY = "poetry"
    PIPENV = "pipenv"
    PIP = "pip"
    HATCH = "hatch"
    PDM = "pdm"
    CONDA = "conda"
    LEGACY = "legacy"
    UNKNOWN = "unknown"


@dataclass
class Project:
    """Represents a detected Python project on disk."""

    path: Path
    name: str
    toolchains: list[Toolchain] = field(default_factory=list)
    dep_files: list[Path] = field(default_factory=list)
    venv_path: Path | None = None
    interpreter: str | None = None
    python_version: str | None = None
    last_activated: datetime | None = None


@dataclass
class DeclaredDep:
    """A dependency declared in a requirements or config file."""

    name: str
    specifier: str = ""
    extras: list[str] = field(default_factory=list)
    source_file: Path = field(default_factory=lambda: Path("."))
    is_dev: bool = False


@dataclass
class InstalledPkg:
    """A package installed in a venv's site-packages."""

    name: str
    version: str
    location: Path = field(default_factory=lambda: Path("."))


@dataclass
class DriftResult:
    """Result of comparing declared deps vs installed packages."""

    project: Project
    missing: list[DeclaredDep] = field(default_factory=list)
    version_mismatch: list[tuple[DeclaredDep, InstalledPkg]] = field(default_factory=list)
    undeclared: list[InstalledPkg] = field(default_factory=list)
    ok: list[DeclaredDep] = field(default_factory=list)


@dataclass
class CheckResult:
    """Result of a single health check."""

    name: str
    status: Literal["ok", "warn", "error"] = "ok"
    message: str = ""
    fix_hint: str | None = None
