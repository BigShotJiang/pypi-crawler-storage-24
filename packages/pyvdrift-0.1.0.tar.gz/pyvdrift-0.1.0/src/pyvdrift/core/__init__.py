"""Core modules for project detection, scanning, and drift analysis."""
