"""Filesystem walker that finds Python projects."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.core.project import Project, Toolchain
from pyvdrift.exceptions import PyvdriftError
from pyvdrift.tools.conda import CondaTool
from pyvdrift.tools.hatch import HatchTool
from pyvdrift.tools.legacy import LegacyTool
from pyvdrift.tools.pdm import PdmTool
from pyvdrift.tools.pip import PipTool
from pyvdrift.tools.pipenv import PipenvTool
from pyvdrift.tools.poetry import PoetryTool
from pyvdrift.tools.uv import UvTool

_SKIP_DIRS = frozenset({
    "node_modules",
    ".git",
    "__pycache__",
    "site-packages",
    "dist",
    "build",
    ".tox",
    ".nox",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
    ".eggs",
})

_PROJECT_MARKERS = (
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "Pipfile",
    "environment.yml",
    "environment.yaml",
)

# Tool detectors in priority order
_TOOL_DETECTORS: list[tuple[Toolchain, type]] = [
    (Toolchain.UV, UvTool),
    (Toolchain.POETRY, PoetryTool),
    (Toolchain.PIPENV, PipenvTool),
    (Toolchain.PDM, PdmTool),
    (Toolchain.HATCH, HatchTool),
    (Toolchain.CONDA, CondaTool),
    (Toolchain.PIP, PipTool),
    (Toolchain.LEGACY, LegacyTool),
]


def scan_projects(
    root: Path,
    *,
    max_depth: int = 5,
    ignore_patterns: list[str] | None = None,
) -> list[Project]:
    """Walk the filesystem from root and find Python projects.

    Args:
        root: Starting directory for the scan.
        max_depth: Maximum directory depth to traverse.
        ignore_patterns: Additional directory names to skip.

    Returns:
        List of detected Project objects.
    """
    try:
        return _scan(root, max_depth=max_depth, ignore_patterns=ignore_patterns)
    except PyvdriftError:
        raise
    except Exception as e:
        raise PyvdriftError(f"scan {root}: {e}") from e


def _scan(
    root: Path,
    *,
    max_depth: int,
    ignore_patterns: list[str] | None,
) -> list[Project]:
    root = root.expanduser().resolve()
    if not root.is_dir():
        return []

    skip_dirs = set(_SKIP_DIRS)
    if ignore_patterns:
        skip_dirs.update(ignore_patterns)

    # Also load .pyvdrift-ignore if it exists
    ignore_file = root / ".pyvdrift-ignore"
    if ignore_file.exists():
        for line in ignore_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                skip_dirs.add(line)

    projects: list[Project] = []
    seen_paths: set[Path] = set()

    _walk(root, root, max_depth, skip_dirs, projects, seen_paths)
    return projects


def _walk(
    current: Path,
    root: Path,
    max_depth: int,
    skip_dirs: set[str],
    projects: list[Project],
    seen: set[Path],
) -> None:
    """Recursively walk directories to find projects."""
    depth = len(current.relative_to(root).parts)
    if depth > max_depth:
        return

    if _is_python_project(current) and current not in seen:
        seen.add(current)
        project = _detect_project(current)
        projects.append(project)
        # Don't recurse into detected projects' subdirs
        return

    try:
        entries = sorted(current.iterdir())
    except PermissionError:
        return

    for entry in entries:
        if not entry.is_dir():
            continue
        if entry.name in skip_dirs:
            continue
        if entry.name.startswith(".") and entry.name not in (".venv", ".git"):
            continue
        _walk(entry, root, max_depth, skip_dirs, projects, seen)


def _is_python_project(directory: Path) -> bool:
    """Check if a directory looks like a Python project."""
    for marker in _PROJECT_MARKERS:
        if (directory / marker).exists():
            return True
    return bool(list(directory.glob("requirements*.txt")))


def _detect_project(project_path: Path) -> Project:
    """Detect which toolchains manage a project and gather metadata."""
    toolchains: list[Toolchain] = []
    dep_files: list[Path] = []

    for toolchain, tool_cls in _TOOL_DETECTORS:
        if tool_cls.detect(project_path):
            toolchains.append(toolchain)
            if lock := tool_cls.lockfile_path(project_path):
                dep_files.append(lock)

    if not toolchains:
        toolchains.append(Toolchain.UNKNOWN)

    # Collect all dep files
    for marker in _PROJECT_MARKERS:
        path = project_path / marker
        if path.exists() and path not in dep_files:
            dep_files.append(path)

    for req_file in project_path.glob("requirements*.txt"):
        if req_file not in dep_files:
            dep_files.append(req_file)

    return Project(
        path=project_path,
        name=project_path.name,
        toolchains=toolchains,
        dep_files=sorted(dep_files),
    )
