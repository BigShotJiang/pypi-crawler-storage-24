"""Drift detection: compare declared deps vs installed packages."""

from __future__ import annotations

import re
from pathlib import Path

from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.version import InvalidVersion, Version

from pyvdrift.core.project import (
    DeclaredDep,
    DriftResult,
    InstalledPkg,
    Project,
    Toolchain,
)
from pyvdrift.exceptions import PyvdriftError
from pyvdrift.tools.conda import CondaTool
from pyvdrift.tools.hatch import HatchTool
from pyvdrift.tools.legacy import LegacyTool
from pyvdrift.tools.pdm import PdmTool
from pyvdrift.tools.pip import PipTool
from pyvdrift.tools.pipenv import PipenvTool
from pyvdrift.tools.poetry import PoetryTool
from pyvdrift.tools.uv import UvTool

_TOOL_MAP = {
    Toolchain.UV: UvTool,
    Toolchain.POETRY: PoetryTool,
    Toolchain.PIPENV: PipenvTool,
    Toolchain.PIP: PipTool,
    Toolchain.HATCH: HatchTool,
    Toolchain.PDM: PdmTool,
    Toolchain.CONDA: CondaTool,
    Toolchain.LEGACY: LegacyTool,
}


def detect_drift(
    project: Project, *, include_dev: bool = False
) -> DriftResult:
    """Compare declared dependencies vs installed packages for a project.

    Args:
        project: The project to check.
        include_dev: Whether to include dev/optional dependencies.

    Returns:
        DriftResult with missing, mismatched, undeclared, and ok deps.
    """
    try:
        return _detect(project, include_dev=include_dev)
    except PyvdriftError:
        raise
    except Exception as e:
        raise PyvdriftError(f"drift check {project.path}: {e}") from e


def _detect(project: Project, *, include_dev: bool) -> DriftResult:
    # Gather declared deps from all tools
    declared = _gather_declared(project, include_dev=include_dev)

    # Read installed packages from venv
    installed = _read_installed(project.venv_path) if project.venv_path else {}

    missing: list[DeclaredDep] = []
    version_mismatch: list[tuple[DeclaredDep, InstalledPkg]] = []
    ok: list[DeclaredDep] = []

    declared_names: set[str] = set()

    for dep in declared:
        normalized = _normalize(dep.name)
        declared_names.add(normalized)

        pkg = installed.get(normalized)
        if pkg is None:
            missing.append(dep)
            continue

        if dep.specifier and not _version_matches(pkg.version, dep.specifier):
            version_mismatch.append((dep, pkg))
        else:
            ok.append(dep)

    # Find undeclared packages
    undeclared: list[InstalledPkg] = []
    undeclared.extend(
        pkg
        for name, pkg in installed.items()
        if name not in declared_names and not _is_stdlib_dist(name)
    )

    return DriftResult(
        project=project,
        missing=missing,
        version_mismatch=version_mismatch,
        undeclared=undeclared,
        ok=ok,
    )


def _gather_declared(project: Project, *, include_dev: bool) -> list[DeclaredDep]:
    """Gather all declared deps from the project's toolchains."""
    all_deps: list[DeclaredDep] = []
    seen: set[str] = set()

    for toolchain in project.toolchains:
        tool_cls = _TOOL_MAP.get(toolchain)
        if tool_cls is None:
            continue
        for dep in tool_cls.declared_deps(project.path):
            if not include_dev and dep.is_dev:
                continue
            key = _normalize(dep.name)
            if key not in seen:
                seen.add(key)
                all_deps.append(dep)

    return all_deps


def _read_installed(venv_path: Path) -> dict[str, InstalledPkg]:
    """Read installed packages from venv site-packages .dist-info dirs."""
    installed: dict[str, InstalledPkg] = {}

    lib_dir = venv_path / "lib"
    if not lib_dir.exists():
        return installed

    for pydir in lib_dir.iterdir():
        sp = pydir / "site-packages"
        if not sp.is_dir():
            continue
        for dist_info in sp.glob("*.dist-info"):
            metadata = dist_info / "METADATA"
            if not metadata.exists():
                continue
            name, version = _parse_metadata(metadata)
            if name:
                normalized = _normalize(name)
                installed[normalized] = InstalledPkg(
                    name=name, version=version, location=dist_info
                )

    return installed


def _parse_metadata(metadata_path: Path) -> tuple[str, str]:
    """Extract Name and Version from a METADATA file."""
    name = ""
    version = ""
    for line in metadata_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Name: "):
            name = line[6:].strip()
        elif line.startswith("Version: "):
            version = line[9:].strip()
        if name and version:
            break
    return name, version


def _version_matches(installed_version: str, specifier: str) -> bool:
    """Check if an installed version satisfies the specifier."""
    try:
        ver = Version(installed_version)
        spec = SpecifierSet(specifier)
        return ver in spec
    except (InvalidVersion, InvalidSpecifier):
        return True  # Can't determine, assume ok


def _normalize(name: str) -> str:
    """Normalize a package name (PEP 503)."""
    return re.sub(r"[-_.]+", "-", name).lower()


def _is_stdlib_dist(name: str) -> bool:
    """Heuristic: skip common stdlib/infrastructure dist-info packages."""
    return name in {"pip", "setuptools", "wheel", "pkg-resources", "distribute"}
