"""Resolves the Python interpreter for a project."""

from __future__ import annotations

import re
from pathlib import Path

from pyvdrift.core.project import Project


def resolve_interpreter(project: Project) -> str | None:
    """Find the Python binary path for a project's venv."""
    if project.venv_path is None:
        return None

    # Check common binary locations
    for bin_name in ("python3", "python"):
        for bin_dir in ("bin", "Scripts"):
            binary = project.venv_path / bin_dir / bin_name
            if binary.exists():
                return str(binary)
    return None


def read_venv_python_version(venv_path: Path) -> str | None:
    """Read the Python version from pyvenv.cfg."""
    cfg = venv_path / "pyvenv.cfg"
    if not cfg.exists():
        return None

    for line in cfg.read_text().splitlines():
        line = line.strip()
        if line.lower().startswith("version"):
            if match := re.search(r"(\d+\.\d+(?:\.\d+)?)", line):
                return match[1]
    return None
