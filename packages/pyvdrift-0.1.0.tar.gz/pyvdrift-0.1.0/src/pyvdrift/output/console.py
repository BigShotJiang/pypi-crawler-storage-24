"""Rich console output for pyvdrift."""

from __future__ import annotations

import contextlib
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from pyvdrift.core.project import CheckResult, DriftResult, Project

console = Console()

_STATUS_ICONS = {
    "ok": "\u2705",
    "warn": "\u26a0\ufe0f",
    "error": "\u274c",
}

_STATUS_COLORS = {
    "ok": "green",
    "warn": "yellow",
    "error": "red",
}


def print_scan_results(projects: list[Project]) -> None:
    """Print scan results as a rich table."""
    if not projects:
        console.print("[dim]No Python projects found.[/dim]")
        return

    table = Table(title="Python Projects Found", show_lines=True)
    table.add_column("Project", style="bold")
    table.add_column("Path", style="dim")
    table.add_column("Tool", style="cyan")
    table.add_column("Venv", style="green")
    table.add_column("Python")
    table.add_column("Last Used")

    for project in projects:
        tools = ", ".join(t.value for t in project.toolchains)
        venv = str(project.venv_path.name) if project.venv_path else "-"
        python = project.python_version or "-"
        last_used = _format_age(project.last_activated) if project.last_activated else "-"

        table.add_row(project.name, str(project.path), tools, venv, python, last_used)

    console.print(table)
    console.print(f"\n[bold]{len(projects)}[/bold] project(s) found.")


def print_drift_result(result: DriftResult) -> None:
    """Print drift check results as a colored table."""
    project = result.project
    tools = ", ".join(t.value for t in project.toolchains)

    console.print(Panel(
        f"[bold]{project.name}[/bold] — detected tool: [cyan]{tools}[/cyan]",
        title="Drift Check",
    ))

    if not result.missing and not result.version_mismatch and not result.undeclared:
        console.print("[green]No drift detected. All packages are in sync.[/green]\n")
        return

    table = Table(show_header=True)
    table.add_column("Status")
    table.add_column("Package")
    table.add_column("Declared")
    table.add_column("Installed")
    table.add_column("Source")

    for dep in result.missing:
        table.add_row(
            Text("MISSING", style="bold red"),
            dep.name,
            dep.specifier or "*",
            "-",
            dep.source_file.name,
        )

    for dep, pkg in result.version_mismatch:
        table.add_row(
            Text("MISMATCH", style="bold yellow"),
            dep.name,
            dep.specifier,
            pkg.version,
            dep.source_file.name,
        )

    for pkg in result.undeclared:
        table.add_row(
            Text("EXTRA", style="bold blue"),
            pkg.name,
            "-",
            pkg.version,
            "-",
        )

    for dep in result.ok:
        table.add_row(
            Text("OK", style="green"),
            dep.name,
            dep.specifier or "*",
            "",
            dep.source_file.name,
        )

    console.print(table)


def print_doctor_results(project: Project, checks: list[CheckResult]) -> None:
    """Print doctor check results."""
    tools = ", ".join(t.value for t in project.toolchains)

    console.print(Panel(
        f"[bold]{project.name}[/bold] — detected tool: [cyan]{tools}[/cyan]",
        title="Doctor",
    ))

    for check in checks:
        icon = _STATUS_ICONS.get(check.status, "?")
        color = _STATUS_COLORS.get(check.status, "white")
        line = f"  {icon}  [{color}]{check.message}[/{color}]"
        if check.fix_hint:
            line += f" — run: [bold]{check.fix_hint}[/bold]"
        console.print(line)

    console.print()


def print_list_dashboard(entries: list[tuple[Project, list[CheckResult], DriftResult | None]]) -> None:
    """Print the list dashboard table."""
    if not entries:
        console.print("[dim]No projects found.[/dim]")
        return

    table = Table(title="Project Dashboard", show_lines=True)
    table.add_column("Name", style="bold")
    table.add_column("Tool", style="cyan")
    table.add_column("Health")
    table.add_column("Missing", justify="right")
    table.add_column("Last Used")

    for project, checks, drift in entries:
        tools = ", ".join(t.value for t in project.toolchains)
        health = _overall_health(checks)
        icon = _STATUS_ICONS.get(health, "?")
        color = _STATUS_COLORS.get(health, "white")
        health_text = Text(f"{icon} {health}", style=color)
        n_missing = str(len(drift.missing)) if drift else "?"
        last_used = _format_age(project.last_activated) if project.last_activated else "never"

        table.add_row(project.name, tools, health_text, n_missing, last_used)

    console.print(table)


def print_clean_preview(entries: list[tuple[Project, int]]) -> None:
    """Print clean preview of stale venvs."""
    if not entries:
        console.print("[dim]No stale venvs found.[/dim]")
        return

    table = Table(title="Stale Virtual Environments")
    table.add_column("Project", style="bold")
    table.add_column("Tool", style="cyan")
    table.add_column("Venv Path")
    table.add_column("Age (days)", justify="right")
    table.add_column("Size")

    total_size = 0
    for project, age_days in entries:
        tools = ", ".join(t.value for t in project.toolchains)
        venv_path = str(project.venv_path) if project.venv_path else "-"
        size = _dir_size(project.venv_path) if project.venv_path else 0
        total_size += size
        table.add_row(
            project.name, tools, venv_path, str(age_days), _format_size(size)
        )

    console.print(table)
    console.print(f"\nTotal space reclaimable: [bold]{_format_size(total_size)}[/bold]")


def _overall_health(checks: list[CheckResult]) -> str:
    """Determine overall health from a list of check results."""
    statuses = {c.status for c in checks}
    if "error" in statuses:
        return "error"
    return "warn" if "warn" in statuses else "ok"


def _format_age(dt: datetime) -> str:
    """Format a datetime as a human-readable age string."""
    now = datetime.now(tz=timezone.utc)
    delta = now - dt
    days = delta.days
    if days == 0:
        return "today"
    if days == 1:
        return "1 day ago"
    if days < 30:
        return f"{days} days ago"
    if days < 365:
        months = days // 30
        return f"{months} month(s) ago"
    years = days // 365
    return f"{years} year(s) ago"


def _dir_size(path: Path | None) -> int:
    """Calculate total size of a directory in bytes."""
    if path is None or not path.exists():
        return 0
    total = 0
    with contextlib.suppress(PermissionError):
        for f in path.rglob("*"):
            if f.is_file():
                total += f.stat().st_size
    return total


def _format_size(size_bytes: int) -> str:
    """Format bytes as human-readable size."""
    for unit in ("B", "KB", "MB", "GB"):
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"
