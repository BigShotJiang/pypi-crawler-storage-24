"""Output formatters for console and JSON."""
