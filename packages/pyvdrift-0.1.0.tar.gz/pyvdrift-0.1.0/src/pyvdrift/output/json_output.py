"""JSON output for pyvdrift --json flag."""

from __future__ import annotations

import json
from typing import Any

from pyvdrift.core.project import CheckResult, DriftResult, Project


def projects_to_json(projects: list[Project]) -> str:
    """Serialize scan results to JSON."""
    return json.dumps([_project_dict(p) for p in projects], indent=2)


def drift_to_json(result: DriftResult) -> str:
    """Serialize drift result to JSON."""
    return json.dumps(
        {
            "project": _project_dict(result.project),
            "missing": [
                {"name": d.name, "specifier": d.specifier, "source": str(d.source_file)}
                for d in result.missing
            ],
            "version_mismatch": [
                {
                    "name": d.name,
                    "specifier": d.specifier,
                    "installed": p.version,
                }
                for d, p in result.version_mismatch
            ],
            "undeclared": [
                {"name": p.name, "version": p.version}
                for p in result.undeclared
            ],
            "ok": [{"name": d.name, "specifier": d.specifier} for d in result.ok],
        },
        indent=2,
    )


def checks_to_json(project: Project, checks: list[CheckResult]) -> str:
    """Serialize doctor results to JSON."""
    return json.dumps(
        {
            "project": _project_dict(project),
            "checks": [
                {
                    "name": c.name,
                    "status": c.status,
                    "message": c.message,
                    "fix_hint": c.fix_hint,
                }
                for c in checks
            ],
        },
        indent=2,
    )


def dashboard_to_json(
    entries: list[tuple[Project, list[CheckResult], DriftResult | None]]
) -> str:
    """Serialize list dashboard to JSON."""
    items: list[dict[str, Any]] = []
    for project, checks, drift in entries:
        statuses = {c.status for c in checks}
        health = "error" if "error" in statuses else ("warn" if "warn" in statuses else "ok")
        items.append({
            "name": project.name,
            "path": str(project.path),
            "tools": [t.value for t in project.toolchains],
            "health": health,
            "missing": len(drift.missing) if drift else None,
            "last_used": project.last_activated.isoformat() if project.last_activated else None,
        })
    return json.dumps(items, indent=2)


def _project_dict(project: Project) -> dict[str, Any]:
    """Convert a Project to a JSON-serializable dict."""
    return {
        "name": project.name,
        "path": str(project.path),
        "toolchains": [t.value for t in project.toolchains],
        "venv_path": str(project.venv_path) if project.venv_path else None,
        "python_version": project.python_version,
    }
