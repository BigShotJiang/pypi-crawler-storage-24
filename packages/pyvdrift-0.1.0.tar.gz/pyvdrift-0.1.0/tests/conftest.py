"""Shared fixtures for pyvdrift tests."""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest


@pytest.fixture
def make_pip_project(tmp_path: Path):
    """Create a minimal pip project with requirements.txt."""

    def _make(
        *,
        deps: str = "requests>=2.28\nflask==3.0.0\n",
        dev_deps: str | None = None,
    ) -> Path:
        project = tmp_path / "pip-project"
        project.mkdir(exist_ok=True)
        (project / "requirements.txt").write_text(deps)
        if dev_deps:
            (project / "requirements-dev.txt").write_text(dev_deps)
        return project

    return _make


@pytest.fixture
def make_uv_project(tmp_path: Path):
    """Create a minimal uv project with pyproject.toml and uv.lock."""

    def _make(
        *,
        deps: list[str] | None = None,
        lock_packages: list[tuple[str, str]] | None = None,
    ) -> Path:
        if deps is None:
            deps = ["requests>=2.28", "flask==3.0.0"]
        if lock_packages is None:
            lock_packages = [("requests", "2.31.0"), ("flask", "3.0.0")]

        project = tmp_path / "uv-project"
        project.mkdir(exist_ok=True)

        deps_str = ", ".join(f'"{d}"' for d in deps)
        (project / "pyproject.toml").write_text(
            textwrap.dedent(f"""\
            [project]
            name = "uv-project"
            version = "0.1.0"
            dependencies = [{deps_str}]

            [tool.uv]
            """)
        )

        lock_entries = ""
        for name, version in lock_packages:
            lock_entries += textwrap.dedent(f"""\
            [[package]]
            name = "{name}"
            version = "{version}"

            """)
        (project / "uv.lock").write_text(lock_entries)
        return project

    return _make


@pytest.fixture
def make_poetry_project(tmp_path: Path):
    """Create a minimal poetry project with pyproject.toml and poetry.lock."""

    def _make(
        *,
        deps: dict[str, str] | None = None,
        dev_deps: dict[str, str] | None = None,
        group_deps: dict[str, dict[str, str]] | None = None,
    ) -> Path:
        if deps is None:
            deps = {"python": "^3.10", "requests": "^2.28"}
        if dev_deps is None:
            dev_deps = {}

        project = tmp_path / "poetry-project"
        project.mkdir(exist_ok=True)

        deps_lines = "\n".join(f'{k} = "{v}"' for k, v in deps.items())
        dev_deps_lines = "\n".join(f'{k} = "{v}"' for k, v in dev_deps.items())

        groups_toml = ""
        if group_deps:
            for group_name, gdeps in group_deps.items():
                gdeps_lines = "\n".join(f'{k} = "{v}"' for k, v in gdeps.items())
                groups_toml += textwrap.dedent(f"""\
                [tool.poetry.group.{group_name}.dependencies]
                {gdeps_lines}

                """)

        (project / "pyproject.toml").write_text(
            textwrap.dedent(f"""\
            [tool.poetry]
            name = "poetry-project"
            version = "0.1.0"

            [tool.poetry.dependencies]
            {deps_lines}

            [tool.poetry.dev-dependencies]
            {dev_deps_lines}

            """) + groups_toml
        )

        # Minimal poetry.lock
        (project / "poetry.lock").write_text(
            textwrap.dedent("""\
            [[package]]
            name = "requests"
            version = "2.31.0"
            description = "HTTP library"

            [metadata]
            lock-version = "2.0"
            """)
        )
        return project

    return _make


@pytest.fixture
def make_pipenv_project(tmp_path: Path):
    """Create a minimal Pipenv project with Pipfile and Pipfile.lock."""

    def _make(
        *,
        packages: dict[str, str] | None = None,
        dev_packages: dict[str, str] | None = None,
    ) -> Path:
        if packages is None:
            packages = {"requests": ">=2.28"}
        if dev_packages is None:
            dev_packages = {"pytest": "*"}

        project = tmp_path / "pipenv-project"
        project.mkdir(exist_ok=True)

        pkg_lines = "\n".join(f'{k} = "{v}"' for k, v in packages.items())
        dev_lines = "\n".join(f'{k} = "{v}"' for k, v in dev_packages.items())

        (project / "Pipfile").write_text(
            textwrap.dedent(f"""\
            [packages]
            {pkg_lines}

            [dev-packages]
            {dev_lines}

            [requires]
            python_version = "3.12"
            """)
        )

        (project / "Pipfile.lock").write_text(
            json.dumps(
                {
                    "_meta": {"requires": {"python_version": "3.12"}},
                    "default": {
                        "requests": {
                            "version": "==2.31.0",
                        }
                    },
                    "develop": {
                        "pytest": {
                            "version": "==8.0.0",
                        }
                    },
                }
            )
        )
        return project

    return _make


@pytest.fixture
def make_conda_project(tmp_path: Path):
    """Create a minimal conda project with environment.yml."""

    def _make(
        *,
        name: str = "myenv",
        deps: list[str] | None = None,
    ) -> Path:
        if deps is None:
            deps = ["python=3.12", "numpy>=1.24", "pandas"]

        project = tmp_path / "conda-project"
        project.mkdir(exist_ok=True)

        deps_lines = "\n".join(f"  - {d}" for d in deps)
        content = f"name: {name}\ndependencies:\n{deps_lines}\n"
        (project / "environment.yml").write_text(content
        )
        return project

    return _make


@pytest.fixture
def make_fake_venv(tmp_path: Path):
    """Create a fake .venv with pyvenv.cfg and site-packages."""

    def _make(project_path: Path, python_version: str = "3.12.1") -> Path:
        venv = project_path / ".venv"
        venv.mkdir(exist_ok=True)
        (venv / "pyvenv.cfg").write_text(
            f"home = /usr/bin\nversion = {python_version}\n"
        )
        site_packages = venv / "lib" / f"python{'.'.join(python_version.split('.')[:2])}" / "site-packages"
        site_packages.mkdir(parents=True, exist_ok=True)
        return venv

    return _make


@pytest.fixture
def make_installed_pkg():
    """Create a .dist-info directory with METADATA in the given site-packages."""

    def _make(venv_path: Path, name: str, version: str) -> Path:
        # Find site-packages
        lib_dir = venv_path / "lib"
        if lib_dir.exists():
            for pydir in lib_dir.iterdir():
                sp = pydir / "site-packages"
                if sp.exists():
                    dist_info = sp / f"{name}-{version}.dist-info"
                    dist_info.mkdir(parents=True, exist_ok=True)
                    (dist_info / "METADATA").write_text(
                        f"Metadata-Version: 2.1\nName: {name}\nVersion: {version}\n"
                    )
                    return dist_info
        raise FileNotFoundError(f"No site-packages found in {venv_path}")

    return _make
