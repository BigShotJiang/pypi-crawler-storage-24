"""Tests for the pyproject.toml parser."""

from __future__ import annotations

import textwrap
from pathlib import Path

from pyvdrift.parsers.pyproject import PyprojectParser


def test_pep621_dependencies(tmp_path: Path):
    """Parse [project.dependencies] section."""
    pp = tmp_path / "pyproject.toml"
    pp.write_text(
        textwrap.dedent("""\
        [project]
        name = "test"
        version = "0.1.0"
        dependencies = ["requests>=2.28", "flask==3.0.0"]
        """)
    )
    deps = PyprojectParser.parse(pp)
    assert len(deps) == 2
    names = {d.name for d in deps}
    assert names == {"requests", "flask"}


def test_pep621_optional_dependencies(tmp_path: Path):
    """Parse [project.optional-dependencies] sections."""
    pp = tmp_path / "pyproject.toml"
    pp.write_text(
        textwrap.dedent("""\
        [project]
        name = "test"
        version = "0.1.0"
        dependencies = ["requests"]

        [project.optional-dependencies]
        dev = ["pytest", "ruff"]
        docs = ["sphinx"]
        """)
    )
    deps = PyprojectParser.parse(pp)
    assert len(deps) == 4
    dev_deps = [d for d in deps if d.is_dev]
    assert len(dev_deps) == 3  # pytest, ruff, sphinx (docs is dev too)


def test_poetry_dependencies(tmp_path: Path):
    """Parse [tool.poetry.dependencies] section."""
    pp = tmp_path / "pyproject.toml"
    pp.write_text(
        textwrap.dedent("""\
        [tool.poetry]
        name = "test"
        version = "0.1.0"

        [tool.poetry.dependencies]
        python = "^3.10"
        requests = "^2.28"
        flask = "3.0.0"
        """)
    )
    deps = PyprojectParser.parse(pp)
    names = {d.name for d in deps}
    assert "requests" in names
    assert "flask" in names
    assert "python" not in names  # python is skipped


def test_poetry_groups(tmp_path: Path):
    """Parse [tool.poetry.group.*.dependencies] sections."""
    pp = tmp_path / "pyproject.toml"
    pp.write_text(
        textwrap.dedent("""\
        [tool.poetry]
        name = "test"

        [tool.poetry.dependencies]
        requests = "^2.28"

        [tool.poetry.group.dev.dependencies]
        pytest = "^8.0"

        [tool.poetry.group.test.dependencies]
        coverage = "^7.0"
        """)
    )
    deps = PyprojectParser.parse(pp)
    assert len(deps) == 3
    dev_deps = [d for d in deps if d.is_dev]
    assert len(dev_deps) == 2


def test_uv_dev_dependencies(tmp_path: Path):
    """Parse [tool.uv.dev-dependencies] section."""
    pp = tmp_path / "pyproject.toml"
    pp.write_text(
        textwrap.dedent("""\
        [project]
        name = "test"
        version = "0.1.0"
        dependencies = ["requests"]

        [tool.uv]
        dev-dependencies = ["pytest>=8", "ruff"]
        """)
    )
    deps = PyprojectParser.parse(pp)
    assert len(deps) == 3
    dev_deps = [d for d in deps if d.is_dev]
    assert len(dev_deps) == 2


def test_nonexistent_file(tmp_path: Path):
    """Missing file returns empty list."""
    deps = PyprojectParser.parse(tmp_path / "nope.toml")
    assert deps == []
