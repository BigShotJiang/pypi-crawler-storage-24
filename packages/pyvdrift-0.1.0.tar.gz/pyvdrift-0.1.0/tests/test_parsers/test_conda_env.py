"""Tests for the conda environment.yml parser."""

from __future__ import annotations

import textwrap
from pathlib import Path

from pyvdrift.parsers.conda_env import CondaEnvParser


def test_basic_conda_env(tmp_path: Path):
    """Parse basic dependencies list."""
    env = tmp_path / "environment.yml"
    env.write_text(
        textwrap.dedent("""\
        name: myenv
        dependencies:
          - python=3.12
          - numpy>=1.24
          - pandas
        """)
    )
    deps = CondaEnvParser.parse(env)
    assert len(deps) == 3
    python_dep = next(d for d in deps if d.name == "python")
    assert python_dep.specifier == "==3.12"
    numpy_dep = next(d for d in deps if d.name == "numpy")
    assert numpy_dep.specifier == ">=1.24"
    pandas_dep = next(d for d in deps if d.name == "pandas")
    assert pandas_dep.specifier == ""


def test_pip_subdeps(tmp_path: Path):
    """Parse pip sub-dependencies."""
    env = tmp_path / "environment.yml"
    env.write_text(
        textwrap.dedent("""\
        name: myenv
        dependencies:
          - python
          - pip:
            - requests>=2.28
            - flask
        """)
    )
    deps = CondaEnvParser.parse(env)
    names = {d.name for d in deps}
    assert "python" in names
    assert "requests" in names
    assert "flask" in names


def test_nonexistent_file(tmp_path: Path):
    deps = CondaEnvParser.parse(tmp_path / "nope.yml")
    assert deps == []
