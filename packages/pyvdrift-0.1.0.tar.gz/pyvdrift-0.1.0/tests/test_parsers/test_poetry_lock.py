"""Tests for the poetry.lock parser."""

from __future__ import annotations

import textwrap
from pathlib import Path

from pyvdrift.parsers.poetry_lock import parse_poetry_lock


def test_parses_poetry_lock(tmp_path: Path):
    """name/version blocks parsed correctly."""
    lock = tmp_path / "poetry.lock"
    lock.write_text(
        textwrap.dedent("""\
        [[package]]
        name = "requests"
        version = "2.31.0"
        description = "HTTP library"

        [[package]]
        name = "flask"
        version = "3.0.0"
        description = "Web framework"

        [metadata]
        lock-version = "2.0"
        """)
    )
    pkgs = parse_poetry_lock(lock)
    assert len(pkgs) == 2
    names = {p.name for p in pkgs}
    assert names == {"requests", "flask"}
    req = next(p for p in pkgs if p.name == "requests")
    assert req.version == "2.31.0"


def test_empty_lock(tmp_path: Path):
    """Empty poetry.lock returns empty list."""
    lock = tmp_path / "poetry.lock"
    lock.write_text("")
    pkgs = parse_poetry_lock(lock)
    assert pkgs == []


def test_nonexistent_lock(tmp_path: Path):
    """Missing poetry.lock returns empty list."""
    pkgs = parse_poetry_lock(tmp_path / "poetry.lock")
    assert pkgs == []
