"""Tests for the uv.lock parser."""

from __future__ import annotations

import textwrap
from pathlib import Path

from pyvdrift.parsers.uv_lock import parse_uv_lock


def test_parses_uv_lock_packages(tmp_path: Path):
    """[[package]] blocks parsed to InstalledPkg list."""
    lock = tmp_path / "uv.lock"
    lock.write_text(
        textwrap.dedent("""\
        [[package]]
        name = "requests"
        version = "2.31.0"

        [[package]]
        name = "flask"
        version = "3.0.0"

        [[package]]
        name = "click"
        version = "8.1.7"
        """)
    )
    pkgs = parse_uv_lock(lock)
    assert len(pkgs) == 3
    names = {p.name for p in pkgs}
    assert names == {"requests", "flask", "click"}
    req = next(p for p in pkgs if p.name == "requests")
    assert req.version == "2.31.0"


def test_empty_lock(tmp_path: Path):
    """Empty uv.lock returns empty list."""
    lock = tmp_path / "uv.lock"
    lock.write_text("")
    pkgs = parse_uv_lock(lock)
    assert pkgs == []


def test_nonexistent_lock(tmp_path: Path):
    """Missing uv.lock returns empty list."""
    pkgs = parse_uv_lock(tmp_path / "uv.lock")
    assert pkgs == []
