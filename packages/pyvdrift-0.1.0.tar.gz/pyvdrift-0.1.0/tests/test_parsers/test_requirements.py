"""Tests for the requirements.txt parser."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.parsers.requirements import RequirementsParser


def test_basic_requirements(tmp_path: Path):
    """Parse simple requirements with version specifiers."""
    req = tmp_path / "requirements.txt"
    req.write_text("requests>=2.28\nflask==3.0.0\nclick\n")
    deps = RequirementsParser.parse(req)
    assert len(deps) == 3
    names = {d.name for d in deps}
    assert names == {"requests", "flask", "click"}
    flask_dep = next(d for d in deps if d.name == "flask")
    assert flask_dep.specifier == "==3.0.0"


def test_skips_comments_and_blanks(tmp_path: Path):
    """Comments and blank lines are ignored."""
    req = tmp_path / "requirements.txt"
    req.write_text("# this is a comment\n\nrequests\n  # indented comment\n")
    deps = RequirementsParser.parse(req)
    assert len(deps) == 1


def test_skips_options(tmp_path: Path):
    """--index-url and other options are skipped."""
    req = tmp_path / "requirements.txt"
    req.write_text("--index-url https://pypi.org/simple\nrequests\n")
    deps = RequirementsParser.parse(req)
    assert len(deps) == 1
    assert deps[0].name == "requests"


def test_skips_editable_and_url_deps(tmp_path: Path):
    """-e installs and URL deps are skipped."""
    req = tmp_path / "requirements.txt"
    req.write_text("-e .\ngit+https://github.com/user/repo.git\nrequests\n")
    deps = RequirementsParser.parse(req)
    assert len(deps) == 1


def test_follows_r_includes(tmp_path: Path):
    """-r base.txt includes are followed."""
    base = tmp_path / "base.txt"
    base.write_text("requests\n")
    req = tmp_path / "requirements.txt"
    req.write_text("-r base.txt\nflask\n")
    deps = RequirementsParser.parse(req)
    names = {d.name for d in deps}
    assert names == {"requests", "flask"}


def test_handles_inline_comments(tmp_path: Path):
    """Inline comments are stripped."""
    req = tmp_path / "requirements.txt"
    req.write_text("requests>=2.0  # HTTP library\n")
    deps = RequirementsParser.parse(req)
    assert deps[0].name == "requests"
    assert deps[0].specifier == ">=2.0"


def test_handles_extras(tmp_path: Path):
    """Extras are parsed correctly."""
    req = tmp_path / "requirements.txt"
    req.write_text("requests[security]>=2.0\n")
    deps = RequirementsParser.parse(req)
    assert deps[0].extras == ["security"]


def test_handles_environment_markers(tmp_path: Path):
    """Environment markers are stripped from the specifier."""
    req = tmp_path / "requirements.txt"
    req.write_text('pywin32>=300; sys_platform == "win32"\nrequests\n')
    deps = RequirementsParser.parse(req)
    assert len(deps) == 2


def test_dev_file_detected(tmp_path: Path):
    """Files with 'dev' in name are marked as dev deps."""
    req = tmp_path / "requirements-dev.txt"
    req.write_text("pytest\n")
    deps = RequirementsParser.parse(req)
    assert deps[0].is_dev is True


def test_nonexistent_file(tmp_path: Path):
    """Missing file returns empty list."""
    deps = RequirementsParser.parse(tmp_path / "nope.txt")
    assert deps == []


def test_circular_includes(tmp_path: Path):
    """Circular -r includes don't cause infinite recursion."""
    a = tmp_path / "a.txt"
    b = tmp_path / "b.txt"
    a.write_text("-r b.txt\nrequests\n")
    b.write_text("-r a.txt\nflask\n")
    deps = RequirementsParser.parse(a)
    names = {d.name for d in deps}
    assert names == {"requests", "flask"}
