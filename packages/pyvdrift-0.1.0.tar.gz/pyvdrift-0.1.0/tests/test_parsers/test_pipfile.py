"""Tests for the Pipfile parser."""

from __future__ import annotations

import textwrap
from pathlib import Path

from pyvdrift.parsers.pipfile import PipfileParser


def test_basic_pipfile(tmp_path: Path):
    """Parse [packages] and [dev-packages] sections."""
    pf = tmp_path / "Pipfile"
    pf.write_text(
        textwrap.dedent("""\
        [packages]
        requests = ">=2.28"
        flask = "==3.0.0"

        [dev-packages]
        pytest = "*"
        """)
    )
    deps = PipfileParser.parse(pf)
    assert len(deps) == 3
    names = {d.name for d in deps}
    assert names == {"requests", "flask", "pytest"}

    pytest_dep = next(d for d in deps if d.name == "pytest")
    assert pytest_dep.is_dev is True
    assert pytest_dep.specifier == ""  # "*" becomes ""

    flask_dep = next(d for d in deps if d.name == "flask")
    assert flask_dep.specifier == "==3.0.0"


def test_nonexistent_pipfile(tmp_path: Path):
    """Missing Pipfile returns empty list."""
    deps = PipfileParser.parse(tmp_path / "Pipfile")
    assert deps == []
