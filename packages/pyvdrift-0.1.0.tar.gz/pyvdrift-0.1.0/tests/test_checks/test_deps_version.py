"""Tests for the deps_version check."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.checks.deps_version import DepsVersionCheck
from pyvdrift.core.project import Project, Toolchain


def test_versions_match(tmp_path: Path, make_fake_venv, make_installed_pkg):
    """Installed versions match → status ok."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests>=2.28\n")

    venv = make_fake_venv(project_dir)
    make_installed_pkg(venv, "requests", "2.31.0")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=venv,
    )
    result = DepsVersionCheck.run(project)
    assert result.status == "ok"


def test_version_mismatch(tmp_path: Path, make_fake_venv, make_installed_pkg):
    """Version mismatch → status warn."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests>=2.28\n")

    venv = make_fake_venv(project_dir)
    make_installed_pkg(venv, "requests", "1.0.0")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=venv,
    )
    result = DepsVersionCheck.run(project)
    assert result.status == "warn"
    assert "mismatch" in result.message
