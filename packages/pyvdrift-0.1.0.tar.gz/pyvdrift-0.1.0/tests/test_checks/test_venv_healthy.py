"""Tests for the venv_healthy check."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.checks.venv_exists import VenvExistsCheck
from pyvdrift.core.project import Project, Toolchain


def test_venv_exists_ok(tmp_path: Path, make_fake_venv):
    """Venv present → status ok."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    venv = make_fake_venv(project_dir)

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=venv,
    )
    result = VenvExistsCheck.run(project)
    assert result.status == "ok"
    assert ".venv" in result.message


def test_venv_missing_error(tmp_path: Path):
    """No venv → status error with fix hint."""
    project = Project(
        path=tmp_path,
        name="proj",
        toolchains=[Toolchain.UV],
        venv_path=None,
    )
    result = VenvExistsCheck.run(project)
    assert result.status == "error"
    assert result.fix_hint is not None
