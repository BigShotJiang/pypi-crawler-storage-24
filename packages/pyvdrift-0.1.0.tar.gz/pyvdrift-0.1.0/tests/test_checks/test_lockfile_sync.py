"""Tests for the lockfile_sync check."""

from __future__ import annotations

import time
from pathlib import Path

from pyvdrift.checks.lockfile_sync import LockfileSyncCheck
from pyvdrift.core.project import Project, Toolchain


def test_uv_lock_stale(tmp_path: Path):
    """pyproject.toml newer than uv.lock → warn."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()

    lock = project_dir / "uv.lock"
    lock.write_text("")

    # Ensure pyproject.toml has a strictly newer mtime
    time.sleep(0.05)
    pyproject = project_dir / "pyproject.toml"
    pyproject.write_text('[project]\nname = "test"\n\n[tool.uv]\n')

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.UV],
    )
    result = LockfileSyncCheck.run(project)
    assert result.status == "warn"
    assert "stale" in result.message
    assert result.fix_hint == "uv lock"


def test_uv_lock_up_to_date(tmp_path: Path):
    """uv.lock newer than pyproject.toml → ok."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()

    pyproject = project_dir / "pyproject.toml"
    pyproject.write_text('[project]\nname = "test"\n\n[tool.uv]\n')

    time.sleep(0.05)
    lock = project_dir / "uv.lock"
    lock.write_text("")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.UV],
    )
    result = LockfileSyncCheck.run(project)
    assert result.status == "ok"


def test_pipfile_lock_stale(tmp_path: Path):
    """Pipfile newer than Pipfile.lock → warn."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()

    lock = project_dir / "Pipfile.lock"
    lock.write_text("{}")

    time.sleep(0.05)
    pipfile = project_dir / "Pipfile"
    pipfile.write_text("[packages]\n")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIPENV],
    )
    result = LockfileSyncCheck.run(project)
    assert result.status == "warn"
    assert "stale" in result.message


def test_pip_no_pinning(tmp_path: Path):
    """requirements.txt with no == pins → warn."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests\nflask>=3.0\n")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
    )
    result = LockfileSyncCheck.run(project)
    assert result.status == "warn"
    assert "no pinned versions" in result.message
