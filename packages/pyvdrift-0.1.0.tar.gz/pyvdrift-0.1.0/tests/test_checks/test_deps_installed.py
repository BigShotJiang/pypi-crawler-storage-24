"""Tests for the deps_installed check."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.checks.deps_installed import DepsInstalledCheck
from pyvdrift.core.project import Project, Toolchain


def test_all_deps_installed(tmp_path: Path, make_fake_venv, make_installed_pkg):
    """All deps installed → status ok."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests>=2.28\n")

    venv = make_fake_venv(project_dir)
    make_installed_pkg(venv, "requests", "2.31.0")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=venv,
    )
    result = DepsInstalledCheck.run(project)
    assert result.status == "ok"


def test_missing_deps_error(tmp_path: Path, make_fake_venv):
    """Missing deps → status error with fix hint."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests>=2.28\nflask\n")

    venv = make_fake_venv(project_dir)

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=venv,
    )
    result = DepsInstalledCheck.run(project)
    assert result.status == "error"
    assert "2" in result.message
    assert result.fix_hint is not None
