"""Tests for the pip tool module."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.tools.pip import PipTool


def test_detects_pip_project(make_pip_project):
    """requirements.txt present → pip detected."""
    project = make_pip_project()
    assert PipTool.detect(project) is True


def test_does_not_detect_empty_dir(tmp_path: Path):
    """Empty directory → pip not detected."""
    assert PipTool.detect(tmp_path) is False


def test_resolves_pip_venv(make_pip_project, make_fake_venv):
    """venv with pyvenv.cfg present → resolved."""
    project = make_pip_project()
    make_fake_venv(project)
    venv = PipTool.resolve_venv(project)
    assert venv is not None
    assert venv.name == ".venv"


def test_no_venv_returns_none(make_pip_project):
    """No venv directory → returns None."""
    project = make_pip_project()
    assert PipTool.resolve_venv(project) is None


def test_declared_deps_basic(make_pip_project):
    """Parse requirements.txt with basic deps."""
    project = make_pip_project()
    deps = PipTool.declared_deps(project)
    names = {d.name.lower() for d in deps}
    assert "requests" in names
    assert "flask" in names


def test_declared_deps_with_dev(make_pip_project):
    """Parse requirements-dev.txt as dev deps."""
    project = make_pip_project(dev_deps="pytest>=7\nruff\n")
    deps = PipTool.declared_deps(project)
    dev_deps = [d for d in deps if d.is_dev]
    assert len(dev_deps) >= 1
    assert any(d.name.lower() == "pytest" for d in dev_deps)


def test_pip_fix_hint(tmp_path: Path):
    """fix_hint returns pip install command."""
    assert "pip install" in PipTool.fix_hint(tmp_path)


def test_detects_requirements_dir(tmp_path: Path):
    """requirements/ directory with .txt files → detected."""
    req_dir = tmp_path / "requirements"
    req_dir.mkdir()
    (req_dir / "base.txt").write_text("requests\n")
    assert PipTool.detect(tmp_path) is True
