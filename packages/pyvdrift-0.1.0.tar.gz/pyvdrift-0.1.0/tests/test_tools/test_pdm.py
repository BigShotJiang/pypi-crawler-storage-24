"""Tests for the PDM tool module."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.tools.pdm import PdmTool


def test_detects_pdm_project_via_lock(tmp_path: Path):
    """pdm.lock present → detected."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "pdm.lock").write_text("")
    assert PdmTool.detect(project) is True


def test_detects_pdm_via_toml(tmp_path: Path):
    """[tool.pdm] in pyproject.toml → detected."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "pyproject.toml").write_text(
        '[project]\nname = "test"\n\n[tool.pdm]\n'
    )
    assert PdmTool.detect(project) is True


def test_does_not_detect_empty(tmp_path: Path):
    assert PdmTool.detect(tmp_path) is False


def test_pdm_fix_hint(tmp_path: Path):
    assert PdmTool.fix_hint(tmp_path) == "pdm install"


def test_pdm_venv_in_project(tmp_path: Path):
    project = tmp_path / "proj"
    project.mkdir()
    venv = project / ".venv"
    venv.mkdir()
    (venv / "pyvenv.cfg").write_text("version = 3.12\n")
    assert PdmTool.resolve_venv(project) == venv
