"""Tests for the conda tool module."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.tools.conda import CondaTool


def test_detects_conda_project(make_conda_project):
    """environment.yml present → CONDA detected."""
    project = make_conda_project()
    assert CondaTool.detect(project) is True


def test_detects_conda_yaml_variant(tmp_path: Path):
    """environment.yaml also detected."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "environment.yaml").write_text("name: test\ndependencies:\n  - python\n")
    assert CondaTool.detect(project) is True


def test_does_not_detect_empty(tmp_path: Path):
    assert CondaTool.detect(tmp_path) is False


def test_parses_conda_deps(make_conda_project):
    """dependencies list parsed correctly."""
    project = make_conda_project()
    deps = CondaTool.declared_deps(project)
    names = {d.name for d in deps}
    assert "numpy" in names
    assert "pandas" in names
    assert "python" in names


def test_conda_graceful_no_binary(make_conda_project):
    """conda not in PATH → warn, not error. resolve_venv returns None."""
    project = make_conda_project()
    # This test works because conda is not installed in CI/test environments
    venv = CondaTool.resolve_venv(project)
    # Should return None gracefully, not raise
    assert venv is None or isinstance(venv, Path)


def test_conda_fix_hint(make_conda_project):
    project = make_conda_project()
    hint = CondaTool.fix_hint(project)
    assert "conda env update" in hint
