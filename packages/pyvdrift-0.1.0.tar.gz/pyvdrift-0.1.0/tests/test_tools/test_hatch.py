"""Tests for the Hatch tool module."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.tools.hatch import HatchTool


def test_detects_hatch_project(tmp_path: Path):
    """[tool.hatch] in pyproject.toml → detected."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "pyproject.toml").write_text(
        '[project]\nname = "test"\n\n[tool.hatch]\n'
    )
    assert HatchTool.detect(project) is True


def test_does_not_detect_empty(tmp_path: Path):
    assert HatchTool.detect(tmp_path) is False


def test_hatch_fix_hint(tmp_path: Path):
    assert HatchTool.fix_hint(tmp_path) == "hatch env create"


def test_hatch_no_lockfile(tmp_path: Path):
    assert HatchTool.lockfile_path(tmp_path) is None


def test_hatch_in_project_venv(tmp_path: Path):
    project = tmp_path / "proj"
    project.mkdir()
    venv = project / ".venv"
    venv.mkdir()
    (venv / "pyvenv.cfg").write_text("version = 3.12\n")
    assert HatchTool.resolve_venv(project) == venv
