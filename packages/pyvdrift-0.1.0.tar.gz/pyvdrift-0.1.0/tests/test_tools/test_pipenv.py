"""Tests for the pipenv tool module."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.tools.pipenv import PipenvTool


def test_detects_pipenv_project(make_pipenv_project):
    """Pipfile present → PIPENV detected."""
    project = make_pipenv_project()
    assert PipenvTool.detect(project) is True


def test_does_not_detect_empty_dir(tmp_path: Path):
    """Empty directory → not detected."""
    assert PipenvTool.detect(tmp_path) is False


def test_parses_pipfile_dev_packages(make_pipenv_project):
    """[dev-packages] parsed with is_dev=True."""
    project = make_pipenv_project()
    deps = PipenvTool.declared_deps(project)
    dev_deps = [d for d in deps if d.is_dev]
    assert len(dev_deps) >= 1
    assert any(d.name == "pytest" for d in dev_deps)


def test_parses_pipfile_packages(make_pipenv_project):
    """[packages] parsed with is_dev=False."""
    project = make_pipenv_project()
    deps = PipenvTool.declared_deps(project)
    non_dev = [d for d in deps if not d.is_dev]
    assert any(d.name == "requests" for d in non_dev)


def test_pipenv_fix_hint(tmp_path: Path):
    """fix_hint returns 'pipenv install'."""
    assert PipenvTool.fix_hint(tmp_path) == "pipenv install"


def test_pipenv_lockfile_path(make_pipenv_project):
    """lockfile_path returns Pipfile.lock when present."""
    project = make_pipenv_project()
    lock = PipenvTool.lockfile_path(project)
    assert lock is not None
    assert lock.name == "Pipfile.lock"


def test_pipenv_in_project_venv(make_pipenv_project, make_fake_venv):
    """.venv in project root is found."""
    project = make_pipenv_project()
    make_fake_venv(project)
    venv = PipenvTool.resolve_venv(project)
    assert venv is not None
    assert venv.name == ".venv"
