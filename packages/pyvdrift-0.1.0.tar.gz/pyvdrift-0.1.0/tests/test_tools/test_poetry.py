"""Tests for the poetry tool module."""

from __future__ import annotations

import textwrap
from pathlib import Path

from pyvdrift.tools.poetry import PoetryTool


def test_detects_poetry_project(make_poetry_project):
    """[tool.poetry] in pyproject.toml → POETRY detected."""
    project = make_poetry_project()
    assert PoetryTool.detect(project) is True


def test_detects_poetry_via_lockfile(tmp_path: Path):
    """poetry.lock present → detected."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "poetry.lock").write_text("[[package]]\n")
    assert PoetryTool.detect(project) is True


def test_does_not_detect_plain_pyproject(tmp_path: Path):
    """pyproject.toml without [tool.poetry] → not detected."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "pyproject.toml").write_text('[project]\nname = "test"\n')
    assert PoetryTool.detect(project) is False


def test_parses_poetry_groups(tmp_path: Path):
    """[tool.poetry.group.dev.dependencies] parsed correctly."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "pyproject.toml").write_text(
        textwrap.dedent("""\
        [tool.poetry]
        name = "test"

        [tool.poetry.dependencies]
        requests = "^2.28"

        [tool.poetry.group.dev.dependencies]
        pytest = "^8.0"
        ruff = "^0.3"
        """)
    )
    deps = PoetryTool.declared_deps(project)
    assert len(deps) == 3
    dev_deps = [d for d in deps if d.is_dev]
    assert len(dev_deps) == 2
    dev_names = {d.name for d in dev_deps}
    assert dev_names == {"pytest", "ruff"}


def test_poetry_in_project_venv(make_poetry_project, make_fake_venv):
    """.venv/ in project root takes priority over cache."""
    project = make_poetry_project()
    make_fake_venv(project)
    venv = PoetryTool.resolve_venv(project)
    assert venv is not None
    assert venv.name == ".venv"


def test_poetry_fix_hint(tmp_path: Path):
    """fix_hint returns 'poetry install'."""
    assert PoetryTool.fix_hint(tmp_path) == "poetry install"


def test_poetry_lockfile_path(make_poetry_project):
    """lockfile_path returns poetry.lock when present."""
    project = make_poetry_project()
    lock = PoetryTool.lockfile_path(project)
    assert lock is not None
    assert lock.name == "poetry.lock"
