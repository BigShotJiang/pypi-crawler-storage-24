"""Tests for the uv tool module."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.tools.uv import UvTool


def test_detects_uv_project(make_uv_project):
    """uv.lock present → toolchain includes UV."""
    project = make_uv_project()
    assert UvTool.detect(project) is True


def test_detects_uv_via_toml(tmp_path: Path):
    """[tool.uv] in pyproject.toml without uv.lock → detected."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "pyproject.toml").write_text(
        '[project]\nname = "test"\n\n[tool.uv]\n'
    )
    assert UvTool.detect(project) is True


def test_does_not_detect_plain_pyproject(tmp_path: Path):
    """pyproject.toml without [tool.uv] → not detected."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "pyproject.toml").write_text('[project]\nname = "test"\n')
    assert UvTool.detect(project) is False


def test_resolves_uv_venv(make_uv_project, make_fake_venv):
    """.venv/ present → venv_path resolved."""
    project = make_uv_project()
    make_fake_venv(project)
    venv = UvTool.resolve_venv(project)
    assert venv is not None
    assert venv.name == ".venv"


def test_no_venv_returns_none(make_uv_project):
    """No .venv → returns None."""
    project = make_uv_project()
    assert UvTool.resolve_venv(project) is None


def test_uv_declared_deps(make_uv_project):
    """Parse deps from pyproject.toml."""
    project = make_uv_project()
    deps = UvTool.declared_deps(project)
    names = {d.name.lower() for d in deps}
    assert "requests" in names
    assert "flask" in names


def test_uv_fix_hint(tmp_path: Path):
    """fix_hint returns 'uv sync'."""
    assert UvTool.fix_hint(tmp_path) == "uv sync"


def test_uv_lockfile_path(make_uv_project):
    """lockfile_path returns uv.lock when present."""
    project = make_uv_project()
    lock = UvTool.lockfile_path(project)
    assert lock is not None
    assert lock.name == "uv.lock"


def test_uv_python_version_from_file(tmp_path: Path):
    """Read python version from .python-version file."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / ".python-version").write_text("3.12\n")
    assert UvTool.python_version(project) == "3.12"
