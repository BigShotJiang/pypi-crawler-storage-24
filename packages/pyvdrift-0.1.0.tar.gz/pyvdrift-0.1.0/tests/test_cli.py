"""Tests for the CLI commands."""

from __future__ import annotations

from typer.testing import CliRunner

from pyvdrift.cli import app

runner = CliRunner()


def test_help():
    """CLI shows help text."""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "pyvdrift" in result.output


def test_scan_help():
    result = runner.invoke(app, ["scan", "--help"])
    assert result.exit_code == 0
    assert "scan" in result.output.lower()


def test_check_help():
    result = runner.invoke(app, ["check", "--help"])
    assert result.exit_code == 0


def test_doctor_help():
    result = runner.invoke(app, ["doctor", "--help"])
    assert result.exit_code == 0


def test_list_help():
    result = runner.invoke(app, ["list", "--help"])
    assert result.exit_code == 0


def test_clean_help():
    result = runner.invoke(app, ["clean", "--help"])
    assert result.exit_code == 0


def test_watch_help():
    result = runner.invoke(app, ["watch", "--help"])
    assert result.exit_code == 0


def test_scan_empty_dir(tmp_path):
    """Scanning an empty dir reports no projects."""
    result = runner.invoke(app, ["scan", str(tmp_path)])
    assert result.exit_code == 0
    assert "No Python projects found" in result.output


def test_scan_json(tmp_path):
    """--json flag outputs JSON."""
    result = runner.invoke(app, ["scan", str(tmp_path), "--json"])
    assert result.exit_code == 0
    assert result.output.strip() == "[]"


def test_check_nonexistent_project(tmp_path):
    """Checking a dir with no project fails gracefully."""
    result = runner.invoke(app, ["check", str(tmp_path)])
    assert result.exit_code == 1


def test_doctor_nonexistent_project(tmp_path):
    """Doctor on a dir with no project fails gracefully."""
    result = runner.invoke(app, ["doctor", str(tmp_path)])
    assert result.exit_code == 1
