"""Tests for drift detection."""

from __future__ import annotations

import textwrap
from pathlib import Path

from pyvdrift.core.drift import detect_drift
from pyvdrift.core.project import Project, Toolchain


def test_no_drift_when_all_installed(tmp_path: Path, make_fake_venv, make_installed_pkg):
    """declared == installed → all ok."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests>=2.28\nflask==3.0.0\n")

    venv = make_fake_venv(project_dir)
    make_installed_pkg(venv, "requests", "2.31.0")
    make_installed_pkg(venv, "flask", "3.0.0")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=venv,
    )
    result = detect_drift(project)
    assert len(result.missing) == 0
    assert len(result.version_mismatch) == 0
    assert len(result.ok) == 2


def test_detects_missing_package(tmp_path: Path, make_fake_venv):
    """declared but no dist-info → missing."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests>=2.28\nflask==3.0.0\n")

    venv = make_fake_venv(project_dir)

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=venv,
    )
    result = detect_drift(project)
    assert len(result.missing) == 2


def test_detects_version_mismatch(tmp_path: Path, make_fake_venv, make_installed_pkg):
    """installed 1.0, requires >=2.0 → mismatch."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests>=2.0\n")

    venv = make_fake_venv(project_dir)
    make_installed_pkg(venv, "requests", "1.0.0")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=venv,
    )
    result = detect_drift(project)
    assert len(result.version_mismatch) == 1
    dep, pkg = result.version_mismatch[0]
    assert dep.name == "requests"
    assert pkg.version == "1.0.0"


def test_uv_project_full_drift_cycle(tmp_path: Path, make_fake_venv, make_installed_pkg):
    """End-to-end uv project check."""
    project_dir = tmp_path / "uv-proj"
    project_dir.mkdir()
    (project_dir / "pyproject.toml").write_text(
        textwrap.dedent("""\
        [project]
        name = "uv-proj"
        version = "0.1.0"
        dependencies = ["requests>=2.28", "click>=8.0"]

        [tool.uv]
        """)
    )
    (project_dir / "uv.lock").write_text("")

    venv = make_fake_venv(project_dir)
    make_installed_pkg(venv, "requests", "2.31.0")
    # click not installed → should be missing

    project = Project(
        path=project_dir,
        name="uv-proj",
        toolchains=[Toolchain.UV],
        venv_path=venv,
    )
    result = detect_drift(project)
    assert len(result.ok) == 1
    assert result.ok[0].name == "requests"
    assert len(result.missing) == 1
    assert result.missing[0].name == "click"


def test_poetry_project_full_drift_cycle(tmp_path: Path, make_fake_venv, make_installed_pkg):
    """End-to-end poetry project check."""
    project_dir = tmp_path / "poetry-proj"
    project_dir.mkdir()
    (project_dir / "pyproject.toml").write_text(
        textwrap.dedent("""\
        [tool.poetry]
        name = "poetry-proj"
        version = "0.1.0"

        [tool.poetry.dependencies]
        python = "^3.10"
        requests = "^2.28"
        flask = "^3.0"
        """)
    )
    (project_dir / "poetry.lock").write_text("")

    venv = make_fake_venv(project_dir)
    make_installed_pkg(venv, "requests", "2.31.0")
    make_installed_pkg(venv, "flask", "3.0.0")

    project = Project(
        path=project_dir,
        name="poetry-proj",
        toolchains=[Toolchain.POETRY],
        venv_path=venv,
    )
    result = detect_drift(project)
    assert len(result.missing) == 0
    assert len(result.ok) == 2


def test_no_venv_all_missing(tmp_path: Path):
    """Project with no venv → all deps are missing."""
    project_dir = tmp_path / "proj"
    project_dir.mkdir()
    (project_dir / "requirements.txt").write_text("requests\nflask\n")

    project = Project(
        path=project_dir,
        name="proj",
        toolchains=[Toolchain.PIP],
        venv_path=None,
    )
    result = detect_drift(project)
    assert len(result.missing) == 2
