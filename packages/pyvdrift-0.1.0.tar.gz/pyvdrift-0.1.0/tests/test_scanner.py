"""Tests for the filesystem scanner."""

from __future__ import annotations

from pathlib import Path

from pyvdrift.core.project import Toolchain
from pyvdrift.core.scanner import scan_projects


def test_finds_uv_project(tmp_path: Path):
    """uv.lock in dir → found with UV toolchain."""
    proj = tmp_path / "myproj"
    proj.mkdir()
    (proj / "pyproject.toml").write_text('[project]\nname = "test"\n\n[tool.uv]\n')
    (proj / "uv.lock").write_text("")
    projects = scan_projects(tmp_path, max_depth=2)
    assert len(projects) == 1
    assert Toolchain.UV in projects[0].toolchains


def test_finds_poetry_project(tmp_path: Path):
    """poetry.lock → found with POETRY toolchain."""
    proj = tmp_path / "myproj"
    proj.mkdir()
    (proj / "pyproject.toml").write_text('[tool.poetry]\nname = "test"\n')
    (proj / "poetry.lock").write_text("")
    projects = scan_projects(tmp_path, max_depth=2)
    assert len(projects) == 1
    assert Toolchain.POETRY in projects[0].toolchains


def test_finds_conda_project(tmp_path: Path):
    """environment.yml → found with CONDA toolchain."""
    proj = tmp_path / "myproj"
    proj.mkdir()
    (proj / "environment.yml").write_text("name: test\ndependencies:\n  - python\n")
    projects = scan_projects(tmp_path, max_depth=2)
    assert len(projects) == 1
    assert Toolchain.CONDA in projects[0].toolchains


def test_finds_multi_tool_project(tmp_path: Path):
    """pyproject.toml + requirements.txt → multiple toolchains."""
    proj = tmp_path / "myproj"
    proj.mkdir()
    (proj / "pyproject.toml").write_text('[project]\nname = "test"\n\n[tool.uv]\n')
    (proj / "uv.lock").write_text("")
    (proj / "requirements.txt").write_text("requests\n")
    projects = scan_projects(tmp_path, max_depth=2)
    assert len(projects) == 1
    toolchains = projects[0].toolchains
    assert Toolchain.UV in toolchains
    assert Toolchain.PIP in toolchains


def test_ignores_node_modules(tmp_path: Path):
    """Projects inside node_modules are not found."""
    nm = tmp_path / "node_modules" / "some_pkg"
    nm.mkdir(parents=True)
    (nm / "requirements.txt").write_text("requests\n")
    projects = scan_projects(tmp_path, max_depth=5)
    assert len(projects) == 0


def test_ignores_site_packages(tmp_path: Path):
    """Projects inside site-packages are not found."""
    sp = tmp_path / "lib" / "python3.12" / "site-packages" / "mypkg"
    sp.mkdir(parents=True)
    (sp / "requirements.txt").write_text("requests\n")
    projects = scan_projects(tmp_path, max_depth=10)
    assert len(projects) == 0


def test_respects_depth_limit(tmp_path: Path):
    """Projects deeper than max_depth are not found."""
    deep = tmp_path / "a" / "b" / "c" / "d" / "e" / "f"
    deep.mkdir(parents=True)
    (deep / "requirements.txt").write_text("requests\n")
    projects = scan_projects(tmp_path, max_depth=2)
    assert len(projects) == 0

    # But with sufficient depth they are found
    projects = scan_projects(tmp_path, max_depth=10)
    assert len(projects) == 1


def test_empty_dir(tmp_path: Path):
    """Empty directory returns no projects."""
    projects = scan_projects(tmp_path, max_depth=5)
    assert projects == []


def test_pyvdrift_ignore(tmp_path: Path):
    """Directories in .pyvdrift-ignore are skipped."""
    proj = tmp_path / "skip_me"
    proj.mkdir()
    (proj / "requirements.txt").write_text("requests\n")
    (tmp_path / ".pyvdrift-ignore").write_text("skip_me\n")
    projects = scan_projects(tmp_path, max_depth=5)
    assert len(projects) == 0
