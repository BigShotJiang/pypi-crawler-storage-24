import dash
import flask

from plotly_cloud._devtool_publish_rpc import PlotlyCloudPublishRPC
from plotly_cloud._run_sync import run_sync


def install_hook():
    rpc = PlotlyCloudPublishRPC()

    try:
        # The style only works with the position left defined.
        dash.hooks.devtool(  # type: ignore
            "plotly_cloud_publish_component",
            "PlotlyCloudPublishComponent",
            {"id": "_plotly-cloud-publish"},
            position="left",
        )
    except Exception:
        return

    dash.hooks.script(
        [
            {"dev_package_path": "cloud_devtools.js", "namespace": "plotly_cloud", "dev_only": True},
        ]
    )

    dash.hooks.stylesheet(
        [
            {"relative_package_path": "cloud_devtools.css", "namespace": "plotly_cloud"},
        ]
    )

    @dash.hooks.route("_plotly_cloud_publish", methods=["POST"])
    def plotly_cloud_publish_rpc():
        data = flask.request.get_json()
        data = run_sync(rpc.handle_operation(data))
        return flask.jsonify(data)

    @dash.hooks.setup()
    def plotly_cloud_setup(app):
        rpc._app_setup = app


if hasattr(dash.hooks, "devtool"):
    install_hook()
