# Background event loop for async operations
import asyncio
import threading

_loop: asyncio.AbstractEventLoop = None  # type: ignore
_loop_thread: threading.Thread = None  # type: ignore


def _get_event_loop():
    """Get or create a background event loop running in a separate thread."""
    global _loop, _loop_thread

    if _loop is None or _loop.is_closed():
        _loop = asyncio.new_event_loop()

        def run_loop():
            asyncio.set_event_loop(_loop)
            _loop.run_forever()

        _loop_thread = threading.Thread(target=run_loop, daemon=True)
        _loop_thread.start()

    return _loop


def run_sync(coro):
    """Run an async coroutine synchronously using a background event loop.

    This avoids issues with nested event loops and ensures proper task context
    for Python 3.14+ where anyio requires asyncio.current_task() to return a valid task.
    """
    loop = _get_event_loop()
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result()
