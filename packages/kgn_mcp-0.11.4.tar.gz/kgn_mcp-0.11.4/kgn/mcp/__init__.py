"""KGN MCP server package."""
