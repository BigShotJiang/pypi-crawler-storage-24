"""KGN logging package."""
