"""
Epochly API Decorators

Decorators for the Epochly framework API.
"""

import functools
import weakref
from typing import Any, Callable, TypeVar, Union, Optional
from ..core.epochly_core import get_epochly_core, EnhancementLevel

F = TypeVar('F', bound=Callable[..., Any])


def optimize(
    level: Union[EnhancementLevel, int, None] = None,  # P0.26 FIX: None = use system level
    monitor_performance: bool = True,
    **options
) -> Callable[[F], F]:
    """
    Decorator to optimize function execution using Epochly.

    Args:
        level: Enhancement level to apply. If None, uses current system level
               (respects EPOCHLY_LEVEL environment variable).
        monitor_performance: Whether to monitor performance
        **options: Additional optimization options

    Returns:
        Decorated function with Epochly optimizations

    P0.26 FIX (Jan 2026): Changed default from LEVEL_1_THREADING to None.
    Previously, decorator always used Level 1 regardless of EPOCHLY_LEVEL env var.
    Now decorator respects the system-wide level setting when no explicit level given.
    """
    def decorator(func: F) -> F:
        # ══════════════════════════════════════════════════════════════════
        # EP-81 FIX: Fast-path cache for optimized function.
        # After the first call resolves the optimization, subsequent calls
        # bypass optimize_function() entirely via closure variable.
        #
        # For explicit level=0 (MONITOR), the optimized function is always
        # the original — set cache at decoration time (zero overhead).
        # For level=None (dynamic), cache after first call BUT invalidate
        # when the system level changes (v0.4.23 fix — see _cached_level).
        # For Level 2 JIT, cache after trust verification of compiled impl.
        # For other levels, cache after first optimize_function() call.
        # ══════════════════════════════════════════════════════════════════
        _fast_fn = None  # Will be set after first call resolves optimization
        _cached_level = None  # v0.4.23: Track which level _fast_fn was resolved at

        # Pre-compute: if explicit Level 0, cache original function immediately
        if level is not None:
            _check_level = EnhancementLevel(level) if isinstance(level, int) else level
            if _check_level == EnhancementLevel.LEVEL_0_MONITOR:
                _fast_fn = func

        # EP-81 R2 FIX (Finding 3): Monitoring disable is NO LONGER done at
        # decoration time. The old approach disabled ALL sys.monitoring for
        # ALL tool IDs at import time, which broke process-wide monitoring
        # (debuggers, profilers, coverage tools).
        #
        # New approach: monitoring disable is deferred to optimize_function()
        # after JIT compilation succeeds. For Level 0 (non-optimizable),
        # only the auto-profiler's tool ID is disabled (not all monitoring).
        # Level 1/3 monitoring is never touched by the decorator path.

        # EP-81 R2 FIX: Cache core reference at decoration time for cheap
        # disable gate in hot path. If core is not available yet, _core_ref
        # stays None and the gate is skipped (no core = nothing to disable).
        try:
            _core = get_epochly_core()
            _core_ref = weakref.ref(_core) if _core is not None else None
        except Exception:
            _core_ref = None

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal _fast_fn, _cached_level, _core_ref

            # EP-81 R2 FIX: Check global disable BEFORE cache (~10ns).
            # Once _fast_fn is populated, it would bypass the core's
            # enabled check indefinitely. This attribute read on the
            # closure-cached core ref preserves disable() semantics.
            # Thread safety: CPython's GIL makes nonlocal assignment atomic
            # for _fast_fn, _cached_level, and _core_ref. Concurrent first
            # calls may redundantly compute, but last-writer-wins is acceptable
            # -- all writers produce equivalent results. No corruption risk.
            # EP-81 R3: Lazy-resolve core ref; use _is_globally_disabled()
            _cr = _core_ref() if _core_ref is not None else None
            if _cr is None:
                try:
                    _cr = get_epochly_core()
                    _core_ref = weakref.ref(_cr) if _cr is not None else None
                except Exception:
                    return func(*args, **kwargs)
            if _cr._is_globally_disabled():
                return func(*args, **kwargs)

            # EP-81 FAST PATH: ~60ns overhead after first call
            # v0.4.23: For level=None (dynamic), check if system level changed
            # since we cached. If it did, invalidate and re-resolve.
            # For explicit levels (level is not None), skip the level check
            # because the user locked the level and it won't change.
            cached = _fast_fn
            if cached is not None:
                if level is not None or _cached_level == _cr.current_level:
                    return cached(*args, **kwargs)
                # Level changed — invalidate cache and re-resolve below
                _fast_fn = None

            epochly_core = get_epochly_core()

            # P0.26 FIX: Determine effective level
            # If level is None, use the system's current level
            effective_level = level
            if effective_level is None:
                effective_level = epochly_core.current_level
            elif isinstance(effective_level, int):
                effective_level = EnhancementLevel(effective_level)

            # EP-81: Level 2 JIT fast path — check for compiled function
            # After first call, optimize_function sets _epochly_jit_impl.
            # Trust-verify it before caching (EP-90 security).
            if effective_level == EnhancementLevel.LEVEL_2_JIT:
                jit_impl = getattr(func, '_epochly_jit_impl', None)
                if jit_impl is not None:
                    from ..core.epochly_core import _is_jit_trusted
                    if _is_jit_trusted(jit_impl):
                        _fast_fn = jit_impl  # Cache verified impl
                        _cached_level = _cr.current_level  # v0.4.23: track for invalidation
                        return jit_impl(*args, **kwargs)

            # Use Epochly core to optimize function execution
            # v0.4.22: Pass _user_level so optimize_function knows if the user
            # explicitly requested a specific level vs auto-detected
            result = epochly_core.optimize_function(
                func, args, kwargs,
                level=effective_level,  # CRITICAL: Pass effective level
                _user_level=level,  # Original decorator param (None if not specified)
                monitor_performance=monitor_performance,
                **options
            )

            # EP-81: Cache the resolved optimization for fast path.
            # v0.4.23 FIX: Cache for ALL levels, including level=None (auto-detected).
            # Previously required `level is not None`, which meant @optimize (no explicit
            # level) NEVER cached — every call went through optimize_function() (~5-10µs).
            # With 25,000 calls in Freddy's canary, this caused the 7.68x regression.
            # For level=None, _cached_level tracks the level at cache time. If the system
            # level changes (progressive enhancement), the cache is invalidated and the
            # function is re-resolved at the new level (see fast-path check above).
            # Level 2 JIT uses trust-verified _epochly_jit_impl (handled above).
            if _fast_fn is None:
                if effective_level != EnhancementLevel.LEVEL_2_JIT:
                    _resolved = getattr(func, '_epochly_resolved_fn', None)
                    if _resolved is not None:
                        _fast_fn = _resolved
                        _cached_level = epochly_core.current_level

            return result
        
        # Add Epochly metadata
        wrapper._epochly_enhanced = True  # type: ignore
        wrapper._epochly_level = level  # type: ignore
        wrapper._epochly_original = func  # type: ignore
        
        return wrapper  # type: ignore
    
    return decorator


def performance_monitor(func: F) -> F:
    """
    Decorator to add performance monitoring to a function.
    
    Args:
        func: Function to monitor
        
    Returns:
        Decorated function with performance monitoring
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        epochly_core = get_epochly_core()
        
        # Enable monitoring if not already enabled
        epochly_core.enable_monitoring(True)
        
        # Execute function with monitoring
        return epochly_core.optimize_function(
            func, args, kwargs,
            monitor_performance=True
        )
    
    # Add Epochly metadata
    wrapper._epochly_monitored = True  # type: ignore
    wrapper._epochly_original = func  # type: ignore
    
    return wrapper  # type: ignore


def jit_compile(func: F) -> F:
    """
    Decorator to enable JIT compilation for a function.
    
    Args:
        func: Function to JIT compile
        
    Returns:
        Decorated function with JIT compilation
    """
    return optimize(
        level=EnhancementLevel.LEVEL_2_JIT,
        monitor_performance=True
    )(func)


def full_optimize(func: F) -> F:
    """
    Decorator to apply full Epochly optimization to a function.

    CRITICAL FIX (Feb 2026): Changed from hardcoded LEVEL_3_FULL to None.
    Previously, @full_optimize always requested Level 3 regardless of the
    EPOCHLY_LEVEL environment variable. This caused hangs in restricted
    environments where Level 3 ProcessPool creation blocks forever.

    Now uses level=None, which makes optimize() respect the system-wide level
    setting (including EPOCHLY_LEVEL env var cap). When no cap is set, the
    system will still aim for the highest available level.

    Args:
        func: Function to fully optimize

    Returns:
        Decorated function with full optimization
    """
    return optimize(
        level=None,
        monitor_performance=True
    )(func)


def threading_optimize(
    max_workers: Optional[int] = None,
    thread_pool: bool = True
) -> Callable[[F], F]:
    """
    Decorator to optimize function with threading.
    
    Args:
        max_workers: Maximum number of worker threads
        thread_pool: Whether to use thread pool
        
    Returns:
        Decorator function
    """
    def decorator(func: F) -> F:
        return optimize(
            level=EnhancementLevel.LEVEL_1_THREADING,
            monitor_performance=True,
            max_workers=max_workers,
            thread_pool=thread_pool
        )(func)
    
    return decorator
