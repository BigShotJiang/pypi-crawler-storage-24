"""
Lens PLG heartbeat — auto-sends periodic heartbeats to the Lens dashboard
using the API key stored by the PLG activation flow.

The heartbeat is what makes the Lens dashboard show the service as "healthy"
and populates runtime metrics. Without it, a freshly activated account shows
"1 service, 0 healthy, no data."

Credential source: ~/.epochly/lens_credentials.json (written by _store_lens_credentials
in trial_command.py during PLG activation).

Lifecycle:
  - start() spawns a daemon thread that sends heartbeats every 60s
  - stop() signals the thread to exit
  - Auto-stops on atexit

All I/O is guarded — heartbeat failures never affect the application.
"""

import atexit
import json
import logging
import os
import socket
import threading
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_HEARTBEAT_INTERVAL = 60  # seconds
_CREDS_FILENAME = 'lens_credentials.json'


def _load_lens_api_key() -> Optional[str]:
    """Load lens_api_key from ~/.epochly/lens_credentials.json."""
    path = Path.home() / '.epochly' / _CREDS_FILENAME
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        return data.get('lens_api_key')
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


class LensHeartbeat:
    """Periodic heartbeat sender for the Lens PLG dashboard."""

    def __init__(self):
        self._api_key: Optional[str] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._started = False

    def start(self) -> bool:
        """Start the heartbeat thread if credentials are available.

        Returns True if started, False if no credentials or already running.
        """
        if self._started:
            return False

        # Check EPOCHLY_DISABLE and telemetry opt-out
        if os.environ.get('EPOCHLY_DISABLE') == '1':
            return False
        if os.environ.get('EPOCHLY_DISABLE_TELEMETRY', '0') == '1':
            return False

        self._api_key = os.environ.get('EPOCHLY_API_KEY') or _load_lens_api_key()
        if not self._api_key:
            logger.debug("No Lens API key found — heartbeat disabled")
            return False

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._heartbeat_loop,
            name='epochly-lens-heartbeat',
            daemon=True,
        )
        self._thread.start()
        self._started = True
        atexit.register(self.stop)
        logger.debug("Lens heartbeat started (interval=%ds)", _HEARTBEAT_INTERVAL)
        return True

    def stop(self):
        """Signal the heartbeat thread to stop."""
        if not self._started:
            return
        self._stop_event.set()
        self._started = False

    def _heartbeat_loop(self):
        """Send heartbeats until stop is signalled."""
        # Send first heartbeat immediately so the dashboard shows "healthy"
        self._send_heartbeat()

        while not self._stop_event.wait(timeout=_HEARTBEAT_INTERVAL):
            self._send_heartbeat()

    def _send_heartbeat(self):
        """Send a single heartbeat to the Lens API. Never raises."""
        try:
            import requests
            from epochly import __version__

            lens_url = os.environ.get(
                'EPOCHLY_LENS_API_URL', 'https://api.epochly.com'
            ).rstrip('/')

            requests.post(
                f"{lens_url}/v1/plg/heartbeat",
                json={
                    "hostname": socket.gethostname(),
                    "epochly_version": __version__,
                    "pid": os.getpid(),
                    "uptime_s": int(time.monotonic()),
                },
                headers={"Authorization": f"Bearer {self._api_key}"},
                timeout=5,
            )
        except Exception:
            logger.debug("Lens heartbeat failed (non-fatal)", exc_info=True)


# Module-level singleton
_heartbeat: Optional[LensHeartbeat] = None


def start_lens_heartbeat() -> bool:
    """Start the global Lens heartbeat if credentials exist.

    Safe to call multiple times — only starts once.
    """
    global _heartbeat
    if _heartbeat is None:
        _heartbeat = LensHeartbeat()
    return _heartbeat.start()


def stop_lens_heartbeat():
    """Stop the global Lens heartbeat."""
    if _heartbeat is not None:
        _heartbeat.stop()
