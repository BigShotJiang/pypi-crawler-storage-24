"""
RComments - A minimal Flask + PostgreSQL commenting system.

Features:
- Hierarchical threading (nested replies)
- Flexible identity (registered username or "Anonymous")
- Meta data tracking (UTC timestamps, IP logging)
- XSS protection (HTML escaping)
- Rate limiting
- Soft deletion
- Automatic cleanup (30 days or 150 comments limit)
"""

from .config import Config, init_config
from .models import db, Comment
from .routes import init_routes
from .utils import cleanup_old_comments, sanitize_html

__version__ = "0.1.3"
__all__ = [
    "Config",
    "init_config",
    "db",
    "Comment",
    "init_routes",
    "cleanup_old_comments",
    "sanitize_html",
]
