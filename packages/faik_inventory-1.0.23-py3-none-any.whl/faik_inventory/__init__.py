"""faik_inventory package metadata and CLI runtime assets."""

__all__ = ["__version__"]
__version__ = "1.0.23"
