import argparse
import os
import socket
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

import uvicorn


def _parse_bolt_endpoint(raw_uri: str) -> tuple[str, int]:
    uri = (raw_uri or "").strip()
    if not uri:
        raise ValueError("NEO4J_URI is empty")

    parsed = urlparse(uri)
    if parsed.scheme:
        if not parsed.scheme.startswith("bolt"):
            raise ValueError(f"unsupported URI scheme: {parsed.scheme}")
        if not parsed.hostname:
            raise ValueError(f"unsupported Bolt URI: {uri}")
        host = parsed.hostname
        port = parsed.port or 7687
        return host, port

    # Support plain host[:port] values like 127.0.0.1:7687.
    host, colon, port_text = uri.rpartition(":")
    if colon:
        if not host:
            raise ValueError(f"invalid Bolt host/port: {uri}")
        try:
            return host, int(port_text)
        except ValueError as exc:
            raise ValueError(f"invalid Bolt port: {port_text}") from exc
    return uri, 7687


def _is_bolt_port_open(host: str, port: int, timeout: float = 1.0) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(timeout)
        return sock.connect_ex((host, port)) == 0


def _wait_for_managed_neo4j(host: str, port: int, *, timeout_seconds: int = 45, interval_seconds: float = 0.5) -> None:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if _is_bolt_port_open(host, port):
            return
        time.sleep(interval_seconds)

    raise TimeoutError(f"Timed out waiting for Bolt on {host}:{port}.")


def _print_managed_neo4j_setup_and_exit(reason: str) -> None:
    print("Managed Neo4j mode requires a pre-running Neo4j service.", file=sys.stderr)
    print(f"Reason: {reason}", file=sys.stderr)
    print(file=sys.stderr)
    print("Run Neo4j before starting this app:", file=sys.stderr)
    print("- sidecar/deployment in Kubernetes", file=sys.stderr)
    print("  (for example a separate neo4j container or service)", file=sys.stderr)
    print("- direct command on the server", file=sys.stderr)
    print("  neo4j start", file=sys.stderr)
    print("", file=sys.stderr)
    print("Make sure the app can reach the server and the Bolt endpoint is available.", file=sys.stderr)
    print("Set at least:", file=sys.stderr)
    print("  export NEO4J_URI=bolt://<host>:<port>", file=sys.stderr)
    print("  export NEO4J_USER=<neo4j-user>", file=sys.stderr)
    print("  export NEO4J_PASSWORD=<neo4j-password>", file=sys.stderr)
    raise SystemExit(1)


def _setup_external_managed_neo4j() -> tuple[str, int]:
    neo4j_uri = os.getenv("NEO4J_URI", "bolt://127.0.0.1:7687")
    try:
        host, port = _parse_bolt_endpoint(neo4j_uri)
    except ValueError as exc:
        _print_managed_neo4j_setup_and_exit(f"invalid NEO4J_URI {neo4j_uri!r}: {exc}")

    managed_bolt_port = os.getenv("FAIK_INVENTORY_MANAGED_BOLT_PORT")
    if managed_bolt_port:
        try:
            port = int(managed_bolt_port)
        except ValueError as exc:
            _print_managed_neo4j_setup_and_exit(f"invalid FAIK_INVENTORY_MANAGED_BOLT_PORT={managed_bolt_port!r}: {exc}")

    os.environ.setdefault("NEO4J_URI", f"bolt://{host}:{port}")
    os.environ.setdefault("NEO4J_USER", os.getenv("FAIK_INVENTORY_MANAGED_NEO4J_USER", "neo4j"))
    os.environ.setdefault("NEO4J_PASSWORD", os.getenv("FAIK_INVENTORY_MANAGED_NEO4J_PASSWORD", "neo4j"))
    os.environ.setdefault("NEO4J_DATABASE", "neo4j")

    return host, port


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the faik-inventory FastAPI server")
    parser.add_argument("--host", default=os.getenv("FAIK_INVENTORY_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("FAIK_INVENTORY_PORT", "8000")))
    parser.add_argument("--reload", action="store_true", default=False)
    parser.add_argument(
        "--managed-neo4j",
        action="store_true",
        help=(
            "Do not start Neo4j from this process. "
            "Verify a managed Neo4j process is already running and reachable."
        ),
    )
    parser.add_argument(
        "--managed-neo4j-bolt-port",
        type=int,
        default=0,
        help=(
            "Override Bolt port check/NEO4J_URI for managed mode. "
            "Use only to force a custom endpoint port."
        ),
    )
    parser.add_argument(
        "--managed-neo4j-dir",
        default=os.getenv("FAIK_INVENTORY_MANAGED_DIR", str(Path.home() / ".local" / "share" / "faik-inventory")),
        help="Deprecated: retained for compatibility; managed mode no longer stores runtime data.",
    )
    args = parser.parse_args()

    if args.managed_neo4j:
        host, port = _setup_external_managed_neo4j()
        if args.managed_neo4j_bolt_port:
            port = args.managed_neo4j_bolt_port
            os.environ["NEO4J_URI"] = f"bolt://{host}:{port}"

        try:
            _wait_for_managed_neo4j(host, port)
        except Exception as exc:
            _print_managed_neo4j_setup_and_exit(
                f"timed out waiting for Neo4j on {host}:{port}. {exc}"
            )

        print(
            "Using externally managed Neo4j for this process: "
            f"bolt://{host}:{port}",
            file=sys.stderr,
        )

    uvicorn.run("app:app", host=args.host, port=args.port, reload=args.reload)


if __name__ == "__main__":
    main()
