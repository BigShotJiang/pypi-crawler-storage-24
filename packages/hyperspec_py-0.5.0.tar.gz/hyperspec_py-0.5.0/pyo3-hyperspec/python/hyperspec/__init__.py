"""Fast processing library for hyperspectral imagery."""

from hyperspec._hyperspec import (
    MnfResult,
    PcaResult,
    SpectralCube,
    __version__,
    band_ratio,
    continuum_removal,
    mnf,
    mnf_denoise,
    ndvi,
    normalized_difference,
    pca,
    pca_inverse,
    pca_transform,
    resample,
    sam,
)

__all__ = [
    "MnfResult",
    "PcaResult",
    "SpectralCube",
    "__version__",
    "band_ratio",
    "continuum_removal",
    "mnf",
    "mnf_denoise",
    "ndvi",
    "normalized_difference",
    "pca",
    "pca_inverse",
    "pca_transform",
    "resample",
    "sam",
]
