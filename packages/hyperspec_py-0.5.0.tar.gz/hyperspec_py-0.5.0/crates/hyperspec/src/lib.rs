//! Fast processing library for hyperspectral imagery.

pub mod algorithms;
pub mod cube;
pub mod error;

pub use algorithms::continuum::continuum_removal;
pub use algorithms::indices::{band_ratio, ndvi, normalized_difference};
pub use algorithms::mnf::{MnfResult, mnf, mnf_denoise};
pub use algorithms::pca::{PcaResult, pca, pca_inverse, pca_transform};
pub use algorithms::resample::{ResampleMethod, resample};
pub use algorithms::sam::sam;
pub use cube::SpectralCube;
pub use error::{HyperspecError, Result};
