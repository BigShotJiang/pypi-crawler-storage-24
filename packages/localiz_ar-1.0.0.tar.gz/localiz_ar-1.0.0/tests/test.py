from localiz_ar import verify

def fn():
    data = {
        "prov_id": 153540,
        "city_id": 9798120,
        "street_id": 2,
    }

    status, property = verify(data, 3)  # nivel 3
    print(status, property)

    status2, property2 = verify(data, 4)  # nivel 4
    print(status2, property2)


if __name__ == "__main__":
    fn()