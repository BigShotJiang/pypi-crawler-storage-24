# LOCALIZ.AR (BACK-END CON PYTHON)

Verificación de direcciones argentinas generadas con la [librería  
Front-End de localiz.ar](https://github.com/santiagomirantes/localiz.ar)

Este paquete permite validar en el Back-End los objetos de dirección  
creados automáticamente por el formulario de localiz.ar, asegurando que  
los IDs enviados por el cliente existan realmente en la base de datos.

------------------------------------------------------------------------

## Instalación

```bash
pip install localiz-ar
```

------------------------------------------------------------------------

## Uso básico

```python

from localiz_ar import verify

result = verify({
  "prov_id": 153536,
  "city_id": 11909161,
  "street_id": 0,
  "number": 123,
  "floor": "Departamento 21"
})

if result[0]:
    print("Dirección válida")
else:
    print("Error en el campo:", result[1])

```

------------------------------------------------------------------------

## Método verify()
El método `verify()` es una función síncrona y cuenta con los siguientes parámetros:


verify(data, check_level)

- data (`dict`): datos extraídos de la librería Front-End  
- check_level (`int`): nivel de verificación de datos

El retorno será una tupla:

`[status, property]`

- `status` (`bool`): False si alguna propiedad es incorrecta  
- `property` (`str`): nombre de la propiedad incorrecta

**IMPORTANTE:** si hay un error de conexión con la base de datos, el método devolverá:
`[False, "internal"]`

------------------------------------------------------------------------

## Formato del objeto data

```python
{
  "prov_id": int,
  "city_id": int,
  "street_id": int,
  "number": int,
  "floor": str
}
```

Estos valores son generados automáticamente por el método `validate()` de la librería Front-End de localiz.ar.

------------------------------------------------------------------------

## Niveles de verificación

| Nivel | Verificación |
|:-:|:-:|
| 1  | Provincia  |
| 2  | Provincia y ciudad |
| 3  | Provincia, ciudad y calle |
| 4  | Provincia, ciudad, calle y número de calle |
| 5  | Provincia, ciudad, calle, número de calle y piso |

------------------------------------------------------------------------

## License

https://opendatacommons.org/licenses/odbl/1.0/

https://opendatacommons.org/licenses/dbcl/1.0/

## Data sources

© OpenStreetMap contributors  
https://www.openstreetmap.org/copyright

Servicio GeoRef – Instituto Geográfico Nacional (Argentina)  
https://creativecommons.org/licenses/by/4.0/
