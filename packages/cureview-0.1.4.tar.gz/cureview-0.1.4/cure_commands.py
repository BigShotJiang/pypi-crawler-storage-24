from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
import tomllib
from typing import TYPE_CHECKING, TextIO

from cure_branding import PRIMARY_CLI_COMMAND
from cure_errors import ReviewflowError
from cure_runtime import (
    REVIEW_INTELLIGENCE_CONFIG_EXAMPLE,
    _doctor_runtime_checks,
    _doctor_runtime_payload,
)
from cure_sessions import build_status_payload, resolve_observation_target
from paths import ReviewflowPaths

if TYPE_CHECKING:
    from cure_runtime import ReviewflowRuntime


def _reviewflow():
    import cure as rf

    return rf


def _watch_line_for_payload(payload: dict[str, object]) -> str:
    pr = payload.get("pr") if isinstance(payload.get("pr"), dict) else {}
    repo_slug = f"{pr.get('owner')}/{pr.get('repo')}#{pr.get('number')}"
    parts = [
        f"session={payload.get('session_id')}",
        f"repo={repo_slug}",
        f"status={payload.get('status')}",
        f"phase={payload.get('phase')}",
    ]
    latest_artifact = payload.get("latest_artifact") if isinstance(payload.get("latest_artifact"), dict) else {}
    latest_path = str((latest_artifact or {}).get("path") or "").strip()
    if latest_path:
        parts.append(f"artifact={latest_path}")
    llm = payload.get("llm") if isinstance(payload.get("llm"), dict) else {}
    llm_summary = str((llm or {}).get("summary") or "").strip()
    if llm_summary:
        parts.append(llm_summary)
    multipass = payload.get("multipass") if isinstance(payload.get("multipass"), dict) else {}
    multipass_enabled = bool(multipass.get("enabled") is True)
    multipass_mode = str(multipass.get("mode") or "").strip().lower()
    if multipass and (multipass_enabled or multipass_mode == "multipass"):
        mp_bits: list[str] = []
        step_workers = multipass.get("step_workers")
        effective_step_workers = multipass.get("effective_step_workers")
        if isinstance(step_workers, int) and step_workers > 0:
            if isinstance(effective_step_workers, int) and effective_step_workers > 0:
                mp_bits.append(f"multipass_workers={effective_step_workers}/{step_workers}")
            else:
                mp_bits.append(f"multipass_workers={step_workers}")
        step_states = multipass.get("step_states") if isinstance(multipass.get("step_states"), list) else []
        if step_states:
            queued = 0
            running = 0
            completed = 0
            failed = 0
            reused = 0
            for item in step_states:
                if not isinstance(item, dict):
                    continue
                status = str(item.get("status") or "").strip().lower()
                if status == "queued":
                    queued += 1
                elif status in {"running", "awaiting_validation"}:
                    running += 1
                elif status == "completed":
                    completed += 1
                elif status == "reused":
                    reused += 1
                elif status in {"failed", "canceled"}:
                    failed += 1
            state_bits: list[str] = []
            if running:
                state_bits.append(f"{running} running")
            if queued:
                state_bits.append(f"{queued} queued")
            if completed:
                state_bits.append(f"{completed} completed")
            if reused:
                state_bits.append(f"{reused} reused")
            if failed:
                state_bits.append(f"{failed} failed")
            if state_bits:
                mp_bits.append("steps=" + ",".join(state_bits))
        if mp_bits:
            parts.append(" ".join(mp_bits))
    live = payload.get("live_progress") if isinstance(payload.get("live_progress"), dict) else {}
    current = live.get("current") if isinstance(live.get("current"), dict) else {}
    current_text = str((current or {}).get("text") or (live or {}).get("last_agent_message") or "").strip()
    if current_text:
        current_text = " ".join(current_text.split())
        if len(current_text) > 80:
            current_text = current_text[:79] + "…"
        parts.append(f"current={current_text}")
    chunkhound = payload.get("chunkhound") if isinstance(payload.get("chunkhound"), dict) else {}
    access = chunkhound.get("access") if isinstance(chunkhound.get("access"), dict) else {}
    access_stage = str((access or {}).get("preflight_stage") or "").strip()
    access_status = str((access or {}).get("preflight_stage_status") or "").strip()
    access_error = str((access or {}).get("error") or "").strip()
    access_elapsed = access.get("elapsed_seconds")
    show_access = bool(access_stage) and (
        str(payload.get("phase") or "").strip() == "chunkhound_access_preflight"
        or (not bool(access.get("preflight_ok")))
        or access_status in {"running", "error", "timeout"}
    )
    if show_access:
        access_bits = [f"chunkhound={access_stage}"]
        if access_status:
            access_bits.append(access_status)
        if isinstance(access_elapsed, (int, float)):
            access_bits.append(f"{float(access_elapsed):.1f}s")
        if access_error and access_status in {"error", "timeout"}:
            compact_error = " ".join(access_error.split())
            if len(compact_error) > 80:
                compact_error = compact_error[:79] + "…"
            access_bits.append(compact_error)
        parts.append(" ".join(access_bits))
    return " ".join(parts)


def preferred_cli_invocation(invocation: str) -> str:
    return f"{PRIMARY_CLI_COMMAND} {invocation}"


def build_commands_catalog_payload() -> dict[str, object]:
    return {
        "schema_version": 2,
        "kind": "cure.commands",
        "commands": [
            {
                "name": "pr",
                "summary": "Create a new review session for a PR.",
                "targets": ["PR_URL"],
                "safety": "Use `--if-reviewed new` for stable agent-safe start semantics.",
                "tty": "Optional TUI on stderr when running in a real terminal.",
                "stdout": "Prints the created session directory path on success.",
                "exit_codes": {"0": "review started", "2": "usage or runtime error"},
                "recommended_invocation": preferred_cli_invocation("pr <PR_URL> --if-reviewed new"),
                "variants": [
                    {
                        "name": "compatibility",
                        "summary": "Bare `pr` keeps current prompt-or-new compatibility behavior.",
                        "invocation": preferred_cli_invocation("pr <PR_URL>"),
                    },
                ],
            },
            {
                "name": "followup",
                "summary": "Run a follow-up review inside an existing session sandbox.",
                "targets": ["session_id"],
                "safety": "Reuses the existing sandbox and appends a new follow-up artifact.",
                "tty": "Optional TUI on stderr when running in a real terminal.",
                "stdout": "Human-readable progress only; follow-up artifact path is not a stable stdout contract.",
                "exit_codes": {"0": "follow-up completed", "2": "usage or runtime error"},
                "recommended_invocation": preferred_cli_invocation("followup <session_id>"),
                "variants": [],
            },
            {
                "name": "resume",
                "summary": "Resume a multipass session, or use its existing PR URL compatibility behavior.",
                "targets": ["session_id", "PR_URL"],
                "safety": "PR URL mode keeps its special resume-or-followup behavior for compatibility.",
                "tty": "Optional TUI on stderr when running in a real terminal.",
                "stdout": "Human-readable progress only.",
                "exit_codes": {"0": "resume or compatible follow-up completed", "2": "usage or runtime error"},
                "recommended_invocation": preferred_cli_invocation("resume <session_id>"),
                "variants": [
                    {
                        "name": "pr_url_compatibility",
                        "summary": "PR URL mode preserves the existing special behavior documented in the README.",
                        "invocation": preferred_cli_invocation("resume <PR_URL>"),
                    },
                ],
            },
            {
                "name": "zip",
                "summary": "Synthesize a final arbiter review for the PR's current HEAD.",
                "targets": ["PR_URL"],
                "safety": "Reads existing review artifacts; does not create a new sandbox.",
                "tty": "Optional TUI on stderr when running in a real terminal.",
                "stdout": "Prints the generated zip markdown path on success.",
                "exit_codes": {"0": "zip completed", "2": "usage or runtime error"},
                "recommended_invocation": preferred_cli_invocation("zip <PR_URL>"),
                "variants": [],
            },
            {
                "name": "clean",
                "summary": "Delete an exact session, preview closed-session cleanup, or use the TTY cleaner.",
                "targets": ["session_id", "closed"],
                "safety": "Bulk cleanup is preview-first with `clean closed --json`; exact delete rejects `--yes`.",
                "tty": "Required only for `clean` with no target and `clean closed` without `--yes`.",
                "stdout": "Structured JSON on `--json`; otherwise human-readable cleanup output.",
                "exit_codes": {"0": "cleanup query or deletion completed", "2": "usage, lookup, or runtime error"},
                "recommended_invocation": preferred_cli_invocation("clean closed --json"),
                "variants": [
                    {
                        "name": "bulk_execute",
                        "summary": "Execute closed-session cleanup after previewing matches.",
                        "invocation": preferred_cli_invocation("clean closed --yes --json"),
                    },
                    {
                        "name": "exact_delete",
                        "summary": "Delete one exact session with a structured result.",
                        "invocation": preferred_cli_invocation("clean <session_id> --json"),
                    },
                ],
            },
            {
                "name": "status",
                "summary": "Resolve a session or PR URL and report the current recorded run state.",
                "targets": ["session_id", "PR_URL"],
                "safety": "Read-only view backed by `meta.json` and recorded artifacts/logs.",
                "tty": "No TTY required.",
                "stdout": "Human-readable single-line status by default, structured JSON with `--json`.",
                "exit_codes": {"0": "target resolved", "2": "invalid target, lookup failure, or corrupt metadata"},
                "recommended_invocation": preferred_cli_invocation("status <session_id|PR_URL> --json"),
                "variants": [],
            },
            {
                "name": "watch",
                "summary": "Attach to a recorded session and follow progress until completion.",
                "targets": ["session_id", "PR_URL"],
                "safety": "Read-only attach flow; uses the same resolver as `status`.",
                "tty": "TTY mode reuses the existing dashboard; non-TTY mode prints plain polling lines.",
                "stdout": "Progress lines until the session reaches `done` or `error`.",
                "exit_codes": {
                    "0": "session finished with status=done",
                    "1": "session finished with status=error",
                    "2": "invalid target, lookup failure, or corrupt metadata",
                },
                "recommended_invocation": preferred_cli_invocation("watch <session_id|PR_URL>"),
                "variants": [],
            },
        ],
    }


def commands_flow(args: argparse.Namespace, *, stdout: TextIO | None = None) -> int:
    out = stdout or sys.stdout
    payload = build_commands_catalog_payload()
    if bool(getattr(args, "json_output", False)):
        print(json.dumps(payload, indent=2, sort_keys=True), file=out)
        return 0
    for command in payload["commands"]:
        print(f"{command['name']}: {command['summary']}", file=out)
        print(f"  {command['recommended_invocation']}", file=out)
        for variant in command.get("variants", []):
            if isinstance(variant, dict) and str(variant.get("invocation") or "").strip():
                print(f"    {variant['name']}: {variant['invocation']}", file=out)
    return 0


def status_flow(
    args: argparse.Namespace,
    *,
    paths: ReviewflowPaths,
    stdout: TextIO | None = None,
) -> int:
    out = stdout or sys.stdout
    payload = build_status_payload(str(getattr(args, "target", "") or ""), sandbox_root=paths.sandbox_root)
    if bool(getattr(args, "json_output", False)):
        print(json.dumps(payload, indent=2, sort_keys=True), file=out)
        return 0
    print(_watch_line_for_payload(payload), file=out)
    return 0


def watch_flow(
    args: argparse.Namespace,
    *,
    paths: ReviewflowPaths,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    rf = _reviewflow()
    out = stdout or sys.stdout
    err = stderr or sys.stderr
    target = str(getattr(args, "target", "") or "")
    resolved = resolve_observation_target(target, sandbox_root=paths.sandbox_root, command_name="watch")
    interval = max(0.0, float(getattr(args, "interval", 2.0) or 0.0))
    verbosity = rf._coerce_ui_verbosity(str(getattr(args, "verbosity", "normal") or "normal"))

    try:
        is_tty = bool(out.isatty()) and bool(err.isatty())
    except Exception:
        is_tty = False

    if is_tty:
        color = rf._stream_supports_color(out) and (not bool(getattr(args, "no_color", False)))
        while True:
            out.write("\x1b[2J\x1b[H")
            out.flush()
            status = rf._render_ui_preview(
                session_dir=resolved.session_dir,
                meta_path=resolved.meta_path,
                verbosity=verbosity,
                color=color,
                width=None,
                height=None,
                final_newline=False,
                stdout=out,
            )
            if status in {"done", "error"}:
                return 0 if status == "done" else 1
            time.sleep(interval if interval > 0 else 0.2)

    last_line = None
    while True:
        payload = build_status_payload(resolved.session_id, sandbox_root=paths.sandbox_root, command_name="watch")
        line = _watch_line_for_payload(payload)
        if line != last_line:
            print(line, file=out)
            out.flush()
            last_line = line
        status = str(payload.get("status") or "").strip().lower()
        if status in {"done", "error"}:
            return 0 if status == "done" else 1
        time.sleep(interval if interval > 0 else 0.2)


def cache_prime(
    *,
    paths: ReviewflowPaths,
    config_path: Path | None = None,
    host: str,
    owner: str,
    repo: str,
    base_ref: str,
    force: bool = False,
    quiet: bool = False,
    no_stream: bool = False,
) -> int:
    rf = _reviewflow()
    return rf.cache_prime(
        paths=paths,
        config_path=config_path,
        host=host,
        owner=owner,
        repo=repo,
        base_ref=base_ref,
        force=force,
        quiet=quiet,
        no_stream=no_stream,
    )


def cache_status(*, paths: ReviewflowPaths, host: str, owner: str, repo: str, base_ref: str) -> int:
    rf = _reviewflow()
    return rf.cache_status(paths=paths, host=host, owner=owner, repo=repo, base_ref=base_ref)


def _path_has_text(path: Path) -> bool:
    try:
        return bool(path.read_text(encoding="utf-8").strip())
    except FileNotFoundError:
        return False


def _default_chunkhound_base_config_path(config_path: Path) -> Path:
    return (config_path.parent / "chunkhound-base.json").resolve(strict=False)


def _load_existing_chunkhound_base_config_path(config_path: Path) -> Path | None:
    try:
        text = config_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise ReviewflowError(f"Failed to read CURe config at {config_path}: {exc}") from exc
    if not text.strip():
        return None
    try:
        raw = tomllib.loads(text)
    except tomllib.TOMLDecodeError as exc:
        raise ReviewflowError(
            f"Failed to parse existing CURe config at {config_path}; use --force to replace it."
        ) from exc
    chunkhound = raw.get("chunkhound")
    if not isinstance(chunkhound, dict):
        return None
    raw_path = str(chunkhound.get("base_config_path") or "").strip()
    if not raw_path:
        return None
    resolved = Path(raw_path).expanduser()
    if not resolved.is_absolute():
        resolved = config_path.parent / resolved
    return resolved.resolve(strict=False)


def _auto_embedding_block() -> dict[str, str] | None:
    if os.environ.get("VOYAGE_API_KEY"):
        return {"provider": "voyage", "model": "voyage-code-3"}
    if os.environ.get("OPENAI_API_KEY"):
        return {"provider": "openai", "model": "text-embedding-3-small"}
    return None


def _render_init_config(*, runtime: ReviewflowRuntime, chunkhound_base_config_path: Path) -> str:
    lines = [
        "# Generated by `cure init`.",
        "# This file is intentionally non-secret and safe to edit locally.",
        "",
        "[paths]",
        f"sandbox_root = {json.dumps(str(runtime.paths.sandbox_root))}",
        f"cache_root = {json.dumps(str(runtime.paths.cache_root))}",
        "",
        REVIEW_INTELLIGENCE_CONFIG_EXAMPLE.rstrip(),
        "",
        "[chunkhound]",
        f"base_config_path = {json.dumps(str(chunkhound_base_config_path))}",
        "",
    ]
    return "\n".join(lines)


def init_flow(args: argparse.Namespace, *, runtime: ReviewflowRuntime) -> int:
    config_path = runtime.config_path
    force = bool(getattr(args, "force", False))
    existing_base_path = None if force else _load_existing_chunkhound_base_config_path(config_path)
    chunkhound_base_config_path = existing_base_path or _default_chunkhound_base_config_path(config_path)

    config_path.parent.mkdir(parents=True, exist_ok=True)
    chunkhound_base_config_path.parent.mkdir(parents=True, exist_ok=True)

    config_written = False
    if force or not _path_has_text(config_path):
        config_path.write_text(
            _render_init_config(
                runtime=runtime,
                chunkhound_base_config_path=chunkhound_base_config_path,
            ),
            encoding="utf-8",
        )
        config_written = True
        print(f"Wrote CURe config: {config_path}")
    else:
        print(f"Left existing CURe config unchanged: {config_path}")

    if not config_written and existing_base_path is None:
        print(
            "Left ChunkHound base config unchanged because the existing cure.toml does not declare `[chunkhound].base_config_path`."
        )
    elif force or not _path_has_text(chunkhound_base_config_path):
        payload: dict[str, object] = {}
        embedding = _auto_embedding_block()
        if embedding is not None:
            payload["embedding"] = embedding
        chunkhound_base_config_path.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        suffix = f" ({embedding['provider']} embedding defaults)" if embedding is not None else ""
        print(f"Wrote ChunkHound base config: {chunkhound_base_config_path}{suffix}")
    else:
        print(f"Left existing ChunkHound base config unchanged: {chunkhound_base_config_path}")

    print(f"Next: {PRIMARY_CLI_COMMAND} install")
    return 0


def pr_flow(
    args: argparse.Namespace,
    *,
    paths: ReviewflowPaths,
    config_path: Path | None = None,
    codex_base_config_path: Path | None = None,
) -> int:
    rf = _reviewflow()
    return rf._pr_flow_impl(
        args,
        paths=paths,
        config_path=config_path,
        codex_base_config_path=codex_base_config_path,
    )


def resume_flow(
    args: argparse.Namespace,
    *,
    paths: ReviewflowPaths,
    config_path: Path | None = None,
    codex_base_config_path: Path | None = None,
) -> int:
    rf = _reviewflow()
    return rf._resume_flow_impl(
        args,
        paths=paths,
        config_path=config_path,
        codex_base_config_path=codex_base_config_path,
    )


def followup_flow(
    args: argparse.Namespace,
    *,
    paths: ReviewflowPaths,
    config_path: Path | None = None,
    codex_base_config_path: Path | None = None,
) -> int:
    rf = _reviewflow()
    return rf._followup_flow_impl(
        args,
        paths=paths,
        config_path=config_path,
        codex_base_config_path=codex_base_config_path,
    )


def zip_flow(
    args: argparse.Namespace,
    *,
    paths: ReviewflowPaths,
    config_path: Path | None = None,
    codex_base_config_path: Path | None = None,
) -> int:
    rf = _reviewflow()
    return rf._zip_flow_impl(
        args,
        paths=paths,
        config_path=config_path,
        codex_base_config_path=codex_base_config_path,
    )


def interactive_flow(
    args: argparse.Namespace,
    *,
    paths: ReviewflowPaths,
    config_path: Path | None = None,
    stdin: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    rf = _reviewflow()
    return rf._interactive_flow_impl(
        args,
        paths=paths,
        config_path=config_path,
        stdin=stdin,
        stderr=stderr,
    )


def clean_flow(
    args: argparse.Namespace,
    *,
    paths: ReviewflowPaths,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    rf = _reviewflow()
    session_id = str(getattr(args, "session_id", "") or "").strip()
    json_output = bool(getattr(args, "json_output", False))
    auto_yes = bool(getattr(args, "yes", False))
    out_stream = stdout or sys.stdout
    if (not session_id) and (json_output or auto_yes):
        raise rf.ReviewflowError("clean with no target does not accept --yes or --json.")
    if session_id == "closed":
        return rf.clean_closed_flow(args, paths=paths, stdin=stdin, stdout=out_stream, stderr=stderr)
    if session_id:
        if auto_yes:
            raise rf.ReviewflowError("clean <session_id> does not accept --yes.")
        return rf.clean_session(session_id, paths=paths, stdout=out_stream, json_output=json_output)
    return rf.interactive_clean_flow(args, paths=paths, stdin=stdin, stderr=stderr)


def doctor_flow(args: argparse.Namespace, *, runtime: ReviewflowRuntime) -> int:
    pr_url = str(getattr(args, "pr_url", "") or "").strip() or None
    checks = _doctor_runtime_checks(
        runtime,
        cli_profile=getattr(args, "agent_runtime_profile", None),
        pr_url=pr_url,
    )
    if bool(getattr(args, "json_output", False)):
        ok_count = sum(1 for item in checks if item.status == "ok")
        warn_count = sum(1 for item in checks if item.status == "warn")
        fail_count = sum(1 for item in checks if item.status == "fail")
        payload = _doctor_runtime_payload(
            runtime,
            cli_profile=getattr(args, "agent_runtime_profile", None),
            pr_url=pr_url,
        )
        payload["checks"] = [
            {"name": item.name, "status": item.status, "detail": item.detail} for item in checks
        ]
        payload["summary"] = {"ok": ok_count, "warn": warn_count, "fail": fail_count}
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0 if fail_count == 0 else 1

    ok_count = sum(1 for item in checks if item.status == "ok")
    warn_count = sum(1 for item in checks if item.status == "warn")
    fail_count = sum(1 for item in checks if item.status == "fail")
    for item in checks:
        print(f"[{item.status}] {item.name}: {item.detail}")
    print(f"summary: ok={ok_count} warn={warn_count} fail={fail_count}")
    return 0 if fail_count == 0 else 1


__all__ = [
    "build_commands_catalog_payload",
    "cache_prime",
    "cache_status",
    "clean_flow",
    "commands_flow",
    "doctor_flow",
    "followup_flow",
    "init_flow",
    "interactive_flow",
    "pr_flow",
    "preferred_cli_invocation",
    "resume_flow",
    "status_flow",
    "watch_flow",
    "zip_flow",
]
