# Pure-python JPEG parser
# Copyright (c) 2013 Thomas P. Robitaille


# Define common markers

MARKERS = {
    b"\xd8": "SOI",
    b"\xc0": "SOF0",
    b"\xc2": "SOF2",
    b"\xc4": "DHT",
    b"\xdb": "DQT",
    b"\xdd": "DRI",
    b"\xda": "SOS",
    b"\xd0": "RST0",
    b"\xd1": "RST1",
    b"\xd2": "RST2",
    b"\xd3": "RST3",
    b"\xd4": "RST4",
    b"\xd5": "RST5",
    b"\xd6": "RST6",
    b"\xd7": "RST7",
    b"\xe0": "APP0",
    b"\xe1": "APP1",
    b"\xe2": "APP2",
    b"\xe3": "APP3",
    b"\xe4": "APP4",
    b"\xe5": "APP5",
    b"\xe6": "APP6",
    b"\xe7": "APP7",
    b"\xe8": "APP8",
    b"\xe9": "APP9",
    b"\xfe": "COM",
    b"\xd9": "EOI",
}

# Define some markers which are always followed by variable-length data

VARIABLE = ["APP0", "APP1", "APP2", "APP3", "APP4", "APP5", "APP6", "APP7", "APP8", "APP9"]


def is_jpeg(filename):
    with open(filename, "rb") as f:
        return f.read(3) == b"\xff\xd8\xff"


class JPEGSegment:
    @classmethod
    def from_bytes(cls, bytes):
        self = cls()
        if bytes[1:2] in MARKERS:
            self.type = MARKERS[bytes[1:2]]
        else:
            self.type = "UNKNOWN"
        self.bytes = bytes
        return self

    def write(self, fileobj):
        fileobj.write(self.bytes)


class JPEGFile:
    @classmethod
    def read(cls, filename):
        with open(filename, "rb") as fileobj:
            contents = fileobj.read()

        self = cls()

        # Search for all starts of segments. Segments all start with 0xff, but
        # we should ignore 0xff instances that are followed by 0x00.

        self.segments = []

        start = end = 0
        while True:
            if (
                contents[start + 1 : start + 2] in MARKERS
                and MARKERS[contents[start + 1 : start + 2]] in VARIABLE
            ):
                end = contents.find(b"\xff", end + 4)
            else:
                end = contents.find(b"\xff", end + 1)
            if end == -1 or contents[end + 1 : end + 2] not in [b"\xff", b"\x00"]:
                if end == -1:
                    end = len(contents) + 1
                self.segments.append(JPEGSegment.from_bytes(contents[start:end]))
                if end == len(contents) + 1:
                    break
                else:
                    start = end

        if self.segments[0].type != "SOI":
            raise ValueError(f"Image did not start with SOI but with {self.segments[0].type}")

        if self.segments[-1].type != "EOI":
            raise ValueError(f"Image did not end with EOI but with {self.segments[-1].type}")

        return self

    def write(self, filename):
        with open(filename, "wb") as fileobj:
            for segment in self.segments:
                segment.write(fileobj)
