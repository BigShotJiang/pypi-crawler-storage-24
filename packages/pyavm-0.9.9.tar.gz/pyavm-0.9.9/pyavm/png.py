# Pure-python PNG parser
# Copyright (c) 2013 Thomas P. Robitaille

import struct
from zlib import crc32

PNG_SIGNATURE = b"\x89\x50\x4e\x47\x0d\x0a\x1a\x0a"


def is_png(filename):
    with open(filename, "rb") as f:
        return f.read(8) == b"\x89\x50\x4e\x47\x0d\x0a\x1a\x0a"


class PNGChunk:
    @classmethod
    def read(cls, fileobj):
        self = cls()

        # Read in chunk length
        length = struct.unpack(">I", fileobj.read(4))[0]

        # Read in chunk type
        self.type = fileobj.read(4)

        # Read in data
        self.data = fileobj.read(length)

        # Read in CRC
        crc = struct.unpack(">I", fileobj.read(4))[0]

        # Check that the CRC matches the actual one
        if crc != self.crc:
            raise ValueError(f"CRC ({self.crc}) does not match advertised ({crc})")

        if length != self.length:
            raise ValueError(
                f"Dynamic length ({self.length}) does not match original length ({length})"
            )

        return self

    def write(self, fileobj):
        # Write length
        fileobj.write(struct.pack(">I", self.length))

        # Write type
        fileobj.write(self.type)

        # Write data
        fileobj.write(self.data)

        # Write CRC
        fileobj.write(struct.pack(">I", self.crc))

    @property
    def crc(self):
        return crc32(self.type + self.data) & 0xFFFFFFFF

    @property
    def length(self):
        return len(self.data)


class PNGFile:
    @classmethod
    def read(cls, filename):
        with open(filename, "rb") as fileobj:
            self = cls()

            # Read signature
            sig = fileobj.read(8)

            if sig != PNG_SIGNATURE:
                raise ValueError(f"Signature ({sig}) does match expected ({PNG_SIGNATURE})")

            self.chunks = []

            while True:
                chunk = PNGChunk.read(fileobj)
                self.chunks.append(chunk)
                if chunk.type == b"IEND":
                    break

        return self

    def write(self, filename):
        with open(filename, "wb") as fileobj:
            fileobj.write(PNG_SIGNATURE)

            for chunk in self.chunks:
                chunk.write(fileobj)
