import polars as pl

allowed_events = ["MUSCULOSKELETAL", "CARDIOVASCULAR", "CANCER"]

lf = (
    pl.scan_parquet("combined_diag_death.parquet")
    .filter(
        pl.col("TDiag").is_in(allowed_events).all().over("case:PNR")
        & pl.all_horizontal(
            [pl.col("TDiag").eq(ev).any().over("case:PNR") for ev in allowed_events]
        )
    )
    .unique(subset=["case:PNR", "ADiag"], keep="first", maintain_order=True)
)

# Computing the average time between diagnoses for each case, excluding the death event
lf = (
    lf.with_columns(pl.col("startTime").diff().over("case:PNR").alias("_tmp_diff"))
    .with_columns(
        pl.col("_tmp_diff")
        .filter(pl.col("TDiag") != "Death")
        .mean()
        .over("case:PNR")
        .alias("case:avg_inter_diagnosis_time")
    )
    .drop("_tmp_diff")
)

# Computing variants
# 1. Group by case to get the sequence of events as a "variant"
lf_tmp = (
    lf.group_by("case:PNR")
    .agg(
        pl.col("TDiag").str.join(">").str.replace(r">Death$", "").alias("variants"),
        (pl.col("TDiag") != "Death").sum().alias("case:diagnosis_count"),
        (pl.col("TDiag") == "Death").any().alias("died"),
    )
    .with_columns(pl.col("died").mean().over("variants").alias("case:mortality"))
    .drop("died")
)

# Joining the KPI back to the main log for further analysis or export
patient_kpi_map = lf_tmp.select(
    [
        pl.col("case:PNR"),
        pl.col("case:mortality"),
        pl.col("case:diagnosis_count"),
    ]
)
lf = lf.join(patient_kpi_map, on="case:PNR", how="left")
