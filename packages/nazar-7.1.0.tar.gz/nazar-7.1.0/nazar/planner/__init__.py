"""Nazar Planner module."""
