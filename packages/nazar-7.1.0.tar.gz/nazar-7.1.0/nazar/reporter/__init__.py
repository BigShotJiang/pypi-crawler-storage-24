"""Nazar Reporter module."""
