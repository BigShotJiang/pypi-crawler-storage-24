"""Nazar Runners module."""
