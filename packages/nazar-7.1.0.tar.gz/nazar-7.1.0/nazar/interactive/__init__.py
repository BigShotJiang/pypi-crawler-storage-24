"""Nazar Interactive Shell."""
