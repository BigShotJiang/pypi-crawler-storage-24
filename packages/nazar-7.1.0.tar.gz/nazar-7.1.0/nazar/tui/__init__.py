"""Nazar TUI module."""
