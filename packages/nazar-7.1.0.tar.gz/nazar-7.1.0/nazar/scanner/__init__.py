"""Nazar Scanner module."""
