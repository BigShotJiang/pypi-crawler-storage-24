# Changelog

## 0.4.0

- Add `update_knowledge` tool for updating title and text content of existing knowledge (file uploads not yet supported)
- Add `api_patch` helper and `topic_knowledge_detail` route

## 0.3.0

- Add `create_topic` and `add_knowledge` tools for saving knowledge from conversations
- Add `api_post` helper and refactor `api_request` to `api_get`
- Extract `API_TIMEOUT` and `SOURCE_TYPE_LOCAL_MCP` constants
- Fix `sync-version` Makefile command

## 0.2.6

- Improve MCP registry quality score
- Add pagination and parameter descriptions to tools

## 0.2.5

- Add `server.json` for MCP registry compatibility
- Add remote streamable-http transport

## 0.2.4

- Add launch guide

## 0.2.3

- Filter out in-flight knowledge from API responses

## 0.2.0

- Rename "projects" to "topics" across tools, routes, and docs

## 0.1.5

- Add PDF visual parsing hint to file download instructions

## 0.1.4

- Remove chunk-based tools in favor of full content retrieval
- Add `client_hint` field and pagination progress

## 0.1.3

- Add image download hint to tool output

## 0.1.2

- Add paginated reference details with chunked content and image support

## 0.1.1

- Rename "context" to "references"
- Add tool annotations and improve documentation

## 0.1.0

Initial release.

- `list_topics` — browse all Obris topics
- `get_topic_knowledge` — retrieve saved knowledge for a topic
