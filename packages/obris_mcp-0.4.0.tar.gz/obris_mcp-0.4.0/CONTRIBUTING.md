# Contributing

Thanks for your interest in contributing to the Obris MCP server!

## Setup

```bash
git clone https://github.com/obris-dev/obris-mcp.git
cd obris-mcp
uv sync
```

Set your API key (add to `~/.zshrc`, `~/.zprofile`, or `~/.bash_profile`):

```bash
export OBRIS_API_KEY=your_api_key_here
```

Then reload your shell:

```bash
source ~/.zshrc
```

## Testing locally

To test your changes, point your MCP client at your local clone instead of the published package.

### Claude Desktop

Open Claude Desktop settings → **Developer** → **Edit Config**, and add the following to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "obris": {
      "command": "/full/path/to/uv",
      "args": [
        "--directory",
        "/path/to/obris-mcp/src/obris_mcp",
        "run",
        "main.py"
      ],
      "env": {
        "OBRIS_API_KEY": "$OBRIS_API_KEY"
      }
    }
  }
}
```

> Run `which uv` to get the full path for `"command"`. Replace `/path/to/obris-mcp` with the actual path to your clone.

Restart Claude Desktop to pick up the changes.

### Claude Code

```bash
claude mcp add Obris -s user -e OBRIS_API_KEY=$OBRIS_API_KEY --transport stdio -- /full/path/to/uv --directory /path/to/obris-mcp/src/obris_mcp run main.py
```

> Run `which uv` to get the full path.

Start a new conversation and type `/mcp` to verify the Obris server is connected.

## Submitting changes

1. Fork the repo and create a branch from `main`
2. Make your changes
3. Test locally with Claude Desktop or Claude Code (see above)
4. Open a pull request with a clear description of what and why

## Reporting bugs

Open an issue on [GitHub](https://github.com/obris-dev/obris-mcp/issues) with:

- What you expected to happen
- What actually happened
- Your OS, Python version, and MCP client (Claude Desktop, Claude Code, etc.)

## Questions?

Reach out at [support@obris.ai](mailto:support@obris.ai).
