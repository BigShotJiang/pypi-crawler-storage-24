# Obris

## Tagline
Save knowledge from the web and make it available to every AI conversation automatically.

## Description
Obris connects the knowledge you collect to your AI conversations. 
Save content from the web using the Chrome extension or upload files directly, 
organize it into topics, and any connected AI tool can access it automatically. 
No copy-pasting, no re-explaining.

## Setup Requirements
- `OBRIS_API_KEY` (required): Your Obris API key. Generate one from your dashboard. https://app.obris.ai/api-keys

## Category
Productivity

## Use Cases
Research, Writing, Decision Making, Brand Consistency, Content Creation, Learning, Meeting Prep, Technical Context, Outreach

## Features
- Stop re-explaining yourself. Save knowledge once and every AI conversation has it
- Your AI knows what's specific to you, your brand, your stack, your workflows
- Ask synthesis questions that pull from everything you've saved, not just one source
- Organize knowledge into topics so your AI pulls the right context for the right task
- Works with text, images, PDFs, anything you've saved or uploaded
- Read-only. Your data is never modified by the server

## Getting Started
Try asking your AI:
- "What Obris topics do I have?"
- "Using my Obris knowledge, pull in my brand guidelines and logos and help me generate a new hero for my marketing site."
- "Using Obris, help me scaffold this repo using my Payments Design documentation."
- "Based on my saved Obris outreach topic, what patterns made them successful?"
- "Use my Shoe Dog topic and tell me the key takeaways from my Shoe Dog highlights."

Tools:
- list_topics — List all your Obris topics
- get_topic_knowledge — Retrieve saved knowledge for a specific topic

## Tags
knowledge, context, bookmarks, highlights, notes, research, productivity, brand, content, documents, mcp, ai-context

## Documentation URL
https://docs.obris.ai

## Health Check URL
https://mcp.obris.ai/health
