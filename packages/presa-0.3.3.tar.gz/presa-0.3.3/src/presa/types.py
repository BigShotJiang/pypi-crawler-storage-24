"""Type definitions for the Presa SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Union


NamedFormat = Literal["A4", "Letter", "Legal"]


@dataclass
class CustomFormat:
    """Custom paper dimensions with unit (e.g., '210mm', '8.5in')."""

    width: str
    height: str


PageFormat = Union[NamedFormat, CustomFormat]


@dataclass
class Margins:
    """Page margins with CSS-style unit strings (e.g., '1cm', '0.5in')."""

    top: str | None = None
    right: str | None = None
    bottom: str | None = None
    left: str | None = None


@dataclass
class PdfMetadata:
    """Optional PDF document metadata applied to the generated output."""

    title: str | None = None
    author: str | None = None
    subject: str | None = None
    keywords: str | None = None
    creator: str | None = None


@dataclass
class GenerateOptions:
    """Options for PDF generation."""

    html: str
    """HTML content to convert to PDF."""

    format: PageFormat | None = None
    """Paper format. Defaults to A4."""

    landscape: bool | None = None
    """Use landscape orientation. Defaults to false."""

    margins: Margins | None = None
    """Page margins. Defaults to 1cm on all sides."""

    print_background: bool | None = None
    """Print background graphics. Defaults to true."""

    scale: float | None = None
    """Scale of the content. Between 0.1 and 2.0. Defaults to 1.0."""

    header_html: str | None = None
    """HTML for repeating page header."""

    footer_html: str | None = None
    """HTML for repeating page footer."""

    width: str | None = None
    """Custom page width (e.g. '100mm', '4in')."""

    height: str | None = None
    """Custom page height (e.g. '100mm', '4in')."""

    accept: str | None = None
    """Output format: 'application/pdf' (default), 'image/png', 'image/jpeg', 'image/webp'."""

    url: str | None = None
    """URL to convert (used with from_url)."""

    metadata: PdfMetadata | None = None
    """Optional PDF metadata (title, author, subject, keywords, creator)."""

    async_mode: bool | None = None
    """If true, process asynchronously and return a job ID."""

    store: bool | None = None
    """If true, store the output and return a download URL instead of binary."""


@dataclass
class GenerateResult:
    """Result of a PDF generation request."""

    buffer: bytes
    """Raw PDF bytes."""

    size: int
    """Content length in bytes."""


@dataclass
class AsyncJobResponse:
    """Response returned when async_mode=True."""

    job_id: str
    status: str
    poll_url: str


@dataclass
class JobResult:
    """Result details for a completed async job."""

    storage_url: str
    expires_at: str
    content_type: str
    size_bytes: int


@dataclass
class JobError:
    """Error details for a failed async job."""

    code: str
    message: str


@dataclass
class JobStatus:
    """Status of an async generation job."""

    job_id: str
    status: str  # pending, processing, completed, failed
    created_at: str = ""
    completed_at: str | None = None
    result: JobResult | None = None
    error: JobError | None = None


@dataclass
class StoredResponse:
    """Response returned when store=True."""

    storage_url: str
    expires_at: str
    content_type: str
    size_bytes: int


@dataclass
class BatchItem:
    """A single item in a batch generation request."""

    html: str | None = None
    url: str | None = None
    format: PageFormat | None = None
    landscape: bool | None = None
    margins: Margins | None = None
    print_background: bool | None = None
    scale: float | None = None
    header_html: str | None = None
    footer_html: str | None = None
    width: str | None = None
    height: str | None = None
    metadata: PdfMetadata | None = None


@dataclass
class BatchStatus:
    """Status of a batch generation job."""

    batch_id: str
    status: str
    total_items: int
    completed_items: int
    failed_items: int
    created_at: str
    completed_at: str | None = None


@dataclass
class BatchResult:
    """Result of a single item in a batch."""

    item_index: int
    job_id: str
    status: str
    storage_url: str | None = None
    error_code: str | None = None
    error_message: str | None = None


@dataclass
class JobSummary:
    """Summary of a job returned by the list endpoint."""

    job_id: str
    status: str
    job_type: str
    created_at: str
    completed_at: str | None = None


@dataclass
class AssetInfo:
    """Information about an uploaded asset."""

    id: str
    name: str
    uri: str
    content_type: str
    size_bytes: int
    created_at: str


@dataclass
class PresaConfig:
    """Configuration for the Presa client."""

    api_key: str | None = None
    """API key for authentication. Defaults to PRESA_API_KEY env var."""

    base_url: str = "https://api.presa.dev"
    """Base URL of the Presa API."""

    timeout: float = 30.0
    """Request timeout in seconds. Defaults to 30."""


@dataclass
class TemplateInfo:
    """Information about a template."""

    id: str
    name: str
    slug: str
    html: str
    variables: dict[str, object] | None
    created_at: str
    updated_at: str


@dataclass
class CursorPage:
    """Cursor-paginated response page."""

    data: list[Any]
    next_cursor: str | None
    has_more: bool


@dataclass
class CreateTemplateInput:
    """Input for creating a template."""

    name: str
    html: str


@dataclass
class UpdateTemplateInput:
    """Input for updating a template."""

    name: str
    html: str


@dataclass
class ListTemplatesOptions:
    """Options for listing templates."""

    limit: int | None = None
    after: str | None = None


@dataclass
class RenderOptions:
    """Options for rendering a template."""

    variables: dict[str, object] | None = None
    strict_variables: bool | None = None
    format: PageFormat | None = None
    landscape: bool | None = None
    margins: Margins | None = None
    print_background: bool | None = None
    scale: float | None = None
    header_html: str | None = None
    footer_html: str | None = None
    width: str | None = None
    height: str | None = None
    accept: str | None = None


@dataclass
class AssetListResponse:
    """Paginated list of assets."""

    data: list[AssetInfo]
    total: int
