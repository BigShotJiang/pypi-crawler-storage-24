# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class MoveAppToGroupRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'group_id': 'str',
        'application_ids': 'list[str]'
    }

    attribute_map = {
        'group_id': 'group_id',
        'application_ids': 'application_ids'
    }

    def __init__(self, group_id=None, application_ids=None):
        r"""MoveAppToGroupRequestBody

        The model defined in huaweicloud sdk

        :param group_id: 分组id
        :type group_id: str
        :param application_ids: 应用id列表
        :type application_ids: list[str]
        """
        
        

        self._group_id = None
        self._application_ids = None
        self.discriminator = None

        self.group_id = group_id
        self.application_ids = application_ids

    @property
    def group_id(self):
        r"""Gets the group_id of this MoveAppToGroupRequestBody.

        分组id

        :return: The group_id of this MoveAppToGroupRequestBody.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this MoveAppToGroupRequestBody.

        分组id

        :param group_id: The group_id of this MoveAppToGroupRequestBody.
        :type group_id: str
        """
        self._group_id = group_id

    @property
    def application_ids(self):
        r"""Gets the application_ids of this MoveAppToGroupRequestBody.

        应用id列表

        :return: The application_ids of this MoveAppToGroupRequestBody.
        :rtype: list[str]
        """
        return self._application_ids

    @application_ids.setter
    def application_ids(self, application_ids):
        r"""Sets the application_ids of this MoveAppToGroupRequestBody.

        应用id列表

        :param application_ids: The application_ids of this MoveAppToGroupRequestBody.
        :type application_ids: list[str]
        """
        self._application_ids = application_ids

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, MoveAppToGroupRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
