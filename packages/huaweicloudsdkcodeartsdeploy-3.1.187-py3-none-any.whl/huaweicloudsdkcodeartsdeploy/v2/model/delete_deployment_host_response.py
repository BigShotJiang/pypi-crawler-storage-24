# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteDeploymentHostResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'host_id': 'str'
    }

    attribute_map = {
        'host_id': 'host_id'
    }

    def __init__(self, host_id=None):
        r"""DeleteDeploymentHostResponse

        The model defined in huaweicloud sdk

        :param host_id: 主机id
        :type host_id: str
        """
        
        super().__init__()

        self._host_id = None
        self.discriminator = None

        if host_id is not None:
            self.host_id = host_id

    @property
    def host_id(self):
        r"""Gets the host_id of this DeleteDeploymentHostResponse.

        主机id

        :return: The host_id of this DeleteDeploymentHostResponse.
        :rtype: str
        """
        return self._host_id

    @host_id.setter
    def host_id(self, host_id):
        r"""Sets the host_id of this DeleteDeploymentHostResponse.

        主机id

        :param host_id: The host_id of this DeleteDeploymentHostResponse.
        :type host_id: str
        """
        self._host_id = host_id

    def to_dict(self):
        import warnings
        warnings.warn("DeleteDeploymentHostResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteDeploymentHostResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
