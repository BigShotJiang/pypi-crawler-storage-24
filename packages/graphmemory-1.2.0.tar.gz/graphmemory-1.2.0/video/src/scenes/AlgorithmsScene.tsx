import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from "remotion";
import { SectionTitle } from "../components/SectionTitle";
import { CodeBlock } from "../components/CodeBlock";
import { COLORS, FONT } from "../theme";

const CODE = `from graphmemory.algorithms import (
  pagerank,
  betweenness_centrality,
  degree_distribution,
  connected_components
)

# PageRank scores
scores = pagerank(graph, alpha=0.85)

# Export to NetworkX
G = graph.to_networkx()`;

type BarProps = {
  label: string;
  value: number;
  maxValue: number;
  color: string;
  index: number;
  delay: number;
};

const Bar: React.FC<BarProps> = ({ label, value, maxValue, color, index, delay }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const barEntrance = spring({
    frame,
    fps,
    delay: delay + index * 5,
    config: { damping: 200 },
  });

  const barWidth = interpolate(barEntrance, [0, 1], [0, (value / maxValue) * 350]);

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16, height: 44 }}>
      <div
        style={{
          width: 80,
          textAlign: "right",
          fontFamily: FONT.sans,
          fontSize: 24,
          fontWeight: 600,
          color: COLORS.text,
        }}
      >
        {label}
      </div>
      <div
        style={{
          width: barWidth,
          height: 28,
          background: `linear-gradient(90deg, ${color}, ${color}aa)`,
          borderRadius: 6,
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          paddingRight: 12,
        }}
      >
        {barEntrance > 0.8 && (
          <span
            style={{
              fontFamily: FONT.mono,
              fontSize: 18,
              fontWeight: 700,
              color: "white",
            }}
          >
            {value.toFixed(3)}
          </span>
        )}
      </div>
    </div>
  );
};

const PR_DATA = [
  { label: "Alice", value: 0.342, color: COLORS.accent },
  { label: "Bob", value: 0.287, color: COLORS.purple },
  { label: "Acme", value: 0.198, color: COLORS.green },
  { label: "SF", value: 0.103, color: COLORS.orange },
  { label: "Eve", value: 0.070, color: COLORS.pink },
];

export const AlgorithmsScene: React.FC = () => {
  return (
    <AbsoluteFill
      style={{ justifyContent: "flex-start", alignItems: "center", padding: 60 }}
    >
      <SectionTitle
        title="Graph Algorithms"
        subtitle="PageRank, centrality, components — powered by NetworkX"
      />
      <div
        style={{
          display: "flex",
          gap: 80,
          marginTop: 50,
          width: "100%",
          justifyContent: "center",
          alignItems: "flex-start",
        }}
      >
        <div style={{ flex: "0 0 auto" }}>
          <CodeBlock code={CODE} delay={20} typingSpeed={1.2} />
        </div>
        <div
          style={{
            flex: "0 0 auto",
            display: "flex",
            flexDirection: "column",
            gap: 8,
            marginTop: 20,
          }}
        >
          <div
            style={{
              fontFamily: FONT.sans,
              fontSize: 28,
              fontWeight: 700,
              color: COLORS.textMuted,
              marginBottom: 12,
            }}
          >
            PageRank Scores
          </div>
          {PR_DATA.map((d, i) => (
            <Bar key={d.label} {...d} maxValue={0.4} index={i} delay={40} />
          ))}
        </div>
      </div>
    </AbsoluteFill>
  );
};
