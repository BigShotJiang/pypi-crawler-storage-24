import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
} from "remotion";
import { SectionTitle } from "../components/SectionTitle";
import { CodeBlock } from "../components/CodeBlock";
import { FeaturePill } from "../components/FeaturePill";
import { COLORS } from "../theme";

const CODE = `# Export / Import in multiple formats
data = graph.export_graph(format="json")
graph.import_graph(data, format="json")

# CSV, GraphML, JSON string
csv = graph.export_graph(format="csv")
xml = graph.export_graph(format="graphml")

# Bulk operations
graph.bulk_insert_nodes(nodes)
graph.bulk_insert_edges(edges)
graph.bulk_delete_nodes(node_ids)`;

const FORMATS = [
  { label: "JSON", color: COLORS.accent },
  { label: "CSV", color: COLORS.green },
  { label: "GraphML", color: COLORS.purple },
  { label: "JSON String", color: COLORS.orange },
];

const OPS = [
  { label: "Bulk Insert", color: COLORS.green },
  { label: "Bulk Delete", color: COLORS.red },
  { label: "Transactions", color: COLORS.yellow },
  { label: "Thread-Safe", color: COLORS.accent },
  { label: "Auto-Retry", color: COLORS.purple },
  { label: "Connection Pool", color: COLORS.pink },
];

export const ExportScene: React.FC = () => {
  return (
    <AbsoluteFill
      style={{ justifyContent: "flex-start", alignItems: "center", padding: 60 }}
    >
      <SectionTitle
        title="Import / Export & Operations"
        subtitle="Multiple formats, bulk operations, transactions, and thread safety"
      />
      <div
        style={{
          display: "flex",
          gap: 60,
          marginTop: 50,
          width: "100%",
          justifyContent: "center",
          alignItems: "flex-start",
        }}
      >
        <div style={{ flex: "0 0 auto" }}>
          <CodeBlock code={CODE} delay={20} typingSpeed={1.4} />
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 30, marginTop: 10 }}>
          <div>
            <div
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: 26,
                fontWeight: 700,
                color: COLORS.textMuted,
                marginBottom: 12,
              }}
            >
              Export Formats
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
              {FORMATS.map((f, i) => (
                <FeaturePill key={f.label} label={f.label} color={f.color} delay={40} index={i} />
              ))}
            </div>
          </div>
          <div>
            <div
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: 26,
                fontWeight: 700,
                color: COLORS.textMuted,
                marginBottom: 12,
              }}
            >
              Operations
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 10, maxWidth: 450 }}>
              {OPS.map((f, i) => (
                <FeaturePill key={f.label} label={f.label} color={f.color} delay={55} index={i} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
