import React from "react";
import {
  AbsoluteFill,
  Img,
  useCurrentFrame,
  useVideoConfig,
  spring,
  staticFile,
} from "remotion";
import { COLORS, FONT } from "../theme";
import { FeaturePill } from "../components/FeaturePill";

export const IntroScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const bannerEntrance = spring({ frame, fps, config: { damping: 200 } });
  const installEntrance = spring({ frame, fps, delay: 25, config: { damping: 200 } });

  const features = [
    "DuckDB",
    "Vector Search",
    "Full-Text Search",
    "Merge / Upsert",
    "GraphRAG",
    "DSPy Extraction",
    "NetworkX",
    "Query Builder",
  ];

  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        gap: 28,
      }}
    >
      {/* Banner image */}
      <div
        style={{
          opacity: bannerEntrance,
          transform: `scale(${0.9 + 0.1 * bannerEntrance}) translateY(${(1 - bannerEntrance) * 40}px)`,
        }}
      >
        <Img
          src={staticFile("banner.png")}
          style={{
            width: 800,
            borderRadius: 20,
            boxShadow: `0 0 80px rgba(88, 166, 255, 0.15)`,
          }}
        />
      </div>

      {/* Install command */}
      <div
        style={{
          opacity: installEntrance,
          transform: `translateY(${(1 - installEntrance) * 20}px)`,
          background: COLORS.codeBg,
          border: `1px solid ${COLORS.codeBorder}`,
          borderRadius: 12,
          padding: "14px 32px",
          fontFamily: FONT.mono,
          fontSize: 28,
          color: COLORS.green,
        }}
      >
        <span style={{ color: COLORS.textMuted }}>$</span> pip install graphmemory
      </div>

      {/* Feature pills */}
      <div
        style={{
          display: "flex",
          gap: 12,
          flexWrap: "wrap",
          justifyContent: "center",
          maxWidth: 900,
          marginTop: 4,
        }}
      >
        {features.map((f, i) => (
          <FeaturePill
            key={f}
            label={f}
            delay={35 + i * 3}
            index={0}
            color={[COLORS.accent, COLORS.green, COLORS.purple, COLORS.yellow, COLORS.orange, COLORS.pink, COLORS.accent, COLORS.green][i]}
          />
        ))}
      </div>
    </AbsoluteFill>
  );
};
