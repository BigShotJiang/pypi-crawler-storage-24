import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from "remotion";
import { SectionTitle } from "../components/SectionTitle";
import { CodeBlock } from "../components/CodeBlock";
import { COLORS, FONT } from "../theme";

const CODE = `from graphmemory import MergeStrategy

# First call — inserts Alice
result = graph.merge_node(
  alice, match_keys=["name"])
# result.created = True

# Second call — updates, no duplicate
result = graph.merge_node(
  alice_v2, match_keys=["name"],
  strategy=MergeStrategy.UPDATE)
# result.created = False

# Bulk merge
results = graph.bulk_merge_nodes(
  nodes, match_keys=["name"])

# Edge dedup on (src, tgt, relation)
graph.bulk_merge_edges(edges)`;

type TimelineEvent = {
  label: string;
  detail: string;
  color: string;
  isUpdate: boolean;
};

const EVENTS: TimelineEvent[] = [
  { label: "merge Alice", detail: "INSERT (new)", color: COLORS.green, isUpdate: false },
  { label: "merge Bob", detail: "INSERT (new)", color: COLORS.green, isUpdate: false },
  { label: "merge Alice", detail: "UPDATE (exists)", color: COLORS.yellow, isUpdate: true },
  { label: "merge Carol", detail: "INSERT (new)", color: COLORS.green, isUpdate: false },
  { label: "merge Bob", detail: "UPDATE (exists)", color: COLORS.yellow, isUpdate: true },
];

export const MergeScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill
      style={{ justifyContent: "flex-start", alignItems: "center", padding: 60 }}
    >
      <SectionTitle
        title="Merge / Upsert"
        subtitle="Deduplicate nodes by property keys — insert new, update existing"
      />
      <div
        style={{
          display: "flex",
          gap: 60,
          marginTop: 50,
          width: "100%",
          justifyContent: "center",
          alignItems: "flex-start",
        }}
      >
        <div style={{ flex: "0 0 auto" }}>
          <CodeBlock code={CODE} delay={20} typingSpeed={1.2} />
        </div>
        <div
          style={{
            flex: "0 0 auto",
            display: "flex",
            flexDirection: "column",
            gap: 6,
            marginTop: 10,
          }}
        >
          <div
            style={{
              fontFamily: FONT.sans,
              fontSize: 26,
              fontWeight: 700,
              color: COLORS.textMuted,
              marginBottom: 8,
            }}
          >
            Merge Timeline
          </div>
          {EVENTS.map((evt, i) => {
            const evtEntrance = spring({
              frame,
              fps,
              delay: 30 + i * 15,
              config: { damping: 200 },
            });

            return (
              <div
                key={i}
                style={{
                  opacity: evtEntrance,
                  transform: `translateX(${(1 - evtEntrance) * 40}px)`,
                  display: "flex",
                  alignItems: "center",
                  gap: 14,
                  height: 48,
                }}
              >
                {/* Dot + line */}
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 20 }}>
                  <div
                    style={{
                      width: 14,
                      height: 14,
                      borderRadius: 7,
                      background: evt.color,
                      border: `2px solid ${evt.color}`,
                      boxShadow: `0 0 8px ${evt.color}60`,
                    }}
                  />
                  {i < EVENTS.length - 1 && (
                    <div style={{ width: 2, height: 34, background: COLORS.codeBorder, marginTop: -1 }} />
                  )}
                </div>

                {/* Label */}
                <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                  <div
                    style={{
                      fontFamily: FONT.mono,
                      fontSize: 20,
                      fontWeight: 600,
                      color: COLORS.text,
                    }}
                  >
                    {evt.label}
                  </div>
                  <div
                    style={{
                      fontFamily: FONT.sans,
                      fontSize: 17,
                      color: evt.color,
                      fontWeight: 600,
                    }}
                  >
                    {evt.detail}
                  </div>
                </div>

                {/* Strategy badge */}
                {evt.isUpdate && evtEntrance > 0.8 && (
                  <div
                    style={{
                      background: `${COLORS.yellow}18`,
                      border: `1px solid ${COLORS.yellow}55`,
                      borderRadius: 6,
                      padding: "3px 10px",
                      fontFamily: FONT.mono,
                      fontSize: 14,
                      color: COLORS.yellow,
                      fontWeight: 600,
                    }}
                  >
                    UPDATE
                  </div>
                )}
              </div>
            );
          })}

          {/* Counter */}
          {(() => {
            const counterEntrance = spring({
              frame,
              fps,
              delay: 30 + EVENTS.length * 15 + 10,
              config: { damping: 200 },
            });
            const nodeCount = 3;
            const callCount = 5;

            return (
              <div
                style={{
                  opacity: counterEntrance,
                  marginTop: 16,
                  display: "flex",
                  gap: 20,
                }}
              >
                <div
                  style={{
                    background: `${COLORS.green}15`,
                    border: `1px solid ${COLORS.green}40`,
                    borderRadius: 10,
                    padding: "10px 18px",
                    textAlign: "center",
                  }}
                >
                  <div style={{ fontFamily: FONT.mono, fontSize: 34, fontWeight: 800, color: COLORS.green }}>
                    {callCount}
                  </div>
                  <div style={{ fontFamily: FONT.sans, fontSize: 16, color: COLORS.textMuted }}>
                    merge calls
                  </div>
                </div>
                <div
                  style={{
                    background: `${COLORS.accent}15`,
                    border: `1px solid ${COLORS.accent}40`,
                    borderRadius: 10,
                    padding: "10px 18px",
                    textAlign: "center",
                  }}
                >
                  <div style={{ fontFamily: FONT.mono, fontSize: 34, fontWeight: 800, color: COLORS.accent }}>
                    {nodeCount}
                  </div>
                  <div style={{ fontFamily: FONT.sans, fontSize: 16, color: COLORS.textMuted }}>
                    unique nodes
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      </div>
    </AbsoluteFill>
  );
};
