import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from "remotion";
import { SectionTitle } from "../components/SectionTitle";
import { CodeBlock } from "../components/CodeBlock";
import { COLORS, FONT } from "../theme";

const CODE = `# Full GraphRAG pipeline
result = graph.retrieve(
  query="Who leads ML at Acme?",
  query_vector=embedding,
  max_hops=2,
  max_tokens=4000)

print(result.context_text)
print(result.token_estimate)

# End-to-end Q&A
answer = graph.ask(
  query="Who leads ML at Acme?",
  query_vector=embedding,
  llm_callable=my_llm)`;

const PIPELINE_STEPS = [
  { label: "Hybrid\nSearch", color: COLORS.accent, icon: "🔍" },
  { label: "Graph\nExpansion", color: COLORS.purple, icon: "🌐" },
  { label: "Context\nAssembly", color: COLORS.green, icon: "📋" },
  { label: "LLM\nGeneration", color: COLORS.orange, icon: "🤖" },
];

export const RetrievalScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill
      style={{ justifyContent: "flex-start", alignItems: "center", padding: 60 }}
    >
      <SectionTitle
        title="GraphRAG Retrieval"
        subtitle="Hybrid search → graph expansion → context assembly → LLM answer"
      />

      {/* Pipeline visualization */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 0,
          marginTop: 40,
        }}
      >
        {PIPELINE_STEPS.map((step, i) => {
          const stepEntrance = spring({
            frame,
            fps,
            delay: 15 + i * 12,
            config: { damping: 200 },
          });

          const arrowEntrance = spring({
            frame,
            fps,
            delay: 15 + i * 12 + 6,
            config: { damping: 200 },
          });

          return (
            <React.Fragment key={i}>
              <div
                style={{
                  opacity: stepEntrance,
                  transform: `scale(${stepEntrance})`,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 8,
                }}
              >
                <div
                  style={{
                    width: 100,
                    height: 100,
                    borderRadius: 20,
                    background: `${step.color}20`,
                    border: `2px solid ${step.color}`,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 4,
                  }}
                >
                  <span style={{ fontSize: 34 }}>{step.icon}</span>
                </div>
                <div
                  style={{
                    fontFamily: FONT.sans,
                    fontSize: 20,
                    fontWeight: 600,
                    color: step.color,
                    textAlign: "center",
                    whiteSpace: "pre-line",
                    lineHeight: 1.3,
                  }}
                >
                  {step.label}
                </div>
              </div>
              {i < PIPELINE_STEPS.length - 1 && (
                <svg
                  width={50}
                  height={20}
                  viewBox="0 0 50 20"
                  style={{ opacity: arrowEntrance, marginBottom: 30 }}
                >
                  <path
                    d="M 5 10 L 35 10 M 28 4 L 38 10 L 28 16"
                    fill="none"
                    stroke={COLORS.textMuted}
                    strokeWidth={2}
                    strokeLinecap="round"
                  />
                </svg>
              )}
            </React.Fragment>
          );
        })}
      </div>

      <div style={{ marginTop: 30 }}>
        <CodeBlock code={CODE} delay={60} typingSpeed={1.4} />
      </div>
    </AbsoluteFill>
  );
};
