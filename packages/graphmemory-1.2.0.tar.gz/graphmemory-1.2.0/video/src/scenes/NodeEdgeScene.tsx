import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring } from "remotion";
import { SectionTitle } from "../components/SectionTitle";
import { CodeBlock } from "../components/CodeBlock";
import { GraphViz } from "../components/GraphViz";
import { COLORS } from "../theme";

const NODES = [
  { id: "alice", label: "Alice", x: 180, y: 120, type: "Person", color: COLORS.nodeFill },
  { id: "bob", label: "Bob", x: 380, y: 80, type: "Person", color: COLORS.nodeFill },
  { id: "acme", label: "Acme", x: 280, y: 280, type: "Company", color: COLORS.purple },
  { id: "sf", label: "SF", x: 500, y: 220, type: "Location", color: COLORS.green },
];

const EDGES = [
  { from: "alice", to: "bob", label: "knows" },
  { from: "alice", to: "acme", label: "works_at" },
  { from: "bob", to: "acme", label: "works_at" },
  { from: "acme", to: "sf", label: "located_in" },
];

const CODE = `graph = GraphMemory(vector_length=384)

alice = Node(type="Person",
  properties={"name": "Alice"},
  vector=[0.1, 0.8, ...])

graph.insert_node(alice)
graph.insert_edge(Edge(
  source_id=alice.id,
  target_id=bob.id,
  relation="knows"))`;

export const NodeEdgeScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill
      style={{ justifyContent: "flex-start", alignItems: "center", padding: 60 }}
    >
      <SectionTitle
        title="Nodes & Edges"
        subtitle="Build knowledge graphs with typed nodes, properties, and vector embeddings"
      />
      <div
        style={{
          display: "flex",
          gap: 60,
          marginTop: 50,
          width: "100%",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div style={{ flex: "0 0 auto" }}>
          <CodeBlock code={CODE} delay={20} typingSpeed={1.2} />
        </div>
        <div style={{ flex: "0 0 auto" }}>
          <GraphViz
            nodes={NODES}
            edges={EDGES}
            delay={30}
            width={600}
            height={380}
          />
        </div>
      </div>
    </AbsoluteFill>
  );
};
