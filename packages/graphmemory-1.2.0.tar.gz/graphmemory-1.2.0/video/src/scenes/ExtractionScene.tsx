import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from "remotion";
import { SectionTitle } from "../components/SectionTitle";
import { CodeBlock } from "../components/CodeBlock";
import { GraphViz } from "../components/GraphViz";
import { COLORS, FONT } from "../theme";

const CODE = `from graphmemory.extraction import (
  extract_and_store
)

text = """
  Alice works at Acme Corp in
  San Francisco. Bob, her colleague,
  leads the ML team.
"""

nodes, edges = extract_and_store(
  graph, text)`;

const NODES = [
  { id: "alice", label: "Alice", x: 150, y: 100, type: "Person", color: COLORS.nodeFill },
  { id: "bob", label: "Bob", x: 400, y: 100, type: "Person", color: COLORS.nodeFill },
  { id: "acme", label: "Acme", x: 280, y: 220, type: "Org", color: COLORS.purple },
  { id: "sf", label: "SF", x: 280, y: 340, type: "Location", color: COLORS.green },
  { id: "ml", label: "ML Team", x: 480, y: 250, type: "Team", color: COLORS.orange },
];

const EDGES = [
  { from: "alice", to: "acme", label: "works_at" },
  { from: "bob", to: "acme", label: "works_at" },
  { from: "acme", to: "sf", label: "located_in" },
  { from: "bob", to: "ml", label: "leads" },
  { from: "alice", to: "bob", label: "colleague" },
];

export const ExtractionScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const arrowEntrance = spring({
    frame,
    fps,
    delay: 50,
    config: { damping: 200 },
  });

  return (
    <AbsoluteFill
      style={{ justifyContent: "flex-start", alignItems: "center", padding: 60 }}
    >
      <SectionTitle
        title="DSPy Extraction"
        subtitle="Extract entities and relationships from unstructured text with LLMs"
      />
      <div
        style={{
          display: "flex",
          gap: 40,
          marginTop: 50,
          width: "100%",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div style={{ flex: "0 0 auto" }}>
          <CodeBlock code={CODE} delay={20} typingSpeed={1.2} />
        </div>

        {/* Arrow */}
        <div
          style={{
            opacity: arrowEntrance,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 8,
          }}
        >
          <svg width={60} height={40} viewBox="0 0 60 40">
            <path
              d="M 5 20 L 45 20 M 35 10 L 50 20 L 35 30"
              fill="none"
              stroke={COLORS.accent}
              strokeWidth={3}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <div
            style={{
              fontFamily: FONT.sans,
              fontSize: 13,
              color: COLORS.textMuted,
            }}
          >
            DSPy
          </div>
        </div>

        <div style={{ flex: "0 0 auto" }}>
          <GraphViz
            nodes={NODES}
            edges={EDGES}
            delay={55}
            width={580}
            height={400}
          />
        </div>
      </div>
    </AbsoluteFill>
  );
};
