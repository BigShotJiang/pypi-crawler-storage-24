import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { COLORS } from "../theme";

export const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();

  const gridOffset = interpolate(frame, [0, 600], [0, 50], {
    extrapolateRight: "extend",
  });

  const gridSize = 60;
  const cols = Math.ceil(width / gridSize) + 2;
  const rows = Math.ceil(height / gridSize) + 2;

  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse at 50% 30%, ${COLORS.bgGradient2} 0%, ${COLORS.bg} 70%)`,
        }}
      />
      <svg width={width} height={height} style={{ position: "absolute", opacity: 0.15 }}>
        {Array.from({ length: cols }, (_, i) => (
          <line
            key={`v${i}`}
            x1={i * gridSize - (gridOffset % gridSize)}
            y1={0}
            x2={i * gridSize - (gridOffset % gridSize)}
            y2={height}
            stroke={COLORS.gridLine}
            strokeWidth={1}
          />
        ))}
        {Array.from({ length: rows }, (_, i) => (
          <line
            key={`h${i}`}
            x1={0}
            y1={i * gridSize - (gridOffset % gridSize)}
            x2={width}
            y2={i * gridSize - (gridOffset % gridSize)}
            stroke={COLORS.gridLine}
            strokeWidth={1}
          />
        ))}
      </svg>
    </AbsoluteFill>
  );
};
