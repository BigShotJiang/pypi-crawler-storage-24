import React from "react";
import { useCurrentFrame, useVideoConfig, spring } from "remotion";
import { COLORS, FONT } from "../theme";

type CodeBlockProps = {
  code: string;
  delay?: number;
  typingSpeed?: number;
};

export const CodeBlock: React.FC<CodeBlockProps> = ({
  code,
  delay = 0,
  typingSpeed = 1.5,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const entrance = spring({
    frame,
    fps,
    delay,
    config: { damping: 200 },
  });

  const charsPerFrame = typingSpeed;
  const typedFrame = Math.max(0, frame - delay - 5);
  const visibleChars = Math.min(
    Math.floor(typedFrame * charsPerFrame),
    code.length
  );
  const displayCode = code.slice(0, visibleChars);
  const showCursor = visibleChars < code.length && frame % 16 < 10;

  return (
    <div
      style={{
        opacity: entrance,
        transform: `translateY(${(1 - entrance) * 30}px)`,
        background: COLORS.codeBg,
        border: `1px solid ${COLORS.codeBorder}`,
        borderRadius: 20,
        padding: "36px 44px",
        fontFamily: FONT.mono,
        fontSize: 32,
        lineHeight: 1.65,
        color: COLORS.text,
        whiteSpace: "pre",
        overflow: "hidden",
        boxShadow: `0 0 60px rgba(88, 166, 255, 0.08)`,
      }}
    >
      {colorize(displayCode)}
      {showCursor && (
        <span style={{ color: COLORS.accent, fontWeight: "bold" }}>▎</span>
      )}
    </div>
  );
};

const colorize = (code: string) => {
  const tokens: { pattern: RegExp; color: string }[] = [
    { pattern: /#[^\n]*/g, color: COLORS.textMuted },
    { pattern: /("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g, color: COLORS.green },
    { pattern: /\b(from|import|with|as|return|def|class|if|else|for|in|and|or|not|None|True|False|try|except|raise|yield|async|await)\b/g, color: COLORS.purple },
    { pattern: /\b(GraphMemory|Node|Edge|QueryBuilder|NetworkX|DSPy)\b/g, color: COLORS.orange },
    { pattern: /\b(\d+\.?\d*)\b/g, color: COLORS.yellow },
    { pattern: /\b(insert_node|insert_edge|nearest_nodes|search_nodes|hybrid_search|retrieve|query|match|where|traverse|execute|pagerank|extract|bulk_insert_nodes|to_networkx|connected_components)\b/g, color: COLORS.accent },
  ];

  const parts: { text: string; color?: string; index: number }[] = [];
  const used = new Set<number>();

  for (const { pattern, color } of tokens) {
    const regex = new RegExp(pattern.source, pattern.flags);
    let m: RegExpExecArray | null;
    while ((m = regex.exec(code)) !== null) {
      let overlap = false;
      for (let i = m.index; i < m.index + m[0].length; i++) {
        if (used.has(i)) { overlap = true; break; }
      }
      if (!overlap) {
        parts.push({ text: m[0], color, index: m.index });
        for (let i = m.index; i < m.index + m[0].length; i++) used.add(i);
      }
    }
  }

  parts.sort((a, b) => a.index - b.index);

  const elements: React.ReactNode[] = [];
  let pos = 0;
  for (const part of parts) {
    if (part.index > pos) {
      elements.push(code.slice(pos, part.index));
    }
    elements.push(
      <span key={part.index} style={{ color: part.color }}>
        {part.text}
      </span>
    );
    pos = part.index + part.text.length;
  }
  if (pos < code.length) elements.push(code.slice(pos));

  return <>{elements}</>;
};
