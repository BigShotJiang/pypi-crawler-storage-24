import React from "react";
import { useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { COLORS, FONT } from "../theme";

type SectionTitleProps = {
  title: string;
  subtitle?: string;
  delay?: number;
  icon?: string;
};

export const SectionTitle: React.FC<SectionTitleProps> = ({
  title,
  subtitle,
  delay = 0,
  icon,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const titleEntrance = spring({
    frame,
    fps,
    delay,
    config: { damping: 200 },
  });

  const subtitleEntrance = spring({
    frame,
    fps,
    delay: delay + 8,
    config: { damping: 200 },
  });

  const lineWidth = interpolate(titleEntrance, [0, 1], [0, 160], {
    extrapolateRight: "clamp",
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
      <div
        style={{
          width: lineWidth,
          height: 3,
          background: `linear-gradient(90deg, transparent, ${COLORS.accent}, transparent)`,
          borderRadius: 2,
        }}
      />
      <div
        style={{
          opacity: titleEntrance,
          transform: `translateY(${(1 - titleEntrance) * 40}px)`,
          fontSize: 68,
          fontWeight: 800,
          fontFamily: FONT.sans,
          color: COLORS.text,
          letterSpacing: -1,
          textAlign: "center",
        }}
      >
        {icon && <span style={{ marginRight: 16 }}>{icon}</span>}
        {title}
      </div>
      {subtitle && (
        <div
          style={{
            opacity: subtitleEntrance,
            transform: `translateY(${(1 - subtitleEntrance) * 20}px)`,
            fontSize: 30,
            fontFamily: FONT.sans,
            color: COLORS.textMuted,
            textAlign: "center",
            maxWidth: 1000,
          }}
        >
          {subtitle}
        </div>
      )}
    </div>
  );
};
