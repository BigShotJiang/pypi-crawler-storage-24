import React from "react";
import { useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { COLORS } from "../theme";

type GraphNode = {
  id: string;
  label: string;
  x: number;
  y: number;
  type?: string;
  color?: string;
};

type GraphEdge = {
  from: string;
  to: string;
  label?: string;
};

type GraphVizProps = {
  nodes: GraphNode[];
  edges: GraphEdge[];
  delay?: number;
  width?: number;
  height?: number;
  highlightNodes?: string[];
  highlightEdges?: [string, string][];
  pulseNodes?: string[];
};

export const GraphViz: React.FC<GraphVizProps> = ({
  nodes,
  edges,
  delay = 0,
  width = 700,
  height = 500,
  highlightNodes = [],
  highlightEdges = [],
  pulseNodes = [],
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const nodeMap = new Map(nodes.map((n) => [n.id, n]));

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <defs>
        <filter id="glow">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <marker
          id="arrowhead"
          markerWidth="12"
          markerHeight="9"
          refX="34"
          refY="4.5"
          orient="auto"
        >
          <polygon points="0 0, 12 4.5, 0 9" fill={COLORS.edgeStroke} />
        </marker>
        <marker
          id="arrowhead-hl"
          markerWidth="12"
          markerHeight="9"
          refX="34"
          refY="4.5"
          orient="auto"
        >
          <polygon points="0 0, 12 4.5, 0 9" fill={COLORS.green} />
        </marker>
      </defs>

      {edges.map((edge, i) => {
        const from = nodeMap.get(edge.from);
        const to = nodeMap.get(edge.to);
        if (!from || !to) return null;

        const edgeEntrance = spring({
          frame,
          fps,
          delay: delay + (nodes.length + i) * 3,
          config: { damping: 200 },
        });

        const isHighlighted = highlightEdges.some(
          ([a, b]) => (a === edge.from && b === edge.to) || (a === edge.to && b === edge.from)
        );

        const midX = (from.x + to.x) / 2;
        const midY = (from.y + to.y) / 2 - 20;

        return (
          <g key={`e${i}`} opacity={edgeEntrance}>
            <line
              x1={from.x}
              y1={from.y}
              x2={from.x + (to.x - from.x) * edgeEntrance}
              y2={from.y + (to.y - from.y) * edgeEntrance}
              stroke={isHighlighted ? COLORS.green : COLORS.edgeStroke}
              strokeWidth={isHighlighted ? 4 : 3}
              strokeOpacity={isHighlighted ? 1 : 0.6}
              markerEnd={isHighlighted ? "url(#arrowhead-hl)" : "url(#arrowhead)"}
            />
            {edge.label && edgeEntrance > 0.8 && (
              <text
                x={midX}
                y={midY}
                textAnchor="middle"
                fill={COLORS.textMuted}
                fontSize={18}
                fontFamily="Inter, sans-serif"
              >
                {edge.label}
              </text>
            )}
          </g>
        );
      })}

      {nodes.map((node, i) => {
        const nodeEntrance = spring({
          frame,
          fps,
          delay: delay + i * 3,
          config: { damping: 200 },
        });

        const isHighlighted = highlightNodes.includes(node.id);
        const isPulsing = pulseNodes.includes(node.id);
        const pulseScale = isPulsing
          ? 1 + 0.08 * Math.sin((frame - delay) * 0.15)
          : 1;
        const nodeColor = node.color || COLORS.nodeFill;
        const r = 28;

        return (
          <g
            key={node.id}
            transform={`translate(${node.x}, ${node.y}) scale(${nodeEntrance * pulseScale})`}
            filter={isHighlighted ? "url(#glow)" : undefined}
          >
            <circle
              r={r}
              fill={nodeColor}
              stroke={isHighlighted ? COLORS.green : COLORS.nodeStroke}
              strokeWidth={isHighlighted ? 4 : 3}
              opacity={0.9}
            />
            <text
              textAnchor="middle"
              dy={6}
              fill="white"
              fontSize={16}
              fontWeight="bold"
              fontFamily="Inter, sans-serif"
            >
              {node.label}
            </text>
            {node.type && (
              <text
                textAnchor="middle"
                dy={-36}
                fill={COLORS.textMuted}
                fontSize={15}
                fontFamily="Inter, sans-serif"
              >
                {node.type}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
};
