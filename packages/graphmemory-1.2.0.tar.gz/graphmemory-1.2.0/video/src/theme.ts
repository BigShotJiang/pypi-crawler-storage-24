export const COLORS = {
  bg: "#0a0a0f",
  bgGradient1: "#0d1117",
  bgGradient2: "#161b22",
  accent: "#58a6ff",
  accentGlow: "#388bfd",
  green: "#3fb950",
  purple: "#bc8cff",
  orange: "#f0883e",
  pink: "#f778ba",
  yellow: "#d29922",
  red: "#f85149",
  text: "#e6edf3",
  textMuted: "#8b949e",
  codeBg: "#161b22",
  codeBorder: "#30363d",
  nodeFill: "#1f6feb",
  nodeStroke: "#58a6ff",
  edgeStroke: "#388bfd",
  gridLine: "#21262d",
} as const;

export const FONT = {
  mono: "'JetBrains Mono', 'Fira Code', monospace",
  sans: "'Inter', system-ui, sans-serif",
} as const;
