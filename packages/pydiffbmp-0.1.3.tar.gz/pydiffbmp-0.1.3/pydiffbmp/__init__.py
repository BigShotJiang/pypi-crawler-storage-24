"""
diffbmp: Differentiable Rendering with Bitmap Primitives

A differentiable rendering framework for image synthesis using arbitrary primitives
(SVG shapes, text glyphs, raster images) as "brushes" in a 2D splatting pipeline.

Key Features:
- GPU-accelerated tile-based rendering with CUDA
- Differentiable end-to-end pipeline
- Support for SVG, text, and raster primitives
- PSD/PDF export for designer workflows
- Structure-aware initialization
- High-level rendering API for diffusion model integration

Example (High-level API - Overlay/Watermark):
    >>> from pydiffbmp import DiffBMPRenderer
    >>> 
    >>> # Simple overlay rendering
    >>> renderer = DiffBMPRenderer(
    ...     overlay_path="logo.png",
    ...     canvas_size=(256, 256),
    ...     device='cuda'
    ... )
    >>> 
    >>> # Apply to image tensor (works in diffusion loops!)
    >>> output = renderer.apply(image_tensor, alpha=0.3)

Example (DiffBMPWrapper API - Generative Art):
    >>> from pydiffbmp import DiffBMPWrapper
    >>> 
    >>> # Create wrapper with parameters as member variables
    >>> wrapper = DiffBMPWrapper(device='cuda')
    >>> wrapper.load_primitive("heart.svg", size=128)
    >>> wrapper.initialize_params(n_primitives=100, canvas_size=(512, 512))
    >>> 
    >>> # Render with member variables
    >>> rendered = wrapper.render()
    >>> 
    >>> # Optimize parameters with gradients
    >>> loss = torch.nn.functional.mse_loss(rendered, target)
    >>> loss.backward()  # Gradients flow to wrapper.x, wrapper.y, etc.

Example (Low-level API):
    >>> from pydiffbmp import SimpleTileRenderer, PrimitiveLoader
    >>> 
    >>> # Load primitive
    >>> loader = PrimitiveLoader("circle.svg", output_width=256, device='cuda')
    >>> S = loader.load_alpha_bitmap()
    >>> 
    >>> # Initialize renderer
    >>> renderer = SimpleTileRenderer(
    ...     canvas_size=(512, 512),
    ...     S=S,
    ...     device='cuda'
    ... )
    >>> 
    >>> # Render from parameters
    >>> output = renderer.render_from_params(x, y, r, theta, v, c)
"""

__version__ = '0.1.0'
__author__ = 'Anonymous'

# Core renderer exports
from pydiffbmp.core.renderer.simple_tile_renderer import SimpleTileRenderer
from pydiffbmp.core.renderer.vector_renderer import VectorRenderer
from pydiffbmp.core.renderer.sequential_renderer import SequentialFrameRenderer

# Initializer exports
from pydiffbmp.core.initializer.svgsplat_initializater import StructureAwareInitializer
from pydiffbmp.core.initializer.random_initializater import RandomInitializer
from pydiffbmp.core.initializer.base_initializer import BaseInitializer
from pydiffbmp.core.initializer.designated_initializer import DesignatedInitializer

# Utility exports
from pydiffbmp.util.primitive_loader import PrimitiveLoader
from pydiffbmp.util.svg_loader import SVGLoader
from pydiffbmp.util.psd_exporter import PSDExporter
from pydiffbmp.util.pdf_exporter import PDFExporter
from pydiffbmp.util.loss_functions import LossComposer

# Preprocessing
from pydiffbmp.core.preprocessing import Preprocessor

# High-level API
from pydiffbmp.diffbmp_renderer import DiffBMPRenderer
from pydiffbmp.diffbmp_wrapper import DiffBMPWrapper

__all__ = [
    # Version
    '__version__',
    '__author__',
    
    # High-level API
    'DiffBMPRenderer',
    'DiffBMPWrapper',
    
    # Renderers
    'SimpleTileRenderer',
    'VectorRenderer',
    'SequentialFrameRenderer',
    
    # Initializers
    'StructureAwareInitializer',
    'RandomInitializer',
    'BaseInitializer',
    'DesignatedInitializer',
    
    # Loaders
    'PrimitiveLoader',
    'SVGLoader',
    
    # Exporters
    'PSDExporter',
    'PDFExporter',
    
    # Utilities
    'LossComposer',
    'Preprocessor',
]


def get_version():
    """Return the current version of diffbmp."""
    return __version__


def check_cuda_available():
    """Check if CUDA extensions are properly compiled and available."""
    try:
        import sys
        import os
        cuda_path = os.path.join(os.path.dirname(__file__), 'cuda_tile_rasterizer', 'cuda_tile_rasterizer')
        if cuda_path not in sys.path:
            sys.path.insert(0, cuda_path)
        from cuda_tile_rasterizer import TileRasterizer
        return True
    except ImportError:
        return False


# Print helpful message on import
def _print_welcome():
    import sys
    if 'pytest' not in sys.modules:  # Don't print during tests
        cuda_status = "✓ Available" if check_cuda_available() else "✗ Not compiled"
        print(f"diffbmp v{__version__} loaded")
        print(f"CUDA extensions: {cuda_status}")
        if not check_cuda_available():
            print("  → Build CUDA extensions: cd cuda_tile_rasterizer && python setup.py build_ext --inplace")

# Uncomment to show welcome message on import
# _print_welcome()
