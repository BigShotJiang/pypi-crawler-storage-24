# xtquant-rpc-client

Cross-platform Python client for remotely hosted `xtquant` domains.

Supported client platforms:

- macOS
- Linux
- Windows

Current scope:

- gRPC transport over protobuf
- token-based authentication
- `xtdata` synchronous read interface wrappers
- IDE-friendly `client.xtdata.*` type hints

Typical usage:

```python
from xtquant_rpc_client import configure_default_client, xtdata

configure_default_client(host="127.0.0.1", port=50051, token="your-token")
dates = xtdata.get_trading_dates("SH", count=5)
```

The client package is pure Python and does not depend on the Windows-only `xtquant` wheel.
Only the server package requires Windows.
