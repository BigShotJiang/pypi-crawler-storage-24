from .google_docs_json_loader import GoogleDocsJSONLoader as GoogleDocsJSONLoader

__all__ = ['GoogleDocsJSONLoader']
