from _typeshed import Incomplete
from gllm_docproc.loader.base_loader import BaseLoader as BaseLoader
from gllm_docproc.loader.loader_utils import create_base_element_metadata as create_base_element_metadata, trim_table_empty_cells as trim_table_empty_cells, validate_file_extension as validate_file_extension
from gllm_docproc.model.element import Element as Element, FOOTER as FOOTER, HEADER as HEADER, IMAGE as IMAGE, TABLE as TABLE, UNCATEGORIZED_TEXT as UNCATEGORIZED_TEXT
from gllm_docproc.model.element_metadata import ElementMetadata as ElementMetadata, GOOGLE_DOCS as GOOGLE_DOCS
from gllm_docproc.model.media import Media as Media, MediaSourceType as MediaSourceType, MediaType as MediaType
from typing import Any

logger: Incomplete

class GoogleDocsJSONLoader(BaseLoader):
    """Loader for Google Docs REST JSON exports.

    Extracts information from a Google Docs API JSON file to list Element.

    Structure assignment by this loader:
    1. Header section paragraphs → HEADER
    2. Footer section paragraphs → FOOTER
    3. Tables → TABLE
    4. Inline and positioned (floating) images → IMAGE (dedicated element per image)
    5. All other body paragraphs → UNCATEGORIZED_TEXT

    Multi-tab documents are fully supported.
    All tabs and nested child tabs are processed in order, with each element carrying a `tab_title` metadata field.
    """
    def load(self, source: str, loaded_elements: list[dict[str, Any]] | None = None, **kwargs: Any) -> list[dict[str, Any]]:
        """Load and extract content from a Google Docs JSON file.

        Args:
            source (str): Path to the Google Docs JSON file.
            loaded_elements (list[dict[str, Any]] | None, optional): Previously loaded elements
                to prepend. Defaults to None.
            **kwargs (Any): Additional keyword arguments.

        Kwargs:
            original_source (str, optional): The original source of the document.

        Returns:
            list[dict[str, Any]]: Extracted elements as a list of Element in dictionary format.
        """
