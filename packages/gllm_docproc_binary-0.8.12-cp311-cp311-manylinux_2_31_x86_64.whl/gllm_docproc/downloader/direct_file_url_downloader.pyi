from _typeshed import Incomplete
from gllm_core.utils.retry import RetryConfig
from gllm_docproc.downloader import BaseDownloader as BaseDownloader
from typing import Any

UNKNOWN_EXTENSION: str
FALLBACK_EXTENSION: str
TMP_EXTENSION: str
MIME_TYPE_TO_EXTENSION_MAP: Incomplete
NETWORK_RETRY_EXCEPTIONS: Incomplete
RETRYABLE_HTTP_STATUS_CODES: Incomplete
DEFAULT_MAX_RETRIES: int

class DirectFileURLDownloader(BaseDownloader):
    """A class for downloading files from a direct file URL to the defined output directory."""
    stream_buffer_size: Incomplete
    retry_config: Incomplete
    session: Incomplete
    logger: Incomplete
    def __init__(self, stream_buffer_size: int = 65536, retry_config: RetryConfig | dict[str, Any] | None = None, max_retries: int = ..., timeout: int | None = None) -> None:
        """Initialize the DirectFileURLDownloader.

        Args:
            stream_buffer_size (int, optional): The size of the buffer for streaming downloads in bytes.
                Defaults to 64KB (65536 bytes).
            retry_config (RetryConfig | dict[str, Any] | None, optional): Retry configuration. When a dict,
                it is validated into RetryConfig. When None, a default RetryConfig is built using
                max_retries and timeout. Defaults to None. Note: retry_on_exceptions cannot be
                customized; it is always NETWORK_RETRY_EXCEPTIONS.
            max_retries (int, optional): The maximum number of retries for failed downloads. Defaults to 3.
                Deprecated: Use retry_config instead.
            timeout (int | None, optional): The timeout for the download request in seconds. Defaults to None.
                Deprecated: Use retry_config instead.
        """
    def download(self, source: str, output: str, **kwargs: Any) -> list[str]:
        """Download source to the output directory.

        Args:
            source (str): The source to be downloaded.
            output (str): The output directory where the downloaded source will be saved.
            **kwargs (Any): Additional keyword arguments.

        kwargs:
            ca_certs_path (str, optional): The path to the CA certificates file. Defaults to None.
            extension (str, optional): The extension of the file to be downloaded. If not provided,
                the extension will be detected from the response headers or content mime type.

        Returns:
            list[str]: A list of file paths of successfully downloaded files.
        """
