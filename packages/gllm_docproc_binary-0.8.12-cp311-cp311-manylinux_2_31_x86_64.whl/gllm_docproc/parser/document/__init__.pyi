from .docx_parser import DOCXParser as DOCXParser
from .google_docs_json_parser import GoogleDocsJSONParser as GoogleDocsJSONParser
from .pdf_parser import PDFParser as PDFParser
from .pptx_parser import PPTXParser as PPTXParser
from .txt_parser import TXTParser as TXTParser
from .xlsx_parser import XLSXParser as XLSXParser

__all__ = ['DOCXParser', 'GoogleDocsJSONParser', 'PDFParser', 'PPTXParser', 'TXTParser', 'XLSXParser']
