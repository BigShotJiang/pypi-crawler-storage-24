from _typeshed import Incomplete
from gllm_docproc.data_generator.base_data_generator import BaseDataGenerator as BaseDataGenerator
from gllm_docproc.model.element import Element as Element
from gllm_docproc.model.media import MediaSourceType as MediaSourceType, MediaType as MediaType
from gllm_docproc.utils.async_utils import run_async_in_sync as run_async_in_sync
from typing import Any

DEFAULT_MODEL_ID: str
DEFAULT_SYSTEM_PROMPT: str
DEFAULT_USER_PROMPT: str
DEFAULT_MAX_CONCURRENT_REQUESTS: int

class LLMTextRewriteDataGenerator(BaseDataGenerator):
    """LLM-powered element text rewrite data generator with lazy initialization and batching.

    This generator rewrites the `text` field of document elements using an LLM while preserving element
    structure and metadata. It supports dynamic model selection, configuration-based processor caching,
    concurrent batch processing, and optional image context for multimodal models.

    Designed primarily for document normalization tasks such as OCR cleanup, formatting correction,
    and layout refinement.
    """
    model_api_keys: Incomplete
    logger: Incomplete
    default_model_id: Incomplete
    default_system_prompt: Incomplete
    default_user_prompt: Incomplete
    default_text_rewrite_enabled: Incomplete
    default_structures_to_rewrite: Incomplete
    default_hyperparameters: dict[str, Any]
    default_retry_config: dict[str, Any]
    default_include_media_images_as_context: Incomplete
    default_max_concurrent_requests: Incomplete
    def __init__(self, model_api_keys: dict[str, str] | None = None, default_model_id: str = ..., default_system_prompt: str = ..., default_user_prompt: str = ..., default_text_rewrite_enabled: bool = True, default_structures_to_rewrite: list[str] | None = None, default_hyperparameters: dict[str, Any] | None = None, default_retry_config: dict[str, Any] | None = None, default_include_media_images_as_context: bool = True, max_concurrent_requests: int = ...) -> None:
        """Initialize the LLMTextRewriteDataGenerator.

        Args:
            model_api_keys (dict[str, str] | None, optional): Dictionary mapping model IDs to their API keys.
                Defaults to None, in which case no API keys are passed during LMInvoker initialization.
            default_model_id (str, optional): Default model ID used when `model_id` is not provided to generate().
                Defaults to DEFAULT_MODEL_ID.
            default_system_prompt (str, optional): Default system prompt used when `system_prompt` is not provided
                to generate(). Defaults to DEFAULT_SYSTEM_PROMPT.
            default_user_prompt (str, optional): Default user prompt used when `user_prompt` is not provided
                to generate(). Defaults to DEFAULT_USER_PROMPT.
            default_text_rewrite_enabled (bool, optional): Default value for `text_rewrite_enabled` in generate().
                Defaults to True.
            default_structures_to_rewrite (list[str] | None, optional): Default value for `structures_to_rewrite`
                in generate(). If None, all structures are eligible for rewriting. Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters passed to the LMInvoker
                when `default_hyperparameters` is not provided in generate(). Defaults to None.
            default_retry_config (dict[str, Any] | None, optional): Default retry configuration passed to the
                LMInvoker when `retry_config` is not provided in generate(). Defaults to None.
            default_include_media_images_as_context (bool, optional): Default value for
                `include_media_images_as_context` in generate(). Defaults to True.
            max_concurrent_requests (int, optional): Default maximum number of concurrent LLM requests per
                generate() call when `max_concurrent_requests` is not provided to generate().
                Defaults to DEFAULT_MAX_CONCURRENT_REQUESTS.

        Raises:
            ValueError: If max_concurrent_requests is less than 1.
        """
    def generate(self, elements: list[dict[str, Any]], **kwargs: Any) -> list[dict[str, Any]]:
        """Rewrite element.text for elements matching structures_to_rewrite using an LLM.

        Args:
            elements (list[dict[str, Any]]): List of dictionaries containing elements to be processed.
            **kwargs (Any): Additional keyword arguments for the LLM text rewrite process.

        Kwargs:
            text_rewrite_enabled (bool, optional): Whether to enable LLM text rewriting. Defaults to True
                or the value configured in __init__.
            structures_to_rewrite (list[str], optional): List of element structure types whose `text`
                field should be rewritten. Elements with structures not in this list are passed through unchanged.
                Defaults to the value configured in __init__ (applies rewriting to all structures if None).
            model_id (str, optional): The ID of the model to use for text rewriting. Defaults to DEFAULT_MODEL_ID
                or the value configured in __init__.
            system_prompt (str, optional): The system prompt to use for text rewriting.
                Defaults to DEFAULT_SYSTEM_PROMPT or the value configured in __init__.
            user_prompt (str, optional): The user prompt template for text rewriting. Must contain a {text} placeholder.
                Defaults to DEFAULT_USER_PROMPT or the value configured in __init__.
            default_hyperparameters (dict[str, Any], optional): Additional hyperparameters passed to the LMInvoker
                configuration. Defaults to {} or the value configured in __init__.
            retry_config (dict[str, Any], optional): Retry configuration passed to the LMInvoker. Defaults to {}
                or the value configured in __init__.
            include_media_images_as_context (bool, optional): Whether to attach associated media images
                from element.metadata.media as visual context when invoking the LLM. Defaults to True or the
                value configured in __init__.
            max_concurrent_requests (int, optional): Maximum number of LLM requests in flight at once for this
                generate() call. Defaults to the value configured in __init__.

        Returns:
            list[dict[str, Any]]: List of dictionaries with text rewritten for matching elements.
                Non-matching elements are returned unchanged.

        Raises:
            ValueError: If max_concurrent_requests is less than 1.
        """
