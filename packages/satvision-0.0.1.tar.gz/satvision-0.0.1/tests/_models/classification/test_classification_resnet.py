#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from pathlib import Path

import numpy as np
import pytest
import torch
from PIL import Image
from torch.nn import InstanceNorm2d

from satvis._models.classification.resnet.config import (
    IN1KResNet18ClassificationInferenceConfig,
    IN1KResNet34ClassificationInferenceConfig,
    IN1KResNet50ClassificationInferenceConfig,
    IN1KResNet101ClassificationInferenceConfig,
    IN1KResNet152ClassificationInferenceConfig,
)
from satvis._models.classification.resnet.inference_model import (
    ResNetClassificationInferenceModel,
)


@pytest.fixture
def device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    elif torch.backends.mps.is_available():
        return torch.device("mps")
    else:
        return torch.device("cpu")


class TestResNetClassificationInferenceModel:
    @pytest.mark.parametrize(
        "config_class",
        [
            IN1KResNet18ClassificationInferenceConfig,
            IN1KResNet34ClassificationInferenceConfig,
            IN1KResNet50ClassificationInferenceConfig,
            IN1KResNet101ClassificationInferenceConfig,
            IN1KResNet152ClassificationInferenceConfig,
        ],
    )
    def test_from_config(self, config_class: type) -> None:
        config = config_class()
        model = ResNetClassificationInferenceModel.from_config(config=config)
        assert model is not None

    def test_from_config__custom_torchvision_kwargs(self) -> None:
        config = IN1KResNet18ClassificationInferenceConfig()
        add_model_args = {
            "torchvision_resnet_kwargs": {"norm_layer": InstanceNorm2d},
            "weights": None,
        }
        config.update_fields(args={"model_args": add_model_args})
        model = ResNetClassificationInferenceModel.from_config(config=config)
        # Check that the norm layer has been updated.
        norm_layer = model.model.layer1[0].bn1  # type: ignore[attr-defined]
        assert isinstance(norm_layer, InstanceNorm2d)
        assert model is not None

    def test_forward(self) -> None:
        config = IN1KResNet18ClassificationInferenceConfig()
        model = ResNetClassificationInferenceModel.from_config(config=config)
        batch = torch.randn(1, 3, 64, 64)
        with torch.no_grad():
            logits = model.forward(images=batch)
        assert logits.shape == (1, 1000)

    def test_predict__with_batched_torch_tensor(self, device: torch.device) -> None:
        config = IN1KResNet18ClassificationInferenceConfig()
        model = ResNetClassificationInferenceModel.from_config(config=config)
        image = torch.randn(1, 3, 224, 224)
        result = model.predict(image=image, device=device, apply_transform=False)
        assert isinstance(result, list)
        assert len(result) == 1

    def test_predict__with_single_torch_tensor(self, device: torch.device) -> None:
        config = IN1KResNet18ClassificationInferenceConfig()
        model = ResNetClassificationInferenceModel.from_config(config=config)
        image = torch.randn(3, 224, 224)
        result = model.predict(image=image, device=device, apply_transform=True)
        assert isinstance(result, dict)
        assert len(result) == 1000

    def test_predict__with_numpy_array(self, device: torch.device) -> None:
        config = IN1KResNet18ClassificationInferenceConfig()
        model = ResNetClassificationInferenceModel.from_config(config=config)
        image = np.random.rand(224, 224, 3).astype(np.float64)
        result = model.predict(image=image, device=device, apply_transform=True)
        assert isinstance(result, dict)
        assert len(result) == 1000

    def test_predict__with_image_path(
        self, device: torch.device, tmp_path: Path
    ) -> None:
        config = IN1KResNet18ClassificationInferenceConfig()
        model = ResNetClassificationInferenceModel.from_config(config=config)

        image_array = (np.random.rand(224, 224, 3) * 255).astype(np.uint8)
        image_path = tmp_path / "test_image.png"

        Image.fromarray(image_array).save(image_path)

        result = model.predict(image=image_path, device=device, apply_transform=True)
        assert isinstance(result, dict)
        assert len(result) == 1000

    @pytest.mark.requires_onnx
    def test_export_onnx(self, tmp_path: Path) -> None:
        config = IN1KResNet18ClassificationInferenceConfig()
        model = ResNetClassificationInferenceModel.from_config(config=config)

        output_path = tmp_path / "model.onnx"
        model.export_onnx(
            output_path=output_path,
        )
        assert output_path.exists()

    @pytest.mark.requires_tensorrt
    @pytest.mark.requires_cuda
    def test_export_tensorrt(self, tmp_path: Path) -> None:
        config = IN1KResNet18ClassificationInferenceConfig()
        model = ResNetClassificationInferenceModel.from_config(config=config)

        output_path = tmp_path / "model.plan"
        model.export_tensorrt(
            output_path=output_path,
            min_batch_size=1,
            max_batch_size=4,
            onnx_opset_version=17,
            onnx_use_torch_dynamo=False,
            fp16=False,
        )
        assert output_path.exists()
