#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import torch

from satvis._models.classification._dummy_model.config import (
    DummyClassificationInferenceModelConfig,
    DummyClassificationModelArgs,
)
from satvis._models.classification._dummy_model.inference_model import (
    DummyClassificationInferenceModel,
)


class TestDummyClassificationInferenceModel:
    def test_from_config(self) -> None:
        config = DummyClassificationInferenceModelConfig()
        model = DummyClassificationInferenceModel.from_config(config=config)
        assert model is not None

    def test_forward(self) -> None:
        model = DummyClassificationInferenceModel.from_config(
            config=DummyClassificationInferenceModelConfig(
                model_args=DummyClassificationModelArgs(
                    out_dim=5,
                    class_mapping={i: f"class_{i}" for i in range(5)},
                )
            )
        )
        batch = torch.randn(2, 3, 224, 224)
        logits = model.forward(images=batch)
        assert logits.shape == (2, 5)
