#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from pathlib import Path

import pytest
import torch
import numpy as np
import scipy.io

from satvis._data import pyarrow_schemas
from satvis._data.classification_dataset import (
    DummyClassificationDataset,
    ImageNetDataset,
)
from satvis._env import Env


def _imagenet_meta() -> tuple[dict[str, int], dict[int, str]]:
    meta_file = (
        Env.SATVIS_DATASETS_DIR.value
        / "imagenet"
        / "devkit"
        / "ILSVRC2012_devkit_t12"
        / "data"
        / "meta.mat"
    )
    meta = scipy.io.loadmat(meta_file, squeeze_me=True, struct_as_record=False)
    synsets = np.atleast_1d(meta["synsets"])
    leaf_synsets = [synset for synset in synsets if synset.num_children == 0]
    sorted_wnids = sorted(str(synset.WNID) for synset in leaf_synsets)
    wnid_to_idx = {wnid: idx for idx, wnid in enumerate(sorted_wnids)}
    ilsvrc_id_to_wnid = {
        int(synset.ILSVRC2012_ID): str(synset.WNID) for synset in leaf_synsets
    }
    return wnid_to_idx, ilsvrc_id_to_wnid


class TestClassificationDataset:
    def test_classification_dummy_dataset(self) -> None:
        dataset = DummyClassificationDataset(num_samples=10, num_classes=5)

        length = len(dataset)
        assert length == 10

        sample = dataset[0]
        assert sample["image"].shape[0] == 3
        assert sample["image"].ndim == 3
        assert sample["label"].dtype == torch.int64

    def test_evaluate_predictions_from_file(self, tmp_path: Path) -> None:
        dataset = DummyClassificationDataset(num_samples=10, num_classes=5)

        # Create dummy predictions
        logits = torch.randn(10, 5)

        # Save predictions to a temporary file
        import pyarrow as pa
        import pyarrow.parquet as pq
        from pyarrow import Table

        table = Table.from_pydict(
            {
                "sample_id": [f"sample_{i}" for i in range(10)],
                "logits": pa.array(logits.numpy().tolist()),
            },
            schema=pyarrow_schemas.classification_predictions_schema(num_classes=5),
        )

        predictions_path = tmp_path / "predictions.parquet"
        pq.write_table(table, predictions_path)

        # Evaluate predictions
        accuracy = dataset.evaluate_predictions(predictions_path)
        assert 0.0 <= accuracy <= 1.0


class TestImageNetDataset:
    @pytest.mark.require_self_hosted_ci
    def test_imagenet_dataset_val_split_real_data(self) -> None:
        dataset = ImageNetDataset(split="val")

        length = len(dataset)
        assert length > 0

        sample = dataset[0]
        assert sample["image"].shape[0] == 3
        assert sample["image"].ndim == 3
        assert sample["label"].dtype == torch.int64

    @pytest.mark.require_self_hosted_ci
    def test_imagenet_dataset_val_split__class_ids_match_reference(self) -> None:
        wnid_to_idx, ilsvrc_id_to_wnid = _imagenet_meta()

        dataset = ImageNetDataset(split="val")
        manifest = dataset.manifest
        class_ids = manifest.column("class_id").to_pylist()

        devkit_root = (
            Env.SATVIS_DATASETS_DIR.value
            / "imagenet"
            / "devkit"
            / "ILSVRC2012_devkit_t12"
        )
        ground_truth_file = (
            devkit_root / "data" / "ILSVRC2012_validation_ground_truth.txt"
        )
        with ground_truth_file.open("r", encoding="utf-8") as handle:
            val_ground_truth = [int(line.strip()) for line in handle if line.strip()]

        expected_class_ids = [
            wnid_to_idx[ilsvrc_id_to_wnid[label]] for label in val_ground_truth
        ]

        assert class_ids == expected_class_ids

    @pytest.mark.require_self_hosted_ci
    def test_imagenet_dataset_train_split__class_ids_match_reference(self) -> None:
        wnid_to_idx, _ = _imagenet_meta()

        dataset = ImageNetDataset(split="train")
        manifest = dataset.manifest

        seen_wnids: set[str] = set()
        for batch in manifest.to_batches():
            sample_ids = batch.column("sample_id").to_pylist()
            class_ids = batch.column("class_id").to_pylist()
            for sample_id, class_id in zip(sample_ids, class_ids):
                wnid, _ = sample_id.split("_", 1)
                expected = wnid_to_idx[wnid]
                assert class_id == expected
                if wnid not in seen_wnids:
                    seen_wnids.add(wnid)
                    if len(seen_wnids) >= 100:
                        return

        pytest.fail("Did not observe expected number of unique WNIDs in manifest")
