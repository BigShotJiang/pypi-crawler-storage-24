#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from pathlib import Path

import pytest
from beartype.roar import (
    BeartypeCallHintParamViolation,
    BeartypeCallHintReturnViolation,
)
from jaxtyping import TypeCheckError

from satvis._decorators import no_type_check, typecheck


def test_typechecked__validates_correct_types() -> None:
    @typecheck
    def add_numbers(a: int, b: int) -> int:
        return a + b

    result = add_numbers(a=5, b=3)

    assert result == 8


def test_typechecked__raises_error_for_wrong_input_type() -> None:
    @typecheck
    def process_string(text: str) -> str:
        return text.upper()

    with pytest.raises((BeartypeCallHintParamViolation, TypeCheckError)):
        process_string(text=123)  # type: ignore[arg-type]


def test_typechecked__raises_error_for_wrong_return_type() -> None:
    @typecheck
    def get_number() -> int:
        return "not a number"  # type: ignore[return-value]

    with pytest.raises((BeartypeCallHintReturnViolation, TypeCheckError)):
        get_number()


def test_typechecked__handles_union_types() -> None:
    @typecheck
    def process_path(path: str | Path) -> str:
        return str(path)

    result1 = process_path(path="test.txt")
    result2 = process_path(path=Path("test.txt"))

    assert result1 == "test.txt"
    assert result2 == "test.txt"


def test_typechecked__raises_error_for_union_type_mismatch() -> None:
    @typecheck
    def process_value(value: str | int) -> str:
        return str(value)

    with pytest.raises((BeartypeCallHintParamViolation, TypeCheckError)):
        process_value(value=[1, 2, 3])  # type: ignore[arg-type]


def test_typechecked__validates_with_defaults() -> None:
    @typecheck
    def greet(name: str, greeting: str = "Hello") -> str:
        return f"{greeting}, {name}!"

    result = greet(name="World")

    assert result == "Hello, World!"


def test_no_type_check_decorator() -> None:
    """Test that no_type_check temporarily disables type checking."""

    @typecheck
    def strict_function(x: int) -> int:
        return x

    @no_type_check
    @typecheck
    def relaxed_function(x: int) -> int:  # type: ignore[no-untyped-def]
        return x

    # Test that strict function raises error with invalid input
    with pytest.raises((BeartypeCallHintParamViolation, TypeCheckError)):
        strict_function("not an int")  # type: ignore[arg-type]

    # Test that relaxed function doesn't raise error (type checking disabled)
    result = relaxed_function("not an int")
    assert result == "not an int"

    # Test that type checking is re-enabled after leaving no_type_check context
    with pytest.raises((BeartypeCallHintParamViolation, TypeCheckError)):
        strict_function("not an int")  # type: ignore[arg-type]
