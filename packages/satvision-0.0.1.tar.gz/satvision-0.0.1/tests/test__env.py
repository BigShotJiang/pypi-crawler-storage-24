#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import os
from unittest.mock import patch

import pytest

from satvis._env import EnvVariable


class TestEnvVariable:
    def test_default_value_when_env_not_set(self) -> None:
        env_var = EnvVariable(name="TEST_VAR", default_value="default", converter=str)

        if "TEST_VAR" in os.environ:
            del os.environ["TEST_VAR"]

        assert env_var.value == "default"

    def test_env_value_when_set(self) -> None:
        env_var = EnvVariable(name="TEST_VAR", default_value="default", converter=str)

        os.environ["TEST_VAR"] = "environment_value"
        try:
            assert env_var.value == "environment_value"
        finally:
            del os.environ["TEST_VAR"]

    def test_int_converter(self) -> None:
        env_var = EnvVariable(name="TEST_INT", default_value="42", converter=int)

        if "TEST_INT" in os.environ:
            del os.environ["TEST_INT"]
        assert env_var.value == 42

        os.environ["TEST_INT"] = "123"
        try:
            assert env_var.value == 123
        finally:
            del os.environ["TEST_INT"]

    def test_float_converter(self) -> None:
        env_var = EnvVariable(name="TEST_FLOAT", default_value="3.14", converter=float)

        os.environ["TEST_FLOAT"] = "2.71"
        try:
            assert env_var.value == 2.71
        finally:
            del os.environ["TEST_FLOAT"]

    def test_invalid_conversion_raises_error(self) -> None:
        env_var = EnvVariable(name="TEST_INVALID", default_value="42", converter=int)

        os.environ["TEST_INVALID"] = "not_a_number"
        try:
            with pytest.raises(ValueError):
                _ = env_var.value
        finally:
            del os.environ["TEST_INVALID"]

    def test_setter_updates_environment(self) -> None:
        env_var = EnvVariable(
            name="TEST_SETTER", default_value="default", converter=str
        )

        env_var.value = "new_value"

        assert os.environ["TEST_SETTER"] == "new_value"
        assert env_var.value == "new_value"

        del os.environ["TEST_SETTER"]

    def test_setter_with_non_string_type(self) -> None:
        env_var = EnvVariable(name="TEST_INT_SETTER", default_value="0", converter=int)

        env_var.value = 456

        assert os.environ["TEST_INT_SETTER"] == "456"
        assert env_var.value == 456

        del os.environ["TEST_INT_SETTER"]

    def test_multiple_accesses_consistent(self) -> None:
        env_var = EnvVariable(
            name="TEST_CONSISTENT", default_value="default", converter=str
        )

        os.environ["TEST_CONSISTENT"] = "consistent_value"
        try:
            value1 = env_var.value
            value2 = env_var.value
            assert value1 == value2 == "consistent_value"
        finally:
            del os.environ["TEST_CONSISTENT"]


class TestEdgeCases:
    def test_empty_string_environment_variable(self) -> None:
        env_var = EnvVariable(name="TEST_EMPTY", default_value="default", converter=str)

        os.environ["TEST_EMPTY"] = ""
        try:
            assert env_var.value == ""
        finally:
            del os.environ["TEST_EMPTY"]

    def test_whitespace_environment_variable(self) -> None:
        env_var = EnvVariable(
            name="TEST_WHITESPACE", default_value="default", converter=str
        )

        os.environ["TEST_WHITESPACE"] = "  spaces  "
        try:
            assert env_var.value == "  spaces  "
        finally:
            del os.environ["TEST_WHITESPACE"]

    def test_boolean_like_strings__demonstrates_limitation(self) -> None:
        bool_env = EnvVariable(name="TEST_BOOL", default_value="True", converter=bool)

        os.environ["TEST_BOOL"] = "false"
        try:
            assert bool_env.value is True
        finally:
            del os.environ["TEST_BOOL"]

        os.environ["TEST_BOOL"] = ""
        try:
            assert bool_env.value is False
        finally:
            del os.environ["TEST_BOOL"]

    def test_custom_converter_function(self) -> None:
        def list_converter(value: str) -> list[str]:
            return value.split(",") if value else []

        env_var = EnvVariable(
            name="TEST_LIST", default_value="a,b,c", converter=list_converter
        )

        if "TEST_LIST" in os.environ:
            del os.environ["TEST_LIST"]
        assert env_var.value == ["a", "b", "c"]

        os.environ["TEST_LIST"] = "x,y,z"
        try:
            assert env_var.value == ["x", "y", "z"]
        finally:
            del os.environ["TEST_LIST"]

    @patch.dict(os.environ, {}, clear=True)
    def test_with_clean_environment(self) -> None:
        env_var = EnvVariable(
            name="CLEAN_TEST", default_value="clean_default", converter=str
        )

        assert env_var.value == "clean_default"
