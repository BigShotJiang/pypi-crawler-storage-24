#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import pytest
import torch
from pytest import Config, Item

from satvis._dependency import ONNX_AVAILABLE, TENSORRT_AVAILABLE
from satvis._env import Env


def pytest_configure(config: Config) -> None:
    """Configure pytest with automatic skipping for optional dependencies."""
    config.addinivalue_line(
        "markers",
        "requires_cuda: marks tests requiring CUDA (skipped if CUDA not available)",
    )
    config.addinivalue_line(
        "markers",
        "requires_onnx: marks tests requiring onnx package (skipped if not installed)",
    )
    config.addinivalue_line(
        "markers",
        "requires_tensorrt: marks tests requiring tensorrt package (skipped if not installed)",
    )
    config.addinivalue_line(
        "markers",
        "require_self_hosted_ci: marks tests that should run only on self-hosted CI",
    )


def pytest_collection_modifyitems(config: Config, items: list[Item]) -> None:
    """Automatically skip tests based on markers and availability."""
    # Check CUDA availability
    cuda_available = torch.cuda.is_available()

    # Apply skip markers
    for item in items:
        if "requires_cuda" in item.keywords and not cuda_available:
            item.add_marker(pytest.mark.skip(reason="CUDA not available"))
        if "requires_onnx" in item.keywords and not ONNX_AVAILABLE:
            item.add_marker(pytest.mark.skip(reason="onnx package not installed"))
        if "requires_tensorrt" in item.keywords and not TENSORRT_AVAILABLE:
            item.add_marker(pytest.mark.skip(reason="tensorrt package not installed"))
        if "require_self_hosted_ci" in item.keywords and not Env._SELF_HOSTED_CI.value:
            item.add_marker(pytest.mark.skip(reason="SELF_HOSTED_CI not enabled"))
