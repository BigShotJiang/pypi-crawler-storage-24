#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import pyarrow as pa


def classification_manifest_schema() -> pa.Schema:
    return pa.schema(
        [
            # Stable identifier used to join with predictions
            pa.field("sample_id", pa.string(), nullable=False),
            # Where to load the image from
            pa.field("image_path", pa.string(), nullable=False),
            # Ground-truth label (e.g., 0..C-1)
            pa.field("class_id", pa.int32(), nullable=False),
            # Optional but commonly useful
            pa.field(
                "split", pa.dictionary(pa.int8(), pa.string()), nullable=True
            ),  # e.g., "train"/"val"
        ]
    )


def classification_predictions_schema(num_classes: int) -> pa.Schema:
    return pa.schema(
        [
            # Must match manifest.sample_id exactly
            pa.field("sample_id", pa.string(), nullable=False),
            # Raw model outputs for all classes (logits recommended; probs optional)
            pa.field("logits", pa.list_(pa.float32(), num_classes), nullable=False),
            # Optional metadata for provenance
            # pa.field("model_id", pa.string(), nullable=True),     # e.g., git sha / run id
            # pa.field("checkpoint", pa.string(), nullable=True),   # e.g., "epoch=12-step=48000"
        ]
    )
