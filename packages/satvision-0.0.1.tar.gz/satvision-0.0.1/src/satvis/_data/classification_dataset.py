#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import warnings
from abc import ABC, abstractmethod
from itertools import chain
from pathlib import Path
from typing import Literal

import numpy as np
import PIL.Image
import polars as pl
import pyarrow as pa
import pyarrow.parquet as pq
import scipy.io
import torch
from pyarrow import Table
from torch.utils.data import Dataset
from torchvision.transforms.v2 import CenterCrop, Compose, Resize

import satvis._file_helpers as satvis_fh
from satvis._data import pyarrow_schemas
from satvis._env import Env
from satvis._types import PathLike, TorchClassificationSample

IMAGENET_DIR: Path = Env.SATVIS_DATASETS_DIR.value / "imagenet"

IMAGENET_VAL_URL = "https://image-net.org/data/ILSVRC/2012/ILSVRC2012_img_val.tar"
IMAGENET_TRAIN_URL = "https://image-net.org/data/ILSVRC/2012/ILSVRC2012_img_train.tar"
IMAGENET_DEVKIT_URL = (
    "https://image-net.org/data/ILSVRC/2012/ILSVRC2012_devkit_t12.tar.gz"
)
warnings.warn(
    "Distribution of ImageNet links is not permitted. Remove before publishing."
)


class ClassificationDataset(Dataset, ABC):
    @abstractmethod
    def __getitem__(self, index: int) -> TorchClassificationSample: ...

    @abstractmethod
    def __len__(self) -> int: ...

    @abstractmethod
    def __str__(self) -> str:
        """Return a single-word name identifying the dataset."""
        ...

    @property
    @abstractmethod
    def manifest(self) -> Table: ...

    def evaluate_predictions(
        self,
        predictions: PathLike | Table,
        eval_method: Literal["simple"] = "simple",
    ):
        """Evaluate classification predictions against ground truth.

        Args:
            predictions: Path to parquet file or in-memory Table containing
                predictions conforming to the classification_predictions_schema.
        """
        # Read predictions as mmapped table if a path is given.
        if isinstance(predictions, (str, Path)):
            predictions_table = pq.read_table(predictions, memory_map=True)
        else:
            predictions_table = predictions

        if eval_method == "simple":
            # Load into Polars, join on sample_id, compute accuracy.
            manifest_df = pl.from_arrow(self.manifest)
            predictions_df = pl.from_arrow(predictions_table)
            joined_df = manifest_df.join(
                predictions_df,
                left_on="sample_id",
                right_on="sample_id",
                how="inner",
            )
            # Compute predicted class as argmax of logits.
            joined_df = joined_df.with_columns(
                pl.col("logits").arr.arg_max().alias("predicted_class_id")
            )
            # Compute accuracy.
            correct_predictions = joined_df.filter(
                pl.col("class_id") == pl.col("predicted_class_id")
            ).height
            total_predictions = joined_df.height
            accuracy = correct_predictions / total_predictions
            return accuracy
        else:
            raise ValueError(f"Unsupported eval_method '{eval_method}'.")


class DummyClassificationDataset(ClassificationDataset):
    def __init__(self, num_samples: int = 10, num_classes: int = 5) -> None:
        sample_ids = [f"sample_{i}" for i in range(num_samples)]
        image_paths = [f"/path/to/image_{i:05d}.jpg" for i in range(num_samples)]
        class_ids = [i % num_classes for i in range(num_samples)]
        splits = ["train"] * num_samples

        table = Table.from_pydict(
            {
                "sample_id": sample_ids,
                "image_path": image_paths,
                "class_id": class_ids,
                "split": splits,
            },
            schema=pyarrow_schemas.classification_manifest_schema(),
        )

        self._manifest = table
        self.image_paths = self._manifest["image_path"]
        self.labels = self._manifest["class_id"]

    def __str__(self) -> str:
        return "dummy-classification-dataset"

    @property
    def manifest(self) -> Table:
        return self._manifest

    def __getitem__(self, index: int) -> TorchClassificationSample:
        # Return dummy data
        image_tensor = torch.zeros((3, 224, 224), dtype=torch.float32)
        label = self.labels[index].as_py()
        return {
            "image": image_tensor,
            "label": torch.tensor(label, dtype=torch.int64),
        }

    def __len__(self) -> int:
        return len(self.manifest)


class ImageNetDataset(ClassificationDataset):
    def __init__(
        self,
        *,
        split: Literal["train", "val"],
    ) -> None:
        if split not in {"train", "val"}:
            raise ValueError(f"Unsupported split '{split}'.")

        devkit_archive = IMAGENET_DIR / "ILSVRC2012_devkit_t12.tar.gz"
        devkit_dir = IMAGENET_DIR / "devkit"
        satvis_fh.maybe_download_file(
            url=IMAGENET_DEVKIT_URL,
            dest_path=devkit_archive,
        )
        satvis_fh.maybe_extract_archive(
            archive_path=devkit_archive,
            extract_to=devkit_dir,
        )
        devkit_root = devkit_dir / "ILSVRC2012_devkit_t12"
        meta_file = devkit_root / "data" / "meta.mat"

        if split == "val":
            val_archive = IMAGENET_DIR / "ILSVRC2012_img_val.tar"
            val_dir = IMAGENET_DIR / "val"
            satvis_fh.maybe_download_file(
                url=IMAGENET_VAL_URL,
                dest_path=val_archive,
            )
            satvis_fh.maybe_extract_archive(
                archive_path=val_archive,
                extract_to=val_dir,
            )
        else:
            train_archive = IMAGENET_DIR / "ILSVRC2012_img_train.tar"
            train_dir = IMAGENET_DIR / "train"
            satvis_fh.maybe_download_file(
                url=IMAGENET_TRAIN_URL,
                dest_path=train_archive,
            )
            satvis_fh.maybe_extract_archive(
                archive_path=train_archive,
                extract_to=train_dir,
            )

        manifest_path = (
            Env.SATVIS_MMAP_DATASETS_DIR.value / f"manifest_imagenet_{split}.parquet"
        )

        if not manifest_path.exists():
            manifest_path.parent.mkdir(parents=True, exist_ok=True)
            meta = scipy.io.loadmat(meta_file, squeeze_me=True, struct_as_record=False)
            if "synsets" not in meta:
                raise KeyError("synsets missing in meta.mat")
            synsets = np.atleast_1d(meta["synsets"])

            # Logic adapted from torchvision.datasets.ImageNet
            valid_synsets = [s for s in synsets if s.num_children == 0]
            valid_wnids: list[str] = [str(s.WNID) for s in valid_synsets]
            sorted_wnids = sorted(valid_wnids)
            wnid_to_class_id: dict[str, int] = {
                wnid: i for i, wnid in enumerate(sorted_wnids)
            }
            ilsvrc_id_to_wnid: dict[int, str] = {
                int(s.ILSVRC2012_ID): str(s.WNID) for s in valid_synsets
            }

            if split == "val":
                ground_truth_file = (
                    devkit_root / "data" / "ILSVRC2012_validation_ground_truth.txt"
                )
                if not ground_truth_file.exists():
                    raise FileNotFoundError(
                        "Validation ground truth file missing; expected in devkit."
                    )
                with ground_truth_file.open("r", encoding="utf-8") as handle:
                    val_ground_truth = [
                        int(line.strip()) for line in handle if line.strip()
                    ]

                val_dir = IMAGENET_DIR / "val"
                image_paths = sorted(
                    str(path.absolute()) for path in val_dir.glob("*.JPEG")
                )
                if len(image_paths) != len(val_ground_truth):
                    raise RuntimeError(
                        f"Mismatch between number of images ({len(image_paths)}) "
                        f"and ground truth entries ({len(val_ground_truth)})."
                    )

                class_ids: list[int] = []
                for label in val_ground_truth:
                    wnid = ilsvrc_id_to_wnid[label]
                    class_ids.append(wnid_to_class_id[wnid])

                sample_ids = [Path(path).stem for path in image_paths]
            else:
                train_dir = IMAGENET_DIR / "train"
                for wnid_archive in sorted(train_dir.glob("*.tar")):
                    wnid = wnid_archive.stem
                    wnid_dir = train_dir / wnid
                    satvis_fh.maybe_extract_archive(
                        archive_path=wnid_archive,
                        extract_to=wnid_dir,
                    )

                image_paths: list[str] = []
                class_ids: list[int] = []
                sample_ids: list[str] = []

                for wnid_dir in sorted(
                    path for path in train_dir.iterdir() if path.is_dir()
                ):
                    wnid = wnid_dir.name
                    if wnid not in wnid_to_class_id:
                        raise KeyError(f"WNID '{wnid}' not found in metadata.")
                    class_id = wnid_to_class_id[wnid]
                    image_files = sorted(
                        chain(wnid_dir.glob("*.JPEG"), wnid_dir.glob("*.jpg")),
                        key=lambda path: path.name,
                    )
                    for image_path in image_files:
                        image_str = str(image_path.absolute())
                        image_paths.append(image_str)
                        class_ids.append(class_id)
                        sample_ids.append(f"{wnid}_{image_path.stem}")

                if not image_paths:
                    raise RuntimeError("No training images found after extraction.")

            splits = [split] * len(sample_ids)

            table = pa.Table.from_pydict(
                {
                    "sample_id": sample_ids,
                    "image_path": image_paths,
                    "class_id": class_ids,
                    "split": splits,
                },
                schema=pyarrow_schemas.classification_manifest_schema(),
            )

            pq.write_table(table, manifest_path)

        # Lazy load using memory map
        self._manifest = pq.read_table(manifest_path, memory_map=True)
        self.sample_ids = self._manifest["sample_id"]
        self.image_paths = self._manifest["image_path"]
        self.labels = self._manifest["class_id"]

    def __str__(self) -> str:
        return "imagenet-dataset"

    @property
    def manifest(self) -> Table:
        return self._manifest

    def __getitem__(self, index: int) -> TorchClassificationSample:
        transform = Compose(
            [
                Resize(256),
                CenterCrop((224, 224)),
            ]
        )

        image_path = self.image_paths[index].as_py()
        label = self.labels[index].as_py()

        # Load image
        from satvis._models.inference_helpers import image_as_tensor

        image_tensor = image_as_tensor(image=image_path)  # (1, C, H, W)

        image_tensor = transform(image_tensor)

        return {
            "sample_id": self.sample_ids[index].as_py(),
            "image": image_tensor.squeeze(0),  # (C, H, W)
            "label": torch.tensor(label, dtype=torch.int64),
        }

    def __len__(self) -> int:
        return len(self.manifest)
