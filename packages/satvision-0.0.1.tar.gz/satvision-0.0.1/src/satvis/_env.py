#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Generic, TypeVar

_T = TypeVar("_T")


def bool_converter(value: str) -> bool:
    true_values = {"1", "true", "yes", "on"}
    false_values = {"0", "false", "no", "off"}
    value_lower = value.lower()
    if value_lower in true_values:
        return True
    elif value_lower in false_values:
        return False
    else:
        raise ValueError(f"Cannot convert '{value}' to bool.")


@dataclass
class EnvVariable(Generic[_T]):
    name: str
    default_value: str | Callable[[], str]
    converter: Callable[[str], _T]

    @property
    def value(self) -> _T:
        if callable(self.default_value):
            str_val = os.getenv(self.name, self.default_value())
        else:
            str_val = os.getenv(self.name, self.default_value)
        env_value = self.converter(str_val)
        return env_value

    @value.setter
    def value(self, new_value: _T) -> None:
        os.environ[self.name] = str(new_value)


class Env:
    SATVIS_MODEL_CACHE_DIR = EnvVariable(
        name="SATVIS_MODEL_CACHE_DIR",
        default_value=str(Path.home() / ".cache" / "satvis" / "models"),
        converter=Path,
    )
    """Directory where downloaded models are cached."""

    SATVIS_DATASETS_DIR = EnvVariable(
        name="SATVIS_DATASETS_DIR",
        default_value=str(Path.home() / ".cache" / "satvis" / "datasets"),
        converter=Path,
    )
    """Raw datasets storage. May be slow (e.g., network drive)."""

    SATVIS_MMAP_DATASETS_DIR = EnvVariable(
        name="SATVIS_MMAP_DATASETS_DIR",
        default_value=str(Path.home() / ".cache" / "satvis" / "mmap_datasets"),
        converter=Path,
    )
    """Memory-mapped datasets storage. Should be on fast local storage."""

    MASTER_ADDR = EnvVariable(
        name="MASTER_ADDR",
        default_value="localhost",
        converter=str,
    )
    """Master address for distributed training."""

    MASTER_PORT = EnvVariable(
        name="MASTER_PORT",
        default_value="12355",
        converter=str,
    )
    """Master port for distributed training."""

    _SELF_HOSTED_CI = EnvVariable(
        name="SELF_HOSTED_CI",
        default_value="0",
        converter=bool_converter,
    )
    """Flag to indicate if tests are running in a self-hosted CI environment with access
    to local datasets and other cached resources.
    """

    _GITHUB_CI = EnvVariable(
        name="GITHUB_CI",
        default_value="0",
        converter=bool_converter,
    )
    """Flag to indicate if tests are running in GitHub CI environment."""
