#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import tarfile
from pathlib import Path

import torch


def maybe_download_file(url: str, dest_path: Path, force: bool = False) -> None:
    """Downloads a file from a URL to a destination path."""
    if not dest_path.parent.exists():
        dest_path.parent.mkdir(parents=True, exist_ok=True)
    if dest_path.exists() and not force:
        return
    torch.hub.download_url_to_file(url, str(dest_path))


def maybe_extract_archive(
    archive_path: Path, extract_to: Path, cleanup: bool = False, force: bool = False
) -> None:
    """Extracts a tar.gz archive to a specified directory."""
    if extract_to.exists() and any(extract_to.iterdir()) and not force:
        return
    if archive_path.suffix == ".tar":
        with tarfile.open(archive_path, "r") as tar:
            tar.extractall(path=extract_to)
    elif archive_path.suffixes == [".tar", ".gz"]:
        with tarfile.open(archive_path, "r:gz") as tar:
            tar.extractall(path=extract_to)
    else:
        raise ValueError(f"Unsupported archive format: {archive_path.suffixes}")
    if cleanup:
        archive_path.unlink()
