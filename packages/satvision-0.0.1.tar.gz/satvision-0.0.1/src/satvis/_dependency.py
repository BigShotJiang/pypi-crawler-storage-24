#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from lightning_utilities.core.imports import RequirementCache

TORCH_DYNAMO_AVAILABLE = bool(RequirementCache("torch>=2.6.0"))
TENSORRT_AVAILABLE = bool(RequirementCache("tensorrt"))
ONNX_AVAILABLE = bool(RequirementCache("onnx"))
TRANSFORMERS_AVAILABLE = bool(RequirementCache("transformers"))
