#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from satvis._types import ModelNameComponents


def parse_model_name(model_name: str) -> ModelNameComponents:
    """Parse model into components.

    Args:
        model_name: Model name string in the format 'framework::model'.
    """
    framework, model = model_name.split("::")
    return ModelNameComponents(framework=framework, model=model)
