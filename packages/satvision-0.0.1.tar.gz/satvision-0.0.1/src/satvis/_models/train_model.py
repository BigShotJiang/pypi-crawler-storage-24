#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Sequence, final

from torch.nn import Module
from torch.optim import Optimizer

from satvis._models.inference_model import InferenceModel, InferenceModelConfig


@dataclass
class OptimizerConfig:
    optimizers: Sequence[Optimizer]


class TrainModel(Module, ABC):
    @final
    def __init__(
        self,
        *,
        inference_model_cls: type[InferenceModel],
        inference_model_config: InferenceModelConfig,
    ) -> None:
        super().__init__()
        self._post_init(
            inference_model_cls=inference_model_cls,
            inference_model_config=inference_model_config,
        )

    @abstractmethod
    def _post_init(
        self,
        *,
        inference_model_cls: type[InferenceModel],
        inference_model_config: InferenceModelConfig,
    ) -> None: ...

    @abstractmethod
    def configure_optimizers(self) -> OptimizerConfig: ...
