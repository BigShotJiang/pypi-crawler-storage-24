#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import logging
import tempfile
import warnings
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, ClassVar, Literal, Self, final

import torch
from PIL.Image import Image as PILImage
from torch.nn import Module
from torch.types import Device

from satvis._dependency import TENSORRT_AVAILABLE, TORCH_DYNAMO_AVAILABLE
from satvis._models.export_helpers import (
    ONNXModelSpec,
)
from satvis._pydantic import SatVisBaseModel
from satvis._transforms.val_transform import (
    ValTransform,
    ValTransformArgs,
)
from satvis._types import (
    NumpyRGBImage,
    PathLike,
    TorchRGBImage,
    TorchRGBImageBatch,
    PrecisionType,
)

logger = logging.getLogger(__name__)


class ModelArgs(SatVisBaseModel):
    weights: str | Path | None


class InferenceModelConfig(SatVisBaseModel):
    """Fully JSON-serializable configuration for an inference model."""

    model_variant: str
    model_args: ModelArgs | None
    val_transform_args: ValTransformArgs
    onnx_model_spec: ONNXModelSpec


class InferenceModel(Module, ABC):
    """Abstract base class for inference models."""

    onnx_model_spec_cls: ClassVar[type[ONNXModelSpec]]

    @final
    def __init__(
        self,
        *,
        model_variant: str,
        model_args: ModelArgs | None,
        val_transform_args: ValTransformArgs,
    ) -> None:
        super().__init__()
        self._post_init(
            model_variant=model_variant,
            model_args=model_args,
            val_transform_args=val_transform_args,
        )
        self.eval()

    @abstractmethod
    def _post_init(
        self,
        *,
        model_variant: str,
        model_args: ModelArgs | None,
        val_transform_args: ValTransformArgs,
    ) -> None: ...

    @classmethod
    @abstractmethod
    def from_config(
        cls,
        config: InferenceModelConfig,
    ) -> Self: ...

    @property
    def device(self) -> Device:
        return next(self.parameters()).device

    @property
    @abstractmethod
    def val_transform(self) -> ValTransform: ...

    @abstractmethod
    def predict(
        self,
        *,
        image: PathLike | PILImage | NumpyRGBImage | TorchRGBImageBatch | TorchRGBImage,
        device: Device | Literal["auto"],
        apply_transform: bool,
        precision: PrecisionType | None = None,
    ) -> Any:
        """Predict the class probabilities for a single image or a batch of images.

        Args:
            image: A single image or a batch of images. Float tensors or arrays are
                expected to be normalized to the [0, 1] range.
            text: A single text string or a batch of text strings.
            device: The device to perform inference on.
            apply_transform: Whether to apply the validation transform to the input images.

        Returns:
            Processed prediction results.
        """
        ...

    def export_onnx(
        self,
        *,
        output_path: PathLike,
        input_dynamic_axes: dict[str, dict[int, str]] | None = None,
        output_dynamic_axes: dict[str, dict[int, str]] | None = None,
        opset_version: int | None = None,
        use_torch_dynamo: bool | Literal["auto"] = "auto",
        verbose: bool = False,
    ) -> None:
        """Export the model to ONNX format.

        Args:
            output_path: Path to save the exported ONNX model to.
            input_dynamic_axes: Optional dictionary specifying dynamic axes for input
                tensors. This will override the dynamic axes specified in the model config.
            output_dynamic_axes: Optional dictionary specifying dynamic axes for output
                tensors. This will override the dynamic axes specified in the model config.
                This is not needed for generating the ONNX file, but can be used for
                automatic generation of dynamic axes information for e.g. protobuf export.
            opset_version: ONNX opset version to use. If None, uses PyTorch's default.
            use_torch_dynamo: Whether to use TorchDynamo for optimization. 'auto' enables
                it if available.
            verbose: Whether to print verbose output during export.
        """
        # Get onnx model spec and override dynamic axes if provided.
        onnx_spec = self.onnx_model_spec_cls()  # type: ignore[call-arg]
        onnx_spec.update_dynamic_axes(
            input_dynamic_axes=input_dynamic_axes,
            output_dynamic_axes=output_dynamic_axes,
        )
        onnx_spec.revalidate()

        if use_torch_dynamo == "auto" and not TORCH_DYNAMO_AVAILABLE:
            msg = (
                "TorchDynamo is not available. Proceeding without it. To enable "
                "TorchDynamo, please install torch>=2.6.0."
            )
            logger.warning(msg)
            use_torch_dynamo_final = False

        elif use_torch_dynamo == "auto":
            use_torch_dynamo_final = TORCH_DYNAMO_AVAILABLE
            logger.debug("Using TorchDynamo exporter.")

        else:
            use_torch_dynamo_final = use_torch_dynamo

        input_names = tuple(elem[0] for elem in onnx_spec.inputs)
        input_tensors = tuple(elem[1].example_tensor() for elem in onnx_spec.inputs)
        output_names = tuple(elem[0] for elem in onnx_spec.outputs)

        # Build dynamic shapes/axes dictionary
        dynamic_info = onnx_spec.get_dynamic_axes_dict(
            include_outputs=not use_torch_dynamo_final
        )

        # Use dynamic_shapes for dynamo (inputs only), dynamic_axes for traditional export (inputs + outputs)
        if use_torch_dynamo is False:
            # Suppress deprecation warning when explicitly choosing legacy export
            with warnings.catch_warnings():
                warnings.filterwarnings(
                    "ignore",
                    message="You are using the legacy TorchScript-based ONNX export",
                    category=DeprecationWarning,
                )
                torch.onnx.export(
                    model=self,
                    args=input_tensors,
                    f=output_path,
                    verbose=verbose,
                    input_names=input_names,
                    output_names=output_names,
                    opset_version=opset_version,
                    dynamic_shapes=dynamic_info
                    if use_torch_dynamo_final and dynamic_info
                    else None,
                    dynamic_axes=dynamic_info
                    if not use_torch_dynamo_final and dynamic_info
                    else None,
                    dynamo=use_torch_dynamo_final,
                    optimize=True,
                    verify=True,
                )
        else:
            # Don't suppress warning for auto mode or explicit True
            torch.onnx.export(
                model=self,
                args=input_tensors,
                f=output_path,
                verbose=verbose,
                input_names=input_names,
                output_names=output_names,
                opset_version=opset_version,
                dynamic_shapes=dynamic_info
                if use_torch_dynamo_final and dynamic_info
                else None,
                dynamic_axes=dynamic_info
                if not use_torch_dynamo_final and dynamic_info
                else None,
                dynamo=use_torch_dynamo_final,
                optimize=True,
                verify=True,
            )

    def export_tensorrt(
        self,
        *,
        output_path: PathLike,
        min_batch_size: int = 1,
        max_batch_size: int = 1,
        onnx_opset_version: int | None = None,
        onnx_use_torch_dynamo: bool
        | Literal["auto"] = False,  # TensorRT+Dynamo is not yet supported.
        verbose: bool = False,
        fp16: bool = False,
    ) -> None:
        """Export the model to TensorRT format.

        Args:
            output_path: Path to save the exported TensorRT engine to.
            min_batch_size: Minimum batch size for optimization profile.
            max_batch_size: Maximum batch size for optimization profile.
            onnx_opset_version: ONNX opset version to use for intermediate conversion.
            onnx_use_torch_dynamo: Whether to use TorchDynamo for ONNX export.
            verbose: Whether to print verbose output during conversion.
            fp16: Whether to use FP16 precision for the TensorRT engine.
        """
        if TENSORRT_AVAILABLE:
            from tensorrt import (
                Builder,
                BuilderFlag,
                NetworkDefinitionCreationFlag,
                OnnxParser,
            )
            from tensorrt import (
                Logger as TRTLogger,
            )
        else:
            raise ImportError(
                "TensorRT is not available. Install the TensorRT extra as follows: "
                "`pip install satvis[tensorrt-cu12]`."
            )

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_onnx_path = Path(temp_dir) / "model.onnx"

            # Suppress warning about torchscript based ONNX exporter.
            # TODO (Lionel/2025-10): Remove this once TorchDynamo is supported.
            with warnings.catch_warnings():
                warnings.filterwarnings(
                    "ignore",
                    message="You are using the legacy TorchScript-based ONNX export.",
                )
                # Export to ONNX first
                self.export_onnx(
                    output_path=temp_onnx_path,
                    opset_version=onnx_opset_version,
                    use_torch_dynamo=onnx_use_torch_dynamo,
                    verbose=verbose,
                )

            # Check if external data file exists and copy it to temp directory
            data_file = temp_onnx_path.with_suffix(".onnx.data")
            if data_file.exists():
                # The external data file is already in the same directory as the ONNX file
                pass

            # Convert ONNX to TensorRT
            trt_logger = TRTLogger(TRTLogger.VERBOSE if verbose else TRTLogger.WARNING)
            builder = Builder(trt_logger)
            network = builder.create_network(
                1 << int(NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
            )
            parser = OnnxParser(network, trt_logger)

            # Parse ONNX model
            with open(temp_onnx_path, "rb") as f:
                if not parser.parse(f.read()):
                    for error in range(parser.num_errors):
                        trt_logger.log(TRTLogger.ERROR, str(parser.get_error(error)))
                    raise RuntimeError("Failed to parse ONNX model")

            # Configure builder
            config = builder.create_builder_config()
            if fp16:
                config.set_flag(BuilderFlag.FP16)

            # Create optimization profile for dynamic shapes
            onnx_spec = self.onnx_model_spec_cls()  # type: ignore[call-arg]
            profile = builder.create_optimization_profile()

            for input_name, tensor_spec in onnx_spec.inputs:
                input_idx = None
                for i in range(network.num_inputs):
                    if network.get_input(i).name == input_name:
                        input_idx = i
                        break

                if input_idx is None:
                    continue

                input_tensor = network.get_input(input_idx)
                shape = input_tensor.shape

                if tensor_spec.dynamic_axes is not None:
                    # Create min, opt, and max shapes for dynamic dimensions
                    min_shape = []
                    opt_shape = []
                    max_shape = []

                    for dim_idx, dim_size in enumerate(shape):
                        if dim_idx in tensor_spec.dynamic_axes:
                            # This dimension is dynamic (typically batch dimension at index 0)
                            min_shape.append(min_batch_size)
                            opt_shape.append(
                                (min_batch_size + max_batch_size) // 2
                            )  # Use average as optimal
                            max_shape.append(max_batch_size)
                        else:
                            # Static dimension - get actual size from tensor spec
                            # since TensorRT shows -1 for dynamic dims in the parsed network
                            static_size = tensor_spec.shape[dim_idx]
                            min_shape.append(static_size)
                            opt_shape.append(static_size)
                            max_shape.append(static_size)

                    profile.set_shape(input_name, min_shape, opt_shape, max_shape)

            config.add_optimization_profile(profile)

            # Build engine
            engine = builder.build_serialized_network(network, config)
            if engine is None:
                raise RuntimeError("Failed to build TensorRT engine")

            # Save engine to file
            with open(output_path, "wb") as f:
                f.write(engine)

            if verbose:
                trt_logger.log(
                    TRTLogger.INFO, f"TensorRT engine saved to {output_path}"
                )
