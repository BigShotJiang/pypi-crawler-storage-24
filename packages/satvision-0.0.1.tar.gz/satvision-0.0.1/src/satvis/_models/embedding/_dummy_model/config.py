#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from pathlib import Path

from pydantic import Field

from satvis._models.embedding._dummy_model.transform import (
    DummyEmbeddingValTransformArgs,
)
from satvis._models.embedding.embedding_inference_model import (
    EmbeddingInferenceModelConfig,
    EmbeddingModelArgs,
)
from satvis._transforms.val_transform import ValTransformArgs


class DummyEmbeddingModelArgs(EmbeddingModelArgs):
    weights: str | Path | None = None
    embedding_dim: int = 128
    random_projection: bool = False
    seed: int = 42
    in_dim: int = 3


class DummyEmbeddingInferenceModelConfig(EmbeddingInferenceModelConfig):
    model_variant: str = "default"
    model_args: DummyEmbeddingModelArgs = Field(default_factory=DummyEmbeddingModelArgs)
    val_transform_args: ValTransformArgs = Field(
        default_factory=DummyEmbeddingValTransformArgs
    )
