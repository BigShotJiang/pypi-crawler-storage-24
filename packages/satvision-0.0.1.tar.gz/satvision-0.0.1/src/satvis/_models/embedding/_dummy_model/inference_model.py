#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#

from typing import Self

import einops
import torch
from torch.nn import AdaptiveAvgPool2d, Conv2d, Linear

from satvis._models.embedding._dummy_model.config import (
    DummyEmbeddingInferenceModelConfig,
    DummyEmbeddingModelArgs,
)
from satvis._models.embedding.embedding_inference_model import EmbeddingInferenceModel
from satvis._models.inference_model import InferenceModelConfig, ModelArgs
from satvis._transforms.val_transform import ValTransform, ValTransformArgs
from satvis._types import (
    TextBatch,
    TorchEmbeddingBatch,
    TorchRGBImageBatch,
)


class DummyEmbeddingInferenceModel(EmbeddingInferenceModel):
    def _post_init(
        self,
        *,
        model_variant: str,
        model_args: ModelArgs | None,
        val_transform_args: ValTransformArgs,
    ) -> None:
        if not model_variant == "default":
            raise ValueError(
                f"Unknown model variant: {model_variant}, expected 'default'."
            )

        if not isinstance(model_args, DummyEmbeddingModelArgs):
            raise TypeError(
                "model_args must be an instance of DummyEmbeddingModelArgs or None."
            )

        self._underlying_embedding_dim = model_args.embedding_dim
        self._embedding_dim = model_args.embedding_dim

        self._val_transform = ValTransform(transform_args=val_transform_args)

        self.image_conv = Conv2d(3, model_args.embedding_dim, kernel_size=3)
        self.image_pool = AdaptiveAvgPool2d((1, 1))

        # Simple text encoder: just a linear projection for demonstration
        # In reality, this would be a text encoder
        self.text_linear = Linear(
            10, model_args.embedding_dim
        )  # Dummy text dimension of 10

    @classmethod
    def from_config(cls, config: InferenceModelConfig) -> Self:
        if not isinstance(config, DummyEmbeddingInferenceModelConfig):
            raise TypeError(
                "Expected config to be of type "
                "DummyEmbeddingInferenceModelConfig, got "
                f"{type(config)}."
            )
        return cls(
            val_transform_args=config.val_transform_args,
            model_variant=config.model_variant,
            model_args=config.model_args,
        )

    def forward(
        self, images: TorchRGBImageBatch | None = None, text: TextBatch | None = None
    ) -> TorchEmbeddingBatch:
        if images is not None and text is not None:
            raise ValueError("Only one of images or text should be provided.")
        if text is not None:
            return self.forward_original_text_embedding(text=text)
        elif images is not None:
            return self.forward_original_image_embedding(images=images)
        else:
            raise ValueError("Either images or text must be provided.")

    @property
    def _original_embedding_dim(self) -> int:
        return self._underlying_embedding_dim

    @property
    def embedding_dim(self) -> int:
        return self._embedding_dim

    @property
    def val_transform(self) -> ValTransform:
        return self._val_transform

    def forward_original_image_embedding(
        self, images: TorchRGBImageBatch
    ) -> TorchEmbeddingBatch:
        features = self.image_conv(images)
        pooled = self.image_pool(features)
        embeddings: TorchEmbeddingBatch = einops.rearrange(pooled, "b c 1 1 -> b c")
        return embeddings

    def forward_original_text_embedding(self, text: TextBatch) -> TorchEmbeddingBatch:
        batch_size = len(text)
        dummy_text_features = torch.randn(batch_size, 10)
        embeddings: TorchEmbeddingBatch = self.text_linear(dummy_text_features)
        return embeddings
