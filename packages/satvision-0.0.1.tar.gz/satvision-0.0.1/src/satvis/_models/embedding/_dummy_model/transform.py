#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#

from pydantic import Field

from satvis._transforms.transform_base import NormalizeArgs
from satvis._transforms.val_transform import ValTransformArgs


class DummyEmbeddingNormalizeArgs(NormalizeArgs):
    mean: tuple[float, float, float] = (0.5, 0.5, 0.5)
    std: tuple[float, float, float] = (0.5, 0.5, 0.5)


class DummyEmbeddingValTransformArgs(ValTransformArgs):
    normalize_args: NormalizeArgs = Field(default_factory=DummyEmbeddingNormalizeArgs)
