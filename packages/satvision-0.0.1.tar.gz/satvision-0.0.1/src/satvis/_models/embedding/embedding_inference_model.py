#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from abc import ABC, abstractmethod
from typing import Literal

from PIL.Image import Image as PILImage
from torch.types import Device

from satvis._models.inference_helpers import image_as_tensor
from satvis._models.inference_model import (
    InferenceModel,
    InferenceModelConfig,
    ModelArgs,
)
from satvis._types import (
    NumpyRGBImage,
    PathLike,
    TextBatch,
    TorchEmbedding,
    TorchEmbeddingBatch,
    TorchImageAttentionMaskBatch,
    TorchImageShapesBatch,
    TorchRGBImage,
    TorchRGBImageBatch,
)


class EmbeddingModelArgs(ModelArgs):
    embedding_dim: int | None
    random_projection: bool
    seed: int


class EmbeddingInferenceModelConfig(InferenceModelConfig):
    pass


class EmbeddingInferenceModel(InferenceModel, ABC):
    @property
    @abstractmethod
    def embedding_dim(self) -> int: ...


class ImageEmbeddingInferenceModel(EmbeddingInferenceModel, ABC):
    @abstractmethod
    def forward(
        self,
        images: TorchRGBImageBatch,
        attention_mask: TorchImageAttentionMaskBatch,
        images_shapes: TorchImageShapesBatch,
    ) -> TorchEmbeddingBatch:
        """Forward pass to compute the original embeddings.

        Args:
            images: A batch of RGB images as a tensor of shape (B, 3, H, W).

        Returns:
            A tensor of shape (B, E) containing the embeddings for each image,
            where E is the embedding dimension.
        """
        ...

    def predict(
        self,
        image: PathLike | PILImage | NumpyRGBImage | TorchRGBImageBatch | TorchRGBImage,
        device: Device | Literal["auto"] = "auto",
        apply_transform: bool = True,
        precision: Literal["32-true", "bf16-mixed", "16-mixed"] = "32-true",
    ) -> TorchEmbedding | TorchEmbeddingBatch:
        """Predict embeddings for a single image or a batch of images.

        Args:
            image: A single image or a batch of images. Float tensors or arrays are
                expected to be normalized to the [0, 1] range.
            device: Device to run inference on.

        Returns:
            A tensor of shape (B, D) or (D,) containing the embeddings,
            where D is the embedding dimension.
        """
        self = self.to(device)

        image_: TorchRGBImageBatch = image_as_tensor(image=image).to(self.device)
        if apply_transform:
            image_ = self.val_transform(image_)
        embeddings: TorchEmbeddingBatch = self(images=image_).cpu()

        if embeddings.shape[0] == 1:
            assert isinstance(embeddings[0], TorchEmbedding)
            return embeddings[0]
        else:
            assert isinstance(embeddings, TorchEmbeddingBatch)
            return embeddings


class MultimodalEmbeddingInferenceModel(EmbeddingInferenceModel, ABC):
    @abstractmethod
    def forward_image_embedding(
        self, images: TorchRGBImageBatch
    ) -> TorchEmbeddingBatch:
        """Forward pass to compute the original embeddings.

        Args:
            images: A batch of RGB images as a tensor of shape (B, 3, H, W).

        Returns:
            A tensor of shape (B, E) containing the embeddings for each image,
            where E is the embedding dimension.
        """
        ...

    @abstractmethod
    def forward_text_embedding(self, text: TextBatch) -> TorchEmbeddingBatch:
        """Forward pass to compute the original text embeddings.

        Args:
            text: A batch of text strings.

        Returns:
            A tensor of shape (B, E) containing the embeddings for each text,
            where E is the embedding dimension.
        """
        ...

    @abstractmethod
    def forward(
        self, images: TorchRGBImageBatch | None, text: TextBatch | None
    ) -> TorchEmbeddingBatch: ...

    def predict(
        self,
        *,
        image: PathLike | PILImage | NumpyRGBImage | TorchRGBImageBatch | TorchRGBImage,
        device: Device | Literal["auto"] = "auto",
        apply_transform: bool = True,
        precision: Literal["32-true", "bf16-mixed", "16-mixed"] = "32-true",
    ) -> TorchEmbedding | TorchEmbeddingBatch:
        raise NotImplementedError(
            "MultimodalEmbeddingInferenceModel does not support the "
            "`predict` method yet. Please use `forward_image_embedding` or "
            "`forward_text_embedding` instead."
        )

    # def predict(
    #     self,
    #     *,
    #     image: PathLike
    #     | NumpyRGBImage
    #     | TorchRGBImageBatch
    #     | TorchRGBImage
    #     | None = None,
    #     text: str | TextBatch | None = None,
    #     device: Device | Literal["auto"] = "auto",
    #     apply_transform: bool = True,
    # ) -> TorchEmbedding | TorchEmbeddingBatch:
    #     """Predict embeddings for a single image/text or a batch of images/text.

    #     Args:
    #         image: A single image or a batch of images. Float tensors or arrays are
    #             expected to be normalized to the [0, 1] range.
    #         text: A single text string or a list of text strings.
    #         device: Device to run inference on.

    #     Returns:
    #         A tensor of shape (B, D) or (D,) containing the embeddings,
    #         where D is the embedding dimension.
    #     """
    #     if image is None and text is None:
    #         raise ValueError("Either `image` or `text` must be provided.")

    #     if image is not None and text is not None:
    #         raise NotImplementedError(
    #             "Simultaneous image and text input is not yet supported for "
    #             "EmbeddingInferenceModel."
    #         )

    #     self = self.to(device)

    #     if image is not None:
    #         image_: TorchRGBImageBatch = image_as_tensor(image=image).to(self.device)
    #         if apply_transform:
    #             image_ = self.val_transform(image_)
    #         embeddings: TorchEmbeddingBatch = self(images=image_, text=None).cpu()
    #     else:
    #         assert text is not None
    #         text_: TextBatch = [text] if isinstance(text, str) else text
    #         embeddings = self(images=None, text=text_).cpu()

    #     if embeddings.shape[0] == 1:
    #         assert isinstance(embeddings[0], TorchEmbedding)
    #         return embeddings[0]
    #     else:
    #         assert isinstance(embeddings, TorchEmbeddingBatch)
    #         return embeddings
