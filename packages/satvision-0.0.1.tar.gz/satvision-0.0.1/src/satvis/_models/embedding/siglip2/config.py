#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from pathlib import Path
from typing import Literal

from pydantic import Field

from satvis._models.embedding.embedding_inference_model import (
    EmbeddingInferenceModelConfig,
    EmbeddingModelArgs,
)
from satvis._models.embedding.siglip2.transform import SigLip2TransformArgs
from satvis._pydantic import SatVisBaseModel

_SIGLIP2_MODELS = Literal[
    "google/siglip2-base-patch16-224",
    "google/siglip2-base-patch16-256",
    "google/siglip2-base-patch16-384",
    "google/siglip2-base-patch16-512",
    "google/siglip2-base-patch32-256",
    "google/siglip2-large-patch16-256",
    "google/siglip2-large-patch16-384",
    "google/siglip2-large-patch16-512",
    "google/siglip2-giant-opt-patch16-256",
    "google/siglip2-giant-opt-patch16-384",
    "google/siglip2-so400m-patch14-224",
    "google/siglip2-so400m-patch14-384",
    "google/siglip2-so400m-patch16-256",
    "google/siglip2-so400m-patch16-384",
    "google/siglip2-so400m-patch16-512",
    # NaFlex variants with dynamic resolution support.
    "google/siglip2-base-path16-naflex",
    "google/siglip2-so400m-patch16-naflex",
]


class TransformersSigLip2Kwargs(SatVisBaseModel):
    attn_implementation: str = "sdpa"  # Use torch's scaled dot-product attention.


class SigLip2EmbeddingModelArgs(EmbeddingModelArgs):
    weights: Path | None = None
    embedding_dim: int = 512
    random_projection: bool = False
    seed: int = 42
    transformers_from_pretrained_kwargs: TransformersSigLip2Kwargs = Field(
        default_factory=TransformersSigLip2Kwargs
    )


class SigLip2EmbeddingInferenceModelConfig(EmbeddingInferenceModelConfig):
    model_variant: _SIGLIP2_MODELS
    model_args: SigLip2EmbeddingModelArgs | None = Field(
        default_factory=SigLip2EmbeddingModelArgs
    )
    val_transform_args: SigLip2TransformArgs = Field(
        default_factory=SigLip2TransformArgs
    )
