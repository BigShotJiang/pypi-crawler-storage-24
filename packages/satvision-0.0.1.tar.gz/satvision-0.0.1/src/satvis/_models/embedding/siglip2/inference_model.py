#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import typing
from typing import Self

from satvis._dependency import TRANSFORMERS_AVAILABLE
from satvis._models.embedding.embedding_inference_model import (
    EmbeddingInferenceModel,
)
from satvis._models.embedding.siglip2.config import (
    _SIGLIP2_MODELS,
    SigLip2EmbeddingInferenceModelConfig,
    SigLip2EmbeddingModelArgs,
)
from satvis._models.inference_model import InferenceModelConfig, ModelArgs
from satvis._transforms.val_transform import ValTransform, ValTransformArgs

if not TRANSFORMERS_AVAILABLE:
    raise ImportError(
        "transformers package is required to use SigLip2EmbeddingInferenceModel. "
        "Please install SatVis with the 'transformers' extra as follows: "
        "`pip install satvis[transformers]`."
    )
else:
    from transformers import SiglipModel


class SigLip2EmbeddingInferenceModel(EmbeddingInferenceModel):
    def _post_init(
        self,
        *,
        model_variant: str,
        model_args: ModelArgs | None,
        val_transform_args: ValTransformArgs,
    ) -> None:
        if model_variant not in typing.get_args(_SIGLIP2_MODELS):
            raise ValueError(
                f"Unknown model variant: {model_variant}, expected one of "
                f"{typing.get_args(_SIGLIP2_MODELS)}."
            )
        if not isinstance(model_args, SigLip2EmbeddingModelArgs):
            raise TypeError(
                f"Expected model_args to be of type SigLip2EmbeddingModelArgs, got "
                f"{type(model_args)}."
            )
        self.model = SiglipModel.from_pretrained(
            model_variant, **model_args.transformers_from_pretrained_kwargs.model_dump()
        )

        self._val_transform = ValTransform(transform_args=val_transform_args)

    @property
    def val_transform(self) -> ValTransform:
        return self._val_transform

    @classmethod
    def from_config(
        cls: type[Self],
        config: InferenceModelConfig,
    ) -> Self:
        if not isinstance(config, SigLip2EmbeddingInferenceModelConfig):
            raise TypeError(
                "Expected config to be of type "
                "SigLip2EmbeddingInferenceModelConfig, got "
                f"{type(config)}."
            )
        return cls(
            val_transform_args=config.val_transform_args,
            model_variant=config.model_variant,
            model_args=config.model_args,
        )
