#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#


from pydantic import Field

from satvis._num_constants import IMAGENET_NORMALIZE_MEAN, IMAGENET_NORMALIZE_STD
from satvis._transforms.transform_base import NormalizeArgs
from satvis._transforms.val_transform import ValTransformArgs


class SigLip2NormalizeArgs(NormalizeArgs):
    """ImageNet normalization for SigLip2 models."""

    mean: tuple[float, float, float] = IMAGENET_NORMALIZE_MEAN
    std: tuple[float, float, float] = IMAGENET_NORMALIZE_STD


class SigLip2TransformArgs(ValTransformArgs):
    """Validation transform arguments for SigLip2 models."""

    normalize_args: SigLip2NormalizeArgs = Field(default_factory=SigLip2NormalizeArgs)
