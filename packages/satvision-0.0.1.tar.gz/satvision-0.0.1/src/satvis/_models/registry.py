#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#

from satvis._models.classification._dummy_model.config import (
    DummyClassificationInferenceModelConfig,
)
from satvis._models.classification._dummy_model.inference_model import (
    DummyClassificationInferenceModel,
)
from satvis._models.classification.resnet.config import (
    IN1KResNet18ClassificationInferenceConfig,
    IN1KResNet34ClassificationInferenceConfig,
    IN1KResNet50ClassificationInferenceConfig,
    IN1KResNet101ClassificationInferenceConfig,
    IN1KResNet152ClassificationInferenceConfig,
)
from satvis._models.classification.resnet.inference_model import (
    ResNetClassificationInferenceModel,
)
from satvis._models.inference_model import InferenceModel, InferenceModelConfig

MODEL_REGISTRY: dict[
    str, dict[str, tuple[type[InferenceModel], type[InferenceModelConfig]]]
] = {
    "torchvision": {
        "resnet18": (
            ResNetClassificationInferenceModel,
            IN1KResNet18ClassificationInferenceConfig,
        ),
        "resnet34": (
            ResNetClassificationInferenceModel,
            IN1KResNet34ClassificationInferenceConfig,
        ),
        "resnet50": (
            ResNetClassificationInferenceModel,
            IN1KResNet50ClassificationInferenceConfig,
        ),
        "resnet101": (
            ResNetClassificationInferenceModel,
            IN1KResNet101ClassificationInferenceConfig,
        ),
        "resnet152": (
            ResNetClassificationInferenceModel,
            IN1KResNet152ClassificationInferenceConfig,
        ),
    },
    "_dummy_models": {
        "dummy_classification_model": (
            DummyClassificationInferenceModel,
            DummyClassificationInferenceModelConfig,
        ),
    },
}


def list_supported_models() -> list[str]:
    supported_models = []
    for framework, models in MODEL_REGISTRY.items():
        # Skip private frameworks.
        if not framework.startswith("_"):
            for model in models.keys():
                supported_models.append(f"{framework}::{model}")
    return supported_models
