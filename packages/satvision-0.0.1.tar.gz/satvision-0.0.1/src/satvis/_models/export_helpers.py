#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from typing import Callable, Literal, Self, Sequence

import torch
from pydantic import ConfigDict, Field
from torch import Tensor

from satvis._pydantic import SatVisBaseModel
from satvis._types import (
    PathLike,
)


class TensorSpec(SatVisBaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    shape: tuple[int, ...] = Field(..., description="Shape of the tensor.")
    dtype: torch.dtype = Field(..., description="Data type of the tensor.")
    dynamic_axes: dict[int, str] | None = Field(
        ...,
        description=(
            "Optional mapping of dimension indices to symbolic names for dynamic "
            "shapes. Common example: {0: 'batch_size'} to make the batch dimension "
            "dynamic."
        ),
    )
    example_tensor_generator: Callable[[Self], Tensor] = Field(
        default=lambda spec: torch.randn(spec.shape, dtype=spec.dtype),
        description="Function to generate an example tensor based on the spec.",
    )

    def example_tensor(self) -> Tensor:
        """Generate an example tensor based on the specified shape and dtype.

        Returns:
            A tensor with the defined shape and data type.
        """
        return self.example_tensor_generator(self)


class ONNXModelSpec(SatVisBaseModel):
    inputs: Sequence[tuple[str, TensorSpec]] = Field(
        ...,
        description=(
            "Sequence of tuples mapping input tensor names to their configurations."
        ),
    )
    outputs: Sequence[tuple[str, TensorSpec]] = Field(
        ...,
        description=(
            "Sequence of tuples mapping output tensor names to their configurations."
        ),
    )

    def revalidate(self) -> None:
        """Re-validate the model to ensure all fields conform to their types."""
        self.model_rebuild(force=True)

    def update_dynamic_axes(
        self,
        input_dynamic_axes: dict[str, dict[int, str]] | None = None,
        output_dynamic_axes: dict[str, dict[int, str]] | None = None,
    ) -> None:
        """Update the dynamic axes for inputs and outputs.

        Args:
            input_dynamic_axes: Mapping from input tensor names to their dynamic axes.
            output_dynamic_axes: Mapping from output tensor names to their dynamic axes.
        """
        if input_dynamic_axes is not None:
            updated_inputs = []
            for name, spec in self.inputs:
                if name in input_dynamic_axes:
                    updated_inputs.append(
                        (
                            name,
                            spec.model_copy(
                                update={"dynamic_axes": input_dynamic_axes[name]}
                            ),
                        )
                    )
                else:
                    updated_inputs.append((name, spec))
            self.inputs = updated_inputs

        if output_dynamic_axes is not None:
            updated_outputs = []
            for name, spec in self.outputs:
                if name in output_dynamic_axes:
                    updated_outputs.append(
                        (
                            name,
                            spec.model_copy(
                                update={"dynamic_axes": output_dynamic_axes[name]}
                            ),
                        )
                    )
                else:
                    updated_outputs.append((name, spec))
            self.outputs = updated_outputs

    def get_dynamic_axes_dict(
        self, include_outputs: bool = False
    ) -> dict[str, dict[int, str]]:
        """Get a combined dictionary of dynamic axes for all inputs and outputs.

        Returns:
            A dictionary mapping tensor names to their dynamic axes.
        """
        dynamic_info = {}
        for name, spec in self.inputs:
            if spec.dynamic_axes is not None:
                dynamic_info[name] = spec.dynamic_axes
        for name, spec in self.outputs:
            if spec.dynamic_axes is not None:
                dynamic_info[name] = spec.dynamic_axes
        return dynamic_info


class ONNXExportConfig(SatVisBaseModel):
    output_path: PathLike = Field(
        ..., description="Path where the exported ONNX model will be saved."
    )
    model_config_: ONNXModelSpec = Field(
        ..., description="Complete configuration of model inputs and outputs."
    )
    opset_version: int | None = Field(
        ..., description="ONNX opset version to use. If None, uses PyTorch's default."
    )
    use_torch_dynamo: bool | Literal["auto"] = Field(
        ...,
        description=(
            "Whether to use TorchDynamo for optimization. 'auto' enables if available."
        ),
    )
    verbose: bool = Field(
        ..., description="Whether to print verbose output during export."
    )
