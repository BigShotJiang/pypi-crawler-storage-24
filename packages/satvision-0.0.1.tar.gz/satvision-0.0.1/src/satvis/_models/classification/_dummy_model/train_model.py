#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from torch.optim import Adam

from satvis._models.inference_model import InferenceModel, InferenceModelConfig
from satvis._models.train_model import OptimizerConfig, TrainModel


class DummyClassificationTrainModel(TrainModel):
    def _post_init(
        self,
        inference_model_cls: type[InferenceModel],
        inference_model_config: InferenceModelConfig,
    ) -> None:
        self.inference_model = inference_model_cls.from_config(inference_model_config)

    def configure_optimizers(self) -> OptimizerConfig:
        return OptimizerConfig(optimizers=[Adam(self.parameters(), lr=0.001)])
