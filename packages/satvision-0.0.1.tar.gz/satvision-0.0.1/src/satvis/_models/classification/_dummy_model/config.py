#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#

from pathlib import Path
from typing import Literal

import torch
from pydantic import Field

from satvis._models.classification._dummy_model.transform import (
    DummyClassificationValTransformArgs,
)
from satvis._models.classification.classification_inference_model import (
    ClassificationInferenceModelConfig,
    ClassificationModelArgs,
)
from satvis._models.export_helpers import ONNXModelSpec, TensorSpec


class DummyClassificationONNXInputTensorSpec(TensorSpec):
    shape: tuple[int, int, int, int] = (1, 3, 224, 224)
    dtype: torch.dtype = torch.float32
    dynamic_axes: dict[int, str] | None = Field(
        default_factory=lambda: {0: "batch_size"}
    )


class DummyClassificationONNXOutputTensorSpec(TensorSpec):
    shape: tuple[int, int] = (1, 10)
    dtype: torch.dtype = torch.float32
    dynamic_axes: dict[int, str] | None = Field(
        default_factory=lambda: {0: "batch_size"}
    )


class DummyClassificationONNXModelSpec(ONNXModelSpec):
    inputs: list[tuple[str, DummyClassificationONNXInputTensorSpec]] = Field(
        default_factory=lambda: [
            ("images", DummyClassificationONNXInputTensorSpec()),
        ]
    )
    outputs: list[tuple[str, DummyClassificationONNXOutputTensorSpec]] = Field(
        default_factory=lambda: [
            ("class_logits", DummyClassificationONNXOutputTensorSpec()),
        ]
    )


class DummyClassificationModelArgs(ClassificationModelArgs):
    weights: str | Path | None = None
    class_mapping: dict[int, str] = Field(
        default_factory=lambda: {i: f"class_{i}" for i in range(10)}
    )
    in_dim: int = 3
    out_dim: int = 10


class DummyClassificationInferenceModelConfig(ClassificationInferenceModelConfig):
    model_variant: Literal["default"] = "default"
    val_transform_args: DummyClassificationValTransformArgs = Field(
        default_factory=DummyClassificationValTransformArgs
    )
    model_args: DummyClassificationModelArgs = Field(
        default_factory=DummyClassificationModelArgs
    )
    onnx_model_spec: DummyClassificationONNXModelSpec = Field(
        default_factory=DummyClassificationONNXModelSpec
    )
