#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from typing import Callable, ClassVar, Self

import einops
from torch import Tensor
from torch.nn import AdaptiveAvgPool2d, Conv2d

from satvis._decorators import typecheck
from satvis._models.classification._dummy_model.config import (
    DummyClassificationInferenceModelConfig,
    DummyClassificationModelArgs,
    DummyClassificationONNXModelSpec,
)
from satvis._models.classification.classification_inference_model import (
    ClassificationInferenceModel,
)
from satvis._models.inference_model import InferenceModelConfig, ModelArgs
from satvis._transforms.val_transform import ValTransform, ValTransformArgs
from satvis._types import ClassificationLogitsBatch, TorchRGBImageBatch


class DummyClassificationInferenceModel(ClassificationInferenceModel):
    onnx_model_spec_cls: ClassVar[type[DummyClassificationONNXModelSpec]] = (
        DummyClassificationONNXModelSpec
    )

    def _post_init(
        self,
        *,
        model_variant: str,
        model_args: ModelArgs | None,
        val_transform_args: ValTransformArgs,
    ) -> None:
        if not model_variant == "default":
            raise ValueError(
                f"Unsupported model_variant '{model_variant}' for "
                "DummyClassificationInferenceModel. Supported variant is 'default'."
            )

        if not isinstance(model_args, DummyClassificationModelArgs):
            raise TypeError(
                "Expected model_args to be of type DummyClassificationModelArgs, got "
                f"{type(model_args)}."
            )

        if not len(model_args.class_mapping) == model_args.out_dim:
            raise ValueError(
                f"The length of class_mapping ({len(model_args.class_mapping)}) must "
                f"match out_dim ({model_args.out_dim})."
            )

        self._val_transform = ValTransform(transform_args=val_transform_args)
        self.conv_layer: Callable[[TorchRGBImageBatch], Tensor] = Conv2d(
            model_args.in_dim, model_args.out_dim, kernel_size=3
        )
        self.pool: Callable[[Tensor], ClassificationLogitsBatch] = AdaptiveAvgPool2d(
            (1, 1)
        )

        self._class_mapping = model_args.class_mapping
        self._internal_class_mapping = {
            i: val for i, val in enumerate(model_args.class_mapping.values())
        }

    @property
    def class_mapping(self) -> dict[int, str]:
        return self._class_mapping

    @property
    def internal_class_mapping(self) -> dict[int, str]:
        return self._internal_class_mapping

    @classmethod
    def from_config(cls, config: InferenceModelConfig) -> Self:
        if not isinstance(config, DummyClassificationInferenceModelConfig):
            raise TypeError(
                "Expected config to be of type "
                "DummyClassificationInferenceModelConfig, got "
                f"{type(config)}."
            )
        return cls(
            val_transform_args=config.val_transform_args,
            model_variant=config.model_variant,
            model_args=config.model_args,
        )

    @property
    def val_transform(self) -> ValTransform:
        return self._val_transform

    @typecheck
    def forward(self, images: TorchRGBImageBatch) -> ClassificationLogitsBatch:
        features = self.conv_layer(images)
        logits = self.pool(features)
        logits = einops.rearrange(logits, "b c 1 1 -> b c")
        return logits
