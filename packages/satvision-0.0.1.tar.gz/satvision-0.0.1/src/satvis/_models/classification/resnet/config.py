#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import json
from pathlib import Path
from typing import Any, Literal

import torch
from pydantic import Field

from satvis._models.classification.classification_inference_model import (
    ClassificationInferenceModelConfig,
    ClassificationModelArgs,
)
from satvis._models.classification.resnet.transform import (
    ResNetClassificationValTransformArgs,
)
from satvis._models.export_helpers import ONNXModelSpec, TensorSpec
from satvis._transforms.val_transform import ValTransformArgs


def load_in1k_class_mapping() -> dict[int, str]:
    with open(Path(__file__).parent / "assets" / "imagenet_classes.json", "r") as f:
        in1k_class_mapping = json.load(f)
        in1k_class_mapping = {int(k): v for k, v in in1k_class_mapping.items()}
    return in1k_class_mapping


_RESNET_WEIGHTS = Literal["in1k_v1", "in1k_v2"]
_RESNET_MODELS = Literal[
    "resnet18",
    "resnet34",
    "resnet50",
    "resnet101",
    "resnet152",
]


class ResNetClassificationONNXInputTensorSpec(TensorSpec):
    shape: tuple[int, int, int, int] = (1, 3, 224, 224)
    dtype: torch.dtype = torch.float32
    dynamic_axes: dict[int, str] | None = Field(
        default_factory=lambda: {0: "batch_size"}
    )


class ResNetClassificationONNXOutputTensorSpec(TensorSpec):
    shape: tuple[int, int] = (1, 1000)
    dtype: torch.dtype = torch.float32
    dynamic_axes: dict[int, str] | None = Field(
        default_factory=lambda: {0: "batch_size"}
    )


class ResNetClassificationONNXModelSpec(ONNXModelSpec):
    inputs: list[tuple[str, ResNetClassificationONNXInputTensorSpec]] = Field(
        default_factory=lambda: [
            ("images", ResNetClassificationONNXInputTensorSpec()),
        ]
    )
    outputs: list[tuple[str, ResNetClassificationONNXOutputTensorSpec]] = Field(
        default_factory=lambda: [
            ("class_logits", ResNetClassificationONNXOutputTensorSpec()),
        ]
    )


class ResNetClassificationModelArgs(ClassificationModelArgs):
    weights: _RESNET_WEIGHTS | Path | None
    class_mapping: dict[int, str] = Field(default_factory=load_in1k_class_mapping)
    torchvision_resnet_kwargs: dict[str, Any] = Field(default_factory=dict)


class ResNetClassificationInferenceConfig(ClassificationInferenceModelConfig):
    model_variant: _RESNET_MODELS
    model_args: ResNetClassificationModelArgs
    val_transform_args: ValTransformArgs = Field(
        default_factory=ResNetClassificationValTransformArgs
    )
    onnx_model_spec: ResNetClassificationONNXModelSpec = Field(
        default_factory=ResNetClassificationONNXModelSpec
    )


class IN1KResNet18ClassificationInferenceConfig(ResNetClassificationInferenceConfig):
    model_variant: _RESNET_MODELS = "resnet18"
    model_args: ResNetClassificationModelArgs = Field(
        default_factory=lambda: ResNetClassificationModelArgs(
            weights="in1k_v1",
        )
    )


class IN1KResNet34ClassificationInferenceConfig(ResNetClassificationInferenceConfig):
    model_variant: _RESNET_MODELS = "resnet34"
    model_args: ResNetClassificationModelArgs = Field(
        default_factory=lambda: ResNetClassificationModelArgs(
            weights="in1k_v1",
        )
    )


class IN1KResNet50ClassificationInferenceConfig(ResNetClassificationInferenceConfig):
    model_variant: _RESNET_MODELS = "resnet50"
    model_args: ResNetClassificationModelArgs = Field(
        default_factory=lambda: ResNetClassificationModelArgs(
            weights="in1k_v2",
        )
    )


class IN1KResNet101ClassificationInferenceConfig(ResNetClassificationInferenceConfig):
    model_variant: _RESNET_MODELS = "resnet101"
    model_args: ResNetClassificationModelArgs = Field(
        default_factory=lambda: ResNetClassificationModelArgs(
            weights="in1k_v2",
        )
    )


class IN1KResNet152ClassificationInferenceConfig(ResNetClassificationInferenceConfig):
    model_variant: _RESNET_MODELS = "resnet152"
    model_args: ResNetClassificationModelArgs = Field(
        default_factory=lambda: ResNetClassificationModelArgs(
            weights="in1k_v2",
        )
    )
