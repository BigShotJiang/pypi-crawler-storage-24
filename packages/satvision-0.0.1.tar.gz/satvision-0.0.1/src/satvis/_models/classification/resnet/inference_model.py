#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import typing
from pathlib import Path
from typing import Any, Callable, ClassVar, Self

import torch
from torchvision import models
from torchvision.models.resnet import (
    ResNet18_Weights,
    ResNet50_Weights,
    ResNet101_Weights,
    ResNet152_Weights,
)

from satvis._models.classification.classification_inference_model import (
    ClassificationInferenceModel,
)
from satvis._models.classification.resnet.config import (
    _RESNET_MODELS,
    _RESNET_WEIGHTS,
    ResNetClassificationInferenceConfig,
    ResNetClassificationModelArgs,
    ResNetClassificationONNXModelSpec,
)
from satvis._models.inference_model import InferenceModelConfig, ModelArgs
from satvis._transforms.val_transform import ValTransform, ValTransformArgs
from satvis._types import ClassificationLogitsBatch, TorchRGBImageBatch


class ResNetClassificationInferenceModel(ClassificationInferenceModel):
    onnx_model_spec_cls: ClassVar[type[ResNetClassificationONNXModelSpec]] = (
        ResNetClassificationONNXModelSpec
    )

    def __str__(self) -> str:
        return f"torchvision-{self.model_variant}"

    def _post_init(
        self,
        *,
        model_variant: str,
        model_args: ModelArgs | None,
        val_transform_args: ValTransformArgs,
    ) -> None:
        if model_variant not in typing.get_args(_RESNET_MODELS):
            raise ValueError(
                f"Unsupported model_variant '{model_variant}' for "
                "ResNetClassificationInferenceModel. Supported variants are: "
                f"{', '.join(typing.get_args(_RESNET_MODELS))}."
            )
        if not isinstance(model_args, ResNetClassificationModelArgs):
            raise TypeError(
                "Expected model_args to be of type ResNetClassificationModelArgs, got "
                f"{type(model_args)}."
            )

        self._class_mapping = model_args.class_mapping
        self._internal_class_mapping = {
            i: val for i, val in enumerate(model_args.class_mapping.values())
        }

        self._val_transform = ValTransform(transform_args=val_transform_args)

        weights = model_args.weights
        loadable_weights: Path | None = None
        if isinstance(weights, (str, Path)) and Path(weights).exists():
            loadable_weights = Path(weights)
            weights = None

        assert isinstance(weights, str) or weights is None

        try:
            builder = BUILDER_WEIGHT_MAPPING[model_variant][weights]["builder"]
            weights = BUILDER_WEIGHT_MAPPING[model_variant][weights]["weights"]
        except KeyError:
            raise ValueError(
                f"Unsupported model/weights combination: {model_variant}, {weights}"
            )

        self.model: Callable[[TorchRGBImageBatch], ClassificationLogitsBatch] = builder(
            num_classes=len(model_args.class_mapping),
            weights=weights,
            **model_args.torchvision_resnet_kwargs,
        )

        if loadable_weights is not None:
            state_dict = torch.load(loadable_weights, map_location="cpu")
            self.model.load_state_dict(state_dict)

    @property
    def class_mapping(self) -> dict[int, str]:
        return self._class_mapping

    @property
    def internal_class_mapping(self) -> dict[int, str]:
        return self._internal_class_mapping

    @classmethod
    def from_config(cls, config: InferenceModelConfig) -> Self:
        if not isinstance(config, ResNetClassificationInferenceConfig):
            raise TypeError(f"Expected config for ResNets, got {type(config)}")
        return cls(
            val_transform_args=config.val_transform_args,
            model_variant=config.model_variant,
            model_args=config.model_args,
        )

    @property
    def val_transform(self) -> ValTransform:
        return self._val_transform

    def forward(self, images: TorchRGBImageBatch) -> ClassificationLogitsBatch:
        logits = self.model(images)
        return logits


BUILDER_WEIGHT_MAPPING: dict[str, dict[_RESNET_WEIGHTS | None, dict[str, Any]]] = {
    "resnet18": {
        "in1k_v1": {
            "builder": models.resnet18,
            "weights": ResNet18_Weights.IMAGENET1K_V1,
        },
        None: {"builder": models.resnet18, "weights": None},
    },
    "resnet34": {
        "in1k_v1": {
            "builder": models.resnet34,
            "weights": models.ResNet34_Weights.IMAGENET1K_V1,
        },
        None: {"builder": models.resnet34, "weights": None},
    },
    "resnet50": {
        "in1k_v1": {
            "builder": models.resnet50,
            "weights": ResNet50_Weights.IMAGENET1K_V1,
        },
        "in1k_v2": {
            "builder": models.resnet50,
            "weights": models.ResNet50_Weights.IMAGENET1K_V2,
        },
        None: {"builder": models.resnet50, "weights": None},
    },
    "resnet101": {
        "in1k_v1": {
            "builder": models.resnet101,
            "weights": models.ResNet101_Weights.IMAGENET1K_V1,
        },
        "in1k_v2": {
            "builder": models.resnet101,
            "weights": ResNet101_Weights.IMAGENET1K_V2,
        },
        None: {"builder": models.resnet101, "weights": None},
    },
    "resnet152": {
        "in1k_v1": {
            "builder": models.resnet152,
            "weights": models.ResNet152_Weights.IMAGENET1K_V1,
        },
        "in1k_v2": {
            "builder": models.resnet152,
            "weights": ResNet152_Weights.IMAGENET1K_V2,
        },
        None: {"builder": models.resnet152, "weights": None},
    },
}
