#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#

from pydantic import Field

from satvis._num_constants import IMAGENET_NORMALIZE_MEAN, IMAGENET_NORMALIZE_STD
from satvis._transforms.transform_base import NormalizeArgs
from satvis._transforms.val_transform import ValTransformArgs


class ResNetClassificationNormalizeArgs(NormalizeArgs):
    mean: tuple[float, float, float] = IMAGENET_NORMALIZE_MEAN
    std: tuple[float, float, float] = IMAGENET_NORMALIZE_STD


class ResNetClassificationValTransformArgs(ValTransformArgs):
    normalize_args: NormalizeArgs = Field(
        default_factory=ResNetClassificationNormalizeArgs
    )
