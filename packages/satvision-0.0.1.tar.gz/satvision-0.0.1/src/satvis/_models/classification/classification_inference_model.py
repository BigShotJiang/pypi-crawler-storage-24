#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import logging
from abc import ABC, abstractmethod
from typing import Literal, overload, Any

import torch
import torch.multiprocessing as mp
from PIL.Image import Image as PILImage
from torch import Tensor
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.types import Device
from torch.utils.data import DataLoader, DistributedSampler
from tqdm import tqdm

import satvis._distributed_helpers as satvis_dist
import satvis._torchamp_helpers as satvis_torchamp_helpers
from satvis._data import pyarrow_schemas
from satvis._data.classification_dataset import ClassificationDataset
from satvis._models import inference_helpers
from satvis._models.inference_model import (
    InferenceModel,
    InferenceModelConfig,
    ModelArgs,
)
from satvis._types import (
    ClassificationLogitsBatch,
    NumpyRGBImage,
    PathLike,
    TorchRGBImage,
    TorchRGBImageBatch,
    PrecisionType,
    StrategyType,
)

logger = logging.getLogger(__name__)


class ClassificationModelArgs(ModelArgs):
    class_mapping: dict[int, str]


class ClassificationInferenceModelConfig(InferenceModelConfig):
    pass


class ClassificationInferenceModel(InferenceModel, ABC):
    """Abstract base class for classification inference models."""

    @property
    @abstractmethod
    def class_mapping(self) -> dict[int, str]:
        """Mapping from class indices to class names as defined in the dataset."""
        ...

    @property
    @abstractmethod
    def internal_class_mapping(self) -> dict[int, str]:
        """Mapping from class indices to class names used internally by the model, which
        starts from 0 and is contiguous.
        """
        ...

    @abstractmethod
    def forward(self, images: TorchRGBImageBatch) -> ClassificationLogitsBatch:
        """Forward pass of the classification model.

        Args:
            images: A batch of RGB images as a tensor of shape (B, 3, H, W).

        Returns:
            A tensor of shape (B, C) containing the class logits for each image,
            where C is the number of classes.
        """
        ...

    @overload
    def predict(
        self,
        *,
        image: ClassificationDataset,
        device: Device | Literal["auto"],
        apply_transform: bool,
        precision: PrecisionType,
        strategy: StrategyType,
        save_parquet: PathLike,
    ) -> None: ...

    @overload
    def predict(
        self,
        *,
        image: PathLike | PILImage | NumpyRGBImage | TorchRGBImage,
        device: Device | Literal["auto"],
        apply_transform: bool,
        precision: PrecisionType,
        strategy: Literal["auto"],
        save_parquet: None = ...,
    ) -> dict[str, float]: ...

    @overload
    def predict(
        self,
        *,
        image: TorchRGBImageBatch,
        device: Device | Literal["auto"],
        apply_transform: bool,
        precision: PrecisionType,
        strategy: Literal["auto"],
        save_parquet: None = ...,
    ) -> list[dict[str, float]]: ...

    def predict(
        self,
        *,
        image: PathLike
        | PILImage
        | NumpyRGBImage
        | TorchRGBImage
        | TorchRGBImageBatch
        | ClassificationDataset,
        device: Device | Literal["auto"] = "auto",
        apply_transform: bool = True,
        precision: PrecisionType | None = None,
        strategy: StrategyType = "auto",
        save_parquet: PathLike | None = None,
        loader_args: dict[str, Any] | None = None,
    ) -> dict[str, float] | list[dict[str, float]] | None:
        """Predict the class probabilities for a single image or a batch of images.

        Args:
            image: A single image or a batch of images. Float tensors or arrays are
                expected to be normalized to the [0, 1] range.
            device: The device to run the inference on. If "auto", selects CUDA if
                available, otherwise MPS if available, otherwise CPU.
            apply_transform: Whether to apply the model's validation transform to the
                input images.
            precision: The precision mode for inference. "32-true" uses full precision,
                "bf16-mixed" uses mixed precision with bfloat16, and "16-mixed" uses
                mixed precision with float16. If None, the model falls back to its
                default or the default of its backend.
            strategy: The inference strategy to use when providing a
                ClassificationDataset as the input. "ddp" uses Distributed Data
                Parallel across all available GPUs. "auto" selects the strategy
                automatically. This argument is ignored when providing a single image
                or a batch of images.
            save_parquet: Path to save the predictions in Parquet format when providing
                a ClassificationDataset. This argument is ignored when providing a
                single image or a batch of images. If None, it will fall back to saving
                as "<model_name>_<dataset_name>_predictions.parquet".
            loader_args: Additional arguments to pass to the DataLoader when using
                a ClassificationDataset as input.

        Returns:
            A dictionary mapping class names to probabilities for a single image,
            or a list of such dictionaries for a batch of images. In case of a dataset
            input, returns None.
        """
        # Case: ClassificationDataset
        if isinstance(image, ClassificationDataset):
            if save_parquet is None:
                dataset_name = str(image)
                model_name = str(self)
                save_parquet = PathLike(
                    f"{model_name}_{dataset_name}_predictions.parquet"
                )
            self._predict_dataset(
                dataset=image,
                device=device,
                apply_transform=apply_transform,
                precision=precision,
                strategy=strategy,
                save_parquet=save_parquet,
                loader_args=loader_args,
            )
        else:
            if (
                strategy != "auto"
                or save_parquet is not None
                or loader_args is not None
            ):
                raise ValueError(
                    "The 'strategy', 'save_parquet', and 'loader_args' arguments are "
                    "only applicable when providing a ClassificationDataset as input."
                )
            return self._predict_simple(
                image=image,
                device=device,
                apply_transform=apply_transform,
                precision=precision,
            )

    def _predict_simple(
        self,
        image: PathLike | PILImage | NumpyRGBImage | TorchRGBImage | TorchRGBImageBatch,
        device: Device | Literal["auto"] = "auto",
        apply_transform: bool = True,
        precision: PrecisionType | None = None,
    ) -> dict[str, float] | list[dict[str, float]]:
        """Predict the class probabilities for a single image or a batch of images."""
        if device == "auto":
            device = torch.device(
                "cuda"
                if torch.cuda.is_available()
                else "mps"
                if torch.backends.mps.is_available()
                else "cpu"
            )

        with inference_helpers.move_module_to_device(module=self, device=device):
            is_batched = isinstance(image, Tensor) and image.ndim == 4
            image_batch = inference_helpers.image_as_tensor(image=image).to(device)

            if apply_transform:
                image_batch = self.val_transform(image_batch)

            if precision != "32-true":
                autocast_available = satvis_torchamp_helpers.amp_autocast_available(
                    device=device
                )
                if not autocast_available:
                    raise RuntimeError(
                        "Automatic Mixed Precision requested but not available "
                        f"for device {device}."
                    )
                dtype = torch.bfloat16 if precision == "bf16-mixed" else torch.float16
                device_type = satvis_torchamp_helpers.get_device_type(device)
                with torch.autocast(device_type=device_type, dtype=dtype):
                    logits = self(images=image_batch)
            else:
                logits = self(images=image_batch)

            probs = torch.softmax(logits, dim=-1).cpu().numpy()  # (B, C)

            # Single image.
            if not is_batched:
                assert probs.shape[0] == 1
                return {
                    self.internal_class_mapping[i]: float(probs[0, i])
                    for i in range(probs.shape[1])
                }
            # Batch of images.
            else:
                return [
                    {
                        self.internal_class_mapping[i]: float(probs[b, i])
                        for i in range(probs.shape[1])
                    }
                    for b in range(probs.shape[0])
                ]

    def _predict_dataset(
        self,
        dataset: ClassificationDataset,
        device: Device | Literal["auto"] = "auto",
        apply_transform: bool = True,
        precision: PrecisionType | None = None,
        strategy: StrategyType = "auto",
        save_parquet: PathLike | None = None,
        loader_args: dict[str, Any] | None = None,
    ) -> None:
        if device == "auto":
            device = torch.device(
                "cuda"
                if torch.cuda.is_available()
                else "mps"
                if torch.backends.mps.is_available()
                else "cpu"
            )
        with inference_helpers.move_module_to_device(module=self, device=device):
            dataloader = DataLoader(
                dataset=dataset,
                batch_size=128,
                shuffle=False,
                num_workers=4,
                pin_memory=True,
            )
            all_logits = []
            all_sample_ids = []
            for batch in tqdm(dataloader):
                sample_ids = batch["sample_id"]
                images = batch["image"].to(device)
                images = self.val_transform(images)
                with torch.no_grad():
                    logits = self(images=images)
                all_logits.append(logits.cpu())
                all_sample_ids.extend(sample_ids)
            all_logits = torch.cat(all_logits, dim=0)  # (N, C)

            # Save predictions to Parquet file.
            import pyarrow as pa
            import pyarrow.parquet as pq
            from pyarrow import Table

            table = Table.from_pydict(
                {
                    "sample_id": pa.array(all_sample_ids),
                    "logits": pa.array(all_logits.numpy().tolist()),
                },
                schema=pyarrow_schemas.classification_predictions_schema(
                    num_classes=all_logits.shape[1]
                ),
            )

            pq.write_table(table, save_parquet)
            logger.info(f"Saved predictions to {save_parquet}")

    def predict_ddp(
        self,
        rank: int,
        world_size: int,
        dataset: ClassificationDataset,
        save_parquet: PathLike,
    ) -> None:
        """Predict the class probabilities for a dataset using Distributed Data
        Parallel (DDP).

        Args:
            rank: The rank of the current process.
            world_size: The total number of processes.
            dataset: The classification dataset to predict on.
            save_parquet: Path to save the predictions in Parquet format.

        Returns:
            None
        """
        with satvis_dist.setup_dist(rank=rank, world_size=world_size):
            model = DDP(self.to(rank))  # No SyncBatchNorm necessary for inference.
            sampler = DistributedSampler(
                dataset, num_replicas=world_size, rank=rank, shuffle=False
            )
            dataloader = DataLoader(
                dataset=dataset,
                batch_size=128,
                sampler=sampler,
                num_workers=4,
                pin_memory=True,
            )
            all_logits = []
            for batch in tqdm(dataloader):
                images = batch["image"].to(rank)
                images = self.val_transform(images)
                with torch.no_grad():
                    logits = model(images)
                all_logits.append(logits.cpu())
            all_logits = torch.cat(all_logits, dim=0).to(rank)  # (N, C)

            # gather results from all ranks
            gathered_logits = [
                all_logits.new_zeros(all_logits.size()) for _ in range(world_size)
            ]
            torch.distributed.all_gather(gathered_logits, all_logits)

            if rank == 0:
                final_logits = torch.cat(gathered_logits, dim=0).to(
                    "cpu"
                )  # (N_total, C)
                # Save predictions to Parquet file.
                import pyarrow as pa
                import pyarrow.parquet as pq
                from pyarrow import Table

                table = Table.from_pydict(
                    {
                        "sample_id": dataset.manifest["sample_id"],
                        "logits": pa.array(final_logits.numpy().tolist()),
                    },
                    schema=pyarrow_schemas.classification_predictions_schema(
                        num_classes=final_logits.shape[1]
                    ),
                )

                pq.write_table(table, save_parquet)
                logger.info(f"Saved predictions to {save_parquet}")
