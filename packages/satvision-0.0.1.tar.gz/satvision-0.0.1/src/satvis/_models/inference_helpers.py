#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import contextlib
import logging
from typing import Generator, Literal

import torch
import torchvision.transforms.v2.functional as F
from PIL import Image
from PIL.Image import Image as PILImage
from torch.nn import Module
from torch.types import Device
from torchvision.tv_tensors import Image as TVImage

from satvis._decorators import typecheck
from satvis._types import (
    NumpyRGBImage,
    PathLike,
    TorchRGBImage,
    TorchRGBImageBatch,
    PrecisionType,
    StrategyType,
)
from satvis import _torchamp_helpers as satvis_torchamp_helpers

logger = logging.getLogger(__name__)


def resolve_strategy(strategy: Literal["ddp", "auto"]) -> Literal["ddp", "single"]:
    """Resolve the strategy for distributed data parallelism.

    Args:
        strategy: Strategy to resolve.

    Returns:
        Resolved strategy.
    """
    if strategy not in ("ddp", "auto"):
        raise ValueError(f"Unsupported strategy '{strategy}'.")
    num_devices = torch.cuda.device_count()
    if strategy == "auto":
        if num_devices > 1:
            return "ddp"
        else:
            return "single"
    if strategy == "ddp" and num_devices < 2:
        logger.warning(
            "DDP strategy requested but only one CUDA device available. "
            "Falling back to single device."
        )
        return "single"
    return strategy


@typecheck
def image_as_tensor(
    image: PathLike | PILImage | NumpyRGBImage | TorchRGBImage | TorchRGBImageBatch,
) -> TorchRGBImageBatch:
    """Convert an image to a torch tensor batch.

    Args:
        image: Input image as a file path, numpy array, or torch tensor. If file path,
            assumes that image is in RGB and uint8 format. If numpy array, assumes shape
            is (H, W, C) and dtype is either uint8 or float64 in [0, 1]. If torch tensor
            it assumes shape is either (C, H, W) or (B, C, H, W), dtype is float32 and
            values are in [0, 1].

    Returns:
        TorchRGBImageBatch: Image as a torch tensor batch of shape (B, C, H, W), dtype
            float32 and values in [0, 1].
    """
    if isinstance(image, PathLike):
        image = Image.open(image).convert("RGB")
        logger.debug(f"Loaded image from path: {image}")
        assert isinstance(image, PILImage)

    if isinstance(image, (PILImage, NumpyRGBImage)):
        image_: TVImage = F.to_image(inpt=image)
        image = F.to_dtype(inpt=image_, dtype=torch.float32, scale=True)
        logger.debug(
            "Converted numpy image to torch tensor and permuted dimensions from "
            "(H, W, C) to (C, H, W)."
        )

    if isinstance(image, TorchRGBImage):
        image = image.unsqueeze(0)
        logger.debug("Added batch dimension to torch image tensor.")

    if not isinstance(image, TorchRGBImageBatch):
        raise ValueError("Conversion to torch image batch failed.")

    if not (0.0 <= image).all() or not (image <= 1.0).all():
        raise ValueError("Image tensor values must be in the range [0, 1].")

    return image


@contextlib.contextmanager
def move_module_to_device(
    module: Module, device: Device
) -> Generator[None, None, None]:
    """Context manager to temporarily move a module to a specified device.

    Args:
        module: The PyTorch module to move.
        device: The target device.

    Yields:
        None
    """
    original_device = next(module.parameters()).device
    module.to(device)
    try:
        yield
    finally:
        module.to(original_device)


class ModelRunContext:
    """Context manager for running a model on specific devices (distributed or single),
    as well as handling precision settings and communication backends.
    """

    def __init__(
        self,
        device: Device | Literal["auto"],
        precision: PrecisionType,
        strategy: StrategyType,
        devices: list[int] | Literal["auto"] = "auto",
    ) -> None:
        self.devices: list[torch.device] = self._resolve_devices(
            device=device, devices=devices, strategy=strategy
        )
        self.device_type: str = satvis_torchamp_helpers.get_device_type(self.devices[0])
        self.amp_autocast_available: bool = (
            satvis_torchamp_helpers.amp_autocast_available(self.devices[0])
        )
        self.autocast_dtype: torch.dtype = (
            torch.float32
            if precision == "32-true"
            else (torch.bfloat16 if precision == "bf16-mixed" else torch.float16)
        )
        self.strategy: StrategyType = strategy

    def _resolve_devices(
        self,
        device: Device | Literal["auto"],
        devices: list[int] | Literal["auto"],
        strategy: StrategyType,
    ) -> list[torch.device]:
        if device == "auto":
            if torch.cuda.is_available():
                if devices == "auto":
                    num_devices = torch.cuda.device_count()
                    return [torch.device(f"cuda:{i}") for i in range(num_devices)]
                else:
                    return [torch.device(f"cuda:{i}") for i in devices]
            elif torch.backends.mps.is_available():
                return [torch.device("mps:0")]
            else:
                return [torch.device("cpu")]
        else:
            return [torch.device(device)]
