#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from abc import ABC, abstractmethod

from pydantic import Field
from torch.nn import Module

from satvis._pydantic import SatVisBaseModel
from satvis._types import TorchRGBImage, TorchRGBImageBatch


class BatchableTransform(Module, ABC):
    @abstractmethod
    def forward(
        self, image: TorchRGBImage | TorchRGBImageBatch
    ) -> TorchRGBImage | TorchRGBImageBatch: ...


class NormalizeArgs(SatVisBaseModel):
    mean: tuple[float, ...] = Field(strict=False)
    std: tuple[float, ...] = Field(strict=False)


class ResizeArgs(SatVisBaseModel):
    size: tuple[int, int] | int  # (height, width) or short side


class CenterCropArgs(SatVisBaseModel):
    size: tuple[int, int] = Field(strict=False)  # (height, width)
