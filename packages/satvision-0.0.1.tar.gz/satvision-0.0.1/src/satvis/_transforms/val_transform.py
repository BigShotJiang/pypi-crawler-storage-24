#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#

import torch
from torchvision.transforms.v2 import CenterCrop, Compose, Normalize, Resize

from satvis._pydantic import SatVisBaseModel
from satvis._transforms.transform_base import (
    BatchableTransform,
    CenterCropArgs,
    NormalizeArgs,
    ResizeArgs,
)
from satvis._types import TorchRGBImage, TorchRGBImageBatch


class ValTransformArgs(SatVisBaseModel):
    normalize_args: NormalizeArgs


class ValTransform(BatchableTransform):
    def __init__(self, transform_args: ValTransformArgs) -> None:
        super().__init__()
        self._transform_args = transform_args
        transforms = [
            Normalize(
                mean=transform_args.normalize_args.mean,
                std=transform_args.normalize_args.std,
            )
        ]
        self.transform = Compose(transforms)

    def forward(
        self, image: TorchRGBImage | TorchRGBImageBatch
    ) -> TorchRGBImage | TorchRGBImageBatch:
        image = self.transform(image)
        return image


class CollateFnArgs(SatVisBaseModel):
    resize_args: ResizeArgs
    center_crop_args: CenterCropArgs


class ValBatchCollateFn:
    def __init__(self, collate_fn_args: CollateFnArgs) -> None:
        self._collate_fn_args = collate_fn_args
        transforms = [
            Resize(size=collate_fn_args.resize_args.size),
            CenterCrop(size=collate_fn_args.center_crop_args.size),
        ]
        self.transform = Compose(transforms)

    def __call__(self, batch: list[TorchRGBImage]) -> TorchRGBImageBatch:
        batch = [self.transform(image) for image in batch]
        return torch.stack(batch, dim=0)
