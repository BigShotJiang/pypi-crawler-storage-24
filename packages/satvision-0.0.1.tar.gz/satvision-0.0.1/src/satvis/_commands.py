#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from typing import Any

from satvis._models import registry
from satvis._models.inference_model import InferenceModel
from satvis._models.model_helpers import parse_model_name
from satvis._models.registry import MODEL_REGISTRY


def get_inference_model(
    *,
    model_name: str,
    override_args: dict[str, Any] | None = None,
) -> InferenceModel:
    parsed_model_name = parse_model_name(model_name)
    try:
        model_cls, config_cls = MODEL_REGISTRY[parsed_model_name["framework"]][
            parsed_model_name["model"]
        ]
    except KeyError:
        raise ValueError(
            f"Unsupported model: {model_name}, supported models are: {registry.list_supported_models()}"
        )
    config = config_cls(**(override_args or {}))
    model = model_cls.from_config(config)
    return model
