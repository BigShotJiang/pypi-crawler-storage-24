#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Literal, Sequence, TypedDict

import numpy as np
from jaxtyping import Float32, Float64, Int64, UInt8
from torch import Tensor

PathLike = str | Path

# Model configs
PrecisionType = Literal["32-true", "16-mixed", "bf16-mixed"]
StrategyType = Literal["ddp", "auto"]

# Image input types
NumpyRGBImage = Float64[np.ndarray, "H W 3"] | UInt8[np.ndarray, "H W 3"]

TorchRGBImage = Float32[Tensor, "3 H W"]
TorchRGBImageBatch = Float32[Tensor, "B 3 H W"]

# Text input types
TextBatch = Sequence[str]
TorchTextBatch = Int64[Tensor, "B L"]

# Transformer-specific input types
TorchImageAttentionMaskBatch = UInt8[Tensor, "B H W"]
TorchImageShapesBatch = Int64[Tensor, "B 2"]

# Model output types
TorchEmbedding = Float32[Tensor, "D"]
TorchEmbeddingBatch = Float32[Tensor, "B D"]

ClassificationLogitsBatch = Float32[Tensor, "B num_classes"]


# Dataset types
class TorchClassificationSample(TypedDict):
    sample_id: str
    image: TorchRGBImage
    label: Int64[Tensor, ""]  # scalar tensor


class SampleTensorConvention(Enum):
    static = "CHW"
    temporal_first = "TCHW"
    temporal_last = "CHWT"


@dataclass(frozen=True)
class DataSpec:
    dataspec_name: str
    num_channels: int
    sample_tensor_convention: SampleTensorConvention


class ModelNameComponents(TypedDict):
    framework: str
    model: str


SymbolicTensorDim = Literal[
    "B",  # batch size
    "C",  # channels / embedding dimension
    "H",  # height
    "W",  # width
]
