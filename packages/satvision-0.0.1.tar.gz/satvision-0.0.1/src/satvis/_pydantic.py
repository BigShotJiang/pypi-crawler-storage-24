#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from typing import Any, Mapping

from pydantic import BaseModel, ConfigDict


class SatVisBaseModel(BaseModel):
    model_config = ConfigDict(validate_assignment=True)

    def update_fields(self, args: Mapping[str, Any]) -> None:
        """Recursively update nested models from a nested mapping."""
        for key, value in args.items():
            if hasattr(self, key):
                current_value = getattr(self, key)
                if isinstance(current_value, SatVisBaseModel) and isinstance(
                    value, Mapping
                ):
                    current_value.update_fields(value)
                else:
                    setattr(self, key, value)
