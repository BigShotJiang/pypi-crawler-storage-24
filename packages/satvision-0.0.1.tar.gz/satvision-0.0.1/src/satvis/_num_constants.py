#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
IMAGENET_NORMALIZE_MEAN: tuple[float, float, float] = (0.485, 0.456, 0.406)
IMAGENET_NORMALIZE_STD: tuple[float, float, float] = (0.229, 0.224, 0.225)
