#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import functools
from typing import Any, Callable, ParamSpec, TypeVar

import jaxtyping
from beartype import beartype
from jaxtyping import jaxtyped

F = TypeVar("F", bound=Callable[..., Any])
P = ParamSpec("P")
R = TypeVar("R")


def typecheck(func: F) -> F:
    return jaxtyped(typechecker=beartype)(func)


def no_type_check(func: Callable[P, R]) -> Callable[P, R]:
    """Decorator that disables jaxtyping during function execution."""

    @functools.wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        jaxtyping.config.update("jaxtyping_disable", True)
        try:
            return func(*args, **kwargs)
        finally:
            jaxtyping.config.update("jaxtyping_disable", False)

    return wrapper
