#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import contextlib
import os

import torch.distributed as dist

from satvis._env import Env

DIST_BACKEND = "nccl"


@contextlib.contextmanager
def setup_dist(rank: int, world_size: int):
    try:
        os.environ["MASTER_ADDR"] = Env.MASTER_ADDR.value
        os.environ["MASTER_PORT"] = Env.MASTER_PORT.value
        dist.init_process_group(DIST_BACKEND, rank=rank, world_size=world_size)
        yield
    finally:
        dist.destroy_process_group()
