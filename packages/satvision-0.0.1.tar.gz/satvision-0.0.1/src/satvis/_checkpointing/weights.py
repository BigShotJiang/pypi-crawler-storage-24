#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import importlib
from dataclasses import dataclass
from typing import Any, Self

import torch

from satvis._models.inference_model import InferenceModel
from satvis._transforms.val_transform import ValTransform
from satvis._types import PathLike


@dataclass
class SerializableModelWeights:
    """A serializable representation of model weights and associated metadata."""

    model_cls_path: str
    model_init_kwargs: dict[str, Any]
    model_state_dict: dict[str, Any]
    val_transform_cls_path: str
    val_transform_init_kwargs: dict[str, Any]

    @classmethod
    def from_checkpoint(cls, checkpoint: PathLike) -> Self:
        checkpoint_data = torch.load(checkpoint, map_location="cpu")
        return cls(
            model_cls_path=checkpoint_data["model_cls_path"],
            model_init_kwargs=checkpoint_data["model_init_kwargs"],
            model_state_dict=checkpoint_data["model_state_dict"],
            val_transform_cls_path=checkpoint_data["val_transform_cls_path"],
            val_transform_init_kwargs=checkpoint_data["val_transform_init_kwargs"],
        )


@dataclass
class ModelWeights:
    """A representation of model weights and associated metadata."""

    model_cls: type[InferenceModel]
    model_init_kwargs: dict[str, Any]
    model_state_dict: dict[str, Any]
    val_transform_cls: type[ValTransform]
    val_transform_init_kwargs: dict[str, Any]

    @classmethod
    def from_serializable(cls, smw: SerializableModelWeights) -> Self:
        model_cls = cls._import_class_from_path(smw.model_cls_path)
        val_transform_cls = cls._import_class_from_path(smw.val_transform_cls_path)
        return cls(
            model_cls=model_cls,
            model_init_kwargs=smw.model_init_kwargs,
            model_state_dict=smw.model_state_dict,
            val_transform_cls=val_transform_cls,
            val_transform_init_kwargs=smw.val_transform_init_kwargs,
        )

    @classmethod
    def from_checkpoint(cls, checkpoint: PathLike) -> Self:
        smw = SerializableModelWeights.from_checkpoint(checkpoint)
        return cls.from_serializable(smw)

    @staticmethod
    def _import_class_from_path(class_path: str) -> type:
        module_path, class_name = class_path.rsplit(".", 1)
        module = importlib.import_module(module_path)
        return getattr(module, class_name)  # type: ignore[no-any-return]


def load_model_weights(
    checkpoint: PathLike | SerializableModelWeights | ModelWeights,
) -> InferenceModel:
    """Load an InferenceModel from various checkpoint formats.

    Args:
        checkpoint: The checkpoint to load from. Can be a file path, a `SerializableModelWeights`, or a `ModelWeights` instance.

    Returns:
        An instance of `InferenceModel` with weights loaded from the checkpoint.
    """
    if isinstance(checkpoint, ModelWeights):
        model = checkpoint.model_cls(**checkpoint.model_init_kwargs)
        model.load_state_dict(checkpoint.model_state_dict)
        return model
    elif isinstance(checkpoint, SerializableModelWeights):
        mw = ModelWeights.from_serializable(checkpoint)
        model = mw.model_cls(**mw.model_init_kwargs)
        model.load_state_dict(mw.model_state_dict)
        return model
    elif isinstance(checkpoint, (str, bytes, PathLike)):
        mw = ModelWeights.from_checkpoint(checkpoint)
        model = mw.model_cls(**mw.model_init_kwargs)
        model.load_state_dict(mw.model_state_dict)
        return model
    else:
        raise ValueError(
            f"Invalid checkpoint type provided: Expected PathLike, SerializableModelWeights, or ModelWeights, got {type(checkpoint)}"
        )
