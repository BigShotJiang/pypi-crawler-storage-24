#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import torch
from torch.types import Device


def get_device_type(device: Device) -> str:
    if isinstance(device, torch.device):
        device_type = device.type
    elif isinstance(device, str):
        device_type = device.lower()
    elif isinstance(device, int):
        device_type = f"cuda:{device}"
    elif device is None:
        device_type = "cpu"
    else:
        raise ValueError(f"Unsupported device type: {device}")
    return device_type


def amp_autocast_available(device: Device) -> bool:
    """Check if automatic mixed precision (AMP) is available for the given device.

    Args:
        device: The device to check.

    Returns:
        True if AMP is available for the device, False otherwise.
    """
    device_type = get_device_type(device)
    return torch.amp.autocast_mode.is_autocast_available(device_type)
