#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import logging
from pathlib import Path

import numpy as np
import torch
from numpy.typing import NDArray
from PIL import Image
from torch import Tensor
from torchvision.transforms.v2 import (
    Compose,
    Normalize,
    ToDtype,
    ToImage,
)

import satvis

logging.basicConfig(level=logging.DEBUG)

model = satvis.get_inference_model(model_name="torchvision::resnet50")

image_path = Path(__file__).parent / "coffeepot.jpg"


def resnet_preprocess(img_path: Path | str) -> NDArray[np.float32]:
    img = Image.open(img_path)
    transform = Compose(
        [
            ToImage(),
            ToDtype(torch.float32, scale=True),
            Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )
    img_tr: Tensor = transform(img)
    return img_tr.numpy()[np.newaxis, :]


image_path = resnet_preprocess(image_path)
image_path = torch.from_numpy(image_path)

predictions = model.predict(
    image=image_path, apply_transform=False, precision="32-true"
)

print(
    "Prediction (32-bit):",
    [max(prediction.items(), key=lambda item: item[1]) for prediction in predictions],
)

predictions = model.predict(
    image=image_path, apply_transform=False, precision="16-mixed"
)

print(
    "Prediction (mixed precision):",
    [max(prediction.items(), key=lambda item: item[1]) for prediction in predictions],
)
