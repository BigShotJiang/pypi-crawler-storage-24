#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
import json
import time
from argparse import ArgumentParser
from pathlib import Path

import numpy as np
import torch
from numpy.typing import NDArray
from PIL import Image
from torch import Tensor
from torchvision.transforms.v2 import (
    Compose,
    Normalize,
    ToDtype,
    ToImage,
)

# Change this to tritonclient.http and port to 8000 if using HTTP protocol.
from tritonclient.grpc import InferenceServerClient, InferInput, InferRequestedOutput

TRITON_URL = "localhost:8001"

script_dir = Path(__file__).parent.resolve()


def resnet_preprocess(img_path: Path | str) -> NDArray[np.float32]:
    img = Image.open(img_path)
    transform = Compose(
        [
            ToImage(),
            ToDtype(torch.float32, scale=True),
            Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )
    img_tr: Tensor = transform(img)
    return img_tr.numpy()[np.newaxis, :]


def get_imagenet_classname(class_index: int) -> str:
    with open(
        script_dir.parent
        / "src/satvis/_models/classification/resnet/assets/imagenet_classes.json",
        "r",
    ) as f:
        class_map = json.load(f)
    return class_map[str(class_index)]


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument(
        "--server_url",
        type=str,
        default=TRITON_URL,
        help="Triton Inference Server URL",
    )
    parser.add_argument(
        "--image_path",
        type=str,
        default=str(script_dir / "coffeepot.jpg"),
        help="Path to the input image",
    )
    args = parser.parse_args()

    transformed_img = resnet_preprocess(args.image_path)

    # Setup a connection with the Triton Inference Server.
    triton_client = InferenceServerClient(url=args.server_url)

    # Specify the names of the input and output layer(s) of our model.
    test_input = InferInput(name="images", shape=transformed_img.shape, datatype="FP32")
    test_input.set_data_from_numpy(input_tensor=transformed_img)

    test_output = InferRequestedOutput(name="class_logits")

    # Querying the server
    for model in ["resnet152_onnx", "resnet152_trt"]:
        print(f"Querying model: {model}")
        start_time = time.time()
        results = triton_client.infer(
            model_name=model, inputs=[test_input], outputs=[test_output]
        )
        end_time = time.time()
        print(f"Inference time: {end_time - start_time:.4f} seconds")
        results = results.as_numpy("class_logits").astype(np.float32)

        # Logits to probabilities
        probs = torch.softmax(torch.from_numpy(results), dim=-1).numpy()  # (B, C)
        predicted_class = np.argmax(probs, axis=-1)  # (B,)
        predicted_prob = np.max(probs, axis=-1)  # (B,)

        # Get ImageNet class name
        predicted_class_name = get_imagenet_classname(predicted_class[0])

        print(
            f"The image is classified as: {predicted_class_name} with probability {predicted_prob[0]:.4f}"
        )
