<!--
SPDX-License-Identifier: MIT
Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
-->

# Contributing

## Getting Started

### Installing Just

This project uses [Just](https://github.com/casey/just) as a command runner.

**Installation:**
Follow the [Just installation guide](https://github.com/casey/just?tab=readme-ov-file#installation).

**Shell autocomplete:**
For autocompletion, follow the [Just shell completion guide](https://github.com/casey/just?tab=readme-ov-file#shell-completion-scripts).

### Installing `uv` Package Manager

This project uses the `uv` package manager, which can be installed via `just`.

```bash
just install-uv
```

### Installing Dependencies

Run the following command to install all dependencies:

```bash
just install
```

This will install dependencies using Python 3.13 with all extras in a new virtual 
environment. To activate the virtual environment, run:

```bash
source .venv/bin/activate
```

## Development Workflow

Run `just --list` to see all available commands, including:
- `just test` - Run tests
- `just format` - Format code and apply license headers
- `just lint` - Run linter
- `just typecheck` - Run type checker
- `just all-checks` - Run all checks (lint, typecheck, tests)