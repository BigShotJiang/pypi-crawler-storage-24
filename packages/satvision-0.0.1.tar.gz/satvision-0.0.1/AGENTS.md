<!--
SPDX-License-Identifier: MIT
Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
-->
## General Guidelines
- Our code is fully typed and typechecked with mypy. Type ignores should be avoided at all cost.
- Never use positional arguments, unless a function only takes a single argument.
- Never try to expose something to the top-level `__init__` file. Public interfaces are holy and should only be created after careful consideration.
- Import classes directly instead of calling them via their module, potentially renaming them if necessary.
- For functions, import the modules, not the functions directly and also not potential subpackages. Also rename modules if necessary.

## Unit Testing
- Unit testing is done with pytest.
- Every function of the code should be covered with a minmal set of unit tests. At this point where things are still bound to change a lot, we should not go crazy and only check basic functionality. Otherwise development will be delayed.
- Unit tests covering methods of a single class (or a specific) should be grouped inside a class.
- Singular functions should generally not be grouped in classes.
- Follow common pytest best practices. This means make use of the builtin fixtures such as the tempfile.
- Use double underscores for additional test descriptions, i.e. `test_function_name__additional_description`.
- Avoid mocking. Operations that use I/O should be implemented using temporary files and directories. Use pytest's integrated fixture.
- When changing something in unit tests, never simultaneously change something in the corresponding code.
- Avoid comments for the sake of comments in tests. Leave them away if not bringing any benefit.