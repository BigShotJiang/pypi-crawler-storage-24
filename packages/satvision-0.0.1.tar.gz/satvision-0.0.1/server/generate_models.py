#
# SPDX-License-Identifier: MIT
# Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
#
from argparse import ArgumentParser, Namespace
from pathlib import Path

import satvis

RESNET_152_ONNX_PATH = (
    Path(__file__).parent / "model_repository" / "resnet152_onnx" / "1" / "model.onnx"
)
RESNET_152_TENSORRT_PATH = (
    Path(__file__).parent / "model_repository" / "resnet152_trt" / "1" / "model.plan"
)


def parse_args() -> Namespace:
    parser = ArgumentParser()
    parser.add_argument(
        "-f",
        "--force-regenerate",
        action="store_true",
        help="Force regeneration of the model even if it exists",
    )
    parser.add_argument(
        "--max-batch-size",
        type=int,
        default=128,
        help="Maximum batch size for TensorRT model",
    )
    args = parser.parse_args()
    return args


def generate_models(args: Namespace) -> None:
    if not RESNET_152_ONNX_PATH.exists() or args.force_regenerate:
        RESNET_152_ONNX_PATH.parent.mkdir(parents=True, exist_ok=True)

        model = satvis.get_inference_model(
            model_name="torchvision::resnet152",
        )

        model.export_onnx(
            output_path=RESNET_152_ONNX_PATH,
            use_torch_dynamo=False,
        )

    if not RESNET_152_TENSORRT_PATH.exists() or args.force_regenerate:
        RESNET_152_TENSORRT_PATH.parent.mkdir(parents=True, exist_ok=True)

        model = satvis.get_inference_model(
            model_name="torchvision::resnet152",
        )

        model.export_tensorrt(
            output_path=RESNET_152_TENSORRT_PATH,
            max_batch_size=args.max_batch_size,
            fp16=True,
        )


if __name__ == "__main__":
    args = parse_args()
    generate_models(args)
