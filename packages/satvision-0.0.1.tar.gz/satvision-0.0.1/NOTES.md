<!--
SPDX-License-Identifier: MIT
Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
-->
## Interesting Projects
 - modality translation: from SAR to RGB and vice versa
 - super resolution