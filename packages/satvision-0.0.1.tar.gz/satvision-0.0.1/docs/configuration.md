<!--
SPDX-License-Identifier: MIT
Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
-->
# Configuration

The application is configured via environment variables controlled by the `Env` class.

::: satvis._env.Env
    options:
        show_root_heading: true
        show_source: false
        heading_level: 2
        separate_signature: true