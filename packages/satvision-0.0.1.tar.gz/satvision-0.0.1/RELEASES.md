<!--
SPDX-License-Identifier: MIT
Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
-->
# Release Process

## Creating a Release

1. Update `__version__` in `src/satvis/__init__.py` to the new version (e.g. `0.1.0`).
2. Create a PR and merge it to `main`.
3. On GitHub, go to **Releases → Draft a new release**.
4. Create a new tag matching the version with a `v` prefix (e.g. `v0.1.0`).
5. Title structure should be `SatVis v0.1.0` (i.e. "SatVis" + space + tag).
6. In the release description, add all relevant changes since the last release (e.g. new features, bug fixes, breaking changes).
7. Publish the release.

This automatically triggers two workflows:
- `docs-deploy` — deploys the versioned docs to GitHub Pages.
- `pypi-publish` — builds and publishes the package to PyPI.

## If a Workflow Fails

The most likely cause is a mismatch between the Git tag and `__version__` in `src/satvis/__init__.py`. Fix the mismatch (update `__version__` and push), then re-trigger the failed workflow manually:

1. Go to **Actions → \<workflow-name\> → Run workflow**.
2. Select the release tag (e.g. `v0.1.0`) from the branch/tag dropdown — **do not use a branch**.
3. Click **Run workflow**.

## One-time PyPI Setup (Trusted Publishing)

Before the first PyPI publish, configure OIDC Trusted Publishing so no API token is needed:

1. On PyPI, go to **Account → Publishing → Add a new pending publisher** and fill in:
   - PyPI project name: `SatVision`
   - GitHub owner: `liopeer`
   - GitHub repo: `SatVis`
   - Workflow filename: `pypi-publish.yml`
   - Environment name: `pypi`
2. In the GitHub repo, go to **Settings → Environments** and create an environment named `pypi` (optionally add a manual approval gate).