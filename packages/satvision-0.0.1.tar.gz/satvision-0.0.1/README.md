<!--
SPDX-License-Identifier: MIT
Copyright (c) 2025–2026 Oblt Lionel Peer, Swiss Armed Forces
-->
# SatVision
[![docs-build](https://github.com/liopeer/SatVis/actions/workflows/docs-build.yml/badge.svg)](https://github.com/liopeer/SatVis/actions/workflows/docs-build.yml)
[![docs-deploy](https://github.com/liopeer/SatVis/actions/workflows/docs-deploy.yml/badge.svg)](https://github.com/liopeer/SatVis/actions/workflows/docs-deploy.yml)
[![docs-deploy-main](https://github.com/liopeer/SatVis/actions/workflows/docs-deploy-main.yml/badge.svg)](https://github.com/liopeer/SatVis/actions/workflows/docs-deploy-main.yml)
[![pypi-publish](https://github.com/liopeer/SatVis/actions/workflows/pypi-publish.yml/badge.svg)](https://github.com/liopeer/SatVis/actions/workflows/pypi-publish.yml)
[![static-checks](https://github.com/liopeer/SatVis/actions/workflows/static-checks.yml/badge.svg)](https://github.com/liopeer/SatVis/actions/workflows/static-checks.yml)

An opinionated framework for deploying computer vison models on remote sensing imagery.

## Getting Started
### Install `uv`
```bash
just install-uv
```

### Install Core Dependencies
```bash
just install
```

### Install Development Dependencies
```bash
just install-all
```

## Triton Server
Requirements:
- NVIDIA Driver >= 570
- Docker CUDA Toolkit

Installation:
```bash
just install
```
which will install `tensorrt==10.9.0.34`. [This is the version that is compatible](https://docs.nvidia.com/deeplearning/frameworks/support-matrix/index.html#framework-matrix-2025) with
Nvidia Triton Server `nvcr.io/nvidia/tritonserver:25.03-py3` and driver>=570.

Creating the models for Triton Inference Server (to be executed on the actual server with GPU access):
```bash
python server/generate_models.py
```

Running the server:
```bash
docker compose -f server/docker-compose.yml up -d
```

## Sending Inference Requests with ResNet
```bash
python scripts/predict.py
```

## RoadMap
### Q4 2025
- [ ] Core PyTorch Framework with Inference and ONNX Export:
    - [x] Classification
    - [ ] Image Embeddings
    - [ ] Language Embeddings
- [ ] TensorRT Export
    - [x] FP32/FP16 export
    - [ ] verification
- [ ] Model Serving
    - [x] Nvidia Triton server with kserver API
    - [ ] Model Zoo for classification and embeddings
- [ ] Documentation of REST API
- [ ] Basic CI/CD
    - [ ] Inference server to container registry
    - [ ] Unit tests with pytest and coverage

### Q1 2026
- [ ] Model Training
    - [ ] Panoptic Segmentation
    - [ ] CLIP-style training for image and language embeddings
- [ ] Multi-Spectral / Hyperspectral support
    - [ ] I/O for various formats (GeoTIFF, HDF5, NetCDF)
    - [ ] Data Augmentation for multi-spectral data
    - [ ] Models
- [ ] Documentation for Python API

### Q2 2026
- [ ] Model Quantization
    - [ ] Int8 PTQ (Post Training Quantization) with calibration

### Small Projects
- PostGIS sampler for PyTorch DataLoader

## Maintainers
- Oblt Lionel Peer (lionel.peer@gmail.com)