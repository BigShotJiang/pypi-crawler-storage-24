# Staso Python SDK

Python SDK for the Staso platform. Decorator-based tracing and automatic data ingestion for AI agent observability.

## Installation

```bash
pip install staso
pip install -e .

```

With Anthropic integration:
```bash
pip install 'staso[anthropic]'
```

## Quick Start

```python
import staso as st

# Initialize
st.init(api_key="ak_...", agent_id="my-agent")

# Patch Anthropic SDK for automatic LLM tracing
st.integrations.patch_anthropic()

# Decorate your agent entry-point
@st.agent(name="support-agent")
def run_agent(query: str) -> str:
    response = client.messages.create(...)
    return response

# Decorate tool functions
@st.tool(name="search_db")
def search_database(query: str) -> str:
    return db.search(query)

# Use sessions to group traces
with st.session("conversation-123"):
    run_agent("Hello!")

# Clean shutdown
st.shutdown()
```

# Full Flow 

### 1. Develop on feature branch
git checkout -b feat/new-endpoint

### 2. Merge to main via PR
git checkout main && git merge feat/new-endpoint

### 3. Bump version (auto-creates git tag)
pip install bump2version
- Patch release: 0.1.0 → 0.1.1
    - bump2version patch
- Minor release: 0.1.1 → 0.2.0
  - bump2version minor
- Major release: 0.2.0 → 1.0.0
  - bump2version major

### 4. Push tag → triggers GitHub Actions → publishes to PyPI
git push origin main --tags