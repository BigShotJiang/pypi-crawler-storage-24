from setuptools import setup

setup(
    name="jitd",
    version="1.0.0",
    description="Just-In-Time Downloads — download specific files from GitHub without cloning",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    python_requires=">=3.7",
    py_modules=["jitd"],
    entry_points={
        "console_scripts": [
            "jitd=jitd:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],
)
