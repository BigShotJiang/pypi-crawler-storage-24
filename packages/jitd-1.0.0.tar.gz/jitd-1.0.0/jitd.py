#!/usr/bin/env python3
"""
jit - Just Instead of cloning The whole repo
Download specific files or folders from GitHub without cloning.
"""

import argparse
import os
import sys
import json
import urllib.request
import urllib.error
from pathlib import Path


GITHUB_API = "https://api.github.com"
GITHUB_RAW = "https://raw.githubusercontent.com"


def parse_github_url(url_or_shorthand: str):
    """
    Parse a GitHub URL or shorthand into (owner, repo, ref, path).
    Supports:
      - owner/repo
      - owner/repo@branch
      - owner/repo/path/to/file
      - owner/repo@branch/path/to/file
      - https://github.com/owner/repo/blob/branch/path
      - https://github.com/owner/repo/tree/branch/path
    """
    url = url_or_shorthand.strip()

    # Full GitHub URL
    if url.startswith("https://github.com/"):
        url = url.replace("https://github.com/", "")
        parts = url.split("/")
        owner = parts[0]
        repo = parts[1]
        ref = "HEAD"
        path = ""
        if len(parts) > 2:
            # parts[2] is 'blob' or 'tree'
            if parts[2] in ("blob", "tree") and len(parts) > 3:
                ref = parts[3]
                path = "/".join(parts[4:]) if len(parts) > 4 else ""
            else:
                path = "/".join(parts[2:])
        return owner, repo, ref, path

    # Shorthand: owner/repo[@ref][/path]
    if "@" in url:
        repo_part, rest = url.split("@", 1)
        owner, repo = repo_part.split("/", 1)
        if "/" in rest:
            ref, path = rest.split("/", 1)
        else:
            ref = rest
            path = ""
    else:
        parts = url.split("/")
        owner = parts[0]
        repo = parts[1]
        ref = "HEAD"
        path = "/".join(parts[2:]) if len(parts) > 2 else ""

    return owner, repo, ref, path


def get_headers(token: str = None):
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "jit-cli/1.0"}
    token = token or os.environ.get("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def api_get(url: str, token: str = None):
    req = urllib.request.Request(url, headers=get_headers(token))
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise FileNotFoundError(f"Not found: {url}")
        elif e.code == 403:
            raise PermissionError("Rate limited or auth required. Set GITHUB_TOKEN env var.")
        elif e.code == 401:
            raise PermissionError("Invalid token. Check your GITHUB_TOKEN.")
        raise RuntimeError(f"GitHub API error {e.code}: {e.reason}")


def download_file(owner: str, repo: str, ref: str, file_path: str,
                  dest: Path, token: str = None, verbose: bool = True):
    """Download a single file from GitHub."""
    raw_url = f"{GITHUB_RAW}/{owner}/{repo}/{ref}/{file_path}"
    req = urllib.request.Request(raw_url, headers=get_headers(token))
    try:
        with urllib.request.urlopen(req) as resp:
            content = resp.read()
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise FileNotFoundError(f"File not found: {file_path}")
        raise RuntimeError(f"Download failed ({e.code}): {file_path}")

    out_path = dest / file_path if dest != Path(".") else Path(file_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(content)
    if verbose:
        print(f"  ✓  {file_path}")
    return out_path


def download_directory(owner: str, repo: str, ref: str, dir_path: str,
                       dest: Path, token: str = None, verbose: bool = True):
    """Recursively download a directory from GitHub."""
    url = f"{GITHUB_API}/repos/{owner}/{repo}/contents/{dir_path}?ref={ref}"
    items = api_get(url, token)
    if not isinstance(items, list):
        raise RuntimeError(f"Expected directory at '{dir_path}', got a file.")

    count = 0
    for item in items:
        if item["type"] == "file":
            download_file(owner, repo, ref, item["path"], dest, token, verbose)
            count += 1
        elif item["type"] == "dir":
            count += download_directory(owner, repo, ref, item["path"], dest, token, verbose)
    return count


def list_contents(owner: str, repo: str, ref: str, path: str, token: str = None, indent: int = 0):
    """List contents of a path in the repo."""
    url = f"{GITHUB_API}/repos/{owner}/{repo}/contents/{path}?ref={ref}"
    try:
        items = api_get(url, token)
    except FileNotFoundError:
        print(f"Path '{path}' not found in {owner}/{repo}@{ref}")
        return

    if isinstance(items, dict):
        # Single file
        size_kb = items.get("size", 0) / 1024
        print(f"{'  ' * indent}📄 {items['name']}  ({size_kb:.1f} KB)")
        return

    dirs = sorted([i for i in items if i["type"] == "dir"], key=lambda x: x["name"])
    files = sorted([i for i in items if i["type"] == "file"], key=lambda x: x["name"])

    for d in dirs:
        print(f"{'  ' * indent}📁 {d['name']}/")
    for f in files:
        size_kb = f.get("size", 0) / 1024
        print(f"{'  ' * indent}📄 {f['name']}  ({size_kb:.1f} KB)")


def resolve_ref(owner: str, repo: str, ref: str, token: str = None) -> str:
    """Resolve HEAD to the default branch name."""
    if ref != "HEAD":
        return ref
    url = f"{GITHUB_API}/repos/{owner}/{repo}"
    info = api_get(url, token)
    return info.get("default_branch", "main")


# ── CLI commands ──────────────────────────────────────────────────────────────

def cmd_get(args):
    owner, repo, ref, path = parse_github_url(args.target)
    token = args.token or os.environ.get("GITHUB_TOKEN")
    dest = Path(args.output) if args.output else Path(".")

    if not path:
        print("Error: No file or directory path specified.\n"
              "Usage: jit get owner/repo/path/to/file  OR  jit get owner/repo@branch/path")
        sys.exit(1)

    resolved_ref = resolve_ref(owner, repo, ref, token)
    print(f"↓  {owner}/{repo}@{resolved_ref}  →  {path}")

    # Check if it's a file or directory
    url = f"{GITHUB_API}/repos/{owner}/{repo}/contents/{path}?ref={resolved_ref}"
    try:
        item = api_get(url, token)
    except FileNotFoundError:
        print(f"Error: '{path}' not found in {owner}/{repo}")
        sys.exit(1)

    if isinstance(item, list):
        # It's a directory
        print(f"Downloading directory '{path}' to {dest}/")
        count = download_directory(owner, repo, resolved_ref, path, dest, token, verbose=not args.quiet)
        print(f"\n✅  {count} file(s) downloaded to '{dest}'")
    else:
        # Single file
        out = download_file(owner, repo, resolved_ref, path, dest, token, verbose=not args.quiet)
        print(f"\n✅  Saved to '{out}'")


def cmd_ls(args):
    owner, repo, ref, path = parse_github_url(args.target)
    token = args.token or os.environ.get("GITHUB_TOKEN")
    resolved_ref = resolve_ref(owner, repo, ref, token)

    print(f"📦  {owner}/{repo}@{resolved_ref}  /  {path or '(root)'}\n")
    list_contents(owner, repo, resolved_ref, path, token)


def cmd_multi(args):
    """Download multiple files listed in a text file or inline."""
    token = args.token or os.environ.get("GITHUB_TOKEN")
    dest = Path(args.output) if args.output else Path(".")

    lines = []
    if args.file:
        lines = Path(args.file).read_text().splitlines()
    elif args.files:
        lines = args.files

    lines = [l.strip() for l in lines if l.strip() and not l.startswith("#")]

    if not lines:
        print("No files specified.")
        sys.exit(1)

    total = 0
    errors = 0
    for line in lines:
        try:
            owner, repo, ref, path = parse_github_url(line)
            if not path:
                print(f"  ✗  Skipping '{line}' — no path specified")
                continue
            resolved_ref = resolve_ref(owner, repo, ref, token)
            url = f"{GITHUB_API}/repos/{owner}/{repo}/contents/{path}?ref={resolved_ref}"
            item = api_get(url, token)
            if isinstance(item, list):
                count = download_directory(owner, repo, resolved_ref, path, dest, token, verbose=not args.quiet)
                total += count
            else:
                download_file(owner, repo, resolved_ref, path, dest, token, verbose=not args.quiet)
                total += 1
        except Exception as e:
            print(f"  ✗  {line}  →  {e}")
            errors += 1

    print(f"\n✅  {total} file(s) downloaded.  {errors} error(s).")


def cmd_info(args):
    owner, repo, ref, path = parse_github_url(args.target)
    token = args.token or os.environ.get("GITHUB_TOKEN")
    url = f"{GITHUB_API}/repos/{owner}/{repo}"
    info = api_get(url, token)

    print(f"📦  {info['full_name']}")
    print(f"    {info.get('description') or '(no description)'}")
    print(f"    ⭐ {info['stargazers_count']}  🍴 {info['forks_count']}  👁 {info['watchers_count']}")
    print(f"    Default branch: {info['default_branch']}")
    print(f"    Language: {info.get('language') or 'unknown'}")
    print(f"    URL: {info['html_url']}")


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="jitd",
        description="jit — Just Instead of cloning The whole repo.\nDownload specific files from GitHub without cloning.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  jit get torvalds/linux/Makefile
  jit get microsoft/vscode@main/package.json
  jit get psf/requests/src/requests -o ./myproject
  jit ls facebook/react/packages
  jit multi -f filelist.txt
  jit info golang/go

Target format:
  owner/repo/path
  owner/repo@branch/path
  https://github.com/owner/repo/blob/branch/path

Set GITHUB_TOKEN env var to increase API rate limits.
        """
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # get
    p_get = sub.add_parser("get", help="Download a file or directory")
    p_get.add_argument("target", help="GitHub target (owner/repo/path or URL)")
    p_get.add_argument("-o", "--output", help="Output directory (default: current dir)")
    p_get.add_argument("-t", "--token", help="GitHub personal access token")
    p_get.add_argument("-q", "--quiet", action="store_true", help="Suppress file-by-file output")
    p_get.set_defaults(func=cmd_get)

    # ls
    p_ls = sub.add_parser("ls", help="List contents of a repo path")
    p_ls.add_argument("target", help="GitHub target (owner/repo or owner/repo/path)")
    p_ls.add_argument("-t", "--token", help="GitHub personal access token")
    p_ls.set_defaults(func=cmd_ls)

    # multi
    p_multi = sub.add_parser("multi", help="Download multiple files at once")
    p_multi.add_argument("files", nargs="*", help="File targets inline")
    p_multi.add_argument("-f", "--file", help="Text file with one target per line")
    p_multi.add_argument("-o", "--output", help="Output directory (default: current dir)")
    p_multi.add_argument("-t", "--token", help="GitHub personal access token")
    p_multi.add_argument("-q", "--quiet", action="store_true")
    p_multi.set_defaults(func=cmd_multi)

    # info
    p_info = sub.add_parser("info", help="Show repo information")
    p_info.add_argument("target", help="owner/repo")
    p_info.add_argument("-t", "--token", help="GitHub personal access token")
    p_info.set_defaults(func=cmd_info)

    args = parser.parse_args()
    try:
        args.func(args)
    except KeyboardInterrupt:
        print("\nAborted.")
        sys.exit(1)
    except PermissionError as e:
        print(f"Auth error: {e}")
        sys.exit(1)
    except FileNotFoundError as e:
        print(f"Not found: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
