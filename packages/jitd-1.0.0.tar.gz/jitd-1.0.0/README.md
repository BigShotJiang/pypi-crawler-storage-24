# jit

**Just Instead of cloning The whole repo.**

A tiny Python CLI to download specific files or folders from any public (or private) GitHub repo — no `git clone` needed.

---

## Why?

Sometimes you just need one file. Or one folder. Not 500MB of history.

```
git clone https://github.com/torvalds/linux   # ❌ 4GB download
jit get torvalds/linux/Makefile               # ✅ 1 file, done
```

---

## Install

```bash
pip install jit-cli
```

Or from source:

```bash
git clone https://github.com/yourname/jit
cd jit
pip install -e .
```

---

## Usage

### `jit get` — Download a file or directory

```bash
# Single file
jit get owner/repo/path/to/file.py

# From a specific branch or tag
jit get owner/repo@main/path/to/file.py
jit get owner/repo@v2.1.0/CHANGELOG.md

# Whole directory (recursive)
jit get psf/requests/src/requests

# Paste a GitHub URL directly
jit get https://github.com/torvalds/linux/blob/master/Makefile

# Save to a specific output directory
jit get microsoft/vscode/src/vs/base -o ./vscode-base
```

### `jit ls` — Browse a repo without downloading

```bash
jit ls golang/go
jit ls facebook/react/packages
```

### `jit multi` — Download many files at once

```bash
# Inline
jit multi torvalds/linux/Makefile psf/requests/README.md

# From a file (one target per line)
jit multi -f filelist.txt
```

Example `filelist.txt`:
```
# Python tools I always want
psf/requests/src/requests/adapters.py
psf/black/src/black/__init__.py
# Config templates
owner/repo@main/configs/base.yml
```

### `jit info` — Repo summary

```bash
jit info golang/go
```

---

## Target format

| Format | Example |
|--------|---------|
| `owner/repo/path` | `torvalds/linux/Makefile` |
| `owner/repo@branch/path` | `microsoft/vscode@main/package.json` |
| `owner/repo@tag/path` | `psf/requests@v2.31.0/README.md` |
| Full GitHub URL | `https://github.com/owner/repo/blob/branch/path` |

---

## Auth & rate limits

GitHub's unauthenticated API limit is **60 requests/hour**. For heavy use, set a token:

```bash
export GITHUB_TOKEN=ghp_yourtoken
```

Or pass inline:

```bash
jit get owner/repo/file.py --token ghp_yourtoken
```

---

## Options

| Flag | Commands | Description |
|------|----------|-------------|
| `-o, --output DIR` | `get`, `multi` | Output directory (default: `.`) |
| `-t, --token TOKEN` | all | GitHub personal access token |
| `-q, --quiet` | `get`, `multi` | Suppress per-file output |

---

## No dependencies

`jit` uses only Python's standard library. Nothing to install beyond Python 3.7+.

---

## License

MIT
