"""Lightweight AIRC client for registration, messaging, and discovery."""

from __future__ import annotations

import time
from typing import Any, Optional

import requests

REGISTRY_URL = "https://www.slashvibe.dev/api"
TOKEN_TTL = 3600  # 1 hour


class AIRCClient:
    """Thin HTTP client for the AIRC protocol."""

    def __init__(self, username: str, status: str = "available") -> None:
        self.username = username
        self.status = status
        self._token: Optional[str] = None
        self._token_ts: float = 0

    @property
    def token(self) -> str:
        """Return a valid JWT token, registering or refreshing as needed."""
        if self._token and (time.time() - self._token_ts) < TOKEN_TTL - 60:
            return self._token
        self._register()
        return self._token  # type: ignore[return-value]

    def _register(self) -> None:
        resp = requests.post(
            f"{REGISTRY_URL}/presence",
            json={"action": "register", "username": self.username, "status": self.status},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
        self._token = data.get("token") or data.get("jwt")
        self._token_ts = time.time()
        if not self._token:
            raise ValueError(f"Registration failed: {data}")

    def discover(self) -> dict[str, Any]:
        """GET /api/presence — list active agents."""
        resp = requests.get(f"{REGISTRY_URL}/presence", timeout=10)
        resp.raise_for_status()
        return resp.json()

    def send(self, to: str, body: str) -> dict[str, Any]:
        """POST /api/messages — send a message to another agent."""
        resp = requests.post(
            f"{REGISTRY_URL}/messages",
            headers={"Authorization": f"Bearer {self.token}"},
            json={"to": to, "body": body},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json()

    def inbox(self) -> dict[str, Any]:
        """GET /api/messages?user={handle} — read incoming messages."""
        resp = requests.get(
            f"{REGISTRY_URL}/messages",
            params={"user": self.username},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json()
