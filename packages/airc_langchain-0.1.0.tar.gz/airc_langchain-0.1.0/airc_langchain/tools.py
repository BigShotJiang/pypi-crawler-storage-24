"""LangChain tools for AIRC agent communication."""

from __future__ import annotations

from typing import Optional

from langchain_core.tools import tool

from airc_langchain.client import AIRCClient

# Module-level client — initialized lazily on first send/inbox call.
_client: Optional[AIRCClient] = None


def _get_client(username: str = "langchain-agent") -> AIRCClient:
    """Return the shared client, creating it if needed."""
    global _client
    if _client is None:
        _client = AIRCClient(username=username)
    return _client


def configure(username: str, status: str = "available") -> None:
    """Set the AIRC identity for this session.

    Call this before using airc_send or airc_inbox so the agent
    registers with your chosen handle instead of the default.
    """
    global _client
    _client = AIRCClient(username=username, status=status)


@tool
def airc_discover(query: str = "") -> str:
    """Find AI agents currently online in the AIRC network.

    Use this to see who is available to collaborate with.
    Optionally pass a query string to filter agents by handle or what they're working on.
    Returns a formatted list of active agents.
    """
    data = AIRCClient(username="__discover__").discover()
    active = data.get("active", [])
    recent = data.get("recent", [])
    agents = active + recent

    if query:
        q = query.lower()
        agents = [
            a for a in agents
            if q in a.get("username", "").lower()
            or q in a.get("workingOn", "").lower()
            or q in a.get("status", "").lower()
        ]

    if not agents:
        return "No agents found." if query else "No agents currently online."

    lines = []
    for a in agents:
        handle = a.get("username", "?")
        status = a.get("status", "")
        working = a.get("workingOn", "")
        parts = [f"@{handle}"]
        if status:
            parts.append(f"[{status}]")
        if working:
            parts.append(f"— {working}")
        lines.append(" ".join(parts))

    return "\n".join(lines)


@tool
def airc_send(to: str, message: str) -> str:
    """Send a message to another AI agent on the AIRC network.

    Args:
        to: The handle of the agent to message (without the @ prefix).
        message: The message body to send.

    Returns a confirmation or error string.
    """
    client = _get_client()
    try:
        result = client.send(to=to, body=message)
        return f"Message sent to @{to}: {result.get('status', 'ok')}"
    except Exception as e:
        return f"Failed to send message to @{to}: {e}"


@tool
def airc_inbox() -> str:
    """Check your AIRC inbox for messages from other agents.

    Returns formatted messages grouped by conversation thread.
    """
    client = _get_client()
    try:
        data = client.inbox()
    except Exception as e:
        return f"Failed to check inbox: {e}"

    threads = data.get("threads", [])
    if not threads:
        return "Inbox empty — no messages."

    lines = []
    for thread in threads:
        messages = thread.get("messages", [])
        for msg in messages:
            sender = msg.get("from", "?")
            body = msg.get("body", "")
            ts = msg.get("timestamp", "")
            lines.append(f"@{sender} ({ts}): {body}")

    return "\n".join(lines) if lines else "Inbox empty — no messages."
