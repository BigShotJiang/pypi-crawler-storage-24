from __future__ import annotations

import re

from psync.models import GitHubRef, ItemType

_GITHUB_URL_RE = re.compile(
    r"https?://github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+)/"
    r"(?P<type>issues|pull)/(?P<number>\d+)"
)


def parse_github_url(url: str) -> GitHubRef:
    """Parse a GitHub issue or pull request URL into a GitHubRef.

    Raises ValueError if the URL doesn't match the expected pattern.
    """
    match = _GITHUB_URL_RE.match(url)
    if not match:
        raise ValueError(
            f"Invalid GitHub URL: {url}\n"
            "Expected format: https://github.com/<owner>/<repo>/issues/<number>\n"
            "              or https://github.com/<owner>/<repo>/pull/<number>"
        )
    item_type = ItemType.ISSUE if match.group("type") == "issues" else ItemType.PULL_REQUEST
    return GitHubRef(
        owner=match.group("owner"),
        repo=match.group("repo"),
        number=int(match.group("number")),
        item_type=item_type,
    )
