"""psync - Sync GitHub Project issue status transitions to start/end date fields."""

__version__ = "0.1.0"
