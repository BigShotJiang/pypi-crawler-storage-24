from __future__ import annotations

from datetime import datetime

import httpx

from psync.models import GitHubRef, ItemType, ProjectItemInfo, StatusTransition

_GRAPHQL_URL = "https://api.github.com/graphql"

# A status change within this many seconds of a "closed" event is considered "Done"
_CLOSE_CORRELATION_THRESHOLD_SECS = 5


class GitHubClient:
    """Client for GitHub REST + GraphQL APIs."""

    def __init__(self, token: str) -> None:
        self._token = token
        self._headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _rest_client(self) -> httpx.Client:
        return httpx.Client(
            base_url="https://api.github.com",
            headers=self._headers,
            timeout=30,
        )

    def _graphql(self, query: str, variables: dict | None = None) -> dict:
        with httpx.Client(headers=self._headers, timeout=30) as client:
            resp = client.post(_GRAPHQL_URL, json={"query": query, "variables": variables or {}})
            resp.raise_for_status()
            data = resp.json()
            if "errors" in data:
                if any(e.get("type") == "INSUFFICIENT_SCOPES" for e in data["errors"]):
                    raise RuntimeError(
                        "Your GitHub token is missing required scopes.\n"
                        "Run the following to fix:\n\n"
                        "  gh auth refresh -s read:project,project\n"
                    )
                raise RuntimeError(f"GraphQL errors: {data['errors']}")
            return data["data"]

    # ── REST: timeline events ──────────────────────────────────────────

    def get_status_transitions(self, ref: GitHubRef) -> StatusTransition:
        """Fetch timeline events and find when the issue moved to In Progress / Done.

        The REST API returns ``project_v2_item_status_changed`` events but does
        NOT include the actual status name.  We collect all status-change and
        close timestamps, then correlate them:

        * A status change within 5 seconds of a ``closed`` event is treated as
          the "Done" transition.
        * The earliest remaining status change is treated as "In Progress".
        """
        status_change_timestamps: list[datetime] = []
        close_timestamps: list[datetime] = []
        page = 1

        with self._rest_client() as client:
            while True:
                resp = client.get(
                    f"/repos/{ref.owner}/{ref.repo}/issues/{ref.number}/timeline",
                    params={"per_page": 100, "page": page},
                )
                resp.raise_for_status()
                events = resp.json()
                if not events:
                    break

                for event in events:
                    event_type = event.get("event")
                    created_at = event.get("created_at", "")
                    if not created_at:
                        continue

                    ts = _parse_timestamp(created_at)

                    if event_type == "project_v2_item_status_changed":
                        status_change_timestamps.append(ts)
                    elif event_type == "closed":
                        close_timestamps.append(ts)

                page += 1

        return _resolve_transitions(status_change_timestamps, close_timestamps)

    # ── REST: item metadata ───────────────────────────────────────────

    def _get_item_data(self, ref: GitHubRef) -> dict:
        """Fetch the raw issue or PR JSON from the REST API."""
        # GitHub REST API serves both issues and PRs under /issues/{n},
        # but for PRs we need /pulls/{n} to get merged_at.
        if ref.item_type == ItemType.PULL_REQUEST:
            path = f"/repos/{ref.owner}/{ref.repo}/pulls/{ref.number}"
        else:
            path = f"/repos/{ref.owner}/{ref.repo}/issues/{ref.number}"
        with self._rest_client() as client:
            resp = client.get(path)
            resp.raise_for_status()
            return resp.json()

    def get_created_at(self, ref: GitHubRef) -> datetime:
        """Fetch the issue/PR creation timestamp."""
        data = self._get_item_data(ref)
        return _parse_timestamp(data["created_at"])

    def get_completed_at(self, ref: GitHubRef) -> datetime | None:
        """Fetch when the issue was closed or the PR was merged/closed."""
        data = self._get_item_data(ref)
        # For PRs, prefer merged_at over closed_at
        if ref.item_type == ItemType.PULL_REQUEST and data.get("merged_at"):
            return _parse_timestamp(data["merged_at"])
        if data.get("closed_at"):
            return _parse_timestamp(data["closed_at"])
        return None

    # ── GraphQL: project item lookup ───────────────────────────────────

    def get_project_item_info(self, ref: GitHubRef) -> ProjectItemInfo:
        """Find the project item linked to this issue/PR and its date field IDs."""
        item_field = "pullRequest" if ref.item_type == ItemType.PULL_REQUEST else "issue"
        query = f"""
        query($owner: String!, $repo: String!, $number: Int!) {{
          repository(owner: $owner, name: $repo) {{
            {item_field}(number: $number) {{
              projectItems(first: 10) {{
                nodes {{
                  id
                  project {{
                    id
                    fields(first: 30) {{
                      nodes {{
                        ... on ProjectV2FieldCommon {{
                          id
                          name
                          dataType
                        }}
                      }}
                    }}
                  }}
                }}
              }}
            }}
          }}
        }}
        """
        data = self._graphql(
            query,
            {"owner": ref.owner, "repo": ref.repo, "number": ref.number},
        )

        items = data["repository"][item_field]["projectItems"]["nodes"]
        if not items:
            raise RuntimeError(f"{ref.full_name} is not linked to any GitHub Project.")

        # Use the first project item found
        item = items[0]
        project_id = item["project"]["id"]
        item_id = item["id"]

        start_field_id = None
        end_field_id = None

        for field in item["project"]["fields"]["nodes"]:
            name_lower = field.get("name", "").lower()
            if name_lower == "start date" and field.get("dataType") == "DATE":
                start_field_id = field["id"]
            elif name_lower == "end date" and field.get("dataType") == "DATE":
                end_field_id = field["id"]

        return ProjectItemInfo(
            project_id=project_id,
            item_id=item_id,
            start_date_field_id=start_field_id,
            end_date_field_id=end_field_id,
        )

    # ── GraphQL: update date fields ────────────────────────────────────

    def update_date_field(
        self, project_id: str, item_id: str, field_id: str, date: datetime
    ) -> None:
        """Update a date field on a project item."""
        mutation = """
        mutation($projectId: ID!, $itemId: ID!, $fieldId: ID!, $date: Date!) {
          updateProjectV2ItemFieldValue(input: {
            projectId: $projectId
            itemId: $itemId
            fieldId: $fieldId
            value: { date: $date }
          }) {
            projectV2Item { id }
          }
        }
        """
        self._graphql(
            mutation,
            {
                "projectId": project_id,
                "itemId": item_id,
                "fieldId": field_id,
                "date": date.strftime("%Y-%m-%d"),
            },
        )


def _parse_timestamp(ts: str) -> datetime:
    """Parse an ISO 8601 timestamp from the GitHub API."""
    # GitHub returns timestamps like "2024-01-15T10:30:00Z"
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def _resolve_transitions(
    status_changes: list[datetime],
    close_events: list[datetime],
) -> StatusTransition:
    """Correlate status-change timestamps with close events to infer transitions.

    A status change within ``_CLOSE_CORRELATION_THRESHOLD_SECS`` of a close
    event is treated as the "Done" transition.  The earliest remaining status
    change is treated as "In Progress".
    """
    if not status_changes:
        return StatusTransition()

    status_changes.sort()

    done_at: datetime | None = None
    done_index: int | None = None

    # Find the status change closest to a close event
    for close_ts in close_events:
        for i, sc_ts in enumerate(status_changes):
            delta = abs((sc_ts - close_ts).total_seconds())
            if delta <= _CLOSE_CORRELATION_THRESHOLD_SECS:
                done_at = sc_ts
                done_index = i
                break
        if done_at:
            break

    # The earliest status change that isn't the "done" one is "in progress"
    in_progress_at: datetime | None = None
    for i, sc_ts in enumerate(status_changes):
        if i != done_index:
            in_progress_at = sc_ts
            break

    return StatusTransition(in_progress_at=in_progress_at, done_at=done_at)
