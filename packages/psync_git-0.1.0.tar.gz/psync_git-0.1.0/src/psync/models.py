from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime


class ItemType(enum.Enum):
    ISSUE = "issue"
    PULL_REQUEST = "pull_request"


@dataclass(frozen=True)
class GitHubRef:
    """Parsed GitHub issue or pull request reference."""

    owner: str
    repo: str
    number: int
    item_type: ItemType

    @property
    def full_name(self) -> str:
        prefix = "#" if self.item_type == ItemType.ISSUE else "!"
        return f"{self.owner}/{self.repo}{prefix}{self.number}"


@dataclass
class StatusTransition:
    """Timestamps for when an issue moved to In Progress / Done."""

    in_progress_at: datetime | None = None
    done_at: datetime | None = None

    @property
    def duration_days(self) -> float | None:
        if self.in_progress_at and self.done_at:
            return (self.done_at - self.in_progress_at).total_seconds() / 86400
        return None


@dataclass(frozen=True)
class ProjectItemInfo:
    """Info about an issue's linked GitHub Project item."""

    project_id: str
    item_id: str
    start_date_field_id: str | None = None
    end_date_field_id: str | None = None
