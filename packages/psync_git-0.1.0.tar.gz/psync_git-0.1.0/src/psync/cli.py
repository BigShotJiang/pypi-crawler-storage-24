from __future__ import annotations

import enum
import os
import subprocess

import typer
from rich import box
from rich.console import Console
from rich.table import Table

from psync.github import GitHubClient
from psync.models import ItemType
from psync.parser import parse_github_url

app = typer.Typer(help="Sync GitHub Project issue/PR status transitions to start/end date fields.")
console = Console()


class StartFrom(str, enum.Enum):
    created = "created"
    in_progress = "in-progress"


def _get_token() -> str:
    """Resolve GitHub token from env var or gh CLI."""
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        return token
    try:
        result = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, check=True)
        return result.stdout.strip()
    except (FileNotFoundError, subprocess.CalledProcessError):
        console.print(
            "[red]Error:[/red] No GitHub token found.\n"
            "Set GITHUB_TOKEN env var or install the gh CLI and run 'gh auth login'."
        )
        raise typer.Exit(1) from None


@app.command()
def sync(
    url: str = typer.Argument(help="GitHub issue or pull request URL"),
    dry_run: bool = typer.Option(False, "--dry-run", "-n", help="Show changes without applying"),
    start_from: StartFrom = typer.Option(  # noqa: B008
        StartFrom.created,
        "--start-from",
        "-s",
        help="Start date source: 'created' or 'in-progress' (status change)",
    ),
) -> None:
    """Detect status transitions and update start/end dates on a GitHub Project item."""
    try:
        ref = parse_github_url(url)
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None

    token = _get_token()
    client = GitHubClient(token)
    kind = "PR" if ref.item_type == ItemType.PULL_REQUEST else "issue"

    console.print(f"Fetching timeline for [bold]{ref.full_name}[/bold] ({kind})...")

    # Resolve start date
    if start_from == StartFrom.created:
        start_date = client.get_created_at(ref)
        start_label = "Created"
    else:
        transition = client.get_status_transitions(ref)
        start_date = transition.in_progress_at
        start_label = "In Progress"

    # Resolve end date
    if ref.item_type == ItemType.PULL_REQUEST:
        end_date = client.get_completed_at(ref)
    else:
        transition = (
            transition
            if start_from == StartFrom.in_progress
            else client.get_status_transitions(ref)
        )
        end_date = transition.done_at

    if not start_date and not end_date:
        console.print("[yellow]No status transitions found.[/yellow]")
        raise typer.Exit(0)

    # Display findings
    table = Table(title="Status Transitions", box=box.SIMPLE)
    table.add_column("Event", style="cyan")
    table.add_column("Timestamp", style="green")

    if start_date:
        table.add_row(f"Start ({start_label})", str(start_date))
    if end_date:
        end_label = "Merged/Closed" if ref.item_type == ItemType.PULL_REQUEST else "Done"
        table.add_row(end_label, str(end_date))
    if start_date and end_date:
        duration = (end_date - start_date).total_seconds() / 86400
        table.add_row("Duration", f"{duration:.1f} days")

    console.print(table)

    if dry_run:
        console.print("[yellow]Dry run - no changes applied.[/yellow]")
        return

    # Update project dates
    console.print("Fetching project item info...")
    try:
        item_info = client.get_project_item_info(ref)
    except RuntimeError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from None

    updated = False

    if start_date and item_info.start_date_field_id:
        client.update_date_field(
            item_info.project_id,
            item_info.item_id,
            item_info.start_date_field_id,
            start_date,
        )
        console.print(f"[green]Updated Start Date → {start_date.strftime('%Y-%m-%d')}[/green]")
        updated = True
    elif start_date and not item_info.start_date_field_id:
        console.print("[yellow]Warning:[/yellow] No 'Start Date' field found in the project.")

    if end_date and item_info.end_date_field_id:
        client.update_date_field(
            item_info.project_id,
            item_info.item_id,
            item_info.end_date_field_id,
            end_date,
        )
        console.print(f"[green]Updated End Date → {end_date.strftime('%Y-%m-%d')}[/green]")
        updated = True
    elif end_date and not item_info.end_date_field_id:
        console.print("[yellow]Warning:[/yellow] No 'End Date' field found in the project.")

    if not updated:
        console.print("[yellow]No date fields were updated.[/yellow]")
