from datetime import datetime, timezone

import httpx
import pytest
import respx

from psync.github import GitHubClient, _resolve_transitions
from psync.models import GitHubRef, ItemType


@pytest.fixture()
def client() -> GitHubClient:
    return GitHubClient(token="fake-token")


@pytest.fixture()
def issue_ref() -> GitHubRef:
    return GitHubRef(owner="acme", repo="widgets", number=42, item_type=ItemType.ISSUE)


@pytest.fixture()
def pr_ref() -> GitHubRef:
    return GitHubRef(owner="acme", repo="widgets", number=10, item_type=ItemType.PULL_REQUEST)


class TestGetStatusTransitions:
    @respx.mock
    def test_finds_in_progress_and_done(self, client: GitHubClient, issue_ref: GitHubRef) -> None:
        """Status change + close event within threshold → In Progress + Done."""
        events = [
            {
                "event": "project_v2_item_status_changed",
                "created_at": "2024-01-10T10:00:00Z",
            },
            {
                "event": "closed",
                "created_at": "2024-01-15T14:00:00Z",
            },
            {
                "event": "project_v2_item_status_changed",
                "created_at": "2024-01-15T14:00:02Z",
            },
        ]

        respx.get(
            "https://api.github.com/repos/acme/widgets/issues/42/timeline",
            params={"per_page": "100", "page": "1"},
        ).mock(return_value=httpx.Response(200, json=events))

        respx.get(
            "https://api.github.com/repos/acme/widgets/issues/42/timeline",
            params={"per_page": "100", "page": "2"},
        ).mock(return_value=httpx.Response(200, json=[]))

        transition = client.get_status_transitions(issue_ref)

        assert transition.in_progress_at is not None
        assert transition.done_at is not None
        assert transition.in_progress_at.day == 10
        assert transition.done_at.day == 15
        assert transition.duration_days == pytest.approx(5.167, abs=0.01)

    @respx.mock
    def test_no_events(self, client: GitHubClient, issue_ref: GitHubRef) -> None:
        respx.get(
            "https://api.github.com/repos/acme/widgets/issues/42/timeline",
            params={"per_page": "100", "page": "1"},
        ).mock(return_value=httpx.Response(200, json=[]))

        transition = client.get_status_transitions(issue_ref)

        assert transition.in_progress_at is None
        assert transition.done_at is None

    @respx.mock
    def test_ignores_non_status_events(self, client: GitHubClient, issue_ref: GitHubRef) -> None:
        events = [
            {"event": "labeled", "created_at": "2024-01-10T10:00:00Z"},
            {"event": "commented", "created_at": "2024-01-11T10:00:00Z"},
        ]

        respx.get(
            "https://api.github.com/repos/acme/widgets/issues/42/timeline",
            params={"per_page": "100", "page": "1"},
        ).mock(return_value=httpx.Response(200, json=events))

        respx.get(
            "https://api.github.com/repos/acme/widgets/issues/42/timeline",
            params={"per_page": "100", "page": "2"},
        ).mock(return_value=httpx.Response(200, json=[]))

        transition = client.get_status_transitions(issue_ref)

        assert transition.in_progress_at is None
        assert transition.done_at is None

    @respx.mock
    def test_only_in_progress_no_close(self, client: GitHubClient, issue_ref: GitHubRef) -> None:
        """Single status change with no close event → In Progress only."""
        events = [
            {
                "event": "project_v2_item_status_changed",
                "created_at": "2024-01-10T10:00:00Z",
            },
        ]

        respx.get(
            "https://api.github.com/repos/acme/widgets/issues/42/timeline",
            params={"per_page": "100", "page": "1"},
        ).mock(return_value=httpx.Response(200, json=events))

        respx.get(
            "https://api.github.com/repos/acme/widgets/issues/42/timeline",
            params={"per_page": "100", "page": "2"},
        ).mock(return_value=httpx.Response(200, json=[]))

        transition = client.get_status_transitions(issue_ref)

        assert transition.in_progress_at is not None
        assert transition.done_at is None


class TestResolveTransitions:
    def test_status_near_close_is_done(self) -> None:
        status_changes = [
            datetime(2024, 1, 10, 10, 0, 0, tzinfo=timezone.utc),
            datetime(2024, 1, 15, 14, 0, 2, tzinfo=timezone.utc),
        ]
        close_events = [datetime(2024, 1, 15, 14, 0, 0, tzinfo=timezone.utc)]

        t = _resolve_transitions(status_changes, close_events)

        assert t.in_progress_at == status_changes[0]
        assert t.done_at == status_changes[1]

    def test_no_close_event_only_in_progress(self) -> None:
        status_changes = [datetime(2024, 1, 10, 10, 0, 0, tzinfo=timezone.utc)]

        t = _resolve_transitions(status_changes, [])

        assert t.in_progress_at == status_changes[0]
        assert t.done_at is None

    def test_empty(self) -> None:
        t = _resolve_transitions([], [])

        assert t.in_progress_at is None
        assert t.done_at is None

    def test_close_too_far_from_status_change(self) -> None:
        """Close event more than 5s from any status change → no Done."""
        status_changes = [datetime(2024, 1, 10, 10, 0, 0, tzinfo=timezone.utc)]
        close_events = [datetime(2024, 1, 15, 14, 0, 0, tzinfo=timezone.utc)]

        t = _resolve_transitions(status_changes, close_events)

        assert t.in_progress_at == status_changes[0]
        assert t.done_at is None


class TestGetCompletedAt:
    @respx.mock
    def test_pr_merged(self, client: GitHubClient, pr_ref: GitHubRef) -> None:
        respx.get("https://api.github.com/repos/acme/widgets/pulls/10").mock(
            return_value=httpx.Response(
                200,
                json={
                    "created_at": "2024-01-01T10:00:00Z",
                    "closed_at": "2024-01-05T12:00:00Z",
                    "merged_at": "2024-01-05T12:00:00Z",
                },
            )
        )

        result = client.get_completed_at(pr_ref)
        assert result is not None
        assert result.day == 5

    @respx.mock
    def test_pr_closed_not_merged(self, client: GitHubClient, pr_ref: GitHubRef) -> None:
        respx.get("https://api.github.com/repos/acme/widgets/pulls/10").mock(
            return_value=httpx.Response(
                200,
                json={
                    "created_at": "2024-01-01T10:00:00Z",
                    "closed_at": "2024-01-05T12:00:00Z",
                    "merged_at": None,
                },
            )
        )

        result = client.get_completed_at(pr_ref)
        assert result is not None
        assert result.day == 5

    @respx.mock
    def test_pr_still_open(self, client: GitHubClient, pr_ref: GitHubRef) -> None:
        respx.get("https://api.github.com/repos/acme/widgets/pulls/10").mock(
            return_value=httpx.Response(
                200,
                json={
                    "created_at": "2024-01-01T10:00:00Z",
                    "closed_at": None,
                    "merged_at": None,
                },
            )
        )

        result = client.get_completed_at(pr_ref)
        assert result is None

    @respx.mock
    def test_issue_created_at(self, client: GitHubClient, issue_ref: GitHubRef) -> None:
        respx.get("https://api.github.com/repos/acme/widgets/issues/42").mock(
            return_value=httpx.Response(
                200,
                json={"created_at": "2024-01-01T10:00:00Z"},
            )
        )

        result = client.get_created_at(issue_ref)
        assert result.day == 1


class TestGetProjectItemInfo:
    @respx.mock
    def test_finds_project_item(self, client: GitHubClient, issue_ref: GitHubRef) -> None:
        graphql_response = {
            "data": {
                "repository": {
                    "issue": {
                        "projectItems": {
                            "nodes": [
                                {
                                    "id": "PVTI_item1",
                                    "project": {
                                        "id": "PVT_proj1",
                                        "fields": {
                                            "nodes": [
                                                {
                                                    "id": "F_status",
                                                    "name": "Status",
                                                    "dataType": "SINGLE_SELECT",
                                                },
                                                {
                                                    "id": "F_start",
                                                    "name": "Start Date",
                                                    "dataType": "DATE",
                                                },
                                                {
                                                    "id": "F_end",
                                                    "name": "End Date",
                                                    "dataType": "DATE",
                                                },
                                            ]
                                        },
                                    },
                                }
                            ]
                        }
                    }
                }
            }
        }

        respx.post("https://api.github.com/graphql").mock(
            return_value=httpx.Response(200, json=graphql_response)
        )

        info = client.get_project_item_info(issue_ref)

        assert info.project_id == "PVT_proj1"
        assert info.item_id == "PVTI_item1"
        assert info.start_date_field_id == "F_start"
        assert info.end_date_field_id == "F_end"

    @respx.mock
    def test_no_project_raises(self, client: GitHubClient, issue_ref: GitHubRef) -> None:
        graphql_response = {"data": {"repository": {"issue": {"projectItems": {"nodes": []}}}}}

        respx.post("https://api.github.com/graphql").mock(
            return_value=httpx.Response(200, json=graphql_response)
        )

        with pytest.raises(RuntimeError, match="not linked to any GitHub Project"):
            client.get_project_item_info(issue_ref)
