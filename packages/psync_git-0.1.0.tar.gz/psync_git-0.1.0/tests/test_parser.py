import pytest

from psync.models import ItemType
from psync.parser import parse_github_url


class TestParseGitHubUrl:
    def test_issue_url(self) -> None:
        ref = parse_github_url("https://github.com/acme/widgets/issues/42")
        assert ref.owner == "acme"
        assert ref.repo == "widgets"
        assert ref.number == 42
        assert ref.item_type == ItemType.ISSUE

    def test_pr_url(self) -> None:
        ref = parse_github_url("https://github.com/acme/widgets/pull/7")
        assert ref.owner == "acme"
        assert ref.repo == "widgets"
        assert ref.number == 7
        assert ref.item_type == ItemType.PULL_REQUEST

    def test_http_scheme(self) -> None:
        ref = parse_github_url("http://github.com/org/repo/issues/99")
        assert ref.owner == "org"
        assert ref.number == 99

    def test_invalid_url_raises(self) -> None:
        with pytest.raises(ValueError, match="Invalid GitHub URL"):
            parse_github_url("https://github.com/org/repo/actions/1")

    def test_empty_string_raises(self) -> None:
        with pytest.raises(ValueError):
            parse_github_url("")

    def test_issue_full_name(self) -> None:
        ref = parse_github_url("https://github.com/acme/widgets/issues/7")
        assert ref.full_name == "acme/widgets#7"

    def test_pr_full_name(self) -> None:
        ref = parse_github_url("https://github.com/acme/widgets/pull/3")
        assert ref.full_name == "acme/widgets!3"
