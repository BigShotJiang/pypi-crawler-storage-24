from datetime import datetime, timezone

from psync.models import StatusTransition


class TestStatusTransition:
    def test_duration_days(self) -> None:
        t = StatusTransition(
            in_progress_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
            done_at=datetime(2024, 1, 4, tzinfo=timezone.utc),
        )
        assert t.duration_days == 3.0

    def test_duration_none_when_incomplete(self) -> None:
        t = StatusTransition(in_progress_at=datetime(2024, 1, 1, tzinfo=timezone.utc))
        assert t.duration_days is None

    def test_duration_none_when_empty(self) -> None:
        t = StatusTransition()
        assert t.duration_days is None
