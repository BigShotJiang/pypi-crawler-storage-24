# psync

Tiny CLI tool that syncs GitHub Project **Start Date** and **End Date** fields based on issue/PR activity.

## What it does

1. Reads timeline events from a GitHub issue or pull request
2. Determines when work started and ended
3. Updates the linked GitHub Project's date fields

**Start date** defaults to the issue/PR creation date (configurable via `--start-from`).
**End date** is inferred from status transitions (issues) or merge/close time (PRs).

## Install

```bash
# From source
uv pip install .

# Or install as a global CLI tool
uv tool install .
```

## Usage

```bash
# Sync dates for an issue
psync https://github.com/org/repo/issues/42

# Sync dates for a pull request
psync https://github.com/org/repo/pull/7

# Preview without updating (dry run)
psync https://github.com/org/repo/issues/42 --dry-run

# Use "in progress" status change as start date instead of creation date
psync https://github.com/org/repo/issues/42 --start-from in-progress
```

## Authentication

psync needs a GitHub token with `read:project` and `project` scopes.

It resolves the token in this order:
1. `GITHUB_TOKEN` or `GH_TOKEN` environment variable
2. `gh auth token` (GitHub CLI)

To add the required scopes to your existing `gh` token:

```bash
gh auth refresh -s read:project,project
```

## Development

```bash
# Install dependencies
uv sync

# Run tests
uv run pytest

# Lint and format
uv run ruff check src/ tests/
uv run ruff format src/ tests/
```
