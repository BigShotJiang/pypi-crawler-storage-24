# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Skills subcomponent -- provides agent-facing skill markdown files."""

import logging
from pathlib import Path

logger = logging.getLogger("openforage.skills")

EXPECTED_FILENAMES = [
    "analytics_guide.md",
    "getting_started.md",
    "heartbeat_setup.md",
    "quick_reference.md",
    "search_basics.md",
    "template_guide.md",
]


def list_skills() -> list[str]:
    """Return absolute file paths to skill markdown files in the installed package.

    Returns exactly 6 absolute paths when all package data files are present.
    Returns empty list [] when:
    - The skills directory is missing or unreadable
    - Any of the 6 expected files is absent or unreadable (all-or-nothing)

    Logs a WARNING via logging.getLogger("openforage.skills") when returning empty list.
    Never raises any exception.
    """
    try:
        skills_dir = Path(__file__).resolve().parent

        if not skills_dir.is_dir():
            logger.warning("Skills directory missing or not found: %s", skills_dir)
            return []

        # Verify directory is readable
        try:
            list(skills_dir.iterdir())
        except PermissionError as e:
            logger.warning(
                "Skills directory unreadable, permission denied: %s - %s",
                skills_dir,
                e,
            )
            return []
        except OSError as e:
            logger.warning("Skills directory access error: %s - %s", skills_dir, e)
            return []

        # Validate each expected file exists and is readable (all-or-nothing)
        paths: list[str] = []
        missing: list[str] = []
        unreadable: list[str] = []

        for filename in EXPECTED_FILENAMES:
            filepath = skills_dir / filename

            if not filepath.is_file():
                missing.append(filename)
                continue

            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    f.read()
                paths.append(str(filepath))
            except OSError:
                unreadable.append(filename)

        if missing:
            logger.warning(
                "Missing skill files in skills directory: %s", ", ".join(missing)
            )
            return []

        if unreadable:
            logger.warning("Unreadable skill files: %s", ", ".join(unreadable))
            return []

        return paths

    except Exception as e:
        logger.warning("Unexpected error in list_skills(): %s", e)
        return []
