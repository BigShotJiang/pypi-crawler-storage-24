---
name: Analytics Guide
description: Interpreting search results and analytics data
version: "1.0"
tags: [analytics, results, interpretation]
---

# Analytics Guide

## Overview

OpenForage provides six analytics operations to help you understand your
search progress. Each function is a callable that provides analytics data.
A feature is an input data column. An expression is a tree-shaped combination
of building blocks. A template is a search strategy that generates and
evaluates expressions.

## get_search_stats()

This function shows per-function and per-feature yield rates and success rates.
It tells you which individual functions and features have the highest rate of
appearing in passing evaluations. Use this to identify which building blocks
are most productive for signal discovery.

```python
stats = openforage.get_search_stats()
```

## get_search_patterns()

This function reveals the depth distribution of expression trees and which
family combinations produce the best results. It shows how deep successful
expressions tend to be and which pairs of function families combine well to
produce passing signals.

```python
patterns = openforage.get_search_patterns()
```

## get_search_velocity()

This function tracks the signal discovery rate over time. It shows the trend
of how fast signals are being found per hour -- whether the discovery speed
is increasing, decreasing, or holding steady over time. A declining trend
may indicate the search space is becoming exhausted.

```python
velocity = openforage.get_search_velocity()
```

## get_yield_analysis()

This function detects diminishing yield rates in the search. When the yield rate
is declining, it means fewer new signals are being discovered relative to
the number of expressions evaluated. Diminishing yield indicates the current
strategy is saturating and you may need to switch approaches.

```python
yield_data = openforage.get_yield_analysis()
```

## get_suggestions()

This function recommends expressions to try next based on patterns in previous
evaluations. Suggestions indicate which building block combinations are likely
to succeed. Interpret each suggestion as a recommendation to explore similar
expression structures, then try evaluating expressions in those directions.

```python
suggestions = openforage.get_suggestions()
```

## get_correlation_patterns()

This function shows which function pairs co-occur together in passing evaluations.
It reveals which function combinations appear in successful expressions. Use this to identify synergistic building blocks that work
well when combined in the same expression tree.

```python
corr = openforage.get_correlation_patterns()
```

## When to Switch Strategies

If the yield rate is declining and discovery velocity has slowed, consider
switching or adjusting your search strategy. Signs that indicate a change
is needed:

- The signal discovery rate has dropped below a threshold that you consider
  productive
- Most new expressions fail evaluation despite trying new combinations
- Analytics show that previously productive function families are no longer
  producing new passing signals

## Interpreting Suggestions

Suggestions represent the system's recommendation for what to try next.
Act on them by incorporating the suggested building blocks into your
template's sampling weights or by directly evaluating the suggested
expression structures.

## Passing vs. Failing Expressions

What distinguishes a passing expression from a failing one is whether it meets
all quality thresholds (Sharpe ratio, minimum annualized return threshold,
turnover). Common patterns in passing expressions:

- They tend to use specific function family combinations that the analytics
  data highlights
- They often have a characteristic tree depth range
- They frequently include building blocks with high individual yield rates

Failing or rejected expressions typically do not meet one or more evaluation
thresholds.
