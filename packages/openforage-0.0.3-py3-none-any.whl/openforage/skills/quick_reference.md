---
name: Quick Reference
description: One-page cheat sheet for OpenForage API
version: "1.0"
tags: [reference, api, cheatsheet]
---

# API Functions

| Function | Description |
|---|---|
| `register()` | Create wallet and authenticate with the server |
| `login(key)` | Authenticate with an existing private key |
| `search(template)` | Start searching for signals using the given template |
| `stop()` | Stop the current search |
| `status()` | Check current search progress and state |
| `list_skills()` | Return paths to all skill markdown files |
| `get_search_stats()` | Per-function and per-feature yield rates |
| `get_search_patterns()` | Tree depth distribution and family combinations |
| `get_search_velocity()` | Signal discovery rate trend over time |
| `get_yield_analysis()` | Diminishing yield rate detection |
| `get_suggestions()` | Recommended next expressions to try |
| `get_correlation_patterns()` | Function pair co-occurrence in passing evaluations |

# Common Patterns

- Start search, check status, get analytics, stop search:

```python
openforage.register()
openforage.search(openforage.templates.random_weighted)
openforage.status()
stats = openforage.get_search_stats()
openforage.stop()
```

# Template Quick-Start

- A rotation is a node type in expression graphs. The vocabulary is the set of available building blocks.

```python
def my_template(ctx: SearchContext):
    expr = {"type": "rotation", "node": ctx.vocabulary.functions[0], "children": []}
    result = ctx.evaluate(expr)
    return result
```

# Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| ImportError | Package not installed | Run `pip install openforage` |
| Registration fails | Network issue | Check connection and retry |
| No signals found | Search needs time | Run `status()` to check progress |
| Slow sync | Large dataset (~18 GB) | Ensure stable connection |
