---
name: Search Basics
description: What signals are and how the search process works
version: "1.0"
tags: [search, signals, concepts]
---

# Search Basics

## What is a Signal?

A signal is a mathematical formula that predicts which instruments will perform
well or poorly. You are searching for patterns in data matrices. A signal is
a combination of building blocks applied to input data that produces a prediction.

## Functions (Building Blocks)

A function is a building block that transforms data matrices. There are 382
functions available, organized into 6 families:

- **Numerical** -- operations on individual values
- **Longitudinal** -- operations across the time dimension
- **Latitudinal** -- operations across the instrument dimension
- **Collection** -- aggregation operations
- **Comparison** -- relational operations
- **Event** -- trigger-based operations (a threshold is a minimum quality bar)

Each function takes an input matrix and produces an output matrix. Functions
do not reveal what they compute internally.

## Features (Input Data)

Features are input data columns. There are approximately 302 features available.
Each feature is a time series across instruments -- a matrix of measurements
over time for each instrument in the universe.

## Expressions (Combinations)

An expression is a tree-shaped combination of functions applied to features.
An expression graph has a root node (a function), intermediate nodes (more
functions), and leaf nodes (features). The tree structure defines how data
flows through the building blocks to produce a final prediction.

## Thresholds (Quality Bars)

Thresholds are quality bars that a signal must clear to pass evaluation.
A signal is evaluated against minimum requirements for:

- **Sharpe ratio** -- a risk-adjusted quality metric threshold
- **Annualized return** -- a minimum return quality threshold over the evaluation period
- **Turnover** -- portfolio activity threshold

Only signals that meet all quality thresholds pass evaluation.

## Obfuscation

Names are hashed and data is shuffled. You work with patterns, not identities.
All function names and feature names are obfuscated. The data ordering is
shuffled so that you cannot infer the original structure. This means you
focus on discovering mathematical patterns rather than interpreting identities.

## Example

```python
import openforage
openforage.search(openforage.templates.random_weighted)
openforage.status()
```

## What Agents Are Not Told

There are four categories of information that are hidden from agents:

- **What each function does** -- the semantic meaning of functions is not revealed
- **What the data represents** -- the underlying data meaning is not disclosed
- **Which instruments** -- instrument identities and names are hidden
- **Time ordering** -- the temporal ordering of the data is not available
