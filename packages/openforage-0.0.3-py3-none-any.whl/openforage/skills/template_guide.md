---
name: Template Guide
description: Using and creating search templates for OpenForage
version: "1.0"
tags: [templates, search, customization]
---

# Template Guide

## The Starter Template

The `random_weighted` template is the recommended starting point. Run it with:

```python
import openforage
openforage.search(openforage.templates.random_weighted)
```

## How random_weighted Works

An expression is a tree-shaped combination of building blocks applied to data.
The `random_weighted` template starts with random expression generation and
learns from yield rates to adapt its sampling strategy. It gradually increases
expression depth and complexity as it discovers which building blocks produce
better results. The discovery rate improves as the template adjusts sampling
weights based on success rates.

## Reading Analytics for Optimization

A function is a building block that transforms data (there are 382 available).
Use analytics to understand what is working. The yield rate by function family
shows which families of building blocks produce the most passing signals. When
yield rates for a family begin to plateau or show diminishing yield rates, consider
shifting sampling weights toward other families.

```python
stats = openforage.get_search_stats()
# Examine per-function yield rates
```

## Custom Template Creation

When the starter template is not sufficient, you can create a custom template
using the SearchContext API.

### SearchContext API

A template is a callable that receives a `SearchContext` with these members:

- `vocabulary` -- the available building blocks and features
- `analytics` -- current search analytics data
- `evaluate()` -- submit an expression for evaluation
- `refresh_analytics()` -- update analytics with latest results

### Expression Graph Format

A rotation is a type of node that represents a building block in the
expression graph. A feature is an input data column used as a leaf node.
Expressions are represented as dict graphs with three keys:

```python
{"type": "rotation", "node": "func_abc123", "children": [{"type": "feature", "node": "feat_001", "children": []}]}
```

The `"type"` field indicates the node kind (rotation, feature, etc.), the `"node"`
field identifies the specific building block, and the `"children"` field lists
child nodes.

### Yield Rate Optimization

Read analytics to identify which building blocks have high yield rates, then
shift your sampling weights to prioritize those building blocks. Weight higher
the function families and features that produce more passing signals.

### Example Custom Template

```python
def my_template(ctx: SearchContext):
    vocab = ctx.vocabulary
    analytics = ctx.analytics
    # Build expression from vocabulary
    expr = {"type": "rotation", "node": vocab.functions[0], "children": []}
    result = ctx.evaluate(expr)
    ctx.refresh_analytics()
    return result
```

## When to Create a Custom Template

Start with `random_weighted` and let it run until you have analytics data.
Consider creating a custom template when:

- The discovery rate is declining and you want to focus on specific families
- You have a hypothesis about which building block combinations work well
- You want to implement a specific search strategy based on analytics insights

Stick with `random_weighted` if you are still exploring and have not yet
identified clear patterns in the analytics data.
