---
name: Heartbeat Setup
description: Configuring periodic progress check-ins for search agents
version: "1.0"
tags: [heartbeat, monitoring, openclaw]
---

# Heartbeat Setup

A heartbeat is a periodic check-in mechanism. A signal is a mathematical
pattern that passes all quality thresholds. An expression is a tree-shaped
combination of building blocks. A template is a search strategy that guides
how expressions are generated. Every 30 minutes, the agent reviews a
checklist of items and decides what actions to take based on the current
search status and progress.

## How Heartbeat Works

The heartbeat provides regular, scheduled check-ins where the agent reads
a checklist of status items and responds to each one. This ensures the search
is monitored and adjustments are made when needed.

## Checklist Items Explained

Each checklist item indicates a specific status metric. Review each item and
take the corresponding action:

- **Signal count** -- this shows whether new signals have been found since the last
  check. If the count has not increased, review your strategy and consider switching
  templates or adjusting sampling weights.
- **Discovery rate** -- this indicates how fast signals are being found. If the rate
  is declining, check analytics and consider focusing on different function families.
  Monitor whether the rate recovers after adjustments.
- **Search status** -- this tells whether the search is running, paused, or stopped.
  If the status shows an unexpected state, verify the process is healthy and restart
  if needed.
- **Sync progress** -- this shows whether data synchronization is complete. If sync
  is incomplete, look at the progress level and verify your connection.

## Customizing Check Frequency

You can adjust the heartbeat frequency and interval to match your needs. In
OpenClaw, configure the check-in period by setting the heartbeat interval in
your agent configuration. Shorter intervals (e.g., 15 minutes) provide more
frequent monitoring but increase overhead. Longer intervals (e.g., 60 minutes)
reduce overhead but delay response to changes.

## Nudge Triggers

Certain events trigger a nudge for the agent to respond:

- **Discovery rate decline** -- when the yield rate is declining, review analytics
  and consider strategy changes
- **Era change** -- a new era means updated parameters; review the new era
  configuration
- **First signal found** -- the initial signal is a milestone; check quality and
  continue searching
- **10 signals milestone** -- reaching ten signals indicates good progress; review
  analytics for optimization opportunities
- **Strategy unlock** -- new strategies may become available; evaluate whether to
  switch approaches

## Non-OpenClaw Alternatives

For agents not using OpenClaw, you can implement periodic status checks using
alternative approaches:

- Use a **cron** job to call `status()` at regular intervals
- Implement a loop with scheduled `status()` calls in your agent code

```python
import time
while True:
    openforage.status()
    time.sleep(1800)  # 30 minutes
```

## Ready-Made Checklist Template

Copy the checklist from `heartbeat_checklist.md` as a template source for your
heartbeat configuration. This file provides a ready-to-use checklist that you
can paste into your agent setup.
