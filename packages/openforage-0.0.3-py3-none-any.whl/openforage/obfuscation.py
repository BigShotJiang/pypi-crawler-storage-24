# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Obfuscation subcomponent — vocabulary loading and data obfuscation."""

import json
import logging
import os

logger = logging.getLogger("openforage.obfuscation")


def load_vocabulary(data_dir=None):
    """Load vocabulary from disk.

    Reads vocabulary.json from the data directory. Returns the parsed dict,
    or None if the file does not exist or cannot be parsed.
    """
    if data_dir is None:
        try:
            from openforage.agent_onboarding import _config
            data_dir = _config.get("data_dir", "~/.openforage/")
        except ImportError:
            data_dir = "~/.openforage/"
    data_dir = os.path.expanduser(data_dir)
    vocab_path = os.path.join(data_dir, "vocabulary.json")
    if not os.path.exists(vocab_path):
        return None
    try:
        with open(vocab_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        logger.warning("Failed to load vocabulary: %s", e)
        return None


class ObfuscationManager:
    """Agent-side vocabulary manager.

    Parses vocabulary from plain JSON and provides vocabulary lookup.
    Shuffle seed decryption and data unshuffling are handled by the
    compiled backtester, not this class.
    """

    _REQUIRED_TOP_KEYS = ("era_id", "rotations", "filtrations", "reductions", "features", "metadata")
    _REQUIRED_META_KEYS = ("n_instruments", "t_signal_is", "t_strategy_is")

    def __init__(self, vocabulary_json: str, era_id: int) -> None:
        if era_id <= 0:
            raise ValueError(f"era_id must be > 0, got {era_id}")

        try:
            parsed = json.loads(vocabulary_json)
        except (json.JSONDecodeError, ValueError) as e:
            raise ValueError(f"vocabulary_json is not valid JSON: {e}") from e

        if not isinstance(parsed, dict):
            raise ValueError(
                f"vocabulary_json missing required key: '{self._REQUIRED_TOP_KEYS[0]}'"
            )

        for key in self._REQUIRED_TOP_KEYS:
            if key not in parsed:
                raise ValueError(f"vocabulary_json missing required key: '{key}'")

        metadata = parsed["metadata"]
        if not isinstance(metadata, dict):
            raise ValueError(
                f"vocabulary_json missing required key: '{self._REQUIRED_META_KEYS[0]}'"
            )

        for key in self._REQUIRED_META_KEYS:
            if key not in metadata:
                raise ValueError(f"vocabulary_json missing required key: '{key}'")

        self._vocabulary = parsed
        self._dimensions = (
            int(metadata["n_instruments"]),
            int(metadata["t_signal_is"]),
            int(metadata["t_strategy_is"]),
        )

    def get_vocabulary(self) -> dict:
        return self._vocabulary

    def get_dimensions(self) -> tuple:
        return self._dimensions
