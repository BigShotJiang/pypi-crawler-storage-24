# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Agent onboarding subcomponent -- register, login, configure, heartbeat."""

import logging
import os
import secrets
from dataclasses import dataclass
from typing import List

from openforage import auth
from openforage.skills import list_skills

logger = logging.getLogger("openforage.agent_onboarding")


@dataclass
class WalletRegistration:
    """Returned by register() on successful wallet creation/re-auth."""
    address: str


@dataclass
class AuthToken:
    """Returned by login() on successful authentication."""
    token: str
    expires_at: float


_config = {
    "auto_heartbeat": True,
    "data_dir": "~/.openforage/",
    "server_url": "https://api.openforage.io",
}

# Module-level cached AuthManager instance (R-23)
_auth_manager = None

# Valid config options and their expected types
_VALID_OPTIONS = {
    "auto_heartbeat": bool,
    "data_dir": str,
    "server_url": str,
}

# Static heartbeat section from L2 spec
_HEARTBEAT_STATIC_SECTION = """## [OpenForage] Search Monitoring

Check these items to stay on top of your signal search:

- [ ] **Search status**: Run `openforage.status()` \u2014 is the search running? Any errors to address?
- [ ] **Discovery rate check**: Run `openforage.get_search_velocity()` \u2014 is your signals-per-hour trending up, stable, or declining?
- [ ] **Suggestions**: Run `openforage.get_suggestions()` \u2014 are there underexplored function families or high-potential features to focus on?
- [ ] **Milestone check**: How many signals have you found? Any new milestones (first signal, 10th signal, Strategy unlock at 100)?
- [ ] **Strategy review**: If discovery rate is declining, consider: restarting with a different template, increasing n_jobs, or creating a custom template focused on high-potential areas.
"""

# Nudge trigger texts from L2 spec
_NUDGE_TEXTS = {
    "discovery_rate_declining": "- [ ] [OpenForage] Search discovery rate has dropped significantly. Run analytics and consider adjusting your template.",
    "era_change": "- [ ] [OpenForage] New era detected. Your search will pause for re-sync. Check status after sync completes.",
    "first_signal": "- [ ] [OpenForage] First signal found! Check status for details.",
    "10_signals": "- [ ] [OpenForage] 10 signals found. Review analytics to see which functions/features work best.",
    "strategy_unlock": "- [ ] [OpenForage] Strategy search unlocked! You can now search for Strategies.",
}

# AGENTS.md fragment from L2 spec
_AGENTS_MD_FRAGMENT = """## OpenForage Integration
- Skills: Provided via `openforage.list_skills()`
- Tools: register, search, stop, status, analytics (via Python API)
- Heartbeat: Auto-injected monitoring checklist
"""


def _find_heartbeat(working_dir=None):
    """Search for HEARTBEAT.md in cwd + up to 3 parent directories.

    Returns the path to HEARTBEAT.md if found, None otherwise.
    """
    current = working_dir if working_dir is not None else os.getcwd()

    for _ in range(4):
        hb_path = os.path.join(current, "HEARTBEAT.md")
        if os.path.exists(hb_path):
            return hb_path
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent

    return None


def _normalize_key(raw_key):
    """Ensure private key has 0x prefix for AuthManager."""
    if raw_key.startswith("0x") or raw_key.startswith("0X"):
        return raw_key
    return "0x" + raw_key


def _write_wallet_key(data_dir, key_content):
    """Write private key to wallet.key with 0600 permissions.

    Raises IOError with exact L2 message format on failure.
    Does NOT create the data_dir automatically -- the directory must already exist.
    """
    wallet_path = os.path.join(data_dir, "wallet.key")
    try:
        fd = os.open(wallet_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, key_content.encode("utf-8"))
        finally:
            os.close(fd)
        os.chmod(wallet_path, 0o600)
    except (IOError, OSError):
        raise IOError(f"Cannot write wallet to {wallet_path}. Check directory permissions.")


def _propagate_auth(am):
    """Set _auth on search_templates and simulate_signal so they know we're authenticated."""
    try:
        import openforage.search_templates as st_mod
        st_mod._auth = am
    except Exception as e:
        logger.warning("Failed to inject auth into search_templates: %s", e)

    try:
        import openforage.simulate_signal as sim_mod
        sim_mod._auth = am
        sim_mod._sync_manager = None  # lazy — constructed at call time
    except Exception as e:
        logger.warning("Failed to inject auth into simulate_signal: %s", e)


def register() -> WalletRegistration:
    """First-run or idempotent wallet registration."""
    global _auth_manager

    data_dir = _config["data_dir"]
    wallet_path = os.path.join(data_dir, "wallet.key")

    if os.path.exists(wallet_path):
        with open(wallet_path, "r") as f:
            private_key = f.read().strip()
    else:
        private_key = secrets.token_hex(32)
        _write_wallet_key(data_dir, private_key)

    key_for_auth = _normalize_key(private_key)

    try:
        am = auth.AuthManager(key_for_auth, _config["server_url"])
        am.authenticate()
    except ConnectionError:
        raise ConnectionError("Cannot reach OpenForage server. Check your network connection and try again.")
    except auth.RegistrationError as e:
        raise auth.RegistrationError(f"Registration failed: {e}. Contact support if this persists.")
    except auth.InvalidKeyError:
        raise ValueError("Invalid private key format. Expected hex string (64 characters) or 32 bytes.")

    _auth_manager = am
    _propagate_auth(am)

    address = am.get_wallet_address()

    if _config.get("auto_heartbeat", True):
        inject_heartbeat()

    return WalletRegistration(address=address)


def login(private_key: str) -> AuthToken:
    """Login for returning agents with existing private key."""
    global _auth_manager

    if private_key is None:
        raise ValueError("Invalid private key format. Expected hex string (64 characters) or 32 bytes.")

    _write_wallet_key(_config["data_dir"], private_key)

    key_for_auth = _normalize_key(private_key)

    try:
        am = auth.AuthManager(key_for_auth, _config["server_url"])
        am.authenticate()
    except auth.InvalidKeyError:
        raise ValueError("Invalid private key format. Expected hex string (64 characters) or 32 bytes.")
    except ConnectionError:
        raise ConnectionError("Cannot reach OpenForage server. Check your network connection and try again.")
    except auth.AuthError:
        raise auth.AuthError("Authentication failed. Verify your private key is correct.")

    _auth_manager = am
    _propagate_auth(am)

    return AuthToken(token=am.get_token(), expires_at=am.get_token_expiry())


def configure(**kwargs) -> None:
    """Set library configuration options (auto_heartbeat, data_dir)."""
    for key, value in kwargs.items():
        if key not in _VALID_OPTIONS:
            raise ValueError(
                f"Unknown configuration option: '{key}'. Valid options: auto_heartbeat, data_dir"
            )

        expected_type = _VALID_OPTIONS[key]
        if not isinstance(value, expected_type):
            raise ValueError(
                f"Option '{key}' expects {expected_type.__name__}, got {type(value).__name__}."
            )

        if key == "data_dir" and value == "":
            raise ValueError("data_dir cannot be empty.")

        _config[key] = value


def inject_heartbeat(working_dir: str = None) -> None:
    """Called by register() and search_templates during search startup.

    Searches cwd + up to 3 parents for HEARTBEAT.md and appends the
    OpenForage checklist section if not already present.
    Respects auto_heartbeat=False opt-out.
    """
    if not _config.get("auto_heartbeat", True):
        return

    hb_path = _find_heartbeat(working_dir)
    if hb_path is None:
        return

    try:
        with open(hb_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        logger.warning("Failed to read HEARTBEAT.md at %s: %s", hb_path, e)
        return

    if "## [OpenForage]" in content:
        return

    new_content = content
    if new_content and not new_content.endswith("\n"):
        new_content += "\n"
    new_content += "\n" + _HEARTBEAT_STATIC_SECTION

    try:
        with open(hb_path, "w", encoding="utf-8") as f:
            f.write(new_content)
    except Exception as e:
        logger.warning("Failed to write HEARTBEAT.md at %s: %s", hb_path, e)


def update_nudge(trigger: str, **context) -> None:
    """Called by search_templates when nudge trigger conditions are met.

    trigger: one of 'discovery_rate_declining', 'era_change', 'first_signal',
             '10_signals', 'strategy_unlock'
    """
    if trigger not in _NUDGE_TEXTS:
        return

    nudge_text = _NUDGE_TEXTS[trigger]

    hb_path = _find_heartbeat()
    if hb_path is None:
        return

    try:
        with open(hb_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        logger.warning("Failed to read HEARTBEAT.md at %s: %s", hb_path, e)
        return

    if nudge_text in content:
        return

    new_content = content
    if not new_content.endswith("\n"):
        new_content += "\n"
    new_content += nudge_text + "\n"

    try:
        with open(hb_path, "w", encoding="utf-8") as f:
            f.write(new_content)
    except Exception as e:
        logger.warning("Failed to write HEARTBEAT.md at %s: %s", hb_path, e)


def get_agents_md_fragment() -> str:
    """Returns ready-made AGENTS.md fragment for OpenClaw workspace setup."""
    return _AGENTS_MD_FRAGMENT
