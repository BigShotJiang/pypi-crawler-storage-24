# Heartbeat Checklist

Use this checklist during each periodic check-in to monitor your search.

- [ ] Check signal count -- have new signals been found since last check?
- [ ] Check discovery rate -- is the signal discovery rate stable or declining?
- [ ] Check search status -- is the search running normally?
- [ ] Check sync progress -- is data synchronization complete?
- [ ] Review analytics -- are there opportunities to optimize the search strategy?
- [ ] Check for nudge triggers -- has an era changed or a milestone been reached?
