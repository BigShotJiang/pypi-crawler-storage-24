# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Submit subcomponent — client-side signal and strategy submission."""

import json
import urllib.request
import urllib.error
from typing import Callable


class SubmissionReceipt:
    """Receipt returned after successful signal/strategy submission."""

    def __init__(self, submission_id: str):
        self.submission_id = submission_id


class SubmissionStatus:
    """Status returned by poll_status for a submitted signal/strategy."""

    def __init__(
        self,
        submission_id: str,
        status: str,
        is_stats: dict,
        os_stats: dict | None,
        payment: dict | None,
        rejection_reason: str | None,
    ):
        self.submission_id = submission_id
        self.status = status
        self.is_stats = is_stats
        self.os_stats = os_stats
        self.payment = payment
        self.rejection_reason = rejection_reason


class SubmissionRejectedError(Exception):
    """Raised when the server rejects a submission or poll request."""

    def __init__(self, status_code: int, reason: str, details: dict | None = None):
        super().__init__(f"{status_code}: {reason}")
        self.status_code = status_code
        self.reason = reason
        self.details = details


def _do_http_request(method: str, url: str, headers: dict | None = None, body_bytes: bytes | None = None) -> tuple[int, bytes]:
    """Make an HTTP request. Returns (status_code, response_body_bytes).

    Raises ConnectionError on network failure.
    """
    req = urllib.request.Request(url, data=body_bytes, headers=headers or {}, method=method)
    try:
        resp = urllib.request.urlopen(req)
        return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read() if e.fp else b""
    except (urllib.error.URLError, OSError, ConnectionRefusedError) as e:
        raise ConnectionError(f"Failed to connect to {url}: {e}") from e


def _handle_error_response(status_code: int, response_body_bytes: bytes) -> None:
    """Parse error response and raise SubmissionRejectedError."""
    reason = "unknown"
    details = None
    try:
        resp_data = json.loads(response_body_bytes)
        reason = resp_data.get("reason", "unknown")
        details = resp_data.get("details", None)
    except (json.JSONDecodeError, ValueError):
        reason = response_body_bytes.decode("utf-8", errors="replace") if response_body_bytes else "unknown"
    raise SubmissionRejectedError(status_code, reason, details)


def _post_submission(endpoint: str, body: dict, get_token: Callable[[], str], server_url: str) -> SubmissionReceipt:
    """POST a submission body to the given endpoint and return a receipt.

    Shared logic for submit_signal and submit_strategy.
    Retries up to 3 times with exponential backoff on ConnectionError only.
    """
    import time

    max_attempts = 3
    base_delay = 1.0
    max_delay = 30.0

    for attempt in range(max_attempts):
        token = get_token()
        url = f"{server_url.rstrip('/')}/{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

        try:
            status_code, resp_body = _do_http_request(
                "POST", url, headers=headers,
                body_bytes=json.dumps(body).encode("utf-8"),
            )
        except ConnectionError:
            if attempt == max_attempts - 1:
                raise
            time.sleep(min(base_delay * (2 ** attempt), max_delay))
            continue

        if not 200 <= status_code < 300:
            _handle_error_response(status_code, resp_body)

        return SubmissionReceipt(submission_id=json.loads(resp_body)["submission_id"])

    # Should not be reached, but ConnectionError on all attempts
    raise ConnectionError(f"Failed to connect to {server_url} after {max_attempts} attempts")


def submit_signal(
    graph: dict,
    universe_id: str,
    is_stats: dict,
    is_mi: float,
    metaparameters: dict | None,
    search_state: dict,
    get_token: Callable[[], str],
    server_url: str,
) -> SubmissionReceipt:
    """Submit a signal via POST /signals/submit."""
    body = {
        "graph": graph,
        "universe_id": universe_id,
        "is_stats": is_stats,
        "is_mi": is_mi,
        "metaparameters": metaparameters,
        "search_state": search_state,
    }
    return _post_submission("signals/submit", body, get_token, server_url)


def submit_strategy(
    graph: dict,
    universe_id: str,
    is_stats: dict,
    is_mi: float,
    metaparameters: dict | None,
    referenced_signal_ids: list,
    search_state: dict,
    get_token: Callable[[], str],
    server_url: str,
) -> SubmissionReceipt:
    """Submit a strategy via POST /strategies/submit."""
    body = {
        "graph": graph,
        "universe_id": universe_id,
        "is_stats": is_stats,
        "is_mi": is_mi,
        "metaparameters": metaparameters,
        "search_state": search_state,
        "referenced_signal_ids": referenced_signal_ids,
    }
    return _post_submission("strategies/submit", body, get_token, server_url)


def poll_status(
    submission_id: str,
    submission_type: str,
    get_token: Callable[[], str],
    server_url: str,
) -> SubmissionStatus:
    """Poll submission status via GET /signals/status/{id} or /strategies/status/{id}."""
    if submission_type not in ("signal", "strategy"):
        raise ValueError(f"submission_type must be 'signal' or 'strategy', got '{submission_type}'.")

    token = get_token()
    plural = "signals" if submission_type == "signal" else "strategies"
    url = f"{server_url.rstrip('/')}/{plural}/status/{submission_id}"
    headers = {"Authorization": f"Bearer {token}"}

    status_code, resp_body = _do_http_request("GET", url, headers=headers)

    if not 200 <= status_code < 300:
        _handle_error_response(status_code, resp_body)

    resp_data = json.loads(resp_body)
    return SubmissionStatus(
        submission_id=resp_data["submission_id"],
        status=resp_data["status"],
        is_stats=resp_data.get("is_stats", {}),
        os_stats=resp_data.get("os_stats"),
        payment=resp_data.get("payment"),
        rejection_reason=resp_data.get("rejection_reason"),
    )
