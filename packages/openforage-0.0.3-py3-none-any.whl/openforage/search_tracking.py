# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Search tracking subcomponent — SQLite-backed evaluation and submission tracking."""

import json
import logging
import os
import shutil
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("openforage.search_tracking")


@dataclass
class FunctionStats:
    """Per-function usage statistics."""
    function_name: str = ""
    rotation_family: Optional[str] = None
    total_evaluations: int = 0
    passed_evaluations: int = 0
    yield_rate: float = 0.0


@dataclass
class FeatureStats:
    """Per-feature usage statistics."""
    feature_name: str = ""
    total_evaluations: int = 0
    passed_evaluations: int = 0
    yield_rate: float = 0.0


@dataclass
class EvaluationRecord:
    """Full evaluation record from history query."""
    eval_id: int = 0
    eval_type: str = ""
    era_id: int = 0
    timestamp: float = 0.0
    universe_id: str = ""
    metaparameters: Optional[dict] = None
    graph: Optional[dict] = None
    tree_depth: int = 0
    passed_thresholds: bool = False
    sharpe: float = 0.0
    returns: float = 0.0
    turnover: float = 0.0
    drawdown: float = 0.0
    delta_exposure: float = 0.0
    max_weight: float = 0.0
    quality_score: float = 0.0
    correlation: float = 0.0
    per_column_stats: Optional[dict] = None
    rejection_reason: Optional[str] = None
    functions: Optional[list] = None
    features: Optional[list] = None
    rotation_families_used: Optional[list] = None
    referenced_signal_ids: Optional[list] = None
    source: str = ""
    submitted: bool = False
    liquidity_metrics: Optional[dict] = None


@dataclass
class PerColumnStatsRecord:
    """Lightweight per-column stats record."""
    eval_id: int = 0
    eval_type: str = ""
    passed_thresholds: bool = False
    per_column_stats: Optional[dict] = None
    rejection_reason: Optional[str] = None
    source: str = ""


@dataclass
class RejectionCount:
    """Aggregated rejection count."""
    rejection_reason: str = ""
    count: int = 0
    percentage: float = 0.0


@dataclass
class AutoMetadata:
    """Auto-generated submission metadata."""
    expression_complexity: int = 0
    submission_date: float = 0.0
    rotation_families_used: list = field(default_factory=list)


@dataclass
class CooccurrencePair:
    """Function pair co-occurrence."""
    function_a: str = ""
    function_b: str = ""
    total_cooccurrences: int = 0
    passed_cooccurrences: int = 0


@dataclass
class VelocityStats:
    """Evaluation rate statistics."""
    window_minutes: int = 0
    total_evaluations: int = 0
    passed_evaluations: int = 0
    evaluations_per_hour: float = 0.0
    passes_per_hour: float = 0.0


@dataclass
class DeleteResult:
    """Result of delete operation."""
    signal_rows_deleted: int = 0
    strategy_rows_deleted: int = 0
    signal_rows_remaining: int = 0
    strategy_rows_remaining: int = 0


@dataclass
class DatabaseInfo:
    """Database size and row counts."""
    file_size_bytes: int = 0
    signal_evaluation_count: int = 0
    strategy_evaluation_count: int = 0
    signal_passed_count: int = 0
    strategy_passed_count: int = 0


@dataclass
class SubmissionQueueItem:
    """Item from submission queue."""
    queue_id: int = 0
    eval_id: int = 0
    eval_type: str = ""
    payload_json: str = ""
    era_id: int = 0
    priority: int = 0
    created_at: float = 0.0


@dataclass
class PendingSubmission:
    """Non-finalized submission status."""
    status_id: int = 0
    eval_id: int = 0
    eval_type: str = ""
    submission_id: str = ""
    era_id: int = 0
    status: str = ""
    submitted_at: float = 0.0
    last_polled_at: Optional[float] = None
    finalized_at: Optional[float] = None
    is_stats_json: Optional[str] = None
    os_stats_json: Optional[str] = None
    payment_json: Optional[str] = None
    rejection_reason: Optional[str] = None


@dataclass
class SubmissionCounts:
    """Aggregated submission counts."""
    queued: int = 0
    pending: int = 0
    accepted: int = 0
    rejected: int = 0
    retrying: int = 0
    discarded: int = 0
    total: int = 0


@dataclass
class SubmissionRetryItem:
    """Item from retry queue."""
    retry_id: int = 0
    eval_id: int = 0
    eval_type: str = ""
    payload_json: str = ""
    era_id: int = 0
    retry_count: int = 0
    last_rejection_reason: str = ""
    retry_after: Optional[float] = None
    created_at: float = 0.0


@dataclass
class RetryCounts:
    """Retry queue aggregates."""
    retrying: int = 0
    ready: int = 0


@dataclass
class BacktestStats:
    """Backtest statistics used as input to record methods."""
    sharpe: float = 0.0
    returns: float = 0.0
    turnover: float = 0.0
    drawdown: float = 0.0
    delta_exposure: float = 0.0
    max_weight: float = 0.0
    quality_score: float = 0.0
    correlation: float = 0.0
    liquidity_metrics: dict = field(default_factory=dict)
    custom_stats: dict = field(default_factory=dict)


# Valid statuses for submission_status
VALID_STATUSES = [
    "pending", "is_validating", "found", "is_rejected",
    "os_validating", "os_passed", "os_failed", "useful", "not_useful",
]
TERMINAL_STATUSES = {"found", "is_rejected", "useful", "not_useful", "os_failed"}

# Disk space threshold in bytes (500 MB)
_DISK_THRESHOLD = 500 * 1024 * 1024

# Table triplets: (eval_table, function_usage_table, feature_usage_table)
_SIGNAL_TABLES = ("signal_evaluations", "signal_function_usage", "signal_feature_usage")
_STRATEGY_TABLES = ("strategy_evaluations", "strategy_function_usage", "strategy_feature_usage")


def _compute_tree_depth(graph):
    """Compute the depth of an expression graph."""
    if not graph:
        return 0
    children = graph.get("children", [])
    if not children:
        return 1
    return 1 + max(_compute_tree_depth(c) for c in children)


def _extract_names(graph, node_type):
    """Extract names from expression graph. Canonical schema: {type, node, children}.

    node_type="function" matches rotation/filtration/reduction nodes.
    node_type="feature" matches feature nodes.
    """
    if not graph:
        return []
    names = []
    gtype = graph.get("type")
    if node_type == "function" and gtype in ("rotation", "filtration", "reduction"):
        name = graph.get("node")
        if name:
            names.append(name)
    elif gtype == node_type:
        name = graph.get("node")
        if name:
            names.append(name)
    for child in graph.get("children", []):
        names.extend(_extract_names(child, node_type))
    return names


def _validate_eval_type(eval_type):
    """Validate eval_type parameter for query methods (None allowed)."""
    if eval_type is not None and eval_type not in ("signal", "strategy"):
        raise ValueError("eval_type must be 'signal', 'strategy', or None")


def _validate_eval_type_strict(eval_type):
    """Validate eval_type parameter (must be 'signal' or 'strategy')."""
    if eval_type not in ("signal", "strategy"):
        raise ValueError("eval_type must be 'signal' or 'strategy'")


def _validate_source_record(source):
    """Validate source parameter for record methods."""
    if source not in ("search", "simulate"):
        raise ValueError(f"source must be 'search' or 'simulate', got '{source}'.")


def _validate_source_query(source):
    """Validate source parameter for query methods."""
    if source is not None and source not in ("search", "simulate"):
        raise ValueError("source must be 'search', 'simulate', or None")


def _filter_by_eval_type(eval_type, signal_item, strategy_item):
    """Return items matching the eval_type filter (None = both)."""
    result = []
    if eval_type is None or eval_type == "signal":
        result.append(signal_item)
    if eval_type is None or eval_type == "strategy":
        result.append(strategy_item)
    return result


def _eval_table_pairs(eval_type):
    """Return (eval_table, type_label) pairs based on eval_type filter."""
    return _filter_by_eval_type(eval_type,
        ("signal_evaluations", "signal"), ("strategy_evaluations", "strategy"))


def _eval_table_triplets(eval_type):
    """Return (eval_table, fn_table, feat_table) triplets based on eval_type filter."""
    return _filter_by_eval_type(eval_type, _SIGNAL_TABLES, _STRATEGY_TABLES)


def _fn_usage_table_pairs(eval_type):
    """Return (fn_usage_table, eval_table) pairs based on eval_type filter."""
    return _filter_by_eval_type(eval_type,
        ("signal_function_usage", "signal_evaluations"),
        ("strategy_function_usage", "strategy_evaluations"))


def _feat_usage_table_pairs(eval_type):
    """Return (feat_usage_table, eval_table) pairs based on eval_type filter."""
    return _filter_by_eval_type(eval_type,
        ("signal_feature_usage", "signal_evaluations"),
        ("strategy_feature_usage", "strategy_evaluations"))


def _join_clauses(clauses, prefix="WHERE"):
    """Join filter clauses into a SQL fragment, or return empty string if none."""
    return (f"{prefix} " + " AND ".join(clauses)) if clauses else ""


def _build_settings_filter(table_alias, era_id, universe_id, metaparameters, source):
    """Build WHERE clause fragments for settings filtering on an eval table."""
    clauses = []
    params = []
    prefix = f"{table_alias}." if table_alias else ""
    if era_id is not None:
        clauses.append(f"{prefix}era_id = ?")
        params.append(era_id)
    if universe_id is not None:
        clauses.append(f"{prefix}universe_id = ?")
        params.append(universe_id)
    if metaparameters is not None:
        for key, val in metaparameters.items():
            clauses.append(f"json_extract({prefix}metaparameters, ?) = ?")
            params.append(f"$.{key}")
            params.append(val)
    if source is not None:
        clauses.append(f"{prefix}source = ?")
        params.append(source)
    return clauses, params


def _collect_rotation_families(functions, function_families):
    """Build deduplicated list of rotation families from function names."""
    if not function_families:
        return []
    seen = set()
    result = []
    for fn in functions:
        if fn in function_families:
            fam = function_families[fn][0]
            if fam not in seen:
                seen.add(fam)
                result.append(fam)
    return result


def _insert_usage_rows(conn, eval_id, functions, features,
                       fn_table, feat_table, function_families, feature_families):
    """Insert function and feature usage rows for an evaluation."""
    for fn in functions:
        rot_fam = fn_family = fn_subfamily = None
        if function_families and fn in function_families:
            rot_fam = fn_family = function_families[fn][0]
            fn_subfamily = function_families[fn][1]
        conn.execute(
            f"INSERT INTO {fn_table} "
            "(eval_id, function_name, rotation_family, function_family, function_subfamily) "
            "VALUES (?, ?, ?, ?, ?)",
            (eval_id, fn, rot_fam, fn_family, fn_subfamily)
        )
    for feat in features:
        feat_family = feat_subfamily = None
        if feature_families and feat in feature_families:
            feat_family = feature_families[feat][0]
            feat_subfamily = feature_families[feat][1]
        conn.execute(
            f"INSERT INTO {feat_table} "
            "(eval_id, feature_name, feature_family, feature_subfamily) "
            "VALUES (?, ?, ?, ?)",
            (eval_id, feat, feat_family, feat_subfamily)
        )


def _delete_eval_ids(conn, id_list, eval_table, fn_table, feat_table):
    """Delete evaluation rows and their linked function/feature usage rows."""
    if not id_list:
        return
    placeholders = ",".join("?" * len(id_list))
    conn.execute(f"DELETE FROM {fn_table} WHERE eval_id IN ({placeholders})", id_list)
    conn.execute(f"DELETE FROM {feat_table} WHERE eval_id IN ({placeholders})", id_list)
    conn.execute(f"DELETE FROM {eval_table} WHERE eval_id IN ({placeholders})", id_list)


class WriterThread:
    """Writer thread for batched DB writes."""

    def __init__(self, tracker, queue, search_status, stop_workers_callback):
        self._tracker = tracker
        self._queue = queue
        self._status = search_status
        self._stop_workers = stop_workers_callback
        self._stop_event = threading.Event()
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=5.0)

    def _drain_queue(self):
        """Drain all available items from the queue without blocking."""
        items = []
        while True:
            try:
                items.append(self._queue.get_nowait())
            except Exception as e:  # queue.Empty — break drain loop
                break  # No more items in queue
        return items

    def _run(self):
        batch = []
        last_flush_time = time.time()

        while not self._stop_event.is_set():
            batch.extend(self._drain_queue())

            now = time.time()
            if len(batch) >= 100 or (batch and now - last_flush_time >= 2.0):
                self._flush(batch)
                batch = []
                last_flush_time = time.time()
            else:
                self._stop_event.wait(timeout=0.1)

        # Drain remaining on stop
        batch.extend(self._drain_queue())
        if batch:
            self._flush(batch)

    def _flush(self, batch):
        """Flush a batch of items to the database."""
        try:
            usage = shutil.disk_usage(os.path.dirname(self._tracker._db_path))
            if usage.free < _DISK_THRESHOLD:
                self._status.error_code = "DISK_FULL"
                self._status.recovery_advice = (
                    "Free disk space or run delete_evaluations() to remove old data."
                )
                self._status.running = False
                self._stop_workers()
                self._stop_event.set()
                return
        except Exception as e:
            logger.warning("Disk space check failed: %s", e)

        try:
            self._do_write(batch)
        except Exception as e:
            time.sleep(0.5)
            try:
                self._do_write(batch)
            except Exception as e:
                self._status.error_code = "DATABASE_ERROR"
                self._status.recovery_advice = (
                    "Check database file permissions and disk space."
                )
                self._status.running = False
                self._status.errors.append(f"Database write failed: {e}")
                self._stop_workers()
                self._stop_event.set()

    def _do_write(self, batch):
        """Write a batch within a single transaction."""
        conn = self._tracker._conn
        conn.execute("BEGIN")
        try:
            for item in batch:
                self._write_evaluation(conn, item)
            conn.execute("COMMIT")
        except Exception as e:
            try:
                conn.execute("ROLLBACK")
            except Exception as e:  # Rollback failure: connection already gone
                pass
            raise

    def _write_evaluation(self, conn, item):
        """Write a single evaluation (signal or strategy) via the tracker's connection."""
        item_type = item.get("type", "signal")
        is_strategy = item_type == "strategy"

        graph = item.get("graph", {})
        stats = item.get("stats")
        era_id = item.get("era_id", 1)
        passed = item.get("passed_thresholds", True)
        universe_id = item.get("universe_id", "")
        metaparameters = item.get("metaparameters", {})
        func_families = item.get("function_families")
        feat_families = item.get("feature_families")
        per_column_stats = item.get("per_column_stats")
        rejection_reason = item.get("rejection_reason")
        source = item.get("source", "search")

        tree_depth = _compute_tree_depth(graph)
        functions = _extract_names(graph, "function")
        features = _extract_names(graph, "feature")
        rotation_families = _collect_rotation_families(functions, func_families)

        meta_json = json.dumps(metaparameters) if metaparameters else "{}"
        pcs_json = json.dumps(per_column_stats) if per_column_stats is not None else None
        lm_json = json.dumps(stats.liquidity_metrics) if stats is not None and stats.liquidity_metrics is not None else None

        base_cols = (
            "timestamp, era_id, graph_json, tree_depth, rotation_families_json, "
            "passed_thresholds, sharpe, returns, turnover, drawdown, "
            "delta_exposure, max_weight, quality_score, correlation, "
            "per_column_stats_json, rejection_reason, universe_id, "
            "metaparameters, submitted, liquidity_metrics_json, source"
        )
        base_vals = (
            time.time(), era_id, json.dumps(graph), tree_depth,
            json.dumps(rotation_families), 1 if passed else 0,
            stats.sharpe, stats.returns, stats.turnover, stats.drawdown,
            stats.delta_exposure, stats.max_weight, stats.quality_score,
            stats.correlation, pcs_json, rejection_reason,
            universe_id, meta_json, 0, lm_json, source
        )

        if is_strategy:
            ref_ids = item.get("referenced_signal_ids", [])
            table = "strategy_evaluations"
            cols = base_cols + ", referenced_signal_ids_json"
            vals = base_vals + (json.dumps(ref_ids),)
            fn_table, feat_table = "strategy_function_usage", "strategy_feature_usage"
        else:
            table = "signal_evaluations"
            cols = base_cols
            vals = base_vals
            fn_table, feat_table = "signal_function_usage", "signal_feature_usage"

        placeholders = ", ".join(["?"] * len(vals))
        cursor = conn.execute(
            f"INSERT INTO {table} ({cols}) VALUES ({placeholders})", vals
        )
        eval_id = cursor.lastrowid

        _insert_usage_rows(conn, eval_id, functions, features,
                           fn_table, feat_table, func_families, feat_families)


class _ConnWrapper:
    """Wrapper around sqlite3.Connection to allow monkey-patching execute."""

    def __init__(self, conn):
        self._real_conn = conn
        self.execute = conn.execute
        self.commit = conn.commit
        self.close = conn.close

    @property
    def in_transaction(self):
        return self._real_conn.in_transaction

    def __getattr__(self, name):
        return getattr(self._real_conn, name)


# SQL for the 9 tables
_SCHEMA_DDLS = [
    # Signal evaluations
    """CREATE TABLE IF NOT EXISTS signal_evaluations (
        eval_id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp REAL NOT NULL,
        era_id INTEGER NOT NULL,
        graph_json TEXT NOT NULL,
        tree_depth INTEGER NOT NULL,
        rotation_families_json TEXT,
        passed_thresholds INTEGER NOT NULL,
        sharpe REAL NOT NULL,
        returns REAL NOT NULL,
        turnover REAL NOT NULL,
        drawdown REAL NOT NULL,
        delta_exposure REAL NOT NULL,
        max_weight REAL NOT NULL,
        quality_score REAL NOT NULL,
        correlation REAL NOT NULL,
        per_column_stats_json TEXT,
        rejection_reason TEXT,
        universe_id TEXT NOT NULL,
        metaparameters TEXT NOT NULL,
        submitted INTEGER NOT NULL DEFAULT 0,
        liquidity_metrics_json TEXT,
        source TEXT NOT NULL DEFAULT 'search'
    )""",
    # Strategy evaluations
    """CREATE TABLE IF NOT EXISTS strategy_evaluations (
        eval_id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp REAL NOT NULL,
        era_id INTEGER NOT NULL,
        graph_json TEXT NOT NULL,
        tree_depth INTEGER NOT NULL,
        rotation_families_json TEXT,
        passed_thresholds INTEGER NOT NULL,
        sharpe REAL NOT NULL,
        returns REAL NOT NULL,
        turnover REAL NOT NULL,
        drawdown REAL NOT NULL,
        delta_exposure REAL NOT NULL,
        max_weight REAL NOT NULL,
        quality_score REAL NOT NULL,
        correlation REAL NOT NULL,
        per_column_stats_json TEXT,
        rejection_reason TEXT,
        universe_id TEXT NOT NULL,
        metaparameters TEXT NOT NULL,
        submitted INTEGER NOT NULL DEFAULT 0,
        liquidity_metrics_json TEXT,
        referenced_signal_ids_json TEXT,
        source TEXT NOT NULL DEFAULT 'search'
    )""",
    # Function/feature usage tables
    """CREATE TABLE IF NOT EXISTS signal_function_usage (
        eval_id INTEGER NOT NULL REFERENCES signal_evaluations(eval_id),
        function_name TEXT NOT NULL,
        rotation_family TEXT,
        function_family TEXT,
        function_subfamily TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS signal_feature_usage (
        eval_id INTEGER NOT NULL REFERENCES signal_evaluations(eval_id),
        feature_name TEXT NOT NULL,
        feature_family TEXT,
        feature_subfamily TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS strategy_function_usage (
        eval_id INTEGER NOT NULL REFERENCES strategy_evaluations(eval_id),
        function_name TEXT NOT NULL,
        rotation_family TEXT,
        function_family TEXT,
        function_subfamily TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS strategy_feature_usage (
        eval_id INTEGER NOT NULL REFERENCES strategy_evaluations(eval_id),
        feature_name TEXT NOT NULL,
        feature_family TEXT,
        feature_subfamily TEXT
    )""",
    # Submission queue
    """CREATE TABLE IF NOT EXISTS submission_queue (
        queue_id INTEGER PRIMARY KEY AUTOINCREMENT,
        eval_id INTEGER NOT NULL,
        eval_type TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        era_id INTEGER NOT NULL,
        priority INTEGER NOT NULL DEFAULT 0,
        created_at REAL NOT NULL
    )""",
    # Submission status
    """CREATE TABLE IF NOT EXISTS submission_status (
        status_id INTEGER PRIMARY KEY AUTOINCREMENT,
        eval_id INTEGER NOT NULL,
        eval_type TEXT NOT NULL,
        submission_id TEXT NOT NULL,
        era_id INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        submitted_at REAL NOT NULL,
        last_polled_at REAL,
        finalized_at REAL,
        is_stats_json TEXT,
        os_stats_json TEXT,
        payment_json TEXT,
        rejection_reason TEXT
    )""",
    # Submission retry
    """CREATE TABLE IF NOT EXISTS submission_retry (
        retry_id INTEGER PRIMARY KEY AUTOINCREMENT,
        eval_id INTEGER NOT NULL,
        eval_type TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        era_id INTEGER NOT NULL,
        retry_count INTEGER NOT NULL DEFAULT 0,
        last_rejection_reason TEXT NOT NULL,
        retry_after REAL,
        created_at REAL NOT NULL
    )""",
]

_SCHEMA_INDEXES = [
    # Signal evaluation indexes
    "CREATE INDEX IF NOT EXISTS idx_signal_era ON signal_evaluations(era_id)",
    "CREATE INDEX IF NOT EXISTS idx_signal_timestamp ON signal_evaluations(timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_signal_passed ON signal_evaluations(passed_thresholds)",
    "CREATE INDEX IF NOT EXISTS idx_signal_rejection ON signal_evaluations(rejection_reason)",
    "CREATE INDEX IF NOT EXISTS idx_signal_settings ON signal_evaluations(universe_id, metaparameters)",
    "CREATE INDEX IF NOT EXISTS idx_signal_source ON signal_evaluations(source)",
    # Strategy evaluation indexes
    "CREATE INDEX IF NOT EXISTS idx_strategy_era ON strategy_evaluations(era_id)",
    "CREATE INDEX IF NOT EXISTS idx_strategy_timestamp ON strategy_evaluations(timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_strategy_passed ON strategy_evaluations(passed_thresholds)",
    "CREATE INDEX IF NOT EXISTS idx_strategy_rejection ON strategy_evaluations(rejection_reason)",
    "CREATE INDEX IF NOT EXISTS idx_strategy_settings ON strategy_evaluations(universe_id, metaparameters)",
    "CREATE INDEX IF NOT EXISTS idx_strategy_source ON strategy_evaluations(source)",
    # Function/feature usage indexes
    "CREATE INDEX IF NOT EXISTS idx_sig_fn_eval ON signal_function_usage(eval_id)",
    "CREATE INDEX IF NOT EXISTS idx_sig_fn_name ON signal_function_usage(function_name)",
    "CREATE INDEX IF NOT EXISTS idx_sig_feat_eval ON signal_feature_usage(eval_id)",
    "CREATE INDEX IF NOT EXISTS idx_sig_feat_name ON signal_feature_usage(feature_name)",
    "CREATE INDEX IF NOT EXISTS idx_meta_fn_eval ON strategy_function_usage(eval_id)",
    "CREATE INDEX IF NOT EXISTS idx_meta_fn_name ON strategy_function_usage(function_name)",
    "CREATE INDEX IF NOT EXISTS idx_meta_feat_eval ON strategy_feature_usage(eval_id)",
    "CREATE INDEX IF NOT EXISTS idx_meta_feat_name ON strategy_feature_usage(feature_name)",
    # Submission table indexes
    "CREATE INDEX IF NOT EXISTS idx_subq_created ON submission_queue(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_subq_priority ON submission_queue(priority DESC, queue_id ASC)",
    "CREATE INDEX IF NOT EXISTS idx_substatus_submission ON submission_status(submission_id)",
    "CREATE INDEX IF NOT EXISTS idx_substatus_status ON submission_status(status)",
    "CREATE INDEX IF NOT EXISTS idx_substatus_eval ON submission_status(eval_id)",
    "CREATE INDEX IF NOT EXISTS idx_retry_era ON submission_retry(era_id)",
    "CREATE INDEX IF NOT EXISTS idx_retry_after ON submission_retry(retry_after)",
]


class SearchTracker:
    """SQLite-backed search evaluation and submission tracker."""

    def __init__(self, data_dir: str):
        if not data_dir:
            raise ValueError("data_dir must not be empty")
        if not os.path.isdir(data_dir):
            raise IOError(f"Directory does not exist: {data_dir}")

        self._data_dir = data_dir
        self._db_path = os.path.join(data_dir, "tracking.db")
        self._closed = False
        self._search_active = False

        raw_conn = sqlite3.connect(self._db_path, check_same_thread=False)
        wal_result = raw_conn.execute("PRAGMA journal_mode=WAL").fetchone()
        if wal_result is None or wal_result[0] != 'wal':
            actual = wal_result[0] if wal_result else 'unknown'
            raise IOError(
                f"WAL mode failed to activate (got '{actual}'). "
                f"Check that '{self._db_path}' is on a local filesystem with write access."
            )
        raw_conn.execute("PRAGMA foreign_keys=ON")
        raw_conn.execute("PRAGMA synchronous=NORMAL")
        self._conn = _ConnWrapper(raw_conn)

        self._create_tables()

    def _check_closed(self):
        if self._closed:
            raise IOError("SearchTracker is closed")

    def _create_tables(self):
        """Create all 9 tables and their indexes."""
        c = self._conn
        for ddl in _SCHEMA_DDLS:
            c.execute(ddl)
        for idx in _SCHEMA_INDEXES:
            c.execute(idx)
        if c.in_transaction:
            c.execute("COMMIT")

    def _validate_record_params(self, graph, era_id, universe_id, metaparameters,
                                 passed_thresholds, rejection_reason, source):
        """Validate common parameters for record methods."""
        if era_id <= 0:
            raise ValueError("era_id must be > 0")
        if not graph:
            raise ValueError("graph must not be empty")
        if not universe_id:
            raise ValueError("universe_id must not be empty")
        if not metaparameters or not isinstance(metaparameters, dict):
            raise ValueError("metaparameters must be a non-empty dict")
        for k, v in metaparameters.items():
            if not k or not v:
                raise ValueError("metaparameters must be a non-empty dict with non-empty keys and values")
        if passed_thresholds and rejection_reason is not None:
            raise ValueError("rejection_reason must be None when passed_thresholds is True")
        if not passed_thresholds and rejection_reason is not None and rejection_reason == "":
            raise ValueError("rejection_reason must not be empty string")
        _validate_source_record(source)

    def _insert_evaluation(self, graph, stats, era_id, passed_thresholds,
                            universe_id, metaparameters, function_families,
                            feature_families, per_column_stats, rejection_reason,
                            source, eval_table, fn_table, feat_table,
                            referenced_signal_ids=None):
        """Insert an evaluation row and its linked usage rows. Returns eval_id."""
        tree_depth = _compute_tree_depth(graph)
        functions = _extract_names(graph, "function")
        features = _extract_names(graph, "feature")
        rotation_families = _collect_rotation_families(functions, function_families)

        meta_json = json.dumps(metaparameters)
        pcs_json = json.dumps(per_column_stats) if per_column_stats is not None else None
        lm_json = json.dumps(stats.liquidity_metrics) if stats.liquidity_metrics is not None else None

        cols = [
            "timestamp", "era_id", "graph_json", "tree_depth", "rotation_families_json",
            "passed_thresholds", "sharpe", "returns", "turnover", "drawdown",
            "delta_exposure", "max_weight", "quality_score", "correlation",
            "per_column_stats_json", "rejection_reason", "universe_id",
            "metaparameters", "submitted", "liquidity_metrics_json",
        ]
        params = [
            time.time(), era_id, json.dumps(graph), tree_depth,
            json.dumps(rotation_families), 1 if passed_thresholds else 0,
            stats.sharpe, stats.returns, stats.turnover, stats.drawdown,
            stats.delta_exposure, stats.max_weight, stats.quality_score,
            stats.correlation, pcs_json, rejection_reason,
            universe_id, meta_json, 0, lm_json,
        ]

        if referenced_signal_ids is not None:
            cols.append("referenced_signal_ids_json")
            params.append(json.dumps(referenced_signal_ids))

        cols.append("source")
        params.append(source)

        placeholders = ", ".join(["?"] * len(cols))
        col_str = ", ".join(cols)
        cursor = self._conn.execute(
            f"INSERT INTO {eval_table} ({col_str}) VALUES ({placeholders})", params
        )

        eval_id = cursor.lastrowid

        _insert_usage_rows(self._conn, eval_id, functions, features,
                           fn_table, feat_table, function_families, feature_families)
        self._conn.commit()
        return eval_id

    def record_signal_evaluation(self, graph, stats, era_id, passed_thresholds,
                                  universe_id, metaparameters,
                                  function_families=None, feature_families=None,
                                  per_column_stats=None, rejection_reason=None,
                                  source='search'):
        self._check_closed()
        self._validate_record_params(graph, era_id, universe_id, metaparameters,
                                      passed_thresholds, rejection_reason, source)
        return self._insert_evaluation(
            graph, stats, era_id, passed_thresholds, universe_id, metaparameters,
            function_families, feature_families, per_column_stats, rejection_reason,
            source, *_SIGNAL_TABLES
        )

    def record_strategy_evaluation(self, graph, stats, era_id, passed_thresholds,
                                    referenced_signal_ids, universe_id, metaparameters,
                                    function_families=None, feature_families=None,
                                    per_column_stats=None, rejection_reason=None,
                                    source='search'):
        self._check_closed()
        self._validate_record_params(graph, era_id, universe_id, metaparameters,
                                      passed_thresholds, rejection_reason, source)
        if not referenced_signal_ids:
            raise ValueError("referenced_signal_ids must not be empty")
        return self._insert_evaluation(
            graph, stats, era_id, passed_thresholds, universe_id, metaparameters,
            function_families, feature_families, per_column_stats, rejection_reason,
            source, *_STRATEGY_TABLES,
            referenced_signal_ids=referenced_signal_ids
        )

    def _usage_stats_query(self, usage_tables, select_cols, group_cols, outer_cols,
                            era_id, universe_id, metaparameters, source):
        """Build and execute a usage stats query across signal/strategy tables.

        Args:
            usage_tables: list of (usage_table, eval_table) pairs
            select_cols: column expression for the inner SELECT (e.g. "fu.function_name, fu.rotation_family")
            group_cols: GROUP BY expression for the inner query
            outer_cols: column expression for the outer UNION aggregate SELECT
        Returns:
            list of row tuples from the query
        """
        queries = []
        all_params = []
        for usage_table, eval_table in usage_tables:
            clauses, params = _build_settings_filter("e", era_id, universe_id, metaparameters, source)
            where = _join_clauses(clauses, "AND")
            queries.append(f"""
                SELECT {select_cols},
                       COUNT(*) as total, SUM(e.passed_thresholds) as passed
                FROM {usage_table} fu
                JOIN {eval_table} e ON fu.eval_id = e.eval_id
                WHERE 1=1 {where}
                GROUP BY {group_cols}
            """)
            all_params.extend(params)

        if len(queries) == 1:
            sql = queries[0]
        else:
            union = " UNION ALL ".join(queries)
            sql = f"""
                SELECT {outer_cols},
                       SUM(total) as total, SUM(passed) as passed
                FROM ({union})
                GROUP BY {outer_cols}
            """

        return self._conn.execute(sql, all_params).fetchall()

    def get_function_stats(self, era_id=None, eval_type=None,
                           universe_id=None, metaparameters=None, source=None):
        self._check_closed()
        _validate_eval_type(eval_type)
        _validate_source_query(source)

        rows = self._usage_stats_query(
            _fn_usage_table_pairs(eval_type), "fu.function_name, fu.rotation_family",
            "fu.function_name, fu.rotation_family",
            "function_name, rotation_family",
            era_id, universe_id, metaparameters, source,
        )
        results = [
            FunctionStats(
                function_name=r[0], rotation_family=r[1],
                total_evaluations=r[2], passed_evaluations=r[3],
                yield_rate=r[3] / r[2] if r[2] > 0 else 0.0,
            )
            for r in rows
        ]
        results.sort(key=lambda x: (-x.yield_rate, -x.total_evaluations))
        return results

    def get_feature_stats(self, era_id=None, eval_type=None,
                          universe_id=None, metaparameters=None, source=None):
        self._check_closed()
        _validate_eval_type(eval_type)
        _validate_source_query(source)

        rows = self._usage_stats_query(
            _feat_usage_table_pairs(eval_type), "fu.feature_name",
            "fu.feature_name", "feature_name",
            era_id, universe_id, metaparameters, source,
        )
        results = [
            FeatureStats(
                feature_name=r[0], total_evaluations=r[1], passed_evaluations=r[2],
                yield_rate=r[2] / r[1] if r[1] > 0 else 0.0,
            )
            for r in rows
        ]
        results.sort(key=lambda x: (-x.yield_rate, -x.total_evaluations))
        return results

    def get_evaluation_history(self, era_id=None, eval_type=None,
                                passed_only=False, limit=1000, offset=0,
                                universe_id=None, metaparameters=None, source=None):
        self._check_closed()
        _validate_eval_type(eval_type)
        _validate_source_query(source)
        if limit is not None and limit < 1:
            raise ValueError("limit must be >= 1")
        if offset < 0:
            raise ValueError("offset must be >= 0")

        table_pairs = _eval_table_pairs(eval_type)
        single_table = len(table_pairs) == 1

        results = []
        for eval_table, etype in table_pairs:
            clauses, params = _build_settings_filter("", era_id, universe_id, metaparameters, source)
            if passed_only:
                clauses.append("passed_thresholds = 1")
            where = _join_clauses(clauses)

            extra_col = ", referenced_signal_ids_json" if etype == "strategy" else ""
            sql = f"""SELECT eval_id, timestamp, era_id, graph_json, tree_depth,
                             rotation_families_json, passed_thresholds, sharpe, returns,
                             turnover, drawdown, delta_exposure, max_weight,
                             quality_score, correlation, per_column_stats_json,
                             rejection_reason, universe_id, metaparameters,
                             submitted, liquidity_metrics_json, source
                             {extra_col}
                      FROM {eval_table} {where}
                      ORDER BY timestamp DESC"""
            if single_table and limit is not None:
                sql += f" LIMIT {limit + offset}"

            fn_table = "signal_function_usage" if etype == "signal" else "strategy_function_usage"
            feat_table = "signal_feature_usage" if etype == "signal" else "strategy_feature_usage"

            main_rows = self._conn.execute(sql, params).fetchall()
            if not main_rows:
                continue

            # Batch-fetch function and feature names (1 query each instead of N+1)
            eval_ids = [row[0] for row in main_rows]
            placeholders = ",".join("?" * len(eval_ids))
            fn_map: dict = {}
            for eval_id, fn_name in self._conn.execute(
                f"SELECT eval_id, function_name FROM {fn_table} WHERE eval_id IN ({placeholders})",
                eval_ids
            ):
                fn_map.setdefault(eval_id, []).append(fn_name)
            feat_map: dict = {}
            for eval_id, feat_name in self._conn.execute(
                f"SELECT eval_id, feature_name FROM {feat_table} WHERE eval_id IN ({placeholders})",
                eval_ids
            ):
                feat_map.setdefault(eval_id, []).append(feat_name)

            for row in main_rows:
                eval_id = row[0]
                ref_ids = None
                if etype == "strategy":
                    ref_raw = row[22]
                    ref_ids = json.loads(ref_raw) if ref_raw else None

                results.append(EvaluationRecord(
                    eval_id=eval_id,
                    eval_type=etype,
                    era_id=row[2],
                    timestamp=row[1],
                    universe_id=row[17],
                    metaparameters=json.loads(row[18]) if row[18] else None,
                    graph=json.loads(row[3]) if row[3] else None,
                    tree_depth=row[4],
                    passed_thresholds=bool(row[6]),
                    sharpe=row[7],
                    returns=row[8],
                    turnover=row[9],
                    drawdown=row[10],
                    delta_exposure=row[11],
                    max_weight=row[12],
                    quality_score=row[13],
                    correlation=row[14],
                    per_column_stats=json.loads(row[15]) if row[15] else None,
                    rejection_reason=row[16],
                    functions=fn_map.get(eval_id, []),
                    features=feat_map.get(eval_id, []),
                    rotation_families_used=json.loads(row[5]) if row[5] else [],
                    referenced_signal_ids=ref_ids,
                    source=row[21],
                    submitted=bool(row[19]),
                    liquidity_metrics=json.loads(row[20]) if row[20] else None,
                ))

        if not single_table:
            results.sort(key=lambda x: -x.timestamp)
        return results[offset:offset + limit]

    def get_per_column_stats_batch(self, era_id=None, eval_type=None,
                                    passed_only=None, limit=None, offset=0,
                                    universe_id=None, metaparameters=None, source=None):
        self._check_closed()
        _validate_eval_type(eval_type)
        _validate_source_query(source)
        if limit is not None and limit < 1:
            raise ValueError("limit must be >= 1")
        if offset < 0:
            raise ValueError("offset must be >= 0")

        results = []
        for eval_table, etype in _eval_table_pairs(eval_type):
            clauses, params = _build_settings_filter("", era_id, universe_id, metaparameters, source)
            if passed_only is True:
                clauses.append("passed_thresholds = 1")
            elif passed_only is False:
                clauses.append("passed_thresholds = 0")
            where = _join_clauses(clauses)

            sql = f"""SELECT eval_id, passed_thresholds, per_column_stats_json,
                             rejection_reason, source
                      FROM {eval_table} {where}
                      ORDER BY eval_id ASC"""
            for row in self._conn.execute(sql, params).fetchall():
                results.append(PerColumnStatsRecord(
                    eval_id=row[0],
                    eval_type=etype,
                    passed_thresholds=bool(row[1]),
                    per_column_stats=json.loads(row[2]) if row[2] else None,
                    rejection_reason=row[3],
                    source=row[4],
                ))

        results.sort(key=lambda x: x.eval_id)
        results = results[offset:]
        if limit is not None:
            results = results[:limit]
        return results

    def get_rejection_summary(self, era_id=None, eval_type=None,
                               universe_id=None, metaparameters=None, source=None):
        self._check_closed()
        _validate_eval_type(eval_type)
        _validate_source_query(source)

        queries = []
        all_params = []
        for eval_table, _ in _eval_table_pairs(eval_type):
            clauses, params = _build_settings_filter("", era_id, universe_id, metaparameters, source)
            clauses.append("rejection_reason IS NOT NULL")
            where = _join_clauses(clauses)
            queries.append(f"""
                SELECT rejection_reason, COUNT(*) as cnt
                FROM {eval_table} {where}
                GROUP BY rejection_reason
            """)
            all_params.extend(params)

        if len(queries) == 1:
            sql = queries[0]
        else:
            union = " UNION ALL ".join(queries)
            sql = f"""
                SELECT rejection_reason, SUM(cnt) as cnt
                FROM ({union})
                GROUP BY rejection_reason
            """

        rows = self._conn.execute(sql, all_params).fetchall()
        total_count = sum(r[1] for r in rows)
        results = [
            RejectionCount(
                rejection_reason=r[0], count=r[1],
                percentage=r[1] / total_count if total_count > 0 else 0.0,
            )
            for r in rows
        ]
        results.sort(key=lambda x: -x.count)
        return results

    def get_auto_metadata(self, eval_id):
        self._check_closed()
        for table in ("signal_evaluations", "strategy_evaluations"):
            row = self._conn.execute(
                f"SELECT tree_depth, timestamp, rotation_families_json FROM {table} WHERE eval_id=?",
                (eval_id,)
            ).fetchone()
            if row is not None:
                return AutoMetadata(
                    expression_complexity=row[0],
                    submission_date=row[1],
                    rotation_families_used=json.loads(row[2]) if row[2] else [],
                )
        raise ValueError(f"Evaluation with eval_id={eval_id} not found")

    def get_function_cooccurrence(self, era_id=None, eval_type=None,
                                   passed_only=False, universe_id=None,
                                   metaparameters=None, source=None):
        self._check_closed()
        _validate_eval_type(eval_type)
        _validate_source_query(source)

        results_dict = {}

        for fn_table, eval_table in _fn_usage_table_pairs(eval_type):
            clauses, params = _build_settings_filter("e", era_id, universe_id, metaparameters, source)
            if passed_only:
                clauses.append("e.passed_thresholds = 1")
            where = _join_clauses(clauses, "AND")

            sql = f"""
                SELECT f1.function_name, f2.function_name, e.passed_thresholds
                FROM {fn_table} f1
                JOIN {fn_table} f2 ON f1.eval_id = f2.eval_id AND f1.function_name < f2.function_name
                JOIN {eval_table} e ON f1.eval_id = e.eval_id
                WHERE 1=1 {where}
            """
            for row in self._conn.execute(sql, params).fetchall():
                pair = (row[0], row[1])
                if pair not in results_dict:
                    results_dict[pair] = [0, 0]
                results_dict[pair][0] += 1
                results_dict[pair][1] += row[2]

        results = [
            CooccurrencePair(
                function_a=fn_a, function_b=fn_b,
                total_cooccurrences=total, passed_cooccurrences=passed,
            )
            for (fn_a, fn_b), (total, passed) in results_dict.items()
        ]
        results.sort(key=lambda x: (-x.total_cooccurrences, x.function_a, x.function_b))
        return results

    def get_evaluation_velocity(self, window_minutes=60, eval_type=None):
        self._check_closed()
        _validate_eval_type(eval_type)
        if window_minutes < 1:
            raise ValueError("window_minutes must be >= 1")

        cutoff = time.time() - window_minutes * 60

        total = 0
        passed = 0
        for eval_table, _ in _eval_table_pairs(eval_type):
            row = self._conn.execute(
                f"SELECT COUNT(*), SUM(passed_thresholds) FROM {eval_table} WHERE timestamp >= ?",
                (cutoff,)
            ).fetchone()
            total += row[0] or 0
            passed += row[1] or 0

        hours = window_minutes / 60.0
        return VelocityStats(
            window_minutes=window_minutes,
            total_evaluations=total,
            passed_evaluations=passed,
            evaluations_per_hour=total / hours if hours > 0 else 0.0,
            passes_per_hour=passed / hours if hours > 0 else 0.0,
        )

    def get_evaluation_count(self, era_id=None, eval_type=None,
                              universe_id=None, metaparameters=None, source=None):
        self._check_closed()
        _validate_eval_type(eval_type)
        _validate_source_query(source)

        total = 0
        for eval_table, _ in _eval_table_pairs(eval_type):
            clauses, params = _build_settings_filter("", era_id, universe_id, metaparameters, source)
            where = _join_clauses(clauses)
            row = self._conn.execute(
                f"SELECT COUNT(*) FROM {eval_table} {where}", params
            ).fetchone()
            total += row[0]
        return total

    def handle_era_transition(self, new_era_id, previous_era_id=None):
        self._check_closed()
        if new_era_id <= 0:
            raise ValueError("era_id must be > 0")
        if previous_era_id is not None:
            if previous_era_id <= 0:
                raise ValueError("era_id must be > 0")
            if previous_era_id >= new_era_id:
                raise ValueError(f"previous_era_id ({previous_era_id}) must be < new_era_id ({new_era_id})")

        keep_eras = {new_era_id}
        if previous_era_id is not None:
            keep_eras.add(previous_era_id)
        era_list = list(keep_eras)
        era_placeholders = ",".join("?" * len(era_list))

        for eval_table, fn_table, feat_table in (_SIGNAL_TABLES, _STRATEGY_TABLES):
            ids_to_delete = [
                r[0] for r in self._conn.execute(
                    f"SELECT eval_id FROM {eval_table} WHERE era_id NOT IN ({era_placeholders})",
                    era_list
                ).fetchall()
            ]

            if ids_to_delete:
                _delete_eval_ids(self._conn, ids_to_delete, eval_table, fn_table, feat_table)

            remaining = self._conn.execute(f"SELECT COUNT(*) FROM {eval_table}").fetchone()[0]
            if remaining == 0:
                self._conn.execute("DELETE FROM sqlite_sequence WHERE name=?", (eval_table,))

        # Submission queue: 1-era retention (only new era)
        self._conn.execute("DELETE FROM submission_queue WHERE era_id != ?", (new_era_id,))
        if self._conn.execute("SELECT COUNT(*) FROM submission_queue").fetchone()[0] == 0:
            self._conn.execute("DELETE FROM sqlite_sequence WHERE name='submission_queue'")

        # Submission retry: entire table cleared
        self._conn.execute("DELETE FROM submission_retry")
        self._conn.execute("DELETE FROM sqlite_sequence WHERE name='submission_retry'")

        # Submission status: terminal old-era rows deleted
        terminal_list = list(TERMINAL_STATUSES)
        placeholders = ",".join("?" * len(terminal_list))
        self._conn.execute(
            f"DELETE FROM submission_status WHERE era_id != ? AND status IN ({placeholders})",
            [new_era_id] + terminal_list
        )

        self._conn.commit()

    def mark_submitted(self, eval_id, eval_type='signal'):
        self._check_closed()
        _validate_eval_type_strict(eval_type)

        table = "signal_evaluations" if eval_type == "signal" else "strategy_evaluations"
        if self._conn.execute(f"SELECT eval_id FROM {table} WHERE eval_id=?", (eval_id,)).fetchone() is None:
            raise ValueError(f"eval_id={eval_id} not found in {table}")

        self._conn.execute(f"UPDATE {table} SET submitted=1 WHERE eval_id=?", (eval_id,))
        self._conn.commit()

    def enqueue_submission(self, eval_id, eval_type, payload_json, era_id):
        self._check_closed()
        _validate_eval_type_strict(eval_type)
        if not payload_json:
            raise ValueError("payload_json must not be empty")
        if era_id <= 0:
            raise ValueError("era_id must be > 0")

        cursor = self._conn.execute(
            """INSERT INTO submission_queue
            (eval_id, eval_type, payload_json, era_id, priority, created_at)
            VALUES (?, ?, ?, ?, 0, ?)""",
            (eval_id, eval_type, payload_json, era_id, time.time())
        )
        self._conn.commit()
        return cursor.lastrowid

    def dequeue_submission(self):
        self._check_closed()
        row = self._conn.execute(
            """SELECT queue_id, eval_id, eval_type, payload_json, era_id, priority, created_at
               FROM submission_queue
               ORDER BY priority DESC, queue_id ASC
               LIMIT 1"""
        ).fetchone()

        if row is None:
            return None

        self._conn.execute("DELETE FROM submission_queue WHERE queue_id=?", (row[0],))
        self._conn.commit()

        return SubmissionQueueItem(
            queue_id=row[0], eval_id=row[1], eval_type=row[2],
            payload_json=row[3], era_id=row[4], priority=row[5], created_at=row[6],
        )

    def record_submission(self, eval_id, eval_type, submission_id, era_id):
        self._check_closed()
        _validate_eval_type_strict(eval_type)
        if not submission_id:
            raise ValueError("submission_id must not be empty")

        cursor = self._conn.execute(
            """INSERT INTO submission_status
            (eval_id, eval_type, submission_id, era_id, status, submitted_at)
            VALUES (?, ?, ?, ?, 'pending', ?)""",
            (eval_id, eval_type, submission_id, era_id, time.time())
        )
        self._conn.commit()
        return cursor.lastrowid

    def update_submission_status(self, submission_id, status,
                                  is_stats_json=None, os_stats_json=None,
                                  payment_json=None, rejection_reason=None):
        self._check_closed()
        if status not in VALID_STATUSES:
            raise ValueError(f"status must be one of {VALID_STATUSES}, got '{status}'")

        if self._conn.execute(
            "SELECT status_id FROM submission_status WHERE submission_id=?", (submission_id,)
        ).fetchone() is None:
            raise ValueError(f"submission_id='{submission_id}' not found")

        now = time.time()
        self._conn.execute(
            """UPDATE submission_status
               SET status=?, last_polled_at=?, finalized_at=COALESCE(?, finalized_at),
                   is_stats_json=COALESCE(?, is_stats_json),
                   os_stats_json=COALESCE(?, os_stats_json),
                   payment_json=COALESCE(?, payment_json),
                   rejection_reason=COALESCE(?, rejection_reason)
               WHERE submission_id=?""",
            (status, now,
             now if status in TERMINAL_STATUSES else None,
             is_stats_json, os_stats_json, payment_json, rejection_reason,
             submission_id)
        )
        self._conn.commit()

    def get_pending_submissions(self):
        self._check_closed()
        rows = self._conn.execute(
            """SELECT status_id, eval_id, eval_type, submission_id, era_id,
                      status, submitted_at, last_polled_at, finalized_at,
                      is_stats_json, os_stats_json, payment_json, rejection_reason
               FROM submission_status
               WHERE finalized_at IS NULL
               ORDER BY submitted_at ASC"""
        ).fetchall()

        return [PendingSubmission(
            status_id=r[0], eval_id=r[1], eval_type=r[2], submission_id=r[3],
            era_id=r[4], status=r[5], submitted_at=r[6], last_polled_at=r[7],
            finalized_at=r[8], is_stats_json=r[9], os_stats_json=r[10],
            payment_json=r[11], rejection_reason=r[12],
        ) for r in rows]

    def _count_where(self, table, where_clause="", params=()):
        """Execute SELECT COUNT(*) with optional WHERE clause."""
        sql = f"SELECT COUNT(*) FROM {table}"
        if where_clause:
            sql += f" WHERE {where_clause}"
        return self._conn.execute(sql, params).fetchone()[0]

    def get_submission_counts(self, era_id=None, discarded_count=0):
        self._check_closed()
        era_filter = "era_id=?" if era_id is not None else ""
        era_params = (era_id,) if era_id is not None else ()

        queued = self._count_where("submission_queue", era_filter, era_params)

        pending_where = "finalized_at IS NULL"
        if era_id is not None:
            pending_where += " AND era_id=?"
        pending = self._count_where("submission_status", pending_where, era_params)

        accepted_where = "status IN (?, ?)"
        accepted_params = ("found", "useful")
        if era_id is not None:
            accepted_where += " AND era_id=?"
            accepted_params += (era_id,)
        accepted = self._count_where("submission_status", accepted_where, accepted_params)

        rejected_where = "status IN (?, ?, ?)"
        rejected_params = ("is_rejected", "not_useful", "os_failed")
        if era_id is not None:
            rejected_where += " AND era_id=?"
            rejected_params += (era_id,)
        rejected = self._count_where("submission_status", rejected_where, rejected_params)

        retrying = self._count_where("submission_retry", era_filter, era_params)

        total = queued + pending + accepted + rejected + retrying

        return SubmissionCounts(
            queued=queued, pending=pending, accepted=accepted,
            rejected=rejected, retrying=retrying,
            discarded=discarded_count, total=total,
        )

    def enqueue_retry(self, eval_id, eval_type, payload_json, era_id,
                       rejection_reason, retry_after=None):
        self._check_closed()
        _validate_eval_type_strict(eval_type)
        if not payload_json:
            raise ValueError("payload_json must not be empty")
        if not rejection_reason:
            raise ValueError("rejection_reason must not be empty")

        cursor = self._conn.execute(
            """INSERT INTO submission_retry
            (eval_id, eval_type, payload_json, era_id, retry_count,
             last_rejection_reason, retry_after, created_at)
            VALUES (?, ?, ?, ?, 0, ?, ?, ?)""",
            (eval_id, eval_type, payload_json, era_id,
             rejection_reason, retry_after, time.time())
        )
        self._conn.commit()
        return cursor.lastrowid

    def dequeue_retryable(self):
        self._check_closed()
        now = time.time()
        row = self._conn.execute(
            """SELECT retry_id, eval_id, eval_type, payload_json, era_id,
                      retry_count, last_rejection_reason, retry_after, created_at
               FROM submission_retry
               WHERE retry_count < 5 AND (retry_after IS NULL OR retry_after <= ?)
               ORDER BY created_at ASC
               LIMIT 1""",
            (now,)
        ).fetchone()

        if row is None:
            return None

        self._conn.execute("DELETE FROM submission_retry WHERE retry_id=?", (row[0],))
        self._conn.commit()

        return SubmissionRetryItem(
            retry_id=row[0], eval_id=row[1], eval_type=row[2],
            payload_json=row[3], era_id=row[4], retry_count=row[5],
            last_rejection_reason=row[6], retry_after=row[7], created_at=row[8],
        )

    def increment_retry(self, retry_id, eval_id, eval_type, payload_json,
                         era_id, rejection_reason, retry_count, retry_after=None):
        self._check_closed()
        self._conn.execute(
            "DELETE FROM submission_retry WHERE eval_id=? AND eval_type=?",
            (eval_id, eval_type)
        )
        self._conn.execute(
            """INSERT INTO submission_retry
            (eval_id, eval_type, payload_json, era_id, retry_count,
             last_rejection_reason, retry_after, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (eval_id, eval_type, payload_json, era_id, retry_count + 1,
             rejection_reason, retry_after, time.time())
        )
        self._conn.commit()

    def clear_retry_queue(self, era_id=None):
        self._check_closed()
        era_filter = "era_id=?" if era_id is not None else ""
        era_params = (era_id,) if era_id is not None else ()
        count = self._count_where("submission_retry", era_filter, era_params)
        if era_filter:
            self._conn.execute("DELETE FROM submission_retry WHERE era_id=?", era_params)
        else:
            self._conn.execute("DELETE FROM submission_retry")
        self._conn.commit()
        return count

    def get_retry_counts(self, era_id=None):
        self._check_closed()
        now = time.time()
        era_filter = "era_id=?" if era_id is not None else ""
        era_params = (era_id,) if era_id is not None else ()

        total = self._count_where("submission_retry", era_filter, era_params)

        ready_where = "retry_count < 5 AND (retry_after IS NULL OR retry_after <= ?)"
        if era_id is not None:
            ready_where = f"era_id=? AND {ready_where}"
        ready_params = era_params + (now,)
        ready = self._count_where("submission_retry", ready_where, ready_params)

        return RetryCounts(retrying=total, ready=ready)

    def requeue_submission(self, eval_id, eval_type, payload_json, era_id):
        self._check_closed()
        _validate_eval_type_strict(eval_type)

        cursor = self._conn.execute(
            """INSERT INTO submission_queue
            (eval_id, eval_type, payload_json, era_id, priority, created_at)
            VALUES (?, ?, ?, ?, 1, ?)""",
            (eval_id, eval_type, payload_json, era_id, time.time())
        )
        self._conn.commit()
        return cursor.lastrowid

    def _get_distinct_column(self, column):
        """Return sorted distinct values of a column across both evaluation tables."""
        rows = self._conn.execute(
            f"""SELECT DISTINCT {column} FROM (
                SELECT {column} FROM signal_evaluations
                UNION
                SELECT {column} FROM strategy_evaluations
            ) ORDER BY {column} ASC"""
        ).fetchall()
        return [r[0] for r in rows]

    def get_available_eras(self):
        self._check_closed()
        return self._get_distinct_column("era_id")

    def get_available_universes(self):
        self._check_closed()
        return self._get_distinct_column("universe_id")

    def delete_evaluations(self, eval_type=None, keep_last=50_000):
        self._check_closed()
        if self._search_active:
            raise RuntimeError("Cannot delete evaluations while search is active")
        if keep_last < 0:
            raise ValueError("keep_last must be >= 0")
        _validate_eval_type(eval_type)

        sig_deleted = strat_deleted = sig_remaining = strat_remaining = 0

        for eval_table, fn_table, feat_table in _eval_table_triplets(eval_type):
            is_signal = eval_table == "signal_evaluations"
            total = self._conn.execute(f"SELECT COUNT(*) FROM {eval_table}").fetchone()[0]
            to_delete = total - keep_last

            if to_delete <= 0:
                if is_signal:
                    sig_remaining = total
                else:
                    strat_remaining = total
                continue

            id_list = [
                r[0] for r in self._conn.execute(
                    f"SELECT eval_id FROM {eval_table} ORDER BY eval_id ASC LIMIT ?",
                    (to_delete,)
                ).fetchall()
            ]

            if id_list:
                _delete_eval_ids(self._conn, id_list, eval_table, fn_table, feat_table)

            remaining = self._conn.execute(f"SELECT COUNT(*) FROM {eval_table}").fetchone()[0]

            if is_signal:
                sig_deleted = len(id_list)
                sig_remaining = remaining
            else:
                strat_deleted = len(id_list)
                strat_remaining = remaining

        self._conn.commit()
        return DeleteResult(
            signal_rows_deleted=sig_deleted,
            strategy_rows_deleted=strat_deleted,
            signal_rows_remaining=sig_remaining,
            strategy_rows_remaining=strat_remaining,
        )

    def delete_failed_evaluations(self, eval_type=None):
        self._check_closed()
        if self._search_active:
            raise RuntimeError("Cannot delete evaluations while search is active")
        _validate_eval_type(eval_type)

        for eval_table, fn_table, feat_table in _eval_table_triplets(eval_type):
            id_list = [
                r[0] for r in self._conn.execute(
                    f"SELECT eval_id FROM {eval_table} WHERE passed_thresholds = 0"
                ).fetchall()
            ]
            _delete_eval_ids(self._conn, id_list, eval_table, fn_table, feat_table)

        self._conn.commit()

    def get_db_info(self):
        self._check_closed()
        file_size = os.path.getsize(self._db_path) if os.path.exists(self._db_path) else 0
        return DatabaseInfo(
            file_size_bytes=file_size,
            signal_evaluation_count=self._conn.execute(
                "SELECT COUNT(*) FROM signal_evaluations").fetchone()[0],
            strategy_evaluation_count=self._conn.execute(
                "SELECT COUNT(*) FROM strategy_evaluations").fetchone()[0],
            signal_passed_count=self._conn.execute(
                "SELECT COUNT(*) FROM signal_evaluations WHERE passed_thresholds=1").fetchone()[0],
            strategy_passed_count=self._conn.execute(
                "SELECT COUNT(*) FROM strategy_evaluations WHERE passed_thresholds=1").fetchone()[0],
        )

    def set_search_active(self, active):
        self._check_closed()
        self._search_active = active

    def close(self):
        if self._closed:
            return
        self._closed = True
        try:
            self._conn.close()
        except Exception as e:
            logger.warning("Error closing database connection: %s", e)
