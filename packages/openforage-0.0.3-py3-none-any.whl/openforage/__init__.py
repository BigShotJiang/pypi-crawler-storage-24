# openforage — top-level public API

try:
    from openforage.agent_onboarding import register, login, configure
    from openforage.search_templates import search, SearchHandle, SearchStatus
    from openforage import simulate_signal as _simulate_signal_mod
    simulate_strategy = _simulate_signal_mod.simulate_strategy
    SimulationHandle = _simulate_signal_mod.SimulationHandle
    SimulationResult = _simulate_signal_mod.SimulationResult
    SimulationStatus = _simulate_signal_mod.SimulationStatus
    PoolResult = _simulate_signal_mod.PoolResult

    # openforage.templates exposes built-in search templates (e.g. random_weighted)
    from openforage import search_templates as templates
except ImportError:
    # Cython modules not compiled — GUI-only mode
    pass
