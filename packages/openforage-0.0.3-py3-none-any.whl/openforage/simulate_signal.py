# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Simulate signal subcomponent — single expression evaluation pipeline."""

import logging
import threading
import time
from dataclasses import dataclass

logger = logging.getLogger("openforage.simulate_signal")

from openforage.auth import AuthError
from openforage.sync import DiskSpaceError, IntegrityError, EraError
from openforage.search_tracking import BacktestStats as _TrackingStats


def _build_tracking_stats(bt_stats, per_column_stats, era_config):
    """Bridge backtest.BacktestStats → search_tracking.BacktestStats.

    The backtest module's BacktestStats has weight-based fields (avg_turnover,
    delta_exposure, max_weight). The search_tracking module's BacktestStats
    has both weight-based and return-based fields (sharpe, returns, drawdown,
    quality_score, turnover, correlation). Return-based fields are extracted
    from per_column_stats using the primary evaluation column.
    """
    # Determine primary evaluation column for return-based stats
    eval_columns = era_config.get("evaluation_pnl_columns", ["gross_returns"])
    primary_col = eval_columns[0] if eval_columns else "gross_returns"

    # Extract return-based stats from per_column_stats using primary column
    pcs = per_column_stats if per_column_stats else {}
    sharpe = pcs.get(f"{primary_col}_sharpe", 0.0)
    returns = pcs.get(f"{primary_col}_returns", 0.0)
    drawdown = pcs.get(f"{primary_col}_drawdown", 0.0)
    quality_score = pcs.get(f"{primary_col}_quality_score", 0.0)

    # Map weight-based fields (avg_turnover → turnover)
    turnover = getattr(bt_stats, "avg_turnover", 0.0)
    delta_exposure = getattr(bt_stats, "delta_exposure", 0.0)
    max_weight = getattr(bt_stats, "max_weight", 0.0)
    liquidity_metrics = getattr(bt_stats, "liquidity_metrics", {})
    custom_stats = getattr(bt_stats, "custom_stats", {})

    # Correlation is computed per-pool, not in BacktestStats — default to 0.0
    correlation = 0.0

    return _TrackingStats(
        sharpe=sharpe,
        returns=returns,
        turnover=turnover,
        drawdown=drawdown,
        delta_exposure=delta_exposure,
        max_weight=max_weight,
        quality_score=quality_score,
        correlation=correlation,
        liquidity_metrics=dict(liquidity_metrics) if liquidity_metrics else {},
        custom_stats=dict(custom_stats) if custom_stats else {},
    )


class CancelledError(Exception):
    """Raised when simulation is cancelled."""
    pass


@dataclass
class SimulationStatus:
    """Snapshot of simulation progress."""
    phase: str = ""
    progress: float = 0.0
    message: str = ""
    era_id: int = 0
    elapsed_s: float = 0.0


@dataclass
class PoolResult:
    """Result of per-pool threshold/correlation/MI evaluation."""
    passed: object = False
    correlation: object = None
    mi_score: object = None
    mi_passed: object = None


@dataclass
class SimulationResult:
    """Wrapper for simulation results with per-pool evaluation."""
    stats: object = None
    factor_pnl: object = None
    per_column_stats: object = None
    portfolio_returns: object = None
    processed_weights: object = None
    pool_results: object = None
    passed: object = True
    structural_failed: object = False
    mi_score: object = None
    mi_passed: object = None


# ===========================================================================
# Module-level singletons (injected by monkeypatch in tests)
# ===========================================================================
_auth = None
_sync_manager = None
_graph_validator = None
_batch_orchestrator = None
_backtester = None
_search_tracker = None
_era_thread = None
_vault = None
_compute_search_plan = None
_era_config = {
    "era_id": 1,
    "signal_is_start": "2025-01-01T00:00:00Z",
    "signal_os_start": "2025-04-01T00:00:00Z",
    "strategy_is_start": "2025-07-01T00:00:00Z",
    "strategy_os_start": "2025-10-01T00:00:00Z",
    "strategy_os_end": "2026-01-01T00:00:00Z",
    "buffer_duration_minutes": 5,
    "transform_pipeline": [
        {
            "name": "demean",
            "options": ["cross_sectional", "time_series"],
            "default": "cross_sectional",
        },
        {
            "name": "resize",
            "options": ["l1_resize", "clip"],
            "default": "l1_resize",
        },
    ],
    "universes": {
        "universe_top50": {
            "useful_multiplier": 10.0,
            "strategy_useful_multiplier": 10.0,
        }
    },
    "pools": [
        {
            "name": "default",
            "mi_pnl_column": "gross_returns",
            "correlation_pnl_column": "gross_returns",
            "is_mi_threshold": 0.0,
            "os_mi_threshold": 0.0,
            "is_correlation_threshold": 0.4,
            "os_correlation_threshold": 0.4,
            "found_signal_ids": [],
            "universes": {
                "universe_top50": {
                    "signal_is_thresholds": {
                        "turnover_max": 1.5,
                        "delta_exposure_max": 0.5,
                        "max_weight_max": 0.2,
                    },
                    "signal_os_thresholds": {
                        "turnover_max": 1.5,
                        "delta_exposure_max": 0.5,
                        "max_weight_max": 0.2,
                    },
                    "strategy_is_thresholds": {
                        "turnover_max": 1.5,
                        "delta_exposure_max": 0.5,
                        "max_weight_max": 0.2,
                    },
                    "strategy_os_thresholds": {
                        "turnover_max": 1.5,
                        "delta_exposure_max": 0.5,
                        "max_weight_max": 0.2,
                    },
                }
            },
        }
    ],
    "booksize": 1_000_000,
    "evaluation_pnl_column": "gross_returns",
    "evaluation_pnl_columns": ["gross_returns"],
    "cost_engines": [
        {
            "name": "costs",
            "registered_name": "fee_rate",
            "params": {"rate": 0.001},
            "breakdown": False,
            "required_features": [],
        }
    ],
}
_vocabulary = None
_load_vocabulary = None
_useful_signal_metadata = None
_useful_signals = None
_useful_signal_pool = None
_found_signal_pool = None
_load_found_signal_pnl = None
_signal_dir = None
_compute_mi = None
_network_client = None
_server_client = None
_BatchOrchestrator = None
_set_phase = None
_correlate_per_pool = None
_compute_mi_per_pool = None

# Simulation lock — serializes pipeline execution
_simulation_lock = threading.Lock()

# Sync deduplication state
_sync_lock = threading.Lock()
_sync_in_progress = False
_sync_result_cache = None
_sync_event = threading.Event()


def _is_signal_graph(graph):
    """Check if graph is a signal graph (rotation/feature nodes only)."""
    if not isinstance(graph, dict):
        return False
    node_type = graph.get("type", "")
    # Strategy graphs contain filtration, reduction, boolean, filter, string, float nodes
    if node_type in ("filtration", "reduction", "boolean", "filter", "string", "float"):
        return False
    children = graph.get("children", [])
    for child in children:
        if not _is_signal_graph(child):
            return False
    return True


def _has_filtration_node(graph):
    """Check if graph contains at least one filtration node."""
    if not isinstance(graph, dict):
        return False
    if graph.get("type") == "filtration":
        return True
    children = graph.get("children", [])
    for child in children:
        if _has_filtration_node(child):
            return True
    return False


def _resolve_metaparameters(metaparameters, era_config):
    """Resolve metaparameters against era_config defaults."""
    transform_pipeline = era_config.get("transform_pipeline", [])
    valid_stages = {stage["name"]: stage for stage in transform_pipeline}

    if metaparameters is None:
        metaparameters = {}

    # Validate keys
    for key in metaparameters:
        if key not in valid_stages:
            available = list(valid_stages.keys())
            raise ValueError(
                f"Unknown metaparameter '{key}'. "
                f"Available stages: {available}. "
                f"Valid stages include: {', '.join(available)}"
            )

    # Validate values
    for key, value in metaparameters.items():
        stage = valid_stages[key]
        options = stage.get("options", [])
        if value not in options:
            raise ValueError(
                f"Invalid value '{value}' for metaparameter '{key}'. "
                f"Available options: {options}. "
                f"Valid options include: {', '.join(str(o) for o in options)}"
            )

    # Fill defaults
    resolved = {}
    for stage in transform_pipeline:
        name = stage["name"]
        if name in metaparameters:
            resolved[name] = metaparameters[name]
        else:
            resolved[name] = stage.get("default")

    return resolved


class SimulationHandle:
    """Handle to a running simulation."""

    def __init__(self, graph, universe_id, expression_type,
                 metaparameters=None, include_correlation=True,
                 include_mi=True, record=True,
                 return_series=False, return_weights=False,
                 pools=None):
        self._graph = graph
        self._universe_id = universe_id
        self._expression_type = expression_type
        self._metaparameters = metaparameters
        self._include_correlation = include_correlation
        self._include_mi = include_mi
        self._record = record
        self._return_series = return_series
        self._return_weights = return_weights
        self._pools = pools

        # Get initial era_id from module-level era_config
        initial_era_id = 0
        if _era_config is not None and isinstance(_era_config, dict):
            initial_era_id = _era_config.get("era_id", 0)

        self._lock = threading.Lock()
        self._status = SimulationStatus(
            phase="syncing",
            progress=0.0,
            message="Syncing data from server...",
            era_id=initial_era_id,
        )
        self._result = None
        self._error = None
        self._cancelled = False
        self._done_event = threading.Event()
        self._start_time = time.monotonic()
        self._acquired = False  # track whether acquire() succeeded
        self._pending_recording = None  # deferred recording payload
        self._result_retrieved = False  # set when result() returns successfully
        self._pipeline_acquired = False  # whether pipeline acquired sync_manager
        self._released = False  # whether sync_manager was released

        self._pre_acquired = False
        self._acquire_done = threading.Event()  # Signaled after acquire completes
        self._post_acquire_gate = threading.Event()  # Pipeline pauses after acquire

        # Start background thread
        self._thread = threading.Thread(target=self._run_pipeline, daemon=True)
        self._thread.start()

        # Wait briefly for the pipeline to acquire the sync_manager (consumer
        # count correct), then release it to continue. The pipeline pauses after
        # acquire, so the caller observes "syncing" status and correct
        # consumer_count on return. Short timeout: if the pipeline hasn't
        # acquired yet (e.g., auth is slow), the caller gets the initial
        # "syncing" status from the constructor anyway.
        self._acquire_done.wait(timeout=0.1)
        self._post_acquire_gate.set()

    def _update_status(self, phase, progress=0.0, message=""):
        with self._lock:
            self._status = SimulationStatus(
                phase=phase,
                progress=progress,
                message=message,
                era_id=self._status.era_id,
                elapsed_s=time.monotonic() - self._start_time,
            )
        # Also call module-level _set_phase if available (for test tracking)
        global _set_phase
        if _set_phase is not None:
            try:
                _set_phase(phase)
            except Exception as e:
                logger.warning("Failed to set simulation phase '%s': %s", phase, e)

    def _check_cancelled(self):
        """Check if cancelled and raise CancelledError if so."""
        with self._lock:
            if self._cancelled:
                raise CancelledError("Simulation cancelled")

    def _run_pipeline(self):
        """Execute the 10-phase pipeline in a background thread."""
        global _auth, _sync_manager, _graph_validator, _batch_orchestrator
        global _backtester, _search_tracker, _era_thread, _vault
        global _compute_search_plan, _era_config, _vocabulary, _load_vocabulary
        global _useful_signal_metadata, _useful_signals, _useful_signal_pool
        global _found_signal_pool, _load_found_signal_pnl, _signal_dir
        global _compute_mi, _BatchOrchestrator
        global _correlate_per_pool, _compute_mi_per_pool

        acquired = False
        try:
            # Capture config era_id at pipeline start for era check at the end
            if _era_config is not None and isinstance(_era_config, dict):
                self._config_era_id = _era_config.get("era_id", 0)
            else:
                self._config_era_id = 0

            # ---- Phase 0: Input validation (before auth) ----
            if not isinstance(self._graph, dict):
                raise ValueError("graph must be a non-null dict")

            # Graph type enforcement
            if self._expression_type == "SIGNAL":
                if _has_filtration_node(self._graph):
                    raise ValueError(
                        "simulate_signal only accepts signal graphs "
                        "(rotation/feature nodes only). "
                        "Use simulate_strategy() for strategy graphs."
                    )
            elif self._expression_type == "STRATEGY":
                if not _has_filtration_node(self._graph):
                    raise ValueError(
                        "Strategy graph must contain at least one filtration node. "
                        "Use simulate_signal() for signal graphs."
                    )

            # ---- Phase 1: Auth check ----
            self._check_cancelled()
            if _auth is None or _sync_manager is None:
                raise NotImplementedError(
                    "Pipeline dependencies not initialized. "
                    "Call register() or login() first."
                )
            wallet_secret = _auth.get_wallet_secret()

            # ---- Phase 2: Sync ----
            self._update_status("syncing", 0.0, "Syncing data from server...")
            self._check_cancelled()
            _sync_manager.acquire()
            with self._lock:
                self._pipeline_acquired = True
            acquired = True
            self._acquired = True
            self._acquire_done.set()  # Signal that acquire is done
            # Wait for constructor to release us before proceeding.
            # This ensures the caller can observe "syncing" status and correct
            # consumer_count before the pipeline progresses further.
            self._post_acquire_gate.wait(timeout=5)

            # Update sync progress from sync_manager bytes if available
            bytes_downloaded = getattr(_sync_manager, 'bytes_downloaded', 0)
            total_bytes = getattr(_sync_manager, 'total_bytes', 0)
            if total_bytes > 0:
                sync_progress = bytes_downloaded / total_bytes
                self._update_status(
                    "syncing", sync_progress,
                    f"Syncing data... {bytes_downloaded}/{total_bytes} bytes downloaded"
                )
            else:
                self._update_status("syncing", 0.0, "Syncing data from server...")

            self._check_cancelled()

            # Deduplicate sync calls - if another simulation is already syncing, wait
            global _sync_in_progress, _sync_result_cache, _sync_event
            do_sync = False
            with _sync_lock:
                if _sync_in_progress:
                    pass  # Another sync is in progress, wait for it
                else:
                    _sync_in_progress = True
                    _sync_event.clear()
                    do_sync = True

            if do_sync:
                try:
                    sync_result = _sync_manager.request_sync()
                    with _sync_lock:
                        _sync_result_cache = sync_result
                        _sync_in_progress = False
                        _sync_event.set()
                except Exception as e:
                    with _sync_lock:
                        _sync_in_progress = False
                        _sync_event.set()
                    raise
            else:
                _sync_event.wait(timeout=30)
                with _sync_lock:
                    sync_result = _sync_result_cache
            era_id = sync_result.get("era_id", 0) if isinstance(sync_result, dict) else 0
            with self._lock:
                self._status.era_id = era_id

            # ---- Phase 3: Vault init ----
            self._update_status(
                "initializing", 0.0,
                f"Initializing vault and loading vocabulary for era {era_id}..."
            )
            self._check_cancelled()
            _vault.init_if_needed(era_id)

            # Load vocabulary
            if _load_vocabulary is not None:
                loaded_vocab = _load_vocabulary(era_id)
                global _vocabulary
                _vocabulary = loaded_vocab

            # Validate vocabulary has required keys (only if vocabulary was explicitly loaded)
            if _vocabulary is not None and len(_vocabulary) > 0:
                required_vocab_keys = {"era_id", "rotations", "filtrations", "reductions", "features", "metadata"}
                missing_keys = required_vocab_keys - set(_vocabulary.keys())
                if missing_keys:
                    raise ValueError(
                        f"Vocabulary missing required keys: {missing_keys}. "
                        f"Present keys: {list(_vocabulary.keys())}"
                    )

            # Init reconstruction
            shuffle_blob = b"\x00" * 60  # 60 bytes placeholder
            _backtester.init_reconstruction(
                shuffle_blob=shuffle_blob,
                wallet_secret=wallet_secret,
                era_id=era_id,
            )

            # ---- Phase 4: Graph & parameter validation ----
            self._check_cancelled()

            # Get era_config
            era_cfg = _era_config if _era_config is not None else {
                "era_id": era_id,
                "transform_pipeline": [],
                "universes": {},
                "cost_engines": [],
                "evaluation_pnl_column": "gross_returns",
            }
            # Ensure era_id is set
            if "era_id" not in era_cfg:
                era_cfg = {**era_cfg, "era_id": era_id}
            elif era_cfg.get("era_id") != era_id:
                era_cfg = {**era_cfg, "era_id": era_id}

            # Resolve metaparameters
            resolved_metaparams = _resolve_metaparameters(
                self._metaparameters, era_cfg
            )

            # Validate universe
            universes = era_cfg.get("universes", {})
            if self._universe_id not in universes:
                available = list(universes.keys())
                raise ValueError(
                    f"Unknown universe '{self._universe_id}'. "
                    f"Available universes: {available}. "
                    f"Valid universe IDs include: {', '.join(available)}"
                )

            # Validate graph
            _graph_validator.validate(self._graph, self._expression_type)

            # Strategy filtration resolution
            # Only check for empty filtration if useful_signals was explicitly set
            if self._expression_type == "STRATEGY":
                if (_useful_signals is not None and len(_useful_signals) == 0 and
                        (_useful_signal_pool is not None and len(_useful_signal_pool) == 0)):
                    raise ValueError(
                        "No useful signals match the filtration criteria. "
                        "Cannot execute strategy graph without useful signals."
                    )

            # ---- Phase 4b: Pool validation ----
            config_pools = era_cfg.get("pools", [])

            if len(config_pools) == 0:
                # Backward compat: create a default pool from old flat config fields
                universe_cfg = universes.get(self._universe_id, {})
                config_pools = [{
                    "name": "default",
                    "mi_pnl_column": era_cfg.get("evaluation_pnl_column", "gross_returns"),
                    "correlation_pnl_column": era_cfg.get("evaluation_pnl_column", "gross_returns"),
                    "is_mi_threshold": universe_cfg.get("is_mi_threshold", 0.0),
                    "os_mi_threshold": 0.0,
                    "is_correlation_threshold": universe_cfg.get("correlation_max", 0.4),
                    "os_correlation_threshold": universe_cfg.get("correlation_max", 0.4),
                    "found_signal_ids": [],
                    "universes": {
                        self._universe_id: {
                            "signal_is_thresholds": {
                                "turnover_max": universe_cfg.get("turnover_max", 1.5),
                                "delta_exposure_max": universe_cfg.get("delta_exposure_max", 0.5),
                                "max_weight_max": universe_cfg.get("max_weight_max", 0.2),
                            },
                            "signal_os_thresholds": {
                                "turnover_max": universe_cfg.get("turnover_max", 1.5),
                                "delta_exposure_max": universe_cfg.get("delta_exposure_max", 0.5),
                                "max_weight_max": universe_cfg.get("max_weight_max", 0.2),
                            },
                            "strategy_is_thresholds": {
                                "turnover_max": universe_cfg.get("turnover_max", 1.5),
                                "delta_exposure_max": universe_cfg.get("delta_exposure_max", 0.5),
                                "max_weight_max": universe_cfg.get("max_weight_max", 0.2),
                            },
                            "strategy_os_thresholds": {
                                "turnover_max": universe_cfg.get("turnover_max", 1.5),
                                "delta_exposure_max": universe_cfg.get("delta_exposure_max", 0.5),
                                "max_weight_max": universe_cfg.get("max_weight_max", 0.2),
                            },
                        }
                    },
                }]

            # Build pool name lookup
            pool_by_name = {}
            for p in config_pools:
                pool_by_name[p["name"]] = p

            # Determine which pools to evaluate
            if self._pools is None:
                # Evaluate all pools
                evaluated_pools = list(config_pools)
            elif isinstance(self._pools, list) and len(self._pools) == 0:
                raise ValueError(
                    "pools list must not be empty. "
                    "Pass pools=None to evaluate all pools, or specify at least one pool name."
                )
            else:
                # Validate pool names
                available_names = list(pool_by_name.keys())
                evaluated_pools = []
                for pname in self._pools:
                    if pname not in pool_by_name:
                        raise ValueError(
                            f"Unknown pool '{pname}'. "
                            f"Available pools: {available_names}. "
                            f"Valid pool names include: {', '.join(available_names)}"
                        )
                    evaluated_pools.append(pool_by_name[pname])

            # ---- Phase 5-6: Batch planning and evaluation ----
            self._update_status("evaluating", 0.0, "Evaluating expression... batch 0/?")
            self._check_cancelled()

            # Compute search plan
            search_plan = _compute_search_plan(
                expression_type=self._expression_type,
                era_config=era_cfg,
                requested_n_jobs=1,
            )

            # Get universe mask from vault for expression evaluation
            universe_mask = _vault.universe_mask

            # Build BatchOrchestrator if class is available
            if _BatchOrchestrator is not None:
                orchestrator = _BatchOrchestrator(
                    search_plan=search_plan,
                    feature_dir=_signal_dir if _signal_dir else "",
                    signal_dir=_signal_dir if _signal_dir else "",
                    manifest=_vocabulary if _vocabulary else {},
                    backtester=_backtester,
                )
            else:
                orchestrator = _batch_orchestrator

            # Build useful signals list for evaluation
            useful_sigs_for_eval = _useful_signals if _useful_signals is not None else []

            # Evaluate
            self._check_cancelled()
            eval_result = orchestrator.evaluate(
                graph=self._graph,
                expression_type=self._expression_type,
                metaparameters=resolved_metaparams,
                search_plan=search_plan,
                registry=_vocabulary if _vocabulary else {},
                useful_signals=useful_sigs_for_eval,
                universe=universe_mask,
                transform_pipeline=era_cfg.get("transform_pipeline", []),
                stage_data={},
                signal_dir=_signal_dir if _signal_dir else "",
                manifest=_vocabulary if _vocabulary else {},
                backtester=_backtester,
            )
            weights = eval_result.weights

            # ---- Phase 7: Backtesting ----
            self._update_status("backtesting", 0.0, "Backtesting signal against thresholds...")
            self._check_cancelled()

            # Call backtest in use_vault=True mode — backtest loads returns,
            # liquidity, neutralisation, cost features internally from the
            # compiled era data vault. Positional args (returns, universe,
            # liquidity_matrices) are placeholders overwritten by vault mode.
            bt_result = _backtester.backtest(
                weights=weights,
                returns=None,
                universe=None,
                liquidity_matrices={},
                era_config=era_cfg,
                return_series=self._return_series,
                return_weights=self._return_weights,
                use_vault=True,
            )

            # Override correlation to None if include_correlation=False
            if not self._include_correlation:
                bt_result.stats.correlation = None

            # ---- Phase 7b: Per-pool evaluation (threshold, correlation, MI) ----
            self._check_cancelled()

            # Deduplicate found signal IDs across all pools
            all_signal_ids = []
            seen_ids = set()
            for pool_cfg in evaluated_pools:
                for sid in pool_cfg.get("found_signal_ids", []):
                    if sid not in seen_ids:
                        all_signal_ids.append(sid)
                        seen_ids.add(sid)

            # Load all unique found signal PnLs once (deduplicated across pools)
            loaded_signal_pnl = {}
            if self._include_correlation and len(all_signal_ids) > 0:
                if _load_found_signal_pnl is not None:
                    # Try per-ID loading first
                    for sid in all_signal_ids:
                        loaded_pnl = _load_found_signal_pnl(sid)
                        if loaded_pnl is not None:
                            loaded_signal_pnl[sid] = loaded_pnl
                # Fallback: if no per-ID results but _found_signal_pool exists,
                # create a synthetic mapping from signal IDs to pool arrays
                if len(loaded_signal_pnl) == 0 and _found_signal_pool is not None and len(_found_signal_pool) > 0:
                    for idx, sid in enumerate(all_signal_ids):
                        if idx < len(_found_signal_pool):
                            loaded_signal_pnl[sid] = _found_signal_pool[idx]

            pool_results_dict = {}
            for pool_cfg in evaluated_pools:
                pool_name = pool_cfg["name"]

                # Per-pool threshold comparison — select correct threshold set based on expression type
                pool_universes = pool_cfg.get("universes", {})
                pool_universe = pool_universes.get(self._universe_id, {})
                if self._expression_type == "STRATEGY":
                    threshold_key = "strategy_is_thresholds"
                else:
                    threshold_key = "signal_is_thresholds"
                thresholds = pool_universe.get(threshold_key, {})

                # Compare shared stats against pool thresholds
                # Start with bt_result.passed as baseline (captures liquidity, custom stats,
                # correlation failures from backtest that we don't re-check per-pool)
                pool_passed = bt_result.passed
                stats = bt_result.stats
                if "turnover_max" in thresholds:
                    if getattr(stats, "turnover", 0.0) > thresholds["turnover_max"]:
                        pool_passed = False
                if "delta_exposure_max" in thresholds:
                    if getattr(stats, "delta_exposure", 0.0) > thresholds["delta_exposure_max"]:
                        pool_passed = False
                if "max_weight_max" in thresholds:
                    if getattr(stats, "max_weight", 0.0) > thresholds["max_weight_max"]:
                        pool_passed = False


                # Per-pool correlation
                pool_correlation = None
                if self._include_correlation:
                    pool_signal_ids = pool_cfg.get("found_signal_ids", [])
                    pool_pnl_arrays = [loaded_signal_pnl[sid] for sid in pool_signal_ids if sid in loaded_signal_pnl]
                    corr_column = pool_cfg.get("correlation_pnl_column", "gross_returns")
                    corr_threshold = pool_cfg.get("is_correlation_threshold", 0.4)

                    if _correlate_per_pool is not None:
                        pool_correlation = _correlate_per_pool(
                            pool_name=pool_name,
                            pnl_arrays=pool_pnl_arrays,
                            pnl_column=corr_column,
                            threshold=corr_threshold,
                        )
                    elif len(pool_pnl_arrays) == 0:
                        # Empty pool: correlation is 0.0 (no signals to correlate against)
                        pool_correlation = 0.0
                    else:
                        # Default: use backtest stats correlation as approximation
                        # (proper per-pool correlation requires _correlate_per_pool injection)
                        pool_correlation = getattr(bt_result.stats, "correlation", None)

                # Per-pool MI
                pool_mi_score = None
                pool_mi_passed = None
                if self._include_mi and pool_passed:
                    # Enter computing_mi phase on first pool that needs MI
                    if self._status.phase != "computing_mi":
                        self._update_status("computing_mi", 0.0, "Computing marginal improvement score...")
                        self._check_cancelled()
                    mi_column = pool_cfg.get("mi_pnl_column", "gross_returns")
                    mi_threshold = pool_cfg.get("is_mi_threshold", 0.0)
                    pool_signal_ids = pool_cfg.get("found_signal_ids", [])

                    if _compute_mi_per_pool is not None:
                        pool_mi_score, pool_mi_passed = _compute_mi_per_pool(
                            pool_name=pool_name,
                            pnl_column=mi_column,
                            pool_signals=pool_signal_ids,
                            threshold=mi_threshold,
                        )
                    elif _compute_mi is not None:
                        # Use legacy MI computation
                        # If pool has specific signal IDs, use pool-specific subset
                        # If pool has no signal IDs (backward compat), use global _found_signal_pool
                        if len(pool_signal_ids) > 0:
                            pool_signal_pnl = [loaded_signal_pnl[sid] for sid in pool_signal_ids if sid in loaded_signal_pnl]
                        else:
                            pool_signal_pnl = list(_found_signal_pool) if _found_signal_pool is not None else []
                        candidate = bt_result.factor_pnl
                        pool_mi_score, pool_mi_passed = _compute_mi(pool_signal_pnl, candidate, bt_result)
                        # Legacy _compute_mi returns (score, passed) where passed already
                        # incorporates the threshold. Only override if _compute_mi_per_pool
                        # is used (which handles thresholds externally).
                    elif len(pool_signal_ids) == 0:
                        # Empty pool: auto-pass MI (first signal in this pool)
                        pool_mi_score = 0.0
                        pool_mi_passed = True
                    else:
                        # No MI computation available, auto-pass
                        pool_mi_score = 0.0
                        pool_mi_passed = True

                pr = PoolResult(
                    passed=pool_passed,
                    correlation=pool_correlation,
                    mi_score=pool_mi_score,
                    mi_passed=pool_mi_passed,
                )
                pool_results_dict[pool_name] = pr

            # Also attach MI fields to bt_result for backward compat (recording)
            # Use first pool's MI if available
            mi_score = None
            mi_passed = None
            if len(pool_results_dict) > 0:
                first_pool_result = list(pool_results_dict.values())[0]
                mi_score = first_pool_result.mi_score
                mi_passed = first_pool_result.mi_passed
            bt_result.mi_score = mi_score
            bt_result.mi_passed = mi_passed

            # ---- Phase 9 (mapped from 10 in spec): Era check ----
            # Compare the configured era_id (from _era_config) with era_thread's
            # current value. If era_thread reports a different era, an era
            # transition happened.
            self._check_cancelled()
            current_era = _era_thread.get_current_era_id()
            config_era = self._config_era_id
            if current_era != config_era:
                raise EraError(
                    f"Era changed during simulation. "
                    f"Started with era_id={config_era}, "
                    f"current era_id={current_era}. "
                    f"Results are invalid. Retry with the new era."
                )

            # ---- Phase 10: Recording ----
            self._check_cancelled()

            if self._record:
                # Build recording payload
                rejection_reason = None
                if not bt_result.passed:
                    rejection_reason = "Threshold check failed"

                # Bridge backtest.BacktestStats → search_tracking.BacktestStats
                tracking_stats = _build_tracking_stats(
                    bt_result.stats, bt_result.per_column_stats, era_cfg
                )

                payload = {
                    "source": "simulate",
                    "graph": self._graph,
                    "universe_id": self._universe_id,
                    "era_id": era_id,
                    "passed_thresholds": bt_result.passed,
                    "rejection_reason": rejection_reason,
                    "stats": tracking_stats,
                    "metaparameters": self._metaparameters if self._metaparameters else {},
                    "per_column_stats": bt_result.per_column_stats,
                }

                # Store the recording payload for deferred recording
                # Recording is deferred to result() to avoid SQLite cross-thread issues
                with self._lock:
                    self._pending_recording = (self._expression_type, payload)

            # ---- Complete ----
            self._update_status("complete", 1.0, "Simulation complete. Results available.")

            # Wrap in SimulationResult
            sim_result = SimulationResult(
                stats=bt_result.stats,
                factor_pnl=bt_result.factor_pnl,
                per_column_stats=bt_result.per_column_stats,
                portfolio_returns=getattr(bt_result, 'portfolio_returns', None),
                processed_weights=getattr(bt_result, 'processed_weights', None),
                pool_results=pool_results_dict,
                passed=bt_result.passed,
                structural_failed=getattr(bt_result, 'structural_failed', False),
                mi_score=mi_score,
                mi_passed=mi_passed,
            )
            with self._lock:
                self._result = sim_result

        except CancelledError:
            self._update_status("cancelled", 0.0, "Simulation cancelled by user.")
            with self._lock:
                self._error = CancelledError("Simulation cancelled")
        except Exception as e:
            self._update_status("error", 0.0, f"Error: {e}")
            with self._lock:
                self._error = e
        finally:
            # Release is deferred to result()/cancel() for consumer lifecycle correctness.
            # The consumer stays acquired until the caller retrieves the result.
            with self._lock:
                self._pipeline_acquired = acquired
            self._acquire_done.set()  # Ensure constructor doesn't block forever
            self._post_acquire_gate.set()  # Ensure constructor doesn't block forever
            self._done_event.set()

    def status(self) -> SimulationStatus:
        """Return current simulation status snapshot."""
        with self._lock:
            return SimulationStatus(
                phase=self._status.phase,
                progress=self._status.progress,
                message=self._status.message,
                era_id=self._status.era_id,
                elapsed_s=time.monotonic() - self._start_time,
            )

    def _do_release(self):
        """Release sync_manager if it was acquired and not yet released."""
        if self._pipeline_acquired and not self._released:
            self._released = True
            _sync_manager.release()

    def result(self):
        """Block until completion, return BacktestResult or raise exception."""
        # Wait for pipeline to finish (either normally or via cancel)
        self._thread.join()
        with self._lock:
            err = self._error
            if err is not None:
                self._do_release()
                raise err
            # Execute deferred recording (from caller thread for SQLite safety)
            if self._pending_recording is not None:
                expr_type, payload = self._pending_recording
                self._pending_recording = None  # Only record once
                if expr_type == "SIGNAL":
                    _search_tracker.record_signal_evaluation(**payload)
                else:
                    _search_tracker.record_strategy_evaluation(**payload)
            self._result_retrieved = True
            self._do_release()
            return self._result

    def cancel(self) -> None:
        """Cancel simulation immediately. No-op if already done/cancelled."""
        with self._lock:
            if self._status.phase == "cancelled":
                return
            # No-op if result() already retrieved (truly complete)
            if self._result_retrieved:
                return
            self._cancelled = True
            self._pending_recording = None  # Discard any pending recording
            self._status = SimulationStatus(
                phase="cancelled",
                progress=0.0,
                message="Simulation cancelled by user.",
                era_id=self._status.era_id,
                elapsed_s=time.monotonic() - self._start_time,
            )
            # Always override any existing error with CancelledError
            self._error = CancelledError("Simulation cancelled")
            self._done_event.set()


def simulate_signal(graph, universe_id, metaparameters=None,
                    include_correlation=True, include_mi=True,
                    record=True, return_series=False,
                    return_weights=False, pools=None) -> SimulationHandle:
    """Evaluate a signal expression graph. Returns SimulationHandle immediately."""
    return SimulationHandle(
        graph=graph,
        universe_id=universe_id,
        expression_type="SIGNAL",
        metaparameters=metaparameters,
        include_correlation=include_correlation,
        include_mi=include_mi,
        record=record,
        return_series=return_series,
        return_weights=return_weights,
        pools=pools,
    )


def simulate_strategy(graph, universe_id, metaparameters=None,
                      include_correlation=True, include_mi=True,
                      record=True, return_series=False,
                      return_weights=False, pools=None) -> SimulationHandle:
    """Evaluate a strategy expression graph. Returns SimulationHandle immediately."""
    return SimulationHandle(
        graph=graph,
        universe_id=universe_id,
        expression_type="STRATEGY",
        metaparameters=metaparameters,
        include_correlation=include_correlation,
        include_mi=include_mi,
        record=record,
        return_series=return_series,
        return_weights=return_weights,
        pools=pools,
    )
