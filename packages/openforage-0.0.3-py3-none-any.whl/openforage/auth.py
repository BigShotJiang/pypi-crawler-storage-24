# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Auth subcomponent -- AuthManager with EIP-191 signing, JWT management, proactive refresh."""

import base64
import json
import re
import threading
import time as _time
import urllib.request
import urllib.error
from urllib.parse import urlparse

from eth_account import Account
from eth_account.messages import encode_defunct

# secp256k1 curve order
_SECP256K1_ORDER = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141

# States
_UNINITIALIZED = "UNINITIALIZED"
_AUTHENTICATING = "AUTHENTICATING"
_AUTHENTICATED = "AUTHENTICATED"
_RE_AUTHENTICATING = "RE_AUTHENTICATING"
_CLOSED = "CLOSED"

# Backoff constants
_BACKOFF_BASE = 1
_BACKOFF_CAP = 60

# Proactive refresh at 80% of 24h lifetime
_REFRESH_RATIO = 0.8
_TOKEN_LIFETIME = 86400  # 24 hours

# Precompiled display name pattern
_DISPLAY_NAME_RE = re.compile(r'^[a-zA-Z0-9_\- ]+$')

# Display name validation error message
_DISPLAY_NAME_ERR = (
    "Display name must be 3-32 characters: letters, numbers, "
    "spaces, hyphens, underscores"
)

# Permanent auth failure reasons that mark refresh as unrecoverable
_PERMANENT_REASONS = frozenset(("signature_mismatch", "invalid_address"))


class InvalidKeyError(Exception):
    """Raised when private key is invalid (format, length, or secp256k1 scalar)."""
    pass


class AuthError(Exception):
    """Raised on authentication failures."""
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


class RegistrationError(Exception):
    """Raised when the server rejects a registration request."""
    pass


class ProfileError(Exception):
    """Raised on display name/profile failures."""
    def __init__(self, reason: str, **kwargs):
        self.reason = reason
        self.__dict__.update(kwargs)
        super().__init__(reason)


class NetworkError(Exception):
    """Raised when network is unreachable after retries."""
    pass


def _default_http_transport(method, url, headers=None, body=None):
    """Default HTTP transport using urllib. Returns (status, resp_headers, body_bytes)."""
    if headers is None:
        headers = {}
    if isinstance(body, str):
        body = body.encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        resp = urllib.request.urlopen(req)
        return (resp.status, dict(resp.headers), resp.read())
    except urllib.error.HTTPError as e:
        resp_headers = dict(e.headers) if e.headers else {}
        resp_body = e.read() if e.fp else b""
        return (e.code, resp_headers, resp_body)


def _validate_private_key(private_key):
    """Validate private key format and value. Returns normalized hex without 0x prefix."""
    if not private_key:
        raise InvalidKeyError("Private key must not be empty")

    raw_hex = private_key
    if raw_hex.startswith(("0x", "0X")):
        raw_hex = raw_hex[2:]

    if len(raw_hex) != 64:
        raise InvalidKeyError(
            f"Private key must be 32 bytes (64 hex chars), got {len(raw_hex)} hex chars"
        )

    try:
        key_int = int(raw_hex, 16)
    except ValueError:
        raise InvalidKeyError("Private key contains non-hex characters")

    if key_int == 0 or key_int >= _SECP256K1_ORDER:
        raise InvalidKeyError("Private key is not a valid secp256k1 scalar")

    return raw_hex


def _validate_server_url(server_url):
    """Validate server URL format. Returns the URL string."""
    if not server_url:
        raise ValueError("server_url must not be empty")

    parsed = urlparse(server_url)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError(f"server_url is not a valid URL: {server_url}")

    if parsed.scheme != "https":
        raise ValueError(f"server_url must use HTTPS, got {parsed.scheme}")

    return server_url


class AuthManager:
    """Client-side authentication manager with state machine and proactive refresh."""

    def __init__(self, private_key: str, server_url: str, *, clock=None, _transport=None):
        raw_hex = _validate_private_key(private_key)
        server_url = _validate_server_url(server_url)

        acct = Account.from_key(bytes.fromhex(raw_hex))
        self._wallet_address = acct.address.lower()
        self._private_key = raw_hex
        self._server_url = server_url.rstrip("/")
        self._clock = clock if clock is not None else _time.time
        self._transport = _transport if _transport is not None else _default_http_transport

        # State machine
        self._state = _UNINITIALIZED
        self._lock = threading.Lock()

        # Auth data
        self._token = None
        self._token_iat = None
        self._token_expiry = None
        self._wallet_secret = None
        self._auth_time = None

        # Concurrent auth sharing
        self._auth_event = None
        self._auth_error = None

        # Background refresh
        self._refresh_thread = None
        self._refresh_stop = threading.Event()

        # Close signaling
        self._close_event = threading.Event()

        # Permanent refresh error (signature_mismatch or invalid_address)
        self._permanent_refresh_error = False

        # Set before refresh state transition; signals get_token() that refresh is imminent
        self._refresh_pending = threading.Event()

        # Set when a refresh/re-auth completes and updates the token
        self._refresh_done = threading.Event()

    def _get_time(self):
        """Get current time using injected clock."""
        return self._clock()

    def _http_request(self, method, path, body_dict=None, headers=None):
        """Make HTTP request to server. Returns (status, resp_headers, resp_body_dict).

        Raises ConnectionError/TimeoutError on network failures.
        """
        url = self._server_url + path
        req_headers = {"Content-Type": "application/json"}
        if headers:
            req_headers.update(headers)

        body_str = json.dumps(body_dict) if body_dict is not None else None

        status, resp_headers, resp_body_bytes = self._transport(
            method, url, headers=req_headers, body=body_str
        )

        resp_body = None
        if resp_body_bytes:
            try:
                resp_body = json.loads(resp_body_bytes)
            except (json.JSONDecodeError, ValueError):
                resp_body = resp_body_bytes.decode("utf-8", errors="replace")

        return status, resp_headers, resp_body

    def _wait_with_clock(self, seconds):
        """Wait using the injected clock. Returns early if close is signaled or clock is stuck."""
        clock_start = self._get_time()
        deadline = clock_start + seconds
        real_start = _time.monotonic()
        last_clock_val = clock_start

        while self._get_time() < deadline:
            if self._close_event.is_set():
                return
            _time.sleep(0.05)

            current_clock = self._get_time()
            if current_clock != last_clock_val:
                last_clock_val = current_clock
                real_start = _time.monotonic()
            elif _time.monotonic() - real_start > 1.0:
                # Clock stuck for > 1s real time -- no one is managing it
                return

    def _request_with_retry(self, method, path, body_dict=None, headers=None,
                            max_attempts=None, is_verify=False):
        """HTTP request with exponential backoff retry for temporary errors.

        Returns (status, resp_headers, resp_body).
        Raises AuthError on permanent errors, NetworkError on exhausted retries.
        """
        attempt = 0
        backoff = _BACKOFF_BASE

        while True:
            if self._close_event.is_set():
                raise AuthError(reason="closed")

            try:
                status, resp_headers, resp_body = self._http_request(
                    method, path, body_dict=body_dict, headers=headers
                )
            except (ConnectionError, TimeoutError, OSError):
                attempt += 1
                if max_attempts is not None and attempt >= max_attempts:
                    raise NetworkError(f"Server unreachable after {attempt} attempts")
                self._wait_with_clock(backoff)
                backoff = min(backoff * 2, _BACKOFF_CAP)
                continue

            # Permanent errors
            if status == 400:
                if path == "/auth/register":
                    raise AuthError(reason="invalid_address")
                elif path == "/api/profile/display_name":
                    error_msg = ""
                    if isinstance(resp_body, dict):
                        error_msg = resp_body.get("error", "")
                    raise ProfileError(reason="validation_failed", message=error_msg)
                else:
                    raise AuthError(reason="invalid_request")

            if status == 401:
                if path == "/auth/verify":
                    raise AuthError(reason="signature_mismatch")
                elif path == "/api/profile/display_name":
                    raise AuthError(reason="auth_failed")
                else:
                    raise AuthError(reason="unauthorized")

            # Challenge re-request errors on verify (caller handles retry)
            if is_verify and status in (404, 410, 409):
                return status, resp_headers, resp_body

            # Rate limit
            if status == 429:
                if path == "/api/profile/display_name":
                    retry_after = 60
                    ra_header = resp_headers.get("Retry-After", resp_headers.get("retry-after", ""))
                    if ra_header:
                        try:
                            retry_after = int(ra_header)
                        except ValueError:
                            pass
                    raise ProfileError(reason="rate_limited", retry_after=retry_after)

                retry_after = backoff
                ra_header = resp_headers.get("Retry-After", resp_headers.get("retry-after", ""))
                if ra_header:
                    try:
                        retry_after = int(ra_header)
                    except ValueError:
                        pass
                attempt += 1
                if max_attempts is not None and attempt >= max_attempts:
                    raise NetworkError(f"Server unreachable after {attempt} attempts")
                self._wait_with_clock(retry_after)
                continue

            # Temporary errors
            if status == 503:
                attempt += 1
                if max_attempts is not None and attempt >= max_attempts:
                    raise NetworkError(f"Server unreachable after {attempt} attempts")
                self._wait_with_clock(backoff)
                backoff = min(backoff * 2, _BACKOFF_CAP)
                continue

            # Success
            if 200 <= status < 300:
                return status, resp_headers, resp_body

            # Unknown error -- treat as temporary
            attempt += 1
            if max_attempts is not None and attempt >= max_attempts:
                raise NetworkError(f"Server unreachable after {attempt} attempts")
            self._wait_with_clock(backoff)
            backoff = min(backoff * 2, _BACKOFF_CAP)

    def _do_auth_flow(self):
        """Execute register -> challenge -> sign -> verify.

        Returns (token, expiry, wallet_secret_bytes).
        Raises AuthError on permanent failure.
        """
        addr = self._wallet_address

        # Step 1: Register
        self._request_with_retry(
            "POST", "/auth/register",
            body_dict={"wallet_address": addr}
        )

        # Steps 2-4: Challenge -> Sign -> Verify (with re-request loop)
        while True:
            if self._close_event.is_set():
                raise AuthError(reason="closed")

            # Get challenge
            _, _, challenge_resp = self._request_with_retry(
                "POST", "/auth/challenge",
                body_dict={"wallet_address": addr}
            )

            if self._close_event.is_set():
                raise AuthError(reason="closed")

            challenge_id = challenge_resp["challenge_id"]
            challenge_message = challenge_resp["message"]

            # Sign with EIP-191
            pk = self._private_key
            if pk is None:
                raise AuthError(reason="closed")
            msg = encode_defunct(text=challenge_message)
            signed = Account.from_key(bytes.fromhex(pk)).sign_message(msg)
            signature_hex = signed.signature.hex()
            if not signature_hex.startswith("0x"):
                signature_hex = "0x" + signature_hex

            # Verify
            status, _, verify_resp = self._request_with_retry(
                "POST", "/auth/verify",
                body_dict={"challenge_id": challenge_id, "signature": signature_hex},
                is_verify=True
            )

            # Challenge expired/used/not-found -- re-request
            if status in (404, 410, 409):
                continue

            return (
                verify_resp["token"],
                verify_resp["expires_at"],
                base64.b64decode(verify_resp["wallet_secret"]),
            )

    def _store_auth_result(self, token, wallet_secret_bytes):
        """Store auth result and signal waiting threads. Must be called under self._lock."""
        self._token = token
        self._wallet_secret = wallet_secret_bytes
        self._auth_time = self._get_time()
        self._token_iat = self._auth_time
        self._token_expiry = self._auth_time + _TOKEN_LIFETIME
        self._state = _AUTHENTICATED
        self._permanent_refresh_error = False
        self._auth_error = None
        if self._auth_event is not None:
            self._auth_event.set()
        self._refresh_done.set()

    def authenticate(self) -> None:
        """Full register -> challenge -> sign -> verify flow."""
        with self._lock:
            if self._state == _CLOSED:
                raise AuthError(reason="closed")

            if self._state in (_RE_AUTHENTICATING, _AUTHENTICATING):
                # Wait for in-flight auth/re-auth to complete
                event = self._auth_event

            elif self._state in (_UNINITIALIZED, _AUTHENTICATED):
                self._state = _AUTHENTICATING
                self._auth_event = threading.Event()
                self._auth_error = None
                event = None

            else:
                raise AuthError(reason="invalid_state")

        if event is not None:
            event.wait()
            with self._lock:
                if self._auth_error is not None:
                    raise self._auth_error
                return

        try:
            token, _, wallet_secret_bytes = self._do_auth_flow()

            with self._lock:
                self._store_auth_result(token, wallet_secret_bytes)

            self._start_refresh()

        except AuthError as e:
            with self._lock:
                if self._state == _AUTHENTICATING:
                    self._state = _UNINITIALIZED
                self._auth_error = e
                if self._auth_event is not None:
                    self._auth_event.set()
            raise

        except Exception as e:
            with self._lock:
                self._auth_error = AuthError(reason=str(e))
                if self._auth_event is not None:
                    self._auth_event.set()
            raise

    def _poll_for_reauth(self, fallback_to_current_token):
        """Poll up to 3s for the refresh thread to enter RE_AUTHENTICATING, then wait.

        If fallback_to_current_token is True, returns the current token on poll timeout
        (used when refresh_pending is set). Otherwise raises token_expired.
        """
        event = None
        for _ in range(30):
            _time.sleep(0.1)
            with self._lock:
                if self._state == _RE_AUTHENTICATING:
                    event = self._auth_event
                    break
                if self._permanent_refresh_error:
                    raise AuthError(reason="token_expired")
                if self._state == _CLOSED:
                    raise AuthError(reason="closed")
        else:
            with self._lock:
                if self._permanent_refresh_error:
                    raise AuthError(reason="token_expired")
                if fallback_to_current_token and self._token is not None:
                    return self._token
            raise AuthError(reason="token_expired")

        if event is not None:
            event.wait()
        with self._lock:
            if self._state == _CLOSED:
                raise AuthError(reason="closed")
            if self._permanent_refresh_error:
                raise AuthError(reason="token_expired")
            if self._token is not None:
                return self._token
        raise AuthError(reason="token_expired")

    def get_token(self) -> str:
        """Return current valid JWT token, blocking during refresh."""
        with self._lock:
            state = self._state
            token = self._token
            token_expiry = self._token_expiry
            permanent_error = self._permanent_refresh_error
            event = self._auth_event

        if state == _CLOSED:
            raise AuthError(reason="closed")

        if state in (_UNINITIALIZED, _AUTHENTICATING):
            raise AuthError(reason="not_authenticated")

        if state == _RE_AUTHENTICATING:
            # During re-auth, return current token (still valid)
            if token is not None:
                return token
            # No token -- wait for re-auth to complete
            if event is not None:
                event.wait()
            with self._lock:
                if self._state == _CLOSED:
                    raise AuthError(reason="closed")
                if self._token is not None:
                    return self._token
            raise AuthError(reason="not_authenticated")

        if state == _AUTHENTICATED:
            now = self._get_time()

            # Token expired
            if token_expiry is not None and now >= token_expiry:
                if permanent_error:
                    raise AuthError(reason="token_expired")

                # Wait for the refresh thread to pick up the expiry
                return self._poll_for_reauth(
                    fallback_to_current_token=self._refresh_pending.is_set()
                )

            # Token still valid but past refresh threshold -- wait for refresh
            with self._lock:
                auth_time = self._auth_time
            if auth_time is not None:
                age = now - auth_time
                if age >= _TOKEN_LIFETIME * _REFRESH_RATIO:
                    self._refresh_done.wait(timeout=10.0)
                    with self._lock:
                        if self._state == _CLOSED:
                            raise AuthError(reason="closed")
                        if self._permanent_refresh_error:
                            raise AuthError(reason="token_expired")
                        if self._token is not None:
                            return self._token
                    raise AuthError(reason="token_expired")

            if token is not None:
                return token
            raise AuthError(reason="not_authenticated")

        raise AuthError(reason="not_authenticated")

    def get_wallet_secret(self) -> bytes:
        """Return 32-byte wallet_secret (base64-decoded)."""
        with self._lock:
            state = self._state

        if state == _CLOSED:
            raise AuthError(reason="closed")
        if state in (_UNINITIALIZED, _AUTHENTICATING):
            raise AuthError(reason="not_authenticated")

        with self._lock:
            if self._wallet_secret is not None:
                return self._wallet_secret

        raise AuthError(reason="not_authenticated")

    def get_wallet_address(self) -> str:
        """Return lowercase 0x-prefixed 42-char wallet address."""
        return self._wallet_address

    def get_token_expiry(self) -> float:
        """Return token expiry as Unix timestamp."""
        with self._lock:
            state = self._state

        if state == _CLOSED:
            raise AuthError(reason="closed")
        if state in (_UNINITIALIZED, _AUTHENTICATING):
            raise AuthError(reason="not_authenticated")

        with self._lock:
            if self._token_expiry is not None:
                return self._token_expiry

        raise AuthError(reason="not_authenticated")

    def notify_era_change(self, new_era_id: int) -> None:
        """Trigger non-blocking background re-authentication for era transitions."""
        if new_era_id <= 0:
            raise ValueError(f"era_id must be > 0, got {new_era_id}")

        with self._lock:
            if self._state == _CLOSED:
                raise AuthError(reason="closed")

            if self._state in (_UNINITIALIZED, _AUTHENTICATING):
                raise AuthError(reason="not_authenticated")

            if self._state == _RE_AUTHENTICATING:
                return  # Already re-authenticating

            self._state = _RE_AUTHENTICATING
            self._auth_event = threading.Event()
            self._auth_error = None

        threading.Thread(target=self._background_reauth, daemon=True).start()

    def _background_reauth(self):
        """Background re-authentication thread (era-change triggered)."""
        try:
            token, _, wallet_secret_bytes = self._do_auth_flow()

            with self._lock:
                if self._state == _CLOSED:
                    return
                self._store_auth_result(token, wallet_secret_bytes)

            self._start_refresh()

        except AuthError as e:
            with self._lock:
                if self._state == _CLOSED:
                    return
                self._auth_error = e
                if e.reason in _PERMANENT_REASONS:
                    self._permanent_refresh_error = True
                self._state = _AUTHENTICATED
                if self._auth_event is not None:
                    self._auth_event.set()

        except Exception as e:
            with self._lock:
                if self._state == _CLOSED:
                    return
                self._auth_error = AuthError(reason=str(e))
                self._state = _AUTHENTICATED
                if self._auth_event is not None:
                    self._auth_event.set()

    def _start_refresh(self):
        """Start the proactive refresh background thread."""
        self._refresh_stop.clear()
        self._close_event.clear()
        self._refresh_pending.clear()
        self._refresh_done.clear()
        t = threading.Thread(target=self._refresh_loop, daemon=True)
        t.start()
        self._refresh_thread = t

    def _refresh_loop(self):
        """Background thread polling for token refresh threshold."""
        while not self._refresh_stop.is_set() and not self._close_event.is_set():
            with self._lock:
                if self._state == _CLOSED:
                    return
                state = self._state
                auth_time = self._auth_time

            if state != _AUTHENTICATED:
                _time.sleep(0.1)
                continue

            if auth_time is not None:
                age = self._get_time() - auth_time
                if age >= _TOKEN_LIFETIME * _REFRESH_RATIO:
                    self._refresh_pending.set()
                    self._do_refresh()
                    return  # New loop started after successful refresh

            _time.sleep(0.1)

    def _do_refresh(self):
        """Perform a proactive token refresh."""
        with self._lock:
            if self._state == _CLOSED:
                return
            self._state = _RE_AUTHENTICATING
            self._auth_event = threading.Event()
            self._auth_error = None

        try:
            token, _, wallet_secret_bytes = self._do_auth_flow()

            with self._lock:
                if self._state == _CLOSED:
                    return
                self._store_auth_result(token, wallet_secret_bytes)

            self._start_refresh()

        except AuthError as e:
            with self._lock:
                if self._state == _CLOSED:
                    return
                self._auth_error = e
                if e.reason in _PERMANENT_REASONS:
                    self._permanent_refresh_error = True
                self._state = _AUTHENTICATED
                if self._auth_event is not None:
                    self._auth_event.set()

        except Exception as e:
            with self._lock:
                if self._state == _CLOSED:
                    return
                self._state = _AUTHENTICATED
                if self._auth_event is not None:
                    self._auth_event.set()

    def set_display_name(self, display_name: str | None) -> dict:
        """Set or reset display name via profile endpoint."""
        with self._lock:
            if self._state == _CLOSED:
                raise AuthError(reason="closed")
            if self._state in (_UNINITIALIZED, _AUTHENTICATING):
                raise AuthError(reason="not_authenticated")

        if display_name is not None and display_name != "":
            trimmed = display_name.strip()

            if not trimmed or len(trimmed) < 3 or len(trimmed) > 32:
                raise ValueError(_DISPLAY_NAME_ERR)

            if not _DISPLAY_NAME_RE.match(trimmed):
                raise ValueError(_DISPLAY_NAME_ERR)

            send_name = trimmed
        else:
            send_name = None

        with self._lock:
            token = self._token

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        _, _, resp_body = self._request_with_retry(
            "POST", "/api/profile/display_name",
            body_dict={"display_name": send_name},
            headers=headers,
            max_attempts=3,
        )

        if isinstance(resp_body, dict):
            return resp_body
        return {"wallet_address": self._wallet_address, "display_name": str(display_name)}

    def close(self) -> None:
        """Stop refresh, clear sensitive material, transition to CLOSED."""
        with self._lock:
            if self._state == _CLOSED:
                return
            self._state = _CLOSED

        self._close_event.set()
        self._refresh_stop.set()

        with self._lock:
            if self._auth_event is not None:
                self._auth_error = AuthError(reason="closed")
                self._auth_event.set()

        self._private_key = None
        self._token = None
        self._wallet_secret = None
        self._token_iat = None
        self._token_expiry = None
