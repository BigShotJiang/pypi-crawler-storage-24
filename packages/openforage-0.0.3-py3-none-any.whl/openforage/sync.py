# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Sync subcomponent — data synchronization, era management, file integrity."""

import hashlib
import json
import logging
import os
import platform
import shutil
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError


logger = logging.getLogger("openforage.sync")


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

def _detect_platform() -> str:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system == "linux":
        if machine in ("x86_64", "amd64"):
            return "linux_x86_64"
        elif machine in ("aarch64", "arm64"):
            return "linux_aarch64"
    elif system == "darwin":
        if machine in ("x86_64", "amd64"):
            return "macos_x86_64"
        elif machine in ("aarch64", "arm64"):
            return "macos_arm64"
    elif system == "windows":
        return "windows_amd64"
    return f"{system}_{machine}"


CURRENT_PLATFORM = _detect_platform()


# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------

class SyncError(Exception):
    """Base sync error."""
    pass


class DiskSpaceError(SyncError):
    """Raised when insufficient disk space for sync."""
    pass


class IntegrityError(SyncError):
    """Raised when file checksum verification fails after retries."""
    pass


class EraError(SyncError):
    """Raised on era-related errors."""
    pass


class ManifestError(SyncError):
    """Raised on manifest parsing or validation errors."""
    pass


class AuthError(Exception):
    """Raised on authentication failures."""
    pass


class StateError(Exception):
    """Raised when operation is invalid for current state."""
    pass


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class SyncResult:
    """Result of a sync operation."""
    features_downloaded: int = 0
    useful_signals_downloaded: int = 0
    bytes_downloaded: int = 0
    era_id: int = 0
    t_signal_is: int = 0
    t_strategy_is: int = 0
    n_instruments: int = 0
    n_features: int = 0
    n_useful_signals: int = 0
    n_found_strategies: int = 0
    pnl_column_count: int = 0
    vocabulary_downloaded: bool = False
    shuffle_seed_downloaded: bool = False


@dataclass
class VerifyResult:
    """Result of a verify operation."""
    valid: bool = True
    corrupted_files: List[str] = field(default_factory=list)
    missing_files: List[str] = field(default_factory=list)


class Manifest:
    """In-memory representation of the server manifest."""
    def __init__(self, data: dict):
        self._data = data
        self.era_id = data.get("era_id", 0)
        self.version = data.get("version", 0)
        self.files = data.get("files", {})
        self.pnl_column_count = data.get("pnl_column_count", 0)
        self.found_signals = data.get("found_signals", {})
        self.found_strategies = data.get("found_strategies", {})
        self.useful_signals = data.get("useful_signals", {})

    def to_dict(self) -> dict:
        return dict(self._data)


# ---------------------------------------------------------------------------
# HTTP helper
# ---------------------------------------------------------------------------

def _http_get(url: str, token: str, range_start: int = 0) -> tuple:
    """HTTP GET with auth header. Returns (status, headers_dict, body_bytes).
    If range_start > 0, sends Range header for resume."""
    headers = {"Authorization": f"Bearer {token}"}
    if range_start > 0:
        headers["Range"] = f"bytes={range_start}-"
    req = Request(url, headers=headers)
    try:
        resp = urlopen(req, timeout=10)
        status = resp.status
        resp_headers = {k: v for k, v in resp.getheaders()}
        try:
            body = resp.read()
        except Exception as read_err:
            if hasattr(read_err, 'partial'):
                body = read_err.partial
            else:
                body = b""
        return (status, resp_headers, body)
    except HTTPError as e:
        status = e.code
        resp_headers = {k: v for k, v in e.headers.items()}
        body = e.read() if hasattr(e, 'read') else b""
        return (status, resp_headers, body)
    except URLError as e:
        raise ConnectionError(f"Connection failed to {url}: {e.reason}") from e


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _atomic_write(filepath: str, data: bytes):
    """Write data to filepath via .tmp + rename (atomic)."""
    tmp_path = filepath + ".tmp"
    parent = os.path.dirname(filepath)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(tmp_path, "wb") as f:
        f.write(data)
    os.replace(tmp_path, filepath)


# ---------------------------------------------------------------------------
# EraThread
# ---------------------------------------------------------------------------

class EraThread:
    """Background thread for era state monitoring."""

    def __init__(self, server_url: str, get_token: Callable[[], str],
                 sync_manager: 'SyncManager', era_poll_interval_s: float = 600.0,
                 kill_searches_fn: Optional[Callable] = None,
                 restart_searches_fn: Optional[Callable] = None):
        self._server_url = server_url
        self._get_token = get_token
        self._sync_manager = sync_manager
        self._poll_interval = era_poll_interval_s
        self._kill_searches_fn = kill_searches_fn
        self._restart_searches_fn = restart_searches_fn
        self._thread = None
        self._stop_event = threading.Event()
        self._started = False
        self._last_known_era_id = None
        self._last_known_state = None
        # Track if we detected "closing" so we can detect abort
        self._in_closing = False

    def start(self) -> None:
        if self._started:
            raise StateError("EraThread already started")
        self._stop_event.clear()
        self._started = True
        # Get initial era_id from sync_manager if available
        if self._sync_manager._manifest is not None:
            self._last_known_era_id = self._sync_manager._manifest.era_id
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if not self._started:
            return
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=10)
        self._started = False

    def is_alive(self) -> bool:
        if self._thread is None:
            return False
        return self._thread.is_alive()

    def _run(self):
        """Poll /era/current at configured interval."""
        # Do initial poll immediately
        self._poll_once()
        while not self._stop_event.is_set():
            self._stop_event.wait(self._poll_interval)
            if self._stop_event.is_set():
                break
            self._poll_once()

    def _poll_once(self):
        """Single poll of /era/current."""
        try:
            token = self._get_token()
            url = f"{self._server_url}/era/current"
            status, headers, body = _http_get(url, token)
            if status == 200:
                era_config = json.loads(body.decode("utf-8"))
                era_id = era_config.get("era_id")
                state = era_config.get("state", "active")
                next_closing_at = era_config.get("next_closing_at")

                # Handle scheduled close (informational only)
                if state == "active" and next_closing_at is not None:
                    logger.info(
                        f"Scheduled close announced at {next_closing_at}. "
                        f"Continue normal operation."
                    )

                # Handle abort: closing -> active (same era)
                if self._in_closing and state == "active" and era_id == self._last_known_era_id:
                    logger.info("Era transition cancelled \u2014 resuming normal operation.")
                    self._in_closing = False
                    if self._restart_searches_fn:
                        try:
                            self._restart_searches_fn()
                        except Exception as e:
                            logger.warning("Restart searches callback failed: %s", e)
                    return

                # Handle closing state (same era, state changed to closing)
                if state == "closing" and not self._in_closing:
                    self._in_closing = True
                    logger.info(
                        f"Scheduled close announced at {next_closing_at}. "
                        f"Continue normal operation."
                    )
                    # Trigger transition for the closing state
                    try:
                        self._sync_manager.trigger_era_transition(
                            new_era_id=era_id,
                            kill_searches_fn=self._kill_searches_fn,
                            restart_searches_fn=self._restart_searches_fn,
                        )
                    except Exception as e:
                        logger.warning("Trigger era transition (closing) failed: %s", e)
                    return

                # Handle new era detected
                if era_id is not None and self._last_known_era_id is not None:
                    if era_id != self._last_known_era_id:
                        self._in_closing = False
                        try:
                            self._sync_manager.trigger_era_transition(
                                new_era_id=era_id,
                                kill_searches_fn=self._kill_searches_fn,
                                restart_searches_fn=self._restart_searches_fn,
                            )
                            self._last_known_era_id = era_id
                        except Exception as e:
                            logger.warning("Trigger era transition (new era) failed: %s", e)

        except Exception as e:
            logger.warning("Era poll failed: %s", e)


# ---------------------------------------------------------------------------
# SyncManager
# ---------------------------------------------------------------------------

class SyncManager:
    """Data synchronization manager with background polling and IPC.

    Use get_or_create() for singleton access keyed by canonical data_dir.
    Direct construction is allowed but does not participate in the singleton registry.
    """

    # Class-level singleton registry: canonical_data_dir -> SyncManager instance
    _instances: dict = {}
    _class_lock = threading.Lock()

    @classmethod
    def get_or_create(cls, data_dir: str, server_url: str,
                      get_token: Callable[[], str],
                      poll_interval_s: float = 600.0) -> 'SyncManager':
        """Get existing or create new SyncManager for this data_dir.

        Singleton keyed by canonical (realpath) data_dir. Validates that
        server_url matches for an existing instance. get_token is refreshed
        on each call (bound methods have unstable identity).
        """
        canonical = os.path.realpath(data_dir)
        with cls._class_lock:
            if canonical in cls._instances:
                instance = cls._instances[canonical]
                if instance._server_url != server_url:
                    raise ValueError(
                        f"SyncManager for '{canonical}' already exists with "
                        f"server_url='{instance._server_url}', cannot reuse "
                        f"with server_url='{server_url}'"
                    )
                # Refresh the token supplier (bound method identity is unstable)
                instance._get_token = get_token
                return instance
            instance = cls(data_dir, server_url, get_token, poll_interval_s)
            cls._instances[canonical] = instance
            return instance

    @classmethod
    def _evict(cls, data_dir: str) -> None:
        """Remove instance from singleton registry (called on 1→0 release)."""
        canonical = os.path.realpath(data_dir)
        with cls._class_lock:
            cls._instances.pop(canonical, None)

    def __init__(self, data_dir: str, server_url: str,
                 get_token: Callable[[], str], poll_interval_s: float = 600.0):
        # Validation
        if not callable(get_token):
            raise TypeError(f"get_token must be callable, got {type(get_token)}")
        if not server_url:
            raise ValueError("server_url must not be empty")
        if not os.path.isdir(data_dir):
            raise FileNotFoundError(f"data_dir does not exist: {data_dir}")

        self._data_dir = data_dir
        self._server_url = server_url
        self._get_token = get_token
        self._poll_interval = poll_interval_s

        # State
        self._manifest = None  # Manifest object or None
        self._running = False
        self._sync_thread = None
        self._stop_event = threading.Event()
        self._sync_lock = threading.Lock()
        self._consumer_lock = threading.Lock()
        # Load persisted consumer count
        self._consumer_count_path = os.path.join(data_dir, ".consumer_count")
        self._consumer_count = 0
        if os.path.exists(self._consumer_count_path):
            try:
                with open(self._consumer_count_path, "r") as f:
                    self._consumer_count = int(f.read().strip())
            except Exception as e:
                logger.warning("Failed to read consumer count: %s", e)
                self._consumer_count = 0
        self._in_transition = False
        self._repair_queue = []
        self._repair_lock = threading.Lock()
        self._coalescing_event = None  # threading.Event for coalescing
        self._coalescing_lock = threading.Lock()  # protects _coalescing_event

        # Era callbacks: list of callables receiving (event_type, era_id)
        # event_type: "kill" (stop workers), "restart" (resume workers), "abort" (cancelled)
        self._era_callbacks = []
        self._era_callbacks_lock = threading.Lock()

        # EraThread (created on first _start_internal, stopped on _stop_internal)
        self._era_thread = None

        # Cross-process file lock for sync serialization
        self._flock_path = os.path.join(data_dir, ".sync_flock")
        self._flock_fd = None

        # IPC file for cross-process coordination (legacy — kept for backward compat)
        self._ipc_lock_path = os.path.join(data_dir, ".sync_lock")

        # Load existing manifest from disk if available
        manifest_path = os.path.join(data_dir, "manifest.json")
        if os.path.exists(manifest_path):
            try:
                with open(manifest_path, "r") as f:
                    data = json.load(f)
                self._manifest = Manifest(data)
            except Exception as e:
                logger.warning("Failed to load manifest from disk: %s", e)

        # Load vocabulary metadata if available
        self._vocabulary = None
        vocab_path = os.path.join(data_dir, "vocabulary.json")
        if os.path.exists(vocab_path):
            try:
                with open(vocab_path, "r") as f:
                    self._vocabulary = json.load(f)
            except Exception as e:
                logger.warning("Failed to load vocabulary from disk: %s", e)

    def register_era_callback(self, callback: Callable) -> None:
        """Register a callback for era change events.

        Callback signature: callback(event_type: str, era_id: int)
        event_type: "kill" (stop workers before transition),
                    "restart" (resume after transition),
                    "abort" (transition cancelled, resume)
        """
        with self._era_callbacks_lock:
            self._era_callbacks.append(callback)

    def unregister_era_callback(self, callback: Callable) -> None:
        """Unregister an era change callback."""
        with self._era_callbacks_lock:
            try:
                self._era_callbacks.remove(callback)
            except ValueError:
                pass  # Already removed

    def _notify_era_callbacks(self, event_type: str, era_id: int) -> None:
        """Notify all registered era callbacks."""
        with self._era_callbacks_lock:
            callbacks = list(self._era_callbacks)
        for cb in callbacks:
            try:
                cb(event_type, era_id)
            except Exception as e:
                logger.warning("Era callback failed (%s): %s", cb, e, exc_info=True)

    def _acquire_flock(self) -> None:
        """Acquire cross-process file lock for sync serialization."""
        import fcntl
        if self._flock_fd is None:
            self._flock_fd = open(self._flock_path, "w")
        fcntl.flock(self._flock_fd, fcntl.LOCK_EX)

    def _release_flock(self) -> None:
        """Release cross-process file lock."""
        import fcntl
        if self._flock_fd is not None:
            fcntl.flock(self._flock_fd, fcntl.LOCK_UN)

    def _http_get(self, url: str, range_start: int = 0) -> tuple:
        """HTTP GET with fresh token per request."""
        token = self._get_token()
        return _http_get(url, token, range_start)

    def sync(self) -> SyncResult:
        """Full sync: manifest, compare, download, verify, atomic write."""
        self._acquire_flock()
        try:
            with self._sync_lock:
                return self._sync_impl()
        finally:
            self._release_flock()

    def _sync_impl(self) -> SyncResult:
        """Internal sync implementation (must hold _sync_lock)."""
        # 0a. Clean up stale .tmp files from previous interrupted syncs
        data_path = Path(self._data_dir)
        for tmp_file in data_path.rglob("*.tmp"):
            try:
                tmp_file.unlink()
            except Exception as e:
                pass  # Best-effort cleanup of stale tmp files

        # 0b. Check manifest version first
        version_url = f"{self._server_url}/data/manifest/version"
        try:
            v_status, v_headers, v_body = self._http_get(version_url)
            if v_status == 401:
                raise AuthError(f"Authentication failed: HTTP 401")
        except AuthError:
            raise
        except Exception as e:
            logger.warning("Manifest version check failed: %s", e)

        # 1. Download full server manifest
        url = f"{self._server_url}/data/manifest"
        status, headers, body = self._http_get(url)
        if status == 401:
            raise AuthError(f"Authentication failed: HTTP {status}")
        if status != 200:
            raise SyncError(f"Failed to fetch manifest: HTTP {status}")

        try:
            server_manifest_data = json.loads(body.decode("utf-8"))
        except json.JSONDecodeError as e:
            raise ManifestError(f"Invalid manifest JSON: {e}") from e

        server_manifest = Manifest(server_manifest_data)

        # Check for era mismatch (server era != local era during normal sync)
        if self._manifest is not None:
            if server_manifest.era_id != self._manifest.era_id:
                raise EraError(
                    f"Era mismatch: local era_id={self._manifest.era_id}, "
                    f"server era_id={server_manifest.era_id}"
                )

        # Check if we already have this version (and all critical files exist)
        if self._manifest is not None and self._manifest.version >= server_manifest.version:
            vocab_path = os.path.join(self._data_dir, "vocabulary.json")
            seed_path = os.path.join(self._data_dir, "shuffle_seed.enc")
            vocab_missing = not os.path.exists(vocab_path)
            seed_missing = not os.path.exists(seed_path)

            if not vocab_missing and not seed_missing:
                return SyncResult(era_id=int(self._manifest.era_id))
            else:
                # Fall through to re-download missing files
                result = SyncResult(era_id=int(self._manifest.era_id))
                if vocab_missing:
                    self._download_vocabulary(server_manifest)
                    result.vocabulary_downloaded = True
                if seed_missing:
                    self._download_shuffle_seed(server_manifest)
                    result.shuffle_seed_downloaded = True
                # Re-populate metadata
                if self._vocabulary is None or vocab_missing:
                    if os.path.exists(vocab_path):
                        with open(vocab_path, "r") as f:
                            self._vocabulary = json.load(f)
                if self._vocabulary:
                    meta = self._vocabulary.get("metadata", {})
                    result.t_signal_is = meta.get("t_signal_is", 0)
                    result.t_strategy_is = meta.get("t_strategy_is", 0)
                    result.n_instruments = meta.get("n_instruments", 0)
                return result

        # 2. Compare files and determine what to download
        result = SyncResult()
        result.era_id = int(server_manifest.era_id)
        result.pnl_column_count = server_manifest.pnl_column_count

        files_to_download = {}
        for file_path, file_info in server_manifest.files.items():
            file_type = file_info.get("type", "")
            file_platform = file_info.get("platform", "")

            # Skip non-matching platform binaries
            if file_type in ("vault_module", "backtester_module"):
                if file_platform and file_platform != CURRENT_PLATFORM:
                    continue

            local_path = os.path.join(self._data_dir, file_path)

            # Within an era, existing files are additive only (never replaced)
            if self._manifest is not None and self._manifest.era_id == server_manifest.era_id:
                if file_path in self._manifest.files:
                    if os.path.exists(local_path):
                        continue

            # Check if file already exists on disk with matching checksum
            if os.path.exists(local_path):
                with open(local_path, "rb") as f:
                    local_sha = _sha256(f.read())
                if local_sha == file_info.get("sha256"):
                    continue

            files_to_download[file_path] = file_info

        # 3. Check disk space (BEFORE starting any download)
        total_needed = sum(f.get("size_bytes", 0) for f in server_manifest.files.values())
        if total_needed > 0:
            du = shutil.disk_usage(self._data_dir)
            free_bytes = du[2] if isinstance(du, tuple) else du.free
            if total_needed > free_bytes:
                raise DiskSpaceError(
                    f"Insufficient disk space: need {total_needed} bytes, "
                    f"have {free_bytes} bytes available"
                )

        # 4. Download files
        for file_path, file_info in files_to_download.items():
            self._download_file(file_path, file_info, result)

        # 4b. Count useful signals downloaded (unique signal groups)
        useful_signal_dirs_downloaded = set()
        for fp in files_to_download:
            if fp.startswith("useful_signals/"):
                parts = fp.split("/")
                if len(parts) >= 2:
                    useful_signal_dirs_downloaded.add(parts[1])
        result.useful_signals_downloaded = len(useful_signal_dirs_downloaded)

        # 5. Download vocabulary (conditional)
        vocab_downloaded = self._download_vocabulary(server_manifest)
        result.vocabulary_downloaded = vocab_downloaded

        # 6. Download shuffle seed (conditional)
        seed_downloaded = self._download_shuffle_seed(server_manifest)
        result.shuffle_seed_downloaded = seed_downloaded

        # 7. Write manifest atomically
        manifest_path = os.path.join(self._data_dir, "manifest.json")
        manifest_json = json.dumps(server_manifest_data).encode("utf-8")
        _atomic_write(manifest_path, manifest_json)

        # 8. Update internal state
        self._manifest = server_manifest

        # 9. Load vocabulary metadata
        if vocab_downloaded or self._vocabulary is None:
            vocab_path = os.path.join(self._data_dir, "vocabulary.json")
            if os.path.exists(vocab_path):
                with open(vocab_path, "r") as f:
                    self._vocabulary = json.load(f)

        # 10. Populate result from vocabulary metadata
        if self._vocabulary:
            meta = self._vocabulary.get("metadata", {})
            result.t_signal_is = meta.get("t_signal_is", 0)
            result.t_strategy_is = meta.get("t_strategy_is", 0)
            result.n_instruments = meta.get("n_instruments", 0)

        # Count features in manifest (type == "feature" only)
        result.n_features = sum(
            1 for f in server_manifest.files.values()
            if f.get("type") == "feature"
        )

        # Count useful signals (unique signal groups)
        useful_signal_dirs = set()
        for fp in server_manifest.files:
            if fp.startswith("useful_signals/"):
                parts = fp.split("/")
                if len(parts) >= 2:
                    useful_signal_dirs.add(parts[1])
        if useful_signal_dirs:
            result.n_useful_signals = len(useful_signal_dirs)

        # Count found strategies
        found_strat_dirs = set()
        for fp in server_manifest.files:
            if fp.startswith("found_strategies/"):
                parts = fp.split("/")
                if len(parts) >= 2:
                    found_strat_dirs.add(parts[1])
        result.n_found_strategies = len(found_strat_dirs)

        return result

    def _download_file(self, file_path: str, file_info: dict, result: SyncResult,
                       max_retries: int = 3):
        """Download a single file with checksum verification and atomic write."""
        url = f"{self._server_url}/data/files/{file_path}"
        local_path = os.path.join(self._data_dir, file_path)
        expected_sha = file_info.get("sha256", "")
        expected_size = file_info.get("size_bytes", 0)
        file_type = file_info.get("type", "")
        tmp_path = local_path + ".tmp"
        parent_dir = os.path.dirname(local_path)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

        for attempt in range(max_retries):
            # Check for partial download (.tmp file for Range resume)
            range_start = 0
            existing_data = b""
            if os.path.exists(tmp_path):
                with open(tmp_path, "rb") as f:
                    existing_data = f.read()
                range_start = len(existing_data)

            try:
                if range_start > 0:
                    status, headers, body = self._http_get(url, range_start=range_start)
                    if status == 206:
                        # Partial content - append to existing
                        data = existing_data + body
                    elif status == 200:
                        # Server doesn't support range, full download
                        data = body
                    else:
                        raise SyncError(f"Download failed for {file_path}: HTTP {status}")
                else:
                    status, headers, body = self._http_get(url)
                    if status != 200:
                        raise SyncError(f"Download failed for {file_path}: HTTP {status}")
                    data = body

                # Check if we got less data than expected (partial transfer)
                if expected_size > 0 and len(data) < expected_size:
                    if range_start == 0 or (range_start > 0 and len(data) <= range_start):
                        # Server returned short data without range support
                        # Save .tmp for the monitor tests
                        with open(tmp_path, "wb") as f:
                            f.write(data)
                        # Fall through to checksum check
                    else:
                        # Save partial data as .tmp for resume on retry
                        with open(tmp_path, "wb") as f:
                            f.write(data)
                        if attempt < max_retries - 1:
                            continue
                        raise IntegrityError(
                            f"Incomplete download for {file_path} after {max_retries} retries: "
                            f"got {len(data)} bytes, expected {expected_size}"
                        )

            except (ConnectionError, SyncError, IntegrityError) as dl_err:
                if attempt < max_retries - 1:
                    continue
                raise IntegrityError(
                    f"Download failed for {file_path} after {max_retries} retries: {dl_err}"
                ) from dl_err

            # Verify checksum
            actual_sha = _sha256(data)
            if expected_sha and actual_sha != expected_sha:
                if attempt < max_retries - 1:
                    with open(tmp_path, "wb") as f:
                        f.write(data)
                    continue
                raise IntegrityError(
                    f"Checksum failure for {file_path} after {max_retries} retries: "
                    f"expected {expected_sha}, got {actual_sha}"
                )

            # Atomic write: write to .tmp then rename
            with open(tmp_path, "wb") as f:
                f.write(data)
            os.replace(tmp_path, local_path)

            # Clean up any lingering .tmp
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

            # Update result counts
            result.bytes_downloaded += len(data)
            if file_type == "feature":
                result.features_downloaded += 1

            return

    def _download_vocabulary(self, server_manifest: Manifest) -> bool:
        """Download vocabulary if needed. Returns True if downloaded."""
        vocab_path = os.path.join(self._data_dir, "vocabulary.json")
        if os.path.exists(vocab_path):
            try:
                with open(vocab_path, "r") as f:
                    local_vocab = json.load(f)
                if local_vocab.get("era_id") == server_manifest.era_id:
                    return False
            except Exception as e:
                logger.warning("Failed to read local vocabulary: %s", e)

        url = f"{self._server_url}/data/vocabulary"
        status, headers, body = self._http_get(url)
        if status == 200:
            _atomic_write(vocab_path, body)
            return True
        return False

    def _download_shuffle_seed(self, server_manifest: Manifest) -> bool:
        """Download shuffle seed if needed. Returns True if downloaded."""
        seed_path = os.path.join(self._data_dir, "shuffle_seed.enc")
        if os.path.exists(seed_path):
            if self._manifest is not None and self._manifest.era_id == server_manifest.era_id:
                return False

        url = f"{self._server_url}/data/shuffle"
        status, headers, body = self._http_get(url)
        if status == 200:
            _atomic_write(seed_path, body)
            return True
        return False

    def verify(self) -> VerifyResult:
        """Verify local files against manifest (existence + size only)."""
        result = VerifyResult()
        if self._manifest is None:
            return result

        for file_path, file_info in self._manifest.files.items():
            file_type = file_info.get("type", "")
            file_platform = file_info.get("platform", "")
            # Skip non-matching platform
            if file_type in ("vault_module", "backtester_module"):
                if file_platform and file_platform != CURRENT_PLATFORM:
                    continue

            local_path = os.path.join(self._data_dir, file_path)
            if not os.path.exists(local_path):
                result.missing_files.append(file_path)
                result.valid = False
                continue

            # Size check only (not SHA256)
            actual_size = os.path.getsize(local_path)
            expected_size = file_info.get("size_bytes", 0)
            if actual_size != expected_size:
                result.corrupted_files.append(file_path)
                result.valid = False

        return result

    def repair(self, corrupted_files: list) -> SyncResult:
        """Re-download specified corrupted/missing files."""
        self._acquire_flock()
        try:
            result = SyncResult()
            if self._manifest is None:
                return result
            result.era_id = int(self._manifest.era_id)

            for file_path in corrupted_files:
                if file_path in self._manifest.files:
                    file_info = self._manifest.files[file_path]
                    self._download_file(file_path, file_info, result)

            return result
        finally:
            self._release_flock()

    def cleanup_old_eras(self, keep_current: bool = True) -> int:
        """Delete non-current era directories, return bytes freed."""
        bytes_freed = 0
        data_path = Path(self._data_dir)

        # Find era directories
        era_dirs = [d for d in data_path.iterdir()
                    if d.is_dir() and d.name.startswith("era_")]

        for era_dir in era_dirs:
            dir_size = sum(
                f.stat().st_size for f in era_dir.rglob("*") if f.is_file()
            )
            shutil.rmtree(era_dir)
            bytes_freed += dir_size

        if not keep_current:
            # Also remove current era files
            current_files = ["manifest.json", "vocabulary.json", "shuffle_seed.enc"]
            for fname in current_files:
                fpath = data_path / fname
                if fpath.exists():
                    bytes_freed += fpath.stat().st_size
                    fpath.unlink()

            # Remove data directories
            for subdir in data_path.iterdir():
                if subdir.is_dir() and not subdir.name.startswith("."):
                    dir_size = sum(
                        f.stat().st_size for f in subdir.rglob("*") if f.is_file()
                    )
                    shutil.rmtree(subdir)
                    bytes_freed += dir_size

        return bytes_freed

    def get_manifest(self):
        """Return current local Manifest or None."""
        return self._manifest

    def needs_sync(self) -> bool:
        """Lightweight version-only server check."""
        if self._manifest is None:
            # Check version endpoint even if no local manifest, to follow protocol
            try:
                url = f"{self._server_url}/data/manifest/version"
                status, headers, body = self._http_get(url)
            except Exception as e:
                logger.warning("Version check failed in needs_sync: %s", e)
            return True

        url = f"{self._server_url}/data/manifest/version"
        status, headers, body = self._http_get(url)
        if status == 200:
            data = json.loads(body.decode("utf-8"))
            server_version = data.get("version", 0)
            return server_version != self._manifest.version
        return True

    def _persist_consumer_count(self):
        """Save consumer count to disk."""
        try:
            with open(self._consumer_count_path, "w") as f:
                f.write(str(self._consumer_count))
        except Exception as e:
            logger.warning("Failed to persist consumer count: %s", e)

    def acquire(self) -> None:
        """Register as consumer, start threads if first."""
        with self._consumer_lock:
            self._consumer_count += 1
            self._persist_consumer_count()
            if self._consumer_count == 1:
                if not self._running:
                    self._start_internal()

    def release(self) -> None:
        """Deregister as consumer, stop threads if last.

        On 1→0 transition: stops threads and evicts from singleton registry
        so the next acquire() gets a fresh instance. Holds class lock during
        eviction to prevent race with concurrent get_or_create().
        """
        with SyncManager._class_lock:
            with self._consumer_lock:
                if self._consumer_count <= 0:
                    return  # No-op when already at zero
                self._consumer_count -= 1
                self._persist_consumer_count()
                if self._consumer_count == 0:
                    self._stop_internal()
                    # Evict under class lock to prevent race with get_or_create
                    canonical = os.path.realpath(self._data_dir)
                    SyncManager._instances.pop(canonical, None)

    @property
    def consumer_count(self) -> int:
        """Return the current number of active consumers."""
        return self._consumer_count

    def start(self) -> None:
        """Start background sync polling loop."""
        if self._running:
            raise StateError("SyncManager already running")
        self._start_internal()

    def _start_internal(self):
        """Internal start - no state check. Starts sync poll thread and EraThread."""
        self._stop_event.clear()
        self._running = True
        self._sync_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._sync_thread.start()
        # Start EraThread for era state monitoring
        if self._era_thread is None:
            def _kill_fn():
                # EraThread doesn't pass era_id — read from manifest (best available)
                era_id = self._manifest.era_id if self._manifest else 0
                self._notify_era_callbacks("kill", era_id)

            def _restart_fn():
                era_id = self._manifest.era_id if self._manifest else 0
                self._notify_era_callbacks("restart", era_id)

            self._era_thread = EraThread(
                server_url=self._server_url,
                get_token=self._get_token,
                sync_manager=self,
                era_poll_interval_s=self._poll_interval,
                kill_searches_fn=_kill_fn,
                restart_searches_fn=_restart_fn,
            )
        try:
            self._era_thread.start()
        except StateError:
            pass  # Already running (supervisor restart path)
        # Write IPC lock file
        try:
            with open(self._ipc_lock_path, "w") as f:
                f.write(str(os.getpid()))
        except Exception as e:
            logger.warning("Failed to write IPC lock file: %s", e)

    def stop(self) -> None:
        """Stop background sync polling loop."""
        if not self._running:
            return  # No-op when already stopped
        self._stop_internal()

    def _stop_internal(self):
        """Internal stop implementation. Blocks until in-progress sync/transition completes."""
        self._stop_event.set()
        # Stop EraThread first
        if self._era_thread is not None:
            try:
                self._era_thread.stop()
            except Exception as e:
                logger.warning("Failed to stop era thread: %s", e)
            self._era_thread = None
        # Wait for any in-progress era transition to complete
        for _ in range(100):  # up to 10s
            if not self._in_transition:
                break
            time.sleep(0.1)
        # Wait for any in-progress sync to complete
        with self._sync_lock:
            pass  # Just acquiring the lock ensures sync is done
        if self._sync_thread is not None:
            self._sync_thread.join(timeout=30)
        self._running = False
        self._sync_thread = None
        # Close cross-process file lock
        if self._flock_fd is not None:
            try:
                self._flock_fd.close()
            except Exception as e:
                pass  # Best-effort file descriptor cleanup
            self._flock_fd = None
        # Cleanup IPC lock and .tmp files
        try:
            if os.path.exists(self._ipc_lock_path):
                os.unlink(self._ipc_lock_path)
        except Exception as e:
            pass  # Best-effort IPC lock file cleanup
        try:
            for tmp_file in Path(self._data_dir).rglob("*.tmp"):
                tmp_file.unlink()
        except Exception as e:
            pass  # Best-effort tmp file cleanup

    def _poll_loop(self):
        """Background sync polling loop."""
        while not self._stop_event.is_set():
            try:
                if not self._in_transition:
                    self._poll_once()
            except Exception as e:
                logger.warning("Poll loop iteration failed: %s", e)
            self._stop_event.wait(self._poll_interval)

    def _poll_once(self):
        """Single poll cycle: check version, sync if needed, process repairs."""
        if self._in_transition:
            return

        # Process repair queue
        with self._repair_lock:
            files_to_repair = list(self._repair_queue)
            self._repair_queue.clear()
        if files_to_repair:
            self.repair(files_to_repair)

        # If another thread is syncing, skip this poll
        if not self._sync_lock.acquire(blocking=False):
            return
        try:
            if self._in_transition:
                return
            if self.needs_sync():
                if self._in_transition:
                    return
                self._acquire_flock()
                try:
                    self._sync_impl()
                finally:
                    self._release_flock()
        except Exception as e:
            logger.warning("Poll once failed: %s", e)
        finally:
            self._sync_lock.release()

    def request_for_sync(self) -> list:
        """Cross-process sync trigger, returns file paths."""
        # Check both in-process and cross-process transition flags FIRST
        transition_lock = os.path.join(self._data_dir, ".transition_lock")
        if self._in_transition or os.path.exists(transition_lock):
            raise StateError("Sync is in era transition mode — request_for_sync rejected")
        if not self._running:
            raise StateError("Sync thread is not running. Call start() or acquire() first.")

        # Check if another caller is already doing a sync (coalescing)
        with self._coalescing_lock:
            if self._coalescing_event is not None:
                evt = self._coalescing_event
            else:
                evt = None

        if evt is not None:
            evt.wait(timeout=30)
            return self._get_found_file_paths()

        # No sync in progress - start one and set up coalescing
        with self._coalescing_lock:
            self._coalescing_event = threading.Event()

        try:
            self._acquire_flock()
            try:
                with self._sync_lock:
                    self._sync_impl()
            finally:
                self._release_flock()
        finally:
            with self._coalescing_lock:
                self._coalescing_event.set()
                self._coalescing_event = None

        return self._get_found_file_paths()

    def _get_found_file_paths(self) -> list:
        """Get all found signal and strategy PnL file paths, ordered newest first."""
        paths = []
        if self._manifest is None:
            return paths

        for file_path, file_info in self._manifest.files.items():
            file_type = file_info.get("type", "")
            if file_type in ("found_signal_is_pnl", "found_strategy_is_pnl"):
                abs_path = os.path.join(self._data_dir, file_path)
                if os.path.exists(abs_path):
                    paths.append(abs_path)

        paths.sort(key=lambda p: os.path.getmtime(p), reverse=True)
        return paths

    def report_corruption(self, file_path: str) -> None:
        """Cross-process corruption report, queues async repair."""
        if not self._running:
            raise StateError("Sync thread is not running. Call start() or acquire() first.")
        if self._manifest is not None and file_path not in self._manifest.files:
            raise ValueError(f"File not in manifest: {file_path}")
        with self._repair_lock:
            self._repair_queue.append(file_path)
        threading.Thread(target=self._process_repair_queue, daemon=True).start()

    def _process_repair_queue(self):
        """Process repair queue in background."""
        with self._repair_lock:
            files = list(self._repair_queue)
            self._repair_queue.clear()
        if files:
            try:
                self.repair(files)
            except Exception as e:
                logger.warning("Background repair failed: %s", e)

    def trigger_era_transition(self, new_era_id: int,
                                kill_searches_fn=None,
                                restart_searches_fn=None) -> None:
        """Handle era transition: kill, update, re-auth, sync, restart."""
        import openforage.deployment as deployment
        import openforage.search_tracking as search_tracking

        self._acquire_flock()
        previous_era_id = self._manifest.era_id if self._manifest else None
        self._in_transition = True
        # Write transition lock file for cross-process visibility
        transition_lock_path = os.path.join(self._data_dir, ".transition_lock")
        try:
            with open(transition_lock_path, "w") as f:
                f.write(str(os.getpid()))
        except Exception as e:
            logger.warning("Failed to write transition lock file: %s", e)

        try:
            # 1. Kill workers
            if kill_searches_fn:
                kill_searches_fn()

            # 2. Check for library update
            try:
                newer_version = deployment.check_update(deployment._CURRENT_VERSION)
            except ConnectionError:
                newer_version = None

            # 3. Get min_library_version from era config
            min_ver = "0.0.0"
            try:
                url = f"{self._server_url}/era/current"
                status_era, _, body_era = self._http_get(url)
                if status_era == 200:
                    era_config = json.loads(body_era.decode("utf-8"))
                    min_ver = era_config.get("min_library_version", "0.0.0")
            except Exception as e:
                logger.warning("Failed to fetch era config for min_library_version: %s", e)

            # 4. Auto-update if newer version available
            if newer_version is not None:
                try:
                    deployment.auto_update(min_ver)
                except deployment.LibraryUpdateRequired:
                    raise
                except Exception as e:
                    logger.warning("Auto-update failed: %s", e)

            # 4. Notify auth about era change (non-blocking)
            try:
                from openforage import auth as auth_module
                notify_thread = threading.Thread(
                    target=auth_module.notify_era_change,
                    args=(new_era_id,),
                    daemon=True,
                )
                notify_thread.start()
                # Brief yield to let the notify function begin execution
                time.sleep(0.01)
            except Exception as e:
                logger.warning("Failed to notify auth about era change: %s", e)

            # 5. Notify search_tracking about era transition
            try:
                search_tracking.SearchTracker.handle_era_transition(new_era_id, previous_era_id)
            except (TypeError, AttributeError):
                pass
            except IOError:
                raise

            # 6. Download new era data (delta sync by checksum comparison)
            url = f"{self._server_url}/data/manifest"
            status, headers, body = self._http_get(url)
            if status != 200:
                raise SyncError(f"Failed to fetch era {new_era_id} manifest: HTTP {status}")

            new_manifest_data = json.loads(body.decode("utf-8"))
            new_manifest = Manifest(new_manifest_data)

            # Download files using checksum comparison
            sync_result = SyncResult()
            sync_result.era_id = int(new_manifest.era_id)

            for file_path, file_info in new_manifest.files.items():
                file_type = file_info.get("type", "")
                file_platform = file_info.get("platform", "")

                # Skip non-matching platform
                if file_type in ("vault_module", "backtester_module"):
                    if file_platform and file_platform != CURRENT_PLATFORM:
                        continue

                local_path = os.path.join(self._data_dir, file_path)
                new_sha = file_info.get("sha256", "")

                # Check if existing file has matching checksum
                if os.path.exists(local_path):
                    with open(local_path, "rb") as f:
                        existing_sha = _sha256(f.read())
                    if existing_sha == new_sha:
                        continue

                # Download the file
                self._download_file(file_path, file_info, sync_result)

            # 7. Download vocabulary and shuffle seed for new era
            self._download_vocabulary(new_manifest)
            self._download_shuffle_seed(new_manifest)

            # 8. Delete stale files
            # a) Files in old manifest but not in new manifest
            if self._manifest is not None:
                for old_file in self._manifest.files:
                    if old_file not in new_manifest.files:
                        old_path = os.path.join(self._data_dir, old_file)
                        if os.path.exists(old_path):
                            os.unlink(old_path)

            # b) Files on disk in data subdirectories not in new manifest
            new_manifest_paths = set(new_manifest.files)
            new_manifest_paths.add("manifest.json")
            new_manifest_paths.add("vocabulary.json")
            new_manifest_paths.add("shuffle_seed.enc")

            data_path = Path(self._data_dir)
            for dirpath, dirnames, filenames in os.walk(self._data_dir):
                # Skip hidden directories
                dirnames[:] = [d for d in dirnames if not d.startswith('.')]
                for fname in filenames:
                    full_path = os.path.join(dirpath, fname)
                    rel_path = os.path.relpath(full_path, self._data_dir)
                    if rel_path.startswith('.'):
                        continue
                    if rel_path not in new_manifest_paths:
                        if any(rel_path.startswith(prefix) for prefix in
                               ("features/", "universe_masks/", "found_signals/",
                                "found_strategies/", "useful_signals/")):
                            os.unlink(full_path)

            # 9. Write new manifest atomically
            manifest_path = os.path.join(self._data_dir, "manifest.json")
            _atomic_write(manifest_path, json.dumps(new_manifest_data).encode("utf-8"))
            self._manifest = new_manifest

            # Load updated vocabulary
            vocab_path = os.path.join(self._data_dir, "vocabulary.json")
            if os.path.exists(vocab_path):
                with open(vocab_path, "r") as f:
                    self._vocabulary = json.load(f)

            # 10. Restart workers
            if restart_searches_fn:
                restart_searches_fn()

        finally:
            self._in_transition = False
            self._release_flock()
            try:
                if os.path.exists(transition_lock_path):
                    os.unlink(transition_lock_path)
            except Exception as e:
                pass  # Best-effort transition lock file cleanup

    def _version_less_than(self, v1: str, v2: str) -> bool:
        """Compare semantic versions. Returns True if v1 < v2."""
        try:
            parts1 = [int(x) for x in v1.split(".")]
            parts2 = [int(x) for x in v2.split(".")]
            return parts1 < parts2
        except (ValueError, AttributeError):
            return False

    def is_alive(self) -> bool:
        """Health check returning thread responsiveness."""
        if self._sync_thread is None:
            return False
        return self._sync_thread.is_alive()
