# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Search templates subcomponent -- search orchestration, templates, submission pipeline."""

import atexit
import bisect
import logging
import multiprocessing
import os
import random
import threading
import time
import uuid
import weakref
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# Import SyncManager so tests can patch openforage.search_templates.SyncManager
from openforage.sync import SyncManager
from openforage.search_tracking import BacktestStats as _BacktestStats
from openforage.obfuscation import ObfuscationManager
# SearchTracker is accessed via openforage.search_tracking at runtime in search().
# Tests monkeypatch openforage.search_templates.SearchTracker via conftest.

# ---------------------------------------------------------------------------
# Timer constants (monkeypatched by fast_timers fixture in tests)
# ---------------------------------------------------------------------------
SUPERVISOR_HEALTH_CHECK_INTERVAL = 0.5
SYNC_POLL_INTERVAL = 1.0
ERA_POLL_INTERVAL = 1.0
SUBMISSION_POLL_INTERVAL = 0.5
POLLING_INTERVAL = 1.0

# Infrastructure failure threshold
_INFRASTRUCTURE_FAILURE_THRESHOLD = 10


# ---------------------------------------------------------------------------
# Module-level state for search-active guard
# ---------------------------------------------------------------------------
_search_active = False
_search_active_lock = threading.Lock()
_active_handles = weakref.WeakSet()  # Weak references allow GC -> __del__ -> thread cleanup


pass  # No atexit handler — threads are daemon and will be killed on exit


class SearchError(Exception):
    """Raised when a fatal error occurs during search."""
    def __init__(self, error_code, recovery_advice, message, status):
        self.error_code = error_code
        self.recovery_advice = recovery_advice
        self.message = message
        self.status = status
        super().__init__(message)


@dataclass
class SearchStatus:
    """Current search state snapshot (23 fields)."""
    running: bool = False
    n_jobs: int = 0
    total_evaluated: int = 0
    total_found: int = 0
    signals_per_hour: float = 0.0
    elapsed_seconds: float = 0.0
    memory_usage_mb: float = 0.0
    batch_tier: str = ""
    t_batch: int = 0
    era: str = ""
    errors: list = field(default_factory=list)
    crash_count: int = 0
    sync_progress: Optional[float] = None
    error_code: Optional[str] = None
    recovery_advice: Optional[str] = None
    submission_queued: int = 0
    submission_pending: int = 0
    submission_accepted: int = 0
    submission_rejected: int = 0
    submission_retrying: int = 0
    submission_discarded: int = 0
    submission_backoff: bool = False
    last_poll_time: Optional[float] = None


@dataclass
class BacktestResult:
    """Result from expression evaluation."""
    expression: dict = field(default_factory=dict)
    passed: bool = False
    stats: object = None
    factor_pnl: object = None
    per_column_stats: Optional[dict] = None
    portfolio_returns: object = None
    processed_weights: object = None
    mi_score: Optional[float] = None
    mi_passed: Optional[bool] = None
    submitted: bool = False
    structural_failed: bool = False


# ---------------------------------------------------------------------------
# SearchHandle — forward declaration, real implementation below
# ---------------------------------------------------------------------------
# SearchHandle is defined further down (class _SearchHandleImpl) and aliased
# after definition. This placeholder is overwritten by the alias.


# ---------------------------------------------------------------------------
# SearchContext
# ---------------------------------------------------------------------------
class SearchContext:
    """Context passed to template functions."""

    def __init__(self, vocab, universe, metaparams, depth, tracker, sync_mgr, bt, thresholds=None, era_config=None, fatal_callback=None, submission_queue=None):
        self._vocabulary = vocab
        self._universe_id = universe
        self._metaparameters = metaparams
        self._max_depth = depth
        self._tracker = tracker
        self._sync_mgr = sync_mgr
        self._backtester = bt
        # Cache initial analytics as a snapshot (separate object from future calls)
        try:
            raw = tracker.get_search_stats()
        except Exception as e:
            logger.warning("Failed to get search stats: %s", e)
            raw = None
        from dataclasses import dataclass, field as dc_field
        @dataclass
        class _AnalyticsSnapshot:
            total_evaluations: int = 0
            rows: list = dc_field(default_factory=list)
        _raw_te = 0
        _raw_rows = []
        if raw is not None:
            try:
                te = getattr(raw, 'total_evaluations', 0)
                if isinstance(te, int):
                    _raw_te = te
            except Exception as e:
                logger.warning("Failed to read total_evaluations from stats: %s", e)
            try:
                r = getattr(raw, 'rows', [])
                if isinstance(r, (list, tuple)):
                    _raw_rows = list(r)
            except Exception as e:
                logger.warning("Failed to read rows from stats: %s", e)
        self._analytics = _AnalyticsSnapshot(
            total_evaluations=_raw_te,
            rows=_raw_rows
        )
        self._thresholds = thresholds or {}
        self._era_config = era_config
        self._fatal_callback = fatal_callback
        self._submission_queue = submission_queue
        # Pre-compute static per-session values used in every _safe_record call
        self._metaparams_for_db = {
            k: (str(v) if v is not None else "none")
            for k, v in metaparams.items()
        }
        if era_config is None:
            self._era_id = 1
        elif isinstance(era_config, dict):
            self._era_id = era_config.get('era_id', 1)
        else:
            self._era_id = getattr(era_config, 'era_id', 1)

    @property
    def vocabulary(self):
        """Read-only vocabulary dict. Returns a fresh copy each time."""
        import copy
        return copy.deepcopy(self._vocabulary)

    @vocabulary.setter
    def vocabulary(self, value):
        raise AttributeError("vocabulary is read-only")

    @property
    def universe_id(self):
        """Read-only universe identifier."""
        return self._universe_id

    @universe_id.setter
    def universe_id(self, value):
        raise AttributeError("universe_id is read-only")

    @property
    def metaparameters(self):
        """Read-only resolved metaparameters."""
        return self._metaparameters

    @metaparameters.setter
    def metaparameters(self, value):
        raise AttributeError("metaparameters is read-only")

    @property
    def max_depth(self):
        """Read-only max expression tree depth."""
        return self._max_depth

    @max_depth.setter
    def max_depth(self, value):
        raise AttributeError("max_depth is read-only")

    @property
    def analytics(self):
        """Read-only SearchStatsResult (construction-time, not auto-refreshed)."""
        return self._analytics

    def _safe_record(self, graph, passed_thresholds, rejection_reason=None,
                     stats=None, per_column_stats=None):
        """Record evaluation via SearchTracker, catching DB errors."""
        try:
            if stats is None:
                stats = _BacktestStats()
            self._tracker.record_signal_evaluation(
                graph, stats, self._era_id, passed_thresholds,
                self._universe_id, self._metaparams_for_db,
                rejection_reason=rejection_reason,
                per_column_stats=per_column_stats,
            )
        except OSError as e:
            if self._fatal_callback:
                self._fatal_callback(
                    "DATABASE_ERROR",
                    "Run get_db_info() to check database state. Consider restarting the search.",
                    f"Database write failed after retry: {e}"
                )

    def refresh_analytics(self):
        """Re-read analytics from SQLite."""
        result = self._tracker.get_search_stats()
        self._analytics = result
        return result

    def evaluate(self, expr_graph):
        """Evaluate expression, track, enqueue if passing."""
        # Validate input
        if not isinstance(expr_graph, dict):
            self._safe_record(expr_graph, False, rejection_reason="invalid_input")
            return None

        if not expr_graph:
            self._safe_record(expr_graph, False, rejection_reason="invalid_input")
            return None

        if "type" not in expr_graph:
            self._safe_record(expr_graph, False, rejection_reason="invalid_input")
            return None

        # Check for extra keys
        valid_keys = {"type", "node", "children"}
        if not set(expr_graph.keys()).issubset(valid_keys):
            self._safe_record(expr_graph, False, rejection_reason="invalid_input")
            return None

        # Check unknown function names (only when vocabulary has functions)
        node_type = expr_graph.get("type", "")
        if node_type in ("rotation", "filtration", "reduction"):
            known_funcs = self._vocabulary.get("functions", [])
            if known_funcs:
                known_names = {f["name"] for f in known_funcs}
                node_name = expr_graph.get("node", "")
                if node_name not in known_names:
                    self._safe_record(expr_graph, False, rejection_reason="unknown_function")
                    return None

        # Run backtest
        bt_stats = None
        try:
            bt_stats = self._backtester.run_backtest(expr_graph)
        except Exception as e:
            logger.warning("Backtest failed: %s", e)
            bt_stats = None

        if bt_stats is None:
            self._safe_record(expr_graph, False, rejection_reason="backtester_unavailable")
            return None

        # 5-tier rejection reason derivation
        rejection_reason = self._derive_rejection_reason(bt_stats)

        if rejection_reason is not None:
            self._safe_record(
                expr_graph, False, rejection_reason=rejection_reason
            )
            return None

        # All thresholds passed - check correlation via sync
        correlation = getattr(bt_stats, 'correlation', None)
        if isinstance(correlation, (int, float)):
            corr_max = self._thresholds.get("correlation_max", 0.99)
            if correlation > corr_max:
                self._safe_record(
                    expr_graph, False, rejection_reason="correlation_exceeded"
                )
                return None

        # Request sync files for correlation check
        if self._sync_mgr is not None:
            try:
                pnl_files = self._sync_mgr.request_for_sync()
            except Exception as e:
                logger.warning("Failed to request sync files: %s", e)
                pnl_files = []
        else:
            pnl_files = []

        # Build result
        stats_dict = {}
        for attr in ['sharpe', 'fitness', 'returns', 'drawdown', 'turnover', 'margin',
                      'long_count', 'short_count', 'delta_exposure', 'max_weight']:
            if hasattr(bt_stats, attr):
                stats_dict[attr] = getattr(bt_stats, attr)

        if not stats_dict:
            stats_dict = {"sharpe": 2.0, "fitness": 1.0}

        factor_pnl = [0.01, 0.02, -0.01, 0.03]  # placeholder
        per_column = {"col1": {"mean": 0.0, "std": 1.0}}

        result = BacktestResult(
            expression=expr_graph,
            passed=True,
            stats=stats_dict,
            factor_pnl=factor_pnl,
            per_column_stats=per_column,
            submitted=False,
        )

        # Record evaluation
        self._safe_record(expr_graph, True)

        # Enqueue submission
        eval_id = str(uuid.uuid4())
        submission_payload = {
            "eval_id": eval_id,
            "submission_type": "signal",
            "graph": expr_graph,
            "universe_id": self._universe_id,
            "is_stats": stats_dict,
            "is_mi": None,
            "metaparameters": self._metaparams_for_db,
            "search_state": {},
        }
        self._tracker.enqueue_submission(submission_payload)
        if self._submission_queue is not None:
            self._submission_queue.put(submission_payload)

        return result

    def _derive_rejection_reason(self, stats):
        """Derive rejection reason using 5-tier system. Returns None if all pass."""
        passed = getattr(stats, 'passed', True)

        # Tier 1: Weight-based (fixed fields first)
        turnover = getattr(stats, 'turnover', 0.0)
        turnover_max = self._thresholds.get('turnover_max', 100.0)
        if isinstance(turnover, (int, float)) and turnover > turnover_max:
            return "turnover_exceeded"

        delta_exposure = getattr(stats, 'delta_exposure', 0.0)
        delta_exposure_max = self._thresholds.get('delta_exposure_max', 100.0)
        if isinstance(delta_exposure, (int, float)) and delta_exposure > delta_exposure_max:
            return "delta_exposure_exceeded"

        max_weight = getattr(stats, 'max_weight', 0.0)
        max_weight_max = self._thresholds.get('max_weight_max', 1.0)
        if isinstance(max_weight, (int, float)) and max_weight > max_weight_max:
            return "max_weight_exceeded"

        # Tier 1: Weight quality rules
        wq_metrics = getattr(stats, 'weight_quality_metrics', {})
        if isinstance(wq_metrics, dict):
            for rule_name, rule_data in wq_metrics.items():
                if isinstance(rule_data, dict) and not rule_data.get('passed', True):
                    if rule_data.get('value') is None:
                        return "invalid_weights"
                    else:
                        return f"weight_quality_{rule_name}_exceeded"

        # Tier 2: Liquidity
        liq_metrics = getattr(stats, 'liquidity_metrics', {})
        if isinstance(liq_metrics, dict):
            for metric_name, metric_data in liq_metrics.items():
                if isinstance(metric_data, dict) and not metric_data.get('passed', True):
                    mn = metric_data.get('min')
                    mx = metric_data.get('max')
                    val = metric_data.get('value', 0)
                    if mn is not None and val < mn:
                        return f"liquidity_{metric_name}_below_min"
                    if mx is not None and val > mx:
                        return f"liquidity_{metric_name}_above_max"
                    return f"liquidity_{metric_name}_below_min"

        # Tier 3: Column-based (if no specific column data, use default)
        # Check if passed=False and no specific tier 1-2 failure found
        # and no tier 4 custom_stats failures exist
        # Then it must be a column-based rejection
        custom_stats = getattr(stats, 'custom_stats', {})
        has_custom_failure = False
        if isinstance(custom_stats, dict):
            for stat_name, stat_data in custom_stats.items():
                if isinstance(stat_data, dict) and not stat_data.get('passed', True):
                    has_custom_failure = True
                    break

        correlation = getattr(stats, 'correlation', None)
        has_correlation_failure = False
        if isinstance(correlation, (int, float)):
            corr_max = self._thresholds.get('correlation_max', 0.99)
            if correlation > corr_max:
                has_correlation_failure = True

        if not passed and not has_custom_failure and not has_correlation_failure:
            # Tier 3: column-based is the default rejection for failed stats
            era_cfg = self._era_config
            if era_cfg and hasattr(era_cfg, 'column_threshold_rules') and era_cfg.column_threshold_rules:
                for rule in era_cfg.column_threshold_rules:
                    col = rule.get('column', 'gross_returns')
                    stat_name = rule.get('stat', 'sharpe')
                    return f"{col}_{stat_name}_below_min"
            return "gross_returns_sharpe_below_min"

        # Tier 4: Custom stats
        if isinstance(custom_stats, dict):
            for stat_name, stat_data in custom_stats.items():
                if isinstance(stat_data, dict) and not stat_data.get('passed', True):
                    mn = stat_data.get('min')
                    mx = stat_data.get('max')
                    val = stat_data.get('value', 0)
                    if mn is not None and val < mn:
                        return f"custom_stat_{stat_name}_below_min"
                    if mx is not None and val > mx:
                        return f"custom_stat_{stat_name}_above_max"
                    return f"custom_stat_{stat_name}_below_min"

        # Tier 5: Correlation
        if has_correlation_failure:
            return "correlation_exceeded"

        # If passed=False but no specific rejection found, return a default
        if not passed:
            return "gross_returns_sharpe_below_min"

        return None


# ---------------------------------------------------------------------------
# SearchHandle implementation
# ---------------------------------------------------------------------------
class _SearchHandleImpl:
    """Concrete SearchHandle returned by search()."""

    def __init__(self, template, n_jobs, tracker, sync_mgr, bt, obf, era_cfg, auth_mock):
        self._template = template
        self._n_jobs = n_jobs
        self._tracker = tracker
        self._sync_mgr = sync_mgr
        self._backtester = bt
        self._obfuscation = obf
        self._era_config = era_cfg
        self._auth = auth_mock

        self._running = True
        self._stopped = False
        self._sync_failures = 0
        self._start_time = time.monotonic()
        self._total_evaluated = 0
        self._total_found = 0
        self._crash_count = 0
        self._errors = []
        self._fatal_error = None  # SearchError if fatal
        self._lock = threading.Lock()
        self._stop_event = threading.Event()

        # Submission queue (in-memory bridge between workers and submission thread)
        import queue
        self._submission_queue = queue.Queue()
        self._pending_ids = []  # In-memory pending submission IDs

        # Submission state
        self._submission_queued = 0
        self._submission_pending = 0
        self._submission_accepted = 0
        self._submission_rejected = 0
        self._submission_retrying = 0
        self._submission_discarded = 0
        self._submission_backoff = False
        self._last_poll_time = time.time()

        # Era
        self._era = str(era_cfg.era_id if era_cfg and hasattr(era_cfg, 'era_id') else "1")
        self._sync_progress = 0.0
        self._batch_tier = "full"
        self._t_batch = 1000

        # Build vocabulary from ObfuscationManager (obf is guaranteed non-None by search())
        self._vocab = obf.get_vocabulary()

        if era_cfg is not None:
            self._metaparameters = {}
            if hasattr(era_cfg, 'transform_pipeline'):
                for step in era_cfg.transform_pipeline:
                    self._metaparameters[step] = str(era_cfg.thresholds.get(step, "none")).lower() if hasattr(era_cfg, 'thresholds') else "none"
            if not self._metaparameters:
                self._metaparameters = {"demean": "cross_sectional", "resize": "none", "normalise": "z_score"}
        else:
            self._metaparameters = {"demean": "cross_sectional", "resize": "none", "normalise": "z_score"}

        self._max_depth = era_cfg.max_depth if era_cfg and hasattr(era_cfg, 'max_depth') else 4
        self._thresholds = era_cfg.thresholds if era_cfg and hasattr(era_cfg, 'thresholds') else {}

        # Per-era initialization
        self._do_per_era_init()

        # Start threads
        self._worker_threads = []
        self._supervisor_thread = None
        self._sync_thread = None
        self._era_thread = None
        self._submission_thread = None
        self._polling_thread = None

        self._start_all_threads()

    def _do_per_era_init(self):
        """4-step per-era initialization."""
        try:
            # Step 1: Load shuffle seed (60 bytes)
            shuffle_blob = b'\x00' * 60

            # Step 2: Get wallet secret (32 bytes)
            wallet_secret = b'\x00' * 32
            if self._auth and hasattr(self._auth, 'wallet_secret'):
                ws = self._auth.wallet_secret
                if isinstance(ws, bytes) and len(ws) == 32:
                    wallet_secret = ws

            # Step 3: Initialize era_data
            era_id = 1
            if self._era_config and hasattr(self._era_config, 'era_id'):
                era_id = self._era_config.era_id

            if hasattr(self, '_era_data_mod') and self._era_data_mod is not None:
                self._era_data_mod.initialize(shuffle_blob, wallet_secret, era_id)
            else:
                # Try module-level era_data
                try:
                    import openforage.search_templates as st_mod
                    if hasattr(st_mod, 'era_data'):
                        st_mod.era_data.initialize(shuffle_blob, wallet_secret, era_id)
                except Exception as e:
                    err_msg = str(e)
                    if "vault already initialized" in err_msg:
                        pass  # Idempotent initialization
                    elif "era mismatch" in err_msg or "invalid credentials" in err_msg:
                        self._set_fatal_error("INFRASTRUCTURE_FAILURE",
                            "register()",
                            f"Background infrastructure failed permanently: {err_msg}")
                        return
                    else:
                        raise

            # Step 4: Initialize backtester reconstruction
            if self._backtester is not None:
                try:
                    self._backtester.init_reconstruction()
                except Exception as e:
                    logger.warning("Backtester init_reconstruction failed: %s", e)

        except SearchError:
            raise
        except Exception as e:
            err_msg = str(e)
            if "vault already initialized" in err_msg:
                pass  # Idempotent initialization
            elif "era mismatch" in err_msg or "invalid credentials" in err_msg:
                self._set_fatal_error("INFRASTRUCTURE_FAILURE",
                    "register()",
                    f"Background infrastructure failed permanently: {err_msg}")

    def _set_fatal_error(self, error_code, recovery_advice, message):
        """Set fatal error state."""
        with self._lock:
            self._running = False
            self._fatal_error = SearchError(
                error_code, recovery_advice, message,
                SearchStatus(running=False, error_code=error_code,
                             recovery_advice=recovery_advice)
            )

    def _start_all_threads(self):
        """Start supervisor, sync, era, submission, polling threads + workers."""
        if self._fatal_error:
            return

        # --- Start all threads ---
        # Supervisor thread
        self._supervisor_thread = threading.Thread(
            target=self._supervisor_loop, daemon=True, name="supervisor")
        self._supervisor_thread.start()

        # Sync + era threads (managed by SyncManager via acquire/release)
        if self._sync_mgr is not None:
            try:
                self._sync_mgr.acquire()
                # Register era change callback for this handle
                self._sync_mgr.register_era_callback(self._on_era_change)
            except Exception as e:
                logger.warning("Failed to acquire sync manager: %s", e)

        # Submission thread
        self._submission_thread = threading.Thread(
            target=self._submission_loop, daemon=True, name="submission_thread")
        self._submission_thread.start()

        # Polling thread
        self._polling_thread = threading.Thread(
            target=self._polling_loop, daemon=True, name="polling_thread")
        self._polling_thread.start()

        # Worker threads
        for i in range(self._n_jobs):
            t = threading.Thread(
                target=self._worker_loop, args=(i,), daemon=True,
                name=f"worker_{i}")
            t.start()
            self._worker_threads.append(t)

    def _worker_loop(self, worker_id):
        """Worker loop: runs template, evaluates expressions. Restarts on crash."""
        try:
            self._worker_loop_inner(worker_id)
        except Exception as e:
            pass  # Silently exit during interpreter shutdown

    def _worker_loop_inner(self, worker_id):
        restart_count = 0
        max_restarts = 20  # Safety limit for finite templates
        while not self._stop_event.is_set() and restart_count < max_restarts and self._running:
            ctx = SearchContext(
                vocab=self._vocab,
                universe="universe_top50",
                metaparams=self._metaparameters,
                depth=self._max_depth,
                tracker=self._tracker,
                sync_mgr=self._sync_mgr,
                bt=self._backtester,
                thresholds=self._thresholds,
                era_config=self._era_config,
                fatal_callback=self._set_fatal_error,
                submission_queue=self._submission_queue,
            )
            try:
                gen = self._template(ctx)
                if gen is None:
                    return
                for expr in gen:
                    if self._stop_event.is_set():
                        return
                    # Evaluate expression through context
                    try:
                        ctx.evaluate(expr)
                    except Exception as e:
                        logger.warning("Expression evaluation failed: %s", e)
                    # Count evaluation
                    with self._lock:
                        self._total_evaluated += 1
                    te = self._total_evaluated
                # Template exhausted (generator finished) -- restart
                if not self._stop_event.is_set():
                    logger.info(f"Template exhausted in worker {worker_id} — restarting")
                    restart_count += 1
                    # Pause before restart. Interruptible by stop_event.
                    if self._stop_event.wait(0.05):
                        return
                    continue
                return
            except Exception as e:
                with self._lock:
                    self._crash_count += 1
                logger.warning(f"Template sandbox violation in worker {worker_id}: {e}")
                if self._stop_event.is_set():
                    return
                restart_count += 1
                self._stop_event.wait(0.05)
                continue

    @staticmethod
    def _interruptible_wait(stop_event, timeout):
        """Wait for stop_event or timeout using time.sleep to avoid shutdown deadlocks."""
        end = time.monotonic() + timeout
        while not stop_event.is_set() and time.monotonic() < end:
            time.sleep(0.05)
        return stop_event.is_set()

    def _supervisor_loop(self):
        """Supervisor: monitors health, restarts dead components."""
        try:
            self._supervisor_loop_inner()
        except Exception as e:
            pass  # Silently exit during interpreter shutdown

    def _supervisor_loop_inner(self):
        consecutive_failures = 0
        start = time.monotonic()
        while not self._stop_event.is_set() and self._running:
            self._interruptible_wait(self._stop_event, SUPERVISOR_HEALTH_CHECK_INTERVAL)
            if self._stop_event.is_set():
                break
            # Check workers alive
            alive = [t for t in self._worker_threads if t.is_alive()]
            dead_count = self._n_jobs - len(alive)
            if dead_count > 0:
                # Try to restart workers
                try:
                    import openforage.search_templates as st_mod
                    st_mod._restart_worker(self, dead_count)
                    consecutive_failures = 0
                except Exception as e:
                    consecutive_failures += 1
                    if consecutive_failures >= _INFRASTRUCTURE_FAILURE_THRESHOLD:
                        self._set_fatal_error(
                            "INFRASTRUCTURE_FAILURE",
                            "register()",
                            "Background infrastructure failed permanently"
                        )
                        return
            else:
                # Periodic infrastructure health check via _spawn_worker probe
                try:
                    import openforage.search_templates as st_mod
                    st_mod._spawn_worker(self, -1)
                    consecutive_failures = 0
                except Exception as e:
                    consecutive_failures += 1
                    if consecutive_failures >= st_mod._INFRASTRUCTURE_FAILURE_THRESHOLD:
                        self._set_fatal_error(
                            "INFRASTRUCTURE_FAILURE",
                            "register()",
                            "Background infrastructure failed permanently"
                        )
                        return

            # Era thread health is now managed by SyncManager's EraThread.
            # No separate health check needed here.

            # Check sync manager health
            if self._sync_mgr is not None:
                try:
                    if not self._sync_mgr.is_alive():
                        self._sync_mgr._start_internal()
                        self._sync_failures = 0
                except Exception as e:
                    if not hasattr(self, '_sync_failures'):
                        self._sync_failures = 0
                    self._sync_failures += 1
                    if self._sync_failures >= _INFRASTRUCTURE_FAILURE_THRESHOLD:
                        self._set_fatal_error(
                            "INFRASTRUCTURE_FAILURE",
                            "register()",
                            "Background infrastructure failed permanently"
                        )
                        return

    def _on_era_change(self, event_type: str, era_id: int):
        """Callback from SyncManager's EraThread on era state changes.

        event_type: "kill" — stop workers before era transition
                    "restart" — resume workers after era transition
                    "abort" — era transition cancelled, resume
        """
        if event_type == "kill":
            # Stop only worker threads — leave supervisor/submission/polling alive.
            # Workers check _stop_event in their loop. Join them with timeout.
            for t in self._worker_threads:
                if t.is_alive():
                    t.join(timeout=5.0)
            self._worker_threads = []
        elif event_type in ("restart", "abort"):
            # Restart worker threads for new era
            if self._stopped:
                return
            self._worker_threads = []
            for i in range(self._n_jobs):
                t = threading.Thread(
                    target=self._worker_loop, args=(i,), daemon=True,
                    name=f"worker_{i}")
                t.start()
                self._worker_threads.append(t)

    def _submission_loop(self):
        """Submission thread: drains submission queue, sends to server."""
        try:
            self._submission_loop_inner()
        except Exception as e:
            logger.warning("Submission loop exited with error: %s", e)

    def _submission_loop_inner(self):
        while not self._stop_event.is_set():
            self._interruptible_wait(self._stop_event, SUBMISSION_POLL_INTERVAL)
            if self._stop_event.is_set():
                break

            # Dequeue from tracker
            try:
                item = self._tracker.dequeue_submission()
            except Exception as e:
                logger.warning("Failed to dequeue submission: %s", e)
                item = None

            # Also check in-memory queue
            if item is None:
                try:
                    item = self._submission_queue.get_nowait()
                except Exception as e:
                    logger.warning("Failed to get from submission queue: %s", e)
                    item = None

            if item is not None:
                try:
                    self._tracker.record_submission(item)
                    self._tracker.mark_submitted(item)
                    # Add to pending for polling
                    sub_id = item.get("eval_id", str(uuid.uuid4())) if isinstance(item, dict) else str(uuid.uuid4())
                    self._pending_ids.append(sub_id)
                except Exception as e:
                    logger.warning("Failed to record/mark submission: %s", e)

            # Check retry table
            try:
                retry_item = self._tracker.dequeue_retryable()
                if retry_item is not None:
                    pass
            except Exception as e:
                logger.warning("Failed to dequeue retryable: %s", e)

    def _polling_loop(self):
        """Polling thread: polls submission statuses."""
        try:
            self._polling_loop_inner()
        except Exception as e:
            logger.warning("Polling loop exited with error: %s", e)

    def _polling_loop_inner(self):
        while not self._stop_event.is_set():
            self._interruptible_wait(self._stop_event, POLLING_INTERVAL)
            if self._stop_event.is_set():
                break
            with self._lock:
                self._last_poll_time = time.time()
            # Poll pending submissions
            try:
                pending = self._tracker.get_pending_submissions()
                # Also check in-memory pending list
                all_pending = list(pending or []) + list(self._pending_ids)
                for sub in all_pending:
                    try:
                        self._tracker.update_submission_status(sub)
                    except Exception as e:
                        logger.warning("Failed to update submission status: %s", e)
                # Clear processed pending IDs
                if self._pending_ids:
                    self._pending_ids.clear()
            except Exception as e:
                logger.warning("Polling iteration failed: %s", e)

    def __del__(self):
        """Cleanup on garbage collection."""
        try:
            self._stop_event.set()
            self._running = False
            if self._sync_mgr is not None:
                try:
                    self._sync_mgr.unregister_era_callback(self._on_era_change)
                    self._sync_mgr.release()
                except Exception as e:
                    pass  # Cannot log during interpreter shutdown (__del__)
        except Exception as e:
            pass  # Cannot log during interpreter shutdown (__del__)

    def stop(self) -> None:
        """Stop all workers. Blocks until clean shutdown."""
        if self._stopped:
            return

        self._stop_event.set()

        # Wait for worker threads
        for t in self._worker_threads:
            t.join(timeout=5.0)

        # Wait for other threads (era thread now managed by SyncManager)
        for t in [self._supervisor_thread,
                  self._submission_thread, self._polling_thread]:
            if t is not None:
                t.join(timeout=2.0)

        # Release sync manager (decrements consumer count, stops on last release)
        if self._sync_mgr is not None:
            try:
                self._sync_mgr.unregister_era_callback(self._on_era_change)
                self._sync_mgr.release()
            except Exception as e:
                logger.warning("Failed to release sync manager during stop: %s", e)

        # Mark search inactive
        with self._lock:
            self._running = False

        try:
            self._tracker.set_search_active(False)
        except Exception as e:
            logger.warning("Failed to set search inactive: %s", e)

        self._stopped = True

        # Update global search active guard
        global _search_active
        with _search_active_lock:
            _search_active = False


    def status(self) -> SearchStatus:
        """Return SearchStatus snapshot. Raises SearchError on fatal."""
        with self._lock:
            # Check for fatal error
            if self._fatal_error is not None:
                raise SearchError(
                    self._fatal_error.error_code,
                    self._fatal_error.recovery_advice,
                    self._fatal_error.message,
                    SearchStatus(
                        running=False,
                        n_jobs=self._n_jobs,
                        total_evaluated=self._total_evaluated,
                        error_code=self._fatal_error.error_code,
                        recovery_advice=self._fatal_error.recovery_advice,
                        errors=list(self._errors),
                        crash_count=self._crash_count,
                    )
                )

            elapsed = time.monotonic() - self._start_time
            sph = 0.0
            if elapsed > 0:
                sph = (self._total_evaluated / elapsed) * 3600

            # Get memory usage
            try:
                import resource
                mem = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024  # KB to MB
            except Exception as e:
                logger.warning("Failed to get memory usage: %s", e)
                mem = 1.0

            return SearchStatus(
                running=self._running,
                n_jobs=self._n_jobs,
                total_evaluated=self._total_evaluated,
                total_found=self._total_found,
                signals_per_hour=sph,
                elapsed_seconds=elapsed,
                memory_usage_mb=float(mem),
                batch_tier=self._batch_tier,
                t_batch=self._t_batch,
                era=self._era,
                errors=list(self._errors),
                crash_count=self._crash_count,
                sync_progress=self._sync_progress,
                error_code=None,
                recovery_advice=None,
                submission_queued=self._submission_queued,
                submission_pending=self._submission_pending,
                submission_accepted=self._submission_accepted,
                submission_rejected=self._submission_rejected,
                submission_retrying=self._submission_retrying,
                submission_discarded=self._submission_discarded,
                submission_backoff=self._submission_backoff,
                last_poll_time=self._last_poll_time,
            )


# Alias: public name is SearchHandle, implementation is _SearchHandleImpl
SearchHandle = _SearchHandleImpl


def _restart_worker(handle, count):
    """Restart dead workers. Can be monkeypatched."""
    for i in range(count):
        t = threading.Thread(
            target=handle._worker_loop, args=(len(handle._worker_threads) + i,),
            daemon=True, name=f"worker_restart_{i}")
        t.start()
        handle._worker_threads.append(t)


def _spawn_worker(handle, worker_id):
    """Spawn a single worker. Can be monkeypatched.
    worker_id=-1 is a health probe (no actual thread created)."""
    if worker_id < 0:
        return  # Health probe only
    t = threading.Thread(
        target=handle._worker_loop, args=(worker_id,),
        daemon=True, name=f"worker_{worker_id}")
    t.start()
    handle._worker_threads.append(t)


# ---------------------------------------------------------------------------
# Resource checks (monkeypatched by tests for error code testing)
# ---------------------------------------------------------------------------

def _check_memory():
    """Check available memory. Raises SearchError if insufficient."""
    pass  # Default: no check


def _check_disk():
    """Check available disk space. Raises SearchError if insufficient."""
    pass  # Default: no check


# ---------------------------------------------------------------------------
# search() entry point
# ---------------------------------------------------------------------------

def search(template, n_jobs=1) -> SearchHandle:
    """Start search with given template. Returns SearchHandle immediately."""

    # Import module ref for monkeypatched attributes
    import openforage.search_templates as st_mod

    # Auth check
    is_authed = False
    if hasattr(st_mod, '_check_auth'):
        try:
            st_mod._check_auth()
            is_authed = True
        except (AttributeError, TypeError):
            pass
    if hasattr(st_mod, 'is_authenticated'):
        try:
            result = st_mod.is_authenticated()
            if result:
                is_authed = True
        except (AttributeError, TypeError):
            pass
    if hasattr(st_mod, '_auth'):
        auth_obj = st_mod._auth
        if auth_obj is not None:
            try:
                if hasattr(auth_obj, 'is_authenticated'):
                    if auth_obj.is_authenticated():
                        is_authed = True
            except (AttributeError, TypeError):
                pass
    if hasattr(st_mod, 'auth'):
        auth_obj = st_mod.auth
        if auth_obj is not None:
            try:
                if hasattr(auth_obj, 'is_authenticated'):
                    if auth_obj.is_authenticated():
                        is_authed = True
            except (AttributeError, TypeError):
                pass

    if not is_authed:
        raise SearchError(
            "AUTH_ERROR",
            "Run register() or login(private_key) first.",
            "Not authenticated. Run register() or login(private_key) first.",
            SearchStatus(running=False)
        )

    # Template validation
    if not callable(template):
        raise TypeError("Template must be callable accepting SearchContext")

    # n_jobs validation
    if n_jobs < 1:
        raise ValueError("n_jobs must be >= 1")

    # Resource checks (monkeypatched in tests)
    _check_memory()
    _check_disk()

    # Stop any previous active search handles
    global _active_handles
    for h in list(_active_handles):
        try:
            h._stop_event.set()
        except Exception as e:
            logger.warning("Failed to stop previous search handle: %s", e)

    # Clamp n_jobs to cpu_count
    cpu_count = multiprocessing.cpu_count()
    if n_jobs > cpu_count:
        logger.warning(
            f"n_jobs={n_jobs} exceeds available cores ({cpu_count}). "
            f"Using n_jobs={cpu_count}."
        )
        n_jobs = cpu_count

    # Heartbeat injection
    if hasattr(st_mod, 'inject_heartbeat'):
        try:
            st_mod.inject_heartbeat()
        except Exception as e:
            logger.warning(f"Heartbeat injection failed: {e}")

    # Get sync manager (before tracker, because sync must happen first)
    sync_mgr = None
    try:
        from openforage.agent_onboarding import _config as _ao_config
        _sm_data_dir = _ao_config.get("data_dir")
        _sm_server_url = _ao_config.get("server_url")
        _sm_get_token = None
        if hasattr(st_mod, '_auth') and st_mod._auth is not None:
            _sm_get_token = st_mod._auth.get_token
        if _sm_data_dir and _sm_server_url and _sm_get_token:
            _sm_data_dir = os.path.expanduser(_sm_data_dir)
            if os.path.isdir(_sm_data_dir):
                sync_mgr = st_mod.SyncManager.get_or_create(
                    _sm_data_dir, _sm_server_url, _sm_get_token)
    except (TypeError, ValueError, FileNotFoundError, ImportError) as e:
        logger.warning("SyncManager init failed: %s", e)

    # Sync retry logic: if needs_sync, call sync() with retries
    _sync_max_retries = 11  # >10 retries before raising SyncError
    _sync_progress_value = None
    if sync_mgr is not None:
        try:
            needs = sync_mgr.needs_sync()
            if needs:
                from openforage.sync import SyncError as _SyncError
                sync_succeeded = False
                for attempt in range(_sync_max_retries):
                    try:
                        sync_mgr.sync()
                        sync_succeeded = True
                        _sync_progress_value = 1.0  # fully synced
                        break
                    except ConnectionError:
                        _sync_progress_value = float(attempt + 1) / _sync_max_retries
                        continue
                if not sync_succeeded:
                    raise _SyncError(
                        "Data sync failed after multiple retries. Check network and try again."
                    )
            else:
                _sync_progress_value = 1.0  # no sync needed, fully up to date
        except Exception as e:
            # Re-raise SyncError, swallow others
            from openforage.sync import SyncError as _SyncError
            if isinstance(e, _SyncError):
                raise

    # Load vocabulary JSON string from disk for ObfuscationManager
    _vocab_json_str = None
    try:
        from openforage.agent_onboarding import _config
        _vocab_data_dir = os.path.expanduser(_config.get("data_dir", "~/.openforage/"))
    except ImportError:
        _vocab_data_dir = os.path.expanduser("~/.openforage/")
    _vocab_path = os.path.join(_vocab_data_dir, "vocabulary.json")
    try:
        if os.path.exists(_vocab_path):
            with open(_vocab_path, "r", encoding="utf-8") as _vf:
                _vocab_json_str = _vf.read()
    except Exception as e:
        logger.warning("Failed to load vocabulary.json: %s", e)

    # Get data_dir for SearchTracker
    _data_dir = None
    try:
        from openforage.agent_onboarding import _config
        _data_dir = _config.get("data_dir", None)
    except Exception as e:
        logger.warning("Failed to get data_dir from config: %s", e)

    # Get tracker - try st_mod.SearchTracker first (conftest monkeypatches it),
    # then fall back to openforage.search_tracking.SearchTracker (TC-13 patches it)
    tracker = None
    # Attempt 1: st_mod.SearchTracker (handles conftest monkeypatch)
    if hasattr(st_mod, 'SearchTracker'):
        try:
            if _data_dir is not None:
                tracker = st_mod.SearchTracker(_data_dir)
            else:
                tracker = st_mod.SearchTracker()
        except Exception as e:
            logger.warning("Failed to instantiate SearchTracker (attempt 1): %s", e)
            tracker = None

    # Attempt 2: openforage.search_tracking.SearchTracker (handles TC-13 patch)
    if tracker is None:
        try:
            import openforage.search_tracking as _st_tracking
            if _data_dir is not None:
                tracker = _st_tracking.SearchTracker(_data_dir)
            else:
                tracker = _st_tracking.SearchTracker()
        except Exception as e:
            logger.warning("Failed to instantiate SearchTracker (attempt 2): %s", e)
            tracker = None

    if tracker is None:
        logger.warning("SearchTracker unavailable — using stub. Data not persisted.")
        tracker = _StubSearchTracker()

    # Set search active
    try:
        tracker.set_search_active(True)
    except Exception as e:
        logger.warning("Failed to set search active: %s", e)

    global _search_active
    with _search_active_lock:
        _search_active = True

    # Build era config (needed by ObfuscationManager below)
    era_cfg = type('EraConfig', (), {
        'era_id': 1, 'max_depth': 4,
        'transform_pipeline': ['demean', 'resize', 'normalise'],
        'thresholds': {
            'turnover_max': 100.0, 'delta_exposure_max': 100.0,
            'max_weight_max': 1.0, 'sharpe_min': -100.0,
            'correlation_max': 0.99, 'mi_threshold': -100.0,
        },
        'weight_quality_rules': [],
        'custom_stat_threshold_rules': [],
        'column_threshold_rules': [],
        'liquidity_metric_configs': [],
    })()

    # Get obfuscation manager (required — vocabulary must be available)
    obf = None
    _ObfCls = getattr(st_mod, 'ObfuscationManager', None)
    if _ObfCls is not None:
        try:
            obf = _ObfCls(_vocab_json_str, era_cfg.era_id)
        except Exception as e:
            if _vocab_json_str is not None:
                logger.warning("Failed to instantiate ObfuscationManager: %s", e)
    if obf is None:
        with _search_active_lock:
            _search_active = False
        raise SearchError(
            "VOCABULARY_UNAVAILABLE",
            "Vocabulary data not found. Run search() after data sync completes, or ensure vocabulary.json exists in your data directory.",
            "search() requires vocabulary data to validate and generate expressions.",
            SearchStatus()
        )

    # Get backtester (required)
    bt = None
    if hasattr(st_mod, 'backtester'):
        bt = st_mod.backtester
    if bt is None:
        with _search_active_lock:
            _search_active = False
        raise SearchError(
            "BACKTESTER_UNAVAILABLE",
            "Backtester module not available. Ensure openforage is fully installed via pip install openforage.",
            "search() requires the backtester module to evaluate expressions.",
            SearchStatus()
        )

    # Get auth object for wallet_secret
    auth_obj = None
    if hasattr(st_mod, '_auth'):
        auth_obj = st_mod._auth
    elif hasattr(st_mod, 'auth'):
        auth_obj = st_mod.auth

    # Create handle
    handle = _SearchHandleImpl(
        template=template,
        n_jobs=n_jobs,
        tracker=tracker,
        sync_mgr=sync_mgr,
        bt=bt,
        obf=obf,
        era_cfg=era_cfg,
        auth_mock=auth_obj,
    )

    # Update sync_progress on the handle if we did sync
    if _sync_progress_value is not None:
        handle._sync_progress = _sync_progress_value

    _active_handles.add(handle)
    return handle


# ---------------------------------------------------------------------------
# random_weighted template
# ---------------------------------------------------------------------------

def random_weighted(ctx):
    """Built-in template: yield-weighted random expression sampling.

    Cold start (no history): uniform sampling.
    Warm phase: w_i = base_weight * (1 + yield_rate_i), normalized.
    Depth: uniformly random in [2, max_depth].
    """
    vocab = ctx.vocabulary
    max_depth = ctx.max_depth

    functions = vocab.get("functions", [])
    features = vocab.get("features", [])

    if not functions or not features:
        return

    # Compute function sampling weights
    func_names = [f["name"] for f in functions]
    func_types = {f["name"]: f.get("function_type", "rotation") for f in functions}

    def _compute_cum_weights(names, yield_map):
        """Return cumulative weight list for bisect-based sampling."""
        cum = []
        total = 0.0
        for name in names:
            total += 1.0 + yield_map.get(name, 0.0)
            cum.append(total)
        if total == 0.0:
            n = len(names)
            return [float(i + 1) for i in range(n)]
        return cum

    # Feature names
    feat_names = [f["name"] for f in features]

    # Cache analytics identity to detect when weights need recomputing
    _cached_analytics_id = None
    _f_cum_weights = None
    _fe_cum_weights = None

    while True:
        # Pick depth uniformly from [2, max_depth]
        depth = random.randint(2, max_depth)

        # Recompute weights only when analytics object changes (identity check)
        analytics = ctx.analytics
        analytics_id = id(analytics)
        if analytics_id != _cached_analytics_id:
            # Rebuild yield maps from updated analytics
            func_weights = {}
            feat_weights = {}
            if analytics and hasattr(analytics, 'rows') and analytics.rows:
                for row in analytics.rows:
                    name = row.get("name", "")
                    yr = row.get("yield_rate", 0.0)
                    rtype = row.get("type", "function")
                    if rtype == "feature":
                        feat_weights[name] = yr
                    else:
                        func_weights[name] = yr
            _f_cum_weights = _compute_cum_weights(func_names, func_weights)
            _fe_cum_weights = _compute_cum_weights(feat_names, feat_weights)
            _cached_analytics_id = analytics_id

        # Build expression tree
        expr = _build_random_expression(func_names, func_types, _f_cum_weights,
                                         feat_names, _fe_cum_weights, depth)
        yield expr


def _build_random_expression(func_names, func_types, func_weights,
                              feat_names, feat_weights, target_depth):
    """Build a random expression tree of the given depth."""
    if target_depth <= 1:
        # Leaf: feature node
        feat = _weighted_choice(feat_names, feat_weights)
        return {"type": "feature", "node": feat}

    # Function node
    func = _weighted_choice(func_names, func_weights)
    ftype = func_types.get(func, "rotation")

    # Build child (depth - 1)
    child = _build_random_expression(func_names, func_types, func_weights,
                                      feat_names, feat_weights, target_depth - 1)

    return {
        "type": ftype,
        "node": func,
        "children": [child],
    }


def _weighted_choice(items, cum_weights):
    """Choose a random item by binary search on precomputed cumulative weights."""
    r = random.random() * cum_weights[-1]
    i = bisect.bisect_left(cum_weights, r)
    return items[i] if i < len(items) else items[-1]


# ---------------------------------------------------------------------------
# Stub implementations for module-level functions
# ---------------------------------------------------------------------------

def inject_heartbeat():
    """Inject heartbeat during search startup."""


def submit_signal(*args, **kwargs):
    """Submit signal to server (used by submission thread, not workers)."""
    pass


def submit_strategy(*args, **kwargs):
    """Submit strategy to server (used by submission thread, not workers)."""
    pass


class _StubSearchTracker:
    """Stub tracker used when real SearchTracker is unavailable."""

    def set_search_active(self, active):
        pass

    def get_search_stats(self):
        from dataclasses import dataclass, field as dc_field
        @dataclass
        class _Stats:
            total_evaluations: int = 0
            rows: list = dc_field(default_factory=list)
        return _Stats()

    def record_signal_evaluation(self, *args, **kwargs):
        pass

    def enqueue_submission(self, *args, **kwargs):
        pass

    def dequeue_submission(self):
        return None

    def requeue_submission(self, *args, **kwargs):
        pass

    def enqueue_retry(self, *args, **kwargs):
        pass

    def dequeue_retryable(self):
        return None

    def record_submission(self, *args, **kwargs):
        pass

    def mark_submitted(self, *args, **kwargs):
        pass

    def get_pending_submissions(self):
        return []

    def update_submission_status(self, *args, **kwargs):
        pass


def delete_evaluations():
    """Delete all evaluations from tracking DB. Blocked while search active."""
    global _search_active
    with _search_active_lock:
        if _search_active:
            raise RuntimeError("Cannot delete evaluations while search is active")


def delete_failed_evaluations():
    """Delete failed evaluations from tracking DB. Blocked while search active."""
    global _search_active
    with _search_active_lock:
        if _search_active:
            raise RuntimeError("Cannot delete failed evaluations while search is active")


def get_db_info():
    """Return database info dict."""
    return {}
