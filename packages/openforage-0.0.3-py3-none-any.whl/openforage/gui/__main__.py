"""Entry point for ``python -m openforage.gui``."""

import argparse
import uvicorn


def main():
    parser = argparse.ArgumentParser(description="OpenForage Simulator GUI")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address")
    parser.add_argument("--port", type=int, default=8000, help="Port number")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    args = parser.parse_args()

    uvicorn.run(
        "openforage.gui.server:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
