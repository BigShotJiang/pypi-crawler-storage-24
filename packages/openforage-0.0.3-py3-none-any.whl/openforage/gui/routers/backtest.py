"""Backtest router — submit, monitor, and retrieve simulation results."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from openforage.gui.runtime import GuiRuntime

router = APIRouter(prefix="/backtest", tags=["backtest"])


class BacktestRunRequest(BaseModel):
    graph_dict: dict[str, Any]
    era_id: str
    expression_type: str = "signal"
    universe_id: Optional[str] = None


class BacktestJobResponse(BaseModel):
    id: str
    status: str
    progress: float = 0.0
    error: Optional[str] = None
    created_at: str
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


class BacktestResultResponse(BaseModel):
    id: str
    job_id: str
    statistics: dict[str, Any]
    per_column_stats: Optional[dict[str, Any]] = None
    threshold_results: Optional[dict[str, Any]] = None
    correlation_score: Optional[float] = None
    pnl_matrix: Optional[dict[str, Any]] = None
    created_at: str


def _ts_to_iso(ts: Optional[float]) -> Optional[str]:
    if ts is None:
        return None
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


@router.post("/run", response_model=BacktestJobResponse)
async def run_backtest(body: BacktestRunRequest, request: Request) -> BacktestJobResponse:
    """Submit an expression for backtesting."""
    runtime: GuiRuntime = request.app.state.runtime

    job_id = await asyncio.to_thread(
        runtime.submit_simulation,
        body.graph_dict,
        body.expression_type,
        body.universe_id,
    )

    status = await asyncio.to_thread(runtime.get_job_status, job_id)
    if status is None:
        raise HTTPException(status_code=500, detail="Failed to create job")

    return BacktestJobResponse(
        id=status["id"],
        status=status["status"],
        progress=status["progress"],
        error=status.get("error"),
        created_at=_ts_to_iso(status["created_at"]) or "",
        started_at=_ts_to_iso(status.get("started_at")),
        completed_at=_ts_to_iso(status.get("completed_at")),
    )


@router.get("/{job_id}/status", response_model=BacktestJobResponse)
async def get_job_status(job_id: str, request: Request) -> BacktestJobResponse:
    """Return current status of a backtest job."""
    runtime: GuiRuntime = request.app.state.runtime
    status = await asyncio.to_thread(runtime.get_job_status, job_id)
    if status is None:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

    return BacktestJobResponse(
        id=status["id"],
        status=status["status"],
        progress=status["progress"],
        error=status.get("error"),
        created_at=_ts_to_iso(status["created_at"]) or "",
        started_at=_ts_to_iso(status.get("started_at")),
        completed_at=_ts_to_iso(status.get("completed_at")),
    )


@router.get("/{job_id}/result", response_model=BacktestResultResponse)
async def get_job_result(job_id: str, request: Request) -> BacktestResultResponse:
    """Return results of a completed backtest."""
    runtime: GuiRuntime = request.app.state.runtime

    # Check job exists and is completed
    status = await asyncio.to_thread(runtime.get_job_status, job_id)
    if status is None:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    if status["status"] not in ("completed",):
        raise HTTPException(
            status_code=404,
            detail=f"Results not available (status: {status['status']})",
        )

    result = await asyncio.to_thread(runtime.get_job_result, job_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Result not found")

    return BacktestResultResponse(
        id=job_id,
        job_id=job_id,
        statistics=result.get("statistics", {}),
        per_column_stats=result.get("per_column_stats"),
        threshold_results=result.get("threshold_results"),
        correlation_score=result.get("statistics", {}).get("correlation"),
        pnl_matrix=result.get("pnl_matrix"),
        created_at=_ts_to_iso(status.get("completed_at")) or "",
    )


@router.delete("/{job_id}")
async def cancel_job(job_id: str, request: Request) -> dict[str, str]:
    """Cancel a running backtest."""
    runtime: GuiRuntime = request.app.state.runtime
    cancelled = await asyncio.to_thread(runtime.cancel_job, job_id)
    if not cancelled:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    return {"status": "cancelled", "job_id": job_id}
