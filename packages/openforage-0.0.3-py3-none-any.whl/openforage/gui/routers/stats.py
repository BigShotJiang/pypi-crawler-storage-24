"""Stats router — basic search statistics."""

from __future__ import annotations

import asyncio
from typing import Any

from fastapi import APIRouter, Request

from openforage.gui.runtime import GuiRuntime

router = APIRouter(prefix="/stats", tags=["stats"])


@router.get("")
async def get_stats(request: Request) -> dict[str, Any]:
    """Return basic search statistics."""
    runtime: GuiRuntime = request.app.state.runtime
    return await asyncio.to_thread(runtime.get_basic_stats)
