"""History router — evaluation history from openforage tracker or gui.db fallback."""

from __future__ import annotations

import asyncio
from typing import Any

from fastapi import APIRouter, Request

from openforage.gui.runtime import GuiRuntime

router = APIRouter(prefix="/history", tags=["history"])


@router.get("")
async def get_history(
    request: Request,
    eval_type: str = "signal",
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Return recent evaluation history."""
    runtime: GuiRuntime = request.app.state.runtime
    return await asyncio.to_thread(runtime.get_evaluation_history, eval_type, limit)
