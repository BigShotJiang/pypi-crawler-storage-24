"""Expressions router — CRUD for saved expressions."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from openforage.gui.runtime import GuiRuntime

router = APIRouter(prefix="/expressions", tags=["expressions"])


class ExpressionCreate(BaseModel):
    canonical_string: str
    graph_dict: dict[str, Any]
    expression_type: str = "signal"
    name: Optional[str] = None
    tags: Optional[list[str]] = None
    era_id: Optional[str] = None
    era_config: Optional[dict[str, Any]] = None


class ExpressionResponse(BaseModel):
    id: str
    canonical_string: str
    graph_dict: dict[str, Any]
    expression_type: str
    name: Optional[str] = None
    tags: Optional[list[str]] = None
    era_id: Optional[str] = None
    era_config: Optional[dict[str, Any]] = None
    created_at: str


def _ts_to_iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


@router.post("", response_model=ExpressionResponse)
async def create_expression(body: ExpressionCreate, request: Request) -> ExpressionResponse:
    """Save a new expression."""
    runtime: GuiRuntime = request.app.state.runtime

    expr_id = await asyncio.to_thread(
        runtime.save_expression,
        body.canonical_string,
        body.graph_dict,
        body.expression_type,
        body.name,
        body.tags,
        body.era_id,
        body.era_config,
    )

    expr = await asyncio.to_thread(runtime.get_expression, expr_id)
    if expr is None:
        raise HTTPException(status_code=500, detail="Failed to save expression")

    return ExpressionResponse(
        id=expr["id"],
        canonical_string=expr["canonical_string"],
        graph_dict=expr["graph_dict"],
        expression_type=expr["expression_type"],
        name=expr.get("name"),
        tags=expr.get("tags"),
        era_id=expr.get("era_id"),
        era_config=expr.get("era_config"),
        created_at=_ts_to_iso(expr["created_at"]),
    )


@router.get("", response_model=list[ExpressionResponse])
async def list_expressions(request: Request, limit: int = 100, offset: int = 0) -> list[ExpressionResponse]:
    """List all saved expressions."""
    runtime: GuiRuntime = request.app.state.runtime
    exprs = await asyncio.to_thread(runtime.list_expressions, limit, offset)
    return [
        ExpressionResponse(
            id=e["id"],
            canonical_string=e["canonical_string"],
            graph_dict=e["graph_dict"],
            expression_type=e["expression_type"],
            name=e.get("name"),
            tags=e.get("tags"),
            era_id=e.get("era_id"),
            era_config=e.get("era_config"),
            created_at=_ts_to_iso(e["created_at"]),
        )
        for e in exprs
    ]


@router.get("/{expression_id}", response_model=ExpressionResponse)
async def get_expression(expression_id: str, request: Request) -> ExpressionResponse:
    """Get a single expression by ID."""
    runtime: GuiRuntime = request.app.state.runtime
    expr = await asyncio.to_thread(runtime.get_expression, expression_id)
    if expr is None:
        raise HTTPException(status_code=404, detail="Expression not found")

    return ExpressionResponse(
        id=expr["id"],
        canonical_string=expr["canonical_string"],
        graph_dict=expr["graph_dict"],
        expression_type=expr["expression_type"],
        name=expr.get("name"),
        tags=expr.get("tags"),
        era_id=expr.get("era_id"),
        era_config=expr.get("era_config"),
        created_at=_ts_to_iso(expr["created_at"]),
    )


@router.delete("/{expression_id}")
async def delete_expression(expression_id: str, request: Request) -> dict[str, str]:
    """Delete a saved expression."""
    runtime: GuiRuntime = request.app.state.runtime
    deleted = await asyncio.to_thread(runtime.delete_expression, expression_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Expression not found")
    return {"status": "deleted", "id": expression_id}
