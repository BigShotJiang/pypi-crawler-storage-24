"""Graph router — validate, parse, and canonicalize expression graphs."""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter
from pydantic import BaseModel

from openforage.gui.services.parser import ParseError, parse_expression
from openforage.gui.services.canonical import canonical_graph_string

router = APIRouter(prefix="/graph", tags=["graph"])


class GraphValidateRequest(BaseModel):
    graph_dict: dict[str, Any]
    expression_type: str = "signal"


class GraphValidateResponse(BaseModel):
    valid: bool
    error: Optional[str] = None


class GraphParseRequest(BaseModel):
    text: str


class GraphParseResponse(BaseModel):
    graph_dict: Optional[dict[str, Any]] = None
    error: Optional[str] = None


class GraphCanonicalRequest(BaseModel):
    graph_dict: dict[str, Any]


class GraphCanonicalResponse(BaseModel):
    canonical_string: str


@router.post("/validate", response_model=GraphValidateResponse)
async def validate_graph(body: GraphValidateRequest) -> GraphValidateResponse:
    """Validate a graph dict structure."""
    try:
        _validate_node(body.graph_dict)
        return GraphValidateResponse(valid=True)
    except ValueError as e:
        return GraphValidateResponse(valid=False, error=str(e))


@router.post("/parse", response_model=GraphParseResponse)
async def parse_text(body: GraphParseRequest) -> GraphParseResponse:
    """Parse expression text into a graph dict."""
    try:
        graph = parse_expression(body.text)
        return GraphParseResponse(graph_dict=graph)
    except ParseError as e:
        return GraphParseResponse(error=e.message)
    except Exception as e:
        return GraphParseResponse(error=str(e))


@router.post("/canonical", response_model=GraphCanonicalResponse)
async def to_canonical(body: GraphCanonicalRequest) -> GraphCanonicalResponse:
    """Convert a graph dict to its canonical string form."""
    canonical = canonical_graph_string(body.graph_dict)
    return GraphCanonicalResponse(canonical_string=canonical)


_VALID_TYPES = frozenset({
    "rotation", "filtration", "reduction", "feature",
    "aggregation", "float", "int", "string", "bool", "function",
})

_LEAF_TYPES = frozenset({"feature", "aggregation", "float", "int", "string", "bool"})


def _validate_node(node: Any, depth: int = 0) -> None:
    """Recursively validate a graph node."""
    if depth > 50:
        raise ValueError("Graph too deep (max 50 levels)")
    if not isinstance(node, dict):
        raise ValueError(f"Node must be a dict, got {type(node).__name__}")
    if "type" not in node:
        raise ValueError("Node missing 'type' field")
    if "node" not in node:
        raise ValueError("Node missing 'node' field")

    node_type = node["type"]
    if node_type not in _VALID_TYPES:
        raise ValueError(f"Invalid node type '{node_type}'")

    if node_type not in _LEAF_TYPES:
        children = node.get("children", [])
        if not isinstance(children, list):
            raise ValueError("'children' must be a list")
        for child in children:
            _validate_node(child, depth + 1)
