"""Era router — current era config, features, and functions."""

from __future__ import annotations

import asyncio
from typing import Any

from fastapi import APIRouter, Request

from openforage.gui.runtime import GuiRuntime

router = APIRouter(prefix="/era", tags=["era"])


@router.get("/current")
async def get_current_era(request: Request) -> dict[str, Any]:
    """Return current era configuration."""
    runtime: GuiRuntime = request.app.state.runtime
    return await asyncio.to_thread(runtime.get_era_config)


@router.get("/features")
async def get_features(request: Request) -> dict[str, list[str]]:
    """Return available features for the current era."""
    runtime: GuiRuntime = request.app.state.runtime
    features = await asyncio.to_thread(runtime.get_features)
    return {"features": features}


@router.get("/functions")
async def get_functions(request: Request) -> dict[str, list[dict[str, Any]]]:
    """Return available functions (rotations, filtrations, reductions)."""
    runtime: GuiRuntime = request.app.state.runtime
    functions = await asyncio.to_thread(runtime.get_functions)
    return {"functions": functions}
