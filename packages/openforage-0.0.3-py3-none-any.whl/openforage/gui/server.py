"""FastAPI application for the OpenForage Simulator GUI."""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from openforage.gui.runtime import GuiRuntime
from openforage.gui.routers import backtest, era, expressions, graph, history, stats

logger = logging.getLogger("openforage.gui")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Initialize GuiRuntime on startup, clean up on shutdown."""
    runtime = GuiRuntime()

    # Try to initialize openforage (non-blocking, best-effort)
    initialized = await asyncio.to_thread(runtime.initialize)
    if initialized:
        logger.info("OpenForage integration active — real data available")
    else:
        logger.warning(
            "OpenForage not initialized (%s) — running with mock data",
            runtime.initialization_error or "unknown reason",
        )

    app.state.runtime = runtime
    app.state.ws_connections: dict[str, list[WebSocket]] = {}

    yield

    runtime.close()
    logger.info("GuiRuntime closed")


app = FastAPI(
    title="OpenForage Simulator GUI",
    description="Local web interface for expression development and backtesting",
    version="0.1.0",
    lifespan=lifespan,
)

# CORS — allow the Next.js dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount routers
app.include_router(backtest.router, prefix="/api")
app.include_router(expressions.router, prefix="/api")
app.include_router(era.router, prefix="/api")
app.include_router(graph.router, prefix="/api")
app.include_router(history.router, prefix="/api")
app.include_router(stats.router, prefix="/api")


@app.get("/api/health")
async def health() -> dict[str, str]:
    """Health check endpoint."""
    runtime: GuiRuntime = app.state.runtime
    return {
        "status": "ok",
        "openforage_initialized": str(runtime.is_initialized),
    }


@app.websocket("/ws/backtest/{job_id}")
async def websocket_backtest(websocket: WebSocket, job_id: str) -> None:
    """Stream backtest progress updates via WebSocket."""
    await websocket.accept()

    if job_id not in app.state.ws_connections:
        app.state.ws_connections[job_id] = []
    app.state.ws_connections[job_id].append(websocket)

    runtime: GuiRuntime = app.state.runtime

    try:
        # Send current status immediately
        status = await asyncio.to_thread(runtime.get_job_status, job_id)
        if status:
            await websocket.send_json({
                "job_id": job_id,
                "status": status["status"],
                "progress": status["progress"],
                "error": status.get("error"),
            })

        # Poll and push updates until job completes
        while True:
            await asyncio.sleep(0.3)
            status = await asyncio.to_thread(runtime.get_job_status, job_id)
            if status is None:
                break

            await websocket.send_json({
                "job_id": job_id,
                "status": status["status"],
                "progress": status["progress"],
                "error": status.get("error"),
            })

            if status["status"] in ("completed", "error", "cancelled"):
                break

    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        if job_id in app.state.ws_connections:
            try:
                app.state.ws_connections[job_id].remove(websocket)
            except ValueError:
                pass
            if not app.state.ws_connections[job_id]:
                del app.state.ws_connections[job_id]
