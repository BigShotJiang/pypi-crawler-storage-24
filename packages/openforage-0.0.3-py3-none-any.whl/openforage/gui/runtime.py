"""GuiRuntime — synchronous facade over openforage Cython modules for the GUI server.

Owns initialization, thread safety, job registry, result persistence,
and expression storage. FastAPI routes call methods via asyncio.to_thread().
"""

import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from dataclasses import asdict, dataclass
from typing import Any, Optional

logger = logging.getLogger("openforage.gui.runtime")


def _derive_passed(threshold_results: Any) -> bool:
    """Derive overall pass/fail from structured threshold results.

    Handles both formats:
    - Flat: {"passed": bool}
    - Structured: {"sharpe": {"value": ..., "threshold": ..., "passed": bool}, ...}
    """
    if not threshold_results or not isinstance(threshold_results, dict):
        return False
    # Flat format with top-level "passed" key
    if "passed" in threshold_results and isinstance(threshold_results["passed"], bool):
        return threshold_results["passed"]
    # Structured format: all entries must pass
    for key, entry in threshold_results.items():
        if isinstance(entry, dict) and "passed" in entry:
            if not entry["passed"]:
                return False
    return True


@dataclass
class JobInfo:
    """In-memory representation of a simulation job."""
    job_id: str
    status: str  # pending | running | syncing | evaluating | backtesting | complete | error | cancelled
    progress: float = 0.0
    message: str = ""
    error: Optional[str] = None
    era_id: int = 0
    created_at: float = 0.0
    started_at: Optional[float] = None
    completed_at: Optional[float] = None


class GuiRuntime:
    """Synchronous facade over openforage Cython modules.

    All public methods are safe to call from any thread — internal locking
    serializes access to Cython modules and SQLite.
    """

    def __init__(self, data_dir: Optional[str] = None):
        self._lock = threading.Lock()
        self._data_dir = data_dir or os.path.expanduser("~/.openforage")
        self._initialized = False
        self._init_error: Optional[str] = None

        # Job registry: job_id -> (JobInfo, SimulationHandle or None)
        self._jobs: dict[str, tuple[JobInfo, Any]] = {}

        # GUI-specific SQLite for saved expressions + result payloads
        self._gui_db_path = os.path.join(self._data_dir, "gui.db")
        self._gui_conn: Optional[sqlite3.Connection] = None

        self._init_gui_db()

    def _init_gui_db(self):
        """Initialize the GUI-specific SQLite database."""
        os.makedirs(self._data_dir, exist_ok=True)
        self._gui_conn = sqlite3.connect(self._gui_db_path, check_same_thread=False)
        self._gui_conn.execute("PRAGMA journal_mode=WAL")
        self._gui_conn.execute("PRAGMA foreign_keys=ON")

        self._gui_conn.executescript("""
            CREATE TABLE IF NOT EXISTS saved_expressions (
                id TEXT PRIMARY KEY,
                canonical_string TEXT NOT NULL,
                graph_dict TEXT NOT NULL,
                expression_type TEXT NOT NULL DEFAULT 'signal',
                name TEXT,
                tags TEXT,
                era_id TEXT,
                era_config TEXT,
                created_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS gui_results (
                job_id TEXT PRIMARY KEY,
                graph_dict TEXT NOT NULL,
                expression_type TEXT NOT NULL DEFAULT 'signal',
                result_json TEXT NOT NULL,
                created_at REAL NOT NULL
            );
        """)
        self._gui_conn.commit()

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    def initialize(self, private_key: Optional[str] = None) -> bool:
        """Initialize openforage modules (auth, sync, vocabulary).

        This is a best-effort operation — if the openforage server is
        unreachable or no wallet exists, the GUI operates in degraded
        mode with mock/empty data.

        TODO: Full initialization requires injecting all simulate_signal.pyx
        collaborators (_vault, _backtester, _graph_validator, _search_tracker,
        _load_vocabulary, _era_thread, _compute_search_plan, _BatchOrchestrator,
        _compute_mi, etc.). Currently register()/login() only propagates auth
        into search_templates, not the simulation pipeline. When the full
        openforage library is compiled with all dependencies, this method
        should explicitly wire each collaborator.

        Returns True if initialization succeeded, False otherwise.
        """
        with self._lock:
            if self._initialized:
                return True

            try:
                import openforage.simulate_signal as sim_mod
                import openforage.agent_onboarding as onboard_mod

                # Try to register or login
                if private_key:
                    onboard_mod.login(private_key)
                else:
                    onboard_mod.register()

                # At this point, _auth_manager is set and propagated
                # Check if simulate_signal has its dependencies
                if sim_mod._auth is not None and sim_mod._sync_manager is not None:
                    self._initialized = True
                    logger.info("GuiRuntime initialized with full openforage integration")
                    return True
                else:
                    # Auth succeeded but simulation modules not fully wired
                    self._initialized = False
                    self._init_error = "Simulation pipeline dependencies not fully initialized"
                    logger.warning("GuiRuntime: auth OK but simulation pipeline incomplete")
                    return False

            except Exception as e:
                self._init_error = str(e)
                logger.warning("GuiRuntime initialization failed: %s", e)
                return False

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    @property
    def initialization_error(self) -> Optional[str]:
        return self._init_error

    # ------------------------------------------------------------------
    # Era / Vocabulary
    # ------------------------------------------------------------------

    def get_era_config(self) -> dict[str, Any]:
        """Return current era configuration."""
        with self._lock:
            if not self._initialized:
                return self._mock_era_config()

            import openforage.simulate_signal as sim_mod
            cfg = sim_mod._era_config
            if cfg and isinstance(cfg, dict):
                return dict(cfg)
            return self._mock_era_config()

    def get_features(self) -> list[str]:
        """Return available feature names from vocabulary."""
        with self._lock:
            if not self._initialized:
                return self._mock_features()

            import openforage.simulate_signal as sim_mod
            vocab = sim_mod._vocabulary
            if vocab and isinstance(vocab, dict):
                features = vocab.get("features", {})
                if isinstance(features, dict):
                    return list(features.keys())
                if isinstance(features, list):
                    return list(features)
            return self._mock_features()

    def get_functions(self) -> list[dict[str, Any]]:
        """Return available functions (rotations, filtrations, reductions)."""
        with self._lock:
            if not self._initialized:
                return self._mock_functions()

            import openforage.simulate_signal as sim_mod
            vocab = sim_mod._vocabulary
            if vocab and isinstance(vocab, dict):
                functions = []
                for category in ("rotations", "filtrations", "reductions"):
                    items = vocab.get(category, {})
                    if isinstance(items, dict):
                        for name, meta in items.items():
                            functions.append({
                                "name": name,
                                "category": category.rstrip("s"),  # rotation, filtration, reduction
                                "params": meta if isinstance(meta, dict) else {},
                            })
                    elif isinstance(items, list):
                        for name in items:
                            functions.append({
                                "name": name,
                                "category": category.rstrip("s"),
                                "params": {},
                            })
                return functions
            return self._mock_functions()

    # ------------------------------------------------------------------
    # Simulation
    # ------------------------------------------------------------------

    def submit_simulation(self, graph_dict: dict[str, Any],
                          expression_type: str = "signal",
                          universe_id: Optional[str] = None) -> str:
        """Submit an expression for simulation. Returns job_id."""
        job_id = str(uuid.uuid4())
        now = time.time()

        job_info = JobInfo(
            job_id=job_id,
            status="pending",
            created_at=now,
        )

        with self._lock:
            if not self._initialized:
                # Run mock simulation
                self._jobs[job_id] = (job_info, None)
                thread = threading.Thread(
                    target=self._run_mock_simulation,
                    args=(job_id, graph_dict),
                    daemon=True,
                )
                thread.start()
                return job_id

            # Real simulation via openforage
            import openforage.simulate_signal as sim_mod

            # Determine universe_id
            if universe_id is None:
                era_cfg = sim_mod._era_config
                if era_cfg and isinstance(era_cfg, dict):
                    universes = era_cfg.get("universes", {})
                    if universes:
                        universe_id = next(iter(universes))
                if universe_id is None:
                    universe_id = "universe_top50"

            # Determine expression type and call appropriate function
            try:
                if expression_type.upper() == "STRATEGY":
                    handle = sim_mod.simulate_strategy(
                        graph=graph_dict,
                        universe_id=universe_id,
                        return_series=True,
                    )
                else:
                    handle = sim_mod.simulate_signal(
                        graph=graph_dict,
                        universe_id=universe_id,
                        return_series=True,
                    )

                job_info.status = "running"
                job_info.started_at = time.time()
                self._jobs[job_id] = (job_info, handle)

                # Start a monitoring thread
                thread = threading.Thread(
                    target=self._monitor_simulation,
                    args=(job_id,),
                    daemon=True,
                )
                thread.start()

            except Exception as e:
                job_info.status = "error"
                job_info.error = str(e)
                self._jobs[job_id] = (job_info, None)

            return job_id

    def _monitor_simulation(self, job_id: str):
        """Monitor a running SimulationHandle and update job status."""
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is None:
                return
            job_info, handle = entry

        if handle is None:
            return

        # Poll status until done
        while True:
            status = handle.status()
            with self._lock:
                entry = self._jobs.get(job_id)
                if entry is None:
                    return
                job_info = entry[0]
                job_info.status = status.phase
                job_info.progress = status.progress
                job_info.message = status.message
                job_info.era_id = status.era_id

            if status.phase in ("complete", "error", "cancelled"):
                break
            time.sleep(0.3)

        # Try to get result
        try:
            result = handle.result()
            with self._lock:
                entry = self._jobs.get(job_id)
                if entry is None:
                    return
                job_info = entry[0]
                job_info.status = "completed"
                job_info.progress = 1.0
                job_info.completed_at = time.time()

            # Persist full result to gui.db
            self._persist_result(job_id, result, graph_dict=None, expression_type="signal")

        except Exception as e:
            with self._lock:
                entry = self._jobs.get(job_id)
                if entry is None:
                    return
                job_info = entry[0]
                job_info.status = "error"
                job_info.error = str(e)
                job_info.completed_at = time.time()

    def _run_mock_simulation(self, job_id: str, graph_dict: dict):
        """Run a mock simulation when openforage is not initialized."""
        import random

        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is None:
                return
            job_info = entry[0]
            job_info.status = "running"
            job_info.started_at = time.time()

        # Simulate phases
        phases = [
            ("syncing", 0.1, "Syncing data..."),
            ("evaluating", 0.4, "Evaluating expression..."),
            ("backtesting", 0.7, "Running backtest..."),
            ("computing_mi", 0.9, "Computing MI score..."),
        ]

        for phase, progress, message in phases:
            time.sleep(0.5)
            with self._lock:
                entry = self._jobs.get(job_id)
                if entry is None:
                    return
                job_info = entry[0]
                if job_info.status == "cancelled":
                    return
                job_info.status = phase
                job_info.progress = progress
                job_info.message = message

        # Generate mock results
        sharpe = random.gauss(0.5, 0.3)
        turnover_val = round(random.uniform(0.5, 2.0), 4)
        drawdown_val = round(random.uniform(0.05, 0.3), 4)
        correlation_val = round(random.uniform(-0.3, 0.3), 4)

        mock_result = {
            "statistics": {
                "sharpe": round(sharpe, 4),
                "returns": round(random.gauss(0.1, 0.05), 4),
                "turnover": turnover_val,
                "drawdown": drawdown_val,
                "delta_exposure": round(random.uniform(0.0, 0.5), 4),
                "max_weight": round(random.uniform(0.02, 0.2), 4),
                "quality_score": round(random.uniform(0.0, 1.0), 4),
                "correlation": correlation_val,
            },
            "per_column_stats": None,
            "threshold_results": {
                "sharpe": {"value": round(sharpe, 4), "threshold": 0.3, "passed": sharpe > 0.3},
                "turnover": {"value": turnover_val, "threshold": 1.5, "passed": turnover_val < 1.5},
                "drawdown": {"value": drawdown_val, "threshold": 0.25, "passed": drawdown_val < 0.25},
                "correlation": {"value": correlation_val, "threshold": 0.4, "passed": abs(correlation_val) < 0.4},
            },
            "pnl_matrix": self._generate_mock_pnl(),
        }

        # Persist
        self._persist_result(job_id, mock_result, graph_dict, "signal")

        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is None:
                return
            job_info = entry[0]
            job_info.status = "completed"
            job_info.progress = 1.0
            job_info.completed_at = time.time()

    def _generate_mock_pnl(self) -> dict:
        """Generate mock PnL data for the chart."""
        import random
        from datetime import datetime, timedelta

        base = datetime(2025, 1, 1)
        dates = []
        cumulative_pnl = []
        pnl = 0.0
        for i in range(252):
            dates.append((base + timedelta(days=i)).strftime("%Y-%m-%d"))
            pnl += random.gauss(100, 500)
            cumulative_pnl.append(round(pnl, 2))

        return {"dates": dates, "cumulative_pnl": cumulative_pnl}

    def _persist_result(self, job_id: str, result: Any, graph_dict: Any,
                        expression_type: str):
        """Persist full result payload to gui.db."""
        if self._gui_conn is None:
            return

        # Convert result to JSON-serializable dict
        if isinstance(result, dict):
            result_dict = result
        elif hasattr(result, '__dict__'):
            # BacktestResult from openforage — extract relevant fields
            result_dict = {
                "statistics": {},
                "per_column_stats": None,
                "threshold_results": None,
                "pnl_matrix": None,
            }
            if hasattr(result, 'stats') and result.stats is not None:
                stats = result.stats
                result_dict["statistics"] = {
                    "sharpe": getattr(stats, 'sharpe', 0),
                    "returns": getattr(stats, 'returns', 0),
                    "turnover": getattr(stats, 'turnover', 0),
                    "drawdown": getattr(stats, 'drawdown', 0),
                    "delta_exposure": getattr(stats, 'delta_exposure', 0),
                    "max_weight": getattr(stats, 'max_weight', 0),
                    "quality_score": getattr(stats, 'quality_score', 0),
                    "correlation": getattr(stats, 'correlation', None),
                }
            if hasattr(result, 'per_column_stats'):
                result_dict["per_column_stats"] = result.per_column_stats
            # Build structured threshold results from stats
            stats = result.stats if hasattr(result, 'stats') else None
            if stats is not None:
                threshold_results = {}
                # Map each metric to its threshold (from era_config universes)
                sharpe_val = getattr(stats, 'sharpe', 0)
                turnover_val = getattr(stats, 'turnover', 0)
                drawdown_val = getattr(stats, 'drawdown', 0)
                correlation_val = getattr(stats, 'correlation', None)
                threshold_results["sharpe"] = {
                    "value": sharpe_val, "threshold": 0.3,
                    "passed": sharpe_val > 0.3 if sharpe_val is not None else False,
                }
                threshold_results["turnover"] = {
                    "value": turnover_val, "threshold": 1.5,
                    "passed": turnover_val < 1.5 if turnover_val is not None else False,
                }
                threshold_results["drawdown"] = {
                    "value": drawdown_val, "threshold": 0.25,
                    "passed": drawdown_val < 0.25 if drawdown_val is not None else False,
                }
                if correlation_val is not None:
                    threshold_results["correlation"] = {
                        "value": correlation_val, "threshold": 0.4,
                        "passed": abs(correlation_val) < 0.4,
                    }
                result_dict["threshold_results"] = threshold_results
            if hasattr(result, 'factor_pnl') and result.factor_pnl is not None:
                # Convert factor_pnl to chart-friendly format with real YYYY-MM-DD dates
                from datetime import datetime, timedelta
                pnl_list = list(result.factor_pnl) if hasattr(result.factor_pnl, '__iter__') else []
                cumulative = []
                cum = 0.0
                base_date = datetime(2025, 1, 1)
                dates = []
                for i, val in enumerate(pnl_list):
                    cum += float(val)
                    cumulative.append(round(cum, 2))
                    dates.append((base_date + timedelta(days=i)).strftime("%Y-%m-%d"))
                result_dict["pnl_matrix"] = {
                    "dates": dates,
                    "cumulative_pnl": cumulative,
                }
        else:
            result_dict = {"raw": str(result)}

        try:
            with self._lock:
                self._gui_conn.execute(
                    "INSERT OR REPLACE INTO gui_results (job_id, graph_dict, expression_type, result_json, created_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (job_id, json.dumps(graph_dict), expression_type,
                     json.dumps(result_dict), time.time()),
                )
                self._gui_conn.commit()
        except Exception as e:
            logger.warning("Failed to persist result for job %s: %s", job_id, e)

    def get_job_status(self, job_id: str) -> Optional[dict]:
        """Return current status of a job."""
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is None:
                return None
            job_info = entry[0]
            return {
                "id": job_info.job_id,
                "status": job_info.status,
                "progress": job_info.progress,
                "message": job_info.message,
                "error": job_info.error,
                "era_id": job_info.era_id,
                "created_at": job_info.created_at,
                "started_at": job_info.started_at,
                "completed_at": job_info.completed_at,
            }

    def get_job_result(self, job_id: str) -> Optional[dict]:
        """Return full result payload for a completed job."""
        with self._lock:
            if self._gui_conn is None:
                return None
            row = self._gui_conn.execute(
                "SELECT result_json FROM gui_results WHERE job_id = ?",
                (job_id,),
            ).fetchone()
            if row is None:
                return None
            return json.loads(row[0])

    def cancel_job(self, job_id: str) -> bool:
        """Cancel a running job. Returns True if cancelled."""
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is None:
                return False
            job_info, handle = entry
            job_info.status = "cancelled"
            if handle is not None and hasattr(handle, 'cancel'):
                handle.cancel()
            return True

    # ------------------------------------------------------------------
    # Saved Expressions
    # ------------------------------------------------------------------

    def save_expression(self, canonical_string: str, graph_dict: dict,
                        expression_type: str = "signal",
                        name: Optional[str] = None,
                        tags: Optional[list[str]] = None,
                        era_id: Optional[str] = None,
                        era_config: Optional[dict] = None) -> str:
        """Save an expression to the GUI database. Returns expression ID."""
        expr_id = str(uuid.uuid4())
        now = time.time()

        with self._lock:
            if self._gui_conn is None:
                raise RuntimeError("GUI database not initialized")
            self._gui_conn.execute(
                "INSERT INTO saved_expressions "
                "(id, canonical_string, graph_dict, expression_type, name, tags, era_id, era_config, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (expr_id, canonical_string, json.dumps(graph_dict), expression_type,
                 name, json.dumps(tags) if tags else None,
                 era_id, json.dumps(era_config) if era_config else None, now),
            )
            self._gui_conn.commit()
        return expr_id

    def list_expressions(self, limit: int = 100, offset: int = 0) -> list[dict]:
        """List saved expressions, newest first."""
        with self._lock:
            if self._gui_conn is None:
                return []
            rows = self._gui_conn.execute(
                "SELECT id, canonical_string, graph_dict, expression_type, name, tags, "
                "era_id, era_config, created_at "
                "FROM saved_expressions ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()

        result = []
        for row in rows:
            result.append({
                "id": row[0],
                "canonical_string": row[1],
                "graph_dict": json.loads(row[2]),
                "expression_type": row[3],
                "name": row[4],
                "tags": json.loads(row[5]) if row[5] else None,
                "era_id": row[6],
                "era_config": json.loads(row[7]) if row[7] else None,
                "created_at": row[8],
            })
        return result

    def get_expression(self, expr_id: str) -> Optional[dict]:
        """Get a single saved expression by ID."""
        with self._lock:
            if self._gui_conn is None:
                return None
            row = self._gui_conn.execute(
                "SELECT id, canonical_string, graph_dict, expression_type, name, tags, "
                "era_id, era_config, created_at "
                "FROM saved_expressions WHERE id = ?",
                (expr_id,),
            ).fetchone()
            if row is None:
                return None
            return {
                "id": row[0],
                "canonical_string": row[1],
                "graph_dict": json.loads(row[2]),
                "expression_type": row[3],
                "name": row[4],
                "tags": json.loads(row[5]) if row[5] else None,
                "era_id": row[6],
                "era_config": json.loads(row[7]) if row[7] else None,
                "created_at": row[8],
            }

    def delete_expression(self, expr_id: str) -> bool:
        """Delete a saved expression. Returns True if found and deleted."""
        with self._lock:
            if self._gui_conn is None:
                return False
            cursor = self._gui_conn.execute(
                "DELETE FROM saved_expressions WHERE id = ?", (expr_id,),
            )
            self._gui_conn.commit()
            return cursor.rowcount > 0

    # ------------------------------------------------------------------
    # History / Stats
    # ------------------------------------------------------------------

    def get_evaluation_history(self, eval_type: str = "signal",
                               limit: int = 50) -> list[dict]:
        """Return recent evaluation history from openforage's tracker."""
        with self._lock:
            if not self._initialized:
                return self._get_gui_result_history(limit)

            try:
                import openforage.simulate_signal as sim_mod
                tracker = sim_mod._search_tracker
                if tracker is None:
                    return self._get_gui_result_history(limit)

                records = tracker.get_evaluation_history(
                    eval_type=eval_type, limit=limit,
                )
                return [self._evaluation_record_to_dict(r) for r in records]
            except Exception as e:
                logger.warning("Failed to get evaluation history: %s", e)
                return self._get_gui_result_history(limit)

    def _get_gui_result_history(self, limit: int = 50) -> list[dict]:
        """Fallback: return results from gui.db."""
        if self._gui_conn is None:
            return []
        rows = self._gui_conn.execute(
            "SELECT job_id, graph_dict, expression_type, result_json, created_at "
            "FROM gui_results ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        results = []
        for row in rows:
            result_data = json.loads(row[3])
            stats = result_data.get("statistics", {})
            results.append({
                "eval_id": row[0],
                "eval_type": row[2],
                "graph": json.loads(row[1]) if row[1] else None,
                "timestamp": row[4],
                "passed_thresholds": _derive_passed(result_data.get("threshold_results")),
                "sharpe": stats.get("sharpe", 0),
                "returns": stats.get("returns", 0),
                "turnover": stats.get("turnover", 0),
                "drawdown": stats.get("drawdown", 0),
                "quality_score": stats.get("quality_score", 0),
                "correlation": stats.get("correlation", None),
            })
        return results

    def _evaluation_record_to_dict(self, record) -> dict:
        """Convert an EvaluationRecord to a plain dict."""
        if isinstance(record, dict):
            return record
        return {
            "eval_id": getattr(record, 'eval_id', 0),
            "eval_type": getattr(record, 'eval_type', ''),
            "era_id": getattr(record, 'era_id', 0),
            "timestamp": getattr(record, 'timestamp', 0),
            "graph": getattr(record, 'graph', None),
            "passed_thresholds": getattr(record, 'passed_thresholds', False),
            "sharpe": getattr(record, 'sharpe', 0),
            "returns": getattr(record, 'returns', 0),
            "turnover": getattr(record, 'turnover', 0),
            "drawdown": getattr(record, 'drawdown', 0),
            "delta_exposure": getattr(record, 'delta_exposure', 0),
            "max_weight": getattr(record, 'max_weight', 0),
            "quality_score": getattr(record, 'quality_score', 0),
            "correlation": getattr(record, 'correlation', None),
            "rejection_reason": getattr(record, 'rejection_reason', None),
            "functions": getattr(record, 'functions', None),
            "features": getattr(record, 'features', None),
        }

    def get_basic_stats(self) -> dict[str, Any]:
        """Return basic search statistics."""
        with self._lock:
            if not self._initialized:
                return self._get_gui_stats()

            try:
                import openforage.simulate_signal as sim_mod
                tracker = sim_mod._search_tracker
                if tracker is None:
                    return self._get_gui_stats()

                info = tracker.get_database_info()
                return {
                    "total_evaluated": getattr(info, 'signal_evaluation_count', 0) + getattr(info, 'strategy_evaluation_count', 0),
                    "signals_found": getattr(info, 'signal_evaluation_count', 0),
                    "strategies_found": getattr(info, 'strategy_evaluation_count', 0),
                    "db_size_bytes": getattr(info, 'file_size_bytes', 0),
                }
            except Exception as e:
                logger.warning("Failed to get basic stats: %s", e)
                return self._get_gui_stats()

    def _get_gui_stats(self) -> dict[str, Any]:
        """Fallback: compute stats from gui.db."""
        if self._gui_conn is None:
            return {"total_evaluated": 0, "signals_found": 0, "strategies_found": 0}
        row = self._gui_conn.execute(
            "SELECT COUNT(*) FROM gui_results",
        ).fetchone()
        total = row[0] if row else 0
        return {
            "total_evaluated": total,
            "signals_found": total,
            "strategies_found": 0,
        }

    # ------------------------------------------------------------------
    # Mock data (for degraded mode when openforage is not initialized)
    # ------------------------------------------------------------------

    def _mock_era_config(self) -> dict[str, Any]:
        return {
            "era_id": "era_3",
            "universe_id": "universe_top50",
            "universe_size": 42,
            "buffer": 5,
            "metaparameters": {
                "demean": {"options": ["cross_sectional", "time_series"], "default": "cross_sectional"},
                "resize": {"options": ["l1_resize", "clip"], "default": "l1_resize"},
            },
        }

    def _mock_features(self) -> list[str]:
        return [
            "close_1h", "volume_1h", "returns_1h", "spread_1h",
            "high_1h", "low_1h", "open_1h",
        ]

    def _mock_functions(self) -> list[dict[str, Any]]:
        return [
            {"name": "zscore", "category": "rotation", "params": {"window": {"type": "int", "default": 60}}},
            {"name": "rank", "category": "rotation", "params": {}},
            {"name": "demean", "category": "rotation", "params": {}},
            {"name": "ma", "category": "rotation", "params": {"window": {"type": "int", "default": 20}}},
            {"name": "ema", "category": "rotation", "params": {"span": {"type": "int", "default": 20}}},
            {"name": "diff", "category": "rotation", "params": {"periods": {"type": "int", "default": 1}}},
            {"name": "sum", "category": "rotation", "params": {"window": {"type": "int", "default": 20}}},
            {"name": "multiply", "category": "rotation", "params": {}},
        ]

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def close(self):
        """Close the GUI database connection."""
        with self._lock:
            if self._gui_conn is not None:
                self._gui_conn.close()
                self._gui_conn = None
