import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: "#0a0a0a",
          secondary: "#171717",
          tertiary: "#1e1e1e",
        },
        text: {
          primary: "#fafafa",
          secondary: "#a3a3a3",
        },
        border: {
          DEFAULT: "#525252",
          subtle: "#262626",
          hover: "#737373",
        },
        status: {
          success: "#4ade80",
          error: "#f87171",
          warning: "#fbbf24",
        },
      },
      fontFamily: {
        mono: ["JetBrains Mono", "monospace"],
      },
      borderRadius: {
        sm: "8px",
        md: "12px",
        lg: "16px",
        xl: "20px",
      },
      boxShadow: {
        sm: "0 1px 2px 0 rgba(0, 0, 0, 0.4)",
        md: "0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -2px rgba(0, 0, 0, 0.4)",
        lg: "0 10px 15px -3px rgba(0, 0, 0, 0.4), 0 4px 6px -4px rgba(0, 0, 0, 0.4)",
        glow: "0 0 20px rgba(74, 222, 128, 0.15)",
      },
      maxWidth: {
        content: "1152px",
        narrow: "672px",
      },
      transitionDuration: {
        fast: "100ms",
        normal: "200ms",
        slow: "300ms",
      },
    },
  },
  plugins: [],
};
export default config;
