import type { Metadata } from "next";
import "./globals.css";
import NavHeader from "@/components/shared/NavHeader";
import ExtensionErrorSuppressor from "@/components/shared/ExtensionErrorSuppressor";

export const metadata: Metadata = {
  title: "OpenForage Simulator",
  description: "Internal simulation and backtest tool for OpenForage signals",
};

/**
 * Inline script that suppresses wallet extension errors before Next.js
 * dev overlay registers its own error handler. Must be in <head> to run
 * before any other scripts.
 */
const EXTENSION_SUPPRESS_SCRIPT = `
(function() {
  function isExtErr(e) {
    var s = (e.message || '') + (e.filename || '') + ((e.error && e.error.stack) || '');
    return /chrome-extension:\\/\\//.test(s) || /moz-extension:\\/\\//.test(s) ||
      (/origin/i.test(e.message || '') && /not allowed/i.test(e.message || ''));
  }
  function isExtRej(e) {
    var r = e.reason;
    var s = typeof r === 'string' ? r : (r instanceof Error ? (r.message||'')+(r.stack||'') : '');
    return /chrome-extension:\\/\\//.test(s) || /moz-extension:\\/\\//.test(s) ||
      (/origin/i.test(s) && /not allowed/i.test(s));
  }
  window.addEventListener('error', function(e) { if (isExtErr(e)) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
  window.addEventListener('unhandledrejection', function(e) { if (isExtRej(e)) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
})();
`;

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <script
          dangerouslySetInnerHTML={{ __html: EXTENSION_SUPPRESS_SCRIPT }}
        />
      </head>
      <body className="font-mono antialiased min-h-screen bg-bg-primary text-text-primary">
        <ExtensionErrorSuppressor />
        <NavHeader />
        <main className="pt-16">{children}</main>
      </body>
    </html>
  );
}
