"use client";

import { Suspense, useState, useEffect, useCallback, useRef } from "react";
import { useSearchParams } from "next/navigation";
import { Play, Save, FolderOpen, AlertTriangle, X } from "lucide-react";
import SplitPanel from "@/components/shared/SplitPanel";
import TabBar from "@/components/shared/TabBar";
import ExpressionEditor from "@/components/editor/ExpressionEditor";
import ConfigPanel from "@/components/editor/ConfigPanel";
import StatsPanel from "@/components/backtest/StatsPanel";
import PnLChart from "@/components/backtest/PnLChart";
import ThresholdTable from "@/components/backtest/ThresholdTable";
import ProgressBar from "@/components/backtest/ProgressBar";
import ErrorBoundary from "@/components/shared/ErrorBoundary";
import {
  getEraConfig,
  getFeatures,
  getFunctions,
  submitBacktest,
  getJobResult,
  cancelJob,
  parseExpression,
  connectWebSocket,
  saveExpression,
  getCanonical,
  listExpressions,
} from "@/lib/api";
import type {
  EraConfig,
  BacktestResult,
  TabItem,
  JobStatus,
  WebSocketProgressMessage,
  Expression,
  GraphDictNode,
  FunctionDef,
} from "@/lib/types";

interface TabState {
  expression: string;
  graphDict: GraphDictNode | null;
  jobId: string | null;
  jobStatus: JobStatus;
  progress: number;
  error: string | null;
  result: BacktestResult | null;
}

/** Terminal statuses that map directly to JobStatus. */
const TERMINAL_STATUSES = new Set(["completed", "failed", "cancelled"]);

/** Normalize backend status phases to frontend JobStatus. */
function normalizeStatus(backendStatus: string): JobStatus {
  if (backendStatus === "idle") return "idle";
  if (backendStatus === "pending") return "pending";
  if (backendStatus === "error") return "failed";
  if (TERMINAL_STATUSES.has(backendStatus)) return backendStatus as JobStatus;
  // All intermediate phases (syncing, evaluating, backtesting, computing_mi, running, etc.)
  return "running";
}

function createTabId(): string {
  return `tab-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function createInitialTab(
  expression?: string
): { tab: TabItem; state: TabState } {
  const id = createTabId();
  return {
    tab: { id, label: "Expression 1" },
    state: {
      expression: expression || "",
      graphDict: null,
      jobId: null,
      jobStatus: "idle",
      progress: 0,
      error: null,
      result: null,
    },
  };
}

export default function BacktestPageWrapper() {
  return (
    <Suspense fallback={null}>
      <BacktestPage />
    </Suspense>
  );
}

function BacktestPage() {
  // Tab management
  const [tabs, setTabs] = useState<TabItem[]>([]);
  const [activeTabId, setActiveTabId] = useState<string>("");
  const [tabStates, setTabStates] = useState<Record<string, TabState>>({});

  // Era config (shared across tabs)
  const [eraConfig, setEraConfig] = useState<EraConfig | null>(null);
  const [eraError, setEraError] = useState<string | null>(null);

  // Features and functions for autocomplete/highlighting
  const [features, setFeatures] = useState<string[]>([]);
  const [functions, setFunctions] = useState<FunctionDef[]>([]);

  // Load modal
  const [showLoadModal, setShowLoadModal] = useState(false);
  const [savedExpressions, setSavedExpressions] = useState<Expression[]>([]);
  const [loadingExpressions, setLoadingExpressions] = useState(false);

  // Per-tab WebSocket refs (keyed by tab ID)
  const wsRefs = useRef<Record<string, WebSocket>>({});

  // Read query params for history restore
  const searchParams = useSearchParams();

  // Initialize first tab — read ?expression= or ?graph= query param if present
  useEffect(() => {
    const initialExpression = searchParams.get("expression") || "";
    const graphParam = searchParams.get("graph") || "";
    const { tab, state } = createInitialTab(initialExpression);
    setTabs([tab]);
    setActiveTabId(tab.id);
    setTabStates({ [tab.id]: state });

    // If we got a graph JSON from query param (from history re-run), use it directly
    if (graphParam) {
      try {
        const graph = JSON.parse(graphParam) as GraphDictNode;
        setTabStates((prev) => ({
          ...prev,
          [tab.id]: {
            ...prev[tab.id],
            graphDict: graph,
          },
        }));
      } catch {
        // Invalid graph JSON — ignore
      }
    } else if (initialExpression) {
      // If we got a text expression, parse it to get the graph dict
      parseExpression(initialExpression)
        .then((res) => {
          if (res.graph_dict) {
            setTabStates((prev) => ({
              ...prev,
              [tab.id]: {
                ...prev[tab.id],
                graphDict: res.graph_dict as unknown as GraphDictNode,
              },
            }));
          }
        })
        .catch(() => {
          // Parse failed — leave graphDict null, text is still populated
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Fetch era config, features, and functions on mount
  useEffect(() => {
    getEraConfig()
      .then(setEraConfig)
      .catch((err) => {
        setEraError(
          `Failed to load era config: ${err.message}. Is the backend running?`
        );
      });
    getFeatures()
      .then((res) => setFeatures(res.features))
      .catch(() => {});
    getFunctions()
      .then((res) => setFunctions(res.functions))
      .catch(() => {});
  }, []);

  // Current tab state helpers
  const currentState = tabStates[activeTabId];

  const updateTab = useCallback(
    (tabId: string, updates: Partial<TabState>) => {
      setTabStates((prev) => ({
        ...prev,
        [tabId]: { ...prev[tabId], ...updates },
      }));
    },
    []
  );

  const updateCurrentTab = useCallback(
    (updates: Partial<TabState>) => {
      updateTab(activeTabId, updates);
    },
    [activeTabId, updateTab]
  );

  // Tab management handlers
  const handleNewTab = useCallback(() => {
    const id = createTabId();
    const tabNumber = tabs.length + 1;
    const newTab: TabItem = { id, label: `Expression ${tabNumber}` };
    const newState: TabState = {
      expression: "",
      graphDict: null,
      jobId: null,
      jobStatus: "idle",
      progress: 0,
      error: null,
      result: null,
    };
    setTabs((prev) => [...prev, newTab]);
    setTabStates((prev) => ({ ...prev, [id]: newState }));
    setActiveTabId(id);
  }, [tabs.length]);

  const handleCloseTab = useCallback(
    (id: string) => {
      if (tabs.length <= 1) return;

      // Close this tab's WebSocket if any
      const ws = wsRefs.current[id];
      if (ws) {
        ws.close();
        delete wsRefs.current[id];
      }

      const idx = tabs.findIndex((t) => t.id === id);
      const newTabs = tabs.filter((t) => t.id !== id);
      setTabs(newTabs);
      setTabStates((prev) => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
      if (activeTabId === id) {
        const newIdx = Math.min(idx, newTabs.length - 1);
        setActiveTabId(newTabs[newIdx].id);
      }
    },
    [tabs, activeTabId]
  );

  // Connect WebSocket for a specific tab's job
  const connectWs = useCallback(
    (tabId: string, jobId: string) => {
      // Close any existing WS for this tab
      const existingWs = wsRefs.current[tabId];
      if (existingWs) {
        existingWs.close();
        delete wsRefs.current[tabId];
      }

      const ws = connectWebSocket(jobId);

      ws.onmessage = (event) => {
        try {
          const msg: WebSocketProgressMessage = JSON.parse(event.data);

          setTabStates((prev) => {
            // Find the tab that owns this job
            const ownerTabId = Object.keys(prev).find(
              (k) => prev[k].jobId === msg.job_id
            );
            if (!ownerTabId) return prev;

            const updates: Partial<TabState> = {
              progress: msg.progress,
              jobStatus: normalizeStatus(msg.status),
            };

            if (msg.error) {
              updates.error = msg.error;
            }

            return {
              ...prev,
              [ownerTabId]: { ...prev[ownerTabId], ...updates },
            };
          });

          // Fetch result on completion
          if (msg.status === "completed") {
            getJobResult(jobId)
              .then((result) => {
                setTabStates((prev) => {
                  const ownerTabId = Object.keys(prev).find(
                    (k) => prev[k].jobId === jobId
                  );
                  if (!ownerTabId) return prev;
                  return {
                    ...prev,
                    [ownerTabId]: {
                      ...prev[ownerTabId],
                      result,
                      jobStatus: "completed",
                    },
                  };
                });
              })
              .catch((err) => {
                setTabStates((prev) => {
                  const ownerTabId = Object.keys(prev).find(
                    (k) => prev[k].jobId === jobId
                  );
                  if (!ownerTabId) return prev;
                  return {
                    ...prev,
                    [ownerTabId]: {
                      ...prev[ownerTabId],
                      error: `Failed to fetch results: ${err.message}`,
                    },
                  };
                });
              });

            ws.close();
            delete wsRefs.current[tabId];
          }
        } catch {
          // Ignore malformed messages
        }
      };

      ws.onerror = () => {
        updateTab(tabId, {
          error: "WebSocket disconnected. Refresh to check status.",
        });
      };

      wsRefs.current[tabId] = ws;
    },
    [updateTab]
  );

  // Run backtest
  const handleRunBacktest = useCallback(async () => {
    if (!currentState || !eraConfig) return;

    updateCurrentTab({
      error: null,
      result: null,
      jobStatus: "pending",
      progress: 0,
    });

    try {
      // Parse the expression text into a graph_dict
      const parseResult = await parseExpression(currentState.expression);
      if (parseResult.error || !parseResult.graph_dict) {
        updateCurrentTab({
          error: parseResult.error || "Failed to parse expression",
          jobStatus: "failed",
        });
        return;
      }

      // Update graph dict in state
      updateCurrentTab({
        graphDict: parseResult.graph_dict as unknown as GraphDictNode,
      });

      // Submit the backtest
      const job = await submitBacktest(parseResult.graph_dict, eraConfig.era_id);

      updateCurrentTab({
        jobId: job.id,
        jobStatus: normalizeStatus(job.status),
        progress: job.progress,
      });

      // Connect WebSocket for live progress on this tab
      connectWs(activeTabId, job.id);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to submit backtest";
      updateCurrentTab({
        error: message,
        jobStatus: "failed",
      });
    }
  }, [currentState, eraConfig, updateCurrentTab, connectWs, activeTabId]);

  // Cancel running job
  const handleCancel = useCallback(async () => {
    if (!currentState?.jobId) return;
    try {
      await cancelJob(currentState.jobId);
      updateCurrentTab({ jobStatus: "cancelled" });
      const ws = wsRefs.current[activeTabId];
      if (ws) {
        ws.close();
        delete wsRefs.current[activeTabId];
      }
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to cancel job";
      updateCurrentTab({ error: message });
    }
  }, [currentState, updateCurrentTab, activeTabId]);

  // Save expression
  const handleSave = useCallback(async () => {
    if (!currentState || !eraConfig) return;

    try {
      const parseResult = await parseExpression(currentState.expression);
      if (parseResult.error || !parseResult.graph_dict) {
        updateCurrentTab({
          error: parseResult.error || "Cannot save: invalid expression",
        });
        return;
      }

      const canonicalResult = await getCanonical(parseResult.graph_dict);

      await saveExpression({
        canonical_string: canonicalResult.canonical_string,
        graph_dict: parseResult.graph_dict,
        expression_type: "signal",
        era_id: eraConfig.era_id,
      });

      updateCurrentTab({ error: null });
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to save expression";
      updateCurrentTab({ error: message });
    }
  }, [currentState, eraConfig, updateCurrentTab]);

  // Load expression modal
  const handleOpenLoad = useCallback(async () => {
    setShowLoadModal(true);
    setLoadingExpressions(true);
    try {
      const exprs = await listExpressions({ limit: 50 });
      setSavedExpressions(exprs);
    } catch {
      setSavedExpressions([]);
    } finally {
      setLoadingExpressions(false);
    }
  }, []);

  const handleLoadExpression = useCallback(
    (expr: Expression) => {
      updateCurrentTab({
        expression: expr.canonical_string,
        graphDict: expr.graph_dict as unknown as GraphDictNode,
        error: null,
        result: null,
        jobId: null,
        jobStatus: "idle",
        progress: 0,
      });
      setShowLoadModal(false);
    },
    [updateCurrentTab]
  );

  // Handle ExpressionEditor onChange
  const handleExpressionChange = useCallback(
    (text: string, graph: GraphDictNode | null) => {
      updateCurrentTab({ expression: text, graphDict: graph });
    },
    [updateCurrentTab]
  );

  // Cleanup all WebSockets on unmount
  useEffect(() => {
    return () => {
      Object.values(wsRefs.current).forEach((ws) => ws.close());
    };
  }, []);

  if (!currentState) {
    return null;
  }

  const isRunning =
    currentState.jobStatus === "running" ||
    currentState.jobStatus === "pending";

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      <TabBar
        tabs={tabs}
        activeTab={activeTabId}
        onTabChange={setActiveTabId}
        onNewTab={handleNewTab}
        onCloseTab={handleCloseTab}
      />

      <div className="flex-1 min-h-0">
        <SplitPanel
          left={
            <div className="space-y-4">
              {/* Expression Editor Header */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-xs font-semibold uppercase tracking-widest text-text-secondary">
                    Expression
                  </h2>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={handleSave}
                      disabled={!currentState.expression || isRunning}
                      className="flex items-center gap-1 px-2 py-1 text-xs text-text-secondary hover:text-text-primary disabled:opacity-40 disabled:cursor-not-allowed transition-colors duration-normal"
                      title="Save expression"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save
                    </button>
                    <button
                      onClick={handleOpenLoad}
                      className="flex items-center gap-1 px-2 py-1 text-xs text-text-secondary hover:text-text-primary transition-colors duration-normal"
                      title="Load expression"
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      Load
                    </button>
                  </div>
                </div>
                <ExpressionEditor
                  value={currentState.expression}
                  graphDict={currentState.graphDict}
                  onChange={handleExpressionChange}
                  features={features}
                  functions={functions}
                  error={
                    currentState.jobStatus === "failed"
                      ? currentState.error || undefined
                      : undefined
                  }
                />
              </div>

              {/* Run Button */}
              <button
                onClick={handleRunBacktest}
                disabled={
                  !currentState.expression || !eraConfig || isRunning
                }
                className={`
                  w-full flex items-center justify-center gap-2 px-4 py-2.5
                  text-xs font-semibold uppercase tracking-widest
                  rounded-md border transition-all duration-normal
                  ${
                    isRunning
                      ? "bg-status-success/10 border-status-success/30 text-status-success cursor-wait"
                      : "bg-status-success/10 border-status-success/30 text-status-success hover:bg-status-success/20 hover:shadow-glow disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-status-success/10 disabled:hover:shadow-none"
                  }
                `}
              >
                <Play className="w-4 h-4" />
                {isRunning
                  ? "Running..."
                  : !eraConfig && eraError
                    ? "Backend Unavailable"
                    : "Run Backtest"}
              </button>

              {/* Progress Bar */}
              {currentState.jobStatus !== "idle" && (
                <ProgressBar
                  progress={currentState.progress}
                  status={currentState.jobStatus}
                  onCancel={handleCancel}
                />
              )}

              {/* Era Config */}
              {eraError ? (
                <div className="flex items-start gap-2 px-3 py-2 bg-status-warning/10 border border-status-warning/30 rounded-sm">
                  <AlertTriangle className="w-4 h-4 text-status-warning mt-0.5 flex-shrink-0" />
                  <span className="text-xs text-status-warning">
                    {eraError}
                  </span>
                </div>
              ) : (
                <ConfigPanel eraConfig={eraConfig} />
              )}
            </div>
          }
          right={
            <div className="space-y-4">
              {/* Stats */}
              <ErrorBoundary label="Stats Panel">
                <StatsPanel
                  statistics={currentState.result?.statistics || null}
                  thresholds={currentState.result?.threshold_results}
                />
              </ErrorBoundary>

              {/* PnL Chart */}
              <ErrorBoundary label="PnL Chart">
                <PnLChart
                  pnlData={currentState.result?.pnl_matrix || null}
                />
              </ErrorBoundary>

              {/* Threshold Table */}
              <ErrorBoundary label="Threshold Table">
                <ThresholdTable
                  thresholds={currentState.result?.threshold_results || null}
                />
              </ErrorBoundary>
            </div>
          }
        />
      </div>

      {/* Load Expression Modal */}
      {showLoadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-bg-secondary border border-border-subtle rounded-md w-full max-w-lg max-h-[70vh] flex flex-col">
            {/* Modal header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-border-subtle">
              <h3 className="text-xs font-semibold uppercase tracking-widest text-text-primary">
                Load Expression
              </h3>
              <button
                onClick={() => setShowLoadModal(false)}
                className="p-1 text-text-secondary hover:text-text-primary transition-colors duration-normal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal body */}
            <div className="flex-1 overflow-y-auto p-4">
              {loadingExpressions ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      className="h-8 bg-bg-tertiary rounded-sm animate-pulse"
                    />
                  ))}
                </div>
              ) : savedExpressions.length === 0 ? (
                <p className="text-xs text-text-secondary text-center py-8">
                  No saved expressions yet.
                </p>
              ) : (
                <div className="space-y-1">
                  {savedExpressions.map((expr) => (
                    <button
                      key={expr.id}
                      onClick={() => handleLoadExpression(expr)}
                      className="w-full text-left px-3 py-2 rounded-sm hover:bg-bg-tertiary transition-colors duration-fast group"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-text-primary truncate">
                          {expr.name || expr.canonical_string}
                        </span>
                        <span className="text-[10px] text-text-secondary">
                          {expr.era_id}
                        </span>
                      </div>
                      {expr.name && (
                        <div className="text-[10px] text-text-secondary font-mono truncate mt-0.5">
                          {expr.canonical_string}
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
