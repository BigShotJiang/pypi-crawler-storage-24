"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  History,
  Play,
  ChevronDown,
  ChevronUp,
  CheckCircle,
  XCircle,
} from "lucide-react";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "";

interface EvaluationRecord {
  eval_id: string | number;
  eval_type: string;
  era_id?: number;
  timestamp: number;
  graph?: Record<string, unknown> | null;
  passed_thresholds: boolean;
  sharpe: number;
  returns: number;
  turnover: number;
  drawdown: number;
  quality_score: number;
  correlation?: number | null;
  rejection_reason?: string | null;
  functions?: string[] | null;
  features?: string[] | null;
}

export default function HistoryPage() {
  const router = useRouter();

  const [records, setRecords] = useState<EvaluationRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [evalType, setEvalType] = useState("signal");
  const [expandedId, setExpandedId] = useState<string | number | null>(null);

  const fetchHistory = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(
        `${API_BASE}/api/history?eval_type=${evalType}&limit=50`
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: EvaluationRecord[] = await res.json();
      setRecords(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch history");
    } finally {
      setLoading(false);
    }
  }, [evalType]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  function formatDate(ts: number): string {
    if (!ts) return "--";
    try {
      const d = new Date(ts * 1000);
      return d.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "--";
    }
  }

  function formatNum(val: number | null | undefined, decimals = 4): string {
    if (val == null || !isFinite(val)) return "--";
    return val.toFixed(decimals);
  }

  function handleLoad(record: EvaluationRecord) {
    if (record.graph) {
      // Navigate to backtest page with the graph loaded
      router.push(
        `/?graph=${encodeURIComponent(JSON.stringify(record.graph))}`
      );
    }
  }

  return (
    <div className="max-w-content mx-auto px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-lg font-semibold uppercase tracking-widest text-text-primary">
          Evaluation History
        </h1>

        {/* Type toggle */}
        <div className="flex items-center gap-1 bg-bg-secondary border border-border-subtle rounded-sm p-0.5">
          {["signal", "strategy"].map((t) => (
            <button
              key={t}
              onClick={() => setEvalType(t)}
              className={`px-3 py-1 text-xs font-medium uppercase tracking-wider rounded-sm transition-colors duration-fast ${
                evalType === t
                  ? "text-status-success bg-status-success/10"
                  : "text-text-secondary hover:text-text-primary"
              }`}
            >
              {t}s
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="mb-4 px-3 py-2 bg-status-error/10 border border-status-error/30 rounded-sm">
          <span className="text-xs text-status-error">{error}</span>
        </div>
      )}

      <div className="bg-bg-secondary border border-border-subtle rounded-md overflow-hidden">
        {loading && records.length === 0 ? (
          <div className="p-6 space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className="h-3 w-16 bg-bg-tertiary rounded-sm animate-pulse" />
                <div className="h-3 w-24 bg-bg-tertiary rounded-sm animate-pulse" />
                <div className="h-3 w-16 bg-bg-tertiary rounded-sm animate-pulse" />
                <div className="h-3 w-20 bg-bg-tertiary rounded-sm animate-pulse" />
              </div>
            ))}
          </div>
        ) : records.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <History className="w-8 h-8 text-text-secondary/30" />
            <p className="text-xs text-text-secondary">
              No evaluations yet. Run a backtest to see results here.
            </p>
          </div>
        ) : (
          <>
            {/* Table header */}
            <div className="hidden md:grid grid-cols-[0.5fr_1fr_1fr_1fr_1fr_1fr_1.2fr] gap-2 px-4 py-2.5 border-b border-border-subtle bg-bg-tertiary">
              <span className="text-xs font-semibold uppercase tracking-wider text-text-secondary">
                Status
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-text-secondary text-right">
                Sharpe
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-text-secondary text-right">
                Returns
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-text-secondary text-right">
                Turnover
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-text-secondary text-right">
                Drawdown
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-text-secondary text-right">
                Quality
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-text-secondary text-right">
                Date
              </span>
            </div>

            {records.map((rec) => {
              const isExpanded = expandedId === rec.eval_id;

              return (
                <div key={rec.eval_id}>
                  <div
                    onClick={() =>
                      setExpandedId(isExpanded ? null : rec.eval_id)
                    }
                    className={`grid grid-cols-1 md:grid-cols-[0.5fr_1fr_1fr_1fr_1fr_1fr_1.2fr] gap-2 px-4 py-3 border-b border-border-subtle cursor-pointer transition-colors duration-fast ${
                      isExpanded
                        ? "bg-bg-tertiary"
                        : "hover:bg-bg-tertiary/50"
                    }`}
                  >
                    <span className="flex items-center">
                      {rec.passed_thresholds ? (
                        <CheckCircle className="w-4 h-4 text-status-success" />
                      ) : (
                        <XCircle className="w-4 h-4 text-status-error" />
                      )}
                    </span>
                    <span
                      className={`text-xs text-right font-medium ${
                        rec.sharpe > 0.3
                          ? "text-status-success"
                          : "text-text-primary"
                      }`}
                    >
                      {formatNum(rec.sharpe)}
                    </span>
                    <span className="text-xs text-text-primary text-right">
                      {formatNum(rec.returns)}
                    </span>
                    <span className="text-xs text-text-primary text-right">
                      {formatNum(rec.turnover)}
                    </span>
                    <span className="text-xs text-text-primary text-right">
                      {formatNum(rec.drawdown)}
                    </span>
                    <span className="text-xs text-text-primary text-right">
                      {formatNum(rec.quality_score)}
                    </span>
                    <div className="flex items-center justify-end gap-1">
                      <span className="text-xs text-text-secondary">
                        {formatDate(rec.timestamp)}
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-3 h-3 text-text-secondary" />
                      ) : (
                        <ChevronDown className="w-3 h-3 text-text-secondary" />
                      )}
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="px-4 py-4 bg-bg-tertiary border-b border-border-subtle">
                      <div className="space-y-3">
                        {rec.rejection_reason && (
                          <div>
                            <span className="text-xs font-semibold uppercase tracking-wider text-status-error">
                              Rejection: {rec.rejection_reason}
                            </span>
                          </div>
                        )}

                        {rec.correlation != null && (
                          <div className="text-xs text-text-secondary">
                            Correlation: {formatNum(rec.correlation)}
                          </div>
                        )}

                        {rec.functions && rec.functions.length > 0 && (
                          <div>
                            <span className="text-xs font-semibold uppercase tracking-wider text-text-secondary">
                              Functions
                            </span>
                            <div className="mt-1 flex gap-1.5 flex-wrap">
                              {rec.functions.map((fn) => (
                                <span
                                  key={fn}
                                  className="px-2 py-0.5 text-xs text-text-secondary bg-bg-secondary border border-border-subtle rounded-sm"
                                >
                                  {fn}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {rec.graph && (
                          <div className="flex items-center gap-2 pt-2">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleLoad(rec);
                              }}
                              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium uppercase tracking-wider text-status-success bg-status-success/10 border border-status-success/30 rounded-sm hover:bg-status-success/20 transition-colors duration-fast"
                            >
                              <Play className="w-3.5 h-3.5" />
                              Re-run
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </>
        )}
      </div>
    </div>
  );
}
