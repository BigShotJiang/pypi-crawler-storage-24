"use client";

import { BarChart3, CheckCircle, XCircle } from "lucide-react";

interface ThresholdInfo {
  value: number;
  threshold: number;
  passed: boolean;
}

interface StatsPanelProps {
  statistics: Record<string, number> | null;
  thresholds?: Record<string, ThresholdInfo> | null;
}

const STAT_LABELS: Record<string, string> = {
  sharpe: "Sharpe Ratio",
  annualized_returns: "Annual Returns",
  avg_turnover: "Avg Turnover",
  max_drawdown: "Max Drawdown",
  total_return: "Total Return",
  volatility: "Volatility",
  calmar_ratio: "Calmar Ratio",
  sortino_ratio: "Sortino Ratio",
  win_rate: "Win Rate",
  profit_factor: "Profit Factor",
};

function formatStatValue(key: string, value: number): string {
  if (
    key.includes("return") ||
    key.includes("drawdown") ||
    key.includes("turnover") ||
    key.includes("win_rate") ||
    key.includes("volatility")
  ) {
    return `${(value * 100).toFixed(2)}%`;
  }
  return value.toFixed(4);
}

function SkeletonRow() {
  return (
    <div className="flex items-center justify-between py-2 px-3">
      <div className="h-3 w-28 bg-bg-tertiary rounded-sm animate-pulse" />
      <div className="h-3 w-16 bg-bg-tertiary rounded-sm animate-pulse" />
    </div>
  );
}

export default function StatsPanel({ statistics, thresholds }: StatsPanelProps) {
  if (statistics === null) {
    return (
      <div className="bg-bg-secondary border border-border-subtle rounded-md p-4">
        <div className="flex items-center gap-2 mb-3">
          <BarChart3 className="w-4 h-4 text-text-secondary" />
          <h3 className="text-xs font-semibold uppercase tracking-widest text-text-secondary">
            Statistics
          </h3>
        </div>
        <div className="space-y-1">
          <SkeletonRow />
          <SkeletonRow />
          <SkeletonRow />
          <SkeletonRow />
          <SkeletonRow />
        </div>
      </div>
    );
  }

  const statEntries = Object.entries(statistics);

  if (statEntries.length === 0) {
    return (
      <div className="bg-bg-secondary border border-border-subtle rounded-md p-4">
        <div className="flex items-center gap-2 mb-3">
          <BarChart3 className="w-4 h-4 text-text-secondary" />
          <h3 className="text-xs font-semibold uppercase tracking-widest text-text-secondary">
            Statistics
          </h3>
        </div>
        <p className="text-xs text-text-secondary">
          Run a backtest to see statistics.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-bg-secondary border border-border-subtle rounded-md p-4">
      <div className="flex items-center gap-2 mb-3">
        <BarChart3 className="w-4 h-4 text-text-secondary" />
        <h3 className="text-xs font-semibold uppercase tracking-widest text-text-secondary">
          Statistics
        </h3>
      </div>

      <div className="space-y-0.5">
        {statEntries.map(([key, value]) => {
          const threshold = thresholds?.[key];
          const passed = threshold?.passed;

          return (
            <div
              key={key}
              className="flex items-center justify-between py-1.5 px-2 rounded-sm hover:bg-bg-tertiary transition-colors duration-fast"
            >
              <span className="text-xs text-text-secondary">
                {STAT_LABELS[key] || key}
              </span>
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs font-medium ${
                    passed === true
                      ? "text-status-success"
                      : passed === false
                        ? "text-status-error"
                        : "text-text-primary"
                  }`}
                >
                  {formatStatValue(key, value)}
                </span>
                {passed !== undefined && (
                  passed ? (
                    <CheckCircle className="w-3.5 h-3.5 text-status-success" />
                  ) : (
                    <XCircle className="w-3.5 h-3.5 text-status-error" />
                  )
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
