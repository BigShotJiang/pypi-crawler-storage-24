"use client";

import { Shield, CheckCircle, XCircle } from "lucide-react";

/**
 * Backend may return threshold_results in two shapes:
 *
 * 1. Structured: Record<string, { value: number; threshold: number; passed: boolean }>
 * 2. Flat (current mock): { mi_pass: bool, mi_score: number, mi_threshold: number, correlation_threshold: number }
 *
 * This component handles both by normalizing flat keys into structured entries.
 */

interface ThresholdEntry {
  value: number;
  threshold: number;
  passed: boolean;
}

interface ThresholdTableProps {
  thresholds: Record<string, unknown> | null;
}

const METRIC_LABELS: Record<string, string> = {
  sharpe: "Sharpe Ratio",
  annualized_returns: "Annual Returns",
  avg_turnover: "Avg Turnover",
  max_drawdown: "Max Drawdown",
  total_return: "Total Return",
  volatility: "Volatility",
  calmar_ratio: "Calmar Ratio",
  sortino_ratio: "Sortino Ratio",
  win_rate: "Win Rate",
  profit_factor: "Profit Factor",
  correlation_score: "Correlation Score",
  mi: "Mutual Information",
  correlation: "Correlation",
};

function formatValue(key: string, value: number): string {
  if (value == null || typeof value !== "number" || !isFinite(value)) {
    return "--";
  }
  if (
    key.includes("return") ||
    key.includes("drawdown") ||
    key.includes("turnover") ||
    key.includes("win_rate") ||
    key.includes("volatility")
  ) {
    return `${(value * 100).toFixed(2)}%`;
  }
  return value.toFixed(4);
}

/**
 * Normalize flat threshold data into structured entries.
 *
 * Flat format example:
 *   { mi_pass: true, mi_score: 0.08, mi_threshold: 0.02, correlation_threshold: 0.7 }
 *
 * Becomes:
 *   { mi: { value: 0.08, threshold: 0.02, passed: true } }
 *
 * Pattern: for each `xxx_pass` boolean, look for `xxx_score` and `xxx_threshold`.
 * Standalone `xxx_threshold` without a `_pass` key is shown as info-only.
 */
function normalizeThresholds(
  raw: Record<string, unknown>
): ThresholdEntry[] {
  const entries: ThresholdEntry[] = [];

  // Check if already structured (values are objects with .value/.threshold/.passed)
  const firstVal = Object.values(raw)[0];
  if (
    firstVal &&
    typeof firstVal === "object" &&
    firstVal !== null &&
    "value" in firstVal &&
    "threshold" in firstVal &&
    "passed" in firstVal
  ) {
    // Already structured
    for (const [, v] of Object.entries(raw)) {
      const entry = v as { value: number; threshold: number; passed: boolean };
      entries.push(entry);
    }
    return entries;
  }

  // Flat format: find xxx_pass keys, pair with xxx_score and xxx_threshold
  const keys = Object.keys(raw);
  const processedPrefixes = new Set<string>();

  for (const key of keys) {
    if (key.endsWith("_pass")) {
      const prefix = key.replace(/_pass$/, "");
      processedPrefixes.add(prefix);
      const score = raw[`${prefix}_score`];
      const threshold = raw[`${prefix}_threshold`];
      entries.push({
        value: typeof score === "number" ? score : 0,
        threshold: typeof threshold === "number" ? threshold : 0,
        passed: !!raw[key],
      });
    }
  }

  // Also pick up standalone xxx_threshold without a _pass (info-only, mark as passed)
  for (const key of keys) {
    if (key.endsWith("_threshold")) {
      const prefix = key.replace(/_threshold$/, "");
      if (!processedPrefixes.has(prefix)) {
        processedPrefixes.add(prefix);
        const threshold = raw[key];
        entries.push({
          value: 0,
          threshold: typeof threshold === "number" ? threshold : 0,
          passed: true,
        });
      }
    }
  }

  return entries;
}

function getEntryLabel(
  raw: Record<string, unknown>,
  index: number
): string {
  // Try to derive label from the raw keys
  const keys = Object.keys(raw).filter((k) => k.endsWith("_pass"));
  if (index < keys.length) {
    const prefix = keys[index].replace(/_pass$/, "");
    return METRIC_LABELS[prefix] || prefix.replace(/_/g, " ");
  }

  // Fallback for standalone thresholds
  const thresholdKeys = Object.keys(raw).filter(
    (k) =>
      k.endsWith("_threshold") &&
      !keys.some((pk) => k.startsWith(pk.replace(/_pass$/, "")))
  );
  const standaloneIdx = index - keys.length;
  if (standaloneIdx >= 0 && standaloneIdx < thresholdKeys.length) {
    const prefix = thresholdKeys[standaloneIdx].replace(/_threshold$/, "");
    return METRIC_LABELS[prefix] || prefix.replace(/_/g, " ");
  }

  return `Metric ${index + 1}`;
}

export default function ThresholdTable({ thresholds }: ThresholdTableProps) {
  if (!thresholds) {
    return null;
  }

  const rawEntries = Object.entries(thresholds);
  if (rawEntries.length === 0) {
    return null;
  }

  const normalized = normalizeThresholds(thresholds);
  if (normalized.length === 0) {
    return null;
  }

  const passCount = normalized.filter((t) => t.passed).length;
  const allPassed = passCount === normalized.length;

  return (
    <div className="bg-bg-secondary border border-border-subtle rounded-md p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-text-secondary" />
          <h3 className="text-xs font-semibold uppercase tracking-widest text-text-secondary">
            Threshold Results
          </h3>
        </div>
        <span
          className={`text-xs font-medium px-2 py-0.5 rounded-sm ${
            allPassed
              ? "text-status-success bg-status-success/10"
              : "text-status-error bg-status-error/10"
          }`}
        >
          {passCount}/{normalized.length} PASSED
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-border-subtle">
              <th className="text-left py-2 px-2 text-text-secondary font-medium uppercase tracking-wider">
                Metric
              </th>
              <th className="text-right py-2 px-2 text-text-secondary font-medium uppercase tracking-wider">
                Value
              </th>
              <th className="text-right py-2 px-2 text-text-secondary font-medium uppercase tracking-wider">
                Threshold
              </th>
              <th className="text-center py-2 px-2 text-text-secondary font-medium uppercase tracking-wider">
                Status
              </th>
            </tr>
          </thead>
          <tbody>
            {normalized.map((entry, index) => (
              <tr
                key={index}
                className="border-b border-border-subtle/50 hover:bg-bg-tertiary transition-colors duration-fast"
              >
                <td className="py-2 px-2 text-text-primary capitalize">
                  {getEntryLabel(thresholds, index)}
                </td>
                <td
                  className={`py-2 px-2 text-right font-medium ${
                    entry.passed ? "text-status-success" : "text-status-error"
                  }`}
                >
                  {formatValue("", entry.value)}
                </td>
                <td className="py-2 px-2 text-right text-text-secondary">
                  {formatValue("", entry.threshold)}
                </td>
                <td className="py-2 px-2 text-center">
                  {entry.passed ? (
                    <span className="inline-flex items-center gap-1 text-status-success">
                      <CheckCircle className="w-3.5 h-3.5" />
                      PASS
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-status-error">
                      <XCircle className="w-3.5 h-3.5" />
                      FAIL
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
