"use client";

import { Loader2, XCircle } from "lucide-react";

interface ProgressBarProps {
  progress: number; // 0-1
  status: string;
  onCancel?: () => void;
}

function getProgressColor(status: string): string {
  switch (status) {
    case "running":
    case "completed":
      return "bg-status-success";
    case "failed":
      return "bg-status-error";
    case "cancelled":
      return "bg-status-warning";
    default:
      return "bg-text-secondary";
  }
}

function getStatusLabel(status: string, progress: number): string {
  switch (status) {
    case "pending":
      return "Queued...";
    case "running":
      return `Running ${Math.round(progress * 100)}%`;
    case "completed":
      return "Completed";
    case "failed":
      return "Failed";
    case "cancelled":
      return "Cancelled";
    default:
      return status;
  }
}

export default function ProgressBar({
  progress,
  status,
  onCancel,
}: ProgressBarProps) {
  const canCancel = status === "running" || status === "pending";
  const isActive = status === "running" || status === "pending";
  const percentage = Math.min(Math.max(progress, 0), 1) * 100;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {isActive && (
            <Loader2 className="w-3.5 h-3.5 text-status-success animate-spin" />
          )}
          <span className="text-xs text-text-secondary">
            {getStatusLabel(status, progress)}
          </span>
        </div>

        {canCancel && onCancel && (
          <button
            onClick={onCancel}
            className="flex items-center gap-1 px-2 py-1 text-xs text-text-secondary hover:text-status-error transition-colors duration-normal"
          >
            <XCircle className="w-3.5 h-3.5" />
            Cancel
          </button>
        )}
      </div>

      <div className="w-full h-1.5 bg-bg-tertiary rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-normal ${getProgressColor(status)}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
