"use client";

import { useEffect, useRef, useCallback } from "react";
import { TrendingUp } from "lucide-react";
import type { PnLData } from "@/lib/types";

interface PnLChartProps {
  pnlData: PnLData | null;
}

export default function PnLChart({ pnlData }: PnLChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<ReturnType<typeof import("lightweight-charts").createChart> | null>(null);

  const initChart = useCallback(async () => {
    if (!chartContainerRef.current) return;

    // Dynamic import for lightweight-charts (browser-only)
    const { createChart, ColorType, LineStyle } = await import(
      "lightweight-charts"
    );

    // Dispose previous chart if any
    if (chartRef.current) {
      chartRef.current.remove();
      chartRef.current = null;
    }

    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: 300,
      layout: {
        background: { type: ColorType.Solid, color: "#0a0a0a" },
        textColor: "#a3a3a3",
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "#262626", style: LineStyle.Dotted },
        horzLines: { color: "#262626", style: LineStyle.Dotted },
      },
      crosshair: {
        vertLine: { color: "#525252", width: 1, style: LineStyle.Dashed },
        horzLine: { color: "#525252", width: 1, style: LineStyle.Dashed },
      },
      timeScale: {
        borderColor: "#262626",
        timeVisible: false,
      },
      rightPriceScale: {
        borderColor: "#262626",
      },
    });

    chartRef.current = chart;

    // Determine data source: backend sends {dates, cumulative_pnl} or {timestamps, values}
    const rawDates = pnlData?.dates || pnlData?.timestamps || [];
    const cumulativePnl = pnlData?.cumulative_pnl;
    const values2d = pnlData?.values;

    // Filter out invalid dates (backend mock can produce e.g. 2025-02-30).
    // Build a valid-index list so we can skip corresponding values too.
    function isValidDate(d: string): boolean {
      const parsed = new Date(d + "T00:00:00Z");
      return !isNaN(parsed.getTime());
    }

    const validIndices = rawDates
      .map((d, i) => (isValidDate(d) ? i : -1))
      .filter((i) => i >= 0);
    const dates = validIndices.map((i) => rawDates[i]);

    if (dates.length > 0) {
      if (cumulativePnl && cumulativePnl.length > 0) {
        // Single series from backend mock format
        const series = chart.addLineSeries({
          color: "#4ade80",
          lineWidth: 2,
          title: "Cumulative PnL",
          priceLineVisible: false,
        });

        const data = dates.map((d, idx) => ({
          time: d as string,
          value: cumulativePnl[validIndices[idx]] ?? 0,
        }));

        series.setData(data as Parameters<typeof series.setData>[0]);
      } else if (values2d && values2d.length > 0) {
        // Multiple series: values is 2D [timestamp_idx][col_idx]
        const columns = pnlData?.columns || ["PnL"];
        const seriesColors = ["#4ade80", "#fbbf24", "#f87171", "#60a5fa", "#c084fc", "#fb923c"];
        const numCols = values2d[0]?.length || 1;

        for (let colIdx = 0; colIdx < numCols; colIdx++) {
          const series = chart.addLineSeries({
            color: seriesColors[colIdx % seriesColors.length],
            lineWidth: 2,
            title: columns[colIdx] || `Series ${colIdx}`,
            priceLineVisible: false,
          });

          const data = dates.map((ts, idx) => ({
            time: ts as string,
            value: values2d[validIndices[idx]]?.[colIdx] ?? 0,
          }));

          series.setData(data as Parameters<typeof series.setData>[0]);
        }
      }

      chart.timeScale().fitContent();
    }

    // Resize observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width } = entry.contentRect;
        chart.applyOptions({ width });
      }
    });
    resizeObserver.observe(chartContainerRef.current);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
      chartRef.current = null;
    };
  }, [pnlData]);

  useEffect(() => {
    let cleanup: (() => void) | undefined;

    initChart().then((c) => {
      cleanup = c;
    });

    return () => {
      cleanup?.();
    };
  }, [initChart]);

  if (!pnlData) {
    return (
      <div className="bg-bg-secondary border border-border-subtle rounded-md p-4">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="w-4 h-4 text-text-secondary" />
          <h3 className="text-xs font-semibold uppercase tracking-widest text-text-secondary">
            PnL Chart
          </h3>
        </div>
        <div className="h-[300px] flex items-center justify-center">
          <span className="text-xs text-text-secondary">
            Run a backtest to see the PnL chart.
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-bg-secondary border border-border-subtle rounded-md p-4">
      <div className="flex items-center gap-2 mb-3">
        <TrendingUp className="w-4 h-4 text-text-secondary" />
        <h3 className="text-xs font-semibold uppercase tracking-widest text-text-secondary">
          PnL Chart
        </h3>
      </div>
      <div ref={chartContainerRef} className="w-full" />
    </div>
  );
}
