/**
 * OpenForage design system tokens for the simulator GUI.
 * Single source of truth for all visual constants.
 */

export const colors = {
  bg: {
    primary: "#0a0a0a",
    secondary: "#171717",
    tertiary: "#1e1e1e",
  },
  text: {
    primary: "#fafafa",
    secondary: "#a3a3a3",
  },
  border: {
    default: "#525252",
    subtle: "#262626",
    hover: "#737373",
  },
  status: {
    success: "#4ade80",
    error: "#f87171",
    warning: "#fbbf24",
  },
} as const;

export const typography = {
  fontFamily: "'JetBrains Mono', monospace",
  sizes: {
    xs: "0.75rem",
    sm: "0.875rem",
    base: "1rem",
    lg: "1.125rem",
    xl: "1.25rem",
    "2xl": "1.5rem",
    "3xl": "1.875rem",
  },
  weights: {
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
  },
  heading: {
    textTransform: "uppercase" as const,
    letterSpacing: "0.1em",
  },
} as const;

export const spacing = {
  sectionGap: "2rem",
  cardPadding: "1.5rem",
  gridGap: "1rem",
  maxWidth: {
    content: "1152px",
    narrow: "672px",
  },
} as const;

export const borderRadius = {
  sm: "8px",
  md: "12px",
  lg: "16px",
  xl: "20px",
  full: "9999px",
} as const;

export const shadows = {
  sm: "0 1px 2px 0 rgba(0, 0, 0, 0.4)",
  md: "0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -2px rgba(0, 0, 0, 0.4)",
  lg: "0 10px 15px -3px rgba(0, 0, 0, 0.4), 0 4px 6px -4px rgba(0, 0, 0, 0.4)",
  glow: "0 0 20px rgba(74, 222, 128, 0.15)",
} as const;

export const motion = {
  fast: "100ms",
  normal: "200ms",
  slow: "300ms",
} as const;

export const glass = {
  bgHeader: "rgba(10, 10, 10, 0.8)",
  bgModal: "rgba(23, 23, 23, 0.9)",
  blur: "12px",
  border: "rgba(82, 82, 82, 0.3)",
} as const;
