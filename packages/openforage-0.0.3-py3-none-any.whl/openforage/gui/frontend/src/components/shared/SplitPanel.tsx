"use client";

import {
  Panel,
  PanelGroup,
  PanelResizeHandle,
} from "react-resizable-panels";

interface SplitPanelProps {
  left: React.ReactNode;
  right: React.ReactNode;
  defaultLeftSize?: number;
  defaultRightSize?: number;
  minLeftSize?: number;
  minRightSize?: number;
}

export default function SplitPanel({
  left,
  right,
  defaultLeftSize = 40,
  defaultRightSize = 60,
  minLeftSize = 25,
  minRightSize = 25,
}: SplitPanelProps) {
  return (
    <PanelGroup direction="horizontal" className="h-full">
      <Panel defaultSize={defaultLeftSize} minSize={minLeftSize}>
        <div className="h-full overflow-auto p-4">{left}</div>
      </Panel>

      <PanelResizeHandle className="w-1.5 bg-border-subtle hover:bg-status-success transition-colors duration-normal flex items-center justify-center group">
        <div className="w-0.5 h-8 bg-border rounded-full group-hover:bg-status-success transition-colors duration-normal" />
      </PanelResizeHandle>

      <Panel defaultSize={defaultRightSize} minSize={minRightSize}>
        <div className="h-full overflow-auto p-4">{right}</div>
      </Panel>
    </PanelGroup>
  );
}
