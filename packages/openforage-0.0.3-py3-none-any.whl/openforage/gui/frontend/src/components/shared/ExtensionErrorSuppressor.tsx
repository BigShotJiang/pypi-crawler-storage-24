"use client";

import { useEffect } from "react";

/**
 * Backup suppressor for wallet extension errors that slip past the
 * inline <head> script in layout.tsx. The <head> script is the primary
 * defense (runs before Next.js dev overlay). This useEffect is a
 * secondary layer for late-binding errors.
 */
export default function ExtensionErrorSuppressor() {
  useEffect(() => {
    function isExtensionError(event: ErrorEvent): boolean {
      const msg = event.message || "";
      const filename = event.filename || "";
      const stack = event.error?.stack || "";
      return (
        /chrome-extension:\/\//.test(msg + filename + stack) ||
        /moz-extension:\/\//.test(msg + filename + stack) ||
        (/origin/i.test(msg) && /not allowed/i.test(msg))
      );
    }

    function handler(event: ErrorEvent) {
      if (isExtensionError(event)) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }

    function rejectionHandler(event: PromiseRejectionEvent) {
      const reason = event.reason;
      const msg =
        typeof reason === "string"
          ? reason
          : reason instanceof Error
            ? (reason.message || "") + (reason.stack || "")
            : "";
      if (
        /chrome-extension:\/\//.test(msg) ||
        /moz-extension:\/\//.test(msg) ||
        (/origin/i.test(msg) && /not allowed/i.test(msg))
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }

    window.addEventListener("error", handler, true);
    window.addEventListener("unhandledrejection", rejectionHandler, true);

    return () => {
      window.removeEventListener("error", handler, true);
      window.removeEventListener("unhandledrejection", rejectionHandler, true);
    };
  }, []);

  return null;
}
