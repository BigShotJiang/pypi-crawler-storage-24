"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Activity } from "lucide-react";

const NAV_LINKS = [
  { href: "/", label: "Backtest" },
  { href: "/history", label: "History" },
] as const;

export default function NavHeader() {
  const pathname = usePathname();

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 border-b"
      style={{
        backgroundColor: "rgba(10, 10, 10, 0.8)",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
        borderColor: "rgba(82, 82, 82, 0.3)",
      }}
    >
      <div className="max-w-content mx-auto px-6 h-14 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <Activity className="w-5 h-5 text-status-success transition-transform duration-normal group-hover:scale-110" />
          <span
            className="text-sm font-semibold tracking-widest uppercase text-text-primary"
          >
            OpenForage Simulator
          </span>
        </Link>

        <nav className="flex items-center gap-1">
          {NAV_LINKS.map((link) => {
            const isActive =
              link.href === "/"
                ? pathname === "/"
                : pathname.startsWith(link.href);

            return (
              <Link
                key={link.href}
                href={link.href}
                className={`
                  px-3 py-1.5 text-xs font-medium uppercase tracking-wider
                  transition-colors duration-normal rounded-sm
                  ${
                    isActive
                      ? "text-status-success bg-status-success/10"
                      : "text-text-secondary hover:text-text-primary hover:bg-bg-tertiary"
                  }
                `}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
