"use client";

import { Component, type ReactNode } from "react";
import { AlertTriangle } from "lucide-react";

interface ErrorBoundaryProps {
  children: ReactNode;
  /** Fallback label shown in the error card, e.g. "Chart" or "Editor". */
  label?: string;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

/**
 * React error boundary that catches render errors in its children
 * and shows a compact fallback card instead of crashing the whole page.
 *
 * Wrap individual heavy components (Monaco, React Flow, Lightweight Charts)
 * so a crash in one does not take down the rest of the UI.
 */
export default class ErrorBoundary extends Component<
  ErrorBoundaryProps,
  ErrorBoundaryState
> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error(
      `[ErrorBoundary${this.props.label ? `: ${this.props.label}` : ""}]`,
      error,
      info.componentStack
    );
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center gap-2 p-6 bg-bg-secondary border border-border-subtle rounded-md text-center">
          <AlertTriangle className="w-5 h-5 text-status-warning" />
          <p className="text-xs text-text-secondary">
            {this.props.label
              ? `${this.props.label} failed to render.`
              : "Something went wrong."}
          </p>
          <button
            onClick={() => this.setState({ hasError: false, error: null })}
            className="px-3 py-1 text-xs text-text-secondary hover:text-text-primary border border-border-subtle rounded-sm transition-colors duration-normal"
          >
            Retry
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
