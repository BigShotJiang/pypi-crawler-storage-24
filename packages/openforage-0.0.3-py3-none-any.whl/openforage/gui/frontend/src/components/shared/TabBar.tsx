"use client";

import { Plus, X } from "lucide-react";
import type { TabItem } from "@/lib/types";

interface TabBarProps {
  tabs: TabItem[];
  activeTab: string;
  onTabChange: (id: string) => void;
  onNewTab: () => void;
  onCloseTab: (id: string) => void;
}

export default function TabBar({
  tabs,
  activeTab,
  onTabChange,
  onNewTab,
  onCloseTab,
}: TabBarProps) {
  return (
    <div className="flex items-center gap-1 border-b border-border-subtle px-2 py-1 bg-bg-secondary overflow-x-auto">
      {tabs.map((tab) => {
        const isActive = tab.id === activeTab;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`
              group flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium
              rounded-sm transition-colors duration-normal whitespace-nowrap
              ${
                isActive
                  ? "bg-bg-tertiary text-status-success border border-border-subtle"
                  : "text-text-secondary hover:text-text-primary hover:bg-bg-tertiary border border-transparent"
              }
            `}
          >
            <span>{tab.label}</span>
            {tabs.length > 1 && (
              <span
                role="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseTab(tab.id);
                }}
                className={`
                  inline-flex items-center justify-center w-4 h-4 rounded-full
                  transition-colors duration-normal
                  ${
                    isActive
                      ? "hover:bg-status-error/20 hover:text-status-error"
                      : "opacity-0 group-hover:opacity-100 hover:bg-status-error/20 hover:text-status-error"
                  }
                `}
              >
                <X className="w-3 h-3" />
              </span>
            )}
          </button>
        );
      })}

      <button
        onClick={onNewTab}
        className="flex items-center justify-center w-7 h-7 text-text-secondary hover:text-status-success hover:bg-bg-tertiary rounded-sm transition-colors duration-normal"
        title="New expression"
      >
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );
}
