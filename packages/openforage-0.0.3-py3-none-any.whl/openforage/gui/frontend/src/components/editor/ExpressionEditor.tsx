"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import CodeEditor from "./CodeEditor";
import { parseExpression, getCanonical } from "@/lib/api";
import type { GraphDictNode, FunctionDef } from "@/lib/types";
import type { GraphDictNode as GraphUtilsNode } from "@/lib/graph-utils";
import ErrorBoundary from "@/components/shared/ErrorBoundary";

// Lazy-load GraphEditor (depends on React Flow which needs browser APIs)
const GraphEditor = dynamic(() => import("./GraphEditor"), {
  ssr: false,
  loading: () => (
    <div
      className="w-full h-full flex items-center justify-center"
      style={{ background: "#0a0a0a" }}
    >
      <span className="text-text-secondary text-xs">
        Loading graph editor...
      </span>
    </div>
  ),
});

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type EditorTab = "string" | "dict" | "visual";

interface ExpressionEditorProps {
  /** Controlled text value from parent (page tab state). */
  value: string;
  /** Last valid graph dict from parent. */
  graphDict: GraphDictNode | null;
  /** Called when text or graph changes. */
  onChange: (text: string, graph: GraphDictNode | null) => void;
  /** External error (e.g., backtest submission error). */
  error?: string;
  /** Available feature names for autocomplete/highlighting. */
  features?: string[];
  /** Available function definitions for autocomplete/highlighting. */
  functions?: FunctionDef[];
}

// ---------------------------------------------------------------------------
// Debounce helper
// ---------------------------------------------------------------------------

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function useDebouncedCallback<T extends (...args: any[]) => void>(
  callback: T,
  delay: number
): T {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const callbackRef = useRef(callback);
  callbackRef.current = callback;

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  return useCallback(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (...args: any[]) => {
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        callbackRef.current(...args);
      }, delay);
    },
    [delay]
  ) as unknown as T;
}

// ---------------------------------------------------------------------------
// ExpressionEditor component
// ---------------------------------------------------------------------------

/**
 * 3-tab expression editor with String, Dict, and Visual views.
 *
 * - **String**: Monaco CodeEditor — edit text, debounced parse (300ms).
 * - **Dict**: Read-only JSON view of the last valid graph dict.
 * - **Visual**: React Flow GraphEditor — renders + allows node deletion.
 *
 * State model:
 * - `value` (draftString) is the source of truth for the String tab.
 * - When `value` is valid: graphDict updates, Dict/Visual tabs reflect it.
 * - When `value` is invalid: graphDict keeps the last good state,
 *   Dict/Visual tabs show stale data with an error badge.
 * - Visual tab edits update graphDict → canonical string → value.
 * - Dict tab is read-only.
 */
export default function ExpressionEditor({
  value,
  graphDict,
  onChange,
  error: externalError,
  features,
  functions,
}: ExpressionEditorProps) {
  const [activeTab, setActiveTab] = useState<EditorTab>("string");
  const [parseError, setParseError] = useState<string | null>(null);

  // Track programmatic updates to avoid infinite loops
  const isProgrammaticUpdate = useRef(false);

  // Debounced parse: text → graph dict
  const debouncedParse = useDebouncedCallback((text: string) => {
    if (isProgrammaticUpdate.current) return;

    const trimmed = text.trim();
    if (!trimmed) {
      setParseError(null);
      onChange("", null);
      return;
    }

    parseExpression(trimmed)
      .then((res) => {
        if (res.error) {
          setParseError(res.error);
          // Keep the text but don't update graph (last valid state preserved)
        } else if (res.graph_dict) {
          setParseError(null);
          onChange(text, res.graph_dict as unknown as GraphDictNode);
        }
      })
      .catch((err) => {
        setParseError(
          err instanceof Error ? err.message : "Failed to parse expression"
        );
      });
  }, 300);

  // Handle code editor text changes
  const handleCodeChange = useCallback(
    (newText: string) => {
      // Update text immediately (keep current graph until parse completes)
      onChange(newText, graphDict);
      if (!isProgrammaticUpdate.current) {
        debouncedParse(newText);
      }
    },
    [onChange, graphDict, debouncedParse]
  );

  // Handle graph editor changes (node deletion etc.)
  // GraphEditor returns the loose GraphDictNode from graph-utils; cast to the strict type.
  const handleGraphChange = useCallback(
    (newGraph: GraphUtilsNode) => {
      setParseError(null);
      // Convert graph back to canonical text
      isProgrammaticUpdate.current = true;
      getCanonical(newGraph as unknown as Record<string, unknown>)
        .then((res) => {
          onChange(res.canonical_string, newGraph as unknown as GraphDictNode);
        })
        .catch(() => {
          // If canonical fails, update graph but keep current text
          onChange(value, newGraph as unknown as GraphDictNode);
        })
        .finally(() => {
          isProgrammaticUpdate.current = false;
        });
    },
    [onChange, value]
  );

  // Determine display error: parse error takes priority, then external error
  const displayError = parseError || externalError || undefined;

  // Tab styles
  const tabBase =
    "px-4 py-2 text-xs font-semibold uppercase tracking-widest transition-colors duration-fast cursor-pointer";
  const tabActive = "text-status-success border-b-2 border-status-success";
  const tabInactive =
    "text-text-secondary border-b-2 border-transparent hover:text-text-primary";

  return (
    <div className="flex flex-col" style={{ minHeight: "380px" }}>
      {/* Tab bar */}
      <div className="flex border-b border-border-subtle bg-bg-secondary">
        <button
          type="button"
          className={`${tabBase} ${activeTab === "string" ? tabActive : tabInactive}`}
          onClick={() => setActiveTab("string")}
        >
          String
        </button>
        <button
          type="button"
          className={`${tabBase} ${activeTab === "dict" ? tabActive : tabInactive}`}
          onClick={() => setActiveTab("dict")}
        >
          Dict
          {parseError && (
            <span className="ml-1.5 inline-block w-1.5 h-1.5 rounded-full bg-status-warning" />
          )}
        </button>
        <button
          type="button"
          className={`${tabBase} ${activeTab === "visual" ? tabActive : tabInactive}`}
          onClick={() => setActiveTab("visual")}
        >
          Visual
          {parseError && (
            <span className="ml-1.5 inline-block w-1.5 h-1.5 rounded-full bg-status-warning" />
          )}
        </button>
      </div>

      {/* Tab content — use absolute positioning so non-active tabs
          remain in the DOM with real dimensions (React Flow needs this). */}
      <div className="flex-1 min-h-0 relative" style={{ minHeight: "320px" }}>
        {/* String tab */}
        <div
          className="absolute inset-0 p-4 overflow-auto"
          style={{
            visibility: activeTab === "string" ? "visible" : "hidden",
            zIndex: activeTab === "string" ? 1 : 0,
          }}
        >
          <ErrorBoundary label="Code Editor">
            <CodeEditor
              value={value}
              onChange={handleCodeChange}
              error={displayError}
              height="260px"
              features={features}
              functions={functions}
            />
          </ErrorBoundary>
        </div>

        {/* Dict tab (read-only JSON) */}
        <div
          className="absolute inset-0 p-4 overflow-auto"
          style={{
            visibility: activeTab === "dict" ? "visible" : "hidden",
            zIndex: activeTab === "dict" ? 1 : 0,
          }}
        >
          {parseError && (
            <div className="mb-2 px-3 py-1.5 bg-status-warning/10 border border-status-warning/30 rounded-sm">
              <span className="text-xs text-status-warning">
                Showing last valid graph — current text has errors
              </span>
            </div>
          )}
          <div className="bg-bg-primary border border-border-subtle rounded-md p-3 overflow-auto max-h-[300px]">
            <pre className="text-xs text-text-secondary font-mono whitespace-pre-wrap">
              {graphDict
                ? JSON.stringify(graphDict, null, 2)
                : "// No valid graph dict yet. Type an expression in the String tab."}
            </pre>
          </div>
        </div>

        {/* Visual tab */}
        <div
          className="absolute inset-0"
          style={{
            visibility: activeTab === "visual" ? "visible" : "hidden",
            zIndex: activeTab === "visual" ? 1 : 0,
          }}
        >
          {parseError && (
            <div className="mx-4 mt-2 mb-1 px-3 py-1.5 bg-status-warning/10 border border-status-warning/30 rounded-sm relative z-10">
              <span className="text-xs text-status-warning">
                Showing last valid graph — current text has errors
              </span>
            </div>
          )}
          <ErrorBoundary label="Graph Editor">
            <GraphEditor graphDict={graphDict} onChange={handleGraphChange} />
          </ErrorBoundary>
        </div>
      </div>
    </div>
  );
}
