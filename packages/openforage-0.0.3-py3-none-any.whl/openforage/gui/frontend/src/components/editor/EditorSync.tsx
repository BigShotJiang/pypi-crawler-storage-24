"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import CodeEditor from "./CodeEditor";
import { parseExpression, getCanonical } from "@/lib/api";
import type { GraphDictNode } from "@/lib/graph-utils";

// Lazy-load GraphEditor (depends on React Flow which needs browser APIs)
const GraphEditor = dynamic(() => import("./GraphEditor"), {
  ssr: false,
  loading: () => (
    <div
      className="w-full h-full flex items-center justify-center"
      style={{ background: "#0a0a0a" }}
    >
      <span className="text-text-secondary text-xs">Loading graph editor...</span>
    </div>
  ),
});

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type ActiveEditor = "code" | "graph";

interface EditorSyncProps {
  /** Initial graph dict to populate both editors. */
  initialGraphDict?: GraphDictNode | null;
  /** Called when the graph changes from either editor. */
  onGraphChange?: (graph: GraphDictNode | null) => void;
}

// ---------------------------------------------------------------------------
// Debounce helper
// ---------------------------------------------------------------------------

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function useDebouncedCallback<T extends (...args: any[]) => void>(
  callback: T,
  delay: number
): T {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const callbackRef = useRef(callback);
  callbackRef.current = callback;

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  return useCallback(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (...args: any[]) => {
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        callbackRef.current(...args);
      }, delay);
    },
    [delay]
  ) as unknown as T;
}

// ---------------------------------------------------------------------------
// EditorSync component
// ---------------------------------------------------------------------------

/**
 * Bidirectional sync between a text code editor and a visual graph editor.
 *
 * - When the user edits code: debounce 300ms, call POST /api/graph/parse,
 *   update the graph if valid, show inline error if invalid.
 * - When the user modifies the graph: call POST /api/graph/canonical,
 *   update the code text.
 * - Tab switching between "Code" and "Graph" views.
 */
export default function EditorSync({
  initialGraphDict = null,
  onGraphChange,
}: EditorSyncProps) {
  const [graphDict, setGraphDict] = useState<GraphDictNode | null>(
    initialGraphDict
  );
  const [codeText, setCodeText] = useState("");
  const [parseError, setParseError] = useState<string | undefined>(undefined);
  const [activeEditor, setActiveEditor] = useState<ActiveEditor>("code");

  // Track whether we are programmatically updating code/graph to avoid loops
  const isProgrammaticUpdate = useRef(false);

  // Initialize code text from initial graph dict
  useEffect(() => {
    if (initialGraphDict) {
      isProgrammaticUpdate.current = true;
      getCanonical(initialGraphDict as unknown as Record<string, unknown>)
        .then((res) => {
          setCodeText(res.canonical_string);
        })
        .catch(() => {
          // If canonical fails, leave code empty
        })
        .finally(() => {
          isProgrammaticUpdate.current = false;
        });
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Notify parent when graph changes
  useEffect(() => {
    onGraphChange?.(graphDict);
  }, [graphDict, onGraphChange]);

  // Debounced parse: code text -> graph dict
  const debouncedParse = useDebouncedCallback((text: string) => {
    if (isProgrammaticUpdate.current) return;

    const trimmed = (text as string).trim();
    if (!trimmed) {
      setGraphDict(null);
      setParseError(undefined);
      return;
    }

    parseExpression(trimmed)
      .then((res) => {
        if (res.error) {
          setParseError(res.error);
        } else if (res.graph_dict) {
          setParseError(undefined);
          setGraphDict(res.graph_dict as unknown as GraphDictNode);
        }
      })
      .catch((err) => {
        setParseError(
          err instanceof Error ? err.message : "Failed to parse expression"
        );
      });
  }, 300);

  // Handle code editor changes
  const handleCodeChange = useCallback(
    (value: string) => {
      setCodeText(value);
      if (!isProgrammaticUpdate.current) {
        debouncedParse(value);
      }
    },
    [debouncedParse]
  );

  // Handle graph editor changes
  const handleGraphChange = useCallback((newGraph: GraphDictNode) => {
    setGraphDict(newGraph);
    setParseError(undefined);

    // Convert graph back to code text
    isProgrammaticUpdate.current = true;
    getCanonical(newGraph as unknown as Record<string, unknown>)
      .then((res) => {
        setCodeText(res.canonical_string);
      })
      .catch(() => {
        // If canonical fails, keep current text
      })
      .finally(() => {
        isProgrammaticUpdate.current = false;
      });
  }, []);

  // Tab styles
  const tabBase =
    "px-4 py-2 text-xs font-semibold uppercase tracking-widest transition-colors duration-fast cursor-pointer";
  const tabActive = "text-status-success border-b-2 border-status-success";
  const tabInactive =
    "text-text-secondary border-b-2 border-transparent hover:text-text-primary";

  return (
    <div className="flex flex-col h-full">
      {/* Tab bar */}
      <div className="flex border-b border-border-subtle bg-bg-secondary">
        <button
          type="button"
          className={`${tabBase} ${activeEditor === "code" ? tabActive : tabInactive}`}
          onClick={() => setActiveEditor("code")}
        >
          Code
        </button>
        <button
          type="button"
          className={`${tabBase} ${activeEditor === "graph" ? tabActive : tabInactive}`}
          onClick={() => setActiveEditor("graph")}
        >
          Graph
        </button>
      </div>

      {/* Editor content */}
      <div className="flex-1 min-h-0">
        {activeEditor === "code" ? (
          <div className="h-full p-4">
            <CodeEditor
              value={codeText}
              onChange={handleCodeChange}
              error={parseError}
              height="100%"
            />
          </div>
        ) : (
          <div className="h-full" style={{ minHeight: "400px" }}>
            <GraphEditor
              graphDict={graphDict}
              onChange={handleGraphChange}
            />
          </div>
        )}
      </div>
    </div>
  );
}
