"use client";

import {
  useCallback,
  useMemo,
  type ComponentType,
  type CSSProperties,
} from "react";
import dynamic from "next/dynamic";
import "reactflow/dist/style.css";
import { Handle, Position } from "reactflow";
import type { GraphDictNode } from "@/lib/graph-utils";
import { graphDictToFlow, flowToGraphDict } from "@/lib/graph-utils";

// ---------------------------------------------------------------------------
// Lazy-load React Flow (uses browser APIs, cannot SSR)
// ---------------------------------------------------------------------------

const ReactFlowProvider = dynamic(
  () => import("reactflow").then((mod) => mod.ReactFlowProvider),
  { ssr: false }
);

const ReactFlowComponent = dynamic(
  () => import("reactflow").then((mod) => mod.default),
  { ssr: false }
);

const Background = dynamic(
  () => import("reactflow").then((mod) => mod.Background),
  { ssr: false }
);

const Controls = dynamic(
  () => import("reactflow").then((mod) => mod.Controls),
  { ssr: false }
);

// ---------------------------------------------------------------------------
// Node color mapping
// ---------------------------------------------------------------------------

const NODE_COLORS: Record<string, string> = {
  rotation: "#4ade80",
  filtration: "#fbbf24",
  feature: "#60a5fa",
  aggregation: "#c084fc",
  int: "#a3a3a3",
  float: "#a3a3a3",
  string: "#a3a3a3",
  bool: "#a3a3a3",
};

const NODE_TYPE_LABELS: Record<string, string> = {
  rotation: "ROT",
  filtration: "FIL",
  feature: "FEA",
  aggregation: "AGG",
  int: "INT",
  float: "FLT",
  string: "STR",
  bool: "BOL",
};

// ---------------------------------------------------------------------------
// Custom node component factory
// ---------------------------------------------------------------------------

interface CustomNodeData {
  label: string;
  graphType: string;
}

interface NodeProps {
  data: CustomNodeData;
  selected?: boolean;
}

function makeCustomNode(defaultType: string): ComponentType<NodeProps> {
  function CustomNode({ data, selected }: NodeProps) {
    const graphType = data.graphType || defaultType;
    const borderColor = NODE_COLORS[graphType] ?? "#525252";
    const typeLabel = NODE_TYPE_LABELS[graphType] ?? graphType.toUpperCase().slice(0, 3);

    const style: CSSProperties = {
      background: "#171717",
      border: `2px solid ${selected ? "#fafafa" : borderColor}`,
      borderRadius: "8px",
      padding: "8px 14px",
      minWidth: "140px",
      display: "flex",
      alignItems: "center",
      gap: "8px",
      fontFamily: "'JetBrains Mono', monospace",
      transition: "border-color 100ms ease",
    };

    const badgeStyle: CSSProperties = {
      background: `${borderColor}22`,
      color: borderColor,
      fontSize: "9px",
      fontWeight: 600,
      letterSpacing: "0.05em",
      padding: "2px 6px",
      borderRadius: "4px",
      textTransform: "uppercase",
      flexShrink: 0,
    };

    const labelStyle: CSSProperties = {
      color: "#fafafa",
      fontSize: "12px",
      fontWeight: 500,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
    };

    const handleStyle: CSSProperties = {
      background: borderColor,
      border: "none",
      width: "8px",
      height: "8px",
    };

    return (
      <div style={style}>
        <Handle type="target" position={Position.Top} style={handleStyle} />
        <span style={badgeStyle}>{typeLabel}</span>
        <span style={labelStyle}>{data.label}</span>
        <Handle type="source" position={Position.Bottom} style={handleStyle} />
      </div>
    );
  }

  CustomNode.displayName = `${defaultType}Node`;
  return CustomNode;
}

// ---------------------------------------------------------------------------
// Node type registry
// ---------------------------------------------------------------------------

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const nodeTypes: Record<string, ComponentType<any>> = {
  rotationNode: makeCustomNode("rotation"),
  filtrationNode: makeCustomNode("filtration"),
  featureNode: makeCustomNode("feature"),
  aggregationNode: makeCustomNode("aggregation"),
  literalNode: makeCustomNode("int"),
};

// ---------------------------------------------------------------------------
// GraphEditor component
// ---------------------------------------------------------------------------

interface GraphEditorProps {
  graphDict: GraphDictNode | null;
  onChange?: (newGraph: GraphDictNode) => void;
}

function GraphEditorInner({ graphDict, onChange }: GraphEditorProps) {
  const { nodes, edges } = useMemo(() => {
    if (!graphDict) return { nodes: [], edges: [] };
    return graphDictToFlow(graphDict);
  }, [graphDict]);

  const onNodesDelete = useCallback(
    (deleted: Array<{ id: string }>) => {
      if (!onChange || !graphDict) return;

      // Remove the deleted node IDs from the flow and rebuild
      const deletedIds = new Set(deleted.map((n) => n.id));
      const remainingNodes = nodes.filter((n) => !deletedIds.has(n.id));
      const remainingEdges = edges.filter(
        (e) => !deletedIds.has(e.source) && !deletedIds.has(e.target)
      );

      if (remainingNodes.length === 0) return;

      const newGraph = flowToGraphDict(remainingNodes, remainingEdges);
      if (newGraph) onChange(newGraph);
    },
    [onChange, graphDict, nodes, edges]
  );

  if (!graphDict) {
    return (
      <div
        className="w-full h-full flex items-center justify-center"
        style={{ background: "#0a0a0a" }}
      >
        <span
          style={{
            color: "#a3a3a3",
            fontSize: "13px",
            fontFamily: "'JetBrains Mono', monospace",
          }}
        >
          Enter an expression in the Code tab to see the graph
        </span>
      </div>
    );
  }

  return (
    <div style={{ width: "100%", height: "100%" }}>
      <ReactFlowComponent
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        onNodesDelete={onNodesDelete}
        fitView
        fitViewOptions={{ padding: 0.3 }}
        proOptions={{ hideAttribution: true }}
        style={{ background: "#0a0a0a" }}
        defaultEdgeOptions={{
          type: "smoothstep",
          style: { stroke: "#525252", strokeWidth: 2 },
        }}
      >
        <Background color="#262626" gap={20} size={1} />
        <Controls
          showInteractive={false}
          style={{
            background: "#171717",
            border: "1px solid #262626",
            borderRadius: "8px",
          }}
        />
      </ReactFlowComponent>
    </div>
  );
}

/**
 * Visual graph editor for expression trees.
 *
 * Renders the graph dict as positioned nodes with colored borders
 * per type.  Lazy-loaded to avoid SSR issues with React Flow.
 */
export default function GraphEditor(props: GraphEditorProps) {
  return (
    <ReactFlowProvider>
      <GraphEditorInner {...props} />
    </ReactFlowProvider>
  );
}
