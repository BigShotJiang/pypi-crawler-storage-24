"use client";

import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import { AlertCircle } from "lucide-react";
import {
  registerOpenForageLanguage,
  LANGUAGE_ID,
} from "@/lib/monaco-openforage";
import type { FunctionDef } from "@/lib/types";

const MonacoEditor = dynamic(() => import("@monaco-editor/react"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-64 bg-bg-secondary rounded-md border border-border-subtle flex items-center justify-center">
      <span className="text-text-secondary text-xs">Loading editor...</span>
    </div>
  ),
});

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
  height?: string;
  features?: string[];
  functions?: FunctionDef[];
}

export default function CodeEditor({
  value,
  onChange,
  error,
  height = "300px",
  features,
  functions,
}: CodeEditorProps) {
  const hasLanguageData = !!(features && features.length > 0);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const monacoRef = useRef<any>(null);

  // Re-register language when features/functions data arrives or changes
  useEffect(() => {
    if (monacoRef.current && hasLanguageData) {
      registerOpenForageLanguage(monacoRef.current, {
        features: features || [],
        functions: functions || [],
      });
    }
  }, [features, functions, hasLanguageData]);

  return (
    <div className="flex flex-col gap-2">
      <div
        className={`
          rounded-md overflow-hidden border
          ${error ? "border-status-error" : "border-border-subtle"}
        `}
      >
        <MonacoEditor
          height={height}
          language={hasLanguageData ? LANGUAGE_ID : "plaintext"}
          theme="of-dark"
          value={value}
          onChange={(val) => onChange(val || "")}
          beforeMount={(monaco) => {
            monacoRef.current = monaco;

            monaco.editor.defineTheme("of-dark", {
              base: "vs-dark",
              inherit: true,
              rules: [
                { token: "", foreground: "fafafa", background: "0a0a0a" },
                { token: "comment", foreground: "a3a3a3" },
                { token: "keyword", foreground: "4ade80" },
                { token: "string", foreground: "fbbf24" },
                { token: "number", foreground: "4ade80" },
                { token: "feature", foreground: "60a5fa" },
                {
                  token: "function-name",
                  foreground: "4ade80",
                  fontStyle: "bold",
                },
                { token: "identifier", foreground: "fafafa" },
                { token: "delimiter", foreground: "a3a3a3" },
                { token: "operator", foreground: "a3a3a3" },
              ],
              colors: {
                "editor.background": "#0a0a0a",
                "editor.foreground": "#fafafa",
                "editorCursor.foreground": "#4ade80",
                "editor.lineHighlightBackground": "#171717",
                "editorLineNumber.foreground": "#525252",
                "editorLineNumber.activeForeground": "#a3a3a3",
                "editor.selectionBackground": "#4ade8033",
                "editor.inactiveSelectionBackground": "#4ade8015",
                "editorWidget.background": "#171717",
                "editorWidget.border": "#262626",
                "editorSuggestWidget.background": "#171717",
                "editorSuggestWidget.border": "#262626",
                "editorSuggestWidget.foreground": "#fafafa",
                "editorSuggestWidget.selectedBackground": "#4ade8022",
                "editorSuggestWidget.highlightForeground": "#4ade80",
                "input.background": "#171717",
                "input.foreground": "#fafafa",
                "input.border": "#262626",
                "scrollbarSlider.background": "#52525233",
                "scrollbarSlider.hoverBackground": "#52525266",
                "scrollbarSlider.activeBackground": "#52525299",
              },
            });

            // Register immediately if data is already available
            if (hasLanguageData) {
              registerOpenForageLanguage(monaco, {
                features: features || [],
                functions: functions || [],
              });
            }
          }}
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            fontFamily: "'JetBrains Mono', monospace",
            wordWrap: "on",
            scrollBeyondLastLine: false,
            lineNumbers: "on",
            glyphMargin: false,
            folding: false,
            lineDecorationsWidth: 0,
            lineNumbersMinChars: 3,
            renderLineHighlight: "line",
            overviewRulerBorder: false,
            hideCursorInOverviewRuler: true,
            padding: { top: 12, bottom: 12 },
            scrollbar: {
              verticalScrollbarSize: 8,
              horizontalScrollbarSize: 8,
            },
            quickSuggestions: true,
            suggestOnTriggerCharacters: true,
          }}
        />
      </div>

      {error && (
        <div className="flex items-start gap-2 px-3 py-2 bg-status-error/10 border border-status-error/30 rounded-sm">
          <AlertCircle className="w-4 h-4 text-status-error mt-0.5 flex-shrink-0" />
          <span className="text-xs text-status-error">{error}</span>
        </div>
      )}
    </div>
  );
}
