"use client";

import { Settings } from "lucide-react";
import type { EraConfig } from "@/lib/types";

interface ConfigPanelProps {
  eraConfig: EraConfig | null;
}

function SkeletonRow() {
  return (
    <div className="flex items-center justify-between py-1.5">
      <div className="h-3 w-24 bg-bg-tertiary rounded-sm animate-pulse" />
      <div className="h-3 w-16 bg-bg-tertiary rounded-sm animate-pulse" />
    </div>
  );
}

export default function ConfigPanel({ eraConfig }: ConfigPanelProps) {
  return (
    <div className="bg-bg-secondary border border-border-subtle rounded-md p-4">
      <div className="flex items-center gap-2 mb-3">
        <Settings className="w-4 h-4 text-text-secondary" />
        <h3 className="text-xs font-semibold uppercase tracking-widest text-text-secondary">
          Era Config
        </h3>
      </div>

      {eraConfig === null ? (
        <div className="space-y-2">
          <SkeletonRow />
          <SkeletonRow />
          <SkeletonRow />
          <SkeletonRow />
        </div>
      ) : (
        <div className="space-y-1">
          <ConfigRow label="Era ID" value={eraConfig.era_id} />
          <ConfigRow label="Universe" value={eraConfig.universe_id} />
          <ConfigRow label="Universe Size" value={String(eraConfig.universe_size)} />
          <ConfigRow label="Buffer" value={String(eraConfig.buffer)} />
          {Object.entries(eraConfig.metaparameters).map(([key, val]) => (
            <ConfigRow
              key={key}
              label={key}
              value={typeof val === "object" ? JSON.stringify(val) : String(val)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function ConfigRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-1 px-1 rounded-sm hover:bg-bg-tertiary transition-colors duration-fast">
      <span className="text-xs text-text-secondary">{label}</span>
      <span className="text-xs text-text-primary font-medium">{value}</span>
    </div>
  );
}
