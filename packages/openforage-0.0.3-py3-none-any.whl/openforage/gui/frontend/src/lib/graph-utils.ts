/**
 * Utilities for converting between graph dict and React Flow nodes/edges.
 *
 * The graph dict is a tree structure produced by the backend parser:
 *   { type, node, children? }
 *
 * React Flow needs flat arrays of nodes (with positions) and edges.
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface GraphDictNode {
  type: string;
  node: string;
  children?: GraphDictNode[];
}

export interface FlowNodeData {
  label: string;
  graphType: string;
}

export interface FlowNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  data: FlowNodeData;
}

export interface FlowEdge {
  id: string;
  source: string;
  target: string;
  type?: string;
  animated?: boolean;
}

// ---------------------------------------------------------------------------
// Layout constants
// ---------------------------------------------------------------------------

const NODE_WIDTH = 180;
const NODE_HEIGHT = 50;
const HORIZONTAL_GAP = 40;
const VERTICAL_GAP = 80;

// ---------------------------------------------------------------------------
// Graph dict type to React Flow node type mapping
// ---------------------------------------------------------------------------

/** Map graph dict types to custom React Flow node type names. */
function flowNodeType(graphType: string): string {
  switch (graphType) {
    case "rotation":
      return "rotationNode";
    case "filtration":
      return "filtrationNode";
    case "feature":
      return "featureNode";
    case "aggregation":
      return "aggregationNode";
    case "int":
    case "float":
    case "string":
    case "bool":
      return "literalNode";
    default:
      return "rotationNode";
  }
}

// ---------------------------------------------------------------------------
// Tree measurement (needed for positioning)
// ---------------------------------------------------------------------------

interface TreeMeasure {
  width: number;
  height: number;
  childWidths: number[];
}

/** Recursively measure the width/height of a subtree. */
function measureTree(node: GraphDictNode): TreeMeasure {
  const children = node.children ?? [];
  if (children.length === 0) {
    return { width: NODE_WIDTH, height: NODE_HEIGHT, childWidths: [] };
  }

  const childMeasures = children.map(measureTree);
  const childWidths = childMeasures.map((m) => m.width);
  const totalChildWidth =
    childWidths.reduce((sum, w) => sum + w, 0) +
    HORIZONTAL_GAP * (children.length - 1);
  const maxChildHeight = Math.max(...childMeasures.map((m) => m.height));

  return {
    width: Math.max(NODE_WIDTH, totalChildWidth),
    height: NODE_HEIGHT + VERTICAL_GAP + maxChildHeight,
    childWidths,
  };
}

// ---------------------------------------------------------------------------
// graphDictToFlow
// ---------------------------------------------------------------------------

let _idCounter = 0;

function resetIdCounter(): void {
  _idCounter = 0;
}

function nextId(): string {
  return `node-${_idCounter++}`;
}

/**
 * Convert a graph dict tree into React Flow nodes and edges.
 *
 * The tree is laid out top-down: the root is at the top center,
 * children are positioned below, evenly distributed.
 */
export function graphDictToFlow(graph: GraphDictNode): {
  nodes: FlowNode[];
  edges: FlowEdge[];
} {
  resetIdCounter();
  const nodes: FlowNode[] = [];
  const edges: FlowEdge[] = [];

  const measure = measureTree(graph);

  function traverse(
    dictNode: GraphDictNode,
    centerX: number,
    topY: number
  ): string {
    const id = nextId();

    nodes.push({
      id,
      type: flowNodeType(dictNode.type),
      position: {
        x: centerX - NODE_WIDTH / 2,
        y: topY,
      },
      data: {
        label: dictNode.node,
        graphType: dictNode.type,
      },
    });

    const children = dictNode.children ?? [];
    if (children.length > 0) {
      const childMeasures = children.map(measureTree);
      const childWidths = childMeasures.map((m) => m.width);
      const totalChildWidth =
        childWidths.reduce((sum, w) => sum + w, 0) +
        HORIZONTAL_GAP * (children.length - 1);

      let childX = centerX - totalChildWidth / 2;
      const childY = topY + NODE_HEIGHT + VERTICAL_GAP;

      for (let i = 0; i < children.length; i++) {
        const childCenterX = childX + childWidths[i] / 2;
        const childId = traverse(children[i], childCenterX, childY);

        edges.push({
          id: `edge-${id}-${childId}`,
          source: id,
          target: childId,
          type: "smoothstep",
          animated: false,
        });

        childX += childWidths[i] + HORIZONTAL_GAP;
      }
    }

    return id;
  }

  traverse(graph, measure.width / 2, 0);

  return { nodes, edges };
}

// ---------------------------------------------------------------------------
// flowToGraphDict
// ---------------------------------------------------------------------------

/**
 * Convert React Flow nodes and edges back into a graph dict tree.
 *
 * Finds the root node (node with no incoming edges) and reconstructs
 * the tree by following outgoing edges.
 */
export function flowToGraphDict(
  nodes: FlowNode[],
  edges: FlowEdge[]
): GraphDictNode | null {
  if (nodes.length === 0) return null;

  // Build adjacency: parent -> children (ordered by x-position)
  const childMap = new Map<string, string[]>();
  const hasParent = new Set<string>();

  for (const edge of edges) {
    const existing = childMap.get(edge.source) ?? [];
    existing.push(edge.target);
    childMap.set(edge.source, existing);
    hasParent.add(edge.target);
  }

  // Find root: node with no incoming edge
  const rootNode = nodes.find((n) => !hasParent.has(n.id));
  if (!rootNode) return null;

  const nodeMap = new Map(nodes.map((n) => [n.id, n]));

  function buildDict(nodeId: string): GraphDictNode | null {
    const flowNode = nodeMap.get(nodeId);
    if (!flowNode) return null;

    const childIds = childMap.get(nodeId) ?? [];

    // Sort children by x-position (left to right) to preserve argument order
    const sortedChildIds = [...childIds].sort((a, b) => {
      const na = nodeMap.get(a);
      const nb = nodeMap.get(b);
      if (!na || !nb) return 0;
      return na.position.x - nb.position.x;
    });

    const graphType = flowNode.data.graphType;
    const label = flowNode.data.label;

    if (sortedChildIds.length === 0) {
      return { type: graphType, node: label };
    }

    const children = sortedChildIds
      .map(buildDict)
      .filter((c): c is GraphDictNode => c !== null);

    return { type: graphType, node: label, children };
  }

  return buildDict(rootNode.id);
}
