/**
 * TypeScript type definitions matching the backend Pydantic schemas.
 */

// ---------------------------------------------------------------------------
// Expression types
// ---------------------------------------------------------------------------

export interface ExpressionCreate {
  canonical_string: string;
  graph_dict: GraphDict;
  expression_type: string;
  name?: string;
  tags?: string[];
  era_id: string;
  era_config?: Record<string, unknown>;
}

export interface Expression {
  id: string;
  canonical_string: string;
  graph_dict: GraphDict;
  expression_type: string;
  name?: string;
  tags?: string[];
  era_id: string;
  era_config?: Record<string, unknown>;
  created_at: string;
}

// ---------------------------------------------------------------------------
// Backtest types
// ---------------------------------------------------------------------------

export interface BacktestRunRequest {
  graph_dict: GraphDict;
  era_id: string;
}

export interface BacktestJob {
  id: string;
  status: "pending" | "running" | "completed" | "failed" | "cancelled";
  progress: number;
  error?: string;
  created_at: string;
  started_at?: string;
  completed_at?: string;
}

export interface BacktestResult {
  id: string;
  job_id: string;
  expression_id?: string;
  statistics: Record<string, number>;
  per_column_stats?: Record<string, Record<string, number>>;
  threshold_results?: Record<
    string,
    { value: number; threshold: number; passed: boolean }
  >;
  correlation_score?: number;
  pnl_matrix: PnLData;
  created_at: string;
}

// ---------------------------------------------------------------------------
// Graph types
// ---------------------------------------------------------------------------

/**
 * Graph dict node — the canonical expression format.
 * Leaf types: feature, aggregation, float, int, string, bool (no children).
 * Function types: rotation, filtration, reduction (have children).
 * The `node` field holds the function name or leaf value.
 */
export interface GraphDictNode {
  type: "rotation" | "filtration" | "reduction" | "feature" | "aggregation" | "float" | "int" | "string" | "bool";
  node: string;
  children?: GraphDictNode[];
}

export type GraphDict = GraphDictNode | Record<string, unknown>;

export interface GraphValidateResponse {
  valid: boolean;
  error?: string;
}

export interface GraphParseResponse {
  graph_dict?: GraphDict;
  error?: string;
}

export interface GraphCanonicalResponse {
  canonical_string: string;
}

// ---------------------------------------------------------------------------
// Era / config types
// ---------------------------------------------------------------------------

export interface EraConfig {
  era_id: string;
  universe_id: string;
  universe_size: number;
  buffer: number;
  metaparameters: Record<string, unknown>;
}

export interface FeatureListResponse {
  features: string[];
}

export interface FunctionDef {
  name: string;
  category: string;
  params: Record<string, unknown>;
  [key: string]: unknown;
}

export interface FunctionListResponse {
  functions: FunctionDef[];
}

// ---------------------------------------------------------------------------
// PnL types
// ---------------------------------------------------------------------------

export interface PnLData {
  dates: string[];
  cumulative_pnl: number[];
  daily_returns?: number[];
  timestamps?: string[];
  values?: number[][];
  columns?: string[];
}

// ---------------------------------------------------------------------------
// WebSocket types
// ---------------------------------------------------------------------------

export interface WebSocketProgressMessage {
  job_id: string;
  status: string;
  progress: number;
  error?: string;
}

// ---------------------------------------------------------------------------
// UI state types
// ---------------------------------------------------------------------------

export interface TabItem {
  id: string;
  label: string;
}

export type JobStatus = "idle" | "pending" | "running" | "completed" | "failed" | "cancelled";
