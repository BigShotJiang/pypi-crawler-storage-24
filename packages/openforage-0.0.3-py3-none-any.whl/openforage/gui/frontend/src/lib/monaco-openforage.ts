/**
 * Monaco language configuration for OpenForage expressions.
 *
 * Registers a custom language with:
 * - Monarch tokenizer (features, functions, numbers, strings, operators)
 * - CompletionItemProvider (feature + function completions with rich detail)
 */

import type * as Monaco from "monaco-editor";

export const LANGUAGE_ID = "openforage-expression";

export interface OpenForageLanguageData {
  features: string[];
  functions: Array<{
    name: string;
    category: string;
    params: Record<string, unknown>;
  }>;
}

let languageRegistered = false;
let completionDisposable: Monaco.IDisposable | null = null;

/**
 * Register (or update) the OpenForage expression language in Monaco.
 *
 * Safe to call multiple times — language ID is registered once,
 * tokenizer and completions are replaced on each call.
 */
export function registerOpenForageLanguage(
  monaco: typeof Monaco,
  data: OpenForageLanguageData
): void {
  if (!languageRegistered) {
    monaco.languages.register({ id: LANGUAGE_ID });
    languageRegistered = true;
  }

  const featureNames = data.features;
  const functionNames = data.functions.map((f) => f.name);

  // Monarch tokenizer with dynamic token lists
  monaco.languages.setMonarchTokensProvider(LANGUAGE_ID, {
    features: featureNames,
    functions: functionNames,
    tokenizer: {
      root: [
        // Numbers (int and float)
        [/\d+(\.\d+)?/, "number"],
        // Double-quoted strings (with escape support)
        [/"(?:[^"\\]|\\.)*"/, "string"],
        // Parentheses and commas
        [/[(),]/, "delimiter"],
        // Operators
        [/[+\-*/=<>!]+/, "operator"],
        // Identifiers — classified by membership in feature/function lists
        [
          /[a-zA-Z_]\w*/,
          {
            cases: {
              "@features": "feature",
              "@functions": "function-name",
              "@default": "identifier",
            },
          },
        ],
      ],
    },
  } as Monaco.languages.IMonarchLanguage);

  // Dispose previous completion provider if updating
  if (completionDisposable) {
    completionDisposable.dispose();
  }

  completionDisposable = monaco.languages.registerCompletionItemProvider(
    LANGUAGE_ID,
    {
      provideCompletionItems: (model, position) => {
        const word = model.getWordUntilPosition(position);
        const range = {
          startLineNumber: position.lineNumber,
          endLineNumber: position.lineNumber,
          startColumn: word.startColumn,
          endColumn: word.endColumn,
        };

        const featureSuggestions: Monaco.languages.CompletionItem[] =
          data.features.map((name) => ({
            label: name,
            kind: monaco.languages.CompletionItemKind.Field,
            insertText: name,
            range,
            detail: "feature",
            documentation: `Feature: ${name}`,
          }));

        const functionSuggestions: Monaco.languages.CompletionItem[] =
          data.functions.map((fn) => {
            const paramEntries = Object.entries(fn.params || {});

            // Snippet with tab stops for each parameter
            const paramSnippet =
              paramEntries.length > 0
                ? paramEntries
                    .map(([pName, pMeta], i) => {
                      const meta = pMeta as { default?: unknown };
                      const defaultVal =
                        meta?.default !== undefined
                          ? String(meta.default)
                          : pName;
                      return `\${${i + 1}:${defaultVal}}`;
                    })
                    .join(", ")
                : "$1";

            // Human-readable parameter info
            const paramInfo = paramEntries
              .map(([pName, pMeta]) => {
                const meta = pMeta as { type?: string; default?: unknown };
                let info = pName;
                if (meta?.type) info += `: ${meta.type}`;
                if (meta?.default !== undefined) info += ` = ${meta.default}`;
                return info;
              })
              .join(", ");

            return {
              label: fn.name,
              kind: monaco.languages.CompletionItemKind.Function,
              insertText: `${fn.name}(${paramSnippet})`,
              insertTextRules:
                monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              range,
              detail: `${fn.category}(${paramInfo})`,
              documentation: `${fn.category} function: ${fn.name}(${paramInfo})`,
            };
          });

        return {
          suggestions: [...featureSuggestions, ...functionSuggestions],
        };
      },
    }
  );
}
