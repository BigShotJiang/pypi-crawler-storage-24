/**
 * API client for the simulator GUI backend.
 * All functions use fetch with proper error handling and return typed responses.
 */

import type {
  BacktestJob,
  BacktestResult,
  Expression,
  ExpressionCreate,
  EraConfig,
  FeatureListResponse,
  FunctionListResponse,
  GraphDict,
  GraphValidateResponse,
  GraphParseResponse,
  GraphCanonicalResponse,
} from "./types";

// In dev, Next.js rewrites /api/* → backend (see next.config.mjs).
// API_BASE is empty so fetch("/api/...") goes through the proxy.
// In production or when NEXT_PUBLIC_API_URL is set, use the explicit URL.
const API_BASE = process.env.NEXT_PUBLIC_API_URL || "";

// WebSocket cannot be proxied through Next.js rewrites, so we connect
// directly to the backend. Default to localhost:8000 for local dev.
const WS_BASE =
  process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:8000";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

async function request<T>(
  path: string,
  options?: RequestInit
): Promise<T> {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options?.headers || {}),
    },
    ...options,
  });

  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || body.message || JSON.stringify(body);
    } catch {
      // keep statusText
    }
    throw new ApiError(detail, res.status);
  }

  return res.json() as Promise<T>;
}

// ---------------------------------------------------------------------------
// Backtest
// ---------------------------------------------------------------------------

export async function submitBacktest(
  graph_dict: GraphDict,
  era_id: string
): Promise<BacktestJob> {
  return request<BacktestJob>("/api/backtest/run", {
    method: "POST",
    body: JSON.stringify({ graph_dict, era_id }),
  });
}

export async function getJobStatus(job_id: string): Promise<BacktestJob> {
  return request<BacktestJob>(`/api/backtest/${job_id}/status`);
}

export async function getJobResult(
  job_id: string
): Promise<BacktestResult> {
  return request<BacktestResult>(`/api/backtest/${job_id}/result`);
}

export async function cancelJob(job_id: string): Promise<BacktestJob> {
  return request<BacktestJob>(`/api/backtest/${job_id}`, {
    method: "DELETE",
  });
}

// ---------------------------------------------------------------------------
// Expressions
// ---------------------------------------------------------------------------

export async function saveExpression(
  data: ExpressionCreate
): Promise<Expression> {
  return request<Expression>("/api/expressions", {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export async function listExpressions(params?: {
  search?: string;
  era_id?: string;
  expression_type?: string;
  tags?: string;
  sort_by?: string;
  sort_order?: string;
  limit?: number;
  offset?: number;
}): Promise<Expression[]> {
  const searchParams = new URLSearchParams();
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== "") searchParams.set(key, String(value));
    });
  }
  const query = searchParams.toString();
  return request<Expression[]>(
    `/api/expressions${query ? `?${query}` : ""}`
  );
}

export async function getExpression(id: string): Promise<Expression> {
  return request<Expression>(`/api/expressions/${id}`);
}

export async function deleteExpression(id: string): Promise<void> {
  await request<void>(`/api/expressions/${id}`, { method: "DELETE" });
}

// ---------------------------------------------------------------------------
// Graph operations
// ---------------------------------------------------------------------------

export async function validateGraph(
  graph_dict: GraphDict,
  expression_type: string = "signal"
): Promise<GraphValidateResponse> {
  return request<GraphValidateResponse>("/api/graph/validate", {
    method: "POST",
    body: JSON.stringify({ graph_dict, expression_type }),
  });
}

export async function getCanonical(
  graph_dict: GraphDict
): Promise<GraphCanonicalResponse> {
  return request<GraphCanonicalResponse>("/api/graph/canonical", {
    method: "POST",
    body: JSON.stringify({ graph_dict }),
  });
}

export async function parseExpression(
  text: string
): Promise<GraphParseResponse> {
  return request<GraphParseResponse>("/api/graph/parse", {
    method: "POST",
    body: JSON.stringify({ text }),
  });
}

// ---------------------------------------------------------------------------
// Era / config
// ---------------------------------------------------------------------------

export async function getEraConfig(): Promise<EraConfig> {
  return request<EraConfig>("/api/era/current");
}

export async function getFeatures(): Promise<FeatureListResponse> {
  return request<FeatureListResponse>("/api/era/features");
}

export async function getFunctions(): Promise<FunctionListResponse> {
  return request<FunctionListResponse>("/api/era/functions");
}

// ---------------------------------------------------------------------------
// WebSocket
// ---------------------------------------------------------------------------

export function connectWebSocket(jobId: string): WebSocket {
  const ws = new WebSocket(`${WS_BASE}/ws/backtest/${jobId}`);
  return ws;
}
