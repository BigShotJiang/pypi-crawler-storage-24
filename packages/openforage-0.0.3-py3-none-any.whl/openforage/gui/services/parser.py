"""Recursive descent parser for expression text to graph dict.

Converts functional notation strings like ``latitudinal_rank(close_1h)``
into nested graph dicts suitable for the graph editor and canonical
string builder.

Grammar::

    expr     := literal | call | identifier
    call     := IDENT '(' arglist ')'
    arglist  := expr (',' expr)*
    literal  := NUMBER | STRING | BOOL
    IDENT    := [a-zA-Z_][a-zA-Z0-9_]*
    NUMBER   := [0-9]+ ('.' [0-9]+)?
    STRING   := '"' [^"]* '"'
    BOOL     := 'true' | 'false'
"""

from __future__ import annotations

import re
from typing import Any


class ParseError(Exception):
    """Raised when the expression text cannot be parsed.

    Attributes
    ----------
    message : str
        Human-readable description of the problem.
    position : int
        Zero-based character offset where the error was detected.
    """

    def __init__(self, message: str, position: int) -> None:
        self.message = message
        self.position = position
        super().__init__(f"{message} at position {position}")


# ---------------------------------------------------------------------------
# Token types
# ---------------------------------------------------------------------------

_TOKEN_IDENT = "IDENT"
_TOKEN_INT = "INT"
_TOKEN_FLOAT = "FLOAT"
_TOKEN_STRING = "STRING"
_TOKEN_BOOL = "BOOL"
_TOKEN_LPAREN = "LPAREN"
_TOKEN_RPAREN = "RPAREN"
_TOKEN_COMMA = "COMMA"
_TOKEN_EOF = "EOF"

# Feature name heuristic: identifiers containing these substrings are
# classified as features when they appear as bare identifiers (no call
# parentheses).
_FEATURE_HINTS = frozenset({
    "_1h", "_1d", "_5m", "_15m", "_4h",
    "close", "volume", "returns", "spread",
    "open_interest", "vwap", "high", "low", "open",
    "bid", "ask", "mid", "trades", "funding",
    "all_", "total_", "net_", "avg_",
})


class _Token:
    """A single lexical token."""

    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind: str, value: str, pos: int) -> None:
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self) -> str:
        return f"Token({self.kind}, {self.value!r}, pos={self.pos})"


# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------

_WHITESPACE_RE = re.compile(r"\s*")
_IDENT_RE = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")
_NUMBER_RE = re.compile(r"[0-9]+(?:\.[0-9]+)?")
_STRING_RE = re.compile(r'"(?:[^"\\]|\\.)*"')


def _tokenize(text: str) -> list[_Token]:
    """Convert *text* into a list of tokens (including a trailing EOF)."""
    tokens: list[_Token] = []
    pos = 0
    length = len(text)

    while pos < length:
        # Skip whitespace
        m = _WHITESPACE_RE.match(text, pos)
        if m and m.end() > pos:
            pos = m.end()
            if pos >= length:
                break

        ch = text[pos]

        if ch == "(":
            tokens.append(_Token(_TOKEN_LPAREN, "(", pos))
            pos += 1
        elif ch == ")":
            tokens.append(_Token(_TOKEN_RPAREN, ")", pos))
            pos += 1
        elif ch == ",":
            tokens.append(_Token(_TOKEN_COMMA, ",", pos))
            pos += 1
        elif ch == '"':
            m = _STRING_RE.match(text, pos)
            if m is None:
                raise ParseError("Unterminated string literal", pos)
            # Store the raw string content without surrounding quotes
            raw = m.group()
            # Unescape basic sequences
            inner = raw[1:-1].replace('\\"', '"').replace("\\\\", "\\")
            tokens.append(_Token(_TOKEN_STRING, inner, pos))
            pos = m.end()
        elif ch.isdigit():
            m = _NUMBER_RE.match(text, pos)
            if m is None:  # pragma: no cover — regex always matches a digit
                raise ParseError("Invalid number", pos)
            val = m.group()
            kind = _TOKEN_FLOAT if "." in val else _TOKEN_INT
            tokens.append(_Token(kind, val, pos))
            pos = m.end()
        elif ch.isalpha() or ch == "_":
            m = _IDENT_RE.match(text, pos)
            if m is None:  # pragma: no cover — regex always matches alpha/_
                raise ParseError("Invalid identifier", pos)
            val = m.group()
            if val in ("true", "false"):
                tokens.append(_Token(_TOKEN_BOOL, val, pos))
            else:
                tokens.append(_Token(_TOKEN_IDENT, val, pos))
            pos = m.end()
        else:
            raise ParseError(f"Unexpected character {ch!r}", pos)

    tokens.append(_Token(_TOKEN_EOF, "", pos))
    return tokens


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

class _Parser:
    """Recursive descent parser over a token stream."""

    def __init__(self, tokens: list[_Token]) -> None:
        self._tokens = tokens
        self._pos = 0

    def _peek(self) -> _Token:
        return self._tokens[self._pos]

    def _advance(self) -> _Token:
        tok = self._tokens[self._pos]
        self._pos += 1
        return tok

    def _expect(self, kind: str) -> _Token:
        tok = self._advance()
        if tok.kind != kind:
            raise ParseError(
                f"Expected {kind} but got {tok.kind} ({tok.value!r})",
                tok.pos,
            )
        return tok

    def parse(self) -> dict[str, Any]:
        """Parse the full expression, consuming all tokens."""
        node = self._parse_expr()
        eof = self._peek()
        if eof.kind != _TOKEN_EOF:
            raise ParseError(
                f"Unexpected token {eof.value!r} after expression",
                eof.pos,
            )
        return node

    def _parse_expr(self) -> dict[str, Any]:
        """Parse a single expression (the core recursive rule)."""
        tok = self._peek()

        if tok.kind == _TOKEN_IDENT:
            return self._parse_ident_or_call()
        if tok.kind == _TOKEN_INT:
            self._advance()
            return {"type": "int", "node": tok.value}
        if tok.kind == _TOKEN_FLOAT:
            self._advance()
            return {"type": "float", "node": tok.value}
        if tok.kind == _TOKEN_STRING:
            self._advance()
            return {"type": "string", "node": tok.value}
        if tok.kind == _TOKEN_BOOL:
            self._advance()
            return {"type": "bool", "node": tok.value}

        raise ParseError(
            f"Expected expression but got {tok.kind} ({tok.value!r})",
            tok.pos,
        )

    def _parse_ident_or_call(self) -> dict[str, Any]:
        """Parse either a bare identifier or a function call."""
        ident_tok = self._advance()  # consume the IDENT

        # Check if followed by '(' — that makes it a function call
        if self._peek().kind == _TOKEN_LPAREN:
            self._advance()  # consume '('
            children: list[dict[str, Any]] = []

            # Handle empty argument list
            if self._peek().kind != _TOKEN_RPAREN:
                children.append(self._parse_expr())
                while self._peek().kind == _TOKEN_COMMA:
                    self._advance()  # consume ','
                    children.append(self._parse_expr())

            self._expect(_TOKEN_RPAREN)
            return {
                "type": "rotation",
                "node": ident_tok.value,
                "children": children,
            }

        # Bare identifier — classify as feature or aggregation
        return {
            "type": _classify_bare_identifier(ident_tok.value),
            "node": ident_tok.value,
        }


_AGGREGATION_HINTS = frozenset({
    "_agg", "_sum", "_mean", "_std", "_var", "_min", "_max",
    "_count", "_median", "_mode", "_rank", "_norm",
    "_ratio", "_pct", "_diff", "_delta",
})


def _classify_bare_identifier(name: str) -> str:
    """Classify a bare identifier as ``feature`` or ``aggregation``.

    Aggregation hints take precedence over feature hints so that
    names like ``volume_agg`` are correctly classified as aggregations
    even though they contain a feature substring (``volume``).
    """
    lower = name.lower()

    # Check aggregation hints first (higher priority)
    for hint in _AGGREGATION_HINTS:
        if lower.endswith(hint):
            return "aggregation"

    # Then check feature hints
    for hint in _FEATURE_HINTS:
        if hint in lower:
            return "feature"

    return "aggregation"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def parse_expression(text: str) -> dict[str, Any]:
    """Parse a text expression into a graph dict.

    Parameters
    ----------
    text:
        Functional notation string, e.g.
        ``"latitudinal_rank(close_1h)"`` or ``"volume_agg"``.

    Returns
    -------
    dict
        Nested graph dict with ``type``, ``node``, and optionally
        ``children`` keys.

    Raises
    ------
    ParseError
        If the text cannot be parsed, with a descriptive message and
        the character position of the error.

    Examples
    --------
    >>> parse_expression("close_1h")
    {'type': 'feature', 'node': 'close_1h'}

    >>> parse_expression("latitudinal_rank(close_1h)")
    {'type': 'rotation', 'node': 'latitudinal_rank', 'children': [{'type': 'feature', 'node': 'close_1h'}]}
    """
    stripped = text.strip()
    if not stripped:
        raise ParseError("Empty expression", 0)

    tokens = _tokenize(stripped)
    parser = _Parser(tokens)
    return parser.parse()
