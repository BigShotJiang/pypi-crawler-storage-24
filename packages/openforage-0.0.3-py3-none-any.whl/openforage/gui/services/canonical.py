"""Canonical string builder for expression graph dicts.

A graph dict is a nested structure where each node has:
- ``type``: one of rotation, filtration, reduction, feature, aggregation, float, int, string, bool
- ``node``: the function name (for function types) or the value (for leaf types)
- ``children``: list of child graph dicts (for function types only)
"""

from __future__ import annotations

from typing import Any

_LEAF_TYPES = frozenset({"feature", "aggregation", "float", "int", "string", "bool"})
_FUNCTION_TYPES = frozenset({"rotation", "filtration", "reduction", "function"})


def canonical_graph_string(graph_node: dict[str, Any]) -> str:
    """Convert a graph node dict into its canonical string representation.

    Parameters
    ----------
    graph_node:
        A dict with ``type`` and ``node`` keys. Function types also have
        ``children``.

    Returns
    -------
    str
        The canonical string, e.g. ``zscore(close_1h, 60)``.
    """
    node_type = graph_node.get("type", "")
    node_value = graph_node.get("node", "")

    if node_type in _LEAF_TYPES:
        if node_type == "string":
            return f'"{node_value}"'
        if node_type == "bool":
            return str(node_value).lower()
        return str(node_value)

    if node_type in _FUNCTION_TYPES:
        children = graph_node.get("children", [])
        child_strings = [canonical_graph_string(child) for child in children]
        return f"{node_value}({', '.join(child_strings)})"

    # Fallback: try node field
    if "children" in graph_node:
        children = graph_node.get("children", [])
        child_strings = [canonical_graph_string(child) for child in children]
        return f"{node_value}({', '.join(child_strings)})"

    return str(node_value) if node_value else "?"
