"""OpenForage Simulator GUI — local web interface for expression development."""
