# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Search analytics subcomponent — aggregated statistics, suggestions, patterns."""

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple, FrozenSet


class AggregateBy(Enum):
    """Aggregation dimension for search stats.

    Each member defines a (function_level, feature_level) pair that determines
    how evaluation functions and features are grouped.
    """
    FUNCTION_FAMILY_FEATURE_FAMILY = ("function_family", "feature_family")
    FUNCTION_FAMILY_FEATURE_SUBFAMILY = ("function_family", "feature_subfamily")
    FUNCTION_FAMILY_FEATURE = ("function_family", "feature")
    FUNCTION_SUBFAMILY_FEATURE_FAMILY = ("function_subfamily", "feature_family")
    FUNCTION_SUBFAMILY_FEATURE_SUBFAMILY = ("function_subfamily", "feature_subfamily")
    FUNCTION_SUBFAMILY_FEATURE = ("function_subfamily", "feature")
    FUNCTION_FEATURE_FAMILY = ("function", "feature_family")
    FUNCTION_FEATURE_SUBFAMILY = ("function", "feature_subfamily")
    FUNCTION_FEATURE = ("function", "feature")
    NONE = None


class EvalPool(Enum):
    """Which evaluations to include."""
    ALL = "all"
    PASSED = "passed"
    SUBMITTED = "submitted"


class TimeWindow(Enum):
    """Time window for filtering evaluations."""
    LIFETIME = "lifetime"
    ERA = "era"
    LAST_WEEK = "last_week"
    LAST_24H = "last_24h"


@dataclass
class WindowStats:
    """Stats for a single time window within a group."""
    window: str = ""
    sharpe: float = 0.0
    returns: float = 0.0
    turnover: float = 0.0
    drawdown: float = 0.0
    correlation: float = 0.0
    yield_rate: float = 0.0
    submittable_yield: dict = field(default_factory=dict)
    composite_score: float = 0.0
    evaluation_count: int = 0


@dataclass
class StatsRow:
    """Single row in search stats result."""
    group_key: Tuple[FrozenSet[str], FrozenSet[str]] = field(
        default_factory=lambda: (frozenset(), frozenset())
    )
    windows: List[WindowStats] = field(default_factory=list)
    evaluation_count: int = 0


@dataclass
class SearchStatsResult:
    """Result from get_search_stats()."""
    rows: List[StatsRow] = field(default_factory=list)
    aggregate_by: Optional[object] = None  # AggregateBy enum
    eval_pool: Optional[object] = None  # EvalPool enum
    filters_applied: dict = field(default_factory=dict)
    total_evaluations: int = 0
    total_groups: int = 0
    groups_shown: int = 0


@dataclass
class SuggestionsResult:
    """Result from get_suggestions()."""
    focus: List[StatsRow] = field(default_factory=list)
    avoid: List[StatsRow] = field(default_factory=list)
    aggregate_by: Optional[object] = None  # AggregateBy enum
    scoring_formula: str = ""


@dataclass
class DepthBucket:
    """Depth distribution bucket."""
    depth: int = 0
    total: int = 0
    passed: int = 0
    yield_rate: float = 0.0


@dataclass
class FamilyYield:
    """Yield for a function family."""
    function_family: str = ""
    total: int = 0
    passed: int = 0
    yield_rate: float = 0.0


@dataclass
class SearchPatternsResult:
    """Result from get_search_patterns()."""
    depth_distribution: List[DepthBucket] = field(default_factory=list)
    family_yield_rates: List[FamilyYield] = field(default_factory=list)
    total_evaluations: int = 0
    total_passed: int = 0


@dataclass
class VelocityWindow:
    """Velocity for a time window."""
    window_minutes: int = 0
    evaluations_per_hour: float = 0.0
    passes_per_hour: float = 0.0
    total_evaluations: int = 0
    total_passed: int = 0


@dataclass
class SearchVelocityResult:
    """Result from get_search_velocity()."""
    windows: List[VelocityWindow] = field(default_factory=list)
    trend: str = ""


@dataclass
class YieldAnalysisResult:
    """Result from get_yield_analysis()."""
    lifetime_yield_rate: float = 0.0
    recent_yield_rate: float = 0.0
    trend: str = ""
    recent_window_minutes: int = 0
    total_evaluations: int = 0
    total_passed: int = 0
    diminishing_returns: bool = False


@dataclass
class FunctionPairPattern:
    """Co-occurrence pattern for function pairs."""
    function_a: str = ""
    function_b: str = ""
    total_cooccurrences: int = 0
    passed_cooccurrences: int = 0
    lift: float = 0.0


@dataclass
class CorrelationPatternsResult:
    """Result from get_correlation_patterns()."""
    pairs: List[FunctionPairPattern] = field(default_factory=list)
    total_passing_evaluations: int = 0
    total_evaluations: int = 0


# ---------------------------------------------------------------------------
# Mapping from AggregateBy level names to EvaluationRecord dict keys
# ---------------------------------------------------------------------------
_FUNC_KEY_MAP = {
    "function_family": "function_family",
    "function_subfamily": "function_subfamily",
    "function": "function_name",
}

_FEAT_KEY_MAP = {
    "feature_family": "feature_family",
    "feature_subfamily": "feature_subfamily",
    "feature": "feature_name",
}

# Sentinel value to distinguish "not provided" from "explicitly None"
_UNSET = object()


class SearchAnalytics:
    """Analytics engine over search tracking data."""

    def __init__(self, search_tracker, pool_configs):
        if search_tracker is None:
            raise ValueError("search_tracker must not be None.")
        if not pool_configs:
            raise ValueError("pool_configs must be non-empty.")
        for pc in pool_configs:
            if pc.is_correlation_threshold <= 0.0:
                raise ValueError("correlation threshold must be positive.")
        self._tracker = search_tracker
        self._pool_configs = pool_configs

    # ------------------------------------------------------------------
    # Internal: validate eval_type
    # ------------------------------------------------------------------
    def _validate_eval_type(self, eval_type):
        if eval_type is not None and eval_type not in ("signal", "strategy"):
            raise ValueError(f"eval_type must be 'signal', 'strategy', or None, got '{eval_type}'.")

    # ------------------------------------------------------------------
    # Internal: fetch and filter evaluations
    # ------------------------------------------------------------------
    def _fetch_evaluations(self, era_id=None, eval_type=None, universe_id=None,
                           metaparameters=None, eval_pool=EvalPool.ALL,
                           function_family=None, function_subfamily=None,
                           feature_family=None, feature_subfamily=None):
        """Fetch evaluations from tracker, applying filters and eval_pool."""
        # Get base evaluations from tracker
        passed_only = (eval_pool == EvalPool.PASSED)
        evals = self._tracker.get_evaluation_history(
            era_id=era_id,
            eval_type=eval_type,
            passed_only=passed_only,
            universe_id=universe_id,
            metaparameters=metaparameters,
        )

        # For SUBMITTED pool, filter to submitted=True
        if eval_pool == EvalPool.SUBMITTED:
            evals = [e for e in evals if e.submitted]

        # Merge all 4 optional filters into a single pass
        need_filter = (function_family is not None or function_subfamily is not None or
                       feature_family is not None or feature_subfamily is not None)
        if need_filter:
            filtered = []
            for e in evals:
                # function_family: at-least-one match (independent predicate)
                if function_family is not None:
                    match = False
                    if e.functions:
                        for f in e.functions:
                            fam = f.get("function_family", "") if isinstance(f, dict) else ""
                            if fam == function_family:
                                match = True
                                break
                    if not match:
                        continue

                # function_subfamily: at-least-one match (independent predicate)
                if function_subfamily is not None:
                    match = False
                    if e.functions:
                        for f in e.functions:
                            sub = f.get("function_subfamily", "") if isinstance(f, dict) else ""
                            if sub == function_subfamily:
                                match = True
                                break
                    if not match:
                        continue

                # feature_family: at-least-one match (independent predicate)
                if feature_family is not None:
                    match = False
                    if e.features:
                        for f in e.features:
                            fam = f.get("feature_family", "") if isinstance(f, dict) else ""
                            if fam == feature_family:
                                match = True
                                break
                    if not match:
                        continue

                # feature_subfamily: at-least-one match (independent predicate)
                if feature_subfamily is not None:
                    match = False
                    if e.features:
                        for f in e.features:
                            sub = f.get("feature_subfamily", "") if isinstance(f, dict) else ""
                            if sub == feature_subfamily:
                                match = True
                                break
                    if not match:
                        continue

                filtered.append(e)
            evals = filtered

        return evals

    # ------------------------------------------------------------------
    # Internal: build group key for an evaluation
    # ------------------------------------------------------------------
    def _build_group_key(self, ev, aggregate_by):
        """Build (frozenset(func_ids), frozenset(feat_ids)) for the evaluation."""
        if aggregate_by == AggregateBy.NONE:
            # No aggregation — each evaluation's exact (function_set, feature_set) is the key
            func_ids = set()
            if ev.functions:
                for f in ev.functions:
                    if isinstance(f, dict):
                        func_ids.add(f.get("function_name", ""))
                    else:
                        func_ids.add(str(f))
            feat_ids = set()
            if ev.features:
                for f in ev.features:
                    if isinstance(f, dict):
                        feat_ids.add(f.get("feature_name", ""))
                    else:
                        feat_ids.add(str(f))
            return (frozenset(func_ids), frozenset(feat_ids))

        func_level, feat_level = aggregate_by.value
        func_key = _FUNC_KEY_MAP[func_level]
        feat_key = _FEAT_KEY_MAP[feat_level]

        func_ids = set()
        if ev.functions:
            for f in ev.functions:
                if isinstance(f, dict):
                    func_ids.add(f.get(func_key, ""))
                else:
                    func_ids.add(str(f))

        feat_ids = set()
        if ev.features:
            for f in ev.features:
                if isinstance(f, dict):
                    feat_ids.add(f.get(feat_key, ""))
                else:
                    feat_ids.add(str(f))

        return (frozenset(func_ids), frozenset(feat_ids))

    # ------------------------------------------------------------------
    # Internal: get per-column stat from evaluation
    # ------------------------------------------------------------------
    def _get_stat(self, ev, pnl_column, stat_name):
        """Get a stat value from per_column_stats or fall back to top-level."""
        if pnl_column is None:
            pnl_column = "gross_returns"

        key = f"{pnl_column}_{stat_name}"
        if ev.per_column_stats and key in ev.per_column_stats:
            return ev.per_column_stats[key]

        # Fallback to top-level
        return getattr(ev, stat_name, 0.0)

    # ------------------------------------------------------------------
    # Internal: filter evaluations by time window
    # ------------------------------------------------------------------
    def _filter_by_time_window(self, evals, tw, era_id, now):
        """Filter evaluations for a specific time window."""
        if tw == TimeWindow.LIFETIME:
            return evals
        elif tw == TimeWindow.ERA:
            if era_id is not None:
                return [e for e in evals if e.era_id == era_id]
            else:
                return evals  # ERA with era_id=None is equivalent to LIFETIME
        elif tw == TimeWindow.LAST_WEEK:
            cutoff = now - 10080 * 60  # 7 days in seconds
            return [e for e in evals if e.timestamp >= cutoff]
        elif tw == TimeWindow.LAST_24H:
            cutoff = now - 1440 * 60  # 24 hours in seconds
            return [e for e in evals if e.timestamp >= cutoff]
        return evals

    # ------------------------------------------------------------------
    # Public: get_search_stats
    # ------------------------------------------------------------------
    def get_search_stats(self, era_id=None, eval_type=None, universe_id=None,
                         metaparameters=None, function_family=None,
                         function_subfamily=None, feature_family=None,
                         feature_subfamily=None,
                         aggregate_by=AggregateBy.FUNCTION_SUBFAMILY_FEATURE_SUBFAMILY,
                         eval_pool=EvalPool.ALL, time_windows=_UNSET,
                         pnl_column=None, min_sample_size=100,
                         sort_ascending=False) -> SearchStatsResult:
        """Aggregated performance statistics with flexible grouping."""
        # Validate inputs
        self._validate_eval_type(eval_type)
        if min_sample_size < 0:
            raise ValueError(f"min_sample_size must be >= 0, got {min_sample_size}.")

        # Handle time_windows default vs explicit None
        if time_windows is _UNSET:
            # Not provided: default to LIFETIME only
            time_windows = [TimeWindow.LIFETIME]
        elif time_windows is None:
            # Explicitly None: all 4 windows
            time_windows = [TimeWindow.LIFETIME, TimeWindow.ERA, TimeWindow.LAST_WEEK, TimeWindow.LAST_24H]
        else:
            if len(time_windows) == 0:
                raise ValueError("time_windows must be None or a non-empty list.")
            if len(time_windows) != len(set(time_windows)):
                raise ValueError("time_windows must not contain duplicates.")

        # Default pnl_column
        if pnl_column is None:
            pnl_column = "gross_returns"

        # Step 1: Filter evaluations
        evals = self._fetch_evaluations(
            era_id=era_id, eval_type=eval_type, universe_id=universe_id,
            metaparameters=metaparameters, eval_pool=eval_pool,
            function_family=function_family, function_subfamily=function_subfamily,
            feature_family=feature_family, feature_subfamily=feature_subfamily,
        )
        total_evaluations = len(evals)

        # Build filters_applied dict
        filters_applied = {}
        if era_id is not None:
            filters_applied["era_id"] = era_id
        if eval_type is not None:
            filters_applied["eval_type"] = eval_type
        if universe_id is not None:
            filters_applied["universe_id"] = universe_id
        if metaparameters is not None:
            filters_applied["metaparameters"] = metaparameters
        if function_family is not None:
            filters_applied["function_family"] = function_family
        if function_subfamily is not None:
            filters_applied["function_subfamily"] = function_subfamily
        if feature_family is not None:
            filters_applied["feature_family"] = feature_family
        if feature_subfamily is not None:
            filters_applied["feature_subfamily"] = feature_subfamily

        if total_evaluations == 0:
            return SearchStatsResult(
                rows=[],
                aggregate_by=aggregate_by,
                eval_pool=eval_pool,
                filters_applied=filters_applied,
                total_evaluations=0,
                total_groups=0,
                groups_shown=0,
            )

        # Pre-compute stat keys once
        key_sharpe = f"{pnl_column}_sharpe"
        key_returns = f"{pnl_column}_returns"
        key_drawdown = f"{pnl_column}_drawdown"

        # Pre-compute time window cutoffs
        now = time.time()
        cutoff_week = now - 604800   # 7 * 24 * 3600
        cutoff_24h = now - 86400     # 24 * 3600

        # Map each TimeWindow to its index in the per-group accumulator arrays
        n_windows = len(time_windows)
        tw_lifetime_idx = None
        tw_era_idx = None
        tw_week_idx = None
        tw_24h_idx = None
        for i, tw in enumerate(time_windows):
            if tw == TimeWindow.LIFETIME:
                tw_lifetime_idx = i
            elif tw == TimeWindow.ERA:
                tw_era_idx = i
            elif tw == TimeWindow.LAST_WEEK:
                tw_week_idx = i
            elif tw == TimeWindow.LAST_24H:
                tw_24h_idx = i

        pool_configs = self._pool_configs
        n_pools = len(pool_configs)
        pool_names = [pc.name for pc in pool_configs]
        pool_thresholds = [pc.is_correlation_threshold for pc in pool_configs]

        # One-pass grouped/windowed accumulator.
        # acc[group_key] = [lifetime_count, windows_data, pool_submittable_data]
        # windows_data[i] = [sum_sharpe, sum_returns, sum_turnover, sum_drawdown,
        #                    sum_correlation, passed_count, n_in_window]
        # pool_submittable_data[i] = [count_pool_0, count_pool_1, ..., count_pool_N]
        acc = {}
        for ev in evals:
            # Extract per-eval stats once (not 3× per group per window)
            pcs = ev.per_column_stats
            if pcs:
                ev_sharpe = pcs[key_sharpe] if key_sharpe in pcs else getattr(ev, "sharpe", 0.0)
                ev_returns = pcs[key_returns] if key_returns in pcs else getattr(ev, "returns", 0.0)
                ev_drawdown = pcs[key_drawdown] if key_drawdown in pcs else getattr(ev, "drawdown", 0.0)
            else:
                ev_sharpe = getattr(ev, "sharpe", 0.0)
                ev_returns = getattr(ev, "returns", 0.0)
                ev_drawdown = getattr(ev, "drawdown", 0.0)
            ev_turnover = ev.turnover
            ev_correlation = ev.correlation
            ev_passed = 1 if ev.passed_thresholds else 0
            # Per-pool submittable: correlation < pool threshold (strict <, Codex: not <=)
            ev_pool_submittable = []
            for p_idx in range(n_pools):
                if ev_passed and ev_correlation < pool_thresholds[p_idx]:
                    ev_pool_submittable.append(1)
                else:
                    ev_pool_submittable.append(0)

            # Build group key once per eval
            gk = self._build_group_key(ev, aggregate_by)
            if gk not in acc:
                acc[gk] = [
                    0,
                    [[0.0, 0.0, 0.0, 0.0, 0.0, 0, 0] for _ in range(n_windows)],
                    [[0] * n_pools for _ in range(n_windows)],
                ]
            entry = acc[gk]
            entry[0] += 1  # lifetime_count

            # Accumulate directly into time-window slots
            ev_ts = ev.timestamp
            ev_era_id = ev.era_id
            windows_data = entry[1]
            pool_data = entry[2]

            if tw_lifetime_idx is not None:
                wa = windows_data[tw_lifetime_idx]
                wa[0] += ev_sharpe; wa[1] += ev_returns; wa[2] += ev_turnover
                wa[3] += ev_drawdown; wa[4] += ev_correlation
                wa[5] += ev_passed; wa[6] += 1
                pd = pool_data[tw_lifetime_idx]
                for p_idx in range(n_pools):
                    pd[p_idx] += ev_pool_submittable[p_idx]

            if tw_era_idx is not None:
                # ERA with era_id=None counts all (same as LIFETIME)
                if era_id is None or ev_era_id == era_id:
                    wa = windows_data[tw_era_idx]
                    wa[0] += ev_sharpe; wa[1] += ev_returns; wa[2] += ev_turnover
                    wa[3] += ev_drawdown; wa[4] += ev_correlation
                    wa[5] += ev_passed; wa[6] += 1
                    pd = pool_data[tw_era_idx]
                    for p_idx in range(n_pools):
                        pd[p_idx] += ev_pool_submittable[p_idx]

            if tw_week_idx is not None and ev_ts >= cutoff_week:
                wa = windows_data[tw_week_idx]
                wa[0] += ev_sharpe; wa[1] += ev_returns; wa[2] += ev_turnover
                wa[3] += ev_drawdown; wa[4] += ev_correlation
                wa[5] += ev_passed; wa[6] += 1
                pd = pool_data[tw_week_idx]
                for p_idx in range(n_pools):
                    pd[p_idx] += ev_pool_submittable[p_idx]

            if tw_24h_idx is not None and ev_ts >= cutoff_24h:
                wa = windows_data[tw_24h_idx]
                wa[0] += ev_sharpe; wa[1] += ev_returns; wa[2] += ev_turnover
                wa[3] += ev_drawdown; wa[4] += ev_correlation
                wa[5] += ev_passed; wa[6] += 1
                pd = pool_data[tw_24h_idx]
                for p_idx in range(n_pools):
                    pd[p_idx] += ev_pool_submittable[p_idx]

        total_groups = len(acc)
        empty_yield = {name: 0.0 for name in pool_names}

        # Build StatsRow objects from accumulators
        rows = []
        for gk, (lifetime_count, windows_data, pool_data) in acc.items():
            # min_sample_size uses LIFETIME count (Codex: not window count)
            if lifetime_count < min_sample_size:
                continue

            window_stats_list = []
            for i, tw in enumerate(time_windows):
                wa = windows_data[i]
                n = wa[6]
                if n == 0:
                    ws = WindowStats(
                        window=tw,
                        sharpe=0.0, returns=0.0, turnover=0.0,
                        drawdown=0.0, correlation=0.0,
                        yield_rate=0.0, submittable_yield=dict(empty_yield),
                        composite_score=0.0, evaluation_count=0,
                    )
                else:
                    mean_sharpe = wa[0] / n
                    mean_returns = wa[1] / n
                    # turnover floor applied to MEAN (Codex: not per-evaluation)
                    mean_turnover = wa[2] / n
                    mean_drawdown = wa[3] / n
                    mean_correlation = wa[4] / n
                    yield_rate = wa[5] / n
                    pd = pool_data[i]
                    submittable_yield = {pool_names[p_idx]: pd[p_idx] / n for p_idx in range(n_pools)}
                    composite_score = mean_sharpe * (1.0 - mean_correlation) * (1.0 / max(mean_turnover, 0.01))
                    ws = WindowStats(
                        window=tw,
                        sharpe=mean_sharpe,
                        returns=mean_returns,
                        turnover=mean_turnover,
                        drawdown=mean_drawdown,
                        correlation=mean_correlation,
                        yield_rate=yield_rate,
                        submittable_yield=submittable_yield,
                        composite_score=composite_score,
                        evaluation_count=n,
                    )
                window_stats_list.append(ws)

            rows.append(StatsRow(
                group_key=gk,
                windows=window_stats_list,
                evaluation_count=lifetime_count,
            ))

        groups_shown = len(rows)

        # Sort by composite_score of first time window
        if sort_ascending:
            rows.sort(key=lambda r: (r.windows[0].composite_score, -r.evaluation_count))
        else:
            rows.sort(key=lambda r: (-r.windows[0].composite_score, -r.evaluation_count))

        return SearchStatsResult(
            rows=rows,
            aggregate_by=aggregate_by,
            eval_pool=eval_pool,
            filters_applied=filters_applied,
            total_evaluations=total_evaluations,
            total_groups=total_groups,
            groups_shown=groups_shown,
        )

    # ------------------------------------------------------------------
    # Public: get_suggestions
    # ------------------------------------------------------------------
    def get_suggestions(self, era_id=None, eval_type=None, universe_id=None,
                        metaparameters=None, function_family=None,
                        function_subfamily=None, feature_family=None,
                        feature_subfamily=None,
                        aggregate_by=AggregateBy.FUNCTION_SUBFAMILY_FEATURE_SUBFAMILY,
                        pnl_column=None, min_sample_size=100,
                        top_n=10) -> SuggestionsResult:
        """Composite-scored focus/avoid suggestions."""
        # Validate inputs
        self._validate_eval_type(eval_type)
        if min_sample_size < 0:
            raise ValueError(f"min_sample_size must be >= 0, got {min_sample_size}.")
        if top_n < 1:
            raise ValueError(f"top_n must be >= 1, got {top_n}.")

        # Suggestions always use EvalPool.ALL and TimeWindow.LIFETIME
        stats_result = self.get_search_stats(
            era_id=era_id, eval_type=eval_type, universe_id=universe_id,
            metaparameters=metaparameters,
            function_family=function_family, function_subfamily=function_subfamily,
            feature_family=feature_family, feature_subfamily=feature_subfamily,
            aggregate_by=aggregate_by,
            eval_pool=EvalPool.ALL,
            time_windows=[TimeWindow.LIFETIME],
            pnl_column=pnl_column,
            min_sample_size=min_sample_size,
            sort_ascending=False,
        )

        all_rows = stats_result.rows

        # Focus: top N by composite_score descending (already sorted desc)
        focus = all_rows[:top_n]

        # Avoid: bottom N by composite_score ascending
        avoid = sorted(all_rows, key=lambda r: (r.windows[0].composite_score, -r.evaluation_count))[:top_n]

        return SuggestionsResult(
            focus=focus,
            avoid=avoid,
            aggregate_by=aggregate_by,
            scoring_formula="sharpe * (1 - correlation) * (1 / max(turnover, 0.01))",
        )

    # ------------------------------------------------------------------
    # Public: get_available_eras
    # ------------------------------------------------------------------
    def get_available_eras(self) -> list:
        """Sorted list of distinct era_id values."""
        return self._tracker.get_available_eras()

    # ------------------------------------------------------------------
    # Public: get_available_universes
    # ------------------------------------------------------------------
    def get_available_universes(self) -> list:
        """Sorted list of distinct universe_id values."""
        return self._tracker.get_available_universes()

    # ------------------------------------------------------------------
    # Public: get_available_aggregations
    # ------------------------------------------------------------------
    def get_available_aggregations(self) -> list:
        """List of all AggregateBy enum values in declaration order."""
        return list(AggregateBy)

    # ------------------------------------------------------------------
    # Public: get_search_patterns
    # ------------------------------------------------------------------
    def get_search_patterns(self, era_id=None, eval_type=None, universe_id=None,
                            metaparameters=None, function_family=None,
                            function_subfamily=None, feature_family=None,
                            feature_subfamily=None,
                            eval_pool=EvalPool.ALL) -> SearchPatternsResult:
        """Depth distribution and family yield analysis."""
        self._validate_eval_type(eval_type)

        evals = self._fetch_evaluations(
            era_id=era_id, eval_type=eval_type, universe_id=universe_id,
            metaparameters=metaparameters, eval_pool=eval_pool,
            function_family=function_family, function_subfamily=function_subfamily,
            feature_family=feature_family, feature_subfamily=feature_subfamily,
        )

        total_evaluations = len(evals)

        if total_evaluations == 0:
            return SearchPatternsResult(
                depth_distribution=[],
                family_yield_rates=[],
                total_evaluations=0,
                total_passed=0,
            )

        # Single pass: compute total_passed, depth distribution, and family yield
        total_passed = 0
        depth_totals = {}
        depth_passed = {}
        family_totals = {}
        family_passed = {}
        for e in evals:
            passed = e.passed_thresholds
            if passed:
                total_passed += 1
            d = e.tree_depth
            depth_totals[d] = depth_totals.get(d, 0) + 1
            if passed:
                depth_passed[d] = depth_passed.get(d, 0) + 1
            if e.functions:
                # Family deduplication: count family once per eval (Codex)
                families_seen = set()
                for f in e.functions:
                    if isinstance(f, dict):
                        fam = f.get("function_family", "")
                    else:
                        fam = str(f)
                    families_seen.add(fam)
                for fam in families_seen:
                    family_totals[fam] = family_totals.get(fam, 0) + 1
                    if passed:
                        family_passed[fam] = family_passed.get(fam, 0) + 1

        depth_distribution = []
        for d in sorted(depth_totals.keys()):
            total = depth_totals[d]
            dp = depth_passed.get(d, 0)
            yr = dp / total if total > 0 else 0.0
            depth_distribution.append(DepthBucket(depth=d, total=total, passed=dp, yield_rate=yr))

        family_yield_rates = []
        for fam in family_totals:
            total = family_totals[fam]
            passed = family_passed.get(fam, 0)
            yr = passed / total if total > 0 else 0.0
            family_yield_rates.append(FamilyYield(
                function_family=fam, total=total, passed=passed, yield_rate=yr,
            ))

        # Sort by yield_rate descending
        family_yield_rates.sort(key=lambda f: -f.yield_rate)

        return SearchPatternsResult(
            depth_distribution=depth_distribution,
            family_yield_rates=family_yield_rates,
            total_evaluations=total_evaluations,
            total_passed=total_passed,
        )

    # ------------------------------------------------------------------
    # Public: get_search_velocity
    # ------------------------------------------------------------------
    def get_search_velocity(self, era_id=None, eval_type=None, universe_id=None,
                            metaparameters=None, function_family=None,
                            function_subfamily=None, feature_family=None,
                            feature_subfamily=None,
                            windows=None) -> SearchVelocityResult:
        """Evaluation rate across time windows."""
        self._validate_eval_type(eval_type)

        if windows is not None:
            if len(windows) == 0:
                raise ValueError("windows must be None or a non-empty list of positive integers.")
            for w in windows:
                if w <= 0:
                    raise ValueError(f"window size must be positive, got {w}.")

        if windows is None:
            windows = [60, 360, 1440]

        # Get all evaluations matching filters
        evals = self._fetch_evaluations(
            era_id=era_id, eval_type=eval_type, universe_id=universe_id,
            metaparameters=metaparameters,
            function_family=function_family, function_subfamily=function_subfamily,
            feature_family=feature_family, feature_subfamily=feature_subfamily,
        )

        now = time.time()

        velocity_windows = []
        for w_minutes in windows:
            cutoff = now - w_minutes * 60
            evals_in_window = [e for e in evals if e.timestamp >= cutoff]
            total_in_window = len(evals_in_window)
            passed_in_window = sum(1 for e in evals_in_window if e.passed_thresholds)
            hours = w_minutes / 60.0
            evals_per_hour = total_in_window / hours if hours > 0 else 0.0
            passes_per_hour = passed_in_window / hours if hours > 0 else 0.0

            velocity_windows.append(VelocityWindow(
                window_minutes=w_minutes,
                evaluations_per_hour=evals_per_hour,
                passes_per_hour=passes_per_hour,
                total_evaluations=total_in_window,
                total_passed=passed_in_window,
            ))

        # Determine trend: compare shortest window to longest window
        # 'insufficient_data' if any window has < 10 evaluations
        any_insufficient = any(vw.total_evaluations < 10 for vw in velocity_windows)
        if any_insufficient:
            trend = "insufficient_data"
        else:
            shortest_idx = 0
            shortest_minutes = velocity_windows[0].window_minutes
            longest_idx = 0
            longest_minutes = velocity_windows[0].window_minutes
            for i, vw in enumerate(velocity_windows):
                if vw.window_minutes < shortest_minutes:
                    shortest_minutes = vw.window_minutes
                    shortest_idx = i
                if vw.window_minutes > longest_minutes:
                    longest_minutes = vw.window_minutes
                    longest_idx = i

            short_rate = velocity_windows[shortest_idx].passes_per_hour
            long_rate = velocity_windows[longest_idx].passes_per_hour

            if short_rate > long_rate * 1.2:
                trend = "rising"
            elif short_rate < long_rate * 0.8:
                trend = "declining"
            else:
                trend = "stable"

        return SearchVelocityResult(
            windows=velocity_windows,
            trend=trend,
        )

    # ------------------------------------------------------------------
    # Public: get_yield_analysis
    # ------------------------------------------------------------------
    def get_yield_analysis(self, era_id=None, eval_type=None, universe_id=None,
                           metaparameters=None, function_family=None,
                           function_subfamily=None, feature_family=None,
                           feature_subfamily=None,
                           recent_window_minutes=360) -> YieldAnalysisResult:
        """Era-level and family-level yield breakdown."""
        self._validate_eval_type(eval_type)
        if recent_window_minutes <= 0:
            raise ValueError(f"recent_window_minutes must be positive, got {recent_window_minutes}.")

        evals = self._fetch_evaluations(
            era_id=era_id, eval_type=eval_type, universe_id=universe_id,
            metaparameters=metaparameters,
            function_family=function_family, function_subfamily=function_subfamily,
            feature_family=feature_family, feature_subfamily=feature_subfamily,
        )

        total_evaluations = len(evals)
        total_passed = sum(1 for e in evals if e.passed_thresholds)

        if total_evaluations == 0:
            return YieldAnalysisResult(
                lifetime_yield_rate=0.0,
                recent_yield_rate=0.0,
                trend="insufficient_data",
                recent_window_minutes=recent_window_minutes,
                total_evaluations=0,
                total_passed=0,
                diminishing_returns=False,
            )

        lifetime_yield_rate = total_passed / total_evaluations

        now = time.time()
        cutoff = now - recent_window_minutes * 60
        recent_evals = [e for e in evals if e.timestamp >= cutoff]
        recent_total = len(recent_evals)
        recent_passed = sum(1 for e in recent_evals if e.passed_thresholds)

        if recent_total == 0:
            recent_yield_rate = 0.0
        else:
            recent_yield_rate = recent_passed / recent_total

        # Determine trend
        if recent_total < 10:
            trend = "insufficient_data"
        elif recent_yield_rate > lifetime_yield_rate * 1.2:
            trend = "improving"
        elif recent_yield_rate < lifetime_yield_rate * 0.8:
            trend = "declining"
        else:
            trend = "stable"

        # Diminishing returns: recent < lifetime * 0.5
        diminishing_returns = recent_yield_rate < lifetime_yield_rate * 0.5

        return YieldAnalysisResult(
            lifetime_yield_rate=lifetime_yield_rate,
            recent_yield_rate=recent_yield_rate,
            trend=trend,
            recent_window_minutes=recent_window_minutes,
            total_evaluations=total_evaluations,
            total_passed=total_passed,
            diminishing_returns=diminishing_returns,
        )

    # ------------------------------------------------------------------
    # Public: get_correlation_patterns
    # ------------------------------------------------------------------
    def get_correlation_patterns(self, era_id=None, eval_type=None, universe_id=None,
                                 metaparameters=None, function_family=None,
                                 function_subfamily=None, feature_family=None,
                                 feature_subfamily=None,
                                 top_n=20) -> CorrelationPatternsResult:
        """Function pair correlation patterns."""
        self._validate_eval_type(eval_type)
        if top_n < 1:
            raise ValueError(f"top_n must be >= 1, got {top_n}.")

        # Get all evaluations matching filters (ALL pool)
        evals = self._fetch_evaluations(
            era_id=era_id, eval_type=eval_type, universe_id=universe_id,
            metaparameters=metaparameters,
            function_family=function_family, function_subfamily=function_subfamily,
            feature_family=feature_family, feature_subfamily=feature_subfamily,
        )

        total_evaluations = len(evals)
        total_passing = sum(1 for e in evals if e.passed_thresholds)

        if total_evaluations == 0:
            return CorrelationPatternsResult(
                pairs=[],
                total_passing_evaluations=0,
                total_evaluations=0,
            )

        # Get co-occurrence data from tracker
        cooccurrence_pairs = self._tracker.get_function_cooccurrence(
            era_id=era_id, eval_type=eval_type,
            universe_id=universe_id, metaparameters=metaparameters,
        )

        # Compute lift and build FunctionPairPattern objects
        base_rate = total_passing / total_evaluations if total_evaluations > 0 else 1.0

        result_pairs = []
        for cp in cooccurrence_pairs:
            pair_rate = cp.passed_cooccurrences / cp.total_cooccurrences if cp.total_cooccurrences > 0 else 0.0
            lift = pair_rate / base_rate if base_rate > 0 else 0.0

            # Ensure alphabetical order
            fa, fb = cp.function_a, cp.function_b
            if fa > fb:
                fa, fb = fb, fa

            result_pairs.append(FunctionPairPattern(
                function_a=fa,
                function_b=fb,
                total_cooccurrences=cp.total_cooccurrences,
                passed_cooccurrences=cp.passed_cooccurrences,
                lift=lift,
            ))

        # Sort by passed_cooccurrences descending, limit to top_n
        result_pairs.sort(key=lambda p: -p.passed_cooccurrences)
        result_pairs = result_pairs[:top_n]

        return CorrelationPatternsResult(
            pairs=result_pairs,
            total_passing_evaluations=total_passing,
            total_evaluations=total_evaluations,
        )
