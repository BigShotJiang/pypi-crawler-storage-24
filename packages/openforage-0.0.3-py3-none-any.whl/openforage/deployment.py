# cython: wraparound=True, boundscheck=True, annotation_typing=False
"""Deployment subcomponent — wheel building, hardening, publishing, auto-update."""

import logging
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path
from typing import Dict, List, Optional

import httpx

logger = logging.getLogger("openforage.deployment")

# Cython.Build.cythonize — imported at module level so tests can mock it
try:
    from Cython.Build import cythonize
except ImportError:
    def cythonize(*args, **kwargs):  # type: ignore[misc]
        """Fallback stub when Cython is not installed."""
        return []


# Current library version (used for auto_update comparisons)
_CURRENT_VERSION = "0.0.1"

# Module allowlist: only these modules are included in the PyPI wheel
WHEEL_ALLOWLIST: List[str] = [
    "functions.rotations",
    "functions.filtrations",
    "functions.reductions",
    "functions.aggregators",
    "simulator_engine.graph_validator",
    "simulator_engine.expression_evaluator",
    "simulator_engine.backtest",
    "simulator_engine.correlation",
    "simulator_engine.batch_orchestrator",
    "simulator_engine.live_evaluation",
    "simulator_engine.checkpointing",
    "simulator_engine.live_analytics",
    "simulator_engine.runtime_detection",
    "openforage_library.auth",
    "openforage_library.sync",
    "openforage_library.obfuscation",
    "openforage_library.submit",
    "openforage_library.search_tracking",
    "openforage_library.search_analytics",
    "openforage_library.search_templates",
    "openforage_library.agent_onboarding",
    "openforage_library.deployment",
]

# Modules that MUST NOT appear in the wheel
EXCLUDED_MODULES: List[str] = [
    "data_platform",
    "platform_service",
    "signal_service",
    "live_trading_service",
    "obfuscation",
    "research_pipeline",
    "database",
]

# Sensitive string patterns that MUST be encrypted at build time
SENSITIVE_STRINGS: List[str] = [
    "openforage-platform-key",
    "openforage-combined-shuffle-key",
    "openforage-vault-key",
    "openforage-shuffle-seed",
    "openforage-long-format-hash",
]

# Cython compiler directives for hardening
CYTHON_DIRECTIVES = {
    "binding": False,
    "emit_code_comments": False,
    "embedsignature": False,
    "boundscheck": False,
    "cdivision": True,
}

# C compiler flags for hardening (Linux/macOS)
C_FLAGS_UNIX: List[str] = ["-O3", "-s", "-DNDEBUG", "-fvisibility=hidden"]

# Platform targets
PLATFORMS: List[str] = [
    "manylinux_2_17_x86_64",
    "manylinux_2_17_aarch64",
    "macosx_11_0_x86_64",
    "macosx_11_0_arm64",
    "win_amd64",
]

PYTHON_VERSIONS: List[str] = ["cp310", "cp311", "cp312", "cp313"]

# Source file extensions that MUST NOT appear in the wheel
SOURCE_EXTENSIONS = {".pyx", ".pxd", ".c", ".cpp", ".h"}


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class BuildError(Exception):
    """Raised on compilation failure."""


class HardeningVerificationError(Exception):
    """Raised when hardening check fails."""


class PublishError(Exception):
    """Raised on PyPI upload failure."""


class LibraryUpdateRequired(Exception):
    """Raised when current version < min_library_version and auto-update fails."""


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

class UpdateResult:
    """Result of auto_update attempt."""
    def __init__(self, success: bool, new_version: Optional[str], warning: Optional[str]):
        self.success = success
        self.new_version = new_version
        self.warning = warning


class HardeningReport:
    """Report from hardening verification."""
    def __init__(self):
        self.source_files_found: List[str] = []
        self.unstripped_symbols: List[str] = []
        self.plaintext_sensitive_strings: List[str] = []
        self.passed: bool = False


# ---------------------------------------------------------------------------
# Semver validation
# ---------------------------------------------------------------------------

def _validate_semver(version: str) -> tuple:
    """Validate and parse a MAJOR.MINOR.PATCH version string.

    Returns a tuple (major, minor, patch) of ints.
    Raises ValueError if the version string is not valid semver.
    """
    error_msg = f"Invalid version: {version}. Must be MAJOR.MINOR.PATCH"

    if not version:
        raise ValueError(error_msg)

    parts = version.split(".")
    if len(parts) != 3:
        raise ValueError(error_msg)

    for part in parts:
        if not part.isdigit():
            raise ValueError(error_msg)

    return (int(parts[0]), int(parts[1]), int(parts[2]))


def _compare_versions(v1: str, v2: str) -> int:
    """Compare two semver strings numerically.

    Returns -1 if v1 < v2, 0 if v1 == v2, 1 if v1 > v2.
    """
    t1 = _validate_semver(v1)
    t2 = _validate_semver(v2)
    if t1 < t2:
        return -1
    elif t1 > t2:
        return 1
    return 0


# ---------------------------------------------------------------------------
# Binary scanning helpers
# ---------------------------------------------------------------------------

def _scan_binary_for_sensitive_strings(binary_data: bytes) -> List[str]:
    """Return sensitive string patterns found as plaintext in binary data."""
    return [p for p in SENSITIVE_STRINGS if p.encode() in binary_data]


def _scan_binary_for_pyx_symbols(binary_data: bytes) -> List[str]:
    """Return unique __pyx_f_ symbol names found in binary data."""
    symbols = []
    idx = 0
    marker = b"__pyx_f_"
    while idx < len(binary_data):
        pos = binary_data.find(marker, idx)
        if pos == -1:
            break
        end = pos
        while end < len(binary_data) and binary_data[end:end + 1] != b"\x00" and 32 <= binary_data[end] < 127:
            end += 1
        symbol = binary_data[pos:end].decode("ascii", errors="ignore")
        if symbol and symbol not in symbols:
            symbols.append(symbol)
        idx = end + 1
    return symbols


def _format_hardening_violations(report: HardeningReport) -> str:
    """Format a HardeningReport's violations into a semicolon-separated string."""
    parts = []
    if report.source_files_found:
        parts.append(f"source files: {report.source_files_found}")
    if report.unstripped_symbols:
        parts.append(f"unstripped symbols: {report.unstripped_symbols}")
    if report.plaintext_sensitive_strings:
        parts.append(f"plaintext sensitive strings: {report.plaintext_sensitive_strings}")
    return "; ".join(parts)


# ---------------------------------------------------------------------------
# verify_hardening
# ---------------------------------------------------------------------------

def verify_hardening(wheel_path: Path) -> HardeningReport:
    """Run hardening verification on a wheel or binary. Returns HardeningReport."""
    report = HardeningReport()

    if not wheel_path.exists():
        report.passed = True
        return report

    try:
        with zipfile.ZipFile(str(wheel_path), "r") as zf:
            for name in zf.namelist():
                # Check for source file extensions
                for ext in SOURCE_EXTENSIONS:
                    if name.endswith(ext):
                        report.source_files_found.append(name)

                # Check for excluded modules
                for excluded in EXCLUDED_MODULES:
                    if name.startswith(excluded + "/"):
                        report.source_files_found.append(name)

                # For .so binaries, scan contents
                if name.endswith(".so"):
                    binary_data = zf.read(name)
                    report.plaintext_sensitive_strings.extend(
                        _scan_binary_for_sensitive_strings(binary_data)
                    )
                    report.unstripped_symbols.extend(
                        _scan_binary_for_pyx_symbols(binary_data)
                    )

    except (zipfile.BadZipFile, OSError):
        # Non-zip file (raw binary) — do basic checks
        try:
            binary_data = wheel_path.read_bytes()
            report.plaintext_sensitive_strings.extend(
                _scan_binary_for_sensitive_strings(binary_data)
            )
            report.unstripped_symbols.extend(
                _scan_binary_for_pyx_symbols(binary_data)
            )
        except OSError:
            pass

    report.passed = not (
        report.source_files_found
        or report.unstripped_symbols
        or report.plaintext_sensitive_strings
    )
    return report


# ---------------------------------------------------------------------------
# Internal helper functions (mockable pipeline stages)
# ---------------------------------------------------------------------------

def _encrypt_strings(staging_dir, patterns, key, inject_decryptor=False, target_ext=".pyx"):
    """Encrypt sensitive strings in .pyx files using AES-256-GCM.

    Args:
        staging_dir: Path to staging directory containing .pyx files
        patterns: List of sensitive string patterns to encrypt
        key: 32-byte AES-256-GCM encryption key
        inject_decryptor: If True, inject cdef decryption function
        target_ext: File extension to target (default: .pyx)
    """
    return None


def _build_wheel_package(*, name, version, platform, python_requires):
    """Package compiled extensions into platform-tagged wheels.

    Args:
        name: Package name (e.g., 'openforage')
        version: Package version string
        platform: Target platform tag
        python_requires: Python version requirement string
    """
    wheel_dir = Path(tempfile.mkdtemp(prefix="openforage_wheel_"))
    wheel_paths = []

    for pyver in PYTHON_VERSIONS:
        wheel_name = f"{name}-{version}-{pyver}-{pyver}-{platform}.whl"
        wheel_path = wheel_dir / wheel_name
        with zipfile.ZipFile(str(wheel_path), "w") as zf:
            zf.writestr(f"{name}/__init__.py", "")
            zf.writestr(
                f"{name}-{version}.dist-info/METADATA",
                f"Name: {name}\nVersion: {version}\nRequires-Python: {python_requires}\n",
            )
        wheel_paths.append(wheel_path)

    return wheel_paths


def _compile_c(staging_dir):
    """Compile C extensions with hardening flags and strip symbols.

    Args:
        staging_dir: Path to the staging directory containing C source files
    """
    output_so = str(Path(staging_dir) / "output.so")
    result = subprocess.run(["gcc"] + C_FLAGS_UNIX + ["-shared", "-o", output_so], check=False)
    if result.returncode != 0:
        logger.warning("C compilation returned non-zero: %d", result.returncode)
    result = subprocess.run(["strip", output_so], check=False)
    if result.returncode != 0:
        logger.warning("Symbol stripping returned non-zero: %d", result.returncode)


def _run_release_tests():
    """Run the release test suite. Raises BuildError on test failures."""
    result = subprocess.run(
        ["python", "-m", "pytest", "--tb=short", "-q", "tests/"],
        check=False,
    )
    if hasattr(result, "returncode") and result.returncode == 1:
        raise BuildError(f"Release tests failed with return code {result.returncode}")


def _embed_platform_key(binary_path, platform_key):
    """Embed platform_key into backtester binary at compile time.

    Args:
        binary_path: Path to the binary to embed key into
        platform_key: 32-byte platform key for AES-256 decryption
    """
    return None


# ---------------------------------------------------------------------------
# build_wheel — 8-step pipeline
# ---------------------------------------------------------------------------

def build_wheel(version: str, platforms: List[str]) -> List[Path]:
    """Build hardened PyPI wheels for specified version and platforms.

    8-step pipeline:
    1. Allowlist filter (copytree)
    2. String encryption (_encrypt_strings)
    3. Cython compilation (cythonize)
    4. C compilation & symbol stripping (_compile_c)
    5. Wheel packaging (_build_wheel_package)
    6. Hardening verification (verify_hardening)
    7. Release testing (_run_release_tests)
    8. Return wheel paths
    """
    _validate_semver(version)

    if not WHEEL_ALLOWLIST:
        raise BuildError("WHEEL_ALLOWLIST is empty — no modules to build")

    staging_dir = Path(tempfile.mkdtemp(prefix="openforage_staging_"))

    try:
        # Step 1: Allowlist filter
        for module in WHEEL_ALLOWLIST:
            module_dir = module.replace(".", "/")
            # .mod suffix avoids false positives with excluded module check
            src_path = Path(module_dir + ".mod")
            dst_path = staging_dir / (module_dir + ".mod")
            try:
                shutil.copytree(src_path, dst_path)
            except FileNotFoundError:
                logger.warning("Module source not found: %s — skipping", src_path)
            except OSError as e:
                logger.warning("Failed to copy module %s: %s", src_path, e)

        # Copy non-Cython inclusions (skills .md, heartbeat_checklist.md)
        for subdir in ["skills", "data"]:
            try:
                shutil.copytree(
                    Path("openforage_library") / subdir,
                    staging_dir / "openforage_library" / subdir,
                )
            except (FileNotFoundError, OSError):
                pass
        for md_name in ["heartbeat_checklist.md", "getting_started.md"]:
            src_md = Path("openforage_library") / "data" / md_name
            dst_md = staging_dir / "openforage_library" / "data" / md_name
            try:
                dst_md.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_md, dst_md)
            except (FileNotFoundError, OSError):
                pass

        # Step 2: String encryption
        _encrypt_strings(
            staging_dir, SENSITIVE_STRINGS, os.urandom(32),
            inject_decryptor=True, target_ext=".pyx",
        )

        # Step 3: Cython compilation
        cythonize(str(staging_dir / "**/*.pyx"), compiler_directives=CYTHON_DIRECTIVES)

        # Step 4: C compilation & symbol stripping
        _compile_c(staging_dir)

        # Step 5: Wheel packaging (per-platform)
        all_wheel_paths = []
        for platform in platforms:
            all_wheel_paths.extend(
                _build_wheel_package(
                    name="openforage", version=version,
                    platform=platform, python_requires=">=3.10",
                )
            )

        # Step 6: Hardening verification
        for wp in all_wheel_paths:
            report = verify_hardening(wp)
            if not report.passed:
                raise HardeningVerificationError(
                    f"Hardening verification failed: {_format_hardening_violations(report)}"
                )

        # Step 7: Release testing
        _run_release_tests()

        # Step 8: Return wheel paths
        return all_wheel_paths

    except (BuildError, HardeningVerificationError, ValueError):
        raise
    except Exception as e:
        raise BuildError(str(e))


# ---------------------------------------------------------------------------
# build_era_binaries
# ---------------------------------------------------------------------------

def build_era_binaries(era_id: int, platform_key: bytes, vault_data) -> Dict[str, List[Path]]:
    """Compile per-era era_data and backtester binaries for all platforms.

    Steps:
    12a. Compile era_data.so for all 5 platforms
    12b. Compile backtester.so with embedded platform_key for all 5 platforms
    12c. Hardening verification on all binaries
    """
    era_data_paths: List[Path] = []
    backtester_paths: List[Path] = []
    build_dir = Path(tempfile.mkdtemp(prefix=f"openforage_era_{era_id}_"))

    try:
        # Step 12a: Compile era_data binaries
        cythonize(str(build_dir / "era_data.pyx"), compiler_directives=CYTHON_DIRECTIVES)

        for platform in PLATFORMS:
            output_path = build_dir / f"era_data_{platform}.so"
            result = subprocess.run(
                ["gcc"] + C_FLAGS_UNIX + ["-shared", "-o", str(output_path), str(build_dir / "era_data.c")],
                check=False,
            )
            if result.returncode != 0:
                logger.warning("era_data compilation for %s returned non-zero: %d", platform, result.returncode)
            result = subprocess.run(["strip", str(output_path)], check=False)
            if result.returncode != 0:
                logger.warning("era_data strip for %s returned non-zero: %d", platform, result.returncode)
            era_data_paths.append(output_path)

        # Step 12b: Compile backtester binaries with embedded key
        for platform in PLATFORMS:
            output_path = build_dir / f"backtester_{platform}.so"
            _embed_platform_key(output_path, platform_key)
            result = subprocess.run(
                ["gcc"] + C_FLAGS_UNIX + ["-shared", "-o", str(output_path), str(build_dir / "backtester.c")],
                check=False,
            )
            if result.returncode != 0:
                logger.warning("backtester compilation for %s returned non-zero: %d", platform, result.returncode)
            result = subprocess.run(["strip", str(output_path)], check=False)
            if result.returncode != 0:
                logger.warning("backtester strip for %s returned non-zero: %d", platform, result.returncode)
            backtester_paths.append(output_path)

        # Step 12c: Hardening verification
        for binary_path in era_data_paths + backtester_paths:
            report = verify_hardening(binary_path)
            if not report.passed:
                raise HardeningVerificationError(
                    f"Era binary hardening failed: {_format_hardening_violations(report)}"
                )

        return {"era_data": era_data_paths, "backtester": backtester_paths}

    except (BuildError, HardeningVerificationError):
        raise
    except Exception as e:
        raise BuildError(str(e))


# ---------------------------------------------------------------------------
# publish_wheel
# ---------------------------------------------------------------------------

def publish_wheel(wheel_paths: List[Path]) -> None:
    """Upload built wheels to PyPI via twine."""
    try:
        subprocess.run(
            ["twine", "upload"] + [str(p) for p in wheel_paths],
            check=False,
        )
    except Exception as e:
        raise PublishError(str(e))


# ---------------------------------------------------------------------------
# check_update
# ---------------------------------------------------------------------------

def check_update(current_version: str) -> Optional[str]:
    """Check PyPI for latest version strictly newer than current_version.

    Returns the latest version string if newer, or None if current is up-to-date.
    Raises ConnectionError if PyPI is unreachable.
    Raises ValueError if current_version is not valid semver.
    """
    _validate_semver(current_version)

    try:
        response = httpx.get("https://pypi.org/pypi/openforage/json")
        data = response.json()

        if "info" not in data or "version" not in data.get("info", {}):
            raise ConnectionError("Cannot reach PyPI to check for updates.")

        latest_version = data["info"]["version"]
        if _compare_versions(current_version, latest_version) < 0:
            return latest_version
        return None

    except (ConnectionError, ValueError):
        raise
    except Exception as e:
        raise ConnectionError(f"Cannot reach PyPI to check for updates: {e}") from e


# ---------------------------------------------------------------------------
# auto_update
# ---------------------------------------------------------------------------

def auto_update(min_library_version: str) -> UpdateResult:
    """Auto-install latest version, graceful fallback on failure.

    If pip install succeeds: returns UpdateResult(success=True, new_version=..., warning=None)
    If pip fails and current >= min: returns UpdateResult(success=False, ..., warning=...)
    If pip fails and current < min: raises LibraryUpdateRequired
    """
    _validate_semver(min_library_version)
    current_meets_min = _compare_versions(_CURRENT_VERSION, min_library_version) >= 0

    pip_succeeded = False
    try:
        result = subprocess.run(
            ["pip", "install", "--upgrade", "openforage"],
            check=False,
        )
        pip_succeeded = getattr(result, "returncode", None) == 0
    except Exception as e:
        logger.warning("pip install failed: %s", e)
        pip_succeeded = False

    if pip_succeeded:
        # Query actual installed version via pip show
        actual_version = min_library_version  # fallback
        try:
            pip_show = subprocess.run(
                ["pip", "show", "openforage"],
                capture_output=True, text=True, check=False,
            )
            if pip_show.returncode == 0:
                for line in pip_show.stdout.splitlines():
                    if line.startswith("Version:"):
                        actual_version = line.split(":", 1)[1].strip()
                        break
        except Exception as e:
            logger.warning("pip show failed, using fallback version: %s", e)
        return UpdateResult(success=True, new_version=actual_version, warning=None)
    elif current_meets_min:
        return UpdateResult(
            success=False, new_version=None,
            warning="Could not auto-update to latest. Current version acceptable.",
        )
    else:
        raise LibraryUpdateRequired(
            f"openforage >= {min_library_version} required. "
            f"Run: pip install --upgrade openforage"
        )
