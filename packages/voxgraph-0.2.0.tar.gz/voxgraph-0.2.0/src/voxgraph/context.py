"""Context propagation for Voxgraph SDK using Python's ContextVar.

ContextVars provide async-safe, task-local storage. When used with asyncio,
each task gets its own copy of the context, preventing cross-contamination
between concurrent sessions (e.g. Agent A logs don't leak into Agent B's trace).

Usage:
    # The SDK sets context automatically; manual usage is also supported:
    with vox_turn_context(turn_id="item_abc", session_id="sess_123", job_id="job_456"):
        # All code inside this block sees these IDs
        ctx = get_current_turn()
        assert ctx.turn_id == "item_abc"
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Generator

__all__ = [
    "TurnContext",
    "vox_turn_context",
    "get_current_turn",
    "get_current_session_id",
    "get_current_turn_id",
]


@dataclass(frozen=True, slots=True)
class TurnContext:
    """Immutable snapshot of the current conversation turn context.

    Attributes:
        turn_id: Unique identifier for this conversation turn (maps to LiveKit item_id).
        session_id: Unique Voxgraph session identifier.
        job_id: LiveKit job identifier for this agent invocation.
    """

    turn_id: str
    session_id: str
    job_id: str


# Module-level ContextVar — single instance shared across entire process.
# Default is None when no turn context is active.
_current_turn: ContextVar[TurnContext | None] = ContextVar("vox_turn", default=None)


@contextmanager
def vox_turn_context(
    turn_id: str,
    session_id: str,
    job_id: str,
) -> Generator[TurnContext, None, None]:
    """Set the active turn context for the duration of a block.

    Uses token-based reset to ensure correct cleanup even if an exception occurs.
    This is critical — without the token reset, a failed turn would leave stale
    context for the next turn.

    Args:
        turn_id: Unique turn identifier.
        session_id: Voxgraph session ID.
        job_id: LiveKit job ID.

    Yields:
        The active TurnContext.
    """
    ctx = TurnContext(turn_id=turn_id, session_id=session_id, job_id=job_id)
    token = _current_turn.set(ctx)
    try:
        yield ctx
    finally:
        _current_turn.reset(token)


def get_current_turn() -> TurnContext | None:
    """Get the current turn context, or None if no turn is active."""
    return _current_turn.get()


def get_current_turn_id() -> str | None:
    """Convenience: get just the turn_id, or None."""
    ctx = _current_turn.get()
    return ctx.turn_id if ctx else None


def get_current_session_id() -> str | None:
    """Convenience: get just the session_id, or None."""
    ctx = _current_turn.get()
    return ctx.session_id if ctx else None
