"""Event-based interceptor for LiveKit AgentSession.

All session data (transcripts, tool calls, events, usage) is captured by
ctx.make_session_report() and sent via the /report endpoint at session end.
Real-time metrics_collected events are not used — the session report
provides aggregated usage totals (tokens, TTS chars, STT duration, etc.).

This module is kept as a thin no-op so the attach/detach interface remains
stable for future use.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from livekit.agents import AgentSession

__all__ = ["attach_listeners", "detach_listeners"]


def attach_listeners(session: "AgentSession") -> None:
    """No-op. All data is captured via ctx.make_session_report() at session end."""


def detach_listeners(session: "AgentSession") -> None:
    """No-op. Nothing was attached."""

