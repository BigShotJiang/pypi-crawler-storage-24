"""AudioRecorder — captures session audio via RecorderIO and uploads to S3.

Design principles:
- Uses LiveKit's built-in ``RecorderIO`` to intercept the AgentSession IO chain.
  This is the same mechanism LiveKit Cloud uses for its own session recordings.
- RecorderIO encodes a stereo Opus/OGG file via PyAV:
    * Left channel  = user microphone (session.input.audio)
    * Right channel = agent TTS output (session.output.audio)
- The OGG file is written to a local temp file during the session, then
  uploaded to S3 in a single PUT at session end via a presigned URL.
- Backend stays entirely out of the audio data path.
- recording_started_at is taken from RecorderIO.recording_started_at so the
  frontend can seek audio by timestamp.

Timing — why we hook BEFORE session.start():
  The AgentSession calls ``agent.on_enter()`` (which speaks the greeting)
  *inside* ``session.start()``, after RoomIO wires up the audio IO but still
  within the same ``asyncio.gather``.  Any wrapping done after
  ``await session.start()`` is too late — the agent's first utterance has
  already been encoded via the unwrapped IO chain and the recording will be
  missing that first speech.

  To capture all audio including the greeting we hook into the session's
  ``_on_audio_output_changed`` callback **before** ``session.start()`` is
  called.  The moment RoomIO sets ``session.output.audio`` our callback fires,
  we wrap both channels with RecorderIO right then, and we kick off the encode
  thread as a background task — all before the agent activity begins.

Quality vs. resilience tradeoff:
  RecorderIO produces Opus/OGG at 48 kHz stereo — the same codec and sample
  rate that LiveKit Egress uses. Quality is significantly better than the
  previous 16 kHz mono WAV approach. The tradeoff is that if the agent process
  crashes, the in-progress recording is lost (the temp file is incomplete).
  If recording reliability under crash conditions is required, use LiveKit
  Egress instead.

New dependency:
  ``av`` (PyAV) is required by RecorderIO for Opus encoding.
  Add to your environment: pip install av

API shape (called by VoxSession):
    recorder = AudioRecorder()
    # Must be called BEFORE session.start():
    recorder.attach(session, conversation_id, http_client, endpoint)
    await session.start(...)     # recorder auto-wires when audio IO is ready
    # ... call runs ...
    recording_url, started_at = await recorder.stop()
"""

from __future__ import annotations

import asyncio
import logging
import os
import pathlib
import tempfile
import time
from typing import Any

import httpx

# RecorderIO requires PyAV (av) for Opus encoding. Import at module level so
# tests can patch it via voxgraph.audio_recorder.RecorderIO.
try:
    from livekit.agents.voice.recorder_io import RecorderIO as _RecorderIO
except ImportError:
    _RecorderIO = None  # type: ignore[assignment,misc]


__all__ = ["AudioRecorder"]

logger = logging.getLogger("voxgraph.audio_recorder")

# Expose as module-level name so tests can patch it cleanly
RecorderIO = _RecorderIO  # noqa: N816

# Opus encoding sample rate — 48 kHz is the native WebRTC/LiveKit rate.
# No resampling step is needed; this is what RecorderIO uses internally.
_SAMPLE_RATE = 48_000


class AudioRecorder:
    """Captures session audio via RecorderIO and uploads to S3.

    Lifecycle:
        1. ``attach()`` — called BEFORE ``session.start()``.  Registers a hook
           on the AgentSession so that the moment RoomIO assigns
           ``session.output.audio`` our code intercepts both audio channels and
           wraps them with RecorderIO.
        2. RecorderIO accumulates ``AudioFrame`` objects from both channels
           in real-time and encodes them with PyAV + Opus.
        3. ``stop()`` — closes RecorderIO (flushes encoder), uploads the
           completed OGG file to S3, deletes the temp file, returns
           (recording_url, recording_started_at).
    """

    def __init__(self) -> None:
        self._conversation_id: str = ""
        self._http_client: httpx.AsyncClient | None = None
        self._endpoint: str = ""

        self._recorder_io: Any | None = None
        self._tmp_path: pathlib.Path | None = None
        self._started_at: float | None = None

        # True once the RecorderIO encode thread has been launched
        self._attached: bool = False
        self._wired: bool = False
        self._stopped: bool = False

    # ─────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────

    def attach(
        self,
        session: Any,
        conversation_id: str,
        http_client: httpx.AsyncClient,
        endpoint: str,
    ) -> None:
        """Register a hook so RecorderIO wires itself when audio IO is ready.

        Must be called **before** ``session.start()`` so that the hook fires
        on the very first assignment to ``session.output.audio`` (which happens
        inside ``RoomIO.start()`` inside ``session.start()``).

        The hook replaces the session's internal ``_on_audio_output_changed``
        callback with our own chained version.  When it fires we:
          1. Save the original callback so it still runs normally.
          2. Wrap both ``session.input.audio`` and ``session.output.audio``
             with ``RecorderIO``.
          3. Schedule ``recorder_io.start()`` as an asyncio task so the encode
             thread starts immediately — before the agent activity begins.

        Args:
            session: The LiveKit ``AgentSession`` to observe.
            conversation_id: Voxgraph conversation UUID (used as S3 key).
            http_client: Shared ``httpx.AsyncClient`` from ``TelemetrySender``.
            endpoint: Voxgraph backend base URL.
        """
        if self._attached:
            logger.warning("AudioRecorder.attach() called twice — ignoring")
            return

        if RecorderIO is None:
            logger.error(
                "AudioRecorder: livekit.agents.voice.recorder_io not available. "
                "Ensure livekit-agents>=1.0 and 'av' (PyAV) are installed."
            )
            return

        self._conversation_id = conversation_id
        self._http_client = http_client
        self._endpoint = endpoint.rstrip("/")
        self._started_at = time.time()
        self._attached = True

        # Create temp file now so that on_audio_output_changed can use it
        tmp_fd, tmp_str = tempfile.mkstemp(suffix=".ogg", prefix=f"vox_{conversation_id[:8]}_")
        os.close(tmp_fd)  # RecorderIO will open it itself via PyAV
        self._tmp_path = pathlib.Path(tmp_str)

        # ── Hook the session's _on_audio_output_changed ───────────────────────
        # AgentOutput calls this whenever session.output.audio is assigned.
        # We chain our wrapping logic in front of the original handler.
        # We hook into AgentOutput._audio_changed which is called
        # exactly when the audio output stream is first attached by RoomIO.
        # We must patch session.output._audio_changed instead of
        # session._on_audio_output_changed because the callback is bound
        # at __init__ time.
        original_hook = getattr(session.output, "_audio_changed", None)

        def hooked_cb(*args: Any, **kwargs: Any) -> None:
            if original_hook:
                original_hook(*args, **kwargs)
                
            if not self._wired:
                self._wire_now(session)

        setattr(session.output, "_audio_changed", hooked_cb)
        logger.debug(
            "AudioRecorder attached hook to session.output._audio_changed (conversation=%s)",
            self._conversation_id
        )

    def _wire_now(self, session: Any) -> None:
        """Wrap the current session.input/output.audio with RecorderIO.

        Called by the hook exactly once, at the moment ``session.output.audio``
        is first assigned by RoomIO (or LiveKit's internal recorder).

        We schedule ``RecorderIO.start()`` as an asyncio task so the encode
        thread starts immediately in the background.
        """
        audio_input = getattr(getattr(session, "input", None), "audio", None)
        audio_output = getattr(getattr(session, "output", None), "audio", None)

        if audio_output is None:
            # audio_output might still be None if output.audio was cleared
            logger.debug("AudioRecorder: _wire_now called but session.output.audio is None — skipping")
            return

        if audio_input is None:
            logger.warning(
                "AudioRecorder: session.input.audio is None at hook time — "
                "user audio will not be recorded"
            )

        assert self._tmp_path is not None
        self._recorder_io = RecorderIO(agent_session=session, sample_rate=_SAMPLE_RATE)

        # Set _wired BEFORE assigning to session.output.audio.
        # The AgentOutput.audio setter fires _on_audio_output_changed() synchronously,
        # which re-enters our hook. If _wired were still False at that point we would
        # recurse infinitely. Setting it first breaks the cycle.
        self._wired = True

        if audio_input is not None:
            session.input.audio = self._recorder_io.record_input(audio_input)

        # Always wrap the output — this is the side that captures agent TTS
        session.output.audio = self._recorder_io.record_output(audio_output)

        # Start the encode thread as a background asyncio task. This mirrors
        # exactly what LiveKit's own AgentSession does for its internal recorder
        # (see agent_session.py lines 677-682: `asyncio.create_task(recorder_io.start(...))`).
        asyncio.create_task(
            self._recorder_io.start(output_path=self._tmp_path),
            name="voxgraph-audio-encode",
        )

        logger.info(
            "AudioRecorder wired (conversation=%s, tmp=%s)",
            self._conversation_id, self._tmp_path,
        )

    async def stop(self) -> tuple[str | None, float | None]:
        """Flush encoder, upload OGG to S3, clean up. Returns (url, started_at).

        Safe to call even if ``attach()`` was never called or failed.
        """
        if self._stopped or not self._wired or self._recorder_io is None:
            return None, None
        self._stopped = True

        # Close RecorderIO — flushes the PyAV encoder and closes the OGG file
        try:
            await self._recorder_io.aclose()
        except Exception:
            logger.exception("AudioRecorder: error closing RecorderIO")

        # Take recording_started_at from RecorderIO (wall time of first audio frame)
        started_at = (
            self._recorder_io.recording_started_at
            if self._recorder_io.recording_started_at is not None
            else self._started_at
        )

        # Upload the completed OGG file to S3
        recording_url = await self._upload_ogg()

        # Delete temp file regardless of upload success
        if self._tmp_path is not None:
            try:
                self._tmp_path.unlink(missing_ok=True)
            except Exception:
                logger.warning("AudioRecorder: could not delete temp file %s", self._tmp_path)
            self._tmp_path = None

        logger.info(
            "AudioRecorder stopped (conversation=%s, url=%s, started_at=%s)",
            self._conversation_id, recording_url, started_at,
        )
        return recording_url, started_at

    # ─────────────────────────────────────────────────────────────────
    # S3 upload
    # ─────────────────────────────────────────────────────────────────

    async def _get_presigned_upload_url(self) -> tuple[str | None, str | None]:
        """POST /recording/presigned-url → (presigned_put_url, recording_url)."""
        if not self._http_client:
            logger.error("AudioRecorder: http client is None, cannot fetch presigned URL")
            return None, None

        logger.debug("AudioRecorder: requesting presigned URL for conversation %s", self._conversation_id)
        try:
            resp = await self._http_client.post(
                f"{self._endpoint}/api/v1/monitoring/call-logs/recording/presigned-url",
                json={"conversation_id": self._conversation_id},
            )
            if resp.status_code < 400:
                data = resp.json()
                return data.get("presigned_put_url"), data.get("recording_url")
            logger.error(
                "AudioRecorder: presigned URL endpoint returned %d: %s",
                resp.status_code, resp.text[:200],
            )
        except Exception:
            logger.exception("AudioRecorder: failed to get presigned upload URL")
        return None, None

    async def _upload_ogg(self) -> str | None:
        """Stream the OGG temp file directly to S3 via a presigned URL (256 KB chunks)."""
        if self._tmp_path is None or not self._tmp_path.exists():
            logger.error("AudioRecorder: temp file missing at upload time — no recording")
            return None

        if self._tmp_path.stat().st_size == 0:
            logger.error("AudioRecorder: temp file is empty — no audio was recorded")
            return None

        presigned_url, recording_url = await self._get_presigned_upload_url()
        if not presigned_url:
            logger.error("AudioRecorder: no presigned URL returned — recording not uploaded")
            return None

        logger.debug("AudioRecorder: uploading %s for conversation %s", self._tmp_path, self._conversation_id)
        try:
            def _iter_file(path: pathlib.Path, chunk_size: int = 1024 * 256):
                """Yield the file in 256 KB chunks to avoid loading it all into RAM."""
                with path.open("rb") as fh:
                    while True:
                        chunk = fh.read(chunk_size)
                        if not chunk:
                            break
                        yield chunk

            async with httpx.AsyncClient(timeout=120.0) as s3_client:
                resp = await s3_client.put(
                    presigned_url,
                    content=_iter_file(self._tmp_path),
                    headers={"Content-Type": "audio/ogg"},
                )
            if resp.status_code in (200, 201):
                return recording_url
            logger.error(
                "AudioRecorder: S3 PUT returned %d: %s",
                resp.status_code, resp.text[:200],
            )
        except Exception:
            logger.exception("AudioRecorder: error uploading OGG to S3")

        return None
