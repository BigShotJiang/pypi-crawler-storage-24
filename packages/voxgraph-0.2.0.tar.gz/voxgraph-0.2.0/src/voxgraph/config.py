"""Voxgraph SDK configuration.

The backend endpoint is hardcoded — all SDK data is sent exclusively to
the Voxgraph backend. Users cannot override this.

Only api_key is required. agent_id and environment are optional.
"""

from __future__ import annotations

import os
import warnings
from dataclasses import dataclass, field

__all__ = ["VoxConfig", "load_config"]

# Fixed production endpoint — never changes, never overridable by callers.
ENDPOINT = "https://api.voxgraph.io"


@dataclass(frozen=True, slots=True)
class VoxConfig:
    """Immutable SDK configuration.

    The endpoint is hardcoded to the Voxgraph backend. Only the API key
    needs to be provided by the user.
    """

    api_key: str = ""
    agent_id: str = ""
    environment: str = "main"  # Prompt branch: "main", "dev", "staging", etc.
    endpoint: str = ENDPOINT   # Internal — always ENDPOINT, never user-supplied
    batch_size: int = 50
    flush_interval_s: float = 1.0
    max_buffer_size: int = 1000
    max_retries: int = 3
    request_timeout_s: float = 10.0
    debug: bool = False         # Internal — set via VOXGRAPH_DEBUG env var only
    tags: dict[str, str] = field(default_factory=dict)


def load_config(
    *,
    api_key: str | None = None,
    agent_id: str | None = None,
    environment: str | None = None,
    tags: dict[str, str] | None = None,
) -> VoxConfig:
    """Create a VoxConfig from explicit arguments, falling back to env vars.

    Users provide: api_key, agent_id, environment.
    The backend endpoint is always ``https://api.voxgraph.io`` and cannot
    be overridden.

    Supported env vars (fallback when the kwarg is not supplied):
        VOXGRAPH_API_KEY      — API key for the Voxgraph backend (required)
        VOXGRAPH_AGENT_ID     — UUID of the voice AI agent (optional)
        VOXGRAPH_ENVIRONMENT  — Prompt branch, default "main" (optional)
        VOXGRAPH_DEBUG        — SDK debug logging; "1"/"true"/"yes" (optional)
    """
    debug = os.environ.get("VOXGRAPH_DEBUG", "").lower() in ("1", "true", "yes")
    resolved_key = api_key or os.environ.get("VOXGRAPH_API_KEY", "")
    if not resolved_key:
        warnings.warn(
            "Voxgraph SDK: no API key provided. Set api_key= or VOXGRAPH_API_KEY. "
            "All telemetry will be silently discarded until a valid key is supplied.",
            UserWarning,
            stacklevel=3,
        )
    return VoxConfig(
        api_key=resolved_key,
        agent_id=agent_id or os.environ.get("VOXGRAPH_AGENT_ID", ""),
        environment=environment or os.environ.get("VOXGRAPH_ENVIRONMENT", "main"),
        endpoint=ENDPOINT,      # Hardcoded — no env var override allowed
        debug=debug,
        tags=tags or {},
    )
