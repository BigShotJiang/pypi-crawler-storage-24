"""LiveKit version compatibility checks.

The SDK relies on public APIs from livekit-agents that were stabilized in v1.0.
This module warns early if an incompatible version is detected, and exposes
version-gate helpers used throughout the SDK to branch between API generations.
"""

from __future__ import annotations

import logging
import warnings

__all__ = [
    "check_livekit_version",
    "livekit_version",
    "livekit_has_model_usage_collector",
]

logger = logging.getLogger("voxgraph.compat")

_MIN_VERSION = (1, 0, 0)
_MAX_VERSION = (2, 0, 0)  # exclusive upper bound

# Sentinel: None means "not yet resolved".
_LIVEKIT_VERSION_CACHE: tuple[int, ...] | None = None
_LIVEKIT_VERSION_RESOLVED = False  # separate flag so (0,0,0) is a valid cache hit


def _parse_version(version_str: str) -> tuple[int, ...]:
    """Parse a version string like '1.4.2' into a tuple of ints."""
    parts: list[int] = []
    for part in version_str.split(".")[:3]:
        # Strip any pre-release suffixes (e.g., "1.4.2rc1" -> "1")
        clean = ""
        for ch in part:
            if ch.isdigit():
                clean += ch
            else:
                break
        if clean:
            parts.append(int(clean))
    return tuple(parts)


def livekit_version() -> tuple[int, ...]:
    """Return the installed livekit-agents version as a tuple of ints.

    The result is computed once and cached for the lifetime of the process.
    Returns ``(0, 0, 0)`` if the version cannot be determined.

    Example::

        if livekit_version() >= (1, 5, 0):
            ...  # use new API
    """
    global _LIVEKIT_VERSION_CACHE, _LIVEKIT_VERSION_RESOLVED

    if _LIVEKIT_VERSION_RESOLVED:
        return _LIVEKIT_VERSION_CACHE or (0, 0, 0)

    try:
        from importlib.metadata import version as _pkg_version

        ver_str = _pkg_version("livekit-agents")
        _LIVEKIT_VERSION_CACHE = _parse_version(ver_str)
    except Exception:
        logger.debug("Could not determine livekit-agents version; assuming (0, 0, 0).")
        _LIVEKIT_VERSION_CACHE = (0, 0, 0)

    _LIVEKIT_VERSION_RESOLVED = True
    return _LIVEKIT_VERSION_CACHE


def livekit_has_model_usage_collector() -> bool:
    """Return True when livekit-agents >= 1.5.0.

    In 1.5.0, ``UsageCollector`` was deprecated in favour of
    ``ModelUsageCollector`` which provides per-model/provider breakdowns.
    The SDK branches on this flag to use the appropriate collector without
    emitting deprecation warnings on newer installs.

    Returns:
        True  → use ``ModelUsageCollector`` (livekit-agents >= 1.5.0)
        False → use legacy ``UsageCollector`` (livekit-agents 1.0–1.4.x)
    """
    return livekit_version() >= (1, 5, 0)


def check_livekit_version() -> None:
    """Check that installed livekit-agents version is compatible.

    Emits a warning (not an error) if version is outside the supported range.
    This allows the SDK to still attempt to work — some features may degrade.
    """
    ver = livekit_version()
    ver_str = ".".join(str(x) for x in ver)

    if ver < _MIN_VERSION:
        warnings.warn(
            f"Voxgraph SDK requires livekit-agents>={'.'.join(map(str, _MIN_VERSION))}, "
            f"found {ver_str}. Some features may not work correctly.",
            UserWarning,
            stacklevel=3,
        )
    elif ver >= _MAX_VERSION:
        warnings.warn(
            f"Voxgraph SDK has not been tested with livekit-agents>="
            f"{'.'.join(map(str, _MAX_VERSION))}. You have {ver_str}. "
            f"Please upgrade voxgraph-sdk or check compatibility.",
            UserWarning,
            stacklevel=3,
        )
    else:
        logger.debug("livekit-agents %s is compatible with Voxgraph SDK.", ver_str)
