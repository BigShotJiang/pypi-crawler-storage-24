"""Tests for the no-op interceptor module.

The Voxgraph SDK uses a lean architecture where all session data
(transcripts, tool calls, events, usage) is captured via
``ctx.make_session_report()`` at session end. The interceptor was
simplified to a no-op; these tests confirm the interface is stable.
"""

from __future__ import annotations

from unittest.mock import MagicMock

from voxgraph.interceptor import attach_listeners, detach_listeners


class TestInterceptorNoOp:
    def test_attach_does_not_register_any_listeners(self, mock_session):
        """attach_listeners() is a no-op — it must not register event listeners."""
        attach_listeners(mock_session)
        mock_session.on.assert_not_called()

    def test_detach_does_not_remove_any_listeners(self, mock_session):
        """detach_listeners() is a no-op — it must not call session.off()."""
        detach_listeners(mock_session)
        mock_session.off.assert_not_called()

    def test_attach_then_detach_is_safe(self, mock_session):
        """Calling attach() then detach() must not raise, even for a fresh session."""
        attach_listeners(mock_session)
        detach_listeners(mock_session)

    def test_double_detach_is_safe(self, mock_session):
        """Calling detach() twice must not raise."""
        detach_listeners(mock_session)
        detach_listeners(mock_session)

    def test_attach_with_arbitrary_session(self):
        """attach_listeners() must accept any mock as session without error."""
        session = MagicMock()
        attach_listeners(session)  # must not raise
