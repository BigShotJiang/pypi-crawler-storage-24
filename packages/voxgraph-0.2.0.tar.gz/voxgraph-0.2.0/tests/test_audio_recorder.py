"""Tests for AudioRecorder — RecorderIO + PyAV + Opus implementation.

These tests cover the new shape where AudioRecorder is a thin wrapper around
LiveKit RecorderIO. RecorderIO and S3 interactions are mocked.

API shape under test:
  - ``attach(session, ...)``  — called BEFORE session.start(); registers hook
  - ``stop()``                — called at session end; flushes + uploads
"""

from __future__ import annotations

import pathlib
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch, call

import httpx
import pytest


# ── Helpers ────────────────────────────────────────────────────────


def _make_session() -> MagicMock:
    """Create a mock AgentSession with input/output audio chains.

    Critically, the mock also needs _on_audio_output_changed so that
    attach() can replace it with the chained hook.
    """
    session = MagicMock()
    session.input = MagicMock()
    session.input.audio = MagicMock(name="original_audio_input")
    session.output = MagicMock()
    session.output.audio = MagicMock(name="original_audio_output")
    # Simulate the private callback that AgentSession exposes
    session._on_audio_output_changed = MagicMock()
    return session


def _trigger_audio_output_changed(session: MagicMock) -> None:
    """Simulate RoomIO assigning session.output.audio, which fires the hook."""
    session.output._audio_changed()


def _make_recorder_io(started_at: float = 1741111111.0) -> MagicMock:
    """Create a mock RecorderIO that mimics the real API."""
    rio = MagicMock()
    rio.recording_started_at = started_at
    rio.record_input = MagicMock(return_value=MagicMock(name="wrapped_input"))
    rio.record_output = MagicMock(return_value=MagicMock(name="wrapped_output"))
    rio.start = AsyncMock()
    rio.aclose = AsyncMock()
    return rio


def _make_http_client(presigned_url: str = "https://s3.example.com/put") -> MagicMock:
    """Create a mock httpx.AsyncClient that returns a successful presigned URL response."""
    client = MagicMock()
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {
        "presigned_put_url": presigned_url,
        "recording_url": "https://cdn.voxgraph.ai/recordings/conv123.ogg",
    }
    client.post = AsyncMock(return_value=resp)
    return client


# ── attach() tests ────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_attach_wires_recorder_io_when_hook_fires():
    """attach() must intercept both session.input.audio and session.output.audio
    the moment the _on_audio_output_changed hook is triggered."""
    from voxgraph.audio_recorder import AudioRecorder

    session = _make_session()
    rio = _make_recorder_io()

    with patch("voxgraph.audio_recorder.RecorderIO", return_value=rio), \
         patch("voxgraph.audio_recorder.tempfile.mkstemp", return_value=(0, "/tmp/test.ogg")), \
         patch("voxgraph.audio_recorder.os.close"), \
         patch("voxgraph.audio_recorder.pathlib.Path", return_value=MagicMock()), \
         patch("voxgraph.audio_recorder.asyncio.create_task"):
        recorder = AudioRecorder()
        recorder.attach(
            session=session,
            conversation_id="conv123",
            http_client=_make_http_client(),
            endpoint="https://api.voxgraph.ai",
        )

        # At this point, only the hook is registered — nothing wired yet
        assert not recorder._wired

        # Simulate RoomIO triggering the hook
        _trigger_audio_output_changed(session)

    # RecorderIO.record_input / record_output called with original audio objects
    rio.record_input.assert_called_once()
    rio.record_output.assert_called_once()
    # Session IO chain was replaced
    assert session.input.audio == rio.record_input.return_value
    assert session.output.audio == rio.record_output.return_value
    # Recorder is now wired
    assert recorder._wired


@pytest.mark.asyncio
async def test_attach_starts_encode_thread_via_create_task():
    """When the hook fires, attach() must schedule RecorderIO.start() as an async task."""
    from voxgraph.audio_recorder import AudioRecorder

    session = _make_session()
    rio = _make_recorder_io()

    with patch("voxgraph.audio_recorder.RecorderIO", return_value=rio), \
         patch("voxgraph.audio_recorder.tempfile.mkstemp", return_value=(0, "/tmp/test.ogg")), \
         patch("voxgraph.audio_recorder.os.close"), \
         patch("voxgraph.audio_recorder.pathlib.Path", return_value=MagicMock()), \
         patch("voxgraph.audio_recorder.asyncio.create_task") as mock_create_task:
        recorder = AudioRecorder()
        recorder.attach(
            session=session,
            conversation_id="conv123",
            http_client=_make_http_client(),
            endpoint="https://api.voxgraph.ai",
        )
        _trigger_audio_output_changed(session)

    # create_task must have been called (encodes the start coroutine as a task)
    mock_create_task.assert_called_once()


@pytest.mark.asyncio
async def test_attach_hook_is_idempotent():
    """The hook must only wire RecorderIO once even if _on_audio_output_changed fires twice."""
    from voxgraph.audio_recorder import AudioRecorder

    session = _make_session()
    rio = _make_recorder_io()

    with patch("voxgraph.audio_recorder.RecorderIO", return_value=rio), \
         patch("voxgraph.audio_recorder.tempfile.mkstemp", return_value=(0, "/tmp/test.ogg")), \
         patch("voxgraph.audio_recorder.os.close"), \
         patch("voxgraph.audio_recorder.pathlib.Path", return_value=MagicMock()), \
         patch("voxgraph.audio_recorder.asyncio.create_task"):
        recorder = AudioRecorder()
        recorder.attach(
            session=session,
            conversation_id="conv123",
            http_client=_make_http_client(),
            endpoint="https://api.voxgraph.ai",
        )
        # Fire twice (e.g. once from RoomIO, once from LiveKit's own RecorderIO)
        _trigger_audio_output_changed(session)
        _trigger_audio_output_changed(session)

    # record_output should only have been called once
    rio.record_output.assert_called_once()


@pytest.mark.asyncio
async def test_attach_skips_if_recorder_io_not_available():
    """attach() must abort gracefully if RecorderIO is None (av not installed)."""
    from voxgraph.audio_recorder import AudioRecorder

    session = _make_session()

    with patch("voxgraph.audio_recorder.RecorderIO", None):
        recorder = AudioRecorder()
        recorder.attach(
            session=session,
            conversation_id="conv123",
            http_client=_make_http_client(),
            endpoint="https://api.voxgraph.ai",
        )

    # attach() should not raise; recorder._attached stays False (RecorderIO unavailable)
    assert not recorder._attached


# ── stop() tests ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_stop_returns_none_if_not_wired():
    """stop() before the hook fires must return (None, None) safely."""
    from voxgraph.audio_recorder import AudioRecorder

    recorder = AudioRecorder()
    url, started_at = await recorder.stop()

    assert url is None
    assert started_at is None


@pytest.mark.asyncio
async def test_stop_calls_aclose_and_uploads(tmp_path: pathlib.Path):
    """stop() must: aclose() RecorderIO, upload OGG, delete temp file, return url."""
    from voxgraph.audio_recorder import AudioRecorder

    # Write a fake OGG file
    tmp_ogg = tmp_path / "test.ogg"
    tmp_ogg.write_bytes(b"OGG_FAKE_CONTENT")

    session = _make_session()
    rio = _make_recorder_io(started_at=1741111111.0)
    http_client = _make_http_client()

    # S3 PUT response
    s3_resp = MagicMock()
    s3_resp.status_code = 200

    recorder = AudioRecorder()
    recorder._wired = True
    recorder._stopped = False
    recorder._recorder_io = rio
    recorder._tmp_path = tmp_ogg
    recorder._conversation_id = "conv123"
    recorder._http_client = http_client
    recorder._endpoint = "https://api.voxgraph.ai"

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client_inst = AsyncMock()
        mock_client_inst.__aenter__ = AsyncMock(return_value=mock_client_inst)
        mock_client_inst.__aexit__ = AsyncMock(return_value=None)
        mock_client_inst.put = AsyncMock(return_value=s3_resp)
        mock_client_cls.return_value = mock_client_inst

        url, started_at = await recorder.stop()

    # RecorderIO flushed
    rio.aclose.assert_awaited_once()
    # Backend called for presigned URL
    http_client.post.assert_awaited_once()
    # S3 PUT issued
    mock_client_inst.put.assert_awaited_once()
    # URL returned
    assert url == "https://cdn.voxgraph.ai/recordings/conv123.ogg"
    assert started_at == 1741111111.0
    # Temp file deleted
    assert not tmp_ogg.exists()


@pytest.mark.asyncio
async def test_stop_returns_none_if_presigned_url_fails(tmp_path: pathlib.Path):
    """stop() must return (None, started_at) if the presigned URL request fails."""
    from voxgraph.audio_recorder import AudioRecorder

    tmp_ogg = tmp_path / "test.ogg"
    tmp_ogg.write_bytes(b"OGG_FAKE_CONTENT")

    rio = _make_recorder_io()

    http_client = MagicMock()
    fail_resp = MagicMock()
    fail_resp.status_code = 502
    fail_resp.text = "S3 error"
    http_client.post = AsyncMock(return_value=fail_resp)

    recorder = AudioRecorder()
    recorder._wired = True
    recorder._stopped = False
    recorder._recorder_io = rio
    recorder._tmp_path = tmp_ogg
    recorder._conversation_id = "conv123"
    recorder._http_client = http_client
    recorder._endpoint = "https://api.voxgraph.ai"

    url, started_at = await recorder.stop()

    assert url is None
    assert started_at == 1741111111.0  # still returns started_at even on failure


@pytest.mark.asyncio
async def test_stop_is_idempotent(tmp_path: pathlib.Path):
    """stop() called twice must only upload once."""
    from voxgraph.audio_recorder import AudioRecorder

    tmp_ogg = tmp_path / "test.ogg"
    tmp_ogg.write_bytes(b"OGG")

    rio = _make_recorder_io()
    http_client = _make_http_client()

    s3_resp = MagicMock()
    s3_resp.status_code = 200

    recorder = AudioRecorder()
    recorder._wired = True
    recorder._stopped = False
    recorder._recorder_io = rio
    recorder._tmp_path = tmp_ogg
    recorder._conversation_id = "conv123"
    recorder._http_client = http_client
    recorder._endpoint = "https://api.voxgraph.ai"

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client_inst = AsyncMock()
        mock_client_inst.__aenter__ = AsyncMock(return_value=mock_client_inst)
        mock_client_inst.__aexit__ = AsyncMock(return_value=None)
        mock_client_inst.put = AsyncMock(return_value=s3_resp)
        mock_client_cls.return_value = mock_client_inst

        await recorder.stop()
        url2, _ = await recorder.stop()  # second call

    # aclose only called once
    assert rio.aclose.await_count == 1
    # Second stop returns (None, None)
    assert url2 is None


# ── recording_started_at fallback ─────────────────────────────────


@pytest.mark.asyncio
async def test_stop_uses_fallback_started_at_when_recorder_io_has_none(tmp_path: pathlib.Path):
    """stop() must use self._started_at if RecorderIO.recording_started_at is None."""
    from voxgraph.audio_recorder import AudioRecorder

    tmp_ogg = tmp_path / "test.ogg"
    tmp_ogg.write_bytes(b"OGG")

    rio = _make_recorder_io()
    rio.recording_started_at = None  # RecorderIO didn't capture a start time

    http_client = _make_http_client()
    s3_resp = MagicMock()
    s3_resp.status_code = 200

    recorder = AudioRecorder()
    recorder._wired = True
    recorder._stopped = False
    recorder._recorder_io = rio
    recorder._tmp_path = tmp_ogg
    recorder._conversation_id = "conv123"
    recorder._http_client = http_client
    recorder._endpoint = "https://api.voxgraph.ai"
    recorder._started_at = 9999.0   # fallback value

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client_inst = AsyncMock()
        mock_client_inst.__aenter__ = AsyncMock(return_value=mock_client_inst)
        mock_client_inst.__aexit__ = AsyncMock(return_value=None)
        mock_client_inst.put = AsyncMock(return_value=s3_resp)
        mock_client_cls.return_value = mock_client_inst

        _, started_at = await recorder.stop()

    assert started_at == 9999.0
