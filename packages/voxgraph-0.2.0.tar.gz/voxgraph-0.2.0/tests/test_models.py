"""Tests for Pydantic v2 data models."""

from __future__ import annotations

import json

import pytest

from voxgraph.models import (
    LogEntry,
    LogLevel,
    SessionMeta,
)


class TestLogEntry:
    def test_defaults(self):
        entry = LogEntry(message="hello")
        assert entry.message == "hello"
        assert entry.level == LogLevel.INFO
        assert entry.turn_id is None
        assert entry.timestamp > 0

    def test_with_context(self):
        entry = LogEntry(
            message="test",
            turn_id="t1",
            session_id="s1",
            extra={"key": "value"},
        )
        assert entry.turn_id == "t1"
        assert entry.extra["key"] == "value"

    def test_json_roundtrip(self):
        entry = LogEntry(message="test", level=LogLevel.ERROR)
        data = entry.model_dump()
        restored = LogEntry.model_validate(data)
        assert restored.message == "test"
        assert restored.level == LogLevel.ERROR

    def test_frozen(self):
        entry = LogEntry(message="test")
        with pytest.raises(Exception):
            entry.message = "modified"  # type: ignore


class TestSessionMeta:
    def test_basic(self):
        meta = SessionMeta(
            session_id="vox_abc123",
            prompt_version="v2.1",
            tags={"env": "staging"},
        )
        assert meta.session_id == "vox_abc123"
        assert meta.tags["env"] == "staging"



    def test_json_roundtrip(self):
        meta = SessionMeta(session_id="vox_test", prompt_version="v1")
        data = json.loads(meta.model_dump_json())
        assert data["session_id"] == "vox_test"
        assert data["prompt_version"] == "v1"
