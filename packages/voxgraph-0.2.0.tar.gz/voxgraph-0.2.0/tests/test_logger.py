"""Tests for the structured logging handler."""

from __future__ import annotations

import logging

import pytest

from voxgraph.context import vox_turn_context
from voxgraph.logger import VoxLogHandler, install_vox_log_handler, uninstall_vox_log_handler
from voxgraph.models import LogEntry


class TestVoxLogHandler:
    """Tests for the VoxLogHandler."""

    def test_captures_log_with_context(self):
        captured: list[LogEntry] = []
        handler = VoxLogHandler(captured.append)

        test_logger = logging.getLogger("test.handler")
        test_logger.addHandler(handler)
        test_logger.setLevel(logging.DEBUG)

        try:
            with vox_turn_context("turn_1", "sess_1", "job_1"):
                test_logger.info("test message")

            assert len(captured) == 1
            assert captured[0].turn_id == "turn_1"
            assert captured[0].session_id == "sess_1"
            assert "test message" in captured[0].message
        finally:
            test_logger.removeHandler(handler)

    def test_captures_log_without_context(self):
        captured: list[LogEntry] = []
        handler = VoxLogHandler(captured.append)

        test_logger = logging.getLogger("test.no_context")
        test_logger.addHandler(handler)
        test_logger.setLevel(logging.DEBUG)

        try:
            test_logger.info("no context log")

            assert len(captured) == 1
            assert captured[0].turn_id is None
            assert captured[0].session_id is None
        finally:
            test_logger.removeHandler(handler)

    def test_respects_min_level(self):
        captured: list[LogEntry] = []
        handler = VoxLogHandler(captured.append, min_level=logging.WARNING)

        test_logger = logging.getLogger("test.level")
        test_logger.addHandler(handler)
        test_logger.setLevel(logging.DEBUG)

        try:
            test_logger.debug("debug — should be ignored")
            test_logger.info("info — should be ignored")
            test_logger.warning("warning — should be captured")

            assert len(captured) == 1
            assert "warning" in captured[0].message
        finally:
            test_logger.removeHandler(handler)

    def test_captures_extra_fields(self):
        captured: list[LogEntry] = []
        handler = VoxLogHandler(captured.append)

        test_logger = logging.getLogger("test.extra")
        test_logger.addHandler(handler)
        test_logger.setLevel(logging.DEBUG)

        try:
            test_logger.info("with extra", extra={"stock_id": 123})

            assert len(captured) == 1
            assert captured[0].extra.get("stock_id") == 123
        finally:
            test_logger.removeHandler(handler)

    def test_handler_never_crashes_application(self):
        """Even if the collector callback raises, the handler should not crash."""

        def bad_collector(entry: LogEntry) -> None:
            raise RuntimeError("Collector exploded!")

        handler = VoxLogHandler(bad_collector)

        test_logger = logging.getLogger("test.crash")
        test_logger.addHandler(handler)
        test_logger.setLevel(logging.DEBUG)

        try:
            # This should NOT raise
            test_logger.info("this should not crash")
        finally:
            test_logger.removeHandler(handler)


class TestInstallUninstall:
    def test_install_and_uninstall(self):
        captured: list[LogEntry] = []
        install_vox_log_handler(captured.append)

        root_logger = logging.getLogger()
        original_level = root_logger.level
        root_logger.setLevel(logging.INFO)  # root defaults to WARNING

        try:
            root_logger.info("test install")

            uninstall_vox_log_handler()

            root_logger.info("after uninstall — should not be captured")

            # Only the first message should be captured
            assert any("test install" in e.message for e in captured)
        finally:
            root_logger.setLevel(original_level)

    def test_reinstall_replaces_previous(self):
        first: list[LogEntry] = []
        second: list[LogEntry] = []

        install_vox_log_handler(first.append)
        install_vox_log_handler(second.append)  # should replace first

        logging.getLogger().info("goes to second")

        uninstall_vox_log_handler()

        assert len(first) == 0  # old handler was removed
