"""Shared test fixtures for Voxgraph SDK tests."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from voxgraph.config import VoxConfig, ENDPOINT
from voxgraph.telemetry import TelemetryCollector


@pytest.fixture
def vox_config() -> VoxConfig:
    """A test configuration with debug mode enabled."""
    return VoxConfig(
        api_key="test_key_123",
        endpoint=ENDPOINT,
        debug=True,
        batch_size=10,
        flush_interval_s=0.1,
        max_buffer_size=100,
    )


@pytest.fixture
def collector() -> TelemetryCollector:
    """A fresh TelemetryCollector for testing."""
    return TelemetryCollector(max_buffer_size=100)


@pytest.fixture
def mock_session() -> MagicMock:
    """A mock LiveKit AgentSession with EventEmitter behavior.

    Supports .on(event, callback) and .off(event, callback).
    """
    session = MagicMock()
    session._listeners: dict[str, list] = {}

    def on(event: str, callback):
        if event not in session._listeners:
            session._listeners[event] = []
        session._listeners[event].append(callback)

    def off(event: str, callback):
        if event in session._listeners:
            session._listeners[event] = [
                cb for cb in session._listeners[event] if cb is not callback
            ]

    def emit(event: str, *args):
        for cb in session._listeners.get(event, []):
            cb(*args)

    session.on = MagicMock(side_effect=on)
    session.off = MagicMock(side_effect=off)
    session.emit = emit
    session.start = AsyncMock()

    return session
