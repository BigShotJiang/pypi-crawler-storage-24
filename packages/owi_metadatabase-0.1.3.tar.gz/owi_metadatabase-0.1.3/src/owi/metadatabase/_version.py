"""Version information for owi.metadatabase package."""

__version__ = "0.1.3"
