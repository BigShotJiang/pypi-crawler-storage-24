"""AgentOpsClient - main entry point for the SDK.

Usage:
    from agent_ops_sdk import AgentOpsClient

    client = AgentOpsClient()  # default: OTLP → localhost:4317
    client.score("tcr", 0.95, trace_id="trace-123")
    client.shutdown()
"""

from __future__ import annotations

import json
import logging
from typing import Any

from opentelemetry import baggage, context, trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from agent_ops_sdk.config import load_config
from agent_ops_sdk.eval.auto_metrics import (
    TraceStats,
    error_rate,
    retry_rate,
    tool_efficiency,
    turns_to_completion,
    workflow_execution,
)
from agent_ops_sdk.eval.scorer import Scorer
from agent_ops_sdk.types import AgentOpsConfig, ScoreInput

logger = logging.getLogger("agent_ops_sdk.client")

# OTel Metrics (optional — graceful if import fails)
try:
    from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
        OTLPMetricExporter,
    )
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader

    _HAS_METRICS = True
except ImportError:  # pragma: no cover
    _HAS_METRICS = False

# OTel Logs (optional — graceful if import fails)
try:
    from opentelemetry.exporter.otlp.proto.grpc._log_exporter import (
        OTLPLogExporter,
    )
    from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
    from opentelemetry.sdk._logs.export import BatchLogRecordProcessor

    _HAS_LOGS = True
except ImportError:  # pragma: no cover
    _HAS_LOGS = False


class AgentOpsClient:
    """Main SDK client. Manages OTel TracerProvider, MeterProvider, LoggerProvider.

    Args:
        service_name: OTel service name (overrides env var).
        enabled: Enable/disable tracing (overrides env var).
        config: Pre-built AgentOpsConfig (ignores other kwargs if provided).
        otlp_endpoint: OTLP gRPC endpoint (overrides env var). Default: AKS OTel Collector.
        auto_instrument: Auto-patch OpenAI/Anthropic/Gemini for tracing.
        instrument_providers: Specific providers to patch (default: all).
        user_id: Default user ID propagated to all spans.
        session_id: Default session ID propagated to all spans.
        tenant_id: Default tenant/org ID propagated to all spans.
        request_id: Default request ID propagated to all spans.
        workflow_id: Default workflow ID propagated to all spans.
        metadata: Default metadata dict propagated to all spans.
        tags: Default tags list propagated to all spans.
    """

    def __init__(
        self,
        *,
        service_name: str | None = None,
        enabled: bool | None = None,
        config: AgentOpsConfig | None = None,
        otlp_endpoint: str | None = None,
        auto_instrument: bool = False,
        instrument_providers: list[str] | None = None,
        instrument_frameworks: bool | None = None,
        instrument_framework_list: list[str] | None = None,
        capture_content: bool = False,
        content_max_length: int = 10_000,
        user_id: str | None = None,
        session_id: str | None = None,
        tenant_id: str | None = None,
        request_id: str | None = None,
        workflow_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        register_globally: bool = True,
    ) -> None:
        self._config = config or load_config(
            service_name=service_name,
            enabled=enabled,
            otlp_endpoint=otlp_endpoint,
        )
        # 생성자 파라미터로 전달된 값을 config에 반영 (frozen dataclass → replace)
        from dataclasses import replace as _dc_replace
        _overrides: dict[str, Any] = {}
        if capture_content is not None and capture_content != self._config.capture_content:
            _overrides["capture_content"] = capture_content
        if content_max_length != self._config.content_max_length:
            _overrides["content_max_length"] = content_max_length
        if _overrides:
            self._config = _dc_replace(self._config, **_overrides)

        self._otlp_processor: BatchSpanProcessor | None = None
        self._provider: TracerProvider | None = None
        self._meter_provider: Any | None = None
        self._logger_provider: Any | None = None
        self._log_handler: Any | None = None

        effective_endpoint = self._config.otlp_endpoint or "http://otel-collector-opentelemetry-collector.observability.svc.cluster.local:4317"

        if self._config.enabled:
            try:
                resource = Resource.create({
                    "service.name": self._config.service_name,
                })
                self._provider = TracerProvider(resource=resource)

                self._setup_otlp_exporter(effective_endpoint)
                if register_globally:
                    try:
                        trace.set_tracer_provider(self._provider)
                    except RuntimeError:
                        logger.debug(
                            "Global TracerProvider already set; "
                            "using SDK-internal provider instead."
                        )

                if _HAS_METRICS:
                    self._setup_meter_provider(resource, effective_endpoint)

                if _HAS_LOGS:
                    self._setup_logger_provider(resource, effective_endpoint)

                self._scorer = Scorer()
            except Exception:
                logger.warning(
                    "Failed to initialize AgentOps SDK. "
                    "Tracing/scoring disabled. Your application will continue normally.",
                    exc_info=True,
                )
                self._otlp_processor = None
                self._provider = None
                self._meter_provider = None
                self._logger_provider = None
                self._scorer = Scorer()
        else:
            self._scorer = Scorer()

        # Auto-instrumentation (LLM providers)
        self._auto_instrumented: list[str] = []
        self._import_hook_instrumented = False
        if auto_instrument:
            from agent_ops_sdk.instrument.auto_instrument import (
                configure_content_capture,
                instrument_on_import,
                patch_all,
            )

            configure_content_capture(
                capture=self._config.capture_content,
                max_length=self._config.content_max_length,
            )
            self._auto_instrumented = patch_all(instrument_providers)
            instrument_on_import(instrument_providers)
            self._import_hook_instrumented = True

        # Auto-instrumentation (agent frameworks)
        _do_fw = instrument_frameworks if instrument_frameworks is not None else auto_instrument
        self._auto_fw_instrumented: list[str] = []
        if _do_fw:
            from agent_ops_sdk.instrument.auto_framework import patch_frameworks

            self._auto_fw_instrumented = patch_frameworks(instrument_framework_list)

        # Default baggage context (user_id, tenant_id, etc.)
        self._baggage_token: object | None = None
        self._setup_default_baggage(
            user_id=user_id,
            session_id=session_id,
            tenant_id=tenant_id,
            request_id=request_id,
            workflow_id=workflow_id,
            metadata=metadata,
            tags=tags,
        )

    def _setup_otlp_exporter(self, endpoint: str) -> None:
        """Add OTLP BatchSpanProcessor to the provider."""
        otlp_exporter = OTLPSpanExporter(
            endpoint=endpoint,
            headers=self._config.get_otlp_headers_dict() or None,
        )
        self._otlp_processor = BatchSpanProcessor(
            otlp_exporter,
            max_queue_size=self._config.max_queue_size,
            max_export_batch_size=self._config.max_export_batch_size,
            schedule_delay_millis=self._config.schedule_delay_millis,
        )
        self._provider.add_span_processor(self._otlp_processor)

    def _setup_meter_provider(self, resource: Resource, endpoint: str) -> None:
        """Set up OTel MeterProvider with OTLP exporter → Mimir."""
        from opentelemetry.sdk.metrics.export import AggregationTemporality
        from opentelemetry.sdk.metrics._internal.instrument import (
            Counter, Histogram, ObservableCounter,
            ObservableGauge, ObservableUpDownCounter, UpDownCounter,
        )

        # Prometheus/Mimir requires cumulative temporality
        cumulative = {
            cls: AggregationTemporality.CUMULATIVE
            for cls in (
                Counter, UpDownCounter, Histogram,
                ObservableCounter, ObservableUpDownCounter, ObservableGauge,
            )
        }
        metric_exporter = OTLPMetricExporter(
            endpoint=endpoint,
            preferred_temporality=cumulative,
        )
        metric_reader = PeriodicExportingMetricReader(metric_exporter)
        self._meter_provider = MeterProvider(
            resource=resource, metric_readers=[metric_reader],
        )
        # Initialize SDK-level metric instruments
        from agent_ops_sdk.telemetry.metrics import init_metrics
        init_metrics(self._meter_provider)

    def _setup_logger_provider(self, resource: Resource, endpoint: str) -> None:
        """Set up OTel LoggerProvider with OTLP exporter → Loki."""
        log_exporter = OTLPLogExporter(endpoint=endpoint)
        self._logger_provider = LoggerProvider(resource=resource)
        self._logger_provider.add_log_record_processor(
            BatchLogRecordProcessor(log_exporter),
        )
        # Bridge Python logging → OTel Logs
        self._log_handler = LoggingHandler(logger_provider=self._logger_provider)
        logging.getLogger("agent_ops_sdk").addHandler(self._log_handler)

    def _setup_default_baggage(
        self,
        *,
        user_id: str | None,
        session_id: str | None,
        tenant_id: str | None,
        request_id: str | None,
        workflow_id: str | None,
        metadata: dict[str, Any] | None,
        tags: list[str] | None,
    ) -> None:
        """Attach default baggage to the global OTel context."""
        pairs: list[tuple[str, str]] = []
        if user_id is not None:
            pairs.append(("agentops.user_id", user_id))
        if session_id is not None:
            pairs.append(("agentops.session_id", session_id))
        if tenant_id is not None:
            pairs.append(("agentops.tenant_id", tenant_id))
        if request_id is not None:
            pairs.append(("agentops.request_id", request_id))
        if workflow_id is not None:
            pairs.append(("agentops.workflow_id", workflow_id))
        if metadata is not None:
            pairs.append(("agentops.metadata", json.dumps(metadata)))
        if tags is not None:
            pairs.append(("agentops.tags", json.dumps(tags)))

        if not pairs:
            return

        ctx = context.get_current()
        for key, value in pairs:
            ctx = baggage.set_baggage(key, value, ctx)
        self._baggage_token = context.attach(ctx)

    @property
    def config(self) -> AgentOpsConfig:
        """Return the current configuration."""
        return self._config

    @property
    def tracer_provider(self) -> TracerProvider | None:
        """Return the SDK-internal TracerProvider."""
        return self._provider

    @property
    def meter_provider(self) -> Any | None:
        """Return the MeterProvider (or None if metrics not active)."""
        return self._meter_provider

    # ------------------------------------------------------------------
    # Manual score submission
    # ------------------------------------------------------------------

    def score(
        self,
        name: str,
        value: float | str | bool,
        *,
        trace_id: str,
        observation_id: str | None = None,
        comment: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Submit a score. Non-breaking."""
        score_input = ScoreInput(
            name=name,
            value=value,
            trace_id=trace_id,
            observation_id=observation_id,
            comment=comment,
            metadata=metadata or {},
        )
        self._scorer.submit_score(score_input)

    def score_batch(
        self,
        scores: list[dict[str, Any]],
        *,
        trace_id: str,
    ) -> None:
        """Submit multiple scores at once. Non-breaking."""
        for s in scores:
            self.score(
                name=s["name"],
                value=s["value"],
                trace_id=trace_id,
                observation_id=s.get("observation_id"),
                comment=s.get("comment"),
                metadata=s.get("metadata"),
            )

    # ------------------------------------------------------------------
    # Semi-auto metric helpers
    # ------------------------------------------------------------------

    def submit_tool_efficiency(self, stats: TraceStats, *, trace_id: str) -> float:
        value = tool_efficiency(stats)
        self.score("tool_efficiency", value, trace_id=trace_id)
        return value

    def submit_retry_rate(self, stats: TraceStats, *, trace_id: str) -> float:
        value = retry_rate(stats)
        self.score("retry_rate", value, trace_id=trace_id)
        return value

    def submit_error_rate(self, stats: TraceStats, *, trace_id: str) -> float:
        value = error_rate(stats)
        self.score("error_rate", value, trace_id=trace_id)
        return value

    def submit_turns_to_completion(self, stats: TraceStats, *, trace_id: str) -> int:
        value = turns_to_completion(stats)
        self.score("turns_to_completion", float(value), trace_id=trace_id)
        return value

    def submit_workflow_execution(self, stats: TraceStats, *, trace_id: str) -> str:
        value = workflow_execution(stats)
        self.score("workflow_execution", value, trace_id=trace_id)
        return value

    def submit_all_auto_metrics(self, stats: TraceStats, *, trace_id: str) -> dict[str, Any]:
        return {
            "tool_efficiency": self.submit_tool_efficiency(stats, trace_id=trace_id),
            "retry_rate": self.submit_retry_rate(stats, trace_id=trace_id),
            "error_rate": self.submit_error_rate(stats, trace_id=trace_id),
            "turns_to_completion": self.submit_turns_to_completion(stats, trace_id=trace_id),
            "workflow_execution": self.submit_workflow_execution(stats, trace_id=trace_id),
        }

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def flush(self) -> None:
        """Flush pending data."""
        if self._otlp_processor is not None:
            self._otlp_processor.force_flush()

    def shutdown(self) -> None:
        """Flush and shut down the SDK."""
        if self._auto_instrumented:
            from agent_ops_sdk.instrument.auto_instrument import unpatch_all

            unpatch_all()
            self._auto_instrumented = []
            self._import_hook_instrumented = False
        elif self._import_hook_instrumented:
            from agent_ops_sdk.instrument.auto_instrument import uninstrument_on_import

            uninstrument_on_import()
            self._import_hook_instrumented = False
        if self._auto_fw_instrumented:
            from agent_ops_sdk.instrument.auto_framework import unpatch_frameworks

            unpatch_frameworks()
            self._auto_fw_instrumented = []
        if self._baggage_token is not None:
            context.detach(self._baggage_token)
            self._baggage_token = None
        # Remove log handler before shutdown
        if self._log_handler is not None:
            logging.getLogger("agent_ops_sdk").removeHandler(self._log_handler)
            self._log_handler = None
        if self._logger_provider is not None:
            try:
                self._logger_provider.shutdown()
            except Exception:
                pass
            self._logger_provider = None
        if self._meter_provider is not None:
            try:
                self._meter_provider.shutdown()
            except Exception:
                pass
            self._meter_provider = None
        if self._provider is not None:
            try:
                self._provider.shutdown()
            except Exception:
                logger.debug("TracerProvider shutdown error", exc_info=True)
        logger.info("AgentOps SDK shut down")

    def __enter__(self) -> AgentOpsClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.shutdown()
