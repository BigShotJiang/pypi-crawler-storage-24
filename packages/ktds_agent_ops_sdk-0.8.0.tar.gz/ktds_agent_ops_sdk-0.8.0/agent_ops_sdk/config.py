"""AgentOps SDK 설정 로더.

우선순위: 명시적 kwargs > AGENTOPS_*/OTEL_* 환경변수 > 기본값.
"""

from __future__ import annotations

import logging
import os

from agent_ops_sdk.types import AgentOpsConfig

logger = logging.getLogger("agent_ops_sdk.config")


def _safe_int(env_key: str, default: int) -> int:
    """환경변수를 정수로 파싱. 유효하지 않으면 기본값 반환."""
    raw = os.environ.get(env_key)
    if raw is None:
        return default
    try:
        return int(raw)
    except (TypeError, ValueError):
        logger.warning(
            "%s='%s' 값이 유효하지 않음, 기본값 %d 사용", env_key, raw, default,
        )
        return default


def _parse_otlp_headers(raw: str) -> tuple[tuple[str, str], ...]:
    """OTEL_EXPORTER_OTLP_HEADERS 형식 파싱: 'k1=v1,k2=v2'."""
    if not raw:
        return ()
    pairs: list[tuple[str, str]] = []
    for pair in raw.split(","):
        pair = pair.strip()
        if "=" in pair:
            key, value = pair.split("=", 1)
            pairs.append((key.strip(), value.strip()))
    return tuple(pairs)


def load_config(**overrides: object) -> AgentOpsConfig:
    """환경변수 + 명시적 오버라이드에서 AgentOpsConfig를 생성.

    Args:
        **overrides: AgentOpsConfig 필드와 일치하는 키워드 인자.
            명시적 값이 최우선.

    Returns:
        불변 AgentOpsConfig 인스턴스.
    """
    env_values: dict[str, object] = {
        "service_name": os.environ.get("OTEL_SERVICE_NAME", "agent-ops-sdk"),
        "enabled": os.environ.get("AGENTOPS_ENABLED", "true").lower() == "true",
        "debug": os.environ.get("AGENTOPS_DEBUG", "false").lower() == "true",
        "max_export_batch_size": _safe_int("OTEL_BSP_MAX_EXPORT_BATCH_SIZE", 512),
        "max_queue_size": _safe_int("OTEL_BSP_MAX_QUEUE_SIZE", 2048),
        "schedule_delay_millis": _safe_int("OTEL_BSP_SCHEDULE_DELAY", 5000),
        "otlp_endpoint": os.environ.get(
            "OTEL_EXPORTER_OTLP_ENDPOINT",
            "http://otel-collector-opentelemetry-collector.observability.svc.cluster.local:4317",
        ),
        "otlp_headers": _parse_otlp_headers(
            os.environ.get("OTEL_EXPORTER_OTLP_HEADERS", ""),
        ),
        "capture_content": os.environ.get(
            "AGENTOPS_CAPTURE_CONTENT", "false",
        ).lower() == "true",
        "content_max_length": _safe_int("AGENTOPS_CONTENT_MAX_LENGTH", 10_000),
    }

    merged = {**env_values, **{k: v for k, v in overrides.items() if v is not None}}
    return AgentOpsConfig(**merged)
