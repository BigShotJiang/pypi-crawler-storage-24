"""AgentOps SDK 핵심 타입 정의.

SDK 전반에서 사용하는 Enum, 데이터클래스 등을 정의한다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ObservationType(str, Enum):
    """관측 타입 — 스팬의 의미론적 분류."""

    AGENT = "agent"
    TOOL = "tool"
    GENERATION = "generation"
    SPAN = "span"
    RETRIEVER = "retriever"
    EMBEDDING = "embedding"
    EVALUATOR = "evaluator"
    GUARDRAIL = "guardrail"


class ScoreDataType(str, Enum):
    """스코어 데이터 타입."""

    NUMERIC = "NUMERIC"
    CATEGORICAL = "CATEGORICAL"
    BOOLEAN = "BOOLEAN"


class CollectionMode(str, Enum):
    """메트릭 수집 방식."""

    AUTO = "AUTO"
    SEMI_AUTO = "SEMI_AUTO"
    MANUAL = "MANUAL"


class MetricCategory(str, Enum):
    """메트릭 카테고리 — 평가지표관리.md + agent_365평가지표.md 기준."""

    NATIVE = "native"
    AGENTIC = "agentic"
    DEEPEVAL = "deepeval"
    RAGAS = "ragas"
    USER_EFFECTIVENESS = "user_effectiveness"
    USER_EFFICIENCY = "user_efficiency"
    USER_SATISFACTION = "user_satisfaction"
    FOUNDRY_GENERAL = "foundry_general"
    FOUNDRY_TEXT_SIMILARITY = "foundry_text_similarity"
    FOUNDRY_RAG = "foundry_rag"
    FOUNDRY_RISK_SAFETY = "foundry_risk_safety"
    FOUNDRY_AGENT = "foundry_agent"


@dataclass(frozen=True)
class MetricDefinition:
    """평가 지표의 불변 정의.

    Attributes:
        name: 고유 지표 ID (snake_case).
        display_name: 사람이 읽을 수 있는 이름.
        data_type: 스코어 데이터 타입.
        category: 평가 카테고리.
        collection_mode: AUTO / SEMI_AUTO / MANUAL.
        min_value: 최소값 (NUMERIC 전용).
        max_value: 최대값 (NUMERIC 전용).
        threshold: 목표 임계값.
        description: 지표 설명.
        categories: CATEGORICAL 허용 값.
    """

    name: str
    display_name: str
    data_type: ScoreDataType
    category: MetricCategory
    collection_mode: CollectionMode = CollectionMode.MANUAL
    min_value: float | None = None
    max_value: float | None = None
    threshold: float | None = None
    description: str = ""
    categories: tuple[str, ...] = ()


@dataclass(frozen=True)
class ScoreInput:
    """스코어 제출 입력값.

    Attributes:
        name: 지표 이름 (MetricDefinition.name 또는 커스텀).
        value: 스코어 값 (float/str/bool).
        trace_id: 스코어를 연결할 trace ID.
        observation_id: trace 내 특정 관측 ID (선택).
        comment: 사람이 읽을 수 있는 코멘트 (선택).
        metadata: 추가 메타데이터 (선택).
    """

    name: str
    value: float | str | bool
    trace_id: str
    observation_id: str | None = None
    comment: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AgentOpsConfig:
    """SDK 설정 (OpenTelemetry OTLP).

    Attributes:
        service_name: OTel 서비스 이름 (OTEL_SERVICE_NAME).
        enabled: 트레이싱/스코어링 활성화 여부 (AGENTOPS_ENABLED).
        debug: 디버그 로깅 활성화 (AGENTOPS_DEBUG).
        max_export_batch_size: OTel BSP 최대 배치 크기.
        max_queue_size: OTel BSP 최대 큐 크기.
        schedule_delay_millis: OTel BSP 스케줄 지연(ms).
        otlp_endpoint: OTLP gRPC 엔드포인트.
        otlp_headers: OTLP 엑스포터 추가 헤더.
        capture_content: 프롬프트/응답 내용 캡처 여부 (기본 off, 민감 데이터 보호).
        content_max_length: 캡처할 최대 문자 수.
    """

    service_name: str = "agent-ops-sdk"
    enabled: bool = True
    debug: bool = False
    max_export_batch_size: int = 512
    max_queue_size: int = 2048
    schedule_delay_millis: int = 5000
    otlp_endpoint: str = "http://otel-collector-opentelemetry-collector.observability.svc.cluster.local:4317"
    otlp_headers: tuple[tuple[str, str], ...] = ()
    capture_content: bool = False
    content_max_length: int = 10_000

    def get_otlp_headers_dict(self) -> dict[str, str]:
        """otlp_headers를 변환 가능한 dict로 반환 (OTel 엑스포터 API용)."""
        return dict(self.otlp_headers)
