"""OTel Metrics instruments for AgentOps SDK.

Counters:
    agentops.tokens.input       - Input token count
    agentops.tokens.output      - Output token count
    agentops.llm.requests       - LLM request count
    agentops.tool.calls         - Tool invocation count
    agentops.errors             - Error count

Histograms:
    agentops.llm.latency        - LLM latency (ms)
    agentops.tool.latency       - Tool latency (ms)
    agentops.span.duration      - Span duration (ms)
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("agent_ops_sdk.telemetry")

_METER_NAME = "agent_ops_sdk"
_metrics_lock = threading.Lock()


@dataclass
class AgentOpsMetrics:
    """Container for all SDK metric instruments."""

    tokens_input: Any = None
    tokens_output: Any = None
    llm_requests: Any = None
    tool_calls: Any = None
    errors: Any = None
    llm_latency: Any = None
    tool_latency: Any = None
    span_duration: Any = None


_metrics: AgentOpsMetrics | None = None


def init_metrics(meter_provider: Any) -> AgentOpsMetrics:
    """Initialize metric instruments from a MeterProvider."""
    global _metrics

    with _metrics_lock:
        meter = meter_provider.get_meter(_METER_NAME)
        _metrics = AgentOpsMetrics(
            tokens_input=meter.create_counter(
                "agentops.tokens.input",
                description="Total input tokens consumed",
                unit="token",
            ),
            tokens_output=meter.create_counter(
                "agentops.tokens.output",
                description="Total output tokens consumed",
                unit="token",
            ),
            llm_requests=meter.create_counter(
                "agentops.llm.requests",
                description="Number of LLM requests",
            ),
            tool_calls=meter.create_counter(
                "agentops.tool.calls",
                description="Number of tool invocations",
            ),
            errors=meter.create_counter(
                "agentops.errors",
                description="Number of errors",
            ),
            llm_latency=meter.create_histogram(
                "agentops.llm.latency",
                description="LLM request latency",
                unit="ms",
            ),
            tool_latency=meter.create_histogram(
                "agentops.tool.latency",
                description="Tool invocation latency",
                unit="ms",
            ),
            span_duration=meter.create_histogram(
                "agentops.span.duration",
                description="Span duration",
                unit="ms",
            ),
        )
        return _metrics


def get_metrics() -> AgentOpsMetrics | None:
    """Return the current metrics instance, or None if not initialized."""
    return _metrics
