"""Telemetry module - OTel metrics instruments for AgentOps SDK."""

from agent_ops_sdk.telemetry.metrics import get_metrics, init_metrics

__all__ = ["get_metrics", "init_metrics"]
