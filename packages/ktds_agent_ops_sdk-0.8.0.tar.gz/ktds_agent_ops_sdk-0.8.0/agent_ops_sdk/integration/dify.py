"""Dify integration adapter.

Wraps Dify HTTP API calls and auto-creates generation spans
with token usage extracted from Dify response metadata.

Usage:
    from agent_ops_sdk.integration.dify import DifyClient

    dify = DifyClient(api_base="http://localhost/v1", api_key="app-xxx")

    @agent
    def my_agent(query):
        return dify.chat(query)  # → generation span auto-created
"""

from __future__ import annotations

import json
import logging
from typing import Any

import httpx
from opentelemetry import trace
from opentelemetry.trace import StatusCode

from agent_ops_sdk.instrument.context import _apply_baggage_to_span
from agent_ops_sdk.instrument.decorator import _get_tracer, _safe_serialize

logger = logging.getLogger("agent_ops_sdk.integration.dify")


class DifyClient:
    """Dify API client with automatic tracing.

    Each API call creates a generation span with:
    - gen_ai.usage.* token attributes (from Dify response metadata)
    - gen_ai.system = "dify"
    - Input query and full response captured
    """

    def __init__(
        self,
        api_base: str,
        api_key: str,
        *,
        user: str = "default",
        timeout: float = 120.0,
    ) -> None:
        self.api_base = api_base.rstrip("/")
        self.api_key = api_key
        self.user = user
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _extract_usage(self, data: dict) -> dict[str, Any]:
        """Extract gen_ai.usage attributes from Dify response metadata."""
        attrs: dict[str, Any] = {}
        usage = (data.get("metadata") or {}).get("usage") or {}
        if usage.get("prompt_tokens") is not None:
            attrs["gen_ai.usage.input_tokens"] = usage["prompt_tokens"]
        if usage.get("completion_tokens") is not None:
            attrs["gen_ai.usage.output_tokens"] = usage["completion_tokens"]
        if usage.get("total_tokens") is not None:
            attrs["gen_ai.usage.total_tokens"] = usage["total_tokens"]
        if usage.get("latency") is not None:
            attrs["dify.latency"] = usage["latency"]
        if usage.get("total_price") is not None:
            attrs["dify.total_price"] = str(usage["total_price"])
        if usage.get("currency") is not None:
            attrs["dify.currency"] = usage["currency"]
        return attrs

    def _extract_model(self, data: dict) -> str | None:
        """Try to extract model name from Dify response metadata."""
        retriever_from = (data.get("metadata") or {}).get("retriever_resources")
        # Dify doesn't always expose model name in chat response,
        # but workflow responses may have it in metadata
        model = (data.get("metadata") or {}).get("model")
        return model

    def chat(
        self,
        query: str,
        *,
        user: str | None = None,
        inputs: dict[str, Any] | None = None,
        conversation_id: str | None = None,
        files: list[dict] | None = None,
    ) -> dict:
        """Call Dify chat-messages API with automatic tracing.

        Creates a generation span with token usage from Dify response.
        """
        tracer = _get_tracer()
        with tracer.start_as_current_span("dify.chat") as span:
            _apply_baggage_to_span(span)

            # Build request
            body: dict[str, Any] = {
                "inputs": inputs or {},
                "query": query,
                "response_mode": "blocking",
                "user": user or self.user,
            }
            if conversation_id:
                body["conversation_id"] = conversation_id
            if files:
                body["files"] = files

            # Set span attributes
            span.set_attribute("agentops.observation_type", "generation")
            span.set_attribute("gen_ai.system", "dify")
            span.set_attribute("gen_ai.operation.name", "chat")
            span.set_attribute("agentops.input", _safe_serialize({"query": query}))

            try:
                with httpx.Client(timeout=self.timeout) as http:
                    resp = http.post(
                        f"{self.api_base}/chat-messages",
                        headers=self._headers(),
                        json=body,
                    )
                    resp.raise_for_status()
                    data = resp.json()

                # Extract and set token usage
                usage_attrs = self._extract_usage(data)
                for k, v in usage_attrs.items():
                    span.set_attribute(k, v)

                # Extract model if available
                model = self._extract_model(data)
                if model:
                    span.set_attribute("gen_ai.request.model", model)

                # Set response attributes
                span.set_attribute("agentops.output", _safe_serialize(data))
                span.set_attribute("dify.answer", data.get("answer", ""))
                span.set_attribute("dify.conversation_id", data.get("conversation_id", ""))
                span.set_attribute("dify.message_id", data.get("message_id", ""))

                return data

            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                raise

    def completion(
        self,
        inputs: dict[str, Any],
        *,
        user: str | None = None,
        files: list[dict] | None = None,
    ) -> dict:
        """Call Dify completion-messages API with automatic tracing."""
        tracer = _get_tracer()
        with tracer.start_as_current_span("dify.completion") as span:
            _apply_baggage_to_span(span)

            body: dict[str, Any] = {
                "inputs": inputs,
                "response_mode": "blocking",
                "user": user or self.user,
            }
            if files:
                body["files"] = files

            span.set_attribute("agentops.observation_type", "generation")
            span.set_attribute("gen_ai.system", "dify")
            span.set_attribute("gen_ai.operation.name", "completion")
            span.set_attribute("agentops.input", _safe_serialize(inputs))

            try:
                with httpx.Client(timeout=self.timeout) as http:
                    resp = http.post(
                        f"{self.api_base}/completion-messages",
                        headers=self._headers(),
                        json=body,
                    )
                    resp.raise_for_status()
                    data = resp.json()

                usage_attrs = self._extract_usage(data)
                for k, v in usage_attrs.items():
                    span.set_attribute(k, v)

                span.set_attribute("agentops.output", _safe_serialize(data))
                span.set_attribute("dify.answer", data.get("answer", ""))

                return data

            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                raise

    def workflow(
        self,
        inputs: dict[str, Any],
        *,
        user: str | None = None,
        files: list[dict] | None = None,
    ) -> dict:
        """Call Dify workflow run API with automatic tracing."""
        tracer = _get_tracer()
        with tracer.start_as_current_span("dify.workflow") as span:
            _apply_baggage_to_span(span)

            body: dict[str, Any] = {
                "inputs": inputs,
                "response_mode": "blocking",
                "user": user or self.user,
            }
            if files:
                body["files"] = files

            span.set_attribute("agentops.observation_type", "generation")
            span.set_attribute("gen_ai.system", "dify")
            span.set_attribute("gen_ai.operation.name", "workflow")
            span.set_attribute("agentops.input", _safe_serialize(inputs))

            try:
                with httpx.Client(timeout=self.timeout) as http:
                    resp = http.post(
                        f"{self.api_base}/workflows/run",
                        headers=self._headers(),
                        json=body,
                    )
                    resp.raise_for_status()
                    data = resp.json()

                usage_attrs = self._extract_usage(data)
                for k, v in usage_attrs.items():
                    span.set_attribute(k, v)

                span.set_attribute("agentops.output", _safe_serialize(data))

                return data

            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                raise
