"""LangChain callback integration for AgentOps SDK."""

from __future__ import annotations

from typing import Any

from opentelemetry import trace
from opentelemetry.trace import StatusCode

from agent_ops_sdk.instrument.decorator import _apply_llm_attributes, _safe_serialize

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
except Exception:  # pragma: no cover - optional dependency
    class BaseCallbackHandler:  # type: ignore[override]
        """Fallback when langchain is not installed."""


class LangChainCallbackHandler(BaseCallbackHandler):
    """Create AgentOps spans from LangChain callback lifecycle events."""

    def __init__(self) -> None:
        super().__init__()
        self._tracer = trace.get_tracer("agent_ops_sdk.integration.langchain")
        self._active_spans: dict[str, trace.Span] = {}

    def _start_span(
        self,
        *,
        run_id: Any,
        name: str,
        observation_type: str,
        payload: Any = None,
        parent_run_id: Any = None,
    ) -> None:
        parent_span = self._active_spans.get(str(parent_run_id)) if parent_run_id is not None else None
        if parent_span is not None and parent_span.is_recording():
            span = self._tracer.start_span(name, context=trace.set_span_in_context(parent_span))
        else:
            span = self._tracer.start_span(name)

        span.set_attribute("agentops.observation_type", observation_type)
        if payload is not None:
            span.set_attribute("agentops.input", _safe_serialize(payload))
        self._active_spans[str(run_id)] = span

    def _end_span(self, run_id: Any, *, output: Any = None, error: Exception | None = None) -> None:
        span = self._active_spans.pop(str(run_id), None)
        if span is None:
            return

        if output is not None:
            span.set_attribute("agentops.output", _safe_serialize(output))

        if error is not None:
            span.set_status(StatusCode.ERROR, str(error))
            span.record_exception(error)
            span.set_attribute("error.type", type(error).__name__)

        span.end()

    # -----------------------
    # LLM events
    # -----------------------

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: Any,
        parent_run_id: Any | None = None,
        **kwargs: Any,
    ) -> None:
        self._start_span(
            run_id=run_id,
            parent_run_id=parent_run_id,
            name="langchain.llm",
            observation_type="generation",
            payload={"serialized": serialized, "prompts": prompts},
        )

    def on_llm_end(self, response: Any, *, run_id: Any, **kwargs: Any) -> None:
        span = self._active_spans.get(str(run_id))
        if span is not None:
            _apply_llm_attributes(span, response)
        self._end_span(run_id, output=response)

    def on_llm_error(self, error: Exception, *, run_id: Any, **kwargs: Any) -> None:
        self._end_span(run_id, error=error)

    # -----------------------
    # Chain events
    # -----------------------

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: Any,
        parent_run_id: Any | None = None,
        **kwargs: Any,
    ) -> None:
        self._start_span(
            run_id=run_id,
            parent_run_id=parent_run_id,
            name="langchain.chain",
            observation_type="workflow",
            payload={"serialized": serialized, "inputs": inputs},
        )

    def on_chain_end(self, outputs: dict[str, Any], *, run_id: Any, **kwargs: Any) -> None:
        self._end_span(run_id, output=outputs)

    def on_chain_error(self, error: Exception, *, run_id: Any, **kwargs: Any) -> None:
        self._end_span(run_id, error=error)

    # -----------------------
    # Tool events
    # -----------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: Any,
        parent_run_id: Any | None = None,
        **kwargs: Any,
    ) -> None:
        self._start_span(
            run_id=run_id,
            parent_run_id=parent_run_id,
            name="langchain.tool",
            observation_type="tool",
            payload={"serialized": serialized, "input": input_str},
        )

    def on_tool_end(self, output: Any, *, run_id: Any, **kwargs: Any) -> None:
        self._end_span(run_id, output=output)

    def on_tool_error(self, error: Exception, *, run_id: Any, **kwargs: Any) -> None:
        self._end_span(run_id, error=error)
