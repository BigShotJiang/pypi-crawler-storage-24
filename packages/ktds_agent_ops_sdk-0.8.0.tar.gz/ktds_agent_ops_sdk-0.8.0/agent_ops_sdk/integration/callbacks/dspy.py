"""DSPy callback integration for AgentOps SDK."""

from __future__ import annotations

from typing import Any

from opentelemetry import trace
from opentelemetry.trace import StatusCode

from agent_ops_sdk.instrument.decorator import _apply_llm_attributes, _safe_serialize

try:
    from dspy.utils.callback import BaseCallback
except Exception:  # pragma: no cover - optional dependency
    class BaseCallback:  # type: ignore[override]
        """Fallback when dspy is not installed."""


class DSPyCallbackHandler(BaseCallback):
    """Record DSPy module/LM events as AgentOps spans."""

    def __init__(self) -> None:
        super().__init__()
        self._tracer = trace.get_tracer("agent_ops_sdk.integration.dspy")
        self._active_spans: dict[str, trace.Span] = {}

    def _start_span(
        self,
        *,
        run_id: Any,
        name: str,
        observation_type: str,
        payload: Any = None,
        parent_run_id: Any = None,
    ) -> None:
        parent_span = self._active_spans.get(str(parent_run_id)) if parent_run_id is not None else None
        if parent_span is not None and parent_span.is_recording():
            span = self._tracer.start_span(name, context=trace.set_span_in_context(parent_span))
        else:
            span = self._tracer.start_span(name)

        span.set_attribute("agentops.observation_type", observation_type)
        if payload is not None:
            span.set_attribute("agentops.input", _safe_serialize(payload))
        self._active_spans[str(run_id)] = span

    def _end_span(self, run_id: Any, *, output: Any = None, error: Exception | None = None) -> None:
        span = self._active_spans.pop(str(run_id), None)
        if span is None:
            return

        if output is not None:
            span.set_attribute("agentops.output", _safe_serialize(output))
            _apply_llm_attributes(span, output)

        if error is not None:
            span.set_status(StatusCode.ERROR, str(error))
            span.record_exception(error)
            span.set_attribute("error.type", type(error).__name__)

        span.end()

    # DSPy module lifecycle
    def on_module_start(
        self,
        call_id: Any,
        instance: Any,
        inputs: dict[str, Any] | None = None,
        parent_call_id: Any | None = None,
    ) -> None:
        self._start_span(
            run_id=call_id,
            parent_run_id=parent_call_id,
            name="dspy.module",
            observation_type="workflow",
            payload={"module": type(instance).__name__, "inputs": inputs or {}},
        )

    def on_module_end(
        self,
        call_id: Any,
        outputs: Any = None,
        exception: Exception | None = None,
    ) -> None:
        self._end_span(call_id, output=outputs, error=exception)

    # DSPy LM lifecycle
    def on_lm_start(
        self,
        call_id: Any,
        instance: Any,
        inputs: dict[str, Any] | None = None,
        parent_call_id: Any | None = None,
    ) -> None:
        self._start_span(
            run_id=call_id,
            parent_run_id=parent_call_id,
            name="dspy.lm",
            observation_type="generation",
            payload={"lm": type(instance).__name__, "inputs": inputs or {}},
        )

    def on_lm_end(
        self,
        call_id: Any,
        outputs: Any = None,
        exception: Exception | None = None,
    ) -> None:
        self._end_span(call_id, output=outputs, error=exception)
