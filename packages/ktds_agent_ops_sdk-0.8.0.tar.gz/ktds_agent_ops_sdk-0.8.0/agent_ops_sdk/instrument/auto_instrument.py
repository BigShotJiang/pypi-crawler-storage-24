"""LLM 프로바이더 자동 계측(auto-instrumentation) 모듈.

설치된 LLM SDK를 자동으로 패치하여 모든 API 호출에 트레이싱 스팬을 생성한다.
사용자 코드 수정 없이 동작한다.

지원 프로바이더:
    - OpenAI (v1+)
    - Anthropic
    - Google GenAI
    - Cohere (v2)
    - Mistral AI
    - LiteLLM
    - Groq
    - Together AI
    - IBM Watsonx

사용법:
    client = AgentOpsClient(auto_instrument=True)
    # 모든 LLM 호출이 자동으로 트레이싱됨
"""

from __future__ import annotations

import functools
import importlib
import importlib.abc
import importlib.machinery
import importlib.metadata
import logging
import re
import sys
import threading
from typing import Any

from opentelemetry.trace import StatusCode

from agent_ops_sdk.instrument._traced_streams import (
    _BaseTracedAsyncStream,
    _BaseTracedSyncStream,
)
from agent_ops_sdk.instrument.context import _apply_baggage_to_span
from agent_ops_sdk.instrument.decorator import (
    _apply_llm_attributes,
    _get_tracer,
    _safe_serialize,
)
from agent_ops_sdk.instrument.llm_extractors import extract_llm_usage

logger = logging.getLogger("agent_ops_sdk.instrument.auto_instrument")

# ---------------------------------------------------------------------------
# 스레드 안전 전역 상태 (C-5)
# ---------------------------------------------------------------------------

_lock = threading.Lock()
_ORIGINALS: dict[str, Any] = {}               # 패치 전 원본 메서드 백업
_PATCHED_PROVIDERS: set[str] = set()           # 이미 패치된 프로바이더
_IMPORT_HOOK_ENABLED = False                   # 임포트 훅 활성화 여부
_AUTO_IMPORT_PROVIDERS: set[str] = set()       # 임포트 시 자동 패치 대상
_PATCH_IN_PROGRESS: set[str] = set()           # 현재 패치 진행 중

# ---------------------------------------------------------------------------
# 프로바이더 버전 게이트
# ---------------------------------------------------------------------------

_PROVIDER_VERSION_GATES: dict[str, tuple[str, str, tuple[str, ...]]] = {
    # 프로바이더: (배포 패키지명, 최소 버전, 모듈 접두사)
    "openai": ("openai", "1.0.0", ("openai",)),
    "anthropic": ("anthropic", "0.32.0", ("anthropic",)),
    "google_genai": ("google-genai", "0.1.0", ("google.genai",)),
    "cohere": ("cohere", "5.0.0", ("cohere",)),
    "mistral": ("mistralai", "1.0.0", ("mistralai",)),
    "litellm": ("litellm", "1.0.0", ("litellm",)),
    "groq": ("groq", "0.5.0", ("groq",)),
    "together": ("together", "1.0.0", ("together",)),
    "watsonx": ("ibm-watsonx-ai", "1.0.0", ("ibm_watsonx_ai",)),
}

_VERSION_PATTERN = re.compile(r"(\d+)")


def _version_tuple(version_str: str) -> tuple[int, ...]:
    """버전 문자열을 비교 가능한 정수 튜플로 변환."""
    return tuple(int(m) for m in _VERSION_PATTERN.findall(version_str))


def _is_version_supported(provider: str) -> bool:
    """설치된 패키지 버전이 최소 요구사항을 충족하는지 확인."""
    gate = _PROVIDER_VERSION_GATES.get(provider)
    if gate is None:
        return True

    dist_name, min_version, _ = gate
    try:
        installed = importlib.metadata.version(dist_name)
    except importlib.metadata.PackageNotFoundError:
        return False
    except Exception:
        logger.debug("버전 확인 실패: %s", dist_name, exc_info=True)
        return True

    supported = _version_tuple(installed) >= _version_tuple(min_version)
    if not supported:
        logger.info(
            "%s 계측 건너뜀: 설치 %s < 요구 %s",
            provider, installed, min_version,
        )
    return supported


# ---------------------------------------------------------------------------
# 스트림 래퍼 (LLM: 마지막 chunk에서 model/tokens 추출)
# ---------------------------------------------------------------------------


class _TracedSyncStream(_BaseTracedSyncStream):
    """동기 스트림 래퍼 — finalize 시 LLM 속성 추출."""

    __slots__ = ()

    def _on_finalize(self) -> None:
        for chunk in reversed(self._chunks):
            info = extract_llm_usage(chunk)
            if info:
                _apply_llm_attributes(self._span, chunk)
                break


class _TracedAsyncStream(_BaseTracedAsyncStream):
    """비동기 스트림 래퍼 — finalize 시 LLM 속성 추출."""

    __slots__ = ()

    def _on_finalize(self) -> None:
        for chunk in reversed(self._chunks):
            info = extract_llm_usage(chunk)
            if info:
                _apply_llm_attributes(self._span, chunk)
                break


# ---------------------------------------------------------------------------
# 공통 헬퍼: 에러 기록, 입력 추출, 서버 정보, 콘텐츠 캡처
# ---------------------------------------------------------------------------


def _record_error(span: Any, exc: Exception, *, end_span: bool = False) -> None:
    """스팬에 에러 정보를 기록하는 공통 헬퍼.

    Args:
        span: OTel 스팬 객체.
        exc: 발생한 예외.
        end_span: True면 스팬을 종료 (스트림에서 사용).
    """
    span.set_status(StatusCode.ERROR, str(exc))
    span.record_exception(exc)
    span.set_attribute("error.type", type(exc).__name__)
    if end_span:
        span.end()


def _operation_to_gen_ai_name(operation: str) -> str:
    """SDK 메서드 오퍼레이션을 GenAI 시맨틱 오퍼레이션 이름으로 매핑."""
    lowered = operation.lower()
    if "embedding" in lowered:
        return "embeddings"
    if "image" in lowered:
        return "image_generation"
    return "chat"


# 입력 페이로드 키 목록 (순서대로 탐색)
_INPUT_KEYS = ("messages", "contents", "input", "prompt", "instructions")

# kwargs에서 스팬 속성으로 매핑할 생성 파라미터
_GENERATION_PARAM_MAP: tuple[tuple[str, str], ...] = (
    ("temperature", "gen_ai.request.temperature"),
    ("max_tokens", "gen_ai.request.max_tokens"),
    ("max_output_tokens", "gen_ai.request.max_tokens"),
    ("top_p", "gen_ai.request.top_p"),
    ("top_k", "gen_ai.request.top_k"),
    ("frequency_penalty", "gen_ai.request.frequency_penalty"),
    ("presence_penalty", "gen_ai.request.presence_penalty"),
)


def _extract_input_payload(kwargs: dict[str, Any]) -> str | None:
    """kwargs에서 입력 페이로드를 찾아 직렬화된 문자열로 반환."""
    for key in _INPUT_KEYS:
        val = kwargs.get(key)
        if val is not None:
            return _safe_serialize(val)
    return None


def _setup_span(
    span: Any,
    provider: str,
    kwargs: dict[str, Any],
    *,
    operation: str = "chat",
) -> None:
    """자동 계측 호출에 공통 스팬 속성을 설정."""
    # 기본 GenAI 속성
    span.set_attribute("agentops.observation_type", "generation")
    span.set_attribute("gen_ai.operation.name", _operation_to_gen_ai_name(operation))
    span.set_attribute("gen_ai.system", provider)
    span.set_attribute("gen_ai.provider.name", provider)
    _apply_baggage_to_span(span)

    # 모델 이름
    model = kwargs.get("model") or kwargs.get("model_id")
    if model:
        span.set_attribute("gen_ai.request.model", str(model))

    # 입력 캡처 (messages/contents/input/prompt/instructions)
    input_serialized = _extract_input_payload(kwargs)
    if input_serialized is not None:
        span.set_attribute("agentops.input", input_serialized)

    # 생성 파라미터 (temperature, max_tokens, top_p, top_k, penalties)
    # Google GenAI SDK는 config 딕셔너리 안에 넣으므로 양쪽 다 탐색
    _param_sources = [kwargs]
    _config = kwargs.get("config")
    if isinstance(_config, dict):
        _param_sources.append(_config)
    elif _config is not None:
        # Pydantic 모델 등 → __dict__ 시도
        try:
            _param_sources.append(vars(_config))
        except Exception:
            pass

    for kwarg_key, attr_name in _GENERATION_PARAM_MAP:
        for src in _param_sources:
            val = src.get(kwarg_key) if isinstance(src, dict) else getattr(src, kwarg_key, None)
            if val is not None:
                span.set_attribute(attr_name, val)
                break

    # stop 시퀀스 (문자열 → 리스트 정규화)
    stop = None
    for src in _param_sources:
        stop = (src.get("stop") if isinstance(src, dict) else getattr(src, "stop", None)) or \
               (src.get("stop_sequences") if isinstance(src, dict) else getattr(src, "stop_sequences", None))
        if stop is not None:
            break
    if stop is not None:
        if isinstance(stop, str):
            stop = [stop]
        span.set_attribute("gen_ai.request.stop_sequences", list(stop))


def _extract_server_info(self_obj: Any, span: Any) -> None:
    """프로바이더 클라이언트에서 server.address/port를 추출하여 스팬에 기록.

    httpx.URL 또는 유사한 base_url 객체에서 host/port를 읽는다.
    실패해도 예외를 발생시키지 않는다 (non-breaking).
    """
    try:
        client = getattr(self_obj, "_client", None) or self_obj
        base_url = getattr(client, "base_url", None)
        if base_url is None:
            return
        host = getattr(base_url, "host", None)
        if host:
            span.set_attribute("server.address", str(host))
        port = getattr(base_url, "port", None)
        if port is not None:
            span.set_attribute("server.port", int(port))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 콘텐츠 캡처 (opt-in: gen_ai.prompt / gen_ai.completion)
# ---------------------------------------------------------------------------

_capture_content: bool = False
_content_max_length: int = 10_000


def configure_content_capture(*, capture: bool, max_length: int = 10_000) -> None:
    """콘텐츠 캡처 설정 (AgentOpsClient 초기화 시 호출).

    Args:
        capture: True면 프롬프트/응답 내용을 스팬에 기록.
        max_length: 캡처할 최대 문자 수 (초과 시 자름).
    """
    global _capture_content, _content_max_length
    _capture_content = capture
    _content_max_length = max_length


def _set_content_attributes(
    span: Any,
    *,
    prompt: str | None = None,
    completion: str | None = None,
) -> None:
    """opt-in 활성화 시 gen_ai.prompt / gen_ai.completion을 스팬에 기록.

    _capture_content가 False면 아무것도 하지 않는다.
    대용량 텍스트는 _content_max_length로 잘린다.
    """
    if not _capture_content:
        return
    try:
        if prompt is not None:
            span.set_attribute("gen_ai.prompt", prompt[:_content_max_length])
        if completion is not None:
            span.set_attribute("gen_ai.completion", completion[:_content_max_length])
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 래퍼 팩토리 (공통 로직 통합)
# ---------------------------------------------------------------------------


def _finalize_non_stream(span: Any, result: Any, kwargs: dict[str, Any]) -> Any:
    """비스트림 호출 완료 후 결과를 스팬에 기록하는 공통 후처리.

    Returns:
        원본 result (투명하게 전달).
    """
    _apply_llm_attributes(span, result)
    output = _safe_serialize(result)
    span.set_attribute("agentops.output", output)
    input_payload = _extract_input_payload(kwargs)
    _set_content_attributes(span, prompt=input_payload, completion=output)
    return result


def _make_wrapper(
    original: Any,
    provider: str,
    operation: str,
    *,
    is_async: bool = False,
) -> Any:
    """인스턴스 메서드용 트레이싱 래퍼 생성 (stream 분기 포함).

    self_obj가 첫 번째 인자인 바운드 메서드를 래핑한다.
    stream=True이면 TracedStream으로 감싸고, 아니면 직접 결과를 기록한다.
    """
    span_name = f"{provider}.{operation}"

    if is_async:

        @functools.wraps(original)
        async def async_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
            is_stream = kwargs.get("stream", False)

            if is_stream:
                # 스트림: 스팬을 열어두고 TracedAsyncStream에 위임
                span = _get_tracer().start_span(span_name)
                _setup_span(span, provider, kwargs, operation=operation)
                _extract_server_info(self_obj, span)
                try:
                    result = await original(self_obj, *args, **kwargs)
                    return _TracedAsyncStream(result, span)
                except Exception as exc:
                    _record_error(span, exc, end_span=True)
                    raise

            # 비스트림: 컨텍스트 매니저로 스팬 자동 종료
            with _get_tracer().start_as_current_span(span_name) as span:
                _setup_span(span, provider, kwargs, operation=operation)
                _extract_server_info(self_obj, span)
                try:
                    result = await original(self_obj, *args, **kwargs)
                    return _finalize_non_stream(span, result, kwargs)
                except Exception as exc:
                    _record_error(span, exc)
                    raise

        return async_wrapper

    @functools.wraps(original)
    def sync_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
        is_stream = kwargs.get("stream", False)

        if is_stream:
            span = _get_tracer().start_span(span_name)
            _setup_span(span, provider, kwargs, operation=operation)
            _extract_server_info(self_obj, span)
            try:
                result = original(self_obj, *args, **kwargs)
                return _TracedSyncStream(result, span)
            except Exception as exc:
                _record_error(span, exc, end_span=True)
                raise

        with _get_tracer().start_as_current_span(span_name) as span:
            _setup_span(span, provider, kwargs, operation=operation)
            _extract_server_info(self_obj, span)
            try:
                result = original(self_obj, *args, **kwargs)
                return _finalize_non_stream(span, result, kwargs)
            except Exception as exc:
                _record_error(span, exc)
                raise

    return sync_wrapper


def _make_stream_wrapper(
    original: Any,
    provider: str,
    operation: str,
    *,
    is_async: bool = False,
) -> Any:
    """항상 스트림을 반환하는 메서드용 래퍼 (stream 분기 없음)."""
    span_name = f"{provider}.{operation}"

    if is_async:

        @functools.wraps(original)
        async def async_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
            span = _get_tracer().start_span(span_name)
            _setup_span(span, provider, kwargs, operation=operation)
            _extract_server_info(self_obj, span)
            try:
                result = await original(self_obj, *args, **kwargs)
                return _TracedAsyncStream(result, span)
            except Exception as exc:
                _record_error(span, exc, end_span=True)
                raise

        return async_wrapper

    @functools.wraps(original)
    def sync_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
        span = _get_tracer().start_span(span_name)
        _setup_span(span, provider, kwargs, operation=operation)
        _extract_server_info(self_obj, span)
        try:
            result = original(self_obj, *args, **kwargs)
            return _TracedSyncStream(result, span)
        except Exception as exc:
            _record_error(span, exc, end_span=True)
            raise

    return sync_wrapper


def _make_function_wrapper(
    original: Any,
    provider: str,
    operation: str,
    *,
    is_async: bool = False,
) -> Any:
    """모듈 레벨 함수용 래퍼 (self 파라미터 없음, 예: litellm.completion)."""
    span_name = f"{provider}.{operation}"

    if is_async:

        @functools.wraps(original)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            is_stream = kwargs.get("stream", False)

            if is_stream:
                span = _get_tracer().start_span(span_name)
                _setup_span(span, provider, kwargs, operation=operation)
                try:
                    result = await original(*args, **kwargs)
                    return _TracedAsyncStream(result, span)
                except Exception as exc:
                    _record_error(span, exc, end_span=True)
                    raise

            with _get_tracer().start_as_current_span(span_name) as span:
                _setup_span(span, provider, kwargs, operation=operation)
                try:
                    result = await original(*args, **kwargs)
                    return _finalize_non_stream(span, result, kwargs)
                except Exception as exc:
                    _record_error(span, exc)
                    raise

        return async_wrapper

    @functools.wraps(original)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        is_stream = kwargs.get("stream", False)

        if is_stream:
            span = _get_tracer().start_span(span_name)
            _setup_span(span, provider, kwargs, operation=operation)
            try:
                result = original(*args, **kwargs)
                return _TracedSyncStream(result, span)
            except Exception as exc:
                _record_error(span, exc, end_span=True)
                raise

        with _get_tracer().start_as_current_span(span_name) as span:
            _setup_span(span, provider, kwargs, operation=operation)
            try:
                result = original(*args, **kwargs)
                return _finalize_non_stream(span, result, kwargs)
            except Exception as exc:
                _record_error(span, exc)
                raise

    return sync_wrapper


# ---------------------------------------------------------------------------
# 프로바이더별 패치 함수
# ---------------------------------------------------------------------------


def _patch_openai_method(
    *,
    module: Any,
    class_name: str,
    method_name: str,
    key: str,
    operation: str,
    is_async: bool = False,
    stream_only: bool = False,
) -> bool:
    """OpenAI 클래스의 단일 메서드를 패치하고 원본을 저장."""
    cls = getattr(module, class_name, None)
    if cls is None or not hasattr(cls, method_name):
        return False

    original = getattr(cls, method_name)
    _ORIGINALS[key] = original
    factory = _make_stream_wrapper if stream_only else _make_wrapper
    setattr(cls, method_name, factory(original, "openai", operation, is_async=is_async))
    return True


# OpenAI 엔드포인트 스펙: (모듈 경로, 동기 클래스, 비동기 클래스, 메서드, 키 접두사, 오퍼레이션)
_OPENAI_ENDPOINTS: list[tuple[str, list[tuple[str, str, str, str, bool]]]] = [
    ("openai.resources.chat.completions", [
        ("Completions", "create", "openai.Completions.create", "chat", False),
        ("AsyncCompletions", "create", "openai.AsyncCompletions.create", "chat", True),
    ]),
    ("openai.resources.completions", [
        ("Completions", "create", "openai.TextCompletions.create", "completion", False),
        ("AsyncCompletions", "create", "openai.TextAsyncCompletions.create", "completion", True),
    ]),
    ("openai.resources.embeddings", [
        ("Embeddings", "create", "openai.Embeddings.create", "embeddings", False),
        ("AsyncEmbeddings", "create", "openai.AsyncEmbeddings.create", "embeddings", True),
    ]),
    ("openai.resources.images", [
        ("Images", "generate", "openai.Images.generate", "image_generate", False),
        ("AsyncImages", "generate", "openai.AsyncImages.generate", "image_generate", True),
    ]),
    ("openai.resources.responses", [
        ("Responses", "create", "openai.Responses.create", "responses", False),
        ("AsyncResponses", "create", "openai.AsyncResponses.create", "responses", True),
    ]),
    ("openai.resources.beta.assistants", [
        ("Assistants", "create", "openai.Assistants.create", "assistants_create", False),
        ("AsyncAssistants", "create", "openai.AsyncAssistants.create", "assistants_create", True),
    ]),
    ("openai.resources.beta.threads.runs", [
        ("Runs", "create", "openai.Runs.create", "runs_create", False),
        ("AsyncRuns", "create", "openai.AsyncRuns.create", "runs_create", True),
    ]),
]

# Runs의 stream 전용 메서드 (별도 처리)
_OPENAI_STREAM_ENDPOINTS: list[tuple[str, list[tuple[str, str, str, str, bool]]]] = [
    ("openai.resources.beta.threads.runs", [
        ("Runs", "create_and_stream", "openai.Runs.create_and_stream", "runs_stream", False),
        ("AsyncRuns", "create_and_stream", "openai.AsyncRuns.create_and_stream", "runs_stream", True),
    ]),
]


def _patch_openai() -> bool:
    """OpenAI SDK 전체 엔드포인트를 패치."""
    if "openai" in _PATCHED_PROVIDERS:
        return True

    patched_any = False

    # 일반 엔드포인트 (stream 분기 포함)
    for module_path, methods in _OPENAI_ENDPOINTS:
        try:
            mod = importlib.import_module(module_path)
            for class_name, method_name, key, operation, is_async in methods:
                patched_any |= _patch_openai_method(
                    module=mod, class_name=class_name, method_name=method_name,
                    key=key, operation=operation, is_async=is_async,
                )
        except ImportError:
            pass

    # 스트림 전용 엔드포인트
    for module_path, methods in _OPENAI_STREAM_ENDPOINTS:
        try:
            mod = importlib.import_module(module_path)
            for class_name, method_name, key, operation, is_async in methods:
                patched_any |= _patch_openai_method(
                    module=mod, class_name=class_name, method_name=method_name,
                    key=key, operation=operation, is_async=is_async, stream_only=True,
                )
        except ImportError:
            pass

    if not patched_any:
        return False

    _PATCHED_PROVIDERS.add("openai")
    logger.info("Auto-instrumented OpenAI")
    return True


def _patch_method_pair(
    module: Any,
    provider: str,
    sync_class: str,
    async_class: str,
    method: str,
    operation: str,
    *,
    factory: Any = _make_wrapper,
) -> None:
    """동기/비동기 클래스의 동일 메서드를 한 번에 패치하는 헬퍼.

    Anthropic, Google, Groq, Together 등 sync/async 쌍 패턴에 사용.
    """
    for cls_name, is_async in ((sync_class, False), (async_class, True)):
        cls = getattr(module, cls_name, None)
        if cls is None or not hasattr(cls, method):
            continue
        orig = getattr(cls, method)
        key = f"{provider}.{cls_name}.{method}"
        _ORIGINALS[key] = orig
        setattr(cls, method, factory(orig, provider, operation, is_async=is_async))


def _patch_anthropic() -> bool:
    """Anthropic SDK messages API를 패치."""
    if "anthropic" in _PATCHED_PROVIDERS:
        return True

    try:
        import anthropic.resources.messages as mod
    except ImportError:
        return False

    _patch_method_pair(mod, "anthropic", "Messages", "AsyncMessages", "create", "messages")

    _PATCHED_PROVIDERS.add("anthropic")
    logger.info("Auto-instrumented Anthropic")
    return True


def _patch_google_genai() -> bool:
    """Google GenAI SDK를 패치."""
    if "google_genai" in _PATCHED_PROVIDERS:
        return True

    try:
        from google.genai import models as mod
    except ImportError:
        return False

    _patch_method_pair(mod, "google", "Models", "AsyncModels", "generate_content", "generate_content")

    _PATCHED_PROVIDERS.add("google_genai")
    logger.info("Auto-instrumented Google GenAI")
    return True


def _patch_cohere() -> bool:
    """Cohere SDK (v2) chat API를 패치."""
    if "cohere" in _PATCHED_PROVIDERS:
        return True

    try:
        import cohere
    except ImportError:
        return False

    # Cohere v2: chat(비스트림) + chat_stream(스트림 전용)
    if hasattr(cohere, "ClientV2"):
        cls = cohere.ClientV2
        if hasattr(cls, "chat"):
            orig = cls.chat
            _ORIGINALS["cohere.ClientV2.chat"] = orig
            cls.chat = _make_wrapper(orig, "cohere", "chat", is_async=False)
        if hasattr(cls, "chat_stream"):
            orig = cls.chat_stream
            _ORIGINALS["cohere.ClientV2.chat_stream"] = orig
            cls.chat_stream = _make_stream_wrapper(orig, "cohere", "chat_stream", is_async=False)
    # Cohere v1 폴백
    elif hasattr(cohere, "Client"):
        cls = cohere.Client
        if hasattr(cls, "chat"):
            orig = cls.chat
            _ORIGINALS["cohere.Client.chat"] = orig
            cls.chat = _make_wrapper(orig, "cohere", "chat", is_async=False)

    _PATCHED_PROVIDERS.add("cohere")
    logger.info("Auto-instrumented Cohere")
    return True


def _patch_mistral() -> bool:
    """Mistral AI SDK chat API를 패치."""
    if "mistral" in _PATCHED_PROVIDERS:
        return True

    try:
        import mistralai
    except ImportError:
        return False

    # Chat 클래스 탐색 (여러 모듈 경로 시도)
    chat_cls = None
    try:
        from mistralai.chat import Chat as chat_cls  # type: ignore[assignment]
    except ImportError:
        pass

    if chat_cls is None:
        for attr_name in ("_chat", "chat"):
            mod = getattr(mistralai, attr_name, None)
            if mod and hasattr(mod, "Chat"):
                chat_cls = mod.Chat
                break

    if chat_cls is None:
        # 최후 수단: Mistral 인스턴스의 chat 속성 타입 확인
        try:
            tmp = mistralai.Mistral.__new__(mistralai.Mistral)
            if hasattr(tmp, "chat") and tmp.chat is not None:
                chat_cls = type(tmp.chat)
        except Exception:
            pass

    if chat_cls is None:
        logger.debug("Mistral Chat 클래스를 찾을 수 없음")
        return False

    # 비스트림 + 스트림 메서드 패치
    _method_specs = [
        ("complete", "chat", False, _make_wrapper),
        ("complete_async", "chat", True, _make_wrapper),
        ("stream", "chat_stream", False, _make_stream_wrapper),
        ("stream_async", "chat_stream", True, _make_stream_wrapper),
    ]
    for method_name, operation, is_async, factory in _method_specs:
        if not hasattr(chat_cls, method_name):
            continue
        orig = getattr(chat_cls, method_name)
        _ORIGINALS[f"mistral.Chat.{method_name}"] = orig
        setattr(chat_cls, method_name, factory(orig, "mistral", operation, is_async=is_async))

    _PATCHED_PROVIDERS.add("mistral")
    logger.info("Auto-instrumented Mistral AI")
    return True


def _patch_litellm() -> bool:
    """LiteLLM 모듈 레벨 completion 함수를 패치."""
    if "litellm" in _PATCHED_PROVIDERS:
        return True

    try:
        import litellm
    except ImportError:
        return False

    for func_name, is_async in (("completion", False), ("acompletion", True)):
        if hasattr(litellm, func_name):
            orig = getattr(litellm, func_name)
            _ORIGINALS[f"litellm.{func_name}"] = orig
            setattr(litellm, func_name, _make_function_wrapper(
                orig, "litellm", "completion", is_async=is_async,
            ))

    _PATCHED_PROVIDERS.add("litellm")
    logger.info("Auto-instrumented LiteLLM")
    return True


def _patch_groq() -> bool:
    """Groq SDK (OpenAI 호환) chat completions를 패치."""
    if "groq" in _PATCHED_PROVIDERS:
        return True

    try:
        import groq.resources.chat.completions as mod
    except ImportError:
        return False

    _patch_method_pair(mod, "groq", "Completions", "AsyncCompletions", "create", "chat")

    _PATCHED_PROVIDERS.add("groq")
    logger.info("Auto-instrumented Groq")
    return True


def _patch_watsonx() -> bool:
    """IBM Watsonx AI SDK (ModelInference)를 패치."""
    if "watsonx" in _PATCHED_PROVIDERS:
        return True

    try:
        from ibm_watsonx_ai.foundation_models import ModelInference
    except ImportError:
        return False

    # 비스트림 메서드: (메서드명, 오퍼레이션, 비동기 여부)
    _non_stream = [
        ("generate", "generate", False),
        ("generate_text", "generate", False),
        ("chat", "chat", False),
        ("agenerate", "generate", True),
        ("achat", "chat", True),
    ]
    for method_name, operation, is_async in _non_stream:
        if not hasattr(ModelInference, method_name):
            continue
        orig = getattr(ModelInference, method_name)
        key = f"watsonx.ModelInference.{method_name}"
        _ORIGINALS[key] = orig
        setattr(ModelInference, method_name,
                _make_wrapper(orig, "watsonx", operation, is_async=is_async))

    # 스트림 메서드
    _stream = [
        ("generate_text_stream", "generate_stream", False),
        ("chat_stream", "chat_stream", False),
        ("agenerate_stream", "generate_stream", True),
        ("achat_stream", "chat_stream", True),
    ]
    for method_name, operation, is_async in _stream:
        if not hasattr(ModelInference, method_name):
            continue
        orig = getattr(ModelInference, method_name)
        key = f"watsonx.ModelInference.{method_name}"
        _ORIGINALS[key] = orig
        setattr(ModelInference, method_name,
                _make_stream_wrapper(orig, "watsonx", operation, is_async=is_async))

    _ORIGINALS["watsonx._ModelInference_cls"] = ModelInference
    _PATCHED_PROVIDERS.add("watsonx")
    logger.info("Auto-instrumented IBM Watsonx")
    return True


def _patch_together() -> bool:
    """Together AI SDK (OpenAI 호환) chat completions를 패치."""
    if "together" in _PATCHED_PROVIDERS:
        return True

    try:
        import together.resources.chat.completions as mod
    except ImportError:
        return False

    _patch_method_pair(mod, "together", "Completions", "AsyncCompletions", "create", "chat")

    _PATCHED_PROVIDERS.add("together")
    logger.info("Auto-instrumented Together AI")
    return True


# ---------------------------------------------------------------------------
# 공개 API: patch_all / unpatch_all
# ---------------------------------------------------------------------------

_PROVIDER_PATCHERS: dict[str, Any] = {
    "openai": _patch_openai,
    "anthropic": _patch_anthropic,
    "google_genai": _patch_google_genai,
    "cohere": _patch_cohere,
    "mistral": _patch_mistral,
    "litellm": _patch_litellm,
    "groq": _patch_groq,
    "together": _patch_together,
    "watsonx": _patch_watsonx,
}


def patch_all(providers: list[str] | None = None) -> list[str]:
    """LLM 프로바이더를 패치하여 자동 트레이싱을 활성화.

    설치되지 않은 프로바이더는 조용히 건너뛴다.

    Args:
        providers: 패치할 프로바이더 목록. 기본값은 전체.

    Returns:
        성공적으로 패치된 프로바이더 이름 목록.
    """
    targets = providers or list(_PROVIDER_PATCHERS.keys())
    patched: list[str] = []

    for name in targets:
        patcher = _PROVIDER_PATCHERS.get(name)
        if patcher is None:
            logger.warning("알 수 없는 프로바이더: %s", name)
            continue
        if not _is_version_supported(name):
            continue
        try:
            if patcher():
                patched.append(name)
        except Exception:
            logger.debug("패치 실패: %s", name, exc_info=True)

    return patched


# ---------------------------------------------------------------------------
# OpenAI unpatch 스펙 (데이터 주도 복원)
# ---------------------------------------------------------------------------

_OPENAI_UNPATCH_SPECS: list[tuple[str, list[tuple[str, str]]]] = [
    ("openai.resources.chat.completions", [
        ("Completions", "openai.Completions.create"),
        ("AsyncCompletions", "openai.AsyncCompletions.create"),
    ]),
    ("openai.resources.completions", [
        ("Completions", "openai.TextCompletions.create"),
        ("AsyncCompletions", "openai.TextAsyncCompletions.create"),
    ]),
    ("openai.resources.embeddings", [
        ("Embeddings", "openai.Embeddings.create"),
        ("AsyncEmbeddings", "openai.AsyncEmbeddings.create"),
    ]),
    ("openai.resources.images", [
        ("Images", "openai.Images.generate"),
        ("AsyncImages", "openai.AsyncImages.generate"),
    ]),
    ("openai.resources.responses", [
        ("Responses", "openai.Responses.create"),
        ("AsyncResponses", "openai.AsyncResponses.create"),
    ]),
    ("openai.resources.beta.assistants", [
        ("Assistants", "openai.Assistants.create"),
        ("AsyncAssistants", "openai.AsyncAssistants.create"),
    ]),
    ("openai.resources.beta.threads.runs", [
        ("Runs", "openai.Runs.create"),
        ("AsyncRuns", "openai.AsyncRuns.create"),
        ("Runs", "openai.Runs.create_and_stream"),
        ("AsyncRuns", "openai.AsyncRuns.create_and_stream"),
    ]),
]


def _restore_openai_originals() -> None:
    """OpenAI 패치를 데이터 스펙 기반으로 복원."""
    for module_path, entries in _OPENAI_UNPATCH_SPECS:
        try:
            mod = importlib.import_module(module_path)
            for class_name, key in entries:
                orig = _ORIGINALS.pop(key, None)
                if orig is not None:
                    cls = getattr(mod, class_name, None)
                    if cls is not None:
                        method_name = key.rsplit(".", 1)[-1]
                        setattr(cls, method_name, orig)
        except ImportError:
            # 패키지가 제거된 경우 — 키만 정리
            for _, key in entries:
                _ORIGINALS.pop(key, None)


def _restore_provider_originals(
    provider_prefix: str,
    module_path: str,
    keys_to_classes: dict[str, str],
) -> None:
    """프로바이더별 패치 복원 공통 헬퍼.

    Args:
        provider_prefix: _ORIGINALS 키 접두사 (예: "anthropic").
        module_path: import할 모듈 경로.
        keys_to_classes: {_ORIGINALS 키: "ClassName.method"} 매핑.
    """
    try:
        mod = importlib.import_module(module_path)
        for key, cls_method in keys_to_classes.items():
            orig = _ORIGINALS.pop(key, None)
            if orig is None:
                continue
            cls_name, method_name = cls_method.rsplit(".", 1)
            cls = getattr(mod, cls_name, None)
            if cls is not None:
                setattr(cls, method_name, orig)
    except ImportError:
        for key in keys_to_classes:
            _ORIGINALS.pop(key, None)


def unpatch_all() -> None:
    """모든 패치된 메서드를 원본으로 복원."""

    # OpenAI (데이터 주도 복원)
    _restore_openai_originals()

    # Anthropic
    _restore_provider_originals("anthropic", "anthropic.resources.messages", {
        "anthropic.Messages.create": "Messages.create",
        "anthropic.AsyncMessages.create": "AsyncMessages.create",
    })

    # Google GenAI
    try:
        from google.genai import models as gmod
        for key, cls_method in {
            "google.Models.generate_content": "Models.generate_content",
            "google.AsyncModels.generate_content": "AsyncModels.generate_content",
        }.items():
            orig = _ORIGINALS.pop(key, None)
            if orig is not None:
                cls_name, method_name = cls_method.rsplit(".", 1)
                cls = getattr(gmod, cls_name, None)
                if cls is not None:
                    setattr(cls, method_name, orig)
    except Exception:
        _ORIGINALS.pop("google.Models.generate_content", None)
        _ORIGINALS.pop("google.AsyncModels.generate_content", None)

    # Cohere
    try:
        import cohere
        for key, target in {
            "cohere.ClientV2.chat": (cohere, "ClientV2", "chat"),
            "cohere.ClientV2.chat_stream": (cohere, "ClientV2", "chat_stream"),
            "cohere.Client.chat": (cohere, "Client", "chat"),
        }.items():
            orig = _ORIGINALS.pop(key, None)
            if orig is not None:
                cls = getattr(target[0], target[1], None)
                if cls is not None:
                    setattr(cls, target[2], orig)
    except ImportError:
        for k in ("cohere.ClientV2.chat", "cohere.ClientV2.chat_stream", "cohere.Client.chat"):
            _ORIGINALS.pop(k, None)

    # Mistral (키 접두사 기반 루프)
    try:
        for key in list(_ORIGINALS):
            if key.startswith("mistral.Chat."):
                method_name = key.split(".")[-1]
                try:
                    from mistralai.chat import Chat
                    setattr(Chat, method_name, _ORIGINALS.pop(key))
                except ImportError:
                    _ORIGINALS.pop(key, None)
    except Exception:
        pass

    # LiteLLM
    try:
        import litellm
        for func_name in ("completion", "acompletion"):
            key = f"litellm.{func_name}"
            orig = _ORIGINALS.pop(key, None)
            if orig is not None:
                setattr(litellm, func_name, orig)
    except ImportError:
        _ORIGINALS.pop("litellm.completion", None)
        _ORIGINALS.pop("litellm.acompletion", None)

    # Groq
    _restore_provider_originals("groq", "groq.resources.chat.completions", {
        "groq.Completions.create": "Completions.create",
        "groq.AsyncCompletions.create": "AsyncCompletions.create",
    })

    # Together AI
    _restore_provider_originals("together", "together.resources.chat.completions", {
        "together.Completions.create": "Completions.create",
        "together.AsyncCompletions.create": "AsyncCompletions.create",
    })

    # IBM Watsonx (클래스 참조 기반 복원)
    watsonx_cls = _ORIGINALS.pop("watsonx._ModelInference_cls", None)
    if watsonx_cls is not None:
        for key in list(_ORIGINALS):
            if key.startswith("watsonx.ModelInference."):
                method_name = key.split(".")[-1]
                setattr(watsonx_cls, method_name, _ORIGINALS.pop(key))
    else:
        for key in list(_ORIGINALS):
            if key.startswith("watsonx."):
                _ORIGINALS.pop(key, None)

    # 임포트 훅도 해제
    uninstrument_on_import()

    with _lock:
        _PATCHED_PROVIDERS.clear()
        _ORIGINALS.clear()
    logger.info("모든 프로바이더 패치 해제 완료")


# ---------------------------------------------------------------------------
# 임포트 훅 (sys.meta_path 기반)
# ---------------------------------------------------------------------------


def _provider_for_module_name(module_name: str) -> str | None:
    """임포트된 모듈 경로에서 프로바이더 이름을 찾는다."""
    for provider, (_, _, prefixes) in _PROVIDER_VERSION_GATES.items():
        for prefix in prefixes:
            if module_name == prefix or module_name.startswith(prefix + "."):
                return provider
    return None


class _AgentOpsImportFinder(importlib.abc.MetaPathFinder):
    """C-4: sys.meta_path 파인더 — 프로바이더 임포트 시 자동 패치.

    모듈이 임포트될 때 해당 프로바이더의 패치 함수를 실행한다.
    재귀 방지를 위해 일시적으로 자기 자신을 meta_path에서 제거한다.
    """

    def find_module(self, fullname: str, path: Any = None) -> "_AgentOpsImportFinder | None":
        provider = _provider_for_module_name(fullname)
        if provider is not None and provider in _AUTO_IMPORT_PROVIDERS:
            return self
        return None

    def load_module(self, fullname: str) -> Any:
        """정상 로더에게 위임한 뒤, 필요하면 패치 실행."""
        # 재귀 방지: 일시적으로 meta_path에서 제거
        if self in sys.meta_path:
            sys.meta_path.remove(self)
        try:
            module = importlib.import_module(fullname)
        finally:
            if self not in sys.meta_path:
                sys.meta_path.append(self)

        try:
            provider = _provider_for_module_name(fullname)
            if provider is None or provider not in _AUTO_IMPORT_PROVIDERS:
                return module
            with _lock:
                if provider in _PATCHED_PROVIDERS or provider in _PATCH_IN_PROGRESS:
                    return module
                if not _is_version_supported(provider):
                    return module
                patcher = _PROVIDER_PATCHERS.get(provider)
                if patcher is None:
                    return module
                _PATCH_IN_PROGRESS.add(provider)
            try:
                patcher()
            except Exception:
                logger.debug("임포트 훅 패치 실패: %s", provider, exc_info=True)
            finally:
                with _lock:
                    _PATCH_IN_PROGRESS.discard(provider)
        except Exception:
            logger.debug("임포트 훅 후처리 실패", exc_info=True)

        return module


_finder_instance: _AgentOpsImportFinder | None = None


def instrument_on_import(providers: list[str] | None = None) -> list[str]:
    """임포트 훅 기반 자동 계측을 활성화.

    향후 임포트되는 프로바이더를 자동으로 패치한다.
    이미 임포트된 프로바이더는 즉시 패치한다.

    Args:
        providers: 대상 프로바이더 목록. 기본값은 전체.

    Returns:
        유효한 대상 프로바이더 이름 목록 (정렬됨).
    """
    global _finder_instance
    targets = set(providers or list(_PROVIDER_PATCHERS.keys()))
    valid_targets = {name for name in targets if name in _PROVIDER_PATCHERS}

    with _lock:
        global _AUTO_IMPORT_PROVIDERS, _IMPORT_HOOK_ENABLED
        _AUTO_IMPORT_PROVIDERS = valid_targets

        if not _IMPORT_HOOK_ENABLED:
            _finder_instance = _AgentOpsImportFinder()
            sys.meta_path.insert(0, _finder_instance)
            _IMPORT_HOOK_ENABLED = True

    # 이미 임포트된 프로바이더 즉시 패치
    for mod_name in tuple(sys.modules.keys()):
        provider = _provider_for_module_name(mod_name)
        if provider is None or provider not in _AUTO_IMPORT_PROVIDERS:
            continue
        with _lock:
            if provider in _PATCHED_PROVIDERS:
                continue
        patcher = _PROVIDER_PATCHERS.get(provider)
        if patcher is None or not _is_version_supported(provider):
            continue
        try:
            patcher()
        except Exception:
            logger.debug("즉시 패치 실패: %s", provider, exc_info=True)

    return sorted(valid_targets)


def uninstrument_on_import() -> None:
    """임포트 훅 기반 자동 계측을 해제."""
    global _IMPORT_HOOK_ENABLED, _AUTO_IMPORT_PROVIDERS, _finder_instance
    with _lock:
        if _IMPORT_HOOK_ENABLED and _finder_instance is not None:
            try:
                sys.meta_path.remove(_finder_instance)
            except ValueError:
                pass
            _finder_instance = None
            _IMPORT_HOOK_ENABLED = False
        _AUTO_IMPORT_PROVIDERS = set()
