"""Instrumentation module - decorators and context propagation."""
