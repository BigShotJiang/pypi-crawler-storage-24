"""Auto-extract model name and token usage from known LLM provider responses.

Supports: OpenAI, Anthropic, Google Gemini, Cohere, LiteLLM, dict responses.
All extraction is best-effort - returns empty dict on failure.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("agent_ops_sdk.instrument.llm_extractors")


def extract_llm_usage(result: Any) -> dict[str, Any]:
    """Try to extract model and token usage from an LLM response object.

    Inspects the return value's attributes to detect the provider.
    Manual ``update_current_observation()`` values take precedence over
    auto-extracted values (merging happens in the decorator).

    Returns:
        Dict with any of: model, usage_input_tokens, usage_output_tokens,
        usage_total_tokens.  Empty dict when nothing detected.
    """
    if result is None:
        return {}

    info: dict[str, Any] = {}
    try:
        # --- Object-based responses (SDK return types) ---

        # OpenAI / Azure OpenAI / LiteLLM
        #   ChatCompletion: .model, .usage.prompt_tokens, .usage.completion_tokens
        # Anthropic Claude
        #   Message: .model, .usage.input_tokens, .usage.output_tokens
        if hasattr(result, "usage") and result.usage is not None:
            info = _extract_from_usage_attr(result)

        # Google Gemini
        #   GenerateContentResponse: .usage_metadata.prompt_token_count, ...
        elif hasattr(result, "usage_metadata") and result.usage_metadata is not None:
            info = _extract_gemini(result)

        # Cohere
        #   ChatResponse: .meta.tokens.input_tokens, ...
        elif hasattr(result, "meta"):
            info = _extract_cohere(result)

        # --- Dict-based responses ---
        elif isinstance(result, dict):
            info = _extract_from_dict(result)

    except Exception:
        logger.debug("Failed to auto-extract LLM usage", exc_info=True)

    # Enrich with provider and finish_reason
    if info:
        _enrich_provider_and_finish(result, info)

    return info


def _enrich_provider_and_finish(result: Any, info: dict[str, Any]) -> None:
    """Detect provider, finish_reason, and response_id; add to info dict."""
    try:
        # Provider detection from module name
        if "provider" not in info:
            provider = _detect_provider(result)
            if provider:
                info["provider"] = provider

        # Finish reason extraction
        if "finish_reason" not in info:
            reason = _extract_finish_reason(result)
            if reason:
                info["finish_reason"] = reason

        # Response ID extraction
        if "response_id" not in info:
            resp_id = _extract_response_id(result)
            if resp_id:
                info["response_id"] = resp_id
    except Exception:
        pass


def _extract_response_id(result: Any) -> str | None:
    """Extract unique completion ID from response."""
    # Object-based: .id attribute (OpenAI, Anthropic, Cohere)
    obj_id = getattr(result, "id", None)
    if obj_id and isinstance(obj_id, str):
        return obj_id
    # Dict-based
    if isinstance(result, dict):
        dict_id = result.get("id")
        if dict_id and isinstance(dict_id, str):
            return dict_id
    return None


def _detect_provider(result: Any) -> str | None:
    """Detect LLM provider from response object's module."""
    module = getattr(type(result), "__module__", "") or ""
    module_lower = module.lower()
    if "openai" in module_lower:
        return "openai"
    if "anthropic" in module_lower:
        return "anthropic"
    if "google" in module_lower or "genai" in module_lower:
        return "google"
    if "cohere" in module_lower:
        return "cohere"
    if "litellm" in module_lower:
        return "litellm"
    # Dict-based: check for provider hints
    if isinstance(result, dict):
        model = result.get("model", "")
        if isinstance(model, str):
            if model.startswith("gpt") or model.startswith("o1") or model.startswith("o3"):
                return "openai"
            if model.startswith("claude"):
                return "anthropic"
            if model.startswith("gemini"):
                return "google"
            if model.startswith("command"):
                return "cohere"
    return None


def _extract_finish_reason(result: Any) -> str | None:
    """Extract finish/stop reason from response."""
    # OpenAI: choices[0].finish_reason
    choices = getattr(result, "choices", None)
    if choices and len(choices) > 0:
        reason = getattr(choices[0], "finish_reason", None)
        if reason:
            return str(reason)
    # Anthropic: stop_reason
    stop_reason = getattr(result, "stop_reason", None)
    if stop_reason:
        return str(stop_reason)
    # Gemini: candidates[0].finish_reason
    candidates = getattr(result, "candidates", None)
    if candidates and len(candidates) > 0:
        reason = getattr(candidates[0], "finish_reason", None)
        if reason:
            return str(reason)
    # Dict-based
    if isinstance(result, dict):
        dict_choices = result.get("choices", [])
        if dict_choices and isinstance(dict_choices, list) and len(dict_choices) > 0:
            reason = dict_choices[0].get("finish_reason")
            if reason:
                return str(reason)
        stop = result.get("stop_reason")
        if stop:
            return str(stop)
    return None


# ------------------------------------------------------------------
# Provider-specific extractors
# ------------------------------------------------------------------


def _extract_from_usage_attr(result: Any) -> dict[str, Any]:
    """Extract from objects with a .usage attribute (OpenAI, Anthropic, LiteLLM)."""
    info: dict[str, Any] = {}
    usage = result.usage

    # Model name
    model = getattr(result, "model", None)
    if model:
        info["model"] = str(model)

    # OpenAI style: prompt_tokens / completion_tokens
    input_tok = getattr(usage, "prompt_tokens", None)
    output_tok = getattr(usage, "completion_tokens", None)
    total_tok = getattr(usage, "total_tokens", None)

    # Anthropic style: input_tokens / output_tokens
    if input_tok is None:
        input_tok = getattr(usage, "input_tokens", None)
    if output_tok is None:
        output_tok = getattr(usage, "output_tokens", None)

    if input_tok is not None:
        info["usage_input_tokens"] = int(input_tok)
    if output_tok is not None:
        info["usage_output_tokens"] = int(output_tok)
    if total_tok is not None:
        info["usage_total_tokens"] = int(total_tok)
    elif input_tok is not None and output_tok is not None:
        info["usage_total_tokens"] = int(input_tok) + int(output_tok)

    return info


def _extract_gemini(result: Any) -> dict[str, Any]:
    """Extract from Google Gemini GenerateContentResponse."""
    info: dict[str, Any] = {}
    meta = result.usage_metadata

    model = getattr(result, "model", None)
    if model:
        info["model"] = str(model)

    input_tok = getattr(meta, "prompt_token_count", None)
    output_tok = getattr(meta, "candidates_token_count", None)
    total_tok = getattr(meta, "total_token_count", None)

    if input_tok is not None:
        info["usage_input_tokens"] = int(input_tok)
    if output_tok is not None:
        info["usage_output_tokens"] = int(output_tok)
    if total_tok is not None:
        info["usage_total_tokens"] = int(total_tok)
    elif input_tok is not None and output_tok is not None:
        info["usage_total_tokens"] = int(input_tok) + int(output_tok)

    return info


def _extract_cohere(result: Any) -> dict[str, Any]:
    """Extract from Cohere ChatResponse."""
    info: dict[str, Any] = {}
    meta = getattr(result, "meta", None)
    if meta is None:
        return info

    tokens = getattr(meta, "tokens", None)
    if tokens is None:
        return info

    model = getattr(result, "model", None)
    if model:
        info["model"] = str(model)

    input_tok = getattr(tokens, "input_tokens", None)
    output_tok = getattr(tokens, "output_tokens", None)

    if input_tok is not None:
        info["usage_input_tokens"] = int(input_tok)
    if output_tok is not None:
        info["usage_output_tokens"] = int(output_tok)
    if input_tok is not None and output_tok is not None:
        info["usage_total_tokens"] = int(input_tok) + int(output_tok)

    return info


def _extract_from_dict(result: dict[str, Any]) -> dict[str, Any]:
    """Extract from dict-shaped responses (e.g. raw JSON API calls)."""
    info: dict[str, Any] = {}

    model = result.get("model")
    if model:
        info["model"] = str(model)

    usage = result.get("usage")
    if not isinstance(usage, dict):
        return info

    # OpenAI-style keys first, then Anthropic-style
    input_tok = usage.get("prompt_tokens") or usage.get("input_tokens")
    output_tok = usage.get("completion_tokens") or usage.get("output_tokens")
    total_tok = usage.get("total_tokens")

    if input_tok is not None:
        info["usage_input_tokens"] = int(input_tok)
    if output_tok is not None:
        info["usage_output_tokens"] = int(output_tok)
    if total_tok is not None:
        info["usage_total_tokens"] = int(total_tok)
    elif input_tok is not None and output_tok is not None:
        info["usage_total_tokens"] = int(input_tok) + int(output_tok)

    return info
