"""Extra auto-instrumentation for agent frameworks (batch 2).

Patches additional frameworks to automatically create tracing spans.
Separated from auto_framework.py to keep files under 800 lines.

Supported frameworks:
    - LangChain (AgentExecutor)
    - LlamaIndex (BaseQueryEngine, BaseChatEngine)
    - Haystack (Pipeline)
    - Agno (Agent)
    - Smolagents (MultiStepAgent)

Usage:
    These patchers are registered into auto_framework._FRAMEWORK_PATCHERS
    via _register_extra_frameworks() called at module load time.
"""

from __future__ import annotations

import logging
from typing import Any

from agent_ops_sdk.instrument.auto_framework import (
    _FW_ORIGINALS,
    _PATCHED_FRAMEWORKS,
    _make_fw_generator_wrapper,
    _make_fw_wrapper,
)

logger = logging.getLogger("agent_ops_sdk.instrument.auto_framework_extra")


# ------------------------------------------------------------------
# LangChain: AgentExecutor only (BaseChatModel covered by auto_instrument)
# ------------------------------------------------------------------


def _patch_langchain() -> bool:
    """Patch LangChain AgentExecutor."""
    if "langchain" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from langchain.agents import AgentExecutor
    except ImportError:
        return False

    _methods: list[tuple[str, str, str, bool, bool]] = [
        # (method_name, span_name, obs_type, is_async, is_generator)
        ("invoke", "agent.invoke", "workflow", False, False),
        ("ainvoke", "agent.invoke", "workflow", True, False),
        ("stream", "agent.stream", "workflow", False, True),
        ("astream", "agent.stream", "workflow", True, True),
    ]

    for method_name, span_name, obs_type, is_async, is_gen in _methods:
        if not hasattr(AgentExecutor, method_name):
            continue
        orig = getattr(AgentExecutor, method_name)
        key = f"langchain.AgentExecutor.{method_name}"
        _FW_ORIGINALS[key] = orig
        factory = _make_fw_generator_wrapper if is_gen else _make_fw_wrapper
        setattr(
            AgentExecutor,
            method_name,
            factory(orig, "langchain", span_name, obs_type, is_async=is_async),
        )

    _PATCHED_FRAMEWORKS.add("langchain")
    logger.info("Auto-instrumented LangChain")
    return True


# ------------------------------------------------------------------
# LlamaIndex: BaseQueryEngine + BaseChatEngine
# ------------------------------------------------------------------


def _patch_llamaindex() -> bool:
    """Patch LlamaIndex BaseQueryEngine and BaseChatEngine."""
    if "llamaindex" in _PATCHED_FRAMEWORKS:
        return True

    # Try v0.10+ import paths first, then fallback
    query_engine_cls = None
    chat_engine_cls = None

    try:
        from llama_index.core.base.query_engine import BaseQueryEngine
        query_engine_cls = BaseQueryEngine
    except ImportError:
        try:
            from llama_index.core.query_engine import BaseQueryEngine
            query_engine_cls = BaseQueryEngine
        except ImportError:
            pass

    try:
        from llama_index.core.chat_engine.types import BaseChatEngine
        chat_engine_cls = BaseChatEngine
    except ImportError:
        try:
            from llama_index.core.chat_engine import BaseChatEngine
            chat_engine_cls = BaseChatEngine
        except ImportError:
            pass

    if query_engine_cls is None and chat_engine_cls is None:
        return False

    # Patch QueryEngine
    if query_engine_cls is not None:
        _qe_methods: list[tuple[str, str, bool, bool]] = [
            ("query", "query_engine.query", False, False),
            ("aquery", "query_engine.query", True, False),
        ]
        for method_name, span_name, is_async, is_gen in _qe_methods:
            if not hasattr(query_engine_cls, method_name):
                continue
            orig = getattr(query_engine_cls, method_name)
            key = f"llamaindex.BaseQueryEngine.{method_name}"
            _FW_ORIGINALS[key] = orig
            setattr(
                query_engine_cls,
                method_name,
                _make_fw_wrapper(
                    orig, "llamaindex", span_name, "workflow", is_async=is_async,
                ),
            )

    # Patch ChatEngine
    if chat_engine_cls is not None:
        _ce_methods: list[tuple[str, str, bool, bool]] = [
            ("chat", "chat_engine.chat", False, False),
            ("achat", "chat_engine.chat", True, False),
            ("stream_chat", "chat_engine.stream_chat", False, True),
            ("astream_chat", "chat_engine.stream_chat", True, True),
        ]
        for method_name, span_name, is_async, is_gen in _ce_methods:
            if not hasattr(chat_engine_cls, method_name):
                continue
            orig = getattr(chat_engine_cls, method_name)
            key = f"llamaindex.BaseChatEngine.{method_name}"
            _FW_ORIGINALS[key] = orig
            factory = _make_fw_generator_wrapper if is_gen else _make_fw_wrapper
            setattr(
                chat_engine_cls,
                method_name,
                factory(
                    orig, "llamaindex", span_name, "workflow", is_async=is_async,
                ),
            )

    _PATCHED_FRAMEWORKS.add("llamaindex")
    logger.info("Auto-instrumented LlamaIndex")
    return True


# ------------------------------------------------------------------
# Haystack: Pipeline
# ------------------------------------------------------------------


def _patch_haystack() -> bool:
    """Patch Haystack Pipeline."""
    if "haystack" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from haystack import Pipeline
    except ImportError:
        return False

    if hasattr(Pipeline, "run"):
        orig = Pipeline.run
        _FW_ORIGINALS["haystack.Pipeline.run"] = orig
        Pipeline.run = _make_fw_wrapper(
            orig, "haystack", "pipeline.run", "workflow",
        )

    if hasattr(Pipeline, "run_async"):
        orig = Pipeline.run_async
        _FW_ORIGINALS["haystack.Pipeline.run_async"] = orig
        Pipeline.run_async = _make_fw_wrapper(
            orig, "haystack", "pipeline.run", "workflow", is_async=True,
        )

    _PATCHED_FRAMEWORKS.add("haystack")
    logger.info("Auto-instrumented Haystack")
    return True


# ------------------------------------------------------------------
# Agno: Agent
# ------------------------------------------------------------------


def _patch_agno() -> bool:
    """Patch Agno Agent."""
    if "agno" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from agno.agent import Agent
    except ImportError:
        return False

    if hasattr(Agent, "run"):
        orig = Agent.run
        _FW_ORIGINALS["agno.Agent.run"] = orig
        Agent.run = _make_fw_wrapper(
            orig, "agno", "agent.run", "agent",
        )

    if hasattr(Agent, "arun"):
        orig = Agent.arun
        _FW_ORIGINALS["agno.Agent.arun"] = orig
        Agent.arun = _make_fw_wrapper(
            orig, "agno", "agent.run", "agent", is_async=True,
        )

    _PATCHED_FRAMEWORKS.add("agno")
    logger.info("Auto-instrumented Agno")
    return True


# ------------------------------------------------------------------
# Smolagents: MultiStepAgent
# ------------------------------------------------------------------


def _patch_smolagents() -> bool:
    """Patch Smolagents MultiStepAgent."""
    if "smolagents" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from smolagents.agents import MultiStepAgent
    except ImportError:
        return False

    if hasattr(MultiStepAgent, "run"):
        orig = MultiStepAgent.run
        _FW_ORIGINALS["smolagents.MultiStepAgent.run"] = orig
        MultiStepAgent.run = _make_fw_wrapper(
            orig, "smolagents", "agent.run", "agent",
        )

    _PATCHED_FRAMEWORKS.add("smolagents")
    logger.info("Auto-instrumented Smolagents")
    return True


# ------------------------------------------------------------------
# Registry of extra patchers
# ------------------------------------------------------------------

EXTRA_FRAMEWORK_PATCHERS: dict[str, Any] = {
    "langchain": _patch_langchain,
    "llamaindex": _patch_llamaindex,
    "haystack": _patch_haystack,
    "agno": _patch_agno,
    "smolagents": _patch_smolagents,
}
