"""Convenience decorators — shorthand for ``@instrument(as_type=...)``."""

from __future__ import annotations

from typing import Callable, TypeVar, overload

from agent_ops_sdk.instrument.decorator import instrument

F = TypeVar("F", bound=Callable[..., object])


# ------------------------------------------------------------------
# @agent
# ------------------------------------------------------------------


@overload
def agent(fn: F) -> F: ...


@overload
def agent(*, name: str | None = None) -> Callable[[F], F]: ...


def agent(
    fn: F | None = None,
    *,
    name: str | None = None,
) -> F | Callable[[F], F]:
    """Shorthand for ``@instrument(as_type="agent")``.

    Usage::

        @agent
        def my_agent(query): ...

        @agent(name="customer-support")
        def support_agent(query): ...
    """
    if fn is not None:
        return instrument(fn, as_type="agent")
    return instrument(as_type="agent", name=name)


# ------------------------------------------------------------------
# @tool
# ------------------------------------------------------------------


@overload
def tool(fn: F) -> F: ...


@overload
def tool(*, name: str | None = None) -> Callable[[F], F]: ...


def tool(
    fn: F | None = None,
    *,
    name: str | None = None,
) -> F | Callable[[F], F]:
    """Shorthand for ``@instrument(as_type="tool")``."""
    if fn is not None:
        return instrument(fn, as_type="tool")
    return instrument(as_type="tool", name=name)


# ------------------------------------------------------------------
# @task
# ------------------------------------------------------------------


@overload
def task(fn: F) -> F: ...


@overload
def task(*, name: str | None = None) -> Callable[[F], F]: ...


def task(
    fn: F | None = None,
    *,
    name: str | None = None,
) -> F | Callable[[F], F]:
    """Shorthand for ``@instrument(as_type="span")`` with task semantics.

    Tasks are spans that represent a unit of work within an agent.
    """
    if fn is not None:
        return instrument(fn, as_type="span", name=name or fn.__name__)
    return instrument(as_type="span", name=name)


# ------------------------------------------------------------------
# @workflow
# ------------------------------------------------------------------


@overload
def workflow(fn: F) -> F: ...


@overload
def workflow(*, name: str | None = None) -> Callable[[F], F]: ...


def workflow(
    fn: F | None = None,
    *,
    name: str | None = None,
) -> F | Callable[[F], F]:
    """Shorthand for ``@instrument(as_type="span")`` with workflow semantics."""
    if fn is not None:
        return instrument(fn, as_type="span", name=name or fn.__name__)
    return instrument(as_type="span", name=name)


# ------------------------------------------------------------------
# @guardrail
# ------------------------------------------------------------------


@overload
def guardrail(fn: F) -> F: ...


@overload
def guardrail(*, name: str | None = None) -> Callable[[F], F]: ...


def guardrail(
    fn: F | None = None,
    *,
    name: str | None = None,
) -> F | Callable[[F], F]:
    """Shorthand for ``@instrument(as_type="guardrail")``."""
    if fn is not None:
        return instrument(fn, as_type="guardrail")
    return instrument(as_type="guardrail", name=name)


# ------------------------------------------------------------------
# @generation
# ------------------------------------------------------------------


@overload
def generation(fn: F) -> F: ...


@overload
def generation(*, name: str | None = None) -> Callable[[F], F]: ...


def generation(
    fn: F | None = None,
    *,
    name: str | None = None,
) -> F | Callable[[F], F]:
    """Shorthand for ``@instrument(as_type="generation")``."""
    if fn is not None:
        return instrument(fn, as_type="generation")
    return instrument(as_type="generation", name=name)


# ------------------------------------------------------------------
# @retriever
# ------------------------------------------------------------------


@overload
def retriever(fn: F) -> F: ...


@overload
def retriever(*, name: str | None = None) -> Callable[[F], F]: ...


def retriever(
    fn: F | None = None,
    *,
    name: str | None = None,
) -> F | Callable[[F], F]:
    """Shorthand for ``@instrument(as_type="retriever")``."""
    if fn is not None:
        return instrument(fn, as_type="retriever")
    return instrument(as_type="retriever", name=name)
