"""Auto-instrumentation for agent frameworks.

Patches known agent frameworks to automatically create tracing spans.
No user code changes required.

Supported frameworks:
    - LangGraph (CompiledGraph / Pregel)
    - CrewAI (Crew, Agent, Task)
    - AutoGen / AG2 (BaseChatAgent)
    - OpenAI Agents SDK (Runner)
    - Google ADK (Runner)
    - Microsoft Agent Framework (ChatAgent)

Usage:
    client = AgentOpsClient(auto_instrument=True)
    # All LLM providers + frameworks are now automatically traced
"""

from __future__ import annotations

import functools
import logging
from typing import Any

from opentelemetry.trace import StatusCode

from agent_ops_sdk.instrument._traced_streams import (
    _BaseTracedAsyncStream,
    _BaseTracedSyncStream,
)
from agent_ops_sdk.instrument.context import _apply_baggage_to_span
from agent_ops_sdk.instrument.decorator import _get_tracer, _safe_serialize

logger = logging.getLogger("agent_ops_sdk.instrument.auto_framework")

# Store original methods for unpatch
_FW_ORIGINALS: dict[str, Any] = {}
_PATCHED_FRAMEWORKS: set[str] = set()

# Map observation_type -> gen_ai.operation.name for framework spans
_FW_OBS_TYPE_TO_OPERATION: dict[str, str] = {
    "workflow": "execute_workflow",
    "agent": "invoke_agent",
    "task": "execute_task",
}


# ------------------------------------------------------------------
# Span setup helper
# ------------------------------------------------------------------


def _setup_framework_span(
    span: Any,
    fw_name: str,
    obs_type: str,
    kwargs: dict[str, Any],
) -> None:
    """Set common span attributes for auto-instrumented framework calls."""
    span.set_attribute("agentops.observation_type", obs_type)
    span.set_attribute("gen_ai.system", fw_name)

    operation = _FW_OBS_TYPE_TO_OPERATION.get(obs_type)
    if operation:
        span.set_attribute("gen_ai.operation.name", operation)

    _apply_baggage_to_span(span)

    # Capture input from kwargs (best-effort)
    if kwargs:
        span.set_attribute("agentops.input", _safe_serialize(kwargs))


# ------------------------------------------------------------------
# Generic wrapper factories
# ------------------------------------------------------------------


def _make_fw_wrapper(
    original: Any,
    fw_name: str,
    span_name: str,
    obs_type: str,
    *,
    is_async: bool = False,
) -> Any:
    """Create a traced wrapper for a framework method (sync or async)."""
    full_span_name = f"{fw_name}.{span_name}"

    if is_async:

        @functools.wraps(original)
        async def async_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
            with _get_tracer().start_as_current_span(full_span_name) as span:
                _setup_framework_span(span, fw_name, obs_type, kwargs)
                try:
                    result = await original(self_obj, *args, **kwargs)
                    span.set_attribute(
                        "agentops.output", _safe_serialize(result)
                    )
                    return result
                except Exception as exc:
                    span.set_status(StatusCode.ERROR, str(exc))
                    span.record_exception(exc)
                    span.set_attribute("error.type", type(exc).__name__)
                    raise

        async_wrapper._agentops_patched = True  # type: ignore[attr-defined]
        return async_wrapper

    @functools.wraps(original)
    def sync_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
        with _get_tracer().start_as_current_span(full_span_name) as span:
            _setup_framework_span(span, fw_name, obs_type, kwargs)
            try:
                result = original(self_obj, *args, **kwargs)
                span.set_attribute(
                    "agentops.output", _safe_serialize(result)
                )
                return result
            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                span.set_attribute("error.type", type(exc).__name__)
                raise

    sync_wrapper._agentops_patched = True  # type: ignore[attr-defined]
    return sync_wrapper


def _make_fw_generator_wrapper(
    original: Any,
    fw_name: str,
    span_name: str,
    obs_type: str,
    *,
    is_async: bool = False,
) -> Any:
    """Create a traced wrapper for framework methods that return a stream/generator."""
    full_span_name = f"{fw_name}.{span_name}"

    if is_async:

        @functools.wraps(original)
        async def async_gen_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
            span = _get_tracer().start_span(full_span_name)
            _setup_framework_span(span, fw_name, obs_type, kwargs)
            try:
                result = await original(self_obj, *args, **kwargs)
                return _FwTracedAsyncStream(result, span)
            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                span.set_attribute("error.type", type(exc).__name__)
                span.end()
                raise

        async_gen_wrapper._agentops_patched = True  # type: ignore[attr-defined]
        return async_gen_wrapper

    @functools.wraps(original)
    def sync_gen_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
        span = _get_tracer().start_span(full_span_name)
        _setup_framework_span(span, fw_name, obs_type, kwargs)
        try:
            result = original(self_obj, *args, **kwargs)
            return _FwTracedSyncStream(result, span)
        except Exception as exc:
            span.set_status(StatusCode.ERROR, str(exc))
            span.record_exception(exc)
            span.set_attribute("error.type", type(exc).__name__)
            span.end()
            raise

    sync_gen_wrapper._agentops_patched = True  # type: ignore[attr-defined]
    return sync_gen_wrapper


# ------------------------------------------------------------------
# Lightweight stream wrappers for framework spans
# (Unlike LLM provider streams, these record last chunk as output)
# ------------------------------------------------------------------


class _FwTracedSyncStream(_BaseTracedSyncStream):
    """Sync stream wrapper that records last chunk as output on finalize."""

    __slots__ = ()

    def _on_finalize(self) -> None:
        if self._chunks:
            self._span.set_attribute(
                "agentops.output", _safe_serialize(self._chunks[-1])
            )


class _FwTracedAsyncStream(_BaseTracedAsyncStream):
    """Async stream wrapper that records last chunk as output on finalize."""

    __slots__ = ()

    def _on_finalize(self) -> None:
        if self._chunks:
            self._span.set_attribute(
                "agentops.output", _safe_serialize(self._chunks[-1])
            )


# ------------------------------------------------------------------
# Framework-specific patchers
# ------------------------------------------------------------------


def _patch_langgraph() -> bool:
    """Patch LangGraph CompiledGraph (Pregel) execution methods."""
    if "langgraph" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from langgraph.pregel import Pregel
    except ImportError:
        return False

    if hasattr(Pregel, "invoke"):
        orig = Pregel.invoke
        _FW_ORIGINALS["langgraph.Pregel.invoke"] = orig
        Pregel.invoke = _make_fw_wrapper(
            orig, "langgraph", "graph.invoke", "workflow",
        )

    if hasattr(Pregel, "ainvoke"):
        orig = Pregel.ainvoke
        _FW_ORIGINALS["langgraph.Pregel.ainvoke"] = orig
        Pregel.ainvoke = _make_fw_wrapper(
            orig, "langgraph", "graph.invoke", "workflow", is_async=True,
        )

    if hasattr(Pregel, "stream"):
        orig = Pregel.stream
        _FW_ORIGINALS["langgraph.Pregel.stream"] = orig
        Pregel.stream = _make_fw_generator_wrapper(
            orig, "langgraph", "graph.stream", "workflow",
        )

    if hasattr(Pregel, "astream"):
        orig = Pregel.astream
        _FW_ORIGINALS["langgraph.Pregel.astream"] = orig
        Pregel.astream = _make_fw_generator_wrapper(
            orig, "langgraph", "graph.stream", "workflow", is_async=True,
        )

    _PATCHED_FRAMEWORKS.add("langgraph")
    logger.info("Auto-instrumented LangGraph")
    return True


def _patch_crewai() -> bool:
    """Patch CrewAI Crew, Agent, and Task."""
    if "crewai" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from crewai import Crew
    except ImportError:
        return False

    # Crew.kickoff -> workflow span
    if hasattr(Crew, "kickoff"):
        orig = Crew.kickoff
        _FW_ORIGINALS["crewai.Crew.kickoff"] = orig
        Crew.kickoff = _make_fw_wrapper(
            orig, "crewai", "crew.kickoff", "workflow",
        )

    if hasattr(Crew, "kickoff_async"):
        orig = Crew.kickoff_async
        _FW_ORIGINALS["crewai.Crew.kickoff_async"] = orig
        Crew.kickoff_async = _make_fw_wrapper(
            orig, "crewai", "crew.kickoff", "workflow", is_async=True,
        )

    # Agent.execute_task -> agent span
    try:
        from crewai import Agent as CrewAgent

        if hasattr(CrewAgent, "execute_task"):
            orig = CrewAgent.execute_task
            _FW_ORIGINALS["crewai.Agent.execute_task"] = orig
            CrewAgent.execute_task = _make_fw_wrapper(
                orig, "crewai", "agent.execute", "agent",
            )
    except ImportError:
        pass

    # Task.execute_sync -> task span
    try:
        from crewai import Task as CrewTask

        if hasattr(CrewTask, "execute_sync"):
            orig = CrewTask.execute_sync
            _FW_ORIGINALS["crewai.Task.execute_sync"] = orig
            CrewTask.execute_sync = _make_fw_wrapper(
                orig, "crewai", "task.execute", "task",
            )
    except ImportError:
        pass

    _PATCHED_FRAMEWORKS.add("crewai")
    logger.info("Auto-instrumented CrewAI")
    return True


def _patch_autogen() -> bool:
    """Patch AutoGen / AG2 BaseChatAgent."""
    if "autogen" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from autogen_agentchat.agents import BaseChatAgent
    except ImportError:
        return False

    if hasattr(BaseChatAgent, "run"):
        orig = BaseChatAgent.run
        _FW_ORIGINALS["autogen.BaseChatAgent.run"] = orig
        BaseChatAgent.run = _make_fw_wrapper(
            orig, "autogen", "agent.run", "workflow", is_async=True,
        )

    if hasattr(BaseChatAgent, "run_stream"):
        orig = BaseChatAgent.run_stream
        _FW_ORIGINALS["autogen.BaseChatAgent.run_stream"] = orig
        BaseChatAgent.run_stream = _make_fw_generator_wrapper(
            orig, "autogen", "agent.run_stream", "workflow", is_async=True,
        )

    if hasattr(BaseChatAgent, "on_messages"):
        orig = BaseChatAgent.on_messages
        _FW_ORIGINALS["autogen.BaseChatAgent.on_messages"] = orig
        BaseChatAgent.on_messages = _make_fw_wrapper(
            orig, "autogen", "agent.on_messages", "agent", is_async=True,
        )

    if hasattr(BaseChatAgent, "on_messages_stream"):
        orig = BaseChatAgent.on_messages_stream
        _FW_ORIGINALS["autogen.BaseChatAgent.on_messages_stream"] = orig
        BaseChatAgent.on_messages_stream = _make_fw_generator_wrapper(
            orig, "autogen", "agent.on_messages_stream", "agent", is_async=True,
        )

    _PATCHED_FRAMEWORKS.add("autogen")
    logger.info("Auto-instrumented AutoGen")
    return True


def _patch_openai_agents() -> bool:
    """Patch OpenAI Agents SDK Runner."""
    if "openai_agents" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from agents import Runner
    except ImportError:
        return False

    if hasattr(Runner, "run"):
        orig = Runner.run
        _FW_ORIGINALS["openai_agents.Runner.run"] = orig
        Runner.run = _make_fw_wrapper(
            orig, "openai_agents", "runner.run", "workflow", is_async=True,
        )

    if hasattr(Runner, "run_sync"):
        orig = Runner.run_sync
        _FW_ORIGINALS["openai_agents.Runner.run_sync"] = orig
        Runner.run_sync = _make_fw_wrapper(
            orig, "openai_agents", "runner.run", "workflow",
        )

    if hasattr(Runner, "run_streamed"):
        orig = Runner.run_streamed
        _FW_ORIGINALS["openai_agents.Runner.run_streamed"] = orig
        Runner.run_streamed = _make_fw_generator_wrapper(
            orig, "openai_agents", "runner.run_streamed", "workflow",
            is_async=True,
        )

    _PATCHED_FRAMEWORKS.add("openai_agents")
    logger.info("Auto-instrumented OpenAI Agents SDK")
    return True


def _patch_google_adk() -> bool:
    """Patch Google ADK Runner."""
    if "google_adk" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from google.adk.runners import Runner
    except ImportError:
        return False

    # Runner.run -> sync generator (yields Event)
    if hasattr(Runner, "run"):
        orig = Runner.run
        _FW_ORIGINALS["google_adk.Runner.run"] = orig
        Runner.run = _make_fw_generator_wrapper(
            orig, "google_adk", "runner.run", "workflow",
        )

    # Runner.run_async -> async generator (yields Event)
    if hasattr(Runner, "run_async"):
        orig = Runner.run_async
        _FW_ORIGINALS["google_adk.Runner.run_async"] = orig
        Runner.run_async = _make_fw_generator_wrapper(
            orig, "google_adk", "runner.run", "workflow", is_async=True,
        )

    # Runner.run_live -> async generator (yields Event)
    if hasattr(Runner, "run_live"):
        orig = Runner.run_live
        _FW_ORIGINALS["google_adk.Runner.run_live"] = orig
        Runner.run_live = _make_fw_generator_wrapper(
            orig, "google_adk", "runner.run_live", "workflow", is_async=True,
        )

    _PATCHED_FRAMEWORKS.add("google_adk")
    logger.info("Auto-instrumented Google ADK")
    return True


def _patch_ms_agent_framework() -> bool:
    """Patch Microsoft Agent Framework ChatAgent."""
    if "ms_agent_framework" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from agent_framework import ChatAgent
    except ImportError:
        return False

    # ChatAgent.run -> async, returns AgentRunResponse
    if hasattr(ChatAgent, "run"):
        orig = ChatAgent.run
        _FW_ORIGINALS["ms_agent_framework.ChatAgent.run"] = orig
        ChatAgent.run = _make_fw_wrapper(
            orig, "ms_agent_framework", "agent.run", "agent", is_async=True,
        )

    # ChatAgent.run_stream -> async, returns AsyncIterable
    if hasattr(ChatAgent, "run_stream"):
        orig = ChatAgent.run_stream
        _FW_ORIGINALS["ms_agent_framework.ChatAgent.run_stream"] = orig
        ChatAgent.run_stream = _make_fw_generator_wrapper(
            orig, "ms_agent_framework", "agent.run_stream", "agent",
            is_async=True,
        )

    _PATCHED_FRAMEWORKS.add("ms_agent_framework")
    logger.info("Auto-instrumented Microsoft Agent Framework")
    return True


def _patch_langchain_tools() -> bool:
    """Patch LangChain BaseTool to trace all tool invocations.

    This patches ``BaseTool.invoke`` and ``BaseTool.ainvoke`` so that every
    LangChain tool — built-in (Tavily, Wikipedia, …), ``@tool`` decorated,
    and ``StructuredTool`` — is automatically traced with an OTel span.

    The span includes:
        - Tool name and description
        - Input arguments and output result
        - Execution time and error status
    """
    if "langchain_tools" in _PATCHED_FRAMEWORKS:
        return True

    try:
        from langchain_core.tools import BaseTool
    except ImportError:
        return False

    # --- Patch BaseTool.invoke ---
    if hasattr(BaseTool, "invoke"):
        orig_invoke = BaseTool.invoke
        if getattr(orig_invoke, "_agentops_patched", False):
            _PATCHED_FRAMEWORKS.add("langchain_tools")
            return True
        _FW_ORIGINALS["langchain_tools.BaseTool.invoke"] = orig_invoke

        @functools.wraps(orig_invoke)
        def traced_invoke(self_obj: Any, input: Any, config: Any = None, **kwargs: Any) -> Any:
            tool_name = getattr(self_obj, "name", type(self_obj).__name__)
            span_name = f"tool.{tool_name}"
            with _get_tracer().start_as_current_span(span_name) as span:
                span.set_attribute("agentops.observation_type", "tool")
                span.set_attribute("gen_ai.operation.name", "execute_tool")
                span.set_attribute("agentops.tool_name", tool_name)
                desc = getattr(self_obj, "description", "")
                if desc:
                    span.set_attribute("agentops.tool_description", str(desc)[:500])
                span.set_attribute("agentops.input", _safe_serialize(input))
                span.set_attribute("agentops.tool_input", _safe_serialize(input))
                _apply_baggage_to_span(span)
                try:
                    result = orig_invoke(self_obj, input, config, **kwargs)
                    serialized = _safe_serialize(result)
                    span.set_attribute("agentops.output", serialized)
                    span.set_attribute("agentops.tool_output", serialized)
                    return result
                except Exception as exc:
                    span.set_status(StatusCode.ERROR, str(exc))
                    span.record_exception(exc)
                    span.set_attribute("error.type", type(exc).__name__)
                    raise

        traced_invoke._agentops_patched = True  # type: ignore[attr-defined]
        BaseTool.invoke = traced_invoke  # type: ignore[assignment]

    # --- Patch BaseTool.ainvoke ---
    if hasattr(BaseTool, "ainvoke"):
        orig_ainvoke = BaseTool.ainvoke
        if not getattr(orig_ainvoke, "_agentops_patched", False):
            _FW_ORIGINALS["langchain_tools.BaseTool.ainvoke"] = orig_ainvoke

            @functools.wraps(orig_ainvoke)
            async def traced_ainvoke(self_obj: Any, input: Any, config: Any = None, **kwargs: Any) -> Any:
                tool_name = getattr(self_obj, "name", type(self_obj).__name__)
                span_name = f"tool.{tool_name}"
                with _get_tracer().start_as_current_span(span_name) as span:
                    span.set_attribute("agentops.observation_type", "tool")
                    span.set_attribute("gen_ai.operation.name", "execute_tool")
                    span.set_attribute("agentops.tool_name", tool_name)
                    desc = getattr(self_obj, "description", "")
                    if desc:
                        span.set_attribute("agentops.tool_description", str(desc)[:500])
                    span.set_attribute("agentops.input", _safe_serialize(input))
                    span.set_attribute("agentops.tool_input", _safe_serialize(input))
                    _apply_baggage_to_span(span)
                    try:
                        result = await orig_ainvoke(self_obj, input, config, **kwargs)
                        serialized = _safe_serialize(result)
                        span.set_attribute("agentops.output", serialized)
                        span.set_attribute("agentops.tool_output", serialized)
                        return result
                    except Exception as exc:
                        span.set_status(StatusCode.ERROR, str(exc))
                        span.record_exception(exc)
                        span.set_attribute("error.type", type(exc).__name__)
                        raise

            traced_ainvoke._agentops_patched = True  # type: ignore[attr-defined]
            BaseTool.ainvoke = traced_ainvoke  # type: ignore[assignment]

    _PATCHED_FRAMEWORKS.add("langchain_tools")
    logger.info("Auto-instrumented LangChain Tools (BaseTool.invoke/ainvoke)")
    return True


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------

_FRAMEWORK_PATCHERS: dict[str, Any] = {
    "langgraph": _patch_langgraph,
    "langchain_tools": _patch_langchain_tools,
    "crewai": _patch_crewai,
    "autogen": _patch_autogen,
    "openai_agents": _patch_openai_agents,
    "google_adk": _patch_google_adk,
    "ms_agent_framework": _patch_ms_agent_framework,
}


def _register_extra_frameworks() -> None:
    """Register extra framework patchers from auto_framework_extra module."""
    try:
        from agent_ops_sdk.instrument.auto_framework_extra import (
            EXTRA_FRAMEWORK_PATCHERS,
        )
        _FRAMEWORK_PATCHERS.update(EXTRA_FRAMEWORK_PATCHERS)
    except ImportError:
        logger.debug("auto_framework_extra not available", exc_info=True)


_register_extra_frameworks()


def patch_frameworks(frameworks: list[str] | None = None) -> list[str]:
    """Patch agent frameworks for automatic tracing.

    Tries to import and patch each framework. Frameworks that are not
    installed are silently skipped.

    Args:
        frameworks: List of framework names to patch. Defaults to all.
            Valid names: "langgraph", "crewai", "autogen", "openai_agents",
            "google_adk", "ms_agent_framework".

    Returns:
        List of successfully patched framework names.
    """
    targets = frameworks or list(_FRAMEWORK_PATCHERS.keys())
    patched: list[str] = []

    for name in targets:
        patcher = _FRAMEWORK_PATCHERS.get(name)
        if patcher is None:
            logger.warning("Unknown framework: %s", name)
            continue
        try:
            if patcher():
                patched.append(name)
        except Exception:
            logger.debug("Failed to patch %s", name, exc_info=True)

    return patched


def _unpatch_by_prefix(
    prefix: str,
    import_fn: Any,
    cls_attr_map: dict[str, str] | None = None,
) -> None:
    """Unpatch all _FW_ORIGINALS keys starting with *prefix*.

    Args:
        prefix: Key prefix in _FW_ORIGINALS (e.g. "langchain.").
        import_fn: Callable returning (cls, key_prefix) pairs to restore,
            or None on ImportError.
        cls_attr_map: If provided, maps key sub-prefixes to class references.
            Not used when import_fn returns the mapping directly.
    """
    if not any(k.startswith(prefix) for k in _FW_ORIGINALS):
        return
    try:
        targets = import_fn()  # list of (cls, key_prefix)
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith(prefix):
                _FW_ORIGINALS.pop(key, None)
        return

    for cls, key_pfx in targets:
        for key in list(_FW_ORIGINALS):
            if key.startswith(key_pfx):
                method_name = key.split(".")[-1]
                setattr(cls, method_name, _FW_ORIGINALS.pop(key))


def unpatch_frameworks() -> None:
    """Restore all patched framework methods to their originals."""
    # LangGraph
    try:
        if any(k.startswith("langgraph.") for k in _FW_ORIGINALS):
            from langgraph.pregel import Pregel

            for key in list(_FW_ORIGINALS):
                if key.startswith("langgraph.Pregel."):
                    method_name = key.split(".")[-1]
                    setattr(Pregel, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("langgraph."):
                _FW_ORIGINALS.pop(key, None)

    # LangChain Tools
    try:
        if any(k.startswith("langchain_tools.") for k in _FW_ORIGINALS):
            from langchain_core.tools import BaseTool

            for key in list(_FW_ORIGINALS):
                if key.startswith("langchain_tools.BaseTool."):
                    method_name = key.split(".")[-1]
                    setattr(BaseTool, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("langchain_tools."):
                _FW_ORIGINALS.pop(key, None)

    # CrewAI
    try:
        if any(k.startswith("crewai.Crew.") for k in _FW_ORIGINALS):
            from crewai import Crew

            for key in list(_FW_ORIGINALS):
                if key.startswith("crewai.Crew."):
                    method_name = key.split(".")[-1]
                    setattr(Crew, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("crewai.Crew."):
                _FW_ORIGINALS.pop(key, None)

    try:
        if any(k.startswith("crewai.Agent.") for k in _FW_ORIGINALS):
            from crewai import Agent as CrewAgent

            for key in list(_FW_ORIGINALS):
                if key.startswith("crewai.Agent."):
                    method_name = key.split(".")[-1]
                    setattr(CrewAgent, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("crewai.Agent."):
                _FW_ORIGINALS.pop(key, None)

    try:
        if any(k.startswith("crewai.Task.") for k in _FW_ORIGINALS):
            from crewai import Task as CrewTask

            for key in list(_FW_ORIGINALS):
                if key.startswith("crewai.Task."):
                    method_name = key.split(".")[-1]
                    setattr(CrewTask, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("crewai.Task."):
                _FW_ORIGINALS.pop(key, None)

    # AutoGen
    try:
        if any(k.startswith("autogen.") for k in _FW_ORIGINALS):
            from autogen_agentchat.agents import BaseChatAgent

            for key in list(_FW_ORIGINALS):
                if key.startswith("autogen.BaseChatAgent."):
                    method_name = key.split(".")[-1]
                    setattr(BaseChatAgent, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("autogen."):
                _FW_ORIGINALS.pop(key, None)

    # OpenAI Agents SDK
    try:
        if any(k.startswith("openai_agents.") for k in _FW_ORIGINALS):
            from agents import Runner

            for key in list(_FW_ORIGINALS):
                if key.startswith("openai_agents.Runner."):
                    method_name = key.split(".")[-1]
                    setattr(Runner, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("openai_agents."):
                _FW_ORIGINALS.pop(key, None)

    # Google ADK
    try:
        if any(k.startswith("google_adk.") for k in _FW_ORIGINALS):
            from google.adk.runners import Runner as AdkRunner

            for key in list(_FW_ORIGINALS):
                if key.startswith("google_adk.Runner."):
                    method_name = key.split(".")[-1]
                    setattr(AdkRunner, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("google_adk."):
                _FW_ORIGINALS.pop(key, None)

    # Microsoft Agent Framework
    try:
        if any(k.startswith("ms_agent_framework.") for k in _FW_ORIGINALS):
            from agent_framework import ChatAgent

            for key in list(_FW_ORIGINALS):
                if key.startswith("ms_agent_framework.ChatAgent."):
                    method_name = key.split(".")[-1]
                    setattr(ChatAgent, method_name, _FW_ORIGINALS.pop(key))
    except ImportError:
        for key in list(_FW_ORIGINALS):
            if key.startswith("ms_agent_framework."):
                _FW_ORIGINALS.pop(key, None)

    # LangChain
    def _import_langchain():
        from langchain.agents import AgentExecutor
        return [(AgentExecutor, "langchain.AgentExecutor.")]

    _unpatch_by_prefix("langchain.", _import_langchain)

    # LlamaIndex
    def _import_llamaindex():
        targets = []
        try:
            from llama_index.core.base.query_engine import BaseQueryEngine
            targets.append((BaseQueryEngine, "llamaindex.BaseQueryEngine."))
        except ImportError:
            try:
                from llama_index.core.query_engine import BaseQueryEngine
                targets.append((BaseQueryEngine, "llamaindex.BaseQueryEngine."))
            except ImportError:
                pass
        try:
            from llama_index.core.chat_engine.types import BaseChatEngine
            targets.append((BaseChatEngine, "llamaindex.BaseChatEngine."))
        except ImportError:
            try:
                from llama_index.core.chat_engine import BaseChatEngine
                targets.append((BaseChatEngine, "llamaindex.BaseChatEngine."))
            except ImportError:
                pass
        if not targets:
            raise ImportError("llama_index not available")
        return targets

    _unpatch_by_prefix("llamaindex.", _import_llamaindex)

    # Haystack
    def _import_haystack():
        from haystack import Pipeline
        return [(Pipeline, "haystack.Pipeline.")]

    _unpatch_by_prefix("haystack.", _import_haystack)

    # Agno
    def _import_agno():
        from agno.agent import Agent
        return [(Agent, "agno.Agent.")]

    _unpatch_by_prefix("agno.", _import_agno)

    # Smolagents
    def _import_smolagents():
        from smolagents.agents import MultiStepAgent
        return [(MultiStepAgent, "smolagents.MultiStepAgent.")]

    _unpatch_by_prefix("smolagents.", _import_smolagents)

    _PATCHED_FRAMEWORKS.clear()
    _FW_ORIGINALS.clear()
    logger.info("Unpatched all frameworks")
