"""Base stream wrapper classes for traced iterators.

Shared by auto_instrument.py (LLM providers) and auto_framework.py (agent frameworks).
Subclasses override _on_finalize() to add domain-specific logic.
"""

from __future__ import annotations

from typing import Any

from opentelemetry.trace import StatusCode

_MAX_CHUNKS = 1_000  # prevent unbounded memory growth


class _BaseTracedSyncStream:
    """Base sync iterator wrapper that ends the span when exhausted."""

    __slots__ = ("_stream", "_span", "_chunks", "_finalized")

    def __init__(self, stream: Any, span: Any) -> None:
        self._stream = stream
        self._span = span
        self._chunks: list[Any] = []
        self._finalized = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            if len(self._chunks) < _MAX_CHUNKS:
                self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._finalize()
            raise
        except Exception as exc:
            self._span.set_status(StatusCode.ERROR, str(exc))
            self._span.record_exception(exc)
            self._span.set_attribute("error.type", type(exc).__name__)
            self._finalize()
            raise

    def _finalize(self) -> None:
        if self._finalized:
            return
        self._finalized = True
        self._on_finalize()
        self._span.end()

    def _on_finalize(self) -> None:
        """Override to add custom finalization logic (e.g. LLM attribute extraction)."""

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args: object) -> None:
        self._finalize()
        if hasattr(self._stream, "__exit__"):
            self._stream.__exit__(*args)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


class _BaseTracedAsyncStream:
    """Base async iterator wrapper that ends the span when exhausted."""

    __slots__ = ("_stream", "_span", "_chunks", "_finalized")

    def __init__(self, stream: Any, span: Any) -> None:
        self._stream = stream
        self._span = span
        self._chunks: list[Any] = []
        self._finalized = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
            if len(self._chunks) < _MAX_CHUNKS:
                self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            self._finalize()
            raise
        except Exception as exc:
            self._span.set_status(StatusCode.ERROR, str(exc))
            self._span.record_exception(exc)
            self._span.set_attribute("error.type", type(exc).__name__)
            self._finalize()
            raise

    def _finalize(self) -> None:
        if self._finalized:
            return
        self._finalized = True
        self._on_finalize()
        self._span.end()

    def _on_finalize(self) -> None:
        """Override to add custom finalization logic."""

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args: object) -> None:
        self._finalize()
        if hasattr(self._stream, "__aexit__"):
            await self._stream.__aexit__(*args)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)
