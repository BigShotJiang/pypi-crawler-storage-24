"""컨텍스트 전파: user_id, session_id, trace_id, observation_id.

OpenTelemetry Baggage를 사용하여 트레이스 레벨 속성을 전파한다.
``update_current_observation()``으로 수동 모델/사용량 보고 가능.
"""

from __future__ import annotations

import contextlib
import json
import logging
from typing import Any, Generator

from opentelemetry import baggage, context, trace
from opentelemetry.trace import format_span_id, format_trace_id

logger = logging.getLogger("agent_ops_sdk.instrument.context")

# Baggage로 전파할 키 목록
_BAGGAGE_KEYS = (
    "agentops.user_id",
    "agentops.session_id",
    "agentops.tenant_id",
    "agentops.request_id",
    "agentops.workflow_id",
    "agentops.metadata",
    "agentops.tags",
)


def _apply_baggage_to_span(span: trace.Span) -> None:
    """Baggage 값을 현재 스팬의 속성으로 복사."""
    for key in _BAGGAGE_KEYS:
        val = baggage.get_baggage(key)
        if val is not None:
            span.set_attribute(key, val)


@contextlib.contextmanager
def trace_context(
    *,
    user_id: str | None = None,
    session_id: str | None = None,
    tenant_id: str | None = None,
    request_id: str | None = None,
    workflow_id: str | None = None,
    metadata: dict[str, Any] | None = None,
    tags: list[str] | None = None,
) -> Generator[None, None, None]:
    """중첩된 @instrument 호출에 트레이스 레벨 컨텍스트를 설정.

    OTel Baggage를 사용하여 식별자와 메타데이터를
    이 컨텍스트 내에서 생성된 모든 자식 관측에 전달한다.

    Args:
        user_id: 사용자 식별자.
        session_id: 세션 식별자.
        tenant_id: 테넌트/조직 식별자.
        request_id: 요청 식별자 (단일 호출).
        workflow_id: 워크플로우/파이프라인 식별자.
        metadata: 추가 메타데이터 dict.
        tags: 태그 목록 (선택).
    """
    ctx = context.get_current()
    _baggage_mapping = {
        "agentops.user_id": user_id,
        "agentops.session_id": session_id,
        "agentops.tenant_id": tenant_id,
        "agentops.request_id": request_id,
        "agentops.workflow_id": workflow_id,
    }
    for baggage_key, value in _baggage_mapping.items():
        if value is not None:
            ctx = baggage.set_baggage(baggage_key, value, ctx)
    if metadata is not None:
        ctx = baggage.set_baggage("agentops.metadata", json.dumps(metadata), ctx)
    if tags is not None:
        ctx = baggage.set_baggage("agentops.tags", json.dumps(tags), ctx)

    token = context.attach(ctx)
    try:
        yield
    finally:
        context.detach(token)


def update_current_observation(
    *,
    model: str | None = None,
    usage_input_tokens: int | None = None,
    usage_output_tokens: int | None = None,
    usage_total_tokens: int | None = None,
    provider: str | None = None,
    finish_reason: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    top_p: float | None = None,
    top_k: int | None = None,
    frequency_penalty: float | None = None,
    presence_penalty: float | None = None,
    stop_sequences: list[str] | None = None,
    server_address: str | None = None,
    server_port: int | None = None,
    response_id: str | None = None,
    response_model: str | None = None,
    conversation_id: str | None = None,
    prompt_template_id: str | None = None,
    prompt_hash: str | None = None,
    cache_hit: bool | None = None,
    cost: float | None = None,
) -> None:
    """현재 관측에 모델/토큰/프롬프트/비용 정보를 기록.

    ``@instrument`` 데코레이터 함수 내에서 호출하면
    현재 스팬에 LLM 세부사항을 기록한다.

    Args:
        model: LLM 모델명 (gen_ai.request.model).
        usage_input_tokens: 입력 토큰 수 (gen_ai.usage.input_tokens).
        usage_output_tokens: 출력 토큰 수 (gen_ai.usage.output_tokens).
        usage_total_tokens: 총 토큰 수 (gen_ai.usage.total_tokens).
        provider: LLM 프로바이더 (gen_ai.system).
        finish_reason: 종료 사유 (gen_ai.response.finish_reason).
        temperature: 샘플링 온도 (gen_ai.request.temperature).
        max_tokens: 최대 출력 토큰 (gen_ai.request.max_tokens).
        top_p: Nucleus 샘플링 (gen_ai.request.top_p).
        top_k: Top-K 샘플링 (gen_ai.request.top_k).
        frequency_penalty: 빈도 페널티 (gen_ai.request.frequency_penalty).
        presence_penalty: 존재 페널티 (gen_ai.request.presence_penalty).
        stop_sequences: 중지 시퀀스 목록 (gen_ai.request.stop_sequences).
        server_address: API 서버 주소 (server.address).
        server_port: API 서버 포트 (server.port).
        response_id: 응답 ID (gen_ai.response.id).
        response_model: 실제 사용된 모델 (gen_ai.response.model).
        conversation_id: 대화 스레드 ID (gen_ai.conversation.id).
        prompt_template_id: 프롬프트 템플릿 식별자.
        prompt_hash: 프롬프트 콘텐츠 해시 (버전 관리용).
        cache_hit: 캐시 히트 여부.
        cost: 예상 비용 (USD).
    """
    try:
        span = trace.get_current_span()

        # --- GenAI 표준 속성 (gen_ai.*) ---
        # 단순 key→attr 매핑은 루프로 처리
        _gen_ai_attrs: list[tuple[str, Any]] = [
            ("gen_ai.request.model", model),
            ("gen_ai.usage.input_tokens", usage_input_tokens),
            ("gen_ai.usage.output_tokens", usage_output_tokens),
            ("gen_ai.request.temperature", temperature),
            ("gen_ai.request.max_tokens", max_tokens),
            ("gen_ai.request.top_p", top_p),
            ("gen_ai.request.top_k", top_k),
            ("gen_ai.request.frequency_penalty", frequency_penalty),
            ("gen_ai.request.presence_penalty", presence_penalty),
            ("gen_ai.request.stop_sequences", stop_sequences),
            ("gen_ai.response.id", response_id),
            ("gen_ai.response.model", response_model),
            ("gen_ai.conversation.id", conversation_id),
            ("server.address", server_address),
            ("server.port", server_port),
        ]
        for attr_name, value in _gen_ai_attrs:
            if value is not None:
                span.set_attribute(attr_name, value)

        # total_tokens 자동 계산
        total = usage_total_tokens
        if total is None and usage_input_tokens is not None and usage_output_tokens is not None:
            total = usage_input_tokens + usage_output_tokens
        if total is not None:
            span.set_attribute("gen_ai.usage.total_tokens", total)

        # provider는 두 속성에 동시 설정
        if provider is not None:
            span.set_attribute("gen_ai.system", provider)
            span.set_attribute("gen_ai.provider.name", provider)

        # finish_reason은 단수+튜플 동시 설정
        if finish_reason is not None:
            span.set_attribute("gen_ai.response.finish_reason", finish_reason)
            span.set_attribute("gen_ai.response.finish_reasons", (finish_reason,))

        # --- AgentOps 커스텀 속성 (agentops.*) ---
        _agentops_attrs: list[tuple[str, Any]] = [
            ("agentops.prompt_template_id", prompt_template_id),
            ("agentops.prompt_hash", prompt_hash),
            ("agentops.cache_hit", cache_hit),
            ("agentops.cost", cost),
        ]
        for attr_name, value in _agentops_attrs:
            if value is not None:
                span.set_attribute(attr_name, value)

    except Exception:
        logger.debug("관측 업데이트 실패", exc_info=True)


def get_current_trace_id() -> str | None:
    """현재 OTel 컨텍스트에서 trace_id를 가져온다."""
    try:
        ctx = trace.get_current_span().get_span_context()
        if ctx.trace_id:
            return format_trace_id(ctx.trace_id)
        return None
    except Exception:
        return None


def set_observation_io(
    *,
    input_text: str | None = None,
    output_text: str | None = None,
    retrieved_docs: list[str] | None = None,
) -> None:
    """현재 관측에 input/output/retrieved_docs를 설정.

    ``@instrument`` 블록 내에서 호출하면 자동 캡처된 값을 덮어쓴다.
    RAG 파이프라인에서는 *retrieved_docs*를 사용하여
    컨텍스트 관련성 평가를 활성화한다.

    Args:
        input_text: agentops.input 오버라이드.
        output_text: agentops.output 오버라이드.
        retrieved_docs: 검색된 문서 문자열 목록.
    """
    try:
        span = trace.get_current_span()
        if input_text is not None:
            span.set_attribute("agentops.input", input_text)
        if output_text is not None:
            span.set_attribute("agentops.output", output_text)
            span.set_attribute("agentops._manual_output", True)
        if retrieved_docs is not None:
            span.set_attribute("agentops.retrieved_docs", json.dumps(retrieved_docs))
    except Exception:
        logger.debug("관측 IO 설정 실패", exc_info=True)


def get_current_observation_id() -> str | None:
    """현재 OTel 컨텍스트에서 observation_id (span_id)를 가져온다."""
    try:
        ctx = trace.get_current_span().get_span_context()
        if ctx.span_id:
            return format_span_id(ctx.span_id)
        return None
    except Exception:
        return None
