"""@instrument decorator - wraps OTel tracer for function tracing.

Provides ``@instrument(as_type="agent")`` syntax using OpenTelemetry spans.
Supports sync/async functions, generators, async generators, and classes.
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import json
import time
from typing import Any, AsyncIterator, Callable, Iterator, TypeVar, overload

from opentelemetry import context as otel_context, trace
from opentelemetry.trace import StatusCode

from agent_ops_sdk.instrument.context import _apply_baggage_to_span
from agent_ops_sdk.instrument.llm_extractors import extract_llm_usage
from agent_ops_sdk.instrument.span_types import validate_observation_type
from agent_ops_sdk.telemetry.metrics import get_metrics

F = TypeVar("F", bound=Callable[..., object])

_MAX_IO_LENGTH = 10_000  # 10KB limit per attribute

_TRACER_NAME = "agent_ops_sdk"

# Map observation_type → gen_ai.operation.name (OTel GenAI semantic convention)
_OBS_TYPE_TO_OPERATION: dict[str, str] = {
    "generation": "chat",
    "tool": "execute_tool",
    "agent": "invoke_agent",
    "embedding": "embeddings",
}


def _safe_serialize(obj: object, max_len: int = _MAX_IO_LENGTH) -> str:
    """Serialize *obj* to a JSON string, truncating if too long."""
    try:
        text = json.dumps(obj, default=str, ensure_ascii=False)
    except Exception:
        text = str(obj)
    if len(text) > max_len:
        return text[:max_len] + "...[truncated]"
    return text


def _get_param_names(func: Callable[..., object]) -> list[str]:
    """Extract parameter names from function signature (cached at decoration time)."""
    try:
        return list(inspect.signature(func).parameters.keys())
    except (ValueError, TypeError):
        return []


def _capture_input(span: trace.Span, param_names: list[str], args: tuple, kwargs: dict) -> None:
    """Record function arguments as ``agentops.input`` span attribute."""
    try:
        input_dict: dict[str, object] = {}
        for i, arg in enumerate(args):
            key = param_names[i] if i < len(param_names) else f"arg_{i}"
            input_dict[key] = arg
        input_dict.update(kwargs)
        span.set_attribute("agentops.input", _safe_serialize(input_dict))
    except Exception:
        pass  # Non-breaking


def _capture_output(span: trace.Span, result: object, obs_type: str) -> None:
    """Record return value as ``agentops.output`` span attribute."""
    try:
        manual_output = span.attributes.get("agentops._manual_output") if span.attributes else None
        if not manual_output:
            serialized = _safe_serialize(result)
            span.set_attribute("agentops.output", serialized)
        else:
            serialized = span.attributes.get("agentops.output", "") if span.attributes else ""
        if obs_type == "tool":
            input_val = span.attributes.get("agentops.input") if span.attributes else None
            if input_val:
                span.set_attribute("agentops.tool_input", input_val)
            span.set_attribute("agentops.tool_output", serialized)
        elif obs_type == "retriever":
            # Auto-set retrieved_docs from output for evaluation metrics
            manual_docs = span.attributes.get("agentops.retrieved_docs") if span.attributes else None
            if not manual_docs:
                span.set_attribute("agentops.retrieved_docs", serialized)
    except Exception:
        pass  # Non-breaking


def _get_tracer() -> trace.Tracer:
    """Get the tracer from the current TracerProvider (supports dynamic provider changes)."""
    return trace.get_tracer(_TRACER_NAME)


def _record_span_metrics(
    obs_type: str, duration_ms: float, error: bool, result: object,
) -> None:
    """Record metrics for a completed span (non-breaking)."""
    try:
        m = get_metrics()
        if m is None:
            return
        attrs = {"agentops.observation_type": obs_type}
        if m.span_duration:
            m.span_duration.record(duration_ms, attrs)
        if error and m.errors:
            m.errors.add(1, attrs)
        if obs_type == "tool" and m.tool_calls:
            m.tool_calls.add(1, attrs)
            if m.tool_latency:
                m.tool_latency.record(duration_ms, attrs)
        if obs_type == "generation":
            if m.llm_requests:
                m.llm_requests.add(1, attrs)
            if m.llm_latency:
                m.llm_latency.record(duration_ms, attrs)
            # Token counters
            info = extract_llm_usage(result)
            if info:
                if "usage_input_tokens" in info and m.tokens_input:
                    m.tokens_input.add(info["usage_input_tokens"], attrs)
                if "usage_output_tokens" in info and m.tokens_output:
                    m.tokens_output.add(info["usage_output_tokens"], attrs)
    except Exception:
        pass  # Non-breaking


def _apply_llm_attributes(span: trace.Span, result: object) -> None:
    """Extract LLM usage from the result and set as span attributes."""
    info = extract_llm_usage(result)
    if not info:
        return
    model = info.get("model")
    if model:
        span.set_attribute("gen_ai.request.model", model)
        span.set_attribute("gen_ai.response.model", model)
    if "usage_input_tokens" in info:
        span.set_attribute("gen_ai.usage.input_tokens", info["usage_input_tokens"])
    if "usage_output_tokens" in info:
        span.set_attribute("gen_ai.usage.output_tokens", info["usage_output_tokens"])
    if "usage_total_tokens" in info:
        span.set_attribute("gen_ai.usage.total_tokens", info["usage_total_tokens"])
    if "provider" in info:
        span.set_attribute("gen_ai.system", info["provider"])
        span.set_attribute("gen_ai.provider.name", info["provider"])
    if "finish_reason" in info:
        reason = info["finish_reason"]
        span.set_attribute("gen_ai.response.finish_reason", reason)
        span.set_attribute("gen_ai.response.finish_reasons", (reason,))
    if "response_id" in info:
        span.set_attribute("gen_ai.response.id", info["response_id"])


# ------------------------------------------------------------------
# Span setup helper (shared by all wrappers)
# ------------------------------------------------------------------


def _setup_span(span: trace.Span, obs_type: str) -> None:
    """Set observation type and operation name on a span."""
    span.set_attribute("agentops.observation_type", obs_type)
    operation = _OBS_TYPE_TO_OPERATION.get(obs_type)
    if operation:
        span.set_attribute("gen_ai.operation.name", operation)
    _apply_baggage_to_span(span)


# ------------------------------------------------------------------
# Generator / AsyncGenerator wrappers (P1: Streaming support)
# ------------------------------------------------------------------


_MAX_CHUNKS = 1_000  # C-3: prevent unbounded memory growth


def _traced_generator(
    gen: Iterator[Any],
    span: trace.Span,
    obs_type: str,
) -> Iterator[Any]:
    """Wrap a sync generator to collect chunks and finalize the span."""
    ctx = trace.set_span_in_context(span)
    token = otel_context.attach(ctx)
    chunks: list[Any] = []
    _t0 = time.monotonic()
    _err = False
    try:
        for chunk in gen:
            if len(chunks) < _MAX_CHUNKS:
                chunks.append(chunk)
            yield chunk
    except Exception as exc:
        _err = True
        span.set_status(StatusCode.ERROR, str(exc))
        span.record_exception(exc)
        span.set_attribute("error.type", type(exc).__name__)
        raise
    finally:
        otel_context.detach(token)
        if chunks:
            _capture_output(span, chunks, obs_type)
            if obs_type == "generation":
                _apply_llm_attributes(span, chunks[-1])
        _record_span_metrics(obs_type, (time.monotonic() - _t0) * 1000, _err, chunks[-1] if chunks else None)
        span.end()


async def _traced_async_generator(
    agen: AsyncIterator[Any],
    span: trace.Span,
    obs_type: str,
) -> AsyncIterator[Any]:
    """Wrap an async generator to collect chunks and finalize the span."""
    ctx = trace.set_span_in_context(span)
    token = otel_context.attach(ctx)
    chunks: list[Any] = []
    _t0 = time.monotonic()
    _err = False
    try:
        async for chunk in agen:
            if len(chunks) < _MAX_CHUNKS:
                chunks.append(chunk)
            yield chunk
    except Exception as exc:
        _err = True
        span.set_status(StatusCode.ERROR, str(exc))
        span.record_exception(exc)
        span.set_attribute("error.type", type(exc).__name__)
        raise
    finally:
        otel_context.detach(token)
        if chunks:
            _capture_output(span, chunks, obs_type)
            if obs_type == "generation":
                _apply_llm_attributes(span, chunks[-1])
        _record_span_metrics(obs_type, (time.monotonic() - _t0) * 1000, _err, chunks[-1] if chunks else None)
        span.end()


# ------------------------------------------------------------------
# Class decorating helper (P3)
# ------------------------------------------------------------------


def _instrument_class(cls: type, as_type: str, obs_name: str | None) -> type:
    """Instrument a class by wrapping its ``__call__`` method."""
    if not hasattr(cls, "__call__") or cls.__call__ is object.__call__:
        return cls

    original_call = cls.__call__
    span_name = obs_name or cls.__name__
    obs_type = validate_observation_type(as_type)
    # I-8: cache param names at decoration time, excluding 'self'
    _param_names = [p for p in _get_param_names(original_call) if p != "self"]

    if asyncio.iscoroutinefunction(original_call):

        @functools.wraps(original_call)
        async def async_call_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
            with _get_tracer().start_as_current_span(span_name) as span:
                _setup_span(span, obs_type)
                _capture_input(span, _param_names, args, kwargs)
                try:
                    result = await original_call(self_obj, *args, **kwargs)
                    _capture_output(span, result, obs_type)
                    if obs_type == "generation":
                        _apply_llm_attributes(span, result)
                    return result
                except Exception as exc:
                    span.set_status(StatusCode.ERROR, str(exc))
                    span.record_exception(exc)
                    span.set_attribute("error.type", type(exc).__name__)
                    raise

        cls.__call__ = async_call_wrapper  # type: ignore[assignment]
    else:

        @functools.wraps(original_call)
        def call_wrapper(self_obj: Any, *args: Any, **kwargs: Any) -> Any:
            with _get_tracer().start_as_current_span(span_name) as span:
                _setup_span(span, obs_type)
                _capture_input(span, _param_names, args, kwargs)
                try:
                    result = original_call(self_obj, *args, **kwargs)
                    _capture_output(span, result, obs_type)
                    if obs_type == "generation":
                        _apply_llm_attributes(span, result)
                    return result
                except Exception as exc:
                    span.set_status(StatusCode.ERROR, str(exc))
                    span.record_exception(exc)
                    span.set_attribute("error.type", type(exc).__name__)
                    raise

        cls.__call__ = call_wrapper  # type: ignore[assignment]

    return cls


# ------------------------------------------------------------------
# Main decorator
# ------------------------------------------------------------------


@overload
def instrument(fn: F) -> F: ...


@overload
def instrument(
    *,
    as_type: str = "span",
    name: str | None = None,
) -> Callable[[F], F]: ...


def instrument(
    fn: F | None = None,
    *,
    as_type: str = "span",
    name: str | None = None,
) -> F | Callable[[F], F]:
    """Decorate a function or class to create a trace span via OpenTelemetry.

    Can be used with or without arguments::

        @instrument
        def foo(): ...

        @instrument(as_type="agent")
        def bar(): ...

        @instrument(as_type="generation", name="my-llm")
        async def baz(): ...

        @instrument(as_type="agent")
        class MyAgent:
            def __call__(self, query): ...

    Supports sync/async functions, generator/async-generator functions,
    and classes with ``__call__``.

    Args:
        fn: The function or class to wrap (when used without parens).
        as_type: Observation type (agent, tool, generation, span, etc.).
        name: Custom observation name. Defaults to function/class name.
    """

    def decorator(func_or_class: F) -> F:
        # P3: Class decorating
        if isinstance(func_or_class, type):
            return _instrument_class(func_or_class, as_type, name)  # type: ignore[return-value]

        func = func_or_class
        obs_type = validate_observation_type(as_type)
        obs_name = name or func.__name__
        _param_names = _get_param_names(func)  # I-7: cache at decoration time

        # P1: Generator function support
        if inspect.isgeneratorfunction(func):

            @functools.wraps(func)
            def gen_wrapper(*args: object, **kwargs: object) -> Iterator[Any]:
                span = _get_tracer().start_span(obs_name)
                _setup_span(span, obs_type)
                _capture_input(span, _param_names, args, kwargs)
                return _traced_generator(func(*args, **kwargs), span, obs_type)

            return gen_wrapper  # type: ignore[return-value]

        # P1: Async generator function support
        if inspect.isasyncgenfunction(func):

            @functools.wraps(func)
            def async_gen_wrapper(*args: object, **kwargs: object) -> AsyncIterator[Any]:
                span = _get_tracer().start_span(obs_name)
                _setup_span(span, obs_type)
                _capture_input(span, _param_names, args, kwargs)
                return _traced_async_generator(func(*args, **kwargs), span, obs_type)

            return async_gen_wrapper  # type: ignore[return-value]

        # Async coroutine function
        if asyncio.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: object, **kwargs: object) -> object:
                _t0 = time.monotonic()
                _err = False
                _result: object = None
                with _get_tracer().start_as_current_span(obs_name) as span:
                    _setup_span(span, obs_type)
                    _capture_input(span, _param_names, args, kwargs)
                    try:
                        _result = await func(*args, **kwargs)  # type: ignore[misc]
                        _capture_output(span, _result, obs_type)
                        if obs_type == "generation":
                            _apply_llm_attributes(span, _result)
                        return _result
                    except Exception as exc:
                        _err = True
                        span.set_status(StatusCode.ERROR, str(exc))
                        span.record_exception(exc)
                        span.set_attribute("error.type", type(exc).__name__)
                        raise
                    finally:
                        _record_span_metrics(
                            obs_type, (time.monotonic() - _t0) * 1000, _err, _result,
                        )

            return async_wrapper  # type: ignore[return-value]

        # Sync function (default)
        @functools.wraps(func)
        def wrapper(*args: object, **kwargs: object) -> object:
            _t0 = time.monotonic()
            _err = False
            _result: object = None
            with _get_tracer().start_as_current_span(obs_name) as span:
                _setup_span(span, obs_type)
                _capture_input(span, _param_names, args, kwargs)
                try:
                    _result = func(*args, **kwargs)
                    _capture_output(span, _result, obs_type)
                    if obs_type == "generation":
                        _apply_llm_attributes(span, _result)
                    return _result
                except Exception as exc:
                    _err = True
                    span.set_status(StatusCode.ERROR, str(exc))
                    span.record_exception(exc)
                    span.set_attribute("error.type", type(exc).__name__)
                    raise
                finally:
                    _record_span_metrics(
                        obs_type, (time.monotonic() - _t0) * 1000, _err, _result,
                    )

        return wrapper  # type: ignore[return-value]

    if fn is not None:
        return decorator(fn)
    return decorator  # type: ignore[return-value]
