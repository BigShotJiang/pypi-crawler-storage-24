"""Observation type mapping for instrumentation."""

from __future__ import annotations

import logging

from agent_ops_sdk.types import ObservationType

logger = logging.getLogger("agent_ops_sdk.instrument")

# Valid as_type values for @instrument decorator
VALID_OBSERVATION_TYPES: frozenset[str] = frozenset(t.value for t in ObservationType)


def validate_observation_type(as_type: str) -> str:
    """Validate and return the observation type string.

    Falls back to "span" for unrecognized types with a warning.
    """
    if as_type in VALID_OBSERVATION_TYPES:
        return as_type
    logger.warning(
        "Unknown observation type '%s', falling back to 'span'. "
        "Valid types: %s",
        as_type,
        ", ".join(sorted(VALID_OBSERVATION_TYPES)),
    )
    return "span"
