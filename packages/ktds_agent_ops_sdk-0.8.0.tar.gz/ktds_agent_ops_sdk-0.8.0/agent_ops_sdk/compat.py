"""Public API compatibility layer for AgentOps-style usage.

Provides module-level ``init()``, ``get_client()``, ``start_trace()``,
and ``end_trace()`` helpers so existing code can migrate with minimal changes.
"""

from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass
from typing import Any

from opentelemetry import context as otel_context, trace
from opentelemetry.trace import StatusCode

from agent_ops_sdk.client import AgentOpsClient
from agent_ops_sdk.types import AgentOpsConfig

logger = logging.getLogger("agent_ops_sdk.compat")

_client_lock = threading.Lock()
_client: AgentOpsClient | None = None


def _status_from_end_state(end_state: StatusCode | str | None) -> StatusCode:
    """Convert string end-state values to OpenTelemetry status codes."""
    if isinstance(end_state, StatusCode):
        return end_state
    if end_state is None:
        return StatusCode.UNSET

    text = str(end_state).strip().lower()
    if text in {"success", "ok", "passed", "pass"}:
        return StatusCode.OK
    if text in {"error", "failed", "failure", "exception", "indeterminate"}:
        return StatusCode.ERROR
    return StatusCode.UNSET


def get_client() -> AgentOpsClient:
    """Return the global singleton client."""
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = AgentOpsClient()
    return _client


def init(
    api_key: str | None = None,
    endpoint: str | None = None,
    app_url: str | None = None,
    *,
    service_name: str | None = None,
    enabled: bool | None = None,
    config: AgentOpsConfig | None = None,
    auto_instrument: bool = False,
    instrument_providers: list[str] | None = None,
    instrument_frameworks: bool | None = None,
    instrument_framework_list: list[str] | None = None,
    user_id: str | None = None,
    session_id: str | None = None,
    tenant_id: str | None = None,
    request_id: str | None = None,
    workflow_id: str | None = None,
    metadata: dict[str, Any] | None = None,
    tags: list[str] | None = None,
) -> AgentOpsClient:
    """Initialize or re-initialize the global client.

    Notes:
        ``api_key``, ``endpoint``, and ``app_url`` are accepted for compatibility
        but are currently not used by this SDK.
    """
    if api_key is not None or endpoint is not None or app_url is not None:
        logger.info(
            "init(): cloud params (api_key/endpoint/app_url) are accepted for "
            "compatibility and currently ignored in this SDK."
        )

    new_client = AgentOpsClient(
        service_name=service_name,
        enabled=enabled,
        config=config,
        auto_instrument=auto_instrument,
        instrument_providers=instrument_providers,
        instrument_frameworks=instrument_frameworks,
        instrument_framework_list=instrument_framework_list,
        user_id=user_id,
        session_id=session_id,
        tenant_id=tenant_id,
        request_id=request_id,
        workflow_id=workflow_id,
        metadata=metadata,
        tags=tags,
    )

    global _client
    old: AgentOpsClient | None = None
    with _client_lock:
        old = _client
        _client = new_client

    # Shutdown outside the lock to avoid deadlock, but guarded by try/except
    if old is not None:
        try:
            old.shutdown()
        except Exception:
            logger.debug("Failed to shut down previous client instance", exc_info=True)

    return new_client


@dataclass
class TraceContext:
    """Container for an explicitly started root span."""

    span: trace.Span
    token: object | None = None
    ended: bool = False

    def end(self, end_state: StatusCode | str = "success") -> None:
        end_trace(self, end_state=end_state)

    def __enter__(self) -> "TraceContext":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: object | None,
    ) -> bool:
        if exc is None:
            end_trace(self, end_state="success")
        else:
            end_trace(self, end_state="error")
        return False


def start_trace(
    trace_name: str = "session",
    tags: dict[str, Any] | list[str] | None = None,
) -> TraceContext:
    """Start a root trace span and attach it as current context."""
    span = trace.get_tracer("agent_ops_sdk").start_span(trace_name)
    span.set_attribute("agentops.observation_type", "span")
    if tags is not None:
        span.set_attribute("agentops.tags", json.dumps(tags))
    token = otel_context.attach(trace.set_span_in_context(span))
    return TraceContext(span=span, token=token)


def end_trace(
    trace_context: TraceContext | None = None,
    end_state: StatusCode | str = "success",
) -> None:
    """End a previously started trace span."""
    status = _status_from_end_state(end_state)

    # Compatibility behavior: end current span if no trace_context is provided.
    if trace_context is None:
        current = trace.get_current_span()
        if current is None or not current.is_recording():
            return
        if status is not StatusCode.UNSET:
            current.set_status(status)
        current.end()
        return

    if trace_context.ended:
        return

    if trace_context.token is not None:
        try:
            otel_context.detach(trace_context.token)
        except Exception:
            logger.debug("Failed to detach trace context token", exc_info=True)

    if trace_context.span.is_recording():
        if status is not StatusCode.UNSET:
            trace_context.span.set_status(status)
        trace_context.span.end()

    trace_context.ended = True
