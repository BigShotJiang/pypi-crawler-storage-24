"""Trace span validation tools.

Validates span structure integrity: orphan spans, time inversions,
missing required attributes, and more.

Usage::

    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
    from agent_ops_sdk import validate_trace_spans

    result = validate_trace_spans(exporter.get_finished_spans())
    assert result.valid
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence


@dataclass(frozen=True)
class ValidationIssue:
    """A single validation issue found in a span."""

    span_id: str
    span_name: str
    issue_type: str
    message: str


@dataclass(frozen=True)
class ValidationResult:
    """Result of ``validate_trace_spans()``."""

    valid: bool
    issues: tuple[ValidationIssue, ...]
    span_count: int
    trace_ids: frozenset[str]

    def __str__(self) -> str:
        if self.valid:
            return f"Valid ({self.span_count} spans, {len(self.trace_ids)} traces)"
        lines = [f"Invalid ({len(self.issues)} issues in {self.span_count} spans):"]
        for issue in self.issues:
            lines.append(f"  [{issue.issue_type}] {issue.span_name}: {issue.message}")
        return "\n".join(lines)


_REQUIRED_ATTRIBUTES = ("agentops.observation_type",)


def validate_trace_spans(spans: Sequence[Any]) -> ValidationResult:
    """Validate a list of OTel ReadableSpan objects.

    Checks performed:
        - **orphan_span**: Span references a parent that doesn't exist in the list.
        - **time_inversion**: Span start_time > end_time.
        - **missing_attribute**: Required attribute is absent.
        - **zero_duration_root**: Root span has zero duration (start == end).
        - **empty_name**: Span has an empty name.

    Args:
        spans: List of ``ReadableSpan`` objects (e.g. from InMemorySpanExporter).

    Returns:
        A ``ValidationResult`` with ``valid=True`` if no issues found.
    """
    issues: list[ValidationIssue] = []
    span_ids: set[int] = set()
    parent_map: dict[int, Any] = {}
    trace_ids: set[str] = set()

    # First pass: collect all span IDs
    for span in spans:
        ctx = span.context
        if ctx:
            span_ids.add(ctx.span_id)
            trace_ids.add(format(ctx.trace_id, "032x"))

    # Second pass: validate each span
    for span in spans:
        ctx = span.context
        sid = format(ctx.span_id, "016x") if ctx else "unknown"
        sname = span.name or ""

        # Empty name check
        if not sname:
            issues.append(ValidationIssue(
                span_id=sid,
                span_name="(empty)",
                issue_type="empty_name",
                message="Span has an empty name.",
            ))

        # Missing required attributes
        attrs = span.attributes or {}
        for attr_name in _REQUIRED_ATTRIBUTES:
            if attr_name not in attrs:
                issues.append(ValidationIssue(
                    span_id=sid,
                    span_name=sname,
                    issue_type="missing_attribute",
                    message=f"Missing required attribute: {attr_name}",
                ))

        # Time inversion check
        start = span.start_time or 0
        end = span.end_time or 0
        if start > end:
            issues.append(ValidationIssue(
                span_id=sid,
                span_name=sname,
                issue_type="time_inversion",
                message=f"start_time ({start}) > end_time ({end})",
            ))

        # Orphan span check
        parent_ctx = span.parent
        if parent_ctx is not None:
            parent_span_id = getattr(parent_ctx, "span_id", None)
            if parent_span_id and parent_span_id not in span_ids:
                issues.append(ValidationIssue(
                    span_id=sid,
                    span_name=sname,
                    issue_type="orphan_span",
                    message=f"Parent span {format(parent_span_id, '016x')} not found in trace.",
                ))

        # Zero duration root span check
        if parent_ctx is None and start == end and start != 0:
            issues.append(ValidationIssue(
                span_id=sid,
                span_name=sname,
                issue_type="zero_duration_root",
                message="Root span has zero duration (start_time == end_time).",
            ))

    return ValidationResult(
        valid=len(issues) == 0,
        issues=tuple(issues),
        span_count=len(spans),
        trace_ids=frozenset(trace_ids),
    )
