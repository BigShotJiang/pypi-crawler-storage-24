"""AgentOps SDK - Agent observability, tracing, and evaluation metrics.

Public API:
    AgentOpsClient      - Main entry point
    instrument          - Tracing decorator
    agent, tool, task, workflow, guardrail, generation, retriever
                        - Convenience decorators (shorthand for @instrument)
    trace_context       - Context propagation (user_id, session_id)
    update_current_observation - Manual model/token reporting
    set_observation_io  - Manual input/output/retrieved_docs setting
    get_current_trace_id - Get current OTel trace ID
    get_current_observation_id - Get current OTel span ID
    patch_all           - Auto-instrument LLM providers
    unpatch_all         - Restore original LLM provider methods
"""

from agent_ops_sdk.client import AgentOpsClient
from agent_ops_sdk.compat import end_trace, get_client, init, start_trace
from agent_ops_sdk.eval.auto_metrics import TraceStats
from agent_ops_sdk.eval.metrics import all_metrics, get_metric
from agent_ops_sdk.instrument.auto_instrument import (
    patch_all,
    unpatch_all,
)
from agent_ops_sdk.instrument.context import (
    get_current_observation_id,
    get_current_trace_id,
    set_observation_io,
    trace_context,
    update_current_observation,
)
from agent_ops_sdk.instrument.decorator import instrument
from agent_ops_sdk.instrument.shortcuts import (
    agent,
    generation,
    guardrail,
    retriever,
    task,
    tool,
    workflow,
)
from agent_ops_sdk.types import (
    AgentOpsConfig,
    ObservationType,
)

__all__ = [
    # Core
    "AgentOpsClient",
    "instrument",
    # Convenience decorators
    "agent",
    "tool",
    "task",
    "workflow",
    "guardrail",
    "generation",
    "retriever",
    # Context
    "trace_context",
    "update_current_observation",
    "set_observation_io",
    "get_current_trace_id",
    "get_current_observation_id",
    # Auto-instrumentation
    "patch_all",
    "unpatch_all",
    # Compat
    "init",
    "get_client",
    "start_trace",
    "end_trace",
    # Metrics
    "TraceStats",
    "all_metrics",
    "get_metric",
    # Types
    "AgentOpsConfig",
    "ObservationType",
]

__version__ = "0.7.0"
