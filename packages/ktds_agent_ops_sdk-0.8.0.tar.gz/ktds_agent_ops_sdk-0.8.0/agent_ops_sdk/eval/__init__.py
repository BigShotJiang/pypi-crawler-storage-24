"""Evaluation module - metrics registry, scorer, and auto-metrics."""
