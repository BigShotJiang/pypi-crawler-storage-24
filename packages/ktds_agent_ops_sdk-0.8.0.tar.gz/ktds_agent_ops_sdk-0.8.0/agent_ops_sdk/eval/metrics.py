"""Metric definitions registry.

All 70+ metrics from 평가지표관리.md and agent_365평가지표.md are registered here.
Each MetricDefinition is immutable and maps to a score_config row.
"""

from __future__ import annotations

from agent_ops_sdk.types import (
    CollectionMode,
    MetricCategory,
    MetricDefinition,
    ScoreDataType,
)

# ---------------------------------------------------------------------------
# Internal registry
# ---------------------------------------------------------------------------
_REGISTRY: dict[str, MetricDefinition] = {}


def _r(m: MetricDefinition) -> MetricDefinition:
    """Register a metric and return it."""
    _REGISTRY[m.name] = m
    return m


# ---------------------------------------------------------------------------
# 1. AI 품질 - Native (기본 성능 지표)
# ---------------------------------------------------------------------------
TCR = _r(MetricDefinition(
    name="tcr", display_name="Task Completion Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.NATIVE,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.95,
    description="주어진 작업을 성공적으로 완료한 비율",
))

ACCURACY = _r(MetricDefinition(
    name="accuracy", display_name="Accuracy",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.NATIVE,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.90,
    description="Agent의 답변과 Ground Truth의 일치 정도",
))

HALLUCINATION_RATE = _r(MetricDefinition(
    name="hallucination_rate", display_name="Hallucination Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.NATIVE,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.05,
    description="AI가 사실이 아닌 정보를 생성하는 빈도",
))

RESPONSE_QUALITY = _r(MetricDefinition(
    name="response_quality", display_name="Response Quality",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.NATIVE,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.5,
    description="완전성/관련성/명확성에 대한 종합 평가",
))

LATENCY_MS = _r(MetricDefinition(
    name="latency_ms", display_name="Latency (ms)",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.NATIVE,
    collection_mode=CollectionMode.AUTO,
    min_value=0.0, max_value=None, threshold=3000.0,
    description="요청부터 응답 생성까지 걸린 시간 (span duration 자동 캡처)",
))

TOKEN_COST = _r(MetricDefinition(
    name="token_cost", display_name="Token Cost",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.NATIVE,
    collection_mode=CollectionMode.AUTO,
    min_value=0.0, max_value=None,
    description="LLM API 사용에 따른 토큰 비용 추적 (자동 캡처)",
))

TOOL_EFFICIENCY = _r(MetricDefinition(
    name="tool_efficiency", display_name="Tool Efficiency",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.NATIVE,
    collection_mode=CollectionMode.SEMI_AUTO,
    min_value=0.0, max_value=1.0, threshold=0.90,
    description="외부 도구의 효율적 호출 성공률",
))

RETRY_RATE = _r(MetricDefinition(
    name="retry_rate", display_name="Retry Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.NATIVE,
    collection_mode=CollectionMode.SEMI_AUTO,
    min_value=0.0, max_value=1.0, threshold=0.10,
    description="실패 후 재시도 비율",
))

# ---------------------------------------------------------------------------
# 2. AI 품질 - Agentic (에이전트 행동 지표)
# ---------------------------------------------------------------------------
TOOL_SELECTION_ACCURACY = _r(MetricDefinition(
    name="tool_selection_accuracy", display_name="Tool Selection Accuracy",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.AGENTIC,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="에이전트가 작업에 적합한 도구를 선택하는 정확도",
))

AGENT_COORDINATION = _r(MetricDefinition(
    name="agent_coordination", display_name="Agent Coordination",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.AGENTIC,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="멀티에이전트 시스템의 에이전트 간 협업 효율성",
))

WORKFLOW_EXECUTION = _r(MetricDefinition(
    name="workflow_execution", display_name="Workflow Execution",
    data_type=ScoreDataType.CATEGORICAL, category=MetricCategory.AGENTIC,
    collection_mode=CollectionMode.SEMI_AUTO,
    description="체인 및 그래프 실행 성공률",
    categories=("success", "partial", "fail"),
))

# ---------------------------------------------------------------------------
# 3. AI 품질 - DeepEval (LLM as a Judge)
# ---------------------------------------------------------------------------
G_EVAL = _r(MetricDefinition(
    name="g_eval", display_name="G-Eval",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.DEEPEVAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.9,
    description="LLM을 평가자로 사용한 사용자 정의 기반 품질 평가",
))

HALLUCINATION_SCORE = _r(MetricDefinition(
    name="hallucination_score", display_name="Hallucination Score",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.DEEPEVAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.9,
    description="컨텍스트 충실도, 환각 없는 정도",
))

TOXICITY = _r(MetricDefinition(
    name="toxicity", display_name="Toxicity",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.DEEPEVAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="욕설/폭력/차별 등 부적절 콘텐츠 탐지",
))

BIAS = _r(MetricDefinition(
    name="bias", display_name="Bias",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.DEEPEVAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="성별/인종/종교 등 편향 탐지",
))

ANSWER_RELEVANCY = _r(MetricDefinition(
    name="answer_relevancy", display_name="Answer Relevancy",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.DEEPEVAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.9,
    description="질문과 답변의 의미적 관련성",
))

# ---------------------------------------------------------------------------
# 4. AI 품질 - RAGAS (RAG 품질 지표)
# ---------------------------------------------------------------------------
RAGAS_FAITHFULNESS = _r(MetricDefinition(
    name="ragas_faithfulness", display_name="RAGAS Faithfulness",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.RAGAS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.8,
    description="생성된 답변이 질문 내용에 대해 충실한지",
))

RAGAS_GROUNDEDNESS = _r(MetricDefinition(
    name="ragas_groundedness", display_name="RAGAS Groundedness",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.RAGAS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.9,
    description="근거에 기반한 답변을 하고 있는지",
))

RAGAS_CONTEXT_PRECISION = _r(MetricDefinition(
    name="ragas_context_precision", display_name="RAGAS Context Precision",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.RAGAS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.8,
    description="검색된 컨텍스트 중 실제로 관련 있는 정보의 비율",
))

RAGAS_CONTEXT_RECALL = _r(MetricDefinition(
    name="ragas_context_recall", display_name="RAGAS Context Recall",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.RAGAS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.8,
    description="정답 생성 필요 정보가 검색된 컨텍스트에 포함된 비율",
))

RAGAS_ANSWER_RELEVANCY = _r(MetricDefinition(
    name="ragas_answer_relevancy", display_name="RAGAS Answer Relevancy",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.RAGAS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.8,
    description="질문과 답변의 관련성 (RAGAS)",
))

RAGAS_POLICY_COMPLIANCE = _r(MetricDefinition(
    name="ragas_policy_compliance", display_name="RAGAS Policy Compliance",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.RAGAS,
    collection_mode=CollectionMode.MANUAL,
    description="민감 정보 포함 여부 Pass/Fail",
))

RAGAS_OVERALL = _r(MetricDefinition(
    name="ragas_overall", display_name="RAGAS Overall Score",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.RAGAS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="모든 RAGAS 메트릭의 종합 점수",
))

# ---------------------------------------------------------------------------
# 5. 사용자 - Effectiveness (효과성)
# ---------------------------------------------------------------------------
USER_TCR = _r(MetricDefinition(
    name="user_tcr", display_name="User Task Completion Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_EFFECTIVENESS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.90,
    description="유저 입장에서 작업을 성공적으로 완료한 비율",
))

ERROR_RATE = _r(MetricDefinition(
    name="error_rate", display_name="Error Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_EFFECTIVENESS,
    collection_mode=CollectionMode.SEMI_AUTO,
    min_value=0.0, max_value=1.0, threshold=0.10,
    description="잘못된 답변, 실패한 액션, 정책 차단 발생 비율",
))

PARTIAL_SUCCESS_RATE = _r(MetricDefinition(
    name="partial_success_rate", display_name="Partial Success Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_EFFECTIVENESS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="일부 목표 달성 (재시도/수정 필요)",
))

CRITICAL_FAILURE_RATE = _r(MetricDefinition(
    name="critical_failure_rate", display_name="Critical Failure Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_EFFECTIVENESS,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="잘못된 액션, 보안/정책 위반 (운영상 치명)",
))

# ---------------------------------------------------------------------------
# 6. 사용자 - Efficiency (효율성)
# ---------------------------------------------------------------------------
TURNS_TO_COMPLETION = _r(MetricDefinition(
    name="turns_to_completion", display_name="Turns to Completion",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_EFFICIENCY,
    collection_mode=CollectionMode.SEMI_AUTO,
    min_value=1.0, max_value=None,
    description="목표 달성까지 소요된 대화 턴 수",
))

FIRST_TURN_SUCCESS_RATE = _r(MetricDefinition(
    name="first_turn_success_rate", display_name="First-Turn Success Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_EFFICIENCY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="첫 응답에서 목적 달성 비율",
))

OVER_INTERACTION_RATE = _r(MetricDefinition(
    name="over_interaction_rate", display_name="Over-Interaction Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_EFFICIENCY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="기준 턴 수 초과 비율",
))

# ---------------------------------------------------------------------------
# 7. 사용자 - Satisfaction (만족도)
# ---------------------------------------------------------------------------
CSAT = _r(MetricDefinition(
    name="csat", display_name="CSAT",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_SATISFACTION,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0,
    description="사용자가 세션 후 직접 느낀 만족도",
))

NPS = _r(MetricDefinition(
    name="nps", display_name="NPS",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_SATISFACTION,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=10.0,
    description="에이전트를 추천할 의향 (0~10)",
))

REUSE_RATE = _r(MetricDefinition(
    name="reuse_rate", display_name="Reuse Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_SATISFACTION,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="일정 기간 내 동일 사용자가 다시 에이전트를 사용하는 비율",
))

SENTIMENT_SCORE = _r(MetricDefinition(
    name="sentiment_score", display_name="Sentiment Score",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_SATISFACTION,
    collection_mode=CollectionMode.MANUAL,
    min_value=-1.0, max_value=1.0,
    description="대화 감정 점수 (-1 부정 ~ +1 긍정)",
))

SENTIMENT_DELTA = _r(MetricDefinition(
    name="sentiment_delta", display_name="Sentiment Delta",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_SATISFACTION,
    collection_mode=CollectionMode.MANUAL,
    min_value=-2.0, max_value=2.0,
    description="대화 시작 대비 종료 시 감정 변화량",
))

EARLY_EXIT_RATE = _r(MetricDefinition(
    name="early_exit_rate", display_name="Early Exit Rate",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.USER_SATISFACTION,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0,
    description="목표 달성 전에 대화를 종료한 비율",
))

POSITIVE_COMPLETION_SIGNAL = _r(MetricDefinition(
    name="positive_completion_signal", display_name="Positive Completion Signal",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.USER_SATISFACTION,
    collection_mode=CollectionMode.MANUAL,
    description="사용자가 문제가 해결되었음을 명시적으로 표시",
))

# ---------------------------------------------------------------------------
# 8. Foundry - General Purpose
# ---------------------------------------------------------------------------
COHERENCE = _r(MetricDefinition(
    name="coherence", display_name="Coherence",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_GENERAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="응답의 논리적 일관성과 구조적 흐름",
))

FLUENCY = _r(MetricDefinition(
    name="fluency", display_name="Fluency",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_GENERAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="텍스트의 자연스러운 표현 품질",
))

RELEVANCE = _r(MetricDefinition(
    name="relevance", display_name="Relevance",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_GENERAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="응답이 사용자의 질문/의도와 관련되어 있는지",
))

GROUNDEDNESS_QA = _r(MetricDefinition(
    name="groundedness_qa", display_name="Groundedness (QA)",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_GENERAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="응답이 주어진 컨텍스트/근거에 기반하고 있는지",
))

SIMILARITY = _r(MetricDefinition(
    name="similarity", display_name="Similarity",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_GENERAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.8,
    description="모델 응답이 정답과 의미적으로 얼마나 유사한지",
))

F1_SCORE = _r(MetricDefinition(
    name="f1_score", display_name="F1 Score",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_GENERAL,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.7,
    description="정답 대비 Precision과 Recall의 균형",
))

# ---------------------------------------------------------------------------
# 9. Foundry - Text Similarity
# ---------------------------------------------------------------------------
SEMANTIC_SIMILARITY = _r(MetricDefinition(
    name="semantic_similarity", display_name="Semantic Similarity",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_TEXT_SIMILARITY,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="생성된 텍스트와 기대 응답의 의미적 유사성",
))

BLEU_SCORE = _r(MetricDefinition(
    name="bleu_score", display_name="BLEU Score",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_TEXT_SIMILARITY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.3,
    description="n-gram 기반 정밀도 측정",
))

GLEU_SCORE = _r(MetricDefinition(
    name="gleu_score", display_name="GLEU Score",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_TEXT_SIMILARITY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.3,
    description="Precision + Recall 균형을 고려한 n-gram 유사성",
))

ROUGE_SCORE = _r(MetricDefinition(
    name="rouge_score", display_name="ROUGE Score",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_TEXT_SIMILARITY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.4,
    description="n-gram 재현율 중심 평가",
))

METEOR_SCORE = _r(MetricDefinition(
    name="meteor_score", display_name="METEOR Score",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_TEXT_SIMILARITY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.4,
    description="동의어/형태소 단위 비교를 통한 유사성",
))

# ---------------------------------------------------------------------------
# 10. Foundry - RAG Evaluators
# ---------------------------------------------------------------------------
RETRIEVAL = _r(MetricDefinition(
    name="retrieval", display_name="Retrieval",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=3.0,
    description="검색된 문서들이 질의와 의미적으로 관련 있는지 자동 평가",
))

GPT_RETRIEVAL = _r(MetricDefinition(
    name="gpt_retrieval", display_name="GPT Retrieval",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=3.0,
    description="LLM(Judge)이 판단한 Query-Document 관련성",
))

RETRIEVAL_RESULT = _r(MetricDefinition(
    name="retrieval_result", display_name="Retrieval Result",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    description="retrieval 점수가 threshold를 통과했는지",
))

GROUNDEDNESS_RAG = _r(MetricDefinition(
    name="groundedness_rag", display_name="Groundedness (RAG)",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=3.0,
    description="응답이 검색된 컨텍스트에 얼마나 근거하고 있는지",
))

GPT_GROUNDEDNESS = _r(MetricDefinition(
    name="gpt_groundedness", display_name="GPT Groundedness",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=3.0,
    description="LLM(Judge)이 판단한 응답의 근거성",
))

GROUNDEDNESS_RESULT = _r(MetricDefinition(
    name="groundedness_result", display_name="Groundedness Result",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    description="groundedness threshold 통과 여부",
))

RELEVANCE_RESPONSE = _r(MetricDefinition(
    name="relevance_response", display_name="Relevance (Response)",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="최종 응답이 질의에 얼마나 적절히 답변했는지",
))

GPT_RELEVANCE = _r(MetricDefinition(
    name="gpt_relevance", display_name="GPT Relevance",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="LLM(Judge) 기반 응답 관련성",
))

RELEVANCE_RESULT = _r(MetricDefinition(
    name="relevance_result", display_name="Relevance Result",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    description="relevance threshold 통과 여부",
))

RESPONSE_COMPLETENESS = _r(MetricDefinition(
    name="response_completeness", display_name="Response Completeness",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="응답이 중요 정보를 빠짐없이 포함했는지",
))

RESPONSE_COMPLETENESS_RESULT = _r(MetricDefinition(
    name="response_completeness_result", display_name="Response Completeness Result",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    description="response_completeness threshold 통과 여부",
))

GROUNDEDNESS_PRO = _r(MetricDefinition(
    name="groundedness_pro", display_name="Groundedness Pro",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=3.5,
    description="응답이 컨텍스트 범위 내 정보만 사용했는지 엄격 평가",
))

GROUNDEDNESS_PRO_RESULT = _r(MetricDefinition(
    name="groundedness_pro_result", display_name="Groundedness Pro Result",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.FOUNDRY_RAG,
    collection_mode=CollectionMode.MANUAL,
    description="groundedness_pro threshold 통과 여부",
))

# ---------------------------------------------------------------------------
# 11. Foundry - Risk & Safety
# ---------------------------------------------------------------------------
HATE_UNFAIRNESS = _r(MetricDefinition(
    name="hate_unfairness", display_name="Hate & Unfairness",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RISK_SAFETY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="AI 응답에서 혐오 또는 불공정 표현의 존재 정도",
))

SEXUAL = _r(MetricDefinition(
    name="sexual", display_name="Sexual Content",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RISK_SAFETY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="성적 콘텐츠 위험 수준",
))

VIOLENCE = _r(MetricDefinition(
    name="violence", display_name="Violence",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RISK_SAFETY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="폭력 관련 언어/행위 위험 수준",
))

SELF_HARM = _r(MetricDefinition(
    name="self_harm", display_name="Self Harm",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RISK_SAFETY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="자해 관련 표현의 존재/위험도",
))

PROTECTED_MATERIAL = _r(MetricDefinition(
    name="protected_material", display_name="Protected Material",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RISK_SAFETY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="저작권 보호 텍스트 포함 여부",
))

INDIRECT_ATTACK = _r(MetricDefinition(
    name="indirect_attack", display_name="Indirect Attack",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RISK_SAFETY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="간접 탈옥 공격에 응답이 얼마나 취약한지",
))

CODE_VULNERABILITY = _r(MetricDefinition(
    name="code_vulnerability", display_name="Code Vulnerability",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RISK_SAFETY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="출력된 코드의 보안 취약성 위험 수준",
))

UNGROUNDED_ATTRIBUTES = _r(MetricDefinition(
    name="ungrounded_attributes", display_name="Ungrounded Attributes",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_RISK_SAFETY,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.1,
    description="개인 속성에 대한 근거 없는 추론",
))

# ---------------------------------------------------------------------------
# 12. Foundry - Agent Evaluators
# ---------------------------------------------------------------------------
INTENT_RESOLUTION = _r(MetricDefinition(
    name="intent_resolution", display_name="Intent Resolution",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_AGENT,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=3.0,
    description="에이전트가 사용자 의도를 정확히 식별했는지",
))

INTENT_RESOLUTION_RESULT = _r(MetricDefinition(
    name="intent_resolution_result", display_name="Intent Resolution Result",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.FOUNDRY_AGENT,
    collection_mode=CollectionMode.MANUAL,
    description="intent_resolution threshold 통과 여부",
))

TOOL_CALL_ACCURACY = _r(MetricDefinition(
    name="tool_call_accuracy", display_name="Tool Call Accuracy",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_AGENT,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=3.0,
    description="에이전트가 올바른 도구 호출을 수행했는지",
))

TOOL_CALL_ACCURACY_RESULT = _r(MetricDefinition(
    name="tool_call_accuracy_result", display_name="Tool Call Accuracy Result",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.FOUNDRY_AGENT,
    collection_mode=CollectionMode.MANUAL,
    description="tool_call_accuracy threshold 통과 여부",
))

CORRECT_TOOL_PERCENTAGE = _r(MetricDefinition(
    name="correct_tool_percentage", display_name="Correct Tool Percentage",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_AGENT,
    collection_mode=CollectionMode.MANUAL,
    min_value=0.0, max_value=1.0, threshold=0.9,
    description="올바른 도구 호출 비율",
))

TASK_ADHERENCE = _r(MetricDefinition(
    name="task_adherence", display_name="Task Adherence",
    data_type=ScoreDataType.NUMERIC, category=MetricCategory.FOUNDRY_AGENT,
    collection_mode=CollectionMode.MANUAL,
    min_value=1.0, max_value=5.0, threshold=4.0,
    description="에이전트가 지정된 작업/목표를 얼마나 충실히 수행했는지",
))

TASK_ADHERENCE_RESULT = _r(MetricDefinition(
    name="task_adherence_result", display_name="Task Adherence Result",
    data_type=ScoreDataType.BOOLEAN, category=MetricCategory.FOUNDRY_AGENT,
    collection_mode=CollectionMode.MANUAL,
    description="task_adherence threshold 통과 여부",
))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_metric(name: str) -> MetricDefinition | None:
    """Look up a metric by name. Returns None if not found."""
    return _REGISTRY.get(name)


def all_metrics() -> list[MetricDefinition]:
    """Return all registered metrics."""
    return list(_REGISTRY.values())


def metrics_by_category(category: MetricCategory) -> list[MetricDefinition]:
    """Return all metrics for a given category."""
    return [m for m in _REGISTRY.values() if m.category == category]


def metrics_by_collection_mode(mode: CollectionMode) -> list[MetricDefinition]:
    """Return all metrics for a given collection mode."""
    return [m for m in _REGISTRY.values() if m.collection_mode == mode]


def register_custom_metric(metric: MetricDefinition) -> None:
    """Register a custom metric. Raises ValueError on name collision."""
    if metric.name in _REGISTRY:
        raise ValueError(f"Metric '{metric.name}' is already registered")
    _REGISTRY[metric.name] = metric
