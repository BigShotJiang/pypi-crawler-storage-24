"""Score submission via OTel span events.

Scores are emitted as span events on the current trace,
which flow through OTel Collector to the configured backends.
All errors are caught and logged - never propagated to user code.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from opentelemetry import trace

from agent_ops_sdk.eval.metrics import get_metric
from agent_ops_sdk.types import ScoreDataType, ScoreInput

logger = logging.getLogger("agent_ops_sdk.eval.scorer")


class Scorer:
    """Submits scores as OTel span events."""

    def submit_score(self, score_input: ScoreInput) -> None:
        """Submit a score as an OTel span event. Non-breaking on any error."""
        try:
            span = trace.get_current_span()
            if span is None or not span.is_recording():
                logger.warning(
                    "Score '%s' dropped: no active span. "
                    "Call score() inside an @agent/@tool/@generation decorated function, "
                    "or use start_trace()/end_trace().",
                    score_input.name,
                )
                return

            metric = get_metric(score_input.name)
            data_type = metric.data_type.value if metric else "NUMERIC"

            value: float | None = None
            string_value: str | None = None

            if metric and metric.data_type == ScoreDataType.BOOLEAN:
                value = 1.0 if score_input.value else 0.0
            elif metric and metric.data_type == ScoreDataType.CATEGORICAL:
                string_value = str(score_input.value)
            else:
                try:
                    value = float(score_input.value) if score_input.value is not None else 0.0
                except (TypeError, ValueError):
                    string_value = str(score_input.value)
                    data_type = ScoreDataType.CATEGORICAL.value

            attributes: dict[str, Any] = {
                "score.name": score_input.name,
                "score.data_type": data_type,
                "score.trace_id": score_input.trace_id,
            }
            if value is not None:
                attributes["score.value"] = value
            if string_value is not None:
                attributes["score.string_value"] = string_value
            if score_input.observation_id:
                attributes["score.observation_id"] = score_input.observation_id
            if score_input.comment:
                attributes["score.comment"] = score_input.comment
            if score_input.metadata:
                attributes["score.metadata"] = json.dumps(score_input.metadata)

            span.add_event("agentops.score", attributes=attributes)
            logger.debug("Submitted score '%s' = %s", score_input.name, value or string_value)

        except Exception:
            logger.warning(
                "Failed to submit score '%s'",
                score_input.name,
                exc_info=True,
            )
