"""Semi-auto metric calculators.

These functions compute metrics from trace/observation data
that the SDK can gather automatically from instrumented code.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TraceStats:
    """Aggregated stats from a single trace for semi-auto metric calculation.

    Attributes:
        total_tool_calls: Total number of tool invocations in the trace.
        successful_tool_calls: Number of tool calls that completed without error.
        retried_tool_calls: Number of tool calls that were retried.
        total_spans: Total number of spans (turns) in the trace.
        error_spans: Number of spans that ended with an error.
        workflow_errors: Number of workflow-level errors.
    """

    total_tool_calls: int = 0
    successful_tool_calls: int = 0
    retried_tool_calls: int = 0
    total_spans: int = 0
    error_spans: int = 0
    workflow_errors: int = 0


def tool_efficiency(stats: TraceStats) -> float:
    """Calculate tool efficiency: successful calls / total calls.

    Returns 1.0 if no tool calls were made.
    """
    if stats.total_tool_calls == 0:
        return 1.0
    return stats.successful_tool_calls / stats.total_tool_calls


def retry_rate(stats: TraceStats) -> float:
    """Calculate retry rate: retried calls / total calls.

    Returns 0.0 if no tool calls were made.
    """
    if stats.total_tool_calls == 0:
        return 0.0
    return stats.retried_tool_calls / stats.total_tool_calls


def error_rate(stats: TraceStats) -> float:
    """Calculate error rate: error spans / total spans.

    Returns 0.0 if no spans exist.
    """
    if stats.total_spans == 0:
        return 0.0
    return stats.error_spans / stats.total_spans


def turns_to_completion(stats: TraceStats) -> int:
    """Return total number of turns (spans) in the trace."""
    return stats.total_spans


def workflow_execution(stats: TraceStats) -> str:
    """Determine workflow execution result.

    Returns:
        "success" if no errors, "partial" if some errors, "fail" if all errored.
    """
    if stats.total_spans == 0:
        return "fail"
    if stats.workflow_errors == 0 and stats.error_spans == 0:
        return "success"
    if stats.error_spans >= stats.total_spans:
        return "fail"
    return "partial"
