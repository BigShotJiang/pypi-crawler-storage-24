# AnalogAI Foundation

A comprehensive Python package for building AI agent systems with advanced capabilities including emotional intelligence, inference mechanisms, and multi-database support.

## Installation

Install the package in editable mode:

```bash
pip install -e .
```

Install with development dependencies:

```bash
pip install -e ".[dev]"
```

## Project Structure

```
Foundation/
├── src/
│   └── analogai/
│       └── foundation/
│           ├── common/         # Shared utilities, logging, DTOs, enums
│           ├── core/           # Core domain value objects and observables
│           ├── extensions/     # Auth, authorization, conversation, queries, etc.
│           ├── infrastructure/ # Repositories, storage adapters, services
│           ├── modules/        # Domain modules (beliefs, notions, inference)
│           ├── setup/          # Factories and wiring helpers
│           └── tests/          # Functional and unit tests
├── pyproject.toml       # Unified package configuration
├── setup.py             # Setup helper
├── MANIFEST.in          # Package manifest
└── README.md
```

## Modules

### Common (`src/analogai/foundation/common/`)
- **Design Patterns**: Chain of responsibility, singleton, state machine
- **Logging**: Application logging utilities
- **Utils**: Serialization, modifiers, lemmatization helpers

### Core (`src/analogai/foundation/core/`)
- **Value Objects**: Time, relation, modifiers, attributes
- **Observables**: Notion and statement observables

### Extensions (`src/analogai/foundation/extensions/`)
- **Authentication / Authorization**: Token & auth services
- **Conversation / Belief Query / Contradictions**: Extension services and adapters

### Infrastructure (`src/analogai/foundation/infrastructure/`)
- **Repositories**: In-memory, MongoDB, Neo4j
- **Storage Adapters**: Vector storage and query adapters
- **Gateways**: Database gateways and services

### Modules (`src/analogai/foundation/modules/`)
- **Belief / Notion / Agent / User**: Domain services and entities
- **Inference**: Categorical & conditional deduction, contradictions

## Requirements

- Python >= 3.12
- See `pyproject.toml` for complete dependency list

## Development

### Running Tests

The project uses Python's built-in `unittest` framework:

```bash
python -m unittest discover -s src -p "test_*.py"
```

### Code Quality

Format code with black:

```bash
black src/
```

Lint with ruff:

```bash
ruff check src/
```

Type check with mypy:

```bash
mypy src/
```

### Coverage

Run coverage report:

```bash
coverage run -m unittest discover -s src -p "test_*.py"
coverage report
coverage html
```

## License

MIT

