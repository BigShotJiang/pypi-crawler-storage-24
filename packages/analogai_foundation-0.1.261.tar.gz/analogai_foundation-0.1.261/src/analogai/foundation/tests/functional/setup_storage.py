from analogai.foundation.infrastructure.factories import StorageAdaptersFactoryImpl

def setup_storage():
    storage_adapters_factory = StorageAdaptersFactoryImpl()
    storage_adapter = storage_adapters_factory.get_storage_adapter()
    return storage_adapter
