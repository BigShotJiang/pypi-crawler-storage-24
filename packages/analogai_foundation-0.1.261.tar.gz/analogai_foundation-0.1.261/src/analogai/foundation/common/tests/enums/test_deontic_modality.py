import unittest
from analogai.foundation.common.enums.deontic_modality import DeonticModality

class TestDeonticModality(unittest.TestCase):
    
    def test_obligatory_enum_value(self):
        self.assertEqual(DeonticModality.OBLIGATORY.value, "obligatory")
    
    def test_permitted_enum_value(self):
        self.assertEqual(DeonticModality.PERMITTED.value, "permitted")
    
    def test_forbidden_enum_value(self):
        self.assertEqual(DeonticModality.FORBIDDEN.value, "forbidden")
    
    def test_create_from_value(self):
        modality = DeonticModality("obligatory")
        self.assertEqual(modality, DeonticModality.OBLIGATORY)
        
        modality = DeonticModality("permitted")
        self.assertEqual(modality, DeonticModality.PERMITTED)
        
        modality = DeonticModality("forbidden")
        self.assertEqual(modality, DeonticModality.FORBIDDEN)

if __name__ == '__main__':
    unittest.main()
