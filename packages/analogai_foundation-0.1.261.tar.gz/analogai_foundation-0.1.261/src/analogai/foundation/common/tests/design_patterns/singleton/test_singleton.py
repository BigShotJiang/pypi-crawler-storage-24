import unittest

from analogai.foundation.common.design_patterns.singleton import Singleton

class Example(metaclass=Singleton):
    def __init__(self):
        self.value = 0

class TestSingleton(unittest.TestCase):
    def test_single_instance(self):
        a = Example()
        b = Example()
        self.assertIs(a, b)

    def test_state_shared(self):
        a = Example()
        b = Example()
        a.value = 42
        self.assertEqual(b.value, 42)

if __name__ == '__main__':
    unittest.main()


