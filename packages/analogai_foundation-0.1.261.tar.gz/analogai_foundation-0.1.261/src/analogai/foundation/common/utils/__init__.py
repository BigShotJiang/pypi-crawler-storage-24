"""Common utility package.

Avoid side-effect imports here to prevent circular dependencies during config loading.
"""

__all__: list[str] = []
