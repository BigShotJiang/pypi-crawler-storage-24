from typing import Optional
from dataclasses import replace
from analogai.foundation.core.value_objects.modifier import Modifier
from analogai.foundation.core.value_objects.time import Time
from analogai.foundation.common.enums.deontic_modality import DeonticModality

class ModifierBuilder:
    
    def __init__(self):
        self._context = Modifier()
    
    def with_location(self, location: str):
        self._context.location = location
        return self
    
    def with_deontic_modality(self, modality: DeonticModality):
        self._context.deontic_modality = modality
        return self
    
    def with_from_time(self, year: Optional[int] = None, month: Optional[int] = None,
                      day: Optional[int] = None, hour: Optional[int] = None,
                      minute: Optional[int] = None):
        self._context.from_time = Time(year=year, month=month, day=day, hour=hour, minute=minute)
        return self
    
    def with_to_time(self, year: Optional[int] = None, month: Optional[int] = None,
                    day: Optional[int] = None, hour: Optional[int] = None,
                    minute: Optional[int] = None):
        self._context.to_time = Time(year=year, month=month, day=day, hour=hour, minute=minute)
        return self

    def with_attributes(self, attributes):
        self._context.attributes = attributes
        return self

    def with_quantity(self, quantity: Optional[float]):
        self._context.quantity = quantity
        return self

    def with_measures(self, measures):
        return self.with_attributes(measures)
    
    def build(self) -> Modifier:
        return replace(self._context)
