from __future__ import annotations


def normalize_relation_value(value: str) -> str:
    if not value:
        return value
    tokens = value.split()
    if not tokens:
        return value
    verb = tokens[0].lower()
    normalized = verb
    if verb in {"is", "are", "am", "was", "were"}:
        normalized = "be"
    elif verb in {"has", "had"}:
        normalized = "have"
    elif verb in {"does", "did"}:
        normalized = "do"
    if normalized == verb:
        return value
    return " ".join([normalized] + tokens[1:])
