from analogai.foundation.common.utils.time_utils.tense import Tense

__all__ = ['Tense']
