from typing import Dict
from analogai.foundation.common.utils.statement_serializers.helpers.verbalization import Verbalization


def _build_relation_to_verbalization() -> Dict[str, Verbalization]:
    result = {}
    for v in Verbalization:
        singular_positive = v.value[0]["positive"]
        result[singular_positive] = v
        plural_positive = v.value[1]["positive"]
        if plural_positive != singular_positive:
            result[plural_positive] = v
    result["be"] = Verbalization.IS_A
    return result


RELATION_TO_VERBALIZATION: Dict[str, Verbalization] = _build_relation_to_verbalization()


__all__ = ["RELATION_TO_VERBALIZATION"]
