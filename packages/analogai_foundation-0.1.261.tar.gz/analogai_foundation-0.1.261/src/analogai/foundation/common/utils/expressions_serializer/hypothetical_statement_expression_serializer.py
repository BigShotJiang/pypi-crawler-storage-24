from typing import Optional

from analogai.foundation.common.dtos.hypothetical_statement_expression import HypotheticalStatementExpression
from analogai.foundation.common.utils.statement_serializers import serialize_condition
from analogai.foundation.common.utils.statement_serializers.helpers import normalize_timezone


def serialize_hypothetical_statement_expression(
    expression: HypotheticalStatementExpression,
    timezone: Optional[str] = None,
) -> str:
    timezone = normalize_timezone(timezone)
    causes = [serialize_condition(c, timezone) for c in expression.causes if c]
    causes = [c for c in causes if c]
    effect = serialize_condition(expression.effect or {}, timezone)
    if not causes and not effect:
        return ""
    causes_part = " and ".join(causes) if causes else "something"
    effect_part = effect or "something"
    return f"If {causes_part}, then {effect_part}."
