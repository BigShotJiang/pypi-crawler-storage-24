from dataclasses import dataclass
from typing import Dict, Any, List

from analogai.foundation.common.enums.criterion import Criterion


@dataclass
class HypotheticalStatementExpression:
    causes: List[Dict[Criterion, Any]]
    effect: Dict[Criterion, Any]
    validity: float

    def __str__(self) -> str:
        from analogai.foundation.common.utils.expressions_serializer import (
            serialize_hypothetical_statement_expression,
        )
        return serialize_hypothetical_statement_expression(self)

    def __repr__(self) -> str:
        return (
            "HypotheticalStatementExpression("
            f"causes={self.causes!r}, effect={self.effect!r}, "
            f"validity={self.validity!r})"
        )
