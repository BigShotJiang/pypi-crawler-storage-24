from dataclasses import dataclass, field
from typing import List, Optional

from analogai.foundation.core.value_objects.attribute import Attribute



@dataclass
class NotionExpression:
    caption: str
    children: List["NotionExpression"] = field(default_factory=list)
    context: Optional[List["NotionExpression"]] = field(default_factory=list)
    attributes: Optional[List[Attribute]] = None

    def __str__(self) -> str:
        return self.caption

    def __repr__(self) -> str:
        return (
            "NotionExpression(caption={!r}, children={!r}, context={!r}, attributes={!r})"
        ).format(self.caption, self.children, self.context, self.attributes)

    def add_child(self, child):
        self.children.append(child)

if __name__ == "__main__":
    notion_expression = NotionExpression("test")
    print(notion_expression)

