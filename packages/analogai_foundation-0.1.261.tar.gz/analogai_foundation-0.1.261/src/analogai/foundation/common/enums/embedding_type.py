from enum import Enum


class EmbeddingType(str, Enum):
	LOCAL = "local"
	API = "api"