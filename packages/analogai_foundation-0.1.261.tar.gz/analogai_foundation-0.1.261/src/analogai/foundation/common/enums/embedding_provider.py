from enum import Enum


class EmbeddingProvider(str, Enum):
    LOCAL = "local"
    OPENAI = "openai"
    AZURE = "azure"
    AZURE_OPENAI = "azure_openai"
    AZURE_FOUNDRY = "azure_foundry"
