from enum import Enum

class AgentOpenness(Enum):
    CLOSED = "closed"
    OPEN = "open"
