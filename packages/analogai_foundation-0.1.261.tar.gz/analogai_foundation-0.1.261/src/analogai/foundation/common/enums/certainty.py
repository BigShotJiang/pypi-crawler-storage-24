from enum import Enum


class Certainty(Enum):
    CERTAIN = "certain"
    UNCERTAIN = "uncertain"
    NEGATED = "negated"

    def to_probability(self) -> float:
        if self is Certainty.CERTAIN:
            return 1.0
        if self is Certainty.UNCERTAIN:
            return 0.5
        return 0.0


def certainty_from_value(value: "Certainty | str | None") -> "Certainty":
    if value is None:
        return Certainty.CERTAIN
    if isinstance(value, Certainty):
        return value
    try:
        return Certainty(str(value))
    except ValueError:
        return Certainty.CERTAIN
