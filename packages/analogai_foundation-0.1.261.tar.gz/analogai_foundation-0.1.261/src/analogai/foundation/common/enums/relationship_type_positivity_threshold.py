from enum import Enum


class RelationshipTypePositivityThreshold(Enum):
    NEGATIVE = 0.3
    UNCERTAIN = 0.7
