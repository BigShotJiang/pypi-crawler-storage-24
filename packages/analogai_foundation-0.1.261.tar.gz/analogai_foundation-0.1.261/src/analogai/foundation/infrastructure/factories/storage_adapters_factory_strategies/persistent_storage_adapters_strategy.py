from analogai.foundation.infrastructure.storage.storage_adapters_factory import StorageAdaptersFactory
from analogai.foundation.infrastructure.storage.mongodb.mongodb_storage_adapter_impl import MongoDBStorageAdapterImpl
from analogai.foundation.infrastructure.storage.mongodb.mongodb_query_storage_adapter_impl import MongoDBQueryStorageAdapterImpl

class PersistentStorageAdaptersStrategy(StorageAdaptersFactory):
    def get_storage_adapter(self):
        return MongoDBStorageAdapterImpl()

    def get_query_storage_adapter(self):
        return MongoDBQueryStorageAdapterImpl()

