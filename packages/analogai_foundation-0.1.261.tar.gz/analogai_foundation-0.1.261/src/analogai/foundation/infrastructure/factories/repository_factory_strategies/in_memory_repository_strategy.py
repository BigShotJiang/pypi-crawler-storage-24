from analogai.foundation.modules.notion.notion_repository import NotionRepository
from analogai.foundation.modules.belief.belief_repository import BeliefRepository
from analogai.foundation.modules.user.user_repository import UserRepository
from analogai.foundation.modules.agent.agent_repository import AgentRepository
from analogai.foundation.modules.direct_statement.direct_statement_repository import StatementRepository
from analogai.foundation.modules.conditionals.hypothetical_statement_repository import HypotheticalStatementRepository
from analogai.foundation.infrastructure.repositories.in_memory.in_memory_user_repository_impl import InMemoryUserRepositoryImpl
from analogai.foundation.infrastructure.repositories.in_memory.in_memory_belief_repository_impl import InMemoryBeliefRepositoryImpl
from analogai.foundation.infrastructure.repositories.in_memory.in_memory_notion_repository_impl import InMemoryNotionRepositoryImpl
from analogai.foundation.infrastructure.repositories.in_memory.in_memory_agent_repository_impl import InMemoryAgentRepositoryImpl
from analogai.foundation.infrastructure.repositories.in_memory.in_memory_statement_repository_impl import InMemoryStatementRepositoryImpl
from analogai.foundation.infrastructure.repositories.in_memory.in_memory_hypothetical_statement_repository_impl import InMemoryHypotheticalStatementRepositoryImpl


class InMemoryRepositoryStrategy:
    def __init__(self):
        self._notion_repository = None
        self._belief_repository = None
        self._user_repository = None
        self._agent_repository = None
        self._statement_repository = None
        self._hypothetical_statement_repository = None
        self._belief_repo_initialized = False

    def get_notion_repository(self) -> NotionRepository:
        if not self._notion_repository:
            self._notion_repository = InMemoryNotionRepositoryImpl()
        return self._notion_repository

    def get_belief_repository(self) -> BeliefRepository:
        if not self._belief_repository:
            if not self._belief_repo_initialized:
                self._belief_repository = InMemoryBeliefRepositoryImpl()
        return self._belief_repository

    def get_user_repository(self) -> UserRepository:
        if not self._user_repository:
            self._user_repository = InMemoryUserRepositoryImpl()
        return self._user_repository

    def get_agent_repository(self) -> AgentRepository:
        if not self._agent_repository:
            self._agent_repository = InMemoryAgentRepositoryImpl()
        return self._agent_repository

    def get_statement_repository(self) -> StatementRepository:
        if not self._statement_repository:
            self._statement_repository = InMemoryStatementRepositoryImpl()
        return self._statement_repository

    def get_hypothetical_statement_repository(self) -> HypotheticalStatementRepository:
        if not self._hypothetical_statement_repository:
            self._hypothetical_statement_repository = InMemoryHypotheticalStatementRepositoryImpl()
        return self._hypothetical_statement_repository

