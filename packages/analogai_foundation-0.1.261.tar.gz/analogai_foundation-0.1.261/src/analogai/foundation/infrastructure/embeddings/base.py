from __future__ import annotations

from typing import List, Protocol


class EmbeddingProvider(Protocol):
    @property
    def dimension(self) -> int | None:
        ...

    def encode(self, text: str) -> List[float]:
        ...

    def encode_batch(self, texts: List[str]) -> List[List[float]]:
        ...
