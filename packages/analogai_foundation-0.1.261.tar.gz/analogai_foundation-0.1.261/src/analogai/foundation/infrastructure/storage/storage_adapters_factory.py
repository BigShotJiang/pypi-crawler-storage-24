from abc import ABC, abstractmethod
from analogai.foundation.infrastructure.storage.storage_adapter import StorageAdapter
from analogai.foundation.infrastructure.storage.query_storage_adapter import QueryStorageAdapter

class StorageAdaptersFactory(ABC):
    @abstractmethod
    def get_storage_adapter(self) -> StorageAdapter:
        pass

    # @abstractmethod
    # def get_query_storage_adapter(self) -> QueryStorageAdapter:
    #     pass

