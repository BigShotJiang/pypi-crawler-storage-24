from .in_memory_storage_adapter_impl import InMemoryStorageAdapterImpl

__all__ = ['InMemoryStorageAdapterImpl']
