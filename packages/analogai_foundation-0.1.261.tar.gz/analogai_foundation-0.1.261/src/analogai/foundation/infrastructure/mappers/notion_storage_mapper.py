from typing import Dict, List, Any
from analogai.foundation.modules.notion.notion import Notion
from analogai.foundation.core.value_objects.attribute import Attribute


class NotionStorageMapper:
    @staticmethod
    def to_dict(notion: Notion) -> Dict[str, Any]:
        result = {
            "id": notion.id,
            "user_id": notion.user_id,
            "agent_id": notion.agent_id,
            "caption": notion.caption
        }
        if notion.attributes is not None:
            result["attributes"] = [
                {"tag": attribute.tag, "value": attribute.value, "unit": attribute.unit}
                for attribute in notion.attributes
            ]
        return result

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> Notion:
        attributes_payload = data.get("attributes")
        attributes = None
        if attributes_payload is not None:
            attributes = [
                Attribute(tag=m.get("tag") or m.get("kind"), value=m.get("value"), unit=m.get("unit"))
                for m in attributes_payload or []
            ]
        return Notion(
            id=data.get("id"),
            user_id=data.get("user_id", ""),
            agent_id=data.get("agent_id", ""),
            caption=data.get("caption", ""),
            attributes=attributes,
        )

