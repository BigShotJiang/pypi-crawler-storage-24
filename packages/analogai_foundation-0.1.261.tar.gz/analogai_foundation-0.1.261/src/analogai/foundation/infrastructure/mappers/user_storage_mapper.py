from typing import Dict
from analogai.foundation.modules.user.user import User


class UserStorageMapper:
    @staticmethod
    def to_dict(user: User) -> Dict:
        result = {
            "id": user.id,
            "name": user.name or "",
            "email": user.email or ""
        }
        if user.timezone is not None:
            result["timezone"] = user.timezone
        if user.nationality is not None:
            result["nationality"] = user.nationality
        if user.location is not None:
            result["location"] = user.location
        return result

    @staticmethod
    def from_dict(data: Dict) -> User:
        user = User(
            id=data.get("id"),
            name=data.get("name", ""),
            email=data.get("email", ""),
            timezone=data.get("timezone"),
            nationality=data.get("nationality"),
            location=data.get("location")
        )
        return user

