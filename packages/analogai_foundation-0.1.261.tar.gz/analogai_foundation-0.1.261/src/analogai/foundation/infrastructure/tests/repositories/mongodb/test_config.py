import unittest

from analogai.foundation.settings import config
from analogai.foundation.common.enums.environment import Environment

class MongoDBEnvironmentCheckMixin:
    def setUp(self):
        super().setUp()
        env_value = config.get("ENVIRONMENT")
        env = Environment(env_value)
        if env in {Environment.DEVELOPMENT, Environment.TESTING}:
            self.skipTest(
                "CRITICAL: MongoDB tests cannot be run in development environment! "
                "Set ENVIRONMENT=staging or ENVIRONMENT=production to run MongoDB tests."
            )

