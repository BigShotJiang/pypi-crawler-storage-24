import unittest
from analogai.foundation.infrastructure.mappers.time_storage_mapper import TimeStorageMapper
from analogai.foundation.core.value_objects.time import Time


class TestTimeStorageMapper(unittest.TestCase):

    def test_absolute_time_to_dict(self):
        time = Time(year=2024, month=12, day=25, hour=14, minute=30)
        result = TimeStorageMapper.to_dict(time)

        self.assertIsNotNone(result)
        self.assertEqual(result["year"], 2024)
        self.assertEqual(result["month"], 12)
        self.assertEqual(result["day"], 25)
        self.assertEqual(result["hour"], 14)
        self.assertEqual(result["minute"], 30)

    def test_absolute_time_from_dict(self):
        data = {
            "year": 2024,
            "month": 12,
            "day": 25,
            "hour": 14,
            "minute": 30
        }
        result = TimeStorageMapper.from_dict(data)

        self.assertIsNotNone(result)
        self.assertIsInstance(result, Time)
        self.assertEqual(result.year, 2024)
        self.assertEqual(result.month, 12)
        self.assertEqual(result.day, 25)
        self.assertEqual(result.hour, 14)
        self.assertEqual(result.minute, 30)

    def test_flatten_absolute_time(self):
        time = Time(year=2024, month=12, day=25)
        result = TimeStorageMapper.flatten_to_dict(time, "from_time")

        self.assertEqual(result["from_time_year"], 2024)
        self.assertEqual(result["from_time_month"], 12)
        self.assertEqual(result["from_time_day"], 25)

    def test_unflatten_absolute_time(self):
        data = {
            "from_time_year": 2024,
            "from_time_month": 12,
            "from_time_day": 25
        }
        result = TimeStorageMapper.unflatten_from_dict(data, "from_time")

        self.assertIsNotNone(result)
        self.assertIsInstance(result, Time)
        self.assertEqual(result.year, 2024)
        self.assertEqual(result.month, 12)
        self.assertEqual(result.day, 25)

    def test_none_time_to_dict(self):
        result = TimeStorageMapper.to_dict(None)
        self.assertIsNone(result)

    def test_none_time_from_dict(self):
        result = TimeStorageMapper.from_dict(None)
        self.assertIsNone(result)

    def test_round_trip_absolute_time(self):
        original = Time(year=2024, month=12, day=25, hour=14, minute=30)
        data = TimeStorageMapper.to_dict(original)
        restored = TimeStorageMapper.from_dict(data)

        self.assertEqual(restored.year, original.year)
        self.assertEqual(restored.month, original.month)
        self.assertEqual(restored.day, original.day)
        self.assertEqual(restored.hour, original.hour)
        self.assertEqual(restored.minute, original.minute)

    def test_flatten_to_dict_absolute_only_absolute_time(self):
        time = Time(year=2025, month=2, day=1, hour=10, minute=5)
        result = TimeStorageMapper.flatten_to_dict_absolute_only(time, "from_time")
        self.assertEqual(result.get("from_time_year"), 2025)
        self.assertEqual(result.get("from_time_month"), 2)
        self.assertEqual(result.get("from_time_day"), 1)
        self.assertEqual(result.get("from_time_hour"), 10)
        self.assertEqual(result.get("from_time_minute"), 5)
        self.assertNotIn("from_time_id", result)

    def test_flatten_to_dict_absolute_only_none(self):
        result = TimeStorageMapper.flatten_to_dict_absolute_only(None, "from_time")
        self.assertEqual(result, {})


if __name__ == '__main__':
    unittest.main()
