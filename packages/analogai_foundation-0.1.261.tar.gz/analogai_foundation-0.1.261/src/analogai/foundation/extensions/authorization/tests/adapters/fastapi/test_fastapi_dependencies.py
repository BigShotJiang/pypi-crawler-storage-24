import unittest
from unittest.mock import Mock, patch
from analogai.foundation.extensions.authorization.adapters.fastapi import build_authorization_dependency
from analogai.foundation.extensions.authorization.core.enums.operation import AuthorizationOperation

class TestFastAPIDependencies(unittest.TestCase):
    def setUp(self):
        self.domain_factory = Mock()

    @patch("analogai.foundation.extensions.authorization.adapters.fastapi.dependencies.AuthorizationFactory")
    def test_build_authorization_dependency_uses_factory(self, factory_cls):
        mock_factory = factory_cls.return_value
        dependency = Mock()
        mock_factory.create_authorization_dependency.return_value = dependency

        result = build_authorization_dependency(AuthorizationOperation.EDIT)

        factory_cls.assert_called_once_with()
        mock_factory.create_authorization_dependency.assert_called_once_with(
            AuthorizationOperation.EDIT
        )
        self.assertIs(result, dependency)

if __name__ == "__main__":
    unittest.main()

