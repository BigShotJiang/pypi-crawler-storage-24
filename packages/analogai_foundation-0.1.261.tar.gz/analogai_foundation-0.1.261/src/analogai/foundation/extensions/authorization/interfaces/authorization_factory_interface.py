from abc import ABC, abstractmethod
from typing import Awaitable, Callable
from fastapi import Request
from analogai.foundation.extensions.authorization.models import AuthorizationContext
from analogai.foundation.extensions.authorization.core.enums.operation import AuthorizationOperation

AuthorizationDependency = Callable[..., Awaitable[AuthorizationContext]]

class AuthorizationFactoryInterface(ABC):
    @abstractmethod
    def create_authorization_dependency(
        self,
        operation: AuthorizationOperation = AuthorizationOperation.CHAT,
    ) -> AuthorizationDependency:
        pass

    @abstractmethod
    def create_api_authorization_dependency(
        self,
        operation: AuthorizationOperation = AuthorizationOperation.CHAT,
    ) -> AuthorizationDependency:
        pass

