from dataclasses import dataclass
from typing import TYPE_CHECKING
from analogai.foundation.modules.agent.agent import Agent
from analogai.foundation.modules.user.user import User

if TYPE_CHECKING:
    from analogai.foundation.extensions.authorization.core.enums.operation import AuthorizationOperation

@dataclass(frozen=True)
class AuthorizationContext:
    user: User
    agent: Agent
    authority: float
    operation: "AuthorizationOperation"

