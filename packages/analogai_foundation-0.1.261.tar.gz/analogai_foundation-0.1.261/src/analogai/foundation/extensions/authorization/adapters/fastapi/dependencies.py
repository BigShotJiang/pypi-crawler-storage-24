from analogai.foundation.extensions.authorization.authorization_factory import AuthorizationFactory
from analogai.foundation.extensions.authorization.core.enums.operation import AuthorizationOperation
from analogai.foundation.extensions.authorization.interfaces.authorization_factory_interface import (
    AuthorizationDependency,
)

def build_authorization_dependency(
    operation: AuthorizationOperation = AuthorizationOperation.CHAT,
) -> AuthorizationDependency:
    factory = AuthorizationFactory()
    return factory.create_authorization_dependency(operation)

def build_api_authorization_dependency(
    operation: AuthorizationOperation = AuthorizationOperation.CHAT,
) -> AuthorizationDependency:
    factory = AuthorizationFactory()
    return factory.create_api_authorization_dependency(operation)

