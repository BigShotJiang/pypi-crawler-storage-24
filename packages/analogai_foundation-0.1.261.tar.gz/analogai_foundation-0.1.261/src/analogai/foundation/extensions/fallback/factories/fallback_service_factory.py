from analogai.foundation.extensions.fallback.services.fallback_service import FallbackService
from analogai.foundation.extensions.fallback.repositories import InMemoryFallbackRepositoryImpl, MongoDBFallbackRepositoryImpl
from analogai.foundation.common.enums.environment import Environment
from analogai.foundation.settings import config

class FallbackServiceFactory:
    def create(self) -> FallbackService:
        env = Environment(config.get("ENVIRONMENT"))
        if env == Environment.PRODUCTION:
            repository = MongoDBFallbackRepositoryImpl()
        else:
            repository = InMemoryFallbackRepositoryImpl()
        return FallbackService(repository)
