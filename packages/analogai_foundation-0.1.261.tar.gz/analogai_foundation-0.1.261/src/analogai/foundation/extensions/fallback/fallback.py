from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime
import uuid

@dataclass
class Fallback:
    user_id: str
    agent_id: str
    user_question: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid.uuid4())
        if not self.user_id or not isinstance(self.user_id, str):
            raise ValueError("user_id must be a non-empty string")
        if not self.agent_id or not isinstance(self.agent_id, str):
            raise ValueError("agent_id must be a non-empty string")
        if not self.user_question or not isinstance(self.user_question, str):
            raise ValueError("user_question must be a non-empty string")
        if not self.timestamp:
            self.timestamp = datetime.utcnow()
