from .fallback_storage_mapper import FallbackStorageMapper

__all__ = ["FallbackStorageMapper"]
