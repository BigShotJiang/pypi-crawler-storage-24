from typing import TYPE_CHECKING

__all__ = [
    "IJWTService",
    "AuthenticationFactoryInterface",
    "TokenPayload",
    "AuthenticationFactory",
    "Auth0JWTService",
    "build_authentication_dependency",
    "build_token_extraction_dependency",
    "build_api_token_authentication_dependency",
]

if TYPE_CHECKING:
    from .core import IJWTService
    from .interfaces import AuthenticationFactoryInterface
    from .models import TokenPayload
    from .authentication_factory import AuthenticationFactory
    from .providers import Auth0JWTService
    from .adapters.fastapi import (
        build_authentication_dependency,
        build_token_extraction_dependency,
        build_api_token_authentication_dependency,
    )

def __getattr__(name: str):
    if name == "IJWTService":
        from .core import IJWTService
        return IJWTService
    if name == "AuthenticationFactoryInterface":
        from .interfaces import AuthenticationFactoryInterface
        return AuthenticationFactoryInterface
    if name == "TokenPayload":
        from .models import TokenPayload
        return TokenPayload
    if name == "AuthenticationFactory":
        from .authentication_factory import AuthenticationFactory
        return AuthenticationFactory
    if name == "Auth0JWTService":
        from .providers import Auth0JWTService
        return Auth0JWTService
    if name == "build_authentication_dependency":
        from .adapters.fastapi import build_authentication_dependency
        return build_authentication_dependency
    if name == "build_token_extraction_dependency":
        from .adapters.fastapi import build_token_extraction_dependency
        return build_token_extraction_dependency
    if name == "build_api_token_authentication_dependency":
        from .adapters.fastapi import build_api_token_authentication_dependency
        return build_api_token_authentication_dependency
    raise AttributeError(name)
