from analogai.foundation.extensions.authentication.authentication_factory import AuthenticationFactory
from analogai.foundation.extensions.authentication.interfaces.authentication_factory_interface import (
    AuthenticationDependency,
    TokenExtractionDependency,
    ApiTokenAuthenticationDependency,
)

def build_authentication_dependency() -> AuthenticationDependency:
    factory = AuthenticationFactory()
    return factory.create_authentication_dependency()

def build_token_extraction_dependency() -> TokenExtractionDependency:
    factory = AuthenticationFactory()
    return factory.create_token_extraction_dependency()

def build_api_token_authentication_dependency() -> ApiTokenAuthenticationDependency:
    factory = AuthenticationFactory()
    return factory.create_api_token_authentication_dependency()

