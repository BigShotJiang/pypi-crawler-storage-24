from abc import ABC, abstractmethod
from typing import Any, Awaitable, Callable
from analogai.foundation.modules.user.user import User
from analogai.foundation.extensions.authentication.models import TokenPayload

AuthenticationDependency = Callable[[Any], Awaitable[User]]
TokenExtractionDependency = Callable[[Any], Awaitable[TokenPayload]]
ApiTokenAuthenticationDependency = Callable[[Any], Awaitable[User]]

class AuthenticationFactoryInterface(ABC):
    @abstractmethod
    def create_authentication_dependency(self) -> AuthenticationDependency:
        pass

    @abstractmethod
    def create_token_extraction_dependency(self) -> TokenExtractionDependency:
        pass

    @abstractmethod
    def create_api_token_authentication_dependency(self) -> ApiTokenAuthenticationDependency:
        pass

