import unittest
from unittest.mock import Mock, patch
from analogai.foundation.extensions.authentication.adapters.fastapi import (
    build_authentication_dependency,
    build_token_extraction_dependency,
)

class TestFastAPIDependencies(unittest.TestCase):
    def setUp(self):
        self.domain_factory = Mock()

    @patch("analogai.foundation.extensions.authentication.adapters.fastapi.dependencies.AuthenticationFactory")
    def test_build_authentication_dependency_uses_factory(self, factory_cls):
        mock_factory = factory_cls.return_value
        dependency = Mock()
        mock_factory.create_authentication_dependency.return_value = dependency

        result = build_authentication_dependency()

        factory_cls.assert_called_once_with()
        mock_factory.create_authentication_dependency.assert_called_once_with()
        self.assertIs(result, dependency)

    @patch("analogai.foundation.extensions.authentication.adapters.fastapi.dependencies.AuthenticationFactory")
    def test_build_token_extraction_dependency_uses_factory(self, factory_cls):
        mock_factory = factory_cls.return_value
        dependency = Mock()
        mock_factory.create_token_extraction_dependency.return_value = dependency

        result = build_token_extraction_dependency()

        factory_cls.assert_called_once_with()
        mock_factory.create_token_extraction_dependency.assert_called_once_with()
        self.assertIs(result, dependency)

if __name__ == "__main__":
    unittest.main()

