from analogai.foundation.settings import config
from analogai.foundation.extensions.contradictions.probability_variance_calculator import calculate_probability_variance


def is_belief_contradictory(belief) -> bool:
    probabilities = [(statement.validity, statement.probability) for statement in belief.statements]
    if not probabilities:
        raise ValueError("Cannot check contradiction for belief without statements")
    variance = calculate_probability_variance(probabilities)
    return variance > config.get("belief.variance", 0.1)
