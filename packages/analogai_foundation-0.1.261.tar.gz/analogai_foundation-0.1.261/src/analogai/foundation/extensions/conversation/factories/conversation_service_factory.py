from analogai.foundation.extensions.conversation.services.conversation_service import ConversationService
from analogai.foundation.extensions.conversation.repositories import InMemoryConversationRepositoryImpl, MongoDBConversationRepositoryImpl
from analogai.foundation.common.enums.environment import Environment
from analogai.foundation.settings import config

class ConversationServiceFactory:
    def create(self) -> ConversationService:
        env = Environment(config.get("ENVIRONMENT"))
        if env == Environment.PRODUCTION:
            repository = MongoDBConversationRepositoryImpl()
        elif env in {Environment.DEVELOPMENT, Environment.TESTING}:
            repository = InMemoryConversationRepositoryImpl()
        else:
            raise ValueError(f"No repository implementation for environment: {env}")
        return ConversationService(repository)
