from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime
from analogai.foundation.modules.user.user import User
from analogai.foundation.modules.agent.agent import Agent
from .turn import Turn

@dataclass
class Conversation:
    id: str
    user: User
    agent: Agent
    created_at: datetime
    updated_at: datetime
    turns: List[Turn] = field(default_factory=list)

    def add_turn(self, turn: Turn):
        self.turns.append(turn)
        self.updated_at = datetime.now()

    def get_recent_turns(self, limit: int = 10) -> List[Turn]:
        return self.turns[-limit:] if len(self.turns) > limit else self.turns

    def get_latest_turn(self) -> Optional[Turn]:
        return self.turns[-1] if self.turns else None

    def get_turn_count(self) -> int:
        return len(self.turns)
