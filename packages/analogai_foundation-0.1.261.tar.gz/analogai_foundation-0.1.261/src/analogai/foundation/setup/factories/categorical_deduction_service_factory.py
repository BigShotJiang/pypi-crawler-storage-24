from analogai.foundation.modules.categorical_deduction.categorical_deduction_service import CategoricalDeductionService
from .belief_service_factory import BeliefServiceFactory


class CategoricalDeductionServiceFactory:
    def __init__(
        self,
        belief_service=None,
        environment: str | None = None,
    ):
        self.belief_service = belief_service or BeliefServiceFactory(environment=environment).get_service()
        self.service = CategoricalDeductionService(
            belief_service=self.belief_service,
        )

    def get_service(self) -> CategoricalDeductionService:
        return self.service