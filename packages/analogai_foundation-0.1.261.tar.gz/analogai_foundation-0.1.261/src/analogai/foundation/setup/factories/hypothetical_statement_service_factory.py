from analogai.foundation.modules.conditionals.hypothetical_statement_service import HypotheticalStatementService
from .repository_selector import create_repository_strategy



class HypotheticalStatementServiceFactory:
    def __init__(
        self,
        repository=None,
        environment: str | None = None,
    ):
        self.repository = repository or create_repository_strategy(environment).get_hypothetical_statement_repository()
        self.service = HypotheticalStatementService(
            hypothetical_statement_repository=self.repository,
        )

    def get_service(self) -> HypotheticalStatementService:
        return self.service

    def get_repository(self):
        return self.repository