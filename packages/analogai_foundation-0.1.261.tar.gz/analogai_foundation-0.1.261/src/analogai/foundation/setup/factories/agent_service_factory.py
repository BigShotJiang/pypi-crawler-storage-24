from analogai.foundation.modules.agent.agent_service import AgentService
from .repository_selector import create_repository_strategy


class AgentServiceFactory:
    def __init__(self, repository=None, environment: str | None = None):
        self.repository = repository or create_repository_strategy(environment).get_agent_repository()
        self.service = AgentService(self.repository)

    def get_service(self) -> AgentService:
        return self.service

    def get_repository(self):
        return self.repository
