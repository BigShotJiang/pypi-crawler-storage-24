from analogai.foundation.modules.belief.belief_service import BeliefService
from .notion_service_factory import NotionServiceFactory
from .statement_service_factory import StatementServiceFactory


class BeliefServiceFactory:
    def __init__(
        self,
        repository=None,
        notion_service=None,
        statement_service=None,
        categorical_deduction_service=None,
        conditional_deduction_service=None,
        environment: str | None = None,
    ):
        self.repository = repository
        self.statement_service = statement_service or StatementServiceFactory(environment=environment).get_service()
        self.notion_service = notion_service or NotionServiceFactory(environment=environment).get_service()
        self.service = BeliefService(
            statement_service=self.statement_service,
            notion_service=self.notion_service,
            categorical_deduction_service=categorical_deduction_service,
            conditional_deduction_service=conditional_deduction_service,
        )

    def get_service(self) -> BeliefService:
        return self.service

    def get_repository(self):
        return self.repository
