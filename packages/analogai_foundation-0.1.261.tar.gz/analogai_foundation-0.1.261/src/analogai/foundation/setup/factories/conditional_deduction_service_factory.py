from analogai.foundation.modules.conditionals.conditional_deduction_service import ConditionalDeductionService
from .belief_service_factory import BeliefServiceFactory
from .hypothetical_statement_service_factory import HypotheticalStatementServiceFactory
from .notion_service_factory import NotionServiceFactory


class ConditionalDeductionServiceFactory:
    def __init__(
        self,
        belief_service=None,
        notion_service=None,
        hypothetical_statement_service=None,
        environment: str | None = None,
    ):
        self.belief_service = belief_service or BeliefServiceFactory(environment=environment).get_service()
        self.notion_service = notion_service or NotionServiceFactory(environment=environment).get_service()
        self.hypothetical_statement_service = (
            hypothetical_statement_service or HypotheticalStatementServiceFactory(environment=environment).get_service()
        )
        self.service = ConditionalDeductionService(
            hypothetical_statement_service=self.hypothetical_statement_service,
            notion_service=self.notion_service,
            belief_service=self.belief_service,
        )

    def get_service(self) -> ConditionalDeductionService:
        return self.service