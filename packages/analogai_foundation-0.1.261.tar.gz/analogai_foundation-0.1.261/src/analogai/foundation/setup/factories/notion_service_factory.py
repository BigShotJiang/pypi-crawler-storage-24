from analogai.foundation.modules.notion.notion_service import NotionService
from .repository_selector import create_repository_strategy


class NotionServiceFactory:
    def __init__(self, repository=None, environment: str | None = None):
        self.repository = repository or create_repository_strategy(environment).get_notion_repository()
        self.service = NotionService(self.repository)

    def get_service(self) -> NotionService:
        return self.service

    def get_repository(self):
        return self.repository
