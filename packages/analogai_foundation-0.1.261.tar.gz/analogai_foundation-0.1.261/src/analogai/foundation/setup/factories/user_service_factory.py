from analogai.foundation.modules.user.user_service import UserService
from .repository_selector import create_repository_strategy


class UserServiceFactory:
    def __init__(self, repository=None, environment: str | None = None):
        self.repository = repository or create_repository_strategy(environment).get_user_repository()
        self.service = UserService(self.repository)

    def get_service(self) -> UserService:
        return self.service

    def get_repository(self):
        return self.repository
