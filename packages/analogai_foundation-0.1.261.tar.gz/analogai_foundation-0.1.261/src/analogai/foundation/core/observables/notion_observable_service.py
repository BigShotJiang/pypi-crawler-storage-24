from abc import ABC, abstractmethod
from .observable_service import ObservableService


class NotionObserver(ABC):
    @abstractmethod
    def on_notion_created(self, notion):
        pass


class NotionObservableService(ObservableService):
    def notify_notion_created(self, notion) -> None:
        for observer in self._observers:
            try:
                observer.on_notion_created(notion)
            except (AttributeError, TypeError):
                pass