from abc import ABC, abstractmethod
from .observable_service import ObservableService


class LearningObserver(ABC):
    @abstractmethod
    def on_learning_created(self, learning):
        pass

    @abstractmethod
    def on_learning_updated(self, learning):
        pass


class LearningObservableService(ObservableService):
    def notify_learning_created(self, learning) -> None:
        for observer in self._observers:
            try:
                observer.on_learning_created(learning)
            except (AttributeError, TypeError):
                pass

    def notify_learning_updated(self, learning) -> None:
        for observer in self._observers:
            try:
                observer.on_learning_updated(learning)
            except (AttributeError, TypeError):
                pass