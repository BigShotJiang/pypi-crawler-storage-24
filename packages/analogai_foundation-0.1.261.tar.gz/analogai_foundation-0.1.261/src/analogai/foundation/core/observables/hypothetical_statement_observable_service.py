from abc import ABC, abstractmethod
from .observable_service import ObservableService


class HypotheticalStatementObserver(ABC):
    @abstractmethod
    def on_hypothetical_statement_created(self, hypothetical_statement):
        pass


class HypotheticalStatementObservableService(ObservableService):
    def notify_hypothetical_statement_created(self, hypothetical_statement) -> None:
        for observer in self._observers:
            try:
                observer.on_hypothetical_statement_created(hypothetical_statement)
            except (AttributeError, TypeError):
                pass


__all__ = ["HypotheticalStatementObserver", "HypotheticalStatementObservableService"]
