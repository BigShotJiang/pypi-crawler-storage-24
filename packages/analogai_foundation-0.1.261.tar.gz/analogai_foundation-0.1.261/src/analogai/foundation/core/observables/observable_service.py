from typing import List, Any


class ObservableService:
    def __init__(self):
        self._observers: List[Any] = []

    def add_observer(self, observer: Any) -> None:
        if observer not in self._observers:
            self._observers.append(observer)

    def remove_observer(self, observer: Any) -> None:
        if observer in self._observers:
            self._observers.remove(observer)