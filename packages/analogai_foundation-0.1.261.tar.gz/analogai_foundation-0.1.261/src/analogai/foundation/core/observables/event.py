from typing import Any
from abc import ABC


class Event(ABC):
    def __init__(self, source: Any):
        self.source = source
        self.timestamp = None