from abc import ABC, abstractmethod
from .observable_service import ObservableService


class UserObserver(ABC):
    @abstractmethod
    def on_user_created(self, user):
        pass


class UserObservableService(ObservableService):
    def notify_user_created(self, user) -> None:
        for observer in self._observers:
            try:
                observer.on_user_created(user)
            except (AttributeError, TypeError):
                pass