from abc import ABC, abstractmethod
from .observable_service import ObservableService


class StatementObserver(ABC):
    @abstractmethod
    def on_statement_created(self, statement):
        pass

    @abstractmethod
    def on_statement_updated(self, statement):
        pass


class StatementObservableService(ObservableService):
    def notify_statement_created(self, statement) -> None:
        for observer in self._observers:
            try:
                observer.on_statement_created(statement)
            except (AttributeError, TypeError):
                pass

    def notify_statement_updated(self, statement) -> None:
        for observer in self._observers:
            try:
                observer.on_statement_updated(statement)
            except (AttributeError, TypeError):
                pass