import unittest
from analogai.foundation.core.value_objects.time import Time

class TestTime(unittest.TestCase):
    
    def test_create_time_with_all_fields(self):
        time = Time(year=2024, month=12, day=25, hour=14, minute=30)
        
        self.assertEqual(time.year, 2024)
        self.assertEqual(time.month, 12)
        self.assertEqual(time.day, 25)
        self.assertEqual(time.hour, 14)
        self.assertEqual(time.minute, 30)
    
    def test_create_time_with_partial_fields(self):
        time = Time(year=2024, month=12)
        
        self.assertEqual(time.year, 2024)
        self.assertEqual(time.month, 12)
        self.assertIsNone(time.day)
        self.assertIsNone(time.hour)
        self.assertIsNone(time.minute)
    
    def test_create_time_empty(self):
        time = Time()
        
        self.assertIsNone(time.year)
        self.assertIsNone(time.month)
        self.assertIsNone(time.day)
        self.assertIsNone(time.hour)
        self.assertIsNone(time.minute)
    
    def test_create_time_with_only_time_fields(self):
        time = Time(hour=10, minute=15)
        
        self.assertIsNone(time.year)
        self.assertIsNone(time.month)
        self.assertIsNone(time.day)
        self.assertEqual(time.hour, 10)
        self.assertEqual(time.minute, 15)

if __name__ == '__main__':
    unittest.main()
