import unittest
from analogai.foundation.core.value_objects.time import Time

class TestTimeValueObject(unittest.TestCase):
    
    def test_create_time_with_all_fields(self):
        time = Time(year=2024, month=12, day=25, hour=14, minute=30)
        
        self.assertEqual(time.year, 2024)
        self.assertEqual(time.month, 12)
        self.assertEqual(time.day, 25)
        self.assertEqual(time.hour, 14)
        self.assertEqual(time.minute, 30)

    def test_create_time_with_partial_fields(self):
        time = Time(year=2024, month=12)
        
        self.assertEqual(time.year, 2024)
        self.assertEqual(time.month, 12)
        self.assertIsNone(time.day)
        self.assertIsNone(time.hour)
        self.assertIsNone(time.minute)

if __name__ == '__main__':
    unittest.main()
