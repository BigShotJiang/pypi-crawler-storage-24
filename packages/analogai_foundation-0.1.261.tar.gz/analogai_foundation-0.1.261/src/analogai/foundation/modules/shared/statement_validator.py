from typing import Union


def validate_probability_validity(probability: Union[float, int], validity: Union[float, int]) -> None:
    prob = float(probability) if probability is not None else 1.0
    valid = float(validity) if validity is not None else 1.0
    if not 0 <= prob <= 1:
        raise ValueError("probability must be between 0 and 1")
    if not 0 <= valid <= 1:
        raise ValueError("validity must be between 0 and 1")