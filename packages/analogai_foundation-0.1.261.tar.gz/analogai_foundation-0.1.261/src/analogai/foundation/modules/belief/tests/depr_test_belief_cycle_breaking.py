# import unittest
# from unittest.mock import Mock
# import uuid
# from analogai.foundation.modules.belief.belief import Belief
# from analogai.foundation.modules.direct_statement.direct_statement import DirectStatement as Statement

# from analogai.foundation.modules.categorical_deduction.categorical_deduction import CategoricalDeduction
# from analogai.foundation.modules.notion.notion import Notion
# from analogai.foundation.modules.belief.utils.cycle_breaker import reset_visited_set


# class TestBeliefCycleBreaking(unittest.TestCase):
#     def setUp(self):
#         self.agent_id = str(uuid.uuid4())
#         self.user_id = str(uuid.uuid4())
#         reset_visited_set()

#         self.notion_a = Notion(user_id=self.user_id, agent_id=self.agent_id, caption="A", id="notion_a")
#         self.notion_b = Notion(user_id=self.user_id, agent_id=self.agent_id, caption="B", id="notion_b")
#         self.notion_c = Notion(user_id=self.user_id, agent_id=self.agent_id, caption="C", id="notion_c")

#     def test_direct_cycle_a_to_b_to_a(self):
#         belief_a_to_b = Belief(agent_id=self.agent_id, id="belief_a_to_b")
#         belief_b_to_a = Belief(agent_id=self.agent_id, id="belief_b_to_a")

#         stmt_a_to_b = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_a,
#             relation="is",
#             complement_notion=self.notion_b,
#             probability=0.8,
#             validity=0.9,
#             id="stmt_a_to_b",
#         )

#         stmt_b_to_a = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_b,
#             relation="is",
#             complement_notion=self.notion_a,
#             probability=0.6,
#             validity=0.7,
#             id="stmt_b_to_a",
#         )

#         belief_a_to_b.add_statement(stmt_a_to_b)
#         belief_b_to_a.add_statement(stmt_b_to_a)

#         deductive_inf_a_to_b = Mock(spec=CategoricalDeduction)
#         deductive_inf_a_to_b.id = "deductive_a_to_b"
#         deductive_inf_a_to_b.validity = 0.5
#         deductive_inf_a_to_b.probability = 0.4
#         deductive_inf_a_to_b.modifier = None
#         deductive_inf_a_to_b.major_premise = belief_b_to_a
#         deductive_inf_a_to_b.minor_premise = belief_b_to_a

#         deductive_inf_b_to_a = Mock(spec=CategoricalDeduction)
#         deductive_inf_b_to_a.id = "deductive_b_to_a"
#         deductive_inf_b_to_a.validity = 0.3
#         deductive_inf_b_to_a.probability = 0.2
#         deductive_inf_b_to_a.modifier = None
#         deductive_inf_b_to_a.major_premise = belief_a_to_b
#         deductive_inf_b_to_a.minor_premise = belief_a_to_b

#         belief_a_to_b.add_statement(deductive_inf_a_to_b)
#         belief_b_to_a.add_statement(deductive_inf_b_to_a)

#         prob_a_to_b = belief_a_to_b.probability
#         self.assertIsNotNone(prob_a_to_b)
#         self.assertGreater(prob_a_to_b, 0.0)

#         prob_b_to_a = belief_b_to_a.probability
#         self.assertIsNotNone(prob_b_to_a)
#         self.assertGreater(prob_b_to_a, 0.0)

#         validity_a_to_b = belief_a_to_b.validity
#         self.assertIsNotNone(validity_a_to_b)
#         self.assertGreater(validity_a_to_b, 0.0)

#         validity_b_to_a = belief_b_to_a.validity
#         self.assertIsNotNone(validity_b_to_a)
#         self.assertGreater(validity_b_to_a, 0.0)

#     def test_indirect_cycle_a_to_b_to_c_to_b(self):
#         belief_a_to_b = Belief(agent_id=self.agent_id, id="belief_a_to_b")
#         belief_b_to_c = Belief(agent_id=self.agent_id, id="belief_b_to_c")
#         belief_c_to_b = Belief(agent_id=self.agent_id, id="belief_c_to_b")

#         stmt_a_to_b = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_a,
#             relation="is",
#             complement_notion=self.notion_b,
#             probability=0.8,
#             validity=0.9,
#             id="stmt_a_to_b",
#         )

#         stmt_b_to_c = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_b,
#             relation="is",
#             complement_notion=self.notion_c,
#             probability=0.6,
#             validity=0.7,
#             id="stmt_b_to_c",
#         )

#         stmt_c_to_b = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_c,
#             relation="is",
#             complement_notion=self.notion_b,
#             probability=0.4,
#             validity=0.5,
#             id="stmt_c_to_b",
#         )

#         belief_a_to_b.add_statement(stmt_a_to_b)
#         belief_b_to_c.add_statement(stmt_b_to_c)
#         belief_c_to_b.add_statement(stmt_c_to_b)

#         deductive_inf_b_to_c = Mock(spec=CategoricalDeduction)
#         deductive_inf_b_to_c.id = "deductive_b_to_c"
#         deductive_inf_b_to_c.validity = 0.3
#         deductive_inf_b_to_c.probability = 0.2
#         deductive_inf_b_to_c.modifier = None
#         deductive_inf_b_to_c.major_premise = belief_a_to_b
#         deductive_inf_b_to_c.minor_premise = belief_c_to_b

#         deductive_inf_c_to_b = Mock(spec=CategoricalDeduction)
#         deductive_inf_c_to_b.id = "deductive_c_to_b"
#         deductive_inf_c_to_b.validity = 0.1
#         deductive_inf_c_to_b.probability = 0.05
#         deductive_inf_c_to_b.modifier = None
#         deductive_inf_c_to_b.major_premise = belief_b_to_c
#         deductive_inf_c_to_b.minor_premise = belief_b_to_c

#         belief_b_to_c.add_statement(deductive_inf_b_to_c)
#         belief_c_to_b.add_statement(deductive_inf_c_to_b)

#         prob_a_to_b = belief_a_to_b.probability
#         self.assertIsNotNone(prob_a_to_b)

#         prob_b_to_c = belief_b_to_c.probability
#         self.assertIsNotNone(prob_b_to_c)

#         prob_c_to_b = belief_c_to_b.probability
#         self.assertIsNotNone(prob_c_to_b)

#         validity_a_to_b = belief_a_to_b.validity
#         self.assertIsNotNone(validity_a_to_b)

#         validity_b_to_c = belief_b_to_c.validity
#         self.assertIsNotNone(validity_b_to_c)

#         validity_c_to_b = belief_c_to_b.validity
#         self.assertIsNotNone(validity_c_to_b)

#     def test_self_referential_cycle(self):
#         belief_a_to_a = Belief(agent_id=self.agent_id, id="belief_a_to_a")

#         stmt_a_to_a = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_a,
#             relation="is",
#             complement_notion=self.notion_a,
#             probability=0.8,
#             validity=0.9,
#             id="stmt_a_to_a",
#         )

#         belief_a_to_a.add_statement(stmt_a_to_a)

#         deductive_inf_a_to_a = Mock(spec=CategoricalDeduction)
#         deductive_inf_a_to_a.id = "deductive_a_to_a"
#         deductive_inf_a_to_a.validity = 0.5
#         deductive_inf_a_to_a.probability = 0.4
#         deductive_inf_a_to_a.modifier = None
#         deductive_inf_a_to_a.major_premise = belief_a_to_a
#         deductive_inf_a_to_a.minor_premise = belief_a_to_a

#         belief_a_to_a.add_statement(deductive_inf_a_to_a)

#         prob = belief_a_to_a.probability
#         self.assertIsNotNone(prob)
#         self.assertGreater(prob, 0.0)

#         validity = belief_a_to_a.validity
#         self.assertIsNotNone(validity)
#         self.assertGreater(validity, 0.0)

#     def test_complex_cycle_with_multiple_paths(self):
#         belief_a_to_b = Belief(agent_id=self.agent_id, id="belief_a_to_b")
#         belief_b_to_c = Belief(agent_id=self.agent_id, id="belief_b_to_c")
#         belief_c_to_a = Belief(agent_id=self.agent_id, id="belief_c_to_a")
#         belief_a_to_c = Belief(agent_id=self.agent_id, id="belief_a_to_c")

#         stmt_a_to_b = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_a,
#             relation="is",
#             complement_notion=self.notion_b,
#             probability=0.8,
#             validity=0.9,
#             id="stmt_a_to_b",
#         )

#         stmt_b_to_c = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_b,
#             relation="is",
#             complement_notion=self.notion_c,
#             probability=0.6,
#             validity=0.7,
#             id="stmt_b_to_c",
#         )

#         stmt_c_to_a = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_c,
#             relation="is",
#             complement_notion=self.notion_a,
#             probability=0.4,
#             validity=0.5,
#             id="stmt_c_to_a",
#         )

#         stmt_a_to_c = Statement(
#             user_id=self.user_id,
#             agent_id=self.agent_id,
#             subject_notion=self.notion_a,
#             relation="is",
#             complement_notion=self.notion_c,
#             probability=0.2,
#             validity=0.3,
#             id="stmt_a_to_c",
#         )

#         belief_a_to_b.add_statement(stmt_a_to_b)
#         belief_b_to_c.add_statement(stmt_b_to_c)
#         belief_c_to_a.add_statement(stmt_c_to_a)
#         belief_a_to_c.add_statement(stmt_a_to_c)

#         deductive_inf_a_to_b = Mock(spec=CategoricalDeduction)
#         deductive_inf_a_to_b.id = "deductive_a_to_b"
#         deductive_inf_a_to_b.validity = 0.1
#         deductive_inf_a_to_b.probability = 0.05
#         deductive_inf_a_to_b.modifier = None
#         deductive_inf_a_to_b.major_premise = belief_c_to_a
#         deductive_inf_a_to_b.minor_premise = belief_a_to_c

#         belief_a_to_b.add_statement(deductive_inf_a_to_b)

#         prob_a_to_b = belief_a_to_b.probability
#         self.assertIsNotNone(prob_a_to_b)

#         prob_b_to_c = belief_b_to_c.probability
#         self.assertIsNotNone(prob_b_to_c)

#         prob_c_to_a = belief_c_to_a.probability
#         self.assertIsNotNone(prob_c_to_a)

#         prob_a_to_c = belief_a_to_c.probability
#         self.assertIsNotNone(prob_a_to_c)


# if __name__ == '__main__':
#     unittest.main()
