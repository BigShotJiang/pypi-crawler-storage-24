import unittest
from analogai.foundation.modules.belief.utils.belief_certainties_calculator_util import calculate_belief_certainties


class TestBeliefCertaintiesCalculatorUtil(unittest.TestCase):
    def test_calculate_belief_certainties_single_statement(self):
        certainties = [(1.0, 0.8)]
        probability, validity = calculate_belief_certainties(certainties)

        self.assertEqual(probability, 0.8)
        self.assertEqual(validity, 1.0)

    def test_calculate_belief_certainties_multiple_statements(self):
        certainties = [(1.0, 0.8), (0.5, 0.6)]

        probability, validity = calculate_belief_certainties(certainties)

        self.assertAlmostEqual(probability, 0.73, places=2)
        self.assertAlmostEqual(validity, 0.83, places=2)

    def test_calculate_belief_certainties_empty_list(self):
        certainties = []

        with self.assertRaises(ValueError):
            calculate_belief_certainties(certainties)

    def test_calculate_belief_certainties_zero_validity(self):
        certainties = [(0.0, 0.8)]

        with self.assertRaises(ValueError):
            calculate_belief_certainties(certainties)

    def test_calculate_belief_certainties_mixed_validities(self):
        certainties = [(1.0, 0.8), (0.2, 0.6), (0.5, 0.4)]

        probability, validity = calculate_belief_certainties(certainties)

        self.assertAlmostEqual(probability, 0.66, places=2)
        self.assertAlmostEqual(validity, 0.76, places=2)


if __name__ == '__main__':
    unittest.main()
