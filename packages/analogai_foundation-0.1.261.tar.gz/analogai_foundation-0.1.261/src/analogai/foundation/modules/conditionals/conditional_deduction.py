from typing import Optional, Any

from analogai.foundation.modules.shared.statement_base import StatementBase
from analogai.foundation.modules.notion.notion import Notion
from analogai.foundation.core.value_objects.modifier import Modifier
from analogai.foundation.core.value_objects.relation import Relation
from analogai.foundation.common.logging.app_logger import app_logger
from analogai.foundation.common.utils.entity_formatters import format_conditional_deduction_repr


class ConditionalDeduction(StatementBase):
    def __init__(
        self,
        agent_id: str,
        hypothetical_statement,
        subject_notion: Notion,
        complement_notion: Notion,
        relation: Relation,
        probability: float,
        validity: float,
        id: Optional[str] = None,
        modifier: Optional[Modifier] = None,
    ):
        super().__init__(
            agent_id=agent_id,
            subject_notion=subject_notion,
            complement_notion=complement_notion,
            relation=relation,
            id=id,
            modifier=modifier,
        )
        self.hypothetical_statement = hypothetical_statement
        self.hypothetical_statement_id = getattr(hypothetical_statement, "id", None)
        self._probability = probability
        self._validity = validity
        self._log_creation()

    @property
    def probability(self) -> float:
        return self._probability

    @property
    def validity(self) -> float:
        return self._validity

    def visit(self, visitor: Any) -> Any:
        return visitor.visit_conditional_deduction(self)

    def _log_creation(self):
        from analogai.foundation.common.utils.statement_serializers import serialize_statement
        try:
            probability = float(self.probability)
            serialized = serialize_statement(
                subject_notion_caption=self.subject_notion.caption,
                complement_notion_caption=self.complement_notion.caption,
                relation=self.relation,
                probability=probability,
                modifier=self.modifier,
                subject_attributes=self.subject_notion.attributes,
                complement_attributes=self.complement_notion.attributes,
            )
            app_logger.debug(f"Created ConditionalDeduction: {serialized} (id: {self.id})")
        except (ValueError, AttributeError, TypeError):
            app_logger.debug(f"Created ConditionalDeduction (id: {self.id})")

    def __repr__(self) -> str:
        return format_conditional_deduction_repr(self)