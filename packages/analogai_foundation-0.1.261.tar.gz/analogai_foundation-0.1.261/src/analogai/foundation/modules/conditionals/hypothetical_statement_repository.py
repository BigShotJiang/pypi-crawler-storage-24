from abc import ABC, abstractmethod
from typing import List, Optional

from analogai.foundation.modules.conditionals.hypothetical_statement import HypotheticalStatement


class HypotheticalStatementRepository(ABC):
    @abstractmethod
    def create(self, hypothetical_statement: HypotheticalStatement) -> HypotheticalStatement:
        pass

    @abstractmethod
    def find_by_id(self, hypothetical_statement_id: str) -> Optional[HypotheticalStatement]:
        pass

    @abstractmethod
    def find_by_agent_id(self, agent_id: str) -> List[HypotheticalStatement]:
        pass