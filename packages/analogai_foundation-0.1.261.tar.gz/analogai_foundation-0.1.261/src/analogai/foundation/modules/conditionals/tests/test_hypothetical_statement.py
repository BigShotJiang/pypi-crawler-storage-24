import unittest

from analogai.foundation.common.enums.certainty import Certainty
from analogai.foundation.common.enums.criterion import Criterion
from analogai.foundation.core.value_objects.effect import Effect
from analogai.foundation.core.value_objects.relation import Relation
from analogai.foundation.modules.conditionals.hypothetical_statement import HypotheticalStatement


class TestHypotheticalStatementCertainty(unittest.TestCase):
    def _build_effect(self, certainty=None):
        criteria = {
            Criterion.SubjectCaption: "sky",
            Criterion.ObjectCaption: "blue",
            Criterion.Relation: Relation.from_string("is"),
        }
        if certainty is not None:
            criteria[Criterion.Certainty] = certainty
        return Effect(criteria)

    def test_user_id_is_preserved(self):
        hypothetical = HypotheticalStatement(
            user_id="user-1",
            agent_id="agent-1",
            causes=[],
            effect=self._build_effect(),
        )
        self.assertEqual(hypothetical.user_id, "user-1")

    def test_effect_certainty_is_preserved(self):
        hypothetical = HypotheticalStatement(
            user_id="user-1",
            agent_id="agent-1",
            causes=[],
            effect=self._build_effect(Certainty.UNCERTAIN),
        )
        self.assertEqual(
            hypothetical.effect.criteria.get(Criterion.Certainty),
            Certainty.UNCERTAIN,
        )


if __name__ == "__main__":
    unittest.main()
