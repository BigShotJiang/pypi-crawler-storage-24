import uuid
from datetime import datetime
from typing import List, Optional

from analogai.foundation.core.value_objects.cause import Cause
from analogai.foundation.core.value_objects.effect import Effect


class HypotheticalStatement:
    def __init__(
        self,
        user_id: Optional[str],
        agent_id: str,
        causes: List[Cause],
        effect: Effect,
        validity: float = 1.0,
        created_at: Optional[datetime] = None,
        id: Optional[str] = None,
    ):
        self.id = id if id else str(uuid.uuid4())
        self.user_id = user_id
        self.agent_id = agent_id
        self.causes = list(causes or [])
        self.effect = effect
        self.validity = validity
        self.created_at = created_at if created_at else datetime.now()
