import unittest
from analogai.foundation.modules.agent.agent import Agent, Role
from analogai.foundation.modules.user.user import User
from analogai.foundation.common.enums.agent_openness import AgentOpenness


class TestAgent(unittest.TestCase):
    def setUp(self):
        self.creator = User(id="creator_id", name="Creator", email="creator@example.com")
        self.user = User(id="user_id", name="Test User", email="user@example.com")
        self.role = Role(user=self.user, authority=0.8)

    def test_agent_default_initialization(self):
        agent = Agent(id="test_agent", creator=self.creator)

        self.assertEqual(agent.id, "test_agent")
        self.assertEqual(agent.knowledge_base, "")
        self.assertEqual(agent.creator, self.creator)
        self.assertEqual(len(agent.roles), 0)
        self.assertEqual(agent.openness, AgentOpenness.OPEN)

    def test_agent_full_initialization(self):
        agent = Agent(
            id="test_agent",
            knowledge_base="Test knowledge base",
            creator=self.creator,
            roles=[self.role]
        )

        self.assertEqual(agent.id, "test_agent")
        self.assertEqual(agent.knowledge_base, "Test knowledge base")
        self.assertEqual(agent.creator, self.creator)
        self.assertEqual(len(agent.roles), 1)
        self.assertEqual(agent.roles[0], self.role)

    def test_set_knowledge_base(self):
        agent = Agent(id="test_agent", creator=self.creator)

        agent.set_knowledge_base("New knowledge base")

        self.assertEqual(agent.knowledge_base, "New knowledge base")

    def test_agent_with_multiple_roles(self):
        user2 = User(id="user2_id", name="User Two", email="user2@example.com")
        role2 = Role(user=user2, authority=0.6)

        agent = Agent(
            id="test_agent",
            creator=self.creator,
            roles=[self.role, role2]
        )

        self.assertEqual(len(agent.roles), 2)
        self.assertEqual(agent.roles[0].user.id, "user_id")
        self.assertEqual(agent.roles[1].user.id, "user2_id")
        self.assertEqual(agent.roles[0].authority, 0.8)
        self.assertEqual(agent.roles[1].authority, 0.6)

    def test_agent_openness_functionality(self):
        agent = Agent(id="test_agent", creator=self.creator)

        self.assertTrue(agent.is_open())
        self.assertFalse(agent.is_closed())

        agent.set_openness(AgentOpenness.CLOSED)

        self.assertFalse(agent.is_open())
        self.assertTrue(agent.is_closed())

        agent.set_openness(AgentOpenness.OPEN)

        self.assertTrue(agent.is_open())
        self.assertFalse(agent.is_closed())

    def test_agent_full_initialization_with_all_fields(self):
        agent = Agent(
            id="test_agent",
            knowledge_base="Test knowledge base",
            creator=self.creator,
            roles=[self.role],
            openness=AgentOpenness.CLOSED
        )

        self.assertEqual(agent.id, "test_agent")
        self.assertEqual(agent.knowledge_base, "Test knowledge base")
        self.assertEqual(agent.creator, self.creator)
        self.assertEqual(len(agent.roles), 1)
        self.assertEqual(agent.openness, AgentOpenness.CLOSED)


if __name__ == "__main__":
    unittest.main()
