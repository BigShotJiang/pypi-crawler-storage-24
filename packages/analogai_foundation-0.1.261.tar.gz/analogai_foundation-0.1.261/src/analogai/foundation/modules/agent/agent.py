from dataclasses import dataclass, field
from typing import List
from analogai.foundation.modules.user.user import User
from analogai.foundation.common.enums.agent_openness import AgentOpenness
import uuid

@dataclass
class Agent:
    creator: User
    name: str = ""
    knowledge_base: str = ""
    roles: List["Role"] = field(default_factory=list)
    openness: AgentOpenness = AgentOpenness.OPEN
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid.uuid4())

    def set_knowledge_base(self, knowledge_base: str):
        self.knowledge_base = knowledge_base

    def get_knowledge_base(self) -> str:
        return self.knowledge_base

    def is_open(self) -> bool:
        return self.openness == AgentOpenness.OPEN

    def is_closed(self) -> bool:
        return self.openness == AgentOpenness.CLOSED

    def set_openness(self, openness: AgentOpenness):
        self.openness = openness

@dataclass
class Role:
    user: User
    authority: float
    id: str = ""

    def __post_init__(self):
        self.id = self.id if self.id else str(uuid.uuid4())