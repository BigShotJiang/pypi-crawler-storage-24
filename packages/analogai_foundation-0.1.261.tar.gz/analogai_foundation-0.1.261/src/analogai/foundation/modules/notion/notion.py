import uuid
from typing import Optional, List

from analogai.foundation.core.value_objects.attribute import Attribute
from analogai.foundation.common.utils.entity_formatters import (
    format_notion_str,
    format_notion_repr,
)


class Notion:
    def __init__(
        self,
        user_id: str,
        agent_id: str,
        caption: str,
        id: Optional[str] = None,
        attributes: Optional[List[Attribute]] = None,
    ):
        self.id = id if id else str(uuid.uuid4())
        self.user_id = user_id
        self.agent_id = agent_id
        self.caption = caption
        self.attributes = attributes

    def __str__(self) -> str:
        return format_notion_str(self)

    def __repr__(self) -> str:
        return format_notion_repr(self)

