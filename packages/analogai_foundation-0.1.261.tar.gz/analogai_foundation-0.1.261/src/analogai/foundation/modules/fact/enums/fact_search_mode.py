from __future__ import annotations

from enum import Enum


class FactSearchMode(str, Enum):
    TEXT_ONLY = "text_only"
    VECTOR_ONLY = "vector_only"
    VECTOR_THEN_TEXT = "vector_then_text"
