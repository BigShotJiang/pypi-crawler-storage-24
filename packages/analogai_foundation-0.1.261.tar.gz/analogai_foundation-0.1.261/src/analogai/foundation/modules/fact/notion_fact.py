from __future__ import annotations

from dataclasses import dataclass

from analogai.foundation.modules.fact.basefact import BaseFact
from analogai.foundation.modules.fact.fact_deletion_utils import delete_notion


@dataclass
class NotionFact(BaseFact):
    notion_id: str = ""

    def __post_init__(self) -> None:
        super().__post_init__()
        if not self.notion_id:
            raise ValueError("NotionFact requires notion_id")

    def delete(self) -> None:
        self._delete_fact()
        delete_notion(self.notion_id, self._notion_service)


__all__ = ["NotionFact"]
