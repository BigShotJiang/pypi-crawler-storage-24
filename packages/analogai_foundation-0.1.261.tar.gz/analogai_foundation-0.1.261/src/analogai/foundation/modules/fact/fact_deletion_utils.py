from __future__ import annotations

from typing import Optional


def delete_statement(statement_id: Optional[str], statement_service: object | None) -> None:
    if not statement_id or statement_service is None:
        return
    find_stmt = getattr(statement_service, "find_by_id", None)
    delete_stmt = getattr(statement_service, "delete", None)
    if callable(find_stmt) and callable(delete_stmt):
        statement = find_stmt(str(statement_id))
        if statement is not None:
            delete_stmt(statement)
        return
    if callable(delete_stmt):
        delete_stmt(statement_id)


def delete_notion(notion_id: Optional[str], notion_service: object | None) -> None:
    if not notion_id or notion_service is None:
        return
    find_notion = getattr(notion_service, "find_by_id", None)
    delete_notion_fn = getattr(notion_service, "delete", None)
    if callable(find_notion) and callable(delete_notion_fn):
        notion = find_notion(str(notion_id))
        if notion is not None:
            delete_notion_fn(notion)
        return
    if callable(delete_notion_fn):
        delete_notion_fn(notion_id)


__all__ = ["delete_statement", "delete_notion"]
