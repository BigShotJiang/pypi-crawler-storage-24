from unittest import TestCase

from analogai.foundation.modules.fact.source.fact_source import UrlSource, FileSource
from analogai.foundation.modules.fact.source.repositories.infrastructure.in_memory_fact_source_repository import (
    InMemoryFactSourceRepository,
)


class TestInMemoryFactSourceRepository(TestCase):
    def setUp(self) -> None:
        self.repo = InMemoryFactSourceRepository()

    def test_register_get_list_delete(self) -> None:
        url_source = UrlSource("https://example.com", agent_id="agent-1")
        file_source = FileSource("C:/tmp/source.txt", agent_id="agent-1")

        self.repo.register_source(url_source)
        self.repo.register_source(file_source)

        self.assertEqual(self.repo.get_source(url_source.id), url_source)
        self.assertEqual(self.repo.get_source(file_source.id), file_source)

        sources = {item.id for item in self.repo.list_sources_for_agent("agent-1")}
        self.assertIn(url_source.id, sources)
        self.assertIn(file_source.id, sources)

        deleted = self.repo.delete_source(url_source.id)
        self.assertEqual(deleted, url_source)
        self.assertIsNone(self.repo.get_source(url_source.id))

    def test_register_ignores_empty_values(self) -> None:
        empty = UrlSource("", agent_id="agent-1")
        self.repo.register_source(empty)
        self.assertEqual(self.repo.list_sources_for_agent("agent-1"), [])
