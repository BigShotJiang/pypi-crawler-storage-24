from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Optional

from analogai.foundation.modules.fact.source.fact_source import FactSource


class FactSourceRepository(ABC):
    @abstractmethod
    def register_source(self, source: FactSource) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_source(self, source_id: str) -> Optional[FactSource]:
        raise NotImplementedError

    @abstractmethod
    def list_sources(self) -> List[FactSource]:
        raise NotImplementedError

    @abstractmethod
    def list_sources_for_agent(self, agent_id: str) -> List[FactSource]:
        raise NotImplementedError

    @abstractmethod
    def delete_source(self, source_id: str) -> Optional[FactSource]:
        raise NotImplementedError
