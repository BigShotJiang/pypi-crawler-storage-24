import unittest
from datetime import datetime

from analogai.foundation.modules.fact.subscribers.fact_observer_registry import (
    FactObserverRegistry,
)
from analogai.foundation.modules.fact.source.fact_source import OtherSource


class TestFactObserverRegistry(unittest.TestCase):
    def setUp(self):
        self.registry = FactObserverRegistry()
        self.source = OtherSource("unit")

    def test_append_and_pop_fifo(self):
        self.registry.append_current_sentence(text="first", role="user", source=self.source)
        self.registry.append_current_sentence(text="second", role="assistant", source=self.source)

        peek = self.registry.get_current_sentence()
        self.assertEqual(peek.text, "first")

        first = self.registry.pop_current_sentence()
        self.assertEqual(first.text, "first")

        second = self.registry.pop_current_sentence()
        self.assertEqual(second.text, "second")

        self.assertIsNone(self.registry.pop_current_sentence())

    def test_clear_current_sentence(self):
        self.registry.append_current_sentence(text="first", role="user", source=self.source)
        self.registry.clear_current_sentence()
        self.assertIsNone(self.registry.get_current_sentence())

    def test_use_current_sentence_context_manager(self):
        with self.registry.use_current_sentence(
            text="inner",
            role="assistant",
            timestamp=datetime.utcnow(),
            source=self.source,
        ):
            current = self.registry.get_current_sentence()
            self.assertEqual(current.text, "inner")

        self.assertIsNone(self.registry.pop_current_sentence())


if __name__ == "__main__":
    unittest.main()
