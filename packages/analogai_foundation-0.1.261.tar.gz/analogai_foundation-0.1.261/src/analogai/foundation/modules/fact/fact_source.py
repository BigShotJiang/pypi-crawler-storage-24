from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import os
from typing import Optional


class SourceType(str, Enum):
    FILE = "FILE"
    WEBSITE = "WEBSITE"
    URL = "WEBSITE"
    OTHER = "OTHER"


@dataclass(frozen=True)
class FactSource:
    type: SourceType
    value: Optional[str] = None

    @property
    def id(self) -> str:
        value = self.value or ""
        return f"{self.type.value}:{value}"

    def __str__(self) -> str:
        if not self.value:
            return ""
        if self.type == SourceType.FILE:
            return os.path.basename(self.value)
        return str(self.value)


@dataclass(frozen=True)
class FileSource(FactSource):
    def __init__(self, value: Optional[str] = None):
        super().__init__(SourceType.FILE, value)

    def __str__(self) -> str:
        if not self.value:
            return ""
        return os.path.basename(self.value)


@dataclass(frozen=True)
class UrlSource(FactSource):
    def __init__(self, value: Optional[str] = None):
        super().__init__(SourceType.WEBSITE, value)

    def __str__(self) -> str:
        return str(self.value or "")


@dataclass(frozen=True)
class OtherSource(FactSource):
    def __init__(self, value: Optional[str] = None):
        super().__init__(SourceType.OTHER, value)

    def __str__(self) -> str:
        return str(self.value or "")


__all__ = ["FactSource", "FileSource", "UrlSource", "OtherSource", "SourceType"]
