from __future__ import annotations

from dataclasses import dataclass

from analogai.foundation.modules.fact.basefact import BaseFact


@dataclass
class HypotheticalStatementFact(BaseFact):
    statement_id: str = ""

    def __post_init__(self) -> None:
        super().__post_init__()
        if not self.statement_id:
            raise ValueError("HypotheticalStatementFact requires statement_id")

    def delete(self) -> None:
        self._delete_fact()


__all__ = ["HypotheticalStatementFact"]
