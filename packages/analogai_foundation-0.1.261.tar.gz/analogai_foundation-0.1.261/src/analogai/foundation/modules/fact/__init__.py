from .utils.fact_context import get_current_turn_id, set_current_turn_id, use_turn_id
from .factories.fact_factory import FactServiceFactory
from .basefact import BaseFact, FactResolver
from .notion_fact import NotionFact
from .direct_statement_fact import DirectStatementFact
from .hypothetical_statement_fact import HypotheticalStatementFact
from .fact_builder import build_fact
from .repositories.fact_repository import FactRepository
from .repositories.infrastructure.in_memory_fact_repository import InMemoryFactRepository
from .repositories.infrastructure.mongo_fact_repository import MongoFactRepository
from .repositories.infrastructure.qdrant_fact_repository import QdrantFactRepository
from .services.fact_service import (
	FactServicePort,
	RepositoryBackedFactService,
)
from .enums.fact_reference_type import FactReferenceType
from .source.fact_source import FactSource, FileSource, OtherSource, SourceType, UrlSource
from .source.repositories.fact_source_repository import FactSourceRepository
from .source.repositories.infrastructure.in_memory_fact_source_repository import (
	InMemoryFactSourceRepository,
)
from .source.repositories.infrastructure.mongo_fact_source_repository import (
	MongoFactSourceRepository,
)
from .source.services.fact_source_service import FactSourceService
from .source.factories.fact_source_service_factory import FactSourceServiceFactory
from .subscribers.fact_observer_registry import FactObserverRegistry, FactSentenceContext
from .subscribers.fact_observer_builder import FactObserverBuilder
from .subscribers.statement_fact_subscriber import StatementFactSubscriber
from .subscribers.notion_fact_subscriber import NotionFactSubscriber
from .subscribers.hypothetical_statement_fact_subscriber import HypotheticalStatementFactSubscriber

__all__ = [
	"get_current_turn_id",
	"set_current_turn_id",
	"use_turn_id",
	"FactServiceFactory",
	"BaseFact",
	"FactResolver",
	"NotionFact",
	"DirectStatementFact",
	"HypotheticalStatementFact",
	"build_fact",
	"FactRepository",
	"FactSourceRepository",
	"InMemoryFactRepository",
	"InMemoryFactSourceRepository",
	"MongoFactRepository",
	"MongoFactSourceRepository",
	"QdrantFactRepository",
	"FactServicePort",
	"RepositoryBackedFactService",
	"FactReferenceType",
	"FactSourceService",
	"FactSourceServiceFactory",
	"FactObserverRegistry",
	"FactSentenceContext",
	"FactObserverBuilder",
	"StatementFactSubscriber",
	"NotionFactSubscriber",
	"HypotheticalStatementFactSubscriber",
	"FactSource",
	"FileSource",
	"UrlSource",
	"OtherSource",
	"SourceType",
]
