from __future__ import annotations

from enum import Enum


class FactEmbeddingMode(str, Enum):
    ENABLED = "enabled"
    DISABLED = "disabled"
