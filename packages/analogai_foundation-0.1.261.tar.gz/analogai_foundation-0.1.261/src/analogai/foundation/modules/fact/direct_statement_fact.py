from __future__ import annotations

from dataclasses import dataclass

from analogai.foundation.modules.fact.basefact import BaseFact
from analogai.foundation.modules.fact.fact_deletion_utils import delete_statement


@dataclass
class DirectStatementFact(BaseFact):
    statement_id: str = ""

    def __post_init__(self) -> None:
        super().__post_init__()
        if not self.statement_id:
            raise ValueError("DirectStatementFact requires statement_id")

    def delete(self) -> None:
        self._delete_fact()
        delete_statement(self.statement_id, self._statement_service)


__all__ = ["DirectStatementFact"]
