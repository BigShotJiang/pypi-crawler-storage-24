from __future__ import annotations

from typing import Any

from analogai.foundation.modules.fact.utils.fact_context import get_current_turn_id
from analogai.foundation.modules.fact.services.fact_service import FactServicePort


class FactStatementService:
    def __init__(self, statement_service: Any, fact_service: FactServicePort):
        self._statement_service = statement_service
        self._fact_service = fact_service

    def __getattr__(self, name: str):
        return getattr(self._statement_service, name)

    def create(self, *args, **kwargs):
        statement = self._statement_service.create(*args, **kwargs)
        turn_id = get_current_turn_id()
        statement_id = statement.id
        if turn_id and statement_id:
            self._fact_service.link_statement(str(statement_id), turn_id)
        return statement
