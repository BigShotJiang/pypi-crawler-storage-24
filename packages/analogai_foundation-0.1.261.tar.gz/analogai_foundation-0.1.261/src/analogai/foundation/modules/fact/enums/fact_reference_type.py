from enum import Enum


class FactReferenceType(str, Enum):
    NOTION = "NOTION"
    STATEMENT = "STATEMENT"
    HYPOTHETICAL_STATEMENT = "HYPOTHETICAL_STATEMENT"
