from __future__ import annotations

from typing import Dict, List, Optional

from analogai.foundation.modules.fact.source.fact_source import FactSource
from analogai.foundation.modules.fact.source.repositories.fact_source_repository import FactSourceRepository


class InMemoryFactSourceRepository(FactSourceRepository):
    def __init__(self) -> None:
        self._sources: Dict[str, FactSource] = {}

    def register_source(self, source: FactSource) -> None:
        if source is None:
            return
        if source.value is None or str(source.value).strip() == "":
            return
        if source.agent_id is None or str(source.agent_id).strip() == "":
            return
        self._sources[source.id] = source

    def get_source(self, source_id: str) -> Optional[FactSource]:
        if not source_id:
            return None
        return self._sources.get(source_id)

    def list_sources(self) -> List[FactSource]:
        return list(self._sources.values())

    def list_sources_for_agent(self, agent_id: str) -> List[FactSource]:
        if not agent_id:
            return []
        return [source for source in self._sources.values() if source.agent_id == agent_id]

    def delete_source(self, source_id: str) -> Optional[FactSource]:
        if not source_id:
            return None
        return self._sources.pop(source_id, None)
