from __future__ import annotations

from analogai.foundation.core.observables.notion_observable_service import NotionObserver
from analogai.foundation.modules.fact.services.fact_service import FactServicePort
from analogai.foundation.modules.fact.subscribers.fact_observer_registry import (
    FactObserverRegistry,
)


class NotionFactSubscriber(NotionObserver):
    def __init__(self, fact_service: FactServicePort, registry: FactObserverRegistry) -> None:
        self._fact_service = fact_service
        self._registry = registry

    def append_current_sentence(self, text: str, source: object, role: str = "user") -> None:
        self._registry.append_current_sentence(text=text, role=role, source=source)

    def on_notion_created(self, notion) -> None:
        context = self._registry.get_current_sentence()
        if context is None or not context.text or not context.text.strip():
            if self._registry.require_sentence:
                raise ValueError("Fact observer requires current sentence text")
            return
        self._fact_service.record_notion_fact(
            user_id=notion.user_id,
            agent_id=notion.agent_id,
            notion_id=str(notion.id),
            text=context.text,
            role=context.role,
            user_name=context.user_name,
            timestamp=context.timestamp,
            source=context.source,
        )


__all__ = ["NotionFactSubscriber"]
