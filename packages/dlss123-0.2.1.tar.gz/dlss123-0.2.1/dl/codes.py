
dl1 = """
DEEP NEURAL NETWORK MODEL
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow import keras

X=np.array([6,7,8,9,10], dtype=float)
y=3*X+2

model=keras.Sequential([keras.layers.Dense(1,input_shape=[1])])
model.compile(optimizer='adam',loss='mse')

print("Training the model...")
history=model.fit(X,y,epochs=500,verbose=0)

weights=model.layers[0].get_weights()
print("Learned Weight:", weights[0][0][0])
print("Learned Bias:", weights[1][0])
"""

dl2 = """
SPEECH TO TEXT
import speech_recognition as sr

recognizer = sr.Recognizer()
AUDIO_FILE = "audio.wav"

with sr.AudioFile(AUDIO_FILE) as source:
    audio = recognizer.listen(source)
    text = recognizer.recognize_google(audio)

print("Transcribed text:", text)
"""

dl3 = """
TEXT TO SPEECH
import pyttsx3

engine = pyttsx3.init()
engine.setProperty('rate',170)
engine.setProperty('volume',0.9)

text=input("Enter text: ")
engine.say(text)
engine.runAndWait()
"""

dl4 = """
TIME SERIES FORECASTING WITH LSTM
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
"""

dl5a = """
FEED FORWARD NEURAL NETWORK FOR LOGIC GATE
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

inputs=np.array([[0,0],[0,1],[1,0],[1,1]])
outputs=np.array([[0],[1],[1],[0]])

model=Sequential()
model.add(Dense(4,input_dim=2,activation='relu'))
model.add(Dense(1,activation='sigmoid'))
"""

dl6a = """
RGB TO GRAYSCALE
from skimage import data
from skimage.color import rgb2gray
import matplotlib.pyplot as plt

coffee=data.coffee()
gray_coffee=rgb2gray(coffee)

plt.imshow(gray_coffee,cmap="gray")
plt.show()
"""

dl7 = """
OBJECT DETECTION USING YOLO
from ultralytics import YOLO
import cv2

model=YOLO("yolov8n.pt")
results=model("nun.jpg")
"""

dl8 = """
CHARACTER RECOGNITION USING CNN (MNIST)
import tensorflow as tf
from tensorflow.keras import layers, models

(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
"""

dl9 = """
AUTOENCODER USING MNIST
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.datasets import mnist
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import Model
"""
