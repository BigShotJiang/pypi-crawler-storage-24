import sys
from colorama import Fore, init

init(autoreset=True)


# --- Custom Loggers ---
class YTFetchLogger:
    def debug(self, msg):
        message = [
            "Downloading item", "Resuming","Destination:",
            "already been downloaded",  "Finished downloading"
        ]
        clean_msg = msg.replace("[download] ", "")

        if any(phrase in msg for phrase in message):
            print(f"{Fore.LIGHTBLACK_EX}{clean_msg}")

        if "Downloading playlist:" in msg:
            print(clean_msg)

        if "Merging formats" in msg:
            print(msg.replace("[Merger] ", ""))

    def info(self, msg):
        pass

    def warning(self, msg):
        if "Some web client https formats have been skipped" in msg:
            return
        print(f"\n{Fore.LIGHTBLACK_EX}{msg}")

    def error(self, msg):
        print(f"\n{msg}")

class ErrorOnlyLogger:
    def debug(self, msg): pass
    def info(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): print(msg)


# --- Custom Progress Hook ---
def progress_hook(d):
    if d['status'] == 'downloading':
        percent = d.get('_percent_str', '0.0%')
        total = d.get('_total_bytes_str', d.get('_total_bytes_estimate_str', 'N/A'))
        speed = d.get('_speed_str', 'N/A')
        status = f"{percent} of {total} at {speed}"
        print(f"\r{status}", end="")
        sys.stdout.flush()
    elif d['status'] == 'finished':
        print()


# --- Error print ---
def print_error(msg):
    print(f"{Fore.RED}{msg}")