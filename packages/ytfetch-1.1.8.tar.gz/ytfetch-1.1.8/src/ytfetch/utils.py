import sys
from yt_dlp.options import create_parser
from .formatter import print_error


def parse_passthrough_args(args_list):
    """
    Parses unknown arguments using yt-dlp's internal parser.
    Returns a dictionary containing ONLY the options explicitly passed by the user.
    """
    parser = create_parser()
    try:
        parsed, _ = parser.parse_known_args(args_list)
    except Exception as e:
        print(e,end='')
        sys.exit(1)

    opts = vars(parsed) # convert to dict

    # Filter out defaults to return ONLY user-provided args
    # create a baseline parser to see what the defaults are
    base_parser = create_parser()
    base_parsed, _ = base_parser.parse_args([])
    base_opts = vars(base_parsed)

    # Build dictionary of only changed items
    final_opts = {}
    for key, value in opts.items():
        # Only keep the option if the user changed it from the default
        if base_opts[key] != value:
            final_opts[key] = value

    return final_opts


def validate_fetch_ranges(fetch_ranges, urls):
    if len(fetch_ranges) != len(urls):
        print_error(f"Error: Provided {len(fetch_ranges)} fetch ranges for {len(urls)} URLs.")
        sys.exit(1)


def format_selector(args):
    height = args.q.rstrip("p")

    if args.mp3 or args.audio:
        return "bestaudio"

    if args.avcmp3:
        return f"bestvideo[vcodec^=avc1][height<={height}]+bestaudio/best[vcodec^=avc1][height<={height}]"
    return f"bestvideo[height<={height}]+bestaudio/best[height<={height}]"