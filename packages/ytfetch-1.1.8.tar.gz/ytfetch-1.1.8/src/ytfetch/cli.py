import argparse


def parse_arguments():
    parser = argparse.ArgumentParser(
        usage = "ytfetch URL ... [OPTIONS] [yt-dlp OPTIONS] ",
        description="ytfetch: yt-dlp wrapper with flexible args.",
        epilog = "type yt-dlp -h for yt-dlp options \n"
        "Doc & issues: https://github.com/voidsnax/ytFetch",
        formatter_class=AlignedHelpFormatter,
        allow_abbrev=False
    )

    parser.add_argument("url", nargs="+", metavar="URL")
    parser.add_argument("-avcmp3", action="store_true",
                        help="Download video in AVC (h.264) & audio in mp3 format")
    parser.add_argument("-q", metavar="QUALITY",default="1080",
                        help="Video quality (e.g., 1080, 720). Default is 1080")
    parser.add_argument("-mp3", action="store_true",
                        help="Extract audio only as MP3")
    parser.add_argument("-audio", action="store_true",
                        help="Extract audio only (bestaudio)")
    parser.add_argument("-fetch", metavar="RANGE",nargs="+",
                        help="Alternate for --playlist-items. Single value applies globally\n"
                        "Multiple values must match number of playlist URLs provided")
    parser.add_argument("-list", metavar="NAME",nargs="?",const="default",
                        help="List playlist contents. Accepts values for searching across playlist")

    args, unknown_args = parser.parse_known_args()
    return args, unknown_args


class AlignedHelpFormatter(argparse.HelpFormatter):
    def __init__(self, *args, **kwargs):
        kwargs['max_help_position'] = 35  # default is 24
        super().__init__(*args, **kwargs)
    def _fill_text(self, text, width, indent):
        # Preserve newlines in Description and Epilog
        # splitlines(keepends=True) ensures not losing of double newlines
        return ''.join(indent + line for line in text.splitlines(keepends=True))

    def _split_lines(self, text, width):
        # Preserve newlines in help
        return text.splitlines()