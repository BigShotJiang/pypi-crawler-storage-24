import sys
import signal

signal.signal(signal.SIGINT, lambda x, y: sys.exit(0))

import subprocess
import yt_dlp
from colorama import Fore

from .cli import parse_arguments
from .utils import (
    parse_passthrough_args,
    validate_fetch_ranges,
    format_selector
    )
from .formatter import (
    YTFetchLogger,
    ErrorOnlyLogger,
    progress_hook,
    print_error
    )

signal.signal(signal.SIGINT, signal.default_int_handler)


def process_urls(custom_args, raw_ytdlp_args):
    urls = custom_args.url
    passthrough_opts = parse_passthrough_args(raw_ytdlp_args)

    ydl_opts = {
        'outtmpl': '%(title)s.%(ext)s',
        'logger': YTFetchLogger(),
        'progress_hooks': [progress_hook],
    }

    ydl_opts.update(passthrough_opts)

    # --- List ---
    if custom_args.list:
        base_cmd = [
            "yt-dlp",
            "--flat-playlist",
            "--print", "%(playlist_index)s - %(title)s"
        ]

        passthrough_args = [arg for arg in raw_ytdlp_args if arg not in urls]
        base_cmd.extend(passthrough_args)
        command = []

        ydl_opts['extract_flat'] = 'in_playlist'
        ydl_opts['logger'] = ErrorOnlyLogger()

        search_mode = False

        fetch_ranges = custom_args.fetch
        if fetch_ranges:
            if len(fetch_ranges) >1:
                validate_fetch_ranges(fetch_ranges,urls)
                for fetch_range in fetch_ranges:
                    command.append(base_cmd + [ "--playlist-items", fetch_range])
            else:
                command.append(base_cmd + ["--playlist-items", fetch_ranges[0]])
        else:
            command.append(base_cmd)

        # make sure command is a list of list
        if len(command) == 1 and len(urls) > 1:
            command = [cmd.copy() for cmd in [command[0]] * len(urls)]


        if custom_args.list != 'default':
            search_mode = True
            list_val = custom_args.list
            search_pattern = list_val.lower()
        for url, cmd in zip(urls, command):
            # currently for title fetching this is more reliable
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:  #type: ignore
                try:
                    info = ydl.extract_info(url, download=False)
                    if 'entries' not in info:
                        print(f"Single Video: {info.get('title')}")
                    else:
                        title = f"▶ Playlist: {info.get('title')}"
                        print(f"▶ Playlist: {Fore.CYAN}{info.get('title')}{Fore.RESET}")
                        print(f"{"-" * len(title)}")
                except Exception as e:
                    print(f"Error getting {url} title: {e}")
            try:
                cmd.append(url)
                # print(cmd)
                result = subprocess.run(cmd, capture_output=True, text=True)
                found_match = False
                for line in result.stdout.splitlines():
                    idx, title = line.split(" - ", 1)
                    video = f"{Fore.YELLOW}{idx}{Fore.RESET} - {title}"
                    if search_mode:
                        if search_pattern in line.lower():
                            found_match = True
                            print(video)
                    else:
                        print(video)
                if not found_match and search_mode:
                    print(f"No match found for {Fore.YELLOW}{search_pattern}{Fore.RESET}")
            except Exception as e:
                print_error(f"Error listing {url}: {e}")

        return

    # --- format selection ---
    ydl_opts['format'] = format_selector(custom_args)

    if custom_args.mp3:
        ydl_opts['postprocessors'] = [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }]

    elif custom_args.avcmp3:
        ydl_opts['merge_output_format'] = 'mp4'
        ydl_opts['postprocessor_args'] = {
            'ffmpeg': ['-c:v', 'copy', '-c:a', 'libmp3lame', '-b:a', '192k']
        }

    # --- Download ---
    def run_download(url, playlist_items=None):
        opts = ydl_opts.copy()
        if playlist_items:
            opts['playlist_items'] = playlist_items
        with yt_dlp.YoutubeDL(opts) as ydl:  #type:ignore
            try:
                ydl.download([url])
            except Exception as e:
                # print(f"Download error for {url}: {e}")
                pass

    fetch_ranges = custom_args.fetch
    if fetch_ranges:
        if len(fetch_ranges) == 1:
            for url in urls:
                run_download(url, fetch_ranges[0])
        else:
            validate_fetch_ranges(fetch_ranges,urls)
            for url, rng in zip(urls, fetch_ranges):
                run_download(url, rng)
    else:
        for url in urls:
            run_download(url)

def main():
    try:
        custom_args, ytdlp_args = parse_arguments()
        process_urls(custom_args, ytdlp_args)
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Process aborted by user{Fore.RESET}")
        sys.exit(1)
