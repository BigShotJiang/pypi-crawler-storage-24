from __future__ import annotations

import asyncio
import importlib.resources
import logging
import sys
from pathlib import Path
from typing import TYPE_CHECKING, TypedDict

import click

from ai.backend.logging import BraceStyleAdapter
from ai.backend.manager.errors.resource import ConfigurationLoadFailed

if TYPE_CHECKING:
    from .context import CLIContext

log = BraceStyleAdapter(logging.getLogger(__spec__.name))


class RevisionDump(TypedDict):
    down_revision: str | None
    revision: str
    is_head: bool
    is_branch_point: bool
    is_merge_point: bool
    doc: str


class RevisionHistory(TypedDict):
    manager_version: str
    revisions: list[RevisionDump]


@click.group()
def cli() -> None:
    pass


@cli.command()
@click.option(
    "-f",
    "--alembic-config",
    default="alembic.ini",
    metavar="PATH",
    help="The path to Alembic config file. [default: alembic.ini]",
)
@click.pass_obj
def show(_cli_ctx: CLIContext, alembic_config: str) -> None:
    """Show the current schema information."""
    from alembic.config import Config
    from alembic.runtime.migration import MigrationContext
    from alembic.script import ScriptDirectory
    from sqlalchemy.engine import Connection

    from ai.backend.manager.models.utils import create_async_engine

    def _get_current_rev_sync(connection: Connection) -> str | None:
        context = MigrationContext.configure(connection)
        return context.get_current_revision()

    async def _show(sa_url: str) -> None:
        engine = create_async_engine(sa_url)
        async with engine.begin() as connection:
            current_rev = await connection.run_sync(_get_current_rev_sync)
        script = ScriptDirectory.from_config(alembic_cfg)
        heads = script.get_heads()
        head_rev = heads[0] if len(heads) > 0 else None
        print(f"Current database revision: {current_rev}")
        print(f"The head revision of available migrations: {head_rev}")

    alembic_cfg = Config(alembic_config)
    sa_url = alembic_cfg.get_main_option("sqlalchemy.url")
    if sa_url is None:
        raise ConfigurationLoadFailed("sqlalchemy.url is not configured in alembic config")
    sa_url = sa_url.replace("postgresql://", "postgresql+asyncpg://")
    asyncio.run(_show(sa_url))


@cli.command()
@click.option(
    "-f",
    "--alembic-config",
    default="alembic.ini",
    type=click.Path(exists=True, dir_okay=False),
    metavar="PATH",
    help="The path to Alembic config file. [default: alembic.ini]",
)
@click.option(
    "--output",
    "-o",
    default="-",
    type=click.Path(dir_okay=False, writable=True),
    help="Output file path (default: stdout)",
)
@click.pass_obj
def dump_history(_cli_ctx: CLIContext, alembic_config: str, output: str) -> None:
    """Dump current alembic history in a serialiazable format."""
    from alembic.config import Config
    from alembic.script import ScriptDirectory

    from ai.backend.common.json import pretty_json_str
    from ai.backend.manager import __version__

    alembic_cfg = Config(alembic_config)
    script = ScriptDirectory.from_config(alembic_cfg)
    serialized_revisions = []

    for sc in script.walk_revisions(base="base", head="heads"):
        revision_dump = RevisionDump(
            down_revision=sc._format_down_revision() if sc.down_revision else None,
            revision=sc.revision,
            is_head=sc.is_head,
            is_branch_point=sc.is_branch_point,
            is_merge_point=sc.is_merge_point,
            doc=sc.doc,
        )
        serialized_revisions.append(revision_dump)

    dump = RevisionHistory(manager_version=__version__, revisions=serialized_revisions)

    if output == "-" or output is None:
        print(pretty_json_str(dump))
    else:
        with Path(output).open(mode="w") as fw:
            fw.write(pretty_json_str(dump))


@cli.command()
@click.argument("previous_version", type=str, metavar="VERSION")
@click.option(
    "-f",
    "--alembic-config",
    default="alembic.ini",
    type=click.Path(exists=True, dir_okay=False),
    metavar="PATH",
    help="The path to Alembic config file. [default: alembic.ini]",
)
@click.option(
    "--dry-run",
    default=False,
    is_flag=True,
    help="When specified, this command only informs of revisions unapplied without actually applying it to the database.",
)
@click.pass_obj
def apply_missing_revisions(
    _cli_ctx: CLIContext, previous_version: str, alembic_config: str, dry_run: bool
) -> None:
    """
    Compare current alembic revision paths with the given serialized
    alembic revision history and try to execute every missing revisions.
    """
    from alembic.config import Config
    from alembic.runtime.environment import EnvironmentContext
    from alembic.runtime.migration import MigrationStep
    from alembic.script import Script, ScriptDirectory

    from ai.backend.common.json import load_json

    with importlib.resources.as_file(
        importlib.resources.files("ai.backend.manager.models.alembic.revision_history")
    ) as f:
        try:
            with (f / f"{previous_version}.json").open() as fr:
                revision_history: RevisionHistory = load_json(fr.read())
        except FileNotFoundError:
            log.error(
                "Could not find revision history dump as of Backend.AI version {}. Make sure you have upgraded this Backend.AI cluster to very latest version of prior major release before initiating this major upgrade.",
                previous_version,
            )
            sys.exit(1)

    alembic_cfg = Config(alembic_config)
    script_directory = ScriptDirectory.from_config(alembic_cfg)
    revisions_to_apply: dict[str, Script] = {}

    for sc in script_directory.walk_revisions(base="base", head="heads"):
        revisions_to_apply[sc.revision] = sc

    for applied_revision in revision_history["revisions"]:
        del revisions_to_apply[applied_revision["revision"]]

    log.info("Applying following revisions:")
    scripts = list(revisions_to_apply.values())[::-1]

    for script_to_apply in scripts:
        log.info("    {}", str(script_to_apply))

    if not dry_run:
        with EnvironmentContext(
            alembic_cfg,
            script_directory,
            fn=lambda _rev, _con: [
                MigrationStep.upgrade_from_script(script_directory.revision_map, script_to_apply)
                for script_to_apply in scripts
            ],
            destination_rev=script_to_apply.revision,
        ):
            script_directory.run_env()


@cli.command()
@click.option(
    "-f",
    "--alembic-config",
    default="alembic.ini",
    type=click.Path(exists=True, dir_okay=False),
    metavar="PATH",
    help="The path to Alembic config file. [default: alembic.ini]",
)
@click.pass_obj
def oneshot(_cli_ctx: CLIContext, alembic_config: str) -> None:
    """
    Set up your database with one-shot schema migration instead of
    iterating over multiple revisions if there is no existing database.
    It uses alembic.ini to configure database connection.

    Reference: http://alembic.sqlalchemy.org/en/latest/cookbook.html
               #building-an-up-to-date-database-from-scratch
    """
    from alembic.config import Config
    from alembic.runtime.migration import MigrationContext
    from alembic.script import ScriptDirectory
    from sqlalchemy.engine import Connection, Engine

    from ai.backend.manager.models.base import ensure_all_tables_registered, metadata
    from ai.backend.manager.models.utils import create_async_engine

    ensure_all_tables_registered()

    def _get_current_rev_sync(connection: Connection) -> str | None:
        context = MigrationContext.configure(connection)
        return context.get_current_revision()

    def _create_all_sync(connection: Connection, engine: Engine) -> None:
        alembic_cfg.attributes["connection"] = connection
        metadata.create_all(engine, checkfirst=False)
        log.info("Stamping alembic version to head...")
        script = ScriptDirectory.from_config(alembic_cfg)
        heads = script.get_heads()
        if not heads:
            log.warning("No alembic migration heads found, skipping version stamping")
            return
        head_rev = heads[0]
        connection.exec_driver_sql("CREATE TABLE alembic_version (\nversion_num varchar(32)\n);")
        connection.exec_driver_sql(f"INSERT INTO alembic_version VALUES('{head_rev}')")

    async def _oneshot(sa_url: str) -> None:
        engine = create_async_engine(sa_url)
        async with engine.begin() as connection:
            await connection.exec_driver_sql('CREATE EXTENSION IF NOT EXISTS "uuid-ossp";')
            current_rev = await connection.run_sync(_get_current_rev_sync)
        if current_rev is None:
            # For a fresh clean database, create all from scratch.
            # (it will raise error if tables already exist.)
            log.info("Detected a fresh new database.")
            log.info("Creating tables...")
            async with engine.begin() as connection:
                await connection.run_sync(_create_all_sync, engine=engine.sync_engine)
            log.info(
                "If you don't need old migrations, delete them and set "
                '"down_revision" value in the earliest migration to "None".'
            )
        else:
            log.info(
                "Detected an existing database (current revision: {}).",
                current_rev,
            )
            log.info("Use 'alembic upgrade head' to apply pending migrations.")

    alembic_cfg = Config(alembic_config)
    sa_url = alembic_cfg.get_main_option("sqlalchemy.url")
    if sa_url is None:
        raise ConfigurationLoadFailed("sqlalchemy.url is not configured in alembic config")
    sa_url = sa_url.replace("postgresql://", "postgresql+asyncpg://")
    asyncio.run(_oneshot(sa_url))
