from __future__ import annotations

import asyncio
import functools
import inspect
import io
import itertools
import json
import logging
import numbers
import re
import time
import traceback
from collections import defaultdict
from collections.abc import (
    Awaitable,
    Callable,
    Generator,
    Hashable,
    Iterable,
    Mapping,
    MutableMapping,
)
from typing import (
    Annotated,
    Any,
    Concatenate,
    ParamSpec,
    Protocol,
    TypeAlias,
    TypeVar,
    cast,
)

import trafaret as t
import yaml
from aiohttp import web
from aiohttp.typedefs import Handler
from pydantic import Field, TypeAdapter, ValidationError

from ai.backend.common.api_handlers import BaseRequestModel, BaseResponseModel
from ai.backend.common.json import load_json
from ai.backend.logging import BraceStyleAdapter
from ai.backend.manager.errors.api import (
    DeprecatedAPI,
    InvalidAPIParameters,
    NotImplementedAPI,
)

log = BraceStyleAdapter(logging.getLogger(__spec__.name))

_rx_sitepkg_path = re.compile(r"^.+/site-packages/")


def method_placeholder(orig_method: str) -> Callable[[web.Request], Awaitable[web.Response]]:
    async def _handler(request: web.Request) -> web.Response:
        raise web.HTTPMethodNotAllowed(request.method, [orig_method])

    return _handler


P = ParamSpec("P")
TAnyResponse = TypeVar("TAnyResponse", bound=web.StreamResponse)


def check_api_params(
    checker: t.Trafaret,
    loads: Callable[[str], Any] | None = None,
    query_param_checker: t.Trafaret | None = None,
    request_examples: list[Any] | None = None,
) -> Callable[
    # We mark the arg for the validated param as Any because we cannot define a generic type of
    # Trafaret's return value.
    [Callable[Concatenate[web.Request, Any, P], Awaitable[TAnyResponse]]],
    Callable[Concatenate[web.Request, P], Awaitable[TAnyResponse]],
]:
    def wrap(
        handler: Callable[Concatenate[web.Request, Any, P], Awaitable[TAnyResponse]],
    ) -> Callable[Concatenate[web.Request, P], Awaitable[TAnyResponse]]:
        @functools.wraps(handler)
        async def wrapped(request: web.Request, *args: P.args, **kwargs: P.kwargs) -> TAnyResponse:
            orig_params: Any
            body: str = ""
            try:
                body_exists = request.can_read_body
                if body_exists and request.method not in ("GET", "HEAD"):
                    body = await request.text()
                    if request.content_type == "text/yaml":
                        orig_params = yaml.load(body, Loader=yaml.BaseLoader)
                    else:
                        orig_params = (loads or json.loads)(body)
                else:
                    orig_params = dict(request.query)
                stripped_params = orig_params.copy()
                log.debug("stripped raw params: {}", mask_sensitive_keys(stripped_params))
                checked_params = checker.check(stripped_params)
                if body_exists and query_param_checker is not None:
                    query_params = query_param_checker.check(request.query)
                    kwargs["query"] = query_params
            except (json.decoder.JSONDecodeError, yaml.YAMLError, yaml.MarkedYAMLError) as e:
                raise InvalidAPIParameters("Malformed body") from e
            except t.DataError as e:
                raise InvalidAPIParameters("Input validation error", extra_data=e.as_dict()) from e
            return await handler(request, checked_params, *args, **kwargs)

        set_handler_attr(wrapped, "request_scheme", checker)
        if request_examples:
            set_handler_attr(wrapped, "request_examples", request_examples)
        return cast(Callable[Concatenate[web.Request, P], Awaitable[TAnyResponse]], wrapped)

    return wrap


LegacyBaseRequestModel: TypeAlias = BaseRequestModel


class LegacyBaseResponseModel(BaseResponseModel):
    status: Annotated[int, Field(strict=True, exclude=True, ge=100, lt=600)] = 200


TParamModel = TypeVar("TParamModel", bound=LegacyBaseRequestModel, contravariant=True)
TQueryModel = TypeVar("TQueryModel", bound=LegacyBaseRequestModel)
TResponseModel = TypeVar("TResponseModel", bound=LegacyBaseResponseModel, covariant=True)

type TPydanticResponse[TResponseModel: LegacyBaseResponseModel] = (
    TResponseModel | list[TResponseModel]
)


class THandlerFuncWithoutParam[**P, TResponseModel: LegacyBaseResponseModel](Protocol):
    def __call__(
        self,
        request: web.Request,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> Awaitable[TPydanticResponse[TResponseModel] | web.StreamResponse]: ...


class THandlerFuncWithParam[
    **P,
    TParamModel: LegacyBaseRequestModel,
    TResponseModel: LegacyBaseResponseModel,
](Protocol):
    def __call__(
        self,
        request: web.Request,
        params: TParamModel,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> Awaitable[TPydanticResponse[TResponseModel] | web.StreamResponse]: ...


def ensure_stream_response_type[TResponseModel: LegacyBaseResponseModel](
    response: LegacyBaseResponseModel
    | BaseResponseModel
    | list[TResponseModel]
    | web.StreamResponse,
) -> web.StreamResponse:
    match response:
        case LegacyBaseResponseModel(status=status):
            return web.json_response(response.model_dump(mode="json"), status=status)
        case BaseResponseModel():
            return web.json_response(response.model_dump(mode="json"))
        case list():
            return web.json_response(TypeAdapter(type(response)).dump_python(response, mode="json"))
        case web.StreamResponse():
            return response
        case _:
            raise RuntimeError(f"Unsupported response type ({type(response).__mro__})")


def pydantic_response_api_handler[**P, TResponseModel: LegacyBaseResponseModel](
    handler: THandlerFuncWithoutParam[P, TResponseModel],
) -> Handler:
    """
    Only for API handlers which does not require request body.
    For handlers with params to consume use @pydantic_params_api_handler() or
    @check_api_params() decorator (only when request param is validated with trafaret).
    """

    @functools.wraps(handler)
    async def wrapped(
        request: web.Request, *args: P.args, **kwargs: P.kwargs
    ) -> web.StreamResponse:
        response = await handler(request, *args, **kwargs)
        return ensure_stream_response_type(response)

    return wrapped


def pydantic_params_api_handler[
    TParamModel: LegacyBaseRequestModel,
    TQueryModel: LegacyBaseRequestModel,
](
    checker: type[TParamModel],
    loads: Callable[[str], Any] | None = None,
    query_param_checker: type[TQueryModel] | None = None,
) -> Callable[[THandlerFuncWithParam[P, TParamModel, TResponseModel]], Handler]:
    def wrap(
        handler: THandlerFuncWithParam[P, TParamModel, TResponseModel],
    ) -> Handler:
        @functools.wraps(handler)
        async def wrapped(
            request: web.Request, *args: P.args, **kwargs: P.kwargs
        ) -> web.StreamResponse:
            orig_params: Any
            body: str = ""
            try:
                body_exists = request.can_read_body
                if body_exists:
                    body = await request.text()
                    if request.content_type == "text/yaml":
                        orig_params = yaml.load(body, Loader=yaml.BaseLoader)
                    else:
                        orig_params = (loads or json.loads)(body)
                else:
                    orig_params = dict(request.query)
                stripped_params = orig_params.copy()
                log.debug("stripped raw params: {}", mask_sensitive_keys(stripped_params))
                checked_params = checker.model_validate(stripped_params)
                if body_exists and query_param_checker is not None:
                    query_params = query_param_checker.model_validate(request.query)
                    kwargs["query"] = query_params
            except (json.decoder.JSONDecodeError, yaml.YAMLError, yaml.MarkedYAMLError) as e:
                raise InvalidAPIParameters("Malformed body") from e
            except ValidationError as ex:
                first_error = ex.errors()[0]
                # Format the first validation error as the message
                # The client may refer extra_data to access the full validation errors.
                metadata = {
                    "input": first_error["input"],
                }
                if loc := first_error["loc"]:
                    metadata["loc"] = loc[0]
                metadata_formatted_items = [
                    f"type={first_error['type']}",  # format as symbol
                    *(f"{k}={v!r}" for k, v in metadata.items()),
                ]
                msg = f"{first_error['msg']} [{', '.join(metadata_formatted_items)}]"
                # To reuse the json serialization provided by pydantic, we call ex.json() and re-parse it.
                raise InvalidAPIParameters(msg, extra_data=load_json(ex.json())) from ex
            result = await handler(request, checked_params, *args, **kwargs)
            return ensure_stream_response_type(result)

        set_handler_attr(wrapped, "request_scheme", checker)

        return wrapped

    return wrap


_danger_words = ["password", "passwd", "secret"]


def mask_sensitive_keys(data: Mapping[str, Any]) -> Mapping[str, Any]:
    """
    Returns a new cloned mapping by masking the values of
    sensitive keys with "***" from the given mapping.
    """
    sanitized = dict()
    for k, v in data.items():
        if any((w in k.lower()) for w in _danger_words):
            sanitized[k] = "***"
        else:
            sanitized[k] = v
    return sanitized


def trim_text(value: str, maxlen: int) -> str:
    if len(value) <= maxlen:
        return value
    return value[: maxlen - 3] + "..."


class _Infinity(numbers.Number):
    def __lt__(self, o: Any) -> bool:
        return False

    def __le__(self, o: Any) -> bool:
        return False

    def __gt__(self, o: Any) -> bool:
        return True

    def __ge__(self, o: Any) -> bool:
        return False

    def __float__(self) -> float:
        return float("inf")

    def __int__(self) -> int:
        return 0xFFFF_FFFF_FFFF_FFFF  # a practical 64-bit maximum

    def __hash__(self) -> int:
        return hash(self)


numbers.Number.register(_Infinity)
Infinity = _Infinity()


def prettify_traceback(exc: BaseException | None) -> str:
    # Make a compact stack trace string
    with io.StringIO() as buf:
        while exc is not None:
            print(f"Exception: {exc!r}", file=buf)
            if exc.__traceback__ is None:
                print("  (no traceback available)", file=buf)
            else:
                for frame in traceback.extract_tb(exc.__traceback__):
                    short_path = _rx_sitepkg_path.sub("<sitepkg>/", frame.filename)
                    print(f"  {short_path}:{frame.lineno} ({frame.name})", file=buf)
            exc = exc.__context__
        return f"Traceback:\n{buf.getvalue()}"


def catch_unexpected(
    log: Any, reraise_cancellation: bool = True, raven: Any = None
) -> Callable[..., Any]:
    def _wrap(func: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(func)
        async def _wrapped(*args: Any, **kwargs: Any) -> Any:
            try:
                return await func(*args, **kwargs)
            except asyncio.CancelledError:
                if reraise_cancellation:
                    raise
            except Exception:
                if raven:
                    raven.captureException()
                log.exception("unexpected error!")
                raise

        return _wrapped

    return _wrap


def set_handler_attr(func: Any, key: str, value: Any) -> None:
    attrs = getattr(func, "_backend_attrs", None)
    if attrs is None:
        attrs = {}
    attrs[key] = value
    func._backend_attrs = attrs


def get_handler_attr(request: web.Request, key: str, default: Any = None) -> Any:
    # When used in the aiohttp server-side codes, we should use
    # request.match_info.hanlder instead of handler passed to the middleware
    # functions because aiohttp wraps this original handler with functools.partial
    # multiple times to implement its internal middleware processing.
    attrs = getattr(request.match_info.handler, "_backend_attrs", None)
    if attrs is not None:
        return attrs.get(key, default)
    return default


async def not_impl_stub(_request: web.Request) -> web.Response:
    raise NotImplementedAPI


def deprecated_stub(msg: str) -> Callable[[web.Request], Awaitable[web.StreamResponse]]:
    async def deprecated_stub_impl(_request: web.Request) -> web.Response:
        raise DeprecatedAPI(extra_msg=msg)

    return deprecated_stub_impl


def chunked(iterable: Iterable[Any], n: int) -> Generator[tuple[Any, ...], None, None]:
    it = iter(iterable)
    while True:
        chunk = tuple(itertools.islice(it, n))
        if not chunk:
            return
        yield chunk


_burst_last_call: float = 0.0
_burst_times: MutableMapping[Hashable, float] = dict()
_burst_counts: MutableMapping[Hashable, int] = defaultdict(int)


async def call_non_bursty(
    key: Hashable,
    coro: Callable[[], Any],
    *,
    max_bursts: int = 64,
    max_idle: int | float = 100.0,
) -> Any:
    """
    Execute a coroutine once upon max_bursts bursty invocations or max_idle
    milliseconds after bursts smaller than max_bursts.
    """
    global _burst_last_call, _burst_times, _burst_counts
    if inspect.iscoroutine(coro):
        # Coroutine objects may not be called before garbage-collected
        # as this function throttles the frequency of invocation.
        # That will generate a bogus warning by the asyncio's debug facility.
        raise TypeError("You must pass coroutine function, not coroutine object.")
    now = time.monotonic()

    if now - _burst_last_call > 3.0:
        # garbage-collect keys
        cleaned_keys = []
        for k, tick in _burst_times.items():
            if now - tick > (max_idle / 1e3):
                cleaned_keys.append(k)
        for k in cleaned_keys:
            del _burst_times[k]
            _burst_counts.pop(k, None)

    last_called = _burst_times.get(key, 0)
    _burst_times[key] = now
    _burst_last_call = now
    invoke = False

    if now - last_called > (max_idle / 1e3):
        invoke = True
        _burst_counts.pop(key, None)
    else:
        _burst_counts[key] += 1
    if _burst_counts[key] >= max_bursts:
        invoke = True
        del _burst_counts[key]

    if invoke:
        if inspect.iscoroutinefunction(coro):
            return await coro()
        return coro()
    return None


class Singleton(type):
    _instances: MutableMapping[Any, Any] = {}

    def __call__(cls, *args: Any, **kwargs: Any) -> Any:
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]


class Undefined(metaclass=Singleton):
    pass


undefined = Undefined()
