import base64
import json

from e2a import E2AClient, InboundEmail


def _make_raw_email(subject="Hello", text="Hi there", html=None):
    """Build a minimal RFC 2822 message."""
    lines = [
        "From: alice@gmail.com",
        "To: bot@agent.example.com",
        f"Subject: {subject}",
        "MIME-Version: 1.0",
    ]
    if html:
        boundary = "boundary123"
        lines.append(f'Content-Type: multipart/alternative; boundary="{boundary}"')
        lines.append("")
        lines.append(f"--{boundary}")
        lines.append("Content-Type: text/plain; charset=utf-8")
        lines.append("")
        lines.append(text)
        lines.append(f"--{boundary}")
        lines.append("Content-Type: text/html; charset=utf-8")
        lines.append("")
        lines.append(html)
        lines.append(f"--{boundary}--")
    else:
        lines.append("Content-Type: text/plain; charset=utf-8")
        lines.append("")
        lines.append(text)
    return "\r\n".join(lines).encode()




def _make_webhook_body(raw_email: bytes, message_id="msg_123", conversation_id=None):
    data = {
        "message_id": message_id,
        "from": "alice@gmail.com",
        "to": "bot@agent.example.com",
        "raw_message": base64.b64encode(raw_email).decode(),
        "auth_headers": {
            "X-E2A-Auth-Verified": "true",
            "X-E2A-Auth-Sender": "alice@gmail.com",
            "X-E2A-Auth-Entity-Type": "human",
            "X-E2A-Auth-Domain-Check": "spf=pass dkim=pass",
            "X-E2A-Auth-Agent-Id": "",
            "X-E2A-Auth-Human-Id": "human_456",
        },
        "received_at": "2026-03-23T10:00:00Z",
    }
    if conversation_id:
        data["conversation_id"] = conversation_id
    return json.dumps(data).encode()




def _make_raw_email_with_attachment(
    subject="Hello", text="See attached", filename="test.pdf", content_type="application/pdf", file_data=b"fake-pdf-data",
):
    """Build an RFC 2822 multipart/mixed message with an attachment."""
    boundary = "mixed_boundary"
    encoded = base64.b64encode(file_data).decode()
    lines = [
        "From: alice@gmail.com",
        "To: bot@agent.example.com",
        f"Subject: {subject}",
        "MIME-Version: 1.0",
        f'Content-Type: multipart/mixed; boundary="{boundary}"',
        "",
        f"--{boundary}",
        "Content-Type: text/plain; charset=utf-8",
        "",
        text,
        f"--{boundary}",
        f"Content-Type: {content_type}",
        f'Content-Disposition: attachment; filename="{filename}"',
        "Content-Transfer-Encoding: base64",
        "",
        encoded,
        f"--{boundary}--",
    ]
    return "\r\n".join(lines).encode()


def test_receive_parses_email():
    raw = _make_raw_email(subject="Test Subject", text="Hello agent")
    body = _make_webhook_body(raw)
    client = E2AClient(api_key="e2a_test")
    email = client.parse(body)

    assert isinstance(email, InboundEmail)
    assert email.message_id == "msg_123"
    assert email.sender == "alice@gmail.com"
    assert email.recipient == "bot@agent.example.com"
    assert email.subject == "Test Subject"
    assert email.text_body == "Hello agent"
    assert email.html_body is None
    assert email.conversation_id is None
    assert email.is_verified is True
    assert email.auth.entity_type == "human"
    assert email.auth.human_id == "human_456"
    client.close()


def test_receive_multipart_email():
    raw = _make_raw_email(subject="Rich", text="Plain text", html="<p>HTML</p>")
    body = _make_webhook_body(raw)
    client = E2AClient(api_key="e2a_test")
    email = client.parse(body)

    assert email.text_body == "Plain text"
    assert email.html_body == "<p>HTML</p>"
    client.close()


def test_receive_with_conversation_id():
    raw = _make_raw_email()
    body = _make_webhook_body(raw, conversation_id="conv_abc")
    client = E2AClient(api_key="e2a_test")
    email = client.parse(body)

    assert email.conversation_id == "conv_abc"
    client.close()



def test_inbound_email_repr():
    raw = _make_raw_email(subject="Hello")
    body = _make_webhook_body(raw, conversation_id="conv_1")
    client = E2AClient(api_key="e2a_test")
    email = client.parse(body)

    r = repr(email)
    assert "msg_123" in r
    assert "alice@gmail.com" in r
    assert "Hello" in r
    assert "conv_1" in r
    client.close()


def test_receive_email_with_attachment():
    file_data = b"fake-pdf-content-here"
    raw = _make_raw_email_with_attachment(
        subject="Report",
        text="See attached report.",
        filename="report.pdf",
        content_type="application/pdf",
        file_data=file_data,
    )
    body = _make_webhook_body(raw)
    client = E2AClient(api_key="e2a_test")
    email = client.parse(body)

    assert email.text_body == "See attached report."
    assert len(email.attachments) == 1
    att = email.attachments[0]
    assert att.filename == "report.pdf"
    assert att.content_type == "application/pdf"
    assert att.data == file_data
    assert att.size == len(file_data)
    client.close()


def test_receive_email_no_attachments():
    raw = _make_raw_email(subject="Plain", text="No attachments here")
    body = _make_webhook_body(raw)
    client = E2AClient(api_key="e2a_test")
    email = client.parse(body)

    assert email.attachments == []
    client.close()


def test_receive_email_multiple_attachments():
    boundary = "multi_att"
    att1_data = base64.b64encode(b"file-one").decode()
    att2_data = base64.b64encode(b"file-two").decode()
    raw = "\r\n".join([
        "From: alice@gmail.com",
        "To: bot@agent.example.com",
        "Subject: Multi",
        "MIME-Version: 1.0",
        f'Content-Type: multipart/mixed; boundary="{boundary}"',
        "",
        f"--{boundary}",
        "Content-Type: text/plain; charset=utf-8",
        "",
        "Two files attached.",
        f"--{boundary}",
        "Content-Type: image/png",
        f'Content-Disposition: attachment; filename="photo.png"',
        "Content-Transfer-Encoding: base64",
        "",
        att1_data,
        f"--{boundary}",
        "Content-Type: application/zip",
        f'Content-Disposition: attachment; filename="archive.zip"',
        "Content-Transfer-Encoding: base64",
        "",
        att2_data,
        f"--{boundary}--",
    ]).encode()
    body = _make_webhook_body(raw)
    client = E2AClient(api_key="e2a_test")
    email = client.parse(body)

    assert len(email.attachments) == 2
    assert email.attachments[0].filename == "photo.png"
    assert email.attachments[0].content_type == "image/png"
    assert email.attachments[0].data == b"file-one"
    assert email.attachments[1].filename == "archive.zip"
    assert email.attachments[1].content_type == "application/zip"
    assert email.attachments[1].data == b"file-two"
    client.close()
