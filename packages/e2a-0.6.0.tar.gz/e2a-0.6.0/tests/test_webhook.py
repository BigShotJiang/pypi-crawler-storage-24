# Webhook signature tests removed — signing key has been removed.
# Auth headers (X-E2A-Auth-*) are verified server-side.
