from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING, Any, Optional

import httpx

from e2a.client import E2AError, _check_response, _serialize_attachments
from e2a.models import Attachment, MessageList, MessageSummary, SendResult

if TYPE_CHECKING:
    from e2a.handler import AsyncInboundEmail


class AsyncE2AClient:
    """Async client for the e2a API.

    Drop-in async replacement for :class:`E2AClient`. Use this in async
    frameworks like FastAPI to avoid blocking the event loop.

    .. code-block:: python

        from e2a import AsyncE2AClient

        client = AsyncE2AClient(api_key="e2a_...")

        @app.post("/webhook")
        async def webhook(request: Request):
            email = client.parse(await request.body())
            await email.reply("Got it!")
            return {"ok": True}

    Args:
        api_key: Your API key.
            Falls back to the ``E2A_API_KEY`` environment variable.
        base_url: e2a API base URL. Defaults to ``https://e2a.dev``.
        timeout: Request timeout in seconds. Defaults to 30.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://e2a.dev",
        timeout: float = 30,
    ) -> None:
        self.api_key = api_key or os.environ.get("E2A_API_KEY", "")
        self.base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    # ── Webhook parsing ──────────────────────────────────────────────

    def parse(self, body: bytes, headers: dict[str, str] | None = None) -> "AsyncInboundEmail":
        """Parse a webhook payload, returning an AsyncInboundEmail.

        This method is synchronous (no I/O needed for parsing).
        The returned email's ``.reply()`` method is async.

        Args:
            body: Raw request body bytes.
            headers: HTTP request headers (currently unused, reserved for future use).

        Returns:
            A parsed :class:`AsyncInboundEmail` with async ``.reply()``.
        """
        from e2a.handler import build_inbound_email_async

        data = json.loads(body)
        return build_inbound_email_async(data, headers or {}, self)

    # ── Polling methods ──────────────────────────────────────────────

    async def get_messages(
        self,
        status: str = "unread",
        limit: int = 50,
        after: str | None = None,
    ) -> MessageList:
        """Fetch messages for a poll-mode agent.

        Args:
            status: Filter by status — ``"unread"``, ``"read"``, or ``"all"``.
            limit: Maximum number of messages to return (1–100).
            after: Cursor for pagination (message ID to start after).

        Returns:
            A :class:`MessageList` with message summaries and pagination info.

        Raises:
            E2AError: If the API returns an error.
        """
        params: dict[str, str] = {"status": status, "limit": str(limit)}
        if after:
            params["after"] = after

        resp = await self._client.get("/api/messages", params=params)
        _check_response(resp)
        data = resp.json()
        messages = [
            MessageSummary(
                message_id=m["message_id"],
                conversation_id=m.get("conversation_id"),
                sender=m["from"],
                recipient=m["to"],
                subject=m.get("subject", ""),
                status=m.get("status", ""),
                created_at=m.get("created_at", ""),
            )
            for m in data.get("messages", [])
        ]
        return MessageList(messages=messages, has_more=data.get("has_more", False))

    async def get_message(self, message_id: str) -> "AsyncInboundEmail":
        """Fetch a single message with full content (marks it as read).

        Returns the same :class:`AsyncInboundEmail` object as ``parse()`` — so
        ``.reply()`` works identically whether you use push or poll mode.

        Args:
            message_id: The message ID to fetch.

        Returns:
            A parsed :class:`AsyncInboundEmail` with async ``.reply()``.

        Raises:
            E2AError: If the API returns an error.
        """
        from e2a.handler import build_inbound_email_async

        resp = await self._client.get(f"/api/messages/{message_id}")
        _check_response(resp)
        data = resp.json()
        return build_inbound_email_async(data, {}, self)

    # ── API methods ────────────────────────────────────────────────────

    async def reply(
        self,
        message_id: str,
        body: str,
        html_body: Optional[str] = None,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
    ) -> SendResult:
        """Reply to an inbound email.

        Args:
            message_id: The ``message_id`` from the webhook payload.
            body: Plain-text reply body.
            html_body: Optional HTML body for rich replies.
            conversation_id: Optional opaque ID for your conversation/thread.
            attachments: Optional list of :class:`Attachment` objects to include.

        Returns:
            A SendResult with status, message_id, and delivery method.

        Raises:
            E2AError: If the API returns an error.
        """
        payload: dict = {"body": body}
        if html_body:
            payload["html_body"] = html_body
        if conversation_id:
            payload["conversation_id"] = conversation_id
        serialized = _serialize_attachments(attachments)
        if serialized:
            payload["attachments"] = serialized

        resp = await self._client.post(f"/api/messages/{message_id}/reply", json=payload)
        _check_response(resp)
        data = resp.json()
        return SendResult(
            status=data["status"],
            message_id=data["message_id"],
            method=data["method"],
        )

    async def send(
        self,
        to: str,
        subject: str,
        body: str,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
    ) -> SendResult:
        """Send a new email.

        Args:
            to: Recipient email address.
            subject: Email subject.
            body: Email body.
            conversation_id: Optional opaque ID for your conversation/thread.
            attachments: Optional list of :class:`Attachment` objects to include.

        Returns:
            A SendResult with status, message_id, and delivery method.

        Raises:
            E2AError: If the API returns an error.
        """
        payload: dict = {"to": to, "subject": subject, "body": body}
        if conversation_id:
            payload["conversation_id"] = conversation_id
        serialized = _serialize_attachments(attachments)
        if serialized:
            payload["attachments"] = serialized

        resp = await self._client.post("/api/send", json=payload)
        _check_response(resp)
        data = resp.json()
        return SendResult(
            status=data["status"],
            message_id=data["message_id"],
            method=data["method"],
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> AsyncE2AClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
