from __future__ import annotations

from dataclasses import dataclass


@dataclass
class AuthHeaders:
    """Parsed e2a authentication headers from a webhook payload."""

    verified: bool
    sender: str
    entity_type: str  # "human" or "agent"
    domain_check: str
    agent_id: str
    human_id: str

    @classmethod
    def from_headers(cls, headers: dict[str, str]) -> AuthHeaders:
        return cls(
            verified=headers.get("X-E2A-Auth-Verified", "").lower() == "true",
            sender=headers.get("X-E2A-Auth-Sender", ""),
            entity_type=headers.get("X-E2A-Auth-Entity-Type", ""),
            domain_check=headers.get("X-E2A-Auth-Domain-Check", ""),
            agent_id=headers.get("X-E2A-Auth-Agent-Id", ""),
            human_id=headers.get("X-E2A-Auth-Human-Id", ""),
        )


@dataclass
class Attachment:
    """An email attachment.

    For inbound emails, attachments are automatically parsed from the raw
    MIME message. For outbound emails, create ``Attachment`` objects and
    pass them to ``send()`` or ``reply()``.

    Attributes:
        filename: Original filename (e.g. ``"report.pdf"``).
        content_type: MIME type (e.g. ``"application/pdf"``).
        data: Raw file bytes.
        size: File size in bytes.
    """

    filename: str
    content_type: str
    data: bytes
    size: int


@dataclass
class SendResult:
    """Result from sending an email or reply."""

    status: str
    message_id: str
    method: str  # "smtp" or "webhook"


@dataclass
class MessageSummary:
    """A message summary from the list endpoint (no body content)."""

    message_id: str
    conversation_id: str | None
    sender: str
    recipient: str
    subject: str
    status: str  # "unread" or "read"
    created_at: str


@dataclass
class MessageList:
    """Response from get_messages()."""

    messages: list[MessageSummary]
    has_more: bool
