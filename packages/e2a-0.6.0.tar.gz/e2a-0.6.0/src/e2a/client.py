from __future__ import annotations

import base64
import json
from typing import TYPE_CHECKING, Any, Optional

import os

import httpx

if TYPE_CHECKING:
    from e2a.handler import InboundEmail

from e2a.models import Attachment, MessageList, MessageSummary, SendResult


def _serialize_attachments(attachments: list[Attachment] | None) -> list[dict] | None:
    if not attachments:
        return None
    return [
        {
            "filename": att.filename,
            "content_type": att.content_type,
            "data": base64.b64encode(att.data).decode(),
        }
        for att in attachments
    ]


class E2AClient:
    """Client for the e2a API.

    Parse incoming webhook emails, reply, and send new emails.

    .. code-block:: python

        from e2a import E2AClient

        client = E2AClient(api_key="e2a_...")

        @app.post("/webhook")
        async def webhook(request: Request):
            email = client.parse(await request.body())
            email.reply("Got it!")
            return {"ok": True}

    Args:
        api_key: Your API key.
            Falls back to the ``E2A_API_KEY`` environment variable.
        base_url: e2a API base URL. Defaults to ``https://e2a.dev``.
        timeout: Request timeout in seconds. Defaults to 30.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://e2a.dev",
        timeout: float = 30,
    ) -> None:
        self.api_key = api_key or os.environ.get("E2A_API_KEY", "")
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    # ── Webhook parsing ──────────────────────────────────────────────

    def parse(self, body: bytes, headers: dict[str, str] | None = None) -> "InboundEmail":
        """Parse a webhook payload, returning an InboundEmail.

        .. code-block:: python

            @app.post("/webhook")
            async def webhook(request: Request):
                email = client.parse(await request.body())
                email.reply("Hello!")
                return {"ok": True}

        Args:
            body: Raw request body bytes.
            headers: HTTP request headers (currently unused, reserved for future use).

        Returns:
            A parsed :class:`InboundEmail` with ``.reply()`` bound to this client.
        """
        from e2a.handler import build_inbound_email

        data = json.loads(body)
        return build_inbound_email(data, headers or {}, self)

    # ── Polling methods ──────────────────────────────────────────────

    def get_messages(
        self,
        status: str = "unread",
        limit: int = 50,
        after: str | None = None,
    ) -> MessageList:
        """Fetch messages for a poll-mode agent.

        Args:
            status: Filter by status — ``"unread"``, ``"read"``, or ``"all"``.
            limit: Maximum number of messages to return (1–100).
            after: Cursor for pagination (message ID to start after).

        Returns:
            A :class:`MessageList` with message summaries and pagination info.

        Raises:
            E2AError: If the API returns an error.
        """
        params: dict[str, str] = {"status": status, "limit": str(limit)}
        if after:
            params["after"] = after

        resp = self._client.get("/api/messages", params=params)
        _check_response(resp)
        data = resp.json()
        messages = [
            MessageSummary(
                message_id=m["message_id"],
                conversation_id=m.get("conversation_id"),
                sender=m["from"],
                recipient=m["to"],
                subject=m.get("subject", ""),
                status=m.get("status", ""),
                created_at=m.get("created_at", ""),
            )
            for m in data.get("messages", [])
        ]
        return MessageList(messages=messages, has_more=data.get("has_more", False))

    def get_message(self, message_id: str) -> "InboundEmail":
        """Fetch a single message with full content (marks it as read).

        Returns the same :class:`InboundEmail` object as ``parse()`` — so
        ``.reply()`` works identically whether you use push or poll mode.

        Args:
            message_id: The message ID to fetch.

        Returns:
            A parsed :class:`InboundEmail` with ``.reply()`` bound to this client.

        Raises:
            E2AError: If the API returns an error.
        """
        from e2a.handler import build_inbound_email

        resp = self._client.get(f"/api/messages/{message_id}")
        _check_response(resp)
        data = resp.json()
        return build_inbound_email(data, {}, self)

    # ── API methods ────────────────────────────────────────────────────

    def reply(
        self,
        message_id: str,
        body: str,
        html_body: Optional[str] = None,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
    ) -> SendResult:
        """Reply to an inbound email.

        Args:
            message_id: The ``message_id`` from the webhook payload.
            body: Plain-text reply body.
            html_body: Optional HTML body for rich replies.
            conversation_id: Optional opaque ID for your conversation/thread.
                When provided, e2a stores a mapping so that follow-up emails
                in the same thread will include this ID in the webhook payload.
            attachments: Optional list of :class:`Attachment` objects to include.

        Returns:
            A SendResult with status, message_id, and delivery method.

        Raises:
            E2AError: If the API returns an error.
        """
        payload: dict = {"body": body}
        if html_body:
            payload["html_body"] = html_body
        if conversation_id:
            payload["conversation_id"] = conversation_id
        serialized = _serialize_attachments(attachments)
        if serialized:
            payload["attachments"] = serialized

        resp = self._client.post(f"/api/messages/{message_id}/reply", json=payload)
        _check_response(resp)
        data = resp.json()
        return SendResult(
            status=data["status"],
            message_id=data["message_id"],
            method=data["method"],
        )

    def send(
        self,
        to: str,
        subject: str,
        body: str,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
    ) -> SendResult:
        """Send a new email.

        Args:
            to: Recipient email address.
            subject: Email subject.
            body: Email body.
            conversation_id: Optional opaque ID for your conversation/thread.
                When provided, e2a stores a mapping so that replies to this
                email will include this ID in the webhook payload.
            attachments: Optional list of :class:`Attachment` objects to include.

        Returns:
            A SendResult with status, message_id, and delivery method.

        Raises:
            E2AError: If the API returns an error.
        """
        payload: dict = {"to": to, "subject": subject, "body": body}
        if conversation_id:
            payload["conversation_id"] = conversation_id
        serialized = _serialize_attachments(attachments)
        if serialized:
            payload["attachments"] = serialized

        resp = self._client.post("/api/send", json=payload)
        _check_response(resp)
        data = resp.json()
        return SendResult(
            status=data["status"],
            message_id=data["message_id"],
            method=data["method"],
        )


    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> E2AClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class E2AError(Exception):
    """Raised when the e2a API returns an error."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"e2a API error ({status_code}): {message}")



def _check_response(resp: httpx.Response) -> None:
    if resp.status_code >= 400:
        try:
            message = resp.text.strip()
        except Exception:
            message = f"HTTP {resp.status_code}"
        raise E2AError(resp.status_code, message)
