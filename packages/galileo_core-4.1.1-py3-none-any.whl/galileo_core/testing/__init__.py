"""Testing helpers and pytest plugin entrypoints for galileo-core."""
