"""
Jettask v2 自定义异常
"""


class JettaskException(Exception):
    """Jettask 基础异常"""
    pass


class TaskNotFoundError(JettaskException):
    """任务未找到异常"""

    def __init__(self, task_id: str):
        self.task_id = task_id
        super().__init__(f"Task {task_id} not found")


class TaskExecutionError(JettaskException):
    """任务执行异常"""

    def __init__(self, task_id: str, message: str):
        self.task_id = task_id
        super().__init__(f"Task {task_id} execution failed: {message}")


class WorkerNotFoundError(JettaskException):
    """Worker 未找到异常"""

    def __init__(self, worker_id: str):
        self.worker_id = worker_id
        super().__init__(f"Worker {worker_id} not found")


class ConfigurationError(JettaskException):
    """配置错误异常"""
    pass


class QueueError(JettaskException):
    """队列错误异常"""
    pass
