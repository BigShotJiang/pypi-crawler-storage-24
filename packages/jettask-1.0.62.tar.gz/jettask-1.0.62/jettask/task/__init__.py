"""
任务管理层

提供统一的任务路由和装饰器
"""

from .router import TaskRouter

__all__ = [
    'TaskRouter',
]
