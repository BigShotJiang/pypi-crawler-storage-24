"""Pydantic models for billing and subscriptions."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal, Self

from pydantic import BaseModel, Field, model_validator

# --- Pricing constants ---

MIN_SEATS = 3

PLAN_PRICES = {
    "starter": {"monthly": 900, "annual": 8600},  # cents: $9/mo, $86/yr
    "pro": {"monthly": 1900, "annual": 18200},  # cents: $19/mo, $182/yr
}

AI_OPS_PER_SEAT = 500  # included ops per seat per month on Pro
AI_OP_OVERAGE_CENTS = 8  # $0.08 per overage op

STARTER_MAX_REPOS = 10

# Operations that count as AI ops
AI_OP_TYPES = frozenset(
    {
        "pr_analysis",
        "doc_update_generation",
        "spec_coverage_scan",
        "slack_qa_response",
        "spec_generation_assist",
    }
)


class Plan(StrEnum):
    STARTER = "starter"
    PRO = "pro"
    ENTERPRISE = "enterprise"


class BillingCycle(StrEnum):
    MONTHLY = "monthly"
    ANNUAL = "annual"


class SubscriptionStatus(StrEnum):
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELED = "canceled"
    TRIALING = "trialing"


class Subscription(BaseModel):
    id: str
    org_login: str
    stripe_customer_id: str | None = None
    stripe_subscription_id: str | None = None
    plan: Plan
    billing_cycle: BillingCycle
    status: SubscriptionStatus = SubscriptionStatus.ACTIVE
    seat_count: int = Field(default=MIN_SEATS, ge=MIN_SEATS)
    current_period_start: datetime | None = None
    current_period_end: datetime | None = None
    trial_start: datetime | None = None
    trial_end: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    @property
    def is_trialing(self) -> bool:
        return self.status == SubscriptionStatus.TRIALING

    @property
    def ai_ops_included(self) -> int:
        """Total AI ops included for this billing period (Pro only)."""
        if self.plan != Plan.PRO:
            return 0
        return self.seat_count * AI_OPS_PER_SEAT

    @property
    def max_repos(self) -> int | None:
        """Max repos allowed. None means unlimited."""
        if self.plan == Plan.STARTER:
            return STARTER_MAX_REPOS
        return None


class CheckoutRequest(BaseModel):
    plan: Plan
    billing_cycle: BillingCycle = BillingCycle.MONTHLY
    seat_count: int = Field(default=MIN_SEATS, ge=MIN_SEATS)
    success_url: str
    cancel_url: str

    @model_validator(mode="after")
    def enterprise_not_checkable(self) -> Self:
        if self.plan == Plan.ENTERPRISE:
            raise ValueError("Enterprise plan requires contacting sales")
        return self


TeamSize = Literal["1-10", "11-50", "51-200", "200+"]


class EnterpriseContactRequest(BaseModel):
    name: str = Field(min_length=1)
    email: str
    company: str = Field(min_length=1)
    team_size: TeamSize
    message: str = ""
    honeypot: str = ""  # spam prevention — should be empty


class AnthropicKeyRequest(BaseModel):
    api_key: str = Field(min_length=10, repr=False)


class AnthropicKeyStatus(BaseModel):
    exists: bool
    suffix: str = ""
    status: str = "none"
    last_validated_at: datetime | None = None


class AiOpUsage(BaseModel):
    """AI operation usage for a billing period."""

    org_login: str
    period_start: datetime
    period_end: datetime
    ops_used: int = 0
    ops_included: int = 0

    @property
    def ops_remaining(self) -> int:
        return max(0, self.ops_included - self.ops_used)

    @property
    def overage_ops(self) -> int:
        return max(0, self.ops_used - self.ops_included)

    @property
    def overage_cost_cents(self) -> int:
        return self.overage_ops * AI_OP_OVERAGE_CENTS
