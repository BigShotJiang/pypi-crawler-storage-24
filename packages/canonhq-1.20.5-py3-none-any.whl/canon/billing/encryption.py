"""AES-256-GCM encryption for BYOK Anthropic API keys."""

from __future__ import annotations

import base64
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def validate_encryption_key(encryption_key: str) -> None:
    """Validate that the encryption key is a valid base64-encoded 256-bit key.

    Raises ValueError if the key is invalid.
    """
    _get_key(encryption_key)


def _get_key(encryption_key: str) -> bytes:
    """Decode the base64-encoded 256-bit encryption key."""
    raw = base64.b64decode(encryption_key)
    if len(raw) != 32:
        raise ValueError("BYOK encryption key must be 256 bits (32 bytes)")
    return raw


def encrypt_api_key(plaintext: str, encryption_key: str) -> bytes:
    """Encrypt an API key using AES-256-GCM.

    Returns nonce (12 bytes) || ciphertext as a single bytes value.
    """
    key = _get_key(encryption_key)
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    return nonce + ciphertext


def decrypt_api_key(encrypted: bytes, encryption_key: str) -> str:
    """Decrypt an API key encrypted with encrypt_api_key."""
    if len(encrypted) < 13:
        raise ValueError(
            f"Encrypted BYOK key data is too short ({len(encrypted)} bytes) — data may be corrupted"
        )
    key = _get_key(encryption_key)
    nonce = encrypted[:12]
    ciphertext = encrypted[12:]
    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(nonce, ciphertext, None)
    return plaintext.decode("utf-8")
