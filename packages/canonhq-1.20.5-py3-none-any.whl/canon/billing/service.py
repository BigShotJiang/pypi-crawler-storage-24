"""Billing business logic — checkout, webhooks, subscription management."""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime, timedelta

import asyncpg

from .encryption import decrypt_api_key, encrypt_api_key
from .models import (
    AI_OP_TYPES,
    AI_OPS_PER_SEAT,
    MIN_SEATS,
    AiOpUsage,
    AnthropicKeyStatus,
    BillingCycle,
    Plan,
    Subscription,
    SubscriptionStatus,
)
from .stripe_client import StripeClient

logger = logging.getLogger(__name__)

TRIAL_DAYS = 14


class BillingService:
    """Handles subscription lifecycle, seat counting, AI ops metering, and BYOK."""

    def __init__(
        self,
        pool: asyncpg.Pool,
        stripe_client: StripeClient,
        byok_encryption_key: str,
    ) -> None:
        if not byok_encryption_key:
            raise ValueError("byok_encryption_key is required for BillingService")
        # Validate key format at startup (fail fast)
        from .encryption import validate_encryption_key

        validate_encryption_key(byok_encryption_key)

        self._pool = pool
        self._stripe = stripe_client
        self._encryption_key = byok_encryption_key

    # --- Subscriptions ---

    async def get_subscription(self, org_login: str) -> Subscription | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM subscriptions WHERE org_login = $1", org_login)
        if row is None:
            return None
        return self._row_to_subscription(row)

    def _row_to_subscription(self, row: asyncpg.Record) -> Subscription:
        return Subscription(
            id=str(row["id"]),
            org_login=row["org_login"],
            stripe_customer_id=row["stripe_customer_id"],
            stripe_subscription_id=row["stripe_subscription_id"],
            plan=Plan(row["plan"]),
            billing_cycle=BillingCycle(row["billing_cycle"]),
            status=SubscriptionStatus(row["status"]),
            seat_count=row["seat_count"],
            current_period_start=row["current_period_start"],
            current_period_end=row["current_period_end"],
            trial_start=row["trial_start"],
            trial_end=row["trial_end"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    async def create_subscription(
        self,
        *,
        org_login: str,
        stripe_customer_id: str | None,
        stripe_subscription_id: str | None,
        plan: Plan,
        billing_cycle: BillingCycle,
        seat_count: int = MIN_SEATS,
        period_start: datetime | None = None,
        period_end: datetime | None = None,
        trial_start: datetime | None = None,
        trial_end: datetime | None = None,
    ) -> Subscription:
        seat_count = max(seat_count, MIN_SEATS)
        status = (
            SubscriptionStatus.TRIALING.value if trial_start else SubscriptionStatus.ACTIVE.value
        )
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO subscriptions (
                    org_login, stripe_customer_id, stripe_subscription_id,
                    plan, billing_cycle, seat_count, status,
                    current_period_start, current_period_end,
                    trial_start, trial_end
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
                ON CONFLICT (org_login) DO UPDATE SET
                    stripe_customer_id = EXCLUDED.stripe_customer_id,
                    stripe_subscription_id = EXCLUDED.stripe_subscription_id,
                    plan = EXCLUDED.plan,
                    billing_cycle = EXCLUDED.billing_cycle,
                    seat_count = EXCLUDED.seat_count,
                    status = EXCLUDED.status,
                    current_period_start = EXCLUDED.current_period_start,
                    current_period_end = EXCLUDED.current_period_end,
                    trial_start = EXCLUDED.trial_start,
                    trial_end = EXCLUDED.trial_end,
                    updated_at = now()
                RETURNING *
                """,
                org_login,
                stripe_customer_id,
                stripe_subscription_id,
                plan.value,
                billing_cycle.value,
                seat_count,
                status,
                period_start,
                period_end,
                trial_start,
                trial_end,
            )
        return self._row_to_subscription(row)

    async def start_trial(
        self,
        *,
        org_login: str,
        stripe_customer_id: str | None = None,
        stripe_subscription_id: str | None = None,
        seat_count: int = MIN_SEATS,
    ) -> Subscription:
        """Start a 14-day Pro trial for an org.

        TODO: Add a cron job or Stripe-managed trial to enforce expiry.
        Currently, trial_end is stored but nothing transitions the subscription
        to canceled/expired when the trial lapses without payment.
        """
        now = datetime.now(UTC)
        trial_end = now + timedelta(days=TRIAL_DAYS)
        return await self.create_subscription(
            org_login=org_login,
            stripe_customer_id=stripe_customer_id,
            stripe_subscription_id=stripe_subscription_id,
            plan=Plan.PRO,
            billing_cycle=BillingCycle.MONTHLY,
            seat_count=seat_count,
            trial_start=now,
            trial_end=trial_end,
            period_start=now,
            period_end=trial_end,
        )

    async def update_subscription_status(
        self, stripe_subscription_id: str, status: SubscriptionStatus
    ) -> None:
        if not stripe_subscription_id:
            logger.error("update_subscription_status called with empty subscription ID")
            return
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE subscriptions SET status = $1, updated_at = now()
                WHERE stripe_subscription_id = $2
                """,
                status.value,
                stripe_subscription_id,
            )
            if result == "UPDATE 0":
                logger.error(
                    "No subscription found for stripe_subscription_id=%s when setting status=%s",
                    stripe_subscription_id,
                    status.value,
                )

    async def update_seat_count(self, org_login: str, seat_count: int) -> None:
        seat_count = max(seat_count, MIN_SEATS)
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE subscriptions SET seat_count = $1, updated_at = now() WHERE org_login = $2",
                seat_count,
                org_login,
            )

    async def update_subscription_from_stripe(
        self, stripe_subscription_id: str, seat_count: int
    ) -> None:
        """Update seat count from Stripe subscription data."""
        seat_count = max(seat_count, MIN_SEATS)
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE subscriptions SET seat_count = $1, updated_at = now()
                WHERE stripe_subscription_id = $2
                """,
                seat_count,
                stripe_subscription_id,
            )

    async def update_subscription_period(
        self,
        stripe_subscription_id: str,
        period_start: datetime,
        period_end: datetime,
    ) -> None:
        """Sync billing period dates from a Stripe subscription event."""
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE subscriptions
                SET current_period_start = $1, current_period_end = $2, updated_at = now()
                WHERE stripe_subscription_id = $3
                """,
                period_start,
                period_end,
                stripe_subscription_id,
            )

    async def get_org_login_by_subscription(self, stripe_subscription_id: str) -> str | None:
        """Look up org_login from a Stripe subscription ID."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT org_login FROM subscriptions WHERE stripe_subscription_id = $1",
                stripe_subscription_id,
            )
        return row["org_login"] if row else None

    async def update_subscription_price(
        self, stripe_subscription_id: str, stripe_price_id: str
    ) -> None:
        """Update plan/cycle based on the Stripe Price ID.

        Looks up the price_id in the settings mapping to determine which
        plan and billing cycle it corresponds to.
        """
        result = self._stripe.plan_for_price_id(stripe_price_id)
        if not result:
            logger.warning(
                "Unknown Stripe price ID %s for subscription %s — skipping plan sync",
                stripe_price_id,
                stripe_subscription_id,
            )
            return
        plan = Plan(result[0])
        cycle = BillingCycle(result[1])
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE subscriptions SET plan = $1, billing_cycle = $2, updated_at = now()
                WHERE stripe_subscription_id = $3
                """,
                plan.value,
                cycle.value,
                stripe_subscription_id,
            )

    # --- Seat activity tracking ---

    async def record_seat_activity(
        self, org_login: str, user_login: str, activity_type: str
    ) -> None:
        """Record a user interaction for seat counting."""
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO seat_activity (org_login, user_login, activity_type)
                VALUES ($1, $2, $3)
                """,
                org_login,
                user_login,
                activity_type,
            )

    async def get_active_seat_count(
        self, org_login: str, period_start: datetime, period_end: datetime
    ) -> int:
        """Count distinct active users in a billing period."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT COUNT(DISTINCT user_login) AS cnt
                FROM seat_activity
                WHERE org_login = $1 AND recorded_at >= $2 AND recorded_at < $3
                """,
                org_login,
                period_start,
                period_end,
            )
        return row["cnt"] if row else 0

    # --- AI operation metering ---

    async def record_ai_op(
        self, org_login: str, op_type: str, user_login: str = "", repo: str = ""
    ) -> None:
        """Record an AI operation. Only valid AI_OP_TYPES are accepted."""
        if op_type not in AI_OP_TYPES:
            raise ValueError(f"Invalid AI op type: {op_type}")
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO ai_op_usage (org_login, op_type, user_login, repo)
                VALUES ($1, $2, $3, $4)
                """,
                org_login,
                op_type,
                user_login,
                repo,
            )

    async def get_ai_op_usage(
        self, org_login: str, period_start: datetime, period_end: datetime
    ) -> AiOpUsage:
        """Get AI op usage for a billing period."""
        sub = await self.get_subscription(org_login)
        ops_included = 0
        if sub and sub.plan == Plan.PRO:
            ops_included = sub.seat_count * AI_OPS_PER_SEAT

        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT COUNT(*) AS cnt FROM ai_op_usage
                WHERE org_login = $1 AND recorded_at >= $2 AND recorded_at < $3
                """,
                org_login,
                period_start,
                period_end,
            )
        ops_used = row["cnt"] if row else 0

        return AiOpUsage(
            org_login=org_login,
            period_start=period_start,
            period_end=period_end,
            ops_used=ops_used,
            ops_included=ops_included,
        )

    # --- Webhook event log ---

    async def claim_event(self, stripe_event_id: str, event_type: str) -> bool:
        """Atomically claim a Stripe event for processing.

        Returns True if this call claimed the event (proceed with processing),
        False if the event was already successfully processed (skip).

        Uses INSERT ... ON CONFLICT DO UPDATE with a WHERE guard so that:
        - New events: INSERT succeeds → process
        - Previously failed (status='processing'): UPDATE succeeds → retry
        - Already done (status='done'): WHERE excludes → skip
        """
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                """
                INSERT INTO billing_events (org_login, stripe_event_id, event_type, payload, status)
                VALUES ('', $1, $2, '{}'::jsonb, 'processing')
                ON CONFLICT (stripe_event_id) DO UPDATE SET processed_at = now()
                WHERE billing_events.status != 'done'
                """,
                stripe_event_id,
                event_type,
            )
            # INSERT 0 1 = new insert or retry of failed event; INSERT 0 0 = already done
            return result == "INSERT 0 1"

    async def record_billing_event(
        self, org_login: str, stripe_event_id: str, event_type: str, payload: dict
    ) -> None:
        """Mark an event as done with resolved org_login and full payload."""
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE billing_events
                SET org_login = $1, payload = $2::jsonb, status = 'done'
                WHERE stripe_event_id = $3
                """,
                org_login,
                json.dumps(payload),
                stripe_event_id,
            )

    # --- BYOK key management ---

    async def store_anthropic_key(self, org_login: str, api_key: str) -> None:
        encrypted = encrypt_api_key(api_key, self._encryption_key)
        suffix = api_key[-4:]
        now = datetime.now(UTC)
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO anthropic_keys (org_login, encrypted_key, key_suffix, last_validated_at)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (org_login) DO UPDATE SET
                    encrypted_key = EXCLUDED.encrypted_key,
                    key_suffix = EXCLUDED.key_suffix,
                    status = 'active',
                    last_validated_at = EXCLUDED.last_validated_at,
                    updated_at = now()
                """,
                org_login,
                encrypted,
                suffix,
                now,
            )

    async def get_anthropic_key(self, org_login: str) -> str | None:
        """Retrieve and decrypt the stored Anthropic key for an org."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT encrypted_key, status FROM anthropic_keys WHERE org_login = $1",
                org_login,
            )
        if row is None or row["status"] != "active":
            return None
        try:
            return decrypt_api_key(bytes(row["encrypted_key"]), self._encryption_key)
        except Exception:
            logger.error(
                "Failed to decrypt BYOK key for org %s — key may be corrupted or encryption key rotated",
                org_login,
                exc_info=True,
            )
            raise

    async def get_anthropic_key_status(self, org_login: str) -> AnthropicKeyStatus:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT key_suffix, status, last_validated_at FROM anthropic_keys WHERE org_login = $1",
                org_login,
            )
        if row is None:
            return AnthropicKeyStatus(exists=False)
        return AnthropicKeyStatus(
            exists=True,
            suffix=row["key_suffix"],
            status=row["status"],
            last_validated_at=row["last_validated_at"],
        )

    async def delete_anthropic_key(self, org_login: str) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute("DELETE FROM anthropic_keys WHERE org_login = $1", org_login)

    async def mark_anthropic_key_invalid(self, org_login: str) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE anthropic_keys SET status = 'invalid', updated_at = now() WHERE org_login = $1",
                org_login,
            )

    # --- Enterprise contacts ---

    async def save_enterprise_contact(
        self,
        *,
        name: str,
        email: str,
        company: str,
        team_size: str,
        message: str = "",
    ) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO enterprise_contacts (name, email, company, team_size, message)
                VALUES ($1, $2, $3, $4, $5)
                """,
                name,
                email,
                company,
                team_size,
                message,
            )
