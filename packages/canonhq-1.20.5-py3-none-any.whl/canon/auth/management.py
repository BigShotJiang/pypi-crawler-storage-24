"""Auth0 Management API client for querying user organization memberships."""

from __future__ import annotations

import logging
import time
from urllib.parse import quote

import httpx

logger = logging.getLogger(__name__)


class Auth0ManagementClient:
    """Client for the Auth0 Management API (machine-to-machine).

    Uses client credentials grant to obtain M2M tokens, then queries
    user organization memberships.  Requires the app to be authorized
    for the Management API with ``read:organizations`` scope in the
    Auth0 dashboard.
    """

    def __init__(
        self,
        *,
        domain: str,
        client_id: str,
        client_secret: str,
        http_client: httpx.AsyncClient,
    ) -> None:
        self._domain = domain
        self._client_id = client_id
        self._client_secret = client_secret
        self._http = http_client
        self._token: str = ""
        self._token_expires: float = 0

    async def _get_token(self) -> str:
        """Obtain an M2M access token via client credentials grant."""
        if self._token and time.time() < self._token_expires:
            return self._token

        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "audience": f"https://{self._domain}/api/v2/",
            },
        )
        resp.raise_for_status()
        data = resp.json()
        token = data.get("access_token")
        if not token:
            raise RuntimeError("Auth0 token response missing access_token")
        self._token = token
        # Auth0 returns expires_in (seconds); cache with a 60s buffer.
        self._token_expires = time.time() + data.get("expires_in", 86400) - 60
        return self._token

    async def get_user_organizations(self, user_id: str) -> list[dict]:
        """Return the Auth0 organizations a user belongs to.

        Args:
            user_id: The Auth0 ``sub`` claim (e.g. ``auth0|abc123``).

        Returns:
            List of org dicts with at least ``id`` and ``name`` keys.
        """
        token = await self._get_token()
        # Auth0 sub contains pipe chars (e.g. auth0|abc123) — percent-encode
        encoded_id = quote(user_id, safe="")
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/users/{encoded_id}/organizations",
            headers={"Authorization": f"Bearer {token}"},
            params={"per_page": "100"},
        )
        resp.raise_for_status()
        return resp.json()
