"""Spec Explorer web application."""
