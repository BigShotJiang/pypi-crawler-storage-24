class SignalLabsError(Exception):
    def __init__(self, code: str, message: str, error_type: str, upgrade_url: str = None, docs_url: str = None, **kwargs):
        super().__init__(message)
        self.code = code
        self.type = error_type
        self.upgrade_url = upgrade_url
        self.docs_url = docs_url
        for k, v in kwargs.items():
            setattr(self, k, v)
