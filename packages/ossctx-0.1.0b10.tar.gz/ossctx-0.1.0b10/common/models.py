"""Shared SQLAlchemy models for cross-subsystem data."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from common.db import Base


class CrossReference(Base):
    """Links entities across subsystems (code <-> docs <-> otel)."""

    __tablename__ = "cross_references"

    id: Mapped[int] = mapped_column(primary_key=True)
    source_type: Mapped[str] = mapped_column(String(32), index=True)  # "code", "docs", "otel"
    source_id: Mapped[str] = mapped_column(String(256), index=True)   # entity ID in source system
    source_name: Mapped[str] = mapped_column(String(512), index=True) # human-readable name
    target_type: Mapped[str] = mapped_column(String(32), index=True)
    target_id: Mapped[str] = mapped_column(String(256), index=True)
    target_name: Mapped[str] = mapped_column(String(512), index=True)
    link_type: Mapped[str] = mapped_column(String(64), index=True)    # "mentions", "implements", "monitors"
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
