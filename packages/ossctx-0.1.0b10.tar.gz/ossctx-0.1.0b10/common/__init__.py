"""Shared platform layer for ossctx."""

import warnings

# Suppress Pydantic V1 compatibility noise from langchain on Python 3.14+.
# This must run before langchain_core is imported anywhere.
warnings.filterwarnings(
    "ignore",
    message="Core Pydantic V1 functionality",
    category=UserWarning,
)
warnings.filterwarnings(
    "ignore",
    message=".*pydantic.v1.*",
    category=UserWarning,
)

from .version import __version__

__all__ = ["__version__"]
