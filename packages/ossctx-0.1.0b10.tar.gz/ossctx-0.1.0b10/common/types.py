"""Shared API schemas."""

from __future__ import annotations

from typing import Any, Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class HealthResponse(BaseModel):
    status: str
    version: str
    uptime_seconds: float = 0.0
    platform: str = ""
    python: str = ""


class ErrorResponse(BaseModel):
    error: str
    detail: str | None = None


class PaginatedResponse(BaseModel):
    """Generic paginated response wrapper."""
    items: list[Any]
    total: int
    offset: int
    limit: int

    @classmethod
    def build(cls, items: list, total: int, offset: int = 0, limit: int = 100) -> PaginatedResponse:
        return cls(items=items, total=total, offset=offset, limit=limit)
