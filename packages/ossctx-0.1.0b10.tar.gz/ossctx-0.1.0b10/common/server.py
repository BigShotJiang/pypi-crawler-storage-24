"""FastAPI app factory for all subsystems."""

from __future__ import annotations

import platform
import time
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from common.middleware import (
    add_cors,
    add_exception_handlers,
    add_rate_limiting,
    add_request_logging,
)
from common.types import HealthResponse

_start_time = time.time()


def create_app(
    title: str,
    version: str,
    cors_origins: list[str] | None = None,
    rate_limit: str | None = None,
) -> FastAPI:
    """Create a base app with shared middleware and health/version endpoint."""
    app = FastAPI(title=title, version=version, docs_url="/api/swagger", redoc_url="/api/redoc")

    add_exception_handlers(app)
    add_cors(app, origins=cors_origins)
    add_request_logging(app)
    if rate_limit:
        add_rate_limiting(app, default_limit=rate_limit)

    @app.get("/api/health")
    async def health() -> dict:
        return {
            "status": "ok",
            "version": version,
            "uptime_seconds": round(time.time() - _start_time, 1),
            "platform": platform.system(),
            "python": platform.python_version(),
        }

    return app


def mount_spa(app: FastAPI, dist_dir: Path, mount_path: str = "/") -> None:
    """Mount static assets and add SPA fallback when built assets are present."""
    index_path = dist_dir / "index.html"
    if not index_path.exists():
        return

    app.mount(mount_path, StaticFiles(directory=str(dist_dir), html=True), name="spa")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa_fallback(full_path: str) -> FileResponse:
        _ = full_path
        return FileResponse(index_path)
