"""Action framework configuration."""

from __future__ import annotations

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings


class ActionSettings(BaseSettings):
    """Settings for the action framework."""

    audit_log_path: Path = Field(default=Path(".action_audit.jsonl"), alias="ACTION_AUDIT_LOG")
    dry_run_default: bool = Field(default=True, alias="ACTION_DRY_RUN")
    max_log_entries: int = Field(default=10000, alias="ACTION_MAX_LOG_ENTRIES")
