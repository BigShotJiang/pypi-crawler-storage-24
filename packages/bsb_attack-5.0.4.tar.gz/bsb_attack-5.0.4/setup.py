from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="bsb-attack",
    version="5.0.4",
    author="Shawpon",
    author_email="githubshawpon@gmail.com",
    description="The world's most powerful multi‑vector load testing tool with real‑time stress bar and admin panel",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Shawpon2/bsb-attack",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "aiohttp>=3.8.0",
        "aiohttp-socks>=0.7.0",
        "colorama>=0.4.4",
        "tqdm>=4.64.0",
        "fake-useragent>=1.1.0",
        "pyyaml>=5.4",
        "websockets>=10.0",
        "scapy>=2.4.5",          # for low‑level floods (optional)
    ],
    entry_points={
        "console_scripts": [
            "bsb-attack = bsb_attack.cli:main",
            "bsb-admin = bsb_attack.admin:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Information Technology",
        "Topic :: Security",
    ],
    python_requires=">=3.7",
)
