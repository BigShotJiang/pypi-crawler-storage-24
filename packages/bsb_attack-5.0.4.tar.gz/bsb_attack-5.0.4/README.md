# bsb-attack
# 🔥 BSB Attack – The Ultimate Load Testing Tool

BSB Attack is the most advanced, multi‑vector load testing tool ever created. It combines **all known attack methods** to push your website to its absolute limit. A beautiful real‑time progress bar fills from 0% to 100% – when it reaches 100%, your site is down. The built‑in admin panel lets you manage users, monitor tests, and block abusers.

## ✨ Features
- **15+ attack methods simultaneously** – HTTP GET/POST, Slowloris, Slow Body, HTTP/2, Random Path, WebSocket, SSL renegotiation, Slow Read, Random Header, Range, DNS, ICMP, TCP SYN, UDP floods (where supported).
- **Smart stress calculation** – error rate + response time + connection failures.
- **Real‑time progress bar** – fills as stress increases. Hit 100% → site down.
- **Admin panel** – password `chandrima2020`. Manage users, view history, block/unblock, force‑stop tests, export to CSV.
- **Persistent configuration** – proxies, thresholds, and method counts editable in `~/.bsb-attack/config.json`.
- **User‑agent rotation** with fallback.
- **Proxy support** – SOCKS/HTTP for distributed testing.
- **Cross‑platform** – Windows, macOS, Linux.
- **Ethical warnings** – responsible use only.

## 📦 Installation
```bash
pip install bsb-attack
