#!/usr/bin/env python3
import sys
import argparse
import getpass
import time
import json
from threading import Thread
from colorama import Fore, Style, init
from tqdm import tqdm

from .models import init_db, get_user, add_user, start_test, end_test
from .core import LoadTester
from . import __version__

init(autoreset=True)

BANNER = f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════════╗
{Fore.CYAN}║         {Fore.YELLOW}BSB ATTACK – Ultimate Load Testing Tool{Fore.CYAN}           ║
{Fore.CYAN}║                    {Fore.GREEN}Version {__version__}{Fore.CYAN}                         ║
{Fore.CYAN}╚══════════════════════════════════════════════════════════╝
{Fore.RESET}
"""

DISCLAIMER = f"""
{Fore.RED}[!] WARNING: This tool is for authorized security testing only.
[!] Unauthorized use against websites you do not own is illegal.
[!] You are responsible for complying with all applicable laws.
{Fore.RESET}
"""

def main():
    parser = argparse.ArgumentParser(description="BSB Attack Load Tester")
    parser.add_argument("target", help="Target URL (e.g., example.com)")
    parser.add_argument("-c", "--concurrency", type=int, default=1000, help="Concurrent tasks")
    parser.add_argument("-d", "--duration", type=int, default=0, help="Test duration in seconds (0 = unlimited)")
    parser.add_argument("-m", "--methods", nargs="+", help="Attack methods to use (default: all)")
    parser.add_argument("-p", "--proxy", action="store_true", help="Use random proxies")
    parser.add_argument("-o", "--output", help="Save summary to file (JSON)")
    parser.add_argument("-q", "--quiet", action="store_true", help="Suppress banner and disclaimer")
    args = parser.parse_args()

    if not args.quiet:
        print(BANNER)
        print(DISCLAIMER)

    username = getpass.getuser()
    init_db()

    user = get_user(username)
    if user and user[1] == 1:
        print(f"{Fore.RED}You have been blocked by the administrator. Contact admin to unblock.{Fore.RESET}")
        print(f"{Fore.YELLOW}Admin contact: githubshawpon@gmail.com | FB: @shawpon.spshawpon{Fore.RESET}")
        sys.exit(1)

    add_user(username)
    user_id = get_user(username)[0]

    if not args.quiet:
        print(f"{Fore.YELLOW}Target: {args.target}")
        print(f"{Fore.YELLOW}Concurrency: {args.concurrency}")
        print(f"{Fore.YELLOW}Methods: {args.methods if args.methods else 'ALL'}")
        print(f"{Fore.YELLOW}Proxy mode: {'ON' if args.proxy else 'OFF'}")
        input(f"{Fore.GREEN}Press Enter to start load testing...{Fore.RESET}")

    test_id = start_test(user_id, args.target)
    tester = LoadTester(args.target, duration=args.duration, concurrency=args.concurrency,
                        methods=args.methods, proxy_mode=args.proxy)

    stop_progress = False
    def progress_updater():
        with tqdm(total=100, desc="Stress Level", bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}%", colour="RED", disable=args.quiet) as pbar:
            while not stop_progress and not tester.stop_event.is_set():
                percent = tester.get_stress_percent()
                pbar.n = percent
                pbar.refresh()
                if percent >= 100:
                    if not args.quiet:
                        print(f"\n{Fore.RED}[!] TARGET SITE IS DOWN! Stress level reached 100%.{Fore.RESET}")
                    tester.stop_event.set()
                    break
                if args.duration > 0 and (time.time() - tester.start_time) >= args.duration:
                    if not args.quiet:
                        print(f"\n{Fore.YELLOW}[!] Test duration completed.{Fore.RESET}")
                    tester.stop_event.set()
                    break
                time.sleep(1)

    attack_thread = Thread(target=tester.run, args=(test_id,))
    progress_thread = Thread(target=progress_updater)

    try:
        attack_thread.start()
        progress_thread.start()
        attack_thread.join()
    except KeyboardInterrupt:
        if not args.quiet:
            print(f"\n{Fore.YELLOW}[!] Test interrupted by user.{Fore.RESET}")
        tester.stop_event.set()
    finally:
        stop_progress = True
        progress_thread.join()

    stats = {
        'requests': tester.total_requests,
        'failures': tester.failures,
        'site_down': tester.get_stress_percent() >= 100,
        'duration': time.time() - tester.start_time,
        'max_stress': tester.get_stress_percent()
    }

    end_test(test_id, stats['requests'], stats['failures'],
             1 if stats['site_down'] else 0, stats['duration'], stats['max_stress'])

    if args.output:
        with open(args.output, 'w') as f:
            json.dump(stats, f, indent=4)

    if not args.quiet:
        print(f"\n{Fore.CYAN}╔════════════════════════════════════════╗")
        print(f"{Fore.CYAN}║           Test Summary                ║")
        print(f"{Fore.CYAN}╠════════════════════════════════════════╣")
        print(f"{Fore.CYAN}║ {Fore.WHITE}Total requests: {stats['requests']:<14}{Fore.CYAN} ║")
        print(f"{Fore.CYAN}║ {Fore.WHITE}Failed requests: {stats['failures']:<13}{Fore.CYAN} ║")
        print(f"{Fore.CYAN}║ {Fore.WHITE}Max stress: {stats['max_stress']}%{Fore.CYAN}                   ║")
        print(f"{Fore.CYAN}║ {Fore.WHITE}Site down: {str(stats['site_down']):<18}{Fore.CYAN} ║")
        print(f"{Fore.CYAN}║ {Fore.WHITE}Duration: {stats['duration']:.2f}s{Fore.CYAN}                 ║")
        print(f"{Fore.CYAN}╚════════════════════════════════════════╝{Fore.RESET}")

        print(f"\n{Fore.MAGENTA}--- Contact ---")
        print(f"Facebook: https://www.facebook.com/shawpon.spshawpon")
        print(f"Facebook Page: https://www.facebook.com/black.spammar.bd")
        print(f"GitHub: https://github.com/Shawpon2")
        print(f"Email: githubshawpon@gmail.com{Fore.RESET}")

if __name__ == "__main__":
    main()
