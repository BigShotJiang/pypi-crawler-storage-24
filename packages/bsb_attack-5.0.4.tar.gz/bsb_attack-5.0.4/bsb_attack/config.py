import json
from pathlib import Path

CONFIG_PATH = Path.home() / ".bsb-attack" / "config.json"

DEFAULT_CONFIG = {
    "proxies": [],
    "stress_threshold": 0.9,
    "response_time_threshold": 10.0,
    "method_task_counts": {
        "http_get": 1000,
        "http_post": 600,
        "random_path": 800,
        "slow_headers": 400,
        "slow_body": 400,
        "http2": 500,
        "websocket": 300,
        "ssl_reneg": 200,
        "slow_read": 300,
        "random_header": 400,
        "range_flood": 300,
        "dns_flood": 200,
        "icmp_flood": 100,
        "syn_flood": 100,
        "udp_flood": 100
    },
    "default_methods": [
        "http_get", "http_post", "random_path", "slow_headers", "slow_body",
        "http2", "websocket", "ssl_reneg", "slow_read", "random_header", "range_flood",
        "dns_flood", "icmp_flood", "syn_flood", "udp_flood"
    ],
    "request_timeout": 8,
    "follow_redirects": True
}

def load_config():
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            user_config = json.load(f)
            config = DEFAULT_CONFIG.copy()
            config.update(user_config)
            return config
    else:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_PATH, 'w') as f:
            json.dump(DEFAULT_CONFIG, f, indent=4)
        return DEFAULT_CONFIG

config = load_config()

PROXY_LIST = config["proxies"]
STRESS_THRESHOLD = config["stress_threshold"]
RESPONSE_TIME_THRESHOLD = config["response_time_threshold"]
METHOD_TASK_COUNTS = config["method_task_counts"]
DEFAULT_METHODS = config["default_methods"]
REQUEST_TIMEOUT = config["request_timeout"]
FOLLOW_REDIRECTS = config["follow_redirects"]
