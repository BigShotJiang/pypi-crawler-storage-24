import sqlite3
import time
import threading
from pathlib import Path

DB_PATH = Path.home() / ".bsb-attack" / "data.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

local = threading.local()

def get_conn():
    if not hasattr(local, 'conn'):
        local.conn = sqlite3.connect(DB_PATH, timeout=10)
        local.conn.execute("PRAGMA journal_mode=WAL")
        local.conn.execute("PRAGMA foreign_keys=ON")
    return local.conn

def init_db():
    conn = get_conn()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE,
                  created_at REAL,
                  is_blocked INTEGER DEFAULT 0)''')
    c.execute('''CREATE TABLE IF NOT EXISTS tests
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  target TEXT,
                  start_time REAL,
                  end_time REAL,
                  requests_sent INTEGER,
                  failures INTEGER,
                  site_down INTEGER,
                  duration REAL,
                  max_stress INTEGER,
                  status TEXT,
                  FOREIGN KEY(user_id) REFERENCES users(id))''')
    conn.commit()

def get_user(username):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT id, is_blocked FROM users WHERE username = ?", (username,))
    return c.fetchone()

def add_user(username):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users (username, created_at) VALUES (?, ?)",
              (username, time.time()))
    conn.commit()

def block_user(username):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET is_blocked = 1 WHERE username = ?", (username,))
    conn.commit()

def unblock_user(username):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET is_blocked = 0 WHERE username = ?", (username,))
    conn.commit()

def start_test(user_id, target):
    conn = get_conn()
    c = conn.cursor()
    c.execute('''INSERT INTO tests (user_id, target, start_time, status)
                 VALUES (?, ?, ?, ?)''', (user_id, target, time.time(), "running"))
    test_id = c.lastrowid
    conn.commit()
    return test_id

def end_test(test_id, requests_sent, failures, site_down, duration, max_stress, status="completed"):
    conn = get_conn()
    c = conn.cursor()
    c.execute('''UPDATE tests SET end_time=?, requests_sent=?, failures=?,
                 site_down=?, duration=?, max_stress=?, status=? WHERE id=?''',
              (time.time(), requests_sent, failures, site_down, duration, max_stress, status, test_id))
    conn.commit()

def get_all_users():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT username, created_at, is_blocked FROM users ORDER BY created_at DESC")
    return c.fetchall()

def get_active_users(within_seconds=300):
    cutoff = time.time() - within_seconds
    conn = get_conn()
    c = conn.cursor()
    c.execute('''SELECT DISTINCT u.username FROM users u
                 JOIN tests t ON u.id = t.user_id
                 WHERE t.start_time > ? AND t.status = 'running' ''', (cutoff,))
    return [r[0] for r in c.fetchall()]

def get_test_history(limit=50):
    conn = get_conn()
    c = conn.cursor()
    c.execute('''SELECT t.id, u.username, t.target, t.start_time, t.end_time,
                        t.requests_sent, t.failures, t.site_down, t.duration, t.max_stress, t.status
                 FROM tests t JOIN users u ON t.user_id = u.id
                 ORDER BY t.start_time DESC LIMIT ?''', (limit,))
    return c.fetchall()

def get_running_tests():
    conn = get_conn()
    c = conn.cursor()
    c.execute('''SELECT t.id, u.username, t.target, t.start_time
                 FROM tests t JOIN users u ON t.user_id = u.id
                 WHERE t.status = 'running' ''')
    return c.fetchall()

def stop_test(test_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE tests SET status='aborted', end_time=? WHERE id=? AND status='running'",
              (time.time(), test_id))
    conn.commit()
    return c.rowcount > 0
