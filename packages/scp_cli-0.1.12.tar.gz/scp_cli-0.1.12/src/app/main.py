from fastapi import FastAPI, Depends, Response
from fastapi.middleware.cors import CORSMiddleware
import os
from .api.routers import router
from .core.config import Settings
from .core.db import init_db, engine
from sqlmodel import Session, text
import time

# observability
import sentry_sdk

settings = Settings()
SENTRY_DSN = os.getenv("SENTRY_DSN", "")

# init Sentry if provided
if SENTRY_DSN:
    sentry_sdk.init(dsn=SENTRY_DSN, traces_sample_rate=0.1)

from contextlib import asynccontextmanager

import logging

logger = logging.getLogger(__name__)
logger.info("CORE API: FastAPI module loaded.")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Database ──
    init_db()

    # ── Redis connectivity probe (logged on every startup) ──
    redis_url = os.getenv("REDIS_URL", "")
    if not redis_url:
        logger.warning(
            "[startup] REDIS_URL is NOT SET — scanning queue will be disabled. "
            "Set REDIS_URL in the Render dashboard to enable background workers."
        )
    else:
        # Redact password for logging
        safe_url = redis_url
        if "@" in redis_url:
            parts = redis_url.rsplit("@", 1)
            scheme = parts[0].split("://")[0]
            safe_url = f"{scheme}://***@{parts[1]}"
        logger.info(f"[startup] REDIS_URL = {safe_url}")
        try:
            from redis import Redis as _Redis
            _conn = _Redis.from_url(
                redis_url,
                socket_connect_timeout=3,
                socket_timeout=3,
                **({"ssl_cert_reqs": None} if redis_url.startswith("rediss://") else {})
            )
            _conn.ping()
            logger.info("[startup] Redis ping OK — queue is reachable.")
            _conn.close()
        except Exception as exc:
            logger.error(
                f"[startup] Redis ping FAILED ({safe_url}): {exc}. "
                "Workers will NOT receive scan jobs until this is resolved."
            )
    yield

app = FastAPI(
    title="security-compliance-platform - scanner API",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Open to all origins; APIs are protected by JWT auth
    allow_credentials=False,  # Must be False when allow_origins=["*"]
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api/v1")


@app.get("/health")
def health(response: Response):
    """
    Advanced health check verifying Database and Redis connectivity.
    """
    status = {
        "status": "ok",
        "timestamp": time.time(),
        "services": {
            "database": "unknown",
            "redis": "unknown",
            "workers": "unknown"
        }
    }
    
    # 1. Check Database
    try:
        with Session(engine) as session:
            session.exec(text("SELECT 1"))
            status["services"]["database"] = "ok"
    except Exception as e:
        status["services"]["database"] = f"error: {str(e)}"
        status["status"] = "error"

    # 2. Check Redis & Workers
    try:
        from redis import Redis
        from rq import Worker, Queue
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
        conn = Redis.from_url(redis_url, socket_connect_timeout=1)
        
        if conn.ping():
            status["services"]["redis"] = "ok"
            # Check for active workers on 'scans' queue
            q = Queue("scans", connection=conn)
            workers = Worker.all(connection=conn)
            scans_workers = [w for w in workers if "scans" in w.queue_names()]
            status["services"]["workers"] = {
                "count": len(scans_workers),
                "status": "ok" if scans_workers else "no_workers_found"
            }
        else:
            status["services"]["redis"] = "failed_ping"
            status["status"] = "error"
    except Exception as e:
        status["services"]["redis"] = f"error: {str(e)}"
        # Redis failure is critical for scanning but maybe not for the whole API?
        # For now, mark as error to be safe.
        status["status"] = "error"

    if status["status"] != "ok":
        response.status_code = 503
        
    return status


