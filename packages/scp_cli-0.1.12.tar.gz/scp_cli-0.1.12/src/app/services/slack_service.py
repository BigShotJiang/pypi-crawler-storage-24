import requests
import logging
from typing import Optional
from ..core.config import Settings
from ..models import User

settings = Settings()
logger = logging.getLogger(__name__)

class SlackService:
    def __init__(self, webhook_url: Optional[str] = None, user: Optional[User] = None):
        if webhook_url:
            self.webhook_url = webhook_url
        elif user and user.slack_webhook_url:
            self.webhook_url = user.slack_webhook_url
        else:
            self.webhook_url = settings.slack_webhook_url

    def send_notification(self, message: str) -> bool:
        """
        Sends a notification to Slack via a webhook URL.
        """
        if not self.webhook_url:
            logger.warning("Slack notification skipped. SLACK_WEBHOOK_URL not configured.")
            return False

        try:
            payload = {"text": message}
            response = requests.post(self.webhook_url, json=payload)
            if response.status_code == 200:
                logger.info("Slack notification sent successfully.")
                return True
            else:
                logger.error(f"Failed to send Slack notification: {response.status_code} {response.text}")
                return False
        except Exception as e:
            logger.error(f"Exception while sending Slack notification: {str(e)}")
            return False

    def notify_pr_created(self, pr_url: str, finding_title: str, severity: str):
        """
        Sends a formatted notification about a new Pull Request.
        """
        message = (
            f"🚀 *New Pull Request Created for Security Fix*\n"
            f"*Finding:* {finding_title}\n"
            f"*Severity:* {severity}\n"
            f"*PR URL:* {pr_url}"
        )
        return self.send_notification(message)
