# Terrascout CLI

Geospatial data scoping from the terminal. Find the best satellite imagery and spatial datasets for your project — ranked, scored, and assessed for feasibility.

Powered by [Terrascout](http://130.162.194.71).

## Install

```bash
pip install terrascout
```

Requires Python 3.11+. No API key needed for free-tier features.

## Quick Start

```bash
# Check connectivity to Terrascout API
terrascout health

# Create a scope from a natural language brief
terrascout scope new "Monitor vegetation on a 500ha mine site near Emerald QLD, monthly for 12 months"

# View results for a scope
terrascout scope view <scope_id>

# Download a PDF compliance report
terrascout scope report <scope_id> --output report.pdf

# Compare recommendations side-by-side
terrascout scope compare <scope_id>
```

## Search

```bash
# Browse free satellite data providers
terrascout search providers --free-only

# Filter by resolution
terrascout search providers --resolution 10

# Search STAC catalogs for recent scenes
terrascout search stac --collection sentinel-2-l2a --bbox 144,-38,145,-37
```

## Projects

```bash
# List your project workspaces
terrascout project list

# Create a new project
terrascout project create "Mine Rehabilitation Monitoring"
```

## AI Agents

```bash
# List available AI agents
terrascout agents list

# Run an agent on a scope
terrascout agents run methodology_writer --scope <scope_id>
```

## Configuration

Config is stored at `~/.terrascout/config.yaml`:

```bash
# View current config
terrascout config show

# Point to a different API (e.g., local dev server)
terrascout config set api_url http://localhost:8000

# Point to production (default)
terrascout config set api_url http://130.162.194.71
```

## Authentication

```bash
terrascout auth login --email user@example.com
terrascout auth status
terrascout auth logout
```

Authentication is optional for core scoping features. Required for projects, agents, and alert subscriptions.

## Also Available

- **Web app**: [http://130.162.194.71](http://130.162.194.71)
- **MCP Server**: Connect Terrascout to Claude, Cursor, Windsurf, and other AI assistants
- **REST API**: Full OpenAPI docs at [/docs](http://130.162.194.71/docs)
