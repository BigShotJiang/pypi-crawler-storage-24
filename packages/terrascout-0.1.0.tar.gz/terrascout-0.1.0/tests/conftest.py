"""Shared fixtures for CLI tests."""

import pytest
from typer.testing import CliRunner

from terrascout_cli.main import app


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def cli_app():
    return app


@pytest.fixture(autouse=True)
def tmp_config(tmp_path, monkeypatch):
    """Redirect config to a temp directory so tests don't touch real ~/.terrascout."""
    config_dir = tmp_path / ".terrascout"
    config_dir.mkdir()
    monkeypatch.setattr("terrascout_cli.config.CONFIG_DIR", config_dir)
    monkeypatch.setattr("terrascout_cli.config.CONFIG_FILE", config_dir / "config.yaml")
