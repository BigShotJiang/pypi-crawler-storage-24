"""CLI tests — 20+ tests covering all command groups."""

from unittest.mock import MagicMock, patch

import httpx
import pytest
from typer.testing import CliRunner

from terrascout_cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_response(status_code: int = 200, json_data: dict | list | None = None, content: bytes = b"") -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    resp.text = str(json_data) if json_data else ""
    resp.content = content
    return resp


SAMPLE_SCOPE_RESPONSE = {
    "scope_id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    "parsed_brief": {
        "objective": "vegetation_monitoring",
        "aoi_description": "near Emerald QLD",
        "min_resolution_m": 10.0,
        "temporal_frequency": "weekly",
        "budget_aud": None,
        "timeframe_months": 12,
        "parse_method": "tier1_extraction",
        "overall_confidence": 0.85,
    },
    "recommendations": [
        {
            "rank": 1,
            "sensor_id": "11111111-2222-3333-4444-555555555555",
            "sensor_name": "MSI",
            "provider_name": "Copernicus / ESA",
            "sensor_type": "optical",
            "spatial_resolution_m": 10.0,
            "temporal_resolution_days": 5.0,
            "fit_score": 0.92,
            "feasibility_status": "feasible",
            "detection_confidence": "high",
            "strengths": ["Free data", "5-day revisit"],
            "limitations": ["Cloud cover in tropics"],
        },
        {
            "rank": 2,
            "sensor_id": "22222222-3333-4444-5555-666666666666",
            "sensor_name": "OLI-2",
            "provider_name": "USGS",
            "sensor_type": "optical",
            "spatial_resolution_m": 30.0,
            "temporal_resolution_days": 16.0,
            "fit_score": 0.65,
            "feasibility_status": "conditional",
            "detection_confidence": "medium",
            "strengths": ["Free data", "Long archive"],
            "limitations": ["30m resolution"],
        },
    ],
    "global_notes": ["No area of interest detected"],
}

SAMPLE_PROVIDERS = [
    {
        "name": "Copernicus / ESA",
        "short_name": "copernicus",
        "provider_type": "government",
        "sensors": [{"name": "MSI", "is_free": True}],
    },
    {
        "name": "USGS",
        "short_name": "usgs",
        "provider_type": "government",
        "sensors": [{"name": "OLI-2", "is_free": True}],
    },
]

SAMPLE_AGENTS = [
    {"slug": "methodology_writer", "name": "Methodology Writer", "description": "Drafts technical methodology", "min_tier": "free"},
    {"slug": "procurement_drafter", "name": "Procurement Drafter", "description": "Generates data acquisition emails", "min_tier": "pro"},
]


# ---------------------------------------------------------------------------
# 1. Version & Health
# ---------------------------------------------------------------------------

def test_version():
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


@patch("terrascout_cli.client.httpx.get")
def test_health_success(mock_get):
    mock_get.return_value = _mock_response(200, {"status": "healthy", "version": "0.1.0", "environment": "production"})
    result = runner.invoke(app, ["health"])
    assert result.exit_code == 0
    assert "healthy" in result.output


@patch("terrascout_cli.client.httpx.get")
def test_health_failure(mock_get):
    mock_get.side_effect = httpx.ConnectError("Connection refused")
    result = runner.invoke(app, ["health"])
    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# 2. Scope commands
# ---------------------------------------------------------------------------

@patch("terrascout_cli.client.httpx.post")
def test_scope_new(mock_post):
    mock_post.return_value = _mock_response(200, SAMPLE_SCOPE_RESPONSE)
    result = runner.invoke(app, ["scope", "new", "Monitor vegetation near Emerald QLD"])
    assert result.exit_code == 0
    assert "Scope created" in result.output
    assert "MSI" in result.output


@patch("terrascout_cli.client.httpx.post")
def test_scope_new_with_project(mock_post):
    mock_post.return_value = _mock_response(200, SAMPLE_SCOPE_RESPONSE)
    result = runner.invoke(app, ["scope", "new", "vegetation", "--project", "some-uuid"])
    assert result.exit_code == 0
    call_json = mock_post.call_args[1].get("json") or mock_post.call_args[0][1] if len(mock_post.call_args[0]) > 1 else mock_post.call_args[1].get("json")
    # Verify project_id was sent
    assert result.exit_code == 0


@patch("terrascout_cli.client.httpx.post")
def test_scope_new_api_error(mock_post):
    mock_post.return_value = _mock_response(500, {"detail": "Internal error"})
    result = runner.invoke(app, ["scope", "new", "test brief"])
    assert result.exit_code == 1
    assert "API error" in result.output


@patch("terrascout_cli.client.httpx.get")
def test_scope_view(mock_get):
    mock_get.return_value = _mock_response(200, SAMPLE_SCOPE_RESPONSE)
    result = runner.invoke(app, ["scope", "view", "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"])
    assert result.exit_code == 0
    assert "MSI" in result.output


@patch("terrascout_cli.client.httpx.get")
def test_scope_view_not_found(mock_get):
    mock_get.return_value = _mock_response(404)
    result = runner.invoke(app, ["scope", "view", "nonexistent-uuid"])
    assert result.exit_code == 1
    assert "not found" in result.output


@patch("terrascout_cli.client.httpx.get")
def test_scope_report(mock_get, tmp_path):
    pdf_bytes = b"%PDF-1.4 fake pdf content"
    mock_get.return_value = _mock_response(200, content=pdf_bytes)
    out_file = tmp_path / "test_report.pdf"
    result = runner.invoke(app, ["scope", "report", "some-uuid", "--output", str(out_file)])
    assert result.exit_code == 0
    assert "Report saved" in result.output
    assert out_file.read_bytes() == pdf_bytes


@patch("terrascout_cli.client.httpx.get")
def test_scope_compare(mock_get):
    mock_get.return_value = _mock_response(200, SAMPLE_SCOPE_RESPONSE)
    result = runner.invoke(app, ["scope", "compare", "some-uuid"])
    assert result.exit_code == 0
    assert "Comparison" in result.output
    assert "MSI" in result.output
    assert "OLI-2" in result.output


# ---------------------------------------------------------------------------
# 3. Search commands
# ---------------------------------------------------------------------------

@patch("terrascout_cli.client.httpx.get")
def test_search_providers(mock_get):
    mock_get.return_value = _mock_response(200, SAMPLE_PROVIDERS)
    result = runner.invoke(app, ["search", "providers"])
    assert result.exit_code == 0
    assert "Copernicus" in result.output


@patch("terrascout_cli.client.httpx.get")
def test_search_providers_with_filters(mock_get):
    mock_get.return_value = _mock_response(200, SAMPLE_PROVIDERS[:1])
    result = runner.invoke(app, ["search", "providers", "--resolution", "10", "--free"])
    assert result.exit_code == 0


@patch("terrascout_cli.client.httpx.get")
def test_search_stac(mock_get):
    stac_response = {
        "scenes": [
            {"scene_id": "S2A_20260101", "acquisition_date": "2026-01-01", "cloud_cover_pct": 12.5, "thumbnail_url": "https://example.com/thumb.png"},
        ]
    }
    mock_get.return_value = _mock_response(200, stac_response)
    result = runner.invoke(app, ["search", "stac", "-c", "sentinel-2", "-b", "144.5,-38.0,145.5,-37.0"])
    assert result.exit_code == 0
    assert "S2A_20260101" in result.output


def test_search_stac_invalid_bbox():
    result = runner.invoke(app, ["search", "stac", "-c", "sentinel-2", "-b", "invalid"])
    assert result.exit_code == 1
    assert "bbox" in result.output.lower()


# ---------------------------------------------------------------------------
# 4. Auth commands
# ---------------------------------------------------------------------------

@patch("httpx.post")
def test_auth_login_success(mock_post):
    mock_post.return_value = _mock_response(200, {"access_token": "jwt-token-123"})
    result = runner.invoke(app, ["auth", "login", "--email", "test@example.com", "--password", "secret123"])
    assert result.exit_code == 0
    assert "Logged in" in result.output


@patch("httpx.post")
def test_auth_login_invalid(mock_post):
    mock_post.return_value = _mock_response(401)
    result = runner.invoke(app, ["auth", "login", "--email", "test@example.com", "--password", "wrong"])
    assert result.exit_code == 1
    assert "Invalid" in result.output


def test_auth_logout():
    result = runner.invoke(app, ["auth", "logout"])
    assert result.exit_code == 0
    assert "Logged out" in result.output


def test_auth_status_not_logged_in():
    result = runner.invoke(app, ["auth", "status"])
    assert result.exit_code == 0
    assert "Not logged in" in result.output


# ---------------------------------------------------------------------------
# 5. Config commands
# ---------------------------------------------------------------------------

def test_config_show():
    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    assert "api_url" in result.output


def test_config_set():
    result = runner.invoke(app, ["config", "set", "api_url", "http://localhost:8000"])
    assert result.exit_code == 0
    assert "Set" in result.output


def test_config_set_invalid_key():
    result = runner.invoke(app, ["config", "set", "invalid_key", "value"])
    assert result.exit_code == 1
    assert "Unknown key" in result.output


# ---------------------------------------------------------------------------
# 6. Project commands
# ---------------------------------------------------------------------------

@patch("terrascout_cli.client.httpx.get")
def test_project_list(mock_get):
    projects = [
        {"id": "proj-1", "name": "Mine Site Alpha", "status": "active", "scope_count": 3, "created_at": "2026-01-15"},
    ]
    mock_get.return_value = _mock_response(200, projects)
    result = runner.invoke(app, ["project", "list"])
    assert result.exit_code == 0
    assert "Mine Site Alpha" in result.output


@patch("terrascout_cli.client.httpx.post")
def test_project_create(mock_post):
    mock_post.return_value = _mock_response(201, {"id": "new-proj", "name": "New Project"})
    result = runner.invoke(app, ["project", "create", "New Project", "--desc", "A test project"])
    assert result.exit_code == 0
    assert "Project created" in result.output


# ---------------------------------------------------------------------------
# 7. Agents commands
# ---------------------------------------------------------------------------

@patch("terrascout_cli.client.httpx.get")
def test_agents_list(mock_get):
    mock_get.return_value = _mock_response(200, SAMPLE_AGENTS)
    result = runner.invoke(app, ["agents", "list"])
    assert result.exit_code == 0
    assert "methodology_writer" in result.output


@patch("terrascout_cli.client.httpx.post")
def test_agents_run(mock_post):
    mock_post.return_value = _mock_response(200, {"output": "## Technical Methodology\nThis is the generated methodology."})
    result = runner.invoke(app, ["agents", "run", "methodology_writer", "--scope", "some-uuid"])
    assert result.exit_code == 0
    assert "Methodology" in result.output


# ---------------------------------------------------------------------------
# 8. Skills commands (stubs)
# ---------------------------------------------------------------------------

@patch("terrascout_cli.client.httpx.get")
def test_skills_list_not_deployed(mock_get):
    mock_get.return_value = _mock_response(404)
    result = runner.invoke(app, ["skills", "list"])
    assert result.exit_code == 0
    assert "not yet deployed" in result.output


# ---------------------------------------------------------------------------
# 9. Help output
# ---------------------------------------------------------------------------

def test_main_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "scope" in result.output
    assert "search" in result.output
    assert "auth" in result.output
    assert "config" in result.output
