"""HTTP API client — all backend communication goes through here."""

from typing import Any

import httpx

from terrascout_cli.config import get_api_url, get_token

TIMEOUT = 30.0


def _headers() -> dict[str, str]:
    headers: dict[str, str] = {"Accept": "application/json"}
    token = get_token()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _base() -> str:
    return get_api_url().rstrip("/")


def _url(path: str) -> str:
    return f"{_base()}/api/v1{path}"


def get(path: str, params: dict[str, Any] | None = None) -> httpx.Response:
    """GET request to the Terrascout API."""
    return httpx.get(_url(path), params=params, headers=_headers(), timeout=TIMEOUT)


def post(path: str, json: dict[str, Any] | None = None) -> httpx.Response:
    """POST request to the Terrascout API."""
    return httpx.post(_url(path), json=json, headers=_headers(), timeout=TIMEOUT)


def get_raw(path: str, params: dict[str, Any] | None = None) -> httpx.Response:
    """GET request returning raw bytes (for PDF downloads etc.)."""
    return httpx.get(
        _url(path),
        params=params,
        headers={**_headers(), "Accept": "application/pdf"},
        timeout=60.0,
    )


def health() -> dict[str, Any]:
    """Check API health."""
    resp = get("/health")
    resp.raise_for_status()
    return resp.json()
