"""Search commands — STAC catalogs and providers."""

from typing import Optional

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from terrascout_cli import client, output

app = typer.Typer(no_args_is_help=True)


@app.command("stac")
def search_stac(
    collection: str = typer.Option(..., "--collection", "-c", help="Sensor slug (e.g. sentinel-2)"),
    bbox: str = typer.Option(..., "--bbox", "-b", help="Bounding box: west,south,east,north"),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Date range: start/end (YYYY-MM-DD)"),
    limit: int = typer.Option(5, "--limit", "-n", help="Max results"),
) -> None:
    """Search STAC catalogs for satellite scenes."""
    params: dict = {"limit": limit}
    if date:
        params["date_range"] = date

    # Parse bbox
    try:
        parts = [float(x.strip()) for x in bbox.split(",")]
        if len(parts) != 4:
            raise ValueError
        params["west"], params["south"], params["east"], params["north"] = parts
    except (ValueError, TypeError):
        output.error("bbox must be 4 comma-separated numbers: west,south,east,north")
        raise typer.Exit(1)

    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Searching STAC for {collection}..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get(f"/preview/{collection}", params=params)

    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    scenes = data.get("scenes", [])
    if scenes:
        output.console.print(output.stac_results_table(scenes))
        output.info(f"{len(scenes)} scene(s) found")
    else:
        output.warning("No scenes found for the given criteria.")


@app.command("providers")
def search_providers(
    resolution: Optional[float] = typer.Option(None, "--resolution", "-r", help="Max resolution in meters"),
    provider_type: Optional[str] = typer.Option(None, "--type", "-t", help="Provider type filter"),
    free_only: bool = typer.Option(False, "--free-only", "--free", help="Show only free providers"),
) -> None:
    """Search the provider catalog."""
    params: dict = {}
    if resolution is not None:
        params["max_resolution_m"] = resolution
    if provider_type:
        params["provider_type"] = provider_type
    if free_only:
        params["free_only"] = True

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Searching providers..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/providers", params=params)

    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    providers = resp.json()
    if isinstance(providers, dict):
        providers = providers.get("providers", [])

    if providers:
        output.console.print(output.providers_table(providers))
        output.info(f"{len(providers)} provider(s)")
    else:
        output.warning("No providers match the criteria.")
