"""Skills commands — list, run (stub for future Skills Engine API)."""

import typer
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from terrascout_cli import client, output

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def skills_list() -> None:
    """List available skills."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading skills..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/skills")

    if resp.status_code == 404:
        output.warning("Skills engine not yet deployed. Coming in a future release.")
        return
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    skills = data if isinstance(data, list) else data.get("skills", [])

    if not skills:
        output.warning("No skills available.")
        return

    table = Table(title="Skills", border_style="cyan", show_lines=True)
    table.add_column("Name", style="bold white")
    table.add_column("Version", style="dim")
    table.add_column("Description")
    table.add_column("Tier", justify="center")

    for s in skills:
        table.add_row(
            s.get("name", ""),
            s.get("version", ""),
            s.get("description", "")[:60],
            s.get("tier", "free"),
        )

    output.console.print(table)


@app.command("run")
def skills_run(
    name: str = typer.Argument(help="Skill name"),
    params: list[str] = typer.Option([], "--param", "-p", help="Parameters as key=value pairs"),
) -> None:
    """Run a skill with parameters."""
    # Parse key=value params
    param_dict: dict = {}
    for p in params:
        if "=" not in p:
            output.error(f"Invalid param format: '{p}'. Use key=value.")
            raise typer.Exit(1)
        k, v = p.split("=", 1)
        param_dict[k] = v

    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Running skill '{name}'..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post(f"/skills/{name}/run", json={"params": param_dict})

    if resp.status_code == 404:
        output.warning("Skills engine not yet deployed. Coming in a future release.")
        return
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    output.console.print(Panel(
        str(data.get("result", data)),
        title=f"Skill: {name}",
        border_style="green",
    ))
