Simple Calculator Library

Functions:
add
subtract
multiply
divide

It calculate simple arithmetic operations, Add numbers, subracts, multiplies and divides digits