# Platypus-Music-Player



i made a music player.....

in python....



```python
import platypus_music_player as player
player.start()
```

Im gonna  make it just do python platypus_music_player or smth