from .main import main
import os
def clear_screen():
    
    if os.name == 'nt':
        
        os.system('cls')
    else:
        
        os.system('clear')
    
def start():
    clear_screen()
    """Launch the Platypus Music Player."""
    try:
        app = main()
        app.main_loop()
    except Exception as e:
        print(f"Error launching Platypus Player: {e}")