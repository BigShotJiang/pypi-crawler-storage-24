"""Setup script for MundiX CLI."""

from setuptools import setup

setup(
    name="mundix-cli",
    version="0.7.9",
    description="AI-Powered Cybersecurity Copilot for Kali Linux — Think Claude Code, but built for hackers.",
    long_description=open("README.md", encoding="utf-8").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="MundiX",
    author_email="contato@mundix.com.br",
    url="https://github.com/k0k4/mundix-cli",
    project_urls={
        "Homepage": "https://chat.mundix.dev",
        "Buy Credits": "https://chat.mundix.dev/billing",
        "Bug Tracker": "https://github.com/k0k4/mundix-cli/issues",
    },
    py_modules=[
        "mundix_cli",
        "ai_provider",
        "memory",
        "system_integrator",
        "autopilot",
        "playbooks",
        "project",
        "skill_loader",
        "agent_orchestrator",
    ],
    install_requires=[
        "openai>=1.0.0",
        "rich>=13.0.0",
        "prompt_toolkit>=3.0.0",
        "requests>=2.28.0",
        "packaging>=21.0",
        "pyyaml>=6.0",
    ],
    entry_points={
        "console_scripts": [
            "mundix=mundix_cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: POSIX :: Linux",
        "Environment :: Console",
    ],
    python_requires=">=3.8",
    keywords="cybersecurity pentesting kali-linux ai cli hacking red-team security copilot terminal",
)
