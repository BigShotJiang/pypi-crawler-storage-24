"""
prism-core: Cryptographic primitives for biometric template protection and key management.

Modules:
    prism.fuzzy   — Sample-then-Lock (STL) Fuzzy Extractor
    prism.keys    — HKDF hierarchical key derivation
    prism.vault   — AES-256-GCM authenticated encryption
    prism.limiter — Sliding-window rate limiter
"""

from prism.fuzzy import FuzzyExtractor
from prism.keys import KeyDerivationManager, generate_root_key
from prism.vault import AESVault
from prism.limiter import RateLimiter

__version__ = "1.0.0"

__all__ = [
    "FuzzyExtractor",
    "KeyDerivationManager",
    "generate_root_key",
    "AESVault",
    "RateLimiter",
]
