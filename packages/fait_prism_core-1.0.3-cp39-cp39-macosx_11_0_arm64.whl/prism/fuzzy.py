"""
Sample-then-Lock (STL) Fuzzy Extractor.

Locks and unlocks cryptographic secrets using noisy biometric feature vectors.
Uses a locker-based scheme where each locker samples a random subset of binarized
features to create a pad that masks the secret. Unlocking uses majority voting
across all lockers to recover the secret.

Accepts torch.Tensor or numpy.ndarray feature inputs.
"""

import secrets
import logging
import hashlib
import numpy as np
from collections import Counter
from typing import Union, Optional, Tuple

logger = logging.getLogger(__name__)

# Default STL parameters (tuned from live biometric testing)
DEFAULT_N_LOCKERS = 1024
DEFAULT_LOCKER_SIZE = 8
DEFAULT_PROB_THRESH = 0.2

# Type alias for feature inputs
FeatureInput = Union["torch.Tensor", np.ndarray]


def _to_numpy(feature: FeatureInput) -> np.ndarray:
    """Convert feature input to a flat numpy array."""
    try:
        import torch
        if isinstance(feature, torch.Tensor):
            return feature.detach().cpu().numpy().flatten()
    except ImportError:
        pass

    if isinstance(feature, np.ndarray):
        return feature.flatten()

    raise TypeError(f"Expected torch.Tensor or numpy.ndarray, got {type(feature)}")


class FuzzyExtractor:
    """
    Sample-then-Lock (STL) Fuzzy Extractor for biometric template protection.

    Locks a secret payload using a biometric feature vector. The same secret can
    be recovered from a similar (but not identical) feature vector, as long as
    the overlap exceeds the probability threshold.

    Args:
        n_lockers: Number of lockers (higher → more robust, slower). Default: 1024.
        locker_size: Bits sampled per locker (higher → stricter matching). Default: 8.
    """

    def __init__(self, n_lockers: int = DEFAULT_N_LOCKERS, locker_size: int = DEFAULT_LOCKER_SIZE):
        if n_lockers < 1:
            raise ValueError("n_lockers must be >= 1")
        if locker_size < 1:
            raise ValueError("locker_size must be >= 1")

        self.n_lockers = n_lockers
        self.locker_size = locker_size

    def _binarize(self, feature: FeatureInput) -> list:
        """Convert feature vector to a bit list using sign thresholding."""
        flat = _to_numpy(feature)
        return (flat > 0).astype(int).tolist()

    def lock_secret(self, feature: FeatureInput, secret_payload: bytes) -> dict:
        """
        Lock a secret using the feature vector.

        Args:
            feature: Biometric feature vector (torch.Tensor or numpy.ndarray).
            secret_payload: Secret bytes to lock (e.g., a 16-byte AES key).

        Returns:
            Helper data dict containing 'seed', 'lockers', 'secret_hash', 'n_features'.
            Store this alongside the enrollment record.
        """
        if not isinstance(secret_payload, bytes) or len(secret_payload) == 0:
            raise ValueError("secret_payload must be non-empty bytes")

        bits = self._binarize(feature)
        n_features = len(bits)

        if n_features < self.locker_size:
            raise ValueError(
                f"Feature vector too short ({n_features}) for locker_size ({self.locker_size})"
            )

        # Reproducible random indices from a secure seed
        locker_seed = secrets.token_bytes(4)
        seed_int = int.from_bytes(locker_seed, "big")
        rng = np.random.default_rng(seed_int)

        secret_hash = hashlib.sha256(secret_payload).digest()

        lockers = []
        for _ in range(self.n_lockers):
            indices = rng.choice(n_features, size=self.locker_size, replace=False)
            locker_bits = [bits[i] for i in indices]

            # Pad = H(bits) → XOR with secret
            bit_str = "".join(str(b) for b in locker_bits)
            pad_hash = hashlib.sha256(bit_str.encode()).digest()
            pad_needed = pad_hash[: len(secret_payload)]
            cipher = bytes([a ^ b for a, b in zip(secret_payload, pad_needed)])

            lockers.append(cipher.hex())

        return {
            "seed": locker_seed.hex(),
            "lockers": lockers,
            "secret_hash": secret_hash.hex(),
            "n_features": n_features,
        }

    def unlock_secret(
        self,
        feature: FeatureInput,
        helper_data: dict,
        prob_thresh: float = DEFAULT_PROB_THRESH,
    ) -> Tuple[Optional[bytes], dict]:
        """
        Attempt to unlock the secret using a probe feature vector.

        Args:
            feature: Probe biometric feature vector.
            helper_data: Helper data dict from lock_secret().
            prob_thresh: Minimum voting ratio to accept (0.0–1.0). Default: 0.2.

        Returns:
            Tuple of (secret_bytes_or_None, stats_dict).
            stats_dict contains 'ratio' — the fraction of lockers that agreed.
        """
        bits = self._binarize(feature)

        locker_seed = bytes.fromhex(helper_data["seed"])
        seed_int = int.from_bytes(locker_seed, "big")
        rng = np.random.default_rng(seed_int)

        stored_lockers = helper_data["lockers"]
        n_features = helper_data["n_features"]

        votes: Counter = Counter()

        for i in range(len(stored_lockers)):
            indices = rng.choice(n_features, size=self.locker_size, replace=False)
            locker_bits = [bits[j] for j in indices]

            bit_str = "".join(str(b) for b in locker_bits)
            pad_hash = hashlib.sha256(bit_str.encode()).digest()

            cipher = bytes.fromhex(stored_lockers[i])
            pad_needed = pad_hash[: len(cipher)]
            candidate = bytes([a ^ b for a, b in zip(cipher, pad_needed)])

            votes[candidate] += 1

        if not votes:
            return None, {"ratio": 0.0}

        best_candidate, count = votes.most_common(1)[0]
        ratio = count / self.n_lockers

        if ratio < prob_thresh:
            return None, {"ratio": ratio}

        # Verify hash integrity
        candidate_hash = hashlib.sha256(best_candidate).digest().hex()
        if candidate_hash == helper_data["secret_hash"]:
            return best_candidate, {"ratio": ratio}
        else:
            return None, {"ratio": ratio}
