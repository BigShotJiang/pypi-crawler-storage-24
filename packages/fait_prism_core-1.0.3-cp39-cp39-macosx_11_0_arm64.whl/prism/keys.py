"""
HKDF-based hierarchical key derivation manager.

Derives per-purpose, per-user, and per-node cryptographic keys from a single
root key using HKDF-SHA256. Supports Fernet symmetric encryption and
formatted key output for integration with external systems.

Key Hierarchy:
    ROOT_KEY (32 bytes, CSPRNG)
        ├── derive("context:A")        → Purpose-specific key
        ├── derive("context:B")        → Purpose-specific key
        ├── derive_for_node("ctx", id) → Per-node key (salt = node_id)
        └── derive_user_key("user_id") → Per-user encryption key
            └── get_user_fernet(id)    → Fernet cipher for user
"""

import os
import secrets
import logging
import base64
from pathlib import Path
from typing import Optional

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)


class KeyDerivationManager:
    """
    Manages a root key and derives all other keys using HKDF-SHA256.

    Args:
        key_source: Either a file path (str/Path) to a 32-byte root key file,
                    or raw 32-byte key material (bytes).
    """

    def __init__(self, key_source: "str | Path | bytes"):
        self._root_key: Optional[bytes] = None

        if isinstance(key_source, bytes):
            if len(key_source) != 32:
                raise ValueError(f"Root key must be 32 bytes, got {len(key_source)}")
            self._root_key = key_source
        else:
            self._key_path = Path(key_source)

    def __del__(self):
        """Best-effort cleanup: dereference root key from memory."""
        if self._root_key is not None:
            try:
                self._root_key = b"\x00" * len(self._root_key)
                del self._root_key
                self._root_key = None
            except Exception:
                pass

    def _load_root_key(self) -> bytes:
        """Load the root key from file (lazy, cached)."""
        if self._root_key is not None:
            return self._root_key

        if not self._key_path.exists():
            raise FileNotFoundError(
                f"Root key not found at {self._key_path}. "
                "Generate one with generate_root_key()."
            )

        with open(self._key_path, "rb") as f:
            self._root_key = f.read()

        if len(self._root_key) != 32:
            raise ValueError(
                f"Invalid root key: expected 32 bytes, got {len(self._root_key)}"
            )

        logger.debug("Loaded root key from %s", self._key_path)
        return self._root_key

    def derive(self, context: "str | bytes", length: int = 32, salt: Optional[bytes] = None) -> bytes:
        """
        Derive a key from the root key using HKDF-SHA256.

        Args:
            context: Purpose string (e.g., "myapp:wallet"). Encoded to UTF-8 if str.
            length: Derived key length in bytes. Default: 32.
            salt: Optional HKDF salt. Default: None (deterministic derivation).

        Returns:
            Derived key bytes.
        """
        root_key = self._load_root_key()
        info = context.encode("utf-8") if isinstance(context, str) else context

        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=length,
            salt=salt,
            info=info,
            backend=default_backend(),
        )
        return hkdf.derive(root_key)

    def derive_for_node(self, context: "str | bytes", node_id: str, length: int = 32) -> bytes:
        """
        Derive a per-node key using node_id as HKDF salt.

        Produces unique keys per node even when all nodes share the same root key.

        Args:
            context: Purpose string.
            node_id: Unique node identifier (used as salt).
            length: Derived key length in bytes.

        Returns:
            Node-specific derived key.
        """
        return self.derive(context, length=length, salt=node_id.encode("utf-8"))

    def derive_user_key(self, user_id: str, master_context: str = "master_seed") -> bytes:
        """
        Derive a per-user encryption key.

        Two-stage derivation: root → master_seed → user_key.

        Args:
            user_id: Unique user identifier (e.g., DID, email, UUID).
            master_context: Context string for the intermediate master seed.

        Returns:
            32-byte user-specific key.
        """
        master_seed = self.derive(master_context)

        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=user_id.encode("utf-8"),
            backend=default_backend(),
        )
        user_key = hkdf.derive(master_seed)

        # Best-effort cleanup of master_seed
        del master_seed

        return user_key

    def get_user_fernet(self, user_id: str) -> Fernet:
        """
        Get a Fernet cipher keyed to a specific user.

        Args:
            user_id: Unique user identifier.

        Returns:
            Fernet instance for encrypt/decrypt operations.
        """
        user_key = self.derive_user_key(user_id)
        fernet_key = base64.urlsafe_b64encode(user_key)
        return Fernet(fernet_key)

    def derive_formatted_key(self, context: str, fmt: str) -> str:
        """
        Derive a key and return it in a specific string format.

        Args:
            context: Purpose string for key derivation.
            fmt: Format string with a single {} placeholder for the hex key.
                 Example: "/key/swarm/psk/1.0.0/\\n/base16/\\n{}"

        Returns:
            Formatted key string.
        """
        key_bytes = self.derive(context)
        return fmt.format(key_bytes.hex())

    def clear_cached_key(self):
        """Clear the cached root key from memory."""
        if self._root_key is not None:
            self._root_key = b"\x00" * len(self._root_key)
            del self._root_key
            self._root_key = None


def generate_root_key(output_path: "str | Path | None" = None) -> bytes:
    """
    Generate a new 32-byte root key using CSPRNG.

    Args:
        output_path: If provided, writes the key to this file with
                     owner-only permissions (0o600).

    Returns:
        The generated 32-byte key.
    """
    key = secrets.token_bytes(32)

    if output_path is not None:
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        with open(output_file, "wb") as f:
            f.write(key)

        try:
            os.chmod(output_file, 0o600)
        except (OSError, AttributeError):
            logger.warning("Could not set restrictive permissions on key file")

        logger.info("Generated root key at %s", output_path)

    return key
