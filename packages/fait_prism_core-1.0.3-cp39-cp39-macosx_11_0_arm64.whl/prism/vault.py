"""
AES-256-GCM authenticated encryption vault.

Encrypts and decrypts numpy arrays or raw byte payloads with AES-GCM,
preserving array shape and dtype metadata for lossless roundtrips.
"""

import logging
import numpy as np
from typing import Optional, Union
from Crypto.Cipher import AES

logger = logging.getLogger(__name__)


class AESVault:
    """
    AES-256-GCM vault for encrypting sensitive payloads.

    Supports both numpy arrays (with shape/dtype preservation) and raw bytes.
    All outputs are hex-encoded dicts suitable for JSON serialization.
    """

    def encrypt(self, key: bytes, payload: Union[np.ndarray, bytes]) -> dict:
        """
        Encrypt a payload using AES-256-GCM.

        Args:
            key: 16, 24, or 32-byte AES key.
            payload: numpy array or raw bytes to encrypt.

        Returns:
            Dict with 'ciphertext', 'nonce', 'tag' (hex strings),
            plus 'shape' and 'dtype' if the input was a numpy array.
        """
        if isinstance(payload, np.ndarray):
            plaintext = payload.tobytes()
            metadata = {
                "shape": list(payload.shape),
                "dtype": str(payload.dtype),
            }
        elif isinstance(payload, bytes):
            plaintext = payload
            metadata = {}
        else:
            raise TypeError(f"Expected np.ndarray or bytes, got {type(payload)}")

        cipher = AES.new(key, AES.MODE_GCM)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext)

        result = {
            "ciphertext": ciphertext.hex(),
            "nonce": cipher.nonce.hex(),
            "tag": tag.hex(),
        }
        result.update(metadata)
        return result

    def decrypt(self, key: bytes, record: dict) -> Union[np.ndarray, bytes]:
        """
        Decrypt a vault record.

        Args:
            key: AES key (must match the key used for encryption).
            record: Dict from encrypt() containing ciphertext, nonce, tag.

        Returns:
            numpy array (if shape/dtype metadata present) or raw bytes.

        Raises:
            ValueError: If decryption fails (wrong key or tampered data).
        """
        try:
            ciphertext = bytes.fromhex(record["ciphertext"])
            nonce = bytes.fromhex(record["nonce"])
            tag = bytes.fromhex(record["tag"])

            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            plaintext = cipher.decrypt_and_verify(ciphertext, tag)

            # Reconstruct numpy array if metadata is present
            if "shape" in record and "dtype" in record:
                dtype = np.dtype(record["dtype"])
                shape = tuple(record["shape"])
                return np.frombuffer(plaintext, dtype=dtype).reshape(shape)

            return plaintext

        except (ValueError, KeyError) as e:
            logger.error(f"Decryption failed (tampering or wrong key): {e}")
            raise ValueError(f"Decryption failed: {e}") from e
