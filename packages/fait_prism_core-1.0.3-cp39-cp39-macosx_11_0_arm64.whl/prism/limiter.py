"""
Sliding-window rate limiter with soft/hard limits and auto-suspension.

Tracks event counts per key within a configurable time window. When the soft
limit is reached, a warning is logged. When the hard limit is reached, the key
is suspended and an optional callback is invoked.

Zero external dependencies beyond the Python standard library.
"""

import time
import logging
from collections import defaultdict
from typing import Optional, Callable, Tuple

logger = logging.getLogger(__name__)


class RateLimiter:
    """
    In-memory sliding-window rate limiter.

    Args:
        soft_limit: Events per window before warning. Default: 5.
        hard_limit: Events per window before suspension. Default: 10.
        window_seconds: Time window in seconds. Default: 60.
        suspend_callback: Optional function called with (key: str) when
                          the hard limit is exceeded.
    """

    def __init__(
        self,
        soft_limit: int = 5,
        hard_limit: int = 10,
        window_seconds: int = 60,
        suspend_callback: Optional[Callable[[str], None]] = None,
    ):
        if soft_limit > hard_limit:
            raise ValueError("soft_limit must be <= hard_limit")

        self.soft_limit = soft_limit
        self.hard_limit = hard_limit
        self.window_seconds = window_seconds
        self.suspend_callback = suspend_callback

        self._history: dict[str, list[float]] = defaultdict(list)
        self._suspended: set[str] = set()

    def _clean(self, key: str) -> None:
        """Remove entries older than the window."""
        cutoff = time.time() - self.window_seconds
        self._history[key] = [ts for ts in self._history[key] if ts > cutoff]

    def check_and_record(self, key: str, skip_limit: bool = False) -> Tuple[bool, str]:
        """
        Check if an event is allowed and record it.

        Args:
            key: Identifier for the rate-limited entity (e.g., device address).
            skip_limit: If True, bypass rate limiting (for trusted entities).

        Returns:
            Tuple of (allowed: bool, message: str).
        """
        if skip_limit:
            return True, "Rate limit bypassed"

        if key in self._suspended:
            return False, "Suspended"

        self._clean(key)
        count = len(self._history[key])

        # Hard limit
        if count >= self.hard_limit:
            self._suspended.add(key)
            logger.warning(f"HARD LIMIT: {key} exceeded {self.hard_limit} events/window — suspended")

            if self.suspend_callback:
                try:
                    self.suspend_callback(key)
                except Exception as e:
                    logger.error(f"Suspend callback failed: {e}")

            return False, f"Rate limit exceeded ({count}/{self.hard_limit}). Suspended."

        # Soft limit
        if count >= self.soft_limit:
            logger.warning(f"SOFT LIMIT: {key} at {count}/{self.soft_limit} events/window")

        # Record
        self._history[key].append(time.time())
        return True, f"OK ({count + 1}/{self.hard_limit})"

    def get_count(self, key: str) -> int:
        """Get current event count for a key within the window."""
        self._clean(key)
        return len(self._history[key])

    def is_suspended(self, key: str) -> bool:
        """Check if a key is suspended."""
        return key in self._suspended

    def reinstate(self, key: str) -> None:
        """Reinstate a suspended key and clear its history."""
        self._suspended.discard(key)
        self._history[key].clear()
        logger.info(f"Reinstated: {key}")

    def reset(self, key: str) -> None:
        """Reset the event counter for a key without changing suspension status."""
        self._history[key].clear()
