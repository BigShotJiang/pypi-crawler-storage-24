# SPDX-License-Identifier: GPL-3.0-or-later
"""
Command-line interface for Local AI Agent Orchestrator.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import yaml

from local_ai_agent_orchestrator.settings import init_settings
from local_ai_agent_orchestrator.state import TaskQueue


def _default_config_path(cwd: Path) -> Path | None:
    for name in ("factory.yaml", "factory.yml"):
        p = cwd / name
        if p.is_file():
            return p
    return None


def _write_example_config(dest: Path) -> None:
    example = {
        "lm_studio_base_url": "http://127.0.0.1:1234",
        "openai_api_key": "lm-studio",
        "total_ram_gb": 36,
        "paths": {
            "plans": "./plans",
            "database": "./.lao/state.db",
        },
        "memory_gate": {
            "release_fraction": 0.75,
            "swap_growth_limit_mb": 512,
            "settle_timeout_s": 60,
            "poll_interval_s": 2,
        },
        "orchestration": {
            "model_load_timeout_s": 180,
            "max_task_attempts": 3,
            "plan_watch_interval_s": 10,
            "llm_request_timeout_s": 300,
            "llm_retry_attempts": 3,
            "llm_retry_backoff_base_s": 5,
        },
        "git": {
            "enabled": True,
            "plan_file_name": "LAO_PLAN.md",
            "commit_trailers": False,
        },
        "models": {
            "planner": {
                "key": "qwen_qwen3.5-35b-a3b",
                "context_length": 32768,
                "max_completion": 16384,
                "supports_tools": True,
                "size_bytes": 21513639040,
                "description": "Architect / planner",
            },
            "coder": {
                "key": "qwen/qwen3-coder-30b",
                "context_length": 16384,
                "max_completion": 4096,
                "supports_tools": True,
                "size_bytes": 17190972664,
                "description": "Coder",
            },
            "reviewer": {
                "key": "mlx-community/DeepSeek-R1-Distill-Qwen-32B-4bit",
                "context_length": 8192,
                "max_completion": 2048,
                "supports_tools": False,
                "size_bytes": 18500000000,
                "description": "Reviewer (MLX 4-bit R1 distill)",
            },
            "embedder": {
                "key": "text-embedding-nomic-embed-text-v1.5",
                "context_length": 2048,
                "max_completion": 0,
                "supports_tools": False,
                "size_bytes": 84106624,
                "description": "Embeddings for semantic search",
            },
        },
    }
    dest.parent.mkdir(parents=True, exist_ok=True)
    with open(dest, "w", encoding="utf-8") as f:
        yaml.dump(example, f, default_flow_style=False, sort_keys=False)
    print(f"Wrote example configuration: {dest}")


def main(argv: list[str] | None = None) -> None:
    argv = argv if argv is not None else sys.argv[1:]
    cwd = Path.cwd()

    parser = argparse.ArgumentParser(
        prog="lao",
        description="Local AI Agent Orchestrator -- LM Studio multi-agent coding pipeline",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Path to factory.yaml (default: ./factory.yaml if present)",
    )
    parser.add_argument(
        "--lm-studio-url",
        dest="lm_studio_base",
        default=os.getenv("LM_STUDIO_BASE_URL"),
        help="LM Studio base URL (overrides config / env)",
    )
    parser.add_argument(
        "--ram-gb",
        dest="total_ram_gb",
        type=float,
        default=None,
        help="Total system RAM in GB (logged / future tuning)",
    )
    parser.add_argument("--workspace", type=Path, default=None, help="Workspace root path")
    parser.add_argument("--plans-dir", type=Path, default=None, help="Plans directory")
    parser.add_argument("--db", type=Path, dest="db_path", default=None, help="SQLite database path")
    parser.add_argument("--planner-model", dest="planner_model", default=None)
    parser.add_argument("--coder-model", dest="coder_model", default=None)
    parser.add_argument("--reviewer-model", dest="reviewer_model", default=None)
    parser.add_argument("--embedder-model", dest="embedder_model", default=None)
    parser.add_argument(
        "--plan",
        type=str,
        default=None,
        help="Process a specific plan file (with run)",
    )
    parser.add_argument(
        "--single-run",
        action="store_true",
        help="Process queue once then exit",
    )
    parser.add_argument(
        "--plain",
        action="store_true",
        help="Classic scrolling log (no full-screen dashboard)",
    )
    parser.add_argument(
        "--no-git",
        action="store_true",
        help="Disable per-plan Git snapshots and phase commits (overrides factory.yaml)",
    )

    sub = parser.add_subparsers(dest="command", help="Command")

    sub.add_parser("run", help="Run orchestrator (default if no subcommand)")

    sub.add_parser("status", help="Show task queue status")
    sub.add_parser("health", help="Check LM Studio and models")
    sub.add_parser("reset-failed", help="Reset failed tasks to pending")
    init_p = sub.add_parser("init", help="Scaffold factory.example.yaml, .lao/, plans/")
    init_p.add_argument(
        "--skip-readme",
        action="store_true",
        help="Do not create README.md if missing",
    )
    init_p.add_argument(
        "--no-interactive",
        action="store_true",
        help="Skip welcome banner (for scripts)",
    )

    args = parser.parse_args(argv)

    if args.command == "init":
        from local_ai_agent_orchestrator.console_ui import write_workspace_readme

        if sys.stdout.isatty() and not args.no_interactive:
            from rich.console import Console
            from rich.panel import Panel

            from local_ai_agent_orchestrator.branding import DISPLAY as D

            Console().print(
                Panel.fit(
                    "[bold]lao init[/] — Local AI Agent Orchestrator workspace",
                    border_style=D["AI_SPARK"],
                    style=f"on {D['BG']}",
                )
            )

        _write_example_config(cwd / "factory.example.yaml")
        (cwd / ".lao").mkdir(parents=True, exist_ok=True)
        (cwd / "plans").mkdir(exist_ok=True)
        if not args.skip_readme and write_workspace_readme(cwd):
            print("Created README.md (workspace guide).")
        print("Created .lao/, plans/, and factory.example.yaml.")
        print("Copy factory.example.yaml to factory.yaml and edit model keys (see `lms ls`).")
        print("Each plan plans/Foo.md → project folder ./Foo/ (next to plans/). plans/README.md is ignored.")
        return

    cfg_path = args.config
    if cfg_path is None:
        cfg_path = _default_config_path(cwd)

    env_config = os.getenv("LAO_CONFIG") or os.getenv("FACTORY_CONFIG")
    if env_config and Path(env_config).is_file():
        cfg_path = Path(env_config)

    model_keys = {}
    if args.planner_model:
        model_keys["planner"] = args.planner_model
    if args.coder_model:
        model_keys["coder"] = args.coder_model
    if args.reviewer_model:
        model_keys["reviewer"] = args.reviewer_model
    if args.embedder_model:
        model_keys["embedder"] = args.embedder_model

    overrides = {}
    if args.lm_studio_base:
        overrides["lm_studio_base"] = args.lm_studio_base
    if args.total_ram_gb is not None:
        overrides["total_ram_gb"] = args.total_ram_gb
    if args.workspace:
        overrides["workspace_root"] = args.workspace
    if args.plans_dir:
        overrides["plans_dir"] = args.plans_dir
    if args.db_path:
        overrides["db_path"] = args.db_path
    if args.no_git:
        overrides["git_enabled"] = False

    init_settings(
        config_path=cfg_path,
        cwd=cwd,
        model_key_overrides=model_keys or None,
        **overrides,
    )

    from local_ai_agent_orchestrator import runner

    cmd = args.command or "run"

    if cmd == "status":
        runner.print_status(TaskQueue())
        return

    if cmd == "health":
        from local_ai_agent_orchestrator.model_manager import ModelManager

        runner.health_check(ModelManager())
        return

    if cmd == "reset-failed":
        q = TaskQueue()
        cur = q._conn.execute(
            "UPDATE micro_tasks SET status='pending', attempt=0 WHERE status='failed'"
        )
        print(f"Reset {cur.rowcount} failed tasks to pending.")
        return

    if cmd in (None, "run"):
        use_tui = sys.stdout.isatty() and not args.plain
        runner.run_entry(
            plan=args.plan,
            single_run=args.single_run,
            use_tui=use_tui,
        )
        return

    parser.print_help()


if __name__ == "__main__":
    main()
