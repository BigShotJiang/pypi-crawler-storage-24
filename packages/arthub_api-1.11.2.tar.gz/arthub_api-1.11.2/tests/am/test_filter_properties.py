# -*- coding: utf-8 -*-
"""测试 filter_tasks / filter_task_tree 的 properties 参数功能"""
from __future__ import absolute_import, print_function, unicode_literals

import unittest

try:
    from unittest.mock import Mock, MagicMock, patch, call
except ImportError:
    from mock import Mock, MagicMock, patch, call

from arthub_api.am.node import Node, Task
from arthub_api.am._internal.loader import PropertyLoader
from arthub_api.am.session import Session
from arthub_api.am.module import Module, ModuleManager
from arthub_api.am.workflow import Workflow, WorkflowState, WorkflowManager


class MockAPIResponse(object):
    """模拟 API 响应"""
    def __init__(self, succeeded=True, result=None):
        self._succeeded = succeeded
        self.result = result

    def is_succeeded(self):
        return self._succeeded


def _create_mock_open_api():
    """创建一个正确 mock 了所有必要 API 的 open_api"""
    mock_api = Mock()
    # SchemaManager 初始化时需要 am_get_all_properties
    mock_api.am_get_all_properties.return_value = MockAPIResponse(
        succeeded=True,
        result=[{'properties': {}}]
    )
    return mock_api


class TestPropertyLoaderSelectedProperties(unittest.TestCase):
    """测试 PropertyLoader.load_node_selected_properties"""

    def setUp(self):
        self.mock_open_api = Mock()
        self.loader = PropertyLoader(self.mock_open_api, 'test_hub')

    def test_load_selected_properties_success(self):
        """测试成功按需加载指定属性"""
        mock_result = MockAPIResponse(
            succeeded=True,
            result=[
                {'properties': {'linked_preview_id': 'preview_001', 'linked_progress_id': 'progress_001'}},
                {'properties': {'linked_preview_id': 'preview_002', 'linked_progress_id': 'progress_002'}},
            ]
        )
        self.mock_open_api.am_get_node_properties.return_value = mock_result

        results = self.loader.load_node_selected_properties(
            [101, 102],
            ['linked_preview_id', 'linked_progress_id']
        )

        self.mock_open_api.am_get_node_properties.assert_called_once_with(
            'test_hub',
            [101, 102],
            ['linked_preview_id', 'linked_progress_id']
        )
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]['properties']['linked_preview_id'], 'preview_001')

    def test_load_selected_properties_failure(self):
        """测试 API 失败时返回空列表"""
        mock_result = MockAPIResponse(succeeded=False, result=None)
        self.mock_open_api.am_get_node_properties.return_value = mock_result

        results = self.loader.load_node_selected_properties([101], ['name'])

        self.assertEqual(results, [])

    def test_load_selected_properties_empty_result(self):
        """测试 API 返回空结果"""
        mock_result = MockAPIResponse(succeeded=True, result=None)
        self.mock_open_api.am_get_node_properties.return_value = mock_result

        results = self.loader.load_node_selected_properties([101], ['name'])

        self.assertEqual(results, [])


class TestSessionPreloadSelected(unittest.TestCase):
    """测试 Session.preload_selected"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api()
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def test_preload_selected_requests_basic_plus_user_props(self):
        """测试 preload_selected 请求基本属性 + 用户指定属性"""
        node = Node(self.session, 101, data={
            '_depth': 0, '_tree_path': [101], '_children_count': 0, '_is_match_filter': True,
            'node_type': 'Entity',
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'linked_preview_id': 'p1',
            }},
        ])

        self.session.preload_selected([node], ['linked_preview_id'])

        call_args = self.session._loader.load_node_selected_properties.call_args
        requested_props = set(call_args[0][1])
        # 应包含基本属性 + 用户属性
        self.assertIn('name', requested_props)
        self.assertIn('type', requested_props)
        self.assertIn('parent', requested_props)
        self.assertIn('linked_preview_id', requested_props)

    def test_preload_selected_slim_raw(self):
        """测试 preload_selected 精简 _raw，只保留必要字段"""
        node = Node(self.session, 101, data={
            '_depth': 0, '_tree_path': [101], '_children_count': 1, '_is_match_filter': True,
            'node_type': 'Entity',
            # 模拟 _parse_task_response 之后可能存在的多余字段
            'extra_field': 'should_be_removed',
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'linked_preview_id': 'preview_001', 'linked_progress_id': 'progress_001',
            }},
        ])

        self.session.preload_selected([node], ['linked_preview_id', 'linked_progress_id'])

        # selected_props 应提升到 _raw 第一层
        self.assertEqual(node._raw.get('linked_preview_id'), 'preview_001')
        self.assertEqual(node._raw.get('linked_progress_id'), 'progress_001')

        # 基本属性应在 properties 中
        self.assertEqual(node._raw['properties']['name'], 'task_01')
        self.assertEqual(node._raw['properties']['type'], 'Entity')
        self.assertEqual(node._raw['properties']['parent'], 100)

        # 多余的字段不应存在
        self.assertNotIn('extra_field', node._raw)
        self.assertNotIn('property_permission', node._raw)
        self.assertNotIn('operations', node._raw)
        self.assertNotIn('workflow', node._raw)

        # 树形元数据应保留
        self.assertEqual(node._raw.get('_depth'), 0)
        self.assertEqual(node._raw.get('_tree_path'), [101])
        self.assertEqual(node._raw.get('_children_count'), 1)
        self.assertTrue(node._raw.get('_is_match_filter'))

        # node_type 应保留
        self.assertEqual(node._raw.get('node_type'), 'Entity')

    def test_preload_selected_sets_selected_mode(self):
        """测试 preload_selected 设置 _selected_mode 标记"""
        node = Node(self.session, 101, data={
            '_depth': 0, '_tree_path': [101], '_children_count': 0, '_is_match_filter': True,
            'node_type': 'Entity',
        })

        self.assertFalse(node._selected_mode)

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'linked_preview_id': 'p1',
            }},
        ])

        self.session.preload_selected([node], ['linked_preview_id'])

        self.assertTrue(node._selected_mode)

    def test_preload_selected_preserves_tree_metadata(self):
        """测试 preload_selected 保留所有树形元数据（包括 _parent_task, _tree_children）"""
        parent_node = Node(self.session, 100, data={})
        child_node = Node(self.session, 102, data={})
        node = Node(self.session, 101, data={
            '_depth': 2,
            '_tree_path': [1, 50, 101],
            '_children_count': 3,
            '_is_match_filter': False,
            '_parent_task': parent_node,
            '_tree_children': [child_node],
            'node_type': 'Entity',
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 50,
                'linked_preview_id': 'p1',
            }},
        ])

        self.session.preload_selected([node], ['linked_preview_id'])

        # 所有树形元数据应保留
        self.assertEqual(node._raw.get('_depth'), 2)
        self.assertEqual(node._raw.get('_tree_path'), [1, 50, 101])
        self.assertEqual(node._raw.get('_children_count'), 3)
        self.assertFalse(node._raw.get('_is_match_filter'))
        self.assertIs(node._raw.get('_parent_task'), parent_node)
        self.assertEqual(node._raw.get('_tree_children'), [child_node])

    def test_preload_selected_empty_nodes(self):
        """测试空节点列表不触发 API 调用"""
        self.session._loader.load_node_selected_properties = Mock()

        self.session.preload_selected([], ['linked_preview_id'])

        self.session._loader.load_node_selected_properties.assert_not_called()

    def test_preload_selected_empty_properties(self):
        """测试空属性列表不触发 API 调用"""
        node = Node(self.session, 101, data={})
        self.session._loader.load_node_selected_properties = Mock()

        self.session.preload_selected([node], [])

        self.session._loader.load_node_selected_properties.assert_not_called()


class TestNodeSelectedMode(unittest.TestCase):
    """测试 Node 在精简模式下的行为"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api()
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def test_getitem_selected_mode_reads_from_raw_first_level(self):
        """测试精简模式下 __getitem__ 从 _raw 第一层读取 selected_props"""
        node = Node(self.session, 101, data={
            'node_type': 'Entity',
            'properties': {'name': 'task_01', 'type': 'Entity', 'parent': 100},
            'linked_preview_id': 'preview_001',
            '_depth': 0, '_tree_path': [101], '_children_count': 0, '_is_match_filter': True,
        })
        node._selected_mode = True

        # selected_props 应从 _raw 第一层读取
        self.assertEqual(node['linked_preview_id'], 'preview_001')
        # 基本属性仍从 properties 读取
        self.assertEqual(node['name'], 'task_01')

    def test_getitem_selected_mode_no_populate(self):
        """测试精简模式下访问不存在的属性不触发 _populate"""
        node = Node(self.session, 101, data={
            'node_type': 'Entity',
            'properties': {'name': 'task_01'},
            '_depth': 0,
        })
        node._selected_mode = True
        node._populate = Mock()

        # 访问不存在的属性应返回 None，不触发 _populate
        result = node['nonexistent_prop']
        self.assertIsNone(result)
        node._populate.assert_not_called()

    def test_getitem_normal_mode_triggers_populate(self):
        """测试普通模式下访问不存在的属性触发 _populate"""
        node = Node(self.session, 101, data={
            'node_type': 'Entity',
            'properties': {'name': 'task_01'},
        })
        # _selected_mode 默认 False
        self.assertFalse(node._selected_mode)

        # mock _populate 使其设置属性
        def mock_populate():
            node._raw['properties']['custom_prop'] = 'loaded_value'
        node._populate = mock_populate

        result = node['custom_prop']
        self.assertEqual(result, 'loaded_value')

    def test_get_method_selected_mode(self):
        """测试精简模式下 get() 方法正常工作"""
        node = Node(self.session, 101, data={
            'node_type': 'Entity',
            'properties': {'name': 'task_01'},
            'linked_preview_id': 'preview_001',
        })
        node._selected_mode = True

        self.assertEqual(node.get('linked_preview_id', 'N/A'), 'preview_001')
        self.assertEqual(node.get('nonexistent', 'default_val'), 'default_val')
        self.assertEqual(node.get('name', 'N/A'), 'task_01')


class TestFilterTasksProperties(unittest.TestCase):
    """测试 filter_tasks / filter_task_tree 的 properties 参数"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api()
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

        # 模拟 am_get_task_list_by_version 返回
        self.mock_task_response = MockAPIResponse(
            succeeded=True,
            result=[{
                'ids': [201, 202, 203],
                'node_type': ['Entity', 'Entity', 'Entity'],
                'depth': [0, 1, 0],
                'path': [[201], [201, 202], [203]],
                'children_count': [1, 0, 0],
                'is_match_filter': [0, 1, 1],
            }]
        )
        self.mock_open_api.am_get_task_list_by_version.return_value = self.mock_task_response

        # 创建 version 节点
        self.version_node = self.session._get_or_create_node('Version', 100, data={
            'properties': {'name': 'test-version'}
        })

    def test_filter_tasks_without_properties_uses_preload(self):
        """测试不传 properties 时使用原有 preload 方法"""
        self.session.preload = Mock()
        self.session.preload_selected = Mock()

        filter_dsl = [{"bool": {"must": []}}]
        result = self.version_node.filter_tasks(filter_dsl)

        self.assertEqual(len(result), 3)
        self.session.preload.assert_called_once()
        self.session.preload_selected.assert_not_called()

    def test_filter_tasks_with_properties_uses_preload_selected(self):
        """测试传 properties 时使用 preload_selected 方法"""
        self.session.preload = Mock()
        self.session.preload_selected = Mock()

        filter_dsl = [{"bool": {"must": []}}]
        result = self.version_node.filter_tasks(
            filter_dsl,
            properties=["linked_preview_id"]
        )

        self.assertEqual(len(result), 3)
        self.session.preload_selected.assert_called_once()
        self.session.preload.assert_not_called()
        # 验证传递的 properties 参数
        call_args = self.session.preload_selected.call_args
        self.assertEqual(call_args[0][1], ["linked_preview_id"])

    def test_filter_task_tree_without_properties_uses_preload(self):
        """测试 filter_task_tree 不传 properties 时使用 preload"""
        self.session.preload = Mock()
        self.session.preload_selected = Mock()

        filter_dsl = [{"bool": {"must": []}}]
        result = self.version_node.filter_task_tree(filter_dsl)

        self.session.preload.assert_called_once()
        self.session.preload_selected.assert_not_called()
        self.assertIsInstance(result, list)

    def test_filter_task_tree_with_properties_uses_preload_selected(self):
        """测试 filter_task_tree 传 properties 时使用 preload_selected"""
        self.session.preload = Mock()
        self.session.preload_selected = Mock()

        filter_dsl = [{"bool": {"must": []}}]
        result = self.version_node.filter_task_tree(
            filter_dsl,
            properties=["linked_preview_id", "linked_progress_id"]
        )

        self.session.preload_selected.assert_called_once()
        self.session.preload.assert_not_called()
        call_args = self.session.preload_selected.call_args
        self.assertEqual(call_args[0][1], ["linked_preview_id", "linked_progress_id"])

    def test_filter_tasks_api_failure_returns_empty(self):
        """测试 API 失败时返回空列表"""
        self.mock_open_api.am_get_task_list_by_version.return_value = MockAPIResponse(
            succeeded=False, result=None
        )

        result = self.version_node.filter_tasks(
            [{"bool": {"must": []}}],
            properties=["linked_preview_id"]
        )

        self.assertEqual(result, [])

    def test_filter_tasks_empty_result_no_preload(self):
        """测试空结果不触发预加载"""
        self.mock_open_api.am_get_task_list_by_version.return_value = MockAPIResponse(
            succeeded=True,
            result=[{'ids': [], 'node_type': []}]
        )
        self.session.preload = Mock()
        self.session.preload_selected = Mock()

        result = self.version_node.filter_tasks(
            [{"bool": {"must": []}}],
            properties=["linked_preview_id"]
        )

        self.assertEqual(result, [])
        self.session.preload.assert_not_called()
        self.session.preload_selected.assert_not_called()

    def test_filter_task_tree_builds_tree_with_properties(self):
        """测试 filter_task_tree 传 properties 时仍能正确构建树形结构"""
        self.session.preload_selected = Mock()

        filter_dsl = [{"bool": {"must": []}}]
        tree = self.version_node.filter_task_tree(
            filter_dsl,
            properties=["linked_preview_id"]
        )

        # 应该有 2 个根节点（depth=0 的 201 和 203）
        self.assertEqual(len(tree), 2)
        # 第一个根节点应有 1 个子节点
        root1 = tree[0]
        self.assertEqual(root1.id, 201)
        self.assertEqual(len(root1.children), 1)
        self.assertEqual(root1.children[0].id, 202)
        # 第二个根节点没有子节点
        root2 = tree[1]
        self.assertEqual(root2.id, 203)
        self.assertEqual(len(root2.children), 0)

    def test_backward_compatibility_no_properties(self):
        """测试向后兼容性：不传 properties 参数时行为不变"""
        self.session.preload = Mock()

        filter_dsl = [{"bool": {"must": []}}]

        # 原有调用方式
        result = self.version_node.filter_tasks(filter_dsl, count=50)
        self.assertEqual(len(result), 3)
        self.session.preload.assert_called_once()

        # 验证 API 调用参数
        self.mock_open_api.am_get_task_list_by_version.assert_called_with(
            'test_hub', 100, filter=filter_dsl, offset=0, count=50
        )


class TestEndToEndSelectedProperties(unittest.TestCase):
    """端到端测试：验证 preload_selected 后节点的完整行为"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api()
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def test_full_flow_slim_node(self):
        """端到端：preload_selected 后节点只包含精简数据"""
        # 模拟两个节点
        node1 = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 1, '_is_match_filter': False,
        })
        node2 = Node(self.session, 202, data={
            'node_type': 'Entity',
            '_depth': 1, '_tree_path': [201, 202], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'linked_preview_id': 'preview_001', 'linked_progress_id': 'progress_001',
            }},
            {'properties': {
                'name': 'child_task', 'type': 'Entity', 'parent': 201,
                'linked_preview_id': 'preview_002', 'linked_progress_id': 'progress_002',
            }},
        ])

        self.session.preload_selected(
            [node1, node2],
            ['linked_preview_id', 'linked_progress_id']
        )

        # 验证 node1
        self.assertTrue(node1._selected_mode)
        # selected_props 在第一层
        self.assertEqual(node1['linked_preview_id'], 'preview_001')
        self.assertEqual(node1['linked_progress_id'], 'progress_001')
        # 基本属性可访问
        self.assertEqual(node1['name'], 'task_01')
        self.assertEqual(node1.node_type, 'Entity')
        self.assertEqual(node1['parent'], 100)
        # 树形元数据保留
        self.assertEqual(node1._raw.get('_depth'), 0)
        self.assertFalse(node1._raw.get('_is_match_filter'))
        # _raw 中不应有多余字段
        expected_keys = {
            'node_type', 'properties',
            'linked_preview_id', 'linked_progress_id',
            '_depth', '_tree_path', '_children_count', '_is_match_filter',
        }
        self.assertEqual(set(node1._raw.keys()), expected_keys)

        # 验证 node2
        self.assertEqual(node2['linked_preview_id'], 'preview_002')
        self.assertEqual(node2['name'], 'child_task')
        self.assertEqual(node2['parent'], 201)

    def test_slim_node_no_auto_populate(self):
        """端到端：精简模式下访问未知属性不触发网络请求"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'linked_preview_id': 'preview_001',
            }},
        ])
        self.session._loader.load_node_properties = Mock(return_value=[])

        self.session.preload_selected([node], ['linked_preview_id'])

        # 访问不存在的属性
        result = node.get('workflow_state', 'N/A')
        self.assertEqual(result, 'N/A')

        # 不应触发全量加载
        self.session._loader.load_node_properties.assert_not_called()


def _create_mock_open_api_with_schemas(schema_dict=None):
    """创建带有 schema 信息的 mock open_api
    
    Args:
        schema_dict: 属性 schema 字典，key 为 field_id，value 为属性元信息
    """
    mock_api = Mock()
    if schema_dict is None:
        schema_dict = {}
    
    properties = {}
    for field_id, info in schema_dict.items():
        properties[field_id] = {
            'display_name': info.get('display_name', ''),
            'type_name': info.get('type_name', 'string'),
            'editor': info.get('editor', ''),
            'scope': info.get('scope', []),
            'range': info.get('range', {}),
            'is_custom': info.get('is_custom', False),
            'is_read_only': info.get('is_read_only', False),
            'file_meta': info.get('file_meta', ''),
            'default_value': info.get('default_value'),
        }
    
    mock_api.am_get_all_properties.return_value = MockAPIResponse(
        succeeded=True,
        result=[{'properties': properties}]
    )
    return mock_api


class TestExpandPersonFields(unittest.TestCase):
    """测试人员型字段展开（editor='personEditor'）"""

    def setUp(self):
        # 创建包含人员型字段 schema 的 mock
        self.mock_open_api = _create_mock_open_api_with_schemas({
            'artist': {
                'display_name': '负责人',
                'type_name': 'string[]',
                'editor': 'personEditor',
            },
            'reviewer': {
                'display_name': '审核人',
                'type_name': 'string[]',
                'editor': 'personEditor',
            },
            'creator': {
                'display_name': '创建者',
                'type_name': 'string',
                'editor': 'personEditor',
            },
            'name': {
                'display_name': '名称',
                'type_name': 'string',
                'editor': 'inputEditor',
            },
            'module': {
                'display_name': '模块',
                'type_name': 'string',
                'editor': 'moduleEditor',
            },
        })
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def test_expand_person_field_single_user(self):
        """测试展开人员型字段：单个用户"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'artist': ['kazenzhong'],
            }},
        ])

        # mock check_account_if_exist（批量查询）
        self.mock_open_api.check_account_if_exist.return_value = MockAPIResponse(
            succeeded=True,
            result={
                'kazenzhong': {'nick_name': 'Kazen', 'account_name': 'kazenzhong', 'icon_url': '', 'extra_field': 'should_be_removed'},
            }
        )

        self.session.preload_selected([node], ['artist'], expand_references=True)

        # artist 字段应被展开为包含详情的列表，且只保留指定字段
        artist_val = node._raw.get('artist')
        self.assertIsNotNone(artist_val)
        self.assertIsInstance(artist_val, list)
        self.assertEqual(len(artist_val), 1)
        self.assertEqual(artist_val[0]['nick_name'], 'Kazen')
        self.assertEqual(artist_val[0]['account_name'], 'kazenzhong')
        self.assertIn('icon_url', artist_val[0])
        self.assertNotIn('extra_field', artist_val[0])

    def test_expand_person_field_multiple_users(self):
        """测试展开人员型字段：多个用户"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'artist': ['user_a', 'user_b'],
            }},
        ])

        # mock check_account_if_exist（批量查询）
        self.mock_open_api.check_account_if_exist.return_value = MockAPIResponse(
            succeeded=True,
            result={
                'user_a': {'nick_name': 'User A', 'account_name': 'user_a'},
                'user_b': {'nick_name': 'User B', 'account_name': 'user_b'},
            }
        )

        self.session.preload_selected([node], ['artist'], expand_references=True)

        artist_val = node._raw.get('artist')
        self.assertIsNotNone(artist_val)
        self.assertIsInstance(artist_val, list)
        self.assertEqual(len(artist_val), 2)

    def test_expand_person_field_empty_value(self):
        """测试展开人员型字段：空值不报错"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'artist': [],
            }},
        ])

        # 空值时不应调用账户 API
        self.session.preload_selected([node], ['artist'], expand_references=True)

        artist_val = node._raw.get('artist')
        self.assertEqual(artist_val, [])
        self.mock_open_api.check_account_if_exist.assert_not_called()

    def test_expand_person_field_none_value(self):
        """测试展开人员型字段：None 值不报错"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'artist': None,
            }},
        ])

        self.session.preload_selected([node], ['artist'], expand_references=True)

        artist_val = node._raw.get('artist')
        self.assertIsNone(artist_val)

    def test_no_expand_when_flag_false(self):
        """测试 expand_references=False 时不展开"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'artist': ['kazenzhong'],
            }},
        ])

        self.session.preload_selected([node], ['artist'], expand_references=False)

        # 应保持原始 ID 值
        artist_val = node._raw.get('artist')
        self.assertEqual(artist_val, ['kazenzhong'])
        self.mock_open_api.check_account_if_exist.assert_not_called()

    def test_expand_person_field_string_value(self):
        """测试展开人员型字段：值为字符串（非数组）"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'creator': 'kazenzhong',
            }},
        ])

        self.mock_open_api.check_account_if_exist.return_value = MockAPIResponse(
            succeeded=True,
            result={
                'kazenzhong': {'nick_name': 'Kazen', 'account_name': 'kazenzhong', 'department': 'TA Hub'},
            }
        )

        self.session.preload_selected([node], ['creator'], expand_references=True)

        creator_val = node._raw.get('creator')
        self.assertIsNotNone(creator_val)
        self.assertIsInstance(creator_val, dict)
        self.assertEqual(creator_val['nick_name'], 'Kazen')
        self.assertEqual(creator_val['account_name'], 'kazenzhong')

    def test_expand_person_field_string_value_not_found(self):
        """测试展开人员型字段：字符串值查询不到用户，返回 fallback"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'creator': 'unknown_user',
            }},
        ])

        self.mock_open_api.check_account_if_exist.return_value = MockAPIResponse(
            succeeded=True,
            result={}
        )

        self.session.preload_selected([node], ['creator'], expand_references=True)

        creator_val = node._raw.get('creator')
        self.assertIsInstance(creator_val, dict)
        self.assertEqual(creator_val['account_name'], 'unknown_user')

    def test_expand_person_field_mixed_string_and_list(self):
        """测试同时展开字符串型和数组型人员字段"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'creator': 'kazenzhong',
                'artist': ['user_a'],
            }},
        ])

        self.mock_open_api.check_account_if_exist.return_value = MockAPIResponse(
            succeeded=True,
            result={
                'kazenzhong': {'nick_name': 'Kazen', 'account_name': 'kazenzhong'},
                'user_a': {'nick_name': 'User A', 'account_name': 'user_a'},
            }
        )

        self.session.preload_selected([node], ['creator', 'artist'], expand_references=True)

        # creator 应展开为 dict
        creator_val = node._raw.get('creator')
        self.assertIsInstance(creator_val, dict)
        self.assertEqual(creator_val['nick_name'], 'Kazen')

        # artist 应展开为 list of dict
        artist_val = node._raw.get('artist')
        self.assertIsInstance(artist_val, list)
        self.assertEqual(artist_val[0]['nick_name'], 'User A')

    def test_expand_person_field_batch_across_nodes(self):
        """测试多个节点的人员字段批量展开（去重）"""
        node1 = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })
        node2 = Node(self.session, 202, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [202], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'artist': ['user_a'],
            }},
            {'properties': {
                'name': 'task_02', 'type': 'Entity', 'parent': 100,
                'artist': ['user_a', 'user_b'],  # user_a 重复
            }},
        ])

        self.mock_open_api.check_account_if_exist.return_value = MockAPIResponse(
            succeeded=True,
            result={
                'user_a': {'nick_name': 'User A', 'account_name': 'user_a'},
                'user_b': {'nick_name': 'User B', 'account_name': 'user_b'},
            }
        )

        self.session.preload_selected([node1, node2], ['artist'], expand_references=True)

        # 验证只调用了一次批量查询（去重后 user_a, user_b）
        self.mock_open_api.check_account_if_exist.assert_called_once()
        call_args = self.mock_open_api.check_account_if_exist.call_args[0]
        queried_names = set(call_args[0])
        self.assertEqual(queried_names, {'user_a', 'user_b'})

        # 两个节点都应被展开
        self.assertEqual(len(node1._raw.get('artist')), 1)
        self.assertEqual(len(node2._raw.get('artist')), 2)


class TestExpandModuleField(unittest.TestCase):
    """测试 module 字段展开"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api_with_schemas({
            'module': {
                'display_name': '模块',
                'type_name': 'string',
                'editor': 'moduleEditor',
            },
            'name': {
                'display_name': '名称',
                'type_name': 'string',
                'editor': 'inputEditor',
            },
        })
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def test_expand_module_field(self):
        """测试展开 module 字段为 Module 对象"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        module_id = 'e3729496-2c09-553a-8c4a-854d0e3c0b96'
        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'module': module_id,
            }},
        ])

        # mock modules manager
        mock_module = Module({
            'name': module_id,
            'display_name': '模型',
            'param_index': 7,
            'color': '#13D1B6',
        })
        self.session._modules = Mock()
        self.session._modules.get.return_value = mock_module

        self.session.preload_selected([node], ['module'], expand_references=True)

        module_val = node._raw.get('module')
        self.assertIsInstance(module_val, Module)
        self.assertEqual(module_val.display_name, '模型')
        self.assertEqual(module_val.name, module_id)

    def test_expand_module_field_not_found(self):
        """测试展开 module 字段时模块不存在，保持原值"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'module': 'nonexistent-module-id',
            }},
        ])

        self.session._modules = Mock()
        self.session._modules.get.return_value = None

        self.session.preload_selected([node], ['module'], expand_references=True)

        module_val = node._raw.get('module')
        # 找不到时保持原始值
        self.assertEqual(module_val, 'nonexistent-module-id')

    def test_expand_module_field_empty_value(self):
        """测试展开 module 字段：空值不报错"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'module': '',
            }},
        ])

        self.session.preload_selected([node], ['module'], expand_references=True)

        module_val = node._raw.get('module')
        self.assertEqual(module_val, '')


class TestExpandWorkflowIdField(unittest.TestCase):
    """测试 workflow_id 字段展开"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api_with_schemas({
            'workflow_id': {
                'display_name': '工作流',
                'type_name': 'int',
                'editor': '',
            },
            'name': {
                'display_name': '名称',
                'type_name': 'string',
                'editor': 'inputEditor',
            },
        })
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def test_expand_workflow_id_field(self):
        """测试展开 workflow_id 字段为包含指定字段的字典"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        wf_id = 120347699877335
        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'workflow_id': wf_id,
            }},
        ])

        # mock workflows manager
        mock_workflow = Workflow({
            'id': wf_id,
            'name': 'am_default_workflow',
            'display_name': '基础工作流',
            'apply_types': ['Entity', 'Stage'],
            'state': [
                {'id': 1001, 'name': 'open', 'display_name': '未开始', 'type': '未开始'},
                {'id': 1002, 'name': 'progressing', 'display_name': '进行中', 'type': '进行中'},
            ],
            'transition': [{'name': 't1', 'previous': 1001, 'next': 1002}],
        })
        self.session._workflows = Mock()
        self.session._workflows.get.return_value = mock_workflow

        self.session.preload_selected([node], ['workflow_id'], expand_references=True)

        wf_val = node._raw.get('workflow_id')
        self.assertIsInstance(wf_val, dict)
        self.assertEqual(wf_val['id'], wf_id)
        self.assertEqual(wf_val['display_name'], '基础工作流')
        self.assertEqual(wf_val['apply_types'], ['Entity', 'Stage'])
        self.assertEqual(wf_val['transition'], [{'name': 't1', 'previous': 1001, 'next': 1002}])

    def test_expand_workflow_id_field_not_found(self):
        """测试展开 workflow_id 字段时工作流不存在，保持原值"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'workflow_id': 999999,
            }},
        ])

        self.session._workflows = Mock()
        self.session._workflows.get.return_value = None

        self.session.preload_selected([node], ['workflow_id'], expand_references=True)

        wf_val = node._raw.get('workflow_id')
        self.assertEqual(wf_val, 999999)

    def test_expand_workflow_id_field_none_value(self):
        """测试展开 workflow_id 字段：None 值不报错"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'workflow_id': None,
            }},
        ])

        self.session.preload_selected([node], ['workflow_id'], expand_references=True)

        wf_val = node._raw.get('workflow_id')
        self.assertIsNone(wf_val)


class TestExpandWorkflowStateField(unittest.TestCase):
    """测试 workflow_state 字段展开"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api_with_schemas({
            'workflow_state': {
                'display_name': '工作流状态',
                'type_name': 'int',
                'editor': '',
            },
            'workflow_id': {
                'display_name': '工作流',
                'type_name': 'int',
                'editor': '',
            },
            'name': {
                'display_name': '名称',
                'type_name': 'string',
                'editor': 'inputEditor',
            },
        })
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def _setup_workflow_mock(self):
        """设置工作流 mock"""
        wf_id = 120347699877335
        mock_workflow = Workflow({
            'id': wf_id,
            'name': 'am_default_workflow',
            'display_name': '基础工作流',
            'state': [
                {'id': 1001, 'name': 'open', 'display_name': '未开始', 'type': '未开始'},
                {'id': 1002, 'name': 'progressing', 'display_name': '进行中', 'type': '进行中'},
                {'id': 1003, 'name': 'done', 'display_name': '已完成', 'type': '已完成'},
            ],
            'transition': [],
        })
        self.session._workflows = Mock()
        self.session._workflows.get.return_value = mock_workflow
        return wf_id, mock_workflow

    def test_expand_workflow_state_with_workflow_id_in_properties(self):
        """测试展开 workflow_state 字段：workflow_id 在请求的属性中"""
        wf_id, mock_workflow = self._setup_workflow_mock()
        
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'workflow_id': wf_id,
                'workflow_state': 1002,
            }},
        ])

        self.session.preload_selected(
            [node], ['workflow_id', 'workflow_state'], expand_references=True
        )

        state_val = node._raw.get('workflow_state')
        self.assertIsInstance(state_val, dict)
        self.assertEqual(state_val['display_name'], '进行中')
        self.assertEqual(state_val['id'], 1002)
        self.assertEqual(state_val['type'], '进行中')
        self.assertEqual(state_val['workflow_id'], wf_id)

    def test_expand_workflow_state_without_workflow_id_in_properties(self):
        """测试展开 workflow_state 字段：workflow_id 不在请求的属性中，需额外加载"""
        wf_id, mock_workflow = self._setup_workflow_mock()

        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        # workflow_id 不在 properties 中，但 workflow_state 在
        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'workflow_state': 1002,
            }},
        ])

        # 需要额外加载 workflow_id
        # 模拟 load_node_selected_properties 第二次调用获取 workflow_id
        original_load = self.session._loader.load_node_selected_properties
        call_count = [0]
        def side_effect(ids, props):
            call_count[0] += 1
            if call_count[0] == 1:
                return [{'properties': {
                    'name': 'task_01', 'type': 'Entity', 'parent': 100,
                    'workflow_state': 1002,
                }}]
            else:
                # 第二次调用获取 workflow_id
                return [{'properties': {'workflow_id': wf_id}}]
        
        self.session._loader.load_node_selected_properties = Mock(side_effect=side_effect)

        self.session.preload_selected(
            [node], ['workflow_state'], expand_references=True
        )

        state_val = node._raw.get('workflow_state')
        self.assertIsInstance(state_val, dict)
        self.assertEqual(state_val['display_name'], '进行中')

    def test_expand_workflow_state_not_found(self):
        """测试展开 workflow_state 字段：状态不存在，保持原值"""
        wf_id, mock_workflow = self._setup_workflow_mock()

        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'workflow_id': wf_id,
                'workflow_state': 9999,  # 不存在的状态 ID
            }},
        ])

        self.session.preload_selected(
            [node], ['workflow_id', 'workflow_state'], expand_references=True
        )

        state_val = node._raw.get('workflow_state')
        # 找不到状态时保持原始值
        self.assertEqual(state_val, 9999)

    def test_expand_workflow_state_none_value(self):
        """测试展开 workflow_state 字段：None 值不报错"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'workflow_state': None,
            }},
        ])

        self.session.preload_selected(
            [node], ['workflow_state'], expand_references=True
        )

        state_val = node._raw.get('workflow_state')
        self.assertIsNone(state_val)


class TestExpandDropdownFields(unittest.TestCase):
    """测试展开下拉选择类字段"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api_with_schemas({
            'priority': {
                'display_name': '优先级',
                'type_name': 'string',
                'editor': 'dropdownEditor',
                'range': {
                    'display_name': {
                        '-1-1-1': '高',
                        '-1-1-2': '中',
                        '-1-1-3': '低',
                    },
                },
            },
            'tags': {
                'display_name': '标签',
                'type_name': 'string[]',
                'editor': 'dropdownMultiSelectEditor',
                'range': {
                    'display_name': {
                        '-1-1-1': '哈哈',
                        '-1-1-2': '哇哇',
                        '-1-1-3': '呵呵',
                        '-1-1-4': '每每',
                    },
                },
            },
            'category': {
                'display_name': '分类',
                'type_name': 'string',
                'editor': 'treeDropdownEditor',
                'range': {
                    'display_name': {
                        '-1-1-1': '角色',
                        '-1-1-2': '场景',
                    },
                },
            },
            'multi_category': {
                'display_name': '多选分类',
                'type_name': 'string[]',
                'editor': 'treeDropdownMultiSelectEditor',
                'range': {
                    'display_name': {
                        '-1-1-1': '动画',
                        '-1-1-2': '特效',
                    },
                },
            },
            'list_single': {
                'display_name': '列表单选',
                'type_name': 'string',
                'editor': 'listDropdownEditor',
                'range': {
                    'display_name': {
                        '-1-1-1': '选项A',
                        '-1-1-2': '选项B',
                    },
                },
            },
            'list_multi': {
                'display_name': '列表多选',
                'type_name': 'string[]',
                'editor': 'listDropdownMultiSelectEditor',
                'range': {
                    'display_name': {
                        '-1-1-1': '选项X',
                        '-1-1-2': '选项Y',
                    },
                },
            },
            'name': {
                'display_name': '名称',
                'type_name': 'string',
                'editor': 'inputEditor',
            },
        })
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def test_expand_dropdown_single_select(self):
        """测试展开单选下拉字段：ID 替换为名称"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'priority': '-1-1-1',
            }},
        ])

        self.session.preload_selected([node], ['priority'], expand_references=True)

        val = node._raw.get('priority')
        self.assertIsInstance(val, dict)
        self.assertEqual(val['id'], '-1-1-1')
        self.assertEqual(val['display_name'], '高')

    def test_expand_dropdown_multi_select(self):
        """测试展开多选下拉字段：ID 数组替换为对象数组"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'tags': ['-1-1-1', '-1-1-3'],
            }},
        ])

        self.session.preload_selected([node], ['tags'], expand_references=True)

        tags = node._raw.get('tags')
        self.assertIsInstance(tags, list)
        self.assertEqual(len(tags), 2)
        self.assertEqual(tags[0], {'id': '-1-1-1', 'display_name': '哈哈'})
        self.assertEqual(tags[1], {'id': '-1-1-3', 'display_name': '呵呵'})

    def test_expand_tree_dropdown_single_select(self):
        """测试展开树形单选下拉字段"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'category': '-1-1-2',
            }},
        ])

        self.session.preload_selected([node], ['category'], expand_references=True)

        val = node._raw.get('category')
        self.assertIsInstance(val, dict)
        self.assertEqual(val['id'], '-1-1-2')
        self.assertEqual(val['display_name'], '场景')

    def test_expand_tree_dropdown_multi_select(self):
        """测试展开树形多选下拉字段"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'multi_category': ['-1-1-1', '-1-1-2'],
            }},
        ])

        self.session.preload_selected([node], ['multi_category'], expand_references=True)

        vals = node._raw.get('multi_category')
        self.assertEqual(vals, [
            {'id': '-1-1-1', 'display_name': '动画'},
            {'id': '-1-1-2', 'display_name': '特效'},
        ])

    def test_expand_list_dropdown_editors(self):
        """测试展开 listDropdownEditor 和 listDropdownMultiSelectEditor"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'list_single': '-1-1-2',
                'list_multi': ['-1-1-1', '-1-1-2'],
            }},
        ])

        self.session.preload_selected([node], ['list_single', 'list_multi'], expand_references=True)

        self.assertEqual(node._raw.get('list_single'), {'id': '-1-1-2', 'display_name': '选项B'})
        self.assertEqual(node._raw.get('list_multi'), [
            {'id': '-1-1-1', 'display_name': '选项X'},
            {'id': '-1-1-2', 'display_name': '选项Y'},
        ])

    def test_expand_dropdown_unknown_id_kept(self):
        """测试展开下拉字段：未知 ID 保持原值"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'priority': '-1-1-999',
            }},
        ])

        self.session.preload_selected([node], ['priority'], expand_references=True)

        # 未知 ID 保持原值
        self.assertEqual(node._raw.get('priority'), '-1-1-999')

    def test_expand_dropdown_empty_value(self):
        """测试展开下拉字段：空值不处理"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'priority': '',
            }},
        ])

        self.session.preload_selected([node], ['priority'], expand_references=True)

        self.assertEqual(node._raw.get('priority'), '')

    def test_expand_dropdown_none_value(self):
        """测试展开下拉字段：None 值不处理"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'priority': None,
            }},
        ])

        self.session.preload_selected([node], ['priority'], expand_references=True)

        self.assertIsNone(node._raw.get('priority'))

    def test_no_expand_when_flag_false(self):
        """测试 expand_references=False 时下拉字段不展开"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'priority': '-1-1-1',
            }},
        ])

        self.session.preload_selected([node], ['priority'], expand_references=False)

        # ID 保持不变
        self.assertEqual(node._raw.get('priority'), '-1-1-1')

    def test_expand_dropdown_multi_across_nodes(self):
        """测试多节点下拉字段展开"""
        node1 = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })
        node2 = Node(self.session, 202, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [202], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'priority': '-1-1-1',
            }},
            {'properties': {
                'name': 'task_02', 'type': 'Entity', 'parent': 100,
                'priority': '-1-1-3',
            }},
        ])

        self.session.preload_selected([node1, node2], ['priority'], expand_references=True)

        self.assertEqual(node1._raw.get('priority'), {'id': '-1-1-1', 'display_name': '高'})
        self.assertEqual(node2._raw.get('priority'), {'id': '-1-1-3', 'display_name': '低'})


class TestExpandReferencesCombined(unittest.TestCase):
    """测试多种引用字段同时展开"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api_with_schemas({
            'artist': {
                'display_name': '负责人',
                'type_name': 'string[]',
                'editor': 'personEditor',
            },
            'module': {
                'display_name': '模块',
                'type_name': 'string',
                'editor': 'moduleEditor',
            },
            'workflow_id': {
                'display_name': '工作流',
                'type_name': 'int',
                'editor': '',
            },
            'workflow_state': {
                'display_name': '工作流状态',
                'type_name': 'int',
                'editor': '',
            },
            'name': {
                'display_name': '名称',
                'type_name': 'string',
                'editor': 'inputEditor',
            },
        })
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

    def test_expand_all_reference_types(self):
        """测试同时展开人员、模块、工作流、工作流状态"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        wf_id = 120347699877335
        module_id = 'e3729496-2c09-553a-8c4a-854d0e3c0b96'

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'artist': ['kazenzhong'],
                'module': module_id,
                'workflow_id': wf_id,
                'workflow_state': 1002,
            }},
        ])

        # mock 人员查询
        self.mock_open_api.check_account_if_exist.return_value = MockAPIResponse(
            succeeded=True,
            result={'kazenzhong': {'nick_name': 'Kazen', 'account_name': 'kazenzhong'}}
        )

        # mock 模块
        mock_module = Module({
            'name': module_id,
            'display_name': '模型',
            'param_index': 7,
        })
        self.session._modules = Mock()
        self.session._modules.get.return_value = mock_module

        # mock 工作流
        mock_workflow = Workflow({
            'id': wf_id,
            'name': 'default_wf',
            'display_name': '基础工作流',
            'state': [
                {'id': 1002, 'name': 'progressing', 'display_name': '进行中', 'type': '进行中'},
            ],
            'transition': [],
        })
        self.session._workflows = Mock()
        self.session._workflows.get.return_value = mock_workflow

        self.session.preload_selected(
            [node],
            ['artist', 'module', 'workflow_id', 'workflow_state'],
            expand_references=True
        )

        # 验证人员展开
        artist_val = node._raw.get('artist')
        self.assertIsInstance(artist_val, list)
        self.assertEqual(artist_val[0]['nick_name'], 'Kazen')

        # 验证模块展开
        module_val = node._raw.get('module')
        self.assertIsInstance(module_val, Module)
        self.assertEqual(module_val.display_name, '模型')

        # 验证工作流展开
        wf_val = node._raw.get('workflow_id')
        self.assertIsInstance(wf_val, dict)
        self.assertEqual(wf_val['display_name'], '基础工作流')
        self.assertEqual(wf_val['id'], wf_id)

        # 验证工作流状态展开
        state_val = node._raw.get('workflow_state')
        self.assertIsInstance(state_val, dict)
        self.assertEqual(state_val['display_name'], '进行中')
        self.assertEqual(state_val['id'], 1002)
        self.assertEqual(state_val['type'], '进行中')
        self.assertEqual(state_val['workflow_id'], wf_id)

    def test_expand_references_default_false(self):
        """测试 expand_references 默认为 False（向后兼容）"""
        node = Node(self.session, 201, data={
            'node_type': 'Entity',
            '_depth': 0, '_tree_path': [201], '_children_count': 0, '_is_match_filter': True,
        })

        self.session._loader.load_node_selected_properties = Mock(return_value=[
            {'properties': {
                'name': 'task_01', 'type': 'Entity', 'parent': 100,
                'artist': ['kazenzhong'],
                'module': 'mod-id',
            }},
        ])

        # 不传 expand_references 参数
        self.session.preload_selected([node], ['artist', 'module'])

        # 应保持原始值
        self.assertEqual(node._raw.get('artist'), ['kazenzhong'])
        self.assertEqual(node._raw.get('module'), 'mod-id')


class TestFilterTasksExpandReferences(unittest.TestCase):
    """测试 filter_tasks / filter_task_tree 的 expand_references 参数传递"""

    def setUp(self):
        self.mock_open_api = _create_mock_open_api_with_schemas({
            'artist': {
                'display_name': '负责人',
                'type_name': 'string[]',
                'editor': 'personEditor',
            },
        })
        self.session = Session(self.mock_open_api, asset_hub='test_hub')

        self.mock_task_response = MockAPIResponse(
            succeeded=True,
            result=[{
                'ids': [201],
                'node_type': ['Entity'],
                'depth': [0],
                'path': [[201]],
                'children_count': [0],
                'is_match_filter': [1],
            }]
        )
        self.mock_open_api.am_get_task_list_by_version.return_value = self.mock_task_response

        self.version_node = self.session._get_or_create_node('Version', 100, data={
            'properties': {'name': 'test-version'}
        })

    def test_filter_tasks_passes_expand_references(self):
        """测试 filter_tasks 传递 expand_references 参数"""
        self.session.preload_selected = Mock()

        self.version_node.filter_tasks(
            [{"bool": {"must": []}}],
            properties=["artist"],
            expand_references=True
        )

        call_args = self.session.preload_selected.call_args
        self.assertTrue(call_args[1].get('expand_references') or 
                        (len(call_args[0]) > 2 and call_args[0][2]))

    def test_filter_task_tree_passes_expand_references(self):
        """测试 filter_task_tree 传递 expand_references 参数"""
        self.session.preload_selected = Mock()

        self.version_node.filter_task_tree(
            [{"bool": {"must": []}}],
            properties=["artist"],
            expand_references=True
        )

        call_args = self.session.preload_selected.call_args
        self.assertTrue(call_args[1].get('expand_references') or 
                        (len(call_args[0]) > 2 and call_args[0][2]))


if __name__ == '__main__':
    unittest.main()
