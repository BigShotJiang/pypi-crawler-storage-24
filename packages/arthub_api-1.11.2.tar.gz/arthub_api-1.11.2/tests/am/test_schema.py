# -*- coding: utf-8 -*-
"""测试 SchemaManager"""
from __future__ import absolute_import, print_function, unicode_literals

import unittest

try:
    from unittest.mock import Mock, MagicMock
except ImportError:
    from mock import Mock, MagicMock

from arthub_api.am._internal.schema import SchemaManager


class TestSchemaManager(unittest.TestCase):
    """测试 SchemaManager"""
    
    def setUp(self):
        """测试前准备"""
        # 创建 mock OpenAPI
        self.mock_api = Mock()
        
        # 模拟 am_get_all_properties 响应
        mock_result = Mock()
        mock_result.is_succeeded.return_value = True
        mock_result.result = {
            'properties': {
                'name': {
                    'display_name': '名称',
                    'type_name': 'string',
                    'editor': 'textEditor',
                    'scope': [{'object_type': 'Entity'}],
                    'range': {},
                    'is_custom': False,
                    'is_read_only': False,
                },
                'artist': {
                    'display_name': '负责人',
                    'type_name': 'string[]',
                    'editor': 'userSelector',
                    'scope': [{'object_type': 'Entity'}],
                    'range': {},
                    'is_custom': False,
                    'is_read_only': False,
                },
                'uuid-123': {
                    'display_name': '文件属性',
                    'type_name': 'int[]',
                    'editor': 'fileSelectorEditor',
                    'scope': [{'object_type': 'Entity'}],
                    'range': {},
                    'is_custom': True,
                    'is_read_only': False,
                },
            }
        }
        self.mock_api.am_get_all_properties.return_value = mock_result
        
        # 创建 SchemaManager
        self.schemas = SchemaManager(self.mock_api, 'test_hub')
        
    def test_getitem(self):
        """测试字典访问"""
        schema = self.schemas['name']
        self.assertEqual(schema['display_name'], '名称')
        self.assertEqual(schema['type_name'], 'string')
        
    def test_getitem_not_found(self):
        """测试访问不存在的属性"""
        with self.assertRaises(KeyError):
            _ = self.schemas['nonexistent']
            
    def test_get(self):
        """测试 get 方法"""
        schema = self.schemas.get('name')
        self.assertIsNotNone(schema)
        
        schema = self.schemas.get('nonexistent')
        self.assertIsNone(schema)
        
        schema = self.schemas.get('nonexistent', {'default': True})
        self.assertEqual(schema, {'default': True})
        
    def test_search(self):
        """测试搜索"""
        results = self.schemas.search('文件')
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['id'], 'uuid-123')
        
        results = self.schemas.search('人')
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['id'], 'artist')
        
    def test_find(self):
        """测试精确查找"""
        schema = self.schemas.find(display_name='名称')
        self.assertIsNotNone(schema)
        self.assertEqual(schema['id'], 'name')
        
        schema = self.schemas.find(display_name='不存在的属性')
        self.assertIsNone(schema)
        
    def test_list_by_editor(self):
        """测试按编辑器过滤"""
        results = self.schemas.list(editor='fileSelectorEditor')
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['id'], 'uuid-123')
        
    def test_list_by_scope(self):
        """测试按 scope 过滤"""
        results = self.schemas.list(scope='Entity')
        self.assertEqual(len(results), 3)
        
    def test_len(self):
        """测试获取总数"""
        self.assertEqual(len(self.schemas), 3)


if __name__ == '__main__':
    unittest.main()
