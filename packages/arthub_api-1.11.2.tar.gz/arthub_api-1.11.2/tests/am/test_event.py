# -*- coding: utf-8 -*-
"""测试 Event 和 EventFilter"""
from __future__ import absolute_import, print_function, unicode_literals

import sys
import os
import pytest

# 添加项目根目录到 path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from arthub_api.am._internal.event import (
    Event, Operation, Who, When, Where,
    Target, Relation,
    TargetFactory
)
from arthub_api.am._internal.event_filter import EventFilter


class TestEvent:
    """测试 Event 类"""
    
    def test_event_creation(self):
        """测试事件创建"""
        who = Who(account_name='test_user', account_id=123)
        when = When(timestamp=1766473774645044500)
        where = Where(depot_id=1, depot_name='test_depot', service_name='AssetMatrixService')
        
        target = Target(
            node_id=100,
            node_name='test_node',
            node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1, 2, 100],
            path_names=['root', 'parent', 'test_node'],
            path_types=['Project', 'Version', 'Entity']
        )
        
        event = Event(
            cmd='event:v1:create-node',
            event_id='test_id',
            timestamp='1766473774',
            session_id='session_id',
            who=who,
            when=when,
            where=where,
            operation=Operation.CREATE_NODE,
            targets=[target]
        )
        
        assert event.operation == Operation.CREATE_NODE
        assert event.who.account_name == 'test_user'
        assert len(event.targets) == 1
        assert event.target == target
        assert event.target.node_name == 'test_node'
    
    def test_event_target_property(self):
        """测试 event.target 便捷属性"""
        who = Who(account_name='test', account_id=1)
        when = When(timestamp=1766473774645044500)
        where = Where(depot_id=1, depot_name='test', service_name='AM')
        
        target1 = Target(
            node_id=1, node_name='target1', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['target1'], path_types=['Entity']
        )
        target2 = Target(
            node_id=2, node_name='target2', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[2], path_names=['target2'], path_types=['Entity']
        )
        
        event = Event(
            cmd='test', event_id='1', timestamp='1', session_id='s1',
            who=who, when=when, where=where,
            operation=Operation.CREATE_NODE,
            targets=[target1, target2]
        )
        
        # event.target 返回第一个
        assert event.target == target1
        assert event.target.node_name == 'target1'
        
        # event.targets 返回所有
        assert event.targets == [target1, target2]
        assert len(event.targets) == 2
    
    def test_event_updated_fields(self):
        """测试 event.updated_fields 便捷属性"""
        who = Who(account_name='test', account_id=1)
        when = When(timestamp=1766473774645044500)
        where = Where(depot_id=1, depot_name='test', service_name='AM')
        
        # 使用动态属性 Target
        target1 = Target(
            node_id=1, node_name='node1', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['node1'], path_types=['Entity'],
            raw_data={
                'updated_field_name': 'estimate_end_date',
                'updated_field_display_name': '预计结束时间',
                'updated_field_old_value': 'null',
                'updated_field_new_value': '1766591999999'
            }
        )
        
        target2 = Target(
            node_id=1, node_name='node1', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['node1'], path_types=['Entity'],
            raw_data={
                'updated_field_name': 'time_left',
                'updated_field_display_name': '剩余时间',
                'updated_field_old_value': '""',
                'updated_field_new_value': '"剩1天"'
            }
        )
        
        event = Event(
            cmd='event:v1:update-property',
            event_id='1', timestamp='1', session_id='s1',
            who=who, when=when, where=where,
            operation=Operation.UPDATE_PROPERTY,
            targets=[target1, target2]
        )
        
        # updated_fields 返回所有字段名
        fields = event.updated_fields
        assert 'estimate_end_date' in fields
        assert 'time_left' in fields
        assert len(fields) == 2
        
        # 验证动态属性
        assert hasattr(target1, 'updated_field_name')
        assert target1.updated_field_name == 'estimate_end_date'
    
    def test_event_no_targets(self):
        """测试没有 targets 的事件"""
        who = Who(account_name='test', account_id=1)
        when = When(timestamp=1766473774645044500)
        where = Where(depot_id=1, depot_name='test', service_name='AM')
        
        event = Event(
            cmd='test', event_id='1', timestamp='1', session_id='s1',
            who=who, when=when, where=where,
            operation=Operation.CREATE_NODE,
            targets=[]
        )
        
        assert event.target is None
        assert event.targets == []
        assert event.updated_fields == []


class TestTargetDynamicProperties:
    """测试 Target 动态属性"""
    
    def test_target_update_property_attributes(self):
        """测试 Target 的 update-property 动态属性"""
        target = Target(
            node_id=100,
            node_name='test_node',
            node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1, 2, 100],
            path_names=['root', 'parent', 'test_node'],
            path_types=['Project', 'Version', 'Entity'],
            raw_data={
                'updated_field_name': 'artist',
                'updated_field_display_name': '美术师',
                'updated_field_old_value': '["user1"]',
                'updated_field_new_value': '["user1", "user2"]'
            }
        )
        
        assert target.node_id == 100
        # 验证动态属性存在
        assert hasattr(target, 'updated_field_name')
        assert target.updated_field_name == 'artist'
        assert target.updated_field_display_name == '美术师'
        assert target.updated_field_old_value == '["user1"]'
        assert target.updated_field_new_value == '["user1", "user2"]'


    def test_target_move_node_attributes(self):
        """测试 Target 的 move-node 动态属性"""
        raw_data = {
            'node_id': 100,
            'node_name': 'moved_node',
            'node_type': 'Entity',
            '_relations': [
                {
                    'relation': 'parent',
                    'target': {
                        'asset_matrix': {
                            'parent_node_id': 200,
                            'parent_node_name': 'new_parent',
                            'parent_node_type': 'Version'
                        }
                    }
                },
                {
                    'relation': 'source',
                    'target': {
                        'asset_matrix': {
                            'source_node_id': 300,
                            'source_node_name': 'old_parent',
                            'source_node_type': 'Version',
                            'path_ids': [1, 2, 300],
                            'path_names': ['root', 'proj', 'old_parent']
                        }
                    }
                }
            ]
        }
        
        target = Target(
            node_id=100,
            node_name='moved_node',
            node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1, 2, 200, 100],
            path_names=['root', 'proj', 'new_parent', 'moved_node'],
            path_types=['Project', 'Project', 'Version', 'Entity'],
            raw_data=raw_data
        )
        
        # 验证动态属性存在
        assert hasattr(target, 'parent')
        assert hasattr(target, 'source')
        
        assert target.parent is not None
        assert target.parent.node_id == 200
        assert target.parent.node_name == 'new_parent'
        assert target.parent.node_type == 'Version'
        
        assert target.source is not None
        assert target.source.node_id == 300
        assert target.source.node_name == 'old_parent'
        assert target.source.path_names == ['root', 'proj', 'old_parent']


class TestEventFilter:
    """测试 EventFilter"""
    
    def _create_test_event(self, operation, targets):
        """创建测试事件"""
        who = Who(account_name='test_user', account_id=123)
        when = When(timestamp=1766473774645044500)
        where = Where(depot_id=1, depot_name='test_depot', service_name='AM')
        
        return Event(
            cmd='test', event_id='1', timestamp='1', session_id='s1',
            who=who, when=when, where=where,
            operation=operation,
            targets=targets
        )
    
    def test_filter_operation(self):
        """测试操作类型过滤"""
        target = Target(
            node_id=1, node_name='test', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['test'], path_types=['Entity']
        )
        
        event1 = self._create_test_event(Operation.CREATE_NODE, [target])
        event2 = self._create_test_event(Operation.DELETE_NODE, [target])
        
        filter_ = EventFilter(operations=[Operation.CREATE_NODE])
        
        assert filter_.match(event1) is True
        assert filter_.match(event2) is False
    
    def test_filter_account_name(self):
        """测试操作人过滤"""
        who1 = Who(account_name='user1', account_id=1)
        who2 = Who(account_name='user2', account_id=2)
        when = When(timestamp=1766473774645044500)
        where = Where(depot_id=1, depot_name='test', service_name='AM')
        
        target = Target(
            node_id=1, node_name='test', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['test'], path_types=['Entity']
        )
        
        event1 = Event(
            cmd='test', event_id='1', timestamp='1', session_id='s1',
            who=who1, when=when, where=where,
            operation=Operation.CREATE_NODE, targets=[target]
        )
        event2 = Event(
            cmd='test', event_id='2', timestamp='2', session_id='s2',
            who=who2, when=when, where=where,
            operation=Operation.CREATE_NODE, targets=[target]
        )
        
        filter_ = EventFilter(account_names=['user1'])
        
        assert filter_.match(event1) is True
        assert filter_.match(event2) is False
    
    def test_filter_node_types_any_mode(self):
        """测试节点类型过滤（ANY 模式）"""
        target1 = Target(
            node_id=1, node_name='t1', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['t1'], path_types=['Entity']
        )
        target2 = Target(
            node_id=2, node_name='t2', node_type='Stage',
            node_type_display_name='环节',
            path_ids=[2], path_names=['t2'], path_types=['Stage']
        )
        
        event = self._create_test_event(Operation.CREATE_NODE, [target1, target2])
        
        # ANY 模式：只要有一个 Entity 就匹配
        filter_ = EventFilter(node_types=['Entity'], match_mode='any')
        assert filter_.match(event) is True
        
        # 没有匹配的
        filter2 = EventFilter(node_types=['Project'], match_mode='any')
        assert filter2.match(event) is False
    
    def test_filter_node_types_all_mode(self):
        """测试节点类型过滤（ALL 模式）"""
        target1 = Target(
            node_id=1, node_name='t1', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['t1'], path_types=['Entity']
        )
        target2 = Target(
            node_id=2, node_name='t2', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[2], path_names=['t2'], path_types=['Entity']
        )
        target3 = Target(
            node_id=3, node_name='t3', node_type='Stage',
            node_type_display_name='环节',
            path_ids=[3], path_names=['t3'], path_types=['Stage']
        )
        
        event1 = self._create_test_event(Operation.CREATE_NODE, [target1, target2])
        event2 = self._create_test_event(Operation.CREATE_NODE, [target1, target3])
        
        # ALL 模式：所有 targets 都必须是 Entity
        filter_ = EventFilter(node_types=['Entity'], match_mode='all')
        assert filter_.match(event1) is True   # 两个都是 Entity
        assert filter_.match(event2) is False  # 有一个是 Stage
    
    def test_filter_updated_fields_any_mode(self):
        """测试字段过滤（ANY 模式）"""
        target1 = Target(
            node_id=1, node_name='node1', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['node1'], path_types=['Entity'],
            raw_data={
                'updated_field_name': 'estimate_end_date',
                'updated_field_display_name': '预计结束时间'
            }
        )
        target2 = Target(
            node_id=1, node_name='node1', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['node1'], path_types=['Entity'],
            raw_data={
                'updated_field_name': 'time_left',
                'updated_field_display_name': '剩余时间'
            }
        )
        target3 = Target(
            node_id=1, node_name='node1', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['node1'], path_types=['Entity'],
            raw_data={
                'updated_field_name': 'artist',
                'updated_field_display_name': '美术师'
            }
        )
        
        event1 = self._create_test_event(
            Operation.UPDATE_PROPERTY,
            [target1, target2]  # 包含 estimate_end_date
        )
        event2 = self._create_test_event(
            Operation.UPDATE_PROPERTY,
            [target3]  # 只有 artist
        )
        
        # ANY 模式：只要有一个字段匹配就通过
        filter_ = EventFilter(
            updated_fields=['estimate_end_date'],
            match_mode='any'
        )
        
        assert filter_.match(event1) is True   # 包含 estimate_end_date
        assert filter_.match(event2) is False  # 不包含
    
    def test_filter_path_contains(self):
        """测试路径过滤"""
        target1 = Target(
            node_id=1, node_name='test_task', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1, 2, 3],
            path_names=['root', 'test_project', 'test_task'],
            path_types=['Project', 'Version', 'Entity']
        )
        target2 = Target(
            node_id=2, node_name='prod_task', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1, 4, 5],
            path_names=['root', 'prod_project', 'prod_task'],
            path_types=['Project', 'Version', 'Entity']
        )
        
        event1 = self._create_test_event(Operation.CREATE_NODE, [target1])
        event2 = self._create_test_event(Operation.CREATE_NODE, [target2])
        
        # 路径包含 'test'
        filter_ = EventFilter(path_contains=['test'])
        
        assert filter_.match(event1) is True
        assert filter_.match(event2) is False
    
    def test_filter_custom(self):
        """测试自定义过滤器"""
        target = Target(
            node_id=1, node_name='test', node_type='Entity',
            node_type_display_name='实体',
            path_ids=[1], path_names=['test'], path_types=['Entity']
        )
        
        event = self._create_test_event(Operation.CREATE_NODE, [target])
        
        # 自定义：只接受工作时间的事件
        def worktime_only(evt):
            hour = evt.when.datetime.hour
            return 9 <= hour <= 18
        
        filter_ = EventFilter(custom=worktime_only)
        
        # 结果取决于测试运行时间
        result = filter_.match(event)
        assert isinstance(result, bool)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

