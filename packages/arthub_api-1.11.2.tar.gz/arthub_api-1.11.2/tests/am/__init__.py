# -*- coding: utf-8 -*-
"""AM SDK 测试"""
from __future__ import absolute_import, print_function, unicode_literals
