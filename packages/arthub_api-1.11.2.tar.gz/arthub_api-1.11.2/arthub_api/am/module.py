# -*- coding: utf-8 -*-
"""模块 (Module) 定义和管理"""
from __future__ import absolute_import, print_function, unicode_literals


class Module(object):
    """AM 模块定义
    
    封装单个模块的完整信息，包括名称、显示名称、依赖关系、颜色配置等。
    
    Attributes:
        name: 模块名称/ID (str)
        display_name: 显示名称 (str)
        param_index: 排序索引 (int)
        pre_modules: 前置依赖模块列表 (list)
        post_modules: 后置依赖模块列表 (list)
        color: UI 颜色 (str)
        is_custom: 是否自定义模块 (bool)
        people_level: 人员级别列表 (list)
        people_level_color: 人员级别颜色列表 (list)
        is_deleted: 是否已删除 (bool)
    
    Example:
        module = session.modules['e3729496-2c09-553a-8c4a-854d0e3c0b96']
        print(module.display_name)  # '模型'
        print(module.param_index)   # 7
        print(module.color)         # '#13D1B6'
        
        # 检查依赖关系
        if module.has_dependencies():
            print("前置模块:", module.pre_modules)
            print("后置模块:", module.post_modules)
        
        # 字典式访问（向后兼容）
        print(module['display_name'])
    """
    
    def __init__(self, data):
        # type: (dict) -> None
        """初始化 Module
        
        Args:
            data: 模块数据字典
        """
        self.name = data.get('name')
        self.display_name = data.get('display_name', '')
        self.param_index = data.get('param_index', 0)
        self.pre_modules = data.get('pre_modules', [])
        self.post_modules = data.get('post_modules', [])
        self.color = data.get('color', '')
        self.is_custom = data.get('is_custom', False)
        self.people_level = data.get('people_level', [])
        self.people_level_color = data.get('people_level_color', [])
        self.is_deleted = data.get('is_deleted', False)
        
        # 保存原始数据用于字典访问
        self._data = data
    
    def has_dependencies(self):
        # type: () -> bool
        """是否有依赖关系（前置或后置模块）
        
        Returns:
            bool: True 表示有依赖关系
        """
        return bool(self.pre_modules or self.post_modules)
    
    def get_all_dependencies(self):
        # type: () -> list
        """获取所有依赖模块（前置 + 后置）
        
        Returns:
            list: 依赖模块名称列表
        """
        return list(self.pre_modules) + list(self.post_modules)
    
    def to_dict(self):
        # type: () -> dict
        """转换为字典
        
        Returns:
            dict: 模块数据字典
        """
        return {
            'name': self.name,
            'display_name': self.display_name,
            'param_index': self.param_index,
            'pre_modules': self.pre_modules,
            'post_modules': self.post_modules,
            'color': self.color,
            'is_custom': self.is_custom,
            'people_level': self.people_level,
            'people_level_color': self.people_level_color,
            'is_deleted': self.is_deleted,
        }
    
    def __getitem__(self, key):
        # type: (str) -> object
        """字典式访问（向后兼容）
        
        Args:
            key: 属性名
            
        Returns:
            属性值
        """
        return self._data.get(key)
    
    def get(self, key, default=None):
        # type: (str, object) -> object
        """安全获取属性值
        
        Args:
            key: 属性名
            default: 默认值
            
        Returns:
            属性值或默认值
        """
        return self._data.get(key, default)
    
    def __repr__(self):
        # type: () -> str
        return "<Module '{}' ({})>".format(
            self.display_name,
            self.name[:8] + '...' if len(self.name) > 8 else self.name
        )
    
    def __str__(self):
        # type: () -> str
        return self.display_name


class ModuleManager(object):
    """模块管理器
    
    负责加载和查询模块定义，提供多种查询方式。
    设计参考 SchemaManager，保持项目风格一致性。
    
    Example:
        # 通过 Session 访问
        modules = session.modules
        
        # 通过 name 获取（字典访问）
        module = modules['e3729496-2c09-553a-8c4a-854d0e3c0b96']
        
        # 查找模块
        module = modules.find(display_name='模型')
        module = modules.find(name='e3729496-2c09-553a-8c4a-854d0e3c0b96')
        
        # 获取所有模块
        all_modules = modules.all()
        
        # 按排序索引排序
        sorted_modules = modules.sorted()
        
        # 搜索模块
        results = modules.search('模型')
    """
    
    def __init__(self, open_api, asset_hub):
        # type: (object, str) -> None
        """初始化并加载模块
        
        Args:
            open_api: OpenAPI 实例
            asset_hub: Asset Hub 名称
        """
        self._modules = []  # type: list[Module]
        self._by_name = {}  # type: dict[str, Module]
        self._by_display_name = {}  # type: dict[str, Module]
        self._load_modules(open_api, asset_hub)
    
    def _load_modules(self, open_api, asset_hub):
        # type: (object, str) -> None
        """从服务器加载模块定义"""
        result = open_api.am_get_all_modules(asset_hub)
        if result.is_succeeded():
            module_data_list = result.result or []
            
            for data in module_data_list:
                if isinstance(data, dict):
                    module = Module(data)
                    self._modules.append(module)
                    
                    # 建立索引
                    if module.name:
                        self._by_name[module.name] = module
                    if module.display_name:
                        self._by_display_name[module.display_name] = module
    
    def __getitem__(self, name):
        # type: (str) -> Module
        """通过 name 获取模块（字典访问）
        
        Args:
            name: 模块名称/ID
            
        Returns:
            Module: 模块对象
            
        Raises:
            KeyError: 如果模块不存在
        """
        if name not in self._by_name:
            raise KeyError("Module '{}' not found".format(name))
        return self._by_name[name]
    
    def get(self, name, default=None):
        # type: (str, object) -> object
        """安全获取模块
        
        Args:
            name: 模块名称/ID
            default: 默认值
            
        Returns:
            Module 对象或默认值
        """
        return self._by_name.get(name, default)
    
    def find(self, name=None, display_name=None):
        # type: (object, object) -> object
        """查找模块
        
        Args:
            name: 模块名称/ID
            display_name: 模块显示名称
            
        Returns:
            Module: 模块对象或 None
            
        Example:
            module = modules.find(display_name='模型')
            if module:
                print(module.name)
        """
        if name:
            return self._by_name.get(name)
        if display_name:
            return self._by_display_name.get(display_name)
        return None
    
    def all(self):
        # type: () -> list
        """返回所有模块列表
        
        Returns:
            list: Module 对象列表
            
        Example:
            for module in session.modules.all():
                print(module.display_name)
        """
        return self._modules
    
    def sorted(self):
        # type: () -> list
        """返回按 param_index 排序的模块列表
        
        Returns:
            list: 排序后的 Module 对象列表
            
        Example:
            for module in session.modules.sorted():
                print("{}: {}".format(module.param_index, module.display_name))
        """
        return sorted(self._modules, key=lambda m: m.param_index)
    
    def search(self, keyword):
        # type: (str) -> list
        """搜索模块（模糊匹配 display_name）
        
        Args:
            keyword: 搜索关键字
            
        Returns:
            list: 匹配的 Module 对象列表
            
        Example:
            results = session.modules.search('模型')
            for module in results:
                print(module.display_name)
        """
        keyword_lower = keyword.lower()
        results = []
        for module in self._modules:
            if keyword_lower in module.display_name.lower():
                results.append(module)
        return results
    
    def __len__(self):
        # type: () -> int
        """模块总数"""
        return len(self._modules)
    
    def __iter__(self):
        # type: () -> object
        """支持迭代"""
        return iter(self._modules)

