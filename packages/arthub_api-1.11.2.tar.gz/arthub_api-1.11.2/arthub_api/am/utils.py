# -*- coding: utf-8 -*-
"""AM 工具函数

提供任务树的打印、遍历等工具函数。
"""
from __future__ import absolute_import, print_function, unicode_literals


def print_tree(tasks, indent=0, show_match=False):
    # type: (list, int, bool) -> None
    """打印任务树结构
    
    递归打印任务列表及其所有子任务，以缩进形式显示层级关系。
    
    Args:
        tasks: 任务列表（树形结构的根节点列表）
        indent: 初始缩进层级（默认 0）
        show_match: 是否显示 filter 匹配状态（默认 False）
            - False: 只显示任务名称
            - True: 在名称前显示 ✓（匹配）或 ○（不匹配）
    
    Example:
        from arthub_api.am import utils
        
        # 打印整个任务树
        tree = version.get_task_tree()
        utils.print_tree(tree)
        
        # 显示 filter 匹配状态
        filtered_tree = version.filter_task_tree(filter_dsl)
        utils.print_tree(filtered_tree, show_match=True)
        
        # 输出示例：
        # - 任务A
        #   - 子任务A-1
        #   - 子任务A-2
        # - 任务B
    """
    if not tasks:
        return
    
    for task in tasks:
        _print_task_recursive(task, indent, show_match)


def _print_task_recursive(task, indent, show_match):
    # type: (object, int, bool) -> None
    """递归打印单个任务及其子任务（内部函数）
    
    Args:
        task: Task 实例
        indent: 缩进层级
        show_match: 是否显示匹配状态
    """
    prefix = "  " * indent + "- "
    
    name = task.properties.get('name', 'N/A')
    if show_match:
        match_marker = "✓ " if task.is_match_filter else "○ "
        print("{}{}{}".format(prefix, match_marker, name))
    else:
        print("{}{}".format(prefix, name))
    
    # 递归打印子任务
    for child in task.children:
        _print_task_recursive(child, indent + 1, show_match)


def walk(root):
    # type: (object) -> object
    """深度优先遍历任务树
    
    生成器方法，按深度优先顺序遍历任务及其所有子任务。
    
    Args:
        root: 根任务节点
        
    Yields:
        tuple: (task, depth) 元组
            - task: Task 实例
            - depth: 相对于根节点的深度（根节点为 0）
    
    Example:
        from arthub_api.am import utils
        
        tree = version.get_task_tree()
        root = tree[0]
        
        # 遍历并打印
        for task, depth in utils.walk(root):
            indent = "  " * depth
            print("{}{}".format(indent, task.properties.get('name')))
        
        # 统计各层任务数
        depth_counts = {}
        for task, depth in utils.walk(root):
            depth_counts[depth] = depth_counts.get(depth, 0) + 1
        print(depth_counts)  # {0: 1, 1: 3, 2: 2}
        
        # 查找所有匹配的叶子节点
        for task, depth in utils.walk(root):
            if task.is_match_filter and not task.children:
                print("Matched leaf: {}".format(task.properties.get('name')))
    """
    # 生成器实现深度优先遍历
    yield root, 0
    for child in root.children:
        for task, d in walk(child):
            yield task, d + 1


def flatten_tree(tree):
    # type: (list) -> list
    """将树形结构转为扁平列表
    
    将根任务列表及其所有子任务展开为扁平列表。
    
    Args:
        tree: 根任务列表
        
    Returns:
        list: 扁平的任务列表（深度优先顺序）
    
    Example:
        from arthub_api.am import utils
        
        tree = version.get_task_tree()
        flat_list = utils.flatten_tree(tree)
        
        print("树形结构有 {} 个根任务".format(len(tree)))
        print("扁平列表有 {} 个任务".format(len(flat_list)))
        
        for task in flat_list:
            print(task.properties.get('name'))
    """
    result = []
    for root in tree:
        for task, _ in walk(root):
            result.append(task)
    return result

