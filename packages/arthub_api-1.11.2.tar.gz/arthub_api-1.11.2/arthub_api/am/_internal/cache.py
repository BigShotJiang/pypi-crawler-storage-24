# -*- coding: utf-8 -*-
"""Node 实例缓存"""
from __future__ import absolute_import, print_function, unicode_literals


class NodeCache(object):
    """简单的 Node 实例缓存
    
    使用 (node_type, node_id) 作为键存储 Node 实例，
    避免同一个节点创建多个实例。
    
    Example:
        cache = NodeCache()
        cache.put('Task', 123, task_instance)
        cached = cache.get('Task', 123)
    """
    
    def __init__(self):
        # type: () -> None
        self._cache = {}  # type: dict
        
    def get(self, node_type, node_id):
        # type: (str, int) -> object
        """获取缓存的 Node
        
        Args:
            node_type: 节点类型 ('Project', 'Version', 'Task')
            node_id: 节点 ID
            
        Returns:
            Node 实例或 None
        """
        return self._cache.get((node_type, node_id))
        
    def put(self, node_type, node_id, node):
        # type: (str, int, object) -> None
        """放入缓存
        
        Args:
            node_type: 节点类型
            node_id: 节点 ID
            node: Node 实例
        """
        self._cache[(node_type, node_id)] = node
        
    def clear(self):
        # type: () -> None
        """清空缓存"""
        self._cache.clear()
        
    def __len__(self):
        # type: () -> int
        """缓存的节点数量"""
        return len(self._cache)
