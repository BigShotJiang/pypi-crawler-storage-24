# -*- coding: utf-8 -*-
"""属性加载和更新"""
from __future__ import absolute_import, print_function, unicode_literals


class PropertyLoader(object):
    """封装属性加载逻辑
    
    内部使用 am_get_node_brief (对应后端的 get-node-brief 接口)
    和 am_update_task_properties 实现属性的读写。
    
    Example:
        loader = PropertyLoader(open_api, asset_hub)
        props = loader.load_node_properties([task_id])
        loader.update_node_properties([task_id], {'name': 'New Name'})
    """
    
    def __init__(self, open_api, asset_hub):
        # type: (object, str) -> None
        """初始化
        
        Args:
            open_api: OpenAPI 实例
            asset_hub: Asset Hub 名称
        """
        self._open_api = open_api
        self._asset_hub = asset_hub
        
    def load_node_properties(self, node_ids):
        # type: (list) -> list
        """加载节点属性（支持批量）
        
        内部调用 am_get_node_brief，返回节点详细信息列表。
        对应后端的 get-node-brief 接口。
        
        Args:
            node_ids: 节点 ID 列表
            
        Returns:
            list: 节点详细信息列表，与 node_ids 顺序对应
                  每个元素包含：
                  - properties: 属性值字典
                  - property_permission: 属性权限字典 (r=只读, rw=可读写, rwD=可读写删除)
                  - workflow_state: 工作流状态
                  等其他信息
                  
        Example:
            # 单个节点
            results = loader.load_node_properties([task_id])
            if results:
                node_info = results[0]
                props = node_info.get('properties', {})
                permissions = node_info.get('property_permission', {})
            
            # 批量加载
            results = loader.load_node_properties([id1, id2, id3])
            for node_info in results:
                print(node_info.get('properties', {}).get('name'))
        """
        result = self._open_api.am_get_node_brief(
            self._asset_hub,
            node_ids
        )
        if result.is_succeeded():
            # am_get_node_brief 返回完整的节点信息，包括 properties 和 property_permission
            return result.result if result.result else []
        return []
        
    def load_node_selected_properties(self, node_ids, properties):
        # type: (list, list) -> list
        """按需加载节点的指定属性
        
        内部调用 am_get_node_properties，只返回指定的属性值。
        对应后端的 get-node-properties 接口。
        
        Args:
            node_ids: 节点 ID 列表
            properties: 需要获取的属性名列表，如 ["linked_preview_id", "linked_progress_id"]
            
        Returns:
            list: 节点属性信息列表，与 node_ids 顺序对应
                  每个元素包含指定属性的值
                  
        Example:
            results = loader.load_node_selected_properties(
                [task_id], 
                ["linked_preview_id", "linked_progress_id"]
            )
            if results:
                props = results[0]
        """
        result = self._open_api.am_get_node_properties(
            self._asset_hub,
            node_ids,
            properties
        )
        if result.is_succeeded():
            return result.result if result.result else []
        return []
        
    def update_node_properties(self, node_ids, properties):
        # type: (list, dict) -> bool
        """更新节点属性
        
        Args:
            node_ids: 节点 ID 列表
            properties: 要更新的属性字典
            
        Returns:
            bool: 是否成功
        """
        result = self._open_api.am_update_task_properties(
            self._asset_hub,
            node_ids,
            properties
        )
        return result.is_succeeded()
