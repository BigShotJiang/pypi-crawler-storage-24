# -*- coding: utf-8 -*-
"""事件过滤器"""
from __future__ import print_function

from .event import Event, Operation, Target

class EventFilter(object):
    """事件过滤器
    
    分为两层过滤：
    1. 高级过滤（业务概念）：version_* - 易用
    2. 通用过滤：node_* - 灵活
    
    匹配模式：
    - 'any': 只要有一个 target 匹配条件就通过（默认）
    - 'all': 所有 targets 都必须匹配条件才通过
    
    自定义过滤：
    - custom: 接收一个函数，签名为 func(event) -> bool
              返回 True 表示匹配，False 表示不匹配
    
    Example:
        # 基础过滤
        filter1 = EventFilter(node_types=['Entity'])
        
        # 自定义过滤
        def only_weekdays(event):
            return event.when.datetime.weekday() < 5
        
        filter2 = EventFilter(
            node_types=['Entity'],
            custom=only_weekdays
        )
    """
    
    def __init__(self, operations=None, account_names=None,
                 version_ids=None, version_names=None,
                 node_ids=None, node_names=None, node_types=None,
                 updated_fields=None,
                 move_to_ids=None, move_from_ids=None,
                 custom=None, match_mode='any'):
        # type: (object, object, object, object, object, object, object, object, object, object, object, str) -> None
        # 基础过滤
        self.operations = operations
        self.account_names = account_names
        
        # 版本过滤
        self.version_ids = version_ids
        self.version_names = version_names
        
        # 节点过滤
        self.node_ids = node_ids
        self.node_names = node_names
        self.node_types = node_types
        
        # 操作专用过滤
        self.updated_fields = updated_fields
        self.move_to_ids = move_to_ids
        self.move_from_ids = move_from_ids
        
        # 高级功能
        self.custom = custom
        self.match_mode = match_mode
    
    @classmethod
    def for_version(cls, version_name, **kwargs):
        # type: (type, str, **dict) -> EventFilter
        """监听特定版本下的所有事件"""
        kwargs['version_names'] = [version_name]
        return cls(**kwargs)
    
    @classmethod
    def for_tasks(cls, version_name=None, task_names=None, task_types=None, **kwargs):
        # type: (type, object, object, object, **dict) -> EventFilter
        """监听任务事件（工厂方法，内部转换为 node_* 参数）"""
        if version_name:
            kwargs['version_names'] = [version_name]
        if task_names:
            kwargs['node_names'] = task_names
        if task_types:
            kwargs['node_types'] = task_types
        return cls(**kwargs)
    
    def match(self, event):
        # type: (Event) -> bool
        """检查事件是否匹配"""
        # 1. 检查事件级别的过滤条件
        if self.operations and event.operation not in self.operations:
            return False
        
        if self.account_names and event.who.account_name not in self.account_names:
            return False
        
        if self.custom and not self.custom(event):
            return False
        
        # 2. 检查 target 级别的过滤条件
        if not event.targets:
            return True
        
        if self.match_mode == 'all':
            return self._match_all(event.targets)
        else:  # 'any'
            return self._match_any(event.targets)
    
    def _match_any(self, targets):
        # type: (list) -> bool
        """只要有一个 target 匹配就返回 True"""
        for target in targets:
            if self._match_target(target):
                return True
        return False
    
    def _match_all(self, targets):
        # type: (list) -> bool
        """所有 targets 都必须匹配才返回 True"""
        for target in targets:
            if not self._match_target(target):
                return False
        return True
    
    def _match_target(self, target):
        # type: (Target) -> bool
        """检查单个 target 是否匹配所有条件"""
        # 版本过滤 (path 结构: [Project, Version, Task...])
        if self.version_names and len(target.path_names) > 1:
            version_name = target.path_names[1]
            if version_name not in self.version_names:
                return False
        
        if self.version_ids and len(target.path_ids) > 1:
            version_id = target.path_ids[1]
            if version_id not in self.version_ids:
                return False
        
        # 节点过滤
        if self.node_ids and target.node_id not in self.node_ids:
            return False
        
        if self.node_names and target.node_name not in self.node_names:
            return False
        
        if self.node_types and target.node_type not in self.node_types:
            return False
        
        # 属性更新专用过滤
        if self.updated_fields:
            if not hasattr(target, 'updated_field_name') or target.updated_field_name not in self.updated_fields:
                return False
        
        # 移动节点专用过滤
        if self.move_to_ids:
            if not hasattr(target, 'parent') or not target.parent or target.parent.node_id not in self.move_to_ids:
                return False
        
        if self.move_from_ids:
            if not hasattr(target, 'source') or not target.source or target.source.node_id not in self.move_from_ids:
                return False
        
        return True