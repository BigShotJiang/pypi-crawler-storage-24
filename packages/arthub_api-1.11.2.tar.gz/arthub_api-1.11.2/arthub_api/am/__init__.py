# -*- coding: utf-8 -*-
"""Asset Matrix 高级 API (V2)

这是 Asset Matrix Python SDK 的高级封装，提供面向对象的接口。

Example:
    from arthub_api.am import Session
    
    # 初始化
    session = Session()
    project = session.project
    
    # 遍历层级
    for version in project.versions:
        for task in version.tasks:
            print(task['name'])
            
    # 过滤查询
    filter_dsl = [{
        "bool": {"must": [
            {"item": {"meta": "artist", "condition": "contains_any", "value": ["kazenzhong"]}}
        ]}
    }]
    my_tasks = version.filter_tasks(filter_dsl)
    
    # 修改属性
    task['name'] = 'New Name'
    task.commit()
    
    # 属性发现
    schema = session.schemas['name']
    print(schema['display_name'])
    print(task.properties)  # 友好的属性视图
"""
from __future__ import absolute_import, print_function, unicode_literals

from .session import Session
from .node import Node, Project, Version, Task
from .module import Module, ModuleManager
from .workflow import Workflow, WorkflowState, WorkflowManager
from .exceptions import (
    AMAPIError,
    AMConnectionError,
    AMAuthError,
    AMNotFoundError,
    AMValidationError,
)
from . import utils
from . import types

# WebSocket 事件相关（用户友好的公共 API）
from ._internal.event import Event, Operation, Target, Who, When, Where
from ._internal.event_filter import EventFilter

__all__ = [
    'Session',
    'Node',
    'Project',
    'Version',
    'Task',
    'Module',
    'ModuleManager',
    'Workflow',
    'WorkflowState',
    'WorkflowManager',
    'utils',
    'types',
    'AMAPIError',
    'AMConnectionError',
    'AMAuthError',
    'AMNotFoundError',
    'AMValidationError',
    # WebSocket 事件
    'EventFilter',
    'Event',
    'Operation',
    'Target',
    'Who',
    'When',
    'Where',
]

__version__ = '0.0.5'
