# -*- coding: utf-8 -*-
"""工作流 (Workflow) 定义和管理"""
from __future__ import absolute_import, print_function, unicode_literals


class WorkflowState(object):
    """工作流状态定义
    
    封装工作流中的单个状态节点信息，包括名称、显示名称、类型等。
    
    Attributes:
        id: 状态 ID (int)
        name: 状态名称 (str), 如 "open", "progressing", "done"
        display_name: 显示名称 (str), 如 "未开始", "进行中", "已完成"
        type: 状态类型 (str), 如 "未开始", "进行中", "已暂停", "已完成"
        workflow_id: 所属工作流 ID (int)
        idx: 排序索引 (int)
    
    Example:
        # 通过 Workflow 获取状态
        workflow = session.workflows[workflow_id]
        state = workflow.get_state_by_id(state_id)
        
        print(state.display_name)  # '进行中'
        print(state.type)          # '进行中'
        
        # 字典式访问（向后兼容）
        print(state['name'])       # 'progressing'
    """
    
    def __init__(self, data):
        # type: (dict) -> None
        """初始化 WorkflowState
        
        Args:
            data: 状态数据字典
        """
        self.id = data.get('id')  # type: int
        self.name = data.get('name', '')  # type: str
        self.display_name = data.get('display_name', '')  # type: str
        self.type = data.get('type', '')  # type: str
        self.workflow_id = data.get('workflow_id')  # type: int
        self.idx = data.get('idx', 0)  # type: int
        
        # 保存原始数据用于字典访问
        self._data = data
    
    def to_dict(self):
        # type: () -> dict
        """转换为字典
        
        Returns:
            dict: 状态数据字典
        """
        return {
            'id': self.id,
            'name': self.name,
            'display_name': self.display_name,
            'type': self.type,
            'workflow_id': self.workflow_id,
            'idx': self.idx,
        }
    
    def __getitem__(self, key):
        # type: (str) -> object
        """字典式访问（向后兼容）
        
        Args:
            key: 属性名
            
        Returns:
            属性值
        """
        return self._data.get(key)
    
    def get(self, key, default=None):
        # type: (str, object) -> object
        """安全获取属性值
        
        Args:
            key: 属性名
            default: 默认值
            
        Returns:
            属性值或默认值
        """
        return self._data.get(key, default)
    
    def __repr__(self):
        # type: () -> str
        return "<WorkflowState '{}' (id={})>".format(self.display_name, self.id)
    
    def __str__(self):
        # type: () -> str
        return self.display_name


class Workflow(object):
    """工作流定义
    
    封装完整的工作流定义，包含所有状态节点和状态转换规则。
    
    Attributes:
        id: 工作流 ID (int)
        name: 工作流名称 (str), 如 "am_default_workflow"
        display_name: 显示名称 (str), 如 "基础工作流"
        states: 状态列表 (list[WorkflowState])
        transitions: 状态转换列表 (list[dict])
        is_system: 是否为系统工作流 (bool)
        creator: 创建者 (str)
        updater: 更新者 (str)
    
    Example:
        # 获取工作流
        workflow = session.workflows[workflow_id]
        
        print(workflow.display_name)  # '基础工作流'
        print(len(workflow.states))   # 4
        
        # 查询状态
        state = workflow.get_state_by_id(state_id)
        state = workflow.get_state_by_name('progressing')
        
        # 查询转换
        transitions = workflow.get_transitions_from(state_id)
        for trans in transitions:
            next_state = workflow.get_state_by_id(trans['next'])
            print(f"{state.display_name} -> {next_state.display_name}")
        
        # 字典式访问（向后兼容）
        print(workflow['name'])
    """
    
    def __init__(self, data):
        # type: (dict) -> None
        """初始化 Workflow
        
        Args:
            data: 工作流数据字典
        """
        self.id = data.get('id')  # type: int
        self.name = data.get('name', '')  # type: str
        self.display_name = data.get('display_name', '')  # type: str
        self.is_system = data.get('is_system', False)  # type: bool
        self.creator = data.get('creator', '')  # type: str
        self.updater = data.get('updater', '')  # type: str
        
        # 解析状态列表
        self.states = []  # type: list[WorkflowState]
        self._state_by_id = {}  # type: dict[int, WorkflowState]
        self._state_by_name = {}  # type: dict[str, WorkflowState]
        
        for state_data in data.get('state', []):
            if isinstance(state_data, dict):
                state = WorkflowState(state_data)
                self.states.append(state)
                if state.id is not None:
                    self._state_by_id[state.id] = state
                if state.name:
                    self._state_by_name[state.name] = state
        
        # 保存转换列表（保持原始格式）
        self.transitions = data.get('transition', [])  # type: list[dict]
        
        # 保存原始数据用于字典访问
        self._data = data
    
    def get_state_by_id(self, state_id):
        # type: (int) -> WorkflowState
        """根据 ID 获取状态
        
        Args:
            state_id: 状态 ID
            
        Returns:
            WorkflowState: 状态对象，如果不存在返回 None
            
        Example:
            state = workflow.get_state_by_id(120347699877337)
            if state:
                print(state.display_name)  # '进行中'
        """
        return self._state_by_id.get(state_id)
    
    def get_state_by_name(self, name):
        # type: (str) -> WorkflowState
        """根据名称获取状态
        
        Args:
            name: 状态名称 (如 "open", "progressing", "done")
            
        Returns:
            WorkflowState: 状态对象，如果不存在返回 None
            
        Example:
            state = workflow.get_state_by_name('progressing')
            if state:
                print(state.display_name)  # '进行中'
        """
        return self._state_by_name.get(name)
    
    def get_transitions_from(self, state_id):
        # type: (int) -> list
        """获取从指定状态出发的所有转换
        
        Args:
            state_id: 起始状态 ID
            
        Returns:
            list: 转换字典列表，每个包含 name, previous, next, display_name 等
            
        Example:
            # 获取从"进行中"状态可以转换到的所有状态
            transitions = workflow.get_transitions_from(progressing_state_id)
            for trans in transitions:
                next_state = workflow.get_state_by_id(trans['next'])
                print(f"可转换到: {next_state.display_name} ({trans['display_name']})")
        """
        result = []
        for trans in self.transitions:
            if trans.get('previous') == state_id:
                result.append(trans)
        return result
    
    def get_transitions_to(self, state_id):
        # type: (int) -> list
        """获取转换到指定状态的所有转换
        
        Args:
            state_id: 目标状态 ID
            
        Returns:
            list: 转换字典列表
            
        Example:
            # 获取可以转换到"已完成"状态的所有来源
            transitions = workflow.get_transitions_to(done_state_id)
            for trans in transitions:
                prev_state = workflow.get_state_by_id(trans['previous'])
                print(f"可从 {prev_state.display_name} 转换过来 ({trans['display_name']})")
        """
        result = []
        for trans in self.transitions:
            if trans.get('next') == state_id:
                result.append(trans)
        return result
    
    def to_dict(self):
        # type: () -> dict
        """转换为字典
        
        Returns:
            dict: 工作流数据字典
        """
        return {
            'id': self.id,
            'name': self.name,
            'display_name': self.display_name,
            'is_system': self.is_system,
            'creator': self.creator,
            'updater': self.updater,
            'state': [s.to_dict() for s in self.states],
            'transition': self.transitions,
        }
    
    def __getitem__(self, key):
        # type: (str) -> object
        """字典式访问（向后兼容）
        
        Args:
            key: 属性名
            
        Returns:
            属性值
        """
        return self._data.get(key)
    
    def get(self, key, default=None):
        # type: (str, object) -> object
        """安全获取属性值
        
        Args:
            key: 属性名
            default: 默认值
            
        Returns:
            属性值或默认值
        """
        return self._data.get(key, default)
    
    def __repr__(self):
        # type: () -> str
        return "<Workflow '{}' (id={}, states={})>".format(
            self.display_name, self.id, len(self.states)
        )
    
    def __str__(self):
        # type: () -> str
        return self.display_name


class WorkflowManager(object):
    """工作流管理器
    
    负责加载和查询工作流定义，提供多种查询方式。
    采用懒加载策略，在首次访问时自动从服务器加载数据。
    
    Example:
        # 通过 Session 访问
        workflows = session.workflows
        
        # 通过 ID 获取（字典访问）
        workflow = workflows[120347699877335]
        
        # 安全获取（不存在返回 None）
        workflow = workflows.get(workflow_id)
        
        # 查找工作流
        workflow = workflows.find(display_name='基础工作流')
        workflow = workflows.find(name='am_default_workflow')
        
        # 获取所有工作流
        all_workflows = workflows.all()
        
        # 迭代所有工作流
        for wf in workflows:
            print(wf.display_name)
    """
    
    def __init__(self, open_api, asset_hub):
        # type: (object, str) -> None
        """初始化工作流管理器
        
        Args:
            open_api: OpenAPI 实例
            asset_hub: Asset Hub 名称
        """
        self._open_api = open_api
        self._asset_hub = asset_hub
        self._workflows = []  # type: list[Workflow]
        self._by_id = {}  # type: dict[int, Workflow]
        self._by_name = {}  # type: dict[str, Workflow]
        self._loaded = False  # type: bool
    
    def _ensure_loaded(self):
        # type: () -> None
        """确保数据已加载（懒加载）"""
        if not self._loaded:
            self._load()
    
    def _load(self):
        # type: () -> None
        """从服务器加载工作流定义"""
        result = self._open_api.am_get_all_workflows(self._asset_hub)
        if result.is_succeeded():
            workflow_data_list = result.result or []
            
            for data in workflow_data_list:
                if isinstance(data, dict):
                    workflow = Workflow(data)
                    self._workflows.append(workflow)
                    
                    # 建立索引
                    if workflow.id is not None:
                        self._by_id[workflow.id] = workflow
                    if workflow.name:
                        self._by_name[workflow.name] = workflow
        
        self._loaded = True
    
    def __getitem__(self, workflow_id):
        # type: (int) -> Workflow
        """通过 ID 获取工作流（字典访问）
        
        Args:
            workflow_id: 工作流 ID
            
        Returns:
            Workflow: 工作流对象
            
        Raises:
            KeyError: 如果工作流不存在
            
        Example:
            workflow = session.workflows[120347699877335]
        """
        self._ensure_loaded()
        if workflow_id not in self._by_id:
            raise KeyError("Workflow with id '{}' not found".format(workflow_id))
        return self._by_id[workflow_id]
    
    def get(self, workflow_id, default=None):
        # type: (int, object) -> object
        """安全获取工作流
        
        Args:
            workflow_id: 工作流 ID
            default: 默认值
            
        Returns:
            Workflow 对象或默认值
            
        Example:
            workflow = session.workflows.get(workflow_id)
            if workflow:
                print(workflow.display_name)
        """
        self._ensure_loaded()
        return self._by_id.get(workflow_id, default)
    
    def find(self, id=None, name=None, display_name=None):
        # type: (int, str, str) -> Workflow
        """查找工作流
        
        Args:
            id: 工作流 ID
            name: 工作流名称
            display_name: 工作流显示名称
            
        Returns:
            Workflow: 工作流对象或 None
            
        Example:
            workflow = workflows.find(display_name='基础工作流')
            workflow = workflows.find(name='am_default_workflow')
        """
        self._ensure_loaded()
        if id is not None:
            return self._by_id.get(id)
        if name:
            return self._by_name.get(name)
        if display_name:
            for wf in self._workflows:
                if wf.display_name == display_name:
                    return wf
        return None
    
    def all(self):
        # type: () -> list
        """返回所有工作流列表
        
        Returns:
            list: Workflow 对象列表
            
        Example:
            for workflow in session.workflows.all():
                print(workflow.display_name)
        """
        self._ensure_loaded()
        return self._workflows
    
    def __len__(self):
        # type: () -> int
        """工作流总数"""
        self._ensure_loaded()
        return len(self._workflows)
    
    def __iter__(self):
        # type: () -> object
        """支持迭代"""
        self._ensure_loaded()
        return iter(self._workflows)
    
    def __contains__(self, workflow_id):
        # type: (int) -> bool
        """检查工作流是否存在
        
        Args:
            workflow_id: 工作流 ID
            
        Returns:
            bool: 是否存在
            
        Example:
            if workflow_id in session.workflows:
                print("工作流存在")
        """
        self._ensure_loaded()
        return workflow_id in self._by_id
