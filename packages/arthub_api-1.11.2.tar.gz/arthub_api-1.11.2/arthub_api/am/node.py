# -*- coding: utf-8 -*-
"""AM Node 抽象和子类"""
from __future__ import absolute_import, print_function, unicode_literals

import logging

from .exceptions import AMAPIError

logger = logging.getLogger(__name__)


class Property(object):
    """单个属性的完整表示（值 + 元数据）
    
    封装属性的值、权限、Schema 等信息，提供统一的访问接口。
    
    Note:
        虽然类名是 Property，但通过 task.field('name') 获取，
        这是因为：
        1. AM 使用 field_id 术语（如 session.schemas 中的键）
        2. 避免与 Python 的 @property 装饰器命名冲突
        3. field 是 Asset Matrix 的标准术语
    
    Attributes:
        value: 属性值（可读写）
        permission: 权限字符串 ('r', 'rw', 'rwD')
        is_writable: 是否可写
        is_readonly: 是否只读
        schema: 属性 Schema 定义
        display_name: 显示名称
    
    Example:
        prop = task.field('name')
        print(prop.value)        # 'My Task'
        print(prop.permission)   # 'rw'
        print(prop.is_writable)  # True
        print(prop.display_name) # '名称'
        
        # 修改值
        if prop.is_writable:
            prop.value = 'New Name'
    """
    
    def __init__(self, node, key):
        # type: (Node, str) -> None
        self._node = node
        self._key = key
    
    @property
    def value(self):
        # type: () -> object
        """属性值"""
        return self._node[self._key]
    
    @value.setter
    def value(self, val):
        # type: (object) -> None
        """设置属性值"""
        self._node[self._key] = val
    
    @property
    def permission(self):
        # type: () -> str
        """权限: 'r' (只读), 'rw' (可读写), 'rwD' (可读写删除)"""
        return self._node.property_permission.get(self._key)
    
    @property
    def is_writable(self):
        # type: () -> bool
        """是否可写"""
        perm = self.permission
        return perm in ('rw', 'rwD') if perm else False
    
    @property
    def is_readonly(self):
        # type: () -> bool
        """是否只读"""
        return self.permission == 'r' if self.permission else False
    
    @property
    def schema(self):
        # type: () -> dict
        """属性的 Schema 定义"""
        return self._node._session.schemas.get(self._key)
    
    @property
    def display_name(self):
        # type: () -> str
        """显示名称"""
        schema = self.schema
        return schema['display_name'] if schema else self._key
    
    def __repr__(self):
        # type: () -> str
        return "<Property '{}' ({}): {} permission={}>".format(
            self.display_name,
            self._key,
            repr(self.value),
            self.permission or 'unknown'
        )
    
    def __str__(self):
        # type: () -> str
        return str(self.value)


class Node(object):
    """AM Node 抽象 (对应后端的 node)
    
    提供字典式访问、自动加载属性、修改跟踪、提交修改等核心功能。
    
    Example:
        task = version.tasks[0]
        
        # 字典式访问
        print(task['name'])
        
        # 修改属性
        task['name'] = 'New Name'
        task.commit()
        
        # 查询 Schema
        schema = task.schema('name')
        print(schema['display_name'])
    """
    
    def __init__(self, session, node_id, data=None):
        # type: (object, int, object) -> None
        """初始化
        
        Args:
            session: Session 实例
            node_id: 节点 ID
            data: 初始数据字典（完整的 get-node-brief 响应）
        """
        self._session = session
        self._id = node_id
        self._raw = data or {}  # 完整的 API 响应（get-node-brief）
        self._modified = {}  # 本地修改
        self._selected_mode = False  # 精简模式标记（properties 参数按需获取时启用）
        
    # ========== 标识 ==========
    
    @property
    def id(self):
        # type: () -> int
        """节点 ID (node_id)"""
        return self._id
        
    @property
    def name(self):
        # type: () -> str
        """节点名称 (等价于 self['name'])"""
        return self['name']
    
    @property
    def node_type(self):
        # type: () -> str
        """节点类型: 'Entity', 'Stage', 'Version', 'Project' 等
        
        返回 API 响应中的 type 字段，表示后端实际的节点类型。
        
        Returns:
            str: 节点类型字符串
        """
        return self.properties.get('type', 'Unknown')
    
    # ========== API 响应数据访问 ==========
    
    @property
    def raw(self):
        # type: () -> dict
        """完整的 API 响应数据（get-node-brief）
        
        Returns:
            dict: 完整的 API 响应字典
        """
        return self._raw
    
    @property
    def properties(self):
        # type: () -> dict
        """属性值字典
        
        Returns:
            dict: 属性键值对
        """
        return self._raw.get('properties', {})
    
    @property
    def property_permission(self):
        # type: () -> dict
        """属性权限字典
        
        Returns:
            dict: 权限字典 (r=只读, rw=可读写, rwD=可读写删除)
        """
        return self._raw.get('property_permission', {})
        
    @property
    def class_name(self):
        # type: () -> str
        """前端类名: 'Project', 'Version', 'Task'"""
        return self.__class__.__name__
        
    # ========== 字典访问 ==========
    
    def __getitem__(self, key):
        # type: (str) -> object
        """获取属性，自动加载
        
        Args:
            key: 属性键
            
        Returns:
            属性值
        """
        # 1. 检查本地修改
        if key in self._modified:
            return self._modified[key]
        
        # 2. 精简模式：优先从 _raw 第一层获取（selected_props 提升到此处）
        if self._selected_mode and key in self._raw:
            return self._raw[key]
            
        # 3. 检查已加载的 properties
        props = self.properties
        if key in props:
            return props[key]
            
        # 4. 精简模式下不自动加载
        if self._selected_mode:
            return None
            
        # 5. 自动加载 (无开关，直接加载)
        self._populate()
        return self.properties.get(key)
        
    def __setitem__(self, key, value):
        # type: (str, object) -> None
        """设置属性 (记录到 _modified)
        
        会检查属性权限，如果是只读属性会发出警告（但不阻止修改，
        因为权限可能在服务端已更新）。
        
        Args:
            key: 属性键
            value: 属性值
            
        Warning:
            如果尝试修改只读属性，会发出警告信息
        """
        # 检查权限（如果已加载）
        perm = self.property_permission.get(key)
        if perm == 'r':
            logger.warning("'%s' is read-only (permission='r'); commit() may fail", key)
        
        self._modified[key] = value
        
    def get(self, key, default=None):
        # type: (str, object) -> object
        """安全获取属性
        
        Args:
            key: 属性键
            default: 默认值
            
        Returns:
            属性值或默认值
        """
        try:
            val = self[key]
            return default if val is None else val
        except (KeyError, Exception):
            return default
            

        
    # ========== 属性加载 ==========
    
    def _populate(self):
        # type: () -> None
        """从服务器加载属性
        
        内部通过 am_get_node_brief (即 get-node-brief) 获取完整的节点信息，
        包括 properties、property_permission、workflow、workflow_state 等。
        """
        results = self._session._loader.load_node_properties([self._id])
        # load_node_properties 返回完整的节点信息
        if results and len(results) > 0:
            node_info = results[0]
            # 保留 _raw 中已有的树形元数据（如 _depth、_tree_path 等）
            tree_meta = {k: v for k, v in self._raw.items() if k.startswith('_')}
            # 更新为完整的 API 响应
            self._raw.update(node_info)
            # 恢复树形元数据
            self._raw.update(tree_meta)
            
        
    def refresh(self):
        # type: () -> None
        """刷新所有属性"""
        # 保留树形元数据
        tree_meta = {k: v for k, v in self._raw.items() if k.startswith('_')}
        self._raw.clear()
        self._raw.update(tree_meta)
        self._populate()
        
    # ========== 修改提交 (简化版) ==========
    
    def is_modified(self):
        # type: () -> bool
        """是否有未提交的修改
        
        Returns:
            bool: True 表示有修改
        """
        return len(self._modified) > 0
        
    def commit(self):
        # type: () -> None
        """提交修改 (无 rollback，失败直接抛异常)
        
        Raises:
            AMAPIError: 提交失败
        """
        if not self.is_modified():
            return
            
        result = self._session._loader.update_node_properties(
            [self._id],
            self._modified
        )
        
        if result:
            # 更新 _raw 中的 properties
            if 'properties' not in self._raw:
                self._raw['properties'] = {}
            self._raw['properties'].update(self._modified)
            self._modified.clear()
        else:
            raise AMAPIError("Failed to commit changes. Please check if property values are valid.")
            
    # ========== 属性发现 (简化版) ==========
    
    def field(self, key):
        # type: (str) -> Property
        """获取属性的完整信息（值 + 元数据）
        
        Note:
            方法名为 field 而不是 property，原因：
            1. AM 使用 field_id 术语（与 session.schemas 一致）
            2. 避免与 Python 的 @property 装饰器冲突
            3. field 是 Asset Matrix 的标准术语
        
        返回 Property 对象，包含：
        - value: 属性值
        - permission: 权限 ('r', 'rw', 'rwD')
        - is_writable, is_readonly: 便捷判断
        - schema: 属性 Schema
        - display_name: 显示名称
        
        Args:
            key: 属性键（field_id）
            
        Returns:
            Property: 属性对象
            
        Example:
            prop = task.field('name')
            print(prop.value)        # 'My Task'
            print(prop.permission)   # 'rw'
            print(prop.is_writable)  # True
            print(prop.display_name) # '名称'
            
            # 修改值
            if prop.is_writable:
                prop.value = 'New Name'
                task.commit()
        """
        return Property(self, key)
    
    def get_deliverables(self):
        # type: () -> list
        """获取交付物及其多版本文件列表
        
        通过以下步骤获取完整的交付物信息：
        1. 调用 get-file-brief 获取当前任务的主版本交付物文件
        2. 调用 get-node-brief 获取交付物节点的 multi_version_file_id
        3. 对多版本任务 id 调用 get-file-brief 获取各版本文件
        
        Returns:
            list: 交付物列表，每个元素是一个 dict：
            [
                {
                    "node_id": int,          # 交付物节点 ID
                    "name": str,             # 文件名
                    "asset_id": int,         # 资产 ID
                    "preview_url": str,      # 预览 URL
                    "display_url": str,      # 展示 URL
                    "file_info": dict,       # get-file-brief 返回的完整文件信息
                    "multi_version_file_id": list,  # 多版本任务 ID 列表
                    "versions": [            # 各版本的文件列表
                        {
                            "version_node_id": int,  # 版本任务 ID
                            "is_main": bool,         # 是否为主版本
                            "name": str,             # 版本文件名称
                            "asset_id": int,         # 版本资产 ID
                            "files": list,           # 该版本下的文件列表
                        },
                        ...
                    ]
                },
                ...
            ]
            
        Example:
            task = version.tasks[0]
            deliverables = task.get_deliverables()
            for d in deliverables:
                print("交付物: {} (node_id={})".format(d['name'], d['node_id']))
                for ver in d['versions']:
                    tag = " (主版本)" if ver['is_main'] else ""
                    print("  版本 [{}]{}:".format(ver['version_node_id'], tag))
                    for f in ver['files']:
                        print("    文件: {}".format(f.get('name', '')))
        """
        open_api = self._session._open_api
        asset_hub = self._session._asset_hub
        
        # 1. 调用 get-file-brief 获取主版本交付物
        file_res = open_api.am_get_file_by_meta_and_task_id(
            asset_hub,
            [{"id": self._id, "meta": "deliverable", "only_main_version": True}]
        )
        if not file_res.is_succeeded():
            return []
        
        # 收集交付物文件的 node_id
        main_files = []  # [(node_id, file_info), ...]
        node_ids = []
        for item in (file_res.result or []):
            for f in item.get('files', []):
                nid = f.get('node_id')
                if nid:
                    main_files.append((nid, f))
                    if nid not in node_ids:
                        node_ids.append(nid)
        
        if not node_ids:
            return []
        
        # 2. 调用 get-node-brief 获取 multi_version_file_id
        brief_res = open_api.am_get_node_brief(asset_hub, node_ids)
        if not brief_res.is_succeeded():
            return []
        
        brief_map = {}  # node_id -> node_brief
        all_version_node_ids = []
        for node_brief in (brief_res.result or []):
            nid = node_brief.get('node_id')
            brief_map[nid] = node_brief
            mv_ids = node_brief.get('multi_version_file_id', []) or []
            for mv_id in mv_ids:
                if mv_id not in all_version_node_ids and mv_id != nid:
                    all_version_node_ids.append(mv_id)
        
        # 3. 对多版本任务 id 调用 get-file-brief 和 get-node-brief
        version_files_map = {}  # mv_node_id -> files
        version_brief_map = {}  # mv_node_id -> node_brief
        if all_version_node_ids:
            mv_items = [{"id": mv_id, "meta": "deliverable", "only_main_version": False}
                        for mv_id in all_version_node_ids]
            mv_file_res = open_api.am_get_file_by_meta_and_task_id(asset_hub, mv_items)
            if mv_file_res.is_succeeded():
                for item in (mv_file_res.result or []):
                    version_files_map[item.get('id')] = item.get('files', [])
            
            # 获取多版本节点的详情（名称等）
            mv_brief_res = open_api.am_get_node_brief(asset_hub, all_version_node_ids)
            if mv_brief_res.is_succeeded():
                for nb in (mv_brief_res.result or []):
                    version_brief_map[nb.get('node_id')] = nb
        
        # 4. 组织结果
        result = []
        for nid, file_info in main_files:
            node_brief = brief_map.get(nid, {})
            mv_ids = node_brief.get('multi_version_file_id', []) or []
            
            versions = []
            for mv_id in mv_ids:
                is_main = mv_id == nid
                mv_files = version_files_map.get(mv_id, [])
                
                if is_main:
                    # 主版本：直接用当前文件信息
                    ver_name = file_info.get('name', file_info.get('file_name', ''))
                    ver_asset_id = file_info.get('asset_id')
                else:
                    # 非主版本：从 get-node-brief 获取名称，从 get-file-brief 获取 asset_id
                    ver_brief = version_brief_map.get(mv_id, {})
                    ver_props = ver_brief.get('properties', {})
                    ver_name = ver_props.get('name', '')
                    # asset_id 从文件列表中取第一个
                    ver_asset_id = mv_files[0].get('asset_id') if mv_files else None
                
                versions.append({
                    "version_node_id": mv_id,
                    "is_main": is_main,
                    "name": ver_name,
                    "asset_id": ver_asset_id,
                    "files": mv_files,
                })
            
            result.append({
                "node_id": nid,
                "name": file_info.get('name', file_info.get('file_name', '')),
                "asset_id": file_info.get('asset_id'),
                "preview_url": file_info.get('preview_url', ''),
                "display_url": file_info.get('display_url', ''),
                "file_info": file_info,
                "multi_version_file_id": mv_ids,
                "versions": versions,
            })
        
        return result
    
    def get_node_pan_directory_id(self):
        # type: () -> dict
        """获取 AM 任务在 Pan 中存储交付物的文件夹信息
        
        流程：
        1. 调用 get-deliverable-asset-directory 接口查询
        2. 若有结果直接返回 {directory_id}
        3. 若无结果，通过 deliverable_storage_address 属性 + depot_get_node_brief_by_path 递归查找
        
        Returns:
            dict: 包含 directory_id 的字典；
                  未找到时返回 None
                  
        Example:
            task = session._get_or_create_node('Task', 120347789384709)
            info = task.get_node_pan_directory_id()
            if info:
                print("directory_id:", info['directory_id'])
                print("full_path_name:", info['full_path_name'])
        """
        open_api = self._session._open_api
        asset_hub = self._session._asset_hub
        
        # 第一步：调用 get-deliverable-asset-directory
        res = open_api.am_get_node_pan_directory_id(asset_hub, self._id)
        if res.is_succeeded() and res.result:
            # result 是列表，取第一个
            items = res.result
            if isinstance(items, list) and len(items) > 0:
                item = items[0]
                if item.get('directory_id'):
                    return {
                        'directory_id': item['directory_id'],
                        # 'full_path_id': item.get('full_path_id', []),
                        # 'full_path_name': item.get('full_path_name', []),
                    }
        
        # 第二步：通过 deliverable_storage_address 属性查找
        self._session.preload_selected([self], ["deliverable_storage_address"])
        storage_address = self['deliverable_storage_address']
        if not storage_address:
            return None
        
        # 属性值是 dict（如 {"url": "AssetHub_yida/.SYS_AM/..."}），提取字符串
        if isinstance(storage_address, dict):
            storage_address = storage_address.get('url', '')
        if not isinstance(storage_address, str) or not storage_address:
            return None
        
        # replaceBeforeFirstSlash: 去除第一个 / 及其前面的字符
        path = self._replace_before_first_slash(storage_address)
        if not path:
            return None
        
        # 获取 depot root id
        root_res = open_api.depot_get_root_id(asset_hub)
        if not root_res.is_succeeded():
            return None
        root_id = root_res.first_result('id') if root_res.first_result() and isinstance(root_res.first_result(), dict) else root_res.result
        if isinstance(root_id, list) and len(root_id) > 0:
            root_id = root_id[0]
        if isinstance(root_id, dict):
            root_id = root_id.get('id', root_id.get('depot_id'))
        
        if not root_id:
            return None
        
        # findParentId: 递归查找路径对应的节点 id
        directory_id = self._find_parent_id(open_api, asset_hub, path, root_id)
        if not directory_id:
            return None
        
        return {
            'directory_id': directory_id,
            # 'full_path_id': [],
            # 'full_path_name': [],
        }
    
    @staticmethod
    def _replace_before_first_slash(input_str):
        # type: (str) -> str
        """去除第一个 / 及其前面的字符
        
        等价于 JS 的 replaceBeforeFirstSlash(input, false)
        """
        if not input_str:
            return input_str
        idx = input_str.find('/')
        if idx == -1:
            return input_str
        return input_str[idx + 1:]
    
    @staticmethod
    def _find_parent_id(open_api, asset_hub, path, root_id):
        # type: (object, str, str, int) -> int
        """递归查找路径对应的节点 ID
        
        从完整路径开始查找，若未找到则逐级去掉末尾路径段重试。
        
        Args:
            open_api: OpenAPI 实例
            asset_hub: 资产库名称
            path: 文件路径
            root_id: depot 根节点 ID
            
        Returns:
            int: 找到的节点 ID；None 表示未找到
        """
        current_path = path
        while current_path:
            res = open_api.depot_get_node_brief_by_path(asset_hub, root_id, current_path)
            if res.is_succeeded() and res.result:
                # result 可能是列表或字典
                items = res.result
                if isinstance(items, list) and len(items) > 0:
                    item = items[0]
                    node_id = item.get('id') if isinstance(item, dict) else item
                    if node_id:
                        return node_id
                elif isinstance(items, dict):
                    node_id = items.get('id')
                    if node_id:
                        return node_id
            
            # 去掉末尾路径段重试
            parts = current_path.rsplit('/', 1)
            if len(parts) <= 1:
                break
            current_path = parts[0]
        
        return None
    
    def upload_file(self, local_path, meta='deliverable_v2'):
        # type: (str, str) -> dict
        """上传文件并关联为交付物，完成转码后清理临时目录
        
        完整流程：
        1. 获取任务在 Pan 中的交付物目录
        2. 在该目录下创建临时文件夹
        3. 上传文件到临时文件夹
        4. 将上传的文件关联到任务上（deliverable_v2）
        5. 获取关联资产的 origin_url 并触发转码
        6. 删除临时文件夹
        
        Args:
            local_path: 本地文件路径，如 r"D:\\image\\test.mp4"
            meta: 关联类型，默认 'deliverable_v2'
            
        Returns:
            dict: 结果信息
            {
                "success": bool,
                "asset_id": int,             # 上传的文件 asset_id
                "linked_asset_ids": list,    # 关联后的 asset_id 列表
                "error": str,                # 失败时的错误信息
            }
            
        Example:
            task = session._get_or_create_node('Task', 120347789384709)
            result = task.upload_file(r"D:\\image\\test.mp4")
            if result['success']:
                print("上传成功，asset_id:", result['asset_id'])
            else:
                print("上传失败:", result['error'])
        """
        from ..storage import Storage
        
        open_api = self._session._open_api
        asset_hub = self._session._asset_hub
        task_id = self._id
        temp_dir_id = None
        
        try:
            # 1. 获取任务在 Pan 中存储交付物的文件夹信息
            dir_info = self.get_node_pan_directory_id()
            if not dir_info:
                return {"success": False, "asset_id": None, "linked_asset_ids": [], "error": "未找到对应的 Pan 目录"}
            
            # 2. 在存储交付物的文件夹下创建临时文件夹
            temp_dir_name = "{}_temp".format(task_id)
            create_dir_res = open_api.depot_create_directory(
                asset_hub=asset_hub,
                payloads=[{
                    "parent_id": dir_info['directory_id'],
                    "name": temp_dir_name,
                    "allowed_rename": True,
                }],
            )
            if not create_dir_res.is_succeeded():
                return {"success": False, "asset_id": None, "linked_asset_ids": [],
                        "error": "临时文件夹创建失败: {}".format(create_dir_res.error_message())}
            temp_dir_id = create_dir_res.result
            
            # 3. 上传文件到临时文件夹
            storage = Storage(open_api)
            upload_res = storage.upload_to_directory_by_id(
                asset_hub=asset_hub,
                remote_dir_id=temp_dir_id,
                local_path=local_path,
            )
            if not upload_res.is_succeeded():
                return {"success": False, "asset_id": None, "linked_asset_ids": [],
                        "error": "上传失败: {}".format(upload_res.error_message())}
            
            uploaded_node = upload_res.data[0]
            asset_id = uploaded_node.id
            
            # 4. 把上传的文件关联到任务上
            link_res = open_api.am_upload_file_by_asset_id(
                asset_hub=asset_hub,
                node_id=task_id,
                asset_ids=[asset_id],
                meta=meta,
            )
            if not link_res.is_succeeded():
                return {"success": False, "asset_id": asset_id, "linked_asset_ids": [],
                        "error": "关联失败: {}".format(link_res.error_message())}
            
            linked_asset_ids = [item['asset_id'] for item in link_res.result]
            
            # 5. 获取关联资产的 origin_url 并触发转码
            brief_res = open_api.depot_get_node_brief_by_ids(
                asset_hub=asset_hub,
                ids=linked_asset_ids,
            )
            if brief_res.is_succeeded():
                asset_files = []
                convert_asset_ids = []
                for idx, brief_item in brief_res.results.items():
                    origin_url = brief_item.get('origin_url', '')
                    item_id = brief_item.get('id')
                    if origin_url:
                        asset_files.append(origin_url)
                        convert_asset_ids.append(item_id)
                
                if asset_files:
                    open_api.depot_convert_asset(
                        asset_hub=asset_hub,
                        asset_files=asset_files,
                        asset_ids=convert_asset_ids,
                    )
            
            return {"success": True, "asset_id": asset_id, "linked_asset_ids": linked_asset_ids, "error": None}
        
        finally:
            # 6. 删除临时文件夹（无论成功失败都清理）
            if temp_dir_id:
                open_api.depot_delete_node_by_ids(
                    asset_hub=asset_hub,
                    ids=[temp_dir_id],
                )
    
    def __repr__(self):
        # type: () -> str
        name = self.get('name', 'Unknown')
        return "<{}({}): {}>".format(self.class_name, self.id, name)


# ========== Node 子类 ==========


class Project(Node):
    """AM 项目根节点
    
    Example:
        project = session.project
        versions = project.versions
        
        # 过滤版本
        test_versions = project.filter_versions([{...}])
    """
    
    @property
    def versions(self):
        # type: () -> list
        """获取所有版本
        
        Returns:
            list: Version 列表
        """
        result = self._session._open_api.am_get_version_list(
            self._session._asset_hub,
            self.id
        )
        if not result.is_succeeded():
            return []
            
        versions = []
        for ver_data in result.result or []:
            ver = self._session._get_or_create_node(
                'Version',
                ver_data['id'],
                ver_data
            )
            versions.append(ver)
        
        if versions:
            self._session.preload(versions)
        
        return versions
        
    def get_versions_by_name(self, name):
        # type: (str) -> list
        """根据名称获取版本列表
        
        由于版本名称可能重复，此方法返回所有匹配的版本。
        
        Args:
            name: 版本名称（精确匹配）
            
        Returns:
            list: 匹配的 Version 列表（可能为空或包含多个版本）
            
        Example:
            # 获取名称为 "v1.0" 的所有版本
            versions = project.get_versions_by_name("v1.0")
            
            if versions:
                print("找到 {} 个匹配的版本".format(len(versions)))
                for ver in versions:
                    print("  - 版本 ID: {}, 名称: {}".format(ver.id, ver['name']))
            else:
                print("未找到匹配的版本")
        """
        all_versions = self.versions
        matched = [v for v in all_versions if v.get('name') == name]
        return matched
    
    def get_versions_tree(self):
        # type: () -> list
        """获取版本树
        
        获取项目下的版本树结构，并通过 get-node-brief 加载每个节点的 name、type 等属性。
        
        Returns:
            list: Version 节点列表（带层级元数据 depth、tree_path 等）
            
        Example:
            versions_tree = project.get_versions_tree()
            for ver in versions_tree:
                print("版本 ID: {}, 名称: {}, 类型: {}".format(
                    ver.id, ver['name'], ver.node_type))
        """
        result = self._session._open_api.am_get_version_tree(
            self._session._asset_hub,
            self.id
        )
        if not result.is_succeeded():
            return []
        
        # 解析树形响应（与 _parse_task_response 同构）
        data = result.result or []
        nodes = []
        
        if isinstance(data, list) and len(data) > 0:
            data = data[0]
        
        if isinstance(data, dict) and 'ids' in data:
            ids = data.get('ids', [])
            node_types = data.get('node_type', [])
            depths = data.get('depth', [])
            paths = data.get('path', [])
            children_counts = data.get('children_count', [])
            
            for i, node_id in enumerate(ids):
                am_node_type = node_types[i] if i < len(node_types) else 'Version'
                node_data = {
                    'node_type': am_node_type,
                    '_depth': depths[i] if i < len(depths) else None,
                    '_tree_path': paths[i] if i < len(paths) else None,
                    '_children_count': children_counts[i] if i < len(children_counts) else 0,
                }
                node = self._session._get_or_create_node(
                    'Version', node_id, data=node_data
                )
                nodes.append(node)
        
        # 调用 get-node-brief 加载 name、type 等属性
        if nodes:
            self._session.preload_selected(nodes, ["name","type"])
        
        # 收集所有不同的 type，批量获取 display_name
        if nodes:
            type_set = set()
            for n in nodes:
                t = n.get('type')
                if t:
                    type_set.add(t)
            if type_set:
                type_res = self._session._open_api.am_get_node_type_by_name(
                    self._session._asset_hub, list(type_set)
                )
                if type_res.is_succeeded() and type_res.result:
                    type_map = {}
                    for item in type_res.result:
                        if isinstance(item, dict):
                            type_map[item.get('name', '')] = item.get('display_name', '')
                    for n in nodes:
                        t = n.get('type')
                        n._raw['_type_display_name'] = type_map.get(t, t or '')
        
        return nodes


class Version(Node):
    """版本节点
    
    Example:
        version = project.versions[0]
        
        # 访问属性 (自动调用 get-node-detail)
        print(version['name'])
        
        # 获取所有任务
        tasks = version.tasks
        
        # 过滤任务
        my_tasks = version.filter_tasks([{...}])
    """
    
    @property
    def parent(self):
        # type: () -> object
        """父 Project
        
        Returns:
            Project 实例或 None
        """
        parent_id = self.get('parent')
        if not parent_id:
            return None
        return self._session._get_or_create_node('Project', parent_id)
        
    @property
    def tasks(self):
        # type: () -> list
        """获取所有任务（自动预加载属性）
        
        SDK 自动预加载任务的所有属性，无需手动操作。
        
        Returns:
            list: Task 列表
            
        Example:
            # SDK 自动预加载属性，直接使用
            tasks = version.tasks
            for task in tasks:
                print(task.properties.get('name'))  # 已加载
                print(task['自定义属性'])            # 已加载
        """
        result = self._session._open_api.am_get_task_list_by_version(
            self._session._asset_hub,
            self.id,
            offset=0,
            count=-1  # -1 表示获取所有任务，智能分页会自动处理
        )
        if not result.is_succeeded():
            return []
            
        task_list = self._parse_task_response(result.result)
        
        # 自动预加载常用属性
        if task_list:
                self._session.preload(task_list)
        
        
        return task_list
        
    def filter_tasks(self, filter_dsl, count=100, properties=None, expand_references=False):
        # type: (list, int, list, bool) -> list
        """使用 AM Filter DSL 过滤任务（扁平列表）
        
        返回符合条件的任务扁平列表（带层级元数据）。
        
        Args:
            filter_dsl: AM Filter DSL 列表
            count: 返回数量（默认 100），-1 表示获取所有匹配的任务
            properties: 可选，需要获取的属性名列表，如 ["linked_preview_id", "linked_progress_id"]。
                       传入时只加载指定属性（按需获取，减少网络开销）；
                       不传时加载全部属性（保持原有行为）。
            expand_references: 是否展开引用型字段（人员、模块、工作流、工作流状态），默认 False。
                              仅在 properties 不为 None 时生效。
            
        Returns:
            list: 过滤后的任务扁平列表（带 is_match_filter 标记和 depth 等元数据）
            
        Note:
            当使用 filter 时，API 可能返回不匹配但需要显示层级的父节点。
            通过 task.is_match_filter 属性可以区分：
            - True: 真正匹配 filter 的任务
            - False: 仅用于显示层级的父节点
            
        Example:
            filter_ = [{
                "bool": {"must": [
                    {"item": {"meta": "artist", "condition": "contains_any", "value": ["kazenzhong"]}}
                ]}
            }]
            
            # 获取全部属性（默认行为）
            tasks = version.filter_tasks(filter_)
            
            # 按需获取指定属性
            tasks = version.filter_tasks(filter_, properties=["linked_preview_id", "linked_progress_id"])
            for task in tasks:
                marker = "✓" if task.is_match_filter else "○"
                indent = "  " * (task.depth or 0)
                print("{}{} {}".format(indent, marker, task.name))
            
            # 按需获取并展开引用
            tasks = version.filter_tasks(
                filter_, 
                properties=["artist", "module", "workflow_state"],
                expand_references=True
            )
            
            # 获取所有匹配任务
            all_tasks = version.filter_tasks(filter_, count=-1)
        """
        result = self._session._open_api.am_get_task_list_by_version(
            self._session._asset_hub,
            self.id,
            filter=filter_dsl,
            offset=0,
            count=count
        )
        if not result.is_succeeded():
            return []
        
        task_list = self._parse_task_response(result.result)
        
        # 自动预加载属性
        if task_list:
            if properties is not None:
                self._session.preload_selected(task_list, properties, expand_references=expand_references)
            else:
                self._session.preload(task_list)
        
        return task_list
    
    def filter_task_tree(self, filter_dsl, count=100, properties=None, expand_references=True):
        # type: (list, int, list, bool) -> list
        """使用 AM Filter DSL 过滤任务（树形结构）
        
        返回符合条件的任务树形结构（根任务列表）。
        
        Args:
            filter_dsl: AM Filter DSL 列表
            count: 返回数量（默认 100），-1 表示获取所有匹配的任务
            properties: 可选，需要获取的属性名列表，如 ["linked_preview_id", "linked_progress_id"]。
                       传入时只加载指定属性（按需获取，减少网络开销）；
                       不传时加载全部属性（保持原有行为）。
            expand_references: 是否展开引用型字段（人员、模块、工作流、工作流状态），默认 False。
                              仅在 properties 不为 None 时生效。
            
        Returns:
            list: 过滤后的根任务列表（带 is_match_filter 标记）
            
        Note:
            当使用 filter 时，API 可能返回不匹配但需要显示层级的父节点。
            通过 task.is_match_filter 属性可以区分：
            - True: 真正匹配 filter 的任务
            - False: 仅用于显示层级的父节点
            
        Example:
            filter_ = [{
                "bool": {"must": [
                    {"item": {"meta": "artist", "condition": "contains_any", "value": ["kazenzhong"]}}
                ]}
            }]
            
            # 获取全部属性（默认行为）
            tree = version.filter_task_tree(filter_)
            
            # 按需获取指定属性
            tree = version.filter_task_tree(filter_, properties=["linked_preview_id"])
            for root in tree:
                if root.is_match_filter:
                    print("✓ {}".format(root.name))
                else:
                    print("○ {}".format(root.name))
                    
                for child in root.children:
                    marker = "✓" if child.is_match_filter else "○"
                    print("  {} {}".format(marker, child.name))
        """
        result = self._session._open_api.am_get_task_list_by_version(
            self._session._asset_hub,
            self.id,
            filter=filter_dsl,
            offset=0,
            count=count
        )
        if not result.is_succeeded():
            return []
        
        task_list = self._parse_task_response(result.result)
        
        # 自动预加载属性
        if task_list:
            if properties is not None:
                self._session.preload_selected(task_list, properties, expand_references=expand_references)
            else:
                self._session.preload(task_list)
        
        return self._build_tree(task_list)
        
    def _parse_task_response(self, data):
        # type: (object) -> list
        """解析 AM task list 响应
        
        Args:
            data: API 响应数据
            
        Returns:
            list: Task 列表（带层级元数据）
            
        Note:
            由于使用了 skip_production_types 排除 File 和 Bug，
            返回的节点类型可能是 Entity（需求）或 Stage（环节），都作为 Task 处理。
            
            层级元数据字段：
            - _depth: 层级深度（0=顶层）
            - _tree_path: 节点路径 [ancestor_id, ..., self_id]
            - _children_count: 直接子节点数量
            - _is_match_filter: 是否匹配 filter 条件
        """
        # AM 返回的是列表，取第一个元素
        # [{"ids": [...], "node_type": [...], "depth": [...], "path": [...], ...}]
        tasks = []
        
        if isinstance(data, list) and len(data) > 0:
            data = data[0]
            
        if isinstance(data, dict) and 'ids' in data:
            ids = data.get('ids', [])
            node_types = data.get('node_type', [])
            
            # 提取层级元数据
            depths = data.get('depth', [])
            paths = data.get('path', [])
            children_counts = data.get('children_count', [])
            is_match_filters = data.get('is_match_filter', [])
            
            # 创建 Task，node_type 和层级元数据存储在 data 中
            for i, task_id in enumerate(ids):
                am_node_type = node_types[i] if i < len(node_types) else 'Entity'
                
                # 构建包含层级信息的初始数据
                task_data = {
                    'node_type': am_node_type,
                    '_depth': depths[i] if i < len(depths) else None,
                    '_tree_path': paths[i] if i < len(paths) else None,
                    '_children_count': children_counts[i] if i < len(children_counts) else 0,
                    '_is_match_filter': bool(is_match_filters[i]) if i < len(is_match_filters) else True,
                }
                
                task = self._session._get_or_create_node(
                    'Task', 
                    task_id, 
                    data=task_data
                )
                tasks.append(task)
        return tasks
    
    def get_task_tree(self):
        # type: () -> list
        """获取任务树形结构
        
        返回根任务列表，可通过 task.children 访问子任务。
        自动预加载常用属性（name, artist, workflow_state_name）。
        
        Returns:
            list: 根任务列表（depth=0 的任务）
            
        Example:
            tree = version.get_task_tree()
            for root in tree:
                print(root.name)
                for child in root.children:
                    print("  - {}".format(child.name))
                    if child.parent:
                        print("    父任务: {}".format(child.parent.name))
        """
        result = self._session._open_api.am_get_task_list_by_version(
            self._session._asset_hub,
            self.id,
            offset=0,
            count=-1
        )
        if not result.is_succeeded():
            return []
            
        task_list = self._parse_task_response(result.result)
        
        # 自动预加载常用属性
        if task_list:
            self._session.preload(task_list)
        
        return self._build_tree(task_list)
    
    def _build_tree(self, tasks):
        # type: (list) -> list
        """从摊平的任务列表构建树形结构
        
        填充每个 Task 的 _tree_children 和 _parent_task 属性，
        返回根节点（depth=0）列表。
        
        Args:
            tasks: Task 列表（带层级元数据）
            
        Returns:
            list: 根任务列表（depth=0 的任务）
        """
        if not tasks:
            return []
        
        # 构建 id -> task 映射
        id_map = {t.id: t for t in tasks}
        
        # 初始化 _tree_children 为空列表
        for task in tasks:
            task._raw['_tree_children'] = []
            task._raw['_parent_task'] = None
        
        roots = []
        for task in tasks:
            # 从 _tree_path 计算父节点 ID
            tree_path = task._raw.get('_tree_path')
            parent_id = None
            if tree_path and len(tree_path) >= 2:
                parent_id = tree_path[-2]
            
            if parent_id and parent_id in id_map:
                # 有父节点且在当前列表中
                parent = id_map[parent_id]
                parent._raw['_tree_children'].append(task)
                task._raw['_parent_task'] = parent
            else:
                # 顶层任务
                roots.append(task)
        
        return roots


class Task(Node):
    """任务/实体节点
    
    代表一个 AM 任务，对应后端的 Entity 或 Stage 类型节点。
    - Entity: 需求节点
    - Stage: 环节节点（需求下的拆分）
    
    属性访问：
        task.properties.get('name')     # 获取属性值
        task.workflow_state             # 工作流状态信息
        task.workflow                   # 工作流信息
        task.operations                 # 可执行的操作列表
        task.module                     # 模块名称
        task.node_type                  # 节点类型 ('Entity' 或 'Stage')
        task.is_entity                  # 是否为 Entity 类型
        task.is_stage                   # 是否为 Stage 类型
    
    Note:
        不同项目的字段配置可能不同，建议通过 session.schemas 
        查找实际字段 ID 后使用 task.properties.get(field_id) 获取。
    
    Example:
        task = version.tasks[0]
        print(task.node_type)  # 'Entity' 或 'Stage'
        print(task.workflow_state.get('display_name'))  # '实现中'
        
        # 获取属性值
        name = task.properties.get('name')
        
        # 修改属性
        task['name'] = 'Updated Name'
        task.commit()
    """
    
    def __init__(self, session, node_id, data=None):
        # type: (object, int, object) -> None
        super(Task, self).__init__(session, node_id, data)
    
    @property
    def version(self):
        # type: () -> object
        """父 Version
        
        返回此任务所属的 Version 节点。
        
        Returns:
            Version: 父 Version 实例或 None
            
        Example:
            task = version.get_task_tree()[0]
            print(task.version.name)  # 输出版本名称
        """
        parent_id = self.get('parent')
        if not parent_id:
            return None
        return self._session._get_or_create_node('Version', parent_id)
    
    @property
    def parent(self):
        # type: () -> object
        """父 Task
        
        返回父任务节点（在树形结构中）。
        如果是顶层任务，返回 None。
        
        Note:
            此属性仅在通过 version.get_task_tree() 或 version.filter_task_tree()
            获取时有效。单独加载的 Task 返回 None。
        
        Returns:
            Task: 父 Task 实例；None 表示是顶层任务
            
        Example:
            tree = version.get_task_tree()
            for root in tree:
                for child in root.children:
                    if child.parent:
                        print("{} 的父任务是 {}".format(child.name, child.parent.name))
        """
        return self._raw.get('_parent_task')
        
    @property
    def children(self):
        # type: () -> list
        """子任务列表
        
        返回子任务列表（在树形结构中）。
        如果没有子任务或不在树形模式下，返回空列表。
        
        Note:
            此属性仅在通过 version.get_task_tree() 或 version.filter_task_tree()
            获取时有效。单独加载的 Task 返回空列表。
        
        Returns:
            list: 子 Task 列表
            
        Example:
            tree = version.get_task_tree()
            for root in tree:
                print("{} 有 {} 个子任务".format(root.name, len(root.children)))
                for child in root.children:
                    print("  - {}".format(child.name))
        """
        return self._raw.get('_tree_children', [])
        
    # ========== API 响应专属属性 ==========
    
    @property
    def workflow(self):
        # type: () -> dict
        """工作流信息
        
        Returns:
            dict: 工作流信息，包含 id, name, display_name
            {
                "id": 120347714236737,
                "name": "Customer_workflow_120347714236736",
                "display_name": "199工作流"
            }
            
        Example:
            wf = task.workflow
            print(wf.get('display_name'))  # '199工作流'
        """
        return self._raw.get('workflow', {})
    
    @property
    def workflow_state(self):
        # type: () -> dict
        """工作流状态信息
        
        Returns:
            dict: 状态信息，包含 id, name, display_name, type
            {        
                "id": 120347714236739,
                "name": "进行中",
                "display_name": "实现中",
                "type": "进行中"
            }
        Example:
            state = task.workflow_state
            print(state.get('display_name'))  # '实现中'
            print(state.get('type'))  # '进行中'
        """
        return self._raw.get('workflow_state', {})
    
    @property
    def operations(self):
        # type: () -> list
        """可执行的状态流转操作
        
        Returns:
            list: 操作列表
            [
                {
                    "name": "实现中-测试中",
                    "next": 120347715702788,
                    "display_name": "开发完成",
                    "transition_id": 120347714236746
                },
                ...
            ]
        Example:
            for op in task.operations:
                print(op.get('display_name'))
        """
        return self._raw.get('operations', [])
    
    def update_workflow_state(self, workflow_state, transition_id):
        # type: (int, int) -> bool
        """修改任务的工作流状态
        
        通过 update_node_properties 接口提交工作流状态变更，
        需同时传入目标状态 ID 和转换 ID。
        
        Args:
            workflow_state: 目标状态 ID
            transition_id: 转换 ID（从 workflow_id.transition 中获取）
            
        Returns:
            bool: 是否成功
            
        Raises:
            AMAPIError: 提交失败
            
        Example:
            task = session._get_or_create_node('Task', task_id)
            task.update_workflow_state(
                workflow_state=120347715702788,
                transition_id=120347714236746
            )
        """
        result = self._session._loader.update_node_properties(
            [self._id],
            {'workflow_state': workflow_state, 'transition_id': transition_id}
        )
        if not result:
            raise AMAPIError("Failed to update workflow state.")
        return True
    
    @property
    def module(self):
        # type: () -> str
        """模块名称
        
        Returns:
            str: 模块名称
            "e06d7c93-691b-5243-80d7-1d30af165b79"
        """
        return self.properties.get('module', '')
    
    # ========== 层级元数据属性（从 tree API 返回时填充）==========
    
    @property
    def depth(self):
        # type: () -> int
        """层级深度 (0=顶层任务)
        
        Note:
            仅在通过 version.tasks 或 version.filter_tasks() 获取时有效。
            单独加载的 Task 不包含此信息，将返回 None。
        
        Returns:
            int: 层级深度，0 表示顶层；None 表示未从树形 API 获取
            
        Example:
            tasks = version.tasks
            for task in tasks:
                indent = "  " * (task.depth or 0)
                print("{}- {}".format(indent, task.name))
        """
        return self._raw.get('_depth')
    
    @property
    def children_count(self):
        # type: () -> int
        """直接子节点数量（无需加载子节点）
        
        Note:
            仅在通过 version.tasks 或 version.filter_tasks() 获取时有效。
        
        Returns:
            int: 直接子节点数量
            
        Example:
            tasks = version.tasks
            parent_tasks = [t for t in tasks if t.children_count > 0]
        """
        return self._raw.get('_children_count', 0)
    
    @property
    def has_children(self):
        # type: () -> bool
        """是否有子节点
        
        Returns:
            bool: True 表示有子节点
            
        Example:
            for task in version.tasks:
                if task.has_children:
                    print("{} has {} children".format(task.name, task.children_count))
        """
        return self.children_count > 0
    
    @property
    def is_match_filter(self):
        # type: () -> bool
        """是否匹配当前 filter 条件
        
        当通过 filter_tasks() 获取时，此属性表示任务是否真正匹配 filter。
        未匹配但仍返回的节点通常是匹配节点的祖先（用于保持层级结构）。
        
        Returns:
            bool: True 表示匹配，False 表示不匹配（仅用于显示层级）
            
        Example:
            tasks = version.filter_tasks(filter_dsl)
            for task in tasks:
                if task.is_match_filter:
                    print("✓ {}".format(task.name))  # matched
                else:
                    print("○ {}".format(task.name))  # parent node for hierarchy
        """
        return self._raw.get('_is_match_filter', True)
    


# ========== Node 类型映射 ==========

_NODE_TYPE_MAP = {
    'Project': Project,
    'Version': Version,
    'Task': Task,
    'Entity': Task,  # 后端的 Entity 映射到 Task
}
