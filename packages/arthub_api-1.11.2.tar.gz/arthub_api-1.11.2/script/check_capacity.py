# -*- coding: UTF-8 -*-

from arthub_api.__main__ import init_config
from arthub_api.__main__ import setup_logging
from arthub_api import arthub_api_config
from arthub_api import (
    OpenAPI,
    Storage,
    api_config_qq,
)
from arthub_api.utils import logger

setup_logging()
init_config()
api_config = api_config_qq
api_config["timeout"] = 200
open_api = OpenAPI(api_config_qq)

res = open_api.login(account_name=arthub_api_config.account_email,
                     password=arthub_api_config.password,
                     login_public_keys=arthub_api_config.login_public_keys)
if not res.is_succeeded():
    print("login failed, message: %s", res.error_message())
    exit(-1)
storage = Storage(open_api)

asset_hub = "timi"
directory_path = [
    u"资产备份/zero/SQEX原版资源/尼尔1资源文件（整理后）/Snow_バージョン管理データ/Workspace_PostProduction/snow/main/resource"
]
total_capacity = 0

for p in directory_path:
    res = storage.get_node_by_path(asset_hub=asset_hub, remote_node_path=p)
    if not res.is_succeeded():
        print("get node by path {} failed, message: {}".format(p, res.error_message()))
        continue
    target_id = res.data["id"]

    res = storage.get_child_nodes_brief_by_id(asset_hub=asset_hub, parent_node_id=target_id, is_recursive=True)
    if not res.is_succeeded():
        print("get child node under {} failed, message: {}".format(target_id, res.error_message()))
        continue

    directory_capacity = 0
    for d in res.data:
        capacity = d.get("capacity")
        if capacity:
            directory_capacity += capacity
    print("\"{}\": {}".format(p, directory_capacity))
    total_capacity += directory_capacity

print("total capacity: ", total_capacity)
