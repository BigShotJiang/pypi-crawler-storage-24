# -*- coding: UTF-8 -*-

from arthub_api.__main__ import init_config
from arthub_api.__main__ import setup_logging
from arthub_api import arthub_api_config
from arthub_api import (
    OpenAPI,
    Storage,
    api_config_qq,
)
from arthub_api.utils import logger
import openpyxl
import os

setup_logging()
init_config()
api_config = api_config_qq
api_config["timeout"] = 200
open_api = OpenAPI(api_config_qq)

res = open_api.login(account_name=arthub_api_config.account_email,
                     password=arthub_api_config.password,
                     login_public_keys=arthub_api_config.login_public_keys)
if not res.is_succeeded():
    print("login failed, message: %s", res.error_message())
    exit(-1)

accounts = [
    "critliu",
    "lylahwang",
    "guodongxu",
]

account_details = []
m = {}
res = open_api.get_account_detail(accounts)
for k in res.results:
    info = res.results[k]
    m[info["account_name"]] = info

# Create a new Excel workbook and select the active worksheet
wb = openpyxl.Workbook()
ws = wb.active

# Write headers to the first row
headers = ["Nick Name", "QYWX", "Company", "Email", "Department"]
ws.append(headers)

# Iterate over accounts and write info to the Excel file
for a in accounts:
    info = m.get(a)
    if info:
        # Extract the required fields
        row = [
            info.get("nick_name", ""),
            info.get("qywx_alias", ""),
            info.get("company", ""),
            info.get("email", ""),
            info.get("department", "")
        ]
        # Append the row to the worksheet
        ws.append(row)

# Get the path to the desktop
desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

# Save the workbook to a file on the desktop
wb.save(os.path.join(desktop_path, "accounts_data.xlsx"))

print("end")
