import os
from arthub_api import (
    OpenAPI,
    Storage,
    api_config_qq
)

# 目标资源库名
asset_hub = "trial"
# 目标目录路径
target_dir_path = "sdk_test/storage_test/download"
# 下载测试路径
local_download_dir_path = "D:/test/sdk_download"

def try_login_with_dev_thm_env():
    # 在非lightbox的运行环境下，没有现成arthub登录态
    # 因此建议配置确定的账号密码及公钥，进行开发测试
    account_name = os.environ.get('DEV_ARTHUB_ACCOUNT_NAME')
    password = os.environ.get('DEV_ARTHUB_ACCOUNT_PASSWORD')
    login_public_keys = os.environ.get('DEV_ARTHUB_LOGIN_PUBLIC_KEYS')
    if not login_public_keys or not account_name or not password:
        return False
    return open_api.login(account_name=account_name, password=password,
                          login_public_keys=login_public_keys).is_succeeded()


def query_children_files(storage, is_recursive):
    res = storage.get_child_nodes(asset_hub=asset_hub, parent_path=target_dir_path,
                                  is_recursive=is_recursive)
    if not res.is_succeeded():
        print("query directory failed, message: %s", res.error_message())
        exit(-1)
    tree = res.data
    file_nodes = []

    def collect_files(tree_node, parent_path=""):
        node_path = os.path.join(parent_path, tree_node.fullname)
        print(node_path)
        if tree_node.is_directory:
            for child_node in tree_node.children:
                collect_files(child_node, node_path)
        else:
            file_nodes.append((node_path, tree_node.brief))

    collect_files(tree)
    return file_nodes


if __name__ == '__main__':
    open_api = OpenAPI(
        config=api_config_qq,
        get_token_from_cache=False,
        apply_blade_env=True  # 从当前环境中读取 arthub 登录态
    )

    # 检测是否有登录态
    if not open_api.is_login():
        if not try_login_with_dev_thm_env():
            print("login failed")
            exit(-1)

    # 存储模块
    storage = Storage(open_api)

    # 拉取目录下子文件信息 children_files
    children_files = query_children_files(
        storage=storage,
        is_recursive=True  # 递归
    )
    # 打印看看
    for child_node in children_files:
        file_path = child_node[0]  # 相对路径
        file_brief = child_node[1]  # 文件信息对象, 可具体查看有哪些字段用于筛选
        print(file_brief.get("file_format")) # 打印文件后缀名看看
        # 下载
        download_path = os.path.join(local_download_dir_path, file_path)
        storage.download_node(asset_hub=asset_hub,
                              node=file_brief,
                              local_dir_path=download_path,
                              download_filters=[],
                              same_name_override=True)

