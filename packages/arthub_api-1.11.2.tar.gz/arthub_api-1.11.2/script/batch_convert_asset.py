from arthub_api.__main__ import init_config
from arthub_api.__main__ import setup_logging
from arthub_api import arthub_api_config
from arthub_api import (
    OpenAPI,
    Storage,
    api_config_qq,
)
from arthub_api.utils import logger

setup_logging()
init_config()

open_api = OpenAPI(api_config_qq)
res = open_api.login(account_name=arthub_api_config.account_email,
                     password=arthub_api_config.password,
                     login_public_keys=arthub_api_config.login_public_keys)
if not res.is_succeeded():
    print("login failed, message: %s", res.error_message())
    exit(-1)
storage = Storage(open_api)
asset_hub = 'xmocap'
root_id = 120347593716126
target_format = ['fbx']


def on_operation_failed(operation, error_message):
    logger.error("[SCRIPT] %s failed, error: %s" % (operation, error_message))


r = storage.get_child_nodes_brief_by_id(asset_hub, root_id,
                                        [{"meta": "type", "condition": "x == asset"}], True,
                                        False)
if not r.is_succeeded():
    on_operation_failed("get_child_nodes_brief_by_id", r.error_message())

asset_ids = []
asset_files = []
for node in r.data:
    file_format = node.get("file_format")
    if file_format and file_format in target_format:
        asset_ids.append(node.get("id"))
        asset_files.append(node.get("origin_url"))

batch_size = 20
for i in range(0, len(asset_ids), batch_size):
    batch_asset_ids = asset_ids[i:i + batch_size]
    batch_asset_files = asset_files[i:i + batch_size]

    res = open_api.depot_convert_asset(asset_hub=asset_hub, asset_ids=batch_asset_ids, asset_files=batch_asset_files)
    if not res.is_succeeded():
        on_operation_failed("convert_asset", res.error_message())
    else:
        print("convert {} asset success".format(len(batch_asset_ids)))

print("batch convert success, total: {}".format(len(asset_ids)))
