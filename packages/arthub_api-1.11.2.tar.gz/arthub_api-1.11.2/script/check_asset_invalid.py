from arthub_api.__main__ import init_config
from arthub_api.__main__ import setup_logging
from arthub_api import arthub_api_config
from arthub_api import (
    OpenAPI,
    Storage,
    api_config_qq,
)
from arthub_api.utils import logger

setup_logging()
init_config()

open_api = OpenAPI(api_config_qq)
res = open_api.login(account_name=arthub_api_config.account_email,
               password=arthub_api_config.password,
               login_public_keys=arthub_api_config.login_public_keys)
if not res.is_succeeded():
    print("login failed, message: %s", res.error_message())
    exit(-1)
storage = Storage(open_api)


def on_operation_failed(operation, error_message):
    logger.error("[SCRIPT] %s failed, error: %s" % (operation, error_message))


def test_invalid_asset(asset_hub, root_id):
    r = storage.get_child_nodes_brief_by_id(asset_hub, root_id,
                                            [{"meta": "type", "condition": "x == asset || x == multiasset"}], True,
                                            False)
    if not r.is_succeeded():
        on_operation_failed("get_child_nodes_brief_by_id", r.error_message())

    error_nodes = []
    download_sign_reqs = []
    for node in r.data:
        crc64 = node.get("crc64")
        capacity = node.get("capacity")
        if (crc64 is None or crc64 == "") and capacity != 0:
            rp = storage.get_child_node_relative_path(node, root_id)
            logger.error("[invalid][crc64] id: %d, path: %s" % (node.get("id"), rp.data))
            error_nodes.append(node)
        else:
            download_sign_reqs.append({
                "object_id": node.get("id"),
                "object_meta": "origin_url"
            })

    return error_nodes, download_sign_reqs
