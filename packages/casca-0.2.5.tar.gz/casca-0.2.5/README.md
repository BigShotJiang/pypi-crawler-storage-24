# Casca

Casca is a lightweight, native Python TUI library with a DOM-like widget tree and CSS-style theming.

## Features

- Zero core dependencies (standard library runtime)
- Declarative widgets (`Container`, `Label`, `Input`, `TextArea`, `Select`, `RadioGroup`, `ListView`, `ProgressBar`, `Spinner`, `DataGrid`, `Button`, `Card`, `Header`, `ScrollView`, `Tabs`)
- CSS-like style parsing and cascade
- Auto-percentage sizing and flex layouts (Row / Column)
- Keyboard and mouse event handling in raw terminal mode
- App state helpers (`invalidate()`, `set_state(...)`) and debug error overlay
- Built-in feedback helpers (`show_toast`, `set_banner`, `clear_banner`)
- Real examples including login screen, dashboard, tabs, and Groq chatbot

## Quick Start

```python
from casca import Container, Label, run_app

CSS = """
#root {
    padding: 1;
    border: ascii;
}
"""



ui_tree = Container(
    Label("Hello from Casca"),
    id="root",
)

if __name__ == "__main__":
    run_app(ui_tree, css=CSS)
```

Or load styles from a file:

```python
from casca import Container, Label, run_app

ui_tree = Container(
    Label("Styled from file.css"),
    id="root",
)

if __name__ == "__main__":
    run_app(ui_tree, css_path="examples/styles/02_forms.css")
```

## Run Use Cases

```bash
python3 -m use_cases.login_screen
python3 -m use_cases.dashboard
python3 -m use_cases.chatbot
```

`use_cases.chatbot` requires `groq` and a `GROQ_API_KEY`.


## Project Layout

- `casca/`: core library
- `use_cases/`: real apps built with Casca
- `examples/`: smaller demos
- `docs/`: MkDocs content

## Release Process

- See `docs/release-checklist.md` for the pre-release and publish checklist.

## License

MIT
