"""Tests for the TextArea multiline input widget."""

from casca import KeyEvent, TextArea


def test_textarea_insert_and_newline():
    ta = TextArea(default_value="hi")

    ta.handle_input(KeyEvent(key="!", is_printable=True))
    ta.handle_input(KeyEvent(key="\r", is_printable=False))
    ta.handle_input(KeyEvent(key="x", is_printable=True))

    assert ta.value == "hi!\nx"


def test_textarea_arrow_navigation_up_down():
    ta = TextArea(default_value="ab\ncd")

    # Start at end of second line (col 2).
    assert ta.cursor_position == len("ab\ncd")

    ta.handle_input(KeyEvent(key="\x1b[A", is_printable=False))
    assert ta.cursor_position == 2

    ta.handle_input(KeyEvent(key="\x1b[B", is_printable=False))
    assert ta.cursor_position == len("ab\ncd")


def test_textarea_backspace_removes_previous_character():
    ta = TextArea(default_value="abc")

    ta.handle_input(KeyEvent(key="\x7f", is_printable=False))

    assert ta.value == "ab"
    assert ta.cursor_position == 2
