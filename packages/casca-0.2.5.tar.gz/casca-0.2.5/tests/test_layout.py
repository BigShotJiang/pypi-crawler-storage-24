"""Layout behavior tests for containers and basic widgets."""

from casca import Container, Label


def _resolve_and_layout(widget, width=80, height=24):
    widget.resolve_styles({})
    return widget.calculate_layout(width, height)


def test_padding_offsets_child_position_in_column_layout():
    child = Label("A")
    root = Container(child, style={"padding": 2})

    _resolve_and_layout(root)

    assert child.x == root.x + 2
    assert child.y == root.y + 2


def test_row_layout_places_children_horizontally():
    left = Label("left")
    right = Label("right")
    root = Container(left, right, style={"flex-direction": "row", "padding": 1})

    _resolve_and_layout(root)

    assert right.x > left.x
    assert right.y == left.y


def test_margin_increases_reported_footprint():
    no_margin = Container(Label("x"), style={"padding": 1})
    with_margin = Container(Label("x"), style={"padding": 1, "margin": 2})

    w1, h1 = _resolve_and_layout(no_margin)
    w2, h2 = _resolve_and_layout(with_margin)

    assert w2 == w1 + 4
    assert h2 == h1 + 4


def test_border_none_does_not_increase_inner_offset():
    child = Label("X")
    root = Container(child, style={"padding": 1, "border": "none"})

    _resolve_and_layout(root)

    assert child.x == root.x + 1
    assert child.y == root.y + 1


def test_per_side_padding_offsets_children():
    child = Label("X")
    root = Container(
        child,
        style={"padding-top": 3, "padding-left": 2, "padding-right": 1, "padding-bottom": 1},
    )

    _resolve_and_layout(root)

    assert child.x == root.x + 2
    assert child.y == root.y + 3


def test_per_side_margin_changes_reported_size():
    base = Container(Label("x"), style={"padding": 1})
    sided = Container(Label("x"), style={"padding": 1, "margin-left": 2, "margin-right": 3, "margin-top": 1, "margin-bottom": 4})

    w1, h1 = _resolve_and_layout(base)
    w2, h2 = _resolve_and_layout(sided)

    assert w2 == w1 + 5
    assert h2 == h1 + 5
