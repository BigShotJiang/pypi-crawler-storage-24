"""Tests for ScrollView behavior."""

from casca import Label, MouseEvent, ScrollView, KeyEvent


class _DummyApp:
    def __init__(self):
        self._running = False

    def _render_cycle(self):
        pass


def _scroll_fixture(height=4):
    scroll = ScrollView(
        Label("L1"), Label("L2"), Label("L3"), Label("L4"), Label("L5"),
        height=height,
    )
    scroll.resolve_styles({})
    scroll.x = 0
    scroll.y = 0
    scroll.calculate_layout(20, 10)
    return scroll


def test_scrollview_down_key_respects_max_scroll():
    scroll = _scroll_fixture()

    for _ in range(100):
        scroll.handle_input(KeyEvent(key="\x1b[B", is_printable=False))

    assert scroll.scroll_y == scroll.max_scroll


def test_scrollview_up_key_not_below_zero():
    scroll = _scroll_fixture()
    scroll.scroll_y = 2

    for _ in range(100):
        scroll.handle_input(KeyEvent(key="\x1b[A", is_printable=False))

    assert scroll.scroll_y == 0


def test_scrollview_wheel_updates_scroll_in_bounds():
    scroll = _scroll_fixture()
    app = _DummyApp()

    down = MouseEvent(x=1, y=1, button=65, pressed=True)
    up = MouseEvent(x=1, y=1, button=64, pressed=True)

    handled_down = scroll.handle_wheel(down, app)
    assert handled_down is True
    assert scroll.scroll_y >= 0

    handled_up = scroll.handle_wheel(up, app)
    assert handled_up is True
    assert scroll.scroll_y >= 0
