"""Tests for App.set_state helper."""

from casca import App


def test_set_state_updates_fields_and_invalidates():
    app = App()
    app.root = object()

    app.set_state(count=1, message="ok")

    assert app.count == 1
    assert app.message == "ok"
    assert app.root is None


def test_set_state_can_skip_rerender():
    app = App()
    marker = object()
    app.root = marker

    app.set_state(rerender=False, count=2)

    assert app.count == 2
    assert app.root is marker
