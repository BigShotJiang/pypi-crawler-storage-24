"""Tests for stylesheet validation warnings."""

from casca.style.css import parse_css, validate_stylesheet


def test_validate_stylesheet_reports_unknown_key():
    sheet = parse_css(".box { made-up-key: 1; color: bright_green; }")
    warnings = validate_stylesheet(sheet)
    assert any("made-up-key" in warning for warning in warnings)


def test_validate_stylesheet_reports_invalid_color():
    sheet = parse_css(".box { color: not-a-real-color; }")
    warnings = validate_stylesheet(sheet)
    assert any("not-a-real-color" in warning for warning in warnings)


def test_validate_stylesheet_accepts_supported_colors():
    sheet = parse_css(".box { color: #00ff00; background: rgb(10,20,30); }")
    warnings = validate_stylesheet(sheet)
    assert warnings == []
