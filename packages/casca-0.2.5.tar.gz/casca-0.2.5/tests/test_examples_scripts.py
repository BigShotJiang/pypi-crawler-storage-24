"""Smoke tests ensuring examples stay small and runnable as scripts."""

from __future__ import annotations

import runpy
from pathlib import Path


EXAMPLES = [
    "01_widgets.py",
    "02_forms.py",
    "03_dialogs.py",
    "04_panels.py",
    "05_navigation.py",
    "06_complete_demo.py",
    "07_inline_css.py",
    "08_data_widgets.py",
    "09_forms_advanced.py",
    "10_progress_spinner.py",
    "11_css_file.py",
    "12_radiogroup.py",
    "13_validation_states.py",
]


def test_examples_expose_build_factory_and_build_ui_tree():
    examples_dir = Path(__file__).resolve().parent.parent / "examples"

    for filename in EXAMPLES:
        namespace = runpy.run_path(str(examples_dir / filename))
        assert "build_example_app" in namespace, f"{filename} must expose build_example_app()"

        app = namespace["build_example_app"]()
        root = app.build_ui()

        assert root is not None, f"{filename} returned empty UI tree"
        root.resolve_styles(app.stylesheet)
        width, height = root.calculate_layout(100, 30)
        assert width > 0 and height > 0, f"{filename} produced invalid layout size"
