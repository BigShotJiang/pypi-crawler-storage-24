"""Tests for RadioGroup widget."""

from casca import KeyEvent, MouseEvent, RadioGroup
from casca.core.events import Keys


def test_radiogroup_keyboard_selection_changes():
    rg = RadioGroup(["A", "B", "C"], selected_index=0)

    rg.handle_input(KeyEvent(key=Keys.DOWN, is_printable=False))
    assert rg.selected_index == 1

    rg.handle_input(KeyEvent(key=Keys.UP, is_printable=False))
    assert rg.selected_index == 0


def test_radiogroup_mouse_selects_specific_option():
    rg = RadioGroup(["A", "B", "C"], selected_index=0)
    rg.resolve_styles({})
    rg.x = 0
    rg.y = 0
    rg.calculate_layout(40, 10)

    handled = rg.on_mouse(MouseEvent(x=1, y=3, button=0, pressed=False))

    assert handled is True
    assert rg.selected_index == 2
    assert rg.value == "C"
