"""Tests for terminal input parsing and key normalization."""

from casca.core.input_parser import parse_terminal_input, parse_terminal_input_incremental
from casca.core.events import Keys


def test_key_normalization_newline_to_carriage_return():
    _mouse, keys, _exit = parse_terminal_input("\n")
    assert len(keys) == 1
    assert keys[0].key == Keys.ENTER
    assert keys[0].is_printable is False


def test_key_normalization_ss3_home_end_to_csi():
    _mouse, keys, _exit = parse_terminal_input("\x1bOH\x1bOF")
    assert [key.key for key in keys] == [Keys.HOME, Keys.END]


def test_function_key_normalization_aliases():
    _mouse, keys, _exit = parse_terminal_input("\x1b[[A\x1b[[B\x1b[15~")
    assert [key.key for key in keys] == [Keys.F1, Keys.F2, Keys.F5]


def test_mixed_stream_parses_mouse_and_keys_and_exit_signal():
    data = "A\x1b[<0;12;7M\x1b[<0;12;7m\x1b[D\x03"
    mouse_events, key_events, exit_requested = parse_terminal_input(data)

    assert exit_requested is True

    assert len(mouse_events) == 2
    assert mouse_events[0].pressed is True
    assert mouse_events[1].pressed is False
    assert mouse_events[0].x == 12 and mouse_events[0].y == 7

    assert [evt.key for evt in key_events] == ["A", "\x1b[D"]
    assert key_events[0].is_printable is True
    assert key_events[1].is_printable is False


def test_incremental_parser_buffers_partial_escape_sequence():
    _m1, keys1, _exit1, trailing1 = parse_terminal_input_incremental("\x1b[")
    assert keys1 == []
    assert trailing1 == "\x1b["

    _m2, keys2, _exit2, trailing2 = parse_terminal_input_incremental("D", pending=trailing1)
    assert [k.key for k in keys2] == [Keys.LEFT]
    assert trailing2 == ""


def test_incremental_parser_buffers_partial_mouse_sequence():
    _m1, _k1, _e1, trailing = parse_terminal_input_incremental("\x1b[<0;10;20")
    assert trailing == "\x1b[<0;10;20"

    m2, _k2, _e2, trailing2 = parse_terminal_input_incremental("M", pending=trailing)
    assert len(m2) == 1
    assert m2[0].x == 10 and m2[0].y == 20
    assert trailing2 == ""
