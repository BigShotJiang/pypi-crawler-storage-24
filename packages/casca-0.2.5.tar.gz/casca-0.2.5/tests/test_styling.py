"""Tests for styling helpers (colors and CSS file loading)."""

from pathlib import Path

from casca.core.ansi import color_from_spec
from casca.style.css import parse_css, load_css_file


def test_color_from_spec_named_and_bright_colors():
    seq = color_from_spec("bright_cyan", "bright_black")
    assert seq.startswith("\x1b[")
    assert "96;100m" in seq


def test_color_from_spec_hex_and_rgb():
    seq = color_from_spec("#12AB34", "rgb(10, 20, 30)")
    assert "38;2;18;171;52" in seq
    assert "48;2;10;20;30" in seq


def test_color_from_spec_256_index():
    seq = color_from_spec("ansi(196)", "ansi(236)")
    assert "38;5;196" in seq
    assert "48;5;236" in seq


def test_parse_css_keeps_rules():
    stylesheet = parse_css(".btn { color: bright_green; text-decoration: underline line-through; }")
    assert stylesheet[".btn"]["color"] == "bright_green"
    assert stylesheet[".btn"]["text-decoration"] == "underline line-through"


def test_load_css_file_reads_content(tmp_path: Path):
    css_file = tmp_path / "sample.css"
    css_file.write_text("#root { color: red; }", encoding="utf-8")

    content = load_css_file(str(css_file))

    assert "#root" in content
    assert "color: red" in content
