"""
Tests for Dialog and Overlay components.
"""

import pytest
from casca import (
    Overlay,
    Modal,
    Dialog,
    Alert,
    Confirm,
    Prompt,
    DialogManager,
    Container,
    Label,
    Button,
    KeyEvent,
    MouseEvent,
)


class TestOverlay:
    """Tests for the Overlay component."""

    def test_overlay_creation(self):
        """Test basic overlay creation."""
        overlay = Overlay(
            Label("Test content"),
            id="test-overlay"
        )
        assert overlay.id == "test-overlay"
        assert overlay.tag == "overlay"
        assert len(overlay.children) == 1

    def test_overlay_closable(self):
        """Test overlay closable property."""
        overlay = Overlay(id="test")
        assert overlay.closable is True

        overlay.closable = False
        assert overlay.closable is False

    def test_overlay_escape_closes(self):
        """Test that Escape key triggers on_close."""
        close_called = False

        def on_close():
            nonlocal close_called
            close_called = True

        overlay = Overlay(on_close=on_close)
        event = KeyEvent(key='\x1b', is_printable=False)  # Escape key
        
        result = overlay.handle_input(event)
        
        assert result is True
        assert close_called is True

    def test_overlay_escape_when_not_closable(self):
        """Test that Escape doesn't close when closable is False."""
        close_called = False

        def on_close():
            nonlocal close_called
            close_called = True

        overlay = Overlay(on_close=on_close)
        overlay.closable = False
        event = KeyEvent(key='\x1b', is_printable=False)
        
        result = overlay.handle_input(event)
        
        assert result is False
        assert close_called is False


class TestModal:
    """Tests for the Modal component."""

    def test_modal_creation(self):
        """Test basic modal creation."""
        modal = Modal(
            "Test Title",
            Label("Content"),
            id="test-modal"
        )
        assert modal.id == "test-modal"
        assert modal.tag == "modal"
        assert modal.modal_title == "Test Title"

    def test_modal_default_dimensions(self):
        """Test modal default width and height."""
        modal = Modal("Title")
        assert modal.preferred_width == 50
        assert modal.preferred_height == 15

    def test_modal_custom_dimensions(self):
        """Test modal with custom dimensions."""
        modal = Modal("Title", width=60, height=20)
        assert modal.preferred_width == 60
        assert modal.preferred_height == 20

    def test_modal_centering(self):
        """Test modal centers itself."""
        modal = Modal("Title", width=40, height=10)
        modal.calculate_layout(80, 24)
        
        # Should be centered
        expected_x = (80 - 40) // 2
        expected_y = (24 - 10) // 2
        assert modal.x == expected_x
        assert modal.y == expected_y

    def test_modal_has_border(self):
        """Test modal has default border styling."""
        modal = Modal("Title")
        # Styles are resolved during render, but default should be set
        assert 'border' not in modal.style or modal.style.get('border') == 'ascii'


class TestDialog:
    """Tests for the Dialog component."""

    def test_dialog_creation(self):
        """Test basic dialog creation."""
        dialog = Dialog(
            "Dialog Title",
            "This is the message"
        )
        assert dialog.tag == "dialog"
        assert dialog.dialog_message == "This is the message"

    def test_dialog_with_buttons(self):
        """Test dialog with custom buttons."""
        btn1 = Button("OK")
        btn2 = Button("Cancel")
        
        dialog = Dialog(
            "Title",
            "Message",
            btn1,
            btn2
        )
        
        # Should have title, message, and button container
        assert len(dialog.children) >= 2


class TestAlert:
    """Tests for the Alert component."""

    def test_alert_creation(self):
        """Test basic alert creation."""
        alert = Alert(
            "Alert Title",
            "Alert message"
        )
        assert alert.tag == "alert"

    def test_alert_custom_ok_text(self):
        """Test alert with custom OK button text."""
        alert = Alert("Title", "Message", ok_text="Dismiss")
        # ok_text is used internally, verify it's passed correctly
        assert alert.tag == "alert"

    def test_alert_callback(self):
        """Test alert on_close callback."""
        callback_called = False

        def on_close():
            nonlocal callback_called
            callback_called = True

        alert = Alert("Title", "Message", on_close=on_close)
        # Structure: Alert -> Modal -> Overlay -> [title_label, content_container]
        # content_container has [message_label, button_container]
        # button_container has [ok_button]
        btn_container = None
        for child in alert.children:
            if hasattr(child, 'classes') and 'modal-content' in child.classes:
                for subchild in child.children:
                    if hasattr(subchild, 'classes') and 'dialog-buttons' in subchild.classes:
                        btn_container = subchild
                        break
                break
        
        if btn_container:
            for btn in btn_container.children:
                if isinstance(btn, Button):
                    if btn.on_click:
                        btn.on_click(MouseEvent(x=1, y=1, button=0, pressed=False))
                        break
        
        assert callback_called is True

    def test_alert_yellow_background(self):
        """Test alert has yellow background by default."""
        alert = Alert("Title", "Message")
        # Default background should be yellow
        assert 'background' not in alert.style or alert.style.get('background') == 'YELLOW'


class TestConfirm:
    """Tests for the Confirm component."""

    def test_confirm_creation(self):
        """Test basic confirm creation."""
        confirm = Confirm(
            "Confirm Title",
            "Are you sure?"
        )
        assert confirm.tag == "confirm"

    def test_confirm_custom_button_texts(self):
        """Test confirm with custom button texts."""
        confirm = Confirm(
            "Title",
            "Message",
            ok_text="Proceed",
            cancel_text="Stop"
        )
        assert confirm.tag == "confirm"

    def test_confirm_callback_with_true(self):
        """Test confirm callback with confirmation."""
        result = None

        def on_confirm(confirmed: bool):
            nonlocal result
            result = confirmed

        confirm = Confirm("Title", "Message", on_confirm=on_confirm)
        
        # Find button container inside modal-content
        btn_container = None
        for child in confirm.children:
            if hasattr(child, 'classes') and 'modal-content' in child.classes:
                for subchild in child.children:
                    if hasattr(subchild, 'classes') and 'dialog-buttons' in subchild.classes:
                        btn_container = subchild
                        break
                break
        
        if btn_container and len(btn_container.children) > 0:
            first_btn = btn_container.children[0]
            if isinstance(first_btn, Button) and first_btn.on_click:
                first_btn.on_click(MouseEvent(x=1, y=1, button=0, pressed=False))
        
        assert result is True

    def test_confirm_callback_with_false(self):
        """Test confirm callback with cancellation."""
        result = None

        def on_confirm(confirmed: bool):
            nonlocal result
            result = confirmed

        confirm = Confirm("Title", "Message", on_confirm=on_confirm)
        
        # Find button container inside modal-content
        btn_container = None
        for child in confirm.children:
            if hasattr(child, 'classes') and 'modal-content' in child.classes:
                for subchild in child.children:
                    if hasattr(subchild, 'classes') and 'dialog-buttons' in subchild.classes:
                        btn_container = subchild
                        break
                break
        
        if btn_container and len(btn_container.children) > 1:
            second_btn = btn_container.children[1]
            if isinstance(second_btn, Button) and second_btn.on_click:
                second_btn.on_click(MouseEvent(x=1, y=1, button=0, pressed=False))
        
        assert result is False

    def test_confirm_red_background(self):
        """Test confirm has red background by default."""
        confirm = Confirm("Title", "Message")
        assert 'background' not in confirm.style or confirm.style.get('background') == 'RED'


class TestPrompt:
    """Tests for the Prompt component."""

    def test_prompt_creation(self):
        """Test basic prompt creation."""
        prompt = Prompt(
            "Prompt Title",
            "Enter value:"
        )
        assert prompt.tag == "prompt"

    def test_prompt_with_placeholder(self):
        """Test prompt with placeholder text."""
        prompt = Prompt(
            "Title",
            "Message",
            placeholder="Enter your name"
        )
        assert prompt.input_field is not None

    def test_prompt_submit_callback(self):
        """Test prompt submit callback with value."""
        result = None

        def on_submit(value: str):
            nonlocal result
            result = value

        prompt = Prompt("Title", "Message", on_submit=on_submit)
        
        # Simulate input
        prompt.input_field.value = "Test Value"
        
        # Find button container inside modal-content
        # Structure: [input_field, ok_button, cancel_button]
        btn_container = None
        for child in prompt.children:
            if hasattr(child, 'classes') and 'modal-content' in child.classes:
                for subchild in child.children:
                    if hasattr(subchild, 'classes') and 'dialog-buttons' in subchild.classes:
                        btn_container = subchild
                        break
                break
        
        # Buttons are at index 1 (OK) and 2 (Cancel), index 0 is input field
        if btn_container and len(btn_container.children) > 1:
            ok_btn = btn_container.children[1]  # Second child is OK button
            if isinstance(ok_btn, Button) and ok_btn.on_click:
                ok_btn.on_click(MouseEvent(x=1, y=1, button=0, pressed=False))
        
        assert result == "Test Value"

    def test_prompt_cancel_callback(self):
        """Test prompt cancel callback."""
        result = None

        def on_submit(value: str):
            nonlocal result
            result = value

        prompt = Prompt("Title", "Message", on_submit=on_submit)
        
        # Find button container inside modal-content
        # Structure: [input_field, ok_button, cancel_button]
        btn_container = None
        for child in prompt.children:
            if hasattr(child, 'classes') and 'modal-content' in child.classes:
                for subchild in child.children:
                    if hasattr(subchild, 'classes') and 'dialog-buttons' in subchild.classes:
                        btn_container = subchild
                        break
                break
        
        # Buttons are at index 1 (OK) and 2 (Cancel), index 0 is input field
        if btn_container and len(btn_container.children) > 2:
            cancel_btn = btn_container.children[2]  # Third child is cancel button
            if isinstance(cancel_btn, Button) and cancel_btn.on_click:
                cancel_btn.on_click(MouseEvent(x=1, y=1, button=0, pressed=False))
        
        assert result == ""

    def test_prompt_cyan_background(self):
        """Test prompt has cyan background by default."""
        prompt = Prompt("Title", "Message")
        assert 'background' not in prompt.style or prompt.style.get('background') == 'CYAN'


class TestDialogManager:
    """Tests for the DialogManager component."""

    def test_manager_creation(self):
        """Test dialog manager creation."""
        manager = DialogManager()
        assert manager.has_dialogs is False
        assert manager.current_dialog is None

    def test_push_dialog(self):
        """Test pushing a dialog to the manager."""
        manager = DialogManager()
        alert = Alert("Title", "Message")
        
        manager.push(alert)
        
        assert manager.has_dialogs is True
        assert manager.current_dialog == alert

    def test_pop_dialog(self):
        """Test popping a dialog from the manager."""
        manager = DialogManager()
        alert = Alert("Title", "Message")
        manager.push(alert)
        
        popped = manager.pop()
        
        assert popped == alert
        assert manager.has_dialogs is False
        assert manager.current_dialog is None

    def test_clear_dialogs(self):
        """Test clearing all dialogs."""
        manager = DialogManager()
        manager.push(Alert("Title 1", "Message 1"))
        manager.push(Alert("Title 2", "Message 2"))
        
        manager.clear()
        
        assert manager.has_dialogs is False
        assert manager.current_dialog is None

    def test_dialog_stack_order(self):
        """Test dialog stack maintains order."""
        manager = DialogManager()
        alert1 = Alert("First", "Message 1")
        alert2 = Alert("Second", "Message 2")
        alert3 = Alert("Third", "Message 3")
        
        manager.push(alert1)
        manager.push(alert2)
        manager.push(alert3)
        
        assert manager.current_dialog == alert3
        
        manager.pop()
        assert manager.current_dialog == alert2
        
        manager.pop()
        assert manager.current_dialog == alert1

    def test_pop_empty_stack(self):
        """Test popping from empty stack returns None."""
        manager = DialogManager()
        popped = manager.pop()
        assert popped is None


class TestConvenienceFunctions:
    """Tests for show_alert, show_confirm, show_prompt functions."""

    def test_show_alert_with_manager(self):
        """Test show_alert function with dialog manager."""
        from casca import show_alert
        
        class MockApp:
            def __init__(self):
                self.dialog_manager = DialogManager()
        
        app = MockApp()
        alert = show_alert(app, "Title", "Message")
        
        assert isinstance(alert, Alert)
        assert app.dialog_manager.has_dialogs is True

    def test_show_confirm_with_manager(self):
        """Test show_confirm function with dialog manager."""
        from casca import show_confirm
        
        class MockApp:
            def __init__(self):
                self.dialog_manager = DialogManager()
        
        app = MockApp()
        confirm = show_confirm(app, "Title", "Message")
        
        assert isinstance(confirm, Confirm)
        assert app.dialog_manager.has_dialogs is True

    def test_show_prompt_with_manager(self):
        """Test show_prompt function with dialog manager."""
        from casca import show_prompt
        
        class MockApp:
            def __init__(self):
                self.dialog_manager = DialogManager()
        
        app = MockApp()
        prompt = show_prompt(app, "Title", "Message")
        
        assert isinstance(prompt, Prompt)
        assert app.dialog_manager.has_dialogs is True
