"""Tests for app-level error handling and debug overlay behavior."""

from casca.core.app import App


class BadRenderApp(App):
    def render(self):
        raise RuntimeError("render failed")


def test_on_error_debug_mode_records_traceback_lines():
    app = App()
    app.debug = True

    try:
        raise ValueError("boom")
    except ValueError as exc:
        app.on_error(exc, "unit-test")

    assert app._last_error_lines
    assert "ERROR in unit-test" in app._last_error_lines[0]


def test_safe_render_cycle_does_not_raise_on_render_exception(capsys):
    app = BadRenderApp()
    app.debug = False

    app._safe_render_cycle()

    captured = capsys.readouterr()
    assert "render failed" in captured.err
