"""Focus traversal tests for Tab and Shift+Tab behavior."""

from casca import App, Container, Button, Input, TextArea, KeyEvent


class FocusApp(App):
    def build_ui(self):
        return Container(
            Input(id="in-1"),
            Button("B1", id="btn-1"),
            TextArea(id="ta-1", width=8, height=3),
            Input(id="in-2"),
        )


def _build_ready_app(app_cls=FocusApp):
    app = app_cls()
    app.root = app.build_ui()
    app.root.resolve_styles(app.stylesheet)
    app.root.x = 0
    app.root.y = 0
    app.root.calculate_layout(80, 24)
    return app


def test_tab_focus_cycles_forward():
    app = _build_ready_app()

    app.handle_input(KeyEvent(key="\t", is_printable=False))
    assert app.focused_id == "in-1"

    app.handle_input(KeyEvent(key="\t", is_printable=False))
    assert app.focused_id == "btn-1"

    app.handle_input(KeyEvent(key="\t", is_printable=False))
    assert app.focused_id == "ta-1"

    app.handle_input(KeyEvent(key="\t", is_printable=False))
    assert app.focused_id == "in-2"


def test_shift_tab_focus_cycles_backward():
    app = _build_ready_app()

    app.handle_input(KeyEvent(key="\t", is_printable=False))
    app.handle_input(KeyEvent(key="\t", is_printable=False))
    assert app.focused_id == "btn-1"

    app.handle_input(KeyEvent(key="\x1b[Z", is_printable=False))
    assert app.focused_id == "in-1"


class _DummyDialogManager:
    def __init__(self):
        self.has_dialogs = True
        self.current_dialog = None
        self.events = []

    def handle_input(self, event):
        self.events.append(event.key)
        return True


class DialogTrapApp(FocusApp):
    def __init__(self):
        super().__init__()
        self.dialog_manager = _DummyDialogManager()


def test_dialog_trap_routes_input_to_dialog_manager():
    app = _build_ready_app(DialogTrapApp)

    app.handle_input(KeyEvent(key="a", is_printable=True))

    assert app.dialog_manager.events == ["a"]
