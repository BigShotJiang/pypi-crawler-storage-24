from casca import (
    App,
    Container,
    Label,
    Button,
    Input,
    Checkbox,
    Card,
    Header,
    ProgressBar,
    Spinner,
    DataGrid,
    RadioGroup,
)


def test_core_imports_exist():
    assert App is not None
    assert Container is not None
    assert Label is not None
    assert Button is not None
    assert Input is not None
    assert Checkbox is not None
    assert Card is not None
    assert Header is not None
    assert ProgressBar is not None
    assert Spinner is not None
    assert DataGrid is not None
    assert RadioGroup is not None
