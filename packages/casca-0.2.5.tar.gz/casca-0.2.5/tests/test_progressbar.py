"""Tests for ProgressBar widget."""

from casca import ProgressBar


class FakeApp:
    def __init__(self):
        self.draw_calls = []
        self.writes = []

    def write(self, text: str):
        self.writes.append(text)

    def draw_text(self, x: int, y: int, text: str, apply_clip=True):
        self.draw_calls.append((x, y, text))


def test_progressbar_clamps_value_bounds():
    bar = ProgressBar(value=150, min_value=0, max_value=100)
    assert bar.value == 100

    bar.set_value(-10)
    assert bar.value == 0


def test_progressbar_renders_bar_and_percentage():
    bar = ProgressBar(value=50, width=20, show_percentage=True)
    bar.resolve_styles({})
    bar.x = 0
    bar.y = 0
    bar.calculate_layout(80, 24)

    app = FakeApp()
    bar.render(app)

    assert len(app.draw_calls) == 1
    _x, _y, line = app.draw_calls[0]
    assert "[" in line and "]" in line
    assert "50%" in line
