"""
Checkbox widget for boolean input.
"""

from typing import Optional, Callable
from ..widgets.base import WidgetBase
from ...core.events import KeyEvent, MouseEvent
from ...style.css import get_border_width, get_box_spacing
from ._validation import ValidatableField, Validator


class Checkbox(WidgetBase, ValidatableField):
    """
    A selectable checkbox with label.
    
    Supports keyboard (Enter/Space) and mouse clicks for toggling.
    """
    tag = 'checkbox'

    def __init__(
        self,
        label_text: str = "",
        checked: bool = False,
        id: str = "",
        classes: str = "",
        on_change: Optional[Callable[[bool], None]] = None,
        validator: Optional[Validator] = None,
        **props
    ):
        super().__init__(id=id, classes=classes, **props)
        self.label_text = label_text
        self.checked = checked
        self.on_change = on_change
        self._init_validation(validator)

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate size based on label text."""
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, 'margin')

        self.content_height = 1
        self.content_width = len(self.label_text) + 4  # "[x] " + text

        self.width = self.content_width + pad_left + pad_right + border_width * 2
        self.height = self.content_height + pad_top + pad_bottom + border_width * 2
        
        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        """Render checkbox with state indicator."""
        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        state_char = '✓' if self.checked else ' '
        
        # Add focus indicator
        if self.focused and not self._disabled:
            state_char = 'x' if self.checked else 'o'
        
        display_text = f"[{state_char}] {self.label_text}"
        app.draw_text(
            self.x + pad_left + border_width + 1,
            self.y + pad_top + border_width + 1,
            display_text
        )

    def handle_input(self, event: KeyEvent) -> bool:
        """Toggle on Enter or Space."""
        if self._disabled:
            return False
            
        if event.key in ('\r', ' '):  # Toggle on Enter or Space
            self.toggle()
            return True
        return super().handle_input(event)

    def on_mouse(self, event: MouseEvent) -> bool:
        """Toggle on left click release."""
        if self._disabled:
            return False
            
        if event.button == 0 and not event.pressed:
            self.toggle()
            return True
        return False

    def toggle(self):
        """Toggle the checkbox state."""
        self.checked = not self.checked
        self.validate(self.checked)
        if self.on_change:
            self.on_change(self.checked)

    def set_checked(self, checked: bool):
        """Set checkbox state programmatically."""
        if self.checked != checked:
            self.checked = checked
            self.validate(self.checked)
            if self.on_change:
                self.on_change(self.checked)
