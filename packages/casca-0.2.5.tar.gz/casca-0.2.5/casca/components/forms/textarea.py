"""TextArea widget for multiline text entry."""

from typing import Optional, Callable

from ..widgets.base import WidgetBase
from ...core.events import KeyEvent, MouseEvent
from ...style.css import get_border_width, get_box_spacing
from ._validation import ValidatableField, Validator


class TextArea(WidgetBase, ValidatableField):
    """A multiline text input widget with basic keyboard navigation."""

    tag = "textarea"

    def __init__(
        self,
        placeholder: str = "",
        default_value: str = "",
        id: str = "",
        classes: str = "",
        on_submit: Optional[Callable[[str], None]] = None,
        validator: Optional[Validator] = None,
        **props,
    ):
        super().__init__(id=id, classes=classes, **props)
        self.placeholder = placeholder
        self.value = default_value
        self.on_submit = on_submit
        self._init_validation(validator)
        self.cursor_position = len(default_value)
        self._scroll_line = 0

        if "width" not in self.props:
            self.props["width"] = 40
        if "height" not in self.props:
            self.props["height"] = 6

    def _lines(self) -> list[str]:
        return self.value.split("\n") if self.value else [""]

    def _index_to_row_col(self, index: int) -> tuple[int, int]:
        row = 0
        col = 0
        remaining = max(0, min(index, len(self.value)))
        for line in self._lines():
            line_len = len(line)
            if remaining <= line_len:
                col = remaining
                return row, col
            remaining -= line_len
            if remaining > 0:
                remaining -= 1
            row += 1
        return row, col

    def _row_col_to_index(self, row: int, col: int) -> int:
        lines = self._lines()
        row = max(0, min(row, len(lines) - 1))
        col = max(0, min(col, len(lines[row])))

        index = 0
        for i in range(row):
            index += len(lines[i]) + 1
        index += col
        return index

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, 'margin')

        self.width = int(self.props.get("width", 40))
        base_height = int(self.props.get("height", 6))
        self.height = base_height + (1 if self.invalid and self.error_message else 0)
        self.content_width = max(1, self.width - (pad_left + pad_right + 2 * border_width))
        self.content_height = max(1, base_height - (pad_top + pad_bottom + 2 * border_width))

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        pad_top, pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        inner_width = max(1, self.width - (pad_left + pad_right + border_width * 2))
        inner_height = max(1, self.height - (pad_top + _pad_bottom + border_width * 2))

        lines = self._lines()
        cursor_row, cursor_col = self._index_to_row_col(self.cursor_position)

        if cursor_row < self._scroll_line:
            self._scroll_line = cursor_row
        elif cursor_row >= self._scroll_line + inner_height:
            self._scroll_line = cursor_row - inner_height + 1

        if not self.value and self.placeholder:
            lines = [self.placeholder]

        visible_start = self._scroll_line
        for i in range(inner_height):
            line_idx = visible_start + i
            line = lines[line_idx] if line_idx < len(lines) else ""

            if self.focused and not self._disabled and line_idx == cursor_row:
                col = min(cursor_col, len(line))
                line = line[:col] + "█" + line[col:]

            app.draw_text(
                self.x + pad_left + border_width + 1,
                self.y + pad_top + border_width + 1 + i,
                line[:inner_width],
            )

        if self.invalid and self.error_message:
            app.draw_text(
                self.x + pad_left + border_width + 1,
                self.y + pad_top + border_width + 1 + inner_height,
                f"! {self.error_message}"[:inner_width],
            )

    def handle_input(self, event: KeyEvent) -> bool:
        if self._disabled:
            return False

        if event.key in ("\x08", "\x7f", "\b"):
            if self.cursor_position > 0:
                self.value = self.value[: self.cursor_position - 1] + self.value[self.cursor_position :]
                self.cursor_position -= 1
            return True

        if event.key in ("\r", "\n"):
            self.value = self.value[: self.cursor_position] + "\n" + self.value[self.cursor_position :]
            self.cursor_position += 1
            self.validate(self.value)
            if self.on_submit:
                self.on_submit(self.value)
            return True

        if event.is_printable and len(event.key) == 1:
            self.value = self.value[: self.cursor_position] + event.key + self.value[self.cursor_position :]
            self.cursor_position += 1
            if self.invalid:
                self.validate(self.value)
            return True

        if event.key == "\x1b[D":
            self.cursor_position = max(0, self.cursor_position - 1)
            return True

        if event.key == "\x1b[C":
            self.cursor_position = min(len(self.value), self.cursor_position + 1)
            return True

        if event.key == "\x1b[A":
            row, col = self._index_to_row_col(self.cursor_position)
            self.cursor_position = self._row_col_to_index(row - 1, col)
            return True

        if event.key == "\x1b[B":
            row, col = self._index_to_row_col(self.cursor_position)
            self.cursor_position = self._row_col_to_index(row + 1, col)
            return True

        if event.key == "\x1b[H":
            row, _col = self._index_to_row_col(self.cursor_position)
            self.cursor_position = self._row_col_to_index(row, 0)
            return True

        if event.key == "\x1b[F":
            row, _col = self._index_to_row_col(self.cursor_position)
            target_line = self._lines()[max(0, min(row, len(self._lines()) - 1))]
            self.cursor_position = self._row_col_to_index(row, len(target_line))
            return True

        return super().handle_input(event)

    def on_mouse(self, event: MouseEvent) -> bool:
        if self._disabled:
            return False
        if event.pressed:
            return True
        return False

    def set_value(self, value: str):
        self.value = value
        self.cursor_position = len(value)
        self.validate(self.value)

    def clear(self):
        self.value = ""
        self.cursor_position = 0
        self._scroll_line = 0
