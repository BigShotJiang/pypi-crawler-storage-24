"""Shared validation behavior for form widgets."""

from __future__ import annotations

from typing import Callable, Optional

Validator = Callable[[object], str | bool | None]


class ValidatableField:
    """Mixin for form widgets that expose invalid/error state."""

    validator: Optional[Validator]
    invalid: bool
    error_message: str

    def _init_validation(self, validator: Optional[Validator] = None):
        self.validator = validator
        self.invalid = False
        self.error_message = ""

    def _sync_invalid_class(self):
        if not hasattr(self, "classes"):
            return
        if self.invalid and "invalid" not in self.classes:
            self.classes.append("invalid")
        if not self.invalid and "invalid" in self.classes:
            self.classes.remove("invalid")

    def set_error(self, message: str):
        self.invalid = True
        self.error_message = message
        self._sync_invalid_class()

    def clear_error(self):
        self.invalid = False
        self.error_message = ""
        self._sync_invalid_class()

    def validate(self, value: object | None = None) -> bool:
        if not self.validator:
            self.clear_error()
            return True

        result = self.validator(value)
        if result is True or result is None:
            self.clear_error()
            return True
        if result is False:
            self.set_error("Invalid value")
            return False

        message = str(result).strip() or "Invalid value"
        self.set_error(message)
        return False
