"""Select/Dropdown widget."""

from typing import Callable, Optional

from ..widgets.base import WidgetBase
from ...core.events import KeyEvent, MouseEvent
from ...style.css import get_border_width, get_box_spacing
from ._validation import ValidatableField, Validator


class Select(WidgetBase, ValidatableField):
    """A simple dropdown select widget with keyboard and mouse controls."""

    tag = "select"

    def __init__(
        self,
        options: list[str],
        selected_index: int = 0,
        id: str = "",
        classes: str = "",
        on_change: Optional[Callable[[str, int], None]] = None,
        validator: Optional[Validator] = None,
        **props,
    ):
        super().__init__(id=id, classes=classes, **props)
        self.options = options or [""]
        self.selected_index = max(0, min(selected_index, len(self.options) - 1))
        self.on_change = on_change
        self.expanded = False
        self._init_validation(validator)

    @property
    def value(self) -> str:
        return self.options[self.selected_index]

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")
        border_width = get_border_width(self.style)

        base_width = max(len(option) for option in self.options) + 4
        self.width = int(self.props.get("width", base_width + pad_left + pad_right + 2 * border_width))

        content_rows = 1 + (len(self.options) if self.expanded else 0) + (1 if self.invalid and self.error_message else 0)
        self.content_height = content_rows
        self.height = content_rows + pad_top + pad_bottom + 2 * border_width

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        inner_width = max(1, self.width - pad_left - _pad_right - (2 * border_width))

        marker = "▾" if not self.expanded else "▴"
        selected = f"{self.value} {marker}"[:inner_width]
        app.draw_text(
            self.x + pad_left + border_width + 1,
            self.y + pad_top + border_width + 1,
            selected,
        )

        if self.expanded:
            for idx, option in enumerate(self.options, start=1):
                prefix = "> " if idx - 1 == self.selected_index else "  "
                line = f"{prefix}{option}"[:inner_width]
                app.draw_text(
                    self.x + pad_left + border_width + 1,
                    self.y + pad_top + border_width + 1 + idx,
                    line,
                )

        if self.invalid and self.error_message:
            error_y = self.y + pad_top + border_width + 2 + (len(self.options) if self.expanded else 0)
            app.draw_text(
                self.x + pad_left + border_width + 1,
                error_y,
                f"! {self.error_message}"[:inner_width],
            )

    def _emit_change(self):
        self.validate(self.value)
        if self.on_change:
            self.on_change(self.value, self.selected_index)

    def handle_input(self, event: KeyEvent) -> bool:
        if self._disabled:
            return False

        if event.key in ("\r", " "):
            self.expanded = not self.expanded
            return True

        if event.key == "\x1b" and self.expanded:
            self.expanded = False
            return True

        if event.key == "\x1b[A" and self.expanded:
            self.selected_index = max(0, self.selected_index - 1)
            self._emit_change()
            return True

        if event.key == "\x1b[B" and self.expanded:
            self.selected_index = min(len(self.options) - 1, self.selected_index + 1)
            self._emit_change()
            return True

        return super().handle_input(event)

    def on_mouse(self, event: MouseEvent) -> bool:
        if self._disabled:
            return False

        if event.button != 0:
            return False

        if event.pressed:
            return True

        pad_top, _pad_right, _pad_bottom, _pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        local_y = (event.y - 1) - self.y - pad_top - border_width

        if local_y <= 0:
            self.expanded = not self.expanded
            return True

        if self.expanded:
            option_index = local_y - 1
            if 0 <= option_index < len(self.options):
                self.selected_index = option_index
                self.expanded = False
                self._emit_change()
                return True

        return False
