"""
Input widget for text entry.
"""

from typing import Optional, Callable
from ..widgets.base import WidgetBase
from ...core.events import KeyEvent, MouseEvent
from ...core.ansi import move_cursor
from ...style.css import get_border_width, get_box_spacing
from ._validation import ValidatableField, Validator


class Input(WidgetBase, ValidatableField):
    """
    A single-line text input field.
    
    Supports typing, backspace, and submit on Enter.
    """
    tag = 'input'

    def __init__(
        self,
        placeholder: str = "",
        default_value: str = "",
        id: str = "",
        classes: str = "",
        on_submit: Optional[Callable[[str], None]] = None,
        validator: Optional[Validator] = None,
        **props
    ):
        super().__init__(id=id, classes=classes, **props)
        self.placeholder = placeholder
        self.value = default_value
        self.on_submit = on_submit
        self.cursor_position = len(default_value)
        self._init_validation(validator)

        # Default width if not specified
        if 'width' not in self.props:
            self.props['width'] = 20

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate fixed-size input field."""
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, 'margin')

        self.content_height = 1 + (1 if self.invalid and self.error_message else 0)
        self.width = self.props.get('width', 20)
        self.height = self.content_height + pad_top + pad_bottom + border_width * 2

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        """Render input field with cursor and placeholder."""
        pad_top, pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        inner_width = self.width - pad_left - pad_right - (border_width * 2)

        # Determine display text
        if self.value:
            display_text = self.value
        else:
            display_text = self.placeholder

        # Apply cursor for focused input
        if self.focused and not self._disabled:
            if self.cursor_position <= len(display_text):
                display_text = (
                    display_text[:self.cursor_position] +
                    '█' +
                    display_text[self.cursor_position:]
                )

        # Truncate to visible width
        visible_text = display_text[:inner_width]
        
        app.draw_text(
            self.x + pad_left + border_width + 1,
            self.y + pad_top + border_width + 1,
            visible_text
        )

        if self.invalid and self.error_message:
            app.draw_text(
                self.x + pad_left + border_width + 1,
                self.y + pad_top + border_width + 2,
                f"! {self.error_message}"[:inner_width],
            )

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle text input and editing."""
        if self._disabled:
            return False

        # Backspace / Delete
        if event.key in ('\x08', '\x7f', '\b'):
            if self.cursor_position > 0:
                self.value = self.value[:self.cursor_position - 1] + self.value[self.cursor_position:]
                self.cursor_position -= 1
            return True
        
        # Enter - submit
        elif event.key in ('\r', '\n'):
            self.validate(self.value)
            if self.on_submit:
                self.on_submit(self.value)
            return True
        
        # Printable characters - type
        elif event.is_printable and len(event.key) == 1:
            self.value = self.value[:self.cursor_position] + event.key + self.value[self.cursor_position:]
            self.cursor_position += 1
            if self.invalid:
                self.validate(self.value)
            return True

        # Arrow keys for cursor navigation
        elif event.key == '\x1b[D':  # Left arrow
            if self.cursor_position > 0:
                self.cursor_position -= 1
            return True
        elif event.key == '\x1b[C':  # Right arrow
            if self.cursor_position < len(self.value):
                self.cursor_position += 1
            return True
        elif event.key == '\x1b[H':  # Home
            self.cursor_position = 0
            return True
        elif event.key == '\x1b[F':  # End
            self.cursor_position = len(self.value)
            return True

        return super().handle_input(event)

    def on_mouse(self, event: MouseEvent) -> bool:
        """Focus on click."""
        if self._disabled:
            return False
            
        if event.pressed:
            # Could implement click-to-position cursor here
            return True
        return False

    def set_value(self, value: str):
        """Set input value programmatically."""
        self.value = value
        self.cursor_position = len(value)
        self.validate(self.value)

    def clear(self):
        """Clear the input field."""
        self.value = ""
        self.cursor_position = 0
