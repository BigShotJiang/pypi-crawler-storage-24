"""
Header component - top navigation/branding panel.
"""

from ..widgets.container import Container


class Header(Container):
    """
    A wide container designed to sit at the top of an app.
    
    Visual characteristics:
    - Full width by default
    - Suitable for branding, navigation, status bars
    
    Usage:
        header = Header(
            Label("My Application", classes="title"),
            Button("Settings", on_click=handle_settings)
        )
    """
    tag = 'header'

    def __init__(self, *children, id: str = "", classes: str = "", **kwargs):
        super().__init__(*children, id=id, classes=classes, **kwargs)
        
        # Default header styling
        if 'style' not in self.props:
            self.props['style'] = {}
        if 'flex-direction' not in self.props['style']:
            self.props['style']['flex-direction'] = 'row'

    def resolve_styles(self, stylesheet: dict):
        """Apply default header styling."""
        super().resolve_styles(stylesheet)
        
        # Headers typically span full width
        if 'width' not in self.style:
            self.style['width'] = '100%'
