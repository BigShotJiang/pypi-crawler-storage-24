"""
ScrollView component - scrollable container.
"""

from ..widgets.container import Container
from ...core.events import KeyEvent, MouseEvent
from ...core.ansi import RESET


class ScrollView(Container):
    """
    A container that clips its children vertically and allows scrolling.
    
    Features:
    - Vertical scrolling with mouse wheel
    - Keyboard navigation (arrow keys)
    - Visual scrollbar indicator
    - Auto-scroll to bottom option
    - Content clipping
    
    Usage:
        scroll = ScrollView(
            Label("Line 1"),
            Label("Line 2"),
            # ... many more lines
            height=10
        )
    """
    tag = 'scrollview'

    def __init__(self, *args, scroll_to_bottom: bool = False, **kwargs):
        super().__init__(*args, **kwargs)
        self.scroll_y = 0
        self.max_scroll = 0
        self.props['scroll_to_bottom'] = scroll_to_bottom
        self._last_max = 0

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate layout and scroll bounds."""
        padding, border_width = self._get_inner_bounds()
        margin = int(self.style.get('margin', 0))

        self.width = self.props.get('width', int(self.style.get('width', available_width)))

        set_height = self.props.get('height') or self.style.get('height')
        if set_height:
            self.height = int(set_height)
        else:
            self.height = available_height

        inner_width = max(0, self.width - 2 * (padding + border_width))

        current_y = 0
        max_child_width = 0

        # Calculate children sizes assuming infinite height
        for child in self.children:
            child.x = self.x + padding + border_width
            child.y = self.y + padding + border_width + current_y

            child_w, child_h = child.calculate_layout(inner_width, 9999)
            current_y += child_h
            max_child_width = max(max_child_width, child_w)

        self.content_height = current_y
        self.content_width = max_child_width

        inner_height = max(0, self.height - 2 * (padding + border_width))
        self.max_scroll = max(0, self.content_height - inner_height)

        # Auto-scroll logic
        was_at_bottom = self._last_max > 0 and self.scroll_y >= self._last_max
        is_first_layout = self._last_max == 0

        if self.props.get('scroll_to_bottom'):
            if is_first_layout or was_at_bottom:
                self.scroll_y = self.max_scroll

        self._last_max = self.max_scroll

        # Clamp scroll position
        if self.scroll_y > self.max_scroll:
            self.scroll_y = self.max_scroll
        if self.scroll_y < 0:
            self.scroll_y = 0

        # Apply scroll offset
        self._apply_scroll_offset()

        return self.width + margin * 2, self.height + margin * 2

    def _apply_scroll_offset(self):
        """Apply scroll offset to all children."""
        def shift(node, offset):
            node.y -= offset
            for c in node.children:
                shift(c, offset)

        for child in self.children:
            shift(child, self.scroll_y)

    def render(self, app):
        """Render with clipping and scrollbar."""
        padding, border_width = self._get_inner_bounds()

        min_y = self.y + padding + border_width + 1
        max_y = min_y + max(0, self.height - 2 * (padding + border_width))
        min_x = self.x + padding + border_width + 1
        max_x = min_x + max(0, self.width - 2 * (padding + border_width))

        prev_clip = getattr(app, 'clip_rect', None)
        app.clip_rect = (min_y, max_y, min_x, max_x)

        self.apply_style(app)

        # Background fill
        if 'background' in self.style:
            for r in range(self.height):
                app.draw_text(self.x + 1, self.y + r + 1, " " * self.width, apply_clip=False)
            self.apply_style(app)

        # Border
        if self.style.get('border', 'none') != 'none':
            self._draw_border(app)

        # Scrollbar
        self._draw_scrollbar(app)

        # Children
        for child in self.children:
            child.render(app)
            self.apply_style(app)

        app.clip_rect = prev_clip
        app.write(RESET)

    def _draw_scrollbar(self, app):
        """Draw visual scrollbar indicator."""
        inner_height = max(0, self.height - 2)
        if self.max_scroll > 0 and inner_height > 0:
            thumb_size = max(1, int(inner_height * (inner_height / (self.content_height or 1))))
            thumb_pos = int((self.scroll_y / self.max_scroll) * (inner_height - thumb_size))

            for i in range(inner_height):
                char = '█' if thumb_pos <= i < thumb_pos + thumb_size else '▒'
                app.draw_text(self.x + self.width - 1, self.y + 2 + i, char, apply_clip=False)

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle keyboard scrolling."""
        # Check children first
        if super().handle_input(event):
            return True

        # Arrow key scrolling
        if event.key == '\x1b[A':  # Up Arrow
            self.scroll_y = max(0, self.scroll_y - 1)
            return True
        elif event.key == '\x1b[B':  # Down arrow
            self.scroll_y = min(self.max_scroll, self.scroll_y + 1)
            return True

        return False

    def handle_wheel(self, event: MouseEvent, app) -> bool:
        """Handle mouse wheel scrolling."""
        term_x = event.x - 1
        term_y = event.y - 1

        if self.x <= term_x < self.x + self.width and self.y <= term_y < self.y + self.height:
            if event.button == 64:  # Scroll up
                self.scroll_y = max(0, self.scroll_y - 1)
                if app._running:
                    app._render_cycle()
                return True
            elif event.button == 65:  # Scroll down
                self.scroll_y = min(self.max_scroll, self.scroll_y + 1)
                if app._running:
                    app._render_cycle()
                return True
        return False

    def scroll_to(self, position: int):
        """Scroll to a specific position."""
        self.scroll_y = max(0, min(position, self.max_scroll))

    def scroll_to_top(self):
        """Scroll to the top."""
        self.scroll_y = 0

    def scroll_to_bottom(self):
        """Scroll to the bottom."""
        self.scroll_y = self.max_scroll
