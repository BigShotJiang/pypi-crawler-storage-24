"""
Casca UI Components

Organized into submodules:
- widgets: Base widgets (Container, Label, Button)
- forms: Form inputs (Checkbox, Input)
- dialogs: Modal dialogs (Overlay, Modal, Dialog, Alert, Confirm, Prompt)
- panels: Panel containers (Card, Header)
- navigation: Navigation components (Tabs, ScrollView)
"""

# Re-export all components for backward compatibility
from .widgets import WidgetBase, Container, Label, Button, ListView, ProgressBar, Spinner, DataGrid
from .forms import Checkbox, Input, Select, TextArea, RadioGroup
from .dialogs import (
    Overlay,
    Modal,
    Dialog,
    Alert,
    Confirm,
    Prompt,
    DialogManager,
    show_alert,
    show_confirm,
    show_prompt,
)
from .panels import Card, Header
from .navigation import Tabs, TabItem, ScrollView

__all__ = [
    # Widgets
    "WidgetBase",
    "Container",
    "Label",
    "Button",
    "ListView",
    "ProgressBar",
    "Spinner",
    "DataGrid",
    # Forms
    "Checkbox",
    "Input",
    "Select",
    "TextArea",
    "RadioGroup",
    # Dialogs
    "Overlay",
    "Modal",
    "Dialog",
    "Alert",
    "Confirm",
    "Prompt",
    "DialogManager",
    "show_alert",
    "show_confirm",
    "show_prompt",
    # Panels
    "Card",
    "Header",
    # Navigation
    "Tabs",
    "TabItem",
    "ScrollView",
]
