"""ProgressBar widget for visualizing bounded numeric progress."""

from .base import WidgetBase
from ...style.css import get_border_width, get_box_spacing


class ProgressBar(WidgetBase):
    """Render a single-line progress indicator with optional percentage text."""

    tag = "progressbar"

    def __init__(
        self,
        value: float = 0,
        min_value: float = 0,
        max_value: float = 100,
        show_percentage: bool = True,
        fill_char: str = "=",
        empty_char: str = "-",
        id: str = "",
        classes: str = "",
        **props,
    ):
        super().__init__(id=id, classes=classes, **props)
        self.min_value = min_value
        self.max_value = max_value if max_value > min_value else (min_value + 1)
        self.value = value
        self.show_percentage = show_percentage
        self.fill_char = (fill_char or "=")[0]
        self.empty_char = (empty_char or "-")[0]
        self._clamp_value()

    def _clamp_value(self):
        self.value = max(self.min_value, min(self.value, self.max_value))

    @property
    def progress(self) -> float:
        span = self.max_value - self.min_value
        if span <= 0:
            return 0.0
        return (self.value - self.min_value) / span

    def set_value(self, value: float):
        self.value = value
        self._clamp_value()

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")
        border_width = get_border_width(self.style)

        default_inner_width = 24
        self.width = int(self.props.get("width", default_inner_width + pad_left + pad_right + 2 * border_width))
        self.height = int(self.props.get("height", 1 + pad_top + pad_bottom + 2 * border_width))

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        pad_top, pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)

        inner_width = max(1, self.width - pad_left - pad_right - (2 * border_width))
        pct_suffix = f" {int(self.progress * 100):3d}%" if self.show_percentage else ""
        bar_space = max(3, inner_width - len(pct_suffix))

        # Keep the familiar [====----] shape even at narrow widths.
        bar_inner = max(1, bar_space - 2)
        filled = int(round(bar_inner * self.progress))
        filled = max(0, min(filled, bar_inner))
        bar = f"[{self.fill_char * filled}{self.empty_char * (bar_inner - filled)}]"

        line = (bar + pct_suffix)[:inner_width]
        app.draw_text(
            self.x + pad_left + border_width + 1,
            self.y + pad_top + border_width + 1,
            line,
        )
