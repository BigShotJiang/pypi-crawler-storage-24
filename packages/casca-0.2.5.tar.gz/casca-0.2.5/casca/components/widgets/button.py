"""
Button widget for user interaction.
"""

from typing import Optional, Callable
from .label import Label
from ...core.events import MouseEvent
from ...style.css import get_border_width, get_box_spacing


class Button(Label):
    """
    Clickable button that triggers callbacks on interaction.
    
    Supports keyboard (Enter/Space) and mouse clicks.
    """
    tag = 'button'

    def __init__(
        self,
        text: str = "",
        id: str = "",
        classes: str = "",
        on_click: Optional[Callable] = None,
        **props
    ):
        super().__init__(text=text, id=id, classes=classes, **props)
        self.on_click = on_click

    def handle_input(self, event) -> bool:
        """Handle keyboard input - triggers on Enter or Space."""
        if self._disabled:
            return False
            
        if event.key in ('\r', ' '):  # Enter or Space
            if self.on_click:
                self.on_click(event)
                return True
        return super().handle_input(event)

    def on_mouse(self, event: MouseEvent) -> bool:
        """Handle mouse clicks - triggers on release."""
        if self._disabled:
            return False
            
        # Trigger on mouse release for primary button
        if event.button == 0 and not event.pressed:
            if self.on_click:
                self.on_click(event)
            return True
        return False

    def render_content(self, app):
        """Render button with focus indicator."""
        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)

        for i, line in enumerate(self.lines):
            # Keep the focus indicator in sync with what is actually rendered.
            render_line = f"[{line}]" if self.focused and not self._disabled else line
            app.draw_text(
                self.x + pad_left + border_width + 1,
                self.y + pad_top + border_width + 1 + i,
                render_line
            )
