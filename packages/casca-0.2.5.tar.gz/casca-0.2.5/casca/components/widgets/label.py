"""
Label widget for displaying text.
"""

import textwrap
from .base import WidgetBase
from ...style.css import get_border_width, get_box_spacing


class Label(WidgetBase):
    """
    Displays text with automatic wrapping based on layout boundaries.
    
    Supports multi-line text using \\n character.
    """
    tag = 'label'

    def __init__(self, text: str = "", id: str = "", classes: str = "", **props):
        super().__init__(id=id, classes=classes, **props)
        self.text = text
        self.lines: list[str] = []

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate size based on text content and wrapping."""
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, 'margin')

        # Calculate available inner width for wrapping
        inner_width = available_width - mar_left - mar_right - pad_left - pad_right - (border_width * 2)
        
        w_prop = self.props.get('width') or self.style.get('width')
        if w_prop:
            if isinstance(w_prop, str) and w_prop.endswith('%'):
                inner_width = int(available_width * (float(w_prop.strip('%')) / 100)) - pad_left - pad_right - (border_width * 2)
            else:
                inner_width = int(w_prop) - pad_left - pad_right - (border_width * 2)

        # Parse and wrap text
        self.lines = []
        for line in self.text.split('\\n'):
            if inner_width > 0:
                wrapped = textwrap.wrap(line, max(1, inner_width))
                if not wrapped:
                    self.lines.append("")
                else:
                    self.lines.extend(wrapped)
            else:
                self.lines.append(line)

        self.content_height = len(self.lines)
        self.content_width = max([len(l) for l in self.lines] + [0])

        self.width = self.content_width + pad_left + pad_right + border_width * 2
        self.height = self.content_height + pad_top + pad_bottom + border_width * 2

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        """Render the text content."""
        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)

        for i, line in enumerate(self.lines):
            app.draw_text(
                self.x + pad_left + border_width + 1,
                self.y + pad_top + border_width + 1 + i,
                line
            )

    def set_text(self, text: str):
        """Update the label text and trigger layout recalculation."""
        self.text = text
        # Parent should call calculate_layout again
