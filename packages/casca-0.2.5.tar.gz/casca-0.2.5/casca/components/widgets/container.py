"""
Container widget for layout and grouping.
"""

from .base import WidgetBase
from ...style.css import get_border_width, get_box_spacing


class Container(WidgetBase):
    """
    A generic container for laying out child widgets.
    
    Supports flex-direction for row/column layouts.
    """
    tag = 'container'

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate layout using flow (stacking) or flexbox."""
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, 'margin')

        # Width priority: Direct property -> Inline style -> Available parent width
        raw_width = self.style.get('width', available_width)
        if isinstance(raw_width, str) and raw_width.endswith('%'):
            raw_width = int(available_width * (float(raw_width.strip('%')) / 100))
        self.width = self.props.get('width', int(raw_width))

        # Content layout logic
        is_row = self.style.get('flex-direction') == 'row'

        current_x = pad_left + border_width
        current_y = pad_top + border_width
        max_child_width = 0
        max_child_height = 0

        for child in self.children:
            child_mar_top, _child_mar_right, _child_mar_bottom, child_mar_left = get_box_spacing(child.style, 'margin')
            child.x = self.x + current_x + child_mar_left
            child.y = self.y + current_y + child_mar_top

            inner_avail_width = max(0, self.width - (pad_left + pad_right + 2 * border_width))

            if is_row:
                child_w, child_h = child.calculate_layout(
                    inner_avail_width - (current_x - pad_left - border_width),
                    max(0, available_height - (pad_top + pad_bottom + 2 * border_width))
                )
                current_x += child_w
                max_child_height = max(max_child_height, child_h)
            else:
                child_w, child_h = child.calculate_layout(
                    inner_avail_width,
                    max(0, available_height - current_y - pad_bottom - border_width)
                )
                current_y += child_h
                max_child_width = max(max_child_width, child_w)

        self.content_width = current_x - (pad_left + border_width) if is_row else max_child_width
        self.content_height = max_child_height if is_row else current_y - (pad_top + border_width)

        # Total height including padding, border and margin
        min_height = pad_top + pad_bottom + border_width * 2

        set_height = self.props.get('height') or self.style.get('height')
        if set_height:
            if isinstance(set_height, str) and set_height.endswith('%'):
                self.height = int(available_height * (float(set_height.strip('%')) / 100))
            else:
                self.height = int(set_height)
        else:
            self.height = self.content_height + min_height

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom
