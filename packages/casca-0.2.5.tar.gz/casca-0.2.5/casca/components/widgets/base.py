"""
Base widget class providing common functionality for all widgets.
"""

from typing import Optional, List
from ...dom.node import Widget
from ...core.ansi import color_from_spec, move_cursor, BOLD, FAINT, ITALIC, UNDERLINE, BLINK, REVERSE, STRIKETHROUGH, RESET
from ...core.events import KeyEvent, MouseEvent
from ...style.css import get_border_width, get_box_spacing


class WidgetBase(Widget):
    """
    Enhanced base widget class with common styling and rendering helpers.

    All widgets should inherit from this class to get consistent behavior.
    """

    tag = 'widget_base'

    def __init__(self, *children, id: str = "", classes: str = "", **props):
        super().__init__(*children, id=id, classes=classes, **props)

        # Visual state
        self._hovered = False
        self._disabled = False

    @property
    def disabled(self) -> bool:
        """Check if widget is disabled."""
        return self._disabled

    @disabled.setter
    def disabled(self, value: bool):
        """Set disabled state."""
        self._disabled = value
        if value and self.focused:
            self.focused = False

    def apply_style(self, app):
        """Applies the current widget's computed style and background."""
        app.write(RESET)
        fg_color = self.style.get('color', 'default')
        bg_color = self.style.get('background', 'default')
        if getattr(self, "invalid", False):
            fg_color = self.style.get("error-color", "bright_red")
        app.write(color_from_spec(fg_color, bg_color))

        # Apply text styling
        if self.style.get('font-weight') == 'bold':
            app.write(BOLD)
        if self.style.get('font-style') == 'italic':
            app.write(ITALIC)
        decoration = self.style.get('text-decoration', '')
        if 'underline' in decoration:
            app.write(UNDERLINE)
        if 'line-through' in decoration:
            app.write(STRIKETHROUGH)
        if self.style.get('font-effect') == 'blink':
            app.write(BLINK)
        if self.style.get('font-effect') == 'reverse':
            app.write(REVERSE)
        if 'opacity' in self.style and float(self.style['opacity']) < 1.0:
            app.write(FAINT)

        # Apply disabled state styling
        if self._disabled:
            app.write(FAINT)

    def _draw_background_fill(self, app, char: str = " "):
        """Draw background fill for the widget."""
        if 'background' in self.style:
            for r in range(self.height):
                app.draw_text(self.x + 1, self.y + r + 1, char * self.width)

    def _draw_border(self, app):
        """Draw border around the widget."""
        border_char = self.style.get('border-char', '+') if self.style.get('border') == 'ascii' else '█'
        
        # Top and bottom
        for r in (0, self.height - 1):
            if r >= 0 and self.width > 0:
                app.draw_text(self.x + 1, self.y + r + 1, border_char * self.width)

        # Sides
        for r in range(1, self.height - 1):
            if self.width > 0:
                app.draw_text(self.x + 1, self.y + r + 1, border_char)
                if self.width > 1:
                    app.draw_text(self.x + self.width, self.y + r + 1, border_char)

    def _get_inner_bounds(self) -> tuple:
        """Get the inner content bounds accounting for padding and border."""
        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        border_width = get_border_width(self.style)
        padding = max(pad_top, pad_left)
        return padding, border_width

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle keyboard input - passes to children by default."""
        if self._disabled:
            return False
            
        for child in reversed(self.children):
            if child.handle_input(event):
                return True
        return False

    def handle_mouse(self, event: MouseEvent, app) -> bool:
        """Handle mouse input - checks bounds and passes to children."""
        if self._disabled:
            return False

        # Terminal coordinates are 1-based, widget coordinates are 0-based
        # Event coordinates are 1-based terminal coordinates
        # Widget x,y are 0-based but rendered at x+1, y+1 (1-based)
        # So we need to compare event coordinates directly with widget coordinates + 1
        # OR convert event to 0-based by subtracting 1
        
        # Current approach: convert event to 0-based
        term_x = event.x - 1
        term_y = event.y - 1

        if self.x <= term_x < self.x + self.width and self.y <= term_y < self.y + self.height:
            # Propagate to children first (highest z-index effectively)
            for child in reversed(self.children):
                if child.handle_mouse(event, app):
                    return True

            # Handle focus for interactive widgets
            if event.pressed and self.tag in ('input', 'textarea', 'button', 'checkbox', 'select', 'listview', 'datagrid', 'radiogroup'):
                if app.focused_widget and app.focused_widget != self:
                    app.focused_widget.focused = False
                app.focused_widget = self
                self.focused = True
                if self.id:
                    app.focused_id = self.id

            # Call widget-specific mouse handler
            handled = self.on_mouse(event) or (event.pressed and self.tag in ('input', 'textarea', 'button', 'checkbox', 'select', 'listview', 'datagrid', 'radiogroup'))

            # Special case for scroll wheel
            if not handled and event.button in (64, 65):
                return getattr(self, 'handle_wheel', lambda e, a: False)(event, app)

            return handled
        return False

    def on_mouse(self, event: MouseEvent) -> bool:
        """Override for widget-specific mouse handling."""
        return False

    def render(self, app):
        """Standard render pipeline for all widgets."""
        self.apply_style(app)

        # Draw background
        self._draw_background_fill(app)
        self.apply_style(app)

        # Draw border if present
        if self.style.get('border', 'none') != 'none':
            self._draw_border(app)

        # Draw widget-specific content
        self.render_content(app)

        # Draw children
        for child in self.children:
            child.render(app)
            self.apply_style(app)

        app.write(RESET)

    def render_content(self, app):
        """Override to implement specific widget content rendering."""
        pass
