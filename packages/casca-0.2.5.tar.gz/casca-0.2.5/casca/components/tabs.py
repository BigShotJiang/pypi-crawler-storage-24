"""Backward-compatible tabs import path.

Prefer importing from `casca.components.navigation.tabs`.
"""

from .navigation.tabs import TabItem, Tabs

__all__ = ["Tabs", "TabItem"]
