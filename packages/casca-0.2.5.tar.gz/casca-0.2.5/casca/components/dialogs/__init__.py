"""
Dialog and overlay components for Casca.

This module provides modal dialogs, alerts, confirmations, and prompts.

Inheritance Hierarchy:
    WidgetBase (from widgets.base)
        └── Overlay
            └── Modal
                └── Dialog
                    ├── Alert
                    ├── Confirm
                    └── Prompt
"""

from .overlay import Overlay
from .modal import Modal
from .dialog import Dialog
from .alert import Alert
from .confirm import Confirm
from .prompt import Prompt
from .manager import DialogManager, show_alert, show_confirm, show_prompt

__all__ = [
    "Overlay",
    "Modal",
    "Dialog",
    "Alert",
    "Confirm",
    "Prompt",
    "DialogManager",
    "show_alert",
    "show_confirm",
    "show_prompt",
]
