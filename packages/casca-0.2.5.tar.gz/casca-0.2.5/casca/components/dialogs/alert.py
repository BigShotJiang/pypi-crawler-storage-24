"""
Alert component - simple notification dialog.
"""

from typing import Optional, Callable
from .dialog import Dialog
from ..widgets.button import Button


class Alert(Dialog):
    """
    A simple alert dialog with a message and single OK button.
    
    Visual characteristics:
    - Yellow background for attention
    - Single dismiss button
    - Closes with Escape or OK button
    
    Usage:
        alert = Alert("Title", "Something happened!")
        dialog_manager.push(alert)
    """
    tag = 'alert'

    def __init__(
        self,
        title: str,
        message: str,
        id: str = "",
        classes: str = "",
        on_close: Optional[Callable] = None,
        ok_text: str = "OK",
        width: int = 45,
        **props
    ):
        def handle_ok(event):
            if on_close:
                on_close()

        ok_button = Button(ok_text, classes="alert-ok-btn", on_click=handle_ok)
        
        super().__init__(
            title,
            message,
            ok_button,
            id=id,
            classes=classes,
            on_close=on_close,
            width=width,
            height=10,
            **props
        )

    def resolve_styles(self, stylesheet: dict):
        """Apply alert-specific styling."""
        super().resolve_styles(stylesheet)
        
        # Alert uses yellow background for attention
        if 'background' not in self.style:
            self.style['background'] = 'YELLOW'
        if 'color' not in self.style:
            self.style['color'] = 'BLACK'
