"""
Prompt component - input dialog for collecting text.
"""

from typing import Optional, Callable
from .dialog import Dialog
from ..widgets.button import Button
from ..forms.input import Input


class Prompt(Dialog):
    """
    An input prompt dialog that collects text input from the user.
    
    Visual characteristics:
    - Cyan background for input collection
    - Text input field with placeholder
    - OK and Cancel buttons
    - Returns entered text via callback
    
    Usage:
        def on_submit(value: str):
            if value:
                print(f"User entered: {value}")
            else:
                print("User cancelled")
        
        prompt = Prompt("Name", "Enter your name:", on_submit=on_submit)
        dialog_manager.push(prompt)
    """
    tag = 'prompt'

    def __init__(
        self,
        title: str,
        message: str,
        id: str = "",
        classes: str = "",
        on_submit: Optional[Callable[[str], None]] = None,
        placeholder: str = "",
        ok_text: str = "OK",
        cancel_text: str = "Cancel",
        width: int = 50,
        **props
    ):
        from ..forms.input import Input
        
        self.on_submit = on_submit
        self.input_field = Input(
            placeholder=placeholder,
            id="prompt-input",
            width=width - 10
        )
        
        def handle_submit(event):
            if self.on_submit:
                self.on_submit(self.input_field.value)

        def handle_cancel(event):
            if self.on_submit:
                self.on_submit("")

        super().__init__(
            title,
            message,
            self.input_field,
            Button(ok_text, classes="prompt-ok-btn", on_click=handle_submit),
            Button(cancel_text, classes="prompt-cancel-btn", on_click=handle_cancel),
            id=id,
            classes=classes,
            on_close=lambda: self._handle_close(),
            width=width,
            height=13,
            **props
        )

    def resolve_styles(self, stylesheet: dict):
        """Apply prompt-specific styling."""
        super().resolve_styles(stylesheet)
        
        # Prompt uses cyan background for input
        if 'background' not in self.style:
            self.style['background'] = 'CYAN'
        if 'color' not in self.style:
            self.style['color'] = 'WHITE'

    def handle_input(self, event) -> bool:
        """Prioritize input field when focused."""
        # Give input field priority when focused
        if self.input_field.focused:
            if self.input_field.handle_input(event):
                return True
        
        return super().handle_input(event)

    def _handle_close(self):
        """Called when dialog is closed without submission."""
        if self.on_submit:
            self.on_submit("")

    def focus_input(self):
        """Programmatically focus the input field."""
        self.input_field.focused = True
