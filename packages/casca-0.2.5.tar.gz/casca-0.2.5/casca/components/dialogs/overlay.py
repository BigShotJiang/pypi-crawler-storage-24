"""
Overlay component - base class for all dialogs.
"""

from typing import Optional, Callable
from ..widgets.base import WidgetBase
from ..widgets.container import Container
from ...core.events import KeyEvent


class Overlay(Container):
    """
    A full-screen overlay container that blocks interaction with underlying content.
    
    Base class for all modal dialogs. Provides:
    - Semi-transparent background overlay
    - Escape key to close
    - Blocks input to widgets underneath
    
    Attributes:
        closable: Whether the overlay can be closed with Escape (default: True)
        overlay_char: Character used for overlay background (default: '░')
    """
    tag = 'overlay'

    def __init__(
        self,
        *children,
        id: str = "",
        classes: str = "",
        on_close: Optional[Callable] = None,
        closable: bool = True,
        **props
    ):
        super().__init__(*children, id=id, classes=classes, **props)
        self.on_close = on_close
        self.closable = closable
        
        # Default overlay styling
        if 'style' not in self.props:
            self.props['style'] = {}
        if 'overlay-char' not in self.props['style']:
            self.props['style']['overlay-char'] = '░'

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle keyboard input - Escape closes if closable."""
        # Capture Escape key to close
        if event.key == '\x1b' and self.closable:  # Escape key
            if self.on_close:
                self.on_close()
            return True
        
        # Pass to children
        return super().handle_input(event)

    def render(self, app):
        """Render overlay with semi-transparent background."""
        # Save current clip rect
        old_clip = getattr(app, 'clip_rect', None)
        
        # Set clip rect to overlay bounds
        app.clip_rect = (self.y, self.y + self.height, self.x, self.x + self.width)
        
        # Apply styles
        self.apply_style(app)
        
        # Draw semi-transparent background
        bg_char = self.style.get('overlay-char', '░')
        for r in range(self.height):
            app.draw_text(self.x + 1, self.y + r + 1, bg_char * self.width)
        
        # Render children
        for child in self.children:
            child.render(app)
            self.apply_style(app)
        
        app.write('\x1b[0m')
        
        # Restore clip rect
        app.clip_rect = old_clip
