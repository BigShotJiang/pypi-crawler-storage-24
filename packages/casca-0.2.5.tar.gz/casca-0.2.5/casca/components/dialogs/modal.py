"""
Modal component - centered dialog container.
"""

from typing import Optional, Callable
from .overlay import Overlay
from ..widgets.label import Label
from ..widgets.container import Container


class Modal(Overlay):
    """
    A centered modal dialog that traps focus.
    
    Provides a container for custom modal content with:
    - Automatic centering on screen
    - Title bar
    - Configurable dimensions
    - Default border styling
    
    Attributes:
        title: The modal title displayed in the header
        preferred_width: Default width (50)
        preferred_height: Default height (15)
    """
    tag = 'modal'

    def __init__(
        self,
        title: str,
        *children,
        id: str = "",
        classes: str = "",
        on_close: Optional[Callable] = None,
        width: int = 50,
        height: int = 15,
        **props
    ):
        self.modal_title = title
        self.preferred_width = width
        self.preferred_height = height
        
        # Create modal structure
        title_label = Label(f" {title} ", classes="modal-title")
        content_container = Container(*children, classes="modal-content")
        
        super().__init__(
            title_label,
            content_container,
            id=id,
            classes=classes,
            on_close=on_close,
            **props
        )

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Center the modal on screen."""
        self.width = self.preferred_width
        self.height = self.preferred_height
        
        # Center position
        self.x = (available_width - self.width) // 2
        self.y = (available_height - self.height) // 2
        
        # Layout children within modal bounds
        return super().calculate_layout(self.width, self.height)

    def resolve_styles(self, stylesheet: dict):
        """Apply default modal styling."""
        super().resolve_styles(stylesheet)
        
        # Default modal styling (can be overridden via CSS)
        if 'border' not in self.style:
            self.style['border'] = 'ascii'
        if 'background' not in self.style:
            self.style['background'] = 'BLUE'
        if 'overlay-char' not in self.style:
            self.style['overlay-char'] = '░'
