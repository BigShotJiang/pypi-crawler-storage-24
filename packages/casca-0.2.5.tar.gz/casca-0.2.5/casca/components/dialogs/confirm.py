"""
Confirm component - confirmation dialog with Yes/No buttons.
"""

from typing import Optional, Callable
from .dialog import Dialog
from ..widgets.button import Button


class Confirm(Dialog):
    """
    A confirmation dialog with OK/Cancel or Yes/No buttons.
    
    Visual characteristics:
    - Red background for warning/caution
    - Two buttons: confirm and cancel
    - Returns boolean result via callback
    
    Usage:
        def on_confirm(result: bool):
            if result:
                print("User confirmed")
            else:
                print("User cancelled")
        
        confirm = Confirm("Delete?", "Are you sure?", on_confirm=on_confirm)
        dialog_manager.push(confirm)
    """
    tag = 'confirm'

    def __init__(
        self,
        title: str,
        message: str,
        id: str = "",
        classes: str = "",
        on_confirm: Optional[Callable[[bool], None]] = None,
        ok_text: str = "Yes",
        cancel_text: str = "No",
        width: int = 45,
        **props
    ):
        self.on_confirm = on_confirm
        
        def handle_confirm(event):
            if self.on_confirm:
                self.on_confirm(True)

        def handle_cancel(event):
            if self.on_confirm:
                self.on_confirm(False)

        confirm_btn = Button(ok_text, classes="confirm-ok-btn", on_click=handle_confirm)
        cancel_btn = Button(cancel_text, classes="confirm-cancel-btn", on_click=handle_cancel)
        
        super().__init__(
            title,
            message,
            confirm_btn,
            cancel_btn,
            id=id,
            classes=classes,
            on_close=lambda: self._handle_close(),
            width=width,
            height=11,
            **props
        )

    def _handle_close(self):
        """Called when dialog is closed without explicit confirmation."""
        if self.on_confirm:
            self.on_confirm(False)

    def resolve_styles(self, stylesheet: dict):
        """Apply confirm-specific styling."""
        super().resolve_styles(stylesheet)
        
        # Confirm uses red background for warning
        if 'background' not in self.style:
            self.style['background'] = 'RED'
        if 'color' not in self.style:
            self.style['color'] = 'WHITE'
