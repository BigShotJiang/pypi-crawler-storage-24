from typing import Optional, List
from ..core.ansi import color_from_spec, move_cursor, BOLD, FAINT, ITALIC, UNDERLINE, BLINK, REVERSE, STRIKETHROUGH, RESET
from ..core.events import KeyEvent, MouseEvent
from ..style.css import get_border_width, get_box_spacing

class Widget:
    """The base class for all UI elements (DOM Node)."""
    
    tag = 'widget'

    def __init__(self, *children, id: str = "", classes: str = "", **props):
        self.children: List['Widget'] = list(children)
        self.id = id
        self.classes = classes.split() if classes else []
        self.props = props
        
        # Layout properties (calculated)
        self.x = 0
        self.y = 0
        self.width = 0
        self.height = 0
        self.content_width = 0
        self.content_height = 0
        
        # Resolved styles (from CSS)
        self.style = {}
        
        # State
        self.focused = False

    def resolve_styles(self, stylesheet: dict):
        from ..style.css import get_style_for_node
        self.style = get_style_for_node(self.id, self.classes, self.tag, stylesheet)
        
        # Merge inline styles (highest priority)
        if 'style' in self.props and isinstance(self.props['style'], dict):
            self.style.update(self.props['style'])
            
        # Recursively resolve styles for children
        for child in self.children:
            child.resolve_styles(stylesheet)
            
    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Base layout logic Flow (stacking). Returns tuple of (width_used, height_used)."""
        
        # Apply padding and border calculations
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, 'padding')
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, 'margin')
        border_width = get_border_width(self.style)
        
        # Width priority: Direct property -> Inline style -> Available parent width
        raw_width = self.style.get('width', available_width)
        if isinstance(raw_width, str) and raw_width.endswith('%'):
            raw_width = int(available_width * (float(raw_width.strip('%')) / 100))
        self.width = self.props.get('width', int(raw_width))
        
        # Content layout logic
        is_row = self.style.get('flex-direction') == 'row'
        
        current_x = pad_left + border_width
        current_y = pad_top + border_width
        max_child_width = 0
        max_child_height = 0
        
        for child in self.children:
            child_mar_top, _child_mar_right, _child_mar_bottom, child_mar_left = get_box_spacing(child.style, 'margin')
            child.x = self.x + current_x + child_mar_left
            child.y = self.y + current_y + child_mar_top
            
            # The children can occupy the inner space
            inner_avail_width = max(0, self.width - (pad_left + pad_right + 2 * border_width))
            
            if is_row:
                child_w, child_h = child.calculate_layout(
                    inner_avail_width - (current_x - pad_left - border_width),
                    max(0, available_height - (pad_top + pad_bottom + 2 * border_width)),
                )
                current_x += child_w
                max_child_height = max(max_child_height, child_h)
            else:
                child_w, child_h = child.calculate_layout(
                    inner_avail_width,
                    max(0, available_height - current_y - pad_bottom - border_width),
                )
                current_y += child_h
                max_child_width = max(max_child_width, child_w)
            
        self.content_width = current_x - (pad_left + border_width) if is_row else max_child_width
        self.content_height = max_child_height if is_row else current_y - (pad_top + border_width)
        
        # Total height used by this widget including padding, border and margin
        min_height = pad_top + pad_bottom + border_width * 2
        
        # If height is strictly set
        set_height = self.props.get('height') or self.style.get('height')
        if set_height:
            if isinstance(set_height, str) and set_height.endswith('%'):
                self.height = int(available_height * (float(set_height.strip('%')) / 100))
            else:
                self.height = int(set_height)
        else:
            self.height = self.content_height + min_height
            
        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def apply_style(self, app):
        """Applies the current widget's computed style and background to the terminal output."""
        app.write(RESET)
        fg_color = self.style.get('color', 'default')
        bg_color = self.style.get('background', 'default')
        app.write(color_from_spec(fg_color, bg_color))

        # Apply text styling
        if self.style.get('font-weight') == 'bold': app.write(BOLD)
        if self.style.get('font-style') == 'italic': app.write(ITALIC)
        decoration = self.style.get('text-decoration', '')
        if 'underline' in decoration:
            app.write(UNDERLINE)
        if 'line-through' in decoration:
            app.write(STRIKETHROUGH)
        if self.style.get('font-effect') == 'blink':
            app.write(BLINK)
        if self.style.get('font-effect') == 'reverse':
            app.write(REVERSE)
        if 'opacity' in self.style and float(self.style['opacity']) < 1.0: app.write(FAINT)

    def render(self, app):
        """Draws the widget to the app render buffer."""
        self.apply_style(app)

        # Draw background fill if applicable
        if 'background' in self.style:
            for r in range(self.height):
                app.draw_text(self.x + 1, self.y + r + 1, " " * self.width)
            self.apply_style(app)

        # Draw border
        if self.style.get('border', 'none') != 'none':
            self._draw_border(app)

        # Draw own content
        self.render_content(app)

        # Draw children
        for child in(self.children):
            child.render(app)
            # Reattach own style so subsequent children/parents don't get reset
            self.apply_style(app)

        app.write(RESET)
        
    def render_content(self, app):
        """Override to implement specific widget text / drawing logic."""
        pass
            
    def _draw_border(self, app):
        border_char = self.style.get('border-char', '+') if self.style.get('border') == 'ascii' else '█'
        # Top and bottom
        for r in (0, self.height - 1):
            if r >= 0 and self.width > 0:
                app.draw_text(self.x + 1, self.y + r + 1, border_char * self.width)
                
        # Sides
        for r in range(1, self.height - 1):
            if self.width > 0:
                app.draw_text(self.x + 1, self.y + r + 1, border_char)
                if self.width > 1:
                    app.draw_text(self.x + self.width, self.y + r + 1, border_char)
                    
    def handle_input(self, event: KeyEvent) -> bool:
        """
        Returns True if the event was consumed, preventing bubbling.
        Passes input down the tree.
        """
        for child in reversed(self.children):
            if child.handle_input(event):
                return True
        return False
        
    def handle_mouse(self, event: MouseEvent, app) -> bool:
        """Passes mouse events down if they fall within bounds."""
        # Terminal coordinates are 1-based (row, column starting at 1)
        # Our widget x,y are 0-based logical coordinates
        # Rendering happens at x+1, y+1 to convert to terminal coordinates
        # Event comes in with 1-based terminal coordinates
        
        # Convert event to 0-based to match our widget coordinate system
        term_x = event.x - 1
        term_y = event.y - 1

        # Check if click is within the widget's full bounds
        if self.x <= term_x < self.x + self.width and self.y <= term_y < self.y + self.height:
            # Propagate to children first (highest z-index effectively)
            for child in reversed(self.children):
                if child.handle_mouse(event, app):
                    return True

            if event.pressed and self.tag in ('input', 'textarea', 'button', 'checkbox', 'select', 'listview'):
                if app.focused_widget and app.focused_widget != self:
                    app.focused_widget.focused = False
                app.focused_widget = self
                self.focused = True
                if self.id:
                    app.focused_id = self.id

            # If kids didn't handle it, try handling it ourselves
            handled = self.on_mouse(event) or (event.pressed and self.tag in ('input', 'textarea', 'button', 'checkbox', 'select', 'listview'))

            # Special case for scroll wheel in bounds but not handled
            if not handled and event.button in (64, 65):
                return getattr(self, 'handle_wheel', lambda e, a: False)(event, app)

            return handled
        return False

    def on_mouse(self, event: MouseEvent) -> bool:
        """Override to implement specific widget mouse logic."""
        return False
