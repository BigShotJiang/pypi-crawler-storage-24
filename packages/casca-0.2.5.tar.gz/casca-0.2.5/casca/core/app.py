import sys
import select
import signal
import os
import traceback

from .terminal import RawTerminal, get_terminal_size
from .ansi import CLEAR_SCREEN, move_cursor, RESET
from .events import KeyEvent, ResizeEvent, MouseEvent
from .input_parser import parse_terminal_input_incremental
from .notifications import ToastManager
from ..style.css import parse_css, load_css_file, validate_stylesheet

class App:
    """
    The main application context and event loop.
    Provides a base class for rendering and handling events.
    """
    css = ""
    css_path = ""
    debug = False

    def __init__(self):
        self._running = False
        self._last_size = get_terminal_size()
        
        # Buffer to accumulate output before flushing (double buffer concept)
        self._output_buffer = []
        self._input_buffer = ""
        
        # DOM Root & Focus State
        self.root = None
        self.stylesheet = self._load_stylesheet()
        self.focused_widget = None
        self.focused_id = None
        self._last_error_lines: list[str] = []
        self.toast_manager = ToastManager()
        self.banner_message = ""
        self.banner_level = "info"

    def _load_stylesheet(self):
        """Build stylesheet from optional CSS file + inline css string."""
        css_parts = []
        if self.css_path:
            css_parts.append(load_css_file(self.css_path))
        if self.css:
            css_parts.append(self.css)
        stylesheet = parse_css("\n".join(css_parts))
        if self.debug:
            for warning in validate_stylesheet(stylesheet):
                sys.stderr.write(f"[Casca][style-warning] {warning}\n")
        return stylesheet

    def reload_stylesheet(self):
        """Reload CSS from file and inline styles at runtime."""
        self.stylesheet = self._load_stylesheet()

    def _focus_scope_root(self):
        """Return root node used for focus traversal."""
        if hasattr(self, "dialog_manager") and getattr(self.dialog_manager, "has_dialogs", False):
            current = getattr(self.dialog_manager, "current_dialog", None)
            if current is not None:
                return current
        return self.root

    def _collect_focusable_widgets(self, root_node):
        """Collect focusable widgets in traversal order."""
        focusable = []
        if not root_node:
            return focusable

        stack = [root_node]
        while stack:
            node = stack.pop()
            disabled = getattr(node, "disabled", False) or getattr(node, "_disabled", False)
            if not disabled and getattr(node, "tag", None) in ("input", "textarea", "button", "checkbox", "select", "listview", "radiogroup"):
                focusable.append(node)
            children = list(getattr(node, "children", []))
            stack.extend(reversed(children))
        return focusable

    def _set_focus(self, target):
        """Set focus to target widget, clearing previous focus."""
        if self.focused_widget and self.focused_widget is not target:
            self.focused_widget.focused = False
        self.focused_widget = target
        if target is not None:
            target.focused = True
            if getattr(target, "id", ""):
                self.focused_id = target.id

    def focus_next(self, reverse: bool = False) -> bool:
        """Move focus to next/previous focusable widget."""
        widgets = self._collect_focusable_widgets(self._focus_scope_root())
        if not widgets:
            self._set_focus(None)
            return False

        if self.focused_widget not in widgets:
            target = widgets[-1] if reverse else widgets[0]
            self._set_focus(target)
            return True

        current_index = widgets.index(self.focused_widget)
        step = -1 if reverse else 1
        next_index = (current_index + step) % len(widgets)
        self._set_focus(widgets[next_index])
        return True

    def run(self):
        """Starts the event loop."""
        self._running = True

        # Attach to SIGWINCH for resize events in Unix
        try:
            signal.signal(signal.SIGWINCH, self._handle_sigwinch)
        except AttributeError:
            # SIGWINCH is not available on all systems (e.g. Windows)
            pass

        with RawTerminal():
            self._safe_render_cycle()
            
            while self._running:
                # Wait for input (0.05s timeout for 20 FPS refresh rate max)
                dr, _, _ = select.select([sys.stdin], [], [], 0.05)
                
                if dr:
                    # Read all available bytes
                    try:
                        data = os.read(sys.stdin.fileno(), 1024).decode('utf-8', errors='replace')
                    except BlockingIOError:
                        continue
                    
                    if not data:
                        continue

                    mouse_events, key_events, exit_requested, self._input_buffer = parse_terminal_input_incremental(
                        data,
                        pending=self._input_buffer,
                    )
                    for mouse_evt in mouse_events:
                        try:
                            self.handle_mouse(mouse_evt)
                        except Exception as exc:
                            self.on_error(exc, "handle_mouse")

                    if exit_requested:
                        self.exit()

                    for key_evt in key_events:
                        try:
                            self.handle_input(key_evt)
                        except Exception as exc:
                            self.on_error(exc, "handle_input")
                        
                    # Request a re-render after an input if app is still running
                    if self._running:
                        self._safe_render_cycle()
                        
                # Optionally check if size changed periodically if SIGWINCH failed
                current_size = get_terminal_size()
                if current_size != self._last_size:
                    self._last_size = current_size
                    try:
                        self.handle_resize(ResizeEvent(*current_size))
                    except Exception as exc:
                        self.on_error(exc, "handle_resize")
                    self._safe_render_cycle()

    def exit(self):
        """Signals the app to break out of the event loop."""
        self._running = False

    def invalidate(self):
        """Mark UI tree dirty so it gets rebuilt on the next render cycle."""
        self.root = None

    def set_state(self, rerender: bool = True, **updates):
        """Update app attributes and optionally invalidate the UI.

        Example:
            self.set_state(counter=counter + 1, status_text="Updated")
        """
        for key, value in updates.items():
            setattr(self, key, value)
        if rerender:
            self.invalidate()

    def write(self, text: str):
        """Appends output to the render buffer."""
        self._output_buffer.append(text)

    def draw_text(self, x: int, y: int, text: str, apply_clip=True):
        """Helper to draw text with optional vertical clipping."""
        if apply_clip and hasattr(self, 'clip_rect') and self.clip_rect:
            min_y, max_y, min_x, max_x = self.clip_rect
            if y < min_y or y >= max_y:
                return
            # horizontal clipping
            if x < min_x:
                text = text[min_x - x:]
                x = min_x
            if x + len(text) > max_x:
                text = text[:max_x - x]
            if not text:
                return
        self.write(move_cursor(x, y))
        self.write(text)

    def flush(self):
        """Writes the entire render buffer to the stdout in one go to prevent flicker."""
        if self._output_buffer:
            sys.stdout.write("".join(self._output_buffer))
            sys.stdout.flush()
            self._output_buffer.clear()

    def _render_cycle(self):
        """Internal render pass to orchestrate drawing."""
        self.write(CLEAR_SCREEN)
        self.write(move_cursor(1, 1))
        
        # Call user's render method
        self.render()
        self._render_banner()
        self._render_toasts()
        self._render_error_overlay()
        
        self.write(RESET)
        self.flush()

    def _render_banner(self):
        """Render a sticky, non-blocking status banner near the bottom line."""
        if not self.banner_message:
            return
        w, h = self._last_size
        text = f"[{self.banner_level.upper()}] {self.banner_message}"[: max(1, w - 1)]
        self.draw_text(1, max(1, h), text, apply_clip=False)

    def _render_toasts(self):
        """Render transient toasts stacked from bottom-right."""
        active_toasts = self.toast_manager.active()
        if not active_toasts:
            return

        w, h = self._last_size
        max_stack = min(3, max(1, h - 2))
        visible = active_toasts[-max_stack:]
        for idx, toast in enumerate(reversed(visible), start=1):
            text = f"[{toast.level.upper()}] {toast.message}"
            clipped = text[: max(1, w - 2)]
            x = max(1, w - len(clipped))
            y = max(1, h - idx)
            self.draw_text(x, y, clipped, apply_clip=False)

    def show_toast(self, message: str, level: str = "info", duration: float = 2.0):
        """Show a transient toast message."""
        self.toast_manager.push(message, level=level, duration=duration)
        self.invalidate()

    def set_banner(self, message: str, level: str = "info"):
        """Set persistent status banner text."""
        self.banner_message = message
        self.banner_level = level
        self.invalidate()

    def clear_banner(self):
        """Clear status banner text."""
        self.banner_message = ""
        self.invalidate()

    def _safe_render_cycle(self):
        """Render cycle with an error boundary."""
        try:
            self._render_cycle()
        except Exception as exc:
            self.on_error(exc, "render")
            self.write(CLEAR_SCREEN)
            self.write(move_cursor(1, 1))
            self._render_error_overlay()
            self.write(RESET)
            self.flush()

    def _render_error_overlay(self):
        """Draw a compact debug overlay when an error is captured."""
        if not self.debug or not self._last_error_lines:
            return

        w, h = self._last_size
        max_lines = max(3, min(8, h - 2))
        lines = self._last_error_lines[:max_lines]

        box_width = max(20, min(w - 2, max(len(line) for line in lines) + 4))
        x = 2
        y = 2

        border = "+" + ("-" * (box_width - 2)) + "+"
        self.draw_text(x, y, border, apply_clip=False)
        for idx, line in enumerate(lines, start=1):
            clipped = line[: box_width - 4]
            padded = clipped + (" " * (box_width - 4 - len(clipped)))
            self.draw_text(x, y + idx, f"|{padded}|", apply_clip=False)
        self.draw_text(x, y + len(lines) + 1, border, apply_clip=False)

    def _handle_sigwinch(self, signum, frame):
        """Unix signal handler for terminal resize."""
        size = get_terminal_size()
        self._last_size = size
        self.handle_resize(ResizeEvent(width=size[0], height=size[1]))
        if self._running:
            self._safe_render_cycle()

    def on_error(self, exc: Exception, context: str):
        """Handle framework/runtime errors.

        Override this in app subclasses for custom behavior.
        """
        if self.debug:
            header = f"ERROR in {context}: {type(exc).__name__}: {exc}"
            stack = traceback.format_exception(type(exc), exc, exc.__traceback__)
            self._last_error_lines = [header] + [line.rstrip() for line in "".join(stack).splitlines()]
            return

        sys.stderr.write(f"[Casca] {context}: {type(exc).__name__}: {exc}\n")

    # --- Methods to be overridden by subclasses (User API) ---

    def handle_input(self, event: KeyEvent):
        """Triggered when a key is pressed."""
        # By default, press 'q' to quit. Subclasses can override.
        if event.key == 'q':
            self.exit()

        if event.key == '\t':
            self.focus_next(reverse=False)
            return
        if event.key == '\x1b[Z':
            self.focus_next(reverse=True)
            return
            
        # Dialog scope: when dialogs are active, route events there first.
        if hasattr(self, "dialog_manager") and getattr(self.dialog_manager, "has_dialogs", False):
            if self.dialog_manager.handle_input(event):
                return

        # Prioritize focused widget, else try routing through the DOM
        consumed = False
        if self.focused_widget:
            consumed = self.focused_widget.handle_input(event)
            
        if not consumed and self.root:
            self.root.handle_input(event)

    def handle_mouse(self, event: MouseEvent):
        """Triggered on mouse interaction."""
        if self.root:
            self.root.handle_mouse(event, self)

    def handle_resize(self, event: ResizeEvent):
        """Triggered when the terminal window changes size."""
        pass

    def build_ui(self):
        """Override this to return the root widget tree."""
        return None

    def render(self):
        """
        The main rendering function.
        Rebuilds styling and layout, then renders the full Widget tree.
        """
        if not self.root:
            self.root = self.build_ui()
            
            # Restore focus after a UI rebuild if an element ID was previously focused
            if self.focused_id:
                def restore_focus(node):
                    if node.id == self.focused_id:
                        node.focused = True
                        self.focused_widget = node
                    for c in node.children:
                        restore_focus(c)
                self.focused_widget = None
                restore_focus(self.root)
            
        if self.root:
            # 1. Resolve CSS
            self.root.resolve_styles(self.stylesheet)
            # 2. Assign root X/Y
            self.root.x = 0
            self.root.y = 0
            # 3. Calculate Layout
            w, h = self._last_size
            self.root.calculate_layout(w, h)
            # 4. Render Layout
            self.root.render(self)
        else:
            self.write(f"Casca UI - Press 'q' to exit.\\n Terminal size: {self._last_size}")

def run_app(widget, css="", css_path=""):
    """A convenience wrapper to run a single widget without subclassing App."""
    class WrapperApp(App):
        def __init__(self):
            self.css_path = css_path
            self.css = css
            super().__init__()
        def build_ui(self):
            return widget
    
    WrapperApp().run()
