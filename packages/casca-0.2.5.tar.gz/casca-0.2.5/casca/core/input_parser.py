"""Terminal input parsing helpers for Casca."""

from __future__ import annotations

import re

from .events import KeyEvent, MouseEvent, Keys

_MOUSE_PATTERN = re.compile(r"\x1b\[<(\d+);(\d+);(\d+)([mM])")

_KEY_NORMALIZATION = {
    "\n": Keys.ENTER,
    "\x1bOH": Keys.HOME,
    "\x1bOF": Keys.END,
    "\x1b[1~": Keys.HOME,
    "\x1b[4~": Keys.END,
    "\x1b[[A": Keys.F1,
    "\x1b[[B": Keys.F2,
    "\x1b[[C": Keys.F3,
    "\x1b[[D": Keys.F4,
}


def parse_terminal_input_incremental(
    data: str,
    pending: str = "",
) -> tuple[list[MouseEvent], list[KeyEvent], bool, str]:
    """Parse raw terminal bytes (decoded to text) into framework events.

    Returns a tuple of:
    - mouse events
    - key events
    - exit_requested flag (Ctrl+C/Ctrl+D)
    - trailing_incomplete sequence (to be prepended to next chunk)
    """
    data = pending + data
    mouse_events: list[MouseEvent] = []
    key_events: list[KeyEvent] = []

    for match in _MOUSE_PATTERN.finditer(data):
        btn, x, y, state = match.groups()
        mouse_events.append(
            MouseEvent(x=int(x), y=int(y), button=int(btn), pressed=(state == "M"))
        )

    data = _MOUSE_PATTERN.sub("", data)
    exit_requested = "\x03" in data or "\x04" in data

    trailing = ""
    i = 0
    while i < len(data):
        if data[i] == "\x1b":
            # Partial mouse sequence: preserve until next chunk.
            if data.startswith("\x1b[<", i):
                next_m = data.find("m", i)
                next_M = data.find("M", i)
                end_idx = min(
                    [pos for pos in (next_m, next_M) if pos != -1],
                    default=-1,
                )
                if end_idx == -1:
                    trailing = data[i:]
                    break

            # SS3 sequences are 3-byte keys like ESC O H / ESC O F.
            if i + 1 < len(data) and data[i + 1] == "O":
                if i + 2 >= len(data):
                    trailing = data[i:]
                    break
                key_events.append(KeyEvent(key=_normalize_key(data[i:i + 3]), is_printable=False))
                i += 3
                continue

            end = i + 1
            while end < len(data) and not data[end].isalpha() and data[end] != "~":
                end += 1
            if end >= len(data):
                trailing = data[i:]
                break

            end += 1
            key_events.append(KeyEvent(key=_normalize_key(data[i:end]), is_printable=False))
            i = end
            continue

        char = data[i]
        if char in ("\x08", "\x7f", "\r", "\n", "\t") or char.isprintable():
            is_printable = char.isprintable() and char not in ("\r", "\n", "\t")
            key_events.append(KeyEvent(key=_normalize_key(char), is_printable=is_printable))
        i += 1

    return mouse_events, key_events, exit_requested, trailing


def parse_terminal_input(data: str) -> tuple[list[MouseEvent], list[KeyEvent], bool]:
    """Backwards-compatible single-chunk parser entrypoint."""
    mouse, keys, should_exit, _trailing = parse_terminal_input_incremental(data)
    return mouse, keys, should_exit


def _normalize_key(key: str) -> str:
    """Normalize equivalent terminal key sequences to canonical values."""
    return _KEY_NORMALIZATION.get(key, key)
