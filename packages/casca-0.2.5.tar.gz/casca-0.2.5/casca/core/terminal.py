import os
import sys
import tty
import termios

from .ansi import ALT_SCREEN_ON, ALT_SCREEN_OFF, HIDE_CURSOR, SHOW_CURSOR, MOUSE_ON, MOUSE_OFF


class RawTerminal:
    """
    Context manager to safely put the terminal into raw mode,
    switch to the alternate screen buffer, and hide the cursor.
    """
    def __init__(self):
        self.fd = sys.stdin.fileno()
        self.old_settings = None

    def __enter__(self):
        # Save old terminal settings
        self.old_settings = termios.tcgetattr(self.fd)
        
        # Set raw mode to read characters immediately
        tty.setraw(self.fd)
        
        # Switch to alternate screen, hide cursor, enable mouse tracking
        sys.stdout.write(ALT_SCREEN_ON)
        sys.stdout.write(HIDE_CURSOR)
        sys.stdout.write(MOUSE_ON)
        sys.stdout.flush()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Restore normal screen, show cursor, disable mouse
        sys.stdout.write(MOUSE_OFF)
        sys.stdout.write(ALT_SCREEN_OFF)
        sys.stdout.write(SHOW_CURSOR)
        sys.stdout.flush()
        
        # Restore terminal settings
        termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old_settings)

def get_terminal_size() -> tuple[int, int]:
    """Returns (width, height) of the current terminal."""
    try:
        size = os.get_terminal_size()
        return size.columns, size.lines
    except OSError:
        return 80, 24
