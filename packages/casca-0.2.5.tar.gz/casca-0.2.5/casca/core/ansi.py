from enum import Enum
import re

class Color(Enum):
    BLACK = 30
    RED = 31
    GREEN = 32
    YELLOW = 33
    BLUE = 34
    MAGENTA = 35
    CYAN = 36
    WHITE = 37
    DEFAULT = 39

class BackColor(Enum):
    BLACK = 40
    RED = 41
    GREEN = 42
    YELLOW = 43
    BLUE = 44
    MAGENTA = 45
    CYAN = 46
    WHITE = 47
    DEFAULT = 49

ESC = '\x1b['
CLEAR_SCREEN = f"{ESC}2J"
ALT_SCREEN_ON = f"{ESC}?1049h"
ALT_SCREEN_OFF = f"{ESC}?1049l"
HIDE_CURSOR = f"{ESC}?25l"
SHOW_CURSOR = f"{ESC}?25h"
MOUSE_ON = f"{ESC}?1000h{ESC}?1006h"
MOUSE_OFF = f"{ESC}?1006l{ESC}?1000l"

# Text Styling
BOLD = f"{ESC}1m"
FAINT = f"{ESC}2m"
ITALIC = f"{ESC}3m"
UNDERLINE = f"{ESC}4m"
BLINK = f"{ESC}5m"
REVERSE = f"{ESC}7m"
STRIKETHROUGH = f"{ESC}9m"

def move_cursor(x: int, y: int) -> str:
    """Move cursor to 1-based x, y position."""
    return f"{ESC}{y};{x}H"

def color(fg: Color = Color.DEFAULT, bg: BackColor = BackColor.DEFAULT) -> str:
    """Set foreground and background color."""
    return f"{ESC}{fg.value};{bg.value}m"


_NAMED_ANSI_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "default": 39,
    "gray": 90,
    "grey": 90,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}


def _parse_rgb_triplet(spec: str):
    match = re.fullmatch(r"rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)", spec.lower())
    if not match:
        return None
    values = tuple(int(part) for part in match.groups())
    if any(value < 0 or value > 255 for value in values):
        return None
    return values


def _parse_hex_color(spec: str):
    match = re.fullmatch(r"#([0-9a-fA-F]{6})", spec)
    if not match:
        return None
    value = match.group(1)
    return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)


def _parse_ansi_index(spec: str):
    match = re.fullmatch(r"ansi\((\d{1,3})\)", spec.lower())
    if not match:
        return None
    value = int(match.group(1))
    if value < 0 or value > 255:
        return None
    return value


def _color_spec_to_sgr(spec, is_background: bool) -> str:
    if isinstance(spec, Enum):
        code = int(spec.value)
        if is_background and 30 <= code <= 37:
            code += 10
        elif not is_background and 40 <= code <= 47:
            code -= 10
        return str(code)

    if spec is None:
        return "49" if is_background else "39"

    text = str(spec).strip()
    if not text:
        return "49" if is_background else "39"

    lowered = text.lower()
    named_code = _NAMED_ANSI_COLORS.get(lowered)
    if named_code is not None:
        if is_background:
            if named_code == 39:
                return "49"
            if 30 <= named_code <= 37:
                named_code += 10
            elif 90 <= named_code <= 97:
                named_code += 10
        return str(named_code)

    rgb = _parse_hex_color(text) or _parse_rgb_triplet(text)
    if rgb is not None:
        prefix = "48;2" if is_background else "38;2"
        return f"{prefix};{rgb[0]};{rgb[1]};{rgb[2]}"

    ansi_index = _parse_ansi_index(text)
    if ansi_index is not None:
        prefix = "48;5" if is_background else "38;5"
        return f"{prefix};{ansi_index}"

    return "49" if is_background else "39"


def color_from_spec(fg=None, bg=None) -> str:
    """Set colors from flexible CSS-like values.

    Accepted formats:
    - named colors: red, bright_cyan, default
    - hex: #RRGGBB
    - rgb(): rgb(120, 10, 240)
    - 256-color index: ansi(196)
    """
    fg_sgr = _color_spec_to_sgr(fg, is_background=False)
    bg_sgr = _color_spec_to_sgr(bg, is_background=True)
    return f"{ESC}{fg_sgr};{bg_sgr}m"

RESET = f"{ESC}0m"
