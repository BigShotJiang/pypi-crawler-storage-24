"""Notification primitives for transient toasts and banners."""

from __future__ import annotations

from dataclasses import dataclass
from time import monotonic


@dataclass
class Toast:
    message: str
    level: str
    created_at: float
    duration: float


class ToastManager:
    """Manage transient toast notifications with auto-dismiss."""

    def __init__(self):
        self._toasts: list[Toast] = []

    def push(self, message: str, level: str = "info", duration: float = 2.0, now: float | None = None):
        timestamp = monotonic() if now is None else now
        self._toasts.append(
            Toast(message=message, level=level, created_at=timestamp, duration=max(0.1, duration))
        )

    def clear(self):
        self._toasts.clear()

    def active(self, now: float | None = None) -> list[Toast]:
        timestamp = monotonic() if now is None else now
        kept: list[Toast] = []
        for toast in self._toasts:
            if (timestamp - toast.created_at) < toast.duration:
                kept.append(toast)
        self._toasts = kept
        return list(self._toasts)
