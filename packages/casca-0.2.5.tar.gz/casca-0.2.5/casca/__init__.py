"""
Casca - A Python TUI Framework

A terminal user interface framework built with Python.
"""

from .core.app import App
from .core.events import KeyEvent, ResizeEvent, MouseEvent
from .core.terminal import RawTerminal, get_terminal_size
from .core.ansi import color, Color, BackColor, move_cursor, CLEAR_SCREEN, RESET
from .core.notifications import Toast, ToastManager
from .dom.node import Widget

# Import all components from organized submodules
from .components import (
    WidgetBase,
    Container,
    Label,
    Button,
    ListView,
    ProgressBar,
    Spinner,
    DataGrid,
    Checkbox,
    Input,
    Select,
    TextArea,
    RadioGroup,
    Card,
    Header,
    ScrollView,
    Tabs,
    TabItem,
    Overlay,
    Modal,
    Dialog,
    Alert,
    Confirm,
    Prompt,
    DialogManager,
    show_alert,
    show_confirm,
    show_prompt,
)
from .style.css import parse_css, load_css_file

__all__ = [
    # Core
    "App",
    "KeyEvent",
    "ResizeEvent",
    "MouseEvent",
    "RawTerminal",
    "get_terminal_size",
    "color",
    "Color",
    "BackColor",
    "move_cursor",
    "CLEAR_SCREEN",
    "RESET",
    "Toast",
    "ToastManager",
    # DOM
    "Widget",
    # Widgets
    "WidgetBase",
    "Container",
    "Label",
    "Button",
    "ListView",
    "ProgressBar",
    "Spinner",
    "DataGrid",
    # Forms
    "Checkbox",
    "Input",
    "Select",
    "TextArea",
    "RadioGroup",
    # Panels
    "Card",
    "Header",
    # Navigation
    "ScrollView",
    "Tabs",
    "TabItem",
    # Dialogs
    "Overlay",
    "Modal",
    "Dialog",
    "Alert",
    "Confirm",
    "Prompt",
    "DialogManager",
    "show_alert",
    "show_confirm",
    "show_prompt",
    # CSS
    "parse_css",
    "load_css_file",
]

from .core.app import run_app
__all__.append('run_app')
