import re
from pathlib import Path
from typing import Dict

_KNOWN_STYLE_KEYS = {
    "color",
    "background",
    "width",
    "height",
    "padding",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "margin",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "border",
    "border-char",
    "font-weight",
    "font-style",
    "text-decoration",
    "font-effect",
    "opacity",
    "flex-direction",
}

_NAMED_COLORS = {
    "default", "black", "red", "green", "yellow", "blue", "magenta", "cyan", "white",
    "bright_black", "bright_red", "bright_green", "bright_yellow", "bright_blue", "bright_magenta", "bright_cyan", "bright_white",
}

def parse_css(css_string: str) -> Dict[str, Dict[str, str]]:
    """
    Extremely lightweight CSS parser.
    Supports basic classes (.cls), IDs (#id), and Element (tag) selectors.
    Returns: { '.btn': {'color': 'red', 'padding': '1'}, ... }
    """
    stylesheet = {}

    # Remove comments
    css_string = re.sub(r'/\*.*?\*/', '', css_string, flags=re.DOTALL)

    # Find all blocks: selector { rules }
    blocks = re.findall(r'([^{]+)\{([^}]+)\}', css_string)

    for selector_group, rules_text in blocks:
        selectors = [s.strip() for s in selector_group.split(',')]

        rules = {}
        for rule in rules_text.split(';'):
            rule = rule.strip()
            if not rule:
                continue
            if ':' in rule:
                key, value = rule.split(':', 1)
                key = key.strip()
                value = value.strip()
                
                # Expand shorthand margin/padding
                if key in ('margin', 'padding') and ' ' in value:
                    parts = value.split()
                    if len(parts) == 4:
                        # top right bottom left
                        rules[f'{key}-top'] = parts[0]
                        rules[f'{key}-right'] = parts[1]
                        rules[f'{key}-bottom'] = parts[2]
                        rules[f'{key}-left'] = parts[3]
                        continue
                    elif len(parts) == 3:
                        # top right/left bottom
                        rules[f'{key}-top'] = parts[0]
                        rules[f'{key}-right'] = parts[1]
                        rules[f'{key}-left'] = parts[1]
                        rules[f'{key}-bottom'] = parts[2]
                        continue
                    elif len(parts) == 2:
                        # top/bottom right/left
                        rules[f'{key}-top'] = parts[0]
                        rules[f'{key}-bottom'] = parts[0]
                        rules[f'{key}-right'] = parts[1]
                        rules[f'{key}-left'] = parts[1]
                        continue
                
                rules[key] = value

        for selector in selectors:
            if selector not in stylesheet:
                stylesheet[selector] = {}
            stylesheet[selector].update(rules)

    return stylesheet


def load_css_file(path: str) -> str:
    """Load CSS text from disk.

    The path can be absolute or relative to the current working directory.
    """
    css_path = Path(path).expanduser().resolve()
    return css_path.read_text(encoding="utf-8")

def get_style_for_node(node_id: str, classes: list[str], tag: str, stylesheet: dict) -> dict:
    """Resolve styles for a given node in order of specificity: tag -> class -> id"""
    style = {}

    # 1. Tag
    if tag in stylesheet:
        style.update(stylesheet[tag])

    # 2. Classes
    for cls in classes:
        cls_sel = f".{cls}"
        if cls_sel in stylesheet:
            style.update(stylesheet[cls_sel])

    # 3. ID
    if node_id:
        id_sel = f"#{node_id}"
        if id_sel in stylesheet:
            style.update(stylesheet[id_sel])

    return style


def get_border_width(style: dict) -> int:
    """Return normalized border width from style values.

    Border width is 0 when border is missing or explicitly set to "none".
    """
    border_value = str(style.get("border", "none")).strip().lower()
    if border_value in ("", "none", "0", "false"):
        return 0
    return 1


def get_box_spacing(style: dict, key: str) -> tuple[int, int, int, int]:
    """Resolve spacing values for top/right/bottom/left.

    Supports base shorthand key (`padding`, `margin`) and expanded keys
    (`padding-top`, `margin-left`, ...).
    """
    base = int(style.get(key, 0))
    top = int(style.get(f"{key}-top", base))
    right = int(style.get(f"{key}-right", base))
    bottom = int(style.get(f"{key}-bottom", base))
    left = int(style.get(f"{key}-left", base))
    return top, right, bottom, left


def validate_stylesheet(stylesheet: Dict[str, Dict[str, str]]) -> list[str]:
    """Return dev-mode warnings for unsupported style keys and invalid values."""
    warnings: list[str] = []

    for selector, rules in stylesheet.items():
        for key, value in rules.items():
            if key not in _KNOWN_STYLE_KEYS:
                warnings.append(f"Unknown style key '{key}' in selector '{selector}'")
                continue

            if key in ("color", "background") and not _is_valid_color_value(value):
                warnings.append(
                    f"Possibly invalid color '{value}' for key '{key}' in selector '{selector}'"
                )

    return warnings


def _is_valid_color_value(value: str) -> bool:
    raw = str(value).strip().lower()
    if raw in _NAMED_COLORS:
        return True
    if re.match(r"^#([0-9a-f]{6})$", raw):
        return True
    if re.match(r"^rgb\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*\)$", raw):
        return True
    if re.match(r"^ansi\(\s*\d{1,3}\s*\)$", raw):
        return True
    return False
