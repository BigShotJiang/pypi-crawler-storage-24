"""Pydantic models for Power BI report structures."""

from pydantic import BaseModel, Field


class ColumnField(BaseModel):
    """A column field in a visual."""
    table: str
    column: str
    ref: str
    alias: str | None = None


class MeasureField(BaseModel):
    """A measure field in a visual."""
    table: str
    measure: str | None = None
    column: str | None = None
    aggregation: str | None = None
    ref: str
    alias: str | None = None


class FilterDefinition(BaseModel):
    """A filter definition."""
    table: str
    column: str
    ref: str
    values: list


class Visual(BaseModel):
    """A visual in a Power BI report page."""
    id: str
    type: str
    title: str | None = None
    columns: list[ColumnField] = Field(default_factory=list)
    measures: list[MeasureField] = Field(default_factory=list)
    column: str | None = None  # For slicers
    filter_column: FilterDefinition | None = None  # For slicers
    default_selection: list | None = None  # For slicers
    filters: list[FilterDefinition] = Field(default_factory=list)


class Page(BaseModel):
    """A page in a Power BI report."""
    id: str
    display_name: str = Field(alias="displayName")
    visuals: list[Visual] = Field(default_factory=list)
    filters: list[FilterDefinition] = Field(default_factory=list)

    model_config = {"populate_by_name": True}


class ReportOntology(BaseModel):
    """The ontology of a Power BI report."""
    dataset_id: str | None = None
    report_filters: list[FilterDefinition] = Field(default_factory=list)
    pages: list[Page] = Field(default_factory=list)
