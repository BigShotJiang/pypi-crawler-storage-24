"""Direct PBIR to DAX - Report parsing and DAX query generation library."""

from importlib.metadata import version

__version__ = version("powerbi-report-as-ontology")

from .core import ReportOntologyClient
from .models import (
    ColumnField,
    MeasureField,
    FilterDefinition,
    Visual,
    Page,
    ReportOntology,
)

__all__ = [
    "ReportOntologyClient",
    # Models
    "ColumnField",
    "MeasureField",
    "FilterDefinition",
    "Visual",
    "Page",
    "ReportOntology",
]
