"""Core functionality for Power BI report extraction and DAX generation."""

from .client import ReportOntologyClient

__all__ = [
    "ReportOntologyClient",
]
