"""File-based caching for parsed report ontologies."""

import json
from pathlib import Path
from ..models import ReportOntology


CACHE_DIR = Path.cwd() / ".powerbi-cache"


class ReportCache:
    """File-based cache for parsed report ontologies."""
    
    def __init__(self):
        CACHE_DIR.mkdir(exist_ok=True)
    
    @staticmethod
    def _get_cache_path(report_id: str) -> Path:
        """Get the cache file path for a report ontology."""
        return CACHE_DIR / f"{report_id}.ontology.json"
    
    @staticmethod
    def _get_raw_path(report_id: str) -> Path:
        """Get the path for raw definition JSON."""
        return CACHE_DIR / f"{report_id}.raw.json"
    
    def get_ontology(self, workspace_id: str, report_id: str) -> ReportOntology | None:
        """Get cached report ontology from file."""
        cache_path = self._get_cache_path(report_id)
        if cache_path.exists():
            with open(cache_path, "r", encoding="utf-8") as f:
                return ReportOntology.model_validate_json(f.read())
        return None
    
    def set_ontology(self, workspace_id: str, report_id: str, ontology: ReportOntology, raw_definition: dict | None = None) -> None:
        """Cache a report ontology to file. Optionally save raw definition as JSON for review."""
        cache_path = self._get_cache_path(report_id)
        with open(cache_path, "w", encoding="utf-8") as f:
            f.write(ontology.model_dump_json(indent=2, by_alias=True))
        
        if raw_definition:
            raw_path = self._get_raw_path(report_id)
            with open(raw_path, "w", encoding="utf-8") as f:
                json.dump(raw_definition, f, indent=2, ensure_ascii=False)
    
    def clear(self, workspace_id: str | None = None, report_id: str | None = None) -> bool:
        """Clear cache. If report_id specified, clear only that entry. Returns True if anything was cleared."""
        if report_id:
            cache_path = self._get_cache_path(report_id)
            raw_path = self._get_raw_path(report_id)
            cleared = False
            if cache_path.exists():
                cache_path.unlink()
                cleared = True
            if raw_path.exists():
                raw_path.unlink()
                cleared = True
            return cleared
        else:
            cleared = False
            for cache_file in CACHE_DIR.glob("*.json"):
                cache_file.unlink()
                cleared = True
            return cleared
    
    def get_json(self, workspace_id: str, report_id: str) -> str | None:
        """Get cached report ontology as raw JSON string."""
        cache_path = self._get_cache_path(report_id)
        if cache_path.exists():
            with open(cache_path, "r", encoding="utf-8") as f:
                return f.read()
        return None
    
    def get_raw_definition(self, workspace_id: str, report_id: str) -> dict | None:
        """Get cached raw definition JSON."""
        raw_path = self._get_raw_path(report_id)
        if raw_path.exists():
            with open(raw_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return None
    
    def exists(self, workspace_id: str, report_id: str) -> bool:
        """Check if a cached ontology exists for the report."""
        return self._get_cache_path(report_id).exists()
    
    def raw_exists(self, workspace_id: str, report_id: str) -> bool:
        """Check if a cached raw definition exists for the report."""
        return self._get_raw_path(report_id).exists()


# Global cache instance
_cache = ReportCache()


def get_cache() -> ReportCache:
    """Get the global cache instance."""
    return _cache
