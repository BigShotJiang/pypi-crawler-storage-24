"""DAX query generation from visual definitions."""

from ..models import Visual, Page, ReportOntology, FilterDefinition


def get_all_filters(ontology: ReportOntology, page: Page, visual: Visual) -> list[dict]:
    """
    Collect all applicable filters for a visual: report-level, page-level,
    slicer defaults, and visual-level filters.
    """
    filters = []
    
    # Report-level filters
    for f in ontology.report_filters:
        filters.append({
            "column": f.ref,
            "values": f.values,
            "source": "report"
        })
    
    # Page-level filters
    for f in page.filters:
        filters.append({
            "column": f.ref,
            "values": f.values,
            "source": "page"
        })
    
    # Slicer defaults on the page
    for v in page.visuals:
        if "slicer" in v.type.lower():
            defaults = v.default_selection
            if defaults:
                if v.filter_column:
                    col_ref = v.filter_column.ref
                else:
                    col_ref = v.column
                
                if col_ref:
                    filters.append({
                        "column": col_ref,
                        "values": defaults,
                        "source": "slicer"
                    })
    
    # Visual-level filters
    for f in visual.filters:
        filters.append({
            "column": f.ref,
            "values": f.values,
            "source": "visual"
        })
    
    return filters


def _format_filter_value(value) -> str:
    """Format a single filter value for DAX."""
    if isinstance(value, str):
        return f'"{value}"'
    return str(value)


def _generate_treatas_expr(filter_data: dict) -> str:
    """Generate a TREATAS expression from filter data."""
    column = filter_data["column"]
    values = filter_data["values"]
    
    formatted_values = [_format_filter_value(v) for v in values]
    value_list = ", ".join(formatted_values)
    
    return f'TREATAS({{{value_list}}}, {column})'


def generate_dax_query(visual: Visual, filters: list[dict] | None = None) -> str:
    """Generate a DAX query from visual's columns and measures, with optional filters."""
    columns = visual.columns
    measures = visual.measures
    
    if not columns and not measures:
        return ""
    
    # Build TREATAS filter expressions
    filter_exprs = []
    if filters:
        for f in filters:
            filter_exprs.append(_generate_treatas_expr(f))
    
    # Build measure expressions with aliases
    measure_exprs = []
    for m in measures:
        alias = m.alias or m.measure or m.column or "Value"
        measure_exprs.append(f'"{alias}", {m.ref}')
    
    if columns:
        # Build column references with ROLLUPADDISSUBTOTAL
        col_rollups = []
        for col in columns:
            col_rollups.append(f'{col.ref}, "{col.alias or col.column}_IsSubtotal"')
        col_list = ",\n        ".join(col_rollups)
        
        # Build SUMMARIZECOLUMNS parts
        summarize_parts = [f"ROLLUPADDISSUBTOTAL(\n            {col_list}\n        )"]
        if filter_exprs:
            summarize_parts.extend(filter_exprs)
        if measure_exprs:
            summarize_parts.extend(measure_exprs)
        
        summarize_str = ",\n        ".join(summarize_parts)
        
        # Build SELECTCOLUMNS aliases for columns
        select_exprs = []
        for col in columns:
            alias = col.alias or col.column
            ref = col.ref
            select_exprs.append(f'"{alias}", {ref}')
            select_exprs.append(f'"{alias}_IsSubtotal", [{alias}_IsSubtotal]')
        
        # Add measure aliases to SELECTCOLUMNS
        for m in measures:
            alias = m.alias or m.measure or m.column or "Value"
            select_exprs.append(f'"{alias}", [{alias}]')
        
        select_str = ",\n        ".join(select_exprs)
        
        return f"""EVALUATE
VAR _data =
    SUMMARIZECOLUMNS(
        {summarize_str}
    )
RETURN
    SELECTCOLUMNS(
        _data,
        {select_str}
    )"""
    
    elif measure_exprs:
        # Measures only
        measure_list = ",\n    ".join(measure_exprs)
        
        return f"""EVALUATE
ROW(
    {measure_list}
)"""
    
    return ""
