"""
Power BI Report (PBIR) Definition Extraction.

Internal module for extracting PBIR definitions from Power BI reports
and converting them to semantic report models.
"""

import base64
import json
import time
import requests

from ..models import ReportOntology, Page, Visual, ColumnField, MeasureField, FilterDefinition


# Visual types to exclude from the semantic report model
EXCLUDED_VISUAL_TYPES = {
    "shape",
    "textbox",
    "image",
    "basicshape",
    "line",
    "actionbutton",
}


def _fetch_dataset_id_from_api(workspace_id: str, report_id: str, headers: dict) -> str | None:
    """Fetch dataset ID from the Power BI Get Report in Group API."""
    url = f"https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/reports/{report_id}"
    response = requests.get(url, headers=headers)
    if response.ok:
        return response.json().get("datasetId")
    return None


def _download_report_definition(workspace_id: str, report_id: str, headers: dict) -> dict:
    """Download report definition from Power BI API."""
    response = requests.post(
        f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/reports/{report_id}/getDefinition",
        headers=headers
    )

    # Poll for completion
    while response.status_code == 202 or response.json().get("status") == "Running":
        location = response.headers.get("Location")
        if location:
            time.sleep(5)
            response = requests.get(location, headers=headers)

    # Get final definition
    definition_response = requests.get(response.headers["Location"], headers=headers)
    return definition_response.json()


def _decode_payload(payload: str) -> dict | str:
    """Decode base64 encoded payload to JSON or string."""
    decoded = base64.b64decode(payload).decode("utf-8")
    try:
        return json.loads(decoded)
    except json.JSONDecodeError:
        return decoded


def _is_excluded_visual(visual_type: str) -> bool:
    """Check if a visual type should be excluded from the semantic report model."""
    return visual_type.lower() in EXCLUDED_VISUAL_TYPES


def _parse_definition(definition: dict) -> tuple[ReportOntology, dict]:
    """Parse a PBIR definition into a ReportOntology. Returns (model, decoded_pbir_content)."""
    # Check if this is raw API response (has definition.parts) or already decoded content
    parts = definition.get("definition", {}).get("parts", [])
    
    if parts:
        # Raw API response - need to decode
        dataset_id = _extract_dataset_id(parts)
        
        has_page_files = any(
            "/pages/" in p.get("path", "") and p.get("path", "").endswith("/page.json")
            for p in parts
        )
        
        if has_page_files:
            model, pbir_content = _parse_modern_pbir(parts)
        else:
            model, pbir_content = _parse_legacy_pbir(parts)
        
        model.dataset_id = dataset_id
        return model, pbir_content
    
    # Already decoded content (from cache)
    return _parse_decoded_content(definition)


def _parse_decoded_content(content: dict) -> tuple[ReportOntology, dict]:
    """Parse already-decoded PBIR content (from cache)."""
    # Check for Legacy-PBIR format (has report.json key)
    if "report.json" in content:
        report_content = content["report.json"]
        
        # Extract report-level filters
        report_filters_json = report_content.get("filters", "[]")
        report_filters = _extract_filters_from_json(report_filters_json)
        
        # Extract sections (pages)
        sections = report_content.get("sections", [])
        pages = []
        
        for section in sections:
            visuals = []
            
            # Extract page-level filters
            page_filters_json = section.get("filters", "[]")
            page_filters = _extract_filters_from_json(page_filters_json)
            
            # Extract visual containers
            for vc in section.get("visualContainers", []):
                vc_config_str = vc.get("config", "{}")
                try:
                    vc_config = json.loads(vc_config_str)
                except json.JSONDecodeError:
                    vc_config = {}
                
                # Skip visual groups
                if "singleVisualGroup" in vc_config:
                    continue
                
                sv = vc_config.get("singleVisual", {})
                visual_type = sv.get("visualType", "unknown")
                
                if _is_excluded_visual(visual_type):
                    continue
                
                visual_name = vc_config.get("name", f"visual_{len(visuals)}")
                visual_model = _extract_visual_model(visual_name, sv)
                
                # Add visual-level filters
                visual_filters_json = vc.get("filters", "[]")
                visual_filters = _extract_filters_from_json(visual_filters_json)
                visual_model.filters = visual_filters
                
                visuals.append(visual_model)
            
            page = Page(
                id=section.get("name", "unknown"),
                displayName=section.get("displayName", section.get("name", "unknown")),
                visuals=visuals,
                filters=page_filters
            )
            pages.append(page)
        
        return ReportOntology(report_filters=report_filters, pages=pages), content
    
    # Modern PBIR format (has individual page/visual files)
    page_files = {}
    visual_files = {}
    
    for path, file_content in content.items():
        if not isinstance(file_content, dict):
            continue
        
        if "/pages/" in path and path.endswith("/page.json"):
            page_name = path.split("/pages/")[1].split("/")[0]
            page_files[page_name] = file_content
        
        if "/visuals/" in path and path.endswith("/visual.json"):
            parts_split = path.split("/")
            page_idx = parts_split.index("pages") + 1 if "pages" in parts_split else -1
            visual_idx = parts_split.index("visuals") + 1 if "visuals" in parts_split else -1
            
            if page_idx > 0 and visual_idx > 0:
                page_name = parts_split[page_idx]
                visual_name = parts_split[visual_idx]
                
                if page_name not in visual_files:
                    visual_files[page_name] = []
                visual_files[page_name].append({
                    "name": visual_name,
                    "content": file_content
                })
    
    pages = []
    for page_name, page_content in page_files.items():
        visuals = []
        
        if page_name in visual_files:
            for visual in visual_files[page_name]:
                visual_content = visual["content"]
                visual_obj = visual_content.get("visual", {})
                visual_type = visual_obj.get("visualType", "unknown")
                
                if _is_excluded_visual(visual_type):
                    continue
                
                visual_model = _extract_visual_model(visual["name"], visual_obj)
                visuals.append(visual_model)
        
        page = Page(
            id=page_name,
            displayName=page_content.get("displayName", page_name),
            visuals=visuals
        )
        pages.append(page)
    
    return ReportOntology(pages=pages), content


def _extract_dataset_id(parts: list) -> str | None:
    """Extract dataset ID from PBIR definition parts."""
    for part in parts:
        path = part.get("path", "")
        payload = part.get("payload", "")
        
        if not payload:
            continue
        
        # Modern PBIR: definition.pbir contains datasetReference
        if path == "definition.pbir":
            try:
                content = _decode_payload(payload)
                if isinstance(content, dict):
                    # Look for byConnection.datasetReference.byPath.datasetPath
                    dataset_ref = content.get("datasetReference", {})
                    by_connection = dataset_ref.get("byConnection", {})
                    if "datasetUri" in by_connection:
                        # Format: /datasets/{dataset_id}
                        uri = by_connection["datasetUri"]
                        if "/datasets/" in uri:
                            return uri.split("/datasets/")[-1]
                    
                    # Alternative: byPath format
                    by_path = dataset_ref.get("byPath", {})
                    if "datasetPath" in by_path:
                        return by_path["datasetPath"]
            except Exception:
                continue
        
        # Legacy PBIR: report.json may have datasetId or connections
        if path == "report.json":
            try:
                content = _decode_payload(payload)
                if isinstance(content, dict):
                    # Direct datasetId field
                    if "datasetId" in content:
                        return content["datasetId"]
                    
                    # Check config for dataset reference
                    config = content.get("config", "{}")
                    if isinstance(config, str):
                        config = json.loads(config)
                    if isinstance(config, dict) and "datasetId" in config:
                        return config["datasetId"]
            except Exception:
                continue
    
    return None


def _parse_modern_pbir(parts: list) -> tuple[ReportOntology, dict]:
    """Parse modern PBIR definition. Returns (model, decoded_content)."""
    page_files = {}
    visual_files = {}
    decoded_parts = {}
    
    for part in parts:
        path = part.get("path", "")
        payload = part.get("payload", "")
        
        if not payload:
            continue
            
        try:
            content = _decode_payload(payload)
        except Exception:
            continue
        
        # Store decoded content for JSON export
        if isinstance(content, dict):
            decoded_parts[path] = content
        
        if not isinstance(content, dict):
            continue
        
        # Collect page definitions
        if "/pages/" in path and path.endswith("/page.json"):
            page_name = path.split("/pages/")[1].split("/")[0]
            page_files[page_name] = content
        
        # Collect visual definitions
        if "/visuals/" in path and path.endswith("/visual.json"):
            parts_split = path.split("/")
            page_idx = parts_split.index("pages") + 1 if "pages" in parts_split else -1
            visual_idx = parts_split.index("visuals") + 1 if "visuals" in parts_split else -1
            
            if page_idx > 0 and visual_idx > 0:
                page_name = parts_split[page_idx]
                visual_name = parts_split[visual_idx]
                
                if page_name not in visual_files:
                    visual_files[page_name] = []
                visual_files[page_name].append({
                    "name": visual_name,
                    "content": content
                })
    
    pages = []
    for page_name, page_content in page_files.items():
        visuals = []
        
        if page_name in visual_files:
            for visual in visual_files[page_name]:
                visual_content = visual["content"]
                visual_obj = visual_content.get("visual", {})
                visual_type = visual_obj.get("visualType", "unknown")
                
                if _is_excluded_visual(visual_type):
                    continue
                
                visual_model = _extract_visual_model(visual["name"], visual_obj)
                visuals.append(visual_model)
        
        page = Page(
            id=page_name,
            displayName=page_content.get("displayName", page_name),
            visuals=visuals
        )
        pages.append(page)
    
    return ReportOntology(pages=pages), decoded_parts


def _parse_legacy_pbir(parts: list) -> tuple[ReportOntology, dict]:
    """Parse Legacy-PBIR definition. Returns (model, report_content)."""
    # Find report.json
    report_content = None
    for part in parts:
        path = part.get("path", "")
        payload = part.get("payload", "")
        
        if path == "report.json" and payload:
            try:
                report_content = _decode_payload(payload)
                break
            except Exception:
                continue
    
    if not report_content or not isinstance(report_content, dict):
        return ReportOntology(), {}
    
    # Extract report-level filters
    report_filters_json = report_content.get("filters", "[]")
    report_filters = _extract_filters_from_json(report_filters_json)
    
    # Extract sections (pages)
    sections = report_content.get("sections", [])
    pages = []
    
    for section in sections:
        visuals = []
        
        # Extract page-level filters
        page_filters_json = section.get("filters", "[]")
        page_filters = _extract_filters_from_json(page_filters_json)
        
        # Extract visual containers
        for vc in section.get("visualContainers", []):
            vc_config_str = vc.get("config", "{}")
            try:
                vc_config = json.loads(vc_config_str)
            except json.JSONDecodeError:
                vc_config = {}
            
            # Skip visual groups
            if "singleVisualGroup" in vc_config:
                continue
            
            sv = vc_config.get("singleVisual", {})
            visual_type = sv.get("visualType", "unknown")
            
            if _is_excluded_visual(visual_type):
                continue
            
            visual_name = vc_config.get("name", f"visual_{len(visuals)}")
            visual_model = _extract_visual_model(visual_name, sv)
            
            # Add visual-level filters
            visual_filters_json = vc.get("filters", "[]")
            visual_filters = _extract_filters_from_json(visual_filters_json)
            visual_model.filters = visual_filters
            
            visuals.append(visual_model)
        
        page = Page(
            id=section.get("name", "unknown"),
            displayName=section.get("displayName", section.get("name", "unknown")),
            visuals=visuals,
            filters=page_filters
        )
        pages.append(page)
    
    return ReportOntology(report_filters=report_filters, pages=pages), {"report.json": report_content}


def _extract_visual_model(visual_name: str, sv: dict) -> Visual:
    """Extract a Visual model from a singleVisual config."""
    visual_type = sv.get("visualType", "unknown")
    
    # Get title
    title = None
    title_config = sv.get("vcObjects", {}).get("title", [])
    if title_config:
        title_props = title_config[0].get("properties", {})
        title_text = title_props.get("text", {}).get("expr", {}).get("Literal", {}).get("Value", "")
        if title_text:
            title = title_text.strip("'\"")
    
    # Also check modern format
    if not title:
        title = sv.get("title", {}).get("text")
    
    # Extract columns and measures from projections using visual-type-aware role mapping
    projections = sv.get("projections", {})
    columns, measures = _extract_visual_fields_from_projections(projections, visual_type)
    
    visual = Visual(
        id=visual_name,
        type=visual_type,
        title=title,
        columns=columns,
        measures=measures
    )
    
    # Extract slicer-specific data
    if "slicer" in visual_type.lower():
        filter_col = _extract_slicer_filter_column(sv)
        if filter_col:
            visual.filter_column = filter_col
        
        slicer_column = _extract_slicer_column(sv)
        if slicer_column:
            visual.column = slicer_column
        
        slicer_defaults = _extract_slicer_defaults(sv)
        if slicer_defaults:
            visual.default_selection = slicer_defaults
    
    return visual


# Roles that are always measures (based on Power BI visual capabilities)
MEASURE_ROLES = {
    "Y", "Y2", "Values", "Value", "Data", "Size", "Tooltips", 
    "Color saturation", "Gradient", "Analyze"
}

# Roles that are always columns/groupings
COLUMN_ROLES = {
    "Category", "Series", "Rows", "Columns", "X", "Location", 
    "Group", "Legend", "Details", "ExplainBy"
}


def _extract_visual_fields_from_projections(projections: dict, visual_type: str = "") -> tuple[list[ColumnField], list[MeasureField]]:
    """Extract columns and measures from projections structure.
    
    Uses role names to determine field type based on Power BI visual capabilities:
    - MEASURE_ROLES: Y, Y2, Values, Value, Data, Size, etc. → Measures
    - COLUMN_ROLES: Category, Series, Rows, Columns, etc. → Columns
    - Unknown roles default to measures (safer for DAX query generation)
    """
    columns = []
    measures = []
    
    if not projections:
        return columns, measures
    
    for role, items in projections.items():
        if not isinstance(items, list):
            continue
            
        for item in items:
            query_ref = item.get("queryRef", "")
            if not query_ref or "." not in query_ref:
                continue
            
            # Parse Table.Column format
            table, field = query_ref.rsplit(".", 1)
            ref = f"'{table}'[{field}]"
            
            # Determine field type based on role
            if role in COLUMN_ROLES:
                columns.append(ColumnField(
                    table=table,
                    column=field,
                    ref=ref,
                    alias=query_ref
                ))
            else:
                # MEASURE_ROLES or unknown roles default to measure
                measures.append(MeasureField(
                    table=table,
                    measure=field,
                    ref=ref,
                    alias=query_ref
                ))
    
    return columns, measures
    
    return columns, measures


def _extract_slicer_column(sv: dict) -> str | None:
    """Extract the column specification from a slicer visual using projections."""
    projections = sv.get("projections", {})
    
    # Slicers typically use "Values" or "Field" role
    for role in ["Values", "Field", "Rows"]:
        items = projections.get(role, [])
        if items:
            query_ref = items[0].get("queryRef", "")
            if query_ref and "." in query_ref:
                table, field = query_ref.rsplit(".", 1)
                return f"'{table}'[{field}]"
    
    return None


def _extract_slicer_filter_column(sv: dict) -> FilterDefinition | None:
    """Extract the actual filter column from a slicer's general.filter definition."""
    objects = sv.get("objects", {})
    general_obj = objects.get("general", [])
    
    for general_item in general_obj:
        props = general_item.get("properties", {})
        filter_def = props.get("filter", {}).get("filter", {})
        if filter_def:
            from_aliases = {f["Name"]: f["Entity"] for f in filter_def.get("From", [])}
            where_clauses = filter_def.get("Where", [])
            
            for where in where_clauses:
                condition = where.get("Condition", {})
                if "In" in condition:
                    expressions = condition["In"].get("Expressions", [])
                    if expressions:
                        col_expr = expressions[0].get("Column", {})
                        source = col_expr.get("Expression", {}).get("SourceRef", {}).get("Source", "")
                        prop = col_expr.get("Property", "")
                        entity = from_aliases.get(source, source)
                        
                        if entity and prop:
                            return FilterDefinition(
                                table=entity,
                                column=prop,
                                ref=f"'{entity}'[{prop}]",
                                values=[]
                            )
    
    return None


def _extract_slicer_defaults(sv: dict) -> list | None:
    """Extract default selection values from a slicer visual configuration."""
    objects = sv.get("objects", {})
    defaults = []
    
    # Check data objects
    for data_item in objects.get("data", []):
        props = data_item.get("properties", {})
        default_value = props.get("defaultValue", {})
        
        if "value" in default_value:
            val_expr = default_value["value"].get("expr", {})
            literal = val_expr.get("Literal", {})
            if "Value" in literal:
                val = _clean_literal_value(literal["Value"])
                defaults.append(val)
        
        filter_expr = props.get("filter", {}).get("value", {}).get("expr", {})
        if filter_expr:
            defaults.extend(_extract_filter_values(filter_expr))
    
    # Check general objects
    for general_item in objects.get("general", []):
        props = general_item.get("properties", {})
        filter_def = props.get("filter", {}).get("filter", {})
        if filter_def:
            for where in filter_def.get("Where", []):
                condition = where.get("Condition", {})
                defaults.extend(_extract_filter_values(condition))
    
    # Check scopedFilterSelectorState
    selector_state = sv.get("scopedFilterSelectorState", {})
    if selector_state:
        selection_state = selector_state.get("selectionState", {})
        for f in selection_state.get("filters", []):
            filter_expr = f.get("expression", {})
            defaults.extend(_extract_filter_values(filter_expr))
    
    return defaults if defaults else None


def _clean_literal_value(val):
    """Clean a literal value from Power BI format."""
    if isinstance(val, str):
        if val.startswith("'") and val.endswith("'"):
            val = val[1:-1]
        elif val.endswith("L") and val[:-1].isdigit():
            val = int(val[:-1])
        elif val.endswith("D") and val[:-1].replace(".", "").isdigit():
            val = float(val[:-1])
    return val


def _extract_filter_values(filter_expr: dict) -> list:
    """Extract literal values from a filter expression."""
    values = []
    
    if "In" in filter_expr:
        in_expr = filter_expr["In"]
        for val_list in in_expr.get("Values", []):
            for val_item in val_list:
                literal = val_item.get("Literal", {})
                if "Value" in literal:
                    values.append(_clean_literal_value(literal["Value"]))
    
    if "Comparison" in filter_expr:
        comp = filter_expr["Comparison"]
        literal = comp.get("Right", {}).get("Literal", {})
        if "Value" in literal:
            values.append(_clean_literal_value(literal["Value"]))
    
    if "And" in filter_expr:
        and_expr = filter_expr["And"]
        values.extend(_extract_filter_values(and_expr.get("Left", {})))
        values.extend(_extract_filter_values(and_expr.get("Right", {})))
    
    if "Or" in filter_expr:
        or_expr = filter_expr["Or"]
        values.extend(_extract_filter_values(or_expr.get("Left", {})))
        values.extend(_extract_filter_values(or_expr.get("Right", {})))
    
    return values


def _extract_filter_definition(filter_obj: dict) -> FilterDefinition | None:
    """Extract filter definition from a Power BI filter object."""
    if not filter_obj:
        return None
    
    filter_def = filter_obj.get("filter", {})
    if not filter_def:
        return None
    
    where_clauses = filter_def.get("Where", [])
    if not where_clauses:
        return None
    
    from_aliases = {f["Name"]: f["Entity"] for f in filter_def.get("From", [])}
    
    for where in where_clauses:
        condition = where.get("Condition", {})
        
        if "In" in condition:
            in_expr = condition["In"]
            expressions = in_expr.get("Expressions", [])
            values_list = in_expr.get("Values", [])
            
            if expressions and values_list:
                col_expr = expressions[0].get("Column", {})
                source = col_expr.get("Expression", {}).get("SourceRef", {}).get("Source", "")
                prop = col_expr.get("Property", "")
                entity = from_aliases.get(source, source)
                
                values = []
                for val_list in values_list:
                    for val_item in val_list:
                        literal = val_item.get("Literal", {})
                        if "Value" in literal:
                            values.append(_clean_literal_value(literal["Value"]))
                
                if entity and prop and values:
                    return FilterDefinition(
                        table=entity,
                        column=prop,
                        ref=f"'{entity}'[{prop}]",
                        values=values
                    )
        
        if "Comparison" in condition:
            comp = condition["Comparison"]
            left = comp.get("Left", {}).get("Column", {})
            right = comp.get("Right", {}).get("Literal", {})
            
            source = left.get("Expression", {}).get("SourceRef", {}).get("Source", "")
            prop = left.get("Property", "")
            entity = from_aliases.get(source, source)
            
            if "Value" in right and entity and prop:
                return FilterDefinition(
                    table=entity,
                    column=prop,
                    ref=f"'{entity}'[{prop}]",
                    values=[_clean_literal_value(right["Value"])]
                )
    
    return None


def _extract_filters_from_json(filters_json: str) -> list[FilterDefinition]:
    """Extract filters from a JSON string of filter definitions."""
    if not filters_json:
        return []
    
    try:
        filters = json.loads(filters_json)
    except json.JSONDecodeError:
        return []
    
    result = []
    for f in filters:
        filter_data = _extract_filter_definition(f)
        if filter_data:
            result.append(filter_data)
    
    return result
