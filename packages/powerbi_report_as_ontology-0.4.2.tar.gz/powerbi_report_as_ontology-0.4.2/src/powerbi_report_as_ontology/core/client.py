"""Client for extracting Power BI report ontologies and querying visual data."""

from __future__ import annotations

import csv
import io
import logging
import time
from typing import Literal

import requests
from azure.identity import AzureCliCredential

logging.getLogger("azure.identity").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

from ..models import ReportOntology, Page, Visual
from .cache import ReportCache
from .extraction import _download_report_definition, _parse_definition, _fetch_dataset_id_from_api
from .dax import generate_dax_query, get_all_filters


# Visual types to skip in page queries (don't display tabular data)
SKIP_IN_PAGE_QUERY = {
    "slicer",
    "advancedSlicerVisual", 
    "chicletSlicer",
    "timeline"
}


def _rows_to_csv(rows: list[dict]) -> str:
    """Convert list of row dicts to CSV string."""
    if not rows:
        return ""
    
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


class ReportOntologyClient:
    """
    Client for extracting Power BI report ontologies and querying visual data.

    Args:
        workspace_id: Power BI workspace ID
        report_id: Power BI report ID
        credential: Azure credential (default: DefaultAzureCredential)
        cache: Report cache instance (default: new ReportCache)
        log_level: Logging level - "default" or "info". In "info" mode, logs
                   DAX query execution time and result size. (default: "default")
    """

    def __init__(
        self,
        workspace_id: str,
        report_id: str,
        credential=None,
        cache: ReportCache | None = None,
        log_level: Literal["default", "info", "debug"] = "default"
    ):
        self._workspace_id = workspace_id
        self._report_id = report_id
        self._credential = credential or AzureCliCredential()
        self._cache = cache if cache is not None else ReportCache()
        self._log_level = log_level
        self._cached_token = None
        self._configure_logger()

    @property
    def workspace_id(self) -> str:
        return self._workspace_id

    @property
    def report_id(self) -> str:
        return self._report_id

    @property
    def cache(self) -> ReportCache:
        return self._cache

    @property
    def log_level(self) -> Literal["default", "info", "debug"]:
        return self._log_level

    @log_level.setter
    def log_level(self, value: Literal["default", "info", "debug"]) -> None:
        if value not in ("default", "info", "debug"):
            raise ValueError(f"Invalid log_level: {value}. Must be 'default', 'info', or 'debug'.")
        self._log_level = value
        self._configure_logger()

    def _configure_logger(self) -> None:
        """Configure logger level based on client log_level setting."""
        if self._log_level == "info":
            logger.setLevel(logging.INFO)
        elif self._log_level == "debug":
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)

    def _get_headers(self) -> dict[str, str]:
        # Refresh token if not cached or expiring within 5 minutes
        if self._cached_token is None or self._cached_token.expires_on - time.time() < 300:
            start_time = time.perf_counter()
            self._cached_token = self._credential.get_token(
                "https://analysis.windows.net/powerbi/api/.default"
            )
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            logger.info(f"Token acquisition completed in {elapsed_ms:.2f}ms")
        return {"Authorization": f"Bearer {self._cached_token.token}"}

    @staticmethod
    def _should_skip_visual(visual: Visual) -> bool:
        """Check if a visual should be skipped in page queries."""
        visual_type = visual.type.lower()
        return any(skip_type.lower() in visual_type for skip_type in SKIP_IN_PAGE_QUERY)

    @staticmethod
    def _find_page(report: ReportOntology, page_name: str | None) -> Page:
        """Find a page by name or return the first page."""
        if not report.pages:
            raise ValueError("Report has no pages")
        
        if page_name:
            for page in report.pages:
                if page.display_name == page_name or page.id == page_name:
                    return page
            available = [p.display_name for p in report.pages]
            raise ValueError(f"Page '{page_name}' not found. Available: {available}")
        
        return report.pages[0]

    @classmethod
    def _find_visual(cls, page: Page, visual_name: str | None) -> Visual:
        """Find a visual by name/title or return the first queryable visual."""
        queryable = [v for v in page.visuals if not cls._should_skip_visual(v)]
        
        if not queryable:
            raise ValueError(f"Page '{page.display_name}' has no queryable visuals")
        
        if visual_name:
            for visual in queryable:
                if visual.title == visual_name or visual.id == visual_name:
                    return visual
            available = [v.title or v.id for v in queryable]
            raise ValueError(f"Visual '{visual_name}' not found. Available: {available}")
        
        return queryable[0]

    # ------------------------------------------------------------------
    # Report ontology
    # ------------------------------------------------------------------

    def extract_report_ontology(self, force_refresh: bool = False) -> ReportOntology:
        """Extract the report ontology, using cache if available."""
        if not force_refresh:
            # Check for cached ontology first
            cached = self._cache.get_ontology(self._workspace_id, self._report_id)
            if cached:
                return cached
            
            # Check for cached raw definition
            cached_raw = self._cache.get_raw_definition(self._workspace_id, self._report_id)
            if cached_raw:
                ontology, pbir_content = _parse_definition(cached_raw)
                if not ontology.dataset_id:
                    headers = self._get_headers()
                    ontology.dataset_id = _fetch_dataset_id_from_api(
                        self._workspace_id, self._report_id, headers
                    )
                self._cache.set_ontology(
                    self._workspace_id, self._report_id, ontology, raw_definition=pbir_content
                )
                return ontology

        # Download from Fabric API
        headers = self._get_headers()
        definition = _download_report_definition(self._workspace_id, self._report_id, headers)
        ontology, pbir_content = _parse_definition(definition)

        if not ontology.dataset_id:
            ontology.dataset_id = _fetch_dataset_id_from_api(
                self._workspace_id, self._report_id, headers
            )

        self._cache.set_ontology(
            self._workspace_id, self._report_id, ontology, raw_definition=pbir_content
        )
        return ontology

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def execute_dax_query(self, dataset_id: str, dax_query: str) -> dict:
        """Execute a DAX query against a dataset."""
        headers = self._get_headers()
        url = f"https://api.powerbi.com/v1.0/myorg/datasets/{dataset_id}/executeQueries"
        payload = {
            "queries": [{"query": dax_query}],
            "serializerSettings": {"includeNulls": True},
        }
        
        start_time = time.perf_counter()
        response = requests.post(url, headers=headers, json=payload)
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            # Try to extract error message from response body
            error_detail = ""
            try:
                error_json = response.json()
                if "error" in error_json:
                    error_detail = error_json["error"].get("message", "")
                    if not error_detail:
                        error_detail = str(error_json["error"])
            except Exception:
                error_detail = response.text[:500] if response.text else ""
            
            error_msg = str(e)
            if error_detail:
                error_msg = f"{e}\nError: {error_detail}"
            error_msg = f"{error_msg}\nDAX query:\n{dax_query}"
            raise requests.exceptions.HTTPError(error_msg) from e
        
        result = response.json()
        
        tables = result.get("results", [{}])[0].get("tables", [])
        rows = tables[0].get("rows", []) if tables else []
        rows_str = str(rows)
        logger.info(
            f"DAX query completed in {elapsed_ms:.2f}ms, "
            f"rows string size: {len(rows_str)} bytes"
        )
        logger.debug(
            f"DAX query text: {dax_query}"
        )
        
        return result

    def query_visual(
        self,
        page_name: str | None = None,
        visual_name: str | None = None,
        filters: list[dict] | None = None,
        output_format: Literal["csv", "json"] = "csv",
    ) -> dict:
        """
        Query data for a specific visual.
        
        Args:
            page_name: Page name or ID (default: first page)
            visual_name: Visual name/title or ID (default: first visual)
            filters: Optional list of filters to apply on top of report filters.
                     Each filter dict should have: table, column, values
            output_format: Output format for rows - "csv" (default) or "json"
        """
        report = self.extract_report_ontology()
        page = self._find_page(report, page_name)
        visual = self._find_visual(page, visual_name)

        all_filters = get_all_filters(report, page, visual)
        
        # Apply user-provided filters on top
        if filters:
            for f in filters:
                all_filters.append({
                    "column": f"'{f['table']}'[{f['column']}]",
                    "values": f.get("values", []),
                    "source": "user"
                })
        
        dax_query = generate_dax_query(visual, all_filters)

        if not dax_query:
            raise ValueError(f"Visual '{visual.title or visual.id}' has no columns or measures to query")
        if not report.dataset_id:
            raise ValueError("Dataset ID not found in report definition")

        result = self.execute_dax_query(report.dataset_id, dax_query)
        tables = result.get("results", [{}])[0].get("tables", [])
        rows = tables[0].get("rows", []) if tables else []
        
        # Format output
        if output_format == "csv":
            rows_output = _rows_to_csv(rows)
        else:
            rows_output = rows

        return {
            "visual": {"id": visual.id, "title": visual.title, "type": visual.type},
            "page": {"id": page.id, "display_name": page.display_name},
            "dax_query": dax_query,
            "rows": rows_output,
            "row_count": len(rows),
        }

    def query_page(
        self,
        page_name: str | None = None,
        filters: list[dict] | None = None,
        output_format: Literal["csv", "json"] = "csv",
    ) -> dict:
        """
        Query data for all visuals on a page.
        
        Args:
            page_name: Page name or ID (default: first page)
            filters: Optional list of filters to apply on top of report filters.
                     Each filter dict should have: table, column, values
            output_format: Output format for rows - "csv" (default) or "json"
        """
        report = self.extract_report_ontology()
        page = self._find_page(report, page_name)

        results = []
        errors = []

        for visual in page.visuals:
            if self._should_skip_visual(visual):
                continue
            
            try:
                result = self.query_visual(
                    page_name=page.display_name,
                    visual_name=visual.id,
                    filters=filters,
                    output_format=output_format
                )
                results.append({
                    "visual": result["visual"],
                    "rows": result["rows"],
                    "row_count": result["row_count"],
                })
            except ValueError:
                # Skip visuals with no columns/measures to query
                continue
            except Exception as e:
                errors.append({
                    "visual_id": visual.id,
                    "visual_title": visual.title,
                    "error": str(e),
                })

        return {
            "page": {"id": page.id, "display_name": page.display_name},
            "results": results,
            "errors": errors,
        }
