# powerbi-report-as-ontology

Python library for Power BI report semantic parsing and DAX query generation.

## Features

- **Report ontology extraction** - Parse Power BI report definitions from Fabric API and represent as an ontology
- **DAX query generation** - Generate DAX queries for visual data retrieval grounded in the ontology
