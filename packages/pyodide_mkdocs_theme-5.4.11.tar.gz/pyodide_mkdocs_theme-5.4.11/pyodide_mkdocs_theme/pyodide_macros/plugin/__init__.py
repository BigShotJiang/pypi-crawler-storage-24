"""
pyodide-mkdocs-theme
Copyleft GNU GPLv3 🄯 2024 Frédéric Zinelli

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.
If not, see <https://www.gnu.org/licenses/>.
"""

from ..plugin_config.dumpers import *
from .config import (
    PLUGIN_CONFIG_SRC,
    ConfOrOptSrc,
    ARGS_MACRO_CONFIG,
    MacroConfigSrc,
    PyodideMacrosConfig,
    DeprecationStatus,
    PluginConfigSrc,
    ConfigOptionSrc,
    SubConfigSrc,
)
from ..plugin_tools.test_cases import Case
from ..plugin_tools.macros_data import IdeToTest
from .maestro_base import BaseMaestro
from .maestro_meta import MaestroMeta
from .maestro_indent import MaestroIndent
from .maestro_macros import MaestroMacros, MacroPyConfig
from .pyodide_macros_plugin import PyodideMacrosPlugin



# MkDocs Material 9.7.2^+:

from colorama import Fore, Style
from os import getenv
from sys import stderr

if not getenv("NO_MKDOCS_2_WARNING"):
    print(
        f"{Fore.YELLOW} │ ⚠ WARNING – Pyodide-MkDocs-Theme is locking MkDocs to 1.x{Style.RESET_ALL}\n"
        f"{Fore.YELLOW} │ {Style.RESET_ALL}\n"
        f"{Fore.YELLOW} │ {Style.RESET_ALL}  MkDocs and MkDocs-Material are now unmaintained.\n"
        f"{Fore.YELLOW} │ {Style.RESET_ALL}   - As of now, MkDocs 2.0 does not plan on providing plugins support.\n"
        f"{Fore.YELLOW} │ {Style.RESET_ALL}   - Zensical is not planning on providing support for plugins extensions "
                                                "either (to the extent needed for PMT).\n"
        f"{Fore.YELLOW} │ {Style.RESET_ALL}\n"
        f"{Fore.YELLOW} │ {Style.RESET_ALL}  So, PMT locks the dependencies to keep it usable.\n"
        f"{Fore.YELLOW} │ {Style.RESET_ALL}\n"
        f"{Fore.YELLOW} │ {Style.RESET_ALL}  (To get rid of both messages, set {Fore.GREEN}NO_MKDOCS_2_WARNING=1"
                                            f"{Style.RESET_ALL} as environment variable)\n"
        , file=stderr,
    )