use comfy_table::Cell;

use crate::auth::context::CliContext;
use crate::commands::sbx::sandbox_endpoint;
use crate::error::{CliError, Result};
use crate::output::table::new_table;

pub async fn run(ctx: &CliContext) -> Result<()> {
    let client = ctx.client()?;
    let url = sandbox_endpoint(ctx, "sandboxes");

    let resp = client.get(&url).send().await.map_err(CliError::Http)?;

    if !resp.status().is_success() {
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        return Err(CliError::Other(anyhow::anyhow!(
            "failed to list sandboxes (HTTP {}): {}",
            status,
            body
        )));
    }

    let body: serde_json::Value = resp.json().await.map_err(CliError::Http)?;
    let sandboxes = body
        .get("sandboxes")
        .or_else(|| body.get("items"))
        .and_then(|v| v.as_array())
        .cloned()
        .unwrap_or_default();

    if sandboxes.is_empty() {
        println!("No sandboxes found.");
        return Ok(());
    }

    let mut table = new_table(&[
        "ID",
        "Status",
        "Image",
        "CPUs",
        "Memory",
        "Disk",
        "Created At",
    ]);

    for s in &sandboxes {
        let id = s
            .get("sandbox_id")
            .or_else(|| s.get("id"))
            .and_then(|v| v.as_str())
            .unwrap_or("-");
        let status = s.get("status").and_then(|v| v.as_str()).unwrap_or("-");
        let image = s.get("image").and_then(|v| v.as_str()).unwrap_or("-");

        let resources = s.get("resources");
        let cpus = resources
            .and_then(|r| r.get("cpus"))
            .and_then(|v| v.as_f64())
            .map(|v| format!("{}", v))
            .unwrap_or_else(|| "-".to_string());
        let memory = resources
            .and_then(|r| r.get("memory_mb"))
            .and_then(|v| v.as_i64())
            .map(|v| format!("{} MB", v))
            .unwrap_or_else(|| "-".to_string());
        let disk = resources
            .and_then(|r| r.get("ephemeral_disk_mb"))
            .and_then(|v| v.as_i64())
            .map(|v| format!("{} MB", v))
            .unwrap_or_else(|| "-".to_string());

        let created_at = s.get("created_at").and_then(|v| v.as_str()).unwrap_or("-");

        table.add_row(vec![
            Cell::new(id),
            Cell::new(status),
            Cell::new(image),
            Cell::new(&cpus),
            Cell::new(&memory),
            Cell::new(&disk),
            Cell::new(created_at),
        ]);
    }

    println!("{table}");
    let count = sandboxes.len();
    println!("{} sandbox{}", count, if count != 1 { "es" } else { "" });

    Ok(())
}
