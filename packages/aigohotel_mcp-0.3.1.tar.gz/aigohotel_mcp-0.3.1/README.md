# AigoHotel MCP Server (UV Version)

AIGOHOTEL 酒店 MCP Server（Python/uv 版本，stdio 运行）。

当前版本：`0.3.1`  
包名：`aigohotel-mcp`

## 工具列表

- `searchHotels`
- `getHotelDetail`
- `getHotelSearchTags`

## 启动方式（uvx）

```bash
uvx aigohotel-mcp
```

或本地开发运行：

```bash
uv run python server.py
```

## 鉴权（stdio）

stdio 模式下通过环境变量传入 API Key：

- `AIGOHOTEL_API_KEY`
- `AIGOHOTEL_SECRET_KEY`

至少配置一个，例如：

```bash
# PowerShell
$env:AIGOHOTEL_API_KEY="mcp_your_key"
uvx aigohotel-mcp
```

## MCP 客户端配置（stdio）

```json
{
  "mcpServers": {
    "aigohotel": {
      "command": "uvx",
      "args": ["aigohotel-mcp"],
      "env": {
        "AIGOHOTEL_API_KEY": "mcp_your_key"
      }
    }
  }
}
```

## 相关链接

- API Key 申请：https://mcp.agentichotel.cn/apply
- Model Context Protocol：https://modelcontextprotocol.io/
