def extract_api_key() -> str:
    import os

    api_key = (os.getenv("AIGOHOTEL_API_KEY") or os.getenv("AIGOHOTEL_SECRET_KEY") or "").strip()

    if not api_key:
        raise Exception("未配置 API Key，请设置环境变量 AIGOHOTEL_API_KEY 或 AIGOHOTEL_SECRET_KEY")

    return api_key
