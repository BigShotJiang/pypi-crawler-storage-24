from dotenv import load_dotenv
from fastmcp import FastMCP

from .tools import register_tools

load_dotenv()

mcp = FastMCP("AigoHotel Search", version="0.3.1")
register_tools(mcp)


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
