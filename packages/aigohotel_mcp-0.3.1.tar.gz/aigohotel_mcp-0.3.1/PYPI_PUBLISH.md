# PyPI 发布指南

## 一次性配置

### 1. 获取 PyPI Token

- 访问: https://pypi.org/manage/account/token/
- 点击 "Add API token" → 复制 Token

### 2. 配置凭证

创建文件 `C:\Users\你的用户名\.pypirc`:

```ini
[pypi]
username = __token__
password = pypi-你的Token
```

### 3. 安装工具

```powershell
pip install twine
```

## 发布新版本

### 1. 修改版本号

编辑 `pyproject.toml`:

```toml
version = "0.1.1"  # 每次发布必须递增
```

### 2. 执行发布

```powershell
cd e:\Cursor\测试脚本File\aigohotel-mcp-uv

# 清理 + 构建 + 检查 + 上传
Remove-Item -Recurse -Force dist -ErrorAction SilentlyContinue
uv build
twine check dist/*
twine upload dist/*
```

完成! 查看: https://pypi.org/project/aigohotel-mcp/

## 常见问题

**版本冲突**: PyPI 不允许覆盖,必须增加版本号
**认证失败**: 检查 `.pypirc` 文件中的 Token 是否正确
