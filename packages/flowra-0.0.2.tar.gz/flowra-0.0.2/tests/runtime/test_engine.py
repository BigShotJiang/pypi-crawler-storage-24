import dataclasses
from typing import Any

import pytest

from flowra.agent import (
    NEW_SCOPE,
    Agent,
    AgentDefinition,
    AgentInstance,
    AgentRegistry,
    AgentResult,
    Call,
    CallStepHandler,
    Goto,
    ServiceLocator,
    Spawn,
    StepResult,
    StepSpec,
    step,
)
from flowra.runtime.engine import Completed, Engine, Progressed
from flowra.runtime.execution import ExecutionStatus
from flowra.runtime.runtime_scope import RuntimeScope


def _scope_factory(parent_services: dict[type, Any]) -> RuntimeScope:
    return RuntimeScope(parent_services=parent_services)


def _instance_factory(defn: AgentDefinition, scope: RuntimeScope, services: dict[type, Any]) -> AgentInstance:
    from flowra.runtime._sealed_scope import create_instance_sealed

    return create_instance_sealed(defn, scope, services)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Val(AgentResult):
    v: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Spec(StepSpec):
    msg: str


def _defn(handler: CallStepHandler) -> AgentDefinition:
    def create(sl: ServiceLocator, slot_containers: dict[str, Any]) -> AgentInstance:
        return AgentInstance(call_step=handler)

    return AgentDefinition(steps={}, slots={}, type_registry={}, create_instance=create)


def _engine(agents: dict[str, Any]) -> Engine:
    return Engine(
        registry=AgentRegistry(agents),
        scope_factory=_scope_factory,
        instance_factory=_instance_factory,
    )


class TestAdvanceSingleStep:
    async def test_completed_in_one_tick(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        engine = _engine({"a": _defn(handler)})
        root = await engine.build_root("a", "start")
        result = await engine.advance(root)
        assert isinstance(result, Completed)
        assert isinstance(result.result, Val)
        assert result.result.v == "ok"


class TestAdvanceGotoStep:
    async def test_progressed_then_completed(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "a":
                return Goto(step="b")
            return Val(v="done")

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "a")

        r1 = await engine.advance(root)
        assert isinstance(r1, Progressed)
        assert root.status == ExecutionStatus.PENDING_STEP
        assert root.pending_step == "b"

        r2 = await engine.advance(root)
        assert isinstance(r2, Completed)


class TestAdvanceGotoAgent:
    async def test_replaces_node_in_place(self) -> None:
        async def ha(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Goto(step="run", agent="b")

        async def hb(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="from_b")

        engine = _engine({"a": _defn(ha), "b": _defn(hb)})
        root = await engine.build_root("a", "go")

        r1 = await engine.advance(root)
        assert isinstance(r1, Progressed)
        assert root.agent_name == "b"
        assert root.pending_step == "run"

        r2 = await engine.advance(root)
        assert isinstance(r2, Completed)
        assert isinstance(r2.result, Val)
        assert r2.result.v == "from_b"


class TestSpawnTreeShape:
    async def test_spawn_creates_children_nodes(self) -> None:
        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="work", agent="c", spec=Spec(msg="1")),
                        Call(step="work", agent="c", spec=Spec(msg="2")),
                    ],
                    then="join",
                )
            assert cr is not None
            return Val(v=",".join(r.v for r in cr))  # type: ignore[union-attr]

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            assert isinstance(spec, Spec)
            return Val(v=spec.msg)

        engine = _engine({"p": _defn(parent), "c": _defn(child)})
        root = await engine.build_root("p", "start")

        # Tick 1: parent spawns
        r1 = await engine.advance(root)
        assert isinstance(r1, Progressed)
        assert root.status == ExecutionStatus.WAITING_CHILDREN
        assert root.children is not None
        assert len(root.children) == 2
        assert all(c.status == ExecutionStatus.PENDING_STEP for c in root.children)
        assert root.then_step == "join"

        # Tick 2: children execute in parallel (propagation deferred to next tick)
        r2 = await engine.advance(root)
        assert isinstance(r2, Progressed)
        assert root.status == ExecutionStatus.WAITING_CHILDREN
        assert root.children is not None
        assert all(c.status == ExecutionStatus.COMPLETED for c in root.children)

        # Tick 3: propagation collapses children → parent becomes PENDING_STEP("join") → join executes → completed
        r3 = await engine.advance(root)
        assert isinstance(r3, Completed)
        assert isinstance(r3.result, Val)
        assert r3.result.v == "1,2"


class TestSpawnCallStepFork:
    async def test_fork_children_and_collect(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="task", spec=Spec(msg="a")),
                        Call(step="task", spec=Spec(msg="b")),
                    ],
                    then="join",
                )
            if step == "task":
                assert isinstance(spec, Spec)
                return Val(v=spec.msg)
            assert cr is not None
            return Val(v="+".join(r.v for r in cr))  # type: ignore[union-attr]

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "start")

        await engine.advance(root)  # spawn
        await engine.advance(root)  # children + propagate
        r = await engine.advance(root)  # join
        assert isinstance(r, Completed)
        assert isinstance(r.result, Val)
        assert r.result.v == "a+b"


class TestParallelExecution:
    async def test_multiple_children_run_in_same_tick(self) -> None:
        call_order: list[str] = []

        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="w", agent="c", spec=Spec(msg="1")),
                        Call(step="w", agent="c", spec=Spec(msg="2")),
                        Call(step="w", agent="c", spec=Spec(msg="3")),
                    ],
                    then="join",
                )
            return Val(v="done")

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            assert isinstance(spec, Spec)
            call_order.append(spec.msg)
            return Val(v=spec.msg)

        engine = _engine({"p": _defn(parent), "c": _defn(child)})
        root = await engine.build_root("p", "start")

        await engine.advance(root)  # spawn
        await engine.advance(root)  # all 3 children in one tick

        # All 3 children were called in the same tick
        assert len(call_order) == 3
        assert set(call_order) == {"1", "2", "3"}


class TestServicePropagation:
    async def test_parent_provides_service_child_sees_it(self) -> None:
        received_services: dict[type, Any] = {}

        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[Call(step="work", agent="c")],
                    then="join",
                )
            return Val(v="done")

        def create_parent(sl: ServiceLocator, slot_containers: dict[str, Any]) -> AgentInstance:
            sl.provide(str, "hello_service")

            async def h(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                return await parent(step, spec, cr)

            return AgentInstance(call_step=h)

        def create_child(sl: ServiceLocator, slot_containers: dict[str, Any]) -> AgentInstance:
            received_services.update(sl.services)

            async def h(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                return Val(v="child_done")

            return AgentInstance(call_step=h)

        parent_defn = AgentDefinition(steps={}, slots={}, type_registry={}, create_instance=create_parent)
        child_defn = AgentDefinition(steps={}, slots={}, type_registry={}, create_instance=create_child)
        engine = _engine({"p": parent_defn, "c": child_defn})
        root = await engine.build_root("p", "start")

        await engine.advance(root)  # spawn
        await engine.advance(root)  # children
        await engine.advance(root)  # join

        assert str in received_services
        assert received_services[str] == "hello_service"

    async def test_goto_agent_does_not_inherit_local_provides(self) -> None:
        sibling_services: dict[type, Any] = {}

        def create_a(sl: ServiceLocator, slot_containers: dict[str, Any]) -> AgentInstance:
            sl.provide(int, 42)

            async def h(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                return Goto(step="run", agent="b")

            return AgentInstance(call_step=h)

        def create_b(sl: ServiceLocator, slot_containers: dict[str, Any]) -> AgentInstance:
            sibling_services.update(sl.services)

            async def h(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                return Val(v="b")

            return AgentInstance(call_step=h)

        defn_a = AgentDefinition(steps={}, slots={}, type_registry={}, create_instance=create_a)
        defn_b = AgentDefinition(steps={}, slots={}, type_registry={}, create_instance=create_b)
        engine = _engine({"a": defn_a, "b": defn_b})
        root = await engine.build_root("a", "go")

        await engine.advance(root)  # goto agent b
        await engine.advance(root)  # b completes

        assert int not in sibling_services


class TestNodeIds:
    async def test_root_has_root_node_id(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        engine = _engine({"a": _defn(handler)})
        root = await engine.build_root("a", "start")
        assert root.node_id == "root"

    async def test_children_get_indexed_node_ids(self) -> None:
        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="w", agent="c"),
                        Call(step="w", agent="c"),
                        Call(step="w", agent="c"),
                    ],
                    then="join",
                )
            return Val(v="done")

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        engine = _engine({"p": _defn(parent), "c": _defn(child)})
        root = await engine.build_root("p", "start")
        await engine.advance(root)  # spawn

        assert root.children is not None
        assert root.children[0].node_id == "root.0"
        assert root.children[1].node_id == "root.1"
        assert root.children[2].node_id == "root.2"

    async def test_goto_agent_preserves_node_id(self) -> None:
        async def ha(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Goto(step="run", agent="b")

        async def hb(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="from_b")

        engine = _engine({"a": _defn(ha), "b": _defn(hb)})
        root = await engine.build_root("a", "go")

        await engine.advance(root)  # goto agent b
        assert root.node_id == "root"
        assert root.agent_name == "b"


class TestUnknownAgent:
    async def test_build_root_raises_key_error(self) -> None:
        engine = _engine({})
        with pytest.raises(KeyError):
            await engine.build_root("nonexistent", "start")


class TestStorageKeyPassthrough:
    async def test_storage_key_from_call_agent_passes_to_child(self) -> None:
        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[Call(step="w", agent="c", storage_key="child-key")],
                    then="join",
                )
            return Val(v="done")

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        engine = _engine({"p": _defn(parent), "c": _defn(child)})
        root = await engine.build_root("p", "start")
        await engine.advance(root)  # spawn

        assert root.children is not None
        assert root.children[0].storage_key == "child-key"

    async def test_storage_key_from_call_step_passes_to_child(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[Call(step="task", storage_key="task-key")],
                    then="join",
                )
            if step == "task":
                return Val(v="ok")
            return Val(v="done")

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "start")
        await engine.advance(root)  # spawn

        assert root.children is not None
        assert root.children[0].storage_key == "task-key"

    async def test_root_storage_key(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        engine = _engine({"a": _defn(handler)})
        root = await engine.build_root("a", "start", storage_key="root-key")
        assert root.storage_key == "root-key"


class TestStorageKeyUniqueness:
    async def test_duplicate_storage_key_raises(self) -> None:
        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="w", agent="c", storage_key="dup"),
                        Call(step="w", agent="c", storage_key="dup"),
                    ],
                    then="join",
                )
            return Val(v="done")

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        engine = _engine({"p": _defn(parent), "c": _defn(child)})
        root = await engine.build_root("p", "start")

        with pytest.raises(ValueError, match="Duplicate storage_key"):
            await engine.advance(root)

    async def test_storage_key_released_after_child_completion(self) -> None:
        """After children complete and are cleaned up, their storage_keys are released."""
        call_count = 0

        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            nonlocal call_count
            call_count += 1
            if step == "start":
                return Spawn(
                    children=[Call(step="w", agent="c", storage_key="reusable")],
                    then="mid",
                )
            if step == "mid":
                # Second spawn reusing the same storage_key
                return Spawn(
                    children=[Call(step="w", agent="c", storage_key="reusable")],
                    then="join",
                )
            return Val(v="done")

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        engine = _engine({"p": _defn(parent), "c": _defn(child)})
        root = await engine.build_root("p", "start")

        await engine.advance(root)  # spawn first batch
        await engine.advance(root)  # children complete, propagate → mid
        await engine.advance(root)  # mid spawns second batch with same key (should not raise)
        await engine.advance(root)  # children complete, propagate → join
        r = await engine.advance(root)  # join completes
        assert isinstance(r, Completed)


# -- Type-based agent resolution ----------------------------------------------


class _AgentB(Agent):
    @step
    async def run(self) -> Val:
        return Val(v="from_b")

    @step
    async def work(self) -> Val:
        return Val(v="child_ok")


class TestTypeResolution:
    async def test_goto_agent_with_type(self) -> None:
        async def ha(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            return Goto(step="run", agent=_AgentB)

        engine = _engine({"a": _defn(ha), "b": _AgentB})
        root = await engine.build_root("a", "go")
        await engine.advance(root)  # goto agent b
        assert root.agent_name == "b"
        r = await engine.advance(root)
        assert isinstance(r, Completed)
        assert isinstance(r.result, Val)
        assert r.result.v == "from_b"

    async def test_call_agent_with_type_in_spawn(self) -> None:
        async def parent(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[Call(step="work", agent=_AgentB)],
                    then="join",
                )
            return Val(v="done")

        engine = _engine({"p": _defn(parent), "c": _AgentB})
        root = await engine.build_root("p", "start")
        await engine.advance(root)  # spawn
        await engine.advance(root)  # child completes
        r = await engine.advance(root)  # join
        assert isinstance(r, Completed)

    async def test_unregistered_type_raises_key_error(self) -> None:
        async def handler(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            return Goto(step="run", agent=_AgentB)

        engine = _engine({"a": _defn(handler)})
        root = await engine.build_root("a", "go")
        with pytest.raises(KeyError):
            await engine.advance(root)


# -- Goto storage_key tests ---------------------------------------------------


class TestGotoStorageKey:
    async def test_goto_same_agent_no_storage_key_keeps_storage(self) -> None:
        """Goto within same agent without storage_key keeps current storage."""

        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "a":
                return Goto(step="b")
            return Val(v="done")

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "a", storage_key="my-key")

        await engine.advance(root)  # goto b
        assert root.storage_key == "my-key"

    async def test_goto_cross_agent_auto_generates_storage_key(self) -> None:
        """Goto to different agent without explicit storage_key auto-generates one."""

        async def ha(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            return Goto(step="run", agent="b")

        async def hb(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            return Val(v="from_b")

        engine = _engine({"a": _defn(ha), "b": _defn(hb)})
        root = await engine.build_root("a", "go", storage_key="original")

        await engine.advance(root)  # goto agent b
        assert root.storage_key is not None
        assert root.storage_key != "original"
        assert root.storage_key == "root:goto:1"

    async def test_goto_cross_agent_explicit_storage_key(self) -> None:
        """Goto to different agent with explicit storage_key uses that key."""

        async def ha(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            return Goto(step="run", agent="b", storage_key="explicit")

        async def hb(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            return Val(v="from_b")

        engine = _engine({"a": _defn(ha), "b": _defn(hb)})
        root = await engine.build_root("a", "go", storage_key="original")

        await engine.advance(root)  # goto agent b
        assert root.storage_key == "explicit"

    async def test_goto_same_agent_new_scope(self) -> None:
        """Goto same agent with NEW_SCOPE gets fresh storage."""

        async def handler(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            if step == "a":
                return Goto(step="b", storage_key=NEW_SCOPE)
            return Val(v="done")

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "a", storage_key="my-key")

        await engine.advance(root)  # goto b with NEW_SCOPE
        assert root.storage_key is not None
        assert root.storage_key != "my-key"
        assert root.storage_key == "root:goto:1"

    async def test_goto_counter_increments(self) -> None:
        """Multiple goto with auto-generated keys get different counters."""
        goto_count = 0

        async def ha(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            nonlocal goto_count
            goto_count += 1
            if goto_count <= 2:
                return Goto(step="go", agent="b")
            return Val(v="done")

        async def hb(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            return Goto(step="go", agent="a")

        engine = _engine({"a": _defn(ha), "b": _defn(hb)})
        root = await engine.build_root("a", "go")

        await engine.advance(root)  # a → b (goto:1)
        assert root.storage_key == "root:goto:1"

        await engine.advance(root)  # b → a (goto:2)
        assert root.storage_key == "root:goto:2"

        await engine.advance(root)  # a → b (goto:3)
        assert root.storage_key == "root:goto:3"

    async def test_goto_explicit_same_key_no_scope_change(self) -> None:
        """Goto same agent with storage_key matching current key → no scope change."""

        async def handler(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            if step == "a":
                return Goto(step="b", storage_key="my-key")
            return Val(v="done")

        engine = _engine({"x": _defn(handler)})
        root = await engine.build_root("x", "a", storage_key="my-key")
        original_scope = root.scope

        await engine.advance(root)  # goto b with same key
        assert root.storage_key == "my-key"
        assert root.scope is original_scope  # scope not recreated


# -- Scope semantics for Call (slots) -----------------------------------------


def _defn_with_counter(handler_factory: Any) -> AgentDefinition:
    """Build an AgentDefinition with a 'counter' Scalar slot."""
    from flowra.agent import SlotContainer, SlotDef, SlotKind

    def create(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
        counter = slot_containers["counter"]
        return handler_factory(counter)

    return AgentDefinition(
        steps={},
        slots={"counter": SlotDef(key="counter", kind=SlotKind.SCALAR, value_type=int)},
        type_registry={},
        create_instance=create,
    )


class TestCallStepScopeSemantics:
    async def test_same_agent_no_storage_key_forks_parent_scope(self) -> None:
        """Same-agent Call without storage_key gets a fork of parent's state."""
        child_values: list[int] = []

        def make_handler(counter: Any) -> AgentInstance:
            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                if step == "start":
                    counter.set(42)
                    return Spawn(
                        children=[Call(step="task")],
                        then="join",
                    )
                if step == "task":
                    child_values.append(counter.get(0))
                    return Val(v="ok")
                return Val(v="done")

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        engine = _engine({"x": defn})
        root = await engine.build_root("x", "start")

        await engine.advance(root)  # start sets counter=42, spawns
        await engine.advance(root)  # child runs
        await engine.advance(root)  # join

        assert child_values == [42]  # child inherited parent's state via fork

    async def test_same_agent_with_storage_key_gets_fresh_scope(self) -> None:
        """Same-agent Call with explicit storage_key gets a clean scope, not forked."""
        child_values: list[int] = []

        def make_handler(counter: Any) -> AgentInstance:
            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                if step == "start":
                    counter.set(42)
                    return Spawn(
                        children=[Call(step="task", storage_key="child-state")],
                        then="join",
                    )
                if step == "task":
                    child_values.append(counter.get(0))
                    return Val(v="ok")
                return Val(v="done")

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        engine = _engine({"x": defn})
        root = await engine.build_root("x", "start")

        await engine.advance(root)  # start sets counter=42, spawns
        await engine.advance(root)  # child runs
        await engine.advance(root)  # join

        assert child_values == [0]  # child got default, not parent's 42

    async def test_same_agent_with_new_scope_gets_fresh_scope(self) -> None:
        """Same-agent Call with NEW_SCOPE gets a fresh scope with auto-generated key."""
        child_values: list[int] = []

        def make_handler(counter: Any) -> AgentInstance:
            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                if step == "start":
                    counter.set(42)
                    return Spawn(
                        children=[Call(step="task", storage_key=NEW_SCOPE)],
                        then="join",
                    )
                if step == "task":
                    child_values.append(counter.get(0))
                    return Val(v="ok")
                return Val(v="done")

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        engine = _engine({"x": defn})
        root = await engine.build_root("x", "start")

        await engine.advance(root)  # start sets counter=42, spawns
        assert root.children is not None
        assert root.children[0].storage_key == "root.0:auto"
        await engine.advance(root)  # child runs
        await engine.advance(root)  # join

        assert child_values == [0]  # child got fresh scope, not parent's 42

    async def test_cross_agent_call_with_new_scope(self) -> None:
        """Cross-agent Call with NEW_SCOPE gets auto-generated storage key."""

        async def parent_handler(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            if step == "start":
                return Spawn(children=[Call(step="run", agent="child", storage_key=NEW_SCOPE)], then="join")
            return Val(v="done")

        async def child_handler(step: str, spec: StepSpec | None, cr: list[AgentResult] | None) -> StepResult:
            return Val(v="child_ok")

        engine = _engine({"parent": _defn(parent_handler), "child": _defn(child_handler)})
        root = await engine.build_root("parent", "start")

        await engine.advance(root)  # spawn
        assert root.children is not None
        assert root.children[0].storage_key == "root.0:auto"
        await engine.advance(root)  # child runs
        r = await engine.advance(root)  # join
        assert isinstance(r, Completed)
