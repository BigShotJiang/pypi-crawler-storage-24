import dataclasses
from typing import ClassVar

import pytest

from flowra.agent import (
    Agent,
    AgentDefinition,
    AgentDefinitionRef,
    AgentInstance,
    AgentResult,
    Call,
    CallStepHandler,
    Goto,
    ServiceLocator,
    Spawn,
    StepMeta,
    StepResult,
    StepSpec,
    step,
)
from flowra.runtime import AgentRuntime


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SimpleResult(AgentResult):
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SimpleSpec(StepSpec):
    message: str


def make_defn(steps: dict[str, StepMeta], handler: CallStepHandler) -> AgentDefinition:
    """Build an AgentDefinition with a given call_step handler factory."""

    def create(sl: ServiceLocator, slot_containers: dict) -> AgentInstance:  # type: ignore[type-arg]
        return AgentInstance(call_step=handler)

    return AgentDefinition(steps=steps, slots={}, type_registry={}, create_instance=create)


class TestSingleStep:
    async def test_returns_agent_result_immediately(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            return SimpleResult(value="done")

        defn = make_defn({"start": StepMeta()}, handler)
        runtime = AgentRuntime(agents={"a": defn})
        result = await runtime.run(agent="a", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "done"

    async def test_returns_none(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            return None

        defn = make_defn({"start": StepMeta()}, handler)
        runtime = AgentRuntime(agents={"a": defn})
        result = await runtime.run(agent="a", step="start")
        assert result is None


class TestGotoStep:
    async def test_chain_step_a_to_step_b(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            if step == "a":
                return Goto(step="b")
            return SimpleResult(value="from_b")

        defn = make_defn({"a": StepMeta(), "b": StepMeta()}, handler)
        runtime = AgentRuntime(agents={"agent": defn})
        result = await runtime.run(agent="agent", step="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "from_b"

    async def test_goto_step_passes_spec(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            if step == "a":
                return Goto(step="b", spec=SimpleSpec(message="hello"))
            assert isinstance(spec, SimpleSpec)
            return SimpleResult(value=spec.message)

        defn = make_defn({"a": StepMeta(), "b": StepMeta()}, handler)
        runtime = AgentRuntime(agents={"agent": defn})
        result = await runtime.run(agent="agent", step="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "hello"


class TestGotoAgent:
    async def test_transfers_to_another_agent(self) -> None:
        async def handler_a(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            return Goto(step="start", agent="b")

        async def handler_b(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            return SimpleResult(value="from_agent_b")

        defn_a = make_defn({"start": StepMeta()}, handler_a)
        defn_b = make_defn({"start": StepMeta()}, handler_b)
        runtime = AgentRuntime(agents={"a": defn_a, "b": defn_b})
        result = await runtime.run(agent="a", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "from_agent_b"


class TestSpawnCallAgent:
    async def test_spawn_children_and_collect_results(self) -> None:
        async def parent_handler(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="work", agent="child", spec=SimpleSpec(message="x")),
                        Call(step="work", agent="child", spec=SimpleSpec(message="y")),
                    ],
                    then="collect",
                )
            # then step
            assert child_results is not None
            results = [r for r in child_results if isinstance(r, SimpleResult)]
            return SimpleResult(value=",".join(r.value for r in results))

        async def child_handler(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            assert isinstance(spec, SimpleSpec)
            return SimpleResult(value=spec.message)

        parent_defn = make_defn({"start": StepMeta(), "collect": StepMeta()}, parent_handler)
        child_defn = make_defn({"work": StepMeta()}, child_handler)
        runtime = AgentRuntime(agents={"parent": parent_defn, "child": child_defn})
        result = await runtime.run(agent="parent", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "x,y"


class TestSpawnCallStep:
    async def test_spawn_fork_children_and_collect(self) -> None:
        call_log: list[str] = []

        async def handler(
            step: str,
            spec: StepSpec | None,
            child_results: list[AgentResult] | None,
        ) -> StepResult:
            call_log.append(step)
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="task", spec=SimpleSpec(message="1")),
                        Call(step="task", spec=SimpleSpec(message="2")),
                    ],
                    then="join",
                )
            if step == "task":
                assert isinstance(spec, SimpleSpec)
                return SimpleResult(value=f"task_{spec.message}")
            # join step
            assert child_results is not None
            results = [r for r in child_results if isinstance(r, SimpleResult)]
            return SimpleResult(value="+".join(r.value for r in results))

        defn = make_defn(
            {"start": StepMeta(), "task": StepMeta(), "join": StepMeta()},
            handler,
        )
        runtime = AgentRuntime(agents={"agent": defn})
        result = await runtime.run(agent="agent", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "task_1+task_2"


class TestUnknownAgent:
    async def test_raises_key_error(self) -> None:
        runtime = AgentRuntime(agents={})
        with pytest.raises(KeyError):
            await runtime.run(agent="nonexistent", step="start")


# -- Type-based agent registration -------------------------------------------


class TestAutoCompileType:
    async def test_agent_subclass_auto_compiles(self) -> None:

        class MyAgent(Agent):
            @step
            async def start(self) -> SimpleResult:
                return SimpleResult(value="from_agent_class")

        runtime = AgentRuntime(agents={"a": MyAgent})
        result = await runtime.run(agent="a", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "from_agent_class"

    async def test_mixed_dict(self) -> None:

        class MyAgent(Agent):
            @step
            async def start(self) -> SimpleResult:
                return SimpleResult(value="class_based")

        async def handler(
            _step: str,
            _spec: StepSpec | None,
            _cr: list[AgentResult] | None,
        ) -> StepResult:
            return SimpleResult(value="defn_based")

        defn = make_defn({"start": StepMeta()}, handler)
        runtime = AgentRuntime(agents={"a": MyAgent, "b": defn})

        r1 = await runtime.run(agent="a", step="start")
        assert isinstance(r1, SimpleResult)
        assert r1.value == "class_based"

        r2 = await runtime.run(agent="b", step="start")
        assert isinstance(r2, SimpleResult)
        assert r2.value == "defn_based"

    def test_duplicate_agent_class_raises(self) -> None:

        class MyAgent(Agent):
            @step
            async def start(self) -> SimpleResult:
                return SimpleResult(value="x")

        with pytest.raises(ValueError, match=r"Duplicate agent class.*MyAgent"):
            AgentRuntime(agents={"a": MyAgent, "b": MyAgent})


class TestRunWithStepRef:
    async def test_run_with_step_ref(self) -> None:

        class Greeter(Agent):
            @step
            async def greet(self) -> SimpleResult:
                return SimpleResult(value="hello")

        runtime = AgentRuntime(agents={"g": Greeter})
        result = await runtime.run(agent=Greeter, step=Greeter.greet)
        assert isinstance(result, SimpleResult)
        assert result.value == "hello"

    async def test_run_with_step_ref_and_spec(self) -> None:

        class Greeter(Agent):
            @step
            async def greet(self, spec: SimpleSpec) -> SimpleResult:
                return SimpleResult(value=spec.message)

        runtime = AgentRuntime(agents={"g": Greeter})
        result = await runtime.run(agent=Greeter, step=Greeter.greet, spec=SimpleSpec(message="world"))
        assert isinstance(result, SimpleResult)
        assert result.value == "world"

    async def test_run_with_step_string(self) -> None:

        class Greeter(Agent):
            @step
            async def greet(self) -> SimpleResult:
                return SimpleResult(value="string")

        runtime = AgentRuntime(agents={"g": Greeter})
        result = await runtime.run(agent="g", step="greet")
        assert isinstance(result, SimpleResult)
        assert result.value == "string"

    async def test_run_with_unregistered_class_raises(self) -> None:

        class Registered(Agent):
            @step
            async def start(self) -> SimpleResult:
                return SimpleResult(value="ok")

        class NotRegistered(Agent):
            @step
            async def start(self) -> SimpleResult:
                return SimpleResult(value="nope")

        runtime = AgentRuntime(agents={"r": Registered})
        with pytest.raises(KeyError, match="NotRegistered"):
            await runtime.run(agent=NotRegistered, step="start")


class TestSubagentRegistration:
    async def test_subagents_automatically_registered(self) -> None:
        """Subagents declared in __subagents__ are registered with namespaced names."""

        class HelperAgent(Agent):
            @step
            async def execute(self) -> SimpleResult:
                return SimpleResult(value="helper_result")

        class MainAgent(Agent):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "helper": HelperAgent,
            }

            @step
            async def start(self) -> Spawn:
                return Spawn(
                    children=[Call(agent="main/helper", step="execute")],
                    then=self.collect,
                )

            @step
            async def collect(self, result: SimpleResult) -> SimpleResult:
                return SimpleResult(value=f"collected:{result.value}")

        runtime = AgentRuntime(agents={"main": MainAgent})
        result = await runtime.run(agent="main", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "collected:helper_result"

    async def test_nested_subagents(self) -> None:
        """Nested subagents are registered with slash-separated names."""

        class GrandchildAgent(Agent):
            @step
            async def work(self) -> SimpleResult:
                return SimpleResult(value="grandchild")

        class ChildAgent(Agent):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "grandchild": GrandchildAgent,
            }

            @step
            async def process(self) -> Spawn:
                return Spawn(
                    children=[Call(agent="parent/child/grandchild", step="work")],
                    then=self.done,
                )

            @step
            async def done(self, result: SimpleResult) -> SimpleResult:
                return SimpleResult(value=f"child:{result.value}")

        class ParentAgent(Agent):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "child": ChildAgent,
            }

            @step
            async def start(self) -> Spawn:
                return Spawn(
                    children=[Call(agent="parent/child", step="process")],
                    then=self.finish,
                )

            @step
            async def finish(self, result: SimpleResult) -> SimpleResult:
                return SimpleResult(value=f"parent:{result.value}")

        runtime = AgentRuntime(agents={"parent": ParentAgent})
        result = await runtime.run(agent="parent", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "parent:child:grandchild"

    async def test_subagent_type_reference(self) -> None:
        """Subagents can be referenced by type via Call(agent=SubAgent)."""

        class HelperAgent(Agent):
            @step
            async def execute(self) -> SimpleResult:
                return SimpleResult(value="typed_helper")

        class MainAgent(Agent):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "helper": HelperAgent,
            }

            @step
            async def start(self) -> Spawn:
                return Spawn(
                    children=[Call(agent=HelperAgent, step="execute")],
                    then=self.collect,
                )

            @step
            async def collect(self, result: SimpleResult) -> SimpleResult:
                return SimpleResult(value=f"got:{result.value}")

        runtime = AgentRuntime(agents={"main": MainAgent})
        result = await runtime.run(agent="main", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "got:typed_helper"

    async def test_subagent_relative_name(self) -> None:
        """Subagents can be referenced by relative name (e.g., './helper')."""

        class HelperAgent(Agent):
            @step
            async def execute(self) -> SimpleResult:
                return SimpleResult(value="relative_helper")

        class MainAgent(Agent):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "helper": HelperAgent,
            }

            @step
            async def start(self) -> Spawn:
                return Spawn(
                    children=[Call(agent="./helper", step="execute")],
                    then=self.collect,
                )

            @step
            async def collect(self, result: SimpleResult) -> SimpleResult:
                return SimpleResult(value=f"got:{result.value}")

        runtime = AgentRuntime(agents={"main": MainAgent})
        result = await runtime.run(agent="main", step="start")
        assert isinstance(result, SimpleResult)
        assert result.value == "got:relative_helper"

    async def test_same_type_multiple_parents(self) -> None:
        """Same subagent type under different parents resolves contextually."""

        class SharedWorker(Agent):
            @step
            async def work(self) -> SimpleResult:
                return SimpleResult(value="shared")

        class TeamA(Agent):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": SharedWorker}

            @step
            async def start(self) -> Spawn:
                return Spawn(
                    children=[Call(agent=SharedWorker, step="work")],
                    then=self.done,
                )

            @step
            async def done(self, result: SimpleResult) -> SimpleResult:
                return SimpleResult(value=f"a:{result.value}")

        class TeamB(Agent):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": SharedWorker}

            @step
            async def start(self) -> Spawn:
                return Spawn(
                    children=[Call(agent=SharedWorker, step="work")],
                    then=self.done,
                )

            @step
            async def done(self, result: SimpleResult) -> SimpleResult:
                return SimpleResult(value=f"b:{result.value}")

        runtime = AgentRuntime(agents={"team_a": TeamA, "team_b": TeamB})
        r1 = await runtime.run(agent="team_a", step="start")
        assert isinstance(r1, SimpleResult)
        assert r1.value == "a:shared"

        r2 = await runtime.run(agent="team_b", step="start")
        assert isinstance(r2, SimpleResult)
        assert r2.value == "b:shared"

    def test_invalid_agent_name_rejected(self) -> None:
        """Agent names with dots or special chars are rejected."""
        defn = make_defn({"start": StepMeta()}, lambda s, sp, cr: None)  # type: ignore[arg-type,return-value]
        with pytest.raises(ValueError, match="Invalid agent name"):
            AgentRuntime(agents={"invalid.name": defn})

        with pytest.raises(ValueError, match="Invalid agent name"):
            AgentRuntime(agents={"invalid name": defn})
