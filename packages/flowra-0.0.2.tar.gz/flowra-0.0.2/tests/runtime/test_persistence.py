"""Persistence integration tests using an in-memory SessionStorage."""

import dataclasses
from typing import Any

import pytest

from flowra.agent import (
    AgentDefinition,
    AgentInstance,
    AgentResult,
    AgentStore,
    Call,
    Goto,
    Scalar,
    ServiceLocator,
    Spawn,
    StepMeta,
    StepResult,
    StepSpec,
)
from flowra.runtime import AgentRuntime, ChangeSet, InMemorySessionStorage
from tests.runtime.storage import TrackingSessionStorage


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Val(AgentResult):
    v: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Spec(StepSpec):
    msg: str


_TYPE_REGISTRY: dict[str, type] = {"Val": Val, "Spec": Spec}


def _defn(handler: Any, type_registry: dict[str, type] | None = None) -> AgentDefinition:
    def create(sl: ServiceLocator, slot_containers: dict) -> AgentInstance:  # type: ignore[type-arg]
        return AgentInstance(call_step=handler)

    return AgentDefinition(steps={}, slots={}, type_registry=type_registry or _TYPE_REGISTRY, create_instance=create)


# -- Tests --


class TestSaveExecutionCalled:
    async def test_save_called_after_run(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        storage = TrackingSessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        result = await runtime.run(agent="a", step="start")

        assert isinstance(result, Val)
        assert result.v == "ok"
        assert len(storage.save_execution_calls) == 1
        assert storage.transaction_count >= 1


class TestSaveExecutionTreeShape:
    async def test_spawn_saves_all_node_ids(self) -> None:
        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="work", agent="c", spec=Spec(msg="1")),
                        Call(step="work", agent="c", spec=Spec(msg="2")),
                    ],
                    then="join",
                )
            assert cr is not None
            return Val(v=",".join(r.v for r in cr))  # type: ignore[union-attr]

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            assert isinstance(spec, Spec)
            return Val(v=spec.msg)

        storage = TrackingSessionStorage()
        runtime = AgentRuntime(agents={"p": _defn(parent), "c": _defn(child)}, storage=storage)
        result = await runtime.run(agent="p", step="start")

        assert isinstance(result, Val)
        assert result.v == "1,2"

        # Should have saved execution multiple times (once per advance tick)
        assert len(storage.save_execution_calls) == 3  # spawn, children+propagate, join

        # Check the second save (after spawn) had children with correct node_ids
        spawn_snapshot = storage.save_execution_calls[0]
        assert spawn_snapshot["node_id"] == "r1"
        assert spawn_snapshot["children"] is not None
        assert len(spawn_snapshot["children"]) == 2
        assert spawn_snapshot["children"][0]["node_id"] == "r1.0"
        assert spawn_snapshot["children"][1]["node_id"] == "r1.1"


class TestResumeFromStorage:
    async def test_run_with_spawn_completes_with_storage(self) -> None:
        call_count = 0

        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            nonlocal call_count
            call_count += 1
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="work", spec=Spec(msg="x")),
                    ],
                    then="join",
                )
            if step == "work":
                assert isinstance(spec, Spec)
                return Val(v=spec.msg)
            # join
            assert cr is not None
            return Val(v="joined:" + ",".join(r.v for r in cr))  # type: ignore[union-attr]

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        result = await runtime.run(agent="a", step="start")

        assert isinstance(result, Val)
        assert result.v == "joined:x"

    async def test_goto_agent_preserves_node_id_in_snapshot(self) -> None:
        async def ha(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Goto(step="run", agent="b")

        async def hb(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="from_b")

        storage = TrackingSessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(ha), "b": _defn(hb)}, storage=storage)
        result = await runtime.run(agent="a", step="start")

        assert isinstance(result, Val)
        assert result.v == "from_b"

        # After Goto to another agent, the saved execution should still have node_id="r1"
        # but agent_name="b" in the final snapshot
        # Note: execution is cleared on completion, so check the save_execution_calls
        assert len(storage.save_execution_calls) >= 1
        last_save = storage.save_execution_calls[-1]
        assert last_save["node_id"] == "r1"


class TestHasPendingExecution:
    async def test_false_without_storage(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        runtime = AgentRuntime(agents={"a": _defn(handler)})
        assert await runtime.has_pending_execution() is False

    async def test_false_with_empty_storage(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        assert await runtime.has_pending_execution() is False

    async def test_false_after_completed_run(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        await runtime.run(agent="a", step="start")
        assert await runtime.has_pending_execution() is False

    async def test_true_with_pending_snapshot(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        # Simulate a crashed run by manually setting execution snapshot
        await storage.save_execution({"node_id": "root", "agent_name": "a", "status": "pending_step"})
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        assert await runtime.has_pending_execution() is True


class TestRunBlockedByPendingExecution:
    async def test_run_raises_when_pending_execution_exists(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        await storage.save_execution({"node_id": "root", "agent_name": "a", "status": "pending_step"})
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        with pytest.raises(RuntimeError, match="Pending execution exists"):
            await runtime.run(agent="a", step="start")


class TestResumeNoStorage:
    async def test_resume_without_storage_raises(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        runtime = AgentRuntime(agents={"a": _defn(handler)})
        with pytest.raises(RuntimeError, match="No storage configured"):
            await runtime.resume()

    async def test_resume_empty_storage_raises(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        with pytest.raises(RuntimeError, match="No persisted state"):
            await runtime.resume()


class TestExecutionClearedOnCompletion:
    async def test_execution_cleared_after_run(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        await runtime.run(agent="a", step="start")

        # Execution snapshot should be cleared after successful completion
        assert await storage.has_execution() is False


class TestResumeRegistersStorageKeys:
    async def test_storage_key_reuse_after_child_completion(self) -> None:
        """After child completes and releases its key, the key can be reused."""
        spawn_count = 0

        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            nonlocal spawn_count
            if step == "start":
                return Spawn(
                    children=[
                        Call(step="work", agent="c", storage_key="child-key"),
                    ],
                    then="join",
                )
            if step == "join":
                spawn_count += 1
                if spawn_count == 1:
                    # First join: spawn again with same key — should work
                    # because first child was released on completion
                    return Spawn(
                        children=[
                            Call(step="work", agent="c", storage_key="child-key"),
                        ],
                        then="done",
                    )
                return Val(v="ok")
            return Val(v="ok")

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="child_done")

        storage = InMemorySessionStorage()

        # Run to completion — verify the key reuse works normally
        runtime = AgentRuntime(
            agents={"p": _defn(parent), "c": _defn(child)},
            storage=storage,
        )
        result = await runtime.run(agent="p", step="start", storage_key="parent-key")
        assert isinstance(result, Val)
        assert result.v == "ok"


class TestSnapshotIncludesStorageKey:
    async def test_storage_key_in_snapshot(self) -> None:
        async def handler(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            return Val(v="ok")

        storage = TrackingSessionStorage()
        runtime = AgentRuntime(agents={"a": _defn(handler)}, storage=storage)
        await runtime.run(agent="a", step="start", storage_key="my-key")

        assert len(storage.save_execution_calls) >= 1
        snapshot = storage.save_execution_calls[0]
        assert snapshot["storage_key"] == "my-key"


class TestSameQualnameNoCollision:
    async def test_two_agents_same_qualname_specs_no_collision(self) -> None:
        """Two agents with same-qualname StepSpec/AgentResult don't collide at startup."""
        # Val and Spec have same qualname across both agents — per-agent registries handle this
        defn_a = AgentDefinition(
            steps={"run": StepMeta(step_spec=Spec, result_types=frozenset({Val}))},
            slots={},
            type_registry={"Val": Val, "Spec": Spec},
            create_instance=lambda sl, sc: AgentInstance(call_step=handler_a),
        )
        defn_b = AgentDefinition(
            steps={"run": StepMeta(step_spec=Spec, result_types=frozenset({Val}))},
            slots={},
            type_registry={"Val": Val, "Spec": Spec},
            create_instance=lambda sl, sc: AgentInstance(call_step=handler_b),
        )

        async def handler_a(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            assert isinstance(spec, Spec)
            return Val(v=f"a:{spec.msg}")

        async def handler_b(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            assert isinstance(spec, Spec)
            return Val(v=f"b:{spec.msg}")

        # Should not raise ValueError — same types in different agents are fine
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn_a, "b": defn_b}, storage=storage)
        result = await runtime.run(agent="a", step="run", spec=Spec(msg="hello"))
        assert isinstance(result, Val)
        assert result.v == "a:hello"

    async def test_resume_deserializes_per_agent_types(self) -> None:
        """Resume correctly deserializes each agent's types using per-agent registries."""

        async def parent(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            if step == "start":
                return Spawn(
                    children=[Call(step="work", agent="c", spec=Spec(msg="test"))],
                    then="join",
                )
            assert cr is not None
            return Val(v=cr[0].v)  # type: ignore[union-attr]

        async def child(
            step: str,
            spec: StepSpec | None,
            cr: list[AgentResult] | None,
        ) -> StepResult:
            assert isinstance(spec, Spec)
            return Val(v=spec.msg)

        storage = InMemorySessionStorage()
        parent_defn = AgentDefinition(
            steps={},
            slots={},
            type_registry={"Val": Val, "Spec": Spec},
            create_instance=lambda sl, sc: AgentInstance(call_step=parent),
        )
        child_defn = AgentDefinition(
            steps={},
            slots={},
            type_registry={"Val": Val, "Spec": Spec},
            create_instance=lambda sl, sc: AgentInstance(call_step=child),
        )
        runtime = AgentRuntime(agents={"p": parent_defn, "c": child_defn}, storage=storage)
        result = await runtime.run(agent="p", step="start")
        assert isinstance(result, Val)
        assert result.v == "test"


# -- Slot-dependent tests ------------------------------------------------------


def _defn_with_counter(
    handler_factory: Any,
    type_registry: dict[str, type] | None = None,
) -> AgentDefinition:
    """Build an AgentDefinition with a 'counter' Scalar[int] slot."""
    from flowra.agent import SlotContainer, SlotDef, SlotKind

    def create(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
        counter = slot_containers["counter"]
        store = sl.services[AgentStore]
        return handler_factory(counter, store)

    return AgentDefinition(
        steps={},
        slots={"counter": SlotDef(key="counter", kind=SlotKind.SCALAR, value_type=int)},
        type_registry=type_registry or _TYPE_REGISTRY,
        create_instance=create,
    )


class TestScopeFlushMidStep:
    async def test_flush_saves_node_state(self) -> None:
        flush_calls_before: list[tuple[str, Any]] = []

        def make_handler(counter: Any, store: AgentStore) -> AgentInstance:
            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                counter.set(counter.get(0) + 1)
                await store.flush()
                flush_calls_before.extend(storage.save_node_state_calls[:])
                counter.set(counter.get(0) + 1)
                return Val(v=str(counter.get(0)))

            return AgentInstance(call_step=handler)

        storage = TrackingSessionStorage()
        defn = _defn_with_counter(make_handler)
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        result = await runtime.run(agent="a", step="start", storage_key="main")

        assert isinstance(result, Val)
        assert result.v == "2"

        # flush mid-step should have saved counter=1
        # First call is __meta (run counter), second is the actual flush
        assert len(flush_calls_before) == 2
        assert flush_calls_before[0] == ("__meta", ChangeSet(scalars={"run_counter": 1}, appends={}))
        assert flush_calls_before[1] == ("main", ChangeSet(scalars={"counter": 1}, appends={}))


class TestNodeStatePersistsAfterCompletion:
    async def test_node_state_persists_after_completion(self) -> None:
        def make_handler(counter: Any, store: AgentStore) -> AgentInstance:
            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                counter.set(counter.get(0) + 1)
                return Val(v=str(counter.get(0)))

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        await runtime.run(agent="a", step="start", storage_key="main")

        # Execution cleared, but node state persists
        assert await storage.has_execution() is False
        node_state = await storage.load_node_state("main")
        assert node_state is not None
        assert node_state["counter"] == 1


class TestCrossRunContinuity:
    async def test_state_restored_in_new_run_with_same_storage_key(self) -> None:
        def make_handler(counter: Any, store: AgentStore) -> AgentInstance:
            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                counter.set(counter.get(0) + 1)
                return Val(v=str(counter.get(0)))

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        storage = InMemorySessionStorage()

        # First run
        runtime1 = AgentRuntime(agents={"a": defn}, storage=storage)
        r1 = await runtime1.run(agent="a", step="start", storage_key="main")
        assert isinstance(r1, Val)
        assert r1.v == "1"

        # Second run with same storage_key — counter should start from 1
        runtime2 = AgentRuntime(agents={"a": defn}, storage=storage)
        r2 = await runtime2.run(agent="a", step="start", storage_key="main")
        assert isinstance(r2, Val)
        assert r2.v == "2"


class TestDefaultStorageKey:
    async def test_root_defaults_to_storage_key_root(self) -> None:
        def make_handler(counter: Any, store: AgentStore) -> AgentInstance:
            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                counter.set(counter.get(0) + 1)
                return Val(v=str(counter.get(0)))

            return AgentInstance(call_step=handler)

        defn = _defn_with_counter(make_handler)
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        await runtime.run(agent="a", step="start")  # default storage_key="root"

        # State saved under default storage_key "root"
        node_state = await storage.load_node_state("root")
        assert node_state is not None
        assert node_state["counter"] == 1


class TestChildStatePersistsAfterPropagation:
    async def test_child_dirty_state_saved_before_propagation_prunes_children(self) -> None:
        """When a child completes, its dirty state must be saved before
        __propagate_completions removes it from the tree.

        Bug: __propagate_completions sets node.children = None inside advance(),
        BEFORE __save_dirty_scopes runs. So the child's dirty changes are lost.
        """

        from flowra.agent import AppendOnlyList, SlotContainer, SlotDef, SlotKind

        def create_parent(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                if step == "start":
                    return Spawn(
                        children=[Call(step="work", agent="child", storage_key="child-state")],
                        then="join",
                    )
                assert cr is not None
                return cr[0]

            return AgentInstance(call_step=handler)

        def create_child(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
            items: AppendOnlyList[str] = slot_containers["items"]  # type: ignore[assignment]

            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                items.append("hello")
                items.append("world")
                return Val(v="done")

            return AgentInstance(call_step=handler)

        parent_defn = AgentDefinition(
            steps={},
            slots={},
            type_registry=_TYPE_REGISTRY,
            create_instance=create_parent,
        )
        child_defn = AgentDefinition(
            steps={},
            slots={"items": SlotDef(key="items", kind=SlotKind.APPEND_ONLY, value_type=str)},
            type_registry=_TYPE_REGISTRY,
            create_instance=create_child,
        )

        storage = InMemorySessionStorage()
        runtime = AgentRuntime(
            agents={"parent": parent_defn, "child": child_defn},
            storage=storage,
        )
        result = await runtime.run(agent="parent", step="start", storage_key="parent-state")
        assert isinstance(result, Val)
        assert result.v == "done"

        # The child's items should have been persisted
        child_state = await storage.load_node_state("child-state")
        assert child_state is not None, "Child state was not persisted — dirty scopes lost during propagation"
        assert child_state["items"] == ["hello", "world"]


class TestRegisterType:
    async def test_register_type_persists_and_restores(self) -> None:
        """Types in type_registry persist and restore correctly."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class CustomData:
            name: str
            value: int

        from flowra.agent import SlotContainer, SlotDef, SlotKind

        def create(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
            data = slot_containers["data"]
            assert isinstance(data, Scalar)

            async def handler(
                step: str,
                spec: StepSpec | None,
                cr: list[AgentResult] | None,
            ) -> StepResult:
                if data.get(None) is None:
                    data.set(CustomData(name="test", value=42))
                    return Goto(step="check")
                current = data.get(None)
                assert isinstance(current, CustomData)
                return Val(v=f"{current.name}:{current.value}")

            return AgentInstance(call_step=handler)

        defn = AgentDefinition(
            steps={},
            slots={"data": SlotDef(key="data", kind=SlotKind.SCALAR, value_type=CustomData)},
            type_registry={**_TYPE_REGISTRY, "CustomData": CustomData},
            create_instance=create,
        )
        storage = InMemorySessionStorage()
        runtime = AgentRuntime(agents={"a": defn}, storage=storage)
        result = await runtime.run(agent="a", step="start", storage_key="main")
        assert isinstance(result, Val)
        assert result.v == "test:42"
