import asyncio

from flowra.agent import InterruptToken
from flowra.runtime import InterruptTokenSource


class TestInterruptTokenSource:
    def test_initial_state_is_false(self) -> None:
        source = InterruptTokenSource()
        assert source.token.interrupted is False

    def test_interrupt_makes_token_interrupted(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        assert source.token.interrupted is True

    def test_interrupt_is_idempotent(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        source.interrupt()
        assert source.token.interrupted is True

    def test_clear_resets_token(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        assert source.token.interrupted is True
        source.clear()
        assert source.token.interrupted is False

    async def test_wait_returns_immediately_when_already_interrupted(self) -> None:
        source = InterruptTokenSource()
        source.interrupt()
        await source.token.wait()  # should not hang

    async def test_wait_completes_when_interrupted_concurrently(self) -> None:
        source = InterruptTokenSource()

        async def interrupt_after_delay() -> None:
            await asyncio.sleep(0.01)
            source.interrupt()

        task = asyncio.create_task(interrupt_after_delay())
        await asyncio.wait_for(source.token.wait(), timeout=1.0)
        await task
        assert source.token.interrupted is True

    def test_token_is_interrupt_token(self) -> None:
        source = InterruptTokenSource()
        assert isinstance(source.token, InterruptToken)
