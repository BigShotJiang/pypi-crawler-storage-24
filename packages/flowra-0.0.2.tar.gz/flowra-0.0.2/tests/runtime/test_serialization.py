import dataclasses
import uuid
from datetime import date, datetime, time
from decimal import Decimal

import pytest

from flowra.agent import AgentResult, StepSpec
from flowra.llm import (
    AssistantMessage,
    ImageBlock,
    SystemMessage,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
    Usage,
    UserMessage,
)
from flowra.runtime.serialization import deserialize_value, serialize_value


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MySpec(StepSpec):
    msg: str
    count: int


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MyResult(AgentResult):
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class NestedSpec(StepSpec):
    inner: MySpec
    label: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpecWithStdlib(StepSpec):
    id: uuid.UUID
    created: datetime
    amount: Decimal


TYPE_REGISTRY: dict[str, type] = {
    "SystemMessage": SystemMessage,
    "UserMessage": UserMessage,
    "AssistantMessage": AssistantMessage,
    "Usage": Usage,
    "TextBlock": TextBlock,
    "ImageBlock": ImageBlock,
    "ToolUseBlock": ToolUseBlock,
    "ToolResultBlock": ToolResultBlock,
    "MySpec": MySpec,
    "MyResult": MyResult,
    "NestedSpec": NestedSpec,
    "SpecWithStdlib": SpecWithStdlib,
}

TYPE_TAGS: dict[type, str] = {v: k for k, v in TYPE_REGISTRY.items()}


class TestSerializePrimitives:
    def test_none(self) -> None:
        assert serialize_value(None, TYPE_TAGS) is None

    def test_str(self) -> None:
        assert serialize_value("hello", TYPE_TAGS) == "hello"

    def test_int(self) -> None:
        assert serialize_value(42, TYPE_TAGS) == 42

    def test_float(self) -> None:
        assert serialize_value(3.14, TYPE_TAGS) == 3.14

    def test_bool(self) -> None:
        assert serialize_value(True, TYPE_TAGS) is True

    def test_list(self) -> None:
        assert serialize_value([1, "a", None], TYPE_TAGS) == [1, "a", None]

    def test_dict(self) -> None:
        assert serialize_value({"a": 1, "b": "c"}, TYPE_TAGS) == {"a": 1, "b": "c"}


class TestSerializeBytes:
    def test_bytes(self) -> None:
        result = serialize_value(b"\x00\x01\x02\xff", TYPE_TAGS)
        assert result == {"__bytes__": "AAEC/w=="}

    def test_empty_bytes(self) -> None:
        result = serialize_value(b"", TYPE_TAGS)
        assert result == {"__bytes__": ""}


class TestSerializeStdlibTypes:
    def test_uuid(self) -> None:
        u = uuid.UUID("550e8400-e29b-41d4-a716-446655440000")
        result = serialize_value(u, TYPE_TAGS)
        assert result == {"__uuid__": "550e8400-e29b-41d4-a716-446655440000"}

    def test_datetime(self) -> None:
        dt = datetime(2024, 1, 15, 10, 30, 0)
        result = serialize_value(dt, TYPE_TAGS)
        assert result == {"__datetime__": "2024-01-15T10:30:00"}

    def test_date(self) -> None:
        d = date(2024, 1, 15)
        result = serialize_value(d, TYPE_TAGS)
        assert result == {"__date__": "2024-01-15"}

    def test_time(self) -> None:
        t = time(10, 30, 45)
        result = serialize_value(t, TYPE_TAGS)
        assert result == {"__time__": "10:30:45"}

    def test_decimal(self) -> None:
        d = Decimal("1.234")
        result = serialize_value(d, TYPE_TAGS)
        assert result == {"__decimal__": "1.234"}


class TestSerializeDataclass:
    def test_step_spec(self) -> None:
        spec = MySpec(msg="hi", count=3)
        result = serialize_value(spec, TYPE_TAGS)
        assert result == {"__type__": "MySpec", "__data__": {"msg": "hi", "count": 3}}

    def test_agent_result(self) -> None:
        res = MyResult(value="ok")
        result = serialize_value(res, TYPE_TAGS)
        assert result == {"__type__": "MyResult", "__data__": {"value": "ok"}}

    def test_usage(self) -> None:
        usage = Usage(input_tokens=10, output_tokens=5)
        result = serialize_value(usage, TYPE_TAGS)
        assert result["__type__"] == "Usage"
        assert result["__data__"]["input_tokens"] == 10
        assert result["__data__"]["output_tokens"] == 5

    def test_unsupported_type_raises(self) -> None:
        with pytest.raises(TypeError, match="Cannot serialize"):
            serialize_value(object(), TYPE_TAGS)

    def test_unregistered_dataclass_raises(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Unregistered(AgentResult):
            x: int

        with pytest.raises(TypeError, match="is not registered in type_tags"):
            serialize_value(Unregistered(x=1), TYPE_TAGS)


class TestSerializeMessages:
    def test_user_message(self) -> None:
        msg = UserMessage(blocks=[TextBlock(text="hello")])
        result = serialize_value(msg, TYPE_TAGS)
        assert result["__type__"] == "UserMessage"
        assert result["__data__"]["role"] == "user"

    def test_assistant_message(self) -> None:
        msg = AssistantMessage(blocks=[TextBlock(text="hi")])
        result = serialize_value(msg, TYPE_TAGS)
        assert result["__type__"] == "AssistantMessage"

    def test_system_message(self) -> None:
        msg = SystemMessage(blocks=[TextBlock(text="sys")])
        result = serialize_value(msg, TYPE_TAGS)
        assert result["__type__"] == "SystemMessage"


class TestSerializeBlocks:
    def test_text_block(self) -> None:
        block = TextBlock(text="hello")
        result = serialize_value(block, TYPE_TAGS)
        assert result["__type__"] == "TextBlock"
        assert result["__data__"]["text"] == "hello"

    def test_tool_use_block(self) -> None:
        block = ToolUseBlock(id="call_1", name="search", input={"query": "test"})
        result = serialize_value(block, TYPE_TAGS)
        assert result["__type__"] == "ToolUseBlock"
        assert result["__data__"]["name"] == "search"

    def test_tool_result_block(self) -> None:
        block = ToolResultBlock(tool_use_id="call_1", content="result")
        result = serialize_value(block, TYPE_TAGS)
        assert result["__type__"] == "ToolResultBlock"
        assert result["__data__"]["content"] == "result"


class TestDeserializePrimitives:
    def test_none(self) -> None:
        assert deserialize_value(None, TYPE_REGISTRY) is None

    def test_str(self) -> None:
        assert deserialize_value("hello", TYPE_REGISTRY) == "hello"

    def test_int(self) -> None:
        assert deserialize_value(42, TYPE_REGISTRY) == 42

    def test_list(self) -> None:
        assert deserialize_value([1, "a"], TYPE_REGISTRY) == [1, "a"]

    def test_plain_dict(self) -> None:
        assert deserialize_value({"a": 1}, TYPE_REGISTRY) == {"a": 1}


class TestDeserializeBytes:
    def test_bytes(self) -> None:
        result = deserialize_value({"__bytes__": "AAEC/w=="}, TYPE_REGISTRY)
        assert result == b"\x00\x01\x02\xff"

    def test_empty_bytes(self) -> None:
        result = deserialize_value({"__bytes__": ""}, TYPE_REGISTRY)
        assert result == b""


class TestDeserializeStdlibTypes:
    def test_uuid(self) -> None:
        result = deserialize_value({"__uuid__": "550e8400-e29b-41d4-a716-446655440000"}, TYPE_REGISTRY)
        assert result == uuid.UUID("550e8400-e29b-41d4-a716-446655440000")

    def test_datetime(self) -> None:
        result = deserialize_value({"__datetime__": "2024-01-15T10:30:00"}, TYPE_REGISTRY)
        assert result == datetime(2024, 1, 15, 10, 30, 0)

    def test_date(self) -> None:
        result = deserialize_value({"__date__": "2024-01-15"}, TYPE_REGISTRY)
        assert result == date(2024, 1, 15)

    def test_time(self) -> None:
        result = deserialize_value({"__time__": "10:30:45"}, TYPE_REGISTRY)
        assert result == time(10, 30, 45)

    def test_decimal(self) -> None:
        result = deserialize_value({"__decimal__": "1.234"}, TYPE_REGISTRY)
        assert result == Decimal("1.234")


class TestDeserializeDataclass:
    def test_step_spec(self) -> None:
        data = {"__type__": "MySpec", "__data__": {"msg": "hi", "count": 3}}
        result = deserialize_value(data, TYPE_REGISTRY)
        assert isinstance(result, MySpec)
        assert result.msg == "hi"
        assert result.count == 3

    def test_agent_result(self) -> None:
        data = {"__type__": "MyResult", "__data__": {"value": "ok"}}
        result = deserialize_value(data, TYPE_REGISTRY)
        assert isinstance(result, MyResult)
        assert result.value == "ok"

    def test_framework_type(self) -> None:
        data = {"__type__": "Usage", "__data__": {"input_tokens": 10, "output_tokens": 5}}
        result = deserialize_value(data, TYPE_REGISTRY)
        assert isinstance(result, Usage)
        assert result.input_tokens == 10

    def test_unknown_type_raises(self) -> None:
        data = {"__type__": "Unknown", "__data__": {}}
        with pytest.raises(TypeError, match="Unknown type tag"):
            deserialize_value(data, TYPE_REGISTRY)


class TestDeserializeMessages:
    def test_user_message_round_trip(self) -> None:
        msg = UserMessage(blocks=[TextBlock(text="hello")])
        serialized = serialize_value(msg, TYPE_TAGS)
        restored = deserialize_value(serialized, TYPE_REGISTRY)
        assert isinstance(restored, UserMessage)
        assert isinstance(restored.blocks[0], TextBlock)
        assert restored.blocks[0].text == "hello"

    def test_assistant_message_round_trip(self) -> None:
        msg = AssistantMessage(blocks=[TextBlock(text="hi")])
        serialized = serialize_value(msg, TYPE_TAGS)
        restored = deserialize_value(serialized, TYPE_REGISTRY)
        assert isinstance(restored, AssistantMessage)


class TestRoundTrip:
    def test_spec_round_trip(self) -> None:
        spec = MySpec(msg="test", count=7)
        restored = deserialize_value(serialize_value(spec, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == spec

    def test_result_round_trip(self) -> None:
        result = MyResult(value="ok")
        restored = deserialize_value(serialize_value(result, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == result

    def test_nested_dataclass_round_trip(self) -> None:
        spec = NestedSpec(inner=MySpec(msg="hi", count=1), label="test")
        restored = deserialize_value(serialize_value(spec, TYPE_TAGS), TYPE_REGISTRY)
        assert isinstance(restored, NestedSpec)
        assert isinstance(restored.inner, MySpec)
        assert restored == spec

    def test_dataclass_with_stdlib_fields_round_trip(self) -> None:
        spec = SpecWithStdlib(
            id=uuid.UUID("550e8400-e29b-41d4-a716-446655440000"),
            created=datetime(2024, 1, 15, 10, 30, 0),
            amount=Decimal("99.99"),
        )
        restored = deserialize_value(serialize_value(spec, TYPE_TAGS), TYPE_REGISTRY)
        assert isinstance(restored, SpecWithStdlib)
        assert restored.id == spec.id
        assert restored.amount == spec.amount

    def test_tool_use_round_trip(self) -> None:
        block = ToolUseBlock(id="call_1", name="search", input={"query": "test"})
        restored = deserialize_value(serialize_value(block, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == block

    def test_tool_result_round_trip(self) -> None:
        block = ToolResultBlock(tool_use_id="call_1", content="done", is_error=True)
        restored = deserialize_value(serialize_value(block, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == block

    def test_mixed_assistant_blocks_round_trip(self) -> None:
        msg = AssistantMessage(
            blocks=[
                TextBlock(text="Let me search."),
                ToolUseBlock(id="call_1", name="search", input={"q": "test"}),
            ]
        )
        restored = deserialize_value(serialize_value(msg, TYPE_TAGS), TYPE_REGISTRY)
        assert isinstance(restored, AssistantMessage)
        assert len(restored.blocks) == 2
        assert isinstance(restored.blocks[0], TextBlock)
        assert isinstance(restored.blocks[1], ToolUseBlock)

    def test_metadata_preserved(self) -> None:
        msg = UserMessage(
            blocks=[TextBlock(text="hello", metadata={"source": "user"})],
            metadata={"session": "abc"},
        )
        restored = deserialize_value(serialize_value(msg, TYPE_TAGS), TYPE_REGISTRY)
        assert isinstance(restored, UserMessage)
        assert restored.metadata == {"session": "abc"}
        assert restored.blocks[0].metadata == {"source": "user"}


class TestRoundTripStdlibTypes:
    def test_uuid_round_trip(self) -> None:
        u = uuid.UUID("550e8400-e29b-41d4-a716-446655440000")
        restored = deserialize_value(serialize_value(u, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == u

    def test_datetime_round_trip(self) -> None:
        dt = datetime(2024, 1, 15, 10, 30, 0)
        restored = deserialize_value(serialize_value(dt, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == dt

    def test_date_round_trip(self) -> None:
        d = date(2024, 1, 15)
        restored = deserialize_value(serialize_value(d, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == d

    def test_time_round_trip(self) -> None:
        t = time(10, 30, 45)
        restored = deserialize_value(serialize_value(t, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == t

    def test_decimal_round_trip(self) -> None:
        d = Decimal("1.234")
        restored = deserialize_value(serialize_value(d, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == d

    def test_stdlib_types_in_dict(self) -> None:
        data = {
            "id": uuid.UUID("550e8400-e29b-41d4-a716-446655440000"),
            "created": datetime(2024, 1, 15),
            "amount": Decimal("99.99"),
        }
        restored = deserialize_value(serialize_value(data, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == data

    def test_stdlib_types_in_list(self) -> None:
        data = [uuid.UUID("550e8400-e29b-41d4-a716-446655440000"), Decimal("1.5"), date(2024, 6, 1)]
        restored = deserialize_value(serialize_value(data, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == data


class TestRoundTripBytes:
    def test_bytes_round_trip(self) -> None:
        data = b"\x00\x01\x02\xff"
        restored = deserialize_value(serialize_value(data, TYPE_TAGS), TYPE_REGISTRY)
        assert restored == data

    def test_image_block_round_trip(self) -> None:
        block = ImageBlock(data=b"\x89PNG\r\n", media_type="image/png")
        serialized = serialize_value(block, TYPE_TAGS)
        restored = deserialize_value(serialized, TYPE_REGISTRY)
        assert isinstance(restored, ImageBlock)
        assert restored.data == b"\x89PNG\r\n"
        assert restored.media_type == "image/png"

    def test_user_message_with_image_round_trip(self) -> None:
        msg = UserMessage(
            blocks=[
                TextBlock(text="look at this"),
                ImageBlock(data=b"\xff\xd8\xff", media_type="image/jpeg"),
            ]
        )
        serialized = serialize_value(msg, TYPE_TAGS)
        restored = deserialize_value(serialized, TYPE_REGISTRY)
        assert isinstance(restored, UserMessage)
        assert isinstance(restored.blocks[1], ImageBlock)
        assert restored.blocks[1].data == b"\xff\xd8\xff"


class TestDeserializeUnsupportedType:
    def test_unsupported_type_raises(self) -> None:
        with pytest.raises(TypeError, match="Cannot deserialize"):
            deserialize_value(set(), {})
