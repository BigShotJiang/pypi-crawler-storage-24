from flowra.lib.tool_loop import (
    CACHE_ALL,
    CACHE_MANUAL,
    CACHE_SESSION,
    NO_CACHE,
    CacheConfig,
    cache_last_message,
    cache_last_session_message,
    cache_last_system_prompt,
    cache_last_tool,
    no_cache_messages,
    no_cache_system_prompt,
    no_cache_tools,
)
from flowra.llm import AssistantMessage, Message, SystemMessage, TextBlock, Tool, ToolUseBlock, UserMessage


def _tool(name: str, *, cache: bool = False) -> Tool:
    return Tool(name=name, description="", input_schema=None, cache=cache)


def _sys(text: str) -> SystemMessage:
    return SystemMessage(blocks=[TextBlock(text=text)])


def _user(text: str) -> UserMessage:
    return UserMessage(blocks=[TextBlock(text=text)])


def _assistant(text: str) -> AssistantMessage:
    return AssistantMessage(blocks=[TextBlock(text=text)])


class TestCacheLastSystemPrompt:
    def test_caches_last_system_message(self) -> None:
        messages: list[SystemMessage] = [
            SystemMessage(blocks=[TextBlock(text="a"), TextBlock(text="b")]),
            SystemMessage(blocks=[TextBlock(text="c")]),
        ]
        result = cache_last_system_prompt(messages)
        sys0 = result[0]
        sys1 = result[1]
        assert isinstance(sys0, SystemMessage)
        assert isinstance(sys1, SystemMessage)
        assert sys0.blocks[0].cache is False
        assert sys0.blocks[1].cache is False
        assert sys1.blocks[0].cache is True

    def test_no_system_messages(self) -> None:
        result = cache_last_system_prompt([])
        assert result == []

    def test_clears_existing_cache(self) -> None:
        messages: list[SystemMessage] = [
            SystemMessage(blocks=[TextBlock(text="a", cache=True)]),
            SystemMessage(blocks=[TextBlock(text="b")]),
        ]
        result = cache_last_system_prompt(messages)
        sys0 = result[0]
        sys1 = result[1]
        assert isinstance(sys0, SystemMessage)
        assert isinstance(sys1, SystemMessage)
        assert sys0.blocks[0].cache is False
        assert sys1.blocks[0].cache is True

    def test_does_not_mutate_original(self) -> None:
        messages: list[SystemMessage] = [SystemMessage(blocks=[TextBlock(text="hello")])]
        cache_last_system_prompt(messages)
        sys0 = messages[0]
        assert isinstance(sys0, SystemMessage)
        assert sys0.blocks[0].cache is False


class TestCacheLastTool:
    def test_caches_last(self) -> None:
        tools = [_tool("a"), _tool("b")]
        result = cache_last_tool(tools)
        assert result[0].cache is False
        assert result[1].cache is True

    def test_single_tool(self) -> None:
        result = cache_last_tool([_tool("a")])
        assert result[0].cache is True

    def test_empty(self) -> None:
        result = cache_last_tool([])
        assert result == []

    def test_clears_existing_cache(self) -> None:
        tools = [_tool("a", cache=True), _tool("b")]
        result = cache_last_tool(tools)
        assert result[0].cache is False
        assert result[1].cache is True

    def test_does_not_mutate_original(self) -> None:
        tools = [_tool("a")]
        cache_last_tool(tools)
        assert tools[0].cache is False


class TestCacheLastMessage:
    def test_caches_last_overall_text_block(self) -> None:
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [_user("hello"), _assistant("hi")]
        result = cache_last_message(session, turn)
        last = result[-1]
        assert isinstance(last, AssistantMessage)
        assert last.blocks[0].cache is True  # type: ignore[union-attr]

    def test_middle_messages_not_cached(self) -> None:
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [_user("hello"), _assistant("hi")]
        result = cache_last_message(session, turn)
        user_msg = result[1]
        assert isinstance(user_msg, UserMessage)
        assert user_msg.blocks[0].cache is False  # type: ignore[union-attr]

    def test_empty(self) -> None:
        result = cache_last_message([], [])
        assert result == []

    def test_caches_last_block_even_if_not_text(self) -> None:
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [
            AssistantMessage(blocks=[ToolUseBlock(id="1", name="t", input={})]),
        ]
        result = cache_last_message(session, turn)
        sys_msg = result[0]
        assert isinstance(sys_msg, SystemMessage)
        assert sys_msg.blocks[0].cache is False
        assistant_msg = result[1]
        assert isinstance(assistant_msg, AssistantMessage)
        assert assistant_msg.blocks[0].cache is True

    def test_clears_existing_cache(self) -> None:
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [
            UserMessage(blocks=[TextBlock(text="hello", cache=True)]),
            _assistant("hi"),
        ]
        result = cache_last_message(session, turn)
        user_msg = result[1]
        assert isinstance(user_msg, UserMessage)
        assert user_msg.blocks[0].cache is False  # type: ignore[union-attr] — cleared
        last = result[-1]
        assert isinstance(last, AssistantMessage)
        assert last.blocks[0].cache is True  # type: ignore[union-attr]


class TestCacheLastSessionMessage:
    def test_caches_last_session_message(self) -> None:
        session: list[Message] = [_sys("system"), _user("saved")]
        turn: list[Message] = [_assistant("response")]
        result = cache_last_session_message(session, turn)
        saved = result[1]
        assert isinstance(saved, UserMessage)
        assert saved.blocks[0].cache is True  # type: ignore[union-attr]

    def test_turn_messages_untouched(self) -> None:
        session: list[Message] = [_sys("system"), _user("saved")]
        turn: list[Message] = [_assistant("response"), _user("follow-up")]
        result = cache_last_session_message(session, turn)
        resp = result[2]
        follow = result[3]
        assert isinstance(resp, AssistantMessage)
        assert resp.blocks[0].cache is False  # type: ignore[union-attr]
        assert isinstance(follow, UserMessage)
        assert follow.blocks[0].cache is False  # type: ignore[union-attr]

    def test_empty_session(self) -> None:
        turn: list[Message] = [_user("hello")]
        result = cache_last_session_message([], turn)
        user_msg = result[0]
        assert isinstance(user_msg, UserMessage)
        assert user_msg.blocks[0].cache is False  # type: ignore[union-attr]


class TestNoCacheSystemPrompt:
    def test_clears_cache_hints(self) -> None:
        messages: list[SystemMessage] = [
            SystemMessage(blocks=[TextBlock(text="a", cache=True)]),
            SystemMessage(blocks=[TextBlock(text="b", cache=True)]),
        ]
        result = no_cache_system_prompt(messages)
        assert result[0].blocks[0].cache is False
        assert result[1].blocks[0].cache is False

    def test_no_hints_to_clear(self) -> None:
        messages: list[SystemMessage] = [_sys("a")]
        result = no_cache_system_prompt(messages)
        assert result[0].blocks[0].cache is False

    def test_empty(self) -> None:
        assert no_cache_system_prompt([]) == []


class TestNoCacheTools:
    def test_clears_cache_hints(self) -> None:
        tools = [_tool("a", cache=True), _tool("b", cache=True)]
        result = no_cache_tools(tools)
        assert result[0].cache is False
        assert result[1].cache is False

    def test_no_hints_to_clear(self) -> None:
        tools = [_tool("a")]
        result = no_cache_tools(tools)
        assert result[0].cache is False

    def test_empty(self) -> None:
        assert no_cache_tools([]) == []


class TestNoCacheMessages:
    def test_clears_cache_hints(self) -> None:
        session: list[Message] = [UserMessage(blocks=[TextBlock(text="a", cache=True)])]
        turn: list[Message] = [AssistantMessage(blocks=[TextBlock(text="b", cache=True)])]
        result = no_cache_messages(session, turn)
        assert result[0].blocks[0].cache is False  # type: ignore[union-attr]
        assert result[1].blocks[0].cache is False  # type: ignore[union-attr]

    def test_no_hints_to_clear(self) -> None:
        session: list[Message] = [_user("a")]
        turn: list[Message] = [_assistant("b")]
        result = no_cache_messages(session, turn)
        assert result[0].blocks[0].cache is False  # type: ignore[union-attr]
        assert result[1].blocks[0].cache is False  # type: ignore[union-attr]

    def test_empty(self) -> None:
        assert no_cache_messages([], []) == []


class TestCacheConfig:
    def test_apply_with_all_strategies(self) -> None:
        config = CacheConfig(
            system_prompt=cache_last_system_prompt,
            tools=cache_last_tool,
            messages=cache_last_message,
        )
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [_user("hello")]
        tools = [_tool("a")]
        messages, result_tools = config.apply(session, turn, tools)
        # System prompt cached
        assert isinstance(messages[0], SystemMessage)
        assert messages[0].blocks[0].cache is True
        # Last tool cached
        assert result_tools[0].cache is True
        # Last message cached
        assert isinstance(messages[-1], UserMessage)
        assert messages[-1].blocks[0].cache is True  # type: ignore[union-attr]

    def test_apply_with_no_strategies(self) -> None:
        config = CacheConfig()
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [_user("hello")]
        tools = [_tool("a")]
        messages, result_tools = config.apply(session, turn, tools)
        assert len(messages) == 2
        assert isinstance(messages[0], SystemMessage)
        assert messages[0].blocks[0].cache is False
        assert result_tools[0].cache is False

    def test_apply_partial_strategies(self) -> None:
        config = CacheConfig(tools=cache_last_tool)
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [_user("hello")]
        tools = [_tool("a")]
        messages, result_tools = config.apply(session, turn, tools)
        assert isinstance(messages[0], SystemMessage)
        assert messages[0].blocks[0].cache is False
        assert result_tools[0].cache is True


class TestPresets:
    def test_no_cache_clears_existing_hints(self) -> None:
        session: list[Message] = [
            SystemMessage(blocks=[TextBlock(text="system", cache=True)]),
        ]
        turn: list[Message] = [
            UserMessage(blocks=[TextBlock(text="hello", cache=True)]),
        ]
        tools = [_tool("a", cache=True)]
        messages, result_tools = NO_CACHE.apply(session, turn, tools)
        assert isinstance(messages[0], SystemMessage)
        assert messages[0].blocks[0].cache is False
        assert isinstance(messages[1], UserMessage)
        assert messages[1].blocks[0].cache is False  # type: ignore[union-attr]
        assert result_tools[0].cache is False

    def test_no_cache_without_existing_hints(self) -> None:
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [_user("hello")]
        tools = [_tool("a")]
        messages, result_tools = NO_CACHE.apply(session, turn, tools)
        assert isinstance(messages[0], SystemMessage)
        assert messages[0].blocks[0].cache is False
        assert isinstance(messages[1], UserMessage)
        assert messages[1].blocks[0].cache is False  # type: ignore[union-attr]
        assert result_tools[0].cache is False

    def test_cache_manual_preserves_existing_hints(self) -> None:
        session: list[Message] = [
            SystemMessage(blocks=[TextBlock(text="system", cache=True)]),
        ]
        turn: list[Message] = [
            UserMessage(blocks=[TextBlock(text="hello", cache=True)]),
        ]
        tools = [_tool("a", cache=True)]
        messages, result_tools = CACHE_MANUAL.apply(session, turn, tools)
        assert isinstance(messages[0], SystemMessage)
        assert messages[0].blocks[0].cache is True
        assert isinstance(messages[1], UserMessage)
        assert messages[1].blocks[0].cache is True  # type: ignore[union-attr]
        assert result_tools[0].cache is True

    def test_cache_all(self) -> None:
        session: list[Message] = [_sys("system")]
        turn: list[Message] = [_user("hello"), _assistant("hi")]
        tools = [_tool("a"), _tool("b")]
        messages, result_tools = CACHE_ALL.apply(session, turn, tools)
        assert isinstance(messages[0], SystemMessage)
        assert messages[0].blocks[0].cache is True
        assert result_tools[-1].cache is True
        last = messages[-1]
        assert isinstance(last, AssistantMessage)
        assert last.blocks[0].cache is True  # type: ignore[union-attr]

    def test_cache_session(self) -> None:
        session: list[Message] = [_sys("system"), _user("saved")]
        turn: list[Message] = [_assistant("response"), _user("follow-up")]
        tools = [_tool("a")]
        messages, result_tools = CACHE_SESSION.apply(session, turn, tools)
        # System cached
        assert isinstance(messages[0], SystemMessage)
        assert messages[0].blocks[0].cache is True
        # Last session message cached
        saved = messages[1]
        assert isinstance(saved, UserMessage)
        assert saved.blocks[0].cache is True  # type: ignore[union-attr]
        # Turn messages NOT cached
        resp = messages[2]
        assert isinstance(resp, AssistantMessage)
        assert resp.blocks[0].cache is False  # type: ignore[union-attr]
        follow = messages[3]
        assert isinstance(follow, UserMessage)
        assert follow.blocks[0].cache is False  # type: ignore[union-attr]
        # Tool cached
        assert result_tools[0].cache is True
