import dataclasses

import pytest

from flowra.agent import NEW_SCOPE, Agent, AgentResult, Call, Goto, Spawn, StepMeta, StepSpec, step

# -- StepSpec / AgentResult ---------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MyStepSpec(StepSpec):
    topic: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MyResult(AgentResult):
    text: str


class TestStepSpec:
    def test_frozen(self) -> None:
        spec = MyStepSpec(topic="test")
        with pytest.raises(dataclasses.FrozenInstanceError):
            spec.topic = "other"  # type: ignore[misc]


class TestAgentResult:
    def test_frozen(self) -> None:
        result = MyResult(text="hi")
        with pytest.raises(dataclasses.FrozenInstanceError):
            result.text = "other"  # type: ignore[misc]


# -- Goto --------------------------------------------------------------------


class _AgentA(Agent):
    @step
    async def run(self) -> MyResult:
        return MyResult(text="a")

    @step
    async def process(self) -> MyResult:
        return MyResult(text="a")


class _AgentB(Agent):
    @step
    async def run(self) -> MyResult:
        return MyResult(text="b")


class TestGoto:
    def test_step_string(self) -> None:
        g = Goto(step="next")
        assert g.step == "next"
        assert g.agent is None
        assert g.spec is None
        assert g.storage_key is None

    def test_with_spec(self) -> None:
        spec = MyStepSpec(topic="t")
        g = Goto(step="next", spec=spec)
        assert g.spec is spec

    def test_frozen(self) -> None:
        g = Goto(step="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            g.step = "y"  # type: ignore[misc]

    def test_unbound_method_requires_agent(self) -> None:
        with pytest.raises(TypeError, match="requires explicit agent parameter"):
            Goto(step=_AgentB.run)

    def test_unbound_method_with_agent_class(self) -> None:
        g = Goto(step=_AgentB.run, agent=_AgentB)
        assert g.agent is _AgentB
        assert g.step == "run"

    def test_bound_method_no_agent(self) -> None:
        a = _AgentA()
        g = Goto(step=a.run)
        assert g.agent is None
        assert g.step == "run"

    def test_explicit_agent_overrides(self) -> None:
        g = Goto(step=_AgentB.run, agent="custom")
        assert g.agent == "custom"
        assert g.step == "run"

    def test_storage_key_string(self) -> None:
        g = Goto(step="next", storage_key="my-key")
        assert g.storage_key == "my-key"

    def test_storage_key_new_scope(self) -> None:
        g = Goto(step="next", storage_key=NEW_SCOPE)
        assert g.storage_key is NEW_SCOPE


# -- Call --------------------------------------------------------------------


class TestCall:
    def test_step_string(self) -> None:
        c = Call(step="fetch")
        assert c.step == "fetch"
        assert c.agent is None
        assert c.spec is None
        assert c.storage_key is None

    def test_with_spec(self) -> None:
        spec = MyStepSpec(topic="t")
        c = Call(step="fetch", spec=spec)
        assert c.spec is spec

    def test_frozen(self) -> None:
        c = Call(step="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            c.step = "y"  # type: ignore[misc]

    def test_unbound_method_requires_agent(self) -> None:
        with pytest.raises(TypeError, match="requires explicit agent parameter"):
            Call(step=_AgentB.run)

    def test_unbound_method_with_agent_class(self) -> None:
        c = Call(step=_AgentB.run, agent=_AgentB)
        assert c.agent is _AgentB
        assert c.step == "run"

    def test_bound_method_no_agent(self) -> None:
        a = _AgentA()
        c = Call(step=a.run)
        assert c.agent is None
        assert c.step == "run"

    def test_explicit_agent_overrides(self) -> None:
        c = Call(step=_AgentB.run, agent="custom")
        assert c.agent == "custom"
        assert c.step == "run"

    def test_storage_key(self) -> None:
        c = Call(step="fetch", storage_key="k")
        assert c.storage_key == "k"


# -- Spawn --------------------------------------------------------------------


class TestSpawn:
    def test_with_same_agent_calls(self) -> None:
        s = Spawn(children=[Call(step="a"), Call(step="b")], then="merge")
        assert len(s.children) == 2
        assert s.then == "merge"

    def test_with_cross_agent_calls(self) -> None:
        s = Spawn(
            children=[Call(agent=_AgentB, step=_AgentB.run), Call(agent=_AgentB, step=_AgentB.run)], then="collect"
        )
        assert len(s.children) == 2

    def test_mixed_children(self) -> None:
        s = Spawn(children=[Call(step="a"), Call(agent=_AgentB, step=_AgentB.run)], then="join")
        assert s.children[0].agent is None
        assert s.children[1].agent is _AgentB

    def test_frozen(self) -> None:
        s = Spawn(children=[], then="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            s.then = "y"  # type: ignore[misc]

    def test_then_resolves_step_ref(self) -> None:
        s = Spawn(children=[], then=_AgentA.run)
        assert s.then == "run"


# -- StepMeta -----------------------------------------------------------------


class TestStepMeta:
    def test_no_spec(self) -> None:
        meta = StepMeta()
        assert meta.step_spec is None

    def test_with_spec(self) -> None:
        meta = StepMeta(step_spec=MyStepSpec)
        assert meta.step_spec is MyStepSpec

    def test_frozen(self) -> None:
        meta = StepMeta()
        with pytest.raises(dataclasses.FrozenInstanceError):
            meta.step_spec = MyStepSpec  # type: ignore[misc]


# -- NEW_SCOPE sentinel -------------------------------------------------------


class TestNewScope:
    def test_is_unique_type(self) -> None:
        assert not isinstance(NEW_SCOPE, str)
        assert NEW_SCOPE is not None
