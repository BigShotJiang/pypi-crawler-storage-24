import dataclasses

from flowra.agent import Agent, AgentDefinition, AgentResult, StepSpec, step

# -- Fixtures -----------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Spec(StepSpec):
    msg: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Result(AgentResult):
    v: str


# -- Test agents --------------------------------------------------------------


class SimpleAgent(Agent):
    @step
    async def start(self, spec: Spec) -> Result:
        return Result(v=spec.msg)

    @step
    async def finish(self) -> Result:
        return Result(v="done")


class OtherAgent(Agent):
    @step
    async def compute(self, spec: Spec) -> Result:
        return Result(v="other")


class ParentAgent(Agent):
    @step
    async def shared(self) -> Result:
        return Result(v="parent")


class ChildAgent(ParentAgent):
    @step
    async def added(self) -> Result:
        return Result(v="child")


class OverridingChild(ParentAgent):
    @step("shared")
    async def shared_v2(self) -> Result:
        return Result(v="overridden")


# -- Tests: auto-compilation -------------------------------------------------


class TestAutoCompilation:
    def test_has_agent_definition(self) -> None:
        assert isinstance(SimpleAgent.__agent_definition__, AgentDefinition)

    def test_steps_discovered(self) -> None:
        assert set(SimpleAgent.__agent_definition__.steps) == {"start", "finish"}

    def test_child_inherits_parent_steps(self) -> None:
        assert "shared" in ChildAgent.__agent_definition__.steps
        assert "added" in ChildAgent.__agent_definition__.steps

    def test_overriding_child_replaces_parent_step(self) -> None:
        assert "shared" in OverridingChild.__agent_definition__.steps
