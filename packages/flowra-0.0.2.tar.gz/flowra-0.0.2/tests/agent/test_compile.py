import abc
import dataclasses
from typing import Any

import pytest

from flowra.agent import (
    AgentDefinition,
    AgentInstance,
    AgentResult,
    AppendOnlyList,
    Goto,
    Scalar,
    ServiceLocator,
    SlotContainer,
    SlotKind,
    Spawn,
    StepSpec,
    compile_agent,
    slot,
    step,
)


def _make_slot_containers(defn: AgentDefinition) -> dict[str, SlotContainer]:
    containers: dict[str, SlotContainer] = {}
    for key, sd in defn.slots.items():
        match sd.kind:
            case SlotKind.SCALAR:
                containers[key] = Scalar()
            case SlotKind.APPEND_ONLY:
                containers[key] = AppendOnlyList()
    return containers


# -- Test fixtures ------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _SlotMsgA:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _SlotMsgB:
    text: str


type _SlotMsg = _SlotMsgA | _SlotMsgB


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatSpec(StepSpec):
    message: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatResult(AgentResult):
    reply: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SubResult(AgentResult):
    value: int


class FakeServiceLocator(ServiceLocator):
    def __init__(self) -> None:
        self.__services: dict[type, Any] = {}
        self.__services[ServiceLocator] = self

    def provide(self, service_type: type, instance: Any) -> None:
        self.__services[service_type] = instance

    @property
    def services(self) -> dict[type, Any]:
        return dict(self.__services)


class SomeService:
    pass


# -- Test agents (plain classes with @step) -----------------------------------


class SimpleAgent:
    @step("start")
    async def start(self, spec: ChatSpec) -> ChatResult:
        return ChatResult(reply=f"echo: {spec.message}")


class AgentWithDI:
    def __init__(self, service: SomeService) -> None:
        self.service = service

    @step("start")
    async def start(self, spec: ChatSpec) -> ChatResult:
        return ChatResult(reply="with_di")


class AgentWithServices:
    def __init__(self, services: ServiceLocator) -> None:
        self.services_loc = services

    @step("start")
    async def start(self) -> ChatResult:
        return ChatResult(reply=f"services={len(self.services_loc.services)}")


class MultiStepAgent:
    @step("start")
    async def start(self, spec: ChatSpec) -> Goto:
        return Goto(step="finish")

    @step("finish")
    async def finish(self) -> ChatResult:
        return ChatResult(reply="done")


class JoinAgent:
    @step("start")
    async def start(self, spec: ChatSpec) -> ChatResult:
        return ChatResult(reply="start")

    @step("collect")
    async def collect(self, results: list[SubResult]) -> ChatResult:
        total = sum(r.value for r in results)
        return ChatResult(reply=f"total={total}")

    @step("single")
    async def single(self, result: SubResult) -> ChatResult:
        return ChatResult(reply=f"got={result.value}")


class ParentAgent:
    @step("start")
    async def start(self, spec: ChatSpec) -> ChatResult:
        return ChatResult(reply="parent")


class InheritedAgent(ParentAgent):
    @step("added")
    async def added(self) -> ChatResult:
        return ChatResult(reply="added")


class OverridingAgent(ParentAgent):
    @step("start")
    async def start_v2(self, spec: ChatSpec) -> ChatResult:
        return ChatResult(reply="overridden")


# -- Tests: compile_agent ----------------------------------------------------


class TestCompileAgent:
    def test_returns_agent_definition(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert isinstance(defn, AgentDefinition)

    def test_steps(self) -> None:
        defn = compile_agent(MultiStepAgent)
        assert set(defn.steps) == {"start", "finish"}

    def test_step_spec_type(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert defn.steps["start"].step_spec is ChatSpec

    def test_step_without_spec(self) -> None:
        defn = compile_agent(MultiStepAgent)
        assert defn.steps["finish"].step_spec is None

    def test_invalid_return_type_raises(self) -> None:
        class Bad:
            @step("x")  # type: ignore[arg-type]
            async def x(self) -> str:

                return "nope"

        with pytest.raises(TypeError, match="not a valid StepResult"):
            compile_agent(Bad)

    def test_inherits_steps(self) -> None:
        defn = compile_agent(InheritedAgent)
        assert set(defn.steps) == {"start", "added"}

    def test_overrides_step(self) -> None:
        defn = compile_agent(OverridingAgent)
        assert set(defn.steps) == {"start"}


# -- Tests: create + call_step -----------------------------------------------


class TestAgentInstance:
    async def test_call_step_with_spec(self) -> None:
        defn = compile_agent(SimpleAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("start", ChatSpec(message="hello"), None)
        assert isinstance(result, ChatResult)
        assert result.reply == "echo: hello"

    async def test_create_returns_agent_instance(self) -> None:
        defn = compile_agent(SimpleAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        assert isinstance(instance, AgentInstance)

    async def test_unknown_step_raises(self) -> None:
        defn = compile_agent(SimpleAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        with pytest.raises(RuntimeError, match="not found"):
            await instance.call_step("nonexistent", None, None)


# -- Tests: create with DI ---------------------------------------------------


class TestDI:
    async def test_injects_service(self) -> None:
        svc = SomeService()
        defn = compile_agent(AgentWithDI)
        sl = FakeServiceLocator()
        sl.provide(SomeService, svc)
        instance = defn.create_instance(sl, _make_slot_containers(defn))
        result = await instance.call_step("start", ChatSpec(message="hi"), None)
        assert isinstance(result, ChatResult)

    async def test_injects_service_locator(self) -> None:
        defn = compile_agent(AgentWithServices)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("start", None, None)
        assert isinstance(result, ChatResult)


# -- Tests: call_step --------------------------------------------------------


class TestCallStep:
    async def test_goto_step(self) -> None:
        defn = compile_agent(MultiStepAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("start", ChatSpec(message="hi"), None)
        assert isinstance(result, Goto)
        assert result.step == "finish"

        result2 = await instance.call_step("finish", None, None)
        assert isinstance(result2, ChatResult)
        assert result2.reply == "done"

    async def test_join_step_with_list(self) -> None:
        defn = compile_agent(JoinAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("collect", None, [SubResult(value=10), SubResult(value=20)])
        assert isinstance(result, ChatResult)
        assert result.reply == "total=30"

    async def test_join_step_with_single_result(self) -> None:
        defn = compile_agent(JoinAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("single", None, [SubResult(value=42)])
        assert isinstance(result, ChatResult)
        assert result.reply == "got=42"

    async def test_join_empty_list(self) -> None:
        defn = compile_agent(JoinAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("collect", None, None)
        assert isinstance(result, ChatResult)
        assert result.reply == "total=0"


# -- Tests: compile_agent with subagents -------------------------------------


class TestCompileWithSubagents:
    def test_subagents_stored_in_definition(self) -> None:
        sub_defn = compile_agent(SimpleAgent)
        defn = compile_agent(SimpleAgent, subagents={"helper": sub_defn})
        assert "helper" in defn.subagents
        assert defn.subagents["helper"] is sub_defn


# -- Tests: StepMeta.result_types extraction ---------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class OtherResult(AgentResult):
    value: int


type _AliasResult = ChatResult | OtherResult
type _InnerAlias = ChatResult | OtherResult
type _OuterAlias = _InnerAlias | Goto | None
type _AliasA = ChatResult | Goto
type _AliasB = OtherResult | None


class TestResultTypesExtraction:
    def test_single_result_type(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert ChatResult in defn.steps["start"].result_types

    def test_multiple_result_types(self) -> None:
        class MultiResultAgent:
            @step("run")
            async def run(self) -> ChatResult | OtherResult | None:
                return None

        defn = compile_agent(MultiResultAgent)
        assert defn.steps["run"].result_types == frozenset({ChatResult, OtherResult})

    def test_no_result_type(self) -> None:
        class NoResultAgent:
            @step("run")
            async def run(self) -> Goto:
                return Goto(step="run")

        defn = compile_agent(NoResultAgent)
        assert defn.steps["run"].result_types == frozenset()

    def test_type_alias_return_type(self) -> None:
        class AliasAgent:
            @step("run")
            async def run(self) -> _AliasResult:
                return ChatResult(reply="ok")

        defn = compile_agent(AliasAgent)
        assert defn.steps["run"].result_types == frozenset({ChatResult, OtherResult})

    def test_nested_type_alias_return_type(self) -> None:
        class NestedAliasAgent:
            @step("run")
            async def run(self) -> _OuterAlias:
                return ChatResult(reply="ok")

        defn = compile_agent(NestedAliasAgent)
        assert defn.steps["run"].result_types == frozenset({ChatResult, OtherResult})

    def test_union_of_type_aliases(self) -> None:
        class UnionAliasAgent:
            @step("run")
            async def run(self) -> _AliasA | _AliasB:
                return ChatResult(reply="ok")

        defn = compile_agent(UnionAliasAgent)
        assert defn.steps["run"].result_types == frozenset({ChatResult, OtherResult})


class TestAbstractTypeRejection:
    def test_abstract_agent_result_in_return_raises(self) -> None:
        class Bad:
            @step("run")
            async def run(self) -> AgentResult:
                return ChatResult(reply="ok")

        with pytest.raises(TypeError, match="concrete AgentResult subclass"):
            compile_agent(Bad)

    def test_abstract_agent_result_in_union_return_raises(self) -> None:
        class Bad:
            @step("run")
            async def run(self) -> AgentResult | None:
                return None

        with pytest.raises(TypeError, match="concrete AgentResult subclass"):
            compile_agent(Bad)

    def test_abstract_step_spec_param_raises(self) -> None:
        class Bad:
            @step("run")
            async def run(self, spec: StepSpec) -> ChatResult:
                return ChatResult(reply="ok")

        with pytest.raises(TypeError, match="concrete StepSpec subclass"):
            compile_agent(Bad)

    def test_abstract_agent_result_param_allowed(self) -> None:
        class Allowed:
            @step("collect")
            async def collect(self, result: AgentResult) -> ChatResult:
                return ChatResult(reply="ok")

        defn = compile_agent(Allowed)
        assert "collect" in defn.steps

    def test_list_agent_result_param_allowed(self) -> None:
        class Allowed:
            @step("collect")
            async def collect(self, results: list[AgentResult]) -> ChatResult:
                return ChatResult(reply="ok")

        defn = compile_agent(Allowed)
        assert "collect" in defn.steps


# -- Tests: Optional service DI ---------------------------------------------


class TestAbstractServiceDI:
    async def test_service_registered_under_abstract_type(self) -> None:
        class AbstractService(abc.ABC):
            @abc.abstractmethod
            def value(self) -> str: ...

        class ConcreteService(AbstractService):
            def value(self) -> str:
                return "concrete"

        class AgentWithAbstract:
            def __init__(self, svc: AbstractService) -> None:
                self.svc = svc

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply=self.svc.value())

        defn = compile_agent(AgentWithAbstract)
        svc = ConcreteService()
        sl = FakeServiceLocator()
        sl.provide(AbstractService, svc)
        instance = defn.create_instance(sl, _make_slot_containers(defn))
        result = await instance.call_step("start", None, None)
        assert isinstance(result, ChatResult)
        assert result.reply == "concrete"


class TestOptionalServiceDI:
    async def test_optional_service_injected_when_provided(self) -> None:
        class AgentWithOptional:
            def __init__(self, svc: SomeService | None) -> None:
                self.svc = svc

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply=f"has_svc={self.svc is not None}")

        defn = compile_agent(AgentWithOptional)
        svc = SomeService()
        sl = FakeServiceLocator()
        sl.provide(SomeService, svc)
        instance = defn.create_instance(sl, _make_slot_containers(defn))
        result = await instance.call_step("start", None, None)
        assert isinstance(result, ChatResult)
        assert result.reply == "has_svc=True"

    async def test_optional_service_none_when_not_provided(self) -> None:
        class AgentWithOptional:
            def __init__(self, svc: SomeService | None = None) -> None:
                self.svc = svc

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply=f"has_svc={self.svc is not None}")

        defn = compile_agent(AgentWithOptional)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("start", None, None)
        assert isinstance(result, ChatResult)
        assert result.reply == "has_svc=False"


# -- Tests: mixed child result type binding ----------------------------------


class TestMixedChildResults:
    async def test_ambiguous_single_result_raises(self) -> None:
        class AmbiguousAgent:
            @step("collect")
            async def collect(self, result: ChatResult) -> ChatResult:
                return result

        defn = compile_agent(AmbiguousAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        child_results: list[AgentResult] = [ChatResult(reply="a"), ChatResult(reply="b")]
        with pytest.raises(RuntimeError, match="Ambiguous child results"):
            await instance.call_step("collect", None, child_results)

    async def test_single_result_picks_correct_type(self) -> None:
        class MixedAgent:
            @step("collect")
            async def collect(self, chat: ChatResult, other: OtherResult) -> ChatResult:
                return ChatResult(reply=f"{chat.reply},{other.value}")

        defn = compile_agent(MixedAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        child_results: list[AgentResult] = [OtherResult(value=42), ChatResult(reply="hi")]
        result = await instance.call_step("collect", None, child_results)
        assert isinstance(result, ChatResult)
        assert result.reply == "hi,42"


# -- Tests: Spawn with undecorated then -------------------------------------


class TestSpawnUndecoratedThen:
    def test_undecorated_then_raises(self) -> None:
        def plain() -> None:
            pass

        with pytest.raises(TypeError, match="not a @step-decorated method"):
            Spawn(children=[], then=plain)  # type: ignore[arg-type]


# -- Tests: sync steps -------------------------------------------------------


class SyncSimpleAgent:
    @step("start")
    def start(self, spec: ChatSpec) -> ChatResult:  # type: ignore[arg-type]
        return ChatResult(reply=f"sync: {spec.message}")


class SyncMultiStepAgent:
    @step("start")
    def start(self) -> Goto:  # type: ignore[arg-type]
        return Goto(step="finish")

    @step("finish")
    def finish(self) -> ChatResult:  # type: ignore[arg-type]
        return ChatResult(reply="sync done")


class TestSyncSteps:
    async def test_sync_step_returns_result(self) -> None:
        defn = compile_agent(SyncSimpleAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("start", ChatSpec(message="hello"), None)
        assert isinstance(result, ChatResult)
        assert result.reply == "sync: hello"

    async def test_sync_step_returns_goto(self) -> None:
        defn = compile_agent(SyncMultiStepAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("start", None, None)
        assert isinstance(result, Goto)
        assert result.step == "finish"

        result2 = await instance.call_step("finish", None, None)
        assert isinstance(result2, ChatResult)
        assert result2.reply == "sync done"


# -- Tests: static slot compilation ------------------------------------------


class TestSlotCompilation:
    def test_scalar_slot_compiled(self) -> None:
        class AgentWithScalar:
            count: Scalar[int] = slot("count")

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        defn = compile_agent(AgentWithScalar)
        assert "count" in defn.slots
        assert defn.slots["count"].kind.value == "scalar"
        assert defn.slots["count"].value_type is int

    def test_append_only_slot_compiled(self) -> None:
        class AgentWithList:
            history: AppendOnlyList[str] = slot("history")

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        defn = compile_agent(AgentWithList)
        assert "history" in defn.slots
        assert defn.slots["history"].kind.value == "append_only"
        assert defn.slots["history"].value_type is str

    def test_multiple_slots(self) -> None:
        class AgentMultiSlot:
            counter: Scalar[int] = slot("counter")
            log: AppendOnlyList[str] = slot("log")

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        defn = compile_agent(AgentMultiSlot)
        assert set(defn.slots) == {"counter", "log"}

    def test_no_slots(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert defn.slots == {}

    def test_unsupported_slot_type_raises(self) -> None:
        class BadSlotAgent:
            bad: dict[str, int] = slot("bad")  # type: ignore[assignment]

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        with pytest.raises(TypeError, match="unsupported type"):
            compile_agent(BadSlotAgent)


# -- Tests: slot containers created on instance -------------------------------


class TestSlotContainers:
    async def test_scalar_slot_usable(self) -> None:
        class CounterAgent:
            count: Scalar[int] = slot("count")

            @step("start")
            async def start(self) -> ChatResult:
                self.count.set(42)
                return ChatResult(reply=f"count={self.count.get()}")

        defn = compile_agent(CounterAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("start", None, None)
        assert isinstance(result, ChatResult)
        assert result.reply == "count=42"

    async def test_append_only_slot_usable(self) -> None:
        class LogAgent:
            log: AppendOnlyList[str] = slot("log")

            @step("start")
            async def start(self) -> ChatResult:
                self.log.append("hello")
                self.log.append("world")
                return ChatResult(reply=f"log={self.log.get_all()}")

        defn = compile_agent(LogAgent)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("start", None, None)
        assert isinstance(result, ChatResult)
        assert result.reply == "log=['hello', 'world']"

    async def test_slots_isolated_between_instances(self) -> None:
        class StatefulAgent:
            count: Scalar[int] = slot("count")

            @step("start")
            async def start(self) -> ChatResult:
                if self.count.has_value():
                    return ChatResult(reply=f"existing={self.count.get()}")
                self.count.set(1)
                return ChatResult(reply="new")

        defn = compile_agent(StatefulAgent)
        i1 = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        i2 = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))

        r1 = await i1.call_step("start", None, None)
        assert isinstance(r1, ChatResult)
        assert r1.reply == "new"

        r2 = await i2.call_step("start", None, None)
        assert isinstance(r2, ChatResult)
        assert r2.reply == "new"

    def test_slot_access_in_constructor_raises(self) -> None:
        class BadAgent:
            count: Scalar[int] = slot("count")

            def __init__(self) -> None:
                self.count.set(42)

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        defn = compile_agent(BadAgent)
        with pytest.raises(RuntimeError, match="slots are not available in the agent constructor"):
            defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))


# -- Tests: type_registry ----------------------------------------------------


class TestTypeRegistry:
    def test_registers_step_spec(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert ChatSpec.__qualname__ in defn.type_registry
        assert defn.type_registry[ChatSpec.__qualname__] is ChatSpec

    def test_registers_result_types(self) -> None:
        defn = compile_agent(SimpleAgent)
        assert ChatResult.__qualname__ in defn.type_registry
        assert defn.type_registry[ChatResult.__qualname__] is ChatResult

    def test_registers_multiple_result_types(self) -> None:
        class MultiAgent:
            @step("run")
            async def run(self) -> ChatResult | OtherResult | None:
                return None

        defn = compile_agent(MultiAgent)
        assert ChatResult.__qualname__ in defn.type_registry
        assert OtherResult.__qualname__ in defn.type_registry

    def test_registers_slot_value_types(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class HistoryEntry:
            text: str

        class AgentWithTypedSlot:
            history: AppendOnlyList[HistoryEntry] = slot("history")

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        defn = compile_agent(AgentWithTypedSlot)
        assert HistoryEntry.__qualname__ in defn.type_registry
        assert defn.type_registry[HistoryEntry.__qualname__] is HistoryEntry

    def test_does_not_register_primitive_slot_types(self) -> None:
        class AgentWithPrimitiveSlot:
            count: Scalar[int] = slot("count")

            @step("start")
            async def start(self) -> ChatResult:
                return ChatResult(reply="ok")

        defn = compile_agent(AgentWithPrimitiveSlot)
        assert "int" not in defn.type_registry

    def test_registers_union_slot_value_types(self) -> None:
        class AgentWithUnionSlot:
            messages: AppendOnlyList[_SlotMsg] = slot("messages")

            @step("start")
            async def start(self) -> Goto:
                return Goto(step="start")

        defn = compile_agent(AgentWithUnionSlot)
        assert _SlotMsgA.__qualname__ in defn.type_registry
        assert defn.type_registry[_SlotMsgA.__qualname__] is _SlotMsgA
        assert _SlotMsgB.__qualname__ in defn.type_registry
        assert defn.type_registry[_SlotMsgB.__qualname__] is _SlotMsgB

    def test_registers_optional_slot_value_type(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Stats:
            count: int

        class AgentWithOptionalSlot:
            stats: Scalar[Stats | None] = slot("stats")

            @step("start")
            async def start(self) -> Goto:
                return Goto(step="start")

        defn = compile_agent(AgentWithOptionalSlot)
        assert Stats.__qualname__ in defn.type_registry
        assert defn.type_registry[Stats.__qualname__] is Stats

    def test_empty_type_registry_for_no_types(self) -> None:
        class MinimalAgent:
            @step("start")
            async def start(self) -> Goto:
                return Goto(step="start")

        defn = compile_agent(MinimalAgent)
        assert defn.type_registry == {}

    def test_duplicate_qualname_raises(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class DupResult(AgentResult):
            v: int

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class DupResult2(AgentResult):
            v: str

        DupResult2.__qualname__ = DupResult.__qualname__

        class AgentWithDup:
            @step("a")
            async def a(self) -> DupResult:
                return DupResult(v=1)

            @step("b")
            async def b(self) -> DupResult2:
                return DupResult2(v="x")

        with pytest.raises(ValueError, match="Duplicate type tag"):
            compile_agent(AgentWithDup)

    def test_distinct_qualnames_no_conflict(self) -> None:
        class _Ns1:
            @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
            class Shared(AgentResult):
                v: int

        class _Ns2:
            @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
            class Shared(AgentResult):
                v: str

        class Agent1:
            @step("a")
            async def a(self) -> _Ns1.Shared:
                return _Ns1.Shared(v=1)

            @step("b")
            async def b(self) -> _Ns2.Shared:
                return _Ns2.Shared(v="x")

        # Both _Ns1.Shared and _Ns2.Shared have qualname "_Ns2.Shared" / "_Ns1.Shared"
        # — actually they have different qualnames so no conflict.
        # Let's verify no error for distinct qualnames:
        defn = compile_agent(Agent1)
        assert _Ns1.Shared.__qualname__ in defn.type_registry
        assert _Ns2.Shared.__qualname__ in defn.type_registry


# -- Tests: union/alias step params ------------------------------------------


type _UnionResult = ChatResult | SubResult


class TestUnionStepParams:
    async def test_union_param_picks_first_match(self) -> None:
        class AgentWithUnion:
            @step("run")
            async def run(self, result: ChatResult | SubResult) -> ChatResult:
                if isinstance(result, ChatResult):
                    return ChatResult(reply=f"chat:{result.reply}")
                return ChatResult(reply=f"sub:{result.value}")

        defn = compile_agent(AgentWithUnion)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("run", None, [SubResult(value=7)])
        assert isinstance(result, ChatResult)
        assert result.reply == "sub:7"

    async def test_type_alias_param(self) -> None:
        class AgentWithAlias:
            @step("run")
            async def run(self, result: _UnionResult) -> ChatResult:
                if isinstance(result, ChatResult):
                    return ChatResult(reply=f"chat:{result.reply}")
                return ChatResult(reply=f"sub:{result.value}")

        defn = compile_agent(AgentWithAlias)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        result = await instance.call_step("run", None, [ChatResult(reply="hi")])
        assert isinstance(result, ChatResult)
        assert result.reply == "chat:hi"

    async def test_list_of_union_param(self) -> None:
        class AgentWithUnionList:
            @step("run")
            async def run(self, results: list[ChatResult | SubResult]) -> ChatResult:
                return ChatResult(reply=f"count={len(results)}")

        defn = compile_agent(AgentWithUnionList)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        child_results: list[AgentResult] = [ChatResult(reply="a"), SubResult(value=1)]
        result = await instance.call_step("run", None, child_results)
        assert isinstance(result, ChatResult)
        assert result.reply == "count=2"

    async def test_list_of_alias_param(self) -> None:
        class AgentWithAliasList:
            @step("run")
            async def run(self, results: list[_UnionResult]) -> ChatResult:
                return ChatResult(reply=f"count={len(results)}")

        defn = compile_agent(AgentWithAliasList)
        instance = defn.create_instance(FakeServiceLocator(), _make_slot_containers(defn))
        child_results: list[AgentResult] = [ChatResult(reply="a"), SubResult(value=1)]
        result = await instance.call_step("run", None, child_results)
        assert isinstance(result, ChatResult)
        assert result.reply == "count=2"
