from typing import Any

from ..agent import (
    AgentDefinition,
    AgentDefinitionRef,
    AgentInstance,
    AgentRef,
    AgentRegistry,
    AgentResult,
    InterruptToken,
    StepRef,
    StepSpec,
    resolve_step_ref,
)
from ._sealed_scope import create_instance_sealed
from .engine import Completed, Engine, Progressed
from .execution import ChildResult, ExecutionNode, ExecutionStatus
from .interrupt import InterruptTokenSource
from .runtime_scope import RuntimeScope
from .serialization import deserialize_value, serialize_value
from .storage import ChangeSet, SessionStorage

__all__ = ["AgentRuntime"]


class AgentRuntime:
    __slots__ = (
        "__engine",
        "__interrupt_source",
        "__registry",
        "__services",
        "__storage",
        "__tag_by_type",
        "__type_by_tag",
    )

    def __init__(
        self,
        agents: dict[str, AgentDefinitionRef],
        storage: SessionStorage | None = None,
        services: dict[type, Any] | None = None,
    ) -> None:
        self.__storage = storage
        self.__interrupt_source = InterruptTokenSource()
        self.__services: dict[type, Any] = {InterruptToken: self.__interrupt_source.token, **(services or {})}
        self.__registry = AgentRegistry(agents)
        self.__type_by_tag, self.__tag_by_type = self.__build_type_maps(self.__registry)
        self.__engine = Engine(
            registry=self.__registry,
            scope_factory=self.__create_scope,
            instance_factory=self.__create_instance,
            services=self.__services,
            scope_restore=self.__init_node,
        )

    async def run(
        self,
        *,
        agent: AgentRef,
        step: StepRef,
        spec: StepSpec | None = None,
        storage_key: str | None = None,
    ) -> AgentResult | None:
        if await self.has_pending_execution():
            msg = "Pending execution exists; call resume() or clear the execution snapshot first"
            raise RuntimeError(msg)

        agent_name = agent if isinstance(agent, str) else self.__registry.name_for_type(agent)
        step_tag = resolve_step_ref(step)

        run_id = await self.__next_run_id() if self.__storage else 1
        effective_storage_key = storage_key if storage_key is not None else "root"
        root = await self.__engine.build_root(
            agent_name,
            step_tag,
            spec,
            storage_key=effective_storage_key,
            node_id=f"r{run_id}",
        )
        return await self.__run_loop(root)

    async def has_pending_execution(self) -> bool:
        if self.__storage is None:
            return False
        return await self.__storage.has_execution()

    async def resume(self) -> AgentResult | None:
        """Resume from persisted execution snapshot. Requires storage."""
        if self.__storage is None:
            msg = "No storage configured for resume"
            raise RuntimeError(msg)
        execution = await self.__storage.load_execution()
        if execution is None:
            msg = "No persisted state to resume from"
            raise RuntimeError(msg)
        root = await self.__restore_tree(execution, parent=None)
        self.__engine.register_live_storage_keys(root)
        return await self.__run_loop(root)

    def interrupt(self) -> None:
        self.__interrupt_source.interrupt()

    async def __run_loop(self, root: ExecutionNode) -> AgentResult | None:
        while True:
            result = await self.__engine.advance(root)
            await self.__save_post_advance(root)
            match result:
                case Completed(result=r):
                    if self.__storage:
                        await self.__storage.clear_execution()
                    self.__interrupt_source.clear()
                    return r
                case Progressed():
                    continue

    async def __save_post_advance(self, root: ExecutionNode) -> None:
        if self.__storage is None:
            return
        async with self.__storage.begin_transaction():
            await self.__storage.save_execution(self.__snapshot_tree(root))
            await self.__save_dirty_scopes(root)
        self.__mark_all_clean(root)

    async def __save_dirty_scopes(self, node: ExecutionNode) -> None:
        assert self.__storage is not None
        effective_key = node.storage_key if node.storage_key is not None else node.node_id
        tt = self.__tag_by_type.get(node.agent_name, {})
        changes = node.scope.get_changes()
        if not changes.empty:
            serialized = ChangeSet(
                scalars={k: serialize_value(v, tt) for k, v in changes.scalars.items()},
                appends={k: [serialize_value(item, tt) for item in v] for k, v in changes.appends.items()},
            )
            await self.__storage.save_node_state(effective_key, serialized)
        if node.children:
            for child in node.children:
                await self.__save_dirty_scopes(child)

    @classmethod
    def __mark_all_clean(cls, node: ExecutionNode) -> None:
        node.scope.mark_clean()
        if node.children:
            for child in node.children:
                cls.__mark_all_clean(child)

    def __snapshot_tree(self, node: ExecutionNode) -> dict[str, Any]:
        tt = self.__tag_by_type.get(node.agent_name, {})
        child_results_data: list[dict[str, Any]] | None = None
        if node.child_results is not None:
            child_results_data = []
            for cr in node.child_results:
                cr_tt = self.__tag_by_type.get(cr.agent_name, {})
                child_results_data.append(
                    {
                        "agent_name": cr.agent_name,
                        "result": serialize_value(cr.result, cr_tt),
                    }
                )
        return {
            "node_id": node.node_id,
            "storage_key": node.storage_key,
            "agent_name": node.agent_name,
            "status": node.status.value,
            "pending_step": node.pending_step,
            "pending_spec": serialize_value(node.pending_spec, tt) if node.pending_spec is not None else None,
            "then_step": node.then_step,
            "goto_counter": node.goto_counter,
            "result": serialize_value(node.result, tt) if node.result is not None else None,
            "child_results": child_results_data,
            "children": [self.__snapshot_tree(c) for c in node.children] if node.children is not None else None,
        }

    async def __restore_tree(
        self,
        data: dict[str, Any],
        parent: ExecutionNode | None,
    ) -> ExecutionNode:
        agent_name: str = data["agent_name"]
        node_id: str = data["node_id"]
        storage_key: str | None = data.get("storage_key")
        defn = self.__registry.get(agent_name)

        parent_services = parent.scope.get_services() if parent else {}
        merged = {**self.__services, **parent_services}
        scope = self.__create_scope(merged)
        instance = self.__create_instance(defn, scope, merged)
        await self.__init_node(scope, storage_key, node_id, agent_name)

        tr = self.__type_by_tag.get(agent_name, {})
        raw_spec = data.get("pending_spec")
        raw_result = data.get("result")
        raw_child_results = data.get("child_results")

        child_results: list[ChildResult] | None = None
        if raw_child_results is not None:
            child_results = []
            for raw_cr in raw_child_results:
                cr_agent = raw_cr["agent_name"]
                cr_tr = self.__type_by_tag.get(cr_agent, {})
                child_results.append(
                    ChildResult(
                        agent_name=cr_agent,
                        result=deserialize_value(raw_cr["result"], cr_tr),
                    )
                )

        node = ExecutionNode(
            node_id=node_id,
            storage_key=storage_key,
            agent_name=agent_name,
            defn=defn,
            instance=instance,
            scope=scope,
            status=ExecutionStatus(data["status"]),
            pending_step=data.get("pending_step"),
            pending_spec=deserialize_value(raw_spec, tr) if raw_spec is not None else None,
            then_step=data.get("then_step"),
            goto_counter=data.get("goto_counter", 0),
            result=deserialize_value(raw_result, tr) if raw_result is not None else None,
            child_results=child_results,
            parent=parent,
        )

        children_data = data.get("children")
        if children_data is not None:
            node.children = [await self.__restore_tree(child_data, parent=node) for child_data in children_data]

        return node

    @staticmethod
    def __build_type_maps(
        registry: AgentRegistry,
    ) -> tuple[dict[str, dict[str, type]], dict[str, dict[type, str]]]:
        type_by_tag: dict[str, dict[str, type]] = {}
        tag_by_type: dict[str, dict[type, str]] = {}
        for agent_name, defn in registry.all_named_definitions():
            tbt = dict(defn.type_registry)
            type_by_tag[agent_name] = tbt
            tag_by_type[agent_name] = {v: k for k, v in tbt.items()}
        return type_by_tag, tag_by_type

    async def __next_run_id(self) -> int:
        assert self.__storage is not None
        meta = await self.__storage.load_node_state("__meta") or {}
        run_id = meta.get("run_counter", 0) + 1
        await self.__storage.save_node_state("__meta", ChangeSet(scalars={"run_counter": run_id}, appends={}))
        return run_id

    def __create_scope(self, parent_services: dict[type, Any]) -> RuntimeScope:
        return RuntimeScope(parent_services=parent_services)

    def __create_instance(self, defn: AgentDefinition, scope: RuntimeScope, services: dict[type, Any]) -> AgentInstance:
        return create_instance_sealed(defn, scope, services)

    async def __init_node(self, scope: RuntimeScope, storage_key: str | None, node_id: str, agent_name: str) -> None:
        if self.__storage is None:
            return
        storage = self.__storage
        tr = self.__type_by_tag.get(agent_name, {})
        tt = self.__tag_by_type.get(agent_name, {})
        effective_key = storage_key if storage_key is not None else node_id

        node_state = await storage.load_node_state(effective_key)
        if node_state:
            deserialized = {k: deserialize_value(v, tr) for k, v in node_state.items()}
            scope.hydrate(deserialized)
            scope.mark_clean()

        async def flush_cb() -> None:
            changes = scope.get_changes()
            if not changes.empty:
                serialized = ChangeSet(
                    scalars={k: serialize_value(v, tt) for k, v in changes.scalars.items()},
                    appends={k: [serialize_value(item, tt) for item in v] for k, v in changes.appends.items()},
                )
                async with storage.begin_transaction():
                    await storage.save_node_state(effective_key, serialized)
                scope.mark_clean()

        scope.set_flush_callback(flush_cb)
