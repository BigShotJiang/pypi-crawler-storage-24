import asyncio

from ..agent import InterruptToken

__all__ = ["InterruptTokenSource"]


class _InterruptTokenImpl(InterruptToken):
    __slots__ = ("__event", "__interrupted")

    def __init__(self) -> None:
        self.__interrupted = False
        self.__event = asyncio.Event()

    @property
    def interrupted(self) -> bool:
        return self.__interrupted

    async def wait(self) -> None:
        """Block until interrupted. Returns immediately if already interrupted."""
        await self.__event.wait()

    def set(self) -> None:
        self.__interrupted = True
        self.__event.set()

    def clear(self) -> None:
        self.__interrupted = False
        self.__event.clear()


class InterruptTokenSource:
    __slots__ = ("__token",)

    def __init__(self) -> None:
        self.__token = _InterruptTokenImpl()

    @property
    def token(self) -> InterruptToken:
        return self.__token

    def interrupt(self) -> None:
        self.__token.set()

    def clear(self) -> None:
        self.__token.clear()
