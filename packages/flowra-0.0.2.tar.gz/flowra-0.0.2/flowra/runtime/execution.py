import dataclasses
import enum

from ..agent import AgentDefinition, AgentInstance, AgentResult, StepSpec
from .runtime_scope import RuntimeScope

__all__ = ["ChildResult", "ExecutionNode", "ExecutionStatus"]


class ExecutionStatus(enum.StrEnum):
    PENDING_STEP = "pending_step"
    WAITING_CHILDREN = "waiting_children"
    COMPLETED = "completed"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChildResult:
    agent_name: str
    result: AgentResult


# Not frozen — node is mutated during execution tree walk
@dataclasses.dataclass(slots=True, kw_only=True)
class ExecutionNode:
    node_id: str
    storage_key: str | None
    agent_name: str
    defn: AgentDefinition
    instance: AgentInstance
    scope: RuntimeScope
    status: ExecutionStatus

    pending_step: str | None = None
    pending_spec: StepSpec | None = None
    children: "list[ExecutionNode] | None" = None
    child_results: list[ChildResult] | None = None
    then_step: str | None = None
    result: AgentResult | None = None
    goto_counter: int = 0
    parent: "ExecutionNode | None" = None
