from typing import Any

from ..agent import AgentDefinition, AgentInstance, AgentStore, ServiceLocator, SlotContainer, SlotKind
from .runtime_scope import RuntimeScope

__all__ = ["create_instance_sealed"]


class _SealedScope(AgentStore, ServiceLocator):
    __slots__ = ("__scope", "__sealed")

    def __init__(self, scope: RuntimeScope) -> None:
        self.__scope = scope
        self.__sealed = False

    def seal(self) -> None:
        self.__sealed = True

    def provide(self, service_type: type, instance: Any) -> None:
        if self.__sealed:
            raise RuntimeError("provide() can only be called during agent construction")
        self.__scope.provide(service_type, instance)

    async def flush(self) -> None:
        await self.__scope.flush()

    @property
    def services(self) -> dict[type, Any]:
        return self.__scope.services


def create_instance_sealed(
    defn: AgentDefinition,
    scope: RuntimeScope,
    services: dict[type, Any],
) -> AgentInstance:
    sealed = _SealedScope(scope)
    for st, inst in services.items():
        if st not in (AgentStore, ServiceLocator):
            scope.provide(st, inst)
    scope.provide(AgentStore, sealed)
    scope.provide(ServiceLocator, sealed)
    slot_containers: dict[str, SlotContainer] = {}
    for key, sd in defn.slots.items():
        match sd.kind:
            case SlotKind.SCALAR:
                slot_containers[key] = scope.create_scalar(key)
            case SlotKind.APPEND_ONLY:
                slot_containers[key] = scope.create_append_only(key)
    instance = defn.create_instance(sealed, slot_containers)
    sealed.seal()
    return instance
