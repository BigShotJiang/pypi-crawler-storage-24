from collections.abc import Callable
from typing import overload

from .agent_def import StepMethod, set_step_tag

__all__ = ["step"]


@overload
def step[F: StepMethod](fn: F, /) -> F: ...


@overload
def step(tag: str = ..., /) -> Callable[[StepMethod], StepMethod]: ...


def step(tag_or_fn: str | StepMethod = "", /) -> StepMethod | Callable[[StepMethod], StepMethod]:
    if callable(tag_or_fn):
        set_step_tag(tag_or_fn, tag_or_fn.__name__)
        return tag_or_fn

    tag = tag_or_fn

    def decorator(fn: StepMethod) -> StepMethod:
        set_step_tag(fn, tag or fn.__name__)
        return fn

    return decorator
