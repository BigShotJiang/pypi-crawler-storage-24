from collections.abc import Iterable, Sequence
from typing import Any

__all__ = [
    "AppendOnlyList",
    "Scalar",
    "SlotMarker",
    "slot",
]


class _Unset:
    __slots__ = ()


_UNSET = _Unset()


class Scalar[T]:
    __slots__ = ("__dirty", "__value")

    def __init__(self) -> None:
        self.__value: T | _Unset = _UNSET
        self.__dirty = False

    def get(self, default: T | _Unset = _UNSET) -> T:
        if not isinstance(self.__value, _Unset):
            return self.__value
        if not isinstance(default, _Unset):
            return default
        raise LookupError("Scalar has no value and no default was provided")

    def has_value(self) -> bool:
        return not isinstance(self.__value, _Unset)

    def set(self, value: T) -> None:
        self.__value = value
        self.__dirty = True

    def restore(self, value: T) -> None:
        self.__value = value
        self.__dirty = False

    def is_dirty(self) -> bool:
        return self.__dirty

    def mark_clean(self) -> None:
        self.__dirty = False


class AppendOnlyList[T]:
    __slots__ = ("__items", "__unflushed_count")

    def __init__(self, items: Sequence[T] = ()) -> None:
        self.__items: list[T] = list(items)
        self.__unflushed_count = 0

    def get_all(self) -> list[T]:
        return list(self.__items)

    def append(self, item: T) -> None:
        self.__items.append(item)
        self.__unflushed_count += 1

    def extend(self, items: Iterable[T]) -> None:
        new_items = list(items)
        self.__items.extend(new_items)
        self.__unflushed_count += len(new_items)

    def restore(self, items: Sequence[T]) -> None:
        self.__items = list(items)
        self.__unflushed_count = 0

    def get_unflushed(self) -> list[T]:
        if self.__unflushed_count == 0:
            return []
        return list(self.__items[-self.__unflushed_count :])

    def mark_clean(self) -> None:
        self.__unflushed_count = 0


class SlotMarker:
    """Sentinel value for declarative slot definitions on Agent classes.

    Accessing slot methods (get, set, has_value, etc.) on a SlotMarker raises a clear error
    because slots are not available until after the agent constructor completes.
    """

    __slots__ = ("key",)

    def __init__(self, key: str) -> None:
        self.key = key

    def __getattr__(self, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        raise RuntimeError(
            f"Cannot access '{name}' on slot '{self.key}' — "
            f"slots are not available in the agent constructor. "
            f"Use slot values in step methods instead."
        )


def slot(key: str) -> Any:
    """Declare a stored slot on an Agent class.

    Usage::

        class MyAgent(Agent):
            count: Scalar[int] = slot("count")
            history: AppendOnlyList[str] = slot("history")
    """
    return SlotMarker(key)
