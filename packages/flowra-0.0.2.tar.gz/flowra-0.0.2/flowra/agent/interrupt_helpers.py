import asyncio
import contextlib
from collections.abc import AsyncIterator

from .interrupt_token import InterruptToken

__all__ = ["with_interrupt"]


async def with_interrupt[T](ait: AsyncIterator[T], token: InterruptToken) -> AsyncIterator[T]:
    """Wrap an async iterator so it exits immediately when *token* is interrupted.

    On each iteration the next item and ``token.wait()`` are raced via
    ``asyncio.wait``.  If the token fires first the iterator is closed and
    the wrapper ends — even if the underlying ``__anext__`` is blocked on I/O.
    """
    if token.interrupted:
        return

    it = ait.__aiter__()
    wait_task: asyncio.Task[None] | None = None
    try:
        while True:
            next_task = asyncio.ensure_future(it.__anext__())
            if wait_task is None or wait_task.done():
                wait_task = asyncio.ensure_future(token.wait())

            done, _ = await asyncio.wait(
                {next_task, wait_task},
                return_when=asyncio.FIRST_COMPLETED,
            )

            if wait_task in done:
                next_task.cancel()
                with contextlib.suppress(asyncio.CancelledError, StopAsyncIteration):
                    await next_task
                return

            try:
                yield next_task.result()
            except StopAsyncIteration:
                return
    finally:
        if wait_task is not None and not wait_task.done():
            wait_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await wait_task
        aclose = getattr(ait, "aclose", None)
        if aclose is not None:
            await aclose()
