import dataclasses
import inspect
import types
import typing
from typing import Any, TypeAliasType, Union, get_args, get_origin

from .agent_def import (
    AgentDefinition,
    AgentDefinitionRef,
    AgentInstance,
    AgentResult,
    Goto,
    SlotContainer,
    SlotDef,
    SlotKind,
    Spawn,
    StepMeta,
    StepResult,
    StepSpec,
    get_step_tag,
)
from .service_locator import ServiceLocator
from .stored_values import AppendOnlyList, Scalar, SlotMarker

__all__ = ["compile_agent"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _InitParam:
    name: str
    service_type: type


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _StepSpecParam:
    name: str
    spec_type: type


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _StepSingleResultParam:
    name: str
    result_type: type | tuple[type, ...]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _StepResultListParam:
    name: str
    item_type: type | tuple[type, ...]


type _StepParam = _StepSpecParam | _StepSingleResultParam | _StepResultListParam


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _CompiledSlot:
    attr_name: str
    slot_def: SlotDef


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _CompiledStep:
    tag: str
    method_name: str
    spec_type: type[StepSpec] | None
    params: tuple[_StepParam, ...]


def compile_agent(
    agent_cls: type,
    subagents: dict[str, AgentDefinitionRef] | None = None,
) -> AgentDefinition:
    return _AgentCompiler.compile(agent_cls, subagents)


class _AgentCompiler:
    __slots__ = ()

    @classmethod
    def compile(
        cls,
        agent_cls: type,
        subagents: dict[str, AgentDefinitionRef] | None = None,
    ) -> AgentDefinition:
        init_params = cls.__compile_init(agent_cls)
        compiled_steps, step_metas = cls.__compile_steps(agent_cls)
        compiled_slots, slot_defs = cls.__compile_slots(agent_cls)
        type_registry = cls.__build_type_registry(step_metas, slot_defs)

        create_instance = cls.__create_instance

        def create(sl: ServiceLocator, slot_containers: dict[str, SlotContainer]) -> AgentInstance:
            return create_instance(agent_cls, init_params, compiled_steps, compiled_slots, sl, slot_containers)

        return AgentDefinition(
            steps=step_metas,
            slots=slot_defs,
            type_registry=type_registry,
            create_instance=create,
            subagents=subagents or {},
        )

    @classmethod
    def __compile_steps(
        cls,
        agent_cls: type,
    ) -> tuple[dict[str, _CompiledStep], dict[str, StepMeta]]:
        compiled_steps: dict[str, _CompiledStep] = {}
        step_metas: dict[str, StepMeta] = {}

        for klass in reversed(agent_cls.__mro__):
            for attr_name in vars(klass):
                val = getattr(klass, attr_name, None)
                if not callable(val):
                    continue
                tag = get_step_tag(val)
                if tag is None:
                    continue

                result_types = cls.__validate_step_return_type(val, tag)
                params = cls.__compile_step_params(val)
                spec_type = cls.__find_spec_param_type(val)
                compiled_steps[tag] = _CompiledStep(tag=tag, method_name=attr_name, spec_type=spec_type, params=params)
                step_metas[tag] = StepMeta(step_spec=spec_type, result_types=result_types)

        return compiled_steps, step_metas

    @classmethod
    def __compile_slots(cls, agent_cls: type) -> tuple[list[_CompiledSlot], dict[str, SlotDef]]:
        compiled_slots: list[_CompiledSlot] = []
        slot_defs: dict[str, SlotDef] = {}
        hints = cls.__get_type_hints(agent_cls)

        for attr_name, annotation in hints.items():
            value = getattr(agent_cls, attr_name, None)
            if not isinstance(value, SlotMarker):
                continue

            origin = get_origin(annotation) or annotation
            if origin is Scalar:
                args = get_args(annotation)
                if not args:
                    raise TypeError(f"Slot {attr_name!r}: bare Scalar is not allowed, use Scalar[T]")
                value_type = args[0]
                sd = SlotDef(key=value.key, kind=SlotKind.SCALAR, value_type=value_type)
            elif origin is AppendOnlyList:
                args = get_args(annotation)
                if not args:
                    raise TypeError(f"Slot {attr_name!r}: bare AppendOnlyList is not allowed, use AppendOnlyList[T]")
                value_type = args[0]
                sd = SlotDef(key=value.key, kind=SlotKind.APPEND_ONLY, value_type=value_type)
            else:
                raise TypeError(
                    f"Slot {attr_name!r} has unsupported type {annotation!r}. Must be Scalar[T] or AppendOnlyList[T]."
                )

            compiled_slots.append(_CompiledSlot(attr_name=attr_name, slot_def=sd))
            slot_defs[sd.key] = sd

        return compiled_slots, slot_defs

    @classmethod
    def __build_type_registry(
        cls,
        step_metas: dict[str, StepMeta],
        slot_defs: dict[str, SlotDef],
    ) -> dict[str, type]:
        registry: dict[str, type] = {}

        for meta in step_metas.values():
            if meta.step_spec is not None:
                cls.__collect_dataclass_types(meta.step_spec, registry)
            for rt in meta.result_types:
                cls.__collect_dataclass_types(rt, registry)

        for sd in slot_defs.values():
            cls.__collect_dataclass_types(sd.value_type, registry)

        return registry

    @classmethod
    def __collect_dataclass_types(cls, typ: Any, registry: dict[str, type], seen: set[int] | None = None) -> None:
        """Walk type annotations to find all dataclass types.

        Resolves unions, generic args, and type aliases recursively.
        Does NOT descend into dataclass fields — marshmallow handles that.
        """
        if seen is None:
            seen = set()
        typ_id = id(typ)
        if typ_id in seen:
            return
        seen.add(typ_id)

        if isinstance(typ, TypeAliasType):
            cls.__collect_dataclass_types(typ.__value__, registry, seen)
            return

        origin = get_origin(typ)
        if origin is not None:
            for arg in get_args(typ):
                cls.__collect_dataclass_types(arg, registry, seen)
            return

        if not isinstance(typ, type):
            return

        if dataclasses.is_dataclass(typ):
            tag = typ.__qualname__
            existing = registry.get(tag)
            if existing is not None and existing is not typ:
                raise ValueError(f"Duplicate type tag {tag!r}: {existing!r} vs {typ!r}")
            registry[tag] = typ

    @classmethod
    def __create_instance(
        cls,
        agent_cls: type,
        init_params: tuple[_InitParam, ...],
        compiled_steps: dict[str, _CompiledStep],
        compiled_slots: list[_CompiledSlot],
        sl: ServiceLocator,
        slot_containers: dict[str, SlotContainer],
    ) -> AgentInstance:
        all_services = dict(sl.services)
        kwargs: dict[str, Any] = {}
        for ip in init_params:
            if ip.service_type in all_services:
                kwargs[ip.name] = all_services[ip.service_type]
        agent = agent_cls(**kwargs)

        for cs in compiled_slots:
            container = slot_containers[cs.slot_def.key]
            setattr(agent, cs.attr_name, container)

        bind_step_args = cls.__bind_step_args

        async def call_step(
            tag: str, spec: StepSpec | None = None, child_results: list[AgentResult] | None = None
        ) -> StepResult:
            step = compiled_steps.get(tag)
            if step is None:
                raise RuntimeError(f"Step {tag!r} not found in {agent_cls.__name__}")
            step_kwargs = bind_step_args(step, spec=spec, child_results=child_results or [])
            result = getattr(agent, step.method_name)(**step_kwargs)
            if inspect.isawaitable(result):
                return await result
            return result

        return AgentInstance(call_step=call_step)

    @staticmethod
    def __bind_step_args(
        step: _CompiledStep,
        *,
        spec: StepSpec | None = None,
        child_results: list[AgentResult] | None = None,
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {}
        for param in step.params:
            match param:
                case _StepSpecParam(name=name):
                    if spec is not None:
                        kwargs[name] = spec
                case _StepSingleResultParam(name=name, result_type=rt):
                    if child_results:
                        matches = [cr for cr in child_results if isinstance(cr, rt)]
                        if len(matches) > 1:
                            raise RuntimeError(
                                f"Ambiguous child results for parameter '{name}': "
                                f"expected at most 1 match of type {rt!r}, got {len(matches)}"
                            )
                        if matches:
                            kwargs[name] = matches[0]
                case _StepResultListParam(name=name, item_type=it):
                    if child_results:
                        kwargs[name] = [cr for cr in child_results if isinstance(cr, it)]
                    else:
                        kwargs[name] = []
        return kwargs

    @classmethod
    def __compile_init(cls, agent_cls: type) -> tuple[_InitParam, ...]:
        hints = cls.__get_type_hints(agent_cls.__init__)
        params: list[_InitParam] = []
        for name, resolved in hints.items():
            if name == "return":
                continue
            service_type = cls.__extract_service_type(resolved)
            if service_type is not None:
                params.append(_InitParam(name=name, service_type=service_type))
        return tuple(params)

    @classmethod
    def __compile_step_params(cls, method: Any) -> tuple[_StepParam, ...]:
        hints = cls.__get_type_hints(method)
        params: list[_StepParam] = []
        for name, hint in hints.items():
            if name == "self" or name == "return":
                continue
            resolved = cls.__resolve_hint(hint)

            if isinstance(resolved, type) and issubclass(resolved, StepSpec):
                if resolved is StepSpec:
                    raise TypeError(
                        f"Step parameter {name!r} must use a concrete StepSpec subclass, not StepSpec itself"
                    )
                params.append(_StepSpecParam(name=name, spec_type=resolved))
            elif isinstance(resolved, type) and issubclass(resolved, AgentResult):
                params.append(_StepSingleResultParam(name=name, result_type=resolved))
            elif (result_types := cls.__extract_agent_result_types(resolved)) is not None:
                params.append(_StepSingleResultParam(name=name, result_type=result_types))
            elif cls.__is_list_of_agent_result(resolved):
                item_hint = cls.__resolve_hint(get_args(resolved)[0])
                if isinstance(item_hint, type) and issubclass(item_hint, AgentResult):
                    params.append(_StepResultListParam(name=name, item_type=item_hint))
                elif (item_types := cls.__extract_agent_result_types(item_hint)) is not None:
                    params.append(_StepResultListParam(name=name, item_type=item_types))
        return tuple(params)

    @classmethod
    def __find_spec_param_type(cls, method: Any) -> type[StepSpec] | None:
        hints = cls.__get_type_hints(method)
        for name, hint in hints.items():
            if name == "self" or name == "return":
                continue
            resolved = cls.__resolve_hint(hint)
            if isinstance(resolved, type) and issubclass(resolved, StepSpec):
                if resolved is StepSpec:
                    raise TypeError(
                        f"Step parameter {name!r} must use a concrete StepSpec subclass, not StepSpec itself"
                    )
                return resolved
        return None

    @classmethod
    def __validate_step_return_type(cls, method: Any, tag: str) -> frozenset[type[AgentResult]]:
        hints = cls.__get_type_hints(method)
        ret = hints.get("return")
        if ret is None or ret is inspect.Parameter.empty:
            return frozenset()
        ret_types = cls.__flatten_types(ret)
        result_types: set[type[AgentResult]] = set()
        for t in ret_types:
            if t is type(None):
                continue
            if not isinstance(t, type):
                return frozenset()
            if t is AgentResult:
                raise TypeError(
                    f"Step {tag!r} return type must use a concrete AgentResult subclass, not AgentResult itself"
                )
            if issubclass(t, AgentResult):
                result_types.add(t)
            elif not issubclass(t, (Goto, Spawn)):
                raise TypeError(
                    f"Step {tag!r} return type {t.__name__} is not a valid StepResult "
                    f"(must be Goto | Spawn | AgentResult | None)"
                )
        return frozenset(result_types)

    @staticmethod
    def __resolve_hint(hint: Any) -> Any:
        """Unwrap TypeAliasType to the underlying type."""
        while isinstance(hint, TypeAliasType):
            hint = hint.__value__
        return hint

    @classmethod
    def __flatten_types(cls, t: Any) -> list[Any]:
        t = cls.__resolve_hint(t)
        if isinstance(t, types.UnionType) or get_origin(t) is Union:
            result: list[Any] = []
            for arg in get_args(t):
                result.extend(cls.__flatten_types(arg))
            return result
        return [t]

    @classmethod
    def __extract_agent_result_types(cls, hint: Any) -> tuple[type, ...] | None:
        flat = cls.__flatten_types(hint)
        result_types = [t for t in flat if t is not type(None)]
        if not result_types:
            return None
        if all(isinstance(t, type) and issubclass(t, AgentResult) for t in result_types):
            return tuple(result_types)
        return None

    @staticmethod
    def __extract_service_type(resolved: Any) -> type | None:
        if isinstance(resolved, type):
            return resolved
        if isinstance(resolved, types.UnionType) or get_origin(resolved) is Union:
            non_none = [a for a in get_args(resolved) if a is not type(None)]
            if len(non_none) == 1 and isinstance(non_none[0], type):
                return non_none[0]
        return None

    @staticmethod
    def __get_type_hints(obj: Any) -> dict[str, Any]:
        try:
            return typing.get_type_hints(obj)
        except Exception:
            return {}

    @classmethod
    def __is_list_of_agent_result(cls, hint: Any) -> bool:
        origin = get_origin(hint)
        if origin is not list:
            return False
        args = get_args(hint)
        if not args:
            return False
        resolved = cls.__resolve_hint(args[0])
        if isinstance(resolved, type) and issubclass(resolved, AgentResult):
            return True
        return cls.__extract_agent_result_types(resolved) is not None
