import dataclasses
import enum
from collections.abc import Awaitable, Callable
from typing import Any, ClassVar

from .service_locator import ServiceLocator
from .stored_values import AppendOnlyList, Scalar

__all__ = [
    "NEW_SCOPE",
    "AbstractAgent",
    "AgentDefinition",
    "AgentDefinitionRef",
    "AgentInstance",
    "AgentRef",
    "AgentResult",
    "Call",
    "CallStepHandler",
    "CreateInstance",
    "Goto",
    "SlotContainer",
    "SlotDef",
    "SlotKind",
    "Spawn",
    "StepAction",
    "StepMeta",
    "StepMethod",
    "StepRef",
    "StepResult",
    "StepSpec",
    "get_step_tag",
    "resolve_step_owner",
    "resolve_step_ref",
    "set_agent_class",
    "set_step_tag",
]

_STEP_TAG_ATTR = "__step_tag__"
_AGENT_CLASS_ATTR = "__agent_class__"


def get_step_tag(fn: Callable[..., Any]) -> str | None:
    return getattr(fn, _STEP_TAG_ATTR, None)


def set_step_tag(fn: Callable[..., Any], tag: str) -> None:
    setattr(fn, _STEP_TAG_ATTR, tag)


def set_agent_class(fn: Callable[..., Any], cls: type) -> None:
    setattr(fn, _AGENT_CLASS_ATTR, cls)


def resolve_step_ref(ref: "StepRef") -> str:
    if isinstance(ref, str):
        return ref
    func = getattr(ref, "__func__", ref)
    tag = getattr(func, _STEP_TAG_ATTR, None)
    if tag is None:
        raise TypeError(f"{ref!r} is not a @step-decorated method")
    return tag


def resolve_step_owner(ref: "StepRef") -> type | None:
    if isinstance(ref, str):
        return None
    bound_self = getattr(ref, "__self__", None)
    if bound_self is not None:
        return type(bound_self)
    func = getattr(ref, "__func__", ref)
    return getattr(func, _AGENT_CLASS_ATTR, None)


def _resolve_step_with_agent(step: "StepRef", agent: "AgentRef | None") -> str:
    if not isinstance(step, str):
        bound_self = getattr(step, "__self__", None)
        if bound_self is None and agent is None:
            msg = (
                f"Unbound method {step!r} requires explicit agent parameter. "
                f"Use agent=AgentClass or agent='agent_name', or use bound method self.{step.__name__}"
            )
            raise TypeError(msg)
        step = resolve_step_ref(step)
    return step


class AbstractAgent:
    __slots__ = ()
    __agent_definition__: ClassVar["AgentDefinition"]


type AgentRef = str | type[AbstractAgent]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StepSpec:
    pass


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AgentResult:
    pass


class _NewScope(enum.Enum):
    NEW_SCOPE = "NEW_SCOPE"


NEW_SCOPE = _NewScope.NEW_SCOPE


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class Goto:
    agent: AgentRef | None
    step: str
    spec: StepSpec | None
    storage_key: str | _NewScope | None

    def __init__(
        self,
        *,
        step: "StepRef",
        agent: AgentRef | None = None,
        spec: StepSpec | None = None,
        storage_key: str | _NewScope | None = None,
    ) -> None:
        object.__setattr__(self, "agent", agent)
        object.__setattr__(self, "step", _resolve_step_with_agent(step, agent))
        object.__setattr__(self, "spec", spec)
        object.__setattr__(self, "storage_key", storage_key)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class Call:
    agent: AgentRef | None
    step: str
    spec: StepSpec | None
    storage_key: str | _NewScope | None

    def __init__(
        self,
        *,
        step: "StepRef",
        agent: AgentRef | None = None,
        spec: StepSpec | None = None,
        storage_key: str | _NewScope | None = None,
    ) -> None:
        object.__setattr__(self, "agent", agent)
        object.__setattr__(self, "step", _resolve_step_with_agent(step, agent))
        object.__setattr__(self, "spec", spec)
        object.__setattr__(self, "storage_key", storage_key)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class Spawn:
    children: list[Call]
    then: str

    def __init__(
        self,
        *,
        children: list[Call],
        then: "StepRef",
    ) -> None:
        object.__setattr__(self, "children", children)
        object.__setattr__(self, "then", resolve_step_ref(then))


type StepAction = Goto | Spawn
type StepResult = StepAction | AgentResult | None
type StepMethod = Callable[..., StepResult | Awaitable[StepResult]]
type StepRef = str | StepMethod

type CallStepHandler = Callable[[str, StepSpec | None, list[AgentResult] | None], Awaitable[StepResult]]

type SlotContainer = Scalar | AppendOnlyList

type CreateInstance = Callable[[ServiceLocator, dict[str, SlotContainer]], AgentInstance]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AgentInstance:
    call_step: CallStepHandler


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StepMeta:
    step_spec: type[StepSpec] | None = None
    result_types: frozenset[type[AgentResult]] = frozenset()


class SlotKind(enum.StrEnum):
    SCALAR = "scalar"
    APPEND_ONLY = "append_only"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SlotDef:
    key: str
    kind: SlotKind
    value_type: type


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AgentDefinition:
    steps: dict[str, StepMeta]
    slots: dict[str, SlotDef]
    type_registry: dict[str, type]
    create_instance: CreateInstance
    subagents: "dict[str, AgentDefinitionRef]" = dataclasses.field(default_factory=dict)


type AgentDefinitionRef = AgentDefinition | type[AbstractAgent]
