import abc

__all__ = ["InterruptToken"]


class InterruptToken(abc.ABC):
    __slots__ = ()

    @property
    @abc.abstractmethod
    def interrupted(self) -> bool: ...

    @abc.abstractmethod
    async def wait(self) -> None:
        """Block until interrupted. Returns immediately if already interrupted."""
