import abc

__all__ = ["AgentStore"]


class AgentStore(abc.ABC):
    __slots__ = ()

    @abc.abstractmethod
    async def flush(self) -> None: ...
