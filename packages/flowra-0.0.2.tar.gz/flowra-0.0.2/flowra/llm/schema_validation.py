import json
from typing import Any

import jsonschema

__all__ = ["validate_json_schema"]


def strip_markdown_code_block(text: str) -> str:
    text = text.strip()
    if text.startswith("```") and text.endswith("```"):
        lines = text.split("\n")
        return "\n".join(lines[1:-1])
    if text.startswith("```"):
        lines = text.split("\n")
        return "\n".join(lines[1:])
    return text


def validate_json_schema(text: str, schema: dict[str, Any]) -> str | None:
    """Strips markdown code fences, parses JSON, validates against the schema.
    Returns None on success, or an error description string on failure.
    """
    cleaned = strip_markdown_code_block(text)
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as e:
        return f"Invalid JSON: {e}"
    try:
        jsonschema.validate(instance=parsed, schema=schema)
    except jsonschema.ValidationError as e:
        return f"Schema validation error: {e}"
    return None
