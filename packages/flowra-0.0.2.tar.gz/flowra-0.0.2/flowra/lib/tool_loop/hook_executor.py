import inspect
from typing import Any

from ...llm import (
    AssistantMessage,
    LLMRequest,
    LLMResponse,
    TextBlock,
    ThinkingBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from .context import ToolLoopAgentContext
from .hooks import (
    AfterToolCallResult,
    BeforeToolCallResult,
    OnAfterLLMCall,
    OnAfterLLMCallAsync,
    OnAfterToolCall,
    OnAfterToolCallAsync,
    OnBeforeLLMCall,
    OnBeforeLLMCallAsync,
    OnBeforeToolCall,
    OnBeforeToolCallAsync,
    OnMessageAccepted,
    OnMessageAcceptedAsync,
    OnResultMessage,
    OnResultMessageAsync,
    OnStartIteration,
    OnStartIterationAsync,
    OnTextDelta,
    OnTextDeltaAsync,
    OnTextReasoning,
    OnTextReasoningAsync,
    OnThinking,
    OnThinkingAsync,
    OnThinkingDelta,
    OnThinkingDeltaAsync,
    OnUserMessage,
    OnUserMessageAsync,
    ResultMessageResult,
    StartIterationResult,
    UserMessageResult,
)

__all__ = [
    "execute_after_llm_call_hook",
    "execute_after_tool_call_hook",
    "execute_before_llm_call_hook",
    "execute_before_tool_call_hook",
    "execute_message_accepted_hook",
    "execute_result_message_hook",
    "execute_start_iteration_hook",
    "execute_text_delta_hook",
    "execute_text_reasoning_hook",
    "execute_thinking_delta_hook",
    "execute_thinking_hook",
    "execute_user_message_hook",
]


async def execute_user_message_hook(
    hook: OnUserMessage | OnUserMessageAsync | None,
    user_message: UserMessage,
) -> UserMessageResult | None:
    if hook is None:
        return None

    result = hook(user_message)
    if inspect.isawaitable(result):
        result = await result
    return result


async def execute_start_iteration_hook(
    hook: OnStartIteration | OnStartIterationAsync | None,
    iteration: int,
    context: ToolLoopAgentContext,
) -> StartIterationResult | None:
    if hook is None:
        return None

    result = hook(iteration, context)
    if inspect.isawaitable(result):
        result = await result
    return result


async def execute_before_llm_call_hook(
    hook: OnBeforeLLMCall | OnBeforeLLMCallAsync | None,
    request: LLMRequest,
    context: ToolLoopAgentContext,
) -> None:
    if hook is None:
        return

    result = hook(request, context)
    if inspect.isawaitable(result):
        await result


async def execute_after_llm_call_hook(
    hook: OnAfterLLMCall | OnAfterLLMCallAsync | None,
    request: LLMRequest,
    response: LLMResponse,
    context: ToolLoopAgentContext,
) -> None:
    if hook is None:
        return

    result = hook(request, response, context)
    if inspect.isawaitable(result):
        await result


async def execute_result_message_hook(
    hook: OnResultMessage | OnResultMessageAsync | None,
    message: AssistantMessage,
    context: ToolLoopAgentContext,
) -> ResultMessageResult | None:
    if hook is None:
        return None

    result = hook(message, context)
    if inspect.isawaitable(result):
        result = await result
    return result


async def execute_before_tool_call_hook(
    hook: OnBeforeToolCall | OnBeforeToolCallAsync | None,
    tool_use: ToolUseBlock,
    context: ToolLoopAgentContext,
) -> BeforeToolCallResult | None:
    if hook is None:
        return None

    result = hook(tool_use, context)
    if inspect.isawaitable(result):
        result = await result
    return result


async def execute_after_tool_call_hook(
    hook: OnAfterToolCall | OnAfterToolCallAsync | None,
    tool_use: ToolUseBlock,
    result: ToolResultBlock,
    context: ToolLoopAgentContext,
) -> AfterToolCallResult | None:
    if hook is None:
        return None

    hook_result = hook(tool_use, result, context)
    if inspect.isawaitable(hook_result):
        hook_result = await hook_result
    return hook_result


async def execute_text_reasoning_hook(
    hook: OnTextReasoning | OnTextReasoningAsync | None,
    text: TextBlock,
    context: ToolLoopAgentContext,
) -> None:
    if hook is None:
        return

    result = hook(text, context)
    if inspect.isawaitable(result):
        await result


async def execute_thinking_hook(
    hook: OnThinking | OnThinkingAsync | None,
    thinking: ThinkingBlock,
    context: ToolLoopAgentContext,
) -> None:
    if hook is None:
        return

    result = hook(thinking, context)
    if inspect.isawaitable(result):
        await result


async def execute_text_delta_hook(
    hook: OnTextDelta | OnTextDeltaAsync | None,
    text: str,
    context: ToolLoopAgentContext,
) -> None:
    if hook is None:
        return

    result = hook(text, context)
    if inspect.isawaitable(result):
        await result


async def execute_thinking_delta_hook(
    hook: OnThinkingDelta | OnThinkingDeltaAsync | None,
    text: str,
    context: ToolLoopAgentContext,
) -> None:
    if hook is None:
        return

    result = hook(text, context)
    if inspect.isawaitable(result):
        await result


async def execute_message_accepted_hook(
    hook: OnMessageAccepted | OnMessageAcceptedAsync | None,
    meta: dict[str, Any] | None,
) -> None:
    if hook is None:
        return

    result = hook(meta)
    if inspect.isawaitable(result):
        await result
