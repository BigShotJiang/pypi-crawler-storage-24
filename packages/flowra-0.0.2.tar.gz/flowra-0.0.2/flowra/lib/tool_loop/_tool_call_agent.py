import dataclasses

from ...agent import Agent, AgentResult, InterruptToken, ServiceLocator, StepSpec, step
from ...llm import ToolResultBlock, ToolUseBlock
from ...tools import ToolRegistry

__all__ = [
    "ToolCallAgent",
    "ToolCallResult",
    "ToolCallSpec",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolCallSpec(StepSpec):
    tool_use: ToolUseBlock
    allowed_tools: set[str] | None = None
    denied_tools: set[str] | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolCallResult(AgentResult):
    tool_use: ToolUseBlock
    result: ToolResultBlock


class ToolCallAgent(Agent):
    """Executes a single tool call and returns the result.

    Checks for interrupt before execution. On interrupt, returns
    an error result instead of executing the tool.
    """

    __slots__ = ("__interrupt", "__registry", "__services")

    def __init__(
        self,
        services: ServiceLocator,
        registry: ToolRegistry,
        interrupt: InterruptToken,
    ) -> None:
        self.__services = services
        self.__registry = registry
        self.__interrupt = interrupt

    @step("execute")
    async def execute(self, spec: ToolCallSpec) -> ToolCallResult:
        tool_use = spec.tool_use

        if self.__interrupt.interrupted:
            result = ToolResultBlock(
                tool_use_id=tool_use.id,
                content="Tool execution interrupted",
                is_error=True,
            )
            return ToolCallResult(tool_use=tool_use, result=result)

        is_denied = spec.allowed_tools is not None and tool_use.name not in spec.allowed_tools
        is_denied = is_denied or (spec.denied_tools is not None and tool_use.name in spec.denied_tools)
        if is_denied:
            result = ToolResultBlock(
                tool_use_id=tool_use.id,
                content=f"Unknown tool: {tool_use.name}",
                is_error=True,
            )
            return ToolCallResult(tool_use=tool_use, result=result)

        execution_result = await self.__registry.execute(
            tool_use.name, tool_use.input, services=self.__services.services
        )
        result = ToolResultBlock(
            tool_use_id=tool_use.id,
            content=execution_result.content,
            is_error=execution_result.is_error,
        )
        return ToolCallResult(tool_use=tool_use, result=result)
