import dataclasses
from typing import Any

from ...llm import Message
from ..config_value import ConfigValue
from ..llm_config import LLMConfig
from .cache import CACHE_MANUAL, CacheConfig

__all__ = ["ToolLoopConfig"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolLoopConfig:
    """Configuration for ToolLoopAgent.

    Data providers accept ConfigValue[T] — a plain value, sync callable, or async callable.
    """

    llm_config: ConfigValue[LLMConfig]
    session_messages: ConfigValue[list[Message]]
    json_schema: ConfigValue[dict[str, Any] | None] = None
    max_iterations: ConfigValue[int] = 10
    allowed_tools: ConfigValue[set[str] | None] = None
    denied_tools: ConfigValue[set[str] | None] = None
    cache_strategy: ConfigValue[CacheConfig] = CACHE_MANUAL
    max_consecutive_errors: ConfigValue[int | None] = None
