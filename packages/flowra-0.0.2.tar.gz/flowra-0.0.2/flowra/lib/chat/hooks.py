import dataclasses
from typing import Protocol

from ...llm import Message

__all__ = [
    "ChatHooks",
    "OnSaveTurnMessages",
    "OnSaveTurnMessagesAsync",
]


class OnSaveTurnMessages(Protocol):
    """Hook called before turn messages are saved into session history.

    Receives the full list of turn messages and returns the filtered list
    to actually persist. Useful for excluding transient messages
    (e.g. dynamic context injected by hooks) from long-term session history.

    Args:
        messages: Turn messages about to be saved into session history.

    Returns:
        Filtered list of messages to save.
    """

    def __call__(self, messages: list[Message]) -> list[Message]: ...


class OnSaveTurnMessagesAsync(Protocol):
    """Async version of OnSaveTurnMessages."""

    async def __call__(self, messages: list[Message]) -> list[Message]: ...


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatHooks:
    """Lifecycle hooks for ChatAgent.

    Provided as a DI service — no need to thread hooks through config layers.
    """

    on_save_turn_messages: OnSaveTurnMessages | OnSaveTurnMessagesAsync | None = None
