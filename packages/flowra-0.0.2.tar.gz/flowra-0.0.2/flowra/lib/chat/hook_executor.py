import inspect

from ...llm import Message
from .hooks import OnSaveTurnMessages, OnSaveTurnMessagesAsync

__all__ = [
    "execute_save_turn_messages_hook",
]


async def execute_save_turn_messages_hook(
    hook: OnSaveTurnMessages | OnSaveTurnMessagesAsync | None,
    messages: list[Message],
) -> list[Message] | None:
    if hook is None:
        return None

    result = hook(messages)
    if inspect.isawaitable(result):
        result = await result
    return result
