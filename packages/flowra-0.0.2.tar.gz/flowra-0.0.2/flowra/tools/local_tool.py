import dataclasses
import datetime
import decimal
import inspect
import json
import re
import types as builtin_types
import uuid
from collections.abc import Awaitable, Callable
from typing import Annotated, Any, Union, get_args, get_origin, get_type_hints

import jsonschema
import marshmallow_recipe as mr

from .types import ToolDefinition, ToolResult

__all__ = ["LocalTool", "ToolExecutionContext", "ToolHandler", "ToolInput", "ToolService", "get_local_tool", "tool"]

_TOOL_DEFINITION_ATTR = "__tool_definition__"
_TOOL_NAME_PATTERN = r"^[a-zA-Z0-9_-]+$"
_TOOL_NAME_RE = re.compile(_TOOL_NAME_PATTERN)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolExecutionContext:
    input: dict[str, Any]
    services: dict[type, Any]


type ToolHandler = Callable[[ToolExecutionContext], ToolResult | Awaitable[ToolResult]]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LocalTool:
    definition: ToolDefinition
    handler: ToolHandler


class ToolInput:
    """Marker for ``Annotated[ParamType, ToolInput]`` to designate a tool input parameter.

    Usage::

        @tool("fetch")
        def fetch(params: Annotated[FetchParams, ToolInput], config: MyConfig) -> str:
            ...
    """

    __slots__ = ()


class ToolService:
    """Marker for ``Annotated[SvcType, ToolService]`` to designate a service (DI) parameter.

    Usage::

        @tool("fetch")
        def fetch(params: Annotated[FetchParams, ToolInput], svc: Annotated[MyService, ToolService]) -> str:
            ...
    """

    __slots__ = ()


def tool[F: Callable[..., Any]](name: str, description: str | None = None) -> Callable[[F], F]:
    """Decorator that turns a Python function into a ``LocalTool``.

    Auto-derives description (from docstring), input/output schemas (from dataclass
    parameters and return type), and builds a ``ToolHandler`` that binds
    ``ToolExecutionContext.input`` and ``ToolExecutionContext.services`` to the
    function's parameters.

    Use ``Annotated[ParamsType, ToolInput]`` / ``Annotated[SvcType, ToolService]``
    to explicitly mark parameters when they cannot be distinguished by type alone.
    Without markers, a single dataclass parameter is treated as tool input,
    everything else as a service.
    """

    def decorator(func: F) -> F:
        tool_description = description
        if tool_description is None:
            if func.__doc__:
                tool_description = func.__doc__.strip()
            else:
                raise ValueError(f"Tool '{name}' must have description or docstring")

        if not _TOOL_NAME_RE.fullmatch(name):
            raise ValueError(f"Tool name '{name}' must match {_TOOL_NAME_PATTERN}")

        binding = _resolve_binding(name, func)

        input_source = _find_input_source(binding)
        input_schema = _input_schema(input_source.model if input_source else None)
        output_schema = _output_schema(binding.output_model)

        async def async_handler(ctx: ToolExecutionContext) -> ToolResult:
            kwargs = _build_kwargs(ctx, binding, input_schema)
            result = func(**kwargs)
            if inspect.isawaitable(result):
                result = await result
            return ToolResult(content=_format_result(result))

        local_tool = LocalTool(
            definition=ToolDefinition(
                name=name,
                description=tool_description,
                input_schema=input_schema,
                output_schema=output_schema,
            ),
            handler=async_handler,
        )

        setattr(func, _TOOL_DEFINITION_ATTR, local_tool)
        return func

    return decorator


def get_local_tool(handler: Callable[..., Any]) -> LocalTool:
    """Extract LocalTool from a @tool decorated handler."""
    local_tool = getattr(handler, _TOOL_DEFINITION_ATTR, None)
    if local_tool is None:
        raise ValueError(f"Handler {handler.__name__} is not decorated with @tool")
    return local_tool


# -- Binding resolution -------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _InputSource:
    model: type[mr.Dataclass]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _ServiceSource:
    service_type: type
    optional: bool = False


type _BindingSource = _InputSource | _ServiceSource


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _Binding:
    sources: dict[str, _BindingSource] = dataclasses.field(default_factory=dict)
    output_model: type[mr.Dataclass] | None = None


def _resolve_binding(tool_name: str, func: Callable[..., Any]) -> _Binding:
    type_hints = get_type_hints(func, include_extras=True)
    sig = inspect.signature(func)

    resolved: list[tuple[str, type, type | None, bool]] = []
    for param_name in sig.parameters:
        if param_name not in type_hints:
            raise TypeError(f"Tool '{tool_name}': parameter '{param_name}' must have a type annotation")

        annotated_type = type_hints[param_name]
        marker = _find_marker(annotated_type)

        actual_type = annotated_type
        if get_origin(annotated_type) is Annotated:
            actual_type = get_args(annotated_type)[0]

        actual_type, is_optional = _unwrap_optional(actual_type)

        if not isinstance(actual_type, type):
            raise TypeError(
                f"Tool '{tool_name}': parameter '{param_name}' must be a dataclass or a service type, got {actual_type}"
            )

        resolved.append((param_name, actual_type, marker, is_optional))

    has_explicit_input = any(m is ToolInput for _, _, m, _ in resolved)

    sources: dict[str, _BindingSource] = {}
    has_tool_input = False

    for param_name, actual_type, marker, is_optional in resolved:
        if marker is ToolInput:
            if not _is_dataclass_type(actual_type):
                raise TypeError(
                    f"Tool '{tool_name}': ToolInput parameter '{param_name}' must be a dataclass, got {actual_type}"
                )
            if has_tool_input:
                raise TypeError(f"Tool '{tool_name}': multiple ToolInput parameters not allowed")
            sources[param_name] = _InputSource(model=actual_type)
            has_tool_input = True
        elif marker is ToolService:
            sources[param_name] = _ServiceSource(service_type=actual_type, optional=is_optional)
        elif _is_dataclass_type(actual_type) and not has_explicit_input:
            if has_tool_input:
                raise TypeError(
                    f"Tool '{tool_name}': multiple dataclass parameters — "
                    f"use Annotated[..., ToolInput] to mark the tool input parameter"
                )
            sources[param_name] = _InputSource(model=actual_type)
            has_tool_input = True
        else:
            sources[param_name] = _ServiceSource(service_type=actual_type, optional=is_optional)

    output_model: type[Any] | None = None
    if "return" in type_hints:
        return_type = type_hints["return"]
        if _is_dataclass_type(return_type):
            output_model = return_type

    return _Binding(
        sources=sources,
        output_model=output_model,
    )


# -- Helpers -------------------------------------------------------------------


def _is_dataclass_type(t: Any) -> bool:
    return isinstance(t, type) and dataclasses.is_dataclass(t)


def _unwrap_optional(t: Any) -> tuple[Any, bool]:
    origin = get_origin(t)
    if origin is builtin_types.UnionType or origin is Union:
        args = get_args(t)
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1 and len(args) == 2:
            return non_none[0], True
    return t, False


def _find_marker(annotated_type: Any) -> type | None:
    metadata = getattr(annotated_type, "__metadata__", None)
    if metadata is None:
        return None
    for x in metadata:
        if x is ToolInput or isinstance(x, ToolInput):
            return ToolInput
        if x is ToolService or isinstance(x, ToolService):
            return ToolService
    return None


def _find_input_source(binding: _Binding) -> _InputSource | None:
    for source in binding.sources.values():
        if isinstance(source, _InputSource):
            return source
    return None


def _input_schema(params_model: type[mr.Dataclass] | None) -> dict[str, Any] | None:
    if params_model is None:
        return None
    return mr.json_schema(params_model)


def _output_schema(output_model: type[mr.Dataclass] | None) -> dict[str, Any] | None:
    if output_model is None:
        return None
    return mr.json_schema(output_model)


def _build_kwargs(
    ctx: ToolExecutionContext,
    binding: _Binding,
    input_schema: dict[str, Any] | None,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {}
    for param_name, source in binding.sources.items():
        match source:
            case _InputSource(model=model):
                if input_schema is not None:
                    jsonschema.validate(ctx.input, input_schema)
                kwargs[param_name] = mr.load(model, ctx.input)
            case _ServiceSource(service_type=service_type, optional=optional):
                if service_type in ctx.services:
                    kwargs[param_name] = ctx.services[service_type]
                elif optional:
                    kwargs[param_name] = None
                else:
                    raise TypeError(
                        f"Required service {service_type.__name__} not found in ToolExecutionContext.services"
                    )
    return kwargs


class _JSONEncoder(json.JSONEncoder):
    __slots__ = ()

    def default(self, o: object) -> Any:
        if isinstance(o, uuid.UUID):
            return str(o)
        if isinstance(o, decimal.Decimal):
            return str(o)
        if isinstance(o, datetime.datetime):
            return o.isoformat()
        if isinstance(o, datetime.date):
            return o.isoformat()
        if isinstance(o, datetime.time):
            return o.isoformat()
        return super().default(o)


def _format_result(result: Any) -> str:
    if dataclasses.is_dataclass(result) and not isinstance(result, type):
        return json.dumps(mr.dump(result), cls=_JSONEncoder)
    if isinstance(result, dict):
        return json.dumps(result, cls=_JSONEncoder)
    if isinstance(result, list):
        if result and dataclasses.is_dataclass(result[0]) and not isinstance(result[0], type):
            return json.dumps([mr.dump(item) for item in result], cls=_JSONEncoder)
        return json.dumps(result, cls=_JSONEncoder)
    return str(result)
