# Prompt: Documentation Review

You are reviewing the documentation for a Python package. Your goal is to verify that the documentation exists, follows the project's best practices, and serves as a useful guide for users.

## Context

You will be given:
- The full source code of every file in the package (including `__init__.py`)
- The documentation file (`docs/<package>.md`), if it exists
- The package name

This library is brand new with no users — documentation should be written for someone encountering the package for the first time.

## Documentation best practices

### Structure

The documentation must follow this structure:

1. **Title:** `` # Package `flowra.<package_name>` ``
2. **One-line description:** what the package does, in one sentence
3. **File tree:** code block showing the package's file structure with brief per-file comments
4. **Quick start:** minimal working example that demonstrates the most common use case
5. **Sections organized by user importance:** NOT alphabetically by entity, but as a journey:
   - What you need on day 1 (basic usage, core types)
   - Configuration and customization
   - Advanced features
   - Internals (for contributors, not users)

### Content quality

- **Completeness:** every public type, function, and constant from the package's `__all__` must be documented
- **Examples are valid:** code snippets must use correct imports, types, method signatures, and field names that match the actual API
- **Responsibility is clear:** after reading the doc, you understand what the package does, why it exists, and how to use it
- **Logical flow:** sections follow naturally from each other — no jumping between unrelated topics
- **Tables for fields:** dataclass and config fields use markdown tables with columns: Field | Type | Default | Description (or Field | Type | Default when Description is obvious from the name)
- **No stale info:** documentation matches the current code, not an older version
- **No redundancy:** don't repeat the same information in multiple places
- **No implementation noise:** don't mention obvious Python mechanics like `frozen=True`, `slots=True`, `kw_only=True` on dataclasses, or that a class "inherits from X" when the user doesn't need to know. Document what things *do*, not how they are *implemented*.

## What to check

1. **Does documentation exist?** If `docs/<package>.md` doesn't exist, report it as the primary issue.

2. **Structure compliance:** does the doc follow the structure above? Missing sections? Wrong order?

3. **Completeness audit:** compare every symbol in the package's `__all__` against the documentation. List any undocumented symbols.

4. **Example validation:** for each code example in the doc:
   - Are the imports correct? (Right package, right symbol names)
   - Are the API calls correct? (Right method names, right argument names, right types)
   - Does the example make sense as a realistic use case?
   - Would the example actually work if run?

5. **Accuracy:** does the documentation correctly describe what the code does? Look for:
   - Descriptions that don't match the actual behavior
   - Default values that are wrong
   - Type signatures that are incorrect
   - Missing parameters or fields in tables

6. **Clarity:** would a new user understand how to use the package after reading this?

## Output format

```
# Documentation Review: flowra.<package_name>

## Documentation exists: YES / NO

## Structure compliance
<List deviations from the expected structure, or "Compliant.">

## Completeness
### Documented symbols
<List of all symbols from __all__ that ARE documented>

### Undocumented symbols
<List of all symbols from __all__ that are NOT documented, or "None.">

## Example validation
### Example 1: <section name>
- **Valid:** YES / NO
- **Issues:** <list issues, or "None">

### Example 2: ...

## Accuracy issues
<List each inaccuracy with the specific documentation text and what the code actually does, or "None found.">

## Clarity issues
<List any sections that are confusing, poorly explained, or missing context, or "None found.">

## Summary
- Documentation exists: YES / NO
- Structure compliant: YES / NO
- Symbols documented: N / M
- Examples valid: N / M
- Accuracy issues: N
- Clarity issues: N
```

## Important

- Compare documentation against actual code — don't trust the documentation at face value.
- Be specific: quote the exact documentation text that's wrong and what it should say.
- Don't review code style or tests here — only documentation quality.
