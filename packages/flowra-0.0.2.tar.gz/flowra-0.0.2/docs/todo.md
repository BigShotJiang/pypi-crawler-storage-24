# TODO

## State

- **Lazy fork / copy-on-write scope.** Currently `RuntimeScope.fork()` copies all scalars
  and append-only lists eagerly. For large state this is expensive. Make it lazy: child
  reads from parent until first write, copies only the specific field on `set()`/`append()`.
  User contract stays the same — child sees a snapshot of parent state at spawn time,
  but the implementation avoids upfront copying.
- **Frozen list.** Immutable list in state (like Scalar, but for lists). Can be created
  cheaply from `append_only` (slice without copying) or from another frozen list. Useful
  when a child agent needs a snapshot of the parent's list.


## Serialization

- **Custom string tags for serialized types.** Currently the serialization tag is always
  `cls.__qualname__`, which is fragile — renaming or moving a class breaks deserialization of
  persisted state. Should allow explicit string tags, e.g. via a decorator (`@type_tag("my_spec")`)
  or a class attribute (`__type_tag__ = "my_spec"`), falling back to `__qualname__` if not set.
  This also decouples the persistence format from Python naming, making refactoring safer.

