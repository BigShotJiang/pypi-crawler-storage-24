# Review Plan

Systematic code review, bottom-up by dependency order.

**Key principle:** this library has no users yet. There are no backwards compatibility constraints. We can rename, restructure, and redesign anything. The goal is to make the code clean, logical, and architecturally sound — not to preserve existing API surfaces.

## Dependency graph

```
llm            (no deps)
tools          (llm)
agent          (no deps)
runtime        (agent, llm)
lib            (agent, llm, tools, runtime)
```

## Per-package review checklist

For each package, perform these steps in order.

**Iteration rules:**

- **Within a step:** repeat the step until no issues remain before moving to the next.
- **After all steps:** if any step changed the code (especially Steps 5–6), go back to Step 1 and run through all steps again. Code changes can invalidate earlier results — style, naming, docs, tests all need to be re-checked.
- **Done when:** a full pass through all steps produces zero changes.
- **Controversial changes:** if a fix involves loosening type safety (e.g. adding `Any`), introducing workarounds, or fundamentally changing a design — stop and discuss before applying. Only straightforward, unambiguous improvements are applied without asking.
- **`make check` after every change:** run `make check` (lint + tests) after any code modification to catch regressions immediately.

### Step 1: Package structure and responsibility review

Analyze each file in the package:

- **File responsibility:** what is this file's single responsibility? Is it clear and focused?
- **File naming:** does the file name accurately reflect its current contents? (Names can become stale after refactors.)
- **Cohesion:** does everything in the file belong together, or should something be split out / moved?

Then analyze the package as a whole:

- **Package responsibility:** does the package have a clear, coherent purpose? Can you explain it in one sentence?
- **File set makes sense:** do the files together cover the package's responsibility without gaps or overlaps?
- **Public API (`__init__.py` / `__all__`):** is the API convenient to use? Is it obvious what to import and how? No unnecessary exports, no missing ones?

If anything is off — report and discuss before fixing.

### Step 2: Code style review

Review every file in the package against `docs/review_prompts/step2_code_style.md`. Fix all violations found.

### Step 3: Documentation review

Check that the package has documentation in `docs/`. Verify the documentation against these best practices:

- **Structure:** title (`# Package flowra.xxx`), one-line description, file tree, quick start, then sections by user importance
- **Sections by importance, not by entity:** organize from "what you need on day 1" to "internals" — a user journey from launch to deep customization
- **Completeness:** every public type, function, and constant from the package's `__all__` is documented
- **Examples are valid:** code snippets compile, imports are correct, variable names match the actual API
- **Responsibility is clear:** reading the doc, you understand what the package does, why it exists, and how to use it
- **Logical flow:** sections follow naturally from each other, no jumping between unrelated topics
- **Tables for fields:** dataclass/config fields use markdown tables (Field | Type | Default | Description)
- **No stale info:** documentation matches the current code, not an older version

### Step 3b: Documentation readability review

Launch an agent that reads the documentation **as a first-time user** (without looking at source code). The agent evaluates:

- **First impression:** is it clear what the package does and how to start?
- **Logical flow:** do sections progress from simple to complex? Are terms explained before use?
- **Completeness of explanation:** is there enough "why" and "when", not just "what"?
- **Examples quality:** are examples self-contained, realistic, and sufficient?
- **Clarity:** any ambiguous prose, unexplained jargon, or walls of text?

Fix all issues from the report.

### Step 4: Independent documentation audit

Launch a separate agent with a clean context (no prior conversation history). The agent receives only:

- The package source code (all files)
- The documentation file (`docs/<package>.md`)
- The documentation best practices (from Step 3 above)

The agent produces a report covering:

- **Consistency with code:** do documented types, fields, defaults, and signatures match the actual code?
- **Completeness:** is every public symbol from `__all__` documented? Any undocumented behavior?
- **Example validity:** do code examples use correct imports, types, and API calls?
- **Accuracy:** does the documentation correctly describe what the code does?
- **Missing context:** is anything important left unexplained?

Fix all issues from the report.

### Step 5: Test review and completeness

Review existing tests for the package, then fill gaps.

**Low-level — each test must be meaningful:**

- **Name matches behavior:** the test name describes what it verifies, not how it's implemented. Names become stale after refactors — fix them.
- **No trivial tests:** don't test that constructing an object returns an object of that type. Every test must verify actual behavior or a contract.
- **One concept per test:** each test checks one thing. If a test has 5 asserts checking unrelated properties — split it.
- **Clear arrange/act/assert:** the test setup, action, and verification are easy to identify.
- **Tests verify outcomes, not implementation:** test what the code does, not how it does it. Don't assert on internal state unless that state IS the contract.
- **Edge cases and error paths:** not just the happy path — test boundaries, invalid inputs, error conditions.
- **No dead tests:** no commented-out tests, no tests that always pass regardless of code changes, no tests that duplicate other tests.

**High-level — coverage is comprehensive:**

- **Every public function/method has tests:** if it's in `__all__`, it's tested.
- **Integration tests for public API:** test the package's public API as a consumer would use it — imports from `__init__.py`, realistic usage patterns.
- **E2E tests where applicable:** if the package interacts with external services (LLM providers, MCP servers), there should be E2E tests (with `_e2e` suffix per project convention).
- **Edge cases at package boundaries:** what happens with empty inputs, None values, invalid configurations, concurrent access?
- **Error handling:** verify that errors are raised with clear messages, not swallowed silently.

**Fill gaps:** write missing unit tests, integration tests, and E2E tests as identified above.

## Lessons learned

Things to watch for in future reviews, based on issues found in past rounds:

- **Provider-specific data in generic contracts.** Fields like `thought_signature` (Google-only) or `cache_creation_5m_input_tokens` (Anthropic-only) were baked into shared types (`ToolUseBlock`, `Usage`). Use `extra: dict[str, Any]` for provider-specific pass-through data instead of polluting the common contract.
- **Duplicate abstractions.** `LLMExecutor` had an identical interface to `LLMProvider` with no documented reason for the split. When two abstractions have the same signature, question whether both are needed.
- **Implementation noise in documentation.** "Frozen dataclass (immutable after creation)", "stored via `AppendOnlyList`", showing `storage_key` in a simple example — these distract from what the user actually needs to know. Documentation describes behavior, not implementation.
- **Bare generics should error early.** `Scalar` without `[T]` silently worked at class definition time but broke later. Catch misuse at compile time with clear error messages.
- **Sibling file naming symmetry.** `openai_provider.py` had a `_provider` suffix while `anthropic_vertex.py` and `google_vertex.py` did not. Check that sibling files follow the same naming pattern.

## Review order

### 1. `flowra.llm` ✅
No dependencies. LLM abstraction: messages, blocks, request/response, provider interface, executor, serialization.

- [x] `_base.py` — LLMData (base class)
- [x] `blocks.py` — TextBlock, ImageBlock, ToolUseBlock, ToolResultBlock
- [x] `messages.py` — SystemMessage, UserMessage, AssistantMessage
- [x] `tools.py` — Tool descriptor for LLM
- [x] `request.py` — LLMRequest
- [x] `response.py` — LLMResponse, StopReason, Usage
- [x] `provider.py` — LLMProvider (ABC)
- [x] `executor.py` — LLMExecutor (ABC)
- [x] `schema_formatting.py` — JSON Schema formatting for LLM prompts
- [x] `schema_validation.py` — JSON Schema validation
- [x] `providers/anthropic_vertex.py` — AnthropicVertexProvider
- [x] `providers/google_vertex.py` — GoogleVertexProvider
- [x] `providers/openai_provider.py` — OpenAIProvider

### 2. `flowra.tools` ✅
Depends on: llm.

- [x] `types.py` — ToolDefinition, ToolResult
- [x] `local_tool.py` — @tool decorator, LocalTool, DI
- [x] `tool_group.py` — LocalToolGroup, McpToolGroup, ToolGroup
- [x] `tool_registry.py` — ToolRegistry
- [x] `mcp_connection.py` — McpConnection (Streamable HTTP)

### 3. `flowra.agent` ✅
No dependencies.

- [x] `step_decorator.py` — @step decorator
- [x] `agent_def.py` — Goto, Call, Spawn, StepSpec, AgentResult, SlotDef, SlotKind, type aliases
- [x] `agent_store.py` — AgentStore (ABC) — flush
- [x] `service_locator.py` — ServiceLocator (ABC) — provide, services
- [x] `interrupt_token.py` — InterruptToken (ABC) — interrupted, wait
- [x] `stored_values.py` — Scalar[T], AppendOnlyList[T], slot()
- [x] `agent.py` — Agent base class, __init_subclass__ compilation
- [x] `agent_registry.py` — AgentRegistry
- [x] `compile.py` — compile_agent(), slot compilation, type registry

### 4. `flowra.runtime` ✅
Depends on: agent, llm.

- [x] `interrupt.py` — InterruptTokenSource
- [x] `execution.py` — ExecutionNode, ExecutionStatus
- [x] `engine.py` — Engine (advance/build_root)
- [x] `runtime_scope.py` — RuntimeScope (AgentStore, ServiceLocator impl)
- [x] `_sealed_scope.py` — create_instance_sealed
- [x] `serialization.py` — serialize/deserialize values (marshmallow_recipe)
- [x] `runtime.py` — AgentRuntime
- [x] `storage/session_storage.py` — SessionStorage (ABC)
- [x] `storage/file.py` — FileSessionStorage
- [x] `storage/in_memory.py` — InMemorySessionStorage

### 5. `flowra.lib` ✅
Depends on: agent, llm, tools, runtime.

- [x] `config_value.py` — ConfigValue[T], resolve()
- [x] `tool_loop/context.py` — ToolLoopAgentContext
- [x] `tool_loop/cache.py` — CacheConfig, strategies, presets
- [x] `tool_loop/hooks.py` — ToolLoopHooks, hook protocols, result types
- [x] `tool_loop/hook_executor.py` — async/sync hook dispatch
- [x] `llm_config.py` — LLMConfig
- [x] `tool_loop/config.py` — ToolLoopConfig
- [x] `tool_loop/spec.py` — ToolLoopSpec, ToolLoopResult, ToolLoopStatus
- [x] `tool_loop/_tool_call_agent.py` — ToolCallAgent
- [x] `tool_loop/agent.py` — ToolLoopAgent
- [x] `chat/config.py` — ChatConfig
- [x] `chat/spec.py` — ChatSpec, ChatResult
- [x] `chat/agent.py` — ChatAgent
