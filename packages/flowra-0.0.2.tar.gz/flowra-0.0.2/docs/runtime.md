# Package `flowra.runtime`

Agent execution engine. Orchestrates agent execution, manages the execution tree, handles persistence
and state management, supports cooperative interrupts, and provides save/resume for crash recovery.

```
flowra/runtime/
├── runtime.py          # AgentRuntime — main orchestrator, public API
├── engine.py           # Engine — execution logic (advance, apply results, node creation)
├── execution.py        # ExecutionNode, ExecutionStatus — execution tree structure
├── runtime_scope.py    # RuntimeScope — state container (scalars, services, dirty tracking)
├── _sealed_scope.py    # create_instance_sealed — enforces init-only API on scope, creates slot containers
├── serialization.py    # serialize_value / deserialize_value — storage serialization (delegates to marshmallow_recipe)
├── interrupt.py        # InterruptTokenSource — cooperative interruption
└── storage/
    ├── session_storage.py  # SessionStorage (ABC), ChangeSet — persistence interface
    ├── in_memory.py        # InMemorySessionStorage — in-memory implementation (dev/test)
    └── file.py             # FileSessionStorage — JSON file-based implementation
```

## Quick start

```python
import dataclasses
from flowra.agent import Agent, AgentResult, step
from flowra.runtime import AgentRuntime

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetResult(AgentResult):
    greeting: str

class Greeter(Agent):
    @step
    async def greet(self) -> GreetResult:
        return GreetResult(greeting="Hello, world!")

# Create runtime and run
runtime = AgentRuntime(agents={"greeter": Greeter})
result = await runtime.run(agent=Greeter, step=Greeter.greet)
print(result.greeting)  # "Hello, world!"
```

## `AgentRuntime`

Main public API. Manages agent definitions, drives execution, handles persistence.

**Constructor:**
```python
AgentRuntime(
    agents: dict[str, AgentDefinitionRef],
    storage: SessionStorage | None = None,
    services: dict[type, Any] | None = None,
)
```

- `agents` — dict mapping agent names to `AgentDefinition` or `AbstractAgent` subclass
  (subclasses are compiled at class definition time via `__init_subclass__`)
- `storage` — optional `SessionStorage` for persistence (save/resume between runs)
- `services` — DI container: dict mapping service types to instances. Services are injected
  into agent `__init__` by matching parameter type annotations. For example, if your agent
  has `def __init__(self, db: Database)`, pass `services={Database: db_instance}`.

**Methods:**

```python
# Run with agent class + step method reference
result = await runtime.run(agent=MyAgent, step=MyAgent.start)
result = await runtime.run(agent=MyAgent, step=MyAgent.start, spec=MySpec(...))
result = await runtime.run(agent=MyAgent, step=MyAgent.start, storage_key="main")

# Run with string names
result = await runtime.run(agent="my_agent", step="start")

# Resume from persisted state (requires storage)
result = await runtime.resume()  # -> AgentResult | None

# Check if a persisted execution snapshot exists
can_resume = await runtime.has_pending_execution()  # bool

# Cooperative interrupt — signal all running agents to stop gracefully
runtime.interrupt()
```

`run()` accepts an optional `storage_key` parameter that controls
persistence identity. Nodes with the same `storage_key` across runs share persisted
state. Default is `"root"`.

`run()` raises `RuntimeError` if a pending execution snapshot already exists.
Call `resume()` to continue the existing execution, or clear the snapshot first.

`resume()` raises `RuntimeError` if no storage is configured or if no execution snapshot exists.

## State and persistence

### `ChangeSet`

Incremental state changes for a single node.

| Field     | Type                   |
|-----------|------------------------|
| `scalars` | `dict[str, Any]`       |
| `appends` | `dict[str, list[Any]]` |

Property `empty: bool` — `True` when both `scalars` and `appends` are empty.

### `SessionStorage`

Abstract persistence interface. All values reaching storage are already JSON-serializable —
the runtime serializes domain objects (messages, specs, results) before saving and
deserializes after loading.

```python
class SessionStorage(ABC):
    @asynccontextmanager
    async def begin_transaction(self) -> AsyncIterator[None]: ...

    async def has_execution(self) -> bool: ...
    async def save_execution(self, execution: dict[str, Any]) -> None: ...
    async def load_execution(self) -> dict[str, Any] | None: ...
    async def clear_execution(self) -> None: ...

    async def save_node_state(self, key: str, changes: ChangeSet) -> None: ...
    async def load_node_state(self, key: str) -> dict[str, Any] | None: ...
```

Two groups of methods:
- **Execution snapshot** (`save_execution`, `load_execution`, `clear_execution`, `has_execution`) —
  temporary crash-recovery snapshot of the execution tree. Cleared on successful completion.
- **Node state** (`save_node_state`, `load_node_state`) — persistent per-node state that survives
  across runs. `save_node_state` receives incremental `ChangeSet` (only dirty scalars and new appends).

**Built-in implementations:**

| Class                    | Use case                                                 |
|--------------------------|----------------------------------------------------------|
| `InMemorySessionStorage` | Dev/test — stores everything in memory                   |
| `FileSessionStorage`     | Production — JSON files under `<base_dir>/<session_id>/` |

### `FileSessionStorage`

```python
FileSessionStorage(base_dir="/var/data/agents", session_id="session-123")
```

File layout (session ID and node keys are sanitized for safe filenames):
```
<base_dir>/<sanitized_session_id>/
├── execution.json                        # execution tree snapshot
└── nodes/
    ├── <sanitized_key>.json              # scalar values (merged on each save)
    └── <sanitized_key>.<field>.jsonl     # append-only list items (one JSON per line)
```

### `InterruptToken` / `InterruptTokenSource`

Cooperative interrupt mechanism shared across the entire execution tree.
Split into a read-only consumer interface (`InterruptToken`, in `agent/`) and
an owner that controls it (`InterruptTokenSource`, in `runtime/`).

**`InterruptToken`** (abc, `flowra.agent`) — consumer interface:
```python
class InterruptToken(abc.ABC):
    @property
    def interrupted(self) -> bool: ...   # Check if interrupted
    async def wait(self) -> None: ...    # Block until interrupted (returns immediately if already set)
```

**`InterruptTokenSource`** (`flowra.runtime`) — owner, creates token:
```python
class InterruptTokenSource:
    @property
    def token(self) -> InterruptToken: ...  # Read-only token for consumers
    def interrupt(self) -> None: ...        # Signal interrupt
    def clear(self) -> None: ...            # Reset (called automatically on completion)
```

**Usage in agents:**

Agents request `InterruptToken` via constructor injection (always available, like `AgentStore`
and `ServiceLocator`):

```python
from flowra.agent import Agent, InterruptToken, step

class LongRunningAgent(Agent):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step
    async def process(self) -> PartialResult | CompleteResult:
        processed = []
        for item in items:
            if self.interrupt.interrupted:
                return PartialResult(processed=processed)
            result = await process_item(item)
            processed.append(result)
        return CompleteResult(processed=processed)
```

**Signaling from outside:**
```python
# In another task/thread:
runtime.interrupt()  # Sets signal for all agents

# Agent checks interrupt.interrupted periodically
# Returns partial result or checkpoint state
# Runtime persists this state (if storage configured)
# On completion, runtime calls clear() to reset for next run()
```

**Properties:**
- Cooperative — agent must check `interrupt.interrupted` and handle gracefully
- Shared across all nodes (single interrupt token for entire execution tree)
- Agent decides what "graceful" means (save progress, return partial result, etc)
- Automatically cleared on successful completion (but not on exceptions, allowing resume)
- `wait()` is useful in tools — block until interrupted, e.g., to cancel a long-running operation

**Example with persistence:**

```python
from flowra.runtime import AgentRuntime
from flowra.runtime.storage import InMemorySessionStorage, FileSessionStorage

# In-memory (dev/test):
storage = InMemorySessionStorage()

# File-based (production):
storage = FileSessionStorage(base_dir="/var/data/agents", session_id="session-123")

runtime = AgentRuntime(
    agents={"worker": WorkerAgent},
    storage=storage,
    services={Database: db_connection},
)

# First run
result = await runtime.run(agent="worker", step="process")

# Later — resume from storage (in new process, after crash, etc)
runtime2 = AgentRuntime(agents={"worker": WorkerAgent}, storage=storage)
result = await runtime2.resume()
```

**Persistence contract:**

1. After each `advance()`, runtime opens a transaction via `storage.begin_transaction()`
2. Snapshot execution tree → `storage.save_execution(tree_snapshot)`
3. For each dirty node: serialize changes → `storage.save_node_state(storage_key, changeset)`
4. Transaction commits
5. Runtime calls `scope.mark_clean()` for all nodes (outside transaction)

On resume:
1. `storage.load_execution()` → deserialize specs/results → reconstruct tree structure
2. For each node: `storage.load_node_state(storage_key)` → deserialize → hydrate scope
3. Continue execution loop

### Serialization

The runtime automatically serializes all values before they reach storage and deserializes
on load. Storage implementations only deal with plain JSON-serializable dicts.

```python
serialize_value(value: Any, type_tags: dict[type, str]) -> Any          # domain object → JSON-serializable
deserialize_value(value: Any, type_registry: dict[str, type]) -> Any   # JSON-serializable → domain object
```

| Type                                                         | Serialization                                       |
|--------------------------------------------------------------|-----------------------------------------------------|
| Primitives (`str`, `int`, `float`, `bool`, `None`)           | Pass through                                        |
| `list`, `dict`                                               | Recurse                                             |
| `bytes`                                                      | `{"__bytes__": "<base64>"}`                         |
| `uuid.UUID`                                                  | `{"__uuid__": "<string>"}`                          |
| `datetime`                                                   | `{"__datetime__": "<isoformat>"}`                   |
| `date`                                                       | `{"__date__": "<isoformat>"}`                       |
| `time`                                                       | `{"__time__": "<isoformat>"}`                       |
| `Decimal`                                                    | `{"__decimal__": "<string>"}`                       |
| Dataclass (messages, blocks, `StepSpec`, `AgentResult`, ...) | `{"__type__": "<qualname>", "__data__": {fields}}` |

Dataclass serialization delegates field conversion to `marshmallow_recipe.dump()`/`load()`.

**Per-agent type registries:** Built at compile time by `compile_agent()`, stored in
`AgentDefinition.type_registry`. The compiler walks step signatures (`StepSpec`,
`AgentResult` subclasses) and slot annotations (`Scalar[T]`, `AppendOnlyList[T]`) to
discover all dataclass types. Unions, generic containers, and type aliases (PEP 695)
are resolved automatically.

At runtime, `AgentRuntime` builds `type_by_tag` and `tag_by_type` maps from each agent's
`type_registry`. Types are tagged with their `qualname` (e.g. `"TextBlock"`,
`"ChatResult"`). Each agent has its own registry — two agents can have same-named
types without conflict. Duplicate qualnames within a single agent raise `ValueError`.

Unregistered types cause `TypeError` at serialization time — there is no fallback.

## Execution model

### Execution lifecycle

High-level flow from `runtime.run()` to result:

**1. Initialization:**
- `AgentRuntime` resolves agent dict (reads pre-compiled `__agent_definition__` from `AbstractAgent` subclasses)
- Builds `Engine` with scope factory and services
- User calls `runtime.run(...)` with agent + step + optional spec

**2. Root creation:**
- `Engine.build_root()` creates root `ExecutionNode`
- Instantiates agent with fresh `RuntimeScope`
- Sets `pending_step` to entry step, status = `PENDING_STEP`

**3. Execution loop:**
```python
while True:
    result = await engine.advance(root)
    await persist_changes()      # Save dirty scopes + execution snapshot
    match result:
        case Completed(result=r):
            return r             # Done — clear execution snapshot, return result
        case Progressed():
            continue             # Keep advancing
```

**4. `Engine.advance()` mechanics:**
- **Propagate** completions from previous cycle (if all children done, parent → `PENDING_STEP` for join-step)
- **Collect** actionable nodes (status = `PENDING_STEP`)
- **Execute** all actionable steps in parallel (`asyncio.gather`)
- **Apply** results to nodes:
  - `AgentResult | None` → status = `COMPLETED`, store result
  - `Goto` → update `pending_step`, optionally create new scope (see scope semantics)
  - `Spawn` → create children, status = `WAITING_CHILDREN`
- **Return** `Completed(result)` or `Progressed()`

### Parallel execution

All `PENDING_STEP` nodes execute concurrently via `asyncio.gather`. This means spawned
children run in parallel within a single `advance()` call.

**Characteristics:**
- No coordination between children — they are independent
- Join-step receives `child_results: list[AgentResult]` (`None` results are filtered out)
- If a child also spawns, grandchildren execute in the next `advance()` call

### Scope semantics

How `Goto` and `Call` (via `Spawn`) affect scope creation. `Goto` transitions the current
node to a different step (or agent). `Call` creates a child node via `Spawn`.

**Goto:**

| Condition                           | Scope behavior                              |
|-------------------------------------|---------------------------------------------|
| Same agent, no `storage_key`        | Keep current scope                          |
| Same agent, `storage_key=NEW_SCOPE` | Fresh scope (auto-generated key)            |
| Same agent, `storage_key="custom"`  | Fresh scope (if different from current key) |
| Cross-agent (any `storage_key`)     | Fresh scope                                 |

**Call (via Spawn):**

| Condition                            | Scope behavior                                        |
|--------------------------------------|-------------------------------------------------------|
| Same agent, no `storage_key`         | Fork parent scope (copy scalars + lists, independent) |
| Same agent, `storage_key=NEW_SCOPE`  | Fresh scope (auto-generated key)                      |
| Same agent, `storage_key="custom"`   | Fresh scope                                           |
| Cross-agent (any `storage_key`)      | Fresh scope                                           |

**Fork behavior:**
- Copies all scalar values (snapshot)
- Copies all list contents (snapshot)
- Child scope is fully independent — mutations don't affect parent
- No flush callback, no dirty state — child starts clean

## Internals

### `ExecutionNode`

Mutable node in the execution tree. Each node represents a running agent instance.

```python
@dataclasses.dataclass(slots=True, kw_only=True)
class ExecutionNode:
    node_id: str                                       # Unique hierarchical ID
    storage_key: str | None                            # Persistence key
    agent_name: str                                    # Agent type name
    defn: AgentDefinition                              # Agent definition (compiled)
    instance: AgentInstance                            # Agent instance
    scope: RuntimeScope                                # State scope
    status: ExecutionStatus                            # Current status
    pending_step: str | None = None                    # Next step to execute
    pending_spec: StepSpec | None = None               # Spec for next step
    children: list[ExecutionNode] | None = None        # Spawned children
    child_results: list[ChildResult] | None = None     # Completed child results
    then_step: str | None = None                       # Join-step tag
    result: AgentResult | None = None                  # Final result
    goto_counter: int = 0                              # Auto-generated storage_key counter
    parent: ExecutionNode | None = None                # Parent node
```

### `ChildResult`

Wraps a child agent's result with the agent name that produced it. Used for
per-agent type registry lookup during serialization/deserialization.

```python
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChildResult:
    agent_name: str
    result: AgentResult
```

### `ExecutionStatus`

```python
class ExecutionStatus(enum.StrEnum):
    PENDING_STEP = "pending_step"           # Ready to execute pending_step
    WAITING_CHILDREN = "waiting_children"   # Blocked on child completion (Spawn)
    COMPLETED = "completed"                 # Finished with result
```

### `Engine`

Low-level execution engine. Drives the execution tree through state transitions.
Most users interact with `AgentRuntime` — direct `Engine` use is rarely needed.

```python
class Engine:
    def __init__(
        self,
        registry: AgentRegistry,
        scope_factory: ScopeFactory,
        instance_factory: InstanceFactory,
        services: dict[type, Any] | None = None,
        scope_restore: ScopeRestoreCallback | None = None,
    ): ...

    async def build_root(
        self,
        agent: str,
        step: str,
        spec: StepSpec | None = None,
        *,
        storage_key: str | None = None,
        node_id: str = "root",
    ) -> ExecutionNode: ...

    async def advance(self, root: ExecutionNode) -> AdvanceResult: ...

    def register_live_storage_keys(self, root: ExecutionNode) -> None: ...
```

**`advance()` return type:**

```python
type AdvanceResult = Completed | Progressed

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Completed:
    result: AgentResult | None

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Progressed:
    pass  # Execution advanced but not complete
```

### `RuntimeScope`

State container for an agent node. Implements both `AgentStore` (flush) and
`ServiceLocator` (service provision and access).

**State management:**
```python
scope.create_scalar(key)        # → Scalar — mutable with dirty tracking
scope.create_append_only(key)   # → AppendOnlyList — append-only
```

**Service propagation:**
```python
scope.provide(service_type, instance)   # Register service for children
scope.services                          # All services in current scope (parent + local)
scope.get_services()                    # Same as services property
scope.get_inherited_services()          # Parent services only (for sibling agents via Goto)
```

**Persistence:**
```python
scope.get_changes()          # ChangeSet (dirty scalars + unflushed appends)
scope.mark_clean()           # Reset dirty flags (after save)
scope.snapshot()             # Full state dict
scope.hydrate(data)          # Restore from snapshot (fields must already be declared; unknown keys are logged and skipped)
scope.set_flush_callback(cb) # Set callback for explicit flush
```

**Forking:**
```python
child_scope = scope.fork(parent_services={...})
```

### Type aliases

```python
type ScopeFactory = Callable[[dict[type, Any]], RuntimeScope]
```
Factory that creates `RuntimeScope` with parent services.

```python
type InstanceFactory = Callable[[AgentDefinition, RuntimeScope, dict[type, Any]], AgentInstance]
```
Factory that creates an agent instance from definition, scope, and services.

```python
type ScopeRestoreCallback = Callable[[RuntimeScope, str | None, str, str], Awaitable[None]]
```
Callback to hydrate scope from storage. Parameters: `scope`, `storage_key`, `node_id`, `agent_name`.

```python
type FlushCallback = Callable[[], Awaitable[None]]
```
Callback invoked by `RuntimeScope.flush()` when called by agent.

### Internal design notes

**Why Engine is separate from AgentRuntime:**
- `Engine` — pure execution logic (no persistence, no public services)
- `AgentRuntime` — orchestration layer (persistence, DI, public API, resume)
- Separation allows testing execution logic independently

**Why storage keys matter:**
- Same `storage_key` → resume from same persisted state across runs
- Different `storage_key` → fresh independent state
- `None` → ephemeral node (still persisted under `node_id` for crash recovery, but no cross-run continuity)
- Uniqueness enforced: duplicate active key → `ValueError` (prevents state collision)
