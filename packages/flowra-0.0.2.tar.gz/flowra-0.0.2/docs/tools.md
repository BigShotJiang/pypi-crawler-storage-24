# Package `flowra.tools`

Tool definition, grouping, registration, and execution — for local Python functions
and remote MCP (Model Context Protocol) servers.

```
flowra/tools/
├── types.py            # ToolDefinition, ToolResult
├── local_tool.py       # @tool decorator, LocalTool, ToolInput, ToolService
├── tool_group.py       # LocalToolGroup, McpToolGroup, create_local_tool_group
├── tool_registry.py    # ToolRegistry
└── mcp_connection.py   # McpConnection (MCP Streamable HTTP transport)
```

## Quick start

```python
import dataclasses
from flowra.tools import ToolRegistry, create_local_tool_group, tool

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SearchParams:
    query: str

@tool("search")
def search(params: SearchParams) -> str:
    """Search the knowledge base."""
    return f"Results for: {params.query}"

group = create_local_tool_group([search], prefix="kb")

# create() is async and returns an async context manager
async with await ToolRegistry.create([group]) as registry:
    tools = registry.get_tools()           # list[ToolDefinition]
    result = await registry.execute(
        "kb__search", {"query": "hello"},  # prefix + "__" + tool name
    )
    print(result.content)                  # "Results for: hello"
    print(result.is_error)                 # False
```

## Types

### `ToolDefinition`

Describes a tool. Shared between local tools and MCP tools.

| Field           | Type                     | Default |
|-----------------|--------------------------|---------|
| `name`          | `str`                    | —       |
| `description`   | `str`                    | —       |
| `input_schema`  | `dict[str, Any] \| None` | `None`  |
| `output_schema` | `dict[str, Any] \| None` | `None`  |

### `ToolResult`

Result of tool execution.

| Field      | Type   | Default |
|------------|--------|---------|
| `content`  | `str`  | —       |
| `is_error` | `bool` | `False` |

## Defining local tools

### `@tool` decorator

Turns a Python function into a tool. Derives input/output schemas from dataclass
type annotations using `marshmallow_recipe` (a project dependency for
dataclass ↔ JSON Schema conversion).

```python
@tool("calculate", description="Evaluate a math expression")
def calculate(params: CalculateParams) -> str:
    # Use a safe evaluator — never pass LLM output to eval()
    return eval_expression(params.expression)
```

- `name` — tool identifier, must match `^[a-zA-Z0-9_-]+$`
- `description` — taken from docstring if not passed explicitly (`ValueError` if neither is provided)
- Every parameter must have a type annotation
- A single dataclass parameter is treated as tool input (its fields become the JSON Schema)
- All other parameters are **services** — injected by matching the parameter's type annotation
  against `ToolExecutionContext.services` (see [Service injection](#service-injection))
- Both sync and async functions are supported
- If the return type is a dataclass, `output_schema` is automatically derived from it

### `get_local_tool`

Extracts the `LocalTool` from a `@tool`-decorated function. Raises `ValueError` if the
function is not decorated.

```python
from flowra.tools import get_local_tool, tool

@tool("ping")
def ping() -> str:
    """Ping."""
    return "pong"

local_tool = get_local_tool(ping)  # LocalTool
```

### `LocalTool`

The object created by `@tool`. Usually you don't construct it manually — use the decorator
and `get_local_tool()` to extract it.

| Field        | Type             | Description                    |
|--------------|------------------|--------------------------------|
| `definition` | `ToolDefinition` | Tool metadata and schema       |
| `handler`    | `ToolHandler`    | The callable that executes it  |

### `ToolHandler`

Type alias for the handler callable:

```python
type ToolHandler = Callable[[ToolExecutionContext], ToolResult | Awaitable[ToolResult]]
```

### `ToolExecutionContext`

Passed to the handler at execution time:

| Field      | Type              | Default | Description                                                                                            |
|------------|-------------------|---------|--------------------------------------------------------------------------------------------------------|
| `input`    | `dict[str, Any]`  | —       | Parsed tool arguments                                                                                  |
| `services` | `dict[type, Any]` | —       | Dependency injection container — maps service types to instances ([details below](#service-injection)) |

### Disambiguation with `ToolInput` and `ToolService`

When a tool has multiple dataclass parameters, the decorator can't tell which is the input.
Use `Annotated` with markers to disambiguate:

```python
from typing import Annotated
from flowra.tools import ToolInput, ToolService, tool

@tool("fetch")
def fetch(
    params: Annotated[FetchParams, ToolInput],
    config: Annotated[ApiConfig, ToolService],
) -> str:
    """Fetch a URL using config."""
    ...
```

`ToolInput` — marks the tool input parameter (the one that maps to JSON Schema).
`ToolService` — marks a DI service parameter.

Without any markers, a single dataclass parameter is automatically treated as input,
everything else as a service. Multiple unmarked dataclass parameters raise `TypeError`
at decoration time.

### Service injection

Non-input parameters are resolved from `ToolExecutionContext.services` by their type
annotation. When calling `ToolRegistry.execute()`, pass services via the `services`
keyword argument:

```python
class ApiClient:
    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

@tool("fetch")
def fetch(params: FetchParams, client: ApiClient) -> str:
    """Fetch data using the API client."""
    return f"{client.base_url}/{params.path}"

# At execution time:
result = await registry.execute(
    "fetch",
    {"path": "users"},
    services={ApiClient: ApiClient(base_url="https://api.example.com")},
)
```

### Optional services

A service parameter typed as `T | None` becomes optional — if the service is not
registered, `None` is passed instead of raising:

```python
@tool("fetch")
def fetch(params: FetchParams, cache: CacheService | None) -> str:
    """cache is None if CacheService is not registered."""
    ...
```

Works with or without the `ToolService` marker.

### Return value serialization

The tool handler's return value is serialized to `ToolResult.content` (always a string):

| Return type   | Serialization                                                                                          |
|---------------|--------------------------------------------------------------------------------------------------------|
| `str`         | As-is                                                                                                  |
| `dict`        | `json.dumps(result)`                                                                                   |
| `list`        | `json.dumps(result)` (if the first element is a dataclass, all elements are serialized field-by-field) |
| Dataclass     | `json.dumps(marshmallow_recipe.dump(result))`                                                          |
| Anything else | `str(result)`                                                                                          |

## Grouping tools

### `LocalToolGroup`

Groups local tools under an optional prefix:

```python
group = LocalToolGroup(tools=[local_tool_1, local_tool_2], prefix="math")
```

| Field    | Type              | Default |
|----------|-------------------|---------|
| `prefix` | `str \| None`     | `None`  |
| `tools`  | `list[LocalTool]` | —       |

Duplicate tool names within a group raise `ValueError` at construction time.

### `create_local_tool_group`

Convenience — extracts `LocalTool` from `@tool`-decorated handlers:

```python
group = create_local_tool_group([search, calculate], prefix="utils")
```

### `McpToolGroup`

Points to a remote MCP server. Tools are fetched at connection time.

```python
McpToolGroup(url="https://mcp.example.com/mcp", prefix="google")
McpToolGroup(url="https://mcp.example.com/mcp", prefix="private", headers={"Authorization": "Bearer ..."})
```

| Field     | Type                     | Default |
|-----------|--------------------------|---------|
| `prefix`  | `str \| None`            | `None`  |
| `url`     | `str`                    | `""`    |
| `headers` | `dict[str, str] \| None` | `None`  |

### `ToolGroup` and `ToolSource`

Type aliases:

```python
type ToolGroup = LocalToolGroup | McpToolGroup
type ToolSource = ToolGroup | LocalTool
```

`ToolSource` is the input type for `ToolRegistry.create()`. Bare `LocalTool` objects
are accepted without wrapping in a group (registered without prefix).

## `ToolRegistry`

Unified registry that owns tool groups and MCP connections. Manages the full lifecycle:
connects to MCP servers on creation, closes all connections on `close()` / `async with` exit.

```python
async with await ToolRegistry.create([group1, group2]) as registry:
    tools = registry.get_tools()
    result = await registry.execute("prefix__tool_name", {"key": "value"})
```

### `create(tool_sources)`

Connects to MCP servers, registers local tools, returns the registry.

Duplicate local tool names raise `ValueError`. MCP tool name conflicts are logged and
skipped without raising (first registration wins).

### `get_tools() -> list[ToolDefinition]`

Returns tool descriptors for all registered tools (local and MCP).

### `get_llm_tools() -> list[Tool]`

Converts registered tool definitions to `flowra.llm.Tool` objects suitable
for passing to `LLMRequest.tools`. Preserves `output_schema`.

### `execute(name, args=None, *, services=None) -> ToolResult`

Executes a tool by its prefixed name. Exceptions are caught and returned as
`ToolResult(content="Error: ...", is_error=True)`.

### `close()`

Removes MCP change callbacks and closes all connections. Also called by `async with`.

### Tool name prefixing

Tools are registered under `<prefix>__<tool_name>` (double underscore separator).
Without a prefix, the tool keeps its plain name.

### Live MCP updates

When an MCP server's tool list changes, the registry rebuilds automatically
via `McpConnection`'s change callback. No manual refresh needed.

## `McpConnection`

Low-level MCP Streamable HTTP transport (JSON-RPC 2.0) built on `httpx` + `asyncio`.
Most users interact with MCP tools through `ToolRegistry` — direct use is rarely needed.

- Handshake: `initialize` → `notifications/initialized` → `tools/list`
- Auto-reconnect on HTTP/connection errors (one retry)
- Background refresh: event-driven with a 60-second fallback poll of `tools/list`
- Tracks tool removals (`invalid_params` errors or "unknown tool" responses)
- SSE support for streaming JSON-RPC responses
- Change callbacks: `add_on_tools_changed()` / `remove_on_tools_changed()`

```python
async with await McpConnection.connect(url, headers) as conn:
    tools = conn.get_tools()                      # list[ToolDefinition]
    result = await conn.call_tool("search", {...}) # ToolResult
```
