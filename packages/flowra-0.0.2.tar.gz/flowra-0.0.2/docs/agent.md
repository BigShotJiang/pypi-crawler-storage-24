# Package `flowra.agent`

Define agents as step-based state machines. Each agent is a Python class whose methods
(decorated with `@step`) form the states; returning `Goto`, `Spawn`, or an `AgentResult`
(all explained below) controls transitions between them.

```
flowra/agent/
├── agent.py           # Agent(AbstractAgent) — base class with auto-compilation
├── step_decorator.py  # @step decorator
├── agent_def.py       # Control flow (Goto, Call, Spawn), type aliases, resolve functions
├── agent_store.py     # AgentStore (ABC) — flush interface
├── service_locator.py # ServiceLocator (ABC) — service provision and access
├── interrupt_token.py  # InterruptToken (ABC) — cooperative interrupt interface
├── interrupt_helpers.py # with_interrupt() — race async iterators against InterruptToken
├── agent_registry.py  # AgentRegistry — hierarchical agent name/type resolution
├── stored_values.py   # Scalar[T], AppendOnlyList[T], slot() — dirty-tracked state containers
└── compile.py         # compile_agent() — introspection, slot discovery, type registry
```

## Quick start

```python
import dataclasses
from flowra.agent import Agent, AgentResult, StepSpec, step

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetSpec(StepSpec):
    name: str

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetResult(AgentResult):
    greeting: str

class Greeter(Agent):
    @step
    async def greet(self, spec: GreetSpec) -> GreetResult:
        return GreetResult(greeting=f"Hello, {spec.name}!")
```

This defines a single-step agent. `GreetSpec` is the input, `GreetResult` is the output.
Returning an `AgentResult` subclass completes the agent. The snippet above is valid Python but
produces no output on its own — to execute agents, use the `runtime` package (`AgentRuntime`):

```python
from flowra.runtime import AgentRuntime

runtime = AgentRuntime(agents={"greeter": Greeter})
result = await runtime.run(agent=Greeter, step=Greeter.greet, spec=GreetSpec(name="World"))
print(result.greeting)  # "Hello, World!"
```

## Steps and the `@step` decorator

A **step** is a method that represents one state of the agent's state machine.
Steps can be either synchronous (`def`) or asynchronous (`async def`).
The runtime calls steps one at a time: it invokes a step, receives its return value,
and uses that to decide what to do next (transition to another step, spawn children,
or complete the agent).

### `@step`

Marks a method as an agent step.

A **tag** is the string name that identifies a step. It is used for persistence, control-flow
references (`Goto`, `Call`), and step overriding. By default, the tag is the method name:

```python
@step                # tag = method name ("process")
async def process(self) -> MyResult: ...

@step("custom_tag")  # tag = "custom_tag"
def process(self) -> MyResult: ...

@step()              # tag = method name ("process")
async def process(self) -> MyResult: ...
```

If a step's return type annotation contains a concrete type that is not `Goto | Spawn | AgentResult | None`,
a `TypeError` is raised at class definition time (when `Agent.__init_subclass__` fires).
PEP 695 type aliases (`type X = A | B`) are resolved automatically, including nested aliases.

### `StepSpec`

Base class for step input data. Subclass to define domain-specific fields.

```python
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class UserInput(StepSpec):
    text: str
```

### `AgentResult`

Base class for agent output. Returning an `AgentResult` subclass from a step completes the agent. Returning `None`
also completes the agent (with no result value).

```python
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GreetResult(AgentResult):
    greeting: str
```

### Concrete types required

Step return type annotations **must use concrete subclasses** of `AgentResult`,
not the base class itself. Similarly, `StepSpec` parameters must use concrete subclasses.
The compiler inspects these annotations to determine which spec to inject, which
child results to match, and which result types to register for serialization.
Using abstract base classes raises `TypeError` at compilation time.

`AgentResult` and `list[AgentResult]` in parameters are allowed as "accept any
child result" wildcards for forwarding patterns.

```python
# GOOD — concrete types:
@step
async def run(self, spec: UserInput) -> GreetResult: ...

# GOOD — AgentResult / list[AgentResult] as child result wildcard:
@step
async def forward(self, cr: list[AgentResult]) -> DoneResult | QuitResult:
    return cr[0]

# BAD — abstract StepSpec param, raises TypeError:
@step
async def run(self, spec: StepSpec) -> GreetResult: ...

# BAD — abstract AgentResult return type, raises TypeError:
@step
async def run(self, spec: UserInput) -> AgentResult: ...
```

## Defining agents

### `Agent`

Base class for agent implementations. When you subclass `Agent`, the framework
automatically scans for `@step`-decorated methods and compiles them into an
`AgentDefinition` (stored as `cls.__agent_definition__`).

```python
class MyAgent(Agent):
    counter: Scalar[int] = slot("counter")

    @step
    async def start(self, spec: MySpec) -> Goto:
        self.counter.set(self.counter.get(0) + 1)
        return Goto(step=self.process, spec=ProcessSpec(data=spec.value))

    @step
    async def process(self, spec: ProcessSpec) -> MyResult:
        return MyResult(answer=spec.data)
```

Subclasses inherit steps from parents (MRO order). A child can override a step
by defining a new method with the same `@step` tag — the match is by tag string,
not by method name.

## Control flow

Steps return one of: `Goto`, `Spawn`, an `AgentResult` subclass, or `None`.

- **`Goto`** — transition to another step: the current step ends, the next step
  begins (in the same agent or a different one)
- **`Spawn`** — fork multiple children to run in parallel, then reconvene at a join step
- **`AgentResult`** — complete the agent and return a result to the caller
- **`None`** — complete the agent with no result

**Storage scopes.** Each agent execution has a **storage key** — an identifier for its
isolated set of stored values (`Scalar`, `AppendOnlyList` — defined in [State management](#state-management)).
`Goto` and `Call` accept an optional `storage_key` to control which storage the target
step uses (see tables below for details).

### `Goto`

Transition to another step, optionally in a different agent.

The field tables below show **constructor parameter types** (what you pass in). The
stored fields after construction are always `str` (resolved tag) for `step`.

| Field         | Type                                    | Default |
|---------------|-----------------------------------------|---------|
| `step`        | `str \| StepMethod`                     | —       |
| `agent`       | `str \| type[AbstractAgent] \| None`    | `None`  |
| `spec`        | `StepSpec \| None`                      | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None`              | `None`  |

`step` accepts a tag string (`"process"`) or a `@step`-decorated method reference
(`self.process`, `OtherAgent.process`). `agent` accepts an agent name string or
an agent class (any subclass of `AbstractAgent`).

```python
# Same agent (bound method — agent is inferred from self):
Goto(step="process")
Goto(step=self.process)

# Cross-agent (agent must be specified explicitly):
Goto(agent=OtherAgent, step="run")               # runtime auto-generates storage key
Goto(agent="other", step="run")
Goto(agent=OtherAgent, step="run", storage_key="calc")  # explicit reusable key

# Fresh storage within same agent:
Goto(step=self.reset, storage_key=NEW_SCOPE)
```

| Method type                 | `agent` parameter                                                       |
|-----------------------------|-------------------------------------------------------------------------|
| Bound (`self.step`)         | Optional — the runtime resolves the agent from the bound instance later |
| Unbound (`OtherAgent.step`) | Required — `TypeError` if omitted                                       |

**`storage_key`** controls which persistent state the target step uses. Each unique
key corresponds to an isolated set of stored values (`Scalar`, `AppendOnlyList`).
When the runtime starts a step with a given storage key, it loads (hydrates) the
stored values from persistent storage for that key. Use an explicit key when you
want to resume a named agent instance rather than start a fresh one:

| `storage_key` value   | Same agent               | Different agent            |
|-----------------------|--------------------------|----------------------------|
| `None` (default)      | Keep current storage     | Auto-generate unique key   |
| `"explicit"`          | Switch to that key       | Use that key               |
| `NEW_SCOPE`           | Auto-generate unique key | Auto-generate unique key   |

`NEW_SCOPE` is a sentinel value that forces a fresh storage scope.

### `Call`

Describe a child to spawn (used inside `Spawn.children`). `Spawn` requires `Call`
rather than `Goto` because it needs to track multiple parallel child executions, each
with its own state — `Goto` replaces the current step, while `Call` creates a new child.

| Field         | Type                                    | Default |
|---------------|-----------------------------------------|---------|
| `step`        | `str \| StepMethod`                     | —       |
| `agent`       | `str \| type[AbstractAgent] \| None`    | `None`  |
| `spec`        | `StepSpec \| None`                      | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None`              | `None`  |

```python
# Same agent:
Call(step="compute", spec=TaskSpec(id=1))
Call(step=self.compute, spec=TaskSpec(id=1))

# Same agent with own persistent state:
Call(step=self.compute, storage_key="worker-1")

# Cross-agent:
Call(agent=WorkerAgent, step="process", spec=TaskSpec(id=1))
Call(agent="calc", step="compute", storage_key="calc")
```

**Child state behavior:**

| Scenario                         | State behavior                                              |
|----------------------------------|-------------------------------------------------------------|
| Same agent, no `storage_key`     | Copy of parent's state — mutations do not affect the parent |
| Same agent, with `storage_key`   | Independent state — loaded from own persistent storage      |
| Different agent                  | Independent state — loaded from own persistent storage      |

Same-agent children without `storage_key` get a full copy (new `Scalar`/`AppendOnlyList`
instances initialized with the parent's current values). This is useful for parallel
workers that need context from the parent but should not modify the parent's state.

### `Spawn`

Fork child agents, then reconvene at a join step.

The table below shows **constructor parameter types**. The stored `then` field
is always `str` (the resolved tag), same as `Goto.step` and `Call.step`.

| Field      | Type                  | Default |
|------------|-----------------------|---------|
| `children` | `list[Call]`          | —       |
| `then`     | `str \| StepMethod`   | —       |

All children execute in parallel. When all complete,
their results are collected and passed to the `then` step via parameter injection
(see [Step parameter injection](#step-parameter-injection) below).

Unlike `Goto` and `Call`, `Spawn.then` does not require an explicit `agent` parameter
for unbound methods — it only needs the step tag, not the agent reference.

```python
@step
async def dispatch(self) -> Spawn:
    return Spawn(
        children=[
            Call(agent=WorkerAgent, step="run", spec=TaskSpec(id=1)),
            Call(agent=WorkerAgent, step="run", spec=TaskSpec(id=2)),
        ],
        then=self.collect,
    )

@step
async def collect(self, results: list[WorkerResult]) -> MyResult:
    # results — all child results of type WorkerResult, injected by the runtime
    total = sum(r.value for r in results)
    return MyResult(total=total)
```

The `then` step receives child results through parameter injection: declare a parameter
typed as `list[SomeResult]` to receive all child results of that type, or a single
`SomeResult` to receive the first match.

## Subagents

Agents can declare internal helper agents using the `__subagents__` class variable.
Subagents are automatically registered in the runtime with namespaced names
(e.g., if the parent is `"loop"`, a subagent named `"tool_call"` becomes
`"loop/tool_call"`).

```python
class ToolCallAgent(Agent):
    @step
    async def execute(self) -> ToolCallResult:
        ...

class ToolLoopAgent(Agent):
    __subagents__ = {
        "tool_call": ToolCallAgent,
    }

    @step
    async def execute_tools(self) -> Spawn:
        return Spawn(
            children=[Call(agent=ToolCallAgent, step=ToolCallAgent.execute)],
            then=self.collect,
        )
```

Nested subagents work recursively (e.g., `"parent/child/grandchild"`).

`__subagents__` is inherited via MRO: a subclass that does not redeclare it
inherits the parent's subagent map. Override with `__subagents__ = {}` to clear.

**Referencing subagents** — four ways:

```python
Call(agent=ToolCallAgent, step=ToolCallAgent.execute)  # by type (contextual resolution)
Call(agent="./tool_call", step="execute")               # relative — my child
Call(agent="../sibling", step="execute")                # relative — my sibling
Call(agent="loop/tool_call", step="execute")            # absolute name
```

**Type-based resolution** walks the agent hierarchy from the current agent upward to root,
so a parent agent can reference its own subagent type without knowing its registration name.
The same class can be a subagent of multiple parents without conflict — each parent resolves
it to its own namespace.

**Relative paths** use Unix-style syntax:
- `"./child"` — my child subagent
- `"../sibling"` — sibling (go up one level, then down)
- `"../../uncle"` — go up two levels

E.g., if the current agent is `"parent/child"`, then `"./gc"` resolves to
`"parent/child/gc"` and `"../sibling"` resolves to `"parent/sibling"`.

**Name validation:** Agent names must match `[a-zA-Z0-9_-]+` (slashes are reserved for
hierarchy separators).

**Note:** Duplicate agent classes at the same hierarchy level raise `ValueError`.

## State management

Agents persist state across steps using **stored values** — mutable containers declared
as class attributes via the `slot()` sentinel. The runtime automatically saves dirty values
at step boundaries. You can also flush manually mid-step via `AgentStore.flush()`.

### Declaring slots

Slots are declared **declaratively** as class attributes using `slot(key)`:

```python
from flowra.agent import Agent, AppendOnlyList, Scalar, slot, step

class MyAgent(Agent):
    counter: Scalar[int] = slot("counter")
    log: AppendOnlyList[str] = slot("log")

    @step
    async def work(self) -> ...:
        self.counter.set(self.counter.get(0) + 1)
        self.log.append(f"step {self.counter.get()}")
```

`slot(key)` returns a `SlotMarker` sentinel. At compilation time, the compiler reads
class annotations to discover all slots and their types (`Scalar[T]` or `AppendOnlyList[T]`).
At runtime, the actual containers are created and injected into the agent instance
before the first step executes.

**Slots are not available in the constructor.** Calling `.get()`, `.set()`, `.has_value()`,
or any other method on a slot inside `__init__` raises `RuntimeError`. Use slot values
in step methods instead. For scalars that need a default, use `get(default)` in the step.

The annotation must be `Scalar[T]` or `AppendOnlyList[T]` — bare `Scalar` or other
types raise `TypeError` at compilation time.

A new `Scalar` starts **unset** — it holds no value until explicitly set via `set()`
or `restore()`. Use `get(default)` to provide an explicit fallback for unset scalars.

```python
class MyAgent(Agent):
    counter: Scalar[int] = slot("counter")
    name: Scalar[str] = slot("name")
    config: Scalar[dict[str, int]] = slot("config")

    @step
    async def work(self) -> ...:
        self.counter.get(0)        # returns 0 if unset
        self.name.get("")          # returns "" if unset
        self.counter.get()         # raises LookupError if unset
```

### `AgentStore`

Minimal interface for flushing state mid-step. The runtime provides the implementation
and injects it into the agent's `__init__`.

| Method    | Description                                                  |
|-----------|--------------------------------------------------------------|
| `flush()` | Persist dirty state immediately, without waiting for step end |

### `flush()`

`flush()` persists dirty state immediately, without waiting for a step boundary.

**Caution:** after `flush()`, state is persisted but the step continues running. If the
step crashes after a flush, on resume the step will re-execute from the beginning with the
already-flushed state. The step must handle this correctly — check whether data was already
written before writing again. See `ToolLoopAgent.start` for an example of this pattern
(`if not self.__turn_messages.get_all()` guard).

```python
from flowra.agent import Agent, AgentStore, Scalar, slot, step

class MyAgent(Agent):
    progress: Scalar[str] = slot("progress")

    def __init__(self, store: AgentStore) -> None:
        self.store = store

    @step
    async def process(self) -> MyResult | None:
        self.progress.set("halfway")
        await self.store.flush()  # persist now, don't wait for step end
        # ... continue processing ...
```

### `Scalar[T]`

Mutable scalar with dirty tracking. Only changed values are persisted.

```python
self.counter.set(self.counter.get(0) + 1)
```

| Method                | Description                                                       |
|-----------------------|-------------------------------------------------------------------|
| `get(default?) -> T`  | Value if set; `default` if provided; `LookupError` otherwise      |
| `has_value() -> bool` | Whether the scalar holds a value                                  |
| `set(value)`          | Set the value, mark dirty                                         |
| `is_dirty()`          | Whether the value changed since last clean                        |
| `mark_clean()`        | Reset dirty flag                                                  |
| `restore(v)`          | Replace value and reset dirty flag (for persistence restore)      |

### `AppendOnlyList[T]`

Append-only list with incremental persistence — only newly appended items are written
on each save.

```python
self.messages.append(new_message)
self.messages.extend([msg1, msg2])
all_messages = self.messages.get_all()
```

| Method              | Description                                                             |
|---------------------|-------------------------------------------------------------------------|
| `get_all() -> list` | All items                                                               |
| `append(item)`      | Append one item and mark as unflushed                                   |
| `extend(items)`     | Append multiple items and mark as unflushed                             |
| `get_unflushed()`   | Items appended since last clean                                         |
| `mark_clean()`      | Reset unflushed counter                                                 |
| `restore(items)`    | Replace all items and reset unflushed counter (for persistence restore) |

## Services: `ServiceLocator`

Interface for service provision and access. The runtime provides the implementation and injects
it into the agent's `__init__` (via the same DI mechanism as `AgentStore`).

"Sealed" means the method can only be called during `__init__` — after construction, the
runtime locks it and further calls raise an error. This prevents accidental mutation mid-step.

| Method / Property         | Sealed | Description                                                          |
|---------------------------|--------|----------------------------------------------------------------------|
| `provide(type[T], instance: T)` | yes | Register a typed service for descendant agents (runtime `isinstance` check) |
| `services` (property)     | no     | All services available in the current scope (`dict[type, Any]`)      |

`provide()` registers a service that is propagated to all descendant agents
(children, grandchildren, etc.). The call is generic and type-safe — the runtime
verifies `isinstance(instance, service_type)` and raises `TypeError` on mismatch.
Descendants receive the service through constructor injection:

```python
# Parent registers a service:
class ParentAgent(Agent):
    def __init__(self, services: ServiceLocator, my_service: MyService) -> None:
        services.provide(MyService, my_service)

# Child (and grandchild) receives it automatically:
class ChildAgent(Agent):
    def __init__(self, my_service: MyService) -> None:
        self.service = my_service
```

## Cooperative interrupts: `InterruptToken`

Read-only interrupt interface. The runtime always provides `InterruptToken` — agents
request it via constructor injection (same as `AgentStore` and `ServiceLocator`).

| Method / Property        | Description                                                                 |
|--------------------------|-----------------------------------------------------------------------------|
| `interrupted` (property) | Whether interrupt was signaled                                              |
| `wait()`                 | Block until interrupted. Returns immediately if already interrupted.        |

The interrupt is cooperative: the runtime sets the flag (via `runtime.interrupt()`),
but the agent must check `interrupt.interrupted` and decide to return early. If the
agent ignores the flag, execution continues normally.

```python
from flowra.agent import Agent, InterruptToken, Scalar, slot, step

class MyAgent(Agent):
    progress: Scalar[str] = slot("progress")

    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step
    async def process(self) -> MyResult | None:
        self.progress.set("halfway")
        if self.interrupt.interrupted:
            return MyResult(partial=True)
        # ... continue processing ...
```

### `with_interrupt` — racing async iterators

`with_interrupt` wraps any `AsyncIterator[T]` so it exits immediately when
the token fires — even if `__anext__()` is blocked on I/O:

```python
from flowra.agent import InterruptToken, with_interrupt

async def consume(stream: AsyncIterator[str], token: InterruptToken) -> list[str]:
    items = []
    async for item in with_interrupt(stream, token):
        items.append(item)
    return items  # partial results if interrupted
```

On each iteration, `__anext__()` and `token.wait()` are raced via
`asyncio.wait(FIRST_COMPLETED)`. If the token wins, the underlying iterator
is closed (`aclose()`) and the wrapper ends. This is used internally by
`ToolLoopAgent` to interrupt LLM streaming immediately.

## Dependency injection

### Constructor injection

When a subclass of `Agent` is compiled, its `__init__` parameters are inspected.
The runtime injects values by matching parameter type annotations:

- **Built-in services** (always available, no registration needed):

  | Service            | Purpose                                           | Sealed after construction |
  |--------------------|---------------------------------------------------|---------------------------|
  | `AgentStore`       | `flush()` — persist dirty state mid-step          | — (never sealed) |
  | `ServiceLocator`   | Register services (`provide`), access `services` dict  | `provide` — yes; `services` — no |
  | `InterruptToken`   | Check `interrupted`, `wait()` for cooperative stop     | — (read-only, never sealed) |

- Other types are resolved from the runtime's `services` dict or from parent
  agents via `ServiceLocator.provide()`

```python
class MyAgent(Agent):
    counter: Scalar[int] = slot("counter")

    def __init__(self, services: ServiceLocator, provider: LLMProvider) -> None:
        self.services = services
        self.provider = provider
```

If a parameter's type is not found in the available services, the runtime does not
supply that parameter. The parameter must have a default in the signature, otherwise
Python raises `TypeError` when the constructor is called. Parameters typed as
`X | None` are also supported — the runtime looks up `X` in the services dict.

**Note:** Service lookup uses exact type matching. If you register `MyService`, a
parameter typed as a superclass of `MyService` will not match — use the exact type.

### Step parameter injection

Step method parameters are injected by type:

| Parameter type                      | Injected value                                   |
|-------------------------------------|--------------------------------------------------|
| Subclass of `StepSpec`              | The spec passed to the step                      |
| Subclass of `AgentResult`           | First child result matching that exact type       |
| Union of `AgentResult` subclasses   | First child result matching any type in the union |
| `list[SubclassOfAgentResult]`       | All child results of that type                   |
| `list[UnionOfAgentResultSubclasses]`| All child results matching any type in the union |

Union types and type aliases are supported in child result parameters:

```python
type AnyWorkerResult = CalcResult | EchoResult

@step
async def join(self, spec: MySpec, results: list[WorkerResult]) -> MyResult:
    # results — all child results of type WorkerResult (from Spawn children)
    ...

@step
async def collect(self, results: list[CalcResult | EchoResult]) -> MyResult:
    # results — all child results matching CalcResult or EchoResult
    ...

@step
async def collect_alias(self, results: list[AnyWorkerResult]) -> MyResult:
    # same as above — type alias is resolved automatically
    ...
```

If a step parameter's type does not match any injection source, the runtime does
not supply that parameter. The parameter must have a default, otherwise Python
raises `TypeError`.

## Utility functions

### `resolve_step_ref(ref: StepRef) -> str`

Resolves a step reference (string or `@step`-decorated method) to its tag string.
Raises `TypeError` if the method is not decorated with `@step`.

```python
resolve_step_ref("process")          # → "process"
resolve_step_ref(MyAgent.process)    # → "process"
resolve_step_ref(my_agent.process)   # → "process"
```

### `resolve_step_owner(ref: StepRef) -> type | None`

Returns the agent class that owns the step. Returns `None` for string refs.
For bound methods uses `type(ref.__self__)`, for unbound methods reads the
`__agent_class__` attribute set during compilation.

```python
resolve_step_owner("process")          # → None
resolve_step_owner(MyAgent.process)    # → MyAgent
resolve_step_owner(my_agent.process)   # → MyAgent
```

## Internals

The sections below describe types used by the `runtime` package to instantiate and
manage agents. Agent authors typically do not interact with these directly.

**"Compilation"** in this context means introspecting a class at definition time to
extract `@step` methods, their parameter types, and return types into metadata
(`AgentDefinition`). No bytecode generation is involved.

### `compile_agent(agent_cls, subagents=None) -> AgentDefinition`

Introspects an agent class and produces an `AgentDefinition`. `Agent.__init_subclass__`
calls this automatically — manual usage is only needed if you build agent definitions
without subclassing `Agent`.

```python
defn = compile_agent(MyAgentClass, subagents={"helper": HelperAgent})
# defn.steps — dict[str, StepMeta]
# defn.slots — dict[str, SlotDef]
# defn.type_registry — dict[str, type]
# defn.create_instance — (ServiceLocator, dict[str, SlotContainer]) → AgentInstance
# defn.subagents — {"helper": HelperAgent}
```

### `AbstractAgent`

Minimal interface the runtime depends on. Declares
`__agent_definition__: ClassVar[AgentDefinition]`. `Agent` inherits from it.

### `AgentDefinition`

Compiled agent descriptor.

| Field             | Type                              | Default |
|-------------------|-----------------------------------|---------|
| `steps`           | `dict[str, StepMeta]`             | —       |
| `slots`           | `dict[str, SlotDef]`              | —       |
| `type_registry`   | `dict[str, type]`                 | —       |
| `create_instance` | `CreateInstance`                  | —       |
| `subagents`       | `dict[str, AgentDefinitionRef]`   | `{}`    |

`create_instance` is a factory: `(ServiceLocator, dict[str, SlotContainer]) → AgentInstance`.

`slots` maps slot keys to `SlotDef` — declarative descriptions of the agent's stored values.

`type_registry` maps `qualname` to `type` — all dataclass types discovered from step
signatures and slot annotations. Used by the runtime for serialization/deserialization.

`subagents` maps local names to agent references (`AgentDefinitionRef`). These are
recursively registered in the runtime with namespaced names via `AgentRegistry`.

### `AgentInstance`

Live agent with a step handler.

| Field       | Type              |
|-------------|-------------------|
| `call_step` | `CallStepHandler` |

### `StepMeta`

Per-step metadata.

| Field          | Type                                  | Default       |
|----------------|---------------------------------------|---------------|
| `step_spec`    | `type[StepSpec] \| None`              | `None`        |
| `result_types` | `frozenset[type[AgentResult]]`        | `frozenset()` |

`result_types` is extracted from the step's return type annotation during compilation.
Used by the runtime to build the type registry for serialization/deserialization.

### `AgentRegistry`

Hierarchical agent name/type/definition registry. Handles registration and resolution of
agents by name (`str`) or by type (`type[AbstractAgent]`).

| Method                               | Description                                                     |
|--------------------------------------|-----------------------------------------------------------------|
| `resolve(ref, context)`              | Resolve by name, relative path, or type → `ResolvedAgent`       |
| `get(name)`                          | Direct lookup by absolute name (raises `KeyError` if not found) |
| `all_definitions()`                  | Returns all registered `AgentDefinition` instances              |
| `name_for_type(agent_type, context)` | Resolves a type to its registered name                          |

Resolution modes for `resolve()`:
- **Absolute name:** `"parent/child"` — looks up directly
- **Relative path:** `"./child"`, `"../sibling"` — resolved relative to `context`
- **By type:** `MyAgent` — walks the hierarchy from `context` upward to root

### `ResolvedAgent`

| Field        | Type              |
|--------------|-------------------|
| `name`       | `str`             |
| `definition` | `AgentDefinition` |

### `SlotDef`

Declarative slot description.

| Field        | Type       |
|--------------|------------|
| `key`        | `str`      |
| `kind`       | `SlotKind` |
| `value_type` | `type`     |

### `SlotKind`

`StrEnum` with two values: `SCALAR`, `APPEND_ONLY`.

### `SlotContainer`

Type alias: `Scalar | AppendOnlyList`.

### Type aliases

**User-facing** — useful in step return type annotations:

```python
type StepAction = Goto | Spawn
type StepResult = StepAction | AgentResult | None
type StepRef = str | StepMethod
type AgentRef = str | type[AbstractAgent]
```

**Internal** — used by the runtime and compilation:

```python
type StepMethod = Callable[..., StepResult | Awaitable[StepResult]]
type AgentDefinitionRef = AgentDefinition | type[AbstractAgent]
type CallStepHandler = Callable[[str, StepSpec | None, list[AgentResult] | None], Awaitable[StepResult]]
type CreateInstance = Callable[[ServiceLocator, dict[str, SlotContainer]], AgentInstance]
```

`StepAction` groups all control-flow commands. Agent authors can use it in return type
annotations when their step may return any flow control command:

```python
@step
async def process(self) -> StepAction | MyResult:
    if done:
        return MyResult(answer=42)
    return Goto(step=self.next_step)
```
