"""switch_model tool — live model switching during chat."""

import dataclasses
from collections.abc import Callable
from typing import Annotated, Any

from examples.app_agent import ModelSwitcher
from examples.llm_routing import ChatLLMRouter
from flowra.lib.tool_loop import ToolLoopAgentContext
from flowra.tools import ToolInput, tool

__all__ = ["create_switch_model_tool"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SwitchModelParams:
    model: str


def create_switch_model_tool(router: ChatLLMRouter) -> Callable[..., Any]:
    """Create a switch_model tool with the available models baked into the description."""
    available = "\n".join(f"- {k}" for k in router.available_models)

    @tool("switch_model", description=f"Switch the active LLM model.\n\nAvailable models:\n{available}")
    def switch_model(
        params: Annotated[SwitchModelParams, ToolInput], switcher: ModelSwitcher, ctx: ToolLoopAgentContext
    ) -> str:
        """Switch the active LLM model."""
        if params.model not in router.available_models:
            return f"Unknown model '{params.model}'. Available:\n{available}"
        switcher.switch_model(params.model)
        ctx.request_finish()
        return f"Switching to {params.model}"

    return switch_model
