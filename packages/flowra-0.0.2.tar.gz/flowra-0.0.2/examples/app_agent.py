"""AppAgent — parent agent wrapping ChatAgent with persistent model selection."""

import abc
import dataclasses
from collections.abc import Callable
from typing import ClassVar

from flowra.agent import Agent, AgentDefinitionRef, Call, Scalar, ServiceLocator, Spawn, slot, step
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib.config_value import ConfigValue
from flowra.lib.tool_loop import CACHE_MANUAL, CacheConfig
from flowra.llm import Message

__all__ = ["AppAgent", "AppConfig", "ModelSwitcher"]


class ModelSwitcher(abc.ABC):
    @abc.abstractmethod
    def switch_model(self, model_key: str) -> None: ...

    @abc.abstractmethod
    def get_current_model(self) -> str: ...


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AppConfig:
    default_model: str
    system_messages: ConfigValue[list[Message]]
    max_iterations: ConfigValue[int] = 10
    allowed_tools: ConfigValue[set[str] | None] = None
    denied_tools: ConfigValue[set[str] | None] = None
    cache_strategy: ConfigValue[CacheConfig] = CACHE_MANUAL
    max_consecutive_errors: ConfigValue[int | None] = None
    on_model_changed: Callable[[str], None] | None = None


class AppAgent(Agent, ModelSwitcher):
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "chat": ChatAgent,
    }

    current_model: Scalar[str] = slot("current_model")

    def __init__(
        self,
        services: ServiceLocator,
        config: AppConfig,
    ) -> None:
        self.__config = config

        services.provide(
            ChatConfig,
            ChatConfig(
                llm_config=self.__make_llm_config,
                system_messages=config.system_messages,
                max_iterations=config.max_iterations,
                allowed_tools=config.allowed_tools,
                denied_tools=config.denied_tools,
                cache_strategy=config.cache_strategy,
                max_consecutive_errors=config.max_consecutive_errors,
            ),
        )
        services.provide(ModelSwitcher, self)

    def __make_llm_config(self) -> LLMConfig:
        return LLMConfig(model=self.current_model.get(default=self.__config.default_model))

    def switch_model(self, model_key: str) -> None:
        self.current_model.set(model_key)
        if self.__config.on_model_changed is not None:
            self.__config.on_model_changed(model_key)

    def get_current_model(self) -> str:
        return self.current_model.get(default=self.__config.default_model)

    @step("process_message")
    async def process_message(self, spec: ChatSpec) -> Spawn:
        return Spawn(
            children=[
                Call(
                    agent=ChatAgent,
                    step=ChatAgent.process_message,
                    spec=spec,
                    storage_key="chat",
                ),
            ],
            then=self.collect_result,
        )

    @step("collect_result")
    async def collect_result(self, result: ChatResult) -> ChatResult:
        return result
