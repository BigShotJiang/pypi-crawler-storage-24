"""kanibako: Run AI coding agents in rootless containers with per-project isolation."""

__version__ = "1.0.1"
