# SPDX-FileCopyrightText: 2025 CSC - IT Center for Science Oy
#
# SPDX-License-Identifier: MIT

from typing import Optional
from .api import wrappers
from . import client


class Model(wrappers.ModelData):
    """Represents a machine learning model served by Aitta.

    Obtain a `Model` object by wrapping the result of `Client.get_model` or by using `Model.load`.

    Arguments:
        - model_data: An `api.wrappers.ModelData` instance containing information about the model.
        - client: A `Client` object used for making requests to the API server.
    """

    def __init__(self, model_data: wrappers.ModelData, client: client.Client) -> None:
        super().__init__(model_data._data)
        self._client = client
        self._metadata: None | wrappers.ModelMetadata = None

    def __str__(self) -> str:
        return f"Model({self.id})"

    @staticmethod
    def load(
        model_id: str | wrappers.ModelBasicReference, client: client.Client
    ) -> "Model":
        """Creates a Model instance given the models id, loading the relevant data from the Aitta API server.

        Arguments:
            - model_id: The unique identifier or a `ModelBasicReference` instance identifying the model.
            - client: A `Client` object used for making requests to the API server.

        Returns:
            a `Model` instance for the model with the given `model_id`
        """
        if isinstance(model_id, wrappers.ModelBasicReference):
            model_reference = model_id
        else:
            model_references = [m for m in client.get_model_list() if m.id == model_id]
            if not model_references:
                raise ModelNotFoundError(model_id)

            model_reference = model_references[0]

        model_data = client.get_model(model_reference)

        return Model(model_data, client)

    @property
    def openai_api_url(self) -> Optional[str]:
        """Returns the OpenAI API endpoint URL if the specified model is compatible with the OpenAI platform.

        The model is compatible if `model_capabilities` contains the `openai-chat-completion` capability.

        If the model is not compatible, an `IncompatibleModelError` is raised instead.

        Returns:
            the OpenAI API endpoint URL is returned as a string.
        """
        links = self._data.links
        if links.openai:
            url = links.openai.href
            if url.startswith("/"):
                url = self._client._endpoint_to_url(url)
            return url
        else:
            raise IncompatibleModelError(self.id)

    @property
    def model_capabilities(self) -> set[str]:
        """Returns the model capabilities.

        Returns:
            the model capabilities as a set of keywords. Empty if there are no special capabilities.
        """
        capabilities = self._data.capabilities.copy()
        return capabilities

    def get_metadata(self, ignore_cached: bool = False) -> wrappers.ModelMetadata:
        """Fetches and returns the model metadata.

        Model metadata is the information stored about the model in the Aitta database. This includes
        the common model information like the description, inputs, outputs and parameters as well as
        configuration options required to run the model on Aitta hardware, e.g., the number of GPUs
        that must be allocated and what software components to load.

        To prevent repeated queries to the server, this method caches the obtained metadata and
        on subsequent calls returns the cached result. Set the `ignore_cached` argument to `True`
        to enforce fetching the data from the Aitta API again.

        Arguments:
            - ignore_cached: If True, cached responses from previous calls are ignored and the
                data is retrieved from the server.

        Returns:
            a `ModelMetadata` object containing the model's metadata as stored in the database.

        Raises:
            - `UnavailableFeatureError` if metadata is not available, e.g., due to lacking access permissions
        """
        if ignore_cached or self._metadata is None:
            self._metadata = self._client.get_model_metadata(self)
        return self._metadata.model_copy()

    def update_metadata(self, metadata: wrappers.ModelMetadata) -> None:
        """Updates the model's metadata in the Aitta model repository.

        Model metadata is the information stored about the model in the Aitta database. This includes
        the common model information like the description, inputs, outputs and parameters as well as
        configuration options required to run the model on Aitta hardware, e.g., the number of GPUs
        that must be allocated and what software components to load.

        Arguments:
            - metadata: The complete new `ModelMetadata` data structure with which to overwrite the existing data in the model repository.
        """
        self._client.update_model_metadata(self, metadata)
        self._metadata = metadata


class ModelNotFoundError(Exception):

    def __init__(self, model_id: str) -> None:
        super().__init__(f"The model '{model_id}' is not available.")
        self._model_id = model_id

    @property
    def model_id(self) -> str:
        return self._model_id


class IncompatibleModelError(Exception):

    def __init__(self, model_id: str) -> None:
        super().__init__(
            f"The model '{model_id}' is not compatible with the OpenAI API."
            f"No OpenAI chat completion link found in the model's metadata."
        )
        self._model_id = model_id

    @property
    def model_id(self) -> str:
        return self._model_id
