# Copyright (c) 2026 GLG, a.s. All rights reserved.
# Licensed under dual license: Non-commercial use free, commercial use requires paid license.
# See LICENSE file for details.
"""UAML Update Checker — notifies users about new versions.

Checks PyPI for newer versions at most once per day.
Non-blocking, non-intrusive — just a one-line notice.

© 2026 GLG, a.s.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

# Check at most once per day (86400 seconds)
CHECK_INTERVAL = 86400
PACKAGE_NAME = "uaml-memory"
PYPI_URL = f"https://pypi.org/pypi/{PACKAGE_NAME}/json"


def _state_file() -> Path:
    """Get path to update check state file."""
    data_dir = Path(os.environ.get("UAML_DATA_DIR", Path.home() / ".uaml"))
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / ".update_check"


def _current_version() -> str:
    """Get current installed version."""
    try:
        from uaml import __version__
        return __version__
    except (ImportError, AttributeError):
        return "0.0.0"


def _parse_version(v: str) -> tuple:
    """Parse version string into comparable tuple."""
    try:
        return tuple(int(x) for x in v.split(".")[:3])
    except (ValueError, AttributeError):
        return (0, 0, 0)


def check_for_update(quiet: bool = False) -> Optional[str]:
    """
    Check PyPI for a newer version. Returns new version string if available, None otherwise.
    
    - Checks at most once per day (cached)
    - Non-blocking (2s timeout)
    - Fails silently on any error
    - Respects UAML_NO_UPDATE_CHECK=1 env var
    """
    # Respect opt-out
    if os.environ.get("UAML_NO_UPDATE_CHECK", "").strip() in ("1", "true", "yes"):
        return None
    
    # Check if we already checked recently
    state_file = _state_file()
    try:
        if state_file.exists():
            state = json.loads(state_file.read_text())
            last_check = state.get("last_check", 0)
            if time.time() - last_check < CHECK_INTERVAL:
                # Already checked recently — use cached result
                cached_latest = state.get("latest_version")
                current = _current_version()
                if cached_latest and _parse_version(cached_latest) > _parse_version(current):
                    if not quiet:
                        _print_notice(current, cached_latest)
                    return cached_latest
                return None
    except (json.JSONDecodeError, OSError):
        pass
    
    # Fetch latest version from PyPI
    try:
        import urllib.request
        req = urllib.request.Request(PYPI_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=2) as resp:
            data = json.loads(resp.read())
            latest = data.get("info", {}).get("version", "0.0.0")
    except Exception:
        # Network error, timeout, etc. — fail silently
        return None
    
    # Save state
    try:
        state_file.write_text(json.dumps({
            "last_check": time.time(),
            "latest_version": latest,
        }))
    except OSError:
        pass
    
    # Compare
    current = _current_version()
    if _parse_version(latest) > _parse_version(current):
        if not quiet:
            _print_notice(current, latest)
        return latest
    
    return None


def _print_notice(current: str, latest: str):
    """Print a non-intrusive update notice."""
    print(
        f"\n  💡 UAML Memory {latest} is available (you have {current}). "
        f"Upgrade: pip install --upgrade uaml-memory\n",
        file=sys.stderr,
    )
