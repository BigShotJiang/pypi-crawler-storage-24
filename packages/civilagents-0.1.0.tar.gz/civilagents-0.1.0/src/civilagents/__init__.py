"""Minimal package for the civilagents PyPI project."""

__all__ = ["__version__", "ping"]

__version__ = "0.1.0"


def ping() -> str:
    """Return a trivial value so the package has a usable public API."""
    return "civilagents"
