# civilagents

Tiny placeholder package for claiming the `civilagents` name on PyPI.

## Install packaging tools

```bash
python -m pip install --upgrade build twine
```

## Build

```bash
python -m build
```

## Publish

```bash
python -m twine upload dist/*
```

If you use an API token, create `~/.pypirc` or enter:

- Username: `__token__`
- Password: your PyPI API token
