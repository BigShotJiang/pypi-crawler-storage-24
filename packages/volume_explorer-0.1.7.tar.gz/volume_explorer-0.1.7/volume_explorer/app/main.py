"""
Streamlit dashboard for Petrel Volumetrics.

Launch:
    volume-explorer
    python -m volume_explorer
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from volume_explorer.constants import SHORT_NAMES, BASE_DIR_NAME
from volume_explorer.layouts import load_layouts, save_layout, Layout
from volume_explorer.parser import parse_raw
from volume_explorer.storage import (
    discover_projects, save_from_clipboard,
    load_name_maps, save_name_maps,
    load_units, save_units,
)
from volume_explorer.styling import style_table, table_to_svg
from volume_explorer.units import format_metric, default_metric_display
from streamlit_sortables import sort_items

BASE_DIR = Path(BASE_DIR_NAME)


def _svg_download_button(
    df: pd.DataFrame,
    fmt: str,
    dark: bool,
    title: str,
    subtitle: str,
    filename: str,
    key: str,
    subtotals: bool = False,
):
    """Render a download button that exports the table as native SVG."""
    svg_data = table_to_svg(
        df, fmt=fmt, dark=dark,
        title=title, subtitle=subtitle, subtotals=subtotals,
    )
    st.download_button(
        "Export SVG",
        data=svg_data,
        file_name=filename,
        mime="image/svg+xml",
        key=key,
    )


def _resolve_base_dir() -> Path:
    """Use CLI workdir argument if provided, otherwise default."""
    import sys
    args = sys.argv
    if "--" in args:
        extra = args[args.index("--") + 1:]
        if extra:
            return Path(extra[0])
    return BASE_DIR


@st.cache_data(ttl=60)
def _build_file_index(file_paths: list[str]) -> list[dict]:
    """Build model/grid index from all JSON files in a project."""
    from volume_explorer import PetrelVolumetrics
    index = []
    for fp in file_paths:
        p = Path(fp)
        try:
            pv_tmp = PetrelVolumetrics.load(p)
            index.append({
                "path": fp,
                "stem": p.stem,
                "model": pv_tmp.model or p.stem,
                "grid": pv_tmp.grid or "default",
                "cases": pv_tmp.case_names,
            })
        except Exception:
            index.append({
                "path": fp,
                "stem": p.stem,
                "model": p.stem,
                "grid": "default",
                "cases": [],
            })
    return index


def _reorder_df(df: pd.DataFrame, row_orders: dict) -> pd.DataFrame:
    """Reorder DataFrame rows based on drag-and-drop ordering."""
    if not row_orders:
        return df

    df = df.copy()

    if isinstance(df.index, pd.MultiIndex):
        for level_name in df.index.names:
            if level_name in row_orders:
                ordered = row_orders[level_name]
                order_map = {v: i for i, v in enumerate(ordered)}
                level_idx = df.index.names.index(level_name)
                keys = df.index.get_level_values(level_idx)
                sort_vals = keys.map(
                    lambda x, m=order_map, n=len(ordered): m.get(x, n)
                )
                df = df.iloc[sort_vals.argsort(kind="stable")]
    else:
        idx_name = df.index.name
        if idx_name and idx_name in row_orders:
            ordered = row_orders[idx_name]
            existing = [v for v in ordered if v in df.index]
            extra = [v for v in df.index if v not in existing]
            df = df.reindex(existing + extra)

    return df


def _name_map_for_category(pv, cat_key: str) -> dict[str, str]:
    """Get the name map for a category (original → display)."""
    nm = pv._load_name_maps()
    return nm.get(cat_key, {})


def _load_display_order(pv) -> dict[str, list[str]]:
    """Load saved display order from name_maps.json."""
    nm = load_name_maps(Path(pv._source_path).parent)
    return nm.get("display_order", {})


def _save_display_order(pv, order: dict[str, list[str]]):
    """Save display order to name_maps.json."""
    project_dir = Path(pv._source_path).parent
    nm = load_name_maps(project_dir)
    nm["display_order"] = order
    save_name_maps(nm, project_dir)


def _apply_saved_order(
    items: list[str], saved: list[str] | None,
) -> list[str]:
    """Reorder items based on a saved order, keeping new items at end."""
    if not saved:
        return items
    item_set = set(items)
    ordered = [s for s in saved if s in item_set]
    extra = [i for i in items if i not in ordered]
    return ordered + extra


def _category_filters(
    pv, key_prefix: str = "",
) -> dict[str, list[str] | None]:
    """Render multiselect filters for all categories. Returns filter dict.

    Options use original names (for query compatibility) but display
    renamed names from project name maps via format_func.
    Wrapped in a collapsible expander to reduce UI clutter.
    """
    from volume_explorer.constants import cat_to_df_col

    filters: dict[str, list[str] | None] = {}
    cat_keys = pv.category_keys
    if not cat_keys:
        return filters

    cat_display = {k: pv._cat_display_name(k) for k in cat_keys}

    saved_order = _load_display_order(pv)

    with st.expander("Filters", expanded=False):
        filter_cols = st.columns(len(cat_keys))
        for col, ck in zip(filter_cols, cat_keys):
            vals = pv.categories.get(ck, [])
            if not vals:
                continue
            vals = _apply_saved_order(vals, saved_order.get(ck))
            cat_nm = _name_map_for_category(pv, ck)
            with col:
                selected = st.multiselect(
                    cat_display.get(ck, ck),
                    options=vals,
                    default=vals,
                    format_func=lambda x, m=cat_nm: m.get(x, x),
                    key=f"{key_prefix}filter_{ck}",
                )
            df_col = cat_to_df_col(ck)
            filters[df_col] = selected if len(selected) < len(vals) else None

    return filters


# ── Import ────────────────────────────────────────────────────────────

def _import_tab(base: Path):
    """Import tab: paste Petrel data from clipboard."""
    st.subheader("Import Petrel Volumetrics")

    st.markdown(
        "Copy a volumetrics table from Petrel, then paste it below. "
        "Both **pivot** (single case) and **single-line** (multi-case) formats "
        "are auto-detected."
    )

    raw_text = st.text_area(
        "Paste Petrel export here",
        height=300,
        placeholder="Copy the volumetrics table in Petrel and paste here...",
        key="import_paste",
    )

    if st.button("Import", type="primary", disabled=not raw_text):
        try:
            data = parse_raw(raw_text)
            out_path = save_from_clipboard(data, base)
            st.success(f"Saved to `{out_path}`")
            st.rerun()
        except ValueError as e:
            st.error(str(e))
        except Exception as e:
            st.error(f"Import failed: {e}")


# ── Maintenance ───────────────────────────────────────────────────────

def _maintenance_tab(pv, selected_file: str, base: Path):
    """Maintenance tab: dataset info, rename fields, units, delete."""
    # ── Dataset info row ──
    col_info, col_actions = st.columns([3, 1])

    with col_info:
        meta = pv.metadata_display()
        parts = []
        for key, label in [("project", "Project"), ("model", "Model"),
                           ("grid", "Grid"), ("date_raw", "Date")]:
            if key in meta:
                parts.append(f"**{label}:** {meta[key]}")
        fmt = pv.format
        n_cases = len(pv.case_names)
        parts.append(
            f"**Format:** {fmt} ({n_cases} case{'s' if n_cases != 1 else ''})"
        )
        st.markdown(" · ".join(parts))

    with col_actions:
        if st.button("Delete dataset", type="secondary"):
            file_path = Path(selected_file)
            if file_path.exists():
                file_path.unlink()
                st.success("Dataset deleted.")
                st.rerun()

    st.divider()

    # ── Edit metadata ──
    st.subheader("Metadata")
    mc1, mc2, mc3 = st.columns(3)
    with mc1:
        new_project = st.text_input(
            "Project name",
            value=pv.metadata.get("project", ""),
            key="meta_project",
        )
    with mc2:
        new_model = st.text_input(
            "Model name",
            value=pv.metadata.get("model", ""),
            key="meta_model",
        )
    with mc3:
        new_grid = st.text_input(
            "Grid name",
            value=pv.metadata.get("grid", ""),
            key="meta_grid",
        )

    meta_changed = (
        new_project != pv.metadata.get("project", "")
        or new_model != pv.metadata.get("model", "")
        or new_grid != pv.metadata.get("grid", "")
    )
    if st.button(
        "Save metadata", type="primary", disabled=not meta_changed,
        key="save_metadata",
    ):
        pv.metadata["project"] = new_project
        pv.metadata["model"] = new_model
        pv.metadata["grid"] = new_grid
        pv._save()
        st.success("Metadata saved.")
        st.rerun()

    st.divider()

    # ── Rename fields ──
    project_dir = Path(selected_file).parent
    nm = load_name_maps(project_dir)

    # Collect renameable sections: cases + categories
    sections: dict[str, dict] = {}

    if pv.case_names and len(pv.case_names) > 1:
        sections["cases"] = {"label": "Cases", "originals": pv.case_names}

    for cat_key, vals in pv.categories.items():
        if vals:
            label = cat_key.replace("_", " ").title()
            sections[cat_key] = {"label": label, "originals": vals}

    # ── Unit conversion ──
    st.subheader("Units")
    st.caption(
        "Change display units for volume metrics. "
        "Values are multiplied accordingly."
    )

    # Available unit options per base unit in the raw Petrel column
    # key = exponent from [*10^X ...], value = list of (label, multiplier)
    _UNIT_OPTIONS = {
        "3": [
            ("kcm — *10³ m³ (default)", 1.0, "kcm"),
            ("mcm — *10⁶ m³", 1e-3, "mcm"),
            ("bcm — *10⁹ m³", 1e-6, "bcm"),
        ],
        "6": [
            ("mcm — *10⁶ m³ (default)", 1.0, "mcm"),
            ("bcm — *10⁹ m³", 1e-3, "bcm"),
            ("kcm — *10³ m³", 1e3, "kcm"),
        ],
    }

    import re as _re
    _RE_EXP = _re.compile(r"\[\*10\^(\d+)\s")

    units_cfg = load_units(base)
    current_mults: dict[str, dict] = {}
    for entry in units_cfg.get("multipliers", []):
        names = entry.get("name", [])
        if isinstance(names, str):
            names = [names]
        for n in names:
            current_mults[n] = entry

    # Group metrics by their base exponent
    cols = st.columns(2)
    for i, (short, raw_col) in enumerate(SHORT_NAMES.items()):
        m = _RE_EXP.search(raw_col)
        if not m:
            continue
        exp = m.group(1)
        options = _UNIT_OPTIONS.get(exp)
        if not options:
            continue

        label, _ = default_metric_display(raw_col)
        cur = current_mults.get(short, {})
        cur_unit = cur.get("result_unit", options[0][2])

        option_labels = [o[0] for o in options]
        option_units = [o[2] for o in options]
        try:
            default_idx = option_units.index(cur_unit)
        except ValueError:
            default_idx = 0

        with cols[i % 2]:
            choice = st.selectbox(
                label,
                options=option_labels,
                index=default_idx,
                key=f"unit_{short}",
            )
            sel_idx = option_labels.index(choice)
            sel_mult = options[sel_idx][1]
            sel_unit = options[sel_idx][2]

    if st.button("Save units", type="primary", key="save_units"):
        new_entries = []
        for short, raw_col in SHORT_NAMES.items():
            m = _RE_EXP.search(raw_col)
            if not m:
                continue
            exp = m.group(1)
            options = _UNIT_OPTIONS.get(exp)
            if not options:
                continue
            choice = st.session_state.get(f"unit_{short}")
            if choice is None:
                continue
            option_labels = [o[0] for o in options]
            sel_idx = option_labels.index(choice)
            sel_mult = options[sel_idx][1]
            sel_unit = options[sel_idx][2]
            if sel_mult != 1.0 or sel_unit != options[0][2]:
                new_entries.append({
                    "name": [short],
                    "multiplier": sel_mult,
                    "result_unit": sel_unit,
                })
        units_cfg["multipliers"] = new_entries
        save_units(units_cfg, base)
        st.success("Units saved.")
        st.rerun()

    st.divider()

    # ── Rename fields ──
    if not sections:
        st.info("No renameable fields in this dataset.")
        return

    st.subheader("Rename Fields")

    rename_tabs = st.tabs([s["label"] for s in sections.values()])

    for tab, (section_key, section) in zip(rename_tabs, sections.items()):
        with tab:
            originals = section["originals"]
            existing_map = nm.get(section_key, {})

            # Auto-detect: does the project name map cover all originals?
            covers_all = existing_map and all(
                orig in existing_map for orig in originals
            )
            if covers_all:
                st.caption(
                    "Conversion dictionary auto-detected from project name maps"
                )

            # Editable rename table
            df_rename = pd.DataFrame({
                "Original": originals,
                "Display Name": [
                    existing_map.get(orig, orig) for orig in originals
                ],
            })

            edited = st.data_editor(
                df_rename,
                key=f"rename_{section_key}",
                width="stretch",
                hide_index=True,
                column_config={
                    "Original": st.column_config.TextColumn(
                        "Original", disabled=True
                    ),
                    "Display Name": st.column_config.TextColumn(
                        "Display Name"
                    ),
                },
            )

            col_save, col_reset = st.columns([1, 1])
            with col_save:
                if st.button(
                    f"Save {section['label']}",
                    key=f"save_{section_key}",
                ):
                    new_map = {}
                    for _, row in edited.iterrows():
                        orig = row["Original"]
                        display = row["Display Name"]
                        if display and display.strip() and display != orig:
                            new_map[orig] = display.strip()

                    nm[section_key] = new_map
                    save_name_maps(nm, project_dir)
                    n = len(new_map)
                    st.success(
                        f"Saved {n} {section['label'].lower()} rename(s)"
                    )
                    st.rerun()

            with col_reset:
                if st.button(
                    f"Reset {section['label']}",
                    key=f"reset_{section_key}",
                ):
                    nm.pop(section_key, None)
                    save_name_maps(nm, project_dir)
                    st.success(
                        f"Reset {section['label'].lower()} to original names"
                    )
                    st.rerun()

            # ── Drag-to-reorder ──
            st.caption("Drag to reorder")
            saved_orders = nm.get("display_order", {})
            current_order = _apply_saved_order(
                originals, saved_orders.get(section_key),
            )
            display_items = [existing_map.get(o, o) for o in current_order]
            display_to_orig = dict(zip(display_items, current_order))
            reordered_display = sort_items(
                display_items, key=f"reorder_{section_key}",
            )
            reordered_originals = [
                display_to_orig[d] for d in reordered_display
            ]
            if reordered_originals != current_order:
                saved_orders[section_key] = reordered_originals
                nm["display_order"] = saved_orders
                save_name_maps(nm, project_dir)


# ── Explore ───────────────────────────────────────────────────────────

def _explore_tab(pv, base: Path, selected_tag: str | None):
    """Explore tab: metric queries with filters."""
    from volume_explorer.constants import cat_to_df_col

    # ── Case selector (multi-case datasets only) ──
    case_filter = None
    if len(pv.case_names) > 1 and selected_tag is None:
        case_nm = _name_map_for_category(pv, "cases")
        selected_cases = st.multiselect(
            "Cases",
            options=pv.case_names,
            default=pv.case_names,
            format_func=lambda x, m=case_nm: m.get(x, x),
            key="explore_case_filter",
        )
        if len(selected_cases) < len(pv.case_names):
            case_filter = selected_cases

    # ── Full-width filter bar ──
    filters = _category_filters(pv, key_prefix="explore_")

    # ── Controls in left column, table in right ──
    col1, col2 = st.columns([1, 3])

    with col1:
        metric_options = {
            short: format_metric(short, base)[0]
            for short in SHORT_NAMES
        }
        selected_metrics = st.multiselect(
            "Metrics",
            options=list(metric_options.keys()),
            default=["stoiip"],
            format_func=lambda x: metric_options.get(x, x),
        )

        cat_keys = pv.category_keys
        cat_display = {k: pv._cat_display_name(k) for k in cat_keys}
        group_by = st.multiselect(
            "Group by",
            options=cat_keys,
            default=cat_keys[:1] if cat_keys else [],
            format_func=lambda x: cat_display.get(x, x),
        )

        hide_zeros = st.checkbox("Hide zeros", value=True)
        subtotals = st.checkbox("Subtotals", value=False)
        decimals = st.selectbox("Decimals", [0, 1, 2, 3, 4], index=2)

        # ── Drag-and-drop display order ──
        saved_order = _load_display_order(pv)
        ordered_metrics = _apply_saved_order(
            list(selected_metrics), saved_order.get("metrics"),
        )
        ordered_group_by = _apply_saved_order(
            list(group_by), saved_order.get("group_by"),
        )
        row_orders: dict[str, list[str]] = {}

        has_reorderable = (
            len(selected_metrics) > 1
            or len(group_by) > 1
            or any(
                len(filters.get(cat_to_df_col(ck)) or pv.categories.get(ck, [])) > 1
                for ck in group_by
            )
        )

        if has_reorderable:
            with st.expander("Display order"):
                if len(selected_metrics) > 1:
                    st.caption("Metric columns")
                    short_to_display = {
                        s: metric_options[s] for s in ordered_metrics
                    }
                    display_to_short = {
                        v: k for k, v in short_to_display.items()
                    }
                    display_names = [
                        short_to_display[s] for s in ordered_metrics
                    ]
                    reordered = sort_items(
                        display_names, key="explore_metric_order",
                    )
                    ordered_metrics = [
                        display_to_short[d] for d in reordered
                    ]

                if len(group_by) > 1:
                    st.caption("Group-by priority")
                    key_to_display = {
                        k: cat_display.get(k, k) for k in ordered_group_by
                    }
                    display_to_key = {
                        v: k for k, v in key_to_display.items()
                    }
                    reordered = sort_items(
                        [key_to_display[k] for k in ordered_group_by],
                        key="explore_groupby_order",
                    )
                    ordered_group_by = [
                        display_to_key[d] for d in reordered
                    ]

                for ck in group_by:
                    df_col = cat_to_df_col(ck)
                    vals = filters.get(df_col)
                    if vals is None:
                        vals = pv.categories.get(ck, [])
                    vals = _apply_saved_order(
                        vals, saved_order.get(f"row_{ck}"),
                    )
                    if len(vals) > 1:
                        cat_nm = _name_map_for_category(pv, ck)
                        st.caption(f"{cat_display.get(ck, ck)} rows")
                        display_vals = [cat_nm.get(v, v) for v in vals]
                        display_to_orig = dict(zip(display_vals, vals))
                        reordered_display = sort_items(
                            display_vals, key=f"explore_order_{ck}",
                        )
                        row_orders[df_col] = [
                            display_to_orig[d] for d in reordered_display
                        ]

                # Persist order changes
                new_order = {
                    "metrics": ordered_metrics,
                    "group_by": ordered_group_by,
                }
                for ck in group_by:
                    df_col = cat_to_df_col(ck)
                    if df_col in row_orders:
                        new_order[f"row_{ck}"] = row_orders[df_col]
                if new_order != saved_order:
                    _save_display_order(pv, new_order)

    with col2:
        if not selected_metrics:
            st.info("Select at least one metric.")
        else:
            metric_arg = (
                ordered_metrics
                if len(ordered_metrics) > 1
                else ordered_metrics[0]
            )
            df = pv.volumes(
                metric=metric_arg,
                by=ordered_group_by if ordered_group_by else None,
                zone=filters.get("zone"),
                facies=filters.get("facies"),
                region=filters.get("region"),
                case=case_filter,
                tag=selected_tag,
                exclude_zero=hide_zeros,
            )

            if df.empty:
                st.warning("No data for current selection.")
            else:
                df = _reorder_df(df, row_orders)
                dark = st.get_option("theme.base") == "dark"
                title = pv.title or pv.model
                tag_label = (
                    f"Tag: {selected_tag}" if selected_tag else ""
                )
                styled = style_table(
                    df,
                    fmt=f"{{:,.{decimals}f}}",
                    dark=dark,
                    title=title,
                    subtitle=tag_label,
                    subtotals=subtotals,
                )
                st.markdown(styled._html, unsafe_allow_html=True)
                _svg_download_button(
                    df, fmt=f"{{:,.{decimals}f}}", dark=dark,
                    title=title, subtitle=tag_label,
                    filename=f"{pv.model}_explore.svg",
                    key="svg_explore", subtotals=subtotals,
                )

    return ordered_metrics, ordered_group_by, filters, hide_zeros, decimals


# ── Case Summary ──────────────────────────────────────────────────────

def _summary_tab(pv, base: Path, selected_tag: str | None):
    """Case Summary tab: multi-case comparison."""
    st.subheader("Multi-case Summary")

    if len(pv.case_names) <= 1:
        st.info(
            "Single-case data. Import a single-line format export "
            "with multiple cases to use this view."
        )
        return

    # ── Full-width filter bar ──
    filters = _category_filters(pv, key_prefix="summary_")

    col1, col2 = st.columns([1, 3])

    with col1:
        all_metrics = list(SHORT_NAMES.keys())
        summary_metrics = st.multiselect(
            "Summary metrics",
            options=all_metrics,
            default=[
                "bulk", "net", "pore", "hcpv_oil",
                "hcpv_gas", "stoiip", "giip",
            ],
            format_func=lambda x: format_metric(x, base)[0],
            key="summary_metrics",
        )

        decimals = st.selectbox(
            "Decimals", [0, 1, 2, 3, 4], index=2, key="summary_decimals",
        )

    with col2:
        if not summary_metrics:
            st.info("Select at least one metric.")
            return

        summary_df = pv.summary_table(
            metrics=summary_metrics,
            zone=filters.get("zone"),
            facies=filters.get("facies"),
            region=filters.get("region"),
            tag=selected_tag,
        )
        if not summary_df.empty:
            dark = st.get_option("theme.base") == "dark"
            tag_label = (
                f"Tag: {selected_tag}" if selected_tag else "All cases"
            )
            styled = style_table(
                summary_df,
                fmt=f"{{:,.{decimals}f}}",
                dark=dark,
                title=f"{pv.model} — Case Summary",
                subtitle=tag_label,
            )
            st.markdown(styled._html, unsafe_allow_html=True)
            _svg_download_button(
                summary_df, fmt=f"{{:,.{decimals}f}}", dark=dark,
                title=f"{pv.model} — Case Summary",
                subtitle=tag_label,
                filename=f"{pv.model}_summary.svg",
                key="svg_summary",
            )


# ── Main ──────────────────────────────────────────────────────────────

def main():
    st.set_page_config(page_title="Volume Explorer", layout="wide")
    st.title("Volume Explorer")

    base = _resolve_base_dir()
    base.mkdir(parents=True, exist_ok=True)

    all_files = discover_projects(base)
    has_data = bool(all_files)

    # ── Sidebar: data selection ──
    pv = None
    selected_tag = None
    selected_file = None

    if has_data:
        st.sidebar.header("Data Selection")

        projects = list(all_files.keys())
        project = st.sidebar.selectbox("Project", projects)

        files = all_files.get(project, [])

        # Build model/grid index from all files in this project
        file_index = _build_file_index([str(f) for f in files])

        # Model selector (only if >1 unique model)
        models = list(dict.fromkeys(fi["model"] for fi in file_index))
        if len(models) > 1:
            selected_model = st.sidebar.selectbox("Model", models)
        else:
            selected_model = models[0] if models else None

        # Grid selector (only if >1 grid for selected model)
        model_files = [fi for fi in file_index if fi["model"] == selected_model]
        grids = list(dict.fromkeys(fi["grid"] for fi in model_files))
        if len(grids) > 1:
            selected_grid = st.sidebar.selectbox("Grid", grids)
        else:
            selected_grid = grids[0] if grids else None

        # Dataset selector (only if >1 dataset for model+grid)
        grid_files = [fi for fi in model_files if fi["grid"] == selected_grid]
        if len(grid_files) > 1:
            file_labels = {fi["path"]: fi["stem"] for fi in grid_files}
            selected_file = st.sidebar.selectbox(
                "Dataset",
                options=[fi["path"] for fi in grid_files],
                format_func=lambda x: file_labels.get(x, x),
            )
        elif grid_files:
            selected_file = grid_files[0]["path"]

        if selected_file:
            from volume_explorer import PetrelVolumetrics
            pv = PetrelVolumetrics.load(selected_file)

            # Tags
            all_tags = pv.tags()
            if all_tags:
                st.sidebar.header("Tags")
                tag_options = ["(all cases)"] + list(all_tags.keys())
                tag_choice = st.sidebar.selectbox(
                    "Filter by tag", tag_options,
                )
                if tag_choice != "(all cases)":
                    selected_tag = tag_choice

            # Case properties
            all_params = pv._data.get("parameters", {})
            if all_params and isinstance(all_params, dict):
                with st.sidebar.expander("Case Properties"):
                    case_options = list(all_params.keys())
                    if len(case_options) == 1:
                        sel_case = case_options[0]
                        st.caption(sel_case)
                    else:
                        sel_case = st.selectbox(
                            "Case", case_options, key="sidebar_case_props",
                        )
                    params = all_params.get(sel_case, {})
                    if params:
                        for k, v in params.items():
                            if isinstance(v, float):
                                st.text(f"{k}: {v:g}")
                            else:
                                st.text(f"{k}: {v}")
                    else:
                        st.caption("No properties for this case.")

            # Metadata
            with st.sidebar.expander("Metadata"):
                meta = pv.metadata_display()
                for key, val in meta.items():
                    if isinstance(val, (dict, list)):
                        continue
                    if key == "date_parsed":
                        continue
                    label = key.replace("_", " ").title()
                    st.text(f"{label}: {val}")

            # Layouts
            st.sidebar.header("Layouts")
            layout_names = ["(none)"] + [l.name for l in load_layouts(base)]
            st.sidebar.selectbox("Load Layout", layout_names)

    # ── Tabs ──
    if has_data and pv is not None:
        tab_maint, tab_explore, tab_summary, tab_import = st.tabs(
            ["Maintenance", "Explore", "Case Summary", "Import"]
        )

        with tab_maint:
            _maintenance_tab(pv, selected_file, base)

        with tab_explore:
            explore_state = _explore_tab(pv, base, selected_tag)
            selected_metrics, group_by, filters, hide_zeros, decimals = (
                explore_state
            )

        with tab_summary:
            _summary_tab(pv, base, selected_tag)

        with tab_import:
            _import_tab(base)

        # Save layout (sidebar)
        with st.sidebar.expander("Save Layout"):
            layout_name = st.text_input("Layout name")
            if st.button("Save") and layout_name:
                layout = Layout(
                    name=layout_name,
                    metrics=selected_metrics,
                    group_by=group_by if group_by else None,
                    filters=filters if filters else None,
                    hide_zeros=hide_zeros,
                    decimals=decimals,
                )
                save_layout(layout, base)
                st.success(f"Layout saved: {layout_name}")

    else:
        tab_import, = st.tabs(["Import"])
        with tab_import:
            _import_tab(base)


if __name__ == "__main__":
    main()
