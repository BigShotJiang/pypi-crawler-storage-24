from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import threading
from typing import Any, Awaitable, Callable

logger = logging.getLogger("estuary_sdk")

try:
    import numpy as np
    import sounddevice as sd

    HAS_AUDIO = True
except (ImportError, OSError):
    HAS_AUDIO = False


class AudioRecorder:
    """Captures audio from the microphone as PCM16 bytes.

    Includes automatic device fallback (tries system default, then explicit
    default, then first available input) and drain() for graceful stop.

    Requires the `audio` optional dependency:
        pip install estuary-sdk[audio]
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        on_audio: Callable[[bytes], Awaitable[None]] | None = None,
    ) -> None:
        if not HAS_AUDIO:
            raise ImportError(
                "sounddevice and numpy are required for audio recording. "
                "Install with: pip install estuary-sdk[audio]"
            )
        self._target_rate = sample_rate
        self._device_rate: int = sample_rate
        self._on_audio = on_audio
        self._stream: sd.InputStream | None = None  # type: ignore[name-defined]
        self._recording = False
        self._loop: asyncio.AbstractEventLoop | None = None
        self._in_flight_count = 0
        self._in_flight_lock = threading.Lock()
        self._drain_event: asyncio.Event | None = None

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def device_sample_rate(self) -> int:
        """The actual sample rate negotiated with the audio device."""
        return self._device_rate

    def _resolve_device_rate(self) -> int:
        """Determine a supported input sample rate for the default device.

        Tries the target rate first, then probes common rates (preferring
        integer multiples of the target for cheap decimation).
        """
        probe_rates = [48000, 32000, 96000, 44100, 22050]

        # Try target rate first
        try:
            sd.check_input_settings(  # type: ignore[attr-defined]
                samplerate=self._target_rate, channels=1, dtype="int16"
            )
            return self._target_rate
        except Exception:
            pass

        for rate in probe_rates:
            if rate == self._target_rate:
                continue
            try:
                sd.check_input_settings(  # type: ignore[attr-defined]
                    samplerate=rate, channels=1, dtype="int16"
                )
                logger.info(
                    "Device does not support %d Hz, using %d Hz (will resample)",
                    self._target_rate,
                    rate,
                )
                return rate
            except Exception:
                continue

        raise RuntimeError(
            f"No supported input sample rate found (tried {self._target_rate} and {probe_rates})"
        )

    @staticmethod
    def _resample_int16(data: bytes, device_rate: int, target_rate: int) -> bytes:
        """Resample PCM16 audio from device_rate to target_rate."""
        if device_rate % target_rate == 0:
            # Integer ratio — simple decimation
            factor = device_rate // target_rate
            return memoryview(data).cast("h")[::factor].tobytes()
        # Non-integer ratio — numpy linear interpolation
        samples = np.frombuffer(data, dtype=np.int16)
        out_len = int(len(samples) * target_rate / device_rate)
        indices = np.linspace(0, len(samples) - 1, out_len)
        resampled = np.interp(indices, np.arange(len(samples)), samples.astype(np.float64))
        return resampled.astype(np.int16).tobytes()

    def _candidate_input_devices(self) -> list[int | None]:
        """Return a list of candidate input device IDs to try.

        Always includes None (system default), the explicit default device,
        and the first available input device.
        """
        default_candidate: int | None = None
        default_device = getattr(sd.default, "device", None)  # type: ignore[attr-defined]
        if isinstance(default_device, (tuple, list)) and default_device:
            if isinstance(default_device[0], int) and default_device[0] >= 0:
                default_candidate = int(default_device[0])
        elif isinstance(default_device, int) and default_device >= 0:
            default_candidate = int(default_device)

        candidates: list[int | None] = [None]
        fallback_candidate = self._first_available_input_device()
        for candidate in (default_candidate, fallback_candidate):
            if candidate is not None and candidate not in candidates:
                candidates.append(candidate)
        return candidates

    def _first_available_input_device(self) -> int | None:
        """Find the first audio device with input channels."""
        try:
            devices = sd.query_devices()  # type: ignore[attr-defined]
        except Exception:
            logger.exception("Failed to query audio devices")
            return None

        for index, device in enumerate(devices):
            try:
                if int(device.get("max_input_channels", 0)) > 0:
                    return index
            except Exception:
                continue
        return None

    def _open_stream(self, device: int | None) -> Any:
        """Open an input stream on the given device."""
        stream_kwargs: dict[str, Any] = {
            "samplerate": self._device_rate,
            "channels": 1,
            "dtype": "int16",
            "blocksize": self._device_rate // 50,
            "callback": self._audio_callback,
        }
        if device is not None:
            stream_kwargs["device"] = device
        return sd.InputStream(**stream_kwargs)  # type: ignore[attr-defined]

    async def start(self) -> None:
        """Start capturing audio with automatic device fallback.

        Tries the system default device first, then the explicit default,
        then the first available input device.
        """
        if self._recording:
            return

        self._loop = asyncio.get_event_loop()
        self._device_rate = self._resolve_device_rate()

        last_error: Exception | None = None
        for device in self._candidate_input_devices():
            try:
                self._stream = self._open_stream(device)
                self._stream.start()
                self._recording = True
                logger.info(
                    "Audio recorder started (rate=%d, device=%s)",
                    self._device_rate,
                    device,
                )
                return
            except Exception as exc:
                last_error = exc
                self._recording = False
                self._close_stream_quietly()
                logger.warning(
                    "Audio input open failed for device=%s, trying fallback",
                    device,
                    exc_info=True,
                )

        raise RuntimeError("No usable input audio device found") from last_error

    def _close_stream_quietly(self) -> None:
        """Close the audio stream without raising."""
        stream = self._stream
        self._stream = None
        if stream is None:
            return
        try:
            stream.stop()
        except Exception:
            logger.debug("Audio input stream stop failed", exc_info=True)
        try:
            stream.close()
        except Exception:
            logger.debug("Audio input stream close failed", exc_info=True)

    async def stop(self) -> None:
        """Stop capturing audio."""
        if not self._recording:
            return

        self._recording = False
        self._drain_event = None
        self._close_stream_quietly()
        logger.debug("Audio recorder stopped")

    async def drain(self, timeout: float = 0.5) -> None:
        """Stop recording and wait for in-flight audio chunks to finish sending.

        Args:
            timeout: Max seconds to wait for in-flight chunks.
        """
        self._recording = False

        need_wait = False
        with self._in_flight_lock:
            if self._in_flight_count > 0:
                self._drain_event = asyncio.Event()
                need_wait = True

        if need_wait and self._drain_event is not None:
            try:
                await asyncio.wait_for(self._drain_event.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                logger.debug(
                    "Audio drain timed out with %d chunks in flight",
                    self._in_flight_count,
                )

        self._drain_event = None
        self._close_stream_quietly()
        logger.debug("Audio recorder drained and stopped")

    def _audio_callback(
        self,
        indata: np.ndarray,  # type: ignore[name-defined]
        frames: int,
        time_info: object,
        status: object,
    ) -> None:
        """Called by sounddevice from the audio thread."""
        if not self._recording or self._on_audio is None or self._loop is None:
            return

        if status:
            logger.warning("Audio recorder status: %s", status)

        with self._in_flight_lock:
            self._in_flight_count += 1

        audio_bytes = indata.tobytes()
        if self._device_rate != self._target_rate:
            audio_bytes = self._resample_int16(
                audio_bytes, self._device_rate, self._target_rate
            )
        fut: concurrent.futures.Future[None] = asyncio.run_coroutine_threadsafe(
            self._on_audio(audio_bytes), self._loop  # type: ignore[arg-type]
        )
        fut.add_done_callback(self._handle_audio_done)

    def _handle_audio_done(self, fut: concurrent.futures.Future[None]) -> None:
        """Handle completion of an in-flight audio callback."""
        try:
            fut.result()
        except Exception:
            logger.exception("Error in audio callback")

        signal_drain = False
        with self._in_flight_lock:
            self._in_flight_count = max(0, self._in_flight_count - 1)
            if self._in_flight_count == 0 and self._drain_event is not None:
                signal_drain = True

        if signal_drain and self._loop is not None and self._drain_event is not None:
            self._loop.call_soon_threadsafe(self._drain_event.set)
