from setuptools import setup, find_packages

setup(
    name="confusehunter",
    version="1.0.1",
    packages=find_packages(),
    install_requires=[
        "aiohttp",
        "click",
        "rich",
        "toml",
        "pyyaml"
    ],
    entry_points={
        'console_scripts': [
            'confusehunter=confusehunter.cli:cli',
        ],
    },
    author="chinnuy93",
    description="Production-grade multi-language CLI security tool for detecting dependency confusion.",
    python_requires='>=3.7',
)
