# ConfuseHunter

Dependency Confusion Scanner  
Developer: **chinnuy93**

---

## What is ConfuseHunter?

ConfuseHunter is a production-grade dependency confusion vulnerability scanner built for security researchers and bug bounty hunters. It detects packages vulnerable to dependency confusion attacks across multiple ecosystems, generates proof-of-concept packages with modular payloads, and produces detailed reports — all from a single CLI.

---

## Installation

```bash
pip install confusehunter
```

---

## Quick Start

```bash
# Interactive mode – guided step-by-step workflow
confusehunter scan https://github.com/target/repo
```


