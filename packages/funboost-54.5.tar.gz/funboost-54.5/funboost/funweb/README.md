---
noteId: "3111c4d3280d11f19619d3c52e8c4c84"
tags: []

---


`funboost_web_manager` 是 `funweb` 的全称。 
funboost_web_manager 名字太长了，用 funweb 做个简化，是一样的意义和用途。

`from funboost.funweb.app import` 和 `from funboost.funboost_web_manager.app import`  效果一样






