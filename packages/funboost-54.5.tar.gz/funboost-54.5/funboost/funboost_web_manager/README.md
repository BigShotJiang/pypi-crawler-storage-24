---
noteId: "3111c4d2280d11f19619d3c52e8c4c84"
tags: []

---



`funweb` 是 `funboost_web_manager` 的简称。 
funboost_web_manager名字太长了，用这个funweb做个简化，是一样的意义和用途。

`from funboost.funweb.app import` 和 `from funboost.funboost_web_manager.app import`  效果一样



