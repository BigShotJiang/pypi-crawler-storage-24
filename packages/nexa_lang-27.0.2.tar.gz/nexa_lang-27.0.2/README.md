<div align="center">

<h1>
  <img src="https://img.shields.io/badge/NEXA-v27-blueviolet?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZmlsbD0id2hpdGUiIGQ9Ik0xMiAyTDIgN2wxMCA1IDEwLTV6TTIgMTdsIDEwIDUgMTAtNXYtN2wtMTAgNUwyIDEweiIvPjwvc3ZnPg==" alt="Nexa v27" />
</h1>

<h2>⚡ Nexa Programming Language</h2>

<p><strong>Modern · AI-Native · Expressive · Safe</strong></p>

<p>
  <em>The language where AI is a first-class citizen.</em><br/>
  Blending the clarity of Python, the safety of Rust, and built-in AI primitives — in one clean syntax.
</p>

[![Build](https://img.shields.io/badge/build-passing-brightgreen?style=flat-square)](https://github.com/nexa-lang/nexa)
[![Version](https://img.shields.io/badge/version-v27-blueviolet?style=flat-square)](https://github.com/nexa-lang/nexa/releases)
[![License](https://img.shields.io/badge/license-MIT-blue?style=flat-square)](LICENSE.md)
[![Python](https://img.shields.io/badge/runtime-Python%203.10+-yellow?style=flat-square)](https://python.org)
[![Discord](https://img.shields.io/badge/community-Discord-5865F2?style=flat-square&logo=discord)](https://discord.gg/nexa-lang)
[![Stars](https://img.shields.io/github/stars/nexa-lang/nexa?style=flat-square&color=orange)](https://github.com/nexa-lang/nexa/stargazers)

<br/>

```nexa
import "agent"

// Build an AI chatbot in 10 lines 🤖
let bot = agent.create("groq", model="llama-3.3-70b")
var history = []

loop {
    let input = read("You: ")
    if input == "quit" { break }
    append(history, {"role": "user", "content": input})
    let reply = await bot.chat(history)
    print(f"Bot: {reply}")
}
```

**👆 That's it. An AI chatbot with memory. In Nexa.**

[📖 Documentation](#documentation) · [🚀 Quick Start](#quick-start) · [💬 Community](https://discord.gg/nexa-lang) · [🗺️ Roadmap](ROADMAP.md)

</div>

---

## ✨ Why Nexa?

| Feature | Python | Rust | Go | **Nexa** |
|---------|--------|------|----|----------|
| Easy syntax | ✅ | ❌ | ✅ | ✅ |
| Type safety | ⚠️ | ✅ | ✅ | ✅ |
| AI keywords built-in | ❌ | ❌ | ❌ | **✅** |
| Pattern matching | ⚠️ | ✅ | ❌ | **✅** |
| Async/await | ✅ | ✅ | ✅ | **✅** |
| REPL | ✅ | ❌ | ❌ | **✅** |
| Built-in test framework | ❌ | ✅ | ✅ | **✅** |
| Pipe operators | ❌ | ❌ | ❌ | **✅** |
| Package manager | ✅ | ✅ | ✅ | **✅** |

---

## 🚀 Quick Start

### Install

```bash
pip install nexa-lang
```

### Run your first Nexa program

```bash
echo 'print("Hello, Nexa!")' > hello.nexa
nexa run hello.nexa
```

### Or use the REPL

```bash
nexa repl
```

---

## 🌟 Core Features

### 🔒 Immutable by Default
```nexa
let name = "Nexa"   // immutable — safe
var count = 0       // explicit mutability
count += 1
```

### 🤖 AI as a First-Class Citizen
```nexa
// Train an ML model with language-level keywords
model Classifier {
    layer Dense(128, activation="relu")
    layer Dense(64,  activation="relu")
    layer Dense(10,  activation="softmax")
}

let clf = new Classifier()
train clf on training_data {
    epochs    = 10
    optimizer = "adam"
    loss      = "crossentropy"
}

let output = predict clf(input_features)
```

### 🔀 Pipe Operators
```nexa
// Chain transformations elegantly
let result = [1, 2, 3, 4, 5]
    |> map(fn(x) => x * 2)
    |> filter(fn(x) => x > 4)
    |> sum()
// result = 24
```

### 🎯 Pattern Matching
```nexa
match response {
    case {"ok": true,  "data": d} { process(d) }
    case {"ok": false, "error": e} { log_error(e) }
    default { print("unexpected response") }
}
```

### ⚡ Async / Concurrent
```nexa
async def fetch_all(urls) {
    for url in urls {
        spawn fetch(url)   // concurrent tasks
    }
}
```

### 🧪 Built-in Testing
```nexa
test "addition works" {
    assert 2 + 2 == 4
}

bench "list append x1000" {
    var l = []
    for i in 0..1000 { append(l, i) }
}
```

Run with:
```bash
nexa test myfile.nexa
nexa bench myfile.nexa
```

### 🌐 Generics (Templates)
```nexa
template Stack<T> {
    var items: List = []
    def push(item: T)  { append(items, item) }
    def pop()  -> T    { return items[len(items)-1] }
    def size() -> Int  { return len(items) }
}

let s = new Stack<Int>()
s.push(42)
s.pop()   // 42
```

---

## 📦 Package Manager

```bash
# Install a package
nexa pkg install nexa_http

# Search packages
nexa pkg search ai

# Publish your package
nexa pkg publish
```

---

## 🛠️ CLI Reference

| Command | Description |
|---------|-------------|
| `nexa run file.nexa` | Execute a Nexa script |
| `nexa repl` | Start the interactive REPL |
| `nexa test file.nexa` | Run all tests |
| `nexa check file.nexa` | Static type checking |
| `nexa fmt file.nexa` | Format code |
| `nexa bench file.nexa` | Run benchmarks |
| `nexa doc file.nexa` | Generate documentation |
| `nexa pkg install <pkg>` | Install a package |
| `nexa pkg publish` | Publish a package |

---

## 📚 Documentation

| Resource | Description |
|----------|-------------|
| [📖 The Nexa Book](docs/) | Complete language reference (Ch 1–20) |
| [⚡ Nexa by Example](examples/) | Quick copy-paste examples |
| [🤖 AI Tutorial](docs/ai-tutorial.md) | Build AI apps with Nexa |
| [🌐 Web Tutorial](docs/web-tutorial.md) | REST APIs and web servers |
| [🔐 Security Guide](docs/security.md) | Nexa for cybersecurity |

---

## 🏗️ Real-World Examples

<details>
<summary>🌐 <strong>REST API Server</strong></summary>

```nexa
import "http"

def handle_hello(req) {
    return {"message": f"Hello, {req.params.name}!"}
}

let app = http.server()
app.get("/hello/:name", handle_hello)
app.listen(8080)
print("Server running on http://localhost:8080")
```
</details>

<details>
<summary>🤖 <strong>AI Agent with Memory</strong></summary>

```nexa
import "agent"

let bot = agent.create("groq", model="llama-3.3-70b")
var history = []

loop {
    let user_input = read("You: ")
    if user_input == "quit" { break }

    append(history, {"role": "user", "content": user_input})
    let reply = await bot.chat(history)
    print(f"Bot: {reply}")
    append(history, {"role": "assistant", "content": reply})
}
```
</details>

<details>
<summary>🧠 <strong>ML Classifier</strong></summary>

```nexa
// AutoML — Nexa picks the best model automatically
automl target=labels from features {
    task       = "classification"
    time_limit = 60
}
```
</details>

---

## 🗺️ Roadmap

- [x] Lexer, Parser, Interpreter (v1–v14)
- [x] Type checker (`nexa check`)
- [x] Async/await, concurrency (`spawn`)
- [x] Generics / Templates, Structs, Enums, Newtypes
- [x] Package manager + registry
- [x] LSP server (VSCode extension)
- [x] AI keywords (`model`, `train`, `predict`, `automl`)
- [x] WASM bridge
- [ ] LLVM native compilation
- [ ] Nexa Playground (browser IDE)
- [ ] `awesome-nexa` community list
- [ ] Official nexa-lang.org website

---

## 🤝 Contributing

We love contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) to get started.

```bash
# Clone and set up
git clone https://github.com/nexa-lang/nexa.git
cd nexa
pip install -e .

# Run the test suite
python -m pytest tests/

# Try a Nexa file
nexa run examples/hello.nexa
```

Good first issues are tagged [`good first issue`](https://github.com/nexa-lang/nexa/issues?q=is%3Aissue+label%3A%22good+first+issue%22).

---

## 🌍 Community

- 💬 **Discord**: [discord.gg/fYWWpnkjgn](https://discord.gg/fYWWpnkjgn)
- 📣 **Reddit**: [r/nexalang](https://reddit.com/r/nexalang)
- 🐦 **Twitter**: [@nexalang](https://twitter.com/nexalang)

---

## 📄 License

Nexa is open-source under the [MIT License](LICENSE.md).

---

<div align="center">

**Built with ❤️ for the future of programming.**

*If Nexa helps you, give it a ⭐ — it helps the project grow!*

[![Star History](https://img.shields.io/badge/⭐_Star_this_repo-orange?style=for-the-badge)](https://github.com/nexa-lang/nexa)

</div>
