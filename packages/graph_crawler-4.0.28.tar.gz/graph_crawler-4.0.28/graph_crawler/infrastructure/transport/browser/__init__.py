"""Module: infrastructure/transport/browser"""
