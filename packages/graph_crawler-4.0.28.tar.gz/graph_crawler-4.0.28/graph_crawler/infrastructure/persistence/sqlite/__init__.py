"""Module: infrastructure/persistence/sqlite"""
