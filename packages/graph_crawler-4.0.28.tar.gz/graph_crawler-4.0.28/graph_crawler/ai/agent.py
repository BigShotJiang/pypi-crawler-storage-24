"""AIAgent - High-level інтерфейс для AI-керованого краулінгу.

AIAgent є "thin wrapper" навколо існуючих core компонентів:
- CrawlContext для управління станом
- StopConditions для динамічної зупинки
- AIExtractionPlugin для витягування даних

Приклад використання:
    ```python
    from graph_crawler.ai import AIAgent, OpenAIModel
    from pydantic import BaseModel
    
    class CompanyInfo(BaseModel):
        name: str
        employees: int
        headquarters: str = None
    
    # Створюємо модель та агент
    model = OpenAIModel(api_key="sk-...")
    agent = AIAgent(model=model, max_pages=30)
    
    # Запускаємо AI-керований краулінг
    result = await agent.crawl(
        url="https://company.com",
        task="Знайди інформацію про компанію",
        output=CompanyInfo
    )
    
    print(result.name)       # "ACME Corp"
    print(result.employees)  # 5000
    ```
"""

import logging
from typing import Any, Dict, List, Optional, TypeVar, Union

from pydantic import BaseModel

from graph_crawler.domain.context import CrawlContext
from graph_crawler.domain.interfaces import (
    ILanguageModel,
    AsyncQueueControlChannel,
    MaxPagesStopCondition,
    SchemaCompleteStopCondition,
    TargetFoundStopCondition,
    IStopCondition,
)
from graph_crawler.ai.extraction_plugin import AIExtractionPlugin

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


class AIAgent:
    """
    High-level AI інтерфейс для graph_crawler.
    
    AIAgent спрощує використання AI-керованого краулінгу:
    1. Автоматично створює CrawlContext з result_schema
    2. Налаштовує StopConditions
    3. Інтегрує AIExtractionPlugin
    4. Повертає типізований результат
    
    Attributes:
        model: LLM провайдер
        max_pages: Максимальна кількість сторінок
        max_depth: Максимальна глибина краулінгу
    """
    
    def __init__(
        self,
        model: ILanguageModel,
        max_pages: int = 50,
        max_depth: int = 3,
        additional_stop_conditions: List[IStopCondition] = None,
    ):
        """
        Ініціалізує AIAgent.
        
        Args:
            model: Реалізація ILanguageModel (OpenAIModel, AnthropicModel)
            max_pages: Safety limit - максимальна кількість сторінок
            max_depth: Максимальна глибина переходів
            additional_stop_conditions: Додаткові умови зупинки
        """
        self.model = model
        self.max_pages = max_pages
        self.max_depth = max_depth
        self.additional_stop_conditions = additional_stop_conditions or []
        
        # Результати останнього краулінгу
        self._last_context: Optional[CrawlContext] = None
        self._last_graph = None
    
    async def crawl(
        self,
        url: str,
        task: str,
        output: type[T] = None,
        **crawler_kwargs,
    ) -> Union[T, str, None]:
        """
        AI-керований краулінг.
        
        Args:
            url: Стартовий URL
            task: Завдання природною мовою (що шукати/витягувати)
            output: Pydantic модель для результату (опціонально)
            **crawler_kwargs: Додаткові параметри для crawl_async
            
        Returns:
            - Pydantic model якщо вказано output
            - str якщо без output (текстовий результат)
            - None якщо нічого не знайдено
            
        Example:
            ```python
            # З Pydantic схемою
            result = await agent.crawl(
                "https://shop.com",
                task="Знайди ціну та назву продукту",
                output=ProductInfo
            )
            
            # Без схеми (вільний текст)
            text = await agent.crawl(
                "https://blog.com",
                task="Підсумуй основні теми блогу"
            )
            ```
        """
        logger.info(f"Starting AI crawl: url={url}, task='{task[:50]}...'")
        
        # 1. Створюємо контекст
        context = CrawlContext(result_schema=output)
        self._last_context = context
        
        # 2. Створюємо умови зупинки
        stop_conditions = self._build_stop_conditions(output)
        
        # 3. Створюємо канал керування
        control_channel = AsyncQueueControlChannel()
        
        # 4. Створюємо extraction plugin
        extraction_plugin = AIExtractionPlugin(
            model=self.model,
            task=task,
            output_schema=output,
        )
        
        # 5. Отримуємо plugins з kwargs або створюємо список
        plugins = crawler_kwargs.pop('plugins', [])
        plugins.append(extraction_plugin)
        
        # 6. Запускаємо краулінг
        try:
            # Імпортуємо crawl_async з API
            from graph_crawler.api import crawl_async
            
            graph = await crawl_async(
                url,
                crawl_context=context,
                stop_conditions=stop_conditions,
                control_channel=control_channel,
                plugins=plugins,
                max_depth=self.max_depth,
                **crawler_kwargs,
            )
            
            self._last_graph = graph
            
            # 7. Повертаємо результат
            if output:
                result = context.result
                if result:
                    logger.info(f"AI crawl completed with result: {type(result).__name__}")
                else:
                    logger.warning(
                        f"AI crawl completed but result incomplete. "
                        f"Missing fields: {context.get_missing_fields()}"
                    )
                return result
            else:
                # Без схеми - повертаємо текстовий результат
                return context.get('text_result')
                
        except Exception as e:
            logger.error(f"AI crawl failed: {e}", exc_info=True)
            raise
    
    def _build_stop_conditions(self, output: type[T] = None) -> List[IStopCondition]:
        """
        Створює список умов зупинки.
        
        Args:
            output: Pydantic схема (опціонально)
            
        Returns:
            Список IStopCondition
        """
        conditions = [
            MaxPagesStopCondition(self.max_pages),
        ]
        
        if output:
            # Зупинка коли схема заповнена
            conditions.append(SchemaCompleteStopCondition(output))
        else:
            # Зупинка коли target_found = True
            conditions.append(TargetFoundStopCondition())
        
        # Додаємо користувацькі умови
        conditions.extend(self.additional_stop_conditions)
        
        return conditions
    
    @property
    def last_context(self) -> Optional[CrawlContext]:
        """Контекст останнього краулінгу."""
        return self._last_context
    
    @property
    def last_graph(self):
        """Граф останнього краулінгу."""
        return self._last_graph
    
    def get_crawl_stats(self) -> Dict[str, Any]:
        """
        Статистика останнього краулінгу.
        
        Returns:
            Словник зі статистикою
        """
        if not self._last_context:
            return {}
        
        return {
            "pages_visited": self._last_context.pages_visited,
            "target_found": self._last_context.target_found,
            "result_complete": self._last_context.result_complete,
            "result_completeness": f"{self._last_context.result_completeness:.1%}",
            "missing_fields": self._last_context.get_missing_fields(),
            "errors_count": len(self._last_context.errors),
            "extracted_data": self._last_context.extracted_data,
        }
    
    def __repr__(self) -> str:
        return (
            f"AIAgent("
            f"model={self.model.model_name}, "
            f"max_pages={self.max_pages}, "
            f"max_depth={self.max_depth})"
        )
