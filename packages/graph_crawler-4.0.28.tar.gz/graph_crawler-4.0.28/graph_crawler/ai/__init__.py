"""AI Agent Integration Module.

Компоненти для інтеграції AI в graph_crawler:
- AIAgent: High-level інтерфейс для AI-керованого краулінгу
- OpenAIModel: Реалізація ILanguageModel для OpenAI
- AnthropicModel: Реалізація ILanguageModel для Anthropic
- AIExtractionPlugin: Плагін для AI-based extraction

Приклад використання:
    ```python
    from graph_crawler.ai import AIAgent, OpenAIModel
    from pydantic import BaseModel
    
    class ProductInfo(BaseModel):
        name: str
        price: float
        description: str = None
    
    model = OpenAIModel(api_key="sk-...")
    agent = AIAgent(model=model, max_pages=30)
    
    result = await agent.crawl(
        "https://shop.com/products/123",
        task="Знайди інформацію про цей продукт",
        output=ProductInfo
    )
    
    print(result.name)   # "iPhone 15"
    print(result.price)  # 999.0
    ```
"""

from graph_crawler.ai.agent import AIAgent
from graph_crawler.ai.models.openai_model import OpenAIModel
from graph_crawler.ai.models.anthropic_model import AnthropicModel
from graph_crawler.ai.models.emergent_model import EmergentModel
from graph_crawler.ai.extraction_plugin import AIExtractionPlugin

__all__ = [
    "AIAgent",
    "OpenAIModel",
    "AnthropicModel",
    "EmergentModel",
    "AIExtractionPlugin",
]
