"""LLM Models - реалізації ILanguageModel для різних провайдерів.

Доступні моделі:
- OpenAIModel: GPT-4, GPT-4o, GPT-4o-mini
- AnthropicModel: Claude 3, Claude 3.5
- EmergentModel: Universal key для OpenAI, Anthropic, Gemini

Приклад:
    ```python
    from graph_crawler.ai.models import OpenAIModel, AnthropicModel, EmergentModel
    
    # OpenAI
    openai = OpenAIModel(api_key="sk-...", model="gpt-4o-mini")
    
    # Anthropic
    anthropic = AnthropicModel(api_key="sk-ant-...", model="claude-3-sonnet-20240229")
    
    # Emergent Universal Key
    emergent = EmergentModel(api_key="sk-emergent-...", provider="openai", model="gpt-4o-mini")
    ```
"""

from graph_crawler.ai.models.openai_model import OpenAIModel
from graph_crawler.ai.models.anthropic_model import AnthropicModel
from graph_crawler.ai.models.emergent_model import EmergentModel

__all__ = [
    "OpenAIModel",
    "AnthropicModel",
    "EmergentModel",
]
