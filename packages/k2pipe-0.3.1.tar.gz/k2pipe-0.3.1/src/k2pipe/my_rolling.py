import pandas as pd
import re
from pandas.api.types import is_integer_dtype


@pd.api.extensions.register_dataframe_accessor("my_rolling")
class GroupedRollingAccessor:
    def __init__(self, pandas_obj):
        self._obj = pandas_obj

    def __call__(self, window, group_col='window_index'):
        # 解析 window 字符串，如 '2P' -> window_size=2
        if isinstance(window, str):
            match = re.match(r'^(\d+)P$', window)
            if not match:
                raise ValueError(f"Unsupported window format: {window}. Use e.g., '2P' for 2 points.")
            window_size = int(match.group(1))
        elif isinstance(window, int):
            window_size = window
        else:
            raise TypeError("window must be an integer or a string like '2P'.")

        if group_col not in self._obj.columns:
            raise KeyError(f"Group column '{group_col}' not found in DataFrame.")

        # 检查 group_col 是否为整数类型（逻辑分组通常为整数）
        if not is_integer_dtype(self._obj[group_col]):
            raise TypeError(f"Group column '{group_col}' must be integer type for logical grouping.")

        return GroupedRolling(self._obj, window_size, group_col)


class GroupedRolling:
    def __init__(self, df, window_size, group_col):
        self.df = df
        self.window_size = window_size
        self.group_col = group_col

    def mean(self):
        return self._apply_agg('mean')

    def sum(self):
        return self._apply_agg('sum')

    def min(self):
        return self._apply_agg('min')

    def max(self):
        return self._apply_agg('max')

    def std(self):
        return self._apply_agg('std')

    def _apply_agg(self, func_name):
        result_dfs = []
        for name, group in self.df.groupby(self.group_col, sort=False):
            # 对每个数值列应用 rolling
            numeric_cols = group.select_dtypes(include='number').columns
            if len(numeric_cols) == 0:
                continue
            rolled = getattr(group[numeric_cols].rolling(window=self.window_size), func_name)()
            rolled[self.group_col] = group[self.group_col].values  # 保留分组列
            # 非数值列保留原值（可选）
            for col in group.columns:
                if col not in numeric_cols and col != self.group_col:
                    rolled[col] = group[col].values
            rolled.index = group.index
            result_dfs.append(rolled)

        if not result_dfs:
            return pd.DataFrame(index=self.df.index)

        result = pd.concat(result_dfs, axis=0).reindex(self.df.index)
        return result