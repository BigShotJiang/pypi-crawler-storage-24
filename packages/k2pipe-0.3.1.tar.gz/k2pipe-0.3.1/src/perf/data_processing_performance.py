import sys, time, argparse, cProfile, pstats, json, resource, contextlib
from typing import Optional, Dict, List, Any, Tuple
from pathlib import Path
from dataclasses import dataclass
from enum import Enum
import pandas as pd
import numpy as np
from joblib import Parallel, delayed

root = Path(__file__).resolve().parents[1]  # k2pipe/
sys.path.insert(0, str(root / "src"))
from k2pipe.pipe import init_pipe  # noqa

init_pipe()


class DataType(Enum):
    INT = "int"
    INT64 = "int64"
    FLOAT = "float"
    FLOAT64 = "float64"
    STR = "str"
    STRING = "string"
    DATETIME = "datetime"
    BOOL = "bool"


@dataclass
class ColumnSpec:
    name: str
    dtype: DataType
    min_val: Optional[float] = None
    max_val: Optional[float] = None
    categories: Optional[List[str]] = None


def mem_usage_mb():
    try:
        import psutil

        return psutil.Process().memory_info().rss / 1024 / 1024
    except Exception:
        try:
            rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            return rss / 1024 / 1024 if sys.platform == "darwin" else rss / 1024
        except Exception:
            return None


@contextlib.contextmanager
def time_block(label, collector):
    t0 = time.perf_counter()
    c0 = time.process_time()
    m0 = mem_usage_mb()
    yield
    m1 = mem_usage_mb()
    collector.append(
        {
            "label": label,
            "wall_s": round(time.perf_counter() - t0, 6),
            "cpu_s": round(time.process_time() - c0, 6),
            "mem_mb": m1,
            "mem_delta_mb": round(m1 - m0, 2) if m0 and m1 else None,
        }
    )


def benchmark_method(df: pd.DataFrame, method_name: str, method_func, repeat: int = 3, **kwargs):
    times = []
    mem_before = mem_usage_mb()
    for _ in range(repeat):
        t0 = time.perf_counter()
        result = method_func(df, **kwargs)
        times.append(time.perf_counter() - t0)
    mem_after = mem_usage_mb()
    return {
        "method": method_name,
        "repeat": repeat,
        "min_s": round(min(times), 6),
        "max_s": round(max(times), 6),
        "avg_s": round(sum(times) / len(times), 6),
        "mem_mb": mem_after,
        "mem_delta_mb": round(mem_after - mem_before, 2) if mem_before and mem_after else None,
    }


def make_synthetic(
    rows=500_000,
    num_cols=5,
    num_devices=50,
    seed=42,
    col_specs: Optional[List[ColumnSpec]] = None,
):
    rs = np.random.default_rng(seed)
    data = {
        "k_device": rs.choice([f"dev{i}" for i in range(num_devices)], size=rows),
        "k_ts": pd.date_range("2025-01-01", periods=rows, freq="s"),
    }
    
    if col_specs:
        for spec in col_specs:
            if spec.dtype == DataType.INT or spec.dtype == DataType.INT64:
                min_v = int(spec.min_val) if spec.min_val is not None else 0
                max_v = int(spec.max_val) if spec.max_val is not None else 1000
                data[spec.name] = rs.integers(min_v, max_v, size=rows, dtype=np.int64 if spec.dtype == DataType.INT64 else np.int32)
            elif spec.dtype == DataType.FLOAT or spec.dtype == DataType.FLOAT64:
                min_v = spec.min_val if spec.min_val is not None else 0.0
                max_v = spec.max_val if spec.max_val is not None else 1000.0
                data[spec.name] = rs.uniform(min_v, max_v, size=rows).astype(np.float64 if spec.dtype == DataType.FLOAT64 else np.float32)
            elif spec.dtype == DataType.STR or spec.dtype == DataType.STRING:
                if spec.categories:
                    data[spec.name] = rs.choice(spec.categories, size=rows)
                else:
                    data[spec.name] = [f"str_{i}" for i in rs.integers(0, 10000, size=rows)]
                if spec.dtype == DataType.STRING:
                    data[spec.name] = pd.array(data[spec.name], dtype="string")
            elif spec.dtype == DataType.DATETIME:
                start = pd.Timestamp("2025-01-01")
                end = pd.Timestamp("2025-12-31")
                timestamps = pd.date_range(start, end, periods=rows)
                data[spec.name] = rs.choice(timestamps, size=rows)
            elif spec.dtype == DataType.BOOL:
                data[spec.name] = rs.choice([True, False], size=rows)
    else:
        for i in range(num_cols):
            data[f"col{i+1}"] = rs.integers(0, 1000, size=rows)
    
    return pd.DataFrame(data)

def write_csv(df, path, chunksize=100_000):
    path.parent.mkdir(parents=True, exist_ok=True)
    first = True
    for i in range(0, len(df), chunksize):
        chunk = df.iloc[i : i + chunksize]
        chunk.to_csv(path, mode="a", header=first, index=False)
        first = False

def load_chunks(csv_path, chunksize):
    for chunk in pd.read_csv(csv_path, chunksize=chunksize):
        yield chunk

def process_chunk(idx, chunk, config):
    init_pipe()
    t0 = time.perf_counter()
    df = chunk.extract_features(config)
    return idx, df, time.perf_counter() - t0


def get_operation_configs() -> Dict[str, pd.DataFrame]:
    return {
        "select_only": pd.DataFrame({
            "feature": ["select"],
            "expression": ["k_device,k_ts"]
        }),
        "compute_add": pd.DataFrame({
            "feature": ["sum_col"],
            "expression": ["col1+col2"]
        }),
        "compute_multiply": pd.DataFrame({
            "feature": ["mul_col"],
            "expression": ["col1*col2"]
        }),
        "compute_divide": pd.DataFrame({
            "feature": ["div_col"],
            "expression": ["col1/col2"]
        }),
        "rolling_mean": pd.DataFrame({
            "feature": ["rolling_mean"],
            "expression": ["col1.rolling(3).mean()"]
        }),
        "rolling_sum": pd.DataFrame({
            "feature": ["rolling_sum"],
            "expression": ["col1.rolling(5).sum()"]
        }),
        "where_simple": pd.DataFrame({
            "feature": ["where_col"],
            "expression": ["where(col1 > 50, col1, col2)"]
        }),
        "where_nested": pd.DataFrame({
            "feature": ["where_nested"],
            "expression": ["where(col1 > 50, where(col2 > 30, col1, col2), col2*2)"]
        }),
        "string_operation": pd.DataFrame({
            "feature": ["str_col"],
            "expression": ["k_device.str.upper()"]
        }),
        "datetime_operation": pd.DataFrame({
            "feature": ["dt_col"],
            "expression": ["k_ts.dt.dayofyear + k_ts.dt.hour / 24.0"]
        }),
        "complex_multi": pd.DataFrame({
            "feature": ["feat1", "feat2", "feat3", "select"],
            "expression": [
                "col1+col2",
                "feat1.rolling(3).mean()",
                "where(feat2 > 100, feat2, col1)",
                "k_device,k_ts,feat1,feat2,feat3"
            ]
        }),
    }


def analyze_performance(result: Dict[str, Any]) -> Dict[str, Any]:
    """分析性能测试结果，识别性能问题"""
    if "operations" not in result:
        return {}
    
    operations = result["operations"]
    valid_ops = {k: v for k, v in operations.items() if "avg_s" in v}
    
    if not valid_ops:
        return {}
    
    analysis = {
        "performance_issues": [],
        "recommendations": [],
        "statistics": {}
    }
    
    times = [v["avg_s"] for v in valid_ops.values()]
    avg_time = sum(times) / len(times)
    median_time = sorted(times)[len(times) // 2]
    
    analysis["statistics"] = {
        "avg_time_s": round(avg_time, 4),
        "median_time_s": round(median_time, 4),
        "min_time_s": round(min(times), 4),
        "max_time_s": round(max(times), 4),
    }
    
    slow_ops = []
    fast_ops = []
    
    for op_name, op_stats in valid_ops.items():
        time_s = op_stats["avg_s"]
        throughput = result["config"]["rows"] / time_s if time_s > 0 else 0
        
        if time_s > avg_time * 2:
            slow_ops.append({
                "operation": op_name,
                "time_s": round(time_s, 4),
                "throughput_rows_per_s": round(throughput, 1),
                "severity": "high" if time_s > avg_time * 3 else "medium",
                "mem_delta_mb": op_stats.get("mem_delta_mb")
            })
        elif time_s < avg_time * 0.5:
            fast_ops.append({
                "operation": op_name,
                "time_s": round(time_s, 4),
                "throughput_rows_per_s": round(throughput, 1)
            })
    
    analysis["performance_issues"] = slow_ops
    
    if slow_ops:
        high_severity = [op for op in slow_ops if op["severity"] == "high"]
        if high_severity:
            analysis["recommendations"].append(
                f"发现 {len(high_severity)} 个严重性能瓶颈，建议优先优化"
            )
        
        for op in slow_ops[:3]:
            if op["severity"] == "high":
                analysis["recommendations"].append(
                    f"  - {op['operation']}: {op['time_s']}s (平均值的 {op['time_s']/avg_time:.1f}x 倍)"
                )
                if op.get("mem_delta_mb") and op["mem_delta_mb"] > 500:
                    analysis["recommendations"].append(
                        f"    内存使用增加 {op['mem_delta_mb']:.1f}MB，可能存在内存泄漏或过度复制"
                    )
    
    if result.get("format_columns"):
        fc_time = result["format_columns"]["avg_s"]
        if fc_time > avg_time:
            analysis["recommendations"].append(
                f"format_columns 耗时 {fc_time:.4f}s，超过平均操作时间，建议检查数据类型转换"
            )
    
    throughputs = [result["config"]["rows"] / v["avg_s"] for v in valid_ops.values() if v["avg_s"] > 0]
    if throughputs:
        analysis["statistics"]["avg_throughput_rows_per_s"] = round(sum(throughputs) / len(throughputs), 1)
        analysis["statistics"]["min_throughput_rows_per_s"] = round(min(throughputs), 1)
        analysis["statistics"]["max_throughput_rows_per_s"] = round(max(throughputs), 1)
    
    return analysis


def get_pandas_direct_operation(op_name: str, df: pd.DataFrame):
    """获取直接 pandas 操作的函数"""
    def select_only(df_in):
        return df_in[['k_device', 'k_ts']]
    
    def compute_add(df_in):
        result = df_in.copy()
        result['sum_col'] = df_in['col1'] + df_in['col2']
        return result
    
    def compute_multiply(df_in):
        result = df_in.copy()
        result['mul_col'] = df_in['col1'] * df_in['col2']
        return result
    
    def compute_divide(df_in):
        result = df_in.copy()
        result['div_col'] = df_in['col1'] / df_in['col2']
        return result
    
    def rolling_mean(df_in):
        result = df_in.copy()
        result['rolling_mean'] = df_in['col1'].rolling(3).mean()
        return result
    
    def rolling_sum(df_in):
        result = df_in.copy()
        result['rolling_sum'] = df_in['col1'].rolling(5).sum()
        return result
    
    def where_simple(df_in):
        result = df_in.copy()
        result['where_col'] = np.where(df_in['col1'] > 50, df_in['col1'], df_in['col2'])
        return result
    
    def where_nested(df_in):
        result = df_in.copy()
        inner = np.where(df_in['col2'] > 30, df_in['col1'], df_in['col2'])
        result['where_nested'] = np.where(df_in['col1'] > 50, inner, df_in['col2'] * 2)
        return result
    
    def string_operation(df_in):
        result = df_in.copy()
        result['str_col'] = df_in['k_device'].str.upper()
        return result
    
    def datetime_operation(df_in):
        result = df_in.copy()
        result['dt_col'] = df_in['k_ts'].dt.dayofyear + df_in['k_ts'].dt.hour / 24.0
        return result
    
    def complex_multi(df_in):
        result = df_in.copy()
        result['feat1'] = df_in['col1'] + df_in['col2']
        result['feat2'] = result['feat1'].rolling(3).mean()
        result['feat3'] = np.where(result['feat2'] > 100, result['feat2'], df_in['col1'])
        return result[['k_device', 'k_ts', 'feat1', 'feat2', 'feat3']]
    
    operations = {
        "select_only": select_only,
        "compute_add": compute_add,
        "compute_multiply": compute_multiply,
        "compute_divide": compute_divide,
        "rolling_mean": rolling_mean,
        "rolling_sum": rolling_sum,
        "where_simple": where_simple,
        "where_nested": where_nested,
        "string_operation": string_operation,
        "datetime_operation": datetime_operation,
        "complex_multi": complex_multi,
    }
    
    return operations.get(op_name)


def compare_with_pandas(df: pd.DataFrame, op_name: str, config: pd.DataFrame) -> Dict[str, Any]:
    """对比 extract_features 与直接 pandas 操作的性能"""
    results = {}
    
    def method_extract_features(df_in, cfg=config):
        return df_in.extract_features(cfg)
    
    pandas_func = get_pandas_direct_operation(op_name, df)
    
    methods = [("extract_features", method_extract_features)]
    
    if pandas_func:
        def method_pandas_direct(df_in, func=pandas_func):
            return func(df_in)
        methods.append(("pandas_direct", method_pandas_direct))
    
    for name, method in methods:
        try:
            stats = benchmark_method(df, name, method, repeat=3)
            results[name] = stats
        except Exception as e:
            results[name] = {"error": str(e)}
    
    if len(results) == 2 and "extract_features" in results and "pandas_direct" in results:
        ef_time = results["extract_features"].get("avg_s", 0)
        pd_time = results["pandas_direct"].get("avg_s", 0)
        if ef_time > 0 and pd_time > 0:
            results["comparison"] = {
                "extract_features_time_s": round(ef_time, 6),
                "pandas_direct_time_s": round(pd_time, 6),
                "speedup": round(pd_time / ef_time, 3) if ef_time > 0 else 0,
                "overhead_percent": round((ef_time - pd_time) / pd_time * 100, 2) if pd_time > 0 else 0,
            }
    
    return results

def verify_export(path: Path, expected_rows: Optional[int], expected_cols: Optional[int]):
    if not path.exists():
        return False, "export file missing"
    header = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    if not header:
        return False, "export file empty"
    cols = len(header[0].split(","))
    if expected_cols is not None and cols != expected_cols:
        return False, f"col mismatch {cols}!={expected_cols}"
    if expected_rows is not None:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            row_cnt = sum(1 for _ in f) - 1
        if row_cnt != expected_rows:
            return False, f"row mismatch {row_cnt}!={expected_rows}"
    return True, "ok"


def run_comprehensive_benchmark(args, rows_override=None):
    rows = rows_override if rows_override is not None else args.rows
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    
    phases: List[dict] = []
    all_results = {}
    
    col_specs = None
    if args.data_types:
        col_specs = []
        type_map = {
            "int": DataType.INT,
            "int64": DataType.INT64,
            "float": DataType.FLOAT,
            "float64": DataType.FLOAT64,
            "str": DataType.STR,
            "string": DataType.STRING,
            "datetime": DataType.DATETIME,
            "bool": DataType.BOOL,
        }
        types = [t.strip() for t in args.data_types.split(",")]
        for i, dtype_str in enumerate(types):
            if dtype_str in type_map:
                col_specs.append(ColumnSpec(
                    name=f"col{i+1}",
                    dtype=type_map[dtype_str],
                    min_val=0,
                    max_val=1000
                ))
    
    with time_block("make_synthetic", phases):
        df_syn = make_synthetic(
            rows=rows,
            num_cols=args.num_cols,
            num_devices=args.num_devices,
            seed=args.seed,
            col_specs=col_specs
        )
    
    print(f"\n数据生成完成: {len(df_syn)} 行, {len(df_syn.columns)} 列")
    print(f"数据类型: {df_syn.dtypes.to_dict()}")
    
    with time_block("format_columns", phases):
        df_syn = df_syn.format_columns()
    
    operation_configs = get_operation_configs()
    operation_results = {}
    
    for op_name, config in operation_configs.items():
        if args.operations and op_name not in args.operations.split(","):
            continue
        
        required_cols = set()
        for _, row in config.iterrows():
            expr = str(row.get('expression', ''))
            if 'col1' in expr:
                required_cols.add('col1')
            if 'col2' in expr:
                required_cols.add('col2')
            if 'col3' in expr:
                required_cols.add('col3')
        
        if required_cols and not all(col in df_syn.columns for col in required_cols):
            print(f"\n跳过操作 {op_name}: 缺少必需的列 {required_cols - set(df_syn.columns)}")
            continue
        
        print(f"\n测试操作: {op_name}")
        try:
            with time_block(f"operation_{op_name}", phases):
                result_df = df_syn.extract_features(config)
            
            def benchmark_extract(df, cfg=config):
                return df.extract_features(cfg)
            
            op_stats = benchmark_method(
                df_syn,
                f"extract_features_{op_name}",
                benchmark_extract,
                repeat=args.repeat
            )
            
            if args.compare_pandas:
                pandas_compare = compare_with_pandas(df_syn, op_name, config)
                op_stats["pandas_comparison"] = pandas_compare
                if "comparison" in pandas_compare:
                    comp = pandas_compare["comparison"]
                    print(f"    vs pandas_direct: {comp['pandas_direct_time_s']:.4f}s, "
                          f"开销: {comp['overhead_percent']:+.1f}%, "
                          f"加速比: {comp['speedup']:.2f}x")
            
            op_stats["output_rows"] = len(result_df)
            op_stats["output_cols"] = len(result_df.columns)
            operation_results[op_name] = op_stats
            print(f"  {op_name}: {op_stats['avg_s']:.4f}s (avg)")
            
        except Exception as e:
            operation_results[op_name] = {"error": str(e)}
            print(f"  {op_name}: 错误 - {e}")
    
    format_columns_stats = benchmark_method(
        df_syn,
        "format_columns",
        lambda df: df.format_columns(),
        repeat=args.repeat
    )
    
    all_results = {
        "config": {
            "rows": rows,
            "num_cols": args.num_cols,
            "num_devices": args.num_devices,
            "data_types": args.data_types,
            "operations": args.operations,
            "repeat": args.repeat,
        },
        "data_info": {
            "rows": len(df_syn),
            "cols": len(df_syn.columns),
            "dtypes": {str(k): str(v) for k, v in df_syn.dtypes.to_dict().items()},
            "memory_usage_mb": round(df_syn.memory_usage(deep=True).sum() / 1024 / 1024, 2),
        },
        "phases": phases,
        "operations": operation_results,
        "format_columns": format_columns_stats,
    }
    
    return all_results


def run_scale_test(args):
    if not args.scale_rows:
        return None
    
    scale_rows = [int(x.strip()) for x in args.scale_rows.split(",") if x.strip()]
    scale_results = []
    
    for rows in scale_rows:
        print(f"\n{'='*60}")
        print(f"测试数据量: {rows:,} 行")
        print(f"{'='*60}")
        result = run_comprehensive_benchmark(args, rows_override=rows)
        scale_results.append(result)
    
    comparison = {
        "scale_test": True,
        "results": scale_results,
        "summary": []
    }
    
    for r in scale_results:
        if "operations" in r:
            for op_name, op_stats in r["operations"].items():
                if "avg_s" in op_stats:
                    comparison["summary"].append({
                        "rows": r["config"]["rows"],
                        "operation": op_name,
                        "avg_time_s": op_stats["avg_s"],
                        "throughput_rows_per_s": round(r["config"]["rows"] / op_stats["avg_s"], 1) if op_stats["avg_s"] > 0 else 0
                    })
    
    return comparison


def main():
    parser = argparse.ArgumentParser(
        description="k2pipe 性能基准测试工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 基础测试
  python data_processing_performance.py --rows 100000

  # 测试不同数据类型
  python data_processing_performance.py --rows 100000 --data-types int,float,str,datetime

  # 测试特定操作
  python data_processing_performance.py --rows 100000 --operations compute_add,rolling_mean,where_simple

  # 数据量扩展测试
  python data_processing_performance.py --scale-rows 10000,100000,1000000

  # 禁用pandas对比（默认开启）
  python data_processing_performance.py --rows 100000 --no-compare-pandas

  # 生成详细报告
  python data_processing_performance.py --rows 100000 --report report.json
        """
    )
    
    parser.add_argument("--rows", type=int, default=100_000, help="测试数据行数")
    parser.add_argument("--num-cols", type=int, default=5, help="列数量")
    parser.add_argument("--num-devices", type=int, default=100, help="设备数量")
    parser.add_argument("--seed", type=int, default=42, help="随机种子")
    parser.add_argument("--output-dir", type=str, default=str(root / "tmp"), help="输出目录")
    
    parser.add_argument(
        "--data-types",
        type=str,
        help="数据类型列表，逗号分隔: int,int64,float,float64,str,string,datetime,bool"
    )
    
    parser.add_argument(
        "--operations",
        type=str,
        help="要测试的操作列表，逗号分隔。可选: select_only,compute_add,compute_multiply,compute_divide,rolling_mean,rolling_sum,where_simple,where_nested,string_operation,datetime_operation,complex_multi"
    )
    
    parser.add_argument(
        "--scale-rows",
        type=str,
        help="数据量扩展测试，逗号分隔的行数列表，如: 10000,100000,1000000"
    )
    
    parser.add_argument("--repeat", type=int, default=3, help="每个测试重复次数")
    parser.add_argument("--compare-pandas", action="store_true", default=True, help="与直接pandas操作对比（默认开启）")
    parser.add_argument("--no-compare-pandas", dest="compare_pandas", action="store_false", help="禁用pandas对比")
    parser.add_argument("--report", type=str, help="保存详细报告到JSON文件")
    parser.add_argument("--stats", action="store_true", help="打印cProfile累计耗时前20")
    parser.add_argument("--profile", action="store_true", help="生成cProfile输出文件 prof.out")
    parser.add_argument("--analyze", action="store_true", default=True, help="自动分析性能问题（默认开启）")
    parser.add_argument("--no-analyze", dest="analyze", action="store_false", help="禁用性能分析")
    
    args = parser.parse_args()

    if args.profile or args.stats:
        pr = cProfile.Profile()
        pr.enable()
        if args.scale_rows:
            result = run_scale_test(args)
        else:
            result = run_comprehensive_benchmark(args)
        pr.disable()
        pr.dump_stats("prof.out")
        if args.profile:
            print("\ncProfile 输出: prof.out")
        if args.stats:
            print("\n累计耗时前20:")
            pstats.Stats(pr).strip_dirs().sort_stats("cumulative").print_stats(20)
    else:
        if args.scale_rows:
            result = run_scale_test(args)
        else:
            result = run_comprehensive_benchmark(args)
    
    if result:
        print("\n" + "="*60)
        print("测试完成")
        print("="*60)
        
        if args.report:
            report_path = Path(args.report).expanduser().resolve()
            report_path.write_text(
                json.dumps(result, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
            print(f"\n详细报告已保存到: {report_path}")
        
        if isinstance(result, dict) and "operations" in result:
            print("\n操作性能汇总 (按耗时排序):")
            print("-" * 60)
            
            ops_list = []
            for op_name, op_stats in result["operations"].items():
                if "avg_s" in op_stats:
                    ops_list.append((op_name, op_stats))
                elif "error" in op_stats:
                    print(f"  {op_name:20s}: 错误 - {op_stats['error']}")
            
            ops_list.sort(key=lambda x: x[1]["avg_s"])
            
            for op_name, op_stats in ops_list:
                throughput = result["config"]["rows"] / op_stats['avg_s'] if op_stats['avg_s'] > 0 else 0
                mem_info = ""
                if op_stats.get("mem_delta_mb"):
                    mem_info = f", 内存: {op_stats['mem_delta_mb']:+.1f}MB"
                
                pandas_info = ""
                if op_stats.get("pandas_comparison") and "comparison" in op_stats["pandas_comparison"]:
                    comp = op_stats["pandas_comparison"]["comparison"]
                    pandas_info = f", vs pandas: {comp['overhead_percent']:+.1f}%"
                
                print(f"  {op_name:20s}: {op_stats['avg_s']:8.4f}s (avg), "
                      f"{op_stats['min_s']:8.4f}s (min), "
                      f"{op_stats['max_s']:8.4f}s (max), "
                      f"吞吐量: {throughput:8,.0f} 行/秒{mem_info}{pandas_info}")
            
            if args.analyze:
                analysis = analyze_performance(result)
            else:
                analysis = None
            
            if analysis:
                print("\n" + "="*60)
                print("性能分析")
                print("="*60)
                
                if analysis.get("statistics"):
                    stats = analysis["statistics"]
                    print(f"\n统计信息:")
                    print(f"  平均耗时: {stats.get('avg_time_s', 0):.4f}s")
                    print(f"  中位数耗时: {stats.get('median_time_s', 0):.4f}s")
                    print(f"  最快: {stats.get('min_time_s', 0):.4f}s")
                    print(f"  最慢: {stats.get('max_time_s', 0):.4f}s")
                    if "avg_throughput_rows_per_s" in stats:
                        print(f"  平均吞吐量: {stats['avg_throughput_rows_per_s']:,} 行/秒")
                        print(f"  吞吐量范围: {stats['min_throughput_rows_per_s']:,} - {stats['max_throughput_rows_per_s']:,} 行/秒")
                
                if analysis.get("performance_issues"):
                    print(f"\n⚠️  发现 {len(analysis['performance_issues'])} 个性能问题:")
                    print("-" * 60)
                    for issue in analysis["performance_issues"]:
                        severity_icon = "🔴" if issue["severity"] == "high" else "🟡"
                        print(f"  {severity_icon} {issue['operation']:20s}: {issue['time_s']:.4f}s "
                              f"(吞吐量: {issue['throughput_rows_per_s']:,.0f} 行/秒)")
                        if issue.get("mem_delta_mb"):
                            print(f"     内存变化: {issue['mem_delta_mb']:+.1f}MB")
                
                if analysis.get("recommendations"):
                    print(f"\n💡 优化建议:")
                    print("-" * 60)
                    for rec in analysis["recommendations"]:
                        print(f"  {rec}")
                
                pandas_comparisons = []
                for op_name, op_stats in result["operations"].items():
                    if op_stats.get("pandas_comparison") and "comparison" in op_stats["pandas_comparison"]:
                        comp = op_stats["pandas_comparison"]["comparison"]
                        pandas_comparisons.append({
                            "operation": op_name,
                            "overhead_percent": comp["overhead_percent"],
                            "speedup": comp["speedup"]
                        })
                
                if pandas_comparisons:
                    print(f"\n📊 Pandas 对比汇总:")
                    print("-" * 60)
                    pandas_comparisons.sort(key=lambda x: abs(x["overhead_percent"]), reverse=True)
                    for comp in pandas_comparisons:
                        if comp["overhead_percent"] > 20:
                            print(f"  ⚠️  {comp['operation']:20s}: extract_features 比 pandas 慢 {comp['overhead_percent']:.1f}% "
                                  f"(pandas 快 {comp['speedup']:.2f}x)")
                        elif comp["overhead_percent"] < -10:
                            print(f"  ✅ {comp['operation']:20s}: extract_features 比 pandas 快 {abs(comp['overhead_percent']):.1f}% "
                                  f"(快 {comp['speedup']:.2f}x)")
                        else:
                            print(f"  ✓  {comp['operation']:20s}: 性能接近 pandas (差异 {comp['overhead_percent']:+.1f}%)")
                
                if args.report and analysis:
                    result["performance_analysis"] = analysis
        
        if isinstance(result, dict) and "scale_test" in result and result["scale_test"]:
            print("\n数据量扩展测试汇总:")
            print("-" * 60)
            for item in result.get("summary", []):
                print(f"  {item['rows']:10,} 行, {item['operation']:20s}: "
                      f"{item['avg_time_s']:8.4f}s, "
                      f"吞吐量: {item['throughput_rows_per_s']:10,.1f} 行/秒")

if __name__ == "__main__":
    main()