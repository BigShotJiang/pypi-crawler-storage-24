from data_validator.commands import entry

if __name__ == "__main__":
    entry()
