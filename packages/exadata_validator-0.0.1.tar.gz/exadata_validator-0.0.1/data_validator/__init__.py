"""Standalone validator package."""
