"""
ServicePortal - Main Framework Class

This module provides the core ServicePortal class that integrates:
- HTTP REST API endpoints (existing functionality)
- WebSocket real-time events (new functionality)
- Security via GatePipeline (shared between HTTP and WebSocket)
- Auto-discovery of routes
- API documentation generation
- Metrics and monitoring

The class is designed to be backward compatible - existing HTTP-only
applications continue to work without modification. WebSocket features
are opt-in via parameters and decorators.

WEBSOCKET WORKER: This framework uses EVENTLET exclusively.
"""

import os
import uuid
import inspect
import traceback
import json
import importlib.util
import logging
from typing import Callable, Any, Optional, Dict, List, Union
from flask import Flask, request, jsonify, make_response
from flask_cors import CORS
import time
import threading
from dataclasses import dataclass, field
import heapq
from typing import get_args, get_origin, Annotated, Union as TypeUnion
import types

logger = logging.getLogger(__name__)

from .gate import GatePipeline, GateConfig, RequestContext, AuthType
from ..tokens import TokenManager, TokenRegistry
from ..dates import DateUtils
from ..customTypes import Options
from ..enforcer import enforce_requirements

# WebSocket modules (new)
from .websockets.engine import WebSocketEngine
from .websockets.security import setup_websocket_security
from .websockets.limits import setup_websocket_limits
from .websockets.protocol import setup_websocket_protocol
from .websockets.metrics import setup_websocket_metrics
from .websockets.config import WebSocketConfig


class MemoryStorage:
    """
    A thread-safe, size-limited, time-aware key-value store 
    with efficient expiration tracking.
    
    (Implementation unchanged - preserved exactly as original)
    """
    
    def __init__(
        self, 
        cleanup_interval: int = 60,
        max_size: int|None = 10_000,
        enable_background_cleanup: bool = True
    ):
        """
        Args:
            cleanup_interval: How often (in seconds) the background janitor runs.
            max_size: Maximum number of items to store (None for unlimited).
            enable_background_cleanup: Whether to run background cleanup thread.
        """
        self._data: dict[str, any] = {}
        self._expires: dict[str, float] = {}
        # Min-heap for efficient expiration tracking (expiry_time, key)
        self._expiry_heap: list[tuple[float, str]] = []
        self._max_size = max_size
        self._size = 0
        self._lock = threading.RLock()  # Reentrant lock for nested calls
        self._cleanup_enabled = enable_background_cleanup
        self._stop_event = threading.Event()
        
        # Only start background thread if enabled
        if self._cleanup_enabled:
            self._cleanup_thread = threading.Thread(
                target=self._background_janitor, 
                args=(cleanup_interval,),
                daemon=True,
                name="MemoryStorage-Janitor"
            )
            # Don't start immediately - let the app control lifecycle
            self._started = False

    def start(self):
        """Start the background cleanup thread."""
        if self._cleanup_enabled and not self._started:
            self._cleanup_thread.start()
            self._started = True
    
    def stop(self):
        """Stop the background cleanup thread."""
        if self._cleanup_enabled:
            self._stop_event.set()
            if self._cleanup_thread.is_alive():
                self._cleanup_thread.join(timeout=5.0)

    def _background_janitor(self, interval: int):
        """Background thread that periodically cleans expired items."""
        while not self._stop_event.is_set():
            # Wait for interval or stop signal
            self._stop_event.wait(interval)
            if not self._stop_event.is_set():
                self.flush_expired()

    def get(self, key: str, default: any = None) -> any:
        """
        Retrieves value; deletes it first if the TTL has expired.
        
        Returns:
            The value if found and not expired, otherwise default.
        """
        with self._lock:
            # Check expiration first (atomic operation)
            if self._is_expired(key):
                self._delete_internal(key)
                return default
            
            return self._data.get(key, default)

    def set(self, key: str, value: any, ttl: int|None = None) -> bool:
        """
        Stores a value with an optional lifespan (TTL).
        
        Returns:
            True if successful, False if max size reached (and no eviction policy).
        """
        with self._lock:
            # Check if we need to make room
            if (self._max_size is not None and 
                key not in self._data and 
                self._size >= self._max_size):
                # Apply LRU eviction policy (simple implementation)
                if not self._evict_oldest():
                    return False  # Could not make room
            
            # Track if this is a new key before writing
            is_new = key not in self._data
            
            # Store the value
            self._data[key] = value
            
            # Update size counter (only if new key)
            if is_new:
                self._size += 1
            
            # Set expiration if TTL provided
            if ttl:
                expiry_time = time.time() + ttl
                self._expires[key] = expiry_time
                heapq.heappush(self._expiry_heap, (expiry_time, key))
            elif key in self._expires:
                # Remove expiration if TTL is None/0
                del self._expires[key]
                # Note: The key will remain in heap but will be ignored on cleanup
                
            return True

    def delete(self, key: str) -> bool:
        """Delete a key if it exists."""
        with self._lock:
            return self._delete_internal(key)
    
    def _delete_internal(self, key: str) -> bool:
        """Internal delete without lock (caller must hold lock)."""
        if key in self._data:
            del self._data[key]
            if key in self._expires:
                del self._expires[key]
                # Note: We don't remove from heap here - cleanup will handle it
            self._size -= 1
            return True
        return False

    def _is_expired(self, key: str) -> bool:
        """Check if a key has expired (assumes caller holds lock)."""
        if key not in self._expires:
            return False
        return time.time() > self._expires[key]

    def _evict_oldest(self) -> bool:
        """
        Evict the oldest expired item, or if none expired, the item 
        closest to expiration.
        
        Returns:
            True if an item was evicted, False otherwise.
        """
        now = time.time()
        
        # First try to evict an expired item
        while self._expiry_heap and self._expiry_heap[0][0] <= now:
            expiry_time, key = heapq.heappop(self._expiry_heap)
            if key in self._expires and self._expires[key] == expiry_time:
                # Still valid (not manually deleted)
                self._delete_internal(key)
                return True
        
        # If no expired items, evict the one closest to expiration
        if self._expiry_heap:
            _, key_to_evict = self._expiry_heap[0]
            self._delete_internal(key_to_evict)
            # Remove from heap
            heapq.heappop(self._expiry_heap)
            return True
            
        return False

    def flush_expired(self) -> int:
        """
        Active cleanup: removes all expired items.
        
        Returns:
            Number of items cleaned up.
        """
        with self._lock:
            cleaned = 0
            now = time.time()
            
            # Process heap until we find unexpired items
            while self._expiry_heap and self._expiry_heap[0][0] <= now:
                expiry_time, key = heapq.heappop(self._expiry_heap)
                
                # Verify it hasn't been manually deleted or had TTL changed
                if (key in self._expires and 
                    self._expires[key] == expiry_time and 
                    now > expiry_time):
                    self._delete_internal(key)
                    cleaned += 1
                # If TTL was updated, the key will have new entry in heap
            
            return cleaned

    def clear(self):
        """Clear all data."""
        with self._lock:
            self._data.clear()
            self._expires.clear()
            self._expiry_heap.clear()
            self._size = 0

    def info(self) -> dict:
        """Get storage statistics."""
        with self._lock:
            return {
                "size": self._size,
                "max_size": self._max_size,
                "expiring_keys": len(self._expires),
                "heap_size": len(self._expiry_heap)
            }


@dataclass
class CrashReport:
    """
    Structured crash information passed to developer's crash handler.
    
    (Implementation unchanged - preserved exactly as original)
    """
    error_id: str
    exception: Exception
    traceback_str: str
    timestamp: str = field(default_factory=DateUtils.current_timestamp)
    request_path: str|None = None
    user_id: str|None = None
    request_data: dict|None = None
    
    @property
    def exception_type(self) -> str:
        """Get the exception class name."""
        return type(self.exception).__name__
    
    @property
    def exception_message(self) -> str:
        """Get the exception error message."""
        return str(self.exception)
    
    @property
    def formatted_traceback(self) -> str:
        """
        Get a cleaned, readable traceback string.
        Converts escape sequences (\n, \t) to actual characters.
        """
        # Replace escape sequences
        cleaned = self.traceback_str
        if '\\n' in cleaned:
            cleaned = cleaned.replace('\\n', '\n')
        if '\\t' in cleaned:
            cleaned = cleaned.replace('\\t', '\t')
        return cleaned.strip()
    
    def as_dict(self) -> dict:
        """
        Convert crash report to dictionary for easy serialization.
        
        Returns:
            Dictionary representation of the crash report
        """
        return {
            'error_id': self.error_id,
            'timestamp': self.timestamp,
            'exception_type': self.exception_type,
            'exception_message': self.exception_message,
            'traceback': self.formatted_traceback,
            'traceback_raw': self.traceback_str,  # Keep original for debugging
            'request_path': self.request_path,
            'user_id': self.user_id,
            'request_data': self.request_data
        }


class ServicePortal:
    """
    ServicePortal - Unified Framework for HTTP APIs and WebSocket Real-Time Events
    
    This class provides a comprehensive framework for building both traditional
    REST APIs and real-time WebSocket applications with a consistent developer
    experience.
    
    Key Features:
        - HTTP REST API endpoints via @endpoint decorator
        - WebSocket real-time events via @on_event decorator
        - Shared security via GatePipeline (works for both HTTP and WebSocket)
        - Automatic route discovery from ./routes unless different route directory specified
        - Built-in API documentation at /docs
        - Comprehensive metrics and monitoring for WebSocket
        - Crash handling and audit logging hooks
        - exclusively use **eventlet** as the websocket async worker
        
    Usage Examples:
        # HTTP-only mode (backward compatible)
        >>> portal = ServicePortal()
        >>> @portal.endpoint("/api/users")
        >>> def get_users():
        ...     return {"users": [...]}
        >>> portal.run(port=5000)
        
        # WebSocket + HTTP mode
        >>> portal = ServicePortal(
        ...     enable_websocket=True,
        ...     websocket_config=WebSocketConfig.production()
        ... )
        >>> @portal.on_event("chat.message", auth_required=True)
        ... def handle_chat(data):
        ...     return {"received": True}
        >>> portal.run(port=5000, use_websockets=True)
    """
    
    def __init__(
        self,
        *,
        debug: bool = False,
        admin_creds: tuple[str, str] = ("admin", "change_me"),
        token_type: Options[str, ["bearer", "api_key", "token_payload"]] = "bearer",
        cors_setup: Callable[[Flask], None] | None = None,
        storage_max_size: int = 10_000,
        default_tokenized_fields: list[str] | None = None,
        default_cookies: dict[str, dict] | None = None,
        enable_websocket: bool = False,
        websocket_config: Optional[WebSocketConfig] = None,
    ):
        """
        Initialize the ServicePortal instance.

        Args:
            debug: Enable Flask debug mode. Not recommended for production.
            admin_creds: Tuple of (username, password) for accessing the /docs endpoint.
                        Default credentials are insecure - always change them.
            token_type: Default token type for the TokenManager.
            cors_setup: Custom CORS configuration function. If None, applies permissive
                       CORS for development (insecure for production).
            storage_max_size: Maximum number of items to store in the MemoryStorage.
            default_tokenized_fields: List of field names to automatically tokenize
                                     in response data for all endpoints.
            default_cookies: A dictionary of cookie names and their properties 
                            to be applied to all responses by default.
            enable_websocket: Whether to enable WebSocket functionality. If False,
                             all WebSocket-related features are disabled and
                             @on_event decorator will raise an error if used.
            websocket_config: Configuration for WebSocket behavior. If None and
                             enable_websocket is True, default configuration is used.
            websocket_security_config: Security-specific configuration for WebSocket.
                                      If None, uses secure defaults.
        
        Warning:
            Default admin credentials are insecure! Always change them in production.
            Default CORS allows all origins - configure properly for production use.
        """
        self.app = Flask(self.__class__.__name__)
        self.debug = debug
        self.admin_creds = admin_creds
        self.default_cookies = default_cookies or {}
        self._running = False
        
        # Endpoint registry: path -> configuration dictionary
        self.registry: dict[str, dict] = {}
        
        # Initialize thread-safe storage with size limits
        self._gate_storage = MemoryStorage(
            cleanup_interval=60,
            max_size=storage_max_size,
            enable_background_cleanup=True
        )
        
        # Core service managers
        self.token_manager = TokenManager(default_type=token_type)
        self.gate_pipeline = GatePipeline(self.token_manager, self._gate_storage)

        # Tokenization configuration
        self.default_tokenized_fields = default_tokenized_fields or []
        
        # Developer extension hooks
        self._crash_handler: Callable[[CrashReport], None]|None = None
        self._audit_logger: Callable|None = None
        
        # Apply CORS configuration
        self._apply_cors(cors_setup)
        
        # Track execution context
        self._is_main = self._check_is_main()
        
        self._websocket_enabled = enable_websocket
        self._websocket_config = websocket_config or (
            WebSocketConfig.production() if not debug else WebSocketConfig.development()
        )
        
        # WebSocket component placeholders (lazy initialization)
        self._websocket_engine = None
        self._websocket_security = None
        self._websocket_limits = None
        self._websocket_protocol = None
        self._websocket_metrics = None
        
        # Holding pen for WebSocket event handlers
        # This allows defining events in any module during auto-discovery,
        # long before the server actually starts.
        self._socket_events: List[Dict[str, Any]] = []
        
        if self._websocket_enabled:
            logger.info("WebSocket mode enabled with config: %s", self._websocket_config)
    
    def _apply_cors(self, cors_setup: Callable[[Flask], None]|None) -> None:
        """
        Apply CORS configuration to the Flask application.
        """
        if cors_setup:
            cors_setup(self.app)
        else:
            # Development-only permissive CORS
            CORS(self.app)
            if not self.debug:
                logger.warning("Using permissive CORS. Configure CORS properly for production!")
    
    def on_crash(self, func: Callable[[CrashReport], None]) -> Callable[[CrashReport], None]:
        """
        Register a function to handle system crashes (uncaught exceptions).
        """
        self._crash_handler = func
        return func
    
    def on_audit(self, func: Callable) -> Callable:
        """
        Register a function to audit all API activity.
        """
        self._audit_logger = func
        return func
    
    def normalize_path(self, path: str) -> str:
        """
        Normalize URL paths by ensuring proper slash formatting.
        """
        parts = [part for part in path.split('/') if part]
        return '/' + '/'.join(parts)
    
    # ============================================================================
    # NEW: WebSocket Event Decorator
    # ============================================================================
    
    def on_event(self, event_name: str, *, auth_required: Optional[bool] = None):
        """
        Decorator to register a WebSocket event handler.
        
        This is the WebSocket equivalent of @endpoint. It registers a function
        to handle real-time events sent over WebSocket connections.
        
        The decorator stores the handler in a "holding pen" during the
        auto-discovery phase. When the server starts in WebSocket mode,
        all handlers are bound to the Socket.IO engine.
        
        Args:
            event_name: Name of the event to handle (e.g., 'chat.message',
                       'stock.update', 'game.move'). This is the event type
                       that clients will emit.
            auth_required: Whether this event requires authentication.
                          - True: Only authenticated connections can emit
                          - False: Public event (no auth required)
                          - None: Use default from WebSocketSecurityConfig
                          
        Returns:
            Decorator function that registers the handler.
            
        Raises:
            RuntimeError: If WebSocket is not enabled (enable_websocket=False)
                         when this decorator is used.
            
        Example:
            >>> @portal.on_event('chat.message', auth_required=True)
            >>> def handle_chat(data):
            ...     '''Process incoming chat messages.'''
            ...     print(f"Message: {data}")
            ...     return {"status": "received"}
            
            >>> @portal.on_event('public.announcement', auth_required=False)
            >>> def handle_announcement(data):
            ...     '''Public announcements - no login needed.'''
            ...     broadcast_to_all(data)
        """
        if not self._websocket_enabled:
            raise RuntimeError(
                "Cannot use @on_event decorator when WebSocket is disabled. "
                "Set enable_websocket=True in ServicePortal constructor."
            )
        
        def decorator(func: Callable) -> Callable:
            # Store in holding pen for later registration
            self._socket_events.append({
                'event': event_name,
                'handler': func,
                'auth_required': auth_required,
                'doc': func.__doc__.strip() if func.__doc__ else "No description provided."
            })
            
            # Log registration (useful for debugging)
            if self.debug:
                logger.debug("WebSocket event stored: %s", event_name)
            
            return func
        return decorator
    
    # ============================================================================
    # Original endpoint decorator (use this for non websocket communication)
    # ============================================================================
    
    def endpoint(
        self, 
        path: str, 
        /, 
        *, 
        gate: GateConfig|None = None,
        group: str = "General", 
        methods: list[str]|None = None,
        cookies: dict[str, dict]|None = None
    ) -> Callable:
        """
        Decorator to register an API endpoint with the ServicePortal.
        
        (Original method preserved exactly - unchanged)
        """
        clean_path = self.normalize_path(path)
        
        def decorator(func: Callable) -> Callable:
            try:
                enforced_func = enforce_requirements(func)
            except (AttributeError, ValueError, TypeError, SyntaxError) as e:
                # Log the error and re-raise to halt server startup for non-compliant endpoints
                logger.error("Endpoint '%s' failed enforcement: %s", clean_path, e)
                raise

            source_file = inspect.getfile(func)
            
            # Extract parameter metadata from function signature
            sig = inspect.signature(func)
            params_meta = {}
            
            for name, param in sig.parameters.items():
                if name in ['self', 'cls']:
                    continue
                
                type_display = "Any"
                annotation = param.annotation
                origin = get_origin(annotation)
                
                if origin is Annotated:
                    args = get_args(annotation)
                    base_type = args[0]
                    metadata = args[1]

                    # Duck-typing check for Definition's _SchemaDescriptor
                    if hasattr(metadata, 'schema') and isinstance(getattr(metadata, 'schema', None), dict):
                        schema_dict = metadata.schema
                        # Convert types to string names for display
                        schema_for_display = {
                            k: (str(v) if hasattr(v, '__name__') and v.__name__ == "Union" else getattr(v, '__name__', str(v))) 
                            for k, v in schema_dict.items()
                        }
                        schema_str = json.dumps(schema_for_display, indent=2)
                        type_display = f"dict (schema):\n{schema_str}"
                    # Check for Options
                    elif isinstance(metadata, str) and metadata.startswith("Options:"):
                        type_display = f"{getattr(base_type, '__name__', str(base_type))} ({metadata})"
                    else:
                        type_display = getattr(base_type, '__name__', str(base_type))

                elif origin is TypeUnion or (hasattr(types, "UnionType") and origin is types.UnionType):
                    args = get_args(annotation)
                    type_display = "|".join([getattr(a, "__name__", str(a)) if a is not type(None) else "None" for a in args])
                elif hasattr(annotation, '__name__'):
                    type_display = annotation.__name__
                
                params_meta[name] = {
                    "required": param.default == inspect.Parameter.empty,
                    "default": param.default if param.default != inspect.Parameter.empty else "REQUIRED",
                    "type": type_display,
                    "kind": param.kind
                }
            
            # Configure gate with required parameters
            gate_config = gate or GateConfig()
            gate_config.required_params = [n for n, m in params_meta.items() if m["required"]]
            
            # Store endpoint configuration
            self.registry[clean_path] = {
                "handler": enforced_func,
                "source_file": source_file,
                "gate_config": gate_config,
                "group": group,
                "params": params_meta,
                "methods": methods or ["POST"],
                "doc": func.__doc__.strip() if func.__doc__ else "No description available.",
                "cookies": cookies or {}
            }
            
            return enforced_func
        return decorator
    
    def _apply_tokenization(self, data: Any, fields: list[str]) -> Any:
        """
        Recursively apply tokenization to specified fields in response data.
        
        (Original method preserved exactly)
        """
        if not fields or data is None:
            return data

        if isinstance(data, list):
            return [self._apply_tokenization(item, fields) for item in data]

        if isinstance(data, dict):
            processed = {}
            for key, value in data.items():
                if key in fields:
                    processed[key] = self.token_manager.mask_data(value)
                else:
                    processed[key] = self._apply_tokenization(value, fields)
            return processed

        return data
    
    def _resp(
        self,
        handler_output: dict,
        http_code: int = 200,
        content_type: str = "application/json",
        gate: GateConfig | None = None,
        ctx: RequestContext | None = None,
        endpoint_cookies: dict[str, dict] | None = None
    ) -> Any:
        """
        Create a standardized HTTP response with optional data tokenization.
        """
        # Extract components from handler output
        status = handler_output.get("status", False)
        log = handler_output.get("log", "")
        raw_data = handler_output.get("data")
        
        # 1. Symmetrical Auth Proxy: Handover session tokens automatically (v0.1.0)
        if status and isinstance(raw_data, dict) and gate:
            auth_key = gate.payload_auth_token_key
            if auth_key and auth_key in raw_data:
                val = raw_data[auth_key]
                if gate.auth_type == AuthType.TOKEN_PAYLOAD:
                    # REPLACE raw ID with the masked session token
                    raw_data[auth_key] = self.token_manager.create_session_token(val, token_type="token_payload")
                elif gate.auth_type == AuthType.BEARER:
                    # INJECT a sibling key for the Authorization Header
                    raw_data["bearer"] = self.token_manager.create_session_token(val, token_type="bearer")
                elif gate.auth_type == AuthType.API_KEY:
                    # INJECT a sibling key for the API Key header
                    raw_data["api_key"] = self.token_manager.create_session_token(val, token_type="api_key")
        
        # 2. Field-Level Data Tokenization
        if status and raw_data is not None:
            # Determine which fields to tokenize
            tokenize_fields = self.default_tokenized_fields
            if gate and gate.tokenized_fields is not None:
                tokenize_fields = gate.tokenized_fields
            
            # Apply tokenization to response data
            processed_data = self._apply_tokenization(raw_data, tokenize_fields)
        else:
            processed_data = raw_data
        
        # Build standardized response payload
        payload = {
            "status": status,
            "log": log,
            "data": processed_data
        }
        
        # Format response based on content type
        if content_type == "application/json":
            response = make_response(jsonify(payload), http_code)
            response.headers["Content-Type"] = "application/json"
        else:
            # For non-JSON responses, convert payload to string
            response = make_response(str(payload), http_code)
            response.headers["Content-Type"] = content_type
            
        # Add security headers from the context if available
        if ctx and ctx.security_headers:
            for key, value in ctx.security_headers.items():
                response.headers[key] = value

        # Build cookies dictionary: global -> endpoint (precedence)
        all_cookies = {**self.default_cookies}
        if endpoint_cookies:
            all_cookies.update(endpoint_cookies)
            
        for name, properties in all_cookies.items():
            response.set_cookie(name, **properties)
        
        return response
    
    def _trigger_audit(
        self, 
        ctx: RequestContext, 
        success: bool, 
        log_msg: str = "", 
        error_code: str|None = None
    ) -> None:
        """
        Trigger the developer's audit logging function if registered.
        
        (Original method preserved exactly)
        """
        if self._audit_logger:
            try:
                self._audit_logger(
                    user_id=ctx.user.get("user_id") if ctx.user else "anonymous",
                    request_id=ctx.request_id,
                    path=request.path,
                    success=success,
                    log=log_msg,
                    error_code=error_code,
                    ip=request.remote_addr,
                    method=request.method,
                    user_agent=request.headers.get("User-Agent", "")
                )
            except Exception as e:
                # Prevent audit logger failures from affecting request processing
                logger.error("Audit logger failed: %s", e)
    
    def _generate_endpoint_map(self, caller_dir: str) -> None:
        """
        Generate a JSON file mapping URL paths to physical file locations.
        """
        endpoint_map = {}
        
        for path, config in self.registry.items():
            try:
                relative_source = os.path.relpath(config["source_file"], caller_dir)
            except ValueError:
                relative_source = config["source_file"]
            
            endpoint_map[path] = {
                "file_location": relative_source,
                "group": config["group"],
                "methods": config["methods"]
            }
        
        map_path = os.path.join(caller_dir, "endpoint_map.json")
        try:
            with open(map_path, "w", encoding="utf-8") as f:
                json.dump(endpoint_map, f, indent=4, ensure_ascii=False)
            logger.info("Endpoint map generated at: %s", map_path)
        except IOError as e:
            logger.error("Failed to write endpoint map: %s", e)
    
    # ============================================================================
    # HTTP endpoint binding (will also serve WebSocket metrics endpoints)
    # ============================================================================
    
    def _add_flask_rule(self, path: str, config: dict) -> None:
        """
        Register a Flask URL rule for an endpoint with full request processing.
        
        (Original method preserved exactly - unchanged)
        """
        def view_func(**url_vars):
            # Handle CORS preflight requests
            if request.method == "OPTIONS":
                return self._resp(
                    {"status": True, "log": "CORS preflight", "data": {}},
                    http_code=204,
                    endpoint_cookies=config.get('cookies')
                )
            
            ctx = None
            try:
                # 1. GATE PROCESSING: Security and validation
                gate_result = self.gate_pipeline.process(request, config["gate_config"])
                ctx = gate_result.context
                
                if not gate_result.success:
                    err = gate_result.error
                    self._trigger_audit(
                        ctx, 
                        success=False, 
                        error_code=err.get("code"), 
                        log_msg=err.get("message")
                    )
                    return self._resp(
                        {"status": False, "log": err.get("message"), "data": err},
                        http_code=400,
                        ctx=ctx,
                        endpoint_cookies=config.get('cookies')
                    )
                
                # 2. HANDLER EXECUTION: Business logic
                incoming = ctx.validated_data.copy() if ctx.validated_data else {}
                incoming.update(url_vars)
                
                # Replace masked tokens with raw identities inside the handler's parameters
                raw_identity = ctx.get("session_identity_raw")
                if raw_identity is not None and config['gate_config'].payload_auth_token_key:
                    incoming[config['gate_config'].payload_auth_token_key] = raw_identity
                
                # Inject fields unmasked by DataUnmaskingGate
                for key, val in ctx.gate_data.items():
                    if key.startswith("unmasked_"):
                        field_name = key.replace("unmasked_", "")
                        incoming[field_name] = val
                
                # Build arguments based on function signature (respecting /, * and variadics)
                pos_args = []
                kw_args = {}
                for p_name, p_meta in config['params'].items():
                    val = None
                    if p_name in incoming:
                        val = incoming[p_name]
                    elif p_meta['default'] != "REQUIRED":
                        val = p_meta['default']
                    else:
                        raise ValueError(f"Missing required parameter: {p_name}")
                    
                    p_kind = p_meta.get('kind')
                    if p_kind == inspect.Parameter.POSITIONAL_ONLY:
                        pos_args.append(val)
                    elif p_kind == inspect.Parameter.VAR_POSITIONAL:
                        if isinstance(val, (list, tuple)):
                            pos_args.extend(val)
                    elif p_kind == inspect.Parameter.VAR_KEYWORD:
                        if isinstance(val, dict):
                            kw_args.update(val)
                    else:
                        # POSITIONAL_OR_KEYWORD or KEYWORD_ONLY
                        kw_args[p_name] = val
                
                # Execute the endpoint handler
                result = config['handler'](*pos_args, **kw_args)
                
                # 3. RESPONSE PROCESSING: Format and tokenize
                if hasattr(result, "to_dict") and hasattr(result, "status"):
                    result = result.to_dict()

                if isinstance(result, tuple) and len(result) == 2 and isinstance(result[1], str):
                    # Handler returned (data, content_type) tuple
                    data, content_type = result
                    self._trigger_audit(ctx, success=True)
                    return self._resp(
                        {"status": True, "log": "Success", "data": data},
                        http_code=200,
                        content_type=content_type,
                        gate=config["gate_config"],
                        ctx=ctx,
                        endpoint_cookies=config.get('cookies')
                    )
                
                if isinstance(result, dict) and "status" in result:
                    # Handler returned full response structure
                    self._trigger_audit(
                        ctx, 
                        success=result.get("status", False), 
                        log_msg=result.get("log", "")
                    )
                    return self._resp(
                        result,
                        http_code=200, # Application results should use 200; Gates handle 400s
                        gate=config["gate_config"],
                        ctx=ctx,
                        endpoint_cookies=config.get('cookies')
                    )
                
                # Default: Wrap handler return value in standardized response
                self._trigger_audit(ctx, success=True)
                return self._resp(
                    {"status": True, "log": "Success", "data": result},
                    http_code=200,
                    gate=config["gate_config"],
                    ctx=ctx,
                    endpoint_cookies=config.get('cookies')
                )
                
            except Exception as e:
                # 4. ERROR HANDLING: Crash reporting
                error_id = f"ERR-{uuid.uuid4().hex[:8].upper()}"
                
                # Create structured crash report
                report = CrashReport(
                    error_id=error_id,
                    exception=e,
                    traceback_str=traceback.format_exc(),
                    request_path=request.path if request else None,
                    user_id=ctx.user.get('user_id') if ctx and hasattr(ctx, 'user') and ctx.user else None,
                    request_data=ctx.validated_data if ctx else None
                )
                
                # Call developer's crash handler
                if self._crash_handler:
                    try:
                        self._crash_handler(report.as_dict())
                    except Exception as hook_error:
                        logger.error("Crash handler failed: %s", hook_error)
                
                # Log to audit system
                self._trigger_audit(
                    ctx, 
                    success=False, 
                    error_code=f"CRASH:{error_id}", 
                    log_msg=str(e)
                )
                
                # Return error response
                error_msg = f"Internal server error: {error_id}"
                if self.debug:
                    error_msg = f"(Error ID: {error_id}):: please contact system admin!"
                    
                return self._resp(
                    {"status": False, "log": error_msg, "data": {}},
                    http_code=500,
                    ctx=ctx,
                    endpoint_cookies=config.get('cookies')
                )
        
        # Register the view function with Flask
        self.app.add_url_rule(
            path, 
            view_func=view_func, 
            methods=config['methods'] + ["OPTIONS"], 
            endpoint=path
        )
    
    def _check_is_main(self) -> bool:
        """
        Check if ServicePortal is being executed from the main module.
        """
        import sys
        main_mod = sys.modules.get('__main__')
        if not main_mod or not hasattr(main_mod, '__file__'):
            return False
        
        self._caller_file = os.path.abspath(main_mod.__file__)
        return True
    
    # ============================================================================
    # Auto-discovery (unchanged - still just imports files)
    # ============================================================================
    
    def _auto_discover(self, abs_path: str) -> None:
        """
        Automatically discover and import Python modules containing route definitions.
        
        This method scans the specified directory for .py files and imports them.
        During import, both @endpoint and @on_event decorators will execute and
        register themselves in their respective collections.
        """
        if not os.path.exists(abs_path):
            logger.warning("Routes directory not found: %s", abs_path)
            return
        
        # print(f"[ServicePortal] Discovering routes in: {abs_path}")
        
        for root, _, files in os.walk(abs_path):
            for file in files:
                if file.endswith(".py") and not file.startswith("__"):
                    module_path = os.path.join(root, file)
                    try:
                        module_name = file[:-3]
                        spec = importlib.util.spec_from_file_location(
                            module_name, 
                            module_path
                        )
                        if spec and spec.loader:
                            module = importlib.util.module_from_spec(spec)
                            spec.loader.exec_module(module)
                            logger.debug("Loaded route module: %s", module_name)
                    except SyntaxError as e:
                        logger.error("Syntax error in %s: %s", file, e)
                        raise
                    except ImportError as e:
                        logger.error("Import error in %s: %s", file, e)
                        raise
                    except Exception as e:
                        logger.error("Failed to load %s: %s", file, e)
                        raise
    
    # ============================================================================
    # HTTP route binding (adds WebSocket metrics endpoints if enabled)
    # ============================================================================
    
    def _bind_routes(self) -> None:
        """
        Bind all registered endpoints to Flask and add system endpoints.
        
        (Original method extended to add WebSocket metrics endpoints)
        """
        # Documentation endpoint (protected by Basic Auth)
        @self.app.route("/docs")
        def docs():
            """Serve the interactive API documentation portal."""
            auth = request.authorization
            if not auth or (auth.username != self.admin_creds[0] or 
                          auth.password != self.admin_creds[1]):
                res = make_response("Unauthorized", 401)
                res.headers['WWW-Authenticate'] = 'Basic realm="Login Required"'
                return res
            return self._build_docs_html()
        
        # Health check endpoint (public)
        @self.app.route("/health")
        def health():
            """Health check endpoint for load balancers and monitoring."""
            storage_info = self._gate_storage.info()
            return jsonify({
                "status": "healthy",
                "service": "ServicePortal",
                "timestamp": DateUtils.current_timestamp(),
                "endpoints_registered": len(self.registry),
                "websocket_events": len(self._socket_events) if self._websocket_enabled else 0,
                "storage": storage_info
            })
        
        # Register all developer HTTP endpoints
        for path, config in self.registry.items():
            self.gate_pipeline.verify_integrity(config["gate_config"])
            self._add_flask_rule(path, config)
        
        # Add WebSocket upgrade path if enabled (handled by Socket.IO internally)
        if self._websocket_enabled:
            @self.app.route('/socket.io/')
            def socket_io_upgrade():
                # This route exists just to register the path - Socket.IO handles it internally
                pass
        
        # 404 Not Found handler
        @self.app.errorhandler(404)
        def not_found(error):
            return self._resp(
                {"status": False, "log": "Endpoint not found", "data": {}},
                http_code=404
            )
        
        # 405 Method Not Allowed handler
        @self.app.errorhandler(405)
        def method_not_allowed(error):
            return self._resp(
                {"status": False, "log": "Method not allowed", "data": {}},
                http_code=405
            )
    
    # ============================================================================
    # NEW: WebSocket metrics endpoints
    # ============================================================================
    
    def _add_websocket_metric_endpoints(self):
        """
        Add HTTP endpoints for WebSocket metrics and monitoring.
        All metrics endpoints (except /health) are protected with the same
        basic auth as the /docs endpoint.
        """
        if not self._websocket_metrics:
            return
        
        # Helper to check authentication
        def check_auth():
            auth = request.authorization
            if not auth or (auth.username != self.admin_creds[0] or 
                        auth.password != self.admin_creds[1]):
                res = make_response("Unauthorized", 401)
                res.headers['WWW-Authenticate'] = 'Basic realm="Login Required"'
                return False, res
            return True, None
        
        @self.app.route('/metrics/dashboard')
        def metrics_dashboard():
            """Real-time WebSocket metrics dashboard."""
            # PROTECT THIS ENDPOINT
            auth_ok, response = check_auth()
            if not auth_ok:
                return response
            
            return self._websocket_metrics.get_dashboard_html()
        
        @self.app.route('/metrics/dashboard-data')
        def metrics_dashboard_data():
            """JSON data for dashboard real-time updates."""
            # PROTECT THIS ENDPOINT
            auth_ok, response = check_auth()
            if not auth_ok:
                return response
            
            return jsonify(self._websocket_metrics.get_dashboard_data())
        
        # @self.app.route('/metrics/prometheus')
        # def metrics_prometheus():
        #     """Prometheus metrics endpoint for scraping."""
        #     # PROTECT THIS ENDPOINT
        #     auth_ok, response = check_auth()
        #     if not auth_ok:
        #         return response
            
        #     return self._websocket_metrics.get_prometheus_metrics()
        
        @self.app.route('/metrics/health')
        def metrics_health():
            """WebSocket-specific health check."""
            # This can stay public (same as /health)
            health = self._websocket_metrics.get_health()
            status_code = 200 if health.is_healthy else 503
            return jsonify({
                "status": health.status,
                "checks": health.checks,
                "timestamp": health.timestamp
            }), status_code
        
        logger.info(
            "WebSocket metrics endpoints added (protected with basic auth): "
            "Dashboard=/metrics/dashboard, Prometheus=/metrics/prometheus, Health=/metrics/health"
        )
    
    # ============================================================================
    # NEW: WebSocket component initialization
    # ============================================================================

    def _init_websocket_components(self):
        """
        Initialize all WebSocket components in the correct dependency order.
        
        This implements the lazy initialization:
        - Components are only created when WebSocket mode is activated
        - Order respects dependencies (engine first, metrics last)
        - Each component gets its own slice from the master config
        """
        if not self._websocket_enabled:
            return
        
        logger.info("Initializing WebSocket components...")
        
        # 1. Engine (core) - gets engine slice
        self._websocket_engine = WebSocketEngine(self.app, self._websocket_config.engine)
        self._websocket_engine.init_app()
        logger.debug("WebSocket Engine initialized")
        
        # 2. Security (depends on GatePipeline) - gets security slice
        if self.gate_pipeline:
            self._websocket_security = setup_websocket_security(
                engine=self._websocket_engine,
                gate_pipeline=self.gate_pipeline,
                token_manager=self.token_manager,
                config=self._websocket_config.security  # ← Just the security part
            )
            logger.debug("WebSocket Security initialized")
        
        # 3. Limits - gets limits slice
        self._websocket_limits = setup_websocket_limits(
            engine=self._websocket_engine,
            config=self._websocket_config.limits,  # ← Just the limits part
            quota_manager=None  # Will use default from limits config
        )
        logger.debug("WebSocket Limits initialized")
        
        # 4. Protocol - gets protocol slice
        self._websocket_protocol = setup_websocket_protocol(
            engine=self._websocket_engine,
            config=self._websocket_config.protocol  # ← Just the protocol part
        )
        logger.debug("WebSocket Protocol initialized")
        
        # 5. Metrics (depends on all above) - gets metrics slice
        if self._websocket_config.metrics.enabled:
            self._websocket_metrics = setup_websocket_metrics(
                engine=self._websocket_engine,
                config=self._websocket_config.metrics,  # ← Just the metrics part
                security=self._websocket_security,
                limits=self._websocket_limits,
                protocol=self._websocket_protocol
            )
            logger.debug("WebSocket Metrics initialized")
        
    # def _init_websocket_components(self):
    #     """
    #     Initialize all WebSocket components in the correct dependency order.
        
    #     This implements the lazy initialization:
    #     - Components are only created when WebSocket mode is activated
    #     - Order respects dependencies (engine first, metrics last)
    #     - Each component builds on previous ones
        
    #     Component order:
    #     1. Engine - Core WebSocket server
    #     2. Security - Authentication via GatePipeline
    #     3. Limits - Rate limiting and quotas
    #     4. Protocol - Message formatting and session management
    #     5. Metrics - Observability (wraps everything)
    #     """
    #     if not self._websocket_enabled:
    #         return
        
    #     print("\n[ServicePortal] Initializing WebSocket components...")
        
    #     # 1. Engine (core)
    #     self._websocket_engine = WebSocketEngine(self.app, self._websocket_config)
    #     self._websocket_engine.init_app()
    #     print(f"  WebSocket Engine initialized")
        
    #     # 2. Security (depends on GatePipeline)
    #     if self.gate_pipeline:
    #         self._websocket_security = setup_websocket_security(
    #             engine=self._websocket_engine,
    #             gate_pipeline=self.gate_pipeline,
    #             token_manager=self.token_manager,
    #             websocket_config=self._websocket_config,
    #             security_config=self._websocket_security_config
    #         )
    #         print(f"  WebSocket Security initialized")
        
    #     # 3. Limits
    #     self._websocket_limits = setup_websocket_limits(
    #         engine=self._websocket_engine,
    #         config=self._websocket_config
    #     )
    #     print(f"  WebSocket Limits initialized")
        
    #     # 4. Protocol
    #     self._websocket_protocol = setup_websocket_protocol(
    #         engine=self._websocket_engine,
    #         config=self._websocket_config
    #     )
    #     print(f"  WebSocket Protocol initialized")
        
    #     # 5. Metrics (depends on all above)
    #     self._websocket_metrics = setup_websocket_metrics(
    #         engine=self._websocket_engine,
    #         config=self._websocket_config,
    #         security=self._websocket_security,
    #         limits=self._websocket_limits,
    #         protocol=self._websocket_protocol
    #     )
    #     print(f"  WebSocket Metrics initialized")
    
    # ============================================================================
    # NEW: Register WebSocket event handlers
    # ============================================================================
    
    def _register_websocket_events(self):
        """
        Register all collected WebSocket event handlers with the engine.
        
        This flushes the "holding pen" created during auto-discovery:
        - Each event handler is bound to the Socket.IO engine
        - Auth requirements are passed to the security manager
        - Handlers are wrapped for consistent error handling
        """
        if not self._websocket_engine:
            return
        
        if not self._socket_events:
            logger.info("No WebSocket events to register")
            return
        
        logger.info("Registering %d WebSocket events...", len(self._socket_events))
        
        for event_config in self._socket_events:
            event_name = event_config['event']
            handler = event_config['handler']
            auth_required = event_config.get('auth_required')
            
            # Register with engine (wrapped for consistent handling)
            @self._websocket_engine.on(event_name)
            def wrapped_handler(data, _handler=handler, _event=event_name):
                """Wrapper that adds metrics and error handling."""
                try:
                    # Record metrics start time
                    start_time = time.time()
                    
                    # Execute the actual handler
                    result = _handler(data)
                    
                    if hasattr(result, "to_dict") and hasattr(result, "status"):
                        result = result.to_dict()
                    
                    # Record latency
                    if self._websocket_metrics:
                        latency = (time.time() - start_time) * 1000
                        self._websocket_metrics.collector.record_latency(_event, latency)
                    
                    return result
                except Exception as e:
                    # Log error
                    if self._websocket_metrics:
                        self._websocket_metrics.collector.record_error("handler_error")
                    
                    # Re-raise for engine to handle
                    raise
            
            # If auth requirement specified, tell security manager
            if auth_required is not None and self._websocket_security:
                # Update the security config's event requirements
                self._websocket_security.config.event_auth_requirements[event_name] = auth_required
            
            logger.debug("Registered WebSocket event: %s (auth=%s)", event_name, auth_required if auth_required is not None else 'default')

    # def _register_websocket_events(self):
    #     """
    #     Register all collected WebSocket event handlers with the engine.
        
    #     This flushes the "holding pen" created during auto-discovery:
    #     - Each event handler is bound to the Socket.IO engine
    #     - Auth requirements are passed to the security manager
    #     - Handlers are wrapped for consistent error handling
        
    #     The registration process ensures that:
    #     - Events are properly namespaced
    #     - Authentication is enforced
    #     - Metrics are collected
    #     """
    #     if not self._websocket_engine:
    #         return
        
    #     if not self._socket_events:
    #         print("[ServicePortal] No WebSocket events to register")
    #         return
        
    #     print(f"\n[ServicePortal] Registering {len(self._socket_events)} WebSocket events...")
        
    #     for event_config in self._socket_events:
    #         event_name = event_config['event']
    #         handler = event_config['handler']
    #         auth_required = event_config.get('auth_required')
            
    #         # Register with engine (wrapped for consistent handling)
    #         @self._websocket_engine.on(event_name)
    #         def wrapped_handler(data, _handler=handler, _event=event_name):
    #             """Wrapper that adds metrics and error handling."""
    #             try:
    #                 # Record metrics start time
    #                 start_time = time.time()
                    
    #                 # Execute the actual handler
    #                 result = _handler(data)
                    
    #                 # Record latency
    #                 if self._websocket_metrics:
    #                     latency = (time.time() - start_time) * 1000
    #                     self._websocket_metrics.collector.record_latency(_event, latency)
                    
    #                 return result
    #             except Exception as e:
    #                 # Log error
    #                 if self._websocket_metrics:
    #                     self._websocket_metrics.collector.record_error("handler_error")
                    
    #                 # Re-raise for engine to handle
    #                 raise
            
    #         # If auth requirement specified, tell security manager
    #         if auth_required is not None and self._websocket_security:
    #             self._websocket_security.config.event_auth_requirements[event_name] = auth_required
            
    #         print(f"  ✓ Registered: {event_name} (auth={auth_required if auth_required is not None else 'default'})")
    
    # ============================================================================
    # NEW: WebSocket server startup
    # ============================================================================
    
    def _start_websocket_server(self, port: int, routes_path: str):
        """
        Start the server in WebSocket mode.
        
        This method:
        1. Discovers HTTP routes
        2. Initializes all WebSocket components
        3. Registers WebSocket event handlers
        4. Adds metrics endpoints
        5. Starts the Socket.IO server
        
        The server runs both:
        - HTTP REST API (on same port)
        - WebSocket real-time events (on same port)
        """
        logger.info("ServicePortal WebSocket Server Starting")
        
        # 1. Discover HTTP routes (same as original)
        caller_dir = os.path.dirname(self._caller_file)
        abs_routes = os.path.abspath(os.path.join(caller_dir, routes_path))
        self._auto_discover(abs_routes)
        
        # 2. Generate endpoint map
        self._generate_endpoint_map(caller_dir)
        
        # 3. Bind HTTP routes (for REST API)
        self._bind_routes()
        
        # 4. Initialize all WebSocket components
        self._init_websocket_components()
        
        # 5. Register WebSocket event handlers
        self._register_websocket_events()
        
        # 6. Add metrics endpoints
        self._add_websocket_metric_endpoints()
        
        # 7. Start storage
        self._gate_storage.start()
        
        # 8. Log startup info
        logger.info(
            "Server ready on port %d | HTTP endpoints: %d | WebSocket events: %d | "
            "Docs: http://localhost:%d/docs | Dashboard: http://localhost:%d/metrics/dashboard",
            port, len(self.registry), len(self._socket_events), port, port
        )
        
        # 9. Run (blocking)
        try:
            self._running = True
            self._websocket_engine.run(host="0.0.0.0", port=port, debug=self.debug)
        except KeyboardInterrupt:
            logger.info("Shutting down...")
        finally:
            self._running = False
            self._gate_storage.stop()
            if self._websocket_metrics:
                self._websocket_metrics.shutdown()
            logger.info("Server stopped")
    
    # ============================================================================
    # LIFECYCLE MANAGEMENT
    # ============================================================================

    # ============================================================================
    # MODIFIED: run() method - now supports WebSocket mode
    # ============================================================================
    
    def run(self, port: int = 5000, routes_path: str = "./routes", use_websockets: bool = False) -> None:
        """
        Start the ServicePortal server.
        
        This method has been extended to support both:
        - Traditional Flask HTTP server (backward compatible)
        - WebSocket + HTTP server (new)
        
        Args:
            port: Port number to listen on (default: 5000).
            routes_path: Path to directory containing route modules,
                        relative to the caller's directory.
            use_websockets: If True, run in WebSocket mode (requires
                          enable_websocket=True in constructor).
                          If False, run in traditional Flask mode.
                          
        Raises:
            RuntimeError: If not called from the main module.
            RuntimeError: If use_websockets=True but WebSocket not enabled
                         in constructor.
            OSError: If the port is already in use or other system errors occur.
            
        Example:
            >>> # Traditional HTTP-only mode
            >>> portal.run(port=8080)
            >>> 
            >>> # WebSocket + HTTP mode
            >>> portal = ServicePortal(enable_websocket=True)
            >>> portal.run(port=8080, use_websockets=True)
        """
        if not self._is_main:
            raise RuntimeError(
                "ServicePortal must be started from the main module. "
                "Make sure your script has `if __name__ == '__main__':`"
            )
        
        # Validate WebSocket mode
        if use_websockets and not self._websocket_enabled:
            raise RuntimeError(
                "Cannot use WebSocket mode because WebSocket is not enabled. "
                "Set enable_websocket=True in ServicePortal constructor."
            )
        
        caller_dir = os.path.dirname(self._caller_file)
        
        # === WebSocket Mode ===
        if use_websockets:
            self._start_websocket_server(port, routes_path)
            return
        
        # === Traditional Flask Mode (Original code preserved exactly) ===
        logger.info("Starting server on port %d (caller: %s)", port, caller_dir)
        
        try:
            # 1. Discover and load route modules
            abs_routes = os.path.abspath(os.path.join(caller_dir, routes_path))
            self._auto_discover(abs_routes)
            
            # 2. Generate endpoint map for debugging
            self._generate_endpoint_map(caller_dir)
            
            # 3. Bind routes to Flask
            self._bind_routes()
            
            # 4. Start storage cleanup thread
            self._gate_storage.start()
            
            logger.info(
                "Registered %d endpoints | Docs: http://localhost:%d/docs | Health: http://localhost:%d/health",
                len(self.registry), port, port
            )
            
            # 5. Run Flask server
            self._running = True
            self.app.run(
                host="0.0.0.0", 
                port=port, 
                debug=self.debug,
                use_reloader=False
            )
            
        except KeyboardInterrupt:
            logger.info("Shutting down...")
        except OSError as e:
            logger.error("Failed to start server: %s", e)
            if "Address already in use" in str(e):
                logger.error("Port %d is already in use. Try a different port.", port)
            raise
        finally:
            # 6. Clean shutdown
            self._running = False
            self._gate_storage.stop()
            logger.info("Server stopped")
    
    # ============================================================================
    # MODIFIED: Documentation builder - now includes WebSocket events
    # ============================================================================
    
    def _build_docs_html(self) -> str:
        """
        Generate an interactive API documentation portal with modern styling.
        
        EXTENDED: Now shows BOTH HTTP endpoints and WebSocket events.
        
        The documentation is split into two sections:
        - HTTP REST API (traditional endpoints)
        - WebSocket Events (real-time events)
        
        Each WebSocket event shows:
        - Event name
        - Authentication requirement
        - Description from docstring
        - Expected payload structure (inferred from code)
        
        Returns:
            HTML string for the documentation portal.
        """
        # HTTP endpoints section (original)
        http_section = self._build_http_docs_section()
        
        # WebSocket events section (new)
        ws_section = self._build_websocket_docs_section() if self._websocket_enabled else ""
        
        # Combine with template
        html = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>ServicePortal | Developer Docs</title>
            <style>
                :root {{
                    --header-bg: #37474f;
                    --group-bg: #455a64;
                    --accent: #066088;
                    --accent-light: #135f7e;
                    --text-main: #263238;
                    --code-bg: #263238; 
                    --code-key: #9cdcfe;
                    --code-type: #4ec9b0;
                    --code-comment: #90a4ae;
                    --bg-canvas: #eceff1;
                    --ws-accent: #4a148c;  /* Purple for WebSocket */
                }}

                body {{ font-family: 'Segoe UI', sans-serif; margin: 0; background: var(--bg-canvas); color: var(--text-main); height: 100vh; display: flex; flex-direction: column; }}
                
                .top-nav {{ background: var(--header-bg); color: white; padding: 12px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.15); z-index: 10; }}
                #apiSearch {{ background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.3); border-radius: 20px; padding: 8px 20px; color: white; width: 250px; outline: none; transition: 0.3s; }}
                #apiSearch:focus {{ background: white; color: var(--text-main); width: 350px; }}

                .main-content {{ flex: 1; overflow-y: auto; padding: 30px; }}
                .container {{ max-width: 1000px; margin: 0 auto; }}

                .section-header {{
                    font-size: 1.5rem;
                    margin: 30px 0 20px 0;
                    padding-bottom: 10px;
                    border-bottom: 2px solid var(--accent);
                }}
                
                .ws-header {{
                    border-bottom-color: var(--ws-accent);
                }}
                
                .method-tag {{
                    background: var(--accent);
                    color: white;
                    padding: 3px 10px;
                    border-radius: 4px;
                    font-size: 0.7rem;
                    letter-spacing: 0.5px;
                }}
                
                .ws-tag {{
                    background: var(--ws-accent);
                }}
                
                .path-text {{
                    font-family: 'Consolas', monospace;
                    font-size: 1.1rem;
                    color: var(--accent-light);
                }}
                
                .gate-badge {{
                    background: #f1f5f9;
                    border: 1px solid #e2e8f0;
                    padding: 5px 12px;
                    border-radius: 6px;
                    font-size: 0.75rem;
                    color: var(--group-bg);
                    font-weight: 600;
                    margin-right: 8px;
                    margin-bottom: 8px;
                    display: inline-block;
                }}
                
                .auth-badge {{
                    background: #fff3e0;
                    border-color: #ff9800;
                    color: #e65100;
                }}
                
                .public-badge {{
                    background: #e8f5e8;
                    border-color: #4caf50;
                    color: #1b5e20;
                }}
                
                .code-block {{ 
                    background: var(--code-bg); 
                    border-radius: 8px; 
                    padding: 20px; 
                    font-family: 'Consolas', 'Courier New', monospace; 
                    font-size: 0.95rem; 
                    overflow-x: auto; 
                    line-height: 1.7;
                    box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
                    color: #e0e0e0;
                }}
                
                .code-label {{ 
                    color: var(--group-bg); 
                    font-size: 0.8rem; 
                    margin-bottom: 10px; 
                    font-weight: bold; 
                    text-transform: uppercase; 
                }}
                
                .indent {{ padding-left: 28px; display: block; border-left: 1px solid rgba(255,255,255,0.05); }}
                .key {{ color: var(--code-key); }}
                .type {{ color: var(--code-type); }}
                .comment {{ color: var(--code-comment); font-style: italic; margin-left: 15px; }}
                
                details {{ background: white; margin-bottom: 12px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; }}
                summary {{ 
                    list-style: none; padding: 18px 25px; cursor: pointer; font-weight: 600; 
                    display: flex; align-items: center; justify-content: space-between;
                    background: #fff; transition: background 0.2s;
                }}
                summary:hover {{ background: #f8f9fa; }}
                summary::-webkit-details-marker {{ display: none; }}
                
                .summary-left {{ display: flex; align-items: center; gap: 15px; flex-wrap: wrap; }}
                
                .card-content {{ padding: 0 25px 25px 25px; border-top: 1px solid #f1f1f1; }}
                .doc-text {{ color: #546e7a; line-height: 1.6; margin: 20px 0; }}
                
                .hidden {{ display: none !important; }}
            </style>
        </head>
        <body>
            <div class="top-nav">
                <div style="font-size: 1.2rem; font-weight: bold;">API <span>DOCUMENTATION</span></div>
                <input type="text" id="apiSearch" placeholder="Filter endpoints..." oninput="filterList()">
            </div>

            <div class="main-content">
                <div class="container">
                    {http_section}
                    {ws_section}
                </div>
            </div>
            
            <script>
                function filterList() {{
                    const query = document.getElementById('apiSearch').value.toLowerCase();
                    document.querySelectorAll('.api-item').forEach(item => {{
                        const text = item.getAttribute('data-search').toLowerCase();
                        item.classList.toggle('hidden', !text.includes(query));
                    }});
                    
                    // Show/hide section headers based on visible items
                    document.querySelectorAll('h2.section-header').forEach(header => {{
                        const section = header.closest('div');
                        if (section) {{
                            const visible = Array.from(section.querySelectorAll('.api-item')).some(item => !item.classList.contains('hidden'));
                            header.classList.toggle('hidden', !visible);
                        }}
                    }});
                }}
            </script>
        </body>
        </html>
        """
        return html
    
    def _build_http_docs_section(self) -> str:
        """Build the HTTP endpoints section of the documentation."""
        if not self.registry:
            return ""
        
        auth_descriptions = {
            AuthType.BEARER: "Bearer token required",
            AuthType.API_KEY: "API key required",
            AuthType.BASIC: "Basic authentication",
            AuthType.TOKEN_PAYLOAD: "Token payload",
            AuthType.NONE: "Public (no auth)"
        }
        
        items_html = ""
        for path, data in self.registry.items():
            gate = data["gate_config"]
            params = data.get('params', {})
            
            # Build parameter documentation
            param_lines = ""
            for name, meta in params.items():
                req = '<span class="comment">required</span>' if meta.get('required') else '<span class="comment">optional</span>'
                param_lines += f"""
                    <span class="indent">
                        <span class="key">{name}</span>: <span class="type">{meta.get('type')}</span> {req}
                        <span class="comment"># Default: {meta.get('default')}</span>
                    </span>"""
            
            body_display = param_lines if param_lines else '<span class="indent"><span class="comment"># No parameters</span></span>'
            
            items_html += f"""
            <details class="api-item" data-search="{path} {data.get('group')}">
                <summary>
                    <div class="summary-left">
                        <span class="method-tag">{" / ".join(data.get('methods', ['POST']))}</span>
                        <span class="path-text">{path}</span>
                    </div>
                    <div style="font-size: 0.75rem; color: #90a4ae;">{data.get('group')}</div>
                </summary>
                
                <div class="card-content">
                    <div class="doc-text">{data.get('doc', 'No description provided.')}</div>
                    
                    <div>
                        <span class="gate-badge">AUTH: {auth_descriptions[gate.auth_type]}</span>
                        <span class="gate-badge">RATE: {gate.rate_limit or "OFF"}</span>
                        <span class="gate-badge">IDEMPOTENT: {gate.idempotent}</span>
                    </div>

                    <div class="code-label">Request Payload Structure</div>
                    <div class="code-block">
                        <span class="key">{{</span>
                        {body_display}
                        <span class="key">}}</span>
                    </div>
                </div>
            </details>
            """
        
        return f"""
            <h2 class="section-header">📡 HTTP REST API</h2>
            <p>{len(self.registry)} endpoints available</p>
            {items_html}
        """
    
    def _build_websocket_docs_section(self) -> str:
        """Build the WebSocket events section of the documentation."""
        if not self._socket_events:
            return ""
        
        items_html = ""
        for event_config in self._socket_events:
            event_name = event_config['event']
            auth_required = event_config.get('auth_required')
            doc = event_config.get('doc', 'No description provided.')
            
            # Determine auth badge - Access security config from master
            if auth_required is True:
                auth_badge = '<span class="gate-badge auth-badge">🔒 REQUIRES AUTH</span>'
            elif auth_required is False:
                auth_badge = '<span class="gate-badge public-badge">🌍 PUBLIC</span>'
            else:
                # Get default from security config
                default = self._websocket_config.security.default_auth_required
                if default:
                    auth_badge = '<span class="gate-badge auth-badge">🔒 AUTH REQUIRED (DEFAULT)</span>'
                else:
                    auth_badge = '<span class="gate-badge public-badge">🌍 PUBLIC (DEFAULT)</span>'
            
            # Infer payload structure (simplified - would need real analysis)
            payload_example = """
                <span class="indent"><span class="key">example</span>: <span class="type">"Any JSON-serializable data"</span></span>
            """
            
            items_html += f"""
            <details class="api-item" data-search="{event_name} websocket realtime">
                <summary>
                    <div class="summary-left">
                        <span class="method-tag ws-tag">EVENT</span>
                        <span class="path-text">{event_name}</span>
                    </div>
                    <div style="font-size: 0.75rem; color: #90a4ae;">WebSocket</div>
                </summary>
                
                <div class="card-content">
                    <div class="doc-text">{doc}</div>
                    
                    <div>
                        {auth_badge}
                        <span class="gate-badge">📨 One-way or request/response</span>
                    </div>

                    <div class="code-label">Expected Payload</div>
                    <div class="code-block">
                        <span class="key">{{</span>
                        {payload_example}
                        <span class="key">}}</span>
                    </div>
                    
                    <div class="code-label" style="margin-top: 15px;">Example Client Emission</div>
                    <div class="code-block">
                        <span class="comment">// JavaScript example</span>
                        <span class="key">socket</span>.emit(<span class="type">'{event_name}'</span>, {{
                            <span class="indent"><span class="key">message</span>: <span class="type">"Hello"</span></span>
                        }});
                    </div>
                </div>
            </details>
            """
        
        return f"""
            <h2 class="section-header ws-header">⚡ WebSocket Real-Time Events</h2>
            <p>{len(self._socket_events)} events available</p>
            <p><small>WebSocket endpoint: <code>ws://localhost:5000</code> (same port as HTTP)</small></p>
            {items_html}
        """