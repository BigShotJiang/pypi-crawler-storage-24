"""AICodeTrustScore CLI -- trust scoring from the command line.

Usage:
    aicodetrustcore score <file>                   Score a single file
    aicodetrustcore diff                           Score staged git diff
    aicodetrustcore report <directory>             Full trust report
    aicodetrustcore history <path>                 Show trust score trend
    aicodetrustcore hallucination-check <path>     Check for AI hallucinations
    aicodetrustcore benchmark                      Compare AI tools
    aicodetrustcore serve                          Start MCP server
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .store import TrustStore


console = Console()

_CATEGORY_COLORS = {
    "ship_it": "bold green",
    "review": "bold yellow",
    "needs_work": "bold red",
    "dont_ship": "bold red on white",
}

_SEVERITY_COLORS = {
    "critical": "bold red",
    "high": "red",
    "medium": "yellow",
    "low": "cyan",
    "info": "dim white",
}


def _get_store(db: str | None = None) -> TrustStore:
    return TrustStore(db)


def _print_trust_score(score: float, category: str) -> None:
    """Print the trust score with color coding."""
    color = _CATEGORY_COLORS.get(category, "white")
    label_map = {
        "ship_it": "SHIP IT",
        "review": "REVIEW BEFORE SHIPPING",
        "needs_work": "NEEDS WORK",
        "dont_ship": "DON'T SHIP",
    }
    label = label_map.get(category, category.upper())
    console.print(f"\n  [{color}]Trust Score: {score:.1f}/100 -- {label}[/]")


def _print_breakdown(breakdown: dict[str, float]) -> None:
    """Print the category breakdown."""
    table = Table(title="Score Breakdown", show_lines=True)
    table.add_column("Category", style="bold")
    table.add_column("Score", justify="right")

    for cat, score in breakdown.items():
        if score >= 90:
            color = "green"
        elif score >= 70:
            color = "yellow"
        elif score >= 50:
            color = "red"
        else:
            color = "bold red"
        table.add_row(cat.replace("_", " ").title(), f"[{color}]{score:.1f}[/]")

    console.print()
    console.print(table)


def _print_issues(issues: list[dict], verbose: bool = False) -> None:
    """Pretty-print issues grouped by severity."""
    if not issues:
        console.print("  [bold green]No issues found -- code looks trustworthy.[/]")
        return

    by_sev: dict[str, list[dict]] = {}
    for issue in issues:
        sev = issue.get("severity", "info")
        by_sev.setdefault(sev, []).append(issue)

    for sev in ["critical", "high", "medium", "low", "info"]:
        items = by_sev.get(sev, [])
        if not items:
            continue

        color = _SEVERITY_COLORS.get(sev, "white")
        console.print(f"\n  [{color}][{sev.upper()}] ({len(items)} issues)[/]")

        for issue in items:
            title = issue.get("title", "")
            cat = issue.get("category", "")
            file_path = issue.get("file_path", "")
            line = issue.get("line_start", 0)

            location = ""
            if file_path:
                location = f" @ {Path(file_path).name}"
                if line:
                    location += f":{line}"

            console.print(f"    [{color}][{cat}][/] {title}[dim]{location}[/]")

            if verbose:
                desc = issue.get("description", "")
                if desc:
                    console.print(f"         [dim]{desc}[/]")
                suggestion = issue.get("suggestion", "")
                if suggestion:
                    console.print(f"         [green]Fix: {suggestion}[/]")


@click.group()
@click.version_option(version="0.1.0", prog_name="AICodeTrustScore")
def main() -> None:
    """AICodeTrustScore -- Continuous trust scoring for AI-generated code.

    Analyzes code from Cursor, Copilot, Claude, and other AI tools,
    scoring trust 0-100 with hallucination detection.
    """
    pass


@main.command("score")
@click.argument("target", type=click.Path(exists=True))
@click.option("--ai-tool", default="", help="AI tool that generated the code (cursor, copilot, claude)")
@click.option("--db", default=None, help="Custom database path")
@click.option("--json-output", is_flag=True, help="Output raw JSON")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed issues")
def score_file(target: str, ai_tool: str, db: str | None, json_output: bool, verbose: bool) -> None:
    """Score a single file for AI code trust."""
    from .server import _run_trust_score

    store = _get_store(db)
    try:
        result = _run_trust_score(target, store, ai_tool)

        if "error" in result:
            console.print(f"  [red]Error: {result['error']}[/]")
            sys.exit(1)

        if json_output:
            click.echo(json.dumps(result, indent=2))
            return

        console.print(Panel.fit(
            f"[bold]AICodeTrustScore[/] -- File Trust Score\n"
            f"Target: {result.get('target', '')}\n"
            f"AI Tool: {result.get('ai_tool', 'unknown')}\n"
            f"Issues: {result.get('total_issues', 0)}",
            border_style="blue",
        ))

        _print_trust_score(result.get("score", 100), result.get("trust_category", ""))
        _print_breakdown(result.get("breakdown", {}))
        _print_issues(result.get("issues", []), verbose=verbose)
        console.print()

    finally:
        store.close()


@main.command("diff")
@click.option("--ai-tool", default="", help="AI tool that generated the code")
@click.option("--db", default=None, help="Custom database path")
@click.option("--json-output", is_flag=True, help="Output raw JSON")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed issues")
def score_diff(ai_tool: str, db: str | None, json_output: bool, verbose: bool) -> None:
    """Score the current git diff for trust."""
    from .server import _run_trust_diff

    try:
        diff = subprocess.run(
            ["git", "diff", "HEAD"],
            capture_output=True, text=True, timeout=30,
        )
        diff_text = diff.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        console.print("  [red]Error: Could not run git diff[/]")
        sys.exit(1)

    if not diff_text.strip():
        console.print("  [yellow]No changes to score (git diff is empty)[/]")
        return

    store = _get_store(db)
    try:
        result = _run_trust_diff(diff_text, store, ai_tool)

        if json_output:
            click.echo(json.dumps(result, indent=2))
            return

        console.print(Panel.fit(
            f"[bold]AICodeTrustScore[/] -- Diff Trust Score\n"
            f"Issues: {result.get('total_issues', 0)}",
            border_style="blue",
        ))

        _print_trust_score(result.get("score", 100), result.get("trust_category", ""))
        _print_breakdown(result.get("breakdown", {}))
        _print_issues(result.get("issues", []), verbose=verbose)
        console.print()

    finally:
        store.close()


@main.command("report")
@click.argument("directory", type=click.Path(exists=True))
@click.option("--db", default=None, help="Custom database path")
@click.option("--json-output", is_flag=True, help="Output raw JSON")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed issues")
def report(directory: str, db: str | None, json_output: bool, verbose: bool) -> None:
    """Generate a full trust report for a directory."""
    from .server import _run_trust_report

    store = _get_store(db)
    try:
        result = _run_trust_report(directory, store)

        if "error" in result:
            console.print(f"  [red]Error: {result['error']}[/]")
            sys.exit(1)

        if json_output:
            click.echo(json.dumps(result, indent=2))
            return

        console.print(Panel.fit(
            f"[bold]AICodeTrustScore[/] -- Trust Report\n"
            f"Target: {result.get('target', '')}\n"
            f"Files: {result.get('files_analyzed', 0)}\n"
            f"Avg Score: {result.get('avg_file_score', 100)}\n"
            f"Issues: {result.get('total_issues', 0)}",
            border_style="blue",
        ))

        _print_trust_score(result.get("score", 100), result.get("trust_category", ""))
        _print_breakdown(result.get("breakdown", {}))

        # Worst offenders
        worst = result.get("worst_offenders", [])
        if worst:
            table = Table(title="Worst Offenders", show_lines=True)
            table.add_column("File", style="bold")
            table.add_column("Score", justify="right")
            table.add_column("Category")
            table.add_column("Issues", justify="right")

            for f in worst[:10]:
                score = f["score"]
                color = "green" if score >= 90 else "yellow" if score >= 70 else "red"
                table.add_row(
                    f["file"],
                    f"[{color}]{score:.1f}[/]",
                    f["category"],
                    str(f["issues"]),
                )

            console.print()
            console.print(table)

        _print_issues(result.get("issues", []), verbose=verbose)
        console.print()

    finally:
        store.close()


@main.command("history")
@click.argument("target", type=click.Path(exists=True))
@click.option("--db", default=None, help="Custom database path")
@click.option("--json-output", is_flag=True, help="Output raw JSON")
def history(target: str, db: str | None, json_output: bool) -> None:
    """Show trust score history and trend."""
    from .server import _get_trust_history

    store = _get_store(db)
    try:
        result = _get_trust_history(target, store)

        if json_output:
            click.echo(json.dumps(result, indent=2))
            return

        trend = result.get("trend", {})
        scores = result.get("scores", [])

        console.print(Panel.fit(
            f"[bold]AICodeTrustScore[/] -- Trust History\n"
            f"Target: {result.get('target', '')}\n"
            f"Reviews: {trend.get('reviews', 0)}",
            border_style="blue",
        ))

        trend_dir = trend.get("trend", "no_data")
        trend_colors = {
            "improving": "green", "degrading": "red",
            "stable": "yellow", "no_data": "dim", "insufficient_data": "dim",
        }
        color = trend_colors.get(trend_dir, "white")
        console.print(f"\n  Trend: [{color}]{trend_dir.upper()}[/]")

        if trend.get("latest_score") is not None:
            console.print(f"  Latest: {trend['latest_score']:.1f}")
            console.print(f"  Average: {trend['avg_score']:.1f}")

        if scores:
            table = Table(title="Recent Scores")
            table.add_column("Date", style="dim")
            table.add_column("Score", justify="right")
            table.add_column("Category")
            table.add_column("AI Tool")

            for s in scores[:10]:
                score = s.get("score", 0)
                sc = "green" if score >= 90 else "yellow" if score >= 70 else "red"
                table.add_row(
                    str(s.get("created_at", ""))[:19],
                    f"[{sc}]{score:.1f}[/]",
                    s.get("category", ""),
                    s.get("ai_tool", ""),
                )

            console.print()
            console.print(table)

        console.print()

    finally:
        store.close()


@main.command("hallucination-check")
@click.argument("target", type=click.Path(exists=True))
@click.option("--db", default=None, help="Custom database path")
@click.option("--json-output", is_flag=True, help="Output raw JSON")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed issues")
def hallucination_check(target: str, db: str | None, json_output: bool, verbose: bool) -> None:
    """Check specifically for AI hallucination patterns."""
    from .server import _run_hallucination_check

    store = _get_store(db)
    try:
        result = _run_hallucination_check(target, store)

        if "error" in result:
            console.print(f"  [red]Error: {result['error']}[/]")
            sys.exit(1)

        if json_output:
            click.echo(json.dumps(result, indent=2))
            return

        h_score = result.get("hallucination_score", 100)
        total = result.get("total_hallucinations", 0)

        color = "green" if h_score >= 90 else "yellow" if h_score >= 70 else "red"

        console.print(Panel.fit(
            f"[bold]AICodeTrustScore[/] -- Hallucination Check\n"
            f"Target: {result.get('target', '')}\n"
            f"Hallucinations found: {total}\n"
            f"[{color}]Hallucination Score: {h_score:.1f}/100[/]",
            border_style="magenta",
        ))

        _print_issues(result.get("hallucinations", []), verbose=verbose)
        console.print()

    finally:
        store.close()


@main.command("benchmark")
@click.option("--db", default=None, help="Custom database path")
@click.option("--json-output", is_flag=True, help="Output raw JSON")
def benchmark(db: str | None, json_output: bool) -> None:
    """Compare trust scores across different AI tools."""
    from .server import _get_benchmark

    store = _get_store(db)
    try:
        result = _get_benchmark(store)

        if json_output:
            click.echo(json.dumps(result, indent=2))
            return

        benchmarks = result.get("benchmarks", {})
        total = result.get("total_scores", 0)

        console.print(Panel.fit(
            f"[bold]AICodeTrustScore[/] -- AI Tool Benchmark\n"
            f"Total scores: {total}",
            border_style="blue",
        ))

        if not benchmarks:
            console.print("\n  [dim]No benchmark data yet. Score some files with --ai-tool to populate.[/]")
        else:
            table = Table(title="AI Tool Comparison", show_lines=True)
            table.add_column("Tool", style="bold")
            table.add_column("Scores", justify="right")
            table.add_column("Avg Score", justify="right")
            table.add_column("Min", justify="right")
            table.add_column("Max", justify="right")
            table.add_column("Avg Hallucination", justify="right")

            for tool, data in sorted(benchmarks.items(), key=lambda x: x[1]["avg_score"], reverse=True):
                avg = data["avg_score"]
                color = "green" if avg >= 90 else "yellow" if avg >= 70 else "red"
                table.add_row(
                    tool,
                    str(data["count"]),
                    f"[{color}]{avg:.1f}[/]",
                    f"{data['min_score']:.1f}",
                    f"{data['max_score']:.1f}",
                    f"{data['avg_hallucination']:.1f}",
                )

            console.print()
            console.print(table)

        console.print()

    finally:
        store.close()


@main.command()
@click.option("--db", default=None, help="Custom database path")
def serve(db: str | None) -> None:
    """Start the AICodeTrustScore MCP server (stdio)."""
    import asyncio
    from .server import create_server
    from mcp.server.stdio import stdio_server

    async def _run() -> None:
        server = create_server(db)
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    asyncio.run(_run())


if __name__ == "__main__":
    main()
