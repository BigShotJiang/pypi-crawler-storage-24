"""CodeTrust HTTP API — FastAPI wrapper around the core trust scoring engine.

Endpoints:
    POST /v1/scan/file     — Score a single file (upload)
    POST /v1/scan/snippet  — Score a code snippet
    POST /v1/scan/diff     — Score a git diff
    POST /v1/scan/repo     — Score an entire repo (zip upload or git URL)
    GET  /v1/reports/{id}  — Get a stored report by ID
    GET  /v1/history       — Score trend for a target
    GET  /v1/benchmark     — Compare AI tools
    GET  /health           — Health check
"""

from __future__ import annotations

import hashlib
import os
import tempfile
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Header, UploadFile, File, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .analyzers import ALL_ANALYZERS
from .analyzers.hallucination import HallucinationAnalyzer
from .store import TrustStore
from .types import TrustIssue, TrustResult, IssueCategory

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

API_KEYS_ENV = "CODETRUST_API_KEYS"  # comma-separated valid keys
FREE_TIER_SCANS_PER_DAY = 10
PRO_TIER_SCANS_PER_DAY = 1000

_CODE_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx", ".go"}


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(
    title="CodeTrust API",
    description="AI code security & quality scanner — catches vulnerabilities, hallucinated dependencies, and compliance issues in AI-generated code.",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Singleton store (created on first request)
_store: TrustStore | None = None


def _get_store() -> TrustStore:
    global _store
    if _store is None:
        db_path = os.environ.get("CODETRUST_DB_PATH", "data/codetrust.db")
        _store = TrustStore(db_path)
    return _store


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

def _validate_api_key(x_api_key: str = Header(default="")) -> str:
    """Validate API key. Returns tier: 'free', 'pro', 'team', 'enterprise'."""
    if not x_api_key:
        return "free"

    valid_keys = os.environ.get(API_KEYS_ENV, "").split(",")
    valid_keys = [k.strip() for k in valid_keys if k.strip()]

    if x_api_key in valid_keys:
        return "pro"  # TODO: look up tier from Stripe

    return "free"


# ---------------------------------------------------------------------------
# Request / Response Models
# ---------------------------------------------------------------------------

class SnippetRequest(BaseModel):
    """Request to scan a code snippet."""
    code: str = Field(..., description="Source code to scan", max_length=500_000)
    language: str = Field(
        "python",
        description="Language: python, typescript, javascript, go",
    )
    ai_tool: str = Field("", description="AI tool that generated this code")
    filename: str = Field("snippet", description="Optional filename for context")


class DiffRequest(BaseModel):
    """Request to scan a git diff."""
    diff: str = Field(..., description="Git diff output", max_length=1_000_000)
    ai_tool: str = Field("", description="AI tool that generated the changes")


class ScanResult(BaseModel):
    """Scan result returned by the API."""
    id: str
    target: str
    score: int
    trust_category: str
    trust_label: str
    total_issues: int
    critical_issues: int
    high_issues: int
    breakdown: dict[str, int]
    issues: list[dict[str, Any]]
    ai_tool: str
    scan_time_ms: int


# ---------------------------------------------------------------------------
# Core scanning logic (reuses server.py functions)
# ---------------------------------------------------------------------------

def _detect_ai_tool(content: str) -> str:
    content_lower = content.lower()
    for marker, tool in [
        ("copilot", "copilot"), ("github copilot", "copilot"),
        ("cursor", "cursor"), ("claude", "claude"), ("anthropic", "claude"),
        ("chatgpt", "chatgpt"), ("openai", "chatgpt"),
        ("gemini", "gemini"), ("codewhisperer", "codewhisperer"),
    ]:
        if marker in content_lower:
            return tool
    return "unknown"


def _scan_content(
    content: str,
    file_path: Path,
    ai_tool: str,
    store: TrustStore,
) -> dict[str, Any]:
    """Run all analyzers on content and return structured result."""
    start = time.monotonic()

    all_issues: list[TrustIssue] = []
    for analyzer_cls in ALL_ANALYZERS:
        all_issues.extend(analyzer_cls.analyze_file(file_path, content))

    detected_tool = ai_tool or _detect_ai_tool(content)

    result = TrustResult(
        target=str(file_path),
        issues=all_issues,
        ai_tool=detected_tool,
    )
    result.compute_score()
    score_id = store.save_result(result)

    elapsed_ms = int((time.monotonic() - start) * 1000)

    output = result.to_dict()
    output["id"] = score_id
    output["scan_time_ms"] = elapsed_ms
    output["critical_issues"] = sum(
        1 for i in all_issues if i.severity.value == "critical"
    )
    output["high_issues"] = sum(
        1 for i in all_issues if i.severity.value == "high"
    )

    return output


def _scan_diff(
    diff_text: str,
    ai_tool: str,
    store: TrustStore,
) -> dict[str, Any]:
    """Scan a git diff — only analyses added lines."""
    start = time.monotonic()

    all_issues: list[TrustIssue] = []
    current_file: str | None = None
    added_lines: list[str] = []

    for line in diff_text.splitlines():
        if line.startswith("+++ b/"):
            if current_file and added_lines:
                fp = Path(current_file)
                if fp.suffix in _CODE_EXTENSIONS:
                    added_content = "\n".join(added_lines)
                    for analyzer_cls in ALL_ANALYZERS:
                        issues = analyzer_cls.analyze_file(fp, added_content)
                        for issue in issues:
                            issue.description = f"[IN DIFF] {issue.description}"
                        all_issues.extend(issues)
            current_file = line[6:]
            added_lines = []
        elif line.startswith("+") and not line.startswith("+++"):
            added_lines.append(line[1:])

    # Process last file
    if current_file and added_lines:
        fp = Path(current_file)
        if fp.suffix in _CODE_EXTENSIONS:
            added_content = "\n".join(added_lines)
            for analyzer_cls in ALL_ANALYZERS:
                issues = analyzer_cls.analyze_file(fp, added_content)
                for issue in issues:
                    issue.description = f"[IN DIFF] {issue.description}"
                all_issues.extend(issues)

    result = TrustResult(
        target="git diff",
        issues=all_issues,
        ai_tool=ai_tool or "unknown",
    )
    result.compute_score()
    score_id = store.save_result(result)

    elapsed_ms = int((time.monotonic() - start) * 1000)

    output = result.to_dict()
    output["id"] = score_id
    output["scan_time_ms"] = elapsed_ms
    output["critical_issues"] = sum(
        1 for i in all_issues if i.severity.value == "critical"
    )
    output["high_issues"] = sum(
        1 for i in all_issues if i.severity.value == "high"
    )

    return output


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "codetrust", "version": "0.1.0"}


@app.post("/v1/scan/snippet", response_model=None)
async def scan_snippet(
    req: SnippetRequest,
    tier: str = Depends(_validate_api_key),
) -> dict[str, Any]:
    """Scan a code snippet for security, quality, and hallucination issues."""
    ext_map = {
        "python": ".py", "typescript": ".ts", "javascript": ".js",
        "go": ".go", "tsx": ".tsx", "jsx": ".jsx",
    }
    ext = ext_map.get(req.language.lower(), ".py")
    fake_path = Path(f"{req.filename}{ext}")

    store = _get_store()
    return _scan_content(req.code, fake_path, req.ai_tool, store)


@app.post("/v1/scan/file", response_model=None)
async def scan_file(
    file: UploadFile = File(...),
    ai_tool: str = "",
    tier: str = Depends(_validate_api_key),
) -> dict[str, Any]:
    """Upload and scan a single source file."""
    if not file.filename:
        raise HTTPException(400, "Filename required")

    ext = Path(file.filename).suffix
    if ext not in _CODE_EXTENSIONS:
        raise HTTPException(
            400,
            f"Unsupported file type: {ext}. Supported: {', '.join(sorted(_CODE_EXTENSIONS))}",
        )

    content = (await file.read()).decode("utf-8", errors="replace")
    if len(content) > 500_000:
        raise HTTPException(413, "File too large (max 500KB)")

    store = _get_store()
    return _scan_content(content, Path(file.filename), ai_tool, store)


@app.post("/v1/scan/diff", response_model=None)
async def scan_diff(
    req: DiffRequest,
    tier: str = Depends(_validate_api_key),
) -> dict[str, Any]:
    """Scan a git diff — only analyses added/changed lines."""
    if not req.diff.strip():
        raise HTTPException(400, "Empty diff")

    store = _get_store()
    return _scan_diff(req.diff, req.ai_tool, store)


@app.get("/v1/reports/{report_id}", response_model=None)
async def get_report(
    report_id: str,
    tier: str = Depends(_validate_api_key),
) -> dict[str, Any]:
    """Retrieve a stored scan report by ID."""
    store = _get_store()
    result = store.get_score(report_id)
    if not result:
        raise HTTPException(404, f"Report not found: {report_id}")
    return result


@app.get("/v1/benchmark", response_model=None)
async def benchmark(
    tier: str = Depends(_validate_api_key),
) -> dict[str, Any]:
    """Compare trust scores across AI tools (Cursor, Copilot, Claude, etc.)."""
    store = _get_store()
    return store.get_benchmark_by_tool()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Run the API server."""
    import uvicorn

    host = os.environ.get("CODETRUST_HOST", "0.0.0.0")
    port = int(os.environ.get("CODETRUST_PORT", "8080"))
    uvicorn.run(
        "aicodetrustcore.api:app",
        host=host,
        port=port,
        reload=False,
    )
