"""Data types for AICodeTrustScore analysis."""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class IssueCategory(str, Enum):
    """Categories of trust issues."""

    CORRECTNESS = "correctness"
    SAFETY = "safety"
    TEST_COVERAGE = "test_coverage"
    DEPENDENCY = "dependency"
    CONSISTENCY = "consistency"
    HALLUCINATION = "hallucination"


class Severity(str, Enum):
    """Issue severity levels."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class TrustCategory(str, Enum):
    """Overall trust score categories."""

    SHIP_IT = "ship_it"           # 90-100
    REVIEW = "review"             # 70-89
    NEEDS_WORK = "needs_work"     # 50-69
    DONT_SHIP = "dont_ship"       # 0-49


# Penalty per issue by category (deducted from 100).
CATEGORY_PENALTY: dict[IssueCategory, int] = {
    IssueCategory.CORRECTNESS: 5,
    IssueCategory.SAFETY: 15,
    IssueCategory.TEST_COVERAGE: 2,
    IssueCategory.DEPENDENCY: 8,
    IssueCategory.CONSISTENCY: 1,
    IssueCategory.HALLUCINATION: 20,
}


def score_to_trust_category(score: float) -> TrustCategory:
    """Map a numeric trust score to a named category."""
    if score >= 90:
        return TrustCategory.SHIP_IT
    elif score >= 70:
        return TrustCategory.REVIEW
    elif score >= 50:
        return TrustCategory.NEEDS_WORK
    else:
        return TrustCategory.DONT_SHIP


TRUST_CATEGORY_LABELS: dict[TrustCategory, str] = {
    TrustCategory.SHIP_IT: "Ship it (green)",
    TrustCategory.REVIEW: "Review before shipping (yellow)",
    TrustCategory.NEEDS_WORK: "Needs work (orange)",
    TrustCategory.DONT_SHIP: "Don't ship (red)",
}


@dataclass
class TrustIssue:
    """A single trust issue detected in AI-generated code."""

    analyzer: str
    category: IssueCategory
    severity: Severity
    title: str
    description: str
    file_path: str = ""
    line_start: int = 0
    line_end: int = 0
    suggestion: str = ""
    code_snippet: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        d = asdict(self)
        d["category"] = self.category.value
        d["severity"] = self.severity.value
        return d


@dataclass
class TrustResult:
    """Aggregated trust score result."""

    target: str
    issues: list[TrustIssue] = field(default_factory=list)
    score: float = 100.0
    trust_category: str = ""
    correctness_score: float = 100.0
    safety_score: float = 100.0
    test_coverage_score: float = 100.0
    dependency_score: float = 100.0
    consistency_score: float = 100.0
    hallucination_score: float = 100.0
    ai_tool: str = "unknown"
    created_at: str = field(
        default_factory=lambda: datetime.datetime.utcnow().isoformat()
    )

    def compute_score(self) -> float:
        """Calculate trust score using weighted category penalties."""
        score = 100.0
        category_deductions: dict[IssueCategory, float] = {c: 0.0 for c in IssueCategory}

        for issue in self.issues:
            penalty = CATEGORY_PENALTY.get(issue.category, 5)
            score -= penalty
            category_deductions[issue.category] += penalty

        self.score = max(0.0, min(100.0, score))
        self.trust_category = score_to_trust_category(self.score).value

        # Per-category scores (each starts at 100, deducts per issue in that category)
        self.correctness_score = max(0.0, 100.0 - category_deductions[IssueCategory.CORRECTNESS])
        self.safety_score = max(0.0, 100.0 - category_deductions[IssueCategory.SAFETY])
        self.test_coverage_score = max(0.0, 100.0 - category_deductions[IssueCategory.TEST_COVERAGE])
        self.dependency_score = max(0.0, 100.0 - category_deductions[IssueCategory.DEPENDENCY])
        self.consistency_score = max(0.0, 100.0 - category_deductions[IssueCategory.CONSISTENCY])
        self.hallucination_score = max(0.0, 100.0 - category_deductions[IssueCategory.HALLUCINATION])

        return self.score

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "target": self.target,
            "score": self.score,
            "trust_category": self.trust_category,
            "trust_label": TRUST_CATEGORY_LABELS.get(
                score_to_trust_category(self.score), ""
            ),
            "breakdown": {
                "correctness": self.correctness_score,
                "safety": self.safety_score,
                "test_coverage": self.test_coverage_score,
                "dependency": self.dependency_score,
                "consistency": self.consistency_score,
                "hallucination": self.hallucination_score,
            },
            "total_issues": len(self.issues),
            "ai_tool": self.ai_tool,
            "created_at": self.created_at,
            "issues": [i.to_dict() for i in self.issues],
        }
