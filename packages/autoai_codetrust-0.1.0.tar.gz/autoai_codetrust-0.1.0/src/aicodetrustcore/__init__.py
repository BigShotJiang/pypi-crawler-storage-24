"""AICodeTrustScore -- Continuous trust scoring for AI-generated code.

Analyzes code produced by Cursor, Copilot, Claude, and other AI tools,
assigning a 0-100 trust score based on correctness, safety, test coverage,
dependency risk, consistency, and hallucination detection.
"""

__version__ = "0.1.0"
