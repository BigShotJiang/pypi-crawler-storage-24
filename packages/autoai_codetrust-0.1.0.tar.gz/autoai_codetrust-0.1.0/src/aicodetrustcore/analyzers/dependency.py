"""Dependency analyzer -- checks for risky, outdated, or hallucinated dependencies.

Checks:
- Imports of non-existent packages (AI hallucination)
- Known vulnerable patterns
- Deprecated APIs
- Overly broad version ranges
- Unnecessary dependencies (could use stdlib)
"""

from __future__ import annotations

import re
from pathlib import Path

from ..types import TrustIssue, IssueCategory, Severity


_CODE_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx", ".go"}

# Known phantom packages that AI commonly hallucinates
_PHANTOM_PYTHON_PACKAGES: set[str] = {
    "utils",            # Very common AI hallucination
    "helpers",          # Not a real package
    "common",           # Not a real package
    "config",           # Ambiguous -- not a standard pip package
    "database",         # Not a real standalone package
    "models",           # Not a pip package (often local module confused with import)
    "flask_utils",      # Does not exist
    "django_helpers",   # Does not exist
    "fastapi_utils",    # Existed briefly but often hallucinated
    "python_utils",     # Not a real package
    "ai_tools",         # Does not exist
    "ml_utils",         # Does not exist
    "data_utils",       # Does not exist
    "web_utils",        # Does not exist
}

_PHANTOM_NPM_PACKAGES: set[str] = {
    "utils",
    "helpers",
    "common",
    "config",
    "react-utils",
    "vue-helpers",
    "node-helpers",
    "api-client",
    "auth-utils",
    "data-helpers",
}

# Known deprecated Python APIs
_DEPRECATED_PYTHON_APIS = [
    (re.compile(r'from\s+distutils\b'), "distutils is deprecated since Python 3.10 -- use setuptools"),
    (re.compile(r'from\s+imp\s+import\b'), "imp module is deprecated -- use importlib"),
    (re.compile(r'from\s+optparse\b'), "optparse is deprecated -- use argparse"),
    (re.compile(r'asyncio\.coroutine'), "asyncio.coroutine is deprecated -- use async def"),
    (re.compile(r'collections\.(?:Mapping|Sequence|Set|MutableMapping|MutableSequence)\b'),
     "collections ABCs moved to collections.abc in Python 3.3+"),
    (re.compile(r'logging\.warn\b'), "logging.warn is deprecated -- use logging.warning"),
    (re.compile(r'assertEquals\b'), "assertEquals is deprecated -- use assertEqual"),
    (re.compile(r'\.readfp\b'), "readfp is deprecated -- use read_file"),
]

# Known deprecated JS/TS APIs
_DEPRECATED_JS_APIS = [
    (re.compile(r'new\s+Buffer\s*\('), "new Buffer() is deprecated -- use Buffer.from() or Buffer.alloc()"),
    (re.compile(r'__defineGetter__'), "__defineGetter__ is deprecated -- use Object.defineProperty"),
    (re.compile(r'__defineSetter__'), "__defineSetter__ is deprecated -- use Object.defineProperty"),
    (re.compile(r'document\.write\s*\('), "document.write is deprecated in modern JS"),
    (re.compile(r'escape\s*\('), "escape() is deprecated -- use encodeURIComponent"),
    (re.compile(r'unescape\s*\('), "unescape() is deprecated -- use decodeURIComponent"),
]

# Stdlib alternatives (AI often imports packages when stdlib suffices)
_UNNECESSARY_DEPS_PYTHON: dict[str, str] = {
    "requests": "For simple HTTP: urllib.request is in stdlib. For async: aiohttp.",
    "pathlib2": "pathlib is in stdlib since Python 3.4",
    "typing_extensions": "Most typing features are in stdlib typing since Python 3.10",
    "six": "Python 2 compatibility layer -- unnecessary for Python 3 only projects",
    "future": "Python 2 compatibility -- unnecessary for Python 3 only projects",
    "enum34": "enum is in stdlib since Python 3.4",
}


class DependencyAnalyzer:
    """Detects dependency risks in AI-generated code."""

    name = "dependency"

    @classmethod
    def analyze_file(cls, file_path: Path, content: str) -> list[TrustIssue]:
        """Analyse a file for dependency issues."""
        findings: list[TrustIssue] = []

        if file_path.suffix not in _CODE_EXTENSIONS:
            return findings

        lines = content.splitlines()
        rel_path = str(file_path)
        is_python = file_path.suffix == ".py"
        is_js_ts = file_path.suffix in {".ts", ".tsx", ".js", ".jsx"}

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # Skip comments
            if stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("*"):
                continue

            if is_python:
                findings.extend(cls._check_python_imports(rel_path, i, stripped))
                findings.extend(cls._check_deprecated_python(rel_path, i, stripped))

            if is_js_ts:
                findings.extend(cls._check_js_imports(rel_path, i, stripped))
                findings.extend(cls._check_deprecated_js(rel_path, i, stripped))

        return findings

    @classmethod
    def _check_python_imports(
        cls, rel_path: str, line_num: int, line: str
    ) -> list[TrustIssue]:
        """Check Python imports for phantom packages and unnecessary deps."""
        findings: list[TrustIssue] = []

        # Extract import package name
        import_match = re.match(r'(?:from\s+(\w+)|import\s+(\w+))', line)
        if not import_match:
            return findings

        package = import_match.group(1) or import_match.group(2)
        if not package:
            return findings

        # Check for phantom packages
        if package in _PHANTOM_PYTHON_PACKAGES:
            findings.append(TrustIssue(
                analyzer=cls.name,
                category=IssueCategory.DEPENDENCY,
                severity=Severity.HIGH,
                title=f"Possibly hallucinated import: '{package}'",
                description=f"'{package}' is commonly hallucinated by AI -- it's not a standard pip package. "
                            f"This may be a local module or the AI invented it.",
                file_path=rel_path,
                line_start=line_num,
                suggestion=f"Verify '{package}' exists: pip show {package}. If it's a local module, use relative imports.",
                code_snippet=line[:200],
            ))

        # Check for unnecessary dependencies
        if package in _UNNECESSARY_DEPS_PYTHON:
            findings.append(TrustIssue(
                analyzer=cls.name,
                category=IssueCategory.DEPENDENCY,
                severity=Severity.LOW,
                title=f"Potentially unnecessary dependency: '{package}'",
                description=_UNNECESSARY_DEPS_PYTHON[package],
                file_path=rel_path,
                line_start=line_num,
                suggestion="Consider using the stdlib alternative to reduce dependency count.",
                code_snippet=line[:200],
            ))

        return findings

    @classmethod
    def _check_js_imports(
        cls, rel_path: str, line_num: int, line: str
    ) -> list[TrustIssue]:
        """Check JS/TS imports for phantom packages."""
        findings: list[TrustIssue] = []

        import_match = re.match(
            r'(?:import\s+.*\s+from\s+["\']([^"\'./][^"\']*)["\']|'
            r'require\s*\(\s*["\']([^"\'./][^"\']*)["\'])',
            line,
        )
        if not import_match:
            return findings

        package = import_match.group(1) or import_match.group(2)
        if not package:
            return findings

        # Strip scope and subpath
        base_package = package.split("/")[0]
        if base_package.startswith("@") and "/" in package:
            base_package = "/".join(package.split("/")[:2])

        if base_package in _PHANTOM_NPM_PACKAGES:
            findings.append(TrustIssue(
                analyzer=cls.name,
                category=IssueCategory.DEPENDENCY,
                severity=Severity.HIGH,
                title=f"Possibly hallucinated import: '{base_package}'",
                description=f"'{base_package}' is commonly hallucinated by AI -- verify it exists on npm.",
                file_path=rel_path,
                line_start=line_num,
                suggestion=f"Verify: npm info {base_package}. If local, use relative imports ('./...').",
                code_snippet=line[:200],
            ))

        return findings

    @classmethod
    def _check_deprecated_python(
        cls, rel_path: str, line_num: int, line: str
    ) -> list[TrustIssue]:
        """Check for deprecated Python APIs."""
        findings: list[TrustIssue] = []
        for pattern, desc in _DEPRECATED_PYTHON_APIS:
            if pattern.search(line):
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.DEPENDENCY,
                    severity=Severity.MEDIUM,
                    title="Deprecated API usage",
                    description=desc,
                    file_path=rel_path,
                    line_start=line_num,
                    suggestion="Update to the recommended replacement API.",
                    code_snippet=line[:200],
                ))
                break
        return findings

    @classmethod
    def _check_deprecated_js(
        cls, rel_path: str, line_num: int, line: str
    ) -> list[TrustIssue]:
        """Check for deprecated JS/TS APIs."""
        findings: list[TrustIssue] = []
        for pattern, desc in _DEPRECATED_JS_APIS:
            if pattern.search(line):
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.DEPENDENCY,
                    severity=Severity.MEDIUM,
                    title="Deprecated API usage",
                    description=desc,
                    file_path=rel_path,
                    line_start=line_num,
                    suggestion="Update to the recommended replacement API.",
                    code_snippet=line[:200],
                ))
                break
        return findings
