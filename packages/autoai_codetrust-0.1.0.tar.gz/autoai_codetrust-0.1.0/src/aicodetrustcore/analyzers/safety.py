"""Safety analyzer -- detects security vulnerabilities in AI-generated code.

Checks:
- SQL injection patterns
- Command injection
- Path traversal
- Hardcoded credentials
- Insecure random for crypto
- Prototype pollution (JS)
- eval/exec usage
"""

from __future__ import annotations

import re
from pathlib import Path

from ..types import TrustIssue, IssueCategory, Severity


_CODE_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx", ".go"}

# SQL injection
_SQL_INJECTION_PATTERNS = [
    (re.compile(r'f["\'].*(?:SELECT|INSERT|UPDATE|DELETE|DROP|ALTER)\s.*\{', re.IGNORECASE),
     "SQL query built with f-string interpolation"),
    (re.compile(r'["\'].*(?:SELECT|INSERT|UPDATE|DELETE)\s.*["\']\s*\+\s*', re.IGNORECASE),
     "SQL query built with string concatenation"),
    (re.compile(r'`.*(?:SELECT|INSERT|UPDATE|DELETE)\s.*\$\{', re.IGNORECASE),
     "SQL query built with template literal interpolation"),
    (re.compile(r'["\'].*(?:SELECT|INSERT|UPDATE|DELETE)\s.*%s.*["\']\s*%', re.IGNORECASE),
     "SQL query using unsafe % string formatting"),
]

# Command injection
_COMMAND_INJECTION_PATTERNS = [
    (re.compile(r'os\.system\s*\('),
     "os.system() is vulnerable to command injection -- use subprocess with shell=False"),
    (re.compile(r'subprocess\.\w+\s*\([^)]*shell\s*=\s*True'),
     "subprocess with shell=True is vulnerable to command injection"),
    (re.compile(r'child_process\.exec\s*\('),
     "child_process.exec() is vulnerable to command injection -- use execFile instead"),
    (re.compile(r'os\.popen\s*\('),
     "os.popen() is vulnerable to command injection"),
]

# Path traversal
_PATH_TRAVERSAL_PATTERNS = [
    (re.compile(r'open\s*\(.*\+.*(?:request|req|params|query|args|input)', re.IGNORECASE),
     "File open with user-controlled path -- path traversal risk"),
    (re.compile(r'(?:readFile|readFileSync|createReadStream)\s*\(.*\+', re.IGNORECASE),
     "Node.js file read with concatenated path -- path traversal risk"),
    (re.compile(r'os\.path\.join\s*\(.*(?:request|input|args|params)', re.IGNORECASE),
     "os.path.join with user input does not prevent path traversal"),
]

# Hardcoded credentials
_CREDENTIAL_PATTERNS = [
    (re.compile(r'(?:api[_-]?key|apikey)\s*[=:]\s*["\'][A-Za-z0-9_\-]{16,}["\']', re.IGNORECASE),
     "Hardcoded API key"),
    (re.compile(r'(?:password|passwd|pwd)\s*[=:]\s*["\'][^"\']{4,}["\']', re.IGNORECASE),
     "Hardcoded password"),
    (re.compile(r'(?:secret|token|auth)\s*[=:]\s*["\'][A-Za-z0-9_\-]{16,}["\']', re.IGNORECASE),
     "Hardcoded secret/token"),
    (re.compile(r'(?:aws_access_key_id|aws_secret_access_key)\s*[=:]\s*["\']', re.IGNORECASE),
     "Hardcoded AWS credential"),
    (re.compile(r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----'),
     "Private key embedded in source code"),
]

# Insecure random for crypto
_INSECURE_RANDOM_PATTERNS = [
    (re.compile(r'random\.(?:random|randint|choice|randrange)\s*\('),
     "Python random module is not cryptographically secure -- use secrets module instead"),
    (re.compile(r'Math\.random\s*\('),
     "Math.random() is not cryptographically secure -- use crypto.getRandomValues()"),
    (re.compile(r'rand\.\w+\s*\('),
     "Standard random may not be cryptographically secure for security contexts"),
]

# Prototype pollution (JS)
_PROTOTYPE_POLLUTION_PATTERNS = [
    (re.compile(r'Object\.assign\s*\(\s*\{\s*\}'),
     "Object.assign with empty target can be used for prototype pollution if source is user-controlled"),
    (re.compile(r'\[.*\]\s*=.*(?:req|request|params|query|body)', re.IGNORECASE),
     "Dynamic property assignment with user input -- prototype pollution risk"),
    (re.compile(r'__proto__'),
     "Direct __proto__ access -- prototype pollution vector"),
]

# eval/exec
_EVAL_EXEC_PATTERNS = [
    (re.compile(r'\beval\s*\('),
     "eval() executes arbitrary code -- never use on untrusted input"),
    (re.compile(r'\bexec\s*\('),
     "exec() executes arbitrary code -- avoid on untrusted input"),
    (re.compile(r'new\s+Function\s*\('),
     "new Function() is equivalent to eval -- avoid with untrusted input"),
]


class SafetyAnalyzer:
    """Detects security safety issues in AI-generated code."""

    name = "safety"

    @classmethod
    def analyze_file(cls, file_path: Path, content: str) -> list[TrustIssue]:
        """Analyse a single file for safety issues."""
        findings: list[TrustIssue] = []

        if file_path.suffix not in _CODE_EXTENSIONS:
            return findings

        lines = content.splitlines()
        rel_path = str(file_path)
        is_test = any(x in str(file_path).lower() for x in ["test", "spec", "mock", "fixture"])

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # Skip comments
            if stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("*"):
                continue

            # SQL injection
            for pattern, desc in _SQL_INJECTION_PATTERNS:
                if pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.SAFETY,
                        severity=Severity.CRITICAL,
                        title="SQL injection vulnerability",
                        description=f"{desc}. Use parameterized queries instead.",
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Use parameterized queries: cursor.execute('SELECT * FROM t WHERE id = ?', (user_id,))",
                        code_snippet=stripped[:200],
                    ))
                    break

            # Command injection
            for pattern, desc in _COMMAND_INJECTION_PATTERNS:
                if pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.SAFETY,
                        severity=Severity.CRITICAL,
                        title="Command injection vulnerability",
                        description=desc,
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Use subprocess.run() with shell=False and pass args as a list.",
                        code_snippet=stripped[:200],
                    ))
                    break

            # Path traversal
            for pattern, desc in _PATH_TRAVERSAL_PATTERNS:
                if pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.SAFETY,
                        severity=Severity.HIGH,
                        title="Path traversal risk",
                        description=desc,
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Validate paths with pathlib.resolve() and check they stay within allowed directory.",
                        code_snippet=stripped[:200],
                    ))
                    break

            # Hardcoded credentials
            for pattern, desc in _CREDENTIAL_PATTERNS:
                if pattern.search(line):
                    sev = Severity.LOW if is_test else Severity.CRITICAL
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.SAFETY,
                        severity=sev,
                        title=desc,
                        description=f"{desc} detected in source code. Secrets in code get committed to version control.",
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Use environment variables or a secret manager.",
                        code_snippet=re.sub(r'["\'][^"\']{4,}["\']', '"***REDACTED***"', stripped[:200]),
                    ))
                    break

            # Insecure random for crypto contexts
            for pattern, desc in _INSECURE_RANDOM_PATTERNS:
                if pattern.search(line):
                    # Only flag if it looks like a security context
                    security_context = any(kw in content.lower() for kw in [
                        "token", "password", "secret", "nonce", "salt", "session", "otp",
                        "csrf", "key", "encrypt",
                    ])
                    if security_context:
                        findings.append(TrustIssue(
                            analyzer=cls.name,
                            category=IssueCategory.SAFETY,
                            severity=Severity.HIGH,
                            title="Insecure random in security context",
                            description=desc,
                            file_path=rel_path,
                            line_start=i,
                            line_end=i,
                            suggestion="Use secrets.token_hex() or secrets.token_urlsafe() for security-sensitive randomness.",
                            code_snippet=stripped[:200],
                        ))
                        break

            # Prototype pollution (JS/TS only)
            if file_path.suffix in {".js", ".jsx", ".ts", ".tsx"}:
                for pattern, desc in _PROTOTYPE_POLLUTION_PATTERNS:
                    if pattern.search(line):
                        findings.append(TrustIssue(
                            analyzer=cls.name,
                            category=IssueCategory.SAFETY,
                            severity=Severity.HIGH,
                            title="Prototype pollution risk",
                            description=desc,
                            file_path=rel_path,
                            line_start=i,
                            line_end=i,
                            suggestion="Validate input properties. Use Object.create(null) or Map instead of plain objects.",
                            code_snippet=stripped[:200],
                        ))
                        break

            # eval/exec
            for pattern, desc in _EVAL_EXEC_PATTERNS:
                if pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.SAFETY,
                        severity=Severity.CRITICAL,
                        title="Dangerous code execution",
                        description=desc,
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Avoid eval/exec. Use safe alternatives like json.loads, ast.literal_eval, or proper parsers.",
                        code_snippet=stripped[:200],
                    ))
                    break

        return findings
