"""AICodeTrustScore analyzers -- each module detects a specific class of trust issue."""

from __future__ import annotations

from .correctness import CorrectnessAnalyzer
from .safety import SafetyAnalyzer
from .test_coverage import TestCoverageAnalyzer
from .dependency import DependencyAnalyzer
from .consistency import ConsistencyAnalyzer
from .hallucination import HallucinationAnalyzer

ALL_ANALYZERS = [
    CorrectnessAnalyzer,
    SafetyAnalyzer,
    TestCoverageAnalyzer,
    DependencyAnalyzer,
    ConsistencyAnalyzer,
    HallucinationAnalyzer,
]

__all__ = [
    "CorrectnessAnalyzer",
    "SafetyAnalyzer",
    "TestCoverageAnalyzer",
    "DependencyAnalyzer",
    "ConsistencyAnalyzer",
    "HallucinationAnalyzer",
    "ALL_ANALYZERS",
]
