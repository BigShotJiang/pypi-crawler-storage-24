"""Consistency analyzer -- checks if AI code matches existing project style.

Checks:
- Naming convention mismatch with existing code
- Different error handling patterns than the project uses
- Import style inconsistency
- Comment style mismatch
- Architecture layer violations
"""

from __future__ import annotations

import re
from pathlib import Path

from ..types import TrustIssue, IssueCategory, Severity


_CODE_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx", ".go"}


class ConsistencyAnalyzer:
    """Detects style and pattern inconsistencies in AI-generated code."""

    name = "consistency"

    @classmethod
    def analyze_file(cls, file_path: Path, content: str) -> list[TrustIssue]:
        """Analyse a file for consistency issues."""
        findings: list[TrustIssue] = []

        if file_path.suffix not in _CODE_EXTENSIONS:
            return findings

        lines = content.splitlines()
        rel_path = str(file_path)
        is_python = file_path.suffix == ".py"
        is_js_ts = file_path.suffix in {".ts", ".tsx", ".js", ".jsx"}

        # Naming convention checks
        if is_python:
            findings.extend(cls._check_python_naming(rel_path, lines))
            findings.extend(cls._check_python_import_style(rel_path, lines))
            findings.extend(cls._check_python_string_style(rel_path, lines))

        if is_js_ts:
            findings.extend(cls._check_js_naming(rel_path, lines))
            findings.extend(cls._check_js_import_style(rel_path, lines))

        # Mixed tab/space indentation
        findings.extend(cls._check_indentation(rel_path, lines))

        return findings

    @classmethod
    def _check_python_naming(cls, rel_path: str, lines: list[str]) -> list[TrustIssue]:
        """Check Python naming conventions (PEP 8)."""
        findings: list[TrustIssue] = []
        camel_case_var = re.compile(r'^\s*([a-z]+[A-Z]\w*)\s*=')

        camel_count = 0
        for i, line in enumerate(lines, 1):
            m = camel_case_var.match(line)
            if m:
                var_name = m.group(1)
                # Exclude common abbreviations
                if not re.match(r'^(is|has|can|should|will)', var_name):
                    camel_count += 1
                    if camel_count <= 3:  # Report first few only
                        findings.append(TrustIssue(
                            analyzer=cls.name,
                            category=IssueCategory.CONSISTENCY,
                            severity=Severity.LOW,
                            title=f"camelCase variable '{var_name}' in Python",
                            description="Python convention is snake_case for variables and functions (PEP 8).",
                            file_path=rel_path,
                            line_start=i,
                            suggestion=f"Rename to '{cls._to_snake_case(var_name)}'.",
                            code_snippet=line.strip()[:200],
                        ))

        # Classes not in PascalCase
        class_pattern = re.compile(r'^\s*class\s+(\w+)')
        for i, line in enumerate(lines, 1):
            m = class_pattern.match(line)
            if m:
                name = m.group(1)
                if "_" in name and not name.startswith("_"):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.CONSISTENCY,
                        severity=Severity.LOW,
                        title=f"Class '{name}' uses snake_case instead of PascalCase",
                        description="Python convention is PascalCase for class names (PEP 8).",
                        file_path=rel_path,
                        line_start=i,
                        suggestion=f"Rename to PascalCase.",
                        code_snippet=line.strip()[:200],
                    ))

        return findings

    @classmethod
    def _check_python_import_style(cls, rel_path: str, lines: list[str]) -> list[TrustIssue]:
        """Check for inconsistent import styles."""
        findings: list[TrustIssue] = []

        has_wildcard = False
        wildcard_line = 0
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if re.match(r'from\s+\w+\s+import\s+\*', stripped):
                has_wildcard = True
                wildcard_line = i

        if has_wildcard:
            findings.append(TrustIssue(
                analyzer=cls.name,
                category=IssueCategory.CONSISTENCY,
                severity=Severity.MEDIUM,
                title="Wildcard import (from x import *)",
                description="Wildcard imports pollute the namespace and make it unclear what's available.",
                file_path=rel_path,
                line_start=wildcard_line,
                suggestion="Import specific names: from module import Class1, func1",
            ))

        return findings

    @classmethod
    def _check_python_string_style(cls, rel_path: str, lines: list[str]) -> list[TrustIssue]:
        """Check for mixed single/double quotes (inconsistency indicator)."""
        findings: list[TrustIssue] = []
        single_count = 0
        double_count = 0

        for line in lines:
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            # Count string literal starts (simple heuristic)
            single_count += len(re.findall(r"(?<![\"\\])'(?!'')", stripped))
            double_count += len(re.findall(r'(?<![\'\\])"(?!"")', stripped))

        total = single_count + double_count
        if total > 10:  # Only check if there are enough strings
            ratio = min(single_count, double_count) / max(single_count, double_count, 1)
            if 0.3 < ratio < 0.7:
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.CONSISTENCY,
                    severity=Severity.INFO,
                    title="Inconsistent string quote style",
                    description=f"Mixed use of single ({single_count}) and double ({double_count}) quotes. "
                                "Pick one style and use it consistently.",
                    file_path=rel_path,
                    line_start=1,
                    suggestion="Use a formatter like black (Python) or prettier (JS) to enforce consistent quotes.",
                ))

        return findings

    @classmethod
    def _check_js_naming(cls, rel_path: str, lines: list[str]) -> list[TrustIssue]:
        """Check JS/TS naming conventions."""
        findings: list[TrustIssue] = []
        snake_case_var = re.compile(r'^\s*(?:const|let|var)\s+([a-z]+_[a-z_]+)\s*=')

        snake_count = 0
        for i, line in enumerate(lines, 1):
            m = snake_case_var.match(line)
            if m:
                var_name = m.group(1)
                snake_count += 1
                if snake_count <= 3:
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.CONSISTENCY,
                        severity=Severity.LOW,
                        title=f"snake_case variable '{var_name}' in JS/TS",
                        description="JavaScript/TypeScript convention is camelCase for variables.",
                        file_path=rel_path,
                        line_start=i,
                        suggestion=f"Rename to '{cls._to_camel_case(var_name)}'.",
                        code_snippet=line.strip()[:200],
                    ))

        return findings

    @classmethod
    def _check_js_import_style(cls, rel_path: str, lines: list[str]) -> list[TrustIssue]:
        """Check for mixed require/import in JS/TS."""
        findings: list[TrustIssue] = []
        has_import = False
        has_require = False

        for line in lines:
            stripped = line.strip()
            if re.match(r'import\s+', stripped):
                has_import = True
            if re.search(r'require\s*\(', stripped):
                has_require = True

        if has_import and has_require:
            findings.append(TrustIssue(
                analyzer=cls.name,
                category=IssueCategory.CONSISTENCY,
                severity=Severity.LOW,
                title="Mixed import and require() statements",
                description="File uses both ES module imports and CommonJS require() -- pick one style.",
                file_path=rel_path,
                line_start=1,
                suggestion="Use ES modules (import/export) consistently in modern JS/TS projects.",
            ))

        return findings

    @classmethod
    def _check_indentation(cls, rel_path: str, lines: list[str]) -> list[TrustIssue]:
        """Check for mixed tabs and spaces."""
        findings: list[TrustIssue] = []
        has_tabs = False
        has_spaces = False

        for line in lines:
            if line.startswith("\t"):
                has_tabs = True
            elif line.startswith("  "):
                has_spaces = True

        if has_tabs and has_spaces:
            findings.append(TrustIssue(
                analyzer=cls.name,
                category=IssueCategory.CONSISTENCY,
                severity=Severity.MEDIUM,
                title="Mixed tabs and spaces for indentation",
                description="File uses both tabs and spaces for indentation -- this causes subtle bugs.",
                file_path=rel_path,
                line_start=1,
                suggestion="Configure your editor to use consistent indentation (spaces recommended).",
            ))

        return findings

    @staticmethod
    def _to_snake_case(name: str) -> str:
        """Convert camelCase to snake_case."""
        s = re.sub(r'([A-Z])', r'_\1', name).lower()
        return s.lstrip("_")

    @staticmethod
    def _to_camel_case(name: str) -> str:
        """Convert snake_case to camelCase."""
        parts = name.split("_")
        return parts[0] + "".join(p.capitalize() for p in parts[1:])
