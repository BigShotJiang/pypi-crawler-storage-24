"""Hallucination analyzer -- THE DIFFERENTIATOR.

Detects AI hallucination patterns in generated code:
- References to APIs that don't exist in imported libraries
- Method signatures that don't match library documentation
- Made-up configuration options
- Non-existent CLI flags
- Phantom package imports (packages that don't exist on PyPI/npm)
- Fictional error codes
- Invented database table/column names
"""

from __future__ import annotations

import re
from pathlib import Path

from ..types import TrustIssue, IssueCategory, Severity


_CODE_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx", ".go"}

# ── Phantom APIs: methods/attrs that AI commonly invents ───────────────

# Python stdlib hallucinations -- methods that don't exist
_PYTHON_STDLIB_PHANTOMS: dict[str, list[str]] = {
    "os": ["get_env", "set_env", "read_file", "write_file", "file_exists",
           "create_dir", "delete_dir", "copy_file", "get_cwd"],
    "os.path": ["is_valid", "normalize", "get_extension", "to_absolute",
                 "file_size", "read"],
    "json": ["parse", "stringify", "read_file", "write_file", "validate",
             "from_string", "to_string"],
    "sys": ["get_args", "get_env", "set_env", "read_input", "write_output"],
    "pathlib.Path": ["read", "write", "copy", "move", "delete",
                     "get_extension", "get_name", "to_string",
                     "create", "remove"],
    "datetime": ["now", "parse", "from_string", "to_string", "format_date",
                 "current_time", "current_date"],
    "datetime.datetime": ["from_string", "to_string", "format_date",
                          "parse", "to_timestamp", "from_date"],
    "re": ["find", "find_all", "replace", "test", "is_match", "extract"],
    "collections": ["HashMap", "ArrayList", "LinkedList", "TreeMap",
                    "HashSet", "Stack", "Queue"],
    "typing": ["Number", "String", "Array", "Map", "Boolean", "Null"],
    "sqlite3": ["execute_query", "fetch_one", "fetch_many", "insert",
                "update", "delete", "create_table"],
    "hashlib": ["hash", "encrypt", "decrypt", "sign", "verify"],
    "subprocess": ["execute", "run_command", "shell", "exec"],
    "http": ["get", "post", "put", "delete", "request", "fetch"],
    "logging": ["log", "info", "debug", "error", "fatal",
                "set_level", "set_format"],
    "socket": ["connect_to", "send_data", "receive_data", "listen_on"],
    "threading": ["create_thread", "run_thread", "wait", "sleep"],
    "asyncio": ["async_run", "await_all", "parallel", "concurrent",
                "run_sync", "wait_all"],
    "math": ["average", "median", "min_val", "max_val", "clamp",
             "round_to", "to_int", "to_float"],
    "string": ["format", "join", "split", "replace", "trim",
               "to_upper", "to_lower", "contains", "starts_with"],
}

# Popular third-party library hallucinations
_PYTHON_THIRDPARTY_PHANTOMS: dict[str, list[str]] = {
    "requests": ["fetch", "send", "Request", "get_json", "post_json",
                 "download", "upload", "async_get", "async_post"],
    "flask": ["create_app", "get_route", "post_route", "json_response",
              "send_json", "get_json", "parse_body", "get_params"],
    "fastapi": ["create_app", "get_route", "post_route", "json_response",
                "get_json", "parse_body", "validate_body",
                "create_router", "mount_router"],
    "django": ["create_app", "get_model", "create_model",
               "get_view", "create_view", "json_response"],
    "sqlalchemy": ["create_model", "get_session", "execute_query",
                   "query_all", "query_one", "insert", "update",
                   "delete", "create_table", "drop_table"],
    "pandas": ["read_json", "read_dict", "to_dict", "to_json",
               "filter_by", "sort", "group", "aggregate",
               "create_dataframe", "from_dict", "from_list"],
    "numpy": ["create_array", "from_list", "to_list", "reshape_to",
              "flatten_to", "sort_by", "filter_by", "map",
              "reduce", "average", "median"],
    "pytest": ["assert_equal", "assert_true", "assert_false",
               "assert_raises", "assert_in", "assert_not_in",
               "expect", "mock_function", "create_mock"],
    "pydantic": ["create_model", "from_json", "to_json", "validate_json",
                 "get_fields", "set_field", "get_schema"],
    "click": ["argument_option", "get_args", "parse_args",
              "create_command", "create_group", "run_command"],
    "rich": ["print_table", "print_panel", "create_table",
             "create_panel", "format_text", "highlight"],
    "celery": ["run_task", "execute_task", "schedule_task",
               "get_result", "wait_for_result"],
    "boto3": ["get_client", "create_client", "get_resource",
              "create_resource", "upload", "download"],
}

# Node.js / JS library hallucinations
_JS_PHANTOMS: dict[str, list[str]] = {
    "express": ["createApp", "getRoute", "postRoute", "jsonResponse",
                "parseBody", "getParams", "getQuery", "sendJson",
                "createRouter", "mountRouter"],
    "react": ["createState", "getState", "setState", "createComponent",
              "getProps", "setProps", "render", "createRef",
              "useQuery", "useFetch", "useApi"],
    "next": ["createApp", "getRoute", "createRoute",
             "getServerProps", "getClientProps",
             "createMiddleware", "useRouter"],
    "axios": ["fetch", "send", "getJson", "postJson",
              "request", "download", "upload"],
    "fs": ["readJson", "writeJson", "readText", "writeText",
           "copyFile", "deleteFile", "createDir", "deleteDir",
           "listFiles", "fileExists", "isFile", "isDir"],
    "path": ["isValid", "getExtension", "getName",
             "getDir", "toAbsolute", "isAbsolute"],
    "crypto": ["hash", "encrypt", "decrypt", "sign",
               "verify", "generateKey", "generateToken"],
}

# Made-up config options that AI commonly generates
_PHANTOM_CONFIG_PATTERNS = [
    # Python
    (re.compile(r'app\.config\[\s*["\'](\w+)["\']\s*\]'),
     re.compile(r'DEBUG|TESTING|SECRET_KEY|DATABASE_URL|SQLALCHEMY_DATABASE_URI|'
                r'SERVER_NAME|PREFERRED_URL_SCHEME|JSON_SORT_KEYS|MAX_CONTENT_LENGTH|'
                r'SESSION_COOKIE_\w+|PERMANENT_SESSION_LIFETIME|SEND_FILE_MAX_AGE_DEFAULT')),
    # Common hallucinated Flask config keys
    (re.compile(r'app\.config\[\s*["\'](\w+)["\']\s*\]'),
     None),  # Will check against known keys
]

# Fictional HTTP status codes
_VALID_HTTP_CODES = {
    100, 101, 102, 103,
    200, 201, 202, 203, 204, 205, 206, 207, 208, 226,
    300, 301, 302, 303, 304, 305, 307, 308,
    400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413,
    414, 415, 416, 417, 418, 421, 422, 423, 424, 425, 426, 428, 429, 431, 451,
    500, 501, 502, 503, 504, 505, 506, 507, 508, 510, 511,
}

# Non-existent environment variable patterns (commonly hallucinated)
_PHANTOM_ENV_VARS = [
    "APP_HOST", "APP_PORT", "APP_DEBUG",  # These are vague, not standard
    "FLASK_APP_KEY", "DJANGO_APP_KEY",
    "API_BASE_URL", "API_ENDPOINT",  # These are project-specific, not framework-standard
]


class HallucinationAnalyzer:
    """Detects AI hallucination patterns in generated code -- the moat."""

    name = "hallucination"

    @classmethod
    def analyze_file(cls, file_path: Path, content: str) -> list[TrustIssue]:
        """Analyse a file for hallucination patterns."""
        findings: list[TrustIssue] = []

        if file_path.suffix not in _CODE_EXTENSIONS:
            return findings

        lines = content.splitlines()
        rel_path = str(file_path)
        is_python = file_path.suffix == ".py"
        is_js_ts = file_path.suffix in {".ts", ".tsx", ".js", ".jsx"}

        # Collect imports to know which libraries are in use
        imports = cls._extract_imports(file_path, content)

        # Check for phantom API calls
        if is_python:
            findings.extend(cls._check_python_phantom_apis(rel_path, lines, imports))
        if is_js_ts:
            findings.extend(cls._check_js_phantom_apis(rel_path, lines, imports))

        # Check for fictional HTTP status codes
        findings.extend(cls._check_http_codes(rel_path, lines))

        # Check for hallucinated method chaining patterns
        findings.extend(cls._check_phantom_chaining(rel_path, lines, is_python))

        # Check for invented async patterns
        if is_python:
            findings.extend(cls._check_python_async_hallucinations(rel_path, lines))

        # Check for non-existent string methods
        if is_python:
            findings.extend(cls._check_python_string_hallucinations(rel_path, lines))

        # Check for fictional decorator patterns
        if is_python:
            findings.extend(cls._check_phantom_decorators(rel_path, lines))

        return findings

    @classmethod
    def _extract_imports(cls, file_path: Path, content: str) -> dict[str, str]:
        """Extract import mappings: alias -> module."""
        imports: dict[str, str] = {}

        if file_path.suffix == ".py":
            for m in re.finditer(r'import\s+(\w+)(?:\s+as\s+(\w+))?', content):
                mod = m.group(1)
                alias = m.group(2) or mod
                imports[alias] = mod
            for m in re.finditer(r'from\s+(\w+(?:\.\w+)*)\s+import\s+(.+)', content):
                mod = m.group(1)
                items = m.group(2)
                for item in items.split(","):
                    item = item.strip()
                    if " as " in item:
                        name, alias = item.split(" as ")
                        imports[alias.strip()] = f"{mod}.{name.strip()}"
                    else:
                        imports[item] = f"{mod}.{item}"

        elif file_path.suffix in {".ts", ".tsx", ".js", ".jsx"}:
            for m in re.finditer(
                r'import\s+(?:\{[^}]+\}|(\w+))\s+from\s+["\']([^"\']+)["\']', content
            ):
                if m.group(1):
                    imports[m.group(1)] = m.group(2)
            for m in re.finditer(
                r'(?:const|let|var)\s+(\w+)\s*=\s*require\s*\(\s*["\']([^"\']+)["\']\s*\)', content
            ):
                imports[m.group(1)] = m.group(2)

        return imports

    @classmethod
    def _check_python_phantom_apis(
        cls, rel_path: str, lines: list[str], imports: dict[str, str]
    ) -> list[TrustIssue]:
        """Check for phantom (non-existent) Python API calls."""
        findings: list[TrustIssue] = []

        # Build a combined lookup of module -> phantom methods
        all_phantoms: dict[str, set[str]] = {}
        for mod, methods in _PYTHON_STDLIB_PHANTOMS.items():
            all_phantoms[mod] = set(methods)
        for mod, methods in _PYTHON_THIRDPARTY_PHANTOMS.items():
            all_phantoms[mod] = set(methods)

        # Check each line for module.method() calls
        method_call = re.compile(r'(\w+)\.(\w+)\s*\(')

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue

            for m in method_call.finditer(line):
                obj = m.group(1)
                method = m.group(2)

                # Check if the object is an imported module
                mod_name = imports.get(obj, obj)

                # Check against phantom databases
                for phantom_mod, phantom_methods in all_phantoms.items():
                    # Match by module name or by base package
                    if mod_name == phantom_mod or mod_name.startswith(phantom_mod + ".") or obj == phantom_mod.split(".")[-1]:
                        if method in phantom_methods:
                            findings.append(TrustIssue(
                                analyzer=cls.name,
                                category=IssueCategory.HALLUCINATION,
                                severity=Severity.CRITICAL,
                                title=f"Hallucinated API: {obj}.{method}()",
                                description=(
                                    f"'{obj}.{method}()' does not exist in the '{phantom_mod}' library. "
                                    f"This is a common AI hallucination pattern."
                                ),
                                file_path=rel_path,
                                line_start=i,
                                line_end=i,
                                suggestion=f"Check the {phantom_mod} documentation for the correct API.",
                                code_snippet=stripped[:200],
                            ))
                            break

        return findings

    @classmethod
    def _check_js_phantom_apis(
        cls, rel_path: str, lines: list[str], imports: dict[str, str]
    ) -> list[TrustIssue]:
        """Check for phantom JS/TS API calls."""
        findings: list[TrustIssue] = []

        method_call = re.compile(r'(\w+)\.(\w+)\s*\(')

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("//") or stripped.startswith("*"):
                continue

            for m in method_call.finditer(line):
                obj = m.group(1)
                method = m.group(2)

                mod_name = imports.get(obj, obj)

                for phantom_mod, phantom_methods in _JS_PHANTOMS.items():
                    if mod_name == phantom_mod or obj == phantom_mod:
                        if method in phantom_methods:
                            findings.append(TrustIssue(
                                analyzer=cls.name,
                                category=IssueCategory.HALLUCINATION,
                                severity=Severity.CRITICAL,
                                title=f"Hallucinated API: {obj}.{method}()",
                                description=(
                                    f"'{obj}.{method}()' does not exist in the '{phantom_mod}' library. "
                                    f"This is a common AI hallucination."
                                ),
                                file_path=rel_path,
                                line_start=i,
                                line_end=i,
                                suggestion=f"Check the {phantom_mod} documentation for the correct API.",
                                code_snippet=stripped[:200],
                            ))
                            break

        return findings

    @classmethod
    def _check_http_codes(cls, rel_path: str, lines: list[str]) -> list[TrustIssue]:
        """Detect fictional HTTP status codes."""
        findings: list[TrustIssue] = []
        http_code_pattern = re.compile(
            r'(?:status[_\s]*(?:code)?|http[_\s]*(?:status)?|response\.status|status=)\s*[=:]\s*(\d{3})\b'
        )
        # Also catch return status patterns
        return_pattern = re.compile(r'return\s+.*?(\d{3})\b')
        jsonify_pattern = re.compile(r'(?:jsonify|json_response|Response|JSONResponse)\s*\(.*?(\d{3})\b')

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith("//"):
                continue

            for pattern in [http_code_pattern, jsonify_pattern]:
                m = pattern.search(line)
                if m:
                    code = int(m.group(1))
                    if 100 <= code <= 599 and code not in _VALID_HTTP_CODES:
                        findings.append(TrustIssue(
                            analyzer=cls.name,
                            category=IssueCategory.HALLUCINATION,
                            severity=Severity.HIGH,
                            title=f"Fictional HTTP status code: {code}",
                            description=f"HTTP status code {code} does not exist in the HTTP specification.",
                            file_path=rel_path,
                            line_start=i,
                            line_end=i,
                            suggestion="Use a valid HTTP status code. See RFC 9110 for the complete list.",
                            code_snippet=stripped[:200],
                        ))
                    break

        return findings

    @classmethod
    def _check_phantom_chaining(
        cls, rel_path: str, lines: list[str], is_python: bool
    ) -> list[TrustIssue]:
        """Detect suspicious method chaining patterns that AI makes up."""
        findings: list[TrustIssue] = []

        if is_python:
            # Python list/dict/str methods that don't exist
            phantom_methods: dict[str, list[str]] = {
                # List methods that don't exist
                "list": ["add", "delete", "contains", "size", "first", "last",
                         "filter", "map", "reduce", "flat", "flatten", "each",
                         "find", "includes", "push", "shift", "unshift"],
                # Dict methods that don't exist
                "dict": ["add", "delete", "contains", "size", "first", "last",
                         "filter", "map", "has_key", "key_exists"],
                # String methods that don't exist
                "str": ["contains", "includes", "trim", "trimStart", "trimEnd",
                        "padStart", "padEnd", "repeat", "charAt", "indexOf",
                        "lastIndexOf", "match", "search", "slice",
                        "substring", "substr", "toUpperCase", "toLowerCase",
                        "forEach"],
            }

            # Detect .contains() on what looks like a list/string (very common hallucination)
            contains_pattern = re.compile(r'\.contains\s*\(')
            for i, line in enumerate(lines, 1):
                if contains_pattern.search(line):
                    # In Python, use 'in' keyword, not .contains()
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.HALLUCINATION,
                        severity=Severity.HIGH,
                        title="Hallucinated method: .contains()",
                        description="Python does not have a .contains() method. Use 'in' operator instead: "
                                    "'item in collection'.",
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Replace x.contains(y) with y in x.",
                        code_snippet=line.strip()[:200],
                    ))

            # .length instead of len()
            length_pattern = re.compile(r'(?<!\w)(\w+)\.length\b(?!\s*[=(])')
            for i, line in enumerate(lines, 1):
                if length_pattern.search(line):
                    stripped = line.strip()
                    if not stripped.startswith("#"):
                        findings.append(TrustIssue(
                            analyzer=cls.name,
                            category=IssueCategory.HALLUCINATION,
                            severity=Severity.HIGH,
                            title="Hallucinated attribute: .length",
                            description="Python does not have a .length attribute. Use len() function instead.",
                            file_path=rel_path,
                            line_start=i,
                            line_end=i,
                            suggestion="Replace x.length with len(x).",
                            code_snippet=stripped[:200],
                        ))

            # .push() instead of .append() (very common JS->Python hallucination)
            push_pattern = re.compile(r'\w+\.push\s*\(')
            for i, line in enumerate(lines, 1):
                stripped = line.strip()
                if not stripped.startswith("#") and push_pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.HALLUCINATION,
                        severity=Severity.HIGH,
                        title="Hallucinated method: .push()",
                        description="Python lists don't have .push(). Use .append() for single items or .extend() for multiple.",
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Replace .push(x) with .append(x).",
                        code_snippet=stripped[:200],
                    ))

            # .forEach() in Python (JS pattern)
            foreach_pattern = re.compile(r'\w+\.forEach\s*\(')
            for i, line in enumerate(lines, 1):
                stripped = line.strip()
                if not stripped.startswith("#") and foreach_pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.HALLUCINATION,
                        severity=Severity.HIGH,
                        title="Hallucinated method: .forEach()",
                        description="Python does not have .forEach(). Use a for loop: 'for item in collection:'.",
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Replace x.forEach(fn) with: for item in x: fn(item)",
                        code_snippet=stripped[:200],
                    ))

        return findings

    @classmethod
    def _check_python_async_hallucinations(
        cls, rel_path: str, lines: list[str]
    ) -> list[TrustIssue]:
        """Detect hallucinated async patterns in Python."""
        findings: list[TrustIssue] = []

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue

            # await on non-async function (common hallucination)
            # asyncio.sleep used without await
            if re.search(r'(?<!\bawait\s)asyncio\.sleep\s*\(', line):
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.HALLUCINATION,
                    severity=Severity.HIGH,
                    title="Missing await on asyncio.sleep()",
                    description="asyncio.sleep() is a coroutine and must be awaited.",
                    file_path=rel_path,
                    line_start=i,
                    suggestion="Add await: await asyncio.sleep(n)",
                    code_snippet=stripped[:200],
                ))

            # time.sleep in async function (mixing sync/async)
            if re.search(r'time\.sleep\s*\(', line):
                # Check if we're in an async function
                for j in range(max(0, i - 20), i):
                    if j < len(lines) and re.match(r'\s*async\s+def\s+', lines[j]):
                        findings.append(TrustIssue(
                            analyzer=cls.name,
                            category=IssueCategory.HALLUCINATION,
                            severity=Severity.MEDIUM,
                            title="time.sleep() in async function",
                            description="time.sleep() blocks the event loop in async code. Use await asyncio.sleep() instead.",
                            file_path=rel_path,
                            line_start=i,
                            suggestion="Replace time.sleep(n) with await asyncio.sleep(n) in async functions.",
                            code_snippet=stripped[:200],
                        ))
                        break

        return findings

    @classmethod
    def _check_python_string_hallucinations(
        cls, rel_path: str, lines: list[str]
    ) -> list[TrustIssue]:
        """Detect hallucinated string methods in Python."""
        findings: list[TrustIssue] = []

        # .trim() instead of .strip() (JS->Python hallucination)
        trim_pattern = re.compile(r'(?<!\w)\w+\.trim\s*\(')
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped.startswith("#") and trim_pattern.search(line):
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.HALLUCINATION,
                    severity=Severity.HIGH,
                    title="Hallucinated method: .trim()",
                    description="Python strings don't have .trim(). Use .strip(), .lstrip(), or .rstrip().",
                    file_path=rel_path,
                    line_start=i,
                    suggestion="Replace .trim() with .strip().",
                    code_snippet=stripped[:200],
                ))

        # .toString() in Python (Java/JS pattern)
        tostring_pattern = re.compile(r'\w+\.toString\s*\(')
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped.startswith("#") and tostring_pattern.search(line):
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.HALLUCINATION,
                    severity=Severity.HIGH,
                    title="Hallucinated method: .toString()",
                    description="Python does not have .toString(). Use str() built-in function.",
                    file_path=rel_path,
                    line_start=i,
                    suggestion="Replace x.toString() with str(x).",
                    code_snippet=stripped[:200],
                ))

        # .equals() in Python (Java pattern)
        equals_pattern = re.compile(r'\w+\.equals\s*\(')
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped.startswith("#") and equals_pattern.search(line):
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.HALLUCINATION,
                    severity=Severity.HIGH,
                    title="Hallucinated method: .equals()",
                    description="Python does not have .equals(). Use == operator for equality.",
                    file_path=rel_path,
                    line_start=i,
                    suggestion="Replace x.equals(y) with x == y.",
                    code_snippet=stripped[:200],
                ))

        return findings

    @classmethod
    def _check_phantom_decorators(cls, rel_path: str, lines: list[str]) -> list[TrustIssue]:
        """Detect hallucinated Python decorators."""
        findings: list[TrustIssue] = []

        # Common hallucinated decorators
        phantom_decorators = {
            "@override": "Python doesn't have @override (prior to 3.12). Use typing.override or just document it.",
            "@synchronized": "Python doesn't have @synchronized (that's Java). Use threading.Lock.",
            "@throws": "Python doesn't have @throws (that's Java/Kotlin). Document exceptions in docstrings.",
            "@nonnull": "Python doesn't have @nonnull (that's Java). Use type hints: def f(x: str) not None.",
            "@nullable": "Python doesn't have @nullable (that's Java). Use Optional[T] type hint.",
            "@autowired": "Python doesn't have @autowired (that's Spring/Java). Use dependency injection manually.",
            "@inject": "Python doesn't have a built-in @inject. Use a DI framework like dependency_injector.",
            "@component": "Python doesn't have @component (that's Angular/Spring). Import and use classes directly.",
            "@service": "Python doesn't have @service (that's Spring). Define a regular class.",
            "@readonly": "Python doesn't have @readonly. Use @property without a setter.",
            "@private": "Python doesn't have @private. Use underscore prefix: _method_name.",
            "@public": "Python doesn't have @public. All methods are public by default.",
        }

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            for decorator, desc in phantom_decorators.items():
                if stripped == decorator or stripped.startswith(decorator + "("):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.HALLUCINATION,
                        severity=Severity.HIGH,
                        title=f"Hallucinated decorator: {decorator}",
                        description=desc,
                        file_path=rel_path,
                        line_start=i,
                        suggestion="Remove the decorator and use the Python-idiomatic alternative.",
                        code_snippet=stripped[:200],
                    ))

        return findings
