"""Correctness analyzer -- detects common AI-generated code bugs.

Checks:
- Off-by-one patterns (loop bounds, array indexing)
- Null/undefined checks missing
- Type mismatches (comparing string to int)
- Unreachable conditions (always-true/false)
- Return type inconsistencies
- Error handling gaps (try without catch, catch without handling)
"""

from __future__ import annotations

import re
from pathlib import Path

from ..types import TrustIssue, IssueCategory, Severity


_CODE_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx", ".go"}


# Off-by-one patterns
_OFF_BY_ONE_PATTERNS = [
    # range(len(x)) when should be range(len(x) - 1) or vice versa
    (re.compile(r'for\s+\w+\s+in\s+range\s*\(\s*len\s*\(\s*\w+\s*\)\s*\+\s*1\s*\)'),
     "range(len(x) + 1) likely off-by-one -- will index past end of list"),
    # arr[len(arr)] -- always out of bounds
    (re.compile(r'\w+\[\s*len\s*\(\s*\w+\s*\)\s*\]'),
     "Indexing at len(x) is always out of bounds -- last valid index is len(x)-1"),
    # <= in range-based for loop (JS/TS/Go)
    (re.compile(r'for\s*\(.*;\s*\w+\s*<=\s*\w+\.length\s*;'),
     "Loop condition uses <= length instead of < length -- off-by-one error"),
]

# Missing null/undefined checks
_NULL_CHECK_PATTERNS = [
    # Chained property access without optional chaining (JS/TS)
    (re.compile(r'(?<![\?\.])\.\w+\.\w+\.\w+\.\w+'),
     "Deep property access without null checks -- may throw on undefined intermediate"),
    # .get() result used without None check (Python)
    (re.compile(r'(\w+)\.get\([^)]+\)\.\w+'),
     "Calling method on .get() result without None check -- .get() can return None"),
]

# Type mismatch patterns
_TYPE_MISMATCH_PATTERNS = [
    # Comparing string to number without conversion
    (re.compile(r'==\s*["\'][0-9]+["\']'),
     "Comparing with string-encoded number -- may need int() or parseInt() conversion"),
    # parseInt without radix
    (re.compile(r'parseInt\s*\(\s*\w+\s*\)(?!\s*,)'),
     "parseInt() without radix parameter -- always specify radix (e.g., parseInt(x, 10))"),
]

# Unreachable code patterns
_UNREACHABLE_PATTERNS = [
    # if True / if False
    (re.compile(r'if\s+True\s*:'),
     "Condition is always True -- dead code branch or debugging leftover"),
    (re.compile(r'if\s+False\s*:'),
     "Condition is always False -- code block is unreachable"),
    # while True without break (simple heuristic)
    (re.compile(r'if\s+\w+\s*(?:==|!=)\s*\w+\s*and\s+\w+\s*(?:==|!=)\s*\w+.*:\s*$'),
     None),  # placeholder, checked by _check_tautology
]

# Error handling gaps
_ERROR_HANDLING_PATTERNS_PY = [
    # bare except
    (re.compile(r'except\s*:'),
     "Bare except catches all exceptions including SystemExit and KeyboardInterrupt"),
    # except Exception: pass
    (re.compile(r'except\s+\w+.*:\s*\n\s*pass\s*$', re.MULTILINE),
     "Exception caught but silently ignored with pass -- errors will be hidden"),
    # try without except (Python)
    (re.compile(r'try\s*:\s*\n(?:(?!\s*except|\s*finally).)*\n\s*finally', re.MULTILINE),
     None),  # try/finally is valid, skip
]

_ERROR_HANDLING_PATTERNS_JS = [
    # empty catch block
    (re.compile(r'catch\s*\([^)]*\)\s*\{\s*\}'),
     "Empty catch block -- errors are silently swallowed"),
    # catch with only console.log
    (re.compile(r'catch\s*\([^)]*\)\s*\{\s*console\.log'),
     "Catch block only logs the error but does not handle or re-throw it"),
]

# Return type inconsistency
_RETURN_PATTERNS = [
    # Function with both return value and bare return
    (re.compile(r'def\s+\w+[^:]*:.*?\n(?:.*\n)*?\s+return\s+\S+.*\n(?:.*\n)*?\s+return\s*$', re.MULTILINE),
     "Function has both value-returning and bare return statements -- inconsistent return type"),
]


class CorrectnessAnalyzer:
    """Detects correctness issues common in AI-generated code."""

    name = "correctness"

    @classmethod
    def analyze_file(cls, file_path: Path, content: str) -> list[TrustIssue]:
        """Analyse a single file for correctness issues."""
        findings: list[TrustIssue] = []

        if file_path.suffix not in _CODE_EXTENSIONS:
            return findings

        lines = content.splitlines()
        rel_path = str(file_path)
        is_python = file_path.suffix == ".py"
        is_js_ts = file_path.suffix in {".ts", ".tsx", ".js", ".jsx"}

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # Skip comments
            if stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("*"):
                continue

            # Off-by-one patterns
            for pattern, desc in _OFF_BY_ONE_PATTERNS:
                if pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.CORRECTNESS,
                        severity=Severity.HIGH,
                        title="Potential off-by-one error",
                        description=desc,
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Check array/list bounds carefully. Last valid index is length-1.",
                        code_snippet=stripped[:200],
                    ))
                    break

            # Null check patterns
            for pattern, desc in _NULL_CHECK_PATTERNS:
                if pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.CORRECTNESS,
                        severity=Severity.MEDIUM,
                        title="Missing null/undefined check",
                        description=desc,
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Add null checks or use optional chaining (?.) before accessing nested properties.",
                        code_snippet=stripped[:200],
                    ))
                    break

            # Type mismatch patterns
            for pattern, desc in _TYPE_MISMATCH_PATTERNS:
                if pattern.search(line):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.CORRECTNESS,
                        severity=Severity.MEDIUM,
                        title="Potential type mismatch",
                        description=desc,
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Ensure types match before comparison. Use explicit conversion.",
                        code_snippet=stripped[:200],
                    ))
                    break

            # Unreachable code (if True / if False)
            if re.search(r'if\s+True\s*:', stripped):
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.CORRECTNESS,
                    severity=Severity.LOW,
                    title="Always-true condition",
                    description="Condition is always True -- dead code branch or debugging leftover",
                    file_path=rel_path,
                    line_start=i,
                    line_end=i,
                    suggestion="Remove the always-true condition or replace with the actual logic.",
                    code_snippet=stripped[:200],
                ))
            elif re.search(r'if\s+False\s*:', stripped):
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.CORRECTNESS,
                    severity=Severity.MEDIUM,
                    title="Unreachable code block",
                    description="Condition is always False -- code block is unreachable",
                    file_path=rel_path,
                    line_start=i,
                    line_end=i,
                    suggestion="Remove the dead code block.",
                    code_snippet=stripped[:200],
                ))

            # Error handling -- Python
            if is_python:
                if re.match(r'except\s*:', stripped):
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.CORRECTNESS,
                        severity=Severity.HIGH,
                        title="Bare except clause",
                        description="Bare except catches all exceptions including SystemExit and KeyboardInterrupt",
                        file_path=rel_path,
                        line_start=i,
                        line_end=i,
                        suggestion="Use 'except Exception:' to avoid catching system-level exceptions.",
                        code_snippet=stripped[:200],
                    ))

            # Error handling -- JS/TS
            if is_js_ts:
                for pattern, desc in _ERROR_HANDLING_PATTERNS_JS:
                    if pattern.search(line):
                        findings.append(TrustIssue(
                            analyzer=cls.name,
                            category=IssueCategory.CORRECTNESS,
                            severity=Severity.MEDIUM,
                            title="Error handling gap",
                            description=desc,
                            file_path=rel_path,
                            line_start=i,
                            line_end=i,
                            suggestion="Handle errors properly: log, re-throw, or return an error state.",
                            code_snippet=stripped[:200],
                        ))
                        break

        # Multi-line checks: except ... pass pattern
        if is_python:
            findings.extend(cls._check_swallowed_exceptions(rel_path, content, lines))

        # Return type consistency
        if is_python:
            findings.extend(cls._check_return_consistency(rel_path, content, lines))

        return findings

    @classmethod
    def _check_swallowed_exceptions(
        cls, rel_path: str, content: str, lines: list[str]
    ) -> list[TrustIssue]:
        """Detect except blocks that silently swallow errors with pass."""
        findings: list[TrustIssue] = []
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if re.match(r'except\s+\w+', stripped) and i < len(lines):
                next_line = lines[i].strip() if i < len(lines) else ""
                if next_line == "pass":
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.CORRECTNESS,
                        severity=Severity.MEDIUM,
                        title="Swallowed exception",
                        description="Exception caught but silently ignored with pass -- errors will be hidden",
                        file_path=rel_path,
                        line_start=i,
                        line_end=i + 1,
                        suggestion="At minimum, log the exception. Consider re-raising or returning an error.",
                        code_snippet=stripped[:200],
                    ))
        return findings

    @classmethod
    def _check_return_consistency(
        cls, rel_path: str, content: str, lines: list[str]
    ) -> list[TrustIssue]:
        """Detect functions with inconsistent return types (value + bare return)."""
        findings: list[TrustIssue] = []
        func_pattern = re.compile(r'^(\s*)def\s+(\w+)')
        in_func = False
        func_name = ""
        func_indent = ""
        func_line = 0
        has_value_return = False
        has_bare_return = False

        for i, line in enumerate(lines, 1):
            m = func_pattern.match(line)
            if m:
                # Evaluate previous function
                if in_func and has_value_return and has_bare_return:
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.CORRECTNESS,
                        severity=Severity.MEDIUM,
                        title="Inconsistent return type",
                        description=f"Function '{func_name}' has both value-returning and bare return statements",
                        file_path=rel_path,
                        line_start=func_line,
                        line_end=i - 1,
                        suggestion="Ensure all return paths return the same type or use Optional.",
                    ))
                in_func = True
                func_name = m.group(2)
                func_indent = m.group(1)
                func_line = i
                has_value_return = False
                has_bare_return = False
                continue

            if in_func:
                stripped = line.strip()
                if stripped.startswith("return ") and stripped != "return":
                    has_value_return = True
                elif stripped == "return":
                    has_bare_return = True

        # Check last function
        if in_func and has_value_return and has_bare_return:
            findings.append(TrustIssue(
                analyzer=cls.name,
                category=IssueCategory.CORRECTNESS,
                severity=Severity.MEDIUM,
                title="Inconsistent return type",
                description=f"Function '{func_name}' has both value-returning and bare return statements",
                file_path=rel_path,
                line_start=func_line,
                line_end=len(lines),
                suggestion="Ensure all return paths return the same type or use Optional.",
            ))

        return findings
