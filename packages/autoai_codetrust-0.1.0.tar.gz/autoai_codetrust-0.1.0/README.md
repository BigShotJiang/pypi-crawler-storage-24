# AICodeTrustScore

Continuous trust scoring for AI-generated code. Analyzes code from Cursor, Copilot, Claude, and other AI tools, assigning a 0-100 trust score with hallucination detection.

## Install

```bash
pip install autoai-aicodetrustcore
```

## Usage

```bash
# Score a file
aicodetrustcore score path/to/file.py

# Score a git diff
aicodetrustcore diff

# Full report for a directory
aicodetrustcore report path/to/project/

# Check for AI hallucinations
aicodetrustcore hallucination-check path/to/file.py

# Start MCP server
aicodetrustcore serve
```

## License

Apache-2.0
