# Quant Tape

**The Last Line Before The Market.**

The security SDK for algorithmic trading.

- Zero latency — runs locally inside your script
- Zero exposure — your keys, strategies, and trades stay private
- Zero compromise — no performance cost, no security trade-offs

## What's Inside

- **Code Scanner** — 36 built-in rules detecting hardcoded broker keys, credentials, and trading logic vulnerabilities
- Supports Alpaca, Binance, Coinbase, Interactive Brokers, Kraken, TD Ameritrade, Tradier, Polygon.io
- CLI: `quanttape scan your_bot.py`
- Output formats: Console, JSON, SARIF

## Coming Soon

- Guard SDK — real-time trade validation, kill-switch, drawdown limits
- Zero-Knowledge Vault — AES-256 encrypted key storage

## Quick Start

```bash
pip install quanttape
quanttape scan my_bot.py
quanttape scan ./my_project/ --output json
quanttape scan ./my_project/ --git-history
```

Join the waitlist: [quanttape.com](https://quanttape.com)
