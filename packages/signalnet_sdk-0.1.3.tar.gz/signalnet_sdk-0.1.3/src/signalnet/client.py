"""Main SignalNet client."""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Optional

import pandas as pd
import requests

from signalnet.exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SignalNetError,
    ValidationError,
)
from signalnet.models import (
    ApiKey,
    Round,
    RoundResult,
    ScoreEntry,
    SubmissionResponse,
    Tournament,
    User,
)
from signalnet.utils import DataCache, csv_bytes_to_dataframe

_DEFAULT_BASE_URL = "https://signalnet-api.vercel.app/api"


class SignalNet:
    """Client for the SignalNet API.

    Args:
        api_key: Your SignalNet API key (``sn_...``). Falls back to the
            ``SIGNALNET_API_KEY`` environment variable if not provided.
        base_url: API base URL. Falls back to ``SIGNALNET_API_URL`` env var,
            then ``https://signalnet-api.vercel.app/api``.
        timeout: Request timeout in seconds. Defaults to 30.
        cache_dir: Directory for local parquet cache. Falls back to
            ``SIGNALNET_CACHE_DIR`` env var, then ``~/.signalnet/data``.

    Example::

        from signalnet import SignalNet

        sn = SignalNet(api_key="sn_...")
        current = sn.get_current_round()
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: int = 30,
        cache_dir: str | None = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("SIGNALNET_API_KEY", "")
        self.base_url = (base_url or os.environ.get("SIGNALNET_API_URL", _DEFAULT_BASE_URL)).rstrip("/")
        self.timeout = timeout
        self._cache = DataCache(cache_dir)
        self._session = requests.Session()
        self._session.headers.update(
            {
                "x-api-key": self.api_key,
                "Accept": "application/json",
            }
        )

    # ── helpers ──────────────────────────────────────────────────────────

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _handle_error(self, resp: requests.Response) -> None:
        """Raise a typed exception for non-2xx responses."""
        if resp.ok:
            return

        try:
            body = resp.json()
        except Exception:
            body = {"detail": resp.text}

        msg = body.get("error") or body.get("message") or body.get("detail") or resp.text
        code = resp.status_code
        kw = {"status_code": code, "response_body": body}

        if code == 401 or code == 403:
            raise AuthenticationError(f"Authentication failed: {msg}", **kw)
        if code == 404:
            raise NotFoundError(f"Not found: {msg}", **kw)
        if code in (400, 422):
            raise ValidationError(f"Validation error: {msg}", **kw)
        if code == 429:
            raise RateLimitError(f"Rate limit exceeded: {msg}", **kw)
        if 500 <= code < 600:
            raise ServerError(f"Server error: {msg}", **kw)
        raise SignalNetError(f"API error ({code}): {msg}", **kw)

    def _get(self, path: str, params: dict[str, Any] | None = None, **kwargs: Any) -> requests.Response:
        resp = self._session.get(self._url(path), params=params, timeout=self.timeout, **kwargs)
        self._handle_error(resp)
        return resp

    def _post(self, path: str, json: dict[str, Any] | None = None, **kwargs: Any) -> requests.Response:
        resp = self._session.post(self._url(path), json=json, timeout=self.timeout, **kwargs)
        self._handle_error(resp)
        return resp

    # ── Rounds ───────────────────────────────────────────────────────────

    def get_current_round(self) -> Round:
        """Get the current active round.

        Returns:
            The current :class:`Round`.
        """
        data = self._get("/tournament/current").json()
        return Round.model_validate(data["round"])

    def get_rounds(self, limit: int | None = None, offset: int | None = None, status: str | None = None) -> list[Round]:
        """List tournament rounds.

        Args:
            limit: Maximum number of rounds to return.
            offset: Pagination offset.
            status: Filter by round status (e.g. ``"active"``).

        Returns:
            A list of :class:`Round` objects.
        """
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if status is not None:
            params["status"] = status

        data = self._get("/tournament/rounds", params=params or None).json()
        return [Round.model_validate(r) for r in data["rounds"]]

    def get_round(self, round_id: int) -> Round:
        """Get details for a specific round.

        Args:
            round_id: The round ID.

        Returns:
            The :class:`Round`.
        """
        data = self._get(f"/tournament/rounds/{round_id}").json()
        return Round.model_validate(data["round"])

    def get_round_results(self, round_id: int) -> list[RoundResult]:
        """Get results (leaderboard) for a resolved round.

        Args:
            round_id: The round ID.

        Returns:
            A list of :class:`RoundResult` entries.
        """
        data = self._get(f"/tournament/rounds/{round_id}/results").json()
        return [RoundResult.model_validate(r) for r in data["results"]]

    # ── Tournaments ──────────────────────────────────────────────────────

    def get_tournaments(self) -> list[Tournament]:
        """List all tournaments.

        Returns:
            A list of :class:`Tournament` objects.
        """
        data = self._get("/tournament/tournaments").json()
        return [Tournament.model_validate(t) for t in data["tournaments"]]

    def get_tournament(self, slug_or_id: str | int) -> Tournament:
        """Get a single tournament by slug or ID.

        This fetches all tournaments and filters locally. For direct ID
        access, use :meth:`get_tournaments` and filter yourself.

        Args:
            slug_or_id: Tournament slug (str) or ID (int).

        Returns:
            The matching :class:`Tournament`.

        Raises:
            NotFoundError: If no tournament matches.
        """
        tournaments = self.get_tournaments()
        for t in tournaments:
            if isinstance(slug_or_id, int) and t.id == slug_or_id:
                return t
            if isinstance(slug_or_id, str) and t.slug == slug_or_id:
                return t
        raise NotFoundError(f"Tournament not found: {slug_or_id}", status_code=404)

    # ── Data Downloads ───────────────────────────────────────────────────

    def download_features(self, round_id: int, *, force: bool = False) -> pd.DataFrame:
        """Download feature data for a round as a DataFrame.

        Results are cached locally as Parquet files. Subsequent calls return
        the cached version instantly.

        Args:
            round_id: The round ID.
            force: If ``True``, bypass the cache and re-download.

        Returns:
            A :class:`pandas.DataFrame` with the feature data.
        """
        if not force:
            cached = self._cache.read_round_features(round_id)
            if cached is not None:
                return cached

        resp = self._get(f"/tournament/rounds/{round_id}/features", headers={"Accept": "text/csv"})
        df = csv_bytes_to_dataframe(resp.content)
        self._cache.write_round_features(round_id, df, len(resp.content))
        return df

    def download_training_data(self, data_type: str, *, force: bool = False) -> pd.DataFrame:
        """Download training data (features or targets) as a DataFrame.

        Results are cached locally as Parquet files. Subsequent calls return
        the cached version instantly.

        Args:
            data_type: Either ``"features"`` or ``"targets"``.
            force: If ``True``, bypass the cache and re-download.

        Returns:
            A :class:`pandas.DataFrame` with the training data.

        Raises:
            ValueError: If *data_type* is not ``"features"`` or ``"targets"``.
        """
        if data_type not in ("features", "targets"):
            raise ValueError(f"data_type must be 'features' or 'targets', got '{data_type}'")

        if not force:
            cached = self._cache.read_training(data_type)
            if cached is not None:
                return cached

        resp = self._get("/tournament/training-data", params={"type": data_type}, headers={"Accept": "text/csv"})
        df = csv_bytes_to_dataframe(resp.content)
        self._cache.write_training(data_type, df, len(resp.content))
        return df

    # ── Cache Management ─────────────────────────────────────────────────

    def clear_cache(self) -> None:
        """Delete all locally cached data files.

        Example::

            sn.clear_cache()
        """
        from signalnet.utils import _human_size, _log

        freed = self._cache.clear()
        _log(f"Cache cleared ({_human_size(freed)} freed)")

    def cache_info(self) -> dict:
        """Return information about the local data cache.

        Returns:
            A dict with ``cache_dir``, ``total_size``, ``total_size_human``,
            ``round_features`` (list of cached round IDs), and
            ``training_files`` (list of cached data types).

        Example::

            info = sn.cache_info()
            print(info)
            # {'cache_dir': '/home/user/.signalnet/data',
            #  'total_size': 2148576,
            #  'total_size_human': '2.0 MB',
            #  'round_features': [1, 2, 3],
            #  'training_files': ['features', 'targets']}
        """
        return self._cache.info()

    # ── Submissions ──────────────────────────────────────────────────────

    def submit(
        self,
        round_id: str,
        predictions: pd.DataFrame,
        stake: int = 0,
    ) -> SubmissionResponse:
        """Submit predictions for a round.

        Args:
            round_id: The round UUID to submit for.
            predictions: A DataFrame with columns ``stock_id`` and ``signal``.
            stake: Amount to stake on this submission (integer).

        Returns:
            A :class:`SubmissionResponse` with submission details.

        Raises:
            ValueError: If the DataFrame is missing required columns.
        """
        required_cols = {"stock_id", "signal"}
        missing = required_cols - set(predictions.columns)
        if missing:
            raise ValueError(f"predictions DataFrame missing columns: {missing}")

        preds = [
            {"stock_id": row["stock_id"], "signal": float(row["signal"])}
            for _, row in predictions.iterrows()
        ]

        # Compute a deterministic hash of the predictions
        signal_hash = hashlib.sha256(
            json.dumps(preds, sort_keys=True).encode()
        ).hexdigest()

        payload = {
            "round_id": str(round_id),
            "signal_hash": signal_hash,
            "stake_amount": str(int(stake)),
            "signal_data": preds,
        }
        data = self._post("/signals/submit", json=payload).json()
        return SubmissionResponse.model_validate(data)

    def get_my_submission(self, round_id: int) -> dict:
        """Get your submission for a specific round.

        Args:
            round_id: The round ID.

        Returns:
            The raw submission data as a dict.
        """
        data = self._get(f"/tournament/rounds/{round_id}/my-submission").json()
        return data

    # ── User ─────────────────────────────────────────────────────────────

    def get_me(self) -> User:
        """Get the authenticated user's profile.

        Returns:
            A :class:`User` object.
        """
        data = self._get("/users/me").json()
        return User.model_validate(data)

    def get_my_scores(self) -> list[ScoreEntry]:
        """Get the authenticated user's score history.

        Returns:
            A list of :class:`ScoreEntry` objects.
        """
        data = self._get("/users/me/scores").json()
        scores = data if isinstance(data, list) else data.get("scores", [])
        return [ScoreEntry.model_validate(s) for s in scores]

    def create_api_key(self, name: str | None = None) -> ApiKey:
        """Create a new API key.

        Args:
            name: Optional display name for the key.

        Returns:
            An :class:`ApiKey` with the newly created key.
        """
        payload: dict[str, Any] = {}
        if name:
            payload["name"] = name
        data = self._post("/users/me/api-keys", json=payload).json()
        return ApiKey.model_validate(data)

    def list_api_keys(self) -> list[ApiKey]:
        """List all API keys for the authenticated user.

        Returns:
            A list of :class:`ApiKey` objects.
        """
        data = self._get("/users/me/api-keys").json()
        keys = data if isinstance(data, list) else data.get("keys", data.get("api_keys", []))
        return [ApiKey.model_validate(k) for k in keys]
