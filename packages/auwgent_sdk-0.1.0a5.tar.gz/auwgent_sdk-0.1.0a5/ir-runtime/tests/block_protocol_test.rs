/// Integration tests for block protocol
use ir_runtime::intent_parser::block_orchestrator::BlockOrchestrator;
use serde_json::json;
use std::sync::{Arc, Mutex};

#[test]
fn test_chat_to_response_text() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("response_text");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write("<response_text>Hello world</response_text>");
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].0, "response_text");
    assert_eq!(results[0].1["text"], "Hello world");
}

#[test]
fn test_tool_to_tool_call() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("tool_call");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write(
        "[tool_call: fetch_session]\nsession_id: \"sess_123\"\n[/tool]\n[tool_call: get_user]\nuser_id: \"usr_456\"\n[/tool]",
    );
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 2);
    assert_eq!(results[0].0, "tool_call");
    assert_eq!(results[0].1["type"], "fetch_session");
    assert_eq!(results[0].1["args"]["session_id"], "sess_123");
    assert_eq!(results[1].0, "tool_call");
    assert_eq!(results[1].1["type"], "get_user");
}

#[test]
fn test_out_to_response_schema() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("response_schema");
    orch.register_output_shape(
        &json!({
            "session_id": { "type": "string", "optional": false },
            "user": {
                "type": {
                    "type": "object",
                    "properties": {
                        "id": { "type": "string", "optional": false },
                        "name": { "type": "string", "optional": false }
                    }
                },
                "optional": false
            }
        }),
        None,
    );

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write(
        "[schema: Output]\nsession_id: \"sess_123\"\nuser_id: \"usr_456\"\nuser_name: \"Nana\"\n[/schema]",
    );
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].0, "response_schema");
    assert_eq!(results[0].1["type"], "Output");
    assert_eq!(results[0].1["response"]["session_id"], "sess_123");
    assert_eq!(results[0].1["response"]["user"]["name"], "Nana");
}

#[test]
fn test_workflow_to_workflow_call() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("workflow_call");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write(
        "[workflow_call: process_data]\ninput: \"test\"\nconfig: { timeout: 30 }\n[/workflow]",
    );
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].0, "workflow_call");
    assert_eq!(results[0].1["type"], "process_data");
    assert_eq!(results[0].1["args"]["input"], "test");
}

#[test]
fn test_helper_to_helper_call() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("helper_call");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write("[helper_call: StoryTeller]\ncity: \"Accra\"\ndays: 3\n[/helper]");
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].0, "helper_call");
    assert_eq!(results[0].1["type"], "StoryTeller");
    assert_eq!(results[0].1["args"]["city"], "Accra");
}

#[test]
fn test_multi_block_response() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("response_text");
    orch.register_intent("tool_call");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    let input = r#"
<response_text>
Let me fetch that data.
</response_text>

[tool_call: fetch_session]
session_id: "sess_123"
[/tool]
[tool_call: get_user]
user_id: "usr_456"
[/tool]

<response_text>
Here's the result.
</response_text>
"#;

    orch.write(input);
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 4); // 2 chat + 2 tools
    assert_eq!(results[0].0, "response_text");
    assert_eq!(results[1].0, "tool_call");
    assert_eq!(results[2].0, "tool_call");
    assert_eq!(results[3].0, "response_text");
}

#[test]
fn test_implicit_chat() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("response_text");
    orch.register_intent("tool_call");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    let input = r#"
Let me help you.

[tool_call: fetch]
id: "123"
[/tool]

Here's the result.
"#;

    orch.write(input);
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 3); // implicit chat + tool + implicit chat
    assert_eq!(results[0].0, "response_text");
    assert!(
        results[0].1["text"]
            .as_str()
            .unwrap()
            .contains("Let me help")
    );
    assert_eq!(results[1].0, "tool_call");
    assert_eq!(results[2].0, "response_text");
    assert!(
        results[2].1["text"]
            .as_str()
            .unwrap()
            .contains("Here's the result")
    );
}

#[test]
fn test_auto_close() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("response_text");
    orch.register_intent("tool_call");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write("<response_text>\nHello\n[tool_call: fetch]\nid: \"123\"\n[/tool]");
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 2);
    assert_eq!(results[0].0, "response_text");
    assert_eq!(results[1].0, "tool_call");
}

#[test]
fn test_last_wins_for_terminal() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("response_text");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write(
        "<response_text>First attempt</response_text><response_text>Second attempt</response_text><response_text>Final answer</response_text>",
    );
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 3); // All chat blocks emitted
    assert_eq!(results[0].1["text"], "First attempt");
    assert_eq!(results[1].1["text"], "Second attempt");
    assert_eq!(results[2].1["text"], "Final answer");
}

#[test]
fn test_custom_intent() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("ask_user");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write(
        "[custom: ask_user]\nquestion: \"Are you sure?\"\noptions: [\"yes\", \"no\"]\n[/custom]",
    );
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].0, "ask_user");
    assert_eq!(results[0].1["question"], "Are you sure?");
}

#[test]
fn test_last_wins_for_response_schema() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("response_schema");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write(
        "[schema: Result]\nstatus: \"first\"\n[/schema]\n[schema: Result]\nstatus: \"second\"\n[/schema]\n[schema: Result]\nstatus: \"final\"\n[/schema]",
    );
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 1); // Only last one
    assert_eq!(results[0].0, "response_schema");
    assert_eq!(results[0].1["response"]["status"], "final");
}

#[test]
fn test_tool_call_unflattens_nested_args_from_aliases() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("tool_call");
    orch.register_tool_shape(
        "create_user",
        &json!({
            "profile": {
                "type": {
                    "type": "object",
                    "properties": {
                        "name": { "type": "string", "optional": false },
                        "contact": {
                            "type": {
                                "type": "object",
                                "properties": {
                                    "email": { "type": "string", "optional": false }
                                }
                            },
                            "optional": false
                        }
                    }
                },
                "optional": false
            }
        }),
        None,
    );

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write(
        "[tool_call: create_user]\nprofile_name: \"Ada\"\nprofile_contact_email: \"ada@test.com\"\n[/tool]",
    );
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].1["args"]["profile"]["name"], "Ada");
    assert_eq!(
        results[0].1["args"]["profile"]["contact"]["email"],
        "ada@test.com"
    );
}

#[test]
fn test_custom_intent_unflattens_nested_fields_from_aliases() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("Thoughts");
    orch.register_custom_intent_shape(
        "Thoughts",
        &json!({
            "trace": {
                "type": {
                    "type": "object",
                    "properties": {
                        "explain": { "type": "string", "optional": false }
                    }
                },
                "optional": false
            }
        }),
        None,
    );

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write("[custom: Thoughts]\ntrace_explain: \"Need lookup first\"\n[/custom]");
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 1);
    assert_eq!(results[0].0, "Thoughts");
    assert_eq!(results[0].1["trace"]["explain"], "Need lookup first");
}

#[test]
fn test_malformed_close_tag_recovers_and_keeps_next_block() {
    let mut orch = BlockOrchestrator::new();
    orch.register_intent("tool_call");
    orch.register_intent("response_text");

    let emitted = Arc::new(Mutex::new(Vec::new()));
    let emitted_clone = Arc::clone(&emitted);

    orch.on_intent_ready(Arc::new(move |name, value| {
        emitted_clone.lock().unwrap().push((name, value));
    }));

    orch.write("[tool_call: fetch]\nid: \"123\"\n[/workflow]\n<response_text>Done</response_text>");
    orch.end();

    let results = emitted.lock().unwrap();
    assert_eq!(results.len(), 2);
    assert_eq!(results[0].0, "tool_call");
    assert_eq!(results[0].1["args"]["id"], "123");
    assert_eq!(results[1].0, "response_text");
    assert_eq!(results[1].1["text"], "Done");
}
