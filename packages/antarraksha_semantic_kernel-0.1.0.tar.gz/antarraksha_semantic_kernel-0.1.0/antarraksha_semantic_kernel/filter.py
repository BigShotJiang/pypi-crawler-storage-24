"""Semantic Kernel filters for Antarraksha enforcement."""

from typing import Any, Dict, Optional

from .client import AntarakshaClient


class AntarakshaPromptFilter:
    """Antarraksha enforcement filter for Semantic Kernel prompt rendering.

    Usage:
        from antarraksha_semantic_kernel import AntarakshaPromptFilter

        prompt_filter = AntarakshaPromptFilter(
            base_url="https://antarraksha.ai",
            agent_id="my-sk-agent",
            passport_id="ANTK-PASS-xxx",
        )

        # Add to Semantic Kernel
        kernel.add_filter("prompt_rendering", prompt_filter.on_prompt_render)
    """

    def __init__(
        self,
        base_url: str = "https://antarraksha.ai",
        agent_id: Optional[str] = None,
        passport_id: Optional[str] = None,
        sdk_key: Optional[str] = None,
        fail_closed: bool = True,
    ):
        self.client = AntarakshaClient(
            base_url=base_url,
            agent_id=agent_id,
            passport_id=passport_id,
            sdk_key=sdk_key,
            framework="semantic-kernel",
            fail_closed=fail_closed,
        )
        if not sdk_key and agent_id and passport_id:
            try:
                self.client.register(capabilities=["semantic_kernel_agent"])
            except Exception:
                pass

    def on_prompt_render(self, context: Any) -> Any:
        result = self.client.intercept(
            call_type="prompt_render",
            call_name="semantic_kernel_prompt",
            parameters={"function_name": getattr(context, "function_name", "unknown")},
        )
        if result.get("decision") == "DENY":
            raise PermissionError(
                f"Antarraksha denied prompt rendering: {result.get('reason', 'Policy violation')}"
            )
        return context


class AntarakshaFunctionFilter:
    """Antarraksha enforcement filter for Semantic Kernel function invocations."""

    def __init__(
        self,
        base_url: str = "https://antarraksha.ai",
        agent_id: Optional[str] = None,
        passport_id: Optional[str] = None,
        sdk_key: Optional[str] = None,
        fail_closed: bool = True,
    ):
        self.client = AntarakshaClient(
            base_url=base_url,
            agent_id=agent_id,
            passport_id=passport_id,
            sdk_key=sdk_key,
            framework="semantic-kernel",
            fail_closed=fail_closed,
        )
        if not sdk_key and agent_id and passport_id:
            try:
                self.client.register(capabilities=["semantic_kernel_agent"])
            except Exception:
                pass

    def on_function_invocation(self, context: Any) -> Any:
        function_name = getattr(context, "function", {})
        plugin_name = getattr(function_name, "plugin_name", "unknown") if hasattr(function_name, "plugin_name") else "unknown"
        fn_name = getattr(function_name, "name", "unknown") if hasattr(function_name, "name") else str(function_name)

        result = self.client.intercept(
            call_type="function_call",
            call_name=f"{plugin_name}.{fn_name}",
            parameters={"plugin": plugin_name, "function": fn_name},
        )
        if result.get("decision") == "DENY":
            raise PermissionError(
                f"Antarraksha denied function '{plugin_name}.{fn_name}': {result.get('reason', 'Policy violation')}"
            )
        return context
