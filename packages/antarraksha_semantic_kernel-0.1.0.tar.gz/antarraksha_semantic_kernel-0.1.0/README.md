# antarraksha-semantic-kernel

Antarraksha AI Agent Enforcement SDK for Semantic Kernel.

## Installation

```bash
pip install antarraksha-semantic-kernel
```

## Quick Start

```python
from antarraksha_semantic_kernel import AntarakshaClient

client = AntarakshaClient(
    base_url="https://antarraksha.ai",
    agent_id="my-agent",
    passport_id="ANTK-PASS-xxx",
)
client.register()
```
