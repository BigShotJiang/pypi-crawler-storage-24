import logging
import os

from nicegui import ui

import db
import auth as auth_module
import layout
import mail


@ui.page("/dept/members")
async def dept_members_page():
    await auth_module.sync_session()
    if not auth_module.is_authenticated():
        ui.navigate.to("/login")
        return

    user = auth_module.current_user()
    user_id = user["id"]

    # All departments the user belongs to, with their role
    all_depts = await db.fetch(
        """
        SELECT d.id, d.name, i.name AS organisation_name, ud.role
        FROM user_department ud
        JOIN department d ON d.id = ud.department_id
        JOIN organisation  i ON i.id = d.organisation_id
        WHERE ud.user_id = $1::uuid
        ORDER BY i.name, d.name
        """,
        user_id,
    )

    # All users available to assign (only needed for admin depts)
    all_users = await db.fetch(
        "SELECT id, name, email FROM user_account ORDER BY name",
    )

    with layout.page("My Departments"):
        if not all_depts:
            ui.label("You are not a member of any department.").classes(
                "text-gray-500 italic"
            )
            return

        for dept in all_depts:
            dept_id = str(dept["id"])
            dept_name = f"{dept['organisation_name']} / {dept['name']}"
            is_admin = dept["role"] == "admin"

            icon = "admin_panel_settings" if is_admin else "folder_open"
            with (
                ui.expansion(dept_name, icon=icon)
                .classes("w-full border rounded-lg")
                .props("default-opened")
            ):
                members_col = ui.column().classes("w-full gap-1 px-2")

                async def refresh(did=dept_id, col=members_col):
                    col.clear()
                    members = await db.fetch(
                        """
                        SELECT ud.user_id, ua.name, ua.email, ud.role
                        FROM user_department ud
                        JOIN user_account ua ON ua.id = ud.user_id
                        WHERE ud.department_id = $1::uuid
                        ORDER BY ua.name
                        """,
                        did,
                    )
                    with col:
                        if not members:
                            ui.label("No members yet.").classes(
                                "text-sm text-gray-400 italic"
                            )
                        for m in members:
                            with ui.row().classes(
                                "w-full items-center justify-between py-1"
                            ):
                                ui.label(f"{m['name']} ({m['email']})").classes(
                                    "text-sm"
                                )
                                ui.badge(m["role"]).props("color=primary")
                                if is_admin:
                                    ui.button(icon="close").props(
                                        "flat round dense color=negative"
                                    ).on(
                                        "click",
                                        handler=lambda _, uid=str(m["user_id"]), d=did, c=col: (
                                            _revoke(uid, d, c)
                                        ),
                                    )

                await refresh(dept_id, members_col)

                if is_admin:
                    ui.separator().classes("my-2")
                    user_options = {
                        str(u["id"]): f"{u['name']} ({u['email']})" for u in all_users
                    }
                    with ui.row().classes("w-full items-end gap-2 px-2 pb-2"):
                        user_select = ui.select(user_options, label="User").classes(
                            "flex-1"
                        )
                        role_select = ui.select(
                            {"member": "Member", "admin": "Admin"},
                            label="Role",
                            value="member",
                        ).classes("w-32")
                        error = ui.label("").classes("text-red-500 text-sm")

                        async def add(
                            did=dept_id,
                            col=members_col,
                            us=user_select,
                            rs=role_select,
                            err=error,
                        ):
                            err.text = ""
                            if not us.value:
                                err.text = "Select a user."
                                return
                            try:
                                # Organisational tracking
                                await db.execute(
                                    """
                                    INSERT INTO user_department (user_id, department_id, role)
                                    VALUES ($1::uuid, $2::uuid, $3)
                                    ON CONFLICT (user_id, department_id) DO UPDATE SET role = EXCLUDED.role
                                    """,
                                    us.value,
                                    did,
                                    rs.value,
                                )
                                # Full-scope access management entry (entity=NULL, time=NULL = no restrictions)
                                dept_info = await db.fetchrow(
                                    "SELECT d.organisation_id FROM department d WHERE d.id = $1::uuid",
                                    did,
                                )
                                management_id = await db.fetchval(
                                    """
                                    INSERT INTO management (organisation_id, department_id)
                                    VALUES ($1::uuid, $2::uuid)
                                    ON CONFLICT (organisation_id, department_id, entity, time_start, time_end)
                                        DO UPDATE SET organisation_id = EXCLUDED.organisation_id
                                    RETURNING id
                                    """,
                                    str(dept_info["organisation_id"]),
                                    did,
                                )
                                await db.execute(
                                    """
                                    INSERT INTO user_management (user_id, management_id, role)
                                    VALUES ($1::uuid, $2::uuid, $3)
                                    ON CONFLICT (user_id, management_id) DO NOTHING
                                    """,
                                    us.value,
                                    str(management_id),
                                    rs.value,
                                )
                                us.value = None
                                await refresh(did, col)
                            except Exception as e:
                                err.text = f"Error: {e}"

                        ui.button("Add", icon="add", on_click=add).props(
                            "color=primary"
                        )
                        ui.button(
                            "Invite",
                            icon="mail",
                            on_click=lambda did=dept_id, col=members_col, rs=role_select: (
                                _invite_dialog(did, col, rs.value)
                            ),
                        ).props("color=secondary")


def _invite_dialog(dept_id: str, col, role: str) -> None:
    with ui.dialog() as dlg, ui.card().classes("w-96 p-6 gap-4"):
        ui.label("Invite new user").classes("text-lg font-semibold")
        name_input = ui.input("Full name").classes("w-full")
        email_input = ui.input("Email").classes("w-full").props("type=email")
        error = ui.label("").classes("text-red-500 text-sm")
        link_label = ui.label("").classes("text-xs text-gray-500 break-all")

        async def send():
            error.text = ""
            link_label.text = ""
            name_val = name_input.value.strip()
            email_val = email_input.value.lower().strip()
            if not name_val or not email_val:
                error.text = "Name and email are required."
                return
            existing = await db.fetchrow(
                "SELECT id FROM user_account WHERE email = $1", email_val
            )
            if existing:
                error.text = (
                    "An account with this email already exists. Use Add instead."
                )
                return
            try:
                user_id = await db.fetchval(
                    "INSERT INTO user_account (email, name) VALUES ($1, $2) RETURNING id",
                    email_val,
                    name_val,
                )
                # Add to department
                dept_info = await db.fetchrow(
                    "SELECT d.organisation_id FROM department d WHERE d.id = $1::uuid",
                    dept_id,
                )
                await db.execute(
                    """
                    INSERT INTO user_department (user_id, department_id, role)
                    VALUES ($1::uuid, $2::uuid, $3)
                    ON CONFLICT (user_id, department_id) DO UPDATE SET role = EXCLUDED.role
                    """,
                    str(user_id),
                    dept_id,
                    role,
                )
                management_id = await db.fetchval(
                    """
                    INSERT INTO management (organisation_id, department_id)
                    VALUES ($1::uuid, $2::uuid)
                    ON CONFLICT (organisation_id, department_id, entity, time_start, time_end)
                        DO UPDATE SET organisation_id = EXCLUDED.organisation_id
                    RETURNING id
                    """,
                    str(dept_info["organisation_id"]),
                    dept_id,
                )
                await db.execute(
                    """
                    INSERT INTO user_management (user_id, management_id, role)
                    VALUES ($1::uuid, $2::uuid, $3)
                    ON CONFLICT (user_id, management_id) DO NOTHING
                    """,
                    str(user_id),
                    str(management_id),
                    role,
                )
                # Generate invite link
                token = await auth_module.create_reset_token(email_val)
                portal_url = os.environ.get("PORTAL_URL", "http://localhost:8081")
                invite_link = f"{portal_url}/reset-password?token={token}"
                try:
                    await mail.send_email(
                        to=email_val,
                        subject="You have been invited to LEAF Portal",
                        body=(
                            f"Hi {name_val},\n\n"
                            f"You have been invited to LEAF Portal. "
                            f"Click the link below to set your password:\n\n"
                            f"{invite_link}\n\n"
                            f"If the link does not work, go to {portal_url}/reset-password\n"
                            f"and enter this code manually:\n\n{token}\n"
                        ),
                    )
                    ui.notify(f"Invite sent to {email_val}.", color="positive")
                except Exception:
                    logging.exception("Failed to send invite email")
                    link_label.text = (
                        f"Email failed — share this link manually: {invite_link}"
                    )
                    ui.notify(
                        "Account created but email failed. See link below.",
                        color="warning",
                    )
                col.clear()
                dlg.close()
            except Exception as e:
                error.text = f"Error: {e}"

        with ui.row().classes("w-full justify-end gap-2 mt-2"):
            ui.button("Cancel", on_click=dlg.close).props("flat")
            ui.button("Send invite", icon="send", on_click=send).props("color=primary")

    dlg.open()


async def _revoke(user_id: str, dept_id: str, col) -> None:
    # Remove organisational tracking entry
    await db.execute(
        "DELETE FROM user_department WHERE user_id = $1::uuid AND department_id = $2::uuid",
        user_id,
        dept_id,
    )
    # Remove the corresponding full-scope access management entry (entity=NULL, time=NULL)
    await db.execute(
        """
        DELETE FROM user_management
        WHERE user_id = $1::uuid
          AND management_id IN (
              SELECT p.id FROM management p
              WHERE p.department_id = $2::uuid
                AND p.entity       IS NULL
                AND p.time_start   IS NULL
                AND p.time_end     IS NULL
          )
        """,
        user_id,
        dept_id,
    )
    ui.navigate.to("/dept/members")
