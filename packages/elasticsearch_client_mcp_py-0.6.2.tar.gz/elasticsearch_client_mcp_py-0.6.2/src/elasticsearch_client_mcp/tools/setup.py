"""
Setup helper functions for interactive configuration guidance.
"""
from __future__ import annotations

import re
from typing import Annotated

from ..config import (
    ConnectionProfile,
    EnvVars,
    SafetyConfig,
    SafetyPolicy,
    generate_env_var_commands,
    generate_safety_env_commands,
    load_wizard_state,
    need_setup,
    save_profiles,
    save_safety_config,
    save_wizard_state,
    load_config,
)
from ..tools.connections import do_list_connections, do_get_connection


# ============ 配置模板预设 ============

class ConfigPreset:
    """配置模板"""
    def __init__(
        self,
        name: str,
        description: str,
        read_only: bool,
        max_search_size: int,
        request_timeout: int,
        allow_search: bool,
        allow_index: bool,
        allow_update: bool,
        allow_delete: bool,
        allow_bulk: bool,
        allow_create_index: bool,
        allow_delete_index: bool,
        allow_update_mapping: bool,
        allow_cluster: bool,
        confirm_write: bool,
        confirm_delete: bool,
        confirm_index: bool,
    ):
        self.name = name
        self.description = description
        self.read_only = read_only
        self.max_search_size = max_search_size
        self.request_timeout = request_timeout
        self.allow_search = allow_search
        self.allow_index = allow_index
        self.allow_update = allow_update
        self.allow_delete = allow_delete
        self.allow_bulk = allow_bulk
        self.allow_create_index = allow_create_index
        self.allow_delete_index = allow_delete_index
        self.allow_update_mapping = allow_update_mapping
        self.allow_cluster = allow_cluster
        self.confirm_write = confirm_write
        self.confirm_delete = confirm_delete
        self.confirm_index = confirm_index


# 预设模板
PRESETS = {
    "safe": ConfigPreset(
        name="safe",
        description="保守模式 - 只读，禁止删除所有内容",
        read_only=False,
        max_search_size=100,
        request_timeout=30,
        allow_search=True,
        allow_index=False,
        allow_update=False,
        allow_delete=False,
        allow_bulk=False,
        allow_create_index=False,
        allow_delete_index=False,
        allow_update_mapping=False,
        allow_cluster=False,
        confirm_write=True,
        confirm_delete=True,
        confirm_index=True,
    ),
    "balanced": ConfigPreset(
        name="balanced",
        description="平衡模式 - 允许常规操作，写入需确认",
        read_only=False,
        max_search_size=500,
        request_timeout=60,
        allow_search=True,
        allow_index=True,
        allow_update=True,
        allow_delete=True,
        allow_bulk=True,
        allow_create_index=False,
        allow_delete_index=False,
        allow_update_mapping=False,
        allow_cluster=False,
        confirm_write=True,
        confirm_delete=True,
        confirm_index=True,
    ),
    "open": ConfigPreset(
        name="open",
        description="开放模式 - 允许大多数操作，仅危险操作需确认",
        read_only=False,
        max_search_size=1000,
        request_timeout=120,
        allow_search=True,
        allow_index=True,
        allow_update=True,
        allow_delete=True,
        allow_bulk=True,
        allow_create_index=True,
        allow_delete_index=False,  # 删除索引始终禁止
        allow_update_mapping=True,
        allow_cluster=False,
        confirm_write=False,
        confirm_delete=True,  # 删除始终确认
        confirm_index=True,
    ),
}


# ============ 工具函数 ============

def _generate_env_var_names(env_name: str, description: str | None = None) -> dict:
    """根据环境名称和描述生成推荐的环境变量名"""
    clean_desc = re.sub(r'[^a-zA-Z0-9]', '', description or "")
    clean_desc = clean_desc.upper()[:10]
    prefix = f"{env_name.upper()}_{clean_desc}" if clean_desc else env_name.upper()

    return {
        "hosts": f"{prefix}_HOSTS",
        "username": f"{prefix}_USERNAME",
        "password": f"{prefix}_PASSWORD",
    }


def _parse_bool_input(val: str | None) -> bool:
    """解析布尔输入 (y/n/是/否/true/false 等)"""
    if val is None:
        return False
    val = val.strip().lower()
    return val in ("1", "true", "yes", "y", "是", "ok")


def _format_bool(val: bool) -> str:
    return "是" if val else "否"


# ============ 帮助函数 ============

def show_help(topic: str | None = None) -> dict:
    """
    显示帮助信息。

    topic 可选值:
    - "guide"     - 快速入门指南
    - "add"       - 添加配置说明
    - "preset"    - 模板说明
    - "env"       - 环境变量说明
    - "wizard"    - 逐步引导说明
    - None        - 显示所有帮助主题
    """
    if topic and topic not in ("guide", "add", "preset", "env", "wizard"):
        topic = None

    all_topics = {
        "guide": _build_guide_help(),
        "add": _build_add_help(),
        "preset": _build_preset_help(),
        "env": _build_env_help(),
        "wizard": _build_wizard_help(),
    }

    if topic:
        return {
            "topic": topic,
            "message": all_topics[topic],
            "hint": "输入 /help 查看所有帮助主题",
        }

    # 显示所有主题
    topics_list = "\n".join([
        f"  • {k:10} - {v.split(chr(10))[0].replace('┌', '').replace('│', '').strip()}"
        for k, v in all_topics.items()
    ])

    return {
        "topics": list(all_topics.keys()),
        "message": f"""┌─────────────────────────────────────────────────┐
│           ES MCP 帮助系统                        │
├─────────────────────────────────────────────────┤
│  可用帮助主题:                                   │
{topics_list}
│  ? <topic>  - 查看特定主题帮助                   │
│     例如: ? guide                                │
└─────────────────────────────────────────────────┘""",
    }


def _build_guide_help() -> str:
    return """┌─────────────────────────────────────────────────┐
│           🚀 快速入门指南                        │
├─────────────────────────────────────────────────┤
│                                                 │
│  首次使用 ES MCP，按以下步骤配置:               │
│                                                 │
│  Step 1: 调用 setup 进入配置向导                │
│                                                 │
│  Step 2: 选择 [2] 添加配置                      │
│          → 输入环境 (test/uat/prod)              │
│          → 输入描述 (选填)                       │
│          → 选择模式:                            │
│            • 快速模板 - 直接选 safe/balanced/open│
│            • 逐步引导 - 每项自定义               │
│                                                 │
│  Step 3: 添加环境变量到 shell 配置               │
│          export TEST_HOSTS="http://..."         │
│          export TEST_PASSWORD="..."             │
│                                                 │
│  Step 4: 运行 source ~/.zshrc 生效              │
│                                                 │
│  常用命令:                                       │
│  • setup         - 进入配置向导                  │
│  • list_connections - 查看所有连接               │
│  • list_indices  - 查看索引                      │
│  • get_mapping   - 查看索引结构                  │
│  • execute_request - 执行 ES 请求               │
│                                                 │
└─────────────────────────────────────────────────┘"""


def _build_add_help() -> str:
    return """┌─────────────────────────────────────────────────┐
│           📝 添加配置说明                        │
├─────────────────────────────────────────────────┤
│                                                 │
│  添加新连接有两种方式:                           │
│                                                 │
│  【方式一: 快速模板】                            │
│  ─────────────────────                          │
│  适合: 想要快速配置，选择预设模板                │
│                                                 │
│  流程:                                          │
│    add_connection(env="test")                   │
│      → 选择 "1" 快速模板                        │
│      → 选择模板 (safe/balanced/open)            │
│      → 完成!                                    │
│                                                 │
│  【方式二: 逐步引导】                            │
│  ─────────────────────                          │
│  适合: 需要自定义每项配置                        │
│                                                 │
│  流程:                                          │
│    add_connection(env="test")                  │
│      → 选择 "2" 逐步引导                        │
│      → 依次设置每项参数                         │
│      → 完成!                                    │
│                                                 │
│  参数说明:                                       │
│  • env        - 环境: test/uat/prod            │
│  • description - 描述: 任意文字                  │
│  • mode       - 模式: preset 或 wizard           │
│                                                 │
└─────────────────────────────────────────────────┘"""


def _build_preset_help() -> str:
    return """┌─────────────────────────────────────────────────┐
│           📦 配置模板说明                        │
├─────────────────────────────────────────────────┤
│                                                 │
│  三种预设模板对比:                               │
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │ 🛡️  safe (保守模式)                      │   │
│  │ ─────────────────────────────────────── │   │
│  │ 适用: 查询为主，禁止修改删除              │   │
│  │ • 允许: search 查询                       │   │
│  │ • 禁止: index/update/delete/bulk         │   │
│  │ • 所有操作需确认                          │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │ ⚖️  balanced (平衡模式)                   │   │
│  │ ─────────────────────────────────────── │   │
│  │ 适用: 日常开发，常用操作                  │   │
│  │ • 允许: search/index/update/delete/bulk  │   │
│  │ • 禁止: create_index/delete_index        │   │
│  │ • 写/删操作需确认                        │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │ 🔓 open (开放模式)                       │   │
│  │ ─────────────────────────────────────── │   │
│  │ 适用: 充分信任，灵活操作                  │   │
│  │ • 允许: 所有常规操作                      │   │
│  │ • 禁止: delete_index / cluster 操作      │   │
│  │ • 删除/危险操作需确认                    │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
└─────────────────────────────────────────────────┘"""


def _build_env_help() -> str:
    return """┌─────────────────────────────────────────────────┐
│           🔐 环境变量说明                        │
├─────────────────────────────────────────────────┤
│                                                 │
│  敏感信息通过环境变量存储，不暴露实际值         │
│                                                 │
│  配置后需要设置的环境变量:                       │
│                                                 │
│  • *_HOSTS     - ES 服务器地址                  │
│                  例: http://10.10.2.49:9200    │
│                                                 │
│  • *_USERNAME  - 用户名 (可选)                  │
│                  有认证时填写                    │
│                                                 │
│  • *_PASSWORD  - 密码 (可选)                    │
│                  有认证时填写                    │
│                                                 │
│  ───────────────────────────────────────        │
│  配置示例:                                       │
│                                                 │
│  # ~/.zshrc 中添加:                             │
│  export TEST_HOSTS="http://10.10.2.49:9200"    │
│  export TEST_PASSWORD="your_password"          │
│                                                 │
│  # 使配置生效:                                  │
│  source ~/.zshrc                               │
│                                                 │
└─────────────────────────────────────────────────┘"""


def _build_wizard_help() -> str:
    return """┌─────────────────────────────────────────────────┐
│           🎯 逐步引导说明                        │
├─────────────────────────────────────────────────┤
│                                                 │
│  逐步引导会依次询问以下配置项:                   │
│                                                 │
│  基础配置:                                       │
│  ─────────────                                  │
│  1. 最大搜索条数 (默认: 100)                    │
│     - 单次查询最多返回的文档数                   │
│                                                 │
│  2. 请求超时 (默认: 30秒)                       │
│     - 单次请求的最大等待时间                     │
│                                                 │
│  操作权限:                                       │
│  ─────────────                                  │
│  3. 允许 search 查询     (默认: 是)             │
│  4. 允许 index 写入     (默认: 是)             │
│  5. 允许 update 更新     (默认: 是)             │
│  6. 允许 delete 删除     (默认: 是)             │
│  7. 允许 bulk 批量操作   (默认: 是)             │
│                                                 │
│  确认设置:                                       │
│  ─────────────                                  │
│  8. 写操作需确认         (默认: 是)             │
│  9. 删除操作需确认       (默认: 是)             │
│  10.创建索引需确认       (默认: 是)             │
│                                                 │
│  ───────────────────────────────────────        │
│  输入说明:                                       │
│  • 布尔项: 直接回车使用默认值 [Y/n]             │
│  • 数字项: 直接回车使用默认值，或输入新值       │
│  • 输入 q 取消操作                              │
│                                                 │
└─────────────────────────────────────────────────┘"""


# ============ 主入口 ============

def setup_guide() -> dict:
    """
    配置向导主入口，返回引导菜单。
    """
    return {
        "need_action": True,
        "message": """┌─────────────────────────────────────────────────┐
│         ES MCP 配置向导                          │
├─────────────────────────────────────────────────┤
│  1️⃣  查询配置 - 查看当前所有配置                  │
│  2️⃣  添加配置 - 新增一个连接                     │
│  3️⃣  修改配置 - 编辑现有连接                     │
│  4️⃣  删除配置 - 删除某个连接                     │
│  5️⃣  设为默认 - 设置默认连接                    │
│  0️⃣  退出                                       │
├─────────────────────────────────────────────────┤
│  💡 输入 ? 查看帮助，或输入 help <主题>           │
└─────────────────────────────────────────────────┘
请输入数字 (1-5) 或 0 退出:""",
        "actions": [
            {"key": "1", "label": "查询配置", "function": "query_config"},
            {"key": "2", "label": "添加配置", "function": "add_config"},
            {"key": "3", "label": "修改配置", "function": "update_config"},
            {"key": "4", "label": "删除配置", "function": "delete_config"},
            {"key": "5", "label": "设为默认", "function": "set_default"},
        ],
    }


# ============ 查询配置 ============

def query_config() -> dict:
    """
    查询配置 - 列出所有连接，可选择查看详情。
    """
    result = do_list_connections()
    connections = result.get("connections", [])

    if not connections:
        return {
            "has_connections": False,
            "message": """暂无配置的连接。

请使用 add_config 添加新连接。""",
        }

    # 构建连接列表
    lines = ["当前已配置的连接：\n"]
    for i, conn in enumerate(connections, 1):
        default_mark = " ⭐ (默认)" if conn["profile"] == result.get("default") else ""
        auth_mark = " 🔒" if conn.get("has_auth") else ""
        lines.append(f"  {i}. {conn['profile']}{default_mark}{auth_mark}")
        lines.append(f"     环境: {conn['env']} | 描述: {conn['description']}")
        env_vars = conn.get("env_vars", {})
        if env_vars.get("hosts"):
            lines.append(f"     hosts: {env_vars['hosts']}")

    lines.append("\n输入连接名称查看详情，或输入 q 返回:")

    return {
        "has_connections": True,
        "connections": connections,
        "default": result.get("default"),
        "message": "\n".join(lines),
    }


def query_config_detail(profile_name: str) -> dict:
    """
    查询指定连接的详情。
    """
    result = do_get_connection(profile_name)

    if not result.get("found"):
        return {
            "found": False,
            "message": f"未找到连接: {profile_name}",
        }

    p = result
    lines = [
        f"=== 连接详情: {p['profile']} ===",
        f"环境: {p['env']}",
        f"描述: {p['description']}",
        f"认证: {'有' if p.get('has_auth') else '无'}",
        "",
        "环境变量:",
    ]

    env_vars = p.get("env_vars", {})
    for key in ("hosts", "username", "password"):
        if env_vars.get(key):
            lines.append(f"  {key}: {env_vars[key]}")

    return {
        "found": True,
        "profile": p["profile"],
        "env": p["env"],
        "description": p["description"],
        "has_auth": p.get("has_auth"),
        "env_vars": env_vars,
        "message": "\n".join(lines),
    }


# ============ 添加配置 ============

def add_config(
    env: str | None = None,
    description: str | None = None,
    mode: str | None = None,
    # 详细配置 (用于逐步引导)
    max_search_size: int | None = None,
    request_timeout: int | None = None,
    allow_search: bool | None = None,
    allow_index: bool | None = None,
    allow_update: bool | None = None,
    allow_delete: bool | None = None,
    allow_bulk: bool | None = None,
    confirm_write: bool | None = None,
    confirm_delete: bool | None = None,
    confirm_index: bool | None = None,
) -> dict:
    """
    添加新连接配置。

    参数:
    - env: 环境名称 (test/uat/prod)，None 则引导选择
    - description: 连接描述，None 则引导输入
    - mode: 添加模式，"preset"=快速模板，"wizard"=逐步引导，None 则引导选择
    - 其他参数: 详细配置项，用于逐步引导或自定义
    """
    # 尝试恢复上次引导状态
    saved_state = load_wizard_state()

    # Step 1: 选择环境
    if env is None:
        # 如果有保存的状态，恢复 env
        if saved_state and saved_state.get("env"):
            env = saved_state["env"]
        else:
            save_wizard_state(None)  # 清除旧状态
            return {
                "step": "select_env",
                "message": """┌─────────────────────────────────────────────────┐
│  添加连接 - Step 1/4: 选择环境                    │
├─────────────────────────────────────────────────┤
│  请选择环境:                                     │
│  1. test  - 测试环境                            │
│  2. uat   - 预发环境                            │
│  3. prod  - 生产环境                            │
├─────────────────────────────────────────────────┤
│  💡 输入 ? add 查看添加配置帮助                  │
└─────────────────────────────────────────────────┘
输入 1/2/3 或环境名称 (test/uat/prod):""",
            }

    # 验证环境
    if env not in ("test", "uat", "prod"):
        return {
            "step": "select_env",
            "error": f"未知环境: {env}，请选择 test/uat/prod",
            "message": """未知环境，请重新选择:
1. test  - 测试环境
2. uat   - 预发环境
3. prod  - 生产环境""",
        }

    # Step 2: 输入描述
    if description is None:
        # 如果有保存的状态，恢复 description
        if saved_state and saved_state.get("description") is not None:
            description = saved_state["description"]
        else:
            # 保存当前状态
            save_wizard_state({"env": env})
            return {
                "step": "input_description",
                "env": env,
                "message": """┌─────────────────────────────────────────────────┐
│  添加连接 - Step 2/4: 输入描述                     │
├─────────────────────────────────────────────────┤
│  请输入连接描述 (选填，回车跳过):                 │
│  例如: "ES测试服务器"、"日志集群" 等              │
└─────────────────────────────────────────────────┘""",
            }

    # Step 3: 选择模式
    if mode is None:
        # 如果有保存的状态，恢复 mode
        if saved_state and saved_state.get("mode"):
            mode = saved_state["mode"]
        else:
            # 保存当前状态
            save_wizard_state({"env": env, "description": description})
            return {
                "step": "select_mode",
                "env": env,
                "description": description,
                "message": f"""┌─────────────────────────────────────────────────┐
│  添加连接 - Step 3/4: 选择配置方式                │
├─────────────────────────────────────────────────┤
│  环境: {env}                                     │
│  描述: {description or '(无)'}                       │
├─────────────────────────────────────────────────┤
│  请选择配置方式:                                 │
│                                                 │
│  1️⃣  快速模板 - 从预设模板选择                   │
│      safe      - 保守模式，只读                  │
│      balanced  - 平衡模式，常用操作              │
│      open      - 开放模式，大多操作              │
│                                                 │
│  2️⃣  逐步引导 - 自定义每项配置                   │
└─────────────────────────────────────────────────┘
输入 1 或 2:""",
            }

    # Step 4: 根据模式完成配置
    if mode == "preset":
        # 如果还没有选择 preset，返回模板选择
        # preset 参数会在后续调用时传入
        save_wizard_state({"env": env, "description": description, "mode": "preset"})
        return {
            "step": "select_preset",
            "env": env,
            "description": description,
            "message": f"""┌─────────────────────────────────────────────────┐
│  添加连接 - Step 4/4: 选择模板                    │
├─────────────────────────────────────────────────┤
│  环境: {env}                                     │
│  描述: {description or '(无)'}                       │
├─────────────────────────────────────────────────┤
│  可用模板:                                       │
│                                                 │
│  1️⃣  safe     - 保守模式 (只读，禁止删除)        │
│  2️⃣  balanced  - 平衡模式 (常规操作，需确认)      │
│  3️⃣  open     - 开放模式 (大多操作可执行)        │
├─────────────────────────────────────────────────┤
│  💡 输入 ? preset 查看模板对比帮助                │
└─────────────────────────────────────────────────┘
输入 1/2/3 或模板名称:""",
        }

    elif mode == "wizard":
        # 逐步引导
        return add_config_wizard(env, description, {
            "max_search_size": max_search_size,
            "request_timeout": request_timeout,
            "allow_search": allow_search,
            "allow_index": allow_index,
            "allow_update": allow_update,
            "allow_delete": allow_delete,
            "allow_bulk": allow_bulk,
            "confirm_write": confirm_write,
            "confirm_delete": confirm_delete,
            "confirm_index": confirm_index,
        })

    return {
        "error": f"未知模式: {mode}",
        "message": "请输入 1 (快速模板) 或 2 (逐步引导)",
    }


def add_config_preset(
    env: str,
    description: str | None,
    preset: str,
) -> dict:
    """
    完成快速模板配置的最后一步 - 选择模板并保存。
    """
    if preset not in PRESETS:
        return {
            "step": "select_preset",
            "error": f"未知模板: {preset}，可用: safe, balanced, open",
        }

    p = PRESETS[preset]

    result = _do_save_profile(
        env=env,
        description=description,
        preset_name=preset,
        max_search_size=p.max_search_size,
        request_timeout=p.request_timeout,
        allow_search=p.allow_search,
        allow_index=p.allow_index,
        allow_update=p.allow_update,
        allow_delete=p.allow_delete,
        allow_bulk=p.allow_bulk,
        allow_create_index=p.allow_create_index,
        allow_delete_index=p.allow_delete_index,
        allow_update_mapping=p.allow_update_mapping,
        allow_cluster=False,
        confirm_write=p.confirm_write,
        confirm_delete=p.confirm_delete,
        confirm_index=p.confirm_index,
    )

    # 清除引导状态
    save_wizard_state(None)

    return result


def add_config_wizard(env: str, description: str | None, params: dict) -> dict:
    """
    逐步引导添加配置。
    """
    # 定义引导步骤
    wizard_steps = [
        {
            "key": "max_search_size",
            "prompt": "最大搜索条数",
            "default": "100",
            "type": "int",
        },
        {
            "key": "request_timeout",
            "prompt": "请求超时 (秒)",
            "default": "30",
            "type": "int",
        },
        {
            "key": "allow_search",
            "prompt": "允许 search 查询",
            "default": "y",
            "type": "bool",
        },
        {
            "key": "allow_index",
            "prompt": "允许 index 写入",
            "default": "y",
            "type": "bool",
        },
        {
            "key": "allow_update",
            "prompt": "允许 update 更新",
            "default": "y",
            "type": "bool",
        },
        {
            "key": "allow_delete",
            "prompt": "允许 delete 删除",
            "default": "y",
            "type": "bool",
        },
        {
            "key": "allow_bulk",
            "prompt": "允许 bulk 批量操作",
            "default": "y",
            "type": "bool",
        },
        {
            "key": "confirm_write",
            "prompt": "写操作需确认",
            "default": "y",
            "type": "bool",
        },
        {
            "key": "confirm_delete",
            "prompt": "删除操作需确认",
            "default": "y",
            "type": "bool",
        },
        {
            "key": "confirm_index",
            "prompt": "创建索引需确认",
            "default": "y",
            "type": "bool",
        },
    ]

    # 检查当前步骤
    current_step = params.get("_current_step", 0)

    if current_step >= len(wizard_steps):
        # 引导完成，保存配置
        return _save_profile_from_wizard(env, description, params)

    step = wizard_steps[current_step]
    key = step["key"]
    current_val = params.get(key)

    # 如果已有值，跳到下一步
    if current_val is not None:
        params["_current_step"] = current_step + 1
        return add_config_wizard(env, description, params)

    return {
        "step": f"wizard_{key}",
        "env": env,
        "description": description,
        "progress": f"{current_step + 1}/{len(wizard_steps)}",
        "message": f"""┌─────────────────────────────────────────────────┐
│  添加连接 - 逐步引导 ({current_step + 1}/{len(wizard_steps)})           │
├─────────────────────────────────────────────────┤
│  环境: {env}                                     │
│  描述: {description or '(无)'}                       │
├─────────────────────────────────────────────────┤
│  {step['prompt']}                          │
│  [默认: {step['default']}]                                   │
├─────────────────────────────────────────────────┤
│  💡 输入 ? wizard 查看引导说明                    │
└─────────────────────────────────────────────────┘
输入值 (直接回车使用默认值):""",
        "wizard_params": params,
    }


def add_config_wizard_input(
    env: str,
    description: str | None,
    params: dict,
    step_key: str,
    value: str,
) -> dict:
    """
    处理逐步引导的用户输入。
    """
    wizard_steps = [
        {"key": "max_search_size", "type": "int", "default": "100"},
        {"key": "request_timeout", "type": "int", "default": "30"},
        {"key": "allow_search", "type": "bool", "default": "y"},
        {"key": "allow_index", "type": "bool", "default": "y"},
        {"key": "allow_update", "type": "bool", "default": "y"},
        {"key": "allow_delete", "type": "bool", "default": "y"},
        {"key": "allow_bulk", "type": "bool", "default": "y"},
        {"key": "confirm_write", "type": "bool", "default": "y"},
        {"key": "confirm_delete", "type": "bool", "default": "y"},
        {"key": "confirm_index", "type": "bool", "default": "y"},
    ]

    step_map = {s["key"]: s for s in wizard_steps}
    step = step_map.get(step_key)

    if not step:
        return {"error": f"未知步骤: {step_key}"}

    # 解析输入值
    if step["type"] == "int":
        parsed_value = int(value) if value.strip() else int(step["default"])
    else:
        parsed_value = _parse_bool_input(value) if value.strip() else _parse_bool_input(step["default"])

    params[step_key] = parsed_value
    params["_current_step"] = params.get("_current_step", 0) + 1

    return add_config_wizard(env, description, params)


def _save_profile_from_wizard(env: str, description: str | None, params: dict) -> dict:
    """从逐步引导结果保存配置"""
    # 提取配置
    max_search_size = params.get("max_search_size", 100)
    request_timeout = params.get("request_timeout", 30)
    allow_search = params.get("allow_search", True)
    allow_index = params.get("allow_index", True)
    allow_update = params.get("allow_update", True)
    allow_delete = params.get("allow_delete", True)
    allow_bulk = params.get("allow_bulk", True)
    confirm_write = params.get("confirm_write", True)
    confirm_delete = params.get("confirm_delete", True)
    confirm_index = params.get("confirm_index", True)

    return _do_save_profile(
        env=env,
        description=description,
        preset_name="wizard",
        max_search_size=max_search_size,
        request_timeout=request_timeout,
        allow_search=allow_search,
        allow_index=allow_index,
        allow_update=allow_update,
        allow_delete=allow_delete,
        allow_bulk=allow_bulk,
        allow_create_index=False,
        allow_delete_index=False,
        allow_update_mapping=False,
        allow_cluster=False,
        confirm_write=confirm_write,
        confirm_delete=confirm_delete,
        confirm_index=confirm_index,
    )


# ============ 修改配置 ============

def update_config(profile_name: str | None = None) -> dict:
    """
    修改现有连接配置。
    """
    result = do_list_connections()
    connections = result.get("connections", [])

    if not connections:
        return {
            "has_connections": False,
            "message": "暂无配置的连接，无法修改。",
        }

    # Step 1: 选择要修改的连接
    if profile_name is None:
        lines = ["请选择要修改的连接:\n"]
        for i, conn in enumerate(connections, 1):
            lines.append(f"  {i}. {conn['profile']} ({conn['env']}) - {conn['description']}")
        lines.append("\n输入连接名称或 q 返回:")
        return {
            "step": "select_profile",
            "message": "\n".join(lines),
        }

    # 验证连接存在
    conn = next((c for c in connections if c["profile"] == profile_name), None)
    if not conn:
        return {
            "step": "select_profile",
            "error": f"未找到连接: {profile_name}",
            "message": f"未找到连接: {profile_name}\n请从以下列表选择:",
        }

    # 加载完整配置
    detail = do_get_connection(profile_name)

    # Step 2: 选择要修改的项
    return {
        "step": "select_field",
        "profile": profile_name,
        "current": detail,
        "message": f"""┌─────────────────────────────────────────────────┐
│  修改连接: {profile_name:<30}  │
├─────────────────────────────────────────────────┤
│  当前配置:                                       │
│    描述: {detail.get('description', '无')}                            │
│    环境: {detail.get('env')}                                    │
├─────────────────────────────────────────────────┤
│  请选择要修改的项:                               │
│  1. 描述 (description)                          │
│  2. 环境 (env)                                  │
│  3. 安全策略 (使用模板重新应用)                  │
│  0. 返回                                        │
└─────────────────────────────────────────────────┘
输入数字 1-3 或 0 返回:""",
    }


def update_config_field(
    profile_name: str,
    field: str,
    value: str,
) -> dict:
    """
    更新连接的指定字段。
    """
    config = load_config()
    profile = config.get_profile(profile_name)

    if not profile:
        return {"error": f"未找到连接: {profile_name}"}

    if field == "description":
        profile.description = value if value.strip() else None
        save_profiles(config.profiles, has_prompted_setup=True)
        return {
            "success": True,
            "message": f"描述已更新为: {value or '(无)'}",
        }

    elif field == "env":
        if value not in ("test", "uat", "prod"):
            return {"error": f"未知环境: {value}，请选择 test/uat/prod"}
        profile.env = value
        save_profiles(config.profiles, has_prompted_setup=True)
        return {
            "success": True,
            "message": f"环境已更新为: {value}",
        }

    return {"error": f"未知字段: {field}"}


def update_config_preset(
    profile_name: str,
    preset: str,
) -> dict:
    """
    使用新模板重新应用安全策略。
    """
    if preset not in PRESETS:
        return {"error": f"未知模板: {preset}，可用: {', '.join(PRESETS.keys())}"}

    p = PRESETS[preset]

    safety = SafetyConfig(
        read_only=p.read_only,
        max_search_size=p.max_search_size,
        request_timeout=p.request_timeout,
        policy=SafetyPolicy(
            allow_search=p.allow_search,
            allow_index=p.allow_index,
            allow_update=p.allow_update,
            allow_delete=p.allow_delete,
            allow_bulk=p.allow_bulk,
            allow_create_index=p.allow_create_index,
            allow_delete_index=p.allow_delete_index,
            allow_update_mapping=p.allow_update_mapping,
            allow_cluster=False,
        ),
        confirm_write=p.confirm_write,
        confirm_delete=p.confirm_delete,
        confirm_index=p.confirm_index,
    )

    save_safety_config(safety)

    return {
        "success": True,
        "message": f"安全策略已更新为模板: {preset} ({p.description})",
    }


# ============ 删除配置 ============

def delete_config(profile_name: str | None = None) -> dict:
    """
    删除连接配置。
    """
    result = do_list_connections()
    connections = result.get("connections", [])

    if not connections:
        return {
            "has_connections": False,
            "message": "暂无配置的连接，无法删除。",
        }

    # Step 1: 选择要删除的连接
    if profile_name is None:
        lines = ["⚠️  请选择要删除的连接:\n"]
        for i, conn in enumerate(connections, 1):
            default_mark = " ⭐" if conn["profile"] == result.get("default") else ""
            lines.append(f"  {i}. {conn['profile']}{default_mark} ({conn['env']}) - {conn['description']}")
        lines.append("\n输入连接名称或 q 返回:")
        return {
            "step": "select_profile",
            "message": "\n".join(lines),
        }

    # Step 2: 确认删除
    conn = next((c for c in connections if c["profile"] == profile_name), None)
    if not conn:
        return {
            "step": "select_profile",
            "error": f"未找到连接: {profile_name}",
        }

    return {
        "step": "confirm_delete",
        "profile": profile_name,
        "message": f"""┌─────────────────────────────────────────────────┐
│  ⚠️  确认删除连接?                              │
├─────────────────────────────────────────────────┤
│  名称: {profile_name}                            │
│  环境: {conn['env']}                                    │
│  描述: {conn['description']}                            │
├─────────────────────────────────────────────────┤
│  此操作不可恢复!                                │
└─────────────────────────────────────────────────┘
输入 yes 确认删除，或 q 取消:""",
    }


def do_delete_config(profile_name: str) -> dict:
    """
    执行删除连接。
    """
    config = load_config()
    original_count = len(config.profiles)

    config.profiles = [p for p in config.profiles if p.name != profile_name]

    if len(config.profiles) == original_count:
        return {"error": f"未找到连接: {profile_name}"}

    save_profiles(config.profiles, has_prompted_setup=True)

    return {
        "success": True,
        "message": f"已删除连接: {profile_name}",
    }


# ============ 设为默认 ============

def set_default(profile_name: str | None = None) -> dict:
    """
    设置默认连接。
    """
    result = do_list_connections()
    connections = result.get("connections", [])

    if not connections:
        return {
            "has_connections": False,
            "message": "暂无配置的连接，无法设置默认。",
        }

    # Step 1: 选择要设为默认的连接
    if profile_name is None:
        lines = ["请选择设为默认的连接:\n"]
        current_default = result.get("default")
        for conn in connections:
            mark = " ⭐ (当前默认)" if conn["profile"] == current_default else ""
            lines.append(f"  • {conn['profile']}{mark} ({conn['env']}) - {conn['description']}")
        lines.append("\n输入连接名称或 q 返回:")
        return {
            "step": "select_profile",
            "message": "\n".join(lines),
        }

    # 验证连接存在
    conn = next((c for c in connections if c["profile"] == profile_name), None)
    if not conn:
        return {
            "step": "select_profile",
            "error": f"未找到连接: {profile_name}",
        }

    # 设置默认 (通过调整 profiles 顺序，把选中的放到最前面作为默认)
    config = load_config()
    profile = config.get_profile(profile_name)
    if not profile:
        return {"error": f"未找到连接: {profile_name}"}

    # 移动到列表首位
    config.profiles.remove(profile)
    config.profiles.insert(0, profile)
    save_profiles(config.profiles, has_prompted_setup=True)

    return {
        "success": True,
        "message": f"已将 {profile_name} 设为默认连接",
    }


# ============ 辅助函数 ============

def _do_save_profile(
    env: str,
    description: str | None,
    preset_name: str,
    max_search_size: int,
    request_timeout: int,
    allow_search: bool,
    allow_index: bool,
    allow_update: bool,
    allow_delete: bool,
    allow_bulk: bool,
    allow_create_index: bool,
    allow_delete_index: bool,
    allow_update_mapping: bool,
    allow_cluster: bool,
    confirm_write: bool,
    confirm_delete: bool,
    confirm_index: bool,
    clear_wizard_state: bool = True,
) -> dict:
    """保存新配置"""
    # 生成环境变量名
    env_names = _generate_env_var_names(env, description)

    # 构建 profile 名称
    profile_name = f"{env}-{description.replace(' ', '-').lower() if description else env}"

    profile = ConnectionProfile(
        name=profile_name,
        env=env,
        description=description,
        skip_product_check=True,
        env_vars=EnvVars(
            hosts=env_names["hosts"],
            username=env_names.get("username"),
            password=env_names["password"],
        ),
    )

    policy = SafetyPolicy(
        allow_search=allow_search,
        allow_index=allow_index,
        allow_update=allow_update,
        allow_delete=allow_delete,
        allow_bulk=allow_bulk,
        allow_create_index=allow_create_index,
        allow_delete_index=allow_delete_index,
        allow_update_mapping=allow_update_mapping,
        allow_cluster=False,
    )

    safety = SafetyConfig(
        read_only=False,
        max_search_size=max_search_size,
        request_timeout=request_timeout,
        policy=policy,
        confirm_write=confirm_write,
        confirm_delete=confirm_delete,
        confirm_index=confirm_index,
    )

    # 保存
    save_profiles([profile], has_prompted_setup=True)
    save_safety_config(safety)

    # 生成环境变量设置命令
    env_commands = generate_env_var_commands(profile)
    safety_commands = generate_safety_env_commands(safety)

    preset_desc = PRESETS[preset_name].description if preset_name in PRESETS else "自定义"

    message = f"""✅ 配置已保存!

┌─────────────────────────────────────────────────┐
│  连接: {profile_name:<36}  │
│  环境: {env}                                        │
│  描述: {description or '(无)'}                            │
│  模板: {preset_desc}              │
├─────────────────────────────────────────────────┤
│  安全策略:                                       │
│    允许 search: {_format_bool(allow_search)}                             │
│    允许 index:  {_format_bool(allow_index)}                             │
│    允许 update: {_format_bool(allow_update)}                             │
│    允许 delete: {_format_bool(allow_delete)}                            │
│    允许 bulk:   {_format_bool(allow_bulk)}                             │
│    最大搜索:    {max_search_size}                              │
│    超时:       {request_timeout}秒                              │
├─────────────────────────────────────────────────┤
│  环境变量名:                                     │
│    hosts:   {env_names['hosts']}                  │
│    password: {env_names['password']}                  │
└─────────────────────────────────────────────────┘

请在 shell 配置文件中添加:
export {env_names['hosts']}="http://your-es-host:9200"
export {env_names['password']}="your_password"

然后运行: source ~/.zshrc"""

    # 清除引导状态
    if clear_wizard_state:
        save_wizard_state(None)

    return {
        "success": True,
        "profile_name": profile_name,
        "preset": preset_name,
        "env_names": env_names,
        "message": message,
    }


# ============ 检查配置状态 ============

def do_check_setup_status() -> dict:
    """
    检查当前配置状态。
    """
    config = load_config()
    has_setup = not need_setup()
    connections = do_list_connections()

    return {
        "configured": has_setup,
        "has_connections": connections["count"] > 0,
        "connection_count": connections["count"],
        "default_connection": connections.get("default"),
        "connections": connections.get("connections", []),
    }
