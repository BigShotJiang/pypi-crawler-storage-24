from __future__ import annotations

from pathlib import Path

from textual.screen import Screen
from textual.widgets import Footer, Header, RichLog, Static


class RuntimeLogsScreen(Screen):
    """Tail the runtime log file (for auditability / debugging)."""

    BINDINGS = [
        ("escape", "app.pop_screen", "Back"),
    ]

    def compose(self):
        yield Header()
        path = getattr(self.app, "runtime_log_path", None)
        if not path:
            yield Static(
                "No runtime log configured.\n\nSet KIWI_CODE_RUNTIME_LOG_PATH to enable streaming.",
                id="runtime-log-missing",
            )
        else:
            yield RichLog(id="runtime-log", wrap=True, markup=False)
        yield Footer()

    def on_mount(self) -> None:
        path = getattr(self.app, "runtime_log_path", None)
        if not path:
            return

        self._path = Path(path)
        self._fp = self._path.open("r", encoding="utf-8", errors="replace")

        # Seed with last ~64KB so the screen is immediately useful.
        try:
            size = self._path.stat().st_size
            if size > 65536:
                self._fp.seek(size - 65536)
        except OSError:
            pass

        self._drain()

        # Poll for new content.
        self.set_interval(0.1, self._drain)

    def on_unmount(self) -> None:
        fp = getattr(self, "_fp", None)
        if fp:
            try:
                fp.close()
            except OSError:
                pass

    def _drain(self) -> None:
        log = self.query_one("#runtime-log", RichLog)
        chunk = self._fp.read()
        if not chunk:
            return
        for line in chunk.splitlines():
            log.write(line)
