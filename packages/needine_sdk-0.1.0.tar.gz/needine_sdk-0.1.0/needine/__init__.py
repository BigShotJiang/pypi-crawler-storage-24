"""Needine Python SDK – certificate API client."""

from __future__ import annotations

import os
from typing import Any

import httpx


class NeedineApiError(Exception):
    """Error returned by the Needine API."""

    def __init__(self, message: str, status: int, data: Any = None):
        super().__init__(message)
        self.status = status
        self.data = data


class NeedineClient:
    """Synchronous client for the Needine Certificate API."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("NEEDINE_API_KEY", "")
        self.base_url = (base_url or os.environ.get("NEEDINE_BASE_URL", "https://api.needine.com")).rstrip("/")
        if not self.api_key:
            raise ValueError("Needine API key is required. Pass api_key or set NEEDINE_API_KEY env var.")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"X-API-Key": self.api_key, "Content-Type": "application/json"},
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "NeedineClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ── Internal ─────────────────────────────────────────────────────────

    def _request(self, method: str, endpoint: str, **kwargs: Any) -> Any:
        response = self._client.request(method, endpoint, **kwargs)
        if response.status_code >= 400:
            try:
                data = response.json()
            except Exception:
                data = None
            msg = data.get("message", f"HTTP {response.status_code}") if isinstance(data, dict) else f"HTTP {response.status_code}"
            raise NeedineApiError(msg, response.status_code, data)
        return response.json()

    # ── Certificates ─────────────────────────────────────────────────────

    def create_certificate(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Create a new certificate."""
        return self._request("POST", "/certificates", json=payload)

    def list_certificates(self, page: int = 1, page_size: int = 50) -> dict[str, Any]:
        """List certificates with pagination."""
        return self._request("GET", "/certificates", params={"page": page, "pageSize": page_size})

    def get_certificate(self, certificate_id: str) -> dict[str, Any]:
        """Get full certificate details."""
        return self._request("GET", f"/certificates/{certificate_id}")

    # ── Verification ─────────────────────────────────────────────────────

    def verify_certificate(self, certificate_id: str) -> dict[str, Any]:
        """Verify a certificate (signature + trust)."""
        return self._request("GET", f"/verification/{certificate_id}")

    # ── Provenance ───────────────────────────────────────────────────────

    def get_provenance(self, certificate_id: str) -> dict[str, Any]:
        """Get provenance / lineage tree."""
        return self._request("GET", f"/certificates/{certificate_id}/provenance")

    # ── Export ───────────────────────────────────────────────────────────

    def export_json(self, certificate_id: str) -> dict[str, Any]:
        """Export verifiable JSON bundle."""
        return self._request("GET", f"/certificates/{certificate_id}/export", params={"format": "json"})

    def export_pdf(self, certificate_id: str) -> bytes:
        """Export PDF as bytes."""
        response = self._client.get(f"/certificates/{certificate_id}/export", params={"format": "pdf"})
        if response.status_code >= 400:
            raise NeedineApiError(f"HTTP {response.status_code}", response.status_code)
        return response.content

    # ── Anchors ──────────────────────────────────────────────────────────

    def verify_anchor(self, certificate_id: str) -> dict[str, Any]:
        """Verify blockchain anchor."""
        return self._request("POST", f"/verification/{certificate_id}/verify-anchor")
