# needine-sdk

Python SDK for the Needine Certificate API.

## Install

```bash
pip install needine-sdk
```

## Quick Start

```python
from needine import NeedineClient

client = NeedineClient(api_key="ndn_...")

# Create a certificate
cert = client.create_certificate({
    "certificateType": "ai_generated_report",
    "signerName": "Ana García",
    "issuingCompany": "Acme Corp",
    "model": {"provider": "openai", "modelName": "gpt-4o"},
    "inputEvidence": [{"sha256Hash": "abc123...", "mimeType": "text/plain"}],
    "outputEvidence": [{"sha256Hash": "def456...", "mimeType": "application/pdf"}],
})

print(cert["certificateId"])

# Verify
result = client.verify_certificate(cert["certificateId"])
print(result["valid"], result["trustLevel"])

# Export
bundle = client.export_json(cert["certificateId"])
pdf_bytes = client.export_pdf(cert["certificateId"])
```

## Configuration

| Parameter  | Env var            | Default                   |
| ---------- | ------------------ | ------------------------- |
| `api_key`  | `NEEDINE_API_KEY`  | —                         |
| `base_url` | `NEEDINE_BASE_URL` | `https://api.needine.com` |

## API

| Method                  | Description                      |
| ----------------------- | -------------------------------- |
| `create_certificate()`  | Issue a new certificate          |
| `list_certificates()`   | Paginated list                   |
| `get_certificate(id)`   | Get full certificate details     |
| `verify_certificate(id)`| Cryptographic + trust validation |
| `get_provenance(id)`    | Lineage/provenance tree          |
| `export_json(id)`       | Full verifiable JSON bundle      |
| `export_pdf(id)`        | PDF as bytes                     |
| `verify_anchor(id)`     | Blockchain anchor verification   |
