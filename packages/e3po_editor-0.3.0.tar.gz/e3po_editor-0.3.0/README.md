# e3po

**E3 Python Option** - A terminal-based text editor written in Python, inspired by the E3/E editor.

## Features

- **2D cursor space** - cursor can move anywhere, not bounded by line length
- **Block marking system** - LINE (Alt-L), BLOCK (Alt-B), CHAR (Alt-Z), WORD (Alt-W)
- **Mark operations** - Copy (Alt-C), Move (Alt-M), Delete (Alt-D), Overlay (Alt-O)
- **Undo/Redo** - F9 to undo, Ctrl-Y or Ctrl-R to redo
- **Search & Replace** - `/pattern` to search, `c/old/new/` to replace with Y/N/Q/G prompts
- **Clipboard support** - Paste via terminal, Alt-K to copy to system clipboard
- **Function keys** - F1 Help, F2 Save, F3 Quit, F4 Save+Quit, F7/F8 Shift mark
- **Syntax highlighting** - Optional tree-sitter based highlighting for Python, C, C++ and more

## Requirements

- Python 3.7 or higher
- A terminal with curses support (standard on macOS and Linux)
- No external dependencies for core editor

## Installation

```bash
pip install e3po-editor
```

Or from source:

```bash
git clone https://github.com/BlakeGFitch/e3po.git
cd e3po
pip install -e .
```

## Usage

```bash
# Edit a file
e3po myfile.txt

# Create new file
e3po

# Run as module (alternative)
python -m e3po myfile.txt
```

## Key Bindings

### Function Keys
| Key | Action |
|-----|--------|
| F1 | Help |
| F2 | Save |
| F3 | Quit (no save) |
| F4 | Save and quit |
| F7 | Shift mark left |
| F8 | Shift mark right |
| F9 | Undo |
| F10 | Next file (not yet implemented) |

### Undo/Redo
| Key | Action |
|-----|--------|
| F9 | Undo |
| Ctrl-Y | Redo |
| Ctrl-R | Redo (alternative) |

### Alt Keys (Mark Operations)
| Key | Action |
|-----|--------|
| Alt-L | Mark line(s) |
| Alt-B | Mark block (rectangular) |
| Alt-Z | Mark characters |
| Alt-W | Mark word |
| Alt-U | Unmark |
| Alt-C | Copy block to cursor |
| Alt-M | Move block to cursor |
| Alt-D | Delete marked region |
| Alt-F | Fill marked region with character |
| Alt-O | Overlay block at cursor |
| Alt-K | Copy mark to system clipboard |
| Alt-Y | Go to mark start |
| Alt-E | Go to mark end |
| Alt-S | Split line |
| Alt-J | Join lines |

### Ctrl Keys
| Key | Action |
|-----|--------|
| Ctrl-F | Repeat last search |
| Ctrl-E | Erase to end of line |
| Ctrl-Y | Redo |
| Ctrl-R | Redo |
| Ctrl-Home | Top of file |
| Ctrl-End | End of file |
| Ctrl-Left | Previous word |
| Ctrl-Right | Next word |

### Command Line (press ESC to enter)
| Command | Action |
|---------|--------|
| `123` | Go to line 123 |
| `/pattern` | Search forward |
| `/pattern/c` | Search (case insensitive) |
| `c/old/new/` | Replace (interactive Y/N/Q/G) |
| `c/old/new/*` | Replace all |
| `t` or `top` | Go to top of file |
| `b` or `bot` | Go to bottom of file |
| `s` or `save` | Save file |
| `q` or `quit` | Quit |
| `n filename` | Set filename |
| `e filename` | Edit file |

## Development

### Project Structure

```
e3po/
├── src/e3po/
│   ├── __init__.py
│   ├── editor.py          # Main editor code
│   └── syntax/            # Syntax highlighting
│       ├── highlighter.py
│       └── queries/       # Tree-sitter queries
├── tests/
│   ├── test_buffer.py
│   ├── test_marks.py
│   └── test_undo_redo.py
├── pyproject.toml
├── README.md
└── SPEC.md
```

### Setting Up Development Environment

```bash
git clone https://github.com/bgf/e3po.git
cd e3po
python3 -m venv venv
source venv/bin/activate
pip install -e ".[dev]"
```

### Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_buffer.py -v

# Run with coverage (if installed)
pytest tests/ --cov=e3po
```

### Adding Tests

Tests use pytest and a mock screen object. Example:

```python
from e3po.editor import Buffer, Editor

def test_my_feature():
    editor = make_editor(["line1", "line2"])
    # ... test code ...
    assert editor.buffer.lines == ["expected"]
```

## Syntax Highlighting

e3po supports optional syntax highlighting using tree-sitter.

### Quick Start

```bash
pip install e3po-editor[syntax]
```

### Supported Languages

| Language | Package | File Extensions |
|----------|---------|-----------------|
| Python | tree-sitter-python | .py, .pyw, .pyi |
| C | tree-sitter-c | .c, .h |
| C++ | tree-sitter-cpp | .cpp, .cc, .cxx, .hpp |
| Bash | tree-sitter-bash | .sh, .bash |
| JSON | tree-sitter-json | .json |
| YAML | tree-sitter-yaml | .yaml, .yml |
| JavaScript | tree-sitter-javascript | .js, .mjs |
| Rust | tree-sitter-rust | .rs |
| Go | tree-sitter-go | .go |

### Installing Additional Languages

```bash
pip install tree-sitter-<language>
```

## License

MIT License. Based on the E3/E editor.
