"""Syntax highlighting for E-Py editor."""
from .highlighter import get_highlighter, SyntaxHighlighter

__all__ = ["get_highlighter", "SyntaxHighlighter"]
