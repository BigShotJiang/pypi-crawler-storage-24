#!/usr/bin/env python3
"""
e3po: E3 Python Option - A text editor using curses.
Implements F-keys and block marking operations from E3/e1/e2.
"""

import curses
import curses.ascii
import sys
import os
import base64
import time
import logging
import traceback
from pathlib import Path
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Dict

# Set up logging to file
logging.basicConfig(
    filename='editor.log',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
log = logging.getLogger(__name__)

# Optional syntax highlighting
SYNTAX_AVAILABLE = False
SyntaxHighlighter = None
try:
    # Try relative import first (when installed as package)
    from .syntax.highlighter import get_highlighter, SyntaxHighlighter
    SYNTAX_AVAILABLE = True
except ImportError:
    try:
        # Fall back to absolute import (when run directly)
        from syntax.highlighter import get_highlighter, SyntaxHighlighter
        SYNTAX_AVAILABLE = True
    except ImportError:
        pass


class MarkMode(Enum):
    """Types of text marking."""
    NONE = auto()
    LINE = auto()       # Alt-L: Mark lines
    CHAR = auto()       # Alt-Z: Mark characters
    BLOCK = auto()      # Alt-B: Mark rectangular block


class UndoType(Enum):
    """Types of undo operations."""
    LINE_CHANGE = auto()   # Single line modified
    LINE_INSERT = auto()   # Line(s) inserted
    LINE_DELETE = auto()   # Line(s) deleted
    LINE_SPLIT = auto()    # Line split (Enter key)
    LINE_JOIN = auto()     # Lines joined (Backspace at start)
    BLOCK_CHANGE = auto()  # Block of lines modified


@dataclass
class UndoEntry:
    """Stores information needed to undo an operation."""
    undo_type: UndoType
    line_num: int                    # Starting line number
    col_pos: int                     # Cursor column position
    saved_lines: List[str]           # Saved line contents
    line_count: int = 1              # Number of lines affected


@dataclass
class Mark:
    """Represents a marked region."""
    mode: MarkMode
    start_row: int
    start_col: int
    end_row: Optional[int] = None
    end_col: Optional[int] = None
    pending: bool = True

    @property
    def is_complete(self) -> bool:
        return not self.pending


@dataclass
class Buffer:
    """Text buffer with lines."""
    lines: List[str] = field(default_factory=lambda: [""])
    filename: Optional[str] = None
    modified: bool = False
    undo_stack: List[UndoEntry] = field(default_factory=list)
    redo_stack: List[UndoEntry] = field(default_factory=list)
    max_undo: int = 100  # Maximum undo/redo entries

    def get_line(self, row: int) -> str:
        if 0 <= row < len(self.lines):
            return self.lines[row]
        return ""

    def set_line(self, row: int, text: str) -> None:
        while row >= len(self.lines):
            self.lines.append("")
        self.lines[row] = text
        self.modified = True

    def insert_char(self, row: int, col: int, ch: str) -> None:
        line = self.get_line(row)
        if col > len(line):
            line = line.ljust(col)
        self.set_line(row, line[:col] + ch + line[col:])

    def delete_char(self, row: int, col: int) -> None:
        line = self.get_line(row)
        if col < len(line):
            self.set_line(row, line[:col] + line[col + 1:])

    def backspace(self, row: int, col: int) -> Tuple[int, int]:
        """Delete char before cursor, return new position."""
        if col > 0:
            self.delete_char(row, col - 1)
            return row, col - 1
        elif row > 0:
            # Join with previous line
            prev_line = self.get_line(row - 1)
            curr_line = self.get_line(row)
            new_col = len(prev_line)
            self.set_line(row - 1, prev_line + curr_line)
            del self.lines[row]
            self.modified = True
            return row - 1, new_col
        return row, col

    def split_line(self, row: int, col: int) -> None:
        """Split line at cursor (Enter key)."""
        line = self.get_line(row)
        self.set_line(row, line[:col])
        self.lines.insert(row + 1, line[col:])
        self.modified = True

    def delete_lines(self, start: int, end: int) -> List[str]:
        """Delete lines from start to end inclusive, return deleted."""
        start = max(0, start)
        end = min(end, len(self.lines) - 1)
        deleted = self.lines[start:end + 1]
        del self.lines[start:end + 1]
        if not self.lines:
            self.lines = [""]
        self.modified = True
        return deleted

    def insert_lines(self, row: int, lines: List[str]) -> None:
        """Insert lines at row."""
        for i, line in enumerate(lines):
            self.lines.insert(row + i, line)
        self.modified = True

    def load(self, filename: str) -> bool:
        """Load file into buffer."""
        try:
            path = Path(filename)
            if path.exists():
                content = path.read_text()
                self.lines = content.split('\n')
                if not self.lines:
                    self.lines = [""]
            else:
                self.lines = [""]
            self.filename = filename
            self.modified = False
            self.undo_stack.clear()  # Clear undo/redo history on load
            self.redo_stack.clear()
            return True
        except Exception:
            return False

    def save(self, filename: Optional[str] = None) -> bool:
        """Save buffer to file."""
        fname = filename or self.filename
        if not fname:
            return False
        try:
            Path(fname).write_text('\n'.join(self.lines))
            self.filename = fname
            self.modified = False
            return True
        except Exception:
            return False

    def push_undo(self, undo_type: UndoType, line_num: int, col_pos: int,
                  start_line: int, end_line: int) -> None:
        """Save lines for undo before modifying them."""
        log.debug(f"push_undo: type={undo_type}, line={line_num}, col={col_pos}, "
                  f"range={start_line}-{end_line}, buffer_lines={len(self.lines)}")
        # Clear redo stack on new edit
        self.redo_stack.clear()

        # Ensure valid range
        start_line = max(0, start_line)
        end_line = min(end_line, len(self.lines) - 1) if end_line is not None else start_line
        if end_line < start_line:
            end_line = start_line

        # Save the lines
        saved = [self.lines[i] if i < len(self.lines) else ""
                 for i in range(start_line, end_line + 1)]

        entry = UndoEntry(
            undo_type=undo_type,
            line_num=line_num,
            col_pos=col_pos,
            saved_lines=saved,
            line_count=end_line - start_line + 1
        )
        self.undo_stack.append(entry)

        # Limit stack size
        if len(self.undo_stack) > self.max_undo:
            self.undo_stack.pop(0)

    def pop_undo(self) -> Optional[UndoEntry]:
        """Pop and return the most recent undo entry."""
        if self.undo_stack:
            return self.undo_stack.pop()
        return None

    def clear_undo(self) -> None:
        """Clear the undo and redo stacks."""
        self.undo_stack.clear()
        self.redo_stack.clear()


class Editor:
    """Main editor class."""

    def __init__(self, filename: Optional[str] = None):
        self.buffer = Buffer()
        self.cursor_row = 0
        self.cursor_col = 0
        self.top_row = 0  # First visible row
        self.left_col = 0  # First visible column
        self.mark: Optional[Mark] = None
        self.message = ""
        self.running = True
        self.screen = None
        self.height = 24
        self.width = 80
        self.edit_height = 20  # Lines for editing area

        # Search state
        self.search_term: Optional[str] = None
        self.search_case_ignore = False

        # Fill mark state (Alt-F waits for fill character)
        self.fill_pending = False

        # Syntax highlighting (can disable with EPYNO_SYNTAX=1 env var)
        self.highlighter: Optional[SyntaxHighlighter] = None
        self.syntax_lang: Optional[str] = None
        self.syntax_last_hash: Optional[int] = None  # Hash of last parsed content

        if SYNTAX_AVAILABLE and not os.environ.get('EPY_NO_SYNTAX'):
            self.highlighter = get_highlighter()

        if filename:
            self.buffer.load(filename)
            self._init_syntax()

    def run(self, screen) -> None:
        """Main loop."""
        self.screen = screen
        curses.start_color()
        curses.use_default_colors()

        # Color pairs
        curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_CYAN)    # F-key bar, status
        curses.init_pair(2, curses.COLOR_BLACK, curses.COLOR_YELLOW)  # Marked text
        curses.init_pair(3, curses.COLOR_WHITE, curses.COLOR_BLUE)    # Help/prompts
        curses.init_pair(4, curses.COLOR_YELLOW, curses.COLOR_BLACK)  # Command line hint
        try:
            curses.init_pair(5, curses.COLOR_WHITE, 238)  # Command line active (grey bg)
        except:
            curses.init_pair(5, curses.COLOR_BLACK, curses.COLOR_WHITE)  # Fallback

        # Syntax highlighting color pairs (10+)
        try:
            curses.init_pair(10, curses.COLOR_BLUE, -1)     # keyword
            curses.init_pair(11, curses.COLOR_GREEN, -1)    # string
            curses.init_pair(12, 245, -1)                   # comment (gray)
            curses.init_pair(13, curses.COLOR_YELLOW, -1)   # function
            curses.init_pair(14, curses.COLOR_CYAN, -1)     # type
            curses.init_pair(15, curses.COLOR_MAGENTA, -1)  # number
            curses.init_pair(16, curses.COLOR_RED, -1)      # constant
        except:
            # Fallback for terminals without 256 colors or default bg support
            curses.init_pair(10, curses.COLOR_BLUE, curses.COLOR_BLACK)
            curses.init_pair(11, curses.COLOR_GREEN, curses.COLOR_BLACK)
            curses.init_pair(12, curses.COLOR_WHITE, curses.COLOR_BLACK)
            curses.init_pair(13, curses.COLOR_YELLOW, curses.COLOR_BLACK)
            curses.init_pair(14, curses.COLOR_CYAN, curses.COLOR_BLACK)
            curses.init_pair(15, curses.COLOR_MAGENTA, curses.COLOR_BLACK)
            curses.init_pair(16, curses.COLOR_RED, curses.COLOR_BLACK)

        curses.curs_set(1)  # Show cursor
        screen.keypad(True)
        screen.timeout(-1)  # Blocking input

        # Reduce ESC delay (default can be 1000ms!)
        try:
            curses.set_escdelay(25)  # 25ms is plenty
        except AttributeError:
            pass  # Not available on all systems

        # Enable bracketed paste mode (works on most modern terminals)
        sys.stdout.write('\033[?2004h')
        sys.stdout.flush()

        self.height, self.width = screen.getmaxyx()
        # Layout: F-keys (1) + edit area + status (1) + command (1)
        self.edit_height = self.height - 3

        self.command_mode = False  # True when typing in command line
        self.command_buffer = ""

        try:
            while self.running:
                try:
                    self.draw()
                    self.handle_input()
                except Exception as e:
                    log.error(f"Error in main loop: {e}")
                    log.error(traceback.format_exc())
                    raise
        finally:
            # Disable bracketed paste mode on exit
            sys.stdout.write('\033[?2004l')
            sys.stdout.flush()

    def _init_syntax(self) -> None:
        """Initialize syntax highlighting for the current file."""
        if not self.highlighter or not self.buffer.filename:
            return

        lang = self.highlighter.detect_language(self.buffer.filename)
        if not lang:
            return

        if self.highlighter.is_available(lang):
            if self.highlighter.load_language(lang):
                self.syntax_lang = lang
                self.syntax_dirty = True
        # Could offer to download if not available

    def _update_syntax(self) -> None:
        """Re-parse the buffer for syntax highlighting."""
        if not self.highlighter or not self.syntax_lang:
            return

        # Check if buffer content changed since last parse
        source = '\n'.join(self.buffer.lines)
        source_hash = hash(source)

        if source_hash == self.syntax_last_hash:
            return  # No changes

        # Check for large file mode
        self.highlighter.set_large_file_mode(len(self.buffer.lines))

        # Parse the buffer
        self.highlighter.parse(source, self.syntax_lang)
        self.syntax_last_hash = source_hash

    def _get_syntax_color(self, highlight_group: int) -> int:
        """Map highlighter color index to curses color pair."""
        # Map from highlighter HIGHLIGHT_GROUPS values to our color pairs
        # highlighter: 1=keyword, 2=string, 3=comment, 4=function, 5=type, 6=number, 9=constant
        # our pairs:  10=keyword, 11=string, 12=comment, 13=function, 14=type, 15=number, 16=constant
        if highlight_group == 1:  # keyword
            return 10
        elif highlight_group == 2:  # string
            return 11
        elif highlight_group == 3:  # comment
            return 12
        elif highlight_group == 4:  # function
            return 13
        elif highlight_group == 5:  # type
            return 14
        elif highlight_group == 6:  # number
            return 15
        elif highlight_group == 9:  # constant
            return 16
        return 0  # default

    def draw(self) -> None:
        """Draw the screen."""
        self.screen.clear()

        # Update syntax highlighting if needed
        try:
            self._update_syntax()
        except:
            pass  # Ignore syntax errors

        # Row 0: F-key bar at top
        self.draw_fkey_bar()

        # Rows 1 to edit_height: Edit area
        for screen_row in range(self.edit_height):
            buf_row = self.top_row + screen_row
            draw_row = screen_row + 1  # Offset by 1 for F-key bar
            if buf_row < len(self.buffer.lines):
                line = self.buffer.lines[buf_row]
                # Pad line to show cursor position if beyond line end
                display_width = max(len(line), self.cursor_col + 1 if buf_row == self.cursor_row else 0)
                padded_line = line.ljust(display_width)
                # Handle horizontal scroll
                visible_line = padded_line[self.left_col:self.left_col + self.width]

                # Draw with highlighting for marked regions
                self.draw_line(draw_row, buf_row, visible_line)
            else:
                self.safe_addstr(draw_row, 0, "~")

        # Second to last row: Status bar
        self.draw_status_bar()

        # Last row: Command line
        self.draw_command_line()

        # Position cursor
        if self.command_mode:
            # Cursor in command line
            cmd_row = self.height - 1
            self.screen.move(cmd_row, len(self.command_buffer))
        else:
            # Cursor in edit area
            cursor_screen_row = self.cursor_row - self.top_row + 1  # +1 for F-key bar
            cursor_screen_col = self.cursor_col - self.left_col
            if 0 <= cursor_screen_row <= self.edit_height and 0 <= cursor_screen_col < self.width:
                self.screen.move(cursor_screen_row, cursor_screen_col)

        self.screen.refresh()

    def draw_line(self, screen_row: int, buf_row: int, visible_line: str) -> None:
        """Draw a line with mark and syntax highlighting."""
        # Get mark highlighting
        marked_cols = self.get_marked_cols(buf_row) if self.mark else set()

        # Get syntax highlighting for this line
        syntax_colors: Dict[int, int] = {}  # col -> color_pair
        if self.highlighter and self.syntax_lang:
            try:
                line_text = self.buffer.get_line(buf_row)
                highlights = self.highlighter.get_highlights(buf_row, buf_row, [line_text])
                if buf_row in highlights:
                    for start_col, end_col, color_idx in highlights[buf_row]:
                        color_pair = self._get_syntax_color(color_idx)
                        if color_pair:
                            for c in range(start_col, end_col):
                                syntax_colors[c] = color_pair
            except:
                pass  # Ignore syntax highlighting errors

        # No highlighting at all - fast path
        if not marked_cols and not syntax_colors:
            self.safe_addstr(screen_row, 0, visible_line)
            return

        # For LINE marks, extend visible_line to full screen width
        if self.mark and self.mark.mode == MarkMode.LINE and self.is_row_in_mark(buf_row):
            visible_line = visible_line.ljust(self.width)

        # Draw character by character with highlighting
        for screen_col in range(min(len(visible_line), self.width)):
            ch = visible_line[screen_col] if screen_col < len(visible_line) else ' '
            buf_col = self.left_col + screen_col

            if buf_col in marked_cols:
                # Mark highlighting takes priority
                self.safe_addstr(screen_row, screen_col, ch, curses.color_pair(2))
            elif buf_col in syntax_colors:
                # Syntax highlighting
                self.safe_addstr(screen_row, screen_col, ch, curses.color_pair(syntax_colors[buf_col]))
            else:
                self.safe_addstr(screen_row, screen_col, ch)

    def get_marked_cols(self, buf_row: int) -> set:
        """Get set of column indices that are marked on this row."""
        if not self.mark:
            return set()

        # Get mark boundaries
        start_row = self.mark.start_row
        end_row = self.mark.end_row if self.mark.end_row is not None else start_row
        start_col = self.mark.start_col
        end_col = self.mark.end_col if self.mark.end_col is not None else start_col

        # Normalize order
        if start_row > end_row or (start_row == end_row and start_col > end_col):
            start_row, end_row = end_row, start_row
            start_col, end_col = end_col, start_col

        if buf_row < start_row or buf_row > end_row:
            return set()

        line_len = len(self.buffer.get_line(buf_row))
        # For display, extend to cursor column if beyond line end
        display_len = max(line_len, self.cursor_col + 1 if buf_row == self.cursor_row else line_len)

        if self.mark.mode == MarkMode.LINE:
            # Entire line is marked - full screen width (2D space)
            return set(range(self.left_col + self.width + 1))

        elif self.mark.mode == MarkMode.CHAR:
            # Character range
            if start_row == end_row:
                # Single line
                if buf_row == start_row:
                    return set(range(start_col, end_col + 1))
            else:
                # Multiple lines
                if buf_row == start_row:
                    return set(range(start_col, max(display_len, end_col) + 1))
                elif buf_row == end_row:
                    return set(range(0, end_col + 1))
                else:
                    return set(range(display_len + 1))

        elif self.mark.mode == MarkMode.BLOCK:
            # Rectangular block - always show full block width
            col_start = min(start_col, end_col if end_col is not None else start_col)
            col_end = max(start_col, end_col if end_col is not None else start_col)
            return set(range(col_start, col_end + 1))

        return set()

    def is_row_in_mark(self, buf_row: int) -> bool:
        """Check if a buffer row is within the mark range."""
        if not self.mark:
            return False
        start_row = min(self.mark.start_row, self.mark.end_row)
        end_row = max(self.mark.start_row, self.mark.end_row)
        return start_row <= buf_row <= end_row

    def safe_addstr(self, row: int, col: int, text: str, attr: int = 0) -> None:
        """Safely add string, handling edge cases."""
        try:
            if 0 <= row < self.height and 0 <= col < self.width:
                max_len = self.width - col
                self.screen.addstr(row, col, text[:max_len], attr)
        except curses.error:
            pass  # Ignore errors at screen edges

    def draw_fkey_bar(self) -> None:
        """Draw F-key bar at top of screen."""
        fkeys = "F1:Help F2:Save F3:Quit F4:Save&Quit F9:Undo F10:Next | ESC:Command"
        fkeys = fkeys.ljust(self.width)[:self.width]
        self.safe_addstr(0, 0, fkeys, curses.color_pair(1))

    def draw_status_bar(self) -> None:
        """Draw status bar (second to last row)."""
        row = self.height - 2

        # Build status string
        fname = self.buffer.filename or "[No Name]"
        mod = "*" if self.buffer.modified else " "
        mark_str = "---"
        if self.mark:
            mark_str = self.mark.mode.name

        # Show message if present, otherwise show file info
        if self.message:
            status = f" {self.message}"
        else:
            status = f" {fname}{mod} | Line: {self.cursor_row + 1} Col: {self.cursor_col + 1} | Mark: {mark_str}"

        status = status.ljust(self.width)[:self.width]
        self.safe_addstr(row, 0, status, curses.color_pair(1))

    def draw_command_line(self) -> None:
        """Draw command line at bottom."""
        row = self.height - 1
        if self.command_mode:
            # Show command buffer with grey background (no colon prefix)
            cmd_display = self.command_buffer.ljust(self.width)[:self.width]
            try:
                self.safe_addstr(row, 0, cmd_display, curses.color_pair(5) | curses.A_BOLD)
            except:
                # Fallback if color 238 not supported
                self.safe_addstr(row, 0, cmd_display, curses.A_REVERSE)
        else:
            # Show hint
            hint = "ESC: command | /search | c/old/new/ | line#"
            hint = hint.ljust(self.width)[:self.width]
            self.safe_addstr(row, 0, hint, curses.A_DIM)

    def handle_input(self) -> None:
        """Handle keyboard input."""
        try:
            ch = self.screen.getch()
        except KeyboardInterrupt:
            self.running = False
            return

        log.debug(f"Key input: {ch} (0x{ch:x})")
        self.message = ""  # Clear message on new input

        # Command mode handling
        if self.command_mode:
            self.handle_command_input(ch)
            return

        # Fill pending - waiting for fill character
        if self.fill_pending:
            self.fill_pending = False
            if 32 <= ch < 127:
                self.do_fill_mark(chr(ch))
            else:
                self.message = "Fill cancelled"
            return

        # Check for ESC (Alt key prefix in terminal, or enter command mode)
        if ch == 27:  # ESC
            # Use nodelay + minimal sleep for fast ESC detection
            self.screen.nodelay(True)
            time.sleep(0.005)  # 5ms - escape sequences arrive almost instantly
            next_ch = self.screen.getch()
            self.screen.nodelay(False)

            if next_ch == -1 or next_ch == curses.ERR:
                # Plain ESC - enter command mode
                self.command_mode = True
                self.command_buffer = ""
            elif next_ch == ord('['):
                # Could be bracketed paste or other escape sequence
                self.handle_escape_sequence()
            else:
                # Alt+key
                self.handle_alt_key(next_ch)
            return

        # Function keys
        if curses.KEY_F1 <= ch <= curses.KEY_F12:
            self.handle_function_key(ch)

        # Cursor movement
        elif ch == curses.KEY_UP:
            self.move_cursor(-1, 0)
        elif ch == curses.KEY_DOWN:
            self.move_cursor(1, 0)
        elif ch == curses.KEY_LEFT:
            self.move_cursor(0, -1)
        elif ch == curses.KEY_RIGHT:
            self.move_cursor(0, 1)
        elif ch == curses.KEY_HOME:
            self.cursor_col = 0
        elif ch == curses.KEY_END:
            self.cursor_col = len(self.buffer.get_line(self.cursor_row))
        elif ch == curses.KEY_PPAGE:  # Page Up
            self.move_cursor(-self.edit_height, 0)
        elif ch == curses.KEY_NPAGE:  # Page Down
            self.move_cursor(self.edit_height, 0)

        # Ctrl-Home: Top of file
        elif ch == 535 or ch == curses.KEY_HOME + 0x200:
            self.cursor_row = 0
            self.cursor_col = 0
        # Ctrl-End: Bottom of file
        elif ch == 530 or ch == curses.KEY_END + 0x200:
            self.cursor_row = len(self.buffer.lines) - 1
            self.cursor_col = len(self.buffer.get_line(self.cursor_row))
        # Ctrl-Left: Beginning of word to left
        elif ch == 545 or ch == curses.KEY_LEFT + 0x200:
            self.cursor_to_word_start()
        # Ctrl-Right: Beginning of word to right
        elif ch == 560 or ch == curses.KEY_RIGHT + 0x200:
            self.cursor_to_word_end()
        # Ctrl-PgUp: Top of screen
        elif ch == 555 or ch == curses.KEY_PPAGE + 0x200:
            self.cursor_row = self.top_row
        # Ctrl-PgDn: Bottom of screen
        elif ch == 550 or ch == curses.KEY_NPAGE + 0x200:
            self.cursor_row = min(self.top_row + self.edit_height - 1, len(self.buffer.lines) - 1)
        # Ctrl-Enter: Column 1 of next line
        elif ch == 529 or ch == 10 + 0x200:
            self.cursor_row = min(self.cursor_row + 1, len(self.buffer.lines) - 1)
            self.cursor_col = 0

        # Editing
        elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
            if self.cursor_col > 0:
                # Deleting char on same line
                self.buffer.push_undo(UndoType.LINE_CHANGE, self.cursor_row,
                                      self.cursor_col, self.cursor_row, self.cursor_row)
            elif self.cursor_row > 0:
                # Joining with previous line
                self.buffer.push_undo(UndoType.LINE_JOIN, self.cursor_row - 1,
                                      len(self.buffer.get_line(self.cursor_row - 1)),
                                      self.cursor_row - 1, self.cursor_row)
            self.cursor_row, self.cursor_col = self.buffer.backspace(
                self.cursor_row, self.cursor_col
            )
        elif ch == curses.KEY_DC:  # Delete
            self.buffer.push_undo(UndoType.LINE_CHANGE, self.cursor_row,
                                  self.cursor_col, self.cursor_row, self.cursor_row)
            self.buffer.delete_char(self.cursor_row, self.cursor_col)
        elif ch == curses.KEY_ENTER or ch == 10 or ch == 13:
            self.buffer.push_undo(UndoType.LINE_SPLIT, self.cursor_row,
                                  self.cursor_col, self.cursor_row, self.cursor_row)
            self.buffer.split_line(self.cursor_row, self.cursor_col)
            self.cursor_row += 1
            self.cursor_col = 0
        elif ch == 9:  # Tab
            self.buffer.push_undo(UndoType.LINE_CHANGE, self.cursor_row,
                                  self.cursor_col, self.cursor_row, self.cursor_row)
            self.buffer.insert_char(self.cursor_row, self.cursor_col, "    ")
            self.cursor_col += 4

        # Ctrl-F: Repeat last search
        elif ch == 6:  # Ctrl-F
            self.action_repeat_search()

        # Ctrl-E: Erase to end of line
        elif ch == 5:  # Ctrl-E
            self.buffer.push_undo(UndoType.LINE_CHANGE, self.cursor_row,
                                  self.cursor_col, self.cursor_row, self.cursor_row)
            line = self.buffer.get_line(self.cursor_row)
            self.buffer.set_line(self.cursor_row, line[:self.cursor_col])
            self.message = "Erased to end of line"

        # Ctrl-Y or Ctrl-R: Redo
        elif ch == 25 or ch == 18:  # Ctrl-Y or Ctrl-R
            self.action_redo()

        # Note: Ctrl-Z is NOT mapped - it sends SIGTSTP (suspend) in terminals

        # Printable characters
        elif 32 <= ch < 127:
            self.buffer.push_undo(UndoType.LINE_CHANGE, self.cursor_row,
                                  self.cursor_col, self.cursor_row, self.cursor_row)
            self.buffer.insert_char(self.cursor_row, self.cursor_col, chr(ch))
            self.cursor_col += 1

        # Unknown key - show code for debugging
        elif ch > 0:
            self.message = f"Key code: {ch} (0x{ch:x})"

        # Ensure cursor is visible
        self.scroll_to_cursor()

    def handle_function_key(self, ch: int) -> None:
        """Handle function keys F1-F12."""
        if ch == curses.KEY_F1:
            self.show_help()
        elif ch == curses.KEY_F2:
            self.action_save()
        elif ch == curses.KEY_F3:
            self.action_quit()
        elif ch == curses.KEY_F4:
            self.action_save_and_quit()
        elif ch == curses.KEY_F5:
            pass  # Not implemented
        elif ch == curses.KEY_F6:
            pass  # Draw options - not implemented
        elif ch == curses.KEY_F7:
            self.action_shift_mark_left()
        elif ch == curses.KEY_F8:
            self.action_shift_mark_right()
        elif ch == curses.KEY_F9:
            self.action_undo()
        elif ch == curses.KEY_F10:
            self.message = "File ring not yet implemented"
        elif ch == curses.KEY_F11:
            pass  # Not implemented
        elif ch == curses.KEY_F12:
            pass  # Not implemented

    def handle_command_input(self, ch: int) -> None:
        """Handle input while in command mode."""
        if ch == 27:  # ESC - cancel command mode
            self.command_mode = False
            self.command_buffer = ""
        # Function keys work in command mode - exit and handle normally
        elif curses.KEY_F1 <= ch <= curses.KEY_F12:
            self.command_mode = False
            self.command_buffer = ""
            self.handle_function_key(ch)
        elif ch == curses.KEY_ENTER or ch == 10 or ch == 13:
            # Execute command
            self.execute_command(self.command_buffer)
            self.command_mode = False
            self.command_buffer = ""
        elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
            if self.command_buffer:
                self.command_buffer = self.command_buffer[:-1]
            else:
                self.command_mode = False
        elif 32 <= ch < 127:
            self.command_buffer += chr(ch)

    def execute_command(self, cmd: str) -> None:
        """Execute a command line command."""
        cmd = cmd.strip()
        if not cmd:
            return

        # Line number - go to line
        if cmd.isdigit():
            line_num = int(cmd)
            if 1 <= line_num <= len(self.buffer.lines):
                self.cursor_row = line_num - 1
                self.cursor_col = 0
                self.scroll_to_cursor()
                self.message = f"Line {line_num}"
            else:
                self.message = f"Line {line_num} out of range"
            return

        # Search: /pattern or /pattern/ or /pattern/c (case insensitive)
        if cmd.startswith('/'):
            self._parse_and_search(cmd[1:])
            return

        # Change: C/old/new/ or C /old/new/
        if cmd.upper().startswith('C/') or cmd.upper().startswith('C /'):
            self.do_change_command(cmd)
            return

        # File commands
        cmd_upper = cmd.upper()
        if cmd_upper in ('Q', 'QUIT'):
            self.action_quit()
        elif cmd_upper in ('F', 'FILE'):
            self.action_save_and_quit()
        elif cmd_upper in ('S', 'SAVE'):
            self.action_save()
        elif cmd_upper.startswith('E ') or cmd_upper.startswith('EDIT '):
            filename = cmd.split(None, 1)[1] if ' ' in cmd else None
            if filename:
                self.buffer.load(filename)
                self.cursor_row = 0
                self.cursor_col = 0
                self.message = f"Loaded {filename}"
        elif cmd_upper.startswith('N ') or cmd_upper.startswith('NAME '):
            filename = cmd.split(None, 1)[1] if ' ' in cmd else None
            if filename:
                self.buffer.filename = filename
                self.message = f"Filename set to {filename}"
        # Navigation commands
        elif cmd_upper in ('T', 'TOP'):
            self.cursor_row = 0
            self.cursor_col = 0
            self.message = "Top of file"
        elif cmd_upper in ('B', 'BOT', 'BOTTOM'):
            self.cursor_row = len(self.buffer.lines) - 1
            self.cursor_col = 0
            self.message = "Bottom of file"
        else:
            self.message = f"Unknown command: {cmd}"

    def search_forward(self, pattern: str, case_ignore: bool = False) -> bool:
        """Search forward for pattern starting from cursor+1. Returns True if found."""
        if not pattern:
            self.message = "No search pattern"
            return False

        # Store for Ctrl-F repeat
        self.search_term = pattern
        self.search_case_ignore = case_ignore

        return self._do_search()

    def _do_search(self) -> bool:
        """Execute search using stored search_term. Returns True if found."""
        if not self.search_term:
            self.message = "No search in progress"
            return False

        pattern = self.search_term
        # Start searching from current position +1 (so we don't get stuck)
        start_row = self.cursor_row
        start_col = self.cursor_col + 1

        # Prepare for case-insensitive search
        if self.search_case_ignore:
            search_pattern = pattern.lower()
        else:
            search_pattern = pattern

        for row in range(start_row, len(self.buffer.lines)):
            line = self.buffer.get_line(row)
            search_line = line.lower() if self.search_case_ignore else line
            col = start_col if row == start_row else 0
            pos = search_line.find(search_pattern, col)
            if pos != -1:
                self.cursor_row = row
                self.cursor_col = pos
                self.scroll_to_cursor()
                self.message = f"Found: {pattern}"
                return True

        # Wrap around from beginning
        for row in range(0, start_row + 1):
            line = self.buffer.get_line(row)
            search_line = line.lower() if self.search_case_ignore else line
            end_col = start_col if row == start_row else len(line)
            pos = search_line.find(search_pattern)
            if pos != -1 and (row < start_row or pos < start_col):
                self.cursor_row = row
                self.cursor_col = pos
                self.scroll_to_cursor()
                self.message = f"Found (wrapped): {pattern}"
                return True

        self.message = f"Not found: {pattern}"
        return False

    def action_repeat_search(self) -> None:
        """Repeat last search (Ctrl-F)."""
        if not self.search_term:
            self.message = "No search in progress"
            return
        self._do_search()

    def _parse_and_search(self, s: str) -> None:
        """Parse search string: pattern or pattern/ or pattern/c"""
        case_ignore = False

        # Check for trailing /c or /C (case insensitive)
        if len(s) >= 2 and s[-1].lower() == 'c' and s[-2] == '/':
            case_ignore = True
            s = s[:-2]
        # Strip trailing slash
        elif s.endswith('/'):
            s = s[:-1]

        if not s:
            self.message = "Search string cleared"
            self.search_term = None
            return

        self.message = f"Search: \"{s}\""
        self.search_forward(s, case_ignore)

    def do_change_command(self, cmd: str) -> None:
        """Execute change (search & replace) command: c/old/new/[flags]"""
        # Find the delimiter (first char after 'c')
        if len(cmd) < 2:
            self.message = "Usage: c/old/new/[*mc]"
            return

        # Skip the 'c' or 'C'
        rest = cmd[1:]
        if not rest:
            self.message = "Usage: c/old/new/[*mc]"
            return

        delim = rest[0]
        parts = rest[1:].split(delim)

        if len(parts) < 2:
            self.message = "Usage: c/old/new/[*mc]"
            return

        old = parts[0]
        new = parts[1]
        flags = parts[2].lower() if len(parts) > 2 else ""

        if not old:
            self.message = "Can't change nothing to something"
            return

        # Parse flags
        do_all = '*' in flags
        do_mark = 'm' in flags
        case_ignore = 'c' in flags

        # Store search term for Ctrl-F
        self.search_term = old
        self.search_case_ignore = case_ignore

        # Save current mark
        saved_mark = self.mark

        # Determine search range
        if do_mark and saved_mark:
            start_row = saved_mark.start_row
            end_row = saved_mark.end_row + 1
        else:
            start_row = self.cursor_row
            end_row = len(self.buffer.lines)

        replaced_count = 0
        found_count = 0
        finished = False
        row = start_row
        col = self.cursor_col
        last_change_row = self.cursor_row
        last_change_col = self.cursor_col

        while not finished and row < end_row:
            line = self.buffer.get_line(row)

            # Find occurrence
            if case_ignore:
                search_line = line.lower()
                search_old = old.lower()
            else:
                search_line = line
                search_old = old

            pos = search_line.find(search_old, col)

            if pos == -1:
                # Move to next line
                row += 1
                col = 0
                continue

            found_count += 1

            # Move cursor to found position
            self.cursor_row = row
            self.cursor_col = pos
            self.scroll_to_cursor()

            if do_all:
                # Replace without asking
                self.buffer.push_undo(UndoType.LINE_CHANGE, row, pos, row, row)
                line = line[:pos] + new + line[pos + len(old):]
                self.buffer.set_line(row, line)
                replaced_count += 1
                # Update cursor to end of replacement
                self.cursor_col = pos + len(new)
                last_change_row = row
                last_change_col = pos
                col = pos + len(new)
                # Redraw to show progress
                self.message = f"Changing... ({replaced_count} so far)"
                self.draw()
                self.screen.refresh()
            else:
                # Interactive mode - highlight and ask
                # Create temporary block mark on the found text
                self.mark = Mark(
                    mode=MarkMode.BLOCK,
                    start_row=row,
                    start_col=pos,
                    end_row=row,
                    end_col=pos + len(old) - 1,
                    pending=False
                )

                # Show prompt and redraw
                self.message = f"Change \"{old}\" to \"{new}\"? (Y/N/Q/G)"
                self.draw()
                self.screen.refresh()

                # Wait for y/n/q/g
                while True:
                    ch = self.screen.getch()
                    if ch in (ord('y'), ord('Y')):
                        # Replace this one
                        self.buffer.push_undo(UndoType.LINE_CHANGE, row, pos, row, row)
                        line = line[:pos] + new + line[pos + len(old):]
                        self.buffer.set_line(row, line)
                        replaced_count += 1
                        self.cursor_col = pos
                        last_change_row = row
                        last_change_col = pos
                        col = pos + len(new)
                        break
                    elif ch in (ord('n'), ord('N')):
                        # Skip this one
                        col = pos + len(old)
                        break
                    elif ch in (ord('q'), ord('Q'), 27):  # Q or ESC
                        # Quit
                        finished = True
                        break
                    elif ch in (ord('g'), ord('G')):
                        # Go - do this one and all remaining
                        self.buffer.push_undo(UndoType.LINE_CHANGE, row, pos, row, row)
                        line = line[:pos] + new + line[pos + len(old):]
                        self.buffer.set_line(row, line)
                        replaced_count += 1
                        self.cursor_col = pos
                        last_change_row = row
                        last_change_col = pos
                        col = pos + len(new)
                        do_all = True
                        break
                    else:
                        # Invalid key - beep
                        curses.beep()

        # Restore mark
        self.mark = saved_mark

        # Leave cursor at last change position
        if replaced_count > 0:
            self.cursor_row = last_change_row
            self.cursor_col = last_change_col
            self.scroll_to_cursor()

        if replaced_count > 0:
            self.message = f"Changed {replaced_count} of {found_count} occurrence(s)"
        else:
            self.message = f"Not found: {old}"

    def handle_escape_sequence(self) -> None:
        """Handle escape sequences starting with ESC [."""
        # Read more characters to determine sequence type
        self.screen.nodelay(True)
        time.sleep(0.005)  # Brief wait for rest of sequence
        seq = ""
        while True:
            ch = self.screen.getch()
            if ch == -1:
                break
            seq += chr(ch)
            # Check for bracketed paste start: "200~"
            if seq == "200~":
                self.screen.nodelay(False)
                self.handle_bracketed_paste()
                return
            # Don't read forever
            if len(seq) > 10:
                break
        self.screen.nodelay(False)
        # Unknown escape sequence - ignore

    def handle_bracketed_paste(self) -> None:
        """Handle bracketed paste - collect text until end sequence."""
        paste_text = ""
        end_seq = "\033[201~"
        buffer = ""

        while True:
            ch = self.screen.getch()
            if ch == -1:
                continue
            if ch == 27:  # ESC - might be start of end sequence
                buffer = chr(ch)
            elif buffer:
                buffer += chr(ch)
                if buffer == end_seq:
                    # End of paste
                    break
                elif not end_seq.startswith(buffer):
                    # Not end sequence, add to paste text
                    paste_text += buffer
                    buffer = ""
            else:
                paste_text += chr(ch)

        # Insert pasted text at cursor
        if paste_text:
            self.insert_pasted_text(paste_text)

    def insert_pasted_text(self, text: str) -> None:
        """Insert pasted text at cursor position."""
        lines = text.split('\n')

        if len(lines) == 1:
            # Single line paste - insert at cursor
            self.buffer.push_undo(UndoType.LINE_CHANGE, self.cursor_row,
                                  self.cursor_col, self.cursor_row, self.cursor_row)
            line = self.buffer.get_line(self.cursor_row)
            if len(line) < self.cursor_col:
                line = line.ljust(self.cursor_col)
            new_line = line[:self.cursor_col] + lines[0] + line[self.cursor_col:]
            self.buffer.set_line(self.cursor_row, new_line)
            self.cursor_col += len(lines[0])
        else:
            # Multi-line paste - save current line for undo
            self.buffer.push_undo(UndoType.LINE_CHANGE, self.cursor_row,
                                  self.cursor_col, self.cursor_row, self.cursor_row)
            first_line = self.buffer.get_line(self.cursor_row)
            if len(first_line) < self.cursor_col:
                first_line = first_line.ljust(self.cursor_col)
            before = first_line[:self.cursor_col]
            after = first_line[self.cursor_col:]

            # First line: before + first pasted line
            self.buffer.set_line(self.cursor_row, before + lines[0])

            # Middle lines: insert as new lines
            for i, pasted_line in enumerate(lines[1:-1], 1):
                self.buffer.lines.insert(self.cursor_row + i, pasted_line)

            # Last line: last pasted line + after
            last_idx = self.cursor_row + len(lines) - 1
            self.buffer.lines.insert(last_idx, lines[-1] + after)

            # Move cursor to end of pasted text
            self.cursor_row = last_idx
            self.cursor_col = len(lines[-1])

        self.buffer.modified = True
        self.message = f"Pasted {len(lines)} line(s)"

    def handle_alt_key(self, ch: int) -> None:
        """Handle Alt+key combinations."""
        key = chr(ch).lower() if 32 <= ch < 127 else ""

        if key == 'l':
            self.action_mark_line()
        elif key == 'z':
            self.action_mark_char()
        elif key == 'b':
            self.action_mark_block()
        elif key == 'w':
            self.action_mark_word()
        elif key == 'u':
            self.action_unmark()
        elif key == 'c':
            self.action_copy()
        elif key == 'm':
            self.action_move()
        elif key == 'd':
            self.action_delete()
        elif key == 'y':
            self.action_goto_mark_start()
        elif key == 'e':
            self.action_goto_mark_end()
        elif key == 'o':
            self.action_overlay()
        elif key == 'v':
            self.message = "Alt-V not used in E3"
        elif key == 'f':
            self.action_fill_mark()
        elif key == 'k':
            self.action_copy_to_clipboard()
        elif key == 's':
            self.action_split_line()
        elif key == 'j':
            self.action_join_line()
        else:
            self.message = f"Unknown Alt-{key.upper()}"

    def move_cursor(self, row_delta: int, col_delta: int) -> None:
        """Move cursor by delta. Cursor can move anywhere in 2D space."""
        self.cursor_row = max(0, min(self.cursor_row + row_delta, len(self.buffer.lines) - 1))
        # Column is NOT bounded by line length - can move past end of line
        self.cursor_col = max(0, self.cursor_col + col_delta)

    def cursor_to_word_start(self) -> None:
        """Move cursor to beginning of word to the left (Ctrl-Left)."""
        line = self.buffer.get_line(self.cursor_row)
        col = self.cursor_col

        # If at start of line, go to end of previous line
        if col == 0:
            if self.cursor_row > 0:
                self.cursor_row -= 1
                self.cursor_col = len(self.buffer.get_line(self.cursor_row))
            return

        # Move left, skipping any spaces
        col -= 1
        while col > 0 and (col >= len(line) or not line[col].isalnum()):
            col -= 1

        # Move to start of word
        while col > 0 and col <= len(line) and line[col - 1].isalnum():
            col -= 1

        self.cursor_col = col

    def cursor_to_word_end(self) -> None:
        """Move cursor to beginning of next word (Ctrl-Right)."""
        line = self.buffer.get_line(self.cursor_row)
        col = self.cursor_col
        line_len = len(line)

        # If at or past end of line, go to start of next line
        if col >= line_len:
            if self.cursor_row < len(self.buffer.lines) - 1:
                self.cursor_row += 1
                self.cursor_col = 0
            return

        # Skip current word (alphanumeric chars)
        while col < line_len and line[col].isalnum():
            col += 1

        # Skip spaces/punctuation to next word
        while col < line_len and not line[col].isalnum():
            col += 1

        self.cursor_col = col

    def scroll_to_cursor(self) -> None:
        """Ensure cursor is visible on screen."""
        # Vertical scroll
        if self.cursor_row < self.top_row:
            self.top_row = self.cursor_row
        elif self.cursor_row >= self.top_row + self.edit_height:
            self.top_row = self.cursor_row - self.edit_height + 1

        # Horizontal scroll
        if self.cursor_col < self.left_col:
            self.left_col = self.cursor_col
        elif self.cursor_col >= self.left_col + self.width:
            self.left_col = self.cursor_col - self.width + 1

    # === Mark actions ===

    def action_mark_line(self) -> None:
        """Mark line - E3 style: extends/trims on subsequent presses."""
        if self.mark and self.mark.mode == MarkMode.LINE:
            # Extend or trim existing line mark
            curl = self.cursor_row
            if curl >= self.mark.start_row and curl <= self.mark.end_row:
                # Cursor inside mark - trim to cursor
                self.mark.end_row = curl
            elif curl < self.mark.start_row:
                # Extend toward top
                self.mark.start_row = curl
            else:
                # Extend toward bottom
                self.mark.end_row = curl
            self.mark.pending = False
            start = min(self.mark.start_row, self.mark.end_row) + 1
            end = max(self.mark.start_row, self.mark.end_row) + 1
            self.message = f"Lines {start}-{end} marked"
        else:
            # Start new line mark (unmark any existing block mark)
            self.mark = Mark(
                mode=MarkMode.LINE,
                start_row=self.cursor_row,
                start_col=0,
                end_row=self.cursor_row,
                end_col=0,
                pending=False
            )
            self.message = f"Line {self.cursor_row + 1} marked"

    def action_mark_char(self) -> None:
        """Mark characters - extends on subsequent presses."""
        if self.mark and self.mark.mode == MarkMode.CHAR:
            # Extend character mark to current position
            self.mark.end_row = self.cursor_row
            self.mark.end_col = self.cursor_col
            self.mark.pending = False
            self.message = "Character mark extended"
        else:
            # Start new character mark
            self.mark = Mark(
                mode=MarkMode.CHAR,
                start_row=self.cursor_row,
                start_col=self.cursor_col,
                end_row=self.cursor_row,
                end_col=self.cursor_col,
                pending=False
            )
            self.message = f"Char mark at ({self.cursor_row + 1}, {self.cursor_col + 1})"

    def action_mark_block(self) -> None:
        """Mark block - E3 style: extends/trims on subsequent presses."""
        if self.mark and self.mark.mode == MarkMode.BLOCK:
            # Extend or trim existing block mark
            curl = self.cursor_row
            curc = self.cursor_col

            # Rows: extend or trim
            if curl >= self.mark.start_row and curl <= self.mark.end_row:
                self.mark.end_row = curl
            elif curl < self.mark.start_row:
                self.mark.start_row = curl
            else:
                self.mark.end_row = curl

            # Cols: extend or trim
            if curc >= self.mark.start_col and curc <= (self.mark.end_col or self.mark.start_col):
                self.mark.end_col = curc
            elif curc < self.mark.start_col:
                self.mark.start_col = curc
            else:
                self.mark.end_col = curc

            self.mark.pending = False
            self.message = "Block mark adjusted"
        else:
            # Start new block mark (unmark any existing line mark)
            self.mark = Mark(
                mode=MarkMode.BLOCK,
                start_row=self.cursor_row,
                start_col=self.cursor_col,
                end_row=self.cursor_row,
                end_col=self.cursor_col,
                pending=False
            )
            self.message = f"Block mark at ({self.cursor_row + 1}, {self.cursor_col + 1})"

    def action_mark_word(self) -> None:
        """Mark word at cursor."""
        line = self.buffer.get_line(self.cursor_row)
        if not line or self.cursor_col >= len(line):
            self.message = "No word at cursor"
            return

        # Find word boundaries
        col = self.cursor_col
        if not line[col].isalnum() and line[col] != '_':
            self.message = "No word at cursor"
            return

        start = col
        while start > 0 and (line[start - 1].isalnum() or line[start - 1] == '_'):
            start -= 1
        end = col
        while end < len(line) - 1 and (line[end + 1].isalnum() or line[end + 1] == '_'):
            end += 1

        self.mark = Mark(
            mode=MarkMode.CHAR,
            start_row=self.cursor_row,
            start_col=start,
            end_row=self.cursor_row,
            end_col=end,
            pending=False
        )
        self.message = f"Word marked: '{line[start:end + 1]}'"

    def action_unmark(self) -> None:
        """Clear current mark."""
        self.mark = None
        self.message = "Mark cleared"

    def action_copy(self) -> None:
        """Copy marked region to cursor position (E3 style - new mark at destination)."""
        if not self.mark:
            self.message = "No mark to copy"
            return

        if self.mark.mode not in (MarkMode.LINE, MarkMode.BLOCK):
            self.message = "Copy works with line or block marks"
            return

        # Get marked text
        text_lines = self.get_marked_text()
        m_lines = len(text_lines)

        if self.mark.mode == MarkMode.LINE:
            # Line copy: insert AFTER current line
            insert_row = self.cursor_row + 1
            # Save empty entry for undo - will delete inserted lines on undo
            self.buffer.push_undo(UndoType.LINE_INSERT, insert_row, 0, insert_row,
                                  insert_row + m_lines - 1)
            self.buffer.insert_lines(insert_row, text_lines)

            # Create new mark at destination
            self.mark = Mark(
                mode=MarkMode.LINE,
                start_row=insert_row,
                start_col=0,
                end_row=insert_row + m_lines - 1,
                end_col=0,
                pending=False
            )
            self.message = f"Copied {m_lines} line(s) after line {self.cursor_row + 1}"

        elif self.mark.mode == MarkMode.BLOCK:
            m_width = len(text_lines[0]) if text_lines else 0

            # Save lines that will be modified for undo
            self.buffer.push_undo(UndoType.BLOCK_CHANGE, self.cursor_row,
                                  self.cursor_col, self.cursor_row,
                                  self.cursor_row + m_lines - 1)

            # Block copy: insert at cursor position
            self.insert_text_at_cursor(text_lines, MarkMode.BLOCK)

            # Create new mark at destination
            self.mark = Mark(
                mode=MarkMode.BLOCK,
                start_row=self.cursor_row,
                start_col=self.cursor_col,
                end_row=self.cursor_row + m_lines - 1,
                end_col=self.cursor_col + m_width - 1,
                pending=False
            )
            self.message = f"Copied block to ({self.cursor_row + 1}, {self.cursor_col + 1})"

    def action_overlay(self) -> None:
        """Overlay marked block at cursor position (replace, not insert). Block marks only."""
        if not self.mark:
            self.message = "No mark to overlay"
            return

        if self.mark.mode != MarkMode.BLOCK:
            self.message = "Can't overlay a line mark - use block mark"
            return

        # Get marked text
        text_lines = self.get_marked_text()
        m_lines = len(text_lines)
        m_width = len(text_lines[0]) if text_lines else 0

        # Save for undo
        self.buffer.push_undo(UndoType.BLOCK_CHANGE, self.cursor_row,
                              self.cursor_col, self.cursor_row,
                              self.cursor_row + m_lines - 1)

        # Overlay at cursor position
        self.overlay_text_at_cursor(text_lines, m_width)

        # Create new mark at destination
        self.mark = Mark(
            mode=MarkMode.BLOCK,
            start_row=self.cursor_row,
            start_col=self.cursor_col,
            end_row=self.cursor_row + m_lines - 1,
            end_col=self.cursor_col + m_width - 1,
            pending=False
        )
        self.message = f"Overlaid block at ({self.cursor_row + 1}, {self.cursor_col + 1})"

    def action_delete(self) -> None:
        """Delete marked region."""
        if not self.mark:
            self.message = "No mark to delete"
            return

        # Save for undo
        start_row = min(self.mark.start_row, self.mark.end_row)
        end_row = max(self.mark.start_row, self.mark.end_row)
        if self.mark.mode == MarkMode.LINE:
            self.buffer.push_undo(UndoType.LINE_DELETE, start_row,
                                  0, start_row, end_row)
        else:
            self.buffer.push_undo(UndoType.BLOCK_CHANGE, start_row,
                                  self.cursor_col, start_row, end_row)

        self.delete_marked_region()
        self.mark = None
        self.message = "Deleted marked region"

    def action_shift_mark_left(self) -> None:
        """Shift marked block/lines left by deleting first char (F7)."""
        log.debug(f"action_shift_mark_left called, mark={self.mark}")
        if not self.mark:
            self.message = "No mark"
            return

        if self.mark.mode not in (MarkMode.LINE, MarkMode.BLOCK):
            self.message = "Shift only works with line or block marks"
            return

        start_row = self.mark.start_row
        end_row = self.mark.end_row
        log.debug(f"Shifting rows {start_row} to {end_row}")

        # Save for undo
        self.buffer.push_undo(UndoType.BLOCK_CHANGE, start_row,
                              self.cursor_col, start_row, end_row)

        # For LINE marks, shift from column 0; for BLOCK, from mark start col
        start_col = 0 if self.mark.mode == MarkMode.LINE else self.mark.start_col

        for row in range(start_row, end_row + 1):
            line = self.buffer.get_line(row)
            if len(line) > start_col:
                # Delete char at start_col
                new_line = line[:start_col] + line[start_col + 1:]
                self.buffer.set_line(row, new_line)

        # Adjust mark end column for block marks
        if self.mark.mode == MarkMode.BLOCK and self.mark.end_col > self.mark.start_col:
            self.mark.end_col -= 1

        self.message = "Shifted left"

    def action_shift_mark_right(self) -> None:
        """Shift marked block/lines right by inserting space (F8)."""
        if not self.mark:
            self.message = "No mark"
            return

        if self.mark.mode not in (MarkMode.LINE, MarkMode.BLOCK):
            self.message = "Shift only works with line or block marks"
            return

        start_row = self.mark.start_row
        end_row = self.mark.end_row

        # Save for undo
        self.buffer.push_undo(UndoType.BLOCK_CHANGE, start_row,
                              self.cursor_col, start_row, end_row)

        # For LINE marks, insert at column 0; for BLOCK, at mark start col
        start_col = 0 if self.mark.mode == MarkMode.LINE else self.mark.start_col

        for row in range(start_row, end_row + 1):
            line = self.buffer.get_line(row)
            # Pad if needed
            if len(line) < start_col:
                line = line.ljust(start_col)
            # Insert space at start_col
            new_line = line[:start_col] + ' ' + line[start_col:]
            self.buffer.set_line(row, new_line)

        # Adjust mark end column for block marks
        if self.mark.mode == MarkMode.BLOCK:
            self.mark.end_col += 1

        self.message = "Shifted right"

    def action_fill_mark(self) -> None:
        """Start fill operation - waits for fill character (Alt-F)."""
        if not self.mark:
            self.message = "No mark to fill"
            return

        if self.mark.mode not in (MarkMode.LINE, MarkMode.BLOCK):
            self.message = "Fill only works with line or block marks"
            return

        self.fill_pending = True
        self.message = "Fill with character: "

    def do_fill_mark(self, fill_char: str) -> None:
        """Fill the marked region with the specified character."""
        if not self.mark:
            self.message = "No mark to fill"
            return

        start_row = min(self.mark.start_row, self.mark.end_row)
        end_row = max(self.mark.start_row, self.mark.end_row)

        # Save for undo
        self.buffer.push_undo(UndoType.BLOCK_CHANGE, start_row,
                              0, start_row, end_row)

        if self.mark.mode == MarkMode.LINE:
            # Fill entire lines - preserve line length
            for row in range(start_row, end_row + 1):
                line = self.buffer.get_line(row)
                line_len = len(line) if line else 1  # At least 1 char
                self.buffer.set_line(row, fill_char * line_len)
            self.message = f"Filled {end_row - start_row + 1} line(s) with '{fill_char}'"

        elif self.mark.mode == MarkMode.BLOCK:
            # Fill rectangular region
            start_col = min(self.mark.start_col, self.mark.end_col)
            end_col = max(self.mark.start_col, self.mark.end_col)
            width = end_col - start_col + 1
            fill_str = fill_char * width

            for row in range(start_row, end_row + 1):
                line = self.buffer.get_line(row)
                # Pad line if needed
                if len(line) < end_col + 1:
                    line = line.ljust(end_col + 1)
                # Replace the block region
                new_line = line[:start_col] + fill_str + line[end_col + 1:]
                self.buffer.set_line(row, new_line)
            self.message = f"Filled block with '{fill_char}'"

    def action_copy_to_clipboard(self) -> None:
        """Copy marked text to system clipboard using OSC 52."""
        if not self.mark:
            self.message = "No mark to copy to clipboard"
            return

        text_lines = self.get_marked_text()
        text = '\n'.join(text_lines)

        # OSC 52 escape sequence to set clipboard
        # Format: ESC ] 52 ; c ; BASE64_TEXT BEL
        encoded = base64.b64encode(text.encode('utf-8')).decode('ascii')
        osc52 = f'\033]52;c;{encoded}\007'
        sys.stdout.write(osc52)
        sys.stdout.flush()

        self.message = f"Copied {len(text_lines)} line(s) to clipboard"

    def action_move(self) -> None:
        """Move marked region to cursor position (E3 style)."""
        if not self.mark:
            self.message = "No mark to move"
            return

        if self.mark.mode not in (MarkMode.LINE, MarkMode.BLOCK):
            self.message = "Move works with line or block marks"
            return

        # Get marked text before deleting
        text_lines = self.get_marked_text()
        m_lines = len(text_lines)
        mode = self.mark.mode

        # Save source mark info
        src_start_row = self.mark.start_row
        src_end_row = self.mark.end_row

        if mode == MarkMode.LINE:
            curl = self.cursor_row

            # Check if cursor is inside the mark
            if curl >= src_start_row and curl <= src_end_row:
                self.message = "Can't move lines over themselves"
                return

            # Delete source lines first
            self.buffer.delete_lines(src_start_row, src_end_row)

            # Adjust cursor if it was after the deleted lines
            if curl > src_end_row:
                curl -= m_lines

            # Insert after cursor line
            insert_row = curl + 1
            self.buffer.insert_lines(insert_row, text_lines)

            # Create new mark at destination
            self.mark = Mark(
                mode=MarkMode.LINE,
                start_row=insert_row,
                start_col=0,
                end_row=insert_row + m_lines - 1,
                end_col=0,
                pending=False
            )
            self.cursor_row = insert_row
            self.message = f"Moved {m_lines} line(s)"

        elif mode == MarkMode.BLOCK:
            m_width = len(text_lines[0]) if text_lines else 0

            # Check if exact overlap
            if (self.cursor_row == src_start_row and
                self.cursor_col == self.mark.start_col):
                self.message = "Moving block over itself has no effect"
                return

            # Delete source block first
            self.delete_marked_region()

            # Insert at cursor
            self.insert_text_at_cursor(text_lines, MarkMode.BLOCK)

            # Create new mark at destination
            self.mark = Mark(
                mode=MarkMode.BLOCK,
                start_row=self.cursor_row,
                start_col=self.cursor_col,
                end_row=self.cursor_row + m_lines - 1,
                end_col=self.cursor_col + m_width - 1,
                pending=False
            )
            self.message = f"Moved block"

    def insert_text_at_cursor(self, text_lines: List[str], mode: MarkMode) -> None:
        """Insert text at cursor position based on mark mode."""
        if not text_lines:
            return

        if mode == MarkMode.LINE:
            # Insert complete lines at cursor row
            self.buffer.insert_lines(self.cursor_row, text_lines)

        elif mode == MarkMode.BLOCK:
            # Block insert - insert at each row starting at cursor
            for i, text in enumerate(text_lines):
                row = self.cursor_row + i
                while row >= len(self.buffer.lines):
                    self.buffer.lines.append("")
                line = self.buffer.get_line(row)
                # Pad line if cursor is beyond line end
                if len(line) < self.cursor_col:
                    line = line.ljust(self.cursor_col)
                self.buffer.set_line(row, line[:self.cursor_col] + text + line[self.cursor_col:])

        else:  # CHAR mode
            # Insert text at cursor position, handling newlines
            if len(text_lines) == 1:
                # Single line insert
                line = self.buffer.get_line(self.cursor_row)
                self.buffer.set_line(self.cursor_row,
                    line[:self.cursor_col] + text_lines[0] + line[self.cursor_col:])
            else:
                # Multi-line insert
                line = self.buffer.get_line(self.cursor_row)
                before = line[:self.cursor_col]
                after = line[self.cursor_col:]

                # First line: before + first text
                self.buffer.set_line(self.cursor_row, before + text_lines[0])

                # Middle lines
                for i, text in enumerate(text_lines[1:-1], 1):
                    self.buffer.lines.insert(self.cursor_row + i, text)

                # Last line: last text + after
                self.buffer.lines.insert(self.cursor_row + len(text_lines) - 1,
                    text_lines[-1] + after)

    def overlay_text_at_cursor(self, text_lines: List[str], width: int) -> None:
        """Overlay (replace) text at cursor position. Block mode only."""
        if not text_lines:
            return

        for i, text in enumerate(text_lines):
            row = self.cursor_row + i
            while row >= len(self.buffer.lines):
                self.buffer.lines.append("")
            line = self.buffer.get_line(row)
            # Pad line if cursor is beyond line end
            if len(line) < self.cursor_col + width:
                line = line.ljust(self.cursor_col + width)
            # Replace the range [cursor_col : cursor_col + width] with text
            new_line = line[:self.cursor_col] + text + line[self.cursor_col + width:]
            self.buffer.set_line(row, new_line)

    def get_marked_text(self) -> List[str]:
        """Get marked text as list of strings."""
        if not self.mark:
            return []

        start_row = self.mark.start_row
        end_row = self.mark.end_row if self.mark.end_row is not None else start_row
        start_col = self.mark.start_col
        end_col = self.mark.end_col if self.mark.end_col is not None else start_col

        # Normalize
        if start_row > end_row:
            start_row, end_row = end_row, start_row
            start_col, end_col = end_col, start_col
        elif start_row == end_row and start_col > end_col:
            start_col, end_col = end_col, start_col

        result = []

        if self.mark.mode == MarkMode.LINE:
            for r in range(start_row, end_row + 1):
                result.append(self.buffer.get_line(r))

        elif self.mark.mode == MarkMode.CHAR:
            for r in range(start_row, end_row + 1):
                line = self.buffer.get_line(r)
                if r == start_row and r == end_row:
                    result.append(line[start_col:end_col + 1])
                elif r == start_row:
                    result.append(line[start_col:])
                elif r == end_row:
                    result.append(line[:end_col + 1])
                else:
                    result.append(line)

        elif self.mark.mode == MarkMode.BLOCK:
            col_start = min(start_col, end_col)
            col_end = max(start_col, end_col)
            for r in range(start_row, end_row + 1):
                line = self.buffer.get_line(r)
                if len(line) < col_end + 1:
                    line = line.ljust(col_end + 1)
                result.append(line[col_start:col_end + 1])

        return result

    def delete_marked_region(self) -> None:
        """Delete the marked region from buffer."""
        if not self.mark:
            return

        start_row = self.mark.start_row
        end_row = self.mark.end_row if self.mark.end_row is not None else start_row
        start_col = self.mark.start_col
        end_col = self.mark.end_col if self.mark.end_col is not None else start_col

        # Normalize
        if start_row > end_row:
            start_row, end_row = end_row, start_row
            start_col, end_col = end_col, start_col
        elif start_row == end_row and start_col > end_col:
            start_col, end_col = end_col, start_col

        if self.mark.mode == MarkMode.LINE:
            self.buffer.delete_lines(start_row, end_row)
            self.cursor_row = min(start_row, len(self.buffer.lines) - 1)
            self.cursor_col = 0

        elif self.mark.mode == MarkMode.CHAR:
            if start_row == end_row:
                line = self.buffer.get_line(start_row)
                self.buffer.set_line(start_row, line[:start_col] + line[end_col + 1:])
            else:
                first = self.buffer.get_line(start_row)[:start_col]
                last = self.buffer.get_line(end_row)[end_col + 1:]
                self.buffer.set_line(start_row, first + last)
                for _ in range(end_row - start_row):
                    if start_row + 1 < len(self.buffer.lines):
                        del self.buffer.lines[start_row + 1]
            self.cursor_row = start_row
            self.cursor_col = start_col

        elif self.mark.mode == MarkMode.BLOCK:
            col_start = min(start_col, end_col)
            col_end = max(start_col, end_col)
            for r in range(start_row, end_row + 1):
                if r < len(self.buffer.lines):
                    line = self.buffer.get_line(r)
                    self.buffer.set_line(r, line[:col_start] + line[col_end + 1:])

    def action_goto_mark_start(self) -> None:
        """Go to mark start."""
        if self.mark:
            self.cursor_row = self.mark.start_row
            self.cursor_col = self.mark.start_col
            self.message = f"Moved to mark start"
        else:
            self.message = "No mark set"

    def action_goto_mark_end(self) -> None:
        """Go to mark end."""
        if self.mark and self.mark.end_row is not None:
            self.cursor_row = self.mark.end_row
            self.cursor_col = self.mark.end_col or 0
            self.message = f"Moved to mark end"
        else:
            self.message = "Mark not complete"

    def action_split_line(self) -> None:
        """Split line at cursor."""
        self.buffer.push_undo(UndoType.LINE_SPLIT, self.cursor_row,
                              self.cursor_col, self.cursor_row, self.cursor_row)
        self.buffer.split_line(self.cursor_row, self.cursor_col)
        self.cursor_row += 1
        self.cursor_col = 0
        self.message = "Line split"

    def action_join_line(self) -> None:
        """Join current line with next."""
        if self.cursor_row < len(self.buffer.lines) - 1:
            self.buffer.push_undo(UndoType.LINE_JOIN, self.cursor_row,
                                  len(self.buffer.get_line(self.cursor_row)),
                                  self.cursor_row, self.cursor_row + 1)
            curr = self.buffer.get_line(self.cursor_row)
            next_line = self.buffer.get_line(self.cursor_row + 1)
            self.buffer.set_line(self.cursor_row, curr + next_line)
            del self.buffer.lines[self.cursor_row + 1]
            self.message = "Lines joined"

    # === File operations ===

    def action_save(self) -> None:
        """Save file."""
        if self.buffer.save():
            self.message = f"Saved {self.buffer.filename}"
        else:
            self.message = "Save failed - no filename"

    def action_quit(self) -> None:
        """Quit without saving."""
        if self.buffer.modified:
            self.message = "File modified! Press F3 again to discard changes"
            self.buffer.modified = False  # Allow second F3 to quit
        else:
            self.running = False

    def action_save_and_quit(self) -> None:
        """Save and quit."""
        if self.buffer.save():
            self.running = False
        else:
            self.message = "Save failed"

    def action_undo(self) -> None:
        """Undo the last edit operation."""
        log.debug(f"action_undo called, stack size={len(self.buffer.undo_stack)}")
        entry = self.buffer.pop_undo()
        if not entry:
            self.message = "Nothing to undo"
            return

        log.debug(f"Undoing: {entry}")
        # Save current state for redo before restoring
        self._save_for_redo(entry)

        # Restore the previous state
        self._apply_undo_entry(entry)

        # Restore cursor position
        self.cursor_row = entry.line_num
        self.cursor_col = entry.col_pos
        self.scroll_to_cursor()

        self.buffer.modified = True
        self.message = f"Undo: {entry.undo_type.name.lower().replace('_', ' ')}"

    def action_redo(self) -> None:
        """Redo the last undone operation."""
        if not self.buffer.redo_stack:
            self.message = "Nothing to redo"
            return

        entry = self.buffer.redo_stack.pop()

        # Save current state for undo before redoing
        self._save_for_undo_from_redo(entry)

        # Apply the redo (same as undo - swap states)
        self._apply_undo_entry(entry)

        # Restore cursor position
        self.cursor_row = entry.line_num
        self.cursor_col = entry.col_pos
        self.scroll_to_cursor()

        self.buffer.modified = True
        self.message = f"Redo: {entry.undo_type.name.lower().replace('_', ' ')}"

    def _save_for_redo(self, entry: UndoEntry) -> None:
        """Save current state to redo stack before undo."""
        # Determine what lines to save based on entry type
        if entry.undo_type == UndoType.LINE_CHANGE:
            saved = [self.buffer.lines[entry.line_num]] if entry.line_num < len(self.buffer.lines) else [""]
            line_count = 1
        elif entry.undo_type == UndoType.LINE_INSERT:
            # Save the inserted lines that will be deleted
            saved = [self.buffer.lines[entry.line_num + i]
                     for i in range(entry.line_count)
                     if entry.line_num + i < len(self.buffer.lines)]
            line_count = len(saved)
        elif entry.undo_type == UndoType.LINE_DELETE:
            # No lines to save (they were deleted, now being restored)
            saved = []
            line_count = len(entry.saved_lines)
        elif entry.undo_type == UndoType.LINE_SPLIT:
            # Save both lines that will be rejoined
            saved = []
            if entry.line_num < len(self.buffer.lines):
                saved.append(self.buffer.lines[entry.line_num])
            if entry.line_num + 1 < len(self.buffer.lines):
                saved.append(self.buffer.lines[entry.line_num + 1])
            line_count = 2
        elif entry.undo_type == UndoType.LINE_JOIN:
            # Save the joined line
            saved = [self.buffer.lines[entry.line_num]] if entry.line_num < len(self.buffer.lines) else [""]
            line_count = 1
        elif entry.undo_type == UndoType.BLOCK_CHANGE:
            saved = [self.buffer.lines[entry.line_num + i]
                     for i in range(entry.line_count)
                     if entry.line_num + i < len(self.buffer.lines)]
            line_count = len(saved)
        else:
            saved = []
            line_count = 0

        redo_entry = UndoEntry(
            undo_type=entry.undo_type,
            line_num=entry.line_num,
            col_pos=entry.col_pos,
            saved_lines=saved,
            line_count=line_count
        )
        self.buffer.redo_stack.append(redo_entry)

        # Limit redo stack size
        if len(self.buffer.redo_stack) > self.buffer.max_undo:
            self.buffer.redo_stack.pop(0)

    def _save_for_undo_from_redo(self, entry: UndoEntry) -> None:
        """Save current state to undo stack before redo (without clearing redo)."""
        # Similar to _save_for_redo but pushes to undo stack
        if entry.undo_type == UndoType.LINE_CHANGE:
            saved = [self.buffer.lines[entry.line_num]] if entry.line_num < len(self.buffer.lines) else [""]
            line_count = 1
        elif entry.undo_type == UndoType.LINE_INSERT:
            saved = []
            line_count = len(entry.saved_lines)
        elif entry.undo_type == UndoType.LINE_DELETE:
            saved = [self.buffer.lines[entry.line_num + i]
                     for i in range(entry.line_count)
                     if entry.line_num + i < len(self.buffer.lines)]
            line_count = len(saved)
        elif entry.undo_type == UndoType.LINE_SPLIT:
            saved = [self.buffer.lines[entry.line_num]] if entry.line_num < len(self.buffer.lines) else [""]
            line_count = 1
        elif entry.undo_type == UndoType.LINE_JOIN:
            saved = []
            if entry.line_num < len(self.buffer.lines):
                saved.append(self.buffer.lines[entry.line_num])
            if entry.line_num + 1 < len(self.buffer.lines):
                saved.append(self.buffer.lines[entry.line_num + 1])
            line_count = 2
        elif entry.undo_type == UndoType.BLOCK_CHANGE:
            saved = [self.buffer.lines[entry.line_num + i]
                     for i in range(entry.line_count)
                     if entry.line_num + i < len(self.buffer.lines)]
            line_count = len(saved)
        else:
            saved = []
            line_count = 0

        undo_entry = UndoEntry(
            undo_type=entry.undo_type,
            line_num=entry.line_num,
            col_pos=entry.col_pos,
            saved_lines=saved,
            line_count=line_count
        )
        self.buffer.undo_stack.append(undo_entry)

    def _apply_undo_entry(self, entry: UndoEntry) -> None:
        """Apply an undo/redo entry to restore state."""
        if entry.undo_type == UndoType.LINE_CHANGE:
            if entry.saved_lines:
                while entry.line_num >= len(self.buffer.lines):
                    self.buffer.lines.append("")
                self.buffer.lines[entry.line_num] = entry.saved_lines[0]

        elif entry.undo_type == UndoType.LINE_INSERT:
            # Lines were inserted - delete them
            for _ in range(entry.line_count):
                if entry.line_num < len(self.buffer.lines):
                    del self.buffer.lines[entry.line_num]
            if not self.buffer.lines:
                self.buffer.lines = [""]

        elif entry.undo_type == UndoType.LINE_DELETE:
            # Lines were deleted - restore them
            for i, line in enumerate(entry.saved_lines):
                self.buffer.lines.insert(entry.line_num + i, line)

        elif entry.undo_type == UndoType.LINE_SPLIT:
            # Line was split - rejoin it
            if entry.line_num + 1 < len(self.buffer.lines):
                del self.buffer.lines[entry.line_num + 1]
            if entry.saved_lines:
                self.buffer.lines[entry.line_num] = entry.saved_lines[0]

        elif entry.undo_type == UndoType.LINE_JOIN:
            # Lines were joined - split them back
            if entry.saved_lines and len(entry.saved_lines) >= 2:
                self.buffer.lines[entry.line_num] = entry.saved_lines[0]
                self.buffer.lines.insert(entry.line_num + 1, entry.saved_lines[1])

        elif entry.undo_type == UndoType.BLOCK_CHANGE:
            for i, line in enumerate(entry.saved_lines):
                row = entry.line_num + i
                while row >= len(self.buffer.lines):
                    self.buffer.lines.append("")
                self.buffer.lines[row] = line

    def show_help(self) -> None:
        """Show help screen with scrolling."""
        help_lines = [
            "E-Py Editor Help                                    PgDn/PgUp to scroll, F3 to exit",
            "=" * 78,
            "",
            "FUNCTION KEYS",
            "  F1  Help (this screen)          F7  Shift mark left",
            "  F2  Save file                   F8  Shift mark right",
            "  F3  Quit (no save)              F9  Undo",
            "  F4  Save and quit               F10 Next file (not yet implemented)",
            "",
            "MARK TYPES (press again to extend/trim)",
            "  Alt-L  Mark line(s) - highlights entire line in 2D space",
            "  Alt-B  Mark block - rectangular selection",
            "  Alt-Z  Mark characters - flows across line boundaries",
            "  Alt-W  Mark word under cursor",
            "",
            "MARK OPERATIONS",
            "  Alt-C  Copy block to cursor (inserts, pushes text right)",
            "  Alt-M  Move block to cursor",
            "  Alt-O  Overlay block at cursor (replaces, no insert)",
            "  Alt-D  Delete marked region",
            "  Alt-U  Unmark / clear mark",
            "  Alt-Y  Go to mark start",
            "  Alt-E  Go to mark end",
            "  Alt-K  Copy mark to system clipboard",
            "",
            "EDITING",
            "  Alt-S  Split line at cursor",
            "  Alt-J  Join current line with next",
            "  Ctrl-E Erase to end of line",
            "",
            "UNDO / REDO",
            "  F9                Undo last edit",
            "  Ctrl-Y or Ctrl-R  Redo (after undo)",
            "  Undoes: typing, delete, backspace, enter, tab, erase",
            "          mark delete/copy/overlay, shift left/right",
            "          split/join lines, change command, paste",
            "  Up to 100 undo/redo levels. Cleared on file load.",
            "",
            "CURSOR MOVEMENT",
            "  Arrow keys      Move one position",
            "  Home/End        Start/end of line",
            "  PgUp/PgDn       Page up/down",
            "  Ctrl-Home       Top of file",
            "  Ctrl-End        End of file",
            "  Ctrl-Left       Previous word",
            "  Ctrl-Right      Next word",
            "  Ctrl-PgUp       Top of screen",
            "  Ctrl-PgDn       Bottom of screen",
            "",
            "COMMAND LINE (press ESC to enter, ESC to exit)",
            "  123           Go to line 123",
            "  /pattern      Search forward from cursor",
            "  /pattern/c    Search case-insensitive",
            "  c/old/new/    Change - prompts Y/N/Q/G for each",
            "  c/old/new/*   Change all occurrences",
            "  c/old/new/c   Change case-insensitive",
            "  c/old/new/m   Change within mark only",
            "  t, top        Go to top of file",
            "  b, bot        Go to bottom of file",
            "  s, save       Save file",
            "  q, quit       Quit without saving",
            "  n filename    Set/change filename",
            "  e filename    Edit file",
            "",
            "CHANGE COMMAND PROMPTS (when not using *)",
            "  Y  Yes, change this occurrence",
            "  N  No, skip this occurrence",
            "  Q  Quit changing",
            "  G  Go - change this and all remaining",
            "",
            "CLIPBOARD",
            "  Paste: Use terminal paste (Cmd-V, Ctrl-V, or middle-click)",
            "  Copy:  Alt-K copies marked text to system clipboard",
            "",
            "2D CURSOR SPACE",
            "  The cursor can move anywhere - not bounded by line length.",
            "  When inserting past line end, spaces are auto-filled.",
            "  LINE marks highlight the entire line width.",
            "",
            "Based on the E3/E editor",
            "",
        ]

        top = 0
        max_top = max(0, len(help_lines) - (self.height - 2))

        while True:
            self.screen.clear()
            for i in range(self.height - 1):
                line_idx = top + i
                if line_idx < len(help_lines):
                    self.safe_addstr(i, 1, help_lines[line_idx], curses.color_pair(3))

            # Status line
            status = f" Line {top + 1}-{min(top + self.height - 1, len(help_lines))} of {len(help_lines)} | PgUp/PgDn to scroll | F3 to exit "
            self.safe_addstr(self.height - 1, 0, status.center(self.width), curses.color_pair(1))
            self.screen.refresh()

            ch = self.screen.getch()
            if ch == curses.KEY_F3 or ch == 27 or ch == ord('q') or ch == ord('Q'):
                break
            elif ch == curses.KEY_PPAGE or ch == curses.KEY_UP:
                top = max(0, top - (self.height - 2))
            elif ch == curses.KEY_NPAGE or ch == curses.KEY_DOWN or ch == ord(' '):
                top = min(max_top, top + (self.height - 2))


def main():
    # Set ESCDELAY before curses init (default is often 1000ms!)
    os.environ.setdefault('ESCDELAY', '25')

    filename = sys.argv[1] if len(sys.argv) > 1 else None
    editor = Editor(filename)
    curses.wrapper(editor.run)


if __name__ == "__main__":
    main()
