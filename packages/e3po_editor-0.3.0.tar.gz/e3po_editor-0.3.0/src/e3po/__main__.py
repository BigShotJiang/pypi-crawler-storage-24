"""Allow running as python -m e3po."""
from .editor import main

if __name__ == "__main__":
    main()
