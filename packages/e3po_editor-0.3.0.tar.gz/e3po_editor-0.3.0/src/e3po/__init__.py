"""e3po: E3 Python Option - A terminal text editor based on E3/E."""

__version__ = "0.3.0"

from .editor import main, Editor, Buffer

__all__ = ["main", "Editor", "Buffer", "__version__"]
