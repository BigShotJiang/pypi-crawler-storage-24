"""L10: Process / Flow slide."""
from .core import *

def L10_process(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L10 Process: 4-step sequential workflow shown as chevrons")
    S.title("Process headline goes here")
    steps = ["Connect", "Configure", "Test", "Deploy"]
    descs = ["Add SIP trunk\nor phone numbers", "Write your SWML\ncall flow",
              "Run live calls\nin the sandbox", "Push to production\nwith one command"]
    S.process_steps(steps, descs)
    S.done()
