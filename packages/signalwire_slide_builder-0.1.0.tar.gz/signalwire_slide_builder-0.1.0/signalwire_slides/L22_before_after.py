"""L22: Before / After (Problem / Solution) slide."""
from .core import *

def L22_before_after(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L22 Before/After: problem on left vs solution on right")
    S.title("The shift")

    half_w = Inches(5.9)
    cy, ch, pad = Inches(1.3), Inches(5.3), Inches(0.5)

    # Left: problem (darker surface)
    rect(S.s, ML, cy, half_w, ch, T["raised"])
    S.text("Before",
           ML + pad, cy + Inches(0.3), w=half_w - pad * 2, h=0.5,
           font="h", size=24, color="muted", bold=True)
    left_items = ["Problem point one", "Problem point two", "Problem point three"]
    S.body(left_items, top=cy + Inches(1.0), left=ML + pad, width=half_w - pad * 2, size=BODY_SM)

    # Right: solution (emphasis surface)
    rx = ML + half_w + Inches(0.15)
    S.card(rx, cy, half_w, ch, accent=T["emphasis"])
    S.text("After",
           rx + pad, cy + Inches(0.3), w=half_w - pad * 2, h=0.5,
           font="h", size=24, color="emphasis", bold=True)
    right_items = ["Solution point one", "Solution point two", "Solution point three"]
    S.body(right_items, top=cy + Inches(1.0), left=rx + pad, width=half_w - pad * 2, size=BODY_SM)

    S.done()
