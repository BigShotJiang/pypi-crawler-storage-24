"""L03: Agenda / Contents slide."""
from .core import *

def L03_agenda(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L03 Agenda: numbered list of topics to be covered")
    S.title("Agenda")
    S.numbered(
        ["Platform overview and market context",
         "Architecture and technical differentiation",
         "Customer outcomes and case studies",
         "Pricing and deployment model",
         "Next steps and Q&A"])
    S.done()
