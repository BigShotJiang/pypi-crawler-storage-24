"""L12: Big Number / KPI slide."""
from .core import *

def L12_kpi(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L12 KPI: single headline metric with context caption")
    S.kpi(
        "141%",
        "What this metric means, one sentence.",
        "KEY METRIC")
    S.done()
