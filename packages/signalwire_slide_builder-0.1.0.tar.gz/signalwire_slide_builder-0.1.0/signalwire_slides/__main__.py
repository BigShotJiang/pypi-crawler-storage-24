"""
CLI entry point: signalwire-slides

Builds the reference deck (29 slides) in Dark and/or Light theme.

Usage:
    signalwire-slides                    # both themes
    signalwire-slides --theme dark       # dark only
    signalwire-slides --theme light      # light only
    signalwire-slides -o my_deck.pptx    # custom output
"""

import argparse
import os
from pptx import Presentation

from .core import (
    SW, SH, GRAD, LIGHT,
    LOGO_WHITE_SVG, LOGO_BLACK_SVG, svg_to_png,
)
from . import (
    ALL_LAYOUTS, RESOURCE_LAYOUTS, LAYOUT_NAMES,
    L15_closing, L17_blank_dark, L18_blank_light,
)


def build_deck(theme_config, logo_png, logo_white_png, suffix, output_dir="."):
    """Build a single-theme .pptx deck."""
    prs = Presentation()
    prs.slide_width = SW; prs.slide_height = SH
    bk = prs.slide_layouts[6]

    for fn in ALL_LAYOUTS:
        if fn == L15_closing:
            fn(prs, bk, theme_config, logo_png, logo_white=logo_white_png)
        else:
            fn(prs, bk, theme_config, logo_png)

    for fn in RESOURCE_LAYOUTS:
        fn(prs, bk, theme_config, logo_png)

    if theme_config["is_gradient"]:
        L17_blank_dark(prs, bk, theme_config, logo_png)
    else:
        L18_blank_light(prs, bk, theme_config, logo_png)

    out = os.path.join(output_dir, f"SignalWire_Template_{suffix}.pptx")
    prs.save(out)
    return out, len(prs.slides)


def main():
    parser = argparse.ArgumentParser(
        description="Build SignalWire branded slide decks"
    )
    parser.add_argument(
        "--theme", choices=["dark", "light", "both"], default="both",
        help="Which theme to build (default: both)"
    )
    parser.add_argument(
        "-o", "--output-dir", default=".",
        help="Output directory (default: current)"
    )
    args = parser.parse_args()

    lw = svg_to_png(LOGO_WHITE_SVG, width=800)
    lb = svg_to_png(LOGO_BLACK_SVG, width=800)

    builds = []
    if args.theme in ("dark", "both"):
        builds.append((GRAD, lw, lw, "Dark", "DARK GRADIENT"))
    if args.theme in ("light", "both"):
        builds.append((LIGHT, lb, lw, "Light", "LIGHT"))

    for theme, logo, logo_w, suffix, label in builds:
        out, count = build_deck(theme, logo, logo_w, suffix, args.output_dir)
        print(f"\n{label}: {out}")
        print(f"  {count} slides:")
        for i, n in enumerate(LAYOUT_NAMES):
            print(f"    {i+1:2}. {n}")


if __name__ == "__main__":
    main()
