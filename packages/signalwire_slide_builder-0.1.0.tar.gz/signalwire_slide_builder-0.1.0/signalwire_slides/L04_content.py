"""L04: Content (Single Message) slide."""
from .core import *

def L04_content(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L04 Content: assertion headline with 3 supporting bullet points")
    S.title("State the key takeaway as a sentence")
    S.body(
        ["First point: 6-8 words max",
         "Second point: supporting evidence",
         "Third point: implication or data"])
    S.done()
