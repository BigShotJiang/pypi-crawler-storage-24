"""L24: Metric Dashboard (4 KPI cards)."""
from .core import *

def L24_metric_dashboard(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L24 Metric Dashboard: 4 KPI cards with values, labels, and context")
    S.title("Performance at a glance")
    metrics = [("$22.1M", "ARR", "37% YoY growth", T["emphasis"]),
                ("141%", "Net Dollar Retention", "Customers expand 41%/yr", T["emphasis_alt"]),
                ("0.37x", "Burn Multiple", "Capital efficient growth", T["emphasis"]),
                ("2.7B", "Minutes Annually", "85 people, global scale", T["emphasis_alt"])]
    S.metric_cards(metrics)
    S.done()
