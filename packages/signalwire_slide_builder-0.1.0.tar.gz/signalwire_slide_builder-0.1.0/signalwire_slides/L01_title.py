"""L01: Title / Cover slide."""
from .core import *

def L01_title(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L01 Title/Cover: opening slide with presentation title and presenter info")
    S.title("Presentation Title", large=True, top=2.0)
    S.subtitle("Presenter  |  Role  |  Date", top=4.5)
    S.done()
