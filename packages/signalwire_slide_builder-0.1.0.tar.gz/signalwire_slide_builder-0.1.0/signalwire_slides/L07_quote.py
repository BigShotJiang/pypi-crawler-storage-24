"""L07: Full-Bleed Quote slide."""
from .core import *

def L07_quote(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L07 Quote: customer or stakeholder testimonial with attribution")
    S.quote(
        "Add a quote here, one to two sentences for impact.",
        "Name, Title",
        "Company")
    S.done()
