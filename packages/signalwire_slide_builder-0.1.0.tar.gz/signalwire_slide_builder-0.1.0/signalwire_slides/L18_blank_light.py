"""L18: Blank slide (light)."""
from .core import *

def L18_blank_light(prs, bk, T, logo_light, ai_notes=None):
    s = prs.slides.add_slide(bk)
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = LIGHT_PAGE_BG
    footer_bar(s, LIGHT, logo_light)
