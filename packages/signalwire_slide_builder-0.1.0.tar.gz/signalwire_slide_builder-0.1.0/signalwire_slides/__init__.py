"""
SignalWire Slide Builder — pip install signalwire-slide-builder

Usage:
    from signalwire_slides import SlideBuilder, GRAD, LIGHT, CATALOG
    from signalwire_slides import L04_content, L12_kpi

    prs = Presentation()
    prs.slide_width = SW; prs.slide_height = SH
    bk = prs.slide_layouts[6]
    lw = svg_to_png(LOGO_WHITE_SVG, width=800)

    S = SlideBuilder(prs, bk, GRAD, lw)
    S.title("Your headline here")
    S.body(["Point one", "Point two", "Point three"])
    S.done()

    prs.save("my_deck.pptx")
"""

from .core import *  # noqa: F401,F403

from .L01_title import L01_title
from .L02_section import L02_section
from .L03_agenda import L03_agenda
from .L04_content import L04_content
from .L05_two_col import L05_two_col
from .L06_image_text import L06_image_text
from .L07_quote import L07_quote
from .L08_chart import L08_chart
from .L09_table import L09_table
from .L10_process import L10_process
from .L11_timeline import L11_timeline
from .L12_kpi import L12_kpi
from .L13_case_study import L13_case_study
from .L14_architecture import L14_architecture
from .L15_closing import L15_closing
from .L16_appendix import L16_appendix
from .L17_blank_dark import L17_blank_dark
from .L18_blank_light import L18_blank_light
from .L19_icon_sheet import L19_icon_sheet
from .L20_color_swatch import L20_color_swatch
from .L21_bento_grid import L21_bento_grid
from .L22_before_after import L22_before_after
from .L23_logo_wall import L23_logo_wall
from .L24_metric_dashboard import L24_metric_dashboard
from .L25_full_bleed_image import L25_full_bleed_image
from .L26_team import L26_team
from .L27_thesis import L27_thesis
from .L28_why_now import L28_why_now
from .L29_competitive import L29_competitive
from .L30_how_it_works import L30_how_it_works

CATALOG = {
    "L01": L01_title, "L02": L02_section, "L03": L03_agenda,
    "L04": L04_content, "L05": L05_two_col, "L06": L06_image_text,
    "L07": L07_quote, "L08": L08_chart, "L09": L09_table,
    "L10": L10_process, "L11": L11_timeline, "L12": L12_kpi,
    "L13": L13_case_study, "L14": L14_architecture, "L15": L15_closing,
    "L16": L16_appendix, "L17": L17_blank_dark, "L18": L18_blank_light,
    "L19": L19_icon_sheet, "L20": L20_color_swatch, "L21": L21_bento_grid,
    "L22": L22_before_after, "L23": L23_logo_wall, "L24": L24_metric_dashboard,
    "L25": L25_full_bleed_image, "L26": L26_team,
    "L27": L27_thesis, "L28": L28_why_now, "L29": L29_competitive,
    "L30": L30_how_it_works,
    "title": L01_title, "section": L02_section, "agenda": L03_agenda,
    "content": L04_content, "two_col": L05_two_col, "image_text": L06_image_text,
    "quote": L07_quote, "chart": L08_chart, "table": L09_table,
    "process": L10_process, "timeline": L11_timeline, "kpi": L12_kpi,
    "case_study": L13_case_study, "architecture": L14_architecture,
    "closing": L15_closing, "appendix": L16_appendix,
    "blank_dark": L17_blank_dark, "blank_light": L18_blank_light,
    "icon_sheet": L19_icon_sheet, "color_swatch": L20_color_swatch,
    "bento": L21_bento_grid, "before_after": L22_before_after,
    "logo_wall": L23_logo_wall, "metric_dashboard": L24_metric_dashboard,
    "full_bleed": L25_full_bleed_image, "team": L26_team,
    "thesis": L27_thesis, "why_now": L28_why_now,
    "competitive": L29_competitive, "how_it_works": L30_how_it_works,
}

ALL_LAYOUTS = [
    L01_title, L02_section, L03_agenda, L04_content,
    L05_two_col, L06_image_text, L07_quote, L08_chart,
    L09_table, L10_process, L11_timeline, L12_kpi,
    L13_case_study, L14_architecture, L15_closing, L16_appendix,
    L21_bento_grid, L22_before_after, L23_logo_wall,
    L24_metric_dashboard, L25_full_bleed_image, L26_team,
    L27_thesis, L28_why_now, L29_competitive, L30_how_it_works,
]

RESOURCE_LAYOUTS = [L19_icon_sheet, L20_color_swatch]

LAYOUT_NAMES = [
    "Title / Cover", "Section Divider", "Agenda / Contents",
    "Content (Single Message)", "Two-Column Comparison",
    "Image + Text", "Full-Bleed Quote", "Chart / Data Story",
    "Table", "Process / Flow", "Timeline / Roadmap",
    "Big Number / KPI", "Case Study", "Architecture / Diagram",
    "Closing / Next Steps", "Appendix / Reference",
    "Bento Grid", "Before / After", "Logo Wall",
    "Metric Dashboard", "Full-Bleed Image", "Team",
    "Thesis / Assertion", "Why Now", "Competitive Matrix",
    "How It Works",
    "Icon Reference", "Color Reference", "Blank",
]

__version__ = "0.1.0"
