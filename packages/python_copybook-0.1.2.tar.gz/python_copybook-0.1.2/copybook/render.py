"""COBOL copybook renderers.

This module converts CobolNode trees back into COBOL copybook strings.
It is intentionally separate from tree.py (which builds trees) and
parser.py (which reads them) — rendering is a distinct concern.

Renderers
---------
    render_copybook(roots, indent_size)
        Renders a full tree back to a COBOL copybook string. Depth-based
        indentation is applied so hierarchy is visually clear. Level numbers
        and field name casing are preserved from the source.

    render_flat_copybook(nodes, record_name, show_occurs)
        Renders a flat list of nodes (typically from build_flat_tree()) as
        a single-level copybook with all fields at level 05 under one 01 record.
        When show_occurs=True, fields that inherited an OCCURS context from a
        parent group get an inline *> comment showing the repeat count.

Indentation model
-----------------
    Fixed-format COBOL has two meaningful indent positions:

        Area A — column 8  (7 leading spaces)  — for 01 / 77 level fields
        Area B — column 12 (11 leading spaces) — for all subordinate fields

    Within Area B, render_copybook adds optional depth-based indent so that
    nested fields are visually offset from their parents. This is cosmetic —
    level numbers carry the actual structure — but makes the output readable.

    The indent_size parameter controls how many extra spaces are added per
    depth level beyond the root. Defaults to 4. Set to 0 for flat output
    where all non-root fields align at Area B.

    Continuation lines (statements that span multiple physical lines) always
    use CONTINUATION_INDENT regardless of depth, to distinguish them from
    new field declarations.
"""

from __future__ import annotations

import re

from copybook.models import CobolNode
from copybook.patterns import AREA_A_INDENT, AREA_B_INDENT, CONTINUATION_INDENT


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _indent_for_depth(depth: int, indent_size: int) -> str:
    """Compute the indent string for a given tree depth.

    Root fields (depth 0) always use Area A indent. All other fields
    use Area B indent plus additional spaces per depth level.

    Args:
        depth: Tree depth of the current node. 0 = root (01/77 level).
        indent_size: Number of extra spaces to add per depth level
            beyond the root. 0 produces flat Area B alignment.

    Returns:
        The full indent string to prepend to the field's declaration line.
    """
    if depth == 0:
        return AREA_A_INDENT
    return AREA_B_INDENT + (" " * indent_size * (depth - 1))


def _render_node_lines(
    node: CobolNode,
    depth: int = 0,
    indent_size: int = 4,
) -> list[str]:
    """Render a single node's declaration as one or more output lines.

    Uses the original CobolLine objects from the field's statement to
    reconstruct the declaration text verbatim, with only the leading
    indent adjusted for depth.

    Single-line statements produce one output line. Multi-line statements
    (e.g. a REDEFINES clause that wrapped across two physical lines) produce
    one line per source line, with continuation lines at CONTINUATION_INDENT
    so they are visually distinct from new field declarations.

    Args:
        node: The CobolNode to render.
        depth: Tree depth of this node. 0 = root (01/77). Controls indent.
        indent_size: Extra spaces per depth level beyond root. Defaults to 4.

    Returns:
        A list of strings, one per output line for this node's declaration.
    """
    source_lines = node.cobol_field.statement.source_lines
    indent = _indent_for_depth(depth, indent_size)
    output = []

    output.append(f"{indent}{source_lines[0].area.strip()}")
    for continuation in source_lines[1:]:
        output.append(f"{CONTINUATION_INDENT}{continuation.area.strip()}")

    return output


def _occurs_comment(node: CobolNode) -> str:
    """Build an inline *> comment describing the inherited OCCURS context.

    Only produces a comment if the node inherited an OCCURS context from an
    ancestor group. Fields that have their own OCCURS clause are not annotated
    — the clause is already visible in their own source text.

    Args:
        node: A flat CobolNode from build_flat_tree().

    Returns:
        An inline comment string e.g. ' *> OCCURS 450 DEPENDING ON I-SRVC-LINE-CNT'
        or an empty string if no inherited OCCURS context applies.
    """
    # Field has its own OCCURS — already visible in source text
    if node.cobol_field.is_array:
        return ""

    # No inherited context from any ancestor group
    if not node.inherited_occurs:
        return ""

    dep = (
        f" DEPENDING ON {node.inherited_depending_on}"
        if node.inherited_depending_on
        else ""
    )
    return f" *> OCCURS {node.inherited_occurs}{dep}"


# ---------------------------------------------------------------------------
# Public renderers
# ---------------------------------------------------------------------------


def render_copybook(
    roots: list[CobolNode],
    indent_size: int = 4,
) -> str:
    """Render a full COBOL copybook string from a tree of CobolNodes.

    Walks the tree in source order and reconstructs each field's declaration
    using the original statement area text. Level numbers and field name
    casing are preserved exactly as parsed from the source copybook.

    Depth-based indentation is applied within Area B so that child fields
    are visually offset from their parents. This is cosmetic — the level
    numbers carry the actual hierarchy — but makes the output readable.

    Multi-line statements are rendered with continuation lines at
    CONTINUATION_INDENT, regardless of depth.

    Args:
        roots: Root-level CobolNode objects from build_tree().
        indent_size: Number of extra spaces to add per depth level beyond
            the root. Defaults to 4. Set to 0 for flat Area B alignment.

    Returns:
        A string containing a valid fixed-format COBOL copybook definition
        with lines joined by newlines.

    Example (indent_size=4):
        '       01  Claim-Record.'
        '           12 Insured-Details.'
        '               15 Insured-Policy-No PIC 9(07).'
        '               15 Insured-Last-Name PIC X(15).'
        '           12 Policy-Details.'
        '               15 Policy-Type PIC 9.'
        '                   88 Private VALUE 1.'
    """
    output_lines: list[str] = []

    def _walk(node: CobolNode, depth: int) -> None:
        output_lines.extend(
            _render_node_lines(node, depth=depth, indent_size=indent_size)
        )
        for child in node.children:
            _walk(child, depth + 1)

    for root in roots:
        _walk(root, depth=0)

    return "\n".join(output_lines)


def _remap_level(area: str, new_level: int = 5) -> str:
    """Replace the leading level number in a statement area string.

    Used when rendering a flat copybook where all fields are remapped to
    level 05 regardless of their original level number.

    Args:
        area: Statement area text starting with a level number.
            e.g. '15 POLICY-TYPE PIC 9.'
        new_level: The level number to substitute in. Defaults to 5,
            which renders as '05'.

    Returns:
        Area string with the leading level number replaced.
            e.g. '05 POLICY-TYPE PIC 9.'
    """
    return re.sub(r"^\d+", f"{new_level:02}", area.strip())


def _inject_occurs(area: str, node: CobolNode) -> str:
    """Inject an inherited OCCURS clause directly into a field declaration.

    Inserts the OCCURS clause before the closing period so the output is
    valid COBOL rather than a comment annotation.

    Args:
        area: Remapped field declaration string ending with a period.
        node: Flat CobolNode carrying inherited_occurs context.

    Returns:
        Declaration string with OCCURS clause inserted before the period,
        or the original string unchanged if no inherited OCCURS applies.
    """
    if node.cobol_field.is_array or not node.inherited_occurs:
        return area

    occurs = f" OCCURS {node.inherited_occurs} TIMES"
    if node.inherited_depending_on:
        occurs += f" DEPENDING ON {node.inherited_depending_on}"

    return area.rstrip(".") + occurs + "."


def _wrap_lines(lines: list[str]) -> list[str]:
    """Wrap output lines to fixed-format 80-column COBOL.

    Content must fit within columns 8-72 (72 chars total including indent).
    Lines exceeding this are split at the nearest word boundary and
    continuation lines use CONTINUATION_INDENT.

    Args:
        lines: Output lines before joining.

    Returns:
        Lines with any overlong content wrapped.
    """
    result = []
    for line in lines:
        if len(line) <= 72:
            result.append(line)
        else:
            # Prefer splitting before DEPENDING so it stays together
            split_at = line.rfind(" DEPENDING", 0, 72)
            if split_at == -1:
                split_at = line.rfind(" ", 0, 72)
            if split_at == -1:
                split_at = 72

            result.append(line[:split_at])
            remainder = line[split_at:].strip()
            while remainder:
                wrapped = f"{CONTINUATION_INDENT}{remainder}"
                if len(wrapped) <= 72:
                    result.append(wrapped)
                    break
                split_at = wrapped.rfind(" DEPENDING", 0, 72)
                if split_at == -1:
                    split_at = wrapped.rfind(" ", 0, 72)
                if split_at == -1:
                    split_at = 72
                result.append(wrapped[:split_at])
                remainder = wrapped[split_at:].strip()
    return result


def render_flat_copybook(
    nodes: list[CobolNode],
    record_name: str = "FLAT-RECORD",
    show_occurs: bool = True,
    occurs_as_comment: bool = False,
) -> str:
    """Render a flat COBOL copybook with all fields at level 05.

    Intended for use with the output of build_flat_tree(), which produces
    a non-overlapping linear list of elementary fields. All fields are
    remapped to level 05 under a single 01 record header.

    The original area text from each field's source lines is used verbatim
    with only the level number remapped, so spacing, clause ordering, and
    field name casing are preserved from the source copybook.

    When show_occurs is True (the default), fields that inherited an OCCURS
    context from a parent group are annotated. The occurs_as_comment flag
    controls how that annotation appears:

        occurs_as_comment=False (default) — OCCURS is injected directly into
            the declaration before the closing period. The output is valid
            COBOL and a compiler will accept it.

        occurs_as_comment=True — OCCURS is appended as an inline *> comment
            after the period. The output is human-readable but not valid COBOL
            since the clause is outside the declaration.

    Fields that have their own OCCURS clause are never annotated — the clause
    is already present in their source text.

    Multi-line statements are rendered with continuation lines at
    CONTINUATION_INDENT.

    Args:
        nodes: List of CobolNode objects from build_flat_tree().
        record_name: Name for the generated 01 record header.
        show_occurs: If True, annotate fields that inherited an OCCURS context
            from an ancestor group. Defaults to True.
        occurs_as_comment: If True, render inherited OCCURS as an inline *>
            comment. If False (default), inject it directly into the
            declaration as a valid COBOL clause.

    Returns:
        A string containing a flat COBOL copybook definition with lines
        joined by newlines.

    Example output (show_occurs=True, occurs_as_comment=False) — valid COBOL:
        '       01  FLAT-MEMO.'
        '           05 I-PROVIDER-NUMBER    PIC X(06).'
        '           05 I-HCPCS              PIC X(05) OCCURS 450 TIMES DEPENDING ON I-SRVC-LINE-CNT.'

    Example output (show_occurs=True, occurs_as_comment=True) — human annotation:
        '       01  FLAT-MEMO.'
        '           05 I-PROVIDER-NUMBER    PIC X(06).'
        '           05 I-HCPCS              PIC X(05). *> OCCURS 450 DEPENDING ON I-SRVC-LINE-CNT'

    Example output (show_occurs=False) — clean, no annotation:
        '       01  FLAT-MEMO.'
        '           05 I-PROVIDER-NUMBER    PIC X(06).'
        '           05 I-HCPCS              PIC X(05).'
    """
    output_lines = [f"{AREA_A_INDENT}01  {record_name}."]

    for node in nodes:
        source_lines = node.cobol_field.statement.source_lines
        first = _remap_level(source_lines[0].area.strip())

        if show_occurs:
            if occurs_as_comment:
                # Append as *> comment — human readable, not valid COBOL
                comment = _occurs_comment(node)
                if comment:
                    first = first.rstrip(".") + "." + comment
            else:
                # Inject directly into declaration — valid COBOL
                first = _inject_occurs(first, node)

        output_lines.append(f"{AREA_B_INDENT}{first}")
        for continuation in source_lines[1:]:
            output_lines.append(f"{CONTINUATION_INDENT}{continuation.area.strip()}")

    output_lines = _wrap_lines(output_lines)
    return "\n".join(output_lines)
