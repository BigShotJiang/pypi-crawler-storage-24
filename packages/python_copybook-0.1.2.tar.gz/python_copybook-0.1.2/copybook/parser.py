from __future__ import annotations

import re

from copybook.models import CobolField, CobolLine, CobolStatement
from copybook.patterns import (
    AREA_A_INDENT,
    AREA_B_INDENT,
    CONTINUATION_INDENT,
    DEPENDING_RE,
    INDEXED_BY_RE,
    OCCURS_RE,
    PIC_RE,
    PREFIX_RE,
    REDEFINES_RE,
    RENAMES_RE,
    RENAMES_THRU_RE,
    RESERVED_WORDS,
    USAGE_RE,
    VALUE_RE,
)


# ---------------------------------------------------------------------------
# Stage 1 — Physical line reading
# ---------------------------------------------------------------------------


def read_copybook(copybook_path: str) -> list[CobolLine]:
    """Read a fixed-format COBOL copybook file into physical line objects.

    Each line is normalised to exactly 80 characters before column slicing:
        - CRLF and LF line endings are stripped
        - Tab characters are expanded (tab width 1) so column positions hold
        - Lines shorter than 80 characters are padded with spaces

    Lines are stored raw — no stripping of content occurs here. This ensures
    that CobolLine.raw_line can reconstruct the original 80-character record.

    Args:
        copybook_path: Absolute or relative path to the .cpy or .cbl file.

    Returns:
        A list of CobolLine objects, one per physical line in the file,
        in source order. Line numbers are 1-based.
    """
    with open(copybook_path, "r") as f:
        raw_lines = f.readlines()

    cobol_lines = []

    for idx, line in enumerate(raw_lines):
        # Normalise to 80 chars before column slicing.
        # rstrip removes CRLF/LF. expandtabs(1) converts tabs to spaces
        # using tab-stop width 1 (safest default for unknown editors).
        # ljust(80) pads lines shorter than 80 chars.
        padded = line.rstrip("\r\n").expandtabs(1).ljust(80)

        cobol_lines.append(
            CobolLine(
                copybook=copybook_path,
                line_number=idx + 1,
                sequence_number=padded[0:6],
                indicator=padded[6],
                area=padded[7:72],
                comment=padded[72:80],
            )
        )

    return cobol_lines


# ---------------------------------------------------------------------------
# Stage 2 — Statement assembly
# ---------------------------------------------------------------------------


def _strip_inline_comment(area: str) -> str:
    """Remove a COBOL inline comment from an area string.

    COBOL 2002 introduced the *> inline comment syntax. Everything from *>
    to the end of the area is a comment and must be removed before the area
    text is accumulated into a statement buffer, otherwise the *> text could
    prevent period detection or pollute clause matching.

    This is distinct from full-line comments (indicator * or /), which are
    handled by CobolLine.is_comment and skipped entirely before this function
    is ever called.

    Args:
        area: Raw area string, potentially containing a *> inline comment.

    Returns:
        Area string with everything from the first *> onward removed,
        and trailing whitespace stripped.

    Examples:
        >>> _strip_inline_comment("PIC 9(2). *> 00 or 30")
        'PIC 9(2).'
        >>> _strip_inline_comment("PIC X(10).")
        'PIC X(10).'
    """
    marker = area.find("*>")
    if marker != -1:
        area = area[:marker]
    return area.strip()


def _extract_area(line: CobolLine) -> str:
    """Extract and normalise the content area from a physical COBOL line.

    For normal lines, the full area is used. For continuation lines
    (indicator -), only area_b is used because area_a on a continuation
    line is blank by convention. If a continuation line is resuming a
    string literal, the leading quote character on area_b is stripped.

    Inline comments (*>) are stripped from the result regardless of line type.

    Args:
        line: A CobolLine whose area text should be extracted.

    Returns:
        Normalised area string ready to be accumulated into a statement buffer.
        Empty string if the line contributes no content.
    """
    if line.is_continuation:
        area = line.area_b.strip()
        # Strip the leading quote that opens a continued string literal.
        # e.g. area_b starts with '"WORLD"' when continuing 'HELLO '
        if area.startswith(("'", '"')):
            area = area[1:]
    else:
        area = line.area.strip()

    return _strip_inline_comment(area)


def read_statements(cobol_lines: list[CobolLine]) -> list[CobolStatement]:
    """Assemble physical COBOL lines into complete logical statements.

    In fixed-format COBOL, a single data declaration can span multiple
    physical lines. A statement is complete when its accumulated area text
    ends with a period. This function:

        - Skips full-line comments (indicator * or /)
        - Handles continuation lines (indicator -) via _extract_area
        - Strips inline comments (*> syntax) before accumulating
        - Collects COBOL reserved words found in each statement
        - Raises if the file ends with an unterminated statement

    The original CobolLine objects are stored on each statement for validation and
    reconstructions of the source lines.

    Args:
        cobol_lines: List of CobolLine objects from read_copybook().

    Returns:
        A list of CobolStatement objects in source order. Each statement
        holds the joined area text, the contributing CobolLine objects,
        the source copybook path, and the reserved words found.

    Raises:
        ValueError: If the last accumulated statement has no closing period,
            indicating the copybook file is malformed or truncated.
    """
    statements: list[CobolStatement] = []
    buffer_area: str = ""
    buffer_lines: list[CobolLine] = []
    buffer_reserved: list[str] = []

    for line in cobol_lines:
        if line.is_comment:
            continue

        area = _extract_area(line)
        if not area:
            continue

        # Accumulate area text — join with a single space when appending
        buffer_area = (buffer_area + " " + area).strip() if buffer_area else area

        # Record which reserved words appear in this line's contribution
        for word in area.split():
            if word.upper() in RESERVED_WORDS:
                buffer_reserved.append(word.upper())

        buffer_lines.append(line)

        # A period marks the end of a complete logical statement
        if buffer_area.endswith("."):
            statements.append(
                CobolStatement(
                    area=buffer_area,
                    source_lines=buffer_lines,
                    copybook=line.copybook,
                    reserved_words=buffer_reserved,
                )
            )
            buffer_area = ""
            buffer_lines = []
            buffer_reserved = []

    if buffer_area:
        line_numbers = [l.line_number for l in buffer_lines]
        raise ValueError(
            f"Unterminated statement starting at line {buffer_lines[0].line_number}, "
            f"spanning lines {line_numbers}: '{buffer_area}'"
        )

    return statements


# ---------------------------------------------------------------------------
# Stage 3 — Field parsing
# ---------------------------------------------------------------------------


def parse_field(statement: CobolStatement) -> CobolField | None:
    """Parse a single CobolStatement into a CobolField.

    Extracts the level number and field name from the fixed statement prefix,
    then searches for each optional clause independently in the remainder.
    Because each clause is found by content rather than position, the order
    of clauses in the source does not affect parsing.

    Clauses searched:
        PIC / PICTURE, REDEFINES, RENAMES, RENAMES THRU, USAGE, OCCURS,
        DEPENDING ON, INDEXED BY, VALUE / VALUES ARE

    SIGN LEADING/TRAILING SEPARATE and SYNCHRONIZED are detected via the
    reserved_words list on the statement rather than by re.search — both
    keywords have unambiguous meanings in a data definition context and
    reserved_words avoids re-searching the area string.

    Args:
        statement: A complete CobolStatement ending with a period.

    Returns:
        A CobolField if the statement matches a data definition (starts with
        a level number and a field name). Returns None if the statement does
        not match — e.g. it is a division header or unrecognised syntax.
        None results are logged as warnings by parse_fields().
    """
    prefix = PREFIX_RE.match(statement.area.strip())
    if not prefix:
        return None

    level, name = prefix.groups()

    # remainder is everything after the level number and field name,
    # with the closing period removed. All clause searches run on this.
    remainder = statement.area[prefix.end() :].rstrip(".")

    pic = PIC_RE.search(remainder)
    redefines = REDEFINES_RE.search(remainder)
    renames = RENAMES_RE.search(remainder)
    renames_thru = RENAMES_THRU_RE.search(remainder)
    usage = USAGE_RE.search(remainder)
    occurs = OCCURS_RE.search(remainder)
    depending = DEPENDING_RE.search(remainder)
    indexed = INDEXED_BY_RE.search(remainder)
    value = VALUE_RE.search(remainder)

    return CobolField(
        statement=statement,
        level=int(level),
        name=name.upper(),
        picture=pic.group(1).upper() if pic else None,
        redefines=redefines.group(1).upper() if redefines else None,
        renames=renames.group(1).upper() if renames else None,
        renames_thru=renames_thru.group(1).upper() if renames_thru else None,
        usage=usage.group(1).upper() if usage else None,
        occurs=int(occurs.group(1)) if occurs else None,
        occurs_max=int(occurs.group(2)) if occurs and occurs.group(2) else None,
        depending_on=depending.group(1).upper() if depending else None,
        indexed_by=indexed.group(1).upper() if indexed else None,
        value=value.group(1).strip() if value else None,
        # SEPARATE only appears in SIGN LEADING/TRAILING SEPARATE context
        sign_separate="SEPARATE" in statement.reserved_words,
        synchronized=(
            "SYNCHRONIZED" in statement.reserved_words
            or "SYNC" in statement.reserved_words
        ),
        source_lines=statement.source_lines,
        copybook=statement.copybook,
    )


def parse_fields(statements: list[CobolStatement]) -> list[CobolField]:
    """Parse all statements into a flat list of CobolField objects.
    Args:
        statements: List of CobolStatement objects from read_statements().

    Returns:
        Flat list of CobolField objects in source order. Statements that
        could not be parsed are omitted; a warning is printed for each.
    """
    fields: list[CobolField] = []

    for statement in statements:
        cobol_field = parse_field(statement)
        if cobol_field is None:
            line_numbers = [l.line_number for l in statement.source_lines]
            print(f"WARNING: could not parse lines {line_numbers}: {statement.area}")
        else:
            fields.append(cobol_field)

    return fields
