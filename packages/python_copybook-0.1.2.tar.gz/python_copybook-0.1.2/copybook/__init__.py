"""python-copybook — fixed-format COBOL copybook parser.

Public API
----------
Parser:
    read_copybook       — file → list[CobolLine]
    read_statements     — list[CobolLine] → list[CobolStatement]
    parse_fields        — list[CobolStatement] → list[CobolField]

Tree builders:
    build_tree          — full hierarchy, mirrors source exactly
    build_flat_tree     — elementary fields only, no groups/88s/REDEFINES

Renderers:
    render_copybook     — full tree → COBOL string, original levels preserved
    render_flat_copybook — flat nodes → level-05 copybook under one 01 record

Models:
    CobolLine           — one physical 80-column line
    CobolStatement      — one logical declaration (may span multiple lines)
    CobolField          — one parsed data field with all clauses extracted
    CobolNode           — one node in a hierarchy tree, wraps a CobolField

Typical usage:
    from copybook import read_copybook, read_statements, parse_fields
    from copybook import build_tree, render_copybook

    lines      = read_copybook("MY.cpy")
    statements = read_statements(lines)
    fields     = parse_fields(statements)
    tree       = build_tree(fields)
    print(render_copybook(tree))
"""

from copybook.parser import read_copybook, read_statements, parse_field, parse_fields
from copybook.tree import build_tree, build_flat_tree
from copybook.render import render_copybook, render_flat_copybook
from copybook.models import CobolLine, CobolStatement, CobolField, CobolNode

__all__ = [
    # Parser
    "read_copybook",
    "read_statements",
    "parse_field",
    "parse_fields",
    # Tree
    "build_tree",
    "build_flat_tree",
    # Render
    "render_copybook",
    "render_flat_copybook",
    # Models
    "CobolLine",
    "CobolStatement",
    "CobolField",
    "CobolNode",
]
