"""COBOL copybook data models.

This module defines the four-layer data model used to represent a COBOL
copybook at increasing levels of abstraction:

    CobolLine      — one physical line from the file (1:1 with lines on disk)
    CobolStatement — one logical declaration (may span multiple CobolLines)
    CobolField     — one parsed data field (extracted from a CobolStatement)
    CobolNode      — one node in a hierarchy tree (wraps a CobolField)

Each layer is a pure data container. No parsing logic lives here.

Serialization note:
    CobolLine, CobolStatement, and CobolField use the default asdict()-based
    to_dict() from CobolBase. CobolNode overrides to_dict() because its
    parent reference creates a circular structure that asdict() cannot handle.
"""

from __future__ import annotations

from dataclasses import dataclass, field as dc_field, asdict
import json
import re


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _json_str(data: dict, indent: int = 2) -> str:
    """Serialize a dict to a JSON string with arrays collapsed to one line.

    Args:
        data: A dict to serialize.
        indent: Number of spaces to use for JSON indentation.

    Returns:
        A JSON string with list fields rendered on a single line.
    """
    raw = json.dumps(data, indent=indent)
    return re.sub(
        r"\[\s*([^\]]*?)\s*\]",
        lambda m: "[" + " ".join(m.group(1).split()) + "]",
        raw,
        flags=re.DOTALL,
    )


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


@dataclass
class CobolBase:
    """Base class for all COBOL model dataclasses.

    Provides a shared JSON serialization method. CobolNode overrides this
    to handle its circular parent reference.
    """

    def to_dict(self, indent: int = 2) -> str:
        """Serialize this instance to a JSON string.

        Arrays are collapsed to a single line for readability.

        Args:
            indent: Number of spaces to use for JSON indentation.

        Returns:
            JSON string representation of this instance.
        """
        return _json_str(asdict(self), indent)


# ---------------------------------------------------------------------------
# Layer 1 — Physical line
# ---------------------------------------------------------------------------


@dataclass
class CobolLine(CobolBase):
    """A single physical line from a fixed-format COBOL copybook file.

    Fixed-format COBOL divides each 80-character line into four named regions:

        Columns 1–6   (index 0:6)  — Sequence number  (optional line numbering)
        Column  7     (index 6)    — Indicator         (*, /, -, D, or space)
        Columns 8–72  (index 7:72) — Area              (actual COBOL content)
        Columns 73–80 (index 72:80)— Identification    (free-form comment/label)

    CobolLine stores all four regions exactly as read from disk — no stripping,
    no normalisation beyond CRLF removal and tab expansion needed to make
    column slicing reliable. This preserves round-trip fidelity: raw_line
    reconstructs the original 80-character record.

    Attributes:
        copybook: Path to the source copybook file.
        line_number: 1-based line number within the file.
        sequence_number: Raw columns 1–6 (may be blank or numeric).
        indicator: Single character at column 7. Space = normal code line.
        area: Raw columns 8–72. Contains the COBOL declaration text.
        comment: Raw columns 73–80. Free-form, ignored by the compiler.
    """

    copybook: str
    line_number: int
    sequence_number: str
    indicator: str
    area: str
    comment: str

    @property
    def area_a(self) -> str:
        """Columns 8–11 of the original line (first 4 chars of area).

        Level numbers 01 and 77, section headers, and FD/SD entries must
        start in Area A. Used to distinguish top-level declarations.
        """
        return self.area[0:4]

    @property
    def area_b(self) -> str:
        """Columns 12–72 of the original line (chars 4 onward of area).

        All subordinate data entries and statements start in Area B.
        Continuation lines (-) supply their content starting here.
        """
        return self.area[4:]

    @property
    def is_comment(self) -> bool:
        """True if this line is a full-line comment.

        An asterisk (*) or slash (/) in the indicator column makes the
        entire line a comment. The area text is ignored by the compiler.
        """
        return self.indicator in ("*", "/")

    @property
    def is_continuation(self) -> bool:
        """True if this line continues the previous logical statement.

        A hyphen (-) in the indicator column means this line's area_b
        content should be appended to the previous line's area. The first
        character of area_b may be a leading quote that must be stripped
        when continuing a string literal.
        """
        return self.indicator == "-"

    @property
    def raw_line(self) -> str:
        """Reconstruct the original 80-character fixed-format line.

        Pads each region to its correct width so the result matches what
        was on disk before readlines() stripped the line ending.

        Returns:
            An 80-character string in fixed-format COBOL layout.
        """
        return (
            f"{self.sequence_number:<6}{self.indicator}{self.area:<65}{self.comment:<8}"
        )


# ---------------------------------------------------------------------------
# Layer 2 — Logical statement
# ---------------------------------------------------------------------------


@dataclass
class CobolStatement(CobolBase):
    """A complete logical COBOL data declaration.

    In fixed-format COBOL, a single logical declaration can span multiple
    physical lines. A statement is considered complete when its accumulated
    area text ends with a period.

    CobolStatement is produced by read_statements(), which joins physical
    lines until a period is found. The original CobolLine objects are
    retained in source_lines for traceability and for reconstructing
    multi-line output.

    Attributes:
        area: The full joined declaration text, including the closing period.
            e.g. '15 Policy-Benefit-Date-X REDEFINES Policy-Benefit-Date-Num PIC X(08).'
        source_lines: The CobolLine objects that contributed to this statement,
            in order. Single-line statements have one entry; multi-line
            statements have two or more.
        copybook: Path to the source copybook file.
        reserved_words: COBOL reserved words found in this statement's area,
            uppercased. Used downstream to quickly check which clauses are
            present without re-searching the area string.
    """

    area: str
    source_lines: list[CobolLine]
    copybook: str
    reserved_words: list[str]


# ---------------------------------------------------------------------------
# Layer 3 — Parsed field
# ---------------------------------------------------------------------------


@dataclass
class CobolField(CobolBase):
    """A parsed COBOL data field definition.

    CobolField is produced by parse_field(), which extracts each clause
    from a CobolStatement using independent regex searches. Clause order
    in the source does not matter — each clause is found by content, not
    by position.

    Tree structure (parent/children) is NOT stored on CobolField. It lives
    on CobolNode so that multiple independent tree views can be built over
    the same set of CobolField objects without mutating the field data.

    Attributes:
        statement: The originating CobolStatement. Retained for access to
            the original area text and source lines, particularly for
            multi-line statement reconstruction in output rendering.
        level: Numeric level number (1, 5, 10, 12, 15, 66, 77, 88, etc.).
        name: Field name, uppercased. FILLER for anonymous fields.
        picture: PIC clause string, uppercased. None for group fields.
            e.g. '9(07)', 'X(15)', 'S9(7)V99'.
        redefines: Name of the field being redefined, uppercased. None if
            no REDEFINES clause. The field overlays the same bytes as the
            target field.
        renames: Name of the first field in a level-66 RENAMES range.
        renames_thru: Name of the last field in a RENAMES THRU range.
        value: VALUE clause content as a raw string. May be a quoted string,
            a numeric literal, or a figurative constant.
        usage: Storage format keyword, uppercased. e.g. 'COMP-3', 'BINARY',
            'DISPLAY'. None means DISPLAY (the default).
        occurs: Fixed array size from OCCURS n TIMES. None if not an array.
        occurs_max: Upper bound from OCCURS n TO m TIMES. None if fixed or
            not an array.
        depending_on: Field name from DEPENDING ON clause, uppercased. Marks
            a variable-length array whose current size is stored elsewhere.
        indexed_by: Index name from INDEXED BY clause, uppercased. Names the
            internal index used to subscript an OCCURS table.
        sign_separate: True if SIGN LEADING SEPARATE or SIGN TRAILING SEPARATE
            is present. The sign occupies its own byte rather than being
            embedded in the high-order digit.
        synchronized: True if SYNCHRONIZED or SYNC is present. The field is
            aligned to a machine word boundary, which affects byte offsets.
        source_lines: The CobolLine objects from the originating statement.
            Duplicated here from statement.source_lines for direct access.
        copybook: Path to the source copybook file.
    """

    statement: CobolStatement
    level: int
    name: str
    picture: str | None
    redefines: str | None
    renames: str | None
    renames_thru: str | None
    value: str | None
    usage: str | None
    occurs: int | None
    occurs_max: int | None
    depending_on: str | None
    indexed_by: str | None
    sign_separate: bool
    synchronized: bool
    source_lines: list[CobolLine]
    copybook: str

    # --- Identity -----------------------------------------------------------

    @property
    def is_filler(self) -> bool:
        """True if this is an anonymous FILLER field.

        FILLER fields hold padding bytes and cannot be referenced by name
        in COBOL procedure code.
        """
        return self.name == "FILLER"

    @property
    def is_condition(self) -> bool:
        """True if this is a level-88 condition name.

        Level-88 fields define named boolean conditions on their parent
        field's value. They do not occupy storage themselves — they are
        not real data fields and must be excluded from offset calculations.
        """
        return self.level == 88

    # --- Structure ----------------------------------------------------------

    @property
    def is_group(self) -> bool:
        """True if this field is a group (no PIC clause).

        Group fields have no PIC clause of their own. Their byte length is
        determined by the sum of their elementary children. A RENAMES field
        is not a group — it references existing storage rather than defining
        new structure.
        """
        return self.picture is None and self.renames is None

    @property
    def is_redefine(self) -> bool:
        """True if this field overlays the storage of another field.

        REDEFINES fields share bytes with the field they redefine. They must
        not advance the byte offset when computing field positions.
        """
        return self.redefines is not None

    @property
    def is_rename(self) -> bool:
        """True if this is a level-66 RENAMES field.

        RENAMES creates an alternative grouping over a range of existing
        fields. Level 66 is a special level that cannot have children.
        """
        return self.renames is not None

    # --- Arrays -------------------------------------------------------------

    @property
    def is_array(self) -> bool:
        """True if this field has a fixed-length OCCURS clause."""
        return self.occurs is not None

    @property
    def is_variable_array(self) -> bool:
        """True if this field has a variable-length OCCURS DEPENDING ON clause.

        The actual number of occurrences at runtime is stored in the field
        named by depending_on, up to a maximum of occurs_max.
        """
        return self.depending_on is not None

    # --- Data type ----------------------------------------------------------

    @property
    def is_numeric(self) -> bool:
        """True if the PIC clause contains digit positions (9).

        Numeric fields hold only digit characters (and possibly a sign or
        decimal point). Non-numeric fields use X, A, or editing characters.
        """
        return self.picture is not None and "9" in self.picture.upper()

    @property
    def is_signed(self) -> bool:
        """True if the PIC clause begins with S, indicating a signed number.

        Signed fields can hold negative values. The sign may be embedded
        in the leading digit byte (default) or occupy a separate byte
        (when sign_separate is True).
        """
        return self.picture is not None and self.picture.upper().startswith("S")


# ---------------------------------------------------------------------------
# Layer 4 — Tree node
# ---------------------------------------------------------------------------


@dataclass
class CobolNode(CobolBase):
    """A node in a COBOL field hierarchy tree.

    Wraps a CobolField with parent and child references for tree traversal.
    Separating tree structure from field data allows multiple independent
    tree views to be built over the same set of CobolField objects without
    mutating the fields themselves.

    tree.py provides two tree builders:
        build_tree()      — full hierarchy, mirrors source structure exactly
        build_flat_tree() — elementary fields only, no groups or REDEFINES

    Serialization:
        to_dict() is overridden here because the parent reference creates a
        circular structure that dataclasses.asdict() cannot handle. Parent is
        serialized as a name string only to break the cycle.

    Attributes:
        cobol_field: The CobolField this node represents.
        parent: Direct reference to the parent CobolNode, or None for roots.
        children: Direct child CobolNode objects in source order.
        inherited_occurs: For nodes under an OCCURS clause, the number of
            occurrences inherited from the nearest ancestor with OCCURS
        inherited_depending_on: For nodes under a variable OCCURS DEPENDING ON,
            the name of the depending_on field inherited from the nearest ancestor
            with a variable OCCURS.
    """

    cobol_field: CobolField
    parent: "CobolNode | None" = None
    children: list["CobolNode"] = dc_field(default_factory=list)
    inherited_occurs: int | None = None
    inherited_depending_on: str | None = None

    @property
    def level(self) -> int:
        """Shortcut to the wrapped field's level number."""
        return self.cobol_field.level

    @property
    def name(self) -> str:
        """Shortcut to the wrapped field's name."""
        return self.cobol_field.name

    def _to_serializable(self) -> dict:
        """Recursively build a serializable dict for this node.

        Serializes only the meaningful field attributes — not the full nested
        chain of CobolStatement and CobolLine objects — to keep output concise.
        Parent is serialized as a name string to break the circular reference.

        Returns:
            A dict safe to pass to json.dumps().
        """
        f = self.cobol_field
        return {
            "name": f.name,
            "level": f.level,
            "picture": f.picture,
            "redefines": f.redefines,
            "renames": f.renames,
            "renames_thru": f.renames_thru,
            "value": f.value,
            "usage": f.usage,
            "occurs": f.occurs,
            "occurs_max": f.occurs_max,
            "depending_on": f.depending_on,
            "indexed_by": f.indexed_by,
            "sign_separate": f.sign_separate,
            "synchronized": f.synchronized,
            "source_lines": [l.line_number for l in f.source_lines],
            "copybook": f.copybook,
            "parent": self.parent.name if self.parent else None,
            "children": [child._to_serializable() for child in self.children],
        }

    def to_dict(self, indent: int = 2) -> str:
        """Serialize this node and its descendants to a JSON string.

        Overrides CobolBase.to_dict to handle the circular parent reference.
        Parent is rendered as a name string rather than a full node.

        Arrays (source_lines) are collapsed to a single line for readability.

        Args:
            indent: Number of spaces to use for JSON indentation.

        Returns:
            JSON string representation of this node and its descendants.
        """
        return _json_str(self._to_serializable(), indent)
