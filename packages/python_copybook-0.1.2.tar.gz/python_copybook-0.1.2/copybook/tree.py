"""COBOL copybook tree builders and copybook renderers.

This module provides two tree views over a flat list of CobolField objects,
and two copybook rendering functions that produce COBOL output from those trees.

Tree builders
-------------
    build_tree(fields)
        Full hierarchy — mirrors the source copybook structure exactly.
        Includes group fields, elementary fields, level-88 condition names,
        and REDEFINES fields. Use when you need the complete picture.

    build_flat_tree(fields)
        Elementary fields only — no groups, no level-88s, no REDEFINES.
        All nodes are unlinked (no parent or children).
        Use for offset calculation or any non-overlapping linear record view.
"""

from __future__ import annotations

import re

from copybook.models import CobolField, CobolNode
from copybook.patterns import AREA_A_INDENT, AREA_B_INDENT, CONTINUATION_INDENT


# ---------------------------------------------------------------------------
# Tree builders
# ---------------------------------------------------------------------------


def build_tree(fields: list[CobolField]) -> list[CobolNode]:
    """Build a full hierarchy tree from a flat list of CobolFields.

    Walks the flat field list in source order. Uses a stack to track the
    current path from the root — when a field with a lower level number
    is encountered, the stack is popped back to the nearest ancestor.

    Includes all field types: groups, elementary fields, level-88 condition
    names, and REDEFINES fields. The tree mirrors the source copybook exactly.

    Args:
        fields: Flat list of CobolField objects in source order, as returned
            by parse_fields().

    Returns:
        List of root-level CobolNode objects (level 01 or 77). All other
        nodes are reachable via .children on each node.
    """
    roots: list[CobolNode] = []
    stack: list[CobolNode] = []

    for f in fields:
        node = CobolNode(cobol_field=f)

        # Pop ancestors at the same or deeper level — they are closed
        while stack and stack[-1].level >= f.level:
            stack.pop()

        if stack:
            node.parent = stack[-1]
            stack[-1].children.append(node)
        else:
            node.parent = None
            roots.append(node)

        stack.append(node)

    return roots


def build_flat_tree(fields: list[CobolField]) -> list[CobolNode]:
    """Build a flat list of nodes containing only elementary non-overlapping fields.

    Builds a full tree internally, then walks it to collect only the fields
    that represent actual storage — excluding:
        - Group fields (no PIC clause — storage is defined by their children)
        - Level-88 condition names (no storage, named boolean conditions only)
        - REDEFINES fields and all their descendants (overlapping storage)

    OCCURS context is propagated downward — if a group field has an OCCURS
    clause, all of its elementary descendants inherit it. This means a flat
    node's effective repeat count may come from an ancestor, not the field
    itself. Use inherited_occurs and inherited_depending_on on each node
    to get the full picture for offset and length calculation.

    All returned nodes are unlinked: parent is None and children is empty.

    Args:
        fields: Flat list of CobolField objects in source order from parse_fields().

    Returns:
        List of unlinked CobolNode objects in source order, one per elementary
        non-overlapping field. Each node carries inherited_occurs and
        inherited_depending_on from its nearest OCCURS ancestor, if any.
    """
    full_tree = build_tree(fields)
    result: list[CobolNode] = []

    def _walk(
        node: CobolNode,
        in_redefine: bool = False,
        inherited_occurs: int | None = None,
        inherited_depending_on: str | None = None,
    ) -> None:
        """Recursively collect elementary non-redefining fields.

        Args:
            node: Current node being visited.
            in_redefine: True if any ancestor has a REDEFINES clause.
                Propagated downward so entire REDEFINES subtrees are excluded.
            inherited_occurs: OCCURS count from the nearest ancestor group
                that had an OCCURS clause. None if no ancestor has OCCURS.
            inherited_depending_on: DEPENDING ON field name from the nearest
                ancestor OCCURS, if it was variable-length.
        """
        if node.cobol_field.is_condition:
            return

        currently_redefining = in_redefine or node.cobol_field.is_redefine

        # If this node has its own OCCURS, it takes over as the context
        # for all descendants — overrides any ancestor OCCURS
        occurs = node.cobol_field.occurs or inherited_occurs
        depending_on = node.cobol_field.depending_on or inherited_depending_on

        if not node.cobol_field.is_group and not currently_redefining:
            flat_node = CobolNode(
                cobol_field=node.cobol_field,
                inherited_occurs=occurs,
                inherited_depending_on=depending_on,
            )
            result.append(flat_node)

        for child in node.children:
            _walk(child, currently_redefining, occurs, depending_on)

    for root in full_tree:
        _walk(root)

    return result
