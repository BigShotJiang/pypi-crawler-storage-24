#!/usr/bin/env python3
"""MoMCP-TUI 交互式管理面板 - CLI 入口"""

from InquirerPy import inquirer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
import subprocess
import sys
import platform
from pathlib import Path

console = Console()


class MoMCPManager:
    """MoMCP-TUI 管理器"""
    
    def __init__(self):
        self.package_name = "momcp-tui"
        self.entry_command = "momcp-tui"
        self.self_package_name = "momcp"
        self.self_entry_command = "momcp"
        
    def check_python_version(self) -> bool:
        """检查 Python 版本"""
        if sys.version_info < (3, 10):
            return False
        return True
    
    def is_installed(self) -> bool:
        """检查是否已安装"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.package_name],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def get_installed_version(self) -> str:
        """获取已安装版本"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.package_name],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                for line in result.stdout.split("\n"):
                    if line.startswith("Version:"):
                        return line.split(":")[1].strip()
        except Exception:
            pass
        return "未知"
    
    def get_latest_version(self) -> str:
        """获取最新版本号"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "index", "versions", self.package_name],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                lines = result.stdout.split("\n")
                if len(lines) > 0:
                    version_line = lines[0]
                    if "(" in version_line and ")" in version_line:
                        start = version_line.find("(") + 1
                        end = version_line.find(")")
                        return version_line[start:end]
        except Exception:
            pass
        return "unknown"
    
    def install(self) -> bool:
        """安装 MoMCP-TUI"""
        console.print("\n")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("正在安装 MoMCP-TUI...", total=None)
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "-U", self.package_name],
                    capture_output=False,
                    text=True
                )
                
                if result.returncode == 0:
                    progress.update(task, completed=100)
                    return True
                else:
                    return False
            except Exception as e:
                console.print(f"[red]安装失败：{e}[/]")
                return False
    
    def uninstall(self) -> bool:
        """卸载 MoMCP-TUI"""
        console.print("\n")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("正在卸载 MoMCP-TUI...", total=None)
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "uninstall", "-y", self.package_name],
                    capture_output=False,
                    text=True
                )
                
                if result.returncode == 0:
                    progress.update(task, completed=100)
                    return True
                else:
                    return False
            except Exception as e:
                console.print(f"[red]卸载失败：{e}[/]")
                return False
    
    def update(self) -> bool:
        """更新 MoMCP-TUI"""
        console.print("\n")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("正在更新 MoMCP-TUI...", total=None)
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--upgrade", self.package_name],
                    capture_output=False,
                    text=True
                )
                
                if result.returncode == 0:
                    progress.update(task, completed=100)
                    return True
                else:
                    return False
            except Exception as e:
                console.print(f"[red]更新失败：{e}[/]")
                return False
    
    def is_self_installed(self) -> bool:
        """检查 momcp 自身是否已安装"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.self_package_name],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def get_self_version(self) -> str:
        """获取 momcp 自身已安装版本"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.self_package_name],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                for line in result.stdout.split("\n"):
                    if line.startswith("Version:"):
                        return line.split(":")[1].strip()
        except Exception:
            pass
        return "未知"
    
    def get_self_latest_version(self) -> str:
        """获取 momcp 自身最新版本号"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "index", "versions", self.self_package_name],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                lines = result.stdout.split("\n")
                if len(lines) > 0:
                    version_line = lines[0]
                    if "(" in version_line and ")" in version_line:
                        start = version_line.find("(") + 1
                        end = version_line.find(")")
                        return version_line[start:end]
        except Exception:
            pass
        return "unknown"
    
    def update_self(self) -> bool:
        """更新 momcp 自身"""
        console.print("\n")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("正在更新 momcp...", total=None)
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--upgrade", self.self_package_name],
                    capture_output=False,
                    text=True
                )
                
                if result.returncode == 0:
                    progress.update(task, completed=100)
                    return True
                else:
                    return False
            except Exception as e:
                console.print(f"[red]更新失败：{e}[/]")
                return False
    
    def launch(self) -> bool:
        """启动 MoMCP-TUI"""
        try:
            console.print("\n[bold cyan]正在启动 MoMCP-TUI...[/]\n")
            subprocess.run([self.entry_command])
            return True
        except KeyboardInterrupt:
            console.print("\n[yellow]程序已退出[/]")
            return True
        except FileNotFoundError:
            console.print("[red]错误：未找到 momcp-tui 命令，请先安装程序[/]")
            return False
        except Exception as e:
            console.print(f"[red]启动失败：{e}[/]")
            return False


def show_banner():
    """显示欢迎横幅"""
    banner = """
     ▄▄       ▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄       ▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄ 
    ▐░░▌     ▐░░▌▐░░░░░░░░░░░▌▐░░▌     ▐░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌
    ▐░▌░▌   ▐░▐░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌░▌   ▐░▐░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌
    ▐░▌▐░▌ ▐░▌▐░▌▐░▌       ▐░▌▐░▌▐░▌ ▐░▌▐░▌▐░▌          ▐░▌       ▐░▌
    ▐░▌ ▐░▐░▌ ▐░▌▐░▌       ▐░▌▐░▌ ▐░▐░▌ ▐░▌▐░▌          ▐░█▄▄▄▄▄▄▄█░▌
    ▐░▌  ▐░▌  ▐░▌▐░▌       ▐░▌▐░▌  ▐░▌  ▐░▌▐░▌          ▐░░░░░░░░░░░▌
    ▐░▌   ▀   ▐░▌▐░▌       ▐░▌▐░▌   ▀   ▐░▌▐░▌          ▐░█▀▀▀▀▀▀▀▀▀ 
    ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌          ▐░▌          
    ▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄▄▄ ▐░▌          
    ▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░▌          
     ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀           
                                                                 
    
                  ╔══════════════════════════════════════════╗
                  ║                                          ║
                  ║        Multi-MCP Tool Orchestrator       ║
                  ║                                          ║
                  ╚══════════════════════════════════════════╝
    """
    console.print(Panel(banner, style="bold cyan", border_style="bright_cyan", title="MoMCP", title_align="center"))


def show_system_info(manager: MoMCPManager):
    """显示系统信息"""
    installed = manager.is_installed()
    version = manager.get_installed_version() if installed else "未安装"
    self_installed = manager.is_self_installed()
    self_version = manager.get_self_version() if self_installed else "未安装"
    
    info_lines = [
        f"[bold]系统信息:[/]",
        f"  - Python 版本：{sys.version.split()[0]}",
        f"  - 操作系统：{platform.system()} {platform.release()}",
        f"  - momcp 状态：{'[green]已安装[/]' if self_installed else '[red]未安装[/]'} (版本：[cyan]{self_version}[/])",
        f"  - MoMCP-TUI 状态：{'[green]已安装[/]' if installed else '[red]未安装[/]'} (版本：[cyan]{version}[/])",
    ]
    
    info_panel = Panel(
        "\n".join(info_lines),
        title="状态面板",
        border_style="blue"
    )
    console.print(info_panel)


def main_menu(manager: MoMCPManager):
    """主菜单"""
    while True:
        console.print("\n")
        
        # 获取当前状态
        installed = manager.is_installed()
        version = manager.get_installed_version() if installed else "未安装"
        self_installed = manager.is_self_installed()
        self_version = manager.get_self_version() if self_installed else "未安装"
        
        # 动态生成菜单选项
        choices = []
        
        # momcp 自我更新选项
        if self_installed:
            choices.append({
                "name": f"[F1] 更新 MoMCP-TUI 管理器 (当前：{self_version})",
                "value": "update_self"
            })
        
        # MoMCP-TUI 相关选项
        if not installed:
            choices.append({
                "name": "[F2] 安装 MoMCP-TUI",
                "value": "install"
            })
        else:
            choices.append({
                "name": "[F2] 启动 MoMCP-TUI",
                "value": "launch"
            })
            choices.append({
                "name": "[F3] 更新 MoMCP-TUI",
                "value": "update"
            })
            choices.append({
                "name": "[F4] 卸载 MoMCP-TUI",
                "value": "uninstall"
            })
        
        choices.append({
            "name": "[F5] 查看帮助",
            "value": "help"
        })
        choices.append({
            "name": "[ESC] 退出",
            "value": "exit"
        })
        
        # 显示菜单
        action = inquirer.select(
            message="请选择操作:",
            choices=choices,
            default=choices[0]
        ).execute()
        
        # 处理选择
        if action == "exit":
            confirm = inquirer.confirm(
                message="确定要退出吗？",
                default=True
            ).execute()
            
            if confirm:
                console.print("\n[yellow]再见！[/]\n")
                break
            continue
        
        elif action == "update_self":
            current_version = manager.get_self_version()
            latest_version = manager.get_self_latest_version()
            
            console.print(f"\n当前版本：[yellow]{current_version}[/]")
            console.print(f"最新版本：[green]{latest_version}[/]")
            
            if current_version != latest_version:
                confirm = inquirer.confirm(
                    message="发现新版本，是否更新？",
                    default=True
                ).execute()
                
                if confirm:
                    if manager.update_self():
                        console.print("\n[green]momcp 更新成功！[/]")
                        console.print("[cyan]请重新启动程序以使用新功能[/]")
                    else:
                        console.print("\n[red]更新失败[/]")
            else:
                console.print("\n[cyan]✓ 已是最新版本[/]")
        
        elif action == "install":
            if manager.install():
                console.print("\n[green]MoMCP-TUI 安装成功！[/]")
                console.print(f"[cyan]运行 `{manager.entry_command}` 启动程序[/]")
            else:
                console.print("\n[red]安装失败[/]")
        
        elif action == "launch":
            manager.launch()
        
        elif action == "update":
            current_version = manager.get_installed_version()
            latest_version = manager.get_latest_version()
            
            console.print(f"\n当前版本：[yellow]{current_version}[/]")
            console.print(f"最新版本：[green]{latest_version}[/]")
            
            if current_version != latest_version:
                confirm = inquirer.confirm(
                    message="发现新版本，是否更新？",
                    default=True
                ).execute()
                
                if confirm:
                    if manager.update():
                        console.print("\n[green]更新成功！[/]")
                    else:
                        console.print("\n[red]更新失败[/]")
            else:
                console.print("\n[cyan]✓ 已是最新版本[/]")
        
        elif action == "uninstall":
            confirm = inquirer.confirm(
                message="确定要卸载 MoMCP-TUI 吗？",
                default=False
            ).execute()
            
            if confirm:
                second_confirm = inquirer.confirm(
                    message="此操作不可逆，确认继续？",
                    default=False
                ).execute()
                
                if second_confirm:
                    if manager.uninstall():
                        console.print("\n[green]卸载成功！[/]")
                    else:
                        console.print("\n[red]卸载失败[/]")
                else:
                    console.print("\n[yellow]已取消卸载[/]")
            else:
                console.print("\n[yellow]已取消卸载[/]")
        
        elif action == "help":
            show_help()


def show_help():
    """显示帮助信息"""
    help_text = """
[bold]MoMCP-TUI 使用说明[/]

[bold]快速命令:[/]
  - 安装：pip install momcp-tui
  - 启动：momcp-tui
  - 更新：pip install --upgrade momcp-tui
  - 卸载：pip uninstall momcp-tui

[bold]功能特性:[/]
  - 多模型对话 - OpenAI、DeepSeek、通义千问、Kimi
  - MCP 工具集成 - 文件操作、代码编辑、联网搜索
  - TUI 界面 - 优雅的终端交互体验

[bold]配置文件:[/]
  - 位置：~/.momcp/config.toml

[bold]常用命令:[/]
  - /model list - 查看可用模型
  - /model set NAME - 切换模型
  - /api_key set KEY - 设置 API Key
  - /allow add PATH - 添加文件白名单
  - /help - 显示帮助文档
"""
    console.print(Panel(help_text, title="帮助文档", border_style="green"))


def main():
    """CLI 入口函数"""
    try:
        # 检查 Python 版本
        if not MoMCPManager().check_python_version():
            console.print("[red]错误：需要 Python 3.10 或更高版本[/]")
            sys.exit(1)
        
        # 显示横幅
        show_banner()
        
        # 创建管理器
        manager = MoMCPManager()
        
        # 显示系统信息
        show_system_info(manager)
        
        # 进入主菜单
        main_menu(manager)
        
    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠ 程序被中断[/]\n")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[red]发生错误：{e}[/]\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
