"""
LangGraph Checkpointer — auto-setup from connection string.

Developer only provides a connection string. The framework handles all DB
table creation, schema setup, and connection management automatically.

Connection string formats:
  postgresql://user:pass@host:5432/dbname   → PostgreSQL (persistent, multi-process)
  ./checkpoints.db                          → SQLite (persistent, single-process)
  :memory:                                  → In-memory (dev/test only)
  (omitted)                                 → In-memory (dev/test only)

config.yaml:
  checkpoint:
    connection_string: "postgresql://user@localhost:5432/flowgraph"

The checkpointer singleton is initialised once per process.
To reset in tests, call reset() explicitly.
"""

import logging
import os
from typing import Optional

from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)

# Process-level singleton — built once, shared across all threads/requests
_instance: Optional[object] = None


def get_checkpointer(config: dict):
    """Return a ready-to-use LangGraph checkpointer.

    All DB table creation is handled automatically.
    Caller only needs to provide a valid connection string in config.

    Args:
        config: Full app config dict (reads config["checkpoint"]["connection_string"]).

    Returns:
        A LangGraph checkpointer (PostgresSaver | SqliteSaver | MemorySaver).
    """
    global _instance
    if _instance is not None:
        return _instance

    conn_str = (
        config.get("checkpoint", {}).get("connection_string")
        or os.environ.get("FLOWGRAPH_CHECKPOINT_URL")
        or ""
    ).strip()

    if _is_postgres(conn_str):
        _instance = _init_postgres(conn_str)
    elif _is_sqlite(conn_str):
        _instance = _init_sqlite(conn_str)
    else:
        _instance = _init_memory()

    return _instance


def reset():
    """Reset the singleton — for testing only."""
    global _instance
    _instance = None


# ── Private helpers ────────────────────────────────────────────────────────────

def _is_postgres(conn_str: str) -> bool:
    return conn_str.startswith(("postgresql://", "postgres://"))


def _is_sqlite(conn_str: str) -> bool:
    return bool(conn_str) and conn_str not in (":memory:",)


def _init_postgres(conn_str: str):
    """Init PostgresSaver and auto-create all required tables."""
    try:
        import psycopg
        from langgraph.checkpoint.postgres import PostgresSaver

        # autocommit=True is required: PostgresSaver.setup() uses
        # CREATE INDEX CONCURRENTLY which cannot run inside a transaction block.
        # The saver manages its own transactions for checkpoint operations.
        connection = psycopg.connect(conn_str, autocommit=True)
        saver = PostgresSaver(connection)
        saver.setup()   # creates checkpoint tables if they don't exist
        logger.info("Checkpointer: PostgreSQL at %s", _redact(conn_str))
        return saver
    except ImportError as e:
        raise RuntimeError(
            "PostgreSQL checkpointer requires 'langgraph-checkpoint-postgres' and 'psycopg'. "
            f"Install with: uv add langgraph-checkpoint-postgres psycopg"
        ) from e
    except Exception as e:
        raise RuntimeError(
            f"Failed to connect to PostgreSQL checkpointer: {e}\n"
            f"Connection string: {_redact(conn_str)}"
        ) from e


def _init_sqlite(conn_str: str) -> object:
    """Init SqliteSaver and auto-create all required tables."""
    try:
        import sqlite3
        from langgraph.checkpoint.sqlite import SqliteSaver

        # Normalise path (strip sqlite:/// prefix if present)
        db_path = conn_str.removeprefix("sqlite:///").removeprefix("sqlite://")
        connection = sqlite3.connect(db_path, check_same_thread=False)
        saver = SqliteSaver(connection)
        logger.info("Checkpointer: SQLite at %s", db_path)
        return saver
    except ImportError as e:
        raise RuntimeError(
            "SQLite checkpointer requires 'langgraph-checkpoint-sqlite'. "
            "Install with: uv add langgraph-checkpoint-sqlite"
        ) from e


def _init_memory() -> MemorySaver:
    logger.info("Checkpointer: in-memory (conversations reset on restart)")
    return MemorySaver()


def _redact(conn_str: str) -> str:
    """Hide password from connection string for logging."""
    import re
    return re.sub(r"(?<=://).+?(?=@)", "****:****", conn_str)
