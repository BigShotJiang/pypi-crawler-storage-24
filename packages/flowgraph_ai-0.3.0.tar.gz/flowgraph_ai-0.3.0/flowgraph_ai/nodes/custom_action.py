"""
CustomAction Node — V3 with full Langfuse + Jaeger observability.

Executes developer-defined Python business logic.
The developer's method receives state, can mutate it, and returns the next node name.

Observability:
  - Each node execution creates a Jaeger span (custom_action.<name>) capturing
    method, args, result, elapsed time, routing decision, and errors.
  - Each node also creates a Langfuse @observe span with input state and output.
  - API calls made from action functions can be wrapped with:
      from flowgraph_ai.observability.tracing import api_call_span
      with api_call_span("POST", url, node_name=node_name) as span: ...

Routing options (in YAML):
  1. routes[] — list of {value, next} pairs matched against result_field
  2. conditional_edges — {field, paths} for field-value based routing
  3. next — simple fixed routing (used with args_from_state mode)
  4. Direct routing (default) — return value IS the next node name

YAML (state-dict mode — traditional):
  check_billing:
    type: custom_action
    method: "actions.billing.check_status"
    result_field: billing_result   # default: action_result
    routes:
      - value: "verified"
        next: get_sr_status
      - value: "not_found"
        next: collect_sr
      - default: error_response

YAML (args_from_state mode — function receives explicit kwargs):
  lookup_order:
    type: custom_action
    method: "actions.order_tools.get_order_status"
    args_from_state:
      order_id: order_id          # function_kwarg: state_field
    result_field: order_status    # stores the return value
    next: success_response        # fixed routing when done
    on_error: error_response      # routing on exception
"""

import importlib
import inspect
import logging
import time

import flowgraph_ai.observability.tracing as otel

logger = logging.getLogger("flowgraph.nodes.custom_action")

# ── Langfuse decorators (optional — graceful no-op if not installed) ─────────
try:
    from langfuse.decorators import observe as _lf_observe, langfuse_context as _lf_ctx
    _LANGFUSE_AVAILABLE = True
except ImportError:
    _LANGFUSE_AVAILABLE = False
    _lf_observe = lambda *a, **kw: (lambda fn: fn)  # noqa: E731
    _lf_ctx = None


def _lf_update(input=None, output=None, metadata=None):
    """Safely update the current Langfuse observation."""
    if not _LANGFUSE_AVAILABLE or _lf_ctx is None:
        return
    try:
        kwargs = {}
        if input is not None:
            kwargs["input"] = input
        if output is not None:
            kwargs["output"] = output
        if metadata is not None:
            kwargs["metadata"] = metadata
        if kwargs:
            _lf_ctx.update_current_observation(**kwargs)
    except Exception:
        pass


def _safe_repr(val, max_len: int = 300) -> str:
    """Return a safe string representation of a value, truncated."""
    try:
        s = repr(val)
    except Exception:
        s = "<unrepresentable>"
    return s[:max_len] + ("…" if len(s) > max_len else "")


def build_node(
    node_def: dict,
    default_llm=None,
    app_config: dict | None = None,
    callbacks: list | None = None,
):
    """Return a LangGraph-compatible node function for a custom_action node.

    The returned function is wrapped with:
    - Jaeger span (custom_action.<node_name>) for distributed tracing
    - Langfuse @observe span for LLM-centric tracing
    - Structured log events at every significant step
    """

    method_path = node_def.get("method")
    result_field = node_def.get("result_field", "action_result")
    args_from_state = node_def.get("args_from_state")  # {kwarg_name: state_field}
    on_error_node = node_def.get("on_error")
    node_name = node_def.get("name", "?")

    if not method_path:
        raise ValueError(
            f"custom_action node '{node_name}' must specify 'method'."
        )

    # ── Build core (untraced) node logic ─────────────────────────────────────

    def _execute(state: dict) -> dict:
        """Core execution logic — called from the traced wrapper."""
        t0 = time.perf_counter()

        # ── Import the action module + function ────────────────────────────
        try:
            module_name, func_name = method_path.rsplit(".", 1)
        except ValueError:
            raise ValueError(
                f"Invalid method path '{method_path}' for node '{node_name}'. "
                f"Expected 'module.path.function_name'."
            )

        try:
            module = importlib.import_module(module_name)
        except ModuleNotFoundError:
            if module_name.startswith("actions.") or module_name.startswith("validations."):
                module = importlib.import_module(f"flowgraph_ai.{module_name}")
            else:
                raise

        func = getattr(module, func_name)

        # ── args_from_state mode ──────────────────────────────────────────
        if args_from_state:
            kwargs = {
                kwarg: state.get(state_field)
                for kwarg, state_field in args_from_state.items()
            }
            sig = inspect.signature(func)
            if "config" in sig.parameters:
                kwargs["config"] = app_config

            logger.info(
                "[ACTION_START] node=%s  method=%s  mode=args_from_state  kwargs=%s",
                node_name, method_path, list(kwargs.keys()),
            )
            _lf_update(
                input={
                    "mode": "args_from_state",
                    "kwargs": {k: _safe_repr(v) for k, v in kwargs.items()},
                    "method": method_path,
                },
            )

            result = func(**kwargs)
            elapsed_ms = (time.perf_counter() - t0) * 1000

            logger.info(
                "[ACTION_DONE] node=%s  method=%s  mode=args_from_state  "
                "result_type=%s  elapsed=%.0fms",
                node_name, method_path, type(result).__name__, elapsed_ms,
            )
            _lf_update(
                output={"result": _safe_repr(result), "result_field": result_field},
                metadata={"elapsed_ms": round(elapsed_ms), "mode": "args_from_state"},
            )
            return {result_field: result}

        # ── state-dict mode (traditional) ─────────────────────────────────
        else:
            # Relevant input fields (exclude noise)
            input_fields = {
                k: _safe_repr(v)
                for k, v in state.items()
                if k not in {"messages"} and not k.startswith("_")
            }

            logger.info(
                "[ACTION_START] node=%s  method=%s  mode=state_dict  "
                "state_keys=%s",
                node_name, method_path, list(input_fields.keys()),
            )
            _lf_update(
                input={
                    "mode": "state_dict",
                    "method": method_path,
                    "state_snapshot": input_fields,
                },
            )

            state_copy = dict(state)
            result = func(state_copy)

            if not isinstance(result, str):
                raise TypeError(
                    f"'{method_path}' must return str (next node name or 'END'), "
                    f"got {type(result).__name__}. "
                    f"Fix: ensure your action function returns a string, or add "
                    f"'args_from_state:' to the node YAML to use keyword-arg mode."
                )

            elapsed_ms = (time.perf_counter() - t0) * 1000

            # Track state mutations
            mutations = {}
            for k, v in state_copy.items():
                if k not in state or state[k] != v:
                    mutations[k] = _safe_repr(v)
                    logger.debug(
                        "[STATE_MUTATION] node=%s  key=%s", node_name, k,
                    )

            logger.info(
                "[ACTION_DONE] node=%s  method=%s  routing_to=%s  "
                "mutations=%d  elapsed=%.0fms",
                node_name, method_path, result, len(mutations), elapsed_ms,
            )
            _lf_update(
                output={
                    "routing_to": result,
                    "state_mutations": mutations,
                    "result_field": result_field,
                },
                metadata={
                    "elapsed_ms": round(elapsed_ms),
                    "mode": "state_dict",
                    "mutated_keys": list(mutations.keys()),
                },
            )

            updates = {result_field: result}
            for k, v in mutations.items():
                updates[k] = state_copy[k]  # original value, not repr

            return updates

    # ── Wrap _execute with Langfuse @observe ─────────────────────────────────

    @_lf_observe(name=f"custom_action:{node_name}", as_type="span")
    def _lf_traced_execute(state: dict) -> dict:
        return _execute(state)

    # ── Outer wrapper: Jaeger span + error handling ───────────────────────────

    def node_fn(state: dict) -> dict:
        with otel.custom_action_span(
            node_name=node_name,
            method_path=method_path,
            session_id=str(state.get("_session_id", "")),
        ) as span:
            try:
                result = _lf_traced_execute(state)
                if span:
                    # Record routing in Jaeger
                    routed_to = result.get(result_field, "?")
                    span.set_attribute("action.routing_to", str(routed_to))
                    span.set_attribute("action.elapsed_ms",
                                       str(round((time.perf_counter()) * 1000)))
                return result

            except Exception as e:
                elapsed_ms = 0
                logger.error(
                    "[ACTION_FAIL] node=%s  method=%s  error=%s\n"
                    "  → routing to on_error node: %s",
                    node_name, method_path, e, on_error_node or "END",
                    exc_info=True,
                )
                if span:
                    from opentelemetry.trace import Status, StatusCode
                    span.set_attribute("action.error", str(e)[:500])
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)

                _lf_update(
                    output={"error": str(e)[:500], "routing_to": on_error_node or "END"},
                    metadata={"failed": True, "method": method_path},
                )
                return {
                    result_field: on_error_node or "END",
                    "error": f"Action '{method_path}' failed: {e}",
                }

    return node_fn


def make_router(node_def: dict, all_node_names: set):
    """Return a LangGraph conditional edge function for a custom_action node."""
    result_field = node_def.get("result_field", "action_result")
    on_error_node = node_def.get("on_error")
    node_name = node_def.get("name", "?")

    # Option 0: args_from_state mode with fixed `next` routing
    if (node_def.get("args_from_state") and "next" in node_def
            and "routes" not in node_def and "conditional_edges" not in node_def):
        next_node = node_def["next"]
        error_node = on_error_node

        def args_router(state: dict) -> str:
            if state.get("error") and error_node:
                target = error_node if error_node in all_node_names else "__end__"
            else:
                target = next_node if next_node in all_node_names else "__end__"
            logger.debug("[ROUTE] node=%s  mode=args_from_state  next=%s", node_name, target)
            return target

        return args_router

    # Option 1: routes[] list
    if "routes" in node_def:
        routes = node_def["routes"]

        def _route_default(r):
            d = r.get("default")
            if isinstance(d, str):
                return d
            return r.get("next")

        default_next = next(
            (_route_default(r) for r in routes if "default" in r or r.get("value") is None),
            "END"
        )
        value_map = {r["value"]: r["next"] for r in routes if "value" in r}

        def routes_router(state: dict) -> str:
            value = str(state.get(result_field, "")).strip()
            target = value_map.get(value, default_next)
            target = target if target in all_node_names else "__end__"
            logger.debug(
                "[ROUTE] node=%s  mode=routes  result_field=%s  value=%r  next=%s",
                node_name, result_field, value, target,
            )
            return target

        return routes_router

    # Option 2: conditional_edges {field, paths}
    if "conditional_edges" in node_def:
        ce = node_def["conditional_edges"]
        field = ce["field"]
        paths = ce["paths"]
        default = paths.get("default", "END")

        def ce_router(state: dict) -> str:
            value = state.get(field)
            key = str(value).lower() if isinstance(value, bool) else str(value)
            target = paths.get(key, default)
            target = target if target in all_node_names else "__end__"
            logger.debug(
                "[ROUTE] node=%s  mode=conditional_edges  field=%s  value=%r  next=%s",
                node_name, field, value, target,
            )
            return target

        return ce_router

    # Option 3: direct routing — return value IS the next node name
    def direct_router(state: dict) -> str:
        value = str(state.get(result_field, "")).strip()
        if value == "END" or not value:
            target = "__end__"
        elif value in all_node_names:
            target = value
        else:
            logger.warning(
                "[ROUTE] node=%s  mode=direct  target=%r  not_in_graph  → END",
                node_name, value,
            )
            target = "__end__"
        logger.debug("[ROUTE] node=%s  mode=direct  next=%s", node_name, target)
        return target

    return direct_router
