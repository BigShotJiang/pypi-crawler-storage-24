"""
HR actions for the hr_leave_request workflow.
Demonstrates that custom actions are domain-specific and live outside the framework.
"""

import uuid
import logging

logger = logging.getLogger(__name__)


def submit_leave_request(state: dict) -> str:
    """Submit a leave request and return the next node name.

    On success: sets state["request_id"] and routes to "confirm".
    On error: sets state["error"] and routes to "error_response".
    """
    required = ["employee_name", "leave_type", "start_date", "end_date", "reason"]
    missing = [f for f in required if not state.get(f)]

    if missing:
        state["error"] = f"Missing required fields: {', '.join(missing)}"
        logger.error("Leave request missing fields: %s", missing)
        return "error_response"

    # Simulate submission — generate a request ID
    request_id = f"LR-{uuid.uuid4().hex[:6].upper()}"
    state["request_id"] = request_id

    logger.info(
        "Leave request submitted: %s for %s (%s to %s)",
        request_id,
        state["employee_name"],
        state["start_date"],
        state["end_date"],
    )
    return "confirm"
