"""
Mock billing actions for the FlowGraph-AI framework.

Each function receives `state: dict` and returns a string.
The returned string IS the next node name (direct routing).
Return "END" to terminate the workflow.

The function may mutate `state` in-place to set output fields.
"""

import logging

logger = logging.getLogger(__name__)


def check_status(state: dict) -> str:
    """Validate billing system access for the given SR number.

    Routes:
      - "fetch_status"  — SR exists and is clear for lookup
      - "gather_sr"     — SR number missing or invalid
      - "END"           — SR rejected (sets state["error"])
    """
    sr_number = str(state.get("sr_number", "")).strip()
    logger.info("Checking billing system for SR: '%s'", sr_number)

    if not sr_number:
        logger.warning("No SR number provided. Routing to 'gather_sr'.")
        return "gather_sr"

    if sr_number == "SR-99999":
        msg = f"{sr_number} was rejected by the billing system."
        logger.error(msg)
        state["error"] = msg
        return "END"

    logger.info("Billing clear for SR: '%s'. Routing to 'collect_contact'.", sr_number)
    return "collect_contact"


def fetch_api_status(state: dict) -> str:
    """Simulate an API call to fetch actual SR status.

    Sets state["output"] with the user-facing message and returns "END".
    """
    sr_number = str(state.get("sr_number", "")).strip()
    logger.info("Fetching API status for SR: '%s'", sr_number)

    # Simulate API response
    status = "In Progress"
    state["output"] = f"Your Service Request {sr_number} is currently: {status}"
    logger.info("Status retrieved: '%s'", status)
    return "END"
