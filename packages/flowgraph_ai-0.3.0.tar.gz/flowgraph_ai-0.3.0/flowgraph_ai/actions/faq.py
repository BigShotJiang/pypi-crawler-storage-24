"""
FAQ action — answers general questions using the configured LLM.

This pattern shows how to use the LLM inside a custom_action when you
need a free-form response rather than structured data collection.
"""

import logging
from flowgraph_ai.config import load_config
from flowgraph_ai.llm.provider import get_llm
from flowgraph_ai.core.history import format_history

logger = logging.getLogger(__name__)


def answer_question(state: dict) -> str:
    """Answer the user's question using the LLM.

    Sets state["output"] with the answer and routes to "final".
    """
    config = load_config()
    llm = get_llm(config)

    question = state.get("user_message", "")
    language = state.get("user_language", "English") or "English"
    history = state.get("messages", [])
    history_text = format_history(history, max_turns=5)

    lang_instr = f"Respond in {language}." if language.lower() != "english" else ""

    prompt = (
        f"You are a helpful assistant. Answer the following question clearly and concisely.\n"
        f"{f'Recent conversation:{chr(10)}{history_text}{chr(10)}' if history_text and history_text != '(no conversation history)' else ''}"
        f"\nQuestion: {question}\n\n"
        f"{lang_instr}\n"
        f"Provide a helpful, accurate answer."
    )

    try:
        answer = llm.invoke(prompt).content.strip()
        state["output"] = answer
        logger.info("FAQ answered: '%s...'", answer[:50])
        return "final"
    except Exception as e:
        logger.error("FAQ action failed: %s", e)
        state["error"] = f"Sorry, I couldn't answer that question: {e}"
        return "final"
