"""
TechMart Online Store — FlowGraph-AI example actions.

Simulates a real e-commerce backend with a mock product catalog,
order database, and return processing system.

Actions:
  search_products          — fuzzy product search by type, budget, preferences
  lookup_order             — verify order ID + email, return status
  check_return_eligibility — 30-day window check
  process_return           — generate RMA label + refund confirmation
  answer_store_question    — LLM-powered FAQ from knowledge base
"""

import random
import re
import logging

logger = logging.getLogger(__name__)

# ── Mock product catalog ───────────────────────────────────────────────────────

PRODUCTS = [
    {
        "id": "P001", "name": "UltraBook Pro 15", "type": "laptop", "price": 899,
        "tags": ["lightweight", "business", "fast", "thin", "productivity"],
        "stock": True, "rating": 4.7,
    },
    {
        "id": "P002", "name": "GameForce X17", "type": "laptop", "price": 1299,
        "tags": ["gaming", "powerful", "rgb", "high-performance", "gpu"],
        "stock": True, "rating": 4.8,
    },
    {
        "id": "P003", "name": "BudgetBook Air", "type": "laptop", "price": 499,
        "tags": ["budget", "lightweight", "student", "everyday", "portable"],
        "stock": True, "rating": 4.2,
    },
    {
        "id": "P004", "name": "StudioPad Pro", "type": "tablet", "price": 699,
        "tags": ["creative", "drawing", "portable", "stylus", "art"],
        "stock": True, "rating": 4.6,
    },
    {
        "id": "P005", "name": "WorkStation Z1", "type": "desktop", "price": 1499,
        "tags": ["powerful", "workstation", "video-editing", "rendering", "4k"],
        "stock": False, "rating": 4.9,
    },
    {
        "id": "P006", "name": "SlimBook 14", "type": "laptop", "price": 749,
        "tags": ["lightweight", "thin", "portable", "business", "battery"],
        "stock": True, "rating": 4.5,
    },
    {
        "id": "P007", "name": "ProTab 11", "type": "tablet", "price": 399,
        "tags": ["budget", "portable", "student", "media", "reading"],
        "stock": True, "rating": 4.0,
    },
    {
        "id": "P008", "name": "Creator Studio 16", "type": "laptop", "price": 1199,
        "tags": ["video-editing", "creative", "colour-accurate", "design", "4k"],
        "stock": True, "rating": 4.7,
    },
]

# ── Mock order database ────────────────────────────────────────────────────────

ORDERS = {
    "ORD-12345": {
        "status": "Shipped", "item": "UltraBook Pro 15", "price": 899,
        "date": "2026-03-05", "eta": "2026-03-13", "email": "demo@example.com",
        "tracking": "TRK-9988776655",
    },
    "ORD-67890": {
        "status": "Delivered", "item": "GameForce X17", "price": 1299,
        "date": "2026-02-10", "email": "test@example.com",
    },
    "ORD-11111": {
        "status": "Processing", "item": "StudioPad Pro", "price": 699,
        "date": "2026-03-10", "email": "user@example.com",
    },
    "ORD-22222": {
        "status": "Delivered", "item": "SlimBook 14", "price": 749,
        "date": "2026-02-28", "email": "sarah@example.com",
    },
}

# ── Store knowledge base (for FAQ) ─────────────────────────────────────────────

STORE_KB = """
You are a friendly, knowledgeable customer support agent for TechMart — a premium online electronics store.

Store Policies & Information:
━━━━━━━━━━━━━━━━━━━━━━━━━━━

SHIPPING:
- Free standard shipping on all orders over $50 (3-5 business days)
- Express shipping: $12.99 (1-2 business days)
- Same-day delivery available in select cities (order before 12pm)
- International shipping: available to 30+ countries (7-14 business days)

RETURNS:
- 30-day hassle-free returns from the order date
- Items must be unused, undamaged, and in original packaging
- Electronics with broken seals may be subject to a 15% restocking fee
- Defective items: full refund + free return shipping

REFUNDS:
- Processed within 5-7 business days after we receive the return
- Original payment method refund (or store credit with 10% bonus)
- Store credit never expires

WARRANTY:
- All electronics: 1-year manufacturer warranty
- Extended warranty plans available (2yr or 3yr)
- Warranty claims: email warranty@simpletools.in with your order ID and issue

PAYMENT:
- Visa, Mastercard, American Express, PayPal, Apple Pay, Google Pay
- Buy Now Pay Later via Klarna (0% interest for 3 months)
- Cryptocurrency accepted (Bitcoin, ETH)

CONTACT:
- Email: support@simpletools.in (response within 2 hours Mon-Fri)
- Live chat: available on website 9am-9pm IST
- Phone: +91-1234-567890 (Mon-Fri 9am-6pm IST)
- WhatsApp: +91-9876-543210

Answer the customer's question based on this information.
Be warm, concise, and genuinely helpful. Use bullet points where it helps readability.
If something isn't covered above, honestly direct them to support@simpletools.in.
"""


# ── Helpers ────────────────────────────────────────────────────────────────────

def _normalise_order_id(raw: str) -> str:
    """Normalise ORD12345 / 12345 → ORD-12345."""
    clean = raw.strip().upper().replace(" ", "")
    if re.match(r"^\d{4,6}$", clean):
        return f"ORD-{clean}"
    if re.match(r"^ORD\d{4,6}$", clean):
        return f"ORD-{clean[3:]}"
    return clean


def _parse_budget(raw: str) -> float:
    """Extract a numeric budget from strings like '$800', '800 dollars', 'around 1k'."""
    raw = raw.lower().replace(",", "")
    if "k" in raw:
        raw = raw.replace("k", "000")
    digits = re.sub(r"[^\d.]", "", raw)
    try:
        return float(digits)
    except ValueError:
        return 9999.0


# ── Actions ────────────────────────────────────────────────────────────────────

def search_products(state: dict) -> str:
    """
    Search products by type, budget, and preferences.
    Populates state["output"] with formatted results.
    Returns: "found" | "no_results"
    """
    product_type = state.get("product_type", "").lower().strip()
    budget_raw   = state.get("budget", "9999")
    preferences  = state.get("preferences", "").lower()

    budget = _parse_budget(str(budget_raw))
    pref_words = [w for w in preferences.split() if len(w) > 2]

    matches = []
    for p in PRODUCTS:
        if not p["stock"]:
            continue
        # Type match (flexible: "laptop" matches "laptop", "laptops", etc.)
        type_match = not product_type or product_type.rstrip("s") in p["type"]
        # Budget match
        budget_match = p["price"] <= budget
        # Preference match (any tag overlaps with preference words)
        pref_match = not pref_words or any(pw in tag for pw in pref_words for tag in p["tags"])

        if type_match and budget_match and pref_match:
            matches.append(p)

    if not matches:
        # Try relaxing preference filter
        matches = [p for p in PRODUCTS if p["stock"] and p["price"] <= budget and
                   (not product_type or product_type.rstrip("s") in p["type"])]

    if not matches:
        state["output"] = (
            f"I couldn't find any {product_type or 'products'} under ${budget:.0f} right now.\n\n"
            "A few options:\n"
            "  • Try a slightly higher budget\n"
            "  • Let me know if you're flexible on the product type\n"
            "  • Email us at support@simpletools.in — we can source specific items!\n\n"
            "Would you like to try a different search?"
        )
        return "no_results"

    # Sort by best match: prefer exact type, then by rating
    matches.sort(key=lambda p: (-int(product_type.rstrip("s") in p["type"]), -p["rating"]))
    matches = matches[:3]  # top 3

    lines = [f"I found {len(matches)} great option(s) for you:\n"]
    for i, p in enumerate(matches, 1):
        stars = "★" * int(p["rating"]) + "☆" * (5 - int(p["rating"]))
        lines.append(
            f"  {i}. {p['name']}\n"
            f"     Price:  ${p['price']}\n"
            f"     Rating: {stars} ({p['rating']})\n"
            f"     Best for: {', '.join(p['tags'][:3])}\n"
            f"     ID: {p['id']}"
        )

    lines.append(
        "\nWould you like more details on any of these, or shall I help you place an order? "
        "You can also ask about specs, comparisons, or anything else!"
    )

    state["output"] = "\n".join(lines)
    state["search_result"] = "found"
    return "found"


def lookup_order(state: dict) -> str:
    """
    Look up an order by ID + email verification.
    Populates state["output"] or state["error"].
    Returns: "found" | "not_found"
    """
    raw_id = state.get("order_id", "").strip()
    email  = state.get("email", "").lower().strip()

    order_id = _normalise_order_id(raw_id)
    order    = ORDERS.get(order_id)

    if not order:
        state["error"] = (
            f"I couldn't find order **{order_id}** in our system.\n\n"
            "Please check:\n"
            "  • The order ID is in your confirmation email (format: ORD-XXXXX)\n"
            "  • You might have placed the order under a different email\n\n"
            "Still having trouble? Email support@simpletools.in with your name and purchase date."
        )
        return "not_found"

    if order["email"] != email:
        state["error"] = (
            "The email address doesn't match what we have on file for this order.\n\n"
            "  • Check if you used a different email address when ordering\n"
            "  • Look for a 'TechMart Order Confirmation' email in your inbox\n\n"
            "For security, we need the email used at checkout. Need more help? "
            "Contact support@simpletools.in."
        )
        return "not_found"

    status = order["status"]
    item   = order["item"]
    date   = order["date"]

    if status == "Shipped":
        eta      = order.get("eta", "a few days")
        tracking = order.get("tracking", "—")
        state["output"] = (
            f"Great news — your order is on its way!\n\n"
            f"  Order ID:    {order_id}\n"
            f"  Item:        {item}\n"
            f"  Status:      {status} ✈\n"
            f"  Order date:  {date}\n"
            f"  Est. arrival:{eta}\n"
            f"  Tracking:    {tracking}\n\n"
            f"Is there anything else I can help with?"
        )
    elif status == "Delivered":
        state["output"] = (
            f"Your order has been delivered!\n\n"
            f"  Order ID:  {order_id}\n"
            f"  Item:      {item}\n"
            f"  Status:    Delivered ✓\n"
            f"  Ordered:   {date}\n\n"
            f"Hope you're loving your {item}! "
            f"If anything is wrong, I can help with a return or warranty claim."
        )
    else:
        state["output"] = (
            f"Your order is currently being prepared.\n\n"
            f"  Order ID:  {order_id}\n"
            f"  Item:      {item}\n"
            f"  Status:    {status} ⚙\n"
            f"  Ordered:   {date}\n\n"
            f"We'll send you a shipping notification as soon as it dispatches. "
            f"Anything else I can help with?"
        )

    return "found"


def check_return_eligibility(state: dict) -> str:
    """
    Check if an order is within the 30-day return window.
    Returns: "eligible" | "not_eligible" | "not_found"
    """
    from datetime import datetime

    raw_id   = state.get("order_id", "").strip()
    order_id = _normalise_order_id(raw_id)
    order    = ORDERS.get(order_id)

    if not order:
        state["error"] = (
            f"I couldn't find order **{order_id}** in our system.\n\n"
            "Please double-check your order ID — it's in your confirmation email "
            "and looks like ORD-12345.\n\n"
            "Still stuck? Email support@simpletools.in."
        )
        return "not_found"

    if order["status"] not in ("Delivered", "Shipped"):
        state["error"] = (
            f"Order {order_id} is currently '{order['status']}' and hasn't been delivered yet.\n\n"
            "Returns can only be initiated for items that have been delivered. "
            "Once your order arrives, you'll have 30 days to return it."
        )
        return "not_eligible"

    order_date  = datetime.strptime(order["date"], "%Y-%m-%d")
    days_since  = (datetime.now() - order_date).days

    if days_since > 30:
        state["error"] = (
            f"Unfortunately, order {order_id} was placed {days_since} days ago — "
            f"just outside our 30-day return window.\n\n"
            "However, if the item is defective or damaged, we may still be able to help. "
            "Please email warranty@simpletools.in with your order ID and a photo of the issue."
        )
        return "not_eligible"

    state["order_item"]       = order["item"]
    state["days_since_order"] = str(days_since)
    state["order_price"]      = str(order.get("price", ""))
    logger.info("Return eligible: order=%s item=%s days=%d", order_id, order["item"], days_since)
    return "eligible"


def process_return(state: dict) -> str:
    """
    Create a return request and generate RMA label.
    Returns: "success"
    """
    raw_id        = state.get("order_id", "").strip()
    order_id      = _normalise_order_id(raw_id)
    item          = state.get("order_item", "your item")
    reason        = state.get("return_reason", "not specified")
    refund_method = state.get("refund_method", "original payment method").strip()
    days          = state.get("days_since_order", "?")

    label_id      = f"RMA-{random.randint(10000, 99999)}"

    # Normalise refund method label
    if "credit" in refund_method.lower():
        refund_label = "Store credit (+ 10% bonus)"
    else:
        refund_label = "Original payment method"

    state["output"] = (
        f"Your return has been approved!\n\n"
        f"  Return ID:      {label_id}\n"
        f"  Order:          {order_id}\n"
        f"  Item:           {item}\n"
        f"  Reason:         {reason}\n"
        f"  Refund to:      {refund_label}\n\n"
        f"Next steps:\n"
        f"  1. Pack the item securely in its original box if possible\n"
        f"  2. Quote your Return ID ({label_id}) on the parcel\n"
        f"  3. Drop it off at any courier within 7 days\n"
        f"  4. Refund will be processed within 5-7 business days of receipt\n\n"
        f"We'll email you once we receive the parcel. "
        f"Is there anything else I can help you with?"
    )
    return "success"


# ── args_from_state-compatible tool functions ──────────────────────────────────
# These accept explicit kwargs (not the full state dict) and return data values
# (not next-node names). Use them with `args_from_state:` in custom_action YAML.

def get_order_status(order_id: str) -> str:
    """Look up order status by order ID. Returns a human-readable status string.

    Args:
        order_id: The order ID (e.g. ORD-12345).

    Returns:
        A string describing the current order status and details.
    """
    norm_id = _normalise_order_id(order_id)
    order = ORDERS.get(norm_id)
    if not order:
        return f"Order {norm_id} not found. Please check the order ID and try again."

    status = order["status"]
    item = order["item"]
    date = order["date"]

    if status == "Shipped":
        eta = order.get("eta", "a few days")
        tracking = order.get("tracking", "—")
        return (
            f"Order {norm_id} ({item}) is currently Shipped ✈\n"
            f"Ordered: {date} | Expected arrival: {eta} | Tracking: {tracking}"
        )
    elif status == "Delivered":
        return f"Order {norm_id} ({item}) has been Delivered ✓. Ordered: {date}"
    else:
        return f"Order {norm_id} ({item}) is currently {status} ⚙. Ordered: {date}"


def get_current_date() -> str:
    """Get the current date and time.

    Returns:
        Current date and time as a human-readable string.
    """
    from datetime import datetime
    return datetime.now().strftime("%A, %B %d, %Y at %I:%M %p")


def list_recent_orders(customer_id: str = "demo") -> str:
    """List recent orders in the mock database.

    Args:
        customer_id: Customer identifier (unused in mock, returns all demo orders).

    Returns:
        A formatted string of recent orders.
    """
    lines = ["Recent orders:"]
    for oid, order in ORDERS.items():
        lines.append(f"  - {oid}: {order['item']} ({order['status']}) — ordered {order['date']}")
    return "\n".join(lines)


def get_exchange_rate(from_currency: str, to_currency: str) -> str:
    """Get the current exchange rate between two currencies (mock data).

    Args:
        from_currency: Source currency code (e.g. USD, EUR, GBP).
        to_currency: Target currency code (e.g. INR, JPY, CNY).

    Returns:
        A string describing the exchange rate.
    """
    rates = {
        ("USD", "INR"): 83.45,
        ("EUR", "INR"): 89.12,
        ("GBP", "INR"): 105.67,
        ("USD", "EUR"): 0.92,
        ("USD", "GBP"): 0.78,
        ("USD", "JPY"): 149.5,
        ("EUR", "USD"): 1.09,
        ("GBP", "USD"): 1.27,
        ("JPY", "USD"): 0.0067,
        ("INR", "USD"): 0.012,
        ("SGD", "USD"): 0.74,
        ("USD", "SGD"): 1.35,
        ("AUD", "USD"): 0.65,
        ("USD", "AUD"): 1.54,
    }
    from_upper = from_currency.upper().strip()
    to_upper = to_currency.upper().strip()
    rate = rates.get((from_upper, to_upper))
    if rate:
        return f"1 {from_upper} = {rate} {to_upper} (mock rate, demo only — as of March 2026)"
    rev = rates.get((to_upper, from_upper))
    if rev:
        r = round(1 / rev, 4)
        return f"1 {from_upper} = {r} {to_upper} (mock rate, demo only — as of March 2026)"
    return f"Exchange rate for {from_upper}/{to_upper} not available. Supported: USD, EUR, GBP, INR, JPY, SGD, AUD."


def answer_store_question(state: dict) -> str:
    """
    LLM-powered FAQ — answers any store question from the knowledge base.
    Returns: "answered"
    """
    from flowgraph_ai.config import load_config
    from flowgraph_ai.llm.provider import get_llm

    cfg      = load_config()
    llm      = get_llm(cfg)
    question = state.get("user_message", "")

    try:
        response        = llm.invoke(f"{STORE_KB}\n\nCustomer question: {question}")
        state["output"] = response.content
    except Exception as e:
        logger.error("FAQ LLM call failed: %s", e)
        state["output"] = (
            "I'm having a bit of trouble right now. "
            "For immediate help, please email support@simpletools.in "
            "or check our website for FAQs."
        )

    return "answered"
