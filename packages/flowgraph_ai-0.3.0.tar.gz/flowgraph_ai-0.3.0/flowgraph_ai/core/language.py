"""
Language Detection.

Detects the language of user input and stores it in state["user_language"].
All subsequent LLM prompts include a language instruction so the bot
always responds in the user's language.
"""

import logging

logger = logging.getLogger(__name__)

_CACHE: dict[str, str] = {}  # Simple in-process cache for detected languages


def detect_language(text: str, llm) -> str:
    """Detect the language of the text.

    Args:
        text: User input text.
        llm: LangChain LLM instance.

    Returns:
        Language name in English (e.g., "English", "Spanish", "Tamil").
    """
    if not text or not text.strip():
        return "English"

    # If the text is extremely short or just alphanumeric/symbols (like "123" or "sr-12345"), assume English
    # This prevents the LLM from hallucinating random languages for IDs
    if len(text.strip()) < 5 or text.strip().replace('-', '').replace('_', '').isalnum():
        return "English"

    # Use first 100 chars for detection (speed + cost)
    sample = text.strip()[:100]

    if sample in _CACHE:
        return _CACHE[sample]

    try:
        prompt = (
            f'Detect the language of this text and respond with ONLY the language name in English.\n'
            f'Text: "{sample}"\n'
            f'Examples of valid responses: English, Spanish, French, Tamil, Hindi, Arabic, German, Portuguese, Chinese, Japanese\n'
            f'Respond with ONLY the language name, nothing else.'
        )
        result = llm.invoke(prompt).content.strip()
        # Sanitize — keep only the first word if LLM returns more
        language = result.split()[0] if result else "English"
        _CACHE[sample] = language
        logger.info("Detected language: '%s' from: '%s...'", language, sample[:30])
        return language
    except Exception as e:
        logger.warning("Language detection failed: %s. Defaulting to English.", e)
        return "English"


def language_instruction(language: str) -> str:
    """Return a language instruction string to append to LLM prompts."""
    if not language or language.lower() == "english":
        return ""
    return f"IMPORTANT: Always respond in {language}."
