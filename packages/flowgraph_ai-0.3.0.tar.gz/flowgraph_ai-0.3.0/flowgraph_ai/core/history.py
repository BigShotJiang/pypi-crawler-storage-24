"""
Conversation History Helpers.

Every workflow has a `messages` list in state (auto-injected).
Each entry: {"role": "assistant"|"user", "content": str, "timestamp": str}

Conversation history can be injected into YAML prompts via {state.messages}
which renders as a formatted string.
"""

import uuid
from datetime import datetime, timezone


def make_message(role: str, content: str) -> dict:
    """Create a single message entry for the conversation history."""
    return {
        "role": role,
        "content": content,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "id": uuid.uuid4().hex[:8],
    }


def format_history(messages: list, max_turns: int = 10) -> str:
    """Format conversation history as a readable string for LLM injection.

    Args:
        messages: List of message dicts from state["messages"].
        max_turns: Maximum number of recent messages to include.

    Returns:
        Formatted string like:
          User: hello
          Bot: Hi! How can I help?
          User: check my SR
    """
    if not messages:
        return "(no conversation history)"

    recent = messages[-max_turns * 2:]  # Each turn = 2 messages
    lines = []
    for msg in recent:
        role_label = "User" if msg.get("role") == "user" else "Bot"
        lines.append(f"{role_label}: {msg.get('content', '')}")
    return "\n".join(lines)


def history_updates(assistant_question: str, user_reply: str) -> dict:
    """Build a state update dict that appends assistant + user messages to history."""
    msgs = []
    if assistant_question:
        msgs.append(make_message("assistant", assistant_question))
    if user_reply:
        msgs.append(make_message("user", user_reply))
    return {"messages": msgs} if msgs else {}
