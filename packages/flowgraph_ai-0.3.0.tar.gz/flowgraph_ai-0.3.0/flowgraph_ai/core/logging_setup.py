"""
FlowGraph-AI Logging Setup.

Usage (in main.py / api/server.py startup):
    from flowgraph_ai.core.logging_setup import configure_logging
    configure_logging(config)

Usage in modules:
    import logging
    logger = logging.getLogger("flowgraph.nodes.data_collector")

Log levels:
    ERROR   — framework errors, LLM failures (always shown)
    WARNING — retries, fallbacks, unexpected inputs
    INFO    — workflow transitions, field collections, LLM call results (default)
    DEBUG   — full prompt content, raw LLM responses, state diffs

Enable DEBUG via config.yaml:
    logging:
      level: DEBUG

Or via env var (takes priority):
    FLOWGRAPH_LOG_LEVEL=DEBUG uvicorn api.server:app

Suppress noisy third-party loggers at DEBUG level:
    uvicorn, httpx, langchain, httpcore, openai
"""

import logging
import os
from typing import Any

_THIRD_PARTY_QUIET = [
    "uvicorn.access", "uvicorn.error", "httpx", "httpcore",
    "langchain", "langchain_core", "langsmith", "openai",
    "anthropic", "urllib3", "asyncio", "multipart",
]


def configure_logging(config: dict) -> None:
    """Set up FlowGraph-AI logging from config.

    Call this once at application startup before any other imports.

    Args:
        config: The full app config dict (from config.yaml / load_config()).
    """
    log_cfg = config.get("logging", {})

    # Env var takes priority over config.yaml
    level_name = (
        os.getenv("FLOWGRAPH_LOG_LEVEL")
        or log_cfg.get("level", "INFO")
    ).upper()
    level = getattr(logging, level_name, logging.INFO)

    # ── Handler setup ─────────────────────────────────────────────────────────
    handlers: list[logging.Handler] = []

    try:
        from rich.logging import RichHandler
        console_handler = RichHandler(
            rich_tracebacks=True,
            markup=True,
            show_path=(level == logging.DEBUG),
            omit_repeated_times=False,
            log_time_format="[%H:%M:%S]",
        )
        console_handler.setFormatter(logging.Formatter("%(message)s"))
        handlers.append(console_handler)
    except ImportError:
        # Rich not available — plain handler
        plain = logging.StreamHandler()
        plain.setFormatter(logging.Formatter(
            "%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
            datefmt="%H:%M:%S",
        ))
        handlers.append(plain)

    # Optional file handler
    log_file = log_cfg.get("file")
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(logging.Formatter(
            "%(asctime)s  %(levelname)-8s  %(name)s  %(message)s"
        ))
        handlers.append(file_handler)

    # ── Root logger — quiet by default, only flowgraph.* is verbose ───────────
    logging.basicConfig(level=logging.WARNING, handlers=handlers, force=True)

    # FlowGraph namespace — full verbosity
    flowgraph_logger = logging.getLogger("flowgraph")
    flowgraph_logger.setLevel(level)
    flowgraph_logger.propagate = True

    # Suppress noisy third-party libraries (keep WARNING and above)
    for name in _THIRD_PARTY_QUIET:
        logging.getLogger(name).setLevel(logging.WARNING)

    # ── Startup announcement ───────────────────────────────────────────────────
    startup_logger = logging.getLogger("flowgraph.startup")
    startup_logger.info(
        "[bold cyan]FlowGraph-AI[/] logging ready  "
        "[dim]level=%s%s[/]",
        level_name,
        f"  file={log_file}" if log_file else "",
    )
    if level == logging.DEBUG:
        startup_logger.debug(
            "[dim]DEBUG mode — full prompt content and LLM responses will be logged.[/]\n"
            "  To suppress: set [cyan]FLOWGRAPH_LOG_LEVEL=INFO[/] or update config.yaml"
        )


def perf_log(logger: logging.Logger, label: str, elapsed: float, level: int = logging.INFO, **context: Any) -> None:
    """Log a timed operation with semantic context.

    Usage:
        t = time.perf_counter()
        result = llm.invoke(prompt)
        perf_log(logger, "LLM_CALL", time.perf_counter() - t, operation="extraction", chars_in=len(prompt))

    Args:
        logger:  The logger instance (flowgraph.* namespaced).
        label:   Semantic operation label (uppercase, e.g. "GUARDRAILS", "FIELD_EXTRACTED").
        elapsed: Duration in seconds.
        level:   Log level (default INFO).
        **context: Additional key=value pairs for context.
    """
    ctx_str = "  ".join(f"{k}={v}" for k, v in context.items()) if context else ""
    msg = f"[{label}] {f'{ctx_str}  ' if ctx_str else ''}elapsed={elapsed * 1000:.0f}ms"
    logger.log(level, msg)
