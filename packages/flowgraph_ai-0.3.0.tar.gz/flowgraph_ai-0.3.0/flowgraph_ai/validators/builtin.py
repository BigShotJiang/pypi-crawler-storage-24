"""Built-in validators for the FlowGraph-AI framework."""

import re


def validate_regex(value: str, config: dict) -> tuple[bool, str]:
    """Validate value matches a regex pattern.

    YAML:
        validation:
          method: regex
          pattern: "^SR-\\d{5}$"
          error_message: "Must be in format SR-XXXXX"
    """
    pattern = config.get("pattern", ".*")
    if re.match(pattern, value):
        return True, ""
    return False, config.get("error_message", f"Value must match pattern: {pattern}")


def validate_length(value: str, config: dict) -> tuple[bool, str]:
    """Validate string length is within bounds.

    YAML:
        validation:
          method: length
          min: 3
          max: 10
    """
    min_len = config.get("min", 0)
    max_len = config.get("max", float("inf"))
    if min_len <= len(value) <= max_len:
        return True, ""
    return False, config.get("error_message", f"Length must be between {min_len} and {max_len}")


def validate_numeric(value: str, config: dict) -> tuple[bool, str]:
    """Validate value is a number, optionally within range.

    YAML:
        validation:
          method: numeric
          min: 1
          max: 100
    """
    try:
        num = float(value)
    except ValueError:
        return False, config.get("error_message", "Must be a valid number")
    min_val = config.get("min", float("-inf"))
    max_val = config.get("max", float("inf"))
    if min_val <= num <= max_val:
        return True, ""
    return False, config.get("error_message", f"Must be between {min_val} and {max_val}")


def validate_one_of(value: str, config: dict) -> tuple[bool, str]:
    """Validate value is one of the allowed options.

    YAML:
        validation:
          method: one_of
          options: ["high", "medium", "low"]
    """
    options = config.get("options", [])
    if value.lower() in [o.lower() for o in options]:
        return True, ""
    return False, config.get("error_message", f"Must be one of: {', '.join(options)}")


def validate_not_empty(value: str, config: dict) -> tuple[bool, str]:
    """Validate value is not empty.

    YAML:
        validation:
          method: not_empty
    """
    if value.strip():
        return True, ""
    return False, config.get("error_message", "This field cannot be empty")


BUILTIN_VALIDATORS: dict[str, callable] = {
    "regex": validate_regex,
    "length": validate_length,
    "numeric": validate_numeric,
    "one_of": validate_one_of,
    "not_empty": validate_not_empty,
}
