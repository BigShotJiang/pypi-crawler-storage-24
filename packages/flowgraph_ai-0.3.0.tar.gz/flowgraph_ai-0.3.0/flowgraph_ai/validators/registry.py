"""
Validation Registry.

Resolves validator by name:
  - Built-in: 'regex', 'length', 'numeric', 'one_of', 'not_empty'
  - Dynamic import: 'validations.sr.check_sr_format'
"""

import importlib
import logging
from flowgraph_ai.validators.builtin import BUILTIN_VALIDATORS

logger = logging.getLogger(__name__)


def run_validation(value: str, validation_config: dict) -> tuple[bool, str]:
    """Run a validation method from config.

    Args:
        value: The value to validate.
        validation_config: Dict with at least a 'method' key.

    Returns:
        (is_valid, error_message) tuple.
    """
    if not validation_config:
        return True, ""

    method_name = validation_config.get("method", "not_empty")

    # Dynamic import for custom validators (e.g., 'validations.sr.check_sr_format')
    if "." in method_name:
        try:
            module_name, func_name = method_name.rsplit(".", 1)
            try:
                module = importlib.import_module(module_name)
            except ModuleNotFoundError:
                if module_name.startswith("validations.") or module_name.startswith("actions."):
                    module = importlib.import_module(f"flowgraph_ai.{module_name}")
                else:
                    raise
            validator_func = getattr(module, func_name)
            return validator_func(value, validation_config)
        except Exception as e:
            logger.error("Validation import error for '%s': %s", method_name, e)
            return False, f"Internal validation error: {e}"

    # Built-in registry lookup
    validator = BUILTIN_VALIDATORS.get(method_name)
    if validator is None:
        logger.warning("Unknown built-in validator: '%s'. Skipping.", method_name)
        return True, ""

    return validator(value, validation_config)
