"""
Node-level Langfuse tracing for FlowGraph-AI.

Wraps each LangGraph node function with a Langfuse span that captures:
- Node input state (relevant fields)
- Node output state delta
- LLM call results (via the callback handler already on the LLM)
- Routing decision (next node)

Uses langfuse.decorators.observe so spans are properly nested under the
parent workflow trace established by propagate_attributes().

Usage (in graph_builder.py):
    from flowgraph_ai.observability.node_tracer import wrap_node
    fn = wrap_node(fn, node_name=name, node_type=node_type, workflow=wf_name)
"""

import logging
import functools
from typing import Callable

logger = logging.getLogger("flowgraph.observability.node_tracer")

# Fields that are too noisy or large to include in traces
_SKIP_FIELDS = {"messages"}

# Fields that hold sensitive data — truncated in traces
_TRUNCATE_FIELDS = {"user_message", "output", "error"}
_TRUNCATE_LEN = 500


def _sanitize_state(state: dict) -> dict:
    """Produce a clean snapshot of state suitable for Langfuse."""
    result = {}
    for k, v in state.items():
        if k in _SKIP_FIELDS:
            continue
        if k.startswith("_"):
            # Internal control fields — still useful, keep them
            result[k] = v
            continue
        if isinstance(v, str) and k in _TRUNCATE_FIELDS:
            result[k] = v[:_TRUNCATE_LEN] + ("…" if len(v) > _TRUNCATE_LEN else "")
        elif isinstance(v, list):
            result[k] = f"[{len(v)} items]"
        else:
            result[k] = v
    return result


def _state_delta(before: dict, after: dict) -> dict:
    """Return only the fields that changed between before and after."""
    delta = {}
    all_keys = set(before) | set(after)
    for k in all_keys:
        v_before = before.get(k)
        v_after = after.get(k)
        if v_before != v_after:
            delta[k] = {"before": v_before, "after": v_after}
    return delta


def wrap_node(
    fn: Callable,
    node_name: str,
    node_type: str,
    workflow: str,
) -> Callable:
    """
    Wrap a LangGraph node function with Langfuse tracing.

    Each call to the wrapped node creates a Langfuse span showing:
    - Input state snapshot
    - Output state delta (what changed)
    - Any routing info (_dc_next_node, _dc_failed)

    Falls back to calling fn() unmodified if Langfuse is unavailable.
    """
    try:
        from langfuse.decorators import observe, langfuse_context
    except ImportError:
        # Langfuse not available — return node unchanged
        return fn

    # custom_action nodes are self-instrumented with their own @observe + Jaeger span
    if node_type == "custom_action":
        return fn

    @observe(name=f"{workflow}/{node_name}", as_type="span")
    @functools.wraps(fn)
    def traced_fn(state: dict) -> dict:
        input_snapshot = _sanitize_state(state)

        # Annotate the span with node metadata and input
        try:
            langfuse_context.update_current_observation(
                name=node_name,
                input=input_snapshot,
                metadata={
                    "node_type": node_type,
                    "workflow": workflow,
                    "node": node_name,
                },
            )
        except Exception:
            pass

        # Run the actual node
        output = fn(state)

        # Compute what changed
        if isinstance(output, dict):
            delta = _state_delta(input_snapshot, _sanitize_state(output))
            # Determine routing decision
            routing_info = {}
            if "_dc_next_node" in output:
                routing_info["next_node"] = output["_dc_next_node"]
            if "_dc_failed" in output:
                routing_info["failed"] = output["_dc_failed"]
            if "_dc_node" in output:
                routing_info["failed_at"] = output["_dc_node"]

            summary_output = {
                "state_delta": delta,
                "routing": routing_info or "→ END",
                # Include key output fields directly for easy reading
            }
            if "output" in output and output.get("output"):
                summary_output["output"] = str(output["output"])[:_TRUNCATE_LEN]
            if "error" in output and output.get("error"):
                summary_output["error"] = str(output["error"])[:_TRUNCATE_LEN]

            try:
                langfuse_context.update_current_observation(
                    output=summary_output,
                    metadata={
                        "node_type": node_type,
                        "workflow": workflow,
                        "node": node_name,
                        "routing": routing_info or "END",
                        "fields_changed": list(delta.keys()),
                    },
                )
            except Exception:
                pass
        else:
            try:
                langfuse_context.update_current_observation(output=str(output))
            except Exception:
                pass

        return output

    return traced_fn
