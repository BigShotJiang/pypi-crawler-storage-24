"""
FlowGraph-AI Observability Module

Provides:
  - Langfuse integration: LLM-level tracing (prompts, completions, tokens, cost)
  - OpenTelemetry / Jaeger integration: workflow + node execution spans

Start the observability stack first:
  flowgraph stack up

Then configure Langfuse:
  flowgraph stack configure
"""
