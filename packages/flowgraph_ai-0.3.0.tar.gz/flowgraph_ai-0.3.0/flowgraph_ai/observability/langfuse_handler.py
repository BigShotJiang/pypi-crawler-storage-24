"""
Langfuse integration for FlowGraph-AI — SDK v4 / Server v3.

Langfuse v4 SDK uses OpenTelemetry-based context propagation internally.
Session, trace name, user ID and metadata are set via `propagate_attributes()`
context manager at the call site — NOT via CallbackHandler constructor args.

Setup:
  1. flowgraph stack up
  2. Open http://localhost:3000 (admin@flowgraph.local / flowgraph123)
  3. Settings → API Keys → copy public + secret keys into config.yaml
  4. Set observability.langfuse.enabled: true in config.yaml

config.yaml:
  observability:
    langfuse:
      enabled: true
      host: http://localhost:3000
      public_key: ""   # or env: LANGFUSE_PUBLIC_KEY
      secret_key: ""   # or env: LANGFUSE_SECRET_KEY

Environment variable overrides (take priority over config.yaml):
  LANGFUSE_PUBLIC_KEY
  LANGFUSE_SECRET_KEY
  LANGFUSE_HOST
"""

import logging
import os

logger = logging.getLogger(__name__)


def get_langfuse_handler(
    config: dict,
    session_id: str,
    trace_name: str,
    metadata: dict | None = None,
    user_id: str | None = None,
    trace_id: str | None = None,
):
    """
    Create a Langfuse v4 LangChain CallbackHandler.

    With SDK v4, session_id / trace_name / metadata are NOT passed here.
    Instead, wrap your graph invocation with `propagate_attributes()`:

        from langfuse import propagate_attributes
        with propagate_attributes(session_id=..., name=..., metadata=...):
            compiled.invoke(input, {"callbacks": [handler], ...})

    Returns None if Langfuse is disabled or not configured.
    """
    obs_cfg = config.get("observability", {}).get("langfuse", {})
    if not obs_cfg.get("enabled", False):
        return None

    public_key = os.getenv("LANGFUSE_PUBLIC_KEY") or obs_cfg.get("public_key", "")
    secret_key = os.getenv("LANGFUSE_SECRET_KEY") or obs_cfg.get("secret_key", "")
    host = os.getenv("LANGFUSE_HOST") or obs_cfg.get("host", "http://localhost:3000")

    if not public_key or not secret_key:
        logger.warning(
            "[Langfuse] API keys not configured — LLM traces will NOT be captured.\n"
            "  Fix: flowgraph stack configure\n"
            "    OR set env vars: LANGFUSE_PUBLIC_KEY + LANGFUSE_SECRET_KEY\n"
            "  Get keys: %s → Settings → API Keys",
            host,
        )
        return None

    # Force env vars so SDK picks them up via auto-detection
    os.environ["LANGFUSE_PUBLIC_KEY"] = public_key
    os.environ["LANGFUSE_SECRET_KEY"] = secret_key
    os.environ["LANGFUSE_HOST"] = host

    try:
        from langfuse.langchain import CallbackHandler

        # v4: No session_id, trace_name, or metadata here.
        # These are set per-invocation via propagate_attributes() at the call site.
        handler = CallbackHandler()

        logger.debug(
            "[Langfuse] Handler created  session=%s  trace=%s",
            session_id, trace_name,
        )
        return handler

    except (ImportError, ModuleNotFoundError):
        logger.error(
            "[Langfuse] Package not installed.\n"
            "  Fix: uv add 'langfuse>=4.0'"
        )
        return None
    except Exception as e:
        logger.warning(
            "[Langfuse] Unexpected error creating handler: %s",
            e,
        )
        return None


def get_propagate_context(
    session_id: str,
    trace_name: str,
    metadata: dict | None = None,
    user_id: str | None = None,
):
    """
    Return a `propagate_attributes()` context manager pre-filled with trace attrs.

    Usage:
        ctx = get_propagate_context(session_id=thread_id, trace_name="workflow:greeting")
        with ctx:
            compiled.invoke(...)
    """
    try:
        from langfuse import propagate_attributes
        return propagate_attributes(
            session_id=session_id,
            trace_name=trace_name,
            user_id=user_id,
            metadata=metadata or {},
        )
    except ImportError:
        # Return a no-op context manager if langfuse is not available
        from contextlib import nullcontext
        return nullcontext()
    except Exception:
        from contextlib import nullcontext
        return nullcontext()


def is_enabled(config: dict) -> bool:
    """Return True if Langfuse is enabled in config."""
    return bool(config.get("observability", {}).get("langfuse", {}).get("enabled", False))


def flush(config: dict) -> None:
    """Flush pending Langfuse traces if enabled. No-op if disabled or unavailable."""
    if not is_enabled(config):
        return
    try:
        from langfuse import Langfuse  # type: ignore
        Langfuse().flush()
    except Exception:
        pass
