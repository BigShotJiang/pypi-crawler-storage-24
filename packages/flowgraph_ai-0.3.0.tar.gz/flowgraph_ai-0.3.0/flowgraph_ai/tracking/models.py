"""Task tracking models for FlowGraph-AI Kanban board."""
from __future__ import annotations
import uuid
from datetime import datetime
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


class TaskStatus(str, Enum):
    BACKLOG = "backlog"
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    WAITING_INPUT = "waiting_input"
    TOOL_RUNNING = "tool_running"
    RETRY_RECOVERY = "retry_recovery"
    COMPLETED = "completed"
    FAILED = "failed"


class TaskEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    task_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now())
    event_type: str   # e.g. "node_enter", "node_exit", "tool_call", "retry", "status_change"
    description: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class Task(BaseModel):
    task_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:8].upper())
    session_id: str
    workflow_name: str
    correlation_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    trace_id: str | None = None  # Jaeger/OTel trace ID

    status: TaskStatus = TaskStatus.PLANNED
    title: str           # Short summary of user request
    user_request: str    # Full original user message
    current_node: str | None = None
    node_type: str | None = None

    retry_count: int = 0
    tool_calls: list[str] = Field(default_factory=list)

    created_at: datetime = Field(default_factory=lambda: datetime.now())
    updated_at: datetime = Field(default_factory=lambda: datetime.now())
    completed_at: datetime | None = None

    result_summary: str | None = None
    error_message: str | None = None

    events: list[TaskEvent] = Field(default_factory=list)

    def add_event(self, event_type: str, description: str, metadata: dict | None = None) -> TaskEvent:
        """Add an event to the task timeline."""
        event = TaskEvent(
            task_id=self.task_id,
            event_type=event_type,
            description=description,
            metadata=metadata or {},
        )
        self.events.append(event)
        self.updated_at = datetime.now()
        return event

    def update_status(self, status: TaskStatus, node: str | None = None, node_type: str | None = None) -> None:
        """Update task status and optionally current node."""
        self.status = status
        if node is not None:
            self.current_node = node
        if node_type is not None:
            self.node_type = node_type
        self.updated_at = datetime.now()
        if status in (TaskStatus.COMPLETED, TaskStatus.FAILED):
            self.completed_at = datetime.now()
