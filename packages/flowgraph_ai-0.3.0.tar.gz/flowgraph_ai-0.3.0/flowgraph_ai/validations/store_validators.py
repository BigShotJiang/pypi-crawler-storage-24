"""
Store validators for the online store example.

Validators:
  validate_order_id  — ORD-XXXXX format (flexible: handles "ORD12345", "ord-12345", etc.)
  validate_email     — standard email format (alias for regex, for clarity)
"""

import re


def validate_order_id(value: str, config: dict) -> tuple[bool, str]:
    """
    Accepts ORD-XXXXX format. Case-insensitive. Normalises dashes.
    Examples accepted: ORD-12345, ord-12345, ORD12345, 12345
    """
    if not value or not value.strip():
        return False, "Please provide your order ID. It looks like ORD-12345."

    cleaned = value.strip().upper().replace(" ", "")

    # Already correct format
    if re.match(r"^ORD-\d{4,6}$", cleaned):
        return True, ""

    # Missing dash: ORD12345
    if re.match(r"^ORD\d{4,6}$", cleaned):
        return True, ""

    # Just digits: 12345
    if re.match(r"^\d{4,6}$", cleaned):
        return True, ""

    return (
        False,
        f"'{value}' doesn't look like a valid order ID. "
        "Order IDs follow the format ORD-12345 — you'll find it in your confirmation email.",
    )
