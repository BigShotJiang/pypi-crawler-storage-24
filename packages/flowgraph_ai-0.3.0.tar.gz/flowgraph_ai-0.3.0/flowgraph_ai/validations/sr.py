"""
Custom SR number validator.

Validates that the SR number matches the format SR-XXXXX (5 digits).
"""

import re

_SR_PATTERN = re.compile(r'^SR-\d{5}$', re.IGNORECASE)


def check_sr_format(value: str, config: dict) -> tuple[bool, str]:
    """Validate SR number format (SR-XXXXX).

    Args:
        value: The extracted SR number string.
        config: Validation config from YAML (not used here).

    Returns:
        (is_valid, error_message)
    """
    normalized = value.strip().upper()
    if _SR_PATTERN.match(normalized):
        return True, ""
    return False, config.get(
        "error_message",
        "Please provide a valid SR number in the format SR-XXXXX (e.g., SR-12345)."
    )
