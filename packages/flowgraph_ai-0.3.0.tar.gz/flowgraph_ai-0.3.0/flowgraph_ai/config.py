import yaml
import os
from dotenv import load_dotenv


def load_config(config_path: str | None = None) -> dict:
    """Load config from YAML and .env file."""
    env_path = os.path.join(os.path.dirname(__file__), "..", ".env")
    load_dotenv(env_path)

    if config_path is None:
        config_path = os.path.join(os.path.dirname(__file__), "..", "config.yaml")
    with open(config_path, "r") as f:
        return yaml.safe_load(f)
