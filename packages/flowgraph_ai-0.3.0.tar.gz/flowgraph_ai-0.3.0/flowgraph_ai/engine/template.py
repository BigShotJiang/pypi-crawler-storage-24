"""
Template Rendering Engine.

Supports all syntaxes:
  - V3: {state.field_name}        (primary — single brace with state. prefix)
  - V2: {{state.field_name}}      (double brace with state. prefix)
  - V2: {{field_name}}            (double brace, no prefix)
  - V1: {field_name}              (single brace, no prefix — backward compat)

Missing keys are replaced with empty string rather than raising KeyError.
"""

import re
import logging

logger = logging.getLogger(__name__)

_V3_PATTERN = re.compile(r'(?<!\{)\{state\.([A-Za-z0-9_]+)\}(?!\})')  # {state.field} — not inside {{}}
_V2_PATTERN = re.compile(r'\{\{state\.([A-Za-z0-9_]+)\}\}')   # {{state.field}}
_V2_BARE_PATTERN = re.compile(r'\{\{([A-Za-z0-9_]+)\}\}')     # {{field}}


def render(template: str, state: dict) -> str:
    """Render a template string with values from state.

    Supports (in resolution order):
      {state.field_name}    — V3 syntax  (primary)
      {{state.field_name}}  — V2 syntax
      {{field_name}}        — V2 shorthand
      {field_name}          — V1 syntax  (backward compat)

    All missing keys resolve to empty string.

    Args:
        template: Template string.
        state: Current workflow state dict.

    Returns:
        Rendered string.
    """
    if not template:
        return template

    safe_state = {k: (str(v) if v is not None else "") for k, v in state.items()}

    # Replace {state.field} syntax — V3 primary (must run BEFORE V1 format_map)
    def replace_v3_state(m: re.Match) -> str:
        key = m.group(1)
        return safe_state.get(key, "")

    result = _V3_PATTERN.sub(replace_v3_state, template)

    # Replace {{state.field}} syntax — V2
    def replace_v2_state(m: re.Match) -> str:
        key = m.group(1)
        val = safe_state.get(key, "")
        if not val:
            logger.debug("Template key '{{state.%s}}' not found in state.", key)
        return val

    result = _V2_PATTERN.sub(replace_v2_state, result)

    # Replace {{field}} syntax (bare, no "state." prefix)
    def replace_v2_bare(m: re.Match) -> str:
        key = m.group(1)
        return safe_state.get(key, "")

    result = _V2_BARE_PATTERN.sub(replace_v2_bare, result)

    # Replace {field} syntax (V1 compat) — only if still has single-brace patterns
    try:
        result = result.format_map(_SafeDict(safe_state))
    except Exception:
        pass

    return result


class _SafeDict(dict):
    """Dict subclass that returns empty string for missing keys (for str.format_map)."""

    def __missing__(self, key: str) -> str:
        return ""
