"""
Hallucination detection and auto-fix for DataCollector extracted values.

After the LLM extracts a field value from user input, this module:
1. Validates the extracted value is actually present in user message / tool results / session state
2. If suspicious → retries with correction prompt
3. Records retry reason in logs and tracker
4. Fails gracefully after max_hallucination_retries

Usage:
    from flowgraph_ai.engine.hallucination import check_grounding, GroundingResult

    result = check_grounding(llm, extracted_value, field_description, user_input, context)
    if not result.is_grounded:
        # retry or flag
"""
from __future__ import annotations
import logging
import re
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger("flowgraph.engine.hallucination")


@dataclass
class GroundingResult:
    """Result of a hallucination grounding check."""
    is_grounded: bool
    confidence: float          # 0.0 – 1.0
    reason: str                # Human-readable explanation
    corrected_value: str | None = None   # Auto-corrected value if available
    method: str = "llm"        # "llm" | "regex" | "deterministic"


def check_grounding(
    llm,
    extracted_value: str,
    field_description: str,
    user_input: str,
    tool_context: str = "",
    session_context: dict | None = None,
    language: str = "",
) -> GroundingResult:
    """Check whether an extracted value is grounded in the available evidence.

    Steps:
    1. Fast deterministic check — is the value a literal substring of the evidence?
    2. LLM grounding check — ask the LLM if the value is supported by the evidence.
    3. Return GroundingResult with is_grounded, confidence, reason, and optional correction.
    """
    if not extracted_value or not extracted_value.strip():
        return GroundingResult(is_grounded=False, confidence=0.0, reason="Empty extracted value")

    # Build evidence string from all available context
    evidence_parts = [f'User said: "{user_input}"']
    if tool_context:
        evidence_parts.append(f"Tool results:\n{tool_context}")
    if session_context:
        relevant = {k: v for k, v in session_context.items()
                    if v and not k.startswith("_") and k not in ("messages", "output", "error")}
        if relevant:
            evidence_parts.append(f"Prior session data: {relevant}")
    evidence = "\n\n".join(evidence_parts)

    # ── Step 1: Fast deterministic check ─────────────────────────────────────
    deterministic_result = _deterministic_check(extracted_value, user_input, tool_context)
    if deterministic_result is not None:
        return deterministic_result

    # ── Step 2: LLM grounding check ───────────────────────────────────────────
    return _llm_grounding_check(llm, extracted_value, field_description, evidence, language)


def _deterministic_check(extracted_value: str, user_input: str, tool_context: str) -> GroundingResult | None:
    """Fast non-LLM check. Returns a result if clearly grounded or clearly absent.

    Returns None if uncertain (falls through to LLM check).
    """
    val = extracted_value.strip().lower()
    combined_evidence = (user_input + " " + tool_context).lower()

    # Direct substring match → clearly grounded
    if val in combined_evidence:
        return GroundingResult(
            is_grounded=True,
            confidence=0.98,
            reason="Value found verbatim in evidence",
            method="deterministic",
        )

    # Check for common hallucination patterns (values that look invented)
    hallucination_patterns = [
        r"\b(john doe|jane doe|test\d+|example\.com|foo|bar|baz|placeholder|dummy|fake)\b",
        r"\b(12345678|00000000|xxxxxx|aaaaaa)\b",
    ]
    for pattern in hallucination_patterns:
        if re.search(pattern, val, re.IGNORECASE):
            logger.warning("[HALLUCINATION] Detected suspicious pattern in value: %r", extracted_value)
            return GroundingResult(
                is_grounded=False,
                confidence=0.9,
                reason=f"Value matches suspicious hallucination pattern: {pattern}",
                method="deterministic",
            )

    return None  # Uncertain — let LLM decide


def _llm_grounding_check(
    llm,
    extracted_value: str,
    field_description: str,
    evidence: str,
    language: str = "",
) -> GroundingResult:
    """Ask the LLM whether the extracted value is supported by the evidence."""
    prompt = (
        f"You are a fact-checker validating an AI extraction result.\n\n"
        f"Field being extracted: {field_description}\n"
        f"Extracted value: \"{extracted_value}\"\n\n"
        f"Evidence available:\n{evidence}\n\n"
        f"Question: Is the extracted value actually present in or clearly derivable from the evidence above?\n\n"
        f"Rules:\n"
        f"- Answer GROUNDED if the value appears verbatim or can be clearly inferred from the evidence.\n"
        f"- Answer HALLUCINATED if the value does NOT appear in the evidence and cannot be inferred.\n"
        f"- If hallucinated, suggest the correct value from the evidence (or 'NONE' if not found).\n\n"
        f"Respond in EXACTLY this format (3 lines):\n"
        f"VERDICT: GROUNDED or HALLUCINATED\n"
        f"CONFIDENCE: 0.0-1.0\n"
        f"CORRECTION: <correct value from evidence, or NONE if not found>\n"
    )
    try:
        raw = llm.invoke(prompt).content.strip()
        return _parse_grounding_response(raw, extracted_value)
    except Exception as e:
        logger.warning("[HALLUCINATION] LLM grounding check failed: %s", e)
        # Fail open — assume grounded if we can't check
        return GroundingResult(
            is_grounded=True,
            confidence=0.5,
            reason=f"Grounding check failed (LLM error: {e}), assuming grounded",
            method="llm",
        )


def _parse_grounding_response(raw: str, original_value: str) -> GroundingResult:
    """Parse the 3-line LLM grounding response."""
    lines = [l.strip() for l in raw.strip().splitlines() if l.strip()]
    verdict = "GROUNDED"
    confidence = 0.8
    correction = None

    for line in lines:
        upper = line.upper()
        if upper.startswith("VERDICT:"):
            verdict = "HALLUCINATED" if "HALLUCINATED" in upper else "GROUNDED"
        elif upper.startswith("CONFIDENCE:"):
            try:
                confidence = float(line.split(":", 1)[1].strip())
                confidence = max(0.0, min(1.0, confidence))
            except (ValueError, IndexError):
                confidence = 0.7
        elif upper.startswith("CORRECTION:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() not in ("NONE", "N/A", ""):
                correction = val

    is_grounded = verdict == "GROUNDED"
    reason = f"LLM verdict: {verdict} (confidence={confidence:.2f})"
    if not is_grounded and correction:
        reason += f" → suggested correction: {correction!r}"

    return GroundingResult(
        is_grounded=is_grounded,
        confidence=confidence,
        reason=reason,
        corrected_value=correction if not is_grounded else None,
        method="llm",
    )


def attempt_autofix(
    llm,
    field_description: str,
    user_input: str,
    tool_context: str = "",
    language: str = "",
) -> str | None:
    """Attempt to deterministically re-extract a field value from evidence.

    Used after hallucination detection fails — tries a stricter extraction prompt.
    Returns the corrected value string, or None if extraction fails.
    """
    evidence = user_input
    if tool_context:
        evidence += f"\n\nAdditional context:\n{tool_context}"

    from flowgraph_ai.core.language import language_instruction
    lang_instr = language_instruction(language)

    prompt = (
        f"STRICT EXTRACTION MODE.\n\n"
        f"Extract ONLY what is explicitly stated in the evidence for: {field_description}\n\n"
        f"Evidence:\n{evidence}\n\n"
        f"Rules:\n"
        f"- Only extract values that appear VERBATIM or are UNAMBIGUOUSLY clear.\n"
        f"- Do NOT infer, guess, or hallucinate.\n"
        f"- If the value is not present, respond with exactly: NOT_FOUND\n\n"
        f"{lang_instr}\n"
        f"Return ONLY the extracted value (or NOT_FOUND)."
    )
    try:
        result = llm.invoke(prompt).content.strip()
        if result and result.upper() != "NOT_FOUND" and result != "none":
            logger.info("[AUTOFIX] Corrected value: %r", result)
            return result
        return None
    except Exception as e:
        logger.warning("[AUTOFIX] Failed: %s", e)
        return None
