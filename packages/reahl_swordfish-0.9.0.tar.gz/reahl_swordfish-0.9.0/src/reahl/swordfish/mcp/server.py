import inspect

from reahl.swordfish import __version__
from reahl.swordfish.mcp.integration_state import current_integrated_session_state


class McpDependencyNotInstalled(Exception):
    pass


def import_fast_mcp():
    try:
        from mcp.server.fastmcp import FastMCP
    except ModuleNotFoundError as module_not_found_error:
        raise McpDependencyNotInstalled(
            "SwordfishMCP requires the mcp package. "
            "Install with: pip install reahl-swordfish"
        ) from module_not_found_error
    return FastMCP


def create_server(
    allow_source_read=True,
    allow_source_write=False,
    allow_eval_arbitrary=False,
    allow_test_execution=False,
    allow_ide_read=True,
    allow_ide_write=False,
    allow_commit=False,
    allow_tracing=False,
    integrated_session_state=None,
    require_gemstone_ast=False,
    mcp_host="127.0.0.1",
    mcp_port=8000,
    mcp_streamable_http_path="/mcp",
):
    if integrated_session_state is None:
        integrated_session_state = current_integrated_session_state()
    fast_mcp = import_fast_mcp()
    register_tools = import_tool_registration()
    try:
        constructor_signature = inspect.signature(fast_mcp)
    except (TypeError, ValueError):
        constructor_signature = None
    supports_keyword_arguments = any(
        parameter.kind == inspect.Parameter.VAR_KEYWORD
        for parameter in (
            constructor_signature.parameters.values() if constructor_signature else []
        )
    )
    server_arguments = {"name": "SwordfishMCP"}

    def add_server_argument(argument_name, argument_value):
        if supports_keyword_arguments:
            server_arguments[argument_name] = argument_value
            return
        if constructor_signature and argument_name in constructor_signature.parameters:
            server_arguments[argument_name] = argument_value

    if supports_keyword_arguments or (
        constructor_signature and "version" in constructor_signature.parameters
    ):
        server_arguments["version"] = __version__
    add_server_argument("host", mcp_host)
    add_server_argument("port", mcp_port)
    add_server_argument(
        "streamable_http_path",
        mcp_streamable_http_path,
    )
    mcp_server = fast_mcp(**server_arguments)
    register_tools(
        mcp_server,
        allow_source_read=allow_source_read,
        allow_source_write=allow_source_write,
        allow_eval_arbitrary=allow_eval_arbitrary,
        allow_test_execution=allow_test_execution,
        allow_ide_read=allow_ide_read,
        allow_ide_write=allow_ide_write,
        allow_commit=allow_commit,
        allow_tracing=allow_tracing,
        integrated_session_state=integrated_session_state,
        require_gemstone_ast=require_gemstone_ast,
    )
    return mcp_server


def import_tool_registration():
    try:
        from reahl.swordfish.mcp.tools import register_tools
    except ModuleNotFoundError as module_not_found_error:
        if module_not_found_error.name == "reahl.ptongue":
            raise McpDependencyNotInstalled(
                "SwordfishMCP requires reahl-parseltongue. "
                "Install project dependencies first."
            ) from module_not_found_error
        raise
    return register_tools
