# nastran95

**NASTRAN-95**, the NASA Structural Analysis System, as an executable with a Python wrapper.

Run finite element analyses from Python, with results returned as NumPy arrays.

## Features

- **Two execution modes**: subprocess (robust) or f2py (in-process via fork)
- **Automatic output parsing**: displacements, stresses, eigenvalues → NumPy arrays
- **Full NASTRAN-95 capability**: all 13 rigid format solution types
- **Simple API**: `nastran95.run(input_deck)` → structured results
- **f2py extension**: direct Fortran binding with COMMON block access
- **Compatible with pyNastran** for BDF model generation

## Quick Start

```python
import nastran95

# Run a static analysis
result = nastran95.run("inp_clean/d01011a.inp")

if result.completed:
    disp = result.displacements[0]
    print(f"Max displacement: {disp.translations.max():.6e}")
```

See [docs/getting-started.md](docs/getting-started.md) for full documentation.

## Installation

Install both the Fortran executable and the Python wrapper using pre-built wheels:

```
pip install nastran95
```

Or, if the wheels are not available for your system, build from source (below).

## Building

First, build the NASTRAN-95 Fortran binary in the parent directory (requires gfortran):


```bash
cd build
make          # compiles ~1850 Fortran sources (~60 seconds)
cd ..
```

Then install the Python package:

```bash
uv sync
```

Optionally, build the f2py extension for in-process execution:

```bash
cd python
uv run python -m nastran95._fortran.build_ext
```

## Testing

```bash
uv run pytest python/tests/ -v
```

## Architecture

```
python/
├── nastran95/
│   ├── __init__.py          # Public API
│   ├── runner.py            # Subprocess & f2py runners
│   ├── parser.py            # F06 output parser
│   ├── models.py            # Result dataclasses
│   └── _fortran/            # f2py extension
│       ├── build_ext.py     # Build script
│       ├── nastran_entry.f   # Fortran wrapper subroutine
│       ├── exit_override.c   # EXIT/STOP interception via fork()
│       └── _nastran_core*.so # Built extension (after build_ext)
├── tests/
│   ├── test_parser.py       # Output parser tests
│   ├── test_runner.py       # Subprocess runner tests
│   ├── test_f2py.py         # f2py extension tests
│   └── test_pynastran_integration.py  # End-to-end with analytical verification
└── docs/
    ├── getting-started.md   # User guide
    └── api-reference.md     # API documentation
```
