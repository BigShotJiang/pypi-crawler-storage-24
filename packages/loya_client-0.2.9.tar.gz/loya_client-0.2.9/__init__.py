"""
LOYA API Library
"""

from .api import API

# from .client import Client

__version__ = "2.0"
