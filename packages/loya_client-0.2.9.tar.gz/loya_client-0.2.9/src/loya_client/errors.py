class LoyaException(Exception):
    pass


class HTTPException(LoyaException):
    def __init__(self, response, *, response_json):
        message = response_json.get("message", "Unknown error")
        code = response_json.get("code", response.status_code)

        super().__init__(f"[{code}] {message}")
        self.response = response
        self.code = code
        self.message = message


class BadRequest(HTTPException):
    pass


class Unauthorized(HTTPException):
    pass


class Forbidden(HTTPException):
    pass


class NotFound(HTTPException):
    pass


class TooManyRequests(HTTPException):
    pass


class LoyaServerError(HTTPException):
    pass
