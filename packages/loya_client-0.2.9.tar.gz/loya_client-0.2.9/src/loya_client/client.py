import logging

log = logging.getLogger(__name__)


class BaseClient:
    def __init__(
        self,
        token: str = "",
    ):
        self.token = token


# class Client(BaseClient):
#     pass
