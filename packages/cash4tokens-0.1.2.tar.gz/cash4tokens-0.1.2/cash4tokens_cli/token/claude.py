"""Claude Code auth helpers backed by the local `claude` CLI."""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
from pathlib import Path

log = logging.getLogger("cash4tokens.token.claude")

AUTH_STATUS_TIMEOUT_S = 10
CLAUDE_STATE_FILE = Path.home() / ".claude.json"
_UNKNOWN_STATUS = {
    "loggedIn": False,
    "authMethod": "unknown",
    "apiProvider": "unknown",
}


def get_claude_binary() -> str | None:
    """Return the local Claude Code binary when installed."""
    return shutil.which("claude")


def get_auth_status() -> dict:
    """Return `claude auth status --json` as a dict."""
    binary = get_claude_binary()
    if not binary:
        return {
            "loggedIn": False,
            "authMethod": "missing",
            "apiProvider": "missing",
        }

    try:
        result = subprocess.run(
            [binary, "auth", "status", "--json"],
            capture_output=True,
            text=True,
            timeout=AUTH_STATUS_TIMEOUT_S,
        )
    except Exception as e:
        log.warning("Failed to check Claude Code auth status: %s", e)
        return _UNKNOWN_STATUS.copy()

    raw = (result.stdout or result.stderr or "").strip()
    if not raw:
        return _UNKNOWN_STATUS.copy()

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        log.warning("Unexpected Claude Code auth status output: %s", raw[:200])
        return _UNKNOWN_STATUS.copy()

    return payload if isinstance(payload, dict) else _UNKNOWN_STATUS.copy()


def _load_state() -> dict:
    """Read Claude Code's local state file when present."""
    if not CLAUDE_STATE_FILE.exists():
        return {}

    try:
        payload = json.loads(CLAUDE_STATE_FILE.read_text())
    except (OSError, json.JSONDecodeError) as e:
        log.warning("Failed to read %s: %s", CLAUDE_STATE_FILE, e)
        return {}

    return payload if isinstance(payload, dict) else {}


def _infer_subscription_type(status: dict, state: dict) -> str:
    """Best-effort mapping from Claude Code state to provider capability tiers."""
    if not status.get("loggedIn"):
        return "unknown"

    max_tier = str(state.get("claudeMaxTier") or "").strip().lower()
    billing_type = str(
        ((state.get("oauthAccount") or {}).get("billingType") or "")
    ).strip().lower()

    if state.get("hasAvailableMaxSubscription") or (
        max_tier and max_tier not in {"not_max", "none", "false"}
    ):
        return "max"

    if billing_type in {"enterprise", "team", "organization"}:
        return "team"

    if state.get("hasAvailableSubscription") or billing_type in {
        "stripe_subscription",
        "subscription",
        "pro",
    }:
        return "pro"

    return "pro"


def get_subscription_info() -> dict:
    """Describe the local Claude Code auth state and inferred plan tier."""
    status = get_auth_status()
    state = _load_state()
    oauth_account = state.get("oauthAccount") or {}
    rate_limit_tier = state.get("claudeMaxTier") or oauth_account.get("billingType")

    return {
        "logged_in": bool(status.get("loggedIn")),
        "subscription_type": _infer_subscription_type(status, state),
        "rate_limit_tier": rate_limit_tier or "unknown",
        "auth_method": status.get("authMethod", "unknown"),
        "api_provider": status.get("apiProvider", "unknown"),
    }
