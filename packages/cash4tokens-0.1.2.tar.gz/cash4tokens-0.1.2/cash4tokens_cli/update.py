"""CLI release manifest and auto-update helpers."""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from importlib import metadata
from pathlib import Path
from typing import Any, Callable

import httpx
from packaging.version import InvalidVersion, Version

from .app_version import PACKAGE_NAME, get_cash4tokens_version

DEFAULT_SERVER_URL = "https://api.cash4tokens.com"
DEFAULT_MANIFEST_PATH = "/manifest.json"
DEFAULT_UPDATE_INTERVAL_SEC = 6 * 60 * 60
PENDING_UPDATE_RETRY_SEC = 5 * 60
FAILED_UPDATE_RETRY_SEC = 30 * 60

log = logging.getLogger("cash4tokens.update")


@dataclass(slots=True)
class ReleaseManifest:
    """Release metadata returned by the cash4tokens API manifest."""

    manifest_url: str
    latest_version: str
    package_name: str = PACKAGE_NAME
    minimum_supported_version: str | None = None
    update_check_interval_sec: int = DEFAULT_UPDATE_INTERVAL_SEC
    release_channel: str = "stable"
    release_notes_url: str | None = None
    published_at: str | None = None

    @classmethod
    def from_payload(
        cls, manifest_url: str, payload: dict[str, Any]
    ) -> "ReleaseManifest":
        """Parse a manifest payload into a typed release record."""
        if payload.get("success") is True and isinstance(payload.get("data"), dict):
            payload = payload["data"]

        latest_version = str(payload["latest_version"]).strip()
        if not latest_version:
            raise ValueError("Manifest is missing latest_version")

        return cls(
            manifest_url=manifest_url,
            latest_version=latest_version,
            package_name=str(payload.get("package_name") or PACKAGE_NAME),
            minimum_supported_version=_clean_optional_str(
                payload.get("minimum_supported_version")
            ),
            update_check_interval_sec=max(
                int(
                    payload.get("update_check_interval_sec")
                    or DEFAULT_UPDATE_INTERVAL_SEC
                ),
                PENDING_UPDATE_RETRY_SEC,
            ),
            release_channel=str(payload.get("release_channel") or "stable"),
            release_notes_url=_clean_optional_str(payload.get("release_notes_url")),
            published_at=_clean_optional_str(payload.get("published_at")),
        )


@dataclass(slots=True)
class UpdateResult:
    """Result of checking or applying an update."""

    status: str
    message: str
    current_version: str | None
    latest_version: str | None = None
    manifest: ReleaseManifest | None = None
    required: bool = False

    @property
    def applied(self) -> bool:
        return self.status == "updated"

    @property
    def available(self) -> bool:
        return self.status == "update_available"


def default_manifest_url(server_url: str | None) -> str:
    """Build the manifest URL from the configured API base URL."""
    base_url = (server_url or DEFAULT_SERVER_URL).rstrip("/")
    return f"{base_url}{DEFAULT_MANIFEST_PATH}"


def restart_current_process() -> None:
    """Replace the current process with a fresh CLI process."""
    argv = list(sys.argv)
    current_entrypoint = Path(argv[0]).expanduser()

    if current_entrypoint.exists() and current_entrypoint.name == "cash4tokens":
        os.execv(str(current_entrypoint), [str(current_entrypoint), *argv[1:]])

    os.execv(
        sys.executable,
        [sys.executable, "-m", "cash4tokens_cli.main", *argv[1:]],
    )


class UpdateManager:
    """Checks the server manifest and upgrades the installed CLI package."""

    def __init__(
        self,
        config: dict | None,
        save_config: Callable[[dict], None] | None = None,
    ) -> None:
        self.config = config if config is not None else {}
        self._save_config = save_config
        self.current_version = get_cash4tokens_version()
        self._current_version = _parse_version(self.current_version)

    @property
    def manifest_url(self) -> str:
        return str(
            self.config.get("manifest_url")
            or default_manifest_url(self.config.get("server_url"))
        )

    def should_check(self) -> bool:
        """Return whether another manifest fetch is due."""
        state = self._state()
        last_checked_at = int(state.get("last_checked_at") or 0)
        interval = max(
            int(state.get("check_interval_sec") or DEFAULT_UPDATE_INTERVAL_SEC),
            PENDING_UPDATE_RETRY_SEC,
        )

        last_status = state.get("last_status")
        if last_status == "update_available":
            interval = min(interval, PENDING_UPDATE_RETRY_SEC)
        elif last_status == "install_failed":
            interval = min(interval, FAILED_UPDATE_RETRY_SEC)

        return time.time() >= last_checked_at + interval

    def check_for_update(self, force: bool = False) -> UpdateResult:
        """Fetch the manifest and compare it with the installed version."""
        if not force and not self.should_check():
            return UpdateResult(
                status="not_due",
                message="Update check not due yet.",
                current_version=self.current_version,
            )

        try:
            manifest = self.fetch_manifest()
        except Exception as exc:
            message = f"Could not fetch release manifest: {exc}"
            self._record_status(
                status="check_failed",
                latest_version=None,
                check_interval_sec=self._state().get("check_interval_sec"),
                error=message,
            )
            return UpdateResult(
                status="check_failed",
                message=message,
                current_version=self.current_version,
            )

        if self._current_version is None:
            message = (
                "Unable to determine the installed CLI version. Skipping auto-update."
            )
            self._record_status(
                status="unknown_version",
                latest_version=manifest.latest_version,
                check_interval_sec=manifest.update_check_interval_sec,
                release_channel=manifest.release_channel,
                release_notes_url=manifest.release_notes_url,
                published_at=manifest.published_at,
                error=message,
            )
            return UpdateResult(
                status="unknown_version",
                message=message,
                current_version=self.current_version,
                latest_version=manifest.latest_version,
                manifest=manifest,
            )

        latest_version = _parse_version(manifest.latest_version)
        if latest_version is None:
            message = f"Manifest version '{manifest.latest_version}' is invalid. Skipping auto-update."
            self._record_status(
                status="check_failed",
                latest_version=manifest.latest_version,
                check_interval_sec=manifest.update_check_interval_sec,
                release_channel=manifest.release_channel,
                release_notes_url=manifest.release_notes_url,
                published_at=manifest.published_at,
                error=message,
            )
            return UpdateResult(
                status="check_failed",
                message=message,
                current_version=self.current_version,
                latest_version=manifest.latest_version,
                manifest=manifest,
            )

        required = self._is_required_update(manifest)
        if self._current_version >= latest_version and not required:
            message = f"cash4tokens CLI is up to date ({self.current_version})."
            self._record_status(
                status="up_to_date",
                latest_version=manifest.latest_version,
                check_interval_sec=manifest.update_check_interval_sec,
                release_channel=manifest.release_channel,
                release_notes_url=manifest.release_notes_url,
                published_at=manifest.published_at,
            )
            return UpdateResult(
                status="up_to_date",
                message=message,
                current_version=self.current_version,
                latest_version=manifest.latest_version,
                manifest=manifest,
            )

        if self._is_local_install():
            message = (
                "Running from a local source checkout or editable install. "
                "Skipping automatic package updates."
            )
            self._record_status(
                status="local_install",
                latest_version=manifest.latest_version,
                check_interval_sec=manifest.update_check_interval_sec,
                release_channel=manifest.release_channel,
                release_notes_url=manifest.release_notes_url,
                published_at=manifest.published_at,
                error=message,
            )
            return UpdateResult(
                status="local_install",
                message=message,
                current_version=self.current_version,
                latest_version=manifest.latest_version,
                manifest=manifest,
                required=required,
            )

        if required:
            message = (
                f"cash4tokens CLI {manifest.minimum_supported_version} or newer is required. "
                f"Installed: {self.current_version}. Latest: {manifest.latest_version}."
            )
        else:
            message = (
                f"cash4tokens CLI {manifest.latest_version} is available "
                f"(installed: {self.current_version})."
            )

        self._record_status(
            status="update_available",
            latest_version=manifest.latest_version,
            check_interval_sec=manifest.update_check_interval_sec,
            release_channel=manifest.release_channel,
            release_notes_url=manifest.release_notes_url,
            published_at=manifest.published_at,
        )
        return UpdateResult(
            status="update_available",
            message=message,
            current_version=self.current_version,
            latest_version=manifest.latest_version,
            manifest=manifest,
            required=required,
        )

    def install_update(self, manifest: ReleaseManifest) -> UpdateResult:
        """Install the release referenced by the manifest via pip."""
        if self._is_local_install():
            message = (
                "Cannot auto-update a local source checkout or editable install. "
                "Publish and install the packaged CLI for automatic updates."
            )
            self._record_status(
                status="install_failed",
                latest_version=manifest.latest_version,
                check_interval_sec=manifest.update_check_interval_sec,
                release_channel=manifest.release_channel,
                release_notes_url=manifest.release_notes_url,
                published_at=manifest.published_at,
                error=message,
            )
            return UpdateResult(
                status="install_failed",
                message=message,
                current_version=self.current_version,
                latest_version=manifest.latest_version,
                manifest=manifest,
                required=self._is_required_update(manifest),
            )

        package_spec = f"{manifest.package_name}=={manifest.latest_version}"
        cmd = [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            "--no-input",
            "--upgrade",
            package_spec,
        ]

        log.info("Installing CLI update with %s", " ".join(cmd))
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            error_output = _trim_command_output(result.stderr or result.stdout)
            message = (
                f"CLI auto-update failed: {error_output or 'pip exited with an error.'}"
            )
            self._record_status(
                status="install_failed",
                latest_version=manifest.latest_version,
                check_interval_sec=manifest.update_check_interval_sec,
                release_channel=manifest.release_channel,
                release_notes_url=manifest.release_notes_url,
                published_at=manifest.published_at,
                error=message,
            )
            return UpdateResult(
                status="install_failed",
                message=message,
                current_version=self.current_version,
                latest_version=manifest.latest_version,
                manifest=manifest,
                required=self._is_required_update(manifest),
            )

        message = f"Updated cash4tokens CLI to {manifest.latest_version}."
        self._record_status(
            status="updated",
            latest_version=manifest.latest_version,
            check_interval_sec=manifest.update_check_interval_sec,
            release_channel=manifest.release_channel,
            release_notes_url=manifest.release_notes_url,
            published_at=manifest.published_at,
        )
        return UpdateResult(
            status="updated",
            message=message,
            current_version=self.current_version,
            latest_version=manifest.latest_version,
            manifest=manifest,
            required=self._is_required_update(manifest),
        )

    def fetch_manifest(self) -> ReleaseManifest:
        """Read and validate the release manifest from the configured server."""
        headers = {
            "Accept": "application/json",
            "User-Agent": f"cash4tokens/{self.current_version}",
        }
        with httpx.Client(timeout=10, follow_redirects=True, headers=headers) as client:
            response = client.get(self.manifest_url)
            response.raise_for_status()
            payload = response.json()

        return ReleaseManifest.from_payload(self.manifest_url, payload)

    def _is_local_install(self) -> bool:
        """Return True for source checkouts and editable installs."""
        try:
            dist = metadata.distribution(PACKAGE_NAME)
            direct_url = dist.read_text("direct_url.json")
            if direct_url:
                data = json.loads(direct_url)
                if data.get("dir_info", {}).get("editable") is True:
                    return True
        except metadata.PackageNotFoundError:
            pass
        except Exception as exc:
            log.debug("Could not inspect distribution metadata: %s", exc)

        package_root = Path(__file__).resolve().parents[1]
        repo_root = Path(__file__).resolve().parents[2]
        return (package_root / ".git").exists() or (repo_root / ".git").exists()

    def _is_required_update(self, manifest: ReleaseManifest) -> bool:
        minimum_supported = _parse_version(manifest.minimum_supported_version)
        if minimum_supported is None or self._current_version is None:
            return False
        return self._current_version < minimum_supported

    def _record_status(
        self,
        *,
        status: str,
        latest_version: str | None,
        check_interval_sec: int | None,
        release_channel: str | None = None,
        release_notes_url: str | None = None,
        published_at: str | None = None,
        error: str | None = None,
    ) -> None:
        state = self._state()
        state["last_checked_at"] = int(time.time())
        state["last_status"] = status
        state["current_version"] = self.current_version
        if latest_version:
            state["latest_version"] = latest_version
        if check_interval_sec:
            state["check_interval_sec"] = int(check_interval_sec)
        if release_channel:
            state["release_channel"] = release_channel
        if release_notes_url:
            state["release_notes_url"] = release_notes_url
        if published_at:
            state["published_at"] = published_at
        if error:
            state["last_error"] = error
        else:
            state.pop("last_error", None)

        if self._save_config:
            self._save_config(self.config)

    def _state(self) -> dict[str, Any]:
        return self.config.setdefault("update", {})


def _clean_optional_str(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _parse_version(value: str | None) -> Version | None:
    if not value:
        return None
    try:
        return Version(str(value))
    except InvalidVersion:
        return None


def _trim_command_output(output: str) -> str:
    lines = [line.strip() for line in output.splitlines() if line.strip()]
    return " ".join(lines[-4:])[:500]
