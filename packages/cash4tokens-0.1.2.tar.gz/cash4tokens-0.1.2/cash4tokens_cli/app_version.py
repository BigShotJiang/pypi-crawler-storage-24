"""CLI-local version helpers."""

from __future__ import annotations

from importlib import metadata
from pathlib import Path

import tomllib

PACKAGE_NAME = "cash4tokens"


def get_cash4tokens_version() -> str:
    """Return the installed package version or the local CLI package version."""
    try:
        return metadata.version(PACKAGE_NAME)
    except metadata.PackageNotFoundError:
        pyproject_path = Path(__file__).resolve().parents[1] / "pyproject.toml"
        if pyproject_path.exists():
            data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
            return str(data.get("project", {}).get("version", "0.0.0"))

    return "0.0.0"
