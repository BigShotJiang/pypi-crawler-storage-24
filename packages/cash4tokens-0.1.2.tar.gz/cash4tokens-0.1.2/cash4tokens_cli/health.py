"""Heartbeat and capability reporting for the daemon."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from .provider.anthropic import AnthropicProvider
from .provider.openai_provider import OpenAIProvider

log = logging.getLogger("cash4tokens.health")


@dataclass
class DaemonHealth:
    provider_id: str
    anthropic: AnthropicProvider = field(default_factory=AnthropicProvider)
    openai: OpenAIProvider = field(default_factory=OpenAIProvider)
    current_load: int = 0
    max_concurrent: int = 3
    _latency_window: list[float] = field(default_factory=list)

    def record_latency(self, ms: float) -> None:
        self._latency_window.append(ms)
        if len(self._latency_window) > 10:
            self._latency_window.pop(0)

    @property
    def avg_latency_ms(self) -> float:
        if not self._latency_window:
            return 0
        return sum(self._latency_window) / len(self._latency_window)

    async def collect_capabilities(self) -> list[dict[str, Any]]:
        """Collect normalized provider capabilities for auth and heartbeats."""
        capability: list[dict[str, Any]] = []

        if await self.anthropic.is_available():
            capability.extend(
                self._normalize_capability(await self.anthropic.get_capability())
            )

        if await self.openai.is_available():
            capability.extend(
                self._normalize_capability(await self.openai.get_capability())
            )

        return capability

    async def build_heartbeat(self) -> dict:
        capability = await self.collect_capabilities()

        return {
            "type": "heartbeat",
            "provider_id": self.provider_id,
            "capability": capability,
            "active_request": self.current_load,
            "max_concurrent": self.max_concurrent,
            "avg_latency_ms": self.avg_latency_ms,
            "throttled": False,
        }

    @staticmethod
    def _normalize_capability(capability: dict[str, Any]) -> list[dict[str, Any]]:
        model_family = capability.get("model_family")
        if isinstance(model_family, list):
            base_capability = {
                key: value for key, value in capability.items() if key != "model_family"
            }
            return [
                {**base_capability, "model_family": family}
                for family in model_family
                if family
            ]

        return [capability]
