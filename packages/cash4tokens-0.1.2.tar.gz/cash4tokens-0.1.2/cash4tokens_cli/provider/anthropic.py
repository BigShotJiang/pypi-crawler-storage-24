"""Anthropic provider backed by the local Claude Code CLI."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from pathlib import Path
from typing import AsyncIterator

from .base import BaseProvider
from ..token.claude import get_auth_status, get_claude_binary, get_subscription_info

log = logging.getLogger("cash4tokens.provider.anthropic")

CLAUDE_CLI_CWD = Path.home()
CLI_TRANSCRIPT_SYSTEM_PROMPT = (
    "You are serving an OpenAI-compatible chat completion request. "
    "Return only the assistant's next reply for the conversation transcript below. "
    "Do not add role labels, XML wrappers, or explanations unless the user asked for them."
)
DATE_SUFFIX_RE = re.compile(r"-\d{8}$")

# Model families available per subscription type
SUBSCRIPTION_MODEL = {
    "max": [
        "claude-opus-4",
        "claude-sonnet-4",
        "claude-haiku-4",
        "claude-3-7-sonnet",
        "claude-3-5-haiku",
    ],
    "pro": [
        "claude-sonnet-4",
        "claude-haiku-4",
        "claude-3-7-sonnet",
        "claude-3-5-haiku",
    ],
    "team": [
        "claude-sonnet-4",
        "claude-haiku-4",
        "claude-3-7-sonnet",
        "claude-3-5-haiku",
    ],
    "free": ["claude-haiku-4", "claude-3-5-haiku"],
    "unknown": [
        "claude-sonnet-4",
        "claude-haiku-4",
        "claude-3-7-sonnet",
        "claude-3-5-haiku",
    ],
}


def _resolve_cli_model(model: str) -> str:
    """Map API-facing model ids to Claude Code CLI model names."""
    stripped = DATE_SUFFIX_RE.sub("", model or "")
    return stripped or "claude-sonnet-4-6"


def _content_to_text(content: object) -> str:
    """Flatten OpenAI-style content payloads into plain text for Claude CLI."""
    if isinstance(content, str):
        return content

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            text = _content_to_text(item)
            if text:
                parts.append(text)
        return "\n".join(parts)

    if isinstance(content, dict):
        item_type = content.get("type")
        if item_type in {"text", "input_text", "output_text"}:
            text = content.get("text")
            return text if isinstance(text, str) else ""
        if item_type == "image_url":
            return "[image omitted]"
        if item_type == "input_image":
            return "[image input omitted]"
        if item_type == "tool_result":
            payload = content.get("content")
            return _content_to_text(payload) or "[tool result omitted]"

        if isinstance(content.get("text"), str):
            return content["text"]

    return str(content) if content is not None else ""


def _message_label(message: dict) -> str:
    """Convert an OpenAI chat role to a transcript label."""
    role = message.get("role", "user")
    if role == "assistant":
        return "Assistant"
    if role == "tool":
        name = message.get("name") or message.get("tool_name") or "tool"
        return f"Tool ({name})"
    return "User"


def _build_prompt(body: dict) -> tuple[str | None, str]:
    """Render a chat transcript prompt for the Claude CLI."""
    system_parts = [CLI_TRANSCRIPT_SYSTEM_PROMPT]
    transcript: list[str] = []

    for message in body.get("messages", []):
        role = message.get("role", "")
        content = _content_to_text(message.get("content", ""))
        if role in {"system", "developer"}:
            if content:
                system_parts.append(content)
            continue

        if not content and message.get("tool_calls"):
            content = json.dumps(message["tool_calls"], ensure_ascii=False)
        if not content:
            continue

        transcript.append(f"{_message_label(message)}:\n{content}")

    if not transcript:
        transcript.append("User:\nPlease respond to the request.")

    prompt = (
        "Continue the conversation below and produce only the next assistant reply.\n\n"
        + "\n\n".join(transcript)
        + "\n\nAssistant:\n"
    )
    system_prompt = "\n\n".join(part for part in system_parts if part)
    return system_prompt or None, prompt


def _extract_message_text(event: dict) -> str:
    """Extract text content from a Claude CLI `assistant` event."""
    message = event.get("message") or {}
    content = message.get("content") or []
    parts: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text")
            if isinstance(text, str):
                parts.append(text)
    return "".join(parts)


def _extract_usage(payload: dict) -> dict[str, int]:
    """Normalize Claude CLI usage payloads."""
    usage = payload.get("usage")
    if not isinstance(usage, dict):
        return {"input_tokens": 0, "output_tokens": 0}

    return {
        "input_tokens": int(usage.get("input_tokens", 0) or 0),
        "output_tokens": int(usage.get("output_tokens", 0) or 0),
    }


def _normalize_stop(stop: object) -> list[str]:
    if isinstance(stop, str):
        return [stop]
    if isinstance(stop, list):
        return [item for item in stop if isinstance(item, str) and item]
    return []


def _apply_stop_sequences(text: str, stop: object) -> str:
    """Trim the first configured stop sequence from the response text."""
    stop_sequences = _normalize_stop(stop)
    indexes = [text.find(seq) for seq in stop_sequences if seq and seq in text]
    if not indexes:
        return text
    return text[: min(indexes)]


def _role_chunk(request_id: str, model: str) -> dict:
    return {
        "id": f"chatcmpl-{request_id}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": {"role": "assistant"},
                "finish_reason": None,
            }
        ],
    }


def _content_chunk(request_id: str, model: str, text: str) -> dict:
    return {
        "id": f"chatcmpl-{request_id}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": {"content": text},
                "finish_reason": None,
            }
        ],
    }


def _finish_chunk(request_id: str, model: str) -> dict:
    return {
        "id": f"chatcmpl-{request_id}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": {},
                "finish_reason": "stop",
            }
        ],
    }


class AnthropicProvider(BaseProvider):
    async def is_available(self) -> bool:
        status = get_auth_status()
        return bool(get_claude_binary()) and bool(status.get("loggedIn"))

    async def get_capability(self) -> dict:
        info = get_subscription_info()
        sub_type = info.get("subscription_type", "unknown")
        model_family = SUBSCRIPTION_MODEL.get(
            sub_type,
            SUBSCRIPTION_MODEL["unknown"],
        )

        return {
            "vendor": "anthropic",
            "subscription_type": sub_type,
            "rate_limit_tier": info.get("rate_limit_tier"),
            "model_family": model_family,
        }

    async def stream_inference(
        self, request_id: str, model: str, body: dict
    ) -> AsyncIterator[dict]:
        binary = get_claude_binary()
        auth = get_auth_status()
        if not binary:
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": "Claude Code CLI is not installed on this machine",
            }
            return
        if not auth.get("loggedIn"):
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": "Claude Code is not logged in on this machine",
            }
            return

        system_prompt, prompt = _build_prompt(body)
        cli_model = _resolve_cli_model(model)
        usage = {"input_tokens": 0, "output_tokens": 0}
        response_text = ""
        result_model = cli_model
        is_error = False
        error_message = ""

        cmd = [
            binary,
            "-p",
            "--output-format",
            "stream-json",
            "--verbose",
            "--no-session-persistence",
            "--setting-sources",
            "user",
            "--strict-mcp-config",
            "--disable-slash-commands",
            "--tools",
            "",
            "--model",
            cli_model,
        ]
        if system_prompt:
            cmd.extend(["--append-system-prompt", system_prompt])
        cmd.append(prompt)

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=str(CLAUDE_CLI_CWD),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )

            assert process.stdout is not None
            while True:
                raw = await process.stdout.readline()
                if not raw:
                    break

                line = raw.decode("utf-8", errors="replace").strip()
                if not line or not line.startswith("{"):
                    continue

                try:
                    event = json.loads(line)
                except ValueError:
                    continue

                event_type = event.get("type")
                if event_type == "system" and event.get("subtype") == "init":
                    result_model = event.get("model") or result_model
                elif event_type == "assistant":
                    text = _extract_message_text(event)
                    if text:
                        response_text = text
                    usage = _extract_usage(event.get("message") or event)
                    if event.get("error"):
                        error_message = str(event["error"])
                elif event_type == "result":
                    response_text = str(event.get("result") or response_text)
                    usage = _extract_usage(event)
                    is_error = bool(event.get("is_error"))
                    if is_error and not error_message:
                        error_message = response_text or "Claude Code request failed"

            returncode = await process.wait()
            if is_error or (returncode != 0 and not response_text):
                yield {
                    "type": "stream_error",
                    "request_id": request_id,
                    "error": error_message or "Claude Code request failed",
                }
                return

            response_text = _apply_stop_sequences(response_text, body.get("stop"))
            yield {
                "type": "stream_chunk",
                "request_id": request_id,
                "data": _role_chunk(request_id, result_model),
            }
            if response_text:
                yield {
                    "type": "stream_chunk",
                    "request_id": request_id,
                    "data": _content_chunk(request_id, result_model, response_text),
                }
            yield {
                "type": "stream_chunk",
                "request_id": request_id,
                "data": _finish_chunk(request_id, result_model),
            }
            yield {
                "type": "stream_complete",
                "request_id": request_id,
                "vendor": "anthropic",
                "model_resolved": result_model,
                "usage": usage,
            }
        except Exception as e:
            log.error("Claude Code streaming error: %s", e)
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": str(e),
            }
