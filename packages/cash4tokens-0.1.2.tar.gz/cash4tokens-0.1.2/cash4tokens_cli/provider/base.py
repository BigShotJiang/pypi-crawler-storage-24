"""Abstract base for AI provider implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import AsyncIterator


class BaseProvider(ABC):
    """Interface for AI inference providers (Anthropic, OpenAI)."""

    @abstractmethod
    async def is_available(self) -> bool:
        """Check if this provider's credentials are available."""
        ...

    @abstractmethod
    async def get_capability(self) -> dict:
        """Return capability info for heartbeat reporting."""
        ...

    @abstractmethod
    async def stream_inference(
        self, request_id: str, model: str, body: dict
    ) -> AsyncIterator[dict]:
        """Execute an inference request and yield message dicts.

        Yields dicts with type: stream_chunk | stream_complete | stream_error
        """
        ...
