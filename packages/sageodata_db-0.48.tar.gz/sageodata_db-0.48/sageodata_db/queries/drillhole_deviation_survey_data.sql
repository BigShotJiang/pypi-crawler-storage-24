select 
t.drillhole_no AS dh_no,                                                   --col
To_char(dh.map_100000_no)
                  || '-'
                  || To_char(dh.dh_seq_no) AS unit_hyphen,                 --col
         Trim(To_char(dh.obs_well_plan_code))
                  || Trim(To_char(dh.obs_well_seq_no, '000')) AS obs_no,   --col
         dh.dh_name                                           AS dh_name,  --col
         summ.aq_subaq                                        AS aquifer,  --col
t.declin_svy_depth AS survey_depth,                                        --col
t.declin_meas_date AS survey_date,                                         --col
-1 * t.declin_from_horiz AS dip,                                           --col
t.declin_meas_method_code AS dip_method,                                   --col
declin.declin_meas_method_desc AS dip_desc,                                --col
t.azimuth,                                                                 --col
t.azimuth_meas_type_code AS azimuth_type,                                  --col
azimuth.meas_type_desc AS azimuth_desc,                                    --col
t.comments AS survey_comments,                                             --col
t.creation_date,                                                           --col
t.created_by,                                                              --col
dh.unit_no      AS unit_long,                                              --col
dh.amg_easting                                       AS easting,  --col
dh.amg_northing                                      AS northing, --col
dh.amg_zone                                          AS zone,     --col
dh.neg_lat_deg_real                                  AS latitude, --col
dh.long_deg_real                                     AS longitude --col
from dd_declin_meas t
join dd_declin_meas_method declin on t.declin_meas_method_code = declin.declin_meas_method_code
join dd_azimuth_meas_type azimuth on t.azimuth_meas_type_code = azimuth.meas_type_code
join dd_drillhole dh on t.drillhole_no = dh.drillhole_no
join dd_drillhole_summary summ on dh.drillhole_no = summ.drillhole_no
WHERE  dh.drillhole_no IN {DH_NO}               --arg DH_NO (sequence of int): drillhole numbers or a :class:`pandas.DataFrame` with a "dh_no" column
AND dh.deletion_ind = 'N'