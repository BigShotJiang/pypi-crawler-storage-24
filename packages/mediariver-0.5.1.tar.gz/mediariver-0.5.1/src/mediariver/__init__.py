"""MediaRiver — Spec-driven media pipeline CLI."""

__version__ = "0.5.0"
