import os
from typing import List, Optional
from pathlib import Path
import subprocess
import shutil

import click
from python_on_whales.docker_client import DockerClient
from python_on_whales.utils import ValidPath

from missim_config import config_io, MissimConfig, LogLevel, Mode

from missim_cli.helpers import (
    docker_compose_path,
    get_project_root,
    call,
    get_installer,
    get_missim_version,
    is_dev_version,
    docker_bake,
    docker_manifest,
    make_dir_set_permission,
    maybe_ignore_prod,
)
from missim_cli.auth_helpers import configure_auth_prompt

DOCKER_ORG = "ghcr.io/greenroom-robotics"

DOCKER = docker_compose_path("./docker-compose.yaml")
DOCKER_DEV = docker_compose_path("./docker-compose.dev.yaml")
DOCKER_PROD = docker_compose_path("./docker-compose.prod.yaml")
DOCKER_NETWORK_HOST = docker_compose_path("./docker-compose.network-host.yaml")
DOCKER_NETWORK_PROXY = docker_compose_path("./docker-compose.network-proxy.yaml")
DOCKER_UE_EDITOR = docker_compose_path("./docker-compose.ue_editor.yaml")
DOCKER_UE_NAS = docker_compose_path("./docker-compose.ue_editor_nas_cache.yaml")
DOCKER_UE_STANDALONE = docker_compose_path("./docker-compose.ue_standalone.yaml")
DOCKER_UE_PIXEL_STREAMING = docker_compose_path("./docker-compose.ue_pixel_streaming.yaml")
DOCKER_CACHE = docker_compose_path("./docker-compose.cache.yaml")


SERVICES = [
    "missim_ui",
    "missim_core",
    "missim_ue",
    "missim_ue_pixel_streaming",
    "missim_ue_standalone",
    "missim_chart_tiler",
    "missim_chart_api",
    "missim_proxy",
]


def get_compose_files(
    mode: Mode,
    prod: bool = False,
    nas: bool = False,
    cache: bool = False,
    proxy: bool = False,
) -> List[ValidPath]:
    compose_files: List[ValidPath] = [DOCKER]
    if prod:
        compose_files.append(DOCKER_PROD)
    else:
        compose_files.append(DOCKER_DEV)

    if proxy:
        compose_files.append(DOCKER_NETWORK_PROXY)
    else:
        compose_files.append(DOCKER_NETWORK_HOST)

    if mode == Mode.UE_EDITOR:
        compose_files.append(DOCKER_UE_EDITOR)
        compose_files.append(DOCKER_UE_PIXEL_STREAMING)
        if nas:
            compose_files.append(DOCKER_UE_NAS)
    elif mode == Mode.UE_STANDALONE:
        compose_files.append(DOCKER_UE_STANDALONE)
        compose_files.append(DOCKER_UE_PIXEL_STREAMING)

    if cache:
        compose_files.append(DOCKER_CACHE)

    return compose_files


def get_docker_client(config: MissimConfig | None = None) -> DockerClient:
    """Get a docker client configured for missim with profiles support"""
    config = config or MissimConfig()
    set_env_from_config(config)

    profiles = []
    if config.proxy.enabled:
        profiles.append("proxy")

    return DockerClient(
        compose_files=get_compose_files(
            mode=config.mode,
            prod=config.prod,
            proxy=config.proxy.enabled,
        ),
        compose_project_directory=get_project_root(),
        compose_profiles=profiles,
    )


def log_config(config: MissimConfig):
    click.echo(click.style("[+] MIS-SIM Config:", fg="green"))
    click.echo(click.style(f" ⠿ Path: {config_io.get_path()}", fg="white"))
    for attr, value in config.__dict__.items():
        click.echo(
            click.style(f" ⠿ {attr}: ".ljust(26), fg="white") + click.style(str(value), fg="green")
        )


def set_env_from_config(config: MissimConfig):
    os.environ["MISSIM_VERSION"] = get_missim_version()
    os.environ["MISSIM_CONFIG"] = config_io.serialise(config)
    os.environ["MISSIM_MODE"] = config.mode.value
    os.environ["MISSIM_PROXY_ENABLED"] = "true" if config.proxy.enabled else "false"
    os.environ["MISSIM_PROXY_HTTP_PORT"] = str(config.proxy.http_port)
    os.environ["MISSIM_PROXY_HTTPS_PORT"] = str(config.proxy.https_port)

    # Middleware settings
    os.environ["ROS_DOMAIN_ID"] = str(config.discovery.ros_domain_id)
    os.environ["ROS_AUTOMATIC_DISCOVERY_RANGE"] = "SUBNET"
    os.environ["RMW_IMPLEMENTATION"] = (
        "rmw_zenoh_cpp" if config.discovery.type == "zenoh" else "rmw_fastrtps_cpp"
    )


def change_registry(image_with_registry: str, new_registry: str):
    # replace the leading part of the image with the new registry
    return new_registry + "/" + "/".join(image_with_registry.split("/")[1:])


def execute_command_on_separate_registry(
    func: callable,
    host: str,
    service: Optional[str] = None,
):
    config = config_io.read()
    docker = get_docker_client(config)
    images = docker.compose.config().services
    mapper = {}
    for service_name, service_config in images.items():
        if service and service_name != service:
            continue
        image = service_config.image
        if image:
            mapper[image] = change_registry(image, host)

    for service_name, service_config in images.items():
        if service and service_name != service:
            continue
        image = service_config.image
        if image:
            func(docker, image, mapper[image])


def tag_and_push(docker: DockerClient, local_image_tag: str, target_image_tag: str):
    docker.image.tag(local_image_tag, target_image_tag)
    docker.image.push(target_image_tag)


def pull_and_tag(docker: DockerClient, local_image_tag: str, target_image_tag: str):
    docker.image.pull(target_image_tag)
    docker.image.tag(target_image_tag, local_image_tag)


@click.group(help="Commands for the sim")
def sim():
    pass


@click.command(name="build")
@click.option(
    "-m",
    "--mode",
    type=click.Choice(Mode),  # type: ignore
)
@click.option(
    "-c",
    "--clean",
    help="Should the UE project be cleaned?",
    is_flag=True,
)
@click.option("--cache", is_flag=True, help="Enable GitHub Actions cache")
@click.argument(
    "services",
    required=False,
    nargs=-1,
    type=click.Choice(SERVICES),
)
def build(mode: Mode | None, clean: bool, cache: bool, services: List[str]):
    """Builds the sim"""
    # If building standalone, we first build the dev sim
    config = config_io.read()
    target_mode = mode or config.mode
    set_env_from_config(config)
    config.mode = target_mode
    config.prod = False
    log_config(config)

    services_list = list(services) if services else None

    if config.mode == Mode.LOW_FIDELITY:
        click.echo("Building low-fidelity...")
        docker = get_docker_client(config)
        docker.compose.build(services=services_list)
        return

    # If we are not low-fidelity, we must do Unreal things....

    # check UE cache dir
    prj_root = get_project_root()
    if not prj_root:
        raise RuntimeError("Could not find project root")

    config.mode = Mode.UE_EDITOR
    docker_ue_editor = get_docker_client(config)
    # build ue-dev container
    click.echo("Building ue-editor...")
    docker_ue_editor.compose.build(cache=True, services=services_list)

    if target_mode == Mode.UE_STANDALONE and (
        services_list is None or "missim_ue" in services_list
    ):
        click.echo("Building ue-standalone...")

        if clean:
            clean_command = """cd "${PROJECTS_HOME}/MissimProject" && ue4 clean && rm -rf dist"""
            docker_ue_editor.compose.run("missim_ue", ["bash", "-c", clean_command], remove=False)

        # run compile command first to build the Plugins for the Editor target
        compile.callback(clean=False)  # type: ignore

        package_cmd = """ && ${UNREAL_HOME}/Engine/Build/BatchFiles/RunUAT.sh  -ScriptsForProject="${PWD}/${PROJECT_NAME}.uproject" Turnkey -command=VerifySdk -platform=Linux -UpdateIfNeeded -project="${PWD}/${PROJECT_NAME}.uproject" BuildCookRun -nop4 -utf8output -nocompileeditor -skipbuildeditor -cook  -project="${PWD}/${PROJECT_NAME}.uproject"  -unrealexe="${UNREAL_HOME}/Engine/Binaries/Linux/UnrealEditor" -platform=Linux -stage -archive -package -build -pak -compressed -prereqs -archivedirectory="${PWD}/dist/" -clientconfig=Development -nocompile -nocompileuat"""
        missing_dir_hack = """ && mkdir -p dist/Linux/Engine/Binaries"""
        proj_hack = """ && mkdir -p "dist/Linux/Engine/Plugins/Runtime/GeoReferencing/Resources/" && cp -r ${UNREAL_HOME}/Engine/Plugins/Runtime/GeoReferencing/Resources/PROJ dist/Linux/Engine/Plugins/Runtime/GeoReferencing/Resources/"""
        # run UE package command to compile and cook the UE project, making the `dist` directory
        ue_project_package_command = (
            """cd "${PROJECTS_HOME}/MissimProject" """ + package_cmd + missing_dir_hack + proj_hack
        )
        docker_ue_editor.compose.run("missim_ue", ["bash", "-c", ue_project_package_command])

        # for some reason this directory is required to exist otherwise standalone does not launch
        # projects/MissimProject/dist/Linux/Engine/Binaries
        # the PROJ resources are also not installed correctly during the package command
        # what in the actual hell is going on with packaging?
        config.mode = Mode.UE_STANDALONE
        docker_ue_standalone = get_docker_client(config)

        docker_ue_standalone.compose.build()


@click.command(name="up")
@click.option(
    "--build",
    help="Should we do a docker build",
    is_flag=True,
)
@click.option(
    "--nas",
    "-n",
    help="Should we mount the NAS directory",
    is_flag=True,
)
@click.argument(
    "services",
    required=False,
    nargs=-1,
    type=click.Choice(SERVICES),
)
def up(build: bool, nas: bool, services: List[str]):
    """Starts the simulator"""
    config = config_io.read()
    dev_mode = is_dev_version()
    config.prod = maybe_ignore_prod(dev_mode, config.prod)

    log_config(config)

    # Make the log, recording and chart tiles directories
    log_directory = Path(config.log_directory).expanduser()
    recording_directory = Path(config.recording_directory).expanduser()
    charts_dir = Path(config.charts_directory).expanduser()

    # Make sure the directories exist and have the correct permissions
    config_io.get_path().chmod(0o777)
    make_dir_set_permission(log_directory)
    make_dir_set_permission(recording_directory)
    make_dir_set_permission(charts_dir)

    os.environ["MISSIM_LOG_DIR"] = str(log_directory)
    os.environ["MISSIM_CHARTS_DIR"] = str(charts_dir)
    os.environ["MISSIM_RECORDING_DIR"] = str(recording_directory)

    # If charts_dir is empty, copy the default charts
    if not os.listdir(charts_dir):
        if dev_mode:
            default_charts_dir = Path(get_project_root()) / "data/charts"
            call(f"cp -r {default_charts_dir}/* {charts_dir}")
        else:
            raise click.UsageError(
                f"Charts directory is empty ({charts_dir}). "
                f"Copy charts from the missim/data/charts folder to {charts_dir}."
            )

    docker = get_docker_client(config)
    services_list = list(services) if services else None
    docker.compose.up(detach=True, services=services_list, build=build)

    ui_url = (
        "http://localhost:5000"
        if not config.proxy.enabled
        else f"https://localhost:{config.proxy.https_port} and http://localhost:{config.proxy.http_port}"
    )
    click.secho(f"UI available at: {ui_url}", fg="green")


@click.command(name="compile")
@click.option(
    "-c",
    "--clean",
    help="Should the UE project be cleaned?",
    is_flag=True,
)
def compile(clean: bool = False):
    """Compile the UE project"""
    config = config_io.read()
    config.mode = Mode.UE_EDITOR
    docker = get_docker_client(config)
    if clean:
        docker.compose.run(
            "missim_ue",
            ["bash", "--login", "-c", 'cd "${PROJECTS_HOME}/MissimProject" && ue4 clean'],
            remove=True,
        )

    build_cmd = """${UNREAL_HOME}/Engine/Build/BatchFiles/RunUBT.sh MissimProjectEditor Development Linux -Project="${PWD}/${PROJECT_NAME}.uproject" -SkipUBTBuild -NoEngineChanges"""
    docker.compose.run(
        "missim_ue",
        ["bash", "--login", "-c", 'cd "${PROJECTS_HOME}/MissimProject" && ' + build_cmd],
        remove=True,
    )


@click.command(name="down")
@click.argument("args", nargs=-1)
def down(args: List[str]):
    """Stops the sim"""
    config = config_io.read()
    dev_mode = is_dev_version()
    config.prod = maybe_ignore_prod(dev_mode, config.prod)
    log_config(config)

    docker = get_docker_client(config)
    docker.compose.down(timeout=20)


@click.command(name="logs")
@click.option("--tail", "-n", type=int, default=None, help="Number of lines to show from the end")
@click.option("--timestamps", "-t", is_flag=True, help="Show timestamps")
@click.option(
    "--since",
    type=str,
    default=None,
    help="Show logs since timestamp (e.g. 2021-01-01T00:00:00) or relative (e.g. 42m for 42 minutes)",
)
@click.argument(
    "services",
    required=False,
    nargs=-1,
    type=click.Choice(SERVICES),
)
def logs(tail: int, timestamps: bool, since: str, services: List[str]):
    """Follow log output from containers"""
    config = config_io.read()
    docker = get_docker_client(config)
    services_list = list(services)

    output = docker.compose.logs(
        services=services_list,
        follow=True,
        tail=str(tail) if tail else "all",
        timestamps=timestamps,
        since=since,
        stream=True,
    )
    for _, stream_content in output:
        print(stream_content.decode("utf-8"), end="", flush=True)  # type: ignore


@click.command(name="restart")
@click.option("--timeout", "-t", type=int, default=20, help="Timeout in seconds (default: 20)")
@click.argument(
    "services",
    required=False,
    nargs=-1,
    type=click.Choice(SERVICES),
)
def restart(timeout: int, services: List[str]):
    """Restart containers"""
    config = config_io.read()
    docker = get_docker_client(config)
    services_list = list(services) or None
    docker.compose.restart(services=services_list, timeout=timeout)


@click.command(name="install")
def install():
    """Install MISSIM (pull Docker images)"""
    config = config_io.read()
    dev_mode = is_dev_version()
    config.prod = maybe_ignore_prod(dev_mode, config.prod)

    docker = get_docker_client(config)
    try:
        docker.compose.pull(
            [
                "missim_ui",
                "missim_core",
                "missim_proxy",
                "missim_chart_tiler",
                "missim_chart_api",
            ]
        )
    except Exception:
        click.echo(
            click.style(
                "Failed to pull MISSIM images. Have you run `missim authenticate`?",
                fg="yellow",
            )
        )


@click.command(name="base-ue")
@click.option(
    "--ue-version",
    type=str,
    default="5.7.3",
    help="The release version of Unreal Engine to build",
)
@click.option(
    "--archive",
    type=click.Path(path_type=Path),
    multiple=True,
    help="Paths to Unreal Engine archive files to use for the build",
)
def base_ue(ue_version: str, archive: List[Path]):
    """Builds the base Unreal Engine image for development"""

    cuda_ver = "12.8.1"
    ubuntu_ver = "24.04"

    args = " ".join([f"--prebuilt-archive={_archive}" for _archive in archive])

    call(
        f"ue4-docker build --ue-version {ue_version} --cuda={cuda_ver} -basetag=ubuntu{ubuntu_ver} --target=full {args} --debug",
        env={"UE4DOCKER_TAG_NAMESPACE": DOCKER_ORG},
        cwd=Path.cwd(),
    )


@click.command(name="upgrade")
@click.option("--version", help="The version to upgrade to.")
def upgrade(version: str):
    """Upgrade MISSIM CLI"""
    click.echo(f"Current version: {get_missim_version()}")
    result = click.prompt(
        "Are you sure you want to upgrade?", default="y", type=click.Choice(["y", "n"])
    )
    if result == "n":
        return

    installer = get_installer("missim-cli")
    if version:
        call(f"{installer} install --upgrade missim-config=={version}")
        call(f"{installer} install --upgrade missim-cli=={version}")
    else:
        call(f"{installer} install --upgrade missim-config")
        call(f"{installer} install --upgrade missim-cli")

    click.echo(click.style("Upgrade of MISSIM CLI complete.", fg="green"))
    click.echo(click.style("Run `missim install` to pull updated Docker images.", fg="green"))


@click.command(name="authenticate")
@click.option(
    "--username",
    help="The username to use for authentication.",
    required=True,
    prompt=True,
)
@click.option("--token", help="The token to use for authentication.", required=True, prompt=True)
def authenticate(username: str, token: str):
    """
    Authenticate with the MISSIM package repository so that you can pull images.

    To get a username and token you'll need to contact a Greenroom Robotics employee.
    """
    call(f"echo {token} | docker login ghcr.io -u {username} --password-stdin")


@click.group(name="configure")
def configure():
    """Configure MIS-SIM"""
    pass


@configure.command(name="all")
@click.option("--mode", type=click.Choice(Mode), help="The mode", default=Mode.LOW_FIDELITY)
@click.option("--prod", type=bool, help="Run in prod mode?", default=True)
@click.option("--default", is_flag=True, help="Use default values")
def configure_all(mode: Mode, prod: bool, default: bool):  # type: ignore
    """Configure all MIS-SIM settings"""

    if default:
        config = MissimConfig()
        config.mode = mode
        config.prod = prod
        config_io.write(config)
    else:
        # Check if the file exists
        if os.path.exists(config_io.get_path()):
            click.echo(
                click.style(
                    f"MIS-SIM config already exists: {config_io.get_path()}",
                    fg="yellow",
                )
            )
            result = click.prompt(
                "Do you want to overwrite it?", default="y", type=click.Choice(["y", "n"])
            )
            if result == "n":
                return

        try:
            config_current = config_io.read()
        except Exception:
            config_current = MissimConfig()

        discovery = config_current.discovery

        config = MissimConfig(
            log_level=click.prompt(
                "Log level",
                default=config_current.log_level.value,
                type=click.Choice([item.value for item in LogLevel]),
            ),
            mode=click.prompt(
                "Mode",
                default=config_current.mode.value,
                type=click.Choice([item.value for item in Mode]),
            ),
            discovery=discovery,
        )

        # Configure authentication
        config.proxy.auth_credentials = configure_auth_prompt(config)

        config_io.write(config)


@configure.command(name="auth")
@click.option(
    "-c", "--config-name", default="", help="Use a configuration file instead of the default"
)
def configure_auth(config_name: str):
    """Configure authentication for MISSIM"""
    if not os.path.exists(config_io.get_path()):
        click.echo(
            click.style(
                f"MISSIM config not found at {config_io.get_path()}. Please run 'missim configure all' first.",
                fg="red",
            )
        )
        return

    config = config_io.read()
    # Configure authentication
    config.proxy.auth_credentials = configure_auth_prompt(config)
    config_io.write(config)
    click.echo(
        click.style(
            f"Authentication configuration updated in {config_io.get_path()}",
            fg="green",
        )
    )


@click.command(name="generate")
def generate():  # type: ignore
    """Generates models, types and schemas"""
    config = config_io.read()
    config.mode = Mode.LOW_FIDELITY
    docker = get_docker_client(config)
    # click.echo(click.style("Generating models from launch params...", fg="green"))

    # docker.compose.execute(
    #     "missim_core",
    #     [
    #         "bash",
    #         "-l",
    #         "-c",
    #         'exec "$@"',
    #         "--",
    #         "python3",
    #         "-m",
    #         "parameter_persistence.generate_models",
    #         "-o",
    #         "/home/ros/missim_core/src/missim_config/missim_config",
    #     ],
    # )
    click.echo(click.style("Generating schemas for MissimConfig", fg="green"))
    subprocess.run(
        ["python3", "-m", "missim_config.generate_schemas"],
        check=True,
        text=True,
        capture_output=True,
    )
    click.echo(click.style("Generating typescript from ROS...", fg="green"))
    docker.compose.execute(
        "missim_core",
        [
            "npx",
            "-y",
            "ros-typescript-generator",
        ],
    )

    click.echo(click.style("Generating typescript from python...", fg="green"))
    docker.compose.execute("missim_core", ["bash", "-l", "./scripts/generate.sh"])

    click.echo(click.style("Running eslint...", fg="green"))
    subprocess.run(
        ["npm", "run", "lint:fix"],
        check=True,
        text=True,
        capture_output=True,
        cwd=get_project_root() / "projects" / "missim_ui",
    )


@click.command(name="test-core")
def test_core():  # type: ignore
    """Runs the tests for missim_core"""
    config = config_io.read()
    config.mode = Mode.LOW_FIDELITY
    docker = get_docker_client(config)
    docker.compose.run(
        "missim_core",
        [
            "platform",
            "ros",
            "test",
            "--package",
            "vessel_manager",
            "--package",
            "missim_scenarios",
        ],
    )


@click.command(name="config")
def config():  # type: ignore
    """Read Config"""
    config = config_io.read()
    log_config(config)


@click.command(name="bake")
@click.option(
    "--version",
    type=str,
    required=True,
    help="The version to bake. Default: latest",
)
@click.option(
    "--push",
    type=bool,
    default=False,
    is_flag=True,
    help="Should we push the images to the registry? Default: False",
)
@click.argument("services", nargs=-1)
def bake(version: str, push: bool, services: List[str]):  # type: ignore
    """Bakes the docker containers"""
    config = config_io.read()
    compose_files = get_compose_files(config.mode, prod=False)
    docker_bake(
        version=version,
        services=services,
        push=push,
        compose_files=compose_files,
    )


@click.command(name="manifest")
@click.option(
    "--version",
    type=str,
    required=True,
    help="The version to create manifests for",
)
def manifest(version: str):  # type: ignore
    """Create and push multi-arch Docker manifests for missim images"""
    config = config_io.read()
    images = [
        "missim_ui",
        "missim_core",
        "missim_proxy",
    ]

    if config.mode == Mode.UE_STANDALONE:
        images.extend(
            [
                "missim_ue_standalone",
                "missim_ue_pixel_streaming",
            ]
        )

    docker_manifest(version=version, images=images, archs=["amd64"])


@click.command(name="ue-generate")
@click.argument("packages", nargs=-1, required=True)
def ue_generate(packages: List[str]):  # type: ignore
    """Generate UE GRUESensor Interfaces

    This command generates UE GRUESensor interfaces using the specified packages.
    It runs a Docker container with the necessary compose files and executes a shell script
    to generate the interfaces.

    Args:
        packages (List[str]): The packages for which to generate the interfaces. <package_name> <package_name> ...
    """

    config = config_io.read()
    config.mode = Mode.UE_EDITOR
    docker = get_docker_client(config)
    command = ["/bin/bash", "/home/ue4/mis_sim/generate_interfaces.sh"]
    if packages:
        command.extend(packages)
    click.echo(f"Generating interfaces for {', '.join(packages)}")
    docker.compose.run("missim_ue", command)
    click.echo(
        "Interfaces generated. Make sure you bump the versions in the missim_ue package.xml files."
    )


@click.command(name="pull-local")
@click.option(
    "--host",
    "-h",
    type=str,
    required=True,
    help="The host to pull the images from, ie localhost:5555",
)
@click.argument(
    "service",
    required=False,
    type=click.Choice(SERVICES),
)
def pull_local(host: str, service: Optional[str] = None):  # type: ignore
    """Pull images from a local registry"""
    execute_command_on_separate_registry(pull_and_tag, host, service)


@click.command(name="push-local")
@click.option(
    "--host",
    "-h",
    type=str,
    required=True,
    help="The host to push the images to, ie localhost:5555",
    default="localhost:5555",
)
@click.argument(
    "service",
    required=False,
    type=click.Choice(SERVICES),
)
def push_local(host: str, service: Optional[str] = None):  # type: ignore
    """Push images to a local registry"""
    execute_command_on_separate_registry(tag_and_push, host, service)


def _ensure_submodule_remote(repo_root: Path, submodule_path: Path, submodule_name: str):
    """Ensure the origin remote is configured for a de-absorbed submodule.

    The de-absorption process can lose the remote config. This reads the URL
    from .gitmodules and sets it as the origin remote.
    """

    url = subprocess.check_output(
        ["git", "config", "--file", ".gitmodules", "--get", f"submodule.{submodule_name}.url"],
        cwd=repo_root,
        text=True,
    ).strip()

    if not url:
        return

    # Check if origin already exists
    result = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        cwd=submodule_path,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        # No origin remote, add it
        call(f"git remote add origin {url}", cwd=submodule_path)
        click.echo(click.style(f"  Set origin remote to {url}", fg="blue"))
    elif result.stdout.strip() != url:
        # Origin exists but wrong URL, update it
        call(f"git remote set-url origin {url}", cwd=submodule_path)
        click.echo(click.style(f"  Updated origin remote to {url}", fg="blue"))


@click.command(name="update-ue")
def update_ue():
    """Update the Unreal Engine submodule and pull LFS content.

    This command initialises and updates the MissimProject submodule and its nested
    submodules (GRUESensors, rclUE), then pulls all Git LFS content. The submodule
    is automatically de-absorbed so that Unreal Editor's source control integration
    works correctly.
    """

    root = get_project_root()

    click.echo(click.style("Updating Unreal Engine submodule...", fg="blue"))

    # Initialize and update submodules recursively
    call("git submodule update --init --recursive projects/MissimProject", cwd=root)
    click.echo(click.style("Pulling LFS content for all submodules...", fg="blue"))
    call("git submodule foreach --recursive 'git lfs pull'", cwd=root)

    # De-absorb the git directory for Unreal Editor source control
    missim_project = root / "projects" / "MissimProject"
    gitfile = missim_project / ".git"

    if gitfile.is_file():
        click.echo(
            click.style("De-absorbing .git directory for Unreal source control...", fg="blue")
        )

        # Read the gitdir path from the gitfile
        gitdir_content = gitfile.read_text().strip()
        if gitdir_content.startswith("gitdir: "):
            gitdir_rel = gitdir_content.replace("gitdir: ", "")
            gitdir_abs = (missim_project / gitdir_rel).resolve()

            if gitdir_abs.is_dir():
                # Remove the gitfile and copy the actual git directory
                gitfile.unlink()
                shutil.copytree(gitdir_abs, gitfile)

                # Remove core.worktree directly from the copied config file.
                # Can't use `git config --unset` with cwd because the stale
                # relative worktree path prevents git from operating.
                config_file = gitfile / "config"
                subprocess.run(
                    ["git", "config", "--file", str(config_file), "--unset", "core.worktree"],
                    check=False,
                )

                # Ensure origin remote is set (gets lost during de-absorption)
                _ensure_submodule_remote(root, missim_project, "projects/MissimProject")

                click.echo(click.style("✓ .git directory de-absorbed successfully!", fg="green"))
            else:
                raise click.ClickException(f"Git directory not found at {gitdir_abs}")
        else:
            raise click.ClickException(f"Unexpected gitfile format: {gitdir_content}")
    elif gitfile.is_dir():
        click.echo(
            click.style("i .git is already a directory, no de-absorption needed.", fg="yellow")
        )

    click.echo(click.style("✓ Unreal Engine submodule updated successfully!", fg="green"))
