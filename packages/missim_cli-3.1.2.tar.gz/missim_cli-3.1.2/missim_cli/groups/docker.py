import click
import requests

from missim_cli.helpers import call
from missim_config import config_io
from missim_cli.groups.base import get_docker_client


@click.group(help="Docker convenience methods")
def docker():
    pass


@click.command(name="clearlogs")
def clearlogs():  # type: ignore
    """Clears all the docker logs"""
    command = 'sudo sh -c "truncate -s 0 /var/lib/docker/containers/*/*-json.log"'
    call(command)


def change_registry(image_with_registry: str, new_registry: str):
    # replace the leading part of the image with the new registry
    return new_registry + "/" + "/".join(image_with_registry.split("/")[1:])


@click.command(name="pull-registry")
@click.option(
    "--host",
    "-h",
    type=str,
    required=True,
    default="localhost:5555",
    help="The registry to pull the images from, ie localhost:5555",
)
def pull_registry(host: str):  # type: ignore
    """Pull images from a registry"""
    config = config_io.read()
    docker = get_docker_client(config)
    all_services = docker.compose.config().services

    for service_name, service_config in all_services.items():
        local_image_tag = service_config.image
        if local_image_tag is None:
            continue
        target_image_tag = change_registry(local_image_tag, host)
        docker.image.pull(target_image_tag)
        docker.image.tag(target_image_tag, local_image_tag)


@click.command(name="push-registry")
@click.option(
    "--host",
    "-h",
    type=str,
    required=True,
    default="localhost:5555",
    help="The registry to push the images to, ie localhost:5555",
)
def push_registry(host: str):  # type: ignore
    """Push images to a registry"""
    config = config_io.read()
    docker = get_docker_client(config)
    all_services = docker.compose.config().services

    for service_name, service_config in all_services.items():
        local_image_tag = service_config.image
        if local_image_tag is None:
            continue
        target_image_tag = change_registry(local_image_tag, host)
        docker.image.tag(local_image_tag, target_image_tag)
        docker.image.push(target_image_tag)


@click.command(name="registry")
@click.option("--port", type=int, default=5555)
@click.option("--persist", type=bool, default=True, is_flag=True)
@click.option("--restart", type=bool, default=False, is_flag=True)
@click.option("--clean-volume", type=bool, default=False, is_flag=True)
@click.argument("up_or_down", type=str)
def registry(port: int, persist: bool, restart: bool, clean_volume: bool, up_or_down: str):  # type: ignore
    """Starts or stops a local docker registry"""
    cmd = f"docker run -d -p {port}:5000"
    if persist:
        cmd += " --name registry -v /var/lib/registry:/var/lib/registry"
    if restart:
        cmd += " --restart=always"

    cmd += " registry:latest"
    if up_or_down == "up":
        call(cmd)
    elif up_or_down == "down":
        call("docker stop registry")
        call("docker rm registry")
        if clean_volume:
            call("sudo rm -rf /var/lib/registry")
    else:
        raise click.ClickException("Invalid command")


@click.command(name="list-registry")
@click.option("--host", type=str, default="localhost:5555")
def list_registry(host: str):  # type: ignore
    """List repositories in a registry"""
    response = requests.get(f"http://{host}/v2/_catalog")
    if response.status_code == 200:
        repositories = response.json().get("repositories", [])
        click.echo(f"Repositories: {repositories}")
    else:
        click.echo(f"Failed to fetch repositories: {response.status_code}")
