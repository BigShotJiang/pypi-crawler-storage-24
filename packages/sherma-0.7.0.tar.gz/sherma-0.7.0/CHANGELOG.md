## v0.7.0 (2026-03-10)

### Feat

- interrupts are here (#7)

## v0.6.0 (2026-03-10)

### Feat

- skill declarative agent is here (#6)

## v0.5.0 (2026-03-09)

### Feat

- declarative agents using yaml (#5)

## v0.4.0 (2026-03-09)

### Feat

- add agent input and output schema (#4)

## v0.3.1 (2026-03-09)

### Fix

- improve interfaces (#3)

## v0.3.0 (2026-03-09)

### Feat

- sherma is here (#2)

## v0.2.0 (2026-03-05)

### Feat

- init repo (#1)
