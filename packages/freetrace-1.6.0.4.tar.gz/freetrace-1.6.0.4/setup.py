# Modified by Claude (claude-opus-4-6, Anthropic AI) — build Cython extensions at pip install time
import os
import numpy as np
from setuptools import setup, Extension

# Try Cython; fall back to pre-generated .c files
try:
    from Cython.Build import cythonize
    USE_CYTHON = True
except ImportError:
    USE_CYTHON = False

_modules = ["image_pad", "regression", "cost_function"]

# Resolve paths: "src/" layout in source tree, flat layout in sdist
_src_cython = os.path.join("src", "FreeTrace", "module", "cython_build")
_flat_cython = os.path.join("FreeTrace", "module", "cython_build")
_src_module = os.path.join("src", "FreeTrace", "module")
_flat_module = os.path.join("FreeTrace", "module")

if os.path.isdir(_src_cython):
    _cython_dir = _src_cython
    _module_dir = _src_module
else:
    _cython_dir = _flat_cython
    _module_dir = _flat_module

if USE_CYTHON:
    ext_modules = cythonize(
        [
            Extension(
                f"FreeTrace.module.{mod}",
                sources=[os.path.join(_cython_dir, f"{mod}.pyx")],
                include_dirs=[np.get_include()],
            )
            for mod in _modules
        ],
        language_level="3",
    )
else:
    # Fall back to pre-generated C files
    ext_modules = [
        Extension(
            f"FreeTrace.module.{mod}",
            sources=[os.path.join(_module_dir, f"{mod}.c")],
            include_dirs=[np.get_include()],
        )
        for mod in _modules
    ]

setup(ext_modules=ext_modules)
