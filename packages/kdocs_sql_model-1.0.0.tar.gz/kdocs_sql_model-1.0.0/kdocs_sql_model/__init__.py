#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KDocsSQL Model - 类似 sqlite3 的数据库操作接口

提供与 sqlite3 模块兼容的 API，降低学习成本。
"""

from .kdocs_sql_model import (
    connect,
    Connection,
    Cursor,
    KDocsSQLError,
    OperationalError,
    DatabaseError,
    ProgrammingError,
    complete_statement,
    apilevel,
    threadsafety,
    paramstyle,
)
from ._client import KDocsSQLClient

__version__ = "1.0.0"
__author__ = "xiaomayisjh"

__all__ = [
    'connect',
    'Connection',
    'Cursor',
    'KDocsSQLError',
    'OperationalError',
    'DatabaseError',
    'ProgrammingError',
    'complete_statement',
    'apilevel',
    'threadsafety',
    'paramstyle',
    'KDocsSQLClient',
]
