#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KDocsSQL Python Client - 金山文档 SQL 引擎客户端

内部模块，用于 HTTP API 调用。
"""

import json

try:
    import requests
except ImportError:
    raise ImportError("缺少 requests 库，请运行: pip install requests")


class KDocsSQLClient:
    """
    KDocsSQL Python 客户端
    
    用于通过 HTTP API 调用金山文档 AirScript SQL 引擎。
    
    Attributes:
        api_token (str): AirScript API Token
        webhook_url (str): Webhook URL
        timeout (int): 请求超时时间(秒)
    """
    
    def __init__(self, api_token, webhook_url, timeout=30):
        self.api_token = api_token
        self.webhook_url = webhook_url
        self.timeout = timeout
    
    def execute(self, sql):
        """
        执行 SQL 语句
        
        Args:
            sql (str): SQL 语句
        
        Returns:
            dict: 执行结果
        """
        headers = {
            "Content-Type": "application/json",
            "AirScript-Token": self.api_token
        }
        payload = {"Context": {"argv": {"sql": sql}}}
        
        try:
            response = requests.post(
                self.webhook_url,
                headers=headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code != 200:
                return {
                    "success": False,
                    "error": "HTTP_ERROR",
                    "message": f"HTTP {response.status_code}: {response.text[:200]}"
                }
            
            return self._parse_response(response.json())
            
        except requests.exceptions.Timeout:
            return {
                "success": False,
                "error": "TIMEOUT",
                "message": f"请求超时 ({self.timeout}秒)"
            }
        except requests.exceptions.ConnectionError:
            return {
                "success": False,
                "error": "CONNECTION_ERROR",
                "message": "网络连接失败"
            }
        except json.JSONDecodeError:
            return {
                "success": False,
                "error": "JSON_ERROR",
                "message": "响应解析失败"
            }
        except Exception as e:
            return {
                "success": False,
                "error": "UNKNOWN_ERROR",
                "message": str(e)
            }
    
    def _parse_response(self, response):
        """解析 API 响应"""
        if not response.get("success") and response.get("error"):
            return {
                "success": False,
                "error": "API_ERROR",
                "message": response.get("error", "未知错误")
            }
        
        data = response.get("data", {})
        result = data.get("result", {})
        
        if not result.get("success", True):
            return {
                "success": False,
                "error": result.get("error", "EXECUTION_ERROR"),
                "message": result.get("message", "执行失败"),
                "position": result.get("position")
            }
        
        return {
            "success": True,
            "type": result.get("type", ""),
            "data": result.get("data", []),
            "rowCount": result.get("rowCount", 0),
            "affectedRows": result.get("affectedRows", 0),
            "columns": result.get("columns", []),
            "executionTime": result.get("executionTime", 0)
        }
