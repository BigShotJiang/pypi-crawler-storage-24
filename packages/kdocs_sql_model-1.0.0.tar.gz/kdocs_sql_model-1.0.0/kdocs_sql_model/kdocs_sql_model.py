#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KDocsSQL Model - 类似 sqlite3 的数据库操作接口

提供与 sqlite3 模块兼容的 API，降低学习成本。

使用方法:
    import kdocs_sql_model as ksql
    
    # 方式1: 类似 sqlite3 的用法
    conn = ksql.connect(api_token, webhook_url)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Sheet1 WHERE id = ?", (1,))
    rows = cursor.fetchall()
    conn.close()
    
    # 方式2: 使用上下文管理器
    with ksql.connect(api_token, webhook_url) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Sheet1")
        for row in cursor:
            print(row)
    
    # 方式3: 简化的直接执行
    with ksql.connect(api_token, webhook_url) as conn:
        for row in conn.execute("SELECT * FROM Sheet1"):
            print(row)

依赖: requests库 (pip install requests)
"""

from typing import Any, Dict, Iterator, List, Optional, Tuple, Union

from ._client import KDocsSQLClient


class KDocsSQLError(Exception):
    """KDocsSQL 基础异常"""
    pass


class OperationalError(KDocsSQLError):
    """操作错误（SQL语法错误、表不存在等）"""
    pass


class DatabaseError(KDocsSQLError):
    """数据库错误"""
    pass


class Cursor:
    """
    数据库游标类
    
    用于执行 SQL 语句并获取结果，接口与 sqlite3.Cursor 兼容。
    
    Attributes:
        description: 结果列描述 (name, type_code, ...)
        rowcount: 影响的行数
        lastrowid: 最后插入的行ID (KDocsSQL不支持，始终为None)
        arrayszie: fetchmany() 默认获取行数
    """
    
    def __init__(self, connection: 'Connection'):
        self._connection = connection
        self._client = connection._client
        self._result: Optional[Dict] = None
        self._rows: List[Dict] = []
        self._row_index: int = 0
        self._closed: bool = False
        
        self.description: Optional[Tuple] = None
        self.rowcount: int = -1
        self.lastrowid: Optional[int] = None
        self.arraysize: int = 1
    
    def _check_closed(self):
        if self._closed:
            raise ProgrammingError("Cursor 已关闭")
    
    def _format_row(self, row: Dict) -> Tuple:
        """将字典行转换为元组"""
        if not self.description:
            return tuple(row.values())
        return tuple(row.get(col[0]) for col in self.description)
    
    def execute(self, sql: str, parameters: Optional[Tuple] = None) -> 'Cursor':
        """
        执行 SQL 语句
        
        Args:
            sql: SQL 语句，支持 ? 占位符
            parameters: 参数元组
        
        Returns:
            Cursor: 返回自身，支持链式调用
        
        Example:
            >>> cursor.execute("SELECT * FROM users WHERE id = ?", (1,))
            >>> cursor.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("张三", 25))
        """
        self._check_closed()
        
        if parameters:
            sql = self._format_sql(sql, parameters)
        
        self._result = self._client.execute(sql)
        
        if not self._result.get('success'):
            error_msg = self._result.get('message', '未知错误')
            raise OperationalError(error_msg)
        
        self._rows = self._result.get('data', [])
        self._row_index = 0
        
        columns = self._result.get('columns', [])
        if columns:
            self.description = tuple((col, None) for col in columns)
        else:
            self.description = None
        
        if self._result.get('type') == 'SELECT':
            self.rowcount = len(self._rows)
        else:
            self.rowcount = self._result.get('affectedRows', 0)
        
        return self
    
    def executemany(self, sql: str, seq_of_parameters: List[Tuple]) -> 'Cursor':
        """
        批量执行 SQL 语句
        
        Args:
            sql: SQL 语句模板
            seq_of_parameters: 参数序列
        
        Returns:
            Cursor: 返回自身
        
        Example:
            >>> cursor.executemany(
            ...     "INSERT INTO users (name, age) VALUES (?, ?)",
            ...     [("张三", 25), ("李四", 30)]
            ... )
        """
        self._check_closed()
        
        total_affected = 0
        for params in seq_of_parameters:
            formatted_sql = self._format_sql(sql, params)
            result = self._client.execute(formatted_sql)
            if not result.get('success'):
                raise OperationalError(result.get('message', '执行失败'))
            total_affected += result.get('affectedRows', 0)
        
        self.rowcount = total_affected
        self._rows = []
        self.description = None
        
        return self
    
    def _format_sql(self, sql: str, parameters: Tuple) -> str:
        """格式化 SQL，替换 ? 占位符"""
        result = []
        param_index = 0
        i = 0
        
        while i < len(sql):
            if sql[i] == '?' and param_index < len(parameters):
                val = parameters[param_index]
                param_index += 1
                result.append(self._format_value(val))
                i += 1
            elif sql[i] == "'":
                j = i + 1
                while j < len(sql) and sql[j] != "'":
                    if sql[j] == "'" and j + 1 < len(sql) and sql[j + 1] == "'":
                        j += 2
                    else:
                        j += 1
                result.append(sql[i:j + 1])
                i = j + 1
            else:
                result.append(sql[i])
                i += 1
        
        return ''.join(result)
    
    def _format_value(self, val: Any) -> str:
        """格式化参数值"""
        if val is None:
            return 'NULL'
        elif isinstance(val, bool):
            return "'1'" if val else "'0'"
        elif isinstance(val, (int, float)):
            return f"'{val}'"
        elif isinstance(val, str):
            escaped = val.replace("'", "''")
            return f"'{escaped}'"
        else:
            escaped = str(val).replace("'", "''")
            return f"'{escaped}'"
    
    def fetchone(self) -> Optional[Tuple]:
        """
        获取下一行结果
        
        Returns:
            元组或 None
        """
        self._check_closed()
        
        if self._row_index < len(self._rows):
            row = self._rows[self._row_index]
            self._row_index += 1
            return self._format_row(row)
        return None
    
    def fetchmany(self, size: Optional[int] = None) -> List[Tuple]:
        """
        获取多行结果
        
        Args:
            size: 获取行数，默认使用 arraysize
        
        Returns:
            行列表
        """
        self._check_closed()
        
        if size is None:
            size = self.arraysize
        
        rows = []
        while len(rows) < size and self._row_index < len(self._rows):
            rows.append(self._format_row(self._rows[self._row_index]))
            self._row_index += 1
        
        return rows
    
    def fetchall(self) -> List[Tuple]:
        """
        获取所有剩余结果
        
        Returns:
            行列表
        """
        self._check_closed()
        
        rows = []
        while self._row_index < len(self._rows):
            rows.append(self._format_row(self._rows[self._row_index]))
            self._row_index += 1
        
        return rows
    
    def fetchone_dict(self) -> Optional[Dict]:
        """获取下一行结果（字典格式）"""
        self._check_closed()
        
        if self._row_index < len(self._rows):
            row = self._rows[self._row_index]
            self._row_index += 1
            return row.copy()
        return None
    
    def fetchall_dict(self) -> List[Dict]:
        """获取所有结果（字典格式）"""
        self._check_closed()
        
        rows = self._rows[self._row_index:]
        self._row_index = len(self._rows)
        return [row.copy() for row in rows]
    
    def scroll(self, value: int, mode: str = 'relative'):
        """
        滚动游标位置
        
        Args:
            value: 滚动值
            mode: 'relative' 相对滚动，'absolute' 绝对定位
        """
        self._check_closed()
        
        if mode == 'relative':
            new_index = self._row_index + value
        elif mode == 'absolute':
            new_index = value
        else:
            raise ProgrammingError(f"无效的滚动模式: {mode}")
        
        if new_index < 0 or new_index > len(self._rows):
            raise IndexError("游标超出范围")
        
        self._row_index = new_index
    
    def close(self):
        """关闭游标"""
        self._closed = True
        self._rows = []
        self._result = None
    
    @property
    def closed(self) -> bool:
        """游标是否已关闭"""
        return self._closed
    
    def __iter__(self) -> Iterator[Tuple]:
        return self
    
    def __next__(self) -> Tuple:
        row = self.fetchone()
        if row is None:
            raise StopIteration
        return row
    
    def __enter__(self) -> 'Cursor':
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


class ProgrammingError(KDocsSQLError):
    """编程错误"""
    pass


class Connection:
    """
    数据库连接类
    
    管理与 KDocsSQL 的连接，接口与 sqlite3.Connection 兼容。
    
    Attributes:
        row_factory: 行工厂（暂不支持）
        text_factory: 文本工厂（暂不支持）
    """
    
    def __init__(self, api_token: str, webhook_url: str, timeout: int = 30):
        self._client = KDocsSQLClient(api_token, webhook_url, timeout)
        self._closed = False
        self._cursors: List[Cursor] = []
        
        self.row_factory = None
        self.text_factory = str
    
    def _check_closed(self):
        if self._closed:
            raise ProgrammingError("Connection 已关闭")
    
    def cursor(self) -> Cursor:
        """
        创建游标
        
        Returns:
            Cursor: 新的游标对象
        """
        self._check_closed()
        
        cursor = Cursor(self)
        self._cursors.append(cursor)
        return cursor
    
    def execute(self, sql: str, parameters: Optional[Tuple] = None) -> Cursor:
        """
        直接执行 SQL（创建临时游标）
        
        Args:
            sql: SQL 语句
            parameters: 参数元组
        
        Returns:
            Cursor: 游标对象
        """
        self._check_closed()
        
        cursor = self.cursor()
        return cursor.execute(sql, parameters)
    
    def executemany(self, sql: str, seq_of_parameters: List[Tuple]) -> Cursor:
        """
        批量执行 SQL
        
        Args:
            sql: SQL 语句
            seq_of_parameters: 参数序列
        
        Returns:
            Cursor: 游标对象
        """
        self._check_closed()
        
        cursor = self.cursor()
        return cursor.executemany(sql, seq_of_parameters)
    
    def executescript(self, sql_script: str) -> Cursor:
        """
        执行多条 SQL 语句（以分号分隔）
        
        Args:
            sql_script: SQL 脚本
        
        Returns:
            Cursor: 最后一个语句的游标
        """
        self._check_closed()
        
        statements = [s.strip() for s in sql_script.split(';') if s.strip()]
        cursor = None
        
        for sql in statements:
            cursor = self.execute(sql)
        
        return cursor
    
    def close(self):
        """关闭连接"""
        self._closed = True
        
        for cursor in self._cursors:
            if not cursor.closed:
                cursor.close()
        
        self._cursors.clear()
    
    @property
    def closed(self) -> bool:
        """连接是否已关闭"""
        return self._closed
    
    def commit(self):
        """提交事务（KDocsSQL 不支持事务，此方法为空操作）"""
        pass
    
    def rollback(self):
        """回滚事务（KDocsSQL 不支持事务，此方法为空操作）"""
        pass
    
    def tables(self) -> List[str]:
        """
        获取所有表名
        
        注意: KDocsSQL 不支持 SHOW TABLES，此方法返回空列表。
        用户需要知道表名才能查询。
        
        Returns:
            表名列表
        """
        return []
    
    def columns(self, table: str) -> List[str]:
        """
        获取表的列名
        
        Args:
            table: 表名
        
        Returns:
            列名列表
        """
        if self.description:
            return [col[0] for col in self.description]
        return []
    
    def select(self, table: str, columns: Union[str, List[str]] = "*", 
               where: Optional[str] = None, order_by: Optional[str] = None,
               limit: Optional[int] = None, offset: Optional[int] = None) -> Cursor:
        """
        执行 SELECT 查询（便捷方法）
        
        Args:
            table: 表名
            columns: 列名，默认 "*"，可传列表
            where: WHERE 条件
            order_by: ORDER BY 子句
            limit: LIMIT 数量
            offset: OFFSET 偏移量
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.select("Sheet1", ["name", "age"], "age > 20", "age DESC", 10)
        """
        if isinstance(columns, list):
            columns = ", ".join(columns)
        
        sql = f"SELECT {columns} FROM {table}"
        
        if where:
            sql += f" WHERE {where}"
        
        if order_by:
            sql += f" ORDER BY {order_by}"
        
        if limit:
            sql += f" LIMIT {limit}"
            if offset:
                sql += f" OFFSET {offset}"
        
        return self.execute(sql)
    
    def insert(self, table: str, data: Union[Dict, List[Dict]]) -> Cursor:
        """
        执行 INSERT 插入（便捷方法）
        
        Args:
            table: 表名
            data: 要插入的数据，单行为字典，多行为列表
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.insert("Sheet1", {"name": "张三", "age": "25"})
            >>> conn.insert("Sheet1", [{"name": "张三"}, {"name": "李四"}])
        """
        if isinstance(data, dict):
            data = [data]
        
        if not data:
            raise ProgrammingError("数据为空")
        
        columns = list(data[0].keys())
        values_list = []
        
        for row in data:
            values = []
            for col in columns:
                val = row.get(col)
                if val is None:
                    values.append("NULL")
                elif isinstance(val, str):
                    values.append(f"'{val.replace(chr(39), chr(39)+chr(39))}'")
                else:
                    values.append(f"'{val}'")
            values_list.append(f"({', '.join(values)})")
        
        sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES {', '.join(values_list)}"
        return self.execute(sql)
    
    def update(self, table: str, data: Dict, where: str) -> Cursor:
        """
        执行 UPDATE 更新（便捷方法）
        
        Args:
            table: 表名
            data: 要更新的数据
            where: WHERE 条件
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.update("Sheet1", {"status": "active"}, "id = '1'")
        """
        if not data:
            raise ProgrammingError("数据为空")
        
        if not where:
            raise ProgrammingError("UPDATE 必须指定 WHERE 条件")
        
        set_items = []
        for col, val in data.items():
            if val is None:
                set_items.append(f"{col} = NULL")
            elif isinstance(val, str):
                set_items.append(f"{col} = '{val.replace(chr(39), chr(39)+chr(39))}'")
            else:
                set_items.append(f"{col} = '{val}'")
        
        sql = f"UPDATE {table} SET {', '.join(set_items)} WHERE {where}"
        return self.execute(sql)
    
    def delete(self, table: str, where: str) -> Cursor:
        """
        执行 DELETE 删除（便捷方法）
        
        Args:
            table: 表名
            where: WHERE 条件
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.delete("Sheet1", "id = '1'")
        """
        if not where:
            raise ProgrammingError("DELETE 必须指定 WHERE 条件")
        
        sql = f"DELETE FROM {table} WHERE {where}"
        return self.execute(sql)
    
    def create_table(self, table: str, columns: List[str], if_not_exists: bool = False) -> Cursor:
        """
        创建表（便捷方法）
        
        Args:
            table: 表名
            columns: 列名列表
            if_not_exists: 是否添加 IF NOT EXISTS
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.create_table("users", ["id", "name", "age"])
        """
        if_not_clause = "IF NOT EXISTS " if if_not_exists else ""
        columns_str = ", ".join(columns)
        sql = f"CREATE TABLE {if_not_clause}{table} ({columns_str})"
        return self.execute(sql)
    
    def drop_table(self, table: str, if_exists: bool = False) -> Cursor:
        """
        删除表（便捷方法）
        
        Args:
            table: 表名
            if_exists: 是否添加 IF EXISTS
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.drop_table("users", if_exists=True)
        """
        if_exists_clause = "IF EXISTS " if if_exists else ""
        sql = f"DROP TABLE {if_exists_clause}{table}"
        return self.execute(sql)
    
    def truncate_table(self, table: str) -> Cursor:
        """
        清空表数据（便捷方法）
        
        Args:
            table: 表名
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.truncate_table("users")
        """
        sql = f"TRUNCATE TABLE {table}"
        return self.execute(sql)
    
    def add_column(self, table: str, column: str) -> Cursor:
        """
        添加列（便捷方法）
        
        Args:
            table: 表名
            column: 列名
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.add_column("users", "email")
        """
        sql = f"ALTER TABLE {table} ADD COLUMN {column}"
        return self.execute(sql)
    
    def drop_column(self, table: str, column: str) -> Cursor:
        """
        删除列（便捷方法）
        
        Args:
            table: 表名
            column: 列名
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.drop_column("users", "temp_column")
        """
        sql = f"ALTER TABLE {table} DROP COLUMN {column}"
        return self.execute(sql)
    
    def rename_column(self, table: str, old_name: str, new_name: str) -> Cursor:
        """
        重命名列（便捷方法）
        
        Args:
            table: 表名
            old_name: 旧列名
            new_name: 新列名
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.rename_column("users", "name", "username")
        """
        sql = f"ALTER TABLE {table} RENAME COLUMN {old_name} TO {new_name}"
        return self.execute(sql)
    
    def rename_table(self, old_name: str, new_name: str) -> Cursor:
        """
        重命名表（便捷方法）
        
        Args:
            old_name: 旧表名
            new_name: 新表名
        
        Returns:
            Cursor: 游标对象
        
        Example:
            >>> conn.rename_table("users", "members")
        """
        sql = f"RENAME TABLE {old_name} TO {new_name}"
        return self.execute(sql)
    
    def count(self, table: str, where: Optional[str] = None) -> int:
        """
        统计行数（便捷方法）
        
        Args:
            table: 表名
            where: WHERE 条件
        
        Returns:
            int: 行数，失败返回 -1
        
        Example:
            >>> conn.count("Sheet1", "status = 'active'")
        """
        sql = f"SELECT COUNT(*) AS cnt FROM {table}"
        if where:
            sql += f" WHERE {where}"
        
        cursor = self.execute(sql)
        row = cursor.fetchone()
        if row:
            return int(row[0]) if row[0] is not None else 0
        return -1
    
    def sum(self, table: str, column: str, where: Optional[str] = None) -> Optional[float]:
        """
        求和（便捷方法）
        
        Args:
            table: 表名
            column: 列名
            where: WHERE 条件
        
        Returns:
            float: 总和，失败返回 None
        
        Example:
            >>> conn.sum("orders", "amount", "status = 'paid'")
        """
        sql = f"SELECT SUM({column}) AS total FROM {table}"
        if where:
            sql += f" WHERE {where}"
        
        cursor = self.execute(sql)
        row = cursor.fetchone()
        if row and row[0] is not None:
            return float(row[0])
        return None
    
    def avg(self, table: str, column: str, where: Optional[str] = None) -> Optional[float]:
        """
        求平均值（便捷方法）
        
        Args:
            table: 表名
            column: 列名
            where: WHERE 条件
        
        Returns:
            float: 平均值，失败返回 None
        
        Example:
            >>> conn.avg("employees", "salary", "department = 'IT'")
        """
        sql = f"SELECT AVG({column}) AS average FROM {table}"
        if where:
            sql += f" WHERE {where}"
        
        cursor = self.execute(sql)
        row = cursor.fetchone()
        if row and row[0] is not None:
            return float(row[0])
        return None
    
    def max(self, table: str, column: str, where: Optional[str] = None) -> Optional[float]:
        """
        求最大值（便捷方法）
        
        Args:
            table: 表名
            column: 列名
            where: WHERE 条件
        
        Returns:
            float: 最大值，失败返回 None
        
        Example:
            >>> conn.max("products", "price")
        """
        sql = f"SELECT MAX({column}) AS maximum FROM {table}"
        if where:
            sql += f" WHERE {where}"
        
        cursor = self.execute(sql)
        row = cursor.fetchone()
        if row and row[0] is not None:
            return float(row[0])
        return None
    
    def min(self, table: str, column: str, where: Optional[str] = None) -> Optional[float]:
        """
        求最小值（便捷方法）
        
        Args:
            table: 表名
            column: 列名
            where: WHERE 条件
        
        Returns:
            float: 最小值，失败返回 None
        
        Example:
            >>> conn.min("products", "price")
        """
        sql = f"SELECT MIN({column}) AS minimum FROM {table}"
        if where:
            sql += f" WHERE {where}"
        
        cursor = self.execute(sql)
        row = cursor.fetchone()
        if row and row[0] is not None:
            return float(row[0])
        return None
    
    def __enter__(self) -> 'Connection':
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


def connect(api_token: str, webhook_url: str, timeout: int = 30) -> Connection:
    """
    创建数据库连接
    
    Args:
        api_token: AirScript API Token
        webhook_url: Webhook URL
        timeout: 请求超时时间(秒)，默认30秒
    
    Returns:
        Connection: 连接对象
    
    Example:
        >>> import kdocs_sql_model as ksql
        >>> conn = ksql.connect("your_token", "your_webhook_url")
        >>> cursor = conn.cursor()
        >>> cursor.execute("SELECT * FROM Sheet1")
        >>> print(cursor.fetchall())
        >>> conn.close()
    """
    return Connection(api_token, webhook_url, timeout)


def complete_statement(sql: str) -> bool:
    """
    检查 SQL 语句是否完整
    
    Args:
        sql: SQL 语句
    
    Returns:
        bool: 是否完整
    """
    sql = sql.strip()
    if not sql:
        return False
    
    return sql.endswith(';') or sql.upper().startswith(('SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'ALTER', 'TRUNCATE', 'RENAME', 'SHOW'))


apilevel = "2.0"
threadsafety = 1
paramstyle = "qmark"


__all__ = [
    'connect',
    'Connection',
    'Cursor',
    'KDocsSQLError',
    'OperationalError',
    'DatabaseError',
    'ProgrammingError',
    'complete_statement',
    'apilevel',
    'threadsafety',
    'paramstyle',
]
