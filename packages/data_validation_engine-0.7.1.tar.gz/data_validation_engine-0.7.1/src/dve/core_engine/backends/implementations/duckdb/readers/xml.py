# mypy: disable-error-code="attr-defined"
"""An xml reader to create duckdb relations"""

from typing import Optional

import polars as pl
from duckdb import DuckDBPyConnection, DuckDBPyRelation, default_connection
from pydantic import BaseModel

from dve.core_engine.backends.base.reader import read_function
from dve.core_engine.backends.exceptions import MessageBearingError
from dve.core_engine.backends.implementations.duckdb.duckdb_helpers import duckdb_write_parquet
from dve.core_engine.backends.readers.xml import XMLStreamReader
from dve.core_engine.backends.utilities import (
    get_polars_type_from_annotation,
    polars_record_index,
    stringify_model,
)
from dve.core_engine.type_hints import URI


@polars_record_index
@duckdb_write_parquet
class DuckDBXMLStreamReader(XMLStreamReader):
    """A reader for XML files"""

    def __init__(self, *, ddb_connection: Optional[DuckDBPyConnection] = None, **kwargs):
        self.ddb_connection = ddb_connection if ddb_connection else default_connection
        super().__init__(**kwargs)

    @read_function(DuckDBPyRelation)
    def read_to_relation(self, resource: URI, entity_name: str, schema: type[BaseModel]):
        """Returns a relation object from the source xml"""
        if self.xsd_location:
            msg = self._run_xmllint(file_uri=resource)
            if msg:
                raise MessageBearingError(
                    "Submitted file failed XSD validation.",
                    messages=[msg],
                )

        polars_schema: dict[str, pl.DataType] = {  # type: ignore
            fld.name: get_polars_type_from_annotation(fld.annotation)
            for fld in stringify_model(schema).__fields__.values()
        }

        _lazy_frame = self.add_record_index(
            pl.LazyFrame(
                data=self.read_to_py_iterator(resource, entity_name, schema), schema=polars_schema
            )
        )
        return self.ddb_connection.sql("select * from _lazy_frame")
