"""General misc utilities."""
