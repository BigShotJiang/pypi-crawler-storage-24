"""Append-only log and cache for agent runs.

This logging is only turned on if the user provides a --log_db argument, and is used for
analytics, debugging, and caching.

This module provides a database-backed logging and caching layer for the keystone agent.
The design philosophy is "log everything, cache selectively":

Architecture
------------
Two tables work together:

1. `cli_run` - Records every CLI invocation (both cache hits and misses)
   - Captures: UUID, timestamp, working directory, CLI arguments, whether cache hit, result
   - Purpose: Analytics on CLI usage patterns, debugging, audit trail

2. `agent_run` - Records every actual agent execution (cache misses only)
   - Captures: UUID (links to cli_run), timestamp, cache key components,
     agent output (events + devcontainer), return code, Claude state tarball
   - Purpose: Replay cache, analytics on agent behavior, debugging

Database Support
----------------
Supports both SQLite and PostgreSQL via SQLAlchemy + pandas:
- SQLite: Pass a file path (e.g., "./runs.db" or "~/.imbue_keystone/log.sqlite")
- PostgreSQL: Pass a connect string (e.g., "postgresql://user:pass@host/db")

Cache Behavior
--------------
The cache key is computed from:
- Git tree hash (content-addressable snapshot of repo)
- Prompt hash (MD5 of the agent prompt)
- Agent config (JSON-serialized AgentConfig)
- Cache version (user-supplied string to force invalidation)

Cache lookup finds the most recent `agent_run` entry where:
- All cache key components match
- return_code == 0 (only successful runs are replayed)

This means failed runs are logged for analytics but never replayed.

CLI Flags
---------
- --log_db: Database path or connect string (default: ~/.imbue_keystone/log.sqlite)
- --require_cache_hit: Fail immediately if cache miss (useful for CI/testing)
- --no_cache_replay: Skip cache lookup but still log the run (force fresh execution)
- --cache_version: String appended to cache key to invalidate old entries

Example Usage
-------------
    # SQLite (default)
    keystone --project_root ./myproject --log_db ./runs.db

    # PostgreSQL
    keystone --project_root ./myproject --log_db postgresql://user:pass@localhost/mydb

    # Force fresh run, ignore cache
    keystone --project_root ./myproject --no_cache_replay

    # Require cache hit (CI mode)
    keystone --project_root ./myproject --require_cache_hit

    # Invalidate cache for this config
    keystone --project_root ./myproject --cache_version v2
"""

import hashlib
import io
import json
import logging
import tarfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import ClassVar

import pandas as pd
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from keystone.git_utils import get_git_tree_hash
from keystone.schema import AgentConfig, StreamEvent
from keystone.version import VersionInfo, get_version_info

logger = logging.getLogger(__name__)


class CacheKey(BaseModel):
    """Components of the cache key, stored for debugging and analytics."""

    git_tree_hash: str
    prompt_hash: str
    agent_config_json: str
    cache_version: str

    def compute_hash(self) -> str:
        """Compute the combined cache key hash."""
        h = hashlib.sha256()
        h.update(self.git_tree_hash.encode("utf-8"))
        h.update(self.prompt_hash.encode("utf-8"))
        h.update(self.agent_config_json.encode("utf-8"))
        h.update(self.cache_version.encode("utf-8"))
        return h.hexdigest()


class AgentRunRecord(BaseModel):
    """Data stored for each agent run."""

    cli_run_id: str
    timestamp: datetime
    cache_key: CacheKey
    events: list[StreamEvent]
    devcontainer_tarball: bytes
    return_code: int
    agent_dir_tarball: bytes | None = (
        None  # Tarball of agent state dirs (e.g. ~/.claude, ~/.codex) from Modal
    )
    version_info: VersionInfo | None = None  # Version of the code that ran


class CLIRunRecord(BaseModel):
    """Data stored for each CLI invocation."""

    id: str
    timestamp: datetime
    cwd: str
    args: list[str]
    cache_hit: bool
    bootstrap_result_json: str | None = None


def compute_cache_key(
    prompt: str,
    repo_path: Path,
    agent_config: AgentConfig,
    cache_version: str,
) -> CacheKey:
    """Compute cache key components from inputs."""
    git_tree_hash = get_git_tree_hash(repo_path)
    prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
    return CacheKey(
        git_tree_hash=git_tree_hash,
        prompt_hash=prompt_hash,
        agent_config_json=agent_config.to_cache_key_json(),
        cache_version=cache_version,
    )


def ensure_column_exists(engine: Engine, table: str, column: str, column_type: str) -> None:
    """Add a column to a table if it doesn't exist.

    Does nothing if the table doesn't exist (table will be created with the column).

    Args:
        engine: SQLAlchemy engine
        table: Table name
        column: Column name to add
        column_type: SQL type for the column (e.g., 'TEXT', 'INTEGER')
    """
    with engine.connect() as conn:
        # Check if column exists (works for SQLite and PostgreSQL)
        # Validate identifiers to prevent SQL injection (PRAGMA and ALTER TABLE
        # don't support parameter binding for identifiers).
        for name in (table, column):
            if not all(ch.isalnum() or ch == "_" for ch in name):
                raise ValueError(f"Invalid SQL identifier: {name!r}")
        if not all(ch.isalnum() or ch in "_, ()" for ch in column_type):
            raise ValueError(f"Invalid SQL type: {column_type!r}")

        if engine.dialect.name == "sqlite":
            result = conn.execute(text(f"PRAGMA table_info({table})"))
            columns = {row[1] for row in result}
            if not columns:
                # Table doesn't exist yet
                return
            if column not in columns:
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {column_type}"))
                conn.commit()
        else:
            # PostgreSQL supports ADD COLUMN IF NOT EXISTS directly
            conn.execute(
                text(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {column} {column_type}")
            )
            conn.commit()


def rename_column_if_exists(
    engine: Engine, table: str, old_column: str, new_column: str, column_type: str
) -> None:
    """Rename a column if the old name exists and the new name doesn't.

    For SQLite < 3.25 (no ALTER TABLE RENAME COLUMN), adds the new column,
    copies data, and leaves the old column in place.

    Args:
        engine: SQLAlchemy engine
        table: Table name
        old_column: Old column name
        new_column: New column name
        column_type: SQL type for the column (e.g., 'TEXT', 'BLOB')
    """
    for name in (table, old_column, new_column):
        if not all(ch.isalnum() or ch == "_" for ch in name):
            raise ValueError(f"Invalid SQL identifier: {name!r}")

    with engine.connect() as conn:
        if engine.dialect.name == "sqlite":
            result = conn.execute(text(f"PRAGMA table_info({table})"))
            columns = {row[1] for row in result}
            if not columns or old_column not in columns or new_column in columns:
                return
            # SQLite 3.25+ supports RENAME COLUMN
            try:
                conn.execute(
                    text(f"ALTER TABLE {table} RENAME COLUMN {old_column} TO {new_column}")
                )
            except Exception:
                # Fallback: add new column and copy data
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {new_column} {column_type}"))
                conn.execute(text(f"UPDATE {table} SET {new_column} = {old_column}"))
            conn.commit()
        else:
            # PostgreSQL
            conn.execute(text(f"ALTER TABLE {table} RENAME COLUMN {old_column} TO {new_column}"))
            conn.commit()


def _create_engine(db_url: str) -> Engine:
    """Create SQLAlchemy engine from URL or path.

    Args:
        db_url: Either a SQLAlchemy URL (postgresql://...) or a file path for SQLite.
    """
    if db_url.startswith(("postgresql://", "postgres://", "sqlite://")):
        return create_engine(db_url)
    else:
        # Treat as SQLite file path
        path = Path(db_url).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        return create_engine(f"sqlite:///{path}")


class AgentLog:
    """Append-only log and cache for agent runs.

    Uses pandas + SQLAlchemy for database operations, supporting both
    SQLite and PostgreSQL.

    Thread-safety: This class is NOT thread-safe. Use one instance per thread.
    """

    _CREATE_TABLES_SQL: ClassVar[list[str]] = [
        """\
        CREATE TABLE IF NOT EXISTS agent_run (
            cli_run_id TEXT,
            timestamp TEXT,
            git_tree_hash TEXT,
            prompt_hash TEXT,
            agent_config_json TEXT,
            cache_version TEXT,
            cache_key_hash TEXT,
            events_json TEXT,
            devcontainer_tarball BLOB,
            return_code INTEGER,
            agent_dir_tarball BLOB,
            version_info_json TEXT
        )
        """,
        """\
        CREATE TABLE IF NOT EXISTS cli_run (
            id TEXT,
            timestamp TEXT,
            cwd TEXT,
            args_json TEXT,
            cache_hit INTEGER,
            bootstrap_result_json TEXT
        )
        """,
    ]

    def __init__(self, db_url: str) -> None:
        """Open or create the log database.

        Args:
            db_url: Database URL or file path.
                - File path: Creates/opens SQLite database
                - postgresql://...: Connects to PostgreSQL
        """
        self._engine = _create_engine(db_url)
        self._ensure_tables()

    def _ensure_tables(self) -> None:
        """Create tables if they don't exist."""
        with self._engine.begin() as conn:
            for sql in self._CREATE_TABLES_SQL:
                conn.execute(text(sql))

    def close(self) -> None:
        """Close the database connection."""
        self._engine.dispose()

    def generate_run_id(self) -> str:
        """Generate a unique ID for a CLI run."""
        return str(uuid.uuid4())

    def log_cli_run(self, record: CLIRunRecord) -> None:
        """Log a CLI invocation."""
        # TODO: Pandas is a heavy dependency just fo this.  Maybe there's another simple way to add a row?
        df = pd.DataFrame(
            [
                {
                    "id": record.id,
                    "timestamp": record.timestamp.isoformat(),
                    "cwd": record.cwd,
                    "args_json": json.dumps(record.args),
                    "cache_hit": record.cache_hit,
                    "bootstrap_result_json": record.bootstrap_result_json,
                }
            ]
        )
        df.to_sql("cli_run", self._engine, if_exists="append", index=False)

    def log_agent_run(self, record: AgentRunRecord) -> None:
        """Log an agent execution."""
        # Schema migrations for older databases
        ensure_column_exists(self._engine, "agent_run", "version_info_json", "TEXT")
        rename_column_if_exists(
            self._engine, "agent_run", "claude_dir_tarball", "agent_dir_tarball", "BLOB"
        )
        ensure_column_exists(self._engine, "agent_run", "agent_dir_tarball", "BLOB")

        # Use current version if not provided
        version_info = record.version_info or get_version_info()

        df = pd.DataFrame(
            [
                {
                    "cli_run_id": record.cli_run_id,
                    "timestamp": record.timestamp.isoformat(),
                    "git_tree_hash": record.cache_key.git_tree_hash,
                    "prompt_hash": record.cache_key.prompt_hash,
                    "agent_config_json": record.cache_key.agent_config_json,
                    "cache_version": record.cache_key.cache_version,
                    "cache_key_hash": record.cache_key.compute_hash(),
                    "events_json": json.dumps([e.model_dump() for e in record.events]),
                    "devcontainer_tarball": record.devcontainer_tarball,
                    "return_code": record.return_code,
                    "agent_dir_tarball": record.agent_dir_tarball,
                    "version_info_json": version_info.model_dump_json(),
                }
            ]
        )
        df.to_sql("agent_run", self._engine, if_exists="append", index=False)

    def lookup_cache(self, cache_key: CacheKey) -> AgentRunRecord | None:
        """Find most recent successful agent run matching the cache key.

        Returns None if no matching successful run exists.
        Only runs with return_code == 0 are considered for replay.
        """
        cache_hash = cache_key.compute_hash()
        # Schema migration: rename old column if needed, ensure new column exists
        rename_column_if_exists(
            self._engine, "agent_run", "claude_dir_tarball", "agent_dir_tarball", "BLOB"
        )
        ensure_column_exists(self._engine, "agent_run", "agent_dir_tarball", "BLOB")
        query = text("""
            SELECT cli_run_id, timestamp,
                   git_tree_hash, prompt_hash, agent_config_json, cache_version,
                   events_json, devcontainer_tarball, return_code, agent_dir_tarball
            FROM agent_run
            WHERE cache_key_hash = :cache_hash AND return_code = 0
            ORDER BY timestamp DESC
            LIMIT 1
        """)

        try:
            with self._engine.connect() as conn:
                result = conn.execute(query, {"cache_hash": cache_hash})
                row = result.fetchone()
        except Exception:
            logger.exception("Cache lookup failed")
            return None

        if row is None:
            return None

        r = row._mapping
        try:
            events_data = json.loads(r["events_json"])
            events = [StreamEvent(**e) for e in events_data]
        except Exception:
            logger.exception("Corrupted cache row for hash %s — treating as cache miss", cache_hash)
            return None
        return AgentRunRecord(
            cli_run_id=r["cli_run_id"],
            timestamp=datetime.fromisoformat(r["timestamp"]),
            cache_key=CacheKey(
                git_tree_hash=r["git_tree_hash"],
                prompt_hash=r["prompt_hash"],
                agent_config_json=r["agent_config_json"],
                cache_version=r["cache_version"],
            ),
            events=events,
            devcontainer_tarball=r["devcontainer_tarball"],
            return_code=r["return_code"],
            agent_dir_tarball=r["agent_dir_tarball"],
        )


def create_devcontainer_tarball(project_root: Path) -> bytes:
    """Create a gzipped tarball of the .devcontainer directory."""
    devcontainer_dir = project_root / ".devcontainer"
    if not devcontainer_dir.exists():
        return b""

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        tar.add(devcontainer_dir, arcname=".devcontainer")
    return buf.getvalue()


def extract_devcontainer_tarball(tarball: bytes, project_root: Path) -> None:
    """Extract a .devcontainer tarball to the project root."""
    if not tarball:
        return

    buf = io.BytesIO(tarball)
    with tarfile.open(fileobj=buf, mode="r:gz") as tar:
        tar.extractall(project_root, filter="data")
