# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Literal, Optional, cast

from pydantic import ConfigDict, Field

from fenix_mcp.application.formatters import _format_sprint, _format_work
from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    Tool,
    ToolRequest,
    UUIDStr,
    resolve_team_id,
)
from fenix_mcp.domain.sprints import SprintService
from fenix_mcp.infrastructure.context import AppContext

SprintsAction = Literal[
    "sprint_list",
    "sprint_active",
    "sprint_get",
    "sprint_work_items",
]


def _sprint_action_choices() -> list[str]:
    return [
        "sprint_list",
        "sprint_active",
        "sprint_get",
        "sprint_work_items",
    ]


class SprintsRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")

    action: SprintsAction
    team_id: Optional[UUIDStr] = Field(
        default=None, description="Associated team ID (UUID)."
    )

    sprint_id: Optional[UUIDStr] = Field(
        default=None, description="Associated sprint ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )


class SprintsTool(Tool):
    name = "sprints"
    description = """Explore Fenix sprint data including active sprint state and sprint-linked work.

Available actions:
- `sprint_list`, `sprint_active`, `sprint_get`, `sprint_work_items`

Common example:
- Check current active sprint:
  `{"action":"sprint_active"}`

Team scoping:
- Optional `team_id` can be sent in any request.
- If omitted, the tool uses the active/default team resolution from context.
"""
    request_model = SprintsRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = SprintService(context.api_client, context.logger)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(SprintsRequest, payload)
        team_id = resolve_team_id(requested_team_id=payload.team_id, context=context)
        action = payload.action

        if action == "sprint_list":
            sprints = await self._service.sprint_list(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
            )
            if not sprints:
                return text("🏃 No sprints found.")
            body = "\n\n".join(_format_sprint(sprint) for sprint in sprints)
            return text(f"🏃 **Sprints ({len(sprints)}):**\n\n{body}")

        if action == "sprint_active":
            try:
                sprint = await self._service.sprint_active(team_id=team_id)
            except Exception:
                sprint = {}
            if not sprint:
                return text("⏳ No active sprint at the moment.")
            return text(_format_sprint(sprint, header="⏳ Active sprint"))

        if action == "sprint_get":
            if not payload.sprint_id:
                return text("❌ Provide sprint_id to get details.")
            sprint = await self._service.sprint_get(payload.sprint_id, team_id=team_id)
            return text(_format_sprint(sprint, header="🏃 Sprint details"))

        if action == "sprint_work_items":
            if not payload.sprint_id:
                return text("❌ Provide sprint_id to list items.")
            items = await self._service.sprint_work_items(
                payload.sprint_id, team_id=team_id
            )
            if not items:
                return text("🏃 No items linked to the specified sprint.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🏃 **Sprint items ({len(items)}):**\n\n{body}")

        return text(
            "❌ Unsupported sprint action.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in _sprint_action_choices())
        )


__all__ = ["SprintsTool", "SprintsAction", "SprintsRequest"]
