# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import List, Literal, Optional, cast

from pydantic import ConfigDict, Field

from fenix_mcp.application.formatters import (
    _format_doc,
    _format_doc_analytics,
    _format_doc_tree_flat,
    _format_doc_tree_nested,
)
from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    CategoryStr,
    DescriptionStr,
    EmojiStr,
    LanguageStr,
    MERMAID_HINT,
    MarkdownStr,
    TagStr,
    TitleStr,
    Tool,
    ToolRequest,
    UUIDStr,
    VersionStr,
    resolve_team_id,
    sanitize_null,
    sanitize_null_list,
)
from fenix_mcp.domain.docs import DocService
from fenix_mcp.infrastructure.context import AppContext

DocsAction = Literal[
    "doc_create",
    "doc_list",
    "doc_get",
    "doc_update",
    "doc_delete",
    "doc_roots",
    "doc_recent",
    "doc_analytics",
    "doc_children",
    "doc_tree",
    "doc_full_tree",
    "doc_move",
    "doc_publish",
    "doc_version",
    "doc_duplicate",
]

_ALLOWED_DOC_TYPES = {
    "folder",
    "page",
    "api_doc",
    "guide",
}


def _doc_action_choices() -> List[str]:
    return [
        "doc_create",
        "doc_list",
        "doc_get",
        "doc_update",
        "doc_delete",
        "doc_roots",
        "doc_recent",
        "doc_analytics",
        "doc_children",
        "doc_tree",
        "doc_full_tree",
        "doc_move",
        "doc_publish",
        "doc_version",
        "doc_duplicate",
    ]


class DocsRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")

    action: DocsAction
    team_id: Optional[UUIDStr] = Field(
        default=None, description="Associated team ID (UUID)."
    )

    id: Optional[UUIDStr] = Field(
        default=None, description="Primary resource ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )
    return_content: Optional[bool] = Field(
        default=None, description="Return full content."
    )
    return_description: Optional[bool] = Field(
        default=None, description="Return full description."
    )
    return_metadata: Optional[bool] = Field(
        default=None, description="Return full metadata."
    )

    doc_title: Optional[TitleStr] = Field(
        default=None, description="Documentation title."
    )
    doc_description: Optional[DescriptionStr] = Field(
        default=None, description="Documentation description."
    )
    doc_content: Optional[MarkdownStr] = Field(
        default=None, description=f"Documentation content (Markdown).{MERMAID_HINT}"
    )
    doc_status: Optional[str] = Field(
        default=None,
        description="Documentation status (draft, review, published, archived).",
    )
    doc_type: Optional[str] = Field(
        default=None,
        description="Documentation type. Values: folder, page, api_doc, guide.",
    )
    doc_language: Optional[LanguageStr] = Field(
        default=None, description="Documentation language (e.g.: pt, en, pt-BR)."
    )
    doc_parent_id: Optional[UUIDStr] = Field(
        default=None, description="Parent document ID (UUID)."
    )
    doc_owner_id: Optional[UUIDStr] = Field(
        default=None, description="Owner ID (UUID)."
    )
    doc_reviewer_id: Optional[UUIDStr] = Field(
        default=None, description="Reviewer ID (UUID)."
    )
    doc_version: Optional[VersionStr] = Field(
        default=None, description="Document version (e.g.: 1.0, 2.1.3)."
    )
    doc_category: Optional[CategoryStr] = Field(default=None, description="Category.")
    doc_tags: Optional[List[TagStr]] = Field(default=None, description="Tags.")
    doc_position: Optional[int] = Field(
        default=None, ge=0, description="Desired position when moving documents."
    )
    doc_emoji: Optional[EmojiStr] = Field(
        default=None,
        description="Emoji displayed with the document. REQUIRED for page, api_doc, and guide types (not required for folder).",
    )
    doc_emote: Optional[EmojiStr] = Field(
        default=None, description="Alias for emoji, kept for compatibility."
    )
    doc_keywords: Optional[List[TagStr]] = Field(
        default=None, description="Keywords for search."
    )
    doc_is_public: Optional[bool] = Field(
        default=None, description="Whether the document is public."
    )


class DocsTool(Tool):
    name = "docs"
    description = """Manage Fenix documentation pages/folders with focused CRUD and tree navigation actions.

Available actions:
- `doc_create`, `doc_list`, `doc_get`, `doc_update`, `doc_delete`
- `doc_roots`, `doc_recent`, `doc_analytics`
- `doc_children`, `doc_tree`, `doc_full_tree`
- `doc_move`, `doc_publish`, `doc_version`, `doc_duplicate`

Common example:
- Discover documents and IDs before reading content:
  `{"action":"doc_full_tree"}`

Team scoping:
- Optional `team_id` can be sent in any request.
- If omitted, the tool uses the active/default team resolution from context.
"""
    request_model = DocsRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = DocService(context.api_client, context.logger)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(DocsRequest, payload)
        team_id = resolve_team_id(requested_team_id=payload.team_id, context=context)
        action = payload.action

        if action == "doc_create":
            if not payload.doc_title:
                return text("❌ Provide doc_title to create the documentation.")
            if payload.doc_type and payload.doc_type not in _ALLOWED_DOC_TYPES:
                allowed = ", ".join(sorted(_ALLOWED_DOC_TYPES))
                return text(
                    "❌ Invalid doc_type. Use one of the supported values: " + allowed
                )
            doc_type = sanitize_null(payload.doc_type) or "page"
            emoji = sanitize_null(payload.doc_emoji or payload.doc_emote)
            if doc_type != "folder" and not emoji:
                return text(
                    "❌ Provide doc_emoji to create documentation. "
                    "Emoji is required for page, api_doc, and guide types."
                )
            doc = await self._service.doc_create(
                {
                    "title": payload.doc_title,
                    "description": sanitize_null(payload.doc_description),
                    "content": sanitize_null(payload.doc_content),
                    "status": sanitize_null(payload.doc_status),
                    "doc_type": sanitize_null(payload.doc_type),
                    "language": sanitize_null(payload.doc_language),
                    "parent_id": sanitize_null(payload.doc_parent_id),
                    "owner_user_id": sanitize_null(payload.doc_owner_id),
                    "reviewer_user_id": sanitize_null(payload.doc_reviewer_id),
                    "version": sanitize_null(payload.doc_version),
                    "category": sanitize_null(payload.doc_category),
                    "tags": sanitize_null_list(payload.doc_tags),
                    "emoji": sanitize_null(payload.doc_emoji or payload.doc_emote),
                    "keywords": sanitize_null_list(payload.doc_keywords),
                    "is_public": payload.doc_is_public,
                },
                team_id=team_id,
            )
            return text(_format_doc(doc, header="✅ Documentation created"))

        if action == "doc_list":
            docs = await self._service.doc_list(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
                returnContent=payload.return_content,
            )
            if not docs:
                return text("📄 No documentation found.")
            body = "\n\n".join(_format_doc(doc) for doc in docs)
            return text(f"📄 **Documents ({len(docs)}):**\n\n{body}")

        if action == "doc_get":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            doc = await self._service.doc_get(
                payload.id, team_id=team_id, return_content=True
            )
            return text(
                _format_doc(doc, header="📄 Documentation details", show_content=True)
            )

        if action == "doc_update":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if payload.doc_type and payload.doc_type not in _ALLOWED_DOC_TYPES:
                allowed = ", ".join(sorted(_ALLOWED_DOC_TYPES))
                return text(
                    "❌ Invalid doc_type. Use one of the supported values: " + allowed
                )
            doc = await self._service.doc_update(
                payload.id,
                {
                    "title": sanitize_null(payload.doc_title),
                    "description": sanitize_null(payload.doc_description),
                    "content": sanitize_null(payload.doc_content),
                    "status": sanitize_null(payload.doc_status),
                    "doc_type": sanitize_null(payload.doc_type),
                    "language": sanitize_null(payload.doc_language),
                    "parent_id": sanitize_null(payload.doc_parent_id),
                    "owner_user_id": sanitize_null(payload.doc_owner_id),
                    "reviewer_user_id": sanitize_null(payload.doc_reviewer_id),
                    "version": sanitize_null(payload.doc_version),
                    "category": sanitize_null(payload.doc_category),
                    "tags": sanitize_null_list(payload.doc_tags),
                    "emoji": sanitize_null(payload.doc_emoji or payload.doc_emote),
                    "keywords": sanitize_null_list(payload.doc_keywords),
                    "is_public": payload.doc_is_public,
                },
                team_id=team_id,
            )
            return text(_format_doc(doc, header="✅ Documentation updated"))

        if action == "doc_delete":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            await self._service.doc_delete(payload.id, team_id=team_id)
            return text(f"🗑️ Documentation {payload.id} removed.")

        if action == "doc_roots":
            docs = await self._service.doc_roots(team_id=team_id)
            if not docs:
                return text("📚 No roots found.")
            body = "\n".join(
                f"- {doc.get('title', 'Untitled')} (ID: {doc.get('id')})"
                for doc in docs
            )
            return text(f"📚 **Documentation roots:**\n{body}")

        if action == "doc_recent":
            docs = await self._service.doc_recent(
                team_id=team_id,
                limit=payload.limit,
            )
            if not docs:
                return text("🕒 No recent documentation found.")
            body = "\n\n".join(_format_doc(doc) for doc in docs)
            return text(f"🕒 **Recent documents ({len(docs)}):**\n\n{body}")

        if action == "doc_analytics":
            analytics = await self._service.doc_analytics(team_id=team_id)
            return text(_format_doc_analytics(analytics))

        if action == "doc_children":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            docs = await self._service.doc_children(payload.id, team_id=team_id)
            if not docs:
                return text("📄 No children registered for the specified document.")
            body = "\n".join(
                f"- {doc.get('title', 'Untitled')} (ID: {doc.get('id')})"
                for doc in docs
            )
            return text(f"📄 **Children:**\n{body}")

        if action == "doc_tree":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            tree = await self._service.doc_tree(payload.id, team_id=team_id)
            formatted = _format_doc_tree_nested(tree)
            return text(f"🌳 **Documentation tree for {payload.id}:**\n\n{formatted}")

        if action == "doc_full_tree":
            tree = await self._service.doc_full_tree(team_id=team_id)
            formatted = _format_doc_tree_flat(tree)
            return text(f"🌳 **Full documentation tree:**\n\n{formatted}")

        if action == "doc_move":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if payload.doc_parent_id is None and payload.doc_position is None:
                return text("❌ Provide doc_parent_id, doc_position or both to move.")
            move_payload = {
                "new_parent_id": payload.doc_parent_id,
                "new_position": payload.doc_position,
            }
            doc = await self._service.doc_move(
                payload.id, move_payload, team_id=team_id
            )
            # The move endpoint may return a sparse response; if the
            # result lacks a title, fetch the full document instead.
            if not doc.get("title") and not doc.get("name"):
                doc = await self._service.doc_get(payload.id, team_id=team_id)
            return text(_format_doc(doc, header="📦 Documentation moved"))

        if action == "doc_publish":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            doc = await self._service.doc_publish(payload.id, team_id=team_id)
            if not doc.get("title") and not doc.get("name"):
                doc = await self._service.doc_get(payload.id, team_id=team_id)
            return text(_format_doc(doc, header="🗞️ Document published"))

        if action == "doc_version":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if not payload.doc_version:
                return text(
                    "❌ Provide doc_version with the version number/identifier."
                )
            version_payload = {
                "title": payload.doc_title or f"Version {payload.doc_version}",
                "version": payload.doc_version,
                "content": payload.doc_content,
            }
            doc = await self._service.doc_version(
                payload.id, version_payload, team_id=team_id
            )
            return text(_format_doc(doc, header="🗞️ New version created"))

        if action == "doc_duplicate":
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if not payload.doc_title:
                return text("❌ Provide doc_title to name the copy.")
            doc = await self._service.doc_duplicate(
                payload.id,
                {
                    "title": payload.doc_title,
                },
                team_id=team_id,
            )
            return text(_format_doc(doc, header="🗂️ Document duplicated"))

        return text(
            "❌ Unsupported documentation action.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in _doc_action_choices())
        )


__all__ = ["DocsTool", "DocsAction", "DocsRequest"]
