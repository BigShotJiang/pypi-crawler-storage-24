# SPDX-License-Identifier: MIT
"""Factory functions to instantiate all tools."""

from __future__ import annotations

from typing import List

from fenix_mcp.application.tool_base import Tool
from fenix_mcp.infrastructure.context import AppContext

from .health import HealthTool
from .initialize import InitializeTool
from .intelligence import IntelligenceTool
from .productivity import ProductivityTool
from .api_catalog import ApiCatalogTool
from .boards import BoardsTool
from .docs import DocsTool
from .skills import SkillsTool
from .sprints import SprintsTool
from .team import TeamTool
from .user_config import UserConfigTool
from .work_items import WorkItemsTool


def build_tools(context: AppContext) -> List[Tool]:
    """Instantiate all available tools."""

    return [
        HealthTool(context),
        InitializeTool(context),
        IntelligenceTool(context),
        ProductivityTool(context),
        WorkItemsTool(context),
        DocsTool(context),
        BoardsTool(context),
        SprintsTool(context),
        SkillsTool(context),
        ApiCatalogTool(context),
        TeamTool(context),
        UserConfigTool(context),
    ]
