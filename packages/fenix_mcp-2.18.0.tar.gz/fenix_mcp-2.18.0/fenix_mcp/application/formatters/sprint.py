# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import _format_date


def _format_sprint(sprint: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"🏃 **{sprint.get('name', 'Unnamed')}**",
            f"ID: {sprint.get('id', 'N/A')}",
            f"Status: {sprint.get('status', 'N/A')}",
            f"Team: {sprint.get('team_id', 'N/A')}",
        ]
    )
    if sprint.get("start_date") or sprint.get("startDate"):
        lines.append(
            f"Start: {_format_date(sprint.get('start_date') or sprint.get('startDate'))}"
        )
    if sprint.get("end_date") or sprint.get("endDate"):
        lines.append(
            f"End: {_format_date(sprint.get('end_date') or sprint.get('endDate'))}"
        )
    return "\n".join(lines)
