# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Any, Dict, List, Optional


def _format_board(board: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"🗂️ **{board.get('name', 'Unnamed')}**",
            f"ID: {board.get('id', 'N/A')}",
            f"Team: {board.get('team_id', 'N/A')}",
            f"Columns: {len(board.get('columns', []))}",
        ]
    )
    return "\n".join(lines)
