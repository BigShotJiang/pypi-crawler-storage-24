# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import _format_date


def _format_skill(
    skill: Dict[str, Any],
    *,
    header: Optional[str] = None,
    show_content: bool = False,
) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")

    name = skill.get("name", "Untitled")
    scope = skill.get("scope", "unknown")
    scope_emoji = {
        "personal": "👤",
        "team": "👥",
        "organization": "🏢",
        "marketplace": "🌍",
    }.get(scope, "🧠")

    lines.extend(
        [
            f"{scope_emoji} **{name}**",
            f"ID: {skill.get('id', 'N/A')}",
            f"Scope: {scope}",
            f"Version: {skill.get('version', '1.0')}",
        ]
    )

    if skill.get("category"):
        lines.append(f"Category: {skill.get('category')}")

    if skill.get("description"):
        lines.append(f"Description: {skill.get('description')}")

    author = skill.get("author")
    if isinstance(author, dict):
        lines.append(f"Author: {author.get('name', 'Unknown')}")

    forked_from = skill.get("forked_from")
    if isinstance(forked_from, dict):
        forked_author = forked_from.get("author", {})
        author_name = (
            forked_author.get("name", "Unknown")
            if isinstance(forked_author, dict)
            else "Unknown"
        )
        lines.append(
            f"Forked from: {forked_from.get('name', 'Unknown')} by {author_name}"
        )

    if skill.get("is_active") is False:
        lines.append("Status: Inactive")

    if skill.get("updated_at") or skill.get("updatedAt"):
        lines.append(
            f"Updated: {_format_date(skill.get('updated_at') or skill.get('updatedAt'))}"
        )

    if show_content and skill.get("content"):
        lines.append("")
        lines.append("**Content:**")
        lines.append(str(skill.get("content") or ""))

    return "\n".join(lines)


def _format_marketplace_skill(skill: Dict[str, Any]) -> str:
    lines: List[str] = []

    name = skill.get("name", "Untitled")
    installs = skill.get("installs", skill.get("downloads", 0))
    rating = skill.get("rating")

    lines.append(f"🌍 **{name}**")
    lines.append(f"ID: {skill.get('id', 'N/A')}")

    if skill.get("description"):
        lines.append(f"Description: {skill.get('description')}")

    author = skill.get("author")
    if isinstance(author, dict):
        lines.append(f"Author: {author.get('name', 'Unknown')}")

    stats_parts = [f"⬇️ {installs}"]
    if rating is not None:
        stats_parts.append(f"⭐ {float(rating):.1f}")
    lines.append(" | ".join(stats_parts))

    return "\n".join(lines)


def _render_export_content(
    *, name: str, description: str, content: str, format: str
) -> str:
    normalized = (format or "").strip().lower()

    if normalized == "cursor":
        return (
            "---\n"
            f"description: {description}\n"
            "globs: \n"
            "alwaysApply: true\n"
            "---\n\n"
            f"{content}"
        )

    if normalized in {"raw", "markdown", ""}:
        return content

    fixed_headers = {
        "windsurf": "Windsurf Rules",
        "cline": "Cline Rules",
        "roo": "Roo Code Rules",
        "codex": "Codex Instructions",
        "aider": "Aider Conventions",
        "continue": "Continue Rules",
        "kiro": "Kiro Rules",
        "void": "Void Rules",
        "droid": "Droid Rules",
        "gemini": "Gemini Rules",
        "kilo": "Kilo Code Rules",
        "trae": "Trae Rules",
        "antigravity": "Antigravity Rules",
        "opencode": "OpenCode Instructions",
    }
    if normalized in fixed_headers:
        return f"# {fixed_headers[normalized]}\n\n{content}"

    if normalized in {"claude", "copilot"}:
        return f"# {name}\n\n{content}"

    return content


def _export_skill_format(skill: Dict[str, Any], format: str) -> str:
    name = str(skill.get("name") or "Untitled")
    description = str(skill.get("description") or "")
    content = str(skill.get("content") or "")
    return _render_export_content(
        name=name, description=description, content=content, format=format
    )


def _export_skills_merged_format(skills: List[Dict[str, Any]], format: str) -> str:
    merged_content = "\n\n---\n\n".join(
        str(skill.get("content") or "") for skill in skills
    )
    count = len(skills)
    name = f"Merged Skills ({count})"
    description = f"Merged export of {count} skills"
    return _render_export_content(
        name=name,
        description=description,
        content=merged_content,
        format=format,
    )


__all__ = [
    "_format_skill",
    "_format_marketplace_skill",
    "_export_skill_format",
    "_export_skills_merged_format",
]
