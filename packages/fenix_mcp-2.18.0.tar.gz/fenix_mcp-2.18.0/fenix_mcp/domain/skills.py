# SPDX-License-Identifier: MIT

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.application.formatters.skill import (
    _export_skill_format,
    _export_skills_merged_format,
)
from fenix_mcp.domain._service_base import ServiceBase, _strip_none


@dataclass(slots=True)
class SkillService(ServiceBase):
    api: Any
    logger: Any

    async def skill_create(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.create_skill, _strip_none(payload), team_id=team_id
        )

    async def skill_list(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_skills, team_id=team_id, **_strip_none(filters)
        )

    async def skill_get(
        self, skill_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(self.api.get_skill, skill_id, team_id=team_id)

    async def skill_update(
        self,
        skill_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.update_skill, skill_id, _strip_none(payload), team_id=team_id
        )

    async def skill_delete(
        self, skill_id: str, *, team_id: Optional[str] = None
    ) -> None:
        await self._call(self.api.delete_skill, skill_id, team_id=team_id)

    async def skill_marketplace(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_marketplace_skills, team_id=team_id, **_strip_none(filters)
        )

    async def skill_fork(
        self,
        skill_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.fork_skill, skill_id, _strip_none(payload), team_id=team_id
        )

    async def skill_export(
        self, skill_id: str, format: str, *, team_id: Optional[str] = None
    ) -> str:
        skill = await self._call_dict(self.api.get_skill, skill_id, team_id=team_id)
        return _export_skill_format(skill, format)

    async def skill_export_merged(
        self, format: str, skill_ids: List[str], *, team_id: Optional[str] = None
    ) -> str:
        if skill_ids:
            skills = [
                await self._call_dict(self.api.get_skill, skill_id, team_id=team_id)
                for skill_id in skill_ids
            ]
        else:
            skills = await self._call_list(self.api.list_skills, team_id=team_id)
        return _export_skills_merged_format(skills, format)

    async def skill_import_github(
        self, repo_url: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.import_github_skill, repo_url, team_id=team_id
        )

    async def skill_install(
        self, skill_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(self.api.install_skill, skill_id, team_id=team_id)


__all__ = ["SkillService"]
