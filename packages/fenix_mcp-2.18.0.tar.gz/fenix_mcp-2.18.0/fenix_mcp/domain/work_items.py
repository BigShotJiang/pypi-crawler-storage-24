# SPDX-License-Identifier: MIT

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import ServiceBase, _strip_none


@dataclass(slots=True)
class WorkItemService(ServiceBase):
    api: Any
    logger: Any

    async def work_create(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.create_work_item, _strip_none(payload), team_id=team_id
        )

    async def work_list(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_work_items, team_id=team_id, **_strip_none(filters)
        )

    async def work_get(
        self, work_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(self.api.get_work_item, work_id, team_id=team_id)

    async def work_get_by_key(
        self, key: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.get_work_item_by_key, key, team_id=team_id
        )

    async def work_assign_to_me(
        self, work_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.assign_work_item_to_me, work_id, team_id=team_id
        )

    async def work_advance_status(
        self, work_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.advance_work_item_status, work_id, team_id=team_id
        )

    async def work_complete_status(
        self, work_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.complete_work_item_status, work_id, team_id=team_id
        )

    async def work_mine(
        self, *, limit: int = 50, offset: int = 0, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.get_work_items_mine, limit=limit, offset=offset, team_id=team_id
        )

    async def work_update(
        self,
        work_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.update_work_item,
            work_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def work_delete(self, work_id: str, *, team_id: Optional[str] = None) -> None:
        await self._call(self.api.delete_work_item, work_id, team_id=team_id)

    async def work_backlog(
        self, *, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(self.api.list_work_items_backlog, team_id=team_id)

    async def work_search(
        self,
        *,
        query: str,
        limit: int,
        team_id: Optional[str] = None,
        item_type: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        assignee_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.search_work_items,
            query=query,
            limit=limit,
            team_id=team_id,
            item_type=item_type,
            status=status,
            priority=priority,
            assignee_id=assignee_id,
            tags=tags,
        )

    async def work_analytics(self, *, team_id: Optional[str] = None) -> Dict[str, Any]:
        return (
            await self._call(self.api.get_work_items_analytics, team_id=team_id) or {}
        )

    async def work_velocity(
        self, *, sprints_count: int, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return (
            await self._call(
                self.api.get_work_items_velocity,
                sprints_count=sprints_count,
                team_id=team_id,
            )
            or {}
        )

    async def work_by_sprint(
        self, *, sprint_id: str, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_work_items_by_sprint, sprint_id=sprint_id, team_id=team_id
        )

    async def work_burndown(
        self, *, sprint_id: str, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return (
            await self._call(
                self.api.get_work_items_burndown,
                sprint_id=sprint_id,
                team_id=team_id,
            )
            or {}
        )

    async def work_by_epic(
        self, *, epic_id: str, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return (
            await self._call(
                self.api.list_work_items_by_epic, epic_id=epic_id, team_id=team_id
            )
            or []
        )

    async def work_epic_progress(
        self, *, epic_id: str, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return (
            await self._call(
                self.api.get_work_items_epic_progress,
                epic_id=epic_id,
                team_id=team_id,
            )
            or {}
        )

    async def work_by_board(
        self, *, board_id: str, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_work_items_by_board, board_id=board_id, team_id=team_id
        )

    async def work_children(
        self, work_id: str, *, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.get_work_item_children, work_id, team_id=team_id
        )

    async def work_move(
        self,
        work_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.move_work_item, work_id, _strip_none(payload), team_id=team_id
        )

    async def work_update_status(
        self,
        work_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.update_work_item_status,
            work_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def work_move_to_board(
        self,
        work_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.move_work_item_to_board,
            work_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def work_link(
        self,
        work_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.link_work_item, work_id, _strip_none(payload), team_id=team_id
        )

    async def work_assign_to_sprint(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.assign_work_items_to_sprint, _strip_none(payload), team_id=team_id
        )

    async def work_bulk_update(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.bulk_update_work_items, _strip_none(payload), team_id=team_id
        )

    async def work_bulk_create(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.bulk_create_work_items, _strip_none(payload), team_id=team_id
        )

    async def list_team_statuses(
        self, *, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(self.api.list_team_statuses, team_id=team_id)


__all__ = ["WorkItemService"]
