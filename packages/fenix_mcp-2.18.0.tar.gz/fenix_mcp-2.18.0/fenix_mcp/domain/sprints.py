# SPDX-License-Identifier: MIT

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import ServiceBase, _strip_none


@dataclass(slots=True)
class SprintService(ServiceBase):
    api: Any
    logger: Any

    async def sprint_create(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.create_sprint, _strip_none(payload), team_id=team_id
        )

    async def sprint_list(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_sprints, team_id=team_id, **_strip_none(filters)
        )

    async def sprint_get(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(self.api.get_sprint, sprint_id, team_id=team_id)

    async def sprint_update(
        self,
        sprint_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.update_sprint, sprint_id, _strip_none(payload), team_id=team_id
        )

    async def sprint_delete(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> None:
        await self._call(self.api.delete_sprint, sprint_id, team_id=team_id)

    async def sprint_recent(
        self, *, limit: int, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return (
            await self._call(self.api.list_recent_sprints, limit=limit, team_id=team_id)
            or []
        )

    async def sprint_search(
        self, *, query: str, limit: int, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.search_sprints,
            query=query,
            limit=limit,
            team_id=team_id,
        )

    async def sprint_active(self, *, team_id: Optional[str] = None) -> Dict[str, Any]:
        return await self._call(self.api.get_active_sprint, team_id=team_id) or {}

    async def sprint_velocity(self, *, team_id: Optional[str] = None) -> Dict[str, Any]:
        return await self._call(self.api.get_sprints_velocity, team_id=team_id) or {}

    async def sprint_burndown(self, *, team_id: Optional[str] = None) -> Dict[str, Any]:
        return await self._call(self.api.get_sprints_burndown, team_id=team_id) or {}

    async def sprint_work_items(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.get_sprint_work_items, sprint_id, team_id=team_id
        )

    async def sprint_add_work_items(
        self,
        sprint_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.add_work_items_to_sprint,
            sprint_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def sprint_remove_work_items(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.remove_work_items_from_sprint,
            _strip_none(payload),
            team_id=team_id,
        )

    async def sprint_analytics(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return (
            await self._call(self.api.get_sprint_analytics, sprint_id, team_id=team_id)
            or {}
        )

    async def sprint_capacity(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return (
            await self._call(self.api.get_sprint_capacity, sprint_id, team_id=team_id)
            or {}
        )

    async def sprint_start(
        self,
        sprint_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.start_sprint, sprint_id, _strip_none(payload), team_id=team_id
        )

    async def sprint_complete(
        self,
        sprint_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.complete_sprint,
            sprint_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def sprint_cancel(
        self, sprint_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(self.api.cancel_sprint, sprint_id, team_id=team_id)


__all__ = ["SprintService"]
