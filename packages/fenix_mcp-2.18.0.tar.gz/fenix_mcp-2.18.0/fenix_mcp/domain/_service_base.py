# SPDX-License-Identifier: MIT

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any, Dict, List, Optional


def _strip_none(data: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in data.items() if value not in (None, "")}


def _format_date(value: Optional[str]) -> str:
    if not value:
        return "não definido"
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.strftime("%d/%m/%Y")
    except ValueError:
        return value


def _ensure_list(value: Any) -> List[Dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        data = value.get("data")
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
    return []


def _ensure_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        data = value.get("data")
        if isinstance(data, dict):
            return data
        return value
    return {}


class ServiceBase:
    async def _call(self, func, *args, **kwargs):
        return await asyncio.to_thread(func, *args, **kwargs)

    async def _call_list(self, func, *args, **kwargs) -> List[Dict[str, Any]]:
        result = await self._call(func, *args, **kwargs)
        return _ensure_list(result)

    async def _call_dict(self, func, *args, **kwargs) -> Dict[str, Any]:
        result = await self._call(func, *args, **kwargs)
        return _ensure_dict(result)


__all__ = [
    "ServiceBase",
    "_strip_none",
    "_format_date",
    "_ensure_list",
    "_ensure_dict",
]
