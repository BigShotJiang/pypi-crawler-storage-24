# SPDX-License-Identifier: MIT

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import ServiceBase, _ensure_dict, _strip_none


@dataclass(slots=True)
class ApiCatalogService(ServiceBase):
    api: Any
    logger: Any

    async def api_catalog_list(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_api_catalog, team_id=team_id, **_strip_none(filters)
        )

    async def api_catalog_get(
        self, spec_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(self.api.get_api_catalog, spec_id, team_id=team_id)

    async def api_catalog_search(
        self,
        *,
        query: str,
        limit: int = 10,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        result = await self._call(
            self.api.search_api_catalog_semantic,
            query=query,
            limit=limit,
            team_id=team_id,
        )
        return _ensure_dict(result) if isinstance(result, dict) else {"data": result}


__all__ = ["ApiCatalogService"]
