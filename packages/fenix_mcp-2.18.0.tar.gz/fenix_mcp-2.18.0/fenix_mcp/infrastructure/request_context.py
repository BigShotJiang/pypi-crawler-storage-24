# SPDX-License-Identifier: MIT
"""Request-scoped context using contextvars for async isolation."""

from __future__ import annotations

import hashlib
import time
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# Context variable for the current request's token
# This is automatically isolated per async task/request
_current_token: ContextVar[Optional[str]] = ContextVar("current_token", default=None)

# Context variable pointing to the current session state
_current_session: ContextVar[Optional["SessionState"]] = ContextVar(
    "current_session", default=None
)

# Session store keyed by sha256(token)[:16]
_session_store: Dict[str, "SessionState"] = {}

_SESSION_TTL_SECONDS = 3600  # 1 hour


@dataclass
class SessionState:
    """Per-user session state that persists across requests with the same token."""

    active_team_id: Optional[str] = None
    active_team_name: Optional[str] = None
    user_teams: List[Dict[str, Any]] = field(default_factory=list)
    init_instructions: Optional[str] = None
    last_access: float = field(default_factory=time.monotonic)


@dataclass(slots=True, frozen=True)
class RequestContext:
    """Holds request-scoped data like the user's token."""

    token: Optional[str] = None
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None
    team_id: Optional[str] = None  # propagated per tool call when provided


def _token_key(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()[:16]


def _cleanup_expired() -> None:
    """Remove sessions that haven't been accessed within TTL."""
    now = time.monotonic()
    expired = [
        k
        for k, v in _session_store.items()
        if now - v.last_access > _SESSION_TTL_SECONDS
    ]
    for k in expired:
        del _session_store[k]


def set_request_context(token: Optional[str]) -> None:
    """Set token and bind/create session for the current async context."""
    _current_token.set(token)
    if token:
        _cleanup_expired()
        key = _token_key(token)
        session = _session_store.get(key)
        if session is None:
            session = SessionState()
            _session_store[key] = session
        session.last_access = time.monotonic()
        _current_session.set(session)
    else:
        _current_session.set(None)


def get_session_state() -> Optional[SessionState]:
    """Get the session state for the current request, or None (STDIO mode)."""
    return _current_session.get()


def get_request_team_id() -> Optional[str]:
    """Get the active team ID from the current session, if any."""
    session = _current_session.get()
    if session is not None:
        return session.active_team_id
    return None


def clear_request_context() -> None:
    """Clear token and session binding for the current async context."""
    _current_token.set(None)
    _current_session.set(None)


# Keep backward-compatible aliases used by existing code
def set_request_token(token: Optional[str]) -> None:
    """Set the token for the current async context/request."""
    _current_token.set(token)


def get_request_token() -> Optional[str]:
    """Get the token for the current async context/request."""
    return _current_token.get()


def clear_request_token() -> None:
    """Clear the token for the current async context/request."""
    _current_token.set(None)
