# SPDX-License-Identifier: MIT
"""Shared context dependency injected into tools."""

from __future__ import annotations

from logging import Logger
from typing import Any

from fenix_mcp.infrastructure.config import Settings
from fenix_mcp.infrastructure.fenix_api.client import FenixApiClient
from fenix_mcp.infrastructure.request_context import get_session_state


class AppContext:
    """Runtime dependencies shared by tools.

    In HTTP mode, active_team_id / active_team_name / user_teams are
    transparently delegated to the per-session SessionState via property
    accessors.  In STDIO mode (no session), they fall back to private
    instance attributes — identical to the previous behavior.
    """

    def __init__(
        self,
        settings: Settings,
        logger: Logger,
        api_client: FenixApiClient,
        active_team_id: str | None = None,
        active_team_name: str | None = None,
        user_teams: list[dict[str, Any]] | None = None,
    ) -> None:
        self.settings = settings
        self.logger = logger
        self.api_client = api_client
        self._active_team_id = active_team_id
        self._active_team_name = active_team_name
        self._user_teams = user_teams if user_teams is not None else []

    # -- active_team_id ------------------------------------------------
    @property
    def active_team_id(self) -> str | None:
        session = get_session_state()
        if session is not None:
            return session.active_team_id
        return self._active_team_id

    @active_team_id.setter
    def active_team_id(self, value: str | None) -> None:
        session = get_session_state()
        if session is not None:
            session.active_team_id = value
        else:
            self._active_team_id = value

    # -- active_team_name ----------------------------------------------
    @property
    def active_team_name(self) -> str | None:
        session = get_session_state()
        if session is not None:
            return session.active_team_name
        return self._active_team_name

    @active_team_name.setter
    def active_team_name(self, value: str | None) -> None:
        session = get_session_state()
        if session is not None:
            session.active_team_name = value
        else:
            self._active_team_name = value

    # -- user_teams ----------------------------------------------------
    @property
    def user_teams(self) -> list[dict[str, Any]]:
        session = get_session_state()
        if session is not None:
            return session.user_teams
        return self._user_teams

    @user_teams.setter
    def user_teams(self, value: list[dict[str, Any]]) -> None:
        session = get_session_state()
        if session is not None:
            session.user_teams = value
        else:
            self._user_teams = value
