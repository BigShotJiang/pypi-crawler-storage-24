# SPDX-License-Identifier: MIT
"""JWKS client for fetching and caching JSON Web Key Sets."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import requests


@dataclass
class JWKSClient:
    """Fetches and caches JWKS from the Authorization Server."""

    jwks_url: str
    cache_ttl: int = 3600
    _cache: Optional[Dict[str, Any]] = field(default=None, init=False, repr=False)
    _cache_expires_at: float = field(default=0.0, init=False, repr=False)
    _logger: logging.Logger = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "_logger", logging.getLogger("fenix_mcp.auth.jwks"))

    def get_jwks(self) -> Dict[str, Any]:
        """Get JWKS, using cache if valid."""
        if self._cache and time.monotonic() < self._cache_expires_at:
            return self._cache

        return self._fetch_jwks()

    def get_signing_key(self, kid: str) -> Optional[Dict[str, Any]]:
        """Get a specific signing key by kid."""
        jwks = self.get_jwks()
        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                return key
        return None

    def get_signing_key_with_refresh(self, kid: str) -> Optional[Dict[str, Any]]:
        """Get signing key, refreshing cache if key not found (key rotation)."""
        key = self.get_signing_key(kid)
        if key is not None:
            return key

        # Key not found — might be key rotation, force refresh
        self._logger.info("Key %s not in cache, refreshing JWKS", kid)
        self.invalidate()
        return self.get_signing_key(kid)

    def invalidate(self) -> None:
        """Force cache invalidation."""
        self._cache = None
        self._cache_expires_at = 0.0

    def _fetch_jwks(self) -> Dict[str, Any]:
        """Fetch JWKS from the remote endpoint."""
        try:
            response = requests.get(self.jwks_url, timeout=10)
            response.raise_for_status()
            data = response.json()

            self._cache = data
            self._cache_expires_at = time.monotonic() + self.cache_ttl
            self._logger.debug(
                "JWKS fetched and cached",
                extra={"keys_count": len(data.get("keys", []))},
            )
            return data
        except Exception:
            # Return stale cache if available
            if self._cache:
                self._logger.warning("JWKS fetch failed, returning stale cache")
                return self._cache
            self._logger.exception("JWKS fetch failed and no cache available")
            raise
