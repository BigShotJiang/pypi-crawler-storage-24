# SPDX-License-Identifier: MIT
"""OAuth authentication infrastructure for Resource Server."""

from fenix_mcp.infrastructure.auth.jwks_client import JWKSClient
from fenix_mcp.infrastructure.auth.jwt_validator import JWTValidator
from fenix_mcp.infrastructure.auth.oauth_client_credentials import (
    OAuthClientCredentials,
)
from fenix_mcp.infrastructure.auth.strategies import (
    AuthStrategy,
    OAuthStrategy,
    PATStrategy,
    CompositeAuthStrategy,
    AuthResult,
)

__all__ = [
    "JWKSClient",
    "JWTValidator",
    "OAuthClientCredentials",
    "AuthStrategy",
    "OAuthStrategy",
    "PATStrategy",
    "CompositeAuthStrategy",
    "AuthResult",
]
