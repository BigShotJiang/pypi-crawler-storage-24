# SPDX-License-Identifier: MIT
"""OAuth client credentials grant for MCP server → fenix-api calls."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Optional

import requests


@dataclass
class OAuthClientCredentials:
    """Obtains and caches tokens via the client_credentials grant.

    The MCP server uses this to get its own token for calling fenix-api,
    instead of passing through the user's token (which is prohibited by MCP spec).
    """

    token_url: str
    client_id: str
    client_secret: str
    scope: str = "api"
    _cached_token: Optional[str] = field(default=None, init=False, repr=False)
    _token_expires_at: float = field(default=0.0, init=False, repr=False)
    _logger: logging.Logger = field(init=False, repr=False)
    _retry_count: int = 3
    _retry_backoff: float = 1.0

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "_logger", logging.getLogger("fenix_mcp.auth.client_credentials")
        )

    def get_token(self) -> str:
        """Get a valid access token, refreshing if needed.

        Renews the token 60 seconds before expiration to avoid edge cases.
        """
        buffer = 60  # seconds before expiry to refresh
        if self._cached_token and time.monotonic() < (self._token_expires_at - buffer):
            return self._cached_token

        return self._fetch_token()

    def invalidate(self) -> None:
        """Force token invalidation."""
        self._cached_token = None
        self._token_expires_at = 0.0

    def _fetch_token(self) -> str:
        """Fetch a new token with exponential backoff retry."""
        last_error: Optional[Exception] = None

        for attempt in range(self._retry_count):
            try:
                response = requests.post(
                    self.token_url,
                    json={
                        "grant_type": "client_credentials",
                        "client_id": self.client_id,
                        "client_secret": self.client_secret,
                        "scope": self.scope,
                    },
                    headers={"Content-Type": "application/json"},
                    timeout=10,
                )
                response.raise_for_status()
                data = response.json()

                self._cached_token = data["access_token"]
                expires_in = data.get("expires_in", 3600)
                self._token_expires_at = time.monotonic() + expires_in

                self._logger.debug(
                    "Client credentials token obtained",
                    extra={"expires_in": expires_in},
                )
                return self._cached_token

            except Exception as exc:
                last_error = exc
                if attempt < self._retry_count - 1:
                    wait = self._retry_backoff * (2**attempt)
                    self._logger.warning(
                        "Token fetch failed (attempt %d/%d), retrying in %.1fs",
                        attempt + 1,
                        self._retry_count,
                        wait,
                    )
                    time.sleep(wait)

        self._logger.error("All token fetch attempts failed")
        raise RuntimeError(
            f"Failed to obtain client credentials token after {self._retry_count} attempts"
        ) from last_error
