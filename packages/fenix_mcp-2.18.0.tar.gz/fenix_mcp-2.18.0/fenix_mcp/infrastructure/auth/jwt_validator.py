# SPDX-License-Identifier: MIT
"""JWT validation with support for both RS256 (JWKS) and HS256 (shared secret)."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import jwt
from jwt import PyJWK

from fenix_mcp.infrastructure.auth.jwks_client import JWKSClient


class JWTValidationError(Exception):
    """Raised when JWT validation fails."""


@dataclass
class JWTClaims:
    """Parsed and validated JWT claims."""

    sub: str
    tenant_id: Optional[str] = None
    team_id: Optional[str] = None
    email: Optional[str] = None
    aud: Optional[str] = None
    exp: Optional[int] = None
    iat: Optional[int] = None
    iss: Optional[str] = None
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class JWTValidator:
    """Validates JWTs using JWKS (RS256) or shared secret (HS256).

    Supabase Cloud uses HS256 with a shared JWT secret (JWKS is empty).
    Self-hosted Supabase or other providers may use RS256 with JWKS.
    This validator supports both automatically.
    """

    jwks_client: JWKSClient
    expected_audience: str = "fenix-mcp"
    jwt_secret: str = ""  # HS256 shared secret (Supabase JWT_SECRET)
    allowed_audiences: List[str] = field(default_factory=lambda: [])
    algorithms: List[str] = field(default_factory=lambda: ["HS256", "RS256", "ES256"])
    _logger: logging.Logger = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "_logger", logging.getLogger("fenix_mcp.auth.jwt"))
        if not self.allowed_audiences:
            self.allowed_audiences = [self.expected_audience, "authenticated"]

    def validate(self, token: str) -> JWTClaims:
        """Validate a JWT token with full signature verification.

        Raises JWTValidationError if validation fails.
        """
        try:
            unverified_header = jwt.get_unverified_header(token)
            alg = unverified_header.get("alg", "HS256")
            kid = unverified_header.get("kid")

            if alg not in self.algorithms:
                raise JWTValidationError(f"Unsupported algorithm: {alg}")

            # Determine signing key based on algorithm
            signing_key = self._resolve_signing_key(alg, kid)

            # Full cryptographic verification via PyJWT
            payload = jwt.decode(
                token,
                key=signing_key,
                algorithms=self.algorithms,
                audience=self.allowed_audiences,
                options={
                    "require": ["exp", "sub"],
                    "verify_exp": True,
                    "verify_aud": True,
                    "verify_iss": False,
                },
            )

            # Extract tenant and team from claims
            app_metadata = payload.get("app_metadata", {})
            tenant_id = app_metadata.get("tenant_id") or payload.get("tenant_id")
            team_id = app_metadata.get("team_id") or payload.get("team_id")

            aud = payload.get("aud")

            return JWTClaims(
                sub=payload.get("sub", ""),
                tenant_id=tenant_id,
                team_id=team_id,
                email=payload.get("email"),
                aud=aud if isinstance(aud, str) else (aud[0] if aud else None),
                exp=payload.get("exp"),
                iat=payload.get("iat"),
                iss=payload.get("iss"),
                raw=payload,
            )

        except jwt.ExpiredSignatureError:
            raise JWTValidationError("Token has expired")
        except jwt.InvalidAudienceError:
            raise JWTValidationError(
                f"Invalid audience. Expected one of: {self.allowed_audiences}"
            )
        except jwt.InvalidSignatureError:
            raise JWTValidationError("Invalid token signature")
        except jwt.DecodeError as exc:
            raise JWTValidationError(f"Token decode failed: {exc}")
        except JWTValidationError:
            raise
        except Exception as exc:
            raise JWTValidationError(f"JWT validation failed: {exc}") from exc

    def _resolve_signing_key(self, alg: str, kid: Optional[str]) -> Any:
        """Resolve the signing key based on algorithm.

        - HS256: Use the shared jwt_secret
        - RS256/ES256: Use JWKS public key
        """
        if alg == "HS256":
            if not self.jwt_secret:
                raise JWTValidationError(
                    "HS256 token received but no jwt_secret configured"
                )
            return self.jwt_secret

        # Asymmetric (RS256, ES256) — use JWKS
        return self._get_signing_key_from_jwks(kid, alg)

    def _get_signing_key_from_jwks(self, kid: Optional[str], alg: str) -> Any:
        """Get the signing key from JWKS for asymmetric verification."""
        if kid:
            key_data = self.jwks_client.get_signing_key_with_refresh(kid)
            if key_data is None:
                raise JWTValidationError(f"Unknown signing key: {kid}")
            return PyJWK(key_data).key

        # No kid — try first key matching the algorithm
        jwks = self.jwks_client.get_jwks()
        for key_data in jwks.get("keys", []):
            if key_data.get("alg") == alg or key_data.get("use") == "sig":
                return PyJWK(key_data).key

        raise JWTValidationError("No suitable signing key found in JWKS")
