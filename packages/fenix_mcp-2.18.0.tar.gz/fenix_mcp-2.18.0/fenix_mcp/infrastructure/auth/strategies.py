# SPDX-License-Identifier: MIT
"""Authentication strategies: OAuth (JWT), PAT, and Composite fallback."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional

from fenix_mcp.infrastructure.auth.jwt_validator import (
    JWTValidator,
    JWTValidationError,
)


@dataclass
class AuthResult:
    """Result of authentication — used by both OAuth and PAT strategies."""

    token: str
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None
    team_id: Optional[str] = None
    is_pat: bool = False
    is_oauth: bool = False


class AuthStrategy(ABC):
    """Base authentication strategy interface."""

    @abstractmethod
    def authenticate(self, token: str) -> Optional[AuthResult]:
        """Attempt to authenticate the given token.

        Returns AuthResult on success, None if this strategy doesn't apply.
        Raises on definitive failure (e.g., expired JWT).
        """
        ...


@dataclass
class OAuthStrategy(AuthStrategy):
    """Validates OAuth JWT tokens via JWKS."""

    jwt_validator: JWTValidator
    _logger: logging.Logger = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "_logger", logging.getLogger("fenix_mcp.auth.oauth_strategy")
        )

    def authenticate(self, token: str) -> Optional[AuthResult]:
        """Validate a JWT token. Returns None if token doesn't look like JWT."""
        if not self._looks_like_jwt(token):
            return None

        try:
            claims = self.jwt_validator.validate(token)
            return AuthResult(
                token=token,
                user_id=claims.sub,
                tenant_id=claims.tenant_id,
                team_id=claims.team_id,
                is_oauth=True,
            )
        except JWTValidationError as exc:
            self._logger.warning("JWT validation failed: %s", exc)
            raise

    @staticmethod
    def _looks_like_jwt(token: str) -> bool:
        """Check if token looks like a JWT (3 base64url parts separated by dots)."""
        parts = token.split(".")
        return len(parts) == 3 and all(len(p) > 0 for p in parts)


@dataclass
class PATStrategy(AuthStrategy):
    """Validates Personal Access Tokens (passthrough to fenix-api)."""

    _logger: logging.Logger = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "_logger", logging.getLogger("fenix_mcp.auth.pat_strategy")
        )

    def authenticate(self, token: str) -> Optional[AuthResult]:
        """Accept PAT tokens (fnx_ prefix or non-JWT format).

        PATs are validated by fenix-api on each request, not locally.
        """
        if OAuthStrategy._looks_like_jwt(token):
            return None

        self._logger.debug("Token detected as PAT")
        return AuthResult(
            token=token,
            is_pat=True,
        )


@dataclass
class CompositeAuthStrategy(AuthStrategy):
    """Tries OAuth first, falls back to PAT.

    Order: OAuth → PAT. If OAuth raises (e.g., expired JWT), it propagates.
    PAT is only tried if OAuth returns None (token doesn't look like JWT).
    """

    strategies: List[AuthStrategy]
    _logger: logging.Logger = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "_logger", logging.getLogger("fenix_mcp.auth.composite")
        )

    def authenticate(self, token: str) -> Optional[AuthResult]:
        for strategy in self.strategies:
            result = strategy.authenticate(token)
            if result is not None:
                return result
        return None
