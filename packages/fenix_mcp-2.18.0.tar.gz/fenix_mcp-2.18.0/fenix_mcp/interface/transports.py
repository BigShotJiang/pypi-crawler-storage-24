# SPDX-License-Identifier: MIT
"""Transport management supporting STDIO, HTTP JSON-RPC, and Streamable HTTP."""

from __future__ import annotations

import asyncio
import json
import logging
import sys
import contextlib
from contextlib import AsyncExitStack
from typing import Iterable, List, Optional, Protocol

from aiohttp import web

from fenix_mcp.infrastructure.config import Settings
from fenix_mcp.infrastructure.request_context import (
    clear_request_context,
    get_session_state,
    set_request_context,
)


class Transport(Protocol):
    name: str

    async def serve_forever(self) -> None:
        pass


class StdIoTransport:
    name = "stdio"

    def __init__(self, server):
        self._server = server
        self._logger = logging.getLogger("fenix_mcp.transport.stdio")

    async def serve_forever(self) -> None:
        loop = asyncio.get_running_loop()
        self._logger.info("STDIO transport awaiting input")
        try:
            while True:
                line = await loop.run_in_executor(None, sys.stdin.readline)
                if not line:
                    await asyncio.sleep(0.05)
                    continue

                line = line.strip()
                if not line:
                    continue

                try:
                    request = json.loads(line)
                except json.JSONDecodeError as exc:  # pragma: no cover - defensive
                    self._logger.warning(
                        "Invalid JSON received on STDIO", extra={"error": str(exc)}
                    )
                    continue

                try:
                    response = await self._server.handle(request)
                except Exception as exc:  # pragma: no cover - defensive
                    self._logger.exception("STDIO transport error")
                    response = {
                        "jsonrpc": "2.0",
                        "id": request.get("id") if isinstance(request, dict) else None,
                        "error": {"code": -32000, "message": str(exc)},
                    }

                if response is not None:
                    sys.stdout.write(json.dumps(response) + "\n")
                    sys.stdout.flush()
        except asyncio.CancelledError:  # pragma: no cover - cancellation path
            self._logger.debug("STDIO transport cancelled")


class HttpTransport:
    name = "http"

    def __init__(
        self,
        server,
        host: str,
        port: int,
        auth_server_url: str = "",
        auth_strategy=None,
    ):
        self._server = server
        self._host = host
        self._port = port
        self._auth_server_url = auth_server_url
        self._auth_strategy = auth_strategy
        self._logger = logging.getLogger("fenix_mcp.transport.http")
        self._runner: web.AppRunner | None = None
        self._shutdown_event = asyncio.Event()

    async def serve_forever(self) -> None:
        await self._start()
        try:
            await self._shutdown_event.wait()
        except asyncio.CancelledError:  # pragma: no cover - cancellation path
            self._logger.debug("HTTP transport cancelled")
        finally:
            await self._cleanup()

    async def shutdown(self) -> None:
        self._shutdown_event.set()
        await self._cleanup()

    async def _start(self) -> None:
        if self._runner is not None:
            return

        app = web.Application()
        app.add_routes(
            [
                web.get("/health", self._handle_health),
                web.get(
                    "/.well-known/oauth-protected-resource",
                    self._handle_protected_resource_metadata,
                ),
                web.post("/mcp", self._handle_mcp),
                web.options("/mcp", self._handle_options),
                web.post("/jsonrpc", self._handle_jsonrpc),
                web.options("/jsonrpc", self._handle_options),
            ]
        )

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, host=self._host, port=self._port)
        try:
            await site.start()
        except Exception:  # pragma: no cover - defensive
            self._logger.exception(
                "Failed to bind HTTP transport",
                extra={"host": self._host, "port": self._port},
            )
            raise

        self._logger.info(
            "HTTP transport listening", extra={"host": self._host, "port": self._port}
        )
        self._runner = runner

    async def _cleanup(self) -> None:
        runner, self._runner = self._runner, None
        if runner is not None:
            await runner.cleanup()

    def _with_cors(self, response: web.StreamResponse) -> web.StreamResponse:
        response.headers.setdefault("Access-Control-Allow-Origin", "*")
        response.headers.setdefault(
            "Access-Control-Allow-Headers", "Content-Type, Authorization"
        )
        response.headers.setdefault("Access-Control-Allow-Methods", "POST, OPTIONS")
        return response

    async def _handle_health(self, request: web.Request) -> web.StreamResponse:
        payload = {
            "status": "ok",
            "transport": "http",
            "sessionId": self._server.session_id,
        }
        return self._with_cors(web.json_response(payload))

    def _get_public_url(self, request: web.Request) -> str:
        """Derive the public-facing URL from the request or config."""
        # Use X-Forwarded-Host/Proto (behind reverse proxy like Railway/Cloudflare)
        proto = request.headers.get("X-Forwarded-Proto", "https")
        host = request.headers.get("X-Forwarded-Host") or request.headers.get("Host")
        if host:
            return f"{proto}://{host}"
        return f"http://{self._host}:{self._port}"

    async def _handle_protected_resource_metadata(
        self, request: web.Request
    ) -> web.StreamResponse:
        """RFC 9728 — OAuth Protected Resource Metadata."""
        public_url = self._get_public_url(request)
        metadata = {
            "resource": public_url,
            "authorization_servers": (
                [self._auth_server_url] if self._auth_server_url else []
            ),
            "bearer_methods_supported": ["header"],
            "resource_signing_alg_values_supported": ["RS256"],
        }
        return self._with_cors(web.json_response(metadata))

    async def _handle_options(self, request: web.Request) -> web.StreamResponse:
        return self._with_cors(web.Response(status=204))

    def _authenticate_request(self, request: web.Request) -> Optional[str]:
        """Extract and validate Bearer token from request.

        Returns the token string if valid, or None.
        For OAuth tokens, validates via JWKS. For PATs, passes through.
        """
        auth_header = request.headers.get("Authorization") or request.headers.get(
            "authorization"
        )
        if not auth_header or not auth_header.lower().startswith("bearer "):
            return None

        token = auth_header.split(" ", 1)[1].strip()
        if not token:
            return None

        if self._auth_strategy:
            try:
                result = self._auth_strategy.authenticate(token)
                if result is None:
                    return None
                # Set enriched context if OAuth
                if result.tenant_id or result.team_id:
                    set_request_context(token)
                    session = get_session_state()
                    if session and result.team_id:
                        session.active_team_id = result.team_id
                    return token
            except Exception as exc:
                self._logger.warning("Auth failed: %s", exc)
                return None

        return token

    async def _handle_mcp(self, request: web.Request) -> web.StreamResponse:
        """Streamable HTTP transport — POST /mcp (MCP spec compliant)."""
        token = self._authenticate_request(request)
        if token:
            set_request_context(token)
        elif self._auth_strategy:
            # Auth required but no valid token
            public_url = self._get_public_url(request)
            resource_url = f"{public_url}/.well-known/oauth-protected-resource"
            return self._with_cors(
                web.json_response(
                    {"error": "unauthorized", "message": "Bearer token required"},
                    status=401,
                    headers={
                        "WWW-Authenticate": f'Bearer resource_metadata="{resource_url}"',
                    },
                )
            )

        try:
            payload = await request.json()
        except Exception:
            clear_request_context()
            return self._with_cors(
                web.json_response(
                    {"error": {"code": -32700, "message": "Invalid JSON"}}, status=400
                )
            )

        try:
            response = await self._server.handle(payload)
        except Exception as exc:
            self._logger.exception("Error processing MCP request")
            return self._with_cors(
                web.json_response(
                    {"error": {"code": -32000, "message": str(exc)}}, status=500
                )
            )
        finally:
            clear_request_context()

        if response is None:
            return self._with_cors(web.Response(status=204))

        resp = self._with_cors(web.json_response(response))
        # Session management via Mcp-Session-Id header
        resp.headers["Mcp-Session-Id"] = self._server.session_id
        return resp

    async def _handle_jsonrpc(self, request: web.Request) -> web.StreamResponse:
        """Legacy JSON-RPC endpoint — deprecated in favor of /mcp."""
        # Extract token from Authorization header (per-request isolation)
        auth_header = request.headers.get("Authorization") or request.headers.get(
            "authorization"
        )
        if auth_header and auth_header.lower().startswith("bearer "):
            token = auth_header.split(" ", 1)[1].strip()
            if token:
                # Set token and bind session (isolated per async request)
                set_request_context(token)

        try:
            payload = await request.json()
        except Exception:  # pragma: no cover - defensive
            clear_request_context()
            return self._with_cors(
                web.json_response(
                    {"error": {"code": -32700, "message": "Invalid JSON"}}, status=400
                )
            )

        self._logger.debug("JSON-RPC request payload", extra={"payload": payload})

        try:
            response = await self._server.handle(payload)
        except Exception as exc:  # pragma: no cover - defensive
            self._logger.exception("Error processing JSON-RPC request")
            return self._with_cors(
                web.json_response(
                    {"error": {"code": -32000, "message": str(exc)}}, status=500
                )
            )
        finally:
            # Clear token after request completes
            clear_request_context()

        if response is None:
            resp = self._with_cors(web.Response(status=204))
        else:
            resp = self._with_cors(web.json_response(response))
        # Deprecation header on legacy endpoint
        resp.headers["Deprecation"] = "true"
        resp.headers["Link"] = '</mcp>; rel="successor-version"'
        return resp


class CompositeTransport:
    def __init__(self, transports: Iterable[Transport]):
        self._transports: List[Transport] = list(transports)
        self.name = "+".join(transport.name for transport in self._transports)

    async def serve_forever(self) -> None:
        tasks = [asyncio.create_task(t.serve_forever()) for t in self._transports]
        try:
            await asyncio.gather(*tasks)
        finally:
            for task in tasks:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task


class TransportFactory:
    def __init__(
        self,
        settings: Settings,
        logger: logging.Logger | None = None,
        auth_strategy=None,
    ):
        self._settings = settings
        self._logger = logger or logging.getLogger("fenix_mcp.transport")
        self._auth_strategy = auth_strategy

    async def create(self, *, stack: AsyncExitStack, server) -> Transport:
        transports: List[Transport] = []

        if self._settings.transport_mode in ("stdio", "both"):
            self._logger.info("Enabling STDIO transport")
            transports.append(StdIoTransport(server))

        if self._settings.transport_mode in ("http", "both"):
            self._logger.info(
                "Enabling HTTP transport",
                extra={
                    "host": self._settings.http_host,
                    "port": self._settings.http_port,
                },
            )
            http_transport = HttpTransport(
                server,
                host=self._settings.http_host,
                port=self._settings.http_port,
                auth_server_url=self._settings.auth_server_url,
                auth_strategy=self._auth_strategy,
            )
            stack.push_async_callback(http_transport.shutdown)
            transports.append(http_transport)

        if not transports:
            raise ValueError(
                "No transport configured. Check FENIX_TRANSPORT_MODE env var."
            )

        if len(transports) == 1:
            return transports[0]

        return CompositeTransport(transports)
