"""Twitter CRDT document builder.

Builds pycrdt Doc objects from ParsedTwitterDocument models.
"""

from __future__ import annotations

import json
from typing import Any

from pycrdt import Doc, XmlElement

from marqetive.utils.crdt.builders.base import BaseCRDTBuilder
from marqetive.utils.crdt.models import ParsedTwitterDocument


class TwitterCRDTBuilder(BaseCRDTBuilder[ParsedTwitterDocument]):
    """Builder for Twitter CRDT documents."""

    @property
    def platform_name(self) -> str:
        return "twitter"

    @property
    def root_node_type(self) -> str:
        return "twittercard"

    def build_document(
        self, parsed: ParsedTwitterDocument, fragment_name: str = "default"
    ) -> Doc[Any]:
        """Build a Twitter CRDT Doc from a parsed document.

        Creates twittercard nodes for each card, and optionally a
        twitterthread node if auto_number_config is present.
        """
        children: list[XmlElement] = []

        # Build twitterthread node if auto_number_config present
        if parsed.auto_number_config is not None:
            config = parsed.auto_number_config
            config_dict = {
                "enabled": config.enabled,
                "position": config.position,
                "formatStyle": config.format_style,
                "skipFirst": config.skip_first,
                "skipLast": config.skip_last,
            }
            thread_attrs = {"autoNumberConfig": json.dumps(config_dict)}
            children.append(XmlElement("twitterthread", attributes=thread_attrs))

        # Build card nodes
        for i, card in enumerate(parsed.cards):
            attrs: dict[str, str] = {}
            if card.id is not None:
                attrs["id"] = card.id
            else:
                attrs["id"] = f"card_{i}"

            if card.media:
                attrs["media"] = self._build_media_attribute(card.media)

            if card.is_quoted:
                attrs["isQuoted"] = "true"

            if card.quoted_card_id is not None:
                attrs["quotedCardId"] = card.quoted_card_id

            if card.quoted_tweet_id is not None:
                attrs["quoteOg"] = "true"
                attrs["og"] = f"https://x.com/i/status/{card.quoted_tweet_id}"

            paragraphs = self._build_text_paragraphs(card.text)
            children.append(
                XmlElement("twittercard", attributes=attrs, contents=paragraphs)
            )

        return self._create_doc_with_fragment(fragment_name, children)
