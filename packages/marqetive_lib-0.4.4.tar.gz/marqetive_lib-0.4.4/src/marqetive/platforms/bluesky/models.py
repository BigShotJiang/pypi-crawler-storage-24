"""BlueSky-specific models for post creation."""

from datetime import datetime

from pydantic import BaseModel, Field


class BlueSkyPostRequest(BaseModel):
    """BlueSky-specific post creation request.

    Attributes:
        text: Post text content.
        langs: Optional BCP-47 language tags (e.g., ["en"]).
        reply_to_uri: Optional post URI to reply to.
        created_at: Optional custom creation timestamp.
    """

    text: str
    langs: list[str] = Field(default_factory=list)
    reply_to_uri: str | None = None
    created_at: datetime | None = None
