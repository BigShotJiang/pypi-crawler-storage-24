"""Threads-specific models for post creation."""

from pydantic import BaseModel


class ThreadsPostRequest(BaseModel):
    """Threads-specific request model.

    Attributes:
        text: Post text content.
        media_url: Optional image or video URL.
        reply_to_post_id: Optional Threads post ID to reply to.
        reply_control: Optional reply control mode (e.g., "everyone").
    """

    text: str
    media_url: str | None = None
    reply_to_post_id: str | None = None
    reply_control: str | None = None
