#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
改进的评分系统 - 结合自然语义分析和AI评分
对除选择题和判断题外的所有题目进行主观评分，取两种评分方式的较高分
"""

import re
import jieba
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print("[WARNING] scikit-learn未安装，将使用简化的语义分析")

try:
    from intelligent_grading_qwen import QwenIntelligentGrader
    AI_GRADING_AVAILABLE = True
except ImportError:
    AI_GRADING_AVAILABLE = False
    print("[WARNING] AI评分模块未找到，将只使用自然语义分析")

# 导入关键词导向评分器
try:
    from keyword_focused_grader import get_keyword_focused_grader, KeywordFocusedGrader
    KEYWORD_GRADING_AVAILABLE = True
    print("[SUCCESS] 关键词导向评分器可用")
except ImportError:
    KEYWORD_GRADING_AVAILABLE = False
    print("[WARNING] 关键词导向评分器不可用")

# 导入语义分析评分器（备用）
try:
    from intelligent_grading_enhanced import get_enhanced_grader, EnhancedIntelligentGrader
    SEMANTIC_GRADING_AVAILABLE = True
    print("[SUCCESS] 语义分析评分器可用")
except ImportError:
    SEMANTIC_GRADING_AVAILABLE = False
    print("[WARNING] 语义分析评分器不可用")

class ImprovedGradingSystem:
    """改进的评分系统 - 结合语义分析和AI评分"""
    
    def __init__(self):
        self.semantic_grader = SemanticGrader()
        
        # 初始化AI评分器（如果可用）
        self.ai_grader = None
        if AI_GRADING_AVAILABLE:
            try:
                self.ai_grader = QwenIntelligentGrader()
                print("[SUCCESS] AI评分器初始化成功")
            except Exception as e:
                print(f"[WARNING] AI评分器初始化失败: {e}")
                self.ai_grader = None
        
        # 支持主观评分的题目类型
        self.subjective_types = [
            'essay', 'code_reading', 'code_practice', 
            'short_answer', 'fill_blank', 'programming',
            'analysis', 'design', 'explanation', 'discussion'
        ]
    
    def is_subjective_question(self, question_type: str) -> bool:
        """判断是否为主观题"""
        return question_type.lower() in self.subjective_types
    
    def grade_question(self, question_type: str, student_answer: str, 
                      correct_answer: str, question_text: str = "", 
                      max_score: float = 100.0) -> Dict[str, Any]:
        """
        对单个题目进行评分
        
        Args:
            question_type: 题目类型
            student_answer: 学生答案
            correct_answer: 正确答案/参考答案
            question_text: 题目文本
            max_score: 满分
            
        Returns:
            评分结果字典
        """
        
        if not self.is_subjective_question(question_type):
            # 选择题和判断题使用精确匹配
            return self._grade_objective_question(
                question_type, student_answer, correct_answer, max_score
            )
        
        # 主观题使用综合评分
        return self._grade_subjective_question(
            student_answer, correct_answer, question_text, max_score, question_type
        )
    
    def _grade_objective_question(self, question_type: str, student_answer: str, 
                                 correct_answer: str, max_score: float) -> Dict[str, Any]:
        """客观题评分（选择题、判断题）"""
        
        student_clean = student_answer.strip()
        correct_clean = correct_answer.strip()
        
        is_correct = False
        score = 0.0
        
        if question_type == 'choice':
            # 选择题：完全匹配
            if student_clean.upper() == correct_clean.upper():
                is_correct = True
                score = max_score
        elif question_type == 'judge':
            # 判断题：完全匹配
            if student_clean.lower() == correct_clean.lower():
                is_correct = True
                score = max_score
        
        return {
            'score': score,
            'is_correct': is_correct,
            'confidence': 1.0 if is_correct else 0.0,
            'feedback': '正确' if is_correct else f'错误，正确答案是：{correct_answer}',
            'grading_method': 'exact_match',
            'details': {
                'question_type': question_type,
                'semantic_score': 0,
                'ai_score': 0,
                'final_score': score
            }
        }
    
    def _grade_subjective_question(self, student_answer: str, reference_answer: str,
                                  question_text: str, max_score: float, 
                                  question_type: str) -> Dict[str, Any]:
        """主观题评分 - 结合语义分析和AI评分"""
        
        # 基础检查
        if not student_answer or not student_answer.strip():
            return {
                'score': 0.0,
                'is_correct': False,
                'confidence': 1.0,
                'feedback': '未作答',
                'grading_method': 'no_answer',
                'details': {
                    'question_type': question_type,
                    'semantic_score': 0,
                    'ai_score': 0,
                    'final_score': 0
                }
            }
        
        results = {}
        
        # 1. 自然语义分析评分
        semantic_result = self.semantic_grader.grade(
            student_answer, reference_answer, question_text, max_score
        )
        results['semantic'] = semantic_result
        
        # 2. AI评分（如果可用）
        ai_result = None
        if self.ai_grader:
            try:
                ai_result = self.ai_grader.intelligent_grade(
                    student_answer, reference_answer, question_text, max_score
                )
                results['ai'] = ai_result
            except Exception as e:
                print(f"AI评分失败: {e}")
                ai_result = None
        
        # 3. 融合评分 - 取较高分
        final_score, final_confidence, grading_method, feedback = self._fuse_scores(
            semantic_result, ai_result, max_score
        )
        
        return {
            'score': final_score,
            'is_correct': final_score > max_score * 0.6,  # 60%以上算正确
            'confidence': final_confidence,
            'feedback': feedback,
            'grading_method': grading_method,
            'details': {
                'question_type': question_type,
                'semantic_score': semantic_result['score'],
                'ai_score': ai_result['score'] if ai_result else 0,
                'final_score': final_score,
                'semantic_details': semantic_result.get('details', {}),
                'ai_details': ai_result.get('details', {}) if ai_result else {}
            }
        }
    
    def _fuse_scores(self, semantic_result: Dict, ai_result: Optional[Dict], 
                    max_score: float) -> Tuple[float, float, str, str]:
        """融合语义分析和AI评分结果"""
        
        semantic_score = semantic_result['score']
        semantic_confidence = semantic_result['confidence']
        
        if not ai_result:
            # 只有语义分析结果
            return (
                semantic_score,
                semantic_confidence,
                'semantic_only',
                f"基于语义分析: {semantic_result['feedback']}"
            )
        
        ai_score = ai_result['score']
        ai_confidence = ai_result['confidence']
        
        # 取较高分策略
        if ai_score > semantic_score:
            # AI评分更高
            score_diff = ai_score - semantic_score
            if score_diff > max_score * 0.3:  # 差异超过30%，需要谨慎
                # 如果差异过大，取加权平均而不是直接取高分
                final_score = (ai_score * 0.7 + semantic_score * 0.3)
                final_confidence = min(ai_confidence, semantic_confidence) * 0.8
                method = 'weighted_fusion_ai_higher'
                feedback = f"AI评分较高但差异较大，综合评分: AI({ai_score:.1f}) + 语义({semantic_score:.1f}) = {final_score:.1f}"
            else:
                # 差异不大，采用AI评分
                final_score = ai_score
                final_confidence = ai_confidence
                method = 'ai_higher'
                feedback = f"AI评分: {ai_result['feedback']}"
        else:
            # 语义分析评分更高或相等
            score_diff = semantic_score - ai_score
            if score_diff > max_score * 0.3:  # 差异超过30%
                # 如果差异过大，取加权平均
                final_score = (semantic_score * 0.7 + ai_score * 0.3)
                final_confidence = min(ai_confidence, semantic_confidence) * 0.8
                method = 'weighted_fusion_semantic_higher'
                feedback = f"语义评分较高但差异较大，综合评分: 语义({semantic_score:.1f}) + AI({ai_score:.1f}) = {final_score:.1f}"
            else:
                # 差异不大，采用语义评分
                final_score = semantic_score
                final_confidence = semantic_confidence
                method = 'semantic_higher'
                feedback = f"语义分析: {semantic_result['feedback']}"
        
        # 确保分数在合理范围内
        final_score = max(0.0, min(final_score, max_score))
        final_confidence = max(0.0, min(final_confidence, 1.0))
        
        return final_score, final_confidence, method, feedback


class SemanticGrader:
    """自然语义分析评分器"""
    
    def __init__(self):
        self.use_sklearn = SKLEARN_AVAILABLE
        if self.use_sklearn:
            self.vectorizer = TfidfVectorizer(
                max_features=1000,
                stop_words=None,
                ngram_range=(1, 2)
            )
        
        # 关键词权重
        self.keyword_weights = {
            'high': 1.0,      # 高权重关键词
            'medium': 0.7,    # 中权重关键词
            'low': 0.4        # 低权重关键词
        }
    
    def preprocess_text(self, text: str) -> str:
        """文本预处理"""
        if not text or not isinstance(text, str):
            return ""
        
        # 去除多余空格和特殊字符
        text = re.sub(r'\s+', ' ', text.strip())
        
        # 中文分词（如果jieba可用）
        try:
            words = jieba.cut(text)
            return ' '.join(words)
        except:
            # 如果jieba不可用，返回原文本
            return text
    
    def calculate_semantic_similarity(self, student_answer: str, reference_answer: str) -> float:
        """计算语义相似性"""
        if not self.use_sklearn:
            return self._simple_similarity(student_answer, reference_answer)
        
        try:
            # 预处理文本
            student_processed = self.preprocess_text(student_answer)
            reference_processed = self.preprocess_text(reference_answer)
            
            if not student_processed or not reference_processed:
                return 0.0
            
            # 使用TF-IDF向量化
            texts = [student_processed, reference_processed]
            tfidf_matrix = self.vectorizer.fit_transform(texts)
            
            # 计算余弦相似度
            similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            
            return float(similarity)
        
        except Exception as e:
            print(f"计算语义相似性时出错: {e}")
            return self._simple_similarity(student_answer, reference_answer)
    
    def _simple_similarity(self, text1: str, text2: str) -> float:
        """简单的相似度计算（不依赖sklearn）"""
        if not text1 or not text2:
            return 0.0
        
        # 字符级别的相似度
        text1_lower = text1.lower()
        text2_lower = text2.lower()
        
        # 计算交集和并集
        set1 = set(text1_lower)
        set2 = set(text2_lower)
        
        intersection = len(set1.intersection(set2))
        union = len(set1.union(set2))
        
        if union == 0:
            return 0.0
        
        return intersection / union
    
    def extract_keywords(self, reference_answer: str) -> Dict[str, List[str]]:
        """从参考答案中提取关键词"""
        keywords = {
            'high': [],
            'medium': [],
            'low': []
        }
        
        if not reference_answer:
            return keywords
        
        # 简单的关键词提取
        text = reference_answer.lower()
        
        # 高权重关键词（技术术语、重要概念）
        high_keywords = re.findall(r'[a-zA-Z]+[0-9]*|[^\w\s]{2,}', text)
        keywords['high'] = [kw for kw in high_keywords if len(kw) > 2]
        
        # 中权重关键词（一般名词、动词）
        words = text.split()
        medium_keywords = [word for word in words if len(word) > 3 and word not in keywords['high']]
        keywords['medium'] = medium_keywords[:10]  # 限制数量
        
        # 低权重关键词（其他词汇）
        low_keywords = [word for word in words if len(word) > 1 and word not in keywords['high'] and word not in keywords['medium']]
        keywords['low'] = low_keywords[:15]  # 限制数量
        
        return keywords
    
    def calculate_keyword_coverage(self, student_answer: str, keywords: Dict[str, List[str]]) -> float:
        """计算关键词覆盖率"""
        student_text = student_answer.lower()
        
        if not student_text:
            return 0.0
        
        total_score = 0.0
        max_possible_score = 0.0
        
        for level, keyword_list in keywords.items():
            weight = self.keyword_weights[level]
            
            for keyword in keyword_list:
                max_possible_score += weight
                
                # 检查关键词是否在学生答案中
                if keyword.lower() in student_text:
                    total_score += weight
        
        if max_possible_score == 0:
            return 0.0
        
        return total_score / max_possible_score
    
    def assess_completeness(self, student_answer: str, reference_answer: str) -> float:
        """评估答案完整性"""
        if not student_answer:
            return 0.0
        
        if not reference_answer:
            return 0.5  # 没有参考答案时给中等分
        
        # 基于长度的完整性
        length_ratio = len(student_answer) / len(reference_answer)
        length_score = min(1.0, length_ratio)
        
        # 基于句子数量的完整性
        student_sentences = len(re.split(r'[。！？.!?]', student_answer))
        reference_sentences = len(re.split(r'[。！？.!?]', reference_answer))
        
        if reference_sentences > 0:
            sentence_ratio = student_sentences / reference_sentences
            sentence_score = min(1.0, sentence_ratio)
        else:
            sentence_score = 0.5
        
        return (length_score * 0.6 + sentence_score * 0.4)
    
    def assess_relevance(self, student_answer: str, question_text: str) -> float:
        """评估答案相关性"""
        if not student_answer or not question_text:
            return 0.0
        
        # 使用相似度计算相关性
        return self.calculate_semantic_similarity(student_answer, question_text)
    
    def grade(self, student_answer: str, reference_answer: str, 
             question_text: str, max_score: float) -> Dict[str, Any]:
        """语义评分主函数"""
        
        if not student_answer or not student_answer.strip():
            return {
                'score': 0.0,
                'confidence': 1.0,
                'feedback': '未作答',
                'details': {}
            }
        
        if len(student_answer.strip()) < 3:
            return {
                'score': max_score * 0.1,
                'confidence': 0.9,
                'feedback': '答案过于简短',
                'details': {}
            }
        
        try:
            # 1. 语义相似性
            semantic_similarity = self.calculate_semantic_similarity(student_answer, reference_answer)
            
            # 2. 关键词覆盖
            keywords = self.extract_keywords(reference_answer)
            keyword_coverage = self.calculate_keyword_coverage(student_answer, keywords)
            
            # 3. 完整性
            completeness = self.assess_completeness(student_answer, reference_answer)
            
            # 4. 相关性
            relevance = self.assess_relevance(student_answer, question_text)
            
            # 综合评分
            weights = {
                'semantic': 0.40,      # 语义相似性
                'keywords': 0.30,      # 关键词覆盖
                'completeness': 0.20,  # 完整性
                'relevance': 0.10      # 相关性
            }
            
            composite_score = (
                semantic_similarity * weights['semantic'] +
                keyword_coverage * weights['keywords'] +
                completeness * weights['completeness'] +
                relevance * weights['relevance']
            )
            
            final_score = composite_score * max_score
            
            # 置信度计算
            scores = [semantic_similarity, keyword_coverage, completeness, relevance]
            confidence = 1.0 - np.std(scores)  # 方差小则置信度高
            confidence = max(0.3, min(1.0, confidence))
            
            # 生成反馈
            feedback = self._generate_feedback(
                semantic_similarity, keyword_coverage, completeness, relevance
            )
            
            return {
                'score': round(final_score, 1),
                'confidence': round(confidence, 3),
                'feedback': feedback,
                'details': {
                    'semantic_similarity': semantic_similarity,
                    'keyword_coverage': keyword_coverage,
                    'completeness': completeness,
                    'relevance': relevance,
                    'composite_score': composite_score
                }
            }
        
        except Exception as e:
            print(f"语义评分出错: {e}")
            return {
                'score': max_score * 0.5,
                'confidence': 0.3,
                'feedback': f'评分出错: {str(e)}',
                'details': {}
            }
    
    def _generate_feedback(self, semantic_sim: float, keyword_cov: float,
                          completeness: float, relevance: float) -> str:
        """生成评分反馈"""
        
        feedback_parts = []
        
        # 语义相似性反馈
        if semantic_sim >= 0.7:
            feedback_parts.append("答案与参考答案语义相似度很高")
        elif semantic_sim >= 0.4:
            feedback_parts.append("答案与参考答案有一定相似性")
        else:
            feedback_parts.append("答案与参考答案相似度较低")
        
        # 关键词覆盖反馈
        if keyword_cov >= 0.7:
            feedback_parts.append("涵盖了主要知识点")
        elif keyword_cov >= 0.4:
            feedback_parts.append("涵盖了部分关键知识点")
        else:
            feedback_parts.append("缺少重要知识点")
        
        # 完整性反馈
        if completeness >= 0.7:
            feedback_parts.append("答案较为完整")
        elif completeness >= 0.4:
            feedback_parts.append("答案基本完整")
        else:
            feedback_parts.append("答案不够完整")
        
        # 相关性反馈
        if relevance < 0.3:
            feedback_parts.append("答案与问题相关性较低")
        
        return "；".join(feedback_parts) + "。"


# 全局评分器实例
_improved_grader = None

def get_improved_grader():
    """获取改进评分器实例"""
    global _improved_grader
    if _improved_grader is None:
        _improved_grader = ImprovedGradingSystem()
    return _improved_grader

def improved_calculate_score_detailed(questions, answers, exam_result_id: int = 0):
    """
    使用改进的评分系统计算详细得分
    
    Args:
        questions: 题目列表
        answers: 答案字典
        exam_result_id: 考试结果ID
        
    Returns:
        (总分, 题目得分列表)
    """
    
    if not questions:
        return 0.0, []
    
    grader = get_improved_grader()
    total_questions = len(questions)
    question_scores = []
    total_score = 0.0
    
    # 每题的满分（平均分配）
    max_score_per_question = 100.0 / total_questions
    
    for i, question in enumerate(questions):
        question_key = f"question_{i}"
        user_answer = answers.get(question_key, "").strip()
        
        # 使用改进的评分系统
        grading_result = grader.grade_question(
            question_type=question.question_type,
            student_answer=user_answer,
            correct_answer=question.correct_answer,
            question_text=question.question_text,
            max_score=max_score_per_question
        )
        
        score = grading_result['score']
        is_correct = grading_result['is_correct']
        total_score += score
        
        # 创建题目得分记录
        from models import QuestionScore
        question_score = QuestionScore(
            exam_result_id=exam_result_id,
            question_id=question.id or 0,
            question_order=i,
            student_answer=user_answer,
            correct_answer=question.correct_answer,
            is_correct=is_correct,
            score=score,
            max_score=max_score_per_question,
            question_type=question.question_type,
            question_text=question.question_text
        )
        
        # 添加评分详情
        question_score.grading_details = {
            'method': grading_result['grading_method'],
            'confidence': grading_result['confidence'],
            'feedback': grading_result['feedback'],
            'details': grading_result['details']
        }
        
        question_scores.append(question_score)
    
    return total_score, question_scores


def test_improved_grading():
    """测试改进的评分系统"""
    print("🧪 测试改进的评分系统...")
    
    grader = ImprovedGradingSystem()
    
    # 测试数据
    test_cases = [
        {
            'type': 'choice',
            'student': 'A',
            'correct': 'A',
            'question': '选择题测试',
            'expected_score': 100
        },
        {
            'type': 'judge', 
            'student': 'True',
            'correct': 'True',
            'question': '判断题测试',
            'expected_score': 100
        },
        {
            'type': 'essay',
            'student': '这是一个详细的答案，包含了多个关键概念和理论分析',
            'correct': '标准答案应该包含关键概念、理论分析和具体示例',
            'question': '请详细说明相关理论',
            'expected_score': 50  # 主观题预期中等分数
        },
        {
            'type': 'code_reading',
            'student': '这段代码实现了排序算法，时间复杂度是O(n²)',
            'correct': '冒泡排序算法，时间复杂度O(n²)，空间复杂度O(1)',
            'question': '分析这段排序代码的算法和复杂度',
            'expected_score': 70
        }
    ]
    
    for i, case in enumerate(test_cases, 1):
        print(f"\n测试用例 {i}: {case['type']}")
        
        result = grader.grade_question(
            question_type=case['type'],
            student_answer=case['student'],
            correct_answer=case['correct'],
            question_text=case['question'],
            max_score=100.0
        )
        
        print(f"  得分: {result['score']:.1f}/100")
        print(f"  置信度: {result['confidence']:.2f}")
        print(f"  评分方法: {result['grading_method']}")
        print(f"  反馈: {result['feedback']}")
        
        if 'details' in result:
            details = result['details']
            if 'semantic_score' in details and 'ai_score' in details:
                print(f"  语义评分: {details['semantic_score']:.1f}")
                print(f"  AI评分: {details['ai_score']:.1f}")
    
    print("\n[SUCCESS] 改进评分系统测试完成！")


if __name__ == "__main__":
    test_improved_grading() 