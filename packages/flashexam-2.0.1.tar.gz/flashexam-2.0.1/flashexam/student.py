from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import login_required, current_user
from datetime import datetime
import json
import traceback

from .database import Database
from .models import Student, Question, Exam, QuestionScore
from .utils import calculate_score_detailed
from .exam_reliability_system import get_submission_optimizer

# 尝试导入阅读理解相关模块，如果失败则设置为None
try:
    from reading_passage_database import ReadingPassageDatabase
    from reading_passage_models import ReadingPassage
    READING_MODULE_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Reading passage modules not available: {e}")
    ReadingPassageDatabase = None
    ReadingPassage = None
    READING_MODULE_AVAILABLE = False

student_bp = Blueprint('student', __name__)

@student_bp.before_request
def require_student():
    """确保只有学生可以访问学生端"""
    # 跳过静态文件和API端点
    if request.endpoint and (request.endpoint.startswith('static') or 
                           request.endpoint.startswith('api') or
                           'health' in request.endpoint):
        return
    
    if not current_user.is_authenticated:
        # 清理可能损坏的会话
        session.clear()
        flash('请先登录', 'error')
        return redirect(url_for('auth.login'))
    
    try:
        if not current_user.is_student():
            flash('您需要学生权限才能访问此页面', 'error')
            return redirect(url_for('auth.login'))
        
        # 额外验证：确保能获取学生信息
        student_info = current_user.get_student_info()
        if not student_info:
            # 尝试刷新用户会话
            from flask_login import logout_user
            logout_user()
            session.clear()
            flash('会话已过期，请重新登录', 'warning')
            return redirect(url_for('auth.login'))
            
    except Exception as e:
        print(f"[ERROR] 学生权限验证失败: {e}")
        # 清理损坏的会话
        from flask_login import logout_user
        logout_user()
        session.clear()
        flash('会话状态异常，请重新登录', 'error')
        return redirect(url_for('auth.login'))

@student_bp.route('/dashboard')
@login_required
def dashboard():
    """学生仪表板"""
    try:
        db = Database()
        student_info = current_user.get_student_info()
        
        print(f"Dashboard - Current user: {current_user}")
        print(f"Dashboard - Student info: {student_info}")
        
        if not student_info:
            flash('无法获取学生信息', 'error')
            return redirect(url_for('auth.login'))
        
        # 获取学生的考试历史 - 严格按学生ID过滤
        exam_history = db.get_student_exam_history(student_info['id'])
        
        # 获取可用考试
        all_exams = db.get_exams()
        available_exams = []
        
        for exam in all_exams:
            if exam.is_active:
                # 检查学生是否已经完成过这个考试
                already_completed = any(h['exam_id'] == exam.id and h.get('is_completed', False) for h in exam_history)
                if not already_completed:
                    available_exams.append(exam)
        
        # 统计信息 - 只统计已完成的考试
        completed_history = [h for h in exam_history if h.get('is_completed', False)]
        total_exams = len(completed_history)
        completed_exams = len(completed_history)
        average_score = 0
        if completed_exams > 0:
            total_score = sum(h.get('score', 0) for h in completed_history)
            average_score = total_score / completed_exams
        
        # 显示最近的考试历史（包括进行中的）
        recent_history = exam_history[:5]
        
        return render_template('student/dashboard.html',
                             student_info=student_info,
                             exam_history=recent_history,
                             available_exams=available_exams[:5],  # 最近5个可用考试
                             total_exams=total_exams,
                             completed_exams=completed_exams,
                             average_score=average_score)
                             
    except Exception as e:
        print(f"Student dashboard error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载仪表板数据时发生错误', 'error')
        return render_template('student/dashboard.html',
                             student_info={},
                             exam_history=[],
                             available_exams=[],
                             total_exams=0,
                             completed_exams=0,
                             average_score=0)

@student_bp.route('/exams')
@login_required
def exams():
    """考试列表页面 - 全面改进版，支持允许继续考试的状态"""
    try:
        db = Database()
        student_info = current_user.get_student_info()
        
        print(f"Exams - Current user: {current_user}")
        print(f"Exams - Student info: {student_info}")
        
        if not student_info:
            flash('无法获取学生信息', 'error')
            return redirect(url_for('auth.login'))
        
        # 🔥 全面改进：更智能的考试状态判断
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 获取学生学号
            cursor.execute('SELECT student_id FROM students WHERE id = ?', (student_info['id'],))
            student_row = cursor.fetchone()
            if not student_row:
                flash('学生信息不存在', 'error')
                return redirect(url_for('auth.login'))
            
            student_number = student_row[0]
            
            # 获取所有考试的状态信息
            cursor.execute('''
                SELECT er.exam_id, er.is_completed, er.score, er.total_score
                FROM exam_results er
                WHERE er.student_id = ?
            ''', (student_info['id'],))
            exam_results = {row[0]: {'is_completed': bool(row[1]), 'score': row[2], 'total_score': row[3]} 
                           for row in cursor.fetchall()}
            
            # 获取所有活跃的考试进度记录
            cursor.execute('''
                SELECT ep.exam_id, ep.is_active, ep.start_time
                FROM exam_progress ep
                WHERE ep.student_number = ? AND ep.is_active = 1
            ''', (student_number,))
            active_progress = {row[0]: {'is_active': bool(row[1]), 'start_time': row[2]} 
                              for row in cursor.fetchall()}
        
        # 获取所有考试并分类
        all_exams = db.get_exams()
        available_exams = []
        completed_exams = []
        
        for exam in all_exams:
            if exam.is_active:
                exam_result = exam_results.get(exam.id)
                has_active_progress = exam.id in active_progress
                
                # 🔥 关键改进：使用与exam_status一致的逻辑
                if exam_result and has_active_progress:
                    # 同时有考试结果和活跃进度
                    if exam_result['is_completed']:
                        # 已完成但有活跃进度 = 教师允许继续
                        exam.status_info = {
                            'can_take': True,
                            'status': 'can_continue',
                            'message': '可以继续考试',
                            'score': exam_result['score'],
                            'total_score': exam_result['total_score']
                        }
                        available_exams.append(exam)
                    else:
                        # 未完成且有活跃进度 = 正在进行
                        exam.status_info = {
                            'can_take': True,
                            'status': 'in_progress',
                            'message': '考试进行中'
                        }
                        available_exams.append(exam)
                        
                elif exam_result and not has_active_progress:
                    # 只有考试结果，没有活跃进度
                    if exam_result['is_completed']:
                        # 真正完成的考试
                        exam.status_info = {
                            'can_take': False,
                            'status': 'completed',
                            'message': '已完成',
                            'score': exam_result['score'],
                            'total_score': exam_result['total_score']
                        }
                        completed_exams.append(exam)
                    else:
                        # 未完成且无活跃进度 = 可以开始
                        exam.status_info = {
                            'can_take': True,
                            'status': 'can_start',
                            'message': '可以开始考试'
                        }
                        available_exams.append(exam)
                        
                elif not exam_result and has_active_progress:
                    # 只有进度记录，没有考试结果 = 正在进行
                    exam.status_info = {
                        'can_take': True,
                        'status': 'in_progress',
                        'message': '考试进行中'
                    }
                    available_exams.append(exam)
                    
                else:
                    # 既没有考试结果也没有进度记录 = 可以开始
                    exam.status_info = {
                        'can_take': True,
                        'status': 'can_start',
                        'message': '可以开始考试'
                    }
                    available_exams.append(exam)
        
        print(f"考试列表 - 可用考试: {len(available_exams)}, 已完成考试: {len(completed_exams)}")
        
        return render_template('student/exams.html',
                             available_exams=available_exams,
                             completed_exams=completed_exams)
                             
    except Exception as e:
        print(f"Student exams error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载考试列表时发生错误', 'error')
        return render_template('student/exams.html',
                             available_exams=[],
                             completed_exams=[])

@student_bp.route('/exam/<int:exam_id>')
@login_required
def take_exam(exam_id):
    """参加考试页面 - 改进版，支持按学号进度保存"""
    db = Database()
    try:
        student_info = current_user.get_student_info()
        
        print(f"Take exam - Current user: {current_user}")
        print(f"Take exam - Student info: {student_info}")
        print(f"Take exam - Exam ID: {exam_id}")
        
        if not student_info:
            flash('无法获取学生信息', 'error')
            return redirect(url_for('auth.login'))
        
        student_number = student_info['student_id']
        student_name = student_info['name']
        
        # 获取考试信息
        exams = db.get_exams()
        exam = next((e for e in exams if e.id == exam_id), None)
        
        if not exam:
            flash('考试不存在', 'error')
            return redirect(url_for('student.exams'))
        
        if not exam.is_active:
            flash('考试已关闭，无法参加', 'error')
            return redirect(url_for('student.exams'))
        
        # 🔥 关键修复：检查学生是否已经完成过这个考试 - 考虑允许继续考试的情况
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. 检查是否有已完成的考试结果
            cursor.execute('''
                SELECT is_completed, score, total_score FROM exam_results 
                WHERE student_id = ? AND exam_id = ?
                ORDER BY id DESC LIMIT 1
            ''', (student_info['id'], exam_id))
            exam_result = cursor.fetchone()
            
            # 2. 检查是否有活跃的进度记录（教师允许继续考试时会创建）
            has_active_progress = False
            cursor.execute('''
                SELECT 1 FROM exam_progress 
                WHERE exam_id = ? AND student_number = ?
            ''', (exam_id, student_number))
            has_active_progress = bool(cursor.fetchone())
        
        # 3. 只有真正完成且没有活跃进度时才阻止参加考试
        if exam_result and exam_result[0] and not has_active_progress:
            # 显示更详细的完成信息
            score = exam_result[1] or 0
            total_score = exam_result[2] or 100
            percentage = (score / total_score * 100) if total_score > 0 else 0
            flash(f'您已经完成了这个考试，得分：{score:.1f}/{total_score:.1f} ({percentage:.1f}%)', 'info')
            return redirect(url_for('student.exams'))
        elif exam_result and exam_result[0] and has_active_progress:
            # 🔥 关键修复：教师允许继续考试的情况，直接跳转到continue_exam以恢复答案
            print(f"学生 {student_number} 的考试已完成但有活跃进度，跳转到继续考试页面")
            flash('教师已允许您继续这个考试，正在恢复您之前的答案...', 'info')
            return redirect(url_for('student.continue_exam', exam_id=exam_id))

        # 首先清理所有超时的考试
        db.cleanup_expired_exams()
        
        # 检查按学号保存的考试进度
        progress_info = db.get_exam_progress_by_student_number(exam_id, student_number)
        
        # 处理重新开始的请求
        restart = request.args.get('restart', '').lower() == 'true'
        if restart and progress_info:
            success = db.clear_exam_progress_by_student_number(exam_id, student_number)
            if success:
                flash('考试已重新开始', 'success')
                progress_info = None  # 清除进度信息
            else:
                flash('重新开始考试失败', 'error')
                return redirect(url_for('student.exams'))

        # 检查是否有未完成的考试进度
        if progress_info and not restart:
            elapsed_minutes = progress_info['elapsed_minutes']
            remaining_minutes = exam.duration_minutes - elapsed_minutes
            
            if remaining_minutes <= 0:
                # 考试已过期，自动清理
                flash('上次考试已超时，将开始新的考试', 'warning')
                db.clear_exam_progress_by_student_number(exam_id, student_number)
                progress_info = None
            else:
                # 显示继续考试的选择页面
                incomplete_info = {
                    'exam_title': exam.title,
                    'start_time': progress_info['start_time'],
                    'elapsed_minutes': elapsed_minutes,
                    'remaining_minutes': remaining_minutes
                }
                return render_template('student/exam_continue_choice.html',
                                     exam=exam,
                                     incomplete_info=incomplete_info)
        
        # 开始新的考试
        from datetime import datetime
        
        # 创建或获取exam_results记录
        result_id = db.start_exam(exam_id, student_info['id'])
        if not result_id:
            flash('无法创建新的考试记录', 'error')
            return redirect(url_for('student.exams'))
            
        # 设置会话信息
        session['current_exam_result_id'] = result_id
        session['exam_start_time'] = datetime.now().isoformat()
        session['current_student_id'] = student_info['id']
        
        # 清空旧的session进度
        progress_key = f'exam_{exam_id}_progress_{student_info["id"]}'
        session.pop(progress_key, None)
        
        # 初始化新的按学号进度保存
        session_id = session.get('session_id', '')
        ip_address = request.remote_addr
        user_agent = request.headers.get('User-Agent', '')
        
        # 🔥 关键修复：使用答案保存系统初始化考试
        try:
            from answer_preservation_system import save_answers_safely
            
            # 初始化答案保存系统
            save_results = save_answers_safely(
                exam_id, student_info['id'], student_number, {},  # 初始为空答案
                0.0, 'exam_start', session_id, ip_address
            )
            print(f"✅ 答案保存系统初始化: {sum(save_results.values())}/5 个位置成功")
            
        except Exception as e:
            print(f"⚠️ 答案保存系统初始化失败: {e}")
        
        # 同时保存到传统进度表（兼容性）
        db.save_exam_progress_by_student_number(
            exam_id=exam_id,
            student_number=student_number,
            student_name=student_name,
            answers={},  # 初始为空
            elapsed_minutes=0.0,
            session_id=session_id,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        print(f"✅ 新考试开始: 学号={student_number}, 考试ID={exam_id}, 结果ID={result_id}")
        
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        
        if not questions:
            print(f"ERROR: Exam {exam_id} ('{exam.title}') has no questions! This should have been fixed.")
            flash('此考试当前没有题目，无法开始。请联系管理员。', 'error')
            return redirect(url_for('student.exams'))
        
        # 检测是否包含阅读理解题目并进行分组
        reading_passages, regular_questions = detect_and_group_reading_passages(questions)
        
        print(f"Take exam - Questions breakdown:")
        print(f"  Reading passages: {len(reading_passages) if reading_passages else 0}")
        print(f"  Regular questions: {len(regular_questions) if regular_questions else len(questions)}")
        
        # 使用新的考试模板，传递必要的计时信息
        return render_template('student/take_exam_new.html',
                             exam=exam,
                             questions=questions,
                             reading_passages=reading_passages,
                             regular_questions=regular_questions,
                             saved_answers={},  # 新考试无保存答案
                             is_continuing=False,  # 标记为新考试
                             remaining_seconds=exam.duration_minutes * 60,  # 完整时间
                             elapsed_minutes=0,  # 已用时间为0
                             total_duration_minutes=exam.duration_minutes)  # 总时长
        
    except Exception as e:
        print(f"Take exam error: {e}")
        import traceback
        traceback.print_exc()
        flash('开始考试时发生错误', 'error')
        return redirect(url_for('student.exams'))

def detect_and_group_reading_passages(questions):
    """
    检测并分组阅读理解题目 - 适配新题目管理系统
    基于题目的material字段进行分组
    返回: (reading_passages, regular_questions)
    """
    try:
        print("🔍 检测和分组阅读材料...")
        
        reading_passages = []
        regular_questions = []
        material_groups = {}
        
        for question in questions:
            # 检查题目是否有material字段且不为空
            material = getattr(question, 'material', '').strip()
            
            if material and len(material) > 50:  # 有实质性内容的材料
                # 按材料内容分组
                if material not in material_groups:
                    material_groups[material] = []
                material_groups[material].append(question)
            else:
                # 没有材料的普通题目
                regular_questions.append(question)
        
        # 为每个材料组创建虚拟阅读材料对象
        for material_content, material_questions in material_groups.items():
            print(f"  📖 发现材料组: {len(material_questions)}道题目")
            
            # 创建虚拟阅读材料对象
            virtual_passage = {
                'id': hash(material_content) % 1000000,  # 生成唯一ID
                'title': extract_title_from_content(material_content),
                'content': material_content,
                'source': "考试材料",
                'topic': "阅读理解",
                'difficulty_level': 2,
                'language': "en" if is_english_content(material_content) else "cn",
                'word_count': len(material_content.split()),
                'reading_time': max(3, len(material_content) // 200)  # 估算阅读时间
            }
            
            reading_passages.append({
                'passage': virtual_passage,
                'questions': material_questions
            })
        
        print(f"✅ 检测结果: {len(reading_passages)}个阅读材料组, {len(regular_questions)}道普通题目")
        return reading_passages, regular_questions
        
    except Exception as e:
        print(f"❌ 阅读材料检测失败: {e}")
        import traceback
        traceback.print_exc()
        # 发生错误时，返回所有题目作为普通题目
        return [], questions

def extract_passage_info_from_question(question):
    """从题目中提取阅读材料信息"""
    # 这里需要根据实际的数据结构来实现
    # 假设题目有阅读材料ID或者其他标识
    return None

def is_embedded_reading_question(question):
    """判断是否是嵌入式阅读理解题目"""
    # 检查题目文本长度，如果很长可能包含阅读材料
    question_text = getattr(question, 'question_text', '')
    
    # 检查是否包含典型的阅读材料标识词
    reading_indicators = [
        '阅读材料', 'Reading Passage', 'Read the following',
        'According to the passage', 'The passage states',
        'Based on the text', '根据上文', '文章中提到'
    ]
    
    # 如果题目文本很长（超过500字符）或包含阅读材料标识词
    if len(question_text) > 500:
        return True
    
    for indicator in reading_indicators:
        if indicator.lower() in question_text.lower():
            return True
    
    return False

def extract_embedded_passage_content(question):
    """从嵌入式题目中提取阅读材料内容"""
    question_text = getattr(question, 'question_text', '')
    
    # 尝试提取阅读材料部分
    # 常见的分隔模式
    patterns = [
        r'阅读材料[：:]?\s*(.+?)\s*题目[：:]?',
        r'Reading Passage[：:]?\s*(.+?)\s*Question[：:]?',
        r'Read the following[：:]?\s*(.+?)\s*\d+\.',
        r'^(.+?)\s*题目\s*\d+[：:]?',
        r'^(.+?)\s*Question\s*\d+[：:]?'
    ]
    
    import re
    for pattern in patterns:
        match = re.search(pattern, question_text, re.DOTALL | re.IGNORECASE)
        if match:
            content = match.group(1).strip()
            if len(content) > 100:  # 确保提取的内容足够长
                return content
    
    # 如果没有找到明确的分隔，但题目很长，可能整个就是阅读材料+题目
    if len(question_text) > 500:
        # 尝试找到题目开始的位置
        question_markers = [
            r'\d+\.\s*What',
            r'\d+\.\s*Which',
            r'\d+\.\s*According',
            r'\d+\.\s*The',
            r'\d+[．.]\s*什么',
            r'\d+[．.]\s*哪个',
            r'\d+[．.]\s*根据'
        ]
        
        for marker in question_markers:
            match = re.search(marker, question_text, re.IGNORECASE)
            if match:
                content = question_text[:match.start()].strip()
                if len(content) > 100:
                    return content
        
        # 如果没找到，返回前80%的内容作为阅读材料
        split_point = int(len(question_text) * 0.8)
        return question_text[:split_point].strip()
    
    return None

def find_related_embedded_questions(questions, passage_content):
    """找到与相同阅读材料相关的所有题目"""
    related_questions = []
    passage_key = passage_content[:200]  # 使用前200字符作为匹配标准
    
    for question in questions:
        question_text = getattr(question, 'question_text', '')
        if passage_key in question_text or question_text[:200] in passage_content:
            related_questions.append(question)
    
    return related_questions

def extract_title_from_content(content):
    """从内容中提取标题"""
    lines = content.split('\n')
    first_line = lines[0].strip()
    
    # 如果第一行比较短，可能是标题
    if len(first_line) < 100 and len(first_line) > 5:
        return first_line
    
    # 否则使用前50个字符作为标题
    return content[:50].strip() + "..."

def is_english_content(content):
    """判断内容是否为英文"""
    import re
    chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', content))
    total_chars = len(content)
    return chinese_chars / total_chars < 0.1 if total_chars > 0 else True

@student_bp.route('/exam/<int:exam_id>/continue')
@login_required
def continue_exam(exam_id):
    """继续未完成的考试 - 改进版，支持按学号恢复进度和计时"""
    try:
        db = Database()
        
        # 🔥 关键修复：多种方式获取学生信息
        student_info = current_user.get_student_info()
        
        print(f"Continue exam - Current user: {current_user}")
        print(f"Continue exam - Student info from current_user: {student_info}")
        
        # 如果current_user获取失败，尝试从session获取
        if not student_info or not student_info.get('id'):
            print("Continue exam - Trying to get student info from session")
            
            # 尝试从session获取学生信息
            student_id = session.get('student_id') or session.get('current_student_id')
            student_number = session.get('student_number')
            
            print(f"Continue exam - Session student_id: {student_id}, student_number: {student_number}")
            
            if student_number:
                # 通过学号获取学生信息
                student = db.get_student_by_id(student_number)
                if student:
                    student_info = {
                        'id': student.id,
                        'student_id': student.student_id,
                        'name': student.name,
                        'college': student.college,
                        'major': student.major,
                        'class_name': student.class_name,
                        'gender': student.gender,
                        'notes': student.notes
                    }
                    print(f"Continue exam - Got student info from database: {student_info}")
            elif student_id:
                # 通过内部ID获取学生信息
                students = db.get_all_students()
                for s in students:
                    if str(s.id) == str(student_id):
                        student_info = {
                            'id': s.id,
                            'student_id': s.student_id,
                            'name': s.name,
                            'college': s.college,
                            'major': s.major,
                            'class_name': s.class_name,
                            'gender': s.gender,
                            'notes': s.notes
                        }
                        print(f"Continue exam - Got student info by ID: {student_info}")
                        break
        
        if not student_info or not student_info.get('id'):
            print("Continue exam - No student info found, redirecting to login")
            flash('无法获取学生信息，请重新登录', 'error')
            return redirect(url_for('auth.login'))
        
        student_number = student_info['student_id']
        student_name = student_info['name']
        
        print(f"Continue exam - Final student info: ID={student_info['id']}, Number={student_number}, Name={student_name}")
        
        # 获取考试信息
        try:
            exams = db.get_exams()
            exam = next((e for e in exams if e.id == exam_id), None)
            
            if not exam:
                print(f"Continue exam - Exam {exam_id} not found")
                flash('考试不存在', 'error')
                return redirect(url_for('student.exams'))
                
            if not exam.is_active:
                print(f"Continue exam - Exam {exam_id} is not active")
                flash('考试已关闭', 'error')
                return redirect(url_for('student.exams'))
                
            print(f"Continue exam - Found exam: {exam.title}")
        except Exception as e:
            print(f"Continue exam - Error getting exam info: {e}")
            flash('获取考试信息失败', 'error')
            return redirect(url_for('student.exams'))
        
        # 🔥 关键修复：使用答案保存系统全面恢复答案和时间
        try:
            from answer_preservation_system import recover_answers_safely
            
            # 首先尝试从答案保存系统恢复
            recovery_result = recover_answers_safely(exam_id, student_info['id'], student_number)
            
            if recovery_result['success']:
                print(f"Continue exam - 答案保存系统恢复成功: {recovery_result['total_recovered']} 个答案")
                print(f"Continue exam - 恢复来源: {', '.join(recovery_result['recovery_sources'])}")
                
                progress_info = {
                    'answers': recovery_result['answers'],
                    'elapsed_minutes': recovery_result['elapsed_minutes'],
                    'start_time': recovery_result['original_start_time'] or datetime.now().isoformat()
                }
                
                flash(f'从多个备份源恢复了 {recovery_result["total_recovered"]} 个答案，完成度 {recovery_result["completion_rate"]:.1f}%', 'success')
                
            else:
                # 回退到传统方法
                print("Continue exam - 答案保存系统无数据，尝试传统方法")
                progress_info = db.get_exam_progress_by_student_number(exam_id, student_number)
                
                if not progress_info:
                    print("Continue exam - 传统方法也无数据，检查session备份")
                    
                    # 尝试从session恢复
                    progress_key = f'exam_{exam_id}_progress_{student_info["id"]}'
                    session_answers = session.get(progress_key, {})
                    
                    if session_answers:
                        print(f"Continue exam - Found session backup with {len(session_answers)} answers")
                        flash(f'从会话备份恢复了 {len(session_answers)} 个答案，请继续答题', 'info')
                        
                        # 重建简单的progress_info结构
                        progress_info = {
                            'answers': session_answers,
                            'elapsed_minutes': 5.0,  # 默认已用5分钟
                            'start_time': datetime.now().isoformat()
                        }
                    else:
                        print("Continue exam - No backup found, starting new exam")
                        flash('没有找到未完成的考试记录，将开始新的考试', 'warning')
                        return redirect(url_for('student.take_exam', exam_id=exam_id))
            
            # 检查是否超时
            elapsed_minutes = progress_info['elapsed_minutes']
            remaining_minutes = exam.duration_minutes - elapsed_minutes
            
            if remaining_minutes <= 0:
                print("Continue exam - Exam expired, cleaning up and starting new")
                flash('考试时间已过期，将开始新的考试', 'warning')
                # 清理过期进度
                db.clear_exam_progress_by_student_number(exam_id, student_number)
                return redirect(url_for('student.take_exam', exam_id=exam_id))
                
        except Exception as e:
            print(f"Continue exam - Error getting progress info: {e}")
            import traceback
            traceback.print_exc()
            
            # 如果是数据库表不存在的错误，给出明确提示
            if "no such table" in str(e).lower():
                flash('考试进度表不存在，请联系管理员，将开始新的考试', 'warning')
            else:
                flash('检查考试状态失败，将开始新的考试', 'warning')
            return redirect(url_for('student.take_exam', exam_id=exam_id))
        
        # 获取或创建考试结果记录
        try:
            # 检查是否有对应的exam_results记录
            incomplete_info = db.get_incomplete_exam_info(student_info['id'], exam_id)
            
            if incomplete_info:
                result_id = incomplete_info['result_id']
                print(f"Continue exam - Found existing result_id: {result_id}")
            else:
                # 创建新的exam_results记录
                result_id = db.start_exam(exam_id, student_info['id'])
                print(f"Continue exam - Created new result_id: {result_id}")
                
                if not result_id:
                    flash('无法创建考试记录', 'error')
                    return redirect(url_for('student.exams'))
            
            # 恢复考试状态到会话
            session['current_exam_result_id'] = result_id
            session['exam_start_time'] = progress_info['start_time']  # 使用原始开始时间
            session['current_student_id'] = student_info['id']
            session['student_id'] = student_info['id']  # 🔥 确保session中有student_id
            session['student_number'] = student_number  # 🔥 确保session中有student_number
            
            print(f"Continue exam - Restored session:")
            print(f"  Result ID: {result_id}")
            print(f"  Original start time: {progress_info['start_time']}")
            print(f"  Elapsed minutes: {elapsed_minutes:.1f}")
            print(f"  Remaining minutes: {remaining_minutes:.1f}")
            
        except Exception as e:
            print(f"Continue exam - Error setting session: {e}")
            flash('恢复考试状态失败，将开始新的考试', 'error')
            return redirect(url_for('student.take_exam', exam_id=exam_id))
        
        # 恢复已保存的答案
        saved_answers = progress_info['answers']
        
        print(f"Continue exam - Restored {len(saved_answers)} answers from progress table")
        
        # 获取考试题目
        try:
            questions = db.get_exam_questions(exam_id)
            
            if not questions:
                print("Continue exam - No questions found")
                flash('考试没有题目', 'error')
                return redirect(url_for('student.exams'))
                
            print(f"Continue exam - Got {len(questions)} questions")
            
        except Exception as e:
            print(f"Continue exam - Error getting questions: {e}")
            flash('获取考试题目失败', 'error')
            return redirect(url_for('student.exams'))
        
        # 格式化保存的答案，确保key格式正确
        formatted_answers = {}
        for key, value in saved_answers.items():
            # 确保key格式为 question_<id>
            if not key.startswith('question_'):
                if key.isdigit():
                    formatted_key = f'question_{key}'
                else:
                    formatted_key = key
            else:
                formatted_key = key
            formatted_answers[formatted_key] = value
        
        print(f"Continue exam - Total formatted answers: {len(formatted_answers)}")
        
        # 同时保存到session作为备份
        progress_key = f'exam_{exam_id}_progress_{student_info["id"]}'
        session[progress_key] = formatted_answers
        
        # 显示继续考试的提示信息
        try:
            if remaining_minutes > 0:
                flash(f'继续之前的考试，已用时 {int(elapsed_minutes)} 分钟，剩余 {int(remaining_minutes)} 分钟', 'info')
            else:
                flash('考试时间即将结束，请尽快完成', 'warning')
        except Exception as e:
            print(f"Continue exam - Error calculating time: {e}")
            flash('继续之前的考试', 'info')
        
        # 检测是否包含阅读理解题目并进行分组
        reading_passages, regular_questions = detect_and_group_reading_passages(questions)
        
        print(f"Continue exam - Questions breakdown:")
        print(f"  Reading passages: {len(reading_passages) if reading_passages else 0}")
        print(f"  Regular questions: {len(regular_questions) if regular_questions else len(questions)}")
        
        # 计算剩余时间（秒）- 这是关键，用于前端计时器
        remaining_seconds = max(0, int(remaining_minutes * 60))
        
        print(f"Continue exam - Remaining seconds for timer: {remaining_seconds}")
        
        return render_template('student/take_exam_new.html',
                             exam=exam,
                             questions=questions,
                             reading_passages=reading_passages,
                             regular_questions=regular_questions,
                             saved_answers=formatted_answers,
                             is_continuing=True,  # 标记为继续考试
                             remaining_seconds=remaining_seconds,  # 传递剩余秒数给前端
                             elapsed_minutes=int(elapsed_minutes),  # 已用时间
                             total_duration_minutes=exam.duration_minutes)  # 总时长
        
    except Exception as e:
        print(f"Continue exam error: {e}")
        import traceback
        traceback.print_exc()
        
        # 更详细的错误信息
        error_message = str(e)
        if "no such table" in error_message.lower():
            flash('数据库表不存在，请联系管理员初始化数据库', 'error')
        elif "database" in error_message.lower():
            flash('数据库连接失败，请稍后重试', 'error')
        else:
            flash(f'继续考试失败: {error_message}', 'error')
        
        return redirect(url_for('student.exams'))

@student_bp.route('/exam/<int:exam_id>/submit', methods=['POST'])
@login_required
def submit_exam(exam_id):
    """提交考试 - 使用队列机制的优化版本"""
    start_time = datetime.now()
    
    try:
        # 增强的会话验证
        if not current_user.is_authenticated:
            return jsonify({'success': False, 'message': '请先登录', 'redirect': url_for('auth.login')})
        
        student_info = current_user.get_student_info()
        if not student_info:
            return jsonify({'success': False, 'message': '会话已过期，请重新登录', 'redirect': url_for('auth.login')})
        
        student_id = student_info['id']
        student_number = student_info.get('student_id')
        
        if not student_id or not student_number:
            return jsonify({'success': False, 'message': '无法获取学生信息，请重新登录', 'redirect': url_for('auth.login')})
        
        # 获取考试信息
        db = Database()
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 收集答案
        answers = {}
        focus_lost_count = 0
        focus_lost_logs = '[]'
        
        if request.is_json:
            data = request.get_json()
            if data:
                answers = data
                focus_lost_count = int(data.get('focus_lost_count', 0))
                focus_lost_logs = str(data.get('focus_lost_logs', '[]'))
        else:
            # 从表单收集
            for key, value in request.form.items():
                if key.startswith('question_'):
                    answers[key] = value.strip()
            focus_lost_count = int(request.form.get('focus_lost_count', 0))
            focus_lost_logs = str(request.form.get('focus_lost_logs', '[]'))
        
        # 尝试更新最终的切屏数据
        if focus_lost_count > 0:
            try:
                db.update_exam_focus_monitoring(
                    exam_id=exam_id,
                    student_id=student_id,
                    focus_lost_count=focus_lost_count,
                    focus_lost_logs=focus_lost_logs
                )
            except Exception as e:
                print(f"⚠️ 提交时保存切屏数据失败: {e}")
        
        # 使用提交优化器进行提交
        print(f"[SUBMIT] Processing submission for Exam {exam_id}, Student {student_id}")
        optimizer = get_submission_optimizer()
        # 注意：submit_with_optimization 默认会延迟评分 (score=0, needs_grading=1)
        result = optimizer.submit_with_optimization(exam_id, student_id, student_number, answers)
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        # 如果是队列提交，返回特定状态
        if result.get('queued', False):
            return jsonify({
                'success': True,
                'queued': True,
                'message': '提交已加入队列，正在处理中...',
                'exam_id': exam_id,
                'student_id': student_id,
                'processing_time': processing_time
            })
            
        # 如果是同步完成（或优先提交），返回完整结果
        if result.get('success', False):
            return jsonify({
                'success': True,
                'queued': False,
                'message': '考试提交成功！等待教师评分',
                'result_id': result.get('result_id'),
                'score': result.get('score', 0),
                'total_score': result.get('total_score', 0),
                'percentage': result.get('percentage', 0),
                'answered_count': result.get('answered_count', 0),
                'total_questions': result.get('total_questions', 0),
                'processing_time': processing_time,
                'grading_status': result.get('grading_status', 'pending')
            })
        else:
            try:
                from answer_preservation_system import save_answers_safely, mark_final_submission
                exam_start_time = session.get('exam_start_time')
                elapsed_minutes = 0.0
                if exam_start_time:
                    try:
                        start_time = datetime.fromisoformat(exam_start_time)
                        elapsed_minutes = (datetime.now() - start_time).total_seconds() / 60
                    except Exception:
                        pass
                session_id = session.get('session_id', '')
                ip_address = request.remote_addr
                save_answers_safely(exam_id, student_id, student_number, answers, elapsed_minutes, 'final', session_id, ip_address)
                mark_final_submission(exam_id, student_id, student_number)
                return jsonify({
                    'success': True,
                    'queued': True,
                    'message': '提交已进入离线处理，稍后自动完成',
                    'exam_id': exam_id,
                    'student_id': student_id,
                    'processing_time': processing_time
                })
            except Exception:
                return jsonify({
                    'success': True,
                    'queued': True,
                    'message': '提交已进入离线处理，稍后自动完成',
                    'exam_id': exam_id,
                    'student_id': student_id,
                    'processing_time': processing_time
                })
        
    except Exception as e:
        processing_time = (datetime.now() - start_time).total_seconds()
        print(f"[ERROR] 提交考试失败: {e}, 时间: {processing_time:.2f}秒")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False, 
            'message': f'提交考试时发生错误: {str(e)}',
            'processing_time': processing_time
        })

@student_bp.route('/exam/<int:exam_id>/check_status')
@login_required
def check_submission_status(exam_id):
    """检查考试提交状态"""
    try:
        student_info = current_user.get_student_info()
        if not student_info:
            return jsonify({'success': False, 'message': '无法获取学生信息'})
            
        student_id = student_info['id']
        
        db = Database()
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, is_completed, score, total_score 
                FROM exam_results 
                WHERE exam_id = ? AND student_id = ? AND is_completed = 1
                ORDER BY id DESC LIMIT 1
            ''', (exam_id, student_id))
            
            row = cursor.fetchone()
            
            if row:
                # 找到已完成的记录
                return jsonify({
                    'success': True,
                    'status': 'completed',
                    'result_id': row[0],
                    'score': row[2],
                    'total_score': row[3]
                })
            else:
                # 未找到完成记录，可能还在队列中处理
                return jsonify({
                    'success': True,
                    'status': 'processing'
                })
                
    except Exception as e:
        print(f"[ERROR] 检查提交状态失败: {e}")
        return jsonify({'success': False, 'message': str(e)})


@student_bp.route('/exam/<int:exam_id>/save', methods=['POST'])
@login_required
def save_exam_progress(exam_id):
    """保存考试进度（自动保存）- 增强版，使用可靠性系统"""
    try:
        student_info = current_user.get_student_info()
        
        print(f"🔄 增强保存 - 学生: {student_info}, 考试: {exam_id}")
        
        if not student_info:
            print("❌ 无法获取学生信息")
            return jsonify({'success': False, 'message': '无法获取学生信息'})
        
        # 验证学生ID
        session_student_id = session.get('student_id')
        
        # 自动修复会话: 如果session中没有student_id或者不匹配，但current_user验证通过
        # 只要 Flask-Login 的 current_user 是可信的（已经通过认证），我们就以它为准
        if (session_student_id is None or session_student_id != student_info['id']) and student_info.get('id'):
            print(f"⚠️ 会话自动修复: 将 student_id 从 {session_student_id} 更新为 {student_info['id']}")
            session['student_id'] = student_info['id']
            session_student_id = student_info['id']
            
        # 二次检查（通常不会触发，除非上面的修复失败）
        if session_student_id != student_info['id']:
            print(f"❌ 学生ID不匹配且无法修复: session={session_student_id}, current={student_info['id']}")
            return jsonify({'success': False, 'message': '账号状态异常，请重新登录后再试'})
        
        # 获取提交的答案
        answers = {}
        try:
            if request.is_json:
                print("📥 处理JSON数据")
                data = request.get_json()
                if data:
                    answers = data
            else:
                print("📥 处理表单数据")
                for key, value in request.form.items():
                    if key.startswith('question_'):
                        question_id = key.replace('question_', '')
                        answers[question_id] = str(value).strip() if value else ''
            
            print(f"📥 收到 {len(answers)} 个答案")
            
        except Exception as e:
            print(f"❌ 数据处理失败: {e}")
            return jsonify({'success': False, 'message': '数据处理失败'})
        
        if not answers:
            return jsonify({'success': False, 'message': '没有有效的答案数据'})
        
        # 使用答案保存系统进行全面保存
        try:
            from answer_preservation_system import save_answers_safely
            
            student_id = student_info['id']
            student_number = student_info['student_id']
            
            # 计算已用时间与会话信息（在调用前准备）
            exam_start_time = session.get('exam_start_time')
            elapsed_minutes = 0.0
            if exam_start_time:
                try:
                    from datetime import datetime
                    start_time = datetime.fromisoformat(exam_start_time)
                    elapsed_minutes = (datetime.now() - start_time).total_seconds() / 60
                except Exception as e:
                    print(f"⚠️ 计算时间失败: {e}")
            
            session_id = session.get('session_id', '')
            ip_address = request.remote_addr
            user_agent = request.headers.get('User-Agent', '')
            
            # 全面保存答案到多个位置
            save_results = save_answers_safely(
                exam_id, student_id, student_number, answers, elapsed_minutes,
                'auto', session_id, ip_address
            )
            
            successful_saves = sum(save_results.values())
            
            print(f"✅ 答案保存系统: {successful_saves}/5 个位置成功")
            
        except Exception as e:
            print(f"⚠️ 答案保存系统失败，使用传统方法: {e}")
            # 如果答案保存系统失败，回退到传统方法
            successful_saves = 0
        
        # 提取切屏监控数据
        focus_lost_count = 0
        focus_lost_logs = '[]'
        
        try:
            if request.is_json:
                data = request.get_json()
                if data:
                    focus_lost_count = int(data.get('focus_lost_count', 0))
                    focus_lost_logs = str(data.get('focus_lost_logs', '[]'))
            else:
                focus_lost_count = int(request.form.get('focus_lost_count', 0))
                focus_lost_logs = str(request.form.get('focus_lost_logs', '[]'))
                
            if focus_lost_count > 0:
                print(f"👀 收到切屏数据: 次数={focus_lost_count}")
        except Exception as e:
            print(f"⚠️ 解析切屏数据失败: {e}")

        # 传统数据库保存（作为备份）
        
        db = Database()
        
        # 保存切屏监控数据到数据库
        if focus_lost_count > 0:
            try:
                db.update_exam_focus_monitoring(
                    exam_id=exam_id,
                    student_id=student_info['id'],
                    focus_lost_count=focus_lost_count,
                    focus_lost_logs=focus_lost_logs
                )
                print(f"✅ 切屏数据已更新到数据库")
            except Exception as e:
                print(f"⚠️ 保存切屏数据失败: {e}")
        
        db_success = db.save_exam_progress_by_student_number(
            exam_id=exam_id,
            student_number=student_info['student_id'],
            student_name=student_info['name'],
            answers=answers,
            elapsed_minutes=elapsed_minutes,
            session_id=session_id,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        # Session备份
        session_success = False
        try:
            progress_key = f'exam_{exam_id}_progress_{student_info["id"]}'
            session[progress_key] = answers
            session_success = True
            print(f"✅ Session备份成功: {progress_key}")
        except Exception as e:
            print(f"⚠️ Session备份失败: {e}")
        
        # 更新会话活动时间
        try:
            if session_id:
                db.update_student_session_activity(session_id)
        except Exception as e:
            print(f"⚠️ 更新会话活动时间失败: {e}")
        
        # 判断保存成功情况
        total_success = successful_saves + (1 if db_success else 0) + (1 if session_success else 0)
        
        if total_success > 0:
            return jsonify({
                'success': True, 
                'message': f'进度已保存到{total_success}个位置',
                'saved_count': len(answers),
                'elapsed_minutes': round(elapsed_minutes, 1),
                'timestamp': datetime.now().isoformat(),
                'backup_status': {
                    'reliability_system': successful_saves > 0,
                    'database': db_success,
                    'session': session_success,
                    'total_backups': total_success
                }
            })
        else:
            return jsonify({'success': False, 'message': '所有保存方式均失败，请重试或重新登录；系统已记录错误'})
        
    except Exception as e:
        print(f"❌ 保存考试进度错误: {e}")
        import traceback
        traceback.print_exc()
        
        try:
            return jsonify({'success': False, 'message': f'保存进度失败: {str(e)}'})
        except:
            return "保存进度失败", 500

@student_bp.route('/results')
@login_required
def results():
    """学生成绩页面"""
    try:
        db = Database()
        student_info = current_user.get_student_info()
        
        if not student_info:
            flash('无法获取学生信息', 'error')
            return redirect(url_for('auth.login'))
        
        # 获取学生的所有考试记录
        exam_history = db.get_student_completed_exams(student_info['id'])
        
        # 获取考试详细信息 - 只显示已完成的考试
        detailed_results = []
        for history in exam_history:
            if history.get('is_completed', False):
                # 获取题目详细得分
                question_details = db.get_student_question_details(
                    student_info['id'], 
                    history['exam_id']
                )
                
                # 计算正确的统计数据
                total_questions = len(question_details)
                correct_count = sum(1 for q in question_details if q.get('is_correct', False))
                
                # 检查是否已经评分完成
                # 客观题（选择题、判断题）在提交时就已评分
                # 主观题需要检查是否有手动评分或AI评分
                objective_types = ['choice', 'judge']
                
                objective_questions = [q for q in question_details if q.get('question_type') in objective_types]
                subjective_questions = [q for q in question_details if q.get('question_type') not in objective_types]
                
                # 客观题总是被认为已评分（在提交时就评分了）
                objective_graded = len(objective_questions) > 0
                
                # 主观题需要检查是否有实际得分
                subjective_graded = len(subjective_questions) == 0 or any(
                    q.get('score', 0) > 0 or q.get('is_manually_graded', False) for q in subjective_questions
                )
                
                # 如果有客观题或主观题已评分，则认为考试有评分
                has_scores = objective_graded or subjective_graded or (history.get('score', 0) > 0)
                
                result = {
                    'exam_id': history['exam_id'],
                    'exam_title': history.get('exam_title', '未知考试'),
                    'score': history.get('score', 0),
                    'total_score': history.get('total_score', 100),  # 添加total_score字段
                    'total_questions': total_questions,              # 使用正确计算的统计数据
                    'correct_count': correct_count,                  # 使用正确计算的统计数据
                    'start_time': history.get('start_time'),
                    'end_time': history.get('end_time'),
                    'question_details': question_details,
                    'is_graded': has_scores  # 标记是否已评分
                }
                detailed_results.append(result)
        
        # 排序（最新的在前面）
        detailed_results.sort(key=lambda x: x.get('start_time', ''), reverse=True)
        
        return render_template('student/results.html',
                             exam_results=detailed_results,
                             student_info=student_info)
                             
    except Exception as e:
        print(f"Student results error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载成绩数据时发生错误', 'error')
        return render_template('student/results.html',
                             exam_results=[],
                             student_info={})

@student_bp.route('/profile')
@login_required
def profile():
    """学生个人信息页面"""
    try:
        student_info = current_user.get_student_info()
        
        if not student_info:
            flash('无法获取学生信息', 'error')
            return redirect(url_for('auth.login'))
        
        # 获取统计信息
        db = Database()
        exam_history = db.get_student_exam_history(student_info['id'])
        
        # 计算统计数据
        total_exams = len(exam_history)
        completed_exams = len([h for h in exam_history if h.get('is_completed', False)])
        average_score = 0
        if completed_exams > 0:
            total_score = sum(h.get('score', 0) for h in exam_history if h.get('is_completed', False))
            average_score = total_score / completed_exams
        
        best_score = max([h.get('score', 0) for h in exam_history if h.get('is_completed', False)], default=0)
        
        return render_template('student/profile.html',
                             student_info=student_info,
                             total_exams=total_exams,
                             completed_exams=completed_exams,
                             average_score=average_score,
                             best_score=best_score)
                             
    except Exception as e:
        print(f"Student profile error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载个人信息时发生错误', 'error')
        return render_template('student/profile.html',
                             student_info={},
                             total_exams=0,
                             completed_exams=0,
                             average_score=0,
                             best_score=0)

@student_bp.route('/profile/update', methods=['POST'])
@login_required
def update_profile():
    """更新学生个人信息"""
    try:
        db = Database()
        student_info = current_user.get_student_info()
        
        if not student_info:
            return jsonify({'success': False, 'message': '无法获取学生信息'})
        
        # 获取学生对象
        student = db.get_student_by_id(student_info['student_id'])
        if not student:
            return jsonify({'success': False, 'message': '学生不存在'})
        
        # 更新可编辑的字段（通常只允许更新少数字段）
        new_password = request.form.get('new_password')
        if new_password:
            student.password = new_password
            
        # 更新数据库
        if db.update_student(student):
            return jsonify({'success': True, 'message': '个人信息更新成功'})
        else:
            return jsonify({'success': False, 'message': '更新失败'})
            
    except Exception as e:
        print(f"Update profile error: {e}")
        return jsonify({'success': False, 'message': f'更新个人信息失败: {str(e)}'})

@student_bp.route('/exam/<int:exam_id>/result')
@login_required
def exam_result_detail(exam_id):
    """查看特定考试的详细结果（保护题目和答案隐私）"""
    try:
        db = Database()
        student_info = current_user.get_student_info()
        
        if not student_info:
            flash('无法获取学生信息', 'error')
            return redirect(url_for('auth.login'))
        
        # 获取学生的这次考试详情
        exam_history = db.get_student_exam_history(student_info['id'])
        exam_result = next((h for h in exam_history if h['exam_id'] == exam_id), None)
        
        if not exam_result or not exam_result.get('is_completed', False):
            flash('考试结果不存在或未完成', 'error')
            return redirect(url_for('student.results'))
        
        # 获取题目详细得分 - 但移除敏感信息
        question_details = db.get_student_question_details(
            student_info['id'], 
            exam_id
        )
        
        # 先计算统计数据（基于原始数据）
        total_questions = len(question_details)
        correct_count = sum(1 for q in question_details if q.get('is_correct', False))
        
        print(f"Debug - 学生 {student_info['id']} 考试 {exam_id} 统计:")
        print(f"  总题数: {total_questions}")
        print(f"  答对题数: {correct_count}")
        print(f"  正确率: {correct_count/total_questions*100 if total_questions > 0 else 0:.1f}%")
        
        # 过滤题目详情，移除题目内容和答案
        filtered_question_details = []
        for detail in question_details:
            filtered_detail = {
                'question_order': detail.get('question_order'),
                'question_type': detail.get('question_type'),
                'score': detail.get('score', 0),
                'max_score': detail.get('max_score', 1),
                'is_correct': detail.get('is_correct', False),
                # 移除敏感字段：
                # 'question_text' - 题目内容
                # 'student_answer' - 学生答案
                # 'correct_answer' - 正确答案
            }
            filtered_question_details.append(filtered_detail)
        
        # 获取考试信息 - 也移除敏感信息
        exams = db.get_exams()
        exam = next((e for e in exams if e.id == exam_id), None)
        
        # 创建过滤后的考试信息
        if exam:
            filtered_exam = {
                'id': exam.id,
                'title': exam.title,
                'duration_minutes': exam.duration_minutes,
                'total_questions': exam.total_questions,
                'total_score': exam.total_score,
                # 移除敏感字段：
                # 'description' - 可能包含提示信息
            }
        else:
            filtered_exam = None
        
        return render_template('student/exam_result_detail_secure.html',
                             exam=filtered_exam,
                             exam_result=exam_result,
                             question_details=filtered_question_details,
                             total_questions=total_questions,  # 使用正确计算的统计数据
                             correct_count=correct_count)      # 使用正确计算的统计数据
                             
    except Exception as e:
        print(f"Exam result detail error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载考试详情时发生错误', 'error')
        return redirect(url_for('student.results'))

@student_bp.route('/exam-status/<int:exam_id>')
@login_required
def exam_status(exam_id):
    """检查考试状态（用于前端定时检查）- 全面改进版"""
    try:
        student_info = current_user.get_student_info()
        if not student_info:
            return jsonify({'success': False, 'message': '无法获取学生信息'})
        
        db = Database()
        
        # 获取考试信息
        exams = db.get_exams()
        exam = next((e for e in exams if e.id == exam_id), None)
        
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        # 🔥 全面改进的考试状态检查逻辑
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. 获取学生学号
            cursor.execute('''
                SELECT student_id FROM students WHERE id = ?
            ''', (student_info['id'],))
            student_row = cursor.fetchone()
            
            if not student_row:
                return jsonify({'success': False, 'message': '学生信息不存在'})
            
            student_number = student_row[0]
            
            # 2. 检查考试结果记录
            cursor.execute('''
                SELECT is_completed, id, score, total_score FROM exam_results 
                WHERE student_id = ? AND exam_id = ?
                ORDER BY id DESC LIMIT 1
            ''', (student_info['id'], exam_id))
            exam_result = cursor.fetchone()
            
            # 3. 检查考试进度记录（包括活跃状态）
            cursor.execute('''
                SELECT is_active, answer_data, start_time FROM exam_progress 
                WHERE exam_id = ? AND student_number = ?
                ORDER BY last_save_time DESC LIMIT 1
            ''', (exam_id, student_number))
            progress_record = cursor.fetchone()
            
            # 4. 🔥 关键改进：更智能的状态判断逻辑
            is_completed = False
            can_take_exam = True
            status_reason = ""
            
            if exam_result and progress_record:
                # 同时有考试结果和进度记录
                is_completed_in_db = bool(exam_result[0])
                has_active_progress = bool(progress_record[0])
                
                if is_completed_in_db and not has_active_progress:
                    # 已完成且没有活跃进度 = 真正完成
                    is_completed = True
                    can_take_exam = False
                    status_reason = "考试已完成"
                elif has_active_progress:
                    # 有活跃进度 = 可以继续考试（无论之前是否完成）
                    is_completed = False
                    can_take_exam = True
                    status_reason = "可以继续考试" if is_completed_in_db else "考试进行中"
                else:
                    # 已完成但进度记录不活跃 = 需要检查是否允许继续
                    is_completed = is_completed_in_db
                    can_take_exam = not is_completed_in_db
                    status_reason = "考试已完成" if is_completed_in_db else "可以开始考试"
                    
            elif exam_result and not progress_record:
                # 只有考试结果，没有进度记录
                is_completed_in_db = bool(exam_result[0])
                is_completed = is_completed_in_db
                can_take_exam = not is_completed_in_db
                status_reason = "考试已完成" if is_completed_in_db else "可以开始考试"
                
            elif not exam_result and progress_record:
                # 只有进度记录，没有考试结果
                has_active_progress = bool(progress_record[0])
                is_completed = False
                can_take_exam = True
                status_reason = "考试进行中"
                
            else:
                # 既没有考试结果也没有进度记录
                is_completed = False
                can_take_exam = True
                status_reason = "可以开始考试"
            
            print(f"考试状态检查 - 学生ID: {student_info['id']}, 学号: {student_number}, 考试ID: {exam_id}")
            print(f"  考试结果: {exam_result}")
            print(f"  进度记录: {progress_record}")
            print(f"  最终判断已完成: {is_completed}")
            print(f"  可以参加考试: {can_take_exam}")
            print(f"  状态原因: {status_reason}")
        
        return jsonify({
            'success': True,
            'is_completed': is_completed,
            'can_take_exam': can_take_exam,
            'is_active': exam.is_active,
            'exam_title': exam.title,
            'status_reason': status_reason
        })
        
    except Exception as e:
        print(f"Check exam status error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'检查考试状态失败: {str(e)}'})

@student_bp.route('/exam/result/<int:result_id>')
@login_required
def exam_result(result_id):
    """显示考试结果 - 支持按分值显示"""
    try:
        student_id = session.get('student_id')
        if not student_id:
            flash('请先登录', 'error')
            return redirect(url_for('auth.student_login'))
        
        # 获取考试结果
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT er.*, e.title, e.description, e.total_score as exam_total_score
                FROM exam_results er
                JOIN exams e ON er.exam_id = e.id
                WHERE er.id = ? AND er.student_id = ?
            ''', (result_id, student_id))
            
            result_row = cursor.fetchone()
            if not result_row:
                flash('考试结果不存在', 'error')
                return redirect(url_for('student.exams'))
            
            # 获取题目得分详情
            cursor.execute('''
                SELECT * FROM question_scores 
                WHERE exam_result_id = ?
                ORDER BY question_order
            ''', (result_id,))
            
            question_scores = cursor.fetchall()
        
        # 计算统计信息
        total_questions = len(question_scores)
        correct_count = sum(1 for qs in question_scores if qs[6])  # is_correct字段
        accuracy = (correct_count / total_questions * 100) if total_questions > 0 else 0
        
        exam_result_data = {
            'id': result_row[0],
            'exam_title': result_row[9],
            'exam_description': result_row[10],
            'score': result_row[4],
            'total_score': result_row[5],
            'exam_total_score': result_row[11],
            'percentage': (result_row[4] / result_row[5] * 100) if result_row[5] > 0 else 0,
            'start_time': result_row[6],
            'end_time': result_row[7],
            'total_questions': total_questions,
            'correct_count': correct_count,
            'accuracy': accuracy
        }
        
        return render_template('student/exam_result.html', 
                             exam_result=exam_result_data,
                             question_scores=question_scores)
        
    except Exception as e:
        print(f"显示考试结果失败: {e}")
        traceback.print_exc()
        flash('显示考试结果时发生错误', 'error')
        return redirect(url_for('student.exams')) 
