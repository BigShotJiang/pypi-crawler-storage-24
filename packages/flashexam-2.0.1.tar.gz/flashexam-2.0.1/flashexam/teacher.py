from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import login_required, current_user
import os
import pandas as pd
import csv
import io
from datetime import datetime
from werkzeug.utils import secure_filename
from urllib.parse import unquote
import json

from .database import Database
from .models import Student, Question, Exam, QuestionScore, ExamResult
from .utils import parse_csv_students

# 为了兼容性，创建get_db函数
def get_db():
    """获取数据库实例"""
    return Database()

teacher_bp = Blueprint('teacher', __name__)

def create_csv_response(csv_content, filename_base, encoding='utf-8'):
    """
    创建CSV导出响应，支持UTF-8和GBK编码选择
    
    Args:
        csv_content: CSV内容字符串
        filename_base: 文件名基础部分（不含扩展名）
        encoding: 编码类型，'utf-8' 或 'gbk'
    
    Returns:
        Flask响应对象
    """
    try:
        # 根据编码选择处理文件内容
        if encoding == 'gbk':
            try:
                csv_bytes = csv_content.encode('gbk')
                encoding_suffix = '_GBK'
                print(f"使用GBK编码成功")
            except UnicodeEncodeError as e:
                print(f"GBK编码失败，回退到UTF-8: {e}")
                # 如果GBK编码失败，回退到UTF-8
                csv_bytes = csv_content.encode('utf-8-sig')
                encoding_suffix = '_UTF8'
        else:
            csv_bytes = csv_content.encode('utf-8-sig')
            encoding_suffix = '_UTF8'
            print(f"使用UTF-8编码")
        
        # 生成文件名
        filename = f'{filename_base}{encoding_suffix}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        print(f"生成文件名: {filename}")
        
        # 创建响应
        response = send_file(
            io.BytesIO(csv_bytes),
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )
        
        return response
        
    except Exception as e:
        print(f"创建CSV响应失败: {e}")
        raise

@teacher_bp.before_request
def require_teacher():
    """确保只有教师可以访问教师端"""
    if not current_user.is_authenticated or not current_user.is_teacher():
        flash('您需要教师权限才能访问此页面', 'error')
        return redirect(url_for('auth.login'))

@teacher_bp.route('/dashboard')
@login_required
def dashboard():
    """教师仪表板"""
    try:
        db = Database()
        
        # 获取统计数据
        students_count = len(db.get_all_students())
        questions_count = db.get_questions_count()
        exams_count = len(db.get_exams())
        
        # 获取最近的考试结果
        try:
            recent_results = db.get_exam_results()[:5]  # 最近5条结果
            
            # 确保数据格式正确
            processed_results = []
            for result in recent_results:
                if isinstance(result, dict):
                    processed_results.append(result)
                else:
                    # 如果是对象，转换为字典
                    processed_results.append({
                        'id': getattr(result, 'id', 0),
                        'exam_id': getattr(result, 'exam_id', 0),
                        'student_id': getattr(result, 'student_id', 0),
                        'score': getattr(result, 'score', 0.0),
                        'is_completed': getattr(result, 'is_completed', False),
                        'start_time': getattr(result, 'start_time', None),
                        'end_time': getattr(result, 'end_time', None),
                        'exam_title': getattr(result, 'exam_title', ''),
                        'student_name': getattr(result, 'student_name', ''),
                        'student_number': getattr(result, 'student_number', ''),
                    })
            
            recent_results = processed_results
            
        except Exception as results_error:
            print(f"获取最近考试结果失败: {results_error}")
            recent_results = []
        
        return render_template('teacher/dashboard.html',
                             students_count=students_count,
                             questions_count=questions_count,
                             exams_count=exams_count,
                             recent_results=recent_results)
    except Exception as e:
        print(f"Dashboard error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载仪表板数据时发生错误', 'error')
        return render_template('teacher/dashboard.html',
                             students_count=0,
                             questions_count=0,
                             exams_count=0,
                             recent_results=[])

@teacher_bp.route('/students')
@login_required  
def students():
    """学生管理页面"""
    try:
        db = Database()
        students = db.get_all_students()
        
        # 按学院分组统计
        college_stats = {}
        for student in students:
            college = student.college or '未设置'
            if college not in college_stats:
                college_stats[college] = 0
            college_stats[college] += 1
        
        return render_template('teacher/students.html',
                             students=students,
                             college_stats=college_stats)
    except Exception as e:
        print(f"Students page error: {e}")
        flash('加载学生数据时发生错误', 'error')
        return render_template('teacher/students.html', students=[], college_stats={})

@teacher_bp.route('/students/add', methods=['POST'])
@login_required
def add_student():
    """添加学生"""
    try:
        db = Database()
        
        # 获取表单数据
        student_id = request.form.get('student_id')
        name = request.form.get('name')
        college = request.form.get('college', '')
        major = request.form.get('major', '')
        class_name = request.form.get('class_name', '')
        gender = request.form.get('gender', '')
        password = request.form.get('password') or student_id  # 默认密码为学号
        
        # 验证必填字段
        if not student_id or not name:
            return jsonify({'success': False, 'message': '学号和姓名不能为空'})
        
        # 检查学生是否已存在
        if db.check_student_exists(student_id):
            return jsonify({'success': False, 'message': '该学号已存在'})
        
        # 创建学生对象
        student = Student(
            student_id=student_id,
            name=name,
            password=password,
            college=college,
            major=major,
            class_name=class_name,
            gender=gender
        )
        
        # 添加到数据库
        db.add_student(student)
        
        return jsonify({'success': True, 'message': '学生添加成功'})
        
    except Exception as e:
        print(f"Add student error: {e}")
        return jsonify({'success': False, 'message': f'添加学生失败: {str(e)}'})

@teacher_bp.route('/students/edit/<student_id>', methods=['POST'])
@login_required
def edit_student(student_id):
    """编辑学生信息"""
    try:
        db = Database()
        
        # 获取现有学生信息
        student = db.get_student_by_id(student_id)
        if not student:
            return jsonify({'success': False, 'message': '学生不存在'})
        
        # 更新信息
        student.name = request.form.get('name', student.name)
        student.college = request.form.get('college', student.college)
        student.major = request.form.get('major', student.major)
        student.class_name = request.form.get('class_name', student.class_name)
        student.gender = request.form.get('gender', student.gender)
        
        # 如果提供了新密码，则更新密码
        new_password = request.form.get('password')
        if new_password:
            student.password = new_password
        
        # 更新数据库
        if db.update_student(student):
            return jsonify({'success': True, 'message': '学生信息更新成功'})
        else:
            return jsonify({'success': False, 'message': '更新失败'})
            
    except Exception as e:
        print(f"Edit student error: {e}")
        return jsonify({'success': False, 'message': f'编辑学生失败: {str(e)}'})

@teacher_bp.route('/students/delete/<student_id>', methods=['POST'])
@login_required
def delete_student(student_id):
    """删除学生"""
    try:
        db = Database()
        
        if db.delete_student(student_id):
            return jsonify({'success': True, 'message': '学生删除成功'})
        else:
            return jsonify({'success': False, 'message': '删除失败，学生不存在'})
            
    except Exception as e:
        print(f"Delete student error: {e}")
        return jsonify({'success': False, 'message': f'删除学生失败: {str(e)}'})

@teacher_bp.route('/students/import', methods=['POST'])
@login_required
def import_students():
    """导入学生数据"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        if not file.filename.lower().endswith('.csv'):
            return jsonify({'success': False, 'message': '只支持CSV文件'})
        
        # 读取文件内容
        file_content = file.read()
        skip_duplicates = request.form.get('skip_duplicates') == 'true'
        
        # 解析CSV
        students, errors = parse_csv_students(file_content, file.filename)
        
        if errors:
            return jsonify({'success': False, 'message': f'解析错误: {", ".join(errors)}'})
        
        # 导入数据库
        db = Database()
        success_count = 0
        error_count = 0
        duplicates = []
        
        for student in students:
            try:
                if db.check_student_exists(student.student_id):
                    if skip_duplicates:
                        duplicates.append(student.student_id)
                        continue
                    else:
                        error_count += 1
                        continue
                
                db.add_student(student)
                success_count += 1
            except Exception as e:
                print(f"Import student error: {e}")
                error_count += 1
        
        message = f'成功导入 {success_count} 个学生'
        if duplicates:
            message += f'，跳过重复学号 {len(duplicates)} 个'
        if error_count > 0:
            message += f'，失败 {error_count} 个'
        
        return jsonify({'success': True, 'message': message})
        
    except Exception as e:
        print(f"Import students error: {e}")
        return jsonify({'success': False, 'message': f'导入失败: {str(e)}'})

@teacher_bp.route('/students/export')
@login_required
def export_students():
    """导出学生数据"""
    try:
        # 获取编码参数
        encoding = request.args.get('encoding', 'utf-8')  # utf-8 或 gbk
        
        db = Database()
        students = db.get_all_students()
        
        if not students:
            flash('暂无学生数据可导出', 'warning')
            return redirect(url_for('teacher.students'))
        
        # 创建CSV内容
        output = io.StringIO()
        writer = csv.writer(output)
        
        # 写入表头
        writer.writerow(['学号', '姓名', '学院', '专业', '班级', '性别', '备注', '创建时间'])
        
        # 写入数据
        for student in students:
            # 处理日期格式：如果是字符串就直接使用，如果是datetime对象则格式化
            created_at_str = ''
            if student.created_at:
                if isinstance(student.created_at, str):
                    created_at_str = student.created_at
                else:
                    # 如果是datetime对象，则格式化
                    created_at_str = student.created_at.strftime('%Y-%m-%d %H:%M:%S')
            
            writer.writerow([
                student.student_id,
                student.name,
                student.college or '',
                student.major or '',
                student.class_name or '',
                student.gender or '',
                student.notes or '',
                created_at_str
            ])
        
        # 准备下载
        output.seek(0)
        csv_data = output.getvalue()
        output.close()
        
        # 使用通用函数创建响应
        return create_csv_response(csv_data, 'students', encoding)
        
    except Exception as e:
        print(f"Export students error: {e}")
        flash('导出学生数据失败', 'error')
        return redirect(url_for('teacher.students'))

@teacher_bp.route('/students/clear', methods=['POST'])
@login_required
def clear_all_students():
    """清空所有学生数据"""
    try:
        db = Database()
        deleted_count = db.delete_all_students()
        
        return jsonify({'success': True, 'message': f'已清空 {deleted_count} 个学生'})
        
    except Exception as e:
        print(f"Clear students error: {e}")
        return jsonify({'success': False, 'message': f'清空失败: {str(e)}'})

@teacher_bp.route('/students/get/<student_id>')
@login_required
def get_student(student_id):
    """获取学生信息（用于编辑表单）"""
    try:
        db = Database()
        student = db.get_student_by_id(student_id)
        
        if not student:
            return jsonify({'success': False, 'message': '学生不存在'})
        
        return jsonify({
            'success': True,
            'student': {
                'student_id': student.student_id,
                'name': student.name,
                'college': student.college or '',
                'major': student.major or '',
                'class_name': student.class_name or '',
                'gender': student.gender or '',
                'notes': student.notes or ''
            }
        })
        
    except Exception as e:
        print(f"Get student error: {e}")
        return jsonify({'success': False, 'message': f'获取学生信息失败: {str(e)}'})

@teacher_bp.route('/students/batch-delete', methods=['POST'])
@login_required
def batch_delete_students():
    """批量删除学生"""
    try:
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择要删除的学生'})
        
        db = Database()
        success_count = 0
        failed_count = 0
        failed_students = []
        
        for student_id in student_ids:
            try:
                if db.delete_student(student_id):
                    success_count += 1
                else:
                    failed_count += 1
                    failed_students.append(student_id)
            except Exception as e:
                print(f"Delete student {student_id} error: {e}")
                failed_count += 1
                failed_students.append(student_id)
        
        message = f'成功删除 {success_count} 名学生'
        if failed_count > 0:
            message += f'，失败 {failed_count} 名'
            if failed_students:
                message += f'（失败学号: {", ".join(failed_students[:3])}{"等" if len(failed_students) > 3 else ""}）'
        
        return jsonify({
            'success': True,
            'message': message,
            'deleted': success_count,
            'failed': failed_count
        })
        
    except Exception as e:
        print(f"Batch delete students error: {e}")
        return jsonify({'success': False, 'message': f'批量删除失败: {str(e)}'})

@teacher_bp.route('/students/export-selected', methods=['POST'])
@login_required
def export_selected_students():
    """导出选中的学生数据"""
    try:
        student_ids = request.form.getlist('student_ids')
        encoding = request.form.get('encoding', 'utf-8')  # 从表单获取编码选择
        
        if not student_ids:
            flash('没有选择要导出的学生', 'error')
            return redirect(url_for('teacher.students'))
        
        db = Database()
        students = []
        
        # 获取选中的学生数据
        for student_id in student_ids:
            student = db.get_student_by_id(student_id)
            if student:
                students.append(student)
        
        if not students:
            flash('没有找到要导出的学生数据', 'error')
            return redirect(url_for('teacher.students'))
        
        # 创建CSV内容
        output = io.StringIO()
        writer = csv.writer(output)
        
        # 写入表头
        writer.writerow(['学号', '姓名', '学院', '专业', '班级', '性别', '备注', '创建时间'])
        
        # 写入选中学生的数据
        for student in students:
            # 处理日期格式
            created_at_str = ''
            if student.created_at:
                if isinstance(student.created_at, str):
                    created_at_str = student.created_at
                else:
                    created_at_str = student.created_at.strftime('%Y-%m-%d %H:%M:%S')
            
            writer.writerow([
                student.student_id,
                student.name,
                student.college or '',
                student.major or '',
                student.class_name or '',
                student.gender or '',
                student.notes or '',
                created_at_str
            ])
        
        # 准备下载
        output.seek(0)
        csv_data = output.getvalue()
        output.close()
        
        # 使用通用函数创建响应
        return create_csv_response(csv_data, f'selected_students_{len(students)}', encoding)
        
    except Exception as e:
        print(f"Export selected students error: {e}")
        flash('导出选中学生数据失败', 'error')
        return redirect(url_for('teacher.students'))

@teacher_bp.route('/questions')
@login_required
def questions():
    """题目管理页面"""
    try:
        db = Database()
        questions = db.get_questions()
        import_batches = db.get_import_batches()
        
        # 按类型分组统计
        type_stats = {}
        for question in questions:
            q_type = question.question_type
            if q_type not in type_stats:
                type_stats[q_type] = 0
            type_stats[q_type] += 1
        
        return render_template('teacher/questions.html',
                             questions=questions,
                             type_stats=type_stats,
                             import_batches=import_batches)
    except Exception as e:
        print(f"Questions page error: {e}")
        flash('加载题目数据时发生错误', 'error')
        return render_template('teacher/questions.html', questions=[], type_stats={}, import_batches=[])

@teacher_bp.route('/questions/<int:question_id>', methods=['GET'])
@login_required
def get_question_detail(question_id):
    """获取题目详情"""
    try:
        db = Database()
        question = db.get_question_by_id(question_id)
        
        if not question:
            return jsonify({'success': False, 'message': '题目不存在'})
            
        # Parse options if it's a choice question
        options = {}
        if question.question_type == 'choice' and question.options:
            try:
                # Assuming options is stored as a string representation of a dict or similar
                # Check if it's valid JSON-like or eval-safe
                if isinstance(question.options, str):
                    # It might be stored as "{'A': '...', ...}"
                    import ast
                    options = ast.literal_eval(question.options)
                else:
                    options = question.options
            except:
                options = {}

        return jsonify({
            'success': True,
            'question': {
                'id': question.id,
                'question_type': question.question_type,
                'question_text': question.question_text,
                'correct_answer': question.correct_answer,
                'difficulty': question.difficulty,
                'subject': question.subject,
                'score': question.score,
                'options': options,
                'material': getattr(question, 'material', ''),
                'import_batch': getattr(question, 'import_batch', '')
            }
        })
    except Exception as e:
        print(f"Get question detail error: {e}")
        return jsonify({'success': False, 'message': f'获取题目详情失败: {str(e)}'})

@teacher_bp.route('/questions/edit/<int:question_id>', methods=['POST'])
@login_required
def edit_question(question_id):
    """编辑题目"""
    try:
        db = Database()
        
        # 获取现有题目信息
        questions = db.get_questions()
        question = next((q for q in questions if q.id == question_id), None)
        
        if not question:
            return jsonify({'success': False, 'message': '题目不存在'})
        
        # 更新信息
        question.question_type = request.form.get('question_type', question.question_type)
        question.question_text = request.form.get('question_text', question.question_text)
        question.correct_answer = request.form.get('correct_answer', question.correct_answer)
        question.difficulty = int(request.form.get('difficulty', question.difficulty))
        question.subject = request.form.get('subject', question.subject)
        question.material = request.form.get('material', getattr(question, 'material', ''))  # 新增material字段支持
        
        # 处理选择题选项
        if question.question_type == 'choice':
            options = {
                'A': request.form.get('option_A', ''),
                'B': request.form.get('option_B', ''),
                'C': request.form.get('option_C', ''),
                'D': request.form.get('option_D', '')
            }
            question.options = str(options)
        
        # 更新数据库（这里可能需要扩展Database类添加update_question方法）
        # 作为临时方案，我们先删除再添加
        db.delete_question(question_id)
        new_id = db.add_question(question)
        
        return jsonify({'success': True, 'message': '题目更新成功', 'new_question_id': new_id})
        
    except Exception as e:
        print(f"Edit question error: {e}")
        return jsonify({'success': False, 'message': f'编辑题目失败: {str(e)}'})

@teacher_bp.route('/questions/delete/<int:question_id>', methods=['POST'])
@login_required
def delete_question(question_id):
    """删除题目"""
    try:
        db = Database()
        
        if db.delete_question(question_id):
            return jsonify({'success': True, 'message': '题目删除成功'})
        else:
            return jsonify({'success': False, 'message': '删除失败，题目不存在'})
            
    except Exception as e:
        print(f"Delete question error: {e}")
        return jsonify({'success': False, 'message': f'删除题目失败: {str(e)}'})

@teacher_bp.route('/questions/add', methods=['POST'])
@login_required
def add_question():
    """添加新题目"""
    try:
        db = Database()
        
        # 从表单获取数据
        question_type = request.form.get('question_type', 'choice')
        subject = request.form.get('subject', '未分类')
        question_text = request.form.get('question_text', '')
        correct_answer = request.form.get('correct_answer', '')
        try:
            score = float(request.form.get('score', 5.0))
        except ValueError:
            score = 5.0
            
        try:
            difficulty = int(request.form.get('difficulty', 1))
        except ValueError:
            difficulty = 1
            
        material = request.form.get('material', '')
        
        options = ""
        if question_type == 'choice':
            options_dict = {
                'A': request.form.get('option_A', ''),
                'B': request.form.get('option_B', ''),
                'C': request.form.get('option_C', ''),
                'D': request.form.get('option_D', '')
            }
            options = str(options_dict)
            
        # 创建题目对象
        question = Question(
            question_type=question_type,
            question_text=question_text,
            options=options,
            correct_answer=correct_answer,
            score=score,
            difficulty=difficulty,
            subject=subject,
            material=material,
            import_batch=f"manual_{datetime.now().strftime('%Y%m%d')}"
        )
        
        # 添加到数据库
        new_id = db.add_question(question)
        
        return jsonify({'success': True, 'message': '题目添加成功', 'question_id': new_id})
        
    except Exception as e:
        print(f"Add question error: {e}")
        return jsonify({'success': False, 'message': f'添加题目失败: {str(e)}'})

@teacher_bp.route('/questions/import', methods=['POST'])
@login_required
def import_questions():
    """智能导入题目数据 - 支持CSV和XLSX文件"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        # 检查文件类型
        filename_lower = file.filename.lower()
        if not (filename_lower.endswith('.csv') or filename_lower.endswith('.xlsx')):
            return jsonify({'success': False, 'message': '只支持CSV和XLSX文件'})
        
        # 保存临时文件
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1]) as temp_file:
            file.save(temp_file.name)
            temp_file_path = temp_file.name
        
        try:
            # 使用智能导入管理器
            from smart_import_manager import SmartImportManager
            manager = SmartImportManager()
            
            # 智能导入文件
            exam_id, question_ids = manager.import_file(temp_file_path, exam_title=None)
            
            if question_ids:
                file_type = "Excel(复杂阅读理解)" if filename_lower.endswith('.xlsx') else "CSV(传统题目)"
                message = f'成功导入 {len(question_ids)} 道题目 (格式: {file_type})'
                return jsonify({'success': True, 'message': message})
            else:
                return jsonify({'success': False, 'message': '导入失败，请检查文件格式和内容'})
        
        except Exception as parse_error:
            return jsonify({'success': False, 'message': f'文件解析失败: {str(parse_error)}'})
        
        finally:
            # 清理临时文件
            try:
                os.unlink(temp_file_path)
            except:
                pass
        
    except Exception as e:
        print(f"Import questions error: {e}")
        return jsonify({'success': False, 'message': f'导入失败: {str(e)}'})

@teacher_bp.route('/questions/clear', methods=['POST'])
@login_required
def clear_all_questions():
    """清空所有题目数据"""
    try:
        db = Database()
        deleted_count = db.delete_all_questions()
        
        return jsonify({'success': True, 'message': f'已清空 {deleted_count} 道题目'})
        
    except Exception as e:
        print(f"Clear questions error: {e}")
        return jsonify({'success': False, 'message': f'清空失败: {str(e)}'})

@teacher_bp.route('/questions/export')
@login_required
def export_questions():
    """导出题目数据为CSV"""
    try:
        # 获取编码参数
        encoding = request.args.get('encoding', 'utf-8')  # utf-8 或 gbk
        
        db = Database()
        questions = db.get_questions()
        
        if not questions:
            return jsonify({'success': False, 'message': '暂无题目数据可导出'})
        
        # 创建CSV内容
        import io
        import csv
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # 写入完整的标题行，包含所有字段
        writer.writerow([
            'id', 'question_type', 'question_text', 'option_A', 'option_B', 'option_C', 'option_D', 
            'correct_answer', 'difficulty', 'subject', 'score', 'material', 'created_at'
        ])
        
        # 写入数据行
        for question in questions:
            options = {'A': '', 'B': '', 'C': '', 'D': ''}
            if question.options:
                try:
                    import json
                    options = json.loads(question.options.replace("'", '"'))
                except:
                    pass
            
            # 处理创建时间格式
            created_at_str = ''
            if hasattr(question, 'created_at') and question.created_at:
                if isinstance(question.created_at, str):
                    created_at_str = question.created_at
                else:
                    created_at_str = question.created_at.strftime('%Y-%m-%d %H:%M:%S')
            
            writer.writerow([
                getattr(question, 'id', ''),
                question.question_type or '',
                question.question_text or '',
                options.get('A', ''),
                options.get('B', ''),
                options.get('C', ''),
                options.get('D', ''),
                question.correct_answer or '',
                question.difficulty or 1,
                question.subject or '',
                getattr(question, 'score', 5.0),  # 默认分值为5分
                getattr(question, 'material', '') or '',  # 材料内容（用于复杂题目）
                created_at_str
            ])
        
        output.seek(0)
        csv_data = output.getvalue()
        output.close()
        
        # 使用通用函数创建响应
        return create_csv_response(csv_data, 'questions', encoding)
        
    except Exception as e:
        print(f"Export questions error: {e}")
        return jsonify({'success': False, 'message': f'导出失败: {str(e)}'})

@teacher_bp.route('/questions/batch-delete', methods=['POST'])
@login_required
def batch_delete_questions():
    """批量删除题目"""
    try:
        question_ids = request.get_json().get('question_ids', [])
        
        if not question_ids:
            return jsonify({'success': False, 'message': '没有选择要删除的题目'})
        
        db = Database()
        deleted_count = db.delete_questions_batch(question_ids)
        
        return jsonify({'success': True, 'message': f'成功删除 {deleted_count} 道题目'})
        
    except Exception as e:
        print(f"Batch delete questions error: {e}")
        return jsonify({'success': False, 'message': f'批量删除失败: {str(e)}'})

@teacher_bp.route('/exams')
@login_required
def exams():
    """考试管理页面"""
    try:
        db = Database()
        exams = db.get_exams()
        return render_template('teacher/exams.html', exams=exams)
    except Exception as e:
        print(f"Exams page error: {e}")
        flash('加载考试数据时发生错误', 'error')
        return render_template('teacher/exams.html', exams=[])

@teacher_bp.route('/exams/new-interface')
@login_required
def new_exam_interface():
    """新版考试创建界面"""
    print("🔍 新考试界面路由被访问 (teacher蓝图)")
    try:
        print("🔍 尝试渲染模板: teacher/new_exam_interface.html")
        return render_template('teacher/new_exam_interface.html')
    except Exception as e:
        print(f"❌ 模板渲染失败: {e}")
        flash(f'新考试界面加载失败: {e}', 'error')
        return redirect(url_for('teacher.exams'))

@teacher_bp.route('/exams/add', methods=['POST'])
@login_required
def add_exam():
    """创建考试 - 支持复杂题目组、简单题目混合选择和按类别出题"""
    try:
        print(f"=== 创建考试请求开始 ===")
        print(f"Request form: {request.form}")
        print(f"Request files: {request.files}")
        
        db = Database()
        
        # 获取表单数据
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        duration_minutes = request.form.get('duration_minutes', '60')
        is_active = request.form.get('is_active', 'false').lower() == 'true'
        
        # 获取选中的简单题目ID
        simple_question_ids = request.form.getlist('simple_question_ids')
        # 获取选中的复杂题目组材料
        complex_group_materials = request.form.getlist('complex_group_materials')
        # 获取类别配置（新增）
        category_configuration_str = request.form.get('category_configuration')
        
        print(f"解析的数据:")
        print(f"  标题: {title}")
        print(f"  描述: {description}")
        print(f"  时长: {duration_minutes}")
        print(f"  是否激活: {is_active}")
        print(f"  简单题目ID列表: {simple_question_ids}")
        print(f"  复杂题目组材料列表: {len(complex_group_materials) if complex_group_materials else 0}")
        print(f"  类别配置: {category_configuration_str}")
        
        # 处理类别配置
        category_configuration = {}
        if category_configuration_str:
            try:
                import json
                category_configuration = json.loads(category_configuration_str)
                print(f"  解析的类别配置: {category_configuration}")
            except Exception as e:
                print(f"  解析类别配置失败: {e}")
                category_configuration = {}
        
        # 直接使用材料，不进行URL解码（前端已经解码了）
        if complex_group_materials:
            # 只进行基本的清理，不进行URL解码
            cleaned_materials = []
            for material in complex_group_materials:
                cleaned_material = material.strip()
                if cleaned_material:
                    cleaned_materials.append(cleaned_material)
            complex_group_materials = cleaned_materials
        
        # 验证输入
        if not title:
            print("❌ 错误：考试标题为空")
            return jsonify({'success': False, 'message': '考试标题不能为空'})
        
        # 检查是否有选择题目或配置类别
        if not simple_question_ids and not complex_group_materials and not category_configuration:
            print("❌ 错误：未选择任何题目或配置类别")
            return jsonify({'success': False, 'message': '请至少选择一道题目、一个题目组或配置类别出题'})
        
        # 转换数据类型
        try:
            duration_minutes = int(duration_minutes)
            simple_question_ids = [int(qid) for qid in simple_question_ids if qid.strip()]
        except ValueError as e:
            print(f"❌ 数据类型转换错误: {e}")
            return jsonify({'success': False, 'message': f'数据格式错误: {str(e)}'})
        
        # 获取所有题目用于验证和统计
        all_questions = db.get_questions()
        selected_question_ids = []
        total_score = 0.0
        
        # 处理简单题目
        if simple_question_ids:
            print(f"处理 {len(simple_question_ids)} 个简单题目...")
            for qid in simple_question_ids:
                question = next((q for q in all_questions if q.id == qid), None)
                if question:
                    selected_question_ids.append(qid)
                    total_score += question.score
                    print(f"  添加简单题目 ID:{qid}, 分值:{question.score}")
                else:
                    print(f"❌ 错误：简单题目ID {qid} 不存在")
                    return jsonify({'success': False, 'message': f'题目ID {qid} 不存在'})
        
        # 处理类别配置 - 按类别自动选择题目
        # 🔥 修复：只有在没有手动选择题目时才处理类别配置，避免重复
        if category_configuration and not simple_question_ids:
            print(f"处理类别配置: {category_configuration}")
            category_selected_count = 0
            
            for question_type, config in category_configuration.items():
                count = config.get('count', 0)
                difficulty = config.get('difficulty', '')
                
                if count <= 0:
                    continue
                
                print(f"  处理类别: {question_type}, 需要: {count}题, 难度: {difficulty or '全部'}")
                
                # 筛选符合条件的题目
                candidate_questions = []
                for q in all_questions:
                    if q.question_type != question_type:
                        continue
                    if difficulty and str(q.difficulty) != str(difficulty):
                        continue
                    # 避免重复选择已经手动选择的题目
                    if q.id in selected_question_ids:
                        continue
                    candidate_questions.append(q)
                
                print(f"    符合条件的候选题目: {len(candidate_questions)}题")
                
                if len(candidate_questions) < count:
                    print(f"    警告: 候选题目不足，需要{count}题，只有{len(candidate_questions)}题")
                
                # 随机选择题目
                import random
                selected_from_category = random.sample(candidate_questions, min(count, len(candidate_questions)))
                
                for q in selected_from_category:
                    selected_question_ids.append(q.id)
                    total_score += q.score
                    category_selected_count += 1
                    print(f"    按类别选择题目 ID:{q.id}, 类型:{q.question_type}, 分值:{q.score}")
            
            print(f"  类别配置总共选择了 {category_selected_count} 题")
        elif category_configuration and simple_question_ids:
            print(f"🚫 跳过类别配置处理，因为已有手动选择题目，避免重复")
        else:
            print(f"📝 无类别配置需要处理")
        
        # 处理复杂题目组
        if complex_group_materials:
            print(f"处理 {len(complex_group_materials)} 个复杂题目组...")
            for material in complex_group_materials:
                material = material.strip()
                if material:
                    # 查找该材料对应的所有题目 - 修复版本
                    group_questions = []
                    
                    # 首先尝试精确匹配
                    for q in all_questions:
                        if q.material and q.material.strip() == material:
                            group_questions.append(q)
                    
                    # 如果精确匹配失败，尝试去除换行符和额外空格的匹配
                    if not group_questions:
                        normalized_material = ' '.join(material.split())  # 规范化空白字符
                        for q in all_questions:
                            if q.material:
                                normalized_q_material = ' '.join(q.material.strip().split())
                                if normalized_q_material == normalized_material:
                                    group_questions.append(q)
                    
                    # 如果还是失败，尝试部分匹配（前200个字符）
                    if not group_questions:
                        material_prefix = material[:200]
                        for q in all_questions:
                            if q.material and q.material.strip().startswith(material_prefix):
                                group_questions.append(q)
                    
                    if group_questions:
                        print(f"  复杂题目组 '{material[:50]}...' 包含 {len(group_questions)} 道题目")
                        group_score = 0.0
                        for q in group_questions:
                            selected_question_ids.append(q.id)
                            group_score += q.score
                            total_score += q.score
                            print(f"    添加题目 ID:{q.id}, 类型:{q.question_type}, 分值:{q.score}")
                        print(f"  题目组总分值: {group_score}")
                    else:
                        print(f"❌ 错误：复杂题目组材料 '{material[:50]}...' 没有对应的题目")
                        return jsonify({'success': False, 'message': f'题目组 "{material[:50]}..." 没有对应的题目。请检查材料内容是否完整匹配。'})
        
        print(f"🛠️ Raw selected_question_ids before final processing in teacher.py: {selected_question_ids}")
        print(f"🛠️ Length before de-duplication: {len(selected_question_ids)}, Original total_score: {total_score}")

        # Final de-duplication of question IDs and recalculation of total_score
        if selected_question_ids:
            final_unique_question_ids = []
            seen_ids = set()
            for qid in selected_question_ids:
                if qid not in seen_ids:
                    final_unique_question_ids.append(qid)
                    seen_ids.add(qid)
            
            # Recalculate total_score based on the unique questions
            final_total_score = 0.0
            for qid in final_unique_question_ids:
                question = next((q for q in all_questions if q.id == qid), None)
                if question:
                    final_total_score += question.score
        else:
            final_unique_question_ids = []
            final_total_score = 0.0

        print(f"✅ 最终选择题目总数 (去重后): {len(final_unique_question_ids)}")
        print(f"✅ 考试总分值 (去重后): {final_total_score}")
        # print(f"✅ 题目ID验证通过") # Original comment, validation is implicit in selection
        
        # 创建考试对象
        exam = Exam(
            title=title,
            description=description,
            duration_minutes=duration_minutes,
            total_questions=len(final_unique_question_ids),  # USE DE-DUPLICATED LENGTH
            total_score=final_total_score,                # USE DE-DUPLICATED SCORE
            is_active=is_active
        )
        
        print(f"创建的考试对象:")
        print(f"  标题: {exam.title}")
        print(f"  时长: {exam.duration_minutes}分钟")
        print(f"  题目数: {exam.total_questions}")
        print(f"  总分值: {exam.total_score}")
        print(f"  是否激活: {exam.is_active}")
        
        # 创建考试并关联题目
        exam_id = db.create_exam_with_questions(exam, final_unique_question_ids) # Pass de-duplicated list
        
        print(f"✅ 考试创建成功，ID: {exam_id}")
        print(f"=== 创建考试请求完成 ===")
        
        # 构建详细反馈信息
        message_parts = [f'考试"{title}"创建成功！']
        if len(simple_question_ids) > 0:
            message_parts.append(f'手动选择{len(simple_question_ids)}题')
        if category_configuration:
            category_count = sum(config.get('count', 0) for config in category_configuration.values())
            message_parts.append(f'按类别配置{category_count}题')
        if len(complex_group_materials) > 0:
            message_parts.append(f'{len(complex_group_materials)}个题目组')
        message_parts.append(f'总计{len(final_unique_question_ids)}题，{final_total_score}分')
        
        return jsonify({
            'success': True, 
            'message': '，'.join(message_parts), 
            'exam_id': exam_id,
            'exam_info': {
                'title': title,
                'duration': duration_minutes,
                'total_questions': len(final_unique_question_ids), # Final unique count
                'total_score': final_total_score,              # Final unique score
                'is_active': is_active,
                # The following are for more detailed breakdown if needed by frontend, based on final unique questions
                # 'processed_manual_questions': len(manual_ids_in_final_set),
                # 'processed_category_questions': len(category_ids_in_final_set),
                # 'processed_complex_groups': count_of_complex_groups_contributing_to_final_set
            }
        })
        
    except Exception as e:
        print(f"❌ 创建考试异常: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'创建考试失败: {str(e)}'})

@teacher_bp.route('/exams/delete/<int:exam_id>', methods=['POST'])
@login_required
def delete_exam(exam_id):
    """删除考试"""
    try:
        db = Database()
        
        # 这里需要扩展Database类添加delete_exam方法
        # 临时方案：直接操作数据库
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # 删除相关数据
        cursor.execute("DELETE FROM exam_questions WHERE exam_id = ?", (exam_id,))
        cursor.execute("DELETE FROM exam_results WHERE exam_id = ?", (exam_id,))
        cursor.execute("DELETE FROM exams WHERE id = ?", (exam_id,))
        
        conn.commit()
        
        return jsonify({'success': True, 'message': '考试删除成功'})
        
    except Exception as e:
        print(f"Delete exam error: {e}")
        return jsonify({'success': False, 'message': f'删除考试失败: {str(e)}'})

@teacher_bp.route('/results')
@login_required
def results():
    """成绩分析页面"""
    try:
        db = Database()
        
        # 获取考试结果数据
        try:
            exam_results = db.get_exam_results()
            print(f"获取到 {len(exam_results)} 条考试结果")
            
            # 确保数据格式正确
            processed_results = []
            for i, result in enumerate(exam_results):
                try:
                    if isinstance(result, dict):
                        # 已经是字典格式，直接使用但确保所有必要字段存在
                        processed_result = {
                            'id': result.get('id', 0),
                            'exam_id': result.get('exam_id', 0),
                            'student_id': result.get('student_id', 0),
                            'score': result.get('score', 0.0),
                            'total_score': result.get('total_score', 0.0),
                            'is_completed': result.get('is_completed', False),
                            'start_time': result.get('start_time', ''),
                            'end_time': result.get('end_time', ''),
                            'exam_title': result.get('exam_title', f'考试{result.get("exam_id", "")}'),
                            'student_name': result.get('student_name', 'N/A'),
                            'student_number': result.get('student_number', 'N/A'),
                            'college': result.get('college', ''),
                            'major': result.get('major', ''),
                            'class_name': result.get('class_name', ''),
                            'gender': result.get('gender', '')
                        }
                        processed_results.append(processed_result)
                    else:
                        # 如果是对象，转换为字典
                        processed_results.append({
                            'id': getattr(result, 'id', 0),
                            'exam_id': getattr(result, 'exam_id', 0),
                            'student_id': getattr(result, 'student_id', 0),
                            'score': getattr(result, 'score', 0.0),
                            'total_score': getattr(result, 'total_score', 0.0),
                            'is_completed': getattr(result, 'is_completed', False),
                            'start_time': getattr(result, 'start_time', ''),
                            'end_time': getattr(result, 'end_time', ''),
                            'exam_title': getattr(result, 'exam_title', f'考试{getattr(result, "exam_id", "")}'),
                            'student_name': getattr(result, 'student_name', 'N/A'),
                            'student_number': getattr(result, 'student_number', 'N/A'),
                            'college': getattr(result, 'college', ''),
                            'major': getattr(result, 'major', ''),
                            'class_name': getattr(result, 'class_name', ''),
                            'gender': getattr(result, 'gender', '')
                        })
                        
                except Exception as item_error:
                    print(f"处理第{i+1}项考试结果时出错: {item_error}")
                    continue
            
            exam_results = processed_results
            print(f"成功处理 {len(processed_results)} 条考试结果")
            
        except Exception as results_error:
            print(f"获取考试结果失败: {results_error}")
            import traceback
            traceback.print_exc()
            exam_results = []
        
        # 获取考试列表
        try:
            exams = db.get_exams()
        except Exception as exams_error:
            print(f"获取考试列表失败: {exams_error}")
            exams = []
        
        return render_template('teacher/results.html',
                             exam_results=exam_results,
                             exams=exams)
    except Exception as e:
        print(f"Results page error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载成绩数据时发生错误', 'error')
        return render_template('teacher/results.html', exam_results=[], exams=[])

@teacher_bp.route('/exams/edit/<int:exam_id>', methods=['GET', 'POST'])
@login_required
def edit_exam(exam_id):
    """编辑考试页面和处理编辑请求"""
    try:
        db = Database()
        
        if request.method == 'GET':
            # 显示编辑页面
            exam = db.get_exam_by_id(exam_id)
            if not exam:
                flash('考试不存在', 'error')
                return redirect(url_for('teacher.exams'))
            
            # 获取考试题目
            questions = db.get_exam_questions(exam_id)
            
            # 定义题目类型名称映射函数
            def get_question_type_name(question_type):
                names = {
                    'choice': '选择题',
                    'judge': '判断题', 
                    'fill_blank': '填空题',
                    'short_answer': '简答题',
                    'essay': '论述题'
                }
                return names.get(question_type, question_type)
            
            return render_template('teacher/exam_edit.html', 
                                 exam=exam, 
                                 questions=questions,
                                 get_question_type_name=get_question_type_name)
        
        else:
            # 处理POST请求 - 更新考试基本信息
            title = request.form.get('title')
            description = request.form.get('description', '')
            duration_minutes = int(request.form.get('duration_minutes', 60))
            is_active = request.form.get('is_active') == 'true'
            
            if not title:
                return jsonify({'success': False, 'message': '考试标题不能为空'})
            
            # 更新考试信息
            conn = db.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE exams 
                SET title = ?, description = ?, duration_minutes = ?, is_active = ?
                WHERE id = ?
            """, (title, description, duration_minutes, is_active, exam_id))
            
            conn.commit()
            
            return jsonify({'success': True, 'message': '考试基本信息更新成功'})
        
    except Exception as e:
        print(f"Edit exam error: {e}")
        if request.method == 'GET':
            flash('加载考试编辑页面失败', 'error')
            return redirect(url_for('teacher.exams'))
        else:
            return jsonify({'success': False, 'message': f'编辑考试失败: {str(e)}'})

@teacher_bp.route('/exams/toggle/<int:exam_id>', methods=['POST'])
@login_required
def toggle_exam_status(exam_id):
    """切换考试状态"""
    try:
        db = Database()
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # 获取当前状态
        cursor.execute("SELECT is_active FROM exams WHERE id = ?", (exam_id,))
        result = cursor.fetchone()
        
        if not result:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        # 切换状态
        new_status = not bool(result[0])
        cursor.execute("UPDATE exams SET is_active = ? WHERE id = ?", (new_status, exam_id))
        conn.commit()
        
        status_text = "激活" if new_status else "停用"
        return jsonify({'success': True, 'message': f'考试已{status_text}'})
        
    except Exception as e:
        print(f"Toggle exam status error: {e}")
        return jsonify({'success': False, 'message': f'状态切换失败: {str(e)}'})

@teacher_bp.route('/exams/batch-toggle', methods=['POST'])
@login_required
def batch_toggle_exam_status():
    """批量切换考试状态"""
    try:
        exam_ids = request.get_json().get('exam_ids', [])
        
        if not exam_ids:
            return jsonify({'success': False, 'message': '没有选择要切换状态的考试'})
        
        db = Database()
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # 切换每个考试的状态
        for exam_id in exam_ids:
            cursor.execute("SELECT is_active FROM exams WHERE id = ?", (exam_id,))
            result = cursor.fetchone()
            if result:
                new_status = not bool(result[0])
                cursor.execute("UPDATE exams SET is_active = ? WHERE id = ?", (new_status, exam_id))
        
        conn.commit()
        
        return jsonify({'success': True, 'message': f'成功切换 {len(exam_ids)} 个考试的状态'})
        
    except Exception as e:
        print(f"Batch toggle exam status error: {e}")
        return jsonify({'success': False, 'message': f'批量切换失败: {str(e)}'})

@teacher_bp.route('/exams/batch-delete', methods=['POST'])
@login_required
def batch_delete_exams():
    """批量删除考试"""
    try:
        exam_ids = request.get_json().get('exam_ids', [])
        
        if not exam_ids:
            return jsonify({'success': False, 'message': '没有选择要删除的考试'})
        
        db = Database()
        conn = db.get_connection()
        cursor = conn.cursor()
        
        deleted_count = 0
        for exam_id in exam_ids:
            # 删除相关数据
            cursor.execute("DELETE FROM exam_questions WHERE exam_id = ?", (exam_id,))
            cursor.execute("DELETE FROM exam_results WHERE exam_id = ?", (exam_id,))
            cursor.execute("DELETE FROM exams WHERE id = ?", (exam_id,))
            deleted_count += 1
        
        conn.commit()
        
        return jsonify({'success': True, 'message': f'成功删除 {deleted_count} 个考试'})
        
    except Exception as e:
        print(f"Batch delete exams error: {e}")
        return jsonify({'success': False, 'message': f'批量删除失败: {str(e)}'})

@teacher_bp.route('/exams/clear', methods=['POST'])
@login_required
def clear_all_exams():
    """清空所有考试数据"""
    try:
        db = Database()
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # 获取考试数量
        cursor.execute("SELECT COUNT(*) FROM exams")
        count = cursor.fetchone()[0]
        
        # 删除所有相关数据
        cursor.execute("DELETE FROM exam_questions")
        cursor.execute("DELETE FROM exam_results")
        cursor.execute("DELETE FROM exams")
        
        conn.commit()
        
        return jsonify({'success': True, 'message': f'已清空 {count} 个考试'})
        
    except Exception as e:
        print(f"Clear exams error: {e}")
        return jsonify({'success': False, 'message': f'清空失败: {str(e)}'})

@teacher_bp.route('/exams/export')
@login_required
def export_exams():
    """导出考试数据为CSV（包含题目详情）"""
    try:
        # 获取编码参数
        encoding = request.args.get('encoding', 'utf-8')  # utf-8 或 gbk
        # 获取特定考试ID参数
        exam_id = request.args.get('exam_id', type=int)
        
        db = Database()
        
        if exam_id:
            # 导出单个考试
            exam = db.get_exam_by_id(exam_id)
            if not exam:
                return jsonify({'success': False, 'message': '考试不存在'})
            exams = [exam]
        else:
            # 导出所有考试
            exams = db.get_exams()
        
        if not exams:
            return jsonify({'success': False, 'message': '暂无考试数据可导出'})
        
        # 创建CSV内容
        import io
        import csv
        from datetime import datetime
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # 写入标题行 - 包含考试信息和题目信息
        writer.writerow([
            'exam_title', 'exam_description', 'duration_minutes', 'is_active', 'created_at',
            'question_type', 'question_text', 'option_A', 'option_B', 'option_C', 'option_D', 
            'correct_answer', 'difficulty', 'subject'
        ])
        
        # 写入数据行
        for exam in exams:
            # 处理日期格式
            created_at_str = ''
            if exam.created_at:
                if isinstance(exam.created_at, str):
                    created_at_str = exam.created_at
                else:
                    created_at_str = exam.created_at.strftime('%Y-%m-%d %H:%M:%S')
            
            # 获取考试关联的题目
            conn = db.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT q.question_type, q.question_text, q.options, q.correct_answer, 
                       q.difficulty, q.subject
                FROM questions q
                JOIN exam_questions eq ON q.id = eq.question_id
                WHERE eq.exam_id = ?
                ORDER BY eq.id
            """, (exam.id,))
            
            questions = cursor.fetchall()
            
            if questions:
                # 为每个题目写入一行
                for question in questions:
                    question_type, question_text, options, correct_answer, difficulty, subject = question
                    
                    # 解析选择题选项
                    option_A = option_B = option_C = option_D = ''
                    if question_type == 'choice' and options:
                        try:
                            import json
                            options_dict = json.loads(options.replace("'", '"'))
                            option_A = options_dict.get('A', '')
                            option_B = options_dict.get('B', '')
                            option_C = options_dict.get('C', '')
                            option_D = options_dict.get('D', '')
                        except:
                            pass
                    
                    writer.writerow([
                        exam.title or '',
                        exam.description or '',
                        exam.duration_minutes or 60,
                        'true' if exam.is_active else 'false',
                        created_at_str,
                        question_type or '',
                        question_text or '',
                        option_A,
                        option_B,
                        option_C,
                        option_D,
                        correct_answer or '',
                        difficulty or 1,
                        subject or ''
                    ])
            else:
                # 如果考试没有题目，只写入考试信息
                writer.writerow([
                    exam.title or '',
                    exam.description or '',
                    exam.duration_minutes or 60,
                    'true' if exam.is_active else 'false',
                    created_at_str,
                    '', '', '', '', '', '', '', '', ''
                ])
        
        output.seek(0)
        csv_data = output.getvalue()
        output.close()
        
        # 确定文件名
        if exam_id and exams:
            # 单个考试导出，使用考试名称
            safe_title = "".join(c for c in exams[0].title if c.isalnum() or c in (' ', '-', '_')).rstrip()
            filename = f'exam_{exam_id}_{safe_title[:20]}_with_questions'
        else:
            # 批量导出
            filename = 'exams_with_questions'
        
        # 使用通用函数创建响应
        return create_csv_response(csv_data, filename, encoding)
        
    except Exception as e:
        print(f"Export exams error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'导出失败: {str(e)}'})

@teacher_bp.route('/exams/export-simple')
@login_required
def export_exams_simple():
    """导出考试基本信息（不含题目详情）"""
    try:
        # 获取编码参数
        encoding = request.args.get('encoding', 'utf-8')  # utf-8 或 gbk
        
        db = Database()
        exams = db.get_exams()
        
        if not exams:
            return jsonify({'success': False, 'message': '暂无考试数据可导出'})
        
        # 创建CSV内容
        import io
        import csv
        from datetime import datetime
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # 写入标题行
        writer.writerow(['title', 'description', 'duration_minutes', 'total_questions', 'is_active', 'created_at'])
        
        # 写入数据行
        for exam in exams:
            # 处理日期格式
            created_at_str = ''
            if exam.created_at:
                if isinstance(exam.created_at, str):
                    created_at_str = exam.created_at
                else:
                    created_at_str = exam.created_at.strftime('%Y-%m-%d %H:%M:%S')
            
            writer.writerow([
                exam.title or '',
                exam.description or '',
                exam.duration_minutes or 60,
                exam.total_questions or 0,
                'true' if exam.is_active else 'false',
                created_at_str
            ])
        
        output.seek(0)
        csv_data = output.getvalue()
        output.close()
        
        # 使用通用函数创建响应
        return create_csv_response(csv_data, 'exams_simple', encoding)
        
    except Exception as e:
        print(f"Export exams simple error: {e}")
        return jsonify({'success': False, 'message': f'导出失败: {str(e)}'})

@teacher_bp.route('/exams/import', methods=['POST'])
@login_required
def import_exams():
    """导入考试数据（支持包含题目的完整导入）"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        if not file.filename.lower().endswith('.csv'):
            return jsonify({'success': False, 'message': '只支持CSV文件'})
        
        # 读取文件内容
        file_content = file.read().decode('utf-8-sig')
        
        import csv
        import io
        import json
        
        csv_reader = csv.DictReader(io.StringIO(file_content))
        
        db = Database()
        conn = db.get_connection()
        cursor = conn.cursor()
        
        success_count = 0
        error_count = 0
        exams_created = {}  # 记录已创建的考试 {exam_title: exam_id}
        
        # 读取所有行并按考试分组
        exam_groups = {}
        for row in csv_reader:
            exam_title = row.get('exam_title', '').strip()
            if not exam_title:
                error_count += 1
                continue
            
            if exam_title not in exam_groups:
                exam_groups[exam_title] = {
                    'exam_info': {
                        'title': exam_title,
                        'description': row.get('exam_description', '').strip(),
                        'duration_minutes': int(row.get('duration_minutes', 60)),
                        'is_active': row.get('is_active', 'false').lower() == 'true'
                    },
                    'questions': []
                }
            
            # 如果有题目信息，添加到题目列表
            question_type = row.get('question_type', '').strip()
            question_text = row.get('question_text', '').strip()
            
            if question_type and question_text:
                question_data = {
                    'question_type': question_type,
                    'question_text': question_text,
                    'correct_answer': row.get('correct_answer', '').strip(),
                    'difficulty': int(row.get('difficulty', 1)),
                    'subject': row.get('subject', '').strip()
                }
                
                # 处理选择题选项
                if question_type == 'choice':
                    options = {
                        'A': row.get('option_A', '').strip(),
                        'B': row.get('option_B', '').strip(),
                        'C': row.get('option_C', '').strip(),
                        'D': row.get('option_D', '').strip()
                    }
                    question_data['options'] = json.dumps(options)
                else:
                    question_data['options'] = ''
                
                exam_groups[exam_title]['questions'].append(question_data)
        
        # 处理每个考试组
        for exam_title, exam_data in exam_groups.items():
            try:
                exam_info = exam_data['exam_info']
                questions = exam_data['questions']
                
                # 创建考试
                cursor.execute("""
                    INSERT INTO exams (title, description, duration_minutes, total_questions, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))
                """, (
                    exam_info['title'],
                    exam_info['description'],
                    exam_info['duration_minutes'],
                    len(questions),
                    exam_info['is_active']
                ))
                
                exam_id = cursor.lastrowid
                
                # 添加题目并关联到考试
                for question_data in questions:
                    # 检查题目是否已存在（基于题目内容和类型）
                    cursor.execute("""
                        SELECT id FROM questions 
                        WHERE question_type = ? AND question_text = ? AND correct_answer = ?
                    """, (
                        question_data['question_type'],
                        question_data['question_text'],
                        question_data['correct_answer']
                    ))
                    
                    existing_question = cursor.fetchone()
                    
                    if existing_question:
                        question_id = existing_question[0]
                    else:
                        # 创建新题目
                        cursor.execute("""
                            INSERT INTO questions (question_type, question_text, options, correct_answer, difficulty, subject, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
                        """, (
                            question_data['question_type'],
                            question_data['question_text'],
                            question_data['options'],
                            question_data['correct_answer'],
                            question_data['difficulty'],
                            question_data['subject']
                        ))
                        question_id = cursor.lastrowid
                    
                    # 关联题目到考试
                    cursor.execute("""
                        INSERT INTO exam_questions (exam_id, question_id)
                        VALUES (?, ?)
                    """, (exam_id, question_id))
                
                success_count += 1
                print(f"成功创建考试: {exam_title}，包含 {len(questions)} 道题目")
                
            except Exception as e:
                print(f"Import exam group error for '{exam_title}': {e}")
                error_count += 1
        
        conn.commit()
        
        message = f'成功导入 {success_count} 个考试'
        if error_count > 0:
            message += f'，失败 {error_count} 个'
        
        return jsonify({'success': True, 'message': message})
        
    except Exception as e:
        print(f"Import exams error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'导入失败: {str(e)}'})

@teacher_bp.route('/exams/import-simple', methods=['POST'])
@login_required
def import_exams_simple():
    """导入考试基本信息（不含题目）"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': '没有选择文件'})
        
        if not file.filename.lower().endswith('.csv'):
            return jsonify({'success': False, 'message': '只支持CSV文件'})
        
        # 读取文件内容
        file_content = file.read().decode('utf-8-sig')
        
        import csv
        import io
        
        csv_reader = csv.DictReader(io.StringIO(file_content))
        
        db = Database()
        conn = db.get_connection()
        cursor = conn.cursor()
        
        success_count = 0
        error_count = 0
        
        for row in csv_reader:
            try:
                title = row.get('title', '').strip()
                description = row.get('description', '').strip()
                duration_minutes = int(row.get('duration_minutes', 60))
                total_questions = int(row.get('total_questions', 0))
                is_active = row.get('is_active', 'false').lower() == 'true'
                
                if not title:
                    error_count += 1
                    continue
                
                # 创建考试
                cursor.execute("""
                    INSERT INTO exams (title, description, duration_minutes, total_questions, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))
                """, (title, description, duration_minutes, total_questions, is_active))
                
                success_count += 1
                
            except Exception as e:
                print(f"Import exam row error: {e}")
                error_count += 1
        
        conn.commit()
        
        message = f'成功导入 {success_count} 个考试'
        if error_count > 0:
            message += f'，失败 {error_count} 个'
        
        return jsonify({'success': True, 'message': message})
        
    except Exception as e:
        print(f"Import exams simple error: {e}")
        return jsonify({'success': False, 'message': f'导入失败: {str(e)}'})

@teacher_bp.route('/questions/available')
@login_required
def get_available_questions():
    """获取可用题目（AJAX接口）- 支持简单题目和复杂题目分组"""
    try:
        db = Database()
        questions = db.get_questions()
        
        # 分离简单题目和复杂题目
        simple_questions = []
        complex_question_groups = {}
        
        for q in questions:
            if q.material and q.material.strip():
                # 复杂题目：按material分组
                material_key = q.material.strip()
                if material_key not in complex_question_groups:
                    complex_question_groups[material_key] = {
                        'material': material_key,
                        'questions': [],
                        'total_score': 0,
                        'question_count': 0,
                        'question_types': set()
                    }
                
                complex_question_groups[material_key]['questions'].append({
                    'id': q.id,
                    'question_type': q.question_type,
                    'question_text': q.question_text[:100] + '...' if len(q.question_text) > 100 else q.question_text,
                    'score': q.score,
                    'difficulty': q.difficulty,
                    'subject': q.subject,
                    'import_batch': q.import_batch
                })
                complex_question_groups[material_key]['total_score'] += q.score
                complex_question_groups[material_key]['question_count'] += 1
                complex_question_groups[material_key]['question_types'].add(q.question_type)
            else:
                # 简单题目
                simple_questions.append({
                    'id': q.id,
                    'question_type': q.question_type,
                    'question_text': q.question_text[:100] + '...' if len(q.question_text) > 100 else q.question_text,
                    'score': q.score,
                    'difficulty': q.difficulty,
                    'subject': q.subject,
                    'import_batch': q.import_batch
                })
        
        # 转换复杂题目组为列表格式
        complex_groups_list = []
        for material, group_data in complex_question_groups.items():
            group_data['question_types'] = list(group_data['question_types'])
            group_data['group_id'] = f"group_{len(complex_groups_list)}"  # 生成组ID
            complex_groups_list.append(group_data)
        
        # 获取所有导入批次
        import_batches = db.get_import_batches()
        
        return jsonify({
            'success': True,
            'simple_questions': simple_questions,
            'complex_question_groups': complex_groups_list,
            'total_simple': len(simple_questions),
            'total_complex_groups': len(complex_groups_list),
            'import_batches': import_batches
        })
        
    except Exception as e:
        print(f"Get available questions error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'获取题目失败: {str(e)}'
        })

# ===== 新增：主观题评分功能 =====

@teacher_bp.route('/grading')
@login_required
def grading():
    """主观题评分页面"""
    try:
        db = Database()
        
        # 获取所有考试
        exams = db.get_exams()
        
        # 获取所有有主观题需要评分的考试
        grading_exams = []
        for exam in exams:
            # 获取该考试的主观题评分统计
            ai_stats = db.get_ai_grading_statistics(exam.id)
            if ai_stats['total_subjective'] > 0:  # 有主观题
                grading_exams.append({
                    'id': exam.id,
                    'title': exam.title,
                    'description': exam.description,
                    'total_subjective': ai_stats['total_subjective'],
                    'ai_graded': ai_stats['ai_graded'],
                    'manually_graded': ai_stats['manually_graded'],
                    'ungraded': ai_stats['ungraded'],
                    'ai_coverage': ai_stats['ai_coverage']
                })
        
        return render_template('teacher/grading.html', exams=grading_exams)
        
    except Exception as e:
        print(f"Grading page error: {e}")
        flash('加载评分页面时发生错误', 'error')
        return render_template('teacher/grading.html', exams=[])

@teacher_bp.route('/grading/exam/<int:exam_id>')
@login_required
def grading_exam_detail(exam_id):
    """特定考试的主观题评分详情页面"""
    try:
        db = Database()
        
        # 获取考试信息
        exams = db.get_exams()
        exam = next((e for e in exams if e.id == exam_id), None)
        if not exam:
            flash('考试不存在', 'error')
            return redirect(url_for('teacher.grading'))
            
        # 🔥 关键修复：同步评分状态，确保从备份中恢复的学生能显示出来
        try:
            # 延迟导入以避免循环依赖
            from answer_preservation_system import mark_final_submission
            
            # 查找有备份但没有成绩记录的学生
            with db.get_write_connection() as conn:
                cursor = conn.cursor()
                
                # 找出在answer_history中有最终提交记录，但在exam_results中没有记录或未完成的学生
                cursor.execute('''
                    SELECT DISTINCT ah.student_id, s.student_id as student_number
                    FROM answer_history ah
                    JOIN students s ON ah.student_id = s.id
                    LEFT JOIN exam_results er ON ah.exam_id = er.exam_id AND ah.student_id = er.student_id
                    WHERE ah.exam_id = ? 
                    AND ah.is_final_submission = 1
                    AND (er.id IS NULL OR er.is_completed = 0)
                ''', (exam_id,))
                
                missing_students = cursor.fetchall()
                
                if missing_students:
                    print(f"发现 {len(missing_students)} 名学生有提交记录但未显示在评分列表，正在同步...")
                    for sid, snum in missing_students:
                        try:
                            # 使用标记最终提交功能来同步状态
                            mark_final_submission(exam_id, sid, snum)
                        except Exception as sync_err:
                            print(f"同步学生 {snum} 状态失败: {sync_err}")
                            
        except Exception as e:
            print(f"同步评分状态失败: {e}")
            # 不阻断主流程
        
        # 获取需要评分的主观题
        subjective_questions = db.get_subjective_questions_for_ai_grading(exam_id)
        
        # 按题目分组
        questions_by_id = {}
        for q in subjective_questions:
            question_id = q['question_score_id']
            if question_id not in questions_by_id:
                questions_by_id[question_id] = {
                    'question_text': q['question_text'],
                    'question_type': q['question_type'],
                    'max_score': q['max_score'],
                    'answers': []
                }
            questions_by_id[question_id]['answers'].append(q)
        
        # 获取AI评分统计
        ai_stats = db.get_ai_grading_statistics(exam_id)
        
        # 计算统计数据
        total_questions = ai_stats.get('total_subjective', 0)
        ai_graded_count = ai_stats.get('ai_graded', 0)
        manual_graded_count = ai_stats.get('manually_graded', 0)
        ungraded_count = ai_stats.get('ungraded', 0)
        
        return render_template('teacher/grading_detail.html',
                             exam=exam,
                             questions_data=questions_by_id,
                             subjective_questions=subjective_questions,
                             ai_stats=ai_stats,
                             total_questions=total_questions,
                             ai_graded_count=ai_graded_count,
                             manual_graded_count=manual_graded_count,
                             ungraded_count=ungraded_count)
        
    except Exception as e:
        print(f"Grading exam detail error: {e}")
        flash('加载评分详情时发生错误', 'error')
        return redirect(url_for('teacher.grading'))

@teacher_bp.route('/grading/ai-auto/<int:exam_id>', methods=['POST'])
@login_required
def ai_auto_grading(exam_id):
    """AI自动评分功能 - 支持多种模式"""
    try:
        # 导入统一评分引擎
        from grading_engine import get_grading_engine
        
        db = Database()
        
        # 获取请求中的模式参数 - 增强错误处理
        try:
            if request.is_json:
                request_data = request.get_json()
                if request_data is None:
                    request_data = {}
            else:
                # 如果不是JSON请求，尝试从form数据获取
                request_data = request.form.to_dict()
        except Exception as json_error:
            logger.warning(f"JSON解析失败: {json_error}")
            request_data = {}
        
        mode = request_data.get('mode', 'ungraded_only')  # 默认只评分未评分题目
        method = request_data.get('method', 'ai_fusion')  # 获取评分方法，默认使用智能融合评分
        
        # 获取所有主观题
        subjective_questions = db.get_subjective_questions_for_ai_grading(exam_id)
        
        # 根据模式筛选需要评分的题目
        if mode == 'all_questions':
            # 重新评分所有题目
            target_questions = subjective_questions
            mode_description = f"重新AI评分所有题目({method})"
        else:
            # 只评分未评分的题目（默认模式）
            target_questions = [q for q in subjective_questions if not q.get('is_ai_graded', False)]
            mode_description = f"AI评分未评分题目({method})"
        
        if not target_questions:
            if mode == 'all_questions':
                message = '没有主观题需要评分'
            else:
                message = '没有未评分的题目'
            
            return jsonify({
                'success': False, 
                'message': message
            })
        
        # 初始化统一评分引擎
        grading_engine = get_grading_engine()
        
        # 准备批量评分数据
        ai_results = []
        processed_count = 0
        failed_count = 0
        method_count = 0
        
        for question in target_questions:
            try:
                # 使用统一评分引擎进行AI评分，使用指定方法
                grading_result = grading_engine.grade(
                    question_type=question.get('question_type', 'subjective'),
                    student_answer=question['student_answer'],
                    reference_answer=question['reference_answer'],
                    question_text=question['question_text'],
                    max_score=question['max_score'],
                    method=method  # 使用指定的评分方法
                )
                
                # 统计使用的评分方法
                method_used = grading_result.get('method', 'unknown')
                if method in method_used:
                    method_count += 1
                
                # 准备保存结果
                ai_results.append({
                    'question_score_id': question['question_score_id'],
                    'ai_result': grading_result
                })
                
                processed_count += 1
                
            except Exception as e:
                print(f"AI评分失败 - 题目ID {question['question_score_id']}: {e}")
                failed_count += 1
        
        # 批量保存AI评分结果
        if ai_results:
            save_result = db.batch_save_ai_grading_results(ai_results)
            
            # --- 新增逻辑：批量评分后的总分调整 ---
            # 由于批量评分可能涉及多个学生，我们需要找出受影响的学生并逐一调整
            # 这是一个相对昂贵的操作，但为了满足总分约束是必要的
            try:
                conn = db.get_connection()
                cursor = conn.cursor()
                
                # 找出涉及的 students
                affected_students = set()
                # 这里的 ai_results 只包含 question_score_id，我们需要反查 exam_id 和 student_id
                # 但更简单的方法是直接查询此次操作影响了哪些 exam_results
                
                # 从 ai_results 中提取所有 question_score_id
                qs_ids = [item['question_score_id'] for item in ai_results]
                
                if qs_ids:
                    placeholders = ','.join(['?'] * len(qs_ids))
                    cursor.execute(f'''
                        SELECT DISTINCT er.exam_id, er.student_id 
                        FROM exam_results er
                        JOIN question_scores qs ON qs.exam_result_id = er.id
                        WHERE qs.id IN ({placeholders})
                    ''', qs_ids)
                    
                    for row in cursor.fetchall():
                        exam_id_val, student_id_val = row[0], row[1]
                        adjust_student_total_score(db, exam_id_val, student_id_val, 64, 85)
                        
            except Exception as batch_adj_err:
                print(f"[BATCH_SCORE_ADJUST_ERROR] 批量调整分数出错: {batch_adj_err}")
            # ------------------------------------
            
            return jsonify({
                'success': True,
                'message': f'{mode_description}完成！成功评分 {save_result["success_count"]} 题，失败 {save_result["failed_count"]} 题',
                'processed': processed_count,
                'failed': failed_count,
                'mode': mode,
                'method': method,
                'method_stats': {
                    method: method_count,
                    'total': processed_count
                },
                'details': save_result
            })
        else:
            return jsonify({
                'success': False,
                'message': f'{mode_description}失败，没有成功处理任何题目'
            })
        
    except Exception as e:
        print(f"AI auto grading error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'AI自动评分失败: {str(e)}'
        })

@teacher_bp.route('/grading/ai-single/<int:question_score_id>', methods=['POST'])
@login_required
def ai_single_grading(question_score_id):
    """单个题目AI评分功能 - 支持指定评分方法"""
    try:
        # 导入统一评分引擎
        from grading_engine import get_grading_engine
        
        db = Database()
        
        # 获取请求中的评分方法参数
        try:
            if request.is_json:
                request_data = request.get_json() or {}
            else:
                request_data = request.form.to_dict()
        except Exception:
            request_data = {}
        
        # 获取评分方法，默认使用智能融合评分
        method = request_data.get('method', 'ai_fusion')
        
        # 获取特定题目的信息 - 使用简化的查询
        conn = db.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT qs.id, qs.student_answer, qs.correct_answer, qs.question_type, 
                   qs.question_text, qs.max_score, qs.is_ai_graded
            FROM question_scores qs
            WHERE qs.id = ?
        """, (question_score_id,))
        
        question_data = cursor.fetchone()
        
        if not question_data:
            return jsonify({
                'success': False,
                'message': '题目不存在'
            })
        
        # 解析字段
        qs_id, student_answer, correct_answer, question_type, question_text, max_score, is_ai_graded = question_data
        
        # 检查是否是主观题 - 与database.py保持一致，只排除choice和judge类型
        if question_type in ['choice', 'judge']:
            return jsonify({
                'success': False,
                'message': '该题目是客观题，无需AI评分'
            })
        
        # 准备评分数据
        student_answer = student_answer or ''
        reference_answer = correct_answer or ''
        question_text = question_text or ''
        max_score = float(max_score or 5.0)
        
        # 初始化统一评分引擎
        grading_engine = get_grading_engine()
        
        # 进行AI评分 - 使用指定的方法
        grading_result = grading_engine.grade(
            question_type=question_type,
            student_answer=student_answer,
            reference_answer=reference_answer,
            question_text=question_text,
            max_score=max_score,
            method=method
        )
        
        # 保存AI评分结果
        ai_results = [{
            'question_score_id': question_score_id,
            'ai_result': grading_result
        }]
        
        save_result = db.batch_save_ai_grading_results(ai_results)
        
        if save_result['success_count'] > 0:
            # 从grading_result中提取详细信息
            result_data = {
                'score': grading_result['score'],
                'confidence': grading_result['confidence'],
                'feedback': grading_result['feedback'],
                'method': grading_result.get('method', 'ai_grading'),
                'max_score': max_score
            }
            
            # 添加详细评分信息
            details = grading_result.get('details', {})
            
            # 评分详细信息
            if details:
                result_data['grading_details'] = details
            
            # 评分策略说明
            if grading_result.get('reasoning'):
                result_data['score_selection_reason'] = grading_result['reasoning']
            
            # 详细分析（如果有）
            if details:
                analysis_parts = []
                
                # 从details中提取语义分析结果
                semantic_result = details.get('semantic_result', {})
                if semantic_result and isinstance(semantic_result, dict) and semantic_result.get('details'):
                    semantic_details = semantic_result['details']
                    if isinstance(semantic_details, dict):
                        analysis_parts.append(f"语义相似度: {semantic_details.get('semantic_similarity', 0):.2f}")
                        analysis_parts.append(f"完整性: {semantic_details.get('completeness', 0):.2f}")
                
                # 从details中提取AI结果
                ai_result = details.get('ai_result', {})
                if ai_result and isinstance(ai_result, dict) and ai_result.get('details'):
                    ai_details = ai_result['details']
                    if isinstance(ai_details, dict) and 'reasoning' in ai_details:
                        analysis_parts.append(f"AI推理: {ai_details['reasoning']}")
                
                if analysis_parts:
                    result_data['detailed_analysis'] = "; ".join(analysis_parts)
                
                # 组合策略信息
                strategy = details.get('combination_strategy', 'unknown')
                if strategy == 'take_higher':
                    result_data['combination_strategy'] = '取高分策略'
                elif strategy == 'weighted_average':
                    result_data['combination_strategy'] = '加权平均策略'
            
            # --- 新增逻辑：总分调整 ---
            # 获取该题目所属的考试和学生ID
            try:
                conn = db.get_connection()
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT er.exam_id, er.student_id 
                    FROM exam_results er
                    JOIN question_scores qs ON qs.exam_result_id = er.id
                    WHERE qs.id = ?
                ''', (question_score_id,))
                er_row = cursor.fetchone()
                
                if er_row:
                    exam_id_val = er_row[0]
                    student_id_val = er_row[1]
                    # 尝试调整总分范围 (64-85)
                    adjust_success, adjust_msg = adjust_student_total_score(db, exam_id_val, student_id_val, 64, 85)
                    if adjust_success:
                        print(f"[SCORE_ADJUST] 学生 {student_id_val} 分数调整成功: {adjust_msg}")
                        # 由于调整后该题分数可能变化，重新获取最新分数返回给前端
                        cursor.execute('SELECT score FROM question_scores WHERE id = ?', (question_score_id,))
                        new_qs_row = cursor.fetchone()
                        if new_qs_row:
                            result_data['score'] = new_qs_row[0]
            except Exception as adj_err:
                print(f"[SCORE_ADJUST_ERROR] 调整分数出错: {adj_err}")
            # ------------------------

            return jsonify({
                'success': True,
                'message': f'AI评分完成！得分：{result_data["score"]}/{max_score}',
                'result': result_data
            })
        else:
            return jsonify({
                'success': False,
                'message': '保存AI评分结果失败'
            })
        
    except Exception as e:
        print(f"Single AI grading error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'单个AI评分失败: {str(e)}'
        })

@teacher_bp.route('/grading/manual-adjust', methods=['POST'])
@login_required  
def manual_adjust_grading():
    """手动调整评分，并返回更新后的总分 - 支持JSON和表单数据"""
    try:
        db = Database()
        
        # 检查请求数据类型
        if request.is_json:
            # JSON数据
            data = request.get_json()
            question_score_id = data.get('question_score_id')
            new_score_raw = data.get('new_score')
            comment = data.get('comment', '')
        else:
            # 表单数据
            question_score_id = request.form.get('question_score_id')
            new_score_raw = request.form.get('new_score')
            comment = request.form.get('comment', '')
        
        # 验证必要参数
        if not question_score_id:
            return jsonify({'success': False, 'message': '缺少题目ID'})
        
        if new_score_raw is None or new_score_raw == '':
            return jsonify({'success': False, 'message': '缺少分数参数'})
        
        # 安全转换分数
        try:
            new_score = float(new_score_raw)
        except (ValueError, TypeError) as e:
            return jsonify({'success': False, 'message': f'分数格式错误: {new_score_raw}'})
        
        # 验证分数范围
        if new_score < 0:
            return jsonify({'success': False, 'message': '分数不能为负数'})
        
        graded_by = current_user.username or '教师'
        
        # 获取题目信息以验证最大分数
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT max_score FROM question_scores WHERE id = ?', (question_score_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({'success': False, 'message': '找不到该题目记录'})
            
            max_score = result[0]
            if new_score > max_score:
                return jsonify({'success': False, 'message': f'分数不能超过满分 {max_score}'})
        
        # 更新评分
        success, exam_result_id = db.update_question_score(int(question_score_id), new_score, graded_by, comment)
        
        if success:
            # 重新计算总分和状态
            new_total_score = db.recalculate_exam_score(exam_result_id)
            
            return jsonify({
                'success': True,
                'message': '评分调整成功',
                'new_total_score': new_total_score,
                'new_score': new_score
            })
        else:
            return jsonify({
                'success': False,
                'message': '评分调整失败'
            })
        
    except Exception as e:
        print(f"Manual adjust grading error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'调整评分失败: {str(e)}'
        })

@teacher_bp.route('/grading/update-answer-and-score', methods=['POST'])
@login_required
def update_answer_and_score():
    """更新学生答案和分数"""
    try:
        print(f"[DEBUG] 收到更新请求")
        print(f"[DEBUG] 请求数据: {request.form}")
        
        db = Database()
        
        # 获取数据
        question_score_id = request.form.get('question_score_id')
        new_score = float(request.form.get('new_score'))
        new_answer = request.form.get('new_answer', '')
        graded_by = current_user.username or '教师'
        
        print(f"[DEBUG] 解析数据: question_score_id={question_score_id}, new_score={new_score}, new_answer={new_answer}")
        
        if not question_score_id:
            return jsonify({'success': False, 'message': '缺少题目ID'})
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 先获取当前记录信息
            cursor.execute('''
                SELECT exam_result_id, question_id, max_score
                FROM question_scores
                WHERE id = ?
            ''', (question_score_id,))
            
            result = cursor.fetchone()
            if not result:
                return jsonify({'success': False, 'message': '找不到该题目记录'})
            
            exam_result_id, question_id, max_score = result
            
            # 验证分数
            if new_score > max_score:
                return jsonify({'success': False, 'message': f'分数不能超过满分 {max_score}'})
            
            if new_score < 0:
                return jsonify({'success': False, 'message': '分数不能为负数'})
            
            # 获取题目类型
            cursor.execute('''
                SELECT question_type FROM question_scores WHERE id = ?
            ''', (question_score_id,))
            question_type = cursor.fetchone()[0]
            
            # 处理判断题答案格式
            if question_type == 'judge':
                # 将中文答案转换为英文格式（与系统保持一致）
                if new_answer == '对':
                    new_answer = 'True'
                elif new_answer == '错':
                    new_answer = 'False'
            
            # 更新答案和分数
            cursor.execute('''
                UPDATE question_scores
                SET student_answer = ?,
                    score = ?,
                    is_manually_graded = 1,
                    graded_by = ?,
                    updated_at = datetime('now')
                WHERE id = ?
            ''', (new_answer, new_score, graded_by, question_score_id))
            
            conn.commit()
            
            print(f"[DEBUG] 题目分数更新成功: question_score_id={question_score_id}")
            
        # 重新计算总分（在with块外面，使用新的连接）
        new_total_score = db.recalculate_exam_score(exam_result_id)
        
        # 再次获取连接来更新答案
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 同时更新exam_results表中的答案（如果存储了JSON格式的答案）
            try:
                cursor.execute('''
                    SELECT answers FROM exam_results WHERE id = ?
                ''', (exam_result_id,))
                
                answers_result = cursor.fetchone()
                if answers_result and answers_result[0]:
                    import json
                    try:
                        answers = json.loads(answers_result[0])
                    except:
                        # 如果不是JSON格式，创建新的字典
                        answers = {}
                    
                    # 更新对应题目的答案，使用 question_<id> 格式的键
                    question_key = f'question_{question_id}'
                    answers[question_key] = new_answer
                    
                    cursor.execute('''
                        UPDATE exam_results
                        SET answers = ?
                        WHERE id = ?
                    ''', (json.dumps(answers, ensure_ascii=False), exam_result_id))
                    
                    conn.commit()
                else:
                    # 如果没有答案记录，创建新的
                    import json
                    answers = {f'question_{question_id}': new_answer}
                    cursor.execute('''
                        UPDATE exam_results
                        SET answers = ?
                        WHERE id = ?
                    ''', (json.dumps(answers, ensure_ascii=False), exam_result_id))
                    
                    conn.commit()
            except Exception as e:
                print(f"更新exam_results答案时出错: {e}")
                import traceback
                traceback.print_exc()
                # 不影响主要功能
            
            return jsonify({
                'success': True,
                'message': '答案和分数更新成功',
                'new_total_score': new_total_score
            })
        
    except Exception as e:
        print(f"Update answer and score error: {e}")
        return jsonify({
            'success': False,
            'message': f'更新失败: {str(e)}'
        })

@teacher_bp.route('/grading/batch-adjust', methods=['POST'])
@login_required
def batch_adjust_grading():
    """批量调整评分"""
    try:
        db = Database()
        
        # 获取批量调整数据
        adjustments = request.get_json()
        if not adjustments or 'adjustments' not in adjustments:
            return jsonify({'success': False, 'message': '无效的调整数据'})
        
        # 准备更新数据
        score_updates = []
        graded_by = current_user.username or '教师'
        
        for adj in adjustments['adjustments']:
            score_updates.append({
                'question_score_id': adj['question_score_id'],
                'new_score': float(adj['new_score']),
                'graded_by': graded_by,
                'comment': adj.get('comment', '')
            })
        
        # 批量更新
        result = db.batch_update_question_scores(score_updates)
        
        return jsonify({
            'success': True,
            'message': f'批量调整完成！成功 {result["success_count"]} 题，失败 {result["failed_count"]} 题',
            'details': result
        })
        
    except Exception as e:
        print(f"Batch adjust grading error: {e}")
        return jsonify({
            'success': False,
            'message': f'批量调整失败: {str(e)}'
        })

@teacher_bp.route('/grading/statistics/<int:exam_id>')
@login_required
def grading_statistics(exam_id):
    """获取评分统计信息"""
    try:
        db = Database()
        
        # 获取AI评分统计
        ai_stats = db.get_ai_grading_statistics(exam_id)
        
        # 获取题目统计
        question_stats = db.get_question_statistics(exam_id)
        
        return jsonify({
            'success': True,
            'ai_stats': ai_stats,
            'question_stats': question_stats
        })
        
    except Exception as e:
        print(f"Grading statistics error: {e}")
        return jsonify({
            'success': False,
            'message': f'获取统计失败: {str(e)}'
        })

# ===== 新增：成绩导出和统计分析功能 =====

@teacher_bp.route('/exams/<int:exam_id>/cleanup-duplicates', methods=['POST'])
@login_required
def cleanup_duplicate_results(exam_id):
    """清理重复的考试记录，保留分数最高的一条"""
    try:
        db = Database()
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        cleaned_count = 0
        students_affected = 0
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. 查找有重复记录的学生
            cursor.execute('''
                SELECT student_id, COUNT(*) as count
                FROM exam_results
                WHERE exam_id = ?
                GROUP BY student_id
                HAVING count > 1
            ''', (exam_id,))
            
            duplicate_students = cursor.fetchall()
            
            for row in duplicate_students:
                student_id = row[0]
                
                # 2. 获取该学生的所有记录
                cursor.execute('''
                    SELECT id, score, is_completed, end_time, start_time
                    FROM exam_results
                    WHERE exam_id = ? AND student_id = ?
                ''', (exam_id, student_id))
                
                records = []
                for r in cursor.fetchall():
                    records.append({
                        'id': r[0],
                        'score': r[1] or 0.0,
                        'is_completed': 1 if r[2] else 0,
                        'end_time': r[3] or '',
                        'start_time': r[4] or ''
                    })
                
                # 3. 排序策略：
                # 优先级1：分数高优先 (desc)
                # 优先级2：已完成优先 (desc)
                # 优先级3：结束时间晚优先 (desc)
                # 优先级4：开始时间晚优先 (desc)
                records.sort(key=lambda x: (
                    x['score'], 
                    x['is_completed'], 
                    x['end_time'],
                    x['start_time']
                ), reverse=True)
                
                # 保留第一个，删除其余的
                keep_record = records[0]
                delete_records = records[1:]
                
                if delete_records:
                    students_affected += 1
                    for rec in delete_records:
                        rec_id = rec['id']
                        # 删除关联的题目得分
                        cursor.execute('DELETE FROM question_scores WHERE exam_result_id = ?', (rec_id,))
                        # 删除考试结果记录
                        cursor.execute('DELETE FROM exam_results WHERE id = ?', (rec_id,))
                        cleaned_count += 1
            
            conn.commit()
            
        return jsonify({
            'success': True, 
            'message': f'清理完成：处理了 {students_affected} 名学生的重复记录，删除了 {cleaned_count} 条多余数据'
        })
        
    except Exception as e:
        print(f"[ERROR] 清理重复记录失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'清理失败: {str(e)}'})

@teacher_bp.route('/results/export')
@login_required
def export_results():
    """导出考试成绩为CSV - 支持详细导出、基础导出和按题型导出"""
    try:
        print(f"=== 开始导出成绩 ===")
        
        # 获取请求参数
        export_type = request.args.get('export_type', 'basic')  # basic, detailed, by_question_type
        encoding = request.args.get('encoding', 'utf-8')  # utf-8 或 gbk
        exam_id_filter = request.args.get('exam_id')
        status_filter = request.args.get('status')
        
        print(f"导出参数: type={export_type}, encoding={encoding}, exam_filter={exam_id_filter}, status_filter={status_filter}")
        
        db = Database()
        exam_results = db.get_exam_results()
        print(f"原始成绩记录数: {len(exam_results)}")
        
        # 应用筛选条件
        if exam_id_filter:
            exam_results = [r for r in exam_results if str(getattr(r, 'exam_id', r.get('exam_id', 0))) == str(exam_id_filter)]
            print(f"按考试筛选后记录数: {len(exam_results)}")
        
        if status_filter == 'completed':
            exam_results = [r for r in exam_results if getattr(r, 'is_completed', r.get('is_completed', False))]
            print(f"按完成状态筛选后记录数: {len(exam_results)}")
        elif status_filter == 'incomplete':
            exam_results = [r for r in exam_results if not getattr(r, 'is_completed', r.get('is_completed', False))]
            print(f"按未完成状态筛选后记录数: {len(exam_results)}")
        
        if not exam_results:
            print("没有符合条件的成绩数据")
            return jsonify({'success': False, 'message': '没有符合条件的成绩数据可导出'})
        
        # 获取关联数据 - 修复students字典键的映射
        all_students = db.get_all_students()
        students = {}
        for s in all_students:
            # 使用数据库内部ID作为键（与exam_results中的student_id对应）
            students[s.id] = s
            # 同时支持学号查找
            students[s.student_id] = s
        
        exams = {e.id: e for e in db.get_exams()}
        print(f"学生数据: {len(all_students)} 个学生，{len(exams)} 个考试")
        
        # 创建CSV内容
        import io
        import csv
        from datetime import datetime
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        print(f"开始{export_type}导出...")
        
        if export_type == 'detailed':
            # 详细导出：包含每道题目的得分
            success_results = export_detailed_results(writer, exam_results, students, exams, db)
        elif export_type == 'by_question_type':
            # 按题型导出：按题型分组显示得分
            success_results = export_by_question_type_results(writer, exam_results, students, exams, db)
        else:
            # 基础导出：只包含总成绩
            success_results = export_basic_results(writer, exam_results, students, exams)
        
        print(f"导出结果: {success_results}")
        
        if not success_results:
            return jsonify({'success': False, 'message': '导出过程中发生错误，请查看服务器日志获取详细信息'})
        
        output.seek(0)
        csv_content = output.getvalue()
        output.close()
        
        print(f"CSV内容长度: {len(csv_content)}")
        
        # 根据编码选择处理文件内容
        if encoding == 'gbk':
            try:
                csv_bytes = csv_content.encode('gbk')
                encoding_suffix = '_GBK'
                print(f"使用GBK编码成功")
            except UnicodeEncodeError as e:
                print(f"GBK编码失败，回退到UTF-8: {e}")
                # 如果GBK编码失败，回退到UTF-8
                csv_bytes = csv_content.encode('utf-8-sig')
                encoding_suffix = '_UTF8'
        else:
            csv_bytes = csv_content.encode('utf-8-sig')
            encoding_suffix = '_UTF8'
            print(f"使用UTF-8编码")
        
        # 生成文件名
        if export_type == 'detailed':
            type_suffix = '_详细'
        elif export_type == 'by_question_type':
            type_suffix = '_按题型'
        else:
            type_suffix = '_基础'
            
        filename = f'exam_results{type_suffix}{encoding_suffix}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        print(f"生成文件名: {filename}")
        
        # 创建响应
        response = send_file(
            io.BytesIO(csv_bytes),
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )
        
        print(f"=== 导出成功完成 ===")
        return response
        
    except Exception as e:
        print(f"Export results error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'导出失败: {str(e)}'})

def export_basic_results(writer, exam_results, students, exams):
    """导出基础成绩表"""
    try:
        print(f"=== 开始基础导出，记录数: {len(exam_results)} ===")
        
        # 写入标题行
        writer.writerow([
            '考试ID', '考试名称', '学生学号', '学生姓名', '学院', '专业', '班级',
            '成绩', '满分', '得分率', '开始时间', '结束时间', '用时(分钟)', '状态'
        ])
        
        # 写入数据行
        processed_count = 0
        for result in exam_results:
            try:
                # 处理结果数据（不论是字典还是对象）
                if isinstance(result, dict):
                    processed_result = result.copy()
                else:
                    processed_result = {
                        'exam_id': getattr(result, 'exam_id', 0),
                        'student_id': getattr(result, 'student_id', ''),
                        'score': getattr(result, 'score', 0.0),
                        'is_completed': getattr(result, 'is_completed', False),
                        'start_time': getattr(result, 'start_time', ''),
                        'end_time': getattr(result, 'end_time', '')
                    }
                
                # 获取基础字段
                exam_id = processed_result.get('exam_id', 0)
                student_id = processed_result.get('student_id', '')
                score = processed_result.get('score', 0.0) or 0.0
                is_completed = processed_result.get('is_completed', False)
                start_time = processed_result.get('start_time', '')
                end_time = processed_result.get('end_time', '')
                
                # 获取学生信息 - 优先使用数据库JOIN返回的信息
                student_name = processed_result.get('student_name', 'N/A')
                student_number = processed_result.get('student_number', str(student_id))
                student_college = processed_result.get('college', '')
                student_major = processed_result.get('major', '')
                student_class = processed_result.get('class_name', '')
                
                # 如果数据库JOIN信息不完整，尝试从students字典获取
                if student_name == 'N/A' or not student_name:
                    student = students.get(student_id) or students.get(str(student_id))
                    if student:
                        try:
                            student_name = getattr(student, 'name', 'N/A') or 'N/A'
                            student_number = getattr(student, 'student_id', str(student_id)) or str(student_id)
                            student_college = getattr(student, 'college', '') or ''
                            student_major = getattr(student, 'major', '') or ''
                            student_class = getattr(student, 'class_name', '') or ''
                        except Exception as e:
                            print(f"处理学生对象时出错 (student_id={student_id}): {e}")
                            # 保持原有值不变
                
                # 获取考试信息 - 优先使用数据库JOIN返回的信息
                exam_title = processed_result.get('exam_title', f'考试{exam_id}')
                
                # 如果数据库JOIN信息不完整，尝试从exams字典获取
                if not exam_title or exam_title == f'考试{exam_id}':
                    exam = exams.get(exam_id)
                    if exam:
                        exam_title = exam.title or f'考试{exam_id}'
                
                # 计算用时
                duration_minutes = ''
                if start_time and end_time:
                    try:
                        from datetime import datetime
                        if isinstance(start_time, str) and isinstance(end_time, str):
                            start_dt = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
                            end_dt = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
                            duration = (end_dt - start_dt).total_seconds() / 60
                            duration_minutes = f"{duration:.1f}"
                    except Exception as time_error:
                        print(f"时间计算错误: {time_error}")
                        duration_minutes = ''
                
                # 获取满分 - 优先使用数据库返回的总分
                max_score = processed_result.get('exam_total_score', 100.0)
                if not max_score or max_score <= 0:
                    max_score = processed_result.get('total_score', 100.0)
                if not max_score or max_score <= 0:
                    exam = exams.get(exam_id)
                    if exam and hasattr(exam, 'total_score') and exam.total_score:
                        max_score = float(exam.total_score)
                    else:
                        max_score = 100.0
                
                # 计算得分率
                score_rate = f"{(score / max_score * 100):.1f}%" if max_score > 0 else "0.0%"
                
                writer.writerow([
                    exam_id,
                    exam_title,
                    student_number,
                    student_name,
                    student_college,
                    student_major,
                    student_class,
                    f"{score:.1f}",
                    f"{max_score:.1f}",
                    score_rate,
                    start_time[:19] if start_time else '',
                    end_time[:19] if end_time else '',
                    duration_minutes,
                    '已完成' if is_completed else '进行中'
                ])
                
                processed_count += 1
                
            except Exception as row_error:
                print(f"处理第{processed_count + 1}行数据时出错: {row_error}")
                continue
        
        print(f"基础导出完成，成功处理 {processed_count} 行数据")
        return True
        
    except Exception as e:
        print(f"Export basic results error: {e}")
        import traceback
        traceback.print_exc()
        return False

def export_detailed_results(writer, exam_results, students, exams, db):
    """导出详细成绩表（包含每道题目得分）"""
    try:
        print(f"=== 开始详细导出，记录数: {len(exam_results)} ===")
        
        # 获取所有题目分数记录
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # 查询所有相关的题目得分记录
        exam_ids = []
        for result in exam_results:
            try:
                if isinstance(result, dict):
                    exam_id = result.get('exam_id', 0)
                else:
                    exam_id = getattr(result, 'exam_id', 0)
                if exam_id and exam_id not in exam_ids:
                    exam_ids.append(exam_id)
            except Exception as e:
                print(f"获取exam_id时出错: {e}")
                continue
        
        print(f"需要查询的考试ID: {exam_ids}")
        
        if not exam_ids:
            print("没有有效的考试ID，回退到基础导出")
            return export_basic_results(writer, exam_results, students, exams)
        
        # 构建SQL查询
        placeholders = ','.join(['?' for _ in exam_ids])
        query = f"""
            SELECT 
                er.exam_id,
                er.student_id,
                qs.question_text,
                qs.question_type,
                qs.student_answer,
                qs.correct_answer,
                qs.max_score,
                COALESCE(qs.score, qs.ai_score, 0) as current_score,
                qs.is_ai_graded,
                qs.is_manually_graded,
                qs.ai_feedback,
                qs.grade_comment,
                er.score as total_score,
                er.is_completed,
                er.start_time,
                er.end_time,
                qs.question_order
            FROM question_scores qs
            JOIN exam_results er ON qs.exam_result_id = er.id
            WHERE er.exam_id IN ({placeholders})
            ORDER BY er.exam_id, er.student_id, qs.question_order
        """
        
        print(f"执行SQL查询...")
        cursor.execute(query, exam_ids)
        detailed_records = cursor.fetchall()
        print(f"查询到详细记录数: {len(detailed_records)}")
        
        if not detailed_records:
            print("没有详细记录，回退到基础导出")
            # 如果没有详细记录，回退到基础导出
            return export_basic_results(writer, exam_results, students, exams)
        
        # 写入标题行
        writer.writerow([
            '考试ID', '考试名称', '学生学号', '学生姓名', '学院', '专业', '班级',
            '题目序号', '题目类型', '题目内容(前50字)', '学生答案(前100字)', '参考答案(前100字)',
            '题目分值', '获得分数', '评分方式', 'AI反馈(前100字)', '教师备注(前100字)',
            '总成绩', '考试状态', '开始时间', '结束时间'
        ])
        
        # 创建学生信息映射表，以student_id为键
        student_info_map = {}
        for result in exam_results:
            if isinstance(result, dict):
                student_id = result.get('student_id')
                if student_id and student_id not in student_info_map:
                    student_info_map[student_id] = {
                        'student_name': result.get('student_name', 'N/A'),
                        'student_number': result.get('student_number', str(student_id)),
                        'college': result.get('college', ''),
                        'major': result.get('major', ''),
                        'class_name': result.get('class_name', ''),
                        'gender': result.get('gender', '')
                    }
        
        # 补充从students字典获取信息
        for student_id, student in students.items():
            if student_id not in student_info_map:
                # 确保student对象有正确的属性
                try:
                    student_info_map[student_id] = {
                        'student_name': getattr(student, 'name', 'N/A') or 'N/A',
                        'student_number': getattr(student, 'student_id', str(student_id)) or str(student_id),
                        'college': getattr(student, 'college', '') or '',
                        'major': getattr(student, 'major', '') or '',
                        'class_name': getattr(student, 'class_name', '') or '',
                        'gender': getattr(student, 'gender', '') or ''
                    }
                except Exception as e:
                    print(f"处理学生信息时出错 (student_id={student_id}): {e}")
                    student_info_map[student_id] = {
                        'student_name': 'N/A',
                        'student_number': str(student_id),
                        'college': '',
                        'major': '',
                        'class_name': '',
                        'gender': ''
                    }
        
        # 处理详细记录
        processed_count = 0
        
        for record in detailed_records:
            try:
                (exam_id, student_id, question_text, question_type, student_answer, 
                 correct_answer, max_score, current_score, is_ai_graded, is_manually_graded,
                 ai_feedback, grade_comment, total_score, is_completed, start_time, end_time, question_order) = record
                
                # 获取学生信息
                student_info = student_info_map.get(student_id, {})
                student_name = student_info.get('student_name', 'N/A')
                student_number = student_info.get('student_number', str(student_id))
                student_college = student_info.get('college', '')
                student_major = student_info.get('major', '')
                student_class = student_info.get('class_name', '')
                
                # 获取考试信息
                exam = exams.get(exam_id)
                exam_title = exam.title if exam else f'考试{exam_id}'
                
                # 确定评分方式
                grading_method = ''
                if is_manually_graded:
                    grading_method = '手动评分'
                elif is_ai_graded:
                    grading_method = 'AI评分'
                else:
                    grading_method = '自动评分'
                
                # 处理文本长度，确保安全
                question_text_short = ''
                if question_text:
                    question_text_short = (question_text[:50] + '...') if len(question_text) > 50 else question_text
                
                student_answer_short = '未作答'
                if student_answer:
                    student_answer_short = (student_answer[:100] + '...') if len(student_answer) > 100 else student_answer
                
                correct_answer_short = ''
                if correct_answer:
                    correct_answer_short = (correct_answer[:100] + '...') if len(correct_answer) > 100 else correct_answer
                
                ai_feedback_short = ''
                if ai_feedback:
                    ai_feedback_short = (ai_feedback[:100] + '...') if len(ai_feedback) > 100 else ai_feedback
                
                grade_comment_short = ''
                if grade_comment:
                    grade_comment_short = (grade_comment[:100] + '...') if len(grade_comment) > 100 else grade_comment
                
                writer.writerow([
                    exam_id,
                    exam_title,
                    student_number,
                    student_name,
                    student_college,
                    student_major,
                    student_class,
                    question_order or (processed_count + 1),  # 使用数据库的question_order或序号
                    question_type or '',
                    question_text_short,
                    student_answer_short,
                    correct_answer_short,
                    f"{max_score:.1f}" if max_score else '0.0',
                    f"{current_score:.1f}" if current_score else '0.0',
                    grading_method,
                    ai_feedback_short,
                    grade_comment_short,
                    f"{total_score:.1f}" if total_score else '0.0',
                    '已完成' if is_completed else '进行中',
                    start_time[:19] if start_time else '',
                    end_time[:19] if end_time else ''
                ])
                
                processed_count += 1
                
            except Exception as row_error:
                print(f"处理详细记录第{processed_count + 1}行时出错: {row_error}")
                continue
        
        print(f"详细导出完成，成功处理 {processed_count} 行数据")
        return True
        
    except Exception as e:
        print(f"Export detailed results error: {e}")
        import traceback
        traceback.print_exc()
        return False

def export_by_question_type_results(writer, exam_results, students, exams, db):
    """按题型导出成绩表（每种题型一列显示得分/满分）"""
    try:
        print(f"=== 开始按题型导出，记录数: {len(exam_results)} ===")
        
        # 获取所有题目分数记录
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # 查询所有相关的题目得分记录
        exam_ids = []
        for result in exam_results:
            try:
                if isinstance(result, dict):
                    exam_id = result.get('exam_id', 0)
                else:
                    exam_id = getattr(result, 'exam_id', 0)
                if exam_id and exam_id not in exam_ids:
                    exam_ids.append(exam_id)
            except Exception as e:
                print(f"获取exam_id时出错: {e}")
                continue
        
        print(f"需要查询的考试ID: {exam_ids}")
        
        if not exam_ids:
            print("没有有效的考试ID，回退到基础导出")
            return export_basic_results(writer, exam_results, students, exams)
        
        # 查询所有题型
        placeholders = ','.join(['?' for _ in exam_ids])
        cursor.execute(f"""
            SELECT DISTINCT qs.question_type
            FROM question_scores qs
            JOIN exam_results er ON qs.exam_result_id = er.id
            WHERE er.exam_id IN ({placeholders})
            ORDER BY qs.question_type
        """, exam_ids)
        question_types = [row[0] for row in cursor.fetchall()]
        print(f"发现的题型: {question_types}")
        
        if not question_types:
            print("没有找到题型，回退到基础导出")
            return export_basic_results(writer, exam_results, students, exams)
        
        # 构建题型中文名称映射
        type_names = {
            'choice': '选择题',
            'judge': '判断题', 
            'essay': '简答题',
            'short_answer': '简答题',
            'fill_blank': '填空题',
            'code_reading': '代码阅读',
            'code_practice': '代码实践',
            'programming': '编程题',
            'analysis': '分析题',
            'practice': '实践题'
        }
        
        # 构建标题行
        header = ['考试ID', '考试名称', '学生学号', '学生姓名', '学院', '专业', '班级']
        for q_type in question_types:
            type_name = type_names.get(q_type, q_type)
            header.extend([f'{type_name}_得分', f'{type_name}_满分'])
        header.extend(['总得分', '总满分', '得分率(%)', '考试状态', '开始时间', '结束时间'])
        
        writer.writerow(header)
        print(f"标题行包含 {len(header)} 列")
        
        # 构建SQL查询，按考试和学生分组统计各题型得分
        query = f"""
            SELECT 
                er.exam_id,
                er.student_id,
                qs.question_type,
                SUM(COALESCE(qs.score, qs.ai_score, 0)) as type_score,
                SUM(qs.max_score) as type_max_score,
                er.score as total_score,
                er.is_completed,
                er.start_time,
                er.end_time
            FROM question_scores qs
            JOIN exam_results er ON qs.exam_result_id = er.id
            WHERE er.exam_id IN ({placeholders})
            GROUP BY er.exam_id, er.student_id, qs.question_type
            ORDER BY er.exam_id, er.student_id, qs.question_type
        """
        
        print(f"执行按题型分组查询...")
        cursor.execute(query, exam_ids)
        type_scores = cursor.fetchall()
        print(f"查询到按题型分组记录数: {len(type_scores)}")
        
        # 组织数据：按(exam_id, student_id)分组
        student_scores = {}
        for record in type_scores:
            exam_id, student_id, question_type, type_score, type_max_score, total_score, is_completed, start_time, end_time = record
            
            key = (exam_id, student_id)
            if key not in student_scores:
                student_scores[key] = {
                    'exam_id': exam_id,
                    'student_id': student_id,
                    'total_score': total_score,
                    'is_completed': is_completed,
                    'start_time': start_time,
                    'end_time': end_time,
                    'type_scores': {}
                }
            
            student_scores[key]['type_scores'][question_type] = {
                'score': type_score or 0.0,
                'max_score': type_max_score or 0.0
            }
        
        print(f"整理后的学生成绩记录数: {len(student_scores)}")
        
        # 创建学生信息映射表
        student_info_map = {}
        for result in exam_results:
            if isinstance(result, dict):
                student_id = result.get('student_id')
                if student_id and student_id not in student_info_map:
                    student_info_map[student_id] = {
                        'student_name': result.get('student_name', 'N/A'),
                        'student_number': result.get('student_number', str(student_id)),
                        'college': result.get('college', ''),
                        'major': result.get('major', ''),
                        'class_name': result.get('class_name', ''),
                    }
        
        # 补充从students字典获取信息
        for student_id, student in students.items():
            if student_id not in student_info_map:
                try:
                    student_info_map[student_id] = {
                        'student_name': getattr(student, 'name', 'N/A') or 'N/A',
                        'student_number': getattr(student, 'student_id', str(student_id)) or str(student_id),
                        'college': getattr(student, 'college', '') or '',
                        'major': getattr(student, 'major', '') or '',
                        'class_name': getattr(student, 'class_name', '') or '',
                    }
                except Exception as e:
                    print(f"处理学生信息时出错 (student_id={student_id}): {e}")
                    student_info_map[student_id] = {
                        'student_name': 'N/A',
                        'student_number': str(student_id),
                        'college': '',
                        'major': '',
                        'class_name': '',
                    }
        
        # 写入数据行
        processed_count = 0
        for (exam_id, student_id), score_data in student_scores.items():
            try:
                # 获取学生信息
                student_info = student_info_map.get(student_id, {})
                student_name = student_info.get('student_name', 'N/A')
                student_number = student_info.get('student_number', str(student_id))
                student_college = student_info.get('college', '')
                student_major = student_info.get('major', '')
                student_class = student_info.get('class_name', '')
                
                # 获取考试信息
                exam = exams.get(exam_id)
                exam_title = exam.title if exam else f'考试{exam_id}'
                
                # 构建数据行
                row = [
                    exam_id,
                    exam_title,
                    student_number,
                    student_name,
                    student_college,
                    student_major,
                    student_class
                ]
                
                # 添加各题型得分
                total_max_score = 0.0
                for q_type in question_types:
                    type_data = score_data['type_scores'].get(q_type, {'score': 0.0, 'max_score': 0.0})
                    row.append(f"{type_data['score']:.1f}")
                    row.append(f"{type_data['max_score']:.1f}")
                    total_max_score += type_data['max_score']
                
                # 添加总分信息
                total_score = score_data['total_score'] or 0.0
                score_rate = (total_score / total_max_score * 100) if total_max_score > 0 else 0.0
                
                row.extend([
                    f"{total_score:.1f}",
                    f"{total_max_score:.1f}",
                    f"{score_rate:.1f}",
                    '已完成' if score_data['is_completed'] else '进行中',
                    score_data['start_time'][:19] if score_data['start_time'] else '',
                    score_data['end_time'][:19] if score_data['end_time'] else ''
                ])
                
                writer.writerow(row)
                processed_count += 1
                
            except Exception as row_error:
                print(f"处理第{processed_count + 1}行数据时出错: {row_error}")
                continue
        
        print(f"按题型导出完成，成功处理 {processed_count} 行数据")
        return True
        
    except Exception as e:
        print(f"Export by question type results error: {e}")
        import traceback
        traceback.print_exc()
        return False

@teacher_bp.route('/results/statistics')
@login_required
def get_results_statistics():
    """获取成绩统计数据（用于图表）"""
    try:
        db = Database()
        exam_results = db.get_exam_results()
        
        # 初始化统计数据
        statistics = {
            'score_distribution': {
                '90-100': 0, '80-89': 0, '70-79': 0, 
                '60-69': 0, '50-59': 0, '0-49': 0
            },
            'exam_statistics': {},
            'completion_rate': 0,
            'average_score': 0,
            'total_students': 0,
            'total_completed': 0
        }
        
        if not exam_results:
            return jsonify({'success': True, 'statistics': statistics})
        
        # 获取考试信息
        exams = {e.id: e for e in db.get_exams()}
        
        # 处理每个成绩记录
        total_score = 0
        completed_count = 0
        total_count = len(exam_results)
        
        for result in exam_results:
            # 兼容字典和对象
            if isinstance(result, dict):
                exam_id = result.get('exam_id', 0)
                score = result.get('score', 0.0) or 0.0
                is_completed = result.get('is_completed', False)
            else:
                exam_id = getattr(result, 'exam_id', 0)
                score = getattr(result, 'score', 0.0) or 0.0
                is_completed = getattr(result, 'is_completed', False)
            
            # 统计已完成的考试
            if is_completed:
                completed_count += 1
                total_score += score
                
                # 分数段统计
                if score >= 90:
                    statistics['score_distribution']['90-100'] += 1
                elif score >= 80:
                    statistics['score_distribution']['80-89'] += 1
                elif score >= 70:
                    statistics['score_distribution']['70-79'] += 1
                elif score >= 60:
                    statistics['score_distribution']['60-69'] += 1
                elif score >= 50:
                    statistics['score_distribution']['50-59'] += 1
                else:
                    statistics['score_distribution']['0-49'] += 1
            
            # 按考试统计
            exam = exams.get(exam_id)
            exam_title = exam.title if exam else f'考试{exam_id}'
            
            if exam_title not in statistics['exam_statistics']:
                statistics['exam_statistics'][exam_title] = {
                    'total': 0,
                    'completed': 0,
                    'average_score': 0,
                    'total_score': 0
                }
            
            statistics['exam_statistics'][exam_title]['total'] += 1
            if is_completed:
                statistics['exam_statistics'][exam_title]['completed'] += 1
                statistics['exam_statistics'][exam_title]['total_score'] += score
        
        # 计算平均分和完成率
        if completed_count > 0:
            statistics['average_score'] = round(total_score / completed_count, 1)
        
        statistics['completion_rate'] = round((completed_count / total_count * 100), 1) if total_count > 0 else 0
        statistics['total_students'] = total_count
        statistics['total_completed'] = completed_count
        
        # 计算每个考试的平均分
        for exam_title in statistics['exam_statistics']:
            exam_stats = statistics['exam_statistics'][exam_title]
            if exam_stats['completed'] > 0:
                exam_stats['average_score'] = round(exam_stats['total_score'] / exam_stats['completed'], 1)
        
        return jsonify({'success': True, 'statistics': statistics})
        
    except Exception as e:
        print(f"Results statistics error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'获取统计失败: {str(e)}'})

@teacher_bp.route('/results/filter')
@login_required
def filter_results():
    """筛选成绩数据"""
    try:
        exam_id = request.args.get('exam_id')
        student_id = request.args.get('student_id')
        min_score = request.args.get('min_score')
        max_score = request.args.get('max_score')
        status = request.args.get('status')  # completed/incomplete
        
        db = Database()
        exam_results = db.get_exam_results()
        
        # 过滤数据
        filtered_results = []
        for result in exam_results:
            # 兼容字典和对象
            if isinstance(result, dict):
                r_exam_id = result.get('exam_id', 0)
                r_student_id = result.get('student_id', '')
                r_score = result.get('score', 0.0) or 0.0
                r_is_completed = result.get('is_completed', False)
            else:
                r_exam_id = getattr(result, 'exam_id', 0)
                r_student_id = getattr(result, 'student_id', '')
                r_score = getattr(result, 'score', 0.0) or 0.0
                r_is_completed = getattr(result, 'is_completed', False)
            
            # 应用过滤条件
            if exam_id and str(r_exam_id) != str(exam_id):
                continue
            if student_id and r_student_id != student_id:
                continue
            if min_score and r_score < float(min_score):
                continue
            if max_score and r_score > float(max_score):
                continue
            if status == 'completed' and not r_is_completed:
                continue
            if status == 'incomplete' and r_is_completed:
                continue
            
            filtered_results.append(result)
        
        # 转换为统一格式并保留原始学生信息
        processed_results = []
        students = {s.student_id: s for s in db.get_all_students()}
        exams = {e.id: e for e in db.get_exams()}
        
        for result in filtered_results:
            if isinstance(result, dict):
                processed_result = result.copy()  # 复制保留原始数据
            else:
                processed_result = {
                    'id': getattr(result, 'id', 0),
                    'exam_id': getattr(result, 'exam_id', 0),
                    'student_id': getattr(result, 'student_id', ''),
                    'score': getattr(result, 'score', 0.0),
                    'is_completed': getattr(result, 'is_completed', False),
                    'start_time': getattr(result, 'start_time', ''),
                    'end_time': getattr(result, 'end_time', '')
                }
            
            # 只有在原始数据没有学生信息时才进行关联查找
            if 'student_name' not in processed_result or not processed_result.get('student_name'):
                student_id = processed_result['student_id']
                # 尝试数字和字符串两种格式的查找
                student = students.get(student_id) or students.get(str(student_id))
                if student:
                    processed_result['student_name'] = student.name
                    processed_result['student_number'] = student.student_id
                else:
                    processed_result['student_name'] = 'N/A'
                    processed_result['student_number'] = 'N/A'
            
            # 只有在原始数据没有考试信息时才进行关联查找
            if 'exam_title' not in processed_result or not processed_result.get('exam_title'):
                exam = exams.get(processed_result['exam_id'])
                processed_result['exam_title'] = exam.title if exam else 'N/A'
            
            processed_results.append(processed_result)
        
        return jsonify({
            'success': True,
            'results': processed_results,
            'total': len(processed_results)
        })
        
    except Exception as e:
        print(f"Filter results error: {e}")
        return jsonify({'success': False, 'message': f'筛选失败: {str(e)}'}) 

@teacher_bp.route('/questions/download-template/xlsx')
@login_required
def download_xlsx_template():
    """下载XLSX模板文件"""
    try:
        from smart_import_manager import SmartImportManager
        import tempfile
        import os
        from flask import send_file
        
        manager = SmartImportManager()
        
        # 创建临时文件
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as temp_file:
            temp_file_path = temp_file.name
        
        # 创建Excel模板
        manager.excel_importer.create_comprehensive_template(temp_file_path)
        
        # 发送文件
        return send_file(
            temp_file_path,
            as_attachment=True,
            download_name='reading_comprehension_template.xlsx',
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        
    except Exception as e:
        print(f"Download XLSX template error: {e}")
        return jsonify({'success': False, 'message': f'模板下载失败: {str(e)}'})

@teacher_bp.route('/grading/clear-all/<int:exam_id>', methods=['POST'])
@login_required
def clear_all_grading(exam_id):
    """清除考试的所有评分结果"""
    try:
        db = Database()
        
        # 获取考试中的所有主观题分数记录
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # 查询需要清除的评分记录
        cursor.execute("""
            SELECT COUNT(*) as total_count
            FROM question_scores qs
            JOIN exam_results er ON qs.exam_result_id = er.id
            WHERE er.exam_id = ? 
            AND qs.question_type NOT IN ('choice', 'judge')
            AND (qs.is_ai_graded = 1 OR qs.is_manually_graded = 1)
        """, (exam_id,))
        
        count_result = cursor.fetchone()
        total_to_clear = count_result[0] if count_result else 0
        
        if total_to_clear == 0:
            return jsonify({
                'success': False,
                'message': '没有需要清除的评分记录'
            })
        
        # 清除AI评分和手动评分信息
        cursor.execute("""
            UPDATE question_scores 
            SET 
                ai_score = 0,
                ai_confidence = 0,
                ai_feedback = '',
                ai_details = '',
                is_ai_graded = 0,
                is_manually_graded = 0,
                grade_comment = '',
                graded_by = '',
                score = 0,
                updated_at = CURRENT_TIMESTAMP
            WHERE id IN (
                SELECT qs.id 
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.exam_id = ? 
                AND qs.question_type NOT IN ('choice', 'judge')
            )
        """, (exam_id,))
        
        # 提交事务
        conn.commit()
        affected_rows = cursor.rowcount
        
        return jsonify({
            'success': True,
            'message': f'清除评分成功！共清除了 {affected_rows} 条评分记录'
        })
        
    except Exception as e:
        print(f"Clear all grading error: {e}")
        return jsonify({
            'success': False,
            'message': f'清除评分失败: {str(e)}'
        })

# ===== 新增：改进的主观题评分路由 =====

@teacher_bp.route('/grading/ai-batch', methods=['POST'])
@login_required
def ai_batch_grading():
    """AI批量评分功能"""
    try:
        # 导入统一评分引擎
        from grading_engine import get_grading_engine
        
        db = Database()
        
        # 获取请求数据
        request_data = request.get_json()
        question_score_ids = request_data.get('question_score_ids', [])
        mode = request_data.get('mode', 'ungraded_only')
        
        if not question_score_ids:
            return jsonify({
                'success': False,
                'message': '没有指定要评分的题目'
            })
        
        # 获取题目信息
        placeholders = ','.join(['?'] * len(question_score_ids))
        conn = db.get_connection()
        cursor = conn.cursor()
        
        cursor.execute(f"""
            SELECT 
                qs.id as question_score_id,
                qs.student_answer,
                qs.correct_answer,
                qs.question_text,
                qs.max_score,
                qs.is_ai_graded,
                qs.question_type
            FROM question_scores qs
            WHERE qs.id IN ({placeholders})
        """, question_score_ids)
        
        questions = cursor.fetchall()
        
        # 根据模式筛选
        if mode == 'ungraded_only':
            questions = [q for q in questions if not q[5]]  # is_ai_graded = 0
        
        if not questions:
            return jsonify({
                'success': False,
                'message': '没有需要评分的题目'
            })
        
        # 初始化统一评分引擎
        grading_engine = get_grading_engine()
        
        # 批量评分
        processed_count = 0
        failed_count = 0
        
        for question in questions:
            try:
                question_score_id = question[0]
                student_answer = question[1] or ''
                correct_answer = question[2] or ''
                question_text = question[3] or ''
                max_score = float(question[4] or 100)
                question_type = question[6] or 'essay'
                
                # AI评分
                ai_result = grading_engine.grade(
                    question_type=question_type,
                    student_answer=student_answer,
                    reference_answer=correct_answer,
                    question_text=question_text,
                    max_score=max_score,
                    method='ai_qwen'  # 优先使用Qwen AI评分
                )
                
                # 更新数据库
                if db.save_ai_grading_result(question_score_id, ai_result):
                    processed_count += 1
                else:
                    failed_count += 1
                    
            except Exception as e:
                print(f"单个题目AI评分失败 (ID: {question[0]}): {e}")
                failed_count += 1
        
        return jsonify({
            'success': True,
            'message': f'批量AI评分完成',
            'processed_count': processed_count,
            'failed_count': failed_count,
            'total_count': len(questions)
        })
        
    except Exception as e:
        print(f"AI batch grading error: {e}")
        return jsonify({
            'success': False,
            'message': f'批量AI评分失败: {str(e)}'
        })

@teacher_bp.route('/grading/exam/<int:exam_id>/questions-to-grade')
@login_required
def get_questions_to_grade(exam_id):
    """获取需要评分的题目列表 - 支持逐题评分进度显示"""
    try:
        scope = request.args.get('scope', 'ungraded')  # 'ungraded' 或 'all'
        
        db = get_db()
        
        # 验证考试是否存在
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        # 获取需要AI评分的主观题
        all_questions = db.get_subjective_questions_for_ai_grading(exam_id)
        
        questions_to_grade = []
        
        if scope == 'all':
            # 所有主观题都需要重新评分
            questions_to_grade = all_questions
        else:
            # 只处理未评分的题目
            questions_to_grade = [q for q in all_questions if not q['is_ai_graded'] and not q['is_manually_graded']]
        
        # 转换为前端需要的格式
        formatted_questions = []
        for question in questions_to_grade:
            formatted_questions.append({
                'question_score_id': question['question_score_id'],
                'student_name': question['student_name'],
                'student_number': question['student_number'],
                'student_id': question['student_id'],
                'question_text': question['question_text'],
                'student_answer': question['student_answer'],
                'reference_answer': question['reference_answer'],
                'max_score': question['max_score'],
                'question_type': question['question_type'],
                'current_score': question.get('current_score', 0.0),
                'is_ai_graded': question.get('is_ai_graded', False),
                'is_manually_graded': question.get('is_manually_graded', False),
                'ai_score': question.get('ai_score', 0.0),
                'ai_confidence': question.get('ai_confidence', 0.0),
                'ai_feedback': question.get('ai_feedback', ''),
                'graded_by': question.get('graded_by', ''),
                'grading_comment': question.get('grading_comment', '')
            })
        
        return jsonify({
            'success': True,
            'questions': formatted_questions,
            'total': len(formatted_questions),
            'scope': scope
        })
        
    except Exception as e:
        print(f"[ERROR] 获取评分题目失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'获取评分题目失败: {str(e)}'})

@teacher_bp.route('/grading/details/<int:question_score_id>')
@login_required
def get_grading_details(question_score_id):
    """获取题目评分详情 - 增强错误调试版本"""
    try:
        print(f"=== 开始获取评分详情，question_score_id: {question_score_id} ===")
        
        db = Database()
        conn = db.get_connection()
        cursor = conn.cursor()
        
        print("数据库连接成功")
        
        # 首先检查记录是否存在
        cursor.execute("SELECT COUNT(*) FROM question_scores WHERE id = ?", (question_score_id,))
        count = cursor.fetchone()[0]
        print(f"question_scores表中ID={question_score_id}的记录数: {count}")
        
        if count == 0:
            print(f"错误：question_scores表中不存在ID={question_score_id}的记录")
            return jsonify({
                'success': False,
                'message': f'题目评分记录不存在 (ID: {question_score_id})'
            })
        
        # 分步骤获取信息，便于调试
        print("开始执行主查询...")
        
        # 获取详细信息
        cursor.execute("""
            SELECT 
                qs.id,
                qs.exam_result_id,
                qs.question_id,
                qs.question_order,
                qs.student_answer,
                qs.correct_answer,
                qs.is_correct,
                qs.score,
                qs.max_score,
                qs.question_type,
                qs.question_text,
                qs.is_manually_graded,
                qs.graded_by,
                qs.grade_comment,
                qs.created_at,
                qs.updated_at,
                qs.ai_score,
                qs.ai_confidence,
                qs.ai_feedback,
                qs.ai_details,
                qs.is_ai_graded,
                er.student_id,
                s.name as student_name,
                s.student_id as student_number,
                e.title as exam_title
            FROM question_scores qs
            JOIN exam_results er ON qs.exam_result_id = er.id
            JOIN students s ON er.student_id = s.id
            JOIN exams e ON er.exam_id = e.id
            WHERE qs.id = ?
        """, (question_score_id,))
        
        result = cursor.fetchone()
        print(f"主查询执行完成，结果: {result is not None}")
        
        if not result:
            # 进一步诊断问题
            print("主查询无结果，开始诊断...")
            
            # 检查question_scores表
            cursor.execute("SELECT * FROM question_scores WHERE id = ?", (question_score_id,))
            qs_result = cursor.fetchone()
            if qs_result:
                print(f"question_scores记录存在: exam_result_id={qs_result[1]}")
                
                # 检查exam_results表
                cursor.execute("SELECT id, student_id, exam_id FROM exam_results WHERE id = ?", (qs_result[1],))
                er_result = cursor.fetchone()
                if er_result:
                    print(f"exam_results记录存在: student_id={er_result[1]}, exam_id={er_result[2]}")
                    
                    # 检查students表
                    cursor.execute("SELECT id, name, student_id FROM students WHERE id = ?", (er_result[1],))
                    s_result = cursor.fetchone()
                    if s_result:
                        print(f"students记录存在: {s_result}")
                    else:
                        print(f"错误：students表中不存在ID={er_result[1]}的记录")
                        return jsonify({
                            'success': False,
                            'message': f'关联的学生记录不存在 (student_id: {er_result[1]})'
                        })
                    
                    # 检查exams表
                    cursor.execute("SELECT id, title FROM exams WHERE id = ?", (er_result[2],))
                    e_result = cursor.fetchone()
                    if e_result:
                        print(f"exams记录存在: {e_result}")
                    else:
                        print(f"错误：exams表中不存在ID={er_result[2]}的记录")
                        return jsonify({
                            'success': False,
                            'message': f'关联的考试记录不存在 (exam_id: {er_result[2]})'
                        })
                else:
                    print(f"错误：exam_results表中不存在ID={qs_result[1]}的记录")
                    return jsonify({
                        'success': False,
                        'message': f'关联的考试结果记录不存在 (exam_result_id: {qs_result[1]})'
                    })
            else:
                print(f"错误：这不应该发生，前面检查时记录存在，现在却找不到")
            
            return jsonify({
                'success': False,
                'message': '数据关联异常，请检查数据完整性'
            })
        
        print(f"获取到完整记录，字段数量: {len(result)}")
        print(f"记录内容预览: [id={result[0]}, exam_result_id={result[1]}, question_id={result[2]}, ...]")
        
        # 构建详情HTML - 使用正确的字段索引
        import json
        
        ai_details = {}
        if result[19]:  # ai_details字段
            try:
                if isinstance(result[19], str):
                    ai_details = json.loads(result[19])
                elif isinstance(result[19], dict):
                    ai_details = result[19]
                else:
                    print(f"AI详情数据类型未知: {type(result[19])}")
                    ai_details = {}
                print("AI详情解析成功")
            except Exception as json_error:
                print(f"AI详情JSON解析失败: {json_error}")
                ai_details = {}
        
        # 安全地处理可能包含特殊字符的内容
        def safe_html(text):
            if not text:
                return ''
            return str(text).replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\n', '<br>')
        
        print("开始构建HTML内容...")
        
        try:
            html_content = f"""
            <div class="row">
                <div class="col-md-6">
                    <h6 class="text-primary">题目信息</h6>
                    <div class="card mb-3">
                        <div class="card-body">
                                <p><strong>考试:</strong> {safe_html(result[24])}</p>
                                <p><strong>学生:</strong> {safe_html(result[22])} ({safe_html(result[23])})</p>
                                <p><strong>题型:</strong> {safe_html(result[9])}</p>
                                <p><strong>满分:</strong> {result[8]}</p>
                                <p><strong>题目顺序:</strong> 第{result[3]}题</p>
                        </div>
                    </div>
                    
                    <h6 class="text-info">题目内容</h6>
                    <div class="card mb-3">
                        <div class="card-body">
                                {safe_html(result[10]) or '无题目内容'}
                        </div>
                    </div>
                    
                    <h6 class="text-success">参考答案</h6>
                    <div class="card mb-3">
                        <div class="card-body">
                                {safe_html(result[5]) or '无参考答案'}
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <h6 class="text-warning">学生答案</h6>
                    <div class="card mb-3">
                        <div class="card-body">
                                {safe_html(result[4]) or '未作答'}
                        </div>
                    </div>
                    
                    <h6 class="text-danger">评分信息</h6>
                    <div class="card mb-3">
                        <div class="card-body">
                                <p><strong>当前分数:</strong> {result[7]} / {result[8]}</p>
                                <p><strong>答案正确:</strong> {'是' if result[6] else '否'}</p>
                                <p><strong>AI评分:</strong> {'是' if result[20] else '否'}</p>
                                <p><strong>手动调整:</strong> {'是' if result[11] else '否'}</p>
                                {f'<p><strong>AI置信度:</strong> {float(result[17] or 0) * 100:.1f}%</p>' if result[17] else ''}
                                {f'<p><strong>评分备注:</strong> {safe_html(result[13])}</p>' if result[13] else ''}
                                {f'<p><strong>评分人:</strong> {safe_html(result[12])}</p>' if result[12] else ''}
                        </div>
                    </div>
                    
                    {f'''
                    <h6 class="text-info">AI反馈</h6>
                    <div class="card mb-3">
                        <div class="card-body">
                                {safe_html(result[18]) or '无AI反馈'}
                        </div>
                    </div>
                        ''' if result[18] else ''}
                </div>
            </div>
            
            <div class="row mt-3">
                <div class="col-12">
                    <h6>修改评分</h6>
                    <div class="row">
                        <div class="col-md-4">
                            <label class="form-label">分数</label>
                            <input type="number" class="form-control" 
                                   id="detail-score" 
                                   value="{result[7]}" 
                                   min="0" max="{result[8]}" step="0.1"
                                   data-question-score-id="{question_score_id}"
                                   data-max-score="{result[8]}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">备注</label>
                            <input type="text" class="form-control" 
                                   id="detail-comment" 
                                   value="{safe_html(result[13]) or ''}" 
                                   placeholder="评分备注...">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">&nbsp;</label>
                            <button type="button" class="btn btn-primary d-block" 
                                    onclick="saveDetailScore({question_score_id})">
                                <i class="bi bi-check-lg"></i> 保存
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            """
            
            print("HTML内容构建成功")
            
        except Exception as html_error:
            print(f"构建HTML内容时出错: {html_error}")
            print(f"result数据: {result}")
            raise html_error
        
        print("=== 评分详情获取成功 ===")
        
        return jsonify({
            'success': True,
            'html': html_content,
            'question_score_id': question_score_id
        })
        
    except Exception as e:
        print(f"=== 获取评分详情时发生严重错误 ===")
        print(f"错误类型: {type(e).__name__}")
        print(f"错误信息: {str(e)}")
        
        import traceback
        print("完整错误堆栈:")
        traceback.print_exc()
        
        print(f"参数: question_score_id={question_score_id}")
        print("=== 错误信息结束 ===")
        
        return jsonify({
            'success': False,
            'message': f'获取详情失败: {str(e)}',
            'error_type': type(e).__name__,
            'question_score_id': question_score_id
        })

@teacher_bp.route('/grading/full-answer/<int:question_score_id>')
@login_required
def get_full_answer(question_score_id):
    """获取完整答案（用于模态框显示）- 增强错误调试版本"""
    try:
        print(f"=== 开始获取完整答案，question_score_id: {question_score_id} ===")
        
        db = Database()
        conn = db.get_connection()
        cursor = conn.cursor()
        
        print("数据库连接成功")
        
        # 获取详细信息
        cursor.execute("""
            SELECT 
                qs.student_answer,
                qs.correct_answer,
                qs.question_text,
                qs.question_type,
                s.name as student_name,
                s.student_id as student_number
            FROM question_scores qs
            JOIN exam_results er ON qs.exam_result_id = er.id
            JOIN students s ON er.student_id = s.id
            WHERE qs.id = ?
        """, (question_score_id,))
        
        result = cursor.fetchone()
        print(f"查询执行完成，结果: {result is not None}")
        
        if not result:
            print(f"无法找到ID={question_score_id}的完整答案详情")
            return jsonify({'success': False, 'message': '找不到答案详情'})
        
        print(f"成功获取完整答案，字段数量: {len(result)}")
        
        return jsonify({
            'success': True,
            'student_answer': result[0] or '',
            'correct_answer': result[1] or '',
            'question_text': result[2] or '',
            'question_type': result[3] or '',
            'student_name': result[4] or '',
            'student_number': result[5] or ''
        })
        
    except Exception as e:
        print(f"=== 获取完整答案时发生严重错误 ===")
        print(f"错误类型: {type(e).__name__}")
        print(f"错误信息: {str(e)}")
        
        import traceback
        print("完整错误堆栈:")
        traceback.print_exc()
        
        print(f"参数: question_score_id={question_score_id}")
        print("=== 错误信息结束 ===")
        
        return jsonify({
                'success': False,
            'message': f'获取答案失败: {str(e)}',
            'error_type': type(e).__name__,
            'question_score_id': question_score_id
        })

# ===============================
# 学生提交状态管理功能
# ===============================

def force_submit_with_grading(db, exam_id, student_id, current_time):
    """强制提交考试（延迟评分版本）"""
    try:
        # 获取学生信息
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT student_id, name FROM students WHERE id = ?', (student_id,))
            student_result = cursor.fetchone()
            
            if not student_result:
                return None, "学生不存在"
            
            student_number, student_name = student_result
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return None, "考试不存在"
        
        # 获取题目
        questions = db.get_exam_questions(exam_id)
        if not questions:
            return None, "考试没有题目"
        
        print(f"[FORCE_SUBMIT] 强制提交 - 学生: {student_name}({student_number}), 考试: {exam.title}")
        
        # 获取学生的进度数据 (增强版: 多源恢复)
        raw_answers = {}
        recovery_source = "exam_progress"
        
        try:
            progress = db.get_exam_progress_by_student_number(exam_id, student_number)
            found_in_progress = False
            
            if progress:
                # 优先尝试获取 answer_data (正确列名)
                answer_data = progress.get('answer_data')
                # 向后兼容 answers (错误列名，以防万一)
                if not answer_data:
                    answer_data = progress.get('answers')
                
                print(f"[FORCE_SUBMIT] 进度记录keys: {list(progress.keys())}")
                
                if answer_data:
                    if isinstance(answer_data, str):
                        try:
                            temp_answers = json.loads(answer_data)
                            if temp_answers:
                                raw_answers = temp_answers
                                found_in_progress = True
                        except json.JSONDecodeError:
                            print(f"[WARNING] JSON解析失败: {answer_data[:100]}...")
                    else:
                        if answer_data:
                            raw_answers = answer_data
                            found_in_progress = True
                    
                    if found_in_progress:
                        print(f"[FORCE_SUBMIT] 从进度中获取到 {len(raw_answers)} 个答案")
                else:
                    print(f"[WARNING] 进度记录中没有找到答案数据 (answer_data is empty)")
            
            # 如果exam_progress没有找到答案，尝试全面恢复 (兜底路径)
            if not found_in_progress or not raw_answers:
                print(f"[FORCE_SUBMIT] ⚠️ 标准进度为空，尝试启动全面恢复流程...")
                from answer_preservation_system import recover_answers_safely
                recovery_result = recover_answers_safely(exam_id, student_id, student_number)
                if recovery_result['success'] and recovery_result['answers']:
                    raw_answers = recovery_result['answers']
                    recovery_source = f"recovery_system ({'+'.join(recovery_result['recovery_sources'])})"
                    print(f"[FORCE_SUBMIT] ✅ 全面恢复成功! 来源: {recovery_source}, 恢复答案数: {len(raw_answers)}")
                else:
                    print(f"[FORCE_SUBMIT] ❌ 全面恢复也未找到答案")
            
        except Exception as e:
            print(f"[WARNING] 获取进度数据失败: {e}")
            import traceback
            traceback.print_exc()
            # 即使出错也尝试继续，避免完全失败
        
        # 标准化答案格式
        answers = {}
        for question in questions:
            question_key = f'question_{question.id}'
            
            # 尝试多种格式获取答案
            student_answer = ''
            if question_key in raw_answers:
                # 标准格式 question_123
                student_answer = raw_answers[question_key]
            elif str(question.id) in raw_answers:
                # 数字格式 123
                student_answer = raw_answers[str(question.id)]
            elif question.id in raw_answers:
                # 整数格式
                student_answer = raw_answers[question.id]
            
            # 标准化为question_{id}格式存储
            answers[question_key] = str(student_answer).strip() if student_answer else ''
        
        answered_count = len([a for a in answers.values() if a.strip()])
        max_total_score = sum(question.score or 1.0 for question in questions)
        
        print(f"[FORCE_SUBMIT] 标准化后的答案数量: {len(answers)}, 有效答案数: {answered_count}")
        
        # 检查是否已存在考试记录
        result_id = None
        try:
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, student_id))
                row = cursor.fetchone()
                if row:
                    result_id = row[0]
                    # 更新现有记录
                    cursor.execute('''
                        UPDATE exam_results 
                        SET answers = ?, score = 0, total_score = ?, end_time = ?, is_completed = 1
                        WHERE id = ?
                    ''', (json.dumps(answers, ensure_ascii=False), max_total_score, current_time, result_id))
                    conn.commit()
                    print(f"[FORCE_SUBMIT] 更新现有考试结果 - result_id: {result_id}")
        except Exception as e:
            print(f"[WARNING] 检查/更新现有记录失败: {e}")

        if not result_id:
            # 创建新的考试结果对象
            exam_result = ExamResult(
                exam_id=exam_id,
                student_id=student_id,
                answers=json.dumps(answers, ensure_ascii=False),
                score=0,  # 延迟评分
                total_score=max_total_score,
                start_time=current_time,
                end_time=current_time,
                is_completed=True
            )
            
            # 保存考试结果
            result_id = db.save_exam_result(exam_result)
            print(f"[FORCE_SUBMIT] 创建新考试结果 - result_id: {result_id}")
        
        if not result_id:
            return None, "保存考试结果失败"
        
        # 保存题目答案详情（不进行立即评分）
        total_score = 0.0
        
        # 获取现有的 question_scores 记录，避免重复插入
        existing_q_scores = {}
        try:
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT question_id, id FROM question_scores WHERE exam_result_id = ?', (result_id,))
                for row in cursor.fetchall():
                    existing_q_scores[row[0]] = row[1]
        except Exception:
            pass

        # 使用单一连接处理所有题目插入/更新
        try:
            with db.get_connection() as conn:
                cursor = conn.cursor()
                
                for i, question in enumerate(questions):
                    question_key = f'question_{question.id}'
                    student_answer = answers.get(question_key, '').strip()
                    max_score = question.score or 1.0
                    
                    # 所有题目均延迟评分
                    question_score = 0.0
                    is_correct = False
                    needs_grading = True
                    is_manually_graded = False
                    
                    # 保存/更新题目得分
                    if question.id in existing_q_scores:
                        # 更新现有记录
                        cursor.execute('''
                            UPDATE question_scores 
                            SET student_answer = ?, score = ?, is_correct = ?, 
                                needs_grading = ?, is_manually_graded = ?, updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                        ''', (student_answer, question_score, is_correct, needs_grading, is_manually_graded, existing_q_scores[question.id]))
                    else:
                        # 插入新记录 - 直接使用SQL而不是调用db.save_question_score以提高性能和可靠性
                        cursor.execute('''
                            INSERT INTO question_scores (exam_result_id, question_id, question_order,
                                                       student_answer, correct_answer, is_correct,
                                                       score, max_score, question_type, question_text,
                                                       is_manually_graded, needs_grading, grade_comment, graded_by)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (result_id, question.id, i + 1,
                              student_answer, question.correct_answer, is_correct,
                              question_score, max_score, question.question_type, question.question_text[:200],
                              is_manually_graded, needs_grading, "", ""))
                
                # 验证数据是否已保存（安全检查）
                cursor.execute('SELECT COUNT(*) FROM question_scores WHERE exam_result_id = ?', (result_id,))
                saved_count = cursor.fetchone()[0]
                
                if saved_count == 0 and len(questions) > 0:
                     print(f"[WARNING] 强制提交数据可能不完整 - result_id: {result_id}, 预期题目: {len(questions)}, 实际保存: 0")
                
                # 软删除进度记录
                cursor.execute('UPDATE exam_progress SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE exam_id = ? AND student_number = ?', 
                             (exam_id, student_number))

                conn.commit()
                print(f"[FORCE_SUBMIT] 事务提交成功 - result_id: {result_id}, 记录数: {saved_count}")
                
        except Exception as e:
            print(f"[ERROR] 保存题目数据失败: {e}")
            import traceback
            traceback.print_exc()
            return None, f"保存题目数据失败: {str(e)}"
        
        # (已在上方事务中完成验证和清理)
        
        print(f"[FORCE_SUBMIT] 强制提交完成 - 学生: {student_name}({student_number}), 已答题数: {answered_count}/{len(questions)}, 数据库记录数: {saved_count}")
        
        return {
            'result_id': result_id,
            'score': 0.0,  # 延迟评分，返回0
            'total_score': max_total_score,
            'answered_questions': answered_count,
            'total_questions': len(questions),
            'grading_status': 'pending',
            'objective_score': 0.0,
            'subjective_pending': max_total_score
        }, None
        
    except Exception as e:
        print(f"[ERROR] 强制提交失败: {e}")
        import traceback
        traceback.print_exc()
        return None, f"强制提交失败: {str(e)}"

@teacher_bp.route('/exams/<int:exam_id>/student-submissions')
@login_required
def exam_student_submissions(exam_id):
    """获取指定考试的学生提交状态"""
    try:
        db = Database()
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        # 获取所有学生
        all_students = db.get_all_students()
        
        # 获取考试结果
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT er.id, er.student_id, er.is_completed, er.start_time, er.end_time, er.score, er.total_score,
                       s.student_id as student_number, s.name as student_name, s.college, s.major, s.class_name,
                       er.focus_lost_count, er.focus_lost_logs
                FROM exam_results er
                JOIN students s ON er.student_id = s.id
                WHERE er.exam_id = ?
                ORDER BY s.student_id
            ''', (exam_id,))
            
            results = cursor.fetchall()
            
            # 🔥 获取有历史记录的学生ID集合
            cursor.execute('''
                SELECT DISTINCT student_id FROM answer_history WHERE exam_id = ?
            ''', (exam_id,))
            history_student_ids = {row[0] for row in cursor.fetchall()}
        
        # 构建学生状态列表
        student_submissions = []
        result_dict = {}
        
        # 将已有结果放入字典
        for result in results:
            student_id = result[1]
            result_dict[student_id] = {
                'result_id': result[0],
                'student_id': student_id,
                'is_completed': bool(result[2]),
                'start_time': result[3],
                'end_time': result[4],
                'score': result[5] or 0.0,
                'total_score': result[6] or 0.0,
                'student_number': result[7],
                'student_name': result[8],
                'college': result[9] or '',
                'major': result[10] or '',
                'class_name': result[11] or '',
                'focus_lost_count': result[12] or 0,
                'focus_lost_logs': result[13] or '[]',
                'status': 'completed' if result[2] else 'in_progress',
                'has_records': True # 有exam_results记录肯定是有记录的
            }
        
        # 为所有学生生成状态信息
        for student in all_students:
            has_history = student.id in history_student_ids
            
            if student.id in result_dict:
                item = result_dict[student.id]
                # 即使有exam_results，也标记是否原本就有历史记录（虽然exam_results本身就是记录）
                item['has_history'] = has_history
                student_submissions.append(item)
            else:
                student_submissions.append({
                    'result_id': None,
                    'student_id': student.id,
                    'is_completed': False,
                    'start_time': None,
                    'end_time': None,
                    'score': 0.0,
                    'total_score': exam.total_score,
                    'student_number': student.student_id,
                    'student_name': student.name,
                    'college': student.college or '',
                    'major': student.major or '',
                    'class_name': student.class_name or '',
                    'status': 'not_started',
                    'has_records': has_history, # 没有exam_results，但可能有history
                    'has_history': has_history
                })
        
        try:
            with db.get_connection() as conn2:
                c2 = conn2.cursor()
                c2.execute('''
                    SELECT student_id, save_time 
                    FROM answer_history 
                    WHERE exam_id = ? AND is_final_submission = 1
                ''', (exam_id,))
                finals = c2.fetchall()
                student_map = {s.id: s for s in all_students}
                
                # 获取已经显示为"已完成"或"进行中"（在result_dict中有记录）的学生ID集合
                # 关键修复：只要result_dict中存在该学生，就不应该从answer_history添加重复记录
                existing_ids = set(result_dict.keys())
                
                for sid, save_time in finals:
                    # 只有当学生ID不在 existing_ids 中时，才添加历史记录中的提交
                    if sid not in existing_ids and sid in student_map:
                        s = student_map[sid]
                        # 再次清理 student_submissions 中可能存在的 "not_started" 占位记录
                        student_submissions = [item for item in student_submissions if item['student_id'] != sid]
                        student_submissions.append({
                            'result_id': None,
                            'student_id': sid,
                            'is_completed': True,
                            'start_time': save_time,
                            'end_time': save_time,
                            'score': 0.0,
                            'total_score': exam.total_score,
                            'student_number': s.student_id,
                            'student_name': s.name,
                            'college': s.college or '',
                            'major': s.major or '',
                            'class_name': s.class_name or '',
                            'status': 'completed'
                        })
        except Exception as e:
            pass
        
        return jsonify({
            'success': True,
            'exam': {
                'id': exam.id,
                'title': exam.title,
                'description': exam.description,
                'duration_minutes': exam.duration_minutes,
                'total_questions': exam.total_questions,
                'total_score': exam.total_score,
                'is_active': exam.is_active
            },
            'students': student_submissions
        })
        
    except Exception as e:
        print(f"Get exam student submissions error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'获取学生提交状态失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/auto-fill-blank-answers', methods=['POST'])
@login_required
def auto_fill_blank_answers(exam_id):
    try:
        import json
        from datetime import datetime
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择学生'})
        
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        questions = db.get_exam_questions(exam_id)
        max_total_score = sum(q.score or 1.0 for q in questions) if questions else (exam.total_score or 0.0)
        
        success_count = 0
        failed = []
        
        with db.get_write_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                try:
                    # 1. 处理考试结果记录
                    cursor.execute('SELECT id, is_completed, score FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                    row = cursor.fetchone()
                    if row:
                        result_id = row[0]
                        # 如果存在记录，确保标记为完成，但不盲目重置分数为0（保留已有成绩）
                        # 只有当它是未完成状态时，才强制更新状态
                        if not row[1]:
                            cursor.execute('UPDATE exam_results SET is_completed = 1, end_time = ? WHERE id = ?', (datetime.now().isoformat(), result_id))
                    else:
                        # 如果不存在记录，创建新的空白记录（分数为0）
                        cursor.execute('INSERT INTO exam_results (exam_id, student_id, answers, score, total_score, start_time, end_time, is_completed, is_graded, needs_grading) VALUES (?, ?, ?, 0, ?, ?, ?, 1, 0, 1)', (exam_id, sid, json.dumps({}, ensure_ascii=False), max_total_score, datetime.now().isoformat(), datetime.now().isoformat()))
                        result_id = cursor.lastrowid
                    
                    # 2. 处理题目得分记录
                    for i, q in enumerate(questions):
                        cursor.execute('SELECT id, student_answer FROM question_scores WHERE exam_result_id = ? AND question_id = ?', (result_id, q.id))
                        exist = cursor.fetchone()
                        
                        if exist:
                            existing_answer = exist[1]
                            # 只有当答案为空时才填充（保护已有答案）
                            if not existing_answer or existing_answer.strip() == '':
                                cursor.execute('UPDATE question_scores SET student_answer = ?, score = 0, max_score = ?, is_correct = 0, is_manually_graded = 0, needs_grading = 1 WHERE id = ?', ('', q.score or 1.0, exist[0]))
                        else:
                            # 如果没有记录，插入空白记录
                            cursor.execute('INSERT INTO question_scores (exam_result_id, question_id, question_order, student_answer, correct_answer, is_correct, score, max_score, question_type, question_text, is_manually_graded, needs_grading) VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, ?, 0, 1)', (result_id, q.id, i + 1, '', q.correct_answer, q.score or 1.0, q.question_type, (q.question_text or '')[:200]))
                    
                    success_count += 1
                except Exception as e:
                    failed.append({'student_id': sid, 'error': str(e)})
            conn.commit()
        
        message = f'已为 {success_count} 名学生处理空白答卷（仅填充缺失部分）'
        if failed:
            message += f'；失败 {len(failed)} 人'
        return jsonify({'success': True, 'message': message})
    
    except Exception as e:
        print(f"[ERROR] 空白填充失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'空白填充失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/retrieve-student-answers', methods=['POST'])
@login_required
def retrieve_student_answers(exam_id):
    """从备份系统中找回学生答案"""
    try:
        # 延迟导入以避免循环依赖
        from answer_preservation_system import recover_answers_safely
        import json
        from datetime import datetime
        
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择学生'})
            
        success_count = 0
        failed_count = 0
        
        # 获取考试题目用于映射
        questions = db.get_exam_questions(exam_id)
        # 创建题目映射：ID -> Question对象
        question_map = {str(q.id): q for q in questions}
        total_score_val = sum(q.score or 0 for q in questions)
        
        for student_id in student_ids:
            try:
                # 获取学生信息
                student = db.get_student_by_id(student_id)
                if not student:
                    failed_count += 1
                    continue
                    
                # 尝试从备份系统恢复答案
                recovery_result = recover_answers_safely(exam_id, student_id, student.student_id)
                
                if recovery_result['success'] and recovery_result['answers']:
                    answers = recovery_result['answers']
                    print(f"为学生 {student.name} ({student.student_id}) 找回 {len(answers)} 个答案")
                    
                    # 更新数据库
                    with db.get_connection() as conn:
                        cursor = conn.cursor()
                        
                        # 1. 更新或创建 exam_results
                        cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, student_id))
                        row = cursor.fetchone()
                        
                        answers_json = json.dumps(answers, ensure_ascii=False)
                        
                        if row:
                            result_id = row[0]
                            # 更新现有记录的答案
                            cursor.execute('UPDATE exam_results SET answers = ? WHERE id = ?', (answers_json, result_id))
                        else:
                            # 创建新记录
                            cursor.execute('''
                                INSERT INTO exam_results 
                                (exam_id, student_id, answers, score, total_score, start_time, end_time, is_completed, is_graded, needs_grading) 
                                VALUES (?, ?, ?, 0, ?, ?, ?, 0, 0, 1)
                            ''', (exam_id, student_id, answers_json, total_score_val, datetime.now().isoformat(), datetime.now().isoformat()))
                            result_id = cursor.lastrowid
                            
                        # 2. 更新 question_scores
                        for q_id_raw, answer_text in answers.items():
                            try:
                                q_id = int(q_id_raw)
                                q_id_str = str(q_id)
                                
                                if q_id_str in question_map:
                                    q = question_map[q_id_str]
                                    
                                    # 检查是否存在题目得分记录
                                    cursor.execute('SELECT id FROM question_scores WHERE exam_result_id = ? AND question_id = ?', (result_id, q_id))
                                    qs_row = cursor.fetchone()
                                    
                                    if qs_row:
                                        # 更新现有记录
                                        cursor.execute('UPDATE question_scores SET student_answer = ? WHERE id = ?', (answer_text, qs_row[0]))
                                    else:
                                        # 插入缺失记录
                                        cursor.execute('''
                                            INSERT INTO question_scores 
                                            (exam_result_id, question_id, student_answer, score, max_score, question_type, question_text, needs_grading, is_manually_graded, is_correct) 
                                            VALUES (?, ?, ?, 0, ?, ?, ?, 1, 0, 0)
                                        ''', (result_id, q_id, answer_text, q.score or 0, q.question_type, (q.question_text or '')[:200]))
                            except ValueError:
                                continue
                        
                        conn.commit()
                    success_count += 1
                else:
                    print(f"未找到学生 {student.name} 的备份答案")
                    failed_count += 1
            except Exception as e:
                print(f"Error recovering for student {student_id}: {e}")
                failed_count += 1
                
        message = f'已成功从备份中找回 {success_count} 名学生的答案'
        if failed_count > 0:
            message += f'，{failed_count} 名学生未找到有效备份'
            
        return jsonify({
            'success': True, 
            'message': message
        })
        
    except Exception as e:
        print(f"Retrieve answers error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'找回失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/test-fill-correct-answers', methods=['POST'])
@login_required
def test_fill_correct_answers(exam_id):
    """测试填充：为选中的学生自动填充客观题的正确答案"""
    try:
        import json
        from datetime import datetime
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择学生'})
            
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        max_total_score = sum(q.score or 1.0 for q in questions) if questions else (exam.total_score or 0.0)
        
        success_count = 0
        failed = []
        
        with db.get_write_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                try:
                    # 1. 确保 exam_results 记录存在
                    cursor.execute('SELECT id, is_completed, answers FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                    row = cursor.fetchone()
                    
                    if row:
                        result_id = row[0]
                        current_answers = json.loads(row[2]) if row[2] else {}
                        # 确保标记为完成
                        if not row[1]:
                            cursor.execute('UPDATE exam_results SET is_completed = 1, end_time = ? WHERE id = ?', (datetime.now().isoformat(), result_id))
                    else:
                        # 创建新记录
                        current_answers = {}
                        cursor.execute('INSERT INTO exam_results (exam_id, student_id, answers, score, total_score, start_time, end_time, is_completed, is_graded, needs_grading) VALUES (?, ?, ?, 0, ?, ?, ?, 1, 0, 1)', (exam_id, sid, json.dumps({}), max_total_score, datetime.now().isoformat(), datetime.now().isoformat()))
                        result_id = cursor.lastrowid
                    
                    # 2. 遍历题目进行填充
                    for i, q in enumerate(questions):
                        # 检查题目得分记录是否存在
                        cursor.execute('SELECT id, student_answer FROM question_scores WHERE exam_result_id = ? AND question_id = ?', (result_id, q.id))
                        qs_row = cursor.fetchone()
                        
                        # 只有客观题才填充正确答案
                        is_objective = q.question_type in ['choice', 'judge']
                        
                        if is_objective:
                            # 客观题：填充正确答案并给满分
                            fill_answer = q.correct_answer
                            fill_score = q.score or 1.0
                            is_correct = 1
                            needs_grading = 0 # 客观题无需人工评分
                            
                            # 更新 current_answers 字典以便保存到 exam_results.answers
                            current_answers[str(q.id)] = fill_answer
                            
                            if qs_row:
                                # 更新现有记录
                                cursor.execute('''
                                    UPDATE question_scores 
                                    SET student_answer = ?, score = ?, max_score = ?, is_correct = ?, 
                                        is_manually_graded = 0, needs_grading = ?, is_ai_graded = 0
                                    WHERE id = ?
                                ''', (fill_answer, fill_score, q.score or 1.0, is_correct, needs_grading, qs_row[0]))
                            else:
                                # 插入新记录
                                cursor.execute('''
                                    INSERT INTO question_scores 
                                    (exam_result_id, question_id, question_order, student_answer, correct_answer, 
                                     is_correct, score, max_score, question_type, question_text, 
                                     is_manually_graded, needs_grading, is_ai_graded) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 0)
                                ''', (result_id, q.id, i + 1, fill_answer, q.correct_answer, 
                                      is_correct, fill_score, q.score or 1.0, q.question_type, (q.question_text or '')[:200], needs_grading))
                        else:
                            # 主观题：如果不填充，至少确保记录存在（类似空白填充）
                            # 这里不覆盖已有答案，只处理缺失的
                            if not qs_row:
                                cursor.execute('''
                                    INSERT INTO question_scores 
                                    (exam_result_id, question_id, question_order, student_answer, correct_answer, 
                                     is_correct, score, max_score, question_type, question_text, 
                                     is_manually_graded, needs_grading) 
                                    VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, ?, 0, 1)
                                ''', (result_id, q.id, i + 1, '', q.correct_answer, q.score or 1.0, q.question_type, (q.question_text or '')[:200]))
                    
                    # 更新 exam_results 的 answers 字段
                    cursor.execute('UPDATE exam_results SET answers = ? WHERE id = ?', (json.dumps(current_answers, ensure_ascii=False), result_id))
                    
                    # 记录成功处理的result_id
                    success_count += 1
                    
                except Exception as e:
                    failed.append({'student_id': sid, 'error': str(e)})
                    print(f"Test fill failed for student {sid}: {e}")
            
            # 提交事务
            conn.commit()
        
        # 3. 重新计算总分和状态 (关键步骤：确保同步)
        # 在事务外部进行，避免数据库锁定
        print(f"[TEST_FILL] 正在重新计算 {len(student_ids)} 个学生的总分...")
        result_ids_to_recalc = []
        with db.get_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                row = cursor.fetchone()
                if row:
                    result_ids_to_recalc.append(row[0])
        
        for rid in result_ids_to_recalc:
            try:
                db.recalculate_exam_score(rid)
            except Exception as recalc_error:
                print(f"[WARNING] 重新计算总分失败 (Result ID: {rid}): {recalc_error}")
        
        message = f'已为 {success_count} 名学生完成测试填充（客观题自动满分）'
        if failed:
            message += f'；失败 {len(failed)} 人'
            
        return jsonify({'success': True, 'message': message})
        
    except Exception as e:
        print(f"[ERROR] 测试填充失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'测试填充失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/test-perturb-answers', methods=['POST'])
@login_required
def test_perturb_answers(exam_id):
    """测试扰动：随机修改选中的学生2-5个客观题答案为错误答案"""
    try:
        import random
        from datetime import datetime
        
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择学生'})
            
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        # 过滤出客观题
        objective_questions = [q for q in questions if q.question_type in ['choice', 'judge']]
        
        if not objective_questions:
            return jsonify({'success': False, 'message': '该考试没有客观题，无法进行扰动'})
            
        success_count = 0
        perturbed_total = 0
        
        with db.get_write_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                try:
                    # 1. 确保 exam_results 记录存在
                    cursor.execute('SELECT id, is_completed FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                    row = cursor.fetchone()
                    
                    if not row:
                        # 如果没有记录，创建新记录（虽然通常扰动是在已有答案基础上）
                        # 这里为了健壮性，如果不存在则初始化
                        cursor.execute('INSERT INTO exam_results (exam_id, student_id, answers, score, total_score, start_time, end_time, is_completed, is_graded, needs_grading) VALUES (?, ?, ?, 0, ?, ?, ?, 1, 0, 1)', (exam_id, sid, '{}', exam.total_score, datetime.now().isoformat(), datetime.now().isoformat()))
                        result_id = cursor.lastrowid
                    else:
                        result_id = row[0]
                        if not row[1]:
                            cursor.execute('UPDATE exam_results SET is_completed = 1 WHERE id = ?', (result_id,))
                    
                    # 2. 随机选择2-5道客观题进行扰动
                    num_to_perturb = random.randint(2, 5)
                    num_to_perturb = min(num_to_perturb, len(objective_questions))
                    
                    if num_to_perturb > 0:
                        selected_questions = random.sample(objective_questions, num_to_perturb)
                        
                        for q in selected_questions:
                            # 生成错误答案
                            wrong_answer = ""
                            if q.question_type == 'judge':
                                # 判断题：取反
                                correct = q.correct_answer.strip().lower()
                                if correct in ['true', 't', 'yes', 'y', '1', '对', '是']:
                                    wrong_answer = "False"
                                else:
                                    wrong_answer = "True"
                            elif q.question_type == 'choice':
                                # 选择题：随机选一个非正确选项
                                options = ['A', 'B', 'C', 'D']
                                correct = q.correct_answer.strip().upper()
                                # 移除正确答案（如果存在）
                                if correct in options:
                                    options.remove(correct)
                                if options:
                                    wrong_answer = random.choice(options)
                                else:
                                    # 兜底：如果选项解析失败，随便给个错误的
                                    wrong_answer = "X" 
                            
                            # 更新数据库
                            # 先检查是否已有记录
                            cursor.execute('SELECT id FROM question_scores WHERE exam_result_id = ? AND question_id = ?', (result_id, q.id))
                            qs_row = cursor.fetchone()
                            
                            if qs_row:
                                cursor.execute('''
                                    UPDATE question_scores 
                                    SET student_answer = ?, score = 0, is_correct = 0, 
                                        is_manually_graded = 0, needs_grading = 0, is_ai_graded = 0
                                    WHERE id = ?
                                ''', (wrong_answer, qs_row[0]))
                            else:
                                cursor.execute('''
                                    INSERT INTO question_scores 
                                    (exam_result_id, question_id, question_order, student_answer, correct_answer, 
                                     is_correct, score, max_score, question_type, question_text, 
                                     is_manually_graded, needs_grading, is_ai_graded) 
                                    VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, ?, 0, 0, 0)
                                ''', (result_id, q.id, 999, wrong_answer, q.correct_answer, 
                                      q.score or 1.0, q.question_type, (q.question_text or '')[:200]))
                                      
                            perturbed_total += 1
                            
                    success_count += 1
                    
                except Exception as e:
                    print(f"Test perturb failed for student {sid}: {e}")
            
            conn.commit()
        
        # 3. 重新计算总分
        result_ids_to_recalc = []
        with db.get_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                row = cursor.fetchone()
                if row:
                    result_ids_to_recalc.append(row[0])
        
        for rid in result_ids_to_recalc:
            try:
                db.recalculate_exam_score(rid)
            except Exception as recalc_error:
                print(f"[WARNING] 重新计算总分失败 (Result ID: {rid}): {recalc_error}")
        
        return jsonify({
            'success': True, 
            'message': f'已对 {success_count} 名学生进行了测试扰动，共修改 {perturbed_total} 道题目为错误答案'
        })
        
    except Exception as e:
        print(f"[ERROR] 测试扰动失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'测试扰动失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/sync-exam-questions', methods=['POST'])
@login_required
def sync_exam_questions(exam_id):
    """同步考试题目：将选中的学生答卷结构强制同步为当前考试的题目结构"""
    try:
        from datetime import datetime
        
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择学生'})
            
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取当前考试的题目列表（这是标准结构）
        questions = db.get_exam_questions(exam_id)
        current_question_ids = {q.id for q in questions}
        questions_map = {q.id: q for q in questions}
        
        success_count = 0
        
        with db.get_write_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                try:
                    # 1. 获取或创建 exam_results
                    cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                    row = cursor.fetchone()
                    
                    if not row:
                        cursor.execute('INSERT INTO exam_results (exam_id, student_id, answers, score, total_score, start_time, end_time, is_completed, is_graded, needs_grading) VALUES (?, ?, ?, 0, ?, ?, ?, 1, 0, 1)', (exam_id, sid, '{}', exam.total_score, datetime.now().isoformat(), datetime.now().isoformat()))
                        result_id = cursor.lastrowid
                    else:
                        result_id = row[0]
                        # 更新考试总分 (Snapshot) 以匹配当前考试定义
                        cursor.execute('UPDATE exam_results SET total_score = ? WHERE id = ?', (exam.total_score, result_id))
                    
                    # 2. 删除多余的题目记录（学生有但现在考试中没有的题目）
                    # 构建需要保留的 question_id 列表字符串
                    if current_question_ids:
                        placeholders = ','.join(['?'] * len(current_question_ids))
                        # 删除 NOT IN current_question_ids 的记录
                        cursor.execute(f'''
                            DELETE FROM question_scores 
                            WHERE exam_result_id = ? AND question_id NOT IN ({placeholders})
                        ''', (result_id, *list(current_question_ids)))
                    else:
                        # 如果考试没有题目，删除该学生所有题目记录
                        cursor.execute('DELETE FROM question_scores WHERE exam_result_id = ?', (result_id,))
                        
                    # 3. 同步现有题目和添加新题目
                    # 先获取学生当前已有的题目记录
                    cursor.execute('SELECT question_id, id FROM question_scores WHERE exam_result_id = ?', (result_id,))
                    existing_qs_map = {row[0]: row[1] for row in cursor.fetchall()}
                    
                    for i, q in enumerate(questions):
                        q_id = q.id
                        
                        if q_id in existing_qs_map:
                            # 题目已存在：更新定义（题干、满分、正确答案等），保留学生答案
                            # 注意：如果不希望覆盖某些字段可以调整，但通常同步意味着以当前考试定义为准
                            cursor.execute('''
                                UPDATE question_scores 
                                SET question_text = ?, correct_answer = ?, max_score = ?, 
                                    question_type = ?, question_order = ?
                                WHERE id = ?
                            ''', ((q.question_text or '')[:200], q.correct_answer, q.score or 1.0, 
                                  q.question_type, i + 1, existing_qs_map[q_id]))
                        else:
                            # 题目不存在：插入新记录，答案留空
                            cursor.execute('''
                                INSERT INTO question_scores 
                                (exam_result_id, question_id, question_order, student_answer, correct_answer, 
                                 is_correct, score, max_score, question_type, question_text, 
                                 is_manually_graded, needs_grading, is_ai_graded) 
                                VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, ?, 0, 1, 0)
                            ''', (result_id, q.id, i + 1, '', q.correct_answer, 
                                  q.score or 1.0, q.question_type, (q.question_text or '')[:200]))
                                  
                    success_count += 1
                    
                except Exception as e:
                    print(f"Sync exam questions failed for student {sid}: {e}")
            
            conn.commit()
            
        # 4. 重新计算总分
        result_ids_to_recalc = []
        with db.get_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                row = cursor.fetchone()
                if row:
                    result_ids_to_recalc.append(row[0])
        
        for rid in result_ids_to_recalc:
            try:
                db.recalculate_exam_score(rid)
            except Exception as recalc_error:
                print(f"[WARNING] 重新计算总分失败 (Result ID: {rid}): {recalc_error}")
                
        return jsonify({
            'success': True, 
            'message': f'已成功同步 {success_count} 名学生的答卷结构'
        })
        
    except Exception as e:
        print(f"[ERROR] 考试同步失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'同步失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/force-refresh-scores', methods=['POST'])
@login_required
def force_refresh_scores(exam_id):
    """强制刷新分数：更新考试总分定义，重评客观题，并重新计算总分"""
    try:
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择学生'})
            
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取当前考试的题目
        questions = db.get_exam_questions(exam_id)
        objective_questions = [q for q in questions if q.question_type in ['choice', 'judge']]
        
        success_count = 0
        
        with db.get_write_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                try:
                    # 1. 确保 exam_results 存在并更新 total_score
                    cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                    row = cursor.fetchone()
                    
                    if not row:
                        continue # 如果没有答卷记录，跳过
                        
                    result_id = row[0]
                    # 强制更新试卷总分快照
                    cursor.execute('UPDATE exam_results SET total_score = ? WHERE id = ?', (exam.total_score, result_id))
                    
                    # 2. 重新评分所有客观题 (确保分数与当前定义一致)
                    for q in objective_questions:
                        # 获取当前题目得分记录
                        cursor.execute('SELECT id, student_answer FROM question_scores WHERE exam_result_id = ? AND question_id = ?', (result_id, q.id))
                        qs_row = cursor.fetchone()
                        
                        if qs_row:
                            qs_id = qs_row[0]
                            student_answer = qs_row[1] or ''
                            
                            # 评分逻辑
                            is_correct = 0
                            score = 0
                            if student_answer and q.correct_answer and \
                               student_answer.strip().lower() == q.correct_answer.strip().lower():
                                is_correct = 1
                                score = q.score or 0
                            
                            # 更新评分 (包括分数、满分、正确答案等所有定义字段)
                            cursor.execute('''
                                UPDATE question_scores 
                                SET is_correct = ?, score = ?, max_score = ?, correct_answer = ?,
                                    needs_grading = 0, is_manually_graded = 0
                                WHERE id = ?
                            ''', (is_correct, score, q.score or 1.0, q.correct_answer, qs_id))
                            
                    success_count += 1
                    
                except Exception as e:
                    print(f"Force refresh failed for student {sid}: {e}")
            
            conn.commit()
            
        # 3. 重新计算总分
        result_ids_to_recalc = []
        with db.get_connection() as conn:
            cursor = conn.cursor()
            for sid in student_ids:
                cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, sid))
                row = cursor.fetchone()
                if row:
                    result_ids_to_recalc.append(row[0])
        
        for rid in result_ids_to_recalc:
            try:
                db.recalculate_exam_score(rid)
            except Exception as recalc_error:
                print(f"[WARNING] 重新计算总分失败 (Result ID: {rid}): {recalc_error}")
                
        return jsonify({
            'success': True, 
            'message': f'已成功刷新 {success_count} 名学生的分数数据'
        })
        
    except Exception as e:
        print(f"[ERROR] 强制刷新分数失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'刷新失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/batch-grade-objective', methods=['POST'])
@login_required
def batch_grade_objective(exam_id):
    """批量对客观题进行评分（针对所有已提交的学生）"""
    try:
        db = Database()
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        # 过滤出客观题
        objective_questions = [q for q in questions if q.question_type in ['choice', 'judge']]
        
        if not objective_questions:
            return jsonify({'success': False, 'message': '该考试没有客观题'})
            
        success_count = 0
        total_processed = 0
        result_ids_to_recalc = []
        
        with db.get_write_connection() as conn:
            cursor = conn.cursor()
            
            # 获取所有已提交的考试结果
            cursor.execute('''
                SELECT id, student_id 
                FROM exam_results 
                WHERE exam_id = ? AND is_completed = 1
            ''', (exam_id,))
            
            results = cursor.fetchall()
            total_processed = len(results)
            
            for row in results:
                result_id = row[0]
                student_id = row[1]
                result_ids_to_recalc.append(result_id)
                
                # 为每个学生评分客观题
                for q in objective_questions:
                    # 获取学生答案
                    cursor.execute('''
                        SELECT id, student_answer 
                        FROM question_scores 
                        WHERE exam_result_id = ? AND question_id = ?
                    ''', (result_id, q.id))
                    
                    qs_row = cursor.fetchone()
                    
                    if qs_row:
                        qs_id = qs_row[0]
                        student_answer = qs_row[1] or ''
                        
                        # 评分逻辑
                        is_correct = 0
                        score = 0
                        if student_answer and q.correct_answer and \
                           student_answer.strip().lower() == q.correct_answer.strip().lower():
                            is_correct = 1
                            score = q.score or 0
                            
                        # 更新评分
                        cursor.execute('''
                            UPDATE question_scores 
                            SET is_correct = ?, score = ?, needs_grading = 0, is_manually_graded = 0
                            WHERE id = ?
                        ''', (is_correct, score, qs_id))
                
                success_count += 1
            
            conn.commit()
        
        # 循环结束后，统一重新计算总分
        print(f"[BATCH_OBJECTIVE] 正在重新计算 {len(result_ids_to_recalc)} 个考试结果的总分...")
        for rid in result_ids_to_recalc:
            try:
                db.recalculate_exam_score(rid)
            except Exception as recalc_error:
                print(f"[WARNING] 重新计算总分失败 (Result ID: {rid}): {recalc_error}")
            
        return jsonify({
            'success': True, 
            'message': f'已完成 {success_count} 名学生的客观题评分'
        })
        
    except Exception as e:
        print(f"[ERROR] 批量客观题评分失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'评分失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/batch-grade-subjective', methods=['POST'])
@login_required
def batch_grade_subjective(exam_id):
    """批量对主观题进行AI评分（针对所有已提交的学生）"""
    try:
        from grading_engine import get_grading_engine
        
        db = Database()
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取评分方法
        method = request.args.get('method', 'ai_fusion')
            
        # 1. 查找需要评分的主观题记录
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 获取所有已提交且包含主观题的记录
            # 这里我们查找所有未完成评分的主观题
            # 或者，根据需求，重新评分所有主观题（为了应用新的评分标准）
            cursor.execute('''
                SELECT qs.id, qs.question_id, qs.student_answer, qs.correct_answer, 
                       qs.question_type, qs.question_text, qs.max_score,
                       er.student_id, er.id as result_id
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.exam_id = ? 
                AND er.is_completed = 1
                AND qs.question_type NOT IN ('choice', 'judge')
            ''', (exam_id,))
            
            rows = cursor.fetchall()
            
        if not rows:
            return jsonify({'success': False, 'message': '没有找到需要评分的主观题'})
            
        print(f"[BATCH_SUBJECTIVE] 找到 {len(rows)} 个主观题需要评分")
        
        # 2. 准备批量评分数据
        grading_engine = get_grading_engine()
        ai_results = []
        processed_count = 0
        failed_count = 0
        
        # 记录涉及的学生ID，以便后续调整总分
        affected_students = set()
        
        for row in rows:
            try:
                qs_id = row[0]
                student_answer = row[2] or ''
                reference_answer = row[3] or ''
                question_type = row[4]
                question_text = row[5] or ''
                max_score = float(row[6] or 5.0)
                student_id = row[7]
                
                affected_students.add(student_id)
                
                # 调用评分引擎
                grading_result = grading_engine.grade(
                    question_type=question_type,
                    student_answer=student_answer,
                    reference_answer=reference_answer,
                    question_text=question_text,
                    max_score=max_score,
                    method=method
                )
                
                ai_results.append({
                    'question_score_id': qs_id,
                    'ai_result': grading_result
                })
                
                processed_count += 1
                
                # 每50条保存一次，避免内存过大
                if len(ai_results) >= 50:
                    db.batch_save_ai_grading_results(ai_results)
                    ai_results = []
                    
            except Exception as e:
                print(f"[ERROR] 题目 {row[0]} 评分失败: {e}")
                failed_count += 1
                
        # 保存剩余结果
        if ai_results:
            db.batch_save_ai_grading_results(ai_results)
            
        # 3. 调整所有受影响学生的总分（64-85规则）
        adjusted_count = 0
        for student_id in affected_students:
            try:
                adjust_student_total_score(db, exam_id, student_id, 64, 85)
                adjusted_count += 1
            except Exception as e:
                print(f"[ERROR] 学生 {student_id} 总分调整失败: {e}")
                
        return jsonify({
            'success': True, 
            'message': f'已完成批量主观题评分: 处理 {processed_count} 题，涉及 {adjusted_count} 名学生'
        })
        
    except Exception as e:
        print(f"[ERROR] 批量主观题评分失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'评分失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/submission-status')
@login_required
def get_exam_submission_status(exam_id):
    """获取考试提交状态（API）"""
    try:
        db = Database()
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取监控配置
        monitoring_config = db.get_exam_monitoring_config(exam_id)
            
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 获取所有学生提交状态，添加切屏数据
            cursor.execute('''
                SELECT 
                    s.id, s.student_id, s.name, s.class_name,
                    er.is_completed, er.score, er.total_score,
                    er.start_time, er.end_time, er.id as result_id,
                    er.is_graded, er.needs_grading,
                    er.focus_lost_count, er.focus_lost_logs
                FROM students s
                LEFT JOIN exam_results er ON s.id = er.student_id AND er.exam_id = ?
                ORDER BY s.student_id
            ''', (exam_id,))
            
            students = []
            for row in cursor.fetchall():
                is_completed = bool(row[4]) if row[4] is not None else False
                
                # 处理状态显示
                status = 'not_started'
                if is_completed:
                    status = 'completed'
                elif row[7]: # start_time exists
                    status = 'in_progress'
                
                students.append({
                    'id': row[0],
                    'student_id': row[1],
                    'name': row[2],
                    'class_name': row[3],
                    'is_completed': is_completed,
                    'score': row[5] if row[5] is not None else 0,
                    'total_score': row[6] if row[6] is not None else exam.total_score,
                    'start_time': row[7],
                    'end_time': row[8],
                    'result_id': row[9],
                    'status': status,
                    'is_graded': bool(row[10]) if row[10] is not None else False,
                    'needs_grading': bool(row[11]) if row[11] is not None else False,
                    'focus_lost_count': row[12] if row[12] is not None else 0,
                    'focus_lost_logs': row[13] if row[13] is not None else '[]'
                })
                
        return jsonify({
            'success': True,
            'students': students,
            'monitoring_config': monitoring_config
        })
        
    except Exception as e:
        print(f"[ERROR] 获取提交状态失败: {e}")
        return jsonify({'success': False, 'message': str(e)})

@teacher_bp.route('/exams/<int:exam_id>/monitoring-settings', methods=['POST'])
@login_required
def update_exam_monitoring_settings(exam_id):
    """更新考试监控设置"""
    try:
        data = request.get_json()
        max_focus_warnings = int(data.get('max_focus_warnings', 9))
        auto_submit_on_exceed = bool(data.get('auto_submit_on_exceed', True))
        warning_interval_seconds = int(data.get('warning_interval_seconds', 30))
        enable_focus_monitoring = bool(data.get('enable_focus_monitoring', True))
        
        db = Database()
        success = db.update_exam_monitoring_config(
            exam_id, 
            max_focus_warnings, 
            auto_submit_on_exceed, 
            warning_interval_seconds,
            enable_focus_monitoring
        )
        
        if success:
            return jsonify({'success': True, 'message': '监控设置已更新'})
        else:
            return jsonify({'success': False, 'message': '更新设置失败'})
            
    except Exception as e:
        print(f"[ERROR] 更新监控设置失败: {e}")
        return jsonify({'success': False, 'message': f'更新设置失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/random-fill-subjective', methods=['POST'])
@login_required
def random_fill_subjective(exam_id):
    """随机填充主观题答案（帮助学生完成考试）"""
    try:
        import random
        from datetime import datetime
        
        db = Database()
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取请求参数
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '未选择学生'})
            
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        # 过滤出主观题
        subjective_questions = [q for q in questions if q.question_type not in ['choice', 'judge']]
        
        if not subjective_questions:
            return jsonify({'success': False, 'message': '该考试没有主观题'})
            
        success_count = 0
        filled_count = 0
        
        with db.get_write_connection() as conn:
            cursor = conn.cursor()
            
            for student_id in student_ids:
                # 1. 确保 exam_results 记录存在
                cursor.execute('SELECT id, is_completed FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, student_id))
                row = cursor.fetchone()
                
                if not row:
                    # 如果没有记录，先创建一个
                    cursor.execute('''
                        INSERT INTO exam_results (exam_id, student_id, answers, score, total_score, start_time, end_time, is_completed, is_graded, needs_grading) 
                        VALUES (?, ?, ?, 0, ?, ?, ?, 1, 0, 1)
                    ''', (exam_id, student_id, '{}', exam.total_score, datetime.now().isoformat(), datetime.now().isoformat()))
                    result_id = cursor.lastrowid
                else:
                    result_id = row[0]
                    # 确保标记为完成
                    if not row[1]:
                        cursor.execute('UPDATE exam_results SET is_completed = 1 WHERE id = ?', (result_id,))
                
                # 2. 找出该学生缺失的主观题
                missing_questions = []
                for q in subjective_questions:
                    cursor.execute('''
                        SELECT id, student_answer FROM question_scores 
                        WHERE exam_result_id = ? AND question_id = ?
                    ''', (result_id, q.id))
                    qs_row = cursor.fetchone()
                    
                    # 如果没有记录或者答案为空，视为缺失
                    if not qs_row or not qs_row[1] or not qs_row[1].strip():
                        missing_questions.append({
                            'question': q,
                            'qs_id': qs_row[0] if qs_row else None
                        })
                
                if not missing_questions:
                    continue
                    
                # 3. 随机选择一部分题目进行填充 (例如 60% 的概率，或者最多3道)
                # 策略：如果缺失 N 道，随机填 min(N, 3) 道，或者 min(N, ceil(N*0.6))
                # 用户要求："比如一个学生有5道主观题空着，就给他填上3道"
                
                num_missing = len(missing_questions)
                num_to_fill = min(num_missing, 3)
                if num_missing > 5:
                    num_to_fill = int(num_missing * 0.6)
                
                if num_to_fill > 0:
                    selected_questions = random.sample(missing_questions, num_to_fill)
                    
                    for item in selected_questions:
                        q = item['question']
                        qs_id = item['qs_id']
                        
                        # 填充正确答案
                        fill_answer = q.correct_answer
                        # 给满分（或者根据需求给部分分，这里给满分）
                        fill_score = q.score or 5.0
                        
                        if qs_id:
                            # 更新现有记录
                            cursor.execute('''
                                UPDATE question_scores 
                                SET student_answer = ?, score = ?, is_manually_graded = 0, needs_grading = 0
                                WHERE id = ?
                            ''', (fill_answer, fill_score, qs_id))
                        else:
                            # 插入新记录
                            cursor.execute('''
                                INSERT INTO question_scores 
                                (exam_result_id, question_id, question_order, student_answer, correct_answer, 
                                 is_correct, score, max_score, question_type, question_text, 
                                 is_manually_graded, needs_grading) 
                                VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?, 0, 0)
                            ''', (result_id, q.id, 999, fill_answer, q.correct_answer, 
                                  fill_score, q.score or 5.0, q.question_type, (q.question_text or '')[:200]))
                        
                        filled_count += 1
                    
                    success_count += 1
            
            conn.commit()
            
        # 批量重新计算总分
        result_ids_to_recalc = []
        with db.get_connection() as conn:
            cursor = conn.cursor()
            for student_id in student_ids:
                cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, student_id))
                res = cursor.fetchone()
                if res:
                    result_ids_to_recalc.append(res[0])
        
        for rid in result_ids_to_recalc:
            try:
                db.recalculate_exam_score(rid)
            except Exception as e:
                print(f"[WARNING] Recalculate failed for {rid}: {e}")
                
        return jsonify({
            'success': True,
            'message': f'随机填充完成：为 {success_count} 名学生填充了 {filled_count} 道主观题'
        })
        
    except Exception as e:
        print(f"[ERROR] 随机填充主观题失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'操作失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/random-improve-subjective', methods=['POST'])
@login_required
def random_improve_subjective(exam_id):
    """随机提升主观题分数（帮助学生提高成绩）"""
    try:
        import random
        from datetime import datetime
        
        db = Database()
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
            
        # 获取请求参数
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '未选择学生'})
            
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        # 过滤出主观题
        subjective_questions = [q for q in questions if q.question_type not in ['choice', 'judge']]
        
        if not subjective_questions:
            return jsonify({'success': False, 'message': '该考试没有主观题'})
            
        success_count = 0
        improved_count = 0
        
        with db.get_write_connection() as conn:
            cursor = conn.cursor()
            
            for student_id in student_ids:
                # 1. 确保 exam_results 记录存在
                cursor.execute('SELECT id, is_completed FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, student_id))
                row = cursor.fetchone()
                
                if not row:
                    # 如果没有记录，跳过（或者可以创建，但提升通常针对已有答卷）
                    continue
                    
                result_id = row[0]
                
                # 2. 找出该学生得分未满的主观题
                improvable_questions = []
                for q in subjective_questions:
                    cursor.execute('''
                        SELECT id, score, max_score FROM question_scores 
                        WHERE exam_result_id = ? AND question_id = ?
                    ''', (result_id, q.id))
                    qs_row = cursor.fetchone()
                    
                    max_score = q.score or 5.0
                    
                    # 如果没有记录，或者分数低于满分
                    if not qs_row:
                        improvable_questions.append({
                            'question': q,
                            'qs_id': None,
                            'max_score': max_score
                        })
                    else:
                        current_score = qs_row[1] if qs_row[1] is not None else 0
                        # 确保使用记录中的max_score或者题目定义的max_score
                        record_max_score = qs_row[2] if qs_row[2] is not None else max_score
                        
                        if current_score < record_max_score:
                            improvable_questions.append({
                                'question': q,
                                'qs_id': qs_row[0],
                                'max_score': record_max_score
                            })
                
                if not improvable_questions:
                    continue
                    
                # 3. 随机选择3道题目进行提升
                num_to_improve = min(len(improvable_questions), 3)
                
                if num_to_improve > 0:
                    selected_questions = random.sample(improvable_questions, num_to_improve)
                    
                    for item in selected_questions:
                        q = item['question']
                        qs_id = item['qs_id']
                        max_score = item['max_score']
                        
                        # 填充标准答案
                        fill_answer = q.correct_answer
                        # 给满分
                        fill_score = max_score
                        
                        if qs_id:
                            # 更新现有记录
                            cursor.execute('''
                                UPDATE question_scores 
                                SET student_answer = ?, score = ?, is_manually_graded = 0, needs_grading = 0, is_correct = 1
                                WHERE id = ?
                            ''', (fill_answer, fill_score, qs_id))
                        else:
                            # 插入新记录
                            cursor.execute('''
                                INSERT INTO question_scores 
                                (exam_result_id, question_id, question_order, student_answer, correct_answer, 
                                 is_correct, score, max_score, question_type, question_text, 
                                 is_manually_graded, needs_grading) 
                                VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?, 0, 0)
                            ''', (result_id, q.id, 999, fill_answer, q.correct_answer, 
                                  fill_score, max_score, q.question_type, (q.question_text or '')[:200]))
                        
                        improved_count += 1
                    
                    success_count += 1
            
            conn.commit()
            
        # 批量重新计算总分
        result_ids_to_recalc = []
        with db.get_connection() as conn:
            cursor = conn.cursor()
            for student_id in student_ids:
                cursor.execute('SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?', (exam_id, student_id))
                res = cursor.fetchone()
                if res:
                    result_ids_to_recalc.append(res[0])
        
        for rid in result_ids_to_recalc:
            try:
                db.recalculate_exam_score(rid)
            except Exception as e:
                print(f"[WARNING] Recalculate failed for {rid}: {e}")
                
        return jsonify({
            'success': True,
            'message': f'随机提升完成：为 {success_count} 名学生提升了 {improved_count} 道主观题'
        })
        
    except Exception as e:
        print(f"[ERROR] 随机提升主观题失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'操作失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/force-submit-students', methods=['POST'])
@login_required
def force_submit_students(exam_id):
    """强制提交指定学生的考试"""
    try:
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择要强制提交的学生'})
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        success_count = 0
        failed_count = 0
        failed_students = []
        
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        for student_id in student_ids:
            try:
                # 使用新的评分逻辑进行强制提交
                submit_result, error_msg = force_submit_with_grading(db, exam_id, student_id, current_time)
                if submit_result:
                    success_count += 1
                    print(f"强制提交成功 - 学生ID: {student_id}, 得分: {submit_result['score']:.1f}/{submit_result['total_score']:.1f}, 已答题数: {submit_result['answered_questions']}")
                else:
                    raise Exception(error_msg or "强制提交失败")
                    
            except Exception as e:
                print(f"Force submit student {student_id} error: {e}")
                failed_count += 1
                # 获取学生姓名用于错误报告
                try:
                    with db.get_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT name FROM students WHERE id = ?', (student_id,))
                        student_result = cursor.fetchone()
                        student_name = student_result[0] if student_result else f'ID:{student_id}'
                        failed_students.append(student_name)
                except:
                    failed_students.append(f'ID:{student_id}')
        
        message = f'成功强制提交 {success_count} 名学生的考试'
        if failed_count > 0:
            message += f'，失败 {failed_count} 名'
            if failed_students:
                message += f'（失败学生: {", ".join(failed_students[:3])}{"等" if len(failed_students) > 3 else ""}）'
        
        return jsonify({
            'success': True,
            'message': message,
            'submitted': success_count,
            'failed': failed_count
        })
        
    except Exception as e:
        print(f"Force submit students error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'强制提交失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/allow-continue-students', methods=['POST'])
@login_required
def allow_continue_students(exam_id):
    """允许已提交的学生继续考试 - 全面改进版"""
    try:
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择要允许继续考试的学生'})
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        success_count = 0
        failed_count = 0
        failed_students = []
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            for student_id in student_ids:
                try:
                    # 获取学生信息
                    cursor.execute('SELECT student_id, name FROM students WHERE id = ?', (student_id,))
                    student_result = cursor.fetchone()
                    if not student_result:
                        failed_count += 1
                        failed_students.append(f'ID:{student_id}')
                        continue
                    
                    student_number, student_name = student_result
                    
                    # 🔥 关键修复1：检查是否有已完成的考试记录
                    cursor.execute('''
                        SELECT id, answers, score, total_score FROM exam_results
                        WHERE student_id = ? AND exam_id = ?
                        ORDER BY id DESC LIMIT 1
                    ''', (student_id, exam_id))
                    
                    exam_result = cursor.fetchone()
                    
                    if exam_result:
                        result_id, saved_answers, current_score, current_total = exam_result
                        
                        # 🔥 关键修复2：重置考试结果状态为未完成
                        cursor.execute('''
                            UPDATE exam_results
                            SET is_completed = 0, 
                                end_time = NULL, 
                                score = 0, 
                                total_score = 0
                            WHERE id = ?
                        ''', (result_id,))
                        print(f"重置了 exam_result_id={result_id} 的完成状态")
                        
                        # 🔥 关键修复3：删除相关的题目得分记录，避免状态不一致
                        cursor.execute('''
                            DELETE FROM question_scores
                            WHERE exam_result_id = ?
                        ''', (result_id,))
                        print(f"删除了 exam_result_id={result_id} 的所有题目得分记录")
                        
                        # 🔥 关键修复4：创建或更新考试进度记录，确保学生能重新进入
                        try:
                            # 解析已保存的答案
                            import json
                            answers_dict = {}
                            if saved_answers:
                                try:
                                    answers_dict = json.loads(saved_answers)
                                    print(f"恢复学生 {student_number} 的答案，共 {len(answers_dict)} 个")
                                except Exception as e:
                                    print(f"解析答案失败: {e}")
                                    answers_dict = {}
                            
                            # 🔥 关键修复5：使用REPLACE确保进度记录存在且活跃
                            from datetime import datetime
                            cursor.execute('''
                                INSERT OR REPLACE INTO exam_progress 
                                (exam_id, student_number, student_name, answer_data, answers, 
                                 start_time, last_save_time, elapsed_minutes, session_id, 
                                 ip_address, user_agent, is_active)
                                VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), 0, 
                                        'allow_continue_' || ?, 'system', 'Teacher Allow Continue', 1)
                            ''', (exam_id, student_number, student_name, 
                                  json.dumps(answers_dict, ensure_ascii=False),
                                  json.dumps(answers_dict, ensure_ascii=False),
                                  datetime.now().strftime('%Y%m%d%H%M%S')))
                            
                            print(f"创建了学生 {student_number} 的活跃进度记录")
                            
                        except Exception as e:
                            print(f"创建进度记录失败: {e}")
                            # 至少创建一个空的进度记录
                            cursor.execute('''
                                INSERT OR REPLACE INTO exam_progress 
                                (exam_id, student_number, student_name, answer_data, answers,
                                 start_time, last_save_time, elapsed_minutes, session_id, 
                                 ip_address, user_agent, is_active)
                                VALUES (?, ?, ?, '{}', '{}', datetime('now'), datetime('now'), 0, 
                                        'allow_continue_' || ?, 'system', 'Teacher Allow Continue', 1)
                            ''', (exam_id, student_number, student_name, 
                                  datetime.now().strftime('%Y%m%d%H%M%S')))
                        
                        # 🔥 关键修复6：清理可能存在的学生会话冲突
                        cursor.execute('''
                            UPDATE student_sessions 
                            SET is_active = 0 
                            WHERE student_number = ? AND is_active = 1
                        ''', (student_number,))
                        
                        print(f"允许学生 {student_number}({student_name}) 继续考试，已保留原有答案")
                        success_count += 1
                        
                    else:
                        # 没有考试记录，创建新的进度记录
                        cursor.execute('''
                            INSERT OR REPLACE INTO exam_progress 
                            (exam_id, student_number, student_name, answer_data, answers,
                             start_time, last_save_time, elapsed_minutes, session_id, 
                             ip_address, user_agent, is_active)
                            VALUES (?, ?, ?, '{}', '{}', datetime('now'), datetime('now'), 0, 
                                    'allow_continue_' || ?, 'system', 'Teacher Allow Continue', 1)
                        ''', (exam_id, student_number, student_name, 
                              datetime.now().strftime('%Y%m%d%H%M%S')))
                        
                        print(f"为学生 {student_number}({student_name}) 创建新的考试进度记录")
                        success_count += 1
                        
                except Exception as e:
                    print(f"Allow continue student {student_id} error: {e}")
                    import traceback
                    traceback.print_exc()
                    failed_count += 1
                    # 获取学生姓名用于错误报告
                    try:
                        cursor.execute('SELECT name FROM students WHERE id = ?', (student_id,))
                        student_result = cursor.fetchone()
                        student_name = student_result[0] if student_result else f'ID:{student_id}'
                        failed_students.append(student_name)
                    except:
                        failed_students.append(f'ID:{student_id}')
            
            conn.commit()
        
        message = f'成功允许 {success_count} 名学生继续考试'
        if failed_count > 0:
            message += f'，失败 {failed_count} 名'
            if failed_students:
                message += f'（失败学生: {", ".join(failed_students[:3])}{"等" if len(failed_students) > 3 else ""}）'
        
        return jsonify({
            'success': True,
            'message': message,
            'allowed': success_count,
            'failed': failed_count
        })
        
    except Exception as e:
        print(f"Allow continue students error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'允许继续考试失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/clear-student-progress', methods=['POST'])
@login_required
def clear_student_progress(exam_id):
    """清除学生的考试记录（完全重置）"""
    try:
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择要清除记录的学生'})
        
        success_count = 0
        failed_count = 0
        failed_students = []
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            for student_id in student_ids:
                try:
                    # 删除考试结果记录
                    cursor.execute('''
                        DELETE FROM exam_results
                        WHERE student_id = ? AND exam_id = ?
                    ''', (student_id, exam_id))
                    
                    # 删除题目得分记录
                    cursor.execute('''
                        DELETE FROM question_scores
                        WHERE exam_result_id IN (
                            SELECT id FROM exam_results 
                            WHERE student_id = ? AND exam_id = ?
                        )
                    ''', (student_id, exam_id))
                    
                    # 删除考试进度记录（如果有）
                    cursor.execute('SELECT student_id FROM students WHERE id = ?', (student_id,))
                    student_result = cursor.fetchone()
                    if student_result:
                        student_number = student_result[0]
                        cursor.execute('''
                            DELETE FROM exam_progress
                            WHERE exam_id = ? AND student_number = ?
                        ''', (exam_id, student_number))
                    
                    success_count += 1
                    
                except Exception as e:
                    print(f"Clear student {student_id} progress error: {e}")
                    failed_count += 1
                    # 获取学生姓名用于错误报告
                    cursor.execute('SELECT name FROM students WHERE id = ?', (student_id,))
                    student_result = cursor.fetchone()
                    student_name = student_result[0] if student_result else f'ID:{student_id}'
                    failed_students.append(student_name)
            
            conn.commit()
        
        message = f'成功清除 {success_count} 名学生的考试记录'
        if failed_count > 0:
            message += f'，失败 {failed_count} 名'
            if failed_students:
                message += f'（失败学生: {", ".join(failed_students[:3])}{"等" if len(failed_students) > 3 else ""}）'
        
        return jsonify({
            'success': True,
            'message': message,
            'cleared': success_count,
            'failed': failed_count
        })
        
    except Exception as e:
        print(f"Clear student progress error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'清除学生记录失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/student-submissions-page')
@login_required
def exam_student_submissions_page(exam_id):
    """学生提交状态管理页面"""
    try:
        db = Database()
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            flash('考试不存在', 'error')
            return redirect(url_for('teacher.exams'))
        
        return render_template('teacher/exam_submissions.html', exam_id=exam_id, exam=exam)
        
    except Exception as e:
        print(f"Exam student submissions page error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载学生提交状态管理页面失败', 'error')
        return redirect(url_for('teacher.exams'))

# ===============================
# 考试题目编辑功能
# ===============================

@teacher_bp.route('/exams/<int:exam_id>/questions/<int:question_id>')
@login_required
def get_exam_question(exam_id, question_id):
    """获取考试中的题目详情"""
    try:
        db = Database()
        
        # 验证题目是否属于该考试
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT q.* FROM questions q
                JOIN exam_questions eq ON q.id = eq.question_id
                WHERE eq.exam_id = ? AND q.id = ?
            ''', (exam_id, question_id))
            
            result = cursor.fetchone()
            if not result:
                return jsonify({'success': False, 'message': '题目不存在或不属于该考试'})
            
            # 转换为字典格式
            columns = [description[0] for description in cursor.description]
            question = dict(zip(columns, result))
            
            return jsonify({'success': True, 'question': question})
        
    except Exception as e:
        print(f"Get exam question error: {e}")
        return jsonify({'success': False, 'message': f'获取题目失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/questions/<int:question_id>/edit', methods=['POST'])
@login_required
def edit_exam_question(exam_id, question_id):
    """编辑考试中的题目内容"""
    try:
        db = Database()
        
        # 获取表单数据
        question_type = request.form.get('question_type')
        question_text = request.form.get('question_text')
        score = float(request.form.get('score', 1))
        explanation = request.form.get('explanation', '')
        difficulty = int(request.form.get('difficulty', 2))
        category = request.form.get('category', '')
        material = request.form.get('material', '')
        
        # 根据题目类型获取答案相关字段
        import json
        options_json = '{}'
        if question_type == 'choice':
            option_a = request.form.get('option_a', '')
            option_b = request.form.get('option_b', '')
            option_c = request.form.get('option_c', '')
            option_d = request.form.get('option_d', '')
            
            options_dict = {
                'A': option_a,
                'B': option_b,
                'C': option_c,
                'D': option_d
            }
            options_json = json.dumps(options_dict, ensure_ascii=False)
            correct_answer = request.form.get('correct_answer')
        else:
            correct_answer = request.form.get('correct_answer', '')
        
        if not question_text:
            return jsonify({'success': False, 'message': '题目内容不能为空'})
        
        # 验证题目是否属于该考试
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 1 FROM exam_questions 
                WHERE exam_id = ? AND question_id = ?
            ''', (exam_id, question_id))
            
            if not cursor.fetchone():
                return jsonify({'success': False, 'message': '题目不属于该考试'})
            
            # 🔥 关键设计：只更新该考试中的题目副本，不影响全局题目库
            # 创建题目副本并更新exam_questions关联
            
            # 1. 插入新的题目记录（副本）
            cursor.execute('''
                INSERT INTO questions (
                    question_type, question_text, options,
                    correct_answer, explanation, score, difficulty, subject, material, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
            ''', (question_type, question_text, options_json,
                  correct_answer, explanation, score, difficulty, category, material))
            
            new_question_id = cursor.lastrowid
            
            # 2. 更新exam_questions关联，指向新的题目副本
            cursor.execute('''
                UPDATE exam_questions
                SET question_id = ?
                WHERE exam_id = ? AND question_id = ?
            ''', (new_question_id, exam_id, question_id))
            
            conn.commit()
            
            print(f"考试 {exam_id} 中的题目 {question_id} 已更新为新副本 {new_question_id}")
            
            return jsonify({
                'success': True, 
                'message': '题目更新成功（已创建考试专用副本）',
                'new_question_id': new_question_id
            })
        
    except Exception as e:
        print(f"Edit exam question error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'编辑题目失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/questions/<int:question_id>/remove', methods=['POST'])
@login_required
def remove_exam_question(exam_id, question_id):
    """从考试中移除题目"""
    try:
        db = Database()
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 验证题目是否属于该考试
            cursor.execute('''
                SELECT 1 FROM exam_questions 
                WHERE exam_id = ? AND question_id = ?
            ''', (exam_id, question_id))
            
            if not cursor.fetchone():
                return jsonify({'success': False, 'message': '题目不属于该考试'})
            
            # 从考试中移除题目（不删除题库中的题目）
            cursor.execute('''
                DELETE FROM exam_questions
                WHERE exam_id = ? AND question_id = ?
            ''', (exam_id, question_id))
            
            # 更新考试的题目统计
            cursor.execute('''
                SELECT COUNT(*), COALESCE(SUM(q.score), 0)
                FROM exam_questions eq
                JOIN questions q ON eq.question_id = q.id
                WHERE eq.exam_id = ?
            ''', (exam_id,))
            
            count, total_score = cursor.fetchone()
            
            cursor.execute('''
                UPDATE exams
                SET total_questions = ?, total_score = ?
                WHERE id = ?
            ''', (count, total_score, exam_id))
            
            conn.commit()
            
            return jsonify({
                'success': True, 
                'message': '题目已从考试中移除',
                'remaining_questions': count,
                'total_score': total_score
            })
        
    except Exception as e:
        print(f"Remove exam question error: {e}")
        return jsonify({'success': False, 'message': f'移除题目失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/questions/add', methods=['POST'])
@login_required
def add_questions_to_exam(exam_id):
    """添加现有题目到考试"""
    try:
        db = Database()
        
        question_ids = request.form.getlist('question_ids')
        if not question_ids:
            return jsonify({'success': False, 'message': '请选择要添加的题目'})
        
        # 转换为整数
        question_ids = [int(qid) for qid in question_ids]
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            added_count = 0
            skipped_count = 0
            
            for question_id in question_ids:
                # 检查题目是否已存在于考试中
                cursor.execute('''
                    SELECT 1 FROM exam_questions 
                    WHERE exam_id = ? AND question_id = ?
                ''', (exam_id, question_id))
                
                if cursor.fetchone():
                    skipped_count += 1
                    continue
                
                # 添加题目到考试
                cursor.execute('''
                    INSERT INTO exam_questions (exam_id, question_id, question_order)
                    VALUES (?, ?, 
                        (SELECT COALESCE(MAX(question_order), 0) + 1 
                         FROM exam_questions WHERE exam_id = ?))
                ''', (exam_id, question_id, exam_id))
                
                added_count += 1
            
            # 更新考试统计
            cursor.execute('''
                SELECT COUNT(*), COALESCE(SUM(q.score), 0)
                FROM exam_questions eq
                JOIN questions q ON eq.question_id = q.id
                WHERE eq.exam_id = ?
            ''', (exam_id,))
            
            count, total_score = cursor.fetchone()
            
            cursor.execute('''
                UPDATE exams
                SET total_questions = ?, total_score = ?
                WHERE id = ?
            ''', (count, total_score, exam_id))
            
            conn.commit()
            
            message = f'成功添加 {added_count} 道题目'
            if skipped_count > 0:
                message += f'，跳过 {skipped_count} 道重复题目'
            
            return jsonify({
                'success': True, 
                'message': message,
                'added': added_count,
                'skipped': skipped_count,
                'total_questions': count
            })
        
    except Exception as e:
        print(f"Add questions to exam error: {e}")
        return jsonify({'success': False, 'message': f'添加题目失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/questions/new', methods=['POST'])
@login_required
def add_new_question_to_exam(exam_id):
    """添加新题目到考试"""
    try:
        db = Database()
        
        # 获取表单数据
        question_type = request.form.get('question_type')
        question_text = request.form.get('question_text')
        score = float(request.form.get('score', 1))
        explanation = request.form.get('explanation', '')
        difficulty = int(request.form.get('difficulty', 2))
        category = request.form.get('category', '')
        material = request.form.get('material', '')
        
        # 根据题目类型获取答案相关字段
        import json
        options_json = '{}'
        if question_type == 'choice':
            option_a = request.form.get('option_a', '')
            option_b = request.form.get('option_b', '')
            option_c = request.form.get('option_c', '')
            option_d = request.form.get('option_d', '')
            
            options_dict = {
                'A': option_a,
                'B': option_b,
                'C': option_c,
                'D': option_d
            }
            options_json = json.dumps(options_dict, ensure_ascii=False)
            correct_answer = request.form.get('correct_answer')
        else:
            correct_answer = request.form.get('correct_answer', '')
        
        if not question_text:
            return jsonify({'success': False, 'message': '题目内容不能为空'})
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. 创建新题目
            cursor.execute('''
                INSERT INTO questions (
                    question_type, question_text, options,
                    correct_answer, explanation, score, difficulty, subject, material, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
            ''', (question_type, question_text, options_json,
                  correct_answer, explanation, score, difficulty, category, material))
            
            new_question_id = cursor.lastrowid
            
            # 2. 添加到考试
            cursor.execute('''
                INSERT INTO exam_questions (exam_id, question_id, question_order)
                VALUES (?, ?, 
                    (SELECT COALESCE(MAX(question_order), 0) + 1 
                     FROM exam_questions WHERE exam_id = ?))
            ''', (exam_id, new_question_id, exam_id))
            
            # 3. 更新考试统计
            cursor.execute('''
                SELECT COUNT(*), COALESCE(SUM(q.score), 0)
                FROM exam_questions eq
                JOIN questions q ON eq.question_id = q.id
                WHERE eq.exam_id = ?
            ''', (exam_id,))
            
            count, total_score = cursor.fetchone()
            
            cursor.execute('''
                UPDATE exams
                SET total_questions = ?, total_score = ?
                WHERE id = ?
            ''', (count, total_score, exam_id))
            
            conn.commit()
            
            return jsonify({
                'success': True, 
                'message': '新题目添加成功',
                'question_id': new_question_id,
                'total_questions': count
            })
        
    except Exception as e:
        print(f"Add new question to exam error: {e}")
        return jsonify({'success': False, 'message': f'添加新题目失败: {str(e)}'})

# ===============================
# 考试题目Word文档导出功能 - 完全重写版
# ===============================

@teacher_bp.route('/exams/<int:exam_id>/export-word')
@login_required
def export_exam_word(exam_id):
    """导出考试题目为Word文档 - 完全重写版"""
    try:
        from docx import Document
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.style import WD_STYLE_TYPE
        from docx.enum.table import WD_TABLE_ALIGNMENT
        import io
        from flask import send_file
        
        db = Database()
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        # 获取考试题目（包含完整信息，按类型优先级排序）
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT q.id, q.question_type, q.question_text, q.options, 
                       q.correct_answer, q.score, q.difficulty, q.subject, q.material, eq.question_order
                FROM questions q
                JOIN exam_questions eq ON q.id = eq.question_id
                WHERE eq.exam_id = ?
                ORDER BY 
                    CASE q.question_type
                        WHEN 'choice' THEN 1
                        WHEN 'judge' THEN 2
                        WHEN 'short_answer' THEN 3
                        WHEN 'fill_blank' THEN 4
                        WHEN 'essay' THEN 5
                        ELSE 6
                    END,
                    eq.question_order
            ''', (exam_id,))
            
            question_rows = cursor.fetchall()
        
        if not question_rows:
            return jsonify({'success': False, 'message': '该考试暂无题目'})
        
        # 构建题目对象
        questions = []
        for row in question_rows:
            # 解析JSON选项
            options_data = {}
            if row[3]:  # options字段
                try:
                    import json
                    options_data = json.loads(row[3])
                except:
                    options_data = {}
            
            question = type('Question', (), {
                'id': row[0],
                'question_type': row[1],
                'question_text': row[2],
                'options': row[3] or '',
                'option_a': options_data.get('A', ''),
                'option_b': options_data.get('B', ''),
                'option_c': options_data.get('C', ''),
                'option_d': options_data.get('D', ''),
                'correct_answer': row[4] or '',
                'explanation': '',  # 数据库中没有explanation字段
                'score': row[5] or 1,
                'difficulty': row[6] or 1,
                'subject': row[7] or '',
                'material': row[8] or '',
                'question_order': row[9]
            })()
            questions.append(question)
        
        # 获取导出参数
        include_answers = request.args.get('answers', 'false').lower() == 'true'
        include_grading = request.args.get('grading', 'false').lower() == 'true'
        
        # 创建Word文档
        doc = Document()
        
        # 设置文档样式
        setup_word_document_styles(doc)
        
        # 添加考试标题
        title = doc.add_heading(f'{exam.title}', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # 添加副标题（根据导出类型）
        if include_answers and include_grading:
            subtitle = doc.add_heading('（参考答案及评分细则版）', level=1)
        elif include_answers:
            subtitle = doc.add_heading('（参考答案版）', level=1)
        else:
            subtitle = doc.add_heading('（学生答题版）', level=1)
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # 添加考试信息表格
        add_exam_information_table(doc, exam, questions)
        
        # 添加答题说明
        add_examination_instructions(doc, questions, include_answers)
        
        # 添加分割线
        doc.add_paragraph('=' * 80).alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # 按原始顺序添加题目内容（不分组）
        add_questions_in_order(doc, questions, include_answers, include_grading)
        
        # 如果包含答案，添加答案部分
        if include_answers:
            add_comprehensive_answer_section(doc, questions, include_grading)
        
        # 保存文档到内存
        doc_buffer = io.BytesIO()
        doc.save(doc_buffer)
        doc_buffer.seek(0)
        
        # 生成文件名
        suffix = '_学生答题版' if not include_answers else '_参考答案版'
        if include_grading and include_answers:
            suffix = '_答案评分细则版'
        
        filename = f'{exam.title}{suffix}.docx'
        
        return send_file(
            doc_buffer,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
        
    except ImportError:
        return jsonify({
            'success': False, 
            'message': '缺少python-docx库，请先安装：pip install python-docx'
        })
    except Exception as e:
        print(f"Export exam word error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'导出Word文档失败: {str(e)}'})

def setup_word_document_styles(doc):
    """设置Word文档样式"""
    try:
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.style import WD_STYLE_TYPE
        
        # 设置默认字体
        style = doc.styles['Normal']
        font = style.font
        font.name = '宋体'
        font.size = Pt(12)
        
        # 创建题目内容样式
        if 'QuestionContent' not in [s.name for s in doc.styles]:
            content_style = doc.styles.add_style('QuestionContent', WD_STYLE_TYPE.PARAGRAPH)
            content_font = content_style.font
            content_font.name = '宋体'
            content_font.size = Pt(12)
            content_style.paragraph_format.space_after = Pt(6)
        
        # 创建选项样式
        if 'OptionStyle' not in [s.name for s in doc.styles]:
            option_style = doc.styles.add_style('OptionStyle', WD_STYLE_TYPE.PARAGRAPH)
            option_font = option_style.font
            option_font.name = '宋体'
            option_font.size = Pt(11)
            option_style.paragraph_format.left_indent = Inches(0.5)
            option_style.paragraph_format.space_after = Pt(3)
        
        # 创建材料样式
        if 'MaterialStyle' not in [s.name for s in doc.styles]:
            material_style = doc.styles.add_style('MaterialStyle', WD_STYLE_TYPE.PARAGRAPH)
            material_font = material_style.font
            material_font.name = '楷体'
            material_font.size = Pt(11)
            material_style.paragraph_format.left_indent = Inches(0.3)
            material_style.paragraph_format.right_indent = Inches(0.3)
            material_style.paragraph_format.space_before = Pt(6)
            material_style.paragraph_format.space_after = Pt(6)
        
        # 创建答案样式
        if 'AnswerStyle' not in [s.name for s in doc.styles]:
            answer_style = doc.styles.add_style('AnswerStyle', WD_STYLE_TYPE.PARAGRAPH)
            answer_font = answer_style.font
            answer_font.name = '楷体'
            answer_font.size = Pt(11)
            answer_font.color.rgb = RGBColor(0, 100, 0)  # 深绿色
            
    except Exception as e:
        print(f"Setup document styles warning: {e}")

def add_exam_information_table(doc, exam, questions):
    """添加考试基本信息表格"""
    from docx.shared import Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    
    # 统计题型信息
    type_stats = {}
    total_score = 0
    
    type_names = {
        'choice': '单项选择题',
        'judge': '判断题',
        'fill_blank': '填空题',
        'short_answer': '简答题',
        'essay': '论述题'
    }
    
    for question in questions:
        qtype = question.question_type
        type_name = type_names.get(qtype, f'{qtype}题')
        
        if type_name not in type_stats:
            type_stats[type_name] = {'count': 0, 'score': 0}
        
        type_stats[type_name]['count'] += 1
        type_stats[type_name]['score'] += question.score
        total_score += question.score
    
    # 创建考试信息表格
    table = doc.add_table(rows=0, cols=4)
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 第一行：基本信息
    row1 = table.add_row()
    row1.cells[0].text = '考试时长'
    row1.cells[1].text = f'{exam.duration_minutes} 分钟'
    row1.cells[2].text = '题目总数'
    row1.cells[3].text = f'{len(questions)} 题'
    
    # 第二行：分值信息
    row2 = table.add_row()
    row2.cells[0].text = '总分'
    row2.cells[1].text = f'{total_score} 分'
    row2.cells[2].text = '考试日期'
    row2.cells[3].text = '_____年____月____日'
    
    # 第三行：题型统计
    if type_stats:
        row3 = table.add_row()
        row3.cells[0].text = '题型分布'
        type_info = '、'.join([f'{name}({stats["count"]}题,{stats["score"]}分)' 
                              for name, stats in type_stats.items()])
        merged_cell = row3.cells[1]
        for i in range(2, 4):
            merged_cell.merge(row3.cells[i])
        merged_cell.text = type_info
    
    # 设置表格样式
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in paragraph.runs:
                    run.font.size = Pt(10)
    
    doc.add_paragraph()  # 添加空行

def add_examination_instructions(doc, questions, include_answers):
    """添加考试说明"""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    
    # 添加说明标题
    instructions_heading = doc.add_heading('考试说明', level=2)
    instructions_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 添加答题要求
    doc.add_paragraph().add_run('答题要求：').bold = True
    requirements = [
        '1. 请在规定时间内完成所有题目，合理分配答题时间',
        '2. 单项选择题：从A、B、C、D四个选项中选择一个最佳答案',
        '3. 判断题：判断题目表述是否正确，选择"正确"或"错误"',
        '4. 填空题：在空白处填入正确答案，注意答案的准确性',
        '5. 简答题：回答要点明确，表述简洁清晰',
        '6. 论述题：观点明确，论证充分，逻辑清晰'
    ]
    
    if not include_answers:
        requirements.append('7. 请将答案写在答题卡上，在试卷上作答无效')
    
    for req in requirements:
        doc.add_paragraph(req)
    
    doc.add_paragraph()  # 添加空行

def add_questions_in_order(doc, questions, include_answers, include_grading):
    """按原始顺序添加题目（不分组）"""
    from docx.shared import Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    
    for i, question in enumerate(questions, 1):
        # 添加题目材料（如果有）
        if question.material and question.material.strip():
            material_heading = doc.add_paragraph()
            material_heading.add_run(f'【题目 {i} 阅读材料】').bold = True
            material_heading.alignment = WD_ALIGN_PARAGRAPH.LEFT
            
            # 添加材料内容
            material_lines = question.material.strip().split('\n')
            for line in material_lines:
                if line.strip():
                    material_para = doc.add_paragraph(line.strip())
                    material_para.style = 'MaterialStyle'
            
            doc.add_paragraph()  # 材料后空行
        
        # 添加题目标题和内容
        question_para = doc.add_paragraph()
        question_para.add_run(f'{i}. ').bold = True
        question_para.add_run(f'({question.score}分) ').italic = True
        
        # 根据题型添加标识
        type_labels = {
            'choice': '【单选题】',
            'judge': '【判断题】',
            'fill_blank': '【填空题】',
            'short_answer': '【简答题】',
            'essay': '【论述题】'
        }
        
        type_label = type_labels.get(question.question_type, f'【{question.question_type}题】')
        question_para.add_run(type_label).bold = True
        question_para.add_run(' ')
        question_para.add_run(question.question_text)
        question_para.style = 'QuestionContent'
        
        # 根据题目类型添加选项或答题空间
        if question.question_type == 'choice':
            add_choice_question_options(doc, question, include_answers)
        elif question.question_type == 'judge':
            add_judge_question_options(doc, question, include_answers)
        elif question.question_type in ['fill_blank', 'short_answer', 'essay']:
            add_subjective_answer_space(doc, question.question_type, include_answers, question.correct_answer if include_answers else None)
        else:
            # 其他题型也添加答题空间
            add_subjective_answer_space(doc, 'other', include_answers, question.correct_answer if include_answers else None)
        
        # 添加解题提示（在学生版中显示）
        if not include_answers and question.explanation and question.explanation.strip():
            hint_para = doc.add_paragraph()
            hint_para.add_run('解题提示：').bold = True
            hint_para.add_run(question.explanation).italic = True
        
        # 题目间空行
        doc.add_paragraph()

def add_choice_question_options(doc, question, include_answers):
    """添加选择题选项"""
    from docx.shared import RGBColor
    
    options = [
        ('A', question.option_a),
        ('B', question.option_b),
        ('C', question.option_c),
        ('D', question.option_d)
    ]
    
    for option_letter, option_text in options:
        if option_text and option_text.strip():
            option_para = doc.add_paragraph()
            option_para.style = 'OptionStyle'
            
            if include_answers and question.correct_answer.upper() == option_letter:
                # 正确答案标记
                run = option_para.add_run(f'{option_letter}. {option_text} ✓')
                run.bold = True
                run.font.color.rgb = RGBColor(0, 120, 0)  # 深绿色
            else:
                option_para.add_run(f'{option_letter}. {option_text}')

def add_judge_question_options(doc, question, include_answers):
    """添加判断题选项"""
    from docx.shared import RGBColor
    
    option_para = doc.add_paragraph()
    option_para.style = 'OptionStyle'
    
    if include_answers:
        correct_answer = question.correct_answer.lower()
        is_true = correct_answer in ['true', '对', '是', '正确', 't', '1', 'yes']
        
        if is_true:
            true_run = option_para.add_run('A. 正确 ✓')
            true_run.bold = True
            true_run.font.color.rgb = RGBColor(0, 120, 0)
            option_para.add_run('    B. 错误')
        else:
            option_para.add_run('A. 正确    ')
            false_run = option_para.add_run('B. 错误 ✓')
            false_run.bold = True
            false_run.font.color.rgb = RGBColor(0, 120, 0)
    else:
        option_para.add_run('A. 正确    B. 错误')

def add_subjective_answer_space(doc, question_type, include_answers, correct_answer=None):
    """添加主观题答题空间"""
    if include_answers and correct_answer:
        # 显示参考答案
        answer_para = doc.add_paragraph()
        answer_para.add_run('参考答案：').bold = True
        answer_para.add_run(correct_answer)
        answer_para.style = 'AnswerStyle'
        return
    
    if include_answers:
        return  # 答案版本但没有具体答案内容
        
    # 根据题型添加不同的答题空间
    if question_type == 'fill_blank':
        space_para = doc.add_paragraph()
        space_para.add_run('答案：___________________________________')
    elif question_type == 'short_answer':
        doc.add_paragraph('答案：')
        for i in range(5):
            doc.add_paragraph('_' * 80)
    elif question_type == 'essay':
        doc.add_paragraph('答案：')
        for i in range(10):
            doc.add_paragraph('_' * 80)
    else:
        doc.add_paragraph('答案：')
        for i in range(4):
            doc.add_paragraph('_' * 80)

def add_comprehensive_answer_section(doc, questions, include_grading):
    """添加完整的答案部分"""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    
    # 添加分页符
    doc.add_page_break()
    
    # 添加答案部分标题
    answer_title = doc.add_heading('参考答案与解析', level=1)
    answer_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    if include_grading:
        grading_note = doc.add_paragraph('（含详细评分细则）')
        grading_note.alignment = WD_ALIGN_PARAGRAPH.CENTER
        grading_note.italic = True
    
    doc.add_paragraph()
    
    # 按顺序添加每题答案
    for i, question in enumerate(questions, 1):
        add_individual_question_answer(doc, question, i, include_grading)

def add_individual_question_answer(doc, question, question_number, include_grading):
    """添加单题完整答案"""
    from docx.shared import RGBColor
    
    # 题目编号和答案
    answer_para = doc.add_paragraph()
    answer_para.add_run(f'{question_number}. ').bold = True
    
    # 根据题型格式化答案
    if question.question_type == 'choice':
        answer_para.add_run(f'【答案】{question.correct_answer}')
    elif question.question_type == 'judge':
        correct_answer = question.correct_answer.lower()
        is_true = correct_answer in ['true', '对', '是', '正确', 't', '1', 'yes']
        answer_text = '正确' if is_true else '错误'
        answer_para.add_run(f'【答案】{answer_text}')
    else:
        answer_para.add_run(f'【答案】{question.correct_answer}')
    
    # 添加解析
    if question.explanation and question.explanation.strip():
        explanation_para = doc.add_paragraph()
        explanation_para.add_run('【解析】').bold = True
        explanation_para.add_run(question.explanation)
    
    # 添加评分细则
    if include_grading:
        add_detailed_grading_criteria(doc, question)
    
    doc.add_paragraph()  # 答案间空行

def add_detailed_grading_criteria(doc, question):
    """添加详细评分细则"""
    score = question.score
    
    criteria_para = doc.add_paragraph()
    criteria_para.add_run('【评分细则】').bold = True
    
    if question.question_type in ['choice', 'judge']:
        criteria_para.add_run(f'答案正确得{score}分，答案错误或不答得0分。')
    elif question.question_type == 'fill_blank':
        criteria_para.add_run(f'答案完全正确得{score}分；')
        criteria_para.add_run(f'答案基本正确（如大小写、标点等细微差异）得{score*0.8:.1f}分；')
        criteria_para.add_run(f'答案部分正确得{score*0.5:.1f}分；')
        criteria_para.add_run('答案错误或空白得0分。')
    elif question.question_type == 'short_answer':
        criteria_para.add_run(f'要点齐全且表述准确得{score}分；')
        criteria_para.add_run(f'要点基本齐全且表述较准确得{score*0.8:.1f}-{score*0.9:.1f}分；')
        criteria_para.add_run(f'要点不够齐全或表述有明显错误得{score*0.5:.1f}-{score*0.7:.1f}分；')
        criteria_para.add_run(f'要点缺失较多得{score*0.2:.1f}-{score*0.4:.1f}分；')
        criteria_para.add_run('要点严重缺失或完全错误得0分。')
    elif question.question_type == 'essay':
        criteria_para.add_run(f'论点明确、论据充分、逻辑清晰、语言流畅得{score}分；')
        criteria_para.add_run(f'论点较明确、论据较充分、逻辑较清晰得{score*0.8:.1f}-{score*0.9:.1f}分；')
        criteria_para.add_run(f'论点基本明确、论据基本充分得{score*0.6:.1f}-{score*0.7:.1f}分；')
        criteria_para.add_run(f'论点不够明确或论据不足得{score*0.3:.1f}-{score*0.5:.1f}分；')
        criteria_para.add_run(f'论点不明确或严重偏题得{score*0.1:.1f}-{score*0.2:.1f}分；')
        criteria_para.add_run('不答或完全偏题得0分。')
    else:
        criteria_para.add_run(f'根据答题质量和完整性分层给分，满分{score}分。')

@teacher_bp.route('/exams/<int:exam_id>/details')
@login_required
def get_exam_details(exam_id):
    """获取考试详情和学生实时状态"""
    try:
        db = Database()
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        # 获取考试题目数量
        questions = db.get_exam_questions(exam_id)
        total_questions = len(questions)
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 获取考试结果和学生状态
            cursor.execute('''
                SELECT 
                    s.id as student_id,
                    s.student_id as student_number,
                    s.name as student_name,
                    s.college,
                    s.major,
                    s.class_name,
                    er.id as result_id,
                    er.start_time,
                    er.end_time,
                    er.score,
                    er.total_score,
                    er.is_completed,
                    er.elapsed_minutes
                FROM students s
                LEFT JOIN exam_results er ON s.id = er.student_id AND er.exam_id = ?
                ORDER BY s.student_id
            ''', (exam_id,))
            
            students_results = cursor.fetchall()
            
            # 获取考试进度信息
            cursor.execute('''
                SELECT 
                    ep.student_number,
                    ep.student_name,
                    ep.start_time,
                    ep.last_save_time,
                    ep.elapsed_minutes,
                    ep.session_id,
                    ep.ip_address,
                    ep.user_agent,
                    ep.is_active,
                    ep.answer_data
                FROM exam_progress ep
                WHERE ep.exam_id = ? AND ep.is_active = 1
            ''', (exam_id,))
            
            progress_data = cursor.fetchall()
            
            # 获取学生活动会话
            cursor.execute('''
                SELECT 
                    ss.student_number,
                    ss.student_name,
                    ss.session_id,
                    ss.ip_address,
                    ss.user_agent,
                    ss.login_time,
                    ss.last_activity,
                    ss.is_active
                FROM student_sessions ss
                WHERE ss.is_active = 1
                ORDER BY ss.last_activity DESC
            ''')
            
            active_sessions = cursor.fetchall()
        
        # 构建进度字典
        progress_dict = {}
        for progress in progress_data:
            student_number = progress[0]
            try:
                answer_data = json.loads(progress[9]) if progress[9] else {}
                answered_count = len([v for v in answer_data.values() if v and str(v).strip()])
            except:
                answered_count = 0
            
            progress_dict[student_number] = {
                'start_time': progress[2],
                'last_save_time': progress[3],
                'elapsed_minutes': progress[4] or 0,
                'session_id': progress[5],
                'ip_address': progress[6],
                'user_agent': progress[7],
                'is_active': bool(progress[8]),
                'answered_count': answered_count,
                'total_questions': total_questions,
                'progress_percent': round((answered_count / total_questions * 100) if total_questions > 0 else 0, 1)
            }
        
        # 构建会话字典
        session_dict = {}
        for session in active_sessions:
            student_number = session[0]
            session_dict[student_number] = {
                'session_id': session[2],
                'ip_address': session[3],
                'user_agent': session[4],
                'login_time': session[5],
                'last_activity': session[6],
                'is_active': bool(session[7])
            }
        
        # 构建学生详情列表
        students_details = []
        for student_result in students_results:
            student_number = student_result[1]
            
            # 获取状态
            if student_result[6]:  # 有exam_result记录
                if student_result[11]:  # is_completed
                    status = 'completed'
                    status_text = '已完成'
                else:
                    status = 'in_progress'
                    status_text = '进行中'
            else:
                # 检查是否有进度记录
                if student_number in progress_dict:
                    status = 'in_progress'
                    status_text = '进行中'
                else:
                    status = 'not_started'
                    status_text = '未开始'
            
            # 获取进度信息
            progress_info = progress_dict.get(student_number, {})
            session_info = session_dict.get(student_number, {})
            
            student_detail = {
                'student_id': student_result[0],
                'student_number': student_number,
                'student_name': student_result[2],
                'college': student_result[3] or '',
                'major': student_result[4] or '',
                'class_name': student_result[5] or '',
                'status': status,
                'status_text': status_text,
                'start_time': student_result[7] or progress_info.get('start_time'),
                'end_time': student_result[8],
                'score': student_result[9] or 0,
                'total_score': student_result[10] or exam.total_score,
                'elapsed_minutes': student_result[12] or progress_info.get('elapsed_minutes', 0),
                'answered_count': progress_info.get('answered_count', 0),
                'total_questions': total_questions,
                'progress_percent': progress_info.get('progress_percent', 0),
                'ip_address': progress_info.get('ip_address') or session_info.get('ip_address', ''),
                'user_agent': progress_info.get('user_agent') or session_info.get('user_agent', ''),
                'last_activity': progress_info.get('last_save_time') or session_info.get('last_activity'),
                'is_online': progress_info.get('is_active', False) or session_info.get('is_active', False),
                'session_id': progress_info.get('session_id') or session_info.get('session_id', '')
            }
            
            students_details.append(student_detail)
        
        # 统计信息
        total_students = len(students_details)
        completed_count = len([s for s in students_details if s['status'] == 'completed'])
        in_progress_count = len([s for s in students_details if s['status'] == 'in_progress'])
        not_started_count = len([s for s in students_details if s['status'] == 'not_started'])
        online_count = len([s for s in students_details if s['is_online']])
        
        return jsonify({
            'success': True,
            'exam': {
                'id': exam.id,
                'title': exam.title,
                'description': exam.description,
                'duration_minutes': exam.duration_minutes,
                'total_questions': total_questions,
                'total_score': exam.total_score,
                'is_active': exam.is_active,
                'created_at': exam.created_at
            },
            'statistics': {
                'total_students': total_students,
                'completed_count': completed_count,
                'in_progress_count': in_progress_count,
                'not_started_count': not_started_count,
                'online_count': online_count,
                'completion_rate': round((completed_count / total_students * 100) if total_students > 0 else 0, 1)
            },
            'students': students_details
        })
        
    except Exception as e:
        print(f"获取考试详情失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'获取考试详情失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/export-details')
@login_required
def export_exam_details(exam_id):
    """导出考试详情为CSV文件"""
    try:
        db = Database()
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        # 获取详细的学生状态信息（复用之前的逻辑）
        questions = db.get_exam_questions(exam_id)
        total_questions = len(questions)
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 获取考试结果和学生状态
            cursor.execute('''
                SELECT 
                    s.id as student_id,
                    s.student_id as student_number,
                    s.name as student_name,
                    s.college,
                    s.major,
                    s.class_name,
                    er.id as result_id,
                    er.start_time,
                    er.end_time,
                    er.score,
                    er.total_score,
                    er.is_completed,
                    er.elapsed_minutes
                FROM students s
                LEFT JOIN exam_results er ON s.id = er.student_id AND er.exam_id = ?
                ORDER BY s.student_id
            ''', (exam_id,))
            
            students_results = cursor.fetchall()
            
            # 获取考试进度信息
            cursor.execute('''
                SELECT 
                    ep.student_number,
                    ep.student_name,
                    ep.start_time,
                    ep.last_save_time,
                    ep.elapsed_minutes,
                    ep.session_id,
                    ep.ip_address,
                    ep.user_agent,
                    ep.is_active,
                    ep.answer_data
                FROM exam_progress ep
                WHERE ep.exam_id = ? AND ep.is_active = 1
            ''', (exam_id,))
            
            progress_data = cursor.fetchall()
            
            # 获取学生活动会话
            cursor.execute('''
                SELECT 
                    ss.student_number,
                    ss.student_name,
                    ss.session_id,
                    ss.ip_address,
                    ss.user_agent,
                    ss.login_time,
                    ss.last_activity,
                    ss.is_active
                FROM student_sessions ss
                WHERE ss.is_active = 1
                ORDER BY ss.last_activity DESC
            ''')
            
            active_sessions = cursor.fetchall()
        
        # 构建进度字典
        progress_dict = {}
        for progress in progress_data:
            student_number = progress[0]
            try:
                answer_data = json.loads(progress[9]) if progress[9] else {}
                answered_count = len([v for v in answer_data.values() if v and str(v).strip()])
            except:
                answered_count = 0
            
            progress_dict[student_number] = {
                'start_time': progress[2],
                'last_save_time': progress[3],
                'elapsed_minutes': progress[4] or 0,
                'session_id': progress[5],
                'ip_address': progress[6],
                'user_agent': progress[7],
                'is_active': bool(progress[8]),
                'answered_count': answered_count,
                'total_questions': total_questions,
                'progress_percent': round((answered_count / total_questions * 100) if total_questions > 0 else 0, 1)
            }
        
        # 构建会话字典
        session_dict = {}
        for session in active_sessions:
            student_number = session[0]
            session_dict[student_number] = {
                'session_id': session[2],
                'ip_address': session[3],
                'user_agent': session[4],
                'login_time': session[5],
                'last_activity': session[6],
                'is_active': bool(session[7])
            }
        
        # 构建CSV数据
        csv_data = []
        csv_headers = [
            '学号', '姓名', '学院', '专业', '班级', '状态', '开始时间', '结束时间', 
            '已用时间(分钟)', '答题进度', '答题百分比', '分数', '总分', 'IP地址', 
            '用户代理', '最后活动时间', '是否在线', '会话ID'
        ]
        
        for student_result in students_results:
            student_number = student_result[1]
            
            # 获取状态
            if student_result[6]:  # 有exam_result记录
                if student_result[11]:  # is_completed
                    status = '已完成'
                else:
                    status = '进行中'
            else:
                # 检查是否有进度记录
                if student_number in progress_dict:
                    status = '进行中'
                else:
                    status = '未开始'
            
            # 获取进度信息
            progress_info = progress_dict.get(student_number, {})
            session_info = session_dict.get(student_number, {})
            
            # 格式化时间
            start_time = student_result[7] or progress_info.get('start_time', '')
            end_time = student_result[8] or ''
            last_activity = progress_info.get('last_save_time') or session_info.get('last_activity', '')
            
            # 格式化进度
            answered_count = progress_info.get('answered_count', 0)
            progress_text = f"{answered_count}/{total_questions}"
            progress_percent = progress_info.get('progress_percent', 0)
            
            # 格式化分数
            score = student_result[9] or 0
            total_score = student_result[10] or exam.total_score
            
            # 其他信息
            ip_address = progress_info.get('ip_address') or session_info.get('ip_address', '')
            user_agent = progress_info.get('user_agent') or session_info.get('user_agent', '')
            is_online = progress_info.get('is_active', False) or session_info.get('is_active', False)
            session_id = progress_info.get('session_id') or session_info.get('session_id', '')
            elapsed_minutes = student_result[12] or progress_info.get('elapsed_minutes', 0)
            
            csv_row = [
                student_number,  # 学号
                student_result[2],  # 姓名
                student_result[3] or '',  # 学院
                student_result[4] or '',  # 专业
                student_result[5] or '',  # 班级
                status,  # 状态
                start_time,  # 开始时间
                end_time,  # 结束时间
                elapsed_minutes,  # 已用时间(分钟)
                progress_text,  # 答题进度
                f"{progress_percent}%",  # 答题百分比
                score,  # 分数
                total_score,  # 总分
                ip_address,  # IP地址
                user_agent,  # 用户代理
                last_activity,  # 最后活动时间
                '是' if is_online else '否',  # 是否在线
                session_id  # 会话ID
            ]
            
            csv_data.append(csv_row)
        
        # 生成CSV文件
        import csv
        import io
        from flask import send_file
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # 写入UTF-8 BOM
        output.write('\ufeff')
        
        # 写入表头
        writer.writerow(csv_headers)
        
        # 写入数据
        for row in csv_data:
            writer.writerow(row)
        
        # 创建文件响应
        output.seek(0)
        content = output.getvalue()
        
        # 创建字节流
        mem = io.BytesIO()
        mem.write(content.encode('utf-8'))
        mem.seek(0)
        
        # 生成文件名
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"考试详情_{exam.title}_{timestamp}.csv"
        
        return send_file(
            mem,
            as_attachment=True,
            download_name=filename,
            mimetype='text/csv; charset=utf-8'
        )
        
    except Exception as e:
        print(f"导出考试详情失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'导出考试详情失败: {str(e)}'})

@teacher_bp.route('/exams/<int:exam_id>/start-exam-students', methods=['POST'])
@login_required
def start_exam_students(exam_id):
    """为选中的学生开始考试"""
    try:
        db = Database()
        data = request.get_json()
        student_ids = data.get('student_ids', [])
        
        if not student_ids:
            return jsonify({'success': False, 'message': '没有选择要开始考试的学生'})
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        if not exam.is_active:
            return jsonify({'success': False, 'message': '考试未激活，无法开始'})
        
        success_count = 0
        failed_count = 0
        failed_students = []
        
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            for student_id in student_ids:
                try:
                    # 获取学生信息
                    cursor.execute('SELECT student_id, name FROM students WHERE id = ?', (student_id,))
                    student_result = cursor.fetchone()
                    if not student_result:
                        failed_count += 1
                        failed_students.append(f'ID:{student_id}')
                        continue
                    
                    student_number, student_name = student_result
                    
                    # 检查是否已经有考试记录
                    cursor.execute('''
                        SELECT id FROM exam_results
                        WHERE student_id = ? AND exam_id = ?
                    ''', (student_id, exam_id))
                    
                    existing_result = cursor.fetchone()
                    
                    if existing_result:
                        # 已有考试记录，跳过
                        failed_count += 1
                        failed_students.append(f'{student_name}(已有记录)')
                        continue
                    
                    # 创建新的考试记录
                    cursor.execute('''
                        INSERT INTO exam_results 
                        (exam_id, student_id, answers, score, total_score, start_time, is_completed)
                        VALUES (?, ?, '{}', 0, ?, datetime('now'), 0)
                    ''', (exam_id, student_id, exam.total_score))
                    
                    result_id = cursor.lastrowid
                    
                    # 创建考试进度记录
                    from datetime import datetime
                    cursor.execute('''
                        INSERT OR REPLACE INTO exam_progress 
                        (exam_id, student_number, student_name, answer_data, answers,
                         start_time, last_save_time, elapsed_minutes, session_id, 
                         ip_address, user_agent, is_active)
                        VALUES (?, ?, ?, '{}', '{}', datetime('now'), datetime('now'), 0, 
                                'teacher_start_' || ?, 'system', 'Teacher Start Exam', 1)
                    ''', (exam_id, student_number, student_name, 
                          datetime.now().strftime('%Y%m%d%H%M%S')))
                    
                    print(f"为学生 {student_number}({student_name}) 开始考试，结果ID: {result_id}")
                    success_count += 1
                    
                except Exception as e:
                    print(f"Start exam for student {student_id} error: {e}")
                    import traceback
                    traceback.print_exc()
                    failed_count += 1
                    # 获取学生姓名用于错误报告
                    try:
                        cursor.execute('SELECT name FROM students WHERE id = ?', (student_id,))
                        student_result = cursor.fetchone()
                        student_name = student_result[0] if student_result else f'ID:{student_id}'
                        failed_students.append(student_name)
                    except:
                        failed_students.append(f'ID:{student_id}')
            
            conn.commit()
        
        message = f'成功为 {success_count} 名学生开始考试'
        if failed_count > 0:
            message += f'，失败 {failed_count} 名'
            if failed_students:
                message += f'（失败学生: {", ".join(failed_students[:3])}{"等" if len(failed_students) > 3 else ""}）'
        
        return jsonify({
            'success': True,
            'message': message,
            'started': success_count,
            'failed': failed_count
        })
        
    except Exception as e:
        print(f"Start exam students error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'开始考试失败: {str(e)}'})

@teacher_bp.route('/grading/unified')
@login_required
def unified_grading():
    """统一评分页面"""
    try:
        db = Database()
        
        # 获取所有需要评分的考试
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 获取需要评分的考试统计 (兼容旧数据库结构)
            cursor.execute("""
                SELECT 
                    e.id as exam_id,
                    e.title as exam_title,
                    e.description,
                    COUNT(DISTINCT er.id) as total_submissions,
                    COUNT(CASE WHEN COALESCE(er.needs_grading, 1) = 1 THEN 1 END) as need_grading,
                    COUNT(CASE WHEN COALESCE(er.is_graded, 0) = 1 THEN 1 END) as graded,
                    AVG(CASE WHEN COALESCE(er.is_graded, 0) = 1 THEN er.score ELSE NULL END) as avg_score
                FROM exams e
                LEFT JOIN exam_results er ON e.id = er.exam_id AND er.is_completed = 1
                GROUP BY e.id, e.title, e.description
                HAVING total_submissions > 0
                ORDER BY need_grading DESC, e.id DESC
            """)
            
            exam_grading_stats = cursor.fetchall()
        
        grading_exams = []
        for row in exam_grading_stats:
            grading_exams.append({
                'exam_id': row[0],
                'exam_title': row[1],
                'description': row[2] or '',
                'total_submissions': row[3],
                'need_grading': row[4],
                'graded': row[5],
                'avg_score': round(row[6], 1) if row[6] else 0,
                'grading_progress': round((row[5] / row[3] * 100), 1) if row[3] > 0 else 0
            })
        
        return render_template('teacher/unified_grading.html', 
                             grading_exams=grading_exams)
        
    except Exception as e:
        print(f"[ERROR] 统一评分页面错误: {e}")
        import traceback
        traceback.print_exc()
        flash('加载统一评分页面时发生错误', 'error')
        return render_template('teacher/unified_grading.html', grading_exams=[])

@teacher_bp.route('/grading/unified/calculate/<int:exam_id>', methods=['POST'])
@login_required
def unified_calculate_scores(exam_id):
    """统一计算指定考试的所有分数"""
    try:
        db = Database()
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'})
        
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        if not questions:
            return jsonify({'success': False, 'message': '考试没有题目'})
        
        # 获取所有需要评分的考试结果
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, student_id, answers 
                FROM exam_results 
                WHERE exam_id = ? AND is_completed = 1 AND COALESCE(needs_grading, 1) = 1
            """, (exam_id,))
            
            pending_results = cursor.fetchall()
        
            if not pending_results:
                return jsonify({
                    'success': False, 
                    'message': '没有需要评分的考试结果'
                })
            
            print(f"[UNIFIED_GRADING] 开始统一评分 - 考试: {exam.title}, 待评分: {len(pending_results)} 份")
            
            success_count = 0
            failed_count = 0
            total_processed = 0
            
            # 批量处理每个考试结果
            for result_row in pending_results:
                result_id, student_id, answers_json = result_row
                
                try:
                    # 解析答案
                    answers = json.loads(answers_json) if answers_json else {}
                    
                    # 计算分数
                    total_score = 0.0
                    max_total_score = 0.0
                    
                    for question in questions:
                        question_key = f'question_{question.id}'
                        student_answer = answers.get(question_key, '').strip()
                        
                        question_score = 0.0
                        max_score = question.score or 1.0
                        max_total_score += max_score
                        is_correct = False
                        
                        if student_answer:
                            if question.question_type in ['choice', 'judge']:
                                # 客观题：完全匹配
                                is_correct = student_answer.upper() == question.correct_answer.upper()
                                question_score = max_score if is_correct else 0.0
                            elif question.question_type in ['fill_blank']:
                                # 填空题：去除空格后比较
                                is_correct = student_answer.replace(' ', '').lower() == question.correct_answer.replace(' ', '').lower()
                                question_score = max_score if is_correct else 0.0
                            else:
                                # 主观题：给予部分分数，等待进一步人工评分
                                if len(student_answer) >= 10:
                                    question_score = max_score * 0.6  # 给60%的分数
                        
                        total_score += question_score
                        
                        # 更新题目得分 (兼容旧数据库)
                        try:
                            cursor.execute("""
                                UPDATE question_scores 
                                SET score = ?, is_correct = ?, needs_grading = 0
                                WHERE exam_result_id = ? AND question_id = ?
                            """, (question_score, is_correct, result_id, question.id))
                        except Exception:
                            # 如果needs_grading字段不存在，使用简化版本
                            cursor.execute("""
                                UPDATE question_scores 
                                SET score = ?, is_correct = ?
                                WHERE exam_result_id = ? AND question_id = ?
                            """, (question_score, is_correct, result_id, question.id))
                    
                    # 更新考试结果总分 (兼容旧数据库)
                    try:
                        cursor.execute("""
                            UPDATE exam_results 
                            SET score = ?, total_score = ?, is_graded = 1, needs_grading = 0
                            WHERE id = ?
                        """, (total_score, max_total_score, result_id))
                    except Exception:
                        # 如果字段不存在，使用简化版本
                        cursor.execute("""
                            UPDATE exam_results 
                            SET score = ?, total_score = ?
                            WHERE id = ?
                        """, (total_score, max_total_score, result_id))
                    
                    success_count += 1
                    total_processed += 1
                    
                    if total_processed % 10 == 0:
                        print(f"[UNIFIED_GRADING] 已处理 {total_processed}/{len(pending_results)} 份")
                    
                except Exception as e:
                    print(f"[ERROR] 评分失败 - 结果ID: {result_id}: {e}")
                    failed_count += 1
                    total_processed += 1
            
            # 提交所有更改
            conn.commit()
            
            print(f"[UNIFIED_GRADING] 统一评分完成 - 成功: {success_count}, 失败: {failed_count}")
            
            return jsonify({
                'success': True,
                'message': f'统一评分完成！成功评分 {success_count} 份，失败 {failed_count} 份',
                'details': {
                    'exam_title': exam.title,
                    'success_count': success_count,
                    'failed_count': failed_count,
                    'total_processed': total_processed
                }
            })
        
    except Exception as e:
        print(f"[ERROR] 统一评分失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'统一评分失败: {str(e)}'
        })

@teacher_bp.route('/grading/unified/calculate-all', methods=['POST'])
@login_required
def unified_calculate_all_scores():
    """统一计算所有考试的分数"""
    try:
        db = Database()
        
        # 获取所有需要评分的考试
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT DISTINCT e.id, e.title
                FROM exams e
                JOIN exam_results er ON e.id = er.exam_id
                WHERE er.is_completed = 1 AND COALESCE(er.needs_grading, 1) = 1
                ORDER BY e.id
            """)
            
            exams_to_grade = cursor.fetchall()
        
        if not exams_to_grade:
            return jsonify({
                'success': False,
                'message': '没有需要评分的考试'
            })
        
        print(f"[UNIFIED_GRADING_ALL] 开始批量评分 - 共 {len(exams_to_grade)} 个考试")
        
        total_success = 0
        total_failed = 0
        processed_exams = []
        
        for exam_row in exams_to_grade:
            exam_id, exam_title = exam_row
            
            try:
                # 调用单个考试的评分逻辑
                result = unified_calculate_scores_internal(db, exam_id)
                
                if result['success']:
                    total_success += result['success_count']
                    total_failed += result['failed_count']
                    processed_exams.append({
                        'exam_id': exam_id,
                        'exam_title': exam_title,
                        'success_count': result['success_count'],
                        'failed_count': result['failed_count'],
                        'status': 'completed'
                    })
                else:
                    processed_exams.append({
                        'exam_id': exam_id,
                        'exam_title': exam_title,
                        'success_count': 0,
                        'failed_count': 0,
                        'status': 'failed',
                        'error': result.get('message', '未知错误')
                    })
                
            except Exception as e:
                print(f"[ERROR] 考试 {exam_id} 评分失败: {e}")
                processed_exams.append({
                    'exam_id': exam_id,
                    'exam_title': exam_title,
                    'success_count': 0,
                    'failed_count': 0,
                    'status': 'failed',
                    'error': str(e)
                })
        
        print(f"[UNIFIED_GRADING_ALL] 批量评分完成 - 总成功: {total_success}, 总失败: {total_failed}")
        
        return jsonify({
            'success': True,
            'message': f'批量评分完成！总共成功评分 {total_success} 份，失败 {total_failed} 份',
            'details': {
                'total_success': total_success,
                'total_failed': total_failed,
                'processed_exams': processed_exams
            }
        })
        
    except Exception as e:
        print(f"[ERROR] 批量评分失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'批量评分失败: {str(e)}'
        })

def unified_calculate_scores_internal(db, exam_id):
    """内部统一评分函数（供批量调用）"""
    try:
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        if not questions:
            return {'success': False, 'message': '考试没有题目'}
        
        # 获取所有需要评分的考试结果
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, student_id, answers 
                FROM exam_results 
                WHERE exam_id = ? AND is_completed = 1 AND COALESCE(needs_grading, 1) = 1
            """, (exam_id,))
            
            pending_results = cursor.fetchall()
        
            if not pending_results:
                return {'success': True, 'success_count': 0, 'failed_count': 0}
            
            success_count = 0
            failed_count = 0
            
            # 批量处理每个考试结果
            for result_row in pending_results:
                result_id, student_id, answers_json = result_row
                
                try:
                    # 解析答案
                    answers = json.loads(answers_json) if answers_json else {}
                    
                    # 计算分数
                    total_score = 0.0
                    max_total_score = 0.0
                    
                    for question in questions:
                        question_key = f'question_{question.id}'
                        student_answer = answers.get(question_key, '').strip()
                        
                        question_score = 0.0
                        max_score = question.score or 1.0
                        max_total_score += max_score
                        is_correct = False
                        
                        if student_answer:
                            if question.question_type in ['choice', 'judge']:
                                is_correct = student_answer.upper() == question.correct_answer.upper()
                                question_score = max_score if is_correct else 0.0
                            elif question.question_type in ['fill_blank']:
                                is_correct = student_answer.replace(' ', '').lower() == question.correct_answer.replace(' ', '').lower()
                                question_score = max_score if is_correct else 0.0
                            else:
                                if len(student_answer) >= 10:
                                    question_score = max_score * 0.6
                        
                        total_score += question_score
                        
                        # 更新题目得分 (兼容旧数据库)
                        try:
                            cursor.execute("""
                                UPDATE question_scores 
                                SET score = ?, is_correct = ?, needs_grading = 0
                                WHERE exam_result_id = ? AND question_id = ?
                            """, (question_score, is_correct, result_id, question.id))
                        except Exception:
                            cursor.execute("""
                                UPDATE question_scores 
                                SET score = ?, is_correct = ?
                                WHERE exam_result_id = ? AND question_id = ?
                            """, (question_score, is_correct, result_id, question.id))
                    
                    # 更新考试结果总分 (兼容旧数据库)
                    try:
                        cursor.execute("""
                            UPDATE exam_results 
                            SET score = ?, total_score = ?, is_graded = 1, needs_grading = 0
                            WHERE id = ?
                        """, (total_score, max_total_score, result_id))
                    except Exception:
                        cursor.execute("""
                            UPDATE exam_results 
                            SET score = ?, total_score = ?
                            WHERE id = ?
                        """, (total_score, max_total_score, result_id))
                    
                    success_count += 1
                    
                except Exception as e:
                    print(f"[ERROR] 内部评分失败 - 结果ID: {result_id}: {e}")
                    failed_count += 1
            
            # 提交所有更改
            conn.commit()
            
            return {
                'success': True,
                'success_count': success_count,
                'failed_count': failed_count
            }
        
    except Exception as e:
        print(f"[ERROR] 内部统一评分失败: {e}")
        return {'success': False, 'message': str(e)}

@teacher_bp.route('/test-update-score')
@login_required
def test_update_score():
    """测试分数更新页面"""
    return render_template('teacher/test_update_score.html')

@teacher_bp.route('/test-export')
@login_required
def test_export():
    """测试导出功能页面"""
    return render_template('teacher/test_export.html')

@teacher_bp.route('/test-api')
@login_required
def test_api():
    """测试API是否可访问"""
    return jsonify({
        'success': True,
        'message': 'API is working',
        'user': current_user.username if hasattr(current_user, 'username') else 'Unknown'
    })

@teacher_bp.route('/get-sample-question-scores')
@login_required
def get_sample_question_scores():
    """获取一些示例的question_score记录用于测试"""
    try:
        db = Database()
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT qs.id, qs.exam_result_id, qs.score, qs.max_score, 
                       qs.question_type, qs.student_answer, er.exam_id, er.student_id
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.is_completed = 1
                ORDER BY qs.id DESC
                LIMIT 10
            """)
            
            results = []
            for row in cursor.fetchall():
                results.append({
                    'id': row[0],
                    'exam_result_id': row[1],
                    'score': row[2],
                    'max_score': row[3],
                    'question_type': row[4],
                    'student_answer': row[5],
                    'exam_id': row[6],
                    'student_id': row[7]
                })
            
            return jsonify({
                'success': True,
                'data': results
            })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        })

@teacher_bp.route('/exams/<int:exam_id>/export-student-papers')
@login_required
def export_student_papers(exam_id):
    """批量导出学生答卷为Word文档"""
    try:
        from docx import Document
        from docx.shared import Pt, Inches, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.style import WD_STYLE_TYPE
        import io
        import zipfile
        from datetime import datetime
        
        # 获取参数
        student_ids = request.args.get('student_ids', '').split(',')
        export_type = request.args.get('export_type', 'original')  # original, graded, both
        file_format = request.args.get('file_format', 'single')  # single, separate
        
        if not student_ids or student_ids == ['']:
            return jsonify({'success': False, 'message': '未选择学生'}), 400
        
        # 转换为整数
        student_ids = [int(sid) for sid in student_ids if sid]
        
        db = Database()
        
        # 获取考试信息
        exam = db.get_exam_by_id(exam_id)
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'}), 404
        
        # 获取考试题目
        questions = db.get_exam_questions(exam_id)
        
        # 获取学生答卷数据
        student_papers = []
        for student_id in student_ids:
            # 获取学生信息
            student = db.get_student_by_id(student_id, by_internal_id=True)
            if not student:
                continue
            
            # 获取考试结果
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT id, score, start_time, end_time, is_completed
                    FROM exam_results
                    WHERE exam_id = ? AND student_id = ? AND is_completed = 1
                    ORDER BY end_time DESC
                    LIMIT 1
                ''', (exam_id, student_id))
                
                result = cursor.fetchone()
                if not result:
                    continue
                
                result_id = result[0]
                
                # 使用与学生答卷详情页面相同的方法获取学生答案
                question_details = db.get_student_question_details(student.id, exam_id)
                
                student_papers.append({
                    'student': student,
                    'result': {
                        'id': result_id,
                        'score': result[1],
                        'start_time': result[2],
                        'end_time': result[3]
                    },
                    'question_details': question_details
                })
        
        if not student_papers:
            return jsonify({'success': False, 'message': '没有找到已完成的答卷'}), 404
        
        # 根据文件格式生成文档
        if file_format == 'single':
            # 合并为一个文件
            if export_type == 'both':
                # 生成两个文档
                doc_original = create_exam_papers_document(exam, questions, student_papers, False)
                doc_graded = create_exam_papers_document(exam, questions, student_papers, True)
                
                # 合并两个文档
                doc = Document()
                # 添加原版
                add_document_content(doc, doc_original, "学生答卷（原版）")
                # 添加分页符
                doc.add_page_break()
                # 添加评分版
                add_document_content(doc, doc_graded, "学生答卷（评分版）")
            else:
                # 生成单个文档
                include_grading = (export_type == 'graded')
                doc = create_exam_papers_document(exam, questions, student_papers, include_grading)
            
            # 保存到内存
            file_stream = io.BytesIO()
            doc.save(file_stream)
            file_stream.seek(0)
            
            # 返回文件
            filename = f"exam_papers_{exam_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
            return send_file(
                file_stream,
                mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                as_attachment=True,
                download_name=filename
            )
        
        else:  # separate
            # 分别导出每个学生的文档
            zip_stream = io.BytesIO()
            
            with zipfile.ZipFile(zip_stream, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                for paper in student_papers:
                    student = paper['student']
                    
                    if export_type == 'both':
                        # 生成两个版本
                        doc_original = create_single_student_paper(exam, questions, paper, False)
                        doc_graded = create_single_student_paper(exam, questions, paper, True)
                        
                        # 保存原版
                        doc_stream = io.BytesIO()
                        doc_original.save(doc_stream)
                        doc_stream.seek(0)
                        filename = f"{student.student_id}_{student.name}_原版.docx"
                        zip_file.writestr(filename, doc_stream.read())
                        
                        # 保存评分版
                        doc_stream = io.BytesIO()
                        doc_graded.save(doc_stream)
                        doc_stream.seek(0)
                        filename = f"{student.student_id}_{student.name}_评分版.docx"
                        zip_file.writestr(filename, doc_stream.read())
                    else:
                        # 生成单个版本
                        include_grading = (export_type == 'graded')
                        doc = create_single_student_paper(exam, questions, paper, include_grading)
                        
                        doc_stream = io.BytesIO()
                        doc.save(doc_stream)
                        doc_stream.seek(0)
                        
                        suffix = "_评分版" if include_grading else "_原版"
                        filename = f"{student.student_id}_{student.name}{suffix}.docx"
                        zip_file.writestr(filename, doc_stream.read())
            
            zip_stream.seek(0)
            
            # 返回ZIP文件
            filename = f"exam_papers_{exam_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
            return send_file(
                zip_stream,
                mimetype='application/zip',
                as_attachment=True,
                download_name=filename
            )
    
    except Exception as e:
        print(f"Export student papers error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'导出失败: {str(e)}'}), 500

def create_exam_papers_document(exam, questions, student_papers, include_grading):
    """创建包含多个学生答卷的Word文档"""
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    
    doc = Document()
    
    # 设置文档标题
    title = doc.add_heading(exam.title, 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 添加文档信息
    info_para = doc.add_paragraph()
    info_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    info_text = f"考试时长：{exam.duration_minutes}分钟 | 总分：{exam.total_score}分 | 题目数：{exam.total_questions}题"
    if include_grading:
        info_text += " | 评分版"
    else:
        info_text += " | 原版"
    info_para.add_run(info_text)
    
    # 为每个学生生成答卷
    for idx, paper in enumerate(student_papers):
        if idx > 0:
            doc.add_page_break()
        
        add_student_paper_to_document(doc, exam, questions, paper, include_grading)
    
    return doc

def create_single_student_paper(exam, questions, paper, include_grading):
    """创建单个学生的答卷文档"""
    from docx import Document
    
    doc = Document()
    add_student_paper_to_document(doc, exam, questions, paper, include_grading)
    return doc

def add_student_paper_to_document(doc, exam, questions, paper, include_grading):
    """将学生答卷添加到文档中"""
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    
    student = paper['student']
    result = paper['result']
    question_details = paper['question_details']
    
    # 学生信息标题
    student_heading = doc.add_heading(f"学生答卷", 1)
    student_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 学生基本信息表格
    table = doc.add_table(rows=2, cols=4)
    table.style = 'Light Grid Accent 1'
    
    # 第一行
    table.cell(0, 0).text = "学号"
    table.cell(0, 1).text = student.student_id
    table.cell(0, 2).text = "姓名"
    table.cell(0, 3).text = student.name
    
    # 第二行
    table.cell(1, 0).text = "学院"
    table.cell(1, 1).text = student.college or ""
    table.cell(1, 2).text = "专业"
    table.cell(1, 3).text = student.major or ""
    
    # 如果是评分版，添加成绩信息
    if include_grading:
        doc.add_paragraph()
        score_para = doc.add_paragraph()
        score_para.add_run(f"总成绩：").bold = True
        
        # 计算实际总分（从question_details中计算）
        actual_total_score = sum(detail.get('score', 0) for detail in question_details)
        max_total_score = sum(detail.get('max_score', 0) for detail in question_details)
        
        # 如果计算出的总分为0，则使用exam_results表中的分数
        if actual_total_score == 0 and result['score'] is not None:
            actual_total_score = result['score']
        
        # 如果计算出的满分为0，则使用考试设置的总分
        if max_total_score == 0:
            max_total_score = exam.total_score
        
        score_run = score_para.add_run(f"{actual_total_score:.1f} / {max_total_score:.1f} 分")
        score_run.font.size = Pt(14)
        score_run.font.color.rgb = RGBColor(255, 0, 0)
    
    doc.add_paragraph()
    
    # 创建题目详情映射（按question_order排序，如果有重复则取有答案的或最新的）
    question_details_map = {}
    for detail in question_details:
        order = detail['question_order']
        if order not in question_details_map:
            question_details_map[order] = detail
        else:
            # 如果已存在，优先选择有答案的记录
            existing = question_details_map[order]
            current_answer = detail.get('student_answer', '')
            existing_answer = existing.get('student_answer', '')
            
            # 优先选择有答案的记录，如果都有答案或都没答案，则保持原有的
            if current_answer and not existing_answer:
                question_details_map[order] = detail
    
    # 添加题目和答案
    doc.add_heading("答题内容", 2)
    
    # 按题目顺序显示
    for idx in range(1, len(question_details) + 1):
        detail = question_details_map.get(idx)
        if not detail:
            continue
            
        # 题目标题
        q_para = doc.add_paragraph()
        q_para.add_run(f"{idx}. ").bold = True
        
        # 题型标记
        type_names = {

            'choice': '选择题',
            'judge': '判断题',
            'fill': '填空题',
            'short_answer': '简答题',
            'essay': '论述题'
        }
        question_type = detail.get('question_type', '')
        q_para.add_run(f"[{type_names.get(question_type, question_type)}] ").bold = True
        
        # 分值
        if include_grading:
            max_score = detail.get('max_score', 0)
            q_para.add_run(f"({max_score}分) ")
        
        # 题目内容
        question_text = detail.get('question_text', '')
        q_para.add_run(question_text)
        
        # 选择题选项
        if question_type == 'choice' and detail.get('options'):
            import json
            try:
                options = detail['options']
                if isinstance(options, str):
                    options = json.loads(options)
                for key, value in options.items():
                    opt_para = doc.add_paragraph(f"    {key}. {value}", style='List Bullet')
            except:
                pass
        
        # 学生答案
        answer_para = doc.add_paragraph()
        answer_para.add_run("学生答案：").bold = True
        
        student_answer = detail.get('student_answer', '')
        if student_answer:
            # 判断题答案转换
            if question_type == 'judge':
                answer_text = student_answer
                if answer_text.lower() in ['true', 't', '1']:
                    answer_text = "对"
                elif answer_text.lower() in ['false', 'f', '0']:
                    answer_text = "错"
            else:
                answer_text = student_answer
            
            answer_para.add_run(answer_text)
        else:
            answer_para.add_run("未作答")
            
        # 如果是评分版，添加正确答案和得分
        if include_grading:
            # 正确答案
            correct_para = doc.add_paragraph()
            correct_para.add_run("正确答案：").bold = True
            
            correct_answer = detail.get('correct_answer', '')
            if question_type == 'judge':
                correct_text = correct_answer
                if correct_text.lower() in ['true', 't', '1']:
                    correct_text = "对"
                elif correct_text.lower() in ['false', 'f', '0']:
                    correct_text = "错"
            else:
                correct_text = correct_answer
                
            correct_run = correct_para.add_run(correct_text)
            correct_run.font.color.rgb = RGBColor(0, 128, 0)
            
            # 得分
            score_para = doc.add_paragraph()
            score_para.add_run("得分：").bold = True
            
            score = detail.get('score', 0)
            max_score = detail.get('max_score', 0)
            score_text = f"{score:.1f} / {max_score:.1f}"
            score_run = score_para.add_run(score_text)
            
            # 根据得分率设置颜色
            score_rate = score / max_score if max_score > 0 else 0
            if score_rate >= 0.8:
                score_run.font.color.rgb = RGBColor(0, 128, 0)  # 绿色
            elif score_rate >= 0.6:
                score_run.font.color.rgb = RGBColor(255, 165, 0)  # 橙色
            else:
                score_run.font.color.rgb = RGBColor(255, 0, 0)  # 红色
                
            # 如果有评语，添加评语
            grade_comment = detail.get('grade_comment', '')
            if grade_comment:
                comment_para = doc.add_paragraph()
                comment_para.add_run("评语：").bold = True
                comment_para.add_run(grade_comment)
        
        # 题目之间添加间隔
        doc.add_paragraph()

def add_document_content(target_doc, source_doc, title):
    """将源文档的内容添加到目标文档中"""
    # 添加标题
    target_doc.add_heading(title, 1)
    
    # 复制源文档的所有段落
    for element in source_doc.element.body:
        target_doc.element.body.append(element)

@teacher_bp.route('/exams/<int:exam_id>/student/<int:student_id>/details')
@login_required
def view_student_exam_details_by_id(exam_id, student_id):
    """根据考试ID和学生ID查看答卷详情（支持未提交状态预览）"""
    db = Database()
    
    # 1. 尝试查找已存在的考试结果
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?", (exam_id, student_id))
        row = cursor.fetchone()
        
        if row:
            # 如果已存在结果，直接复用现有逻辑
            return student_exam_details(row[0])

    # 2. 如果没有结果（进行中/未开始），构建虚拟预览
    try:
        student = db.get_student_by_id(student_id)
        exam = db.get_exam_by_id(exam_id)
        
        if not student or not exam:
            flash('学生或考试不存在', 'error')
            return redirect(url_for('teacher.exam_submissions', exam_id=exam_id))

        # 尝试恢复草稿答案
        try:
            from answer_preservation_system import recover_answers_safely
            recovery_result = recover_answers_safely(exam_id, student_id, student.student_id)
            recovered_answers = recovery_result.get('answers', {})
        except Exception as e:
            print(f"[ERROR] 恢复系统调用失败，尝试直接读取进度表: {e}")
            progress = db.get_exam_progress_by_student_number(exam_id, student.student_id)
            recovered_answers = {}
            if progress:
                import json
                answer_data = progress.get('answer_data') or progress.get('answers')
                if answer_data:
                    if isinstance(answer_data, str):
                        try:
                            recovered_answers = json.loads(answer_data)
                        except: pass
                    else:
                        recovered_answers = answer_data
        
        print(f"[PREVIEW_DETAILS] 构建虚拟答卷 - 学生: {student.name}, 恢复答案数: {len(recovered_answers)}")
        
        # 获取原始题目
        raw_questions = db.get_exam_questions(exam_id)
        
        # 构建虚拟的 questions 列表
        questions = []
        total_score = 0.0
        
        for i, q in enumerate(raw_questions):
            # 尝试匹配答案
            question_key = f'question_{q.id}'
            student_answer = ''
            
            # 多格式匹配
            if question_key in recovered_answers:
                student_answer = recovered_answers[question_key]
            elif str(q.id) in recovered_answers:
                student_answer = recovered_answers[str(q.id)]
            elif q.id in recovered_answers:
                student_answer = recovered_answers[q.id]
            
            student_answer = str(student_answer).strip()
            
            # 构建 detail 对象
            opts = {}
            if q.options and q.question_type == 'choice':
                try:
                    import json
                    parsed = json.loads(q.options)
                    if isinstance(parsed, dict):
                        opts = parsed
                except:
                    try:
                        parsed = eval(q.options)
                        if isinstance(parsed, dict):
                            opts = parsed
                    except:
                        opts = {}
            detail = {
                'id': q.id,
                'question_id': q.id,
                'question_order': i + 1,
                'question_text': q.question_text,
                'question_type': q.question_type,
                'score': 0.0,
                'max_score': q.score or 0.0,
                'student_answer': student_answer,
                'correct_answer': q.correct_answer,
                'is_correct': False,
                'options': opts,
                'grade_comment': '（草稿预览 - 未提交）',
                'is_manually_graded': False
            }
            questions.append(detail)

        # 构建虚拟 result 对象
        virtual_result = {
            'id': 0, # 虚拟ID
            'exam_id': exam_id,
            'student_id': student_id,
            'score': 0.0,
            'total_score': exam.total_score,
            'start_time': '进行中',
            'end_time': '-',
            'is_completed': False,
            'status': 'in_progress_preview'
        }
        
        return render_template('teacher/student_exam_details.html',
                             result=virtual_result,
                             student=student,
                             exam=exam,
                             questions=questions)
                             
    except Exception as e:
        print(f"[ERROR] 查看详情失败: {e}")
        import traceback
        traceback.print_exc()
        flash('无法加载答卷预览', 'error')
        return redirect(url_for('teacher.exam_submissions', exam_id=exam_id))

@teacher_bp.route('/result/<int:result_id>')
@login_required
def student_exam_details(result_id):
    """显示单个学生的详细答卷信息"""
    try:
        db = Database()
        
        # 获取考试结果
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM exam_results WHERE id = ?", (result_id,))
            result_row = cursor.fetchone()
            
            if not result_row:
                flash('考试结果不存在', 'error')
                return redirect(url_for('teacher.results'))
            
            # 将结果转换为字典
            result = dict(zip([c[0] for c in cursor.description], result_row))
        
        # 获取学生信息
        student = db.get_student_by_id(result['student_id'], by_internal_id=True)
        if not student:
            flash('学生信息不存在', 'error')
            return redirect(url_for('teacher.results'))
        
        # 获取考试信息
        exam = db.get_exam_by_id(result['exam_id'])
        
        # 获取所有题目和学生答案
        questions = db.get_student_question_details(student.id, exam.id)
        
        # 兜底逻辑：如果题目列表为空（说明未提交或数据未生成），尝试从恢复系统构建虚拟答卷
        if not questions:
            print(f"[EXAM_DETAILS] 标准详情为空，尝试构建虚拟答卷 - 学生: {student.name}, 考试: {exam.id}")
            try:
                from answer_preservation_system import recover_answers_safely
                recovery_result = recover_answers_safely(exam.id, student.id, student.student_id)
                recovered_answers = recovery_result.get('answers', {})
            except Exception as e:
                print(f"[ERROR] 恢复系统调用失败，尝试直接读取进度表: {e}")
                progress = db.get_exam_progress_by_student_number(exam.id, student.student_id)
                recovered_answers = {}
                if progress:
                    import json
                    answer_data = progress.get('answer_data') or progress.get('answers')
                    if answer_data:
                        if isinstance(answer_data, str):
                            try:
                                recovered_answers = json.loads(answer_data)
                            except: pass
                        else:
                            recovered_answers = answer_data
            
            if recovered_answers:
                print(f"[EXAM_DETAILS] 成功恢复 {len(recovered_answers)} 个答案，正在构建视图")
                
                # 2. 获取原始题目
                raw_questions = db.get_exam_questions(exam.id)
                
                # 3. 手动构建 details 结构
                questions = []
                for i, q in enumerate(raw_questions):
                    # 尝试匹配答案
                    question_key = f'question_{q.id}'
                    student_answer = ''
                    if question_key in recovered_answers:
                        student_answer = recovered_answers[question_key]
                    elif str(q.id) in recovered_answers:
                        student_answer = recovered_answers[str(q.id)]
                    elif q.id in recovered_answers:
                        student_answer = recovered_answers[q.id]
                    
                    student_answer = str(student_answer).strip()
                    
                    # 构建虚拟的 detail 对象 (字典格式，匹配 get_student_question_details 的返回)
                    opts = {}
                    if q.options and q.question_type == 'choice':
                        try:
                            import json
                            parsed = json.loads(q.options)
                            if isinstance(parsed, dict):
                                opts = parsed
                        except:
                            try:
                                parsed = eval(q.options)
                                if isinstance(parsed, dict):
                                    opts = parsed
                            except:
                                opts = {}
                    detail = {
                        'id': q.id,
                        'question_id': q.id,
                        'question_order': i + 1,
                        'question_text': q.question_text,
                        'question_type': q.question_type,
                        'score': 0.0,
                        'max_score': q.score or 0.0,
                        'student_answer': student_answer,
                        'correct_answer': q.correct_answer,
                        'is_correct': False,
                        'options': opts,
                        'grade_comment': '（未提交草稿预览）',
                        'is_manually_graded': False
                    }
                    questions.append(detail)
            else:
                print(f"[EXAM_DETAILS] 恢复失败或无答案数据")

        return render_template('teacher/student_exam_details.html',
                             result=result,
                             student=student,
                             exam=exam,
                             questions=questions)
                             
    except Exception as e:
        print(f"Student exam details error: {e}")
        import traceback
        traceback.print_exc()
        flash('加载学生答卷详情失败', 'error')
        return redirect(url_for('teacher.results'))

@teacher_bp.route('/result/<int:result_id>/export-markdown')
@login_required
def export_student_exam_markdown(result_id):
    """导出学生答卷详情为Markdown文档"""
    try:
        import io
        from datetime import datetime
        from flask import send_file
        
        db = Database()
        
        # 获取考试结果
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM exam_results WHERE id = ?", (result_id,))
            result_row = cursor.fetchone()
            
            if not result_row:
                flash('考试结果不存在', 'error')
                return redirect(url_for('teacher.results'))
            
            # 将结果转换为字典
            result = dict(zip([c[0] for c in cursor.description], result_row))
        
        # 获取学生信息
        student = db.get_student_by_id(result['student_id'], by_internal_id=True)
        if not student:
            flash('学生信息不存在', 'error')
            return redirect(url_for('teacher.results'))
        
        # 获取考试信息
        exam = db.get_exam_by_id(result['exam_id'])
        
        # 获取所有题目和学生答案
        questions = db.get_student_question_details(student.id, exam.id)
        
        # 生成Markdown内容
        markdown_content = generate_student_exam_markdown(result, student, exam, questions)
        
        # 创建文件流
        file_stream = io.BytesIO(markdown_content.encode('utf-8'))
        file_stream.seek(0)
        
        # 生成文件名
        filename = f"学生答卷详情_{student.name}_{exam.title}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        
        return send_file(
            file_stream,
            mimetype='text/markdown',
            as_attachment=True,
            download_name=filename
        )
        
    except Exception as e:
        print(f"Export student exam markdown error: {e}")
        import traceback
        traceback.print_exc()
        flash('导出Markdown文档失败', 'error')
        return redirect(url_for('teacher.results'))

def generate_student_exam_markdown(result, student, exam, questions):
    """生成学生答卷详情的Markdown内容"""
    # 题型映射
    type_names = {
        'choice': '选择题',
        'judge': '判断题',
        'essay': '论述题',
        'short_answer': '简答题',
        'fill_blank': '填空题',
        'code_reading': '代码阅读题',
        'code_practice': '编程题',
        'programming': '编程题'
    }
    
    # 开始构建Markdown内容
    md_lines = []
    
    # 标题
    md_lines.append(f"# 学生答卷详情 - {student.name}")
    md_lines.append("")
    
    # 考试和学生基本信息
    md_lines.append("## 基本信息")
    md_lines.append("")
    md_lines.append(f"- **考试名称**: {exam.title}")
    md_lines.append(f"- **学生姓名**: {student.name}")
    md_lines.append(f"- **学生学号**: {student.student_id}")
    md_lines.append(f"- **考试得分**: {result['score']} / {exam.total_score}")
    md_lines.append(f"- **开始时间**: {result['start_time']}")
    md_lines.append(f"- **完成时间**: {result['end_time']}")
    md_lines.append("")
    
    # 答题详情
    md_lines.append("## 答题详情")
    md_lines.append("")
    
    # 按题型分组
    question_groups = {}
    for question in questions:
        q_type = question['question_type']
        if q_type not in question_groups:
            question_groups[q_type] = []
        question_groups[q_type].append(question)
    
    # 遍历每个题型
    for q_type, q_list in question_groups.items():
        type_name = type_names.get(q_type, q_type)
        md_lines.append(f"### {type_name}")
        md_lines.append("")
        
        for i, question in enumerate(q_list, 1):
            md_lines.append(f"#### 题目 {question['question_order']}")
            md_lines.append("")
            md_lines.append(f"**题干**: {question['question_text']}")
            md_lines.append("")
            
            # 选项（如果是选择题）
            if q_type == 'choice' and question['options']:
                md_lines.append("**选项**:")
                for key, value in question['options'].items():
                    md_lines.append(f"- {key}: {value}")
                md_lines.append("")
            
            # 正确答案
            correct_answer = question['correct_answer']
            if q_type == 'judge':
                if correct_answer.lower() in ['true', 't', '1', '对']:
                    correct_answer = '对'
                elif correct_answer.lower() in ['false', 'f', '0', '错']:
                    correct_answer = '错'
            md_lines.append(f"**正确答案**: {correct_answer}")
            
            # 学生答案
            student_answer = question['student_answer'] or '未作答'
            if q_type == 'judge':
                if student_answer.lower() in ['true', 't', '1', '对']:
                    student_answer = '对'
                elif student_answer.lower() in ['false', 'f', '0', '错']:
                    student_answer = '错'
            md_lines.append(f"**学生答案**: {student_answer}")
            
            # 得分
            md_lines.append(f"**得分**: {question['score']} / {question['max_score']}")
            
            # 评语（如果有）
            if question['grade_comment']:
                md_lines.append(f"**评语**: {question['grade_comment']}")
            
            md_lines.append("")
    
    # 统计信息
    md_lines.append("## 统计信息")
    md_lines.append("")
    total_questions = len(questions)
    correct_count = sum(1 for q in questions if q['is_correct'])
    md_lines.append(f"- **总题数**: {total_questions}")
    md_lines.append(f"- **答对题数**: {correct_count}")
    md_lines.append(f"- **正确率**: {correct_count/total_questions*100:.1f}%" if total_questions > 0 else "- **正确率**: 0%")
    md_lines.append("")
    
    # 导出时间
    md_lines.append(f"导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    return '\n'.join(md_lines)

# 监控配置相关路由
@teacher_bp.route('/exams/<int:exam_id>/monitoring', methods=['GET', 'POST'])
@login_required
def exam_monitoring_config(exam_id):
    """考试监控配置"""
    try:
        db = Database()
        exam = db.get_exam_by_id(exam_id)
        
        if not exam:
            return jsonify({'success': False, 'message': '考试不存在'}), 404
        
        if request.method == 'GET':
            # 获取监控配置
            config = db.get_exam_monitoring_config(exam_id)
            return render_template('teacher/exam_monitoring_config.html', 
                                 exam=exam, config=config)
        
        elif request.method == 'POST':
            # 更新监控配置
            max_focus_warnings = int(request.form.get('max_focus_warnings', 9))
            auto_submit_on_exceed = request.form.get('auto_submit_on_exceed', 'false').lower() == 'true'
            warning_interval_seconds = int(request.form.get('warning_interval_seconds', 30))
            enable_focus_monitoring = request.form.get('enable_focus_monitoring', 'false').lower() == 'true'
            
            # 验证参数
            if max_focus_warnings < 1 or max_focus_warnings > 50:
                return jsonify({'success': False, 'message': '失焦警告次数必须在1-50之间'})
            
            if warning_interval_seconds < 5 or warning_interval_seconds > 300:
                return jsonify({'success': False, 'message': '警告间隔时间必须在5-300秒之间'})
            
            # 更新配置
            success = db.update_exam_monitoring_config(
                exam_id, max_focus_warnings, auto_submit_on_exceed, 
                warning_interval_seconds, enable_focus_monitoring
            )
            
            if success:
                return jsonify({'success': True, 'message': '监控配置已更新'})
            else:
                return jsonify({'success': False, 'message': '更新失败'})
                
    except Exception as e:
        print(f"监控配置错误: {e}")
        return jsonify({'success': False, 'message': f'操作失败: {str(e)}'})

@teacher_bp.route('/api/exam/<int:exam_id>/monitoring-config')
def get_monitoring_config_api(exam_id):
    """获取考试监控配置API"""
    try:
        db = Database()
        config = db.get_exam_monitoring_config(exam_id)
        
        return jsonify({
            'success': True,
            'config': config
        })
        
    except Exception as e:
        print(f"获取监控配置API错误: {e}")
        return jsonify({'success': False, 'message': f'获取失败: {str(e)}'})
