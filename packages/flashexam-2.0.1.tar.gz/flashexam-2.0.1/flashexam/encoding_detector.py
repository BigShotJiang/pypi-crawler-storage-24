#!/usr/bin/env python3
"""
🔍 智能编码检测模块
自动检测CSV文件编码，确保中文字符正确显示
支持UTF-8、GBK、GB2312、UTF-16等常见编码
"""

import chardet
import codecs
import pandas as pd
from typing import Tuple, List, Optional, Dict, Any
from io import StringIO, BytesIO
import csv
from dataclasses import dataclass

@dataclass
class EncodingDetectionResult:
    """编码检测结果"""
    encoding: str
    confidence: float
    success: bool
    error_message: str = ""
    detected_encodings: List[Dict[str, Any]] = None

class SmartEncodingDetector:
    """智能编码检测器"""
    
    # 常见的中文编码列表，按优先级排序
    COMMON_ENCODINGS = [
        'utf-8',
        'utf-8-sig',  # UTF-8 with BOM
        'gbk',
        'gb2312',
        'gb18030',
        'utf-16',
        'utf-16le',
        'utf-16be',
        'big5',
        'cp936',  # Windows简体中文
        'iso-8859-1',  # Latin-1
    ]
    
    def __init__(self):
        self.detection_cache = {}
    
    def detect_encoding(self, file_content: bytes, filename: str = "") -> EncodingDetectionResult:
        """
        智能检测文件编码
        
        Args:
            file_content: 文件字节内容
            filename: 文件名（可选，用于缓存）
        
        Returns:
            EncodingDetectionResult: 检测结果
        """
        # 检查缓存
        content_hash = hash(file_content)
        if content_hash in self.detection_cache:
            return self.detection_cache[content_hash]
        
        detected_encodings = []
        
        try:
            # 1. 使用chardet库检测
            chardet_result = chardet.detect(file_content)
            if chardet_result and chardet_result['encoding']:
                detected_encodings.append({
                    'encoding': chardet_result['encoding'],
                    'confidence': chardet_result['confidence'],
                    'method': 'chardet'
                })
            
            # 2. 尝试常见编码
            for encoding in self.COMMON_ENCODINGS:
                try:
                    decoded_content = file_content.decode(encoding)
                    # 检查是否包含乱码字符
                    if self._is_valid_chinese_content(decoded_content):
                        confidence = 0.9 if encoding in ['utf-8', 'utf-8-sig', 'gbk'] else 0.7
                        detected_encodings.append({
                            'encoding': encoding,
                            'confidence': confidence,
                            'method': 'manual_test'
                        })
                except UnicodeDecodeError:
                    continue
                except Exception:
                    continue
            
            # 3. 按置信度排序
            detected_encodings.sort(key=lambda x: x['confidence'], reverse=True)
            
            if detected_encodings:
                best_encoding = detected_encodings[0]
                result = EncodingDetectionResult(
                    encoding=best_encoding['encoding'],
                    confidence=best_encoding['confidence'],
                    success=True,
                    detected_encodings=detected_encodings
                )
            else:
                # 默认使用UTF-8
                result = EncodingDetectionResult(
                    encoding='utf-8',
                    confidence=0.5,
                    success=False,
                    error_message="无法确定编码，使用UTF-8作为默认编码"
                )
            
            # 缓存结果
            self.detection_cache[content_hash] = result
            return result
            
        except Exception as e:
            return EncodingDetectionResult(
                encoding='utf-8',
                confidence=0.0,
                success=False,
                error_message=f"编码检测失败: {str(e)}"
            )
    
    def _is_valid_chinese_content(self, content: str) -> bool:
        """检查内容是否包含有效的中文字符且没有明显乱码"""
        if not content:
            return False
        
        # 检查是否包含中文字符
        has_chinese = any('\u4e00' <= char <= '\u9fff' for char in content[:1000])
        
        # 检查乱码特征
        has_garbled = any(char in content for char in ['�', '锟', '斤拷'])
        
        # 检查常见CSV分隔符
        has_csv_structure = any(sep in content for sep in [',', '\t', ';'])
        
        return (has_chinese or has_csv_structure) and not has_garbled
    
    def read_csv_with_encoding_detection(self, file_content: bytes, filename: str = "") -> Tuple[pd.DataFrame, EncodingDetectionResult]:
        """
        使用编码检测读取CSV文件
        
        Args:
            file_content: 文件字节内容
            filename: 文件名
        
        Returns:
            Tuple[pd.DataFrame, EncodingDetectionResult]: CSV数据和检测结果
        """
        detection_result = self.detect_encoding(file_content, filename)
        
        try:
            # 尝试使用检测到的编码读取CSV
            text_content = file_content.decode(detection_result.encoding)
            
            # 处理BOM
            if text_content.startswith('\ufeff'):
                text_content = text_content[1:]
            
            # 使用StringIO读取CSV
            csv_buffer = StringIO(text_content)
            df = pd.read_csv(csv_buffer)
            
            # 验证读取结果
            if df.empty:
                raise ValueError("CSV文件为空")
            
            # 检查列名是否正常
            if df.columns.tolist() == [f'Unnamed: {i}' for i in range(len(df.columns))]:
                # 可能是分隔符问题，尝试其他分隔符
                for sep in [';', '\t', '|']:
                    try:
                        csv_buffer = StringIO(text_content)
                        df_test = pd.read_csv(csv_buffer, sep=sep)
                        if len(df_test.columns) > len(df.columns):
                            df = df_test
                            break
                    except:
                        continue
            
            return df, detection_result
            
        except Exception as e:
            # 如果主要编码失败，尝试其他编码
            for encoding_info in detection_result.detected_encodings or []:
                try:
                    text_content = file_content.decode(encoding_info['encoding'])
                    if text_content.startswith('\ufeff'):
                        text_content = text_content[1:]
                    
                    csv_buffer = StringIO(text_content)
                    df = pd.read_csv(csv_buffer)
                    
                    if not df.empty:
                        detection_result.encoding = encoding_info['encoding']
                        detection_result.confidence = encoding_info['confidence']
                        return df, detection_result
                except:
                    continue
            
            # 所有编码都失败，抛出异常
            detection_result.success = False
            detection_result.error_message = f"使用编码 {detection_result.encoding} 读取CSV失败: {str(e)}"
            raise ValueError(detection_result.error_message)

def create_encoding_test_files():
    """创建不同编码的测试文件（用于测试）"""
    import os
    
    # 测试数据
    test_data = """student_id,name,password,college,major,class_name,gender,notes
2024001,张三,123456,计算机学院,软件工程,软工2024-1班,男,优秀学生
2024002,李四,2024002,信息学院,计算机科学,计科2024-1班,女,学习委员
2024003,王五,password,网络安全学院,信息安全,网安2024-1班,男,班长
2024004,赵六,666666,数据科学学院,数据科学与大数据技术,数据2024-1班,女,体育委员"""

    encodings_to_test = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig']
    
    for encoding in encodings_to_test:
        try:
            filename = f"test_students_{encoding.replace('-', '_')}.csv"
            with open(filename, 'w', encoding=encoding, newline='') as f:
                f.write(test_data)
            print(f"✅ 创建测试文件: {filename} ({encoding})")
        except Exception as e:
            print(f"❌ 创建 {encoding} 测试文件失败: {e}")

def test_encoding_detection():
    """测试编码检测功能"""
    print("\n" + "="*60)
    print("🔍 智能编码检测测试")
    print("="*60)
    
    detector = SmartEncodingDetector()
    
    # 创建测试文件
    print("📄 创建测试文件...")
    create_encoding_test_files()
    
    # 测试不同编码的文件
    test_files = [
        'test_students_utf_8.csv',
        'test_students_gbk.csv', 
        'test_students_gb2312.csv',
        'test_students_utf_8_sig.csv'
    ]
    
    for filename in test_files:
        try:
            print(f"\n🧪 测试文件: {filename}")
            
            with open(filename, 'rb') as f:
                file_content = f.read()
            
            # 检测编码
            detection_result = detector.detect_encoding(file_content, filename)
            print(f"  检测编码: {detection_result.encoding}")
            print(f"  置信度: {detection_result.confidence:.2f}")
            print(f"  状态: {'✅ 成功' if detection_result.success else '❌ 失败'}")
            
            if detection_result.error_message:
                print(f"  错误: {detection_result.error_message}")
            
            # 尝试读取CSV
            try:
                df, _ = detector.read_csv_with_encoding_detection(file_content, filename)
                print(f"  CSV读取: ✅ 成功 ({len(df)} 行)")
                print(f"  列名: {list(df.columns)}")
                print(f"  示例数据: {df.iloc[0]['name'] if 'name' in df.columns else 'N/A'}")
            except Exception as e:
                print(f"  CSV读取: ❌ 失败 - {e}")
        
        except FileNotFoundError:
            print(f"  ⚠️ 文件不存在: {filename}")
        except Exception as e:
            print(f"  ❌ 测试失败: {e}")
    
    # 清理测试文件
    print(f"\n🧹 清理测试文件...")
    for filename in test_files:
        try:
            import os
            if os.path.exists(filename):
                os.remove(filename)
                print(f"  ✅ 删除: {filename}")
        except:
            pass
    
    print("\n" + "="*60)
    print("🎉 编码检测测试完成")
    print("="*60)

if __name__ == "__main__":
    test_encoding_detection() 