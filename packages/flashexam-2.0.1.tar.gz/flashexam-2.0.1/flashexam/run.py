#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FlashExam 主启动脚本
"""

import os
import sys

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

# 添加flask_app目录到Python路径，以支持相对导入
flask_app_path = os.path.join(project_root, 'flask_app')
sys.path.insert(0, flask_app_path)

def main():
    """主函数"""
    print("🚀 FlashExam 在线考试系统启动中...")
    print(f"📁 项目路径: {project_root}")
    
    try:
        # 设置环境变量，确保Flask能找到应用
        os.environ['FLASK_APP'] = 'flask_app'
        
        # 导入必要模块
        import database
        import models
        import utils
        
        # 初始化数据库（Database类在初始化时会自动调用init_database）
        print("🔄 初始化数据库...")
        db = database.Database()
        print("✅ 数据库初始化完成")
        
        # 导入Flask应用
        sys.path.append(os.path.join(project_root, 'flask_app'))
        from flask_app import create_app
        
        # 创建Flask应用实例
        app = create_app()
        
        print("✅ 系统初始化完成")
        print("📍 访问地址:")
        print("   🌐 主页: http://localhost:5000")
        print("   👨‍🏫 教师端: http://localhost:5000/teacher")
        print("   👨‍🎓 学生端: http://localhost:5000/student")
        print("🔑 默认教师账户: admin / admin123")
        print("📚 详细说明请查看 README.md")
        print("-" * 50)
        
        # 启动Flask应用
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=False,
            threaded=True
        )
        
    except ImportError as e:
        print(f"❌ 导入错误: {e}")
        print("💡 请确保已安装所有依赖: pip install -r requirements.txt")
        print("💡 如果问题持续，请检查项目文件完整性")
        sys.exit(1)
        
    except Exception as e:
        print(f"❌ 启动失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main() 