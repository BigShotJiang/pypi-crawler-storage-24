import pandas as pd
import json
from typing import List, Dict, Any, Tuple
from io import BytesIO
import csv
from io import StringIO
import hashlib
import secrets
from datetime import datetime, timedelta

from .models import Question, Student, QuestionScore
from .encoding_detector import SmartEncodingDetector, EncodingDetectionResult

# 全局编码检测器实例
_encoding_detector = SmartEncodingDetector()

# 导入改进的评分系统
try:
    from improved_grading_system import improved_calculate_score_detailed, get_improved_grader
    IMPROVED_GRADING_AVAILABLE = True
    print("✅ 改进评分系统加载成功")
except ImportError as e:
    IMPROVED_GRADING_AVAILABLE = False
    print(f"⚠️ 改进评分系统未找到: {e}")

def parse_csv_questions(file_content: bytes, file_name: str) -> List[Question]:
    """解析CSV文件中的题目 - 支持智能编码检测和多格式兼容"""
    try:
        # 使用智能编码检测读取CSV
        df, detection_result = _encoding_detector.read_csv_with_encoding_detection(file_content, file_name)
        
        # 记录编码检测信息
        if detection_result.success:
            print(f"+ 题目CSV智能编码检测: {detection_result.encoding} (置信度: {detection_result.confidence:.2f})")
        else:
            print(f"- 题目CSV编码检测警告: {detection_result.error_message}")
        
        # 智能识别CSV格式
        csv_format = detect_csv_format(df)
        print(f"+ 检测到CSV格式: {csv_format['format_name']}")
        
        # 根据格式解析题目
        if csv_format['format_type'] == 'standard':
            return parse_standard_format(df)
        elif csv_format['format_type'] == 'chinese':
            return parse_chinese_format(df)
        elif csv_format['format_type'] == 'flexible':
            return parse_flexible_format(df, csv_format)
        else:
            raise ValueError(f"不支持的CSV格式: {csv_format['format_name']}")
        
    except Exception as e:
        # 回退到传统方法
        print(f"- 智能格式检测失败，使用传统方法: {str(e)}")
        try:
            # 将字节数据转换为BytesIO对象，供pandas读取
            csv_buffer = BytesIO(file_content)
            df = pd.read_csv(csv_buffer)
            
            # 尝试标准格式
            return parse_standard_format(df)
            
        except Exception as fallback_error:
            raise ValueError(f"解析CSV文件失败: {str(fallback_error)}")

def detect_csv_format(df: pd.DataFrame) -> Dict[str, Any]:
    """智能检测CSV格式类型"""
    columns = [col.strip() for col in df.columns]
    
    # 格式1: 标准英文格式
    standard_columns = ['question_type', 'question_text', 'correct_answer']
    if all(col in columns for col in standard_columns):
        return {
            'format_type': 'standard',
            'format_name': '标准英文格式',
            'confidence': 1.0
        }
    
    # 格式2: 中文格式 (用户提供的格式)
    chinese_columns = ['章节', '题目', '正确答案']
    if all(col in columns for col in chinese_columns):
        return {
            'format_type': 'chinese',
            'format_name': '中文格式',
            'confidence': 1.0
        }
    
    # 格式3: 灵活匹配格式
    flexible_mapping = detect_flexible_columns(columns)
    if flexible_mapping['question_text'] and flexible_mapping['correct_answer']:
        return {
            'format_type': 'flexible',
            'format_name': '自适应格式',
            'confidence': 0.8,
            'column_mapping': flexible_mapping
        }
    
    return {
        'format_type': 'unknown',
        'format_name': '未知格式',
        'confidence': 0.0
    }

def detect_flexible_columns(columns: List[str]) -> Dict[str, str]:
    """检测灵活的列名映射"""
    mapping = {
        'question_text': None,
        'correct_answer': None,
        'subject': None,
        'difficulty': None,
        'options': {}
    }
    
    # 题目内容列的可能名称
    question_keywords = ['题目', 'question', 'text', '内容', '问题', 'title']
    # 正确答案列的可能名称
    answer_keywords = ['正确答案', 'answer', 'correct', '答案', 'key']
    # 科目/章节列的可能名称
    subject_keywords = ['章节', 'subject', '科目', '分类', 'category', 'chapter']
    # 难度列的可能名称
    difficulty_keywords = ['难度', 'difficulty', '级别', 'level']
    
    for col in columns:
        col_lower = col.lower()
        
        # 匹配题目内容
        if not mapping['question_text']:
            for keyword in question_keywords:
                if keyword in col_lower or keyword in col:
                    mapping['question_text'] = col
                    break
        
        # 匹配正确答案
        if not mapping['correct_answer']:
            for keyword in answer_keywords:
                if keyword in col_lower or keyword in col:
                    mapping['correct_answer'] = col
                    break
        
        # 匹配科目/章节
        if not mapping['subject']:
            for keyword in subject_keywords:
                if keyword in col_lower or keyword in col:
                    mapping['subject'] = col
                    break
        
        # 匹配难度
        if not mapping['difficulty']:
            for keyword in difficulty_keywords:
                if keyword in col_lower or keyword in col:
                    mapping['difficulty'] = col
                    break
        
        # 匹配选项 (A, B, C, D等)
        if '选项' in col or 'option' in col_lower:
            # 提取选项标识 (A, B, C, D)
            for char in ['A', 'B', 'C', 'D', 'E', 'F']:
                if char in col.upper():
                    mapping['options'][char] = col
                    break
    
    return mapping

def parse_standard_format(df: pd.DataFrame) -> List[Question]:
    """解析标准英文格式"""
    print(f"DEBUG_UTILS: Entering parse_standard_format. df.columns: {list(df.columns)}") # DEBUG
    # 检查必要的列
    required_columns = ['question_type', 'question_text', 'correct_answer']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"CSV文件缺少必要的列: {col}")
    
    questions = []
    for index, row in df.iterrows():
        try:
            question_type = str(row['question_type']).strip().lower()
            question_text = str(row['question_text']).strip()
            correct_answer = str(row['correct_answer']).strip()
            
            # 宽松的类型匹配逻辑：先归一化
            if 'choice' in question_type:
                question_type = 'choice'
            elif 'judge' in question_type:
                question_type = 'judge'
            
            # 验证题目类型
            valid_types = [
                # 基础题型
                'choice', 'judge', 'essay', 'short_answer', 'fill_blank',
                # 编程题型
                'code_reading', 'code_practice', 'programming',
                # 英语阅读理解
                'reading_comprehension', 'reading_multiple_choice', 'reading_true_false',
                'reading_fill_blank', 'reading_matching', 'reading_summary', 'reading_passage_multiple',
                # 英语完型填空
                'cloze_test', 'cloze_multiple_choice', 'cloze_word_bank', 'cloze_grammar',
                # 英语听力理解
                'listening_comprehension', 'listening_multiple_choice', 'listening_fill_blank',
                'listening_matching', 'listening_note_taking', 'listening_summary',
                # 英语口语表达
                'speaking_independent', 'speaking_integrated', 'speaking_description',
                'speaking_opinion', 'speaking_conversation', 'speaking_presentation',
                # 英语写作表达
                'writing_essay', 'writing_integrated', 'writing_independent',
                'writing_summary', 'writing_letter', 'writing_report',
                # 英语语法词汇
                'grammar_choice', 'vocabulary_choice', 'vocabulary_fill',
                'phrase_matching', 'sentence_correction', 'word_formation',
                # 英语翻译
                'translation_en_to_cn', 'translation_cn_to_en', 'translation_sentence', 'translation_paragraph',
                # 托福专项
                'toefl_integrated',
                # 雅思专项
                'ielts_task1', 'ielts_task2', 'ielts_speaking_part1', 'ielts_speaking_part2', 'ielts_speaking_part3',
                # GRE专项
                'gre_reading', 'gre_verbal',
                # 考研专项
                'postgraduate_reading', 'postgraduate_cloze', 'postgraduate_translation', 'postgraduate_writing'
            ]
            if question_type not in valid_types:
                raise ValueError(f"第{index+2}行: 不支持的题目类型 '{question_type}'，支持的类型: {', '.join(valid_types)}")
            
            # 处理选择题选项
            options = ""
            if question_type == 'choice':
                options_dict = {}
                for option_key in ['A', 'B', 'C', 'D', 'E', 'F']:
                    option_col_in_csv = f'option_{option_key}'
                    if option_col_in_csv in df.columns and pd.notna(row[option_col_in_csv]):
                        options_dict[option_key] = str(row[option_col_in_csv]).strip()
                
                print(f"DEBUG_UTILS: Choice Q (row index {index}): options_dict before json.dumps: {options_dict}") # DEBUG
                
                if options_dict:
                    options = json.dumps(options_dict, ensure_ascii=False)
                else:
                    # 如果没有标准选项列，尝试从options列读取
                    if 'options' in df.columns and pd.notna(row['options']):
                        options = str(row['options']).strip()
                print(f"DEBUG_UTILS: Choice Q (row index {index}): final 'options' string for Question: '{options}'") # DEBUG
            
            # 其他字段
            difficulty = str(row.get('difficulty', 'medium')).strip()
            subject = str(row.get('subject', '')).strip()
            
            question = Question(
                question_type=question_type,
                question_text=question_text,
                options=options,
                correct_answer=correct_answer,
                difficulty=difficulty,
                subject=subject
            )
            
            questions.append(question)
            
        except Exception as e:
            raise ValueError(f"第{index+2}行解析错误: {str(e)}")
    
    return questions

def parse_chinese_format(df: pd.DataFrame) -> List[Question]:
    """解析中文格式 (章节,题目,选项A,选项B,选项C,选项D,正确答案,难度)"""
    # 检查必要的列
    required_columns = ['题目', '正确答案']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"CSV文件缺少必要的列: {col}")
    
    questions = []
    for index, row in df.iterrows():
        try:
            # 基本信息
            question_text = str(row['题目']).strip()
            correct_answer = str(row['正确答案']).strip()
            
            if not question_text or not correct_answer:
                raise ValueError(f"题目内容或正确答案不能为空")
            
            # 检查是否有选项列，如果有就是选择题
            option_columns = ['选项A', '选项B', '选项C', '选项D']
            has_options = any(col in df.columns and pd.notna(row.get(col)) for col in option_columns)
            
            if has_options:
                # 选择题
                question_type = 'choice'
                options_dict = {}
                
                for i, option_col in enumerate(option_columns):
                    if option_col in df.columns and pd.notna(row[option_col]):
                        option_key = chr(65 + i)  # A, B, C, D
                        options_dict[option_key] = str(row[option_col]).strip()
                
                options = json.dumps(options_dict, ensure_ascii=False) if options_dict else ""
                
                # 验证正确答案是否是有效选项
                if correct_answer.upper() not in options_dict.keys():
                    # 如果正确答案不是选项字母，尝试匹配选项内容
                    for key, value in options_dict.items():
                        if correct_answer in value or value in correct_answer:
                            correct_answer = key
                            break
                    else:
                        # 如果仍然匹配不到，保持原值但给出警告
                        print(f"警告: 第{index+2}行正确答案 '{correct_answer}' 可能与选项不匹配")
            
            else:
                # 没有选项列，判断是判断题还是简答题
                if correct_answer.lower() in ['true', 'false', '是', '否', '对', '错', '正确', '错误']:
                    question_type = 'judge'
                    # 标准化判断题答案
                    if correct_answer in ['是', '对', '正确', 'true']:
                        correct_answer = 'True'
                    elif correct_answer in ['否', '错', '错误', 'false']:
                        correct_answer = 'False'
                else:
                    question_type = 'essay'
                
                options = ""
            
            # 其他字段
            subject = str(row.get('章节', '')).strip()
            
            # 处理难度字段
            difficulty_raw = str(row.get('难度', '适当')).strip()
            difficulty_mapping = {
                '容易': 'easy',
                '简单': 'easy', 
                '适当': 'medium',
                '中等': 'medium',
                '困难': 'hard',
                '难': 'hard'
            }
            difficulty = difficulty_mapping.get(difficulty_raw, 'medium')
            
            question = Question(
                question_type=question_type,
                question_text=question_text,
                options=options,
                correct_answer=correct_answer,
                difficulty=difficulty,
                subject=subject
            )
            
            questions.append(question)
            
        except Exception as e:
            raise ValueError(f"第{index+2}行解析错误: {str(e)}")
    
    return questions

def parse_flexible_format(df: pd.DataFrame, csv_format: Dict[str, Any]) -> List[Question]:
    """解析灵活格式，根据检测到的列映射"""
    column_mapping = csv_format['column_mapping']
    
    # 检查必要的映射
    if not column_mapping['question_text']:
        raise ValueError("无法找到题目内容列")
    if not column_mapping['correct_answer']:
        raise ValueError("无法找到正确答案列")
    
    questions = []
    for index, row in df.iterrows():
        try:
            # 基本信息
            question_text = str(row[column_mapping['question_text']]).strip()
            correct_answer = str(row[column_mapping['correct_answer']]).strip()
            
            if not question_text or not correct_answer:
                raise ValueError(f"题目内容或正确答案不能为空")
            
            # 检查选项
            has_options = bool(column_mapping['options'])
            
            if has_options:
                # 选择题
                question_type = 'choice'
                options_dict = {}
                
                for option_key, option_col in column_mapping['options'].items():
                    if pd.notna(row.get(option_col)):
                        options_dict[option_key] = str(row[option_col]).strip()
                
                options = json.dumps(options_dict, ensure_ascii=False) if options_dict else ""
            
            else:
                # 判断题目类型
                if correct_answer.lower() in ['true', 'false', '是', '否', '对', '错', '正确', '错误']:
                    question_type = 'judge'
                    # 标准化判断题答案
                    if correct_answer in ['是', '对', '正确', 'true']:
                        correct_answer = 'True'
                    elif correct_answer in ['否', '错', '错误', 'false']:
                        correct_answer = 'False'
                else:
                    question_type = 'essay'
                
                options = ""
            
            # 其他字段
            subject = ""
            if column_mapping['subject']:
                subject = str(row.get(column_mapping['subject'], '')).strip()
            
            difficulty = "medium"
            if column_mapping['difficulty']:
                difficulty_raw = str(row.get(column_mapping['difficulty'], '')).strip()
                # 处理中文难度
                difficulty_mapping = {
                    '容易': 'easy', '简单': 'easy', 
                    '适当': 'medium', '中等': 'medium',
                    '困难': 'hard', '难': 'hard'
                }
                difficulty = difficulty_mapping.get(difficulty_raw, difficulty_raw or 'medium')
            
            question = Question(
                question_type=question_type,
                question_text=question_text,
                options=options,
                correct_answer=correct_answer,
                difficulty=difficulty,
                subject=subject
            )
            
            questions.append(question)
            
        except Exception as e:
            raise ValueError(f"第{index+2}行解析错误: {str(e)}")
    
    return questions

def parse_csv_students(file_content, file_name: str) -> Tuple[List[Student], List[str]]:
    """解析学生CSV文件 - 支持智能编码检测"""
    students = []
    errors = []
    
    try:
        # 处理文件内容，支持智能编码检测
        if isinstance(file_content, bytes):
            # 使用智能编码检测
            try:
                df, detection_result = _encoding_detector.read_csv_with_encoding_detection(file_content, file_name)
                
                # 记录编码检测信息
                if detection_result.success:
                    print(f"+ 智能编码检测: {detection_result.encoding} (置信度: {detection_result.confidence:.2f})")
                else:
                    print(f"- 编码检测警告: {detection_result.error_message}")
                
                # 转换为字符串格式用于后续处理
                content = df.to_csv(index=False)
                
            except Exception as e:
                errors.append(f"智能编码检测失败: {str(e)}")
                # 回退到传统方法
                try:
                    content = file_content.decode('utf-8-sig')
                except UnicodeDecodeError:
                    try:
                        content = file_content.decode('gbk')
                    except UnicodeDecodeError:
                        content = file_content.decode('utf-8', errors='ignore')
                        errors.append("字符编码检测失败，可能存在乱码")
        
        elif isinstance(file_content, str):
            content = file_content
        else:
            # 文件对象
            file_bytes = file_content.read()
            if isinstance(file_bytes, bytes):
                try:
                    df, detection_result = _encoding_detector.read_csv_with_encoding_detection(file_bytes, file_name)
                    
                    if detection_result.success:
                        print(f"+ 智能编码检测: {detection_result.encoding} (置信度: {detection_result.confidence:.2f})")
                    else:
                        print(f"- 编码检测警告: {detection_result.error_message}")
                    
                    content = df.to_csv(index=False)
                except Exception as e:
                    errors.append(f"智能编码检测失败: {str(e)}")
                    content = file_bytes.decode('utf-8-sig', errors='ignore')
            else:
                content = file_bytes
        
        # 解析CSV
        csv_reader = csv.DictReader(StringIO(content))
        
        # 检查必需的列
        required_columns = ['student_id', 'name']
        optional_columns = ['password', 'college', 'major', 'class_name', 'gender', 'notes']
        
        if not all(col in csv_reader.fieldnames for col in required_columns):
            missing = [col for col in required_columns if col not in csv_reader.fieldnames]
            errors.append(f"缺少必需的列: {', '.join(missing)}")
            return students, errors
        
        for row_num, row in enumerate(csv_reader, start=2):
            try:
                # 检查必填字段
                student_id = row.get('student_id', '').strip()
                name = row.get('name', '').strip()
                
                if not student_id:
                    errors.append(f"第{row_num}行: 学号不能为空")
                    continue
                
                if not name:
                    errors.append(f"第{row_num}行: 姓名不能为空")
                    continue
                
                # 获取可选字段
                password = row.get('password', '').strip()
                if not password:
                    password = student_id  # 默认密码为学号
                
                college = row.get('college', '').strip()
                major = row.get('major', '').strip()
                class_name = row.get('class_name', '').strip()
                gender = row.get('gender', '').strip()
                notes = row.get('notes', '').strip()
                
                # 创建学生对象
                student = Student(
                    student_id=student_id,
                    name=name,
                    password=password,
                    college=college,
                    major=major,
                    class_name=class_name,
                    gender=gender,
                    notes=notes
                )
                
                students.append(student)
                
            except Exception as e:
                errors.append(f"第{row_num}行解析错误: {str(e)}")
        
        return students, errors
        
    except Exception as e:
        errors.append(f"解析学生CSV文件失败: {str(e)}")
        return students, errors

def parse_csv_students_with_encoding_info(file_content, file_name: str) -> Tuple[List[Student], List[str], EncodingDetectionResult]:
    """解析学生CSV文件并返回编码检测信息"""
    students = []
    errors = []
    detection_result = None
    
    try:
        if isinstance(file_content, bytes):
            # 使用智能编码检测
            df, detection_result = _encoding_detector.read_csv_with_encoding_detection(file_content, file_name)
            
            # 验证CSV格式
            validation_errors = validate_students_csv_format(df)
            errors.extend(validation_errors)
            
            # 如果没有严重错误，解析学生数据
            serious_errors = [e for e in errors if not e.startswith("建议添加的列")]
            if not serious_errors:
                for index, row in df.iterrows():
                    try:
                        student_id = str(row.get('student_id', '')).strip()
                        name = str(row.get('name', '')).strip()
                        
                        if not student_id or not name:
                            errors.append(f"第{index+2}行: 学号或姓名不能为空")
                            continue
                        
                        password = str(row.get('password', '')).strip()
                        if not password:
                            password = student_id
                        
                        student = Student(
                            student_id=student_id,
                            name=name,
                            password=password,
                            college=str(row.get('college', '')).strip(),
                            major=str(row.get('major', '')).strip(),
                            class_name=str(row.get('class_name', '')).strip(),
                            gender=str(row.get('gender', '')).strip(),
                            notes=str(row.get('notes', '')).strip()
                        )
                        
                        students.append(student)
                        
                    except Exception as e:
                        errors.append(f"第{index+2}行解析错误: {str(e)}")
            
            return students, errors, detection_result
        
        else:
            # 回退到原来的方法
            students, errors = parse_csv_students(file_content, file_name)
            detection_result = EncodingDetectionResult(
                encoding='utf-8',
                confidence=1.0,
                success=True,
                error_message=""
            )
            return students, errors, detection_result
            
    except Exception as e:
        errors.append(f"解析CSV文件失败: {str(e)}")
        if detection_result is None:
            detection_result = EncodingDetectionResult(
                encoding='unknown',
                confidence=0.0,
                success=False,
                error_message=str(e)
            )
        return students, errors, detection_result

def calculate_score_detailed(questions: List[Question], answers: Dict[str, str], exam_result_id: int = 0) -> Tuple[float, List[QuestionScore]]:
    """计算考试得分并返回详细的题目得分信息 - 使用改进的评分系统"""
    
    if IMPROVED_GRADING_AVAILABLE:
        # 使用改进的评分系统
        try:
            return improved_calculate_score_detailed(questions, answers, exam_result_id)
        except Exception as e:
            print(f"改进评分系统失败，回退到传统方法: {e}")
    
    # 回退到传统评分方法
    return _legacy_calculate_score_detailed(questions, answers, exam_result_id)

def _legacy_calculate_score_detailed(questions: List[Question], answers: Dict[str, str], exam_result_id: int = 0) -> Tuple[float, List[QuestionScore]]:
    """传统的计算考试得分方法（作为回退方案）"""
    if not questions:
        return 0.0, []
    
    total_questions = len(questions)
    correct_count = 0
    question_scores = []
    
    # 每题的满分（平均分配）
    max_score_per_question = 100.0 / total_questions
    
    for i, question in enumerate(questions):
        question_key = f"question_{i}"
        user_answer = answers.get(question_key, "").strip()
        correct_answer = question.correct_answer.strip()
        
        is_correct = False
        score = 0.0
        
        if question.question_type == 'choice' or 'choice' in question.question_type:
            # 选择题：完全匹配
            if user_answer.upper() == correct_answer.upper():
                is_correct = True
                score = max_score_per_question
                correct_count += 1
        elif question.question_type == 'judge' or 'judge' in question.question_type:
            # 判断题：完全匹配
            if user_answer.lower() == correct_answer.lower():
                is_correct = True
                score = max_score_per_question
                correct_count += 1
        elif question.question_type in ['essay', 'code_reading', 'code_practice', 'short_answer', 'fill_blank', 'programming',
                                        # 英语阅读理解
                                        'reading_comprehension', 'reading_multiple_choice', 'reading_true_false',
                                        'reading_fill_blank', 'reading_matching', 'reading_summary', 'reading_passage_multiple',
                                        # 英语完型填空
                                        'cloze_test', 'cloze_multiple_choice', 'cloze_word_bank', 'cloze_grammar',
                                        # 英语听力理解
                                        'listening_comprehension', 'listening_multiple_choice', 'listening_fill_blank',
                                        'listening_matching', 'listening_note_taking', 'listening_summary',
                                        # 英语口语表达
                                        'speaking_independent', 'speaking_integrated', 'speaking_description',
                                        'speaking_opinion', 'speaking_conversation', 'speaking_presentation',
                                        # 英语写作表达
                                        'writing_essay', 'writing_integrated', 'writing_independent',
                                        'writing_summary', 'writing_letter', 'writing_report',
                                        # 英语语法词汇
                                        'grammar_choice', 'vocabulary_choice', 'vocabulary_fill',
                                        'phrase_matching', 'sentence_correction', 'word_formation',
                                        # 英语翻译
                                        'translation_en_to_cn', 'translation_cn_to_en', 'translation_sentence', 'translation_paragraph',
                                        # 托福专项
                                        'toefl_integrated',
                                        # 雅思专项
                                        'ielts_task1', 'ielts_task2', 'ielts_speaking_part1', 'ielts_speaking_part2', 'ielts_speaking_part3',
                                        # GRE专项
                                        'gre_reading', 'gre_verbal',
                                        # 考研专项
                                        'postgraduate_reading', 'postgraduate_cloze', 'postgraduate_translation', 'postgraduate_writing']:
            # 简答题及所有新类型题目：包含关键词即可（简单实现）
            # 将答案和用户答案都转为小写并去除空格进行比较
            correct_clean = correct_answer.lower().strip()
            user_clean = user_answer.lower().strip()
            
            # 如果用户答案包含正确答案，或者正确答案包含用户答案（考虑部分匹配）
            if (correct_clean in user_clean) or (user_clean in correct_clean and len(user_clean) > 10):
                is_correct = True
                score = max_score_per_question
                correct_count += 1
            # 如果用户答案长度合理且有一定重叠，给部分分数
            elif len(user_clean) > 5:
                # 计算简单的相似度（共同字符数/总字符数）
                common_chars = sum(1 for c in user_clean if c in correct_clean)
                similarity = common_chars / max(len(user_clean), len(correct_clean))
                if similarity > 0.3:  # 30%相似度即可得分
                    is_correct = True
                    score = max_score_per_question * similarity
                    correct_count += similarity
        
        # 创建题目得分记录
        question_score = QuestionScore(
            exam_result_id=exam_result_id,
            question_id=question.id or 0,
            question_order=i,
            student_answer=user_answer,
            correct_answer=correct_answer,
            is_correct=is_correct,
            score=score,
            max_score=max_score_per_question,
            question_type=question.question_type,
            question_text=question.question_text
        )
        question_scores.append(question_score)
    
    total_score = (correct_count / total_questions) * 100
    return total_score, question_scores

def calculate_score(questions: List[Question], answers: Dict[str, str]) -> float:
    """计算考试得分（保持向后兼容）"""
    total_score, _ = calculate_score_detailed(questions, answers)
    return total_score

def format_question_display(question: Question, question_index: int) -> str:
    """格式化题目显示"""
    display_text = f"**第 {question_index + 1} 题** ({get_question_type_name(question.question_type)})\n\n"
    display_text += f"{question.question_text}\n\n"
    
    if question.question_type == 'choice' and question.options:
        try:
            options = json.loads(question.options)
            for key, value in options.items():
                display_text += f"{key}. {value}\n"
        except:
            pass
    
    return display_text

def get_question_type_name(question_type: str) -> str:
    """获取题目类型中文名称"""
    type_names = {
        # 基础题型
        "choice": "选择题",
        "judge": "判断题",
        "essay": "简答题",
        "short_answer": "问答题",
        "fill_blank": "填空题",
        
        # 编程题型
        "code_reading": "代码阅读题",
        "code_practice": "代码实践题",
        "programming": "编程题",
        
        # 英语阅读理解
        "reading_comprehension": "英语阅读理解",
        "reading_multiple_choice": "阅读选择题",
        "reading_true_false": "阅读判断题",
        "reading_fill_blank": "阅读填空题",
        "reading_matching": "阅读匹配题",
        "reading_summary": "阅读概括题",
        "reading_passage_multiple": "阅读文章多题组",
        
        # 英语完型填空
        "cloze_test": "完型填空",
        "cloze_multiple_choice": "完型选择题",
        "cloze_word_bank": "完型词库题",
        "cloze_grammar": "语法填空",
        
        # 英语听力理解
        "listening_comprehension": "听力理解",
        "listening_multiple_choice": "听力选择题",
        "listening_fill_blank": "听力填空题",
        "listening_matching": "听力匹配题",
        "listening_note_taking": "听力笔记题",
        "listening_summary": "听力概括题",
        
        # 英语口语表达
        "speaking_independent": "口语独立题",
        "speaking_integrated": "口语综合题",
        "speaking_description": "口语描述题",
        "speaking_opinion": "口语观点题",
        "speaking_conversation": "口语对话题",
        "speaking_presentation": "口语展示题",
        
        # 英语写作表达
        "writing_essay": "写作题",
        "writing_integrated": "写作综合题",
        "writing_independent": "写作独立题",
        "writing_summary": "写作摘要题",
        "writing_letter": "写作书信题",
        "writing_report": "写作报告题",
        
        # 英语语法词汇
        "grammar_choice": "语法选择题",
        "vocabulary_choice": "词汇选择题",
        "vocabulary_fill": "词汇填空题",
        "phrase_matching": "短语匹配题",
        "sentence_correction": "句子改错题",
        "word_formation": "词汇变形题",
        
        # 英语翻译
        "translation_en_to_cn": "英译汉",
        "translation_cn_to_en": "汉译英",
        "translation_sentence": "句子翻译",
        "translation_paragraph": "段落翻译",
        
        # 托福专项
        "toefl_integrated": "托福综合题",
        
        # 雅思专项
        "ielts_task1": "雅思小作文",
        "ielts_task2": "雅思大作文",
        "ielts_speaking_part1": "雅思口语Part1",
        "ielts_speaking_part2": "雅思口语Part2",
        "ielts_speaking_part3": "雅思口语Part3",
        
        # GRE专项
        "gre_reading": "GRE阅读",
        "gre_verbal": "GRE语文",
        
        # 考研专项
        "postgraduate_reading": "考研英语阅读",
        "postgraduate_cloze": "考研英语完型",
        "postgraduate_translation": "考研英语翻译",
        "postgraduate_writing": "考研英语写作"
    }
    return type_names.get(question_type, f'{question_type}(未知类型)')

def validate_csv_format(df: pd.DataFrame) -> List[str]:
    """验证CSV格式 - 支持多种格式"""
    errors = []
    
    # 智能检测格式
    csv_format = detect_csv_format(df)
    
    if csv_format['format_type'] == 'standard':
        # 标准英文格式验证
        errors.extend(validate_standard_format(df))
    elif csv_format['format_type'] == 'chinese':
        # 中文格式验证
        errors.extend(validate_chinese_format(df))
    elif csv_format['format_type'] == 'flexible':
        # 灵活格式验证
        errors.extend(validate_flexible_format(df, csv_format))
    else:
        errors.append(f"不支持的CSV格式: {csv_format['format_name']}")
        # 尝试提供格式建议
        errors.append("支持的格式:")
        errors.append("1. 标准英文格式: question_type, question_text, correct_answer, option_A, option_B...")
        errors.append("2. 中文格式: 章节, 题目, 选项A, 选项B, 选项C, 选项D, 正确答案, 难度")
        errors.append("3. 自适应格式: 包含题目内容和正确答案的列（列名灵活）")
    
    return errors

def validate_standard_format(df: pd.DataFrame) -> List[str]:
    """验证标准英文格式"""
    errors = []
    
    # 检查必要列
    required_columns = ['question_type', 'question_text', 'correct_answer']
    for col in required_columns:
        if col not in df.columns:
            errors.append(f"缺少必要的列: {col}")
    
    # 检查数据
    for index, row in df.iterrows():
        row_num = index + 1
        
        # 检查题目类型
        if pd.isna(row.get('question_type')):
            errors.append(f"第{row_num}行: 题目类型不能为空")
        else:
            valid_types = [
                # 基础题型
                'choice', 'judge', 'essay', 'short_answer', 'fill_blank',
                # 编程题型
                'code_reading', 'code_practice', 'programming',
                # 英语阅读理解
                'reading_comprehension', 'reading_multiple_choice', 'reading_true_false',
                'reading_fill_blank', 'reading_matching', 'reading_summary', 'reading_passage_multiple',
                # 英语完型填空
                'cloze_test', 'cloze_multiple_choice', 'cloze_word_bank', 'cloze_grammar',
                # 英语听力理解
                'listening_comprehension', 'listening_multiple_choice', 'listening_fill_blank',
                'listening_matching', 'listening_note_taking', 'listening_summary',
                # 英语口语表达
                'speaking_independent', 'speaking_integrated', 'speaking_description',
                'speaking_opinion', 'speaking_conversation', 'speaking_presentation',
                # 英语写作表达
                'writing_essay', 'writing_integrated', 'writing_independent',
                'writing_summary', 'writing_letter', 'writing_report',
                # 英语语法词汇
                'grammar_choice', 'vocabulary_choice', 'vocabulary_fill',
                'phrase_matching', 'sentence_correction', 'word_formation',
                # 英语翻译
                'translation_en_to_cn', 'translation_cn_to_en', 'translation_sentence', 'translation_paragraph',
                # 托福专项
                'toefl_integrated',
                # 雅思专项
                'ielts_task1', 'ielts_task2', 'ielts_speaking_part1', 'ielts_speaking_part2', 'ielts_speaking_part3',
                # GRE专项
                'gre_reading', 'gre_verbal',
                # 考研专项
                'postgraduate_reading', 'postgraduate_cloze', 'postgraduate_translation', 'postgraduate_writing'
            ]
            if str(row['question_type']).lower() not in valid_types:
                errors.append(f"第{row_num}行: 不支持的题目类型 '{row['question_type']}'，支持的类型请参考文档")
        
        # 检查题目内容
        if pd.isna(row.get('question_text')) or str(row['question_text']).strip() == '':
            errors.append(f"第{row_num}行: 题目内容不能为空")
        
        # 检查正确答案
        if pd.isna(row.get('correct_answer')) or str(row['correct_answer']).strip() == '':
            errors.append(f"第{row_num}行: 正确答案不能为空")
        
        # 检查选择题选项
        if str(row.get('question_type', '')).lower() == 'choice' or 'choice' in str(row.get('question_type', '')).lower():
            option_cols = [col for col in df.columns if col.startswith('option_')]
            if not option_cols:
                errors.append(f"第{row_num}行: 选择题必须包含选项列 (option_A, option_B, etc.)")
    
    return errors

def validate_chinese_format(df: pd.DataFrame) -> List[str]:
    """验证中文格式"""
    errors = []
    
    # 检查必要列
    required_columns = ['题目', '正确答案']
    for col in required_columns:
        if col not in df.columns:
            errors.append(f"缺少必要的列: {col}")
    
    # 检查推荐列
    recommended_columns = ['章节', '难度']
    missing_recommended = [col for col in recommended_columns if col not in df.columns]
    if missing_recommended:
        errors.append(f"建议添加的列: {', '.join(missing_recommended)}")
    
    # 检查数据
    if len(df) == 0:
        errors.append("CSV文件为空")
        return errors
    
    for index, row in df.iterrows():
        row_num = index + 1
        
        # 检查题目内容
        if pd.isna(row.get('题目')) or str(row['题目']).strip() == '':
            errors.append(f"第{row_num}行: 题目内容不能为空")
        
        # 检查正确答案
        if pd.isna(row.get('正确答案')) or str(row['正确答案']).strip() == '':
            errors.append(f"第{row_num}行: 正确答案不能为空")
        
        # 检查选项一致性（如果有选项列）
        option_columns = ['选项A', '选项B', '选项C', '选项D']
        has_options = any(col in df.columns for col in option_columns)
        if has_options:
            valid_options = [col for col in option_columns if col in df.columns and pd.notna(row.get(col))]
            if len(valid_options) < 2:
                errors.append(f"第{row_num}行: 选择题至少需要2个选项")
            
            # 检查正确答案是否匹配选项
            correct_answer = str(row.get('正确答案', '')).strip()
            if correct_answer.upper() not in ['A', 'B', 'C', 'D', 'E', 'F']:
                # 检查是否是选项内容
                option_found = False
                for i, option_col in enumerate(option_columns):
                    if option_col in df.columns and pd.notna(row.get(option_col)):
                        if correct_answer in str(row[option_col]):
                            option_found = True
                            break
                if not option_found:
                    errors.append(f"第{row_num}行: 正确答案 '{correct_answer}' 与选项不匹配")
        
        # 检查难度值
        if '难度' in df.columns and pd.notna(row.get('难度')):
            difficulty = str(row['难度']).strip()
            if difficulty not in ['容易', '简单', '适当', '中等', '困难', '难', 'easy', 'medium', 'hard']:
                errors.append(f"第{row_num}行: 难度值 '{difficulty}' 不在支持范围内")
    
    return errors

def validate_flexible_format(df: pd.DataFrame, csv_format: Dict[str, Any]) -> List[str]:
    """验证灵活格式"""
    errors = []
    column_mapping = csv_format['column_mapping']
    
    # 检查必要映射
    if not column_mapping['question_text']:
        errors.append("无法找到题目内容列，请确保列名包含：题目、question、text、内容、问题等关键词")
    
    if not column_mapping['correct_answer']:
        errors.append("无法找到正确答案列，请确保列名包含：正确答案、answer、correct、答案等关键词")
    
    if errors:
        return errors
    
    # 检查数据
    if len(df) == 0:
        errors.append("CSV文件为空")
        return errors
    
    for index, row in df.iterrows():
        row_num = index + 1
        
        # 检查题目内容
        question_text = str(row.get(column_mapping['question_text'], '')).strip()
        if not question_text:
            errors.append(f"第{row_num}行: 题目内容不能为空")
        
        # 检查正确答案
        correct_answer = str(row.get(column_mapping['correct_answer'], '')).strip()
        if not correct_answer:
            errors.append(f"第{row_num}行: 正确答案不能为空")
        
        # 检查选项（如果有）
        if column_mapping['options']:
            valid_options = []
            for option_key, option_col in column_mapping['options'].items():
                if pd.notna(row.get(option_col)):
                    valid_options.append(option_key)
            
            if len(valid_options) > 0 and len(valid_options) < 2:
                errors.append(f"第{row_num}行: 选择题至少需要2个选项")
    
    return errors

def validate_students_csv_format(df: pd.DataFrame) -> List[str]:
    """验证学生CSV格式"""
    errors = []
    
    # 检查必需的列
    required_columns = ['student_id', 'name']
    for col in required_columns:
        if col not in df.columns:
            errors.append(f"缺少必需的列: {col}")
    
    # 检查推荐的列
    recommended_columns = ['password', 'college', 'major', 'class_name', 'gender', 'notes']
    missing_recommended = [col for col in recommended_columns if col not in df.columns]
    if missing_recommended:
        errors.append(f"建议添加的列: {', '.join(missing_recommended)}")
    
    # 检查数据
    if len(df) == 0:
        errors.append("CSV文件为空")
        return errors
    
    # 检查学号重复
    if 'student_id' in df.columns:
        duplicate_ids = df[df['student_id'].duplicated()]['student_id'].tolist()
        if duplicate_ids:
            errors.append(f"发现重复学号: {', '.join(map(str, duplicate_ids))}")
    
    # 检查必填字段是否为空
    if 'student_id' in df.columns:
        empty_ids = df[df['student_id'].isna() | (df['student_id'].astype(str).str.strip() == '')].index.tolist()
        if empty_ids:
            errors.append(f"第 {', '.join(map(lambda x: str(x+2), empty_ids))} 行学号为空")
    
    if 'name' in df.columns:
        empty_names = df[df['name'].isna() | (df['name'].astype(str).str.strip() == '')].index.tolist()
        if empty_names:
            errors.append(f"第 {', '.join(map(lambda x: str(x+2), empty_names))} 行姓名为空")
    
    return errors

def create_sample_csv_content() -> str:
    """创建示例CSV内容"""
    return """question_type,question_text,option_A,option_B,option_C,option_D,correct_answer,difficulty,subject
choice,Python中哪个关键字用于定义函数?,def,function,func,define,A,1,Python
choice,以下哪个不是Python的数据类型?,int,str,bool,array,D,2,Python
judge,Python是一种解释型语言,,,,,True,1,Python
judge,Python中的列表是可变的,,,,,True,1,Python
essay,请简述Python的主要特点,,,,,面向对象 解释型 动态类型,3,Python"""

def create_sample_students_csv_content() -> str:
    """创建示例学生CSV内容"""
    return """student_id,name,password,college,major,class_name,gender,notes
2021001,张三,123456,计算机学院,计算机科学与技术,计科21-1,男,班长
2021002,李四,2021002,计算机学院,软件工程,软工21-1,女,学习委员
2021003,王五,password123,网络安全学院,信息安全,信安21-1,男,
2021004,赵六,666666,数据科学学院,数据科学与大数据技术,数据21-1,女,体育委员
2021005,钱七,qwerty,人工智能学院,人工智能,人工21-1,男,优秀学生"""

def generate_session_token():
    """生成安全的会话令牌"""
    return secrets.token_urlsafe(32)

def hash_session_token(token):
    """对会话令牌进行哈希处理"""
    return hashlib.sha256(token.encode()).hexdigest()

def create_login_session(db, user_type, user_id, user_info):
    """创建登录会话"""
    token = generate_session_token()
    token_hash = hash_session_token(token)
    
    # 会话有效期24小时
    expires_at = datetime.now() + timedelta(hours=24)
    
    # 存储会话信息到数据库
    db.create_session(token_hash, user_type, user_id, user_info, expires_at)
    
    return token

def get_persistent_login_js():
    """返回用于持久化登录状态的JavaScript代码"""
    return """
    <script>
    // 保存登录状态到localStorage
    function saveLoginState(userType, token, userInfo) {
        const loginData = {
            userType: userType,
            token: token,
            userInfo: userInfo,
            timestamp: Date.now()
        };
        localStorage.setItem('flashexam_login', JSON.stringify(loginData));
    }
    
    // 从localStorage获取登录状态
    function getLoginState() {
        const loginData = localStorage.getItem('flashexam_login');
        if (loginData) {
            try {
                const data = JSON.parse(loginData);
                // 检查是否过期（24小时）
                if (Date.now() - data.timestamp < 24 * 60 * 60 * 1000) {
                    return data;
                } else {
                    // 过期则清除
                    clearLoginState();
                }
            } catch (e) {
                clearLoginState();
            }
        }
        return null;
    }
    
    // 清除登录状态
    function clearLoginState() {
        localStorage.removeItem('flashexam_login');
    }
    
    // 检查登录状态并通知Streamlit
    function checkLoginState() {
        const loginState = getLoginState();
        if (loginState) {
            // 使用Streamlit的自定义组件通信机制
            window.parent.postMessage({
                type: 'streamlit:setComponentValue',
                value: loginState
            }, '*');
        }
    }
    
    // 页面加载时检查登录状态
    document.addEventListener('DOMContentLoaded', checkLoginState);
    
    // 定义全局函数供Streamlit调用
    window.FlashExamAuth = {
        saveLogin: saveLoginState,
        getLogin: getLoginState,
        clearLogin: clearLoginState,
        checkLogin: checkLoginState
    };
    </script>
    """

def render_login_persistence_component():
    """渲染登录持久化组件"""
    import streamlit.components.v1 as components
    
    html_code = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Login Persistence</title>
    </head>
    <body>
        {get_persistent_login_js()}
        <div id="login-checker" style="display: none;"></div>
    </body>
    </html>
    """
    
    # 使用components.html渲染JavaScript
    return components.html(html_code, height=0, key="login_persistence")

def check_session_validity(db, token):
    """检查会话令牌是否有效"""
    if not token:
        return None
    
    token_hash = hash_session_token(token)
    session_info = db.get_session(token_hash)
    
    if session_info and session_info['expires_at'] > datetime.now():
        return session_info
    
    # 会话过期或无效，清除
    if session_info:
        db.delete_session(token_hash)
    
    return None

def get_login_html_component(action_type="check"):
    """获取登录相关的HTML组件 - 简化版本，避免兼容性问题"""
    if action_type == "save":
        return """
        <script>
        // 保存登录状态到localStorage
        function saveLoginToStorage(userType, sessionToken, userInfo) {
            const loginData = {
                userType: userType,
                sessionToken: sessionToken,
                userInfo: userInfo,
                timestamp: Date.now()
            };
            localStorage.setItem('flashexam_session', JSON.stringify(loginData));
            sessionStorage.setItem('flashexam_active', 'true');
            console.log('Login state saved:', userType);
        }
        
        // 立即检查是否需要保存
        const urlParams = new URLSearchParams(window.location.search);
        const saveLogin = urlParams.get('save_login');
        if (saveLogin) {
            setTimeout(() => {
                window.parent.postMessage({type: 'flashexam_login_saved'}, '*');
            }, 100);
        }
        </script>
        """
    
    elif action_type == "check":
        return """
        <script>
        // 检查并恢复登录状态 - 简化版本
        function checkLoginState() {
            try {
                const sessionData = localStorage.getItem('flashexam_session');
                const isActive = sessionStorage.getItem('flashexam_active');
                
                if (sessionData && isActive) {
                    const data = JSON.parse(sessionData);
                    // 检查24小时有效期
                    if (Date.now() - data.timestamp < 24 * 60 * 60 * 1000) {
                        // 通过URL参数的方式通知Streamlit
                        const currentUrl = new URL(window.location);
                        if (!currentUrl.searchParams.has('restored_login')) {
                            currentUrl.searchParams.set('restored_login', 'true');
                            currentUrl.searchParams.set('login_data', btoa(JSON.stringify(data)));
                            window.location.href = currentUrl.toString();
                        }
                        return;
                    }
                }
                
                // 清理无效数据
                localStorage.removeItem('flashexam_session');
                sessionStorage.removeItem('flashexam_active');
                
                // 清理URL参数
                const currentUrl = new URL(window.location);
                if (currentUrl.searchParams.has('restored_login')) {
                    currentUrl.searchParams.delete('restored_login');
                    currentUrl.searchParams.delete('login_data');
                    window.history.replaceState({}, '', currentUrl.toString());
                }
            } catch (e) {
                console.log('检查登录状态时发生错误:', e);
            }
        }
        
        // 页面加载完成后检查
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', checkLoginState);
        } else {
            checkLoginState();
        }
        </script>
        """
    
    elif action_type == "clear":
        return """
        <script>
        // 清除登录状态
        localStorage.removeItem('flashexam_session');
        sessionStorage.removeItem('flashexam_active');
        console.log('Login state cleared');
        
        // 清理URL参数
        const currentUrl = new URL(window.location);
        currentUrl.searchParams.delete('restored_login');
        currentUrl.searchParams.delete('login_data');
        window.history.replaceState({}, '', currentUrl.toString());
        </script>
        """

def init_session_management(st):
    """初始化会话管理"""
    # 在session_state中添加会话管理相关的键
    if 'login_checked' not in st.session_state:
        st.session_state.login_checked = False
    
    if 'session_token' not in st.session_state:
        st.session_state.session_token = None
    
    if 'login_restored' not in st.session_state:
        st.session_state.login_restored = False

def simplified_login_persistence_check():
    """简化的登录持久化检查 - 通过URL参数方式"""
    import streamlit as st
    
    # 只使用新版本的 st.query_params API
    try:
        query_params = st.query_params
    except Exception as e:
        print(f"获取查询参数失败: {e}")
        return None
    
    if 'restored_login' in query_params and 'login_data' in query_params:
        try:
            import base64
            import json
            
            # 解码登录数据
            encoded_data = query_params['login_data']
            decoded_data = base64.b64decode(encoded_data).decode('utf-8')
            login_data = json.loads(decoded_data)
            
            return login_data
        except Exception as e:
            print(f"恢复登录数据失败: {e}")
            return None
    
    return None

def save_login_state_simplified(user_type, session_token, user_info):
    """简化的保存登录状态"""
    import streamlit as st
    import streamlit.components.v1 as components
    
    # 使用简化的HTML组件，不使用key参数
    html_code = f"""
    <script>
    const loginData = {{
        userType: '{user_type}',
        sessionToken: '{session_token}',
        userInfo: {json.dumps(user_info)},
        timestamp: Date.now()
    }};
    localStorage.setItem('flashexam_session', JSON.stringify(loginData));
    sessionStorage.setItem('flashexam_active', 'true');
    console.log('登录状态已保存:', '{user_type}');
    </script>
    """
    
    # 不使用key参数
    components.html(html_code, height=0)

def clear_login_state_simplified():
    """简化的清除登录状态"""
    import streamlit.components.v1 as components
    
    html_code = """
    <script>
    localStorage.removeItem('flashexam_session');
    sessionStorage.removeItem('flashexam_active');
    console.log('登录状态已清除');
    
    // 清理URL参数
    const currentUrl = new URL(window.location);
    currentUrl.searchParams.delete('restored_login');
    currentUrl.searchParams.delete('login_data');
    window.history.replaceState({}, '', currentUrl.toString());
    </script>
    """
    
    components.html(html_code, height=0) 