#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阅读理解材料数据库操作类
"""

import sqlite3
import json
from datetime import datetime
from typing import List, Optional, Tuple
from reading_passage_models import (
    ReadingPassage, PassageQuestion, PassageSet, 
    PassageSetItem, PassageExamResult, PassageQuestionResult
)

class ReadingPassageDatabase:
    """阅读理解数据库操作类"""
    
    def __init__(self, db_path="exam_database.db"):
        self.db_path = db_path
        self.init_tables()
    
    def get_connection(self):
        """获取数据库连接"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_tables(self):
        """初始化阅读理解相关表"""
        with self.get_connection() as conn:
            # 阅读材料表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS reading_passages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    source TEXT DEFAULT '',
                    topic TEXT DEFAULT '',
                    difficulty_level INTEGER DEFAULT 2,
                    word_count INTEGER DEFAULT 0,
                    reading_time INTEGER DEFAULT 0,
                    language TEXT DEFAULT 'en',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT 1
                )
            """)
            
            # 阅读材料题目表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS passage_questions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    passage_id INTEGER NOT NULL,
                    question_order INTEGER DEFAULT 1,
                    question_type TEXT NOT NULL,
                    question_text TEXT NOT NULL,
                    options TEXT DEFAULT '',
                    correct_answer TEXT NOT NULL,
                    explanation TEXT DEFAULT '',
                    difficulty INTEGER DEFAULT 2,
                    points REAL DEFAULT 1.0,
                    time_limit INTEGER DEFAULT 0,
                    skill_focus TEXT DEFAULT '',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT 1,
                    FOREIGN KEY (passage_id) REFERENCES reading_passages (id)
                )
            """)
            
            # 阅读材料集合表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS passage_sets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT DEFAULT '',
                    exam_type TEXT DEFAULT '',
                    total_passages INTEGER DEFAULT 0,
                    total_questions INTEGER DEFAULT 0,
                    time_limit INTEGER DEFAULT 60,
                    difficulty_level INTEGER DEFAULT 2,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_active BOOLEAN DEFAULT 1
                )
            """)
            
            # 阅读材料集合项目表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS passage_set_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    set_id INTEGER NOT NULL,
                    passage_id INTEGER NOT NULL,
                    passage_order INTEGER DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (set_id) REFERENCES passage_sets (id),
                    FOREIGN KEY (passage_id) REFERENCES reading_passages (id)
                )
            """)
            
            # 阅读理解考试结果表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS passage_exam_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    set_id INTEGER NOT NULL,
                    student_id INTEGER NOT NULL,
                    passage_results TEXT DEFAULT '{}',
                    total_score REAL DEFAULT 0.0,
                    total_possible REAL DEFAULT 0.0,
                    percentage REAL DEFAULT 0.0,
                    start_time TIMESTAMP,
                    end_time TIMESTAMP,
                    time_spent INTEGER DEFAULT 0,
                    is_completed BOOLEAN DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (set_id) REFERENCES passage_sets (id),
                    FOREIGN KEY (student_id) REFERENCES students (id)
                )
            """)
            
            # 阅读理解题目结果详情表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS passage_question_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exam_result_id INTEGER NOT NULL,
                    passage_id INTEGER NOT NULL,
                    question_id INTEGER NOT NULL,
                    student_answer TEXT DEFAULT '',
                    correct_answer TEXT DEFAULT '',
                    is_correct BOOLEAN DEFAULT 0,
                    score REAL DEFAULT 0.0,
                    max_score REAL DEFAULT 1.0,
                    time_spent INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (exam_result_id) REFERENCES passage_exam_results (id),
                    FOREIGN KEY (passage_id) REFERENCES reading_passages (id),
                    FOREIGN KEY (question_id) REFERENCES passage_questions (id)
                )
            """)
            
            conn.commit()
            print("✅ 阅读理解数据库表初始化完成")
    
    # ================= 阅读材料操作 =================
    
    def add_reading_passage(self, passage: ReadingPassage) -> int:
        """添加阅读材料"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO reading_passages 
                (title, content, source, topic, difficulty_level, word_count, reading_time, language)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                passage.title, passage.content, passage.source, passage.topic,
                passage.difficulty_level, passage.word_count, passage.reading_time, passage.language
            ))
            return cursor.lastrowid
    
    def get_reading_passages(self, active_only=True) -> List[ReadingPassage]:
        """获取所有阅读材料"""
        with self.get_connection() as conn:
            query = "SELECT * FROM reading_passages"
            if active_only:
                query += " WHERE is_active = 1"
            query += " ORDER BY created_at DESC"
            
            rows = conn.execute(query).fetchall()
            return [self._row_to_reading_passage(row) for row in rows]
    
    def get_reading_passage(self, passage_id: int) -> Optional[ReadingPassage]:
        """获取单个阅读材料"""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT * FROM reading_passages WHERE id = ?", (passage_id,)
            ).fetchone()
            return self._row_to_reading_passage(row) if row else None
    
    def update_reading_passage(self, passage: ReadingPassage) -> bool:
        """更新阅读材料"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                UPDATE reading_passages 
                SET title=?, content=?, source=?, topic=?, difficulty_level=?, 
                    word_count=?, reading_time=?, language=?, updated_at=CURRENT_TIMESTAMP
                WHERE id=?
            """, (
                passage.title, passage.content, passage.source, passage.topic,
                passage.difficulty_level, passage.word_count, passage.reading_time, 
                passage.language, passage.id
            ))
            return cursor.rowcount > 0
    
    def delete_reading_passage(self, passage_id: int) -> bool:
        """删除阅读材料（软删除）"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "UPDATE reading_passages SET is_active = 0 WHERE id = ?", (passage_id,)
            )
            return cursor.rowcount > 0
    
    # ================= 阅读材料题目操作 =================
    
    def add_passage_question(self, question: PassageQuestion) -> int:
        """添加阅读材料题目"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO passage_questions 
                (passage_id, question_order, question_type, question_text, options, 
                 correct_answer, explanation, difficulty, points, time_limit, skill_focus)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                question.passage_id, question.question_order, question.question_type,
                question.question_text, question.options, question.correct_answer,
                question.explanation, question.difficulty, question.points,
                question.time_limit, question.skill_focus
            ))
            return cursor.lastrowid
    
    def get_passage_questions(self, passage_id: int, active_only=True) -> List[PassageQuestion]:
        """获取阅读材料的所有题目"""
        with self.get_connection() as conn:
            query = "SELECT * FROM passage_questions WHERE passage_id = ?"
            params = [passage_id]
            
            if active_only:
                query += " AND is_active = 1"
            query += " ORDER BY question_order"
            
            rows = conn.execute(query, params).fetchall()
            return [self._row_to_passage_question(row) for row in rows]
    
    def get_passage_question(self, question_id: int) -> Optional[PassageQuestion]:
        """获取单个题目"""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT * FROM passage_questions WHERE id = ?", (question_id,)
            ).fetchone()
            return self._row_to_passage_question(row) if row else None
    
    def update_passage_question(self, question: PassageQuestion) -> bool:
        """更新题目"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                UPDATE passage_questions 
                SET question_order=?, question_type=?, question_text=?, options=?, 
                    correct_answer=?, explanation=?, difficulty=?, points=?, 
                    time_limit=?, skill_focus=?
                WHERE id=?
            """, (
                question.question_order, question.question_type, question.question_text,
                question.options, question.correct_answer, question.explanation,
                question.difficulty, question.points, question.time_limit,
                question.skill_focus, question.id
            ))
            return cursor.rowcount > 0
    
    def delete_passage_question(self, question_id: int) -> bool:
        """删除题目（软删除）"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "UPDATE passage_questions SET is_active = 0 WHERE id = ?", (question_id,)
            )
            return cursor.rowcount > 0
    
    # ================= 阅读材料集合操作 =================
    
    def create_passage_set(self, passage_set: PassageSet, passage_ids: List[int]) -> int:
        """创建阅读材料集合"""
        with self.get_connection() as conn:
            # 创建集合
            cursor = conn.execute("""
                INSERT INTO passage_sets 
                (title, description, exam_type, total_passages, total_questions, time_limit, difficulty_level)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                passage_set.title, passage_set.description, passage_set.exam_type,
                len(passage_ids), passage_set.total_questions, passage_set.time_limit,
                passage_set.difficulty_level
            ))
            set_id = cursor.lastrowid
            
            # 添加集合项目
            for order, passage_id in enumerate(passage_ids, 1):
                conn.execute("""
                    INSERT INTO passage_set_items (set_id, passage_id, passage_order)
                    VALUES (?, ?, ?)
                """, (set_id, passage_id, order))
            
            return set_id
    
    def get_passage_sets(self, active_only=True) -> List[PassageSet]:
        """获取所有阅读材料集合"""
        with self.get_connection() as conn:
            query = "SELECT * FROM passage_sets"
            if active_only:
                query += " WHERE is_active = 1"
            query += " ORDER BY created_at DESC"
            
            rows = conn.execute(query).fetchall()
            return [self._row_to_passage_set(row) for row in rows]
    
    def get_passage_set_with_passages(self, set_id: int) -> Tuple[Optional[PassageSet], List[ReadingPassage]]:
        """获取集合及其包含的阅读材料"""
        with self.get_connection() as conn:
            # 获取集合信息
            set_row = conn.execute(
                "SELECT * FROM passage_sets WHERE id = ?", (set_id,)
            ).fetchone()
            
            if not set_row:
                return None, []
            
            passage_set = self._row_to_passage_set(set_row)
            
            # 获取集合中的阅读材料
            passages_query = """
                SELECT rp.* FROM reading_passages rp
                JOIN passage_set_items psi ON rp.id = psi.passage_id
                WHERE psi.set_id = ? AND rp.is_active = 1
                ORDER BY psi.passage_order
            """
            passage_rows = conn.execute(passages_query, (set_id,)).fetchall()
            passages = [self._row_to_reading_passage(row) for row in passage_rows]
            
            return passage_set, passages
    
    # ================= 数据转换辅助方法 =================
    
    def _row_to_reading_passage(self, row) -> ReadingPassage:
        """将数据库行转换为ReadingPassage对象"""
        return ReadingPassage(
            id=row['id'],
            title=row['title'],
            content=row['content'],
            source=row['source'],
            topic=row['topic'],
            difficulty_level=row['difficulty_level'],
            word_count=row['word_count'],
            reading_time=row['reading_time'],
            language=row['language'],
            created_at=datetime.fromisoformat(row['created_at']) if row['created_at'] else None,
            updated_at=datetime.fromisoformat(row['updated_at']) if row['updated_at'] else None,
            is_active=bool(row['is_active'])
        )
    
    def _row_to_passage_question(self, row) -> PassageQuestion:
        """将数据库行转换为PassageQuestion对象"""
        return PassageQuestion(
            id=row['id'],
            passage_id=row['passage_id'],
            question_order=row['question_order'],
            question_type=row['question_type'],
            question_text=row['question_text'],
            options=row['options'],
            correct_answer=row['correct_answer'],
            explanation=row['explanation'],
            difficulty=row['difficulty'],
            points=row['points'],
            time_limit=row['time_limit'],
            skill_focus=row['skill_focus'],
            created_at=datetime.fromisoformat(row['created_at']) if row['created_at'] else None,
            is_active=bool(row['is_active'])
        )
    
    def _row_to_passage_set(self, row) -> PassageSet:
        """将数据库行转换为PassageSet对象"""
        return PassageSet(
            id=row['id'],
            title=row['title'],
            description=row['description'],
            exam_type=row['exam_type'],
            total_passages=row['total_passages'],
            total_questions=row['total_questions'],
            time_limit=row['time_limit'],
            difficulty_level=row['difficulty_level'],
            created_at=datetime.fromisoformat(row['created_at']) if row['created_at'] else None,
            is_active=bool(row['is_active'])
        ) 