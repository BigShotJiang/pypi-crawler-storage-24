#!/usr/bin/env python3
"""
快速测试脚本 - 检查AI评分功能状态
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_ollama_service():
    """测试Ollama服务状态"""
    print("🔍 正在检查Ollama服务状态...")
    
    try:
        from intelligent_grading_ollama import check_ollama_service_status, diagnose_ollama_setup
        
        # 检查服务状态
        status = check_ollama_service_status()
        
        if status["service_available"]:
            print("✅ Ollama服务运行正常")
            print(f"📄 版本: {status['version']}")
            
            if status["models"]:
                print(f"📦 可用模型: {', '.join(status['models'])}")
                
                if 'qwen3:0.6b' in status["models"]:
                    print("✅ 推荐模型qwen3:0.6b可用")
                    return True
                elif 'qwen2:7b' in status["models"]:
                    print("✅ 备用模型qwen2:7b可用")
                    return True
                else:
                    print("⚠️ 推荐模型qwen3:0.6b不可用")
                    print("💡 请运行: ollama pull qwen3:0.6b")
                    return False
            else:
                print("❌ 没有可用模型")
                print("💡 请运行: ollama pull qwen3:0.6b")
                return False
        else:
            print(f"❌ Ollama服务不可用: {status['error_message']}")
            print("\n" + diagnose_ollama_setup())
            return False
            
    except ImportError as e:
        print(f"❌ 无法导入Ollama模块: {e}")
        return False
    except Exception as e:
        print(f"❌ 检查Ollama服务时出错: {e}")
        return False

def test_grading_engine():
    """测试评分引擎"""
    print("\n🧪 正在测试评分引擎...")
    
    try:
        from grading_engine import get_grading_engine
        
        # 初始化评分引擎
        engine = get_grading_engine()
        print(f"✅ 评分引擎初始化成功")
        print(f"📦 可用方法: {engine.get_available_methods()}")
        
        # 测试用例
        test_cases = [
            {
                'name': 'Ollama AI评分测试',
                'question_type': 'subjective',
                'student_answer': '列表推导式是Python中一种简洁的创建列表的方法',
                'reference_answer': '列表推导式是一种简洁的创建列表的方法',
                'question_text': '请简述Python列表推导式的特点',
                'max_score': 10.0,
                'method': 'ai_ollama'
            },
            {
                'name': 'Qwen AI评分测试',
                'question_type': 'subjective',
                'student_answer': 'Python是解释型语言，面向对象',
                'reference_answer': 'Python是一种解释型、面向对象的高级编程语言',
                'question_text': '请简述Python的特点',
                'max_score': 5.0,
                'method': 'ai_qwen'
            },
            {
                'name': 'AI增强评分测试',
                'question_type': 'subjective',
                'student_answer': '函数可以重复使用代码',
                'reference_answer': '函数是一段可重复使用的代码块',
                'question_text': '请说明函数的作用',
                'max_score': 5.0,
                'method': 'ai_enhanced'
            }
        ]
        
        all_success = True
        
        for test_case in test_cases:
            print(f"\n📝 {test_case['name']}:")
            
            try:
                result = engine.grade(**test_case)
                print(f"   得分: {result['score']}/{test_case['max_score']}")
                print(f"   置信度: {result['confidence']:.2f}")
                print(f"   方法: {result['method']}")
                print(f"   反馈: {result['feedback'][:100]}...")
                
                # 检查是否使用了回退方法
                if 'fallback' in result['method'].lower() or 'error' in result['method'].lower():
                    print(f"   ⚠️ 使用了回退方法: {result['method']}")
                    if test_case['method'] == 'ai_ollama':
                        all_success = False
                else:
                    print(f"   ✅ 评分成功")
                    
            except Exception as e:
                print(f"   ❌ 评分失败: {e}")
                all_success = False
        
        return all_success
        
    except Exception as e:
        print(f"❌ 评分引擎测试失败: {e}")
        return False

def main():
    """主函数"""
    print("🎓 FlashExam AI评分功能状态检查")
    print("=" * 50)
    
    ollama_ok = test_ollama_service()
    engine_ok = test_grading_engine()
    
    print("\n" + "=" * 50)
    print("📊 测试总结:")
    
    if ollama_ok and engine_ok:
        print("✅ 所有AI评分功能正常")
        print("💡 您可以在主观题评分中使用以下方法：")
        print("   - Ollama本地模型（推荐）")
        print("   - Qwen本地模型")
        print("   - AI增强算法")
    elif engine_ok:
        print("⚠️ 评分引擎正常，但Ollama服务不可用")
        print("💡 您可以使用以下备用方法：")
        print("   - Qwen本地模型")
        print("   - AI增强算法") 
        print("   - 语义相似度")
        print("   - 关键词匹配")
    else:
        print("❌ AI评分功能存在问题")
        print("💡 建议：")
        print("   1. 检查Ollama安装和服务状态")
        print("   2. 检查Qwen模型是否正确下载")
        print("   3. 查看日志获取详细错误信息")
    
    print("\n🔗 如需帮助，请参考docs/目录下的相关文档")

if __name__ == "__main__":
    main() 