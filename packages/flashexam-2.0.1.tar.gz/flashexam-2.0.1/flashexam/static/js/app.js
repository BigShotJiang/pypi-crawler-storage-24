/**
 * FlashExam - 前端JavaScript文件
 * 增强版 - 离线模式支持
 */

// 全局变量
window.FlashExam = window.FlashExam || {};
window.FlashExam.offlineMode = true; // 默认启用离线模式

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    console.log('⚡ FlashExam 前端脚本已加载');
    
    // 初始化Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // 初始化Bootstrap popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // 自动隐藏alert消息
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert:not([data-persistent])');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // 资源加载检查
    checkResourceLoading();
});

/**
 * 检查关键资源是否正确加载
 */
function checkResourceLoading() {
    // 检查Bootstrap是否已加载
    if (typeof bootstrap === 'undefined') {
        console.error('⚠️ Bootstrap未加载');
        FlashExam.showResourceError('Bootstrap库未加载，页面可能无法正常显示。请检查static/js/libs/bootstrap/目录。');
    }
    
    // 检查jQuery是否已加载
    if (typeof jQuery === 'undefined') {
        console.error('⚠️ jQuery未加载');
        FlashExam.showResourceError('jQuery库未加载，页面交互功能可能无法正常工作。请检查static/js/libs/jquery/目录。');
    }
    
    // 检查Prism代码高亮库是否可用（可选依赖）
    if (typeof Prism === 'undefined' && document.querySelector('pre > code')) {
        console.warn('⚠️ Prism代码高亮库未加载，但页面中包含代码块');
    }
}

/**
 * 显示资源错误提示
 */
FlashExam.showResourceError = function(message) {
    var container = document.querySelector('main') || document.body;
    var alertDiv = document.createElement('div');
    alertDiv.className = 'resource-error';
    alertDiv.innerHTML = '<strong>资源加载错误:</strong> ' + message;
    
    if (container.firstChild) {
        container.insertBefore(alertDiv, container.firstChild);
    } else {
        container.appendChild(alertDiv);
    }
};

// 通用AJAX请求函数 - 增强版支持离线模式
FlashExam.ajax = function(url, options) {
    options = options || {};
    options.method = options.method || 'GET';
    options.headers = options.headers || {};
    options.headers['Content-Type'] = options.headers['Content-Type'] || 'application/json';
    
    // 检查网络连接状态
    if (!navigator.onLine) {
        return Promise.reject(new Error('网络连接已断开，请检查网络设置'));
    }
    
    return fetch(url, options)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.status);
            }
            return response.json();
        })
        .catch(error => {
            console.error('AJAX Error:', error);
            // 添加离线模式提示
            if (window.FlashExam.offlineMode) {
                console.warn('🔍 当前处于离线模式，部分网络请求可能不可用');
            }
            throw error;
        });
};

// 显示消息提示
FlashExam.showMessage = function(message, type) {
    type = type || 'info';
    const alertClass = {
        'success': 'alert-success',
        'error': 'alert-danger', 
        'warning': 'alert-warning',
        'info': 'alert-info'
    }[type] || 'alert-info';
    
    const icon = {
        'success': 'bi-check-circle',
        'error': 'bi-exclamation-triangle',
        'warning': 'bi-exclamation-circle',
        'info': 'bi-info-circle'
    }[type] || 'bi-info-circle';
    
    const alertHtml = `
        <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
            <i class="bi ${icon}"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // 找到容器并插入消息
    const container = document.querySelector('main .container-fluid') || 
                      document.querySelector('main .container') || 
                      document.body;
    const alertDiv = document.createElement('div');
    alertDiv.innerHTML = alertHtml;
    
    if (container.firstChild) {
        container.insertBefore(alertDiv.firstElementChild, container.firstChild);
    } else {
        container.appendChild(alertDiv.firstElementChild);
    }
    
    // 3秒后自动消失
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert:not([data-persistent])');
        alerts.forEach(alert => {
            if (alert.parentElement) { // 确保元素仍在DOM中
                try {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                } catch (e) {
                    // 如果bootstrap未加载，手动移除
                    alert.parentElement.removeChild(alert);
                }
            }
        });
    }, 3000);
};

console.log('FlashExam JavaScript loaded successfully'); 