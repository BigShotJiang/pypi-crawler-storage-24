
    // 离线检测工具
    (function() {
        'use strict';
        
        // 检查资源是否可用
        function checkResource(url) {
            return new Promise((resolve) => {
                const xhr = new XMLHttpRequest();
                xhr.open('HEAD', url, true);
                xhr.timeout = 5000;
                
                xhr.onload = function() {
                    resolve(xhr.status >= 200 && xhr.status < 300);
                };
                
                xhr.onerror = function() {
                    resolve(false);
                };
                
                xhr.ontimeout = function() {
                    resolve(false);
                };
                
                xhr.send();
            });
        }
        
        // 检查关键资源
        async function checkCriticalResources() {
            const resources = [
                '/static/css/libs/bootstrap/bootstrap.min.css',
                '/static/css/libs/bootstrap-icons/bootstrap-icons.min.css',
                '/static/js/libs/bootstrap/bootstrap.bundle.min.js',
                '/static/js/libs/jquery/jquery.min.js'
            ];
            
            const results = await Promise.all(resources.map(checkResource));
            const allAvailable = results.every(result => result);
            
            if (!allAvailable) {
                console.warn('⚠️ 部分关键资源无法访问，系统可能无法正常工作');
                showOfflineWarning();
            }
        }
        
        // 显示离线警告
        function showOfflineWarning() {
            const warningDiv = document.createElement('div');
            warningDiv.className = 'alert alert-warning alert-dismissible fade show';
            warningDiv.innerHTML = `
                <strong>警告：</strong>系统检测到部分资源无法访问。
                请确保所有静态资源文件已正确放置，并检查网络连接。
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="关闭"></button>
            `;
            
            const mainElement = document.querySelector('main');
            if (mainElement && mainElement.firstChild) {
                mainElement.insertBefore(warningDiv, mainElement.firstChild);
            }
        }
        
        // 初始化
        document.addEventListener('DOMContentLoaded', function() {
            checkCriticalResources();
        });
    })();
    