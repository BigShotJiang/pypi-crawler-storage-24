/**
 * Prism代码高亮库的自动初始化 (离线模式支持)
 */
document.addEventListener('DOMContentLoaded', function() {
    // 配置Prism自动加载器 (如果可用)
    if (window.Prism && Prism.plugins && Prism.plugins.autoloader) {
        Prism.plugins.autoloader.languages_path = '/static/js/libs/prism/components/';
    }
    
    // 如果没有autoloader插件，手动加载常用语言支持
    if (!window.Prism || !Prism.plugins || !Prism.plugins.autoloader) {
        var languages = [
            'markup', 'clike', 'javascript', 'python', 
            'java', 'c', 'cpp', 'css', 'sql', 'json'
        ];
        
        // 依次加载每种语言支持
        languages.forEach(function(lang) {
            var script = document.createElement('script');
            script.src = '/static/js/libs/prism/components/prism-' + lang + '.min.js';
            script.async = true;
            document.head.appendChild(script);
        });
    }
    
    // 初始化所有pre>code元素
    setTimeout(function() {
        if (typeof Prism !== 'undefined') {
            // 查找页面上所有没有高亮处理的代码块
            var codeBlocks = document.querySelectorAll('pre>code:not(.prism-highlighted)');
            
            if (codeBlocks.length > 0) {
                codeBlocks.forEach(function(block) {
                    // 添加标记，避免重复处理
                    block.classList.add('prism-highlighted');
                    
                    // 确保代码块有语言类
                    if (!block.className.match(/language-\w+/)) {
                        // 如果没有语言类，默认设置为text
                        block.classList.add('language-text');
                    }
                    
                    // 手动触发高亮
                    Prism.highlightElement(block);
                });
                
                console.log('代码高亮初始化完成, 处理了 ' + codeBlocks.length + ' 个代码块');
            }
        } else {
            console.warn('⚠️ Prism库未正确加载，代码高亮功能不可用');
        }
    }, 1000); // 给予足够时间加载所有语言组件
}); 