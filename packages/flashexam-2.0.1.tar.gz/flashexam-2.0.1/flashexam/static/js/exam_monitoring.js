/**
 * FlashExam 考试监控系统
 * 处理外部程序检测和自动交卷功能
 */

class ExamMonitoring {
    constructor() {
        // 监控状态
        this.state = {
            isActive: false,                // 是否激活监控
            isSubmitted: false,             // 考试是否已提交
            leaveCount: 0,                  // 离开页面次数
            warningThreshold: 3,            // 警告阈值
            autoSubmitThreshold: 5,         // 自动提交阈值
            lastWarningTime: 0,             // 上次警告时间
            monitoringInterval: null,       // 监控定时器
            warningShown: false             // 警告是否已显示
        };
        
        // 绑定方法到实例
        this.handleVisibilityChange = this.handleVisibilityChange.bind(this);
        this.handleSubmitExam = this.handleSubmitExam.bind(this);
        
        // 初始化
        this.init();
    }
    
    init() {
        console.log('初始化考试监控系统...');
        
        // 检查 Session Storage 中是否有状态
        this.loadState();
        
        // 如果考试已提交，不激活监控
        if (this.state.isSubmitted) {
            console.log('考试已提交，不启用监控');
            return;
        }
        
        // 绑定事件监听器
        this.bindEvents();
        
        // 激活监控
        this.activateMonitoring();
    }
    
    // 激活监控
    activateMonitoring() {
        if (this.state.isSubmitted) {
            console.log('考试已提交，不启用监控');
            return;
        }
        
        this.state.isActive = true;
        this.saveState();
        console.log('监控系统已激活');
    }
    
    // 停止监控
    deactivateMonitoring() {
        this.state.isActive = false;
        this.saveState();
        console.log('监控系统已停用');
        
        // 移除事件监听器
        document.removeEventListener('visibilitychange', this.handleVisibilityChange);
        
        // 清除定时器
        if (this.state.monitoringInterval) {
            clearInterval(this.state.monitoringInterval);
            this.state.monitoringInterval = null;
        }
    }
    
    // 绑定事件
    bindEvents() {
        // 监听页面可见性变化
        document.addEventListener('visibilitychange', this.handleVisibilityChange);
        
        // 监听考试提交
        const submitButton = document.getElementById('confirmSubmit');
        if (submitButton) {
            submitButton.addEventListener('click', this.handleSubmitExam);
        }
    }
    
    // 处理页面可见性变化
    handleVisibilityChange() {
        if (!this.state.isActive || this.state.isSubmitted) return;
        
        if (document.hidden) {
            // 用户离开页面
            this.state.leaveCount++;
            this.saveState();
            console.log(`用户离开页面，当前次数: ${this.state.leaveCount}`);
            
            // 达到警告阈值
            if (this.state.leaveCount >= this.state.warningThreshold && !this.state.warningShown) {
                this.showLeaveWarning();
            }
            
            // 达到自动提交阈值
            if (this.state.leaveCount >= this.state.autoSubmitThreshold) {
                this.triggerAutoSubmit();
            }
        }
    }
    
    // 显示离开警告
    showLeaveWarning() {
        if (this.state.isSubmitted) return;
        
        const now = Date.now();
        // 确保警告至少间隔30秒
        if (now - this.state.lastWarningTime < 30000) return;
        
        this.state.lastWarningTime = now;
        this.state.warningShown = true;
        this.saveState();
        
        // 使用 FlashExam 全局消息系统显示警告
        if (window.FlashExam && window.FlashExam.showMessage) {
            window.FlashExam.showMessage(
                '您已多次离开考试页面，考试将被自动提交！', 
                'warning'
            );
        } else {
            alert('警告：您已多次离开考试页面，考试将被自动提交！');
        }
    }
    
    // 触发自动提交
    triggerAutoSubmit() {
        if (this.state.isSubmitted) return;
        
        console.log('触发自动提交');
        
        // 标记为已提交
        this.handleSubmitExam();
        
        // 调用提交函数
        if (typeof submitExam === 'function') {
            submitExam();
        }
    }
    
    // 处理考试提交
    handleSubmitExam() {
        console.log('考试已提交，停用监控');
        this.state.isSubmitted = true;
        this.state.isActive = false;
        this.saveState();
        this.deactivateMonitoring();
    }
    
    // 保存状态到 Session Storage
    saveState() {
        try {
            sessionStorage.setItem('exam_monitoring_state', JSON.stringify(this.state));
        } catch (e) {
            console.error('保存监控状态失败:', e);
        }
    }
    
    // 从 Session Storage 加载状态
    loadState() {
        try {
            const savedState = sessionStorage.getItem('exam_monitoring_state');
            if (savedState) {
                const parsedState = JSON.parse(savedState);
                // 合并状态，保留默认值
                this.state = { ...this.state, ...parsedState };
                console.log('已加载监控状态:', this.state);
            }
        } catch (e) {
            console.error('加载监控状态失败:', e);
        }
    }
}

// 初始化监控
document.addEventListener('DOMContentLoaded', function() {
    // 检查是否在考试页面
    const isExamPage = document.getElementById('examForm') || 
                       document.querySelector('.exam-container');
    
    if (isExamPage) {
        console.log('检测到考试页面，初始化监控');
        window.examMonitoring = new ExamMonitoring();
    }
});

// 导出全局函数，用于手动提交考试
window.examSubmitted = function() {
    if (window.examMonitoring) {
        window.examMonitoring.handleSubmitExam();
    }
}; 