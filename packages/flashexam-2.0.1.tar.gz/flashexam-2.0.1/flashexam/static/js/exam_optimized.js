/**
 * FlashExam 优化版前端JavaScript
 * 解决答案保存和并发问题
 */

class ExamOptimized {
    constructor(examId, studentId, resultId) {
        this.examId = examId;
        this.studentId = studentId;
        this.resultId = resultId;
        this.isOptimized = true;
        
        // 配置参数
        this.config = {
            autoSaveInterval: 10000,  // 10秒自动保存
            retryDelay: 2000,         // 重试延迟
            maxRetries: 3,            // 最大重试次数
            debounceDelay: 1000,      // 防抖延迟
            batchSize: 50             // 批量处理大小
        };
        
        // 状态管理
        this.state = {
            lastSaved: new Date(),
            saveInProgress: false,
            hasUnsavedChanges: false,
            connectionStatus: 'online',
            retryCount: 0
        };
        
        // 答案缓存
        this.answersCache = new Map();
        this.pendingAnswers = new Map();
        
        // 定时器
        this.timers = {
            autoSave: null,
            debounce: null,
            statusCheck: null
        };
        
        this.init();
    }
    
    init() {
        console.log('初始化优化版考试系统...', {
            examId: this.examId,
            studentId: this.studentId,
            resultId: this.resultId
        });
        
        this.loadExistingAnswers();
        this.setupEventListeners();
        this.startAutoSave();
        this.startStatusMonitoring();
        this.setupBeforeUnload();
        this.updateUI();
    }
    
    // ==================== 答案管理 ====================
    
    loadExistingAnswers() {
        // 从页面加载已有答案
        const formElements = document.querySelectorAll('input[name^="question_"], textarea[name^="question_"], select[name^="question_"]');
        
        formElements.forEach(element => {
            const questionId = element.name;
            let value = '';
            
            if (element.type === 'radio' || element.type === 'checkbox') {
                if (element.checked) {
                    value = element.value;
                }
            } else {
                value = element.value;
            }
            
            if (value) {
                this.answersCache.set(questionId, value);
            }
        });
        
        console.log(`加载了 ${this.answersCache.size} 个已有答案`);
    }
    
    updateAnswer(questionId, value) {
        // 更新答案缓存
        if (value && value.trim()) {
            this.answersCache.set(questionId, value.trim());
        } else {
            this.answersCache.delete(questionId);
        }
        
        // 标记为有未保存更改
        this.state.hasUnsavedChanges = true;
        
        // 防抖保存
        this.debouncedSave();
        
        // 更新UI状态
        this.updateUI();
    }
    
    getAnswers() {
        const answers = {};
        this.answersCache.forEach((value, key) => {
            answers[key] = value;
        });
        return answers;
    }
    
    // ==================== 自动保存 ====================
    
    debouncedSave() {
        // 清除之前的防抖定时器
        if (this.timers.debounce) {
            clearTimeout(this.timers.debounce);
        }
        
        // 设置新的防抖定时器
        this.timers.debounce = setTimeout(() => {
            this.saveProgress();
        }, this.config.debounceDelay);
    }
    
    startAutoSave() {
        this.timers.autoSave = setInterval(() => {
            if (this.state.hasUnsavedChanges && !this.state.saveInProgress) {
                this.saveProgress();
            }
        }, this.config.autoSaveInterval);
        
        console.log(`自动保存已启动，间隔 ${this.config.autoSaveInterval}ms`);
    }
    
    async saveProgress(force = false) {
        if (this.state.saveInProgress && !force) {
            console.log('保存正在进行中，跳过此次保存');
            return;
        }
        
        if (!this.state.hasUnsavedChanges && !force) {
            console.log('没有未保存的更改，跳过保存');
            return;
        }
        
        this.state.saveInProgress = true;
        this.updateUI();
        
        const answers = this.getAnswers();
        const saveData = {
            ...answers,
            timestamp: new Date().toISOString(),
            source: 'auto_save'
        };
        
        try {
            console.log('开始保存进度...', {
                answerCount: Object.keys(answers).length,
                timestamp: saveData.timestamp
            });
            
            const response = await this.makeRequest(`/student_opt/exam/${this.examId}/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(saveData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.state.lastSaved = new Date();
                this.state.hasUnsavedChanges = false;
                this.state.retryCount = 0;
                this.state.connectionStatus = 'online';
                
                console.log('保存成功:', result);
                this.showStatusMessage('进度已保存', 'success');
            } else {
                throw new Error(result.message || '保存失败');
            }
            
        } catch (error) {
            console.error('保存失败:', error);
            this.handleSaveError(error);
        } finally {
            this.state.saveInProgress = false;
            this.updateUI();
        }
    }
    
    // ==================== 错误处理和重试 ====================
    
    async handleSaveError(error) {
        this.state.retryCount++;
        this.state.connectionStatus = 'error';
        
        if (this.state.retryCount <= this.config.maxRetries) {
            console.log(`保存失败，将在 ${this.config.retryDelay}ms 后重试 (${this.state.retryCount}/${this.config.maxRetries})`);
            
            this.showStatusMessage(`保存失败，正在重试... (${this.state.retryCount}/${this.config.maxRetries})`, 'warning');
            
            setTimeout(() => {
                this.saveProgress(true);
            }, this.config.retryDelay);
        } else {
            console.error('保存失败，已达到最大重试次数');
            this.showStatusMessage('保存失败，请检查网络连接', 'error');
            
            // 将答案保存到本地存储作为备份
            this.saveToLocalStorage();
        }
    }
    
    // ==================== 本地存储备份 ====================
    
    saveToLocalStorage() {
        try {
            const backupData = {
                examId: this.examId,
                studentId: this.studentId,
                answers: this.getAnswers(),
                timestamp: new Date().toISOString()
            };
            
            localStorage.setItem(`exam_backup_${this.examId}_${this.studentId}`, JSON.stringify(backupData));
            console.log('答案已备份到本地存储');
            this.showStatusMessage('答案已备份到本地', 'info');
        } catch (error) {
            console.error('本地备份失败:', error);
        }
    }
    
    loadFromLocalStorage() {
        try {
            const backupKey = `exam_backup_${this.examId}_${this.studentId}`;
            const backupData = localStorage.getItem(backupKey);
            
            if (backupData) {
                const data = JSON.parse(backupData);
                console.log('发现本地备份:', data);
                
                // 询问用户是否恢复
                if (confirm('发现本地备份的答案，是否恢复？')) {
                    this.restoreAnswers(data.answers);
                    localStorage.removeItem(backupKey);
                }
            }
        } catch (error) {
            console.error('加载本地备份失败:', error);
        }
    }
    
    restoreAnswers(answers) {
        Object.entries(answers).forEach(([questionId, value]) => {
            const element = document.querySelector(`[name="${questionId}"]`);
            if (element) {
                if (element.type === 'radio') {
                    const radio = document.querySelector(`[name="${questionId}"][value="${value}"]`);
                    if (radio) radio.checked = true;
                } else if (element.type === 'checkbox') {
                    element.checked = value === element.value;
                } else {
                    element.value = value;
                }
                
                this.answersCache.set(questionId, value);
            }
        });
        
        this.state.hasUnsavedChanges = true;
        this.updateUI();
        this.showStatusMessage('答案已恢复', 'success');
    }
    
    // ==================== 网络请求 ====================
    
    async makeRequest(url, options = {}) {
        const defaultOptions = {
            timeout: 15000,  // 15秒超时
            ...options
        };
        
        // 创建AbortController用于超时控制
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), defaultOptions.timeout);
        
        try {
            const response = await fetch(url, {
                ...defaultOptions,
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            return response;
        } catch (error) {
            clearTimeout(timeoutId);
            throw error;
        }
    }
    
    // ==================== 状态监控 ====================
    
    startStatusMonitoring() {
        this.timers.statusCheck = setInterval(() => {
            this.checkConnectionStatus();
        }, 30000);  // 每30秒检查一次
    }
    
    async checkConnectionStatus() {
        try {
            const response = await this.makeRequest('/health', {
                method: 'GET',
                timeout: 5000
            });
            
            const result = await response.json();
            
            if (result.status === 'healthy') {
                if (this.state.connectionStatus === 'error') {
                    this.state.connectionStatus = 'online';
                    this.showStatusMessage('网络连接已恢复', 'success');
                    
                    // 如果有未保存的更改，立即保存
                    if (this.state.hasUnsavedChanges) {
                        this.saveProgress();
                    }
                }
            }
        } catch (error) {
            if (this.state.connectionStatus === 'online') {
                this.state.connectionStatus = 'error';
                this.showStatusMessage('网络连接异常', 'warning');
            }
        }
    }
    
    // ==================== 事件监听 ====================
    
    setupEventListeners() {
        // 监听答案输入
        document.addEventListener('change', (e) => {
            if (e.target.name && e.target.name.startsWith('question_')) {
                this.handleAnswerChange(e);
            }
        });
        
        document.addEventListener('input', (e) => {
            if (e.target.name && e.target.name.startsWith('question_')) {
                this.handleAnswerChange(e);
            }
        });
        
        // 监听页面可见性变化
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && this.state.hasUnsavedChanges) {
                this.saveProgress();
            }
        });
        
        // 监听网络状态变化
        window.addEventListener('online', () => {
            this.state.connectionStatus = 'online';
            this.showStatusMessage('网络已连接', 'success');
            if (this.state.hasUnsavedChanges) {
                this.saveProgress();
            }
        });
        
        window.addEventListener('offline', () => {
            this.state.connectionStatus = 'offline';
            this.showStatusMessage('网络已断开', 'warning');
        });
    }
    
    handleAnswerChange(event) {
        const questionId = event.target.name;
        let value = '';
        
        if (event.target.type === 'radio' || event.target.type === 'checkbox') {
            if (event.target.checked) {
                value = event.target.value;
            } else {
                // 对于取消选中的情况，需要检查是否还有其他选中的选项
                const checkedElements = document.querySelectorAll(`[name="${questionId}"]:checked`);
                if (checkedElements.length > 0) {
                    value = checkedElements[0].value;
                }
            }
        } else {
            value = event.target.value;
        }
        
        this.updateAnswer(questionId, value);
    }
    
    setupBeforeUnload() {
        window.addEventListener('beforeunload', (e) => {
            if (this.state.hasUnsavedChanges) {
                // 尝试同步保存
                navigator.sendBeacon(`/student_opt/exam/${this.examId}/save`, 
                    JSON.stringify(this.getAnswers()));
                
                // 显示确认对话框
                const message = '您有未保存的答案，确定要离开吗？';
                e.returnValue = message;
                return message;
            }
        });
    }
    
    // ==================== UI 更新 ====================
    
    updateUI() {
        this.updateStatusIndicator();
        this.updateSaveButton();
        this.updateAnswerCount();
    }
    
    updateStatusIndicator() {
        const indicator = document.getElementById('status-indicator');
        if (!indicator) return;
        
        let status = '';
        let className = '';
        
        if (this.state.saveInProgress) {
            status = '正在保存...';
            className = 'saving';
        } else if (this.state.hasUnsavedChanges) {
            status = '有未保存的更改';
            className = 'unsaved';
        } else {
            const timeAgo = Math.floor((new Date() - this.state.lastSaved) / 1000);
            status = `已保存 (${timeAgo}秒前)`;
            className = 'saved';
        }
        
        indicator.textContent = status;
        indicator.className = `status-indicator ${className}`;
    }
    
    updateSaveButton() {
        const saveBtn = document.getElementById('save-progress-btn');
        if (!saveBtn) return;
        
        saveBtn.disabled = this.state.saveInProgress;
        saveBtn.textContent = this.state.saveInProgress ? '保存中...' : '保存进度';
    }
    
    updateAnswerCount() {
        const counter = document.getElementById('answer-counter');
        if (!counter) return;
        
        const totalQuestions = document.querySelectorAll('[name^="question_"]').length;
        const answeredQuestions = this.answersCache.size;
        
        counter.textContent = `已答题: ${answeredQuestions}/${totalQuestions}`;
    }
    
    showStatusMessage(message, type = 'info') {
        // 创建状态消息元素
        const messageEl = document.createElement('div');
        messageEl.className = `status-message ${type}`;
        messageEl.textContent = message;
        
        // 添加到页面
        document.body.appendChild(messageEl);
        
        // 自动消失
        setTimeout(() => {
            messageEl.remove();
        }, 3000);
        
        console.log(`状态消息 [${type}]:`, message);
    }
    
    // ==================== 考试提交 ====================
    
    async submitExam() {
        // 最后一次保存
        await this.saveProgress(true);
        
        // 清理定时器
        this.cleanup();
        
        // 提交考试
        const formData = new FormData();
        this.answersCache.forEach((value, key) => {
            formData.append(key, value);
        });
        
        try {
            const response = await this.makeRequest(`/student_opt/exam/${this.examId}/submit`, {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                // 清理本地存储
                localStorage.removeItem(`exam_backup_${this.examId}_${this.studentId}`);
                
                // 显示结果
                alert(`考试提交成功！\n得分：${result.score}/${result.total_score} (${result.percentage}%)`);
                
                // 跳转到结果页面
                window.location.href = `/student_opt/exam/${this.examId}/result`;
            } else {
                throw new Error(result.message || '提交失败');
            }
        } catch (error) {
            console.error('提交考试失败:', error);
            alert('提交失败：' + error.message);
        }
    }
    
    // ==================== 清理 ====================
    
    cleanup() {
        // 清理所有定时器
        Object.values(this.timers).forEach(timer => {
            if (timer) clearInterval(timer);
        });
        
        console.log('优化版考试系统已清理');
    }
}

// ==================== 全局函数 ====================

let examOptimized = null;

function initOptimizedExam(examId, studentId, resultId) {
    console.log('初始化优化版考试系统');
    examOptimized = new ExamOptimized(examId, studentId, resultId);
    
    // 检查本地备份
    examOptimized.loadFromLocalStorage();
    
    return examOptimized;
}

function saveProgress() {
    if (examOptimized) {
        examOptimized.saveProgress(true);
    }
}

function submitOptimizedExam() {
    if (examOptimized && confirm('确定要提交考试吗？提交后将无法修改答案。')) {
        examOptimized.submitExam();
    }
}

// 页面卸载时清理
window.addEventListener('unload', () => {
    if (examOptimized) {
        examOptimized.cleanup();
    }
});

// 导出给全局使用
window.ExamOptimized = ExamOptimized;
window.initOptimizedExam = initOptimizedExam;
window.saveProgress = saveProgress;
window.submitOptimizedExam = submitOptimizedExam; 