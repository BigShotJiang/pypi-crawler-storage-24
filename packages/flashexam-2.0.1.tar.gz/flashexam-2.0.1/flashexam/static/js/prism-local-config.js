
// Prism.js 本地配置
window.Prism = window.Prism || {};
window.Prism.plugins = window.Prism.plugins || {};

// 设置autoloader使用本地路径
if (window.Prism.plugins.autoloader) {
    window.Prism.plugins.autoloader.languages_path = '/static/js/libs/prism/components/';
}

// 配置Prism在加载前设置路径
document.addEventListener('DOMContentLoaded', function() {
    if (typeof Prism !== 'undefined' && Prism.plugins && Prism.plugins.autoloader) {
        Prism.plugins.autoloader.languages_path = '/static/js/libs/prism/components/';
    }
});
