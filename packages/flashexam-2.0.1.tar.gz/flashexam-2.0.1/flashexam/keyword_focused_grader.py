#!/usr/bin/env python3
"""
关键词导向评分器 - 基于关键词匹配的评分模块
"""

import re
import jieba
from typing import Dict, List, Any, Optional


class KeywordFocusedGrader:
    """关键词导向评分器"""
    
    def __init__(self):
        self.name = "KeywordFocusedGrader"
        # 停用词列表
        self.stop_words = {'的', '了', '在', '是', '有', '和', '与', '或', '但', '而', '因为', '所以', '如果', '那么', '这', '那', '就', '都', '也', '还', '不', '很', '非常'}
    
    def extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        if not text:
            return []
        
        # 使用jieba分词
        words = jieba.lcut(text)
        
        # 过滤停用词和短词
        keywords = [word for word in words if len(word) > 1 and word not in self.stop_words]
        
        return keywords
    
    def grade(self, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """关键词匹配评分"""
        if not student_answer or not student_answer.strip():
            return {
                'score': 0.0,
                'confidence': 1.0,
                'feedback': '答案为空',
                'method': self.name,
                'details': {'matched_keywords': [], 'total_keywords': 0}
            }
        
        # 提取关键词
        student_keywords = set(self.extract_keywords(student_answer.lower()))
        reference_keywords = set(self.extract_keywords(reference_answer.lower()))
        
        if not reference_keywords:
            return {
                'score': max_score * 0.5,
                'confidence': 0.3,
                'feedback': '参考答案无关键词，给予基础分',
                'method': self.name,
                'details': {'matched_keywords': [], 'total_keywords': 0}
            }
        
        # 计算匹配度
        matched_keywords = student_keywords.intersection(reference_keywords)
        match_ratio = len(matched_keywords) / len(reference_keywords)
        
        # 计算分数
        score = max_score * match_ratio
        
        # 调整置信度
        confidence = 0.8 if match_ratio > 0.5 else 0.6
        
        feedback = f"关键词匹配度: {match_ratio:.2%}, 匹配关键词: {', '.join(list(matched_keywords)[:10])}"
        
        return {
            'score': round(score, 2),
            'confidence': confidence,
            'feedback': feedback,
            'method': self.name,
            'details': {
                'matched_keywords': list(matched_keywords),
                'total_keywords': len(reference_keywords),
                'match_ratio': match_ratio
            }
        }


def get_keyword_focused_grader():
    """获取关键词导向评分器实例"""
    return KeywordFocusedGrader() 