import redis
import os
import time
import json
import threading
from collections import deque, defaultdict
from typing import Optional, Dict, Any, List

class LocalMemoryStore:
    """High-performance In-Memory Queue and KV Store with AOF Persistence.
    Mimics Redis behavior using Python internal structures + Append Only File.
    """
    def __init__(self, aof_path: str = None):
        if aof_path is None:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            storage_dir = os.path.join(base_dir, '..', 'storage')
            os.makedirs(storage_dir, exist_ok=True)
            self.aof_path = os.path.join(storage_dir, 'local_redis.aof')
        else:
            self.aof_path = aof_path
            
        self.kv_store = {}
        self.queue_store = defaultdict(deque)
        self.lock = threading.Lock()
        
        # Open AOF file
        self._recover_from_aof()
        self.aof_file = open(self.aof_path, 'a', encoding='utf-8')
        
        print(f"[LOCAL_STORE] Initialized in-memory cache with AOF at {self.aof_path}")

    def _recover_from_aof(self):
        """Replay AOF log to restore state"""
        if not os.path.exists(self.aof_path):
            return

        print("[LOCAL_STORE] Recovering from AOF...")
        try:
            with open(self.aof_path, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        cmd = json.loads(line)
                        op = cmd[0]
                        if op == 'hset':
                            key, mapping = cmd[1], cmd[2]
                            if key not in self.kv_store: self.kv_store[key] = {}
                            self.kv_store[key].update(mapping)
                        elif op == 'rpush':
                            key, values = cmd[1], cmd[2]
                            self.queue_store[key].extend(values)
                        elif op == 'lpop':
                            key, count = cmd[1], cmd[2]
                            for _ in range(count):
                                if self.queue_store[key]:
                                    self.queue_store[key].popleft()
                    except Exception:
                        continue
        except Exception as e:
            print(f"[LOCAL_STORE] AOF Recovery warning: {e}")

    def _write_aof(self, cmd: List[Any]):
        """Write command to AOF"""
        try:
            self.aof_file.write(json.dumps(cmd, ensure_ascii=False) + '\n')
            self.aof_file.flush()
        except Exception as e:
            print(f"[LOCAL_STORE] AOF Write error: {e}")

    def hset(self, name: str, mapping: Dict[str, Any]) -> bool:
        with self.lock:
            # Normalize values
            safe_mapping = {k: (json.dumps(v) if isinstance(v, (dict, list)) else str(v)) 
                           for k, v in mapping.items()}
            
            # Persist
            self._write_aof(['hset', name, safe_mapping])
            
            # Update Memory
            if name not in self.kv_store:
                self.kv_store[name] = {}
            self.kv_store[name].update(safe_mapping)
            return True

    def hgetall(self, name: str) -> Dict[str, str]:
        with self.lock:
            return self.kv_store.get(name, {}).copy()

    def rpush(self, name: str, *values) -> bool:
        with self.lock:
            # Normalize
            safe_values = [(json.dumps(v) if isinstance(v, (dict, list)) else str(v)) for v in values]
            
            # Persist
            self._write_aof(['rpush', name, safe_values])
            
            # Update Memory
            self.queue_store[name].extend(safe_values)
            return True

    def lpop_batch(self, name: str, count: int = 1) -> List[str]:
        with self.lock:
            if not self.queue_store[name]:
                return []
            
            results = []
            for _ in range(count):
                if not self.queue_store[name]:
                    break
                results.append(self.queue_store[name].popleft())
            
            if results:
                # Record the pop in AOF so replay knows these are gone
                # Alternatively, we could just not record LPOP and let replay restore them, 
                # but then we might re-process items on crash. 
                # Ideally, we record LPOP.
                self._write_aof(['lpop', name, len(results)])
            
            return results

class RedisManager:
    """Redis connection manager with pooling and fallback support"""
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(RedisManager, cls).__new__(cls)
                    cls._instance._init_redis()
        return cls._instance

    def _init_redis(self):
        """Initialize Redis connection pool"""
        self.host = os.environ.get('REDIS_HOST', 'localhost')
        self.port = int(os.environ.get('REDIS_PORT', 6379))
        self.db = int(os.environ.get('REDIS_DB', 0))
        self.password = os.environ.get('REDIS_PASSWORD', None)
        self.use_local_fallback = True
        self.local_store = None
        
        try:
            pool = redis.ConnectionPool(
                host=self.host,
                port=self.port,
                db=self.db,
                password=self.password,
                decode_responses=True,  # Automatically decode bytes to strings
                socket_timeout=2,       # Fast fail
                socket_connect_timeout=2,
                max_connections=50
            )
            self.client = redis.Redis(connection_pool=pool)
            self.is_connected = self._check_connection()
            if self.is_connected:
                print(f"[REDIS] Successfully connected to {self.host}:{self.port}")
            else:
                print(f"[REDIS] Failed to connect to {self.host}:{self.port}")
                self._init_local_store()
        except Exception as e:
            print(f"[REDIS] Initialization error: {e}")
            self.client = None
            self.is_connected = False
            self._init_local_store()

    def _init_local_store(self):
        """Initialize local In-Memory store fallback"""
        if self.use_local_fallback:
            print("[REDIS] Switching to Local In-Memory Store fallback...")
            try:
                self.local_store = LocalMemoryStore()
                self.client = self.local_store # Duck typing
                self.is_connected = True # Treat as connected
            except Exception as e:
                print(f"[REDIS] Failed to init local store: {e}")

    def _check_connection(self) -> bool:
        """Check if Redis is reachable"""
        try:
            return self.client.ping()
        except Exception:
            return False

    def get_client(self) -> Optional[redis.Redis]:
        """Get the Redis client if connected"""
        if not self.is_connected:
            return None
        return self.client

    def is_available(self) -> bool:
        return self.is_connected

    # Helper methods for common operations
    def hset(self, name: str, mapping: Dict[str, Any]) -> bool:
        if not self.is_available(): return False
        try:
            # Check if it's the local store
            if self.local_store:
                return self.local_store.hset(name, mapping)
            
            # Real Redis
            safe_mapping = {k: (json.dumps(v) if isinstance(v, (dict, list)) else str(v)) 
                           for k, v in mapping.items()}
            self.client.hset(name, mapping=safe_mapping)
            return True
        except Exception as e:
            print(f"[REDIS] HSET error: {e}")
            return False

    def hgetall(self, name: str) -> Dict[str, str]:
        if not self.is_available(): return {}
        try:
            if self.local_store:
                return self.local_store.hgetall(name)
            return self.client.hgetall(name)
        except Exception as e:
            print(f"[REDIS] HGETALL error: {e}")
            return {}

    def rpush(self, name: str, *values) -> bool:
        if not self.is_available(): return False
        try:
            if self.local_store:
                return self.local_store.rpush(name, *values)
            self.client.rpush(name, *values)
            return True
        except Exception as e:
            print(f"[REDIS] RPUSH error: {e}")
            return False

    def lpop_batch(self, name: str, count: int = 1) -> List[str]:
        if not self.is_available(): return []
        try:
            if self.local_store:
                return self.local_store.lpop_batch(name, count)
            
            # Use pipeline to pop multiple items
            pipe = self.client.pipeline()
            pipe.lrange(name, 0, count - 1)
            pipe.ltrim(name, count, -1)
            results = pipe.execute()
            return results[0] if results else []
        except Exception as e:
            print(f"[REDIS] LPOP BATCH error: {e}")
            return []
