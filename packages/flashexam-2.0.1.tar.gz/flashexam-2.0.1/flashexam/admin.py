"""
管理员管理模块
提供教师账户管理和系统管理功能
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
import os
from datetime import datetime

from .database import Database

admin_bp = Blueprint('admin', __name__)

def require_admin():
    """检查是否为管理员（教师角色）"""
    if not current_user.is_authenticated or not current_user.is_teacher():
        return False
    return True

@admin_bp.route('/')
@login_required
def index():
    """管理面板首页"""
    if not require_admin():
        flash('需要管理员权限', 'error')
        return redirect(url_for('auth.login'))
    
    db = Database()
    
    stats = {
        'total_students': len(db.get_all_students()),
        'total_exams': len(db.get_exams()),
        'active_exams': len([e for e in db.get_exams() if e.is_active]),
        'total_questions': len(db.get_questions())
    }
    
    return render_template('admin/index.html', stats=stats)

@admin_bp.route('/teachers')
@login_required
def teachers():
    """教师账户列表"""
    if not require_admin():
        return jsonify({'success': False, 'message': '需要管理员权限'}), 403
    
    db = Database()
    
    return render_template('admin/teachers.html')

@admin_bp.route('/teachers/add', methods=['POST'])
@login_required
def add_teacher():
    """添加教师账户"""
    if not require_admin():
        return jsonify({'success': False, 'message': '需要管理员权限'}), 403
    
    try:
        data = request.get_json() if request.is_json else request.form
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        name = data.get('name', '').strip()
        email = data.get('email', '').strip()
        
        if not all([username, password, name]):
            return jsonify({'success': False, 'message': '请填写所有必填字段'}), 400
        
        if len(password) < 6:
            return jsonify({'success': False, 'message': '密码长度至少6位'}), 400
        
        db = Database()
        
        if db.get_teacher_info(username):
            return jsonify({'success': False, 'message': '用户名已存在'}), 400
        
        success = db.set_teacher_password(username, password, name, email)
        
        if success:
            return jsonify({'success': True, 'message': '教师账户添加成功'})
        else:
            return jsonify({'success': False, 'message': '添加失败，请重试'}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/teachers/<username>/password', methods=['PUT'])
@login_required
def update_teacher_password(username):
    """更新教师密码"""
    if not require_admin():
        return jsonify({'success': False, 'message': '需要管理员权限'}), 403
    
    try:
        data = request.get_json()
        new_password = data.get('new_password', '').strip()
        
        if not new_password:
            return jsonify({'success': False, 'message': '新密码不能为空'}), 400
        
        if len(new_password) < 6:
            return jsonify({'success': False, 'message': '密码长度至少6位'}), 400
        
        db = Database()
        
        if not db.get_teacher_info(username):
            return jsonify({'success': False, 'message': '用户不存在'}), 404
        
        success = db.update_teacher_password(username, new_password)
        
        if success:
            return jsonify({'success': True, 'message': '密码更新成功'})
        else:
            return jsonify({'success': False, 'message': '更新失败，请重试'}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/students')
@login_required
def manage_students():
    """学生管理页面"""
    if not require_admin():
        flash('需要管理员权限', 'error')
        return redirect(url_for('auth.login'))
    
    return redirect(url_for('teacher.students'))

@admin_bp.route('/settings')
@login_required
def settings():
    """系统设置"""
    if not require_admin():
        flash('需要管理员权限', 'error')
        return redirect(url_for('auth.login'))
    
    return render_template('admin/settings.html')

@admin_bp.route('/api/teachers')
@login_required
def api_get_teachers():
    """获取教师列表API"""
    if not require_admin():
        return jsonify({'success': False, 'message': '需要管理员权限'}), 403
    
    db = Database()
    
    try:
        db.conn.row_factory = None
        cursor = db.conn.execute('''
            SELECT username, name, email, created_at
            FROM teachers
            ORDER BY created_at DESC
        ''')
        rows = cursor.fetchall()
        
        teachers_list = []
        for row in rows:
            teachers_list.append({
                'username': row[0],
                'name': row[1],
                'email': row[2] or '',
                'created_at': row[3] or ''
            })
        
        return jsonify({
            'success': True,
            'teachers': teachers_list,
            'count': len(teachers_list)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/api/stats')
@login_required
def api_get_stats():
    """获取系统统计API"""
    if not require_admin():
        return jsonify({'success': False, 'message': '需要管理员权限'}), 403
    
    db = Database()
    
    try:
        stats = {
            'total_students': len(db.get_all_students()),
            'total_exams': len(db.get_exams()),
            'active_exams': len([e for e in db.get_exams() if e.is_active]),
            'total_questions': len(db.get_questions()),
            'database_size': os.path.getsize(db.db_path) if hasattr(db, 'db_path') else 0
        }
        
        return jsonify({
            'success': True,
            'stats': stats
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500