#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
新的考试创建API
使用新题目管理系统重构考试创建逻辑
"""

from flask import Blueprint, request, jsonify, render_template
from typing import List, Dict, Any
from database import Database
from models import Exam
from new_question_system import NewQuestionManager, QuestionCategory

class NewExamCreationAPI:
    """新的考试创建API"""
    
    def __init__(self):
        self.db = Database()
        self.question_manager = NewQuestionManager(self.db)
    
    def get_available_questions_new(self) -> Dict[str, Any]:
        """获取可用题目 - 新版本API（修复版）"""
        try:
            print("🔍 获取可用题目（新版本API）...")
            
            # 使用题目管理器获取数据，确保ID一致性
            simple_questions = self.question_manager.get_simple_questions()
            question_groups_data = []
            
            # 获取真实的题目组数据
            for group in self.question_manager.get_question_groups():
                group_questions = self.question_manager.get_questions_by_group(group.id)
                
                group_data = {
                    'group_id': group.id,  # 使用真实的题目组ID
                    'name': group.name,
                    'description': group.description,
                    'material': group.material,
                    'material_preview': group.material[:100] + '...' if len(group.material) > 100 else group.material,
                    'subject': group.subject,
                    'difficulty': group.difficulty,
                    'total_score': group.total_score,
                    'question_count': group.question_count,
                    'estimated_time': group.estimated_time,
                    'question_types': list(set(q.question_type.value for q in group_questions)),
                    'questions': [
                        {
                            'id': q.id,
                            'question_type': q.question_type.value,
                            'question_text': q.question_text[:80] + '...' if len(q.question_text) > 80 else q.question_text,
                            'score': q.score,
                            'group_order': q.group_order
                        } for q in group_questions
                    ]
                }
                question_groups_data.append(group_data)
            
            # 转换简单题目数据
            simple_questions_data = [
                {
                    'id': q.id,
                    'question_type': q.question_type.value,
                    'question_text': q.question_text[:100] + '...' if len(q.question_text) > 100 else q.question_text,
                    'score': q.score,
                    'difficulty': q.difficulty,
                    'subject': q.subject,
                    'estimated_time': q.estimated_time
                } for q in simple_questions if q.is_active
            ]
            
            print(f"  ✅ 简单题目: {len(simple_questions_data)}道")
            print(f"  ✅ 题目组: {len(question_groups_data)}组")
            
            # 计算统计信息
            total_questions = len(simple_questions_data) + sum(g['question_count'] for g in question_groups_data)
            
            return {
                'success': True,
                'simple_questions': simple_questions_data,
                'question_groups': question_groups_data,
                'statistics': {
                    'total_questions': total_questions,
                    'simple_count': len(simple_questions_data),
                    'grouped_count': sum(g['question_count'] for g in question_groups_data),
                    'groups_count': len(question_groups_data),
                    'question_types': {},  # 可以后续完善
                    'subjects': {}         # 可以后续完善
                }
            }
            
        except Exception as e:
            print(f"❌ 获取题目失败: {e}")
            import traceback
            traceback.print_exc()
            return {
                'success': False,
                'error': str(e),
                'simple_questions': [],
                'question_groups': [],
                'statistics': {}
            }
    
    def create_exam_new(self, form_data: Dict[str, Any]) -> Dict[str, Any]:
        """创建考试 - 新版本"""
        try:
            print("🎯 新考试创建API开始处理...")
            
            # 解析基本信息
            title = form_data.get('title', '').strip()
            description = form_data.get('description', '').strip()
            duration_minutes = int(form_data.get('duration_minutes', 60))
            is_active = str(form_data.get('is_active', 'false')).lower() == 'true'
            
            print(f"  考试信息: {title}, 时长: {duration_minutes}分钟")
            
            # 解析题目选择
            simple_question_ids = []
            if 'simple_question_ids' in form_data:
                simple_ids_raw = form_data.get('simple_question_ids')
                if isinstance(simple_ids_raw, list):
                    simple_question_ids = [int(qid) for qid in simple_ids_raw if str(qid).isdigit()]
                elif isinstance(simple_ids_raw, str) and simple_ids_raw.isdigit():
                    simple_question_ids = [int(simple_ids_raw)]
            
            group_ids = []
            if 'group_ids' in form_data:
                group_ids_raw = form_data.get('group_ids')
                if isinstance(group_ids_raw, list):
                    group_ids = [str(gid) for gid in group_ids_raw]
                elif isinstance(group_ids_raw, str):
                    group_ids = [group_ids_raw]
            
            print(f"  选择简单题目ID: {simple_question_ids}")
            print(f"  选择题目组ID: {group_ids}")
            
            # 验证输入
            if not title:
                return {'success': False, 'message': '请输入考试标题'}
            
            if not simple_question_ids and not group_ids:
                return {'success': False, 'message': '请至少选择一道题目或一个题目组'}
            
            # 使用新题目管理器创建选择
            selection = self.question_manager.create_exam_question_selection(
                simple_question_ids=simple_question_ids,
                group_ids=group_ids
            )
            
            print(f"  题目选择结果:")
            print(f"    简单题目: {len(selection['simple_questions'])}道")
            print(f"    题目组: {len(selection['grouped_questions'])}组")
            print(f"    总题目数: {selection['total_questions']}")
            print(f"    总分: {selection['total_score']}")
            print(f"    题目ID列表: {selection['question_ids']}")
            
            if selection['total_questions'] == 0:
                return {'success': False, 'message': '没有找到有效的题目'}
            
            # 创建考试对象
            exam = Exam(
                title=title,
                description=description,
                duration_minutes=duration_minutes,
                total_questions=selection['total_questions'],
                total_score=selection['total_score'],
                is_active=is_active
            )
            
            # 保存考试到数据库
            exam_id = self.db.create_exam_with_questions(exam, selection['question_ids'])
            
            if exam_id and exam_id != -1:
                print(f"✅ 考试创建成功，ID: {exam_id}")
                
                return {
                    'success': True,
                    'message': f'考试"{title}"创建成功',
                    'exam_id': exam_id,
                    'exam_info': {
                        'title': title,
                        'total_questions': selection['total_questions'],
                        'total_score': selection['total_score'],
                        'duration_minutes': duration_minutes,
                        'estimated_time': selection['estimated_time']
                    },
                    'selection_summary': {
                        'simple_questions': len(selection['simple_questions']),
                        'question_groups': len(selection['grouped_questions']),
                        'group_details': [
                            {
                                'group_name': item['group'].name,
                                'question_count': len(item['questions']),
                                'total_score': item['group'].total_score
                            } for item in selection['grouped_questions']
                        ]
                    }
                }
            else:
                return {'success': False, 'message': '考试创建失败，请检查数据库连接'}
                
        except Exception as e:
            print(f"❌ 考试创建失败: {str(e)}")
            import traceback
            traceback.print_exc()
            return {'success': False, 'message': f'创建考试时发生错误: {str(e)}'}

# Flask路由接口
def create_new_exam_routes(app):
    """创建新的考试管理路由"""
    
    exam_api = NewExamCreationAPI()
    
    @app.route('/api/questions/available-new')
    def get_available_questions_new():
        """获取可用题目 - 新版本API"""
        return jsonify(exam_api.get_available_questions_new())
    
    @app.route('/api/exams/create-new', methods=['POST'])
    def create_exam_new():
        """创建考试 - 新版本API"""
        print(f"🎯 接收到新考试创建请求")
        print(f"  请求方法: {request.method}")
        print(f"  Content-Type: {request.content_type}")
        
        # 解析表单数据
        form_data = {}
        
        # 基本信息
        form_data['title'] = request.form.get('title', '').strip()
        form_data['description'] = request.form.get('description', '').strip()
        form_data['duration_minutes'] = request.form.get('duration_minutes', '60')
        form_data['is_active'] = request.form.get('is_active', 'false')
        
        print(f"  基本信息: 标题='{form_data['title']}', 时长={form_data['duration_minutes']}分钟")
        
        # 简单题目ID - 改进处理逻辑
        simple_ids = request.form.getlist('simple_question_ids')
        print(f"  原始简单题目IDs: {simple_ids}")
        
        # 处理可能的数据格式问题
        processed_simple_ids = []
        for sid in simple_ids:
            try:
                if isinstance(sid, str) and sid.strip():
                    processed_simple_ids.append(int(sid.strip()))
                elif isinstance(sid, int):
                    processed_simple_ids.append(sid)
            except (ValueError, TypeError):
                print(f"  ⚠️ 无效的简单题目ID: {sid}")
                
        if processed_simple_ids:
            form_data['simple_question_ids'] = processed_simple_ids
            print(f"  处理后简单题目IDs: {processed_simple_ids}")
        
        # 题目组ID - 改进处理逻辑  
        group_ids = request.form.getlist('group_ids')
        print(f"  原始题目组IDs: {group_ids}")
        
        # 处理可能的数据格式问题
        processed_group_ids = []
        for gid in group_ids:
            if isinstance(gid, str) and gid.strip():
                processed_group_ids.append(gid.strip())
            elif gid:  # 其他非空值
                processed_group_ids.append(str(gid))
                
        if processed_group_ids:
            form_data['group_ids'] = processed_group_ids
            print(f"  处理后题目组IDs: {processed_group_ids}")
        
        print(f"🎯 最终表单数据: {form_data}")
        
        try:
            result = exam_api.create_exam_new(form_data)
            print(f"  API处理结果: {result.get('success', False)}")
            if not result.get('success', False):
                print(f"  错误信息: {result.get('message', '未知错误')}")
            return jsonify(result)
        except Exception as e:
            print(f"❌ API调用异常: {str(e)}")
            import traceback
            traceback.print_exc()
            return jsonify({
                'success': False, 
                'message': f'服务器内部错误: {str(e)}'
            })

def test_new_exam_api():
    """测试新的考试创建API"""
    print("🧪 测试新考试创建API")
    print("=" * 50)
    
    api = NewExamCreationAPI()
    
    # 测试获取题目
    print("\n1️⃣ 测试获取可用题目...")
    questions_data = api.get_available_questions_new()
    
    if questions_data['success']:
        print(f"✅ 获取题目成功")
        print(f"  简单题目: {len(questions_data['simple_questions'])}道")
        print(f"  题目组: {len(questions_data['question_groups'])}组")
        
        # 显示题目组信息
        for i, group in enumerate(questions_data['question_groups'], 1):
            print(f"  题目组{i}: {group['name']} ({group['question_count']}题, {group['total_score']}分)")
    else:
        print(f"❌ 获取题目失败: {questions_data.get('error')}")
        return
    
    # 测试创建考试
    print("\n2️⃣ 测试创建考试...")
    
    # 选择一些题目
    simple_ids = []
    if questions_data['simple_questions']:
        simple_ids = [q['id'] for q in questions_data['simple_questions'][:3]]
    
    group_ids = []
    if questions_data['question_groups']:
        group_ids = [questions_data['question_groups'][0]['group_id']]
    
    test_form_data = {
        'title': '新API测试考试',
        'description': '使用新API创建的测试考试',
        'duration_minutes': '90',
        'is_active': 'true',
        'simple_question_ids': simple_ids,
        'group_ids': group_ids
    }
    
    print(f"  测试数据: {test_form_data}")
    
    result = api.create_exam_new(test_form_data)
    
    if result['success']:
        print(f"✅ 考试创建成功!")
        print(f"  考试ID: {result['exam_id']}")
        print(f"  题目总数: {result['exam_info']['total_questions']}")
        print(f"  总分: {result['exam_info']['total_score']}")
        print(f"  选择简单题目: {result['selection_summary']['simple_questions']}道")
        print(f"  选择题目组: {result['selection_summary']['question_groups']}组")
    else:
        print(f"❌ 考试创建失败: {result['message']}")

if __name__ == "__main__":
    test_new_exam_api() 