#!/usr/bin/env python3
"""
基于Ollama的智能评分系统
支持使用Ollama运行的本地LLM模型进行主观题评分
"""

import os
import re
import json
import logging
import requests
from typing import Dict, List, Any, Optional
from datetime import datetime
import jieba
from difflib import SequenceMatcher

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OllamaIntelligentGrader:
    """基于Ollama的智能评分器"""
    
    def __init__(self, ollama_url: str = "http://localhost:11434", model_name: str = "qwen3:0.6b"):
        """
        初始化Ollama智能评分器
        
        Args:
            ollama_url: Ollama服务地址
            model_name: 使用的模型名称
        """
        self.ollama_url = ollama_url.rstrip('/')
        self.model_name = model_name
        self.timeout = 30  # 请求超时时间
        
        # 检查Ollama服务是否可用
        self.is_available = self._check_ollama_service()
        
        if self.is_available:
            # 检查模型是否可用
            self.is_model_available = self._check_model_availability()
        else:
            self.is_model_available = False
            
        logger.info(f"Ollama评分器初始化: 服务{'可用' if self.is_available else '不可用'}, "
                   f"模型({self.model_name}){'可用' if self.is_model_available else '不可用'}")
    
    def _check_ollama_service(self) -> bool:
        """检查Ollama服务是否运行"""
        try:
            response = requests.get(f"{self.ollama_url}/api/version", timeout=5)
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"Ollama服务检查失败: {e}")
            return False
    
    def _check_model_availability(self) -> bool:
        """检查指定模型是否可用"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get('models', [])
                available_models = [model['name'] for model in models]
                return self.model_name in available_models
            return False
        except Exception as e:
            logger.warning(f"模型可用性检查失败: {e}")
            return False
    
    def get_available_models(self) -> List[str]:
        """获取可用的模型列表"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get('models', [])
                return [model['name'] for model in models]
            return []
        except Exception as e:
            logger.error(f"获取模型列表失败: {e}")
            return []
    
    def _create_grading_prompt(self, question_text: str, reference_answer: str, 
                              student_answer: str, max_score: float) -> str:
        """创建评分提示词"""
        
        prompt = f"""你是一位经验丰富的专业教师，请对以下学生答案进行公正、准确的评分。

题目：{question_text}

标准答案：{reference_answer}

学生答案：{student_answer}

评分要求：
1. 满分：{max_score}分
2. 重点关注答案的正确性、完整性和逻辑性
3. 即使表达方式不同，只要核心概念正确就应该给分
4. 有具体例子或详细说明的答案应该给予适当加分
5. 空答案或完全错误的答案得0分
6. 部分正确的答案应该给予相应比例的分数
7. 请严格按照JSON格式返回结果，不要包含其他内容

请按以下JSON格式输出评分结果：
{{
    "score": 分数（0到{max_score}之间的数字，可以是小数），
    "confidence": 置信度（0到1之间的小数），
    "feedback": "评分理由和建议",
    "reasoning": "详细的评分分析"
}}

请直接返回JSON，不要包含任何其他文字："""
        
        return prompt
    
    def _call_ollama_api(self, prompt: str) -> str:
        """调用Ollama API - 改进错误处理版本"""
        try:
            # 首先检查服务可用性
            if not self._check_ollama_service():
                logger.warning("Ollama服务不可用，将使用备用评分算法")
                return ""
            
            data = {
                "model": self.model_name,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.1,  # 降低随机性
                    "top_p": 0.9,
                    "num_predict": 300  # 限制输出长度
                }
            }
            
            logger.debug(f"正在调用Ollama API: {self.ollama_url}/api/generate")
            
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json=data,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                try:
                    result = response.json()
                    response_text = result.get('response', '')
                    
                    if not response_text:
                        logger.warning("Ollama API返回空响应")
                        return ""
                    
                    logger.debug(f"Ollama API响应: {response_text[:100]}...")
                    return response_text
                    
                except ValueError as e:
                    logger.error(f"Ollama API响应JSON解析失败: {e}")
                    logger.error(f"响应内容: {response.text[:200]}")
                    return ""
            else:
                logger.error(f"Ollama API调用失败: HTTP {response.status_code}")
                logger.error(f"响应内容: {response.text[:200]}")
                return ""
                
        except requests.exceptions.ConnectTimeout:
            logger.error(f"Ollama API连接超时: {self.ollama_url}")
            return ""
        except requests.exceptions.ConnectionError:
            logger.error(f"无法连接到Ollama服务: {self.ollama_url}")
            return ""
        except requests.exceptions.RequestException as e:
            logger.error(f"Ollama API请求异常: {e}")
            return ""
        except Exception as e:
            logger.error(f"Ollama API调用未知异常: {e}")
            return ""
    
    def _extract_json_from_response(self, response: str) -> Dict[str, Any]:
        """从模型响应中提取JSON结果"""
        try:
            # 清理响应文本
            response = response.strip()
            
            # 尝试直接解析JSON
            if response.startswith('{') and response.endswith('}'):
                return json.loads(response)
            
            # 查找JSON块
            json_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
            matches = re.findall(json_pattern, response, re.DOTALL)
            
            for match in matches:
                try:
                    result = json.loads(match.strip())
                    if 'score' in result:
                        return result
                except json.JSONDecodeError:
                    continue
            
            # 如果无法提取JSON，使用备用解析
            return self._parse_fallback_response(response)
            
        except Exception as e:
            logger.warning(f"JSON解析失败: {e}")
            return self._parse_fallback_response(response)
    
    def _parse_fallback_response(self, response: str) -> Dict[str, Any]:
        """备用响应解析方法"""
        result = {
            "score": 0.0,
            "confidence": 0.5,
            "feedback": "解析失败，建议人工复核",
            "reasoning": "模型响应格式不正确"
        }
        
        # 尝试提取分数
        score_patterns = [
            r'["\']?score["\']?\s*[:：]\s*(\d+\.?\d*)',
            r'分数\s*[:：]\s*(\d+\.?\d*)',
            r'得分\s*[:：]\s*(\d+\.?\d*)',
            r'(\d+\.?\d*)\s*分'
        ]
        
        for pattern in score_patterns:
            match = re.search(pattern, response, re.IGNORECASE)
            if match:
                try:
                    score = float(match.group(1))
                    result["score"] = score
                    result["confidence"] = 0.4
                    result["feedback"] = "基于文本解析的评分"
                    break
                except ValueError:
                    continue
        
        return result
    
    def preprocess_text(self, text: str) -> str:
        """文本预处理"""
        if not text:
            return ""
        return re.sub(r'\s+', ' ', text.strip())
    
    def extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        if not text:
            return []
        
        words = jieba.lcut(text)
        stopwords = {
            '的', '了', '在', '是', '有', '和', '就', '都', '而', '及', '与', '或', '但',
            '这', '那', '这个', '那个', '一个', '一种', '可以', '能够', '什么', '如何'
        }
        
        keywords = [word for word in words if len(word) > 1 and word not in stopwords]
        return keywords
    
    def calculate_semantic_similarity(self, student_answer: str, reference_answer: str) -> float:
        """计算语义相似度"""
        if not student_answer or not reference_answer:
            return 0.0
        
        # 字符串相似度
        sequence_similarity = SequenceMatcher(None, student_answer.lower(), reference_answer.lower()).ratio()
        
        # 关键词相似度
        student_keywords = set(self.extract_keywords(student_answer))
        reference_keywords = set(self.extract_keywords(reference_answer))
        
        if not reference_keywords:
            keyword_similarity = 0.0
        else:
            intersection = len(student_keywords & reference_keywords)
            if intersection == 0:
                keyword_similarity = 0.0
            else:
                precision = intersection / len(student_keywords) if student_keywords else 0
                recall = intersection / len(reference_keywords)
                keyword_similarity = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        
        # 综合相似度
        return (0.3 * sequence_similarity + 0.7 * keyword_similarity)
    
    def calculate_fallback_score(self, student_answer: str, reference_answer: str, max_score: float) -> Dict[str, Any]:
        """当Ollama不可用时的备用评分算法"""
        if not student_answer or len(student_answer.strip()) == 0:
            return {
                "score": 0.0,
                "confidence": 1.0,
                "feedback": "学生未作答",
                "reasoning": "空答案",
                "method": "fallback"
            }
        
        # 计算语义相似度
        similarity = self.calculate_semantic_similarity(student_answer, reference_answer)
        
        # 基于相似度计算分数
        base_score = similarity * max_score
        
        # 长度奖励
        if len(student_answer) > len(reference_answer) * 0.8:
            length_bonus = max_score * 0.1
        else:
            length_bonus = 0
        
        final_score = min(base_score + length_bonus, max_score)
        
        return {
            "score": round(final_score, 1),
            "confidence": 0.6,
            "feedback": f"语义相似度: {similarity:.2%}，基于算法评分",
            "reasoning": "Ollama不可用，使用备用算法评分",
            "method": "fallback"
        }
    
    def intelligent_grade(self, student_answer: str, reference_answer: str, 
                         question_text: str, max_score: float = 5.0) -> Dict[str, Any]:
        """
        智能评分主函数
        
        Args:
            student_answer: 学生答案
            reference_answer: 参考答案
            question_text: 题目文本
            max_score: 满分分值
        
        Returns:
            包含评分结果的字典
        """
        try:
            # 文本预处理
            student_answer = self.preprocess_text(student_answer or "")
            reference_answer = self.preprocess_text(reference_answer or "")
            question_text = self.preprocess_text(question_text or "")
            
            # 特殊处理空答案
            if not student_answer or len(student_answer.strip()) == 0:
                return {
                    "score": 0.0,
                    "confidence": 1.0,
                    "feedback": "学生未作答",
                    "reasoning": "空答案",
                    "method": "ollama",
                    "model": self.model_name,
                    "grading_time": datetime.now().isoformat()
                }
            
            # 如果Ollama不可用，使用备用算法
            if not self.is_available or not self.is_model_available:
                result = self.calculate_fallback_score(student_answer, reference_answer, max_score)
                result.update({
                    "method": "fallback",
                    "model": "算法评分",
                    "grading_time": datetime.now().isoformat()
                })
                return result
            
            # 使用Ollama进行评分
            prompt = self._create_grading_prompt(question_text, reference_answer, student_answer, max_score)
            response = self._call_ollama_api(prompt)
            
            if response:
                ai_result = self._extract_json_from_response(response)
                
                # 验证AI结果的合理性
                if self._validate_ai_result(ai_result, max_score):
                    ai_result.update({
                        "method": "ollama",
                        "model": self.model_name,
                        "grading_time": datetime.now().isoformat()
                    })
                    return ai_result
                else:
                    # AI结果不合理，使用备用算法
                    result = self.calculate_fallback_score(student_answer, reference_answer, max_score)
                    result.update({
                        "method": "fallback_ai_invalid",
                        "model": "算法评分(AI结果无效)",
                        "grading_time": datetime.now().isoformat()
                    })
                    return result
            else:
                # API调用失败，使用备用算法
                result = self.calculate_fallback_score(student_answer, reference_answer, max_score)
                result.update({
                    "method": "fallback_api_failed",
                    "model": "算法评分(API失败)",
                    "grading_time": datetime.now().isoformat()
                })
                return result
                
        except Exception as e:
            logger.error(f"Ollama智能评分失败: {e}")
            # 异常情况，使用备用算法
            result = self.calculate_fallback_score(student_answer or "", reference_answer or "", max_score)
            result.update({
                "method": "fallback_exception",
                "model": f"算法评分(异常: {str(e)})",
                "grading_time": datetime.now().isoformat()
            })
            return result
    
    def _validate_ai_result(self, ai_result: Dict[str, Any], max_score: float) -> bool:
        """验证AI评分结果的合理性"""
        if not ai_result or 'score' not in ai_result:
            return False
        
        try:
            score = float(ai_result.get('score', 0))
            confidence = float(ai_result.get('confidence', 0))
            
            # 检查分数范围
            if not (0 <= score <= max_score):
                return False
            
            # 检查置信度范围
            if not (0 <= confidence <= 1.0):
                return False
            
            # 检查反馈内容
            feedback = ai_result.get('feedback', '')
            if len(feedback) < 3:
                return False
            
            return True
            
        except (ValueError, TypeError):
            return False
    
    def batch_intelligent_grade(self, answers_data: List[Dict]) -> List[Dict]:
        """批量智能评分"""
        results = []
        total = len(answers_data)
        
        logger.info(f"开始批量Ollama评分，共 {total} 道题")
        
        for i, data in enumerate(answers_data):
            try:
                result = self.intelligent_grade(
                    student_answer=data.get('student_answer', ''),
                    reference_answer=data.get('reference_answer', ''),
                    question_text=data.get('question_text', ''),
                    max_score=data.get('max_score', 5.0)
                )
                
                # 添加原始数据信息
                result.update({
                    'question_score_id': data.get('question_score_id'),
                    'student_id': data.get('student_id')
                })
                
                results.append(result)
                
                if (i + 1) % 5 == 0:
                    logger.info(f"批量评分进度: {i + 1}/{total}")
                    
            except Exception as e:
                logger.error(f"批量评分第{i+1}题失败: {e}")
                results.append({
                    'question_score_id': data.get('question_score_id'),
                    'student_id': data.get('student_id'),
                    'score': 0.0,
                    'confidence': 0.0,
                    'feedback': f"评分失败: {str(e)}",
                    'method': 'error',
                    'model': 'error',
                    'grading_time': datetime.now().isoformat()
                })
        
        logger.info(f"批量Ollama评分完成，共处理 {len(results)} 道题")
        return results
    
    def get_model_info(self) -> Dict[str, str]:
        """获取模型信息"""
        return {
            "model_name": self.model_name,
            "ollama_url": self.ollama_url,
            "service_status": "可用" if self.is_available else "不可用",
            "model_status": "可用" if self.is_model_available else "不可用",
            "version": "1.0.0 - Ollama集成版",
            "features": "本地LLM评分 + 语义相似度 + 备用算法"
        }

# 全局变量
_ollama_grader = None

def get_ollama_grader(ollama_url: str = "http://localhost:11434", 
                     model_name: str = "qwen3:0.6b") -> OllamaIntelligentGrader:
    """
    获取Ollama智能评分器单例
    
    Args:
        ollama_url: Ollama服务地址
        model_name: 模型名称
    
    Returns:
        OllamaIntelligentGrader实例
    """
    global _ollama_grader
    
    if _ollama_grader is None or _ollama_grader.model_name != model_name:
        _ollama_grader = OllamaIntelligentGrader(ollama_url, model_name)
    
    return _ollama_grader

def test_ollama_grader():
    """测试Ollama评分器"""
    try:
        grader = get_ollama_grader()
        
        # 获取可用模型
        models = grader.get_available_models()
        print(f"可用的Ollama模型: {models}")
        
        # 测试用例
        test_cases = [
            {
                'name': 'Python特点测试',
                'question_text': '请简述Python的主要特点',
                'reference_answer': 'Python是一种解释型、面向对象、动态类型的高级编程语言，具有语法简洁、易学易用的特点',
                'student_answer': 'Python是解释型语言，面向对象，语法简单易学',
                'max_score': 5.0
            },
            {
                'name': '空答案测试',
                'question_text': '请说明函数的作用',
                'reference_answer': '函数是一段可重复使用的代码块',
                'student_answer': '',
                'max_score': 5.0
            }
        ]
        
        print("\n🧪 Ollama评分器测试结果:")
        print("=" * 60)
        
        for i, test_data in enumerate(test_cases, 1):
            result = grader.intelligent_grade(
                question_text=test_data['question_text'],
                reference_answer=test_data['reference_answer'],
                student_answer=test_data['student_answer'],
                max_score=test_data['max_score']
            )
            
            print(f"\n测试 {i}: {test_data['name']}")
            print(f"学生答案: '{test_data['student_answer']}'")
            print(f"得分: {result['score']}/{test_data['max_score']}")
            print(f"置信度: {result['confidence']}")
            print(f"反馈: {result['feedback']}")
            print(f"方法: {result['method']}")
            print(f"模型: {result['model']}")
        
        print("\n" + "=" * 60)
        print("✅ Ollama评分器测试完成！")
        
    except Exception as e:
        print(f"❌ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()

def check_ollama_service_status(ollama_url: str = "http://localhost:11434") -> Dict[str, Any]:
    """
    检查Ollama服务状态并提供诊断信息
    
    Args:
        ollama_url: Ollama服务地址
        
    Returns:
        服务状态信息字典
    """
    import requests
    
    status = {
        "service_available": False,
        "version": None,
        "models": [],
        "error_message": None,
        "suggestions": []
    }
    
    try:
        # 检查服务版本
        logger.info(f"正在检查Ollama服务: {ollama_url}")
        
        version_response = requests.get(f"{ollama_url}/api/version", timeout=5)
        if version_response.status_code == 200:
            status["service_available"] = True
            version_data = version_response.json()
            status["version"] = version_data.get("version", "unknown")
            logger.info(f"✅ Ollama服务运行正常，版本: {status['version']}")
            
            # 获取可用模型
            try:
                models_response = requests.get(f"{ollama_url}/api/tags", timeout=5)
                if models_response.status_code == 200:
                    models_data = models_response.json()
                    status["models"] = [model['name'] for model in models_data.get('models', [])]
                    logger.info(f"📦 可用模型: {status['models']}")
                    
                    if not status["models"]:
                        status["suggestions"].append("没有可用的模型，请使用 'ollama pull qwen2:7b' 下载模型")
                    elif 'qwen2:7b' not in status["models"]:
                        status["suggestions"].append("推荐的qwen2:7b模型不可用，请使用 'ollama pull qwen2:7b' 下载")
                else:
                    status["error_message"] = f"获取模型列表失败: HTTP {models_response.status_code}"
                    status["suggestions"].append("服务运行但无法获取模型列表，请检查Ollama服务状态")
                    
            except Exception as e:
                status["error_message"] = f"获取模型列表异常: {e}"
                status["suggestions"].append("无法获取模型列表，请检查Ollama服务")
        else:
            status["error_message"] = f"服务检查失败: HTTP {version_response.status_code}"
            status["suggestions"].extend([
                "Ollama服务可能未运行",
                "请确保已安装Ollama: https://ollama.ai/",
                f"请检查服务地址: {ollama_url}",
                "在终端运行 'ollama serve' 启动服务"
            ])
            
    except requests.exceptions.ConnectTimeout:
        status["error_message"] = "连接超时"
        status["suggestions"].extend([
            "Ollama服务响应超时",
            "请检查服务是否正在运行",
            "在终端运行 'ollama serve' 启动服务"
        ])
        
    except requests.exceptions.ConnectionError:
        status["error_message"] = "连接失败"
        status["suggestions"].extend([
            "无法连接到Ollama服务",
            "请确保已安装Ollama: https://ollama.ai/",
            f"请检查服务地址: {ollama_url}",
            "在终端运行 'ollama serve' 启动服务",
            "检查防火墙设置是否阻止了11434端口"
        ])
        
    except Exception as e:
        status["error_message"] = f"未知错误: {e}"
        status["suggestions"].append("发生未知错误，请检查Ollama安装和配置")
    
    return status

def diagnose_ollama_setup() -> str:
    """
    诊断Ollama安装和配置问题
    
    Returns:
        诊断结果和建议的字符串
    """
    import platform
    
    diagnosis = []
    diagnosis.append("🔍 Ollama AI评分服务诊断")
    diagnosis.append("=" * 50)
    
    # 检查操作系统
    os_name = platform.system()
    diagnosis.append(f"操作系统: {os_name} {platform.release()}")
    
    # 检查服务状态
    status = check_ollama_service_status()
    
    if status["service_available"]:
        diagnosis.append("✅ Ollama服务: 运行正常")
        diagnosis.append(f"📄 版本: {status['version']}")
        
        if status["models"]:
            diagnosis.append(f"📦 可用模型: {', '.join(status['models'])}")
            
            if 'qwen2:7b' in status["models"]:
                diagnosis.append("✅ 推荐模型qwen2:7b: 可用")
            else:
                diagnosis.append("⚠️ 推荐模型qwen2:7b: 不可用")
        else:
            diagnosis.append("❌ 可用模型: 无")
    else:
        diagnosis.append(f"❌ Ollama服务: {status['error_message']}")
    
    # 添加建议
    if status["suggestions"]:
        diagnosis.append("\n💡 建议解决方案:")
        for i, suggestion in enumerate(status["suggestions"], 1):
            diagnosis.append(f"{i}. {suggestion}")
    
    # 添加安装指南
    diagnosis.append("\n📋 完整安装指南:")
    if os_name == "Windows":
        diagnosis.extend([
            "1. 访问 https://ollama.ai/ 下载Windows版本",
            "2. 安装完成后，打开命令提示符或PowerShell",
            "3. 运行: ollama serve (启动服务)",
            "4. 运行: ollama pull qwen2:7b (下载模型)",
            "5. 重新尝试AI评分功能"
        ])
    elif os_name == "Darwin":  # macOS
        diagnosis.extend([
            "1. 访问 https://ollama.ai/ 下载macOS版本",
            "2. 安装完成后，打开终端",
            "3. 运行: ollama serve (启动服务)",
            "4. 运行: ollama pull qwen2:7b (下载模型)",
            "5. 重新尝试AI评分功能"
        ])
    else:  # Linux
        diagnosis.extend([
            "1. 运行: curl -fsSL https://ollama.ai/install.sh | sh",
            "2. 运行: ollama serve (启动服务)",
            "3. 运行: ollama pull qwen2:7b (下载模型)",
            "4. 重新尝试AI评分功能"
        ])
    
    diagnosis.append("\n🔗 更多帮助:")
    diagnosis.append("- Ollama官网: https://ollama.ai/")
    diagnosis.append("- 文档: https://github.com/ollama/ollama")
    diagnosis.append("- 模型库: https://ollama.ai/library")
    
    return "\n".join(diagnosis)

if __name__ == "__main__":
    test_ollama_grader() 