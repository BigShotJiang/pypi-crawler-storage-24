#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
英语题目管理路由
独立的英语考试题目管理系统，支持托福、雅思、GRE、考研英语等
"""

import os
import sys
import json
import csv
import io
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, make_response, send_file
from werkzeug.utils import secure_filename
from flask_login import login_required

# 添加项目根目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from flask_app.auth import login_required
from english_exam_manager import EnglishExamManager, EnglishQuestion
from utils_english_exam_types import ExtendedQuestionTypes

# 创建蓝图
english_questions_bp = Blueprint('english_questions', __name__, url_prefix='/teacher/english-questions')

# 初始化英语题目管理器
exam_manager = EnglishExamManager()

@english_questions_bp.route('/')
@login_required
def index():
    """英语题目管理主页"""
    return render_template('teacher/english_questions.html')

@english_questions_bp.route('/api/questions')
@login_required
def get_questions():
    """获取所有英语题目"""
    try:
        questions_data = []
        for question in exam_manager.questions:
            questions_data.append({
                'id': id(question),  # 使用对象ID作为临时ID
                'question_type': question.question_type,
                'question_text': question.question_text,
                'correct_answer': question.correct_answer,
                'difficulty': question.difficulty,
                'subject': question.subject,
                'option_A': question.option_A,
                'option_B': question.option_B,
                'option_C': question.option_C,
                'option_D': question.option_D,
                'audio_file': question.audio_file,
                'speaking_time': question.speaking_time,
                'writing_words': question.writing_words,
                'passage': question.passage,
                'passage_id': getattr(question, 'passage_id', ''),
                'import_batch': getattr(question, 'import_batch', ''),
                'exam_category': ExtendedQuestionTypes.get_exam_category(question.question_type),
                'created_at': question.created_at.strftime('%Y-%m-%d %H:%M:%S')
            })
        
        return jsonify({
            'success': True,
            'questions': questions_data,
            'total': len(questions_data)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'获取题目失败: {str(e)}'
        })

@english_questions_bp.route('/template/<exam_type>')
@login_required
def download_template(exam_type):
    """下载指定考试类型的模板"""
    try:
        template_file = exam_manager.create_template_csv(exam_type)
        
        return send_file(
            template_file,
            as_attachment=True,
            download_name=f'{exam_type}_template.csv',
            mimetype='text/csv'
        )
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'模板下载失败: {str(e)}'
        })

@english_questions_bp.route('/import', methods=['POST'])
@login_required
def import_questions():
    """导入英语题目"""
    try:
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'message': '没有上传文件'
            })
        
        file = request.files['file']
        exam_type = request.form.get('exam_type', 'auto')
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': '没有选择文件'
            })
        
        if not file.filename.lower().endswith('.csv'):
            return jsonify({
                'success': False,
                'message': '只支持CSV文件格式'
            })
        
        # 保存上传的文件
        filename = secure_filename(file.filename)
        temp_path = os.path.join(exam_manager.data_dir, f'temp_{filename}')
        file.save(temp_path)
        
        try:
            # 记录导入前的题目ID
            existing_ids = {id(q) for q in exam_manager.questions}
            
            # 导入题目
            result = exam_manager.import_from_csv(temp_path, exam_type)
            
            # 为新导入的题目添加批次号
            batch_id = datetime.now().strftime('%Y%m%d_%H%M%S')
            for q in exam_manager.questions:
                if id(q) not in existing_ids:
                    q.import_batch = batch_id
            
            # 清理临时文件
            if os.path.exists(temp_path):
                os.remove(temp_path)
            
            if result['success']:
                return jsonify({
                    'success': True,
                    'message': f"成功导入 {result['imported_count']} 道题目",
                    'imported_count': result['imported_count'],
                    'total_count': result['total_count'],
                    'errors': result['errors']
                })
            else:
                return jsonify({
                    'success': False,
                    'message': result['error'],
                    'errors': result['errors']
                })
                
        except Exception as e:
            # 清理临时文件
            if os.path.exists(temp_path):
                os.remove(temp_path)
            raise e
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'导入失败: {str(e)}'
        })

def create_csv_response(csv_content, filename_base, encoding='utf-8'):
    """
    创建CSV导出响应，支持UTF-8和GBK编码选择
    
    Args:
        csv_content: CSV内容字符串
        filename_base: 文件名基础部分（不含扩展名）
        encoding: 编码类型，'utf-8' 或 'gbk'
    
    Returns:
        Flask响应对象
    """
    try:
        # 根据编码选择处理文件内容
        if encoding == 'gbk':
            try:
                csv_bytes = csv_content.encode('gbk')
                encoding_suffix = '_GBK'
                print(f"使用GBK编码成功")
            except UnicodeEncodeError as e:
                print(f"GBK编码失败，回退到UTF-8: {e}")
                # 如果GBK编码失败，回退到UTF-8
                csv_bytes = csv_content.encode('utf-8-sig')
                encoding_suffix = '_UTF8'
        else:
            csv_bytes = csv_content.encode('utf-8-sig')
            encoding_suffix = '_UTF8'
            print(f"使用UTF-8编码")
        
        # 生成文件名
        filename = f'{filename_base}{encoding_suffix}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        print(f"生成文件名: {filename}")
        
        # 创建响应
        response = send_file(
            io.BytesIO(csv_bytes),
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )
        
        return response
        
    except Exception as e:
        print(f"创建CSV响应失败: {e}")
        raise

@english_questions_bp.route('/export')
@login_required
def export_questions():
    """导出英语题目"""
    try:
        # 获取编码参数
        encoding = request.args.get('encoding', 'utf-8')  # utf-8 或 gbk
        
        if not exam_manager.questions:
            return jsonify({
                'success': False,
                'message': '暂无题目数据可导出'
            })
        
        # 创建CSV内容
        output = io.StringIO()
        writer = csv.writer(output)
        
        # 写入标题行
        headers = [
            'question_type', 'question_text', 'option_A', 'option_B', 'option_C', 'option_D',
            'correct_answer', 'difficulty', 'subject', 'audio_file', 'image_file', 'passage',
            'speaking_time', 'writing_words', 'created_at'
        ]
        writer.writerow(headers)
        
        # 写入数据行
        for question in exam_manager.questions:
            writer.writerow([
                question.question_type,
                question.question_text,
                question.option_A,
                question.option_B,
                question.option_C,
                question.option_D,
                question.correct_answer,
                question.difficulty,
                question.subject,
                question.audio_file,
                question.image_file,
                question.passage,
                question.speaking_time,
                question.writing_words,
                question.created_at.strftime('%Y-%m-%d %H:%M:%S')
            ])
        
        output.seek(0)
        csv_data = output.getvalue()
        output.close()
        
        # 使用通用函数创建响应
        return create_csv_response(csv_data, 'english_questions', encoding)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'导出失败: {str(e)}'
        })

@english_questions_bp.route('/add', methods=['POST'])
@login_required
def add_question():
    """添加英语题目"""
    try:
        data = request.get_json()
        
        # 验证必填字段
        required_fields = ['question_type', 'question_text', 'correct_answer']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'缺少必填字段: {field}'
                })
        
        # 验证题目类型
        if not ExtendedQuestionTypes.is_valid_type(data['question_type']):
            return jsonify({
                'success': False,
                'message': f"不支持的题目类型: {data['question_type']}"
            })
        
        # 创建题目对象
        question = EnglishQuestion(
            question_type=data['question_type'],
            question_text=data['question_text'],
            correct_answer=data['correct_answer'],
            difficulty=int(data.get('difficulty', 3)),
            subject=data.get('subject', 'English'),
            option_A=data.get('option_A', ''),
            option_B=data.get('option_B', ''),
            option_C=data.get('option_C', ''),
            option_D=data.get('option_D', ''),
            audio_file=data.get('audio_file', ''),
            speaking_time=int(data.get('speaking_time', 0)),
            writing_words=int(data.get('writing_words', 0)),
            passage=data.get('passage', ''),
            passage_id=data.get('passage_id', '')
        )
        
        # 添加批次号
        question.import_batch = f"manual_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # 添加到管理器
        exam_manager.questions.append(question)
        
        return jsonify({
            'success': True,
            'message': '题目添加成功',
            'question_id': id(question)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'添加题目失败: {str(e)}'
        })

@english_questions_bp.route('/edit/<int:question_id>', methods=['POST'])
@login_required
def edit_question(question_id):
    """编辑英语题目"""
    try:
        data = request.get_json()
        
        # 查找并移除旧题目
        question_to_remove = None
        for question in exam_manager.questions:
            if id(question) == question_id:
                question_to_remove = question
                break
        
        if not question_to_remove:
            return jsonify({'success': False, 'message': '题目不存在'})
            
        exam_manager.questions.remove(question_to_remove)
        
        # 创建新题目
        question = EnglishQuestion(
            question_type=data['question_type'],
            question_text=data['question_text'],
            correct_answer=data['correct_answer'],
            difficulty=int(data.get('difficulty', 3)),
            subject=data.get('subject', 'English'),
            option_A=data.get('option_A', ''),
            option_B=data.get('option_B', ''),
            option_C=data.get('option_C', ''),
            option_D=data.get('option_D', ''),
            audio_file=data.get('audio_file', ''),
            speaking_time=int(data.get('speaking_time', 0)),
            writing_words=int(data.get('writing_words', 0)),
            passage=data.get('passage', ''),
            passage_id=data.get('passage_id', '')
        )
        
        # 保留原有的 import_batch 和 created_at
        question.import_batch = getattr(question_to_remove, 'import_batch', '')
        question.created_at = question_to_remove.created_at
        
        # 添加到管理器
        exam_manager.questions.append(question)
        
        return jsonify({
            'success': True,
            'message': '题目更新成功',
            'question_id': id(question)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'编辑题目失败: {str(e)}'
        })

@english_questions_bp.route('/delete/<int:question_id>', methods=['DELETE'])
@login_required
def delete_question(question_id):
    """删除英语题目"""
    try:
        # 查找并删除题目
        question_to_remove = None
        for question in exam_manager.questions:
            if id(question) == question_id:
                question_to_remove = question
                break
        
        if question_to_remove:
            exam_manager.questions.remove(question_to_remove)
            return jsonify({
                'success': True,
                'message': '题目删除成功'
            })
        else:
            return jsonify({
                'success': False,
                'message': '找不到指定的题目'
            })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'删除题目失败: {str(e)}'
        })

@english_questions_bp.route('/statistics')
@login_required
def get_statistics():
    """获取题目统计信息"""
    try:
        stats = exam_manager.get_statistics()
        return jsonify({
            'success': True,
            'statistics': stats
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'获取统计信息失败: {str(e)}'
        })

@english_questions_bp.route('/validate')
@login_required
def validate_questions():
    """验证题目数据"""
    try:
        issues = exam_manager.validate_questions()
        return jsonify({
            'success': True,
            'issues': issues,
            'valid': len(issues) == 0
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'验证失败: {str(e)}'
        })

@english_questions_bp.route('/clear', methods=['POST'])
@login_required
def clear_all_questions():
    """清空所有英语题目"""
    try:
        exam_manager.questions.clear()
        return jsonify({
            'success': True,
            'message': '所有英语题目已清空'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'清空失败: {str(e)}'
        })

@english_questions_bp.route('/types')
@login_required
def get_question_types():
    """获取支持的题目类型"""
    try:
        types_info = {}
        
        # 按考试类别组织题目类型
        categories = ['toefl', 'ielts', 'gre', 'postgraduate', 'general']
        
        for category in categories:
            types_info[category] = {
                'name': category.upper(),
                'types': []
            }
        
        # 获取所有支持的题目类型
        all_types = ExtendedQuestionTypes.get_all_types()
        
        for q_type in all_types:
            category = ExtendedQuestionTypes.get_exam_category(q_type)
            type_info = {
                'type': q_type,
                'name': ExtendedQuestionTypes.get_type_name(q_type),
                'icon': ExtendedQuestionTypes.get_type_icon(q_type),
                'description': ExtendedQuestionTypes.get_type_description(q_type),
                'is_english': ExtendedQuestionTypes.is_english_type(q_type)
            }
            
            if category in types_info:
                types_info[category]['types'].append(type_info)
        
        return jsonify({
            'success': True,
            'types': types_info
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'获取题目类型失败: {str(e)}'
        })

@english_questions_bp.route('/api/passages')
@login_required
def get_reading_passages():
    """获取阅读文章及其相关题目"""
    try:
        passages = {}
        
        for question in exam_manager.questions:
            passage_id = getattr(question, 'passage_id', '')
            
            if passage_id:
                if passage_id not in passages:
                    passages[passage_id] = {
                        'passage_id': passage_id,
                        'passage_content': question.passage,
                        'questions': []
                    }
                
                passages[passage_id]['questions'].append({
                    'id': id(question),
                    'question_type': question.question_type,
                    'question_text': question.question_text,
                    'correct_answer': question.correct_answer,
                    'difficulty': question.difficulty,
                    'subject': question.subject,
                    'option_A': question.option_A,
                    'option_B': question.option_B,
                    'option_C': question.option_C,
                    'option_D': question.option_D
                })
        
        return jsonify({
            'success': True,
            'passages': list(passages.values()),
            'total': len(passages)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'获取阅读文章失败: {str(e)}'
        })

# 错误处理
@english_questions_bp.errorhandler(404)
def not_found(error):
    return jsonify({
        'success': False,
        'message': '页面未找到'
    }), 404

@english_questions_bp.errorhandler(500)
def internal_error(error):
    return jsonify({
        'success': False,
        'message': '服务器内部错误'
    }), 500 