#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阅读理解管理路由
托福TPO风格的阅读理解材料管理
"""

from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for, send_file
import json
import os
import sys
from datetime import datetime

# 添加项目根目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from reading_passage_models import ReadingPassage, PassageQuestion, PassageSet
from reading_passage_database import ReadingPassageDatabase
from reading_passage_importer import ReadingPassageImporter

reading_passages_bp = Blueprint('reading_passages', __name__, url_prefix='/teacher/reading')

# 初始化数据库
reading_db = ReadingPassageDatabase()

@reading_passages_bp.route('/')
def index():
    """阅读理解管理主页"""
    if not session.get('is_teacher'):
        return redirect(url_for('auth.login'))
    
    try:
        # 获取所有阅读材料
        passages = reading_db.get_reading_passages()
        
        # 统计信息
        stats = {
            'total_passages': len(passages),
            'total_questions': 0,
            'sources': {},
            'topics': {},
            'difficulty_levels': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
        }
        
        for passage in passages:
            # 统计每个阅读材料的题目数量
            questions = reading_db.get_passage_questions(passage.id)
            stats['total_questions'] += len(questions)
            
            # 统计来源
            source = passage.source or '未分类'
            stats['sources'][source] = stats['sources'].get(source, 0) + 1
            
            # 统计主题
            topic = passage.topic or '未分类'
            stats['topics'][topic] = stats['topics'].get(topic, 0) + 1
            
            # 统计难度
            difficulty = passage.difficulty_level
            if difficulty in stats['difficulty_levels']:
                stats['difficulty_levels'][difficulty] += 1
        
        return render_template('teacher/reading_passages.html', 
                             passages=passages, 
                             stats=stats)
    
    except Exception as e:
        print(f"❌ 获取阅读材料失败: {e}")
        return render_template('teacher/reading_passages.html', 
                             passages=[], 
                             stats={}, 
                             error="获取数据失败")

@reading_passages_bp.route('/passage/<int:passage_id>')
def view_passage(passage_id):
    """查看单个阅读材料详情"""
    if not session.get('is_teacher'):
        return redirect(url_for('auth.login'))
    
    try:
        # 获取阅读材料
        passage = reading_db.get_reading_passage(passage_id)
        if not passage:
            return jsonify({'error': '阅读材料不存在'}), 404
        
        # 获取相关题目
        questions = reading_db.get_passage_questions(passage_id)
        
        return render_template('teacher/passage_detail.html', 
                             passage=passage, 
                             questions=questions)
    
    except Exception as e:
        print(f"❌ 获取阅读材料详情失败: {e}")
        return jsonify({'error': '获取详情失败'}), 500

@reading_passages_bp.route('/import', methods=['GET', 'POST'])
def import_passages():
    """导入阅读理解材料"""
    if not session.get('is_teacher'):
        return redirect(url_for('auth.login'))
    
    if request.method == 'GET':
        return render_template('teacher/import_passages.html')
    
    try:
        # 检查文件上传
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': '请选择文件'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': '请选择文件'}), 400
        
        # 检查文件类型
        if not file.filename.lower().endswith('.xlsx'):
            return jsonify({'success': False, 'message': '只支持Excel (.xlsx) 格式文件'}), 400
        
        # 保存临时文件
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
            file.save(tmp_file.name)
            temp_path = tmp_file.name
        
        try:
            # 导入阅读理解材料
            importer = ReadingPassageImporter()
            source = request.form.get('source', '教师导入')
            
            passage_ids, question_ids = importer.import_excel_file(temp_path, source)
            
            if passage_ids:
                return jsonify({
                    'success': True,
                    'message': f'导入成功！共导入 {len(passage_ids)} 篇阅读材料，{len(question_ids)} 道题目',
                    'passage_count': len(passage_ids),
                    'question_count': len(question_ids)
                })
            else:
                return jsonify({'success': False, 'message': '导入失败，未找到有效数据'}), 400
        
        finally:
            # 清理临时文件
            try:
                os.unlink(temp_path)
            except:
                pass
    
    except Exception as e:
        print(f"❌ 导入阅读材料失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'导入失败: {str(e)}'}), 500

@reading_passages_bp.route('/api/passages')
def api_get_passages():
    """API: 获取阅读材料列表"""
    if not session.get('is_teacher'):
        return jsonify({'error': '未授权'}), 401
    
    try:
        passages = reading_db.get_reading_passages()
        
        # 转换为JSON格式
        passages_data = []
        for passage in passages:
            questions = reading_db.get_passage_questions(passage.id)
            passages_data.append({
                'id': passage.id,
                'title': passage.title,
                'content': passage.content[:200] + '...' if len(passage.content) > 200 else passage.content,
                'source': passage.source,
                'topic': passage.topic,
                'difficulty_level': passage.difficulty_level,
                'word_count': passage.word_count,
                'reading_time': passage.reading_time,
                'language': passage.language,
                'question_count': len(questions),
                'created_at': passage.created_at.isoformat() if passage.created_at else None
            })
        
        return jsonify({
            'success': True,
            'passages': passages_data
        })
    
    except Exception as e:
        print(f"❌ API获取阅读材料失败: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@reading_passages_bp.route('/api/passage/<int:passage_id>')
def api_get_passage_detail(passage_id):
    """API: 获取阅读材料详情"""
    if not session.get('is_teacher'):
        return jsonify({'error': '未授权'}), 401
    
    try:
        # 获取阅读材料
        passage = reading_db.get_reading_passage(passage_id)
        if not passage:
            return jsonify({'error': '阅读材料不存在'}), 404
        
        # 获取相关题目
        questions = reading_db.get_passage_questions(passage_id)
        
        # 转换为JSON格式
        passage_data = {
            'id': passage.id,
            'title': passage.title,
            'content': passage.content,
            'source': passage.source,
            'topic': passage.topic,
            'difficulty_level': passage.difficulty_level,
            'word_count': passage.word_count,
            'reading_time': passage.reading_time,
            'language': passage.language,
            'created_at': passage.created_at.isoformat() if passage.created_at else None,
            'questions': []
        }
        
        for question in questions:
            question_data = {
                'id': question.id,
                'order': question.question_order,
                'type': question.question_type,
                'text': question.question_text,
                'options': json.loads(question.options) if question.options else {},
                'correct_answer': question.correct_answer,
                'explanation': question.explanation,
                'difficulty': question.difficulty,
                'points': question.points,
                'skill_focus': question.skill_focus
            }
            passage_data['questions'].append(question_data)
        
        return jsonify({
            'success': True,
            'passage': passage_data
        })
    
    except Exception as e:
        print(f"❌ API获取阅读材料详情失败: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@reading_passages_bp.route('/api/passage/<int:passage_id>/delete', methods=['POST'])
def api_delete_passage(passage_id):
    """API: 删除阅读材料"""
    if not session.get('is_teacher'):
        return jsonify({'error': '未授权'}), 401
    
    try:
        success = reading_db.delete_reading_passage(passage_id)
        
        if success:
            return jsonify({
                'success': True,
                'message': '阅读材料删除成功'
            })
        else:
            return jsonify({
                'success': False,
                'message': '删除失败，阅读材料不存在'
            }), 404
    
    except Exception as e:
        print(f"❌ API删除阅读材料失败: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@reading_passages_bp.route('/sets')
def passage_sets():
    """阅读材料集合管理"""
    if not session.get('is_teacher'):
        return redirect(url_for('auth.login'))
    
    try:
        # 获取所有集合
        sets = reading_db.get_passage_sets()
        
        return render_template('teacher/passage_sets.html', sets=sets)
    
    except Exception as e:
        print(f"❌ 获取阅读材料集合失败: {e}")
        return render_template('teacher/passage_sets.html', sets=[], error="获取数据失败")

@reading_passages_bp.route('/sets/create', methods=['GET', 'POST'])
def create_passage_set():
    """创建阅读材料集合"""
    if not session.get('is_teacher'):
        return redirect(url_for('auth.login'))
    
    if request.method == 'GET':
        # 获取所有可用的阅读材料
        passages = reading_db.get_reading_passages()
        return render_template('teacher/create_passage_set.html', passages=passages)
    
    try:
        # 获取表单数据
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        exam_type = request.form.get('exam_type', '').strip()
        time_limit = int(request.form.get('time_limit', 60))
        difficulty_level = int(request.form.get('difficulty_level', 2))
        
        # 获取选中的阅读材料ID
        passage_ids = request.form.getlist('passage_ids')
        passage_ids = [int(pid) for pid in passage_ids if pid.isdigit()]
        
        if not title:
            return jsonify({'success': False, 'message': '请输入集合标题'}), 400
        
        if not passage_ids:
            return jsonify({'success': False, 'message': '请选择至少一篇阅读材料'}), 400
        
        # 计算总题目数
        total_questions = 0
        for passage_id in passage_ids:
            questions = reading_db.get_passage_questions(passage_id)
            total_questions += len(questions)
        
        # 创建集合
        passage_set = PassageSet(
            title=title,
            description=description,
            exam_type=exam_type,
            total_questions=total_questions,
            time_limit=time_limit,
            difficulty_level=difficulty_level
        )
        
        set_id = reading_db.create_passage_set(passage_set, passage_ids)
        
        if set_id > 0:
            return jsonify({
                'success': True,
                'message': f'集合创建成功！包含 {len(passage_ids)} 篇阅读材料，{total_questions} 道题目',
                'set_id': set_id
            })
        else:
            return jsonify({'success': False, 'message': '创建失败'}), 500
    
    except Exception as e:
        print(f"❌ 创建阅读材料集合失败: {e}")
        return jsonify({'success': False, 'message': f'创建失败: {str(e)}'}), 500 