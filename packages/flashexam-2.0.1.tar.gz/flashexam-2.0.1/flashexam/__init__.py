"""FlashExam - Intelligent Online Examination System with AI Grading."""

__version__ = "2.0.1"

from flask import Flask
from flask_login import LoginManager
from flask_session import Session
import os
import sys
from datetime import timedelta
import json
import time

current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("[WARNING] psutil未安装，将使用模拟数据")

_app_start_time = time.time()
_request_count = 0
_active_connections = 0

def load_development_config(app, static_folder):
    """加载开发环境配置"""
    app.config.update({
        'SECRET_KEY': os.environ.get('SECRET_KEY') or 'flashexam-dev-key-2024',
        'UPLOAD_FOLDER': os.path.join(static_folder, 'uploads'),
        'MAX_CONTENT_LENGTH': 16 * 1024 * 1024,
        'TEMPLATES_AUTO_RELOAD': True,
        'JSON_AS_ASCII': False,
        'DEBUG': True
    })

def load_production_config(app, static_folder):
    """加载生产环境配置"""
    is_https = os.environ.get('HTTPS', '').lower() in ('1', 'true', 'on')
    
    app.config.update({
        'SECRET_KEY': os.environ.get('SECRET_KEY') or 'flashexam-prod-key-2024',
        'UPLOAD_FOLDER': os.path.join(static_folder, 'uploads'),
        'MAX_CONTENT_LENGTH': 32 * 1024 * 1024,
        'TEMPLATES_AUTO_RELOAD': False,
        'JSON_AS_ASCII': False,
        'SEND_FILE_MAX_AGE_DEFAULT': 43200,
        'SESSION_COOKIE_SECURE': is_https,
        'SESSION_COOKIE_HTTPONLY': True,
        'SESSION_COOKIE_SAMESITE': 'Lax',
        'DEBUG': False
    })

def load_high_performance_config(app, static_folder):
    """加载高性能环境配置"""
    is_https = os.environ.get('HTTPS', '').lower() in ('1', 'true', 'on')
    
    app.config.update({
        'SECRET_KEY': os.environ.get('SECRET_KEY') or 'flashexam-hp-key-2024',
        'UPLOAD_FOLDER': os.path.join(static_folder, 'uploads'),
        'MAX_CONTENT_LENGTH': 64 * 1024 * 1024,
        'TEMPLATES_AUTO_RELOAD': False,
        'JSON_AS_ASCII': False,
        'SEND_FILE_MAX_AGE_DEFAULT': 86400,
        'SESSION_COOKIE_SECURE': is_https,
        'SESSION_COOKIE_HTTPONLY': True,
        'SESSION_COOKIE_SAMESITE': 'Lax',
        'PERMANENT_SESSION_LIFETIME': timedelta(hours=8),
        'DEBUG': False
    })

def create_app(config_name='development'):
    """
    Flask应用工厂函数
    支持多种配置模式：development, production, high-performance
    """
    template_folder = os.path.join(os.path.dirname(__file__), 'templates')
    static_folder = os.path.join(os.path.dirname(__file__), 'static')
    
    app = Flask(__name__, 
                template_folder=template_folder,
                static_folder=static_folder)
    
    if config_name == 'production':
        load_production_config(app, static_folder)
    elif config_name == 'high-performance':
        load_high_performance_config(app, static_folder)
    else:
        load_development_config(app, static_folder)
    
    app.config['SESSION_TYPE'] = 'filesystem'
    app.config['SESSION_PERMANENT'] = True
    if 'PERMANENT_SESSION_LIFETIME' not in app.config:
        app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=24)
    app.config['SESSION_USE_SIGNER'] = True
    app.config['SESSION_KEY_PREFIX'] = 'flashexam:'
    app.config['SESSION_FILE_DIR'] = os.path.join(os.path.dirname(__file__), 'storage', 'sessions')
    app.config['DATABASE_PATH'] = os.path.join(os.path.dirname(__file__), 'storage', 'exam_database.db')
    
    Session(app)
    
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = '请先登录系统'
    login_manager.login_message_category = 'warning'
    
    app.jinja_env.globals['hasattr'] = hasattr
    
    @app.before_request
    def before_request():
        global _request_count, _active_connections
        _request_count += 1
        _active_connections += 1
    
    @app.after_request
    def after_request(response):
        global _active_connections
        _active_connections = max(0, _active_connections - 1)
        return response
    
    @app.template_filter('from_json')
    def from_json_filter(value):
        try:
            if isinstance(value, str):
                return json.loads(value)
            return value
        except (json.JSONDecodeError, TypeError):
            return []
    
    @app.template_filter('rjust')
    def rjust_filter(value, width, fillchar=' '):
        try:
            return str(value).rjust(int(width), str(fillchar))
        except (ValueError, TypeError):
            return str(value)
    
    @app.template_filter('ljust')
    def ljust_filter(value, width, fillchar=' '):
        try:
            return str(value).ljust(int(width), str(fillchar))
        except (ValueError, TypeError):
            return str(value)
    
    @app.template_filter('zfill')
    def zfill_filter(value, width):
        try:
            return str(value).zfill(int(width))
        except (ValueError, TypeError):
            return str(value)
    
    @login_manager.user_loader
    def load_user(user_id):
        from .user import User
        return User.get_by_id(user_id)
    
    from .auth import auth_bp
    from .teacher import teacher_bp
    from .student import student_bp
    from .api import api_bp
    from .main import main_bp
    from .admin import admin_bp
    
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(teacher_bp, url_prefix='/teacher')
    app.register_blueprint(student_bp, url_prefix='/student')
    app.register_blueprint(api_bp, url_prefix='/api')
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp, url_prefix='/admin')
    
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config['SESSION_FILE_DIR'], exist_ok=True)
    
    @app.errorhandler(404)
    def not_found_error(error):
        try:
            from flask import render_template
            return render_template('errors/404.html'), 404
        except:
            return '<h1>404 - 页面不存在</h1><p>抱歉，您访问的页面不存在。</p><a href="/">返回首页</a>', 404

    @app.errorhandler(500)
    def internal_error(error):
        try:
            from flask import render_template
            return render_template('errors/500.html'), 500
        except:
            return '<h1>500 - 服务器错误</h1><p>抱歉，服务器遇到了错误。</p><a href="/">返回首页</a>', 500
    
    print("[SUCCESS] FlashExam 初始化完成")
    return app

__all__ = [
    "__version__",
    "create_app",
]