from flask import Blueprint, render_template, redirect, url_for
from flask_login import current_user

from .database import Database

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    """主页"""
    # 首先检查是否需要设置管理员密码
    db = Database()
    if not db.has_teacher_password():
        return redirect(url_for('auth.setup_password'))
    
    # 如果已登录，直接跳转到对应界面
    if current_user.is_authenticated:
        if current_user.is_teacher():
            return redirect(url_for('teacher.dashboard'))
        else:
            return redirect(url_for('student.dashboard'))
    
    # 未登录用户显示主页
    return render_template('index.html', need_setup=False)

@main_bp.route('/about')
def about():
    """关于页面"""
    return render_template('about.html')

@main_bp.route('/help')
def help():
    """帮助页面"""
    return render_template('help.html') 