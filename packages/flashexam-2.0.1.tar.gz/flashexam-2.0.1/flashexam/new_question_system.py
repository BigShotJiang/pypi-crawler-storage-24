#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全新题目管理系统
重新设计题目分类、导入和考试选题机制
"""

import json
import uuid
import hashlib
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Set
from datetime import datetime
from enum import Enum

class QuestionCategory(Enum):
    """题目类别枚举"""
    SIMPLE = "simple"           # 简单题目（独立题目）
    GROUPED = "grouped"         # 分组题目（题目组）
    READING = "reading"         # 阅读理解题目
    LISTENING = "listening"     # 听力题目
    SPEAKING = "speaking"       # 口语题目
    WRITING = "writing"         # 写作题目

class QuestionType(Enum):
    """题目类型枚举"""
    # 客观题
    CHOICE = "choice"                    # 选择题
    MULTIPLE_CHOICE = "multiple_choice"   # 多选题
    JUDGE = "judge"                      # 判断题
    FILL_BLANK = "fill_blank"            # 填空题
    
    # 主观题
    SHORT_ANSWER = "short_answer"        # 简答题
    ESSAY = "essay"                      # 论述题
    ANALYSIS = "analysis"                # 分析题
    
    # 编程题
    CODE_READING = "code_reading"        # 代码阅读题
    CODE_PRACTICE = "code_practice"      # 代码编程题
    CODE_DEBUG = "code_debug"            # 代码调试题
    
    # 语言类
    TRANSLATION = "translation"          # 翻译题
    COMPOSITION = "composition"          # 作文题
    SPEAKING = "speaking"                # 口语题
    LISTENING = "listening"              # 听力题

@dataclass
class QuestionGroup:
    """题目组模型"""
    id: Optional[str] = None              # 题目组唯一ID
    name: str = ""                        # 题目组名称
    description: str = ""                 # 题目组描述
    material: str = ""                    # 阅读材料/背景材料
    material_type: str = "text"           # 材料类型：text, audio, video, image
    category: QuestionCategory = QuestionCategory.GROUPED
    subject: str = ""                     # 学科
    difficulty: int = 1                   # 整体难度 1-5
    estimated_time: int = 0               # 预估完成时间（分钟）
    total_score: float = 0.0              # 题目组总分
    question_count: int = 0               # 包含题目数量
    created_at: Optional[datetime] = field(default_factory=datetime.now)
    is_active: bool = True
    
    def __post_init__(self):
        if self.id is None:
            # 生成基于内容的唯一ID
            content_hash = hashlib.md5(
                (self.name + self.material + str(self.created_at)).encode()
            ).hexdigest()[:8]
            self.id = f"group_{content_hash}"

@dataclass
class EnhancedQuestion:
    """增强题目模型"""
    id: Optional[int] = None              # 数据库ID
    uuid: Optional[str] = None            # 题目唯一标识符
    group_id: Optional[str] = None        # 所属题目组ID（可选）
    group_order: int = 0                  # 在题目组中的顺序
    
    # 基本信息
    question_type: QuestionType = QuestionType.CHOICE
    category: QuestionCategory = QuestionCategory.SIMPLE
    question_text: str = ""
    options: str = ""                     # JSON格式选项
    correct_answer: str = ""
    explanation: str = ""                 # 答案解析
    
    # 评分信息
    score: float = 1.0
    difficulty: int = 1                   # 1-5难度等级
    estimated_time: int = 2               # 预估完成时间（分钟）
    
    # 分类信息
    subject: str = ""                     # 学科
    chapter: str = ""                     # 章节
    knowledge_points: List[str] = field(default_factory=list)  # 知识点标签
    
    # 材料相关（用于题目组）
    material: str = ""                    # 材料内容（向后兼容）
    material_reference: str = ""          # 材料引用（新设计）
    
    # 元数据
    created_at: Optional[datetime] = field(default_factory=datetime.now)
    updated_at: Optional[datetime] = field(default_factory=datetime.now)
    created_by: str = ""                  # 创建者
    is_active: bool = True
    
    def __post_init__(self):
        if self.uuid is None:
            self.uuid = str(uuid.uuid4())
        
        # 根据题目内容自动判断类别
        if self.group_id:
            self.category = QuestionCategory.GROUPED
        elif self.material and self.material.strip():
            # 向后兼容：有material的题目视为分组题目
            self.category = QuestionCategory.GROUPED

class NewQuestionManager:
    """新题目管理器"""
    
    def __init__(self, database):
        self.db = database
        self.question_groups: Dict[str, QuestionGroup] = {}
        self.questions: Dict[str, EnhancedQuestion] = {}
        self._initialize_system()
    
    def _initialize_system(self):
        """初始化系统，迁移现有数据"""
        print("🔄 初始化新题目管理系统...")
        self._migrate_existing_questions()
        self._build_question_groups()
    
    def _migrate_existing_questions(self):
        """迁移现有题目数据"""
        print("📦 迁移现有题目数据...")
        existing_questions = self.db.get_questions()
        
        for old_q in existing_questions:
            # 转换为新的题目模型
            new_question = EnhancedQuestion(
                id=old_q.id,
                question_type=self._convert_question_type(old_q.question_type),
                question_text=old_q.question_text,
                options=old_q.options,
                correct_answer=old_q.correct_answer,
                score=old_q.score,
                difficulty=old_q.difficulty,
                subject=old_q.subject,
                material=old_q.material,
                created_at=old_q.created_at
            )
            
            self.questions[new_question.uuid] = new_question
        
        print(f"✅ 迁移了 {len(self.questions)} 道题目")
    
    def _convert_question_type(self, old_type: str) -> QuestionType:
        """转换旧的题目类型到新枚举"""
        type_mapping = {
            'choice': QuestionType.CHOICE,
            'judge': QuestionType.JUDGE,
            'essay': QuestionType.ESSAY,
            'short_answer': QuestionType.SHORT_ANSWER,
            'code_reading': QuestionType.CODE_READING,
            'code_practice': QuestionType.CODE_PRACTICE,
            'analysis': QuestionType.ANALYSIS,
            'fill_blank': QuestionType.FILL_BLANK,
        }
        return type_mapping.get(old_type, QuestionType.CHOICE)
    
    def _build_question_groups(self):
        """构建题目组"""
        print("🔗 构建题目组...")
        
        # 按material分组
        material_groups = {}
        for question in self.questions.values():
            if question.material and question.material.strip():
                material_key = question.material.strip()
                if material_key not in material_groups:
                    material_groups[material_key] = []
                material_groups[material_key].append(question)
        
        # 创建题目组对象
        for material, questions_list in material_groups.items():
            group = QuestionGroup(
                name=f"题目组 - {material[:30]}...",
                description=f"包含 {len(questions_list)} 道题目的题目组",
                material=material,
                subject=questions_list[0].subject if questions_list else "",
                difficulty=int(sum(q.difficulty for q in questions_list) / len(questions_list)),
                total_score=sum(q.score for q in questions_list),
                question_count=len(questions_list),
                estimated_time=sum(q.estimated_time for q in questions_list)
            )
            
            # 更新题目的group_id
            for i, question in enumerate(questions_list):
                question.group_id = group.id
                question.group_order = i + 1
                question.category = QuestionCategory.GROUPED
            
            self.question_groups[group.id] = group
        
        print(f"✅ 构建了 {len(self.question_groups)} 个题目组")
    
    def get_simple_questions(self) -> List[EnhancedQuestion]:
        """获取简单题目（独立题目）"""
        return [q for q in self.questions.values() 
                if q.category == QuestionCategory.SIMPLE and q.is_active]
    
    def get_grouped_questions(self) -> Dict[str, List[EnhancedQuestion]]:
        """获取分组题目"""
        grouped = {}
        for question in self.questions.values():
            if question.category == QuestionCategory.GROUPED and question.group_id:
                if question.group_id not in grouped:
                    grouped[question.group_id] = []
                grouped[question.group_id].append(question)
        
        # 按group_order排序
        for group_id in grouped:
            grouped[group_id].sort(key=lambda q: q.group_order)
        
        return grouped
    
    def get_question_groups(self) -> List[QuestionGroup]:
        """获取所有题目组"""
        return list(self.question_groups.values())
    
    def get_questions_by_group(self, group_id: str) -> List[EnhancedQuestion]:
        """获取指定题目组的所有题目"""
        questions = [q for q in self.questions.values() 
                    if q.group_id == group_id and q.is_active]
        return sorted(questions, key=lambda q: q.group_order)
    
    def create_exam_question_selection(self, simple_question_ids: List[int] = None, 
                                     group_ids: List[str] = None) -> Dict[str, Any]:
        """创建考试题目选择"""
        selection = {
            'simple_questions': [],
            'grouped_questions': [],
            'total_questions': 0,
            'total_score': 0.0,
            'estimated_time': 0,
            'question_ids': []  # 所有题目的数据库ID
        }
        
        # 处理简单题目
        if simple_question_ids:
            for q_id in simple_question_ids:
                question = self._find_question_by_db_id(q_id)
                if question and question.category == QuestionCategory.SIMPLE:
                    selection['simple_questions'].append(question)
                    selection['question_ids'].append(q_id)
                    selection['total_score'] += question.score
                    selection['estimated_time'] += question.estimated_time
        
        # 处理题目组
        if group_ids:
            for group_id in group_ids:
                if group_id in self.question_groups:
                    group = self.question_groups[group_id]
                    group_questions = self.get_questions_by_group(group_id)
                    
                    selection['grouped_questions'].append({
                        'group': group,
                        'questions': group_questions
                    })
                    
                    # 添加题目ID
                    for question in group_questions:
                        if question.id:
                            selection['question_ids'].append(question.id)
                    
                    selection['total_score'] += group.total_score
                    selection['estimated_time'] += group.estimated_time
        
        selection['total_questions'] = len(selection['question_ids'])
        
        return selection
    
    def _find_question_by_db_id(self, db_id: int) -> Optional[EnhancedQuestion]:
        """根据数据库ID查找题目"""
        for question in self.questions.values():
            if question.id == db_id:
                return question
        return None
    
    def find_group_by_material(self, material: str) -> Optional[QuestionGroup]:
        """根据材料内容查找题目组"""
        material = material.strip()
        for group in self.question_groups.values():
            if group.material.strip() == material:
                return group
        return None
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取系统统计信息"""
        simple_questions = self.get_simple_questions()
        grouped_questions = self.get_grouped_questions()
        
        stats = {
            'total_questions': len(self.questions),
            'simple_questions_count': len(simple_questions),
            'grouped_questions_count': sum(len(questions) for questions in grouped_questions.values()),
            'question_groups_count': len(self.question_groups),
            'question_types': {},
            'subjects': {},
            'difficulties': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
        }
        
        # 统计题目类型和学科
        for question in self.questions.values():
            if question.is_active:
                # 题目类型统计
                type_key = question.question_type.value
                stats['question_types'][type_key] = stats['question_types'].get(type_key, 0) + 1
                
                # 学科统计
                subject = question.subject or "未分类"
                stats['subjects'][subject] = stats['subjects'].get(subject, 0) + 1
                
                # 难度统计
                stats['difficulties'][question.difficulty] += 1
        
        return stats

def test_new_question_system():
    """测试新题目系统"""
    print("🧪 测试新题目管理系统")
    print("=" * 60)
    
    # 初始化
    from database import Database
    db = Database()
    manager = NewQuestionManager(db)
    
    # 获取统计信息
    stats = manager.get_statistics()
    print(f"\n📊 系统统计:")
    print(f"  总题目数: {stats['total_questions']}")
    print(f"  简单题目: {stats['simple_questions_count']}")
    print(f"  分组题目: {stats['grouped_questions_count']}")
    print(f"  题目组数: {stats['question_groups_count']}")
    
    # 显示题目组信息
    print(f"\n🔗 题目组详情:")
    for i, group in enumerate(manager.get_question_groups(), 1):
        print(f"  {i}. {group.name}")
        print(f"     ID: {group.id}")
        print(f"     题目数: {group.question_count}, 总分: {group.total_score}")
        print(f"     材料长度: {len(group.material)}")
    
    # 测试简单题目
    simple_questions = manager.get_simple_questions()
    print(f"\n📝 简单题目示例 (前5个):")
    for i, question in enumerate(simple_questions[:5], 1):
        print(f"  {i}. ID:{question.id}, 类型:{question.question_type.value}")
        print(f"     题目: {question.question_text[:50]}...")
    
    # 测试考试创建
    if simple_questions and manager.get_question_groups():
        print(f"\n🎯 测试考试创建:")
        
        # 选择题目
        selected_simple = [q.id for q in simple_questions[:3] if q.id]
        selected_groups = [list(manager.question_groups.keys())[0]]
        
        selection = manager.create_exam_question_selection(
            simple_question_ids=selected_simple,
            group_ids=selected_groups
        )
        
        print(f"  选择简单题目: {len(selection['simple_questions'])}道")
        print(f"  选择题目组: {len(selection['grouped_questions'])}组")
        print(f"  总题目数: {selection['total_questions']}")
        print(f"  总分: {selection['total_score']}")
        print(f"  预估时间: {selection['estimated_time']}分钟")
        print(f"  题目ID列表: {selection['question_ids']}")

if __name__ == "__main__":
    test_new_question_system() 