from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime
import uuid

from .user import User
from .database import Database

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """登录页面"""
    if current_user.is_authenticated:
        if current_user.is_teacher():
            return redirect(url_for('teacher.dashboard'))
        else:
            return redirect(url_for('student.dashboard'))
    
    if request.method == 'POST':
        # 处理JSON和表单数据
        if request.is_json:
            data = request.get_json()
            username = data.get('username', '').strip()
            password = data.get('password', '')
            role = data.get('role', 'student')
            remember = bool(data.get('remember', False))
        else:
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            role = request.form.get('role', 'student')
            remember = bool(request.form.get('remember'))
        
        if not username:
            error_msg = '用户名不能为空'
            if request.is_json:
                return jsonify({'success': False, 'message': error_msg})
            else:
                flash(error_msg, 'error')
                return render_template('auth/login.html')
        
        # 所有用户都需要密码
        if not password:
            error_msg = '密码不能为空'
            if request.is_json:
                return jsonify({'success': False, 'message': error_msg})
            else:
                flash(error_msg, 'error')
                return render_template('auth/login.html')
        
        # 使用新的认证方法
        user = User.authenticate(username, password)
        
        if user:
            # 检查角色是否匹配
            if user.role != role:
                error_msg = f'用户角色不匹配，您是{user.role}，请选择正确的角色'
                if request.is_json:
                    return jsonify({'success': False, 'message': error_msg})
                else:
                    flash(error_msg, 'error')
                    return render_template('auth/login.html')
            
            login_user(user, remember=remember)
            success_msg = f'欢迎回来，{user.name}！'
            
            # 确定重定向URL
            next_page = request.args.get('next')
            if next_page:
                redirect_url = next_page
            elif user.is_teacher():
                redirect_url = url_for('teacher.dashboard')
            else:
                redirect_url = url_for('student.dashboard')
            
            if request.is_json:
                return jsonify({
                    'success': True, 
                    'message': success_msg,
                    'redirect': redirect_url
                })
            else:
                flash(success_msg, 'success')
                return redirect(redirect_url)
        else:
            error_msg = '用户名或密码错误'
            if request.is_json:
                return jsonify({'success': False, 'message': error_msg})
            else:
                flash(error_msg, 'error')
    
    return render_template('auth/login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    """退出登录"""
    logout_user()
    session.clear()  # 彻底清除会话数据
    
    # 强制清除所有可能存在的cookie
    response = redirect(url_for('main.index'))
    response.delete_cookie('remember_token')
    response.delete_cookie('session')
    
    flash('您已成功退出登录', 'info')
    return response

@auth_bp.route('/check-auth')
def check_auth():
    """检查认证状态的API"""
    if current_user.is_authenticated:
        return jsonify({
            'authenticated': True,
            'user': {
                'name': current_user.get_display_name(),
                'role': current_user.role,
                'username': current_user.username
            }
        })
    else:
        return jsonify({'authenticated': False})

@auth_bp.route('/setup-password')
def setup_password():
    """教师密码设置页面"""
    db = Database()
    if db.has_teacher_password():
        flash('管理员密码已设置，请直接登录', 'info')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/setup_password.html')

@auth_bp.route('/setup-password', methods=['POST'])
def setup_password_post():
    """处理教师密码设置"""
    try:
        data = request.get_json() if request.is_json else request.form
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        confirm_password = data.get('confirm_password', '').strip()
        name = data.get('name', '').strip()
        email = data.get('email', '').strip()
        
        # 验证输入
        if not all([username, password, name]):
            error_msg = '请填写所有必填字段'
            return jsonify({'success': False, 'message': error_msg}) if request.is_json else _redirect_with_error(error_msg)
        
        if password != confirm_password:
            error_msg = '两次输入的密码不一致'
            return jsonify({'success': False, 'message': error_msg}) if request.is_json else _redirect_with_error(error_msg)
        
        if len(password) < 6:
            error_msg = '密码长度至少6位'
            return jsonify({'success': False, 'message': error_msg}) if request.is_json else _redirect_with_error(error_msg)
        
        # 设置密码
        db = Database()
        
        # 检查是否已设置
        if db.has_teacher_password():
            error_msg = '管理员密码已设置'
            return jsonify({'success': False, 'message': error_msg}) if request.is_json else _redirect_with_error(error_msg)
        
        # 创建管理员账户
        success = db.set_teacher_password(username, password, name, email)
        
        if success:
            if request.is_json:
                return jsonify({
                    'success': True,
                    'message': '管理员账户设置成功！',
                    'redirect': url_for('auth.login')
                })
            else:
                flash('管理员账户设置成功！', 'success')
                return redirect(url_for('auth.login'))
        else:
            error_msg = '账户设置失败，请重试'
            return jsonify({'success': False, 'message': error_msg}) if request.is_json else _redirect_with_error(error_msg)
    
    except Exception as e:
        print(f"Setup password error: {e}")
        error_msg = '设置过程中发生错误，请重试'
        return jsonify({'success': False, 'message': error_msg}) if request.is_json else _redirect_with_error(error_msg)

def _redirect_with_error(message):
    """辅助函数：带错误消息的重定向"""
    flash(message, 'error')
    return redirect(url_for('auth.login'))

@auth_bp.route('/student/login', methods=['GET', 'POST'])
def student_login():
    """学生登录 - 改进版，支持会话管理和防重复登录"""
    if request.method == 'POST':
        student_id = request.form.get('student_id', '').strip()
        password = request.form.get('password', '')
        
        if not student_id or not password:
            flash('请输入学号和密码', 'error')
            return render_template('auth/student_login.html')
        
        db = Database()
        
        try:
            # 验证学生身份
            student = db.get_student_by_id(student_id)
            if not student:
                flash('学号不存在', 'error')
                return render_template('auth/student_login.html')
            
            # 验证密码
            if not student.check_password(password):
                flash('密码错误', 'error')
                return render_template('auth/student_login.html')
            
            # 生成会话ID
            session_id = str(uuid.uuid4())
            
            # 获取请求信息
            ip_address = request.remote_addr
            user_agent = request.headers.get('User-Agent', '')
            
            # 检查是否已在其他地方登录
            conflict_info = db.check_student_session_conflict(student_id, session_id)
            
            if conflict_info.get('has_conflict'):
                # 有其他活跃会话，询问是否强制登录
                other_ip = conflict_info.get('other_ip', '未知')
                other_login_time = conflict_info.get('other_login_time', '未知')
                
                # 将冲突信息保存到session中，用于确认页面
                session['pending_login'] = {
                    'student_id': student_id,
                    'db_id': student.id,  # 保存数据库ID
                    'student_name': student.name,
                    'session_id': session_id,
                    'ip_address': ip_address,
                    'user_agent': user_agent,
                    'conflict_info': conflict_info
                }
                
                return render_template('auth/login_conflict.html', 
                                     student=student,
                                     conflict_info=conflict_info,
                                     current_ip=ip_address)
            
            # 没有冲突，直接创建会话并登录
            success = db.create_student_session(
                student_number=student_id,
                student_name=student.name,
                session_id=session_id,
                ip_address=ip_address,
                user_agent=user_agent
            )
            
            if not success:
                flash('创建会话失败，请重试', 'error')
                return render_template('auth/student_login.html')
            
            # 设置会话信息
            session.permanent = False  # 确保会话在浏览器关闭时失效
            session['user_type'] = 'student'
            session['student_id'] = student.id
            session['student_number'] = student_id
            session['student_name'] = student.name
            session['session_id'] = session_id
            session['login_time'] = datetime.now().isoformat()
            session['current_student_id'] = student.id
            
            # 清理非活跃会话
            db.cleanup_inactive_sessions()
            
            print(f"[SUCCESS] 学生登录成功: {student.name} ({student_id}), 会话ID: {session_id[:8]}...")
            flash(f'欢迎回来，{student.name}！', 'success')
            
            # 重定向到考试列表
            next_url = request.args.get('next') or url_for('student.exams')
            return redirect(next_url)
            
        except Exception as e:
            print(f"[ERROR] 学生登录失败: {e}")
            import traceback
            traceback.print_exc()
            flash('登录过程中发生错误，请重试', 'error')
            return render_template('auth/student_login.html')
    
    return render_template('auth/student_login.html')

@auth_bp.route('/student/login/force', methods=['POST'])
def force_student_login():
    """强制学生登录（踢出其他会话）"""
    pending_login = session.get('pending_login')
    
    if not pending_login:
        flash('会话信息已过期，请重新登录', 'error')
        return redirect(url_for('auth.student_login'))
    
    try:
        db = Database()
        
        # 创建新会话（这会自动将其他会话设为非活跃）
        success = db.create_student_session(
            student_number=pending_login['student_id'],
            student_name=pending_login['student_name'],
            session_id=pending_login['session_id'],
            ip_address=pending_login['ip_address'],
            user_agent=pending_login['user_agent']
        )
        
        if not success:
            flash('强制登录失败，请重试', 'error')
            return redirect(url_for('auth.student_login'))
        
        # 设置会话信息
        session.permanent = False  # 确保会话在浏览器关闭时失效
        session['user_type'] = 'student'
        session['student_id'] = pending_login['db_id']  # 确保设置student_id
        session['current_student_id'] = pending_login['db_id']  # 使用数据库ID保持一致性
        session['student_number'] = pending_login['student_id']
        session['student_name'] = pending_login['student_name']
        session['session_id'] = pending_login['session_id']
        session['login_time'] = datetime.now().isoformat()
        
        # 清除临时登录信息
        session.pop('pending_login', None)
        
        print(f"[SUCCESS] 强制登录成功: {pending_login['student_name']} ({pending_login['student_id']})")
        flash(f'强制登录成功！已踢出其他设备的登录。', 'success')
        
        return redirect(url_for('student.exams'))
        
    except Exception as e:
        print(f"[ERROR] 强制登录失败: {e}")
        flash('强制登录失败，请重试', 'error')
        return redirect(url_for('auth.student_login')) 
