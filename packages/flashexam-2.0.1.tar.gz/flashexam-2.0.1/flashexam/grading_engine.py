#!/usr/bin/env python3
"""
统一评分引擎 - 整合所有评分算法
支持多种评分方法：关键词、语义、AI轻量、AI增强、本地Qwen
"""

import os
import re
import json
import logging
from typing import Dict, List, Any, Optional, Union
from datetime import datetime
import jieba
from difflib import SequenceMatcher

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BaseGrader:
    """基础评分器"""
    
    def __init__(self):
        self.name = "BaseGrader"
    
    def grade(self, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """评分接口"""
        raise NotImplementedError("子类必须实现grade方法")
    
    def preprocess_text(self, text: str) -> str:
        """文本预处理"""
        if not text:
            return ""
        
        # 去除多余空格和换行
        text = re.sub(r'\s+', ' ', text.strip())
        # 统一标点符号
        text = text.replace('，', ',').replace('。', '.').replace('；', ';')
        return text

class KeywordGrader(BaseGrader):
    """关键词评分器"""
    
    def __init__(self):
        super().__init__()
        self.name = "KeywordGrader"
    
    def extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        text = self.preprocess_text(text)
        
        # 使用jieba分词
        words = jieba.lcut(text)
        
        # 过滤停用词和短词
        stop_words = {'的', '了', '在', '是', '有', '和', '与', '或', '但', '而', '因为', '所以', '如果', '那么'}
        keywords = [word for word in words if len(word) > 1 and word not in stop_words]
        
        return keywords
    
    def grade(self, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """关键词匹配评分"""
        if not student_answer or not student_answer.strip():
            return {
                'score': 0.0,
                'confidence': 1.0,
                'feedback': '答案为空',
                'method': self.name,
                'details': {'matched_keywords': [], 'total_keywords': 0}
            }
        
        # 提取关键词
        student_keywords = set(self.extract_keywords(student_answer))
        reference_keywords = set(self.extract_keywords(reference_answer))
        
        if not reference_keywords:
            return {
                'score': max_score * 0.5,
                'confidence': 0.3,
                'feedback': '参考答案无关键词，给予基础分',
                'method': self.name,
                'details': {'matched_keywords': [], 'total_keywords': 0}
            }
        
        # 计算匹配度
        matched_keywords = student_keywords.intersection(reference_keywords)
        match_ratio = len(matched_keywords) / len(reference_keywords)
        
        # 计算分数
        score = max_score * match_ratio
        
        # 调整置信度
        confidence = 0.8 if match_ratio > 0.5 else 0.6
        
        feedback = f"关键词匹配度: {match_ratio:.2%}, 匹配关键词: {', '.join(matched_keywords)}"
        
        return {
            'score': round(score, 2),
            'confidence': confidence,
            'feedback': feedback,
            'method': self.name,
            'details': {
                'matched_keywords': list(matched_keywords),
                'total_keywords': len(reference_keywords),
                'match_ratio': match_ratio
            }
        }

class SemanticGrader(BaseGrader):
    """语义相似度评分器"""
    
    def __init__(self):
        super().__init__()
        self.name = "SemanticGrader"
    
    def calculate_similarity(self, text1: str, text2: str) -> float:
        """计算文本相似度"""
        text1 = self.preprocess_text(text1)
        text2 = self.preprocess_text(text2)
        
        if not text1 or not text2:
            return 0.0
        
        # 使用SequenceMatcher计算相似度
        similarity = SequenceMatcher(None, text1, text2).ratio()
        
        # 使用jieba分词计算词汇相似度
        words1 = set(jieba.lcut(text1))
        words2 = set(jieba.lcut(text2))
        
        if words1 and words2:
            word_similarity = len(words1.intersection(words2)) / len(words1.union(words2))
            # 综合字符相似度和词汇相似度
            similarity = (similarity + word_similarity) / 2
        
        return similarity
    
    def grade(self, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """语义相似度评分"""
        if not student_answer or not student_answer.strip():
            return {
                'score': 0.0,
                'confidence': 1.0,
                'feedback': '答案为空',
                'method': self.name,
                'details': {'similarity': 0.0}
            }
        
        # 计算相似度
        similarity = self.calculate_similarity(student_answer, reference_answer)
        
        # 计算分数
        score = max_score * similarity
        
        # 调整置信度
        confidence = 0.7 if similarity > 0.3 else 0.5
        
        feedback = f"语义相似度: {similarity:.2%}"
        
        return {
            'score': round(score, 2),
            'confidence': confidence,
            'feedback': feedback,
            'method': self.name,
            'details': {'similarity': similarity}
        }

class AILiteGrader(BaseGrader):
    """AI轻量评分器"""
    
    def __init__(self):
        super().__init__()
        self.name = "AILiteGrader"
    
    def analyze_answer_quality(self, student_answer: str, reference_answer: str) -> Dict[str, float]:
        """分析答案质量"""
        student_answer = self.preprocess_text(student_answer)
        reference_answer = self.preprocess_text(reference_answer)
        
        # 长度分析
        length_ratio = min(len(student_answer) / max(len(reference_answer), 1), 2.0)
        length_score = min(length_ratio, 1.0)
        
        # 关键词覆盖度
        student_words = set(jieba.lcut(student_answer))
        reference_words = set(jieba.lcut(reference_answer))
        coverage = len(student_words.intersection(reference_words)) / max(len(reference_words), 1)
        
        # 结构完整性（简单检测）
        structure_score = 0.5
        if '因为' in student_answer or '由于' in student_answer:
            structure_score += 0.2
        if '所以' in student_answer or '因此' in student_answer:
            structure_score += 0.2
        if any(char in student_answer for char in '，。；：'):
            structure_score += 0.1
        
        structure_score = min(structure_score, 1.0)
        
        return {
            'length_score': length_score,
            'coverage_score': coverage,
            'structure_score': structure_score
        }
    
    def grade(self, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """AI轻量评分"""
        if not student_answer or not student_answer.strip():
            return {
                'score': 0.0,
                'confidence': 1.0,
                'feedback': '答案为空',
                'method': self.name,
                'details': {}
            }
        
        # 分析答案质量
        quality = self.analyze_answer_quality(student_answer, reference_answer)
        
        # 综合评分
        final_score = (
            quality['length_score'] * 0.3 +
            quality['coverage_score'] * 0.5 +
            quality['structure_score'] * 0.2
        )
        
        score = max_score * final_score
        confidence = 0.75
        
        feedback = f"综合评分: 长度{quality['length_score']:.2f}, 覆盖度{quality['coverage_score']:.2f}, 结构{quality['structure_score']:.2f}"
        
        return {
            'score': round(score, 2),
            'confidence': confidence,
            'feedback': feedback,
            'method': self.name,
            'details': quality
        }

class AIEnhancedGrader(BaseGrader):
    """AI增强评分器"""
    
    def __init__(self):
        super().__init__()
        self.name = "AIEnhancedGrader"
    
    def deep_analyze_answer(self, student_answer: str, reference_answer: str, 
                           question_text: str) -> Dict[str, Any]:
        """深度分析答案"""
        student_answer = self.preprocess_text(student_answer)
        reference_answer = self.preprocess_text(reference_answer)
        
        # 内容相关性分析
        relevance_score = self.calculate_relevance(student_answer, question_text, reference_answer)
        
        # 逻辑完整性分析
        logic_score = self.analyze_logic(student_answer)
        
        # 准确性分析
        accuracy_score = self.analyze_accuracy(student_answer, reference_answer)
        
        # 创新性分析
        innovation_score = self.analyze_innovation(student_answer, reference_answer)
        
        return {
            'relevance_score': relevance_score,
            'logic_score': logic_score,
            'accuracy_score': accuracy_score,
            'innovation_score': innovation_score
        }
    
    def calculate_relevance(self, student_answer: str, question_text: str, reference_answer: str) -> float:
        """计算相关性"""
        if not question_text:
            return 0.7  # 默认相关性
        
        # 提取问题关键词
        question_words = set(jieba.lcut(question_text))
        student_words = set(jieba.lcut(student_answer))
        
        # 计算问题相关性
        relevance = len(question_words.intersection(student_words)) / max(len(question_words), 1)
        return min(relevance * 1.5, 1.0)
    
    def analyze_logic(self, student_answer: str) -> float:
        """分析逻辑性"""
        logic_indicators = ['因为', '由于', '所以', '因此', '首先', '其次', '最后', '总之']
        logic_count = sum(1 for indicator in logic_indicators if indicator in student_answer)
        
        # 检查逻辑连接词
        logic_score = min(logic_count * 0.2, 1.0)
        
        # 检查句子结构
        sentences = re.split(r'[。！？]', student_answer)
        if len(sentences) > 1:
            logic_score += 0.2
        
        return min(logic_score, 1.0)
    
    def analyze_accuracy(self, student_answer: str, reference_answer: str) -> float:
        """分析准确性"""
        # 使用语义相似度作为准确性指标
        similarity = SequenceMatcher(None, student_answer, reference_answer).ratio()
        
        # 关键词匹配
        student_words = set(jieba.lcut(student_answer))
        reference_words = set(jieba.lcut(reference_answer))
        keyword_match = len(student_words.intersection(reference_words)) / max(len(reference_words), 1)
        
        return (similarity + keyword_match) / 2
    
    def analyze_innovation(self, student_answer: str, reference_answer: str) -> float:
        """分析创新性"""
        student_words = set(jieba.lcut(student_answer))
        reference_words = set(jieba.lcut(reference_answer))
        
        # 计算独特词汇比例
        unique_words = student_words - reference_words
        innovation_ratio = len(unique_words) / max(len(student_words), 1)
        
        # 适度的创新是好的，但不能偏离太多
        if innovation_ratio > 0.7:
            return 0.3  # 偏离太多
        elif innovation_ratio > 0.3:
            return 0.8  # 适度创新
        else:
            return 0.5  # 缺乏创新
    
    def grade(self, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """AI增强评分"""
        if not student_answer or not student_answer.strip():
            return {
                'score': 0.0,
                'confidence': 1.0,
                'feedback': '答案为空',
                'method': self.name,
                'details': {}
            }
        
        # 深度分析
        analysis = self.deep_analyze_answer(student_answer, reference_answer, question_text)
        
        # 综合评分
        final_score = (
            analysis['relevance_score'] * 0.3 +
            analysis['logic_score'] * 0.2 +
            analysis['accuracy_score'] * 0.4 +
            analysis['innovation_score'] * 0.1
        )
        
        score = max_score * final_score
        confidence = 0.85
        
        feedback = f"AI增强评分: 相关性{analysis['relevance_score']:.2f}, 逻辑性{analysis['logic_score']:.2f}, 准确性{analysis['accuracy_score']:.2f}"
        
        return {
            'score': round(score, 2),
            'confidence': confidence,
            'feedback': feedback,
            'method': self.name,
            'details': analysis
        }

class QwenGrader(BaseGrader):
    """本地Qwen模型评分器"""
    
    def __init__(self, model_path: Optional[str] = None):
        super().__init__()
        self.name = "QwenGrader"
        self.qwen_grader = None
        self.error_message = None
        
        # 尝试加载本地Qwen评分器
        try:
            from intelligent_grading_qwen import QwenIntelligentGrader
            self.qwen_grader = QwenIntelligentGrader(model_path)
            
            if self.qwen_grader and hasattr(self.qwen_grader, 'model') and self.qwen_grader.model:
                logger.info("本地Qwen评分器加载成功")
            else:
                self.error_message = "Qwen模型加载失败"
                logger.warning(self.error_message)
                
        except ImportError:
            self.error_message = "Qwen评分模块不可用"
            logger.warning(self.error_message)
        except Exception as e:
            self.error_message = f"Qwen评分器初始化失败: {e}"
            logger.warning(self.error_message)
    
    def grade(self, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """本地Qwen模型评分"""
        if not self.qwen_grader or self.error_message:
            # 回退到AI增强评分
            fallback_grader = AIEnhancedGrader()
            result = fallback_grader.grade(student_answer, reference_answer, question_text, max_score, **kwargs)
            result['method'] = f"{self.name}(Fallback)"
            
            error_detail = self.error_message or "Qwen不可用"
            result['feedback'] += f" [使用回退评分: {error_detail}]"
            
            logger.info(f"使用回退评分: {error_detail}")
            return result
        
        try:
            result = self.qwen_grader.intelligent_grade(
                student_answer, reference_answer, question_text, max_score
            )
            result['method'] = self.name
            return result
        except Exception as e:
            logger.error(f"Qwen评分失败: {e}")
            # 回退到AI增强评分
            fallback_grader = AIEnhancedGrader()
            result = fallback_grader.grade(student_answer, reference_answer, question_text, max_score, **kwargs)
            result['method'] = f"{self.name}(Error)"
            result['feedback'] += f" [评分错误: {str(e)}，使用回退评分]"
            return result

class GradingEngine:
    """统一评分引擎 - 专注本地模型与智能融合"""
    
    def __init__(self):
        """初始化评分引擎"""
        self.graders = {
            'keyword': KeywordGrader(),
            'semantic': SemanticGrader(),
            'ai_lite': AILiteGrader(),
            'ai_enhanced': AIEnhancedGrader(),
            'ai_qwen': QwenGrader()
        }
        
        # 评分方法优先级（从高到低）- 智能融合模式优先
        self.method_priority = ['ai_fusion', 'ai_qwen', 'ai_enhanced', 'ai_lite', 'semantic', 'keyword']
        
        logger.info(f"评分引擎初始化完成，可用方法: {list(self.graders.keys()) + ['ai_fusion']}")
        logger.info(f"优先级顺序: {self.method_priority}")
    
    def ai_fusion_grade(self, student_answer: str, reference_answer: str, 
                       question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """
        智能融合评分 - 结合语义分析和本地Qwen模型评分，取两者较高分数
        
        策略：
        1. 同时使用语义分析和Qwen模型评分
        2. 比较两种方法的结果
        3. 选择较高的分数，但保留详细的分析信息
        4. 提供融合策略的透明度
        """
        try:
            # 获取语义分析结果
            semantic_result = self.graders['semantic'].grade(
                student_answer, reference_answer, question_text, max_score, **kwargs
            )
            
            # 获取Qwen模型结果  
            qwen_result = self.graders['ai_qwen'].grade(
                student_answer, reference_answer, question_text, max_score, **kwargs
            )
            
            # 分析两种方法的结果
            semantic_score = semantic_result.get('score', 0.0)
            qwen_score = qwen_result.get('score', 0.0)
            
            # 选择较高的分数
            if qwen_score >= semantic_score:
                final_score = qwen_score
                primary_method = 'qwen'
                primary_confidence = qwen_result.get('confidence', 0.0)
                primary_feedback = qwen_result.get('feedback', '')
            else:
                final_score = semantic_score
                primary_method = 'semantic'
                primary_confidence = semantic_result.get('confidence', 0.0)
                primary_feedback = semantic_result.get('feedback', '')
            
            # 计算综合置信度（两种方法的平均置信度，偏向于选中的方法）
            semantic_confidence = semantic_result.get('confidence', 0.0)
            qwen_confidence = qwen_result.get('confidence', 0.0)
            avg_confidence = (semantic_confidence + qwen_confidence) / 2
            fusion_confidence = (primary_confidence * 0.7 + avg_confidence * 0.3)
            
            # 生成融合反馈
            fusion_feedback = self._generate_fusion_feedback(
                semantic_result, qwen_result, primary_method, final_score, max_score
            )
            
            # 构建详细结果
            details = {
                'semantic_result': {
                    'score': semantic_score,
                    'confidence': semantic_confidence,
                    'feedback': semantic_result.get('feedback', ''),
                    'details': semantic_result.get('details', {})
                },
                'qwen_result': {
                    'score': qwen_score,
                    'confidence': qwen_confidence,
                    'feedback': qwen_result.get('feedback', ''),
                    'details': qwen_result.get('details', {})
                },
                'fusion_strategy': 'take_higher',
                'selected_method': primary_method,
                'score_difference': abs(semantic_score - qwen_score),
                'weights': {
                    'semantic': 1.0 if primary_method == 'semantic' else 0.0,
                    'qwen': 1.0 if primary_method == 'qwen' else 0.0
                }
            }
            
            return {
                'score': final_score,
                'confidence': fusion_confidence,
                'feedback': fusion_feedback,
                'method': 'ai_fusion',
                'details': details,
                'grading_time': datetime.now().isoformat(),
                'engine_version': '2.2.0 - 智能融合专版'
            }
            
        except Exception as e:
            logger.error(f"智能融合评分失败: {e}")
            # 回退到Qwen模型
            try:
                fallback_result = self.graders['ai_qwen'].grade(
                    student_answer, reference_answer, question_text, max_score, **kwargs
                )
                fallback_result['method'] = 'ai_fusion(fallback_qwen)'
                fallback_result['feedback'] += ' [融合评分失败，使用Qwen模型]'
                return fallback_result
            except:
                return {
                    'score': 0.0,
                    'confidence': 0.0,
                    'feedback': f'融合评分系统错误: {str(e)}',
                    'method': 'ai_fusion(error)',
                    'details': {'error': str(e)},
                    'grading_time': datetime.now().isoformat(),
                    'engine_version': '2.2.0 - 智能融合专版'
                }
    
    def _generate_fusion_feedback(self, semantic_result: Dict, qwen_result: Dict, 
                                 primary_method: str, final_score: float, max_score: float) -> str:
        """生成融合评分的反馈信息"""
        semantic_score = semantic_result.get('score', 0.0)
        qwen_score = qwen_result.get('score', 0.0)
        
        # 基础反馈
        if primary_method == 'qwen':
            base_feedback = qwen_result.get('feedback', '')
            analysis_info = f"本地Qwen模型评分: {qwen_score:.1f}分，语义分析评分: {semantic_score:.1f}分。"
        else:
            base_feedback = semantic_result.get('feedback', '')
            analysis_info = f"语义分析评分: {semantic_score:.1f}分，本地Qwen模型评分: {qwen_score:.1f}分。"
        
        # 融合策略说明
        strategy_info = "采用智能融合策略，选择了较高的评分结果。"
        
        # 分数差异分析
        score_diff = abs(semantic_score - qwen_score)
        if score_diff < 0.5:
            consistency_info = "两种评分方法结果高度一致，说明答案质量评估可靠。"
        elif score_diff < 1.0:
            consistency_info = "两种评分方法结果基本一致，评分较为可靠。"
        else:
            consistency_info = "两种评分方法存在一定差异，已选择较优结果。"
        
        return f"{base_feedback} {analysis_info} {strategy_info} {consistency_info}"
    
    def select_best_method(self, question_type: str, student_answer: str, 
                          reference_answer: str = "") -> str:
        """自动选择最佳评分方法"""
        # 根据题目类型选择
        if question_type in ['choice', 'judge', 'fill']:
            return 'keyword'  # 客观题用关键词匹配
        
        # 主观题根据答案长度和复杂度选择
        answer_length = len(student_answer.strip()) if student_answer else 0
        
        if answer_length == 0:
            return 'keyword'  # 空答案用最简单的方法
        elif answer_length < 10:
            return 'semantic'  # 极短答案用语义相似度
        else:
            return 'ai_fusion'  # 其他情况都用智能融合评分（最高质量）
    
    def grade(self, question_type: str, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, 
              method: str = 'auto', **kwargs) -> Dict[str, Any]:
        """
        统一评分接口
        
        Args:
            question_type: 题目类型 (choice, judge, fill, subjective)
            student_answer: 学生答案
            reference_answer: 参考答案
            question_text: 题目文本
            max_score: 满分
            method: 评分方法 (auto, keyword, semantic, ai_lite, ai_enhanced, ai_qwen)
            **kwargs: 其他参数
        
        Returns:
            评分结果字典
        """
        # 自动选择方法
        if method == 'auto':
            method = self.select_best_method(question_type, student_answer, reference_answer)
        
        # 特殊处理融合评分
        if method == 'ai_fusion':
            return self.ai_fusion_grade(student_answer, reference_answer, question_text, max_score, **kwargs)
        
        # 检查方法是否可用
        if method not in self.graders:
            # logger.warning(f"评分方法 {method} 不可用，使用默认方法") # 抑制警告
            method = 'ai_fusion'  # 默认使用智能融合评分
            return self.ai_fusion_grade(student_answer, reference_answer, question_text, max_score, **kwargs)
        
        # 执行评分
        try:
            grader = self.graders[method]
            result = grader.grade(student_answer, reference_answer, question_text, max_score, **kwargs)
            
            # 添加元信息
            result.update({
                'question_type': question_type,
                'grading_time': datetime.now().isoformat(),
                'engine_version': '2.1.0 - 本地Qwen专版'
            })
            
            logger.debug(f"评分完成: {method}, 分数: {result['score']}")
            return result
            
        except Exception as e:
            logger.error(f"评分失败: {method}, 错误: {e}")
            
            # 回退到关键词评分
            try:
                fallback_grader = self.graders['keyword']
                result = fallback_grader.grade(student_answer, reference_answer, question_text, max_score, **kwargs)
                result['method'] = f"{method}(Fallback)"
                result['feedback'] += f" [评分失败，使用回退方法]"
                result.update({
                    'question_type': question_type,
                    'grading_time': datetime.now().isoformat(),
                    'engine_version': '2.1.0 - 本地Qwen专版'
                })
                return result
            except Exception as fallback_error:
                logger.error(f"回退评分也失败: {fallback_error}")
                return {
                    'score': 0.0,
                    'confidence': 0.0,
                    'feedback': f'评分系统错误: {str(e)}',
                    'method': f"{method}(Error)",
                    'question_type': question_type,
                    'grading_time': datetime.now().isoformat(),
                    'engine_version': '2.1.0 - 本地Qwen专版',
                    'details': {'error': str(e)}
                }
    
    def batch_grade(self, questions_data: List[Dict]) -> List[Dict]:
        """批量评分"""
        results = []
        
        for i, question_data in enumerate(questions_data):
            try:
                result = self.grade(
                    question_type=question_data.get('question_type', 'subjective'),
                    student_answer=question_data.get('student_answer', ''),
                    reference_answer=question_data.get('reference_answer', ''),
                    question_text=question_data.get('question_text', ''),
                    max_score=question_data.get('max_score', 5.0),
                    method=question_data.get('method', 'auto')
                )
                result['question_id'] = question_data.get('question_id', i)
                results.append(result)
                
            except Exception as e:
                logger.error(f"批量评分第{i}题失败: {e}")
                results.append({
                    'question_id': question_data.get('question_id', i),
                    'score': 0.0,
                    'confidence': 0.0,
                    'feedback': f'评分失败: {str(e)}',
                    'method': 'Error',
                    'question_type': question_data.get('question_type', 'subjective'),
                    'grading_time': datetime.now().isoformat(),
                    'engine_version': '2.1.0 - 本地Qwen专版'
                })
        
        return results
    
    def get_available_methods(self) -> List[str]:
        """获取可用的评分方法"""
        return list(self.graders.keys()) + ['ai_fusion']
    
    def get_method_info(self, method: str) -> Dict[str, str]:
        """获取评分方法信息"""
        if method == 'ai_fusion':
            return {
                'name': '智能融合评分',
                'description': '结合语义分析和本地Qwen模型的综合评分，取两者较高分数',
                'suitable_for': '所有主观题类型，确保最优评分质量'
            }
        
        if method not in self.graders:
            return {'error': f'方法 {method} 不存在'}
        
        grader = self.graders[method]
        return {
            'name': grader.name,
            'description': grader.__class__.__doc__ or '无描述',
            'suitable_for': self._get_method_suitability(method)
        }
    
    def _get_method_suitability(self, method: str) -> str:
        """获取方法适用性描述"""
        suitability_map = {
            'keyword': '客观题、关键词匹配',
            'semantic': '短答案、语义相似度',
            'ai_lite': '中等长度主观题',
            'ai_enhanced': '复杂主观题、算法评分',
            'ai_qwen': '高质量主观题评分(本地Qwen3-0.6B模型)',
            'ai_fusion': '所有主观题类型，智能融合评分策略'
        }
        return suitability_map.get(method, '通用')

# 全局评分引擎实例
_grading_engine = None

def get_grading_engine() -> GradingEngine:
    """获取全局评分引擎实例"""
    global _grading_engine
    if _grading_engine is None:
        _grading_engine = GradingEngine()
    return _grading_engine

def grade_answer(question_type: str, student_answer: str, reference_answer: str, 
                question_text: str = "", max_score: float = 5.0, 
                method: str = 'auto', **kwargs) -> Dict[str, Any]:
    """便捷评分函数"""
    engine = get_grading_engine()
    return engine.grade(question_type, student_answer, reference_answer, 
                       question_text, max_score, method, **kwargs)

if __name__ == "__main__":
    # 测试评分引擎
    engine = GradingEngine()
    
    test_cases = [
        {
            'question_type': 'subjective',
            'student_answer': '光合作用是植物利用阳光、水和二氧化碳制造有机物的过程',
            'reference_answer': '光合作用是绿色植物利用光能，将二氧化碳和水转化为有机物，并释放氧气的过程',
            'question_text': '什么是光合作用？',
            'max_score': 10.0
        }
    ]
    
    for test_case in test_cases:
        result = engine.grade(**test_case)
        print(f"评分结果: {json.dumps(result, ensure_ascii=False, indent=2)}") 