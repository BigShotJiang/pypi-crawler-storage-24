#!/usr/bin/env python3
"""
FlashExam CLI Entry Point
Command-line interface for starting the FlashExam server
"""

import os
import sys
import platform
import argparse
import signal
from pathlib import Path

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='FlashExam 在线考试系统',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
运行模式说明:
  dev        开发模式 - 启用调试，自动重载
  prod       生产模式 - 优化性能，稳定运行  
  high-perf  高性能模式 - 最大性能，监控支持

使用示例:
  flashexam                         # 开发模式
  flashexam --mode prod             # 生产模式
  flashexam --mode prod --port 8080 # 指定端口
  flashexam --init-db               # 初始化数据库
        """
    )
    
    parser.add_argument('--mode', 
                       choices=['dev', 'prod', 'high-perf'], 
                       default='dev', 
                       help='运行模式 (默认: dev)')
    
    parser.add_argument('--host', 
                       default='0.0.0.0', 
                       help='绑定地址 (默认: 0.0.0.0)')
    
    parser.add_argument('--port', 
                       type=int, 
                       default=5000, 
                       help='端口号 (默认: 5000)')
    
    parser.add_argument('--workers', 
                       type=int, 
                       default=4, 
                       help='工作进程数 (默认: 4)')
    
    parser.add_argument('--init-db', 
                       action='store_true',
                       help='初始化数据库')
    
    parser.add_argument('--version', 
                       action='version', 
                       version='FlashExam v%(prog)s')
    
    args = parser.parse_args()
    
    from . import __version__
    
    print("=" * 80)
    print("FlashExam 在线考试系统")
    print("=" * 80)
    print(f"运行平台: {platform.system()} {platform.release()}")
    print(f"Python版本: {sys.version.split()[0]}")
    print(f"运行模式: {args.mode}")
    print(f"绑定地址: {args.host}:{args.port}")
    print("=" * 80)
    
    if args.init_db:
        init_database()
        return
    
    if args.mode == 'dev':
        start_development_server(args)
    elif args.mode == 'prod':
        start_production_server(args)
    elif args.mode == 'high-perf':
        start_high_performance_server(args)

def init_database():
    """初始化数据库"""
    from .setup_database import init_database as _init_db
    _init_db()
    print("数据库初始化完成")

def start_development_server(args):
    """启动开发服务器"""
    print("启动开发模式...")
    
    from . import create_app
    app = create_app('development')
    
    from .database import Database
    db = Database()
    need_setup = not db.has_teacher_password()
    
    print("系统初始化完成")
    print(f"主页: http://{args.host}:{args.port}")
    
    if need_setup:
        print("首次启动，请设置管理员账户")
    else:
        print(f"教师端: http://{args.host}:{args.port}/teacher")
        print(f"学生端: http://{args.host}:{args.port}/student")
    
    print("-" * 50)
    
    app.run(
        host=args.host,
        port=args.port,
        debug=True,
        use_reloader=True
    )

def start_production_server(args):
    """启动生产服务器"""
    print("启动生产模式...")
    
    try:
        import waitress
    except ImportError:
        print("缺少waitress依赖，请运行: pip install waitress")
        sys.exit(1)
    
    from . import create_app
    app = create_app('production')
    
    print("生产环境初始化完成")
    print(f"服务地址: http://{args.host}:{args.port}")
    print(f"工作线程: {args.workers}")
    print("-" * 50)
    
    from waitress import serve
    serve(
        app,
        host=args.host,
        port=args.port,
        threads=args.workers * 4,
        connection_limit=1000,
        cleanup_interval=30,
        channel_timeout=120,
        log_socket_errors=True,
        expose_tracebacks=False
    )

def start_high_performance_server(args):
    """启动高性能服务器"""
    print("启动高性能模式...")
    
    try:
        import waitress
        import psutil
    except ImportError as e:
        print(f"缺少依赖: {e}")
        print("请运行: pip install waitress psutil")
        sys.exit(1)
    
    from . import create_app
    app = create_app('high-performance')
    
    print("高性能环境初始化完成")
    print(f"服务地址: http://{args.host}:{args.port}")
    print(f"工作线程: {args.workers * 4}")
    print(f"CPU核心: {psutil.cpu_count()}")
    print(f"系统内存: {psutil.virtual_memory().total / (1024**3):.1f}GB")
    print("-" * 50)
    
    from waitress import serve
    serve(
        app,
        host=args.host,
        port=args.port,
        threads=args.workers * 4,
        connection_limit=2000,
        cleanup_interval=15,
        channel_timeout=300,
        log_socket_errors=True,
        expose_tracebacks=False
    )

if __name__ == "__main__":
    main()