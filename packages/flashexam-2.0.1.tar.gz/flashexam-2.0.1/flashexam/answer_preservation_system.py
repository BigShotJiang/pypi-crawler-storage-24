#!/usr/bin/env python3
"""
答案保存系统 - 确保学生答题内容永不丢失
支持多层备份、自动恢复、时间连续性
集成Redis缓存层和异步写入，提升高并发性能
"""

import json
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
import sqlite3
import os
from concurrent.futures import ThreadPoolExecutor
from redis_store import RedisManager

class AnswerPreservationSystem:
    """答案保存系统 - 多层保护，确保答案永不丢失"""
    
    def __init__(self, db_path: str = None):
        # 使用绝对路径，确保在不同目录下调用时都能找到数据库
        if not db_path:
            base_dir = Path(__file__).resolve().parent.parent
            self.db_path = str(base_dir / 'storage' / 'exam_database.db')
        else:
            self.db_path = db_path
            
        print(f"[ANSWER_SYSTEM] 数据库路径: {self.db_path}")
        
        self.backup_dir = Path("storage/answer_backups")
        if not self.backup_dir.is_absolute():
             base_dir = Path(__file__).resolve().parent.parent
             self.backup_dir = base_dir / 'storage' / 'answer_backups'
             
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        print(f"[ANSWER_SYSTEM] 备份目录: {self.backup_dir}")
        
        # 内存缓存 - 最快的访问
        self.memory_cache = {}
        self.cache_lock = threading.Lock()
        
        # Redis管理器
        self.redis = RedisManager()
        self.use_redis = self.redis.is_available()
        
        # 异步写入队列
        self.write_queue_key = "exam_write_queue"
        self.is_running = True
        
        # 文件写入线程池 (处理磁盘IO)
        self.file_writer_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="FileWriter")
        
        # 初始化系统
        self._init_backup_tables()
        
        # 启动后台同步线程
        self.sync_thread = threading.Thread(target=self._sync_worker, daemon=True)
        self.sync_thread.start()
        
        print(f"[ANSWER_SYSTEM] 答案保存系统已初始化 (Redis: {'Enabled' if self.use_redis else 'Disabled'})")
    
    def _init_backup_tables(self):
        """初始化备份表"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 答案历史表 - 记录每次保存的完整历史
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS answer_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        exam_id INTEGER NOT NULL,
                        student_id INTEGER NOT NULL,
                        student_number TEXT NOT NULL,
                        answer_data TEXT NOT NULL,
                        save_time TEXT NOT NULL,
                        save_type TEXT DEFAULT 'auto',
                        elapsed_minutes REAL DEFAULT 0,
                        session_id TEXT,
                        ip_address TEXT,
                        is_final_submission INTEGER DEFAULT 0,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # 答案快照表 - 定期快照，用于快速恢复
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS answer_snapshots (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        exam_id INTEGER NOT NULL,
                        student_id INTEGER NOT NULL,
                        student_number TEXT NOT NULL,
                        answer_data TEXT NOT NULL,
                        snapshot_time TEXT NOT NULL,
                        elapsed_minutes REAL DEFAULT 0,
                        total_questions INTEGER DEFAULT 0,
                        answered_questions INTEGER DEFAULT 0,
                        completion_rate REAL DEFAULT 0,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(exam_id, student_id)
                    )
                ''')
                
                # 考试时间记录表 - 精确记录考试时间
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS exam_time_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        exam_id INTEGER NOT NULL,
                        student_id INTEGER NOT NULL,
                        student_number TEXT NOT NULL,
                        original_start_time TEXT NOT NULL,
                        last_activity_time TEXT NOT NULL,
                        total_elapsed_minutes REAL DEFAULT 0,
                        pause_count INTEGER DEFAULT 0,
                        resume_count INTEGER DEFAULT 0,
                        is_active INTEGER DEFAULT 1,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(exam_id, student_id)
                    )
                ''')
                
                print("[ANSWER_SYSTEM] 备份表初始化完成")
                
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 初始化备份表失败: {e}")
    
    def _sync_worker(self):
        """后台同步线程：从Redis队列读取数据并批量写入SQLite"""
        while self.is_running:
            if not self.use_redis:
                time.sleep(5)
                # 尝试重新连接Redis
                if self.redis.is_available():
                    self.use_redis = True
                    print("[ANSWER_SYSTEM] Redis连接已恢复，启用异步写入")
                continue
                
            try:
                # 批量获取任务 (增加到500以支持更高并发)
                tasks = self.redis.lpop_batch(self.write_queue_key, count=500)
                
                if not tasks:
                    time.sleep(0.5)  # 队列为空时短暂休眠
                    continue
                
                # 处理任务
                self._process_batch_writes(tasks)
                
            except Exception as e:
                print(f"[ANSWER_SYSTEM] 后台同步线程出错: {e}")
                time.sleep(1)

    def _write_backup_file(self, task: Dict[str, Any]):
        """写入备份文件的任务函数"""
        try:
            backup_file = self.backup_dir / f"exam_{task['exam_id']}_student_{task['student_id']}.json"
            with open(backup_file, 'w', encoding='utf-8') as f:
                json.dump(task, f, ensure_ascii=False, indent=2)
        except Exception:
            pass # 文件写入失败暂不处理

    def _process_batch_writes(self, tasks: List[str]):
        """批量处理写入任务"""
        try:
            parsed_tasks = []
            snapshots = {}  # 用于去重，只保存最新的快照
            
            for task_json in tasks:
                try:
                    task = json.loads(task_json)
                    parsed_tasks.append(task)
                    
                    # 记录每个学生最新的状态用于快照更新
                    key = (task['exam_id'], task['student_id'])
                    snapshots[key] = task
                except json.JSONDecodeError:
                    continue
            
            if not parsed_tasks:
                return

            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 1. 批量写入历史记录 (保留所有记录以确保完整可追溯)
                history_values = []
                for task in parsed_tasks:
                    history_values.append((
                        task['exam_id'], task['student_id'], task['student_number'],
                        json.dumps(task['answers'], ensure_ascii=False),
                        task['save_time'], task['save_type'], task['elapsed_minutes'],
                        task.get('session_id'), task.get('ip_address')
                    ))
                
                cursor.executemany('''
                    INSERT INTO answer_history 
                    (exam_id, student_id, student_number, answer_data, save_time, 
                     save_type, elapsed_minutes, session_id, ip_address)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', history_values)
                
                # 2. 批量更新快照 (只更新最新的)
                snapshot_values = []
                for task in snapshots.values():
                    answers = task['answers']
                    total_questions = len(answers)
                    answered_questions = sum(1 for v in answers.values() if v and v.strip())
                    completion_rate = (answered_questions / total_questions * 100) if total_questions > 0 else 0
                    
                    snapshot_values.append((
                        task['exam_id'], task['student_id'], task['student_number'],
                        json.dumps(answers, ensure_ascii=False),
                        task['save_time'], task['elapsed_minutes'],
                        total_questions, answered_questions, completion_rate
                    ))
                
                cursor.executemany('''
                    INSERT OR REPLACE INTO answer_snapshots 
                    (exam_id, student_id, student_number, answer_data, snapshot_time,
                     elapsed_minutes, total_questions, answered_questions, completion_rate)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', snapshot_values)
                
                # 3. 批量更新时间记录
                current_time = datetime.now().isoformat()
                time_values = []
                # 准备时间记录数据
                for task in snapshots.values():
                    time_values.append((
                        task['exam_id'], task['student_id'], task['student_number'],
                        task['exam_id'], task['student_id'], current_time, # subquery params
                        current_time, task['elapsed_minutes'], current_time
                    ))
                
                # 批量执行
                cursor.executemany('''
                    INSERT OR REPLACE INTO exam_time_records 
                    (exam_id, student_id, student_number, original_start_time,
                        last_activity_time, total_elapsed_minutes, updated_at)
                    VALUES (?, ?, ?, 
                            COALESCE((SELECT original_start_time FROM exam_time_records 
                                        WHERE exam_id = ? AND student_id = ?), ?),
                            ?, ?, ?)
                ''', time_values)

                # 4. 提交事务 (关键：先提交DB，释放锁)
                conn.commit()
            
            # 5. 文件备份 (提交到线程池处理，不阻塞主Worker循环)
            for task in snapshots.values():
                self.file_writer_pool.submit(self._write_backup_file, task)

            print(f"[ANSWER_SYSTEM] 异步批量保存成功: 处理 {len(parsed_tasks)} 条记录")
                
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 批量写入DB失败: {e}")

    def save_answers_comprehensive(self, exam_id: int, student_id: int, student_number: str, 
                                 answers: Dict[str, str], elapsed_minutes: float = 0,
                                 save_type: str = 'auto', session_id: str = None, 
                                 ip_address: str = None) -> Dict[str, bool]:
        """全面保存答案 - 多层备份"""
        results = {
            'redis_cache': False,
            'async_queue': False,
            'memory_cache': False,
            'database_history': False,
            'database_snapshot': False,
            'file_backup': False,
            'time_record': False
        }
        
        current_time = datetime.now().isoformat()
        
        # 1. Redis缓存与异步队列 (优先)
        if self.use_redis and self.redis.is_available():
            try:
                # 保存到Redis Hash (实时状态)
                redis_key = f"exam:{exam_id}:student:{student_id}"
                mapping = {
                    'answers': json.dumps(answers, ensure_ascii=False),
                    'elapsed_minutes': elapsed_minutes,
                    'save_time': current_time,
                    'student_number': student_number
                }
                if self.redis.hset(redis_key, mapping):
                    results['redis_cache'] = True
                
                # 推送到异步队列 (持久化)
                task_payload = {
                    'exam_id': exam_id,
                    'student_id': student_id,
                    'student_number': student_number,
                    'answers': answers,
                    'elapsed_minutes': elapsed_minutes,
                    'save_time': current_time,
                    'save_type': save_type,
                    'session_id': session_id,
                    'ip_address': ip_address
                }
                if self.redis.rpush(self.write_queue_key, json.dumps(task_payload, ensure_ascii=False)):
                    results['async_queue'] = True
                    
                # 如果Redis操作成功，直接返回，不再执行同步DB写入
                if results['redis_cache'] and results['async_queue']:
                    # 更新本地内存缓存作为二级缓存
                    with self.cache_lock:
                        self.memory_cache[f"{exam_id}_{student_id}"] = {
                            'answers': answers.copy(),
                            'elapsed_minutes': elapsed_minutes,
                            'save_time': current_time,
                            'save_type': save_type
                        }
                    # print(f"[ANSWER_SYSTEM] Redis异步保存成功 (队列+缓存)") # 减少日志输出
                    return results
                    
            except Exception as e:
                print(f"[ANSWER_SYSTEM] Redis操作失败，降级到同步写入: {e}")
                self.use_redis = False

        # --- 降级方案：同步写入 (原逻辑) ---
        
        cache_key = f"{exam_id}_{student_id}"
        
        try:
            # 1. 内存缓存保存
            with self.cache_lock:
                self.memory_cache[cache_key] = {
                    'answers': answers.copy(),
                    'elapsed_minutes': elapsed_minutes,
                    'save_time': current_time,
                    'save_type': save_type
                }
                results['memory_cache'] = True
            
            # 2. 数据库历史记录保存
            try:
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    cursor.execute('''
                        INSERT INTO answer_history 
                        (exam_id, student_id, student_number, answer_data, save_time, 
                         save_type, elapsed_minutes, session_id, ip_address)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (exam_id, student_id, student_number, 
                          json.dumps(answers, ensure_ascii=False),
                          current_time, save_type, elapsed_minutes, session_id, ip_address))
                    results['database_history'] = True
            except Exception as e:
                print(f"[ANSWER_SYSTEM] 数据库历史保存失败: {e}")
            
            # 3. 数据库快照保存
            try:
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    total_questions = len(answers)
                    answered_questions = sum(1 for v in answers.values() if v and v.strip())
                    completion_rate = (answered_questions / total_questions * 100) if total_questions > 0 else 0
                    
                    cursor.execute('''
                        INSERT OR REPLACE INTO answer_snapshots 
                        (exam_id, student_id, student_number, answer_data, snapshot_time,
                         elapsed_minutes, total_questions, answered_questions, completion_rate)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (exam_id, student_id, student_number,
                          json.dumps(answers, ensure_ascii=False),
                          current_time, elapsed_minutes, total_questions, 
                          answered_questions, completion_rate))
                    results['database_snapshot'] = True
            except Exception as e:
                print(f"[ANSWER_SYSTEM] 数据库快照保存失败: {e}")
            
            # 4. 文件备份保存
            try:
                backup_file = self.backup_dir / f"exam_{exam_id}_student_{student_id}.json"
                backup_data = {
                    'exam_id': exam_id,
                    'student_id': student_id,
                    'student_number': student_number,
                    'answers': answers,
                    'elapsed_minutes': elapsed_minutes,
                    'save_time': current_time,
                    'save_type': save_type,
                    'session_id': session_id,
                    'ip_address': ip_address
                }
                with open(backup_file, 'w', encoding='utf-8') as f:
                    json.dump(backup_data, f, ensure_ascii=False, indent=2)
                results['file_backup'] = True
            except Exception as e:
                print(f"[ANSWER_SYSTEM] 文件备份保存失败: {e}")
            
            # 5. 时间记录保存
            try:
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    cursor.execute('''
                        INSERT OR REPLACE INTO exam_time_records 
                        (exam_id, student_id, student_number, original_start_time,
                         last_activity_time, total_elapsed_minutes, updated_at)
                        VALUES (?, ?, ?, 
                                COALESCE((SELECT original_start_time FROM exam_time_records 
                                         WHERE exam_id = ? AND student_id = ?), ?),
                                ?, ?, ?)
                    ''', (exam_id, student_id, student_number, exam_id, student_id,
                          current_time, current_time, elapsed_minutes, current_time))
                    results['time_record'] = True
            except Exception as e:
                print(f"[ANSWER_SYSTEM] 时间记录保存失败: {e}")
            
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 全面保存过程出错: {e}")
        
        success_count = sum(results.values())
        print(f"[ANSWER_SYSTEM] 同步保存完成: {success_count}/5 个位置成功")
        
        return results
    
    def recover_answers_comprehensive(self, exam_id: int, student_id: int, 
                                    student_number: str) -> Dict[str, Any]:
        """全面恢复答案 - 多源合并"""
        recovery_result = {
            'success': False,
            'answers': {},
            'elapsed_minutes': 0.0,
            'original_start_time': None,
            'recovery_sources': [],
            'total_recovered': 0,
            'completion_rate': 0.0
        }
        
        cache_key = f"{exam_id}_{student_id}"
        all_answers = {}
        best_elapsed_minutes = 0.0
        original_start_time = None
        
        print(f"[ANSWER_SYSTEM] 开始全面恢复: 考试{exam_id}, 学生{student_id}")
        
        # 0. 从Redis恢复 (最新且最快)
        if self.use_redis and self.redis.is_available():
            try:
                redis_key = f"exam:{exam_id}:student:{student_id}"
                redis_data = self.redis.hgetall(redis_key)
                if redis_data:
                    if 'answers' in redis_data:
                        answers = json.loads(redis_data['answers'])
                        all_answers.update(answers)
                    if 'elapsed_minutes' in redis_data:
                        best_elapsed_minutes = max(best_elapsed_minutes, float(redis_data['elapsed_minutes']))
                    recovery_result['recovery_sources'].append('redis_cache')
                    print(f"[ANSWER_SYSTEM] 从Redis缓存恢复: {len(all_answers)} 个答案")
            except Exception as e:
                print(f"[ANSWER_SYSTEM] Redis恢复失败: {e}")

        # 1. 从内存缓存恢复
        try:
            with self.cache_lock:
                if cache_key in self.memory_cache:
                    cache_data = self.memory_cache[cache_key]
                    all_answers.update(cache_data['answers'])
                    best_elapsed_minutes = max(best_elapsed_minutes, cache_data['elapsed_minutes'])
                    recovery_result['recovery_sources'].append('memory_cache')
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 内存缓存恢复失败: {e}")
        
        # 2. 从数据库快照恢复
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT answer_data, elapsed_minutes, completion_rate
                    FROM answer_snapshots 
                    WHERE exam_id = ? AND student_id = ?
                    ORDER BY id DESC LIMIT 1
                ''', (exam_id, student_id))
                
                row = cursor.fetchone()
                if row:
                    snapshot_answers = json.loads(row[0])
                    for key, value in snapshot_answers.items():
                        if key not in all_answers or not all_answers[key]:
                            all_answers[key] = value
                    best_elapsed_minutes = max(best_elapsed_minutes, row[1] or 0)
                    recovery_result['completion_rate'] = row[2] or 0
                    recovery_result['recovery_sources'].append('database_snapshot')
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 数据库快照恢复失败: {e}")
        
        # 3. 从考试进度表恢复
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT answer_data, elapsed_minutes, start_time
                    FROM exam_progress 
                    WHERE exam_id = ? AND student_number = ? AND is_active = 1
                    ORDER BY id DESC LIMIT 1
                ''', (exam_id, student_number))
                
                row = cursor.fetchone()
                if row:
                    progress_answers = json.loads(row[0])
                    for key, value in progress_answers.items():
                        if key not in all_answers or not all_answers[key]:
                            all_answers[key] = value
                    best_elapsed_minutes = max(best_elapsed_minutes, row[1] or 0)
                    if not original_start_time and row[2]:
                        original_start_time = row[2]
                    recovery_result['recovery_sources'].append('exam_progress')
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 考试进度表恢复失败: {e}")
        
        # 4. 从时间记录表恢复
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT original_start_time, total_elapsed_minutes
                    FROM exam_time_records 
                    WHERE exam_id = ? AND student_id = ? AND is_active = 1
                    ORDER BY id DESC LIMIT 1
                ''', (exam_id, student_id))
                
                row = cursor.fetchone()
                if row:
                    if not original_start_time and row[0]:
                        original_start_time = row[0]
                    best_elapsed_minutes = max(best_elapsed_minutes, row[1] or 0)
                    recovery_result['recovery_sources'].append('time_records')
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 时间记录恢复失败: {e}")
        
        # 5. 从文件备份恢复
        try:
            backup_file = self.backup_dir / f"exam_{exam_id}_student_{student_id}.json"
            if backup_file.exists():
                with open(backup_file, 'r', encoding='utf-8') as f:
                    backup_data = json.load(f)
                    backup_answers = backup_data.get('answers', {})
                    for key, value in backup_answers.items():
                        if key not in all_answers or not all_answers[key]:
                            all_answers[key] = value
                    best_elapsed_minutes = max(best_elapsed_minutes, backup_data.get('elapsed_minutes', 0))
                    if not original_start_time and backup_data.get('save_time'):
                        original_start_time = backup_data['save_time']
                    recovery_result['recovery_sources'].append('file_backup')
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 文件备份恢复失败: {e}")
        
        # 整理恢复结果
        recovery_result['answers'] = all_answers
        recovery_result['elapsed_minutes'] = best_elapsed_minutes
        recovery_result['original_start_time'] = original_start_time
        recovery_result['total_recovered'] = len(all_answers)
        recovery_result['success'] = len(all_answers) > 0
        
        if not recovery_result['completion_rate'] and all_answers:
            answered_count = sum(1 for v in all_answers.values() if v and v.strip())
            recovery_result['completion_rate'] = (answered_count / len(all_answers) * 100) if all_answers else 0
        
        print(f"[ANSWER_SYSTEM] 恢复完成: {len(all_answers)} 个答案, {len(recovery_result['recovery_sources'])} 个来源")
        
        return recovery_result
    
    def mark_final_submission(self, exam_id: int, student_id: int, student_number: str,
                            final_answers: Dict[str, str], final_score: float = 0) -> bool:
        """标记最终提交"""
        try:
            current_time = datetime.now().isoformat()
            
            # 1. 确保Redis队列中的剩余数据已写入
            # (这里不等待队列清空，直接写入DB以确保最终提交的原子性)
            
            # 2. 保存最终提交到历史记录
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO answer_history 
                    (exam_id, student_id, student_number, answer_data, save_time, 
                     save_type, is_final_submission)
                    VALUES (?, ?, ?, ?, ?, 'final_submission', 1)
                ''', (exam_id, student_id, student_number,
                      json.dumps(final_answers, ensure_ascii=False), current_time))
                
                # 更新时间记录为非活跃
                cursor.execute('''
                    UPDATE exam_time_records 
                    SET is_active = 0, updated_at = ?
                    WHERE exam_id = ? AND student_id = ?
                ''', (current_time, exam_id, student_id))
                
                # 清除Redis缓存 (可选，也可以保留一段时间)
                if self.use_redis and self.redis.is_available():
                    self.redis.client.delete(f"exam:{exam_id}:student:{student_id}")
                
                print(f"[ANSWER_SYSTEM] 最终提交标记完成")
                
                try:
                    from database import Database
                    db = Database(self.db_path)
                    exam = db.get_exam_by_id(exam_id)
                    questions = db.get_exam_questions(exam_id)
                    max_total_score = sum(q.score or 1.0 for q in questions) if questions else (exam.total_score or 0.0)
                    
                    with sqlite3.connect(self.db_path) as conn2:
                        c2 = conn2.cursor()
                        c2.execute("""
                            SELECT id, is_completed FROM exam_results 
                            WHERE student_id = ? AND exam_id = ?
                        """, (student_id, exam_id))
                        row = c2.fetchone()
                        if row:
                            result_id = row[0]
                            if not row[1]:
                                c2.execute('''
                                    UPDATE exam_results 
                                    SET answers = ?, score = 0, total_score = ?, end_time = ?, is_completed = 1,
                                        is_graded = 0, needs_grading = 1
                                    WHERE id = ?
                                ''', (json.dumps(final_answers or {}, ensure_ascii=False), max_total_score, current_time, result_id))
                        else:
                            c2.execute('''
                                INSERT INTO exam_results 
                                (exam_id, student_id, answers, score, total_score, start_time, end_time, 
                                 is_completed, is_graded, needs_grading)
                                VALUES (?, ?, ?, 0, ?, ?, ?, 1, 0, 1)
                            ''', (exam_id, student_id, json.dumps(final_answers or {}, ensure_ascii=False),
                                  max_total_score, current_time, current_time))
                            result_id = c2.lastrowid
                        
                        if questions:
                            for i, q in enumerate(questions):
                                c2.execute("""
                                    SELECT id FROM question_scores 
                                    WHERE exam_result_id = ? AND question_id = ?
                                """, (result_id, q.id))
                                exist_q = c2.fetchone()
                                student_answer = (final_answers or {}).get(f'question_{q.id}', '')
                                max_score = q.score or 1.0
                                if exist_q:
                                    c2.execute('''
                                        UPDATE question_scores 
                                        SET student_answer = ?, score = 0, max_score = ?, is_correct = 0,
                                            is_manually_graded = 0, needs_grading = 1
                                        WHERE id = ?
                                    ''', (student_answer, max_score, exist_q[0]))
                                else:
                                    c2.execute('''
                                        INSERT INTO question_scores 
                                        (exam_result_id, question_id, question_order, student_answer, correct_answer,
                                         is_correct, score, max_score, question_type, question_text, 
                                         is_manually_graded, needs_grading)
                                        VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, ?, 0, 1)
                                    ''', (result_id, q.id, i + 1, student_answer, q.correct_answer,
                                          max_score, q.question_type, (q.question_text or '')[:200]))
                        conn2.commit()
                except Exception as e:
                    print(f"[ANSWER_SYSTEM] 兜底创建结果记录失败: {e}")
                
                return True
                
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 标记最终提交失败: {e}")
            return False
    
    def get_answer_history(self, exam_id: int, student_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """获取答案保存历史"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT save_time, save_type, elapsed_minutes, is_final_submission,
                           LENGTH(answer_data) as data_size
                    FROM answer_history 
                    WHERE exam_id = ? AND student_id = ?
                    ORDER BY id DESC LIMIT ?
                ''', (exam_id, student_id, limit))
                
                history = []
                for row in cursor.fetchall():
                    history.append({
                        'save_time': row[0],
                        'save_type': row[1],
                        'elapsed_minutes': row[2],
                        'is_final_submission': bool(row[3]),
                        'data_size': row[4]
                    })
                
                return history
                
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 获取答案历史失败: {e}")
            return []
    
    def cleanup_old_data(self, days_to_keep: int = 30) -> Dict[str, int]:
        """清理旧数据"""
        cleanup_result = {
            'history_cleaned': 0,
            'snapshots_cleaned': 0,
            'files_cleaned': 0
        }
        
        try:
            cutoff_date = (datetime.now() - timedelta(days=days_to_keep)).isoformat()
            
            # 清理历史记录（保留最终提交）
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    DELETE FROM answer_history 
                    WHERE created_at < ? AND is_final_submission = 0
                ''', (cutoff_date,))
                cleanup_result['history_cleaned'] = cursor.rowcount
            
            # 清理文件备份
            for backup_file in self.backup_dir.glob("*.json"):
                if backup_file.stat().st_mtime < time.time() - (days_to_keep * 24 * 3600):
                    backup_file.unlink()
                    cleanup_result['files_cleaned'] += 1
            
            print(f"[ANSWER_SYSTEM] 清理完成: {cleanup_result}")
            
        except Exception as e:
            print(f"[ANSWER_SYSTEM] 清理数据失败: {e}")
        
        return cleanup_result

# 全局实例
_answer_system = None

def get_answer_preservation_system() -> AnswerPreservationSystem:
    """获取答案保存系统实例"""
    global _answer_system
    if _answer_system is None:
        _answer_system = AnswerPreservationSystem()
    return _answer_system

def save_answers_safely(exam_id: int, student_id: int, student_number: str,
                       answers: Dict[str, str], elapsed_minutes: float = 0,
                       save_type: str = 'auto', session_id: str = None,
                       ip_address: str = None) -> Dict[str, bool]:
    """安全保存答案的便捷函数"""
    system = get_answer_preservation_system()
    return system.save_answers_comprehensive(
        exam_id, student_id, student_number, answers, elapsed_minutes,
        save_type, session_id, ip_address
    )

def recover_answers_safely(exam_id: int, student_id: int, student_number: str) -> Dict[str, Any]:
    """安全恢复答案的便捷函数"""
    system = get_answer_preservation_system()
    return system.recover_answers_comprehensive(exam_id, student_id, student_number)

def mark_final_submission(exam_id: int, student_id: int, student_number: str, 
                         result_id: int = None) -> bool:
    """标记最终提交的便捷函数"""
    system = get_answer_preservation_system()
    
    # 先恢复最新的答案
    recovery_result = system.recover_answers_comprehensive(exam_id, student_id, student_number)
    if recovery_result['success']:
        final_answers = recovery_result['answers']
    else:
        final_answers = {}
    
    # 标记为最终提交
    return system.mark_final_submission(exam_id, student_id, student_number, final_answers)
