import sys
import os
import time
import threading
import shutil
from datetime import datetime

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from exam_reliability_system import get_submission_optimizer, get_reliability_system
from database import Database

def test_queue_submission():
    print("Starting queue submission test...")
    
    # Use a test database
    test_db_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'storage', 'test_exam_database.db'))
    
    # Copy real DB schema if needed, or just let Database class init it
    if os.path.exists(test_db_path):
        os.remove(test_db_path)
        
    # Initialize DB
    db = Database(test_db_path)
    
    # Create a test exam and student
    with db.get_connection() as conn:
        cursor = conn.cursor()
        # Create exam
        cursor.execute("INSERT INTO exams (title, duration_minutes, is_active) VALUES ('Test Exam', 60, 1)")
        exam_id = cursor.lastrowid
        # Create question
        cursor.execute("INSERT INTO questions (question_text, score) VALUES ('Test Q1', 10)")
        q_id = cursor.lastrowid
        cursor.execute(f"INSERT INTO exam_questions (exam_id, question_id, question_order) VALUES ({exam_id}, {q_id}, 1)")
        # Create student
        cursor.execute("INSERT INTO students (student_id, name) VALUES ('test_student', 'Test User')")
        student_id = cursor.lastrowid
        conn.commit()
        
    print(f"Created test exam {exam_id} and student {student_id}")
    
    # Initialize reliability system with test DB
    reliability_system = get_reliability_system(test_db_path)
    optimizer = get_submission_optimizer(test_db_path)
    
    # Submit exam
    answers = {f'question_{q_id}': 'test answer'}
    student_number = 'test_student'
    
    print("Submitting exam...")
    result = optimizer.submit_with_optimization(exam_id, student_id, student_number, answers)
    
    print(f"Submission result: {result}")
    
    if result.get('queued'):
        print("Submission queued. Waiting for processing...")
        # Wait for processing
        max_wait = 10
        for i in range(max_wait):
            time.sleep(1)
            # Check DB directly
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT is_completed FROM exam_results WHERE exam_id=? AND student_id=?", (exam_id, student_id))
                row = cursor.fetchone()
                if row and row[0]:
                    print("Submission processed successfully!")
                    break
            print(f"Waiting... {i+1}/{max_wait}")
        else:
            print("Timeout waiting for submission processing.")
    elif result.get('success'):
        print("Submission processed immediately (synchronously or fast).")
    else:
        print("Submission failed.")

    # Cleanup
    # try:
    #     os.remove(test_db_path)
    # except:
    #     pass

if __name__ == "__main__":
    test_queue_submission()
