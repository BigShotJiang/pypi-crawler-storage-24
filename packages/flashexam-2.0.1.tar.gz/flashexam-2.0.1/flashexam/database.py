import sqlite3
import json
import os
import time
import functools
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any

from .models import Question, Exam, Student, ExamResult, QuestionScore

def retry_on_lock(max_retries=10, delay=0.02):
    """
    Decorator to retry database operations when locked.
    Uses exponential backoff strategy with faster retries.
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for i in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except sqlite3.OperationalError as e:
                    if "locked" in str(e):
                        if i < max_retries - 1:
                            # Exponential backoff: 0.02, 0.04, 0.08, 0.16...
                            sleep_time = delay * (2 ** i)
                            # Cap max sleep time to 0.5s to remain responsive
                            if sleep_time > 0.5:
                                sleep_time = 0.5
                            print(f"[DATABASE] Database locked in {func.__name__}, retrying in {sleep_time:.2f}s... ({i+1}/{max_retries})")
                            time.sleep(sleep_time)
                            continue
                    raise
            return func(*args, **kwargs)
        return wrapper
    return decorator

class Database:
    def __init__(self, db_path: str = None):
        if db_path is None:
            # 确保数据库路径正确
            current_dir = os.path.dirname(os.path.abspath(__file__))
            self.db_path = os.path.join(current_dir, '..', 'storage', 'exam_database.db')
            # 规范化路径
            self.db_path = os.path.normpath(self.db_path)
        else:
            self.db_path = db_path
        
        # 确保storage目录存在
        storage_dir = os.path.dirname(self.db_path)
        os.makedirs(storage_dir, exist_ok=True)
        
        print(f"[DATABASE] 数据库路径: {self.db_path}")
        self.init_database()
    
    def get_connection(self):
        """获取数据库连接（读操作建议使用）"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)  # 增加超时时间到30秒
        conn.row_factory = sqlite3.Row
        # Enable WAL mode for better concurrency
        conn.execute('PRAGMA journal_mode=WAL;')
        conn.execute('PRAGMA synchronous=NORMAL;')
        return conn
    
    def get_write_connection(self, max_retries=10, delay=0.02):
        """获取用于写入的数据库连接（使用IMMEDIATE事务防止死锁）"""
        for i in range(max_retries):
            try:
                conn = self.get_connection()
                # 立即获取写锁，避免"升级死锁"
                conn.execute('BEGIN IMMEDIATE')
                return conn
            except sqlite3.OperationalError as e:
                if "locked" in str(e):
                    if i < max_retries - 1:
                        sleep_time = delay * (2 ** i)
                        if sleep_time > 0.5:
                            sleep_time = 0.5
                        print(f"[DATABASE] Acquire write lock failed, retrying in {sleep_time:.2f}s... ({i+1}/{max_retries})")
                        time.sleep(sleep_time)
                        try:
                            conn.close()
                        except:
                            pass
                        continue
                if 'conn' in locals():
                    try:
                        conn.close()
                    except:
                        pass
                raise
        # Fallback (should be caught by loop, but for safety)
        conn = self.get_connection()
        conn.execute('BEGIN IMMEDIATE')
        return conn
    
    def init_database(self):
        """初始化数据库表"""
        with sqlite3.connect(self.db_path, timeout=30.0) as conn:
            cursor = conn.cursor()
            
            # 创建教师表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS teachers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL DEFAULT 'admin',
                    password_hash TEXT NOT NULL,
                    name TEXT DEFAULT '管理员',
                    email TEXT DEFAULT '',
                    is_active BOOLEAN DEFAULT 1,
                    last_login TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建题目表 - 支持总分
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS questions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question_text TEXT NOT NULL,
                    question_type TEXT DEFAULT 'choice',
                    options TEXT,
                    correct_answer TEXT,
                    score REAL DEFAULT 1.0,
                    difficulty TEXT DEFAULT 'medium',
                    subject TEXT DEFAULT '',
                    knowledge_point TEXT DEFAULT '',
                    material TEXT DEFAULT '',
                    material_type TEXT DEFAULT 'text',
                    import_batch TEXT DEFAULT '',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建考试表 - 支持总分
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS exams (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT,
                    duration_minutes INTEGER DEFAULT 60,
                    total_questions INTEGER DEFAULT 0,
                    total_score REAL DEFAULT 0.0,
                    is_active BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 检查学生表是否存在，如果不存在则创建
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS students (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT UNIQUE NOT NULL,
                    name TEXT NOT NULL,
                    password TEXT DEFAULT '',
                    college TEXT DEFAULT '',
                    major TEXT DEFAULT '',
                    class_name TEXT DEFAULT '',
                    gender TEXT DEFAULT '',
                    notes TEXT DEFAULT '',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建考试-题目关联表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS exam_questions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exam_id INTEGER,
                    question_id INTEGER,
                    question_order INTEGER,
                    FOREIGN KEY (exam_id) REFERENCES exams (id),
                    FOREIGN KEY (question_id) REFERENCES questions (id)
                )
            ''')
            
            # 创建考试结果表 - 新增字段支持进度保存和计时
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS exam_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exam_id INTEGER NOT NULL,
                    student_id INTEGER NOT NULL,
                    answers TEXT,
                    score REAL DEFAULT 0,
                    total_score REAL DEFAULT 0.0,
                    start_time TIMESTAMP,
                    end_time TIMESTAMP,
                    last_save_time TIMESTAMP,
                    elapsed_minutes REAL DEFAULT 0.0,
                    is_completed BOOLEAN DEFAULT 0,
                    FOREIGN KEY (exam_id) REFERENCES exams (id),
                    FOREIGN KEY (student_id) REFERENCES students (id)
                )
            ''')
            
            # 新增：考试进度详细保存表 - 按学号和考试ID存储
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS exam_progress (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exam_id INTEGER NOT NULL,
                    student_number TEXT NOT NULL,
                    student_name TEXT NOT NULL,
                    answer_data TEXT NOT NULL,
                    start_time TIMESTAMP NOT NULL,
                    last_save_time TIMESTAMP NOT NULL,
                    elapsed_minutes REAL DEFAULT 0.0,
                    session_id TEXT,
                    ip_address TEXT,
                    user_agent TEXT,
                    is_active BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(exam_id, student_number)
                )
            ''')
            
            # 创建题目得分详情表 - 支持按分值计分
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS question_scores (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exam_result_id INTEGER NOT NULL,
                    question_id INTEGER NOT NULL,
                    question_order INTEGER NOT NULL,
                    student_answer TEXT,
                    correct_answer TEXT,
                    is_correct BOOLEAN DEFAULT 0,
                    score REAL DEFAULT 0.0,
                    max_score REAL DEFAULT 0.0,
                    question_type TEXT,
                    question_text TEXT,
                    is_manually_graded BOOLEAN DEFAULT 0,
                    graded_by TEXT,
                    grade_comment TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (exam_result_id) REFERENCES exam_results (id),
                    FOREIGN KEY (question_id) REFERENCES questions (id)
                )
            ''')
            
            # 新增：学生登录会话表 - 防止重复登录
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS student_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_number TEXT NOT NULL,
                    student_name TEXT NOT NULL,
                    session_id TEXT UNIQUE NOT NULL,
                    ip_address TEXT,
                    user_agent TEXT,
                    login_time TIMESTAMP NOT NULL,
                    last_activity TIMESTAMP NOT NULL,
                    is_active BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
            
            # 检查并更新数据库结构
            self._migrate_database_schema()
            
            print("+ 数据库结构已是最新版本")
            print("+ 数据库初始化完成，学生表结构正确")
    
    @retry_on_lock()
    def _migrate_database_schema(self):
        """检查并迁移数据库结构，支持重试"""
        try:
            with self.get_write_connection() as conn:
                cursor = conn.cursor()
                
                # 检查并添加缺失的字段
                
                # 1. 为exam_results表添加延迟评分字段
                try:
                    cursor.execute("ALTER TABLE exam_results ADD COLUMN needs_grading BOOLEAN DEFAULT 1")
                    print("[MIGRATE] 添加 exam_results.needs_grading 字段")
                except sqlite3.OperationalError:
                    pass  # 字段已存在
                
                try:
                    cursor.execute("ALTER TABLE exam_results ADD COLUMN is_graded BOOLEAN DEFAULT 0")
                    print("[MIGRATE] 添加 exam_results.is_graded 字段")
                except sqlite3.OperationalError:
                    pass  # 字段已存在
                
                # 添加elapsed_minutes和last_save_time字段
                try:
                    cursor.execute("ALTER TABLE exam_results ADD COLUMN elapsed_minutes REAL DEFAULT 0.0")
                    print("[MIGRATE] 添加 exam_results.elapsed_minutes 字段")
                except sqlite3.OperationalError:
                    pass  # 字段已存在
                
                try:
                    cursor.execute("ALTER TABLE exam_results ADD COLUMN last_save_time TIMESTAMP")
                    print("[MIGRATE] 添加 exam_results.last_save_time 字段")
                except sqlite3.OperationalError:
                    pass  # 字段已存在
                
                # 添加切屏监控字段
                try:
                    cursor.execute("ALTER TABLE exam_results ADD COLUMN focus_lost_count INTEGER DEFAULT 0")
                    print("[MIGRATE] 添加 exam_results.focus_lost_count 字段")
                except sqlite3.OperationalError:
                    pass  # 字段已存在
                
                try:
                    cursor.execute("ALTER TABLE exam_results ADD COLUMN focus_lost_logs TEXT")
                    print("[MIGRATE] 添加 exam_results.focus_lost_logs 字段")
                except sqlite3.OperationalError:
                    pass  # 字段已存在
                
                # 2. 为question_scores表添加延迟评分字段
                try:
                    cursor.execute("ALTER TABLE question_scores ADD COLUMN needs_grading BOOLEAN DEFAULT 1")
                    print("[MIGRATE] 添加 question_scores.needs_grading 字段")
                except sqlite3.OperationalError:
                    pass  # 字段已存在
                
                # 3. 为question_scores表添加AI评分相关字段（如果不存在）
                ai_grading_fields = [
                    ("ai_score", "REAL DEFAULT 0"),
                    ("ai_confidence", "REAL DEFAULT 0"),
                    ("ai_feedback", "TEXT DEFAULT ''"),
                    ("ai_details", "TEXT DEFAULT ''"),
                    ("is_ai_graded", "BOOLEAN DEFAULT 0")
                ]
                
                for field_name, field_type in ai_grading_fields:
                    try:
                        cursor.execute(f"ALTER TABLE question_scores ADD COLUMN {field_name} {field_type}")
                        print(f"[MIGRATE] 添加 question_scores.{field_name} 字段")
                    except sqlite3.OperationalError:
                        pass  # 字段已存在
                
                # 4. 为exams表添加监控配置字段
                monitoring_fields = [
                    ("max_focus_warnings", "INTEGER DEFAULT 9"),
                    ("auto_submit_on_exceed", "BOOLEAN DEFAULT 1"),
                    ("warning_interval_seconds", "INTEGER DEFAULT 30"),
                    ("enable_focus_monitoring", "BOOLEAN DEFAULT 1")
                ]
                
                for field_name, field_type in monitoring_fields:
                    try:
                        cursor.execute(f"ALTER TABLE exams ADD COLUMN {field_name} {field_type}")
                        print(f"[MIGRATE] 添加 exams.{field_name} 字段")
                    except sqlite3.OperationalError:
                        pass  # 字段已存在
                
                # 5. 更新现有数据：标记已完成但未评分的考试需要评分
                cursor.execute("""
                    UPDATE exam_results 
                    SET needs_grading = 1, is_graded = 0
                    WHERE is_completed = 1 
                    AND (needs_grading IS NULL OR is_graded IS NULL)
                """)
                
                cursor.execute("""
                    UPDATE question_scores 
                    SET needs_grading = 1
                    WHERE needs_grading IS NULL
                """)
                
                # 6. 为questions表添加import_batch字段
                try:
                    cursor.execute("ALTER TABLE questions ADD COLUMN import_batch TEXT DEFAULT ''")
                    print("[MIGRATE] 添加 questions.import_batch 字段")
                except sqlite3.OperationalError:
                    pass  # 字段已存在
                
                conn.commit()
                print("[MIGRATE] 数据库结构迁移完成")
                
        except Exception as e:
            print(f"[ERROR] 数据库迁移失败: {e}")
            import traceback
            traceback.print_exc()
    
    # 题目相关操作
    def add_question(self, question: Question) -> int:
        """添加题目 - 支持分值、阅读材料和导入批次"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO questions (question_type, question_text, options, correct_answer, 
                                     score, difficulty, subject, material, import_batch)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (question.question_type, question.question_text, question.options, 
                  question.correct_answer, question.score, question.difficulty, 
                  question.subject, question.material, question.import_batch))
            return cursor.lastrowid
    
    def get_questions(self, import_batch: Optional[str] = None) -> List[Question]:
        """获取所有题目 - 支持分值、阅读材料和导入批次筛选"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            if import_batch:
                cursor.execute('''
                    SELECT id, question_type, question_text, options, correct_answer, 
                           score, difficulty, subject, material, created_at, import_batch
                    FROM questions 
                    WHERE import_batch = ?
                    ORDER BY id
                ''', (import_batch,))
            else:
                cursor.execute('''
                    SELECT id, question_type, question_text, options, correct_answer, 
                           score, difficulty, subject, material, created_at, import_batch
                    FROM questions ORDER BY id
                ''')
            
            questions = []
            for row in cursor.fetchall():
                question = Question(
                    id=row[0],
                    question_type=row[1],
                    question_text=row[2],
                    options=row[3] or "",
                    correct_answer=row[4],
                    score=row[5] or 1.0,
                    difficulty=row[6] or 1,
                    subject=row[7] or "",
                    material=row[8] or "",
                    created_at=row[9],
                    import_batch=row[10] or ""
                )
                questions.append(question)
            
            return questions

    def get_import_batches(self) -> List[str]:
        """获取所有唯一的导入批次"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT DISTINCT import_batch 
                FROM questions 
                WHERE import_batch IS NOT NULL AND import_batch != ''
                ORDER BY import_batch DESC
            ''')
            return [row[0] for row in cursor.fetchall()]
    
    def delete_question(self, question_id: int) -> bool:
        """删除题目"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM questions WHERE id = ?', (question_id,))
            return cursor.rowcount > 0
    
    def delete_questions_batch(self, question_ids: List[int]) -> int:
        """批量删除题目"""
        if not question_ids:
            return 0
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            # 使用参数化查询进行批量删除
            placeholders = ','.join(['?'] * len(question_ids))
            cursor.execute(f'DELETE FROM questions WHERE id IN ({placeholders})', question_ids)
            return cursor.rowcount
    
    def delete_all_questions(self) -> int:
        """删除所有题目"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            # 先获取总数
            cursor.execute('SELECT COUNT(*) FROM questions')
            count = cursor.fetchone()[0]
            
            # 删除所有题目
            cursor.execute('DELETE FROM questions')
            
            # 重置自增ID计数器
            cursor.execute("DELETE FROM sqlite_sequence WHERE name = 'questions'")
            
            return count
    
    def get_questions_count(self, question_type: Optional[str] = None) -> int:
        """获取题目总数"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            if question_type:
                cursor.execute('SELECT COUNT(*) FROM questions WHERE question_type = ?', (question_type,))
            else:
                cursor.execute('SELECT COUNT(*) FROM questions')
            return cursor.fetchone()[0]
    
    def check_question_exists(self, question_text: str) -> bool:
        """检查题目是否已存在（基于题干）"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            # 去除首尾空格后比较
            cursor.execute('SELECT COUNT(*) FROM questions WHERE TRIM(question_text) = TRIM(?)', (question_text,))
            return cursor.fetchone()[0] > 0
    
    def find_duplicate_questions(self, questions: List[Question]) -> Dict[str, Any]:
        """查找重复的题目
        
        Returns:
            Dict包含重复信息：
            - duplicate_count: 重复题目数量
            - duplicate_questions: 重复的题目列表
            - internal_duplicates: CSV内部重复的题目
        """
        duplicates = {
            'duplicate_count': 0,
            'duplicate_questions': [],
            'internal_duplicates': []
        }
        
        # 检查与数据库中现有题目的重复
        for i, question in enumerate(questions):
            if self.check_question_exists(question.question_text):
                duplicates['duplicate_questions'].append({
                    'index': i + 1,
                    'question_text': question.question_text[:50] + '...' if len(question.question_text) > 50 else question.question_text
                })
        
        # 检查CSV内部的重复
        seen_questions = {}
        for i, question in enumerate(questions):
            question_key = question.question_text.strip()
            if question_key in seen_questions:
                duplicates['internal_duplicates'].append({
                    'index': i + 1,
                    'original_index': seen_questions[question_key] + 1,
                    'question_text': question.question_text[:50] + '...' if len(question.question_text) > 50 else question.question_text
                })
            else:
                seen_questions[question_key] = i
        
        duplicates['duplicate_count'] = len(duplicates['duplicate_questions']) + len(duplicates['internal_duplicates'])
        
        return duplicates
    
    def get_question_by_id(self, question_id: int) -> Optional[Question]:
        """根据ID获取题目"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, question_type, question_text, options, correct_answer, 
                       score, difficulty, subject, material, created_at
                FROM questions WHERE id = ?
            ''', (question_id,))
            
            row = cursor.fetchone()
            if row:
                return Question(
                    id=row[0],
                    question_type=row[1],
                    question_text=row[2],
                    options=row[3] or "",
                    correct_answer=row[4],
                    score=row[5] or 1.0,
                    difficulty=row[6] or 1,
                    subject=row[7] or "",
                    material=row[8] or "",
                    created_at=row[9]
                )
            return None
    
    # 考试相关操作
    def create_exam(self, exam: Exam) -> int:
        """创建考试 - 支持总分"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO exams (title, description, duration_minutes, total_questions, total_score, is_active)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (exam.title, exam.description, exam.duration_minutes, 
                  exam.total_questions, exam.total_score, exam.is_active))
            return cursor.lastrowid

    def create_exam_with_questions(self, exam: Exam, question_ids: List[int]) -> int:
        """创建考试并关联题目"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 创建考试
            cursor.execute('''
                INSERT INTO exams (title, description, duration_minutes, total_questions, total_score, is_active)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (exam.title, exam.description, exam.duration_minutes, 
                  exam.total_questions, exam.total_score, exam.is_active))
            
            exam_id = cursor.lastrowid
            
            # 关联题目
            # Ensure question_ids are unique before inserting
            unique_question_ids = list(set(question_ids))
            for order, question_id in enumerate(unique_question_ids, 1):
                cursor.execute('''
                    INSERT INTO exam_questions (exam_id, question_id, question_order)
                    VALUES (?, ?, ?)
                ''', (exam_id, question_id, order))
            
            return exam_id

    def add_question_to_exam(self, exam_id: int, question_id: int, order: int):
        """添加题目到考试"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO exam_questions (exam_id, question_id, question_order)
                VALUES (?, ?, ?)
            ''', (exam_id, question_id, order))

    def get_exam_questions(self, exam_id: int) -> List[Question]:
        """获取考试的所有题目 - 支持分值和阅读材料，按题目类型排序"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT q.id, q.question_type, q.question_text, q.options, q.correct_answer,
                       q.score, q.difficulty, q.subject, q.material, q.created_at,
                       eq.question_order
                FROM questions q
                JOIN exam_questions eq ON q.id = eq.question_id
                WHERE eq.exam_id = ?
                ORDER BY 
                    CASE q.question_type
                        WHEN 'choice' THEN 1
                        WHEN 'judge' THEN 2
                        WHEN 'short_answer' THEN 3
                        WHEN 'fill_blank' THEN 4
                        WHEN 'essay' THEN 5
                        ELSE 6
                    END,
                    eq.question_order
            ''', (exam_id,))
            
            questions = []
            for row in cursor.fetchall():
                question = Question(
                    id=row[0],
                    question_type=row[1],
                    question_text=row[2],
                    options=row[3] or "",
                    correct_answer=row[4],
                    score=row[5] or 1.0,
                    difficulty=row[6] or 1,
                    subject=row[7] or "",
                    material=row[8] or "",
                    created_at=row[9]
                )
                questions.append(question)
            
            return questions

    def get_exam_by_id(self, exam_id: int) -> Optional[Exam]:
        """根据ID获取考试信息 - 支持总分和监控配置"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, title, description, duration_minutes, total_questions, 
                       total_score, is_active, created_at, max_focus_warnings, 
                       auto_submit_on_exceed, warning_interval_seconds, enable_focus_monitoring
                FROM exams WHERE id = ?
            ''', (exam_id,))
            
            row = cursor.fetchone()
            if row:
                return Exam(
                    id=row[0],
                    title=row[1],
                    description=row[2],
                    duration_minutes=row[3],
                    total_questions=row[4],
                    total_score=row[5] or 0.0,
                    is_active=bool(row[6]),
                    created_at=row[7],
                    max_focus_warnings=row[8] or 9,
                    auto_submit_on_exceed=bool(row[9] if row[9] is not None else 1),
                    warning_interval_seconds=row[10] or 30,
                    enable_focus_monitoring=bool(row[11] if row[11] is not None else 1)
                )
            return None

    def update_exam_totals(self, exam_id: int):
        """更新考试的题目数量和总分"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 计算题目数量和总分
            cursor.execute('''
                SELECT COUNT(*), COALESCE(SUM(q.score), 0)
                FROM exam_questions eq
                JOIN questions q ON eq.question_id = q.id
                WHERE eq.exam_id = ?
            ''', (exam_id,))
            
            result = cursor.fetchone()
            total_questions = result[0] if result else 0
            total_score = result[1] if result else 0.0
            
            # 更新考试表
            cursor.execute('''
                UPDATE exams 
                SET total_questions = ?, total_score = ?
                WHERE id = ?
            ''', (total_questions, total_score, exam_id))

    def get_exams(self) -> List[Exam]:
        """获取所有考试列表"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, title, description, duration_minutes, total_questions, 
                       total_score, is_active, created_at
                FROM exams 
                ORDER BY created_at DESC
            ''')
            
            exams = []
            for row in cursor.fetchall():
                exam = Exam(
                    id=row[0],
                    title=row[1],
                    description=row[2] or "",
                    duration_minutes=row[3],
                    total_questions=row[4],
                    total_score=row[5] or 0.0,
                    is_active=bool(row[6]),
                    created_at=row[7]
                )
                exams.append(exam)
            
            return exams
    
    # 学生相关操作
    def add_student(self, student: Student) -> int:
        """添加学生 - 严格按照CSV列名顺序: student_id,name,password,college,major,class_name,gender,notes"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute('''
                    INSERT INTO students (student_id, name, password, college, major, class_name, gender, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (student.student_id, student.name, student.password, student.college, 
                      student.major, student.class_name, student.gender, student.notes))
                return cursor.lastrowid
            except sqlite3.IntegrityError:
                return -1  # 学号已存在
    
    def check_student_exists(self, student_id: str) -> bool:
        """检查学号是否已存在"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM students WHERE student_id = ?', (student_id,))
            return cursor.fetchone()[0] > 0
    
    def update_student(self, student: Student) -> bool:
        """更新学生信息 - 严格按照CSV列名顺序"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE students 
                SET name = ?, password = ?, college = ?, major = ?, class_name = ?, gender = ?, notes = ?
                WHERE student_id = ?
            ''', (student.name, student.password, student.college, student.major, 
                  student.class_name, student.gender, student.notes, student.student_id))
            return cursor.rowcount > 0
    
    def get_student_by_id(self, student_id: str, by_internal_id: bool = False) -> Optional[Student]:
        """根据学号或内部ID获取学生"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            if by_internal_id:
                cursor.execute('SELECT * FROM students WHERE id = ?', (student_id,))
            else:
                cursor.execute('SELECT * FROM students WHERE student_id = ?', (student_id,))
            
            row = cursor.fetchone()
            
            if row:
                return Student(
                    id=row[0],
                    student_id=row[1],
                    name=row[2],
                    password=row[3] or "",
                    college=row[4] or "",
                    major=row[5] or "",
                    class_name=row[6] or "",
                    gender=row[7] or "",
                    notes=row[8] or "",
                    created_at=row[9]
                )
            return None
    
    def get_all_students(self) -> List[Student]:
        """获取所有学生 - 字段顺序: id,student_id,name,password,college,major,class_name,gender,notes,created_at"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM students ORDER BY student_id')
            
            rows = cursor.fetchall()
            students = []
            for row in rows:
                student = Student(
                    id=row[0],                    # id
                    student_id=row[1],           # student_id
                    name=row[2],                 # name
                    password=row[3] or "",       # password
                    college=row[4] or "",        # college
                    major=row[5] or "",          # major
                    class_name=row[6] or "",     # class_name
                    gender=row[7] or "",         # gender
                    notes=row[8] or "",          # notes
                    created_at=row[9]            # created_at
                )
                students.append(student)
            return students
    
    def delete_student(self, student_id: str) -> bool:
        """删除学生"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM students WHERE student_id = ?', (student_id,))
            return cursor.rowcount > 0
    
    def batch_delete_students(self, student_ids: List[str]) -> int:
        """批量删除学生"""
        if not student_ids:
            return 0
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            # 使用参数化查询防止SQL注入
            placeholders = ','.join(['?' for _ in student_ids])
            cursor.execute(f'DELETE FROM students WHERE student_id IN ({placeholders})', student_ids)
            return cursor.rowcount
    
    def delete_students_by_class(self, class_name: str) -> int:
        """按班级删除学生"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM students WHERE class_name = ?', (class_name,))
            return cursor.rowcount
    
    def delete_students_by_major(self, major: str) -> int:
        """按专业删除学生"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM students WHERE major = ?', (major,))
            return cursor.rowcount
    
    def delete_all_students(self) -> int:
        """删除所有学生"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM students')
            return cursor.rowcount
    
    def authenticate_student(self, student_id: str, password: str) -> Optional[Student]:
        """验证学生登录 - 字段顺序: id,student_id,name,password,college,major,class_name,gender,notes,created_at"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM students WHERE student_id = ? AND password = ?', (student_id, password))
            row = cursor.fetchone()
            
            if row:
                return Student(
                    id=row[0],                    # id
                    student_id=row[1],           # student_id
                    name=row[2],                 # name
                    password=row[3] or "",       # password
                    college=row[4] or "",        # college
                    major=row[5] or "",          # major
                    class_name=row[6] or "",     # class_name
                    gender=row[7] or "",         # gender
                    notes=row[8] or "",          # notes
                    created_at=row[9]            # created_at
                )
            return None
    
    def update_student_password(self, student_id: str, new_password: str) -> bool:
        """更新单个学生密码"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                'UPDATE students SET password = ? WHERE student_id = ?',
                (new_password, student_id)
            )
            return cursor.rowcount > 0
    
    def batch_reset_passwords_to_student_id(self) -> int:
        """批量重置所有学生密码为学号"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE students SET password = student_id')
            return cursor.rowcount
    
    def batch_reset_passwords_to_uniform(self, uniform_password: str) -> int:
        """批量重置所有学生密码为统一密码"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE students SET password = ?', (uniform_password,))
            return cursor.rowcount
    
    def get_student_password_info(self) -> List[Dict[str, Any]]:
        """获取所有学生的密码信息（用于管理）- 严格按照数据库字段顺序"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT student_id, name, password, college, major, class_name, created_at
                FROM students 
                ORDER BY student_id
            ''')
            
            rows = cursor.fetchall()
            password_info = []
            for row in rows:
                info = {
                    'student_id': row[0],        # student_id
                    'name': row[1],              # name
                    'password': row[2] or "",    # password
                    'college': row[3] or "",     # college
                    'major': row[4] or "",       # major
                    'class_name': row[5] or "",  # class_name
                    'created_at': row[6]         # created_at
                }
                password_info.append(info)
            return password_info
    
    # 考试结果相关操作
    def start_exam(self, exam_id: int, student_id: int) -> int:
        """开始考试 - 改进版，检查并清理旧的未完成记录"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # 首先检查是否有该学生对该考试的未完成记录
            cursor.execute('''
                SELECT id, start_time FROM exam_results 
                WHERE student_id = ? AND exam_id = ? AND is_completed = 0
            ''', (student_id, exam_id))
            existing_result = cursor.fetchone()
            
            if existing_result:
                result_id, start_time_str = existing_result
                
                # 检查是否超时
                start_time = datetime.fromisoformat(start_time_str)
                current_time = datetime.now()
                elapsed_minutes = (current_time - start_time).total_seconds() / 60
                
                # 获取考试时长
                cursor.execute('SELECT duration_minutes FROM exams WHERE id = ?', (exam_id,))
                exam_duration = cursor.fetchone()
                
                if exam_duration and elapsed_minutes >= exam_duration[0]:
                    # 考试已超时，自动标记为完成（0分）
                    print(f"考试已超时，自动标记为完成：学生ID={student_id}, 考试ID={exam_id}")
                    cursor.execute('''
                        UPDATE exam_results 
                        SET is_completed = 1, end_time = ?, score = 0
                        WHERE id = ?
                    ''', (current_time.isoformat(), result_id))
                    conn.commit()
                    
                    # 创建新的考试记录
                    cursor.execute('''
                        INSERT INTO exam_results (exam_id, student_id, start_time)
                        VALUES (?, ?, ?)
                    ''', (exam_id, student_id, datetime.now().isoformat()))
                    return cursor.lastrowid
                else:
                    # 考试未超时，继续使用现有记录
                    print(f"继续未完成的考试：学生ID={student_id}, 考试ID={exam_id}, 已用时={elapsed_minutes:.1f}分钟")
                    return result_id
            
            # 没有未完成记录，创建新记录
            cursor.execute('''
                INSERT INTO exam_results (exam_id, student_id, start_time)
                VALUES (?, ?, ?)
            ''', (exam_id, student_id, datetime.now().isoformat()))
            return cursor.lastrowid

    def cleanup_expired_exams(self) -> int:
        """清理所有超时的未完成考试"""
        count = 0
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # 查找所有未完成且已超时的考试
            cursor.execute('''
                SELECT er.id, er.start_time, e.duration_minutes
                FROM exam_results er
                JOIN exams e ON er.exam_id = e.id
                WHERE er.is_completed = 0
            ''')
            
            rows = cursor.fetchall()
            current_time = datetime.now()
            
            for row in rows:
                result_id, start_time_str, duration_minutes = row
                start_time = datetime.fromisoformat(start_time_str)
                elapsed_minutes = (current_time - start_time).total_seconds() / 60
                
                if elapsed_minutes >= duration_minutes:
                    # 超时了，标记为完成（0分）
                    cursor.execute('''
                        UPDATE exam_results 
                        SET is_completed = 1, end_time = ?, score = 0
                        WHERE id = ?
                    ''', (current_time.isoformat(), result_id))
                    count += 1
            
            conn.commit()
            return count

    def force_restart_exam(self, exam_id: int, student_id: int) -> bool:
        """强制重新开始考试 - 清理所有该学生对该考试的记录"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            try:
                # 删除未完成的考试记录
                cursor.execute('''
                    DELETE FROM exam_results 
                    WHERE student_id = ? AND exam_id = ? AND is_completed = 0
                ''', (student_id, exam_id))
                
                # 同时清理相关的题目得分记录
                cursor.execute('''
                    DELETE FROM question_scores 
                    WHERE exam_result_id IN (
                        SELECT id FROM exam_results 
                        WHERE student_id = ? AND exam_id = ? AND is_completed = 0
                    )
                ''', (student_id, exam_id))
                
                conn.commit()
                print(f"强制重启考试成功：学生ID={student_id}, 考试ID={exam_id}")
                return True
                
            except Exception as e:
                print(f"强制重启考试失败: {e}")
                conn.rollback()
                return False

    def get_incomplete_exam_info(self, student_id: int, exam_id: int) -> Optional[Dict[str, Any]]:
        """获取学生的未完成考试信息"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT er.id, er.start_time, e.duration_minutes, e.title
                FROM exam_results er
                JOIN exams e ON er.exam_id = e.id
                WHERE er.student_id = ? AND er.exam_id = ? AND er.is_completed = 0
            ''', (student_id, exam_id))
            
            result = cursor.fetchone()
            if result:
                result_id, start_time_str, duration_minutes, exam_title = result
                start_time = datetime.fromisoformat(start_time_str)
                current_time = datetime.now()
                elapsed_minutes = (current_time - start_time).total_seconds() / 60
                remaining_minutes = max(0, duration_minutes - elapsed_minutes)
                
                return {
                    'result_id': result_id,
                    'start_time': start_time_str,
                    'duration_minutes': duration_minutes,
                    'exam_title': exam_title,
                    'elapsed_minutes': elapsed_minutes,
                    'remaining_minutes': remaining_minutes,
                    'is_expired': remaining_minutes <= 0
                }
            
            return None
    
    # 题目得分详情相关操作
    @retry_on_lock()
    def save_question_scores(self, question_scores: List[QuestionScore]) -> bool:
        """保存题目得分详情"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                for qs in question_scores:
                    cursor.execute('''
                        INSERT INTO question_scores 
                        (exam_result_id, question_id, question_order, student_answer, 
                         correct_answer, is_correct, score, max_score, question_type, question_text)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (qs.exam_result_id, qs.question_id, qs.question_order, 
                          qs.student_answer, qs.correct_answer, qs.is_correct, 
                          qs.score, qs.max_score, qs.question_type, qs.question_text))
                conn.commit()
                return True
        except Exception as e:
            print(f"保存题目得分失败: {e}")
            return False
    
    def get_question_scores_by_result(self, exam_result_id: int) -> List[QuestionScore]:
        """根据考试结果ID获取题目得分详情"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM question_scores 
                WHERE exam_result_id = ? 
                ORDER BY 
                    CASE question_type
                        WHEN 'choice' THEN 1
                        WHEN 'judge' THEN 2
                        WHEN 'short_answer' THEN 3
                        WHEN 'fill_blank' THEN 4
                        WHEN 'essay' THEN 5
                        ELSE 6
                    END,
                    question_order
            ''', (exam_result_id,))
            
            rows = cursor.fetchall()
            question_scores = []
            for row in rows:
                qs = QuestionScore(
                    id=row[0],
                    exam_result_id=row[1],
                    question_id=row[2],
                    question_order=row[3],
                    student_answer=row[4],
                    correct_answer=row[5],
                    is_correct=bool(row[6]),
                    score=row[7],
                    max_score=row[8],
                    question_type=row[9],
                    question_text=row[10],
                    is_manually_graded=bool(row[11]) if len(row) > 11 else False,
                    graded_by=row[12] if len(row) > 12 else "",
                    grade_comment=row[13] if len(row) > 13 else "",
                    created_at=row[14] if len(row) > 14 else None,
                    updated_at=row[15] if len(row) > 15 else None
                )
                question_scores.append(qs)
            return question_scores
    
    @retry_on_lock()
    def update_question_score(self, question_score_id: int, new_score: float, 
                             graded_by: str = "", comment: str = "") -> tuple[bool, int]:
        """更新单个题目的分数，并返回成功状态和exam_result_id"""
        with self.get_write_connection() as conn:
            cursor = conn.cursor()
            
            # 先获取exam_result_id
            cursor.execute("SELECT exam_result_id FROM question_scores WHERE id = ?", (question_score_id,))
            result = cursor.fetchone()
            if not result:
                return False, 0
                
            exam_result_id = result[0]
            
            # 更新分数
            cursor.execute('''
                UPDATE question_scores 
                SET score = ?, is_manually_graded = 1, graded_by = ?, grade_comment = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (new_score, graded_by, comment, question_score_id))
            
            # 确保提交事务
            conn.commit()
            
            print(f"[DEBUG] 更新题目分数: question_score_id={question_score_id}, new_score={new_score}")
            
            return cursor.rowcount > 0, exam_result_id

    @retry_on_lock()
    def recalculate_exam_score(self, exam_result_id: int) -> float:
        """根据所有题目的分数重新计算并更新考试总分及评分状态"""
        with self.get_write_connection() as conn:
            cursor = conn.cursor()
            
            # 1. 计算总分
            cursor.execute("SELECT SUM(score) FROM question_scores WHERE exam_result_id = ?", (exam_result_id,))
            total_score_result = cursor.fetchone()
            new_total_score = total_score_result[0] if total_score_result and total_score_result[0] is not None else 0.0
            
            # 2. 检查评分状态
            # 检查是否有任何题目还需要评分 (needs_grading = 1)
            cursor.execute("""
                SELECT COUNT(*) FROM question_scores 
                WHERE exam_result_id = ? AND needs_grading = 1
            """, (exam_result_id,))
            needs_grading_count = cursor.fetchone()[0]
            
            # 检查是否所有题目都已经有分数或者被标记为已评分 (is_manually_graded=1 OR is_ai_graded=1 OR is_correct IS NOT NULL)
            # 这里简化逻辑：如果needs_grading_count为0，则认为已完成评分
            
            is_graded = 1 if needs_grading_count == 0 else 0
            needs_grading = 1 if needs_grading_count > 0 else 0
            
            # 3. 更新exam_results表
            cursor.execute("""
                UPDATE exam_results 
                SET score = ?, is_graded = ?, needs_grading = ?
                WHERE id = ?
            """, (new_total_score, is_graded, needs_grading, exam_result_id))
            
            # 确保提交事务
            conn.commit()
            
            print(f"[DEBUG] 重新计算总分与状态: exam_result_id={exam_result_id}, score={new_total_score}, is_graded={is_graded}")
            
            return new_total_score
    
    @retry_on_lock()
    def batch_update_question_scores(self, score_updates: List[Dict[str, Any]]) -> Dict[str, Any]:
        """批量更新题目得分
        
        Args:
            score_updates: 包含更新信息的列表，每个元素包含:
                - question_score_id: 题目得分ID
                - new_score: 新得分
                - graded_by: 评分人
                - comment: 评分备注
        
        Returns:
            Dict包含成功数量、失败数量和错误信息
        """
        success_count = 0
        failed_count = 0
        errors = []
        affected_exam_results = set()
        
        try:
            with self.get_write_connection() as conn:
                cursor = conn.cursor()
                
                for update in score_updates:
                    try:
                        question_score_id = update['question_score_id']
                        new_score = update['new_score']
                        graded_by = update.get('graded_by', '教师')
                        comment = update.get('comment', '')
                        
                        # 获取exam_result_id
                        cursor.execute('SELECT exam_result_id FROM question_scores WHERE id = ?', (question_score_id,))
                        row = cursor.fetchone()
                        if not row:
                            errors.append(f"未找到ID为{question_score_id}的题目得分记录")
                            failed_count += 1
                            continue
                        
                        exam_result_id = row[0]
                        affected_exam_results.add(exam_result_id)
                        
                        # 更新得分
                        cursor.execute('''
                            UPDATE question_scores 
                            SET score = ?, is_manually_graded = 1, graded_by = ?, 
                                grade_comment = ?, updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                        ''', (new_score, graded_by, comment, question_score_id))
                        
                        if cursor.rowcount > 0:
                            success_count += 1
                        else:
                            errors.append(f"更新题目得分ID {question_score_id} 失败")
                            failed_count += 1
                    
                    except Exception as e:
                        errors.append(f"更新题目得分ID {update.get('question_score_id', 'unknown')} 时出错: {str(e)}")
                        failed_count += 1
                
                conn.commit()
                
            # 重新计算所有受影响的考试结果总分和状态 (使用单独的连接以避免事务嵌套)
            for exam_result_id in affected_exam_results:
                try:
                    self.recalculate_exam_score(exam_result_id)
                except Exception as e:
                    print(f"[ERROR] 重新计算总分失败 (Result ID: {exam_result_id}): {e}")
            
            print(f"批量更新完成: 成功{success_count}个, 失败{failed_count}个")
                
        except Exception as e:
            errors.append(f"批量更新过程中发生错误: {str(e)}")
            print(f"批量更新题目得分失败: {e}")
            import traceback
            traceback.print_exc()
        
        return {
            'success_count': success_count,
            'failed_count': failed_count,
            'errors': errors,
            'affected_exams': len(affected_exam_results)
        }
    
    def get_detailed_exam_results_for_teacher(self, exam_id: int) -> List[Dict[str, Any]]:
        """获取教师端详细考试结果（包含每道题得分）"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 
                    er.id as result_id,
                    er.exam_id,
                    er.student_id,
                    er.score as total_score,
                    er.start_time,
                    er.end_time,
                    e.title as exam_title,
                    s.name as student_name,
                    s.student_id as student_number,
                    COALESCE(s.college, '') as college,
                    COALESCE(s.major, '') as major,
                    COALESCE(s.class_name, '') as class_name,
                    COALESCE(s.gender, '') as gender
                FROM exam_results er
                JOIN exams e ON er.exam_id = e.id
                JOIN students s ON er.student_id = s.id
                WHERE er.exam_id = ? AND er.is_completed = 1
                ORDER BY s.student_id
            ''', (exam_id,))
            
            rows = cursor.fetchall()
            results = []
            
            for row in rows:
                result = {
                    'result_id': row[0],
                    'exam_id': row[1],
                    'student_id': row[2],
                    'total_score': row[3],
                    'start_time': row[4],
                    'end_time': row[5],
                    'exam_title': row[6],
                    'student_name': row[7],
                    'student_number': row[8],
                    'college': row[9] or "",
                    'major': row[10] or "",
                    'class_name': row[11] or "",
                    'gender': row[12] or "",
                    'question_scores': self.get_question_scores_by_result(row[0])
                }
                results.append(result)
            
            return results
    
    def get_question_statistics(self, exam_id: int) -> List[Dict[str, Any]]:
        """获取考试中每道题的统计信息"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 
                    qs.question_id,
                    qs.question_order,
                    qs.question_text,
                    qs.question_type,
                    qs.correct_answer,
                    COUNT(*) as total_attempts,
                    SUM(CASE WHEN qs.is_correct = 1 THEN 1 ELSE 0 END) as correct_count,
                    AVG(qs.score) as avg_score,
                    qs.max_score
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.exam_id = ? AND er.is_completed = 1
                GROUP BY qs.question_id, qs.question_order, qs.question_text, 
                         qs.question_type, qs.correct_answer, qs.max_score
                ORDER BY qs.question_order
            ''', (exam_id,))
            
            rows = cursor.fetchall()
            statistics = []
            for row in rows:
                stat = {
                    'question_id': row[0],
                    'question_order': row[1],
                    'question_text': row[2],
                    'question_type': row[3],
                    'correct_answer': row[4],
                    'total_attempts': row[5],
                    'correct_count': row[6],
                    'correct_rate': (row[6] / row[5] * 100) if row[5] > 0 else 0,
                    'avg_score': row[7] or 0,
                    'max_score': row[8]
                }
                statistics.append(stat)
            return statistics
    
    def get_student_question_details(self, student_id: int, exam_id: int) -> List[Dict[str, Any]]:
        """获取学生考试详细信息"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT qs.id, qs.question_id, qs.question_order, qs.student_answer, 
                       qs.correct_answer, qs.is_correct, qs.score, qs.max_score,
                       qs.question_type, qs.question_text, qs.is_manually_graded,
                       qs.graded_by, qs.grade_comment, er.start_time,
                       q.options
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                LEFT JOIN questions q ON qs.question_id = q.id
                WHERE er.student_id = ? AND er.exam_id = ?
                ORDER BY 
                    CASE qs.question_type
                        WHEN 'choice' THEN 1
                        WHEN 'judge' THEN 2
                        WHEN 'short_answer' THEN 3
                        WHEN 'fill_blank' THEN 4
                        WHEN 'essay' THEN 5
                        ELSE 6
                    END,
                    qs.question_order
            ''', (student_id, exam_id))
            
            rows = cursor.fetchall()
            details = []
            for row in rows:
                detail = {
                    'id': row[0],
                    'question_id': row[1],
                    'question_order': row[2],
                    'student_answer': row[3],
                    'correct_answer': row[4],
                    'is_correct': bool(row[5]),
                    'score': row[6],
                    'max_score': row[7],
                    'question_type': row[8],
                    'question_text': row[9],
                    'is_manually_graded': bool(row[10]),
                    'graded_by': row[11],
                    'grade_comment': row[12],
                    'exam_time': row[13],
                    'options': {}
                }
                
                # 解析选项（如果是选择题）
                if row[14] and detail['question_type'] == 'choice':
                    try:
                        import json
                        detail['options'] = json.loads(row[14])
                    except:
                        # 尝试其他格式
                        try:
                            detail['options'] = eval(row[14])
                        except:
                            detail['options'] = {}
                
                details.append(detail)
            return details
    
    @retry_on_lock()
    def save_ai_grading_result(self, question_score_id: int, ai_result: Dict[str, Any]) -> bool:
        """保存AI评分结果"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                import json
                ai_details_json = json.dumps(ai_result.get('details', {}), ensure_ascii=False)
                
                cursor.execute('''
                    UPDATE question_scores 
                    SET ai_score = ?, ai_confidence = ?, ai_feedback = ?, 
                        ai_details = ?, is_ai_graded = 1, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (
                    ai_result.get('score', 0.0),
                    ai_result.get('confidence', 0.0),
                    ai_result.get('feedback', ''),
                    ai_details_json,
                    question_score_id
                ))
                
                conn.commit()
                return cursor.rowcount > 0
        
        except Exception as e:
            print(f"保存AI评分结果失败: {e}")
            return False
    
    def get_subjective_questions_for_ai_grading(self, exam_id: int) -> List[Dict[str, Any]]:
        """获取需要AI评分的主观题 - 自动排除客观题类型，支持所有其他类型"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # 使用排除法：排除客观题类型（选择题和判断题），其他所有类型都视为主观题
            # 这样可以自动支持未来新增的任何题目类型（如分析题、设计题等）
            cursor.execute('''
                SELECT 
                    qs.id as question_score_id,
                    qs.student_answer,
                    qs.correct_answer,
                    qs.question_text,
                    qs.max_score,
                    qs.is_ai_graded,
                    qs.is_manually_graded,
                    qs.ai_score,
                    qs.ai_confidence,
                    qs.ai_feedback,
                    qs.ai_details,
                    qs.question_type,
                    er.student_id,
                    s.name as student_name,
                    s.student_id as student_number,
                    qs.score as current_score,
                    qs.graded_by,
                    qs.grade_comment
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                JOIN students s ON er.student_id = s.id
                WHERE er.exam_id = ? 
                      AND qs.question_type NOT IN ('choice', 'judge')
                      AND er.is_completed = 1
                ORDER BY qs.question_order, s.student_id
            ''', (exam_id,))
            
            rows = cursor.fetchall()
            questions = []
            
            import json
            
            for row in rows:
                question = {
                    'question_score_id': row[0],
                    'student_answer': row[1],
                    'reference_answer': row[2],
                    'question_text': row[3],
                    'max_score': row[4],
                    'is_ai_graded': bool(row[5]),
                    'is_manually_graded': bool(row[6]),
                    'ai_score': row[7] if row[7] is not None else 0.0,
                    'ai_confidence': row[8] if row[8] is not None else 0.0,
                    'ai_feedback': row[9] if row[9] is not None else '',
                    'question_type': row[11],
                    'student_id': row[12],
                    'student_name': row[13],
                    'student_number': row[14],
                    'current_score': row[15] if row[15] is not None else 0.0,
                    'graded_by': row[16] if row[16] is not None else '',
                    'grading_comment': row[17] if row[17] is not None else ''
                }
                
                # 解析AI详细信息
                ai_details_raw = row[10]
                if ai_details_raw:
                    try:
                        # 确保ai_details_raw是字符串，再进行JSON解析
                        if isinstance(ai_details_raw, str):
                            ai_details = json.loads(ai_details_raw)
                        elif isinstance(ai_details_raw, dict):
                            ai_details = ai_details_raw
                        else:
                            print(f"AI详情数据类型未知: {type(ai_details_raw)}")
                            ai_details = {}
                        
                        # 确保ai_details是字典类型再使用.get()方法
                        if isinstance(ai_details, dict):
                            # 提取语义分析结果
                            semantic_result = ai_details.get('semantic_result', {})
                            if semantic_result and isinstance(semantic_result, dict):
                                question['semantic_score'] = semantic_result.get('score', 0.0)
                                question['semantic_confidence'] = semantic_result.get('confidence', 0.0)
                                question['semantic_feedback'] = semantic_result.get('feedback', '')
                            else:
                                question['semantic_score'] = 0.0
                                question['semantic_confidence'] = 0.0
                                question['semantic_feedback'] = ''
                            
                            # 提取AI模型结果
                            ai_result = ai_details.get('ai_result', {})
                            if ai_result and isinstance(ai_result, dict):
                                question['ai_model_score'] = ai_result.get('score', 0.0)
                                question['ai_model_confidence'] = ai_result.get('confidence', 0.0)
                                question['ai_model_feedback'] = ai_result.get('feedback', '')
                            else:
                                question['ai_model_score'] = 0.0
                                question['ai_model_confidence'] = 0.0
                                question['ai_model_feedback'] = ''
                            
                            # 评分策略信息
                            question['combination_strategy'] = ai_details.get('combination_strategy', '')
                            weights = ai_details.get('weights', {})
                            if isinstance(weights, dict):
                                question['ai_method'] = weights.get('semantic', 0) > 0 and weights.get('ai', 0) > 0 and '综合评分' or '增强AI评分'
                            else:
                                question['ai_method'] = '增强AI评分'
                            
                            # 详细分析
                            semantic_details = semantic_result.get('details', {}) if isinstance(semantic_result, dict) else {}
                            if semantic_details:
                                analysis_parts = []
                                if 'semantic_similarity' in semantic_details:
                                    analysis_parts.append(f"语义相似度: {semantic_details['semantic_similarity']:.2f}")
                                if 'completeness' in semantic_details:
                                    analysis_parts.append(f"完整性: {semantic_details['completeness']:.2f}")
                                if analysis_parts:
                                    question['detailed_analysis'] = "; ".join(analysis_parts)
                            
                            # 评分策略说明
                            if 'combination_strategy' in ai_details:
                                if ai_details['combination_strategy'] == 'take_higher':
                                    question['score_selection_reason'] = '取高分策略 - 选择较高的评分结果'
                                elif ai_details['combination_strategy'] == 'weighted_average':
                                    question['score_selection_reason'] = '加权平均策略 - 综合两种评分方法'
                                else:
                                    question['score_selection_reason'] = '基于最优评分方法的结果'
                        else:
                            print(f"AI详情解析后不是字典类型: {type(ai_details)}")
                            # 设置默认值
                            question['semantic_score'] = 0.0
                            question['semantic_confidence'] = 0.0
                            question['semantic_feedback'] = ''
                            question['ai_model_score'] = 0.0
                            question['ai_model_confidence'] = 0.0
                            question['ai_model_feedback'] = ''
                            question['ai_method'] = '增强AI评分'
                        
                    except (json.JSONDecodeError, KeyError, TypeError) as e:
                        print(f"解析AI详细信息失败 (question_score_id: {row[0]}): {e}")
                        # 设置默认值
                        question['semantic_score'] = 0.0
                        question['semantic_confidence'] = 0.0
                        question['semantic_feedback'] = ''
                        question['ai_model_score'] = 0.0
                        question['ai_model_confidence'] = 0.0
                        question['ai_model_feedback'] = ''
                        question['ai_method'] = '增强AI评分'
                else:
                    # 如果没有AI详情，设置默认值
                    question['semantic_score'] = 0.0
                    question['semantic_confidence'] = 0.0
                    question['semantic_feedback'] = ''
                    question['ai_model_score'] = 0.0
                    question['ai_model_confidence'] = 0.0
                    question['ai_model_feedback'] = ''
                    question['ai_method'] = '增强AI评分'
                
                questions.append(question)
            
            return questions
    
    # 保持向后兼容性的别名
    def get_essay_questions_for_ai_grading(self, exam_id: int) -> List[Dict[str, Any]]:
        """获取需要AI评分的主观题 - 兼容性别名"""
        return self.get_subjective_questions_for_ai_grading(exam_id)
    
    @retry_on_lock()
    def batch_save_ai_grading_results(self, ai_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """批量保存AI评分结果"""
        success_count = 0
        failed_count = 0
        errors = []
        affected_exam_results = set()
        
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                import json
                
                for result in ai_results:
                    try:
                        question_score_id = result['question_score_id']
                        ai_data = result['ai_result']
                        
                        # 获取exam_result_id
                        cursor.execute('SELECT exam_result_id FROM question_scores WHERE id = ?', (question_score_id,))
                        row = cursor.fetchone()
                        if not row:
                            errors.append(f"未找到ID为{question_score_id}的题目得分记录")
                            failed_count += 1
                            continue
                        
                        exam_result_id = row[0]
                        affected_exam_results.add(exam_result_id)
                        
                        # 保存AI评分结果
                        ai_details_json = json.dumps(ai_data.get('details', {}), ensure_ascii=False)
                        
                        cursor.execute('''
                            UPDATE question_scores 
                            SET ai_score = ?, ai_confidence = ?, ai_feedback = ?, 
                                ai_details = ?, is_ai_graded = 1, 
                                score = ?, updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                        ''', (
                            ai_data.get('score', 0.0),
                            ai_data.get('confidence', 0.0),
                            ai_data.get('feedback', ''),
                            ai_details_json,
                            ai_data.get('score', 0.0),  # 同时更新实际得分
                            question_score_id
                        ))
                        
                        if cursor.rowcount > 0:
                            success_count += 1
                        else:
                            errors.append(f"更新题目得分ID {question_score_id} 失败")
                            failed_count += 1
                    
                    except Exception as e:
                        errors.append(f"处理题目得分ID {result.get('question_score_id', 'unknown')} 时出错: {str(e)}")
                        failed_count += 1
                
                # 重新计算所有受影响的考试结果总分和状态
                for exam_result_id in affected_exam_results:
                    # 使用新的同步逻辑
                    self.recalculate_exam_score(exam_result_id)
                
                conn.commit()
                print(f"批量AI评分完成: 成功{success_count}个, 失败{failed_count}个")
                
        except Exception as e:
            errors.append(f"批量AI评分过程中发生错误: {str(e)}")
            print(f"批量AI评分失败: {e}")
            import traceback
            traceback.print_exc()
        
        return {
            'success_count': success_count,
            'failed_count': failed_count,
            'errors': errors,
            'affected_exams': len(affected_exam_results)
        }
    
    def get_ai_grading_statistics(self, exam_id: int) -> Dict[str, Any]:
        """获取AI评分统计信息 - 自动排除客观题类型，支持所有其他类型"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # 使用排除法：排除客观题类型（选择题和判断题），其他所有类型都视为主观题
            # 这样可以自动支持未来新增的任何题目类型（如分析题、设计题等）
            
            # 获取主观题总数
            cursor.execute('''
                SELECT COUNT(*) as total_subjective
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.exam_id = ? 
                      AND qs.question_type NOT IN ('choice', 'judge') 
                      AND er.is_completed = 1
            ''', (exam_id,))
            total_subjective = cursor.fetchone()[0]
            
            # 获取AI已评分数量
            cursor.execute('''
                SELECT COUNT(*) as ai_graded
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.exam_id = ? 
                      AND qs.question_type NOT IN ('choice', 'judge')
                      AND qs.is_ai_graded = 1 AND er.is_completed = 1
            ''', (exam_id,))
            ai_graded = cursor.fetchone()[0]
            
            # 获取人工已评分数量
            cursor.execute('''
                SELECT COUNT(*) as manually_graded
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.exam_id = ? 
                      AND qs.question_type NOT IN ('choice', 'judge')
                      AND qs.is_manually_graded = 1 AND er.is_completed = 1
            ''', (exam_id,))
            manually_graded = cursor.fetchone()[0]
            
            # 获取平均AI置信度
            cursor.execute('''
                SELECT AVG(qs.ai_confidence) as avg_confidence
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.exam_id = ? 
                      AND qs.question_type NOT IN ('choice', 'judge')
                      AND qs.is_ai_graded = 1 AND er.is_completed = 1
            ''', (exam_id,))
            avg_confidence_result = cursor.fetchone()
            avg_confidence = avg_confidence_result[0] if avg_confidence_result[0] else 0.0
            
            # 按题目类型统计（只统计主观题类型）
            cursor.execute('''
                SELECT qs.question_type, COUNT(*) as count
                FROM question_scores qs
                JOIN exam_results er ON qs.exam_result_id = er.id
                WHERE er.exam_id = ? 
                      AND qs.question_type NOT IN ('choice', 'judge') 
                      AND er.is_completed = 1
                GROUP BY qs.question_type
            ''', (exam_id,))
            type_distribution = dict(cursor.fetchall())
            
            return {
                'total_subjective': total_subjective,  # 更新字段名
                'total_essays': total_subjective,  # 保持向后兼容
                'ai_graded': ai_graded,
                'manually_graded': manually_graded,
                'ungraded': total_subjective - max(ai_graded, manually_graded),
                'avg_confidence': round(avg_confidence, 3),
                'ai_coverage': round(ai_graded / total_subjective * 100, 1) if total_subjective > 0 else 0.0,
                'type_distribution': type_distribution
            }
    
    # 教师管理相关方法
    def has_teacher_password(self) -> bool:
        """检查是否已设置教师密码"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM teachers WHERE is_active = 1')
            result = cursor.fetchone()
            return result[0] > 0
    
    def set_teacher_password(self, username: str = 'admin', password: str = '', name: str = '管理员', email: str = '') -> bool:
        """设置教师密码"""
        try:
            # 使用bcrypt进行密码哈希
            import bcrypt
            
            # 生成盐值并哈希密码
            salt = bcrypt.gensalt()
            password_hash = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 检查是否已存在教师账户
                cursor.execute('SELECT COUNT(*) FROM teachers WHERE is_active = 1')
                existing_count = cursor.fetchone()[0]
                
                if existing_count > 0:
                    print("- 教师账户已存在，无法重复设置")
                    return False
                
                # 插入新的教师记录
                cursor.execute('''
                    INSERT INTO teachers (username, password_hash, name, email, is_active, created_at, updated_at)
                    VALUES (?, ?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ''', (username, password_hash, name, email))
                
                conn.commit()
                print(f"+ 教师密码设置成功: {username}")
                return True
                
        except ImportError:
            print("- bcrypt未安装，使用SHA-256作为备选方案")
            # 备选方案：使用SHA-256
            import hashlib
            import secrets
            
            # 生成随机盐值
            salt = secrets.token_hex(32)
            password_hash = hashlib.sha256((password + salt).encode('utf-8')).hexdigest()
            # 将盐值和哈希值组合存储
            stored_hash = f"sha256${salt}${password_hash}"
            
            try:
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    
                    # 检查是否已存在教师账户
                    cursor.execute('SELECT COUNT(*) FROM teachers WHERE is_active = 1')
                    existing_count = cursor.fetchone()[0]
                    
                    if existing_count > 0:
                        print("- 教师账户已存在，无法重复设置")
                        return False
                    
                    cursor.execute('''
                        INSERT INTO teachers (username, password_hash, name, email, is_active, created_at, updated_at)
                        VALUES (?, ?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ''', (username, stored_hash, name, email))
                    
                    conn.commit()
                    print(f"+ 教师密码设置成功: {username} (使用SHA-256)")
                    return True
                    
            except Exception as e:
                print(f"- 教师密码设置失败: {e}")
                return False
                
        except Exception as e:
            print(f"- 教师密码设置失败: {e}")
            return False
    
    def verify_teacher_password(self, username: str, password: str) -> bool:
        """验证教师密码"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT id, password_hash FROM teachers 
                    WHERE username = ? AND is_active = 1
                ''', (username,))
                
                result = cursor.fetchone()
                if not result:
                    return False
                
                teacher_id, stored_hash = result
                
                # 检查密码哈希格式
                if stored_hash.startswith('sha256$'):
                    # 旧格式SHA-256验证
                    import hashlib
                    parts = stored_hash.split('$')
                    if len(parts) == 3:
                        salt = parts[1]
                        expected_hash = parts[2]
                        password_hash = hashlib.sha256((password + salt).encode('utf-8')).hexdigest()
                        is_valid = password_hash == expected_hash
                    else:
                        # 更旧的格式，直接SHA-256
                        password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
                        is_valid = password_hash == stored_hash
                else:
                    # 尝试bcrypt验证
                    try:
                        import bcrypt
                        is_valid = bcrypt.checkpw(password.encode('utf-8'), stored_hash.encode('utf-8'))
                    except ImportError:
                        # bcrypt不可用，尝试直接SHA-256比较
                        import hashlib
                        password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
                        is_valid = password_hash == stored_hash
                
                if is_valid:
                    # 更新最后登录时间
                    cursor.execute('''
                        UPDATE teachers 
                        SET last_login = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ''', (teacher_id,))
                    conn.commit()
                    return True
                
                return False
                
        except Exception as e:
            print(f"- 教师密码验证失败: {e}")
            return False
    
    def get_teacher_info(self, username: str) -> Optional[Dict[str, Any]]:
        """获取教师信息"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT id, username, name, email, last_login, created_at
                    FROM teachers 
                    WHERE username = ? AND is_active = 1
                ''', (username,))
                
                result = cursor.fetchone()
                if result:
                    return {
                        'id': result[0],
                        'username': result[1],
                        'name': result[2],
                        'email': result[3],
                        'last_login': result[4],
                        'created_at': result[5]
                    }
                
                return None
                
        except Exception as e:
            print(f"- 获取教师信息失败: {e}")
            return None
    
    def update_teacher_password(self, username: str, new_password: str) -> bool:
        """更新教师密码"""
        import hashlib
        
        try:
            password_hash = hashlib.sha256(new_password.encode('utf-8')).hexdigest()
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE teachers 
                    SET password_hash = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE username = ? AND is_active = 1
                ''', (password_hash, username))
                
                conn.commit()
                return cursor.rowcount > 0
                
        except Exception as e:
            print(f"- 更新教师密码失败: {e}")
            return False
    
    # 会话管理相关方法
    def create_session(self, token_hash: str, user_type: str, user_id: str, user_info: dict, expires_at: datetime) -> bool:
        """创建用户会话"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 清理过期的会话
                cursor.execute('DELETE FROM user_sessions WHERE expires_at < CURRENT_TIMESTAMP')
                
                # 删除同一用户的旧会话
                cursor.execute('DELETE FROM user_sessions WHERE user_type = ? AND user_id = ?', (user_type, user_id))
                
                # 创建新会话
                cursor.execute('''
                    INSERT INTO user_sessions (token_hash, user_type, user_id, user_info, expires_at)
                    VALUES (?, ?, ?, ?, ?)
                ''', (token_hash, user_type, user_id, json.dumps(user_info), expires_at))
                
                conn.commit()
                return True
                
        except Exception as e:
            print(f"- 创建会话失败: {e}")
            return False
    
    def get_session(self, token_hash: str) -> Optional[Dict[str, Any]]:
        """获取会话信息"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT user_type, user_id, user_info, expires_at
                    FROM user_sessions 
                    WHERE token_hash = ? AND expires_at > CURRENT_TIMESTAMP
                ''', (token_hash,))
                
                result = cursor.fetchone()
                if result:
                    return {
                        'user_type': result[0],
                        'user_id': result[1],
                        'user_info': json.loads(result[2]) if result[2] else {},
                        'expires_at': datetime.fromisoformat(result[3]) if result[3] else None
                    }
                
                return None
                
        except Exception as e:
            print(f"- 获取会话失败: {e}")
            return None
    
    def delete_session(self, token_hash: str) -> bool:
        """删除会话"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM user_sessions WHERE token_hash = ?', (token_hash,))
                conn.commit()
                return cursor.rowcount > 0
                
        except Exception as e:
            print(f"- 删除会话失败: {e}")
            return False
    
    def cleanup_expired_sessions(self) -> int:
        """清理过期的会话"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM user_sessions WHERE expires_at < CURRENT_TIMESTAMP')
                conn.commit()
                return cursor.rowcount
                
        except Exception as e:
            print(f"- 清理过期会话失败: {e}")
            return 0
    
    def refresh_session(self, token_hash: str, new_expires_at: datetime) -> bool:
        """刷新会话过期时间"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE user_sessions 
                    SET expires_at = ? 
                    WHERE token_hash = ?
                ''', (new_expires_at, token_hash))
                
                conn.commit()
                return cursor.rowcount > 0
                
        except Exception as e:
            print(f"- 刷新会话失败: {e}")
            return False

    @retry_on_lock()
    def submit_exam(self, result_id: int, answers: Dict[str, str], score: float):
        """提交考试"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE exam_results 
                    SET answers = ?, score = ?, end_time = ?, is_completed = 1
                    WHERE id = ?
                ''', (json.dumps(answers, ensure_ascii=False), score, datetime.now().isoformat(), result_id))
                
                # 检查是否更新了行
                if cursor.rowcount == 0:
                    print(f"提交考试失败：未找到result_id={result_id}的记录")
                    return False
                    
                conn.commit()
                print(f"考试提交成功：result_id={result_id}, score={score}, answers_count={len(answers)}")
                return True
                
        except Exception as e:
            print(f"提交考试异常: {e}")
            import traceback
            traceback.print_exc()
            return False

    def get_exam_results(self, exam_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """获取考试结果 - 支持所有状态的考试结果"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            if exam_id:
                cursor.execute('''
                    SELECT er.id, er.exam_id, er.student_id, er.answers, er.score, er.total_score,
                           er.start_time, er.end_time, er.is_completed,
                           e.title as exam_title, e.total_score as exam_total_score,
                           s.name as student_name, s.student_id as student_number,
                           COALESCE(s.college, '') as college, 
                           COALESCE(s.major, '') as major, 
                           COALESCE(s.class_name, '') as class_name, 
                           COALESCE(s.gender, '') as gender
                    FROM exam_results er
                    JOIN exams e ON er.exam_id = e.id
                    JOIN students s ON er.student_id = s.id
                    WHERE er.exam_id = ?
                    ORDER BY er.start_time DESC
                ''', (exam_id,))
            else:
                cursor.execute('''
                    SELECT er.id, er.exam_id, er.student_id, er.answers, er.score, er.total_score,
                           er.start_time, er.end_time, er.is_completed,
                           e.title as exam_title, e.total_score as exam_total_score,
                           s.name as student_name, s.student_id as student_number,
                           COALESCE(s.college, '') as college, 
                           COALESCE(s.major, '') as major, 
                           COALESCE(s.class_name, '') as class_name, 
                           COALESCE(s.gender, '') as gender
                    FROM exam_results er
                    JOIN exams e ON er.exam_id = e.id
                    JOIN students s ON er.student_id = s.id
                    ORDER BY er.start_time DESC
                ''')
            
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = {
                    'id': row[0],
                    'exam_id': row[1],
                    'student_id': row[2],
                    'answers': row[3],
                    'score': row[4] or 0.0,
                    'total_score': row[5] or 0.0,  # 从exam_results表
                    'start_time': row[6],
                    'end_time': row[7],
                    'is_completed': bool(row[8]),
                    'exam_title': row[9] or f'考试{row[1]}',
                    'exam_total_score': row[10] or 100.0,  # 从exams表
                    'student_name': row[11] or 'N/A',
                    'student_number': row[12] or 'N/A',
                    'college': row[13] or '',
                    'major': row[14] or '',
                    'class_name': row[15] or '',
                    'gender': row[16] or ''
                }
                results.append(result)
            return results

    def get_student_exam_history(self, student_id: int) -> List[Dict[str, Any]]:
        """获取学生考试历史（所有记录，包括已完成和未完成的）"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT er.id, er.exam_id, er.student_id, er.answers, er.score, er.total_score,
                       er.start_time, er.end_time, er.is_completed, e.title as exam_title
                FROM exam_results er
                JOIN exams e ON er.exam_id = e.id
                WHERE er.student_id = ?
                ORDER BY er.start_time DESC
            ''', (student_id,))
            
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = {
                    'id': row[0],
                    'exam_id': row[1],
                    'student_id': row[2],
                    'answers': row[3],
                    'score': row[4] or 0.0,
                    'total_score': row[5] or 100.0,  # 添加total_score字段
                    'start_time': row[6],
                    'end_time': row[7],
                    'is_completed': bool(row[8]),
                    'exam_title': row[9] or f'考试{row[1]}'
                }
                results.append(result)
            return results

    def get_student_completed_exams(self, student_id: int) -> List[Dict[str, Any]]:
        """获取学生已完成的考试历史"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT er.id, er.exam_id, er.student_id, er.answers, er.score, er.total_score,
                       er.start_time, er.end_time, er.is_completed, e.title as exam_title
                FROM exam_results er
                JOIN exams e ON er.exam_id = e.id
                WHERE er.student_id = ? AND er.is_completed = 1
                ORDER BY er.end_time DESC
            ''', (student_id,))
            
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = {
                    'id': row[0],
                    'exam_id': row[1],
                    'student_id': row[2],
                    'answers': row[3],
                    'score': row[4] or 0.0,
                    'total_score': row[5] or 100.0,  # 添加total_score字段
                    'start_time': row[6],
                    'end_time': row[7],
                    'is_completed': bool(row[8]),
                    'exam_title': row[9] or f'考试{row[1]}'
                }
                results.append(result)
            return results

    def save_exam_result(self, exam_result: ExamResult) -> int:
        """保存考试结果 - 支持总分"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO exam_results (exam_id, student_id, answers, score, total_score, 
                                        start_time, end_time, is_completed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (exam_result.exam_id, exam_result.student_id, exam_result.answers,
                  exam_result.score, exam_result.total_score, exam_result.start_time,
                  exam_result.end_time, exam_result.is_completed))
            return cursor.lastrowid

    def save_question_score(self, question_score: QuestionScore):
        """保存题目得分详情"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO question_scores (exam_result_id, question_id, question_order,
                                           student_answer, correct_answer, is_correct,
                                           score, max_score, question_type, question_text,
                                           is_manually_graded, graded_by, grade_comment)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (question_score.exam_result_id, question_score.question_id, question_score.question_order,
                  question_score.student_answer, question_score.correct_answer, question_score.is_correct,
                  question_score.score, question_score.max_score, question_score.question_type,
                  question_score.question_text, question_score.is_manually_graded,
                  question_score.graded_by, question_score.grade_comment))

    def delete_incomplete_exam(self, student_id: int, exam_id: int):
        """删除未完成的考试记录"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                DELETE FROM exam_results 
                WHERE student_id = ? AND exam_id = ? AND is_completed = 0
            ''', (student_id, exam_id)) 

    # 新增：考试进度管理方法
    def save_exam_progress_by_student_number(self, exam_id: int, student_number: str, 
                                           student_name: str, answers: dict, 
                                           elapsed_minutes: float = 0.0,
                                           session_id: str = None, ip_address: str = None, 
                                           user_agent: str = None) -> bool:
        """按学号保存考试进度"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                current_time = datetime.now().isoformat()
                
                # 检查是否已有记录
                cursor.execute('''
                    SELECT id, start_time, is_active FROM exam_progress 
                    WHERE exam_id = ? AND student_number = ?
                ''', (exam_id, student_number))
                
                existing = cursor.fetchone()
                answer_json = json.dumps(answers, ensure_ascii=False)
                
                if existing:
                    # 🔥 关键修复：检查考试是否已被强制关闭
                    # existing[2] 是 is_active 字段
                    if existing[2] == 0:
                        print(f"[WARNING] 拒绝更新已关闭的考试进度: 学号={student_number}, 考试ID={exam_id}")
                        return False
                    
                    # 更新现有记录
                    cursor.execute('''
                        UPDATE exam_progress 
                        SET student_name = ?, answer_data = ?, last_save_time = ?, 
                            elapsed_minutes = ?, session_id = ?, ip_address = ?, 
                            user_agent = ?, is_active = 1, updated_at = ?
                        WHERE exam_id = ? AND student_number = ?
                    ''', (student_name, answer_json, current_time, elapsed_minutes,
                          session_id, ip_address, user_agent, current_time, exam_id, student_number))
                    print(f"[SUCCESS] 更新考试进度: 学号={student_number}, 考试ID={exam_id}, 已用时={elapsed_minutes:.1f}分钟")
                else:
                    # 创建新记录
                    cursor.execute('''
                        INSERT INTO exam_progress 
                        (exam_id, student_number, student_name, answer_data, start_time, 
                         last_save_time, elapsed_minutes, session_id, ip_address, user_agent)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (exam_id, student_number, student_name, answer_json, current_time,
                          current_time, elapsed_minutes, session_id, ip_address, user_agent))
                    print(f"[SUCCESS] 创建考试进度: 学号={student_number}, 考试ID={exam_id}")
                
                return True
                
        except Exception as e:
            print(f"[ERROR] 保存考试进度失败: {e}")
            return False
    
    def get_exam_progress_by_student_number(self, exam_id: int, student_number: str) -> Optional[Dict[str, Any]]:
        """按学号获取考试进度"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT exam_id, student_number, student_name, answer_data, 
                           start_time, last_save_time, elapsed_minutes, session_id,
                           ip_address, user_agent, is_active
                    FROM exam_progress 
                    WHERE exam_id = ? AND student_number = ? AND is_active = 1
                ''', (exam_id, student_number))
                
                row = cursor.fetchone()
                if row:
                    try:
                        answers = json.loads(row[3]) if row[3] else {}
                    except (json.JSONDecodeError, TypeError):
                        answers = {}
                    
                    # 计算当前已用时间
                    start_time = datetime.fromisoformat(row[4])
                    current_elapsed = (datetime.now() - start_time).total_seconds() / 60
                    stored_elapsed = row[6] or 0.0
                    total_elapsed = max(current_elapsed, stored_elapsed)
                    
                    return {
                        'exam_id': row[0],
                        'student_number': row[1],
                        'student_name': row[2],
                        'answers': answers,
                        'start_time': row[4],
                        'last_save_time': row[5],
                        'elapsed_minutes': total_elapsed,
                        'stored_elapsed_minutes': stored_elapsed,
                        'session_id': row[7],
                        'ip_address': row[8],
                        'user_agent': row[9],
                        'is_active': bool(row[10])
                    }
                
                return None
                
        except Exception as e:
            print(f"[ERROR] 获取考试进度失败: {e}")
            return None
    
    def clear_exam_progress_by_student_number(self, exam_id: int, student_number: str) -> bool:
        """清空学号的考试进度（重新开始时使用）"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE exam_progress 
                    SET is_active = 0, updated_at = ?
                    WHERE exam_id = ? AND student_number = ?
                ''', (datetime.now().isoformat(), exam_id, student_number))
                print(f"[SUCCESS] 清空考试进度: 学号={student_number}, 考试ID={exam_id}")
                return True
        except Exception as e:
            print(f"[ERROR] 清空考试进度失败: {e}")
            return False
    
    # 新增：学生会话管理方法
    def create_student_session(self, student_number: str, student_name: str, 
                             session_id: str, ip_address: str = None, 
                             user_agent: str = None) -> bool:
        """创建学生登录会话"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                current_time = datetime.now().isoformat()
                
                # 先将该学生的其他会话标记为非活跃
                cursor.execute('''
                    UPDATE student_sessions 
                    SET is_active = 0, last_activity = ?
                    WHERE student_number = ? AND is_active = 1
                ''', (current_time, student_number))
                
                # 创建新会话
                cursor.execute('''
                    INSERT INTO student_sessions 
                    (student_number, student_name, session_id, ip_address, 
                     user_agent, login_time, last_activity)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (student_number, student_name, session_id, ip_address, 
                      user_agent, current_time, current_time))
                
                print(f"[SUCCESS] 创建学生会话: 学号={student_number}, 会话ID={session_id[:8]}...")
                return True
                
        except Exception as e:
            print(f"[ERROR] 创建学生会话失败: {e}")
            return False
    
    def check_student_session_conflict(self, student_number: str, 
                                     current_session_id: str) -> Dict[str, Any]:
        """检查学生是否在其他地方登录"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT session_id, ip_address, login_time, last_activity
                    FROM student_sessions 
                    WHERE student_number = ? AND is_active = 1 AND session_id != ?
                    ORDER BY last_activity DESC
                ''', (student_number, current_session_id))
                
                other_sessions = cursor.fetchall()
                
                if other_sessions:
                    latest_session = other_sessions[0]
                    return {
                        'has_conflict': True,
                        'other_session_id': latest_session[0],
                        'other_ip': latest_session[1],
                        'other_login_time': latest_session[2],
                        'other_last_activity': latest_session[3],
                        'total_conflicts': len(other_sessions)
                    }
                
                return {'has_conflict': False}
                
        except Exception as e:
            print(f"[ERROR] 检查会话冲突失败: {e}")
            return {'has_conflict': False, 'error': str(e)}
    
    def update_student_session_activity(self, session_id: str) -> bool:
        """更新学生会话活动时间"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE student_sessions 
                    SET last_activity = ?
                    WHERE session_id = ? AND is_active = 1
                ''', (datetime.now().isoformat(), session_id))
                return cursor.rowcount > 0
        except Exception as e:
            print(f"[ERROR] 更新会话活动失败: {e}")
            return False
    
    def get_student_active_sessions(self, student_number: str) -> List[Dict[str, Any]]:
        """获取学生的所有活跃会话"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT session_id, ip_address, login_time, last_activity, user_agent
                    FROM student_sessions 
                    WHERE student_number = ? AND is_active = 1
                    ORDER BY last_activity DESC
                ''', (student_number,))
                
                sessions = []
                for row in cursor.fetchall():
                    sessions.append({
                        'session_id': row[0],
                        'ip_address': row[1],
                        'login_time': row[2],
                        'last_activity': row[3],
                        'user_agent': row[4]
                    })
                
                return sessions
                
        except Exception as e:
            print(f"[ERROR] 获取活跃会话失败: {e}")
            return []
    
    def cleanup_inactive_sessions(self, timeout_minutes: int = 30) -> int:
        """清理非活跃会话"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                timeout_time = (datetime.now() - timedelta(minutes=timeout_minutes)).isoformat()
                
                cursor.execute('''
                    UPDATE student_sessions 
                    SET is_active = 0
                    WHERE last_activity < ? AND is_active = 1
                ''', (timeout_time,))
                
                cleaned_count = cursor.rowcount
                if cleaned_count > 0:
                    print(f"[SUCCESS] 清理了 {cleaned_count} 个非活跃会话")
                
                return cleaned_count
                
        except Exception as e:
            print(f"[ERROR] 清理非活跃会话失败: {e}")
            return 0
    
    # 监控配置相关操作
    def update_exam_monitoring_config(self, exam_id: int, max_focus_warnings: int, 
                                    auto_submit_on_exceed: bool, warning_interval_seconds: int, 
                                    enable_focus_monitoring: bool) -> bool:
        """更新考试监控配置"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE exams 
                SET max_focus_warnings = ?, auto_submit_on_exceed = ?, 
                    warning_interval_seconds = ?, enable_focus_monitoring = ?
                WHERE id = ?
            ''', (max_focus_warnings, auto_submit_on_exceed, warning_interval_seconds, 
                  enable_focus_monitoring, exam_id))
            return cursor.rowcount > 0
    
    def get_exam_monitoring_config(self, exam_id: int) -> Dict[str, Any]:
        """获取考试监控配置"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT max_focus_warnings, auto_submit_on_exceed, 
                       warning_interval_seconds, enable_focus_monitoring
                FROM exams WHERE id = ?
            ''', (exam_id,))
            
            row = cursor.fetchone()
            if row:
                return {
                    'max_focus_warnings': row[0] or 9,
                    'auto_submit_on_exceed': bool(row[1] if row[1] is not None else 1),
                    'warning_interval_seconds': row[2] or 30,
                    'enable_focus_monitoring': bool(row[3] if row[3] is not None else 1)
                }
            return {
                'max_focus_warnings': 9,
                'auto_submit_on_exceed': True,
                'warning_interval_seconds': 30,
                'enable_focus_monitoring': True
            }

    @retry_on_lock()
    def update_exam_focus_monitoring(self, exam_id: int, student_id: int, focus_lost_count: int, focus_lost_logs: str) -> bool:
        """更新学生切屏监控数据"""
        try:
            with self.get_write_connection() as conn:
                cursor = conn.cursor()
                
                # 首先检查是否已有结果记录
                cursor.execute('''
                    SELECT id FROM exam_results 
                    WHERE exam_id = ? AND student_id = ?
                ''', (exam_id, student_id))
                
                row = cursor.fetchone()
                
                if row:
                    # 更新现有记录
                    cursor.execute('''
                        UPDATE exam_results 
                        SET focus_lost_count = ?, focus_lost_logs = ?
                        WHERE id = ?
                    ''', (focus_lost_count, focus_lost_logs, row[0]))
                    return True
                else:
                    # 如果没有记录，可能考试尚未开始，这里我们只更新已存在的记录
                    # 正常情况下，save_exam_progress会先创建记录或由start_exam创建
                    print(f"[WARNING] 尝试更新切屏数据但未找到考试记录: Exam {exam_id}, Student {student_id}")
                    return False
                    
        except Exception as e:
            print(f"[ERROR] 更新切屏数据失败: {e}")
            return False