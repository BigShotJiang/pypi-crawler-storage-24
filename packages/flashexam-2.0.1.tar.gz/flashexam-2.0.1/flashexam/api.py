from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
import os
import time
from datetime import datetime

from .database import Database
from .models import Student, Question, Exam

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("[WARNING] psutil未安装，系统监控功能将受限")

try:
    from code_executor import CodeExecutor
    CODE_EXECUTOR_AVAILABLE = True
except ImportError:
    CODE_EXECUTOR_AVAILABLE = False
    print("[WARNING] code_executor未安装，代码执行功能将受限")

api_bp = Blueprint('api', __name__)

# 全局变量用于监控
_app_start_time = time.time()
_request_count = 0
_active_connections = 0

@api_bp.route('/status')
def status():
    """API状态检查"""
    return jsonify({
        'status': 'ok',
        'version': '2.0.0',
        'message': 'FlashExam Flask API is running'
    })

@api_bp.route('/health')
def health_check():
    """健康检查接口"""
    global _request_count
    _request_count += 1
    
    if PSUTIL_AVAILABLE:
        stats = get_system_stats()
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'system': stats
        })
    else:
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'system': {
                'uptime': int(time.time() - _app_start_time),
                'total_requests': _request_count,
                'message': 'Limited monitoring (psutil not available)'
            }
        })

@api_bp.route('/metrics')
def get_metrics():
    """获取基础指标"""
    global _request_count
    _request_count += 1
    
    return get_system_stats() if PSUTIL_AVAILABLE else {
        'uptime': int(time.time() - _app_start_time),
        'total_requests': _request_count,
        'message': 'Limited metrics available'
    }

@api_bp.route('/system/stats')
def system_stats():
    """系统统计API，供前端监控组件使用"""
    global _request_count, _active_connections
    _request_count += 1
    
    try:
        if PSUTIL_AVAILABLE:
            # 获取系统统计信息
            cpu_percent = psutil.cpu_percent(interval=0.1)  # 快速采样
            memory = psutil.virtual_memory()
            
            # 模拟连接数（实际应用中可能需要更复杂的逻辑）
            _active_connections = max(0, _active_connections + (-1 if _request_count % 3 == 0 else 1))
            
            # 计算平均响应时间（简化版本）
            avg_response_time = 0.08  # 假设80ms平均响应时间
            
            # 格式化数据
            formatted_stats = {
                'server_uptime': int(time.time() - _app_start_time),
                'cpu_usage': round(cpu_percent, 1),
                'memory_usage': round(memory.percent, 1),
                'active_connections': _active_connections,
                'total_requests': _request_count,
                'avg_response_time': avg_response_time,
                'status': 'normal' if cpu_percent < 80 and memory.percent < 90 else 'warning',
                'timestamp': datetime.now().isoformat()
            }
            
            return jsonify(formatted_stats)
        else:
            # 无psutil时的备用统计
            return jsonify({
                'server_uptime': int(time.time() - _app_start_time),
                'cpu_usage': 25.0,  # 模拟数据
                'memory_usage': 45.0,  # 模拟数据
                'active_connections': _active_connections,
                'total_requests': _request_count,
                'avg_response_time': 0.1,
                'status': 'normal',
                'timestamp': datetime.now().isoformat(),
                'note': 'Simulated data (psutil not available)'
            })
    except Exception as e:
        return jsonify({
            'error': str(e),
            'status': 'error',
            'timestamp': datetime.now().isoformat()
        }), 500

def get_system_stats():
    """获取系统统计信息"""
    global _request_count, _active_connections
    
    if not PSUTIL_AVAILABLE:
        return {
            'uptime': time.time() - _app_start_time,
            'total_requests': _request_count,
            'message': 'psutil not available'
        }
    
    try:
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        return {
            'uptime': time.time() - _app_start_time,
            'cpu_percent': cpu_percent,
            'memory_percent': memory.percent,
            'memory_used_gb': memory.used / (1024**3),
            'memory_total_gb': memory.total / (1024**3),
            'disk_percent': disk.percent,
            'disk_free_gb': disk.free / (1024**3),
            'active_connections': _active_connections,
            'total_requests': _request_count
        }
    except Exception as e:
        return {
            'error': str(e),
            'uptime': time.time() - _app_start_time,
            'total_requests': _request_count
        }

@api_bp.route('/user-info')
@login_required
def user_info():
    """获取当前用户信息"""
    try:
        user_data = current_user.to_dict()
        return jsonify({
            'success': True,
            'user': user_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/students', methods=['GET'])
@login_required
def get_students():
    """获取学生列表（仅教师）"""
    if not current_user.is_teacher():
        return jsonify({'success': False, 'message': '权限不足'}), 403
    
    try:
        db = Database()
        students = db.get_all_students()
        students_data = [
            {
                'id': s.id,
                'student_id': s.student_id,
                'name': s.name,
                'college': s.college,
                'major': s.major,
                'class_name': s.class_name,
                'gender': s.gender
            } for s in students
        ]
        
        return jsonify({
            'success': True,
            'students': students_data,
            'count': len(students_data)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/questions', methods=['GET'])
@login_required
def get_questions():
    """获取题目列表（仅教师）"""
    if not current_user.is_teacher():
        return jsonify({'success': False, 'message': '权限不足'}), 403
    
    try:
        db = Database()
        question_type = request.args.get('type')
        questions = db.get_questions(question_type)
        
        questions_data = [
            {
                'id': q.id,
                'question_type': q.question_type,
                'question_text': q.question_text[:100] + '...' if len(q.question_text) > 100 else q.question_text,
                'difficulty': q.difficulty,
                'subject': q.subject
            } for q in questions
        ]
        
        return jsonify({
            'success': True,
            'questions': questions_data,
            'count': len(questions_data)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/exams', methods=['GET'])
@login_required
def get_exams():
    """获取考试列表"""
    try:
        db = Database()
        exams = db.get_exams()
        
        # 学生只能看到激活的考试
        if current_user.is_student():
            exams = [exam for exam in exams if exam.is_active]
        
        exams_data = [
            {
                'id': e.id,
                'title': e.title,
                'description': e.description,
                'duration_minutes': e.duration_minutes,
                'total_questions': e.total_questions,
                'is_active': e.is_active,
                'created_at': e.created_at.isoformat() if e.created_at else None
            } for e in exams
        ]
        
        return jsonify({
            'success': True,
            'exams': exams_data,
            'count': len(exams_data)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/exam/<int:exam_id>/questions')
@login_required
def get_exam_questions(exam_id):
    """获取考试题目"""
    try:
        db = Database()
        questions = db.get_exam_questions(exam_id)
        
        questions_data = [
            {
                'id': q.id,
                'question_type': q.question_type,
                'question_text': q.question_text,
                'options': q.options,
                'difficulty': q.difficulty
                # 注意：不返回正确答案给学生
            } for q in questions
        ]
        
        return jsonify({
            'success': True,
            'questions': questions_data,
            'count': len(questions_data)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/upload', methods=['POST'])
@login_required
def upload_file():
    """文件上传接口"""
    if not current_user.is_teacher():
        return jsonify({'success': False, 'message': '权限不足'}), 403
    
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': '没有文件'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': '没有选择文件'}), 400
        
        return jsonify({
            'success': True,
            'message': '文件上传成功',
            'filename': file.filename
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/execute-code', methods=['POST'])
@login_required
def execute_code():
    """代码执行接口"""
    if not CODE_EXECUTOR_AVAILABLE:
        return jsonify({
            'success': False,
            'message': '代码执行功能不可用，请检查配置'
        }), 503
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '请求数据无效'}), 400
        
        code = data.get('code', '')
        language = data.get('language', 'python')
        
        if not code.strip():
            return jsonify({'success': False, 'message': '代码不能为空'}), 400
        
        supported_languages = ['python', 'c', 'java', 'bash', 'javascript']
        if language not in supported_languages:
            return jsonify({
                'success': False,
                'message': f'不支持的语言: {language}。支持的语言: {", ".join(supported_languages)}'
            }), 400
        
        executor = CodeExecutor(timeout=10)
        result = executor.execute(code, language)
        
        return jsonify({
            'success': result.success,
            'output': result.output,
            'error': result.error,
            'execution_time': result.execution_time,
            'exit_code': result.exit_code,
            'language': language
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'代码执行错误: {str(e)}'
        }), 500

@api_bp.route('/languages', methods=['GET'])
def get_supported_languages():
    """获取支持的编程语言列表"""
    return jsonify({
        'success': True,
        'languages': [
            {'id': 'python', 'name': 'Python', 'ext': '.py'},
            {'id': 'c', 'name': 'C', 'ext': '.c'},
            {'id': 'java', 'name': 'Java', 'ext': '.java'},
            {'id': 'bash', 'name': 'Shell/Bash', 'ext': '.sh'},
            {'id': 'javascript', 'name': 'JavaScript', 'ext': '.js'}
        ]
    }) 