from flask_login import UserMixin

from .database import Database

class User(UserMixin):
    """用户模型，支持教师和学生两种角色"""
    
    def __init__(self, user_id, username, role, name=None):
        self.id = user_id
        self.username = username  
        self.role = role
        self.name = name or username
        self._extra_info = None  # 缓存额外信息
    
    @staticmethod
    def get_by_id(user_id):
        """根据用户ID获取用户"""
        try:
            db = Database()
            
            # 首先尝试从teachers表查找
            teacher_info = db.get_teacher_info('admin')  # 通常只有一个admin教师
            if teacher_info and str(teacher_info['id']) == str(user_id):
                return User(user_id=teacher_info['id'], 
                           username=teacher_info['username'], 
                           role='teacher',
                           name=teacher_info.get('name', teacher_info['username']))
            
            # 然后从students表查找 - 这里要用内部ID查找
            students = db.get_all_students()
            for student in students:
                if str(student.id) == str(user_id):
                    return User(user_id=student.id,
                               username=student.student_id,
                               role='student', 
                               name=student.name)
        except Exception as e:
            print(f"User.get_by_id error: {e}")
                       
        return None
    
    @staticmethod
    def authenticate(username, password):
        """用户认证"""
        try:
            db = Database()
            
            print(f"authenticate: Attempting to authenticate username={username}")
            
            # 首先尝试teacher登录
            if db.verify_teacher_password(username, password):
                teacher_info = db.get_teacher_info(username)
                if teacher_info:
                    print(f"authenticate: Teacher login successful")
                    return User(user_id=teacher_info['id'],
                               username=teacher_info['username'],
                               role='teacher',
                               name=teacher_info.get('name', teacher_info['username']))
            
            # 然后尝试student登录  
            student = db.authenticate_student(username, password)
            if student:
                print(f"authenticate: Student login successful, student.id={student.id}, student.student_id={student.student_id}")
                return User(user_id=student.id,  # 使用学生的内部ID
                           username=student.student_id,  # 使用学号作为用户名
                           role='student',
                           name=student.name)
            
            print(f"authenticate: Authentication failed for username={username}")
                           
        except Exception as e:
            print(f"User.authenticate error: {e}")
            import traceback
            traceback.print_exc()
                               
        return None
    
    def get_id(self):
        """Flask-Login要求的方法"""
        return str(self.id)
    
    @property
    def is_authenticated(self):
        return True
    
    @property
    def is_active(self):
        return True
    
    @property
    def is_anonymous(self):
        return False
    
    def is_teacher(self):
        """检查是否为教师"""
        return self.role == 'teacher'
    
    def is_student(self):
        """检查是否为学生"""
        return self.role == 'student'
    
    def get_display_name(self):
        """获取显示名称"""
        return self.name if self.name else self.username
    
    def get_student_info(self):
        """获取学生详细信息（仅学生角色）"""
        if self.role == 'student':
            try:
                db = Database()
                
                print(f"get_student_info: Looking for student with ID={self.id}, username={self.username}")
                
                # 方法1：通过用户ID直接查找（首选方法）
                students = db.get_all_students()
                print(f"get_student_info: Found {len(students)} total students")
                
                for student in students:
                    print(f"get_student_info: Checking student ID={student.id}, student_id={student.student_id}")
                    if str(student.id) == str(self.id):  # 转换为字符串比较
                        print(f"get_student_info: Found match by ID")
                        return {
                            'id': student.id,
                            'student_id': student.student_id,
                            'name': student.name,
                            'college': student.college,
                            'major': student.major,
                            'class_name': student.class_name,
                            'gender': student.gender,
                            'notes': student.notes
                        }
                
                # 方法2：通过student_id查找（备用方法）
                print(f"get_student_info: No ID match found, trying by student_id={self.username}")
                student = db.get_student_by_id(self.username)
                if student:
                    print(f"get_student_info: Found by student_id, updating user ID from {self.id} to {student.id}")
                    # 更新用户ID以保持一致性
                    self.id = student.id
                    return {
                        'id': student.id,
                        'student_id': student.student_id,
                        'name': student.name,
                        'college': student.college,
                        'major': student.major,
                        'class_name': student.class_name,
                        'gender': student.gender,
                        'notes': student.notes
                    }
                
                print(f"get_student_info: No student found")
                
            except Exception as e:
                print(f"get_student_info error: {e}")
                import traceback
                traceback.print_exc()
        
        print(f"get_student_info: Returning empty dict (role={self.role})")
        return {}
    
    @property
    def extra_info(self):
        """获取用户额外信息（学生专业、班级等）"""
        if self._extra_info is None:
            if self.role == 'student':
                self._extra_info = self.get_student_info()
            else:
                self._extra_info = {}
        return self._extra_info
    
    def __repr__(self):
        return f'<User {self.username} ({self.role}), ID: {self.id}>' 