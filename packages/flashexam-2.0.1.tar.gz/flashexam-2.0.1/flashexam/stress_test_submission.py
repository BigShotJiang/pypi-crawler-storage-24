import sys
import os
import time
import threading
import concurrent.futures
import sqlite3
import random
from datetime import datetime

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from exam_reliability_system import get_submission_optimizer, get_reliability_system
from database import Database

# Configuration
NUM_STUDENTS = 200
DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'storage', 'stress_test.db'))

def setup_environment():
    """Setup test database, exam, and students"""
    print(f"Setting up test environment with {NUM_STUDENTS} students...")
    
    if os.path.exists(DB_PATH):
        try:
            os.remove(DB_PATH)
        except Exception as e:
            print(f"Warning: Could not remove existing DB: {e}")

    # Initialize DB schema
    db = Database(DB_PATH)
    
    with db.get_connection() as conn:
        cursor = conn.cursor()
        
        # Create exam
        cursor.execute("INSERT INTO exams (title, duration_minutes, is_active) VALUES ('Stress Test Exam', 60, 1)")
        exam_id = cursor.lastrowid
        
        # Create questions
        question_ids = []
        for i in range(5):
            cursor.execute(f"INSERT INTO questions (question_text, score, question_type, correct_answer) VALUES ('Question {i+1}', 10, 'choice', 'A')")
            q_id = cursor.lastrowid
            question_ids.append(q_id)
            cursor.execute(f"INSERT INTO exam_questions (exam_id, question_id, question_order) VALUES ({exam_id}, {q_id}, {i+1})")
        
        # Create students
        student_ids = []
        for i in range(NUM_STUDENTS):
            student_number = f"stu_{i+1:03d}"
            cursor.execute("INSERT INTO students (student_id, name) VALUES (?, ?)", (student_number, f"Student {i+1}"))
            student_ids.append((cursor.lastrowid, student_number))
            
        conn.commit()
        
    print(f"Created Exam ID: {exam_id}, Questions: {len(question_ids)}, Students: {len(student_ids)}")
    return exam_id, question_ids, student_ids

def simulate_submission(optimizer, exam_id, student_info, question_ids):
    """Simulate a single student submission"""
    student_id, student_number = student_info
    
    # Generate random answers
    answers = {}
    for q_id in question_ids:
        answers[f'question_{q_id}'] = random.choice(['A', 'B', 'C', 'D'])
        
    start_time = time.time()
    result = optimizer.submit_with_optimization(exam_id, student_id, student_number, answers)
    end_time = time.time()
    
    return {
        'student_id': student_id,
        'queued': result.get('queued', False),
        'success': result.get('success', False),
        'api_time': end_time - start_time,
        'message': result.get('message', '')
    }

def run_stress_test():
    # 1. Setup
    exam_id, question_ids, student_ids = setup_environment()
    
    # 2. Initialize System
    print("Initializing Exam Reliability System...")
    # Force re-initialization for this test
    import exam_reliability_system
    exam_reliability_system._reliability_system = None
    exam_reliability_system._submission_optimizer = None
    
    optimizer = get_submission_optimizer(DB_PATH)
    
    # 3. Concurrent Submission
    print(f"\nStarting {NUM_STUDENTS} concurrent submissions...")
    results = []
    
    start_time = time.time()
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=NUM_STUDENTS) as executor:
        futures = [
            executor.submit(simulate_submission, optimizer, exam_id, student, question_ids)
            for student in student_ids
        ]
        
        for future in concurrent.futures.as_completed(futures):
            results.append(future.result())
            
    api_complete_time = time.time()
    print(f"All {NUM_STUDENTS} API requests completed in {api_complete_time - start_time:.4f} seconds")
    
    # Analyze API results
    queued_count = sum(1 for r in results if r['queued'])
    success_count = sum(1 for r in results if r['success'])
    avg_api_time = sum(r['api_time'] for r in results) / len(results)
    
    print(f"API Results: Queued={queued_count}, Direct Success={success_count}, Avg Response Time={avg_api_time*1000:.2f}ms")
    
    # 4. Monitor Background Processing
    print("\nWaiting for background processing to complete...")
    processed_count = 0
    wait_start = time.time()
    
    while processed_count < NUM_STUDENTS:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM exam_results WHERE exam_id = ? AND is_completed = 1", (exam_id,))
            processed_count = cursor.fetchone()[0]
        
        sys.stdout.write(f"\rProcessed: {processed_count}/{NUM_STUDENTS}")
        sys.stdout.flush()
        
        if processed_count >= NUM_STUDENTS:
            break
            
        if time.time() - wait_start > 60: # 60s timeout
            print("\nTimeout waiting for processing!")
            break
            
        time.sleep(0.5)
        
    total_time = time.time() - start_time
    print(f"\n\nTotal Test Completed in {total_time:.4f} seconds")
    print(f"Throughput: {NUM_STUDENTS / total_time:.2f} submissions/second")
    
    # 5. Verify Data Integrity
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM question_scores")
        total_scores = cursor.fetchone()[0]
        expected_scores = NUM_STUDENTS * 5
        
        print(f"\nData Integrity Check:")
        print(f"Exam Results: {processed_count}/{NUM_STUDENTS}")
        print(f"Question Scores: {total_scores}/{expected_scores}")
        
        if processed_count == NUM_STUDENTS and total_scores == expected_scores:
            print("SUCCESS: All data correctly recorded.")
        else:
            print("FAILURE: Data missing.")

if __name__ == "__main__":
    run_stress_test()
