from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime

@dataclass
class Question:
    """题目模型 - 支持新的分值和阅读材料字段"""
    id: Optional[int] = None
    question_type: str = ""  # 支持类型: choice, judge, essay, code_reading, code_practice, short_answer, fill_blank, programming, analysis, practice
    question_text: str = ""
    options: str = ""  # JSON格式存储选择题选项
    correct_answer: str = ""
    score: float = 1.0  # 新增：题目分值
    difficulty: int = 1  # 1-5难度等级
    subject: str = ""
    material: str = ""  # 新增：阅读材料内容
    import_batch: str = ""  # 新增：导入批次标识 (YYYYMMDD_HHMMSS)
    created_at: Optional[datetime] = None

@dataclass
class Exam:
    """考试模型"""
    id: Optional[int] = None
    title: str = ""
    description: str = ""
    duration_minutes: int = 60
    total_questions: int = 0
    total_score: float = 0.0  # 新增：考试总分
    created_at: Optional[datetime] = None
    is_active: bool = True
    # 监控配置字段
    max_focus_warnings: int = 9  # 最大失焦警告次数
    auto_submit_on_exceed: bool = True  # 超过次数是否自动提交
    warning_interval_seconds: int = 30  # 警告间隔时间（秒）
    enable_focus_monitoring: bool = True  # 是否启用失焦监控

@dataclass
class Student:
    """学生模型 - 严格按照CSV列名顺序: student_id,name,password,college,major,class_name,gender,notes"""
    id: Optional[int] = None
    student_id: str = ""      # 学号 (CSV第1列)
    name: str = ""            # 姓名 (CSV第2列)
    password: str = ""        # 登录密码 (CSV第3列)
    college: str = ""         # 学院 (CSV第4列)
    major: str = ""           # 专业 (CSV第5列)
    class_name: str = ""      # 班级 (CSV第6列)
    gender: str = ""          # 性别 (CSV第7列)
    notes: str = ""           # 特殊备注 (CSV第8列)
    created_at: Optional[datetime] = None

@dataclass
class ExamResult:
    """考试结果模型"""
    id: Optional[int] = None
    exam_id: int = 0
    student_id: int = 0
    answers: str = ""  # JSON格式存储答案
    score: float = 0.0
    total_score: float = 0.0  # 新增：考试总分（用于计算百分比）
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    is_completed: bool = False

@dataclass
class QuestionScore:
    """题目得分详情模型 - 支持按分值计分"""
    id: Optional[int] = None
    exam_result_id: int = 0  # 关联考试结果ID
    question_id: int = 0  # 题目ID
    question_order: int = 0  # 题目在考试中的顺序
    student_answer: str = ""  # 学生答案
    correct_answer: str = ""  # 正确答案
    is_correct: bool = False  # 是否正确
    score: float = 0.0  # 该题得分
    max_score: float = 0.0  # 该题满分（从Question.score获取）
    question_type: str = ""  # 题目类型
    question_text: str = ""  # 题目内容（冗余存储，便于查询）
    is_manually_graded: bool = False  # 是否手动评分
    graded_by: str = ""  # 评分教师
    grade_comment: str = ""  # 评分备注
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None 