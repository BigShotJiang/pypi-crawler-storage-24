"""
Code Execution Module for FlashExam
支持 Python, C, Java, Shell 命令的安全执行
"""

import os
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class ExecutionResult:
    success: bool
    output: str
    error: str
    execution_time: float
    exit_code: int


class CodeExecutor:
    """安全代码执行器"""
    
    DEFAULT_TIMEOUT = 10
    MAX_OUTPUT_SIZE = 10000
    
    LANGUAGE_CONFIG = {
        'python': {
            'ext': '.py',
            'compile_cmd': None,
            'run_cmd': ['python3', '{file}'],
        },
        'c': {
            'ext': '.c',
            'compile_cmd': ['gcc', '-o', '{output}', '{file}'],
            'run_cmd': ['{output}'],
        },
        'java': {
            'ext': '.java',
            'compile_cmd': ['javac', '{file}'],
            'run_cmd': ['java', '-cp', '{dir}', 'Main'],
        },
        'bash': {
            'ext': '.sh',
            'compile_cmd': None,
            'run_cmd': ['bash', '{file}'],
        },
        'javascript': {
            'ext': '.js',
            'compile_cmd': None,
            'run_cmd': ['node', '{file}'],
        },
    }
    
    DANGEROUS_PATTERNS = [
        'import os',
        'import subprocess',
        'import sys',
        '__import__',
        'eval(',
        'exec(',
        'compile(',
        'open(',
        'file(',
        'input(',
        'raw_input(',
        'globals(',
        'locals(',
        'vars(',
        'dir(',
        'getattr(',
        'setattr(',
        'delattr(',
        'hasattr(',
        'System.exit',
        'Runtime.getRuntime',
        'ProcessBuilder',
        'fork(',
        'exec(',
        'system(',
        'popen(',
    ]
    
    def __init__(self, timeout: int = None, max_output: int = None):
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self.max_output = max_output or self.MAX_OUTPUT_SIZE
    
    def execute(self, code: str, language: str) -> ExecutionResult:
        if language not in self.LANGUAGE_CONFIG:
            return ExecutionResult(
                success=False,
                output='',
                error=f'不支持的语言: {language}',
                execution_time=0,
                exit_code=-1
            )
        
        security_check = self._check_security(code, language)
        if not security_check['safe']:
            return ExecutionResult(
                success=False,
                output='',
                error=f'安全检查未通过: {security_check["reason"]}',
                execution_time=0,
                exit_code=-1
            )
        
        return self._execute_code(code, language)
    
    def _check_security(self, code: str, language: str) -> Dict[str, Any]:
        code_lower = code.lower()
        
        for pattern in self.DANGEROUS_PATTERNS:
            if pattern.lower() in code_lower:
                return {
                    'safe': False,
                    'reason': f'检测到潜在危险的代码模式: {pattern}'
                }
        
        return {'safe': True, 'reason': None}
    
    def _execute_code(self, code: str, language: str) -> ExecutionResult:
        config = self.LANGUAGE_CONFIG[language]
        start_time = time.time()
        
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            if language == 'java':
                file_path = temp_path / 'Main.java'
            else:
                file_path = temp_path / f'code{config["ext"]}'
            
            file_path.write_text(code, encoding='utf-8')
            
            if config['compile_cmd']:
                compile_result = self._run_command(
                    self._format_cmd(config['compile_cmd'], file_path, temp_path),
                    temp_path
                )
                if compile_result.returncode != 0:
                    return ExecutionResult(
                        success=False,
                        output='',
                        error=compile_result.stderr or '编译失败',
                        execution_time=time.time() - start_time,
                        exit_code=compile_result.returncode
                    )
            
            run_result = self._run_command(
                self._format_cmd(config['run_cmd'], file_path, temp_path),
                temp_path
            )
            
            output = run_result.stdout or ''
            error = run_result.stderr or ''
            
            if len(output) > self.max_output:
                output = output[:self.max_output] + '\n... (输出已截断)'
            
            return ExecutionResult(
                success=run_result.returncode == 0,
                output=output,
                error=error,
                execution_time=round((time.time() - start_time) * 1000, 2),
                exit_code=run_result.returncode
            )
    
    def _format_cmd(self, cmd_template: list, file_path: Path, temp_dir: Path) -> list:
        result = []
        for part in cmd_template:
            part = part.replace('{file}', str(file_path))
            part = part.replace('{dir}', str(temp_dir))
            part = part.replace('{output}', str(temp_dir / 'output'))
            result.append(part)
        return result
    
    def _run_command(self, cmd: list, cwd: Path) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}
            )
        except subprocess.TimeoutExpired:
            return subprocess.CompletedProcess(
                args=cmd,
                returncode=-1,
                stdout='',
                stderr=f'执行超时 (超过 {self.timeout} 秒)'
            )
        except Exception as e:
            return subprocess.CompletedProcess(
                args=cmd,
                returncode=-1,
                stdout='',
                stderr=str(e)
            )


def create_executor(timeout: int = 10) -> CodeExecutor:
    return CodeExecutor(timeout=timeout)