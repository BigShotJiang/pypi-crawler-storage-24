#!/usr/bin/env python3
"""
语义分析评分器 - 增强版智能评分模块
"""

import re
import jieba
from difflib import SequenceMatcher
from typing import Dict, List, Any, Optional


class EnhancedIntelligentGrader:
    """增强版智能评分器"""
    
    def __init__(self):
        self.name = "EnhancedIntelligentGrader"
    
    def preprocess_text(self, text: str) -> str:
        """文本预处理"""
        if not text:
            return ""
        
        # 去除多余空格和换行
        text = re.sub(r'\s+', ' ', text.strip())
        # 统一标点符号
        text = text.replace('，', ',').replace('。', '.').replace('；', ';')
        return text
    
    def calculate_similarity(self, text1: str, text2: str) -> float:
        """计算文本相似度"""
        text1 = self.preprocess_text(text1)
        text2 = self.preprocess_text(text2)
        
        if not text1 or not text2:
            return 0.0
        
        # 使用SequenceMatcher计算相似度
        similarity = SequenceMatcher(None, text1, text2).ratio()
        
        # 使用jieba分词计算词汇相似度
        words1 = set(jieba.lcut(text1))
        words2 = set(jieba.lcut(text2))
        
        if words1 and words2:
            word_similarity = len(words1.intersection(words2)) / len(words1.union(words2))
            # 综合字符相似度和词汇相似度
            similarity = (similarity + word_similarity) / 2
        
        return similarity
    
    def analyze_answer_quality(self, student_answer: str, reference_answer: str) -> Dict[str, float]:
        """分析答案质量"""
        student_answer = self.preprocess_text(student_answer)
        reference_answer = self.preprocess_text(reference_answer)
        
        # 长度分析
        length_ratio = min(len(student_answer) / max(len(reference_answer), 1), 2.0)
        length_score = min(length_ratio, 1.0)
        
        # 关键词覆盖度
        student_words = set(jieba.lcut(student_answer))
        reference_words = set(jieba.lcut(reference_answer))
        coverage = len(student_words.intersection(reference_words)) / max(len(reference_words), 1)
        
        # 结构完整性（简单检测）
        structure_score = 0.5
        if '因为' in student_answer or '由于' in student_answer:
            structure_score += 0.2
        if '所以' in student_answer or '因此' in student_answer:
            structure_score += 0.2
        if any(char in student_answer for char in '，。；：'):
            structure_score += 0.1
        
        structure_score = min(structure_score, 1.0)
        
        return {
            'length_score': length_score,
            'coverage_score': coverage,
            'structure_score': structure_score
        }
    
    def grade(self, student_answer: str, reference_answer: str, 
              question_text: str = "", max_score: float = 5.0, **kwargs) -> Dict[str, Any]:
        """语义分析评分"""
        if not student_answer or not student_answer.strip():
            return {
                'score': 0.0,
                'confidence': 1.0,
                'feedback': '答案为空',
                'method': self.name,
                'details': {}
            }
        
        # 计算相似度
        similarity = self.calculate_similarity(student_answer, reference_answer)
        
        # 分析答案质量
        quality = self.analyze_answer_quality(student_answer, reference_answer)
        
        # 综合评分
        final_score = (
            similarity * 0.5 +
            quality['coverage_score'] * 0.3 +
            quality['structure_score'] * 0.2
        )
        
        score = max_score * final_score
        confidence = 0.75 if final_score > 0.5 else 0.6
        
        feedback = f"语义相似度: {similarity:.2%}, 覆盖度: {quality['coverage_score']:.2%}, 结构: {quality['structure_score']:.2f}"
        
        return {
            'score': round(score, 2),
            'confidence': confidence,
            'feedback': feedback,
            'method': self.name,
            'details': {
                'similarity': similarity,
                'quality': quality,
                'final_score': final_score
            }
        }


def get_enhanced_grader():
    """获取增强版评分器实例"""
    return EnhancedIntelligentGrader() 