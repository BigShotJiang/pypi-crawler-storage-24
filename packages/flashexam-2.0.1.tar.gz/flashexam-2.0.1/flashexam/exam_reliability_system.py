#!/usr/bin/env python3
"""
考试系统可靠性增强模块
解决答案保存、提交拥堵、数据同步和成绩计算问题
"""

import json
import time
import threading
import queue
import sqlite3
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
import asyncio
import logging
from pathlib import Path

class ExamReliabilitySystem:
    """考试可靠性系统 - 确保答案保存和提交的可靠性"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.backup_dir = Path(db_path).parent / "backup_answers"
        self.backup_dir.mkdir(exist_ok=True)
        
        # 答案缓存系统
        self.answer_cache = {}
        self.cache_lock = threading.Lock()
        
        # 提交队列系统
        self.submit_queue = queue.Queue(maxsize=1000)
        self.submit_executor = ThreadPoolExecutor(max_workers=5, thread_name_prefix="ExamSubmit")
        
        # 自动保存系统
        self.auto_save_executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="AutoSave")
        
        # 数据完整性检查
        self.integrity_checker = threading.Thread(target=self._integrity_check_loop, daemon=True)
        self.integrity_checker.start()
        
        # 启动提交处理线程
        self.submit_processor = threading.Thread(target=self._process_submit_queue, daemon=True)
        self.submit_processor.start()
        
        print("[SUCCESS] 考试可靠性系统已启动")
    
    def _integrity_check_loop(self):
        """数据完整性检查循环"""
        while True:
            try:
                self._check_data_integrity()
                time.sleep(30)  # 每30秒检查一次
            except Exception as e:
                print(f"数据完整性检查错误: {e}")
                time.sleep(60)
    
    def _check_data_integrity(self):
        """检查数据完整性（不进行分数计算）"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 检查是否有答案但未标记需要评分的记录
                cursor.execute("""
                    SELECT er.id, er.exam_id, er.student_id, er.answers
                    FROM exam_results er
                    WHERE er.is_completed = 1 
                    AND er.answers IS NOT NULL AND er.answers != ''
                    AND json_extract(er.answers, '$') IS NOT NULL
                    AND (er.needs_grading IS NULL OR er.needs_grading = 0)
                """)
                
                ungraded_records = cursor.fetchall()
                
                if ungraded_records:
                    # 标记这些记录需要评分
                    for record in ungraded_records:
                        result_id = record[0]
                        cursor.execute("""
                            UPDATE exam_results 
                            SET needs_grading = 1, is_graded = 0
                            WHERE id = ?
                        """, (result_id,))
                    
                    conn.commit()
                    print(f"[INTEGRITY] 标记了 {len(ungraded_records)} 个记录需要评分")
                        
        except Exception as e:
            print(f"[ERROR] 数据完整性检查失败: {e}")
    
    def _recalculate_score_async(self, result_id: int, exam_id: int, answers: Dict):
        """已废弃：不再自动重新计算分数，改为标记需要评分"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE exam_results 
                    SET needs_grading = 1, is_graded = 0
                    WHERE id = ?
                """, (result_id,))
                conn.commit()
                print(f"[INTEGRITY] 标记考试结果 {result_id} 需要评分")
        except Exception as e:
            print(f"[ERROR] 标记需要评分失败 - 结果ID: {result_id}: {e}")
    
    def save_answer_with_backup(self, exam_id: int, student_id: int, student_number: str, 
                               question_id: str, answer: str, timestamp: str = None, skip_db: bool = False) -> bool:
        """带备份的答案保存"""
        if not timestamp:
            timestamp = datetime.now().isoformat()
        
        try:
            # 1. 保存到内存缓存
            cache_key = f"{exam_id}_{student_id}"
            with self.cache_lock:
                if cache_key not in self.answer_cache:
                    self.answer_cache[cache_key] = {}
                self.answer_cache[cache_key][question_id] = {
                    'answer': answer,
                    'timestamp': timestamp,
                    'saved_to_db': False
                }
            
            # 2. 保存到文件备份
            self._save_to_file_backup(exam_id, student_number, question_id, answer, timestamp)
            
            # 3. 异步保存到数据库 (可选)
            if not skip_db:
                self.auto_save_executor.submit(
                    self._save_to_database_async, exam_id, student_id, student_number, 
                    {question_id: answer}, timestamp
                )
            
            return True
            
        except Exception as e:
            print(f"保存答案失败: {e}")
            return False
    
    def _save_to_file_backup(self, exam_id: int, student_number: str, 
                           question_id: str, answer: str, timestamp: str):
        """保存到文件备份"""
        try:
            backup_file = self.backup_dir / f"exam_{exam_id}_{student_number}.json"
            
            # 读取现有数据
            backup_data = {}
            if backup_file.exists():
                try:
                    with open(backup_file, 'r', encoding='utf-8') as f:
                        backup_data = json.load(f)
                except:
                    backup_data = {}
            
            # 更新答案
            if 'answers' not in backup_data:
                backup_data['answers'] = {}
            
            backup_data['answers'][question_id] = {
                'answer': answer,
                'timestamp': timestamp
            }
            backup_data['last_update'] = timestamp
            backup_data['exam_id'] = exam_id
            backup_data['student_number'] = student_number
            
            # 写入文件
            with open(backup_file, 'w', encoding='utf-8') as f:
                json.dump(backup_data, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            print(f"文件备份失败: {e}")
    
    def _save_to_database_async(self, exam_id: int, student_id: int, student_number: str,
                              answers: Dict[str, str], timestamp: str):
        """异步保存到数据库"""
        try:
            from database import Database
            db = Database(self.db_path)
            
            success = db.save_exam_progress_by_student_number(
                exam_id=exam_id,
                student_number=student_number,
                student_name="",  # 这里可以为空，数据库会处理
                answers=answers,
                elapsed_minutes=0,
                session_id="",
                ip_address="",
                user_agent=""
            )
            
            if success:
                # 标记缓存中的答案已保存到数据库
                cache_key = f"{exam_id}_{student_id}"
                with self.cache_lock:
                    if cache_key in self.answer_cache:
                        for qid in answers:
                            if qid in self.answer_cache[cache_key]:
                                self.answer_cache[cache_key][qid]['saved_to_db'] = True
                                
        except Exception as e:
            print(f"异步数据库保存失败: {e}")
    
    def batch_save_answers(self, exam_id: int, student_id: int, student_number: str,
                          answers: Dict[str, str], skip_db: bool = False) -> Dict[str, bool]:
        """批量保存答案"""
        results = {}
        timestamp = datetime.now().isoformat()
        
        for question_id, answer in answers.items():
            results[question_id] = self.save_answer_with_backup(
                exam_id, student_id, student_number, question_id, answer, timestamp, skip_db=skip_db
            )
        
        return results
    
    def get_cached_answers(self, exam_id: int, student_id: int) -> Dict[str, str]:
        """获取缓存的答案"""
        cache_key = f"{exam_id}_{student_id}"
        with self.cache_lock:
            if cache_key in self.answer_cache:
                return {
                    qid: data['answer'] 
                    for qid, data in self.answer_cache[cache_key].items()
                }
        return {}
    
    def restore_answers_from_backup(self, exam_id: int, student_number: str) -> Dict[str, str]:
        """从备份恢复答案"""
        try:
            # 1. 从文件备份恢复
            backup_file = self.backup_dir / f"exam_{exam_id}_{student_number}.json"
            if backup_file.exists():
                with open(backup_file, 'r', encoding='utf-8') as f:
                    backup_data = json.load(f)
                    if 'answers' in backup_data:
                        return {
                            qid: data['answer'] if isinstance(data, dict) else data
                            for qid, data in backup_data['answers'].items()
                        }
            
            # 2. 从数据库恢复
            from database import Database
            db = Database(self.db_path)
            progress = db.get_exam_progress_by_student_number(exam_id, student_number)
            if progress and progress.get('answers'):
                try:
                    return json.loads(progress['answers'])
                except:
                    return {}
            
        except Exception as e:
            print(f"恢复答案失败: {e}")
        
        return {}
    
    def submit_exam_reliable(self, exam_id: int, student_id: int, student_number: str,
                           answers: Dict[str, str], force_submit: bool = False) -> Dict[str, Any]:
        """可靠的考试提交"""
        submit_data = {
            'exam_id': exam_id,
            'student_id': student_id,
            'student_number': student_number,
            'answers': answers,
            'timestamp': datetime.now().isoformat(),
            'force_submit': force_submit,
            'attempts': 0,
            'max_attempts': 3
        }
        
        # 如果队列满了，直接同步提交
        try:
            self.submit_queue.put_nowait(submit_data)
            return {'success': True, 'message': '提交请求已加入队列', 'queued': True}
        except queue.Full:
            # 队列满了，直接同步提交
            return self._process_single_submit(submit_data)
    
    def _process_submit_queue(self):
        """处理提交队列"""
        while True:
            try:
                submit_data = self.submit_queue.get(timeout=1)
                result = self._process_single_submit(submit_data)
                if not result['success'] and submit_data['attempts'] < submit_data['max_attempts']:
                    # 重试
                    submit_data['attempts'] += 1
                    time.sleep(1)  # 等待1秒后重试
                    try:
                        self.submit_queue.put_nowait(submit_data)
                    except queue.Full:
                        pass  # 队列满了就放弃重试
                
                self.submit_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                print(f"处理提交队列错误: {e}")
    
    def _process_single_submit(self, submit_data: Dict[str, Any]) -> Dict[str, Any]:
        """处理单个提交（延迟评分版本）"""
        try:
            from database import Database
            db = Database(self.db_path)
            
            exam_id = submit_data['exam_id']
            student_id = submit_data['student_id']
            student_number = submit_data['student_number']
            answers = submit_data['answers']
            
            # 检查是否已经提交过
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT id, is_completed FROM exam_results 
                    WHERE student_id = ? AND exam_id = ? AND is_completed = 1
                """, (student_id, exam_id))
                existing = cursor.fetchone()
                
                if existing and not submit_data['force_submit']:
                    return {
                        'success': True, 
                        'message': '考试已提交过',
                        'result_id': existing[0],
                        'duplicate': True,
                        'score': 0,  # 延迟评分
                        'total_score': 0,
                        'percentage': 0
                    }
            
            # 获取考试信息和题目
            exam = db.get_exam_by_id(exam_id)
            if not exam:
                return {'success': False, 'message': '考试不存在'}
            
            questions = db.get_exam_questions(exam_id)
            if not questions:
                return {'success': False, 'message': '考试没有题目'}
            
            # 计算总分（仅用于显示）
            max_total_score = sum(question.score or 1.0 for question in questions)
            answered_count = len([v for v in answers.values() if v.strip()])
            
            # 使用事务保存数据（不计算分数）
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                try:
                    cursor.execute("BEGIN TRANSACTION")
                    
                    # 检查是否有未完成的记录
                    cursor.execute("""
                        SELECT id FROM exam_results 
                        WHERE student_id = ? AND exam_id = ? AND is_completed = 0
                    """, (student_id, exam_id))
                    existing_result = cursor.fetchone()
                    
                    if existing_result:
                        # 更新现有记录
                        result_id = existing_result[0]
                        cursor.execute('''
                            UPDATE exam_results 
                            SET answers = ?, score = 0, total_score = ?, end_time = ?, is_completed = 1,
                                is_graded = 0, needs_grading = 1
                            WHERE id = ?
                        ''', (json.dumps(answers, ensure_ascii=False), max_total_score, 
                              datetime.now().isoformat(), result_id))
                    else:
                        # 创建新记录
                        cursor.execute('''
                            INSERT INTO exam_results 
                            (exam_id, student_id, answers, score, total_score, start_time, end_time, 
                             is_completed, is_graded, needs_grading)
                            VALUES (?, ?, ?, 0, ?, ?, ?, 1, 0, 1)
                        ''', (exam_id, student_id, json.dumps(answers, ensure_ascii=False), 
                              max_total_score, datetime.now().isoformat(), datetime.now().isoformat()))
                        result_id = cursor.lastrowid
                    
                    # 保存题目答案详情（不计算分数）
                    for i, question in enumerate(questions):
                        question_key = f'question_{question.id}'
                        student_answer = answers.get(question_key, '')
                        max_score = question.score or 1.0
                        
                        # 检查是否已存在题目得分记录
                        cursor.execute("""
                            SELECT id FROM question_scores 
                            WHERE exam_result_id = ? AND question_id = ?
                        """, (result_id, question.id))
                        existing_qs = cursor.fetchone()
                        
                        if existing_qs:
                            # 更新现有记录
                            cursor.execute('''
                                UPDATE question_scores 
                                SET student_answer = ?, score = 0, max_score = ?, is_correct = 0,
                                    is_manually_graded = 0, needs_grading = 1
                                WHERE id = ?
                            ''', (student_answer, max_score, existing_qs[0]))
                        else:
                            # 创建新记录
                            cursor.execute('''
                                INSERT INTO question_scores 
                                (exam_result_id, question_id, question_order, student_answer, correct_answer,
                                 is_correct, score, max_score, question_type, question_text, 
                                 is_manually_graded, needs_grading)
                                VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, ?, 0, 1)
                            ''', (result_id, question.id, i + 1, student_answer, question.correct_answer,
                                  max_score, question.question_type, question.question_text[:200]))
                    
                    # 删除进度记录
                    cursor.execute('DELETE FROM exam_progress WHERE exam_id = ? AND student_number = ?', 
                                 (exam_id, student_number))
                    
                    cursor.execute("COMMIT")
                    
                    # 清理缓存和备份文件
                    self._cleanup_after_submit(exam_id, student_id, student_number)
                    
                    return {
                        'success': True,
                        'message': f'考试提交成功！已答题 {answered_count}/{len(questions)} 道，等待教师评分',
                        'result_id': result_id,
                        'score': 0,  # 延迟评分
                        'total_score': max_total_score,
                        'percentage': 0,  # 延迟评分
                        'answered_count': answered_count,
                        'total_questions': len(questions),
                        'grading_status': 'pending'
                    }
                    
                except Exception as e:
                    cursor.execute("ROLLBACK")
                    raise e
                    
        except Exception as e:
            print(f"[ERROR] 提交处理失败: {e}")
            return {'success': False, 'message': f'提交失败: {str(e)}'}
    
    def _cleanup_after_submit(self, exam_id: int, student_id: int, student_number: str):
        """提交后清理"""
        try:
            # 清理内存缓存
            cache_key = f"{exam_id}_{student_id}"
            with self.cache_lock:
                self.answer_cache.pop(cache_key, None)
            
            # 删除备份文件
            backup_file = self.backup_dir / f"exam_{exam_id}_{student_number}.json"
            if backup_file.exists():
                backup_file.unlink()
                
        except Exception as e:
            print(f"清理失败: {e}")
    
    def get_submit_queue_status(self) -> Dict[str, Any]:
        """获取提交队列状态"""
        return {
            'queue_size': self.submit_queue.qsize(),
            'queue_full': self.submit_queue.full(),
            'max_size': self.submit_queue.maxsize,
            'active_threads': threading.active_count()
        }

class ExamContinuityManager:
    """考试连续性管理器 - 处理继续考试时的答案恢复"""
    
    def __init__(self, reliability_system: ExamReliabilitySystem):
        self.reliability_system = reliability_system
    
    def prepare_continue_exam(self, exam_id: int, student_id: int, student_number: str) -> Dict[str, Any]:
        """准备继续考试 - 恢复所有已保存的答案"""
        try:
            # 1. 从可靠性系统获取缓存答案
            cached_answers = self.reliability_system.get_cached_answers(exam_id, student_id)
            
            # 2. 从备份文件恢复答案
            backup_answers = self.reliability_system.restore_answers_from_backup(exam_id, student_number)
            
            # 3. 从数据库恢复进度
            from database import Database
            db = Database(self.reliability_system.db_path)
            db_progress = db.get_exam_progress_by_student_number(exam_id, student_number)
            db_answers = {}
            if db_progress and db_progress.get('answers'):
                try:
                    db_answers = json.loads(db_progress['answers'])
                except:
                    db_answers = {}
            
            # 4. 合并所有答案，优先级：缓存 > 备份 > 数据库
            merged_answers = {}
            merged_answers.update(db_answers)      # 最低优先级
            merged_answers.update(backup_answers)  # 中等优先级
            merged_answers.update(cached_answers)  # 最高优先级
            
            # 5. 验证答案完整性
            questions = db.get_exam_questions(exam_id)
            question_ids = [f'question_{q.id}' for q in questions]
            
            recovered_count = 0
            for qid in question_ids:
                if qid in merged_answers and merged_answers[qid].strip():
                    recovered_count += 1
            
            # 6. 将合并后的答案重新保存到所有位置
            if merged_answers:
                for qid, answer in merged_answers.items():
                    if answer.strip():  # 只保存非空答案
                        self.reliability_system.save_answer_with_backup(
                            exam_id, student_id, student_number, qid, answer
                        )
            
            return {
                'success': True,
                'recovered_answers': merged_answers,
                'recovered_count': recovered_count,
                'total_questions': len(question_ids),
                'recovery_sources': {
                    'cache': len(cached_answers),
                    'backup': len(backup_answers), 
                    'database': len(db_answers)
                },
                'message': f'成功恢复 {recovered_count}/{len(question_ids)} 道题目的答案'
            }
            
        except Exception as e:
            print(f"准备继续考试失败: {e}")
            return {
                'success': False,
                'recovered_answers': {},
                'recovered_count': 0,
                'message': f'恢复答案失败: {str(e)}'
            }

class ExamSubmissionOptimizer:
    """考试提交优化器 - 减少提交拥堵"""
    
    def __init__(self, reliability_system: ExamReliabilitySystem):
        self.reliability_system = reliability_system
        self.submission_stats = {
            'total_submissions': 0,
            'successful_submissions': 0,
            'failed_submissions': 0,
            'queued_submissions': 0,
            'average_time': 0.0
        }
        self.stats_lock = threading.Lock()
    
    def submit_with_optimization(self, exam_id: int, student_id: int, student_number: str,
                               answers: Dict[str, str]) -> Dict[str, Any]:
        """优化的提交方式"""
        start_time = time.time()
        
        try:
            # 1. 预提交验证
            validation_result = self._pre_submit_validation(exam_id, student_id, answers)
            if not validation_result['valid']:
                return {
                    'success': False,
                    'message': validation_result['message']
                }
            
            # 2. 先保存答案到所有备份位置（提交时跳过数据库写入，减少竞争）
            backup_result = self.reliability_system.batch_save_answers(
                exam_id, student_id, student_number, answers, skip_db=True
            )
            
            # 3. 检查系统负载
            queue_status = self.reliability_system.get_submit_queue_status()
            if queue_status['queue_size'] > queue_status['max_size'] * 0.8:
                # 系统负载高，使用优先提交
                result = self._priority_submit(exam_id, student_id, student_number, answers)
            else:
                # 正常提交
                result = self.reliability_system.submit_exam_reliable(
                    exam_id, student_id, student_number, answers
                )
            
            # 4. 更新统计信息
            submission_time = time.time() - start_time
            self._update_stats(result['success'], submission_time, result.get('queued', False))
            
            # 5. 添加提交确认
            if result['success']:
                result['backup_saved'] = sum(backup_result.values())
                result['submission_time'] = round(submission_time, 2)
                result['confirmation_code'] = self._generate_confirmation_code(
                    exam_id, student_id, result.get('result_id', 0)
                )
            
            return result
            
        except Exception as e:
            submission_time = time.time() - start_time
            self._update_stats(False, submission_time, False)
            return {
                'success': False,
                'message': f'提交失败: {str(e)}',
                'submission_time': round(submission_time, 2)
            }
    
    def _pre_submit_validation(self, exam_id: int, student_id: int, answers: Dict[str, str]) -> Dict[str, Any]:
        """预提交验证"""
        try:
            from database import Database
            db = Database(self.reliability_system.db_path)
            
            # 1. 检查考试是否存在
            exam = db.get_exam_by_id(exam_id)
            if not exam:
                return {'valid': False, 'message': '考试不存在'}
            
            # 2. 检查是否已经提交过
            with sqlite3.connect(self.reliability_system.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT COUNT(*) FROM exam_results 
                    WHERE student_id = ? AND exam_id = ? AND is_completed = 1
                """, (student_id, exam_id))
                count = cursor.fetchone()[0]
                if count > 0:
                    return {'valid': False, 'message': '考试已提交过，请勿重复提交'}
            
            # 3. 检查答案格式
            if not answers or not isinstance(answers, dict):
                return {'valid': False, 'message': '答案格式无效'}
            
            # 4. 检查是否有有效答案
            valid_answers = sum(1 for v in answers.values() if str(v).strip())
            if valid_answers == 0:
                return {'valid': True, 'message': '未检测到有效答案，仍将提交'}
            
            return {'valid': True, 'message': '验证通过'}
            
        except Exception as e:
            return {'valid': False, 'message': f'验证失败: {str(e)}'}
    
    def _priority_submit(self, exam_id: int, student_id: int, student_number: str,
                        answers: Dict[str, str]) -> Dict[str, Any]:
        """优先提交 - 绕过队列直接提交"""
        submit_data = {
            'exam_id': exam_id,
            'student_id': student_id,
            'student_number': student_number,
            'answers': answers,
            'timestamp': datetime.now().isoformat(),
            'force_submit': False,
            'attempts': 0,
            'max_attempts': 1
        }
        
        result = self.reliability_system._process_single_submit(submit_data)
        result['priority_submit'] = True
        return result
    
    def _generate_confirmation_code(self, exam_id: int, student_id: int, result_id: int) -> str:
        """生成提交确认码"""
        data = f"{exam_id}_{student_id}_{result_id}_{int(time.time())}"
        return hashlib.md5(data.encode()).hexdigest()[:8].upper()
    
    def _update_stats(self, success: bool, submission_time: float, queued: bool):
        """更新统计信息"""
        with self.stats_lock:
            self.submission_stats['total_submissions'] += 1
            if success:
                self.submission_stats['successful_submissions'] += 1
            else:
                self.submission_stats['failed_submissions'] += 1
            if queued:
                self.submission_stats['queued_submissions'] += 1
            
            # 更新平均时间
            total = self.submission_stats['total_submissions']
            old_avg = self.submission_stats['average_time']
            self.submission_stats['average_time'] = (old_avg * (total - 1) + submission_time) / total
    
    def get_submission_stats(self) -> Dict[str, Any]:
        """获取提交统计信息"""
        with self.stats_lock:
            stats = self.submission_stats.copy()
            
        # 计算成功率
        total = stats['total_submissions']
        if total > 0:
            stats['success_rate'] = stats['successful_submissions'] / total * 100
            stats['failure_rate'] = stats['failed_submissions'] / total * 100
            stats['queue_rate'] = stats['queued_submissions'] / total * 100
        else:
            stats['success_rate'] = 0
            stats['failure_rate'] = 0
            stats['queue_rate'] = 0
        
        return stats

# 全局实例
_reliability_system = None
_continuity_manager = None
_submission_optimizer = None

def get_reliability_system(db_path: str = None) -> ExamReliabilitySystem:
    """获取可靠性系统实例"""
    global _reliability_system
    if _reliability_system is None:
        if db_path is None:
            from pathlib import Path
            db_path = str(Path(__file__).parent.parent / "storage" / "exam_database.db")
        _reliability_system = ExamReliabilitySystem(db_path)
    return _reliability_system

def get_continuity_manager(db_path: str = None) -> ExamContinuityManager:
    """获取连续性管理器实例"""
    global _continuity_manager
    if _continuity_manager is None:
        reliability_system = get_reliability_system(db_path)
        _continuity_manager = ExamContinuityManager(reliability_system)
    return _continuity_manager

def get_submission_optimizer(db_path: str = None) -> ExamSubmissionOptimizer:
    """获取提交优化器实例"""
    global _submission_optimizer
    if _submission_optimizer is None:
        reliability_system = get_reliability_system(db_path)
        _submission_optimizer = ExamSubmissionOptimizer(reliability_system)
    return _submission_optimizer 
