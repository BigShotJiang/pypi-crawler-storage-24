#!/usr/bin/env python3
"""
FlashExam 数据库初始化脚本
用于创建空的数据库结构
"""

import sqlite3
import os
from pathlib import Path

def init_database(db_path: str | None = None) -> str:
    """初始化数据库表结构"""
    if db_path is None:
        base_dir = Path(__file__).parent
        db_path = str(base_dir / "storage" / "exam_database.db")
    
    # 确保storage目录存在
    storage_dir = os.path.dirname(db_path)
    os.makedirs(storage_dir, exist_ok=True)
    
    print(f"[DATABASE] 初始化数据库: {db_path}")
    
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        
        # 创建教师表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS teachers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL DEFAULT 'admin',
                password_hash TEXT NOT NULL,
                name TEXT DEFAULT '管理员',
                email TEXT DEFAULT '',
                is_active BOOLEAN DEFAULT 1,
                last_login TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 创建题目表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                question_text TEXT NOT NULL,
                question_type TEXT DEFAULT 'choice',
                options TEXT,
                correct_answer TEXT,
                score REAL DEFAULT 1.0,
                difficulty TEXT DEFAULT 'medium',
                subject TEXT DEFAULT '',
                knowledge_point TEXT DEFAULT '',
                material TEXT DEFAULT '',
                material_type TEXT DEFAULT 'text',
                import_batch TEXT DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 创建考试表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS exams (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                duration_minutes INTEGER DEFAULT 60,
                total_questions INTEGER DEFAULT 0,
                total_score REAL DEFAULT 0.0,
                is_active BOOLEAN DEFAULT 1,
                max_focus_warnings INTEGER DEFAULT 9,
                auto_submit_on_exceed BOOLEAN DEFAULT 1,
                warning_interval_seconds INTEGER DEFAULT 30,
                enable_focus_monitoring BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 创建学生表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                password TEXT DEFAULT '',
                college TEXT DEFAULT '',
                major TEXT DEFAULT '',
                class_name TEXT DEFAULT '',
                gender TEXT DEFAULT '',
                notes TEXT DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 创建考试-题目关联表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS exam_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exam_id INTEGER,
                question_id INTEGER,
                question_order INTEGER,
                FOREIGN KEY (exam_id) REFERENCES exams (id),
                FOREIGN KEY (question_id) REFERENCES questions (id)
            )
        ''')
        
        # 创建考试结果表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS exam_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exam_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                answers TEXT,
                score REAL DEFAULT 0,
                total_score REAL DEFAULT 0.0,
                start_time TIMESTAMP,
                end_time TIMESTAMP,
                last_save_time TIMESTAMP,
                elapsed_minutes REAL DEFAULT 0.0,
                is_completed BOOLEAN DEFAULT 0,
                needs_grading BOOLEAN DEFAULT 1,
                is_graded BOOLEAN DEFAULT 0,
                focus_lost_count INTEGER DEFAULT 0,
                focus_lost_logs TEXT,
                FOREIGN KEY (exam_id) REFERENCES exams (id),
                FOREIGN KEY (student_id) REFERENCES students (id)
            )
        ''')
        
        # 创建考试进度表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS exam_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exam_id INTEGER NOT NULL,
                student_number TEXT NOT NULL,
                student_name TEXT NOT NULL,
                answer_data TEXT NOT NULL,
                start_time TIMESTAMP NOT NULL,
                last_save_time TIMESTAMP NOT NULL,
                elapsed_minutes REAL DEFAULT 0.0,
                session_id TEXT,
                ip_address TEXT,
                user_agent TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(exam_id, student_number)
            )
        ''')
        
        # 创建题目得分详情表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS question_scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exam_result_id INTEGER NOT NULL,
                question_id INTEGER NOT NULL,
                question_order INTEGER NOT NULL,
                student_answer TEXT,
                correct_answer TEXT,
                is_correct BOOLEAN DEFAULT 0,
                score REAL DEFAULT 0.0,
                max_score REAL DEFAULT 0.0,
                question_type TEXT,
                question_text TEXT,
                is_manually_graded BOOLEAN DEFAULT 0,
                graded_by TEXT,
                grade_comment TEXT,
                needs_grading BOOLEAN DEFAULT 1,
                ai_score REAL DEFAULT 0,
                ai_confidence REAL DEFAULT 0,
                ai_feedback TEXT DEFAULT '',
                ai_details TEXT DEFAULT '',
                is_ai_graded BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (exam_result_id) REFERENCES exam_results (id),
                FOREIGN KEY (question_id) REFERENCES questions (id)
            )
        ''')
        
        # 创建学生登录会话表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS student_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_number TEXT NOT NULL,
                student_name TEXT NOT NULL,
                session_id TEXT UNIQUE NOT NULL,
                ip_address TEXT,
                user_agent TEXT,
                login_time TIMESTAMP NOT NULL,
                last_activity TIMESTAMP NOT NULL,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 阅读材料表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS reading_passages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                source TEXT DEFAULT '',
                topic TEXT DEFAULT '',
                difficulty_level INTEGER DEFAULT 2,
                word_count INTEGER DEFAULT 0,
                reading_time INTEGER DEFAULT 0,
                language TEXT DEFAULT 'en',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # 阅读材料题目表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS passage_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                passage_id INTEGER NOT NULL,
                question_order INTEGER DEFAULT 1,
                question_type TEXT NOT NULL,
                question_text TEXT NOT NULL,
                options TEXT DEFAULT '',
                correct_answer TEXT NOT NULL,
                explanation TEXT DEFAULT '',
                difficulty INTEGER DEFAULT 2,
                points REAL DEFAULT 1.0,
                time_limit INTEGER DEFAULT 0,
                skill_focus TEXT DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (passage_id) REFERENCES reading_passages (id)
            )
        ''')
        
        # 阅读材料集合表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS passage_sets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT DEFAULT '',
                exam_type TEXT DEFAULT '',
                total_passages INTEGER DEFAULT 0,
                total_questions INTEGER DEFAULT 0,
                time_limit INTEGER DEFAULT 60,
                difficulty_level INTEGER DEFAULT 2,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # 阅读材料集合项目表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS passage_set_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                set_id INTEGER NOT NULL,
                passage_id INTEGER NOT NULL,
                passage_order INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (set_id) REFERENCES passage_sets (id),
                FOREIGN KEY (passage_id) REFERENCES reading_passages (id)
            )
        ''')
        
        # 阅读理解考试结果表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS passage_exam_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                set_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                passage_results TEXT DEFAULT '{}',
                total_score REAL DEFAULT 0.0,
                total_possible REAL DEFAULT 0.0,
                percentage REAL DEFAULT 0.0,
                start_time TIMESTAMP,
                end_time TIMESTAMP,
                time_spent INTEGER DEFAULT 0,
                is_completed BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (set_id) REFERENCES passage_sets (id),
                FOREIGN KEY (student_id) REFERENCES students (id)
            )
        ''')
        
        # 阅读理解题目结果详情表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS passage_question_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exam_result_id INTEGER NOT NULL,
                passage_id INTEGER NOT NULL,
                question_id INTEGER NOT NULL,
                student_answer TEXT DEFAULT '',
                correct_answer TEXT DEFAULT '',
                is_correct BOOLEAN DEFAULT 0,
                score REAL DEFAULT 0.0,
                max_score REAL DEFAULT 1.0,
                time_spent INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (exam_result_id) REFERENCES passage_exam_results (id),
                FOREIGN KEY (passage_id) REFERENCES reading_passages (id),
                FOREIGN KEY (question_id) REFERENCES passage_questions (id)
            )
        ''')
        
        # 答案历史表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS answer_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exam_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                student_number TEXT NOT NULL,
                answer_data TEXT NOT NULL,
                save_time TEXT NOT NULL,
                save_type TEXT DEFAULT 'auto',
                elapsed_minutes REAL DEFAULT 0,
                session_id TEXT,
                ip_address TEXT,
                is_final_submission INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 答案快照表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS answer_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exam_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                student_number TEXT NOT NULL,
                answer_data TEXT NOT NULL,
                snapshot_time TEXT NOT NULL,
                elapsed_minutes REAL DEFAULT 0,
                total_questions INTEGER DEFAULT 0,
                answered_questions INTEGER DEFAULT 0,
                completion_rate REAL DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(exam_id, student_id)
            )
        ''')
        
        # 考试时间记录表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS exam_time_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exam_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                student_number TEXT NOT NULL,
                original_start_time TEXT NOT NULL,
                last_activity_time TEXT NOT NULL,
                total_elapsed_minutes REAL DEFAULT 0,
                pause_count INTEGER DEFAULT 0,
                resume_count INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(exam_id, student_id)
            )
        ''')
        
        conn.commit()
        
        # 启用WAL模式
        conn.execute('PRAGMA journal_mode=WAL;')
        conn.execute('PRAGMA synchronous=NORMAL;')
        
    print("[DATABASE] 数据库初始化完成")
    print(f"[DATABASE] 数据库路径: {db_path}")
    return db_path

if __name__ == "__main__":
    init_database()