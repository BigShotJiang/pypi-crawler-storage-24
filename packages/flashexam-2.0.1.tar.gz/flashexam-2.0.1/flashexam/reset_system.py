#!/usr/bin/env python3
"""
FlashExam 系统重置工具
用于重置系统到初始状态，支持多种重置级别
"""

import os
import sys
import shutil
from pathlib import Path
from datetime import datetime

# 添加当前目录到路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

def backup_database(db_path):
    """备份数据库"""
    if not os.path.exists(db_path):
        print("   ℹ️  数据库文件不存在，跳过备份")
        return None
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = Path(db_path).parent / "backups"
    backup_dir.mkdir(exist_ok=True)
    
    backup_path = backup_dir / f"exam_database_backup_{timestamp}.db"
    
    try:
        shutil.copy2(db_path, backup_path)
        print(f"   ✅ 数据库已备份到: {backup_path}")
        return backup_path
    except Exception as e:
        print(f"   ❌ 备份失败: {e}")
        return None

def reset_admin_only():
    """仅重置管理员账户"""
    print("🔄 重置管理员账户")
    print("=" * 40)
    
    try:
        from database import Database
        db = Database()
        
        # 备份数据库
        print("📋 1. 备份数据库...")
        backup_path = backup_database(db.db_path)
        
        # 删除管理员账户
        print("🗑️  2. 删除管理员账户...")
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 删除教师记录
            cursor.execute('DELETE FROM teachers')
            deleted_teachers = cursor.rowcount
            
            # 删除教师相关的会话
            cursor.execute("DELETE FROM user_sessions WHERE user_type = 'teacher'")
            deleted_sessions = cursor.rowcount
            
            conn.commit()
        
        print(f"   ✅ 删除了 {deleted_teachers} 个教师账户")
        print(f"   ✅ 删除了 {deleted_sessions} 个教师会话")
        
        # 验证重置结果
        print("🔍 3. 验证重置结果...")
        if not db.has_teacher_password():
            print("   ✅ 管理员账户重置成功")
            print("   💡 现在可以重新启动系统进行初次设置")
        else:
            print("   ❌ 重置失败，仍检测到管理员账户")
        
        return True
        
    except Exception as e:
        print(f"❌ 重置失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def reset_all_data():
    """完全重置所有数据"""
    print("🔄 完全重置系统数据")
    print("=" * 40)
    
    try:
        from database import Database
        db = Database()
        
        # 备份数据库
        print("📋 1. 备份数据库...")
        backup_path = backup_database(db.db_path)
        
        # 获取重置前的统计信息
        print("📊 2. 获取当前数据统计...")
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 统计各表数据量
            tables_stats = {}
            tables = ['teachers', 'students', 'questions', 'exams', 'exam_results', 'question_scores', 'user_sessions']
            
            for table in tables:
                try:
                    cursor.execute(f'SELECT COUNT(*) FROM {table}')
                    count = cursor.fetchone()[0]
                    tables_stats[table] = count
                    print(f"   📋 {table}: {count} 条记录")
                except:
                    tables_stats[table] = 0
        
        # 确认删除
        total_records = sum(tables_stats.values())
        print(f"\n⚠️  即将删除总共 {total_records} 条记录！")
        
        # 删除所有数据
        print("\n🗑️  3. 删除所有数据...")
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 按顺序删除表数据（考虑外键约束）
            delete_order = [
                'question_scores',
                'exam_results', 
                'exam_questions',
                'user_sessions',
                'questions',
                'exams',
                'students',
                'teachers'
            ]
            
            for table in delete_order:
                try:
                    cursor.execute(f'DELETE FROM {table}')
                    deleted = cursor.rowcount
                    print(f"   ✅ {table}: 删除了 {deleted} 条记录")
                except Exception as e:
                    print(f"   ⚠️  {table}: 删除失败 - {e}")
            
            # 重置自增ID
            print("🔄 4. 重置自增ID...")
            cursor.execute("DELETE FROM sqlite_sequence")
            
            conn.commit()
        
        # 验证重置结果
        print("🔍 5. 验证重置结果...")
        if not db.has_teacher_password():
            print("   ✅ 系统重置成功")
            print("   💡 现在可以重新启动系统进行初次设置")
        else:
            print("   ❌ 重置失败，仍检测到管理员账户")
        
        return True
        
    except Exception as e:
        print(f"❌ 重置失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def reset_sessions_only():
    """仅清理会话数据"""
    print("🔄 清理会话数据")
    print("=" * 40)
    
    try:
        from database import Database
        db = Database()
        
        print("🗑️  删除所有会话...")
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM user_sessions')
            deleted = cursor.rowcount
            conn.commit()
        
        print(f"   ✅ 删除了 {deleted} 个会话")
        
        # 清理会话文件
        session_dir = Path(__file__).parent.parent / "storage" / "sessions"
        if session_dir.exists():
            session_files = list(session_dir.glob("*"))
            for file in session_files:
                try:
                    if file.is_file():
                        file.unlink()
                except:
                    pass
            print(f"   ✅ 清理了会话文件目录")
        
        print("✅ 会话清理完成")
        return True
        
    except Exception as e:
        print(f"❌ 会话清理失败: {e}")
        return False

def show_system_status():
    """显示系统当前状态"""
    print("📊 FlashExam 系统状态")
    print("=" * 40)
    
    try:
        from database import Database
        db = Database()
        
        # 检查管理员账户
        has_admin = db.has_teacher_password()
        print(f"🔐 管理员账户: {'已设置' if has_admin else '未设置'}")
        
        if has_admin:
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT username, name, created_at FROM teachers WHERE is_active = 1 LIMIT 1')
                result = cursor.fetchone()
                if result:
                    print(f"   👤 用户名: {result[0]}")
                    print(f"   📝 姓名: {result[1]}")
                    print(f"   📅 创建时间: {result[2]}")
        
        # 统计数据
        print("\n📋 数据统计:")
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # 统计各表数据
            stats = [
                ('teachers', '教师'),
                ('students', '学生'),
                ('questions', '题目'),
                ('exams', '考试'),
                ('exam_results', '考试结果'),
                ('user_sessions', '用户会话')
            ]
            
            for table, name in stats:
                try:
                    cursor.execute(f'SELECT COUNT(*) FROM {table}')
                    count = cursor.fetchone()[0]
                    print(f"   📊 {name}: {count}")
                except:
                    print(f"   ❌ {name}: 查询失败")
        
        # 数据库文件信息
        print(f"\n💾 数据库文件: {db.db_path}")
        if os.path.exists(db.db_path):
            file_size = os.path.getsize(db.db_path) / 1024 / 1024  # MB
            print(f"   📏 文件大小: {file_size:.2f} MB")
        else:
            print("   ❌ 数据库文件不存在")
        
    except Exception as e:
        print(f"❌ 状态查询失败: {e}")

def interactive_menu():
    """交互式菜单"""
    print("🔧 FlashExam 系统重置工具")
    print("=" * 50)
    
    while True:
        print("\n📋 请选择操作:")
        print("1. 查看系统状态")
        print("2. 仅重置管理员账户（保留其他数据）")
        print("3. 完全重置所有数据")
        print("4. 仅清理会话数据")
        print("0. 退出")
        
        choice = input("\n请输入选项编号: ").strip()
        
        if choice == '0':
            print("👋 退出程序")
            break
        elif choice == '1':
            show_system_status()
        elif choice == '2':
            print("\n⚠️  您选择了重置管理员账户")
            print("   这将删除所有教师账户，但保留学生、题目、考试等数据")
            confirm = input("   确认执行吗？(输入 'YES' 确认): ")
            if confirm == 'YES':
                reset_admin_only()
            else:
                print("   ❌ 操作已取消")
        elif choice == '3':
            print("\n⚠️  您选择了完全重置系统")
            print("   这将删除所有数据，包括教师、学生、题目、考试等")
            print("   数据将被备份，但此操作不可逆！")
            confirm = input("   确认执行吗？(输入 'DELETE ALL' 确认): ")
            if confirm == 'DELETE ALL':
                reset_all_data()
            else:
                print("   ❌ 操作已取消")
        elif choice == '4':
            print("\n🔄 清理会话数据")
            confirm = input("   确认清理所有用户会话吗？(输入 'YES' 确认): ")
            if confirm == 'YES':
                reset_sessions_only()
            else:
                print("   ❌ 操作已取消")
        else:
            print("❌ 无效选项，请重新选择")

def main():
    """主函数"""
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == 'admin':
            # 快速重置管理员
            print("⚡ 快速重置管理员账户")
            confirm = input("确认重置管理员账户吗？(输入 'YES' 确认): ")
            if confirm == 'YES':
                reset_admin_only()
            else:
                print("❌ 操作已取消")
                
        elif command == 'all':
            # 快速完全重置
            print("⚡ 快速完全重置系统")
            print("⚠️  这将删除所有数据！")
            confirm = input("确认完全重置吗？(输入 'DELETE ALL' 确认): ")
            if confirm == 'DELETE ALL':
                reset_all_data()
            else:
                print("❌ 操作已取消")
                
        elif command == 'status':
            # 查看状态
            show_system_status()
            
        elif command == 'sessions':
            # 清理会话
            reset_sessions_only()
            
        else:
            print("使用方法:")
            print("  python reset_system.py                # 交互式菜单")
            print("  python reset_system.py admin          # 快速重置管理员")
            print("  python reset_system.py all            # 快速完全重置")
            print("  python reset_system.py status         # 查看系统状态")
            print("  python reset_system.py sessions       # 清理会话")
    else:
        # 交互式模式
        interactive_menu()

if __name__ == "__main__":
    main() 