#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能导入管理器
根据文件类型自动选择导入方式：
- xlsx文件：增强型Excel解析器（全面修复版）
- csv文件：传统简单题目模式
"""

import os
import csv
from pathlib import Path
from database import Database
from models import Question, Exam
import json

class SmartImportManager:
    def __init__(self):
        self.db = Database()
        # 简化依赖：不依赖enhanced_excel_parser，直接处理
    
    def import_file(self, file_path, exam_title=None):
        """智能导入文件"""
        print(f"🤖 智能导入管理器 v3.0")
        print(f"📁 文件路径: {file_path}")
        
        # 生成批次ID (YYYYMMDD_HHMMSS)
        import datetime
        batch_id = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        print(f"📦 导入批次ID: {batch_id}")
        
        if not os.path.exists(file_path):
            print(f"❌ 文件不存在: {file_path}")
            return None, []
        
        # 获取文件扩展名
        file_ext = Path(file_path).suffix.lower()
        print(f"📄 文件类型: {file_ext}")
        
        # 根据文件类型选择导入方式
        if file_ext == '.xlsx':
            return self._import_xlsx_file(file_path, exam_title, batch_id)
        elif file_ext == '.csv':
            return self._import_csv_file(file_path, exam_title, batch_id)
        else:
            print(f"❌ 不支持的文件类型: {file_ext}")
            print("支持的文件类型: .xlsx (Excel), .csv (CSV)")
            return None, []
    
    def _import_xlsx_file(self, file_path, exam_title, batch_id=None):
        """导入Excel文件"""
        print("📚 导入Excel文件...")
        
        try:
            import pandas as pd
            import openpyxl
            
            # 使用openpyxl直接读取Excel文件以保持换行符
            print(f"  📖 使用openpyxl读取文件: {file_path}")
            workbook = openpyxl.load_workbook(file_path)
            worksheet = workbook.active
            
            # 获取所有数据，保持换行符
            data_rows = []
            headers = []
            
            # 读取表头
            for col_num, cell in enumerate(worksheet[1], 1):
                if cell.value:
                    headers.append(str(cell.value).strip())
                else:
                    headers.append(f"col_{col_num}")
            
            print(f"  📋 表头: {headers}")
            
            # 读取数据行
            for row_num in range(2, worksheet.max_row + 1):
                row_data = {}
                for col_num, header in enumerate(headers, 1):
                    cell = worksheet.cell(row=row_num, column=col_num)
                    if cell.value is not None:
                        # 保持原始值，包括换行符
                        cell_value = str(cell.value)
                        row_data[header] = cell_value
                    else:
                        row_data[header] = ""
                
                # 只添加非空行
                if any(str(v).strip() for v in row_data.values()):
                    data_rows.append(row_data)
            
            print(f"  📊 读取Excel文件成功，共 {len(data_rows)} 行数据")
            
            # 创建DataFrame用于后续处理
            df = pd.DataFrame(data_rows)
            
            # 预处理：处理材料字段的共享逻辑
            df = self._preprocess_excel_data_preserve_newlines(df)
            
            question_ids = []
            for index, row in df.iterrows():
                question = self._create_question_from_excel_row_preserve_newlines(row)
                if question:
                    question_id = self.db.add_question(question)
                    if question_id != -1:
                        question_ids.append(question_id)
                        print(f"  ✅ 题目 {index+1}: ID={question_id}")
                        # 调试：输出材料内容的前100个字符
                        if question.material:
                            material_preview = question.material.replace('\n', '\\n')[:100]
                            print(f"    📖 材料预览: {material_preview}...")
                    else:
                        print(f"  ❌ 题目 {index+1} 导入失败")
                else:
                    print(f"  ⚠️ 题目 {index+1} 数据无效，跳过")
            
            # 创建考试
            exam_id = None
            if exam_title and question_ids:
                exam = Exam(
                    title=exam_title,
                    description=f"从Excel文件导入的{len(question_ids)}道题目",
                    duration_minutes=60,
                    is_active=True
                )
                
                exam_id = self.db.create_exam_with_questions(exam, question_ids)
                if exam_id and exam_id != -1:
                    print(f"✅ 考试创建成功: {exam_title} (ID: {exam_id})")
                else:
                    print("❌ 考试创建失败")
            
            return exam_id, question_ids
            
        except ImportError:
            print("❌ 需要安装pandas和openpyxl库来处理Excel文件: pip install pandas openpyxl")
            return None, []
        except Exception as e:
            print(f"❌ Excel文件导入异常: {e}")
            import traceback
            traceback.print_exc()
            return None, []
    
    def _preprocess_excel_data_preserve_newlines(self, df):
        """预处理Excel数据，正确处理分组和简单题目的识别，保持换行符"""
        import pandas as pd
        
        print("  🔧 预处理Excel数据（保持换行符）...")
        
        # 查找Number和Material列
        number_col = None
        material_col = None
        
        for col in df.columns:
            col_lower = str(col).lower()
            if col_lower in ['number', 'num', '序号', '题号']:
                number_col = col
            elif col_lower in ['material', '材料', '阅读材料', 'passage']:
                material_col = col
        
        if number_col is not None:
            print(f"  📝 找到题号列: {number_col}")
        if material_col is not None:
            print(f"  📝 找到材料列: {material_col}")
        
        # 分析题目类型：基于Number和Material的组合
        if number_col is not None and material_col is not None:
            current_group_number = None
            current_group_material = None
            
            for index in df.index:
                number_value = df.at[index, number_col]
                material_value = df.at[index, material_col]
                
                # 检查是否有新的题目编号
                if pd.notna(number_value) and str(number_value).strip() and str(number_value).strip() != 'nan':
                    current_group_number = str(number_value).strip()
                    
                    # 检查这个编号是否有对应的材料
                    if pd.notna(material_value) and str(material_value).strip() and str(material_value).strip() != 'nan':
                        current_group_material = str(material_value)  # 保持原始内容，包括换行符
                        newline_count = current_group_material.count('\n')
                        print(f"    📖 题目编号{current_group_number}: 发现分组材料 ({len(current_group_material)}字符, {newline_count}换行)")
                    else:
                        # 新编号但无材料，这是简单题目
                        current_group_material = None
                        df.at[index, material_col] = ""  # 确保Material列为空
                        print(f"    📝 题目编号{current_group_number}: 简单题目（无材料）")
                else:
                    # 没有新编号，检查是否属于当前分组
                    if current_group_material is not None:
                        # 属于当前材料组，使用组材料
                        df.at[index, material_col] = current_group_material
                        print(f"    🔄 题目(编号{current_group_number}): 分组题目，使用共享材料")
                    else:
                        # 当前组无材料，这是简单题目
                        df.at[index, material_col] = ""
                        print(f"    📋 题目(编号{current_group_number}): 简单题目")
        
        return df
    
    def _create_question_from_excel_row_preserve_newlines(self, row):
        """从Excel行数据创建题目对象，保持换行符"""
        try:
            # 获取必要字段 - 改进字段映射
            question_text = str(row.get('题目', row.get('question_text', row.get('题目内容', '')))).strip()
            question_type = str(row.get('题目类型', row.get('question_type', 'choice'))).strip()
            correct_answer = str(row.get('正确答案', row.get('correct_answer', row.get('答案', '')))).strip()
            
            if not question_text:
                return None
            
            # 处理选项
            options = {}
            # 统一的题目类型判断逻辑
            if 'choice' in question_type.lower() or question_type.lower() in ['multiple_choice', '选择题', '单选题', '多选题']:
                question_type = 'choice' # 规范化为choice
                options = {
                    'A': str(row.get('选项A', row.get('option_A', ''))).strip(),
                    'B': str(row.get('选项B', row.get('option_B', ''))).strip(),
                    'C': str(row.get('选项C', row.get('option_C', ''))).strip(),
                    'D': str(row.get('选项D', row.get('option_D', ''))).strip(),
                }
                # 移除空选项
                options = {k: v for k, v in options.items() if v}
            elif 'judge' in question_type.lower() or question_type.lower() in ['判断题', 'true_false']:
                question_type = 'judge' # 规范化为judge
            
            # 获取其他字段
            subject = str(row.get('学科', row.get('subject', 'Python编程'))).strip()
            difficulty = int(row.get('难度', row.get('difficulty', 1)))
            score = float(row.get('分值', row.get('score', 1.0)))
            
            # 改进材料字段映射 - 添加更多可能的列名，并保持换行符
            material = ""
            material_fields = ['材料', 'material', 'Material', '阅读材料', '背景材料', 'passage', 'Passage', 
                             'reading_passage', 'Reading_Passage', 'content', 'Content', '内容', '文章']
            
            for field in material_fields:
                if field in row:
                    material_value = row.get(field, '')
                    if material_value and str(material_value).strip() and str(material_value).strip() != 'nan':
                        material = str(material_value)  # 保持原始内容，包括换行符
                        break
            
            # 调试信息：显示换行符数量
            newline_count = material.count('\n') if material else 0
            print(f"  📝 题目 {row.get('Number', '?')}: material({len(material)}字符, {newline_count}换行)")
            
            question = Question(
                question_type=question_type,
                question_text=question_text,
                options=json.dumps(options, ensure_ascii=False) if options else '',
                correct_answer=correct_answer,
                score=score,
                difficulty=difficulty,
                subject=subject,
                material=material  # 保持原始换行符
            )
            
            return question
            
        except Exception as e:
            print(f"  ❌ 创建题目对象失败: {e}")
            return None
    
    def _import_csv_file(self, file_path, exam_title, batch_id=None):
        """导入CSV文件（传统简单题目模式）"""
        print("📋 使用传统简单题目模式导入CSV文件...")
        
        try:
            # 解析CSV文件
            questions_data = self._parse_csv_file(file_path)
            if not questions_data:
                print("❌ CSV文件解析失败或无有效数据")
                return None, []
            
            # 导入题目到数据库
            question_ids = []
            for i, question_data in enumerate(questions_data, 1):
                question = self._create_question_from_csv_data(question_data)
                if question:
                    # 设置批次ID
                    if batch_id:
                        question.import_batch = batch_id
                        
                    question_id = self.db.add_question(question)
                    if question_id != -1:
                        question_ids.append(question_id)
                        print(f"  ✅ 题目 {i}: ID={question_id}")
                    else:
                        print(f"  ❌ 题目 {i} 导入失败")
                else:
                    print(f"  ⚠️ 题目 {i} 数据无效，跳过")
            
            # 创建考试
            exam_id = None
            if exam_title and question_ids:
                exam = Exam(
                    title=exam_title,
                    description=f"从CSV文件导入的{len(question_ids)}道题目",
                    duration_minutes=60,
                    is_active=True
                )
                
                exam_id = self.db.create_exam_with_questions(exam, question_ids)
                if exam_id and exam_id != -1:
                    print(f"✅ 考试创建成功: {exam_title} (ID: {exam_id})")
                else:
                    print("❌ 考试创建失败")
            
            return exam_id, question_ids
            
        except Exception as e:
            print(f"❌ CSV文件导入异常: {e}")
            import traceback
            traceback.print_exc()
            return None, []
    
    def _parse_csv_file(self, file_path):
        """解析CSV文件"""
        print(f"  🔍 解析CSV文件: {file_path}")
        
        questions_data = []
        
        try:
            # 尝试不同的编码
            encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig']
            content = None
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    print(f"  ✅ 使用编码: {encoding}")
                    break
                except UnicodeDecodeError:
                    continue
            
            if content is None:
                print("  ❌ 无法读取文件，编码问题")
                return []
            
            # 解析CSV内容
            lines = content.strip().split('\n')
            if not lines:
                print("  ❌ 文件为空")
                return []
            
            # 检测分隔符
            first_line = lines[0]
            delimiter = ','
            if '\t' in first_line:
                delimiter = '\t'
            elif ';' in first_line:
                delimiter = ';'
            
            print(f"  📊 检测到分隔符: '{delimiter}'")
            
            # 解析CSV数据
            csv_reader = csv.DictReader(lines, delimiter=delimiter)
            
            for row_num, row in enumerate(csv_reader, 1):
                # 清理数据
                cleaned_row = {}
                for key, value in row.items():
                    if key and value:
                        cleaned_key = key.strip().lower()
                        cleaned_value = value.strip()
                        cleaned_row[cleaned_key] = cleaned_value
                
                if cleaned_row:
                    questions_data.append(cleaned_row)
                    print(f"    ➤ 解析行 {row_num}: {list(cleaned_row.keys())}")
            
            print(f"  📝 共解析 {len(questions_data)} 行数据")
            return questions_data
            
        except Exception as e:
            print(f"  ❌ CSV解析失败: {e}")
            return []
    
    def _create_question_from_csv_data(self, data):
        """从CSV数据创建题目对象"""
        try:
            # 映射常见的列名
            field_mapping = {
                'question_type': ['题目类型', 'type', '类型', '题型', 'question_type'],
                'question_text': ['题目文本', '题目', '题目内容', '题干', 'question', '问题', 'question_text'],
                'correct_answer': ['正确答案', '答案', 'answer', 'correct', 'correct_answer'],
                'options': ['选项', 'options', '备选项'],
                'subject': ['学科', 'subject', '科目'],
                'difficulty': ['难度', 'difficulty', '难度等级'],
                'score': ['分值', 'score', '分数'],
                'material': ['材料', 'material', '阅读材料', '背景材料']
            }
            
            # 提取字段值
            def get_field_value(field_names, default=''):
                for name in field_names:
                    if name in data:
                        return data[name]
                return default
            
            question_text = get_field_value(field_mapping['question_text'])
            if not question_text:
                return None
            
            question_type = get_field_value(field_mapping['question_type'], 'choice')
            correct_answer = get_field_value(field_mapping['correct_answer'])
            subject = get_field_value(field_mapping['subject'], 'Python编程')
            material = get_field_value(field_mapping['material'])
            
            try:
                difficulty = int(get_field_value(field_mapping['difficulty'], '1'))
            except (ValueError, TypeError):
                difficulty = 1
                
            try:
                score = float(get_field_value(field_mapping['score'], '1.0'))
            except (ValueError, TypeError):
                score = 1.0
            
            # 处理选项
            options_dict = {}
            # 统一的题目类型判断逻辑
            if 'choice' in question_type.lower() or question_type.lower() in ['multiple_choice', '选择题', '单选题', '多选题']:
                question_type = 'choice' # 规范化
                # 尝试不同的选项格式
                option_keys = ['a', 'b', 'c', 'd', '选项a', '选项b', '选项c', '选项d', 
                              'option_a', 'option_b', 'option_c', 'option_d']
                
                for key in option_keys:
                    if key in data and data[key]:
                        option_label = key[-1].upper() if key[-1].isalpha() else key
                        options_dict[option_label] = data[key]
            elif 'judge' in question_type.lower() or question_type.lower() in ['判断题', 'true_false']:
                question_type = 'judge' # 规范化
            
            options_json = json.dumps(options_dict, ensure_ascii=False) if options_dict else ''
            
            question = Question(
                question_type=question_type,
                question_text=question_text,
                options=options_json,
                correct_answer=correct_answer,
                score=score,
                difficulty=difficulty,
                subject=subject,
                material=material
            )
            
            return question
            
        except Exception as e:
            print(f"  ❌ 创建题目对象失败: {e}")
            return None

if __name__ == "__main__":
    # 测试代码
    manager = SmartImportManager()
    print("智能导入管理器已准备就绪")
    print("支持的格式：.xlsx, .csv") 