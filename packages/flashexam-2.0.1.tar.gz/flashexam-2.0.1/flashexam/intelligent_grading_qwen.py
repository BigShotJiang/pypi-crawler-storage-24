#!/usr/bin/env python3
"""
基于Qwen3-0.6B模型的智能评分系统 - 改进版
使用ModelScope下载的Qwen3-0.6B模型进行主观题评分
优化评分算法，提高评分准确性
"""

import os
import re
import json
import logging
from typing import Dict, List, Any, Optional
# 延迟导入torch相关模块，避免Streamlit兼容性问题
import jieba
import numpy as np
from datetime import datetime
from difflib import SequenceMatcher

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class QwenIntelligentGrader:
    """基于Qwen3-0.6B的智能评分器 - 改进版"""
    
    def __init__(self, model_path: Optional[str] = None):
        """
        初始化Qwen智能评分器
        
        Args:
            model_path: Qwen模型路径，如果为None则自动检测
        """
        # 自动检测模型路径
        if model_path is None:
            model_path = self._find_model_path()
        
        self.model_path = model_path
        self.model = None
        self.tokenizer = None
        self.device = None
        
        # 延迟加载的模块
        self._torch = None
        self._AutoTokenizer = None
        self._AutoModelForCausalLM = None
        
        # 评分配置
        self.max_length = 512
        self.temperature = 0.1  # 降低随机性，提高评分一致性
        self.top_p = 0.9
        
        # 尝试初始化模型，如果失败则标记为未加载
        try:
            self._load_model()
        except Exception as e:
            logger.warning(f"模型初始化失败，将仅使用算法评分: {str(e)}")
    
    def _lazy_import_torch(self):
        """延迟导入torch相关模块"""
        if self._torch is None:
            try:
                import torch
                from transformers import AutoTokenizer, AutoModelForCausalLM
                
                self._torch = torch
                self._AutoTokenizer = AutoTokenizer
                self._AutoModelForCausalLM = AutoModelForCausalLM
                
                # 设置设备
                self.device = "cuda" if torch.cuda.is_available() else "cpu"
                
                return True
            except ImportError as e:
                logger.error(f"torch模块导入失败: {str(e)}")
                return False
        return True
    
    def _find_model_path(self) -> str:
        """自动查找模型路径"""
        possible_paths = [
            "../models/Qwen3-0___6B",  # Release版本模型路径（优先）
            "models/Qwen3-0___6B",  # 当前目录下的模型路径
            "assets/models/Qwen3-0___6B",  # 原始项目结构路径（兼容）
            "models/Qwen3-0.6B",   # 备用路径
            "models/qwen3-0.6b",   # 备用路径
            "models/Qwen3-0.6B/Qwen/Qwen3-0___6B",  # 嵌套路径（兼容）
            "models/qwen3-0.6b/Qwen/Qwen3-0___6B",  # 嵌套路径（兼容）
        ]
        
        for path in possible_paths:
            if os.path.exists(path) and os.path.exists(os.path.join(path, "config.json")):
                logger.info(f"🔍 找到模型路径: {path}")
                return path
        
        # 如果都找不到，返回默认路径
        default_path = "../models/Qwen3-0___6B"
        logger.warning(f"⚠️ 未找到现有模型，使用默认路径: {default_path}")
        return default_path
        
    def _load_model(self):
        """加载Qwen3-0.6B模型"""
        # 首先尝试延迟导入torch
        if not self._lazy_import_torch():
            raise ImportError("无法导入torch相关模块")
        
        try:
            logger.info(f"正在加载Qwen3-0.6B模型从: {self.model_path}")
            
            # 检查模型路径是否存在
            if not os.path.exists(self.model_path):
                logger.error(f"模型路径不存在: {self.model_path}")
                logger.info("请运行以下命令下载模型:")
                logger.info("python download_qwen_model.py")
                raise FileNotFoundError(f"模型路径不存在: {self.model_path}")
            
            # 检查关键文件
            config_path = os.path.join(self.model_path, "config.json")
            if not os.path.exists(config_path):
                logger.error(f"模型配置文件不存在: {config_path}")
                raise FileNotFoundError(f"模型配置文件不存在: {config_path}")
            
            # 加载tokenizer
            self.tokenizer = self._AutoTokenizer.from_pretrained(
                self.model_path,
                trust_remote_code=True,
                local_files_only=True  # 只使用本地文件
            )
            
            # 设置pad_token如果不存在
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
            
            # 加载模型
            self.model = self._AutoModelForCausalLM.from_pretrained(
                self.model_path,
                trust_remote_code=True,
                torch_dtype=self._torch.float16 if self.device == "cuda" else self._torch.float32,
                device_map="auto" if self.device == "cuda" else None,
                local_files_only=True  # 只使用本地文件
            )
            
            if self.device == "cpu":
                self.model = self.model.to(self.device)
            
            self.model.eval()
            logger.info("✅ Qwen3-0.6B模型加载成功")
            
        except Exception as e:
            logger.error(f"❌ 模型加载失败: {str(e)}")
            logger.info("请检查以下事项:")
            logger.info("1. 运行: python download_qwen_model.py")
            logger.info("2. 确保已安装: pip install torch transformers modelscope")
            logger.info("3. 检查模型文件完整性")
            raise e
    
    def _create_grading_prompt(self, question_text: str, reference_answer: str, 
                              student_answer: str, max_score: float) -> str:
        """创建评分提示词 - 改进版"""
        
        prompt = f"""你是一位经验丰富的专业教师，请对以下学生答案进行公正、准确的评分。

题目：{question_text}

标准答案：{reference_answer}

学生答案：{student_answer}

评分要求：
1. 满分：{max_score}分
2. 重点关注答案的正确性、完整性和逻辑性
3. 即使表达方式不同，只要核心概念正确就应该给分
4. 有具体例子或详细说明的答案应该给予适当加分
5. 空答案或完全错误的答案得0分
6. 部分正确的答案应该给予相应比例的分数

请按JSON格式输出评分结果：
{{
    "score": 0到{max_score}之间的分数（可以是小数），
    "confidence": 0到1之间的置信度，
    "feedback": "评分理由和建议",
    "reasoning": "详细的评分分析"
}}

评分结果："""
        
        return prompt
    
    def _extract_json_from_response(self, response: str) -> Dict[str, Any]:
        """从模型响应中提取JSON结果 - 改进版"""
        try:
            # 清理响应文本
            response = response.strip()
            
            # 尝试直接解析JSON
            if response.startswith('{') and response.endswith('}'):
                return json.loads(response)
            
            # 使用正则表达式提取JSON
            json_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
            matches = re.findall(json_pattern, response, re.DOTALL)
            
            for match in matches:
                try:
                    result = json.loads(match.strip())
                    if 'score' in result:
                        return result
                except json.JSONDecodeError:
                    continue
            
            # 如果无法提取JSON，使用备用解析
            return self._parse_fallback_response(response)
            
        except Exception as e:
            logger.warning(f"JSON解析失败: {str(e)}")
            return self._parse_fallback_response(response)
    
    def _parse_fallback_response(self, response: str) -> Dict[str, Any]:
        """备用响应解析方法 - 改进版"""
        result = {
            "score": 0.0,
            "confidence": 0.5,
            "feedback": "解析失败，建议人工复核",
            "reasoning": "模型响应格式不正确"
        }
        
        # 尝试提取分数
        score_patterns = [
            r'["\']?score["\']?\s*[:：]\s*(\d+\.?\d*)',
            r'分数\s*[:：]\s*(\d+\.?\d*)',
            r'得分\s*[:：]\s*(\d+\.?\d*)',
            r'(\d+\.?\d*)\s*分'
        ]
        
        for pattern in score_patterns:
            match = re.search(pattern, response, re.IGNORECASE)
            if match:
                try:
                    score = float(match.group(1))
                    result["score"] = score
                    result["confidence"] = 0.4  # 降低置信度
                    result["feedback"] = "基于文本解析的评分"
                    break
                except ValueError:
                    continue
        
        # 尝试提取置信度
        confidence_patterns = [
            r'["\']?confidence["\']?\s*[:：]\s*(\d*\.?\d+)',
            r'置信度\s*[:：]\s*(\d*\.?\d+)'
        ]
        
        for pattern in confidence_patterns:
            match = re.search(pattern, response, re.IGNORECASE)
            if match:
                try:
                    confidence = float(match.group(1))
                    result["confidence"] = min(max(confidence, 0.0), 1.0)
                    break
                except ValueError:
                    continue
        
        return result
    
    def _generate_with_qwen(self, prompt: str) -> str:
        """使用Qwen模型生成响应"""
        try:
            if self.model is None or self.tokenizer is None or self._torch is None:
                return ""
            
            # 编码输入
            inputs = self.tokenizer(
                prompt,
                return_tensors="pt",
                max_length=self.max_length,
                truncation=True,
                padding=True
            ).to(self.device)
            
            # 生成响应
            with self._torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=200,
                    temperature=self.temperature,
                    top_p=self.top_p,
                    do_sample=True,
                    pad_token_id=self.tokenizer.eos_token_id
                )
            
            # 解码响应
            response = self.tokenizer.decode(
                outputs[0][inputs['input_ids'].shape[1]:],
                skip_special_tokens=True
            )
            
            return response.strip()
            
        except Exception as e:
            logger.error(f"模型生成失败: {str(e)}")
            return ""
    
    def preprocess_text(self, text: str) -> str:
        """文本预处理"""
        if not text:
            return ""
        
        # 移除多余空白字符
        text = re.sub(r'\s+', ' ', text.strip())
        
        return text
    
    def extract_keywords(self, text: str) -> List[str]:
        """提取关键词 - 改进版"""
        if not text:
            return []
        
        # 中文分词
        words = jieba.lcut(text)
        
        # 扩展停用词表
        stopwords = {
            '的', '了', '在', '是', '有', '和', '就', '都', '而', '及', '与', '或', '但', '然而', '因此', '所以',
            '这', '那', '这个', '那个', '这些', '那些', '一个', '一种', '一些', '可以', '能够', '可能',
            '非常', '很', '特别', '比较', '相对', '主要', '基本', '简单', '复杂', '重要', '关键',
            '什么', '哪个', '怎么', '如何', '为什么', '因为', '由于', '通过', '使用', '利用'
        }
        
        # 过滤关键词
        keywords = []
        for word in words:
            # 保留长度大于1的词，但排除停用词
            if len(word) > 1 and word not in stopwords:
                keywords.append(word)
            # 对于技术词汇，即使是单字符也保留
            elif word in ['C', 'R', 'SQL', 'AI', 'UI', 'API']:
                keywords.append(word)
        
        return keywords
    
    def calculate_semantic_similarity(self, student_answer: str, reference_answer: str) -> float:
        """计算语义相似度 - 优化版"""
        if not student_answer or not reference_answer:
            return 0.0
        
        # 使用SequenceMatcher计算字符串相似度
        sequence_similarity = SequenceMatcher(None, student_answer.lower(), reference_answer.lower()).ratio()
        
        # 计算关键词相似度
        student_keywords = set(self.extract_keywords(student_answer))
        reference_keywords = set(self.extract_keywords(reference_answer))
        
        if not reference_keywords:
            keyword_similarity = 0.0
        else:
            # 计算交集比例（使用调和平均）
            intersection = len(student_keywords & reference_keywords)
            if intersection == 0:
                keyword_similarity = 0.0
            else:
                precision = intersection / len(student_keywords) if student_keywords else 0
                recall = intersection / len(reference_keywords)
                keyword_similarity = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        
        # 核心概念匹配检查
        core_concept_bonus = 0.0
        
        # 定义关键概念映射
        concept_mappings = {
            # 列表推导式相关
            '列表推导式': ['列表推导', '推导式', 'list comprehension', '推导'],
            '简洁': ['简单', '简便', '方便', '快速', '高效'],
            '创建': ['生成', '构建', '建立', '制作'],
            '列表': ['list', '数组', '序列'],
            '方法': ['方式', '语法', '技术', '技巧'],
            
            # Python相关
            'python': ['Python', 'PYTHON', 'py'],
            '解释型': ['解释', '解释执行'],
            '面向对象': ['oop', '对象导向', '面向对象编程'],
            '动态类型': ['动态', '运行时类型'],
            
            # 函数相关
            '函数': ['function', 'def', '方法', '子程序'],
            '重复使用': ['复用', '重用', '多次使用', '反复使用'],
            '代码块': ['代码段', '程序块', 'block'],
        }
        
        # 检查核心概念匹配
        student_lower = student_answer.lower()
        reference_lower = reference_answer.lower()
        
        matched_concepts = 0
        total_concepts = 0
        
        for main_concept, synonyms in concept_mappings.items():
            # 检查参考答案中是否包含这个概念
            concept_in_reference = any(syn in reference_lower for syn in [main_concept] + synonyms)
            
            if concept_in_reference:
                total_concepts += 1
                # 检查学生答案中是否包含相关概念
                concept_in_student = any(syn in student_lower for syn in [main_concept] + synonyms)
                if concept_in_student:
                    matched_concepts += 1
        
        if total_concepts > 0:
            core_concept_bonus = matched_concepts / total_concepts * 0.4  # 最多40%的概念匹配加分
        
        # 长度奖励：如果学生答案比参考答案详细，给予奖励
        length_bonus = 0.0
        if len(student_answer) > len(reference_answer) * 1.2:
            length_bonus = 0.1  # 详细答案奖励
        
        # 综合相似度计算（调整权重）
        final_similarity = (
            0.2 * sequence_similarity +      # 字符串相似度权重降低
            0.4 * keyword_similarity +       # 关键词匹配
            0.3 * core_concept_bonus +       # 核心概念匹配加分
            0.1 * length_bonus               # 详细程度奖励
        )
        
        return min(final_similarity, 1.0)
    
    def calculate_completeness_score(self, student_answer: str, reference_answer: str) -> float:
        """计算答案完整性得分 - 优化版"""
        if not student_answer:
            return 0.0
        
        student_len = len(student_answer)
        reference_len = len(reference_answer)
        
        if reference_len == 0:
            return 0.5  # 如果参考答案为空，给一个中等分数
        
        # 基于长度的完整性评估
        length_ratio = min(student_len / reference_len, 1.0)
        
        # 如果学生答案明显比参考答案详细，给予加分
        if student_len > reference_len * 1.5:
            length_bonus = 0.3  # 增加详细答案的奖励
        elif student_len > reference_len * 1.2:
            length_bonus = 0.2
        else:
            length_bonus = 0.0
        
        # 检查是否包含额外有价值的内容
        value_indicators = [
            '例如', '举例', '比如', '示例', '：', ':', 
            '`', '[', ']', '(', ')',  # 代码或示例标记
            '具体', '详细', '进一步', '另外', '此外'
        ]
        
        extra_value = any(indicator in student_answer for indicator in value_indicators)
        extra_value_bonus = 0.1 if extra_value else 0.0
        
        final_completeness = min(length_ratio + length_bonus + extra_value_bonus, 1.0)
        return final_completeness
    
    def has_examples_or_details(self, text: str) -> bool:
        """检查是否包含示例或详细说明 - 新增功能"""
        if not text:
            return False
        
        # 检查是否包含代码示例
        code_patterns = [
            r'`[^`]+`',  # 反引号代码
            r'\[[^\]]+\]',  # 方括号（如列表示例）
            r'\([^)]+\)',  # 括号说明
            r'例如|比如|举例|示例|代码|例子',  # 示例关键词
            r'：|:',  # 冒号（通常引出例子）
        ]
        
        for pattern in code_patterns:
            if re.search(pattern, text):
                return True
        
        return False
    
    def calculate_enhanced_score(self, student_answer: str, reference_answer: str, max_score: float) -> Dict[str, Any]:
        """计算增强评分 - 改进的评分算法（更宽松且只返回整数）"""
        if not student_answer or len(student_answer.strip()) == 0:
            return {
                "score": 0.0,
                "confidence": 1.0,
                "feedback": "学生未作答",
                "components": {"base": 0, "similarity": 0, "completeness": 0, "example_bonus": 0}
            }
        
        if not reference_answer:
            # 如果没有参考答案，基于答案质量给分，更宽松
            base_score = min(len(student_answer) / 10, 1.0) * max_score * 0.9  # 进一步降低长度要求
            return {
                "score": float(round(base_score)),  # 返回整数
                "confidence": 0.4,
                "feedback": "无参考答案，基于答案质量评分",
                "components": {"base": base_score, "similarity": 0, "completeness": 0, "example_bonus": 0}
            }
        
        # 计算各项指标
        semantic_similarity = self.calculate_semantic_similarity(student_answer, reference_answer)
        completeness = self.calculate_completeness_score(student_answer, reference_answer)
        has_examples = self.has_examples_or_details(student_answer)
        
        # 极度宽松的评分策略 - 尽量多给分
        # 基础分数（基于语义相似度）- 提高权重并增加基础分
        base_score = semantic_similarity * max_score
        
        # 如果语义相似度有一定基础，直接拉高分数
        if semantic_similarity > 0.5:
            base_score = max(base_score, max_score * 0.9)  # 高相似度直接给90%以上
        elif semantic_similarity > 0.3:
            base_score = max(base_score, max_score * 0.75) # 中等相似度至少75%
        elif semantic_similarity > 0.1:
            base_score = max(base_score, max_score * 0.6)  # 低相似度至少60%
        
        # 完整性加分
        completeness_bonus = completeness * max_score * 0.2
        
        # 示例和详细说明加分
        example_bonus = max_score * 0.2 if has_examples else 0
        
        # 宽松奖励：只要写了且不是完全无关，就给辛苦分
        answer_length = len(student_answer.strip())
        if answer_length >= 5:
            effort_bonus = max_score * 0.15  # 努力奖励
        else:
            effort_bonus = 0
        
        # 总分计算
        total_score = base_score + completeness_bonus + example_bonus + effort_bonus
        final_score = min(total_score, max_score)
        
        # 最低分数保障（只要不是完全无关或无意义的答案）
        if semantic_similarity > 0.05 and answer_length >= 3:
            final_score = max(final_score, max_score * 0.4)  # 至少给40%
        
        # 整数化处理
        final_score = float(round(final_score))
        
        # 置信度计算 - 更积极
        confidence = 0.7 + 0.3 * semantic_similarity
        
        # 生成更积极的反馈
        feedback_parts = []
        if semantic_similarity > 0.7:
            feedback_parts.append("答案表达优秀")
        elif semantic_similarity > 0.4:
            feedback_parts.append("答案基本正确")
        elif semantic_similarity > 0.1:
            feedback_parts.append("答案有一定相关性")
        else:
            feedback_parts.append("答案需要改进")
        
        if has_examples:
            feedback_parts.append("包含示例")
        
        feedback = "；".join(feedback_parts)
        
        return {
            "score": final_score,
            "confidence": round(confidence, 3),
            "feedback": feedback,
            "components": {
                "base": round(base_score, 1),
                "similarity": round(semantic_similarity, 3),
                "completeness": round(completeness, 3),
                "example_bonus": round(example_bonus, 1),
                "effort_bonus": round(effort_bonus, 1)
            }
        }
    
    def check_meaningless_answer(self, student_answer: str) -> Dict[str, Any]:
        """检查是否为无意义答案"""
        if not student_answer or len(student_answer.strip()) == 0:
            return {"is_meaningless": True, "reason": "空答案", "suggested_score": 0.0}
        
        answer_lower = student_answer.lower().strip()
        
        # 无意义答案关键词 - 修改为更精确的检测
        meaningless_patterns = [
            # 直接表示不知道
            "我不知道", "不知道", "不清楚", "不会", "不懂", "不明白",
            "i don't know", "i dont know", "no idea", "don't know", "dont know",
            
            # 表示放弃
            "不做了", "放弃", "跳过", "pass", "skip", "给up",
            
            # 无关回答
            "无关", "不相关", "与题目无关", "这题不会",
            
            # 明显的敷衍回答
            "随便", "不管", "都行", "whatever", "anything", "nothing",
            "瞎写", "乱写", "胡说", "瞎说", "编的", "瞎编",
            
            # 明显无意义的独立回答
            "哦", "嗯", "啊", "呢", "吗",
        ]
        
        # 检查是否完全匹配或高度匹配无意义关键词
        for pattern in meaningless_patterns:
            # 完全匹配
            if answer_lower == pattern:
                return {
                    "is_meaningless": True, 
                    "reason": f"完全匹配无意义关键词: '{pattern}'", 
                    "suggested_score": 0.0
                }
            # 如果答案很短且包含无意义词汇
            if pattern in answer_lower and len(answer_lower) <= len(pattern) + 5:
                return {
                    "is_meaningless": True, 
                    "reason": f"短答案包含无意义关键词: '{pattern}'", 
                    "suggested_score": 0.0
                }
        
        # 检查是否只包含标点符号和无意义字符
        punctuation_only_patterns = ["？", "?", "。", ".", "！", "!", "，", ",", "；", ";"]
        cleaned_answer = answer_lower
        for punct in punctuation_only_patterns:
            cleaned_answer = cleaned_answer.replace(punct, "")
        
        if len(cleaned_answer.strip()) == 0:
            return {
                "is_meaningless": True, 
                "reason": "只包含标点符号", 
                "suggested_score": 0.0
            }
        
        # 检查是否只是很短的无实际意义词汇
        very_short_meaningless = ["嗯嗯", "哦哦", "啊啊", "呢呢", "吗吗", "额额"]
        if answer_lower in very_short_meaningless:
            return {
                "is_meaningless": True, 
                "reason": f"很短的无意义词汇: '{answer_lower}'", 
                "suggested_score": 0.0
            }
        
        # 检查答案长度和内容质量（更宽松的标准）
        answer_clean = re.sub(r'[^\w\s]', '', answer_lower)  # 移除标点符号
        words = answer_clean.split()
        
        # 如果答案太短且没有实际内容（更严格的条件）
        if len(words) <= 1 and len(student_answer.strip()) <= 5:
            # 检查是否是有意义的短答案
            meaningful_short_answers = [
                "对", "错", "是", "否", "true", "false", "正确", "错误",
                "有", "无", "能", "不能", "可以", "不可以", "会", "不会",
                "yes", "no", "好", "不好", "行", "不行"
            ]
            
            if not any(word in answer_lower for word in meaningful_short_answers):
                return {
                    "is_meaningless": True, 
                    "reason": "答案过短且无实际内容", 
                    "suggested_score": 0.0
                }
        
        # 检查是否只是重复字符（更严格的条件）
        unique_chars = set(student_answer.strip())
        if len(unique_chars) <= 1 and len(student_answer.strip()) >= 3:
            return {
                "is_meaningless": True, 
                "reason": "只包含重复字符", 
                "suggested_score": 0.0
            }
        
        return {"is_meaningless": False, "reason": "答案有意义", "suggested_score": None}
    
    def check_answer_relevance(self, student_answer: str, question_text: str, reference_answer: str) -> Dict[str, Any]:
        """检查答案与题目的相关性"""
        if not student_answer or not question_text:
            return {"is_relevant": False, "reason": "缺少必要信息"}
        
        # 对于非常短的可能正确答案，特殊处理
        very_short_valid_answers = [
            "是", "否", "对", "错", "true", "false", "正确", "错误",
            "有", "无", "能", "不能", "可以", "不可以", "会", "不会",
            "yes", "no", "好", "不好", "行", "不行"
        ]
        
        student_lower = student_answer.lower().strip()
        if student_lower in [x.lower() for x in very_short_valid_answers] and len(student_answer.strip()) <= 3:
            return {"is_relevant": True, "reason": "简短但可能正确的答案"}
        
        # 提取题目关键词
        question_keywords = set(self.extract_keywords(question_text))
        reference_keywords = set(self.extract_keywords(reference_answer)) if reference_answer else set()
        student_keywords = set(self.extract_keywords(student_answer))
        
        # 合并题目和参考答案的关键词作为相关词汇
        relevant_keywords = question_keywords | reference_keywords
        
        if not relevant_keywords:
            return {"is_relevant": True, "reason": "无法判断相关性"}  # 给学生答案一个机会
        
        # 计算关键词重叠度
        overlap_count = len(student_keywords & relevant_keywords)
        overlap_ratio = overlap_count / len(relevant_keywords) if relevant_keywords else 0
        
        # 检查是否包含明显无关的内容
        irrelevant_patterns = [
            "这题不会", "与题目无关", "不知道题目在问什么",
            "看不懂题目", "题目太难", "没学过", "没见过",
            "随便写写", "瞎写的", "胡编的"
        ]
        
        answer_lower = student_answer.lower()
        for pattern in irrelevant_patterns:
            if pattern in answer_lower:
                return {
                    "is_relevant": False, 
                    "reason": f"包含明显无关内容: '{pattern}'"
                }
        
        # 如果完全没有关键词重叠且答案较短，认为不相关
        if overlap_ratio == 0 and len(student_answer.strip()) < 15:  # 提高长度阈值
            return {
                "is_relevant": False, 
                "reason": f"与题目无关键词重叠且答案过短 (重叠率: {overlap_ratio:.2f})"
            }
        
        # 如果关键词重叠度太低，认为相关性较差
        if overlap_ratio < 0.05:  # 降低阈值，更宽松
            return {
                "is_relevant": False, 
                "reason": f"关键词重叠度过低 (重叠率: {overlap_ratio:.2f})"
            }
        
        return {
            "is_relevant": True, 
            "reason": f"答案相关 (关键词重叠率: {overlap_ratio:.2f})"
        }
    
    def apply_strict_grading_rules(self, student_answer: str, question_text: str, 
                                  reference_answer: str, max_score: float) -> Dict[str, Any]:
        """应用严格的评分规则"""
        
        # 检查无意义答案
        meaningless_check = self.check_meaningless_answer(student_answer)
        if meaningless_check["is_meaningless"]:
            return {
                "should_override": True,
                "final_score": 0.0,
                "confidence": 1.0,
                "feedback": f"无意义答案: {meaningless_check['reason']}",
                "rule_applied": "无意义答案检测"
            }
        
        # 检查答案相关性
        relevance_check = self.check_answer_relevance(student_answer, question_text, reference_answer)
        if not relevance_check["is_relevant"]:
            return {
                "should_override": True,
                "final_score": 0.0,
                "confidence": 0.9,
                "feedback": f"答案与题目不相关: {relevance_check['reason']}",
                "rule_applied": "答案相关性检测"
            }
        
        return {
            "should_override": False,
            "final_score": None,
            "confidence": None,
            "feedback": "通过严格规则检查",
            "rule_applied": "无规则应用"
        }
    
    def validate_ai_grading_reasonableness(self, ai_result: Dict[str, Any], student_answer: str, 
                                         reference_answer: str, max_score: float, question_text: str = "") -> Dict[str, Any]:
        """验证AI评分的合理性"""
        if not ai_result or 'score' not in ai_result:
            return {"is_reasonable": False, "reason": "AI评分结果无效"}
        
        ai_score = float(ai_result.get('score', 0))
        ai_confidence = float(ai_result.get('confidence', 0))
        
        # 基本合理性检查
        if not (0 <= ai_score <= max_score):
            return {"is_reasonable": False, "reason": f"AI评分超出范围: {ai_score}"}
        
        if not (0 <= ai_confidence <= 1.0):
            return {"is_reasonable": False, "reason": f"AI置信度超出范围: {ai_confidence}"}
        
        # 检查AI是否给无意义答案高分
        meaningless_check = self.check_meaningless_answer(student_answer)
        if meaningless_check["is_meaningless"] and ai_score > max_score * 0.2:
            return {
                "is_reasonable": False, 
                "reason": f"AI给无意义答案过高分数: {ai_score}/{max_score} ({meaningless_check['reason']})"
            }
        
        # 更合理的相关性检查（不要太严格）
        # 只有在答案明显不相关且AI给高分时才拒绝
        if reference_answer and question_text:  # 只有在有参考答案和题目时才检查相关性
            relevance_check = self.check_answer_relevance(student_answer, question_text, reference_answer)
            if not relevance_check["is_relevant"] and ai_score > max_score * 0.7:  # 提高阈值到70%
                return {
                    "is_reasonable": False, 
                    "reason": f"AI给明显不相关答案过高分数: {ai_score}/{max_score} ({relevance_check['reason']})"
                }
        
        # 检查反馈质量
        feedback = ai_result.get('feedback', '')
        if len(feedback) < 5:
            return {"is_reasonable": False, "reason": "AI反馈过短"}
        
        # 检查答案长度与分数的合理性（更宽松的检查）
        answer_length = len(student_answer.strip())
        if answer_length < 3 and ai_score > max_score * 0.6:  # 只有在答案极短时才检查
            return {
                "is_reasonable": False, 
                "reason": f"答案过短({answer_length}字符)但AI给分过高: {ai_score}/{max_score}"
            }
        
        return {"is_reasonable": True, "reason": "AI评分合理"}

    def intelligent_grade(self, student_answer: str, reference_answer: str, 
                         question_text: str, max_score: float = 5.0) -> Dict[str, Any]:
        """
        智能评分主函数 - 增强版（包含严格规则检查）
        
        Args:
            student_answer: 学生答案
            reference_answer: 参考答案
            question_text: 题目文本
            max_score: 满分分值
        
        Returns:
            包含评分结果的字典
        """
        try:
            # 文本预处理
            student_answer = self.preprocess_text(student_answer or "")
            reference_answer = self.preprocess_text(reference_answer or "")
            question_text = self.preprocess_text(question_text or "")
            
            # 特殊处理空答案
            if not student_answer or len(student_answer.strip()) == 0:
                return {
                    "score": 0.0,
                    "confidence": 1.0,
                    "feedback": "学生未作答",
                    "details": {
                        "enhanced_components": {"base": 0, "similarity": 0, "completeness": 0, "example_bonus": 0},
                        "semantic_similarity": 0.0,
                        "completeness": 0.0,
                        "has_examples": False,
                        "ai_result": "空答案，跳过AI评分",
                        "strict_rules": {"rule_applied": "空答案检测", "override": True},
                        "grading_time": datetime.now().isoformat(),
                        "algorithm": "Strict Rules - Empty Answer"
                    }
                }
            
            # 第一步：应用严格评分规则
            strict_rules_result = self.apply_strict_grading_rules(
                student_answer, question_text, reference_answer, max_score
            )
            
            if strict_rules_result["should_override"]:
                return {
                    "score": strict_rules_result["final_score"],
                    "confidence": strict_rules_result["confidence"],
                    "feedback": strict_rules_result["feedback"],
                    "details": {
                        "enhanced_components": {"base": 0, "similarity": 0, "completeness": 0, "example_bonus": 0},
                        "semantic_similarity": 0.0,
                        "completeness": 0.0,
                        "has_examples": False,
                        "ai_result": "被严格规则覆盖",
                        "strict_rules": strict_rules_result,
                        "grading_time": datetime.now().isoformat(),
                        "algorithm": f"Strict Rules - {strict_rules_result['rule_applied']}"
                    }
                }
            
            # 第二步：使用增强评分算法
            enhanced_result = self.calculate_enhanced_score(student_answer, reference_answer, max_score)
            
            # 第三步：如果模型加载成功，尝试使用AI评分
            ai_result = None
            final_score = enhanced_result['score']
            final_confidence = enhanced_result['confidence']
            final_feedback = enhanced_result['feedback']
            algorithm_used = "Enhanced Algorithm"
            
            if self.model is not None:
                try:
                    prompt = self._create_grading_prompt(question_text, reference_answer, student_answer, max_score)
                    response = self._generate_with_qwen(prompt)
                    ai_result = self._extract_json_from_response(response)
                    
                    # 验证AI评分合理性
                    if ai_result and 'score' in ai_result:
                        ai_reasonableness = self.validate_ai_grading_reasonableness(
                            ai_result, student_answer, reference_answer, max_score, question_text
                        )
                        
                        if ai_reasonableness["is_reasonable"]:
                            # AI评分合理，进行融合
                            ai_score = float(ai_result.get('score', 0))
                            enhanced_score = enhanced_result['score']
                            ai_confidence = float(ai_result.get('confidence', 0.5))
                            
                            # 智能融合策略 - 增强版（更宽松的评分）
                            score_diff = abs(ai_score - enhanced_score)
                            
                            # 根据答案质量调整融合策略
                            semantic_sim = enhanced_result['components']['similarity']
                            has_examples = enhanced_result['components']['example_bonus'] > 0
                            is_detailed = enhanced_result['components']['completeness'] > 0.8
                            
                            # 更宽松的融合策略 - 倾向于给高分
                            if score_diff <= max_score * 0.1:
                                # 分数差异很小，适度信任AI，但倾向于高分
                                final_score = max(ai_score, enhanced_score) * 0.8 + min(ai_score, enhanced_score) * 0.2
                                final_confidence = min(ai_confidence * 0.8 + enhanced_result['confidence'] * 0.2, 1.0)
                                final_feedback = f"{enhanced_result['feedback']}；AI评分一致，取较优结果"
                            elif score_diff <= max_score * 0.25:
                                # 分数差异中等，采用宽松策略
                                if semantic_sim > 0.3 or (has_examples and is_detailed):
                                    # 答案有一定质量，显著倾向于高分
                                    higher_score = max(ai_score, enhanced_score)
                                    lower_score = min(ai_score, enhanced_score)
                                    final_score = higher_score * 0.85 + lower_score * 0.15
                                    final_confidence = ai_confidence * 0.7
                                    final_feedback = f"{enhanced_result['feedback']}；答案质量尚可，采用宽松评分策略"
                                else:
                                    # 答案质量一般，仍然倾向于高分但更保守
                                    higher_score = max(ai_score, enhanced_score)
                                    lower_score = min(ai_score, enhanced_score)
                                    final_score = higher_score * 0.75 + lower_score * 0.25
                                    final_confidence = enhanced_result['confidence'] * 0.8
                                    final_feedback = f"{enhanced_result['feedback']}；采用相对宽松的评分策略"
                            else:
                                # 分数差异较大，更加宽松的处理
                                higher_score = max(ai_score, enhanced_score)
                                lower_score = min(ai_score, enhanced_score)
                                
                                if semantic_sim > 0.4 or (has_examples and is_detailed):
                                    # 答案确实有价值，显著倾向于高分，接近满分策略
                                    if semantic_sim > 0.6 and not strict_rules_result["should_override"]:
                                        # 语义相似度高且未被严格规则拒绝，给接近满分
                                        final_score = max(higher_score, max_score * 0.85)
                                        final_feedback = f"{enhanced_result['feedback']}；意思基本符合，给予高分"
                                    else:
                                        # 一般质量但有价值，倾向于高分
                                        final_score = higher_score * 0.8 + lower_score * 0.2
                                        final_feedback = f"{enhanced_result['feedback']}；答案有价值，倾向于高分评价"
                                    
                                    final_confidence = enhanced_result['confidence'] * 0.7
                                    
                                elif semantic_sim > 0.2 and not strict_rules_result["should_override"]:
                                    # 有一定相关性且未被严格规则拒绝，给予中等偏上分数
                                    final_score = max(higher_score, max_score * 0.6)
                                    final_confidence = enhanced_result['confidence'] * 0.6
                                    final_feedback = f"{enhanced_result['feedback']}；答案相关性尚可，给予中等偏上分数"
                                
                                else:
                                    # 质量较差但仍给予基础分
                                    final_score = max(higher_score * 0.6, max_score * 0.3)  # 至少给30%分数
                                    final_confidence = enhanced_result['confidence'] * 0.5
                                    final_feedback = f"{enhanced_result['feedback']}；基于宽松原则给予基础分数"
                            
                            # 确保最终分数不会太低（至少给20%的基础分，除非被严格规则拒绝）
                            if not strict_rules_result["should_override"] and final_score < max_score * 0.2:
                                final_score = max_score * 0.2
                                final_feedback += "；基于宽松评分原则提升至基础分数"
                            
                            algorithm_used = "Enhanced + AI Fusion (Lenient Strategy)"
                        else:
                            # AI评分不合理，使用增强算法
                            final_score = enhanced_result['score']
                            final_confidence = enhanced_result['confidence'] * 0.8
                            final_feedback = f"{enhanced_result['feedback']}；AI评分不合理已忽略 ({ai_reasonableness['reason']})"
                            algorithm_used = "Enhanced Algorithm (AI Rejected)"
                            ai_result["validation_failed"] = ai_reasonableness["reason"]
                    
                except Exception as e:
                    logger.warning(f"AI评分失败，使用增强算法: {str(e)}")
                    final_score = enhanced_result['score']
                    final_confidence = enhanced_result['confidence']
                    final_feedback = enhanced_result['feedback']
                    algorithm_used = "Enhanced Algorithm (AI Failed)"
            else:
                # 模型未加载，使用增强算法（宽松模式）
                final_score = enhanced_result['score']
                final_confidence = enhanced_result['confidence']
                final_feedback = f"{enhanced_result['feedback']}（基于宽松算法评分）"
                algorithm_used = "Enhanced Algorithm (Lenient Mode)"
            
            # 构建最终结果
            final_result = {
                "score": round(min(max(final_score, 0.0), max_score), 1),
                "confidence": round(min(max(final_confidence, 0.0), 1.0), 3),
                "feedback": final_feedback,
                "details": {
                    "enhanced_components": enhanced_result['components'],
                    "semantic_similarity": enhanced_result['components']['similarity'],
                    "completeness": enhanced_result['components']['completeness'],
                    "has_examples": self.has_examples_or_details(student_answer),
                    "ai_result": ai_result if ai_result else "AI评分未使用",
                    "strict_rules": strict_rules_result,
                    "grading_time": datetime.now().isoformat(),
                    "algorithm": algorithm_used
                }
            }
            
            logger.info(f"评分完成: {final_result['score']:.1f}/{max_score} (置信度: {final_result['confidence']:.2f}) - {algorithm_used}")
            return final_result
            
        except Exception as e:
            logger.error(f"智能评分失败: {str(e)}")
            # 最后的降级方案
            try:
                fallback_result = self.calculate_enhanced_score(student_answer or "", reference_answer or "", max_score)
                return {
                    "score": fallback_result['score'],
                    "confidence": 0.2,
                    "feedback": f"评分出错，使用降级算法: {fallback_result['feedback']}",
                    "details": {"error": str(e), "algorithm": "Fallback Enhanced"}
                }
            except:
                return {
                    "score": 0.0,
                    "confidence": 0.0,
                    "feedback": f"评分系统出错: {str(e)}",
                    "details": {"error": str(e), "algorithm": "Error"}
                }
    
    def batch_intelligent_grade(self, answers_data: List[Dict]) -> List[Dict]:
        """
        批量智能评分 - 改进版
        
        Args:
            answers_data: 包含答案数据的列表
        
        Returns:
            评分结果列表
        """
        results = []
        total = len(answers_data)
        
        logger.info(f"开始批量AI评分，共 {total} 道题")
        
        for i, data in enumerate(answers_data):
            try:
                result = self.intelligent_grade(
                    student_answer=data.get('student_answer', ''),
                    reference_answer=data.get('reference_answer', ''),
                    question_text=data.get('question_text', ''),
                    max_score=data.get('max_score', 5.0)
                )
                
                # 添加原始数据信息
                result.update({
                    'question_score_id': data.get('question_score_id'),
                    'student_id': data.get('student_id')
                })
                
                results.append(result)
                
                if (i + 1) % 5 == 0:  # 更频繁的进度报告
                    logger.info(f"批量评分进度: {i + 1}/{total}")
                    
            except Exception as e:
                logger.error(f"批量评分第{i+1}题失败: {str(e)}")
                results.append({
                    'question_score_id': data.get('question_score_id'),
                    'student_id': data.get('student_id'),
                    'score': 0.0,
                    'confidence': 0.0,
                    'feedback': f"评分失败: {str(e)}",
                    'details': {'error': str(e), 'algorithm': 'Error'}
                })
        
        logger.info(f"批量AI评分完成，共处理 {len(results)} 道题")
        return results
    
    def get_model_info(self) -> Dict[str, str]:
        """获取模型信息"""
        return {
            "model_name": "Qwen3-0.6B Enhanced with Strict Rules + Lenient Grading",
            "model_path": self.model_path,
            "device": self.device,
            "status": "已加载" if self.model else "未加载",
            "version": "3.1.0 - Enhanced Algorithm + Strict Rules + Lenient Strategy",
            "features": "语义相似度 + 完整性评估 + 示例检测 + AI融合 + 严格规则检查 + 无意义答案过滤 + 宽松评分策略"
        }

# 全局变量
_qwen_grader = None

def get_qwen_grader(model_path: Optional[str] = None) -> QwenIntelligentGrader:
    """
    获取Qwen智能评分器单例
    
    Args:
        model_path: 模型路径
    
    Returns:
        QwenIntelligentGrader实例
    """
    global _qwen_grader
    
    if _qwen_grader is None:
        _qwen_grader = QwenIntelligentGrader(model_path)
    
    return _qwen_grader

def test_qwen_grader():
    """测试Qwen评分器 - 改进版"""
    try:
        grader = get_qwen_grader()
        
        # 测试用例 - 包含无意义答案测试
        test_cases = [
            {
                'name': '列表推导式测试',
                'question_text': '请简述Python列表推导式的特点',
                'reference_answer': '列表推导式是一种简洁的创建列表的方法',
                'student_answer': '列表推导式是Python中快速生成列表的一种简洁语法。举例：`[x**2 for x in range(5)]` 生成平方数列表 `[0, 1, 4, 9, 16]`。',
                'max_score': 10.0
            },
            {
                'name': '无意义答案测试1',
                'question_text': '请简述Python的主要特点',
                'reference_answer': 'Python是一种解释型、面向对象、动态类型的高级编程语言，具有语法简洁、易学易用的特点',
                'student_answer': '我不知道',
                'max_score': 5.0
            },
            {
                'name': '无意义答案测试2',
                'question_text': '请说明函数的作用',
                'reference_answer': '函数是一段可重复使用的代码块',
                'student_answer': '不会',
                'max_score': 5.0
            },
            {
                'name': '无关答案测试',
                'question_text': '请解释变量的概念',
                'reference_answer': '变量是存储数据的容器',
                'student_answer': '今天天气真好',
                'max_score': 5.0
            },
            {
                'name': '过短无意义答案测试',
                'question_text': '请描述循环的用途',
                'reference_answer': '循环用于重复执行代码块',
                'student_answer': '嗯嗯',
                'max_score': 5.0
            },
            {
                'name': '正常答案测试',
                'question_text': '请简述Python的主要特点',
                'reference_answer': 'Python是一种解释型、面向对象、动态类型的高级编程语言，具有语法简洁、易学易用的特点',
                'student_answer': 'Python是解释型语言，面向对象，语法简单',
                'max_score': 5.0
            },
            {
                'name': '空答案测试',
                'question_text': '请说明函数的作用',
                'reference_answer': '函数是一段可重复使用的代码块',
                'student_answer': '',
                'max_score': 5.0
            }
        ]
        
        print("🧪 Qwen评分器增强版测试结果（包含严格规则检查）:")
        print("=" * 60)
        
        for i, test_data in enumerate(test_cases, 1):
            result = grader.intelligent_grade(
                question_text=test_data['question_text'],
                reference_answer=test_data['reference_answer'],
                student_answer=test_data['student_answer'],
                max_score=test_data['max_score']
            )
            
            print(f"\n测试 {i}: {test_data['name']}")
            print(f"学生答案: '{test_data['student_answer']}'")
            print(f"得分: {result['score']}/{test_data['max_score']}")
            print(f"置信度: {result['confidence']}")
            print(f"反馈: {result['feedback']}")
            print(f"算法: {result['details']['algorithm']}")
            
            # 显示严格规则检查结果
            if 'strict_rules' in result['details']:
                strict_rules = result['details']['strict_rules']
                if strict_rules.get('should_override', False):
                    print(f"🚨 严格规则触发: {strict_rules['rule_applied']}")
                else:
                    print(f"✅ 通过严格规则检查")
            
            # 显示AI验证结果
            if 'ai_result' in result['details'] and isinstance(result['details']['ai_result'], dict):
                ai_result = result['details']['ai_result']
                if 'validation_failed' in ai_result:
                    print(f"⚠️ AI评分被拒绝: {ai_result['validation_failed']}")
                else:
                    print(f"🤖 AI评分通过验证")
        
        print("\n" + "=" * 60)
        print("✅ 严格规则检查测试完成！")
        print("📋 测试总结:")
        print("- 无意义答案应该得0分")
        print("- 无关答案应该得0分")
        print("- 过短无意义答案应该得0分")
        print("- 空答案应该得0分")
        print("- 正常答案应该得到合理分数")
        
    except Exception as e:
        print(f"❌ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_qwen_grader() 