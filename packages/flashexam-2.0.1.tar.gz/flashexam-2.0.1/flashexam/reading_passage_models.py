#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阅读理解材料和题目的数据模型
用于托福TPO风格的阅读理解管理
"""

from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime

@dataclass
class ReadingPassage:
    """阅读材料模型"""
    id: Optional[int] = None
    title: str = ""           # 阅读材料标题
    content: str = ""         # 阅读材料内容
    source: str = ""          # 来源（如：托福、雅思、考研等）
    topic: str = ""           # 主题分类（如：科学、社会、文学等）
    difficulty_level: int = 2 # 难度等级 1-5
    word_count: int = 0       # 字数统计
    reading_time: int = 0     # 建议阅读时间（分钟）
    language: str = "en"      # 语言：en=英语, cn=中文
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    is_active: bool = True    # 是否启用

@dataclass
class PassageQuestion:
    """阅读材料关联题目模型"""
    id: Optional[int] = None
    passage_id: int = 0       # 关联的阅读材料ID
    question_order: int = 1   # 题目在该阅读材料中的顺序
    question_type: str = ""   # 题目类型
    question_text: str = ""   # 题目内容
    options: str = ""         # JSON格式存储选择题选项
    correct_answer: str = ""  # 正确答案
    explanation: str = ""     # 答案解析
    difficulty: int = 2       # 题目难度 1-5
    points: float = 1.0       # 题目分值
    time_limit: int = 0       # 单题时间限制（秒），0表示无限制
    skill_focus: str = ""     # 考查技能（如：主旨大意、细节理解、推理判断等）
    created_at: Optional[datetime] = None
    is_active: bool = True

@dataclass
class PassageSet:
    """阅读材料集合模型（用于组卷）"""
    id: Optional[int] = None
    title: str = ""           # 集合标题
    description: str = ""     # 描述
    exam_type: str = ""       # 考试类型（托福、雅思、考研等）
    total_passages: int = 0   # 包含的阅读材料数量
    total_questions: int = 0  # 包含的题目总数
    time_limit: int = 60      # 总时间限制（分钟）
    difficulty_level: int = 2 # 整体难度
    created_at: Optional[datetime] = None
    is_active: bool = True

@dataclass
class PassageSetItem:
    """阅读材料集合项目模型"""
    id: Optional[int] = None
    set_id: int = 0           # 所属集合ID
    passage_id: int = 0       # 阅读材料ID
    passage_order: int = 1    # 在集合中的顺序
    created_at: Optional[datetime] = None

@dataclass
class PassageExamResult:
    """阅读理解考试结果模型"""
    id: Optional[int] = None
    set_id: int = 0           # 考试集合ID
    student_id: int = 0       # 学生ID
    passage_results: str = ""  # JSON格式存储每个阅读材料的结果
    total_score: float = 0.0   # 总分
    total_possible: float = 0.0 # 总满分
    percentage: float = 0.0    # 得分率
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    time_spent: int = 0        # 总用时（秒）
    is_completed: bool = False
    created_at: Optional[datetime] = None

@dataclass
class PassageQuestionResult:
    """阅读理解题目结果详情"""
    id: Optional[int] = None
    exam_result_id: int = 0    # 关联考试结果ID
    passage_id: int = 0        # 阅读材料ID
    question_id: int = 0       # 题目ID
    student_answer: str = ""   # 学生答案
    correct_answer: str = ""   # 正确答案
    is_correct: bool = False   # 是否正确
    score: float = 0.0         # 得分
    max_score: float = 1.0     # 满分
    time_spent: int = 0        # 用时（秒）
    created_at: Optional[datetime] = None 