"""Tests for FlashExam code executor."""

import pytest
from flashexam.code_executor import CodeExecutor, ExecutionResult


class TestCodeExecutor:
    """Test code executor functionality."""
    
    def test_executor_creation(self):
        """Test executor can be created."""
        executor = CodeExecutor()
        assert executor.timeout == 10
        assert executor.max_output == 10000
    
    def test_python_hello_world(self):
        """Test Python code execution."""
        executor = CodeExecutor()
        result = executor.execute('print("Hello, World!")', 'python')
        assert result.success
        assert "Hello, World!" in result.output
    
    def test_python_calculation(self):
        """Test Python calculation."""
        executor = CodeExecutor()
        result = executor.execute('print(2 + 2)', 'python')
        assert result.success
        assert "4" in result.output
    
    def test_unsupported_language(self):
        """Test unsupported language returns error."""
        executor = CodeExecutor()
        result = executor.execute('print("test")', 'unsupported')
        assert not result.success
        assert "不支持的语言" in result.error
    
    def test_security_check(self):
        """Test security check blocks dangerous code."""
        executor = CodeExecutor()
        result = executor.execute('import os', 'python')
        assert not result.success
        assert "安全检查未通过" in result.error
    
    def test_timeout(self):
        """Test code execution timeout."""
        executor = CodeExecutor(timeout=1)
        result = executor.execute('import time; time.sleep(10)', 'python')
        # Should be blocked by security check first
        assert not result.success


class TestExecutionResult:
    """Test execution result dataclass."""
    
    def test_result_creation(self):
        """Test result can be created."""
        result = ExecutionResult(
            success=True,
            output="test",
            error="",
            execution_time=100.0,
            exit_code=0
        )
        assert result.success
        assert result.output == "test"
        assert result.execution_time == 100.0