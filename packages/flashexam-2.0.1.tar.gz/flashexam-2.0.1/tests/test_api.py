"""Tests for FlashExam API endpoints."""

import pytest
from flashexam import create_app


@pytest.fixture
def app():
    """Create test application."""
    app = create_app('development')
    app.config['TESTING'] = True
    yield app


@pytest.fixture
def client(app):
    """Create test client."""
    return app.test_client()


class TestAPIEndpoints:
    """Test API endpoints."""
    
    def test_status_endpoint(self, client):
        """Test /api/status endpoint."""
        response = client.get('/api/status')
        assert response.status_code == 200
        data = response.get_json()
        assert data['status'] == 'ok'
    
    def test_health_endpoint(self, client):
        """Test /api/health endpoint."""
        response = client.get('/api/health')
        assert response.status_code == 200
        data = response.get_json()
        assert 'status' in data
    
    def test_languages_endpoint(self, client):
        """Test /api/languages endpoint."""
        response = client.get('/api/languages')
        assert response.status_code == 200
        data = response.get_json()
        assert data['success']
        assert len(data['languages']) == 5