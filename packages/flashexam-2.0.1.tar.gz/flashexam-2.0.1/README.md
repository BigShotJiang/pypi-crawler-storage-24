# FlashExam

[![PyPI version](https://badge.fury.io/py/flashexam.svg)](https://badge.fury.io/py/flashexam)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![macOS](https://img.shields.io/badge/macOS-supported-green.svg)]()
[![Linux](https://img.shields.io/badge/Linux-supported-green.svg)]()
[![Windows](https://img.shields.io/badge/Windows-supported-green.svg)]()

**English** | [中文](#中文文档)

---

## FlashExam - Intelligent Online Examination System with AI Grading

A Flask-based intelligent online examination system with AI grading support, compatible with macOS, Linux, and Windows.

### Features

- **Multiple Question Types**: Multiple choice, true/false, short answer, fill-in-the-blank, programming, code execution
- **AI Intelligent Grading**: Subjective question grading based on Qwen model
- **Code Execution**: Online execution support for Python, C, Java, Shell, JavaScript
- **Reading Comprehension**: TOEFL-style reading comprehension exams
- **Real-time Monitoring**: Tab switch detection and anti-cheating features
- **Batch Import**: Import questions and students via Excel/CSV
- **Admin Panel**: Teacher account management and system configuration
- **Cross-platform**: Supports macOS, Linux, Windows

### Quick Start

#### Installation

```bash
# Install from PyPI
pip install flashexam

# Or install from source
git clone https://github.com/cycleuser/flashexam.git
cd flashexam
pip install -e .
```

#### Initialize Database

```bash
flashexam --init-db
```

#### Start Server

```bash
# Development mode (default)
flashexam

# Production mode
flashexam --mode prod

# High-performance mode
flashexam --mode high-perf --workers 8

# Custom port
flashexam --port 8080
```

#### Access the System

- Homepage: http://localhost:5000
- Teacher Portal: http://localhost:5000/teacher
- Student Portal: http://localhost:5000/student
- Admin Panel: http://localhost:5000/admin

First startup requires setting up an administrator account.

### Command Line Arguments

```
flashexam [options]

Options:
  --mode {dev,prod,high-perf}  Run mode (default: dev)
  --host HOST                  Bind address (default: 0.0.0.0)
  --port PORT                  Port number (default: 5000)
  --workers N                  Worker processes (default: 4)
  --init-db                    Initialize database
  --version                    Show version information
```

### Project Structure

```
flashexam/
├── __init__.py          # Application factory
├── cli.py               # CLI entry point
├── database.py          # Database operations
├── teacher.py           # Teacher endpoints
├── student.py           # Student endpoints
├── auth.py              # Authentication module
├── admin.py             # Admin module
├── api.py               # API endpoints
├── code_executor.py     # Code executor
├── models.py            # Data models
├── utils.py             # Utility functions
├── templates/           # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── auth/
│   ├── student/
│   ├── teacher/
│   └── admin/
├── static/              # Static resources
│   ├── css/
│   └── js/
└── storage/             # Data storage
    └── exam_database.db
```

### Development

#### Install Development Dependencies

```bash
pip install -e ".[dev]"
```

#### Run Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=flashexam

# Run specific test file
pytest tests/test_code_executor.py -v
```

#### Code Style

```bash
ruff check .
ruff format .
```

### Publish to PyPI

```bash
# Linux/macOS
./upload_pypi.sh

# Windows
upload_pypi.bat
```

### Tech Stack

- **Backend**: Flask, SQLite, Flask-Login, Flask-Session
- **Frontend**: Bootstrap 5, jQuery
- **AI**: PyTorch, Transformers, Qwen (optional)
- **Server**: Waitress (production)

### License

This project is licensed under the [GNU General Public License v3.0](LICENSE).

### Contributing

Issues and Pull Requests are welcome!

1. Fork this repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Create a Pull Request

### Author

FlashExam Contributors

### Links

- [GitHub](https://github.com/cycleuser/flashexam)
- [PyPI](https://pypi.org/project/flashexam/)
- [Issues](https://github.com/cycleuser/flashexam/issues)

---

# 中文文档

## FlashExam - 智能在线考试系统

基于 Flask 的智能在线考试系统，支持 AI 智能评分，兼容 macOS、Linux 和 Windows。

### 功能特性

- **多题型支持**: 选择题、判断题、简答题、填空题、编程题、代码执行题
- **AI 智能评分**: 基于 Qwen 模型的主观题智能评分
- **代码执行**: 支持 Python、C、Java、Shell、JavaScript 在线执行
- **阅读理解**: 支持 TOEFL 风格阅读理解考试
- **实时监控**: 考试切屏检测、防作弊功能
- **批量导入**: 支持 Excel/CSV 批量导入题目和学生
- **管理面板**: 教师账户管理、系统配置
- **跨平台**: 支持 macOS、Linux、Windows

### 快速开始

#### 安装

```bash
# 从 PyPI 安装
pip install flashexam

# 或从源码安装
git clone https://github.com/cycleuser/flashexam.git
cd flashexam
pip install -e .
```

#### 初始化数据库

```bash
flashexam --init-db
```

#### 启动服务

```bash
# 开发模式 (默认)
flashexam

# 生产模式
flashexam --mode prod

# 高性能模式
flashexam --mode high-perf --workers 8

# 指定端口
flashexam --port 8080
```

#### 访问系统

- 主页: http://localhost:5000
- 教师端: http://localhost:5000/teacher
- 学生端: http://localhost:5000/student
- 管理面板: http://localhost:5000/admin

首次启动时需要设置管理员账户。

### 命令行参数

```
flashexam [选项]

选项:
  --mode {dev,prod,high-perf}  运行模式 (默认: dev)
  --host HOST                  绑定地址 (默认: 0.0.0.0)
  --port PORT                  端口号 (默认: 5000)
  --workers N                  工作进程数 (默认: 4)
  --init-db                    初始化数据库
  --version                    显示版本信息
```

### 项目结构

```
flashexam/
├── __init__.py          # 应用工厂
├── cli.py               # 命令行入口
├── database.py          # 数据库操作
├── teacher.py           # 教师端路由
├── student.py           # 学生端路由
├── auth.py              # 认证模块
├── admin.py             # 管理模块
├── api.py               # API 接口
├── code_executor.py     # 代码执行器
├── models.py            # 数据模型
├── utils.py             # 工具函数
├── templates/           # HTML 模板
├── static/              # 静态资源
└── storage/             # 数据存储
```

### 开发

#### 安装开发依赖

```bash
pip install -e ".[dev]"
```

#### 运行测试

```bash
# 运行所有测试
pytest

# 运行覆盖率测试
pytest --cov=flashexam

# 运行指定测试文件
pytest tests/test_code_executor.py -v
```

#### 代码风格

```bash
ruff check .
ruff format .
```

### 发布到 PyPI

```bash
# Linux/macOS
./upload_pypi.sh

# Windows
upload_pypi.bat
```

### 技术栈

- **后端**: Flask, SQLite, Flask-Login, Flask-Session
- **前端**: Bootstrap 5, jQuery
- **AI**: PyTorch, Transformers, Qwen (可选)
- **服务器**: Waitress (生产环境)

### 许可证

本项目采用 [GNU General Public License v3.0](LICENSE) 许可证。

### 贡献

欢迎提交 Issue 和 Pull Request！

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建 Pull Request

### 作者

FlashExam Contributors

### 链接

- [GitHub](https://github.com/cycleuser/flashexam)
- [PyPI](https://pypi.org/project/flashexam/)
- [问题反馈](https://github.com/cycleuser/flashexam/issues)