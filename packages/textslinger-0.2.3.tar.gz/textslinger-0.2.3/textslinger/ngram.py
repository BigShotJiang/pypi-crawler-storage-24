from typing import List, Tuple, Final, Optional
from textslinger.language_model import LanguageModel, DecodeConfig
from textslinger.helpers import compute_max_hypo_len
import kenlm
import numpy as np
from heapq import heappush, heappushpop, heappop
from os import path
from dataclasses import dataclass


@dataclass
class DecodeConfigNGram(DecodeConfig):
    """
    Parameters that control the search and pruning behavior when decoding with an n-gram language model
    """

    # Stop the search once we hit this many completed hypotheses, None = don't prune based on this
    max_word_hypotheses: Optional[int] = 100
    # Hypothesis with log prob > than this distance from the best hypothesis are pruned
    beam_best: float = 30.0
    # Maximum number of hypotheses to track during each extension of search
    beam_search_max: int = 100
    # Maximum length of words that can be predicted
    max_word_len: int = 25
    # Constant we multiply language model log probs by
    lm_scale: float = 1.0
    # Log prob penalty for inserting characters between input events, None = insertions not allowed in sequence
    ins_penalty: Optional[float] = -20.0
    # Log prob penalty for inserting characters after input events (auto complete), None = only word end characters allowed
    ins_penalty_after_input: Optional[float] = 0.0
    # Log prob penalty for deleting an event in the input sequence, None = deletions not allowed from sequence
    del_penalty: Optional[float] = -20.0


# Default values for the parameters to predict_words
DEFAULT_MAX_WORD_HYPOTHESES = 256
DEFAULT_BEAM_LOGP_BEST = 5.0
DEFAULT_SEARCH_MAX = 100
DEFAULT_MAX_WORD_LEN = 25

# Constant for converting KenLM log base 10 to log base e
LN_10 = np.log(10)

# TODO: add support for mixed case n-gram models, currently assumes only lowercase plus punctuation
# NOTE: Added predict lower parameter to predict_words, but currently untested since need mixed case n-gram for testing


class NGramLanguageModel(LanguageModel):
    """Character n-gram language model using the KenLM library for querying"""

    def __init__(
        self,
        symbol_set: List[str],
        lm_path: str,
        space_symbol: str = "<sp>",
    ):
        """
        Construct an instance of NGramLanguageModel.
        :param symbol_set: symbols we want to make predictions over
        :param lm_path: location of the n-gram language model, either in ARPA text format or KenLM binary format
        :param space_symbol: pseudo-word for spaces between words
        """
        super().__init__(symbol_set=symbol_set)
        if not path.exists(lm_path):
            print(f"ERROR: {lm_path} does not exist!")
            return

        self.lm_path = lm_path
        self.model = kenlm.LanguageModel(self.lm_path)
        self.state = kenlm.State()
        self.state2 = kenlm.State()
        self.space_symbol = space_symbol

        # Create a parallel version of symbol_set that does any conversion required to bring plain characters into the n-gram's vocab
        self.symbol_set_converted = [
            self.space_symbol if symbol == " " else symbol for symbol in symbol_set
        ]

    # TODO: remove, has been replaced by new version that also does noisy input decoding
    def predict_words_old(
        self,
        left_context: str,
        word_end_symbols: List[str] = None,
        nbest: int = None,
        beam_logp_best: float = None,
        beam_search_max: int = None,
        max_word_len: int = None,
        max_word_hypotheses: int = None,
        predict_lower: bool = True,
        include_ending_symbol: bool = False,
        return_log_probs=False,
        **kwargs,
    ) -> List:

        # We want each language model class set its own default pruning values
        # We want the client keystroke_savings.py to default to these if pruning switches aren't set
        # Values using for EMNLP 2025 paper
        beam_logp_best = beam_logp_best if beam_logp_best is not None else DEFAULT_BEAM_LOGP_BEST
        beam_search_max = beam_search_max if beam_search_max is not None else DEFAULT_SEARCH_MAX
        max_word_len = max_word_len if max_word_len is not None else DEFAULT_MAX_WORD_LEN
        max_word_hypotheses = (
            max_word_hypotheses if max_word_hypotheses is not None else DEFAULT_MAX_WORD_HYPOTHESES
        )

        # Since List is a mutable type, we can't set a default reliably in the method declaration
        # We'll set the default of a trailing space if caller didn't specify a list of right contexts
        word_end_symbols = word_end_symbols if word_end_symbols is not None else [" "]

        state1 = kenlm.State()
        state2 = kenlm.State()
        # Condition the LM on the sentence start token since we may not have enough left context to move <s> out of the markov window
        self.model.BeginSentenceWrite(state1)

        # Update the state one character at a time for the left context
        # Also note the last space so we can figure out the prefix of the current word (if any)
        # Shorten to one character less than the order of the n-gram model
        truncated_left_context = left_context[-self.model.order + 1 :]

        # Advance the language model state based on the left context
        src, dst = state1, state2
        for ch in truncated_left_context:
            ch = self.space_symbol if ch == " " else ch
            self.model.BaseScore(src, ch, dst)
            src, dst = dst, src  # swap buffers
        start_state = src

        # Reusable KenLM state, we use this to compute the probability of next character before we decide if we are keeping it
        temp_out_state = kenlm.State()

        # Create a symbol set that also includes any end of word symbols that aren't in our normal symbol set
        # If any of the end symbols occur in the normal symbol set, we include at end of list
        search_symbols = []
        for symbol in self.symbol_set:
            if symbol not in word_end_symbols:
                search_symbols.append(symbol)
        index_first_end_symbol = len(search_symbols)
        for end_symbol in word_end_symbols:
            search_symbols.append(end_symbol)

        # Parallel version of the set of all search symbols that handles any conversion to pseudo-words needed by LM like <sp>
        search_symbols_converted = []
        for symbol in search_symbols:
            if symbol == " ":
                search_symbols_converted.append(self.space_symbol)
            else:
                search_symbols_converted.append(symbol)

        # We store hypotheses in a list with a tuple (log_prob, current word characters, KenLM state)
        current_hypos = [(0.0, "", start_state)]

        LOGP: Final[int] = 0
        STR: Final[int] = 1
        STATE: Final[int] = 2

        # Finished hypotheses map a word string (without ending symbols) to its log prob
        # We use a dictionary since we may want to merge hypotheses that are the same word
        finished_hypos = {}
        best_finished_log_prob = float("-inf")

        # Compute the maximum length of hypotheses based on existing prefix of word (if any)
        max_hypo_len = None
        if max_word_len:
            max_hypo_len = compute_max_hypo_len(
                left_context=left_context, max_word_len=max_word_len
            )

        # Flag that breaks out of all loops
        done = False

        # Note: Python's heap pops minimum value, so we are going to explore worst first.
        # Might be better to explore best first, but this is in conflict with the need to easily replace the worst hypothesis.
        while len(current_hypos) > 0 and not done:
            # We'll store extended hypotheses in a min heap to make it easy to maintain only a fixed number of the best
            next_hypos = []

            hypo_index = 0
            while hypo_index < len(current_hypos) and not done:
                hypo = current_hypos[hypo_index]
                # print(f"DEBUG, hypo {hypo[0]:.3f} '{hypo[1]}'")
                # Extend this hypothesis by all possible symbols
                # This could include symbols that were specified to end words but aren't valid character inside of words
                for search_index in range(len(search_symbols)):
                    # Compute the new log prob and string for our candidate new hypothesis
                    # NOTE: We convert normal characters to any special version in the LM, e.g. " " -> "<sp>"
                    new_log_prob = hypo[LOGP] + self.model.BaseScore(
                        hypo[STATE],
                        search_symbols_converted[search_index],
                        temp_out_state,
                    )

                    # We avoid adding finished or intermediate hypotheses if they are outside log prob beam
                    # This is a bit faster than only doing it for intermediate hypotheses
                    if (best_finished_log_prob - new_log_prob) < beam_logp_best and len(
                        hypo[STR]
                    ) <= max_word_len:
                        # See if we have finished by generating any of the valid right symbols
                        # These were organized to be at the end of the list of search_symbols
                        if search_index >= index_first_end_symbol and (
                            max_hypo_len is None or len(hypo[STR]) <= max_hypo_len
                        ):
                            # Optionally we marginalize all cases to predict just lowercase words
                            word = hypo[STR].lower() if predict_lower else hypo[STR]
                            # Optionally separate hypotheses by the symbol that ended a word
                            # This might be useful for clients that want to predict "word," versus "word."
                            if include_ending_symbol:
                                word += search_symbols[search_index]
                            # print(
                            #    f"DEBUG, word {word} finished on {search_symbols_converted[search_index]} {new_log_prob:.3f}"
                            # )

                            if word in finished_hypos:
                                # If already had this word finish with a different end symbol we sum the probabilities
                                finished_hypos[word] = np.logaddexp(
                                    finished_hypos[word], new_log_prob
                                )
                            else:
                                # Haven't seen this word, we will just always add it to the dictionary
                                # It would be expensive to maintain a fixed dictionary size of the best finished hypotheses
                                finished_hypos[word] = new_log_prob

                                # Stop the search if we hit a hard cap on distinct completed word hypotheses
                                if (
                                    max_word_hypotheses
                                    and len(finished_hypos) >= max_word_hypotheses
                                ):
                                    done = True
                                    break
                            # Update the current best log prob of any finishing hypothesis
                            best_finished_log_prob = max(best_finished_log_prob, new_log_prob)
                        # This hypothesis didn't finish
                        # Keep if it is still within beam width of our best hypothesis thus far
                        elif max_hypo_len is None or len(hypo[STR]) < max_hypo_len:
                            # This hypothesis is within the beam of the best to date
                            # We'll make a copy of the KenLM state object and extend the string
                            if len(next_hypos) < beam_search_max:
                                # Add if we haven't reached our beam width limit so add
                                heappush(
                                    next_hypos,
                                    (
                                        new_log_prob,
                                        hypo[STR] + search_symbols[search_index],
                                        temp_out_state.__copy__(),
                                    ),
                                )
                            else:
                                # Or replace the worst hypotheses with the new one
                                heappushpop(
                                    next_hypos,
                                    (
                                        new_log_prob,
                                        hypo[STR] + search_symbols[search_index],
                                        temp_out_state.__copy__(),
                                    ),
                                )
                hypo_index += 1
            current_hypos = next_hypos

        # Convert our dictionary of finished hypotheses to a sorted list
        sorted_best = sorted(finished_hypos.items(), key=lambda item: item[1], reverse=True)[:nbest]

        # Optional inclusion of log prob in result
        return [(hypo[0], float(hypo[1])) if return_log_probs else hypo[0] for hypo in sorted_best]

    def predict(self, evidence: List[str], **kwargs) -> List[Tuple[str, float]]:
        # Optional subclass parameters:
        # :param unnormalized_logprobs:  whether to skip symbol normalization and return log probs (base 10), unique parameter to this class
        unnormalized_logprobs = kwargs.get("unnormalized_logprobs", False)

        # Do not modify the original parameter, could affect mixture model
        context = evidence.copy()

        # Limit context based on the context length of the n-gram model
        context = context[-(self.model.order - 1) :]

        # Replace spaces with whatever the n-gram model uses for a space
        context = [self.space_symbol if ch == " " else ch for ch in context]

        self.model.BeginSentenceWrite(self.state)

        # Update the state one token at a time based on evidence, alternate states
        # Alternate between state buffers while processing context
        state_a, state_b = self.state, self.state2
        for token in context:
            self.model.BaseScore(state_a, token, state_b)
            state_a, state_b = state_b, state_a  # swap buffers
        final_state = state_a

        temp_state = kenlm.State()

        # Compute the log prob (base 10) of everything in our symbol set
        log_probs = []
        for char in self.symbol_set:
            if char == " ":
                char = self.space_symbol
            log_probs.append(self.model.BaseScore(final_state, char, temp_state))
        log_probs = np.array(log_probs, dtype=np.float64)

        if unnormalized_logprobs:
            # We don't want to normalize the probabilities, just return the raw log probability (base 10) for each
            # This is useful, e.g. for comparing against SRILM's result using a LM's full vocab
            probs = log_probs
        else:
            # Numerically stable log-sum-exp normalization (base 10)
            m = log_probs.max()
            probs = np.power(10.0, log_probs - m)
            probs /= probs.sum(dtype=np.float64)

        return sorted(
            ((s, float(p.item())) for s, p in zip(self.symbol_set, probs)),
            key=lambda x: x[1],
            reverse=True,
        )

    def score_item(self, item: str) -> float:
        """
        Get the log prob of a string conditioned on sentence start
        :param item: a text string to score
        :return: the log prob (base e) of a text string conditioned on sentence start
        """
        return float(self.model.score(self._text_to_letters(item), bos=True, eos=False) * LN_10)

    def score_items(self, items: List[str], **kwargs) -> List[float]:
        """
        Get the log prob of a list of strings
        :param items: a list of strings to score
        :return: the list of log probs (base e) of the strings
        """
        results = []
        for item in items:
            results.append(self.score_item(item=item))
        return results

    def _text_to_letters(self, text: str) -> str:
        """
        Convert a normal string like "the cat sat" into letters separated by whitespace.
        Any spaces in the original string will be replaced with our space word.
        This is useful for scoring an entire sentence with the KenLM score or full_scores method.
        :param text: text to convert
        :return: converted text
        """
        result = ""
        for i in range(len(text)):
            if len(result) > 0:
                result += " "
            if text[i] == " ":
                result += self.space_symbol
            else:
                result += text[i]
        return result

    def predict_words(
        self,
        left_context: str = "",
        input_sequence: List[List[Tuple[str, float]]] = None,
        config: DecodeConfigNGram = DecodeConfigNGram(),
        word_end_symbols: List[str] = None,
        nbest: int = None,
        predict_lower: bool = True,
        include_ending_symbol: bool = False,
        return_log_probs=False,
    ) -> List:
        # Since List is a mutable type, we can't set a default reliably in the method declaration
        # We'll set the default of a trailing space if caller didn't specify a list of right contexts
        word_end_symbols = word_end_symbols if word_end_symbols is not None else [" "]

        if not input_sequence:
            input_sequence = []

        state1 = kenlm.State()
        state2 = kenlm.State()
        # Condition the LM on the sentence start token since we may not have enough left context to move <s> out of the markov window
        self.model.BeginSentenceWrite(state1)

        # Update the state one character at a time for the left context
        # Also note the last space so we can figure out the prefix of the current word (if any)
        # Shorten to one character less than the order of the n-gram model
        truncated_left_context = left_context[-self.model.order + 1 :]

        # Advance the language model state based on the left context
        src, dst = state1, state2
        for ch in truncated_left_context:
            ch = self.space_symbol if ch == " " else ch
            self.model.BaseScore(src, ch, dst)
            src, dst = dst, src  # swap buffers
        start_state = src

        # Reusable KenLM state, we use this to compute the probability of next character before we decide if we are keeping it
        temp_out_state = kenlm.State()

        # Create a symbol set that also includes any end of word symbols that aren't in our normal symbol set
        # If any of the end symbols occur in the normal symbol set, we include at end of list
        search_symbols = []
        for symbol in self.symbol_set:
            if symbol not in word_end_symbols:
                search_symbols.append(symbol)
        index_first_end_symbol = len(search_symbols)
        for end_symbol in word_end_symbols:
            search_symbols.append(end_symbol)

        # Parallel version of the set of all search symbols that handles any conversion to pseudo-words needed by LM like <sp>
        search_symbols_converted = []
        for symbol in search_symbols:
            if symbol == " ":
                search_symbols_converted.append(self.space_symbol)
            else:
                search_symbols_converted.append(symbol)

        # We store hypotheses in a list with a tuple (log_prob, current hypothesis text, KenLM state, index into input sequence)
        current_hypos = [(0.0, "", start_state, 0, "")]

        LOGP: Final[int] = 0  # Log probability of the hypothesis
        STR: Final[int] = 1  # Hypothesis text thus far
        STATE: Final[int] = 2  # KenLM state
        INDEX: Final[int] = 3  # Current index into the noisy input sequence
        TYPE: Final[int] = 4  # Optional tracking of type of extension

        # Finished hypotheses map a word string (without ending symbols) to its log prob
        # We use a dictionary since we may want to merge hypotheses that are the same word
        finished_hypos = {}
        best_finished_log_prob = float("-inf")

        # Compute the maximum length of hypotheses based on existing prefix of word (if any)
        max_hypo_len = None
        if config.max_word_len:
            max_hypo_len = compute_max_hypo_len(
                left_context=left_context, max_word_len=config.max_word_len
            )

        # Flag that breaks out of all loops
        done = False

        # Precompute this since we always multiply by KenLM BaseScore's by this
        LN_10_SCALE_FACTOR = LN_10 * config.lm_scale

        # Allow quick lookup of a symbol at a given position in the input sequence
        input_sequence_dict = [dict(event) for event in input_sequence]

        # Note: Python's heap pops minimum value, so we are going to explore worst first.
        # Might be better to explore best first, but this is in conflict with the need to easily replace the worst hypothesis.
        while len(current_hypos) > 0 and not done:
            # We'll store extended hypotheses in a min heap to make it easy to maintain only a fixed number of the best
            next_hypos = []

            hypo_index = 0
            while hypo_index < len(current_hypos) and not done:
                hypo = current_hypos[hypo_index]
                hypo_at_end = hypo[INDEX] == len(input_sequence)
                # print(
                #    f"DEBUG, hypo {hypo[0]:.3f} '{hypo[1]}' {hypo[3]} {hypo[4]}, hypo_at_end {hypo_at_end}"
                # )

                # If we are still generating the input sequence we could consume an event by deletion
                if config.del_penalty and hypo[INDEX] < len(input_sequence):
                    # No need for a language model query since no new symbol generated
                    # Can't make string longer but might get pruned for other reasons
                    del_log_prob = hypo[LOGP] + config.del_penalty
                    if (best_finished_log_prob - del_log_prob) < config.beam_best:
                        del_hypo = (
                            del_log_prob,
                            hypo[STR],
                            hypo[STATE].__copy__(),
                            hypo[INDEX] + 1,
                            hypo[TYPE] + "D",
                        )
                        if len(next_hypos) < config.beam_search_max:
                            # We haven't reached the beam width for this ply of the search
                            heappush(next_hypos, del_hypo)
                        else:
                            # Or replace the worst hypotheses with the new one
                            heappushpop(next_hypos, del_hypo)

                # For insertion events or extending past the input sequence (auto complete)
                # we will need the probability of all next symbols given this hypothesis.
                # We also will need these for generating events in the current sequence position.
                # Precompute dictionary: symbol -> (log prob to generate symbol, KenLM state)
                symbol_to_prob_state = {}
                for search_index, symbol in enumerate(search_symbols_converted):
                    # We convert to base e right away and also apply the LM scale factor
                    # We also add to the existing hypothesis log prob
                    log_prob = hypo[LOGP] + float(
                        self.model.BaseScore(
                            hypo[STATE],
                            symbol,
                            temp_out_state,
                        )
                        * LN_10_SCALE_FACTOR
                    )
                    symbol_to_prob_state[search_symbols[search_index]] = (
                        log_prob,
                        temp_out_state.__copy__(),
                    )

                # Loop will handle both substitutions that consume events in input sequence,
                # insertion within the input sequence, or insertion after it is consumed (auto complete)
                for search_index, symbol in enumerate(search_symbols):
                    # Note: This dictionary already has the current hypothesis log prob plus LM * scale factor
                    new_log_prob = symbol_to_prob_state[symbol][0]
                    new_state = symbol_to_prob_state[symbol][1]

                    # First check this extension is even possible before additional penalties
                    if (best_finished_log_prob - new_log_prob) < config.beam_best:
                        is_end_symbol = search_index >= index_first_end_symbol
                        # First handling symbols that are in the current input event set
                        if (
                            hypo[INDEX] < len(input_sequence)
                            and symbol in input_sequence_dict[hypo[INDEX]]
                        ):
                            # print(f"DEBUG, SUB")
                            # We are a symbol in the current position in the input, generate and advance
                            sub_log_prob = new_log_prob + input_sequence_dict[hypo[INDEX]][symbol]
                            if (best_finished_log_prob - sub_log_prob) < config.beam_best:
                                if is_end_symbol and hypo[INDEX] == len(input_sequence) - 1:
                                    # By generating this event, the hypothesis reached a valid ending
                                    # Optionally we marginalize all cases to predict just lowercase words
                                    word = hypo[STR].lower() if predict_lower else hypo[STR]
                                    # Optionally separate hypotheses by the symbol that ended a word
                                    # This might be useful for clients that want to predict "word," versus "word."
                                    if include_ending_symbol:
                                        word += symbol
                                    if word in finished_hypos:
                                        # If already had this word finish with a different end symbol we sum the probabilities
                                        finished_hypos[word] = np.logaddexp(
                                            finished_hypos[word], sub_log_prob
                                        )
                                    else:
                                        # Haven't seen this word, we will just always add it to the dictionary
                                        # It would be expensive to maintain a fixed dictionary size of the best finished hypotheses
                                        finished_hypos[word] = sub_log_prob

                                        # Stop the search if we hit a hard cap on distinct completed word hypotheses
                                        if (
                                            config.max_word_hypotheses
                                            and len(finished_hypos) >= config.max_word_hypotheses
                                        ):
                                            done = True
                                            break

                                    # Update the current best log prob of any finishing hypothesis
                                    best_finished_log_prob = max(
                                        best_finished_log_prob, sub_log_prob
                                    )
                                else:
                                    sub_hypo = (
                                        sub_log_prob,
                                        hypo[STR] + symbol,
                                        new_state.__copy__(),
                                        hypo[INDEX] + 1,
                                        hypo[TYPE] + "S",
                                    )
                                    if len(next_hypos) < config.beam_search_max:
                                        # We haven't reached the beam width for this ply of the search
                                        heappush(next_hypos, sub_hypo)
                                    else:
                                        # Or replace the worst hypotheses with the new one
                                        heappushpop(next_hypos, sub_hypo)

                        # We may additionally want to create an insertion hypothesis for this symbol.
                        # This can happen:
                        # 1) During the input sequence (if ins_penalty is on)
                        # 2) After the input sequence (if ins_penalty_after_input is on)
                        # 3) After the input sequence for word end symbols
                        if config.ins_penalty or (
                            hypo_at_end
                            and (config.ins_penalty_after_input is not None or is_end_symbol)
                        ):
                            # print(
                            #    f"DEBUG, INS '{symbol}' {config.ins_penalty} {hypo_at_end} {config.ins_penalty_after_input} {is_end_symbol}"
                            # )

                            # If we are in still inside the input sequence we pay the insertion penalty
                            # But once we are done with the input adding characters is free
                            ins_log_prob = new_log_prob

                            # We have a different penalty for inside the input sequence versus after
                            if not hypo_at_end:
                                ins_log_prob += config.ins_penalty
                            elif config.ins_penalty_after_input:
                                ins_log_prob += config.ins_penalty_after_input

                            if (best_finished_log_prob - ins_log_prob) < config.beam_best:
                                if is_end_symbol and hypo_at_end:
                                    # print(
                                    #    f"DEBUG, INS is_end_symbol {is_end_symbol} hypo_at_end {hypo_at_end} symbol '{symbol}'"
                                    # )
                                    # By generating this event, the hypothesis reached a valid ending
                                    # Optionally we marginalize all cases to predict just lowercase words
                                    word = hypo[STR].lower() if predict_lower else hypo[STR]
                                    # Optionally separate hypotheses by the symbol that ended a word
                                    # This might be useful for clients that want to predict "word," versus "word."
                                    if include_ending_symbol:
                                        word += symbol
                                    # print(
                                    #    f"DEBUG, word {word} finished on {search_symbols_converted[search_index]} {new_log_prob:.3f}"
                                    # )
                                    if word in finished_hypos:
                                        # If already had this word finish with a different end symbol we sum the probabilities
                                        finished_hypos[word] = np.logaddexp(
                                            finished_hypos[word], ins_log_prob
                                        )
                                    else:
                                        # Haven't seen this word, we will just always add it to the dictionary
                                        # It would be expensive to maintain a fixed dictionary size of the best finished hypotheses
                                        finished_hypos[word] = ins_log_prob

                                        # Stop the search if we hit a hard cap on distinct completed word hypotheses
                                        if (
                                            config.max_word_hypotheses
                                            and len(finished_hypos) >= config.max_word_hypotheses
                                        ):
                                            done = True
                                            break
                                    # Update the current best log prob of any finishing hypothesis
                                    best_finished_log_prob = max(
                                        best_finished_log_prob, ins_log_prob
                                    )
                                # Add as a new insertion hypothesis, but not if it has reached the max word length
                                elif max_hypo_len is None or len(hypo[STR]) < max_hypo_len:
                                    ins_hypo = (
                                        ins_log_prob,
                                        hypo[STR] + symbol,
                                        new_state.__copy__(),  # TODO: maybe don't need to copy since last use in loop?
                                        hypo[INDEX],
                                        hypo[TYPE] + "I",
                                    )
                                    if (
                                        config.beam_search_max is None
                                        or len(next_hypos) < config.beam_search_max
                                    ):
                                        # We haven't reached the beam width for this ply of the search
                                        heappush(next_hypos, ins_hypo)
                                    else:
                                        # Or replace the worst hypotheses with the new one
                                        heappushpop(next_hypos, ins_hypo)

                hypo_index += 1
            current_hypos = next_hypos

        # Convert our dictionary of finished hypotheses to a sorted list
        sorted_best = sorted(finished_hypos.items(), key=lambda item: item[1], reverse=True)[:nbest]

        # Optional inclusion of log prob in result
        return [(hypo[0], float(hypo[1])) if return_log_probs else hypo[0] for hypo in sorted_best]
