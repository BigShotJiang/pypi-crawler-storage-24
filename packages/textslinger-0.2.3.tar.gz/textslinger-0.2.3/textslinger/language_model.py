"""Defines the language model base class."""

from abc import ABC, abstractmethod
from typing import List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class DecodeConfig:
    """
    Allows subclasses to receive different parameters for the decode method
    """

    pass


class LanguageModel(ABC):
    """Parent class for language model classes"""

    symbol_set: List[str] = None

    def __init__(self, symbol_set: List[str]):
        self.symbol_set = symbol_set
        self.model = None

    @classmethod
    def name(cls) -> str:
        """Model name used for configuration"""
        suffix = "LanguageModel"
        if cls.__name__.endswith(suffix):
            return cls.__name__[0 : -len(suffix)].upper()
        return cls.__name__.upper()

    @abstractmethod
    def predict(self, evidence: List[str], **kwargs) -> List[Tuple[str, float]]:
        """
        Given an evidence of typed string, predict the probability distribution of the next symbol
        :param evidence: a list of characters (typed by the user)
        :return: A list of symbols with probabilities sorted from most to least probable
        """
        ...

    @abstractmethod
    def score_item(self, item: str) -> float:
        """
        Calculate the log prob of a single item assume the model's default starting context
        :return: log prob base e
        """
        ...

    @abstractmethod
    def score_items(
        self,
        items: List[str],
        **kwargs,
    ) -> List[float]:
        """
        Given a list of sentences or other texts, compute the log prob of each under the language model
        Some subclasses may take optional parameters via kwargs such as batch size
        :param items: list of things we want scored
        :return: list of log probs (base e) for each item in the list
        """
        ...

    def get_num_parameters(self) -> int:
        """
        Find out how many parameters the loaded model has
        If a subclass doesn't implement this method, we return 0
        :return: integer number of parameters in the transformer model
        """
        return 0

    @abstractmethod
    def predict_words(
        self,
        left_context: str = "",
        input_sequence: List[List[Tuple[str, float]]] = None,
        config: DecodeConfig = DecodeConfig(),
        word_end_symbols: List[str] = None,
        nbest: int = None,
        predict_lower: bool = True,
        include_ending_symbol: bool = False,
        return_log_probs=False,
    ) -> List:
        """
        Decode a noisy sequence of input events given some fixed left text context
        :param left_context: fixed left text context
        :param input_sequence: noisy input sequence (if any), each sequence item is a list of (symbol, log prob) tuples
        :param config: controls various penalties and pruning options during the search for the word predictions
        :param word_end_symbols: tuple of symbols that we consider to end a word, defaults to None
        :param nbest: number of most likely words to return
        :param predict_lower: marginalize predictions to lowercase
        :param include_ending_symbol: include end symbol in hypotheses (useful to predict different punctuation after a word)
        :param return_log_probs: whether to return log probs of each word
        :return: the most likely text hypotheses for the input events
        """
        ...
