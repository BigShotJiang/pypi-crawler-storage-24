import torch
from typing import List, Tuple, Final, Optional
from transformers import AutoModelForCausalLM, AutoTokenizer
from textslinger.language_model import LanguageModel, DecodeConfig
from textslinger.helpers import (
    compute_max_hypo_len,
    Device,
    Precision,
    precision_to_dtype,
    convert_device,
)
from textslinger.exceptions import InvalidLanguageModelException
from scipy.special import logsumexp
from heapq import heappush, heappushpop
import torch.nn.functional as F
import numpy as np
from torch.nn.utils.rnn import pad_sequence
from dataclasses import dataclass

# Set to True if we are loading models that require this when creating the model and tokenizer
TRUST_REMOTE_CODE = True


@dataclass
class DecodeConfigByte(DecodeConfig):
    """
    Parameters that control the search and pruning behavior when decoding with a causal byte language model
    """

    # Stop the search once we hit this many completed hypotheses, None = don't prune based on this
    max_word_hypotheses: Optional[int] = 256
    # Hypothesis with log prob > than this distance from the best hypothesis are pruned
    beam_best: float = 8.0
    # Maximum number of hypotheses to track during each extension of search
    beam_search_max: int = 300
    # Maximum length of words that can be predicted
    max_word_len: int = 25

    # TODO: these are not currently used in predict_words
    # Constant we multiply language model log probs by
    # lm_scale: float = 1.0
    # Log prob penalty for inserting characters between input events, None = insertions not allowed in sequence
    # ins_penalty: Optional[float] = -20.0
    # Log prob penalty for inserting characters after input events (auto complete), None = only word end characters allowed
    # ins_penalty_after_input: Optional[float] = 0.0
    # Log prob penalty for deleting an event in the input sequence, None = deletions not allowed from sequence
    # del_penalty: Optional[float] = -20.0

    # How many hypotheses to try and extend in one inference
    batch_size: Optional[int] = None


class CausalByteLanguageModel(LanguageModel):
    """
    Character language model based on a pre-trained causal transformer language model using byte tokenization.
    Currently only tested to support a community version of Meta's latent byte transformer.
    """

    def __init__(
        self,
        symbol_set: List[str],
        lang_model_name: str,
        lm_path: str = None,
        device: Device = Device.AUTO,
        precision: Precision = Precision.FP32,
    ):
        """
        Initialize instance variables and load the language model with given path
        Args:
            response_type      - SYMBOL only
            symbol_set         - list of symbol strings
            lang_model_name    - name of the Hugging Face casual language model to load
            lm_path            - load fine-tuned model from specified directory
            device             - device to use for making predictions (auto, cpu, mps, or cuda)
            precision          - precision to load model (fp32, fp16, bf16)
        """
        super().__init__(symbol_set=symbol_set)

        self.tokenizer = None
        self.vocab_size = 0
        self.device = convert_device(device)
        self.index_to_word = {}
        self.index_to_word_lower = {}
        self.result_to_vocab_indexes = []
        self.symbol_set_lower = None
        self.symbol_index_to_vocab_index = []
        self.symbol_set_lower = []

        # We optionally load the model from a local directory, but if this is not
        # specified, we load a Hugging Face model
        self.model_name = lang_model_name
        self.model_dir = lm_path if lm_path else self.model_name
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(
                self.model_name, use_fast=False, trust_remote_code=TRUST_REMOTE_CODE
            )
        except Exception as e:
            raise InvalidLanguageModelException(
                f"{self.model_name} is not a valid model identifier on HuggingFace."
            ) from e

        self.vocab_size = self.tokenizer.vocab_size
        try:
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_dir,
                trust_remote_code=TRUST_REMOTE_CODE,
                device_map=self.device,
                dtype=precision_to_dtype(precision),
            )
        except Exception as e:
            raise InvalidLanguageModelException(
                f"{self.model_dir} is not a valid local folder or model identifier on HuggingFace."
            ) from e

        self.model.eval()

        # Make sure we start inference with the <boe> and <s> tokens
        # First tokens in BLT: '<boe>', '<s>', '</s>', '<pad>'
        # Currently there doesn't seem to be a better way to do this
        self.left_context_tokens = [self.tokenizer.bos_token_id]
        if "/blt-" in self.model_name:
            self.left_context_tokens = [0, 1]

        self.change_symbol_set(symbol_set)

    def change_symbol_set(
        self,
        symbol_set: List[str],
    ) -> None:
        """
        Change the active symbol set of the model
        Build a vocabulary table mapping token index to word strings
        :param symbol_set: List of symbol strings
        """
        self.symbol_set = symbol_set
        self.index_to_word = {}
        self.index_to_word_lower = {}
        self.result_to_vocab_indexes = []
        self.symbol_set_lower = None
        self.symbol_index_to_vocab_index = []
        self.symbol_set_lower = []

        for ch in self.symbol_set:
            self.symbol_set_lower.append(ch.lower())

        # List of empty lists
        self.result_to_vocab_indexes = [[] for _ in range(len(self.symbol_set_lower))]

        for i in range(self.vocab_size):
            word = self.tokenizer.decode([i])
            word_lower = word.lower()
            self.index_to_word[i] = word
            self.index_to_word_lower[i] = word_lower

            # Create a mapping between the vocab index and the index in the result set
            try:
                self.result_to_vocab_indexes[self.symbol_set_lower.index(word_lower)].append(i)
            except ValueError:
                pass

        # Make an array that can convert the index of a symbol into the token ID
        for ch in self.symbol_set:
            self.symbol_index_to_vocab_index.append(self.tokenizer.encode(ch)[0])

    def _get_symbol_log_probs(self, log_probs: np.ndarray) -> List[float]:
        """
        Create a simple list with the log probs of all the characters we need to return
        :param log_probs: List of log probs from all the tokens in the LM
        :return: List of log probs of just the character in our vocab, marginalized over upper and lowercase
        """
        result_log_probs = []
        for i in range(len(self.symbol_set_lower)):
            # List of 1 or more indexes in the LLM vocab we need to sum
            indexes = self.result_to_vocab_indexes[i]
            if len(indexes) == 1:
                result_log_probs.append(float(log_probs[indexes[0]]))
            elif len(indexes) > 1:
                # Create a list of the log probs for this character
                char_log_probs = []
                for index in indexes:
                    char_log_probs.append(log_probs[index])
                result_log_probs.append(logsumexp(char_log_probs))
            else:
                # This should only happen if the language model doesn't have all our characters
                result_log_probs.append(float("-inf"))
        return result_log_probs

    # TODO: this doesn't currently use the input_sequence
    def predict_words(
        self,
        left_context: str = "",
        input_sequence: List[List[Tuple[str, float]]] = None,
        config: DecodeConfigByte = DecodeConfigByte(),
        word_end_symbols: List[str] = None,
        nbest: int = None,
        predict_lower: bool = True,
        include_ending_symbol: bool = False,
        return_log_probs=False,
    ) -> List:
        # Since List is a mutable type, we can't set a default reliably in the method declaration
        # We'll set the default of a trailing space if caller didn't specify a list of right contexts
        if word_end_symbols is None:
            word_end_symbols = [" "]

        # Create a symbol set that also includes any end of word symbols that aren't in our normal symbol set
        # If any of the end symbols occur in the normal symbol set, we include at end of list

        # Currently we only support conversion of the multi-byte sequence for curly apostrophe to normal apostrophe
        # But only do this if normal apostrophe is in the symbol set
        if "'" in self.symbol_set:
            # For Meta's BLT model: ('�', 230), ('�', 132), ('�', 157),
            apostrophe_symbol_ids = self.tokenizer.encode("’", add_special_tokens=False)
            search_symbols = [""] * len(apostrophe_symbol_ids)
        else:
            apostrophe_symbol_ids = None
            search_symbols = []

        for symbol in self.symbol_set:
            if symbol not in word_end_symbols:
                # We'll add both an upper and lowercase version of this symbol
                # since we want the search to consider any casing
                if symbol.lower() != symbol.upper():
                    search_symbols.append(symbol.lower())
                    search_symbols.append(symbol.upper())
                else:
                    search_symbols.append(symbol)
        index_first_end_symbol = len(search_symbols)
        for end_symbol in word_end_symbols:
            search_symbols.append(end_symbol)

        # Create a parallel list of the token IDs for our search symbols
        # Start with the curly apostrophe sequence if we are converting that

        # If we added the curly apostrophe token IDs, we need to skip over them
        offset = 0
        if apostrophe_symbol_ids:
            search_symbol_ids = apostrophe_symbol_ids.copy()
            offset = len(search_symbol_ids)
        else:
            search_symbol_ids = []
        # After that the IDs of all the normal symbols
        for symbol in search_symbols[offset:]:
            search_symbol_ids.extend(self.tokenizer.encode(symbol, add_special_tokens=False))

        assert len(search_symbol_ids) == len(search_symbols)

        tokens = list(self.left_context_tokens)
        if left_context:
            tokens += self.tokenizer.encode(left_context, add_special_tokens=False)

        # We store hypotheses in a list with a tuple (log_prob, current word characters, subword token sequence)
        current_hypos = [(0.0, "", tokens)]

        LOGP: Final[int] = 0
        STR: Final[int] = 1
        TOKENS: Final[int] = 2

        # Finished hypotheses map a word string (without ending symbols) to its log prob
        # We use a dictionary since we may want to merge hypotheses that are the same word
        finished_hypos = {}
        best_finished_log_prob = float("-inf")

        # Compute the maximum length of hypotheses based on existing prefix of word (if any)
        max_hypo_len = compute_max_hypo_len(
            left_context=left_context, max_word_len=config.max_word_len
        )

        # Flag that breaks out of all loops
        done = False

        while len(current_hypos) > 0 and not done:
            # We'll store extended hypotheses in a min heap to make it easy to maintain only a fixed number of the best
            next_hypos = []

            # Go through all the current hypotheses loading into one or more mini-batches
            hypo_index = 0
            while hypo_index < len(current_hypos) and not done:
                size = 0
                max_length = 0
                batch_tokens = []

                # Remember the starting index for this minibatch
                batch_start_index = hypo_index

                # Add to the next mini-batch until we either run out of hypotheses or we hit mini-batch size
                # Keep track of the maximum length hypothesis as we go through them
                while (not config.batch_size or size < config.batch_size) and hypo_index < len(
                    current_hypos
                ):
                    tokens = current_hypos[hypo_index][TOKENS]
                    max_length = max(len(tokens), max_length)
                    batch_tokens.append(tokens)
                    size += 1
                    hypo_index += 1

                # Construct the tensor for inference
                batch_tensors = []
                for tokens in batch_tokens:
                    batch_tensors.append(torch.tensor(tokens))
                tokens_tensor = torch.stack(tuple(batch_tensors)).to(self.device)

                with torch.inference_mode():
                    logits = self.model(tokens_tensor).logits  # shape (batch_size, max_length, 384)
                    # We care about the logits in the last position of second dimension
                    # We want to sum to one in the last dimension over the first dimensions (different hypotheses)
                    log_probs = torch.log_softmax(logits[:, -1, :], dim=1).detach().cpu().numpy()

                # For each hypothesis in the mini-batch, create a new next hypothesis for every character
                # in the symbol set that isn't one of our end of word symbols.
                # For end of word symbols, add the hypothesis to the finished_hypos dictionary.
                batch_index = 0
                while batch_index < len(log_probs) and not done:
                    for search_index, token_index in enumerate(search_symbol_ids):
                        # Grab the corresponding hypothesis from the original set
                        hypo = current_hypos[batch_start_index + batch_index]

                        # Pull the log prob for the corresponding position in the inference and add to existing accumulated log prob
                        # Use float cast to avoid 16-bit floating point when on GPU with --fp16 switch
                        new_log_prob = float(log_probs[batch_index, token_index]) + hypo[LOGP]

                        # We avoid adding finished or intermediate hypotheses if they are outside log prob beam
                        # This is a bit faster than only doing it for intermediate hypotheses
                        if (best_finished_log_prob - new_log_prob) < config.beam_best:
                            # See if we have finished by generating any of the valid right symbols
                            # These were organized to be at the end of the list of search_symbols
                            if (
                                search_index >= index_first_end_symbol
                                and len(hypo[STR]) <= max_hypo_len
                            ):
                                # Optionally we marginalize all cases to predict just lowercase words
                                word = hypo[STR].lower() if predict_lower else hypo[STR]
                                # Optionally separate hypotheses by the symbol that ended a word
                                # This might be useful for clients that want to predict "word," versus "word."
                                if include_ending_symbol:
                                    word += search_symbols[search_index]

                                if word in finished_hypos:
                                    # If already had this word finish with a different end symbol we sum the probabilities
                                    finished_hypos[word] = np.logaddexp(
                                        finished_hypos[word], new_log_prob
                                    )
                                else:
                                    # Haven't seen this word, we will just always add it to the dictionary
                                    # It would be expensive to maintain a fixed dictionary size of the best finished hypotheses
                                    finished_hypos[word] = new_log_prob

                                    # Stop the search if we hit a hard cap on distinct completed word hypotheses
                                    if (
                                        config.max_word_hypotheses
                                        and len(finished_hypos) >= config.max_word_hypotheses
                                    ):
                                        done = True
                                        break
                                # Update the current best log prob of any finishing hypothesis
                                best_finished_log_prob = max(best_finished_log_prob, new_log_prob)
                            # This hypothesis didn't finish
                            # It can't be an end symbol
                            # Keep if it is still within beam width of our best hypothesis thus far
                            elif (
                                search_index < index_first_end_symbol
                                and len(hypo[STR]) < max_hypo_len
                            ):
                                # This hypothesis is within the beam of the best to date
                                # Extend by the text and token ID
                                new_tokens = hypo[TOKENS] + [token_index]
                                # Check if we just extended by a complete curly apostrophe sequence
                                if (
                                    apostrophe_symbol_ids
                                    and len(new_tokens) >= len(apostrophe_symbol_ids)
                                    and new_tokens[-len(apostrophe_symbol_ids) :]
                                    == apostrophe_symbol_ids
                                ):
                                    new_hypo = (
                                        new_log_prob,
                                        hypo[STR] + "'",
                                        new_tokens,
                                    )
                                else:
                                    new_hypo = (
                                        new_log_prob,
                                        hypo[STR] + search_symbols[search_index],
                                        new_tokens,
                                    )
                                if len(next_hypos) < config.beam_search_max:
                                    # Add if we haven't reached our beam width limit so add
                                    heappush(next_hypos, new_hypo)
                                else:
                                    # Or replace the worst hypotheses with the new one
                                    heappushpop(next_hypos, new_hypo)
                    batch_index += 1

            current_hypos = next_hypos

        # Convert our dictionary of finished hypotheses to a sorted list
        sorted_best = sorted(finished_hypos.items(), key=lambda item: item[1], reverse=True)[:nbest]

        # Optional inclusion of log prob in result
        return [(hypo[0], float(hypo[1])) if return_log_probs else hypo[0] for hypo in sorted_best]

    def predict(self, evidence: List[str], **kwargs) -> List[Tuple[str, float]]:
        context = "".join(evidence)
        # Optional subclass parameters:
        # :param unnormalized_logprobs:  whether to skip symbol normalization and return log probs (base 10), unique parameter to this class
        unnormalized_logprobs = kwargs.get("unnormalized_logprobs", False)

        # TODO: add support for prediction of mixed case

        tokens = []
        tokens.extend(self.left_context_tokens)
        # Don't extend if the context is empty, this avoids some models like byt5 from adding extra </s> at start
        if len(context) > 0:
            tokens.extend(self.tokenizer.encode(context, add_special_tokens=False))

        tensor = torch.tensor([tokens]).to(self.device)
        with torch.inference_mode():
            logits = self.model(tensor).logits  # Shape is (1, 1, 384)
            log_probs = torch.log_softmax(logits[-1, -1, :], dim=0).detach().cpu().numpy()

        # Create a simple list with the probabilities of all the characters we need to return
        # Normalize to a distribution that sums to 1
        # Numerically stable log-sum-exp normalization (base e)
        char_log_probs = np.asarray(
            self._get_symbol_log_probs(log_probs=log_probs), dtype=np.float64
        )

        # Normalize unless raw log-probs requested
        if unnormalized_logprobs:
            char_probs = char_log_probs
        else:
            char_probs = np.exp(char_log_probs - logsumexp(char_log_probs))

        # Pair symbols with probabilities and return sorted
        return sorted(
            zip(self.symbol_set_lower, char_probs.astype(float)),
            key=lambda x: x[1],
            reverse=True,
        )

    def get_all_tokens_text(self):
        """
        Return an array with the text of all subword tokens.
        The array is in order by the integer index into the vocabulary.
        This is mostly just for exploring the tokens in different LLMs.
        :return: Array of subword token text strings.
        """
        result = []
        for i in range(self.vocab_size):
            result.append(self.tokenizer.decode([i]))
        return result

    def get_tokenization(self, text: str) -> List[Tuple]:
        """
        Given a text string, return a list of (token text, token ID) tuples.
        """
        result = []
        token_ids = self.tokenizer.encode(text, add_special_tokens=False)
        for i in range(len(token_ids)):
            result.append((self.index_to_word[token_ids[i]], token_ids[i]))
        return result

    def get_num_parameters(self) -> int:
        return sum(p.numel() for p in self.model.parameters())

    def score_item(self, item: str) -> float:
        return self.score_items([item])[0]

    def score_items(self, items: List[str], **kwargs) -> List[float]:
        """
        :param items: a list of text strings
        """
        # Optional parameter, limit inference to give batch size, if not set tries to do as one big batch
        batch_size = kwargs.get("batch_size", len(items))

        if len(items) == 0:
            return []

        batch_size = batch_size or len(items)
        all_log_probs = []

        # Process items in batch_size chunks
        for start in range(0, len(items), batch_size):
            batch_items = items[start : start + batch_size]

            # We need to make sure the token sequences start with [0, 1] for models like Meta's BLT
            enc = self.tokenizer(
                batch_items,
                return_tensors=None,
                padding=False,
                add_special_tokens=False,
            )
            input_ids_list = []
            for tokens in enc["input_ids"]:
                input_ids_list.append(self.left_context_tokens + tokens)
            input_ids = pad_sequence(
                [torch.tensor(seq, dtype=torch.long) for seq in input_ids_list],
                batch_first=True,
                padding_value=self.tokenizer.pad_token_id or 0,
            ).to(self.device)
            attention_mask = (input_ids != (self.tokenizer.pad_token_id or 0)).long()

            with torch.inference_mode():
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
                logits = outputs.logits

                # Shift logits/labels so each token predicts the next one
                shift_logits = logits[:, :-1, :]
                shift_labels = input_ids[:, 1:]
                shift_mask = attention_mask[:, 1:]

                log_probs = F.log_softmax(shift_logits, dim=-1)
                token_log_probs = log_probs.gather(2, shift_labels.unsqueeze(-1)).squeeze(-1)

                # Mask out padding tokens
                token_log_probs = token_log_probs * shift_mask

                # Sum over tokens to get sentence log probability
                batch_log_probs = token_log_probs.sum(dim=1)

            all_log_probs.extend(batch_log_probs.cpu().tolist())

        return all_log_probs
