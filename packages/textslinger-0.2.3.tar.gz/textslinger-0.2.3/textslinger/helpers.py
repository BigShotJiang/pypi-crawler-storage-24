"""
Helper functions and classes
"""

from enum import Enum
import torch


class Device(str, Enum):
    CPU = "cpu"
    CUDA = "cuda"
    MPS = "mps"
    AUTO = "auto"

    @property
    def str(self) -> str:
        return self.value


class Precision(str, Enum):
    FP32 = "fp32"
    FP16 = "fp16"
    BF16 = "bf16"


PRECISION_TO_TORCH = {
    Precision.FP32: torch.float32,
    Precision.FP16: torch.float16,
    Precision.BF16: torch.bfloat16,
}


def convert_device(device: Device) -> str:
    """
    Handles mapping auto device to the best backend
    :param device: Device enum
    :return: torch.device for the resolved backend
    """
    if device == Device.AUTO:
        if torch.cuda.is_available():
            resolved = Device.CUDA
        elif torch.backends.mps.is_available():
            resolved = Device.MPS
        else:
            resolved = Device.CPU
    else:
        resolved = device
    return resolved.str


def precision_to_dtype(precision: Precision) -> torch.dtype:
    """
    Convert the precision enum into the type we need to create automodel
    """
    try:
        return PRECISION_TO_TORCH[precision]
    except KeyError:
        raise ValueError(f"Unsupported precision: {precision}")


def compute_max_hypo_len(left_context: str, max_word_len: int) -> int:
    """Compute the maximum letters we may still generate for the current word."""
    prefix_letters = 0
    if left_context:
        pos = len(left_context) - 1
        while pos >= 0 and left_context[pos] != " ":
            if left_context[pos].isalpha():
                prefix_letters += 1
            pos -= 1
    return max(0, max_word_len - prefix_letters)
