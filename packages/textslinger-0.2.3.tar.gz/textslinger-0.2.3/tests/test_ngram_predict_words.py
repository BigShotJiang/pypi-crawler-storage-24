# Tests specific to the decode method in the n-gram language model class

from textslinger.ngram import (
    DecodeConfigNGram,
)
import pytest
from tests.test_constants import *
from tests.helpers import check_match, check_len_limit
from tests.test_ngram import shared_lm, shared_lm_full
import copy


@pytest.fixture(scope="module")
def input_uniform_a_to_z():
    """
    Obtain a list of input event tuples that is uniform over A-Z
    """
    result = []
    for letter in STR_LOWERCASE_LETTERS:
        result.append((letter, 0.0))

    yield result


@pytest.fixture(scope="module")
def input_uniform_a_to_f():
    """
    Obtain a list of input event tuples that is uniform over A-F
    """
    result = []
    for letter in "abcdef":
        result.append((letter, 0.0))
    yield result


@pytest.fixture(scope="module")
def config_default():
    """
    A default set for our tests since we don't want to rely on the defaults in the class
    since they might get changed
    """
    config = DecodeConfigNGram()
    config.max_word_hypotheses = 100
    config.beam_best = 30.0
    config.beam_search_max = 100
    config.max_word_len = 25
    config.lm_scale = 1.0
    config.ins_penalty = -20.0
    config.ins_after_input_penalty = 0.0
    config.del_penalty = -20.0
    yield config


@pytest.fixture(scope="module")
def config_no_ins_del(config_default):
    """
    A config for the decode method that doesn't allow insertions or deletions
    """
    config = copy.deepcopy(config_default)
    config.ins_penalty = None
    config.del_penalty = None
    config.ins_after_input_penalty = 0.0
    yield config


@pytest.fixture(scope="module")
def config_small_ins(config_default):
    """
    A config for the decode method that doesn't allow insertions or deletions
    """
    config = copy.deepcopy(config_default)
    config.ins_penalty = -1.0
    yield config


@pytest.fixture(scope="module")
def config_small_del(config_default):
    """
    A config with a small deletion penalty
    """
    config = copy.deepcopy(config_default)
    config.del_penalty = -1.0
    yield config


@pytest.fixture(scope="module")
def config_wide(config_default):
    """
    A config with a wide beam
    """
    config = copy.deepcopy(config_default)
    config.beam_search_max = 1000
    config.beam_best = 100.0
    config.max_word_hypotheses = None
    yield config


@pytest.fixture(scope="module")
def config_wide_no_del(config_default):
    """
    A config with a wide beam but no deletions allowed
    """
    config = copy.deepcopy(config_default)
    config.del_penalty = None
    config.beam_search_max = 1000
    config.beam_best = 100.0
    config.max_word_hypotheses = None
    yield config


@pytest.fixture(scope="module")
def config_wide_no_ins_del(config_default):
    """
    A config that doesn't allow insertions or deletions
    """
    config = copy.deepcopy(config_default)
    config.del_penalty = None
    config.ins_penalty = None
    config.beam_search_max = 1000
    config.beam_best = 100.0
    config.max_word_hypotheses = None
    yield config


@pytest.fixture(scope="module")
def config_no_autocomplete(config_default):
    """
    A config that doesn't allow autocompletion after the input
    """
    config = copy.deepcopy(config_default)
    config.ins_penalty = None
    config.del_penalty = None
    config.ins_penalty_after_input = None
    yield config


@pytest.fixture(scope="module")
def config_old(config_default):
    """
    Config simulating how the original predict_words function worked
    """
    config = copy.deepcopy(config_default)
    config.ins_penalty = None
    config.del_penalty = None
    config.ins_after_input_penalty = 0.0
    config.lm_scale = 1 / np.log(10)  # Adjust for change to searching in log base e
    config.max_word_hypotheses = 256
    config.beam_best = 5.0
    config.beam_search_max = 100
    config.max_word_len = 25
    yield config


@pytest.fixture(scope="module")
def config_old_max_len4(config_old):
    """
    Config simulating how the original predict_words function worked
    This version request words that are 4 letters or shorter (including any prefix)
    """
    config = copy.deepcopy(config_old)
    config.max_word_len = 4
    yield config


def test_basic_match(shared_lm, config_default):
    """
    Test decoding with a perfect noiseless input sequence
    Should behave similarly to predict_words but guided by events
    """
    references = ["the", "they", "then"]
    input_sequence = [[("t", 0.0)], [("h", 0.0)], [("e", 0.0)]]
    predictions = shared_lm.predict_words(
        left_context="",
        input_sequence=input_sequence,
        config=config_default,
        nbest=3,
    )
    check_match(predictions, references)


def test_basic_match_with_log_probs(shared_lm, config_default):
    """
    Test decoding with a perfect noiseless input sequence
    Should behave similarly to predict_words but guided by events
    """
    references = [
        ("the", -3.477916710200815),
        ("they", -4.6299651686218635),
        ("then", -5.505788537487132),
    ]
    input_sequence = [[("t", 0.0)], [("h", 0.0)], [("e", 0.0)]]
    predictions = shared_lm.predict_words(
        left_context="",
        input_sequence=input_sequence,
        config=config_default,
        nbest=3,
        return_log_probs=True,
    )
    check_match(predictions, references)


def test_substitution(shared_lm, config_default):
    """
    Test the LM's ability to correct a bad character in the input (substitution)
    """
    references = [
        ("there", -9.029981972603796),
        ("thar", -12.742332343659609),
        ("thers", -13.588288007343559),
    ]
    input_sequence = [
        [("t", 0.0)],
        [("h", 0.0)],
        [("a", 0.0), ("e", -2.0)],
        [("r", 0.0)],
    ]
    predictions = shared_lm.predict_words(
        left_context="in ",
        input_sequence=input_sequence,
        config=config_default,
        nbest=3,
        return_log_probs=True,
    )
    check_match(predictions, references)


def test_uniform_a_to_z(shared_lm, input_uniform_a_to_z, config_no_ins_del):
    """
    Based on suggestive context find the right word in a uniform set of 6 input events
    """

    input_sequence = [input_uniform_a_to_z] * 6
    predictions = shared_lm.predict_words(
        left_context="i live in the united ",
        input_sequence=input_sequence,
        config=config_no_ins_del,
    )
    # Best choice should be "states"
    assert predictions[0] == "states"
    # Everything else should be exactly the length of the input sequence
    for prediction in predictions:
        assert len(prediction) == len(input_sequence)


def test_uniform_a_to_z_max_hypos(shared_lm, input_uniform_a_to_z, config_no_ins_del):
    """
    Based on suggestive context find the right word in a uniform set of 6 input events
    """
    config = copy.deepcopy(config_no_ins_del)
    config.max_word_hypotheses = 10
    input_sequence = [input_uniform_a_to_z] * 6
    predictions = shared_lm.predict_words(
        left_context="i live in the united ",
        input_sequence=input_sequence,
        config=config,
    )
    assert len(predictions) == config.max_word_hypotheses
    # This caused the search to end early before we found "states"
    assert predictions[0] == "stored"
    # Everything else should be exactly the length of the input sequence
    for prediction in predictions:
        assert len(prediction) == len(input_sequence)


def test_uniform_a_to_f(shared_lm, input_uniform_a_to_f, config_no_ins_del):
    """
    Find words that only use the letters A-F
    """

    input_sequence = [input_uniform_a_to_f] * 3
    predictions = shared_lm.predict_words(
        left_context="are you d",
        input_sequence=input_sequence,
        config=config_no_ins_del,
    )
    # Everything else should be exactly the length of the input sequence
    assert predictions[0] == "ead"  # "are you dead"
    assert predictions[1] == "eaf"  # "are you deaf"
    for prediction in predictions:
        assert len(prediction) == len(input_sequence)
        for ch in prediction:
            assert ch in "abcdef"


def test_deletion(shared_lm, config_small_del):
    """
    Test handling an extra character in the input (deletion)
    """
    references = ["the"]
    input_events = [[("t", 0.0)], [("h", 0.0)], [("x", 0.0)], [("e", 0.0)]]
    # We set a light deletion penalty to allow the skip
    predictions = shared_lm.predict_words(
        left_context="where is ",
        input_sequence=input_events,
        nbest=1,
        config=config_small_del,
    )
    check_match(predictions, references)


def test_insertion(shared_lm, config_small_ins):
    """
    Test handling a missing character in the input (insertion).
    """
    references = ["the"]
    input_events = [[("t", 0.0)], [("e", 0.0)]]

    # Set a light insertion penalty to allow adding the 'h'
    predictions = shared_lm.predict_words(
        left_context="where is ",
        input_sequence=input_events,
        nbest=1,
        config=config_small_ins,
    )
    check_match(predictions, references)


def test_start_no_input(shared_lm, config_default):
    """
    Test that the search continues to generate characters once input is exhausted.
    This is the "autocompletion" feature.
    """
    references = ["i", "it", "we", "is"]
    predictions = shared_lm.predict_words(left_context="", config=config_default, nbest=4)
    check_match(predictions, references)


def test_word_prefix(shared_lm, config_wide_no_del):
    """
    Test that the search continues to generate characters once input is exhausted.
    This is the "autocompletion" feature.
    """
    references = ["nd", "nding", "nds", "ndable", "ndings"]
    predictions = shared_lm.predict_words(
        left_context="my understa",
        config=config_wide_no_del,
        nbest=5,
    )
    check_match(predictions, references)


def test_word_prefix_ins_after_penalty(shared_lm, config_wide_no_del):
    """
    Use a penalty for after the input autocomplete insertions
    """
    references = ["", "r", "n", "y", "l"]
    config = copy.deepcopy(config_wide_no_del)
    config.ins_penalty_after_input = -20.0
    predictions = shared_lm.predict_words(
        left_context="my understa",
        config=config,
        nbest=5,
    )
    check_match(predictions, references)

    # Increasing should cause all options to be pruned
    config.ins_penalty_after_input = -200.0
    predictions = shared_lm.predict_words(
        left_context="my understa",
        config=config,
        nbest=5,
    )
    assert predictions[0] == ""


def test_no_autocomplete_no_input(shared_lm, config_no_autocomplete):
    """
    Turn off the ability to insert letters at the end of a word
    No input so the only choice is to insertion a word end symbol
    """
    references = [""]
    predictions = shared_lm.predict_words(
        left_context="dogs and cat",
        config=config_no_autocomplete,
    )
    check_match(predictions, references)


def test_no_autocomplete(shared_lm, input_uniform_a_to_z, config_no_autocomplete):
    """
    Turn off the ability to insert letters at the end of a word
    Give all the letters as a possible ending to the current word
    """
    predictions = shared_lm.predict_words(
        left_context="dogs and cat",
        input_sequence=[input_uniform_a_to_z],
        config=config_no_autocomplete,
    )
    assert len(predictions) == 26
    assert predictions[0] == "s"
    for prediction in predictions:
        assert len(prediction) == 1


def test_with_end_symbols_included_no_input(shared_lm, config_default):
    """
    Make word predictions with multiple end symbols but without input events
    """
    references = ["d ", "d.", "d,", "d?", " ", ".", "d!"]
    predictions = shared_lm.predict_words(
        left_context="this is the en",
        word_end_symbols=[" ", "!", "?", ".", ","],
        config=config_default,
        include_ending_symbol=True,
    )
    check_match(predictions, references)


def test_with_end_symbols_included(shared_lm, config_default):
    """
    Make word predictions with multiple end symbols
    Give it a single input event
    """
    references = ["d ", "d.", "d,", "d?", "d!"]
    predictions = shared_lm.predict_words(
        left_context="this is the en",
        word_end_symbols=[" ", "!", "?", ".", ","],
        config=config_default,
        include_ending_symbol=True,
        input_sequence=[[("d", 0.0), ("x", 0.0), ("y", 0.0), ("z", 0.0)]],
    )
    check_match(predictions, references)


def test_end_symbols_in_input(shared_lm_full, config_default):
    """
    Test a user giving word end symbols in the input
    """
    references = ["d ", "d.", "d?", "d!"]
    config = copy.deepcopy(config_default)
    config.max_word_hypotheses = 4
    predictions = shared_lm_full.predict_words(
        left_context="this is the en",
        word_end_symbols=[" ", "!", "?", ".", ","],
        config=config,
        include_ending_symbol=True,
        input_sequence=[
            [("d", 0.0)],
            [(".", 0.0), (" ", 0.0), ("!", 0.0), ("?", 0.0), (",", 0.0)],
        ],
    )
    check_match(predictions, references)


def test_end_symbols_in_input_merge(shared_lm_full, config_default):
    """
    Test a user giving word end symbols in the input
    """
    references = ["d", "", "c"]
    config = copy.deepcopy(config_default)
    config.max_word_hypotheses = 3
    predictions = shared_lm_full.predict_words(
        left_context="this is the en",
        word_end_symbols=[" ", "!", "?", ".", ","],
        config=config,
        input_sequence=[
            [("d", 0.0)],
        ],
    )
    check_match(predictions, references)


def test_midword_context(shared_lm, config_wide_no_ins_del):
    """
    Make word predictions in the middle of a word with strong left context
    We'll check we get the expected default number of predictions
    Also check the first few predictions
    """
    references = ["ican", "ica", "icans"]
    predictions = shared_lm.predict_words(
        left_context="the united states of amer", config=config_wide_no_ins_del
    )
    check_match(
        predictions,
        references,
    )


def test_predict_no_context(shared_lm, config_old):
    """
    Make word predictions without any left context
    """
    references = ["i", "you", "the"]
    predictions = shared_lm.predict_words(config=config_old)
    print(predictions)
    check_match(predictions, references, expected_predictions=config_old.max_word_hypotheses)


def test_no_context_nbest(shared_lm, config_old):
    """
    Make word predictions without any left context
    Test with different nbest parameters
    """
    references = ["i", "you", "the", "what", "it", "but", "and", "this", "we"]
    for i in range(1, 10):
        predictions = shared_lm.predict_words(config=config_old, nbest=i)
        check_match(predictions, references[:i], expected_predictions=i)


def test_start_context(shared_lm, config_old):
    """
    Make word predictions at start of new word with strong left context
    """
    references = ["is", "of", "and"]
    predictions = shared_lm.predict_words(config=config_old, left_context="my name ")
    check_match(predictions, references, expected_predictions=config_old.max_word_hypotheses)


def test_start_context_with_probs(shared_lm, config_old):
    """
    Make word predictions at start of new word with strong left context
    This version tests the optional return of tuples with log probabilities
    Also tests that a shorter context of 11 characters get the same answer
    But a short enough context changes the log probabilities
    """
    references = [
        ("is", -0.23404090013355014),
        ("of", -1.188608528114855),
        ("and", -1.4341645850799976),
    ]
    # Using full sentence context
    predictions = shared_lm.predict_words(
        config=config_old, left_context="good morning my name ", return_log_probs=True
    )
    check_match(predictions, references, expected_predictions=config_old.max_word_hypotheses)

    # Now context is at the limit the model can use
    predictions = shared_lm.predict_words(
        config=config_old, left_context="ng my name ", return_log_probs=True
    )
    check_match(predictions, references, expected_predictions=config_old.max_word_hypotheses)

    # Now shortened context such that it changed just the log probabilities
    references = [
        ("is", -0.1719172364100814),
        ("of", -1.3368232259526849),
        ("and", -1.5823792829178274),
    ]
    predictions = shared_lm.predict_words(
        config=config_old, left_context="my name ", return_log_probs=True
    )
    check_match(predictions, references, expected_predictions=config_old.max_word_hypotheses)


def test_with_end_symbols(shared_lm, config_old):
    """
    Make word predictions with multiple end symbols
    """
    references = ["d", "glish", "tire"]
    predictions = shared_lm.predict_words(
        config=config_old,
        left_context="this is the en",
        word_end_symbols=[" ", "!", "?", "."],
    )
    check_match(predictions, references, expected_predictions=config_old.max_word_hypotheses)


def test_max3(shared_lm, config_old):
    """
    Make word predictions but with a smaller number of max word hypotheses
    """
    references = ["", "j", "q"]
    config = copy.deepcopy(config_old)
    config.max_word_hypotheses = 3
    predictions = shared_lm.predict_words(
        config=config,
        left_context="this is a t",
    )
    check_match(predictions, references, expected_predictions=config.max_word_hypotheses)


def test_max965(shared_lm, config_old):
    """
    Make word predictions but with a larger number of max word hypotheses
    But not so large that we don't reach this number due to other pruning
    """
    references = ["ime", "errible", "ough"]
    config = copy.deepcopy(config_old)
    config.max_word_hypotheses = 965
    predictions = shared_lm.predict_words(
        config=config,
        left_context="this is a t",
    )
    check_match(predictions, references, expected_predictions=config.max_word_hypotheses)


def test_max1000(shared_lm, config_old):
    """
    Make word predictions but with a larger number of max word hypotheses
    At this point we don't reach the target due to other pruning
    """
    references = ["ime", "errible", "ough"]
    config = copy.deepcopy(config_old)
    config.max_word_hypotheses = 1000
    predictions = shared_lm.predict_words(config=config, left_context="this is a t")
    check_match(predictions, references, expected_predictions=965)


def test_max1000_best6(shared_lm, config_old):
    """
    Make word predictions but with a larger number of max word hypotheses
    Increased beam width so we now find 1000 predictions
    """
    references = ["ime", "errible", "ough"]
    config = copy.deepcopy(config_old)
    config.max_word_hypotheses = 1000
    config.beam_best = 6.0
    predictions = shared_lm.predict_words(
        config=config,
        left_context="this is a t",
    )
    check_match(predictions, references, expected_predictions=config.max_word_hypotheses)


def test_max1000_best6_max10(shared_lm, config_old):
    """
    Make word predictions but with a larger number of max word hypotheses
    Increased beam width but with reduced beam max resulting in finding fewer predictions
    """
    references = ["ime", "errible", "ough"]
    config = copy.deepcopy(config_old)
    config.max_word_hypotheses = 1000
    config.beam_best = 6.0
    config.beam_search_max = 10
    predictions = shared_lm.predict_words(
        config=config,
        left_context="this is a t",
    )
    check_match(predictions, references, expected_predictions=147)


def test_len4_midword(shared_lm, config_old_max_len4):
    """
    Make word predictions but limit word length to 4 letters in total
    This version tests with a partial prefix of one letter
    """
    references = ["ame", "ew", "ext"]
    current_len = 1
    predictions = shared_lm.predict_words(config=config_old_max_len4, left_context="my n")
    check_match(predictions, references, expected_predictions=182)

    # Check all predictions are <= 3 characters (since we already have one letter)
    # Also be sure we find something that makes it to the max word length
    target_len = config_old_max_len4.max_word_len - current_len
    assert check_len_limit(predictions, target_len) == target_len


def test_len4_midword2(shared_lm, config_old_max_len4):
    """
    Make word predictions but limit word length to 4 letters in total
    This version tests with a partial prefix of two letters
    """
    references = ["me", "il", ""]
    current_len = 2
    predictions = shared_lm.predict_words(config=config_old_max_len4, left_context="my na")
    check_match(predictions, references, expected_predictions=106)

    # Check all predictions are <= 2 characters (since we already have two letters)
    # Also be sure we find something that makes it to the max word length
    target_len = config_old_max_len4.max_word_len - current_len
    assert check_len_limit(predictions, target_len) == target_len


def test_len4_start_word(shared_lm, config_old_max_len4):
    """
    Make word predictions but limit word length to 4 letters in total
    This version tests with no prefix of the current word
    """
    references = ["dad", "son", "mom"]
    current_len = 0
    predictions = shared_lm.predict_words(config=config_old_max_len4, left_context="my ")
    check_match(
        predictions,
        references,
        expected_predictions=config_old_max_len4.max_word_hypotheses,
    )

    # Check all predictions are <= the max word length
    # Also be sure we find something that makes it to the max word length
    target_len = config_old_max_len4.max_word_len - current_len
    assert check_len_limit(predictions, target_len) == target_len


def test_noisy_prefix(shared_lm, config_wide):
    references = [
        ("test", -10.208287283667913),
        ("team", -11.134456733320446),
        ("testing", -11.718006013719238),
        ("teacher", -11.977622122946139),
        ("beautiful", -12.740177681371103),
    ]
    predictions = shared_lm.predict_words(
        config=config_wide,
        left_context="this is a ",
        nbest=5,
        return_log_probs=True,
        input_sequence=[
            [("t", -1.0), ("a", -2.0), ("b", -3.0), ("c", -4.0)],
            [("e", -1.0), ("a", -2.0), ("b", -3.0), ("c", -4.0)],
            [("s", -1.0), ("a", -2.0), ("b", -3.0), ("c", -4.0)],
        ],
    )
    check_match(
        predictions,
        references,
    )
