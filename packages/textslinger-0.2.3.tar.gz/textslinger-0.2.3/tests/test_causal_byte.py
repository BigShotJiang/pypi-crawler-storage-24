from textslinger.causal_byte import (
    CausalByteLanguageModel,
    InvalidLanguageModelException,
    DecodeConfigByte,
)
import pytest
from tests.helpers import (
    check_match,
    check_sum_to_one,
    suppress_stderr_fd,
    read_float_list,
)
from tests.test_constants import *
from textslinger.eval_helper import (
    load_phrases_plaintext,
    filter_phrases,
    normalize_phrases,
)
import copy

# NOTE: if the device is changed to MPS, many tests fail because the probabilities and/or hypotheses change
# Currently set high enough to pass on various CPUs and GPUs
EPSILON_BYTE_PREDICT = 0.04

# Higher epsilon for scoring items and comparing total log prob
EPSILON_BYTE_LOG_PROB = 0.2


@pytest.fixture(scope="module")
def shared_lm(device, precision):
    """
    Load a shared byte LLM that is used by all tests
    Since some tests need different symbol sets, each test should call change_symbol_set at start of test
    This reduces the amount of memory required to run this module
    """
    with suppress_stderr_fd():
        lm = CausalByteLanguageModel(
            symbol_set=SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS,
            lang_model_name=BYTE_LLM,
            device=device,
            precision=precision,
        )
    yield lm


@pytest.fixture(scope="module")
def config_default():
    """
    A default set for our tests since we don't want to rely on the defaults in the class
    since they might get changed
    """
    config = DecodeConfigByte()
    config.max_word_hypotheses = 256
    config.beam_best = 8.0
    config.beam_search_max = 300
    config.max_word_len = 25
    config.lm_scale = 1.0
    config.ins_penalty = -20.0
    config.ins_after_input_penalty = 0.0
    config.del_penalty = -20.0
    config.batch_size = None
    yield config


@pytest.fixture(scope="module")
def config_narrow(config_default):
    """
    Narrow beam for fast decoding
    """
    config = copy.deepcopy(config_default)
    config.beam_best = 5.0
    config.beam_search_max = 4
    yield config


@pytest.fixture(scope="module")
def config_narrower(config_default):
    """
    Narrow beam for fast decoding
    """
    config = copy.deepcopy(config_default)
    config.beam_best = 1.3
    config.beam_search_max = 4
    yield config


@pytest.fixture(scope="module")
def config_narrowest(config_default):
    """
    Narrow beam for fast decoding
    """
    config = copy.deepcopy(config_default)
    config.beam_best = 0.5
    config.beam_search_max = 4
    yield config


def test_bogus_model_name():
    """
    Attempt to load with a bogus model name
    """
    with pytest.raises(InvalidLanguageModelException):
        CausalByteLanguageModel(
            symbol_set=SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS,
            lang_model_name="user/bogus",
        )


def test_bogus_lm_path():
    """
    Attempt to load with a valid model name but a bogus local directory
    """
    with pytest.raises(InvalidLanguageModelException):
        CausalByteLanguageModel(
            symbol_set=SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS,
            lang_model_name=BYTE_LLM,
            lm_path="bogus_model_dir",
        )


def test_lowercase_symbol_set(shared_lm):
    """
    Checks the lowercase symbol set makes sense
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)

    # First of all size should be correct
    assert len(shared_lm.symbol_set) == len(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    assert len(shared_lm.symbol_set_lower) == len(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)

    # Check all symbols are in both the normal and lowercase symbol sets
    for symbol in SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS:
        assert symbol in shared_lm.symbol_set
        assert symbol in shared_lm.symbol_set_lower


def test_class_name(shared_lm):
    """
    Check our name using the base class method
    """
    assert shared_lm.name() == "CAUSALBYTE"


def test_num_parameters(shared_lm):
    """
    Check method that returns number of model parameters
    """
    assert shared_lm.get_num_parameters() == BYTE_LLM_PARAMS


def test_get_all_tokens_text(shared_lm):
    """
    Check method that returns all tokens
    """
    assert len(shared_lm.get_all_tokens_text()) == BYTE_LLM_TOKENS


def test_get_tokenization_us_keyboard(shared_lm):
    """
    Tokenize characters you can type on a US keyboard to token tuples
    """
    test_str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 `~!@#$%^&*()_+-=[]\\;',./{}|:\"<>?"
    pairs = shared_lm.get_tokenization(test_str)
    assert len(pairs) == len(test_str)
    for i, pair in enumerate(pairs):
        assert pair[0] == test_str[i]
        assert 0 <= pair[1] < BYTE_LLM_TOKENS


def test_get_tokenization_two_byte_chars(shared_lm):
    """
    Tokenize characters that take two bytes under Meta's BLT model
    """
    test_str = "éñüöçøß"
    pairs = shared_lm.get_tokenization(test_str)
    assert len(pairs) == 2 * len(test_str)
    for pair in pairs:
        assert 0 <= pair[1] < BYTE_LLM_TOKENS


def test_get_tokenization_three_byte_chars(shared_lm):
    """
    Tokenize characters that take three bytes under Meta's BLT model
    """
    test_str = "’—你あ한€✓"
    pairs = shared_lm.get_tokenization(test_str)
    assert len(pairs) == 3 * len(test_str)
    for pair in pairs:
        assert 0 <= pair[1] < BYTE_LLM_TOKENS


def test_get_tokenization_emoji(shared_lm):
    """
    Tokenize characters that take three bytes under Meta's BLT model
    """
    # This family emoji is a combination of 7 codepoints
    test_str = "👨‍👩‍👧‍👦"
    pairs = shared_lm.get_tokenization(test_str)
    assert len(test_str) == 7
    assert len(pairs) == 25
    for pair in pairs:
        assert 0 <= pair[1] < BYTE_LLM_TOKENS


def test_predict_no_context(shared_lm):
    """
    Predict the next symbol based on having no left context
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [
        ("t", 0.22908457338479865),
        ("w", 0.12630019743464407),
        ("s", 0.09301586581373826),
    ]
    predictions = shared_lm.predict(evidence=[])
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm.symbol_set),
        epsilon=EPSILON_BYTE_PREDICT,
    )
    check_sum_to_one(predictions)


def test_predict_space_context(shared_lm):
    """
    Predict the next symbol based on having a single space as left context
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [
        (" ", 0.6994546110031655),
        ("i", 0.03821663370884904),
        ("t", 0.023027119362824356),
    ]
    predictions = shared_lm.predict(evidence=[" "])
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm.symbol_set),
        epsilon=EPSILON_BYTE_PREDICT,
    )
    check_sum_to_one(predictions)


def test_predict_short_context_prefix1(shared_lm):
    """
    Predict the next symbol based on having some left context
    Uses a single letter of prefix for the current word
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [
        ("a", 0.4810834386710976),
        ("e", 0.3010587913538831),
        ("u", 0.10734580508602524),
    ]
    predictions = shared_lm.predict(evidence=list("my n"))
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm.symbol_set),
        epsilon=EPSILON_BYTE_PREDICT,
    )
    check_sum_to_one(predictions)


def test_predict_long_context_prefix8(shared_lm):
    """
    Predict the next symbol based on having a lot of left context
    Uses a long prefix for the current word
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [
        ("t", 0.9992753208580899),
        ("c", 0.0006667494053309576),
        (" ", 1.5196042746019054e-05),
    ]
    predictions = shared_lm.predict(evidence=list("This finding is not importan"))
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm.symbol_set),
        epsilon=EPSILON_BYTE_PREDICT,
    )
    check_sum_to_one(predictions)


def test_predict_contraction_with_apostrophe(shared_lm):
    """
    Predict the last part of a word that is probably a contraction
    This version uses a model that does have apostrophe in the symbol set
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [
        ("'", 0.9072960039319478),
        ("e", 0.04517297057165003),
        ("t", 0.021341899263380027),
    ]
    predictions = shared_lm.predict(evidence=list("If you fall don"))
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm.symbol_set),
        epsilon=EPSILON_BYTE_PREDICT,
    )
    check_sum_to_one(predictions)


def test_predict_contraction_no_apostrophe(shared_lm):
    """
    Predict the last part of a word that is probably a contraction
    This version uses a model that does not have an apostrophe in the symbol set
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE)
    references = [
        ("e", 0.4897241322480899),
        ("t", 0.23136939999788825),
        ("a", 0.18019427864074547),
    ]
    predictions = shared_lm.predict(evidence=list("If you fall don"))
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm.symbol_set),
        epsilon=EPSILON_BYTE_PREDICT,
    )
    check_sum_to_one(predictions)


def test_predict_symbol_endings(shared_lm):
    """
    Predict the next symbol at end of sentence
    This uses a model that has a variety of different punctuation symbols
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [
        (".", 0.494546293121901),
        (" ", 0.1998147888833427),
        ("!", 0.16055569342467985),
        (",", 0.12119379572175441),
        ("?", 0.013811697553420281),
    ]
    predictions = shared_lm.predict(
        evidence=list("It's the end of the world as we know it and I feel fine")
    )
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm.symbol_set),
        epsilon=EPSILON_BYTE_PREDICT,
    )
    check_sum_to_one(predictions)


def test_predict_words_no_context(shared_lm, config_narrowest):
    """
    Make word predictions in the middle of a word that is likely a contraction
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = ["title", "what", "let"]
    predictions = shared_lm.predict_words(
        left_context="",
        config=config_narrowest,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references)


def test_predict_words_full_word(shared_lm, config_narrowest):
    """
    Make word predictions at the end of a word but merge word end symbols
    This causes all the end of word symbol hypotheses to collapse into blank hypothesis
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [""]
    predictions = shared_lm.predict_words(
        left_context="Bye bye",
        config=config_narrowest,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references)


def test_predict_words_full_word_include_ending(shared_lm, config_narrow):
    """
    Make word predictions at the end of a word and request the ending symbol be included in results
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [" ", ",", "!", ".", "?"]
    predictions = shared_lm.predict_words(
        left_context="Bye bye",
        config=config_narrow,
        include_ending_symbol=True,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references)


def test_predict_words_partial_word_with_log_probs(shared_lm, config_narrow):
    """
    Make word predictions at near the end of a word
    This also checks the log probs in the results
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = [("e", -0.11844532689588708), ("", -4.672425501089463)]
    predictions = shared_lm.predict_words(
        left_context="Bye by",
        config=config_narrow,
        return_log_probs=True,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references, epsilon=EPSILON_BYTE_PREDICT)


def test_predict_words_partial_word_include_ending(shared_lm, config_narrow):
    """
    Make word predictions at near the end of a word and request the ending symbol be included in results
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = ["e ", "e,", "e!", "e.", " ", "e?"]
    predictions = shared_lm.predict_words(
        left_context="Bye by",
        config=config_narrow,
        include_ending_symbol=True,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references)


def test_predict_words_contraction(shared_lm, config_narrower):
    """
    Make word predictions in the middle of a word that is likely a contraction
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = ["d", "dn't", "e", "", "n"]
    predictions = shared_lm.predict_words(
        left_context="I do not know why you di",
        config=config_narrower,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references)


def test_predict_words_contraction_no_apostrophe(shared_lm, config_narrower):
    """
    Make word predictions in the middle of a word that is likely a contraction
    This version doesn't have apostrophe in the valid symbols
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE)
    references = ["d", "e", "", "n"]
    predictions = shared_lm.predict_words(
        left_context="I do not know why you di",
        config=config_narrower,
    )
    check_match(predictions, references, expected_predictions=len(references))


def test_predict_words_contraction_prune_max_words(shared_lm, config_narrower):
    """
    Make word predictions in the middle of a word that is likely a contraction
    This version prunes based on the maximum number of word hypotheses
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    config = copy.deepcopy(config_narrower)
    config.max_word_hypotheses = 3
    references = ["e", "", "n"]
    predictions = shared_lm.predict_words(
        left_context="I do not know why you di",
        config=config,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references, expected_predictions=config.max_word_hypotheses)


def test_predict_words_mixed_case(shared_lm, config_narrower):
    """
    Try and predict a word that is in mixed case
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = ["iPhone", "Apple"]
    predictions = shared_lm.predict_words(
        left_context="On Friday Apple released their latest phone the ",
        config=config_narrower,
        predict_lower=False,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references)


def test_predict_words_extra_endings(shared_lm, config_narrowest):
    """
    Predict the very end of a word but with extra word endings enabled
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = ["y", ""]
    predictions = shared_lm.predict_words(
        left_context="How are you feeling toda",
        config=config_narrowest,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references, expected_predictions=len(references))


def test_predict_words_extra_endings_batch(shared_lm, config_narrowest):
    """
    Predict the very end of a word but with extra word endings enabled
    Uses a smaller mini batch size during inference
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    config = copy.deepcopy(config_narrowest)
    config.batch_size = 8
    references = ["y", ""]
    predictions = shared_lm.predict_words(
        left_context="How are you feeling toda",
        config=config,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references, expected_predictions=len(references))


def test_predict_words_curly_apostrophe(shared_lm, config_narrowest):
    """
    Try and predict the ending of a word with curly apostrophe
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    references = ["'t", "t", ""]
    predictions = shared_lm.predict_words(
        left_context="You didn’t do it and I also didn",
        config=config_narrowest,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references, expected_predictions=len(references))


def test_predict_words_english(shared_lm, config_narrowest):
    """
    Prediction to compare with that uses English left context
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    # Without Spanish left context this returns completions for English words
    references = ["d"]
    predictions = shared_lm.predict_words(
        left_context="Good day and I love you very much. Ad",
        config=config_narrowest,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references)


def test_predict_words_spanish(shared_lm, config_narrowest):
    """
    Try and predict a word in Spanish using Spanish left context
    """
    shared_lm.change_symbol_set(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    # We now should get completions for some Spanish words like: Hola and Hoy
    references = ["ios"]
    predictions = shared_lm.predict_words(
        left_context="¡Buen día y te amo mucho! Ad",
        config=config_narrowest,
        word_end_symbols=[" ", ".", ",", "!", "?"],
    )
    check_match(predictions, references)


def test_score_item(shared_lm):
    """
    Test computing the log prob (base e) for a single sentence
    """
    score = shared_lm.score_item(STR_PEOPLE_SHOCKED)
    assert score == pytest.approx(LOG_PROB_BYTE_PEOPLE_SHOCKED, abs=EPSILON_BYTE_LOG_PROB)


def test_score_item_and_extension(shared_lm):
    """
    Score sentence and then again with additional character on end
    Verify that this matches adding prediction of that single character
    """
    add_char = " "
    score = shared_lm.score_item(STR_PEOPLE_SHOCKED)
    score_plus_space = shared_lm.score_item(STR_PEOPLE_SHOCKED + add_char)
    assert score > score_plus_space
    char_to_log_prob = dict(
        shared_lm.predict(evidence=list(STR_PEOPLE_SHOCKED), unnormalized_logprobs=True)
    )
    score_plus_predict = score + char_to_log_prob[add_char]
    assert score_plus_predict == pytest.approx(score_plus_space, abs=EPSILON_BYTE_LOG_PROB)


def test_score_items_identical(shared_lm):
    """
    Test computing the log prob (base e) for multiple identical sentences
    Do inference in one big batch
    """
    num_repeats = 7
    items = [STR_PEOPLE_SHOCKED] * num_repeats
    scores = shared_lm.score_items(items=items, batch_size=None)
    assert len(scores) == num_repeats
    for score in scores:
        assert score == pytest.approx(LOG_PROB_BYTE_PEOPLE_SHOCKED, abs=EPSILON_BYTE_LOG_PROB)


def test_score_items_identical_batch_size1(shared_lm):
    """
    Test computing the log prob (base e) for multiple identical sentences
    Do inference one item at a time
    """
    num_repeats = 7
    items = [STR_PEOPLE_SHOCKED] * num_repeats
    scores = shared_lm.score_items(items=items, batch_size=1)
    assert len(scores) == num_repeats
    for score in scores:
        assert score == pytest.approx(LOG_PROB_BYTE_PEOPLE_SHOCKED, abs=EPSILON_BYTE_LOG_PROB)


def test_score_items_identical_batch_size2(shared_lm):
    """
    Test computing the log prob (base e) for multiple identical sentences
    Do inference one item at a time
    """
    num_repeats = 7
    items = [STR_PEOPLE_SHOCKED] * num_repeats
    scores = shared_lm.score_items(items=items, batch_size=2)
    assert len(scores) == num_repeats
    for score in scores:
        assert score == pytest.approx(LOG_PROB_BYTE_PEOPLE_SHOCKED, abs=EPSILON_BYTE_LOG_PROB)


def test_score_items_alternating(shared_lm):
    """
    Test computing the log prob (base e) for multiple alternating sentences
    """
    # Create a list with alternating sentences with known log probs
    num_repeats = 7
    items = []
    for _ in range(num_repeats):
        items.append(STR_PEOPLE_SHOCKED)
        items.append(STR_LOWERCASE_LETTERS_SPACE)
    scores = shared_lm.score_items(items=items)

    for i in range(len(items)):
        if i % 2 == 0:
            assert scores[i] == pytest.approx(
                LOG_PROB_BYTE_PEOPLE_SHOCKED, abs=EPSILON_BYTE_LOG_PROB
            )
        else:
            assert scores[i] == pytest.approx(
                LOG_PROB_BYTE_LOWERCASE_LETTERS_SPACE, abs=EPSILON_BYTE_LOG_PROB
            )


def test_score_items_empty(shared_lm):
    """
    Test asking for scoring of empty list
    """
    scores = shared_lm.score_items(items=[])
    assert len(scores) == 0


def test_score_items_order(shared_lm):
    """
    Score sentences that have an obvious order of probability
    """
    items = [
        "The United States of America",
        "the united states of america",
        "The United State of America",
        "The United State of Alabama",
        "The United State of Amerika",
        "The United State of_Amerika",
    ]
    scores = shared_lm.score_items(items=items)
    print(scores)
    for i in range(1, len(items)):
        assert scores[i - 1] > scores[i]


@pytest.mark.long
def test_score_items_comm2(shared_lm, rewrite_ref_files):
    """
    Compute the log prob of each sentence in the COMM2 test set
    We filter to sentences without numbers, lowercase, and strip symbols other than apostrophe
    Compare against log probs obtained from a previous run of the model
    """
    phrases = load_phrases_plaintext(filename=COMM2_PHRASES, drop_first_col=True)
    phrases = filter_phrases(phrases=phrases, drop_numbers=True)
    phrases, _ = normalize_phrases(phrases=phrases, lower=True, strip_symbols=True)
    scores = shared_lm.score_items(items=phrases, batch_size=32)
    if rewrite_ref_files:
        print(f"Rewriting log probs to: {COMM2_BYTE_LOG_PROBS}")
        with open(COMM2_BYTE_LOG_PROBS, "w") as f:
            for lp in scores:
                f.write(f"{lp}\n")
    known_log_probs = read_float_list(filename=COMM2_BYTE_LOG_PROBS)
    assert len(scores) == len(known_log_probs)
    for i in range(len(scores)):
        # Note: we need a bit larger epsilon to pass on both CPU and CUDA devices
        assert scores[i] == pytest.approx(known_log_probs[i], abs=2.0)
