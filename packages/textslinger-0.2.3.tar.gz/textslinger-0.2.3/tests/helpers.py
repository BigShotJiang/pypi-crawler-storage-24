"""
Helper functions that different test scripts use.
"""

import pytest
import os
import sys
from contextlib import contextmanager
from textslinger.language_model import LanguageModel
import numpy as np
from typing import List

# Epsilon for testing equality of floating point values
EPSILON = 1e-6


def check_match(predictions, references, expected_predictions=None, epsilon=EPSILON):
    """
    Verify a set of predictions match against known references
    Supports either tuples containing strings and floating point values or just a list of string
    :param predictions: list of predictions
    :param references: list of references
    :param expected_predictions: how many items we expect in the predictions list, None to not check
    :param epsilon: epsilon parameter for the comparison against known floating-point values
    """
    if expected_predictions is not None:
        assert len(predictions) == expected_predictions

    if all(isinstance(x, tuple) for x in predictions):
        # We have a list of tuples (string, float)
        for i, reference in enumerate(references):
            assert predictions[i][0] == reference[0]
            assert predictions[i][1] == pytest.approx(reference[1], abs=epsilon)
    else:
        # We have a list of strings
        for i, reference in enumerate(references):
            assert predictions[i] == reference


def check_len_limit(predictions, max_len):
    """
    Verify a set of predictions have strings no more than max_len
    Supports either tuples containing strings and floating point values or just a list of string
    :param predictions: list of predictions
    :param max_len: maximum length of predictions
    :return: max length of any prediction
    """
    # If we get a list of tuples, convert to just a list of the first element
    if all(isinstance(x, tuple) for x in predictions):
        predictions = [x[0] for x in predictions]

    longest = 0
    for prediction in predictions:
        assert len(prediction) <= max_len
        longest = max(longest, len(prediction))
    return longest


def check_sum_to_one(predictions, epsilon=EPSILON):
    """
    Given a list of (string, float) tuples check that the floats sum to one.
    :param predictions: list of predictions
    :param epsilon: epsilon parameter for the comparison against 1.0
    """
    assert sum(prob for _, prob in predictions) == pytest.approx(1.0, abs=epsilon)


def check_sum_less_than_one(predictions):
    """
    Given a list of (string, float) tuples check that the floats sum to one.
    :param predictions: list of predictions
    """
    assert sum(prob for _, prob in predictions) < 1.0


@contextmanager
def suppress_stderr_fd():
    """
    For use in suppressing stderr output in some of our tests
    """
    fd = sys.stderr.fileno()
    saved_fd = os.dup(fd)
    try:
        with open(os.devnull, "w") as devnull:
            os.dup2(devnull.fileno(), fd)
        yield
    finally:
        os.dup2(saved_fd, fd)
        os.close(saved_fd)


@contextmanager
def suppress_all_console_output():
    old_out = os.dup(1)
    old_err = os.dup(2)
    try:
        # Redirect stdout + stderr
        with open(os.devnull, "w") as dn:
            os.dup2(dn.fileno(), 1)
            os.dup2(dn.fileno(), 2)

        # ALSO redirect /dev/tty if used
        try:
            tty = os.open("/dev/tty", os.O_WRONLY)
            old_tty = os.dup(tty)
            os.dup2(os.open(os.devnull, os.O_WRONLY), tty)
        except OSError:
            old_tty = None

        yield

    finally:
        os.dup2(old_out, 1)
        os.dup2(old_err, 2)
        os.close(old_out)
        os.close(old_err)

        if old_tty is not None:
            os.dup2(old_tty, tty)
            os.close(old_tty)


def check_predict_sum_log_prob(
    expected: float,
    lm: LanguageModel,
    text: str,
    base10: bool = False,
    epsilon=EPSILON,
    unnormalized_logprobs=False,
):
    """
    Compute the sum of the log probability of some text and check against known value
    :param expected: expected log probability
    :param lm: language model to use
    :param text: sequence of characters to predict
    :param base10: whether to use log base10 instead of base e
    :param epsilon: epsilon parameter for the comparison against known value
    :param unnormalized_logprobs: whether to request unnormalized logprobs (only supported by ngram LM)
    :return: sum of log probability
    """
    sum_log_prob = 0.0
    for i in range(len(text)):
        char_probs = dict(
            lm.predict(
                evidence=list(text[:i]), unnormalized_logprobs=unnormalized_logprobs
            )
        )
        if unnormalized_logprobs:
            sum_log_prob += char_probs[text[i]]
        elif base10:
            sum_log_prob += np.log10(char_probs[text[i]])
        else:
            sum_log_prob += np.log(char_probs[text[i]])
    print(f"{sum_log_prob}")
    assert sum_log_prob == pytest.approx(expected, abs=epsilon)


def read_float_list(filename):
    """Reads a file where each line contains exactly one float."""
    result = []
    with open(filename, "r") as f:
        for line in f:
            clean_line = line.strip()
            if clean_line:
                result.append(float(clean_line))
    return result
