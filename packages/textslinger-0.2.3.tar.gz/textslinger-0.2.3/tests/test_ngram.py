from textslinger.ngram import (
    NGramLanguageModel,
    DEFAULT_MAX_WORD_HYPOTHESES,
)
import pytest
from tests.test_constants import *
from tests.helpers import (
    check_match,
    check_len_limit,
    check_sum_to_one,
    check_sum_less_than_one,
    check_predict_sum_log_prob,
    suppress_all_console_output,
    read_float_list,
)
from textslinger.eval_helper import (
    load_phrases_plaintext,
    filter_phrases,
    normalize_phrases,
)

# Some log prob tests are on really improbable sequences and our KenLM results diverge from SRILM's
EPSILON_NGRAM_PREDICT = 1e-1


@pytest.fixture(scope="module")
def shared_lm():
    """
    Runs once so various tests can share a loaded KenLM model
    """
    lm = NGramLanguageModel(symbol_set=SYMBOLS_LOWERCASE_SPACE, lm_path=NGRAM_KENLM)
    yield lm


@pytest.fixture(scope="module")
def shared_lm_full():
    """
    This model uses more punctuation including apostrophe and sentence end symbols like ?.!
    """
    lm = NGramLanguageModel(
        symbol_set=SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS,
        lm_path=NGRAM_KENLM,
    )
    yield lm


@pytest.fixture(scope="module")
def shared_lm_full_start_end():
    """
    This model uses more punctuation and also the start and end words
    """
    symbols_plus_start_end = SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS.copy()
    symbols_plus_start_end.append("<s>")
    symbols_plus_start_end.append("</s>")

    lm = NGramLanguageModel(
        symbol_set=symbols_plus_start_end,
        lm_path=NGRAM_KENLM,
    )
    yield lm


@pytest.fixture(scope="module")
def shared_lm_arpa():
    """
    Runs once so various tests can share a loaded ARPA text format model
    """
    with suppress_all_console_output():
        lm = NGramLanguageModel(symbol_set=SYMBOLS_LOWERCASE_SPACE, lm_path=NGRAM_ARPA)
    yield lm


@pytest.fixture(scope="module")
def comm2_lower_stripped():
    """
    Obtain a list of phrases in lowercase and stripped of symbols
    """
    phrases = load_phrases_plaintext(filename=COMM2_PHRASES, drop_first_col=True)
    phrases = filter_phrases(phrases=phrases, drop_numbers=True)
    phrases, _ = normalize_phrases(phrases=phrases, lower=True, strip_symbols=True)
    yield phrases


def test_construct_bogus_model(capfd):
    """
    Construct using a filename that doesn't exist
    Note: use capfd to supress KenLM C library's standard error output
    """
    lm = NGramLanguageModel(symbol_set=SYMBOLS_LOWERCASE_SPACE, lm_path="bogus.arpa")
    captured = capfd.readouterr()
    assert lm is not None
    assert lm.model is None
    assert captured.out.startswith("ERROR:")


def test_construct_arpa_model_check_instance_vars(shared_lm_arpa):
    """
    Construct using a text format ARPA language model
    """
    assert shared_lm_arpa is not None
    assert shared_lm_arpa.model is not None
    assert shared_lm_arpa.state is not None
    assert shared_lm_arpa.state2 is not None
    assert shared_lm_arpa.space_symbol == "<sp>"


def test_instance_vars(shared_lm):
    """
    Check instance variables are set to default values
    """
    assert shared_lm is not None
    assert shared_lm.model is not None
    assert shared_lm.state is not None
    assert shared_lm.state2 is not None
    assert shared_lm.space_symbol == "<sp>"


def test_default_symbol_set(shared_lm):
    """
    Check converted symbol set is correct
    """

    # First of all size should be correct
    assert len(shared_lm.symbol_set_converted) == len(SYMBOLS_LOWERCASE_SPACE)

    # Space should be converted to special word
    assert "<sp>" in shared_lm.symbol_set_converted
    assert " " not in shared_lm.symbol_set_converted

    # Construct a new model but change default special word
    SPACE_SYMBOL = "<space>"
    lm = NGramLanguageModel(
        symbol_set=SYMBOLS_LOWERCASE_SPACE,
        lm_path=NGRAM_KENLM,
        space_symbol=SPACE_SYMBOL,
    )
    assert SPACE_SYMBOL in lm.symbol_set_converted
    assert " " not in lm.symbol_set_converted


def test_construct_custom_symbol_set():
    """
    Check we can construct with a different symbol set
    """

    # Construct a new model but change default special word
    SPACE_SYMBOL = "<space>"
    lm = NGramLanguageModel(
        symbol_set=SYMBOLS_LOWERCASE_SPACE,
        lm_path=NGRAM_KENLM,
        space_symbol=SPACE_SYMBOL,
    )
    assert SPACE_SYMBOL in lm.symbol_set_converted
    assert " " not in lm.symbol_set_converted


def test_predict_words_midword_context(shared_lm):
    """
    Make word predictions in the middle of a word with strong left context
    We'll check we get the expected default number of predictions
    Also check the first few predictions
    """
    references = ["ican", "ica", "icans"]
    predictions = shared_lm.predict_words_old(left_context="the united states of amer")
    check_match(predictions, references, expected_predictions=DEFAULT_MAX_WORD_HYPOTHESES)


def test_predict_words_no_context(shared_lm):
    """
    Make word predictions without any left context
    """
    references = ["i", "you", "the"]
    predictions = shared_lm.predict_words_old(left_context="")
    print(predictions)
    check_match(predictions, references, expected_predictions=DEFAULT_MAX_WORD_HYPOTHESES)


def test_predict_words_no_context_nbest(shared_lm):
    """
    Make word predictions without any left context
    Test with different nbest parameters
    """
    references = ["i", "you", "the", "what", "it", "but", "and", "this", "we"]
    for i in range(1, 10):
        predictions = shared_lm.predict_words_old(left_context="", nbest=i)
        check_match(predictions, references[:i], expected_predictions=i)


def test_predict_words_start_context(shared_lm):
    """
    Make word predictions at start of new word with strong left context
    """
    references = ["is", "of", "and"]
    predictions = shared_lm.predict_words_old(left_context="my name ")
    check_match(predictions, references, expected_predictions=DEFAULT_MAX_WORD_HYPOTHESES)


def test_predict_words_start_context_with_probs(shared_lm):
    """
    Make word predictions at start of new word with strong left context
    This version tests the optional return of tuples with log probabilities
    Also tests that a shorter context of 11 characters get the same answer
    But a short enough context changes the log probabilities
    """
    references = [
        ("is", -0.23404090013355017),
        ("of", -1.1886085281148553),
        ("and", -1.4341645850799978),
    ]
    # Using full sentence context
    predictions = shared_lm.predict_words_old(
        left_context="good morning my name ", return_log_probs=True
    )
    check_match(predictions, references, expected_predictions=DEFAULT_MAX_WORD_HYPOTHESES)

    # Now context is at the limit the model can use
    predictions = shared_lm.predict_words_old(left_context="ng my name ", return_log_probs=True)
    check_match(predictions, references, expected_predictions=DEFAULT_MAX_WORD_HYPOTHESES)

    # Now shortened context such that it changed just the log probabilities
    references = [
        ("is", -0.1719172364100814),
        ("of", -1.3368232259526849),
        ("and", -1.5823792829178274),
    ]
    predictions = shared_lm.predict_words_old(left_context="my name ", return_log_probs=True)
    check_match(predictions, references, expected_predictions=DEFAULT_MAX_WORD_HYPOTHESES)


def test_predict_words_with_end_symbols(shared_lm):
    """
    Make word predictions with multiple end symbols
    """
    references = ["d", "glish", "tire"]
    predictions = shared_lm.predict_words_old(
        left_context="this is the en", word_end_symbols=[" ", "!", "?", "."]
    )
    check_match(predictions, references, expected_predictions=DEFAULT_MAX_WORD_HYPOTHESES)


def test_predict_words_max3(shared_lm):
    """
    Make word predictions but with a smaller number of max word hypotheses
    """
    references = ["", "j", "q"]
    word_hypotheses = 3
    predictions = shared_lm.predict_words_old(
        left_context="this is a t", max_word_hypotheses=word_hypotheses
    )
    check_match(predictions, references, expected_predictions=word_hypotheses)


def test_predict_words_max965(shared_lm):
    """
    Make word predictions but with a larger number of max word hypotheses
    But not so large that we don't reach this number due to other pruning
    """
    references = ["ime", "errible", "ough"]
    word_hypotheses = 965
    predictions = shared_lm.predict_words_old(
        left_context="this is a t", max_word_hypotheses=word_hypotheses
    )
    check_match(predictions, references, expected_predictions=word_hypotheses)


def test_predict_words_max1000(shared_lm):
    """
    Make word predictions but with a larger number of max word hypotheses
    At this point we don't reach the target due to other pruning
    """
    references = ["ime", "errible", "ough"]
    word_hypotheses = 1000
    predictions = shared_lm.predict_words_old(
        left_context="this is a t", max_word_hypotheses=word_hypotheses
    )
    check_match(predictions, references, expected_predictions=965)


def test_predict_words_max1000_best6(shared_lm):
    """
    Make word predictions but with a larger number of max word hypotheses
    Increased beam width so we now find 1000 predictions
    """
    references = ["ime", "errible", "ough"]
    word_hypotheses = 1000
    predictions = shared_lm.predict_words_old(
        left_context="this is a t",
        max_word_hypotheses=word_hypotheses,
        beam_logp_best=6.0,
    )
    check_match(predictions, references, expected_predictions=word_hypotheses)


def test_predict_words_max1000_best6_max10(shared_lm):
    """
    Make word predictions but with a larger number of max word hypotheses
    Increased beam width but with reduced beam max resulting in finding fewer predictions
    """
    references = ["ime", "errible", "ough"]
    word_hypotheses = 1000
    predictions = shared_lm.predict_words_old(
        left_context="this is a t",
        max_word_hypotheses=word_hypotheses,
        beam_logp_best=6.0,
        beam_search_max=10,
    )
    check_match(predictions, references, expected_predictions=147)


def test_predict_words_len4_midword(shared_lm):
    """
    Make word predictions but limit word length to 4 letters in total
    This version tests with a partial prefix of one letter
    """
    references = ["ame", "ew", "ext"]
    max_word_len = 4
    current_len = 1
    predictions = shared_lm.predict_words_old(left_context="my n", max_word_len=max_word_len)
    check_match(predictions, references, expected_predictions=182)

    # Check all predictions are <= 3 characters (since we already have one letter)
    # Also be sure we find something that makes it to the max word length
    target_len = max_word_len - current_len
    assert check_len_limit(predictions, target_len) == target_len


def test_predict_words_len4_midword2(shared_lm):
    """
    Make word predictions but limit word length to 4 letters in total
    This version tests with a partial prefix of two letters
    """
    references = ["me", "il", ""]
    max_word_len = 4
    current_len = 2
    predictions = shared_lm.predict_words_old(left_context="my na", max_word_len=max_word_len)
    check_match(predictions, references, expected_predictions=106)

    # Check all predictions are <= 2 characters (since we already have two letters)
    # Also be sure we find something that makes it to the max word length
    target_len = max_word_len - current_len
    assert check_len_limit(predictions, target_len) == target_len


def test_predict_words_len4_start_word(shared_lm):
    """
    Make word predictions but limit word length to 4 letters in total
    This version tests with no prefix of the current word
    """
    references = ["dad", "son", "mom"]
    max_word_len = 4
    current_len = 0
    predictions = shared_lm.predict_words_old(left_context="my ", max_word_len=max_word_len)
    check_match(predictions, references, expected_predictions=DEFAULT_MAX_WORD_HYPOTHESES)

    # Check all predictions are <= the max word length
    # Also be sure we find something that makes it to the max word length
    target_len = max_word_len - current_len
    assert check_len_limit(predictions, target_len) == target_len


def test_predict_no_context(shared_lm):
    """
    Predict the next symbol based on having no left context
    """
    references = [
        ("i", 0.2343584801108431),
        ("t", 0.13211592376654224),
        ("w", 0.10467796169107213),
    ]
    predictions = shared_lm.predict(evidence=[])
    check_match(predictions, references, expected_predictions=len(shared_lm.symbol_set))
    check_sum_to_one(predictions)


def test_predict_with_short_context(shared_lm):
    """
    Predict the next symbol based on having some left context
    """
    references = [
        ("a", 0.6613459014658845),
        ("e", 0.2169462669013232),
        ("o", 0.05226519997615336),
    ]
    predictions = shared_lm.predict(evidence=list("my n"))
    check_match(predictions, references, expected_predictions=len(shared_lm.symbol_set))
    check_sum_to_one(predictions)


def test_predict_long_context_check_all(shared_lm):
    """
    Predict the next symbol based on having a lot of left context
    Also this test checks the entire symbol set
    """
    references = [
        ("w", 0.17285635336204394),
        ("d", 0.13906310598533556),
        ("c", 0.11882249960445865),
        ("h", 0.11068630027226566),
        ("a", 0.08941723271670499),
        ("l", 0.04354639620012885),
        ("s", 0.04194631951611507),
        ("n", 0.0413026547360662),
        ("t", 0.03794077309881237),
        ("g", 0.036815682068083375),
        ("f", 0.026439687324647722),
        ("k", 0.024349875592202305),
        ("r", 0.02326449873389944),
        ("m", 0.01875449382696545),
        ("p", 0.014056410732678215),
        ("b", 0.011997122378457938),
        ("e", 0.011454867902041062),
        ("u", 0.010445814770403223),
        ("i", 0.009278920042217847),
        ("o", 0.008167456099734056),
        ("j", 0.005090117723175747),
        ("v", 0.00296263467899673),
        ("y", 0.0008350353338797985),
        ("q", 0.0004728622844439802),
        ("z", 2.0419476822953604e-05),
        ("x", 1.2465539418917166e-05),
        (" ", 6.481092412261176e-200),
    ]
    predictions = shared_lm.predict(evidence=list("my name is not important but if you "))
    check_match(predictions, references, expected_predictions=len(shared_lm.symbol_set))
    check_sum_to_one(predictions)


def test_predict_unnormalized_logprobs(shared_lm):
    """
    Predict the next symbol but don't normalize to subset of our symbol_set
    """
    references = [
        ("w", -0.7624089121818542),
        ("d", -0.8568823337554932),
        ("c", -0.925195574760437),
    ]
    predictions = shared_lm.predict(
        evidence=list("my name is not important but if you "),
        unnormalized_logprobs=True,
    )
    check_match(predictions, references, expected_predictions=len(shared_lm.symbol_set))
    check_sum_less_than_one(predictions)


def test_predict_has_all_symbols(shared_lm):
    """
    Predict the next symbol based on having some left context
    Make sure we get exactly one hypothesis for each symbol in our set
    """
    predictions = shared_lm.predict(evidence=list("my n"))
    assert sorted(a for a, _ in predictions) == sorted(shared_lm.symbol_set)


def test_predict_symbol_endings(shared_lm_full_start_end):
    """
    Predict the next symbol based using model including end of sentence symbols
    """
    references = [
        (" ", -0.15905393660068512),
        (".", -0.7532857656478882),
        (",", -1.4871705770492554),
        ("i", -1.6081666946411133),
        ("s", -1.6310633420944214),
        ("?", -1.8620015382766724),
        ("e", -2.1706998348236084),
        ("l", -2.191169023513794),
        ("p", -2.2345008850097656),
        ("o", -2.321052074432373),
        ("a", -2.6255788803100586),
        ("!", -2.7555835247039795),
    ]

    predictions = shared_lm_full_start_end.predict(
        evidence=list("this is the end"), unnormalized_logprobs=True
    )
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm_full_start_end.symbol_set),
    )
    check_sum_less_than_one(predictions)


def test_predict_symbol_full(shared_lm_full_start_end):
    """
    Predict the next symbol based using model including all LM symbols
    This version normalizes the result to sum to 1.0, which fixes the KenLM answer which doesn't quite sum to 1.0
    """
    references = [
        ("</s>", 0.7729407912192374),
        (" ", 0.2244225605497543),
        ("c", 0.00046964579352591667),
    ]
    predictions = shared_lm_full_start_end.predict(evidence=list("this is the end."))
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm_full_start_end.symbol_set),
    )
    check_sum_to_one(predictions)


def test_predict_symbol_unnormalized_logprobs(shared_lm_full_start_end):
    """
    Predict the next symbol based using model including all LM symbols
    This version does not normalize the KenLM distribution that doesn't quite sum to 1.0
    """
    references = [
        ("</s>", -0.11175040155649185),
        (" ", -0.6488301157951355),
        ("c", -3.3281261920928955),
    ]
    predictions = shared_lm_full_start_end.predict(
        evidence=list("this is the end."),
        unnormalized_logprobs=True,
    )
    check_match(
        predictions,
        references,
        expected_predictions=len(shared_lm_full_start_end.symbol_set),
    )
    assert sum(prob for _, prob in predictions) == pytest.approx(
        -239.8013362661004, abs=EPSILON_NGRAM_PREDICT
    )


def test_class_name(shared_lm):
    """
    Check our name using the base class method
    """
    assert shared_lm.name() == "NGRAM"


def test_sentence_sum_log_prob(shared_lm_arpa):
    """
    Test a sentence with a known log probability (base 10)
    Should match result using SRILM's ngram utility:
    $ ngram -lm assets/lm_dec19_char_tiny_12gram.arpa -order 12 -ppl assets/phrases/people_shocked.txt
    """
    check_predict_sum_log_prob(
        expected=LOG_PROB_NGRAM_PEOPLE_SHOCKED_BASE10,
        lm=shared_lm_arpa,
        text=STR_PEOPLE_SHOCKED,
        base10=True,
        epsilon=EPSILON_NGRAM_PREDICT,
        unnormalized_logprobs=True,
    )


def test_alphabet_sum_log_prob(shared_lm_arpa):
    """
    Test all characters in the symbol set of the LM with a known log probability (base 10)
    Should match result using SRILM's ngram utility:
    $ ngram -lm assets/lm_dec19_char_tiny_12gram.arpa -order 12 -ppl assets/phrases/alphabet_lower.txt
    """
    check_predict_sum_log_prob(
        expected=LOG_PROB_NGRAM_LOWERCASE_LETTERS_SPACE_BASE10,
        lm=shared_lm_arpa,
        text=STR_LOWERCASE_LETTERS_SPACE,
        base10=True,
        epsilon=EPSILON_NGRAM_PREDICT,
        unnormalized_logprobs=True,
    )


def test_num_parameters(shared_lm):
    """
    There is no good way to compute this via the KenLM library
    """
    assert shared_lm.get_num_parameters() == 0


def test_text_to_letters(shared_lm):
    """
    Helper method that converts to a string that can be scored by KenLM in one call
    """
    text = "The cat  sat."
    assert (
        shared_lm._text_to_letters(text)
        == "T h e "
        + shared_lm.space_symbol
        + " c a t "
        + shared_lm.space_symbol
        + " "
        + shared_lm.space_symbol
        + " s a t ."
    )


def test_score_item(shared_lm):
    """
    Test computing the log prob (base e) for a single sentence
    """
    assert shared_lm.score_item(STR_PEOPLE_SHOCKED) == pytest.approx(
        LOG_PROB_NGRAM_PEOPLE_SHOCKED, abs=EPSILON_NGRAM_PREDICT
    )


def test_score_items_identical(shared_lm):
    """
    Test computing the log prob (base e) for multiple identical sentences
    """
    num_repeats = 7
    items = [STR_PEOPLE_SHOCKED] * num_repeats
    scores = shared_lm.score_items(items=items)
    for score in scores:
        assert score == pytest.approx(LOG_PROB_NGRAM_PEOPLE_SHOCKED, abs=EPSILON_NGRAM_PREDICT)


def test_score_items_alternating(shared_lm):
    """
    Test computing the log prob (base e) for multiple alternating sentences
    """
    # Create a list with alternating sentences with known log probs
    num_repeats = 7
    items = []
    for _ in range(num_repeats):
        items.append(STR_PEOPLE_SHOCKED)
        items.append(STR_LOWERCASE_LETTERS_SPACE)
    scores = shared_lm.score_items(items=items)

    for i in range(len(items)):
        if i % 2 == 0:
            assert scores[i] == pytest.approx(
                LOG_PROB_NGRAM_PEOPLE_SHOCKED, abs=EPSILON_NGRAM_PREDICT
            )
        else:
            assert scores[i] == pytest.approx(
                LOG_PROB_NGRAM_LOWERCASE_LETTERS_SPACE, abs=EPSILON_NGRAM_PREDICT
            )


def test_score_items_alphabet(shared_lm):
    """
    Test computing the log prob (base e) for all characters in the LM's vocabulary
    """
    items = list(SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS)
    scores = shared_lm.score_items(items=items)
    # This is almost all possible events after <s> (except the sentence start and end words)
    # Thus it should almost sum to one
    m = np.max(scores)
    prob_sum = float(np.exp(scores - m).sum() * np.exp(m))
    assert prob_sum == pytest.approx(1.0, abs=EPSILON_NGRAM_PREDICT)


def test_score_items_comm2(shared_lm):
    """
    Compute the log prob of each sentence in the COMM2 test set
    We filter to sentences without numbers, lowercase, and strip symbols other than apostrophe
    Compare against the known SRILM log probs for the same sentences
    """
    phrases = load_phrases_plaintext(filename=COMM2_PHRASES, drop_first_col=True)
    phrases = filter_phrases(phrases=phrases, drop_numbers=True)
    phrases, _ = normalize_phrases(phrases=phrases, lower=True, strip_symbols=True)
    scores = shared_lm.score_items(items=phrases)
    srilm_log_probs = read_float_list(filename=COMM2_NGRAM_LOG_PROBS)
    assert len(scores) == len(srilm_log_probs)
    for i in range(len(scores)):
        # Note: we need a bit larger epsilon for a few of the sentences
        assert scores[i] == pytest.approx(srilm_log_probs[i] * np.log(10), abs=0.2)
