"""
Run keystroke_savings on a tiny phrase file with an n-gram LM.
Confirms end-to-end execution with a sensible KS percentage.
 * Invokes scripts/keystroke_savings.py on a tiny phrase file.
 * Uses a character ARPA text format n-gram model.
 * Parses "FINAL KS:" from stdout and asserts it is within [0, 100].
"""

import pytest
from tests.test_constants import MINI_PHRASES, NGRAM_KENLM, FINAL_KS_STR
from scripts.keystroke_savings import main
from os import path


def test_keystroke_savings_with_ngram(capsys):
    if not (path.isfile(NGRAM_KENLM)):
        pytest.skip(f"Missing {NGRAM_KENLM}; run assets/download.sh")

    cmd_str = (
        f"--phrases {MINI_PHRASES} "
        + f"--ngram "
        + f"--ngram-lm {NGRAM_KENLM} "
        + f"--nbest 3 --beam 2.0 --beam-max 100 --max-word-len 25 --max-word-hypotheses 100 --strip-symbols --predict-lower --lower --no-times"
    )
    cmd = cmd_str.split(" ")
    try:
        main(args=cmd)
    except SystemExit as e:
        pytest.fail(f"Keystroke savings script exited with SystemExit: {e}")

    captured = capsys.readouterr()

    # Parse the "FINAL KS:" from stdout and check it is in range [0, 100]
    line = next((l for l in captured.out.splitlines() if l.startswith(FINAL_KS_STR)), None)
    assert line, f"No line starting with '{FINAL_KS_STR}' found in output!"
    ks = float(line.split(":")[1].strip())
    # Note: Changed to match under the new predict_words that searches in log base e
    assert ks == pytest.approx(46.5517, abs=0.01)
