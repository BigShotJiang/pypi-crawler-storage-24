"""
Causal subword LM loaded from a local snapshot.
"""

import os, pytest, unittest
from textslinger.causal_subword import CausalSubwordLanguageModel
from tests.test_constants import (
    SUBWORD_LLM_AAC_DIR,
    SYMBOLS_LOWERCASE_SPACE_APOSTROPHE,
    SUBWORD_LLM_AAC_ID,
)
from textslinger.helpers import Device, Precision


class TestCausalSubwordLocal(unittest.TestCase):
    """Set up model for testing"""

    @classmethod
    def setUpClass(cls):
        if not (os.path.isdir(SUBWORD_LLM_AAC_DIR)):
            pytest.skip(
                f"Missing {SUBWORD_LLM_AAC_DIR}; run assets/download.sh",
                allow_module_level=True,
            )

        # TODO: Ideally, test cases will leverage a variety of supported models and architectures to ensure changes don't break support for a particular model.

        # lm_path=model_dir forces purely local loading (no Hub lookups).
        cls.lm = CausalSubwordLanguageModel(
            symbol_set=SYMBOLS_LOWERCASE_SPACE_APOSTROPHE,
            lang_model_name=SUBWORD_LLM_AAC_ID,
            lm_path=SUBWORD_LLM_AAC_DIR,
            beam_width=6,
            max_completed=1500,
            device=Device.CPU,
            precision=Precision.FP32,
        )

    # TODO: Remove once confident the test suite is running properly
    def test_trivial(self):
        assert True

    """Character Prediction Tests"""

    def test_non_mutable_evidence(self):
        """Test that the model does not change the evidence variable passed in."""
        evidence = list("Test test")
        evidence2 = list("Test test")
        self.lm.predict(evidence)
        self.assertEqual(evidence, evidence2)

    def test_consistent_results(self):
        """Ensure predictions are the same for subsequent queries with the same evidence."""
        query1 = self.lm.predict(list("evidenc"))
        query2 = self.lm.predict(list("evidenc"))

        for (sym1, prob1), (sym2, prob2) in zip(query1, query2):
            self.assertEqual(sym1, sym2)
            self.assertAlmostEqual(prob1, prob2, places=5)

    def test_predict_empty_context(self):
        symbol_probs = self.lm.predict(evidence=[])
        probs = [prob for sym, prob in symbol_probs]

        self.assertTrue(
            len(set(probs)) > 1,
            "Distribution should not be uniform even without context.",
        )

        self.assertAlmostEqual(sum(probs), 1, places=3, msg="Probabilities should sum to 1.")

    def test_predict_middle_of_word(self):
        symbol_probs = self.lm.predict(evidence=list("This is a tes"))
        probs = [prob for sym, prob in symbol_probs]

        self.assertTrue(len(set(probs)) > 1, "Distribution should not be uniform.")

        self.assertAlmostEqual(sum(probs), 1, places=3, msg="Probabilities should sum to 1.")

        most_likely_sym, most_likely_prob = symbol_probs[0]
        self.assertAlmostEqual(
            most_likely_prob,
            max(probs),
            places=5,
            msg="Output list should be sorted in decreasing order.",
        )

        self.assertEqual(
            "t",
            most_likely_sym,
            f"Lowercase T should be the most likely symbol: {symbol_probs}.",
        )

    """Word Prediction Tests"""

    def test_local_model_predict_words_small_beam(self):

        # Small, fast query: we only assert that we get at least one completion.
        words = self.lm.predict_words(
            "the ",
            return_log_probs=False,
        )
        assert isinstance(words, list) and len(words) > 0
