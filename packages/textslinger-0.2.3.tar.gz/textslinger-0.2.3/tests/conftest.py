"""
For configuration options related to running the test suite
"""

import pytest
from textslinger.helpers import Device, Precision


def pytest_addoption(parser):
    parser.addoption("--device", type=Device, choices=list(Device), default=Device.CPU)
    parser.addoption(
        "--precision", type=Precision, choices=list(Precision), default=Precision.FP32
    )
    parser.addoption(
        "--run-optional",
        action="store_true",
        default=False,
        help="Run optional tests that are skipped by default",
    )
    parser.addoption(
        "--run-long",
        action="store_true",
        default=False,
        help="Run long tests that are skipped by default",
    )
    parser.addoption(
        "--rewrite-ref-files",
        action="store_true",
        default=False,
        help="Rewrite reference files, e.g. files with log probabilities obtained from a model",
    )


def pytest_runtest_setup(item):
    # Skip optional tests by default
    if "optional" in item.keywords and not item.config.getoption("--run-optional"):
        pytest.skip("Skipping optional test by default")

    # Skip long tests by default unless --run-long is provided
    if "long" in item.keywords and not item.config.getoption("--run-long"):
        pytest.skip("Skipping long test by default")


@pytest.fixture(scope="session")
def device(request):
    """
    Fixture to determine whether tests run on auto, cpu, cuda, or mps
    """
    return request.config.getoption("--device")


@pytest.fixture(scope="session")
def precision(request):
    """
    Fixture to set the precision models are loaded with
    """
    return request.config.getoption("--precision")


@pytest.fixture(scope="session")
def rewrite_ref_files(request):
    """
    Fixture to request some tests rewrite their reference files
    """
    return request.config.getoption("--rewrite-ref-files")
