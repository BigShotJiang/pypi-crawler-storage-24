"""
Fast unit-style tests that exercise constructor error paths and
confirm key init defaults are surfaced on the instance. Tests
do not require a downloaded or online LLM.

What these cover:
1) Error path: if Hugging Face loaders fail, the constructor should raise our
   InvalidLanguageModelException. We simulate loader failure with monkeypatch.

2) Success path: when the HF loader calls succeed, the constructor should expose
   key initialization defaults (beam_width, fp16, max_completed, predict_lower,
   batch_size) on the instance.
"""

import pytest

# We import-skip transformers because textslinger.causal_subword imports it at module import time.
pytest.importorskip(
    "transformers", reason="transformers package required to import the module"
)

import textslinger.causal_subword as sw
from textslinger.exceptions import InvalidLanguageModelException
from textslinger.helpers import Device, Precision


def test_constructor_raises_on_loader_failure(monkeypatch):
    """
    Idea: If HF loaders fail, the constructor should raise InvalidLanguageModelException.
    This exercises the error path without any network calls.
    """

    class _Raise:
        @classmethod
        def from_pretrained(cls, *a, **k):
            # Simulate any underlying HF/OSError
            raise OSError("simulated failure")

    # Patch the names used inside textslinger.causal_subword
    monkeypatch.setattr(sw, "AutoTokenizer", _Raise, raising=True)
    monkeypatch.setattr(sw, "AutoModelForCausalLM", _Raise, raising=True)

    with pytest.raises(InvalidLanguageModelException):
        sw.CausalSubwordLanguageModel(symbol_set=list("ab "), lang_model_name="ignored")


def test_constructor_exposes_init_defaults(monkeypatch):
    """
    Idea: With success stubs in place, confirm init parameters (beam_width, fp16,
    max_completed, predict_lower, batch_size) are reflected on the instance.
    """

    class _Tok:
        # minimal tokenizer attributes the class reads
        vocab_size = 8
        pad_token_id = 0
        bos_token_id = 1
        eos_token_id = 2

        @classmethod
        def from_pretrained(cls, *a, **k):
            return cls()

        # used by _build_vocab()
        def decode(self, ids):
            # Accept either a single id or a list like [id]
            if isinstance(ids, list) and ids and isinstance(ids[0], int):
                return f"tok{ids[0]}"
            if isinstance(ids, int):
                return f"tok{ids}"
            return ""

        # used by _encode() inside the class
        def encode(self, text, add_special_tokens=False):
            # Return a stable, tiny list of ids; keep within 0..vocab_size-1
            if not text:
                return [self.eos_token_id]
            # e.g., two tokens for any non-empty input
            return [self.bos_token_id, self.eos_token_id]

    class _Mod:
        @classmethod
        def from_pretrained(cls, *a, **k):
            # Minimal HF-like model: supports .half(), .eval(), .to()
            class M:
                def half(self):
                    return self

                def eval(self):
                    return self

                def to(self, *args, **kwargs):
                    return self

            return M()

    # Patch the HF classes referenced by our module to the stubs above.
    monkeypatch.setattr(sw, "AutoTokenizer", _Tok, raising=True)
    monkeypatch.setattr(sw, "AutoModelForCausalLM", _Mod, raising=True)

    lm = sw.CausalSubwordLanguageModel(
        symbol_set=list("ab "),
        lang_model_name="any",
        beam_width=8,
        max_completed=256,
        device=Device.CPU,
        precision=Precision.FP32,
    )
    # Ensure the constructor surfaced the requested initialization values.
    assert lm.beam_width == 8
    assert lm.max_completed == 256
