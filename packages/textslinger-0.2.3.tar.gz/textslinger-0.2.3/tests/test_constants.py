"""
Various constants that different tests may want to use.
"""

from pathlib import Path
import numpy as np

STR_LOWERCASE_LETTERS = "abcdefghijklmnopqrstuvwxyz"
STR_LOWERCASE_LETTERS_SPACE = "abcdefghijklmnopqrstuvwxyz "
LOG_PROB_NGRAM_LOWERCASE_LETTERS_SPACE_BASE10 = -67.260173141956329
LOG_PROB_NGRAM_LOWERCASE_LETTERS_SPACE = float(
    LOG_PROB_NGRAM_LOWERCASE_LETTERS_SPACE_BASE10 * np.log(10)
)
LOG_PROB_BYTE_LOWERCASE_LETTERS_SPACE = -29.576818466186523

# Symbol set for tests that only use lowercase letters plus space
SYMBOLS_LOWERCASE_SPACE = list(STR_LOWERCASE_LETTERS_SPACE)

# Including apostrophe as well
SYMBOLS_LOWERCASE_SPACE_APOSTROPHE = list("abcdefghijklmnopqrstuvwxyz' ")

# Also typical end of sentence punctuation
SYMBOLS_LOWERCASE_SPACE_APOSTROPHE_ENDINGS = list("abcdefghijklmnopqrstuvwxyz',.?! ")

# Upper and lowercase plus space
SYMBOLS_UPPER_LOWER_PLUS_SPACE = list(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
)

# Resolve to repo_root/assets
ASSETS_DIR = Path(__file__).resolve().parents[1] / "assets"

# Resolve to repo_root/scripts
SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "scripts"

# N-gram LM files we use in our tests
NGRAM_ARPA = str(ASSETS_DIR / "lm_dec19_char_tiny_12gram.arpa")
NGRAM_KENLM = str(ASSETS_DIR / "lm_dec19_char_tiny_12gram.kenlm")

# Small set of sentences
MINI_PHRASES = str(ASSETS_DIR / "phrases/mini_phrases.txt")

# Script for measuring keystroke savings
KEYSTROKE_SAVINGS_SCRIPT = str(SCRIPTS_DIR / "keystroke_savings.py")

# String used by the keystroke savings script for its final output
FINAL_KS_STR = "FINAL KS:"

# Subword tokenized LLM optimized for AAC like text, based on the OPT LLM (350M parameters)
# TODO: maybe replace this with a smaller model
SUBWORD_LLM_AAC_ID = "figmtu/opt-350m-aac"

# Local subword tokenized LLM obtained using the download.sh script
# TODO: maybe replace this with a smaller model
SUBWORD_LLM_AAC_DIR = str(ASSETS_DIR / "aac_subword")

# Community maintained converted version of Meta's byte latent transformer
# https://arxiv.org/abs/2412.09871
# Currently requires transformers 5.0 nightly build to fix bug
BYTE_LLM = "itazap/blt-1b-hf"
BYTE_LLM_PARAMS = 4633391872
BYTE_LLM_TOKENS = 260

# A sentence for measuring log probability under the language models
# This was measured using SRILM's ngram utility using the ARPA text format NGRAM_ARPA
# The model conditioned the start on <s> but did not predict a final </s>
STR_PEOPLE_SHOCKED = "people down here are shocked"
LOG_PROB_NGRAM_PEOPLE_SHOCKED_BASE10 = -14.707553195308719
LOG_PROB_NGRAM_PEOPLE_SHOCKED = float(LOG_PROB_NGRAM_PEOPLE_SHOCKED_BASE10 * np.log(10))
LOG_PROB_BYTE_PEOPLE_SHOCKED = -45.126502990722656

# COMM2 phrase set of AAC like messages
COMM2_PHRASES = str(ASSETS_DIR / "phrases/comm2.txt")

# The log probs (base 10) of the phrases in COMM2 as calculated by SRILM's ngram utility
# Phrases with numbers were removed and text was lowercased and stripped of symbols except for apostrophe
COMM2_NGRAM_LOG_PROBS = str(ASSETS_DIR / "phrases/comm2_ngram_logprobs.txt")

# Log probs (base e) measured by Meta's BLT LLM
COMM2_BYTE_LOG_PROBS = str(ASSETS_DIR / "phrases/comm2_byte_logprobs.txt")
