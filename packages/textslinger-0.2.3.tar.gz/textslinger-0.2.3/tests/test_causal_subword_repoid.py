"""
Test subword tokenized LLM loaded via a Hugging Face repository ID.
The model will be downloaded the first time a test is run.
After this, the model should be loaded from the local cache.
"""

from textslinger.causal_subword import CausalSubwordLanguageModel
from tests.test_constants import (
    SYMBOLS_LOWERCASE_SPACE_APOSTROPHE,
    SUBWORD_LLM_AAC_ID,
)
from textslinger.helpers import Device, Precision


def test_load_predict_word():
    # No lm_path here: we intentionally exercise the 'load by repo id' code path.
    lm = CausalSubwordLanguageModel(
        symbol_set=SYMBOLS_LOWERCASE_SPACE_APOSTROPHE,
        lang_model_name=SUBWORD_LLM_AAC_ID,
        beam_width=4,
        max_completed=800,
        device=Device.CPU,
        precision=Precision.FP32,
    )
    words = lm.predict_words("a ", nbest=2, return_log_probs=False)
    assert isinstance(words, list) and len(words) > 0
