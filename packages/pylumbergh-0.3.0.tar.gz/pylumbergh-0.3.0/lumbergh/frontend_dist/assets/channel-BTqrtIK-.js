import{ap as o,aq as n}from"./index-BE27zu0q.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
