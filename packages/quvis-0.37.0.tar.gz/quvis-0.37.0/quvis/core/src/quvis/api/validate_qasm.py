"""
QASM Validation API

This module parses a QASM file directly to validate it and extract the number of qubits.
"""

import sys, json, argparse, logging
from qiskit import QuantumCircuit

logger = logging.getLogger(__name__)

def main():
    parser = argparse.ArgumentParser(description="Validate a QASM file")
    parser.add_argument("--qasm-file", required=True, type=str, help="Path to the QASM file")
    args = parser.parse_args()

    try:
        circuit = QuantumCircuit.from_qasm_file(args.qasm_file)
        result = {
            "valid": True,
            "num_qubits": circuit.num_qubits,
        }
        print(json.dumps(result, separators=(",", ":")))
    except Exception as e:
        logger.error(f"ERROR: QASM validation failed: {e}")
        error_result = {"valid": False, "error": str(e)}
        print(json.dumps(error_result, separators=(",", ":")))
        sys.exit(1)

if __name__ == "__main__":
    main()
