// quvis/web/src/config/defaults.ts
// Single source of truth for all visualization parameter defaults.
// Edit this file to set personal preference defaults.

export const VISUALIZATION_DEFAULTS = {
    appearance: {
        qubitSize: 1.0,
        connectionThickness: 0.05,
        inactiveAlpha: 0.1,
        renderBlochSpheres: false,
        renderConnectionLines: true,
        baseSize: 2000.0,
    },
    layout: {
        repelForce: 0.6,
        idealDistance: 1.0,
        iterations: 500,
        attractForce: 0.1,
        coreDistance: 5.0,
        is3D: false,
        distanceMaxMultiplier: 5.0,
    },
    heatmap: {
        maxSlices: -1, // -1 means no limit
        fadeThreshold: 0.2,
        greenThreshold: 0.6,
        yellowThreshold: 0.8,
        intensityPower: 0.3,
        minIntensity: 0.001,
        borderWidth: 0.0,
    },
    fidelity: {
        oneQubitBase: 0.99,
        twoQubitBase: 0.98,
    },
    multicore: {
        interCoreSpacing: 20.0, // world-unit gap between core edges — must match backend: core/src/quvis/factories.py _INTER_CORE_SPACING
    },
} as const;

export type CoreConnectivity = 'all-to-all' | 'grid' | 'line' | 'ring';