// quvis/web/src/test/constants.test.ts
import { describe, it, expect, vi, beforeEach } from 'vitest';

describe('fetchConstants', () => {
    beforeEach(() => {
        vi.restoreAllMocks();
    });

    it('calls the constants URL and returns parsed JSON', async () => {
        const mockData = {
            qubits: { min: 2, max: 10000, default: 100 },
            heavy_hex_distance: { min: 3, max: 21, step: 2, default: 7 },
            grid_size: { min: 2, max: 30, default: 10 },
            optimization_level: { min: 0, max: 3, default: 1 },
            qaoa_reps: { min: 1, max: 10, default: 2 },
        };

        global.fetch = vi.fn().mockResolvedValue({
            ok: true,
            json: () => Promise.resolve(mockData),
        } as any);

        const { fetchConstants } = await import('../config/constants.js');
        const result = await fetchConstants();

        expect(fetch).toHaveBeenCalledWith(expect.stringContaining('/api/constants'));
        expect(result.qubits.max).toBe(10000);
        expect(result.heavy_hex_distance.step).toBe(2);
    });

    it('throws when the response is not ok', async () => {
        global.fetch = vi.fn().mockResolvedValue({
            ok: false,
            status: 503,
        } as any);

        const { fetchConstants } = await import('../config/constants.js');
        await expect(fetchConstants()).rejects.toThrow('Failed to fetch constants');
    });
});
