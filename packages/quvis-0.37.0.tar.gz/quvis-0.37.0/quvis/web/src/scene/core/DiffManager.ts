import * as THREE from 'three';
import { QubitGridController } from '../objects/QubitGridController.js';
import { VISUALIZATION_DEFAULTS } from '../../config/defaults.js';

export interface DiffPanel {
    circuitIndex: number;
    scene: THREE.Scene;
    grid: QubitGridController;
}

export interface ViewportRect {
    x: number;
    y: number;
    width: number;
    height: number;
}

interface DiffManagerParams {
    visualizationMode: 'compiled' | 'logical';
    maxSlicesForHeatmap: number;
    repelForce: number;
    idealDistance: number;
    iterations: number;
    coreDistance: number;
    connectionThickness: number;
    inactiveAlpha: number;
    qubitSize: number;
    blochSpheresVisible: boolean;
    connectionLinesVisible: boolean;
}

export class DiffManager {
    private panels: DiffPanel[] = [];
    private data: any;
    private camera: THREE.PerspectiveCamera;
    private mouse: THREE.Vector2;
    private isLightBackground: () => boolean;
    private smartAlignment?: any;
    private params: DiffManagerParams;

    constructor(
        data: any,
        camera: THREE.PerspectiveCamera,
        mouse: THREE.Vector2,
        isLightBackground: () => boolean,
        smartAlignment?: any,
        params?: DiffManagerParams,
    ) {
        this.data = data;
        this.camera = camera;
        this.mouse = mouse;
        this.isLightBackground = isLightBackground;
        this.smartAlignment = smartAlignment;
        this.params = params ?? {
            visualizationMode: 'compiled',
            maxSlicesForHeatmap: VISUALIZATION_DEFAULTS.heatmap.maxSlices,
            repelForce: VISUALIZATION_DEFAULTS.layout.repelForce,
            idealDistance: VISUALIZATION_DEFAULTS.layout.idealDistance,
            iterations: VISUALIZATION_DEFAULTS.layout.iterations,
            coreDistance: VISUALIZATION_DEFAULTS.layout.coreDistance,
            connectionThickness: VISUALIZATION_DEFAULTS.appearance.connectionThickness,
            inactiveAlpha: VISUALIZATION_DEFAULTS.appearance.inactiveAlpha,
            qubitSize: VISUALIZATION_DEFAULTS.appearance.qubitSize,
            blochSpheresVisible: VISUALIZATION_DEFAULTS.appearance.renderBlochSpheres,
            connectionLinesVisible: VISUALIZATION_DEFAULTS.appearance.renderConnectionLines,
        };
    }

    get isDiffMode(): boolean {
        return this.panels.length > 1;
    }

    get panelCount(): number {
        return this.panels.length;
    }

    get activePanels(): readonly DiffPanel[] {
        return this.panels;
    }

    getMaxSliceCount(): number {
        if (this.panels.length === 0) return 0;
        return Math.max(...this.panels.map(p => p.grid.getActiveSliceCount()));
    }

    getViewportRects(canvasWidth: number, canvasHeight: number): ViewportRect[] {
        const count = this.panels.length;
        if (count === 0) return [];

        const columnWidth = canvasWidth / count;
        return this.panels.map((_, i) => ({
            x: i * columnWidth,
            y: 0,
            width: columnWidth,
            height: canvasHeight,
        }));
    }

    addPanel(circuitIndex: number): DiffPanel {
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(this.isLightBackground() ? 0xffffff : 0x121212);

        const grid = new QubitGridController(
            scene,
            this.mouse,
            this.camera,
            this.data,
            this.params.visualizationMode,
            this.params.maxSlicesForHeatmap,
            this.params.repelForce,
            this.params.idealDistance,
            this.params.iterations,
            this.params.coreDistance,
            this.params.connectionThickness,
            this.params.inactiveAlpha,
            this.params.qubitSize,
            this.params.blochSpheresVisible,
            this.params.connectionLinesVisible,
            undefined, // onSlicesLoadedCallback
            this.isLightBackground,
            undefined, // smartAlignment
            undefined, // onSettingsChanged
        );

        grid.switchToCircuit(circuitIndex);

        const panel: DiffPanel = { circuitIndex, scene, grid };
        this.panels.push(panel);
        return panel;
    }

    removePanel(circuitIndex: number): void {
        const index = this.panels.findIndex(p => p.circuitIndex === circuitIndex);
        if (index === -1) return;

        const panel = this.panels[index];
        panel.grid.dispose();
        this.panels.splice(index, 1);
    }

    setCurrentSlice(sliceIndex: number): void {
        for (const panel of this.panels) {
            const maxSlice = panel.grid.getActiveSliceCount() - 1;
            const clamped = Math.max(0, Math.min(sliceIndex, maxSlice));
            panel.grid.setCurrentSlice(clamped);
        }
    }

    updateAppearanceParameters(params: {
        qubitSize?: number;
        connectionThickness?: number;
        inactiveAlpha?: number;
        baseSize?: number;
    }): void {
        for (const panel of this.panels) {
            panel.grid.updateAppearanceParameters(params);
        }
    }

    updateLayoutParameters(
        params: {
            repelForce?: number;
            idealDistance?: number;
            iterations?: number;
            coreDistance?: number;
            is3D?: boolean;
            distanceMaxMultiplier?: number;
        },
        onComplete?: () => void,
    ): void {
        if (this.panels.length === 0) {
            onComplete?.();
            return;
        }

        let remaining = this.panels.length;
        const onPanelComplete = () => {
            remaining--;
            if (remaining <= 0) {
                onComplete?.();
            }
        };

        for (const panel of this.panels) {
            panel.grid.updateLayoutParameters(params, onPanelComplete);
        }
    }

    updateHeatmapSlices(slices: number): void {
        for (const panel of this.panels) {
            panel.grid.updateHeatmapSlices(slices);
        }
    }

    updateHeatmapColorParameters(params: {
        fadeThreshold?: number;
        greenThreshold?: number;
        yellowThreshold?: number;
        intensityPower?: number;
        minIntensity?: number;
        borderWidth?: number;
    }): void {
        for (const panel of this.panels) {
            panel.grid.updateHeatmapColorParameters(params);
        }
    }

    updateHeatmapLightBackground(isLight: boolean): void {
        for (const panel of this.panels) {
            panel.scene.background = new THREE.Color(isLight ? 0xffffff : 0x121212);
            panel.grid.updateHeatmapLightBackground(isLight);
        }
    }

    updateConnectionColors(): void {
        for (const panel of this.panels) {
            panel.grid.updateConnectionColors();
        }
    }

    setBlochSpheresVisible(visible: boolean): void {
        for (const panel of this.panels) {
            panel.grid.setBlochSpheresVisible(visible);
        }
    }

    setConnectionLinesVisible(visible: boolean): void {
        for (const panel of this.panels) {
            panel.grid.setConnectionLinesVisible(visible);
        }
    }

    updateHeatmapBaseSize(size: number): void {
        for (const panel of this.panels) {
            if (panel.grid.heatmap) {
                panel.grid.heatmap.updateBaseSize(size);
            }
        }
    }

    resizeHeatmaps(canvasWidth: number, canvasHeight: number): void {
        const viewports = this.getViewportRects(canvasWidth, canvasHeight);
        for (let i = 0; i < this.panels.length; i++) {
            const vp = viewports[i];
            const heatmap = this.panels[i].grid.heatmap;
            if (heatmap) {
                heatmap.resize(vp.width, vp.height);
                heatmap.material.uniforms.aspect.value = vp.width / vp.height;
            }
        }
    }

    dispose(): void {
        for (const panel of this.panels) {
            panel.grid.dispose();
        }
        this.panels = [];
    }
}
