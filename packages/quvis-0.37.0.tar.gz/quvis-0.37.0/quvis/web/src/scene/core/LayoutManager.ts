import * as THREE from "three";
// @ts-ignore
import { forceSimulation, forceLink, forceManyBody, forceCenter, forceCollide, forceX, forceY, forceZ } from 'd3-force-3d';
import { VISUALIZATION_DEFAULTS } from "../../config/defaults.js";

interface LayoutParameters {
    kRepel: number;
    idealDist: number;
    iterations: number;
    kAttract: number;
    barnesHutTheta: number;
    coreDistance: number;
    is3D: boolean;
    distanceMaxMultiplier: number;
}

export class LayoutManager {
    // Area Calculation
    private static readonly LAYOUT_AREA_SCALE = 2.5;

    // Default Parameters
    public static readonly DEFAULT_K_REPEL = VISUALIZATION_DEFAULTS.layout.repelForce;
    public static readonly DEFAULT_IDEAL_DIST = VISUALIZATION_DEFAULTS.layout.idealDistance;
    public static readonly DEFAULT_ITERATIONS = VISUALIZATION_DEFAULTS.layout.iterations;
    public static readonly DEFAULT_K_ATTRACT = 0.1;
    public static readonly DEFAULT_BARNES_HUT_THETA = 0.8;
    public static readonly DEFAULT_CORE_DISTANCE = 5.0;
    public static readonly DEFAULT_IS_3D = false;
    public static readonly DEFAULT_DISTANCE_MAX_MULTIPLIER = 5.0;

    private qubitPositions: Map<number, THREE.Vector3> = new Map();
    private layoutParams: LayoutParameters;
    private layoutAreaSide: number = 0;
    public lastLayoutCalculationTime: number = 0;
    private currentComputationId: number = 0;

    constructor(config: Partial<LayoutParameters> = {}) {
        this.layoutParams = {
            kRepel: config.kRepel ?? LayoutManager.DEFAULT_K_REPEL,
            idealDist: config.idealDist ?? LayoutManager.DEFAULT_IDEAL_DIST,
            iterations: config.iterations ?? LayoutManager.DEFAULT_ITERATIONS,
            kAttract: config.kAttract ?? LayoutManager.DEFAULT_K_ATTRACT,
            barnesHutTheta: config.barnesHutTheta ?? LayoutManager.DEFAULT_BARNES_HUT_THETA,
            coreDistance: config.coreDistance ?? LayoutManager.DEFAULT_CORE_DISTANCE,
            is3D: config.is3D ?? LayoutManager.DEFAULT_IS_3D,
            distanceMaxMultiplier: config.distanceMaxMultiplier ?? LayoutManager.DEFAULT_DISTANCE_MAX_MULTIPLIER,
        };
    }

    get positions(): Map<number, THREE.Vector3> {
        return this.qubitPositions;
    }

    get parameters(): LayoutParameters {
        return { ...this.layoutParams };
    }

    get areaSide(): number {
        return this.layoutAreaSide;
    }

    public abortComputation(): void {
        this.currentComputationId++;
    }

    /**
     * Apply grid layout to existing qubits, maintaining their order
     */
    applyGridLayoutToExistingQubits(): void {
        this.abortComputation();
        const qubitIds = Array.from(this.qubitPositions.keys()).sort(
            (a, b) => a - b,
        );
        const numQubits = qubitIds.length;

        if (numQubits === 0) return;

        const cols = Math.ceil(Math.sqrt(numQubits));
        const rows = Math.ceil(numQubits / cols);

        const gridWidth = (cols - 1) * this.layoutParams.idealDist;
        const gridHeight = (rows - 1) * this.layoutParams.idealDist;
        const startX = -gridWidth / 2;
        const startY = gridHeight / 2;

        qubitIds.forEach((qubitId, index) => {
            const col = index % cols;
            const row = Math.floor(index / cols);
            const x = startX + col * this.layoutParams.idealDist;
            const y = startY - row * this.layoutParams.idealDist;
            this.qubitPositions.set(qubitId, new THREE.Vector3(x, y, 0));
        });
    }

    /**
     * Apply a pre-calculated deterministic layout (e.g., from the backend)
     */
    applyDeterministicLayout(nodes: Array<{ id: number; x: number; y: number; z?: number }>): void {
        this.abortComputation();
        this.qubitPositions.clear();

        nodes.forEach(node => {
            this.qubitPositions.set(node.id, new THREE.Vector3(node.x, node.y, node.z || 0));
        });
    }



    /**
     * Update layout parameters
     */
    updateParameters(params: {
        repelForce?: number;
        idealDistance?: number;
        iterations?: number;
        attractForce?: number;
        coreDistance?: number;
        is3D?: boolean;
        distanceMaxMultiplier?: number;
    }): boolean {
        let changed = false;

        if (
            params.repelForce !== undefined &&
            this.layoutParams.kRepel !== params.repelForce
        ) {
            this.layoutParams.kRepel = params.repelForce;
            changed = true;
        }
        if (
            params.idealDistance !== undefined &&
            this.layoutParams.idealDist !== params.idealDistance
        ) {
            this.layoutParams.idealDist = params.idealDistance;
            changed = true;
        }
        if (
            params.iterations !== undefined &&
            this.layoutParams.iterations !== params.iterations
        ) {
            this.layoutParams.iterations = params.iterations;
            changed = true;
        }
        if (
            params.attractForce !== undefined &&
            this.layoutParams.kAttract !== params.attractForce
        ) {
            this.layoutParams.kAttract = params.attractForce;
            changed = true;
        }
        if (
            params.coreDistance !== undefined &&
            this.layoutParams.coreDistance !== params.coreDistance
        ) {
            this.layoutParams.coreDistance = params.coreDistance;
            changed = true;
        }
        if (
            params.is3D !== undefined &&
            this.layoutParams.is3D !== params.is3D
        ) {
            this.layoutParams.is3D = params.is3D;
            changed = true;
        }
        if (
            params.distanceMaxMultiplier !== undefined &&
            this.layoutParams.distanceMaxMultiplier !== params.distanceMaxMultiplier
        ) {
            this.layoutParams.distanceMaxMultiplier = params.distanceMaxMultiplier;
            changed = true;
        }

        return changed;
    }

    /**
     * Update just the ideal distance and apply grid layout
     */
    updateIdealDistance(distance: number): void {
        if (this.layoutParams.idealDist !== distance) {
            this.layoutParams.idealDist = distance;
            this.applyGridLayoutToExistingQubits();
        }
    }

    getQubitPosition(qubitId: number): THREE.Vector3 | undefined {
        return this.qubitPositions.get(qubitId);
    }

    setQubitPosition(qubitId: number, position: THREE.Vector3): void {
        this.qubitPositions.set(qubitId, position.clone());
    }

    clearPositions(): void {
        this.qubitPositions.clear();
    }

    getQubitIds(): number[] {
        return Array.from(this.qubitPositions.keys());
    }

    hasQubit(qubitId: number): boolean {
        return this.qubitPositions.has(qubitId);
    }

    getQubitCount(): number {
        return this.qubitPositions.size;
    }

    private validateSimulationInput(
        numNodes: number,
        edges: number[][],
        externalAttractions: { nodeIndex: number; targetPosition: THREE.Vector3; strength: number }[]
    ): void {
        for (const edge of edges) {
            if (edge[0] >= numNodes || edge[1] >= numNodes) {
                throw new Error(
                    `Invalid edge in force simulation: [${edge[0]}, ${edge[1]}] for ${numNodes} nodes`
                );
            }
        }
        for (const att of externalAttractions) {
            if (att.nodeIndex >= numNodes) {
                throw new Error(
                    `Invalid external attraction: nodeIndex ${att.nodeIndex} out of bounds for ${numNodes} nodes`
                );
            }
        }
    }

    /**
     * Run an asynchronous force-directed simulation for a graph
     */
    private async runForceSimulation(
        numNodes: number,
        edges: number[][],
        iterations: number,
        kRepel: number,
        kAttract: number,
        idealDist: number,
        is3D: boolean,
        distanceMaxMultiplier: number,
        externalAttractions: { nodeIndex: number; targetPosition: THREE.Vector3; strength: number }[] = [],
        onTick?: (nodes: { id: number, x: number, y: number, z: number }[]) => void,
        initialPositions?: THREE.Vector3[],
        computationId?: number
    ): Promise<THREE.Vector3[]> {
        console.log("Running force simulation for", numNodes, "nodes");
        if (numNodes <= 0) return [];
        if (numNodes === 1) return [new THREE.Vector3(0, 0, 0)];

        const initialSpread = idealDist * Math.sqrt(numNodes) * 0.1;

        // 1. Initialize Nodes for D3
        const nodes: { id: number, x: number, y: number, z: number, vx?: number, vy?: number, vz?: number }[] = Array.from({ length: numNodes }, (_, i) => {
            if (initialPositions && initialPositions[i]) {
                const pos = initialPositions[i];
                return {
                    id: i,
                    x: pos.x,
                    y: pos.y,
                    z: is3D ? pos.z : 0
                };
            }
            return {
                id: i,
                x: (Math.random() - 0.5) * initialSpread,
                y: (Math.random() - 0.5) * initialSpread,
                z: is3D ? (Math.random() - 0.5) * initialSpread : 0
            };
        });

        // 2. Initialize Links for D3
        const links = edges.map(edge => ({
            source: edge[0],
            target: edge[1]
        }));

        // 3. Configure D3 Simulation
        // Using numDimensions(3) to allow generic 3D space, though we focus on 2.5D
        // WARNING: MUST attach numDimensions(3) before adding nodes due to a bug in d3-force-3d vz initialization
        const simulation = forceSimulation()
            .numDimensions(is3D ? 3 : 2)
            .nodes(nodes)
            .force('charge', forceManyBody().strength(-kRepel * 10).distanceMax(idealDist * distanceMaxMultiplier))
            .force('link', forceLink(links).id((d: any) => d.id).distance(idealDist).strength(kAttract))
            .force('center', forceCenter(0, 0, 0))
            .force('collide', forceCollide(idealDist * 0.45).iterations(2));

        // Add external attractions (custom force in D3)
        if (externalAttractions && externalAttractions.length > 0) {
            simulation.force('external', (alpha: number) => {
                for (const attr of externalAttractions) {
                    const node = nodes[attr.nodeIndex];
                    if (node) {
                        node.vx = (node.vx || 0) + (attr.targetPosition.x - node.x) * attr.strength * alpha;
                        node.vy = (node.vy || 0) + (attr.targetPosition.y - node.y) * attr.strength * alpha;
                        node.vz = (node.vz || 0) + (attr.targetPosition.z - node.z) * attr.strength * alpha;
                    }
                }
            });
        }

        // To keep Z near 0 unless pushed out by strong 3D forces
        // simulation.force('z', forceZ(0).strength(0.01));

        // Let D3 fully stabilize the graph natively instead of arbitrary iteration counts
        // Standard D3 approach: tick synchronously until alpha reaches alphaMin
        simulation.stop();

        // Adjust alphaDecay roughly to user requested iterations
        // Default alphaDecay is ~0.0228, which yields ~300 iterations.
        // alphaDecay = 1 - (alphaMin/alpha0)^(1/iterations)
        const alphaMin = 0.001;
        const alphaDecay = 1 - Math.pow(alphaMin, 1 / Math.max(iterations, 1));
        simulation.alphaDecay(alphaDecay);

        return new Promise((resolve) => {
            let currentTick = 0;
            const frameBudgetMs = 12; // ~12ms budget to leave room for React/ThreeJS rendering to maintain 60fps

            const step = () => {
                if (computationId !== undefined && this.currentComputationId !== computationId) {
                    simulation.stop();
                    resolve(nodes.map(pos => new THREE.Vector3(pos.x, pos.y, pos.z)));
                    return;
                }

                const startTime = performance.now();

                // Run as many ticks as possible within the frame budget
                // Always do at least 1 tick to ensure progress
                do {
                    simulation.tick();
                    currentTick++;
                } while (currentTick < iterations && (performance.now() - startTime) < frameBudgetMs);

                if (onTick) {
                    onTick(nodes);
                }

                if (currentTick >= iterations) {
                    const positions = nodes.map(pos => new THREE.Vector3(pos.x, pos.y, pos.z));
                    resolve(positions);
                } else {
                    requestAnimationFrame(step);
                }
            };

            requestAnimationFrame(step);
        });

    }

    /**
     * Calculate layout for modular architecture
     */
    async calculateModularLayout(
        modularInfo: {
            num_cores: number;
            qubits_per_core: number;
            global_topology: string;       // unused — reserved for future topology-aware layout
            inter_core_links?: number[][]; // unused — reserved for future rotation alignment
        },
        coreDistance: number = LayoutManager.DEFAULT_CORE_DISTANCE, // unused — spacing derived from bounding radius
        couplingMap: number[][],
        onTick?: (positions: Map<number, THREE.Vector3>) => void
    ): Promise<void> {
        this.abortComputation();
        const computationId = this.currentComputationId;

        const { num_cores, qubits_per_core } = modularInfo;
        const numQubits = num_cores * qubits_per_core;

        if (numQubits === 0) {
            this.qubitPositions.clear();
            return;
        }

        const existingPositions = this.qubitPositions.size === numQubits ? new Map(this.qubitPositions) : null;
        this.qubitPositions.clear();

        // Seed intra-core layouts from existing positions if available
        const initialLocalPositions: Map<number, THREE.Vector3[]> = new Map();
        if (existingPositions) {
            // Validate that all expected qubit IDs exist before seeding
            let allKeysPresent = true;
            for (let id = 0; id < numQubits && allKeysPresent; id++) {
                if (!existingPositions.has(id)) allKeysPresent = false;
            }

            if (allKeysPresent) {
                for (let c = 0; c < num_cores; c++) {
                    let centroid = new THREE.Vector3();
                    for (let j = 0; j < qubits_per_core; j++) {
                        centroid.add(existingPositions.get(c * qubits_per_core + j)!);
                    }
                    centroid.divideScalar(qubits_per_core);
                    const localPosArray: THREE.Vector3[] = [];
                    for (let j = 0; j < qubits_per_core; j++) {
                        localPosArray.push(existingPositions.get(c * qubits_per_core + j)!.clone().sub(centroid));
                    }
                    initialLocalPositions.set(c, localPosArray);
                }
            }
        }

        // Step 1: Run intra-core force layouts
        const coreInternalEdges: Map<number, number[][]> = new Map();
        for (let c = 0; c < num_cores; c++) coreInternalEdges.set(c, []);

        for (const pair of couplingMap) {
            const core1 = Math.floor(pair[0] / qubits_per_core);
            const core2 = Math.floor(pair[1] / qubits_per_core);
            if (core1 === core2) {
                coreInternalEdges.get(core1)?.push([pair[0] % qubits_per_core, pair[1] % qubits_per_core]);
            }
        }

        const coreLocalPositions: Map<number, THREE.Vector3[]> = new Map();

        for (let c = 0; c < num_cores; c++) {
            const edges = coreInternalEdges.get(c) || [];
            const localPos = await this.runForceSimulation(
                qubits_per_core,
                edges,
                this.layoutParams.iterations,
                this.layoutParams.kRepel,
                this.layoutParams.kAttract,
                this.layoutParams.idealDist,
                this.layoutParams.is3D,
                this.layoutParams.distanceMaxMultiplier,
                [],
                (nodes) => {
                    if (num_cores === 1 && onTick) {
                        for (let j = 0; j < qubits_per_core; j++) {
                            this.qubitPositions.set(j, new THREE.Vector3(nodes[j].x, nodes[j].y, nodes[j].z));
                        }
                        onTick(this.qubitPositions);
                    }
                },
                initialLocalPositions.get(c),
                computationId
            );

            if (this.currentComputationId !== computationId) return;
            coreLocalPositions.set(c, localPos);
        }

        // Step 2: Compute maxBoundingRadius across all cores
        // localPos is centred at origin by forceCenter in the simulation
        let maxBoundingRadius = 0;
        for (let c = 0; c < num_cores; c++) {
            const localPositions = coreLocalPositions.get(c)!;
            for (const pos of localPositions) {
                maxBoundingRadius = Math.max(maxBoundingRadius, pos.length());
            }
        }

        // Step 3: Compute polygon core centers
        // d = centre-to-centre distance between adjacent cores
        // = 2 * maxBoundingRadius (both cores' edges) + interCoreSpacing (the gap between them)
        const interCoreSpacing = VISUALIZATION_DEFAULTS.multicore.interCoreSpacing;
        const d = 2 * maxBoundingRadius + interCoreSpacing;

        const corePositions: THREE.Vector3[] = computePolygonCorePositions(num_cores, d);

        // Step 4: Combine positions (no rotation — connections not wired yet)
        for (let i = 0; i < num_cores; i++) {
            const corePos = corePositions[i];
            const localPositions = coreLocalPositions.get(i)!;
            for (let j = 0; j < qubits_per_core; j++) {
                this.qubitPositions.set(i * qubits_per_core + j, new THREE.Vector3().copy(corePos).add(localPositions[j]));
            }
        }

        // Estimate area side
        let maxDim = 0;
        this.qubitPositions.forEach(p => {
            maxDim = Math.max(maxDim, Math.abs(p.x), Math.abs(p.y));
        });
        this.layoutAreaSide = maxDim * LayoutManager.LAYOUT_AREA_SCALE;
    }

    // Retained for future use when inter-core connections are wired.
    // Will be called from calculateModularLayout to align comm qubits toward their target cores.
    private applyRigidBodyRotation(
        localPos: THREE.Vector3[],
        coreIndex: number,
        corePositions: THREE.Vector3[],
        interCoreLinks: number[][],
        qubitsPerCore: number,
        is3D: boolean
    ): void {
        const alignPairs: { localVec: THREE.Vector3; targetDir: THREE.Vector3 }[] = [];
        const thisCorePos = corePositions[coreIndex];

        if (!interCoreLinks) return;

        for (const link of interCoreLinks) {
            const q1 = link[0];
            const q2 = link[1];

            const c1 = Math.floor(q1 / qubitsPerCore);
            const c2 = Math.floor(q2 / qubitsPerCore);

            let localIndex = -1;
            let targetCorePos: THREE.Vector3 | null = null;

            if (c1 === coreIndex && c2 !== coreIndex) {
                localIndex = q1 % qubitsPerCore;
                targetCorePos = corePositions[c2];
            } else if (c2 === coreIndex && c1 !== coreIndex) {
                localIndex = q2 % qubitsPerCore;
                targetCorePos = corePositions[c1];
            }

            if (localIndex !== -1 && targetCorePos) {
                const localVec = localPos[localIndex].clone().normalize();
                const targetDir = new THREE.Vector3().subVectors(targetCorePos, thisCorePos).normalize();

                if (localVec.lengthSq() > 0.0001 && targetDir.lengthSq() > 0.0001) {
                    alignPairs.push({ localVec, targetDir });
                }
            }
        }

        if (alignPairs.length === 0) return;

        let sumA = 0;
        let sumB = 0;
        for (const pair of alignPairs) {
            const x = pair.localVec.x;
            const y = pair.localVec.y;
            const dx = pair.targetDir.x;
            const dy = pair.targetDir.y;
            sumA += x * dx + y * dy;
            sumB += x * dy - y * dx;
        }

        let theta = 0;
        if (sumA !== 0 || sumB !== 0) {
            theta = Math.atan2(sumB, sumA);
        }

        const qZ = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), theta);
        let finalQ = qZ.clone();

        if (is3D) {
            const firstLocal = alignPairs[0].localVec.clone().applyQuaternion(qZ);
            const firstTarget = alignPairs[0].targetDir;
            const qTilt = new THREE.Quaternion().setFromUnitVectors(firstLocal, firstTarget);
            finalQ = qTilt.multiply(qZ);
        }

        for (const pos of localPos) {
            pos.applyQuaternion(finalQ);
        }
    }

    /**
     * Dispose of the layout manager and clean up resources
     */
    dispose(): void {
        this.qubitPositions.clear();
    }
}

/**
 * Returns N core centre positions arranged as a regular N-gon.
 * The side length (centre-to-centre distance between adjacent cores) equals `d`.
 *
 *   N=1 → origin
 *   N=2 → (-d/2, 0, 0) and (+d/2, 0, 0)
 *   N≥3 → circumradius R = d / (2·sin(π/N)), vertices at (R·cos(2πk/N), R·sin(2πk/N), 0)
 */
function computePolygonCorePositions(n: number, d: number): THREE.Vector3[] {
    if (n === 1) return [new THREE.Vector3(0, 0, 0)];
    if (n === 2) return [new THREE.Vector3(-d / 2, 0, 0), new THREE.Vector3(d / 2, 0, 0)];
    const R = d / (2 * Math.sin(Math.PI / n));
    return Array.from({ length: n }, (_, k) => {
        const angle = (2 * Math.PI * k) / n;
        return new THREE.Vector3(R * Math.cos(angle), R * Math.sin(angle), 0);
    });
}
