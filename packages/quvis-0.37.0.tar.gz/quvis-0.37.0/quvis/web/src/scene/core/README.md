# LayoutManager Subsystem

The `LayoutManager` is responsible for orchestrating the spatial positioning of qubits within the 3D scene. It leverages `d3-force-3d` to execute high-performance, physics-based numerical simulations to calculate graph layouts for quantum topologies.

## Core Architectural Approaches

### 1. Velocity Verlet Integration & Planar Anchoring
Layout iterations rely on the `d3-force-3d` library's adaptation of the Velocity Verlet algorithm. To prevent topological collapse and dimensional buckling (where flat 2D lattices fold organically into the Z-axis due to geometric frustration), the manager explicitly restricts kinematic dimensions. 
For topologies inherently planar (e.g., Heavy-Hex grids), `.numDimensions(2)` is applied to force strict geometric compliance on the X and Y axes, while entirely precluding velocity leakage into the Z-dimension.

### 2. Peripheral Cushioning via `distanceMax`
Large quantum topologies suffer from the "Boundary Compression Effect" in force layouts, where the intense central radial push of massive structures crushes outermost nodes against global positioning constraints. `LayoutManager` circumvents this global ballooning by imposing a `.distanceMax()` cutoff equal to five times the ideal spring distance. This limits electrostatic Many-Body repulsions to the immediate topological neighborhoods instead of global aggregates.

### 3. Multilevel Core Synthesis (Polygon Layout)
For distributed quantum computing layouts involving multiple modular cores, the manager uses a deterministic polygon-based pipeline:

1. **Intra-Core Solidification**: The topology of each core is simulated in isolation (without external attractions), generating a stable, unstretched sub-graph.
2. **Bounding Radius Computation**: The maximum distance from the centroid to any qubit is computed across all cores.
3. **Polygon Vertex Placement**: Cores are placed at the vertices of a regular N-gon. The side length `d = 2 × maxBoundingRadius + interCoreSpacing` guarantees a fixed gap between core edges.
4. **Assembly**: Each core's local qubit positions are translated to their polygon vertex, producing a visually balanced multi-core layout.

> **Note:** `applyRigidBodyRotation` is implemented but not yet active. It will be called in a future step to orient communication qubits toward their target cores once inter-core connections are wired.
