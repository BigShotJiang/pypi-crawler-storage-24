export interface LayoutParameters {
    repelForce: number;
    idealDistance: number;
    iterations: number;
    coreDistance: number;
    attractForce: number;
    is3D: boolean;
    distanceMaxMultiplier: number;
}

export class LayoutParameterManager {
    private parameters: LayoutParameters;

    constructor(
        repelForce: number = 0.6,
        idealDistance: number = 1.0,
        iterations: number = 500,
        coreDistance: number = 5.0,
        attractForce: number = 0.1,
        is3D: boolean = false,
        distanceMaxMultiplier: number = 5.0,
    ) {
        this.parameters = {
            repelForce,
            idealDistance,
            iterations,
            coreDistance,
            attractForce,
            is3D,
            distanceMaxMultiplier,
        };
    }

    public getParameters(): LayoutParameters {
        return { ...this.parameters };
    }

    public updateParameters(
        params: Partial<LayoutParameters>,
    ): LayoutParameters {
        if (params.repelForce !== undefined) {
            this.parameters.repelForce = params.repelForce;
        }
        if (params.idealDistance !== undefined) {
            this.parameters.idealDistance = params.idealDistance;
        }
        if (params.iterations !== undefined) {
            this.parameters.iterations = params.iterations;
        }
        if (params.coreDistance !== undefined) {
            this.parameters.coreDistance = params.coreDistance;
        }
        if (params.attractForce !== undefined) {
            this.parameters.attractForce = params.attractForce;
        }
        if (params.is3D !== undefined) {
            this.parameters.is3D = params.is3D;
        }
        if (params.distanceMaxMultiplier !== undefined) {
            this.parameters.distanceMaxMultiplier = params.distanceMaxMultiplier;
        }
        return this.getParameters();
    }

    public getRepelForce(): number {
        return this.parameters.repelForce;
    }

    public getIdealDistance(): number {
        return this.parameters.idealDistance;
    }

    public getIterations(): number {
        return this.parameters.iterations;
    }

    public getAttractForce(): number {
        return this.parameters.attractForce;
    }

    public setRepelForce(value: number): void {
        this.parameters.repelForce = value;
    }

    public setIdealDistance(value: number): void {
        this.parameters.idealDistance = value;
    }

    public setIterations(value: number): void {
        this.parameters.iterations = value;
    }

    public setAttractForce(value: number): void {
        this.parameters.attractForce = value;
    }

    public getCoreDistance(): number {
        return this.parameters.coreDistance;
    }

    public setCoreDistance(value: number): void {
        this.parameters.coreDistance = value;
    }

    public getIs3D(): boolean {
        return this.parameters.is3D;
    }

    public setIs3D(value: boolean): void {
        this.parameters.is3D = value;
    }

    public getDistanceMaxMultiplier(): number {
        return this.parameters.distanceMaxMultiplier;
    }

    public setDistanceMaxMultiplier(value: number): void {
        this.parameters.distanceMaxMultiplier = value;
    }
}
