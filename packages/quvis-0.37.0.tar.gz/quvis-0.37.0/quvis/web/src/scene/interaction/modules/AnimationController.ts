import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { QubitGridController } from "../../objects/QubitGridController.js";
import type { DiffPanel, ViewportRect } from "../../core/DiffManager.js";

export class AnimationController {
    private animationFrameId: number | null = null;
    private currentFPS: number = 0;
    private lastFPSTime: number = 0;
    private frameCount: number = 0;
    private isRunning: boolean = false;

    private scene: THREE.Scene;
    private camera: THREE.PerspectiveCamera;
    private renderer: THREE.WebGLRenderer;
    private controls: OrbitControls;
    private grid!: QubitGridController;
    private diffPanels: DiffPanel[] = [];
    private viewportRects: ViewportRect[] = [];

    constructor(
        scene: THREE.Scene,
        camera: THREE.PerspectiveCamera,
        renderer: THREE.WebGLRenderer,
        controls: OrbitControls,
    ) {
        this.scene = scene;
        this.camera = camera;
        this.renderer = renderer;
        this.controls = controls;
    }

    public setGrid(grid: QubitGridController): void {
        this.grid = grid;
    }

    public setDiffPanels(panels: DiffPanel[], viewportRects: ViewportRect[]): void {
        this.diffPanels = panels;
        this.viewportRects = viewportRects;
    }

    public clearDiffPanels(): void {
        this.diffPanels = [];
        this.viewportRects = [];
    }

    public start(): void {
        if (!this.isRunning) {
            this.isRunning = true;
            this.animate();
        }
    }

    public stop(): void {
        this.isRunning = false;
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
    }

    public getCurrentFPS(): number {
        return this.currentFPS;
    }

    private animate(): void {
        if (!this.isRunning) return;

        this.animationFrameId = requestAnimationFrame(() => this.animate());

        // Update FPS counter
        this.updateFPS();

        // Update controls
        this.controls.update();

        if (this.diffPanels.length > 0) {
            this.renderDiffMode();
        } else {
            this.renderSingleMode();
        }
    }

    private renderSingleMode(): void {
        // LOD update based on camera distance
        const distance = this.controls.getDistance();
        this.grid.updateLOD(distance);

        // Update camera position uniform for heatmap shader
        if (this.grid.heatmap) {
            this.grid.heatmap.material.uniforms.cameraPosition.value.copy(
                this.camera.position,
            );
        }

        // Render heatmap if present (two-pass rendering)
        if (this.grid.heatmap) {
            // Temporarily remove heatmap mesh from scene to avoid double rendering
            const heatmapMesh = this.grid.heatmap.mesh;
            const wasInScene = heatmapMesh.parent === this.scene;
            if (wasInScene) {
                this.scene.remove(heatmapMesh);
            }

            // Render the main scene without heatmap
            this.renderer.render(this.scene, this.camera);

            // Render heatmap with two-pass system over the main scene
            this.grid.heatmap.render(this.renderer, this.scene);

            // Restore heatmap mesh to scene for other operations
            if (wasInScene) {
                this.scene.add(heatmapMesh);
            }
        } else {
            // Standard single-pass rendering when no heatmap
            this.renderer.render(this.scene, this.camera);
        }
    }

    private renderDiffMode(): void {
        const distance = this.controls.getDistance();

        // Enable scissor test for multi-viewport rendering
        this.renderer.setScissorTest(true);
        this.renderer.clear();

        for (let i = 0; i < this.diffPanels.length; i++) {
            const panel = this.diffPanels[i];
            const rect = this.viewportRects[i];

            // Set viewport and scissor to this panel's rect
            this.renderer.setViewport(rect.x, rect.y, rect.width, rect.height);
            this.renderer.setScissor(rect.x, rect.y, rect.width, rect.height);

            // Update camera aspect for this specific viewport to prevent distortion
            this.camera.aspect = rect.width / rect.height;
            this.camera.updateProjectionMatrix();

            // LOD update for this panel
            panel.grid.updateLOD(distance);

            // Update camera position uniform for heatmap shader
            if (panel.grid.heatmap) {
                panel.grid.heatmap.material.uniforms.cameraPosition.value.copy(
                    this.camera.position,
                );
            }

            // Render with two-pass heatmap if present
            if (panel.grid.heatmap) {
                const heatmapMesh = panel.grid.heatmap.mesh;
                const wasInScene = heatmapMesh.parent === panel.scene;
                if (wasInScene) {
                    panel.scene.remove(heatmapMesh);
                }

                this.renderer.render(panel.scene, this.camera);
                panel.grid.heatmap.render(this.renderer, panel.scene);

                if (wasInScene) {
                    panel.scene.add(heatmapMesh);
                }
            } else {
                this.renderer.render(panel.scene, this.camera);
            }
        }

        // Reset viewport to full canvas and disable scissor test
        const canvas = this.renderer.domElement;
        this.renderer.setViewport(0, 0, canvas.width, canvas.height);
        this.renderer.setScissorTest(false);

        // Restore camera aspect to full canvas
        this.camera.aspect = canvas.width / canvas.height;
        this.camera.updateProjectionMatrix();
    }

    private updateFPS(): void {
        const now = performance.now();
        this.frameCount++;
        if (now >= this.lastFPSTime + 1000) {
            this.currentFPS = this.frameCount;
            this.frameCount = 0;
            this.lastFPSTime = now;
        }
    }

    public dispose(): void {
        this.stop();
    }
}
