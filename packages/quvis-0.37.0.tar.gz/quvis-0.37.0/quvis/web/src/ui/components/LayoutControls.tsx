import React, { useState, useEffect } from "react";
import type { Playground } from "../../scene/Playground.js";
import { colors } from "../theme/colors.js";
import Slider from './Slider.js';

interface LayoutControlsProps {
    playground: Playground | null;
    initialValues: {
        repelForce: number;
        idealDistance: number;
        iterations: number;
        attractForce?: number;
        coreDistance?: number;
        is3D?: boolean;
        distanceMaxMultiplier?: number;
    };
    topPosition: string;
    setIsLoading: (loading: boolean) => void;
}

const basePanelStyle: React.CSSProperties = {
    position: "fixed",
    left: "10px",
    backgroundColor: colors.background.panel,
    padding: "15px",
    borderRadius: "8px",
    color: colors.text.primary,
    fontFamily: "Inter, system-ui, sans-serif",
    zIndex: 10,
    width: "250px",
    boxShadow: `0 2px 10px ${colors.shadow.light}`,
};

const headerStyle: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    borderBottom: `1px solid ${colors.border.separator}`,
    paddingBottom: "10px",
    marginBottom: "10px",
};

const headerTitleStyle: React.CSSProperties = {
    margin: "0",
    fontSize: "14px",
    fontWeight: 600,
    color: colors.text.primary,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
};

const controlGroupStyle: React.CSSProperties = {
    marginBottom: "15px",
};

const labelStyle: React.CSSProperties = {
    display: "block",
    marginBottom: "5px",
    fontSize: "0.9em",
};

const sliderContainerStyle: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    width: "100%",
};

const valueStyle: React.CSSProperties = {
    marginLeft: "10px",
    fontSize: "0.9em",
};

const buttonStyle: React.CSSProperties = {
    width: "100%",
    padding: "10px",
    backgroundColor: colors.primary.main,
    color: colors.text.primary,
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "1em",
    marginTop: "10px",
    transition: "all 0.2s ease",
};

const LayoutControls: React.FC<LayoutControlsProps> = ({
    playground,
    initialValues,
    topPosition,
    setIsLoading,
}) => {
    const [repelForce, setRepelForce] = useState(initialValues.repelForce);
    const [idealDistance, setIdealDistance] = useState(initialValues.idealDistance);
    const [iterations, setIterations] = useState(initialValues.iterations);
    const [attractForce, setAttractForce] = useState(initialValues.attractForce ?? 0.1);
    const [coreDistance, setCoreDistance] = useState(initialValues.coreDistance ?? 5.0);
    const [is3D, setIs3D] = useState(initialValues.is3D ?? false);
    const [distanceMaxMultiplier, setDistanceMaxMultiplier] = useState(
        initialValues.distanceMaxMultiplier ?? 5.0,
    );

    useEffect(() => {
        setRepelForce(initialValues.repelForce);
        setIdealDistance(initialValues.idealDistance);
        setIterations(initialValues.iterations);
        setAttractForce(initialValues.attractForce ?? 0.1);
        setCoreDistance(initialValues.coreDistance ?? 5.0);
    }, [initialValues]);

    const handleCoreDistanceChange = (value: number) => {
        setCoreDistance(value);
        if (playground) {
            playground.updateLayoutParameters({ coreDistance: value });
        }
    };

    const handleIs3DChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setIs3D(event.target.checked);
    };

    const handleDistanceMaxMultiplierChange = (value: number) => {
        setDistanceMaxMultiplier(value);
        if (playground) {
            playground.updateLayoutParameters({ distanceMaxMultiplier: value });
        }
    };

    const handleRepelForceChange = (value: number) => {
        setRepelForce(value);
        if (playground) {
            playground.updateLayoutParameters({ repelForce: value });
        }
    };

    const handleIdealDistanceChange = (value: number) => {
        setIdealDistance(value);
        if (playground) {
            playground.updateLayoutParameters({ idealDistance: value });
        }
    };

    const handleIterationsChange = (value: number) => {
        setIterations(value);
        if (playground) {
            playground.updateLayoutParameters({ iterations: value });
        }
    };

    const handleAttractForceChange = (value: number) => {
        setAttractForce(value);
        if (playground) {
            playground.updateLayoutParameters({ attractForce: value });
        }
    };

    const handleForceButtonClick = () => {
        const multiCore = playground?.isMultiCore() ?? false;
        if (multiCore) setIsLoading(true);

        playground?.updateLayoutParameters(
            {
                repelForce,
                idealDistance,
                iterations,
                attractForce,
                coreDistance,
                is3D,
                distanceMaxMultiplier,
            },
            () => {
                if (multiCore) setIsLoading(false);
            }
        );
    };

    const panelStyle: React.CSSProperties = {
        ...basePanelStyle,
        top: topPosition,
    };

    return (
        <div style={panelStyle}>
            <div style={headerStyle}>
                <h4 style={headerTitleStyle}>Layout Controls</h4>
            </div>

            <div style={{ maxHeight: "60vh", overflowY: "auto", overflowX: "hidden", paddingRight: "5px" }}>
                <div style={controlGroupStyle}>
                    <label htmlFor="core-distance" style={labelStyle}>Core Distance</label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            id="core-distance"
                            min={1.0}
                            max={500}
                            step={0.5}
                            value={coreDistance}
                            onChange={handleCoreDistanceChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={1}
                            inputWidth="50px"
                        />
                    </div>
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="is-3d" style={{ ...labelStyle, display: "flex", alignItems: "center" }}>
                        <input
                            type="checkbox"
                            id="is-3d"
                            checked={is3D}
                            onChange={handleIs3DChange}
                            style={{ marginRight: "10px", cursor: "pointer" }}
                        />
                        Enable 3D Layout
                    </label>
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="distance-max-multiplier" style={labelStyle}>Repulsion Max Distance</label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            id="distance-max-multiplier"
                            min={1.0}
                            max={20.0}
                            step={0.5}
                            value={distanceMaxMultiplier}
                            onChange={handleDistanceMaxMultiplierChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={1}
                            inputWidth="50px"
                        />
                    </div>
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="repel-force" style={labelStyle}>Repel Force</label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            id="repel-force"
                            min={0.1}
                            max={2.0}
                            step={0.01}
                            value={repelForce}
                            onChange={handleRepelForceChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={2}
                            inputWidth="50px"
                        />
                    </div>
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="ideal-distance" style={labelStyle}>Ideal Distance</label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            id="ideal-distance"
                            min={1.0}
                            max={10.0}
                            step={0.5}
                            value={idealDistance}
                            onChange={handleIdealDistanceChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={1}
                            inputWidth="50px"
                        />
                    </div>
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="iterations" style={labelStyle}>Iterations</label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            id="iterations"
                            min={100}
                            max={20000}
                            step={100}
                            value={iterations}
                            onChange={handleIterationsChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={0}
                            inputWidth="50px"
                        />
                    </div>
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="attract-force" style={labelStyle}>Attract Force</label>
                    <div style={sliderContainerStyle}>
                        <Slider
                            id="attract-force"
                            min={0}
                            max={1}
                            step={0.001}
                            value={attractForce}
                            onChange={handleAttractForceChange}
                            style={{ flex: 1 }}
                            showInput
                            precision={3}
                            inputWidth="50px"
                        />
                    </div>
                </div>

                <div style={controlGroupStyle}>
                    <button style={buttonStyle} onClick={handleForceButtonClick}>
                        Apply Force Layout
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LayoutControls;
