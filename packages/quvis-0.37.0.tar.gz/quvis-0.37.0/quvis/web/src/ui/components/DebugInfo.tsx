import React from "react";
import { colors } from "../theme/colors.js";

interface DebugInfoProps {
    fps: number;
    layoutTime: number;
    bottomPosition?: string;  // kept for backwards compat, no longer used
}

const DebugInfo: React.FC<DebugInfoProps> = ({ fps, layoutTime, bottomPosition }) => {
    const containerStyle: React.CSSProperties = {
        position: "fixed",
        bottom: "10px",
        right: "290px",   // sits just to the left of PlaybackControls (250px + 20px margin + 20px gap)
        width: "120px",
        padding: "10px 14px",
        boxSizing: "border-box",
        zIndex: 10,
        backgroundColor: colors.background.panel,
        borderRadius: "8px",
        color: colors.text.primary,
        fontFamily: "Arial, sans-serif",
    };

    const titleStyle: React.CSSProperties = {
        textAlign: "center",
        fontWeight: "bold",
        marginBottom: "10px",
    };

    const infoStyle: React.CSSProperties = {
        fontSize: "0.9em",
        lineHeight: "1.5",
    };

    return (
        <div style={containerStyle}>
            <div style={titleStyle}>Debug Info</div>
            <div style={infoStyle}>
                <div>FPS: {fps.toFixed(1)}</div>
                {layoutTime > 0 && (
                    <div>Last layout time: {layoutTime.toFixed(2)} ms</div>
                )}
            </div>
        </div>
    );
};

export default DebugInfo;
