import React from 'react';
import RCSlider from 'rc-slider';
import 'rc-slider/assets/index.css';
import { colors } from '../theme/colors.js';
import { Play, Pause } from 'lucide-react';

interface PlaybackControlsProps {
    isPlaying: boolean;
    onPlayPause: () => void;
    speed: number;
    onSpeedChange: (speed: number) => void;
    disabled: boolean;
    isAtEnd: boolean;
}

// Determine the actual slider component, trying to access .default for CJS/ESM interop
const defaultSliderExport = (
    RCSlider as unknown as { default?: React.ElementType }
).default;
const ActualSlider: React.ElementType =
    defaultSliderExport || (RCSlider as unknown as React.ElementType);

const PlaybackControls: React.FC<PlaybackControlsProps> = ({
    isPlaying,
    onPlayPause,
    speed,
    onSpeedChange,
    disabled,
    isAtEnd,
}) => {
    const containerStyle: React.CSSProperties = {
        position: 'fixed',
        bottom: '10px',
        right: '10px',
        width: '250px',
        height: '48px',
        padding: '0 12px',
        display: 'flex',
        alignItems: 'center',
        boxSizing: 'border-box',
        zIndex: 10,
        backgroundColor: colors.background.panel,
        borderRadius: '8px',
        boxShadow: `0 2px 10px ${colors.shadow.light}`,
        color: colors.text.primary,
        fontFamily: 'Inter, system-ui, sans-serif',
        transition: 'all 0.3s ease',
    };

    const buttonStyle: React.CSSProperties = {
        background: colors.background.panelSolid,
        color: colors.text.primary,
        border: `1px solid ${colors.border.light}`,
        borderRadius: '4px',
        padding: '6px',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minWidth: '32px',
        minHeight: '32px',
        transition: 'all 0.2s ease',
    };

    const disabledButtonStyle: React.CSSProperties = {
        ...buttonStyle,
        opacity: 0.5,
        cursor: 'not-allowed',
    };

    const sliderLabelStyle: React.CSSProperties = {
        fontSize: '0.75em',
        fontWeight: 500,
        color: colors.text.primary,
        whiteSpace: 'nowrap',
    };

    return (
        <div style={containerStyle}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', width: '100%' }}>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                    <div style={sliderLabelStyle}>
                        Speed:{' '}
                        {speed >= 0.001
                            ? `${(speed * 1000).toFixed(0)}ms`
                            : speed >= 0.000001
                                ? `${(speed * 1000000).toFixed(0)}μs`
                                : `${(speed * 1000000).toFixed(1)}μs`}
                    </div>
                    <ActualSlider
                        min={0.0000001}
                        max={0.1}
                        step={0.000001}
                        value={speed}
                        onChange={(value: number) => onSpeedChange(value)}
                        disabled={disabled}
                        trackStyle={{
                            backgroundColor: colors.primary.main,
                            height: 4,
                        }}
                        railStyle={{
                            backgroundColor: colors.ui.border,
                            height: 4,
                        }}
                        handleStyle={{
                            borderColor: colors.primary.main,
                            backgroundColor: colors.primary.main,
                            width: 16,
                            height: 16,
                            marginTop: -6,
                            marginLeft: -8,
                            opacity: disabled ? 0.5 : 1,
                            zIndex: 2,
                            cursor: disabled ? 'not-allowed' : 'pointer',
                        }}
                    />
                </div>
                <button
                    onClick={onPlayPause}
                    disabled={disabled || isAtEnd}
                    style={
                        disabled || isAtEnd
                            ? disabledButtonStyle
                            : buttonStyle
                    }
                >
                    {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                </button>
            </div>
        </div>
    );
};

export default PlaybackControls;