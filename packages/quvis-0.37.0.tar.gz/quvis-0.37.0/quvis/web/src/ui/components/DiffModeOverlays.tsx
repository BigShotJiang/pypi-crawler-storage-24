import React from 'react';
import { colors } from '../theme/colors.js';

interface CircuitInfo {
    algorithm_name: string;
    circuit_type: 'logical' | 'compiled';
    circuit_stats: {
        original_gates?: number;
        transpiled_gates?: number;
        depth: number;
        qubits: number;
        swap_count?: number;
    };
}

interface DiffModeOverlaysProps {
    circuits: CircuitInfo[];
    selectedCircuitIndices: number[];
}

const DiffModeOverlays: React.FC<DiffModeOverlaysProps> = ({ circuits, selectedCircuitIndices }) => {
    if (selectedCircuitIndices.length < 2) return null;

    const viewportWidth = 100 / selectedCircuitIndices.length;

    const formatCircuitInfo = (circuit: CircuitInfo): string => {
        const stats = circuit.circuit_stats;
        const parts = [`${stats.qubits}Q`, `${stats.depth}D`];

        if (
            circuit.circuit_type === 'compiled' &&
            stats.swap_count !== undefined
        ) {
            parts.push(`${stats.swap_count}S`);
        }

        return parts.join(' • ');
    };

    const typeIndicatorStyle = (
        type: 'logical' | 'compiled'
    ): React.CSSProperties => ({
        fontSize: '10px',
        fontWeight: 600,
        textTransform: 'uppercase',
        letterSpacing: '0.5px',
        color:
            type === 'logical'
                ? colors.circuit.logical
                : colors.circuit.compiled,
        backgroundColor:
            type === 'logical'
                ? `${colors.circuit.logical}20`
                : `${colors.circuit.compiled}20`,
        padding: '2px 6px',
        borderRadius: '3px',
        marginTop: '2px',
        alignSelf: 'center',
    });

    const cardStyle: React.CSSProperties = {
        padding: '8px 12px',
        borderRadius: '4px',
        border: '1px solid ' + colors.ui.border,
        backgroundColor: colors.ui.surface,
        color: colors.text.primary,
        fontSize: '13px',
        fontWeight: 600,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '4px',
        textAlign: 'center',
        minWidth: '120px',
        pointerEvents: 'none',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)', // A slight shadow helps it pop off the 3d canvas
    };

    return (
        <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 10 }}>
            {selectedCircuitIndices.map((circuitIndex, i) => {
                const circuit = circuits[circuitIndex];
                if (!circuit) return null;

                const leftPos = i * viewportWidth;

                return (
                    <React.Fragment key={`diff-overlay-${circuitIndex}`}>
                        {/* The Overlay Card */}
                        <div style={{
                            position: 'absolute',
                            top: '80px', // Give it some padding below the circuit tabs
                            left: `calc(${leftPos}vw + ${viewportWidth / 2}vw)`,
                            transform: 'translateX(-50%)',
                            pointerEvents: 'auto',
                        }}>
                            <div style={cardStyle}>
                                <span style={typeIndicatorStyle(circuit.circuit_type)}>
                                    {circuit.circuit_type}
                                </span>
                                <span style={{
                                    fontSize: '13px',
                                    fontWeight: 500,
                                    lineHeight: '16px',
                                }}>
                                    {circuit.algorithm_name}
                                </span>
                                <span style={{
                                    fontSize: '11px',
                                    opacity: 0.8,
                                    lineHeight: '14px',
                                    fontWeight: 400
                                }}>
                                    {formatCircuitInfo(circuit)}
                                </span>
                            </div>
                        </div>

                        {/* The Separator Line (Rendered for all except the first one) */}
                        {i > 0 && (
                            <div style={{
                                position: 'absolute',
                                left: `${leftPos}vw`,
                                top: 0,
                                bottom: 0,
                                width: '2px',
                                backgroundColor: colors.ui.border,
                                zIndex: 5,
                                opacity: 0.5, // Make line softly blend into the background
                            }} />
                        )}
                    </React.Fragment>
                );
            })}
        </div>
    );
};

export default DiffModeOverlays;
