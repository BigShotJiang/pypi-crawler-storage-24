import React, { useState, useEffect, useRef } from 'react';
import RCSlider from 'rc-slider';
import 'rc-slider/assets/index.css';
import { colors } from '../theme/colors.js';
import './Slider.css';

/**
 * Determine the actual slider component for CJS/ESM interop.
 * Some environments might wrap the default export in a .default property.
 */
const defaultSliderExport = (
    RCSlider as unknown as { default?: React.ElementType }
).default;

const ActualSlider: React.ElementType =
    defaultSliderExport || (RCSlider as unknown as React.ElementType);

export interface SliderProps {
    /** Minimum value of the slider */
    min: number;
    /** Maximum value of the slider */
    max: number;
    /** The granularity of the slider */
    step?: number;
    /** Current value of the slider */
    value: number;
    /** Callback when value changes */
    onChange: (value: number) => void;
    /** Whether the slider is disabled */
    disabled?: boolean;
    /** Optional container style overrides */
    style?: React.CSSProperties;
    /** Custom color for the active track */
    trackColor?: string;
    /** Custom color for the slider handle */
    handleColor?: string;
    /** Custom color for the inactive rail */
    railColor?: string;
    /** Optional HTML ID for the container */
    id?: string;
    /** Whether to show a numeric input box */
    showInput?: boolean;
    /** Decimal places for formatting */
    precision?: number;
    /** Width of the numeric input box */
    inputWidth?: string;
}

/**
 * A unified, styled Slider component based on rc-slider.
 * This component abstracts the project's consensus on slider aesthetics
 * and optional integrated numeric input.
 */
const Slider: React.FC<SliderProps> = ({
    min,
    max,
    step,
    value,
    onChange,
    disabled = false,
    style,
    trackColor = colors.primary.main,
    handleColor = colors.primary.main,
    railColor = colors.ui.border,
    id,
    showInput = false,
    precision = 0,
    inputWidth = '50px',
}) => {
    // Format helper to support "All" for -1
    const formatValue = (val: number) => {
        if (val === -1) return 'All';
        return val.toFixed(precision);
    };

    // String state for fluid typing
    const [localInput, setLocalInput] = useState(formatValue(value));
    const [isFocused, setIsFocused] = useState(false);

    // Sync input string when parent value changes (unless we are typing)
    useEffect(() => {
        if (!isFocused) {
            setLocalInput(formatValue(value));
        } else {
            // Even if focused, if the numeric difference is large enough, we should sync
            // This handles external resets or large jumps while the user happens to have focus
            const numLocal = parseFloat(localInput);
            if (numLocal === -1 && value === -1) return; // Both are 'All'

            if (!isNaN(numLocal) && Math.abs(numLocal - value) > (step || 0.001)) {
                setLocalInput(formatValue(value));
            }
        }
    }, [value, precision, isFocused]);

    const handleSliderChange = (val: number | number[]) => {
        const numValue = typeof val === 'number' ? val : val[0];
        onChange(numValue);
        // Sync input immediately when sliding
        if (!isFocused) {
            setLocalInput(formatValue(numValue));
        }
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setLocalInput(e.target.value);
    };

    const handleInputBlurOrEnter = () => {
        setIsFocused(false);
        const text = localInput.trim();

        if (text.toLowerCase() === 'all') {
            onChange(-1);
            setLocalInput('All');
            return;
        }

        let numValue = parseFloat(text);

        if (isNaN(numValue)) {
            setLocalInput(formatValue(value));
            return;
        }

        // Snap to boundaries
        numValue = Math.max(min, Math.min(max, numValue));

        // Notify parent if changed
        if (numValue !== value) {
            onChange(numValue);
        }

        // Always refresh the local input text to the formatted/clamped version
        setLocalInput(formatValue(numValue));
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleInputBlurOrEnter();
            (e.target as HTMLInputElement).blur();
        } else if (e.key === 'Escape') {
            setIsFocused(false);
            setLocalInput(formatValue(value));
            (e.target as HTMLInputElement).blur();
        }
    };

    const sliderElement = (
        <ActualSlider
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={handleSliderChange}
            disabled={disabled}
            trackStyle={{ backgroundColor: trackColor, height: 4 }}
            railStyle={{ backgroundColor: railColor, height: 4 }}
            handleStyle={{
                borderColor: handleColor,
                backgroundColor: handleColor,
                width: 16,
                height: 16,
                marginTop: -6,
                marginLeft: -8,
                opacity: disabled ? 0.5 : 1,
                zIndex: 2,
                cursor: disabled ? 'not-allowed' : 'pointer',
            }}
        />
    );

    return (
        <div
            className="quvis-slider-container"
            style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '4px 0',
                width: '100%',
                ...style
            }}
            id={id}
        >
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', padding: '0 8px' }}>
                {sliderElement}
            </div>

            {showInput && (
                <input
                    type="text"
                    inputMode="decimal"
                    className="quvis-slider-input"
                    value={localInput}
                    onChange={handleInputChange}
                    onBlur={handleInputBlurOrEnter}
                    onFocus={() => { setIsFocused(true); }}
                    onKeyDown={handleKeyDown}
                    disabled={disabled}
                    style={{
                        width: inputWidth,
                        backgroundColor: colors.background.main,
                        color: colors.text.primary,
                        border: `1px solid ${colors.border.main}`,
                        borderRadius: '4px',
                        padding: '4px 6px',
                        fontSize: '0.85em',
                        textAlign: 'center',
                        outline: 'none',
                        transition: 'border-color 0.2s ease',
                    }}
                />
            )}
        </div>
    );
};

export default Slider;
