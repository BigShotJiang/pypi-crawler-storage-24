import requests

class Channel:
    def __init__(self, channel_id: str, bot):
        self.id = channel_id
        self.bot = bot

    def send(self, content: str):
        url = f"{self.bot.api_base}/api/bot/messages/send"
        payload = {"channelId": self.id, "content": content}
        return requests.post(url, headers=self.bot._headers(), json=payload).json()


class Message:
    def __init__(self, content: str, channel_id: str, bot):
        self.content = content
        self.channel = Channel(channel_id, bot)

    @classmethod
    def from_data(cls, data: dict, bot):
        content = data.get("content") or ""
        channel_id = data.get("channelId") or ""
        return cls(content, channel_id, bot)