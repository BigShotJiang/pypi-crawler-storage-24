from setuptools import setup, find_packages

setup(
    name="maxrealmconnect.py",
    version="0.1.0",
    description="Python library for making bots on MaxRealm Connect",
    author="Max",
    packages=find_packages(),
    install_requires=[
        "requests",
        "websockets",
    ],
    python_requires=">=3.10",
)