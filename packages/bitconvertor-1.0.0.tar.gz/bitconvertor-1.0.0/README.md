<h3>Here is the code for BitConvertor, a simple library made with Python for Python to convert between strings, decimal values, binary values and hexadecimal values.
<br>

<hr style="height:2px; background-color:gray; border:none;">
<br>

<h4>Import :</h4>
To use the library in your script, you have to import it with this Python instruction :
<br><br>

```Python
from bitconvertor import *
```
<br>

<hr style="height:2px; background-color:gray; border:none;">
<br>

<h4>Convert decimal into... :</h4>
<br>

- Binary :<br><br>
  ```Python
  decimal_to_binary(integer_value)
  ```
  Exemple :
  ```Python
  binary_value = decimal_to_binary(1234)      # binary_value = 00000100 11010010
  ```
  <br>
- Hexadecimal :<br><br>
  ```Python
  decimal_to_hexadecimal(integer_value)
  ```
  Exemple :
  ```Python
  hexadecimal_value = decimal_to_hexadecimal(1234)      # hexadecimal_value = 00000100 11010010
  ```
  <br>
- Character :<br><br>
  ```Python
  decimal_to_character(integer_value)
  ```
  Exemple :
  ```Python
  character_value = decimal_to_character(65)      # character_value = 'A'
  ```
  <br>
- String :<br><br>
  ```Python
  decimal_to_string(string_value)
  ```
  Exemple :
  ```Python
  string_value = decimal_to_string("66 111 110 106 111 117 114")      # string_value = "Bonjour"
  ```

<hr style="height:2px; background-color:gray; border:none;">
<br>

<h4>Convert binary into... :</h4>
<br>

- Decimal :<br><br>
  ```Python
  binary_to_decimal(string_value)
  ```
  Exemple :
  ```Python
  decimal_value = binary_to_decimal("0000010011010010")      # decimal_value = 1234
  ```
  <br>
- Hexadecimal :<br><br>
  ```Python
  binary_to_hexadecimal(string_value)
  ```
  Exemple :
  ```Python
  hexadecimal_value = binary_to_hexadecimal("0000010011010010")      # hexadecimal_value = 04 D2
  ```
  <br>
- Character :<br><br>
  ```Python
  binary_to_char(string_value)
  ```
  Exemple :
  ```Python
  character_value = binary_to_char("01000010")      # character_value = 'B'
  ```
  <br>
- String :<br><br>
  ```Python
  binary_to_string(string_value)
  ```
  Exemple :
  ```Python
  string_value = binary_to_string("01000010 01101111 01101110 01101010 01101111 01110101 01110010")      # string_value = "Bonjour"
  ```
<br>

<hr style="height:2px; background-color:gray; border:none;">
<br>

<h4>Convert hexadecimal into... :</h4>
<br>

- Decimal :<br><br>
  ```Python
  hexadecimal_to_decimal(string_value)
  ```
  Exemple :
  ```Python
  decimal_value = hexadecimal_to_decimal("04 D2")      # decimal_value = 1234
  ```
  <br>
- Binary :<br><br>
  ```Python
  hexadecimal_to_binary(string_value)
  ```
  Exemple :
  ```Python
  binary_value = hexadecimal_to_binary("04 D2")      # binary_value = 0000010011010010
  ```
  <br>
- Character :<br><br>
  ```Python
  hexadecimal_to_char(string_value)
  ```
  Exemple :
  ```Python
  character_value = hexadecimal_to_char("41")      # character_value = 'A'
  ```
  <br>
- String :<br><br>
  ```Python
  hexadecimal_to_string(string_value)
  ```
  Exemple :
  ```Python
  string_value = hexadecimal_to_string("42 6F 6E 6A 6F 75 72")      # string_value = "Bonjour"
  ```
<br>

<hr style="height:2px; background-color:gray; border:none;">
<br>

<h4>Convert character into... :</h4>
<br>

- Decimal :<br><br>
  ```Python
  char_to_decimal(character_value)
  ```
  Exemple :
  ```Python
  decimal_value = char_to_decimal('A')      # decimal_value = 65
  ```
  <br>
- Binary :<br><br>
  ```Python
  char_to_binary(character_value)
  ```
  Exemple :
  ```Python
  binary_value = char_to_binary('A')      # binary_value = 01000001
  ```
  <br>
- Hexadecimal :<br><br>
  ```Python
  char_to_hexadecimal(character_value)
  ```
  Exemple :
  ```Python
  hexadecimal_value = char_to_hexadecimal('A')      # hexadecimal_value = 41
  ```
<br>

<hr style="height:2px; background-color:gray; border:none;">
<br>

<h4>Convert string into... :</h4>
<br>

- Decimal :<br><br>
  ```Python
  string_to_decimal(string_value)
  ```
  Exemple :
  ```Python
  decimal_value = string_to_decimal("Bonjour")      # decimal_value = "66 111 110 106 111 117 114"
  ```
  <br>
- Binary :<br><br>
  ```Python
  string_to_binary(string_value)
  ```
  Exemple :
  ```Python
  binary_value = string_to_binary("Bonjour")      # binary_value = "01000010 01101111 01101110 01101010 01101111 01110101 01110010"
  ```
  <br>
- Hexadecimal :<br><br>
  ```Python
  string_to_hexadecimal(string_value)
  ```
  Exemple :
  ```Python
  hexadecimal_value = string_to_hexadecimal("Bonjour")      # hexadecimal_value = "42 6F 6E 6A 6F 75 72"
  ```
