"""Hardcoding detection patterns."""
import re

HARDCODING_PATTERNS = [
    (r'["\'][0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}["\']', "Hardcoded GUID"),
    (r'["\']https?://(?!schema\.org|api\.fabric\.microsoft\.com)[^"\']+(["\'])', "Hardcoded URL"),
    (r'["\'][A-Za-z]:\\[^"\']+(["\'])', "Hardcoded Windows path"),
    (r'["\']abfss?://[^"\']+(["\'])', "Hardcoded ABFS path"),
    (r'(?:Password|Pwd)=[^;\s]+', "Hardcoded password"),
    (r'(?:api[_-]?key|secret|token)\s*=\s*["\'][^"\']+["\']', "Hardcoded credential"),
    (r'["\'](?:19|20)\d{2}[-/](?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12]\d|3[01])["\']', "Hardcoded date"),
    (r'["\'](?:FY|CY)[-]?\d{2,4}["\']', "Hardcoded fiscal year"),
    (r'\.filter\s*\([^)]*==\s*["\'][^"\']+["\']', "Hardcoded filter"),
    (r'\.where\s*\([^)]*==\s*["\'][^"\']+["\']', "Hardcoded where"),
    (r'\.isin\s*\(\s*\[[^\]]*["\'][^"\']+["\']', "Hardcoded isin"),
    (r'\.when\s*\([^)]*==\s*["\'][^"\']+["\']', "Hardcoded when"),
    (r'lit\s*\(\s*["\'][^"\']+["\']\s*\)', "Hardcoded literal"),
    (r'\.like\s*\(\s*["\'][^"\']+["\']', "Hardcoded like"),
    (r'\.contains\s*\(\s*["\'][^"\']+["\']', "Hardcoded contains"),
    (r'\.fillna\s*\(\s*["\'][^"\']+["\']', "Hardcoded fillna"),
    (r'\.startswith\s*\(\s*["\'][^"\']+["\']', "Hardcoded startswith"),
    (r'\.endswith\s*\(\s*["\'][^"\']+["\']', "Hardcoded endswith"),
]

COMPILED_PATTERNS = []
for p, d in HARDCODING_PATTERNS:
    try:
        COMPILED_PATTERNS.append((re.compile(p, re.IGNORECASE), d))
    except re.error:
        pass
