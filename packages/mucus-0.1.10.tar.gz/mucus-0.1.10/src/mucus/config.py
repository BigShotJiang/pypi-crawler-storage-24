import pathlib
import yaml


def path(filename='config.yaml'):
    return pathlib.Path().home().joinpath('.config', 'mucus', filename)


def dump(config):
    try:
        with path().open('w') as f:
            yaml.dump(config, f)
    except FileNotFoundError:
        return {}


def load():
    try:
        with path().open('r') as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        return {}
