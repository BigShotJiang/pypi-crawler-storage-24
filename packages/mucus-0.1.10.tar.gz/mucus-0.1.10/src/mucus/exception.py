class MucusException(Exception):
    pass


class Exit(MucusException):
    pass


class CommandException(MucusException):
    pass


class MucusError(MucusException):
    def __str__(self):
        return ': '.join((self.__doc__ or self.__class__.__name__, self.args.join('; ')))


class NoSuchCommand(MucusError):
    '''no such command'''


class SoxNotInstalled(MucusError):
    '''SoX is not installed'''


class DeezerError(MucusError):
    pass


class DeezerAuthError(DeezerError):
    pass


class DeezerStreamError(DeezerError):
    pass


class NoMedia(DeezerError):
    pass


class NoSource(DeezerError):
    pass
