# ast-ai 🚀

`ast-ai` is a CLI tool designed to scan your projects and compress their Abstract Syntax Tree (AST) to send it more efficiently into the context of LLMs (Large Language Models).

It supports multiple languages (Python, JavaScript, TypeScript, Java, PHP, HTML, JSON, Bash) and uses incremental caching for optimal performance.

## 📦 Installation

### Recommended: via pipx (Global)

To install `ast-ai` globally and use it in any project without polluting your Python environment:

```bash
# From the GitLab repository (replace with the actual URL)
pipx install git+https://gitlab.com/your-org/ast-ai.git

# OR from the GitLab package registry (if published)
pipx install --index-url https://gitlab.com/api/v4/projects/YOUR_PROJECT_ID/packages/pypi/simple ast-ai
```

### For Development (Local)

If you wish to contribute to the project:

```bash
git clone https://gitlab.com/your-org/ast-ai.git
cd ast-ai
make install-dev
source .venv/bin/activate
```

## 🛠 Usage

Once installed, the `ast-ai` command is available everywhere.

### 1. Scan a project
Scans the current directory and generates the AST cache:
```bash
ast-ai scan
```

Useful options:
- `ast-ai scan --skeleton`: Generates a "skeleton" version (truncates the body of functions/methods).
- `ast-ai scan -e vendor -e node_modules`: Excludes specific directories.

### 2. Retrieve the AST of a file
Displays the compressed AST in JSON format for a specific file:
```bash
ast-ai get src/main.py
```

### 3. Clear the cache
```bash
ast-ai clear
```

## 📂 Project Structure

- `src/ast_ai/`: Main source code.
- `.ast_cache/`: Locally generated directory to store the cache (ignored by git).
- `docs/`: Detailed documentation and tutorials.
- `Makefile`: Useful commands for development.

## 🤝 Development

The project uses a `Makefile` to simplify common tasks:

- `make install-dev`: Prepares the development environment.
- `make lint`: Checks code quality.
- `make test`: Runs the test suite.
- `make build`: Prepares the package for distribution.
- `make clean`: Cleans up temporary files and the virtual environment.

---
Developed with ❤️ to optimize your LLM contexts.
