import sys
from pathlib import Path
from typing import Dict, Any, List

def load_config(project_root: Path) -> Dict[str, Any]:
    """
    Loads configuration from pyproject.toml or .astcleaner.toml.
    """
    config = {
        "exclude": [],
        "skeleton": False
    }

    # Try pyproject.toml first
    pyproject_path = project_root / "pyproject.toml"
    if pyproject_path.exists():
        parsed = _parse_toml(pyproject_path)
        if parsed and "tool" in parsed and "ast-ai" in parsed["tool"]:
            tool_config = parsed["tool"]["ast-ai"]
            config.update(tool_config)
            return config

    # Try .astcleaner.toml
    config_path = project_root / ".astcleaner.toml"
    if config_path.exists():
        parsed = _parse_toml(config_path)
        if parsed:
            config.update(parsed)
            return config

    return config

def _parse_toml(path: Path) -> Dict[str, Any]:
    try:
        if sys.version_info >= (3, 11):
            import tomllib
            with open(path, "rb") as f:
                return tomllib.load(f)
        else:
            import tomli
            with open(path, "rb") as f:
                return tomli.load(f)
    except (ImportError, Exception):
        return {}
