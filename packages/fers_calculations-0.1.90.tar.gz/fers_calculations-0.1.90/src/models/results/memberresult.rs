use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::models::results::forces::{NodeForces, SectionForce};

#[derive(Serialize, Deserialize, ToSchema, Debug, Clone)]
pub struct MemberResult {
    pub start_node_forces: NodeForces,
    pub end_node_forces: NodeForces,
    pub maximums: NodeForces,
    pub minimums: NodeForces,
    pub local_start_forces: NodeForces,
    pub local_end_forces: NodeForces,
    pub local_maximums: NodeForces,
    pub local_minimums: NodeForces,
    pub section_forces: Vec<SectionForce>,
}
