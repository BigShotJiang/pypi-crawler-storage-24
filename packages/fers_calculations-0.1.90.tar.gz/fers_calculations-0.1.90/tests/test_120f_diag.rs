use fers_calculations::analysis::calculate_from_json_internal;

#[test]
fn test_120f_combo_member23_vy() {
    let _ = env_logger::builder().is_test(true).try_init();
    
    let json_str = std::fs::read_to_string(concat!(
        env!("CARGO_MANIFEST_DIR"), "/tests/_test_cantileverrack.json"
    )).unwrap();
    
    let mut data: serde_json::Value = serde_json::from_str(&json_str).unwrap();
    data["settings"]["analysis_options"]["order"] = serde_json::json!("Nonlinear");
    data["settings"]["analysis_options"]["nonlinear_method"] = serde_json::json!("P_Delta");
    data["settings"]["analysis_options"]["axial_slack"] = serde_json::json!(0.001);
    
    // Keep only combo 1 for speed
    if let Some(combos) = data["load_combinations"].as_array() {
        let keep: Vec<serde_json::Value> = combos.iter()
            .filter(|c| c["id"].as_u64() == Some(1))
            .cloned().collect();
        data["load_combinations"] = serde_json::json!(keep);
    }
    
    let result_str = calculate_from_json_internal(&data.to_string()).unwrap();
    let result: serde_json::Value = serde_json::from_str(&result_str).unwrap();
    
    // Find first loadcombination result
    if let Some(combos) = result["results"]["loadcombinations"].as_object() {
        for (name, lc) in combos {
            println!("Combo: {}", name);
            for mid in ["23", "24"] {
                let mr = &lc["member_results"][mid];
                let fx = mr["start_node_forces"]["fx"].as_f64().unwrap();
                let active = fx.abs() > 0.01;
                println!("  m{}: active={}, local_fx={}, local_fy={}",
                    mid, active,
                    mr["local_start_forces"]["fx"],
                    mr["local_start_forces"]["fy"]);
                println!("    global start: fx={}, fy={}, fz={}",
                    mr["start_node_forces"]["fx"],
                    mr["start_node_forces"]["fy"],
                    mr["start_node_forces"]["fz"]);
            }
        }
    }
}
