# tokopedia-client-mcp-server

A **Model Context Protocol (MCP)** server that gives AI assistants (Claude,
GPT-4, etc.) direct access to Tokopedia — Indonesia's largest e-commerce
marketplace — so they can search products, read descriptions, analyse reviews,
and download review photos/videos to recommend the best products.

<!-- mcp-name: io.github.its-benjamin/tokopedia-unofficial-mcp-server -->

---

## Disclaimer And Responsible Use

- This project is an independent, unofficial integration and is not affiliated with, endorsed by, or sponsored by Tokopedia.
- "Tokopedia" and related marks are trademarks of their respective owners.
- Users are responsible for complying with Tokopedia Terms of Service, robots/policy constraints, and applicable law in their jurisdiction.
- Do not use this project to scrape protected/private data, bypass access controls, or automate abusive traffic.
- Do not commit personal credentials, cookies, HAR captures, or other sensitive browsing artifacts to this repository.

## Private Reporting Policy

- Please report security issues privately and do not open public issues for active vulnerabilities.
- Preferred channel: open a private security advisory in this repository.
- Rights-holder, abuse, or policy concerns should use the same private channel.
- Include links, impact, and reproduction details so triage can be done quickly.
- Response targets: initial acknowledgment within 72 hours and triage update within 7 days.

---

## Features

| Tool | What it does |
|---|---|
| `search_products` | Search by keyword with sorting (best match, price, sales, reviews); image URLs are optional |
| `get_product_detail` | Description, specs, rating, sold count by product URL; media is optional |
| `get_product_reviews` | Paginated buyer reviews in a compact AI-friendly shape; low-signal arrival/packing reviews are filtered by default and review media is optional |
| `get_shop_info` | Seller profile, location, official-badge status, transaction stats |
| `get_review_media` | Collect image & video URLs posted in buyer reviews |
| `download_media` | Fetch any image/video as base64 for the AI to view or analyse |
| `generate_login_qr` | Start Tokopedia QR login and return image data plus terminal-safe fallback |
| `check_qr_login_status` | Poll QR login approval status |

---

## Requirements

- Python ≥ 3.11
- Internet access to `gql.tokopedia.com`
- Live QR login requires the optional QR extra plus Playwright Firefox runtime: `pip install .[qr]` then `python -m playwright install firefox`

---

## Installation

```bash
# From source
pip install .

# Optional: only needed for live QR login
pip install .[qr]

# Required after installing the QR extra
python -m playwright install firefox

# For development (includes test dependencies)
pip install -e ".[dev]"
```

Optional location context defaults can be provided through environment variables.
By default the server sends blank location fields, so the repo does not embed any
personal city, district, warehouse, or coordinate values: `TOKOPEDIA_DEFAULT_USER_ADDRESS_ID`,
`TOKOPEDIA_DEFAULT_USER_CITY_ID`, `TOKOPEDIA_DEFAULT_USER_DISTRICT_ID`,
`TOKOPEDIA_DEFAULT_USER_WAREHOUSE_ID`, `TOKOPEDIA_DEFAULT_USER_POSTAL_CODE`,
`TOKOPEDIA_DEFAULT_USER_LAT`, and `TOKOPEDIA_DEFAULT_USER_LONG`.

---

## Running the server

MCP servers communicate over **stdio** and are launched automatically by
compatible AI clients (Claude Desktop, Cursor, etc.).

```bash
tokopedia-mcp-server
```

Or directly with Python:

```bash
python -m tokopedia_mcp.server
```

---

## Claude Desktop integration

Add the following to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "tokopedia": {
      "command": "tokopedia-mcp-server"
    }
  }
}
```

After restarting Claude Desktop you will see the Tokopedia tools available.

---

## Example AI prompts

- *"Search for a gaming laptop under 15 million rupiah and compare the top 3."*
- *"Show me the reviews for product 123456 — are buyers happy with the quality?"*
- *"Get the shop info for 'samsung-id' — is it an official store?"*
- *"Fetch the review photos for product 789 so I can see what the packaging looks like."*

---

## Tool reference

### `search_products`

| Parameter | Type | Default | Description |
|---|---|---|---|
| `query` | `str` | — | Search keyword, e.g. `"laptop gaming"` |
| `page` | `int` | `1` | 1-based page number |
| `rows` | `int` | `60` | Results per page (1–60) |
| `sort_by` | `str` | `"best_match"` | `best_match`, `newest`, `highest_sales`, `lowest_price`, `highest_price`, `most_reviews` |
| `include_images` | `bool` | `false` | Include product image URLs in results |

### `get_product_detail`

| Parameter | Type | Description |
|---|---|---|
| `product_url` | `str` | Full Tokopedia product URL or short link, e.g. `"https://www.tokopedia.com/samsung-id/galaxy-s24"` or `"https://tk.tokopedia.com/..."` |
| `include_media` | `bool` | Include product image/video URLs in the response |
| `variants.selected_confidence` | `str` | Confidence level for selected variants |

When variant data is available, `get_product_detail` may include `variants.selected_confidence`:
- `explicit`: selected options are provided directly by Tokopedia payloads.
- `inferred`: selected options are inferred from page title text as fallback.

When Tokopedia exposes per-variant SKU rows, `get_product_detail` may also include:
- `variant_offers`: list of variant combinations with `option_name`, `price`, `price_value`, `stock`, and variant URL.
- `selected_offer`: best-matched offer for currently selected variants.
- `price_range`: min/max price across available variant offers.

### `get_product_reviews`

| Parameter | Type | Default | Description |
|---|---|---|---|
| `product_id` | `str` | — | Numeric product ID (from search results) |
| `page` | `int` | `1` | Page number |
| `limit` | `int` | `10` | Reviews per page (max 100) |
| `sort_by` | `str` | `"helpful"` | `helpful`, `newest`, `highest_rating`, `lowest_rating` |
| `include_media` | `bool` | `false` | Include review image/video attachment metadata |
| `include_low_signal` | `bool` | `false` | Include low-signal reviews like “just arrived”, “not tested yet”, or packing-only comments |

Returned review items include `variant_name` when Tokopedia provides variant info (for example, color/size combinations).

### `get_shop_info`

| Parameter | Type | Description |
|---|---|---|
| `shop_domain` | `str` | Shop slug, e.g. `"samsung-id"` |

### `get_review_media`

| Parameter | Type | Default | Description |
|---|---|---|---|
| `product_id` | `str` | — | Numeric product ID |
| `page` | `int` | `1` | Page of reviews to scan |
| `limit` | `int` | `10` | Reviews to scan per page |

### `download_media`

| Parameter | Type | Description |
|---|---|---|
| `media_url` | `str` | Direct URL from `image_url`, `thumbnail_url`, or `video_url` fields |

### `generate_login_qr`

Returns a transport-neutral QR payload for MCP hosts:

- Rich clients should prefer `qr_image_data_url` for direct rendering.
- Clients that want raw bytes can decode `qr_image_base64` using `qr_image_mime_type`.
- Terminal-only clients can display `qr_ascii`.
- The server does not open any temporary window or browser popup.
- For live Tokopedia QR generation, the server bootstraps device cookies through a headless Firefox session before returning to the HTTP client flow.

Important fields in the response:

| Field | Description |
|---|---|
| `uuid` | Token to pass into `check_qr_login_status` |
| `qr_image_data_url` | Ready-to-render data URL for GUI/chat clients |
| `qr_image_base64` | Raw base64 image returned by Tokopedia |
| `qr_image_mime_type` | MIME type for `qr_image_base64` |
| `qr_png_base64` | PNG-normalized QR image for clients that prefer PNG |
| `qr_ascii` | ASCII fallback for terminal rendering |

### `check_qr_login_status`

Pass the `uuid` returned by `generate_login_qr`. Possible statuses include `waiting`, `approved`, `rejected`, and `expired`.

---

## Development

```bash
# Run all tests
pytest

# Run tests with verbose output
pytest -v
```

---

## OpenClaw Skill Bundle

This repository includes a ClawHub/OpenClaw skill bundle at:

- `skills/tokopedia_unofficial_mcp/SKILL.md`

Companion files:

- `skills/tokopedia_unofficial_mcp/prompts.txt`
- `skills/tokopedia_unofficial_mcp/publish-notes.txt`

For ClawHub web upload, select the `skills/tokopedia_unofficial_mcp` folder.

---

## License

MIT